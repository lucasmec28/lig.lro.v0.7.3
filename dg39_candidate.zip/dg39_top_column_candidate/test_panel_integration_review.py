"""Independent reviewer integration regressions for DG39 panel demand."""
import unittest
from . import test_direct_route
from .direct4e_route import evaluate_route
class PanelIntegrationReview(unittest.TestCase):
 def sample(self):
  d=test_direct_route.RouteTests().sample()
  d['receiver']['area']=10000
  d['panel']={'receiver_shear_right_up_N':30000,'axes_confirmed':True,'receiver_axial_compression':0}
  return d
 def test_actual_loads_not_meq_or_terminating_shear(self):
  d=self.sample();r=evaluate_route(d)['parts']['C_panel']
  p=d['plate'];q=d['loads'];expected=q['M']/(p['d']-p['tf'])+q['N']/2-30000
  self.assertAlmostEqual(r['signed_demand_N'],expected)
  d['loads']['V']*=2
  self.assertEqual(evaluate_route(d)['parts']['C_panel']['signed_demand_N'],r['signed_demand_N'])
 def test_conflicting_supplied_demand_rejected(self):
  d=self.sample();d['panel']['signed_demand']=0
  with self.assertRaises(ValueError):evaluate_route(d)
 def test_external_demand_remains_unverified(self):
  d=self.sample();d['panel']={'signed_demand':0,'receiver_axial_compression':0}
  r=evaluate_route(d)
  self.assertIn('not derived or verified',r['parts']['C_panel']['equilibrium']['status'])
  self.assertFalse(r['aggregate_approved'])
