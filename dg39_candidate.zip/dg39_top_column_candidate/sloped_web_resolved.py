"""Derived DG39 §3.6 / §3.7.5 web-weld B3/B4/B5 in PLATE axes.
Actual normal/shear demands use real cut areas; physical axial60% development
uses projected area in a distinct envelope case. No directional enhancement.
Not a complete connection route and not an alternate-contact solution.
"""
from math import cos,radians,sqrt,isfinite
from .sloped import resolve_interface,cut_dimensions
from .elastic_weld_group import _finite


def evaluate(d,tf,tw,fy,fu,Fexx,web_leg,pfi,N,M,V,angle_degrees,*,web_joint_orthogonal_confirmed=False):
    if web_joint_orthogonal_confirmed is not True:raise ValueError('Confirm actual web and plate planes form90degree T; no root gap credited')
    vals=[_finite(v,k) for v,k in zip((d,tf,tw,fy,fu,Fexx,web_leg,pfi,N,M,V,angle_degrees),('d','tf','tw','fy','fu','Fexx','web leg','pfi','N','M','V','angle'))]
    d,tf,tw,fy,fu,Fexx,w,pfi,N,M,V,a=vals
    if min(d,tf,tw,fy,fu,Fexx,w,pfi)<=0 or d<=2*tf or fu<fy:raise ValueError('Invalid physical geometry/material')
    if abs(a)>=30:raise ValueError('Outside declared whole-detail skew subset; not a norm limit on web alone')
    r=resolve_interface(N,M,V,a);h=cut_dimensions(d,tf,a)['flange_centers_mm'];c=cos(radians(a))
    P=r['normal_tension_N'];Q=r['tangent_right_N'];Trp=abs(M)/h+max(P,0)/2;Trwp=.5*Trp
    Lclear=(d-2*tf)/c;Lt=pfi+152.4;Lv=min(Lclear-Lt,Lclear/2)
    normal_area=tw*Lt;axial_area=normal_area*c;minimum=.60*fy*axial_area
    out={'source':'Derived DG39 §3.6 resolved paths + §3.7.5; shear example5.2-1 p73, EqJ4-4',
         'normal_N':P,'tangent_N':Q,'moment_Nmm':M,'h_mm':h,
         'normal_flange_envelope_N':Trp,'normal_web_demand_N':Trwp,
         'normal_resultants_N':{'left':P/2-M/h,'right':P/2+M/h},
         'tension_length_real_mm':Lt,'shear_length_requested_mm':Lv,
         'normal_cut_area_mm2':normal_area,'axial_projected_area_mm2':axial_area,
         'physical_axial_development_minimum_N':minimum,
         'directional_enhancement_factor':1.,'resistant_route_qualified':False,'connection_approved':False,
         'development_distribution_assumption':'uniform source development across symmetric web subregion; resultant through corresponding subgroup center. Actual eccentricity requires actual force/moment, not removal of moment.',
         'load_contract':'Actual normal paths useNp,M/h; tangentialVp uses remaining web region. Physical axial60% development is separate envelope, never added to external actions.',
         'pending':['accessible continuous two-sided equal-leg fillets and root detail','source minimum/maximum weld sizes and geometry limits','flange welds, plate/bolts/receiver and complete integrated route','qualify the declared load paths; no contact redistribution inferred']}
    derived=(P,Q,h,Trp,Trwp,Lclear,Lt,Lv,normal_area,axial_area,minimum)
    if not all(isfinite(x) for x in derived):raise ValueError('Derived values exceed numerical domain')
    if Lv<=0:
        out.update(status='separated_partition_unavailable',parts={},note='Requested source zone does not fit; no shortening of6in and no resistance assigned to nonexistent region')
        return out
    a_throat=w/sqrt(2);normal_yield=.9*fy*normal_area
    weld_t=.75*.6*Fexx*2*a_throat*Lt
    weld_v=.75*.6*Fexx*2*a_throat*Lv
    base_v=.75*.6*fu*tw*Lv
    if not all(isfinite(x) and x>0 for x in (normal_yield,weld_t,weld_v,base_v)):raise ValueError('Derived resistance exceeds numerical domain')
    out.update(status='derived_numerical_components',high_tensile_axial_investigation_required=max(P,0)*h>abs(M),parts={
        'B3_web_normal_yield':{'demand_N':Trwp,'LRFD_N':normal_yield,'numeric_comparison':Trwp<=normal_yield,'area_basis':'real cut normal to actual normal force'},
        'B4_web_weld_normal':{'demand_N':Trwp,'LRFD_N':weld_t,'numeric_comparison':Trwp<=weld_t},
        'B4_physical_axial_development':{'demand_N':minimum,'LRFD_N':weld_t,'numeric_comparison':minimum<=weld_t,'direction':'physical column axial, not normal to plate; basic nondirectional weld capacity'},
        'B5_web_weld_shear':{'demand_N':abs(Q),'LRFD_N':weld_v,'numeric_comparison':abs(Q)<=weld_v,'direction':'parallel to real web-weld line'},
        'B5_web_base_shear_rupture':{'demand_N':abs(Q),'LRFD_N':base_v,'numeric_comparison':abs(Q)<=base_v,'area_basis':'tw times real shear rupture length; NOT axial projected area'}
    })
    return out
