"""Declared DG39 §3.7.3 conventional rolled-receiver branch, no added FEM gate."""
REQUIRED=('rolled_I_W_receiver','continuous_both_sides','single_terminating_column','orthogonal_conventional_joint','no_cap_or_stiffener_credit','panel_deformation_not_in_global_analysis','no_opposing_transverse_connection')
def check_panel_domain(declarations):
 missing=[k for k in REQUIRED if declarations.get(k) is not True]
 return {'source':'DG39 §3.7.3 pp40/43; conventional J10-9/10 branch','satisfied':not missing,'missing_or_outside':missing,
         'plate_buckling_extra_check_required_in_this_branch':False,'FEM_required_by_this_branch':False}
