"""Main direct ONE-plate DG39 4E route, isolated, explicit partial qualifications.
Does not switch method to fit a member. Inputs remain free and failures visible.
"""
from math import sqrt,isfinite
from .core import Plate4E,evaluate_A1_A2,extension_shear_A3,CompressionSideShearPath,compression_bolts_A4
from .flush_components import standard_fillet_welds_flush2,receiver_web_local,panel_yield_capacity

def receiver_flange_4e(c,N,M,bf,tf,fy):
 if not all(isfinite(x) and x>0 for x in (bf,tf,fy)):raise ValueError('Positive finite receiver properties required')
 bf_actual=bf
 bf=min(bf,c.member_bf+max(25.4,c.tp)) # DG39 §4.2.2 p51, effective receiver width
 a=evaluate_A1_A2(c,N,M);h1,h2=a['h1_mm'],a['h2_mm'];s=sqrt(bf*c.g)/2;gap=c.pfo+c.tf+c.pfi
 yc=bf/2*(h1+h2)/s+2/c.g*(h2*(3*gap/4+s)+h1*(gap/4+s)+gap**2/2)+c.g/2
 rd=.9*fy*tf**2*yc;sd=1.1*a['Meq_Nmm']
 return {'source':'DG39 Eq3-43/3-44, continuous unstiffened receiver',
 'receiver_bf_actual_mm':bf_actual,'receiver_bf_effective_mm':bf,'effective_width_source':'DG39 §4.2.2 p51',
 'Yc_mm':yc,'required_Nmm':sd,'resistance_Nmm':rd,'numeric_comparison':sd<=rd,
 'source_domain_issues':a['source_domain_issues'],'aggregate_approved':False,
 'pending':['actual continuous receiver geometry and effective flange width','local web and panel','assembly/detail checks']}

def evaluate_route(data):
 """JSON-compatible generic integration, missing substeps listed not silently skipped.
 All profile/plate units mm; stresses MPa; loads N and N.mm. N tension positive.
 """
 if data.get('method','4E')!='4E':raise ValueError('This route stays DG39 4E; variants are separate')
 geometry=data.get('geometry',{})
 if geometry.get('plate_perpendicular_to_column') is not True or geometry.get('plate_parallel_to_receiver_flange') is not True:
  raise ValueError('Confirm orthogonal supported geometry: plate perpendicular to column and parallel to receiver flange')
 c=Plate4E(**data['plate']);loads=data['loads'];N,M,V=(loads[k] for k in ('N','M','V'))
 sign=lambda x:1 if x>0 else -1 if x<0 else 0
 signature={'M_sign':sign(M),'V_sign':sign(V)}
 receiver=data['receiver'];parts={};notes=[]
 parts['A1_A2']=evaluate_A1_A2(c,N,M,V)
 if 'bolt_grade' in data:
  from .materials import bolt_grade
  parts['bolt_material']=bolt_grade(data['bolt_grade'])
  if abs(c.fnt_bolt-parts['bolt_material']['Fnt_MPa'])>1e-5:raise ValueError('Fnt differs from selected DG39 bolt grade')
 else:notes.append('Bolt grade not selected from source-qualified catalogue')
 parts['A3']=extension_shear_A3(c,N,M,data['plate_fu'],data['hole_diameter'])
 if V==0:
  parts['A4']={'status':'not_applicable_zero_shear','A4_numeric_comparison':True,'demand_N':0.,'source':'DG39 A4; no shear action in supplied combination','aggregate_approved':False}
 if 'shear_geometry' in data and V!=0:
  if 'shear_path' in data:raise ValueError('Choose derived shear geometry or explicit clearances, not both')
  if 'bolt_material' not in parts:raise ValueError('Source bolt grade required for automatic shear geometry')
  from .bolt_clearances import derive_shear_path
  g=data['shear_geometry']
  data=dict(data,shear_path=derive_shear_path(c,M,V,data['hole_diameter'],receiver['bf'],g['left_end_distance'],g['right_end_distance'],parts['bolt_material']['Fnv_MPa'],g.get('axes_confirmed',False)))
 if 'shear_geometry' in data:
  from .detailing import standard_three_quarter_edges
  g=data['shear_geometry']
  parts['bolt_details']=standard_three_quarter_edges(c,data['hole_diameter'],receiver['bf'],g['left_end_distance'],g['right_end_distance'])
 if 'shear_path' in data and V!=0:
  q=data['shear_path']
  if q.get('direction_signature')!=signature:raise ValueError('shear_path directional clearances must explicitly match current M/V signs')
  if 'bolt_material' in parts and abs(q['fnv_bolt']-parts['bolt_material']['Fnv_MPa'])>1e-5:raise ValueError('Fnv differs from selected grade with threads included')
  p=CompressionSideShearPath(receiver['tf'],receiver['fu'],data['plate_fu'],q['fnv_bolt'],tuple(q['plate_clear_distances']),tuple(q['receiver_clear_distances']))
  try:
   parts['A4']=compression_bolts_A4(c,p,N,M,V)
   parts['A4']['geometry_inputs']=dict(q)
  except ValueError as e:notes.append('A4: '+str(e))
 elif V!=0:notes.append('A4: provide actual directional hole clearances and bolt Fnv')
 if 'welds' in data:
  w=data['welds'];member=data['member']
  parts['B']=standard_fillet_welds_flush2(c,member['tw'],member['k1'],member['fy'],member['fu'],w['Fexx'],w['flange_leg'],w['web_leg'],N,M,V,_four_e=True)
  if parts['B'].get('status')=='numerical_substeps_only':
   from .detailing import fillet_limits
   edges=w.get('actual_edge_thicknesses',{})
   parts['B_details']={
    'flange':fillet_limits(c.tf,c.tp,w['flange_leg'],c.member_bf/2-member['k1'],edges.get('flange')),
    'web_tension':fillet_limits(member['tw'],c.tp,w['web_leg'],parts['B']['lwt_mm'],edges.get('web')),
    'web_shear':fillet_limits(member['tw'],c.tp,w['web_leg'],parts['B']['lwv_mm'],edges.get('web'))}
 else:notes.append('B: enter actual welds, member material and root geometry')
 parts['C_flange']=receiver_flange_4e(c,N,M,receiver['bf'],receiver['tf'],receiver['fy'])
 if 'local_geometry' in data:
  if 'local_points' in data:raise ValueError('Choose derived local geometry or explicit local points, not conflicting duplicate inputs')
  from .local_transfer import flange_locations
  g=data['local_geometry']
  if 'welds' not in data:raise ValueError('Actual flange weld needed to derive bearing spread Eq3-47')
  data=dict(data,local_points=flange_locations(c.d,c.tf,N,M,g['left_end_distance'],g['right_end_distance'],c.tp,data['welds']['flange_leg'],c.pfo,c.de))
 if 'local_points' in data:
  pts=data['local_points']
  if not pts:raise ValueError('At least actual tension and compression application locations must be supplied')
  ft=max(0.,N/2+abs(M)/(c.d-c.tf));fc=max(0.,-N/2+abs(M)/(c.d-c.tf))
  if max(p['tension_force'] for p in pts)+1e-6<ft or max(p['compression_force'] for p in pts)+1e-6<fc:
   raise ValueError('Local receiver demands cannot omit calculated terminating-member flange forces')
  parts['C_web']=[]
  for p in data['local_points']:
   local=receiver_web_local(receiver['d'],receiver['tw'],receiver['tf'],receiver['kdes'],receiver['fy'],receiver['E'],p['bearing_length'],p['distance_to_end'],p['tension_force'],p['compression_force'])
   local['application_inputs']=dict(p)
   parts['C_web'].append(local)
 else:notes.append('C_web: actual tension/compression locations, spreading and end distances required')
 if 'panel' in data:
  p=data['panel']
  if 'receiver_shear_right_up_N' in p:
   from .panel_equilibrium import one_column_panel_demand
   eq=one_column_panel_demand(c.d,c.tf,N,M,p['receiver_shear_right_up_N'],p.get('axes_confirmed',False))
   demand=eq['signed_demand_N']
   if 'signed_demand' in p and (not isfinite(p['signed_demand']) or abs(p['signed_demand']-demand)>1e-6):raise ValueError('Supplied panel demand differs from source equilibrium')
  else:
   eq={'status':'external demand not derived or verified by this route'}
   demand=p.get('signed_demand')
  if not isinstance(demand,(int,float)) or not isfinite(demand):raise ValueError('Finite numeric panel demand required')
  r=panel_yield_capacity(receiver['d'],receiver['tw'],receiver['fy'],receiver['area'],p['receiver_axial_compression'])
  from .panel_domain import check_panel_domain
  r['domain']=check_panel_domain(p.get('domain',{}))
  if not r['domain']['satisfied']:notes.append('C_panel domain: '+', '.join(r['domain']['missing_or_outside']))
  r['signed_demand_N']=demand;r['equilibrium']=eq;r['numeric_comparison']=abs(demand)<=r['design_capacity_N'];parts['C_panel']=r
 else:notes.append('C_panel: signed demand and receiver axial force required; no zero default')
 c_checks=[parts['C_flange']['numeric_comparison']]
 for local in parts.get('C_web',[]):
  c_checks.extend(local[k] for k in ('tension_yield_numeric','compression_yield_numeric','compression_crippling_numeric'))
 if 'C_panel' in parts:c_checks.append(parts['C_panel']['numeric_comparison'])
 c_complete='C_web' in parts and 'C_panel' in parts
 receiver_outcome=('does_not_meet_unstiffened_configuration' if not all(c_checks) else 'numeric_components_meet_pending_detail_and_domain' if c_complete else 'missing_source_step_inputs')
 result={'method':'DG39 4E direct single plate'
 ,'receiver_unstiffened_outcome':receiver_outcome
 ,'stiffener_branch':'Not implemented or credited. C3-C5 not required if the unstiffened receiver satisfies applicable source checks; otherwise this configuration does not meet.','physical_roles':{'column':'terminating member','beam':'continuous receiver'},
 'direction_signature':signature,
 'active_tension_end':'+d local' if M>0 else '-d local' if M<0 else 'no bending-selected end',
 'clearance_rule':'Every supplied lc is for current M/V sign combination, not reusable automatically after sign reversal',
 'geometry':geometry,'parts':parts,'missing_inputs':notes,'source_domain_issues':parts['A1_A2']['source_domain_issues'],
 'aggregate_approved':False,'status':'component calculations with explicit pending qualification',
 'pending_method_closure':['weld and bolt detailing source requirements','no receiver stiffener resistance credited',
 'explicit panel source-domain declarations when absent','actual source-qualified material and axial domain']}

 from .source_steps import source_step_matrix
 result['source_steps']=source_step_matrix(result)
 required_parts=('A4','B','B_details','bolt_material','bolt_details','C_web','C_panel')
 absent=[k for k in required_parts if k not in parts]
 reasons=list(result['source_domain_issues'])+['missing:'+k for k in absent]
 if parts.get('B',{}).get('status')!='numerical_substeps_only':reasons.append('standard_weld_partition_not_available')
 if parts.get('bolt_details',{}).get('status')!='checked_documented_subset':reasons.append('bolt_detail_subset_not_qualified')
 if not parts.get('C_panel',{}).get('domain',{}).get('satisfied'):reasons.append('panel_domain_not_declared')
 if parts.get('C_panel',{}).get('equilibrium',{}).get('status'):reasons.append('panel_equilibrium_external_unverified')
 if 'local_geometry' not in data:reasons.append('physical_local_positions_not_derived')
 if parts.get('B_details',{}).get('web_shear',{}).get('end_loaded_no_reduction_range') is False:reasons.append('long_web_shear_weld_loading_and_effective_length_not_qualified')
 result['computational_coverage_complete']=not reasons
 result['computational_coverage_reasons']=reasons
 result['all_computed_checks_satisfied']=(not reasons and all(row['state'] in ('numeric_satisfied','not_applicable') for row in result['source_steps'].values()) and all(row.get('detail_satisfied') is not False for row in result['source_steps'].values()))
 result['manual_construction_items']=['head/washer/wrench clearance and weld interference','specified bolt installation and faying contact','actual accessible weld lengths and edge condition','material/filler identification and source welding fabrication requirements']
 result['pending_method_closure']=reasons
 result['verification_limits']=['Published source component benchmarks and synthetic integral test exist; no project approval or experimental validation is implied']
 for component in parts.values():
  entries=component if isinstance(component,list) else [component]
  for entry in entries:
   if isinstance(entry,dict) and 'pending' in entry:
    entry['standalone_component_context_not_route_pending']=entry.pop('pending')
 result['scope_notes']=['No receiver stiffener, cap plate, composite slab contribution or tension-field benefit credited','Manual construction items remain distinct from numeric checks','aggregate_approved remains false; numerical completion is not engineering approval']
 return result
