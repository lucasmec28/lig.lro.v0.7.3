"""DG39 §5.1.3 stage ledger; no new engineering checks and no final approval.
Numerical source components never stand in for detailing/domain completion.
"""
def source_step_matrix(result):
 p=result['parts'];o={}
 def item(name,passed=None,applicable=True,note=''):
  if not applicable:state='not_applicable'
  elif passed is None:state='input_or_method_step_pending'
  elif result['source_domain_issues']:state='outside_source_domain'
  else:state='numeric_satisfied' if passed else 'numeric_not_satisfied'
  o[name]={'state':state,'note':note}
 a=p['A1_A2']
 item('A1',a['A1_numeric_diameter_comparison'],note='Diâmetro dos parafusos; confirmar material real e detalhamento')
 item('A2',a['A2_numeric_thickness_comparison'],note='Chapa de topo pelo modelo de chapa espessa')
 item('A3',p['A3']['A3_numeric_comparison'],note='Cisalhamento da extensão sem nervura')
 item('A4',p.get('A4',{}).get('A4_numeric_comparison'),applicable=p.get('A4',{}).get('status')!='not_applicable_zero_shear',note='Corte, pressão de contato e rasgamento no lado comprimido; distâncias reais')
 w=p.get('B',{})
 item('B2',applicable=False,note='Esta rota não tem nervura na chapa')
 if w.get('status')=='numerical_substeps_only':
  item('B1',w['flange_demand_N']<=w['flange_weld_LRFD_N'] and w['flange_demand_within_nominal_yield'],note='Solda das mesas e desenvolvimento mínimo da fonte; detalhamento pendente')
  item('B3',w['web_tension_demand_N']<=w['web_tension_yield_LRFD_N'],note='Escoamento da alma junto aos parafusos tracionados')
  item('B4',w['web_tension_weld_demand_N']<=w['web_tension_weld_LRFD_N'],note='Solda da alma à tração, incluindo mínimo exigido pela fonte')
  item('B5',w['web_shear_demand_N']<=min(w['web_shear_weld_LRFD_N'],w['web_base_shear_LRFD_N']),note='Solda da alma ao corte e ruptura da alma do perfil')
 else:
  for k in ('B1','B3','B4','B5'):item(k,note=w.get('status','Dados das soldas ausentes'))
 item('C1',applicable=False,note='Receptora contínua sem chapa de fechamento; nenhum benefício de fechamento')
 c=[p['C_flange']['numeric_comparison']]
 for local in p.get('C_web',[]):c.extend(local[k] for k in ('tension_yield_numeric','compression_yield_numeric','compression_crippling_numeric'))
 item('C2',all(c) if 'C_web' in p else None,note='Flexão da mesa e efeitos locais na alma; conferir continuidade e posições reais')
 for k in ('C3','C4','C5'):
  item(k,applicable=False,note='Sem enrijecedor na receptora. Se C2 falhar, a configuração não atende; nenhum reforço presumido.')
 item('C6',p.get('C_panel',{}).get('numeric_comparison'),note='Escoamento do painel; conferir domínio físico e equilíbrio com sinais')
 for k in ('A1','A4'):
  o[k]['detail_satisfied']=p.get('bolt_details',{}).get('detail_pass')
 for k,detail in (('B1','flange'),('B4','web_tension'),('B5','web_shear')):
  q=p.get('B_details',{}).get(detail)
  o[k]['detail_satisfied']=all(q[x] for x in ('minimum_satisfied','edge_maximum_satisfied','length_satisfied')) if q else None
 o['C6']['domain_satisfied']=p.get('C_panel',{}).get('domain',{}).get('satisfied',False)
 return {k:o[k] for k in ('A1','A2','A3','A4','B1','B2','B3','B4','B5','C1','C2','C3','C4','C5','C6')}
