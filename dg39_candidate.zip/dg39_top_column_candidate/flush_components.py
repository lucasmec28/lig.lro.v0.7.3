"""DG39 local components for direct flush2, LRFD; no aggregate approval.
Functions are independent source substeps. They require actual geometry and actions.
"""
from math import sqrt,isfinite
from .flush2 import evaluate_flush2_A1_A2

def _positive(*values):
 if not all(isfinite(v) and v>0 for v in values):raise ValueError('Positive finite inputs required')

def receiver_flange_continuous(c,receiver_bf,receiver_tf,receiver_fy,N,M):
 """AppendixA TableA-1(a), Eq3-43, Example5.2-1 p75 resistance factors.
 Continuous unstiffened receiver, no cap-plate credit. Geometry must actually match.
 """
 _positive(receiver_bf,receiver_tf,receiver_fy)
 receiver_bf_actual=receiver_bf
 receiver_bf=min(receiver_bf,c.member_bf+max(25.4,c.tp)) # DG39 §4.2.2 p51
 a=evaluate_flush2_A1_A2(c,N,M);h=a['h_mm'];s=sqrt(receiver_bf*c.g)/2
 yc=receiver_bf*h/s+4*h*s/c.g
 rd=.9*receiver_fy*receiver_tf**2*yc
 sd=1.10*a['Meq_Nmm']
 return {'source':'DG39 AppendixA TableA-1(a), Eq3-43, LRFD phi=.90',
  'receiver_bf_actual_mm':receiver_bf_actual,'receiver_bf_effective_mm':receiver_bf,
  'source_domain_issues':a['source_domain_issues'],'Yc_mm':yc,'s_mm':s,'required_Nmm':sd,'resistance_Nmm':rd,
  'numeric_comparison':rd>=sd,'aggregate_approved':False,
  'pending':['receiver continuity and no interfering end/opening/stiffener',
             'physical bolt fit and receiver effective width','receiver web and panel',
             'general high axial applicability']}

def receiver_web_local(dc,tcw,tcf,kdes,fy,E,lb,distance_to_end,force_tension,force_compression):
 """DG39 §3.7.6 Eq3-46 and AISC J10-4/5 as quoted pp47–48.
 lb is supplied actual effective bearing length with plate-edge truncation considered.
 I/W receiver only: Qf=1. Unopposed single connection only; compression web buckling for opposing loads excluded.
 """
 _positive(dc,tcw,tcf,kdes,fy,E,lb)
 if not all(isfinite(v) and v>=0 for v in (distance_to_end,force_tension,force_compression)):
  raise ValueError('Nonnegative finite distances/demands required')
 ct=.5 if distance_to_end<dc else 1.
 yielding=(6*ct*kdes+lb)*fy*tcw
 ratio=lb/dc;tr=(tcw/tcf)**1.5
 if distance_to_end>=dc/2:rn=.8*tcw**2*(1+3*ratio*tr)*sqrt(E*fy*tcf/tcw)
 elif ratio<=.2:rn=.4*tcw**2*(1+3*ratio*tr)*sqrt(E*fy*tcf/tcw)
 else:rn=.4*tcw**2*(1+(4*ratio-.2)*tr)*sqrt(E*fy*tcf/tcw)
 crippling=.75*rn
 return {'source':'DG39 §3.7.6, Eq3-46; J10-4/5 quoted by guide',
  'Qf':1.0,'Qf_scope':'wide-flange I/W receiver only; DG39 §3.7.6 pp47–48, example p76','capacity_status':'source component for I/W receiver','single_application_location':True,
  'yielding_resistance_N':yielding,'crippling_resistance_N':crippling,
  'tension_yield_numeric':force_tension<=yielding,
  'compression_yield_numeric':force_compression<=yielding,
  'compression_crippling_numeric':force_compression<=crippling,
  'aggregate_approved':False,
  'pending':['opposing transverse loads if any',
             'receiver panel shear','stiffeners and their welds if required']}

def standard_fillet_welds_flush2(c,tw,k1,fy_member,fu_member,Fexx,w_flange,w_web,N,M,V,*,_four_e=False):
 """DG39 §3.7.5 and Example5.2-1 pp70–73 standard separated weld zones.
 Flange double-sided fillets; web double-sided fillets. Detail/code minimums separate.
 Stops when source-assumed zones do not fit; does NOT invent a reduced 6-inch zone.
 """
 _positive(tw,k1,fy_member,fu_member,Fexx,w_flange,w_web)
 if _four_e:
  from .core import evaluate_A1_A2
  a=evaluate_A1_A2(c,N,M,V)
 else:a=evaluate_flush2_A1_A2(c,N,M)
 if not isfinite(V):raise ValueError('Finite shear required')
 hw=c.d-2*c.tf;lwt=c.pfi+152.4;lwv=min(hw-lwt,hw/2)
 if lwv<=0:
  return {'status':'standard_weld_partition_not_applicable','source_domain_issues':a['source_domain_issues'],'web_clear_mm':hw,
   'tension_zone_requested_mm':lwt,'shear_zone_mm':lwv,'aggregate_approved':False,
   'source':'DG39 §3.7.5 pp44–45',
   'next':'Source allows an effective tee alternative; this function does not implement it'}
 lf=2*c.member_bf-2*k1
 if lf<=0:raise ValueError('Nonpositive flange weld effective length')
 z=c.d-c.tf;ft=abs(M)/z+max(N,0)/2;fc=abs(M)/z+max(-N,0)/2
 fmin=.60*fy_member*c.member_bf*c.tf
 rf=max(ft,fc,fmin)
 flange_rd=.75*.6*Fexx*w_flange/sqrt(2)*lf*1.5
 web_yield_rd=.9*fy_member*tw*lwt
 web_tension_force=ft*(.5 if _four_e else 1.)
 web_weld_demand=max(web_tension_force,.60*fy_member*tw*lwt)
 web_t_rd=.75*2*.6*Fexx*w_web/sqrt(2)*lwt*1.5
 web_v_rd=.75*2*.6*Fexx*w_web/sqrt(2)*lwv
 web_base_v_rd=.75*.6*fu_member*lwv*tw
 return {'source':'DG39 §3.7.5 Eq3-38/39/40/41; '+('Example5.3-1' if _four_e else 'Example5.2-1 pp70–73'),
  'status':'numerical_substeps_only','source_domain_issues':a['source_domain_issues'],
  'flange_yield_nominal_N':fy_member*c.member_bf*c.tf,
  'flange_demand_within_nominal_yield':rf<=fy_member*c.member_bf*c.tf,
  'flange_demand_N':rf,'flange_weld_LRFD_N':flange_rd,
  'web_tension_demand_N':web_tension_force,'web_tension_yield_LRFD_N':web_yield_rd,
  'web_tension_weld_demand_N':web_weld_demand,'web_tension_weld_LRFD_N':web_t_rd,
  'web_shear_demand_N':abs(V),'web_shear_weld_LRFD_N':web_v_rd,'web_base_shear_LRFD_N':web_base_v_rd,
  'lwt_mm':lwt,'lwv_mm':lwv,'aggregate_approved':False,
  'pending':['weld minimum and maximum sizes, actual accessible effective lengths',
             'matching filler/base materials and full detailing','source force applicability',
             'receiver components and panel']}

def shear_two_compression_bolts(c,N,M,V,fnv_bolt,plate_fu,receiver_fu,receiver_tf,plate_clear,receiver_clear):
 """DG39 Example5.2-1 pp69–70; two actual compression-side bolts.
 Requires separately established directional clearances and actual force split.
 """
 from math import pi
 a=evaluate_flush2_A1_A2(c,N,M)
 _positive(fnv_bolt,plate_fu,receiver_fu,receiver_tf)
 if not isfinite(V):raise ValueError('Finite shear required')
 if abs(M)/(c.d-c.tf)-N/2<0:raise ValueError('Separate tension/shear interaction required')
 if len(plate_clear)!=2 or len(receiver_clear)!=2:raise ValueError('Exactly two compression-side bolts required')
 _positive(*plate_clear,*receiver_clear)
 bolt=fnv_bolt*pi*c.db**2/4
 caps=[.75*min(bolt,2.4*c.db*c.tp*plate_fu,1.2*lp*c.tp*plate_fu,
                   2.4*c.db*receiver_tf*receiver_fu,1.2*lr*receiver_tf*receiver_fu)
       for lp,lr in zip(plate_clear,receiver_clear)]
 return {'source':'DG39 Example5.2-1 pp69–70',
  'demand_each_N':abs(V)/2,'design_resistances_each_N':caps,'equal_share_group_strength_N':2*min(caps),
  'numeric_comparison':all(abs(V)/2<=r for r in caps),'aggregate_approved':False,
  'source_domain_issues':a['source_domain_issues'],
  'pending':['actual hole fit/details','bolt group material qualification','large axial applicability','B/C source steps']}

def panel_yield_capacity(dc,tw,fy,area,axial_compression,panel_deformation_in_analysis=False):
 """DG39 §3.7.3 pp40,77, J10-9/10 quoted; LRFD phi=.90.
 Capacity substep ONLY. Demand must follow signed node equilibrium and actual panel.
 No buckling/tension-field or receiver-flange contribution included.
 """
 _positive(dc,tw,fy,area)
 if not isfinite(axial_compression) or axial_compression<0:raise ValueError('Nonnegative axial compression required')
 if panel_deformation_in_analysis:raise ValueError('Different source branch J10-11/12 required')
 ratio=axial_compression/(fy*area)
 if ratio>=1.4:raise ValueError('Yield-capacity branch not physically usable at this axial ratio')
 factor=1. if ratio<=.4 else 1.4-ratio
 return {'source':'DG39 §3.7.3 J10-9/10 and Example5.2-1 p77',
  'design_capacity_N':.90*.60*fy*dc*tw*factor,'axial_reduction_factor':factor,
  'aggregate_approved':False,
  'pending':['signed panel demand from receiver and terminating member actions',
             'panel boundary/geometry matches source','web buckling applicability',
             'receiver local checks and welds']}
