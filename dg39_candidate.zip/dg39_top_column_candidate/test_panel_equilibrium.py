import unittest
from .panel_equilibrium import one_column_panel_demand as calc
class PanelEquilibriumTests(unittest.TestCase):
 def test_independent_signed_equilibrium_benchmark(self):
  # Arithmetic free-body benchmark, not a published DG39 worked example.
  a=calc(520,20,20000,100e6,30000,True)
  b=calc(520,20,-20000,-100e6,-30000,True)
  self.assertEqual(a['signed_demand_N'],180000)
  self.assertEqual(b['signed_demand_N'],-180000)
 def test_force_sum(self):
  r=calc(500,20,10000,48e6,15000,True)
  self.assertEqual(r['signed_demand_N'],90000)
  self.assertEqual(r['source_Pr2_N'],-10000)
 def test_reversal_preserves_sign(self):
  a=calc(500,20,10000,48e6,15000,True)
  b=calc(500,20,-10000,-48e6,-15000,True)
  self.assertEqual(a['signed_demand_N'],-b['signed_demand_N'])
 def test_axes_required(self):
  with self.assertRaises(ValueError):calc(500,20,0,0,0)
 def test_axial_sign(self):
  self.assertEqual(calc(500,20,-10000,0,0,True)['signed_demand_N'],-5000)
if __name__=='__main__':unittest.main()
