"""Geometry-only adapter for DG39 A1/A2,A3,A4 and receiver flange model.
Never use its projected Plate4E for physical section areas, weld development or
receiver properties. Source Table5-9 screening is split from conservative apparent
geometry screening; their intersection is an implementation subset, not a new norm.
"""
from dataclasses import replace,asdict
from math import cos,radians
from .core import evaluate_A1_A2,extension_shear_A3,compression_bolts_A4
from .direct4e_route import receiver_flange_4e
from .sloped import resolve_interface
from .elastic_weld_group import _finite


def evaluate(c,N,M,V,angle_degrees,*,plate_fu,hole_diameter,receiver_bf,receiver_tf,receiver_fy,shear_path=None,shear_clearances_in_resolved_direction=False,common_reference_confirmed=False):
    if common_reference_confirmed is not True:raise ValueError('All supplied actions must refer to the same declared joint point')
    for key,value in asdict(c).items():
        if key!='symmetric_both_ends' and _finite(value,key)<=0:raise ValueError('Positive finite plate input required: '+key)
    for key,value in (('plate_fu',plate_fu),('hole_diameter',hole_diameter),('receiver_bf',receiver_bf),('receiver_tf',receiver_tf),('receiver_fy',receiver_fy)):
        if _finite(value,key)<=0:raise ValueError('Positive finite input required: '+key)
    if plate_fu<c.fy_plate:raise ValueError('Plate ultimate stress cannot be less than yield stress')
    r=resolve_interface(N,M,V,angle_degrees);ca=cos(radians(angle_degrees))
    physical=evaluate_A1_A2(c,0,M,0)
    projected=replace(c,d=c.d/ca,tf=c.tf/ca)
    P=r['normal_tension_N'];Q=r['tangent_right_N'];a=evaluate_A1_A2(projected,P,M,Q)
    range_keys={'Table5-9:d','Table5-9:tf'}
    phys=[x for x in physical['source_domain_issues'] if x in range_keys]
    apparent=[x for x in a['source_domain_issues'] if x in range_keys]
    other=[x for x in a['source_domain_issues'] if x not in range_keys]
    parts={'A1_A2':a,'C_flange':receiver_flange_4e(projected,P,M,receiver_bf,receiver_tf,receiver_fy)}
    pending=[]
    if projected.bp-2*(hole_diameter+25.4/16)<=0:
        pending.append('A3 not computable: nonpositive net width; other theoretical components preserved')
    else:
        parts['A3']=extension_shear_A3(projected,P,M,plate_fu,hole_diameter,allow_incompatible_hole=True)
    if Q == 0:
        parts['A4']={'status':'not_applicable_zero_resolved_shear','demand_N':0.,'A4_numeric_comparison':True,'aggregate_approved':False}
    elif shear_path is not None:
        if shear_clearances_in_resolved_direction is not True:raise ValueError('A4 clear distances must follow actual resolvedVp direction and compression-side group')
        for key in ('receiver_tf','receiver_fu','plate_fu','fnv_bolt'):
            if _finite(getattr(shear_path,key),key)<=0:raise ValueError('Positive A4 material/geometry required')
        for distances in (shear_path.plate_clear_distances,shear_path.receiver_clear_distances):
            if not isinstance(distances,(list,tuple)) or len(distances)!=4 or any(_finite(v,'clearance')<=0 for v in distances):raise ValueError('Four positive finite A4 clearances required')
        if shear_path.receiver_tf!=receiver_tf or shear_path.plate_fu!=plate_fu or shear_path.receiver_fu<receiver_fy:raise ValueError('A4 properties conflict with the same connected parts')
        if abs(M)/(projected.d-projected.tf)-P/2<0:
            pending.append('A4 unavailable: compression-side group in tension; qualified combined tension/shear route required')
        else:parts['A4']=compression_bolts_A4(projected,shear_path,P,M,Q)
    else:pending.append('A4 needs actual four-hole clear distances in resolvedVp direction')
    for p in parts.values():
        p['projected_core_screen_issues']=p.pop('source_domain_issues',[])
        for key in list(p):
            if key.endswith('_checked_domain_conditions_satisfied'):
                p['original_core_geometric_screen_passed']=p.pop(key)
        p['resistant_route_qualified']=False
    return {'source':'Derived geometry composition DG39 §3.6 with source A/C formulas; projected d,tf only for inspected geometry uses',
            'normal_N':P,'tangent_N':Q,'moment_Nmm':M,
            'physical_d_mm':c.d,'physical_tf_mm':c.tf,'plate_geometry_d_mm':projected.d,'plate_geometry_tf_mm':projected.tf,
            'physical_table_depth_thickness_screen':phys,'apparent_table_depth_thickness_screen':apparent,
            'depth_thickness_subset_satisfied':not phys and not apparent,
            'conservative_implementation_subset_satisfied':not phys and not apparent and not other,
            'other_source_screen_issues':other,
            'range_interpretation':'Intersection physical/apparent bounds is conservative implementation scope, not a duplicated normative requirement. Numbers remain theoretical outside; no automatic qualification.',
            'parts':parts,'pending':pending+['complete weld/receiver web/panel/detailing and integrated review'],
            'resistant_route_qualified':False,'connection_approved':False}
