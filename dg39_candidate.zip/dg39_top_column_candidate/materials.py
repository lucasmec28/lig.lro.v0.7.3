"""Small source-backed catalogue, not a claim about the user's actual steel."""
KSI=4448.2216152605/25.4**2
BOLTS={
 'A325 (Group 120)':{'Fnt_MPa':90*KSI,'Fnv_MPa':54*KSI,'source':'DG39 Example5.3-1 p123','threads':'included in shear plane'},
 'A490 (Group 150)':{'Fnt_MPa':113*KSI,'Fnv_MPa':68*KSI,'source':'DG39 Example5.3-2 p138','threads':'included in shear plane'},
}
def bolt_grade(grade):
 if grade not in BOLTS:raise ValueError('Grade not included in this source-qualified subset')
 return dict(BOLTS[grade],grade=grade,actual_certificate_verified=False)
