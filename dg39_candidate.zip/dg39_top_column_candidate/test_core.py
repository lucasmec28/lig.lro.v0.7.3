import unittest,math
from dataclasses import replace
from .core import *
IN=25.4;KIP=4448.2216152605;KSI=KIP/IN**2
C=Plate4E(d=24*IN,tf=.375*IN,member_bf=8*IN,bp=8*IN,tp=.625*IN,g=3*IN,pfi=1.75*IN,pfo=2.5*IN,de=2.5*IN,fy_plate=50*KSI,db=.75*IN,fnt_bolt=90*KSI)
class Tests(unittest.TestCase):
 def test_dg39_example_531_A1_A2(self):
  r=evaluate_A1_A2(C,11*KIP,2510*KIP*IN,33.8*KIP)
  self.assertAlmostEqual(r['Meq_Nmm']/(KIP*IN),2640,delta=1)
  self.assertAlmostEqual(r['Yp_mm']/IN,186,delta=1)
  self.assertAlmostEqual(r['bolt_diameter_required_mm']/IN,.720,delta=.001)
  self.assertAlmostEqual(r['plate_thickness_required_mm']/IN,.589,delta=.001)
  self.assertFalse(r['source_domain_issues']);self.assertFalse(r['aggregate_approved'])
 def test_example_A4(self):
  path=CompressionSideShearPath(.625*IN,65*KSI,65*KSI,54*KSI,(2*IN,)*4,((2.5-.8125/2)*IN,)*4)
  r=compression_bolts_A4(C,path,11*KIP,2510*KIP*IN,33.8*KIP)
  self.assertAlmostEqual(r['equal_distribution_group_strength_N']/KIP,71.7,delta=.2)
  self.assertTrue(r['A4_numeric_comparison']);self.assertFalse(r['aggregate_approved'])
 def test_A4_weak_hole_cannot_be_averaged(self):
  path=CompressionSideShearPath(.625*IN,65*KSI,65*KSI,54*KSI,(.01,100,100,100),(100,)*4)
  r=compression_bolts_A4(C,path,0,1e6,1000)
  self.assertFalse(r['A4_numeric_comparison'])
 def test_A4_tension_side_requires_other_route(self):
  path=CompressionSideShearPath(20,400,400,300,(100,)*4,(100,)*4)
  with self.assertRaises(ValueError):compression_bolts_A4(C,path,1e6,1,100)
 def test_example_A3(self):
  r=extension_shear_A3(C,11*KIP,2510*KIP*IN,65*KSI,.8125*IN)
  self.assertAlmostEqual(r['demand_N']/KIP,55.9,delta=.1)
  self.assertAlmostEqual(r['shear_yield_LRFD_N']/KIP,150,delta=.01)
  self.assertAlmostEqual(r['shear_rupture_LRFD_N']/KIP,114,delta=.5)
 def test_material_and_bolt_limits(self):
  self.assertIn('Section3-7-2:plate steel exceeds 50 ksi',evaluate_A1_A2(replace(C,fy_plate=60*KSI),0,1e6)['source_domain_issues'])
  self.assertIn('Section3-7-2:bolt exceeds 1.5 inch',evaluate_A1_A2(replace(C,db=40),0,1e6)['source_domain_issues'])
 def test_moment_reversal_symmetric_group(self):
  a=evaluate_A1_A2(C,100,1e6);b=evaluate_A1_A2(C,100,-1e6)
  self.assertEqual(a['Meq_Nmm'],b['Meq_Nmm'])
 def test_compression_increases_compressed_flange_not_effective_moment(self):
  a=evaluate_A1_A2(C,-1e5,1e6);b=evaluate_A1_A2(C,0,1e6)
  self.assertEqual(a['Meq_Nmm'],b['Meq_Nmm'])
  self.assertAlmostEqual(a['compression_flange_demand_N']-b['compression_flange_demand_N'],5e4)
  self.assertNotIn('Section3-5:large tensile axial investigation required',a['source_domain_issues'])
 def test_high_tension_flags(self):
  self.assertIn('Section3-5:large tensile axial investigation required',evaluate_A1_A2(C,1e5,1e6)['source_domain_issues'])
 def test_shear_never_claimed_checked(self):
  r=evaluate_A1_A2(C,0,1e6,1e12);self.assertFalse(r['V_checked']);self.assertFalse(r['aggregate_approved'])
 def test_small_diameter_fails_substep(self):
  self.assertFalse(evaluate_A1_A2(replace(C,db=2),11*KIP,2510*KIP*IN)['A1_numeric_diameter_comparison'])
 def test_thin_plate_fails_substep(self):
  self.assertFalse(evaluate_A1_A2(replace(C,tp=2),11*KIP,2510*KIP*IN)['A2_numeric_thickness_comparison'])
 def test_domain_small_profile(self):
  self.assertIn('Table5-9:d',evaluate_A1_A2(replace(C,d=200),0,1e6)['source_domain_issues'])
 def test_direct_roles(self):
  r=evaluate_direct_partial(DirectTopColumnDetail(C,True,True,True,True),0,1e6,100)
  self.assertEqual(r['physical_roles']['terminating_member'],'actual column')
 def test_dual_plate_not_silently_accepted(self):
  with self.assertRaises(ValueError):evaluate_direct_partial(DirectTopColumnDetail(C,True,True,True,False),0,1e6,100)
 def test_sloped_interface_not_silently_accepted(self):
  with self.assertRaises(ValueError):evaluate_direct_partial(DirectTopColumnDetail(C,True,False,True,True),0,1e6,100)
 def test_nonsymmetric_not_accepted(self):
  with self.assertRaises(ValueError):evaluate_A1_A2(replace(C,symmetric_both_ends=False),0,-1e6)
 def test_outside_domain_not_qualified(self):
  self.assertFalse(evaluate_A1_A2(replace(C,d=200),0,1e6)['A1_A2_checked_domain_conditions_satisfied'])
 def test_nonfinite(self):
  with self.assertRaises(ValueError):evaluate_A1_A2(C,math.nan,1)
if __name__=='__main__':unittest.main(verbosity=2)
