"""Experimental composition of inspected DG39 sloped components.

Not the application route. All approvals remain false. The terminating column
is below the plate; actions are supplied at its weld-plane origin. Receiver
contact origin is the normal projection across the physical plate thickness.
This makes moment transport explicit; no fictitious force or shortened weld.
"""
from copy import deepcopy
from dataclasses import asdict
from math import isfinite, cos, radians, isclose
from .core import Plate4E, CompressionSideShearPath
from .sloped import resolve_interface
from .sloped_local_transfer import transfer_clockwise_moment, derive_local_points
from .sloped_plate_receiver_adapter import evaluate as plate_components
from .sloped_flange_resolved import evaluate as flange_components
from .sloped_web_resolved import evaluate as web_components
from .sloped_panel_model import equivalent_plate_and_panel
from .flush_components import receiver_web_local, panel_yield_capacity
from .sloped_panel_domain import check as check_sloped_panel_domain


def _finite_tree(value, path='input'):
    if isinstance(value, dict):
        for key, item in value.items():
            _finite_tree(item, path + '.' + str(key))
    elif isinstance(value, (list, tuple)):
        for index, item in enumerate(value):
            _finite_tree(item, path + '.' + str(index))
    elif isinstance(value, (int, float)) and not isinstance(value, bool) and not isfinite(value):
        raise ValueError('Nonfinite input: ' + path)


def _positive_mapping(mapping, names, path):
    for key in names:
        value = mapping.get(key)
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not isfinite(value) or value <= 0:
            raise ValueError('Positive finite input required: ' + path + '.' + key)


def evaluate(data):
    """Return computable research components, preserving missing component inputs.

    Units: N, mm, MPa. `weld_plane_loads` are global column N,V and clockwise M.
    No loads may be supplied at the receiver centroid instead of the named cut.
    Optional data are omitted explicitly, not filled with engineering defaults.
    """
    _finite_tree(data)
    snapshot = deepcopy(data)
    geometry = data['geometry']
    for key in ('column_below_plate', 'parallel_continuous_receiver_contact',
                'weld_origin_is_column_axis_at_cut', 'contact_origin_is_normal_projection'):
        if geometry.get(key) is not True:
            raise ValueError('Confirm physical geometry/reference: ' + key)
    a = geometry['angle_degrees']
    if isinstance(a, bool) or not isinstance(a, (int, float)) or not isfinite(a) or abs(a) >= 30:
        raise ValueError('Whole-detail research subset requires abs(angle)<30 degrees')
    c = Plate4E(**data['plate'])
    receiver = data['receiver']
    _positive_mapping(receiver, ('d', 'bf', 'tf', 'tw', 'fy', 'fu'), 'receiver')
    if receiver['fu'] < receiver['fy'] or receiver['d'] <= 2*receiver['tf']:
        raise ValueError('Invalid receiver section/material')
    _positive_mapping(data, ('plate_fu', 'hole_diameter'), 'input')
    loads = data['weld_plane_loads']
    N, M, V = (loads[k] for k in ('N', 'M', 'V'))
    resolved = resolve_interface(N, M, V, a)
    # Physical plate is above the terminating column. Positive n points DOWN.
    delta_n = -c.tp
    Mc = transfer_clockwise_moment(resolved['normal_tension_N'], resolved['tangent_right_N'], M, 0., delta_n)
    parts, missing = {}, []
    shear = data.get('shear_path')
    path = None
    if shear is not None:
        expected = {'M_sign': (Mc > 0)-(Mc < 0),
                    'Vp_sign': (resolved['tangent_right_N'] > 0)-(resolved['tangent_right_N'] < 0)}
        if shear.get('direction_signature') != expected:
            raise ValueError('A4 clearances must match contact moment and resolved tangent-force signs')
        path = CompressionSideShearPath(receiver['tf'], receiver['fu'], data['plate_fu'], shear['fnv_bolt'],
                                       tuple(shear['plate_clear_distances']), tuple(shear['receiver_clear_distances']))
    parts['plate_and_receiver_flange'] = plate_components(
        c, N, Mc, V, a, plate_fu=data['plate_fu'], hole_diameter=data['hole_diameter'],
        receiver_bf=receiver['bf'], receiver_tf=receiver['tf'], receiver_fy=receiver['fy'],
        shear_path=path, shear_clearances_in_resolved_direction=path is not None,
        common_reference_confirmed=True)
    if path is None and resolved['tangent_right_N'] != 0:
        missing.append('A4 actual resolved-direction hole clearances and bolt shear material')
    welds, member = data.get('welds'), data.get('member')
    if welds is not None and member is not None:
        _positive_mapping(member, ('tw','fy','fu'), 'member')
        if member['fu'] < member['fy']:
            raise ValueError('Member ultimate stress cannot be less than yield stress')
        parts['flange_welds'] = flange_components(
            c.d,c.tf,c.member_bf,member['fy'],welds['Fexx'],N,M,V,a,welds['flange_details'],
            fitted_root_confirmed=welds.get('fitted_root_confirmed',False),
            local_angles_confirmed=welds.get('local_angles_confirmed',False),
            source_distribution_confirmed=welds.get('source_distribution_confirmed',False))
        parts['web_welds'] = web_components(
            c.d,c.tf,member['tw'],member['fy'],member['fu'],welds['Fexx'],welds['web_leg'],c.pfi,N,M,V,a,
            web_joint_orthogonal_confirmed=welds.get('web_joint_orthogonal_confirmed',False))
        if 'k1' in member:
            from .sloped_weld_detail import inspect as inspect_weld_detail
            legs={q[k] for q in welds['flange_details'].values() for k in ('left_leg_mm','right_leg_mm')}
            if len(legs)==1:
                parts['weld_detail']=inspect_weld_detail(c,member['tw'],member['k1'],next(iter(legs)),welds['web_leg'],a)
            else:
                missing.append('B conventional detail screening only covers one common flange leg; asymmetric welds remain separate study')
    else:
        missing.append('B physical member properties and actual weld details')
    local = data.get('local_contact_geometry')
    if local is not None:
        _positive_mapping(receiver, ('kdes','E'), 'receiver')
        expected_extent = c.d/(2*cos(radians(a))) + c.pfo + c.de
        for edge in ('plate_left_extent','plate_right_extent'):
            if not isclose(local[edge],expected_extent,rel_tol=1e-10,abs_tol=1e-8):
                raise ValueError('Contact plate extent conflicts with the same symmetric 4E plate: '+edge)
        if welds is not None and member is not None:
            for label in ('left','right'):
                detail = welds['flange_details'][label+'_flange']
                if tuple(local['plate_side_legs'][label]) != (detail['left_leg_mm'],detail['right_leg_mm']):
                    raise ValueError('Contact spread and flange weld must use the same actual plate-side legs')
        try:
            points = derive_local_points(c.d,c.tf,N,Mc,V,a,c.tp,
                local['plate_left_extent'],local['plate_right_extent'],
                local['receiver_left_extent'],local['receiver_right_extent'],local['plate_side_legs'],
                contact_reference_confirmed=True,parallel_continuous_contact_confirmed=True)
            parts['receiver_web'] = []
            for point in points:
                result = receiver_web_local(receiver['d'],receiver['tw'],receiver['tf'],receiver['kdes'],
                    receiver['fy'],receiver['E'],point['bearing_length'],point['distance_to_end'],
                    point['tension_force'],point['compression_force'])
                result['application_inputs'] = point
                result['resistant_route_qualified'] = False
                parts['receiver_web'].append(result)
        except ValueError as exc:
            missing.append('C web local geometry not computable: '+str(exc))
    else:
        missing.append('C web actual contact extents and plate-side weld legs')
    panel = data.get('panel')
    if panel is not None:
        _positive_mapping(receiver, ('area',), 'receiver')
        eq = equivalent_plate_and_panel(c.d,c.tf,N,Mc,V,a,panel['receiver_shear_right_local_up_N'],
            axes_confirmed=panel.get('axes_confirmed',False),
            symmetric_single_member_confirmed=panel.get('symmetric_single_member_confirmed',False))
        strength = panel_yield_capacity(receiver['d'],receiver['tw'],receiver['fy'],receiver['area'],
            panel['receiver_axial_compression'],panel.get('panel_deformation_in_analysis',False))
        domain = check_sloped_panel_domain(panel.get('domain',{}))
        strength.update(equilibrium=eq,signed_demand_N=eq['signed_panel_demand_N'],
            numeric_comparison=abs(eq['signed_panel_demand_N'])<=strength['design_capacity_N'],
            domain=domain,method_domain_conditions_satisfied=domain['satisfied'],resistant_route_qualified=False,
            actual_receiver_shear_area_mm2=receiver['d']*receiver['tw'],
            domain_note='Sloped source branch inspected explicitly; old orthogonal-domain flag is not reused')
        parts['panel'] = strength
    else:
        missing.append('C panel signed right receiver shear and receiver axial compression')
    return {'method':'DG39 sloped one-plate experimental component composition',
        'status':'research_components_not_application_route','input_snapshot':snapshot,
        'reference_contract':{'input':'column weld-plane axis origin',
            'contact':'normal projection on receiver contact plane',
            'delta_tangent_mm':0.,'delta_normal_mm':delta_n,
            'normal_N':resolved['normal_tension_N'],'tangent_N':resolved['tangent_right_N'],
            'weld_moment_Nmm':M,'contact_moment_Nmm':Mc,
            'transport_rule':'M_contact=M_weld-tp*Vp; no force is added'},
        'parts':parts,'missing_inputs':missing,
        'panel_domain_pending':([] if parts.get('panel',{}).get('domain',{}).get('satisfied') else ['Declare the applicable conventional receiver panel domain or implement the different source branch']),
        'geometric_admission':{'rule':'Intersection of physical/apparent source bounds; implementation subset, not a duplicated norm',
            'satisfied':parts['plate_and_receiver_flange']['conservative_implementation_subset_satisfied'],
            'interpretation':'Conservative admission restriction, not proof of conservative resistance'},
        'pending_qualification':([] if parts['plate_and_receiver_flange']['conservative_implementation_subset_satisfied'] else ['input outside declared source/geometric subset'])+[
            'physical weld detailing, access and valid local-force distribution',
            'source/physical conditions beyond synthetic arithmetic verification',
            'actual bolt/material/detailing and all applicable source limits'],
        'resistant_route_qualified':False,'connection_approved':False,
        'computational_coverage_complete':False,
        'notes':['No additional global elastic weld-group check is imposed by this composition',
                 'Local development minimums are alternative cases, never added to external loads',
                 'A numerical component passing does not approve the connection']}
