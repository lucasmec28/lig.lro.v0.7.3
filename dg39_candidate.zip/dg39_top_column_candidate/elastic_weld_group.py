"""Isolated weighted elastic weld-line group, not a complete DG39 route.
Derived from AISC Manual 15th ed Part 8 pp8-12/13 and8-16.
Units mm,N,MPa. Right-handed local axes (t,k,n); coordinates in (t,k).
Uniform elastic modulus; rigid connected parts; all supplied throat area effective.
No contact redistribution, directional enhancement, base-metal or local development.
"""
from math import hypot, isfinite, sqrt


def _finite(x, label):
    if isinstance(x, bool) or not isinstance(x, (int,float)):
        raise ValueError(label+' must be finite numeric')
    try: v=float(x)
    except (ValueError,OverflowError): raise ValueError(label+' exceeds numerical domain') from None
    if not isfinite(v): raise ValueError(label+' must be finite numeric')
    return v


def _vec(x, n, label):
    if not isinstance(x,(tuple,list)) or len(x)!=n:
        raise ValueError(label+' has wrong dimension')
    return tuple(_finite(v,label) for v in x)


def _cross(a,b):
    return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])


def evaluate(segments, force_N, moment_Nmm):
    """F,M applied at coordinate origin in right-handed local axes.

    Each segment: start_mm,end_mm (2D), throat_mm,Fexx_MPa,optional name.
    Signed stress includes compression; results are numerical comparisons only.
    This implementation subset requires noncollinear effective weld lines.
    """
    F=_vec(force_N,3,'force'); M=_vec(moment_Nmm,3,'moment')
    if not isinstance(segments,(list,tuple)) or not segments:
        raise ValueError('Actual weld segments required')
    rows=[]
    for i,s in enumerate(segments):
        if not isinstance(s,dict): raise ValueError('Invalid segment')
        a=_vec(s.get('start_mm'),2,'start');b=_vec(s.get('end_mm'),2,'end')
        throat=_finite(s.get('throat_mm'),'throat');fexx=_finite(s.get('Fexx_MPa'),'Fexx')
        length=hypot(b[0]-a[0],b[1]-a[1])
        if throat<=0 or fexx<=0 or length<=0: raise ValueError('Positive throat, Fexx and actual length required')
        rows.append(dict(name=str(s.get('name',i)),a=a,b=b,throat=throat,fexx=fexx,area=throat*length))
    A=sum(s['area'] for s in rows)
    if not isfinite(A) or A<=0: raise ValueError('Derived area exceeds numerical domain')
    C=tuple(sum(s['area']*(s['a'][j]+s['b'][j])/2 for s in rows)/A for j in range(2))
    Suu=Svv=Suv=0.
    for s in rows:
        u0,v0=s['a'][0]-C[0],s['a'][1]-C[1];u1,v1=s['b'][0]-C[0],s['b'][1]-C[1]
        Suu+=s['area']*(u0*u0+u0*u1+u1*u1)/3
        Svv+=s['area']*(v0*v0+v0*v1+v1*v1)/3
        Suv+=s['area']*(2*u0*v0+u0*v1+u1*v0+2*u1*v1)/6
    J=Suu+Svv; det=Suu*Svv-Suv*Suv
    if not all(isfinite(v) for v in (*C,Suu,Svv,Suv,J,det)): raise ValueError('Derived group properties exceed numerical domain')
    if J<=0 or det<=1e-12*J*J:
        raise ValueError('Collinear/ill-conditioned group outside this implementation subset; not a finding of physical failure')
    rxF=_cross((*C,0.),F);Mc=tuple(M[j]-rxF[j] for j in range(3))
    b=(-Mc[1]*Svv-Mc[0]*Suv)/det
    c=(Mc[0]*Suu+Mc[1]*Suv)/det
    results=[]
    for s in rows:
        endpoints=[]
        for u0,v0 in (s['a'],s['b']):
            u,v=u0-C[0],v0-C[1]
            normal=F[2]/A+b*u+c*v
            tau1=F[0]/A-Mc[2]*v/J; tau2=F[1]/A+Mc[2]*u/J
            eq=hypot(normal,tau1,tau2)
            if not isfinite(eq): raise ValueError('Derived stresses exceed numerical domain')
            endpoints.append({'point_mm':(u0,v0),'normal_MPa':normal,'tau_t_MPa':tau1,'tau_k_MPa':tau2,'vector_resultant_MPa':eq})
        cap=.75*.60*s['fexx'];maxeq=max(e['vector_resultant_MPa'] for e in endpoints)
        if not isfinite(cap) or cap<=0 or not isfinite(maxeq/cap): raise ValueError('Derived resistance/ratio exceeds numerical domain')
        results.append({'name':s['name'],'endpoints':endpoints,'maximum_vector_resultant_MPa':maxeq,'basic_LRFD_limit_MPa':cap,'ratio':maxeq/cap,'numeric_comparison':maxeq<=cap})
    return {'source':'Weighted mechanical derivation: AISC Manual15 Part8 pp8-12/13,8-16; not literal DG39 equation',
            'area_mm2':A,'centroid_mm':C,'Suu_mm4':Suu,'Svv_mm4':Svv,'Suv_mm4':Suv,'J_mm4':J,
            'force_N':F,'moment_origin_Nmm':M,'moment_centroid_Nmm':Mc,
            'normal_gradient_MPa_per_mm':(b,c),'parts':results,'directional_enhancement_factor':1.,
            'resistant_route_qualified':False,'connection_approved':False,
            'assumptions':['uniform weld elastic modulus','rigid connected parts','actual effective throat and lengths supplied','no duplicate counting of the same physical weld; coincident physical welds need distinct identification','compression carried by welds; no unilateral contact','right-handed local basis and common action origin'],
            'pending':['DG39 local flange/web development minimum60% and effectiveT definition','base-metal strength and load paths','actual throat detailing/WPS and accessible lengths','plate, bolts, receiver and integrated connection checks']}
