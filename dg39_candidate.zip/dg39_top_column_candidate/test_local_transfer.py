import unittest
from .local_transfer import flange_locations
class LocalTransferTests(unittest.TestCase):
 def f(self,N,M):return flange_locations(520,20,N,M,1000,2000,20,6,40,30)
 def test_signed_flange_distribution_and_distances(self):
  a,b=self.f(20000,100e6)
  self.assertEqual(a['compression_force'],190000)
  self.assertEqual(b['tension_force'],210000)
  self.assertEqual(a['distance_to_end'],750)
  self.assertEqual(b['distance_to_end'],1250)
  self.assertEqual(a['bearing_length'],72)
 def test_pure_axial_compression_both_locations(self):
  p=self.f(-20000,0)
  self.assertEqual([q['compression_force'] for q in p],[10000,10000])
 def test_reversal_swaps_flange_force(self):
  a=self.f(20000,100e6);b=self.f(20000,-100e6)
  self.assertEqual(a[0]['compression_force'],b[1]['compression_force'])
 def test_receiver_end_cannot_omit_bearing_material(self):
  with self.assertRaises(ValueError):flange_locations(520,20,0,1e6,251,2000,20,6,40,30)
 def test_spread_not_invented_if_plate_too_short(self):
  with self.assertRaises(ValueError):flange_locations(520,20,0,1e6,1000,2000,40,10,10,10)

 def test_signed_flange_forces_preserve_axial_and_moment(self):
  for n,m in ((20000,100e6),(-800000,100e6),(800000,-100e6),(0,0)):
   points=self.f(n,m)
   f=[p['tension_force']-p['compression_force'] for p in points]
   self.assertAlmostEqual(sum(f),n)
   self.assertAlmostEqual(sum(q*p['position_mm'] for q,p in zip(f,points)),m)
