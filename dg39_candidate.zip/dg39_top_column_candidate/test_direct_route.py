import unittest
from dataclasses import asdict
from .test_core import C,IN,KIP,KSI
from .direct4e_route import *
class RouteTests(unittest.TestCase):
 def sample(self):
  return {'method':'4E','geometry':{'plate_perpendicular_to_column':True,'plate_parallel_to_receiver_flange':True},'plate':asdict(C),'loads':{'N':11*KIP,'M':2510*KIP*IN,'V':33.8*KIP},'plate_fu':65*KSI,'hole_diameter':.8125*IN,
  'receiver':{'d':26*IN,'bf':8*IN,'tw':.25*IN,'tf':.625*IN,'fy':50*KSI,'fu':65*KSI},
  'member':{'tw':.25*IN,'k1':.125*IN,'fy':50*KSI,'fu':65*KSI},'welds':{'Fexx':70*KSI,'flange_leg':.25*IN,'web_leg':.1875*IN}}
 def test_generic_runs_without_case_specific_input(self):
  r=evaluate_route(self.sample());self.assertFalse(r['aggregate_approved']);self.assertIn('C_flange',r['parts']);self.assertTrue(r['missing_inputs'])
 def test_method_not_changed_to_fit(self):
  d=self.sample();d['plate']['d']=205
  r=evaluate_route(d);self.assertIn('Table5-9:d',r['source_domain_issues']);self.assertEqual(r['method'],'DG39 4E direct single plate')
 def test_rejects_implicit_variant(self):
  d=self.sample();d['method']='flush2'
  with self.assertRaises(ValueError):evaluate_route(d)
 def test_4e_web_force_is_half(self):
  d=self.sample();r=evaluate_route(d)
  self.assertAlmostEqual(r['parts']['B']['web_tension_demand_N'],r['parts']['A1_A2']['tension_flange_demand_N']/2)
 def test_geometry_must_be_confirmed(self):
  d=self.sample();d.pop('geometry')
  with self.assertRaises(ValueError):evaluate_route(d)
 def test_direction_must_match(self):
  d=self.sample();d['shear_path']={'direction_signature':{'M_sign':-1,'V_sign':1}}
  with self.assertRaises(ValueError):evaluate_route(d)
 def test_panel_nan_rejected(self):
  d=self.sample();d['panel']={'signed_demand':float('nan')}
  with self.assertRaises(ValueError):evaluate_route(d)
 def test_unstiffened_receiver_failure_is_not_a_method_switch(self):
  d=self.sample();d['receiver']['tf']=.1
  r=evaluate_route(d)
  self.assertEqual(r['receiver_unstiffened_outcome'],'does_not_meet_unstiffened_configuration')
  self.assertEqual(r['method'],'DG39 4E direct single plate')
 def test_local_demands_cannot_be_omitted(self):
  d=self.sample();d['local_points']=[{'tension_force':0,'compression_force':0}]
  with self.assertRaises(ValueError):evaluate_route(d)
 def test_source_ledger_has_all_steps_no_added_global_checks(self):
  r=evaluate_route(self.sample());steps=r['source_steps']
  self.assertEqual(len(steps),15)
  self.assertEqual(steps['B2']['state'],'not_applicable')
  self.assertEqual(steps['C1']['state'],'not_applicable')
  self.assertEqual(steps['C6']['state'],'input_or_method_step_pending')
  self.assertFalse(r['aggregate_approved'])
 def test_zero_shear_does_not_create_bolt_shear_check(self):
  d=self.sample();d['loads']['V']=0
  r=evaluate_route(d)
  self.assertEqual(r['source_steps']['A4']['state'],'not_applicable')
  self.assertFalse(any(x.startswith('A4:') for x in r['missing_inputs']))
 def test_receiver_width_limited_by_source(self):
  cap=C.member_bf+max(25.4,C.tp)
  a=receiver_flange_4e(C,0,1e6,cap,10,345)
  b=receiver_flange_4e(C,0,1e6,cap*2,10,345)
  self.assertEqual(a['resistance_Nmm'],b['resistance_Nmm'])
  self.assertEqual(b['receiver_bf_effective_mm'],cap)
 def test_receiver_thickness_scaling(self):
  a=receiver_flange_4e(C,0,1e6,200,10,345);b=receiver_flange_4e(C,0,1e6,200,20,345)
  self.assertAlmostEqual(b['resistance_Nmm']/a['resistance_Nmm'],4)
if __name__=='__main__':unittest.main(verbosity=2)
