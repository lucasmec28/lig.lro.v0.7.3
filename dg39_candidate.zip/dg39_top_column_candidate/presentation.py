"""Portuguese UX labels only; no changes to methods or calculated values."""
MISSING={
 'A4: provide actual directional hole clearances and bolt Fnv':'A4 · Caminho do cortante: complete as distâncias às extremidades em Geometria física e ative a derivação dos oito furos, ou informe o caminho avançado.',
 'B: enter actual welds, member material and root geometry':'B · Soldas: informe k1 real da coluna, filetes e consumível em Soldas e entradas complementares.',
 'C_web: actual tension/compression locations, spreading and end distances required':'C · Alma receptora: complete as distâncias às extremidades, kdes e as soldas; ative a derivação das duas mesas.',
 'C_panel: signed demand and receiver axial force required; no zero default':'C · Painel: informe Vrc e força axial da viga receptora, confira os eixos e as condições físicas; zeros precisam ser explícitos.',
}
def missing_message(value):return MISSING.get(value,value)
