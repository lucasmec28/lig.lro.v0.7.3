import unittest
from .materials import *
class MaterialTests(unittest.TestCase):
 def test_source_grade120(self):
  b=bolt_grade('A325 (Group 120)');self.assertAlmostEqual(b['Fnt_MPa']/KSI,90);self.assertAlmostEqual(b['Fnv_MPa']/KSI,54)
 def test_source_grade150(self):
  b=bolt_grade('A490 (Group 150)');self.assertAlmostEqual(b['Fnt_MPa']/KSI,113);self.assertAlmostEqual(b['Fnv_MPa']/KSI,68)
 def test_unknown_grade_not_invented(self):
  with self.assertRaises(ValueError):bolt_grade('200')
