"""DG39 §3.6 coordinate resolution, NOT a qualified sloped resistant route.
Global x right/y up. Column vertical. Positive N pulls column down;
positive V right; M clockwise. Plate tangent rises alpha to the right.
The two unit vectors are t=(cos a,sin a), n=(sin a,-cos a).
All actions are at the SAME interface reference point; no eccentric transfer.
"""
from math import radians,sin,cos,isfinite

def resolve_interface(N,M,V,angle_degrees):
    vals=(N,M,V,angle_degrees)
    if not all(isinstance(v,(int,float)) and not isinstance(v,bool) and isfinite(v) for v in vals):
        raise ValueError('Ações e inclinação devem ser números finitos')
    if not -90 < angle_degrees < 90:
        raise ValueError('Geometria requer -90° < inclinação < 90°; isto não é faixa de qualificação resistente')
    a=radians(angle_degrees);c=cos(a);s=sin(a)
    return {'source':'DG39 §3.6, Fig3-14; projeção vetorial nos eixos explicitados',
            'angle_degrees':angle_degrees,'normal_tension_N':N*c+V*s,
            'tangent_right_N':V*c-N*s,'clockwise_moment_Nmm':M,
            'input_column_N':N,'input_column_V':V,
            'same_reference_point_required':True,'geometry_is_orthogonal':angle_degrees==0,'resistant_route_qualified':False,
            'basis':{'tangent':[c,s],'tension_normal':[s,-c]},
            'pending_sloped_steps':[] if angle_degrees==0 else [
                'Braços dos parafusos e linhas de plastificação medidos na chapa inclinada',
                'Transferência local para alma/mesa e geometria/demanda do painel inclinado',
                'Soldas de junção oblíqua conforme referências internas do DG39 §3.6']}

def cut_dimensions(d,tf,angle_degrees):
    resolve_interface(0,0,0,angle_degrees)
    if not all(isinstance(v,(int,float)) and not isinstance(v,bool) and isfinite(v) and v>0 for v in (d,tf)) or 2*tf>=d:
        raise ValueError('Dimensões de seção inválidas')
    c=cos(radians(angle_degrees))
    return {'cut_depth_mm':d/c,'flange_strip_mm':tf/c,'flange_centers_mm':(d-tf)/c,
            'status':'geometria projetada, não perfil equivalente resistente'}
