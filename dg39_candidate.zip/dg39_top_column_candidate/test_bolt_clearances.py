import unittest
from .test_core import C
from .bolt_clearances import derive_shear_path
class ClearanceTests(unittest.TestCase):
 def f(self,M=1,V=1):return derive_shear_path(C,M,V,22,250,1000,1000,370,True)
 def test_nearest_hole_and_edge(self):
  a=self.f();self.assertEqual(len(a['plate_clear_distances']),4)
  expected=C.pfi+C.tf+C.pfo-22
  self.assertAlmostEqual(a['receiver_clear_distances'][0],expected)
  self.assertAlmostEqual(a['plate_clear_distances'][0],C.de-11)
  self.assertEqual(a['plate_clear_distances'][0],a['plate_clear_distances'][1])
 def test_reversal_symmetric_geometry(self):
  a=self.f();b=self.f(-1,-1)
  self.assertEqual(sorted(a['plate_clear_distances']),sorted(b['plate_clear_distances']))
 def test_shear_reversal_changes_plate_edge_path(self):
  a=self.f(1,-1)
  self.assertAlmostEqual(a['plate_clear_distances'][0],C.pfi+C.tf+C.pfo-22)
 def test_fit_rejected_not_invented(self):
  with self.assertRaises(ValueError):derive_shear_path(C,1,1,22,20,1000,1000,370,True)
 def test_zero_requires_explicit_choice(self):
  with self.assertRaises(ValueError):self.f(0,1)
 def test_piece_forces_are_opposite_and_receiver_near_end_is_used(self):
  outer=C.d/2+C.pfo
  # M+, V-: active outer bolt at -outer; receiver tears toward left end.
  a=derive_shear_path(C,1,-1,22,250,outer+40,1000,370,True)
  self.assertEqual(a['bolt_force_on_plate_sign'],1)
  self.assertEqual(a['bolt_force_on_receiver_sign'],-1)
  self.assertAlmostEqual(a['receiver_clear_distances'][0],29)
  self.assertAlmostEqual(a['plate_clear_distances'][0],C.pfi+C.tf+C.pfo-22)
  self.assertNotEqual(a['receiver_clear_distances'][0],a['plate_clear_distances'][0])
