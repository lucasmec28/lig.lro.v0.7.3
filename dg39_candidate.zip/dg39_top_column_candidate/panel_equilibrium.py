"""DG39 Eq3-34, Fig3-15(a,b): one right-side member, rotated 90 deg CW.
Actual terminating column below continuous receiving beam. No opposing member.
Local +d is right along the receiver; positive M is CW and tensions that side.
N is tensile positive (downward away from receiver). Vrc is receiver shear
positive UP at the RIGHT-hand receiver cut. This is NOT column shear V.
"""
from math import isfinite

def one_column_panel_demand(d,tf,N,M,receiver_shear_right_up_N,axes_confirmed=False):
 if axes_confirmed is not True:raise ValueError('Confirm Fig3-15 right-member clockwise-rotated axes before deriving panel demand')
 if not all(isfinite(x) for x in (d,tf,N,M,receiver_shear_right_up_N)) or tf<=0 or d<=2*tf:
  raise ValueError('Finite actions and valid terminating section required')
 # Original right-side axial Pr2 is compression-positive; Pr2=-N.
 moment=M/(d-tf);axial=N/2;shear=-receiver_shear_right_up_N
 return {'source':'DG39 §3.7.3 Eq3-34, Fig3-15 right member rotated 90deg clockwise; other member absent',
         'signed_demand_N':moment+axial+shear,'moment_term_N':moment,'axial_term_N':axial,'receiver_shear_term_N':shear,
         'source_Pr2_N':-N,'N_tension_positive':True,'M_positive':'clockwise, tension at local +d right side',
         'Vrc_positive':'upward at right receiver cut','column_V_not_used_as_receiver_shear':True,
         'capacity_or_domain_approval':False}
