import unittest
from .detailing import *
from .test_core import C
class DetailTests(unittest.TestCase):
 def test_companion_minimum_examples(self):
  for thinner,other,wmin in ((.25,.375,.125),(.5,2,.1875),(.75,1,.25)):
   r=fillet_limits(thinner*IN,other*IN,wmin*IN,100)
   self.assertEqual(r['minimum_mm'],wmin*IN);self.assertTrue(r['minimum_satisfied'])
 def test_t_joint_not_given_false_maximum(self):
  r=fillet_limits(.25*IN,IN,.3*IN,100)
  self.assertIsNone(r['maximum_mm'])
 def test_actual_edge_companion_example(self):
  r=fillet_limits(.25*IN,.375*IN,.1875*IN,100,edge_thickness=.25*IN)
  self.assertEqual(r['maximum_mm'],.1875*IN)
 def test_three_quarter_edges(self):
  r=standard_three_quarter_edges(C,.8125*IN,200,1000,1000)
  self.assertTrue(r['detail_pass'])
 def test_no_other_hole_extrapolation(self):
  r=standard_three_quarter_edges(C,25,200,1000,1000)
  self.assertEqual(r['status'],'outside_documented_detail_subset')
