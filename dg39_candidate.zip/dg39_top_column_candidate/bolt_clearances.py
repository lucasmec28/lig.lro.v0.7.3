"""Physical circular-hole clearances for direct symmetric 4E, shear along local+d.
Distances only; resistances remain DG39 A4. No minimum edge/wrench rule invented.
"""
from math import isfinite

def derive_shear_path(c,M,V,hole_diameter,receiver_bf,left_end_distance,right_end_distance,fnv_bolt,axes_confirmed=False):
 if axes_confirmed is not True:raise ValueError('Confirm shear positive along local+d (receiver to right)')
 if not all(isfinite(x) and x>0 for x in (hole_diameter,receiver_bf,left_end_distance,right_end_distance,fnv_bolt)):
  raise ValueError('Positive actual hole, receiver, material and end geometry required')
 if not all(isfinite(x) for x in (M,V)) or M==0 or V==0:
  raise ValueError('Automatic compression-side geometry needs nonzero M and V; zero cases require explicit source force-path choice')
 if hole_diameter<c.db:raise ValueError('Hole cannot be smaller than bolt')
 if min(c.bp,receiver_bf)<c.g+hole_diameter:raise ValueError('Holes do not fit inside actual plate/receiver flange width')
 outer=c.d/2+c.pfo;inner=c.d/2-c.tf-c.pfi
 rows=sorted((-outer,-inner,inner,outer))
 if inner<=0 or min(rows[i+1]-rows[i] for i in range(3))<=hole_diameter:
  raise ValueError('Hole rows overlap')
 edge=outer+c.de
 if min(left_end_distance,right_end_distance)<=outer+hole_diameter/2:
  raise ValueError('Receiver ends do not contain all eight holes')
 direction=1 if V>0 else -1;compression=-1 if M>0 else 1
 active=[x for x in rows if x*compression>0]
 def lc(x,left,right,direction):
  next_holes=[direction*(other-x)-hole_diameter for other in rows if direction*(other-x)>0]
  edge_clear=(right-x if direction>0 else x+left)-hole_diameter/2
  return min([edge_clear]+next_holes)
 plate=[];receiver=[];coordinates=[]
 for x in active:
  for y in (-c.g/2,c.g/2):
   plate.append(lc(x,edge,edge,-direction));receiver.append(lc(x,left_end_distance,right_end_distance,direction));coordinates.append((x,y))
 if min(plate+receiver)<=0:raise ValueError('Nonpositive directional clear distance')
 return {'fnv_bolt':fnv_bolt,'plate_clear_distances':plate,'receiver_clear_distances':receiver,
         'direction_signature':{'M_sign':1 if M>0 else -1,'V_sign':direction},
         'compression_bolt_coordinates_mm':coordinates,'hole_diameter_mm':hole_diameter,
         'geometry_source':'Actual eight circular holes, nearest hole or edge under bolt force on each piece; DG39 A4 directional lc',
         'column_shear_external_positive':'local+d',
         'bolt_force_on_plate_sign':-direction,'bolt_force_on_receiver_sign':direction,
         'minimum_edges_and_tool_clearance_not_qualified':True}
