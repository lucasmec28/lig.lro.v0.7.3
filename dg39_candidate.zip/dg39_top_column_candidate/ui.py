"""Isolated Streamlit UI; no repository or production integration."""
import json
from dataclasses import asdict
import streamlit as st
from .core import Plate4E,evaluate_A1_A2
from .direct4e_route import evaluate_route
from .materials import BOLTS,bolt_grade
from .panel_domain import REQUIRED
from .catalog_ui import section,material,bolt_diameter,domain_message
from .drawing import render_svg
from .presentation import missing_message
from .sloped import resolve_interface,cut_dimensions

def render():
    st.title('Viga sobre coluna com uma chapa de topo')
    st.caption('DG39 2023 • rota 4E • coluna terminante e viga contínua receptora • rota candidata')
    st.warning('Método em implementação. Resultados por componente, sem aprovação agregada da ligação. O perfil não altera automaticamente a rota.')
    st.info('Pré-preenchimento confirmado: coluna W200×41,7(H), viga W200×26,6, parafusos 3/4. Dimensões da chapa e posições iniciais são ilustrativas e editáveis. Informe esforços reais para calcular.')
    st.subheader('1 · Perfis e materiais')
    left,right=st.columns(2)
    with left:
     st.markdown('**Coluna terminante**')
     col=section('coluna','W 200 x 41,7 (H)')
     d,bf,tf,tw,fy,fu=[col[k] for k in ('d','bf','tf','tw','fy','fu')]
    with right:
     st.markdown('**Viga contínua receptora**')
     rec=section('viga','W 200 x 26,6')
     rd,rbf,rtf,rtw,rfy,rfu=[rec[k] for k in ('d','bf','tf','tw','fy','fu')]
    st.subheader('2 · Chapa e parafusos')
    angle=st.number_input('Inclinação da viga — graus',min_value=-89.,max_value=89.,value=0.,step=1.,key='dg39_angle',help='Positiva: a viga sobe para a direita. A coluna permanece vertical; a chapa acompanha a mesa da viga. Faixa numérica, não qualificação resistente.')
    if angle!=0:st.warning('Inclinação: desenho, projeções geométricas e transformação de ações disponíveis em estudo. O cálculo resistente inclinado ainda não está habilitado; não se reutiliza silenciosamente a ligação ortogonal.')
    with st.expander('Como medir as cotas da chapa e dos parafusos'):
     st.write('g: distância transversal entre os eixos das duas colunas de furos. pfi: da face INTERNA da mesa da coluna ao centro da fileira interna. pfo: da face EXTERNA da mesa ao centro da fileira externa. de: do centro dessa fileira externa à borda da chapa. Todas as distâncias longitudinais são medidas sobre a chapa, não na projeção horizontal.')
     st.write('bp: largura transversal da chapa; tp: espessura medida normal à chapa; db: diâmetro nominal do parafuso; dh: diâmetro real do furo. Não confundir distância ao centro do furo com distância livre até a borda do furo.')
    a,b,c=st.columns(3)
    with a:
     bp=st.number_input('Largura da chapa mm',min_value=1.,value=166.,key='dg39_bp')
     tp=st.number_input('Espessura da chapa mm',min_value=.1,value=16.,key='dg39_tp')
     fyp,fup,plate_material=material('Aço da chapa','dg39_plate','ASTM A36','plate',tp)
    with b:
     g=st.number_input('Gabarito transversal g mm',min_value=1.,value=70.,key='dg39_g')
     pfi=st.number_input('Distância interna pfi mm',min_value=1.,value=45.,key='dg39_pfi')
     pfo=st.number_input('Distância externa pfo mm',min_value=1.,value=40.,key='dg39_pfo')
     de=st.number_input('Borda externa de mm',min_value=1.,value=35.,key='dg39_de')
    with c:
     db=bolt_diameter()
     dh=st.number_input('Diâmetro do furo mm',min_value=1.,value=20.6375,key='dg39_dh')
     bolt_name=st.selectbox('Material do parafuso',list(BOLTS),key='dg39_bolt_grade')
     bolt=bolt_grade(bolt_name);fnt=bolt['Fnt_MPa']
     st.caption(f"Fnt={fnt:.2f} MPa; Fnv={bolt['Fnv_MPa']:.2f} MPa; rosca no plano de corte. Confirmar especificação real.")
     st.caption('4E simétrica: oito parafusos físicos, quatro tracionados por sentido de momento. Confirmar grupo/material e montagem.')
    plate=Plate4E(d,tf,bf,bp,tp,g,pfi,pfo,de,fyp,db,fnt)
    try:
     screen=evaluate_A1_A2(plate,0,0)
     if screen['source_domain_issues']:st.error('Limites geométricos ou de material: '+'; '.join(domain_message(x) for x in screen['source_domain_issues']))
    except ValueError as e:st.error(str(e))
    orthogonal=st.checkbox('Confirmo chapa perpendicular à coluna e paralela à mesa receptora nesta configuração ortogonal',value=False,key='dg39_orthogonal')
    st.subheader('3 · Esforços na coluna junto à interface')
    st.caption('N positivo em tração; M positivo traciona a extremidade local +d da coluna; V tangente positivo na direção local declarada da chapa. Unidades de entrada kN e kN.m. Não são geradas combinações.')
    a,b,c=st.columns(3)
    with a:Ns=st.text_input('N kN',value='',key='dg39_N')
    with b:Ms=st.text_input('M kN.m',value='',key='dg39_M')
    with c:Vs=st.text_input('V kN',value='',key='dg39_V')
    def drawing_load(raw,scale):
     try:
      import math
      value=float(raw.replace(',','.'))*scale
      return value if math.isfinite(value) else None
     except ValueError:return None
    drawing_data={'angle_degrees':angle,'hole_diameter':dh,'plate':asdict(plate),'member':{'tw':tw},'receiver':{'d':rd,'bf':rbf,'tf':rtf,'tw':rtw},'loads':{'N':drawing_load(Ns,1000),'M':drawing_load(Ms,1e6),'V':drawing_load(Vs,1000)},'labels':{'column':col['name'],'receiver':rec['name']}}
    st.subheader('Desenho dinâmico da ligação')
    try:st.image(render_svg(drawing_data),width='stretch')
    except (ValueError,TypeError) as exc:st.warning('Desenho não gerado: '+str(exc))
    if angle!=0:
     with st.expander('Transformação dos esforços e projeções — DG39 §3.6',expanded=True):
      st.caption('Ações no MESMO ponto da interface: N tração para baixo; V para a direita; M horário. A chapa sobe para a direita quando α é positivo. Não há transferência automática de excentricidade.')
      st.write('N⊥ = N cos α + V sen α; V∥ = V cos α − N sen α; Mchapa = M. A rotação conserva N²+V². Isso não resolve, por si só, painel ou soldas oblíquas.')
      vals=[drawing_load(Ns,1000),drawing_load(Ms,1e6),drawing_load(Vs,1000)]
      if all(x is not None for x in vals):
       resolved=resolve_interface(*vals,angle)
       st.write(f"N⊥ = {resolved['normal_tension_N']/1000:.3f} kN; V∥ = {resolved['tangent_right_N']/1000:.3f} kN; M = {resolved['clockwise_moment_Nmm']/1e6:.3f} kN.m")
      else:st.caption('Preencha N, M e V para apresentar a transformação numérica; não foram assumidos zeros.')
      try:
       cuts=cut_dimensions(d,tf,angle)
       st.write(f"Interseção da coluna na chapa: {cuts['cut_depth_mm']:.2f} mm; distância entre centros das mesas na chapa: {cuts['flange_centers_mm']:.2f} mm. Não são dimensões de um perfil equivalente resistente.")
      except ValueError as exc:st.error('Projeção geométrica não gerada: '+str(exc))
    st.caption('Atualiza com perfis, chapa, furos e ações. Esquema explicativo, não desenho de fabricação nem aprovação da ligação.')
    st.caption('Para painel pela Eq3-34: coluna abaixo da viga, +d para a direita, M positivo horário, N positivo em tração; Vrc é o cortante vertical para cima no corte DIREITO da viga receptora, não V da coluna.')
    with st.expander('Soldas e entradas complementares'):
     st.caption('k1 e kdes não constam explicitamente no catálogo embutido; informe pela fonte do perfil. Não são deduzidos de clear.')
     st.caption('Dados opcionais executam os componentes correspondentes. Ausência será listada; não será convertida em zero nem aprovação.')
     k1s=st.text_input('k1 real da coluna mm para soldas de filete',value='',key='dg39_k1')
     wf=st.number_input('Filete nas mesas mm',min_value=.1,value=6.,key='dg39_wf')
     ww=st.number_input('Filete na alma mm',min_value=.1,value=5.,key='dg39_ww')
     consumable=st.selectbox('Consumível da solda',['E70XX · DG39','Informar manualmente'],key='dg39_consumable')
     fexx=st.number_input('FEXX MPa',min_value=1.,value=482.6330105,disabled=consumable.startswith('E70XX'),key='dg39_fexx')
     extra=st.text_area('Dados avançados JSON para shear_path local_points panel e propriedades receptoras',value='{}',height=130,key='dg39_extra')
     st.caption('Esquema e unidades em README. Ações do painel e distâncias às extremidades devem corresponder ao nó real.')
    with st.expander('Geometria física da receptora — derivação sem JSON'):
     st.caption('Distâncias medidas do centro da coluna às extremidades reais da viga. Não são comprimentos inventados nem distâncias à borda da chapa.')
     eleft=st.text_input('Centro da coluna até extremidade esquerda mm',value='',key='dg39_end_left')
     eright=st.text_input('Centro da coluna até extremidade direita mm',value='',key='dg39_end_right')
     kdes_text=st.text_input('kdes real da viga receptora mm',value='',key='dg39_receiver_kdes')
     elastic=st.number_input('E da viga receptora MPa',min_value=1.,value=200000.,key='dg39_receiver_E')
     auto_local=st.checkbox('Derivar posições e forças das duas mesas e espalhamento Eq3-47',value=False,key='dg39_auto_local')
     auto_shear=st.checkbox('Derivar lc dos oito furos — V externo da coluna positivo para a direita',value=False,key='dg39_auto_shear')
     st.caption('Para forças locais, informe também soldas e k1 da coluna. lc segue ação/reação: sentidos opostos na chapa e na receptora.')
    with st.expander('Painel — equilíbrio do nó pela Eq3-34'):
     auto_panel=st.checkbox('Derivar demanda do painel com os eixos declarados',value=False,key='dg39_auto_panel')
     domain_labels=['Receptora I/W laminada','Receptora contínua dos dois lados','Apenas esta coluna terminante','Nó convencional ortogonal','Sem benefício de cap plate, enrijecedor ou doubler','Deformação do painel não considerada na análise global','Sem ligação transversal oposta']
     domain={k:st.checkbox(label,value=False,key='dg39_domain_'+k) for k,label in zip(REQUIRED,domain_labels)}
     vrc_text=st.text_input('Cortante na viga no corte à DIREITA, positivo para cima kN',value='',key='dg39_receiver_Vrc')
     prc_text=st.text_input('Compressão axial na viga receptora kN, zero explícito se ausente',value='',key='dg39_receiver_Prc')
     st.caption('Área preenchida pelo catálogo do receptor quando selecionado; qualquer alteração é uma entrada manual a conferir. Trocar para perfil manual limpa a área catalogal, salvo rascunho manual salvo nesta sessão.')
     area_text=st.text_input('Área real da seção da viga receptora mm²',value='',key='dg39_receiver_area')
     st.caption('Coluna abaixo da viga; M horário e N tração positivos. Este cortante não é V da coluna. Domínio físico do painel continua explícito.')
    if st.button('Calcular componentes',key='dg39_calculate'):
     if not all(x.strip() for x in (Ns,Ms,Vs)):st.warning('Preencha N, M e V. Zero deve ser informado explicitamente.')
     else:
      try:
       if angle!=0:raise ValueError('Cálculo resistente inclinado ainda não implementado integralmente: faltam braços/linhas de plastificação, transferência/painel e soldas oblíquas. A transformação isolada não autoriza aprovação.')
       if not all(st.session_state.get(k+'_material_valid',False) for k in ('dg39_col','dg39_rec','dg39_plate')):raise ValueError('Material/produto fora da faixa cadastral. Corrija a seleção; não foi extrapolada resistência.')
       val=lambda s:float(s.replace(',','.'))
       data={'method':'4E','bolt_grade':bolt_name,'geometry':{'angle_degrees':angle,'plate_perpendicular_to_column':orthogonal,'plate_parallel_to_receiver_flange':orthogonal},'plate':asdict(plate),'plate_fu':fup,'hole_diameter':dh,
             'loads':{'N':val(Ns)*1000,'M':val(Ms)*1e6,'V':val(Vs)*1000},
             'receiver':{'d':rd,'bf':rbf,'tf':rtf,'tw':rtw,'fy':rfy,'fu':rfu},
             'member':{'tw':tw,'fy':fy,'fu':fu}}
       extras=json.loads(extra)
       if not isinstance(extras,dict):raise ValueError('JSON deve ser objeto')
       allowed={'shear_path','shear_geometry','local_points','local_geometry','panel','receiver_extra'}
       if set(extras)-allowed:raise ValueError('JSON contém campos não suportados; método e perfis não podem ser substituídos ocultamente')
       receiver_extra=extras.pop('receiver_extra',{})
       if set(receiver_extra)-{'kdes','E','area'}:raise ValueError('receiver_extra aceita kdes E area')
       data['receiver'].update(receiver_extra);data.update(extras)
       if k1s.strip():
        data['member']['k1']=val(k1s);data['welds']={'flange_leg':wf,'web_leg':ww,'Fexx':fexx}
       if auto_local or auto_shear:
        ends={'left_end_distance':val(eleft),'right_end_distance':val(eright)}
        if auto_local:
         if 'local_points' in data or 'local_geometry' in data:raise ValueError('Não duplique geometria local em JSON e formulário')
         data['local_geometry']=ends;data['receiver'].update(kdes=val(kdes_text),E=elastic)
        if auto_shear:
         if 'shear_path' in data or 'shear_geometry' in data:raise ValueError('Não duplique caminho de cortante em JSON e formulário')
         data['shear_geometry']=dict(ends,axes_confirmed=True)
       if auto_panel:
        if 'panel' in data:raise ValueError('Não duplique painel em JSON e formulário')
        data['receiver']['area']=val(area_text)
        data['panel']={'receiver_shear_right_up_N':val(vrc_text)*1000,'receiver_axial_compression':val(prc_text)*1000,'axes_confirmed':True,'domain':domain}
       result=evaluate_route(data)
       st.subheader('Resultado parcial')
       for alert in result.get('constructibility_warnings',[]):st.warning('Incompatibilidade construtiva: '+alert)
       if result.get('constructibility_warnings'):st.caption('Os resultados computáveis e a memória permanecem disponíveis; incompatibilidade não foi convertida em atendimento da ligação.')
       states=[row['state'] for row in result['source_steps'].values()]
       c1,c2,c3=st.columns(3)
       c1.metric('Etapas com comparação atendida',states.count('numeric_satisfied'))
       c2.metric('Fora do domínio',states.count('outside_source_domain'))
       c3.metric('Entradas / etapas pendentes',states.count('input_or_method_step_pending'))
       if result['computational_coverage_complete']:
        st.info('Etapas numéricas cobertas no domínio declarado. Resultado: '+('comparações atendidas.' if result['all_computed_checks_satisfied'] else 'há comparações não atendidas.')+' Isso não equivale à aprovação de projeto; confira os detalhes de fabricação.')
       with st.expander('Conferências de fabricação e limites da entrega'):
        for note in result['manual_construction_items']:st.write(note)
        st.write('Testes de componentes publicados e caso sintético integral não são validação experimental desta ligação real.')
       for issue in result['source_domain_issues']:st.error(domain_message(issue))
       for item in result['missing_inputs']:st.warning(missing_message(item))
       st.warning('Sem aprovação agregada. Falha numérica, saída do domínio e etapa pendente têm significados diferentes.')
       labels={'not_applicable':'Não aplicável','input_or_method_step_pending':'Entrada ou etapa pendente','outside_source_domain':'Fora do domínio','numeric_satisfied':'Comparação numérica atende','numeric_not_satisfied':'Comparação numérica não atende'}
       st.subheader('Roteiro da fonte — etapa por etapa')
       st.table([{'Etapa':name,'Estado':labels[row['state']],'Detalhamento':('Atende ao subconjunto conferido' if row.get('detail_satisfied') is True else 'Não atende' if row.get('detail_satisfied') is False else 'Ver observações'),'Observação':row['note']} for name,row in result['source_steps'].items()])
       if result['receiver_unstiffened_outcome']=='does_not_meet_unstiffened_configuration':st.error('O receptor não atende nesta configuração sem enrijecedores. Não foi mudado o método nem creditado reforço.')
       for name,part in result['parts'].items():
        with st.expander('Detalhes técnicos · '+name,expanded=False):st.json(part)
       st.download_button('Baixar memória de cálculo parcial JSON',json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False),'resultado_parcial_DG39.json','application/json')
      except (ValueError,KeyError,TypeError,OverflowError) as e:st.error('Entrada não processada: '+str(e))
    with st.expander('Fonte e roteiro'):
     st.write('DG39 §1.1 Fig1-1c; §3.5 ações axiais; §3.7.5 soldas; §3.7.6 receptor; §5.1.3 A B C; Tabela5-10 para4E. Não se adicionam verificações globais como etapas locais desta rota.')
     st.write('A cobertura depende do preenchimento das entradas e do domínio exibidos em cada etapa. Detalhes de fabricação e certificado precisam ser conferidos. Esta rota não credita enrijecedores: se o receptor falhar, a configuração não atende. A alternativa flush permanece separada e não é selecionada para fazer o perfil passar.')
