"""Isolated Streamlit UI; no repository or production integration."""
import json
from dataclasses import asdict
import streamlit as st
from .core import Plate4E,evaluate_A1_A2
from .direct4e_route import evaluate_route
from .materials import BOLTS,bolt_grade
from .panel_domain import REQUIRED

def render():
    st.title('Viga sobre coluna com uma chapa de topo')
    st.caption('DG39 2023 • rota 4E • coluna terminante e viga contínua receptora • cópia isolada')
    st.warning('Método em implementação. Resultados por componente, sem aprovação agregada da ligação. O perfil não altera automaticamente a rota.')
    st.info('Pré-preenchimento confirmado: coluna W200×41,7(H), viga W200×26,6, parafusos 3/4. Dimensões da chapa e posições iniciais são ilustrativas e editáveis. Informe esforços reais para calcular.')
    left,right=st.columns(2)
    with left:
     st.subheader('Coluna terminante')
     d=st.number_input('Altura da coluna d mm',min_value=1.,value=205.,key='dg39_d')
     bf=st.number_input('Largura de mesa da coluna mm',min_value=1.,value=166.)
     tf=st.number_input('Espessura da mesa da coluna mm',min_value=.1,value=11.8)
     tw=st.number_input('Espessura da alma da coluna mm',min_value=.1,value=7.2)
     fy=st.number_input('fy da coluna MPa',min_value=1.,value=345.)
     fu=st.number_input('fu da coluna MPa',min_value=1.,value=450.)
    with right:
     st.subheader('Viga receptora contínua')
     rd=st.number_input('Altura da viga mm',min_value=1.,value=207.)
     rbf=st.number_input('Largura de mesa da viga mm',min_value=1.,value=133.)
     rtf=st.number_input('Espessura da mesa da viga mm',min_value=.1,value=8.4)
     rtw=st.number_input('Espessura da alma da viga mm',min_value=.1,value=5.8)
     rfy=st.number_input('fy da viga MPa',min_value=1.,value=345.)
     rfu=st.number_input('fu da viga MPa',min_value=1.,value=450.)
    st.subheader('Chapa e parafusos')
    a,b,c=st.columns(3)
    with a:
     bp=st.number_input('Largura da chapa mm',min_value=1.,value=166.)
     tp=st.number_input('Espessura da chapa mm',min_value=.1,value=16.)
     fyp=st.number_input('fy da chapa MPa',min_value=1.,value=250.)
     fup=st.number_input('fu da chapa MPa',min_value=1.,value=400.)
    with b:
     g=st.number_input('Gabarito transversal g mm',min_value=1.,value=70.)
     pfi=st.number_input('Distância interna pfi mm',min_value=1.,value=45.)
     pfo=st.number_input('Distância externa pfo mm',min_value=1.,value=40.)
     de=st.number_input('Borda externa de mm',min_value=1.,value=35.)
    with c:
     db=st.number_input('Diâmetro do parafuso mm',min_value=1.,value=19.05)
     dh=st.number_input('Diâmetro do furo mm',min_value=1.,value=20.6375)
     bolt_name=st.selectbox('Material do parafuso',list(BOLTS),key='dg39_bolt_grade')
     bolt=bolt_grade(bolt_name);fnt=bolt['Fnt_MPa']
     st.caption(f"Fnt={fnt:.2f} MPa; Fnv={bolt['Fnv_MPa']:.2f} MPa; rosca no plano de corte. Confirmar especificação real.")
     st.caption('4E simétrica: oito parafusos físicos, quatro tracionados por sentido de momento. Confirmar grupo/material e montagem.')
    plate=Plate4E(d,tf,bf,bp,tp,g,pfi,pfo,de,fyp,db,fnt)
    try:
     screen=evaluate_A1_A2(plate,0,0)
     if screen['source_domain_issues']:st.error('Limites geométricos ou de material: '+', '.join(screen['source_domain_issues']))
    except ValueError as e:st.error(str(e))
    orthogonal=st.checkbox('Confirmo chapa perpendicular à coluna e paralela à mesa receptora nesta configuração ortogonal',value=False,key='dg39_orthogonal')
    st.subheader('Esforços de cálculo na coluna junto à interface')
    st.caption('N positivo em tração; M positivo traciona a extremidade local +d da coluna; V tangente positivo na direção local declarada da chapa. Unidades de entrada kN e kN.m. Não são geradas combinações.')
    a,b,c=st.columns(3)
    with a:Ns=st.text_input('N kN',value='',key='dg39_N')
    with b:Ms=st.text_input('M kN.m',value='',key='dg39_M')
    with c:Vs=st.text_input('V kN',value='',key='dg39_V')
    st.caption('Para painel pela Eq3-34: coluna abaixo da viga, +d para a direita, M positivo horário, N positivo em tração; Vrc é o cortante vertical para cima no corte DIREITO da viga receptora, não V da coluna.')
    with st.expander('Soldas e entradas complementares'):
     st.caption('Dados opcionais executam os componentes correspondentes. Ausência será listada; não será convertida em zero nem aprovação.')
     k1s=st.text_input('k1 real da coluna mm para soldas de filete',value='',key='dg39_k1')
     wf=st.number_input('Filete nas mesas mm',min_value=.1,value=6.)
     ww=st.number_input('Filete na alma mm',min_value=.1,value=5.)
     fexx=st.number_input('FEXX MPa',min_value=1.,value=482.6330105)
     extra=st.text_area('Dados avançados JSON para shear_path local_points panel e propriedades receptoras',value='{}',height=130,key='dg39_extra')
     st.caption('Esquema e unidades em README. Ações do painel e distâncias às extremidades devem corresponder ao nó real.')
    with st.expander('Geometria física da receptora — derivação sem JSON'):
     st.caption('Distâncias medidas do centro da coluna às extremidades reais da viga. Não são comprimentos inventados nem distâncias à borda da chapa.')
     eleft=st.text_input('Centro da coluna até extremidade esquerda mm',value='',key='dg39_end_left')
     eright=st.text_input('Centro da coluna até extremidade direita mm',value='',key='dg39_end_right')
     kdes_text=st.text_input('kdes real da viga receptora mm',value='',key='dg39_receiver_kdes')
     elastic=st.number_input('E da viga receptora MPa',min_value=1.,value=200000.,key='dg39_receiver_E')
     auto_local=st.checkbox('Derivar posições e forças das duas mesas e espalhamento Eq3-47',value=False,key='dg39_auto_local')
     auto_shear=st.checkbox('Derivar lc dos oito furos — V externo da coluna positivo para a direita',value=False,key='dg39_auto_shear')
     st.caption('Para forças locais, informe também soldas e k1 da coluna. lc segue ação/reação: sentidos opostos na chapa e na receptora.')
    with st.expander('Painel — equilíbrio do nó pela Eq3-34'):
     auto_panel=st.checkbox('Derivar demanda do painel com os eixos declarados',value=False,key='dg39_auto_panel')
     domain_labels=['Receptora I/W laminada','Receptora contínua dos dois lados','Apenas esta coluna terminante','Nó convencional ortogonal','Sem benefício de cap plate, enrijecedor ou doubler','Deformação do painel não considerada na análise global','Sem ligação transversal oposta']
     domain={k:st.checkbox(label,value=False,key='dg39_domain_'+k) for k,label in zip(REQUIRED,domain_labels)}
     vrc_text=st.text_input('Cortante na viga no corte à DIREITA, positivo para cima kN',value='',key='dg39_receiver_Vrc')
     prc_text=st.text_input('Compressão axial na viga receptora kN, zero explícito se ausente',value='',key='dg39_receiver_Prc')
     area_text=st.text_input('Área real da seção da viga receptora mm²',value='',key='dg39_receiver_area')
     st.caption('Coluna abaixo da viga; M horário e N tração positivos. Este cortante não é V da coluna. Domínio físico do painel continua explícito.')
    if st.button('Calcular componentes',key='dg39_calculate'):
     if not all(x.strip() for x in (Ns,Ms,Vs)):st.warning('Preencha N, M e V. Zero deve ser informado explicitamente.')
     else:
      try:
       val=lambda s:float(s.replace(',','.'))
       data={'method':'4E','bolt_grade':bolt_name,'geometry':{'plate_perpendicular_to_column':orthogonal,'plate_parallel_to_receiver_flange':orthogonal},'plate':asdict(plate),'plate_fu':fup,'hole_diameter':dh,
             'loads':{'N':val(Ns)*1000,'M':val(Ms)*1e6,'V':val(Vs)*1000},
             'receiver':{'d':rd,'bf':rbf,'tf':rtf,'tw':rtw,'fy':rfy,'fu':rfu},
             'member':{'tw':tw,'fy':fy,'fu':fu}}
       extras=json.loads(extra)
       if not isinstance(extras,dict):raise ValueError('JSON deve ser objeto')
       allowed={'shear_path','shear_geometry','local_points','local_geometry','panel','receiver_extra'}
       if set(extras)-allowed:raise ValueError('JSON contém campos não suportados; método e perfis não podem ser substituídos ocultamente')
       receiver_extra=extras.pop('receiver_extra',{})
       if set(receiver_extra)-{'kdes','E','area'}:raise ValueError('receiver_extra aceita kdes E area')
       data['receiver'].update(receiver_extra);data.update(extras)
       if k1s.strip():
        data['member']['k1']=val(k1s);data['welds']={'flange_leg':wf,'web_leg':ww,'Fexx':fexx}
       if auto_local or auto_shear:
        ends={'left_end_distance':val(eleft),'right_end_distance':val(eright)}
        if auto_local:
         if 'local_points' in data or 'local_geometry' in data:raise ValueError('Não duplique geometria local em JSON e formulário')
         data['local_geometry']=ends;data['receiver'].update(kdes=val(kdes_text),E=elastic)
        if auto_shear:
         if 'shear_path' in data or 'shear_geometry' in data:raise ValueError('Não duplique caminho de cortante em JSON e formulário')
         data['shear_geometry']=dict(ends,axes_confirmed=True)
       if auto_panel:
        if 'panel' in data:raise ValueError('Não duplique painel em JSON e formulário')
        data['receiver']['area']=val(area_text)
        data['panel']={'receiver_shear_right_up_N':val(vrc_text)*1000,'receiver_axial_compression':val(prc_text)*1000,'axes_confirmed':True,'domain':domain}
       result=evaluate_route(data)
       st.subheader('Resultado parcial')
       if result['computational_coverage_complete']:
        st.info('Etapas numéricas cobertas no domínio declarado. Resultado: '+('comparações atendidas.' if result['all_computed_checks_satisfied'] else 'há comparações não atendidas.')+' Isso não equivale à aprovação de projeto; confira os detalhes de fabricação.')
       with st.expander('Conferências de fabricação e limites da entrega'):
        for note in result['manual_construction_items']:st.write(note)
        st.write('Testes de componentes publicados e caso sintético integral não são validação experimental desta ligação real.')
       for issue in result['source_domain_issues']:st.error(issue)
       for item in result['missing_inputs']:st.warning(item)
       st.warning('Sem aprovação agregada. Falha numérica, saída do domínio e etapa pendente têm significados diferentes.')
       labels={'not_applicable':'Não aplicável','input_or_method_step_pending':'Entrada ou etapa pendente','outside_source_domain':'Fora do domínio','numeric_satisfied':'Comparação numérica atende','numeric_not_satisfied':'Comparação numérica não atende'}
       st.subheader('Roteiro da fonte — etapa por etapa')
       st.table([{'Etapa':name,'Estado':labels[row['state']],'Detalhamento':('Atende ao subconjunto conferido' if row.get('detail_satisfied') is True else 'Não atende' if row.get('detail_satisfied') is False else 'Ver observações'),'Observação':row['note']} for name,row in result['source_steps'].items()])
       if result['receiver_unstiffened_outcome']=='does_not_meet_unstiffened_configuration':st.error('O receptor não atende nesta configuração sem enrijecedores. Não foi mudado o método nem creditado reforço.')
       for name,part in result['parts'].items():
        with st.expander(name,expanded=True):st.json(part)
       st.download_button('Baixar memória de cálculo parcial JSON',json.dumps(result,ensure_ascii=False,indent=2),'resultado_parcial_DG39.json','application/json')
      except (ValueError,KeyError,TypeError,OverflowError) as e:st.error('Entrada não processada: '+str(e))
    with st.expander('Fonte e roteiro'):
     st.write('DG39 §1.1 Fig1-1c; §3.5 ações axiais; §3.7.5 soldas; §3.7.6 receptor; §5.1.3 A B C; Tabela5-10 para4E. Não se adicionam verificações globais como etapas locais desta rota.')
     st.write('Pendente: detalhamento completo das soldas/parafusos, qualificação dos materiais e do painel. Esta rota não credita enrijecedores: se o receptor falhar, a configuração não atende. A alternativa flush permanece separada e não é selecionada para fazer o perfil passar.')
