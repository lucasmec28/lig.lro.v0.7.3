"""Geometria isolada de garganta, DG21 2ª ed. §3.11.3 pp59–60 Fig3-19.
Complemento de soldagem referido pelo DG39 §3.6. NÃO dimensiona a ligação.
'w' = ambas pernas iguais raiz→pé SOBRE as superfícies, não dimensão perpendicular
W de outra figura. Triângulo diagramático de face plana; não avalia concavidade real.
Sem crédito de convexidade/penetração. Sem extrapolar Z-loss.
"""
from math import cos,radians,isfinite

def paired_equal_leg_throats(angle_degrees,leg_left_mm,leg_right_mm,*,fitted_root_confirmed=False,local_angles_confirmed=False):
 if fitted_root_confirmed is not True or local_angles_confirmed is not True:
  raise ValueError("Confirme raiz ajustada sem folga e ângulos locais90±α; inclinação global sozinha é insuficiente")
 vals=(angle_degrees,leg_left_mm,leg_right_mm)
 if not all(isinstance(x,(int,float)) and not isinstance(x,bool) and isfinite(x) for x in vals):
  raise ValueError('Ângulo e pernas devem ser números finitos')
 if leg_left_mm<=0 or leg_right_mm<=0:raise ValueError('Pernas devem ser positivas')
 if not abs(angle_degrees)<30:
  raise ValueError('Subconjunto implementado |α|<30°: ambos ângulos entre60°e120°; fora dele exige tratamento específico, não significa proibição normativa')
 # Vertical flange plane; plate tangent rises alpha to the right.
 # Wedge under plate left is 90-alpha, under plate right 90+alpha.
 psi_left=90-angle_degrees;psi_right=90+angle_degrees
 return {'source':'AISC DG21 2ª ed. §3.11.3 Eq3-1/Fig3-19 pp59–60; DG39 §3.6 remissão a junções oblíquas',
         'angle_degrees':angle_degrees,
         'left':{'dihedral_degrees':psi_left,'equal_legs_mm':leg_left_mm,'geometric_throat_mm':leg_left_mm*cos(radians(psi_left/2))},
         'right':{'dihedral_degrees':psi_right,'equal_legs_mm':leg_right_mm,'geometric_throat_mm':leg_right_mm*cos(radians(psi_right/2))},
         'z_loss_applied_mm':0.,'z_loss_scope':'Somente o subconjunto aberto 60<ψ<120; texto requer Z-loss abaixo60. Não extrapolar a≤60.',
         'resistant_route_qualified':False,'face_assumption':'triângulo diagramático de face plana; garganta real de cordão côncavo não avaliada',
         'pending':['comprimentos efetivos e acessibilidade reais','solicitação e distribuição entre cordões','limites construtivos e WPS aplicável','demais etapas da ligação']}
