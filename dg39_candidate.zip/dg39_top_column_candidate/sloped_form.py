"""Conventional sloped-study form to explicit component contract; no Streamlit.
Defaults are stated model assumptions, not field confirmations. Missing optional
inputs preserve other computable components; no default design actions.
"""
from dataclasses import asdict, replace
from math import cos, radians, isfinite
from .sloped import resolve_interface
from .bolt_clearances import derive_shear_path
from .sloped_local_transfer import transfer_clockwise_moment


def number(raw,label,positive=False,nonnegative=False):
    if isinstance(raw,bool):raise ValueError(label+': informe número válido')
    if not str(raw).strip():raise ValueError(label+': campo vazio; zero deve ser explícito')
    try:v=float(str(raw).replace(',','.'))
    except ValueError:raise ValueError(label+': informe número válido')
    if not isfinite(v):raise ValueError(label+': informe número finito')
    if positive and v<=0:raise ValueError(label+': informe valor maior que zero')
    if nonnegative and v<0:raise ValueError(label+': informe valor maior ou igual a zero')
    return v


def build(plate,receiver,member,angle,actions,fields,options,domain,fnv):
    if not abs(angle)<30:raise ValueError('Estudo inclinado disponível somente para |α|<30°; fora desse subconjunto o detalhe exige outra rota')
    loads={k:number(actions[k],'Esforços · '+k)*scale for k,scale in (('N',1000),('M',1e6),('V',1000))}
    r=resolve_interface(loads['N'],loads['M'],loads['V'],angle);c=cos(radians(angle));mc=loads['M']-plate.tp*r['tangent_right_N']
    pending=[];warnings=[]
    values={}
    labels={'k1':'Soldas · k1 real da coluna mm','end_left':'Geometria física · extremidade esquerda mm','end_right':'Geometria física · extremidade direita mm',
      'receiver_kdes':'Geometria física · kdes real da viga mm','receiver_area':'Painel · área real da viga mm²',
      'receiver_Vrc':'Painel · cortante direito local kN','receiver_Prc':'Painel · compressão axial da viga kN'}
    active={'k1'}
    if options.get('auto_local',True):active.add('receiver_kdes')
    if options.get('auto_local',True) or options.get('auto_shear',True):active.update(('end_left','end_right'))
    if options.get('auto_panel',True):active.update(('receiver_area','receiver_Vrc','receiver_Prc'))
    for key,label in labels.items():
        if key not in active:continue
        raw=fields.get(key,'')
        if str(raw).strip():values[key]=number(raw,label,positive=key not in ('receiver_Vrc','receiver_Prc'),nonnegative=key=='receiver_Prc')
    data={'geometry':{'angle_degrees':angle,'column_below_plate':True,'parallel_continuous_receiver_contact':True,
          'weld_origin_is_column_axis_at_cut':True,'contact_origin_is_normal_projection':True},
       'plate':asdict(plate),'plate_fu':fields['plate_fu'],'hole_diameter':fields['hole_diameter'],
       'weld_plane_loads':loads,'receiver':dict(receiver),'member':dict(member)}
    if 'k1' in values:
        inside=plate.member_bf-2*values['k1'];outside=plate.member_bf
        if inside<=0:
            warnings.append('k1 deixa comprimento interno de solda não positivo; mesas não computadas por esse detalhe')
        else:
            leg=fields['wf']
            def detail(left,right):return {'left_leg_mm':leg,'right_leg_mm':leg,'left_effective_length_mm':left,'right_effective_length_mm':right}
            data['member']['k1']=values['k1']
            data['welds']={'Fexx':fields['fexx'],'web_leg':fields['ww'],
                'flange_details':{'left_flange':detail(outside,inside),'right_flange':detail(inside,outside)},
                'fitted_root_confirmed':True,'local_angles_confirmed':True,'source_distribution_confirmed':True,'web_joint_orthogonal_confirmed':True}
            if plate.bp<plate.member_bf:warnings.append('Largura da chapa menor que a mesa da coluna: comprimentos de solda convencionais são teóricos; montagem exige conferência')
    else:pending.append(labels['k1'])
    ends=all(k in values for k in ('end_left','end_right'))
    if options.get('auto_shear',True) and r['tangent_right_N']!=0:
        if ends:
            projected=replace(plate,d=plate.d/c,tf=plate.tf/c)
            try:
                path=derive_shear_path(projected,mc,r['tangent_right_N'],fields['hole_diameter'],receiver['bf'],values['end_left'],values['end_right'],fnv,True)
                sig=path.pop('direction_signature');path['direction_signature']={'M_sign':sig['M_sign'],'Vp_sign':sig['V_sign']}
                data['shear_path']=path
            except ValueError as e:warnings.append('A4 não derivável neste detalhe: '+str(e))
        else:pending.extend(labels[k] for k in ('end_left','end_right') if k not in values)
    if options.get('auto_local',True):
        if ends and 'receiver_kdes' in values and 'welds' in data:
            extent=plate.d/(2*c)+plate.pfo+plate.de
            data['receiver'].update(kdes=values['receiver_kdes'],E=fields['receiver_E'])
            data['local_contact_geometry']={'plate_left_extent':extent,'plate_right_extent':extent,
               'receiver_left_extent':values['end_left'],'receiver_right_extent':values['end_right'],
               'plate_side_legs':{'left':[fields['wf']]*2,'right':[fields['wf']]*2}}
        else:pending.extend(labels[k] for k in ('end_left','end_right','receiver_kdes','k1') if k not in values)
    if options.get('auto_panel',True):
        if all(k in values for k in ('receiver_area','receiver_Vrc','receiver_Prc')):
            data['receiver']['area']=values['receiver_area']
            data['panel']={'receiver_shear_right_local_up_N':values['receiver_Vrc']*1000,
                'receiver_axial_compression':values['receiver_Prc']*1000,'axes_confirmed':True,
                'symmetric_single_member_confirmed':True,'domain':dict(domain)}
        else:pending.extend(labels[k] for k in ('receiver_area','receiver_Vrc','receiver_Prc') if k not in values)
    if fields['hole_diameter']<plate.db:warnings.append('Furo menor que o parafuso; montagem incompatível, números teóricos não corrigem a geometria')
    if min(plate.bp,receiver['bf'])<plate.g+fields['hole_diameter']:warnings.append('Furos não cabem na largura da chapa/mesa receptora')
    data['declared_premises']={'status':'adopted_model_assumptions_not_field_verified',
       'physical_detail':'Coluna abaixo; chapa paralela à viga; filetes de duas faces com pernas iguais por cordão, raiz ajustada sem folga; sem majoração direcional; comprimentos bf e bf−2k1',
       'reference':'N,V,M no plano da solda; extremidades do receptor medidas da projeção normal dessa origem no contato, ao longo da viga',
       'panel_domain':dict(domain),'unfilled_fields':list(dict.fromkeys(pending)),
       'weld_limits':'Detalhe real, WPS, concavidade e acessibilidade não inspecionados; não usar este ramo se a configuração diferir'}
    return data,list(dict.fromkeys(pending)),warnings
