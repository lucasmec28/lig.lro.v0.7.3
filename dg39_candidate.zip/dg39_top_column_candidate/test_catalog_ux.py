import unittest
from pathlib import Path
from streamlit.testing.v1 import AppTest
from .catalog_ui import PROFILES,MANUAL
APP=str(Path(__file__).with_name('app_isolated.py'))
class CatalogueUXTests(unittest.TestCase):
 def app(self):return AppTest.from_file(APP,default_timeout=30).run()
 def test_catalog_presets_locked_geometry_and_area(self):
  at=self.app();self.assertFalse(at.exception)
  self.assertEqual(at.selectbox(key='dg39_col_profile').value,'W 200 x 41,7 (H)')
  self.assertEqual(at.selectbox(key='dg39_rec_profile').value,'W 200 x 26,6')
  self.assertTrue(at.number_input(key='dg39_d').disabled)
  self.assertAlmostEqual(float(at.text_input(key='dg39_receiver_area').value),PROFILES['W 200 x 26,6']['area'])
 def test_member_switch_independent(self):
  at=self.app();name=list(PROFILES)[-1];old=at.number_input(key='dg39_d').value
  at.selectbox(key='dg39_rec_profile').select(name).run()
  self.assertEqual(at.number_input(key='dg39_rec_d').value,PROFILES[name]['d'])
  self.assertEqual(at.number_input(key='dg39_d').value,old)
 def test_manual_draft_restored(self):
  at=self.app();at.selectbox(key='dg39_col_profile').select(MANUAL).run()
  at.number_input(key='dg39_d').set_value(678.).run()
  at.selectbox(key='dg39_col_profile').select('W 200 x 41,7 (H)').run()
  at.selectbox(key='dg39_col_profile').select(MANUAL).run()
  self.assertEqual(at.number_input(key='dg39_d').value,678.)
 def test_manual_receiver_clears_catalog_area(self):
  at=self.app();at.selectbox(key='dg39_rec_profile').select(MANUAL).run()
  self.assertEqual(at.text_input(key='dg39_receiver_area').value,'')
 def test_material_properties_do_not_change_loads(self):
  at=self.app();at.text_input(key='dg39_M').set_value('12').run()
  at.selectbox(key='dg39_col_material').select('ASTM A36').run()
  self.assertEqual(at.number_input(key='dg39_col_fy').value,250.)
  self.assertEqual(at.number_input(key='dg39_rec_fy').value,345.)
  self.assertEqual(at.text_input(key='dg39_M').value,'12')
 def test_invalid_material_product_blocks_compute(self):
  at=self.app();at.number_input(key='dg39_tp').set_value(201.).run()
  for k in ('N','M','V'):at.text_input(key='dg39_'+k).set_value('0')
  at.button(key='dg39_calculate').click().run()
  self.assertFalse(at.exception)
  self.assertTrue(any('fora da faixa cadastral' in x.value for x in at.error))
  self.assertFalse(any(x.value=='Resultado parcial' for x in at.subheader))
 def test_manual_strength_guard(self):
  at=self.app();at.selectbox(key='dg39_plate_material').select(MANUAL).run()
  at.number_input(key='dg39_plate_fy').set_value(450.).run()
  self.assertTrue(any('fu não pode' in x.value for x in at.error))
 def test_consumable_and_diameter_explicit(self):
  at=self.app();self.assertEqual(at.selectbox(key='dg39_diameter_choice').value,'3/4"')
  at.selectbox(key='dg39_diameter_choice').select('1"').run()
  self.assertEqual(at.number_input(key='dg39_db').value,25.4)
  self.assertTrue(any('não tem todo o detalhamento' in x.value for x in at.warning))
if __name__=='__main__':unittest.main()
