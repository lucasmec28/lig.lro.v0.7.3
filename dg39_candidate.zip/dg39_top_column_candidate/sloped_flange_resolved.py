"""Derived DG39 flange-weld development in resolved plate axes.
DG39 §3.6/§3.7.5 + DG21 theoretical skew throats; basic weld strength only.
Source normal demand and physical axial60% floor are distinct envelope cases.
The generic global elastic group is NOT automatically an additional code check.
"""
from math import isfinite
from .sloped import resolve_interface,cut_dimensions
from .skew_weld_geometry import paired_equal_leg_throats
from .elastic_weld_group import _finite


def evaluate(d,tf,bf,fy,Fexx,N,M,V,angle_degrees,details,*,fitted_root_confirmed=False,local_angles_confirmed=False,source_distribution_confirmed=False):
    if source_distribution_confirmed is not True:raise ValueError('Confirm source detail with admissible force distribution; arbitrary asymmetric lengths do not establish equilibrium by area summation alone')
    d,tf,bf,fy,Fexx,N,M,V,a=[_finite(v,k) for v,k in zip((d,tf,bf,fy,Fexx,N,M,V,angle_degrees),('d','tf','bf','fy','Fexx','N','M','V','angle'))]
    if min(d,tf,bf,fy,Fexx)<=0 or d<=2*tf:raise ValueError('Invalid physical section/material')
    if not isinstance(details,dict) or set(details)!={'left_flange','right_flange'}:raise ValueError('Both actual flange weld details required')
    resolved=resolve_interface(N,M,V,a);h=cut_dimensions(d,tf,a)['flange_centers_mm'];P=resolved['normal_tension_N'];Trp=abs(M)/h+max(P,0)/2;minimum=.6*fy*bf*tf
    if not all(isfinite(x) for x in (h,P,Trp,minimum)):raise ValueError('Derived demand exceeds numerical domain')
    parts={}
    for name in ('left_flange','right_flange'):
        q=details[name]
        required={'left_leg_mm','right_leg_mm','left_effective_length_mm','right_effective_length_mm'}
        if not isinstance(q,dict) or set(q)!=required:raise ValueError('Actual legs and accessible lengths required')
        left=_finite(q['left_effective_length_mm'],'left length');right=_finite(q['right_effective_length_mm'],'right length')
        if min(left,right)<=0:raise ValueError('Positive effective lengths required')
        throat=paired_equal_leg_throats(a,q['left_leg_mm'],q['right_leg_mm'],fitted_root_confirmed=fitted_root_confirmed,local_angles_confirmed=local_angles_confirmed)
        Aw=throat['left']['geometric_throat_mm']*left+throat['right']['geometric_throat_mm']*right
        Rd=.75*.6*Fexx*Aw
        if not isfinite(Rd) or Rd<=0:raise ValueError('Derived resistance exceeds numerical domain')
        parts[name]={'source_normal_development_N':Trp,'physical_axial_minimum_N':minimum,'basic_LRFD_N':Rd,'effective_throat_area_mm2':Aw,
                     'normal_numeric_comparison':Trp<=Rd,'axial_minimum_numeric_comparison':minimum<=Rd,'throats':throat}
    return {'source':'Derived DG39 §3.6/§3.7.5 + DG21 equal-leg geometric throats; kds1',
            'normal_N':P,'tangent_N':resolved['tangent_right_N'],'moment_Nmm':M,'h_mm':h,
            'parts':parts,'directional_enhancement_factor':1.,'resistant_route_qualified':False,'connection_approved':False,
            'high_tensile_axial_investigation_required':max(P,0)*h>abs(M),
            'source_distribution_confirmed':True,
            'detail_coordinates':'left/right mean global left/right along inclined plate around EACH flange, not inside/outside. Left flange outside=left; right flange outside=right. Do not swap throat and effective length labels.',
            'assumptions':['source symmetric flange load-path model','actual accessible effective weld lengths supplied','geometric throats, no gap or extra penetration benefit','basic strength area summation with admissible force distribution; no optional directional increase'],
            'pending':['complete actual detail/minimum and maximum weld sizes','nominal physical flange/member limits and connection geometry','source domain and integrated plate/bolts/receiver checks'],
            'envelope_rule':'Normal demand and physical axial minimum are not simultaneous added actions; no compression envelope invented as Eq3-38 requirement'}
