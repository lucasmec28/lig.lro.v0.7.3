"""Two physical flange application points, DG39 §3.5 Fig3-13 and Eq3-47.
No replacement for actual local geometry; no invented project dimensions.
"""
from math import isfinite

def flange_locations(d,tf,N,M,left_end_distance,right_end_distance,tp,flange_weld_leg,pfo,de):
 vals=(d,tf,left_end_distance,right_end_distance,tp,flange_weld_leg,pfo,de)
 if not all(isfinite(v) and v>0 for v in vals) or not all(isfinite(v) for v in (N,M)) or d<=2*tf:
  raise ValueError('Finite loads and positive actual geometry required')
 z=d-tf
 if min(left_end_distance,right_end_distance)<=z/2:
  raise ValueError('Receiver does not continue past both flange application points')
 # Eq3-47 may only be used untruncated when the outer spreading fits plate end.
 if flange_weld_leg+tp>pfo+de:
  raise ValueError('Untruncated Eq3-47 bearing spread exceeds plate end; actual spreading needs separate treatment')
 lb=tf+2*flange_weld_leg+2*tp
 if min(left_end_distance,right_end_distance)-z/2<lb/2:
  raise ValueError('Full Eq3-47 bearing strip extends beyond receiver end; no truncation model supplied')
 out=[]
 for side in (-1,1):
  x=side*z/2;f=N/2+side*M/z
  out.append({'position_mm':x,'tension_force':max(f,0.),'compression_force':max(-f,0.),
              'distance_to_end':min(left_end_distance+x,right_end_distance-x),'bearing_length':lb,
              'source':'DG39 §3.5 Fig3-13; §3.7.6 Eq3-47; signed physical flange force',
              'receiver_continues_beyond_both_points':True})
 return out
