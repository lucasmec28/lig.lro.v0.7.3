"""Versioned DG39 input drafts, independent of Streamlit and resistance routines.
Call apply_import BEFORE creating widgets, normally in an explicit import callback.
No upload hash/deduplication: the same project can intentionally be reapplied.
"""
import json,math
from copy import deepcopy
from .panel_domain import REQUIRED
from .materials import BOLTS
SCHEMA='lro.dg39.project'
VERSION=1
MAX_BYTES=262144
MAX_TEXT=128
MANUAL='Informar manualmente'
UNITS={'geometry':'mm','stress':'MPa','forces':'kN','moment':'kN.m','angle':'degree'}
NUMERIC={'dg39_d','dg39_col_bf','dg39_col_tf','dg39_col_tw','dg39_rec_d','dg39_rec_bf','dg39_rec_tf','dg39_rec_tw','dg39_col_fy','dg39_col_fu','dg39_rec_fy','dg39_rec_fu','dg39_plate_fy','dg39_plate_fu','dg39_bp','dg39_tp','dg39_g','dg39_pfi','dg39_pfo','dg39_de','dg39_db','dg39_dh','dg39_wf','dg39_ww','dg39_fexx','dg39_receiver_E','dg39_angle'}
TEXT_NUMERIC={'dg39_N','dg39_M','dg39_V','dg39_k1','dg39_end_left','dg39_end_right','dg39_receiver_kdes','dg39_receiver_Vrc','dg39_receiver_Prc','dg39_receiver_area','dg39_rec_manual_area'}
BOOLEAN={'dg39_orthogonal','dg39_auto_local','dg39_auto_shear','dg39_auto_panel'}|{'dg39_domain_'+k for k in REQUIRED}
SELECTION={'dg39_col_profile','dg39_rec_profile','dg39_col_material','dg39_rec_material','dg39_plate_material','dg39_diameter_choice','dg39_bolt_grade','dg39_consumable'}
DRAFTS={'dg39_col_manual_draft':{'d','bf','tf','tw'},'dg39_rec_manual_draft':{'d','bf','tf','tw'},**{f'dg39_{k}_manual_material_draft':{'fy','fu'} for k in ('col','rec','plate')}}
ALLOWED=NUMERIC|TEXT_NUMERIC|BOOLEAN|SELECTION|set(DRAFTS)|{'dg39_extra'}
DERIVED={f'dg39_{k}_{suffix}' for k in ('col','rec','plate') for suffix in ('last_profile','last_material','material_valid')}|{'dg39_last_diameter','dg39_result','dg39_results','dg39_last_result','dg39_calculation_result'}

class ProjectError(ValueError):pass

def _finite(value,key,positive=False):
    if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value):raise ProjectError(key+': número finito exigido')
    if abs(value)>1e12:raise ProjectError(key+': excede limite operacional de magnitude')
    if positive and value<=0:raise ProjectError(key+': valor positivo exigido')
    return float(value)

def _pairs(items):
    out={}
    for key,value in items:
        if key in out:raise ProjectError('Chave JSON duplicada: '+key)
        out[key]=value
    return out

def _json(text):
    try:return json.loads(text,object_pairs_hook=_pairs,parse_constant=lambda token:(_ for _ in ()).throw(ProjectError('Constante não finita: '+token)))
    except (ValueError,TypeError,RecursionError) as exc:raise ProjectError('JSON inválido: '+str(exc)) from exc

def _tree(value,depth=0):
    if depth>12:raise ProjectError('JSON avançado excede profundidade permitida')
    if isinstance(value,dict):
        for key,item in value.items():
            if not isinstance(key,str) or key.startswith('__') or key in {'constructor','prototype'}:raise ProjectError('Chave avançada não permitida')
            _tree(item,depth+1)
    elif isinstance(value,list):
        if len(value)>10000:raise ProjectError('Lista avançada excessiva')
        for item in value:_tree(item,depth+1)
    elif isinstance(value,(int,float)) and not isinstance(value,bool):_finite(value,'JSON avançado')
    elif value is not None and not isinstance(value,(str,bool)):raise ProjectError('Tipo avançado inválido')

def _catalogues():
    from lro.models import profiles,STEELS,DIAMETERS
    return {name:p for name,p in profiles().items() if p.family=='W'},STEELS,DIAMETERS

def _validate(state):
    if not isinstance(state,dict):raise ProjectError('state deve ser objeto JSON')
    unknown=set(state)-ALLOWED
    if unknown:raise ProjectError('Campos não permitidos: '+', '.join(sorted(unknown)))
    out={};profiles,steels,diameters=_catalogues()
    for key,value in state.items():
        if key in NUMERIC:
            out[key]=_finite(value,key,key!='dg39_angle')
            if key=='dg39_angle' and not -89<=out[key]<=89:raise ProjectError('Inclinação fora do intervalo da interface')
        elif key in TEXT_NUMERIC:
            if not isinstance(value,str) or len(value)>MAX_TEXT:raise ProjectError(key+': texto numérico curto exigido')
            out[key]=value
        elif key in BOOLEAN:
            if type(value) is not bool:raise ProjectError(key+': booleano exigido')
            out[key]=value
        elif key in SELECTION:
            if not isinstance(value,str) or len(value)>256:raise ProjectError(key+': seleção textual exigida')
            if key.endswith('_profile'):choices=set(profiles)|{MANUAL}
            elif key.endswith('_material'):
                product='plate' if key=='dg39_plate_material' else 'profile'
                choices={n for n,s in steels.items() if (s.plate_allowed if product=='plate' else s.rolled_allowed)}|{MANUAL}
            elif key=='dg39_diameter_choice':choices=set(diameters)|{MANUAL}
            elif key=='dg39_bolt_grade':choices=set(BOLTS)
            else:choices={'E70XX · DG39',MANUAL}
            if value not in choices:raise ProjectError(key+': opção indisponível no catálogo atual: '+value)
            out[key]=value
        elif key in DRAFTS:
            if not isinstance(value,dict) or set(value)!=DRAFTS[key]:raise ProjectError(key+': estrutura de rascunho incompleta ou não permitida')
            out[key]={k:_finite(v,key+'.'+k,True) for k,v in value.items()}
        elif key=='dg39_extra':
            if not isinstance(value,str) or len(value.encode('utf-8'))>65536:raise ProjectError('JSON avançado deve ser texto com até 64 KiB')
            extra=_json(value.strip() or '{}')
            if not isinstance(extra,dict) or set(extra)-{'shear_path','shear_geometry','local_points','local_geometry','panel','receiver_extra'}:raise ProjectError('Objeto avançado contém campos não suportados')
            _tree(extra);out[key]=value
    return out


def draft_warnings(state):
    """Raw text drafts may be saved; validation remains mandatory at calculation."""
    warnings=[]
    names={'dg39_N':'Esforços · N kN','dg39_M':'Esforços · M kN.m','dg39_V':'Esforços · V kN','dg39_k1':'Soldas · k1 da coluna','dg39_end_left':'Geometria física · extremidade esquerda','dg39_end_right':'Geometria física · extremidade direita','dg39_receiver_kdes':'Geometria física · kdes da viga','dg39_receiver_Vrc':'Painel · Vrc','dg39_receiver_Prc':'Painel · compressão axial','dg39_receiver_area':'Painel · área da viga','dg39_rec_manual_area':'Perfil manual · área da viga'}
    for key in sorted(TEXT_NUMERIC):
        value=state.get(key,'')
        if not isinstance(value,str) or not value.strip():continue
        try:
            number=float(value.strip().replace(',','.'))
            if not math.isfinite(number):warnings.append(names.get(key,key)+': texto não representa número finito')
            elif abs(number)>1e12:warnings.append(names.get(key,key)+': magnitude exige conferência')
        except ValueError:warnings.append(names.get(key,key)+': texto precisa ser corrigido para calcular')
    return warnings

def serialize_state(state):
    """Export only input whitelist; ignore buttons/uploads/results/other apps."""
    draft={k:deepcopy(state[k]) for k in ALLOWED if k in state}
    # Recover the old material/section draft collision without guessing dimensions.
    for prefix in ('dg39_col','dg39_rec','dg39_plate'):
        old=state.get(prefix+'_manual_draft')
        if isinstance(old,dict) and set(old)=={'fy','fu'}:
            draft.pop(prefix+'_manual_draft',None)
            draft.setdefault(prefix+'_manual_material_draft',deepcopy(old))
    clean=_validate(draft)
    body={'schema':SCHEMA,'version':VERSION,'method':'4E','units':UNITS,'state':clean}
    encoded=json.dumps(body,ensure_ascii=False,indent=2,allow_nan=False,sort_keys=True)
    if len(encoded.encode('utf-8'))>MAX_BYTES:raise ProjectError('Projeto excede 256 KiB')
    return encoded

def parse_project(payload):
    """Parse a project file; return validated UI inputs, not calculated results."""
    if isinstance(payload,bytes):
        if len(payload)>MAX_BYTES:raise ProjectError('Projeto excede 256 KiB')
        try:payload=payload.decode('utf-8-sig')
        except UnicodeError as exc:raise ProjectError('Arquivo deve usar UTF-8') from exc
    if not isinstance(payload,str):raise ProjectError('Arquivo deve ser texto ou bytes')
    if len(payload.encode('utf-8'))>MAX_BYTES:raise ProjectError('Projeto excede 256 KiB')
    obj=_json(payload)
    if not isinstance(obj,dict) or set(obj)!={'schema','version','method','units','state'}:raise ProjectError('Envelope de projeto inválido; use exportação de entradas, não memória de resultados')
    if obj['schema']!=SCHEMA or type(obj['version']) is not int or obj['version']!=VERSION or obj['method']!='4E':raise ProjectError('Formato, versão ou método não suportado')
    if obj['units']!=UNITS:raise ProjectError('Unidades divergentes; nenhuma conversão silenciosa')
    return _validate(obj['state'])

def apply_import(target,parsed_state):
    """Atomically validate/prepare, then replace owned inputs before widgets exist.
    Derived catalogue state is rehydrated. Caller manages uploader reset/generation;
    no file digest is stored here, so identical bytes can be imported repeatedly.
    """
    out=_validate(deepcopy(parsed_state));profiles,steels,diameters=_catalogues();canonical=[]
    for prefix,iscol in (('dg39_col',True),('dg39_rec',False)):
        name=out.get(prefix+'_profile')
        if name:
            out[prefix+'_last_profile']=name
            if name!=MANUAL:
                row=profiles[name]
                for k in ('d','bf','tf','tw'):
                    key='dg39_d' if iscol and k=='d' else prefix+'_'+k
                    out[key]=float(getattr(row,k));canonical.append(key)
                if not iscol and 'dg39_receiver_area' not in out:
                    out['dg39_receiver_area']=f'{row.area:g}';canonical.append('dg39_receiver_area')
    for prefix in ('dg39_col','dg39_rec','dg39_plate'):
        name=out.get(prefix+'_material')
        if name:
            out[prefix+'_last_material']=name
            if name!=MANUAL:
                for k in ('fy','fu'):out[prefix+'_'+k]=float(getattr(steels[name],k));canonical.append(prefix+'_'+k)
    name=out.get('dg39_diameter_choice')
    if name:
        out['dg39_last_diameter']=name
        if name!=MANUAL:out['dg39_db']=float(diameters[name]);canonical.append('dg39_db')
    if out.get('dg39_consumable')=='E70XX · DG39':out['dg39_fexx']=482.6330105;canonical.append('dg39_fexx')
    reset=[k for k in ALLOWED|DERIVED if k in target]
    for key in reset:del target[key]
    target.update(out)
    return {'imported_input_count':len(parsed_state),'canonical_fields':canonical,'reset_fields':reset,'missing_input_keys':sorted(ALLOWED-set(parsed_state)),'results_imported':False,'draft_warnings':draft_warnings(out)}
