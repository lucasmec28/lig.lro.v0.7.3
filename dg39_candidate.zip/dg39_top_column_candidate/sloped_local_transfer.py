"""DG39 Eq3-47 geometry extension, spread1:1 (p217), edge truncation (p76).
Requires normal model resultants at RECEIVER CONTACT reference plane. Coordinate
origin is normal projection of weld-plane origin; not silently axis-intersection.
Legs are actual root-to-toe distances ALONG plate; NOT weld throat dimensions.
"""
from math import isfinite,cos,radians
from .sloped import resolve_interface,cut_dimensions

def transfer_clockwise_moment(normal_N,tangent_N,moment_Nmm,delta_tangent_mm,delta_normal_mm):
 vals=(normal_N,tangent_N,moment_Nmm,delta_tangent_mm,delta_normal_mm)
 if not all(isinstance(x,(int,float)) and not isinstance(x,bool) and isfinite(x) for x in vals):raise ValueError('Finite wrench/translation required')
 # right-handed global x/y, but plate basis(t,n_down) is left-handed.
 # New origin displacement delta: M_cw(new)=M_cw(old)+delta cross F.
 return moment_Nmm+delta_normal_mm*tangent_N-delta_tangent_mm*normal_N

def derive_local_points(d,tf,N,M,V,angle_degrees,tp,plate_left_extent,plate_right_extent,receiver_left_extent,receiver_right_extent,legs,*,contact_reference_confirmed=False,parallel_continuous_contact_confirmed=False):
 if contact_reference_confirmed is not True or parallel_continuous_contact_confirmed is not True:
  raise ValueError('Confirm contact-plane action reference and actual parallel continuous receiver contact')
 vals=(tp,plate_left_extent,plate_right_extent,receiver_left_extent,receiver_right_extent)
 if not all(isinstance(x,(int,float)) and not isinstance(x,bool) and isfinite(x) and x>0 for x in vals):raise ValueError('Positive finite actual dimensions required')
 r=resolve_interface(N,M,V,angle_degrees);c=cos(radians(angle_degrees));h=cut_dimensions(d,tf,angle_degrees)['flange_centers_mm'];strip=tf/c
 if not isinstance(legs,dict) or set(legs)!={'left','right'}:raise ValueError('Supply plate-side legs for both physical flanges')
 out=[]
 for label,side in (('left',-1),('right',1)):
  w=legs[label]
  if not isinstance(w,(list,tuple)) or len(w)!=2 or not all(isinstance(x,(int,float)) and not isinstance(x,bool) and isfinite(x) and x>0 for x in w):raise ValueError('Two positive actual plate-side legs required per flange')
  s=side*h/2;force=r['normal_tension_N']/2+side*M/h
  if not -receiver_left_extent<s<receiver_right_extent:raise ValueError('Application point is not inside actual receiver extent')
  if not -plate_left_extent<s<plate_right_extent:raise ValueError('Application point is not inside plate extent')
  footprint=(s-strip/2-w[0],s+strip/2+w[1]);raw=(footprint[0]-tp,footprint[1]+tp)
  effective=(max(raw[0],-plate_left_extent,-receiver_left_extent),min(raw[1],plate_right_extent,receiver_right_extent))
  if effective[1]<=effective[0]:raise ValueError('No effective bearing strip remains')
  out.append({'position_mm':s,'tension_force':max(force,0.),'compression_force':max(-force,0.),
              'distance_to_end':min(receiver_left_extent+s,receiver_right_extent-s),'bearing_length':effective[1]-effective[0],
              'weld_footprint_interval_mm':footprint,'untruncated_spread_interval_mm':raw,'effective_spread_interval_mm':effective,
              'spread_truncated':effective!=raw,'application_not_shifted_to_footprint_centroid':True,
              'construction_warning':('Weld footprint exceeds actual plate; verify constructibility' if footprint[0]<-plate_left_extent or footprint[1]>plate_right_extent else None),
              'source':'Derived DG39 Eq3-47, spread1:1 p217 and truncated examplep76; equivalent normal actions§3.5–3.6',
              'resistant_route_qualified':False})
 return out
