"""DG39 two-bolt flush A1/A2 candidate: 4 physical bolts, 2 active per sign.
Source Table5-1/5-2 and Example5.2-1 pp66–69. No complete resistance result.
"""
from dataclasses import dataclass,asdict
from math import sqrt,pi,isfinite
@dataclass(frozen=True)
class Flush2:
 d:float
 tf:float
 member_bf:float
 bp:float
 tp:float
 g:float
 pfi:float
 fy_plate:float
 db:float
 fnt_bolt:float
 symmetric_both_ends:bool=True

def evaluate_flush2_A1_A2(c:Flush2,N:float,M:float):
 if c.symmetric_both_ends is not True:raise ValueError('Symmetric 4-physical-bolt assembly required')
 if not all(isfinite(v) and v>0 for k,v in asdict(c).items() if k!='symmetric_both_ends'):
  raise ValueError('Positive finite parameters required')
 if not all(isfinite(v) for v in (N,M)):raise ValueError('Finite demands required')
 if c.d<=2*c.tf:raise ValueError('Invalid member depth')
 h=c.d-1.5*c.tf-c.pfi
 if h<=0:raise ValueError('Invalid bolt arm')
 issues=[];IN=25.4;KSI=4448.2216152605/IN**2
 for key,(lo,hi) in {'pfi':(1.3125,2.25),'g':(2.25,4.5),'d':(8,24),'bp':(5,14),'tf':(.1875,.75)}.items():
  if not lo*.9*IN<=getattr(c,key)<=hi*1.1*IN:issues.append('Table5-1:'+key)
 if c.fy_plate>50*KSI:issues.append('Section3-7-2:plate steel exceeds 50 ksi')
 if c.db>1.5*IN:issues.append('Section3-7-2:bolt exceeds 1.5 inch')
 if c.g>c.member_bf:issues.append('Eq4-1:gage exceeds member flange')
 if c.bp>c.member_bf+max(c.tp,IN):issues.append('Eq4-3:effective plate width exceeded')
 axial=max(N,0)*(c.d-c.tf)/2
 if axial>abs(M)/2:issues.append('Section3-5:large tensile axial investigation required')
 s=sqrt(c.bp*c.g)/2;p=min(c.pfi,s)
 yp=c.bp/2*h*(1/p+1/s)+2/c.g*h*(p+s)
 meq=abs(M)+axial
 db=sqrt(4*meq/(pi*.75*c.fnt_bolt*2*h))
 tp=sqrt(1.10*meq/(.80*.90*c.fy_plate*yp))
 return {'source':'DG39 §5.1.1 Eq5-3/5-4 Table5-2; gamma_r=0.80',
 'Meq_Nmm':meq,'Yp_mm':yp,'h_mm':h,'bolt_diameter_required_mm':db,
 'plate_thickness_required_mm':tp,'A1_numeric_comparison':c.db>=db,'A2_numeric_comparison':c.tp>=tp,
 'physical_bolt_count':4,'active_tension_bolt_count':2,'source_domain_issues':issues,
 'checked_domain_conditions_satisfied':not issues,'aggregate_approved':False,
 'pending':['A4 compression-side two-bolt shear','B member-to-plate welds','C receiver flange/web/panel',
 'bolt material catalog and general large axial applicability','physical bolt fit and assembly','receiver-to-terminating geometry mapping']}
