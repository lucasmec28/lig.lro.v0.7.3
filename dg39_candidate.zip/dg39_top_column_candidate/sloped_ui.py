"""UI of experimental sloped component study in a local candidate copy only."""
import json
import streamlit as st
from .sloped_form import build
from .sloped_component_route import evaluate
from .sloped_summary import rows


def render_calculation(plate,col,rec,bolt,domain,angle,actions,fields,options,extra,material_valid):
    st.info('Estudo inclinado em cópia: componentes numéricos disponíveis, sem aprovação agregada. Premissas e limites acompanham o arquivo; detalhe incompatível não é convertido em atendimento.')
    with st.expander('Referências e detalhe de solda adotados no estudo inclinado'):
        st.write('N,V,M são informados no plano da solda, no eixo da coluna. N tração para baixo; V global para a direita; M horário. Até o contato receptor: Mcontato = Msolda − tp·V∥.')
        st.write('Distâncias às extremidades são medidas da projeção normal dessa origem no contato, ao longo da viga. Não informar distâncias medidas de outra origem sem transformar.')
        st.write('Filetes de duas faces, pernas iguais em cada cordão, raiz ajustada sem folga; fora bf, dentro dois trechos bf/2−k1. Sem majoração direcional opcional. k1 é dado real do perfil, não deduzido automaticamente.')
        st.write('As premissas representam o modelo convencional adotado, não inspeção de campo. Se raiz, folga, acesso ou detalhe diferirem, esta rota não representa a fabricação.')
    if not st.button('Calcular componentes',key='dg39_calculate'):return
    if not all(str(actions[k]).strip() for k in ('N','M','V')):
        st.warning('Preencha N, M e V na seção Esforços. Campos vazios: '+', '.join(k for k in ('N','M','V') if not str(actions[k]).strip())+'. Zero deve ser informado explicitamente.')
        return
    try:
        if not material_valid:raise ValueError('Material/produto fora da faixa cadastral; não foi extrapolada resistência')
        try:advanced=json.loads(extra.strip() or '{}')
        except (ValueError,AttributeError):raise ValueError('JSON avançado opcional inválido; neste estudo use os formulários e mantenha {}')
        if advanced!={}:raise ValueError('O estudo inclinado usa os formulários com referências explícitas; JSON avançado da rota ortogonal não é reaproveitado. Salve-o antes de limpar.')
        receiver={k:rec[k] for k in ('d','bf','tf','tw','fy','fu')}
        member={k:col[k] for k in ('tw','fy','fu')}
        data,pending,warnings=build(plate,receiver,member,angle,actions,fields,options,domain,bolt['Fnv_MPa'])
        result=evaluate(data)
        result['form_pending']=pending;result['constructibility_warnings']=warnings
        st.subheader('Resultado parcial inclinado — estudo')
        st.warning('Sem aprovação agregada. Cálculo numérico, admissibilidade do método e compatibilidade de montagem são avaliações distintas.')
        for item in pending:st.warning('Campo pendente — '+item+'. Demais componentes computáveis preservados.')
        for item in warnings:st.warning('Incompatibilidade ou limite construtivo: '+item)
        if not result['geometric_admission']['satisfied']:st.warning('Geometria/material fora do subconjunto de admissão declarado. Valores teóricos mantidos; método não foi trocado para fazer o perfil atender.')
        for item in result['missing_inputs']:st.warning('Componente pendente: '+item)
        for item in result['panel_domain_pending']:st.warning('Painel: '+item)
        st.subheader('Roteiro da fonte — comparações disponíveis')
        st.table(rows(result))
        with st.expander('Premissas adotadas e referência dos esforços',expanded=False):
            st.json(data['declared_premises']);st.json(result['reference_contract'])
        detail=result['parts'].get('weld_detail',{})
        for item in detail.get('warnings',[]):st.warning('Soldas · '+item)
        for name,part in result['parts'].items():
            with st.expander('Detalhes técnicos · '+name,expanded=False):st.json(part)
        with st.expander('Limites que permanecem e roteiro da fonte'):
            st.write('DG39 §§3.5–3.7, Tabela5-10, A/B/C; DG21 garganta oblíqua. Comparador sintético integral e exemplos de componentes não constituem ensaio físico da ligação.')
            st.write('O painel usa dimensões reais do receptor no ramo convencional declarado; não foi adicionada exigência universal de G2 ou FEM.')
            for note in result['pending_qualification']:st.write(note)
        st.download_button('Baixar estudo parcial inclinado JSON',json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False),
                           'estudo_parcial_DG39_inclinado.json','application/json',key='dg39_sloped_report',on_click='ignore')
    except (ValueError,KeyError,TypeError,OverflowError) as exc:
        st.error('Entrada não processada: '+str(exc))
