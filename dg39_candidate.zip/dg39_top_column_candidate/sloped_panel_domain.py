"""DG39 conventional rolled-receiver panel branch with declared sloped axes.

DG39 §3.6 p38 admits sloped panels and uses the actual dimension in the
shear direction. §3.7.3 pp40/43 distinguishes conventional J10 yielding from
built-up gable/knee plate-buckling/tension-field branches. No universal extra
buckling or FEM check is generated merely because the assembly is inclined.
"""
REQUIRED = (
    'rolled_I_W_receiver',
    'continuous_both_sides',
    'uniform_receiver_and_coplanar_connection',
    'no_omitted_loads_between_reference_cuts',
    'single_terminating_column',
    'plate_parallel_to_receiver_flange',
    'panel_cut_normal_to_receiver_axis',
    'no_cap_doubler_or_stiffener_credit',
    'panel_deformation_not_in_global_analysis',
    'no_opposing_transverse_connection',
    'not_built_up_knee_or_gable_panel',
    'no_openings_or_discontinuities_in_panel',
)


def check(declarations):
    if not isinstance(declarations, dict):
        raise ValueError('Panel domain declarations must be an object')
    missing = [key for key in REQUIRED if declarations.get(key) is not True]
    return {
        'source': 'DG39 §3.6 p38 and §3.7.3 pp40/43, conventional J10-9/10 branch',
        'satisfied': not missing,
        'missing_or_outside': missing,
        'shear_area_basis': 'actual receiver depth normal to its longitudinal axis times actual web thickness',
        'do_not_project': 'Do not replace receiver depth by the projected terminating-member cut depth',
        'extra_plate_buckling_check_required_in_this_branch': False if not missing else None,
        'FEM_required_by_this_branch': False if not missing else None,
        'interpretation': 'Documented method-domain declaration, not proof of physical construction or project approval',
        'other_branch': 'Built-up knee/gable panels, opening/discontinuity, credited reinforcement or panel deformation in global analysis need their applicable source branch',
    }
