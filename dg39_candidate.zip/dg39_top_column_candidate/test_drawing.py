import unittest,copy,xml.etree.ElementTree as ET
try:
 from .drawing import render_svg,geometry
except ImportError:
 from drawing import render_svg,geometry

def fixture():
 return {'plate':{'d':205.,'tf':11.8,'member_bf':166.,'bp':166.,'tp':16.,'g':70.,'pfi':45.,'pfo':40.,'de':35.,'db':19.05},'member':{'tw':7.2},'receiver':{'d':207.,'bf':133.,'tf':8.4,'tw':5.8},'hole_diameter':20.6375,'labels':{'column':'W200×41,7(H)','receiver':'W200×26,6'}}
class DrawingTests(unittest.TestCase):
 def test_valid_xml_eight_holes(self):
  root=ET.fromstring(render_svg(fixture()));holes=[e for e in root.findall('{*}circle') if e.attrib.get('id','').startswith('bolt-')]
  self.assertEqual(len(holes),8);self.assertEqual(len({(e.attrib['data-x-mm'],e.attrib['data-y-mm']) for e in holes}),8)
 def test_moment_reverses_four_highlights(self):
  seen=[]
  for M in [1e7,-1e7]:
   f=fixture();f['loads']={'M':M};root=ET.fromstring(render_svg(f));active=[float(e.attrib['data-x-mm']) for e in root.findall('{*}circle') if e.attrib.get('class')=='moment-side']
   self.assertEqual(len(active),4);self.assertTrue(all(x*M>0 for x in active));seen.append(sorted(active))
  self.assertEqual(seen[0],sorted(-x for x in seen[1]))
 def test_absent_actions_no_arrows(self):
  s=render_svg(fixture());root=ET.fromstring(s)
  self.assertEqual(len([e for e in root.iter() if e.attrib.get('class')=='force']),0)
  self.assertIn('N = não informado',s);self.assertIn('M = não informado',s)
 def test_zero_actions_not_missing(self):
  f=fixture();f['loads']={'N':0,'M':0,'V':0};s=render_svg(f)
  self.assertIn('N = 0 kN',s);self.assertNotIn('N = não informado',s)
 def test_action_units_and_signs(self):
  f=fixture();f['loads']={'N':12000,'M':-2e7,'V':-5000};s=render_svg(f)
  self.assertIn('N = 12 kN',s);self.assertIn('M = -20 kN·m',s);self.assertIn('V = -5 kN',s)
  self.assertIn('data-m-sign="-1"',s)
 def test_reject_nonfinite_and_geometry(self):
  for key,value in [('d',float('nan')),('tp',0),('tf',150),('pfi',150)]:
   f=fixture();f['plate'][key]=value
   with self.assertRaises(ValueError):render_svg(f)
  f=fixture();f['loads']={'M':float('inf')}
  with self.assertRaises(ValueError):render_svg(f)
 def test_escape_labels(self):
  f=fixture();f['labels']['column']='<script>alert("x")</script>'
  s=render_svg(f);self.assertNotIn('<script>',s);ET.fromstring(s)
 def test_conflicts_are_visible_not_auto_fixed(self):
  f=fixture();f['plate']['bp']=70.;s=render_svg(f)
  self.assertIn('Furos ultrapassam a largura da chapa',s);self.assertEqual(f['plate']['bp'],70.)
 def test_hole_and_shank_are_distinct(self):
  root=ET.fromstring(render_svg(fixture()));holes=[e for e in root.findall('{*}circle') if e.attrib.get('id','').startswith('bolt-')];shanks=[e for e in root.findall('{*}circle') if e.attrib.get('data-role')=='bolt-shank']
  self.assertEqual(len(shanks),8)
  self.assertTrue(all(float(h.attrib['r'])>float(b.attrib['r']) for h,b in zip(holes,shanks)))
 def test_dimensional_change_changes_svg(self):
  f=fixture();a=render_svg(f);f['plate']['tp']=25.;b=render_svg(f)
  self.assertNotEqual(a,b);self.assertIn('Chapa tp = 25 mm',b)
if __name__=='__main__':unittest.main()
