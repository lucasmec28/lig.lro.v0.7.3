import unittest
from streamlit.testing.v1 import AppTest
from pathlib import Path
APP=str(Path(__file__).with_name('app_isolated.py'))
class UITests(unittest.TestCase):
 def test_initial_presets_domain_and_no_results(self):
  at=AppTest.from_file(APP).run();at.checkbox(key='dg39_orthogonal').set_value(True)
  self.assertFalse(at.exception);self.assertEqual(at.number_input(key='dg39_d').value,205.)
  self.assertTrue(any('Table5-9:d' in x.value for x in at.error))
  self.assertFalse(any(x.value=='Resultado parcial' for x in at.subheader))
 def test_blank_loads_block_calculation(self):
  at=AppTest.from_file(APP).run();at.checkbox(key='dg39_orthogonal').set_value(True);at.button(key='dg39_calculate').click().run()
  self.assertFalse(at.exception);self.assertTrue(any('Preencha N' in x.value for x in at.warning))
 def test_explicit_inputs_render_partial_and_keep_method(self):
  at=AppTest.from_file(APP).run();at.checkbox(key='dg39_orthogonal').set_value(True)
  at.text_input(key='dg39_N').set_value('0');at.text_input(key='dg39_M').set_value('10');at.text_input(key='dg39_V').set_value('5')
  at.button(key='dg39_calculate').click().run()
  self.assertFalse(at.exception);self.assertTrue(any(x.value=='Resultado parcial' for x in at.subheader))
  self.assertTrue(any('Table5-9:d' in x.value for x in at.error))
 def test_json_cannot_change_method(self):
  at=AppTest.from_file(APP).run();at.checkbox(key='dg39_orthogonal').set_value(True)
  for k in ('N','M','V'):at.text_input(key='dg39_'+k).set_value('0')
  at.text_area(key='dg39_extra').set_value('{"method":"flush2"}')
  at.button(key='dg39_calculate').click().run()
  self.assertFalse(at.exception);self.assertTrue(any('não suportados' in x.value for x in at.error))
 def test_repeat_and_invalid_inputs_no_stale_approval(self):
  at=AppTest.from_file(APP).run();at.checkbox(key='dg39_orthogonal').set_value(True)
  for k in ('N','M','V'):at.text_input(key='dg39_'+k).set_value('0')
  at.button(key='dg39_calculate').click().run();at.text_input(key='dg39_N').set_value('abc');at.button(key='dg39_calculate').click().run()
  self.assertFalse(at.exception);self.assertTrue(any('Entrada não processada' in x.value for x in at.error))
 def test_physical_geometry_forms_without_json(self):
  at=AppTest.from_file(APP).run();at.checkbox(key='dg39_orthogonal').set_value(True)
  for k,v in {'N':'0','M':'10','V':'5','end_left':'1000','end_right':'1000','receiver_kdes':'15','k1':'10'}.items():at.text_input(key='dg39_'+k).set_value(v)
  at.checkbox(key='dg39_auto_local').set_value(True);at.checkbox(key='dg39_auto_shear').set_value(True)
  at.button(key='dg39_calculate').click().run()
  self.assertFalse(at.exception)
  self.assertFalse(any('Entrada não processada' in x.value for x in at.error))
  self.assertTrue(any(x.label=='Detalhes técnicos · A4' for x in at.expander))
  self.assertTrue(any(x.label=='Detalhes técnicos · C_web' for x in at.expander))
 def test_panel_form_and_missing_input_recovery(self):
  at=AppTest.from_file(APP).run();at.checkbox(key='dg39_orthogonal').set_value(True)
  for k,v in {'N':'0','M':'10','V':'5','receiver_Vrc':'2','receiver_Prc':'0'}.items():at.text_input(key='dg39_'+k).set_value(v)
  at.text_input(key='dg39_receiver_area').set_value('');at.checkbox(key='dg39_auto_panel').set_value(True);at.button(key='dg39_calculate').click().run()
  self.assertTrue(any('Entrada não processada' in x.value for x in at.error))
  at.text_input(key='dg39_receiver_area').set_value('3400');at.button(key='dg39_calculate').click().run()
  self.assertFalse(at.exception)
  self.assertFalse(any('Entrada não processada' in x.value for x in at.error))
  self.assertTrue(any(x.label=='Detalhes técnicos · C_panel' for x in at.expander))
if __name__=='__main__':unittest.main(verbosity=2)
