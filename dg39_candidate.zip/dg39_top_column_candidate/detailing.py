"""DG39-referenced AISC360-22 detailing; imperial provisions converted to mm.
Source reproduction cross-checked against DG39/Companion16 examples.
Not an authenticated publisher PDF; limited standard3/4 bolt branch.
"""
from math import isfinite
IN=25.4

def fillet_limits(t1,t2,w,length,edge_thickness=None):
 if not all(isfinite(x) and x>0 for x in (t1,t2,w,length)):raise ValueError('Positive finite weld geometry required')
 t=min(t1,t2)/IN
 minimum=(1/8 if t<=1/4 else 3/16 if t<=1/2 else 1/4 if t<=3/4 else 5/16)*IN
 maximum=None
 if edge_thickness is not None:
  if not isfinite(edge_thickness) or edge_thickness<=0:raise ValueError('Actual welded-edge thickness required')
  maximum=edge_thickness if edge_thickness<IN/4 else edge_thickness-IN/16
 return {'source':'AISC360-22 TableJ2.4 and J2.2b, invoked by DG39 B',
         'unit_basis':'US customary converted to mm','minimum_mm':minimum,'maximum_mm':maximum,
         'minimum_satisfied':w>=minimum,'edge_maximum_satisfied':maximum is None or w<=maximum,
         'length_satisfied':length>=4*w,'end_loaded_no_reduction_range':length<=100*w,'edge_rule_applied':edge_thickness is not None,
         'note':'Edge maximum not imposed automatically on a T-joint; no full-throat exception credited'}

def standard_three_quarter_edges(c,hole_diameter,receiver_bf,left_end_distance,right_end_distance):
 vals=(hole_diameter,receiver_bf,left_end_distance,right_end_distance)
 if not all(isfinite(x) and x>0 for x in vals):raise ValueError('Positive finite hole and edge geometry required')
 if abs(c.db-.75*IN)>1e-6 or abs(hole_diameter-.8125*IN)>1e-6:
  return {'status':'outside_documented_detail_subset','source':'Standard3/4in bolt,13/16in hole only','detail_pass':False}
 outer=c.d/2+c.pfo
 edges={'plate_longitudinal':c.de,'plate_transverse':(c.bp-c.g)/2,
        'receiver_left':left_end_distance-outer,'receiver_right':right_end_distance-outer,
        'receiver_transverse':(receiver_bf-c.g)/2}
 pitch=min(c.g,c.pfi+c.tf+c.pfo,c.d-2*c.tf-2*c.pfi)
 return {'status':'checked_documented_subset','source':'AISC360-22 J3.4/TableJ3.4; Companion16 IID-6; DG39§4.2.2',
         'minimum_edge_mm':IN,'edges_mm':edges,'edge_checks':{k:v>=IN for k,v in edges.items()},
         'minimum_pitch_satisfied':pitch>=8*c.db/3,'clear_between_holes_satisfied':pitch-hole_diameter>=c.db,
         'detail_pass':all(v>=IN for v in edges.values()) and pitch>=8*c.db/3 and pitch-hole_diameter>=c.db,
         'pending':['actual head/washer/wrench and weld interference','bolt installation and contact detailing']}
