"""Source-derived equivalent plate/panel action model, no resistance acceptance.
DG39 §3.6 resolves actions into plate coordinates; §3.5 splits normal axial
force between two symmetric flange lines; Eq3-34 balances right panel cut.
NOT printed as this oriented equation; explicit derivation and α=0 benchmark.
Different from sloped_action_contract's THREE-force representation. Do not mix.
"""
from math import isfinite
from .sloped import resolve_interface,cut_dimensions

def equivalent_plate_and_panel(d,tf,N,M,V,angle_degrees,receiver_shear_right_local_up_N,*,axes_confirmed=False,symmetric_single_member_confirmed=False):
 if axes_confirmed is not True or symmetric_single_member_confirmed is not True:
  raise ValueError('Confirme eixos, ponto comum e membro simétrico único antes do modelo equivalente')
 q=receiver_shear_right_local_up_N
 if not isinstance(q,(int,float)) or isinstance(q,bool) or not isfinite(q):raise ValueError('Cortante local direito da viga deve ser finito')
 resolved=resolve_interface(N,M,V,angle_degrees);h=cut_dimensions(d,tf,angle_degrees)['flange_centers_mm']
 np=resolved['normal_tension_N'];vp=resolved['tangent_right_N']
 right=np/2+M/h;left=np/2-M/h
 axial_moment=max(np,0)*h/2
 return {'source':'Derivação DG39 §3.5–3.6 e Eq3-34; não fórmula impressa específica desta orientação',
 'normal_total_N':np,'tangent_total_N':vp,'moment_Nmm':M,'flange_center_arm_on_plate_mm':h,
 'equivalent_normal_right_N':right,'equivalent_normal_left_N':left,
 'signed_panel_demand_N':right-q,'receiver_shear_right_local_up_N':q,
 'receiver_shear_convention':'No corte direito, positivo na normal local para cima (-sinα,cosα); não cortante global nem V da coluna',
 'high_tensile_axial_investigation_required':axial_moment>abs(M)/2,
 'equivalent_axial_moment_Nmm':axial_moment,
 'resistance_or_domain_approved':False,
 'interpretation':'Resultantes equivalentes do modelo simplificado da chapa; não forças físicas originais das mesas ou distribuição elástica de contato',
 'pending':['domínio resistente/geométrico de cada componente','distribuição e espalhamento local conforme detalhe','capacidade painel no ramo físico aplicável e soldas']}
