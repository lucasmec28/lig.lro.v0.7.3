"""Conventional physical weld inventory/details for the isolated sloped study.
No automatic edge maximum for a T-joint, no universal long-weld penalty.
"""
from math import cos,radians,isfinite
from .detailing import fillet_limits


def inspect(c,tw,k1,flange_leg,web_leg,angle):
    values=(tw,k1,flange_leg,web_leg,angle)
    if any(isinstance(x,bool) or not isinstance(x,(int,float)) or not isfinite(x) for x in values):raise ValueError('Finite actual weld-detail dimensions required')
    if min(tw,k1,flange_leg,web_leg)<=0 or abs(angle)>=30:raise ValueError('Invalid weld-detail dimensions or outside skew subset')
    inside=c.member_bf-2*k1;outside=c.member_bf
    if inside<=0:return {'status':'conventional_flange_inventory_not_available','reason':'bf−2k1 must be positive','connection_approved':False}
    real_clear=(c.d-2*c.tf)/cos(radians(angle));lt=c.pfi+152.4;lv=min(real_clear-lt,real_clear/2)
    def limits(t,w,length,load):
        r=fillet_limits(t,c.tp,w,length)
        r['loading']=load
        r['edge_maximum_status']='not_applicable_to_declared_T_joint_without_free_welded_edge'
        # Retain source L>=4w screening; do not silently reduce usable size.
        if not r['length_satisfied']:r['short_weld_note']='Source permits an effective-size treatment; it is not implemented here. Current nominal-size capacity remains theoretical.'
        r['long_weld_reduction_automatically_applied']=False
        r['long_weld_pending']=load=='parallel_transfer_not_established' and not r['end_loaded_no_reduction_range']
        return r
    groups={'flange_outside':limits(c.tf,flange_leg,outside,'transverse_source_development'),
            'flange_inside_each_segment':limits(c.tf,flange_leg,inside/2,'transverse_source_development')}
    if lv>0:
        groups['web_normal']=limits(tw,web_leg,lt,'transverse_source_development')
        groups['web_shear']=limits(tw,web_leg,lv,'parallel_transfer_not_established')
    warnings=[]
    if k1<tw/2:warnings.append('k1 smaller than half web thickness: root/inside weld geometry inconsistent')
    if c.bp<c.member_bf:warnings.append('plate narrower than flange: full conventional transverse lengths not physically established')
    if lv<=0:warnings.append('source separated web regions do not fit; no shortened six-inch zone invented')
    if any(not q['minimum_satisfied'] for q in groups.values()):warnings.append('one or more nominal fillet legs below source minimum size')
    if any(not q['length_satisfied'] for q in groups.values()):warnings.append('nominal-size short weld needs the source effective-size treatment')
    if any(q['long_weld_pending'] for q in groups.values()):warnings.append('long parallel-loaded web weld needs actual transfer and effective-length treatment')
    return {'status':'conventional_detail_screen_only','source':'DG39§3.7.5/example p70; DG21§§3.5.2–3.5.4,3.11.3; AISC TableJ2.4/J2.2b',
        'outside_effective_length_mm':outside,'inside_effective_length_mm':inside,
        'nominal_total_per_flange_mm':outside+inside,
        'inside_segment_count':2,'inside_each_segment_mm':inside/2,
        'nominal_lengths_are_physically_available':c.bp>=c.member_bf and k1>=tw/2,
        'web_normal_length_mm':lt,'web_shear_length_mm':lv,
        'groups':groups,'warnings':warnings,'detail_screen_satisfied':not warnings,
        'assumptions':['equal legs within each individual weld','fitted root without gap','accessible conventional outside/inside welds','T joints without credited penetration/convexity'],
        'manual_items':['actual WPS and process','actual root, profile concavity and effective throat','tool/weld access and intersections','cut edges/returns and any free-edge joint condition'],
        'connection_approved':False,'resistant_route_qualified':False}
