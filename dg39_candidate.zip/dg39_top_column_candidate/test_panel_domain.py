import unittest
from .panel_domain import *
class PanelDomainTests(unittest.TestCase):
 def test_all_source_branch_declarations(self):
  r=check_panel_domain(dict.fromkeys(REQUIRED,True));self.assertTrue(r['satisfied']);self.assertFalse(r['FEM_required_by_this_branch'])
 def test_no_implied_geometry(self):
  r=check_panel_domain({});self.assertFalse(r['satisfied']);self.assertEqual(len(r['missing_or_outside']),7)
 def test_different_analysis_branch_not_accepted(self):
  d=dict.fromkeys(REQUIRED,True);d['panel_deformation_not_in_global_analysis']=False
  self.assertFalse(check_panel_domain(d)['satisfied'])
