"""Readable stage summary of already-computed checks; creates no new checks."""

def rows(result):
    p=result['parts'];out=[]
    def add(stage,value,note=''):
        label='Não calculado' if value is None else 'Atende numericamente' if value else 'Não atende numericamente'
        out.append({'Etapa':stage,'Comparação':label,'Observação':note})
    a=p['plate_and_receiver_flange']['parts'];base=a['A1_A2']
    scope='Valores teóricos fora do subconjunto declarado' if not result['geometric_admission']['satisfied'] else 'Dentro do subconjunto geométrico declarado; sem aprovação global'
    add('A1 · Tração dos parafusos',base['A1_numeric_diameter_comparison'],scope)
    add('A2 · Espessura da chapa',base['A2_numeric_thickness_comparison'],scope)
    add('A3 · Cortante da extensão',a.get('A3',{}).get('A3_numeric_comparison'),scope)
    a4=a.get('A4',{})
    if a4.get('status')=='not_applicable_zero_resolved_shear':out.append({'Etapa':'A4 · Cortante nos parafusos','Comparação':'Não aplicável: V∥=0','Observação':'Somente nesta combinação'})
    else:add('A4 · Cortante nos parafusos',a4.get('A4_numeric_comparison'),'Folgas direcionais atuais; grupo da fonte')
    flange=p.get('flange_welds',{}).get('parts',{})
    add('B1 · Soldas das mesas',all(q['normal_numeric_comparison'] and q['axial_minimum_numeric_comparison'] for q in flange.values()) if flange else None,'Demanda e piso de desenvolvimento separados; conferir detalhe')
    web=p.get('web_welds',{}).get('parts',{})
    add('B3 · Escoamento local da alma',web.get('B3_web_normal_yield',{}).get('numeric_comparison'),'Zona da fonte; não reduzida para caber')
    for stage,keys in [('B4 · Solda da zona normal',('B4_web_weld_normal','B4_physical_axial_development')),('B5 · Cortante da alma/solda',('B5_web_weld_shear','B5_web_base_shear_rupture'))]:
        add(stage,all(web[k]['numeric_comparison'] for k in keys) if all(k in web for k in keys) else None,'Comparação por componentes da fonte')
    add('C · Flexão da mesa receptora',a.get('C_flange',{}).get('numeric_comparison'),scope)
    local=p.get('receiver_web',[])
    add('C · Efeitos locais na alma receptora',all(q[k] for q in local for k in ('tension_yield_numeric','compression_yield_numeric','compression_crippling_numeric')) if local else None,'Duas posições e forças assinadas; comprimentos reais declarados')
    panel=p.get('panel',{})
    add('C · Painel',panel.get('numeric_comparison'),'Domínio convencional declarado' if panel.get('domain',{}).get('satisfied') else 'Domínio/entradas pendentes; comparação não qualifica aplicação')
    detail=p.get('weld_detail',{})
    add('Detalhamento · Soldas',detail.get('detail_screen_satisfied'),'Subconjunto de tamanhos/comprimentos; fabricação e WPS não inspecionados')
    return out
