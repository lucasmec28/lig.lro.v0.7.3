"""Three-view SVG for the direct one-plate DG39 4E topology; no resistance claims.
Input matches evaluate_route: plate/member/receiver, loads in N,Nmm and labels.
Absent actions stay absent. Orange means moment-side only, not calculated bolt force.
"""
from html import escape
from math import isfinite,cos,sin,radians

def _number(value, name, positive=False):
    if isinstance(value,bool) or not isinstance(value,(int,float)) or not isfinite(value):
        raise ValueError(name+': informe número finito')
    if positive and value<=0:raise ValueError(name+': dimensão deve ser positiva')
    return float(value)

def geometry(data):
    p=data['plate'];r=data['receiver'];m=data.get('member',{})
    keys=('d','tf','member_bf','bp','tp','g','pfi','pfo','de','db')
    v={k:_number(p[k],k,True) for k in keys}
    rr={k:_number(r[k],'receiver.'+k,True) for k in ('d','bf','tf','tw')}
    tw=_number(m.get('tw',p.get('tw')),'member.tw',True)
    if v['d']<=2*v['tf'] or v['member_bf']<=tw or rr['d']<=2*rr['tf'] or rr['bf']<=rr['tw']:
        raise ValueError('Geometria I inconsistente')
    outer=v['d']/2+v['pfo'];inner=v['d']/2-v['tf']-v['pfi']
    if inner<=0:raise ValueError('Fileiras internas não cabem entre as mesas')
    rows=(-outer,-inner,inner,outer)
    hole=_number(data.get('hole_diameter',v['db']),'hole_diameter',True)
    if hole<v['db']:raise ValueError('Furo menor que parafuso')
    warnings=[]
    if min(rows[i+1]-rows[i] for i in range(3))<=hole:warnings.append('Furos sobrepostos no arranjo informado.')
    if v['g']+hole>v['bp']:warnings.append('Furos ultrapassam a largura da chapa.')
    if v['g']+hole>rr['bf']:warnings.append('Furos ultrapassam a mesa receptora.')
    if v['de']<hole/2:warnings.append('Furos ultrapassam a extremidade da chapa.')
    loads={k:None if data.get('loads',{}).get(k) is None else _number(data['loads'][k],k) for k in ('N','M','V')}
    return v,rr,tw,rows,hole,loads,warnings

def render_svg(data):
    """Return a self-contained safe SVG string; dimensions mm, actions kN/kN.m."""
    p,r,tw,rows,hole,loads,warnings=geometry(data)
    fmt=lambda x:f'{x:.2f}'.rstrip('0').rstrip('.').replace('.',',')
    labels=data.get('labels',{}); label=lambda k:str(labels.get(k,k))
    svg=['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1100 790" role="img" aria-label="Ligação de coluna sob viga contínua com uma chapa e oito parafusos">',
    '<defs><marker id="arrow" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto-start-reverse"><path d="M0,0 L8,4 L0,8Z" fill="#7c3aed"/></marker><marker id="dim" markerWidth="6" markerHeight="6" refX="3" refY="3" orient="auto-start-reverse"><path d="M6,0 L0,3 L6,6" fill="none" stroke="#64748b"/></marker></defs>',
    '<style>text{font-family:Arial,sans-serif;fill:#172554;font-size:13px}.title{font-size:19px;font-weight:bold}.small{font-size:11px}.steel{fill:#cbd5e1;stroke:#334155;stroke-width:1.4}.plate{fill:#93c5fd;stroke:#1d4ed8;stroke-width:1.5}.axis{stroke:#94a3b8;stroke-dasharray:5 4;stroke-width:1}.force{stroke:#7c3aed;stroke-width:2.5;fill:none;marker-end:url(#arrow)}.dimension{stroke:#64748b;stroke-width:1;marker-start:url(#dim);marker-end:url(#dim)}.moment-side{fill:#fed7aa;stroke:#c2410c;stroke-width:2}.neutral{fill:#fff;stroke:#1d4ed8;stroke-width:1.5}</style>',
    '<rect width="1100" height="790" rx="12" fill="#f8fafc"/>']
    def text(x,y,t,cls='',anchor=None):svg.append(f'<text x="{x:.2f}" y="{y:.2f}" class="{cls}"'+(f' text-anchor="{anchor}"' if anchor else '')+'>'+escape(str(t))+'</text>')
    def rect(x,y,w,h,cls='steel',extra=''):svg.append(f'<rect x="{x:.3f}" y="{y:.3f}" width="{max(w,.01):.3f}" height="{max(h,.01):.3f}" class="{cls}" {extra}/>')
    def line(x1,y1,x2,y2,cls='axis'):svg.append(f'<line x1="{x1:.3f}" y1="{y1:.3f}" x2="{x2:.3f}" y2="{y2:.3f}" class="{cls}"/>')
    def dim(x1,y1,x2,y2,txt,tx=None,ty=None):
        line(x1,y1,x2,y2,'dimension');text((x1+x2)/2 if tx is None else tx,(y1+y2)/2-6 if ty is None else ty,txt,'small','middle')
    text(24,31,'UMA CHAPA • COLUNA SOB VIGA CONTÍNUA • DG39 4E','title')
    text(24,52,'Geometria dinâmica de referência. Não é desenho de fabricação nem certificado de resistência.','small')
    # Front: horizontal receiver axis x, vertical column below, global positive x right.
    text(24,82,'1 · Elevação longitudinal (+d para a direita)','title')
    L=p['d']+2*(p['pfo']+p['de']);s=min(410/(L+80),190/(r['d']+p['tp']))
    cx=255;top=105;bottom=top+r['d']*s;pl_y=bottom
    rect(40,top,430,r['tf']*s);rect(40,top+r['tf']*s,430,(r['d']-2*r['tf'])*s,extra='fill-opacity="0.25"')
    rect(40,bottom-r['tf']*s,430,r['tf']*s)
    rect(cx-L*s/2,pl_y,L*s,p['tp']*s,'plate')
    cy=pl_y+p['tp']*s;colheight=85
    rect(cx-p['d']*s/2,cy,p['tf']*s,colheight);rect(cx+p['d']*s/2-p['tf']*s,cy,p['tf']*s,colheight)
    rect(cx-p['d']*s/2+p['tf']*s,cy,(p['d']-2*p['tf'])*s,colheight,extra='fill-opacity="0.18"')
    for x in rows:
        rect(cx+x*s-p['db']*s/2,bottom-r['tf']*s-4,p['db']*s,(p['tp']+r['tf'])*s+12,'plate')
    dim(cx-p['d']*s/2,cy+colheight+16,cx+p['d']*s/2,cy+colheight+16,'d = '+fmt(p['d'])+' mm')
    text(45,top+18,label('receiver').replace('&amp;','&'),'small')
    text(cx,cy+colheight-10,label('column').replace('&amp;','&'),'small','middle')
    # Actions are symbolic; arrow lengths deliberately do not scale with load.
    fy=cy+35
    if loads['N'] is not None and loads['N']!=0:
        start,end=(fy,fy+35) if loads['N']>0 else (fy+35,fy)
        line(cx,start,cx,end,'force')
    if loads['V'] is not None and loads['V']!=0:line(cx,fy,cx+(45 if loads['V']>0 else -45),fy,'force')
    if loads['M'] is not None and loads['M']!=0:
        sweep=1 if loads['M']>0 else 0
        a=(cx+56+27*cos(radians(-140)),fy+27*sin(radians(-140)))
        b=(cx+56+27*cos(radians(140)),fy+27*sin(radians(140)))
        if not sweep:a,b=b,a
        svg.append(f'<path d="M {a[0]:.3f} {a[1]:.3f} A 27 27 0 1 {sweep} {b[0]:.3f} {b[1]:.3f}" class="force" data-m-sign="{1 if loads["M"]>0 else -1}"/>')
    # Side cross-section, receiver I above single plate, terminating column projected.
    text(570,82,'2 · Seção transversal à viga','title')
    sy=min(380/max(r['bf'],p['bp'],p['member_bf']),190/(r['d']+p['tp']));sx=815;yt=105;yb=yt+r['d']*sy
    rect(sx-r['bf']*sy/2,yt,r['bf']*sy,r['tf']*sy);rect(sx-r['tw']*sy/2,yt+r['tf']*sy,r['tw']*sy,(r['d']-2*r['tf'])*sy)
    rect(sx-r['bf']*sy/2,yb-r['tf']*sy,r['bf']*sy,r['tf']*sy)
    rect(sx-p['bp']*sy/2,yb,p['bp']*sy,p['tp']*sy,'plate')
    rect(sx-p['member_bf']*sy/2,yb+p['tp']*sy,p['member_bf']*sy,85,extra='fill-opacity="0.25"')
    for y in (-p['g']/2,p['g']/2):rect(sx+y*sy-p['db']*sy/2,yb-r['tf']*sy-4,p['db']*sy,(r['tf']+p['tp'])*sy+12,'plate')
    dim(sx-p['bp']*sy/2,yb+p['tp']*sy+105,sx+p['bp']*sy/2,yb+p['tp']*sy+105,'bp = '+fmt(p['bp'])+' mm')
    text(570,412,'Chapa tp = '+fmt(p['tp'])+' mm · mesa receptora tf = '+fmt(r['tf'])+' mm','small')
    # Plan at the connection interface: receiver footprint, column footprint, eight holes.
    text(24,445,'3 · Planta da chapa / posição dos oito furos','title')
    ps=min(600/(L+80),210/max(p['bp'],p['member_bf'],r['bf']));px=365;py=590
    rect(45,py-r['bf']*ps/2,640,r['bf']*ps,'steel','fill-opacity="0.14" stroke-dasharray="6 4"')
    rect(px-L*ps/2,py-p['bp']*ps/2,L*ps,p['bp']*ps,'plate','fill-opacity="0.35"')
    rect(px-p['d']*ps/2,py-p['member_bf']*ps/2,p['tf']*ps,p['member_bf']*ps,'steel','fill-opacity="0.5"')
    rect(px+(p['d']/2-p['tf'])*ps,py-p['member_bf']*ps/2,p['tf']*ps,p['member_bf']*ps,'steel','fill-opacity="0.5"')
    rect(px+(-p['d']/2+p['tf'])*ps,py-tw*ps/2,(p['d']-2*p['tf'])*ps,tw*ps,'steel','fill-opacity="0.5"')
    line(35,py,690,py);line(px,465,px,715)
    for i,x in enumerate(rows):
        for j,y in enumerate((-p['g']/2,p['g']/2)):
            tension=loads['M'] is not None and loads['M']!=0 and x*loads['M']>0
            cls='moment-side' if tension else 'neutral'
            svg.append(f'<circle id="bolt-{2*i+j+1}" data-x-mm="{x}" data-y-mm="{y}" cx="{px+x*ps:.3f}" cy="{py-y*ps:.3f}" r="{max(hole*ps/2,2):.3f}" class="{cls}"><title>Furo {2*i+j+1}: x={fmt(x)}; y={fmt(y)} mm</title></circle>')
            svg.append(f'<circle cx="{px+x*ps:.3f}" cy="{py-y*ps:.3f}" r="{max(p["db"]*ps/2,1):.3f}" fill="#64748b" fill-opacity="0.28" stroke="#475569" stroke-width="0.7" data-role="bolt-shank"/>')
    dim(px+L*ps/2+18,py-p['g']*ps/2,px+L*ps/2+18,py+p['g']*ps/2,'g '+fmt(p['g']),tx=px+L*ps/2+42)
    # Inline geometry table remains legible for very short clearances.
    text(720,478,'GEOMETRIA E AÇÕES','title')
    fields=[('Chapa L × bp',fmt(L)+' × '+fmt(p['bp'])+' mm'),('pfi / pfo / de',f"{fmt(p['pfi'])} / {fmt(p['pfo'])} / {fmt(p['de'])} mm"),('Mesa coluna tf',fmt(p['tf'])+' mm'),('Parafuso / furo',fmt(p['db'])+' / '+fmt(hole)+' mm')]
    for i,(name,value) in enumerate(fields):text(720,504+21*i,name+': '+value,'small')
    for i,(key,unit,div) in enumerate((('N','kN',1000),('V','kN',1000),('M','kN·m',1e6))):
        value='não informado' if loads[key] is None else fmt(loads[key]/div)+' '+unit
        text(720,600+22*i,key+' = '+value)
    text(720,678,'Laranja: lado tracionado pelo momento.','small')
    text(720,695,'Cinza: haste db; contorno: furo dh.','small')
    text(720,712,'Cor não é força calculada por parafuso.','small')
    text(24,737,'Convenção: N+ tração (↓ na coluna); V+ direita; M+ horário. Sem ações informadas, não são desenhadas setas.','small')
    text(24,756,'Vistas têm escalas independentes; comprimento livre dos membros é esquemático. Cotas informadas prevalecem.','small')
    if warnings:text(24,777,'ATENÇÃO: '+' '.join(warnings),'small')
    svg.append('</svg>');return ''.join(svg)
