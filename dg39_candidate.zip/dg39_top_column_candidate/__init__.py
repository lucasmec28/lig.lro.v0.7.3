"""Isolated DG39 top-column candidate; no production approval."""
