import unittest
from dataclasses import replace
from .flush2 import *
IN=25.4;KIP=4448.2216152605;KSI=KIP/IN**2
C=Flush2(17.7*IN,.425*IN,6*IN,7*IN,.5625*IN,3.5*IN,1.5*IN,50*KSI,.75*IN,90*KSI)
class FlushTests(unittest.TestCase):
 def test_example_521(self):
  r=evaluate_flush2_A1_A2(C,3.3*KIP,800*KIP*IN)
  self.assertAlmostEqual(r['Meq_Nmm']/(KIP*IN),829,delta=1)
  self.assertAlmostEqual(r['Yp_mm']/IN,93.9,delta=.3)
  self.assertAlmostEqual(r['bolt_diameter_required_mm']/IN,.708,delta=.001)
  self.assertAlmostEqual(r['plate_thickness_required_mm']/IN,.519,delta=.001)
  self.assertFalse(r['source_domain_issues']);self.assertFalse(r['aggregate_approved'])
 def test_depth_205_not_rejected_by_flush_range_only(self):
  r=evaluate_flush2_A1_A2(replace(C,d=205,tf=11.8,member_bf=166,bp=166,g=70,pfi=35),0,0)
  self.assertNotIn('Table5-1:d',r['source_domain_issues'])
  self.assertFalse(r['aggregate_approved'])
 def test_no_extended_gamma(self):
  r=evaluate_flush2_A1_A2(C,3.3*KIP,800*KIP*IN)
  tp_wrong=(1.1*r['Meq_Nmm']/(.9*C.fy_plate*r['Yp_mm']))**.5
  self.assertAlmostEqual(r['plate_thickness_required_mm']/tp_wrong,(1/.8)**.5)
 def test_four_physical(self):
  r=evaluate_flush2_A1_A2(C,0,1e6)
  self.assertEqual((r['physical_bolt_count'],r['active_tension_bolt_count']),(4,2))
if __name__=='__main__':unittest.main(verbosity=2)
