"""Independent synthetic full component case, NOT a published complete example.
A/B dimensions reuse DG39 Ex5.3-1; receiver is synthetic (not catalogue).
Rolled-receiver flags and area from idealized radius10mm are verification inputs, not product evidence.
"""
import unittest,math,copy
from dataclasses import asdict
from .test_core import C,IN,KIP,KSI
from .direct4e_route import evaluate_route
from .panel_domain import REQUIRED

def synthetic_case():
 return {'method':'4E','geometry':{'plate_perpendicular_to_column':True,'plate_parallel_to_receiver_flange':True},
 'plate':asdict(C),'loads':{'N':11*KIP,'M':2510*KIP*IN,'V':-33.8*KIP},'plate_fu':65*KSI,'hole_diameter':.8125*IN,'bolt_grade':'A325 (Group 120)',
 'receiver':{'d':700,'bf':300,'tf':30,'tw':16,'kdes':40,'E':200000,'area':2*300*30+(700-60)*16+4*(1-math.pi/4)*10**2,'fy':50*KSI,'fu':65*KSI},
 'member':{'tw':.25*IN,'k1':.125*IN,'fy':50*KSI,'fu':65*KSI},
 'welds':{'flange_leg':.25*IN,'web_leg':.1875*IN,'Fexx':70*KSI},
 'shear_geometry':{'left_end_distance':3000,'right_end_distance':3000,'axes_confirmed':True},
 'local_geometry':{'left_end_distance':3000,'right_end_distance':3000},
 'panel':{'receiver_shear_right_up_N':30000,'receiver_axial_compression':0,'axes_confirmed':True,'domain':{k:True for k in REQUIRED}}}

class SyntheticIntegralReview(unittest.TestCase):
 def setUp(self):self.data=synthetic_case();self.result=evaluate_route(self.data);self.p=self.result['parts']
 def test_A_published_component_and_independent_arithmetic(self):
  a=self.p['A1_A2'];self.assertAlmostEqual(a['bolt_diameter_required_mm']/IN,.7202186761360305)
  self.assertAlmostEqual(a['plate_thickness_required_mm']/IN,.589330188919464)
  ft=(2510/23.625+11/2)*KIP
  self.assertAlmostEqual(self.p['A3']['demand_N'],ft/2)
  self.assertAlmostEqual(self.p['A3']['shear_yield_LRFD_N'],150*KIP)
  self.assertAlmostEqual(self.p['A3']['shear_rupture_LRFD_N'],.75*.6*65*(8-2*(.8125+.0625))*.625*KIP)
  self.assertAlmostEqual(self.p['A4']['equal_distribution_group_strength_N'],4*.75*54*math.pi*.75**2/4*KIP)
 def test_B_independent_force_and_resistance_calculations(self):
  b=self.p['B'];ft=(2510/23.625+5.5)*KIP;lw=7.75;lv=11.625
  self.assertAlmostEqual(b['flange_demand_N'],ft)
  self.assertAlmostEqual(b['flange_weld_LRFD_N'],.75*.6*70*.25/math.sqrt(2)*(16-.25)*1.5*KIP)
  self.assertAlmostEqual(b['web_tension_demand_N'],ft/2)
  self.assertAlmostEqual(b['web_tension_yield_LRFD_N'],.9*50*.25*lw*KIP)
  self.assertAlmostEqual(b['web_tension_weld_demand_N'],.6*50*.25*lw*KIP)
  self.assertAlmostEqual(b['web_tension_weld_LRFD_N'],.75*2*.6*70*.1875/math.sqrt(2)*lw*1.5*KIP)
  self.assertAlmostEqual(b['web_shear_weld_LRFD_N'],.75*2*.6*70*.1875/math.sqrt(2)*lv*KIP)
  self.assertAlmostEqual(b['web_base_shear_LRFD_N'],.75*.6*65*.25*lv*KIP)
 def test_C_independent_receiver_arithmetic(self):
  # Continuous receiver Eq3-44, width limited to 8+1=9in (228.6mm).
  bf=9*IN;g=3*IN;s=math.sqrt(bf*g)/2;h1=26.3125*IN;h2=21.6875*IN;c=4.625*IN
  yc=bf/2*(h1+h2)/s+2/g*(h2*(.75*c+s)+h1*(.25*c+s)+c*c/2)+g/2
  self.assertAlmostEqual(self.p['C_flange']['resistance_Nmm'],.9*50*KSI*30**2*yc,delta=1e-5)
  lb=(.375+2*.25+2*.625)*IN
  ry=(6*40+lb)*50*KSI*16
  rc=.75*.8*16**2*(1+3*lb/700*(16/30)**1.5)*math.sqrt(200000*50*KSI*30/16)
  for i,q in enumerate(self.p['C_web']):
   self.assertAlmostEqual(q['yielding_resistance_N'],ry)
   self.assertAlmostEqual(q['crippling_resistance_N'],rc)
   self.assertAlmostEqual(q['application_inputs']['distance_to_end'],3000-23.625*IN/2)
  panel=self.p['C_panel']
  self.assertAlmostEqual(panel['signed_demand_N'],(2510/23.625+5.5)*KIP-30000)
  self.assertAlmostEqual(panel['design_capacity_N'],.9*.6*50*KSI*700*16)
  self.assertTrue(panel['domain']['satisfied'])
 def test_reductions_create_failures_without_method_switch(self):
  d=copy.deepcopy(self.data);d['plate']['tp']=10
  self.assertFalse(evaluate_route(d)['parts']['A1_A2']['A2_numeric_thickness_comparison'])
  d=copy.deepcopy(self.data);d['receiver']['tf']=5
  self.assertFalse(evaluate_route(d)['parts']['C_flange']['numeric_comparison'])
  d=copy.deepcopy(self.data);d['receiver']['tw']=1
  self.assertFalse(evaluate_route(d)['parts']['C_panel']['numeric_comparison'])
  d=copy.deepcopy(self.data);d['welds']['web_leg']=1
  b=evaluate_route(d)['parts']['B'];self.assertGreater(b['web_shear_demand_N'],b['web_shear_weld_LRFD_N'])
 def test_component_case_not_commercial_or_published_validation(self):
  self.assertFalse(self.result['aggregate_approved'])
  self.assertEqual(self.result['missing_inputs'],[])
  self.assertTrue(self.p['bolt_details']['detail_pass'])
  for q in self.p['B_details'].values():self.assertTrue(q['minimum_satisfied']);self.assertTrue(q['length_satisfied'])
