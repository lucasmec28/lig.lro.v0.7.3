import unittest,math
from dataclasses import replace
from .test_flush2 import C,IN,KIP,KSI
from .flush_components import *
class ComponentTests(unittest.TestCase):
 def test_flush_two_shear_example521(self):
  r=shear_two_compression_bolts(C,3.3*KIP,800*KIP*IN,25.8*KIP,54*KSI,65*KSI,65*KSI,.520*IN,(2*IN,)*2,(2*IN,)*2)
  self.assertAlmostEqual(r['equal_share_group_strength_N']/KIP,35.9,delta=.2)
 def test_flush_shear_refuses_four(self):
  with self.assertRaises(ValueError):shear_two_compression_bolts(C,0,1e6,100,300,450,450,10,(100,)*4,(100,)*4)
 def test_panel_example521_capacity(self):
  r=panel_yield_capacity(12.5*IN,.300*IN,50*KSI,10*IN**2,0)
  self.assertAlmostEqual(r['design_capacity_N']/KIP,101.25,delta=.01)
 def test_panel_axial_reduction(self):
  r=panel_yield_capacity(300,8,345,6000,.8*345*6000)
  self.assertAlmostEqual(r['axial_reduction_factor'],.6)
 def test_source_weld_example521(self):
  r=standard_fillet_welds_flush2(C,.300*IN,.75*IN,50*KSI,65*KSI,70*KSI,.25*IN,.1875*IN,3.3*KIP,800*KIP*IN,25.8*KIP)
  for key,target in [('flange_demand_N',76.5),('flange_weld_LRFD_N',87.8),('web_tension_demand_N',48.0),('web_tension_yield_LRFD_N',102),('web_tension_weld_demand_N',67.8),('web_tension_weld_LRFD_N',93.8),('web_shear_weld_LRFD_N',70.4),('web_base_shear_LRFD_N',74.0)]:
   self.assertAlmostEqual(r[key]/KIP,target,delta=.8,msg=key)
 def test_small_depth_partition_stops(self):
  r=standard_fillet_welds_flush2(replace(C,d=205,tf=11.8,pfi=35,member_bf=166),7.2,15,345,450,490,5,5,0,0,1)
  self.assertEqual(r['status'],'standard_weld_partition_not_applicable')
  self.assertAlmostEqual(r['web_clear_mm'],181.4);self.assertAlmostEqual(r['tension_zone_requested_mm'],187.4)
 def test_continuous_flange_closed_form(self):
  r=receiver_flange_continuous(C,200,20,345,0,1e6)
  h=C.d-1.5*C.tf-C.pfi
  self.assertAlmostEqual(r['Yc_mm'],4*h*math.sqrt(min(200,C.member_bf+max(25.4,C.tp))/C.g))
 def test_flange_thickness_squared(self):
  a=receiver_flange_continuous(C,200,10,345,0,1e6);b=receiver_flange_continuous(C,200,20,345,0,1e6)
  self.assertAlmostEqual(b['resistance_Nmm']/a['resistance_Nmm'],4)
 def test_web_source_example521(self):
  r=receiver_web_local(12.5*IN,.300*IN,.520*IN,.820*IN,50*KSI,29000*KSI,1.7375*IN,30*IN,0,46.3*KIP)
  self.assertAlmostEqual(r['yielding_resistance_N']/KIP,99.9,delta=.2)
  self.assertAlmostEqual(r['crippling_resistance_N']/KIP,.75*135,delta=.5)
 def test_end_has_smaller_yield_capacity(self):
  args=(300,8,15,25,345,200000,50)
  a=receiver_web_local(*args,0,1,1);b=receiver_web_local(*args,1000,1,1)
  self.assertLess(a['yielding_resistance_N'],b['yielding_resistance_N'])
if __name__=='__main__':unittest.main(verbosity=2)
