from dg39_top_column_candidate.ui import render
render()
