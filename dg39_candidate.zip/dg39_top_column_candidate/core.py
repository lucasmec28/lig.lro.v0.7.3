"""DG39 4E LRFD A1/A2 benchmark core, isolated, NOT complete connection design.
Units N, mm, MPa. Physical member roles explicit. No NBR resistance coefficients.
Resistance output is only for the selected substeps; aggregate_approved always false.
"""
from dataclasses import dataclass,asdict
from math import sqrt,pi,isfinite

@dataclass(frozen=True)
class Plate4E:
 d:float
 tf:float
 member_bf:float
 bp:float
 tp:float
 g:float
 pfi:float
 pfo:float
 de:float
 fy_plate:float
 db:float
 fnt_bolt:float
 symmetric_both_ends:bool=True

def evaluate_A1_A2(c:Plate4E,N:float,M:float,V:float=0.):
 if c.symmetric_both_ends is not True:raise ValueError('This candidate requires symmetric groups at both ends: 8 physical bolts, 4 active in tension per moment sign')
 vals=[v for k,v in asdict(c).items() if k!='symmetric_both_ends']
 if not all(isfinite(x) and x>0 for x in vals):raise ValueError('Positive finite geometry and properties required')
 if not all(isfinite(x) for x in (N,M,V)):raise ValueError('Finite actions required')
 if c.d<=2*c.tf:raise ValueError('Invalid section depth')
 issues=[]
 # DG39 §3.7.2 limits independent of dimensional test-range tolerance.
 ksi=4448.2216152605/25.4**2
 if c.fy_plate>50*ksi:issues.append('Section3-7-2:plate steel exceeds 50 ksi')
 if c.db>1.5*25.4:issues.append('Section3-7-2:bolt exceeds 1.5 inch')
 # Source dimensions Table5-9, with its stated +/-10% tolerance. pf is checked both sides.
 ranges={'pfi':(1,2.5),'pfo':(1,2.5),'g':(2.75,7),'d':(15.75,72),'bp':(5,10.25),'tf':(.375,1)}
 for name,(lo,hi) in ranges.items():
  if not lo*.9*25.4<=getattr(c,name)<=hi*1.1*25.4:issues.append('Table5-9:'+name)
 # pext = distance from flange outer face to plate end = pfo+de
 if not 2.5*.9*25.4<=c.pfo+c.de<=7.5*1.1*25.4:issues.append('Table5-9:pext')
 if c.g>c.member_bf:issues.append('Eq4-1:gage exceeds member flange')
 for pitch in (c.g,c.pfi+c.tf+c.pfo,c.d-2*c.tf-2*c.pfi):
  if pitch<(8/3)*c.db:issues.append('Section4-2-2:bolt center spacing below 2 2/3 db')
 if c.bp>c.member_bf+max(c.tp,25.4):issues.append('Eq4-3:effective width exceeded')
 z=c.d-c.tf;added=max(N,0)*z/2
 if added>abs(M)/2:issues.append('Section3-5:large tensile axial investigation required')
 h1=c.d-c.tf/2+c.pfo;h2=c.d-1.5*c.tf-c.pfi
 if h2<=0:raise ValueError('Invalid inner bolt arm')
 s=sqrt(c.bp*c.g)/2;pi_eff=min(c.pfi,s)
 yp=c.bp/2*(h1/c.pfo+h2*(1/pi_eff+1/s)-.5)+2/c.g*h2*(s+pi_eff)
 meq=abs(M)+added
 db_req=sqrt(4*meq/(pi*.75*c.fnt_bolt*2*(h1+h2)))
 tp_req=sqrt(1.10*meq/(.90*c.fy_plate*yp))
 return {'source':'DG39 2023 §3.5; §5.1.1 Eqs5-3/5-4; Table5-10',
         'method':'LRFD thick 4E, gamma_r=1', 'Meq_Nmm':meq,'Yp_mm':yp,'h1_mm':h1,'h2_mm':h2,
         'bolt_diameter_required_mm':db_req,'plate_thickness_required_mm':tp_req,
         'A1_numeric_diameter_comparison':c.db>=db_req,'A2_numeric_thickness_comparison':c.tp>=tp_req,
         'A1_A2_checked_domain_conditions_satisfied':not issues,'physical_bolt_count':8,'active_tension_bolt_count':4,
         'tension_flange_demand_N':abs(M)/z+max(N,0)/2,
         'compression_flange_demand_N':abs(M)/z+max(-N,0)/2,
         'source_domain_issues':issues,'aggregate_approved':False,
         'pending':['A3 extension shear','A4 shear transfer and tension-shear interaction',
                    'B member-to-plate welds','C receiver flange/web/panel/stiffeners',
                    'actual assembly and bolt detailing','bolt grade and Fnt catalog qualification','large axial applicability in either sign','horizontal receiver geometry mapping'],
         'V_input_N':V,'V_checked':False,
         'axial_scope_note':'Large axial force may be outside guide applicability (§3.7.2); compression is not cleared by the tensile screen.'}

@dataclass(frozen=True)
class DirectTopColumnDetail:
 column_member:Plate4E
 receiver_is_continuous:bool
 plate_perpendicular_to_column:bool
 plate_parallel_to_receiver_flange:bool
 one_plate_direct_to_flange:bool
 source_role_column_is_terminating_member:bool=True

def evaluate_direct_partial(detail:DirectTopColumnDetail,N_column:float,M_column:float,V_column:float):
 if not all((detail.receiver_is_continuous,detail.plate_perpendicular_to_column,
             detail.plate_parallel_to_receiver_flange,detail.one_plate_direct_to_flange,
             detail.source_role_column_is_terminating_member)):
  raise ValueError('This first isolated adapter only accepts direct orthogonal one-plate geometry')
 r=evaluate_A1_A2(detail.column_member,N_column,M_column,V_column)
 r['physical_roles']={'terminating_member':'actual column','receiver':'actual continuous beam'}
 return r


def extension_shear_A3(c:Plate4E,N:float,M:float,fu_plate:float,hole_diameter:float):
 """DG39 Example5.3-1 p126 / §5.1.3 A3; 4E unstiffened only.
 AISC net-hole allowance 1/16 inch is applied explicitly, not a NBR deduction.
 Demand ignores beneficial compression. No receiver or bolt shear claim.
 """
 base=evaluate_A1_A2(c,N,M)
 if not isfinite(fu_plate) or fu_plate<c.fy_plate:raise ValueError('Invalid ultimate stress')
 if not isfinite(hole_diameter) or hole_diameter<c.db:raise ValueError('Invalid hole diameter')
 net_width=c.bp-2*(hole_diameter+25.4/16)
 if net_width<=0:raise ValueError('Nonpositive net width')
 demand=base['tension_flange_demand_N']/2
 ry=1.0*.6*c.fy_plate*c.bp*c.tp
 rr=.75*.6*fu_plate*net_width*c.tp
 return {'demand_N':demand,'shear_yield_LRFD_N':ry,'shear_rupture_LRFD_N':rr,
         'source_domain_issues':base['source_domain_issues'],
         'A3_numeric_comparison':demand<=min(ry,rr),'A3_checked_domain_conditions_satisfied':not base['source_domain_issues'],'aggregate_approved':False,
         'source':'DG39 Example5.3-1 p126, AISC J4.2 as invoked by guide',
         'net_hole_allowance_mm':25.4/16}

@dataclass(frozen=True)
class CompressionSideShearPath:
 receiver_tf:float
 receiver_fu:float
 plate_fu:float
 fnv_bolt:float
 plate_clear_distances:tuple
 receiver_clear_distances:tuple

def compression_bolts_A4(c:Plate4E,path:CompressionSideShearPath,N:float,M:float,V:float):
 """DG39 Example5.3-1 p127, four actual compression-side bolt holes.
 Clear distances are measured in actual force direction, to next hole/edge.
 Restricted to compression-side force; does not solve tension+shear bolt interaction.
 """
 base=evaluate_A1_A2(c,N,M,V)
 if abs(M)/(c.d-c.tf)-N/2 < 0:
  raise ValueError('Compression-side group not in compression: combined tension/shear route required')
 for d in (path.plate_clear_distances,path.receiver_clear_distances):
  if len(d)!=4 or not all(isfinite(v) and v>0 for v in d):raise ValueError('Four positive clear distances required for each connected part')
 if not all(isfinite(v) and v>0 for v in (path.receiver_tf,path.receiver_fu,path.plate_fu,path.fnv_bolt)):
  raise ValueError('Positive finite properties required')
 rb=path.fnv_bolt*pi*c.db*c.db/4
 capacities=[]
 for lp,lr in zip(path.plate_clear_distances,path.receiver_clear_distances):
  rp=min(2.4*c.db*c.tp*path.plate_fu,1.2*lp*c.tp*path.plate_fu)
  rr=min(2.4*c.db*path.receiver_tf*path.receiver_fu,1.2*lr*path.receiver_tf*path.receiver_fu)
  capacities.append(.75*min(rb,rp,rr))
 # Equal shear across this source-assumed four-bolt group: weakest bolt governs.
 demand_per_bolt=abs(V)/4
 return {'source':'DG39 Example5.3-1 p127, AISC J3.11 invoked by guide',
         'design_strengths_each_bolt_N':capacities,'demand_each_bolt_N':demand_per_bolt,
         'A4_numeric_comparison':all(demand_per_bolt<=r for r in capacities),
         'equal_distribution_group_strength_N':4*min(capacities),
         'source_domain_issues':base['source_domain_issues'],
         'aggregate_approved':False,
         'pending':['actual directional hole geometry and edge detailing',
                    'bolt material grade and Fnv catalog verification',
                    'bolt length and assembly requirements','B welds','C receiver local and panel checks']}
