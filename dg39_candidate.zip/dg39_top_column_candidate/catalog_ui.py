"""Reuse app physical-property catalogues; never import resistance formulas."""
from dataclasses import asdict
import streamlit as st
from lro.models import profiles, STEELS, DIAMETERS

MANUAL='Informar manualmente'
PROFILES={k:asdict(v) for k,v in profiles().items() if v.family=='W'}

def number(label,*,value,key,**kwargs):
    if key not in st.session_state:st.session_state[key]=value
    return st.number_input(label,key=key,**kwargs)


def _migrate_legacy_draft(prefix):
    old=st.session_state.get(prefix+'_manual_draft')
    if isinstance(old,dict) and set(old)=={'fy','fu'}:
        st.session_state.setdefault(prefix+'_manual_material_draft',dict(old))
        del st.session_state[prefix+'_manual_draft']

def material(label,key,default,product,thickness):
    _migrate_legacy_draft(key)
    options=[name for name,s in STEELS.items() if (s.plate_allowed if product=='plate' else s.rolled_allowed)]+[MANUAL]
    name=st.selectbox(label,options,index=options.index(default),key=key+'_material')
    manual=name==MANUAL
    previous=st.session_state.get(key+'_last_material')
    if previous==MANUAL and name!=MANUAL:
        st.session_state[key+'_manual_material_draft']={x:st.session_state.get(key+'_'+x) for x in ('fy','fu')}
    if manual and previous!=MANUAL and key+'_manual_material_draft' in st.session_state:
        for x,value in st.session_state[key+'_manual_material_draft'].items():
            if value is not None:st.session_state[key+'_'+x]=value
    st.session_state[key+'_material_valid']=True
    if not manual:
        s=STEELS[name]
        if st.session_state.get(key+'_last_material')!=name:
            st.session_state[key+'_fy']=float(s.fy);st.session_state[key+'_fu']=float(s.fu);st.session_state[key+'_last_material']=name
        lower=s.plate_min if product=='plate' else s.profile_min;upper=s.plate_max if product=='plate' else s.profile_max
        if not lower<=thickness<=upper:
            st.session_state[key+'_material_valid']=False
            st.error(f'{name}: espessura {thickness:g} mm fora da faixa cadastral {lower:g}–{upper:g} mm. Selecionar material não comprova aplicabilidade.')
        st.caption(f'Propriedades nominais: {s.source}. Não importa fatores resistentes de outra rota; confirmar produto/certificado.')
    else:st.session_state[key+'_last_material']=MANUAL
    with st.expander('Propriedades do material — '+label,expanded=manual):
        fy=number('fy MPa · '+label,min_value=1.,value=345. if product!='plate' else 250.,key=key+'_fy',disabled=not manual)
        fu=number('fu MPa · '+label,min_value=1.,value=450. if product!='plate' else 400.,key=key+'_fu',disabled=not manual)
    if fu<fy:
        st.session_state[key+'_material_valid']=False
        st.error('fu não pode ser inferior a fy; confira a seleção/entrada.')
    return fy,fu,name

def section(role,default):
    col=role=='coluna';prefix='dg39_col' if col else 'dg39_rec'
    _migrate_legacy_draft(prefix)
    name=st.selectbox('Perfil da '+role,list(PROFILES)+[MANUAL],index=list(PROFILES).index(default),key=prefix+'_profile')
    manual=name==MANUAL
    keys={'d':'dg39_d' if col else prefix+'_d','bf':prefix+'_bf','tf':prefix+'_tf','tw':prefix+'_tw'}
    fallback={'d':205. if col else 207.,'bf':166. if col else 133.,'tf':11.8 if col else 8.4,'tw':7.2 if col else 5.8}
    previous=st.session_state.get(prefix+'_last_profile')
    if previous!=name:
        if previous==MANUAL:
            st.session_state[prefix+'_manual_draft']={k:st.session_state.get(key,fallback[k]) for k,key in keys.items()}
            if not col:st.session_state[prefix+'_manual_area']=st.session_state.get('dg39_receiver_area','')
        if manual and prefix+'_manual_draft' in st.session_state:
            for k,key in keys.items():st.session_state[key]=st.session_state[prefix+'_manual_draft'][k]
        if not manual:
            row=PROFILES[name]
            for k,key in keys.items():st.session_state[key]=float(row[k])
            if not col:st.session_state['dg39_receiver_area']=f"{row['area']:g}"
        if col:st.session_state['dg39_k1']=''
        else:
            st.session_state['dg39_receiver_kdes']=''
            if manual:st.session_state['dg39_receiver_area']=st.session_state.get(prefix+'_manual_area','')
        st.session_state[prefix+'_last_profile']=name
    if not manual:
        row=PROFILES[name]
        st.caption(f"{row['mass']:g} kg/m · A={row['area']:g} mm² · d={row['d']:g} · bf={row['bf']:g} · tf={row['tf']:g} · tw={row['tw']:g} mm")
        st.caption('Origem: '+row['source'])
    else:st.caption('Seção personalizada: dimensões e área precisam corresponder ao perfil real. A rota não muda automaticamente.')
    with st.expander('Dimensões da '+role+' — catálogo / edição manual',expanded=manual):
        labels={'d':'Altura d','bf':'Largura de mesa bf','tf':'Espessura de mesa tf','tw':'Espessura de alma tw'}
        values={k:number(labels[k]+' da '+role+' mm',min_value=.1,value=fallback[k],key=key,disabled=not manual) for k,key in keys.items()}
    fy,fu,steel=material('Aço da '+role,prefix,'ASTM A572 Gr.50','profile',max(values['tf'],values['tw']))
    return dict(values,fy=fy,fu=fu,name=name,steel=steel,source=PROFILES[name]['source'] if not manual else 'Entrada manual',area=PROFILES[name]['area'] if not manual else None)

def bolt_diameter():
    labels=list(DIAMETERS)+[MANUAL]
    name=st.selectbox('Diâmetro nominal do parafuso',labels,index=labels.index('3/4"'),key='dg39_diameter_choice')
    manual=name==MANUAL
    if st.session_state.get('dg39_last_diameter')!=name:
        if not manual:st.session_state['dg39_db']=float(DIAMETERS[name])
        st.session_state['dg39_last_diameter']=name
    db=number('Diâmetro do parafuso mm',min_value=1.,value=19.05,key='dg39_db',disabled=not manual)
    if db!=19.05:st.warning('Este diâmetro não tem todo o detalhamento de borda/furo qualificado nesta candidata. Não haverá aprovação por extrapolação.')
    return db

def domain_message(code):
    if code=='Table5-9:d':return 'Altura d da coluna fora da faixa qualificada da rota 4E (Tabela 5-9; limite inferior com tolerância: 360,045 mm). Troque o perfil se necessário; o método permanece 4E. [Table5-9:d]'
    return code
