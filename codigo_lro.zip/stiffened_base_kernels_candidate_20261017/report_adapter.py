"""Isolated report boundary. Never prevents reporting because a check fails.
No active UI/report template is imported; callers explicitly supply geometry.
"""
import json
from .composition import symmetric_rib_load_path
from .section_checks import check_composed_elastic_stresses
from .receiver import paired_column_receiver
from .triangular_candidate import composed_triangular_stability
from .tension_rib import long_tension_rib


def compose_report_candidate(*,left_inputs,right_inputs,receiver_inputs,plate_fy_MPa,rib_fy_MPa,
                             stability_model_selected=None,short_edge_support_condition=None,
                             tension_rib_inputs=None):
    sides=[]
    for name,inputs in (('left',left_inputs),('right',right_inputs)):
        try:
            path=symmetric_rib_load_path(**inputs)
            if path['domain']:
                elastic=check_composed_elastic_stresses(load_path=path,plate_thickness_mm=inputs['plate_thickness_mm'],
                    plate_fy_MPa=plate_fy_MPa,rib_fy_MPa=rib_fy_MPa)
                selected=stability_model_selected.get(name) if isinstance(stability_model_selected,dict) else stability_model_selected
                if selected=='P207_long_tension_rib':
                    stability=long_tension_rib(load_path=path,model_selected=selected,rib_fy_MPa=rib_fy_MPa,**(tension_rib_inputs or {}))
                else:
                    stability=composed_triangular_stability(load_path=path,model_selected=selected,
                        short_edge_support_condition=short_edge_support_condition,rib_fy_MPa=rib_fy_MPa)
            else:
                elastic=stability=dict(component_domain=False,reasons=['Geometry/load path outside domain'])
            sides.append(dict(name=name,load_path=path,elastic=elastic,stability=stability))
        except (ValueError,TypeError,OverflowError) as exc:
            sides.append(dict(name=name,load_path=dict(domain=False,reasons=[str(exc)]),
                elastic=None,stability=None,input_error=True))
    if all(s['load_path'].get('domain') for s in sides):
        try:
            receiver=paired_column_receiver(left_load_path=sides[0]['load_path'],right_load_path=sides[1]['load_path'],**receiver_inputs)
        except (ValueError,TypeError,OverflowError) as exc:
            receiver=dict(domain=False,reasons=[str(exc)],input_error=True)
    else:
        receiver=dict(domain=False,reasons=['Receiver calculation requires both valid side load paths'])
    result=dict(candidate_only=True,production_credit=False,assembly_approval=False,sides=sides,receiver=receiver,
        scope='Symmetric exterior ribs only; explicit geometry, no automatic detail replacement',
        pending=['Central plate panels and full load partition equilibrium',
            'Anchor/concrete and hole/washer checks','Weld detailing and base metal',
            'Reversed-load variable rib stability when tension present',
            'Independent complete topology review before runtime'])
    result['check_states']=collect_check_states(result)
    result['assembly_state']='incomplete_not_approved'
    # Verify exportability at the boundary, before any UI/MC consumer receives it.
    json.dumps(result,allow_nan=False)
    return result


def collect_check_states(value,path='result'):
    """Do not equate a sufficient bound failure with physical structural failure."""
    states=[]
    if isinstance(value,dict):
        if value.get('status') in ('PASS','FAIL','NOT_APPLICABLE'):
            states.append(dict(component=path,state={'PASS':'component_bound_satisfied','FAIL':'component_bound_not_satisfied','NOT_APPLICABLE':'not_demanded'}[value['status']]))
        if isinstance(value.get('ratio'),(int,float)):
            states.append(dict(component=path,state='component_bound_satisfied' if value['ratio']<=1 else 'component_bound_not_satisfied'))
        if value.get('input_error'): states.append(dict(component=path,state='input_error'))
        if value.get('domain') is False or value.get('component_domain') is False:
            states.append(dict(component=path,state='outside_domain',reasons=value.get('reasons',[])))
        for key in ('passes','passes_weld_metal_only','capacity_bound_satisfied','normal_pass','shear_pass','prescription_satisfied','weld_material_matching'):
            if key in value:
                states.append(dict(component=path+'.'+key,state='component_bound_satisfied' if value[key] else 'component_bound_not_satisfied',
                    physical_failure_demonstrated=value.get('physical_failure_demonstrated',False)))
        for key,item in value.items():
            if key!='check_states': states.extend(collect_check_states(item,path+'.'+key))
    elif isinstance(value,(list,tuple)):
        for i,item in enumerate(value): states.extend(collect_check_states(item,f'{path}[{i}]'))
    return states


def export_mc_text(result):
    """Plain-text MC evidence, available for passed, failed and outside-domain data."""
    lines=['MEMÓRIA DE CÁLCULO CANDIDATA, NÃO LIBERADA PARA PRODUÇÃO',
           'Geometria fornecida preservada. Atender um componente não aprova o conjunto.',
           'Estado do conjunto: '+result.get('assembly_state','incomplete_not_approved'),'',
           'ESTADOS POR COMPONENTE']
    for state in result.get('check_states',collect_check_states(result)):
        lines.append(state['component']+': '+state['state'])
        lines.extend('  '+reason for reason in state.get('reasons',[]))
    lines+=['','RESULTADOS COMPLETOS E ESCOPO',json.dumps(result,indent=2,ensure_ascii=False,allow_nan=False)]
    return '\n'.join(lines)+'\n'
