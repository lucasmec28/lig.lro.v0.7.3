"""Elastic planar line-weld group actions, separate foot/root calls required.

Local x,y are in joint plane, z normal. Forces/moments about line centroid.
Uniform throat/material only. Effective segments supplied explicitly, not all
physical perimeter automatically. Cross product r × q defines moment signs.
Classical elastic weld-group mechanics: F/L; Mz*r/J; normal linear traction.
No base-metal, local plate bending, fabrication or whole-joint approval.
"""
from math import hypot, sqrt
from .kernels import real, positive, finite_result


@finite_result
def weld_group(*, segments, Fx_N=0., Fy_N=0., Fz_N=0., Mx_Nmm=0., My_Nmm=0., Mz_Nmm=0.):
    forces=[real(v,n) for v,n in zip((Fx_N,Fy_N,Fz_N,Mx_Nmm,My_Nmm,Mz_Nmm),('Fx','Fy','Fz','Mx','My','Mz'))]
    Fx,Fy,Fz,Mx,My,Mz=forces
    seg=[]; L=sx=sy=0.
    for line in segments:
        if len(line)!=4: raise ValueError('Segment requires x0,y0,x1,y1')
        x0,y0,x1,y1=[real(v,'coordinate') for v in line]; l=hypot(x1-x0,y1-y0)
        positive(l,'segment length')
        dx,dy=x1-x0,y1-y0
        for a,b,c,d,old_l in seg:
            tol=1e-12*max(l,old_l,1.)
            if abs(dx*(b-y0)-dy*(a-x0))<=tol*l and abs(dx*(d-y0)-dy*(c-x0))<=tol*l:
                t0=((a-x0)*dx+(b-y0)*dy)/l; t1=((c-x0)*dx+(d-y0)*dy)/l
                if min(l,max(t0,t1))-max(0.,min(t0,t1))>tol:
                    raise ValueError('Overlapping effective weld segments double count material')
        seg.append((x0,y0,x1,y1,l))
        L+=l; sx+=l*(x0+x1)/2; sy+=l*(y0+y1)/2
    positive(L,'group length'); cx=sx/L; cy=sy/L
    Ixx=Iyy=Ixy=0.
    for x0,y0,x1,y1,l in seg:
        x0-=cx; x1-=cx; y0-=cy; y1-=cy
        Ixx+=l*(y0*y0+y0*y1+y1*y1)/3
        Iyy+=l*(x0*x0+x0*x1+x1*x1)/3
        Ixy+=l*(2*x0*y0+x0*y1+x1*y0+2*x1*y1)/6
    J=Ixx+Iyy; determinant=Ixx*Iyy-Ixy*Ixy
    # qz=Fz/L + ax*x + ay*y. My=-integral(x*qz); Mx=integral(y*qz).
    if determinant>1e-14*max(Ixx*Iyy,J*J):
        ax=(-My*Ixx-Mx*Ixy)/determinant; ay=(Mx*Iyy+My*Ixy)/determinant
    elif abs(Ixy)<=1e-14*J and Ixx==0 and My==0:
        ax=0.; ay=0.
        if Mx: raise ValueError('Collinear group cannot resist Mx')
    elif abs(Ixy)<=1e-14*J and Iyy==0 and My==0:
        ax=0.; ay=Mx/Ixx
    elif abs(Ixy)<=1e-14*J and Ixx==0 and Mx==0:
        ax=-My/Iyy; ay=0.
    elif Mx==0 and My==0: ax=ay=0.
    else: raise ValueError('Singular out-of-plane weld group')
    points=[]
    for x0,y0,x1,y1,l in seg:
        for x,y in ((x0,y0),(x1,y1)):
            xx=x-cx; yy=y-cy
            qx=Fx/L-Mz*yy/J; qy=Fy/L+Mz*xx/J; qz=Fz/L+ax*xx+ay*yy
            points.append(dict(x_mm=x,y_mm=y,qx_N_mm=qx,qy_N_mm=qy,qz_N_mm=qz,q_N_mm=sqrt(qx*qx+qy*qy+qz*qz)))
    # Norm of affine traction on each straight segment is convex: endpoint maximum exact.
    return dict(L_mm=L,centroid_mm=(cx,cy),Ixx_mm3=Ixx,Iyy_mm3=Iyy,Ixy_mm3=Ixy,J_mm3=J,
                normal_coefficients=(ax,ay),endpoints=points,qmax_N_mm=max(p['q_N_mm'] for p in points),
                recovered_forces_N=(Fx,Fy,Fz),
                recovered_moments_Nmm=(ax*Ixy+ay*Ixx,-ax*Iyy-ay*Ixy,Mz),
                production_credit=False,base_metal_verified=False)


@finite_result
def weld_metal_comparison(*, actions, fuw_MPa, throat_mm, combination_kind):
    """Reuse existing NBR 8800:2024 Table 9 scalar function, no new coefficients.
    Import source hash recorded in SOURCES.json; tests cover its unchanged API.
    'passes_weld_metal_only' must never be promoted to connection approval.
    """
    from .verified_welds import fillet_unit_length_resistance
    rd=fillet_unit_length_resistance(fuw_MPa=fuw_MPa, throat_mm=throat_mm, combination_kind=combination_kind)
    demand=real(actions['qmax_N_mm'],'qmax',0)
    return dict(demand_N_mm=demand,resistance_N_mm=rd.resistance_N_per_mm,
                utilization=demand/rd.resistance_N_per_mm,passes_weld_metal_only=demand<=rd.resistance_N_per_mm,
                source=rd.source,production_credit=False,connection_approval=False)
