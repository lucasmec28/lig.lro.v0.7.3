"""Finite classical load-path composition for one exterior, rectangular rib.

Bellei §§2.3.5–2.3.5.1: independent transverse cantilever strips to central rib;
DG1 Ex4.7-3: opposite equal anchor strips, qface=T/beff, local receiver 2q/tr;
P207 §6.8: rib-base weld for tension/shear; compression may bear if guaranteed.

Each constant longitudinal cell is a pair of symmetric transverse strips.
The plate is continuous across the rib: opposing transverse interface moments
remain in plate flexure and are not a fictitious net torque on the rib.
Only uniaxial global contact p(x), four symmetric anchors and no torsion/V are
in this domain. This is an explicit statical published approximation, not FE.
No complete member stability or column-receiver capacity is inferred here.
"""
from math import sqrt
from .kernels import real,positive,finite_result
from .joints import weld_group,weld_metal_comparison


def _strip_moments(p,reach,c,t_per_width):
    """Exact signed bending envelope of one transverse cantilever in one cell.
    Compression pressure positive; anchor downward negative. T/beff distributed
    along s, concentrated at transverse coordinate c. No unphysical pmax field.
    """
    points={0.,reach}
    if 0<c<reach: points.add(c)
    if p and t_per_width:
        u=reach-t_per_width/p
        if 0<u<min(c,reach): points.add(u)
    values=[(u,p*(reach-u)**2/2-t_per_width*max(c-u,0)) for u in sorted(points)]
    maximum=max(values,key=lambda x:abs(x[1]))
    return dict(candidates_u_m_mm=values,maximum_abs_m_Nmm_per_mm=abs(maximum[1]),
                governing_u_mm=maximum[0],signed_m_at_support_Nmm_per_mm=values[0][1])


@finite_result
def symmetric_rib_load_path(*, rib_length_mm,rib_height_mm,rib_thickness_mm,
        plate_length_mm,column_depth_mm,column_flange_width_mm,
        plate_width_mm,plate_thickness_mm,gauge_mm,bolt_s_mm,bolt_forces_N,
        contact_start_mm,contact_end_mm,contact_pressure_MPa,
        foot_effective_start_mm,foot_effective_end_mm,foot_throat_mm,root_throat_mm,
        root_weld_start_height_mm,root_weld_end_height_mm,fuw_MPa,combination_kind,
        plate_monolithic_over_rib,symmetric_geometry,foot_welds_equivalent,
        compression_bearing_guaranteed,tension_component_inputs=None,rib_top_profile_mm=None):
    """Return demands and finite component states even if a scalar check fails.

    Contact is the ACTUAL portion of the global uniform pressure block on this
    rib's entire tributary B width, not an arbitrary area-sharing coefficient.
    Rib extends to the plate edge; central region between column faces is a
    separate panel/receptor, never silently assigned to this exterior rib.
    Solid rectangle or explicit positive piecewise-linear top outline, no cutouts/holes.
    A zero-height triangular tip is not silently approximated by a rectangle.
    Local axes root: x transverse to rib; y vertical; z outward longitudinal.
    """
    lr=positive(rib_length_mm,'lr'); h=positive(rib_height_mm,'h'); tr=positive(rib_thickness_mm,'tr')
    B=positive(plate_width_mm,'B'); tp=positive(plate_thickness_mm,'tp'); g=positive(gauge_mm,'g')
    L=positive(plate_length_mm,'L'); d=positive(column_depth_mm,'d'); bf=positive(column_flange_width_mm,'bf')
    a=real(bolt_s_mm,'a',0); s0=real(contact_start_mm,'contact start',0); s1=real(contact_end_mm,'contact end',0)
    p=real(contact_pressure_MPa,'pressure',0); lo=real(foot_effective_start_mm,'foot start',0); hi=positive(foot_effective_end_mm,'foot end')
    af=positive(foot_throat_mm,'foot throat'); ar=positive(root_throat_mm,'root throat')
    z0=real(root_weld_start_height_mm,'root weld start',0); z1=positive(root_weld_end_height_mm,'root weld end')
    if not 0<=s0<=s1<=lr or not 0<=lo<hi<=lr or not 0<=z0<z1<=h: raise ValueError('Intervals outside actual rib')
    if len(bolt_forces_N)!=2: raise ValueError('Exactly two anchor forces required')
    tl,tt=[real(x,'anchor force',0) for x in bolt_forces_N]
    flags=(plate_monolithic_over_rib,symmetric_geometry,foot_welds_equivalent,compression_bearing_guaranteed)
    if any(type(x) is not bool for x in flags): raise ValueError('Explicit boolean geometric conditions required')
    reasons=[]
    if L<=d or abs(lr-(L-d)/2)>1e-9: reasons.append('Rib must reach physical plate edge without changing geometry')
    if B<bf: reasons.append('Plate does not contain column flange')
    if not plate_monolithic_over_rib: reasons.append('Plate discontinuous across rib; opposite strip moments cannot be balanced by continuity')
    if not symmetric_geometry or tl!=tt: reasons.append('Transverse symmetry and equal anchor forces required')
    if not foot_welds_equivalent: reasons.append('Two equivalent foot welds required')
    if not tr<g<B: reasons.append('Anchor/rib/edge ordering invalid')
    if a>lr: reasons.append('Anchor outside rib length')
    top=((0.,h),(lr,h)) if rib_top_profile_mm is None else tuple(tuple(v) for v in rib_top_profile_mm)
    if len(top)<2: raise ValueError('Top profile requires at least two points')
    for x,hh in top: real(x,'profile s',0); positive(hh,'profile height')
    if top[0]!=(0.,h) or top[-1][0]!=lr: raise ValueError('Profile must retain actual root height and rib length')
    if any(b[0]<=a_[0] or b[1]>a_[1] for a_,b in zip(top,top[1:])):
        raise ValueError('Top profile must advance strictly and not increase height')
    def height_at(s):
        for (x0,h0),(x1,h1) in zip(top,top[1:]):
            if x0<=s<=x1: return h0+(h1-h0)*(s-x0)/(x1-x0)
        raise ValueError('Section outside rib')
    c=(g-tr)/2; beff=2*c; reach=(B-tr)/2
    if tl and not (lo<=a-c and a+c<=hi): reasons.append('DG1 fan outside actual effective foot weld')
    if p and s1>s0 and not compression_bearing_guaranteed and not (lo<=s0 and s1<=hi): reasons.append('Compression has no full foot weld or guaranteed bearing path')
    tension_component=None
    if tl:
        from .tension_component import mapped_tension_component
        required={'column_flange_base_weld_leg_mm','bolt_stress_area_mm2','free_rod_segments'}
        if not isinstance(tension_component_inputs,dict) or set(tension_component_inputs)!=required:
            reasons.append('Explicit source parameters for no-prying calculation required, not a pass flag')
        elif not reasons:
            tension_component=mapped_tension_component(plate_L_mm=L,plate_B_mm=B,column_d_mm=d,column_bf_mm=bf,
                rib_length_mm=lr,rib_thickness_mm=tr,gauge_mm=g,bolt_a1_mm=a,
                rib_base_weld_leg_mm=af*sqrt(2),effective_foot_start_mm=lo,effective_foot_end_mm=hi,
                plate_thickness_mm=tp,bolt_force_N=tl,**tension_component_inputs)
            if not tension_component['component_domain'] or not tension_component['component_no_prying_bound']:
                reasons.extend(tension_component['reasons'])
    out=dict(domain=not reasons,reasons=reasons,production_credit=False,assembly_approval=False,
             pending=['rib out-of-plane stability and NBR interactions','column flange/web receiver checks',
                      'weld detailing and base metal','central plate panels','anchors and concrete'],
             source='Bellei 2006 §§2.3.5–2.3.5.1; DG1 3rd Ex4.7-3; SCI P207 §6.8',
             tension_component=tension_component,
             geometry=dict(rib_length_mm=lr,rib_height_mm=h,rib_thickness_mm=tr,plate_thickness_mm=tp,
                plate_length_mm=L,plate_width_mm=B,column_depth_mm=d,column_flange_width_mm=bf,
                root_weld_start_height_mm=z0,root_weld_end_height_mm=z1,foot_throat_mm=af,root_throat_mm=ar,
                rib_top_profile_mm=top,foot_effective_start_mm=lo,foot_effective_end_mm=hi))
    if reasons: return out
    cuts=sorted({0.,lr,s0,s1,*[x for x,hh in top],*([a-c,a+c] if tl else [])})
    cells=[]
    for left,right in zip(cuts,cuts[1:]):
        if right==left: continue
        mid=(left+right)/2
        pp=p if s0<=mid<=s1 else 0.
        td=tl/beff if tl and a-c<=mid<=a+c else 0.
        contact_line=pp*B
        net=contact_line-2*td
        # Bearing relieves only positive compression. Tension never disappears.
        qface=(min(net,0.) if compression_bearing_guaranteed else net)/2
        plate=_strip_moments(pp,reach,c,td)
        cells.append(dict(start_mm=left,end_mm=right,p_MPa=pp,T_per_face_per_mm=td,
            rib_line_N_mm=net,foot_weld_qface_N_mm=qface,
            local_rib_normal_MPa=net/tr,plate=plate))
    V=sum(v['rib_line_N_mm']*(v['end_mm']-v['start_mm']) for v in cells)
    M=sum(v['rib_line_N_mm']*(v['end_mm']**2-v['start_mm']**2)/2 for v in cells)
    def section(s):
        shear=moment=0.
        for v in cells:
            left=max(s,v['start_mm']); right=v['end_mm']; w=v['rib_line_N_mm']
            if right>left:
                shear+=w*(right-left); moment+=w*((right-s)**2-(left-s)**2)/2
        hs=height_at(s)
        return dict(s_mm=s,height_mm=hs,N_N=0.,V_N=shear,M_Nmm=moment,
            sigma_bending_extreme_MPa=6*moment/(tr*hs*hs),tau_shear_max_MPa=1.5*shear/(tr*hs))
    sections=[section(s) for s in cuts]
    for cell in cells:
        w=cell['rib_line_N_mm']; left=cell['start_mm']; right=cell['end_mm']
        if w:
            # V'(s)=-w; zero shear gives interior extremum of bending moment.
            s=left+section(left)['V_N']/w
            if left<s<right: sections.append(section(s))
        # M/h² extrema for the ACTUAL taper, not just maxima of M.
        h0=height_at(left); k=(height_at(right)-h0)/(right-left)
        at_left=section(left); V0=at_left['V_N']; M0=at_left['M_Nmm']
        denominator=w*h0+k*V0
        if denominator:
            u=(V0*h0+2*k*M0)/denominator
            if 0<u<right-left: sections.append(section(left+u))
    sections.sort(key=lambda x:x['s_mm'])
    # Root moment is about transverse axis; vertical shear is in root joint plane.
    root=weld_group(segments=[(-tr/2,z0,-tr/2,z1),(tr/2,z0,tr/2,z1)],Fy_N=V,Mx_Nmm=-M)
    root_check=weld_metal_comparison(actions=root,fuw_MPa=fuw_MPa,throat_mm=ar,combination_kind=combination_kind)
    foot_q=max(abs(v['foot_weld_qface_N_mm']) for v in cells)
    foot_check=weld_metal_comparison(actions={'qmax_N_mm':foot_q},fuw_MPa=fuw_MPa,throat_mm=af,combination_kind=combination_kind)
    out.update(cells=cells,sections=sections,root_actions=dict(N_N=0.,V_N=V,M_Nmm=M),
        root_weld_group=root,root_weld_metal= root_check,foot_weld_metal=foot_check,
        maximum_plate_bending_Nmm_per_mm=max(v['plate']['maximum_abs_m_Nmm_per_mm'] for v in cells),
        maximum_local_rib_normal_MPa=max(abs(v['local_rib_normal_MPa']) for v in cells),
        root_properties=dict(A_mm2=tr*h,W_mm3=tr*h*h/6,I_mm4=tr*h**3/12),
        transverse_net_torque_Nmm=0.,transverse_plate_moments_retained=True)
    return out
