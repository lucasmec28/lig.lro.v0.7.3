"""Isolated actions kernels, never a complete base approval or production route."""
