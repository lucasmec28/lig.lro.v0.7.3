"""Explicit illustrative geometry; calls existing equilibrium without changing it."""
from dataclasses import replace
import sys
from pathlib import Path
from .composition import symmetric_rib_load_path
from .receiver import paired_column_receiver
from .section_checks import check_composed_elastic_stresses
from .triangular_candidate import composed_triangular_stability


def run_nm_benchmark(moment_Nmm=120e6,*,rib_height_mm=300,throat_mm=6/2**.5):
    from lro.models import Profile
    from lro.base_plate import BasePlate,reactions
    class Geometry(BasePlate):
        @property
        def L(self): return 672.8
        @property
        def B(self): return 219.6
        @property
        def a(self): return self.column.d/2+self.a1
    p=Profile('Explicit benchmark I300x160','Soldado',40.,300.,160.,8.,12.,276.,6048.)
    c=Geometry(p,a1=106.4,a2=119.6,N=400000,M=moment_Nmm)
    r=reactions(c); lr=(c.L-p.d)/2
    xlo=c.L/2-r['lc'] if moment_Nmm>=0 else -c.L/2
    xhi=c.L/2 if moment_Nmm>=0 else -c.L/2+r['lc']
    paths=[]
    for side in (-1,1):
        # Project actual contact onto s measured outward from this column face.
        endpoints=sorted((side*xlo-p.d/2,side*xhi-p.d/2))
        lo=max(0.,min(lr,endpoints[0])); hi=max(0.,min(lr,endpoints[1]))
        T=sum(force for force,x in ((r['Ft_max'],r['T_max_x']),(r['Ft_min'],r['T_min_x'])) if side*x>0)
        path=symmetric_rib_load_path(rib_length_mm=lr,rib_height_mm=rib_height_mm,rib_thickness_mm=10,
            rib_top_profile_mm=[(0,rib_height_mm),(20,rib_height_mm),(lr,20)],plate_length_mm=c.L,column_depth_mm=p.d,column_flange_width_mm=p.bf,
            plate_width_mm=c.B,plate_thickness_mm=25,gauge_mm=119.6,bolt_s_mm=c.a1,bolt_forces_N=(T,T),
            contact_start_mm=lo,contact_end_mm=hi,contact_pressure_MPa=r['sigma'],
            foot_effective_start_mm=0,foot_effective_end_mm=lr,foot_throat_mm=throat_mm,root_throat_mm=throat_mm,
            root_weld_start_height_mm=0,root_weld_end_height_mm=rib_height_mm,fuw_MPa=490,combination_kind='normal',
            plate_monolithic_over_rib=True,symmetric_geometry=True,foot_welds_equivalent=True,compression_bearing_guaranteed=False,
            tension_component_inputs=dict(column_flange_base_weld_leg_mm=8,bolt_stress_area_mm2=353,free_rod_segments=[(120,353)]))
        paths.append(path)
    centerlo=max(-p.d/2,xlo); centerhi=min(p.d/2,xhi)
    centerV=r['sigma']*c.B*max(0.,centerhi-centerlo)
    centerM=centerV*(centerlo+centerhi)/2
    Nrec=centerV+sum(q['root_actions']['V_N'] for q in paths)
    Mrec=centerM+sum(side*(q['root_actions']['M_Nmm']+p.d/2*q['root_actions']['V_N']) for side,q in zip((-1,1),paths))
    receiver=paired_column_receiver(left_load_path=paths[0],right_load_path=paths[1],column_flange_thickness_mm=p.tf,
        column_web_thickness_mm=p.tw,column_gross_area_mm2=6048,column_fy_MPa=250,column_fu_MPa=400,column_fabrication='welded',
        column_panel_shear_at_bottom_N=0,column_axial_compression_envelope_N=c.N,column_flange_lateral_length_mm=2000,root_weld_leg_mm=throat_mm*2**.5)
    return dict(illustrative_geometry_only=True,production_credit=False,N_N=c.N,M_Nmm=moment_Nmm,reactions=r,
        central_contact_N=centerV,central_contact_M_Nmm=centerM,residual_N=Nrec-c.N,residual_M_Nmm=Mrec-moment_Nmm,
        sides=paths,receiver=receiver,
        elastic=[check_composed_elastic_stresses(load_path=q,plate_thickness_mm=25,plate_fy_MPa=250,rib_fy_MPa=250) for q in paths],
        stability=[composed_triangular_stability(load_path=q,model_selected='triangular_inscribed_strips',short_edge_support_condition='both_short_edges_rigidly_supported',rib_fy_MPa=250) for q in paths])
