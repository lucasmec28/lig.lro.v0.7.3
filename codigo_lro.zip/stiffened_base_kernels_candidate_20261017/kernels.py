"""N, mm, MPa. Published demand models; no topology inference or design approval.

Bellei 2006 pp36–37 tables are transcribed from rendered originals. Edge order
is bottom/right/top/left in the source diagram, a horizontal and b vertical.
No table supplies reactions, stiffness, or support adequacy. A computed demand
is not evidence that the real weld/member provides the specified restraint.
"""
from dataclasses import dataclass, asdict
from math import isfinite, sqrt, hypot
from numbers import Real
from functools import wraps


def finite_result(fn):
    """Reject overflow/underflow-to-division failures rather than export NaN/Inf."""
    @wraps(fn)
    def checked(*args, **kwargs):
        try:
            result=fn(*args, **kwargs)
        except (OverflowError, ZeroDivisionError) as exc:
            raise ValueError('Outside finite numerical domain') from exc
        def visit(v):
            if isinstance(v,float) and not isfinite(v): raise ValueError('Nonfinite derived result')
            if isinstance(v,dict):
                for x in v.values(): visit(x)
            elif isinstance(v,(list,tuple)):
                for x in v: visit(x)
        visit(result)
        return result
    return checked


def real(v, name, minimum=None):
    if isinstance(v, bool) or not isinstance(v, Real) or not isfinite(v):
        raise ValueError(f'{name}: finite real required')
    if minimum is not None and v < minimum:
        raise ValueError(f'{name}: below {minimum}')
    return float(v)


def positive(v, name):
    v = real(v, name)
    if v <= 0: raise ValueError(f'{name}: positive required')
    return v


# Finite knots only. Case 5 infinity knot 0.8 is deliberately not interpolated.
TABLES = {
 1: ('CCCC', (1,1.2,1.4,1.6,1.8,2), (.31,.38,.44,.47,.49,.52)),
 2: ('CCFC', (.25,.5,.75,1,1.5,2,3), (.02,.08,.17,.32,.73,1.2,2.1)),
 3: ('CSFS', (.25,.5,.75,1,1.5,2,3), (.05,.19,.39,.67,1.28,1.8,2.5)),
 4: ('CFFC', (.125,.25,.375,.5,.75,1), (.05,.19,.40,.63,1.25,1.8)),
 5: ('SFSS', (.5,.67,1,1.5,2), (.36,.45,.67,.77,.79)),
 6: ('SSSS', (1,1.2,1.4,1.6,1.8,2,3), (.29,.38,.45,.52,.57,.61,.71)),
}


@finite_result
def panel_demand(*, case, edges, a_mm, b_mm, pressure_MPa):
    """Uniform-pressure table demand; explicit matching source orientation required."""
    if isinstance(case, bool) or case not in TABLES: raise ValueError('Unknown table case')
    expected, xs, ys = TABLES[case]
    if edges != expected: raise ValueError('Edges do not match source case/orientation')
    a, b = positive(a_mm,'a'), positive(b_mm,'b')
    p = real(pressure_MPa,'p',0); r = a/b
    if not xs[0] <= r <= xs[-1]: raise ValueError('No table extrapolation permitted')
    if r in xs:
        beta=ys[xs.index(r)]; bracket=(r,r)
    else:
        i=next(i for i in range(len(xs)-1) if xs[i] < r < xs[i+1])
        beta=ys[i]+(ys[i+1]-ys[i])*(r-xs[i])/(xs[i+1]-xs[i]); bracket=(xs[i],xs[i+1])
    return dict(case=case, edges=edges, ratio=r, beta=beta, bracket=bracket,
                m_Nmm_per_mm=beta*p*b*b/6, source='Bellei 2006 pp36–37',
                production_credit=False, support_adequacy_verified=False)


@dataclass(frozen=True)
class PressurePatch:
    """Actual rectangular loaded area, local s from rib root, y transverse.
    p(s,y)=p0+ps*s+py*y. Do not pass a fictitious pmax field as actual load.
    """
    s0: float
    s1: float
    y0: float
    y1: float
    p0: float
    ps: float=0.
    py: float=0.

    def validate(self):
        for name, value in asdict(self).items(): real(value,name)
        if not 0 <= self.s0 < self.s1 or not self.y0 < self.y1: raise ValueError('Invalid patch extent')
        if min(self.p0+self.ps*s+self.py*y for s in (self.s0,self.s1) for y in (self.y0,self.y1)) < 0:
            raise ValueError('Negative contact pressure; no silent clipping')


@finite_result
def pressure_resultant(patches):
    """Exact area integrals; reject overlap. Caller proves partition completeness."""
    patches=tuple(patches)
    V=Ms=My=area=0.
    for i,p in enumerate(patches):
        p.validate()
        for q in patches[:i]:
            if min(p.s1,q.s1)>max(p.s0,q.s0) and min(p.y1,q.y1)>max(p.y0,q.y0):
                raise ValueError('Overlapping tributary patches')
        sx=[(p.s1**(k+1)-p.s0**(k+1))/(k+1) for k in range(3)]
        yy=[(p.y1**(k+1)-p.y0**(k+1))/(k+1) for k in range(3)]
        V+=p.p0*sx[0]*yy[0]+p.ps*sx[1]*yy[0]+p.py*sx[0]*yy[1]
        Ms+=p.p0*sx[1]*yy[0]+p.ps*sx[2]*yy[0]+p.py*sx[1]*yy[1]
        My+=p.p0*sx[0]*yy[1]+p.ps*sx[1]*yy[1]+p.py*sx[0]*yy[2]
        area+=sx[0]*yy[0]
    return dict(V_N=V,Mroot_Nmm=Ms, transverse_first_moment_Nmm=My,
                centroid_s_mm=Ms/V if V else None, centroid_y_mm=My/V if V else None,
                loaded_area_mm2=area, partition_completeness_verified=False, production_credit=False)


@finite_result
def rib_actions(patches, point_forces=()):
    """Signed normal point loads (F,s,y), negative for anchor tension.
    Contact centroid remains separate from resultant line, undefined if V=0.
    """
    contact=pressure_resultant(patches); V=contact['V_N']; M=contact['Mroot_Nmm']; Q=contact['transverse_first_moment_Nmm']
    for F,s,y in point_forces:
        F=real(F,'F'); s=real(s,'s',0); y=real(y,'y'); V+=F; M+=F*s; Q+=F*y
    return dict(contact=contact,V_N=V,Mroot_Nmm=M,transverse_first_moment_Nmm=Q,
                resultant_s_mm=M/V if V else None, production_credit=False)


@finite_result
def cantilever_strip(*, reach_mm, loaded_start_mm, loaded_end_mm, pressure_MPa):
    """Unit-width strip, support at u=0, actual uniform loaded interval only."""
    e=positive(reach_mm,'reach'); u0=real(loaded_start_mm,'u0',0); u1=real(loaded_end_mm,'u1',0)
    if not u0<=u1<=e: raise ValueError('Loaded interval outside real cantilever')
    p=real(pressure_MPa,'p',0)
    return dict(V_N_per_mm=p*(u1-u0),m_Nmm_per_mm=p*(u1*u1-u0*u0)/2,production_credit=False)


@finite_result
def dg1_tension_strip(*, bolt_force_N, gauge_mm, rib_thickness_mm, bolt_s_mm,
                      effective_weld_start_mm, effective_weld_end_mm, plate_thickness_mm):
    """DG1 §4.3.2/Ex4.7-3 adapted demand only. No Q=0 permission.
    Actual continuous welded receiver interval must contain the entire 45° fan.
    """
    T=real(bolt_force_N,'T',0); g=positive(gauge_mm,'g'); tr=positive(rib_thickness_mm,'tr')
    s=real(bolt_s_mm,'s',0); lo=real(effective_weld_start_mm,'lo',0)
    hi=positive(effective_weld_end_mm,'hi'); tp=positive(plate_thickness_mm,'tp')
    if g<=tr or hi<=lo: raise ValueError('Invalid transverse arm or receiver interval')
    c=(g-tr)/2; b=2*c; fits=lo<=s-c and s+c<=hi
    return dict(c_mm=c, beff_mm=b if fits else None, fan_interval_mm=(s-c,s+c),
                geometric_domain=fits, M_per_bolt_Nmm=T*c,
                elastic_stress_MPa=6*T*c/(b*tp*tp) if fits else None,
                root_pair_V_N=-2*T, root_pair_M_Nmm=-2*T*s,
                effective_weld_length_per_face_mm=b if fits else None,
                tension_scope='blocked_pending_leff_prying_receiver_qualification',
                production_credit=False)


@finite_result
def equilibrium_residual(*, N_N, M_Nmm, C_N, C_x_mm, anchors):
    """Validate existing solver output; does not solve or reuse plain-plate sizing."""
    N=real(N_N,'N'); M=real(M_Nmm,'M'); C=real(C_N,'C',0); x=real(C_x_mm,'x')
    f=C; moment=C*x
    for T,tx in anchors:
        T=real(T,'T',0); tx=real(tx,'tx'); f-=T; moment-=T*tx
    return dict(residual_N=f-N,residual_M_Nmm=moment-M,production_credit=False)


@finite_result
def historical_bellei(*, beta, p_kN_cm2, b_cm, fy_kN_cm2, method):
    """HISTORICAL arithmetic only. Never a modern NBR verification."""
    beta=positive(beta,'beta'); p=real(p_kN_cm2,'p',0); b=positive(b_cm,'b'); fy=positive(fy_kN_cm2,'fy')
    if method not in ('ASD_historical','LRFD_historical'): raise ValueError('Historical method required')
    factor=.66 if method=='ASD_historical' else .99
    return dict(m_kNcm_per_cm=beta*p*b*b/6,t_historical_cm=b*sqrt(beta*p/(factor*fy)),
                modern_approval=False,source='Bellei 2006 historical comparison only')
