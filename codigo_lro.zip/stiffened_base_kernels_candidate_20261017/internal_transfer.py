"""Actual internal I-section interfaces under the retained nominal root field.
No autosizing, electrode substitution, or free-beam recovery is performed.
"""
from types import SimpleNamespace
from math import hypot
from .kernels import positive,real,finite_result
from .completion_components import _primitives
from .verified_local_helpers import flange_web_weld_stress_bounds

@finite_result
def internal_flange_web_transfer(*,receiver,column_web_thickness_mm,column_flange_thickness_mm,
        column_fy_MPa,column_fu_MPa,fabrication,internal_throat_mm,internal_fuw_MPa,
        continuous_two_faces,connected_height_mm,global_column_shear_N=0.):
    if not receiver.get('domain'):return dict(domain=False,reasons=['Receiver outside domain'])
    tw=positive(column_web_thickness_mm,'tw');tf=positive(column_flange_thickness_mm,'tf')
    fy=positive(column_fy_MPa,'fy');fu=positive(column_fu_MPa,'fu');height=positive(connected_height_mm,'connected height')
    h=receiver['root_effective_height_mm'];Vglobal=real(global_column_shear_N,'global shear')
    reasons=[]
    if Vglobal!=0:reasons.append('Nonzero global shear requires its separate concurrent longitudinal transfer field')
    if height<h:reasons.append('Internal connection does not cover actual root transfer height')
    if fabrication not in ('welded','rolled'):reasons.append('Identify welded or rolled I section')
    if fabrication=='welded' and continuous_two_faces is not True:reasons.append('Two real continuous internal fillets required')
    out=dict(domain=not reasons,reasons=reasons,checks=[],interfaces=[],production_credit=False,assembly_approval=False,
        source='Existing flange_web_weld_stress_bounds; NBR8800 Table9 and6.5.3/6.5.5',
        demand_basis='Same nominal Mface/Vroot field as receiver, N/M static with zero external column shear',
        P207_2_19=dict(state='not_applicable_to_this_receiver_topology',reason='Not a partial-depth stiffener inside receptor web; no invented diagonal cut'))
    if reasons:return out
    shear,tension=_primitives();case={'id':'current_NM'}
    for r in receiver['roots']:
        qn=6*abs(r['M_inner_face_Nmm'])/h**2;qs=abs(r['V_root_N'])/h
        name='flange_web_'+str(r['side'])
        # Distinct normal tension and longitudinal shear physical directions.
        tension(out,case,name+'_web_normal',qn,1.,tw,fy,fu)
        shear(out,case,name+'_web_parallel',qs,1.,tw,fy,fu)
        tension(out,case,name+'_flange_normal',qn,1.,tf,fy,fu)
        shear(out,case,name+'_flange_parallel',qs,1.,tf,fy,fu)
        entry=dict(side=r['side'],normal_line_bound_N_mm=qn,parallel_line_N_mm=qs,
            source_Mface_Nmm=r['M_inner_face_Nmm'],source_Vroot_N=r['V_root_N'])
        if fabrication=='welded':
            a=positive(internal_throat_mm,'actual internal throat');fw=positive(internal_fuw_MPa,'actual fuw')
            stress=flange_web_weld_stress_bounds(SimpleNamespace(section=SimpleNamespace(tw_mm=tw)),
                throat_mm=a,transverse_normal_bound_mpa=qn/tw,shear_transfer_bound_mpa=qs/tw)
            rd=.6*fw/1.35;demand=stress['traction_resultant_bound_mpa']
            entry.update(weld=dict(stress,actual_fuw_MPa=fw,resistance_MPa=rd,utilization=demand/rd,capacity_bound_satisfied=demand<=rd),
                weld_material_matching=fw>=fu)
        else:entry['weld']=dict(state='not_applicable_integral_rolled_section',fictitious_weld_created=False)
        out['interfaces'].append(entry)
    return out
