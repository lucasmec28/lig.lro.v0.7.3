"""Exact retained standalone helpers; provenance in docs/BASE_PORTABILITY.json."""
import math
SOURCE='ABNT NBR 8800:2024 + Er1:2025, 5.7.1–5.7.9, pp.63–68'

def _positive(v,zero=False):
    if isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or (v<0 if zero else v<=0):
        raise ValueError('Dimensão/ação numérica fora do domínio.')
    return float(v)

def local_web_capacities(s,m,*,bearing_length_mm,end_distance_mm,lateral_length_mm,loaded_flange='top',rotation_restrained=False):
    """5.7.3–6, no stiffener credit; k=tf for welded omits weld benefit.

    For wheels, ln=0 is an explicit conservative lower-bound choice at the
    OUTER flange, not the 10084 effective web length. Cr=16E is the lower branch
    regardless of the unknown first-yield moment; no unrelated M snapshot.
    """
    if loaded_flange not in ('top','bottom') or type(rotation_restrained) is not bool:raise ValueError('Mesa carregada ou vínculo inválido.')
    ln=_positive(bearing_length_mm,True);distance=_positive(end_distance_mm,True);ell=_positive(lateral_length_mm)
    tf=s.tf_mm if loaded_flange=='top' else s.bottom_thickness
    d=s.d_mm;tw=s.tw_mm;h=d-s.tf_mm-s.bottom_thickness-(2*s.root_radius_mm if s.fabrication=='rolled' else 0)
    for v in (tf,d,tw,h,m.E_mpa,m.fy_mpa,m.gamma_a1):_positive(v)
    k=tf+(s.root_radius_mm if s.fabrication=='rolled' else 0)
    yield_cap=1.10*((5 if distance>d else 2.5)*k+ln)*m.fy_mpa*tw/m.gamma_a1/1000
    near=distance<d/2
    c=.33 if near else .66
    q=(4*ln/d-.2) if near and ln/d>.2 else 3*ln/d
    cripple=c*tw**2/m.gamma_a1*(1+q*(tw/tf)**1.5)*math.sqrt(m.E_mpa*m.fy_mpa*tf/tw)/1000
    bf=s.bf_mm if loaded_flange=='top' else s.bottom_width
    ratio=(h/tw)/(ell/bf);limit=2.3 if rotation_restrained else 1.7
    lateral=16*m.E_mpa*tw**3*tf/(m.gamma_a1*h*h)*((.94 if rotation_restrained else 0)+.37*ratio**3)/1000
    opposed=24*tw**3*math.sqrt(m.E_mpa*m.fy_mpa)/(m.gamma_a1*h)/1000*(.5 if near else 1)
    return {'web_yield_kn':yield_cap,'web_crippling_kn':cripple,'web_sidesway_kn':lateral,
            'opposed_compression_kn':opposed,'lateral_mode_excluded':ratio>limit,'lateral_ratio':ratio,
            'lateral_threshold':limit,'Cr_mpa':16*m.E_mpa,'h_mm':h,'k_mm':k,'near_end':near,
            'bearing_length_mm':ln,'end_distance_mm':distance,'lateral_length_mm':ell,'source':SOURCE}

def flange_web_weld_stress_bounds(p, *,throat_mm,transverse_normal_bound_mpa,shear_transfer_bound_mpa):
    """Two equal continuous fillets; line equilibrium plus 45° throat transform.

    σz and resultant longitudinal-interface shear are nominal WEB-side bounds at
    the junction. qz=tw*σz and qx=tw*τ. Each symmetric weld takes half the line
    force. Vertical transfer resolves equally into throat normal/perpendicular
    shear; qx is parallel shear. Local web-bending is included in supplied σz.
    This is a nominal throat model, not a toe hot-spot field. No averaging of the
    local flow over the entire beam length and no fictitious load spread.
    """
    a=_positive(throat_mm);z=_positive(transverse_normal_bound_mpa,True);t=_positive(shear_transfer_bound_mpa,True)
    scale=p.section.tw_mm/(2*a)
    normal=scale*z/math.sqrt(2);parallel=scale*t;perpendicular=normal
    return {'normal_perpendicular_bound_mpa':normal,'shear_perpendicular_bound_mpa':perpendicular,
        'shear_parallel_bound_mpa':parallel,'shear_resultant_bound_mpa':math.hypot(parallel,perpendicular),
        'traction_resultant_bound_mpa':scale*math.hypot(z,t),
        'line_vertical_n_per_mm':z*p.section.tw_mm,'line_longitudinal_n_per_mm':t*p.section.tw_mm,
        'throat_mm':a,'number_of_lines_per_interface':2,'complete':True,
        'source':'NBR 8800, 5.4.5 e 5.7.1; equilíbrio q=t_w σ e transformação da garganta de filete a 45°.',
        'requirements':['Dois filetes iguais, contínuos, um em cada lado da alma, em ambas as mesas.',
            'Metal depositado com resistência ao escoamento e à ruptura não inferiores ao metal-base; procedimento e qualidade especificados.',
            'Tensões longitudinais globais do detalhe e fadiga são combinadas pela rota própria; não classificar garganta como metal-base.']}
