"""Finite completion components. Existing NBR primitives, actual actions only.
No complete-assembly approval is inferred from these individual comparisons.
"""
import sys
from pathlib import Path
from .kernels import positive,real,finite_result


def _primitives():
    from lro.welded_coverplate_splice import _shear,_tension
    return _shear,_tension

@finite_result
def adjacent_base_metal(*,load_path,rib_fy_MPa,rib_fu_MPa,plate_fy_MPa,plate_fu_MPa,
                        flange_thickness_mm,column_fy_MPa,column_fu_MPa):
    """Reuse existing all-direction conservative shear transfer screen per line.
    Two faces share one physical rib thickness. Do not assign tr to each face.
    This screen is sufficient, not a new directional failure interaction.
    """
    if not load_path.get('domain'): return dict(domain=False,reasons=['Invalid load path'],checks=[])
    shear,_=_primitives();g=load_path['geometry'];tr=g['rib_thickness_mm'];tp=g['plate_thickness_mm']
    tf=positive(flange_thickness_mm,'tf')
    materials=[('rib',tr/2,rib_fy_MPa,rib_fu_MPa),('plate',tp/2,plate_fy_MPa,plate_fu_MPa),
               ('flange',tf/2,column_fy_MPa,column_fu_MPa)]
    for _,t,fy,fu in materials: positive(t,'allocated t');positive(fy,'fy');positive(fu,'fu')
    out=dict(domain=True,checks=[],production_credit=False,assembly_approval=False,
        source='NBR8800:2024 6.5.5; existing welded_coverplate_splice._shear / _transfer',
        allocation='Each of two equivalent faces receives half of the common physical thickness',
        sufficient_bound=True,physical_failure_demonstrated=False)
    case={'id':'actual_combination'}
    for joint,receiver in [('foot','plate'),('root','flange')]:
        q=load_path[joint+'_weld_metal']['demand_N_mm']
        for name,t,fy,fu in materials:
            if name in ('rib',receiver):
                shear(out,case,joint+'_'+name+'_per_face',q,1.,t,fy,fu)
    return out

@finite_result
def central_pressure_bands(*,plate_length_mm,plate_width_mm,column_depth_mm,column_flange_width_mm,
                           column_flange_thickness_mm,column_web_thickness_mm,
                           contact_start_x_mm,contact_end_x_mm,pressure_MPa,plate_thickness_mm,plate_fy_MPa):
    """Bellei transverse one-way strips on real web/flange lines.
    Returns only the three interior bands. Exterior rib loads remain separate.
    Contact is actual in x; no pmax enlargement and no fictitious panel reactions.
    """
    L=positive(plate_length_mm,'L');B=positive(plate_width_mm,'B');d=positive(column_depth_mm,'d')
    bf=positive(column_flange_width_mm,'bf');tf=positive(column_flange_thickness_mm,'tf');tw=positive(column_web_thickness_mm,'tw')
    tp=positive(plate_thickness_mm,'tp');fy=positive(plate_fy_MPa,'fy');p=real(pressure_MPa,'p',0)
    x0=real(contact_start_x_mm,'contact x0');x1=real(contact_end_x_mm,'contact x1')
    if not -L/2<=x0<=x1<=L/2 or d>=L or bf>B or tw>=bf or 2*tf>=d: raise ValueError('Physical geometry outside central-strip domain')
    rows=[]
    for label,a,b,support_width in [('left_flange',-d/2,-d/2+tf,bf),('web',-d/2+tf,d/2-tf,tw),('right_flange',d/2-tf,d/2,bf)]:
        lo=max(a,x0);hi=min(b,x1);length=max(0.,hi-lo)
        reach=(B-support_width)/2
        # Pressure directly below support plus two transverse cantilevers.
        V=p*B*length;M=V*(lo+hi)/2 if length else 0.
        m=p*reach**2/2 if length else 0.;stress=6*m/tp**2
        rows.append(dict(name=label,start_x_mm=a,end_x_mm=b,contact_start_x_mm=lo if length else None,
            contact_end_x_mm=hi if length else None,support_width_mm=support_width,tributary_width_mm=B,
            actual_contact_area_mm2=B*length,V_N=V,M_global_Nmm=M,
            direct_bearing_N=p*support_width*length,two_overhang_reaction_N=2*p*reach*length,
            strip_reach_mm=reach,plate_moment_Nmm_per_mm=m,normal_stress_MPa=stress,
            resistance_MPa=fy/1.1,utilization=stress/(fy/1.1),capacity_bound_satisfied=stress<=fy/1.1,
            shear_stress_MPa=1.5*p*reach/tp if length else 0.,shear_resistance_MPa=.6*fy/1.1,
            shear_pass=(1.5*p*reach/tp<=.6*fy/1.1 if length else True),
            load_per_support_length_N_mm=p*B if length else 0.))
    return dict(domain=True,bands=rows,V_N=sum(r['V_N'] for r in rows),M_global_Nmm=sum(r['M_global_Nmm'] for r in rows),
        production_credit=False,assembly_approval=False,
        source='Bellei2006 2.3.5 one-way transverse strips; NBR8800:2024 5.5.2.3(a)',
        assumptions=['Continuous monolithic plate across real web/flange supports',
            'Uniform pressure in transverse y and actual clipped contact in x',
            'No additional two-way support credit or automatic beta table selection'],
        support_joint_demands_required=True)

@finite_result
def central_support_transfer(*,central_bands,plate_thickness_mm,plate_fy_MPa,plate_fu_MPa,
                             column_fy_MPa,column_fu_MPa,foot_throat_mm,fuw_MPa,
                             direct_bearing_guaranteed):
    """Each real web/flange foot receives its own central-band reaction.
    Two equal continuous fillets on the two sides of each physical foot.
    Actual compression bearing may remove normal weld demand only when explicit.
    """
    if type(direct_bearing_guaranteed) is not bool:raise ValueError('Explicit bearing condition required')
    from .verified_welds import fillet_unit_length_resistance
    a=positive(foot_throat_mm,'column foot throat');tp=positive(plate_thickness_mm,'plate t')
    weldRd=fillet_unit_length_resistance(fuw_MPa=fuw_MPa,throat_mm=a,combination_kind='normal').resistance_N_per_mm
    shear,_=_primitives();out=dict(domain=True,reasons=[],checks=[],bands=[],production_credit=False,assembly_approval=False)
    for r in central_bands['bands']:
        t=r['support_width_mm'];q=r['load_per_support_length_N_mm']
        # A flange band has width tf in x and length bf in y. Its actual load
        # is uniform in y after transverse-strip transfer only as a nominal
        # two-line foot transfer; use the loaded contact width in x.
        if r['name']!='web':
            contact=0 if r['contact_start_x_mm'] is None else r['contact_end_x_mm']-r['contact_start_x_mm']
            q=r['V_N']/t if t else 0.
            bearing_width=contact
        else:bearing_width=t
        bearing=q/bearing_width if bearing_width else 0.
        local_moment=0.
        face_loads=(q/2,q/2)
        if r['name']!='web':
            centre=(r['start_x_mm']+r['end_x_mm'])/2
            local_moment=r['M_global_Nmm']-centre*r['V_N']
            separation=r['end_x_mm']-r['start_x_mm']
            face_loads=(q/2-local_moment/(t*separation),q/2+local_moment/(t*separation))
        qface=0. if direct_bearing_guaranteed else max(abs(v) for v in face_loads)
        entry=dict(name=r['name'],V_N=r['V_N'],M_global_Nmm=r['M_global_Nmm'],
            normal_line_N_mm=q,actual_pair_face_loads_N_mm=face_loads,local_moment_Nmm=local_moment,per_face_weld_N_mm=qface,direct_bearing=direct_bearing_guaranteed,
            bearing_stress_MPa=bearing,bearing_resistance_MPa=min(plate_fy_MPa,column_fy_MPa)/1.1,
            capacity_bound_satisfied=(bearing<=min(plate_fy_MPa,column_fy_MPa)/1.1 if direct_bearing_guaranteed else qface<=weldRd),
            weld_resistance_N_mm=weldRd)
        entry['direct_pressure_load_N']=r['direct_bearing_N']
        entry['overhang_edge_reaction_each_N']=r['two_overhang_reaction_N']/2
        entry['overhang_reaction_coordinates_y_mm']=(-r['support_width_mm']/2,r['support_width_mm']/2)
        if direct_bearing_guaranteed:
            entry['stress_interpretation']='Nominal compression of physical support section, not proven uniform contact pressure'
            entry['source']='SCI P2076.8 direct compression bearing; physical support section stress'
        elif r['name']!='web' and r['V_N']:
            # Resultants remain useful, but a full-length uniform weld flow
            # would smear concentrated overhang-edge reactions without source.
            out['domain']=False
            out['reasons'].append(r['name']+': no direct bearing; effective weld load distribution for overhang edge reactions not qualified')
            entry.pop('capacity_bound_satisfied',None)
            entry.pop('per_face_weld_N_mm',None)
            entry['transfer_state']='outside_qualified_weld_distribution'
            entry['pair_line_values_are_resultant_averages_not_design_flows']=True
        out['bands'].append(entry)
        if not direct_bearing_guaranteed and r['name']=='web':
            for label,thick,fy,fu in [('plate',tp,plate_fy_MPa,plate_fu_MPa),('column',bearing_width,column_fy_MPa,column_fu_MPa)]:
                if thick:shear(out,{'id':'central'},r['name']+'_'+label,qface,1.,thick/2,fy,fu)
    out['source']='P2076.8 direct compression bearing; NBR6.2/Table9 and retained6.5.5 primitive'
    return out
