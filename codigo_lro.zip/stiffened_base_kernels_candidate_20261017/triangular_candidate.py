"""Separate, explicitly selected Shakya/Vinnakota compression candidate.

Model: Engineering Journal 45(3),2008, pp187–196, eqs1–19, with 2009 errata
for eq15; design K=0.65, not experimental K=0.5. AISC2005 and NBR8800:2024
5.3.3.1 have the SAME chi(lambda) expressions. This file retains the published
plate model and nominal integral, but uses gamma_a1=1.10, NOT AISC phi=0.90.
That explicit reconciliation does not make this a native NBR triangular-plate
formula, and does not qualify the joints/corner automatically.

The corner hinge O is part of the published resistance mechanism, not a new
physical connection or tie requirement. Joints retain their real V/M demands.
The elastic demand field is not asserted identical to the ultimate mechanism.
No production path calls this file. Reversal/tension/mixed-sign line loads are
outside this compression component and receive no stability credit.
"""
from math import sqrt,pi,log,expm1,erf,hypot
from .kernels import real,positive,finite_result

K_DESIGN=.65
GAMMA_A1=1.10


@finite_result
def triangular_compression_integrals(*,height_a_mm,loaded_edge_b_mm,thickness_mm,fy_MPa,E_MPa=200000.):
    """Analytical published nominal moment integral and its companion force integral.
    Companion Q integral is statics of the SAME Fcr field, not another capacity.
    """
    a=positive(height_a_mm,'a'); b=positive(loaded_edge_b_mm,'b'); t=positive(thickness_mm,'t')
    fy=positive(fy_MPa,'fy'); E=positive(E_MPa,'E')
    D=hypot(a,b); B=a*b/D
    alpha=sqrt(12)*K_DESIGN*(a/b+b/a)/(pi*t)*sqrt(fy/E)
    transition=1.5/alpha; u=min(B,transition); k=-log(.658)*alpha**2
    if k==0: raise ValueError('Outside representable slenderness range')
    i0=sqrt(pi)/(2*sqrt(k))*erf(sqrt(k)*u)
    i1=-expm1(-k*u*u)/(2*k)
    if B>u:
        i0+=.877/(alpha*alpha)*(1/u-1/B)
        i1+=.877/(alpha*alpha)*log(B/u)
    Qn=fy*t*i0; Mn=fy*t*i1
    tstar_over_b=4*K_DESIGN/(sqrt(3)*pi)*sqrt(fy/E)*sqrt(1+(a/b)**2)
    return dict(a_mm=a,b_mm=b,t_mm=t,B_mm=B,alpha_per_mm=alpha,z1_mm=transition,
        Q_nominal_N=Qn,M_nominal_Nmm=Mn,Q_design_field_N=Qn/GAMMA_A1,M_design_Nmm=Mn/GAMMA_A1,
        tstar_over_b_corrected=tstar_over_b,all_strips_inelastic=B<=transition,
        K=K_DESIGN,gamma_a1=GAMMA_A1,production_credit=False,
        source='Shakya/Vinnakota2008 eq18 + errata2009 eq15; chi=NBR8800:2024 5.3.3.1, normal combinations')


@finite_result
def inscribed_triangular_candidate(*,model_selected,actual_top_profile_mm,core_a_mm,core_b_mm,
        thickness_mm,fy_MPa,line_load_cells,short_edge_support_condition):
    """Core option without changing the actual polygon; no double resistance credit.
    Only nonnegative compressive line loads entirely inside the selected core.
    The explicit two-short-edge support condition is the published domain.
    No invented corner tie or equality of elastic/ultimate fields is required.
    """
    a=positive(core_a_mm,'core a'); b=positive(core_b_mm,'core b')
    top=tuple(tuple(v) for v in actual_top_profile_mm)
    reasons=[]
    if model_selected!='triangular_inscribed_strips': reasons.append('Explicit selection of this published core model required')
    if short_edge_support_condition!='both_short_edges_rigidly_supported': reasons.append('Published two-short-edge support condition not established')
    if len(top)<2: raise ValueError('Actual outline required')
    for x,h in top: real(x,'outline x',0); real(h,'outline height',0)
    if top[0][0]!=0 or any(y[0]<=x[0] for x,y in zip(top,top[1:])): raise ValueError('Invalid actual top outline')
    if b>top[-1][0] or a>top[0][1]: reasons.append('Selected triangle outside actual plate')
    for x,h in top:
        if x<=b and h<a*(1-x/b): reasons.append('Selected triangle exceeds actual top boundary')
    cells=tuple(line_load_cells); P=M=0.
    for c in cells:
        lo=real(c['start_mm'],'start',0); hi=real(c['end_mm'],'end',0); w=real(c['rib_line_N_mm'],'line load')
        if hi<=lo: raise ValueError('Invalid line-load interval')
        if w<0: reasons.append('Tension or mixed-sign loading outside compression strip model')
        if w and hi>b: reasons.append('Real load lies outside selected core; no load may be omitted')
        P+=w*(hi-lo); M+=w*(hi*hi-lo*lo)/2
    for i,c in enumerate(cells):
        if any(min(c['end_mm'],d['end_mm'])>max(c['start_mm'],d['start_mm']) for d in cells[:i]): raise ValueError('Overlapping line-load cells')
    out=dict(component_domain=not reasons,reasons=reasons,production_credit=False,assembly_approval=False,
        support_condition=short_edge_support_condition,actual_geometry_unchanged=True,
        ignored_extra_material_credit=0.,pending=['joint/base-metal resistance under actual V/M demands',
            'independent complete-topology benchmark and user selection before runtime'])
    if reasons: return out
    cap=triangular_compression_integrals(height_a_mm=a,loaded_edge_b_mm=b,thickness_mm=thickness_mm,fy_MPa=fy_MPa)
    eta=M/cap['M_design_Nmm']
    out.update(capacity=cap,P_compression_N=P,M_about_O_Nmm=M,application_s_mm=M/P if P else None,
        utilization_M=eta,capacity_bound_satisfied=eta<=1,
        model_source='Shakya/Vinnakota2008 Eq18 + 2009 errata; design K=.65',
        resistance_source='NBR8800:2024 5.3.3.1 matching chi curve, gamma_a1=1.10',
        demand_and_resistance_fields_identical=False,physical_corner_tie_required_by_source=False,
        branch='compression_inscribed_triangle_nominal_stability')
    return out


@finite_result
def composed_triangular_stability(*,load_path,model_selected,short_edge_support_condition,rib_fy_MPa):
    """Explicit optional resistance component, never an automatic geometry switch.
    Uses the inscribed triangle with the SAME root and foot dimensions. All
    real cell loads are retained exclusively; extra material gives no credit.
    """
    if not load_path.get('domain'):
        return dict(component_domain=False,reasons=['Load path outside geometry domain'],production_credit=False)
    g=load_path['geometry']; a=g['rib_height_mm']; b=g['rib_length_mm']
    if g['root_weld_start_height_mm']!=0 or g['root_weld_end_height_mm']!=a:
        return dict(component_domain=False,reasons=['Actual root support does not cover the selected triangle edge'],production_credit=False)
    if g['foot_effective_start_mm']!=0 or g['foot_effective_end_mm']!=b:
        return dict(component_domain=False,reasons=['Actual foot support does not cover the selected triangle edge'],production_credit=False)
    result=inscribed_triangular_candidate(model_selected=model_selected,actual_top_profile_mm=g['rib_top_profile_mm'],
        core_a_mm=a,core_b_mm=b,thickness_mm=g['rib_thickness_mm'],fy_MPa=rib_fy_MPa,
        line_load_cells=load_path['cells'],short_edge_support_condition=short_edge_support_condition)
    result['actual_root_actions']=load_path['root_actions']
    result['joints_use_actual_elastic_V_M']=True
    return result
