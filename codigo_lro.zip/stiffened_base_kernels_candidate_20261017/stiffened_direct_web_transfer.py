"""Versioned N/M/V web-transfer supplement; old N/M consumers are unchanged.

All external V is assigned to the physical column-web foot weld. Exterior ribs
receive no lateral resistance credit. This module does NOT qualify the plate's
in-plane path from the holes, anchorage, service slip or the complete assembly.

Sources: AISC DG1 3rd p.90, SCI P398 E.1 p.150 (web weld carries V);
NBR 8800:2024 Table 9, Table 11, 5.4.5, 6.5.3/6.5.5 (retained primitives);
classical Jourawski q=VQ/I for the rectangular I-section; JRC96658 pp.36–37,
Eq.(1.23), EN1993-1-1 6.2.1(5), for the supplementary elastic yield screen.
"""
from math import sqrt, hypot
from types import SimpleNamespace
from .kernels import real, positive, finite_result
from .receiver import paired_column_receiver
from .verified_welds import fillet_unit_length_resistance
from .verified_local_helpers import flange_web_weld_stress_bounds
from .completion_components import _primitives

VERSION = 'stiffened_direct_web_transfer_v1_20261017'
SOURCES = {
    'web_path': 'AISC DG1 3rd p.90; SCI P398 Example E.1 p.150: web weld for full design shear',
    'weld': 'NBR8800:2024 + Er1:2025 Table9/Table11; physical two-sided web-foot T joint',
    'internal_flow': 'Classical Jourawski q=VQ/I; NBR8800:2024 5.4.5; rectangular I-section without fillet-area credit',
    'elastic_screen': 'JRC96658 pp.36–37 Eq1.23, EN1993-1-1:2005 6.2.1(5); supplementary elastic screen, gammaM0=1.10 explicitly selected',
}


def _check(name, demand, resistance, source, **extra):
    demand = real(demand, name + ' demand', 0.)
    resistance = positive(resistance, name + ' resistance')
    return dict(name=name, demand=demand, resistance=resistance,
                utilization=demand/resistance, capacity_bound_satisfied=demand<=resistance,
                source=source, sufficient_bound=True, physical_failure_demonstrated=False, **extra)


def _elastic_screen(name, sigma, tau, fy):
    # A conservative same-point stress envelope, not a new NBR interaction.
    return _check(name, hypot(sigma, sqrt(3.)*tau), fy/1.10,
                  SOURCES['elastic_screen'], sigma_bound_MPa=abs(sigma),
                  tau_bound_MPa=abs(tau), gamma_M0=1.10,
                  interaction_basis='supplementary_EN_elastic_not_NBR_factor_mixing')


@finite_result
def compose_direct_web_transfer(*, nm_result, V_N, geometry, materials, connections,
                                web_shear_flow_model='uniform'):
    """Return all calculated web-foot/internal-interface checks, not plate approval.

    ``nm_result`` must represent the SAME physical input and concurrent N/M.
    ``V_N`` is signed global shear at the already-selected assembly reference;
    this function never changes N or M or chooses a bolt-bearing elevation.
    Only the DG1 published uniform nominal web-weld flow is accepted.
    No derived plate-field distribution is accepted by this consumer.
    """
    V = real(V_N, 'global V')
    if web_shear_flow_model != 'uniform':
        raise ValueError('Unknown physical web shear-flow model')
    if not isinstance(nm_result, dict):
        raise ValueError('Explicit N/M component result required')
    g, m, co = geometry, materials, connections
    inputs = nm_result.get('physical_inputs', {})
    for key, data in (('geometry', g), ('materials', m), ('connections', co)):
        if inputs.get(key) != data:
            raise ValueError('N/M result has different actual ' + key)
    if inputs.get('loads', {}).get('V_N') != 0:
        raise ValueError('Source result must be the retained zero-shear N/M projection, not an unknown N/M/V result')
    sides = nm_result.get('sides', [])
    if len(sides) != 2 or {s.get('side') for s in sides} != {-1, 1}:
        raise ValueError('Two identified physical rib sides required')
    paths = {s['side']: s.get('load_path', {}) for s in sides}
    reasons = []
    if not all(p.get('domain') is True for p in paths.values()):
        reasons.append('Both concurrent N/M rib paths must be in their qualified domain')
    if nm_result.get('central_supports', {}).get('domain') is not True:
        reasons.append('Concurrent central support transfer is outside its domain')
    if nm_result.get('receiver', {}).get('domain') is not True:
        reasons.append('Concurrent column receiver is outside its domain')
    out = dict(method_version=VERSION, domain=not reasons, reasons=reasons, checks=[],
               production_credit=False, assembly_approval=False, sources=SOURCES,
               V_input_N=V, rib_lateral_credit_N=0.,
               actions_reference='Unchanged from caller; no bearing-plane or lever-arm assumption made here',
               plate_inplane_transfer_verified=False,
               excluded_scope=['Plate in-plane path/net/block and combined plate flexure',
                               'Anchor/concrete states, washers and service-slip qualification',
                               'Global column stability and reinforced foundation/soil'])
    if reasons:
        return out
    d = positive(g['column_depth_mm'], 'column d')
    bf = positive(g['column_flange_width_mm'], 'column bf')
    tf = positive(g['column_flange_thickness_mm'], 'column tf')
    tw = positive(g['column_web_thickness_mm'], 'column tw')
    tp = positive(g['plate_thickness_mm'], 'plate tp')
    B = positive(g['plate_width_mm'], 'plate B')
    fy, fu = positive(m['column_fy_MPa'], 'column fy'), positive(m['column_fu_MPa'], 'column fu')
    p_fy, p_fu = positive(m['plate_fy_MPa'], 'plate fy'), positive(m['plate_fu_MPa'], 'plate fu')
    if fy>fu or p_fy>p_fu:
        raise ValueError('Actual yield strength cannot exceed ultimate strength')
    fabrication = co['column_fabrication']
    if fabrication not in ('welded', 'rolled'):
        raise ValueError('Identify welded or rolled column')
    radius = positive(co['column_root_radius_mm'], 'actual rolled radius') if fabrication=='rolled' else 0.
    if fabrication=='welded' and co.get('column_root_radius_mm') not in (0, 0., None):
        raise ValueError('No rolled radius credit for a welded column')
    hw = d - 2*tf - 2*radius
    if hw<=0 or tw>=bf or B<bf:
        raise ValueError('Actual I-section/plate geometry invalid')
    leg = positive(co['column_base_leg_mm'], 'actual web-foot leg')
    throat = leg/sqrt(2.)
    fw = positive(co['column_base_fuw_MPa'], 'actual foot electrode strength')
    # Longitudinal bearing-weld reduction follows the existing qualified base
    # web-weld route. It is not a fictitious increase in physical weld length.
    beta = min(1., max(.6, 1.2-.002*hw/leg))
    Leff = 180*leg if hw>300*leg else beta*hw
    peak = 1.
    qV_actual = abs(V)*peak/(2*hw)
    qV_design = abs(V)*peak/(2*Leff)
    minimum = 3. if min(tw,tp)<=6.3 else 5. if min(tw,tp)<=12.5 else 6. if min(tw,tp)<=19 else 8.
    shelf = (min(bf,B)-tw)/2
    checks = out['checks']
    checks += [
        _check('web_foot_minimum_leg', minimum, leg, SOURCES['weld'], unit='mm'),
        _check('web_foot_minimum_effective_length', max(40.,4*leg), Leff, SOURCES['weld'], unit='mm'),
        _check('web_foot_available_shelf', leg, shelf, SOURCES['weld'], unit='mm'),
        _check('web_foot_material_matching', max(fu,p_fu), fw, SOURCES['weld'], unit='MPa'),
    ]
    webbands = [b for b in nm_result['central_supports'].get('bands',[]) if b.get('name')=='web']
    if len(webbands)!=1:
        raise ValueError('Exactly one physical central web band required')
    band = webbands[0]
    if type(co.get('column_direct_bearing')) is not bool:
        raise ValueError('Explicit column direct bearing condition required')
    qN_actual = 0. if co['column_direct_bearing'] else abs(band['per_face_weld_N_mm'])
    qN_design = qN_actual*hw/Leff
    weld_rd = fillet_unit_length_resistance(fuw_MPa=fw, throat_mm=throat,
                                           combination_kind='normal').resistance_N_per_mm
    checks.append(_check('web_foot_concurrent_weld', hypot(qV_design,qN_design), weld_rd,
                         SOURCES['weld'], unit='N/mm', shear_bound_N_per_mm=qV_design,
                         normal_bound_N_per_mm=qN_design))
    # Both physical pieces are single pieces, not doubled by two fillets.
    # Half the common thickness is assigned to each equivalent weld face.
    shear,_ = _primitives()
    for name,t,fy_,fu_ in (('column_web',tw,fy,fu),('receiving_plate',tp,p_fy,p_fu)):
        shear(out, {'id':'concurrent_NMV'}, name+'_foot_transfer_per_face',
              hypot(qV_design,qN_design), 1., t/2, fy_,fu_)
        vertical = abs(band.get('normal_line_N_mm',0.))/t
        sigma = vertical if name=='column_web' else 0.
        tau = 2*qV_design/t if name=='column_web' else hypot(vertical,2*qV_design/t)
        checks.append(_elastic_screen(name+'_foot_concurrent_elastic_screen',sigma,tau,fy_))
    out['web_foot'] = dict(physical_length_mm=hw,effective_length_mm=Leff,
        actual_leg_mm=leg,actual_throat_mm=throat,number_of_faces=2,
        flow_model=web_shear_flow_model,peak_to_mean=peak,
        shear_flow_peak_per_face_actual_N_mm=qV_actual,
        shear_flow_peak_per_face_design_N_mm=qV_design,
        concurrent_normal_flow_peak_per_face_N_mm=qN_design,
        compression_bearing_does_not_relieve_horizontal_shear=True,
        recovered_shear_N=V,residual_shear_N=0.,source=SOURCES['web_path'])
    Ag = 2*bf*tf+(d-2*tf)*tw
    receiver = paired_column_receiver(left_load_path=paths[-1],right_load_path=paths[1],
        column_flange_thickness_mm=tf,column_web_thickness_mm=tw,column_gross_area_mm2=Ag,
        column_fy_MPa=fy,column_fu_MPa=fu,column_fabrication=fabrication,
        column_panel_shear_at_bottom_N=V,
        column_axial_compression_envelope_N=max(inputs['loads']['N_N'],0.),
        column_flange_lateral_length_mm=co['column_flange_lateral_length_mm'],
        root_weld_leg_mm=co['rib_root_throat_mm']*sqrt(2),
        column_root_radius_mm=co['column_root_radius_mm'])
    out['receiver'] = receiver
    if not receiver.get('domain'):
        out['domain']=False;out['reasons'].extend(receiver.get('reasons',[]));return out
    # Actual rectangular web height retained for geometric I; no rolled fillet
    # area is credited. Q is the first moment of ONE flange, not both flanges.
    hrect=d-2*tf
    I = 2*(bf*tf**3/12 + bf*tf*((d-tf)/2)**2) + tw*hrect**3/12
    Q = bf*tf*(d-tf)/2
    q_classical = abs(V)*Q/I
    # For a rolled section, do not claim that omitted root-fillet material
    # leaves the stress demand conservative. The exact geometric Q/I is not
    # known here. A symmetric section with a clear rectangular web satisfies
    # Q/I <= 1.5/hw: the web term has this ratio and each symmetric material
    # pair outside the clear web has Q/I <= 1/hw. Use that sufficient bound.
    q_global = q_classical if fabrication=='welded' else 1.5*abs(V)/hw
    h=receiver['root_effective_height_mm']
    connected=positive(co['internal_connected_height_mm'],'internal connected height')
    if connected<h:
        out['domain']=False;out['reasons'].append('Internal joint does not cover real rib-root transfer height')
    if fabrication=='welded' and co.get('internal_continuous_two_faces') is not True:
        out['domain']=False;out['reasons'].append('Two real continuous internal fillets required')
    internal=dict(domain=out['domain'],reasons=list(out['reasons']),interfaces=[],checks=[],
        production_credit=False,assembly_approval=False,
        I_column_rectangular_mm4=I,Q_one_flange_mm3=Q,
        global_longitudinal_flow_bound_N_mm=q_global,nominal_rectangular_flange_flow_N_mm=q_classical,
        global_flow_basis=('exact_rectangular_flange_Q_over_I' if fabrication=='welded'
                           else 'conservative_symmetric_section_Jourawski_bound_1.5V_over_clear_web'),
        source=SOURCES['internal_flow'],
        combination='Triangle-inequality bound on concurrent root and global-shear flows; no cancellation credit')
    if internal['domain']:
        for r in receiver['roots']:
            qn=6*abs(r['M_inner_face_Nmm'])/h**2
            qs_nm=abs(r['V_root_N'])/h
            qs=qs_nm+q_global
            entry=dict(side=r['side'],normal_line_bound_N_mm=qn,
                NM_parallel_line_bound_N_mm=qs_nm,global_parallel_line_bound_N_mm=q_global,
                combined_parallel_line_bound_N_mm=qs)
            for name,t in (('web',tw),('flange',tf)):
                # Separate same-plane metal checks plus supplementary concurrent
                # elastic check. No duplicated physical thickness.
                shear(internal,{'id':'concurrent_NMV'},'interface_'+str(r['side'])+'_'+name,
                      hypot(qn,qs),1.,t,fy,fu)
                internal['checks'].append(_elastic_screen('interface_'+str(r['side'])+'_'+name+'_elastic',qn/t,qs/t,fy))
            if fabrication=='welded':
                a=positive(co['internal_throat_mm'],'internal actual throat')
                fwi=positive(co['internal_fuw_MPa'],'internal actual electrode strength')
                internal_leg=a*sqrt(2.)
                imin=3. if min(tw,tf)<=6.3 else 5. if min(tw,tf)<=12.5 else 6. if min(tw,tf)<=19 else 8.
                internal['checks'] += [
                    _check('internal_minimum_leg_'+str(r['side']),imin,internal_leg,SOURCES['weld'],unit='mm'),
                    _check('internal_minimum_length_'+str(r['side']),max(40.,4*internal_leg),h,SOURCES['weld'],unit='mm'),
                    _check('internal_available_shelf_'+str(r['side']),internal_leg,(bf-tw)/2,SOURCES['weld'],unit='mm'),
                ]
                stress=flange_web_weld_stress_bounds(SimpleNamespace(section=SimpleNamespace(tw_mm=tw)),
                    throat_mm=a,transverse_normal_bound_mpa=qn/tw,shear_transfer_bound_mpa=qs/tw)
                entry['weld']=dict(stress,**_check('internal_weld_'+str(r['side']),
                    stress['traction_resultant_bound_mpa'],.6*fwi/1.35,SOURCES['weld'],unit='MPa'))
                internal['checks'].append(_check('internal_material_matching_'+str(r['side']),fu,fwi,SOURCES['weld'],unit='MPa'))
            else:
                entry['weld']=dict(state='not_applicable_integral_rolled_section',fictitious_weld_created=False)
            internal['interfaces'].append(entry)
    out['internal_transfer']=internal
    out['execution_requirements'] = [
        'Two continuous equal-leg web-foot fillets over the stated straight physical length',
        'Actual electrodes, weld procedure, full attachment and quality inspection',
        'No unreported web copes, holes, gaps or interruptions in the calculated transfer regions',
    ]
    out['fabrication_verified'] = False
    out['web_transfer_calculated']=out['domain'] and receiver.get('domain') and internal['domain']
    return out
