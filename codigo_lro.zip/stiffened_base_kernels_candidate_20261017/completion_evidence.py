import json
from pathlib import Path
from .complete_fixture import fixture
from .full_composer import compose_complete_selected_domain
from .report_adapter import export_mc_text
from .make_evidence import run

def main():
    here=Path(__file__).resolve().parent
    results={str(sign):compose_complete_selected_domain(**fixture(sign*120e6)) for sign in (1,-1)}
    original=fixture();original['geometry'].update(rib_height_mm=300,rib_top_profile_mm=[(0,300),(20,300),(186.4,20)])
    results['original_short_height']=compose_complete_selected_domain(**original)
    (here/'COMPLETION_RESULTS.json').write_text(json.dumps(results,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
    (here/'MC_COMPLETE_SELECTED.txt').write_text(export_mc_text(results['1']))
    (here/'MC_SHORT_HEIGHT_OUTSIDE_BRANCH.txt').write_text(export_mc_text(results['original_short_height']))
    run()
if __name__=='__main__':main()
