"""Reuse retained anchorage routines with explicit physical rods, not legacy a1.
Normalweight cracked cast-in concrete, static N/M and zero rod shear first.
"""
import sys,math
from pathlib import Path
from .kernels import positive,real,finite_result

@finite_result
def anchorage_zero_shear(*,rods,block_bounds_mm,embedment_mm,concrete_fck_MPa,
                        rod_diameter_mm,rod_fy_MPa,rod_fu_MPa,thread_stress_area_mm2,
                        bearing_area_mm2,headed_detail,physical_detail,
                        rod_material,ductile=False,ductility_reference=''):
    from lro.concrete_anchorage import breakout_group
    from lro.concrete_headed import evaluate_headed
    from lro.concrete_shear import aci_steel,interaction
    db=positive(rod_diameter_mm,'db');As=positive(thread_stress_area_mm2,'As')
    fy=positive(rod_fy_MPa,'fy');fu=positive(rod_fu_MPa,'fu');h=positive(embedment_mm,'hef');fc=positive(concrete_fck_MPa,'fck')
    if As>math.pi*db*db/4 or fy>fu: raise ValueError('Inconsistent physical rod area or material')
    if not isinstance(rods,(tuple,list)) or not 1<=len(rods)<=4: raise ValueError('One to four actual rods required')
    if len({r['id'] for r in rods})!=len(rods): raise ValueError('Duplicate rod identifier')
    for r in rods:
        real(r['x'],'x');real(r['y'],'y');real(r['tension'],'T',0)
        if real(r.get('shear',0),'rod shear')!=0: raise ValueError('This adapter does not silently remove rod shear')
    required=('cast_in','normalweight','cracked','static','intact_prism','no_sleeves_or_voids','splitting_detail_satisfied')
    reasons=[f'Physical input {k}=True required' for k in required if physical_detail.get(k) is not True]
    if fc>10000*.006894757293168361: reasons.append('Concrete above retained ACI cast-in strength domain')
    out=dict(domain=not reasons,reasons=reasons,production_credit=False,assembly_approval=False,rods=rods,
             source='Retained concrete_anchorage/concrete_headed/concrete_shear, ACI318-19 + DG1; NBR steel separate')
    if reasons:return out
    active=[r for r in rods if r['tension']>0]
    groups=[]
    def calculate_group(group):
        g=breakout_group(group,block_bounds_mm,h,fc)
        if g['connected']:groups.append(g)
        else:
            for indices in g['components']:calculate_group([group[i] for i in indices])
    if active:calculate_group(active)
    headed=evaluate_headed(rods,block_bounds_mm,h,fc,positive(bearing_area_mm2,'head area'),headed_detail)
    aci=[aci_steel(tension=r['tension'],shear=0,area_tension=As,area_shear=None,fy=fy,fu=fu,
        ductile=ductile,ductility_ref=ductility_reference,id=r['id']) for r in rods]
    nbr=[]
    if rod_material=='ASTM A36':
        # Existing BasePlate.anchor_steel_rd, without importing its geometry.
        rd=.75*math.pi*db*db/4*400/1.35
        nbr=[dict(id=r['id'],demand_N=r['tension'],resistance_N=rd,utilization=r['tension']/rd,
            capacity_bound_satisfied=r['tension']<=rd,source='NBR8800:2024 6.7.2.2, existing A36 rod steel') for r in rods]
    elif rod_material not in ('ASTM F1554 Grade 36','ASTM F1554 Grade 55','ASTM F1554 Grade 105'):
        raise ValueError('Material outside declared A36/F1554 anchorage adapter')
    tensionchecks=[dict(g,id='cone_'+str(i),ratio=g['ratio']) for i,g in enumerate(groups)]
    tensionchecks += [c for a in aci for c in a['checks']]
    for mode in ('pullout','sideface'):tensionchecks+=headed.get(mode,{}).get('checks',[])
    tensionchecks+=headed.get('prerequisites',{}).get('mechanical',{}).get('checks',[])
    pending=[]
    if active:
        for name in ('pullout','sideface'):
            if headed.get(name,{}).get('status') not in ('calculated','not_applicable','not_demanded'):
                pending.extend(headed.get(name,{}).get('reasons',[name+' not covered']))
        if headed.get('prerequisites',{}).get('status') not in ('verified','failed'):
            pending.append('Head/nut/plate mechanical or physical prerequisites incomplete')
    out.update(cone=dict(status='calculated' if active else 'not_demanded',groups=groups),headed=headed,
        aci_rod_steel=aci,nbr_A36_rod_steel=nbr,
        shear_breakout=dict(status='not_demanded',reason='Actual rod shear is zero'),
        pryout=dict(status='not_demanded',reason='Actual rod shear is zero'),
        interaction=interaction(tensionchecks,[],complete=not pending,pending_reasons=pending),
        pending=pending,selected_anchor_modes_complete=not pending,
        excluded_scope=['Reinforced foundation design and soil bearing, not part of this connection component'])
    return out
