"""Separate elastic stress limits, ABNT NBR8800:2024 5.5.2.3(a,b).

Normal combinations only: gamma_a1=1.10. This is not a substitute for clauses
(c,d) instability. It does not invent a von-Mises interaction as a NBR rule.
Section stress limits and member-stability states remain different objects.
"""
from .kernels import real,positive,finite_result

GAMMA_A1_NORMAL=1.10
SOURCE='ABNT NBR 8800:2024 corrigida 2025, 5.5.2.3(a,b), p63/PDF85; normal combinations'


@finite_result
def elastic_stress_limits(*, sigma_MPa,tau_MPa,fy_MPa,combination_kind='normal'):
    if combination_kind!='normal': raise ValueError('This isolated stress verifier covers normal combinations only')
    sigma=real(sigma_MPa,'sigma'); tau=real(tau_MPa,'tau'); fy=positive(fy_MPa,'fy')
    sn=fy/GAMMA_A1_NORMAL; sv=.6*fy/GAMMA_A1_NORMAL
    return dict(sigma_demand_MPa=abs(sigma),tau_demand_MPa=abs(tau),sigma_resistance_MPa=sn,tau_resistance_MPa=sv,
                normal_utilization=abs(sigma)/sn,shear_utilization=abs(tau)/sv,
                normal_pass=abs(sigma)<=sn,shear_pass=abs(tau)<=sv,
                instability_verified=False,production_credit=False,source=SOURCE)


@finite_result
def check_composed_elastic_stresses(*, load_path,plate_thickness_mm,plate_fy_MPa,rib_fy_MPa):
    """Apply explicit limits to exact candidate demands; no assembly approval."""
    tp=positive(plate_thickness_mm,'tp')
    if load_path.get('domain') and tp!=load_path['geometry']['plate_thickness_mm']: raise ValueError('Thickness differs from composed geometry')
    if not load_path.get('domain'): return dict(scope='outside_load_path_domain',production_credit=False,assembly_approval=False)
    plate=elastic_stress_limits(sigma_MPa=6*load_path['maximum_plate_bending_Nmm_per_mm']/tp**2,tau_MPa=0,fy_MPa=plate_fy_MPa)
    sections=[dict(s_mm=s['s_mm'],checks=elastic_stress_limits(sigma_MPa=s['sigma_bending_extreme_MPa'],
                  tau_MPa=s['tau_shear_max_MPa'],fy_MPa=rib_fy_MPa)) for s in load_path['sections']]
    local=elastic_stress_limits(sigma_MPa=load_path['maximum_local_rib_normal_MPa'],tau_MPa=0,fy_MPa=rib_fy_MPa)
    return dict(plate_flexure_elastic=plate,rib_sections=sections,rib_local_normal=local,
                production_credit=False,assembly_approval=False,
                plate_shear_and_local_holes_verified=False,
                member_stability=dict(state='pending',reason='NBR 5.5.2.3(c,d): actual out-of-plane mode/restraint/load-height required; no 3D solver presumption'))
