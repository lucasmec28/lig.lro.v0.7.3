"""Isolated fillet-weld detail and scalar helpers; units N, mm and MPa.

This is not a weld-group, load-path, base-metal, fatigue or station check.
The geometric domain is equal-leg orthogonal fillets of uniform size, with
no submerged-arc throat enhancement, reinforced-edge exception or hole/slot
fillets. A physical length includes only actual admissible weld and returns;
this scalar module cannot establish continuity, terminations or fabrication.
Physical deposited weld mass belongs to geometry.py, never to Leff here.

Sources: ABNT NBR 8800:2024 sections 6.2.2.2, 6.2.5.1/Table 9,
6.2.6.2/Table 11 and 6.1.5.2, as constrained by the isolated first-domain
contract SHEAR_PANEL_FIRST_DOMAIN_2026-10-17.md, section 4.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, field
from decimal import Decimal
from math import copysign, hypot, isclose, isfinite, sqrt
from numbers import Real
from typing import Literal


WeldRole = Literal["ordinary_panel", "longitudinal_bearing"]
CombinationKind = Literal["normal", "special", "construction", "exceptional"]

GEOMETRY_SOURCE = (
    "ABNT NBR 8800:2024, 6.2.2.2, p. 75 (source PDF p. 97), and "
    "6.2.6.2.1-6.2.6.2.3, Table 11, pp. 80-81 (source PDF pp. 102-103); "
    "isolated first-domain contract 2026-10-17, section 4"
)
CAPACITY_SOURCE = (
    "ABNT NBR 8800:2024, 6.2.5.1, Table 9 and notes d/i, p. 78 "
    "(source PDF p. 100)"
)
MINIMUM_FORCE_SOURCE = (
    "ABNT NBR 8800:2024, 6.1.5.2, p. 70 (source PDF p. 92); "
    "actual nonzero connection force only, with existing direction and sense"
)


def _real(value: object, name: str, *, positive: bool = False) -> float:
    """Do not coerce booleans, text, complex numbers or missing inputs."""
    if isinstance(value, bool) or not isinstance(value, (Real, Decimal)):
        raise TypeError(f"{name} must be a real number, not {type(value).__name__}")
    try:
        result = float(value)
    except (OverflowError, ValueError) as exc:
        raise ValueError(f"{name} must be finite and representable") from exc
    if not isfinite(result) or positive and result <= 0.0:
        requirement = "finite and strictly positive" if positive else "finite"
        raise ValueError(f"{name} must be {requirement}")
    return result


def _derived_positive(value: float, name: str) -> float:
    if not isfinite(value) or value <= 0.0:
        raise ValueError(f"{name} is outside the finite positive numeric domain")
    return value


@dataclass(frozen=True)
class FilletGeometryResult:
    """Independent detail checks, not a prescribed connection approval."""

    connected_thickness_1_mm: float
    connected_thickness_2_mm: float
    edge_thickness_mm: float
    lesser_connected_thickness_mm: float
    leg_mm: float
    physical_length_mm: float
    role: WeldRole
    minimum_leg_mm: float
    maximum_edge_leg_mm: float
    minimum_leg_pass: bool
    maximum_edge_leg_pass: bool
    throat_mm: float
    beta: float | None
    long_weld_branch: str
    effective_length_mm: float
    effective_length_factor: float
    minimum_effective_length_mm: float
    effective_length_pass: bool
    detail_geometry_pass: bool
    single_pass_execution_required: bool = field(default=True, init=False)
    fabrication_verified: bool = field(default=False, init=False)
    station_scope_evaluated: bool = field(default=False, init=False)
    production_credit: bool = field(default=False, init=False)
    source: str = field(default=GEOMETRY_SOURCE, init=False)
    scope: str = field(
        default=(
            "Equal-leg orthogonal fillet size and effective length only. "
            "No continuity/attachment, static transfer, base-metal, fatigue "
            "or complete-station conclusion. Table 11 execution is a design "
            "requirement, not confirmation of fabrication."
        ),
        init=False,
    )


def evaluate_fillet_geometry(
    *,
    connected_thickness_1_mm: float,
    connected_thickness_2_mm: float,
    edge_thickness_mm: float,
    leg_mm: float,
    physical_length_mm: float,
    role: WeldRole,
) -> FilletGeometryResult:
    """Evaluate separate minimum-leg, edge maximum and length limitations.

    Table 11 uses the LESSER thickness of the two connected pieces. The
    maximum leg uses the explicitly identified piece whose edge receives
    the weld; its thickness must match one of those two pieces. Numeric
    inputs must be finite and positive. A well-formed but noncompliant
    detail returns false check(s), rather than silently resizing a weld.

    ``ordinary_panel`` has Leff=Lw and beta=None: the bearing reduction is
    not applied merely because a panel weld is long. ``longitudinal_bearing``
    identifies the nonuniform longitudinal bearing/localized-force domain:
    beta=clamp(1.2-0.002 Lw/leg, 0.6, 1); if Lw>300leg, Leff=180leg.
    In that last branch beta remains the clamped formula coefficient 0.6,
    while effective_length_factor records the distinct actual Leff/Lw.
    The upper clamp ceases at 100leg, not at 150leg. No tolerance moves a
    branch or a dimension limit. Leff >= max(40 mm, 4leg) is the deliberately
    restricted first-domain rule, not a claim to cover every source option.
    """
    t1 = _real(connected_thickness_1_mm, "connected_thickness_1_mm", positive=True)
    t2 = _real(connected_thickness_2_mm, "connected_thickness_2_mm", positive=True)
    edge = _real(edge_thickness_mm, "edge_thickness_mm", positive=True)
    leg = _real(leg_mm, "leg_mm", positive=True)
    length = _real(physical_length_mm, "physical_length_mm", positive=True)
    if not isinstance(role, str) or role not in ("ordinary_panel", "longitudinal_bearing"):
        raise ValueError("role must explicitly be ordinary_panel or longitudinal_bearing")
    if edge not in (t1, t2):
        raise ValueError("edge_thickness_mm must identify one of the two connected pieces")

    lesser = min(t1, t2)
    minimum = (3.0 if lesser <= 6.3 else 5.0 if lesser <= 12.5
               else 6.0 if lesser <= 19.0 else 8.0)
    maximum = edge if edge < 6.3 else edge - 1.5
    throat = _derived_positive(leg / sqrt(2.0), "throat_mm")

    beta = None
    branch = "ordinary_physical_length"
    effective = length
    if role == "longitudinal_bearing":
        limit = _derived_positive(300.0 * leg, "300leg")
        if length > limit:
            beta = 0.6
            branch = "fixed_180_leg"
            effective = _derived_positive(180.0 * leg, "180leg")
        else:
            ratio = _derived_positive(length / leg, "Lw/leg")
            beta = min(1.0, max(0.6, 1.2 - 0.002 * ratio))
            branch = "beta_clamped_unity" if length <= 100.0 * leg else "beta_formula"
            effective = _derived_positive(beta * length, "effective_length_mm")
    factor = _derived_positive(effective / length, "effective_length_factor")
    minimum_length = max(40.0, _derived_positive(4.0 * leg, "4leg"))
    minimum_pass = leg >= minimum
    maximum_pass = leg <= maximum
    length_pass = effective >= minimum_length
    return FilletGeometryResult(
        connected_thickness_1_mm=t1,
        connected_thickness_2_mm=t2,
        edge_thickness_mm=edge,
        lesser_connected_thickness_mm=lesser,
        leg_mm=leg,
        physical_length_mm=length,
        role=role,
        minimum_leg_mm=minimum,
        maximum_edge_leg_mm=maximum,
        minimum_leg_pass=minimum_pass,
        maximum_edge_leg_pass=maximum_pass,
        throat_mm=throat,
        beta=beta,
        long_weld_branch=branch,
        effective_length_mm=effective,
        effective_length_factor=factor,
        minimum_effective_length_mm=minimum_length,
        effective_length_pass=length_pass,
        detail_geometry_pass=minimum_pass and maximum_pass and length_pass,
    )


@dataclass(frozen=True)
class FilletUnitLengthResistance:
    fuw_MPa: float
    throat_mm: float
    combination_kind: CombinationKind
    gamma_w2: float
    resistance_N_per_mm: float
    station_scope_evaluated: bool = field(default=False, init=False)
    production_credit: bool = field(default=False, init=False)
    source: str = field(default=CAPACITY_SOURCE, init=False)
    scope: str = field(
        default=(
            "Ordinary Table 9 weld-metal resistance per effective unit length "
            "only. No applied demand, direction enhancement, weld-group "
            "equilibrium, base-metal capacity or static-transfer completion."
        ),
        init=False,
    )


def fillet_unit_length_resistance(
    *, fuw_MPa: float, throat_mm: float, combination_kind: CombinationKind
) -> FilletUnitLengthResistance:
    """Return 0.60*fuw*throat/gamma_w2, without inferring any force demand.

    Resistance is per EFFECTIVE unit length, not per physical unit length
    after a long-weld reduction. Material compatibility, prescribed geometry
    and resistance of the actual connected base metals require other checks.
    """
    fuw = _real(fuw_MPa, "fuw_MPa", positive=True)
    throat = _real(throat_mm, "throat_mm", positive=True)
    if not isinstance(combination_kind, str) or combination_kind not in (
        "normal", "special", "construction", "exceptional"
    ):
        raise ValueError("combination_kind must be normal, special, construction or exceptional")
    gamma = 1.15 if combination_kind == "exceptional" else 1.35
    resistance = _derived_positive(0.60 * fuw * throat / gamma, "resistance_N_per_mm")
    return FilletUnitLengthResistance(fuw, throat, combination_kind, gamma, resistance)


@dataclass(frozen=True)
class MinimumConnectionResultant:
    connection_id: str
    real_resultant_N: float
    physical_direction_xyz: tuple[float, float, float]
    actual_direction_xyz: tuple[float, float, float]
    real_magnitude_N: float
    required_resultant_N: float
    signed_required_resultant_N: float
    floor_applied: bool
    minimum_resultant_N: float = field(default=45000.0, init=False)
    station_scope_evaluated: bool = field(default=False, init=False)
    production_credit: bool = field(default=False, init=False)
    source: str = field(default=MINIMUM_FORCE_SOURCE, init=False)
    scope: str = field(
        default=(
            "45 kN minimum for one identified physical connection subject "
            "to an existing nonzero force. Not a force per weld, a fictitious "
            "panel-stabilization load, or a substitute for actual moments, "
            "coexisting forces, equilibrium and base-metal checks."
        ),
        init=False,
    )


def minimum_connection_resultant(
    *,
    real_resultant_N: float,
    physical_direction_xyz: Sequence[float],
    connection_id: str,
) -> MinimumConnectionResultant:
    """Apply the source minimum only to an existing nonzero physical force.

    ``physical_direction_xyz`` is a supplied unit reference direction; the
    sign of ``real_resultant_N`` defines its physical sense. Neither the
    reference direction nor the sign is invented or normalized. The output
    retains both, and also gives the oriented ``actual_direction_xyz``.
    ``required_resultant_N`` is the magnitude max(abs(real_resultant),45000).

    Use once for the corresponding physical connection, not per cordon.
    This helper is not applicable to the source-exempt bracing/round-rod/
    cladding/purlin connection classes, and does not assess them. An unloaded
    prescriptive shear-panel role is not an input force: zero/unknown is
    rejected, rather than replaced with a fabricated load or direction.
    """
    force = _real(real_resultant_N, "real_resultant_N")
    if force == 0.0:
        raise ValueError("a nonzero existing physical resultant is required; no force is invented")
    if not isinstance(connection_id, str) or not connection_id.strip():
        raise ValueError("connection_id must identify the physical connection, not an anonymous weld")
    if (not isinstance(physical_direction_xyz, Sequence)
            or isinstance(physical_direction_xyz, (str, bytes))
            or len(physical_direction_xyz) != 3):
        raise TypeError("physical_direction_xyz must contain three real components")
    direction = tuple(_real(value, "physical_direction_xyz component") for value in physical_direction_xyz)
    if not isclose(hypot(*direction), 1.0, rel_tol=1e-12, abs_tol=1e-12):
        raise ValueError("physical_direction_xyz must be an explicit unit direction; no normalization")
    sign = copysign(1.0, force)
    magnitude = abs(force)
    required = max(magnitude, 45000.0)
    return MinimumConnectionResultant(
        connection_id=connection_id,
        real_resultant_N=force,
        physical_direction_xyz=direction,
        actual_direction_xyz=tuple(sign * component for component in direction),
        real_magnitude_N=magnitude,
        required_resultant_N=required,
        signed_required_resultant_N=copysign(required, force),
        floor_applied=magnitude < 45000.0,
    )
