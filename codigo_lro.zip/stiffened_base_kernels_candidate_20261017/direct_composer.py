"""Bounded published nominal N/M/V composition with real consumers.

Normal rib benefit remains in N/M; V is integral in EN rods, independent plate
components, every ACI state, actual web-foot, receiver and internal joint.
The optional basal-plate scope is not a normative rule or a V resistance.
"""
from copy import deepcopy
from dataclasses import asdict
import math
from lro.direct_anchor_shear import DirectAnchorShear,evaluate_direct_anchor_shear,unc_thread_area
from lro.direct_anchor_aci import evaluate_direct_aci
from .full_composer import compose_complete_selected_domain
from .stiffened_direct_web_transfer import compose_direct_web_transfer
from lro.direct_external_plate import external_plate_components

PLATE_GAP=('Transferência nominal in-plane da placa fora do domínio publicado/adaptado selecionado. '
           'P398/P207 permitem composição convencional; não se exige campo próprio nem interação genérica adicional. '
           'O ramo opcional de placa basal robusta deve ser conferido com geometria e consumidores reais.')


def flatten_checks(value,path=''):
    """Collect actual numerical checks; scope flags are not resistance checks."""
    rows=[]
    if isinstance(value,dict):
        ratio=value.get('ratio',value.get('utilization'))
        flag=value.get('capacity_bound_satisfied',value.get('passes'))
        has_measure=any(k in value for k in ('demand','demand_N','demand_MPa','utilization','ratio','actual_fck_MPa'))
        is_summary=('checks' in value and 'forces' in value) or path.endswith('.steel_plate_uls')
        if has_measure and not is_summary and (type(flag) is bool or type(ratio) in (int,float)):
            state=('não atende' if type(ratio) in (int,float) and ratio>1 else 'pendente') if (('passes' in value and value['passes'] is None) or value.get('status') in ('pending','invalid','outside_domain')) else ('atende' if (flag if type(flag) is bool else ratio<=1) else 'não atende')
            linear_segment=('.adjacent_base_metal.checks[' in path or value.get('case_id')=='concurrent_NMV') and value.get('mode') in ('shear_yield','shear_rupture')
            displayed_unit='N/1 mm' if linear_segment else value.get('unit','MPa' if any(k in value for k in ('normal_stress_MPa','demand_MPa','sigma_bound_MPa')) else '')
            rows.append(dict(component=path,label=value.get('label',value.get('name',value.get('id',path))),state=state,ratio=ratio,unit=displayed_unit,
                demand=value.get('demand',value.get('demand_N',value.get('demand_MPa',value.get('normal_stress_MPa',value.get('required_fck_MPa'))))),
                resistance=value.get('resistance',value.get('resistance_N',value.get('resistance_MPa',value.get('capacity',value.get('actual_fck_MPa'))))),
                reference=value.get('reference',value.get('method',value.get('source','')))))
        # Named old-kernel checks carry no generic demand/ratio key. Keep them,
        # particularly axial washer prescriptions and separate normal/shear
        # stress limits, instead of accidentally hiding a known failure.
        for key in ('normal_pass','shear_pass','prescription_satisfied','passes_weld_metal_only','weld_material_matching'):
            if type(value.get(key)) is bool:
                prefix='sigma' if key=='normal_pass' else 'tau' if key=='shear_pass' else None
                rows.append(dict(component=path+'.'+key,label=key,unit='MPa' if prefix else '',state='atende' if value[key] else 'não atende',
                    ratio=value.get('normal_utilization' if key=='normal_pass' else 'shear_utilization' if key=='shear_pass' else 'utilization'),
                    demand=value.get(prefix+'_demand_MPa') if prefix else None,
                    resistance=value.get(prefix+'_resistance_MPa') if prefix else None,
                    reference=value.get('reference',value.get('method',value.get('source','')))))
        if type(value.get('capacity_bound_satisfied')) is bool and not has_measure:
            rows.append(dict(component=path+'.capacity_bound_satisfied',state='atende' if value['capacity_bound_satisfied'] else 'não atende',
                ratio=None,demand=None,resistance=None,reference=value.get('source','')))
        for k,v in value.items():
            if k not in ('physical_inputs','checks_flat','check_states','actual_rods','sources','selected_domain_conclusion','cone_geometry','states_summary'):
                rows.extend(flatten_checks(v,path+'.'+str(k) if path else str(k)))
    elif isinstance(value,(list,tuple)):
        for i,item in enumerate(value):rows.extend(flatten_checks(item,path+'['+str(i)+']'))
    return rows


def compose_stiffened_direct(*,geometry,materials,loads,connections,anchorage,washer,models,direct_shear,direct_detail):
    inputs=deepcopy(dict(geometry=geometry,materials=materials,loads=loads,connections=connections,
        anchorage=anchorage,washer=washer,models=models,direct_shear=direct_shear,direct_detail=direct_detail))
    g,m,co,a,w=geometry,materials,connections,anchorage,washer
    ds=DirectAnchorShear.from_dict(direct_shear) if isinstance(direct_shear,dict) else direct_shear
    if not isinstance(ds,DirectAnchorShear):raise ValueError('Configuração direta explícita obrigatória.')
    if not all(type(x) in (int,float) and math.isfinite(x) for x in loads.values()):raise ValueError('Ações finitas obrigatórias.')
    prerequisites=[]
    if direct_detail.get('actions_reference_plate_top_confirmed') is not True or not str(direct_detail.get('actions_reference_ref','')).strip():
        prerequisites.append('Identifique N, M e V na face superior da placa; não se transforma momento automaticamente.')
    # Both material/geometry contracts refer to the SAME physical rod and hole.
    for actual,selected,label in ((a['rod_fy_MPa'],ds.fy,'fy'),(a['rod_fu_MPa'],ds.fu,'fu'),
                                  (w['base_hole_mm'],ds.hole_diameter,'furo da placa'),(w['threads_per_inch'],ds.thread_tpi,'TPI')):
        if not math.isclose(actual,selected,rel_tol=0.,abs_tol=1e-8):
            prerequisites.append('Dados divergentes da mesma peça: '+label+'. Nenhum valor foi substituído.')
    if a['rod_material']!=ds.material_name:prerequisites.append('Identificação do material da haste deve ser a mesma nos dois contratos.')
    if ds.thread_standard!='UNC_2A':prerequisites.append('Arruela axial desta composição exige a prescrição UNC existente, sem converter diâmetro métrico.')
    if w['center_offset_x_mm']!=0 or w['center_offset_y_mm']!=0:
        prerequisites.append('Composição direta inicial exige eixos reais de haste e furo coincidentes; excentricidade de montagem não modelada.')
    try:
        area=unc_thread_area(a['rod_diameter_mm'],w['threads_per_inch'])
        if not math.isclose(area,ds.thread_area,rel_tol=1e-8,abs_tol=1e-8):
            prerequisites.append('As deve coincidir com a área UNC usada na rigidez/prying N/M; área alternativa exige adaptador específico.')
    except (ValueError,TypeError):prerequisites.append('Bitola e passo UNC não qualificados nesta composição.')
    projection=deepcopy(dict(geometry=g,materials=m,loads=dict(loads,V_N=0.),connections=co,anchorage=a,washer=w,models=models))
    nm=compose_complete_selected_domain(**projection,defer_anchorage=True)
    nm_missing=[x for x in nm.get('missing',[]) if x!='Ancoragem transferida ao consumidor direto de estados N/M/V.']
    rods=nm.get('actual_rods',[])
    out=dict(method_version='stiffened_direct_nominal_v2_20261017',physical_inputs=inputs,
        coverage_qualified=False,calculation_coverage_complete=False,assembly_approval=False,production_credit=False,
        projection=dict(purpose='Somente componentes normais N/M; NÃO é a combinação N/M/V completa',loads_NM=dict(loads,V_N=0.),
                        original_loads=dict(loads),no_action_or_geometry_replacement=True),
        credited_friction_N=0.,credited_washer_shear_N=0.,credited_rib_shear_N=0.,
        foundation_complete=False,missing=prerequisites+nm_missing,checks_flat=[])
    if not rods:
        out.update(nm_components=nm,direct_anchor_shear={},aci_components={},web_transfer={},
            conclusion_label='Composição incompleta: caminho normal N/M fora do domínio')
        out['checks_flat']=flatten_checks(nm,'NM');return out
    direct=evaluate_direct_anchor_shear(ds,rods=rods,L=g['plate_length_mm'],B=g['plate_width_mm'],tp=g['plate_thickness_mm'],
        plate_fu=m['plate_fu_MPa'],db=a['rod_diameter_mm'],V=loads['V_N'],grout_t=direct_detail['grout_t_mm'],
        grout_fck=co['grout_fck_MPa'],fck=a['concrete_fck_MPa'])
    try:
        aci=evaluate_direct_aci(direct=direct,rods=rods,bounds=a['block_bounds_mm'],hef=a['embedment_mm'],fc=a['concrete_fck_MPa'],
            block_h=direct_detail['block_height_mm'],db=a['rod_diameter_mm'],fy=ds.fy,fu=ds.fu,As=ds.thread_area,
            bearing_area=a['bearing_area_mm2'],headed_detail=a['headed_detail'],physical_detail=a['physical_detail'],
            ductile=a.get('ductile',False),ductility_reference=a.get('ductility_reference',''))
    except (ValueError,TypeError,KeyError,IndexError,ZeroDivisionError,OverflowError,AttributeError) as exc:
        aci=dict(domain=False,complete=False,passes=None,status='pending',states=[],reasons=['ACI: '+str(exc)])
    try:
        web=compose_direct_web_transfer(nm_result=nm,V_N=loads['V_N'],geometry=g,materials=m,connections=co)
    except (ValueError,TypeError,KeyError,IndexError,ZeroDivisionError,OverflowError,AttributeError) as exc:
        web=dict(domain=False,web_transfer_calculated=False,assembly_approval=False,reasons=['Transferência pela alma: '+str(exc)],checks=[])
    plate=external_plate_components(L=g['plate_length_mm'],B=g['plate_width_mm'],t=g['plate_thickness_mm'],
        d=g['column_depth_mm'],bf=g['column_flange_width_mm'],tw=g['column_web_thickness_mm'],
        a=g['column_depth_mm']/2+g['bolt_s_mm'],gauge=g['gauge_mm'],d0=ds.hole_diameter,
        fy=m['plate_fy_MPa'],fu=m['plate_fu_MPa'],V=loads['V_N'],states=direct.get('states',[]),
        source_half_width=g['column_web_thickness_mm']/2+co['column_base_leg_mm'],
        plate_monolithic=co['plate_monolithic'],flange_weld_leg=co['column_base_leg_mm'],rod_fu=ds.fu,rod_As=ds.thread_area,washer_width=w['washer_width_mm'])
    if plate['complete']:
        from lro.direct_anchor_shear import PLATE_NOTE
        direct['documentary_plate_record']=direct.get('plate_transfer_scope',{})
        direct['plate_transfer_scope']=dict(status=plate['status'],complete=True,passes=plate['passes'],
            independently_calculated=True,reference=plate['reference'])
        for key in ('reasons','pending_reasons'):
            direct[key]=[x for x in direct.get(key,[]) if x!=PLATE_NOTE]
        direct['valid']=bool(direct.get('domain',{}).get('eligible') and direct.get('steel_plate_uls',{}).get('passes')
                             and direct.get('service_scope',{}).get('passes') and plate['passes'])
    else:
        out['missing'].extend([PLATE_GAP]+plate['reasons'])
    # Do not leave obsolete zero-shear anchorage/receiver/internal consumers in
    # the report as apparent complete N/M/V checks. Their replacements are above.
    for key in ('anchorage','receiver','internal_transfer','check_states','selected_domain_conclusion'):
        nm.pop(key,None)
    nm.update(scope='Projeção normal N/M exclusivamente; V real é calculado nos consumidores separados.',
        assembly_approval=False,calculation_coverage_complete=False)
    nbr=[]
    if a['rod_material']=='ASTM A36':
        rd=min(.75*math.pi*a['rod_diameter_mm']**2/4,ds.thread_area)*ds.fu/1.35
        nbr=[dict(id=r['id'],demand=r['tension'],resistance=rd,ratio=r['tension']/rd,
            passes=r['tension']<=rd,reference='NBR8800:2024 6.7.2.2; min(0,75Ag,As)·fu real/1,35, separado EN e ACI') for r in rods]
    out.update(nm_components=nm,direct_anchor_shear=direct,aci_components=aci,web_transfer=web,nbr_rod_tension=nbr,
        actual_rods=rods,plate_transfer_scope=plate,
        actions_reference=dict(plane='top_of_baseplate',confirmed=not any('face superior' in x for x in prerequisites),
            reference=direct_detail.get('actions_reference_ref',''),automatic_moment_shift_Nmm=0.))
    for scope in ('domain','service_scope'):out['missing'].extend(direct.get(scope,{}).get('reasons',[]))
    out['missing'].extend(aci.get('reasons',[]));out['missing'].extend(web.get('reasons',[]))
    out['missing']=list(dict.fromkeys(out['missing']))
    flat_sources={k:out[k] for k in ('nm_components','direct_anchor_shear','aci_components','web_transfer','nbr_rod_tension')}
    # Each plate criterion once; states/prefixes retain rich evidence, not extra checks.
    flat_sources['plate_transfer_scope']={'checks':plate['checks']}
    out['checks_flat']=flatten_checks(flat_sources)
    failed=sum(x['state']=='não atende' for x in out['checks_flat'])
    coverage=bool(not out['missing'] and plate['complete'] and direct.get('domain',{}).get('eligible')
        and direct.get('service_scope',{}).get('passes') and aci.get('complete') and web.get('web_transfer_calculated'))
    passed=bool(coverage and direct.get('steel_plate_uls',{}).get('passes') and aci.get('passes') is True
                and all(x['state']=='atende' for x in out['checks_flat']))
    out.update(coverage_qualified=coverage,calculation_coverage_complete=coverage,selected_route_resistance_pass=passed,
        nominal_composition=dict(method='P398 base + P207 6.8, with actual independent components',
            complete=coverage,passes=passed,own_membrane_field=False,generic_new_plate_interaction=False,
            normal_rib_benefit_retained=True,actual_V_N=loads['V_N'],rib_V_N=0.,
            optional_application_envelope=plate.get('application_envelope',{})),
        foundation_complete=False,assembly_approval=False,production_credit=False)
    out['conclusion_label']=('N + M + V: escopo nominal delimitado atende; fundação externa' if passed else
        'N + M + V: '+str(failed)+' critérios não atendidos no escopo calculado' if coverage else
        'N + M + V parcial: '+(str(failed)+' critérios não atendidos; ' if failed else '')+'consultar pendências de domínio/composição')
    return out
