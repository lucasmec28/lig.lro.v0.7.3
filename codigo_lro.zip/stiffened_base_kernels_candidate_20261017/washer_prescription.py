"""Published DG1 3rd Table4-3 axial plate-washer prescription, not invented Rd.
All dimensions are actual; failed geometry is reported, never silently changed.
"""
from math import pi,hypot,isclose
from .kernels import real,positive,finite_result
UNC_TPI={19.05:10.,22.225:9.,25.4:8.,31.75:7.,38.1:6.,44.45:5.,50.8:4.5,63.5:4.}
STANDARD_HOLE={19.05:20.6375,22.225:23.8125,25.4:28.575,31.75:34.925,38.1:41.275,44.45:47.625,50.8:53.975,63.5:66.675}
GRADE_FU_MPA={2:58*6.894757293168361,3:75*6.894757293168361,4:125*6.894757293168361}
ROWS={
 19.05:(33.3375,50.8,6.35,6.35,9.525),22.225:(39.6875,63.5,9.525,9.525,12.7),
 25.4:(47.625,76.2,9.525,9.525,12.7),31.75:(53.975,88.9,9.525,12.7,15.875),
 38.1:(60.325,101.6,9.525,12.7,15.875),44.45:(73.025,114.3,19.05,19.05,19.05),
 50.8:(82.55,127.,19.05,19.05,19.05),63.5:(95.25,139.7,19.05,19.05,22.225)}

@finite_result
def axial_washer_prescription(*,rod_diameter_mm,rod_material,threads_per_inch,rod_fu_MPa,
        tension_N,washer_material,washer_shape,washer_width_mm,washer_thickness_mm,washer_hole_mm,
        base_hole_mm,center_offset_x_mm,center_offset_y_mm,edge_clearance_x_mm,edge_clearance_y_mm,
        nearest_obstacle_clearance_mm,nut_material,thread_class,full_nut_engagement,direct_seating,washer_centered_on_rod,
        A36_equivalence_selected=False):
    db=positive(rod_diameter_mm,'db');n=positive(threads_per_inch,'n');fu=positive(rod_fu_MPa,'fu');T=real(tension_N,'T',0)
    b=positive(washer_width_mm,'washer width');t=positive(washer_thickness_mm,'washer t');dh=positive(washer_hole_mm,'washer hole')
    D=positive(base_hole_mm,'base hole');dx=real(center_offset_x_mm,'offset x');dy=real(center_offset_y_mm,'offset y')
    ex=real(edge_clearance_x_mm,'edge x',0);ey=real(edge_clearance_y_mm,'edge y',0);obs=real(nearest_obstacle_clearance_mm,'obstacle clearance',0)
    for flag in (full_nut_engagement,direct_seating,washer_centered_on_rod,A36_equivalence_selected):
        if type(flag) is not bool:raise ValueError('Physical choices must be explicit booleans')
    key=next((k for k in ROWS if isclose(k,db,rel_tol=0,abs_tol=1e-8)),None)
    materialmap={'ASTM F1554 Grade 36':2,'ASTM F1554 Grade 55':3,'ASTM F1554 Grade 105':4}
    adaptation=rod_material=='ASTM A36' and A36_equivalence_selected
    idx=2 if adaptation else materialmap.get(rod_material)
    reasons=[]
    if key is None:reasons.append('No exact DG1 Table4-3 diameter row; no interpolation')
    if key is not None and not isclose(n,UNC_TPI[key],rel_tol=0,abs_tol=1e-10):reasons.append('TPI does not match published UNC diameter in DG1 Table4-1')
    if key is not None and not db<dh<=STANDARD_HOLE[key]:reasons.append('Washer hole exceeds standard hole of AISC TableJ3.3 or does not clear actual rod')
    if idx is None:reasons.append('Material outside direct prescription or explicitly selected A36 equivalence')
    if washer_material!='ASTM A572 Grade 50':reasons.append('DG1 prescription requires A572 Grade50 washer')
    if washer_shape not in ('square','circular'):reasons.append('Only square/circular plate washers prescribed')
    if thread_class!='UNC 2A' or not full_nut_engagement:reasons.append('Compatible UNC2A thread and full nut engagement required')
    expected='ASTM A563 DH' if idx==4 else 'ASTM A563 Grade A heavy hex'
    if nut_material!=expected:reasons.append('Compatible published nut specification required: '+expected)
    if not washer_centered_on_rod:reasons.append('Selected prescription requires explicit washer centered on actual rod; offset is relative to base hole')
    if not direct_seating:reasons.append('Direct seating without gap/shims required')
    if not db<=dh<D:reasons.append('Actual washer/base hole geometry not in oversized-hole prescription')
    root=db/25.4-.9743/n
    if root<=0:raise ValueError('Thread root outside numerical domain')
    As=pi/4*(root*25.4)**2
    effective_fu=min(fu,GRADE_FU_MPA[idx]) if idx in GRADE_FU_MPA else fu
    rodRd=.75*effective_fu*As
    if reasons:return dict(component_domain=False,reasons=reasons,production_credit=False,assembly_approval=False)
    row=ROWS[key];coverage=(b/2>=D/2+hypot(dx,dy) if washer_shape=='circular' else b/2>=D/2+abs(dx) and b/2>=D/2+abs(dy))
    # Clearances are measured from washer centre, after applying actual placement.
    checks=dict(rod_fits_actual_base_hole=hypot(dx,dy)+db/2<=D/2,base_hole=D<=row[0],width=b>=row[1],thickness=t>=row[idx],covers_actual_hole=coverage,
        remains_on_plate=min(ex,ey)>=b/2,no_collision=obs>=b/2,rod_design_strength=T<=rodRd)
    return dict(component_domain=True,reasons=[],production_credit=False,assembly_approval=False,
        source='DG1 3rd 4.5.3/Table4-3 pp55-56; 2.3/Table2-2; Eq4-21 to4-23',
        prescription_checks=checks,prescription_satisfied=all(checks.values()),washer_Rd_N=None,
        grade_mapping='explicit A36 same strength-level adaptation from Table2-2' if adaptation else 'direct F1554 table grade',
        required=dict(base_hole_max_mm=row[0],washer_width_min_mm=row[1],washer_thickness_min_mm=row[idx]),
        actual=dict(db_mm=db,base_hole_mm=D,washer_width_mm=b,washer_thickness_mm=t),
        rod_check=dict(T_N=T,As_UNC_mm2=As,resistance_N=rodRd,utilization=T/rodRd,capacity_bound_satisfied=T<=rodRd),
        washer_standard_hole_max_mm=STANDARD_HOLE[key],UNC_TPI_required=UNC_TPI[key],
        rod_fu_input_MPa=fu,rod_fu_for_prescription_MPa=effective_fu,grade_nominal_fu_limit_MPa=GRADE_FU_MPA[idx],
        hole_source='DG1 4.3.3 standard washer hole; AISC360-16 TableJ3.3; not oversized base-hole column of Table4-3',
        scope='Axial table prescription only; no washer stiffness or shear/couple capacity inferred')
