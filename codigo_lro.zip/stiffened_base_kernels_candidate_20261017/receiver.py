"""Two simultaneous rectangular root fields on opposite column flanges.

Classical elastic group traction and exact 1D column-panel equilibrium.
Reuse NBR8800 functions without altering column_actions() or active runtime.
Real V and M are independent: never reconstruct M=abs(V)*e.

Domain: equal effective root heights at the same elevation, column I section,
Nrib=0, no additional normal patches within the panel. Caller supplies the
concurrent panel shear at its bottom and axial compression envelope; these are
not inferred from a different load case. Global column stability is separate.
"""
from dataclasses import asdict
from math import sqrt
from types import SimpleNamespace
from .kernels import real,positive,finite_result
from lro.column_checks import normal_patch,crippling_point
from lro.local_checks import web_shear
from .verified_local_helpers import local_web_capacities


def _check(demand,resistance,source):
    return dict(demand_N=abs(demand),resistance_N=resistance,
                utilization=abs(demand)/resistance if resistance else None,
                passes=abs(demand)<=resistance,source=source,production_credit=False,
                sufficient_bound=True,physical_failure_demonstrated=False,
                state='sufficient_check_satisfied' if abs(demand)<=resistance else 'sufficient_check_not_satisfied')


@finite_result
def paired_column_receiver(*,left_load_path,right_load_path,column_flange_thickness_mm,
        column_web_thickness_mm,column_gross_area_mm2,column_fy_MPa,column_fu_MPa,column_fabrication,
        column_panel_shear_at_bottom_N,column_axial_compression_envelope_N,
        column_flange_lateral_length_mm,root_weld_leg_mm,column_root_radius_mm=None):
    tf=positive(column_flange_thickness_mm,'tf'); tw=positive(column_web_thickness_mm,'tw')
    Ag=positive(column_gross_area_mm2,'Ag'); fy=positive(column_fy_MPa,'fy'); fu=positive(column_fu_MPa,'fu')
    Vbottom=real(column_panel_shear_at_bottom_N,'concurrent panel shear'); Ncol=real(column_axial_compression_envelope_N,'Ncol envelope',0)
    Llat=positive(column_flange_lateral_length_mm,'actual unbraced flange length'); leg=positive(root_weld_leg_mm,'root weld leg')
    if fu<fy: raise ValueError('fu cannot be less than fy')
    out=dict(production_credit=False,assembly_approval=False,
        pending=['column global combined stress/stability','internal flange-web joint and fabrication',
                 'actual unbraced flange length and concurrent column actions require project evidence'])
    if column_fabrication not in ('welded','rolled'):
        out.update(domain=False,reasons=['Explicit welded or rolled fabrication required']); return out
    if column_fabrication=='rolled' and column_root_radius_mm is None:
        out.update(domain=False,reasons=['Actual rolled root radius required; it cannot be silently omitted']); return out
    radius=positive(column_root_radius_mm,'rolled root radius') if column_fabrication=='rolled' else 0.
    if column_fabrication=='welded' and column_root_radius_mm not in (None,0):
        raise ValueError('Welded receiver domain does not credit a rolled root radius')
    if not left_load_path.get('domain') or not right_load_path.get('domain'):
        out.update(domain=False,reasons=['Both actual rib load paths must be in domain']); return out
    gl,gr=left_load_path['geometry'],right_load_path['geometry']
    matched=['rib_height_mm','column_depth_mm','column_flange_width_mm','root_weld_start_height_mm','root_weld_end_height_mm']
    if any(gl[k]!=gr[k] for k in matched):
        out.update(domain=False,reasons=['Root fields require same effective height and elevation on the same column']); return out
    if any(abs(leg/sqrt(2)-g['root_throat_mm'])>1e-12 for g in (gl,gr)):
        raise ValueError('Root weld leg differs from composed physical weld throat')
    d=gl['column_depth_mm']; bf=gl['column_flange_width_mm']; hweb=d-2*tf-2*radius
    if hweb<=0 or tw>=bf: raise ValueError('Column geometry invalid')
    h=gl['root_weld_end_height_mm']-gl['root_weld_start_height_mm']
    s=SimpleNamespace(d_mm=d,bf_mm=bf,tf_mm=tf,tw_mm=tw,bottom_width=bf,bottom_thickness=tf,root_radius_mm=radius,fabrication=column_fabrication)
    material=SimpleNamespace(E_mpa=200000.,fy_mpa=fy,gamma_a1=1.10)
    # End and zero loaded-length lower-bound capacities, no root-radius credit.
    cap=local_web_capacities(s,material,bearing_length_mm=0.,end_distance_mm=0.,lateral_length_mm=Llat,rotation_restrained=False)
    records=[]; globalslope=0.
    for side,path,g in [(-1,left_load_path,gl),(1,right_load_path,gr)]:
        V=path['root_actions']['V_N']; M=path['root_actions']['M_Nmm']
        if path['root_actions']['N_N']!=0: raise ValueError('Nrib != 0 requires general field')
        Mface=M+tf*V
        patch=normal_patch(0.,Mface,h)
        global_My=-side*Mface; slope=12*global_My/h**3; globalslope+=slope
        loaded_width=g['rib_thickness_mm']+2*leg
        flange=(_check(patch.tension,.5*6.25*tf**2*fy/1.10,'NBR 5.7.2, end reduction')
                if loaded_width>=.15*bf else dict(state='not_required_by_loaded_width_condition',source='NBR 5.7.2.1',production_credit=False))
        checks=dict(web_local_yield=_check(max(patch.tension,patch.compression),1000*cap['web_yield_kn'],'NBR 5.7.3, zero loaded length/end'),
            flange_local_flexure=flange,
            web_crippling=_check(patch.compression,crippling_point(tw,tf,fy),'NBR 5.7.4, point/end bound'),
            web_sidesway=(_check(patch.compression,1000*cap['web_sidesway_kn'],'NBR 5.7.5, rotation unrestrained')
                if not cap['lateral_mode_excluded'] else dict(state='excluded_by_normative_ratio',source='NBR 5.7.5',production_credit=False)))
        records.append(dict(side=side,V_root_N=V,M_root_Nmm=M,M_inner_face_Nmm=Mface,
            global_My_Nmm=global_My,qx_slope_N_mm2=slope,normal_patch=asdict(patch),checks=checks))
    # qx(z)=globalslope*(z-h/2), z from bottom of common root interval.
    samples=[dict(z_local_mm=z,V_panel_N=Vbottom-globalslope*(z*z/2-h*z/2)) for z in (0.,h/2,h)]
    panel_demand=max(abs(x['V_panel_N']) for x in samples)
    shear_capacity,cv=web_shear(hweb,tw,fy)
    # No gross-area credit from radii/weld metal omitted in capacity geometry.
    Ag_rect=2*bf*tf+(d-2*tf)*tw; Ag_reduction=min(Ag,Ag_rect)
    axial_factor=1. if Ncol<=.4*Ag_reduction*fy else max(0.,1.4-Ncol/(Ag_reduction*fy))
    panel=_check(panel_demand,shear_capacity*axial_factor,'NBR 5.4.3 + 5.7.7, algebraic field and concurrent axial envelope')
    panel.update(Cv=cv,axial_factor=axial_factor,concurrent_axial_envelope_N=Ncol,samples=samples,
        declared_gross_area_mm2=Ag,conservative_area_for_axial_reduction_mm2=Ag_reduction,
        shear_area_basis='Conservative clear-web portion hweb*tw, no full d*tw or flange contribution credited')
    opposed=records[0]['M_inner_face_Nmm']*records[1]['M_inner_face_Nmm']>0
    # Both compression zones then coincide; larger compression is a conservative envelope.
    opposing=_check(max(r['normal_patch']['compression'] for r in records) if opposed else 0.,
        1000*cap['opposed_compression_kn'],'NBR 5.7.6, same-elevation opposing compression, end reduction')
    opposing['active']=opposed
    out.update(domain=True,roots=records,web_capacity_inputs=cap,panel=panel,opposed_compression=opposing,
               root_effective_height_mm=h,qx_total_slope_N_mm2=globalslope,
               column_geometry=dict(fabrication=column_fabrication,root_radius_mm=radius,clear_web_mm=hweb))
    return out
