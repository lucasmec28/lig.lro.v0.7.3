"""New explicit physical fixture; does not rewrite earlier arithmetic or user detail."""
from math import pi

def fixture(moment_Nmm=120e6):
    As=pi/4*((1-.9743/8)*25.4)**2
    return dict(
      geometry=dict(plate_length_mm=672.8,plate_width_mm=219.6,plate_thickness_mm=25,
        column_depth_mm=300,column_flange_width_mm=160,column_flange_thickness_mm=12,column_web_thickness_mm=8,
        rib_length_mm=186.4,rib_height_mm=400,rib_thickness_mm=10,rib_top_profile_mm=[(0,400),(20,400),(186.4,20)],
        gauge_mm=119.6,bolt_s_mm=106.4),
      materials=dict(plate_fy_MPa=250,plate_fu_MPa=400,rib_fy_MPa=250,rib_fu_MPa=400,column_fy_MPa=250,column_fu_MPa=400),
      loads=dict(N_N=400000,M_Nmm=moment_Nmm,V_N=0),
      connections=dict(grout_fck_MPa=60,column_fabrication='welded',column_root_radius_mm=0.,rib_foot_throat_mm=6,rib_root_throat_mm=6,rib_fuw_MPa=490,
        column_base_leg_mm=8,column_base_fuw_MPa=490,column_direct_bearing=True,plate_monolithic=True,
        equivalent_two_rib_fillets=True,rib_compression_bearing=False,whole_rib_connected=True,intact_rib=True,
        short_edge_support_condition='both_short_edges_rigidly_supported',column_flange_lateral_length_mm=2000,
        internal_throat_mm=5,internal_fuw_MPa=490,internal_continuous_two_faces=True,internal_connected_height_mm=400),
      anchorage=dict(rods=[dict(id=f'A{i+1}',x=x,y=y) for i,(x,y) in enumerate([(-256.4,-59.8),(-256.4,59.8),(256.4,-59.8),(256.4,59.8)])],
        rod_diameter_mm=25.4,rod_material='ASTM F1554 Grade 36',rod_fy_MPa=250,rod_fu_MPa=400,
        free_rod_segments=[(150,As)],block_bounds_mm=(-600,-500,600,500),embedment_mm=400,concrete_fck_MPa=30,bearing_area_mm2=1000,
        headed_detail=dict(family='headed',bearing_area_ref='Illustrative dimensioned head: net bearing1000mm2',effective_area_qualified=True,
          qualified_bearing_area=1000,actual_available_bearing_area=1000,detail_confirmed=True,detail_ref='Illustrative cast-in intact prism fixture',
          mechanical_resistance=200000,mechanical_ref='Explicit illustrative supplied design capacity, not derived by this fixture'),
        physical_detail={k:True for k in ('cast_in','normalweight','cracked','static','intact_prism','no_sleeves_or_voids','splitting_detail_satisfied')}),
      washer=dict(threads_per_inch=8,washer_material='ASTM A572 Grade 50',washer_shape='square',washer_width_mm=76.2,washer_thickness_mm=9.525,
        washer_hole_mm=27,base_hole_mm=47.625,center_offset_x_mm=(47.625-25.4)/2,center_offset_y_mm=0,
        nut_material='ASTM A563 Grade A heavy hex',thread_class='UNC 2A',full_nut_engagement=True,direct_seating=True,washer_centered_on_rod=True),
      models=dict(left='P207_long_tension_rib',right='triangular_inscribed_strips') if moment_Nmm>0 else
             dict(right='P207_long_tension_rib',left='triangular_inscribed_strips'))
