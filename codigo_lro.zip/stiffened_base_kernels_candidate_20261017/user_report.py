"""Standalone Portuguese calculation report; no application or calculation mutation."""
from html import escape
from math import isfinite
import re
import base64
import xml.etree.ElementTree as ET
from .report_adapter import collect_check_states

_LABELS = {
 'M_about_O_Nmm':'Momento solicitante (N mm)', 'M_design_Nmm':'Momento resistente de cálculo (N mm)', 'utilization_M':'Utilização à flexão',
 'plate_yield_N_mm':'Solicitação para escoamento da chapa (N/mm)', 'two_face_resistance_N_mm':'Resistência dos dois filetes (N/mm)',
 'sigma_demand_MPa':'Tensão normal solicitante (MPa)', 'tau_demand_MPa':'Tensão de cisalhamento solicitante (MPa)',
 'sigma_resistance_MPa':'Resistência normal (MPa)', 'tau_resistance_MPa':'Resistência ao cisalhamento (MPa)',
 'normal_utilization':'Utilização normal', 'shear_utilization':'Utilização ao cisalhamento',
 'geometry':'Geometria', 'materials':'Materiais', 'loads':'Ações de cálculo',
 'connections':'Ligações e condições de apoio', 'anchorage':'Ancoragem',
 'washer':'Arruela superior e porca', 'models':'Modelos de resistência adotados',
 'plate_length_mm':'Comprimento da chapa (mm)', 'plate_width_mm':'Largura da chapa (mm)',
 'plate_thickness_mm':'Espessura da chapa (mm)', 'column_depth_mm':'Altura do pilar (mm)',
 'column_flange_width_mm':'Largura da mesa do pilar (mm)',
 'column_flange_thickness_mm':'Espessura da mesa do pilar (mm)',
 'column_web_thickness_mm':'Espessura da alma do pilar (mm)',
 'rib_length_mm':'Comprimento da nervura (mm)', 'rib_height_mm':'Altura da nervura (mm)',
 'rib_thickness_mm':'Espessura da nervura (mm)', 'rib_top_profile_mm':'Vértices do contorno superior da nervura (mm)',
 'gauge_mm':'Distância entre linhas de chumbadores (mm)', 'bolt_s_mm':'Distância da mesa à linha de chumbadores (mm)',
 'N_N':'Força normal N (N)', 'V_N':'Força cortante V (N)', 'M_Nmm':'Momento M (N·mm)',
 'left':'Esquerda', 'right':'Direita', 'sides':'Nervuras laterais',
 'load_path':'Transmissão de esforços', 'elastic':'Tensões elásticas',
 'selected_resistance':'Resistência e estabilidade pelo modelo selecionado',
 'adjacent_base_metal':'Metal-base adjacente às soldas', 'central_plate':'Faixas centrais da chapa',
 'central_supports':'Transferência das faixas centrais', 'receiver':'Recepção de esforços pelo pilar',
 'internal_transfer':'Transferência interna mesa–alma', 'upper_washers':'Arruelas superiores',
 'concrete_contact':'Contato com o concreto', 'grout':'Argamassa de regularização',
 'reaction_actions':'Reações de equilíbrio', 'actual_rods':'Forças e coordenadas dos chumbadores',
 'actual_thread_area_mm2':'Área resistente real da rosca (mm²)',
 'contact_support_geometry':'Área de contato e apoio físico', 'equilibrium':'Resíduos de equilíbrio',
 'residual_N':'Resíduo de força normal (N)', 'residual_M_Nmm':'Resíduo de momento (N·mm)',
 'C':'Resultante de compressão (N)', 'C_x':'Abscissa da compressão (mm)',
 'lc':'Comprimento de contato (mm)', 'sigma':'Pressão de contato (MPa)',
 'Ft_max':'Maior tração por chumbador (N)', 'Ft_min':'Menor tração por chumbador (N)',
 'T_max_x':'Abscissa da maior tração (mm)', 'T_min_x':'Abscissa da menor tração (mm)',
 'checks':'Verificações', 'roots':'Regiões de ligação ao pilar', 'root':'Ligação vertical ao pilar',
 'foot':'Ligação horizontal à chapa', 'root_actions':'Esforços na ligação ao pilar',
 'root_weld_metal':'Metal de solda na ligação ao pilar', 'foot_weld_metal':'Metal de solda na ligação à chapa',
 'plate_flexure_elastic':'Flexão elástica da chapa', 'rib_sections':'Seções da nervura',
 'rib_local_normal':'Tensão normal local da nervura', 'full_strength_weld_metal':'Soldas para resistência integral',
 'gross_yield':'Escoamento da seção bruta', 'net_rupture':'Ruptura da seção líquida',
 'local_DG1_yield':'Escoamento local pelo DG1', 'actual_weld_checks_retained':'Verificações das soldas reais',
 'web_local_yield':'Escoamento local da alma', 'flange_local_flexure':'Flexão local da mesa',
 'web_crippling':'Enrugamento da alma', 'web_sidesway':'Instabilidade lateral da alma',
 'panel':'Painel de alma', 'opposed_compression':'Compressões opostas', 'bands':'Faixas',
 'cone':'Cone de ruptura do concreto', 'headed':'Ancoragem com cabeça', 'pullout':'Arrancamento local',
 'sideface':'Ruptura lateral do concreto', 'aci_rod_steel':'Aço dos chumbadores pelo ACI',
 'nbr_A36_rod_steel':'Aço dos chumbadores pela NBR', 'shear_breakout':'Ruptura do concreto por cortante',
 'pryout':'Arrancamento por alavanca', 'interaction':'Interação tração–cortante',
 'prescription_checks':'Exigências geométricas e de material', 'passes':'Critério de resistência',
 'passes_weld_metal_only':'Critério do metal de solda', 'normal_pass':'Critério de tensão normal',
 'shear_pass':'Critério de cisalhamento', 'capacity_bound_satisfied':'Limite de resistência',
 'prescription_satisfied':'Atendimento da prescrição', 'weld_material_matching':'Compatibilidade do metal de solda',
 'domain':'Domínio de aplicação', 'component_domain':'Domínio do componente',
 'source':'Referência e critério', 'reference':'Referência', 'method':'Método', 'reasons':'Justificativas',
 'pending':'Pendências', 'missing':'Lacunas', 'assumptions':'Hipóteses', 'result':'Resultado',
 'ratio':'Solicitação / resistência', 'utilization':'Índice de utilização',
 'demand':'Solicitação (N)', 'resistance':'Resistência de cálculo (N)',
 'demand_N':'Solicitação (N)', 'resistance_N':'Resistência de cálculo (N)',
 'demand_MPa':'Solicitação (MPa)', 'resistance_MPa':'Resistência de cálculo (MPa)',
 'demand_N_mm':'Solicitação linear (N/mm)', 'resistance_N_mm':'Resistência linear (N/mm)',
 'rods':'Chumbadores', 'x':'Coordenada x (mm)', 'y':'Coordenada y (mm)',
 'tension':'Tração (N)', 'shear':'Cortante (N)', 'id':'Identificação', 'name':'Identificação',
 'free_rod_segments':'Trechos livres da barra [comprimento (mm), área (mm²)]',
 'block_bounds_mm':'Limites físicos do bloco [xmin, ymin, xmax, ymax] (mm)',
 'rod_diameter_mm':'Diâmetro do chumbador (mm)', 'embedment_mm':'Embutimento efetivo (mm)',
 'concrete_fck_MPa':'Resistência característica do concreto (MPa)',
 'headed_detail':'Detalhe da cabeça de ancoragem', 'physical_detail':'Condições físicas da ancoragem',
 'mechanical_resistance':'Resistência mecânica documentada da cabeça (N)',
 'mechanical_ref':'Documento da resistência mecânica', 'detail_ref':'Documento do detalhe',
 'rod_material':'Material do chumbador', 'washer_material':'Material da arruela', 'nut_material':'Material da porca',
 'P207_long_tension_rib':'Nervura longa tracionada, SCI P207',
 'triangular_inscribed_strips':'Faixas triangulares inscritas',
 'both_short_edges_rigidly_supported':'Duas bordas curtas rigidamente apoiadas',
 'welded':'Soldado', 'rolled':'Laminado', 'square':'Quadrada',
 'PASS':'Atendido', 'FAIL':'Não atendido', 'NOT_APPLICABLE':'Não solicitado / não aplicável',
 'not_demanded':'Não solicitado', 'not_applicable':'Não aplicável',
 'calculated':'Calculado', 'verified':'Verificado', 'outside_domain':'Fora do domínio',
 'component_bound_satisfied':'Limite atendido', 'component_bound_not_satisfied':'Limite não atendido',
 'input_error':'Erro nos dados', 'sufficient_check_satisfied':'Critério suficiente atendido',
 'sufficient_check_not_satisfied':'Critério suficiente não atendido',
}
_TOKENS = {'plate':'chapa','rib':'nervura','column':'pilar','flange':'mesa','web':'alma',
 'length':'comprimento','width':'largura','thickness':'espessura','height':'altura',
 'root':'raiz','foot':'base','throat':'garganta','weld':'solda','internal':'interna',
 'rod':'chumbador','washer':'arruela','hole':'furo','base':'base','actual':'real',
 'required':'exigido','minimum':'mínimo','maximum':'máximo','min':'mínimo','max':'máximo',
 'material':'material','center':'centro','offset':'excentricidade','direct':'direto',
 'bearing':'apoio','continuous':'contínua','two':'duas','faces':'faces','connected':'conectada',
 'threads':'fios','per':'por','inch':'polegada','thread':'rosca','class':'classe',
 'full':'integral','nut':'porca','engagement':'engajamento','seating':'assentamento',
 'centered':'centrada','on':'sobre','fabrication':'fabricação','radius':'raio',
 'compression':'compressão','tension':'tração','intact':'íntegra','monolithic':'monolítica',
 'equivalent':'equivalentes','fillets':'filetes','whole':'integral','short':'curta','edge':'borda',
 'support':'apoio','condition':'condição','lateral':'lateral','grout':'argamassa',
 'bounds':'limites','normal':'normal','stress':'tensão','shear':'cisalhamento',
 'design':'de cálculo','nominal':'nominal','strength':'resistência','area':'área',
 'start':'início','end':'fim','effective':'efetivo','local':'local','global':'global',
 'remaining':'restantes','modes':'modos','physical':'físico','detail':'detalhe',
 'confirmed':'confirmado','qualified':'qualificado','available':'disponível',
 'cast':'moldado','in':'no local','normalweight':'peso normal','cracked':'fissurado',
 'static':'estático','prism':'prisma','no':'sem','sleeves':'bainhas','or':'ou','voids':'vazios',
 'splitting':'fendilhamento','satisfied':'atendido','profile':'contorno','top':'superior',
 'fy':'fy','fu':'fu','fuw':'fuw','fck':'fck', 'MPa':'MPa','mm':'mm','mm2':'mm²','mm3':'mm³','mm4':'mm⁴','Nmm':'N·mm',
}
_LABELS.update({
 'P207 long-rib shortcut requires h >= 1.8 lr; short-rib rotation branch not implemented': 'SCI P207: a simplificação de nervura longa exige h ≥ 1,8 lr. A verificação por rotação de nervura curta não está disponível neste cálculo.',
 'Axial table prescription only; no washer stiffness or shear/couple capacity inferred': 'Somente prescrição tabelada para esforço axial. Não se atribui rigidez à arruela nem resistência a cortante ou a binário.',
 'Composed with selected resistance, receiver, anchors and washer prescription; inspect each result': 'Associado às verificações de resistência, pilar receptor, chumbadores e arruelas. Examinar cada resultado.',
 'Conservative clear-web portion hweb*tw, no full d*tw or flange contribution credited': 'Área conservadora da alma livre hweb × tw, sem considerar d × tw integral nem contribuição das mesas.',
 'Continuous monolithic plate across real web/flange supports': 'Chapa monolítica contínua sobre os apoios físicos de alma e mesas.',
 'Each of two equivalent faces receives half of the common physical thickness': 'Cada uma das duas faces equivalentes recebe metade da espessura física comum.',
 'Explicit illustrative supplied design capacity, not derived by this fixture': 'Resistência de cálculo ilustrativa fornecida explicitamente; não determinada neste exemplo de cálculo.',
 'Fatigue, seismic, nonzero global shear, biaxial bending and nonsymmetric geometry': 'Fadiga, sismo, cortante global não nulo, flexão biaxial e geometria não simétrica.',
 'Global column/frame design and reinforced foundation/soil design': 'Dimensionamento global do pilar e da estrutura, fundação armada e solo.',
 'Illustrative cast-in intact prism fixture': 'Exemplo ilustrativo de ancoragem concretada em prisma íntegro.',
 'Illustrative dimensioned head: net bearing1000mm2': 'Cabeça ilustrativa dimensionada: área líquida de apoio de 1000 mm².',
 'No additional two-way support credit or automatic beta table selection': 'Sem contribuição adicional de apoio bidirecional nem seleção automática de coeficiente β tabelado.',
 'Nominal compression of physical support section, not proven uniform contact pressure': 'Compressão nominal da seção física de apoio; não demonstra pressão uniforme de contato.',
 'Not a partial-depth stiffener inside receptor web; no invented diagonal cut': 'Não se trata de enrijecedor de altura parcial dentro da alma receptora; não foi admitido corte diagonal fictício.',
 'Published tension-stiffener component; no claim of arbitrary free-beam stability': 'Modelo publicado de enrijecedor tracionado; não representa comprovação de estabilidade de uma viga livre arbitrária.',
 'Reinforced foundation design and soil bearing, not part of this connection component': 'Dimensionamento da fundação armada e capacidade do solo não integram esta verificação de ligação.',
 'Same nominal Mface/Vroot field as receiver, N/M static with zero external column shear': 'Mesmo campo nominal Mface/Vroot utilizado no pilar receptor; ações estáticas N/M e cortante externo nulo.',
 'Uniform pressure in transverse y and actual clipped contact in x': 'Pressão uniforme na direção transversal y e contato limitado à extensão física em x.',
 'Actual rod shear is zero': 'O cortante real nos chumbadores é nulo.',
 'Actual geometry, no fictitious concrete beyond support': 'Geometria real, sem concreto fictício além do apoio.',
 'Actual global compression contact rectangle is not contained in the physical concrete support': 'O retângulo de contato da compressão global não está contido no apoio físico de concreto.',
 'Load path outside selected geometry domain': 'Transmissão de esforços fora do domínio geométrico selecionado.',
 'excluded_by_normative_ratio': 'Dispensado pela relação geométrica normativa',
 'not_applicable_to_this_receiver_topology': 'Não aplicável à configuração deste pilar receptor',
 'selected_component_calculated': 'Componente selecionado calculado',
 'compression_inscribed_triangle_nominal_stability': 'Estabilidade nominal do triângulo inscrito comprimido',
 'excluded_scope':'Escopo não abrangido', 'scope':'Escopo', 'state':'Estado', 'status':'Estado',
 'physical_failure_demonstrated':'Ruptura física demonstrada', 'sufficient_bound':'Critério suficiente',
 'component_mapping_verified':'Correspondência física do componente verificada',
 'component_qualification':'Qualificação do componente', 'base_metal_verified':'Metal-base verificado neste cálculo local',
 'member_stability':'Estabilidade do elemento', 'bound_satisfied':'Limite atendido',
 'not_an_automatic_capacity_pass':'O cálculo não implica atendimento automático',
 'component_no_prying_bound':'Limite de ausência de efeito alavanca no componente',
 'selected_anchor_modes_complete':'Modos selecionados da ancoragem calculados',
 'no_collision':'Ausência de interferência física', 'covers_actual_hole':'Cobertura do furo real',
 'remains_on_plate':'Arruela contida na chapa', 'base_hole_within_plate':'Furo de base contido na chapa',
 'rod_fits_actual_base_hole':'Compatibilidade do chumbador com o furo real',
 'grade_mapping':'Correspondência entre classes de material',
 'direct F1554 table grade':'Classe F1554 indicada diretamente na tabela',
 'prerequisites':'Pré-requisitos', 'requirements':'Exigências', 'details':'Detalhes',
 'actual':'Valor real', 'required':'Valor exigido', 'remaining_modes':'Modos complementares',
 'mechanical':'Resistência mecânica', 'rod_check':'Verificação do chumbador',
})
_TOKENS.update({'source':'referência','check':'verificação','checks':'verificações','groups':'grupos',
 'cells':'trechos','sections':'seções','samples':'pontos de avaliação','line':'linear','lines':'linhas',
 'normalweight':'peso normal','capacity':'capacidade','input':'fornecida','for':'para',
 'prescription':'prescrição','grade':'classe','limit':'limite','within':'contido em','standard':'padrão',
 'maximum':'máximo','minimum':'mínimo','nominal':'nominal','perpendicular':'perpendicular',
 'parallel':'paralela','bound':'limite','resultant':'resultante','strain':'deformação',
 'moment':'momento','moments':'momentos','forces':'forças','recovered':'recuperados',
 'yield':'escoamento','rupture':'ruptura','gross':'bruta','effective':'efetiva',
 'combination':'combinação','current':'atual','face':'face','per':'por','retained':'mantidos',
 'selected':'selecionados','geometric':'geométrico','complete':'completo','not':'não',
 'verified':'verificado','mapping':'correspondência','source':'referência','model':'modelo',
 'allocation':'distribuição','basis':'base de cálculo','formula':'expressão','used':'utilizada',
 'support':'apoio','strip':'faixa','strips':'faixas','compression':'compressão',
 'inscribed':'inscrita','triangle':'triângulo','stability':'estabilidade','nominal':'nominal',
 'longitudinal':'longitudinal','transverse':'transversal','shear':'cisalhamento',
 'field':'campo','stress':'tensão','interpretation':'interpretação'})

_LABELS.update({
 'actual_contact_rectangle_mm':'Retângulo real de contato [xmin, ymin, xmax, ymax] (mm)',
 'physical_support_bounds_mm':'Limites físicos do apoio [xmin, ymin, xmax, ymax] (mm)',
 'elastic_stress_MPa':'Tensão elástica (MPa)', 'tension_component':'Componente tracionado',
 'rod_compliance':'Deformabilidade do chumbador',
 'embedment_compliance_credited':'Deformabilidade do trecho embutido considerada',
 'ratio_Lb_limit_over_Lb':'Relação entre comprimento limite e comprimento livre Lb',
 'branch':'Modelo de resistência selecionado', 'active':'Solicitação atuante',
 'supplementary_reinforcement_credit':'Contribuição de armadura suplementar considerada',
 'ductile':'Classificação como dúctil', 'interaction_required':'Verificação de interação exigida',
 'family':'Tipo de ancoragem', 'shape':'Forma', 'headed':'Ancoragem com cabeça',
 'washer_shape':'Forma da arruela', 'column_base_leg_mm':'Perna do filete pilar–base (mm)',
 'UNC_TPI_required':'Número de fios por polegada exigido para rosca UNC',
 'actual_fck_MPa':'fck efetivo (MPa)', 'required_fck_MPa':'fck exigido (MPa)',
 'bearing_stress_MPa':'Tensão de apoio (MPa)', 'bearing_resistance_MPa':'Resistência ao apoio (MPa)',
 'weld_resistance_N_mm':'Resistência da solda por comprimento (N/mm)',
 'h_required_mm':'Altura exigida (mm)', 'parallel_web_resistance_credited_N':'Resistência paralela da alma considerada (N)',
 'web_capacity_inputs':'Parâmetros de resistência da alma', 'lateral_ratio':'Relação geométrica lateral',
 'normal_stress_MPa':'Tensão normal (MPa)', 'shear_stress_MPa':'Tensão de cisalhamento (MPa)',
 'shear_resistance_MPa':'Resistência ao cisalhamento (MPa)',
 'normal_utilization':'Índice de utilização em tensão normal', 'shear_utilization':'Índice de utilização em cisalhamento',
 'capacity':'Resistência de cálculo (N)', 'source_resistance':'Referência da resistência',
 'component_domain':'Domínio do componente', 'physical_detail':'Condições físicas do detalhe',
 'source_model':'Referência do modelo', 'interfaces':'Interfaces',
 'no_bolted_085_cap':'Redução de 0,85 para ligação parafusada não aplicada',
 'actual_geometry_unchanged':'Geometria real preservada', 'cast_in':'Concretado no local',
 'normalweight':'Concreto de peso normal', 'cracked':'Concreto fissurado',
 'full_nut_engagement':'Engajamento integral da porca', 'direct_seating':'Assentamento direto',
 'short_edge_support_condition':'Condição de apoio das bordas curtas',
 'whole_rib_connected':'Nervura integralmente conectada', 'intact_rib':'Nervura íntegra',
 'rib_compression_bearing':'Apoio direto da nervura comprimida',
 'column_direct_bearing':'Apoio direto do pilar',
 'DG1 4.3.3 standard washer hole; AISC360-16 TableJ3.3; not oversized base-hole column of Table4-3':
 'DG1 4.3.3, furo padrão da arruela; AISC360-16 Tabela J3.3; não corresponde à coluna de furos alargados da base na Tabela 4-3.',
 'ABNT NBR 8800:2024 corrigida 2025, 5.5.2.3(a,b), p63/PDF85; normal combinations':
 'ABNT NBR 8800:2024 corrigida 2025, 5.5.2.3(a,b), p63/PDF85; combinações normais',
 'ABNT NBR 8800:2024, 6.2.5.1, Table 9 and notes d/i, p. 78 (source PDF p. 100)':
 'ABNT NBR 8800:2024, 6.2.5.1, Tabela 9 e notas d/i, p. 78 (PDF de referência p. 100)',
 'Bellei 2006 §§2.3.5–2.3.5.1; DG1 3rd Ex4.7-3; SCI P207 §6.8':
 'Bellei 2006 §§2.3.5–2.3.5.1; DG1 3ª edição, Ex4.7-3; SCI P207 §6.8',
 'Bellei2006 2.3.5 one-way transverse strips; NBR8800:2024 5.5.2.3(a)':
 'Bellei2006 2.3.5, faixas transversais unidirecionais; NBR8800:2024 5.5.2.3(a)',
 'DG1 3rd 4.5.3/Table4-3 pp55-56; 2.3/Table2-2; Eq4-21 to4-23':
 'DG1 3ª edição 4.5.3/Tabela4-3 pp55-56; 2.3/Tabela2-2; equações4-21 a4-23',
 'Existing flange_web_weld_stress_bounds; NBR8800 Table9 and6.5.3/6.5.5':
 'Limites de tensão na solda mesa–alma; NBR8800 Tabela9 e6.5.3/6.5.5',
 'NBR 5.4.3 + 5.7.7, algebraic field and concurrent axial envelope':
 'NBR 5.4.3 + 5.7.7, campo algébrico e envoltória axial concomitante',
 'NBR 5.7.2, end reduction':'NBR 5.7.2, redução de extremidade',
 'NBR 5.7.3, zero loaded length/end':'NBR 5.7.3, comprimento carregado nulo/extremidade',
 'NBR 5.7.4, point/end bound':'NBR 5.7.4, limite para carga pontual/extremidade',
 'NBR 5.7.6, same-elevation opposing compression, end reduction':
 'NBR 5.7.6, compressões opostas na mesma cota, redução de extremidade',
 'NBR8800 6.6.5, no confinement credit':'NBR8800 6.6.5, sem contribuição de confinamento',
 'NBR8800:2024 5.3.3.1 matching chi curve, gamma_a1=1.10':
 'NBR8800:2024 5.3.3.1, curva χ correspondente, γa1=1.10',
 'NBR8800:2024 6.5.3, 5.2.3/5.2.4.2/5.2.5a, Table9, normal combinations':
 'NBR8800:2024 6.5.3, 5.2.3/5.2.4.2/5.2.5a, Tabela9, combinações normais',
 'NBR8800:2024 6.5.5; existing welded_coverplate_splice._shear / _transfer':
 'NBR8800:2024 6.5.5, resistência ao cisalhamento e transferência de esforços em ligação soldada',
 'P2076.8 direct compression bearing; NBR6.2/Table9 and retained6.5.5 primitive':
 'P2076.8, apoio direto de compressão; NBR6.2/Tabela9 e critério6.5.5',
 'Retained concrete_anchorage/concrete_headed/concrete_shear, ACI318-19 + DG1; NBR steel separate':
 'Ancoragem, cabeça e cisalhamento no concreto: ACI318-19 + DG1; aço pela NBR verificado separadamente',
 'SCI P207 Step6C pp35-36 Eqs2.17/2.18, long-rib shortcut':
 'SCI P207 Etapa6C pp35-36, equações2.17/2.18, simplificação para nervura longa',
 'SCI P2076.8 direct compression bearing; physical support section stress':
 'SCI P2076.8, apoio direto de compressão; tensão na seção física de apoio',
 'SCI P398 Appendix G p163':'SCI P398 Apêndice G p163',
 'SCI P398 Table 2.2(b), pp12–14; HERON eq21':'SCI P398 Tabela 2.2(b), pp12–14; HERON equação21',
 'Shakya/Vinnakota2008 Eq18 + 2009 errata; design K=.65':
 'Shakya/Vinnakota2008 equação18 + errata de 2009; K de cálculo=.65',
 'Shakya/Vinnakota2008 eq18 + errata2009 eq15; chi=NBR8800:2024 5.3.3.1, normal combinations':
 'Shakya/Vinnakota2008 equação18 + errata2009 equação15; χ=NBR8800:2024 5.3.3.1, combinações normais',
 'upper_washers_common':'Condições comuns das arruelas superiores',
})
_TOKENS.update({'leg':'perna do filete','family':'tipo','shape':'forma','elastic':'elástica',
 'scope':'escopo','component':'componente','components':'componentes','compliance':'deformabilidade',
 'credited':'considerada','credit':'contribuição considerada','ratio':'relação','over':'dividido por',
 'branch':'modelo','active':'atuante','supplementary':'suplementar','reinforcement':'armadura',
 'ductile':'dúctil','interaction':'interação','contact':'contato','rectangle':'retângulo',
 'resistance':'resistência','inputs':'parâmetros','properties':'propriedades','actions':'esforços',
 'load':'carga','loads':'cargas','group':'grupo','geometry':'geometria','dimensions':'dimensões',
 'lengths':'comprimentos','stiffener':'enrijecedor','count':'quantidade','free':'livre',
 'embedment':'embutimento','intact':'íntegro','plate':'chapa','top':'superior'})

_SKIP = {'selected_domain_conclusion','check_states','physical_inputs','candidate_only','production_credit','assembly_approval',
         'assembly_state','review_gate','connection_approval'}


def _clean(text):
    # Editorial translation only: preserve numerical values and engineering references.
    text = _LABELS.get(str(text), str(text))
    text = text.replace('Retained concrete_anchorage/concrete_headed/concrete_shear, ACI318-19 + DG1; NBR steel separate','ACI 318-19 e AISC DG1 para ancoragem; resistência do aço verificada separadamente pela NBR 8800')
    for old,new in {'existing welded_coverplate_splice._shear / _transfer':'resistência do metal-base','Existing flange_web_weld_stress_bounds':'Tensões na ligação mesa–alma','retained6.5.5 primitive':'6.5.5','normal combinations':'combinações normais'}.items():text=text.replace(old,new)
    text = re.sub(r'\bfixtures?\b', 'exemplo de cálculo', text, flags=re.I)
    text = re.sub(r'\bcandidates?\b', 'alternativas de cálculo', text, flags=re.I)
    text = re.sub(r'\bkernels?\b', 'procedimentos de cálculo', text, flags=re.I)
    text = re.sub(r'\bruntime\b', 'uso operacional', text, flags=re.I)
    return text


def _label(key):
    if key in _LABELS:
        return _LABELS[key]
    return _clean(' '.join(_TOKENS.get(token, token) for token in str(key).split('_')))


def _value(value):
    if value is None:
        return 'Não informado / não aplicável'
    if isinstance(value, bool):
        return 'Sim' if value else 'Não'
    if isinstance(value, (float, int)):
        if isinstance(value, float) and not isfinite(value):
            return 'Valor não finito: verificar dados'
        return format(value, '.6g')
    if isinstance(value, (tuple, list)):
        return '[' + '; '.join(_value(x) for x in value) + ']'
    return _LABELS.get(str(value), _clean(value))


def _flat(value, prefix=''):
    if isinstance(value, dict):
        for key, item in value.items():
            if key in _SKIP:
                continue
            name = (prefix + ' › ' if prefix else '') + _label(key)
            yield from _flat(item, name)
    elif isinstance(value, (list, tuple)) and any(isinstance(x, dict) for x in value):
        for i, item in enumerate(value):
            yield from _flat(item, f'{prefix} [{i+1}]')
    else:
        yield prefix, _value(value)


def _table(rows, headings=('Grandeza / condição', 'Valor')):
    widths=([35,13,45,7] if headings[0]=='Verificação' else [30,20,30,20]) if len(headings)==4 else [35,58,7] if len(headings)==3 else [45,55]
    if headings==('Fonte','Referência / critério'):widths=[8,92]
    def cells(values,tag):
        return ''.join(f'<{tag} width="{widths[i]}%">'+escape(str(v))+f'</{tag}>' for i,v in enumerate(values))
    return '<table width="100%" cellspacing="0" cellpadding="1"><thead><tr>'+cells(headings,'th')+'</tr></thead><tbody>'+''.join('<tr>'+cells(row,'td')+'</tr>' for row in rows)+'</tbody></table>'


def _path(path):
    # Convert zero-based diagnostic paths into human-facing one-based component names.
    parts = path.split('.')
    labels=[]
    for part in parts:
        if part=='result':
            continue
        match=re.fullmatch(r'(.*?)\[(\d+)\]',part)
        labels.append(_label(match[1])+' '+str(int(match[2])+1) if match else _label(part))
    return ' › '.join(labels)


def _resolve(result, path):
    node=result
    inherited=[]
    for part in path.split('.')[1:]:
        if isinstance(node,dict):
            inherited.extend(str(node[k]) for k in ('source','reference','method','model_source','source_model','source_resistance') if node.get(k))
        match=re.fullmatch(r'(.*?)\[(\d+)\]',part)
        try:
            node=node[match[1]][int(match[2])] if match else node[part]
        except (KeyError,TypeError,IndexError):
            break
    return node, inherited


def _group(path):
    parts=path.split('.')
    return parts[1] if len(parts)>1 else 'result'


def _nodes(value, path='result'):
    if isinstance(value,dict):
        yield path,value
        for key,item in value.items():
            if key not in _SKIP:
                yield from _nodes(item,path+'.'+key)
    elif isinstance(value,(list,tuple)):
        for i,item in enumerate(value):
            yield from _nodes(item,f'{path}[{i}]')


def _input_tables(inputs):
    output=[]
    for group,value in inputs.items():
        if not isinstance(value,(dict,list,tuple)):
            output.append(_table([(_label(group),_value(value))]))
            continue
        output.append('<h3>'+escape(_label(group))+'</h3>')
        rows=list(_flat(value))
        # Two compact pairs per row; no repeated top-level path prefix.
        packed=[]
        for i in range(0,len(rows),2):
            packed.append(tuple(rows[i])+(tuple(rows[i+1]) if i+1<len(rows) else ('','')))
        output.append(_table(packed,('Grandeza / condição','Valor','Grandeza / condição','Valor')))
    return ''.join(output)


def _drawing_image(svg):
    """Embed only passive, self-contained SVG as an image, never active HTML."""
    if not isinstance(svg,str) or len(svg)>2_000_000:
        raise ValueError('O desenho deve ser um SVG textual de até 2 MB.')
    if re.search(r'<!DOCTYPE|<!ENTITY',svg,re.I):
        raise ValueError('Declarações externas não são permitidas no desenho.')
    try:
        root=ET.fromstring(svg)
    except ET.ParseError as exc:
        raise ValueError('SVG do desenho inválido.') from exc
    permitted={'svg','g','path','line','polyline','polygon','rect','circle','ellipse',
               'text','tspan','defs','marker','title','desc','clipPath','pattern','use','style'}
    if root.tag.rsplit('}',1)[-1]!='svg':
        raise ValueError('O desenho deve ter elemento raiz SVG.')
    for element in root.iter():
        tag=element.tag.rsplit('}',1)[-1]
        if tag not in permitted:
            raise ValueError('Elemento ativo ou não permitido no desenho SVG.')
        if element.tag.startswith('{') and not element.tag.startswith('{http://www.w3.org/2000/svg}'):
            raise ValueError('Espaço de nomes externo não permitido no desenho.')
        for key,value in element.attrib.items():
            name=key.rsplit('}',1)[-1].lower()
            if name.startswith('on') or name in ('src','base'):
                raise ValueError('Atributo ativo não permitido no desenho SVG.')
            if name=='href' and not re.fullmatch(r'#[A-Za-z_][\w.-]*',value):
                raise ValueError('Referências externas não são permitidas no desenho SVG.')
        # CSS is limited to passive presentation with only local paint/marker URLs.
        css=' '.join(element.attrib.values())+' '+(element.text or '' if tag=='style' else '')
        if re.search(r'@import|expression\s*\(|javascript\s*:|data\s*:|https?\s*:|file\s*:|behavior\s*:|[-]moz-binding',css,re.I):
            raise ValueError('Conteúdo ativo ou externo não permitido no desenho SVG.')
        for url in re.findall(r'url\s*\((.*?)\)',css,re.I):
            if not re.fullmatch(r'[\s\"\']*#[A-Za-z_][\w.-]*[\s\"\']*',url):
                raise ValueError('Somente referências locais são permitidas no desenho SVG.')
        if '\\' in css:
            raise ValueError('Escapes CSS não são permitidos no desenho SVG.')
    encoded=base64.b64encode(ET.tostring(root,encoding='utf-8')).decode('ascii')
    return '<figure class="drawing"><img alt="Geometria e cortes da base com nervuras" src="data:image/svg+xml;base64,'+encoded+'"><figcaption>Geometria e cortes do detalhe informado. Conferir cotas, materiais e condições de apoio com as entradas desta memória.</figcaption></figure>'


def export_user_mc(inputs, result, drawing_svg=None):
    """Return self-contained printable HTML, including every failed/outside check.

    ``inputs`` is the physical compose_complete_selected_domain input dictionary.
    ``result`` may be incomplete. Nothing here grants approval or recalculates data.
    All text, including supplied references and IDs, is escaped before HTML output.
    """
    if not isinstance(inputs,dict) or not isinstance(result,dict):
        raise TypeError('Entradas e resultados devem ser dicionários.')
    states=collect_check_states(result)  # Rebuild: stale cached summaries cannot hide failures.
    failed=[s for s in states if s['state']=='component_bound_not_satisfied']
    outside=[s for s in states if s['state'] in ('outside_domain','input_error')]
    missing=result.get('missing',[])
    complete=result.get('calculation_coverage_complete') is True and not missing and not outside
    mismatch=any(key not in inputs or inputs[key]!=value for key,value in result.get('physical_inputs',{}).items())
    if mismatch:
        complete=False
    verdict='Fora do domínio ou cálculo incompleto' if not complete or not states else 'Não atende a um ou mais critérios calculados' if failed else 'Atende aos critérios calculados no domínio selecionado'
    summary=[('Conclusão dos critérios calculados',verdict),('Cobertura do domínio selecionado', 'Completa nos resultados apresentados' if complete else 'Incompleta ou não demonstrada'),
             ('Verificações de resistência / prescrição', f'{len(failed)} registro(s) de limite não atendido; {len(outside)} registro(s) fora do domínio ou com erro'),
             ('Aprovação do conjunto','Não emitida por esta memória. Exige revisão independente e responsabilidade técnica.')]
    body=['<header><p>ENGENHARIA ESTRUTURAL · MEMÓRIA DE CÁLCULO</p><h1>Base de pilar com nervuras</h1>',
          '<p>Flexão uniaxial e força normal · domínio estático selecionado · unidades N, mm e MPa.</p></header>',
          '<section><h2>1. Conclusão e limites de uso</h2>',_table(summary),
          '<p class="notice">Cobertura de cálculo não significa resistência atendida nem aprovação do conjunto. '
          'Um limite suficiente não atendido não demonstra, isoladamente, ruptura física; ele impede concluir atendimento pelo critério adotado. '
          'Os registros podem repetir o mesmo fenômeno em diferentes verificações e não representam contagem de modos de falha independentes.</p>']
    if mismatch:
        body.append('<p class="alert">Divergência entre as entradas fornecidas e as entradas registradas no cálculo. Não usar esta memória para aprovação sem reconciliação.</p>')
    if not states:
        body.append('<p class="alert">Não há verificações de resistência disponíveis. Ausência de resultados não equivale a atendimento.</p>')
    body+=['<h3>Pendências e condições fora do domínio</h3>']
    issues=[]
    for path,text in _flat(result):
        if any(term in path for term in ('Lacunas','Pendências','Justificativas')) and text!='[]':
            issues.append((path,text))
    body.append(_table(issues) if issues else '<p>Nenhuma pendência adicional declarada. Mantém-se a exigência de revisão independente.</p>')
    body+=['<p>Não abrangidos: dimensionamento global do pilar e da estrutura; fundação armada e solo; fadiga; sismo; cortante global diferente de zero; flexão biaxial e geometria não simétrica.</p></section>',
           '<section><h2>2. Entradas físicas fornecidas</h2><p>Valores apresentados sem substituição de geometria, material ou detalhe. Coordenadas conforme o sistema do cálculo.</p>',_input_tables(inputs),'</section>']
    if drawing_svg is not None:
        body+=['<section><h3>Desenhos essenciais do detalhe</h3>',_drawing_image(drawing_svg),'</section>']
    if mismatch:
        body+=['<section><h3>Entradas registradas no cálculo, para reconciliação</h3>',_table(_flat(result['physical_inputs'])),'</section>']
    body+=['<section><h2>3. Ações, reações e equilíbrio</h2>']
    for key in ('reaction_actions','actual_rods','actual_thread_area_mm2','contact_support_geometry','equilibrium'):
        body+=[_input_tables({key:result[key]}) if key in result else '<h3>'+escape(_label(key))+'</h3><p>Não disponível neste resultado.</p>']
    body+=['</section><section><h2>4. Quadro de verificações</h2>',
           '<p>Critério: solicitação ≤ resistência, índice de utilização ≤ 1 ou cumprimento integral da prescrição identificada. Os detalhes numéricos e as hipóteses constam da seção 5.</p>']
    references={}
    def reference_ids(refs):
        ids=[]
        for ref in dict.fromkeys(_clean(x) for x in refs if x):
            if ref not in references:
                references[ref]='R'+str(len(references)+1)
            ids.append(references[ref])
        return ', '.join(ids) or 'Não informada'
    grouped={}
    represented=set()
    numeric_terms=('demand','resistance','utilization','ratio','stress','capacity','required','actual_fck','plate_yield')
    for state in states:
        path=state['component']; node,refs=_resolve(result,path)
        nodepath=path
        if not isinstance(node,dict):
            nodepath=path.rsplit('.',1)[0]
            node,parentrefs=_resolve(result,nodepath);refs+=parentrefs
        numbers=[]
        if isinstance(node,dict):
            refs += [str(node[k]) for k in ('source','reference','method','model_source','source_model','source_resistance') if node.get(k)]
            for key,value in node.items():
                if path.endswith('.normal_pass') and key.startswith(('tau_','shear_')):continue
                if path.endswith('.shear_pass') and key.startswith(('sigma_','normal_')):continue
                if isinstance(value,(int,float)) and not isinstance(value,bool) and any(t in key.lower() for t in numeric_terms):
                    numbers.append(_label(key)+': '+_value(value))
                    represented.add((nodepath,key))
        if isinstance(node,dict) and 'M_about_O_Nmm' in node and isinstance(node.get('capacity'),dict):
            for key,value in [('M_about_O_Nmm',node['M_about_O_Nmm']),('M_design_Nmm',node['capacity'].get('M_design_Nmm'))]:
                if isinstance(value,(int,float)) and not isinstance(value,bool): numbers.append(_label(key)+': '+_value(value))
        if '.adjacent_base_metal.' in path or (path.startswith('result.internal_transfer.checks')):
            numbers.append('Forças referidas a trecho de 1 mm da junta')
        group=_group(path)
        relative='.'.join(path.split('.')[2:])
        # Each row remains individually traceable, including duplicate states.
        grouped.setdefault(group,[]).append((_path('result.'+relative) if relative else _label(group),
             _label(state['state']),'; '.join(numbers) or 'Condição geométrica / prescrição; ver seção 5',reference_ids(refs)))
    for group,rows in grouped.items():
        body+=['<h3>'+escape(_path('result.'+group))+'</h3>',
               _table(rows,('Verificação','Resultado','Valores / critério','Fonte'))]
    body+=['</section><section><h2>5. Hipóteses e resultados complementares</h2>',
           '<p>Valores de solicitação e resistência já apresentados no quadro não são repetidos. '
           'O arquivo de resultados completo disponibilizado separadamente contém os pontos intermediários de integração, distribuições e demais grandezas auxiliares. '
           'Condições e referências abaixo devem ser conferidas no detalhe real.</p>']
    # Preserve every remaining demand/capacity value, all hypotheses and false
    # qualification flags, without reprinting scalar paths and metadata hundreds of times.
    contextual=result.get('selected_domain_conclusion',{}).get('coverage_qualified') is True and complete
    local_scope_markers={'component_mapping_verified','component_qualification','base_metal_verified','instability_verified',
        'plate_shear_and_local_holes_verified','remaining_modes','physical_failure_demonstrated',
        'demand_and_resistance_fields_identical','physical_corner_tie_required_by_source','compression_strip_formula_used','free_beam_LTB_imposed'}
    if contextual:
        body+=['<p>A cobertura é dada pelos componentes efetivamente calculados: correspondência P398/HERON, metal-base adjacente às juntas e resistência/estabilidade da nervura pelo modelo selecionado.</p>',
          '<p>Chapa verificada pelos modelos de flexão e prescrições de furos/arruelas indicados; não se declara verificação geral de modos locais arbitrários.</p>',
          '<p>Ancoragem: cone de concreto e aço calculados; fendilhamento e detalhamento dependem das condições físicas explicitamente confirmadas. Cortante, pryout e interação com cortante não são solicitados no domínio V = 0. Dimensionamento do bloco armado e da fundação permanece fora do escopo.</p>']
    notes={}; seen=set()
    note_keys={'assumptions','scope','tension_scope','stress_interpretation','shear_area_basis',
               'requirements','prescription_checks','remaining_modes','source_model','model_source',
               'method','source','reference','resistance_source','support_condition','branch'}
    for path,node in _nodes(result):
        group=_group(path)
        if group in ('reaction_actions','actual_rods','actual_thread_area_mm2','contact_support_geometry','equilibrium'):
            continue
        clauses=[];refs=[]
        for key,value in node.items():
            if contextual and key in local_scope_markers:continue
            if key in _SKIP or key in ('reasons','pending','missing'):
                continue
            if key in ('source','reference','method','model_source','resistance_source','source_model','source_resistance') and value:
                refs.append(str(value)); continue
            numeric=isinstance(value,(int,float)) and not isinstance(value,bool)
            if numeric and any(term in key.lower() for term in numeric_terms) and (path,key) not in represented:
                clauses.append(_label(key)+': '+_value(value))
            elif key in note_keys and value:
                clauses.append(_label(key)+': '+('; '.join(k+': '+v for k,v in _flat(value)) if isinstance(value,dict) else _value(value)))
            elif value is False and key not in ('passes','normal_pass','shear_pass','passes_weld_metal_only','capacity_bound_satisfied','prescription_satisfied','weld_material_matching'):
                clauses.append(_label(key)+': Não')
        if not clauses:
            # Sources are also collected when attached to an auxiliary calculation.
            reference_ids(refs)
            continue
        text='; '.join(clauses)
        signature=(group,text)
        if signature in seen:
            continue
        seen.add(signature)
        relative='.'.join(path.split('.')[2:])
        notes.setdefault(group,[]).append((_path('result.'+relative) if relative else _label(group),text,reference_ids(refs)))
    washer_notes={}
    for group,rows in list(notes.items()):
        match=re.fullmatch(r'upper_washers\[(\d+)\]',group)
        if not match:continue
        index=int(match[1]);rod=result.get('upper_washers',[])[index].get('id',str(index+1))
        for row in rows:washer_notes.setdefault(tuple(row),[]).append((group,str(rod)))
    common=[]
    for row,identities in washer_notes.items():
        if len(identities)<2:continue
        for group,_ in identities:
            notes[group].remove(row)
        common.append(('Chumbadores '+', '.join(rod for _,rod in identities)+' › '+row[0],row[1],row[2]))
    if common:notes['upper_washers_common']=common
    for group,rows in notes.items():
        if not rows:continue
        body+=['<h3>'+escape(_path('result.'+group))+'</h3>',_table(rows,('Local / condição','Valores e hipóteses','Fonte'))]
    body+=['<h2>6. Referências dos critérios</h2>',_table(((ident,ref) for ref,ident in references.items()),('Fonte','Referência / critério'))]
    body+=['</section><footer>Fim da memória · verificar documentos do detalhe, condições de execução e revisão técnica antes de uso.</footer>']
    return '<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Memória de cálculo — base com nervuras</title><style>'+_CSS+'</style></head><body><main>'+''.join(body)+'</main></body></html>'


_CSS='''body{margin:0;background:#edf1f5;color:#182a3b;font:11px/1.25 Arial,sans-serif}main{max-width:1150px;margin:32px auto;background:white;padding:42px}header{border-bottom:5px solid #246b81;padding-bottom:20px}header>p:first-child{font-size:11px;letter-spacing:2px;color:#246b81}h1{font-size:26px;margin:8px 0}h2{font-size:20px;margin:30px 0 14px}h3{font-size:14px;color:#246b81}table{border-collapse:collapse;width:100%;margin:6px 0 12px;table-layout:auto}th,td{text-align:left;vertical-align:top;border-bottom:1px solid #dce3e9;padding:2px;overflow-wrap:break-word}th{background:#eaf0f4;font-size:12px}tr:nth-child(even){background:#f8fafc}.notice,.alert{padding:14px;border-left:4px solid #c38d28;background:#fff7e5}.alert{border-color:#ae3737}footer{margin-top:36px;border-top:1px solid #bbc9d3;padding-top:14px;color:#546878}.drawing{margin:14px 0;break-inside:avoid}.drawing img{display:block;width:100%;max-height:230mm;object-fit:contain}.drawing figcaption{font-size:10px;color:#546878}@media print{body{background:white;font-size:10px}th,td{padding:3px 5px}table{margin:6px 0 12px}h2{margin:18px 0 8px}h3{margin:12px 0 5px}main{margin:0;padding:0;max-width:none}thead{display:table-header-group}tr{break-inside:avoid}h2,h3{break-after:avoid}header{break-inside:avoid}@page{size:A4;margin:15mm}'''
