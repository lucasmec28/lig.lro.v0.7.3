"""P207 Step6C long tension-rib component, mapped explicitly to this geometry.
The length shortcut is not permission to change an existing short rib. NBR
resistances are separate from the P207 component model and BS design strengths.
"""
from .kernels import positive,finite_result

@finite_result
def long_tension_rib(*,load_path,model_selected,rib_fy_MPa,rib_fu_MPa,
                     whole_section_directly_connected,no_holes_or_copes):
    fy=positive(rib_fy_MPa,'rib fy'); fu=positive(rib_fu_MPa,'rib fu')
    if type(whole_section_directly_connected) is not bool or type(no_holes_or_copes) is not bool:
        raise ValueError('Explicit physical section conditions required')
    reasons=[]
    if model_selected!='P207_long_tension_rib': reasons.append('Explicit P207 long tension-rib selection required')
    if not load_path.get('domain'):
        return dict(component_domain=False,reasons=['Load path outside domain'],production_credit=False)
    g=load_path['geometry']; h=g['rib_height_mm']; b=g['rib_length_mm']; t=g['rib_thickness_mm']
    if h<1.8*b: reasons.append('P207 long-rib shortcut requires h >= 1.8 lr; short-rib rotation branch not implemented')
    if not whole_section_directly_connected or not no_holes_or_copes:
        reasons.append('Intact single plate and direct connection of the whole section required for An=Ag and Ct=1')
    if g['foot_effective_start_mm']!=0 or g['foot_effective_end_mm']!=b or g['root_weld_start_height_mm']!=0 or g['root_weld_end_height_mm']!=h:
        reasons.append('Both physical edges must be fully connected')
    if any(c['rib_line_N_mm']>0 for c in load_path['cells']):
        reasons.append('Compression or mixed-sign load is outside this pure tension component')
    T=-load_path['root_actions']['V_N']
    component=load_path.get('tension_component')
    if T<=0 or not component or not component.get('component_no_prying_bound'):
        reasons.append('Positive tension and qualified no-prying component required')
    qy=fy*t/1.1
    full={name:dict(two_face_resistance_N_mm=2*load_path[name+'_weld_metal']['resistance_N_mm'],
            plate_yield_N_mm=qy,capacity_bound_satisfied=2*load_path[name+'_weld_metal']['resistance_N_mm']>=qy)
            for name in ('foot','root')}
    if not all(q['capacity_bound_satisfied'] for q in full.values()): reasons.append('Weld metal does not develop plate yield per unit length at both edges')
    out=dict(component_domain=not reasons,reasons=reasons,production_credit=False,assembly_approval=False,
        h_required_mm=1.8*b,h_actual_mm=h,actual_geometry_unchanged=True,full_strength_weld_metal=full,
        source_model='SCI P207 Step6C pp35-36 Eqs2.17/2.18, long-rib shortcut',
        source_resistance='NBR8800:2024 6.5.3, 5.2.3/5.2.4.2/5.2.5a, Table9, normal combinations',
        parallel_web_resistance_credited_N=0.,stiffener_count=1,
        pending=['Joint and receiving base metal','Receiver tension paths beyond rib tip (P207 Eq2.19), where applicable',
            'Independent topology review before runtime'])
    if reasons: return out
    A=b*t; beff=component['dg1']['beff_mm']
    # Source has two plates: its factor 2 is NOT applied to this single plate.
    capacities={'gross_yield':A*fy/1.1,'net_rupture':A*fu/1.35,'local_DG1_yield':beff*t*fy/1.1}
    out.update(T_N=T,Ag_mm2=A,An_mm2=A,Ae_mm2=A,Ct=1.,beff_DG1_mm=beff,
        checks={key:dict(demand_N=T,resistance_N=value,utilization=T/value,capacity_bound_satisfied=T<=value)
                for key,value in capacities.items()},
        actual_root_actions=load_path['root_actions'],
        actual_weld_checks_retained=dict(foot=load_path['foot_weld_metal'],root=load_path['root_weld_metal']),
        compression_strip_formula_used=False,free_beam_LTB_imposed=False,
        scope='Published tension-stiffener component; no claim of arbitrary free-beam stability')
    return out
