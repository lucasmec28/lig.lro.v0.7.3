"""Published T-component arithmetic, isolated from design approval.

SCI P398 Appendix G is a published approximation to the alpha chart, not an
exact elastic solution. Only its bracketed alpha range [4.45,8] is used.
HERON 53(1/2), Wald/Sokol/Jaspart 2008 eqs19–22 supply the no-prying bound.
No function accepts an arbitrary alpha, sets leff=DG1 beff, or grants credit.
"""
from math import pi
from .kernels import real, positive, finite_result


@finite_result
def alpha_curve_lambda1(alpha, lambda2):
    alpha=positive(alpha,'alpha'); lam2=real(lambda2,'lambda2',0)
    if not 4.45<=alpha<=8: raise ValueError('Outside published Appendix G alpha range')
    lim1=1.25/(alpha-2.75); lim2=alpha*lim1/2
    return lim1 if lam2>=lim2 else lim1+(1-lim1)*((lim2-lam2)/lim2)**(.185*alpha**1.785)


@finite_result
def alpha_from_geometry(*, m_mm, e_mm, m2_mm):
    m=positive(m_mm,'m'); e=positive(e_mm,'e'); m2=positive(m2_mm,'m2')
    l1=m/(m+e); l2=m2/(m+e)
    if not alpha_curve_lambda1(8,l2)<=l1<=alpha_curve_lambda1(4.45,l2):
        raise ValueError('Geometry outside bracketed Appendix G curves; no alpha extrapolation')
    lo,hi=4.45,8.
    for _ in range(80):
        mid=(lo+hi)/2
        if alpha_curve_lambda1(mid,l2)>l1: lo=mid
        else: hi=mid
    a=(lo+hi)/2
    return dict(alpha=a,lambda1=l1,lambda2=l2,curve_residual=alpha_curve_lambda1(a,l2)-l1,
                source='SCI P398 Appendix G p163',production_credit=False)


@finite_result
def p398_pair_extension_lengths(*, m_mm, e_mm, mx_mm, ex_mm):
    """Table 2.2(b) component parameters, NOT automatic base geometry mapping.
    mx is used as the transverse-stiffener distance m2 for the alpha chart.
    Caller must establish the component correspondence in the domain contract.
    """
    m=positive(m_mm,'m'); e=positive(e_mm,'e'); mx=positive(mx_mm,'mx'); ex=positive(ex_mm,'ex')
    alpha=alpha_from_geometry(m_mm=m,e_mm=e,m2_mm=mx)
    cp=(2*pi*m,pi*m+2*ex)
    nc=(alpha['alpha']*m-(2*m+.625*e)+ex,2*m+.625*e+ex,4*m+1.25*e)
    if min(nc)<=0: raise ValueError('Non-positive effective length outside component domain')
    leff=min(*cp,*nc)
    return dict(alpha_result=alpha,cp_candidates_mm=cp,nc_candidates_mm=nc,
                leff_cp_mm=min(cp),leff_nc_mm=min(nc),leff_mm=leff,
                leff_ini_mm=.85*leff,source='SCI P398 Table 2.2(b), pp12–14; HERON eq21',
                component_mapping_verified=False,production_credit=False)


@finite_result
def heron_no_prying_bound(*, m_mm, n_mm, bolt_stress_area_mm2, leff_ini_mm,
                         plate_thickness_mm, effective_elongation_length_mm):
    """Raw eq20 arithmetic; positive result is NOT full no-prying qualification.
    Lb must be effective elongation length, never an unverified embedment depth.
    """
    m=positive(m_mm,'m'); n=positive(n_mm,'n'); As=positive(bolt_stress_area_mm2,'As')
    leff=positive(leff_ini_mm,'leff_ini'); t=positive(plate_thickness_mm,'tp')
    Lb=positive(effective_elongation_length_mm,'Lb')
    limit=6*m*m*n*As/(leff*t**3)
    return dict(Lb_limit_mm=limit,Lb_mm=Lb,bound_satisfied=Lb>=limit,
                ratio_Lb_limit_over_Lb=limit/Lb,production_credit=False,
                source='HERON 53(1/2) 2008 eq20',component_qualification=False)


@finite_result
def free_rod_compliance_length(*, bolt_stress_area_mm2, free_segments):
    """Lower bound As*sum(L/A), same E, actual free steel only.
    No embedment/bond/head/concrete compliance credited. Segment lengths and
    areas must represent the actual tension path, not overlapping portions.
    """
    As=positive(bolt_stress_area_mm2,'As'); segments=tuple(free_segments)
    if not segments: raise ValueError('Actual free steel segments required')
    Lb=sum(As*positive(L,'segment L')/positive(A,'segment A') for L,A in segments)
    return dict(Lb_lower_bound_mm=Lb,embedment_compliance_credited=False,production_credit=False)


@finite_result
def mapped_tension_component(*, plate_L_mm, plate_B_mm, column_d_mm, column_bf_mm,
        rib_length_mm, rib_thickness_mm, gauge_mm, bolt_a1_mm,
        rib_base_weld_leg_mm, column_flange_base_weld_leg_mm,
        effective_foot_start_mm, effective_foot_end_mm,
        bolt_stress_area_mm2, free_rod_segments, plate_thickness_mm, bolt_force_N):
    """Restricted rotated P398 2.2(b) + DG1/HERON candidate, no production credit.
    Rib must reach physical plate edge exactly (roundoff tolerance 1e-9 mm).
    m2 uses the COLUMN FLANGE–BASE weld, not the vertical rib-root weld.
    The complete root joint/receiver/plate/anchor checks remain separate.
    """
    from .kernels import dg1_tension_strip
    L=positive(plate_L_mm,'L'); B=positive(plate_B_mm,'B')
    d=positive(column_d_mm,'d'); bf=positive(column_bf_mm,'bf')
    lr=positive(rib_length_mm,'lr'); tr=positive(rib_thickness_mm,'tr')
    g=positive(gauge_mm,'g'); a1=positive(bolt_a1_mm,'a1')
    sf=positive(rib_base_weld_leg_mm,'rib-base weld leg')
    sc=positive(column_flange_base_weld_leg_mm,'flange-base weld leg')
    lo=real(effective_foot_start_mm,'foot start',0); hi=positive(effective_foot_end_mm,'foot end')
    As=positive(bolt_stress_area_mm2,'As'); tp=positive(plate_thickness_mm,'tp'); T=real(bolt_force_N,'T',0)
    if hi<=lo or hi>lr: raise ValueError('Effective weld interval outside real rib')
    reasons=[]
    if L<=d or B<bf: reasons.append('Plate does not contain column')
    if abs(lr-(L-d)/2)>1e-9: reasons.append('Rib does not reach physical plate edge')
    if bf<1.33*g: reasons.append('Column flange too narrow to restrict yield-line pattern')
    m=(g-tr)/2-.8*sf; e=(B-g)/2; ex=(L-d)/2-a1; mx=a1-.8*sc
    if min(m,e,ex,mx)<=0: reasons.append('Non-positive P398 component dimension')
    out=dict(component_dimensions_mm=dict(m=m,e=e,ex=ex,mx=mx),reasons=reasons,
             production_credit=False,assembly_approval=False,
             pending=['rib and receiver stiffness/strength/stability','both joints and base metals',
                      'plate local failure modes and washers','anchors and concrete',
                      'independent complete-topology benchmark'])
    if g<=tr:
        out.update(component_domain=False,component_no_prying_bound=False); return out
    dg=dg1_tension_strip(bolt_force_N=T,gauge_mm=g,rib_thickness_mm=tr,bolt_s_mm=a1,
            effective_weld_start_mm=lo,effective_weld_end_mm=hi,plate_thickness_mm=tp)
    out['dg1']=dg
    if not dg['geometric_domain']: reasons.append('DG1 full fan outside effective receiver')
    if reasons:
        out.update(component_domain=False,component_no_prying_bound=False); return out
    try:
        lengths=p398_pair_extension_lengths(m_mm=m,e_mm=e,mx_mm=mx,ex_mm=ex)
    except ValueError as exc:
        reasons.append(str(exc)); out.update(component_domain=False,component_no_prying_bound=False); return out
    compliance=free_rod_compliance_length(bolt_stress_area_mm2=As,free_segments=free_rod_segments)
    bound=heron_no_prying_bound(m_mm=m,n_mm=e,bolt_stress_area_mm2=As,
        leff_ini_mm=lengths['leff_ini_mm'],plate_thickness_mm=tp,
        effective_elongation_length_mm=compliance['Lb_lower_bound_mm'])
    out.update(component_domain=True,lengths=lengths,rod_compliance=compliance,heron=bound,
               component_no_prying_bound=bound['bound_satisfied'])
    if not bound['bound_satisfied']: reasons.append('HERON bound fails; coupled prying branch not implemented')
    return out
