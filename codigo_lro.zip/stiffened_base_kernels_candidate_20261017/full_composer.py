"""Complete selected-domain N/M composer with one physical input contract.
Candidate only. Inputs are not repaired, geometry/materials are not substituted.
"""
import math,sys
from pathlib import Path
from .composition import symmetric_rib_load_path
from .receiver import paired_column_receiver
from .section_checks import check_composed_elastic_stresses
from .triangular_candidate import composed_triangular_stability
from .tension_rib import long_tension_rib
from .completion_components import adjacent_base_metal,central_pressure_bands,central_support_transfer
from .internal_transfer import internal_flange_web_transfer
from .anchorage_adapter import anchorage_zero_shear
from .washer_prescription import axial_washer_prescription
from .report_adapter import collect_check_states


def compose_complete_selected_domain(*,geometry,materials,loads,connections,anchorage,washer,models,defer_anchorage=False):
    if type(defer_anchorage) is not bool:raise ValueError('Explicit anchorage composition mode required')
    from lro.models import Profile
    from lro.base_plate import BasePlate,reactions
    g=geometry;m=materials;co=connections
    if loads['V_N']!=0:raise ValueError('Selected complete composer is static N/M, V external = 0')
    L=g['plate_length_mm'];B=g['plate_width_mm'];d=g['column_depth_mm'];bf=g['column_flange_width_mm']
    tf=g['column_flange_thickness_mm'];tw=g['column_web_thickness_mm'];a=d/2+g['bolt_s_mm'];gauge=g['gauge_mm']
    db=anchorage['rod_diameter_mm'];As=math.pi/4*((db/25.4-.9743/washer['threads_per_inch'])*25.4)**2
    if not 0<As<=math.pi*db*db/4:raise ValueError('Inconsistent actual UNC thread area')
    if len(anchorage['rods'])!=4 or {(r['x'],r['y']) for r in anchorage['rods']}!={(x,y) for x in (-a,a) for y in (-gauge/2,gauge/2)}:
        raise ValueError('Actual four rod coordinates must match the selected symmetric geometry')
    Ag=2*bf*tf+(d-2*tf)*tw
    p=Profile('Explicit physical input',co['column_fabrication'],0.,d,bf,tw,tf,d-2*tf,Ag)
    class GlobalGeometry(BasePlate):
        @property
        def L(self):return L
        @property
        def B(self):return B
        @property
        def a(self):return a
        @property
        def fy(self):return m['plate_fy_MPa']
    c=GlobalGeometry(p,a1=g['bolt_s_mm'],a2=gauge,N=loads['N_N'],M=loads['M_Nmm'],V=0,
        tp=g['plate_thickness_mm'],db=db,fck=anchorage['concrete_fck_MPa'])
    r=reactions(c)
    x0=L/2-r['lc'] if loads['M_Nmm']>=0 else -L/2
    x1=L/2 if loads['M_Nmm']>=0 else -L/2+r['lc']
    actual_rods=[]
    for rod in anchorage['rods']:
        T=r['Ft_max'] if math.isclose(rod['x'],r['T_max_x'],abs_tol=1e-8) else r['Ft_min']
        actual_rods.append(dict(rod,tension=T,shear=0.))
    sides=[];paths=[]
    for side,name in [(-1,'left'),(1,'right')]:
        lr=g['rib_length_mm'];extent=sorted((side*x0-d/2,side*x1-d/2))
        lo=max(0.,min(lr,extent[0]));hi=max(0.,min(lr,extent[1]))
        forces=tuple(rod['tension'] for rod in actual_rods if side*rod['x']>0)
        keys=('rib_length_mm','rib_height_mm','rib_thickness_mm','rib_top_profile_mm','plate_length_mm','column_depth_mm',
              'column_flange_width_mm','plate_width_mm','plate_thickness_mm','gauge_mm','bolt_s_mm')
        args={k:g[k] for k in keys}
        args.update(bolt_forces_N=forces,contact_start_mm=lo,contact_end_mm=hi,contact_pressure_MPa=r['sigma'],
            foot_effective_start_mm=0.,foot_effective_end_mm=lr,root_weld_start_height_mm=0.,root_weld_end_height_mm=g['rib_height_mm'],
            foot_throat_mm=co['rib_foot_throat_mm'],root_throat_mm=co['rib_root_throat_mm'],fuw_MPa=co['rib_fuw_MPa'],combination_kind='normal',
            plate_monolithic_over_rib=co['plate_monolithic'],symmetric_geometry=True,foot_welds_equivalent=co['equivalent_two_rib_fillets'],
            compression_bearing_guaranteed=co['rib_compression_bearing'],
            tension_component_inputs=dict(column_flange_base_weld_leg_mm=co['column_base_leg_mm'],bolt_stress_area_mm2=As,
                free_rod_segments=anchorage['free_rod_segments']))
        path=symmetric_rib_load_path(**args);paths.append(path)
        elastic=check_composed_elastic_stresses(load_path=path,plate_thickness_mm=g['plate_thickness_mm'],plate_fy_MPa=m['plate_fy_MPa'],rib_fy_MPa=m['rib_fy_MPa'])
        model=models[name]
        if model=='P207_long_tension_rib':
            stability=long_tension_rib(load_path=path,model_selected=model,rib_fy_MPa=m['rib_fy_MPa'],rib_fu_MPa=m['rib_fu_MPa'],
                whole_section_directly_connected=co['whole_rib_connected'],no_holes_or_copes=co['intact_rib'])
        else:stability=composed_triangular_stability(load_path=path,model_selected=model,short_edge_support_condition=co['short_edge_support_condition'],rib_fy_MPa=m['rib_fy_MPa'])
        base=adjacent_base_metal(load_path=path,rib_fy_MPa=m['rib_fy_MPa'],rib_fu_MPa=m['rib_fu_MPa'],plate_fy_MPa=m['plate_fy_MPa'],
            plate_fu_MPa=m['plate_fu_MPa'],flange_thickness_mm=tf,column_fy_MPa=m['column_fy_MPa'],column_fu_MPa=m['column_fu_MPa'])
        sides.append(dict(side=side,name=name,load_path=path,elastic=elastic,selected_resistance=stability,adjacent_base_metal=base))
    if not all(p['domain'] for p in paths):
        return dict(production_credit=False,assembly_approval=False,sides=sides,calculation_coverage_complete=False,
            missing=['Load path outside selected geometry domain'],physical_inputs=dict(geometry=g,materials=m,loads=loads))
    central=central_pressure_bands(plate_length_mm=L,plate_width_mm=B,column_depth_mm=d,column_flange_width_mm=bf,
        column_flange_thickness_mm=tf,column_web_thickness_mm=tw,contact_start_x_mm=x0,contact_end_x_mm=x1,
        pressure_MPa=r['sigma'],plate_thickness_mm=g['plate_thickness_mm'],plate_fy_MPa=m['plate_fy_MPa'])
    support=central_support_transfer(central_bands=central,plate_thickness_mm=g['plate_thickness_mm'],plate_fy_MPa=m['plate_fy_MPa'],
        plate_fu_MPa=m['plate_fu_MPa'],column_fy_MPa=m['column_fy_MPa'],column_fu_MPa=m['column_fu_MPa'],
        foot_throat_mm=co['column_base_leg_mm']/math.sqrt(2),fuw_MPa=co['column_base_fuw_MPa'],direct_bearing_guaranteed=co['column_direct_bearing'])
    receiver=paired_column_receiver(left_load_path=paths[0],right_load_path=paths[1],column_flange_thickness_mm=tf,column_web_thickness_mm=tw,
        column_gross_area_mm2=Ag,column_fy_MPa=m['column_fy_MPa'],column_fu_MPa=m['column_fu_MPa'],column_fabrication=co['column_fabrication'],
        column_panel_shear_at_bottom_N=0.,column_axial_compression_envelope_N=max(loads['N_N'],0),
        column_flange_lateral_length_mm=co['column_flange_lateral_length_mm'],root_weld_leg_mm=co['rib_root_throat_mm']*math.sqrt(2),
        column_root_radius_mm=co['column_root_radius_mm'])
    internal=internal_flange_web_transfer(receiver=receiver,column_web_thickness_mm=tw,column_flange_thickness_mm=tf,
        column_fy_MPa=m['column_fy_MPa'],column_fu_MPa=m['column_fu_MPa'],fabrication=co['column_fabrication'],
        internal_throat_mm=co['internal_throat_mm'],internal_fuw_MPa=co['internal_fuw_MPa'],
        continuous_two_faces=co['internal_continuous_two_faces'],connected_height_mm=co['internal_connected_height_mm'])
    anchorargs={k:v for k,v in anchorage.items() if k not in ('rods','free_rod_segments')}
    anchorargs.update(rods=actual_rods,thread_stress_area_mm2=As)
    anchored=(dict(domain=False,status='deferred',reasons=['Ancoragem transferida ao consumidor direto de estados N/M/V.'],pending=[])
        if defer_anchorage else anchorage_zero_shear(**anchorargs))
    washers=[]
    for rod in actual_rods:
        wa=dict(washer)
        # Rod coordinates are actual. Washer is centred on that rod; offsets
        # describe washer centre minus BASE-HOLE centre, not motion of the rod.
        hole_x=rod['x']-wa['center_offset_x_mm'];hole_y=rod['y']-wa['center_offset_y_mm']
        hole_fits=(abs(hole_x)+wa['base_hole_mm']/2<=L/2 and abs(hole_y)+wa['base_hole_mm']/2<=B/2)
        wa.update(rod_diameter_mm=db,rod_material=anchorage['rod_material'],rod_fu_MPa=anchorage['rod_fu_MPa'],tension_N=rod['tension'],
            edge_clearance_x_mm=L/2-abs(rod['x']),edge_clearance_y_mm=B/2-abs(rod['y']),
            nearest_obstacle_clearance_mm=max(0.,min(abs(rod['y'])-g['rib_thickness_mm']/2-co['rib_foot_throat_mm']*math.sqrt(2),
                g['bolt_s_mm']-co['column_base_leg_mm'])))
        wr=axial_washer_prescription(**wa)
        wr['actual_base_hole_center_mm']=(hole_x,hole_y);wr['base_hole_within_plate']=hole_fits
        if wr.get('component_domain'):
            wr['prescription_checks']['base_hole_within_plate']=hole_fits
            wr['prescription_satisfied']=all(wr['prescription_checks'].values())
        washers.append(dict(id=rod['id'],result=wr))
    Nrec=central['V_N']+sum(q['root_actions']['V_N'] for q in paths)
    Mrec=central['M_global_Nmm']+sum(side*(q['root_actions']['M_Nmm']+d/2*q['root_actions']['V_N']) for side,q in zip((-1,1),paths))
    xmin,ymin,xmax,ymax=anchorage['block_bounds_mm']
    contact_supported=(not r['C']) or (xmin<=x0 and x1<=xmax and ymin<=-B/2 and B/2<=ymax)
    missing=[] if contact_supported else ['Actual global compression contact rectangle is not contained in the physical concrete support']
    for s in sides:
        if not s['selected_resistance'].get('component_domain'):missing.extend(s['selected_resistance'].get('reasons',[]))
    for component in (receiver,internal,anchored,support):
        if not component.get('domain'):missing.extend(component.get('reasons',[]))
    missing.extend(anchored.get('pending',[]))
    for w in washers:
        if not w['result']['component_domain']:missing.extend(w['result']['reasons'])
    out=dict(candidate_only=True,production_credit=False,assembly_approval=False,calculation_coverage_complete=not missing,missing=missing,
        physical_inputs=dict(geometry=g,materials=m,loads=loads,connections=co,anchorage=anchorage,washer=washer,models=models),
        reaction_actions={k:r[k] for k in ('C','C_x','lc','sigma','Ft_max','Ft_min','T_max_x','T_min_x')},
        contact_support_geometry=dict(domain=contact_supported,actual_contact_rectangle_mm=(x0,-B/2,x1,B/2),
            physical_support_bounds_mm=anchorage['block_bounds_mm'],source='Actual geometry, no fictitious concrete beyond support'),
        concrete_contact=dict(demand_MPa=r['sigma'],resistance_MPa=.85*anchorage['concrete_fck_MPa']/1.4,
            capacity_bound_satisfied=r['sigma']<=.85*anchorage['concrete_fck_MPa']/1.4,source='NBR8800 6.6.5, no confinement credit'),
        grout=dict(required_fck_MPa=2*anchorage['concrete_fck_MPa'],actual_fck_MPa=co['grout_fck_MPa'],
            capacity_bound_satisfied=co['grout_fck_MPa']>=2*anchorage['concrete_fck_MPa'],source='NBR8800 6.7.1.5d'),
        actual_rods=actual_rods,actual_thread_area_mm2=As,sides=sides,central_plate=central,central_supports=support,receiver=receiver,
        internal_transfer=internal,anchorage=anchored,upper_washers=washers,
        equilibrium=dict(residual_N=Nrec-loads['N_N'],residual_M_Nmm=Mrec-loads['M_Nmm']),
        assembly_state='complete_selected_calculations_review_required' if not missing else 'incomplete_selected_domain',
        excluded_scope=['Global column/frame design and reinforced foundation/soil design',
            'Fatigue, seismic, nonzero global shear, biaxial bending and nonsymmetric geometry'])
    # Contextualize generic kernel-scope notes only in this composed result.
    # The standalone kernels and their historical evidence remain unchanged.
    for s in sides:
        s['load_path']['pending']=[]
        s['elastic']['member_stability']=dict(state='selected_component_calculated' if s['selected_resistance'].get('component_domain') else 'outside_selected_domain',
            result_reference='selected_resistance',not_an_automatic_capacity_pass=True)
        s['selected_resistance']['pending']=[]
        if s['load_path'].get('tension_component'):
            tc=s['load_path']['tension_component'];tc['pending']=[]
            tc['dg1']['tension_scope']='Composed with selected resistance, receiver, anchors and washer prescription; inspect each result'
    receiver['pending']=[]
    out['review_gate']='Independent final complete-topology audit required; no runtime release'
    out['check_states']=collect_check_states(out)
    return out
