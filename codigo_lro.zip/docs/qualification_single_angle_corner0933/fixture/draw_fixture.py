"""Dimensioned qualification schematic; nominal envelopes, no inferred rolled radii."""
from pathlib import Path
import json,math,os
os.environ.setdefault('MPLCONFIGDIR','/tmp/single_angle_corner_mpl')
os.environ.setdefault('XDG_CACHE_HOME','/tmp/single_angle_corner_cache')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon,Rectangle
ROOT=Path(__file__).resolve().parent
D=json.loads((ROOT/'FIXTURE_INPUT.json').read_text());g=D['geometry'];r=math.sqrt(2)
fig,(a,b)=plt.subplots(1,2,figsize=(15,9),gridspec_kw={'width_ratios':[1.3,1]})
fig.suptitle('C1-1L | 100 kN static tensile corner gusset',fontsize=20,fontweight='bold',y=.98)
a.add_patch(Rectangle((-154,-220),308,1190,color='#e4e9ef',ec='#607084'))
a.add_patch(Rectangle((154,-158.5),760,317,color='#e4e9ef',ec='#607084'))
for yy in [-151.9,151.9]:a.add_patch(Rectangle((-138.6,yy-6),277.2,12,color='#d3ae45'))
a.add_patch(Polygon(g['gusset_polygon'],closed=True,facecolor='#dcecf5',edgecolor='#1f5e7c',linewidth=2))
for key in ['beam_seam','column_seam']:
 p,q=g[key];a.plot([p[0],q[0]],[p[1],q[1]],color='#286747',linewidth=5)
def xy(u,v):return [(u-v)/r,(u+v)/r]
a.add_patch(Polygon([xy(u,v) for u,v in [(630,-22.1),(970,-22.1),(970,54.1),(630,54.1)]],facecolor='#edaa86',alpha=.8,edgecolor='#a44427'))
for v in [-22.1,54.1]:
 p,q=xy(650,v),xy(870,v);a.plot([p[0],q[0]],[p[1],q[1]],color='#a83a28',linewidth=4)
a.plot([0,780],[0,780],'--',c='#6c627b',lw=1)
a.scatter([0],[0],s=25,c='black');a.text(-110,25,'O (0,0)',fontsize=10)
a.annotate('',xy=xy(1100,0),xytext=xy(975,0),arrowprops={'arrowstyle':'->','lw':2});a.text(600,870,'P = 100 kN\nprojected v = 0',fontsize=11)
a.text(210,350,'One L76.2 × 7.94\non +z face',fontsize=11,bbox={'facecolor':'white','alpha':.9,'edgecolor':'none'})
a.text(355,810,'Gusset 12 mm\n600 × 600, 30 mm clip',fontsize=10)
a.text(330,80,'Beam W310 × 52',fontsize=11)
a.text(-115,540,'Column\nW310 × 97 (H)',fontsize=10)
a.text(210,180,'2 × 6 mm root fillets; Leff 550',fontsize=9,color='#286747')
a.text(102,240,'2 × 6 mm; 550',fontsize=9,color='#286747',rotation=90)
a.text(235,660,'Two 5 mm fillets\nu650…870 (L220)',fontsize=10,color='#a44427')
a.set(xlim=(-220,930),ylim=(-230,990),aspect='equal',xlabel='x (mm)',ylabel='y (mm)');a.set_title('Elevation | same complete-cut joint and two roots',fontsize=12);a.grid(alpha=.12)
# Real nominal one-angle section. Sharp envelopes are illustrative only.
b.add_patch(Rectangle((-55,-6),155,12,color='#dcecf5',ec='#1f5e7c'))
section=[(-22.1,6),(54.1,6),(54.1,13.94),(-14.16,13.94),(-14.16,82.2),(-22.1,82.2)]
b.add_patch(Polygon(section,facecolor='#edaa86',edgecolor='#a44427',linewidth=2))
for verts in [[(-27.1,6),(-22.1,6),(-22.1,11)],[(54.1,6),(59.1,6),(54.1,11)]]:b.add_patch(Polygon(verts,color='#a83a28'))
b.axhline(0,c='#1f5e7c',ls='--',lw=1);b.scatter([0],[28.1],c='#a44427',s=55);b.scatter([0],[0],facecolor='white',edgecolor='#1f5e7c',s=55,zorder=5)
b.annotate('Actual centroid\nv0, z+28.1',xy=(0,28.1),xytext=(28,40),arrowprops={'arrowstyle':'->'},fontsize=10)
b.annotate('Nominal connection axis z0\nNBR static end idealization',xy=(0,0),xytext=(-48,-30),arrowprops={'arrowstyle':'->'},fontsize=10)
b.annotate('Faying face z+6',xy=(40,6),xytext=(45,22),arrowprops={'arrowstyle':'->'},fontsize=10)
b.annotate('',xy=(-38,6),xytext=(-38,82.2),arrowprops={'arrowstyle':'|-|'})
b.text(-42,44,'76.2',rotation=90,ha='right',va='center',fontsize=10)
b.text(-51,92,'No opposite-face angle or weld',fontsize=11,fontweight='bold')
b.text(-51,-47,'Real raw spatial moment: 2.81 kNm\n28.1 mm = 22.1 + 6 mm; no cancellation',fontsize=11,color='#a44427')
b.set(xlim=(-60,110),ylim=(-58,100),aspect='equal',xlabel='v (mm)',ylabel='z (mm)');b.set_title('Section normal to brace | one physical angle',fontsize=12);b.grid(alpha=.12)
fig.text(.07,.018,'Qualification schematic. Not fabrication/WPS approval. Nominal envelopes only; Gerdau rolled radii remain unknown. Full dimensions, cuts and materials: FIXTURE_INPUT.json.',fontsize=9)
fig.subplots_adjust(left=.06,right=.97,bottom=.10,top=.90,wspace=.24)
fig.savefig(ROOT/'FIXTURE.svg');fig.savefig(ROOT/'FIXTURE.png',dpi=150)
