#!/usr/bin/env python3
"""Independent 1L static planar corner crosscheck; no production imports/outputs.
Units: N, mm, MPa, N mm. Hardcoded inputs independently transcribed from
FULL_JOINT_CONTRACT and locally inspected NBR/Gerdau source evidence.
"""
from math import sqrt, tan, pi, hypot
import json
from pathlib import Path

P=100000.; b=76.2; t=7.94; Ag=1148.; ec=22.1; tg=12.
fy=250.; fu=400.; fw=485.; ga1=1.10; ga2=gw2=1.35
L=220.; u0=650.; u1=870.; s=5.; vh=-22.1; vt=54.1
c=1/sqrt(2); Fh=P*(1-ec/b); Ft=P*ec/b
ct=max(1-ec/L, .5)

def checked(demand, resistance, **extra):
    return {'demand':demand,'resistance':resistance,'utilization':demand/resistance,**extra}

def cross(r,f): return r[0]*f[1]-r[1]*f[0]
def add(a,b): return [x+y for x,y in zip(a,b)]
def neg(a): return [-x for x in a]
def xy(u,v): return [c*(u-v),c*(u+v)]
def uv(x,y): return [c*(x+y),c*(y-x)]

angle={
 'gross_yield':checked(P,Ag*fy/ga1),
 'effective_rupture':checked(P,ct*Ag*fu/ga2,Ct=ct,Ae=ct*Ag,Ct_lower_bound=.5),
 'nominal_block_yield_branch':checked(P,.6*fy*t*L/ga2,Av=t*L,At=0.),
 'nominal_block_rupture_branch':checked(P,.6*fu*t*L/ga2,Av=t*L,At=0.),
}
weld_R=.6*fw*(s/sqrt(2))*L/gw2
lines={}
for name,F,v in [('heel',Fh,vh),('toe',Ft,vt)]:
    lines[name]={'v':v,'force':F,'fraction':F/P,'uniform_N_per_mm':F/L,
      'weld':checked(F,weld_R,throat=s/sqrt(2)),
      'angle_substrate_yield':checked(F,.6*fy*L*min(s,t)/ga1),
      'angle_substrate_rupture':checked(F,.6*fu*L*min(s,t)/ga2),
      'gusset_substrate_yield':checked(F,.6*fy*L*min(s,tg)/ga1),
      'gusset_substrate_rupture':checked(F,.6*fu*L*min(s,tg)/ga2)}

# Equal projected tractions: old two-face P/2 per angle, new one-face P.
old_projected=[2*(P/2)*(1-ec/b)/L,2*(P/2)*(ec/b)/L]
new_projected=[Fh/L,Ft/L]
assert old_projected==new_projected
assert abs(Fh+Ft-P)<1e-9 and abs(Fh*vh+Ft*vt)<1e-8

polygon=[[184.,158.5],[754.,158.5],[754.,758.5],[154.,758.5],[154.,188.5]]
polyuv=[uv(*p) for p in polygon]
def chord(u):
    vs=[]
    for (a,va),(z,vz) in zip(polyuv,polyuv[1:]+polyuv[:1]):
        if min(a,z)-1e-9<=u<=max(a,z)+1e-9:
            if abs(z-a)>1e-12: vs.append(va+(u-a)*(vz-va)/(z-a))
    return min(vs),max(vs)
def tension_section(N,vlo,vhi):
    width=vhi-vlo; centroid=(vhi+vlo)/2; A=width*tg; S=tg*width**2/6
    M=-N*centroid
    extreme=[N/A-abs(M)/S,N/A+abs(M)/S]
    return {'N':N,'v_low':vlo,'v_high':vhi,'width':width,'centroid_v':centroid,
      'area':A,'section_modulus':S,'moment':M,'normal_stress_extremes':extreme,
      'yield_utilization':extreme[1]/(fy/ga1),'supplemental_gross_rupture_utilization':extreme[1]/(fu/ga2)}
spread=L*tan(pi/6)
whit=tension_section(P,vh-spread,vt+spread)
assert chord(u0)[0]<whit['v_low']<whit['v_high']<chord(u0)[1]
body=[{'u':u,**tension_section(P*(u1-u)/L,*chord(u))} for u in (650.,700.,760.,800.,870.)]
# Analytic proof over [650,870]: b(u)=2*(K-u), vbar constant.
K=sqrt(2)*(754+758.5)/2; vbar=c*(758.5-754)
# sigma_max/P = (u1-u)/L * [1/(2*tg*(K-u))+6|vbar|/(4*tg*(K-u)^2)].
# With q=K-u, a=K-u1, A=1/(2tg), B=1.5|vbar|/tg, the derivative
# in q has numerator q*(A*a-B)+2*a*B. Both coefficients are positive here.
assert abs(vbar-body[0]['centroid_v'])<1e-10
assert abs(2*(K-u0)-body[0]['width'])<1e-10
a=K-u1; A=1/(2*tg); B=1.5*abs(vbar)/tg
body_proof={'K':K,'vbar':vbar,'q_range':[K-u1,K-u0],
  'derivative_q_linear_coefficient':A*a-B,'derivative_q_constant':2*a*B,
  'monotone_decreasing_with_u':A*a-B>0 and 2*a*B>0,'maximum_at_u':u0}
assert body_proof['monotone_decreasing_with_u']

# A conservative whole-P ordinary partial tear-path envelope remains identical.
gusset_envelope=checked(P,.6*fy*tg*L/ga2,Av=tg*L,At=0.,gamma=ga2)
# Representative physical U/L blocks: shear rays stop on x754 or y758.5.
# All rear transverse boundaries at u650 are between real free right/top edges.
vlo,vhi=chord(u0)
def forward_exit(v):
    ux=sqrt(2)*754+v; uy=sqrt(2)*758.5-v
    return min(ux,uy),('right x=754' if ux<uy else 'top y=758.5')
def path(name, shear_v, Atwidth, demand):
    exits=[forward_exit(v) for v in shear_v]
    lengths=[u-u0 for u,_ in exits]
    Av=tg*sum(lengths); At=tg*Atwidth
    branch_r=(.6*fu*Av+.5*fu*At)/ga2
    branch_y=(.6*fy*Av+.5*fu*At)/ga2
    return checked(demand,min(branch_r,branch_y),name=name,Av=Av,At=At,
      shear_lines=[{'v':v,'u_start':u0,'u_end':u,'boundary':edge} for v,(u,edge) in zip(shear_v,exits)],
      rupture_branch=branch_r,yield_branch=branch_y,Cts=.5)
paths=[
 path('U both external footprint', [vh-s,vt+s],b+2*s,P),
 path('U heel footprint',[vh-s,vh],s,Fh),
 path('U toe footprint',[vt,vt+s],s,Ft),
 path('L heel to right free edge',[vh],vh-vlo,Fh),
 path('L both to right free edge',[vt+s],vt+s-vlo,P),
 path('L toe to top free edge',[vt],vhi-vt,Ft),
 path('L both to top free edge',[vh-s],vhi-(vh-s),P),
]
for p in paths: assert p['resistance']>p['demand']

# Independently derive planar UFM root shares and complete-cut joint equilibrium.
H=V=P*c; eb=158.5; colx=154.; alpha=beta=315.
Hc=colx*V/(eb+beta); Hb=H-Hc; Vb=eb*Hb/alpha; Vc=V-Vb
B=[colx+alpha,eb]; C=[colx,eb+beta]; J=[colx,0.]
Rbrace=[H,V]; Fb=[Hb,Vb]; Fc=[Hc,Vc]
assert hypot(*(add(add(Rbrace,neg(Fb)),neg(Fc))))<1e-8
assert abs(cross(B,Fb)+cross(C,Fc))<1e-7
D=[1000.,0.]; FD=[-30710.67811865475,-50000.]; MD=62300000.
U=[0.,1000.]; FU=[10000.,-500000.]; MU=10000000.
LL=[0.,-1000.]
FJ=add(FD,Fb)
MJ=MD+cross([D[0]-J[0],D[1]-J[1]],FD)+cross([B[0]-J[0],B[1]-J[1]],Fb)
FL=neg(add(add(FD,FU),Rbrace))
ML=-(MD+cross(D,FD)+MU+cross(U,FU)+cross(LL,FL))
# Action on column combines the actual recovered interface and gusset column root.
Fcol=add(FJ,Fc); Mcol=MJ+cross(J,FJ)+cross(C,Fc)
beam_residual=[*add(add(FD,Fb),neg(FJ)),MD+cross(D,FD)+cross(B,Fb)-MJ-cross(J,FJ)]
col_residual=[*add(add(add(FU,FL),FJ),Fc),MU+cross(U,FU)+ML+cross(LL,FL)+MJ+cross(J,FJ)+cross(C,Fc)]
assembly_residual=[*add(add(add(FD,FU),FL),Rbrace),MD+cross(D,FD)+MU+cross(U,FU)+ML+cross(LL,FL)]
for residual in (beam_residual,col_residual,assembly_residual): assert max(map(abs,residual))<1e-7
bf=167.; tf=13.2; tw=7.6; d=317.; h0=d-tf; Af=bf*tf; Aw=(d-2*tf)*tw; A0=2*Af+Aw
Ftop=FJ[0]*Af/A0-MJ/h0; Fbottom=FJ[0]*Af/A0+MJ/h0; Nweb=FJ[0]*Aw/A0
assert abs(Ftop+Fbottom+Nweb-FJ[0])<1e-8
assert abs((Fbottom-Ftop)*h0/2-MJ)<1e-7
Qtop=-(FU[0]+Hc+Ftop); Qbottom=Qtop-Nweb
roots={}
for name,F in [('beam',Fb),('column',Fc)]:
    resultant=hypot(*F); qdesign=1.25*resultant/550
    roots[name]={'Fx':F[0],'Fy':F[1],'M':0.,'q_design_total':qdesign,
      'weld_utilization':qdesign/(2*6/sqrt(2)*(.6*fw/gw2))}

# Real z geometry; no fictional second angle and no asserted 3D cancellation.
zface=tg/2; zcg=zface+ec
spatial={
 'gusset_midplane_z':0.,'faying_surface_z':zface,'angle_centroid_z':zcg,
 'connected_leg_nominal_z_range':[zface,zface+t],
 'outstanding_leg_nominal_z_range':[zface,zface+b],
 'root_radius':None,'toe_radius':None,'toe_flat':None,
 'bar_centroid_to_faying_moment_norm':P*ec,
 'faying_to_gusset_midplane_moment_norm':P*zface,
 'raw_centroid_to_midplane_moment_vector':[-zcg*V,zcg*H,0.],
 'raw_centroid_to_midplane_moment_norm':P*zcg,
 'interpretation':'Real one-face geometry. Ordinary static angle-end axis mismatch is neglected only under the declared NBR6.1.8.2 nominal planar connection idealization. The 3D raw moment is not physically zero.'}

detail={'minimum_fillet':5.,'ordinary_maximum_fillet':t-1.5,'specified':s,
 'length_ratio_L_over_s':L/s,'long_weld_beta':min(1.,1.2-.002*L/s),
 'minimum_effective_length':max(4*s,40.),'end_margin':20.,
 'minimum_overlap':max(5*min(t,tg),25.),'actual_free_end_to_forward_weld_end':u1-630.,
 'angle_end_xy_heel':xy(630,vh),'angle_end_xy_toe':xy(630,vt)}
assert detail['minimum_fillet']<=s<=detail['ordinary_maximum_fillet']
assert detail['long_weld_beta']==1.
assert L>=detail['minimum_effective_length']
assert detail['actual_free_end_to_forward_weld_end']>=detail['minimum_overlap']

out={
 'scope':'Independent static tensile nominal planar 1L corner crosscheck; no production code imported or edited.',
 'angle':angle,'weld_lines':lines,'spatial_geometry_and_exemption':spatial,'detailing':detail,
 'gusset':{'Whitmore':whit,'body_sections':body,'body_extremum_proof':body_proof,
   'ordinary_partial_path_envelope':gusset_envelope,'independent_representative_physical_paths':paths,
   'old_2L_projected_N_per_mm':old_projected,'new_1L_projected_N_per_mm':new_projected,
   'inplane_projected_loads_identical':old_projected==new_projected},
 'joint':{'root_actions':roots,'beam_to_column_at_J':{'force':FJ,'moment':MJ},
   'derived_lower_cut':{'force':FL,'moment':ML},'column_combined_about_O':{'force':Fcol,'moment':Mcol},
   'flange_forces':{'top':Ftop,'bottom':Fbottom,'Nweb':Nweb},
   'beam_web_weld_resultant':hypot(Nweb,FJ[1]),
   'panel_shear':{'top':Qtop,'bottom':Qbottom},
   'top_compression_active':Ftop<0.,'continuity_upper_overlap_absolute_load':abs(Ftop)+Hc,
   'residuals':{'beam':beam_residual,'column':col_residual,'assembly':assembly_residual}},
 'governing_changed_component':{'name':'angle nominal through-leg block envelope','utilization':angle['nominal_block_yield_branch']['utilization']},
}
Path(__file__).with_name('INDEPENDENT_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'angle':angle,'weld_lines':lines,'spatial':spatial,'joint':out['joint'],
 'max_representative_gusset_path_utilization':max(p['utilization'] for p in paths)},indent=2))
