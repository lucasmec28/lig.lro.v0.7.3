"""Validate source-derived 1L fixture and invariants without importing production."""
from pathlib import Path
import json,math,hashlib,sys
P=Path(__file__).resolve().parent;W=P.parent
load=lambda p:json.loads(p.read_text())
one=load(P/'fixture/ORACLE.json');two=load(W/'corner_gusset_strong_axis_scope/full_joint_fixture/ORACLE.json')
g=load(P/'fixture/GUSSET_PATHS.json');oldg=load(W/'corner_gusset_strong_axis_scope/full_joint_fixture/crossreview/INDEPENDENT_GUSSET_REVIEW.json')
x=load(P/'crosscheck/INDEPENDENT_RESULTS.json');rows=[]
def near(label,a,b):
 ok=math.isclose(a,b,rel_tol=1e-10,abs_tol=1e-7);rows.append(dict(label=label,actual=a,expected=b,pass_=ok));assert ok,(label,a,b)
def eq(label,a,b):
 ok=a==b;rows.append(dict(label=label,pass_=ok));assert ok,label
baseline={c['id']:c for c in two['checks']};change=0
for q in one['checks']:
 key=q['id'].replace('angle_single_','angle_each_').replace('_weld_positive_face','_weld_each_face').replace('_substrate_positive_face','_substrate_each_face')
 r=baseline[key];factor=2 if key!=q['id'] else 1;change+=factor==2
 for field,mult in [('demand',factor),('resistance',1),('utilization',factor)]:near(q['id']+'.'+field,q[field],mult*r[field])
 assert q['pass_']
eq('nine_changed_rows',change,9)
for key in ['force_model','joint_beam_to_column','complete_cuts','equilibrium_residuals','seams','joint_distribution','continuity_per_plate_traction','panel']:
 eq('invariant.'+key,one[key],two[key])
for key in ['actual_body_chord','rupture_paths','ordinary_path_zero_tension_lower_bound','support_edge_sections','whitmore']:
 eq('gusset.'+key,g[key],oldg[key])
checks={q['id']:q for q in one['checks']}
for key,r in [('angle_single_gross',x['angle']['gross_yield']),('angle_single_effective_rupture',x['angle']['effective_rupture']),('angle_single_nominal_through_leg_block',x['angle']['nominal_block_yield_branch'])]:
 for fld in ['demand','resistance','utilization']:near('new_independent.'+key+'.'+fld,checks[key][fld],r[fld])
for line in ['heel','toe']:
 for tail,src in [('weld','weld'),('angle_substrate','angle_substrate_yield'),('gusset_face_substrate','gusset_substrate_yield')]:
  r=x['weld_lines'][line][src];key='brace_'+line+'_'+tail+'_positive_face'
  for fld in ['demand','resistance','utilization']:near('new_independent.'+key+'.'+fld,checks[key][fld],r[fld])
for face,fn,sn in [('beam','Hb','Vb'),('column','Hc','Vc')]:
 r=x['joint']['root_actions'][face]
 near('crosscheck.'+fn,one['force_model'][fn],r['Fx']);near('crosscheck.'+sn,one['force_model'][sn],r['Fy'])
 near('crosscheck.'+face+'.weld',checks[face+'_root_weld']['utilization'],r['weld_utilization'])
for k,j in [('Fx',0),('Fy',1)]:near('crosscheck.interface.'+k,one['joint_beam_to_column'][k],x['joint']['beam_to_column_at_J']['force'][j])
near('crosscheck.interface.M',one['joint_beam_to_column']['M'],x['joint']['beam_to_column_at_J']['moment'])
for key,other in [('Qtop','top'),('Qbottom','bottom')]:near('crosscheck.panel.'+key,one['panel'][key],x['joint']['panel_shear'][other])
near('crosscheck.whitmore.width',one['geometry']['whitmore_b'],x['gusset']['Whitmore']['width'])
near('crosscheck.whitmore.peak',checks['gusset_whitmore_gross_peak_tension']['demand'],max(x['gusset']['Whitmore']['normal_stress_extremes']))
near('crosscheck.body.peak',checks['gusset_actual_body_chord_gross']['demand'],max(x['gusset']['body_sections'][0]['normal_stress_extremes']))
near('crosscheck.raw_spatial_moment',one['spatial_idealization']['raw_Mout_Nmm'],x['spatial_geometry_and_exemption']['raw_centroid_to_midplane_moment_norm'])
par=load(P/'parameterized/EXPECTED_PARAMETERIZED.json')
for name,row in par['comparisons'].items():
 assert row['identical']
 near('parameterized.'+name+'.angle_count',row['one_angle_demand'],2*row['two_angle_each_demand'])
 near('parameterized.'+name+'.weld_count',row['one_angle_heel_weld_ratio'],2*row['two_angle_each_heel_weld_ratio'])
 assert row['body_compression_present']==('shifted_compression' in name)
# Fixed baseline runtime bytes are only hashed, never imported or executed.
before=load(P/'evidence/RUNTIME_BEFORE.json');approved=load(W/'review0932/validation_runs/RUNTIME_HASHES0932.json')
eq('approved_runtime_snapshot',before,approved)
after={k:hashlib.sha256((W/'review0932/source0932'/k).read_bytes()).hexdigest() for k in before}
eq('runtime_134_unchanged',before,after)
(P/'evidence/RUNTIME_AFTER.json').write_text(json.dumps(after,indent=2)+'\n')
source=load(P/'evidence/SOURCE_HASHES.json')
for path,h in source.items():eq('immutable_source.'+path,hashlib.sha256((W/path).read_bytes()).hexdigest(),h)
record=dict(decision='GO_BOUNDED_STATIC_NOMINAL_PLANAR_1L_METHOD_QUALIFICATION',production_implemented=False,production_executed=False,full_fixture_checks=86,changed_brace_rows=9,unchanged_rows=77,gusset_physical_paths=len(g['rupture_paths']),parameterized_cases=len(par['cases']),independent_comparisons=len(rows),all_pass=True,production_runtime_files_unchanged=len(before),max_1L_changed_utilization=checks['angle_single_nominal_through_leg_block']['utilization'],spatial_scope='Explicit NBR6.1.8.2 ordinary single-angle end-axis midplane idealization; physical28.1mm and raw2.81kNm do not cancel; exact3D equilibrium not claimed',validation_rows=rows,python=sys.version)
(P/'VALIDATION.json').write_text(json.dumps(record,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({k:v for k,v in record.items() if k!='validation_rows'},indent=2))
