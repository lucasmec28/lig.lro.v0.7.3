# Welded single-angle corner qualification

**GO for a parameterized nominal planar static 1L adapter.** This is a method/fixture qualification, with no production implementation or release approval.

Read `SINGLE_ANGLE_CORNER_CONTRACT.md` first. Its essential scope is the explicitly adopted NBR 6.1.8.2 ordinary static angle-end idealization: the real one-sided 28.1 mm offset and raw 2.81 kNm moment are recorded, not falsely canceled. The source does not prescribe a numerical midplane projection; the implementation declares that engineering idealization openly.

Evidence:
- `fixture/FIXTURE_INPUT.json`: complete actual geometry, independent materials, named concurrent cuts and 1L position.
- `fixture/ORACLE.json`: all 86 recalculated component rows; nine changed brace rows and 77 invariant rows.
- `fixture/GUSSET_PATHS.json`: eight physical gusset U/L paths and partial-path envelope, with the common gusset counted once.
- `fixture/FIXTURE.svg` and `.png`: visually checked elevation and real one-angle section.
- `parameterized/EXPECTED_PARAMETERIZED.json`: nine cases, including real changed geometry/catalog/material/continuity and genuine compressed-region rejection witnesses.
- `crosscheck/SOURCE_AND_CROSSCHECK.md` and `INDEPENDENT_RESULTS.json`: separately authored source/calculation crosscheck.
- `VALIDATION.json`: 352 passing observations/comparisons, 134 unchanged production runtime hashes.
- `PROVENANCE.md`: exact distinction between adapted prior independent calculations, fresh independent crosscheck and untouched production.
- `MANIFEST.json` and `SHA256SUMS`: this final deliverable snapshot. Evidence subfolder binds original source and before/after runtime bytes.

## Reproduce

Run from `/workspace/scratch/200bd23c4a9b`:

```
python single_angle_corner_scope/fixture/build_fixture.py
python single_angle_corner_scope/fixture/build_gusset_paths.py
python single_angle_corner_scope/parameterized/build_expected.py
python single_angle_corner_scope/crosscheck/independent_check.py
python single_angle_corner_scope/validate_qualification.py
```

The full fixture, gusset path and fresh crosscheck scripts use standard-library Python. The parameterized mechanics script uses NumPy polynomial roots. Tested environment: Python3.12.14, NumPy2.3.5. Optional drawing script uses Matplotlib3.10.8; image pixels were inspected after rendering. No production module is imported or executed. The final validator uses existing prior qualification files and the accepted production runtime hash list solely for invariant/source/hash comparison.

The full C1 angle remains Gerdau L76.2×76.2×7.94, with two5 mm ×220 mm longitudinal fillets carrying all100 kN. Governing changed-component utilization0.515228. Shared gusset, both roots, receiving members, continuity and panel retain their complete concurrent-action calculation.

No further literature pass or blanket finite-element prerequisite is needed for this precisely declared scope. Full spatial transfer, fatigue/seismic loading and actual compressed gusset regions are separate, explicitly unqualified increments.
