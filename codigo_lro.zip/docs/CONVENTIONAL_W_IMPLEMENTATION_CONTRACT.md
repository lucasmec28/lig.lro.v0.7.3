# Conventional M004 W splice: finite current-NBR implementation contract

**Parametric update:** `PARAMETRIC_DOMAIN_ADDENDUM.md` supersedes the fixed-profile/dimension admission restrictions below. W310×97 remains a benchmark; other profiles and geometries are admitted by computed inequalities and the independent varied-profile fixtures.

Date: 2026-10-10. Independent qualification of the newly supplied Fakury design route. No production file, frozen093 or frozen094 was edited. Numerical work imports no production module.

## Decision

**GO to implement the bounded conventional route below as a separate force model.** The books now supply the accepted analytical premises that were missing: the flange-only N/M allocation, the V/Ve web transfer, the bolt-row supported cover model and the conventional web L/U block treatment. It is unnecessary to invent a pure-couple web-block capacity for this route: when V=0 its web force and web moment are both zero.

**No required local resistance law remains unidentified within the bounded domain below.** The remaining work is finite implementation and independent implementation validation of the listed checks, not another open-ended literature search. This conclusion does not complete the old retained-web-share model. That model still needs its generalized Nw/Mw/block interaction basis.

**This research package is not a production release or a complete assembly pass.** Its ten fixtures verify the newly qualified mechanics/compression/web subchecks. The existing bolt, bearing, flange-tension/block, detailing and member checks must be connected to the new forces and independently tested before the app can return a complete connection result. Actual global member stability and service/slip requirements are separate, explicitly identified project prerequisites, not missing web-block formulas.

## 1. Bounded first implementation

Use a distinct family/model identifier; never silently change an old saved project's allocation. The first qualified specialization is:

- Identical, constant-section, coaxial rolled W members, normal static ultimate combinations, major-axis N/M/V only. No torsion, minor-axis bending, fatigue, seismic ductility qualification or direct end-bearing credit.
- The actual eight-cover arrangement: two outer flange plates, four separate inner strips, two web covers. Equal flange plate thickness and material; outer width = twice one inner width; centered, symmetric bolt lines and matched outer/inner load paths. Hence each outer takes F/2 and each inner F/4. These are separate plates, never a fabricated composite box.
- Keep the independently qualified starting geometry: W310×97, d308, bf305, tf15.4, tw9.9 mm; outer240×16, each inner120×16, inner clear band50; each web200×10; gap10; longitudinal pitches60; nearest member-end bolts40 from the end, hence stations±45; web second station±105; web levels−60,0,+60. Flange four rows each side at45,105,165,225. Cover end distance40. Standard M20 holes physical22/net24 unless documented drilled-hole treatment changes the net deduction.
- The scalar web-path qualification is tied to this actual complete 2×3 grid, e=75 mm and its real free edges. Do not expose arbitrary eccentricity, missing bolts, nonuniform/staggered grids, slots, cuts or unequal web plates under the same approval. Other profile/plate sizes may be added through the same finite constraint-and-fixture procedure, not by claiming that the one numeric example certifies every shape.
- Small geometry changes that only make an admitted limit state stronger still need the fit/detail checks and an explicit domain rule. Avoid both silent extrapolation and a blanket rejection of every future extension.

At this stage fixed geometry with freely varying signed N/M/V is a useful, honestly bounded design module. Compression and combined actions are real supported cases, not force values converted to absolute tension. Material and physical assembly details must match the report.

## 2. One coherent action model

Use tension-positive N, h0=d−tf=292.6 mm:

- Ftop=N/2−M/h0; Fbottom=N/2+M/h0.
- Nw=0 and Mw at the splice center=0.
- Each web cover carries V/2 and the associated eccentric transfer. On the right complete bolt group: Fx=0, Fy=V, Cg=−75V. On the left: Fx=0, Fy=−V, Cg=−75V, with the declared global sign convention.
- With local coordinates x=±30,y=−60,0,+60, J=sum(x²+y²)=19,800 mm², qx=−Cg y/J and qy=Fy/6+Cg x/J. These are complete-bolt resultants; each shear plane/cover receives one half. Keep the vector resultant in bolt shear and directional bearing/tearout.
- Flange bolts transfer their flange force uniformly over eight bolts per side in this conventional regular group; every individual shear plane carries |F|/16. Each inner strip has four bolts per side, each carrying |F|/16.
- Both ends are in series. Do not add left/right capacities. Signed M reverses the tension/compression flange; signed V reverses/mirrors the web transfer.

For N=−600 kN, M=120 kNm, V=100 kN: Ftop=−710.1161996 kN, Fbottom=+110.1161996 kN; outer compression355.0580998 kN and each inner177.5290499 kN. Maximum complete web bolt resultant36.08637989 kN.

Use exact cut equilibrium before/after every bolt station. The actual per-cover cut moment peaks at2.250 kNm, while the source-style group envelope is3.750 kNm. The contract deliberately uses the latter for cover bending/interaction in this fixed geometry and records the former separately. The group moment must not be mislabeled as every cut's moment. Under the chosen signs the total connection-section moment varies as M(x)=M(0)−Vx. Connected-member checks must retain this gradient through the transfer region, including up to the outer flange rows; they cannot use only the splice-center M.

## 3. Flange compression: actual separate plate stability

Fakury printed314/part4PDF61 uses the central bolt-row span90 mm and K=.65 for its flange cover. Printed320/PDF67 explicitly proposes outer plus inner covers. Use the conservative K=1 in the same supported-strip idealization, rather than importing .65.

The specified assembly detail must contain both complete members and all bolt stacks, firm plate-to-member contact in the overlaps, properly installed structural bolts/nuts/washers, and the required member lateral/torsional restraints. No packing gaps, unattached strips, missing bridge rows, erection-only support state or bearing-contact credit. The connection report/drawing must identify these physical conditions; a free-standing `restrained=True` switch is insufficient. This is an ordinary designed support detail, not a demand for continuum contact analysis.

For each separate outer plate and each separate inner strip:

1. Le=max(gap+2e_member, every load-carrying overlap-row interval)=max(90,60)=90 mm; rweak=t/√12. The unsupported length is not the10 mm butt gap.
2. Apply current6.5.4: Le/r≤25 permits fyAg/γa1; Le/r>25 invokes5.3. The second branch is **>25**, as corrected by Errata1:2025; the uncorrected body page prints the wrong inequality.
3. Check the actual local overlap widths fromTable4: outer AA170/t and AL35/t; each inner's two AL60/t outstands. At t16 they are10.625,2.1875,3.75 versus39.598(AA) and15.839(AL), all non-slender. Across the open bridge do not imagine a longitudinal backing plate or an AA line through empty space; use the finite row-supported rectangular bar model.
4. Preserve both flexural axes and torsion. An independent conservative torsion screen uses Nez≥GJ/r0², dropping positive warping stiffness, with r0²=(b²+t²)/12 and the Saint-Venant rectangular J. For actual outer/inner plates the torsional bounds are5.013 MN/9.461 MN, above their respective gross squash loads0.960 MN/0.480 MN. No torsional capacity from the spacing between separate plates is credited.
5. For future admitted Le/r>25 variants, use Ne=min(Nex,Ney,Nez), lambda0=√(Agfy/Ne), chi=.658^(lambda0²) below1.5 or .877/lambda0² above, and χAefffy/γa1. Local effective area must follow5.3.4 when applicable. Do not reuse the older Q formulation. The present thin/slender fixtures are arithmetic stress-tests, not automatic admission of new fabrication geometries.

Actual Le/r=19.485572. OuterRc=872.727273 kN; each innerRc=436.363636 kN. Baseline compression utilization=.406837406 for both. At a deliberately thinner t12/L90, including the conservative torsion bound givesRc568.655964 kN, rather than the earlier weak-flexure-only conditional631.538729 kN. The fixture uses560kN pass/580kN fail. At t12/L450 weak flexure governs andRc267.574205kN. This explicitly prevents the old flexure-only scalar from silently becoming a complete mode check.

## 4. Real web block paths and the scalar convention

The ordinary scalar NBR6.5.6 check is applicable here as the **bounded source shear-transfer design convention**. Fakury printed315–316 uses full V/2 and Cts=.5 on the cover L/U paths, while printed318 separately retains Ve in the bolt field. Thus eccentricity alone does not invalidate this particular conventional procedure. It does not establish a generalized independent Nw/Mw/pure-couple resistance.

For one whole cover, actual boundary x=±145,y=±100; bolt columns x=−105,−45,+45,+105 and levels y=−60,0,+60. x=0 and x=±5 are **not** cover free edges.

Retain36 explicit representative checks per physical cover: two longitudinal half-groups × two top/bottom free edges × three vertical prefixes k=1,2,3 × three path families. Every path's shear-leg vertices and transverse-tension vertices are in the JSON fixture.

For the right half, L1's shear line is x105 and transverse segment ends at free x145; L2's shear line is x45 and transverse segment ends at x145; U has shear lines x45/x105 with its transverse segment between them. Mirror in x for the left half. For the top-edge paths, yfree100 and ycut=60,0,−60 for k1,2,3; mirror in y for bottom-edge paths.

With dn24,t10:

- Lv=40+(k−1)60, Lvn=Lv−(k−.5)24.
- L1: Agv=tLv, Anv=tLvn, Ant=t(40−.5dn)=280 mm².
- L2: Agv=tLv, Anv=tLvn, Ant=t(100−1.5dn)=640 mm².
- U: Agv=2tLv, Anv=2tLvn, Ant=t(60−dn)=360 mm².
- Use Cts=.5 for all these eccentric-web checks and R=[min(.6fyAgv,.6fuAnv)+.5fuAnt]/γa2.

The full L2 path is1600/1000/640 mm² andR272.592593kN. The full U is3200/2000/360 andR408.888889kN. The minimum retained path is the single-level outer L1:400/280/280, R85.925926kN.

**Demand fraction:** deliberately assign the full |V|/2 to every retained path, including a partial prefix. Do not use k*m/6 or reuse the old axial equal-bolt fraction. This is a conservative envelope within the source convention; it is not a new mixed N/V/M formula. In the actual vector field every relevant contiguous prefix's total resultant is≤|V|/2. The fixture verifies that fact independently, while retaining each subset's nonzero residual couple as a diagnostic rather than falsely setting it to zero. The source's shear-transfer convention, not an invented zero-couple assumption, supplies the scalar resistance mapping.

The source's longer full-cover paths were not forgotten: an exhaustive84-candidate L/U audit includes all contiguous column spans and both physical x free ends, including paths that cross the splice. At every k their resistance is≥the retained representative with the same one/two shear legs, and every subset resultant is≤the same |V|/2 envelope. Therefore they are dominated and need not inflate the production report. This is explicitly a regular rectilinear source-family enumeration; there are no staggered holes or other topology changes in the admitted domain.

Reversal evaluates both real y edges and both x halves; changing V's sign leaves the governing utilization unchanged and swaps the actual loaded/mirrored regions. Per-cover capacities are not doubled when checking a cover.

**Member web:** it continues into the two flanges. y=±100 (the cover boundaries) and the clear-web-to-flange interfaces are not member free edges. Do not apply these cover L/U capacities to a fictitiously cropped member web. The conventional uncut-member route checks its actual bolt bearing/edge tearout, gross/net shear and connected-member/hole resistance. There is no additional cover-style top/bottom block in that uncut member geometry. A coped, slotted, cut or otherwise freed member edge is outside this model and must not fall through to a pass. The earlier longitudinal axial-web U paths belong to the former Nw allocation and are not copied with an invented web N demand.

## 5. Web cover bending, holes and combined action

Apply current AnnexD/TableD.1's solid rectangular section rule, both covers separately, Lb=max(90,60)=90 mm and Cb=1. Retain the specified bolt-row lateral/twist support premise. No benefit from spacing between the two covers is credited. The source uses this same finite bridge-span rectangular-cover model.

For h200,t10: Ag2000mm², Ig6,666,666.667mm⁴, Zg100,000mm³, Wg66,666.667mm³; ry=t/√12. TableD.1 gives λ=Lb/ry, λp=.13E√(JA)/Mpl, λr=2ECb√(JA)/Mr, with Mpl=fyZ and Mr=fyW; use its plastic/interpolation/elastic branches andγa1. Actual MRd,LTB=22.179548kNm.

Net geometry must integrate the real three-hole cut. Deducting area×hole-center-distance is insufficient for the central hole that crosses the plastic axis:

- An=t[h−3dn]=1280mm².
- Inet=t h³/12−t[2(dn³/12+dn×60²)+dn³/12]=4,904,106.667mm⁴.
- Znet=t h²/4−2(t dn×60)−t dn²/4=100000−28800−1440=69,760mm³.
- Wnet=Inet/(h/2)=49,041.066667mm³.

The last1440mm³ deduction is mandatory. The tempting71,200mm³ value is wrong. The fixture independently integrates the retained intervals [−100,−72], [−48,−12], [12,48], [72,100], rather than copying a production expression.

Retain all of these separately:

1. Shear yielding .6fyAg/γa1 and net rupture .6fuAn/γa2, current6.5.5.
2. AnnexD cover flexure/LTB.
3. Net bending rupture fuZnet/γa2 from the accepted source connection-element method:20.669630kNm here.
4. Gross combined stress. To avoid relying on the source's plastic M/Z estimate, this contract adopts the stricter elastic envelope sigma=Menv/Wg and tau=1.5(V/2)/Ag, sqrt(sigma²+3tau²)≤fy/γa1. The source's printed plus sigma_x sigma_y typo has no effect with sigma_y=0; do not propagate it into a general biaxial implementation.
5. An explicitly labelled conservative *additional design screen*: |Vcover|/VRd + |Menv|/MRd,net≤1. This is not advertised as a codified NBR mixed net-fracture equation and does not replace1–4. It confines admitted designs further than the source's separate rupture checks; it is not permission to apply the model to independent web N/M.

At V100kN the ratios are shear.219727, LTB.169075, net bending.181426, added net screen.401152 and gross elastic combined.378062. The36-path full-V block envelope ratio.581897 governs these web checks. Because local bolt bearing and net bending retain Ve, that eccentricity has not vanished from the strength procedure.

## 6. Remaining mandatory implementation checks

These are specified algorithms/checks to implement and test, not research gates:

- All current axial-module physical fit, root/washer/tool clearances, minimum/maximum spacing/edge distances, grip and long-joint bounds, hole policy, product/material range and actual multiplicity checks.
- Bolt shear per individual complete vector and each physical shear plane; flange and web bearing/local tearout per actual loaded piece and direction, including real member butt edges. Do not use the symmetric source's flange bolt capacity as a web resultant capacity.
- Tension flange cover/strip gross yielding, effective net rupture (Ae≤.85Ag for cover plates) and actual axial L/U prefixes; both separate inner strips. Main-flange gross/net and admissible free-outstand blocks use the new full flange force, not the smaller prior retained-web-share force. In compression use the above plate stability and actual local bearing; do not turn compressive N into a tensile assembly.
- Connected-member web gross/net shear with three actual holes and member material/thickness. Member flange hole-flexure clause5.4.2.6 retains its Yt gate andγa1 denominator, plus local flange-force checks. No unsupported whole-section Ct=1 claim merely copied from the previous model in which every element carried axial force; the flange-only local checks take all N/M without crediting web/fillet normal resistance.
- Member actions across the transfer region from exact statics or a conservative envelope that includes Vx. If the module returns a complete member check, use verified5.3/5.4 resistance inputs, the flange-hole cap where applicable and current5.5.1 interaction. Supplied member capacity fields need units, source/reference and a distinct external-verification status; coverRc is never memberNc,Rd.
- Applicable6.1.5 minimum/continuity actions must be a separate declared load case/envelope based on the relevant member criterion. Do not insert the old positive axial45kN floor into the actual signed N/M/V equations, suppress a reversal, or fabricate nonzero web N when V=0. For an unimplemented minimum-action policy, display precisely that policy prerequisite instead of falsely reporting complete checks.

## 7. Scope prerequisites, not unresolved local strength research

Global member buckling/restraint and the building analysis remain the responsible member/system design. The connection must report the exact supplied global-capacity/analysis basis or clearly exclude that global conclusion. A local splice result cannot assert global member adequacy.

A bearing-type ULS calculation does not certify no slip, rotational stiffness, frame rigidity, service deflection, cyclic behavior or erection stability. Fakury uses slip-critical bolts and separately warns about splice slip. If a project requires slip resistance/rigid service behavior, require the actual bolt pretension/faying-surface/hole/service-action checks or leave that specific service requirement pending. Do not block a legitimately scoped ULS connection merely by demanding a generic frame-stiffness study it never claimed to perform.

The physical row-restraint conditions are part of the issued detail. Missing or contradicted conditions produce an explicit unsupported-detail status, not a made-up capacity. Within the issued standard detail the source-supported K1/Lb model is available; it should not be held in permanent 'unknown support' limbo.

## 8. Independent fixtures and finite release gate

Run `python w_splice_scope/conventional_qualification/verify_conventional_contract.py`.

It regenerates `conventional_fixtures.json` and asserts:

- Ten signed load cases: baseline, M reversal, V reversal, total reversal, pure M, pure compression, V only, V170kN pass / V175kN block-envelope fail, and a flange-compression fail.
- Exact complete-group/global equilibrium; before/after cut forces; pure M gives exactly zero web bolt force and zero web moment.
-36 explicit real-edge/prefix representatives per cover, actual coordinates, a full84-path geometric/demand dominance audit, and sign-reversal invariance.
- Exact integral-derived netA/I/Z, including the central hole.
- Separate outer/inner flexural/torsional data, five stocky/thinner/long-span pass/fail cases, and values just below/at/above the corrected25 boundary.
- Invalid/pending classifications for absent restraints, unequal covers, retained web N/M, fictitious member free edges, central-hole omission, unsupportedK=.65, arbitrary large eccentricity, unverified member inputs and unmet slip requirement.

The fixture is intentionally not labelled a full-assembly oracle: the qualified existing flange/bolt/bearing checks must also be exercised under the new actions. The next worker should implement in a separate development copy, then an independent reviewer should compare the production outputs against these fixtures, independently spot-check bolt/bearing/flange demand routing, test serialization/domain rejection and verify reports/drawings show the same actual model. Correct concrete discrepancies and rerun the affected objective tests; no repeated broad source search once these objective tests pass.

## Sources actually inspected

- User-supplied NBR8800:2024 with Er1:2025: physicalPDF1(errata),67–71(compression),116–117(connection elements),159–168(AnnexD/TableD.1). Relevant screenshots saved in this folder's `pages/`. Printed page=physical−22 for these body pages.
- Fakury et al. §10.14.7, printed311–320 / part4PDF58–67; images/replica at `new_references_20261009/w_books_review/`. Directly inspected314–317 and actual drawing; book review establishes311/320 allocation/inside-cover statements.
- Actual M004 p72 and section images in `w_splice_scope/source/`; existing independently qualified axial detailing/check basis in `w_splice_scope/axial_tension_completion.md` and its fixture script. Existing implementation was read only to identify actual dimensions and guardrails, not imported as a resistance oracle.

`source_read_manifest.json` identifies the current NBR PDF and the read-only093 source files by SHA-256.
