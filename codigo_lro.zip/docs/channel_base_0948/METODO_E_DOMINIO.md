# Base U rotulada — método e domínio 0.9.48

## Referências e identidade

Ranzi, G.; Kneen, P. (2002), *Design of Pinned Column Base Plates*, Steel Construction 36(2), §§4.3.4, 5.2.2, 5.4.1–2 e Apêndice A.2. Referência fornecida pelo usuário, conferida nas páginas renderizadas. Fig.19 é um método GENÉRICO de balanços de tração. Os mecanismos U específicos de uma/duas barras das Figs.47–52 NÃO foram aplicados a quatro barras.

Nucor Skyline, *Technical Product Manual*, p.78: C6×8.2/C150×12.2, T=4⅜ pol=111,125 mm. https://www.nucorskyline.com/File%20Library/Document%20Library/English/Brochures/Product_Manual_EN.pdf#page=80

Tabela fornecida O Calculista de Aço: U152×12,2, d=152,4; bf≈48,8; tw=5,08; tf médio=8,71; área=1550 mm²; centroide 13 mm do dorso. A equivalência dimensional não certifica a mesma raiz para toda série comercial brasileira. O T de referência é editável e requer confirmação da peça/série fornecida. A espessura mínima da mesa na faixa de solda é entrada separada, inicialmente não informada; não é inferida de tf médio.

## Configuração limitada

Um U laminado sobre placa retangular e graute/concreto, sem enrijecedores. Quatro barras em (±ax,±ay), fora do envelope transversal completo do U, em faixas alinhadas com a alma livre. Placa e aço do pilar independentes. N é positivo na compressão; V é paralelo à alma. Sem momento externamente aplicado. Sem chave, ação biaxial ou torção. Para V pelos chumbadores exige-se ey=0; outros casos não são silenciosamente convertidos.

Origem: centro da placa e da malha das barras. Centroide real do perfil: (0,ey). Dorso: y=ey−ec. A força N gera o momento local N·ey quando ey≠0. O centroide não é bf/2, nem o plano médio da alma. No exemplo, ec−tw/2=10,46 mm.

## Compressão

Admite-se somente contato integral: q(y)=N/(LB)[1+12ey y/B²]. Integrais: ∫q dA=N; ∫yq dA=N ey. qmin≥0 é requisito do domínio, equivalente a |ey|≤B/6. A pressão máxima é comparada à resistência NBR 0,85fck/1,40, sem confinamento.

A placa usa o envelope uniforme qmax, maior ou igual à pressão em qualquer ponto. Projeções máximas reais às linhas efetivas do artigo:

- a1=(L−0,95d)/2
- a2=B/2−0,40bf+|ey−ec+bf/2|
- a4=√(2d bf)/3
- tmin=max(a1,a2,a4)√[2qmax/(fy/1,10)]

a4 corresponde ao painel U apoiado em três bordas e livre na quarta; não é o painel I/H. A aproximação do Apêndice A.2 está limitada a 1,25≤d/bf≤4. λ=1 em todos os casos: nenhuma redução Murray–Stockwell para cargas leves. A2 incorpora a maior projeção assimétrica; a fórmula equivale a conter a placa real em um retângulo simétrico mais largo, sem substituir a área real no equilíbrio. O uso de projeções deslocadas e qmax é uma extensão mecânica conservadora declarada, não validação experimental de geometria excêntrica pelo artigo.

## Tração e alavanca

Ações externas nominais: Ti=U/4[1+ey yi/ay²], U=max(−N,0). Somatórios nominais equilibram U e Uey. Somente Ti≥0: estados mistos de contato/tração não são resolvidos.

Para cada lado, bt é a distância da barra à face REAL da alma. A largura nominal de dispersão a 45° é 2bt+dh (Fig.19). O crédito é limitado a be=min(2bt+dh;2ax;T−2ax). As faixas são centradas em x=±ax, não se sobrepõem, e ficam inteiramente dentro da alma reta T. Os dois lados da alma pertencem a partes diferentes da placa: não somam a mesma área resistente. Não se credita enrijecimento das mesas ou ação bidirecional. be>0 e bt>0 dependem da geometria validada.

O §5.4.2 recomenda allowance de alavanca 1,4 nas barras, equivalente a φp=1/1,4 sobre a capacidade. O programa mantém `nominal_rods` para equilíbrio e `rods` com 1,4Ti para dimensionamento de aço/ancoragem/interação. A demanda de dimensionamento NÃO é uma segunda solução equilibrada: o acréscimo requer reações locais de contato que o allowance representa. Não se anuncia solução exata de deformação, pressão de pé ou rotação.

Adicionalmente, a placa é verificada pelo envelope max(1,4Ti bt;0,4Ti eout), onde eout é o trecho da barra até a borda externa, e tmin=√[4M/(be fy/1,10)]. A verificação da faixa externa evita esquecer o momento do allowance Q=0,4Ti fora da barra. Essa amplificação adicional da placa é uma adaptação explícita, não a equação literal 41. A fonte não demonstra que 1,4 seja um limite universal para qualquer disposição; configurações fora das faixas e caminhos aqui definidos exigem modelo específico.

## Soldas e transferência

Grupo elástico: duas linhas na alma RETA T, descontadas as extremidades, e duas linhas nas faces EXTERNAS das mesas. Faces internas inclinadas e raízes não recebem crédito. Garganta z/√2; metal E7018. O grupo recebe N/V integrais, mesmo sob compressão, e o momento entre centroide do U e centro do grupo. Para V também se conserva a torção decorrente desse deslocamento do grupo de soldas. Componentes de força são combinadas por resultante vetorial. A mínima espessura real da mesa é exigida para dimensões de filete e envelope do metal-base. Nenhum trecho de raiz foi inventado a partir da espessura média.

## Fatores e concreto

Resistência de placa: fy/γa1, γa1=1,10, SUBSTITUI 0,9fy da referência AS; não existe produto 0,9/γa1. A adaptação é explícita e não se declara cálculo literal AS4100. Chumbadores/soldas NBR mantêm γa2=γw2=1,35. Concreto ACI é complementar e usa os φ originais das rotinas, sem γc adicional. Ações fornecidas já são de cálculo.

Cone, pullout, ruptura lateral, pryout, bordas de corte e interação reutilizam as rotinas existentes com coordenadas reais e envelope 1,4Ti. Vetores de corte documentados têm assinatura incluindo L/B/ax/ay/ec/ey e a geometria U; alterações invalidam a qualificação. Não há soma de atrito e barras. As verificações parciais das arruelas mantêm suas pendências próprias quando sua transferência local não foi resolvida.

## Estados e limites

Dados inválidos, interferências, falha de resistência e condição pendente são categorias distintas. Compressão com dados locais completos pode atender; não há reprovação incondicional imposta à família. Tração/corte nas barras exige a ancoragem aplicável. Rigidez rotacional, estabilidade global, bloco armado e fundação pertencem ao projeto estrutural. Testes de software confirmam implementação e regressão, não aprovação estrutural da obra.
