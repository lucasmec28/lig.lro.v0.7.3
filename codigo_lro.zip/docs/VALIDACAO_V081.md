# Validação da versão 0.8.1

Escopo: incremento restrito à chave retangular de chapa única da placa de base Tipo 1. Os outros modelos de ligação foram preservados. Este registro documenta testes de software e consistência com as equações declaradas; não aprova um projeto para execução.

## Verificações realizadas

- Suíte automatizada: 371 testes, incluindo os 5 casos de aceitação da chave, sinais opostos, cancelamento M+V·eV, graute real, valores não finitos e geometria inválida.
- Regressões independentes das ligações anteriores: 18 cenários.
- Revisão independente focalizada: 28 testes do núcleo e comparação dos cinco casos com aritmética Decimal de 40 dígitos. Resultados coincidentes dentro da tolerância de ponto flutuante.
- Chumbadores documentados: testes de três caminhos, padrão inicial, independência de capacidade, aplicabilidade vinculada aos dados atuais, invalidação e importação pendente sobre estado confirmado.
- Interface Streamlit AppTest: importação repetida, conservação de M/V de entrada, campos personalizados, troca de caminho do cortante/família, persistência JSON e invalidação da memória após editar a geometria.
- Desenho: dimensões reais dos retângulos e graute, referência na face superior, posição da reação, sentido do cortante e espelhamento das reações.
- Word: equações nativas editáveis; versões com V positivo e negativo renderizadas em nove páginas cada, todas inspecionadas visualmente. O caminho de chumbadores documentados também foi renderizado em cinco páginas e revisado.
- Distribuição: quatro arquivos na raiz, código íntegro por manifesto e checksum, compilação e abertura independente do pacote, importação W200 e exportação Word, exemplo de chave e seus arquivos exportáveis.

A interface foi exercitada com Streamlit AppTest. Não foi realizada homologação em navegador real ou publicação no GitHub/Streamlit Cloud.

## Verificações que continuam pendentes

Resistência e detalhamento das soldas da chave; metal-base; flexão local e transferência de tensões na ligação chave–placa; ruptura e efeitos de borda do concreto; bloco armado conforme NBR 6118; ancoragem no concreto; soldas do pilar; transferência à fundação e classificação de rigidez. O cálculo fornece as ações prescritas Vw/Mw, mas não uma utilização de solda. Nenhuma dessas verificações é considerada atendida por simples passagem das verificações locais da chapa.

Cruciforme e perfis W permanecem como descrições da rota de resistência externa. Não há modelo interno de contato, seção ou solda dessas formas.

Método e valores de referência: `CHAVE_RETANGULAR_V081.md`. Casos reproduzíveis: `tests/test_shear_plate.py`, `tests/test_shear_plate_app.py` e `tests/test_shear_plate_artifacts.py`.
