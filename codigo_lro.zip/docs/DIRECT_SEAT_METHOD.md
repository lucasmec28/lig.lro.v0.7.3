# Apoio direto entre mesas: verificacoes locais DEV2

Esta copia separada tem schema3, connection_type
beam_direct_seat_standard_holes e componente
0.9.46-direct-seat-local-review-dev.2. O escopo calculado e local: escoamento e
enrugamento das almas originais, com geometria nominal da montagem. As copias
anteriores e o motor legado0.9.44 sao preservados. JSON DEV1, oblongos ou legados
nao sao convertidos automaticamente para este componente.

Verificacoes locais calculadas atendem no caso informado. Isso nao representa
qualificacao integral da ligacao. A condicao local necessaria de NBR5.7.8 na
propria W360 permanece explicita e pendente: o projeto deve fornecer contencao
longitudinal demonstrada ou o detalhe de enrijecimento exigido, conforme
aplicabilidade. Estabilidade externa e montagem nao sao atestadas pelo APP.
global_pass, engineering_approved e local_connection_qualified permanecem false.

## Modelo e acoes

A mesa inferior da W360x39 apoia diretamente na mesa superior da W410x38,8.
x segue a W360, y a W410 e z e vertical. Extremidade fisica W360 em x=+70 mm,
distinta da referencia da reacao centrada x=0. A alma superior e o par
construtivo da W410 estao em y=0. Nao ha chapa intermediaria ou solda sob a
viga superior. O modelo nominal de gravidade usa o apoio direto entre mesas
e as almas originais; nao soma resistencia dos enrijecedores.

A familia ASI DG6 A1(c) foi conferida pelo revisor do pai e aceita pelo usuario.
Essa evidencia identifica a familia; as quatro resistencias calculadas usam
NBR8800:2024/Errata2025 e seus coeficientes. Este executor nao materializou nem
releu os PDFs ASI. A elevacao A1(c) nao define contagem, planta ou aperto dos
parafusos. Quatro parafusos nao invalidam por si o caminho nominal de gravidade.

V=2610 kgf ja em ELU, convertido por9,80665 para25595,3565 N. N=My=Tz=0;
referencia da reacao x=0. O minimo resistente para esta viga de piso,
NBR6.1.5.2, e um caso separado de45000 N na mesma direcao vertical descendente.
Nao e fator adicional de acao. A forca de verificacao e max(V_ELU,45000).
Entradas N, My, Tz ou excentricidade nao nulas sao preservadas e retornam fora
do escopo. V deve ser descendente positivo. V nao e corte dos parafusos
verticais; nao se usa V/4, V/2, C=V, prying ou uma pressao uniforme presumida.

## Quatro verificacoes resistentes locais

Vigas propostas ASTM A572 Gr50, fy345 MPa; E200000 MPa;
gamma_a1=1,10 fixo. Dimensoes nominais W360: d353/bf128/tw6,5/tf10,7 mm;
W410: d399/bf140/tw6,4/tf8,8 mm. Identificacao dos produtos reais a conferir.

Escoamento local, NBR5.7.1/5.7.3: limite inferior do ramo de extremidade com
ln tendendo a zero e k=tf:

Frd = 1,10 x 2,5tf x fy x tw / gamma_a1.

Enrugamento local, NBR5.7.4: menor ramo de extremidade com ln tendendo a zero:

Frd = 0,33tw^2 sqrt(E fy tf/tw) / gamma_a1.

Esses limites nao inventam comprimento de contato ou footprint. O resultado
e condicionado ao dominio nominal de compressao local centrada do apoio
direto. A geometria do retangulo dos parafusos nao e area de apoio.

| Alma original | Escoamento local, kN | Enrugamento local, kN | Demanda separada, kN |
| --- | ---: | ---: | ---: |
| W360 superior | 59,986875 | 135,085186 | 45,000 |
| W410 apoio | 48,576000 | 119,689788 | 45,000 |

local_strength_checks_satisfied resume somente estas quatro linhas.
local_geometry_checks_satisfied resume a geometria implementada.
local_checks_satisfied combina ambas e a especificacao do apoio direto.
gravity_checks_satisfied e somente alias de compatibilidade desses calculos
locais; nao significa aprovacao integral.

## Par construtivo preservado sem credito

Preserva-se o par8x60 mm, altura nominal381,4 mm, recortes quadrados20x20,
plano y=0, filetes propostos5 mm e duas linhas verticais L150 mm. Ajuste e
ligacao as interfaces permanecem detalhes construtivos propostos. Altura
nominal nao e ordem de corte sem conferir a peca real e suas tolerancias.

pair_strength_credit=false e pair_dimensioned=false. Nao sao calculadas ou
somadas capacidades fitted, compressao da barra composta, barra individual,
flexocompressao ou resistencia do grupo de soldas. As alternativas32/40 mm
nao foram adotadas. Verificacoes geometricas nominais e requisitos minimos
de largura, espessura e filete nao constituem dimensionamento resistente do
par ou das suas soldas. Flags fitted/web/mesas nao condicionam o calculo das
almas originais; nao sao prova de execucao.

Para os estados locais calculados, a diferenca normativa de NBR5.7.9.2 e
max(45000-48576,0)=0 N. Esse registro explica que nenhum incremento resistente
do reforco e necessario para escoamento/enrugamento da alma original; zero
nao dispensa construcao adequada nem declara o par dimensionado. NBR5.7.9.4
e o modelo de enrijecedores para os estados de5.7.9.3, nao uma exigencia criada
automaticamente por manter um par fisico no detalhe local5.7.9.2.

## Gabarito circular e montagem

Quatro M16, centros x=+/-35 e y=+/-40 mm: passo70/gabarito80.
Furos circulares padrao diametro18 nas duas mesas, arruelas externas
diametro33 em ambas. Classes, cabecas/porcas, comprimentos e aperto reais
devem respeitar o projeto. Nao existe verificacao de curso ou liberacao axial.

Centros70/80 superam2,7db=43,2 mm; distancias livres52/62 superam db16.
Espacamento maximo usa o menor ramo min(14t,180)=123,2 mm. Borda superior
longitudinal35 contra22 mm; lateral24 contra22 mm, margem nominal2 mm.
Borda transversal da mesa W41035 contra22 mm. No interno W410 nao se presume
uma extremidade fisica proxima ao gabarito.

R nominal12 mm nas duas vigas vem do catalogo Gerdau09/2017, inferido de
(h-d')/2; raio real nao atestado. Limites de raio externo de ferramenta mais
folga:24,75 mm na W360 e19,80 mm na W410. Proposta17+2 deixa margem nominal
0,80 mm governante. Arruela inferior deixa3,30 mm nominal ate a tangencia;
arruela superior7,50 mm ate a borda lateral. A ferramenta envolve cabeca ou
porca, nao a arruela inteira. O filtro raio>=db/2 e apenas condicao necessaria
da haste. Ferragem, insercao axial e sequencia reais devem ser conferidas.

Alivio quadrado20>=R12 evita o envelope nominal da concordancia; linha150
cabe no corpo intacto381,4-40=341,4 mm. Filete5 respeita as verificacoes
geometricas implementadas; nao e capacidade resistente creditada.
Preparo compativel das faces de apoio direto e requisito de projeto; nao se
declara contato usinado existente ou resistencia1,8Afy de faces nao verificadas.

## Condicao local necessaria e interface externa

NBR5.7.8 se aplica a apoios/extremidades sem restricao a rotacao em torno do
eixo longitudinal e com alma nao ligada a outra viga/pilar. Quando essas
condicoes coexistirem, exige enrijecedores transversais de altura completa
soldados as mesas e a alma. A verificacao deve considerar a propria W360;
o par fisico na W410 nao substitui esse detalhe. Quatro parafusos entre mesas
e contraventamentos qualitativos nao comprovam automaticamente a contencao.
Condicao desconhecida recebe PENDING, nao FAIL fisico. Scope
local_necessary_5_7_8 e separado do escopo global e do resumo dos calculos.

Lucas informou comprimento4 m, no W410 interno central e contraventamentos/
vigas. Os tres campos external_length_reported_mm, external_support_node e
external_bracing_record registram somente a informacao fornecida. Nao se
converte4 m em vao, comprimento normativo lateralmente destravado ou contencao
longitudinal observada; nenhum deles altera resistencia ou geometria.

NBR5.7.5 e os requisitos de estabilidade/contencao pertinentes ficam sob
responsabilidade do engenheiro do projeto externo. Este nucleo nao calcula
estabilidade com o registro4 m nem toma ausencia de My/Tz como prova de
contencao. A rotacao da extremidade e uma condicao distinta da restricao
longitudinal de5.7.8. Apoio direto, preparo das faces, montagem e as condicoes
locais/externas aplicaveis devem ser atendidos antes da qualificacao integral.

## Serializacao e verificacao do software

Schema3 e identidade DEV2 impedem reinterpretacao silenciosa de projetos DEV1.
Importacao estrita exige todos os campos, unidades e premissas canonicas;
bool nao e numero, NaN/Inf nao sao valores validos. Nenhum resultado e tratado
como entrada. JSON legados continuam com seus motores originais preservados.

Testes independentes DEV2 ficam em docs/validation_local_dev2. Os recibos e
testes anteriores sao historicos da copia DEV1; nao validam este componente.
Testes verificam o software, preservacao e limites declarados, sem aprovar
estabilidade, montagem ou a engenharia integral da ligacao.
