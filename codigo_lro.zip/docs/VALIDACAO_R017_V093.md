# Validação R017 · 0.9.3-angle-dev

Data: 2026-10-09 UTC. Alvo: família local R017 em cópia separada da versão092 congelada. Não é certificação de engenharia, aprovação de toda a estrutura nem validação de todos os mecanismos fora do domínio declarado.

## Resultado

- **1.280 testes passaram** no agregado da aplicação, 671,51s. A coleta ocorreu antes das últimas correções localizadas da R017 e da adição de quatro testes. Isso não é apresentado como uma execução única do estado final de1.284 testes.
- **284 testes passaram** no código final congelado, 110,30s: testes R017 do motor/UI/desenho/Word e auditoria independente de geometria, coordenadas, entrada/saída, importação e navegação. Os seis hashes de produção foram iguais antes/depois. Não substitui o agregado das outras famílias.
- **7.645 assertivas independentes passaram**, zero falhas, por reexecução do comparador original e da cópia portátil de pacote sobre o motor final. Equações e dados esperados foram congelados por revisor independente antes da comparação, sem importar helpers do aplicativo para produzir oracles.
- Coleta final: **1.284 testes** em `tests/`. A diferença de quatro em relação ao agregado está abrangida na execução final focada.
- Todos os **287 arquivos não-cache da origem092 permanecem inalterados**. Na cópia093, até o fechamento exclusivo desta expansão R017 e antes da correção separada DG39 da endplate, os únicos Python pré-existentes alterados são `app.py` (integração/guarda da versão) e `lro/models.py` (constante da versão). Implementações das famílias anteriores não foram modificadas nesta expansão.

## Sequência e proveniência

1. Fontes, domínio, travamentos e valores esperados do R017 definidos independentemente.
2. Motor inicial com primeiro escoamento, instabilidade complementar, componentes NBR e alma única do apoio.
3. UI/desenho/Word e testes específicos.
4. Auditoria identificou e corrigiu dois defeitos: margem de montagem não pode virar colisão física fictícia; coordenadas geométricas/exportadas precisam de origem e sinal inequívocos.
5. Correções textuais pontuais solicitadas na revisão, sem alteração numérica.
6. Execução final exata284, comparador independente7.645, geração de seis exemplos no código final e nova renderização dos casos pendente e invertido.

Hash SHA256 do motor final:
`4244bfd94663850f0453bcb52b0e3bcdd26adb0362b039e4316fc8de13959f81`

Os hashes de motor, desenho, relatório, UI, roteador, versão e18 arquivos de exemplo estão em `validation/v093/production_and_examples_freeze_sha256.json`. O registro consolidado é `R017_VALIDATION_RECORD.json`.

## Cobertura independente

- Geometria real, quarto de círculo R15, integridade de furos, colisões e margem de montagem separada.
- NBR atual: coeficientes0,45/0,56, redução de pega, contato direcional por furo e soma, áreas brutas/líquidas, todos os prefixos de bloco e parcelas k/n.
- Duas cantoneiras reais, n parafusos comuns em corte duplo,2n parafusos de apoio em corte simples e uma espessura física para cada alma.
- Modelo de recorte: conversão35060kN/cm²→350600MPa, primeiro escoamento distinto, ausência deγ duplicado, domínio c≤2d/dc≤0,2d e caso governado por instabilidade.
- V positivo, negativo e zero; borda e mesa comprimida corretas; piso45kN separado da reação real.
- Apoio: sem borda fictícia na raiz ou ponta da cantoneira; sem bloco de mesa de pilar; sem reação globalV/2 inventada; transporte Mx=Vez e coordenadas inequívocas.
- Contenções: condição externa declarada com sistema, referência e localização; a falta não é suprida por checkbox nem pelas próprias cantoneiras. `local_pass` separado de `global_pass` sempre falso.
- Schema JSON estrito, tipos/números não finitos, enumerações externas preservadas, resultado antigo vinculado a outra entrada rejeitado, navegação/importação/rollback e relatórios favoráveis antigos invalidados.

## Word e desenhos

Seis conjuntos JSON/SVG/Word foram gerados: base com travamento pendente, condição externa didática, V invertido didático, falha resistente, recorte c200 pendente e falha de detalhamento.

Todos os seis Word contêm31 tabelas editáveis e23 equações OMML nativas. Foram renderizados os exemplos finais pendente e invertido,29 páginas cada. Todas as páginas foram inspecionadas em folhas de contato, com primeira página, desenho, tabelas de coordenadas alteradas e página final ampliadas. O responsável pelos artefatos já havia inspecionado integralmente, em resolução completa, as29 páginas do template qualificado. Não foram encontradas páginas órfãs, cortes de desenho ou linhas quebradas após a correção da largura da imagem.

O caso didático qualificado explicita que a contenção é uma condição de contorno de teste; não contém projeto de travamento real e não é detalhe executivo. Exemplo atendido localmente não implica aprovação global de membros.

## Arquivos de evidência

- `validation/v093/aggregate_initial.log`
- `validation/v093/final_exact_hash_validation.log` e `FINAL_AUDIT_RECORD.json`
- `validation/v093/final_independent_original_comparison.log`
- `docs/r017_verification/r017_implementation_comparison.json`
- `validation/v093/artifact_render_audit.json`
- `tests/fixtures/r017_independent_fixtures.json` e `r017_supplemental_fixtures.json`
- `tests/fixtures/calculate_r017_fixtures.py`, `calculate_r017_supplemental.py` e `compare_r017_implementation.py`
- `validation/v093/test_r017_adversarial.py` e `test_r017_state_adversarial.py`

As oracles e geradores do pacote são idênticos aos independentes. Apenas a raiz de importação do comparador foi adaptada à árvore distribuída. Para reproduzir a auditoria numérica a partir da raiz do fonte: `python tests/fixtures/compare_r017_implementation.py`. Testes: `python -m pytest -q tests`; auditoria adicional: `python -m pytest -q validation/v093/test_r017_adversarial.py validation/v093/test_r017_state_adversarial.py`.

## Limites preservados

Recortes desiguais/profundos/simples, caminhos curvos não qualificados, geometria não convencional, esforços fora do plano, apoio com abertura/ligação superposta, acesso não resolvido e falta de contenção externa continuam sem atendimento completo. A linha histórica Gerdau266kN não foi forçada; sua reprodução exata continua dependendo do conjunto de dimensões/premissas originais. Não foi identificada lacuna de equação local aplicável dentro do domínio restrito declarado. A elaboração do projeto real e suas condições externas permanecem responsabilidade técnica do projetista.

Empacotamento limpo, atualização do manifesto de distribuição, teste de inicialização do pacote e publicação são etapas próprias, não representadas como realizadas por este registro de implementação.


## Fronteira desta validação

Este fechamento precede a correção separada de verificações da endplate4E identificadas na revisão DG39. O agregado acima é evidência anterior àquela alteração; o ciclo final combinado da distribuição deve incluir os arquivos e testes dessa correção. Nenhum arquivo da endplate foi modificado por esta implementação R017.
