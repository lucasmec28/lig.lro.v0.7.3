"""Verify the one complete, stable final-source run; do not change tests or oracles."""
from pathlib import Path
import hashlib,json,xml.etree.ElementTree as ET
R=Path(__file__).resolve().parent;S=R/'source0939';A=R/'aggregate_final'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((A/'RUN_MANIFEST.json').read_text());hold=json.loads((R/'RUNTIME_TEST_HOLD0939.json').read_text())
assert manifest['runtime_and_tests_stable'] is True
assert manifest['source_and_tests_sha256_before']==manifest['source_and_tests_sha256_after']==hold['files']
for p,h in hold['files'].items():assert sha(S/p)==h,p
collected=[line.strip() for line in (R/'COLLECTION0939_FINAL.txt').read_text().splitlines() if line.startswith('tests/') or line.startswith('review0939/source0939/tests/')]
collected=[n.removeprefix('review0939/source0939/') for n in collected]
assert len(collected)==len(set(collected))==5762,len(collected)
ledger=[];groups=[]
for g in manifest['results']:
 root=ET.parse(A/g['junit']).getroot();cases=[]
 for case in root.iter('testcase'):
  classname=case.attrib['classname'];name=case.attrib['name'];filename=next(part for part in classname.split('.') if part.startswith('test_'))+'.py'
  matches=[node for node in collected if node.startswith('tests/'+filename+'::') and node.rsplit('::',1)[-1]==name]
  assert len(matches)==1,(classname,name,matches)
  status='failed' if case.find('failure') is not None else 'error' if case.find('error') is not None else 'skipped' if case.find('skipped') is not None else 'passed'
  row={'case':matches[0],'group':g['id'],'status':status,'seconds':float(case.attrib.get('time',0))}
  if status!='passed':
   node=case.find({'failed':'failure','error':'error','skipped':'skipped'}[status]);row['message']=node.attrib.get('message','');row['detail']=node.text or ''
  cases.append(row)
 groups.append({**g,'cases':len(cases),'counts':{s:sum(x['status']==s for x in cases) for s in ['passed','failed','error','skipped']}});ledger.extend(cases)
assert len(ledger)==len(set(x['case'] for x in ledger))==5762
assert {x['case'] for x in ledger}==set(collected)
failures=[x for x in ledger if x['status']=='failed'];assert len(failures)==1,failures
assert failures[0]['case']=='tests/test_axial_double_angle.py::test_bolt_bearing_oracle_file_and_opposite_loaded_free_ends'
assert 'bolt_bearing_oracle.json' in failures[0]['detail']
assert not any(x['status'] in ['error','skipped'] for x in ledger)
summary={'complete':True,'coverage_mode':'One complete execution of the final held runtime and test tree, four disjoint file groups.','single_final_test_tree_execution':True,'distinct_cases':len(ledger),'passed':sum(x['status']=='passed' for x in ledger),'failed':len(failures),'errors':0,'skipped':0,'runtime_and_tests_stable':True,'runtime_test_hold_sha256':sha(R/'RUNTIME_TEST_HOLD0939.json'),'held_files':len(hold['files']),'groups':groups,'failures':failures,'case_set_equals_final_collection':True,'review_counts_added_to_pytest_total':False}
(R/'FINAL_AGGREGATE_SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
(A/'CASE_LEDGER0939.json').write_text(json.dumps(sorted(ledger,key=lambda x:x['case']),indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ['groups','failures']},indent=2))
