# Verificação de software da versão 0.7.5

Data: 9 de outubro de 2026. Execução em ambiente isolado, Python 3.12.14.

## Resultados

- 251 testes pytest aprovados. Incluem os 237 testes da 0.7.4 e 14 casos de guarda numérica, navegação e importação inválida.
- 18 cenários independentes aprovados, com subcasos nas cinco configurações. A fixture da W200 foi copiada do projeto original da versão 0.7.3.
- Compilação Python dos módulos e da entrada concluída sem erros.
- Relatórios W200 e W410 com linha intermediária: cinco páginas por documento, renderizadas e inspecionadas visualmente. Sem sobreposição, corte ou perda das ressalvas; a quantidade de parafusos físicos e considerada no cálculo permanece explícita.

## Versões usadas

- Streamlit 1.65.0
- pandas 2.2.3
- matplotlib 3.10.8
- python-docx 1.2.0
- pytest 9.1.1

As quatro dependências de execução correspondem exatamente ao requirements.txt.

## Repetir os testes

Na cópia extraída de codigo_lro.zip:

```bash
python -m pip install -r requirements-dev.txt
python -m pytest -q tests
python validation/tests/independent_regressions.py --source .
python verificar_pacote.py
```

## Alcance

A auditoria verifica comportamento do software, preservação de entradas, rastreabilidade dos avisos, exportação e consistência dos modelos já implementados. Não equivale à validação estrutural independente de todas as equações, à aprovação de detalhes para execução ou à verificação global da estrutura. O aplicativo não foi publicado nem testado em uma conta Streamlit Cloud nesta revisão.
