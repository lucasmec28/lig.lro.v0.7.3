# Validação composta 0.9.43

6311 casos distintos, com 6310 aprovados e uma falha histórica não resolvida. Não é uma execução única da árvore final de testes emendada.

O agregado integral original teve 6288 aprovações e 23 falhas: uma ausência real do oráculo externo bolt_bearing_oracle.json e vinte e duas comparações do catálogo explícito antigo de dezenove rótulos. Após revisão independente, apenas dois rótulos foram acrescentados à lista esperada de um módulo de testes. Os 47 casos desse módulo foram reexecutados e aprovados. Eles substituem os respectivos resultados na visão final, sem aumentar a contagem distinta. Runtime e dados são idênticos nas duas etapas; a única diferença da árvore de testes é rastreada por hashes. Zero erros e pulados. A falha do oráculo não foi substituída nem mascarada.

Contagens de revisões, replays e pacote são separadas. As rotas 1L e 2L têm contratos próprios. A 2L cobre somente a montagem final concluída, sem aprovação do içamento ou fase intermediária. Os limites físicos anteriores, inclusive chapa receptora e cortante rotulado, permanecem. Fonte 0.9.42 imutável. Este congelamento não é aprovação de fabricação, projeto real, pacote ou implantação.
