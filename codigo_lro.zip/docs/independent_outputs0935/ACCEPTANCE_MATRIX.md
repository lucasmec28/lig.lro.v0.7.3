# Independent 0.9.35 output acceptance

Read-only review of candidate source, then exact final APP-only replay. Qualification contract and oracle are independent references; they are never resistance lookup data.

## Source matrix

- Main app retains 19 routes, welded and bolted 1L/2L-T variants. The sign of total N alone selects compression/tension; there is no second effort selector.
- Compression fixture CC1: genuine receiver FAIL remains; CC2: complete passing compression; CC3: computed buckling failure and slenderness/service qualification pending coexist. Each retains original cuts.
- Physical compression declarations: beam, column and attached-end statuses/source bind current physical geometry only; missing, absent, forged and stale boundary approvals are specific pending issues, while real failures remain. Force-only and unrelated edits do not erase valid physical qualification. Receiver lateral restraint never substitutes for three restraints.
- Scope: welded symmetric 2L-T only. Welded 1L and both bolted compression variants are clearly unqualified. No Ct rupture row becomes compression capacity. Signed compression arrows and forces agree with both roots, J, D/U/L cuts and visual labels.
- Actual -20 kN and separately synthetic -45 kN cases; actual zero remains zero and separate +45 kN nominal convention. This is a 0935 correction for welded adapters: 0934 had the minimum only on bolted adapters. Test +20/zero welded 1L and 2L-T, and identify the intentional added minimum-strength cases rather than claiming unchanged legacy behavior. Force changes recompute complete chain while retaining complete D/U background.
- Genuine AppTest callbacks: declaration edits, source/geometry changes, report invalidation, save/import/reopen, branch and route navigation, repeated controls. Download storage observer captures the actual bytes emitted by download buttons. This does not claim browser DOM clicks or OS dialog interaction.
- Native decoder: exact fields, no unknown keys or invalid enums/types, finite real fields, no booleans as numbers, NaN/infinities, malformed declaration values. Rejected upload is atomic for project, draft, accepted/template, results and report.
- Compact summaries group physical mechanisms. Detailed report retains raw check trace, factors, length model and sources. Downloaded PNG/SVG/native/results/Word reflect current state and Word media match drawing bytes.
- Render PNG and independently rasterize SVG. Inspect selected drawings and every rendered compact/detailed Word page or prove exact pixel identity to an inspected page. Record all visual evidence outside APP with hashes.
- Runtime before/after hashes and actual loaded module hashes for each runnable checkpoint. No evidence carried across changed bytes without exact comparison or rerun.
- Legacy: old routes remain; intended changes in negative-force corner calculations are identified rather than claiming unchanged output. Retain 0934 long-bolt controls and strict timestamp/generated-ID-only SVG normalization with mutation proof.

## Packaged gate

Only after source GO: freshly extract exact APP, with no optional companion files or source checkout on PYTHONPATH. Run actual outer app.py, observe private wrapper extraction, verify all loaded runtime hashes match source, repeat callbacks and emitted outputs, compare source native/results/PNG/SVG bytes and every Word XML/media member. Legacy SVG comparator ignores only declared generated date and bijective defs IDs; mutation witnesses establish that geometry, labels and styles remain checked. Final APP remains byte-immutable during tests.

Prepared 2026-10-12 and executed through final source review. See SOURCE_OUTPUT_ACCEPTANCE.json for the exact accepted runtime map, coverage and scope. Final APP-only replay remains a separate gate.
