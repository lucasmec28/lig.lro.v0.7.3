"""Independent semantics of actual emitted bytes; imports no application module."""
from pathlib import Path
from io import BytesIO
from zipfile import ZipFile
import sys,json,xml.etree.ElementTree as ET,hashlib,re,math
from docx import Document
cap=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True);records=[]
SVG='{http://www.w3.org/2000/svg}'
def vector(root,gid):
 element=next(e for e in root.iter() if e.get('id')==gid+'-arrow-path')
 paths=list(element.iter(SVG+'path'));assert paths,(gid,'no path')
 path=paths[0].get('d');points=[tuple(map(float,x)) for x in re.findall(r'[MQ L]\s+(-?\d+(?:\.\d+)?)\s+(-?\d+(?:\.\d+)?)',path)]
 assert len(points)>1,(gid,path)
 return points[-1][0]-points[0][0],-(points[-1][1]-points[0][1])
def agrees(value,component):return value==0 or value*component>0
for receipt in json.loads((cap/'DOWNLOAD_RECEIPT.json').read_text()):
 tag=receipt['tag'];native=json.loads((cap/(tag+'.json')).read_text());c=native['connection'];r=json.loads((cap/(tag+'.results.json')).read_text())['result']
 root=ET.fromstring((cap/(tag+'.svg')).read_bytes());ids=[e.get('id') for e in root.iter() if e.get('id')]
 assert len(ids)==len(set(ids)),(tag,'duplicate SVG ids')
 single=c['topology'].startswith('single');bolted=c['topology'].endswith('bolted')
 for key in ['beam-root-double-fillet','column-root-double-fillet','beam_cut-named-cut','upper_column_cut-named-cut','lower_column_cut-named-cut','beam-upper-CJP','beam-lower-CJP','T-central-gusset']:
  assert key in ids,(tag,key)
 for side in ['positive','negative']:
  assert ('T-'+side+'-L' in ids)==(not single or c.get('single_angle_face')==side),(tag,side)
 if c['P']:
  vx,vy=vector(root,'brace-actual-force');th=math.radians(c['phi_deg'])
  assert agrees(c['P']*math.cos(th),vx) and agrees(c['P']*math.sin(th),vy),(tag,'brace arrow')
 else:assert 'brace-actual-force-arrow-path' not in ids
 arrows=[]
 for cut in ['beam_cut','upper_column_cut','lower_column_cut']:
  action=r['forces'][cut]
  for component in ['Fx','Fy']:
   gid=cut+'-actual-'+component
   if action[component]:
    vx,vy=vector(root,gid);assert agrees(action[component],vx if component=='Fx' else vy),(tag,gid)
    arrows.append(gid)
   else:assert gid+'-arrow-path' not in ids
  if action['M']:
   element=next(e for e in root.iter() if e.get('id')==cut+'-actual-M')
   path=next(element.iter(SVG+'path')).get('d')
   pts=[(float(x),-float(y)) for x,y in re.findall(r'[ML]\s+(-?\d+(?:\.\d+)?)\s+(-?\d+(?:\.\d+)?)',path)]
   vectors=[(b[0]-a[0],b[1]-a[1]) for a,b in zip(pts,pts[1:])]
   turn=sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(vectors,vectors[1:]))
   assert turn*action['M']>0,(tag,cut,'moment rotation')
   arrows.append(cut+'-actual-M')
 if bolted:
  assert sum(i.startswith('corner-bolt-') for i in ids)==c['bolt_count'],tag
  assert sum(i.startswith('T-shear-plane-') for i in ids)==(1 if single else 2),tag
  assert not any(i.startswith(('brace-','T-')) and i.endswith('-fillet') for i in ids),tag
 else:
  assert sum(i.startswith('brace-') and i.endswith('-fillet') for i in ids)==(2 if single else 4)
  assert sum(i.startswith('T-') and i.endswith('-fillet') for i in ids)==(2 if single else 4)
 if receipt['resistant_report_ready']:
  docbytes=(cap/(tag+'.docx')).read_bytes();d=Document(BytesIO(docbytes));text='\n'.join([p.text for p in d.paragraphs]+[cell.text for t in d.tables for row in t.rows for cell in row.cells])
  for term in ['COMPLETE_CUTS','D · viga completo','U · pilar superior completo','DERIVADO','CJP','continuidade']:
   assert term in text,(tag,term)
  if receipt['detailed']:assert all(row['id'] in text for row in r['checks'])
  else:assert 'Auditoria detalhada' not in text
  with ZipFile(BytesIO(docbytes)) as z:media={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.startswith('word/media/')}
  assert hashlib.sha256((cap/(tag+'.png')).read_bytes()).hexdigest() in media.values()
 else:media={}
 mc=(cap/(tag+'_mc.txt')).read_text();assert 'RESUMO POR COMPONENTE' in mc and 'LINHAGEM' in mc
 mentions=sum(row['id'] in mc for row in r['checks']);assert mentions<len(r['checks'])/2,(tag,mentions)
 if c['P']<0 and c['topology']=='symmetric_2L_T_welded':
  cp=r['compression'];vectors=r['brace']['signed_weld_vectors'];assert len(vectors)==4
  if any(v!='confirmed' for v in cp['restraints'].values()):assert 'PENDENTES' in ''.join(root.itertext()),(tag,'drawing conceals missing physical restraint')
  assert abs(sum(v['force'] for v in vectors)-c['P'])<1e-8
  assert all(v['force']<0 and v['magnitude']>0 for v in vectors)
  assert all(v['Fx']*c['P']>0 and v['Fy']*c['P']>0 for v in vectors)
  assert not any(row['id'].split('minimum45__')[-1] in ('angle_each_net_rupture','angle_each_support_side_block','angle_tension_rupture') for row in r['checks'])
  for phrase in ['Ct, ruptura líquida por tração e bloco de ponta tracionada estão inativos','força axial assinada=','magnitude=']:
   assert phrase in mc,(tag,phrase)
  if receipt['resistant_report_ready']:
   for phrase in ['Ct, ruptura líquida por tração e bloco de ponta tracionada estão inativos','força axial assinada=','magnitude=']:
    assert phrase in text,(tag,phrase)
 if 'minimum' in tag:
  assert r['force_cases']['actual']==r['forces']
  design=r['design_cases'][0];assert design['actual_P']==c['P'] and design['design_P']==(-45000 if c['P']<0 else 45000)
  synth=r['force_cases']['minimum_45kN'];assert synth==design['result']['forces']
  for cut in ('beam_cut','upper_column_cut'):assert synth[cut]==r['forces'][cut],(tag,cut,'background changed')
  assert 'Caso sintético de resistência mínima45kN' in text and 'L sintético derivado' in text
  if not c['P']:assert 'N real zero preservado; +45 kN em +u adotado nominalmente em tração, não sentido prescrito pela norma.' in text
 controls=json.loads((cap/(tag+'_controls.json')).read_text())
 effort_controls=[x for x in controls if x['kind'] in ('radio','selectbox') and re.search(r'tra[çc][aã]o|compress[aã]o',str(x['label']),re.I) and not re.search(r'restr|detalhe|apoio|qualif',str(x['label']),re.I)]
 assert not effort_controls,(tag,'redundant effort selector',effort_controls)
 records.append({'tag':tag,'pass':True,'signed_action_arrows':arrows,'zero_arrow_absent':not c['P'],'brace_arrow_direction_verified':bool(c['P']),'raw_check_ids_in_condensed_mc':mentions,'checks':len(r['checks']),'word_media':media})
(out/'ARTIFACT_SEMANTICS.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
print('PASS',len(records),'actual artifact scenarios')
