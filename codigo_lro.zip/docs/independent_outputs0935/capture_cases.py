"""Capture genuine Streamlit callback state and emitted media bytes, independently.

The storage tap observes emitted bytes without altering them. This is not a browser
click/download or clipboard test. Keep test inputs and output outside application.
"""
from pathlib import Path
from copy import deepcopy
from io import BytesIO
from zipfile import ZipFile
import argparse, sys, json, hashlib, importlib.metadata

p=argparse.ArgumentParser();p.add_argument('runtime',type=Path);p.add_argument('cases',type=Path);p.add_argument('output',type=Path);a=p.parse_args()
source=a.runtime.resolve();out=a.output.resolve();out.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(source))
sha=lambda b:hashlib.sha256(b).hexdigest()
def file_hashes(root):
 return {str(f.relative_to(root)):sha(f.read_bytes()) for pattern in ('app.py','lro/*.py','data/*.json','requirements*.txt') for f in root.glob(pattern)}
from streamlit.testing.v1 import AppTest
from streamlit.runtime.memory_media_file_storage import MemoryMediaFileStorage
wrapper_extractions=[]
if (source/'codigo_lro.zip').exists():
 # Observe the real wrapper's temporary-directory allocation without changing it.
 import tempfile
 original_temporary_directory=tempfile.TemporaryDirectory
 def observe_temporary_directory(*args,**kwargs):
  holder=original_temporary_directory(*args,**kwargs)
  wrapper_extractions.append({'root':str(Path(holder.name).resolve()),'prefix':kwargs.get('prefix')})
  return holder
 tempfile.TemporaryDirectory=observe_temporary_directory
 try:
  at=AppTest.from_file(str(source/'app.py'),default_timeout=300).run();assert not at.exception
 finally:tempfile.TemporaryDirectory=original_temporary_directory
runtime=Path(sys.modules['lro'].__file__).resolve().parent.parent if 'lro' in sys.modules else source
wrapper_extraction=next((x for x in wrapper_extractions if x['root']==str(runtime)),None)
if (source/'codigo_lro.zip').exists():assert wrapper_extraction,'Loaded runtime is not the wrapper-created private extraction'
before=file_hashes(runtime)
from lro.corner_gusset import CornerGusset as C,FAMILY,analyze
from lro.corner_gusset_ui import PROJECT,RESULT,REPORT,decode_project,checks_complete
from lro.corner_gusset_presentation import input_fingerprint,physical_envelopes,memory_text,compact_envelopes
from lro.corner_gusset_drawing import image_bytes,effort_convention_png
from docx import Document
files={};original=MemoryMediaFileStorage.load_and_get_id

def observe(storage,*args,**kwargs):
 identity=original(storage,*args,**kwargs)
 files[identity]=storage._files_by_id[identity].content
 return identity
MemoryMediaFileStorage.load_and_get_id=observe

def button(at,label):return next(x for x in at.button if x.label==label)
def visible(at):return '\n'.join(str(x.value) for k in ('title','caption','info','warning','error','success','markdown','text_area','code') for x in getattr(at,k))
def capture(row):
 native_path=Path(row['native']);native_path=native_path if native_path.is_absolute() else a.cases.resolve().parent/native_path
 c=decode_project(native_path.read_bytes());tag=row['tag'];detailed=row.get('detailed',False)
 at=AppTest.from_file(str(source/'app.py'),default_timeout=300)
 at.session_state['connection_family']=FAMILY;at.session_state[PROJECT]=c.to_dict();at.run()
 assert not at.exception,[x.message for x in at.exception]
 assert len(at.selectbox(key='connection_family').options)==19
 assert at.session_state[PROJECT]==c.to_dict()
 r=at.session_state[RESULT];assert r==analyze(c)
 if row.get('expected_status'):assert r['status']==row['expected_status'],(tag,r['status'],row['expected_status'])
 if 'expected_complete' in row:assert r.get('complete')==row['expected_complete'],(tag,r.get('complete'),row['expected_complete'])
 assert at.session_state['cg_mc_current']==memory_text(c)
 if detailed:at.checkbox(key='cg_report_detailed').check().run();assert not at.exception
 ready=checks_complete(r)
 if ready:button(at,'Gerar memória de canto').click().run();assert not at.exception
 else:assert button(at,'Gerar memória de canto').disabled
 exports={}
 for item in at.get('download_button'):
  data=files[Path(item.proto.url).name.rsplit('.',1)[0]]
  ext='.png' if data.startswith(b'\x89PNG') else '.docx' if data.startswith(b'PK') else '.svg' if b'<svg' in data[:1000] else '.json' if data.lstrip().startswith(b'{') else '.txt'
  if ext=='.json' and 'connection' not in json.loads(data):ext='.results.json'
  target=out/(tag+ext);target.write_bytes(data)
  exports[ext]={'path':str(target),'bytes':len(data),'sha256':sha(data),'label':item.label,'emitted_url':item.proto.url}
 assert {'.png','.svg','.json','.results.json'}<=set(exports),exports
 assert json.loads(Path(exports['.json']['path']).read_text())==c.to_dict()
 assert decode_project(Path(exports['.json']['path']).read_bytes())==c
 assert json.loads(Path(exports['.results.json']['path']).read_text())=={'input':c.to_dict(),'result':r}
 assert ('.docx' in exports)==ready
 assert Path(exports['.png']['path']).read_bytes()==image_bytes(c,fmt='png')
 assert Path(exports['.svg']['path']).read_bytes()==image_bytes(c,fmt='svg')
 assert input_fingerprint(c) in Path(exports['.svg']['path']).read_text()
 (out/(tag+'_ui.txt')).write_text(visible(at));(out/(tag+'_mc.txt')).write_text(at.session_state['cg_mc_current'])
 controls=[{'kind':kind,'key':getattr(item,'key',None),'label':getattr(item,'label',None),'value':getattr(item,'value',None)} for kind in ('number_input','text_input','selectbox','checkbox','radio') for item in getattr(at,kind)]
 (out/(tag+'_controls.json')).write_text(json.dumps(controls,ensure_ascii=False,indent=2,default=str)+'\n')
 if ready:
  docbytes=Path(exports['.docx']['path']).read_bytes();doc=Document(BytesIO(docbytes))
  text='\n'.join([x.text for x in doc.paragraphs]+[cell.text for table in doc.tables for rr in table.rows for cell in rr.cells])
  (out/(tag+'_word.txt')).write_text(text)
  with ZipFile(BytesIO(docbytes)) as z:
   media=[z.read(n) for n in z.namelist() if n.startswith('word/media/')]
  assert Path(exports['.png']['path']).read_bytes() in media
  assert effort_convention_png(c) in media
  if detailed:assert all(x['id'] in text for x in r['checks'])
 groups=physical_envelopes(r)
 return {'tag':tag,'status':r['status'],'complete':r.get('complete'),'issues':r.get('issues'),'detailed':detailed,'resistant_report_ready':ready,'input_sha256':input_fingerprint(c),'check_count':len(r.get('checks',[])),'physical_group_count':len(groups),'compact_group_count':len(compact_envelopes(r)),'groups':[{'label':g['component_label'],'status':g['status'],'members':len(g['members'])} for g in groups],'exports':exports}

records=[]
for row in json.loads(a.cases.read_text()):
 print('CAPTURE',row['tag'],flush=True)
 record=capture(row);records.append(record)
 (out/'DOWNLOAD_RECEIPT.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
 print('PASS',record['tag'],record['status'],record['check_count'],record['physical_group_count'],flush=True)
after=file_hashes(runtime)
loaded={name:{'path':str(Path(mod.__file__).resolve()),'sha256':sha(Path(mod.__file__).read_bytes())} for name,mod in sys.modules.items() if (name=='lro' or name.startswith('lro.')) and getattr(mod,'__file__',None)}
receipt={'actual_outer_entry':str(source/'app.py'),'outer_entry_sha256':sha((source/'app.py').read_bytes()),'embedded_bundle_sha256':sha((source/'codigo_lro.zip').read_bytes()) if (source/'codigo_lro.zip').exists() else None,'wrapper_extraction':wrapper_extraction,'loaded_runtime_root':str(runtime),'runtime_files_unchanged':before==after,'before':before,'after':after,'loaded_application_modules':loaded,'python':sys.version,'packages':{n:importlib.metadata.version(n) for n in ['streamlit','pandas','matplotlib','python-docx','pytest','numpy']},'not_claimed':['Browser DOM click','Operating-system download','Clipboard click','Numerical method approval']}
(out/'RUNTIME_PROVENANCE.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
assert before==after,'Runtime source changed during capture'
