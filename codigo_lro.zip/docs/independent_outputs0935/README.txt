Independent0.9.35 output acceptance. Source GO and final APP-only replay are distinct gates. Run with runtime dependencies plus Streamlit AppTest/pytest available:

PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=<test_dependencies> python -B replay_finalapp.py <fresh exact APP directory containing app.py and codigo_lro.zip> <external output directory>

Do not place a source checkout or optional companion ZIP on PYTHONPATH. The actual APP wrapper is started and its private extraction observed; loaded module bytes must match SOURCE_RUNTIME_HASHES. Twenty-two current scenarios, eight callback groups and four older-adapter states are replayed. Word comparisons cover every word/ XML/media member, excluding ZIP/core timestamps only. Current corner SVG/native/results/PNG bytes are exact; legacy SVG normalizes only generated dc:date and bijective defs IDs, with seven mutation witnesses. No browser clicks, OS download dialog or clipboard interaction is claimed.

Large actual outputs, SVG rasterizations and rendered Word pages are retained outside APP under the evidence root recorded in RETAINED_EVIDENCE_MANIFEST; they are audit material, never runtime dependencies.
