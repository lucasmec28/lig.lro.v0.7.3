"""Independent main-app callbacks and atomic native import acceptance."""
from pathlib import Path
from dataclasses import replace
from copy import deepcopy
import sys,json,hashlib,os,traceback
source=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();out.mkdir(parents=True,exist_ok=True);sys.path.insert(0,str(source));here=Path(__file__).resolve().parent
from streamlit.testing.v1 import AppTest
if (source/'codigo_lro.zip').exists():
 boot=AppTest.from_file(str(source/'app.py'),default_timeout=300).run();assert not boot.exception
from lro.corner_gusset import CornerGusset as C,FAMILY,analyze,BOLTED_FIELDS
from lro.corner_compression import RESTRAINT_FIELDS,geometry_stamp
from lro.corner_gusset_ui import PROJECT,RESULT,REPORT,TEMPLATE,ACCEPTED,DRAFT,_key,decode_project,checks_complete
from lro.corner_gusset_presentation import memory_text,approved
base=decode_project((here/'inputs/CC2_compact.json').read_bytes());records=[]
runtime=Path(sys.modules['lro'].__file__).resolve().parent.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before={str(p.relative_to(runtime)):sha(p) for pattern in ('app.py','lro/*.py','data/*.json','requirements*.txt') for p in runtime.glob(pattern)}
def fresh(c=base):
 at=AppTest.from_file(str(source/'app.py'),default_timeout=300);at.session_state['connection_family']=FAMILY;at.session_state[PROJECT]=c.to_dict();at.run();assert not at.exception;return at
def button(at,label):return next(x for x in at.button if x.label==label)
def snap(at):return {k:deepcopy(at.session_state[k]) for k in (PROJECT,RESULT,REPORT,TEMPLATE,ACCEPTED,DRAFT) if k in at.session_state}
def upload(at,payload):
 data=payload if isinstance(payload,bytes) else json.dumps(payload).encode()
 at.get('file_uploader')[0].upload('independent.json',data,'application/json').run();button(at,'Carregar projeto de canto').click().run();assert not at.exception

def record(name,fn):
 if os.environ.get('ONLY') and os.environ['ONLY'] not in name:return
 print('RUN',name,flush=True)
 try:detail=fn();records.append({'name':name,'pass':True,'detail':detail});print('PASS',name,flush=True)
 except Exception as exc:traceback.print_exc();records.append({'name':name,'pass':False,'error':repr(exc)});print('FAIL',name,repr(exc),flush=True)
 (out/'CALLBACK_RECEIPT.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')

def decoder():
 tested=[];native=base.to_dict()
 for field,value in native['connection'].items():
  mutations=[]
  if type(value) in (int,float):mutations=[('bool',True),('nan',float('nan')),('positive_inf',float('inf')),('negative_inf',-float('inf')),('number_string','1')]
  elif field in RESTRAINT_FIELDS:mutations=[('wrong_type',True),('wrong_type_integer',1)]
  for label,badval in mutations:
   bad=deepcopy(native);bad['connection'][field]=badval
   try:decode_project(json.dumps(bad));raise AssertionError('Accepted '+field+':'+label)
   except (TypeError,ValueError):pass
   tested.append(field+':'+label)
 for field in RESTRAINT_FIELDS:
  bad=deepcopy(native);bad['connection'].pop(field)
  try:decode_project(json.dumps(bad));raise AssertionError('Missing '+field+' accepted')
  except (TypeError,ValueError):pass
  tested.append(field+':missing')
 for field in RESTRAINT_FIELDS[:3]:
  bad=deepcopy(native);bad['connection'][field]='approved'
  try:decode_project(json.dumps(bad));raise AssertionError('Unsupported enum '+field+' accepted')
  except (TypeError,ValueError):pass
  tested.append(field+':invalid_enum')
 for label,mutate in [('unknown',lambda b:b['connection'].update(compression_approved=True)),('wrong_units',lambda b:b['units'].update(force='kN')),('wrong_fixed',lambda b:b['fixed_assumptions'].update(gusset_count=2))]:
  bad=deepcopy(native);mutate(bad)
  try:decode_project(json.dumps(bad));raise AssertionError(label+' accepted')
  except (TypeError,ValueError):pass
  tested.append(label)
 return {'rejected_cases':len(tested),'tests':tested}
record('strict finite and restraint native decoder',decoder)

def atomic():
 at=fresh();button(at,'Gerar memória de canto').click().run();assert REPORT in at.session_state;initial=snap(at)
 variants=[]
 for field,value in [('compression_beam_restraint',True),('compression_column_restraint','approved'),('compression_geometry_stamp',12),('P',float('nan')),('plate_t',float('inf')),('compression_extra_approval',True)]:
  bad=deepcopy(initial[PROJECT]);bad['connection'][field]=value;variants.append(bad)
 bad=deepcopy(initial[PROJECT]);bad['connection'].pop('compression_detail_source');variants.append(bad)
 for bad in variants:
  upload(at,bad);assert any('Não foi possível abrir' in x.value for x in at.error);assert snap(at)==initial
 return {'actual_rejected_uploads':len(variants),'preserved_keys':list(initial)}
record('atomic rejected file uploads',atomic)

def physical_binding():
 at=fresh();original=deepcopy(at.session_state[PROJECT]);stamp=original['connection']['compression_geometry_stamp']
 button(at,'Gerar memória de canto').click().run();assert REPORT in at.session_state
 # This force edit must retain physical qualification, but invalidate its old report.
 at.number_input(key=_key('P')).set_value(-20.).run();assert not at.exception
 c=C.from_dict(at.session_state[PROJECT]);r=at.session_state[RESULT]
 assert c.compression_geometry_stamp==stamp==geometry_stamp(c) and r['compression']['qualified']
 assert REPORT not in at.session_state and r['forces']['H']<0 and abs(r['forces']['H']**2+r['forces']['V']**2-20000.**2)<1e-5
 for n in ['beam_cut_Fx','beam_cut_Fy','beam_cut_M','upper_column_cut_Fx','upper_column_cut_Fy','upper_column_cut_M']:assert getattr(c,n)==original['connection'][n]
 at.text_input(key=_key('project')).set_value('Force-only replay project label').run();assert not at.exception
 c=C.from_dict(at.session_state[PROJECT]);assert geometry_stamp(c)==stamp
 # Materials affect resistance but do not describe a different restraint layout.
 at.selectbox(key=_key('gusset_steel')).set_value('ASTM A572 Gr.50').run();assert not at.exception
 c=C.from_dict(at.session_state[PROJECT]);assert geometry_stamp(c)==stamp and at.session_state[RESULT]['compression']['declaration_matches_geometry']
 at.number_input(key=_key('corner_clip')).set_value(31.).run();assert not at.exception
 r=at.session_state[RESULT];assert not r['complete'] and any(i['id']=='compression_geometry_declaration' for i in r['issues']) and button(at,'Gerar memória de canto').disabled
 assert at.session_state[PROJECT]['connection']['compression_geometry_stamp']==stamp
 saved=deepcopy(at.session_state[PROJECT]);upload(at,saved);assert at.session_state[PROJECT]==saved and not at.session_state[RESULT]['complete']
 at.number_input(key=_key('corner_clip')).set_value(30.).run();assert not at.exception
 assert at.session_state[RESULT]['compression']['declaration_matches_geometry']
 return {'force_and_project_material_retain_geometry_binding':True,'changed_clip_stale_after_reopen':True,'restored_geometry_identity_valid':True}
record('force preservation geometry invalidation and reopening',physical_binding)

def statuses():
 at=fresh();result=[]
 for field in RESTRAINT_FIELDS[:3]:
  for value in ('unknown','absent'):
   at.selectbox(key=_key(field)).set_value(value).run();assert not at.exception
   r=at.session_state[RESULT];assert any(i['id']==field for i in r['issues']) and not r['complete'] and not approved(r)
   assert button(at,'Gerar memória de canto').disabled
   # Existing receiver-only lateral restraint stays true and cannot cure it.
   assert at.session_state[PROJECT]['connection']['lateral_restraint'] is True
   result.append(field+':'+value)
   at.selectbox(key=_key(field)).set_value('confirmed').run();assert not at.exception
 at.number_input(key=_key('P')).set_value(-100.).run();at.selectbox(key=_key(RESTRAINT_FIELDS[0])).set_value('unknown').run();assert not at.exception
 r=at.session_state[RESULT];assert r['status']=='FAIL' and not r['complete'] and any(x['status']=='FAIL' for x in r['checks'])
 assert any('VERIFICAÇÃO INCOMPLETA' in x.value for x in at.error)
 return {'status_control_cases':result,'real_receiver_failure_survives_unknown':True}
record('three physical restraints independent from receiver lateral flag',statuses)

def native_and_routes():
 at=fresh();saved=deepcopy(at.session_state[PROJECT]);upload(at,saved);assert at.session_state[PROJECT]==saved
 options=at.selectbox(key='connection_family').options;assert len(options)==19
 at.selectbox(key='connection_family').set_value(options[0]).run();assert not at.exception
 at.selectbox(key='connection_family').set_value(FAMILY).run();assert not at.exception and at.session_state[PROJECT]==saved
 old=[]
 for filename in ('received_0932_welded_2LT.json','received_0933_welded_1L.json'):
  data=(here/'inputs'/filename).read_bytes();c=decode_project(data);upload(at,data);assert at.session_state[PROJECT]==c.to_dict() and at.session_state[RESULT]==analyze(c)
  old.append({'name':filename,'topology':c.topology,'default_restraints':c.compression_beam_restraint})
 return {'routes':options,'native_exact_after_reopen_and_navigation':True,'old_inputs':old}
record('19 routes native reopen and old file imports',native_and_routes)

def sign_only_and_minimum():
 summary=[]
 for topology in ('symmetric_2L_T_welded','single_1L_welded'):
  c=replace(base,topology=topology,symmetric=not topology.startswith('single'),P=20000.)
  at=fresh(c)
  for value in (20.,0.,-20.):
   at.number_input(key=_key('P')).set_value(value).run();assert not at.exception
   current=C.from_dict(at.session_state[PROJECT]);r=at.session_state[RESULT]
   assert current.P==value*1000 and at.session_state['cg_mc_current']==memory_text(current)
   if value<0 and topology.startswith('single'):assert not r['complete'] and not approved(r)
   elif value>=0:assert r['complete'] and r['status']=='PASS'
   summary.append({'topology':topology,'P':current.P,'status':r['status'],'complete':r['complete'],'force_case_keys':list(r.get('force_cases',{}))})
 return {'scenarios':summary,'intentional_0935_change':'Low-positive/zero welded strength-minimum cases added; 0934 minimum applied only to bolted adapters.'}
record('sign only dispatch and welded minimum conventions',sign_only_and_minimum)

def declaration_protocol():
 at=fresh(C());assert not any(x.key==_key('compression_beam_restraint') for x in at.selectbox)
 at.number_input(key=_key('P')).set_value(-50.).run();assert not at.exception
 assert at.selectbox(key=_key('compression_beam_restraint')).value=='unknown'
 assert not at.session_state[RESULT]['complete']
 button(at,'Registrar contenções na geometria atual').click().run();assert not at.exception
 assert at.session_state[PROJECT]['connection']['compression_geometry_stamp']=='undeclared'
 for name in RESTRAINT_FIELDS[:3]:at.selectbox(key=_key(name)).set_value('confirmed').run();assert not at.exception
 button(at,'Registrar contenções na geometria atual').click().run();assert not at.exception
 assert at.session_state[PROJECT]['connection']['compression_geometry_stamp']=='undeclared'
 at.text_input(key=_key('compression_detail_source')).set_value('Independent ordinary-detail test: actual 30 mm free clip, effective 550 mm roots, symmetric continuous 2L overlap; all three physical restraints declared solely for this fixture.').run()
 button(at,'Registrar contenções na geometria atual').click().run();assert not at.exception
 c=C.from_dict(at.session_state[PROJECT]);assert c.compression_geometry_stamp==geometry_stamp(c) and at.session_state[RESULT]['complete']
 at.number_input(key=_key('corner_clip')).set_value(31.).run();assert not at.exception and not at.session_state[RESULT]['complete']
 at.text_input(key=_key('compression_detail_source')).set_value('Independent explicitly revised ordinary-detail test: actual 31 mm free clip, unchanged end margins and symmetric continuous 2L overlap; updated roots and three physical restraints declared for this fixture only.').run()
 button(at,'Registrar contenções na geometria atual').click().run();assert not at.exception
 c=C.from_dict(at.session_state[PROJECT]);assert c.compression_geometry_stamp==geometry_stamp(c) and at.session_state[RESULT]['complete']
 return {'positive_to_negative_group_seeded':True,'unknown_restraints_not_approved_by_button':True,'unknown_source_not_approved_by_button':True,'explicit_current_detail_bound':True,'explicit_revised_detail_bound':True}
record('explicit declaration protocol and new negative branch',declaration_protocol)

def cleared_detail():
 at=fresh(replace(base,P=-100000.));at.text_input(key=_key('compression_detail_source')).set_value('').run();assert not at.exception
 r=at.session_state[RESULT];assert r['status']=='FAIL' and not r['complete'] and any(i['id']=='compression_detail_source' for i in r['issues'])
 assert any(x['status']=='FAIL' for x in r['checks']) and button(at,'Gerar memória de canto').disabled
 for tag in ('CC1_compact','CC3_pending_failure'):
  native=json.loads((here/'inputs'/(tag+'.json')).read_text());native['connection']['compression_geometry_stamp']='  '
  upload(at,native);r=at.session_state[RESULT];assert r['status']=='FAIL' and not r['complete']
  assert any(i['id']=='compression_geometry_declaration' for i in r['issues']) and any(x['status']=='FAIL' for x in r['checks'])
 return {'cleared_source_retains_receiver_failure':True,'blank_imported_stamp_retains_CC1_and_CC3_failures':True}
record('cleared detail retains meaningful calculated failures',cleared_detail)

after={str(p.relative_to(runtime)):sha(p) for pattern in ('app.py','lro/*.py','data/*.json','requirements*.txt') for p in runtime.glob(pattern)}
(out/'RUNTIME_PROVENANCE.json').write_text(json.dumps({'runtime_root':str(runtime),'before':before,'after':after,'runtime_unchanged':before==after,'not_claimed':['Browser DOM click','OS download dialog','Clipboard interaction']},indent=2)+'\n')
assert before==after,'Source changed during callback run'
print(json.dumps({'passed':all(x['pass'] for x in records),'groups':len(records)},indent=2),flush=True)
if not all(x['pass'] for x in records):raise SystemExit(1)
