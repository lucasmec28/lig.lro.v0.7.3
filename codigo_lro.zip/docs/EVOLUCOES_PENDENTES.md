# Evoluções pendentes

Estado atual da integração 0.9.11-pinned-endplate-audit-dev. A terceira família existente, end plate rotulada, recebeu a correção delimitada de detalhamento/importação/apresentação. As quatro qualificações locais explícitas estão em `PINNED_END_PLATE_AUDIT0911_METHOD.md`; não houve fechamento artificial do mecanismo completo. Histórico da etapa anterior: A revisão delimitada da segunda família, duas talas, corrige fidelidade da interface e filetes por junta, conserva mecanismos resistentes distintos e mostra junto à conclusão as duas qualificações locais ainda abertas. Método: `DOUBLE_COVER_AUDIT0910_METHOD.md`. A reconciliação Single plate recuperou/conferiu o P901 e corrigiu o bloco L completo Bv da chapa de duas colunas; a pendência documental restante é o domínio integral da dispensa automática da Tabela 10-9. Ver `SINGLE_PLATE_AUDIT099_METHOD.md`.

## Sequência de trabalho definida

A sequência após a revisão 0.9.8 das bases começou pela Single plate na 0.9.9 e alcança duas talas na 0.9.10. As qualificações abertas são precisas e não impedem encerrar as correções demonstradas: não confundir revisão finita com aprovação irrestrita da família. Prosseguir pela ordem do catálogo somente mediante próxima etapa, antes de novas famílias; esta versão não inicia outra auditoria nem amplia modelos existentes.

## Desenhos dinâmicos — prioridade baixa

Revisar posicionamento de textos, cotas e linhas à medida que as dimensões mudam, reduzindo sobreposições e verificando se cada chamada aponta para o elemento correto. Considerar a captura enviada pelo usuário em 9 de outubro de 2026. Este pedido é uma melhoria futura e não amplia as verificações estruturais desta versão.

## Bases engastada e rotulada

Já disponíveis: Tipo 1 com quatro chumbadores externos e N/M/V; Tipo 2 com quatro internos e N/V; atrito, chumbadores com arruelas soldadas e chaves; contato/flexão/corte locais da chave simples e das chapas ativas cruz/W; solda/furo da arruela; cone, pullout, ruptura lateral, cortante, pryout e interação ACI da ancoragem em seus domínios; solda pilar–placa qualificada por duas mesas N/M e alma V, com filete/CJP independentes.

Na chave retangular única, a versão 0.9.6 acrescentou o componente dos dois filetes opostos: ações prescritas integrais Vw/Mw da NBR, binário local documentado, resistência do metal da solda e requisitos numéricos de detalhamento. A versão 0.9.7 acrescenta o componente complementar conservador ACI de contato da chave e três superfícies de ruptura de borda, com recorte no bloco real e políticas explícitas. Há estados completos separados para o centroide NBR físico e o centroide ACI limitado; nenhuma ação N/M/V do topo é substituída. Tipo 1 mantém sua topologia uniforme declarada e Tipo 2 conserva C1/C2/T1/T2. Uma chave profunda não é proibida automaticamente, mas o estado suplementar precisa permanecer compatível e qualificado.

A aplicação desse concreto complementar exige dados reais de restrição das barras, preenchimento/consolidação e respiros, além das condições de ancoragem e áreas documentadas quando houver tração nas barras. Solda perimetral de arruela não comprova barra soldada. Barras efetivamente soldadas ou rigidamente ligadas ainda exigem o modelo concorrente de interação específico. O ramo omite aumentos positivos de membro fino/estreito; não implementa todas as opções da norma. Os resultados locais independentes e as falhas conhecidas permanecem visíveis quando uma qualificação ou um estado de equilíbrio está pendente.

Permanecem: transferência local completa arruela–placa e metal-base/transferência da placa na solda do pilar; comprovação mecânica da cabeça/porca/chapa enterrada quando não documentada; metal-base, fixação e flexão local da placa receptora da chave; soldas, concreto específico e componentes inativos das chaves cruz/W fora dos seus domínios já calculados; resistência e soldas do par de enrijecedores quando selecionado. Também permanecem os modos de ancoragem ou detalhe não cobertos por dados válidos no projeto, fendilhamento, cobrimentos, armaduras, juntas e transferência global ao bloco/fundação/solo.

Rigidez rotacional, outros eixos/torção, ações cíclicas/sísmicas e ancoragens fora do domínio não são aprovados. Gancho J pode permanecer adiado. Não há requisito genérico de FEA para detalhes convencionais. Nenhum componente ou conjunto parcial de resultados aprova a chave, a ancoragem ou a base completa.

Em uma futura retomada das bases, os itens deverão tratar os caminhos físicos remanescentes, especialmente metal-base e transferência da placa receptora, sem repetir como pendentes os componentes já calculados. Isso não precede a auditoria sequencial das ligações existentes agora solicitada. Ver `SINGLE_KEY_WELD_COMPONENT.md` e `SINGLE_KEY_CONCRETE_COMPONENT.md` para os limites exatos.

## Cantoneiras

R016 toda parafusada, R015 soldada/parafusada e R017 com recorte convencional já estão implementadas. Permanecem cantoneira única, abas estendidas e geometrias/ações fora dos domínios publicados; conservar os requisitos de travamento e detalhamento de cada modelo.

## Emenda W

A variante axial M004 preserva seu modelo e seus projetos salvos. A família separada convencional N/M/V da 0.9.5 admite compressão, tração, momento e cortante simultâneos, reversões e casos puros, com perfis/chapas/parafusos variáveis. Usa oito talas: todo N/M nas seis talas de mesa e V com sua excentricidade real nas duas talas de alma. A malha da alma é regular 2×3 por extremidade e as talas de mesa permanecem simétricas e balanceadas. A admissão é feita por desigualdades finitas, geometria, detalhamento e condições explícitas; não se limita a um único W310.

Inclui compressão das tiras separadas com flambagem flexional/torsional e seção efetiva, todos os planos de corte e contatos reais dos parafusos, 84 caminhos de bloco das talas de alma, integral exata da seção líquida, verificações locais de talas e membro conectado e envelope assinado de ações. A política de forças mínimas mantém os casos originais e suplementares identificados. UI, JSON, Word e desenho declaram o modelo e o estado exato. Falhas calculadas permanecem visíveis mesmo quando outro requisito impede a conclusão.

Permanecem fora desse domínio: malhas arbitrárias, talas não balanceadas, perfis distintos/não coaxiais, contato resistente de topo, calços participantes, rasgos/recortes, flexão menor, torção e ações de fadiga/cíclicas/sísmicas. A estabilidade global do membro, os esforços de análise global, a rigidez da ligação e o deslizamento de serviço não são certificados pela verificação local. A ausência de deslizamento, quando exigida, conserva sua pendência específica. A correspondência do bloco escalar além dos limites de excentricidade/subconjuntos fica pendente sem apagar os demais resultados finitos. Condições de apoio/montagem e detalhamento não conformes também impedem aprovação.

Ver domínio e fontes em W_CONVENTIONAL_NMV_SCOPE.md, CONVENTIONAL_W_IMPLEMENTATION_CONTRACT.md e PARAMETRIC_DOMAIN_ADDENDUM.md. As referências recebidas fundamentam esta rota convencional; não existe pendência genérica de “aguardar livros” para o domínio já implementado. Esta conclusão não se estende a toda geometria possível de emenda W.
