# Evoluções pendentes

## Desenhos dinâmicos — prioridade baixa

Revisar posicionamento de textos, cotas e linhas à medida que as dimensões mudam, reduzindo sobreposições e verificando se cada chamada aponta para o elemento correto. Considerar a captura enviada pelo usuário em 9 de outubro de 2026. Este pedido é uma melhoria futura e não amplia as verificações estruturais desta versão.

## Chumbadores ao cisalhamento

A versão 0.8.1 apresenta o caminho como comparação externa documentada para o grupo instalado e a combinação atual. Um modelo interno conforme NBR 6.7.2.5, com interação e detalhamento necessários, requer um incremento técnico próprio.
