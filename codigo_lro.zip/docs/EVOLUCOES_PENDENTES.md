# Evoluções pendentes

## Desenhos dinâmicos — prioridade baixa

Revisar posicionamento de textos, cotas e linhas à medida que as dimensões mudam, reduzindo sobreposições e verificando se cada chamada aponta para o elemento correto. Considerar a captura enviada pelo usuário em 9 de outubro de 2026. Este pedido é uma melhoria futura e não amplia as verificações estruturais desta versão.

## Chumbadores ao cisalhamento

A 0.8.2 implementa o modelo local com quatro arruelas soldadas, trações concorrentes, limite conservador para a ambiguidade do índice publicado, interação geral separada e limite local de concreto. A próxima etapa limitada é dimensionar a solda arruela–placa e a transferência local, com geometria/material reais e ação Fv,Rd sem redução. Ancoragem no concreto, efeitos de borda/grupo, bloco armado, soldas do pilar e rigidez permanecem separados. Veja CHUMBADORES_CORTANTE_V082.md.
