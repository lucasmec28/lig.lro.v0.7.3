# Validação do incremento0.9.4

Fonte final:0.9.4-base-weld-dev. As fontes0.9.2 e0.9.3 permaneceram intactas. As verificações abaixo qualificam o software no escopo declarado; não aprovam um projeto executivo nem o conteúdo de uma memória externa.

## Resultado agregado e correções de teste

A execução agregada terminou com **1463 testes aprovados e2 falhas de asserções de teste**, em968,39s. Ela havia coletado as asserções anteriores às correções:

1. Um teste da entrada propositalmente inválida Tipo2 tentou recarregar o JSON com validação estrita, depois de já comprovar que a interface mostrava a interferência e bloqueava os artefatos. A correção lê somente a assinatura do rascunho salvo nesse ponto; não enfraquece a validação.
2. Um teste de navegação R017 esperava a versão global0.9.3 na legenda. A correção usa a versão global atual0.9.4 e exige, separadamente, que a identidade do componente R017 continue0.9.3.

Não houve alteração de código de produção durante a execução final. Os dois arquivos de teste corrigidos constam do registro de diferenças.

Reexecuções finais:

-32 testes de interface das soldas aprovados, incluindo geração Word, importações, assinaturas, trocas perna/garganta e recuperação de geometria inválida.
-4 casos focalizados de geometria inválida→válida aprovados, preservando as falhas originais e impedindo relatórios/desenhos obsoletos.
-1 teste corrigido da versão global/identidade R017 aprovado.
-251 verificações independentes mais4 casos de recuperação:255 aprovados.
-31 testes de artefatos aprovados, incluindo planos físicos, sinais, CJP única, rejeição de resultado obsoleto e ausência de vazamento de figuras em entradas recusadas.

Os1465 casos coletados têm evidência de aprovação entre o agregado e as reexecuções das asserções corrigidas. **Não se declara uma execução única com1465 aprovações.**

## Evidência técnica e visual

A auditoria independente reproduziu os casos de estática assinada com Decimal e comparou os dados DG1 com a convenção resistente NBR. O filete de1/4pol. do exemploDG1 não recebe aprovação AISC emprestada: ηNBR=1,084555858. O escopo mantém separadas a qualificação de transferência, a resistência numérica e a base completa.

Oito exemplos, em32 arquivos JSON/Word/SVG/PNG, são identificados como DIDÁTICOS e usam registros sintéticos de ensaio ou qualificação ausente/obsoleta. Seus vínculos, estados e equilíbrios foram recarregados e conferidos. Foram inspecionadas22 páginas renderizadas: relatório completo de filetes, componente CJP e componente de contato preparado. As alterações finais de assinatura/guardas foram comparadas diretamente e não mudaram o conteúdo desses exemplos.

O smoke de processo novo verificou as duas famílias, quatro combinações de juntas independentes, perna/garganta, importação repetida, pendência, falha numérica, invalidação e recuperação, desenho e Word. A distribuição final deve repetir esse smoke em processo novo contra seu pacote real.

Registros e resumos: `validation/v094/FINAL_VALIDATION_RECORD_094.json`, `FINAL_ARTIFACT_RECORD_094.json`, `independent_FINAL_REVIEW.md` e registros de correções no mesmo diretório. Os hashes de produção e a evidência da execução integral são mantidos no registro de entrega. O manifesto da distribuição é gerado pelo empacotamento, depois desta validação.
