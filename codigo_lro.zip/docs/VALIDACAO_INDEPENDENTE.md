# Limites de validação e continuação

> Atualização 0.7.2: o enrijecedor oposto passou a estar disponível no detalhamento viga–viga, sem crédito resistente. Corrigida a transcrição da alternativa rigorosa de punção sob V puro para ts·tp. Consulte AJUSTES_V072.md; descrições anteriores permanecem como histórico.
> Registro técnico histórico. A versão 0.7.1 permite calcular com avisos de montagem e restaura o complemento entre mesas apenas no detalhamento, sem verificações extras nem crédito resistente. As referências ao bloqueio dessa opção descrevem o comportamento anterior. Consulte AJUSTES_V071.md.

A versão 0.5.1 mantém a variante entre mesas retirada e exclui a interação fora do plano da alma da viga sob N+V ou N excêntrico, com nota no app e no Word. A conclusão abrange somente as verificações realizadas. Para reintroduzir ou concluir esses modelos, comparar o nó inteiro com referência ou modelo numérico validado, abrangendo geometria, materiais, soldas, parafusos, vínculos, imperfeições e critérios de estabilidade/rotação. Equilíbrio de um grupo de soldas e índices isolados não bastam.

Separar: (1) teste do código; (2) conferência de equação; (3) adequação do modelo ao detalhe; (4) validação integral. Os 113 testes e as 13 comparações desta versão documentam principalmente as duas primeiras categorias. Os limites da terceira e da quarta permanecem expressos nos resultados e na revisão técnica.
