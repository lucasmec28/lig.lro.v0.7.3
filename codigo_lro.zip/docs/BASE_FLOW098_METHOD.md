# Bases: método e fluxo 0.9.8-base-flow-dev

## Objetivo e hierarquia técnica

Esta revisão consolida a entrada e a aplicabilidade das verificações existentes. Não acrescenta uma nova família, fórmula resistente ou uma aprovação geral de fundações. Permanecem 11 famílias, seus esquemas de projeto e versões de componentes.

- A base nativa brasileira usa ABNT NBR 8800:2024, com Errata 1:2025. Ações são de cálculo na face superior; Tipo 1 e Tipo 2 conservam suas equações e seus limites físicos próprios.
- AISC Design Guide 1, terceira edição (2024, errata de maio de 2025), organiza o caminho de forças e os componentes complementares. ACI 318-19, capítulo 17, continua com seus fatores e modos próprios onde esse método é selecionado; não se misturam denominadores NBR/ACI.
- Alex Sander Clemente de Souza, Dimensionamento de elementos e ligações em estruturas de aço, capítulo 11, serve de comparação e explicação prática. Suas hipóteses elásticas triangular/trapezoidal e referências antigas de ancoragem não são somadas ao procedimento NBR/DG1 mais recente. Não se impõe o mínimo antigo de 12d como uma obrigação adicional nem se substitui o aço A36 por SAE 1020.

Fontes oficiais de edição/errata: [catálogo AISC](https://www.aisc.org/aisc/publications/design-guides/design-guide-summary/) e [errata DG1](https://www.aisc.org/globalassets/aisc/publications/revisions-and-errata/design-guide-1-3rd-ed.-revisions-and-errata-list.pdf). As cópias fornecidas pelo usuário fundamentam a leitura das cláusulas; este documento não reproduz seu conteúdo.

## Caminho de cortante e demanda de cada componente

Uma rota é selecionada por vez, sem soma automática de atrito, chave e chumbadores. O resultado ACI passa a registrar V_column, V_anchor, V_key e V_friction, em N, com o caminho e a aplicabilidade.

- Chumbadores: V_anchor=V_column. Conservam-se a tração Ti de cada barra, a distribuição física documentada, as capacidades condicionadas NBR e os estados reais alternativos de linhas do concreto.
- Atrito: V_friction=V_column e V_anchor=0, conforme a hipótese expressa de caminho exclusivo. A capacidade do atrito e a ausência de compressão continuam sendo verificadas. Dados antigos da chave, que está inativa, não alteram esse caminho.
- Chave retangular única: V_key=V_column. V_anchor=0 somente com o dado físico explícito de barras não soldadas/sem ligação rígida à placa. Esse fato não exige texto de referência para definir a demanda. Barras de restrição desconhecida ou efetivamente soldadas/rigidamente ligadas deixam a interação específica pendente; não se presume Vi=0 ou V/4. A solda perimetral da arruela não define a restrição da barra.
- Outros dispositivos: a ausência de um contrato de restrição/demanda das barras permanece explicitamente fora deste incremento; não se generaliza a conclusão da chave única para cruz/W ou dispositivo externo.

V_anchor=0 torna ruptura ao cortante e pryout sem solicitação ou não aplicáveis, sem linha numérica de aprovação. Se todos Ti também forem zero, não são exigidas áreas de aço, apoio mecânico enterrado ou interação. Se houver Ti, continuam as verificações de tração aplicáveis, com Ase,N e fonte; Ase,V e distribuição de Vi não são exigidas. A interação desses estados usa beta_V=0, sem uma capacidade de cortante inventada.

ACI 17.7.1.1, R17.7.2.1 e DG1 exemplo 4.7-4 justificam conservar os estados de aço associados às superfícies de linhas próximas/distantes na rota real pelos chumbadores. Esta revisão não remove esses estados, seus envelopes ou as verificações por barra. As construções virtuais de borda paralela não viram forças físicas transversais.

## Uma comparação governante, detalhes preservados

No cortante nativo com arruelas soldadas, a resistência governante continua sendo a soma dos mínimos de cada barra entre expressão especial, interação geral e limite local de concreto. A tela e a memória não repetem duas comparações de grupo que são dominadas por essa soma. As três capacidades intermediárias e as resistências individuais permanecem nos resultados detalhados. Uma distribuição física ou estado de linhas continua sendo verificada em cada barra; a soma não substitui isso.

O domínio b<=100z da solda da arruela é uma fronteira do modelo sem redução implementado. Sair dele deixa a adequação do comprimento efetivo pendente; não cria uma proibição universal da NBR. Falhas físicas ou numéricas independentes permanecem visíveis. As ações prescritas de desenvolvimento de capacidade da chave e das arruelas permanecem integrais, inclusive quando V aplicado é zero.

## Entrada orientada pelo detalhe

1. Família, ações e geometria real.
2. Um caminho para o cortante, com seus dados físicos.
3. Uma seção de solda pilar–placa para tipos, dimensões, modelo e qualificação externa realmente necessária.
4. Dados de ancoragem e área compartilhada exibidos conforme a demanda.
5. Resultado calculado, dado ativo faltante, caminho local ainda não calculado e responsabilidade externa em categorias separadas.

Ase,N pode ser informada para barras tracionadas dos estados da chave mesmo com o conjunto complementar ACI da ancoragem desligado. Informar a área não seleciona outros modos nem os aprova. Cone e demais modos conservam a seleção salva do projeto: não há migração automática de método.

Os dois filetes completos da chave usam Lreal=Leff=bh derivados da largura informada quando esse detalhe padrão é escolhido. A opção manual conserva comprimentos importados não conformes e seu estado fora do modelo; não corrige dados para produzir aprovação. O tamanho perna/garganta continua fisicamente equivalente na troca de representação.

Rascunhos físicos negativos da solda da chave, arruela superior e dimensões de componentes desligados permanecem salvos, mas não bloqueiam atrito ou outro ramo realmente inativo. Na reativação, reaparecem com seu erro, sem correção silenciosa nem falha do editor. Tipos incorretos, enumerações inválidas e valores não finitos continuam sendo recusados, inclusive em rascunhos inativos; a geometria realmente usada no caminho ativo continua obrigatória.

## Solda pilar–placa: cálculo, evidência e execução

A estática assinada N/M nas duas mesas e V na alma é explicada automaticamente. Não se pede que o engenheiro escreva novamente as equações, as fontes do aplicativo e os requisitos usuais de solda contínua. Comprimentos físicos e efetivos continuam distintos e explícitos: a largura total da mesa não prova automaticamente a transferência por uma placa flexível.

O campo geral conserva uma referência específica da análise externa de compatibilidade placa–chumbadores/contato e de Leff, com método e vínculo aos dados pertinentes. Uma referência genérica não é uma resistência adicional; seu conteúdo continua sob responsabilidade técnica. Ausência desse vínculo mantém a transferência condicional, mesmo que o metal da solda calculado atenda.

Processo, preparação CJP, cobre-junta e requisitos de tenacidade efetivamente acionados continuam necessários. Um nome de WPS, relatório de inspeção ou três narrativas redundantes não são pré-requisitos para o cálculo numérico de projeto. Registros antigos são preservados e podem ser consultados/editados em campos opcionais. O aplicativo não verifica execução nem inspeção realizada.

Há duas identidades diferentes:

- Vínculo da análise externa: dados físicos, ações, materiais, Leff, método, referência principal e evidência de contato. Metadados opcionais não invalidam esse vínculo.
- Atualidade do resultado/exportação: assinatura completa da entrada. Editar qualquer entrada impede reutilizar o resultado antigo para Word/desenho, mesmo se o vínculo técnico continua válido.

Uma assinatura legada somente é reconhecida se coincidir exatamente com o algoritmo anterior para os mesmos dados. A interface informa sua preservação e atualiza o vínculo para o escopo atual. Mudança física não é migrada nem requalificada; retornar ao valor antigo após invalidação não restaura o vínculo por conta própria.

## Limites que permanecem reais

Não foram implementados catálogo completo de cabeça/porca padronizada, rota alternativa tabulada integral da NBR, novo modelo da placa receptora, novos enrijecedores, outra família ou mistura de modelos. A rota tabulada NBR exige o conjunto de suas condições, incluindo bloco/armaduras reais e projeto NBR 6118; botões para adotar espaçamentos não demonstram esse conjunto.

Continuam identificados os caminhos locais realmente não calculados, como flexão/transferência arruela–placa, metal-base e placa receptora da chave e compatibilidade da transferência pilar–placa. Bloco/armadura, fundação/solo, membro/rigidez global e conformidade de execução são responsabilidades separadas; não recebem aprovação implícita nem geram por si novos modos locais repetidos.

Depois desta revisão limitada das bases, a sequência solicitada é auditar as famílias já existentes uma por uma, começando por Single plate, antes de acrescentar outras famílias ao catálogo.
