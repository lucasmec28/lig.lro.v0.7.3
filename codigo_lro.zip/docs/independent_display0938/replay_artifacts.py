"""Portable representative19-route SVG+PNG+Word evidence replay.
Usage: python replay_artifacts.py APP_ROOT OUTPUT
Requires declared APP dependencies; exports written only to OUTPUT.
"""
import argparse,hashlib,json,os,subprocess,sys
from pathlib import Path
from artifact_geometry import svg_signature,digest
P=argparse.ArgumentParser();P.add_argument('app');P.add_argument('output');A=P.parse_args();ROOT=Path(A.app).resolve();OUT=Path(A.output).resolve();OUT.mkdir(parents=True,exist_ok=True);HERE=Path(__file__).resolve().parent
commit=json.loads((HERE/'runtime_expected.json').read_text());before={k:hashlib.sha256((ROOT/k).read_bytes()).hexdigest() for k in commit['files']};assert before==commit['files'],'Runtime commitment mismatch'
env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1';env['PYTHONPATH']=str(ROOT)+os.pathsep+env.get('PYTHONPATH','')
subprocess.run([sys.executable,str(HERE/'render_artifact_probe.py'),str(ROOT),str(OUT)],env=env,check=True)
actual={x['route']:x for x in json.loads((OUT/'RESULTS.json').read_text())};expected=json.loads((HERE/'artifact_expected.json').read_text());records=[]
from PIL import Image
for row in expected['routes']:
 route=row['route'];got=actual[route];assert not got['errors'] and got['native_unchanged_by_exports'] and got['result_unchanged_by_exports'],route
 assert got['preset']==row['preset'] and sorted(got['exports'])==row['surfaces'],route
 signature=svg_signature(OUT/(route+'.svg'));assert signature==row['svg'],(route,'SVG geometry or reviewed presentation changed')
 for kind,detail in row['word'].items():
  value=got['exports'][kind];assert digest(value['lines'])==detail['visible_lines_sha256'],(route,kind,'text');assert value['external_links']==detail['external_links'];assert value['omml_equations']==detail['omml_equations']
 with Image.open(OUT/(route+'.png')) as im:im.verify()
 records.append({'route':route,'physical_groups':len(signature['physical_groups']),'svg':1,'png':1,'word':len(row['word'])})
assert set(actual)=={x['route'] for x in expected['routes']}
assert {k:hashlib.sha256((ROOT/k).read_bytes()).hexdigest() for k in before}==before,'Runtime changed during replay'
report={'pass':True,'runtime_aggregate':commit['runtime_aggregate'],'routes':len(records),'SVG':sum(x['svg'] for x in records),'PNG':sum(x['png'] for x in records),'Word':sum(x['word'] for x in records),'untagged_routes_exact_to0937':sum(not x['svg']['physical_groups'] for x in expected['routes']),'untagged_shapes_exact_to0937':sum(x['svg']['untagged_shape_count'] for x in expected['routes']),'physical_geometry_groups_exact_to0937':sum(x['physical_groups'] for x in records),'scope':'One reviewed representative preset per route; exports through production APIs; not a browser download click or browser pixel capture.','records':records};(OUT/'ARTIFACT_REPLAY.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
