import sys,json,hashlib
from pathlib import Path
from dataclasses import replace
R=Path(sys.argv[1]).resolve();O=Path(sys.argv[2]).resolve();O.mkdir(parents=True,exist_ok=True);sys.path.insert(0,str(R))
from streamlit.testing.v1 import AppTest
from streamlit import dataframe_util
from lro.welded_angle_gusset import WeldedAngleGusset,evaluate,FAMILY
from lro.welded_angle_gusset_ui import PROJECT,RESULT
base=WeldedAngleGusset();peak=evaluate(base)['summary']['utilization'];rows=[]
for target in (.9999,1.0001):
 c=replace(base,N=base.N*target/peak);raw=evaluate(c)
 at=AppTest.from_file(str(R/'app.py'),default_timeout=180);at.session_state['connection_family']=FAMILY;at.session_state[PROJECT]=c.to_dict();at.run();assert not at.exception
 assert at.session_state[PROJECT]==c.to_dict() and at.session_state[RESULT]==raw
 table=at.dataframe[-1];plain=table.value;shown=dataframe_util.convert_arrow_bytes_to_pandas_df(table.proto.arrow_data.styler.display_values)
 ix=plain['Índice'].idxmax();record={'target':target,'raw_utilization':plain.loc[ix,'Índice'],'display_utilization':shown.loc[ix,'Índice'],'raw_status':plain.loc[ix,'Resultado'],'display_status':shown.loc[ix,'Resultado'],'result_status':raw['status'],'input_N':c.N,'native_preserved':True,'raw_engine_preserved':True}
 assert record['display_utilization']=='1.00'
 assert record['raw_status']==record['display_status']==('PASS' if target<1 else 'FAIL')
 rows.append(record)
(O/'REAL_THRESHOLD_PROBE.json').write_text(json.dumps({'pass':True,'records':rows},ensure_ascii=False,indent=2));print(rows)
