"""Reviewer-owned read-only per-route export and visible precision audit.
Usage: python review_artifacts.py SOURCE OUTPUT [--route route] [--skip-expanded]
No production source is written. Generated exports stay in OUTPUT.
"""
import argparse,dataclasses,hashlib,importlib,inspect,json,math,re,sys,time,traceback,zipfile
from pathlib import Path
from io import BytesIO
import xml.etree.ElementTree as ET
P=argparse.ArgumentParser();P.add_argument('source');P.add_argument('output');P.add_argument('--route',action='append');P.add_argument('--skip-expanded',action='store_true');A=P.parse_args()
SRC=Path(A.source).resolve();OUT=Path(A.output).resolve();OUT.mkdir(parents=True,exist_ok=True);sys.path.insert(0,str(SRC))
ROUTES=[('single_plate','examples','drawing','report',None),('column_web_double_cover','double_cover','double_cover_drawing','double_cover_report',None),('end_plate_pinned','end_plate','end_plate_drawing','end_plate_report','pinned'),('end_plate_moment','end_plate','end_plate_drawing','end_plate_report','moment')]
ROUTES += [(route,mod,mod+'_drawing',mod+'_report',None) for route,mod in [('base_plate_fixed','base_plate'),('base_plate_pinned','pinned_base_plate'),('w_splice_m004','w_splice'),('w_splice_conventional','w_splice_conventional'),('double_angle_r016','double_angle'),('welded_double_angle_r015','welded_double_angle'),('coped_double_angle_r017','coped_double_angle'),('axial_double_angle_bolted','axial_double_angle'),('axial_single_angle_bolted','axial_single_angle'),('welded_w_splice','welded_w_splice'),('welded_angle_gusset','welded_angle_gusset'),('welded_double_angle_gusset','welded_double_angle_gusset'),('welded_opposed_angle_gusset','welded_opposed_angle_gusset'),('bolted_angle_gusset','bolted_angle_gusset'),('corner_gusset','corner_gusset')]]
sha=lambda b:hashlib.sha256(b).hexdigest()
def hashes():return {str(p.relative_to(SRC)):sha(p.read_bytes()) for pat in ('app.py','lro/*.py','data/*.json','requirements*.txt') for p in sorted(SRC.glob(pat))}
def clean(x):
 if dataclasses.is_dataclass(x):return {f.name:clean(getattr(x,f.name)) for f in dataclasses.fields(x)}
 if isinstance(x,dict):return {str(k):clean(v) for k,v in x.items()}
 if isinstance(x,(list,tuple)):return [clean(v) for v in x]
 if isinstance(x,set):return sorted(clean(v) for v in x)
 if isinstance(x,float) and not math.isfinite(x):return str(x)
 if isinstance(x,(str,int,float,bool)) or x is None:return x
 raise TypeError(type(x))
def canonical(x):return json.dumps(clean(x),ensure_ascii=False,sort_keys=True,allow_nan=False)
# Include all apparent long decimals, then classify rather than silently whitelist.
NUMBER=re.compile(r'(?<![\w.,])[-+]?\d+[.,]\d{3,}(?:[eE][-+]?\d+)?(?![\d,]|\.\d)')
def findings(lines):
 out=[]
 for i,line in enumerate(lines):
  for m in NUMBER.finditer(line):
   token=m.group();category='review'
   if re.fullmatch(r'[-+]?\d{1,3}[.,]\d{3}',token):category='possible_thousands_or_decimal'
   if re.search(r'(?:\b0[.,]707\b|\b0[.,]875\b|\b0[.,]658\b|\b0[.,]877\b|\b0[.,]694\b|\b0[.,]010\b)',token):category='possible_normative_literal'
   if 'v0.' in line or 'v0,' in line or '0.9.' in line:category='possible_version'
   out.append({'line':i+1,'token':token,'category':category,'context':line[max(0,m.start()-100):m.end()+130]})
 return out
NS={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main','m':'http://schemas.openxmlformats.org/officeDocument/2006/math','s':'http://www.w3.org/2000/svg'}
def docx_data(data):
 lines=[];links=[];omml=0;media=[]
 with zipfile.ZipFile(BytesIO(data)) as z:
  for name in z.namelist():
   if name.startswith('word/') and name.endswith('.xml') and (name=='word/document.xml' or 'header' in name or 'footer' in name):
    root=ET.fromstring(z.read(name));omml+=len(root.findall('.//m:oMath',NS))
    for p in root.findall('.//w:p',NS):
     line=''.join(t.text or '' for t in p.iter() if t.tag in ('{'+NS['w']+'}t','{'+NS['m']+'}t'))
     if line:lines.append(line)
   if name.endswith('.rels'):
    for el in ET.fromstring(z.read(name)):
     if el.attrib.get('TargetMode')=='External':links.append(el.attrib['Target'])
   if name.startswith('word/media/'):media.append({'name':name,'sha256':sha(z.read(name))})
 return {'lines':lines,'external_links':sorted(links),'omml_equations':omml,'media':media}
def svg_data(data):
 root=ET.fromstring(data);lines=[''.join(e.itertext()) for e in root.iter() if e.tag=='{'+NS['s']+'}text']
 groups={}
 for g in root.iter():
  gid=g.attrib.get('id','')
  if gid and not re.match(r'^(?:figure_|patch_|axes_|text_|line2d_|matplotlib|p[0-9a-f]{6,}|m[0-9a-f]{6,}|h[0-9a-f]{6,})',gid) and not any(e.tag=='{'+NS['s']+'}text' for e in g.iter()):
   paths=[]
   for el in g.iter():
    if el.tag.rsplit('}',1)[-1] in ('path','line','polygon','polyline','rect','circle','ellipse'):
     paths.append({k:v for k,v in el.attrib.items() if k in ('d','x','y','x1','x2','y1','y2','cx','cy','r','rx','ry','width','height','points','transform')})
   if paths:groups[gid]=paths
 return {'lines':lines,'named_geometry':groups,'viewBox':root.attrib.get('viewBox')}
def save_export(route,kind,data):
 path=OUT/(route+'.'+kind);path.write_bytes(data)
 rec={'path':str(path),'bytes':len(data),'sha256':sha(data)}
 if kind.endswith('docx'):
  more=docx_data(data);rec.update(more);rec['long_decimals']=findings(more['lines']);(OUT/(route+'.'+kind+'.txt')).write_text('\n'.join(more['lines']))
 if kind=='svg':
  more=svg_data(data);rec.update(more);rec['long_decimals']=findings(more['lines']);(OUT/(route+'.svg.txt')).write_text('\n'.join(more['lines']))
 return rec
before=hashes();records=[]
for route,modname,drawname,reportname,kind in ROUTES:
 if A.route and route not in A.route:continue
 t=time.time();row={'route':route,'exports':{},'errors':[]};print('START',route,flush=True)
 try:
  m=importlib.import_module('lro.'+modname);presets=m.presets();label,c=next((k,v) for k,v in presets.items() if kind is None or getattr(v,'kind',None)==kind)
  evaluator=importlib.import_module('lro.engine').evaluate if modname=='examples' else (m.analyze if modname=='corner_gusset' else m.evaluate)
  r=evaluator(c);native_before=canonical(c);result_before=canonical(r)
  row.update(preset=label,native_sha256=sha(native_before.encode()),result_sha256=sha(result_before.encode()),status=getattr(r,'status',None) if not isinstance(r,dict) else r.get('status'))
  (OUT/(route+'.native.json')).write_text(native_before);(OUT/(route+'.result.json')).write_text(result_before)
  d=importlib.import_module('lro.'+drawname);im=d.image_bytes;params=inspect.signature(im).parameters;kwargs={'r':r} if 'r' in params else ({'result':r} if 'result' in params else {})
  for fmt in ('svg','png'):
   try:
    data=im(c,fmt=fmt,**kwargs);data=data.encode() if isinstance(data,str) else data;row['exports'][fmt]=save_export(route,fmt,data)
   except Exception:row['errors'].append({'surface':fmt,'error':traceback.format_exc()})
  if reportname=='pinned_base_plate_report':reportname='base_plate_report'
  report=importlib.import_module('lro.'+reportname).create_report;params=inspect.signature(report).parameters
  detail_options=[False,True] if 'detailed' in params and not A.skip_expanded else [False]
  row['expanded_offered']='detailed' in params
  for detailed in detail_options:
   name='expanded.docx' if detailed else 'concise.docx'
   try:
    data=report(c,r,**({'detailed':detailed} if 'detailed' in params else {}));row['exports'][name]=save_export(route,name,data)
   except Exception:row['errors'].append({'surface':name,'error':traceback.format_exc()})
  row['native_unchanged_by_exports']=canonical(c)==native_before;row['result_unchanged_by_exports']=canonical(r)==result_before
 except Exception:row['errors'].append({'surface':'setup','error':traceback.format_exc()})
 row['seconds']=round(time.time()-t,2);records.append(row);(OUT/'RESULTS.json').write_text(json.dumps(records,ensure_ascii=False,indent=2));print('DONE',route,'secs',row['seconds'],'exports',list(row['exports']),'errors',row['errors'],flush=True)
 try:
  import matplotlib.pyplot as plt;plt.close('all')
 except ImportError:pass
after=hashes();provenance={'source':str(SRC),'before':before,'after':after,'stable':before==after,'source_sha256_before':sha(json.dumps(before,sort_keys=True).encode()),'source_sha256_after':sha(json.dumps(after,sort_keys=True).encode()),'changed_files':[p for p in sorted(set(before)|set(after)) if before.get(p)!=after.get(p)],'claim':'Direct public export API generation; not a browser-download click test.'};provenance['APP_only_runtime_imports']={name:str(Path(m.__file__).resolve().relative_to(SRC)) for name,m in sys.modules.items() if (name=='lro' or name.startswith('lro.')) and getattr(m,'__file__',None)};(OUT/'PROVENANCE.json').write_text(json.dumps(provenance,indent=2));print('STABLE',provenance['stable'],'HASH',provenance['source_sha256_after'],flush=True)
