Portable 0.9.38 precision regression evidence

Commands (install the APP-declared dependencies first):
  python replay_precision.py /absolute/APP /absolute/output/precision --ui
  python replay_artifacts.py /absolute/APP /absolute/output/artifacts

Both commands read only the supplied APP and this shipped evidence folder and write
only OUTPUT. No0937 checkout, optional source companion, or local engine dump is
needed. PYTHONDONTWRITEBYTECODE=1 is recommended. Output must be outside an immutable
APP. Runtime files and catalogs are committed in runtime_expected.json.

Coverage:106 complete preset engine/native structures represented by canonical
SHA256 commitments to immutable0937,19 real Streamlit AppTest routes, raw numeric
Styler backing tables and separate display strings, exact imported high-precision
values across reruns and unrelated edits, real raw utilization.9999 PASS/1.0001 FAIL
both displaying1.00, and19 representative SVG+PNG+31Word exports. Word display text,
OMML counts and external reference links are committed separately from geometry.

Geometry correction: the earlier reviewer count694 named SVG objects included
71 single-plate font-glyph definitions. The portable gate correctly counts623
explicitly named physical groups, excludes SVG font defs and text, and additionally
compares all non-text shape coordinates for the four untagged routes. Exact shape
tags, coordinate strings and ancestor transforms are committed. Text/font paths
and automatic annotation leaders are presentation, not physical geometry. No
geometry tolerance or rounded-coordinate normalization is used.

Limits: one representative export preset per route is not all branches/presets.
PNG payloads must decode; visual review was performed separately on6 drawings and
20Word pages, not pixel-identical cross-platform rendering. No real browser-pixel
screenshot or browser download-click claim is made. AppTest verifies widget format
protocols and exact native state, not browser decimal-comma pixel localization.

The106 commitments prove full result/native parity with reviewed0937; they are
not independent normative oracles. Any pre-existing test missing its independent
oracle (including the external axial bolt-bearing oracle) remains a documented
limitation, not silently waived or counted as a newly passed engineering oracle.
Inherited fixture/data/docs commitments support test-slice reuse. One new narrative
doc, DISPLAY_PRECISION0938.md, is not a test fixture. Do not treat its prose hash as
runtime or mechanical authority. Aggregate test counts remain separate from this
replay's case counts.
