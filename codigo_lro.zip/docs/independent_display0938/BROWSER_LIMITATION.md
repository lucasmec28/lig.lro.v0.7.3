# Browser capture limitation

No actual screenshot acceptance is claimed. The supplied reference screenshot was directly inspected, and the exact matching route and fields were identified.

An isolated local Streamlit server was attempted, with usage statistics disabled. The execution reviewer rejected the process because Streamlit made an incidental external checkip.amazonaws.com network-metadata request that was not authorized. No workaround around that rejection was attempted. Earlier local Chromium launch attempts failed with socket() Operation not permitted; supported cloud-browser navigation to the local address returned connection refused.

Evidence is therefore bounded to real Streamlit AppTest controls/protobuf data and independent native SVG/PNG/Word rendering. Runtime format %.2f and raw widget preservation are verified, but browser-localized decimal comma pixels are not.
