"""Reviewer-owned real AppTest route coverage; no mocked engine or widget."""
import sys, json, hashlib, math, re, traceback
from pathlib import Path
from copy import deepcopy
from dataclasses import replace
R=Path(sys.argv[1]).resolve();OUT=Path(sys.argv[2]).resolve();OUT.mkdir(exist_ok=True,parents=True);sys.path.insert(0,str(R))
from streamlit.testing.v1 import AppTest
from lro.guided_selection import FAMILIES

def hashes():
 return {str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [R/'app.py',*sorted((R/'lro').glob('*.py'))]}
before=hashes(); rows=[]
for family in FAMILIES:
 item={'route':family.id,'label':family.route_select_value}
 try:
  at=AppTest.from_file(str(R/'app.py'),default_timeout=180)
  at.session_state['connection_family']=family.route_select_value
  at.run();assert not at.exception,[x.message for x in at.exception]
  item['controls']=[{'key':x.key,'label':x.label,'value':x.value,'format':x.proto.format,'data_type':x.proto.data_type} for x in at.number_input]
  item['bad_formats']=[x for x in item['controls'] if x['format'] not in ('%.2f','%.2e','%d','%i')]
  item['dataframes']=len(at.dataframe)
  item['table_values']=[x.value.to_dict(orient='records') for x in at.dataframe]
  from streamlit import dataframe_util
  item['table_display_values']=[dataframe_util.convert_arrow_bytes_to_pandas_df(x.proto.arrow_data.styler.display_values).to_dict(orient='records') if x.proto.arrow_data.styler.display_values else None for x in at.dataframe]
  item['table_numeric_columns']=[list(x.value.select_dtypes(include='number').columns) for x in at.dataframe]
  item['metrics']=[{'label':x.label,'value':x.value} for x in at.metric]
  item['visible_text']=[{'kind':kind,'value':str(x.value)} for kind in ('caption','markdown','code','text','info','warning','error','success') for x in getattr(at,kind)]
  pattern=re.compile(r'(?<![\w.,])[-+]?\d+[.,]\d{3,}(?:[eE][-+]?\d+)?(?![\d,]|\.\d)')
  item['text_decimal_matches']=[{'kind':t['kind'],'number':m.group(),'context':t['value'][max(0,m.start()-90):m.end()+110]} for t in item['visible_text'] for m in pattern.finditer(t['value'])]
  native_keys=[k for k in at.session_state._state.filtered_state if k.startswith('_') and ('project' in k or 'result' in k)]
  state={k:deepcopy(at.session_state[k]) for k in native_keys}
  at.run();assert not at.exception,[x.message for x in at.exception]
  item['native_and_results_unchanged_on_noop']=all(at.session_state[k]==v for k,v in state.items())
  item['checked_state_keys']=native_keys
  item['pass']=not item['bad_formats'] and item['native_and_results_unchanged_on_noop']
 except Exception as exc:
  item.update(pass_=False,error=repr(exc),traceback=traceback.format_exc())
 rows.append(item);(OUT/(family.id+'.json')).write_text(json.dumps(item,ensure_ascii=False,indent=2,default=str));print(family.id,item.get('pass'),item.get('error',''),flush=True)
# Screenshot route with the exact imported precision stress case.
from lro.welded_angle_gusset import WeldedAngleGusset,FAMILY,evaluate
from lro.welded_angle_gusset_ui import PROJECT,RESULT
c=replace(WeldedAngleGusset(),N=123456.78901234567,theta_deg=45.123456789,center_s=0.000123456789,center_n=150.123456789,weld_length=200.123456789,end_margin=20.123456789,angle_weld_leg=5.123456789)
at=AppTest.from_file(str(R/'app.py'),default_timeout=180);at.session_state['connection_family']=FAMILY;at.session_state[PROJECT]=c.to_dict();at.run();assert not at.exception
first=deepcopy(at.session_state[PROJECT]);assert first==c.to_dict()
controls={k:at.number_input(key='wag_'+k) for k in ('theta_deg','center_s','center_n','weld_length','end_margin','angle_weld_leg')}
probe={'controls':{k:{'raw':x.value,'format':x.proto.format} for k,x in controls.items()},'initial_native_exact':first==c.to_dict(),'initial_engine_exact':at.session_state[RESULT]==evaluate(c)}
at.run();probe['noop_native_exact']=at.session_state[PROJECT]==c.to_dict()
at.text_input(key='wag_project').set_value('Independent precision review').run();expected=replace(c,project='Independent precision review');probe['unrelated_edit_native_exact']=at.session_state[PROJECT]==expected.to_dict();probe['unrelated_engine_exact']=at.session_state[RESULT]==evaluate(expected)
at.number_input(key='wag_center_n').set_value(155.12).run();expected=replace(expected,center_n=155.12);probe['edited_only_target_native_exact']=at.session_state[PROJECT]==expected.to_dict();probe['edited_engine_exact']=at.session_state[RESULT]==evaluate(expected)
probe['pass']=all(v for k,v in probe.items() if k!='controls');(OUT/'screenshot_route_precision.json').write_text(json.dumps(probe,ensure_ascii=False,indent=2));print('screenshot precision',probe['pass'],flush=True)
summary={'source_before':before,'source_after':hashes(),'source_stable':before==hashes(),'route_count':len(rows),'all_routes_pass':all(x.get('pass') for x in rows),'screenshot_probe_pass':probe['pass']}
summary['APP_only_runtime_imports']={name:str(Path(m.__file__).resolve().relative_to(R)) for name,m in sys.modules.items() if (name=='lro' or name.startswith('lro.')) and getattr(m,'__file__',None)}
(OUT/'SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));print('DONE',summary['all_routes_pass'],summary['source_stable'],flush=True)
