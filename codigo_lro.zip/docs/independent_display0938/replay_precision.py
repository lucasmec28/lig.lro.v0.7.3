"""Portable read-only regression gate. Usage: python replay_precision.py APP_ROOT OUTPUT [--ui]
Requires the APP's declared dependencies. Writes evidence only beneath OUTPUT.
"""
import argparse,dataclasses,hashlib,importlib,json,math,os,subprocess,sys
from pathlib import Path
P=argparse.ArgumentParser();P.add_argument('app');P.add_argument('output');P.add_argument('--ui',action='store_true');A=P.parse_args()
ROOT=Path(A.app).resolve();OUT=Path(A.output).resolve();OUT.mkdir(parents=True,exist_ok=True);HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT))
def sha(x):return hashlib.sha256(x).hexdigest()
def clean(x):
 if dataclasses.is_dataclass(x):return {f.name:clean(getattr(x,f.name)) for f in dataclasses.fields(x)}
 if isinstance(x,dict):return {str(k):clean(v) for k,v in x.items()}
 if isinstance(x,(list,tuple)):return [clean(v) for v in x]
 if isinstance(x,set):return sorted(clean(v) for v in x)
 if isinstance(x,float) and not math.isfinite(x):return {'nonfinite':str(x)}
 if x is None or isinstance(x,(str,bool,int,float)):return x
 if hasattr(x,'item'):return clean(x.item())
 raise TypeError(type(x))
def digest(x):return sha(json.dumps(clean(x),ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode())
commit=json.loads((HERE/'runtime_expected.json').read_text());before={k:sha((ROOT/k).read_bytes()) for k in commit['files']};assert before==commit['files'],'Runtime commitment mismatch'
expected=json.loads((HERE/'engine_expected.json').read_text());records=[]
for row in expected['cases']:
 m=importlib.import_module('lro.'+row['module']);c=m.presets()[row['label']];fn=importlib.import_module('lro.engine').evaluate if row['module']=='examples' else (m.analyze if row['module']=='corner_gusset' else m.evaluate);r=fn(c)
 native=clean(c.to_dict() if hasattr(c,'to_dict') else c);version=native.pop('app_version',None)
 got={'module':row['module'],'label':row['label'],'result_sha256':digest(r),'native_except_top_app_version_sha256':digest(native),'expected_app_version':version};assert got==row,got;records.append(got)
banner=json.loads((HERE/'signed_banner_expected.json').read_text())
from lro.models import Connection
from lro.engine import evaluate
from lro.drawing import connection_figure,image_bytes
c=Connection.from_dict(banner['native_input']);r=evaluate(c);assert c.V==banner['input_V'] and c.N==banner['input_N'];assert c.to_dict()==banner['native_input'];assert digest(r)==banner['raw_result_sha256']
fig=connection_figure(c);geometry=[]
for ax in fig.axes:geometry.append({'limits':[list(ax.get_xlim()),list(ax.get_ylim())],'patches':[p.get_path().vertices.tolist() for p in ax.patches],'lines':[{'x':list(line.get_xdata()),'y':list(line.get_ydata())} for line in ax.lines]})
assert digest(geometry)==banner['figure_geometry_sha256'];assert banner['banner'] in image_bytes(c,'svg').decode();assert c.to_dict()==banner['native_input'] and digest(r)==banner['raw_result_sha256']
imports={name:str(Path(m.__file__).resolve().relative_to(ROOT)) for name,m in sys.modules.items() if (name=='lro' or name.startswith('lro.')) and getattr(m,'__file__',None)}
report={'pass':True,'runtime_aggregate':commit['runtime_aggregate'],'engine_native_cases':len(records),'browser_pixels_claimed':False,'custom_signed_banner_pass':True,'APP_only_runtime_imports':imports,'limitation':'Hashes establish parity with reviewed0937 results; they do not replace a missing independent normative oracle.'}
if A.ui:
 env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1';env['PYTHONPATH']=str(ROOT)+os.pathsep+env.get('PYTHONPATH','')
 for script,dest in [('replay_ui_probe.py','ui'),('replay_threshold_probe.py','threshold')]:subprocess.run([sys.executable,str(HERE/script),str(ROOT),str(OUT/dest)],env=env,check=True)
 summary=json.loads((OUT/'ui/SUMMARY.json').read_text());assert summary['route_count']==19 and summary['all_routes_pass'] and summary['source_stable'] and summary['screenshot_probe_pass']
 for row in json.loads((HERE/'ui_expected.json').read_text())['routes']:
  actual=json.loads((OUT/'ui'/f"{row['route']}.json").read_text());assert actual['label']==row['selector'];assert [{k:t[k] for k in ('key','format','data_type')} for t in actual['controls']]==row['controls'];assert actual['dataframes']==row['dataframes'];assert actual['table_numeric_columns']==row['numeric_table_columns'];assert actual['metrics']==row['metrics'];assert digest(actual['visible_text'])==row['visible_text_sha256'];assert digest(actual['table_display_values'])==row['table_display_sha256']
 report['ui_routes']=19;report['imported_precision_probe']=True;report['raw_unity_threshold_probe']=True
assert {k:sha((ROOT/k).read_bytes()) for k in before}==before,'Runtime changed during replay'
(OUT/'PRECISION_REPLAY.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
