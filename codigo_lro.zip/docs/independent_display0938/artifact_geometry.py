"""Strict physical SVG geometry and visible-label extraction.
Auto text/background/leader groups and random glyph/clip IDs are outside the
physical-group contract; every reviewed explicitly named geometry group is exact.
"""
import hashlib,json,re,xml.etree.ElementTree as ET
S='{http://www.w3.org/2000/svg}'
GEOM={'d','x','y','x1','x2','y1','y2','cx','cy','r','rx','ry','width','height','points','transform'}
SHAPES={'path','line','polygon','polyline','rect','circle','ellipse'}
def digest(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def svg_signature(path):
 root=ET.parse(path,parser=ET.XMLParser(target=ET.TreeBuilder(insert_comments=True))).getroot();groups={}
 def walk(el,parents):
  transforms=parents+([el.attrib['transform']] if 'transform' in el.attrib else [])
  if el.tag in (S+'defs',S+'metadata'):return
  gid=el.attrib.get('id','')
  if gid and not re.match(r'^(?:figure_|patch_|axes_|text_|line2d_|matplotlib|[pmh][0-9a-f]{6,})',gid) and not any(x.tag==S+'text' for x in el.iter()):
   shapes=[]
   def visit(e,chain):
    chain=chain+([e.attrib['transform']] if 'transform' in e.attrib else [])
    tag=e.tag.rsplit('}',1)[-1] if isinstance(e.tag,str) else ''
    if tag in SHAPES:shapes.append({'tag':tag,'attributes':{k:v for k,v in e.attrib.items() if k in GEOM},'ancestor_transforms':chain})
    for child in e:visit(child,chain)
   visit(el,parents)
   if shapes:groups[gid]=digest(shapes)
  for child in el:walk(child,transforms)
 walk(root,[])
 # Path-font labels survive as SVG comments; text-font labels are standard text.
 labels=[(e.text or '') if e.tag is ET.Comment else ''.join(e.itertext()) for e in root.iter() if e.tag is ET.Comment or e.tag==S+'text']
 physical=[]
 def untagged(e,parents):
  tag=e.tag.rsplit('}',1)[-1] if isinstance(e.tag,str) else ''
  if tag in ('defs','metadata','text') or e.attrib.get('id','').startswith('text_'):return
  chain=parents+([e.attrib['transform']] if 'transform' in e.attrib else [])
  if tag in SHAPES:physical.append({'tag':tag,'attributes':{k:v for k,v in e.attrib.items() if k in GEOM},'ancestor_transforms':chain})
  for child in e:untagged(child,chain)
 if not groups:untagged(root,[])
 return {'untagged_shape_count':len(physical),'untagged_shapes_sha256':digest(physical) if not groups else None,'physical_groups':groups,'visible_labels_sha256':digest(labels),'visible_label_count':len(labels),'viewBox':root.attrib.get('viewBox')}
