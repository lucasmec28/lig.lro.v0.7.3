# Novas variantes completas de cantoneiras e gusset

Versão 0.9.30-gusset-variants-dev. Desenvolvimento e aceitação local de fonte; não é aprovação da estrutura ou fabricação.

## Rotas e identidade

O seletor principal contém18 famílias, com a ordem original das16 preservada. Foram acrescentadas:

1. `welded_opposed_angle_gusset`: duas L idênticas opostas pelos vértices, `><`, contato direto, h=tg derivado. Quatro filetes longitudinais em posições projetadas distintas.
2. `bolted_angle_gusset`: configuração `1L` ou `2L-T`, uma linha de parafusos, gusset retangular perfurado, raiz dupla soldada e mesa exterior W. São duas configurações em um seletor; não se conta uma rota duas vezes.

A forma nativa de cada família tem identidade explícita, unidades N/mm/MPa/Nmm e premissas estritas. Importação rejeitada não altera projeto, rascunho, resultado ou memória aceita. Nenhum arquivo1L/T soldado anterior ou componente axial parafusado é promovido silenciosamente a uma ligação completa.

## Duas cantoneiras opostas soldadas

Use N total. Cada L e seus filetes recebem N/2; chapa única, raiz dupla e W recebem N integral. As raízes dos quatro filetes estão em v=±tg/2 e v=±(tg/2+b); cada talão recebe (1−ec/b)N/2 e cada ponta ecN/(2b). A posição z física permanece no desenho e no diagnóstico, enquanto a resistência aplica a idealização estática NBR6.1.8.2/6.5.2 por L. Binários locais superfície–plano médio não são declarados fisicamente cancelados ou aprovados como campo3D.

O centro do par v=0 define a linha resultante. Nraiz=Nsenθ, Vraiz=Ncosθ e Mraiz=N(s0senθ−n0cosθ). O solver conserva as quatro fontes e todas as transições entre trechos; extremos normais interiores são resolvidos. A chapa comum recebe caminhos U contíguos e L, recortados pelo retângulo e pelas bordas reais, com força calculada de todas as linhas capturadas, inclusive em sobreposição de footprints. Contato positivo com a raiz apoiada torna o bloco inativo; não se cria uma borda livre fictícia.

A faixa local precisa conter os quatro footprints, estar contida e respeitar espalhamento até30°. Além da faixa agregada centrada, há triagem suplementar por face em t/2, com N/2 e momento próprio ±(N/2)(tg/2+ec), usando o menor Ct adaptado com t inteiro. As espessuras alocadas somam a única chapa. Não é um modelo espacial ou uma prova de fissura exata.

Referências e fixture independentes: `qualification_gussets0930/opposed/QUALIFICATION.md`, `INPUT_DOMAIN.md`, `FINAL_RECEIPT.json`; fixture reproduzível em `../tests/fixtures/opposed_welded0930.json`. Caso120kN: índice0,375; caso330kN, mesmos corpos: falha1,03125 no envelope da chapa comum. O ramo reutiliza primitivas qualificadas de aço/solda/raiz/W, nunca aprovação global ou capacidade T.

## Ligação parafusada completa

Uma L tem um plano de corte e recebe N. No2L-T cada parafuso físico atravessa L–chapa–L, com dois planos e N/(2n) por plano/L; o furo central recebe N/n. N continua integral na chapa comum, raiz e W. Oposição pelos vértices não usa esse modelo: necessita duas linhas distintas de parafusos de corte simples e nova qualificação da chapa comum perfurada.

Há resistência bruta/líquida efetiva por L, Ct com ec real, plano de corte individual, contato direcional por furo, blocos L até bordas livres reais, Whitmore recortado, cortes líquidos força-normais e transferência até a raiz. Diâmetro físico de furo controla contato; dedução líquida segue fabricação broqueada ou acréscimo normativo. A ponta livre carregada da L e a borda carregada da chapa ficam em sentidos opostos. Não se somam capacidades de caminhos alternativos para mascarar um furo sobrecarregado.

As seções horizontais perfuradas têm resultantes discretas, áreas/centroides/inércias recomputados e limites antes/depois das forças pontuais. σ=N/A+M(s−sbar)/I e a triagem1,5|V|/A são nominais complementares. Não são campos elásticos exatos ao redor dos furos nem substituem contato, Whitmore, área líquida ou bloco. Extremos numéricos são registrados como buscas escalares, sem alegação de certificado intervalar.

O raio interno Gerdau não é publicado. O usuário informa envelope interno de talão, sua origem e envelope da ferramenta/folga; dado ausente mantém montagem pendente mesmo com resistências favoráveis. O preset12,35mm é hipótese dimensional explícita do fixture, não dado fornecido pelo catálogo ou comprovação da peça real. A interface não oferece um checkbox de aprovação para substituir a dimensão.

Referências e qualificação independentes: `qualification_gussets0930/bolted/CONTRACT.md`, `INDEPENDENT_METHOD_VERDICT.md`, `QUALIFICATION_MANIFEST.json`. Principal fixture Gerdau76,2×6,35, θ80°, N100kN: Mraiz−2,604723kNm, solda da raizη0,525594925. N200kN falhaη1,051189849;1L do mesmo conjunto conserva chapa/raiz e tem blocoLη0,827553232. A qualificação inclui variantes90°/100°, materiais e furos18/20mm.

### Refinamento identificado na revisão do motor

A revisão independente identificou que, quando uma tampa transversal de bloco corta um furo circular, a dedução líquida varia com a corda do círculo. Só avaliar centro, tangentes e cantos do retângulo não captura necessariamente a menor resistência dentro do intervalo. O motor acrescenta pontos estacionários analíticos de ambos os ramos de resistência, incluindo a faixa inferior do primeiro furo, e mantém explicitamente os limites de força com e sem o parafuso cortado. A raiz apoiada continua excluída como borda livre.

Reprodução: cinco parafusos, passo43,2mm, H270mm e N45kN. A segunda tampa esquerda tem resistência421657,962910N no centro u=−43,2mm; o extremo interior em u≈−44,762834mm reduz para421400,852712N. Este mínimo é geométrico, não um fator inventado ou uma alteração global do caminho de carga.

Os witnesses centrais originais dos fixtures de qualificação são conservados como seus oráculos exatos. O envelope ampliado da chapa do exemplo principal passa de0,211126905388 para0,212268705525, sem alterar a solda de raiz governante0,525594924539 nem converter o fixture antigo em outro oráculo. A correção e a regressão adversarial constam da aceitação independente final do motor. Grip que reduz a resistência a zero é recusado antes da aritmética resistente.

## Continuidade comum e limites

As duas rotas mantêm materiais independentes de L/chapa/W e consumíveis, cinquenta identidades Gerdau qualificadas e seção Arcelor legada. Ações reais zero permanecem zero; mínimo45kN e recomendação50% são casos separados, aplicados uma vez à conexão/par antes da divisão. V/M/T externos, compressão, fadiga, sismo, partilha desigual e geometrias não qualificadas não são transformados em tração aprovada.

Raiz dupla longitudinal na mesa exterior W, centrada na alma. M real determina qn=Nraiz/B±6Mraiz/B²; qs=Vraiz/B. Solda usa max(pico,1,25média), suplemento explicitado DG29, com fatores NBR; metal base conserva tensões normais/cisalhantes. Mesa usa qpeak/(2tf), sem fator de média reservado à solda. Preservam-se flexão local ou dispensa geométrica, alma local tracionada, cisalhamento longitudinal, interação local e efeitos das duas extremidades W.

Exportam-se ações na face e Mcentroide=Mraiz−dWVraiz/2. O salto de cortante transversal do membro é Nraiz; Vraiz é o esforço longitudinal da interface. Ações preexistentes do W não são assumidas nulas. Sem qualificação global, placa de canto com duas interfaces, apoio direto na alma ou liberação de fabricação.

## Proveniência e aceitação

Fixtures novos são cálculos derivados das fontes fornecidas e revistos independentemente. Não recuperam o antigo arquivo externo ausente de contato de parafusos. Todos os817 arquivos congelados de0.9.29 são verificados intactos; motores físicos preexistentes são byte-idênticos, exceto identificação global de versão em `models.py`. Alterações em módulos antigos de apresentação limitam-se ao encaminhamento/legenda e à correção do aviso de que a família oposta ainda seria futura.

`VALIDATION0930.json` é o registro de testes deduplicados e de aceitação independente da fonte. Reruns não são somados; contagens de assertivas do revisor ficam separadas dos casos pytest. Extração e smoke de um pacote final pertencem ao gate de empacotamento, não a este gate de fonte.
