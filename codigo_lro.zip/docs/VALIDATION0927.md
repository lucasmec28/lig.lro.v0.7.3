# Validação 0.9.27-gerdau-angles-dev

Integração concluída para revisão técnica. Sem upload, push, deploy ou aprovação de fabricação. A contagem abaixo não soma novamente as suítes sobrepostas.

## Resultado deduplicado: seis famílias alteradas

A coleta final contém **1.235 casos de teste distintos**: **1.234 passaram e1 falhou por arquivo de referência externo ausente**. O teste com falha é test_axial_double_angle.py::test_bolt_bearing_oracle_file_and_opposite_loaded_free_ends: não foi encontrado next_connection_scope/bolt_bearing_oracle.json. A mesma falha foi reproduzida no código0.9.26; não é apresentada como aprovação nem como teste numérico executado. O arquivo ausente não foi inventado ou reconstruído pelo motor.

Composição verificável:

- Agregado das seis famílias:1.232 passaram e1 falhou, em887,43s.
- Dois novos casos de rodapé axial, acrescentados após a coleta do agregado:2 passaram; são os únicos casos acrescentados à contagem acima.
- Após a última correção do importador legado: todos os237 testes da família1L soldada passaram. São uma repetição qualificada de casos já contados, não mais237 casos distintos.
- Rechecagem final dos seletores e artefatos axiais:315 passaram; também se sobrepõem à contagem deduplicada.
- A suíte histórica integral do aplicativo foi interrompida antes de terminar e não é declarada aprovada. O agregado concluído cobre todas as seis famílias alteradas.
- Compilação de app.py e lro/: passou.

O ambiente final usa os pacotes instalados antes de acrescentar a pasta de dependências existente. Não houve instalação nova para criar um resultado artificialmente favorável.

## Conteúdo coberto

- Catálogo: transcrição byte a byte,52 linhas originais/50 operacionais, medidas e conversões exatas, raios desconhecidos explícitos, identidade ArcelorMittal separada e critério da linha46 sem aviso operacional.
- Motor Gerdau: todas as50 seções; frações calcanhar/ponta, ponto de força, momento, pegada, Ct/Ag, largura local, caminhos, espessura de material e meia capacidade. Cantoneira pequena com falha real, seção grande, diferentes aços e limite6,35mm ordinário/reforçado/superior a t.
- Compatibilidade: esquemas completos originais e atuais, sem migração para tamanho aproximado; o importador0.9.26 rejeita o esquema híbrido que acrescente o novo campo de borda.
- UI: carregamentos50×5 nas outras famílias, filtro≥63,5mm e tamanhos menores de uso eventual, projeto menor importado preservado, restauração manual, navegação, material independente, bloqueio de identidade adulterada, invalidação de saídas antigas e fonte de raio independente.
- Desenhos/Word: dimensão, fabricante, identidade, fonte, aço e modelo efetivos. Raios Gerdau não são desenhados como conhecidos. Instrução de borda reforçada consta no desenho, Word e interface.

## Revisões independentes

- Fonte e conversões:624 valores e12 pontos da página renderizada conferidos.
- Adaptador:50 seções/1.640 comparações passaram.
- Fixtures nominais derivadas separadamente:10 casos/290 verificações passaram.
- Paridade0.9.26:29 cenários/39.767 valores numéricos preservados. Metadados novos são adicionais; entradas antigas não mudam.
- Os três verificadores de cálculo foram reproduzidos após a correção final do importador; todos passaram no kernel final.
- Comparador R017 existente:7.645 asserções, zero falhas; referência congelada preservada.
- Aceitação das seis rotas nativas:29 grupos passaram.
- Saídas reais:49 downloads, incluindo JSON, SVG, PNG e Word. Cinco famílias anteriores passaram5/5 grupos; gusset, após correção final do importador, passou13/13 grupos. O arquivo0.9.26 híbrido é rejeitado atomicamente, preservando projeto, resultado e Word já aceitos.
- Renderização:13 documentos Word/197 páginas dentro dos limites de página; exemplo comum gusset compacto8páginas/detalhado17 e páginas alteradas de desenho/proveniência inspecionados visualmente. Isto não significa que cada uma das197 páginas recebeu a mesma inspeção visual detalhada.

## Limites do produto

Um perfil selecionável não implica aprovação do detalhe: resistência, contenção, compressão interna, soldas, produto/espessura de material e topologia continuam sendo verificados. R015/R016/R017 conservam seus domínios e pendências anteriores; dados Gerdau não são arredondados para corresponder às combinações antigas.

Kernel final: ef753dbaaa0314e08746f206779e479c37af2a8f303f122e1baacf9c2d3111fa. Catálogo transcrito: b412b9af03a073110627dfb055cde103cd86f9d2c699db122a45e1a2605c1a60. Método e referências: GERDAU_ANGLES0927_METHOD.md. O pacote de distribuição deve gerar seu manifesto final após a separação dos exemplos opcionais; o código-fonte e as provas são preservados.
