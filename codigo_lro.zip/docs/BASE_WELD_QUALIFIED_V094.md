# Solda pilar–placa por duas mesas normais e alma ao corte

Incremento0.9.4 de componente, nas bases Tipo1 e Tipo2. Não encerra a placa, a fundação, a ancoragem nem a classificação de rigidez da base.

## Domínio finito

Pilar W/I duplamente simétrico, centrado, placa sem enrijecedores, ações estáticas de cálculo N/M forte/V paralelo à alma. N>0 comprime. Entradas na face superior da placa. Não há momento fraco, torção, fadiga, sismo ou redistribuição geral elástica pelo perímetro. Tipo2 continua sem momento aplicado: M=0. O antigo modelo automático `type2_uplift_web_strips` não muda.

O modelo `two_flange_normal_web_shear` prescreve toda força normal e todo momento nas duas mesas; todo V vai à alma. A mesma junta e os mesmos comprimentos são usados nas duas mesas. Alma e mesas têm escolhas independentes entre filete e CJP, com entradas de perna ou garganta para filetes. Não se admite mistura de juntas esquerda/direita nesta primeira interface.

## Fonte e extensão declarada

AISC DG1,3ª ed., Ex4.7-9, pp109–115 mostra uma rota prática com dois filetes externos de mesa, F=M/d e comprimento bf, em uma geometria específica. Não exige FEA nem demonstra que toda placa flexível comporte a mesma largura. Ex4.7-5, pp90–91 atribui V/2 a cada face da alma e verifica ruptura da alma ao corte. §§4.3.2 e4.3.5–4.3.10 sustentam caminhos de componentes qualificados e distinguem contato preparado de compressão pelas soldas.

A extensão assinada por estática é FL=(−M−N xR)/h e FR=(M+N xL)/h, h=xR−xL. F positivo traciona o pilar; F negativo permanece como demanda comprimida. Para filetes externos x=±d/2. Para CJP x=±(d−tf)/2. A escolha CJP muda o braço; não herda M/d. A estática é extensão explicitamente identificada e não é apresentada como fórmula publicada de exemplo N/M/V.

As trações uniformes no trecho efetivo integram FL+FR=−N, xL FL+xR FR=M e V. Duas soldas de alma carregam V/2 por face; uma CJP carrega V em seção única. Forças de chumbadores não substituem forças de mesas. M informado não recebe V·eV da chave inferior no componente superior.

## Dados e qualificação

Comprimentos físico e efetivo são separados, contínuos, retos e centrados. Leff≤Lreal; mesas contidas em bf e B; alma contida em clear. Não se usam l0 de placa, porcentagem automática do perímetro, fator0.85 de Souza ou regra g<bf para inventar eficácia. Comprimentos físicos, espaço nominal para filete, dimensões e materiais são verificados; detalhe técnico deve tratar concordâncias, furos, arruelas, acesso e preparação.

A memória identifica método (exemplo aplicável, transferência unidirecional ou modelo de placa), referência e revisão, justificativa de alocação N/M/V, comprimentos efetivos e execução. A assinatura liga essa documentação às ações, geometria, materiais e juntas atuais. Não verifica seu conteúdo e não converte mera marcação de caixa em qualificação. Mudanças físicas, de ações, materiais ou evidência invalidam o vínculo; UI exige novo vínculo explícito, mesmo após voltar aos valores antigos. A troca equivalente perna/garganta conserva a perna física (12 algarismos significativos para remover ruído numérico de √2); dimensões de filetes ocultas em CJP e rascunhos de dispositivos inativos não invalidam a qualificação. Áreas/dados de contato solicitado e dimensões reais das arruelas permanecem vinculados.

Sem vínculo ou execução completa, a aritmética possível permanece visível: `numerical_status` descreve pass/fail dos componentes computados e `qualification_status` descreve a validade documental. Falha resistente conhecida prevalece mesmo que haja qualificação pendente. Nenhum padrão inicia qualificado.

## Resistências atuais e detalhamento

NBR8800:2024 corrigida2025, Tabelas8/9/11 e§§6.2/6.5:

- Filetes E7018 com a=z/√2 e qRd=0.6·485·a/1.35 N/mm. Não há ganho direcional AISC.
- Mínimos de perna da Tabela11 usam a peça menos espessa e a execução em passe único. Leff≥max(40mm,4z). Não se inventa limite genérico de borda livre em juntaT.
- Filetes longitudinais da alma: limita-se conservadoramente Ld=min(Leff,βLreal); β=min(1,max(0.6,1.2−0.002Lreal/z)), ou Ld≤180z para Lreal>300z. Ld limita resistência, não altera a geometria qualificada nem a integral física V. O campo real usa V/(2Leff); a demanda equivalente de resistência usa |V|/(2Ld).
- CJP: uma seção com Leff·min(tcol,tp), normal min(fy)/1.10 e cisalhamento0.6min(fy)/1.10. Procedimento, penetração, cobre-junta, inspeção e Charpy aplicáveis são explícitos. Uma CJP não vale duas faces.
- Metal-base do pilar: cada mesa usa Leff tf uma vez para escoamento local em tração/compressão, e ruptura se tracionada; alma usa Leff tw uma vez para escoamento/ruptura ao corte. Não usa Ld de redução do filete como área da alma. Seção íntegra local não significa estabilidade do membro ou validação de recortes/furos.
- Materiais do pilar e placa são independentes e respeitam produto/espessura compatíveis com a rota E7018 implementada.

A escolha simples `smaw_e7018` não declara filete de passe único; a execução mista declara filetes de passe único e CJP qualificada. A execução não fica resolvida apenas selecionando CJP.

## Contato preparado opcional

Modo padrão: as soldas recebem também toda compressão atribuída. Opção de contato somente para N>0 e M=0, com área efetiva real Acont, registro de preparação/contato e qualificação atual. NBR6.6.2: Rd=1.8Acont·min(fy)/1.35. Acont não pode superar a seção geométrica real; a área da placa não substitui a área de contato. Requisitos de preparo seguem12.2.1.6/.8, sem exigir que toda placa seja fresada.

Somente contato qualificado e resistente zera as forças normais das soldas; o registro mantém a resultante de contato −N no equilíbrio. Se ausente, insuficiente, não físico ou fora do domínio, a compressão permanece nas soldas e a condição solicitada é pendente/falha. Não se soma arbitrariamente contato e soldas. V sempre continua nas soldas da alma; mínimos de detalhamento permanecem.

## Limites da placa e resultados

Os cálculos não inventam resistência de placa a partir de F/(Leff tp) normal. Fusão/ruptura local na placa, flexão–cisalhamento, caminho aos chumbadores/contato e compatibilidade com o dimensionamento global da placa têm seu escopo declarado. Não há formulário obrigatório de três resistências externas substituindo o cálculo de solda. O componente pode atender no escopo documentado, enquanto a base permanece a complementar.

JSON guarda entradas e vínculo; Word apresenta as ações, forças com sinais, resíduos calculados, comprimentos físico/efetivo/de resistência, materiais, requisitos, referências e estado atual. Desenho diferencia filetes externos e planos CJP, em planta coerente com x paralelo à alma; inclui auditoria com força no pilar. Exportação rejeita objeto de resultados de outra assinatura em vez de misturar dados atuais com números antigos.

## Regressões de fonte

Fixture independente em `tests/fixtures/base_weld_practical_independent.json`:

- DG1 Ex4.7-9: Fmesa65.934065934kip contra força da linha de chumbadores46.953170398kip, diferentes pelos braços físicos.
- Mesma solda1/4in×11in, E7018/NBR: F293289.337N; Rd270423.450N; η1.084555858, reprova. Não herda a aprovação AISC.
- N40kip,M1200kipin,V25kip: filetes FL−85.934065934kip,FR45.934065934kip; CJP com h17.52in dá FL−88.493150685kip,FR48.493150685kip.
- Reversão de M troca forças; reversão de V preserva a resistência e troca a tração tangencial; alta compressão mantém as duas forças negativas; alto arrancamento mantém as duas positivas.

Testes de componente cobrem alternativas fillet/CJP, materiais, limites de comprimento, perna/garganta, força positiva/negativa, contato, JSON, vínculo obsoleto, e os casos anteriores de tração pura Tipo2.

## Distinção da regra de detalhe de Fakury

Fakury, Dimensionamento de elementos estruturais de aço e mistos de aço e concreto, §11.10 (parte5 PDF19), remete a§10.12.8 e ao detalhe com filetes dos dois lados de cada mesa e alma, perna mínima5t/7. Esse perímetro não é o par de filetes exteriores implementado aqui. A recomendação de CJP quando a perna supera12mm não proíbe automaticamente filetes maiores nem é prova de resistência.

Mesmo na idealização de dois filetes: t=7mm, z=5mm, L=100mm por lado, fw=485MPa, fy=350MPa dão Rd,solda=152420.795N pela rota escalar atual e Rd,escoamento=222727.273N. Uma força200kN reprova a solda, η=1.312156914. Logo o atalho5t/7 não substitui as resistências explícitas deste motor nem dispensa a qualificação de transferência da placa. Não se importa implicitamente um aumento direcional1.5 para fazer o atalho atender.
