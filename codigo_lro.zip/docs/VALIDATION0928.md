# Validação 0.9.28-welded-double-angle-gusset-dev

Gate de aceitação do fonte escopado concluído. Sem upload, push, deploy, aprovação da estrutura ou liberação de fabricação. O fonte 0.9.27 original permanece íntegro; todo o incremento foi feito em cópia isolada.

## Contagem final deduplicada: 519 testes distintos aprovados

- Nova família 2L-T: 114 testes de motor, 32 de UI e 28 de artefatos, total 174.
- Regressão completa da família 1L-gusset existente: 237.
- Navegação guiada e conservação dos projetos nativos: 108.
- Total: 519 nodeids distintos. Não é a suíte histórica integral do aplicativo.

A execução agregada inicial coletou 513 testes: 509 passaram e quatro falharam em uma expectativa antiga do teste de navegação end-plate. A mesma falha foi reproduzida nos quatro casos sobre o fonte 0.9.27, sem alteração de produção: a partir da 0.9.24, o serializador nativo omite deliberadamente pb fora da variante 8ES, mas o teste ainda comparava todos os campos internos da dataclass. A expectativa foi corrigida somente no teste, verificando o conjunto exato de chaves do esquema ativo e todos os seus valores, com a tolerância de força anterior. Os quatro casos corrigidos passaram. Nenhum código de end-plate foi alterado.

Seis novos testes de geometria Gerdau foram acrescentados ao arquivo de artefatos após a coleta inicial. Os 28 testes finais desse arquivo passaram. A composição final é 509 + 4 corrigidos + 6 novos = 519. A coleta final confirma exatamente esses 519 nodeids.

Reruns sobrepostos não são somados: 114 testes do motor foram repetidos após corrigir apenas a redação da nota N/2 de Gerdau; os 28 de artefatos foram repetidos após as últimas correções de cabeçalhos e nota; os 32 de UI também passaram em uma execução dedicada. A compilação final de app.py e lro/ passou.

Outra manutenção de teste: o cenário temporário de instalação incompleta do guia passou a incluir o arquivo autêntico data/gerdau_equal_angles.json já exigido desde a 0.9.27, para isolar a ausência do módulo de navegação. Nenhum catálogo sintético foi usado. As listas/contagens de rotas foram atualizadas para a 16ª família, preservando a ordem das quinze anteriores.

## Aceitação numérica independente

35 grupos externos passaram no kernel final 825caaf75bdf04ba63b0b2e96b8986de622dd44ec9e651f0b7f1f23a7f1c4428. A revisão cobre os três novos fixtures independentes em revisão 2, cada governador de caminhos, equilíbrio 3D das quatro soldas, N/2 versus força total nos componentes comuns, mínimo 45 kN único, recomendação baseada na capacidade do par, θ90°/135°, independência dos aços/consumíveis, ambos os extremos W e rejeição explícita de entradas fora do escopo.

Casos decisivos:

- Arcelor 100 kN total: atende localmente; faixa comum η=0,539733333.
- Arcelor 200 kN total: os filetes das L e da raiz atendem; a chapa comum falha por escoamento η=1,079466667 e ruptura adaptada η=1,008461538.
- Gerdau R25 63,5×6,35, filete 5 mm: detalhe ordinário reprovado; detalhe reforçado explícito atende ao exemplo de 100 kN, η=0,451146667.
- Contato da raiz em chapa de 8 mm com dois filetes de 5 mm usa uma profundidade de 8 mm, não 10 ou 16 mm.
- Com Mraiz=0, a solda usa 1,25 qmédia quando governante, mas a punção da mesa conserva qpico.

A nota nominal Gerdau agora declara “demanda integral da cantoneira desta face (N/2 do par)”. A correção foi exclusivamente textual. O revisor confirmou todos os campos numéricos inalterados e repetiu os 35 grupos no hash final.

Os cinco arquivos de execução 1L-gusset permanecem byte a byte idênticos. O revisor comparou 16 cenários completos 1L em processos separados com resultados idênticos e confirmou a integridade dos 774 arquivos não transitórios do fonte 0.9.27 original. Entre os arquivos de execução preexistentes da nova cópia, somente app.py, a versão global em models.py e o catálogo de navegação foram alterados.

## UI, arquivos nativos, desenho e Word

Revisão independente do app.py real por Streamlit AppTest, com bytes reais enviados ao importador e downloads reais capturados da aplicação, sem substituir os cálculos ou callbacks: 17 grupos passaram e 29 arquivos distintos foram capturados. O mecanismo de teste não é apresentado como inspeção de pixels de um navegador.

Foram verificados rota direta/guiada, isolamento e restauração 1L/2L, importação efetiva do JSON, recusa atômica de esquema adulterado/1L, entradas que invalidam saídas anteriores, formatos atuais, casos de falha e zero real/mínimo, θ135°, Gerdau ordinário/reforçado, nomenclatura e resultados atuais. Dois Word Gerdau foram recapturados após a correção da nota, substituindo as versões anteriores sem inflar a contagem de arquivos distintos.

Cinco Word efetivamente baixados receberam renderização e aceitação visual independente: 76 páginas, correspondendo a 58 imagens de página únicas; páginas byte a byte idênticas compartilham a inspeção. A página 12 detalhada Gerdau corrigida foi reinspecionada. Auditoria de texto e limites de página também passou. O revisor examinou os PNG e renderizações SVG de casos passantes, falhos, obtusos e de força real zero.

Os exemplos pré-gerados incluem sete JSON nativos, quatro SVG, quatro PNG e seis Word. Os seis Word renderizam 99 páginas: três compactos de 10 páginas e três detalhados de 23. A revisão do autor incluiu todas as páginas AM100, todas as 23 páginas AM200 detalhado e a página Gerdau corrigida; a revisão independente de 76 páginas é a cobertura distinta descrita acima, sem alegação de uma segunda inspeção independente de todas as 99.

## Escopo e limites restantes

Somente T simétrico soldado, duas L idênticas com talões alinhados, uma chapa retangular comum, quatro filetes longitudinais acessíveis e raiz dupla na mesa exterior W longitudinal e centrada na alma, sob tração estática em combinação normal. Não qualifica compressão, vértices opostos, parafusos, assimetria, estabilidade global, fabricação ou publicação. A área e o shear lag individuais são preservados; a chapa e a raiz não têm capacidade duplicada.

O teste histórico test_axial_double_angle.py::test_bolt_bearing_oracle_file_and_opposite_loaded_free_ends depende de next_connection_scope/bolt_bearing_oracle.json, ausente antes deste incremento. Sua falha já havia sido reproduzida em 0.9.26 e documentada em 0.9.27. Ele não pertence ao agregado 0.9.28, não foi reexecutado e sua referência não foi reconstruída a partir do motor. O presente gate não o apresenta como aprovado.

Não foi executada a suíte histórica integral. Os pacotes instalados tiveram prioridade, acrescentando-se ao fim do caminho a pasta de dependências já existente para pytest/Streamlit; não houve instalação nova. A verificação do ZIP final é uma etapa separada de empacotamento sobre o fonte congelado, sem alterar os cálculos ou este escopo de aceitação.

Método: WELDED_DOUBLE_ANGLE_GUSSET0928_METHOD.md. Exemplos e resultados: WELDED_DOUBLE_ANGLE_GUSSET0928_EXAMPLES.json. Gate legível pelo construtor de distribuição: VALIDATION0928.json. Os hashes desse gate se restringem a arquivos operacionais; os exemplos binários opcionais não são dependências de execução e podem ser entregues separadamente.
