# Validação da fonte 0.9.36

GO do ramo local delimitado, com uma indisponibilidade histórica explicitamente preservada. A suíte integral executou **5.362 casos distintos: 5.361 aprovados, 1 falha, 0 erros, 0 pulados**, sobre os mesmos bytes finais de runtime e testes nos quatro grupos disjuntos. A única falha é o teste herdado que depende do arquivo externo original `next_connection_scope/bolt_bearing_oracle.json`, ainda ausente. Ele não é contado como aprovado nem substituído por oráculo inventado.

As 86 verificações novas de motor e 6 novas de UI fazem parte dos5.362. Os608 testes afetados focados também se sobrepõem à suíte; não se somam. O JUnit, o livro de nós, o manifesto antes/depois e logs brutos estão em `validation0936/aggregate/`.

A revisão independente de motor aprovou287 testes e22 casos de paridade, com148.262 comparações. A revisão de saídas aprovou13 cenários,6 grupos de callbacks,347 rejeições nativas,27 mutações de identidade física,12 rejeições atômicas de upload,12 paridades completas do canto,4 estados de parafusos longos,7 provas de mutação do SVG e74 páginas Word. São unidades distintas, não uma contagem adicional de testes da suíte.

O replay portátil de motor executa286 testes de implementação e os22 casos de paridade. O teste287 original verifica1.740 arquivos do0.9.35 e depende da fonte anterior: seu recibo é preservado e verificado, sem afirmar que a fonte ausente foi reexecutada no pacote. Todos os1.457 arquivos entregáveis da fonte congelada0.9.35 foram conferidos novamente e permanecem intactos.

BCC1 permanece NÃO ATENDE no receptor comum,η1,010114594. U interno selecionado836,842473kN usa cap de tração zero; cap completo é diagnóstico. O resultado local não certifica membro global, costuras intermediárias, fabricação ou execução da protensão.

Falhas exploratórias, o primeiro rodapé1L sobreposto e capturas realizadas durante edição foram retidos e identificados como superados; não foram apagados nem recontados como aprovação. A evidência portátil preserva o replaySVG corrigido e a proveniência histórica. Os grandes renders permanecem no local de auditoria registrado, fora do runtime.

Esta é a qualificação da fonte. PacoteAPP extraído, replayAPP-only, tamanho, upload e entrega exigem seus gates próprios. Não houve push, publicação ou deploy.
