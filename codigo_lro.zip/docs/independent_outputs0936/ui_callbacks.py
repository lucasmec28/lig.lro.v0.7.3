"""Independent finite main-app callbacks and bolted native acceptance.

AppTest executes genuine Streamlit callbacks and upload state. It does not claim
browser DOM clicks, an operating-system file dialog or clipboard interaction.
"""
from pathlib import Path
from dataclasses import replace
from copy import deepcopy
import sys,json,hashlib,os,traceback

source=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();out.mkdir(parents=True,exist_ok=True)
here=Path(__file__).resolve().parent;sys.path.insert(0,str(source))
from streamlit.testing.v1 import AppTest
entry=source
if (entry/"codigo_lro.zip").exists():
 boot=AppTest.from_file(str(entry/"app.py"),default_timeout=300).run();assert not boot.exception
 source=Path(sys.modules["lro"].__file__).resolve().parent.parent
from lro.corner_gusset import CornerGusset as C,FAMILY,analyze
from lro.corner_compression import RESTRAINT_FIELDS,geometry_stamp
from lro.corner_gusset_ui import PROJECT,RESULT,REPORT,TEMPLATE,ACCEPTED,DRAFT,_key,decode_project

base=decode_project((here/'inputs/BCC1_compact.json').read_bytes())
FRICTION_FIELDS=('bolt_friction_type','bolt_surface_class','bolt_installation_source',
 'bolt_hardened_washer_count','bolt_washer_location','bolt_washer_diameter',
 'bolt_angle_continuation','bolt_continuation_source','combination_type')
ENUMS={'bolt_surface_class':('unknown','A','B'),'bolt_washer_location':('none','rotating','both'),
 'combination_type':('unknown','normal_ultimate','special_ultimate','exceptional_ultimate')}
records=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def hashes():return {str(p.relative_to(source)):sha(p) for pattern in ('app.py','lro/*.py','data/*.json','requirements*.txt') for p in source.glob(pattern)}
before=hashes()
def fresh(c=base):
 at=AppTest.from_file(str(entry/'app.py'),default_timeout=300)
 at.session_state['connection_family']=FAMILY;at.session_state[PROJECT]=c.to_dict();at.run()
 assert not at.exception,[x.message for x in at.exception]
 return at
def button(at,label):return next(x for x in at.button if x.label==label)
def snap(at):return {k:deepcopy(at.session_state[k]) for k in (PROJECT,RESULT,REPORT,TEMPLATE,ACCEPTED,DRAFT) if k in at.session_state}
def native(at):return C.from_dict(at.session_state[PROJECT])
def upload(at,payload):
 data=payload if isinstance(payload,bytes) else json.dumps(payload).encode()
 at.get('file_uploader')[0].upload('independent0936.json',data,'application/json').run()
 button(at,'Carregar projeto de canto').click().run();assert not at.exception
def record(name,fn):
 if os.environ.get('ONLY') and os.environ['ONLY'] not in name:return
 print('RUN',name,flush=True)
 try:detail=fn();records.append({'name':name,'pass':True,'detail':detail});print('PASS',name,flush=True)
 except Exception as exc:traceback.print_exc();records.append({'name':name,'pass':False,'error':repr(exc)});print('FAIL',name,repr(exc),flush=True)
 (out/'CALLBACK_RECEIPT.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')

def decoder():
 native=base.to_dict();tested=[]
 for field,value in native['connection'].items():
  variations=[]
  if type(value) in (int,float):variations=[('bool',True),('nan',float('nan')),('inf',float('inf')),('negative_inf',-float('inf')),('numeric_text','1')]
  elif field in RESTRAINT_FIELDS+FRICTION_FIELDS:variations=[('type_int',1),('type_bool',True)] if type(value) is str else [('type_int',1),('type_text','true')]
  if field in ('bolt_count','bolt_hardened_washer_count'):variations.append(('fraction',1.25))
  if field in ENUMS or field in RESTRAINT_FIELDS[:3]:variations.append(('unsupported_enum','approved'))
  for label,value in variations:
   bad=deepcopy(native);bad['connection'][field]=value
   try:decode_project(json.dumps(bad));raise AssertionError('Accepted '+field+':'+label)
   except (TypeError,ValueError):pass
   tested.append(field+':'+label)
 for field in RESTRAINT_FIELDS+FRICTION_FIELDS:
  bad=deepcopy(native);bad['connection'].pop(field)
  try:decode_project(json.dumps(bad));raise AssertionError('Missing required '+field+' accepted')
  except (TypeError,ValueError):pass
  tested.append(field+':missing')
 for label,mutate in [('unknown',lambda b:b['connection'].update(compression_approved=True)),('units',lambda b:b['units'].update(force='kN')),('fixed',lambda b:b['fixed_assumptions'].update(gusset_count=2))]:
  bad=deepcopy(native);mutate(bad)
  try:decode_project(json.dumps(bad));raise AssertionError(label+' accepted')
  except (TypeError,ValueError):pass
  tested.append(label)
 return {'rejections':len(tested),'tested':tested,'valid_exact_roundtrip':decode_project(json.dumps(native))==base}
record('strict native finite fields enums counts and required groups',decoder)

def binding():
 stamp=geometry_stamp(base);assert base.compression_geometry_stamp==stamp
 variations={'bolt_start':386.,'bolt_pitch':61.,'bolt_count':5,'bolt_gauge':41.,
 'bolt_diameter':19.05,'bolt_drilled':False,'bolt_angle_end':36.,'bolt_tool_radius':19.,
 'bolt_fabrication_clearance':3.,'bolt_heel_extent':14.,'bolt_washer_stack':5.,
 'bolt_pretensioned':False,'bolt_friction_type':False,'bolt_surface_class':'A',
 'bolt_hardened_washer_count':2,'bolt_washer_location':'both','bolt_washer_diameter':33.,
 'bolt_angle_continuation':59.,'bolt_continuation_source':'Changed actual continuation detail',
 'bolt_installation_source':'Changed clamp installation detail','corner_clip':31.,
 'root_weld_leg':7.,'beam_seam_start_margin':11.,'column_seam_start_margin':11.,
 'plate_t':13.,'phi_deg':44.9,'compression_detail_source':'Changed physical restraint detail'}
 changed=[]
 for field,value in variations.items():
  c=replace(base,**{field:value});assert geometry_stamp(c)!=stamp,('Stamp ignored physical mutation',field)
  assert c.compression_geometry_stamp==stamp
  changed.append(field)
 retained=[]
 for field,value in {'P':-20000.,'project':'New project label','case_id':'Other load case',
  'gusset_steel':'ASTM A572 Gr.50','combination_type':'special_ultimate','lateral_restraint':False}.items():
  c=replace(base,**{field:value});assert geometry_stamp(c)==stamp,('Nonphysical mutation erased detail',field);retained.append(field)
 return {'physical_mutations_invalidate':changed,'nonphysical_identity_preserved':retained}
record('bolt hole contact hardware and roots geometry identity',binding)

def sign_controls():
 legacy=replace(C(),topology='symmetric_2L_T_bolted',plate_width=300.,plate_height=300.,bolt_heel_extent=13.94,bolt_heel_extent_source='Legacy assumed heel geometry')
 at=fresh(legacy);assert len(at.selectbox(key='connection_family').options)==19
 def keys():return {x.key for kind in ('number_input','text_input','selectbox','checkbox','radio') for x in getattr(at,kind)}
 for n in RESTRAINT_FIELDS+FRICTION_FIELDS:assert _key(n) not in keys(),('Unnecessary positive legacy control',n)
 at.number_input(key=_key('P')).set_value(-100.).run();assert not at.exception
 k=keys()
 for n in RESTRAINT_FIELDS[:4]+FRICTION_FIELDS:assert _key(n) in k,('Missing negative physical input',n)
 assert native(at).P==-100000. and not at.session_state[RESULT]['complete']
 assert not any('global' in key.lower() for key in k if isinstance(key,str))
 upload(at,base.to_dict());assert native(at)==base
 button(at,'Gerar memória de canto').click().run();assert REPORT in at.session_state
 at.number_input(key=_key('P')).set_value(100.).run();assert not at.exception
 assert native(at).bolt_friction_type and at.session_state[RESULT]['service_slip']['required']
 assert REPORT not in at.session_state
 for n in FRICTION_FIELDS:
  if n not in ('bolt_angle_continuation','bolt_continuation_source'):assert _key(n) in keys(),('Lost retained positive friction control',n)
 for value in (0.,-20.,-100.):
  at.number_input(key=_key('P')).set_value(value).run();assert not at.exception
  assert native(at).P==1000*value and native(at).compression_geometry_stamp==base.compression_geometry_stamp
  assert all(getattr(native(at),f)==getattr(base,f) for f in FRICTION_FIELDS)
 saved=deepcopy(at.session_state[PROJECT]);family=next(x for x in at.selectbox(key='connection_family').options if x!=FAMILY)
 at.selectbox(key='connection_family').set_value(family).run();assert not at.exception
 at.selectbox(key='connection_family').set_value(FAMILY).run();assert not at.exception
 assert at.session_state[PROJECT]==saved
 upload(at,saved);assert at.session_state[PROJECT]==saved
 return {'routes':19,'single_signed_force_control':True,'minimal_legacy_positive':True,'positive_friction_retained':True,'sign_navigation_reopen_exact':True}
record('sign conditional minimal inputs repeated edits and route navigation',sign_controls)

def atomic():
 at=fresh();button(at,'Gerar memória de canto').click().run();assert REPORT in at.session_state
 original=snap(at);badcases=[]
 for field,value in [('bolt_hardened_washer_count',True),('bolt_hardened_washer_count',1.25),('bolt_washer_diameter',float('inf')),('bolt_surface_class','C'),('combination_type','normal'),('bolt_friction_type','true'),('compression_geometry_stamp',1),('P',float('nan'))]:
  bad=deepcopy(original[PROJECT]);bad['connection'][field]=value;badcases.append(bad)
 for field in ('bolt_installation_source','bolt_continuation_source','compression_brace_restraint'):
  bad=deepcopy(original[PROJECT]);bad['connection'].pop(field);badcases.append(bad)
 bad=deepcopy(original[PROJECT]);bad['connection']['extra_approval']=True;badcases.append(bad)
 for bad in badcases:
  upload(at,bad);assert any('Não foi possível abrir' in x.value for x in at.error);assert snap(at)==original
 return {'actual_rejected_uploads':len(badcases),'preserved_state_keys':list(original)}
record('atomic malformed native uploads preserve current valid outputs',atomic)

def edit_and_stale():
 at=fresh();stamp=base.compression_geometry_stamp
 button(at,'Gerar memória de canto').click().run();assert REPORT in at.session_state
 at.number_input(key=_key('P')).set_value(-20.).run();assert not at.exception
 assert native(at).compression_geometry_stamp==stamp==geometry_stamp(native(at)) and REPORT not in at.session_state
 for name in ('beam_cut_Fx','beam_cut_Fy','beam_cut_M','upper_column_cut_Fx','upper_column_cut_Fy','upper_column_cut_M'):assert getattr(native(at),name)==getattr(base,name)
 at.number_input(key=_key('bolt_washer_diameter')).set_value(33.).run();assert not at.exception
 assert native(at).compression_geometry_stamp==stamp!=geometry_stamp(native(at))
 assert any(i['id']=='compression_geometry_declaration' for i in at.session_state[RESULT]['issues'])
 assert button(at,'Gerar memória de canto').disabled
 saved=deepcopy(at.session_state[PROJECT]);upload(at,saved);assert at.session_state[PROJECT]==saved and not at.session_state[RESULT]['complete']
 at.number_input(key=_key('bolt_washer_diameter')).set_value(32.).run();assert not at.exception
 assert native(at).compression_geometry_stamp==geometry_stamp(native(at))
 at.number_input(key=_key('bolt_hardened_washer_count')).set_value(2).run();assert not at.exception
 assert type(at.session_state[PROJECT]['connection']['bolt_hardened_washer_count']) is int
 saved=deepcopy(at.session_state[PROJECT]);upload(at,saved);assert at.session_state[PROJECT]==saved
 return {'actual_force_preserves_D_U_and_detail':True,'washer_edit_invalidates_report_and_restraint':True,'stale_reopen_stays_pending':True,'integer_washer_edit_roundtrip':True}
record('actual force preserves detail but physical hardware invalidates',edit_and_stale)

def restraints_and_declaration():
 at=fresh();tested=[]
 for field in RESTRAINT_FIELDS[:3]:
  for value in ('unknown','absent'):
   at.selectbox(key=_key(field)).set_value(value).run();assert not at.exception
   r=at.session_state[RESULT];assert not r['complete'] and any(i['id']==field for i in r['issues'])
   assert r['status']=='FAIL' and any(x['status']=='FAIL' for x in r['checks'])
   assert native(at).lateral_restraint and button(at,'Gerar memória de canto').disabled
   button(at,'Registrar contenções na geometria atual').click().run();assert not at.exception
   assert not at.session_state[RESULT]['complete']
   tested.append(field+':'+value)
   at.selectbox(key=_key(field)).set_value('confirmed').run();assert not at.exception
 at.text_input(key=_key('compression_detail_source')).set_value('').run();assert not at.exception
 button(at,'Registrar contenções na geometria atual').click().run();assert not at.exception
 assert not at.session_state[RESULT]['complete']
 at.text_input(key=_key('compression_detail_source')).set_value(base.compression_detail_source).run()
 button(at,'Registrar contenções na geometria atual').click().run();assert not at.exception
 assert native(at).compression_geometry_stamp==geometry_stamp(native(at)) and at.session_state[RESULT]['complete']
 return {'named_missing_or_absent':tested,'receiver_flag_not_substitute':True,'real_failure_preserved':True,'empty_source_not_certified':True,'explicit_detail_only_registration':True}
record('specific restraints cannot be replaced by receiver flag or checkbox',restraints_and_declaration)

after=hashes();loaded={n:{'path':str(Path(m.__file__).resolve()),'sha256':sha(Path(m.__file__))} for n,m in sys.modules.items() if (n=='lro' or n.startswith('lro.')) and getattr(m,'__file__',None)}
(out/'RUNTIME_PROVENANCE.json').write_text(json.dumps({'runtime_root':str(source),'actual_outer_entry':str(entry/'app.py'),'before':before,'after':after,'runtime_unchanged':before==after,'loaded_application_modules':loaded,'not_claimed':['Browser DOM click','OS file dialog','Clipboard interaction']},indent=2)+'\n')
assert before==after,'Runtime source changed during callback run'
print(json.dumps({'passed':all(r['pass'] for r in records),'groups':len(records)},indent=2),flush=True)
if not all(r['pass'] for r in records):raise SystemExit(1)
