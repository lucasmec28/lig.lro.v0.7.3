Independent 0.9.36 source output acceptance. This directory is portable evidence, not an APP package. SOURCE_OUTPUT_ACCEPTANCE.json is the source-only GO. The future APP-only gate is PREPARED, NOT RUN.

After authorization, use a fresh exact APP directory containing only its actual outer app.py and codigo_lro.zip; no source checkout or optional companion files on PYTHONPATH:

PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=<test_dependencies> python -B replay_finalapp.py <APP directory> <external output directory>

The real wrapper and private extraction are observed. Exact loaded module hashes must match SOURCE_RUNTIME_HASHES.json. The replay covers 13 output scenarios, six callback groups and four legacy long-bolt states; all Word XML/media members are compared. Corner native/results/PNG/SVG bytes are exact. Legacy SVG ignores only generated timestamp and bijective defs IDs, retaining geometry, labels, styles and semantic action IDs. Seven negative mutation witnesses verify this boundary.

The wrapper-only bootstrap is prepared infrastructure and is not claimed as tested before an APP exists. Source-mode callback body was tested. No browser DOM clicks, OS download dialogs, clipboard clicks, global stability or fabrication approval is claimed.

Large outputs/renders and superseded failure logs remain outside production; RETAINED_EVIDENCE_MANIFEST.json records their exact hashes and original root. The historical 0.9.35 SVG harness and evidence provenance remain preserved. No ZIP or other archive was created.
