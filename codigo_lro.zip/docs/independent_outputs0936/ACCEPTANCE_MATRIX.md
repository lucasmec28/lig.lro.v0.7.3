# Independent 0.9.36 bolted compression output acceptance

This is a finite, read-only source acceptance of the bolted symmetric 2L-T strong-axis corner compression extension. All evidence is written outside production. It does not package, upload, publish, approve fabrication, or certify global member stability.

## Required checkpoints

1. Reconstruct BCC1 input from the frozen prospective fixture and existing native adapter. Preserve its independent materials and full D/U background. Record all reviewed scope hashes and reject fixture mutation.
2. Main app has 19 routes and the existing four corner adapters. N alone chooses compression. Negative symmetric bolted input reveals the physically necessary friction, continuation and restraint details; ordinary positive legacy input remains minimal. A positive case on a retained friction-type detail still checks slip.
3. Native save, strict decode, actual file-uploader load and reopen retain the physical surface, installation, continuation, hardware and geometry identity. Malformed finite values, booleans-as-numbers, counts, enums, unknown keys and incomplete required groups are rejected atomically. Failed import preserves project, template, accepted values, result, report and draft.
4. Physical root, bolt count/stations/pitch/gauge, hole/contact/clamp and hardware edits invalidate the declaration. Force, project label and material-only edits retain geometry identity. Missing or absent beam, column or brace restraint remains named and unverified; receiver lateral restraint cannot substitute. A stale declaration never becomes valid through save/import.
5. BCC1 has complete local computations, but the actual full joint remains FAIL with common receiver eta 1.010114593606587. The selected inward-U strength is 836842.473182953 N, not the full-cap diagnostic capacity. Neither a rescue load nor a favorable diagnostic replaces it.
6. Actual -20 kN and synthetic -45 kN remain distinct signed cases, each with its complete chain and unchanged D/U background. The synthetic cut is not a Robot/frame cut. Actual zero remains zero with the separately declared +45 kN tensile convention. Unknown, special and exceptional ULS cases receive no automatic 0.70 service scaling. Single-angle compression remains excluded.
7. Capture actual main-app emitted native JSON, results JSON, SVG, PNG, compact Word and expanded Word. Reports and drawings disclose the local/global boundary and the physical friction/detail assumptions. Expanded reports preserve raw rows. The condensed memory and component summaries do not conceal actual failures or pending qualifications. Drawings show four physical bolts, two shear planes, signed actual actions, physical hardware/contact and no brace welds.
8. Render and inspect every unique compact/expanded Word page and selected PNG/SVG drawings. Exact pixel identity may inherit a documented inspected page; text/XML checks alone are not visual acceptance. Record visual hashes and limitations honestly.
9. Replay unchanged positive/welded corner cases and legacy long-bolt 950/1000 mm controls. Normalize only the explicitly documented version differences; do not normalize numerical or semantic drift. Preserve the strict SVG replay normalizer and its mutation witnesses, which exclude only generated timestamps and bijective generated definitions IDs.
10. Hash the runtime before and after each executable checkpoint and identify actual loaded modules. Re-run changed bytes or explicitly prove the permitted delta. Keep all failed, superseded and historical evidence rather than deleting it.

## Historical evidence

HISTORICAL_EVIDENCE_PROVENANCE.json inventories all 1,767 original files from the 0.9.35 output acceptance, retained in place. Selected inherited scripts and receipts are copied verbatim under inherited0935. These are historical evidence only and are not counted as a 0.9.36 pass. In particular, the inherited final-APP replay remains preserved but is not executed in this source-only task.

Prepared before implementation readiness. Execution and visual review are complete: source-only GO is recorded in SOURCE_OUTPUT_ACCEPTANCE.json, with the stable checkpoints and limitations in REVIEW.md. The APP-only replay remains prepared and unexecuted until separately authorized.
