"""Independent semantics of emitted 0936 files, with no production imports."""
from pathlib import Path
from io import BytesIO
from zipfile import ZipFile
import sys,json,hashlib,math,runpy,xml.etree.ElementTree as ET
from docx import Document

here=Path(__file__).resolve().parent;cap=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
# The inherited review covers SVG physical entities, signs of all actual arrows,
# native/report image identity, condensed trace and actual/minimum D/U lineage.
runpy.run_path(str(here/'inherited0935/artifact_semantics.py'),run_name='__main__')
base_records=json.loads((out/'ARTIFACT_SEMANTICS.json').read_text())
(out/'INHERITED_ARTIFACT_SEMANTICS.json').write_text(json.dumps(base_records,indent=2)+'\n')
records=[]
def close(actual,expected):assert math.isclose(actual,expected,rel_tol=2e-9,abs_tol=2e-6),(actual,expected)
def word(path):
 d=Document(BytesIO(path.read_bytes()))
 return '\n'.join([p.text for p in d.paragraphs]+[c.text for t in d.tables for row in t.rows for c in row.cells])
for receipt in json.loads((cap/'DOWNLOAD_RECEIPT.json').read_text()):
 tag=receipt['tag'];native=json.loads((cap/(tag+'.json')).read_text());c=native['connection']
 r=json.loads((cap/(tag+'.results.json')).read_text())['result'];checks=r['checks']
 check_by={x['id']:x for x in checks};extra={}
 svg=ET.fromstring((cap/(tag+'.svg')).read_bytes());drawing_text=' '.join(svg.itertext())
 mc=(cap/(tag+'_mc.txt')).read_text();wtext=word(cap/(tag+'.docx')) if receipt['resistant_report_ready'] else ''
 if c['topology']=='symmetric_2L_T_bolted' and c['P']<0:
  assert r['brace']['force_mode']=='compression' and r['brace']['physical_bolt_count']==4
  close(r['brace']['per_angle_force'],c['P']/2);close(r['brace']['per_plane_force'],c['P']/8)
  close(r['brace']['force_per_gusset_hole'],c['P']/4)
  assert r['brace']['global_member_stability']=='outside_scope'
  assert not any('tension' in x['id'] or 'net_rupture' in x['id'] or 'support_side_block' in x['id'] for x in checks if x.get('component') in ('angles','angle_block'))
  assert all(x['demand']>=0 for x in checks if x['status']!='NOT_APPLICABLE')
  assert r['compression']['inward_zero_cap']['full_cap_diagnostic']['model']=='diagnostic_only_full_cap_not_selected'
  selected=check_by['gusset_inward_tangent_U_zero_cap'];assert selected['model']=='selected_zero_tension_cap'
  close(selected['resistance'],r['compression']['inward_zero_cap']['zero_cap_resistance'])
  extra['signed_compression_no_tension_strength']=True
  if tag in ('BCC1_compact','BCC1_detailed'):
   assert r['status']=='FAIL' and r['complete'] is True
   common=[x for x in checks if x['status']=='FAIL'];assert common
   assert any(math.isclose(x['utilization'],1.010114593606587,rel_tol=2e-9) for x in common)
   close(selected['resistance'],836842.473182953);close(selected['utilization'],.119496802809)
   close(r['compression']['resistance'],503329.314516)
   close(r['compression']['angle_segment']['r_min'],15.)
   close(r['compression']['angle_segment']['Le_over_r'],4.)
   close(r['geometry']['bolt_grip'],31.88)
   local_components={'angles','bolts','angle_bearing','gusset_bearing','gusset_whitmore','gusset_block','gusset_compression','service_slip'}
   local=[x for x in checks if x.get('component') in local_components]
   assert all(x['status']=='PASS' for x in local),(tag,[(x['id'],x['status']) for x in local])
   extra.update(common_receiver_failure_preserved=True,selected_U_resistance_N=selected['resistance'],local_strength_rows_pass=len(local))
 if c.get('bolt_friction_type') and c['topology']=='symmetric_2L_T_bolted':
  slip=r['service_slip'];assert slip['required'] and not slip['ultimate_friction_capacity_added']
  assert slip['interfaces']==2 and slip['minimum_pretension']==91000.
  assert slip['hardware']['hardened_count']==1 and slip['hardware']['location']=='rotating'
  assert slip['hardware']['total_thickness']==4.
  if c['combination_type']=='normal_ultimate':
   close(slip['signed_local_service_force'],.7*c['P']);close(slip['per_bolt_demand'],.7*abs(c['P'])/4)
   close(slip['per_bolt_resistance'],72800.);close(slip['per_interface_resistance'],36400.)
   assert len([x for x in checks if x['id'].startswith('bolt') and x['id'].endswith('_service_slip')])==4
  else:
   assert not slip['qualified'] and 'signed_local_service_force' not in slip and 'per_bolt_demand' not in slip
   assert not any(x['id'].endswith('_service_slip') for x in checks)
   assert any(i['id']=='friction_service_case' for i in r['issues'])
   extra['unknown_or_special_not_scaled']=True
  if receipt['resistant_report_ready']:
   for name,text in [('memory',mc),('Word',wtext)]:
    assert c['bolt_installation_source'] in text,(tag,name,'installation source omitted')
    if c['P']<0:assert c['bolt_continuation_source'] in text,(tag,name,'continuation source omitted')
    assert 'Classe B' in text or 'classe B' in text,(tag,name,'surface omitted')
    assert 'arruela' in text.lower(),(tag,name,'hardware omitted')
    assert 'global' in text.lower() and ('exclu' in text.lower() or 'fora' in text.lower() or 'sem aprovação global' in text.lower()),(tag,name,'global boundary omitted')
   extra['physical_detail_in_reports']=True
 if 'minimum' in tag:
  actual=r['forces'];design=r['design_cases'][0];synthetic=design['result'];df=synthetic['forces']
  assert design['design_P']==(-45000. if c['P']<0 else 45000.)
  if c['P']<0:
   for k,v in {'Fx':34852.813742385705,'Fy':564142.135623731,'M':-47152813.7423857}.items():close(actual['lower_column_cut'][k],v)
   for k,v in {'Fx':52530.48327204938,'Fy':581819.8051533946,'M':-64830483.27204938}.items():close(df['lower_column_cut'][k],v)
  assert synthetic['service_slip']['case_provenance'].startswith('synthetic minimum')
  assert actual['beam_cut']==df['beam_cut'] and actual['upper_column_cut']==df['upper_column_cut']
  extra['actual_synthetic_and_service_provenance_separate']=True
 if tag in ('missing_brace_restraint','stale_hardware'):
  assert not r['complete'] and r['status']=='FAIL' and not receipt['resistant_report_ready']
  assert any(x['status']=='FAIL' for x in checks)
  assert 'PENDENT' in drawing_text.upper(),(tag,'drawing hides missing/stale restraint')
 if tag=='single_bolted_compression':
  assert not r['complete'] and not receipt['resistant_report_ready']
  assert 'Detalhe por atrito mantido no caso tracionado' not in drawing_text
 if tag=='positive_retained_friction':assert r['service_slip']['required'] and r['service_slip']['qualified']
 records.append({'tag':tag,'pass':True,**extra})
(out/'BOLTED_COMPRESSION_ARTIFACT_SEMANTICS.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
print('PASS',len(records),'bolted compression artifact scenarios')
