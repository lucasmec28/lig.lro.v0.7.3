# Independent 0.9.36 source output review

## Decision

GO for the finite source UI, native, report and drawing acceptance, bound to the 139 runtime files in SOURCE_RUNTIME_HASHES.json. The receipt is SOURCE_OUTPUT_ACCEPTANCE.json. The production writer owns the separate aggregate-suite and source-release decision. An APP-only replay, packaging, upload and publication have not been performed.

BCC1 correctly remains a complete but failing full joint. Its common continuity/column receiver utilization is 1.0101145936065872. The selected local inward-U resistance is 836842.4731829532 N; the full-cap result remains a separately labeled diagnostic. No alternate force or fixture was used to rescue BCC1.

## Executed acceptance

- Thirteen main-app capture scenarios include compact/expanded BCC1, actual -20 kN and separate synthetic -45 kN, actual zero with separate +45 kN convention, retained positive friction detail, unknown/special/exceptional combinations, absent brace restraint, stale hardware, the excluded old BC1 root projection, and excluded single-angle compression.
- Six genuine Streamlit callback groups preserve 19 routes, the sign-driven minimum conditional inputs, repeated sign edits, route navigation, report invalidation, save/upload/reopen, and explicit geometry-bound declarations. This is AppTest callback evidence, not browser DOM or operating-system dialog evidence.
- 347 strict native mutation witnesses reject malformed numeric types, nonfinite values, invalid enums/counts and incomplete required groups. Twelve actual rejected file uploads preserve all accepted project/result/report/template/draft state atomically.
- Twenty-seven physical identity mutations cover roots, bolts, pitch/stations, holes/contact/clamp, continuation and hardware/details. Force, materials, case labels and the combination category retain the physical geometry identity. Receiver-only restraint never substitutes for one of the three required physical restraints.
- All 13 emitted native/results/SVG/PNG/Word scenario semantics pass. Negative bearing/force transfer stays signed, physical bolt and shear-plane counts agree, current images are present in Word, unknown/special/exceptional cases never receive automatic 0.70 service scaling, actual and minimum complete cuts retain separate provenance, and excluded cases cannot export a completed resistant Word report.
- Twelve positive/welded native/result states match retained accepted evidence, normalizing only exact values at component_version keys. The two oldest received native inputs have an explicitly recorded isolated frozen-0.9.35 regeneration because no final result receipt existed for them.
- Four genuine older-adapter 950/1000 mm UI states preserve their source-native/results/PNG bytes and every Word XML/media member. SVG comparison ignores only generated dc:date text and bijective generated defs IDs. All seven comparator mutation witnesses pass; geometry, semantic action identifiers, labels, styles and references remain checked.
- Six Word documents were rendered into 74 pages. Every final page was opened directly at full resolution or matched by exact PNG SHA-256 to a documented directly inspected page. Seven drawing scenarios were reviewed through independent SVG rasterization; selected emitted PNGs were opened directly as well. No visual blocker remains.

## Corrected finding and retained failures

The initial unsupported negative 1L friction drawing had overlapping footer rows and called the case tensile. The production writer separated the eccentricity/no-cancellation/disclaimer rows, labeled unsupported friction output diagnostic, and made the zero-force label explicit. Final SVG raster and emitted PNG inspection confirms the fix. Initial evidence remains in round1/DRAWING_VISUAL_REVIEW_INITIAL.json.

Initial harness issues were corrected without production changes: the diameter mutation now uses supported 19.05 mm; positive friction UI expects only active service inputs while retaining inactive continuation data; the global-scope wording check recognizes the explicit Portuguese “Sem aprovação global”; and two absent historical output paths now receive a provenance-recorded frozen-source regeneration. Original failure logs remain. The round1 and final runs also correctly rejected runtime changes during capture; the final_stable checkpoint has unchanged before/after runtime hashes throughout.

## Provenance and boundaries

The qualified contract/input/oracle manifest was verified before fixture construction. Input preparation uses only the prospective physical fixture; it does not use oracle resistances as production inputs. The inherited 0.9.35 evidence, including stale failures and the amended SVG replay, remains untouched and inventoried in HISTORICAL_EVIDENCE_PROVENANCE.json.

Large media, Word page PNGs, rasterizations and raw logs remain in this review directory. The compact portable evidence directory contains native inputs, exact expected output hashes, acceptance receipts, review records, a retained-evidence inventory and a prepared APP-only replay. It is evidence and future test infrastructure, not an APP package or a completed package gate.

This review does not claim global brace/frame adequacy, far-end or stitch qualification, actual installed restraint/pretension certification, manufacturing tolerance approval, or fabrication authorization.
