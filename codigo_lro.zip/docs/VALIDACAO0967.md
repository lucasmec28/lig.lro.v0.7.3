# Validação 0.9.67

- 257 testes principais passaram; quatro testes de artefatos foram selecionados na rodada própria.
- 151 testes numéricos finais passaram após compatibilizar expectativas da nova envoltória; rodadas sobrepostas, não somar contagens.
- 295 testes na rodada final de apresentação/legados/convenções passaram.
- Dois Word finais de 15 páginas inspecionados visualmente: preset e ações negativas/filetes distintos.
- Revisão mecânica independente: 300 casos de barra EB; Timoshenko comparado a elementos finitos independentes; 100 grupos vetoriais 3D com gargantas distintas comparados a quadratura/solver6x6; sinais/reflexões/origem/zero e momentos equilibrados.
- Checks da nervura com extensão e resultados dos cinco presets single plate em ambas formas comparados à .66, sem mudanças.
- Desenho físico preservado. Legenda externa idêntica; variante interna corrigida para V positivo em +y.
- JSON ida/volta, memória recalculada, invalidação de exportação antiga e quadro de vetores concomitantes testados.
- Pacote de uso compacto com quatro arquivos. O verificador interno confere todos os arquivos pelo manifesto atual. Hash e teste do ZIP extraído são registrados na entrega.

A validação de software não aprova a ligação completa. Permanecem as pendências de chapa perfurada, interação líquida, blocos/ligamentos, FLT e chapas receptoras/fixidez/rotação, explicitadas no método.
