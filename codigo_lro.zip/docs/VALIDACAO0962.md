# Revisão 0.9.62 — duas talas

Auditoria restrita da família de duas talas, sobre a fonte 0.9.61 preservada.

Correções: rejeição consistente de diâmetro não pertencente ao catálogo; momento assinado do grupo para V negativo, coerente com a equação da memória; desenho e exportação SVG indisponíveis para geometria inválida. As capacidades e picos resistentes da configuração simétrica não mudam pela correção de sinal.

Não há novo método de resistência da nervura perfurada interna. Mantêm-se os avisos de transferência pelos ligamentos até três bordas, estabilidade local, soldas e receptores, assim como rotação/acesso de montagem. AISC 15 Fig.10-19c não corresponde automaticamente a esta emenda simétrica interna. O balanço somente na alma, anteriormente investigado, não demonstra falha do detalhe real.

Matriz/plano precedeu a criação desta cópia. Evidências e totais de testes são preservados separadamente com a fonte completa e no recibo final da entrega. Testes de software não constituem aprovação estrutural.

Resultado final: 206 testes da suíte de duas talas aprovados. Validação adicional de interface: 72 aprovados, com cobertura sobreposta (não somar). Pacote extraído aprovado.
