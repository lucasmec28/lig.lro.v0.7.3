# Chave retangular: metal de dois filetes opostos

Componente integrado em 0.9.6-key-weld-dev: verificação local, não aprovação da chave ou base completa. Empacotamento e publicação são etapas separadas.

## Física e fontes

Uma chapa retangular maciça centrada, `b=lug_bh` em y, `t=lug_t` em x, projeção H abaixo da placa e graute real g, H>g. Somente dois filetes ortogonais de pernas iguais, idênticos, retos e contínuos: raízes físicas x=±t/2 e y=−b/2 a +b/2, sob a placa. Não há retorno, contorno fechado, dobra, cruz, W ou crédito a solda adicional. CJP exige outro modelo. `Lreal=Leff=b`, de tamanho pleno até os extremos. Perna z e garganta z/√2 são representações equivalentes.

NBR 8800:2024, corrigida em 2025, §6.7.2.4: para soldas não CJP, são preservadas as ações de desenvolvimento de capacidade já calculadas pelo motor:

- σ=1,7 fck/1,40
- |Vw|=σ b(H−g)
- |Mw|=|Vw|(H+g)/2

Não se substitui Vw por Vreal, Vreal/2, capacidade menor do aço, resistência reduzida de chumbadores ou parcela após atrito. Em Vreal=0, permanece o envelope positivo. Com Vreal<0, ambos os sinais invertem. O equilíbrio global existente permanece `Mlocal=Mtopo+Vreal[tp+(H+g)/2]`; nenhuma ação prescrita da solda retorna ao equilíbrio global ou à solda superior pilar–placa.

AISC DG1, 3ª ed., Ex.4.7-5, pp.88–89: o binário local é entre centroides separados por `ac=t+2z/3`, sem corrigir novamente o momento da raiz. Esta distância analítica é distinta das raízes físicas. Em cada linha:

- qx=Vw/(2Leff)
- qz,+ = Mw/(ac Leff); qz,− = −Mw/(ac Leff)
- q=√(qx²+qz²), incluindo a componente comprimida
- qRd=0,6 fw(z/√2)/γw2, fw=485 MPa e γw2=1,35

A resistência é a escalar da NBR, sem aumento direcional AISC de 1,5. Relatórios identificam ações da chave sobre a placa; a reação na chave tem sinais opostos. São verificadas as resultantes ΣqxLeff=Vw, ΣqzLeff=0 e ΣxqzLeff=Mw. Unidades canônicas: N, mm, N·mm, N/mm e MPa.

## Detalhamento, produtos e execução

A perna mínima usa a parte real mais fina pela Tabela 11: 3 mm para tmin≤6,3; 5 para ≤12,5; 6 para ≤19; 8 acima. O requisito associado de execução em passe único tem registro explícito. O comprimento de cada filete deve atender Leff≥max(40 mm;4z). Não se aplica automaticamente o máximo t−1,5 de uma borda livre à raiz de uma ligação T.

Verificam-se prateleira da placa, apoio da perna vertical na face real da chave (z≤H), implantação física e colisão com os quatro furos da geometria nativa; os filetes da coluna estão na face superior e não são obstáculos fictícios da face inferior. O documento de execução deve cobrir apoio íntegro, continuidade e tamanho pleno, acesso, extremos e demais interferências inferiores. Não se presume esse documento a partir da escolha do eletrodo.

Se o filete avança abaixo do graute (z>g), ele ocupa parte da face plana de contato com concreto adotada pelo modelo. Essa geometria exige detalhe próprio e permanece pendente, com valores nominais sem crédito resistente. z≤g é fronteira geométrica desta idealização, não máximo universal NBR de filete.

Nesta primeira implementação, Lreal≤100z é domínio da aplicação, não proibição universal NBR de soldas transversais longas. Acima dele há pendência precisa de tratamento de comprimento/direção e não se concede resistência qualificada. Um comprimento inferior a b também exige outro detalhe físico; não reduz o contato da chave silenciosamente. Leff>Lreal ou Lreal>b são incompatibilidades geométricas.

Processo SMAW/E7018; os aços reais da chave e da placa são independentes. A rota de compatibilidade abrange ASTM A36 e A572 Gr.42/50/55, com os limites de espessura de cada produto já cadastrados. Outro material/processo não herda uma resistência qualificada. A relação tchave≤tplaca reutiliza a verificação existente, sem duplicação de cálculo.

O registro de execução fica vinculado a geometria, ações, materiais, processo e texto técnico atual. Converter perna↔garganta sem modificar a perna física mantém o vínculo. A assinatura apenas detecta alterações, não valida o conteúdo técnico do documento. Separadamente, a assinatura do resultado inclui o estado de confirmação e impede mostrar resultado antigo para entradas novas.

## Resultados e limites

`weld_component_status` e `status`: pass, fail ou pending. Falhas numéricas conhecidas continuam visíveis mesmo se faltar execução ou outro dado. Materiais/domínio sem qualificação não ganham uma aprovação de metal de solda; números nominais diagnósticos são identificados como tal.

Sempre: `attachment_complete=False`, `device_complete=False`, `complete=False`. Permanecem separados:

- Metal-base junto à fusão na chave e na placa sob o campo adotado
- Flexão/cisalhamento e transferência local da placa aos chumbadores/contato reais
- Concreto específico da chave, bordas, arrancamento, bloco armado e fundação

Não foi criado um passe fictício da placa receptora por q/t ou por uma faixa escalar. Os cálculos já existentes de contato, flexão/corte da chave, placa, chumbadores e demais componentes continuam intactos. Sucesso local não apaga falhas existentes ou restrições Tipo 2 C1/C2/T1/T2.

## Evidência reproduzível

`tests/fixtures/single_key_weld_independent.json`: quatro referências independentes de 50 dígitos Decimal, sem importação das fórmulas de produção.

- DG1 Ex.4.7-5, ações originais: NBR índice 1,145624512 (não atende), versus AISC com ganho direcional 0,758020101
- Mesma geometria, ações prescritas NBR: índice 3,561255627 (não atende)
- Exemplo local b=100, H=100, g=40, t=tp=50,8, z=16, fck=20: índice 0,743144640 (atende ao componente)
- b=200, H=150, g=40, t=31,75, tp=38,1, z=8, fck=30: índice 8,577558369 (não atende), embora a flexão da própria chave sob Vreal=100 kN atenda

`validation/verify_single_key_weld.py` reproduz as contas com Decimal e compara com o motor. Os exemplos em `validation/single_key_weld` contêm pass/fail, inversão, Vreal=0, dado inválido, documento desatualizado, material incompatível e colisão física. Qualificações desses exemplos são dados sintéticos, nunca evidência real de projeto.

Testes focados: `test_single_key_weld.py`, `test_single_key_weld_app.py` e `test_single_key_weld_artifacts.py`. Evidência final de execução e renderização consta de `docs/VALIDACAO_KEY_WELD096.md` e `validation/v096/`. O agregado completo da integração 096 foi executado sobre código e testes congelados, separadamente dos ensaios anteriores do componente.
