# Revisão 0.7.4

## Resultado desta revisão

Limites empíricos de aplicação não impedem mais o estudo numérico quando as equações continuam utilizáveis. A interface e a memória distinguem extrapolação, não conformidade de detalhamento, interferência de montagem e entrada inválida. Nenhum esforço ou dimensão informado é corrigido silenciosamente.

| Situação | Cálculo e Word | Conclusão |
|---|---|---|
| Faixa ensaiada ou detalhe de referência ultrapassado | Disponíveis | Cálculo com ressalvas e extrapolação do modelo |
| Espaçamento máximo ou distância máxima à borda excedidos | Disponíveis | Não atende ao detalhamento, mesmo com índices menores que 1 |
| Resistência ou condição do método não atendida | Disponíveis | Não atende |
| Interferência de montagem, com equações utilizáveis | Disponíveis | Conferir interferências |
| Equação ou distribuição não aplicável, entrada inválida, ligamento inviável | Bloqueados | Geometria inválida com motivo específico |

A continuidade do cálculo não equivale à aprovação do detalhe. As ressalvas aparecem na conclusão e nas premissas da memória Word. Fora do domínio validado, os valores calculados não confirmam a resistência ou a classificação de rigidez do arranjo.

## End plate engastada e W200

Os limites da tabela 5-9 do DG39, já acrescidos da tolerância de 10%, passam a avisos de extrapolação. Isso inclui altura e espessura da mesa da viga, pfi, pfo, extensão, gabarito e largura da chapa. O mesmo tratamento é dado a fy da chapa acima de 345 MPa e gabarito maior que bf da viga, quando os demais requisitos permitem executar as equações.

A seção 4.1.2 do DG39 alerta que mudar dimensões além da faixa de ensaios pode alterar o mecanismo de plastificação; diminuir a altura da viga não é automaticamente uma extrapolação validada. O programa mantém essa ressalva e não confirma o engaste pela simples obtenção de índices menores que 1.

Caso do usuário preservado em `examples/Caso_usuario_W200_v074.json`: W200×26,6 em W200×35,9(H), tp=19,05 mm, g=80 mm, V=44.129,925 N, N=2.000 N, M=2.941.995 Nmm. Produz 17 verificações, maior índice 0,827540, com duas ressalvas de domínio. Não representa validação experimental da W200 nem aprovação automática do engaste.

A largura física pode superar bf + max(25,4 mm; tp), mas o cálculo de Yp passa a usar apenas a largura efetiva limitada, conforme DG39 3.7.2. O desenho e os demais detalhes continuam com a largura física informada. A chapa deve permanecer dentro da mesa da coluna nesta implementação.

Continuam bloqueados, entre outros: axial dominante fora da distribuição implementada, ausência de momento no caso 4E, inversão de momento com extensão só acima, linhas internas cruzadas, braços não positivos, material sem propriedades aplicáveis e espaçamentos mínimos incompatíveis com o detalhe adotado.

## Linhas intermediárias entre mesas

Novo campo em **End plate engastada → Chapa e parafusos → Linhas intermediárias entre as mesas**. Aceita de zero a dez linhas, cada uma com dois parafusos, equidistantes entre as duas linhas internas do grupo base. O valor inicial é zero, inclusive para projetos JSON antigos.

Essas linhas são **de detalhamento, sem crédito resistente**. São mostradas no desenho, salvas no JSON e registradas no Word. Todos os furos entram no espaçamento, nos ligamentos de contato e nas deduções dos blocos da chapa. Nas verificações de blocos parciais, a parcela de V continua proporcional somente aos parafusos do grupo base contidos no bloco. Os parafusos extras não diminuem as forças do grupo original nem aumentam a capacidade de momento calculada.

O efeito das linhas adicionais sobre contato, distribuição de tração, alavanca, rigidez e plastificação não está dimensionado como um novo grupo resistente. Por isso, o arranjo ampliado recebe sempre ressalva de extrapolação. Esta opção não implementa os modelos 6E/8E/8ES nem fornece aprovação automática dos parafusos adicionais.

No detalhe do print W410×46,1 / W200×35,9(H), com pfi=45 mm, há 290,6 mm entre as linhas internas. O limite adotado é 244,8 mm. Uma linha intermediária divide esse vão em 145,3 mm. Essa mudança resolve o aviso de espaçamento desse vão; não comprova, sozinha, o dimensionamento completo do arranjo. O campo não é alterado automaticamente.

## Auditoria das outras ligações

- **Single plate na alma da viga e na mesa da coluna:** espaçamentos máximos e distâncias máximas às bordas passam a não conformidades sem bloquear cálculo/Word. Limites de recorte, esbeltez e altura conectada, que já permitiam cálculo com pendência, recebem indicação explícita de extrapolação. Ductilidade, soldas, hierarquia contra punção e demais verificações resistentes continuam sem aprovação quando falham.
- **Duas talas na alma da coluna:** mesmo tratamento para espaçamento e bordas máximos. Altura conectada, espessuras ligadas à flexibilidade e tolerância sem calços acima de 1 mm recebem ressalvas de domínio. Diferença de espessuras sem contato/calços compatíveis, soma dos calços fora do modelo, eliminação da seção líquida e requisitos de soldagem continuam exigindo revisão antes de calcular.
- **End plate rotulada:** gabarito fora de 90–140 mm, chapa com fy acima de 275 MPa, sobra acima de 10 mm e grupo com extensão menor que meia altura tornam-se ressalvas de classificação. O campo da sobra admite valores acima de 10 mm. Momento externo continua fora do modelo rotulado; os limites calculados de flexibilidade, ductilidade e alavanca continuam sendo conferidos.
- **Todas as famílias:** entradas não finitas, materiais desconhecidos, dimensões não positivas, falta de ligamentos e mecanismos sem distribuição de forças implementada continuam bloqueados. O enrijecedor oposto e o complemento entre mesas preservam a condição de detalhamento sem crédito resistente.

## Referências conferidas

- ABNT NBR 8800:2024, versão corrigida 2025, arquivo fornecido: 6.3.10(a) para espaçamento máximo de elementos protegidos/não sujeitos à corrosão e 6.3.12 para distância máxima à borda. Não são recomendações facultativas; a não conformidade permanece no resultado.
- AISC Design Guide 39 (2023), arquivo fornecido: 4.1.2, 5.3.1 e tabela 5-9 para domínio de ensaios; tabela 5-10 e equação 3-44 para os mecanismos 4E; 3.7.2 para largura efetiva e hipóteses de aplicação.
- SCI P358 (2014), 4.7, referência já adotada para o detalhe nominalmente rotulado. Os critérios numéricos resistentes anteriores são preservados.

## Verificação do software

Regressões cobrem o JSON antigo da W200, o aviso de espaçamento do W410, linhas intermediárias nos dois layouts e nos sentidos permitidos de M, nenhuma redução indevida das forças do grupo base, dedução dos novos furos, falhas resistentes com ressalvas, limites da rotulada, geometrias bloqueadas e exportação Word pela interface. A distribuição final de quatro arquivos é testada a partir de uma extração limpa.
