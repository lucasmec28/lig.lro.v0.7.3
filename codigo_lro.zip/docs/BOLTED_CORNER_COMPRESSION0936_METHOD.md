# Compressão local parafusada 2L-T · 0.9.36

A implementação segue o contrato e a revisão independente congelados em `qualification_bolted_corner_compression0936/`. Um único incremento dentro da família de canto existente; continuam 19 rotas. O sinal N<0 ativa somente o adaptador 2L-T simétrico. 1L/opostas, cargas espaciais, fadiga/sismo, estabilidade global, far-end e costuras intermediárias permanecem excluídos.

## Domínio físico e entradas condicionais

Uma linha de parafusos passantes de alta resistência, duas interfaces de contato direto iguais, furos redondos padrão furados, sem enchimento, prying ou tração externa no parafuso. A extremidade por atrito é uma restrição deliberada da primeira rota sob NBR5.3.6.2/6.1.11.2(c), não classificação universal de todo par 2L. Usa os campos anteriores de parafuso, diâmetro, rosca, protensão, pega, ferramenta, talão e aços. O novo grupo condicional identifica Classe A/B, origem de preparo/aperto/inspeção, quantidade e posição das arruelas endurecidas, diâmetro real, continuação carregada das L e classificação do ELU. A espessura total das arruelas permanece no campo de pega existente.

As três contenções documentadas e seu identificador geométrico são reutilizados; no ramo parafusado a identidade inclui posições, furos, gramil, contato, hardware e detalhe de aperto/superfície, além das raízes e membros. A fonte precisa justificar translação relativa e torção em cada estação e contenção fora do plano do traspasse. Simetria/protensão/marcação isoladas não provam essa condição. Mudança física invalida a declaração. Forças, materiais e classificação da combinação não a invalidam, mas suas verificações são recalculadas.

## Mecânica selecionada

- N/2 por L, N/(2n) por plano e N/n por furo da chapa única, com sinais reais. Deslizamento de serviço: 0,80 μ Ce FTb ns; 0,70|N| somente para ELU normal identificado. FTb métrico16 A325 é91kN, distinto de5/8pol=85kN. Nunca se adiciona atrito ao corte/contato ELU.
- Contato comprimido: chapa−u, L+u. Último furo da L usa continuação íntegra real>=2db, não ponta livre junto à raiz. Cada parede é independente.
- Cada L: compressão bruta, escoamento líquido suplementar, AL3 com b integral, intervalo curto K1/Le=p e r mínimo publicado. p/r<=25 é limite do domínio local escolhido, não limite universal normativo.
- Whitmore desde o primeiro parafuso: faixa nominal inteira contida e projeções inteiras nas duas raízes efetivas; K1 e máximo sobre toda a faixa. NBR5.3 completa para qualquer Le, sem atalho de escoamento pela anomalia textual de6.5.4.
- U reverso selecionado tem zero crédito de tração do cap: Rd=min(0,6fyAgv;0,6fuAnv)/γa2. Todos os L reversos devem continuar excluídos por apoio; U precisa de duas pernas distintas até o recorte livre real. Outra topologia fica especificamente não verificada. Cap completo é diagnóstico separado, nunca outra capacidade selecionável.
- Corpo bruto/líquido com raízes parciais e limites incluído/excluído do furo cortado; refinamento numérico explícito, sem certificado de intervalo ou campo pontual de pressão. Só tensão normal positiva real ativa ruptura por tração.
- A cadeia assinada completa conserva raízes, J, L derivado, mesas/alma, continuidade, união receptora e painel. −45kN é caso sintético separado para −45<N<0; D/U reais permanecem fundo explícito. N=0 conserva zero real e convenção nominal+45kN. Deslizamento mínimo é salvaguarda sintética, não combinação rara real.

## Testemunhos e limites

BCC1 usa a geometria hipotética congelada300×300×12mm, primeiro parafuso u385mm, quatro M16/passo60mm, ClasseB, arruela endurecida4×32mm e continuação60mm. Foi acrescentado como novo preset; BC1 antigo não foi deslocado nem redimensionado. BCC1 dá Nc,Rd chapa503,329315kN, intervalo de cada L260,687892kN, deslizamento72,8kN/parafuso e U conservador836,842473kN. A margem nominal da projeção na coluna é só0,251418mm e não é tolerância de fabricação.

BCC1 permanece NÃO ATENDE no receptor comum: η1,010114594. Não se altera a força nem se redimensiona o receptor para ocultar a falha. BCC2 real−20/sintético−45 mantém cortes inferiores distintos. As saídas compactas/expandidas e desenhos mostram sinais, mecanismos ativos, hardware, contenções e alcance local.

A evidência de0.9.35 e a correção anterior do replaySVG são preservadas. Expectativas de testes alteradas por esta expansão de domínio têm bytes originais e motivos em `test_amendments0936/`; falhas exploratórias são mantidas fora da fonte. O teste externo histórico de contato de parafusos continua sem seu arquivo original e não é contado como aprovado. Validação final, congelamento e autorização de pacote são gates separados.
