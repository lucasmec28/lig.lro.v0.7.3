# Concrete anchor tension breakout: bounded specification

Date: 2026-10-09. Purpose: add a genuine concrete tension-breakout check to the existing Type 1 NBR baseplate calculator, while retaining an explicit incomplete-anchorage status. Technical basis for the complementary implementation in version 0.8.3.

## 1. Recommended increment and honest completion wording

Implement the regular four-external-rod Type 1 layout, its actual concurrent per-rod tensile reactions, a rectangular intact-concrete prism, and cast-in mechanically headed anchorage. Supported families are a forged head, a mechanically engaged buried anchorage nut, and a buried rigid bearing plate retained by a suitable nut. A straight rod with no defined anchorage device is not one of those families; neither is a post-installed adhesive anchor.

Native numerical scope: static tension breakout, normalweight cracked concrete, identical cast-in anchors with common actual effective embedment, no supplementary-reinforcement strength credit. Use the basic ACI 318-19 expression throughout rather than the optional deep-embedment enhancement. Real concrete edges, overlapping cones, loaded-group eccentricity, and the three-or-more-edge effective-depth correction are included.

A suitable result is: “Ruptura do cone de concreto por tração: atende/não atende à verificação complementar ACI 318-19. Ancoragem completa ainda não verificada.” Do not say the anchors, foundation, or whole base have been approved. If no rods are tensile, this mode is “não solicitado nesta combinação,” not proof of overall anchorage adequacy.

Pullout, bearing-plate/nut strength, side-face blowout when applicable, splitting/detailing, concrete shear breakout, pryout and tension/shear interaction remain individually visible as unverified unless calculated by a separately verified path. Existing steel checks remain valid only inside their existing detailed domain. This increment is useful by itself because it exposes the actual reduced tension cone, rather than continuing to imply concrete anchorage from a rod-steel result.

## 2. Source map and evidence strength

### Supplied primary references inspected

- AISC Design Guide 1, 3rd edition (2024), supplied PDF under `baseplate_references/Automação MC/900064977-AISC-Design-Guide-01-Base-Connection-Design-for-Steel-Structures-3rd-Ed.pdf`.
  - Printed p.8 / physical p.18: recommends headed rods or straight rods with a buried nut; discusses embedded plate washers and constructability. Printed p.9 excludes post-installed anchor design from the Guide.
  - Printed pp.29–33 / physical pp.39–43: §4.3.2.2, pullout, breakout, side-face blowout, Figures4-2/4-3/4-4. Formula pixels were inspected; do not rely on extraction that loses square-root signs.
  - Printed pp.74–76 / physical pp.84–86: Example4.7-3, four rods, concentric uplift, optional deep-embedment branch.
  - Printed pp.84–85 / physical pp.94–95: Example4.7-5, only two rods in tension; group area and eccentricity use that loaded row.
  - Printed pp.135–137 / physical pp.145–147: Example4.7-15, 20in square pedestal, 4in square anchor group, fictitious embedment5.333in and concrete strength20.4kip after rounded arithmetic.
- Supplied corrected NBR8800:2024/Er1:2025 remains the steel/base reference. Its corrected Figure21 shows buried nuts. Corrected Table18 notes require actual concrete-block design and reinforcement under NBR6118, and distinguish the upper special washers used for shear. The corrected table is not proof of CCD breakout capacity.
- User drawing `references/Automação MC/PADRÃO DE LIGAÇÕES-4Model.pdf`, single large sheet, lower row:
  - C-001, drawing p.66: hooked rod.
  - C-002, drawing p.67: hooked rod.
  - C-003, drawing p.68: straight rod with buried plate and nut. The adjacent upper-washer table is not the buried plate table. No plate bearing area may be inferred from the upper-washer table.
  - Inspected high-resolution crops saved as C001.png, C002.png, C003.png here.

### Public primary corroboration and errata

- ACI's own Fall2023 anchorage lecture: https://www.concrete.org/portals/0/files/pdf/webinars/ws_F23_Matthew%20Senecal.pdf . Slides45,51,65–69 substantiate group checks, no general effective-embedment cap, and the narrow-member correction. The research note `aci_modifiers.md` contains exact geometry and source limitations.
- Official AISC DG1 errata dated May23,2025: https://www.aisc.org/media/22mmv1en/design-guide-1-3rd-ed-revisions-and-errata-list-1.pdf . Direct retrieval returned403; the official indexed text was readable. Relevant entries correct the p.28 steel ASD safety factor to2.00 and add a nominal-pullout symbol definition after Eq4-25 on p.29. The retrieved excerpt does not change the breakout equations. Do not state that a complete downloaded errata PDF was inspected.
- Hilti's publisher-produced PROFIS guide reproduces relevant ACI318-19 clauses: https://viewer.joomag.com/profis-design-guide-ac-318-19-july-2022/0546853001659024142/p52 and pages66–78. It is primary evidence for that implementation and reproduced excerpts, not a licensed copy of the complete ACI code. Do not import Hilti-only software limits as ACI requirements.

DG1's edition basis is ACI318-19(22), not ACI318-25. Final engineering review should verify controlling-code wording and applicable errata from legitimate complete access before claiming code-complete anchorage. This deliverable intentionally makes no such claim.

## 3. Design-basis separation

Keep existing NBR8800 steel, baseplate and contact equations and their factors unchanged. This is an explicitly labelled complementary ACI318-19 concrete-anchorage calculation.

- Actions: pass the already factored simultaneous NBR-combination reactions T_i from the existing solver. Do not refactor them as ASCE7 loads, combine maxima from different cases, or multiply by another load factor.
- Concrete: ACI equations use specified compressive strength f'_c; do not substitute fcd=fck/gamma_c. For the existing normalweight20–50MPa input range, record the assumption that the declared characteristic cylinder strength is being used as f'_c, subject to the responsible engineer's design-basis acceptance.
- Strength reduction: phi=0.70 for concrete tension breakout without qualifying supplementary reinforcement, ACI Table17.5.3(b). Do not additionally divide by NBR gamma_c or gamma_a. Ordinary block reinforcement alone does not justify phi0.75 or suppress breakout.
- DG1 explicitly assumes ASCE7 load factors when presenting its phi factors (p.29). Therefore combining NBR action effects with ACI resistance models must be disclosed as a complementary design basis; do not claim it is a fully calibrated NBR anchorage prescription or fully compliant ASCE/ACI design.
- Native default excludes seismic, cyclic/fatigue, fire and impact. Any seismic non-steel strength reduction or ductility route is a separate future implementation.

## 4. Required inputs and physical gates

### Existing validated inputs

- Four actual anchor centers `(x_i,y_i)` in the established baseplate coordinates, their physical rod IDs and one concurrent load-combination ID.
- Four actual nonnegative tensile reactions `T_i` from that combination. Existing NBR case behavior: C1/C2 allzero; C3/T3/M0 two tension rods on the appropriate moment-sign side; T1 four equal; T2 two unequal pairs, with smaller pair possibly zero at the transition.
- Nominal diameter and existing steel/plate geometry/materials. Moment reversal must move loaded rods to their physical opposite edge; it must not simply reuse an unordered force list.

### New concrete/anchorage inputs

- Actual block or pedestal left/right/bottom/top plan bounds relative to the same anchor axes, or actual width/length plus actual offset. Do not substitute the baseplate outline or a minimum tabulated block for these values.
- Actual concrete member thickness/depth below its structural top surface; a larger footing below a narrower pedestal or stepped boundary is outside this rectangular-prism geometry unless the actual relevant concrete region is separately modeled.
- Physical effective embedment `hef_physical`: distance from the structural concrete top surface to the upper load-bearing face of the buried head/nut/plate. Exclude grout and exposed projection. Never infer it from total rod length, thread length, or C-003 dimension H/d without resolving the actual datum.
- Concrete normalweight status and specified cylinder strength. First increment fixes cracked concrete; an uncracked increase needs a documented service-level no-cracking analysis and its own supported option.
- Cast-in anchor family and traceable anchorage-detail reference. Mechanical head/nut engagement must be real, not a checkbox that turns an unknown plain rod into a headed anchor.
- Head/plate actual plan dimensions, hole, thickness, actual lower extent of the complete nut/plate/rod end below the bearing face, and bottom cover. For nut-only anchorage record its documented effective concrete-bearing area and dimensional reference. Nut chamfers make an ideal hex outline an unreliable automatic bearing-area proxy.
- Installation/detail declaration that the modeled concrete is intact and the selected bearing face exists. Return unsupported for an unfilled void/pocket, damaged concrete, sleeves affecting the modeled load path, or a headed device bearing in unqualified fill.
- Record whether the anchorage is torqued/preloaded, and the engineer's cover/splitting/detailing check. Tension-breakout strength can be shown independently, but unresolved prerequisites must remain visible and may not become a general anchorage pass.

Geometry validation: all finite values, positive actual dimensions, all anchor centers inside actual concrete bounds, all modeled buried head footprints inside the block, sufficient actual thickness for the complete embedded assembly and declared bottom cover. Reject booleans-as-numbers, missing bounds, impossible embedment and nonpositive net bearing areas. Do not silently clamp head dimensions or move rods.

### C drawings: physical detail caveat

All C-001/002/003 show an approximately150mm-deep foam pocket around the rod near the concrete top, with diameter100mm or150mm according to rod size. No source examined establishes a general full-strength CCD treatment of that unfilled pocket. The first native scope explicitly assumes intact structural concrete; an unfilled pocket is outside it. This does not instruct fabrication to fill the pocket or assume an unverified grout bond; the actual installed detail needs a qualified load path.

This detail also matters to existing native anchor shear: `anchor_shear_scope/specification.md` explicitly excludes standoff/free ungrouted rod length and sleeves across the shear-transfer zone. Selecting C-003 must not automatically certify that shear path. The upper welded special washer is a separate load-transfer component from the buried anchorage plate/nut.

## 5. Calculation contract

### Units

Recommended unambiguous implementation: convert new ACI calculations to the DG1 equation units at a single boundary: inches, psi, lbf. Use24 and16 only with those units. Convert1in=25.4mm,1lbf=4.4482216152605N,1psi≈0.006894757293168MPa. Do not insert24 into an N/mm/MPa implementation. The independently rounded ACI SI coefficient10 does not reproduce the US24 path exactly; select and state one convention rather than switch coefficients mid-test.

### Active geometry and candidates

Let S contain anchors with actual `T_i>0`, after roundoff-scale force cleanup consistent with the equilibrium solver. Do not use an arbitrary threshold to erase a small positive force or turn genuinely negative/inconsistent forces into tension. An empty S means no tensile demand.

The primary code check uses actual interacting tension-loaded groups. An independently loaded singleton uses the single-anchor equation; a row with overlapping projections is a group; two noninteracting groups are separate checks. In the current Type1 model, the main states are a single loaded row or all four tensile rods.

It is acceptable to additionally check all nonempty positive-load subsets (at most15) as an explicitly CONSERVATIVE APPLICATION ENVELOPE. Preserve the primary active-group result and label the extra governing subset. No source in this review says ACI mandates all15 checks. Do not advertise the envelope as an exact optimized ACI capacity. Arbitrary L-shaped/diagonal subsets are geometry stress cases beyond the normal production Type1 loading patterns.

For any candidate group, calculate its exterior anchor-envelope clearances:

`c_left=min(x_i)-X_left; c_right=X_right-max(x_i); c_bottom=min(y_i)-Y_bottom; c_top=Y_top-max(y_i)`.

These are not distances from every individual anchor to every remote edge. The minimum of them is `cmin` for that candidate.

### Narrow pedestal / three or more edges

Start with physical embedment h. If three or more of the candidate's exterior clearances are less than1.5h, set:

`hcalc=min(h, max(cmax/1.5, smax/3))`.

Here cmax is the largest of the influencing clearances below1.5h, excluding a remote fourth edge. For the regular2×2 rectangular group use `smax=max(sx,sy)`; a regular two-rod row uses its row spacing; a singleton uses0. DG1's4×4in example uses4in, not the diagonal5.657in. A generic many-row/irregular-group definition is not verified here. If arbitrary conservative subsets require another spacing interpretation, document and review it; do not claim it is exact controlling-code language.

`min(h,...)` is a defensive no-increase guard. A proposed modification greater than physicalh is not increased embedment. Apply hcalc consistently in ALL tension-breakout terms: projected area, reference area, Nb, edge factor and eccentricity factor. Do not alter physical embedment for head fit or side-face-blowout screening.

Source: ACI17.6.2.1.2; DG1pp.135–137; ACI public slides67–68. The training slide uses a non-strict symbol at the boundary; exact controlling-code text should govern. Tests at equality must avoid a discontinuous artificial strength gain.

### Projected area

For candidate anchor i create its square influence region:

`R_i=[x_i-1.5hcalc,x_i+1.5hcalc] × [y_i-1.5hcalc,y_i+1.5hcalc]`.

For the regular supported pattern, compute the actual union of these regions clipped to the actual concrete rectangle:

`ANc=area( union_i(R_i) intersect concrete_rectangle )`.

`ANco=9*hcalc²`, and enforce the source bound `ANc<=n*ANco` without increasing the actual area. A negative/zero area with positive tensile demand is invalid/failing, not a pass.

For aligned overlapping full2×2 or a loaded row, the union reproduces the familiar row/rectangle formula. A bounding box is valid only when the union actually fills that box. It overcounts an L-shaped missing corner or disconnected groups. A plane-sweep union of clipped rectangles is simple and exact numerical geometry; no circular-cone area may be substituted for the CCD square footprint.

Keep separately identifiable disconnected components and their own demands. Summing capacities across components can hide one locally overloaded anchor. If all subsets are evaluated, each component/singleton still must govern its own demand. The generalized square-union implementation for irregular subsets is a conservative engineering geometry choice, not a verbatim ACI general-group algorithm.

### Basic strength and modifiers

For the first release, in inch/psi/lbf:

`Nb=24*lambda_a*sqrt(fc_psi)*hcalc^1.5`.

`lambda_a=1.0` for the supported normalweight concrete. Reference ACI17.6.2.2.1; DG1pp.30–31.

The optional headed-stud/bolt branch is `Nb=16*lambda_a*sqrt(fc_psi)*hcalc^(5/3)` for11in≤hcalc≤25in, ACI17.6.2.2.3. It may be omitted entirely. There is no general25in effective-embedment limit for the basic cast-in breakout equation; do not confuse the optional interval with a global domain cap.

`psi_ed=1` when cmin≥1.5hcalc, otherwise `psi_ed=0.7+0.3*cmin/(1.5hcalc)`; ACI17.6.2.4.1.

`psi_c=1.0` for cracked concrete. The cast-in uncracked breakout multiplier is1.25 if that separate condition is proven under17.6.2.5; the native first scope does not claim it. `psi_cp=1.0` for cast-in anchors,17.6.2.6.2. This does not waive splitting/detailing requirements.

For a group, use geometric centroid of candidate tensile anchors `(xg,yg)` and force resultant `(xt,yt)`:

`xg=sum(x_i)/n; yg=sum(y_i)/n`.

`Tg=sum(T_i); xt=sum(T_i*x_i)/Tg; yt=sum(T_i*y_i)/Tg`.

`ex=abs(xt-xg); ey=abs(yt-yg)`.

`psi_ec=[1/(1+ex/(1.5hcalc))]*[1/(1+ey/(1.5hcalc))]`.

References17.6.2.3.1–.3. The production uniaxial model normally has one factor equal1. Do not use the centroid of clipped area, the baseplate centroid, the column M/N, or a radial eccentricity in place of the two factors. Equal forces in a lone loaded row have psi_ec=1 even though the row is offset from the plate center.

Singleton: `Ncb=(ANc/ANco)*psi_ed*psi_c*psi_cp*Nb`.

Group: `Ncbg=(ANc/ANco)*psi_ec*psi_ed*psi_c*psi_cp*Nb`.

Design strength `phiNcb=0.70*Ncb` (or group counterpart). Demand is the same candidate's actualTg. Compare `eta=Tg/phiNcb`. Never compare the maximum rod force with group capacity or the sum of all four demands with only one loaded row's area accidentally.

## 6. Pure-helper interface and outputs

Inputs: source/method version; factored-case ID; four `{id,x,y,T}` entries; concrete bounds/depth/strength/normalweight/cracking; physicalhef; cast-in family and head-detail metadata; optional explicit conservative-envelope policy. Feed solver reactions rather than recalculate moment distribution in this helper.

Outputs must include:

- `scope_status`: computed_partial / no_tension_demand / unsupported / invalid, distinct from numerical strength pass/fail.
- source edition, units, phi and every supported assumption.
- Physicalhef AND separate hcalc, including narrow-rule trigger, all candidate clearances, influencingedges,cmax,smax.
- Active anchor IDs and all candidate/component IDs actually checked; per-rod forces and group demand.
- Projected union rectangles/polygon, clipped area, reference area and area ratio. The drawing should show the concrete edges and the reduction, not only a generic cone symbol.
- Nb, all psi factors, tensile force centroid/geometric centroid, nominal and design capacities, utilization and governing candidate.
- Primary code-group result separately from additional conservative subset-envelope result.
- List of unsupported or still-unverified modes/prerequisites with specific reasons; never null→zero resistance or null→PASS.
- Source provenance and load-combination identity preserved through save/load, drawings and Word export.

Native mode should not silently replace existing externally verified anchorage capacities or migrate old files into a concrete pass. Legacy unknown geometry remains unknown until actual new inputs are supplied.

## 7. Other modes: exact next-scope formulas and gates

### Pullout of a cast-in head/nut

DG1p.29 Eq4-25 and ACI17.6.3:

`Np=8*Abrg*f'_c; Npn=psi_c,P*Np; phiNpn=0.70*Npn`.

Abrg is actual net bearing area, not steel tensile area, upper-washer area, or gross buried-plate area without its hole. `psi_c,P=1.0` cracked and1.4 only with justified no-service-cracking condition. Pullout is checked against the most highly loaded actual anchor, not a pooled group force divided by four.

For a rigid rectangular buried plate with a circular hole, geometric net area is `Bhead*Lhead - pi*dhole²/4`, only if that entire footprint can actually transfer load. The plate must develop its bending/local bearing and nut/thread loads; do not credit an arbitrarily thin plate as a rigid head. A mechanical nut/head rating and plate verification remain required. The upper special washer welded to the baseplate does not increase Abrg.

DG1Table4-2 benchmark:7/8in heavy-hex nut net area1.19in²,fc4000psi,cracked gives phiNpn=26,656lbf≈26.7kip. For1in nut area1.50in², result33,600lbf.

### Side-face blowout

Screen every physical free edge using PHYSICALhef. Headed anchors require consideration when `hef_physical>2.5*ca1`. Reducinghef for tension breakout must never suppress this trigger.

DG1pp.31–33 / ACI17.6.4:

`Nsb=160*ca1*sqrt(Abrg)*lambda_a*sqrt(f'_c)` in inch/psi/lbf.

For a susceptible group along one edge with spacing below6ca1:

`Nsbg=(1+s/(6ca1))*Nsb`, where s is distance between outer susceptible anchors along that edge.

DG1's summary is insufficient to implement every corner/second-edge and unequal-head configuration. ACI's additional perpendicular-edge reduction and exact grouping provisions must be verified before a general side-face calculation is shipped. First increment: if any edge triggers it, show “side-face blowout required; not calculated.” If all physical edges have hef≤2.5c, it is legitimately “not applicable for entered geometry,” subject to other physical gates.

### Hooked rods

DG1p.29 gives `Np=0.9*f'_c*eh*da`, with3da≤eh≤4.5da and the same pullout phi/cracking modifier. It warns hooks have limited pullout and recommends restricting their use. C-001/002 are hooks. Merely reusing a headed cone formula does not establish their pullout or deformation behavior. Store hook type if useful, but keep native complete tension anchorage unavailable until hook geometry/detail/pullout are deliberately implemented and verified. Deferring J is justified.

### Shear, pryout and combined interaction

Native tension cone gives no concrete shear capacity. ACI17.7.2 shear breakout,17.7.3 pryout and17.8 interaction remain unverified; existing NBR steel shear and upper-washer checks cannot substitute for them. If V≠0 on the anchorage path, show those pending modes prominently even if tension breakout passes. Do not claim V=0 unless the complete authorized shear-transfer path actually keeps anchor concrete shear at zero. A friction/lug checkbox alone is not that verification.

Splitting/minimum spacing/cover/member design remain separate. See `aci_modifiers.md`: retrieved table values distinguish torqued vs not-torqued cast-in anchors. No unverified generic h/hef condition may be borrowed from post-installed anchors or from one vendor's software.

## 8. Independent benchmarks and release checks

`benchmarks.json` contains eight independent analytical fixtures; no production functions were imported. All reference values use the canonical DG1US coefficients, with unit conversions supplied.

1. DG1Example4.7-3:15in embedment,4×4in group,fc4000psi. Basic branch phiNcb=73,188.576190lbf. Optional5/3 branch=76,624.428658lbf fullprecision; guide76.3kip is based on rounded intermediate values.
2. DG1Example4.7-15:20in square pedestal,4in square group,physicalhef14in; hcalc=16/3in; ANc400in²; phiNcb=20,448.308814lbf.
3. One edge:hef10in,c5in,ANc600in²,psi_ed0.8,phiNcb17,920lbf.
4. Two-edge corner:hef10in,c5/8in,ANc460in²,phiNcb13,738.666667lbf. No three-edge correction.
5. Only one two-rod row loaded:ANc1080in²,phiNcb40,320lbf. Wrongly counting the two unloaded rods would give51,072lbf.
6. Four unequal tensile rods:5/15kip row pairs,ex2in,psi15/17,phiNcb45,063.529412lbf.
7. Three-edge asymmetric ACI training geometry:clearances5/4/6in,spacing9in; hcalc4in,ANc200in²,phiNcb10,625.252938lbf. The far anchor-to-left-edge14in must not be used as cmax.
8. Geometry/partition stress:three squares at(0,0),(8,0),(0,6),side30in,union1320in² not bounding1368. Four distant squares have3600in² total,not4900; one34kip demand exceeds its33.6kip singleton resistance even when the pooled total would pass.

Also test zero tensions, moment-sign mirroring against asymmetric concrete bounds, anchor-permutation invariance, load-case preservation, nonfinite/bool/missing inputs, impossible head fit, physicalhef vs fictitioushcalc separation, metric↔US conversion, explicit unfilled-pocket gate, no-credit inactive rods, boundary c=1.5h and spacing=3h, invalid adhesion/plain-rod family, deepbasic branch beyond25in without applying the optional formula, and no silent full-anchorage pass under shear.

The implemented result should make it visually obvious why edges and overlap reduce the cone and which actual tensile group governs. The software release still needs independent implementation review, test execution, UI/export validation and engineering sign-off for its claimed scope.
