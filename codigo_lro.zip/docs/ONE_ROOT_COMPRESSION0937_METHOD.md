# Compressão local de duas cantoneiras em T na mesa W

Incremento0.9.37, 12out2026. Uma chapa retangular e uma raiz contínua dupla na mesa exterior de W laminado, centrada na alma. Duas L iguais em T simétrico, uma por face, quatro filetes longitudinais idênticos. N negativo escolhe o ramo de compressão local; 19 rotas são preservadas. A categoria interna histórica axial_tension do guia permanece por compatibilidade de navegação; seu rótulo agora explicita domínio conforme a família.

## Caso real ainda sem aprovação

SRC1 é o antigo exemplo de200kN com apenas o sinal invertido: chapa400×300×10mm, L100×100×12, θ75°, centro(0,150), quatro filetes5×200mm e raiz dupla5×400mm, W310×165×52. Nenhuma peça foi redimensionada. A seção local ainda falha:245,333333/227,272727=1,079466667. Faixa Whitmore266,724617mm, Lmáx96,652683mm e resistência condicional556,476924kN. Vínculos reais de raiz/W, diagonal e receptor permanecem desconhecidos.

## Método e dados físicos

DG29 Exemplo5.4 fornece o modelo de uma raiz com K1,2 e deslocamento lateral permitido. A raiz/W e a continuação da diagonal exigem contenção real à rotação fora do plano; simetria, quatro soldas ou solda contínua não demonstram esses vínculos. Campos separados registram estado, fonte e assinatura da geometria para raiz e diagonal. Outro registro independente identifica contenção relativa das mesas do W ou os dados reais de5.7.5. Não há vão padrão, inferência por distância à extremidade ou exigência genérica de FEA.

A assinatura é recalculada a partir da geometria/topologia física, não das ações ou rótulos. Alteração da implantação, chapa, seção, soldas ou extremidades invalida os registros pertinentes. Mudança de vão/rotação/interação do receptor invalida seu registro sem estabelecer ou destruir automaticamente o vínculo geométrico raiz/diagonal. O botão de vínculo apenas carimba fontes explicitamente informadas: não muda estados, não inventa fontes e não preenche vãos. Texto desconhecido ou não informado não satisfaz evidência.

O campo inteiro deve ter normais não positivas nas seções horizontais, na faixa local e em ambos os extremos da raiz. Campo misto recebe OUTSIDE_SCOPE preciso com ações reais exportadas, sem resistência emprestada de tração por módulo de N. Condições de vínculo desconhecidas, em contraste, preservam resistências e falhas diagnósticas. CHECKS_FAIL_AND_UNVERIFIED mantém ambos; NOT_VERIFIED não se transforma em aprovação por ausência de falha numérica.

Whitmore a30° parte da extremidade da transferência mais próxima da raiz. Intersecta o retângulo e as projeções paralelas à diagonal que chegam à raiz real. A maior faixa simétrica sobre v0=ec−b/2 recebe N integral. Le=1,2 vezes o máximo exato dos comprimentos de toda a faixa. Exige todos os comprimentos maiores que1e−10 max(1,B,H,Lw), rejeitando arredondamentos de borda exatamente na raiz. Não cria segunda raiz, borda física virtual, K0,7 ou compactação de canto. Curva integral NBR5.3, Aef=A para essa faixa não perfurada; AL3 com b integral é verificado separadamente nas L. Le/r200 permanece um limite automático conservador de comportamento em serviço.

## Transferência e W receptor

N/2 por L e quatro forças físicas; uma chapa, raiz e W com N total uma única vez. Ações N/V/M e as seções elásticas são assinadas. Mantêm-se metal dos filetes, substratos, escoamento da introdução/chapas e cisalhamento. O limite uniforme de transferência usa uma superfície L vezes espessura e Ant0, conservando a ponta plana real do catálogo legado. Não usa Ct nem blocos tracionados da ponta livre em compressão.

Nraiz=N senθ; Vraiz=N cosθ; Mraiz=xforça Nraiz−yforça Vraiz. Para resistência receptora, Neq=B max(0,−qn1,−qn2) é envelope de pressão; não é ação adicional no equilíbrio. NBR5.7.3 inclui extremidade d;5.7.4 inclui d/2 e B/d0,2. Mesa por tração5.7.2 inativa. W5.7.5 exige contenção relativa real ou ℓ real envolvendo ambas as mesas e condição de rotação da mesa carregada, h=d−2k, Cr16E conservador. Razões superiores estritas a2,3/1,7 dispensam o modo; igualdade ainda usa fórmula. O cálculo5.7.5 não prova a rotação da raiz K1,2. Ações próximas/opostas/painel devem ser identificadas; outro modelo é exigido quando interagem.

## Ações e formatos

|N|<45kN não nulo recebe caso separado com o mesmo sinal antes da divisão nas L. Zero permanece caso real zero com mínimo nominal+45kN da rota existente. A opção50% em compressão fica pendente de resistência global real da diagonal, sem reutilizar Ct tracionado. Projetos nativos0.9.28 são validados integralmente e migrados com contenções desconhecidas. Campos/preceitos híbridos, tipos errados e dados não finitos são rejeitados. Premissas ativas variam explicitamente com o sinal; importação não converte premissas incompatíveis silenciosamente.

A UI mostra os campos avançados somente em compressão, conserva os ocultos na entrada nativa e invalida memórias antigas. Resultados físicos agrupados e Word diagnóstico ficam disponíveis mesmo com vínculos pendentes. Word compacto/detalhado e desenho atual repetem sinal, força por face, faixa cortada à raiz, falhas e condições. Ct fica explicitamente inativo nas primitivas de compressão. Os exportadores recalculam a entrada atual, ignorando qualquer aprovação fornecida pelo chamador.

## Fontes e correção

O contrato revisado, fixture independente, oráculo, páginas lidas e revisão do método estão em qualification0937. ERRATA_NBR8800_0937.md identifica o PDF exato: a Errata1 PDF1 corrige6.5.4(b) para Le/r>25. O corpo antigo PDF117 é superado. A interpretação ativa do canto foi corrigida; aritmética conservadora e evidência histórica congelada não foram reescritas.

Nenhuma aprovação global da diagonal/W/pórtico ou fabricação. Sem extensão a alma W direta, nervura interna, 1L, parafusos, cantoneiras opostas, sismo, fadiga ou ações espaciais.
