# Auditoria e plano 0.9.62

Base preservada: cloud_connection_0961/src. Trabalho exclusivamente na cópia cloud_connection_0962/src; sem publicação, implantação ou acesso ao computador do usuário.

## Matriz de decisão antes da cópia

| Frente | Evidência disponível | Decisão |
| --- | --- | --- |
| Nervura perfurada interna, três bordas | Decisões anteriores e AISC 15, Fig.10-19, novamente inspecionada; não há novo exemplo aplicável com linha interna e duas talas | Não implementar resistência integral fictícia, não remover pendências |
| Parafusos/componentes existentes | Auditoria de implementação e casos assinados | Corrigir inconsistências reproduzíveis e acrescentar regressões |
| Importação de diâmetros | db=19.050000001 é aceito pela tolerância do motor e provoca KeyError no lookup exato | Alinhar validação ao catálogo exato usado pela interface; entrada inválida deve retornar resultado de geometria, nunca crash |
| Sinais na memória | V negativo usa Mgrupo positivo na substituição, embora a equação assinada diga Mg=V eg | Preservar sinal no grupo elástico e usar módulos somente nos mecanismos que os exigem; provar invariância dos picos e coerência da memória |
| UI, desenho e exportação | Auditoria independente em andamento | Corrigir apenas defeitos demonstrados; preservar posição interna e folga inicial de 10 mm |
| Entrega | Pacote compacto existente | Regerar identidade, manifesto e arquivo compacto; validar paridade de runtime e launcher extraído |

## Plano curto
1. Fixar os defeitos confirmados na cópia 0.9.62, sem mudar domínio resistente.
2. Completar auditoria de UI/desenhos/exportação e executar regressões de duas talas.
3. Verificar pacote extraído e fornecer resumo objetivo do que mudou e da lacuna técnica remanescente.

## Achado adicional confirmado

A geometria com edge_x=1 mm era corretamente rejeitada pelo cálculo, mas o SVG continuava disponível. A interface agora bloqueia desenho/SVG para severity=error, preservando a inspeção de geometrias válidas com falhas resistentes ou pendências técnicas.
