# Validação focada de0.9.31

Gate de fonte aprovado após aceitação numérica/saída independentes e aceite do responsável pela integração: 988 casos pytest distintos passaram, sem falhas ou skips nesses relatórios. Reruns sobrepostos não são somados. Comparações numéricas independentes ficam separadas dos casos pytest.

Escopo: nova disposição2L opostas parafusadas, estado nativo distinto, desenhos físicos, Word resumido/detalhado, resumo copiável e convenção positiva sem valores; preservação dos18 seletores e dos resultados físicos anteriores1L/2L-T.875 arquivos congelados de0.9.30 continuam intactos no diretório original; nenhum arquivo legado foi removido da nova fonte. Motores físicos anteriores e double_cover permanecem byte-idênticos; identificação global de versão e pontos declarados de apresentação foram alterados.

Exemplo300×300×12,5mm/80°/100kN: bloco da L0,421153774; raiz0,387391955; parcial refinado0,196108418. Diagnóstico negativo de sinal na introdução não rejeita a conexão; ligamento real/raiz permanecem sujeitos ao domínio tracionado.

Evidências: `ENGINE_ACCEPTANCE0931.json`, `UI_ACCEPTANCE0931.json`, `LEGACY_PARITY0931.json`; método `OPPOSED_BOLTED_GUSSET0931_METHOD.md`. Caminhos em `VALIDATION0931.json` são relativos à raiz da fonte.

Não foi rodada a suíte histórica inteira. O antigo oráculo externo ausente de contato de parafusos continua não recuperado. Qualificação de método prévia com736 comparações não é contada como teste da implementação. Sem upload/push/deploy, qualificação global ou liberação de fabricação. Extração/smoke do pacote é gate separado.
