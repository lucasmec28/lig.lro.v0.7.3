# Validação da fonte0.9.41

MRE1/2 sem nervuras: seis linhas e12 parafusos, seis ativos à tração e seis
comprimidos recebendo V. Aços independentes, sinais N/M/V, saturação somente
em Yp, caminhos físicos e casos completos conforme o contrato limitado.
Demanda espessa e diagnóstico nominal são separados, sem gate redundante.

## Execução integral única nos bytes finais

5949 casos distintos:5948 aprovados, uma falha histórica, zero erros e zero
pulados. Quatro grupos disjuntos cobrem exatamente a coleção final. Runtime,
testes,fixtures e catálogos ficaram idênticos antes/depois da execução.

A falha é test_axial_double_angle.py::test_bolt_bearing_oracle_file_and_opposite_loaded_free_ends,
por ausência do oráculo externo original bolt_bearing_oracle.json. Não foi
inventado substituto nem transformada a falta em aprovação ou skip.

## Revisões independentes e legado

A revisão mecânica independente aprovou91 casos focados e4602 comparações
aritméticas em26 testemunhos;80 estados completos do legado permaneceram
exatamente iguais. A revisão de saídas guarda as verificações nativas, visuais
e as limitações precisas de cobertura em seu recibo. PNGs dos seis exemplos
legados e conteúdo dos Word mantêm paridade, normalizando só a versão global.
Todos os42 fixtures herdados são exatos. As seis emendas de testes antigos
alteram somente versão/seletor/serialização nativa real, sem expectativas
numéricas reescritas. Esses números não são somados à contagem do agregado.

A documentação inclui scripts executáveis, fixture independente,80 estados
legados completos comprimidos, cinco nativos atuais e reprodução de artefatos.
Capturas exploratórias brutas não foram incorporadas ao incremento.

Fonte GO não é pacote GO, publicação, fabricação ou aprovação de um projeto
real. A fonte0.9.40 permanece imutável. O empacotamento deve verificar o APP
efetivamente extraído e tratar qualquer nova omissão histórica com aprovação
exata do responsável pela entrega.
