# Soldas em três bordas — single plate entre mesas

## Escopo
A versão 0.9.66 compartilha o núcleo elástico de soldas da versão 0.9.65 com a single plate entre mesas. O modo retangular convencional e a rotina de duas talas são preservados. Há dois filetes simétricos em cada uma das três bordas; a garganta da alma pode diferir da garganta das mesas. Os alívios de canto não recebem solda.

## Geometria e equilíbrio
Coordenadas: x para fora da alma receptora; y para cima; origem no meio da altura do apoio. O cortante de entrada V positivo é dirigido para baixo, logo Fx=N e Fy=−V. A carga é aplicada no centro horizontal dos parafusos e na altura do eixo da viga apoiada. Sua translação ao centroide do grupo gera MG=M0−xG·Fy+yG·Fx, com M0=xP·Fy−yP·Fx. Não se adiciona novamente o momento que já originou forças no grupo de parafusos.

Aw=Σ2aL; a=w/√2. Centroide ponderado pelas áreas de garganta e momento polar Jw integrado em cada segmento. Tensões equivalentes: τx=Fx/Aw−MG(y−yG)/Jw e τy=Fy/Aw+MG(x−xG)/Jw. O máximo da norma ocorre em uma das extremidades de cada segmento. A resistência nominal de projeto da garganta é 0,60fw/1,35, sem majoração direcional. As forças e os momentos são integrados por borda, conservando seu binário local, e conferidos contra o equilíbrio global. Reações sobre a chapa têm os sinais opostos às ações transmitidas aos receptores.

## Hipóteses e limites
Chapa e receptores rígidos no plano; rigidez elástica uniforme por área de garganta. O resultado é próprio das soldas sob essa hipótese. Não dimensiona o campo da chapa perfurada, sua estabilidade, metal-base completo, rigidez/capacidade dos receptores nem capacidade de rotação da ligação. O enrijecedor oposto permanece sem crédito. Comprimentos L/w>100 mantêm pendência sobre a aplicabilidade de redução de soldas longas. Intervalos físicos inválidos ou incompatíveis com o receptor não recebem capacidade fictícia.

A aprovação da single plate retangular não pode ser copiada para a chapa entre mesas. As verificações nominais conservadas são referências identificadas, enquanto as verificações que pressupõem transferência integral apenas à alma são substituídas pelo novo caminho e suas pendências. Não se somam as resistências dos dois modelos.

## Fontes
- ABNT NBR 8800:2024, versão corrigida 2025, seção 6.2 e Tabela 9: resistência das soldas e requisitos geométricos aplicáveis.
- AISC Steel Construction Manual, 15ª edição, pp.8-12 e 8-13: método elástico. A ponderação por gargantas distintas é a extensão analítica explicitada pelo núcleo.
- RISA, Stability and Geometry Checks, seção Bolts Located Between Horizontal Welds: a condição de rotação da single plate direta depende da posição dos parafusos em relação às soldas horizontais. Não é uma conclusão de ruptura da chapa e não é transferida automaticamente à ligação de duas talas.
https://help.risa.com/risahelp/risaconnection/Content/Design%20Checks/Stability%20and%20Geometry.htm

## Rota de viga-coluna
Permanece estudo independente, sem nova aprovação no aplicativo. Conter apenas uma borda lateralmente não elimina necessariamente a torção. Nenhuma isenção de FLT nem resistência de seção íntegra é atribuída automaticamente à chapa perfurada nesta versão.
