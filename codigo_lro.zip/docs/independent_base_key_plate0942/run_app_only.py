#!/usr/bin/env python3
"""Portable, source/output-parameterized verification of the delivered APP.

Requires only Python plus APP requirements. No book files, private workspace,
pytest, or external review files. Numeric references use independent Decimal
arithmetic and a separate bracketed equilibrium solution.
"""
from pathlib import Path
from decimal import Decimal,localcontext
import argparse,hashlib,importlib.util,json,math,os,sys

D=Decimal


def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def bisection_oracle(*,tp,H,tkey,V,state):
    """Independent C=T and C*(a+L/2-lc/2)=|V|e, 160 bisections."""
    with localcontext() as ctx:
        ctx.prec=70
        tp,H,tkey,V=map(lambda v:D(str(v)),(tp,H,tkey,V))
        L=D(500);B=D(230);a=D(200);g=D(40);fy=D(250);bh=D(100)
        e=tp+(H+g)/2 if state=='native_nbr_full_depth' else tp+g+min(H-g,2*tkey)/2
        p=D('.85')*20/D('1.4') if state=='native_nbr_full_depth' else D('.65')*D('.85')*20
        moment=abs(V)*e;q=p*B;arm=L/2+a;lo=D(0);hi=L/2
        assert q*hi*(arm-hi/2)>moment
        for _ in range(160):
            mid=(lo+hi)/2
            if q*mid*(arm-mid/2)<moment:lo=mid
            else:hi=mid
        lc=(lo+hi)/2;C=q*lc;mt=C*a;mc=C*(L-lc)/2;rd=fy*bh*tp**2/(4*D('1.10'))
        return {k:float(v) for k,v in dict(lc_mm=lc,C_N=C,T_row_N=C,M_tension_Nmm=mt,
            M_contact_Nmm=mc,M_Sd_Nmm=max(mt,mc),M_Rd_Nmm=rd,utilization=max(mt,mc)/rd,
            t_required_mm=(4*max(mt,mc)*D('1.10')/(fy*bh)).sqrt(),e_mm=e,
            Mbase_Nmm=(D(1) if V>0 else D(-1))*moment).items()}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source',type=Path,help='Unpacked APP source root containing lro and data')
    parser.add_argument('output',type=Path,help='Separate output folder for evidence')
    args=parser.parse_args();source=args.source.resolve();output=args.output.resolve()
    if output==source or source in output.parents:parser.error('Output must be outside the APP source root.')
    assert (source/'lro/single_key_plate.py').is_file()
    output.mkdir(parents=True,exist_ok=True)
    os.environ.setdefault('MPLCONFIGDIR',str(output/'mpl_cache'))
    os.environ.setdefault('XDG_CACHE_HOME',str(output/'cache'))
    sys.dont_write_bytecode=True;sys.path.insert(0,str(source))
    from lro.models import Profile,VERSION
    from lro.base_plate import BasePlate,evaluate
    from lro.single_key_concrete import SingleKeyConcrete
    from lro.single_key_plate import local_bending_values
    from lro.single_key_plate_artifacts import image_bytes,json_bytes,append_report
    from lro.base_plate_report import create_report
    from docx import Document
    from docx.shared import Inches,Pt
    from io import BytesIO
    from dataclasses import replace
    runtime_paths=[source/'app.py',*source.glob('lro/*.py'),*source.glob('data/*')]
    before={str(p.relative_to(source)):digest(p) for p in sorted(runtime_paths) if p.is_file()}
    independent=source/'docs/independent_base_key_plate0942/reproduce_oracles.py'
    spec=importlib.util.spec_from_file_location('independent_receiving_plate_oracles',independent)
    oracle=importlib.util.module_from_spec(spec);spec.loader.exec_module(oracle)
    refs=oracle.make_oracles()
    fixture=source/'tests/fixtures/single_key_plate0942_independent.json'
    assert refs==json.loads(fixture.read_text()),'Decimal fixture does not reproduce'
    profile=Profile('Portable I300','Soldado',40.,300.,150.,8.,12.,276.,7008.)
    def connection(tp=50.8,H=140.,tkey=20.,V=100000.):
        return BasePlate(profile,a1=50.,a2=130.,N=0.,M=0.,V=V,tp=tp,lug_bh=100.,lug_bv=H,
                         lug_t=tkey,grout_t=40.,fck=20.,grout_fck=40.,shear_path='plate',
                         single_key_concrete=SingleKeyConcrete(model='aci318_19_conservative'))
    fields=('lc_mm','C_N','T_row_N','M_tension_Nmm','M_contact_Nmm','M_Sd_Nmm','M_Rd_Nmm','utilization','t_required_mm')
    decimal_results=[]
    for case in refs['cases']:
        i,e=case['input'],case['expected']
        if case['id'].startswith('published_'):
            actual=local_bending_values(C=e['C_N'],T_row=e['T_row_N'],a=float(i['a']),L=float(i['L']),
                lc=e['lc_mm'],bh=float(i['bh']),tp=float(i['tp']),fy=float(i['fy']),gamma=float(i['gamma']))
        else:
            r=evaluate(connection(H=float(i['key_H']),tkey=float(i['key_t']),V=float(i['V'])))
            actual=next(s for s in r.local_single_key_plate['states'] if s['id']==i['state_id'])
        errors={k:actual[k]-e[k] for k in fields}
        assert all(math.isclose(actual[k],e[k],rel_tol=2e-12,abs_tol=1e-8) for k in fields)
        decimal_results.append(dict(id=case['id'],errors=errors,pass_=True))
    bisected=[]
    for tp in (25.4,31.75,38.1,44.45,50.8):
        for H in (100.,140.):
            for magnitude in (30000.,60000.,100000.):
                for sign in (-1,1):
                    c=connection(tp=tp,H=H,V=sign*magnitude);r=evaluate(c);d=r.local_single_key_plate
                    assert d['status'] in ('pending','fail') and not d['complete']
                    for state in d['states']:
                        expected=bisection_oracle(tp=tp,H=H,tkey=20,V=sign*magnitude,state=state['id'])
                        errors={k:state[k]-v for k,v in expected.items()}
                        assert all(math.isclose(state[k],v,rel_tol=2e-12,abs_tol=1e-8) for k,v in expected.items())
                        bisected.append(dict(tp=tp,H=H,V=sign*magnitude,state=state['id'],errors=errors,pass_=True))
    artifacts=[]
    for sign,label in ((1,'positive'),(-1,'negative')):
        c=connection(V=sign*100000.);r=evaluate(c);prefix='deep_key_'+label
        payloads={prefix+'.json':json_bytes(c,r),prefix+'.png':image_bytes(c,r),
                  prefix+'_full.docx':create_report(c,r)}
        doc=Document();sec=doc.sections[0];sec.page_width=Inches(8.27);sec.page_height=Inches(11.69)
        sec.left_margin=sec.right_margin=Inches(.65);sec.top_margin=sec.bottom_margin=Inches(.6)
        doc.styles['Normal'].font.name='Arial';doc.styles['Normal'].font.size=Pt(10)
        doc.add_paragraph('APP '+VERSION+' · componente de escoamento por flexão')
        append_report(doc,c,r);buf=BytesIO();doc.save(buf);payloads[prefix+'_component.docx']=buf.getvalue()
        for name,data in payloads.items():
            path=output/name;path.write_bytes(data);artifacts.append(dict(file=name,bytes=len(data),sha256=digest(path)))
        expected=max(r.geometry['t_required'],r.local_single_key_plate['t_required_mm'])
        full=Document(BytesIO(payloads[prefix+'_full.docx']))
        row=next(row for table in full.tables for row in table.rows if row.cells[0].text=='Espessura requerida / adotada')
        from lro.report import number
        assert row.cells[1].text==number(expected,3)+' / '+number(c.tp,3)
    after={str(p.relative_to(source)):digest(p) for p in sorted(runtime_paths) if p.is_file()}
    assert before==after
    result=dict(status='PASS',app_version=VERSION,source=str(source),runtime_sha256=before,
                runtime_unchanged=True,fixture_sha256=digest(fixture),generator_sha256=digest(independent),
                decimal_cases=decimal_results,bisection_states=bisected,artifacts=artifacts,
                counts=dict(decimal_cases=len(decimal_results),bisection_states=len(bisected),artifacts=len(artifacts)),
                limitations='Only bounded gross-section flexural yielding; full transfer, holes, rupture and fillet/base-metal interfaces remain pending. Word files generated and XML values checked; render separately for visual QA.')
    (output/'APP_ONLY_REPLAY.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(status='PASS',version=VERSION,counts=result['counts'],receipt=str(output/'APP_ONLY_REPLAY.json'))))


if __name__=='__main__':main()
