#!/usr/bin/env python3
"""Compare independent, precomputed Decimal oracles to the candidate source.

This is intentionally separate from reproduce_oracles.py. Imports the production
adapter only for comparison. Disables bytecode writes and writes only here.
"""
from pathlib import Path
import sys
sys.dont_write_bytecode = True
import json, math, hashlib
from dataclasses import replace
HERE = Path(__file__).resolve().parent
SOURCE = HERE.parents[1]
sys.path.insert(0, str(SOURCE))
from lro.models import Profile
from lro.base_plate import BasePlate, evaluate, reactions
from lro.single_key_plate import local_bending_values, evaluate_component, result_is_current
from lro.single_key_concrete import SingleKeyConcrete


def main():
    from reproduce_oracles import make_oracles
    data=make_oracles()
    fixture=json.loads((SOURCE/'tests/fixtures/single_key_plate0942_independent.json').read_text())
    assert data==fixture, 'Independent oracle fixture does not reproduce'
    profile=Profile('Independent P300','W',40.,300.,150.,8.,12.,276.,5000.)
    summary={'source':str(SOURCE),'comparisons':[], 'negative_and_domain_tests':[]}
    failures=[]
    metrics=('lc_mm','C_N','T_row_N','M_tension_Nmm','M_contact_Nmm','M_Sd_Nmm',
             'M_Rd_Nmm','Z_mm3','utilization','t_required_mm','Mbase_Nmm','e_mm',
             'contact_x_mm','tension_row_x_mm','Vtop_N')
    for case in data['cases']:
        expected=case['expected']; inp=case['input']
        if case['id'].startswith('published_'):
            actual=local_bending_values(C=expected['C_N'],T_row=expected['T_row_N'],
                a=float(inp['a']),L=float(inp['L']),lc=expected['lc_mm'],bh=float(inp['bh']),
                tp=float(inp['tp']),fy=float(inp['fy']),gamma=float(inp['gamma']))
            component_status='kernel'
        else:
            c=BasePlate(profile,a1=50.,a2=130.,N=0.,M=0.,V=float(inp['V']),
                tp=50.8,lug_bh=100.,lug_bv=float(inp['key_H']),lug_t=float(inp['key_t']),
                grout_t=40.,fck=20.,grout_fck=60.,shear_path='plate',
                single_key_concrete=SingleKeyConcrete(model='aci318_19_conservative'))
            r=evaluate(c);out=r.local_single_key_plate
            actual=next(s for s in out['states'] if s['id']==inp['state_id'])
            component_status=out['status']
            assert component_status=='pending' and out['flexure_status']=='pass'
            assert out['complete'] is False and out['attachment_complete'] is False
            assert result_is_current(c,r)
            assert not result_is_current(replace(c,tp=50.81),r)
        fields={}
        for field in metrics:
            if field not in actual:continue
            target=expected[field]
            good=math.isclose(actual[field],target,rel_tol=2e-12,abs_tol=1e-8)
            fields[field]={'expected':target,'actual':actual[field],'pass':good,
                           'absolute_error':abs(actual[field]-target)}
            if not good:failures.append(case['id']+':'+field)
        summary['comparisons'].append({'id':case['id'],'status':component_status,'fields':fields})
    c=BasePlate(profile,a1=50.,a2=130.,N=0.,M=0.,V=100000.,tp=50.8,lug_bh=100.,
                lug_bv=100.,lug_t=50.8,grout_t=40.,fck=20.,shear_path='plate')
    for changes in ({'N':1e-20},{'M':1e-20},{'V':0.},{'stiffener_detail':'web_pair'},{'shear_path':'friction'}):
        actual=evaluate_component(replace(c,**changes),reactions(c))
        assert actual=={}
        summary['negative_and_domain_tests'].append({'changes':changes,'result':'not eligible, no inherited check'})
    caci=replace(c,single_key_concrete=SingleKeyConcrete(model='aci318_19_conservative'))
    no_supp=evaluate_component(caci,reactions(caci),{})
    assert no_supp['flexure_status']=='pending' and len(no_supp['states'])==2
    assert no_supp['states'][0]['status']=='pass' and no_supp['states'][1]['status']=='pending'
    summary['negative_and_domain_tests'].append({'case':'missing selected ACI state','result':'pending; native numeric result retained'})
    corrupt=reactions(c);corrupt['residual_M']=1e6
    bad=evaluate_component(c,corrupt)
    assert bad['flexure_status']=='pending' and 'utilization' not in bad
    summary['negative_and_domain_tests'].append({'case':'corrupted native moment residual','result':'pending; no numeric credit'})
    try:local_bending_values(C=100.,T_row=100.,a=200.,L=500.,lc=251.,bh=100.,tp=50.8,fy=250.)
    except ValueError:summary['negative_and_domain_tests'].append({'case':'contact crossing center','result':'rejected by bounded arithmetic kernel'})
    else:failures.append('cross-center gate did not reject')
    # A thin receiving plate is a transparent failed numeric example, independent
    # of concurrent key thickness noncompliance retained by the full evaluator.
    thin=replace(c,tp=12.7)
    failed=evaluate_component(thin,reactions(thin))
    assert failed['flexure_status']=='fail' and failed['status']=='fail'
    summary['negative_and_domain_tests'].append({'case':'thin receiving plate','result':'numeric failure retained','ratio':failed['utilization']})
    summary['source_sha256']={str(p.relative_to(SOURCE)):hashlib.sha256(p.read_bytes()).hexdigest()
        for p in [SOURCE/'lro/single_key_plate.py',SOURCE/'lro/single_key_plate_artifacts.py',SOURCE/'lro/base_plate.py']}
    summary['failures']=failures
    summary['result']='PASS' if not failures else 'FAIL'
    if len(sys.argv)>1:Path(sys.argv[1]).write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
    print(summary['result'],len(summary['comparisons']),'oracle comparisons;',len(summary['negative_and_domain_tests']),'domain/status checks')
    if failures:raise SystemExit('\n'.join(failures))

if __name__=='__main__':main()
