# Reprodução independente da placa receptora

Execute a partir da raiz do APP:

    python docs/independent_base_key_plate0942/replay.py

Opcionalmente, informe um caminho de JSON para guardar o resultado:

    python docs/independent_base_key_plate0942/replay.py resultado_base_key_plate.json

O replay primeiro regenera as dez referências com Decimal de 60 dígitos e confere identidade com tests/fixtures/single_key_plate0942_independent.json. Depois compara o runtime e executa nove fronteiras/status. O gerador não importa o runtime nem reaproveita seus números. O arquivo PROVENANCE.json identifica as fontes e os hashes.

Para a integração completa, execute os testes test_single_key_plate0942.py e test_single_key_plate0942_app.py com as dependências de desenvolvimento do projeto. O primeiro abrange 81 casos; o segundo usa o app real via Streamlit AppTest e cobre importação, sinal, mudança de domínio, navegação, espessura exibida e memória Word.

Esta evidência qualifica somente o escoamento por flexão da seção bruta ideal, dentro do domínio do método. Números favoráveis não aprovam respiros/furos não posicionados, outros cortes, ruptura, interação, distribuição transversal ou metal-base das interfaces.

## Ensaio da distribuição APP isolada

    python APP/docs/independent_base_key_plate0942/run_app_only.py APP pasta_de_resultados

O destino deve ficar fora da pasta APP. O runner lê VERSION do runtime final, regenera dez casos Decimal, confronta 120 estados por bisseção independente e emite JSON, PNG, Word completo e Word do componente para V positivo e negativo. O recibo registra os hashes exatos de app.py, lro/*.py e data/*, sem modificar esses arquivos. Usa somente as dependências de requirements.txt e os arquivos presentes no APP. As memórias produzidas devem ser renderizadas separadamente para a inspeção visual final.
