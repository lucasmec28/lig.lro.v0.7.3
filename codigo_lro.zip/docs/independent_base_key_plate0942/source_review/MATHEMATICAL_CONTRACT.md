# Receiving baseplate at a single rectangular key: finite qualification

Status before implementation: original DG1 pp. 89–90 (PDF pp. 99–100) and corrected NBR text are available and have been read. Immutable source: review0941/source0941. Work is isolated in base_transfer0942/source0942.

## What the primary source supports

DG1 Ex. 4.7-5 applies a concentrated couple at the centered shear key, neglects the column's stiffening effect, and checks the two one-sided section moments at the key:

- T is the TOTAL tension in the active row, not tension per rod.
- Mt = T a; Mc = C (L − lc)/2, with C equal to the FULL contact resultant.
- Ms = max(Mt, Mc). Do not add these one-sided moments; their sum is the applied couple for pure shear equilibrium.
- b_eff = bh; Z = bh tp² / 4. Do not multiply C by bh/B.
- NBR resistance bridge: MRd = (fy/1.10) Z. This uses the rectangular plastic strip resistance underlying the existing NBR §6.7 plate cantilever thickness equation, not AISC's 0.90 factor.

## Initial production contract

Type 1 only; native centered, solid rectangular key; shear_path=plate; no stiffeners; N=Mtop=0; V nonzero; contact and one tension row in each supported force state. Use actual applied V, preserving its sign through equilibrium. Native Mbase already includes V[tp+(H+g)/2]. If the optional ACI key component is selected, separately consume its existing limited-depth force state, retaining its own pressure and centroid. No recomputation of C/T, no second V e, no substitution of prescribed weld-development Vw/Mw for actual support reactions.

The section check is independent of the key's own lug_bending check, CJP fused min-thickness checks and Type-2 45-degree tension bands. None is duplicated or modified. Nonzero N/M, Type 2, stiffeners, multiple/active keys and other shear paths do not inherit this route.

## Qualification boundary

The code can calculate the ideal intact section's one-sided local bending demands and plastic resistance. The explicit DG1 example does not close both fillet-adjacent base-metal interfaces under the existing mixed Vw/Mw field. NBR Table 9 sends fillet base metal to §6.5; it does not say to reuse the weld-throat resultant or CJP min-section formula. Those interfaces need defined physical cuts, effective/net areas and combined local force paths.

The current input schema also does not place auxiliary grout/vent holes. A positive intact-section bending result therefore remains conditional on intact geometry; it cannot approve all reduced sections, transverse transfer from actual anchors/contact, local weld footprints, shear/flexure interaction or the complete attachment. The new component will explicitly report numerical flexure separately from pending full transfer. Missing auxiliary-hole geometry will not be invented, nor will a free-text checkbox be treated as mechanical proof.

This is useful completion of a previously absent, source-supported bending calculation, with unresolved mechanisms named rather than hidden. It is not a qualification of the whole receiving plate or base.

## Required tests

Independent published LRFD/ASD arithmetic; independent Decimal native/complementary state oracle; both V signs; scalar pass/fail and equality boundary; two rods vs total row force; full C vs bh/B reduction; no repeated V e; optional ACI missing/unsupported state stays pending; domain guards; physical anchor holes; nonfinite/overflow inputs; unchanged legacy actions/checks outside contract; stale-result refusal and app/JSON/Word correspondence.

## Final qualification clarification

The implemented limit state is gross-section flexural yielding only. Each state is limited to lc≤L/2. Overall component status remains pending after favorable yielding; rupture and full transfer are not approved. An ACI state must also carry the current source signature. App/Word thickness summaries include the new calculated requirement without changing native equilibrium data.
