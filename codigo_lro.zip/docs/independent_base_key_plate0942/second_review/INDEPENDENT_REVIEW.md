# Independent review of the receiving baseplate gross section

## Decision

SCOPED GO for the bounded source implementation. Final held-source tests:495 passed in72.45s; receipt recorded in FINAL_DECISION.json. This is a source-method and source-app review. It gives no package, deployment, installed-runtime or complete engineering-connection approval.

No remaining method, arithmetic, sign, material, state-consumption or stated-domain defect was found. The receiving plate's gross-section flexural-yielding calculation is correct within the expressly limited contract. Favorable values remain conditional; the enclosing component does not become pass.

## Evidence and exact source

The candidate is base_transfer0942/source0942, reviewed through an isolated read-only-equivalent copy under review_base_transfer0942/source_snapshot. FINAL_HOLD_BINDING.json binds it to base_transfer0942/FINAL_SOURCE_HOLD.json with SHA-256 7a8756f85d883b8dfa460c0e36bdc4cf91b335e402f47206ad30598b4da9545e. All 156 held files were verified. Source0941 was not edited; all 2,378 files in its pre-work manifest still match.

I visually inspected the actual rendered primary pages:
- DG1 third edition, printed89/PDF99: the couple at the key is resisted by two tension anchors and edge contact; column stiffening is neglected.
- DG1 printed90/PDF100: max(Trow*a, full C*(L-lc)/2), effective width equal to key width, Z=bh*tp^2/4, published LRFD/ASD values.
- Corrected NBR8800, printed105/PDF127, section6.7.2.2: rectangular plate-cantilever resistance based on fy/gamma_a1. The candidate's NBR bridge is an explicit algebraic plastic-strip resistance, not use of AISC phi0.90 under an NBR label.
- Corrected NBR printed108/PDF130, section6.7.2.4: key bending and prescribed weld Vw/Mw remain separate.
- Corrected NBR printed78/PDF100, Table9: fillet-adjacent base metal is referred to section6.5 and is not the weld-throat resistance or a CJP minimum-section check.

Primary PDF hashes are in base_transfer0942/independent_review/source_evidence_manifest.json. Rendered source pages remain there and in base_transfer0942/evidence.

## Reviewed mechanics and domain

Type1 only; native centered solid rectangular key; shear_path=plate; exact N=Mtop=0; nonzero signed actual V; no stiffeners. Nonzero N/M is excluded even at tiny magnitudes. Other shear paths, active/multiple keys and Type2 do not inherit this calculation. Each force state must show one active row, two positive anchor tensions, four rods total, valid residuals, opposing edge contact and lc<=L/2.

For each state, Trow is the sum of both active rods, C is the full contact resultant, Mt=Trow*a, Mc=C*(L-lc)/2, MSd=max(Mt,Mc), MRd=(fy,plate/1.10)*bh*tp^2/4. The sum Mt+Mc is used only as an equilibrium audit. There is no bh/B contact reduction, doubled V*e, prescribed-weld-load substitution, arbitrary width enlargement or key-material substitution.

The native and selected ACI states keep their distinct pressures, centroids and moments. Selected-but-missing or stale ACI reactions remain pending. The deep-key example retains e_native140.8mm and e_ACI110.8mm, with ratios0.528027530675582 and0.416114496261895. Reversing V mirrors contact/anchors and preserves magnitudes.

The new calculation does not repeat key bending, CJP fused sections, or Type2 tension bands. Existing native actions and geometries remain unchanged.

## Independent testing

review_numeric.py first constructs its own 60-digit Decimal bisection statics oracle, then imports candidate source for comparison. It does not use production reaction solvers or stored production values to form expected numbers. BISECTION_ORACLES.json and NUMERIC_REVIEW.json contain evidence.

- 30 varied geometries/materials/load magnitudes, both V signs, native and ACI states:120 independently solved states pass.
- Both favorable and unfavorable numerical cases are exercised:30 favorable and30 unfavorable two-state cases.
- 24 additional guards pass: receiving versus key material, exact N/M exclusion, V0, stiffeners, all alternate/active paths, absent selected ACI, own-half-plane exact boundary, no native equilibrium, stale results/JSON and the two published rounded DG1 cases.
- Candidate module tests additionally cover physical-hole intersection, nonfinite/boolean/overflow/underflow input, equality thresholds, force-state tampering, stale complementary state, JSON fidelity, diagrams, editable equations and full Word staleness.
- Actual Streamlit AppTest exercises JSON import, recalculation, sign reversal, cached-report invalidation, leaving/re-entering the domain, family/path transitions, new export availability and the required-thickness metric.
-45 legacy preset cases retain exact prior checks, geometry, component data and all outside-domain derived statuses.
-60 varied native/ACI cases retain all prior mechanics. The comparison removes only new component/check/scope data and normalizes the precisely declared in-domain boundary wording. All existing reaction components remain exact.

Final held-source pytest count and timing are in FINAL_HOLD_REVIEW.log and FINAL_HOLD_REVIEW.xml. Earlier pre-final runs were482 and483 passing tests; those are not substituted for the final receipt.

## Presentation finding corrected

The initial source-app displayed max(native thickness,new receiving-section thickness) while Word's generic required-thickness row still displayed native-only17.979mm in the deep-key case. This would understate the calculated requirement relative to the app's36.914mm.

The worker corrected the Word summary to the same maximum, left native geometry unchanged, added a conditional-scope note and separately reports the component requirement. New regressions cover the Word row and app metric. Corrected rendered page3 shows36.91/50.80mm; page13 shows the component36.91mm, both native/ACI moments, editable equations and the explicit pending boundaries. I visually checked affected pages3 and13 plus adjacent page14 of the final20-page render. No clipping or overlap was found in these reviewed pages. This review does not claim a separate whole-document visual audit of unchanged pages.

An eligibility-only sentence was also changed from claiming a calculation was performed to saying that it is handled in a separate component. This keeps equilibrium-unavailable and cross-center-contact cases truthful. ACI's in-domain boundary now acknowledges the separate gross yielding check while preserving plate_transfer_status=pending; outside-domain wording remains unchanged.

## Nonnegotiable retained limits

Known anchor holes touching/cutting x=0 get no gross-section credit. Unknown auxiliary/vent-hole geometry remains pending, even if existing narrative confirmations are filled. A favorable numerical flexure result does not clear integrity_status, transfer_status or base_metal_status, nor complete, attachment_complete or device_complete.

Physical/net sections, transverse load introduction, local interaction, rupture, both fillet-adjacent connected-base-metal interfaces, full transfer, anchorage, concrete and foundation/block scopes remain open. Required next work for interface qualification is a physical cut/area and concurrent-action model under the same prescribed weld force field. No unsupported q/t criterion or arbitrary two-area shortcut was added.

The review changes no worker code. It does not package, deploy, widen supported domains, or interfere with the separate endplate-only index patch.
