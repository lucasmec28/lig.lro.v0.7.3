"""Independent second review. Bisection statics oracle formed before production import."""
from decimal import Decimal, localcontext
from pathlib import Path
import json,sys,math,random
from dataclasses import replace
D=Decimal
HERE=Path(__file__).resolve().parent
rng=random.Random(942)
inputs=[]
for n in range(30):
    inputs.append(dict(a1=rng.choice([40,50,65]),a2=rng.choice([130,160,180]),tp=rng.choice([25.4,38.1,50.8,76.2]),V=rng.randrange(15000,350000),lug_bh=rng.choice([60,100,150]),lug_bv=rng.choice([100,140,180]),lug_t=rng.choice([20,25.4,38.1]),fck=rng.choice([20,30,40,50]),plate_steel=rng.choice(['ASTM A36','ASTM A572 Gr.50'])))
# Independent force equilibrium with a bisection solve, no production output or solver.
def expected(i,aci=False):
    with localcontext() as ctx:
        ctx.prec=60
        v={k:D(str(x)) for k,x in i.items() if k!='plate_steel'}
        L=300+4*v['a1'];B=v['a2']+2*v['a1'];a=150+v['a1'];g=D(40)
        e=v['tp']+g+min(v['lug_bv']-g,2*v['lug_t'])/2 if aci else v['tp']+(v['lug_bv']+g)/2
        p=D('.65')*D('.85')*v['fck'] if aci else D('.85')*v['fck']/D('1.4')
        q=p*B;M=v['V']*e;lo=D(0);hi=L/2
        assert q*hi*(a+L/2-hi/2)>M
        for _ in range(210):
            mid=(lo+hi)/2
            if q*mid*(a+L/2-mid/2)<M:lo=mid
            else:hi=mid
        lc=(lo+hi)/2;C=q*lc;Mt=C*a;Mc=C*(L-lc)/2;fy=D(250 if i['plate_steel']=='ASTM A36' else 345)
        Z=v['lug_bh']*v['tp']**2/4;Rd=fy*Z/D('1.1');Sd=max(Mt,Mc)
        return {k:float(x) for k,x in dict(lc_mm=lc,C_N=C,T_row_N=C,e_mm=e,Mbase_Nmm=M,M_tension_Nmm=Mt,M_contact_Nmm=Mc,M_Sd_Nmm=Sd,M_Rd_Nmm=Rd,Z_mm3=Z,fy_MPa=fy,b_eff_mm=v['lug_bh'],utilization=Sd/Rd,t_required_mm=(4*Sd*D('1.1')/(fy*v['lug_bh'])).sqrt()).items()}
oracles=[dict(input=i,native=expected(i),aci=expected(i,True)) for i in inputs]
(HERE/'BISECTION_ORACLES.json').write_text(json.dumps(oracles,indent=2))
sys.path.insert(0,str(HERE/'source_snapshot'))
from lro.models import Profile
from lro.base_plate import BasePlate,evaluate,reactions
from lro.single_key_concrete import SingleKeyConcrete
from lro.single_key_plate import local_bending_values,evaluate_component,result_is_current
from lro.single_key_plate_artifacts import json_bytes
from lro.active_shear_key import PATHS
P=Profile('Review I300','Soldado',40.,300.,150.,8.,12.,276.,7008.)
base=BasePlate(P,a1=50.,a2=130.,tp=50.8,N=0.,M=0.,V=100000.,fck=20.,grout_fck=100.,grout_t=40.,shear_path='plate',lug_bh=100.,lug_bv=100.,lug_t=50.8)
records=[];guards=[]
for n,o in enumerate(oracles):
    for sign in (-1,1):
        c=replace(base,**dict(o['input'],V=sign*o['input']['V']),single_key_concrete=SingleKeyConcrete(model='aci318_19_conservative'))
        r=evaluate(c);d=r.local_single_key_plate
        assert len(d['states'])==2,(n,r.issues,d)
        for state,oracle in zip(d['states'],[o['native'],o['aci']]):
            for k,v in oracle.items():
                if k=='Mbase_Nmm':v*=sign
                assert math.isclose(state[k],v,rel_tol=5e-12,abs_tol=1e-7),(n,k,state[k],v)
            assert state['moment_sign']==sign
            assert state['contact_x_mm']*sign>0 and state['tension_row_x_mm']*sign<0
            assert math.isclose(state['M_tension_Nmm']+state['M_contact_Nmm'],abs(state['Mbase_Nmm']),rel_tol=5e-12)
        assert d['status']!='pass' and d['integrity_status']==d['transfer_status']==d['base_metal_status']=='pending'
        assert not any(d[k] for k in ('complete','attachment_complete','device_complete'))
        payload=json.loads(json_bytes(c,r));assert payload['result']==d and payload['complete'] is False
        records.append(dict(case=n,sign=sign,ratios=[s['utilization'] for s in d['states']],flexure_status=d['flexure_status']))
# Distinguish receiving steel from key steel independently at every material change.
r=evaluate(base);v=r.local_single_key_plate['states'][0]
for key,steel,factor in [('lug_steel','ASTM A572 Gr.50',1),('plate_steel','ASTM A572 Gr.50',345/250)]:
    got=evaluate(replace(base,**{key:steel})).local_single_key_plate['states'][0]
    assert math.isclose(got['M_Rd_Nmm'],v['M_Rd_Nmm']*factor);guards.append(key)
for change in [dict(N=1e-300),dict(N=-1e-300),dict(M=1e-300),dict(M=-1e-300),dict(V=0),dict(stiffener_detail='web_pair')]+[dict(shear_path=x) for x in ('friction','anchors','external')+PATHS]:
    d=evaluate(replace(base,**change)).local_single_key_plate
    assert not d,change;guards.append(change)
# Unsupported selected ACI does not disappear or borrow native state.
c=replace(base,single_key_concrete=SingleKeyConcrete(model='unsupported'))
d=evaluate(c).local_single_key_plate
assert [s['status'] for s in d['states']]==['pass','pending'];assert d['flexure_status']=='pending'
guards.append('missing_selected_aci_state')
# Exact boundary: permissible at half plane, rejected just above.
kw=dict(C=10000.,T_row=10000.,L=500.,a=200.,lc=250.,bh=100.,tp=25.4,fy=250.)
assert local_bending_values(**kw)['M_Sd_Nmm']==2000000.
try:local_bending_values(**dict(kw,lc=math.nextafter(250.,math.inf)))
except ValueError:pass
else:raise AssertionError('cross-center accepted')
guards.append('own_half_plane_exact_boundary')
# Native equilibrium failure reports unavailable, never invents state.
c=replace(base,V=1e9);d=evaluate(c).local_single_key_plate
assert d['flexure_status']=='pending' and not any('M_Rd_Nmm' in s for s in d['states']);guards.append('no_native_equilibrium')
# Any source input change invalidates old result and export.
for change in [dict(V=-base.V),dict(tp=base.tp+1e-8),dict(lug_bh=base.lug_bh+1e-8),dict(plate_steel='ASTM A572 Gr.50'),dict(lug_steel='ASTM A572 Gr.50'),dict(N=1e-30)]:
    c=replace(base,**change);assert not result_is_current(c,r)
    try:json_bytes(c,r)
    except ValueError:pass
    else:raise AssertionError('stale JSON accepted')
    guards.append(dict(stale=change))
# Published rounded source checks directly; NBR production factor is independent.
for Ct,lc,phi,Msd,Rd in [(6.41,.0967,.9,47.8,90.),(4.10,.0930,1/1.67,30.6,100/1.67)]:
    x=local_bending_values(C=Ct,T_row=Ct,a=4.25,L=15.,lc=lc,bh=8.,tp=1.,fy=50.,gamma=1/phi)
    assert round(x['M_Sd_Nmm'],1)==Msd and math.isclose(x['M_Rd_Nmm'],Rd)
    guards.append(dict(published_Msd=Msd))
(HERE/'NUMERIC_REVIEW.json').write_text(json.dumps(dict(status='PASS',oracle_states=120,records=records,guards=guards,guard_count=len(guards)),indent=2))
print('PASS:',len(records)*2,'independent bisection states;',len(guards),'additional guards')
