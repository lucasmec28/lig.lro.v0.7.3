#!/usr/bin/env python3
"""Independent Decimal oracles for DG1 local receiving-plate bending.

Standard-library only. No production imports or calls. All source numbers enter
as decimal strings. Run from any directory; the JSON is written beside this file.
"""
from decimal import Decimal, localcontext
from pathlib import Path
import json

D = Decimal
PRECISION = 60


def calculate(*, L, B, a, pressure, moment, bh, tp, fy, gamma, sign=1, e=None):
    """Derive contact length from C=T and M=C(a+L/2-lc/2)."""
    L, B, a, pressure, moment, bh, tp, fy, gamma = map(
        D, (L, B, a, pressure, moment, bh, tp, fy, gamma))
    moment = abs(moment)
    q = pressure * B
    arm = L / 2 + a
    discriminant = arm * arm - 2 * moment / q
    lc = (2 * moment / q) / (arm + discriminant.sqrt())
    C = q * lc
    T = C
    xc = (L - lc) / 2
    mt = T * a
    mc = C * xc
    msd = max(mt, mc)
    Z = bh * tp * tp / 4
    mrd = fy * Z / gamma
    result = {
        'pressure_MPa': pressure, 'q_Npmm': q, 'L_mm': L, 'B_mm': B,
        'a_mm': a, 'lc_mm': lc, 'C_N': C, 'T_row_N': T, 'T_per_anchor_N': T/2,
        'contact_x_mm': D(sign) * xc, 'tension_row_x_mm': -D(sign) * a,
        'Mbase_Nmm': D(sign) * moment, 'M_tension_Nmm': mt,
        'M_contact_Nmm': mc, 'M_Sd_Nmm': msd, 'M_Rd_Nmm': mrd,
        'Z_mm3': Z, 'b_eff_mm': bh, 'tp_mm': tp, 'fy_MPa': fy,
        'gamma_a1': gamma, 'utilization': msd / mrd,
        't_required_mm': (4 * msd * gamma / (fy * bh)).sqrt(),
        'residual_N_N': C-T, 'residual_M_Nmm': D(sign)*(mt+mc-moment),
    }
    if e is not None:
        result['e_mm'] = D(e)
        result['Vtop_N'] = D(sign) * moment / D(e)
    return result


def case(identity, inputs, output, units, source):
    # Decimal strings are authoritative; JSON numbers ease ordinary test use.
    return {
        'id': identity, 'input': inputs, 'units': units, 'source': source,
        'expected': {k: float(v) for k, v in output.items()},
        'expected_decimal': {k: str(v) for k, v in output.items()},
        'governing_side': 'contact' if output['M_contact_Nmm'] >= output['M_tension_Nmm'] else 'tension',
    }


def make_oracles():
    cases = []
    with localcontext() as ctx:
        ctx.prec = PRECISION
        # Published source dimensions are inches; force is kip and stress ksi.
        # Output key suffixes are canonical adapter names, but units below govern.
        for identity, q, moment, gamma in [
            ('published_DG1_LRFD', '66.3', '75', D(1)/D('0.9')),
            ('published_DG1_ASD', '44.1', '48', D('1.67')),
        ]:
            inp = dict(L='15', B='15', a='4.25', pressure=str(D(q)/15),
                       moment=moment, bh='8', tp='1', fy='50', gamma=str(gamma))
            result = calculate(**inp)
            cases.append(case(identity, inp, result,
                dict(force='kip', length='in', moment='kip-in', stress='ksi'),
                'DG1 3e Ex4.7-5 printed89-90/PDF99-100. Uses source qmax rounded66.3/44.1; no extra eccentricity.'))
        # Native metric geometry requested for independent adapter testing.
        base = dict(L='500', B='230', a='200', bh='100', tp='50.8', fy='250', gamma='1.10')
        pressures = {'native_nbr_full_depth': D('.85')*20/D('1.4'),
                     'aci_limited_bearing_centroid': D('.65')*D('.85')*20}
        for geometry, H, key_t, eccentricities in [
            ('metric_short_key', '100', '50.8', dict(native_nbr_full_depth='120.8', aci_limited_bearing_centroid='120.8')),
            ('metric_deep_key', '140', '20', dict(native_nbr_full_depth='140.8', aci_limited_bearing_centroid='110.8')),
        ]:
            for state_id, pressure in pressures.items():
                for sign in (1, -1):
                    e = eccentricities[state_id]
                    moment = D('100000') * D(e)
                    inp = dict(base, pressure=str(pressure), moment=str(moment), sign=sign, e=e)
                    result = calculate(**inp)
                    stored_input = dict(inp, N='0', Mtop='0', V=str(sign*100000),
                                        column_d='300', column_bf='150', a1='50', a2='130',
                                        key_H=H, key_t=key_t, grout_t='40', fck='20', state_id=state_id)
                    cases.append(case(geometry+'_'+state_id+('_positive' if sign>0 else '_negative'),
                        stored_input,result,dict(force='N', length='mm', moment='N mm', stress='MPa'),
                        'Analytical C=T equilibrium; DG1 local moments; NBR fy/gamma_a1 resistance. Synthetic qualification case, not a design approval.'))
    return {
        'schema': 'independent_single_key_plate_oracles_v1',
        'precision_decimal_digits': PRECISION,
        'independence': 'Python standard library Decimal only. No production import, fixture, solver, or numerical output reused.',
        'output_key_note': 'Published oracle field names retain metric suffixes only to ease kernel mapping; each case units object is authoritative. Metric cases are N/mm/MPa.',
        'equations': [
            'q=p*B; K=L/2+a; lc=(2*|M|/q)/(K+sqrt(K^2-2*|M|/q))',
            'C=q*lc; Trow=C; Ft=C/2; xc=sign(M)*(L-lc)/2',
            'Mt=Trow*a; Mc=C*(L-lc)/2; MSd=max(Mt,Mc)',
            'Z=bh*tp^2/4; MRd=fy*Z/gamma; utilization=MSd/MRd',
            'Native e=tp+(H+g)/2; ACI e=tp+g+min(H-g,2*tkey)/2',
        ],
        'cases': cases,
    }


if __name__ == '__main__':
    destination = Path(__file__).resolve().with_name('single_key_plate_oracles.json')
    data = make_oracles()
    destination.write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n')
    print(destination)
    for c in data['cases']:
        r=c['expected']
        print(c['id'], 'lc=', format(r['lc_mm'], '.15g'), 'Msd=', format(r['M_Sd_Nmm'], '.15g'), 'ratio=', format(r['utilization'], '.15g'))
