# Convenção dos esforços e natureza axial · 0.9.29

Esta revisão altera somente a apresentação. O sinal já fazia parte das entradas; não há seletor adicional de natureza, novo campo nativo, adaptação de sinal, conversão de projetos, alteração de unidades ou mudança de cálculo. Digite a força no mesmo campo existente. A legenda ao lado interpreta o valor canônico atual como **Tração**, **Compressão** ou **Sem axial**, sem arredondamento nem tolerância. Valores pequenos mantêm seu sinal; zero, incluindo zero negativo, indica ausência de axial.

A figura separada **Convenção positiva dos esforços** é uma referência sem valores. Suas setas não representam o caso digitado, ações mínimas, resultados ou reações. Elas não se invertem quando a força muda de sinal. Os desenhos reais SVG/PNG e relatórios Word continuam representando exatamente o contrato anterior. Esta legenda não é indicação de atendimento nem ampliação do domínio mecânico.

## Contrato das dezesseis famílias

| Família | Natureza de N positivo | Domínio axial existente | Setas da referência |
| --- | --- | --- | --- |
| Single plate | Tração | Tração; compressão continua fora | N à direita; V para baixo como referência ilustrada |
| Alma de coluna, duas talas | Tração | Tração e compressão locais | N à direita; V para baixo |
| End plate rotulada | Tração | Tração e compressão locais | N à direita; V para baixo |
| End plate engastada 4E/4ES/8ES | Tração | Tração e compressão, com restrições de flexão dominante | N à direita; V para baixo; M horário |
| Base engastada | Compressão | Compressão e tração | N para baixo; V em +x à direita; M horário |
| Base rotulada | Compressão | Compressão e tração dentro dos estados existentes | N para baixo; V em +x à direita |
| Emenda W M004 | Tração | Tração somente | N no eixo nominal |
| Emenda W convencional | Tração | Tração e compressão | Face +x à direita: N à direita; V para cima; M anti-horário |
| Cantoneiras R016 | Não aplicável ao modelo | Cortante somente | V para baixo na viga apoiada |
| Cantoneiras R015 | Não aplicável ao modelo | Cortante somente | V para baixo na viga apoiada |
| Cantoneiras R017 | Não aplicável ao modelo | Cortante somente | V para baixo na viga recortada |
| Axial 2L parafusada | Tração total do par | Tração somente | N no eixo nominal dos parafusos |
| Axial 1L parafusada | Tração | Tração somente | N no eixo nominal dos parafusos |
| Emenda W soldada | Tração | Tração e compressão, preservando as restrições locais | Face +x de A: N em +x; V em −y; M anti-horário |
| 1L soldada à chapa de nó | Tração | Tração somente | N no eixo da cantoneira, em θ a partir de +s |
| 2L-T soldada à chapa de nó | Tração total do par | Tração somente | Um N total no eixo do par, em θ a partir de +s |

São sete famílias com ambos os ramos axiais, seis de tração e três de cortante. Na single plate, V é usado em módulo/envelope pelo cálculo existente; a seta não promete mudança de caminho de ruptura pela inversão de V. As end plates também usam módulo de V nas resistências ao corte. Nas famílias de tração, N negativo recebe o aviso “fora do domínio desta família”; nas famílias de cortante, qualquer N não nulo recebe esse aviso, sem alterar os critérios numéricos de rejeição existentes. O aviso qualitativo não substitui o diagnóstico do motor.

## Referenciais que não devem ser confundidos

- End plate: M positivo horário traciona a mesa superior; a variante superior 4E e o domínio de flexão mantêm seus bloqueios existentes.
- W convencional: M positivo traciona a mesa inferior. Na face +x, V positivo é para cima; +y aponta para a mesa superior.
- W soldada: +y aponta para a mesa inferior e V positivo corresponde a −y. Na orientação viga, N aponta à direita e V para cima; na orientação pilar, N aponta para cima e V para a esquerda. M positivo permanece anti-horário na representação. Todas as combinações usam o mesmo referencial, com natureza axial própria.
- Bases: N positivo é compressão, sem inversão de arquivos antigos. As ações referem-se à face superior da placa. O momento local da chave não é nova entrada M da base rotulada.
- Cantoneiras soldadas à chapa de nó: +s acompanha o eixo longitudinal do W; +n é normal à mesa. θ não é a inclinação global. N acompanha a inclinação atual sem imprimir seu valor. V paralelo, N normal e M da raiz são derivados. A partilha N/2 da dupla L é interna; nunca requer redigitação.
- R015/R016/R017: o único esforço externo qualificado é V. Momentos excêntricos internos não recebem uma seta de momento externo.

## Implementação e conservação

`lro/load_conventions.py` é um módulo puro para rótulos/SVG e um adaptador de renderização Streamlit sem escrita em estado. Os pontos de inserção recebem `c.N` após a reconstrução canônica do formulário e usam um espaço reservado junto às entradas. No caso de conversão inválida que interrompe a reconstrução, os erros existentes permanecem a fonte de diagnóstico; nenhuma conversão alternativa é introduzida.

O SVG contém título, descrição e rótulos acessíveis, não recebe N/V/M como argumentos e não mostra magnitudes. Somente orientação viga/pilar e θ mudam a direção geométrica da referência. Não há ações espaciais, aprovação de compressão adicional, ampliação de domínio, novo cálculo, novos mínimos ou liberação de fabricação.

A revisão AST compara todos os módulos existentes com 0.9.28 após remover somente os novos pontos de apresentação e a identificação da versão. Os dados de catálogo e arquivos entregues de 0.9.28 permanecem íntegros. O registro `VALIDATION0929.json` discrimina os testes focados e a aceitação independente efetivamente concluídos; a suíte histórica completa não é necessária nem declarada nesta alteração.
