# Verificação de software da versão 0.8.0

Data: 9 de outubro de 2026. Runtime Python 3.12.14, Streamlit 1.65.0, pandas 2.2.3, matplotlib 3.10.8 e python-docx 1.2.0. As quatro bibliotecas de execução correspondem exatamente ao requirements.txt; pytest 9.1.1 usado nos testes.

## Resultado integrado

- 310 testes pytest aprovados em 94,65 segundos: 251 anteriores, 57 do módulo de bases e dois fluxos integrados entre a base e as famílias anteriores.
- 18 cenários independentes de regressão das cinco configurações anteriores aprovados, com subcasos incluindo o JSON original da W200, falhas, entradas inválidas e rastreabilidade no Word.
- Compilação Python concluída sem erros.
- Testes de interface com Streamlit AppTest: exemplos, navegação repetida, rascunhos válidos e inválidos, campos de cortante ocultos, JSON, repetição de geração Word e invalidação após edição. Não houve inspeção visual de pixels em um navegador real.
- Word da base: seis páginas renderizadas e inspecionadas visualmente, a partir dos mesmos quatro módulos finais integrados. Os relatórios W200 e W410 com linha intermediária também foram conferidos visualmente na versão anterior, cujas equações/layouts foram preservados.

## Conferência independente da base

Nove fixtures independentes cobrem os seis regimes, o momento puro e as transições C2/C3 e T2/T3. Uma conferência adicional de equilíbrio aplicou 10.000 casos aleatórios: 9.517 soluções aceitas apresentaram resíduos inferiores a 10⁻⁵ N e 10⁻³ N·mm; 483 casos sem solução válida foram rejeitados. Isso confere equilíbrio e implementação, sem ampliar o domínio normativo do modelo.

Foram conferidos os sinais, a resistência do aço, o caminho exclusivo de V, o intervalo de concreto 20–50 MPa, a geometria Tipo 1 e as correções da Tabela 18. Os modos de ruptura de ancoragem no concreto, bloco, fundação, soldas e rigidez não receberam resistência fictícia nem aprovação global.

## Repetir

Na cópia extraída de codigo_lro.zip:

```bash
python -m pip install -r requirements-dev.txt
python -m pytest -q tests
python validation/tests/independent_regressions.py --source .
python verificar_pacote.py
```

A distribuição continua composta por quatro arquivos. O pacote é conferido pelo manifesto e por inicialização em uma extração limpa, com importação/Word da W200 e Word de placa de base. Nenhuma publicação automática ou acesso à conta Streamlit Cloud foi realizado.

Testes de software, resíduos de equilíbrio e inspeção do Word não constituem certificação estrutural, aprovação da base completa ou validação experimental de modelos extrapolados.
