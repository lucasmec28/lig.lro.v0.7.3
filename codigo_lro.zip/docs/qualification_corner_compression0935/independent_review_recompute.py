"""Independent review checks; no production or fixture-builder imports."""
import json, math, sys
from pathlib import Path
p=Path(__file__).resolve().parent
f=json.loads((p/'FIXTURE_INPUT.json').read_text()); o=json.loads((p/'ORACLE.json').read_text())
g=f['geometry']; m=f['materials']; a=f['catalog']['angle_each']; b=f['catalog']['beam']; col=f['catalog']['column']; c=f['case']
theta=math.radians(g['brace_phi_deg']); eu=(math.cos(theta),math.sin(theta)); ev=(-eu[1],eu[0]); t=g['gusset_t']; E=m['E']; fy=m['gusset']['fy']; ga=m['gamma_a1']
def xy(u,v): return [u*eu[i]+v*ev[i] for i in (0,1)]
def cross(x,y): return x[0]*y[1]-x[1]*y[0]
def near(x,y): assert math.isclose(x,y,rel_tol=1e-10,abs_tol=1e-7),(x,y)
u0,u1=g['brace_u_weld_range']; spread=(u1-u0)*math.tan(math.radians(30)); limits=[-a['ec']-spread,a['b']-a['ec']+spread]; half=min(map(abs,limits)); bw=2*half
# Intersect rays p-s*eu with x=ec and y=eb; first face hit is the smaller positive s.
def ray_length(v):
 pt=xy(u0,v)
 return min((pt[0]-g['ec'])/eu[0],(pt[1]-g['eb'])/eu[1])
# Face switch is the transverse projection of the intersection of the two faces.
v_switch=g['ec']*ev[0]+g['eb']*ev[1]
L=max(ray_length(v) for v in [-half,half,v_switch]); I=bw*t**3/12; area=bw*t; Ne=math.pi**2*E*I/L**2; lam=math.sqrt(area*fy/Ne); chi=math.exp(math.log(.658)*lam**2) if lam<=1.5 else .877/lam**2; R=chi*area*fy/ga
for key,val in [('b',bw),('A',area),('L_nominal_face_upper_envelope',L),('lambda0',lam),('chi',chi),('Nc_Rd',R)]: near(val,o['Whitmore'][key])
# Dense samples are a cross-check, not the proof: a min of two affine functions peaks at endpoint/switch.
assert max(ray_length(-half+2*half*i/10000) for i in range(10001))<=L+1e-10
B=[sum(q[i] for q in g['beam_seam'])/2 for i in (0,1)]; C=[sum(q[i] for q in g['column_seam'])/2 for i in (0,1)]; J=g['beam_joint']['point_J']
P=float(sys.argv[1]) if len(sys.argv)>1 else c['P']; F=[P*z for z in eu]; Fc_x=g['ec']*F[1]/C[1]; Fb_x=F[0]-Fc_x; Fb_y=Fb_x*g['eb']/(B[0]-g['ec']); Fc_y=F[1]-Fb_y
D=c['beam_cut']; U=c['upper_column_cut']; jointF=[D['Fx']+Fb_x,D['Fy']+Fb_y]; jointM=D['M']+cross([D['point'][i]-J[i] for i in (0,1)],[D['Fx'],D['Fy']])+cross([B[i]-J[i] for i in (0,1)],[Fb_x,Fb_y]); lowerF=[-U['Fx']-jointF[0]-Fc_x,-U['Fy']-jointF[1]-Fc_y]
ly=c['lower_column_cut_point'][1]; lowerM=-(U['M']+cross([U['point'][0],U['point'][1]-ly],[U['Fx'],U['Fy']])+jointM+cross([J[0],J[1]-ly],jointF)+cross([C[0],C[1]-ly],[Fc_x,Fc_y]))
Af=b['bf']*b['tf']; Aw=(b['d']-2*b['tf'])*b['tw']; A0=2*Af+Aw; h0=b['d']-b['tf']; ft=jointF[0]*Af/A0-jointM/h0; fb=jointF[0]*Af/A0+jointM/h0; nw=jointF[0]*Aw/A0
qt=-(U['Fx']+Fc_x+ft); qb=qt-nw
# Integrate named external force sources above a generic column cut, with no production fields.
points=[(U['point'],[U['Fx'],U['Fy']],U['M']),([g['ec'],h0/2],[ft,0.],0.),([g['ec'],-h0/2],[fb,0.],0.)]
lines=[(g['column_seam'][0][1],g['column_seam'][1][1],[Fc_x,Fc_y]),(-110.,110.,[nw,jointF[1]])]
def field(y):
 FX=FY=M=0.
 for pt,force,mom in points:
  if pt[1]>y: FX+=force[0]; FY+=force[1]; M+=mom+cross([pt[0],pt[1]-y],force)
 for y0,y1,force in lines:
  if y>=y1: continue
  low=max(y,y0); frac=(y1-low)/(y1-y0); FF=[v*frac for v in force]; FX+=FF[0]; FY+=FF[1]; M+=cross([g['ec'],(low+y1)/2-y],FF)
 return [-FX,-FY,-M]
stations=sorted({ly,U['point'][1],h0/2,-h0/2,-110.,110.,*g['column_seam'][0][1:],*g['column_seam'][1][1:]}); values=[]
for x0,x1 in zip(stations,stations[1:]):
 eps=1e-7; l=x0+eps; r=x1-eps; mid=(l+r)/2; h=(r-l)/2
 ml,mm,mr=[field(x)[2] for x in [l,mid,r]]; aa=(ml+mr-2*mm)/2; bb=(mr-ml)/2
 candidates=[l,r]
 if abs(aa)>1e-10 and -1<-bb/(2*aa)<1: candidates.append(mid+h*(-bb/(2*aa)))
 values.extend(field(y) for y in candidates)
maxN=max(abs(lowerF[1]),abs(U['Fy']),*[abs(v[1]) for v in values]); maxM=max(abs(lowerM),abs(U['M']),*[abs(v[2]) for v in values]); baseline=maxN/col['Ag']+maxM/col['Wx']; cp=g['continuity']; Lweb=cp['effective_web_weld_x'][1]-cp['effective_web_weld_x'][0]; zload=sum(cp['effective_flange_weld_z_each_positive'])/2; ecc=zload-col['tw']/2; tau_panel=max(abs(qt),abs(qb))/(col['d']*col['tw']); sigma_local=3*abs(ft)*ecc/(Lweb**2*(2*cp['web_fillet_leg'])); tau_local=abs(ft)/(Lweb*min(col['tw'],4*cp['web_fillet_leg'])); bound=baseline+sigma_local+math.sqrt(3)*(tau_local+tau_panel); eta=bound/(m['column']['fy']/ga)
near(eta,o['declared_coverage_cases']['CC2_lower_demand']['case']['concurrent_receiver']['utilization'] if P==-50000 else 1.018850578758671)
# Inner free-clip U path, independent geometry and circular chord subtraction.
clip0,clip1=g['gusset_polygon'][0],g['gusset_polygon'][-1]; uclip=sum(clip0[i]*eu[i] for i in (0,1)); vclip=sorted(sum(q[i]*ev[i] for i in (0,1)) for q in (clip0,clip1)); assert vclip[0]<-9<9<vclip[1]
cap=364.6; chord=2*math.sqrt(9**2-(370-cap)**2); Av=2*t*(cap-uclip); Ant=t*(18-chord); Rtear=min(.6*250*Av+.5*400*Ant,.6*400*Av+.5*400*Ant)/m['gamma_a2']; near(Rtear,o['bolted_reversal_witness']['inward_tangent_U_first_hole']['R'])
t3=6.; A3=bw*t3; I3=bw*t3**3/12; Ne3=math.pi**2*E*I3/L**2; lam3=math.sqrt(A3*fy/Ne3); chi3=.877/lam3**2; R3=chi3*A3*fy/ga
near(R3,o['declared_coverage_cases']['CC3_thinner_gusset']['R'])
result={'P':P,'CC3':{'thickness':t3,'slenderness':L/math.sqrt(I3/A3),'R':R3,'utilization':100000/R3},'Whitmore':{'width':bw,'L':L,'A':area,'Ne':Ne,'lambda0':lam,'chi':chi,'R':R,'slenderness':L/math.sqrt(I/area)},'root_signed':{'Hb':Fb_x,'Vb':Fb_y,'Hc':Fc_x,'Vc':Fc_y},'lower_cut':lowerF+[lowerM],'joint':jointF+[jointM],'receiver':{'baseline':baseline,'sigma_local':sigma_local,'tau_local':tau_local,'tau_panel':tau_panel,'bound':bound,'eta':eta},'inner_clip_U':{'uclip':uclip,'clip_v_range':vclip,'cap':cap,'Av':Av,'Ant':Ant,'R':Rtear},'checks':'all independent comparisons passed; no production imports or writes'}
(p/('INDEPENDENT_RECOMPUTE_CC2.json' if P==-50000 else 'INDEPENDENT_RECOMPUTE.json')).write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps(result,indent=2))
