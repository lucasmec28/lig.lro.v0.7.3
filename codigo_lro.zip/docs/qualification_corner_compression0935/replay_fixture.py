"""Portable replay of the frozen independent arithmetic, without app imports.

The original build_fixture.py is retained byte-for-byte. Only its historical
input locator is replaced in-memory. All generated files are written in a
fresh temporary directory and compared to the frozen input/oracle hashes.
"""
from contextlib import redirect_stdout
from io import StringIO
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory

HERE=Path(__file__).resolve().parent
BASE=HERE.parent/'qualification_corner0932/FIXTURE_INPUT.json'
OLD="BASE=ROOT.parent/'review0934/source0934_harness_amended/docs/qualification_corner0932/FIXTURE_INPUT.json'"
source=(HERE/'build_fixture.py').read_text()
assert source.count(OLD)==1, 'Frozen builder locator changed; do not guess a replacement.'
source=source.replace(OLD, 'BASE=Path('+repr(str(BASE))+')')
expected={name:hashlib.sha256((HERE/name).read_bytes()).hexdigest() for name in ('FIXTURE_INPUT.json','ORACLE.json')}
with TemporaryDirectory(prefix='corner_compression_replay_') as directory:
    directory=Path(directory)
    with redirect_stdout(StringIO()):
        exec(compile(source,str(HERE/'build_fixture.py'),'exec'),{'__file__':str(directory/'build_fixture.py'),'__name__':'__main__'})
    for name,digest in expected.items():
        assert hashlib.sha256((directory/name).read_bytes()).hexdigest()==digest, name+' differs from frozen evidence'
    script=directory/'independent_review_recompute.py'
    script.write_bytes((HERE/script.name).read_bytes())
    records=[]
    for arguments in ([],['-50000']):
        run=subprocess.run([sys.executable,str(script)]+arguments,check=True,text=True,capture_output=True)
        records.append(json.loads(run.stdout))
    print(json.dumps({'status':'PASS','production_imports':False,'frozen_source_writes':False,
                      'frozen_sha256':expected,'independent_cases':records},indent=2))
