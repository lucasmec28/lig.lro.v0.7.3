# Independent review: ordinary strong-axis corner compression

12 October 2026. Read-only review of the frozen 0.9.34 source and proposed bounded method. No production implementation, release, fabrication approval, or global-member approval.

## Decision

**GO to implement and test the finite static axial-compression branch for symmetric continuously welded 2L-T.** The DG29 ordinary two-edge corner equivalent-column model provides a defensible conventional method. The physical restraint/detail domain must be declared and enforced. There is no missing generic reference or automatic need for fresh FEA.

The owner's revised `COMPRESSION_CORNER_CONTRACT.md` addresses the material review qualifications below. The decision is an implementation-method decision, not acceptance of the current kernel: its compression gates are still active. Bolted compression, single angles, eccentric/spatial demands, fatigue/seismic hinges, one-root and weak-axis details remain outside this first acceptance.

## Primary sources independently inspected

All PDF page numbers are one-based.

- Supplied AISC DG29 Appendix C.1, printed 374–376 / PDF 382–384: ordinary equivalent-column model, configuration-dependent K, three-line average length, and compactness geometry. Table C-1 gives noncompact corner K=1.0 with average length. The adopted full-strip maximum is a deliberately longer implementation length, not a verbatim source equation.
- DG29 printed 377–378 / PDF 385–386: free-edge discussion is in high-cycle or low-cycle fatigue contexts. Do not turn these into an additional universal static strength prerequisite.
- DG29 printed 209 / PDF 217: explicit symmetric Whitmore reduction. The source receiver is weak-axis, so only the geometric reduction precedent is used.
- DG29 Example 5.1, printed 45 and 51 / PDF 53 and 59: strong-axis geometry and compression benchmark. The published L=9.76 in, t=1 in, K=0.5 reproduces KL/r=16.9048. Printed compression area 20.9 in² gives 940.5 kip, rounded 941; the preceding Whitmore calculation has a different area. This is a source discrepancy, not a calibration target.
- Supplied NBR 8800:2024 corrected file, printed 45–47 / PDF 67–69: 5.3.2–5.3.4 compression resistance, reduction factor and effective area; Table 4 plate-element classification.
- NBR printed 52–53 / PDF 74–75: 5.3.7 recommends slenderness not above 200; when it is exceeded, the structural engineer must establish appropriate serviceability limits. It is not an unconditional numerical prohibition.
- NBR printed 94–95 / PDF 116–117: 6.5 connection elements, normal/shear and block mechanisms. The visible duplicate `Le/r≤25` in both 6.5.4 branches is anomalous. Evaluating the full 5.3 curve for all positive lengths avoids exploiting that anomaly and avoids an unsupported yield-only shortcut.
- Official Dowswell 2006 paper, printed 91–97 / PDF 1–7: confirms the ordinary rectangular-outer-edge corner, semi-empirical Whitmore-column idealization, actual restraint sensitivity and calibration of K=1 to average length. https://ej.aisc.org/index.php/engj/article/download/877/876
- Current official AISC FAQ 5.3.6 corroborates Whitmore use for both welded and bolted attachments: https://www.aisc.org/aisc/solutions-center/engineering-faqs/5-connections/

## Independent numerical result

`check_contract.py` reads fixture input only while computing results; it imports neither owner calculation modules nor production. It solves the four UFM force-equilibrium equations from physical seam centroids, obtains the lower cut directly from global external equilibrium, and separately reconstructs the piecewise column field. The oracle is read only afterward for comparison. All 26 comparisons pass; assembly residuals are below 1e-6 N/Nmm.

| Quantity | Independent result |
|---|---:|
| Raw Whitmore interval | [-149.117059, +181.117059] mm |
| Centered retained width | 298.234118 mm |
| Retained 12 mm area | 3578.809421 mm² |
| Three nominal lengths | 276.730091, 425.847150, 283.094052 mm |
| Three-length average | 328.557098 mm |
| Full-strip nominal-face maximum | 429.029131 mm |
| CC1 Le/r; lambda0; chi | 123.850042; 1.393802671; 0.443475885 |
| CC1 gusset compression resistance | 360.708108 kN |
| CC1 gusset demand/resistance | 0.277232471 |
| CC1 root Hb,Vb,Hc,Vc | -47.712907,-24.007923,-22.997771,-46.702755 kN |
| CC1 J Fx,Fy,M | -78.423586,-74.007923,+20.000000 kN,kN,kNm |
| CC1 lower Fx,Fy,M | +91.421356,+620.710678,-103.721356 kN,kN,kNm |
| CC1 top/bottom flange | -91.957546,+39.708023 kN |
| CC1 panel top/bottom | +104.955317,+131.129379 kN |
| CC1 concurrent receiver bound | 319.548591 MPa / 313.636364 MPa = 1.018850579 |
| CC2 same-cuts -50 kN receiver ratio | 0.848249209 |
| CC3 t6 gusset resistance | 45.897911 kN |
| CC3 demand/resistance; Le/r | 2.178748408; 247.700084 |

CC1 must remain **FAIL under the conservative receiver screen** even though its gusset buckling check passes. Since the receiver expression is an upper bound, its failure is not by itself proof of actual physical yielding. The contract nevertheless cannot return PASS with that failed check. CC2 is a separate predeclared load case, not a repair of CC1. CC3 is a failure witness, not a proposed fabrication detail.

The signed -20 kN, -45 kN, zero and +45 kN assemblies were also recomputed and recorded as prospective arithmetic witnesses. Actual zero remains zero; a minimum-strength case is separately labeled and recomputes the full joint rather than replacing the actual load. Correction after checking frozen line 1043: the existing synthetic minimum was implemented only for bolted corners, not welded corners. See MINIMUM_FORCE_CLARIFICATION.md for the source-based welded 2L-T and positive 1L correction and the explicit zero-direction convention.

## Geometry, local area and modes

1. The full-strip maximum correctly includes the nominal-face switch at v=3.181981 mm. Reporting max3 as the full maximum would be false. Using the longer maximum reduces capacity relative to DG29's K1 times average length.
2. Actual stripe/brace containment, effective root intervals and perpendicular root projections must be checked. These conditions do not prove that an arbitrarily large relief is permissible. Nominal-face projection through this ordinary relief remains a geometry-specific conventional idealization. The clip itself receives no support credit. Any restraint-relevant geometry change invalidates prior detail assent.
3. The three physical restraint conditions are essential. Existing receiver `lateral_restraint` alone proves none of the complete gusset/brace boundary model. Drawn welds alone do not justify K=0.5 or compact yielding-only credit. No invented spring constant or numeric clip-size ratio is needed for the declared ordinary detail.
4. The retained Whitmore rectangle is a conventional effective solid section; its fictitious side lines are not free longitudinal edges of a real AL plate. The DG29 equivalent-column model uses A=bw*t. It is inappropriate to invent an AA or AL classification for bw/t and then claim that category comes from NBR. Physical angle legs do require local compactness: b/t=9.596977 is below the conservative AL3 limit 12.727922, so retaining their full catalog area is conservative with unknown rolled radii. Initial scope may reject slender legs rather than invent a reduction model.
5. The model supplies the ordinary gusset plate stability check. Continue supported-root combined normal/shear yielding and actual-section strength checks. Remove blanket negative-gusset-stress gates only inside this modeled direct axial domain; retain specific failures for mixed root signs, imposed couples, offsets, unsupported geometry or missing restraint.
6. Nondirectional weld and substrate shear magnitudes remain applicable after sign reversal. Tension net rupture and outward opening blocks do not become compression mechanisms through abs(P). The direction-independent shear-only uniform-run envelope can be retained with zero transverse tension credit. A reversed bolted adapter still needs its distinct bearing directions, physical exits and supported-contact-aware block family; its witness is not end-to-end qualification.
7. Keep signed receiver modes: both roots here activate web crippling, while tension-only local flange bending and normal rupture follow actual positive normal actions. Complete D/U cuts, derived lower cut, flange force signs, continuity, receiver unions and panel remain concurrent.
8. Global two-angle/member/frame stability remains explicitly outside the local connection result. There is no reason to request global unbraced length, stitch layout beyond the connection, an opposite-end model or a Robot certificate merely to compute this local branch.

## Minimum new project inputs

A geometry-bound description/status for actual out-of-plane restraint at the beam root, column root and connected brace end/overlap. Existing geometry, materials, welds and signed complete cuts provide the numerical data. If slenderness exceeds 200, the engineer's serviceability limit is additionally required for automatic acceptance. No questions to the driving user were asked.

## Remaining acceptance work

Implement the bounded adapter, sign filtering, domain predicates, geometry-bound restraint persistence and native artifact reporting; run CC1/CC2/CC3, lambda0 transition, zero length, signed minimum case, lost restraint, root/relief interference, offsets/mixed signs and excluded topology tests; then perform independent engine/output acceptance. None of those implementation tests was replaced by this method review. No frozen source or owner source was edited.

## Exact identity and narrow correction

This GO is tied to contract SHA256 `1ece7177739f6050ce7349a1eb6f27b3fe2189628296ab5b352bdf909e1bcd92`, fixture SHA256 `8baa55d87805e7331d20d04b0ea5bce7da3297e491031152707b10a896b376f4`, and oracle SHA256 `1a70ff5a7cf6a2ecf5b0df2236443b7b099ace708206e0f9a48c9b2038b7b365`, read together with MINIMUM_FORCE_CLARIFICATION.md. That addendum supersedes any claim that a welded zero/+45 kN synthetic case already existed. Source-based requirement: nonzero sub-45 kN welded 2L-T and positive welded 1L also need the minimum; the nominal +45 kN choice at zero is an explicitly adopted convention. Frozen contract, fixture and oracle remain untouched.
