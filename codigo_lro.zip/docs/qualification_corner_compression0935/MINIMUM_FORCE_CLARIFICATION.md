# Bounded correction: NBR minimum connection force

12 October 2026. This explanatory addendum corrects historical wording in the reviewed compression contract. It does not alter the frozen source, fixture or oracle.

## Source and rule

Supplied corrected NBR 8800:2024, clause 6.1.5.2, **PDF page 92 / printed page 70**, was rendered and visually inspected. For a connection with design force below 45 kN, the clause requires design for 45 kN in the direction and sense of the acting force, subject to its expressly listed exceptions. It applies to welded and bolted connections and does not distinguish a single angle from two angles.

The exceptions concern diagonals/posts of lacing in built-up members, round-bar ties, side-wall girts and roof purlins. A frame brace made from two angles is not automatically a lacing component of a built-up member; its two-angle construction alone does not invoke that exception. No such exception is established for the present ordinary frame-brace fixture.

Clause 6.1.5.3 on the same page is a separate engineer-discretionary recommendation based on member resistance. Do not silently introduce its 50% or special 100% recommendation as part of this bounded fix.

## Correct frozen implementation history

The actual frozen `lro/corner_gusset.py` line 1043 begins synthetic minimum generation with `is_bolted(c)` and `0<=c.P<45000`. Therefore 0.9.34 provides that synthetic case for its bolted corner adapters only. Welded 2L-T and welded 1L have no such case, including at zero.

The earlier wording to “retain the existing +45 kN convention at zero” is accurate only about the already implemented bolted adapter. Applying it to welded adapters is a **new corrective behavior**, not preservation of existing welded behavior. The general code requirement was not confined to bolted connections.

## Recommended bounded implementation

For a non-exempt symmetric welded 2L-T brace connection:

- 0 < P_actual < 45 kN: retain actual P and complete cuts, add P_design = +45 kN.
- -45 kN < P_actual < 0: retain actual P and complete cuts, add P_design = -45 kN.
- |P_actual| >= 45 kN: no duplicate minimum case is needed.
- P_actual = 0: preserve actual zero. NBR does not determine a direction/sense for a zero force. A separately labeled +45 kN case along the explicitly modeled nominal +u tensile direction is an acceptable declared implementation convention, consistent with the previously adopted bolted convention. Call it a convention; do not claim the standard selected a positive sign or that it proves the negative-direction minimum. Do not infer -45 solely because the adapter is now compression-capable.

Apply 45 kN once to the total brace connection, then divide among two physical angles/welds. Keep the specified D/U cuts and other loads as explicit background for the synthetic design-strength case; recompute both roots, J, derived lower cut, flange actions, continuity, shared receivers and panel. Envelope actual and synthetic component results with their own provenance. The synthetic lower cut is not actual or Robot-derived. NBR does not prescribe this as a real frame-analysis combination; it is the declared full-load-path implementation of the local minimum-strength requirement.

**Positive welded 1L has the same minimum requirement.** The clean bounded correction is to add its +45 kN synthetic case for 0 < P < 45 kN, with the same explicit zero convention if used. This requires no negative-1L compression qualification. If implementation is deliberately deferred, low-force welded 1L needs a specific unresolved minimum-strength check; a PASS that silently ignores the clause is not justified. Do not describe a deferred software scope as a normative exemption.

Test welded 2L at -45, just above -45, -20, zero, +20, just below +45 and +45 kN, plus positive welded 1L at +20 and +45 kN. Verify actual cuts remain unchanged and each synthetic result records its signed P and recomputed lower cut.

## Exact reviewed identities

The method GO is tied to these exact frozen inputs, **read together with this addendum**:

- COMPRESSION_CORNER_CONTRACT.md: `1ece7177739f6050ce7349a1eb6f27b3fe2189628296ab5b352bdf909e1bcd92`
- FIXTURE_INPUT.json: `8baa55d87805e7331d20d04b0ea5bce7da3297e491031152707b10a896b376f4`
- ORACLE.json: `1a70ff5a7cf6a2ecf5b0df2236443b7b099ace708206e0f9a48c9b2038b7b365`

The fixture/oracle numeric witnesses were not changed. The +45 and -45 values in the oracle are separately constructed prospective witnesses, not evidence that a welded runtime minimum was already implemented. Production GO still requires implementation and independent acceptance of the new branches.
