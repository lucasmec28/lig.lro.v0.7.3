"""Independent bounded compression qualification, stdlib only; no app imports."""
import json, math
from pathlib import Path
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent/'review0934/source0934_harness_amended/docs/qualification_corner0932/FIXTURE_INPUT.json'
f=json.loads(BASE.read_text())
f['status']='INDEPENDENT_COMPRESSION_SCOPE_FIXTURE_NOT_PRODUCTION_OR_PROJECT_APPROVAL'
f['assumptions'][0]='Static axial compression, identical symmetric continuously welded T-2L; local connection qualification only'
f['case']['id']='CC1_WELDED_2LT_COMPRESSION_COMPLETE'
f['case']['P']=-100000.
f['case'].pop('lower_column_cut_verification',None)
f['case'].pop('independent_conversion_witness',None)
f['compression_contract']={
 'topology':'symmetric 2L-T, each face continuously heel/toe welded; no spacers',
 'support_model':'ordinary two-edge restrained corner, small inner relief retained; receiver faces are nominal reference lines, not a point support at relief',
 'restraint_beam_root':'out-of-plane translation and rotation restrained by actual connected beam/frame system',
 'restraint_column_root':'out-of-plane translation and rotation restrained by actual connected column/frame system',
 'restraint_brace_attachment':'relative out-of-plane sway and rotation restrained over attached brace overlap; this declaration does not prove global brace stability',
 'geometry_checks':'entire selected compression stripe perpendicular projections lie inside both actual effective root seams; brace overlap and stripe contained; small root relief has no support credit',
 'boundary_declaration_scope':'current actual CC1 relief/root layout only; geometry changes cannot inherit a previous boundary qualification; projected feet alone do not authorize arbitrary enlarged clips',
 'Whitmore':'symmetrically trim to smaller side about nominal force axis; full abs(P) on that stripe',
 'length':'use support-side start of load-transfer weld, conservatively beyond actual angle end; upper envelope of published brace-parallel lengths over selected stripe',
 'K':1.,'compact_yield_only_credit':False,'short_column_exemption_credit':False,
 'brace_global_stability':'outside local connection module; supplied design axial force comes from structural design, no member unbraced length inferred',
 'factor_basis':'NBR8800:2024 5.3.2/5.3.3 and 6.5.4; DG29 Appendix C geometry/mode model, no mixed LRFD factors'}
(ROOT/'FIXTURE_INPUT.json').write_text(json.dumps(f,indent=2,ensure_ascii=False)+'\n')
g=f['geometry']; cat=f['catalog']; m=f['materials']; c=f['case']; E=m['E']; ga=m['gamma_a1']; ga2=m['gamma_a2']; fy=m['gusset']['fy']; tg=g['gusset_t']; co=si=math.sqrt(.5)
a=cat['angle_each']; b=cat['beam']; col=cat['column']; eb=g['eb']; ec=g['ec']; u0,u1=g['brace_u_weld_range']; Lw=u1-u0
left=-a['ec']-Lw/math.sqrt(3); right=a['b']-a['ec']+Lw/math.sqrt(3)
half=min(-left,right); vmin,vmax=-half,half; width=2*half
# For a stripe at constant u0, first nominal supporting face hit travelling -u.
def nominal_length(v):
 ub=(eb-v*co)/si; uc=(ec+v*si)/co
 return max(0.,u0-max(ub,uc))
vs=[vmin,0.,vmax]; v_switch=eb*co-ec*si
if vmin<=v_switch<=vmax:vs.append(v_switch)
lengths=[nominal_length(v) for v in vs]; L=max(lengths); r=tg/math.sqrt(12); slender=L/r; lam=slender*math.sqrt(fy/(math.pi**2*E)); chi=.658**(lam**2) if lam<=1.5 else .877/lam**2
A=width*tg; R=chi*A*fy/ga
feet=[]
for v in (vmin,vmax):
 x=u0*co-v*si; y=u0*si+v*co
 feet.append({'v':v,'beam_foot':[x,eb],'beam_inside_weld':g['beam_seam'][0][0]<=x<=g['beam_seam'][1][0], 'column_foot':[ec,y],'column_inside_weld':g['column_seam'][0][1]<=y<=g['column_seam'][1][1]})

def case(P):
 H=P*co; V=P*si; Hc=ec*V/(eb+g['beta']); Hb=H-Hc; Vb=eb*Hb/g['alpha']; Vc=V-Vb
 D=c['beam_cut']; U=c['upper_column_cut']; xj=ec
 Jx=D['Fx']+Hb; Jy=D['Fy']+Vb
 Jm=D['M']+(D['point'][0]-xj)*D['Fy']-D['point'][1]*D['Fx']+g['alpha']*Vb-eb*Hb
 Lx=-(U['Fx']+Jx+Hc); Ly=-(U['Fy']+Jy+Vc)
 ly=c['lower_column_cut_point'][1]
 Lm=-(U['M']+U['point'][0]*U['Fy']-(U['point'][1]-ly)*U['Fx']+Jm+xj*Jy+ly*Jx+ec*Vc-(eb+g['beta']-ly)*Hc)
 Af=b['bf']*b['tf']; Aw=(b['d']-2*b['tf'])*b['tw']; A0=2*Af+Aw; h0=b['d']-b['tf']; Nw=Jx*Aw/A0; Ft=Jx*Af/A0-Jm/h0; Fb=Jx*Af/A0+Jm/h0
 Qtop=-(U['Fx']+Hc+Ft); Qbottom=Qtop-Nw
 roots={}
 for name,normal,shear,mem,interior in [('beam',Vb,Hb,b,False),('column',Hc,Vc,col,True)]:
  ends=g[name+'_seam']; length=math.dist(*ends); q=math.hypot(normal,shear)/length; ratio=length/mem['d']; mult=3*ratio if interior or ratio<=.2 else 4*ratio-.2
  crip=(.66 if interior else .33)*mem['tw']**2*(1+mult*(mem['tw']/mem['tf'])**1.5)*math.sqrt(E*m[name]['fy']*mem['tf']/mem['tw'])/ga
  roots[name]={'signed_normal':normal,'signed_shear':shear,'length':length,'weld_line_demand':1.25*q,'weld_line_resistance':2*g['root_fillet_leg']/math.sqrt(2)*.6*m['weld']['fw']/m['gamma_w2'],'receiver_web_crippling_resistance':crip,'compression_mode_active':normal<0}
 # Independent column free-body field. Fit its exact quadratic moment on
 # each load-station interval using three values, then test vertex/endpoints.
 ytop=(b['d']-b['tf'])/2; wl=220.; sy0,sy1=[p[1] for p in g['column_seam']]
 def field(y,branch_y):
  xx=U['Fx']; yy=U['Fy']; mm=U['M']- (U['point'][1]-y)*U['Fx']
  for py,px in [(ytop,Ft),(-ytop,Fb)]:
   if py>branch_y:xx+=px;mm-=(py-y)*px
  for low,high,fx,fyline in [(sy0,sy1,Hc,Vc),(-wl/2,wl/2,Nw,Jy)]:
   frac=1. if branch_y<=low else 0. if branch_y>=high else (high-y)/(high-low)
   yc=(low+high)/2 if branch_y<=low else (high+y)/2
   xx+=frac*fx; yy+=frac*fyline; mm+=ec*frac*fyline-(yc-y)*frac*fx
  return -xx,-yy,-mm
 stations=sorted(set([ly,U['point'][1],sy0,sy1,-wl/2,wl/2,-ytop,ytop])); fields=[]
 for lo,hi in zip(stations,stations[1:]):
  mid=(lo+hi)/2; halfspan=(hi-lo)/2
  p0,p1,p2=[field(y,mid) for y in (lo,mid,hi)]; fields.extend([p0,p2])
  aa=(p0[2]+p2[2])/2-p1[2]; bb=(p2[2]-p0[2])/2
  if abs(aa)>1e-8:
   z=-bb/(2*aa)
   if -1<z<1:fields.append(field(mid+z*halfspan,mid))
 Nmax=max([abs(U['Fy']),abs(Ly)]+[abs(z[1]) for z in fields]); Mmax=max([abs(U['M']),abs(Lm)]+[abs(z[2]) for z in fields])
 baseline=Nmax/col['Ag']+Mmax/col['Wx']; panel_tau=max(abs(Qtop),abs(Qbottom))/(col['d']*col['tw'])
 cp=g['continuity']; cpL=cp['effective_web_weld_x'][1]-cp['effective_web_weld_x'][0]; cpE=sum(cp['effective_flange_weld_z_each_positive'])/2-col['tw']/2; weld=cp['web_fillet_leg']
 local_normal=3*abs(Ft)*cpE/(cpL**2*(2*weld));local_shear=abs(Ft)/(cpL*min(col['tw'],4*weld)); bound=baseline+local_normal+math.sqrt(3)*(local_shear+panel_tau)
 receiver={'Nmax':Nmax,'Mmax':Mmax,'baseline_normal':baseline,'panel_tau':panel_tau,'local_normal':local_normal,'local_shear':local_shear,'top_concurrent_bound':bound,'resistance':m['column']['fy']/ga,'utilization':bound/(m['column']['fy']/ga)}
 residual=[D['Fx']+U['Fx']+Lx+H,D['Fy']+U['Fy']+Ly+V,D['M']+D['point'][0]*D['Fy']-D['point'][1]*D['Fx']+U['M']+U['point'][0]*U['Fy']-U['point'][1]*U['Fx']+Lm-ly*Lx]
 return {'P':P,'H':H,'V':V,'Hb':Hb,'Vb':Vb,'Hc':Hc,'Vc':Vc,'J':[Jx,Jy,Jm],'lower_cut':[Lx,Ly,Lm],'Ftop':Ft,'Fbottom':Fb,'Nweb':Nw,'Qtop':Qtop,'Qbottom':Qbottom,'roots':roots,'concurrent_receiver':receiver,'assembly_residual':residual}
main=case(c['P'])
# Per-face distributed weld/substrate forces reverse; magnitudes do not.
q_weld=g['brace_fillet_leg']/math.sqrt(2)*.6*m['weld']['fw']/m['gamma_w2']
brace={'angle_b_over_t':a['b']/a['t'],'conservative_AL3_limit':.45*math.sqrt(E/m['angle']['fy']),'per_angle_local_gross_compression_resistance':a['Ag']*m['angle']['fy']/ga,'angle_each_demand':abs(c['P'])/2,
 'gusset_uniform_partial_weld_run_shear_envelope':.6*fy*tg*Lw/ga2,
 'angle_uniform_partial_weld_run_shear_envelope':.6*m['angle']['fy']*a['t']*Lw/ga2}
for tag,frac in [('heel',1-a['ec']/a['b']),('toe',a['ec']/a['b'])]:
 brace[tag]={'signed_each_face_force':c['P']/2*frac,'weld_resistance_each':q_weld*Lw}
# Reversed-bolted direction witness, independent BC1 geometry only; not a complete bolted qualification.
bs=[370.,430.,490.,550.]; dh=18.; dn=18.; ubare=(ec+eb+30)/math.sqrt(2); uouter=min((ec+300)/co,(eb+300)/si)
reversed_bearing=[]
for j,u in enumerate(bs):
 lc_g=bs[j]-bs[j-1]-dh if j else u-ubare-dh/2
 lc_a=(bs[j+1]-u-dh) if j<len(bs)-1 else None
 rg=min(1.2*lc_g*12*400,2.4*16*12*400)/ga2
 ra=2.4*16*a['t']*400/ga2 if lc_a is None else min(1.2*lc_a*a['t']*400,2.4*16*a['t']*400)/ga2
 reversed_bearing.append({'hole':j+1,'gusset_force_direction':'-u','gusset_lc':lc_g,'gusset_R':rg,'angle_force_direction':'+u','angle_lc':lc_a,'angle_unbounded_member_continuation':lc_a is None,'angle_R':ra})
# A compression force CAN tear toward the inner free clip. Tangent U strip ±9 has zero supported-edge contact in BC1.
x=-5.4; cap=bs[0]+x; halfchord=math.sqrt((dn/2)**2-x*x); Av=2*12*(cap-ubare); Ant=12*(dn-2*halfchord); Ry=(.6*250*Av+.5*400*Ant)/ga2; Rr=(.6*400*Av+.5*400*Ant)/ga2
reversal={'warning':'direction/one-path numerical witness only; do not label complete bolted compression GO','bearing':reversed_bearing,'inner_clip_u':ubare,'inward_tangent_U_first_hole':{'cap_u':cap,'x':x,'Agv':Av,'Anv':Av,'Ant':Ant,'Ryield':Ry,'Rrupture':Rr,'demand_conservative_included_hole':25000.,'R':min(Ry,Rr),'utilization':25000/min(Ry,Rr)},'angle_free_tip_tension_blocks':'inactive for this compression direction; do not reuse abs(P) tension blocks'}
result={'status':'FINITE_LOCAL_COMPRESSION_METHOD_AND_FIXTURES_NOT_IMPLEMENTED','units':'N mm MPa Nmm','Whitmore':{'raw_v_range':[left,right],'centered_v_range':[vmin,vmax],'b':width,'A':A,'r':r,'length_candidates':[{'v':v,'L':ll} for v,ll in zip(vs,lengths)],'L_nominal_face_upper_envelope':L,'K':1.,'Le':L,'slenderness':slender,'lambda0':lam,'chi':chi,'Nc_Rd':R,'demand':abs(c['P']),'utilization':abs(c['P'])/R,'root_projection_checks':feet},'brace_end_local':brace,'main_case':main,'signed_minimum_witness':{'actual':case(-20000),'synthetic':case(-45000),'zero_actual_unchanged':case(0),'zero_existing_positive_minimum':case(45000)},'bolted_reversal_witness':reversal,'published_DG29_Ex5_1_replay':{'t_in':1.,'L_in':9.76,'K':.5,'KL_over_r':.5*9.76/(1/math.sqrt(12)),'reported_KL_over_r':16.9,'printed_compression_Ag_in2':20.9,'LRFD_kip':.9*50*20.9,'reported_LRFD_kip':941,'note':'Guide printed compression Ag20.9 differs from previous Whitmore Aw21.5; retained source discrepancy, not calibration input.'}}
thin=6.; thin_r=thin/math.sqrt(12); thin_lambda=L/thin_r*math.sqrt(fy/(math.pi**2*E)); thin_chi=.658**(thin_lambda**2) if thin_lambda<=1.5 else .877/thin_lambda**2; thin_R=thin_chi*width*thin*fy/ga
result['declared_coverage_cases']={
 'CC2_lower_demand':{'description':'Single predeclared lower-demand verification case, same explicitly retained complete D/U cuts and all geometry; not an optimization of CC1.','case':case(-50000.),'beam_cut':c['beam_cut'],'upper_column_cut':c['upper_column_cut'],'gusset_compression_R':R,'gusset_utilization':50000/R},
 'CC3_thinner_gusset':{'description':'Single predeclared adverse plate-thickness witness, original P−100kN and complete cuts, t6mm; not proposed project resizing.','t':thin,'r':thin_r,'Le_over_r':L/thin_r,'NBR_5_3_7_serviceability_flag':'greater than recommended200; requires project-specific service limits and is outside conservative automatic <=200 gate, not an absolute code prohibition','lambda0':thin_lambda,'chi':thin_chi,'R':thin_R,'demand':100000.,'utilization':100000/thin_R,'other_geometry_and_cuts':'identical to CC1 except gusset thickness; all root/assembly detailing must still be evaluated'}}
(ROOT/'ORACLE.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
assert all(z['beam_inside_weld'] and z['column_inside_weld'] for z in feet)
assert max(map(abs,main['assembly_residual']))<1e-6
assert 0<chi<1 and abs(c['P'])/R<1
print(json.dumps({k:result[k] for k in ('Whitmore','main_case','bolted_reversal_witness')},indent=2))
