# Independent bounded compression-method review

Date: 2026-10-12. Scope: one independent review of the proposed local method and numerical fixtures. Production `review0934/source0934_harness_amended/lro/corner_gusset.py` was inspected read-only; no production changes or project approval are made.

## Decision

**GO for implementation of the declared static, symmetric, continuously heel/toe-welded 2L-T, strong-axis two-root local connection route, subject to the explicit scope guards below.** No additional essential local compression mode was identified that requires abandoning this finite conventional model or making new continuum/FEA research a prerequisite. This is a method decision, not a PASS for CC1: **CC1 remains a strength FAIL at the concurrent column receiver, utilization 1.018850579.** Bolted compression remains **NOT GO** from this review.

Reviewed inputs: newly completed `COMPRESSION_CORNER_CONTRACT.md`, `source_reading/CORNER_COMPRESSION_SOURCES.md`, `build_fixture.py`, `FIXTURE_INPUT.json`, `ORACLE.json`, relevant existing production geometry/force/local-resistance/aggregation code, and supplied NBR page images/text. The inherited tensile assumption in the fixture was reported and has been corrected to static axial compression.

## Why the finite method is supportable

- DG29 Appendix C supplies an equivalent Whitmore column for an ordinary restrained corner. K=1 with the maximum nominal-face distance across the entire retained strip is a conservative implementation of the noncompact K=1 / three-line-average model. It is not quoted as the guide's literal length prescription. Including the support-line switch is essential: three sampled lines alone miss C1's actual maximum by 3.181981 mm.
- Symmetric reduction about the force axis puts the full axial load on a smaller concentric strip. It takes no strength credit from the discarded side. K=0.5, compact-yield-only credit and the short-column exemption are unnecessary for this GO.
- NBR 5.3 supplies the resistance curve and factors; DG29 supplies the local gusset model and geometry. This is an explicitly identified combined design basis, not an exact AISC LRFD result.
- The angle check is a **local attached-end** check. Using the full nominal b/t with the stricter AL3 limit is conservative relative to AL4 for continuously connected angles. Each angle has b/t=9.596977 <12.727922 and gross yielding resistance 260.909091 kN against 50 kN. Continuous heel/toe attachment, actual restraint and the ordinary static angle-end idealization remain necessary. Supplied NBR 6.1.8.2 (PDF93/printed71) expressly includes single/double angles and fillet-weld groups under static axial loading; it does not establish global brace stability.
- Reverse-signed root normal forces correctly activate beam/column receiver compression branches. Existing root interaction, weld/base/contact checks, local receiver yielding/crippling, continuity compression/stability, common receiver interactions and panel actions remain active. The new gusset check cannot replace them.
- Uniform longitudinal weld/associated substrate checks and the conservative partial-path shear envelopes can cover the selected hole-free welded load-transfer family in either direction. Tension-only outer-edge block labels cannot be claimed as an inward-compression qualification merely by applying abs(P). The associated path/envelope applicability must stay explicit.

The ordinary DG29 equivalent-column model is the stability model for the selected gusset; a second invented free-strip plate model is not automatically required. Likewise, separate global two-angle flexural/flexural-torsional and built-up-member stability cannot be inferred from this local result and stays outside scope.

## Essential implementation guards

1. Require actual out-of-plane root and brace-end restraint declarations, not merely the existing receiver `lateral_restraint` flag. Require the retained strip and brace footprint to be contained and every strip's perpendicular projections to fall in the **actual effective** continuous root seams.
2. Treat the 30 mm inner relief as free, never as a point support. Nominal member faces are reference lines of the conventional corner idealization. Projection checks alone do not bound the severity of a larger relief or remote root setbacks. Bind automatic approval to the declared ordinary-detail domain; materially different reliefs/root layouts require their own engineered boundary model. A larger K cannot manufacture absent support.
3. Keep nonzero work-point offset, one-root/weak-axis/asymmetric/spaced/intermittently attached topologies, imposed out-of-plane actions, and seismic/fatigue behavior outside this increment. Do not remove compression warnings globally for unrelated cases or adapters.
4. Preserve signed actual COMPLETE_CUTS actions, lower-cut equilibrium and background D/U actions. Any minimum-strength companion case is synthetic, separately labeled and sign-preserving; it must not rewrite the actual combination. Zero-P behavior needs its own explicit convention.
5. A passing new gusset row does not erase any receiver/detail failure. Distinguish qualified method, computed resistance, missing applicability and overall assembly status.
6. NBR 5.3.7.1 recommends member slenderness no greater than 200; 5.3.7.2 permits project-responsible service-behavior limits when exceeded. A conservative automatic ≤200 gate is defensible, but do not label 200 an unconditional code prohibition. CC1 has 123.850042; CC3 t6 has 247.700084 and needs that domain/service qualification in addition to its strength failure.

## Independent numerical checks

`independent_review_recompute.py` imports neither production nor the fixture builder. It derives ray/member-face intersections in physical coordinates, independently integrates column-cut actions, and recomputes the hole/clip geometry. Executed successfully for CC1 and CC2; results are in `INDEPENDENT_RECOMPUTE.json` and `INDEPENDENT_RECOMPUTE_CC2.json`. Both runs also independently recompute CC3 thickness resistance.

| Quantity | Independent result |
|---|---:|
| Symmetric Whitmore width / area | 298.234118 mm / 3578.809421 mm² |
| Full-strip maximum L, at v=3.181981 mm | 429.029131 mm |
| Euler load / reduced slenderness | 460549.161462 N / 1.393802671 |
| χ / gusset Nc,Rd | 0.443475885 / 360708.108198 N |
| Gusset utilization, P=−100 kN | 0.277232471 |
| Beam root Hb / Vb | −47712.907411 / −24007.923253 N |
| Column root Hc / Vc | −22997.770708 / −46702.754866 N |
| Lower cut Fx / Fy / M | 91421.356237 N / 620710.678119 N / −103721356.237310 Nmm |
| Concurrent receiver baseline / local normal | 121.899584 / 45.516285 MPa |
| Local shear / panel shear | 44.829349 / 43.004519 MPa |
| Receiver bound / resistance / utilization | 319.548591 / 313.636364 MPa / **1.018850579** |

The declared CC2 lower-force and CC3 thinner-plate cases are coverage witnesses, not an iterative attempt to resize CC1 into a pass. The independent recomputations give CC2 gusset utilization 0.138616235 and receiver utilization 0.848249209; CC3 gusset resistance 45897.910750 N and utilization 2.178748408. CC3's associated changed thickness/detail/applicability checks must also remain visible.

## Bolted reversal witness

The direction arithmetic is correct for the stated witness: gusset bearing acts toward −u and angle bearing toward +u. The first gusset clear distance is 118.815927 mm; subsequent inter-hole clear distances are 42 mm. The last angle hole has continuing member material toward +u, not the free-tip edge used in tension. These happen to reach the capped bearing resistance here; equal final capacities do not prove the direction bookkeeping is unnecessary.

The inner free clip is u=242.184073 mm and extends over v=[−18.031223,+24.395184] mm. Thus the U strip v=±9 mm reaches an actual free clip and does not terminate on either supported root. At cap u=364.6 mm, the circle chord subtraction gives Agv=Anv=2937.982259 mm² and Ant=43.2 mm². The two resistances are 332842.473183 N and 528707.957093 N; the former controls. Counting the full 25 kN first-hole force when the cap intersects its hole is conservative for this witness. This is one inward path, not an exhaustive bolted compression qualification.

## Source cautions

The supplied NBR PDF116–117/printed94–95 visually prints Le/r ≤25 in both 6.5.4(a) and 6.5.4(b). Record this apparent threshold inconsistency rather than silently changing the quotation. The selected always-evaluate-5.3 χ branch avoids taking favorable short-column credit.

DG29 Example 5.1's printed compression Ag=20.9 in² gives 940.5 kips, displayed as 941; KL/r=16.904816 reproduces 16.9. Its prior tensile effective-area expression gives 21.5205 in². Preserve that source discrepancy rather than fitting a single geometry output to both.

Official model cross-check: [Dowswell, 2006, Effective Length Factors for Gusset Plate Buckling](https://ej.aisc.org/index.php/engj/article/download/877/876), especially corner definitions, effective-width/column model and Table 7. The supplied DG29 Appendix C remains the controlling geometry reference for this deliverable.
