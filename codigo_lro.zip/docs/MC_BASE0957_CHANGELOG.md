# Revisão 0.9.57 — apresentação e entradas

Escopo: melhorias de apresentação Word, entradas avançadas e geometria de desenho. A revisão não amplia o domínio normativo dos cálculos e não implementa nova otimização estrutural/concreto.

## Pendências encaminhadas para auditoria posterior
- Busca limitada de requisitos mínimos de concreto: qualificar montagem enterrada, definir objetivo e candidatos fabricáveis; não substituir dados reais por valores que artificialmente passam.
- A1(e): flexão/caminho de carga da chapa de topo ainda sem modelo validado aplicável à geometria. Contato F/A isolado não fecha a chapa.
- Revisar testes históricos dev.2 do apoio direto: 26 falhas repetem-se na 0.9.56 e na 0.9.57 antes das alterações finais, devido a expectativas antigas de status/domínio. Não foram ocultadas nem usadas para declarar aprovação.
- Prosseguir auditoria individual do catálogo, com prioridade para pendências de cálculo reais, coerência das figuras e exportações, sem estabilidade global indevidamente incluída no cálculo da ligação.
- Melhorias do app de combinações exigem sua própria base de código; não incluídas neste pacote de ligações.

## Evidência
Resultados de cálculo dos 28 exemplos de seis famílias comparados com .56: iguais, desconsiderando apenas assinaturas de entrada que incluem o novo parâmetro de desenho. Testes focados, desenhos e Word são conferidos durante a integração. O resultado final e contagens são registrados na entrega; testes de software não substituem validação técnica do projeto.
