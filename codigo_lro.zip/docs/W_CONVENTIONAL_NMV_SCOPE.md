# Emenda W convencional paramétrica com N/M/V

Componente separado: `w_splice_conventional_nmv`, versão `0.9.5-w-conventional-dev`.
Esta integração de desenvolvimento não foi publicada. Projetos M004 axiais antigos preservam seu identificador, versão, partilha e avaliações originais.

## Modelo de forças e domínio

Oito talas físicas: duas externas, quatro tiras internas e duas de alma. Perfis W laminados idênticos, constantes e coaxiais; ações últimas normais estáticas no eixo principal. N positivo traciona. O modelo convencional atribui integralmente N e M às mesas: Fsuperior=N/2−M/(d−tf), Finferior=N/2+M/(d−tf). A alma recebe somente V e sua excentricidade geométrica, com Nw=Mw(0)=0. Especialização atual de partilha igual, não exigência universal NBR: bo=2bi, mesma espessura/material; cada externa recebe F/2 e cada tira F/4. As extremidades são verificadas em série, nunca somadas. Sem contato de topo, calços participantes, rasgos, recortes, torção, flexão menor ou hipótese de inércia-caixão entre talas.

Perfis, espessuras, larguras, passos, bordas, folga e parafusos variam. A malha da alma continua regular 2×3 por extremidade. A admissão calcula geometria, acessos, detalhamento, produto/material, pega, comprimento de ligação e os testes adimensionais do modelo escalar. Não há filtro por nome W310 nem dimensões fixas do exemplo.

Para a=pweb/2, b=folga/2+emembro e e=b+a, J=6a²+4g². Com V ativo, exige e·a/J≤1/6 e resultante de todo subconjunto contíguo de colunas/prefixo vertical por tala≤|V|/2. A falha dessa correspondência deixa especificamente o bloco escalar pendente; os vetores, contato, compressão e demais resultados calculáveis permanecem. Quando V=0, nenhuma pendência hipotética de força da alma impede o caso de N/M.

## Verificações implementadas

- Equilíbrio assinado dos grupos completos, das duas talas e dos cortes imediatamente antes/depois de cada estação; momento real de corte separado do momento de grupo Ve/2. Envelope resistente=max(Ve/2, |Mcorte|max).
- Cada plano físico de corte de cada parafuso; cada furo de cada peça. Contato/rasgamento usa o vetor real e a distância até borda/furo real. Tela adicional conservadora soma |qx|/Rx+|qy|/Ry. Bordas da tala não são inventadas como bordas livres da alma contínua do membro.
- Talas tracionadas: seção bruta, Ae=min(An;0,85Ag), blocos L/U de cada prefixo e cada tira real. Mesas do membro: resistências locais e blocos de balanços livres admissíveis; nenhuma afirmação Ct=1 da seção W inteira.
- Talas comprimidas independentes: vão máximo entre linhas portantes, K=1, dois eixos de Euler, limite torsional conservador GJ/r0², χ com Ag no índice reduzido, Aef atual da 5.3.4/tabelas4–5. Atalho bruto da6.5.4(a) somente com Le/r≤25, elementos locais não esbeltos e limite torsional≥Agfy; outros casos usam5.3. Não se usa Q antigo, K=.65 ou vão igual apenas à folga de topo.
- Cada tala da alma: corte bruto/líquido, FLT retangular atual do anexoD, ruptura por flexão líquida, interação elástica bruta e tela líquida linear adicional explicitamente não normativa. An/Inet/Znet resultam da integral das partes remanescentes, incluindo a dedução do furo que atravessa o eixo plástico.
- Todos os84caminhos reais L/U por tala, ambas bordas verticais, todos os prefixos e caminhos que atravessam a emenda. Cts=.5 e demanda integral|V|/2. Pontes menores que o passo não são rejeitadas por conveniência de enumeração.
- Alma do membro: corte bruto/líquido e instabilidade por cisalhamento. Mesas do membro: limites locais de tração/compressão, seção efetiva local com b=bf/2 e Aef=2 beff tf (5.1.2.2.4(a), sem duplicar faixa central) e limite dos furos da5.4.2.6 com Yt correto e γa1. A solicitação do membro conserva M(x)=M(0)−Vx até a última fila das mesas/alma.

## Condições externas e estados

A prescrição de apoio é um detalhe físico: dois membros presentes e contidos, todas as filas/parafusos/porcas/arruelas, contato firme nas sobreposições e nenhuma tira solta ou etapa de montagem isolada. Escolher outro detalhe conserva resultados condicionais e impede aprovação.

A política da6.1.5.3 fica pendente até ser escolhida: fornecer um envelope recomendado separado, ou registrar a decisão do responsável de usar as ações de projeto sem adotar a recomendação discricionária de50%/100%. A segunda opção emite advertência e não exige capacidades externas. O piso obrigatório da6.1.5.2 é avaliado em caso suplementar: para0<hypot(N,V)<45kN, escala-se N/V juntos até45kN na mesma direção e sentido e conserva-se o binário M independente. Essa interpretação vetorial é declarada como convenção do modelo. Aplica-se também a um caso suplementar fornecido com pequena força; não se somam eixos independentes como múltiplos pisos. O caso original permanece inalterado. N=V=0 não inventa direção/força axial; momento puro continua próprio. Todos os casos nulos recebem SEM AVALIAÇÃO, nunca aprovação. A análise de integridade e a qualidade da referência externa não são certificadas pelo simples registro de texto.

Capacidades globais opcionais Nc,Rd, Nt,Rd, M,Rd e V,Rd exigem unidades e referência externa, além de vínculo SHA256 ao caso atual. A interação5.5.1 usa essas capacidades e o limite dos furos, quando ativo. Alterar dados invalida o vínculo. Sem base externa, a conclusão global permanece expressamente excluída, sem substituir Nc,Rd por resistência de tala. O módulo não determina comprimentos/deslocamentos globais ou prova a qualidade da análise externa.

Se o projeto exige ausência de deslizamento, o atendimento específico de serviço permanece pendente. Um resultado local ELU não certifica rigidez de pórtico, ausência de deslizamento, fadiga ou montagem.

Estados distintos: falha numérica, entrada inválida, geometria inválida, fora do modelo, falha resistente calculada, falha de detalhamento, verificações locais pendentes e verificações locais atendidas. Uma colisão de encaixe conserva as capacidades matematicamente calculáveis e a lista de falhas. Ligamentos não positivos impedem as expressões que deles dependem. Resultados condicionais não são convertidos em PASS agregado.

## Fontes e validação

Base analítica: Fakury, *Dimensionamento de Elementos Estruturais de Aço e Mistos de Aço e Concreto*, pp.310–320; extensão externa+interna expressa em p.320. Regras resistentes atuais: ABNT NBR8800:2024 com Er1:2025, inclusive correção do ramo>25 da6.5.4. Os livros de Pfeil e Bellei foram usados na distinção de modelos; não se mistura partilha elástica de momento da alma com o menor V/Ve da rota convencional.

Contratos independentes: `CONVENTIONAL_W_IMPLEMENTATION_CONTRACT.md` e `PARAMETRIC_DOMAIN_ADDENDUM.md`, preservados junto a esta documentação. Os JSON `tests/fixtures/conventional_fixtures.json` e `parametric_fixtures.json` são dados importados de cálculos independentes, sem importar o motor de produção. Incluem dez combinações assinadas, geometria exata dos caminhos/cortes, três furos, limites de compressão/esbeltez e doze configurações paramétricas. São oráculos dos subchecks que cobrem, não passes automáticos da montagem inteira.

Exemplo: W610/M30 passa os novos subchecks isolados de compressão/bloco do oráculo, mas a avaliação completa detecta índice1,041862 na compressão local da mesa do membro ao incluir a variação Vx. A falha é mantida. Não se modifica a produção para forçar um PASS de um oráculo parcial.

Teste de desenvolvimento: `PYTHONPATH=connections_audit/test_dependencies:connections_work095/source python -m pytest -q connections_work095/source/tests` no ambiente de trabalho. No pacote extraído com dependências instaladas, `python -m pytest -q tests`.


Revisão vigente 0.9.14: `CONVENTIONAL_SPLICE_AUDIT0914_METHOD.md` complementa e corrige os contratos históricos. Referências anteriores a perfil fixo não limitam o domínio paramétrico atual.
