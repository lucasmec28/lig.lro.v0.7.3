# Revisão 0.7.5

Esta versão mantém os modelos e critérios da 0.7.4 e corrige dois defeitos de software.

## Projetos preservados durante a navegação

Alternar o seletor de família podia apagar campos de um projeto em edição: na end plate engastada, o momento podia voltar a zero; nas duas talas, os dados voltavam ao exemplo. Agora há um rascunho por família na sessão, com rascunhos separados para end plate rotulada e engastada. Geometria, esforços com seus sinais, materiais, observações e linhas intermediárias são recuperados ao voltar.

Carregar explicitamente um exemplo ou importar um projeto substitui o rascunho da família correspondente. Um arquivo inválido mantém o projeto que já estava aberto. A memória Word anterior não é oferecida depois de alterar entradas. Essa preservação vale para a sessão aberta; para guardar permanentemente ou usar em outro computador, continue usando o JSON.

## Guarda de resultados numéricos

Um valor de resistência infinito não pode mais produzir índice zero e resultado favorável. Solicitação ou resistência não finita, ou resistência não positiva, produz índice infinito e falha. Demanda nula com resistência finita positiva e ações negativas continuam tratadas normalmente. Nenhum modelo implementado usa resistência infinita como representação de item não aplicável.

## O que permanece

A W200 original continua calculável com ressalvas do DG39. As linhas intermediárias continuam sem crédito resistente, com furos e geometria explicitamente considerados. Falhas de resistência, não conformidades de detalhamento, extrapolação e interferências continuam distintas. Não houve alteração de equações estruturais, dos esforços dos exemplos ou dos formatos de projeto anteriores.

## Verificação

- Testes originais da versão 0.7.4, acrescidos de regressões de navegação, importação inválida e finitude numérica.
- Verificação independente de 18 cenários com subcasos nas cinco configurações: compatibilidade do JSON original, NaN/infinito, dimensões e tipos inválidos, esforços e sentidos não suportados, espaçamentos máximos e manutenção das ressalvas no Word.
- Execução com Python 3.12 e as quatro dependências fixadas em requirements.txt.
- Conferência visual dos relatórios Word da W200 original e de uma W410 com uma linha intermediária.
- Pacote de quatro arquivos verificado e iniciado em extração limpa.

Testes de software e a conferência visual não são uma validação independente de todos os procedimentos estruturais. As hipóteses e exclusões do método continuam sendo responsabilidade do projeto e estão documentadas na interface e na memória.
