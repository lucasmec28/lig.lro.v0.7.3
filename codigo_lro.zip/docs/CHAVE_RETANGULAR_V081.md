# Chave de cisalhamento retangular — 0.8.1

## O que é calculado

Uma chapa vertical retangular maciça, centrada sob a placa de base Tipo 1, sem furos, enrijecedores, torção ou ações biaxiais. O cortante atua perpendicularmente à face da chave. A largura `bh` é paralela a B; a espessura `tpv` é paralela a L. A projeção `bv` parte da face inferior da placa e inclui a espessura real de graute `en`.

Aço ASTM A36 por padrão, com outros aços de chapa do catálogo e suas propriedades/limites. Espessuras comerciais em polegadas, sempre acompanhadas do valor em mm; espessuras personalizadas permanecem possíveis. Não há correção automática de entradas.

São verificadas separadamente:

- Contato local chave–concreto: σlug,Rd=1,7fck/γc; Vbearing,Rd=σlug,Rd bh(bv−en).
- Flexão da chave: tpv,min=√[2|V|(bv+en)/(bh(fy/γa1))].
- Relação de espessuras: tpv≤tp.
- Escoamento por cisalhamento: Vy,Rd=0,60fy bh tpv/γa1.
- Ruptura por cisalhamento: Vu,Rd=0,60fu bh tpv/γa2.

γa1=1,10; γa2=1,35; γc=1,40. A relação A2/A1=4 é prescrita somente para o contato da chave. O contato horizontal da placa de base continua com A2/A1=1. A chave recebe todo o cortante, sem somar atrito. O mínimo das resistências locais não é apresentado como resistência do dispositivo completo.

Referências: ABNT NBR 8800:2024, versão corrigida 2025, 6.7.2.3–6.7.2.4/Figura 24, 6.6.5 e 6.5.5(a),(b).

## Referência das ações e sinais

As ações informadas M e V referem-se à face superior da placa, antes da inclusão do efeito da chave. No corte, +x aponta à direita; V positivo aponta em +x e M positivo é horário, gerando compressão no lado +x.

- eV=tp+(bv+en)/2
- ΔM=V eV, com sinal
- Mef=M informado+ΔM

A soma algébrica ocorre uma única vez, antes de tomar o módulo no equilíbrio N–M. Os chumbadores e a placa utilizam Mef. O JSON guarda apenas as entradas; Mef é sempre recalculado. Não informe novamente em M a parcela V eV que o app já acrescenta.

Essa transformação é derivada por estática para a referência declarada, não apresentada como uma equação numerada da NBR. AISC Design Guide 1, 3ª edição, 2024, pp.79–82 e 89–90 trata do efeito do cortante excêntrico e da flexão local da placa.

Os caminhos legados de atrito e de capacidade externa conservam seu comportamento N–M e seus JSONs. Na rota externa, a memória específica deve tratar da geometria, orientação, excentricidade da reação e esforços correspondentes na base; não há transformação automática nesse caminho.

## Soldas: ações prescritas, resistência pendente

A NBR 6.7.2.4 prescreve as ações para dimensionar as soldas na resistência de contato do concreto:

- Vw=Vbearing,Rd
- Mw=½ σlug,Rd bh(bv²−en²)=Vw(bv+en)/2

O módulo mostra ambas, sem limitá-las pelo cortante aplicado ou pela resistência menor da chapa. Mw é a ação local na solda, na face inferior da placa; ΔM é o efeito da ação aplicada no equilíbrio global. As duas parcelas não são somadas entre si.

Nesta versão não são calculadas resistência nem utilização das soldas. Permanecem a complementar: dimensões efetivas/detalhamento dos filetes, metal de solda, metal-base, transferência de tensões e flexão local da placa na fixação da chave. Não se reutiliza o modelo de solda de outra família de ligação.

## Limites da conclusão

“Atende às verificações realizadas” limita-se às linhas efetivamente calculadas. Permanecem pendentes a ligação completa da chave, ruptura/arrancamento e efeitos de borda do concreto, bloco adequadamente armado conforme NBR 6118, transferência à fundação, ancoragem dos chumbadores no concreto, soldas do pilar e classificação de rigidez. A pressão local de contato não substitui a verificação do bloco.

Chaves cruciformes e trechos de perfil W têm somente um descritor na rota de resistência externa. A orientação do W é nomeada em relação a V. O app não converte essas formas em chapa equivalente nem calcula sua seção, contato ou soldas. A memória externa continua necessária.

## Casos de aceitação

1. bh=100, bv=100, en=40, tpv=tp=50,8 mm; fck=20; fy=250; fu=400 MPa; V=100 kN: Vbearing=145,714286 kN, tpv,min=35,099858 mm, Vy=692,727273 kN e Vu=903,111111 kN; Vw=145,714286 kN e Mw=10,200000 kN·m. Verificações locais atendem; dispositivo completo pendente.
2. V=150 kN, demais dados iguais: contato não atende; não há resgate por soma de atrito.
3. tpv=31,75 mm: flexão da chave não atende. tpv=50,8 com tp=38,1 mm: relação de espessuras não atende, sem alteração das entradas.
4. bh=200, bv=150, en=40, tpv=31,75, tp=38,1 mm; fck=30 MPa; V=100 kN: Vw=801,428571 kN e Mw=76,135714 kN·m, apesar de a flexão da chave para o V aplicado atender.
5. No primeiro caso, N=M=0: ΔM=12,080000 kN·m. V invertido espelha a linha tracionada. Sinais, cancelamento algébrico, JSON repetido, desenho e Word são verificados.

Dimensões que não cabem sob a placa, bv≤en, dados não finitos e aços inválidos são rejeitados. Uma relação tpv>tp permanece calculável com a não conformidade explícita.

## Três caminhos de cisalhamento

O seletor principal apresenta chumbadores, barra/chave de cisalhamento e atrito. Uma nova base abre no caminho dos chumbadores, com resistência e aplicabilidade pendentes; o cálculo N–M continua disponível. Os exemplos antigos e JSONs existentes conservam seu caminho declarado, inclusive atrito.

Nos chumbadores, a comparação usa o VRd externo do grupo instalado para a combinação atual, com capacidade/referência independentes das usadas para uma chave. O usuário deve confirmar que a memória cobre os dados atuais; essa confirmação fica vinculada às ações N–M–V com sinais, geometria, materiais, capacidade e referência. Alterações pertinentes ou a importação de um projeto sem confirmação voltam a deixar o cortante pendente. Título e observações não alteram essa aplicabilidade.

A memória externa deve verificar as barras efetivamente engajadas, furos, arruelas e soldas, interação tração–corte–flexão, alavanca/afastamento no graute e o concreto (ancoragem, interação, borda, ruptura, pryout e grupo). Não se adota automaticamente 4×resistência de uma barra. Esta rota preserva M informado, sem transporte automático V·e; a memória externa deve fornecer as ações resultantes adequadas da base, incluindo a excentricidade da reação. A verificação interna do aço à tração permanece isolada e não demonstra a interação.

O modelo nativo de chumbadores ao corte da NBR 6.7.2.5 é uma etapa futura. Nesta versão, confirmação de aplicabilidade é uma declaração técnica do usuário; o app não valida a memória externa nem certifica a base completa. Não há soma automática entre os três caminhos.
