# Seleção guiada de famílias existentes · 0.9.19

## Uso

O seletor direto **Tipo de ligação** permanece disponível, com as mesmas onze famílias e a mesma ordem. Logo depois dele, na barra lateral, o expansor **Encontrar uma família · seleção guiada** oferece uma busca opcional:

1. Escolha a interface: base, mesa de coluna, alma de coluna, alma de viga de apoio ou emenda W coaxial.
2. Escolha uma categoria nominal presente nessa interface.
3. Selecione uma família, leia seu escopo e clique em **Abrir família**.

Selecionar um resultado não abre a família, mesmo quando há somente um resultado. A família já aberta tem botão desabilitado. **Limpar filtros** restaura apenas a busca. Quando uma interface não oferece a categoria anteriormente escolhida, só esse filtro volta para **Todos os modelos**, com uma legenda explicativa.

**Os filtros ajudam a encontrar uma família. Não configuram o projeto aberto nem comprovam rigidez ou capacidade de rotação. Confirme o apoio real e o modelo no formulário da família e confira seu escopo e suas verificações.**

O aviso de família fora dos filtros compara somente seu nome com os resultados da busca. A ausência desse aviso não significa compatibilidade física nem aprovação técnica. Resultados vazios ou filtros inconsistentes nunca abrem outra família automaticamente.

## Catálogo delimitado

| Interface | Modelo nominal | Resultados na ordem do seletor |
|---|---|---|
| Placa de base | Engastada · intenção do modelo | Placa de base · engastada |
| Placa de base | Rotulada / flexível · sem momento externo | Placa de base · rotulada |
| Viga–mesa de coluna | Rotulada / flexível · sem momento externo | Single plate; End plate · rotulada; Cantoneiras duplas · R016 · cortante; Cantoneiras duplas · R015 · soldadas/parafusadas |
| Viga–mesa de coluna | Engastada · intenção do modelo | End plate · engastada |
| Viga–alma de coluna | Rotulada / flexível · sem momento externo | Alma de coluna · duas talas |
| Viga–viga · alma da viga de apoio | Rotulada / flexível · sem momento externo | Single plate; Cantoneiras duplas · R017 · viga recortada |
| Emenda entre perfis W coaxiais | Tração axial | Emenda W · M004 · tração axial |
| Emenda entre perfis W coaxiais | N/M/V · modelo convencional | Emenda W · convencional · N/M/V |

São onze famílias e doze associações. Single plate tem duas interfaces, mas aparece uma única vez em **Todos**. Seu filtro não aciona a troca nativa de apoio: complemento, enrijecedor e demais campos continuam sob controle do formulário existente.

As interfaces alternativas dos formulários R015/R016 continuam fora do domínio dos motores e não recebem etiquetas no guia. R017 tem somente alma de viga perpendicular. Duas talas mantém rótula nominal e a qualificação pendente de rotação/flexibilidade e estabilidade. Emendas W permanecem axial ou N/M/V; a transmissão de momento não é uma certificação de engaste. Bases Tipo 1 legadas com indicação rotulada continuam externas, com seu momento e aviso nativos; nunca se tornam Tipo 2 por um filtro.

## Conservação e limites

- O módulo usa somente seu catálogo, chaves `nav_guide_` e o nome `connection_family` da família aberta. Não examina modelos físicos, widgets de engenharia, rascunhos, snapshots, resultados ou qualificações.
- Filtros/candidatos não entram nos JSON nativos, hashes técnicos, desenhos ou relatórios. Só o callback explícito de abertura escreve a família do dispatcher.
- O dispatcher e os formulários não foram refatorados. Abertura/restauração usam os mesmos presets, estado e importadores do seletor direto. Os onze nomes existentes não foram renomeados.
- Não há importador global, adaptador de esquema, migração silenciosa, cálculo novo, mudança de capacidade ou aprovação de projeto.
- Importação nativa de end plate continua podendo trocar pinned/moment e a família correspondente; o guia não reverte essa decisão.
- Mantêm-se a reavaliação canônica e os bloqueios de exportação das famílias.

A verificação desta mudança é focada em catálogo, navegação e conservação/importação real com Streamlit AppTest. Não é uma nova auditoria dos motores, inspeção visual por navegador ou certificação da suíte técnica integral. A cópia é de desenvolvimento e não constitui publicação.
