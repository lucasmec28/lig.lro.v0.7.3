"""New independent conventional bolted-corner fixture, stdlib only, no lro import.
Point loads and circular hole deductions give exact geometry/resultants; nominal
section stress is a supplemental screen, not hole/contact continuum elasticity.
"""
from pathlib import Path
import json,math,subprocess,sys,copy,hashlib
R=Path(__file__).resolve().parent
I=json.loads((R/'FIXTURE_INPUT.json').read_text());g=I['geometry'];m=I['materials'];a=I['catalog']['angle_each'];b=g['bolted_brace'];P=I['case']['P'];t=g['gusset_t'];ga1=m['gamma_a1'];ga2=m['gamma_a2'];fy=m['gusset']['fy'];fu=m['gusset']['fu'];ph=math.radians(b['phi_deg']);C,S=math.cos(ph),math.sin(ph);rt=math.sqrt(2)
uv=lambda p:[C*p[0]+S*p[1],-S*p[0]+C*p[1]]
xy=lambda u,v:[C*u-S*v,S*u+C*v]
poly=[uv(p) for p in g['gusset_polygon']];us=b['bolt_stations_u'];n=len(us);Lc=us[-1]-us[0];dh=b['physical_hole_diameter'];dn=dh if b['drilled'] else dh+2;r=dn/2;db=b['bolt_diameter'];gauge=b['gauge'];e=us[0]-b['angle_free_end_u'];checks=[]
subprocess.run([sys.executable,str(R/'build_common_fixture.py')],check=True)
common=json.loads((R/'COMMON_ORACLE.json').read_text());F=common['force_model']
def row(id,D,Rd,**extra):
 d=dict(id=id,demand=D,resistance=Rd,utilization=D/Rd,pass_=D<=Rd*(1+1e-10),**extra);checks.append(d);return d

def line_intersections(fixed_axis,z):
 vals=[]
 for p,q in zip(poly,poly[1:]+poly[:1]):
  dx=q[fixed_axis]-p[fixed_axis]
  if abs(dx)<1e-10:
   if abs(p[fixed_axis]-z)<1e-8:vals.extend((p[1-fixed_axis],q[1-fixed_axis]))
  else:
   k=(z-p[fixed_axis])/dx
   if -1e-9<=k<=1+1e-9:vals.append(p[1-fixed_axis]+k*(q[1-fixed_axis]-p[1-fixed_axis]))
 return [min(vals),max(vals)] if vals else None

def edge_id_at(u,v):
 p=xy(u,v)
 for idx,(s,z) in enumerate(zip(g['gusset_polygon'],g['gusset_polygon'][1:]+g['gusset_polygon'][:1])):
  dx,dy=z[0]-s[0],z[1]-s[1];cr=(p[0]-s[0])*dy-(p[1]-s[1])*dx
  if abs(cr)<1e-5 and min(s[0],z[0])-1e-6<=p[0]<=max(s[0],z[0])+1e-6 and min(s[1],z[1])-1e-6<=p[1]<=max(s[1],z[1])+1e-6:return ['beam_support','right_free','top_free','column_support','clip_free'][idx]
 return 'unknown'

# Entire physical contact edges, including portions beyond effective seams.
supports={'beam':[poly[0],poly[1]],'column':[poly[3],poly[4]]}
def clipped_support(a0,z0,u,vlo,vhi):
 lo,hi=0.,1.
 for p,q in [(a0[0]-u,z0[0]-u),(a0[1]-vlo,z0[1]-vlo),(vhi-a0[1],vhi-z0[1])]:
  d=q-p
  if abs(d)<1e-12:
   if p< -1e-9:return 0.
  elif d>0:lo=max(lo,-p/d)
  else:hi=min(hi,-p/d)
 return max(0.,hi-lo)*math.dist(a0,z0)
def support_hits(u,vlo,vhi):return {k:L for k,(a0,z0) in supports.items() if (L:=clipped_support(a0,z0,u,vlo,vhi))>1e-7}

# Nominal straight-row static end-axis model; real geometry is retained separately.
boltxy=[xy(u,0) for u in us];exit0=line_intersections(1,0)[1]
Ct=max(.5,1-a['ec']/Lc);An=a['Ag']-dn*a['t'];Ab=math.pi*db*db/4
angle_paths=[];bolt_bearing=[]
for count,label in [(1,'1L'),(2,'2L-T')]:
 row(label+'_angle_gross_each',P/count,a['Ag']*m['angle']['fy']/ga1,component='angles')
 row(label+'_angle_net_effective_each',P/count,Ct*An*m['angle']['fu']/ga2,component='angles',Ct=Ct,An=An,Lc=Lc)
 grip=count*a['t']+t+b['washer_stack'];kg=1-.01*max(0,grip-5*db)/1.5
 for j,u in enumerate(us):
  for plane in range(count):row(f'{label}_bolt{j+1}_plane{plane+1}',P/(count*n),.45*Ab*b['fub']/ga2*kg,component='bolts',grip=grip,grip_factor=kg)
  lc=e-dh/2 if j==0 else us[j]-us[j-1]-dh
  rr=min(1.2*lc*a['t']*m['angle']['fu'],2.4*db*a['t']*m['angle']['fu'])/ga2
  row(f'{label}_angle_bearing{j+1}',P/(count*n),rr,component='angle_bearing',lc=lc,force_direction='-u')
 for k in range(1,n+1):
  Lv=e+us[k-1]-us[0];Agv=Lv*a['t'];Anv=(Lv-(k-.5)*dn)*a['t']
  for side,Ant in [('connected_real_toe',(a['b']-gauge-dn/2)*a['t']),('opposite_real_toe_catalog_complement',a['Ag']-(a['b']-gauge)*a['t']-dn*a['t']/2)]:
   Ry=(.6*m['angle']['fy']*Agv+.5*m['angle']['fu']*Ant)/ga2;Rr=(.6*m['angle']['fu']*Anv+.5*m['angle']['fu']*Ant)/ga2
   z=row(f'{label}_angle_block_{side}_{k}',P*k/(count*n),min(Ry,Rr),component='angle_block',Agv=Agv,Anv=Anv,Ant=Ant,Ryield=Ry,Rrupture=Rr,captured_bolts=list(range(1,k+1)),heel_is_free=False)
   angle_paths.append(z)
for j,u in enumerate(us):
 lc=us[j+1]-u-dh if j<n-1 else exit0-u-dh/2
 z=row(f'common_gusset_bearing{j+1}',P/n,min(1.2*lc*t*fu,2.4*db*t*fu)/ga2,component='gusset_bearing',lc=lc,force_direction='+u',physical_hole_diameter=dh)
 bolt_bearing.append(z)
# Whitmore spreads from last to first physical bolt; one row has zero row gauge.
w=2*Lc*math.tan(math.pi/6);ch=line_intersections(0,us[0]);vl=max(-w/2,ch[0]);vh=min(w/2,ch[1]);bw=vh-vl
assert abs(bw-w)<1e-8, 'fixture must have contained Whitmore'
row('gusset_whitmore_gross',P,bw*t*fy/ga1,component='gusset',width=bw,ends=[xy(us[0],vl),xy(us[0],vh)])
row('gusset_whitmore_net_supplement',P,(bw-dn)*t*fu/ga2,component='gusset',net_width=bw-dn,conventional_net_area_screen=True)

# All ordinary one-shear L cap families terminate at genuine free edges.
# Within a circular hole the cap deduction is a half chord, not fixed d/2.
# Candidate u include geometric/support transitions and minima of both branches.
base_events={us[0]-r,us[-1]+r}|{u+du for u in us for du in [-r,0,r]}|{p[0] for p in poly if us[0]-r<=p[0]<=us[-1]+r}
for a0,z0 in supports.values():
 for p in (a0,z0):
  if us[0]-r<=p[0]<=us[-1]+r:base_events.add(p[0])
 # root crossing row v0 changes whether one side retains support.
 if a0[1]*z0[1]<0:
  f=-a0[1]/(z0[1]-a0[1]);u=a0[0]+f*(z0[0]-a0[0])
  if us[0]-r<=u<=us[-1]+r:base_events.add(u)
events=set(base_events)
for lo,hi in zip(sorted(base_events),sorted(base_events)[1:]):
 mid=(lo+hi)/2;j=next((j for j,z in enumerate(us) if abs(mid-z)<r),None)
 if j is None:continue
 q1=line_intersections(0,lo);q2=line_intersections(0,hi)
 for side in [0,1]:
  slope=((abs(q2[side])-abs(q1[side]))/(hi-lo))
  for K in [-slope,1.2*fy/fu-slope]:
   u=us[j]+r*K/math.hypot(1,K)
   if lo<u<hi:events.add(u)
 # U with both longitudinal cuts tangent to nominal holes: cap width2r.
 # Yield derivative: -1.2fy+fu*x/sqrt(r²-x²); Rr analogous.
 for K in [1.2*fy/fu,1.2]:
  u=us[j]+r*K/math.hypot(1,K)
  if lo<u<hi:events.add(u)

def block_state(u,side):
 ch=line_intersections(0,u);vl,vh=ch;capt=[j+1 for j,z in enumerate(us) if z+r>=u-1e-8];excluded=[j+1 for j,z in enumerate(us) if z-r>u+1e-8]
 if not capt:return None
 h=max([math.sqrt(max(0,r*r-(u-z)**2)) for z in us if abs(u-z)<=r]+[0]);ded=sum(max(0,min(exit0,z+r)-max(u,z-r)) for z in us)
 if side=='negative':vb=vl;hits=support_hits(u,-1e20,0);path=[[exit0,0],[u,0],[u,vb]];Agv=(exit0-u)*t;Anv=(exit0-u-ded)*t;Ant=(abs(vb)-h)*t
 elif side=='positive':vb=vh;hits=support_hits(u,0,1e20);path=[[exit0,0],[u,0],[u,vb]];Agv=(exit0-u)*t;Anv=(exit0-u-ded)*t;Ant=(abs(vb)-h)*t
 else:
  if not vl<=-r or not r<=vh:return None
  x0=line_intersections(1,-r)[1];x1=line_intersections(1,r)[1];hits=support_hits(u,-r,r);path=[[x0,-r],[u,-r],[u,r],[x1,r]];Agv=(x0+x1-2*u)*t;Anv=Agv;Ant=(2*r-2*h)*t
  vb=None
 if hits:return dict(id=f'G_{side}_{u:.10f}',u=u,side=side,active=False,support_hits=hits,path_uv=path)
 if side!='tangent_U' and edge_id_at(u,vb).endswith('support'):return dict(id=f'G_{side}_{u:.10f}',u=u,side=side,active=False,reason='transverse_end_on_supported_edge',path_uv=path)
 assert Agv>0 and Anv>0 and Ant>=-1e-6
 Ry=(.6*fy*Agv+.5*fu*Ant)/ga2;Rr=(.6*fu*Anv+.5*fu*Ant)/ga2;Rd=min(Ry,Rr);D=len(capt)*P/n
 return dict(id=f'G_{side}_{u:.10f}',u=u,side=side,active=True,Agv=Agv,Anv=Anv,Ant=max(0,Ant),Ryield=Ry,Rrupture=Rr,resistance=Rd,demand=D,utilization=D/Rd,path_uv=path,path_xy=[xy(*p) for p in path],captured_bolts_including_crossing=capt,captured_bolts_excluding_crossing=excluded,demand_limits=[len(excluded)*P/n,D],force_model='included/excluded crossing-hole envelope, no contact-pressure distribution assumed',free_exit=[edge_id_at(*path[0]),edge_id_at(*path[-1])])
paths=[z for u in sorted(events) for side in ['negative','positive','tangent_U'] if (z:=block_state(u,side))]
for side in ['negative','positive','tangent_U']:
 p=max([p for p in paths if p['side']==side and p['active']],key=lambda x:x['utilization'])
 row('gusset_block_'+side,p['demand'],p['resistance'],component='gusset_block',witness=p)

# Force-normal physical gross/net cuts use actual bolt points plus both retained
# support tractions. Both limits of each cut-hole force are retained.
seams=[]
for label,Fx,Fy in [('beam',-F['Hb'],-F['Vb']),('column',-F['Hc'],-F['Vc'])]:
 ep=[uv(p) for p in g[label+'_seam']];ep.sort();seams.append(dict(label=label,ends=ep,Nu=C*Fx+S*Fy,Vv=-S*Fx+C*Fy))
def section(u,include=True,net=True):
 ch=line_intersections(0,u)
 if not ch or ch[1]-ch[0]<1e-8:return None
 vl,vh=ch;h=max([math.sqrt(max(0,r*r-(u-z)**2)) for z in us if abs(u-z)<=r]+[0]) if net else 0
 A=t*(vh-vl-2*h);vc=t*(vh*vh-vl*vl)/(2*A);Iz=t*((vh**3-vl**3)/3-2*h**3/3)-A*vc*vc
 Nu=Vv=Mz=0.;retained=[]
 for j,z in enumerate(us):
  yes=(z+r>=u-1e-8) if include and abs(z-u)<=r+1e-8 else (z-r>u+1e-8) if abs(z-u)<=r+1e-8 else z>u
  if yes:Nu+=P/n;Mz+=vc*P/n;retained.append('bolt'+str(j+1))
 for s in seams:
  pa,pb=s['ends'];u0,u1=pa[0],pb[0]
  if u>=u1:continue
  f=1. if u<=u0 else (u1-u)/(u1-u0);q0=pa if u<=u0 else [u,pa[1]+(u-u0)*(pb[1]-pa[1])/(u1-u0)];uc=(q0[0]+pb[0])/2;vv=(q0[1]+pb[1])/2;nn=f*s['Nu'];tt=f*s['Vv'];Nu+=nn;Vv+=tt;Mz+=(uc-u)*tt-(vv-vc)*nn;retained.append(s['label']+'_root')
 Nu=0. if abs(Nu)<1e-8 else Nu;Vv=0. if abs(Vv)<1e-8 else Vv;Mz=0. if abs(Mz)<1e-6 else Mz
 sig=[Nu/A-Mz*(z-vc)/Iz for z in [vl,vh]] # Moment Mz = -int(v-vc)*sigma*dA
 vm=max(math.hypot(z,math.sqrt(3)*1.5*Vv/A) for z in sig)
 return dict(u=u,include_cut_hole=include,net=net,chord_v=[vl,vh],A=A,centroid_v=vc,I=Iz,hole_half_chord=h,N=Nu,V=Vv,M=Mz,sigma_edges=sig,nominal_VM=vm,retained_sources=retained)
sec_events=set(events)|{p[0] for p in poly if p[0]<=us[-1]+r}|{p0[0] for s in seams for p0 in s['ends'] if p0[0]<=us[-1]+r}
# Numerical closure of a supplemental scalar screen, not interval certification.
secpoints=set(sec_events)
for lo,hi in zip(sorted(sec_events),sorted(sec_events)[1:]):secpoints.update(lo+(hi-lo)*j/64 for j in range(1,64))
def maximize(func,lo,hi):
 z=(math.sqrt(5)-1)/2;c=hi-z*(hi-lo);d=lo+z*(hi-lo);fc=func(c);fd=func(d)
 for _ in range(80):
  if fc>fd:hi,d,fd=d,c,fc;c=hi-z*(hi-lo);fc=func(c)
  else:lo,c,fc=c,d,fd;d=lo+z*(hi-lo);fd=func(d)
 return (lo+hi)/2
for lo,hi in zip(sorted(sec_events),sorted(sec_events)[1:]):
 if hi-lo<1e-8:continue
 for inc in [False,True]:
  for net in [False,True]:
   for quantity in ['sigma','VM']:
    def fun(u):
     z=section(u,inc,net)
     if z is None:return 0. # zero-width physical polygon endpoint, not a resisting section
     return max(map(abs,z['sigma_edges'])) if quantity=='sigma' else z['nominal_VM']
    grid=[lo+(hi-lo)*j/32 for j in range(33)];vals=[fun(x) for x in grid]
    for j in range(1,32):
     if vals[j]>=vals[j-1] and vals[j]>=vals[j+1] and (vals[j]>0):secpoints.add(maximize(fun,grid[j-1],grid[j+1]))
sections=[z for u in sorted(secpoints) for include in [False,True] for net in [False,True] if (z:=section(u,include,net))]
witnesses={'peak_normal':max(sections,key=lambda z:max(map(abs,z['sigma_edges']))),'peak_VM':max(sections,key=lambda z:z['nominal_VM']),'minimum_normal':min(sections,key=lambda z:min(z['sigma_edges']))}
row('gusset_actual_net_body_rupture',max(map(abs,witnesses['peak_normal']['sigma_edges'])),fu/ga2,component='gusset_sections',witness=witnesses['peak_normal'],nominal_screen=True)
row('gusset_actual_net_body_yield',witnesses['peak_VM']['nominal_VM'],fy/ga1,component='gusset_sections',witness=witnesses['peak_VM'],nominal_screen=True)
# Reusable exact station oracles; high-density search results are separate.
station_oracles=[section(u,k,net) for u in sorted(sec_events) for k in [False,True] for net in [False,True]]

# Physical detailing: actual line segments, tool envelope, heel and free ends.
def distance_seg(p,a0,z0):
 dx=z0[0]-a0[0];dy=z0[1]-a0[1];k=max(0,min(1,((p[0]-a0[0])*dx+(p[1]-a0[1])*dy)/(dx*dx+dy*dy)));return math.hypot(p[0]-a0[0]-k*dx,p[1]-a0[1]-k*dy)
edges=list(zip(g['gusset_polygon'],g['gusset_polygon'][1:]+g['gusset_polygon'][:1]));detail=[]
def detailrow(id,x,bound,op):
 ok=x>=bound-1e-8 if op=='>=' else x<=bound+1e-8;detail.append(dict(id=id,value=x,bound=bound,operator=op,pass_=ok))
for j,p in enumerate(boltxy):
 for edge,(p0,p1) in enumerate(edges):
  d=distance_seg(p,p0,p1);detailrow(f'bolt{j+1}_edge{edge}_minimum',d,22, '>=');detailrow(f'bolt{j+1}_edge{edge}_tool',d,b['tool_radius']+b['fabrication_clearance']+(g['root_fillet_leg'] if edge in [0,3] else 0),'>=')
for edge in [1,2,4]:detailrow('conservative_all_free_edge_max_'+str(edge),min(distance_seg(p,*edges[edge]) for p in boltxy),min(12*t,150),'<=')
for pitch in [z-u for u,z in zip(us,us[1:])]:
 detailrow('pitch_min',pitch,max(2.7*db,dh+db),'>=');detailrow('pitch_max',pitch,min(24*min(a['t'],t),300),'<=');detailrow('tool_pitch',pitch,2*b['tool_radius']+b['fabrication_clearance'],'>=')
for nm,d in [('angle_free_end',e),('angle_connected_toe',a['b']-gauge)]:detailrow(nm+'_minimum',d,22,'>=');detailrow(nm+'_maximum',d,min(12*a['t'],150),'<=');detailrow(nm+'_tool',d,b['tool_radius']+b['fabrication_clearance'],'>=')
detailrow('heel_tool_clearance',gauge-b['heel_extent'],b['tool_radius']+b['fabrication_clearance'],'>=')
detailrow('heel_hole_clearance',gauge-b['heel_extent'],dh/2,'>=')
footprint=[xy(u,v) for u in [b['angle_free_end_u'],us[-1]+b['tool_radius']+b['fabrication_clearance']] for v in [-gauge,a['b']-gauge]]
for j,p in enumerate(footprint):
 uu,vv=uv(p);z=line_intersections(0,uu);detailrow('angle_footprint'+str(j),min(vv-z[0],z[1]-vv) if z else -1,0,'>=')
# Verify the summed physical bolt resultant is exactly nominal planar P once.
bolt_R=[sum(P/n*C for _ in us),sum(P/n*S for _ in us),sum(p[0]*(P/n*S)-p[1]*(P/n*C) for p in boltxy)]
assert max(abs(x-y) for x,y in zip(bolt_R,[F['H'],F['V'],0]))<1e-7
summary={label:max((z for z in checks if z['id'].startswith(label)),key=lambda z:z['utilization']) for label in ['1L','2L-T']}
common_strength=max(common['checks'],key=lambda z:z['utilization'])
out=dict(purpose='New independent conventional bolted strong-axis corner method fixture',inputs='FIXTURE_INPUT.json',arrangements=['1L','2L-T'],checks=checks,common_full_joint=common,common_geometry_count=dict(gussets=1,beam_roots=1,column_roots=1),bolt_centers_xy=boltxy,force_per_hole=P/n,physical_bolt_resultant=bolt_R,angle_Ct=Ct,angle_An=An,Whitmore=dict(u=us[0],width=bw,net_width=bw-dn,contained=True),gusset_block_paths=paths,section_station_oracles=station_oracles,section_search_witnesses=witnesses,section_search=dict(method='all hole/polygon/root events plus64 interior subdivisions and bounded scalar refinement of observed local extrema; exact station witnesses separate',interval_certification=False,pointwise_hole_stress_claimed=False),detailing=detail,physical_angle_footprint=footprint,angle_summary=summary,common_governing=common_strength,all_strength_checks_pass=all(z['pass_'] for z in checks+common['checks']),all_fixture_details_pass=all(z['pass_'] for z in detail),minimum_nominal_section_normal=min(witnesses['minimum_normal']['sigma_edges']),idealization=I['idealization'])
(R/'ORACLE.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:out[k] for k in ['all_strength_checks_pass','all_fixture_details_pass','minimum_nominal_section_normal','angle_Ct','angle_An','Whitmore']},indent=2))
print('angle governs',[(k,v['id'],v['utilization']) for k,v in summary.items()]);print('common',common_strength['id'],common_strength['utilization']);print('block',[(z['id'],z['utilization']) for z in checks if z['component']=='gusset_block']);print('detail fails',[z for z in detail if not z['pass_']])
