"""Independent common welded-root/full-joint calculation for bolted compact corner.
Adapted transparently from prior independent C1 calculation, never production code.
Standard library only. Never imports production code. See ../PROVENANCE.md.
N, mm, MPa. Actions act on the named isolated body; +M is CCW.
"""
from pathlib import Path
from math import sin,cos,tan,radians,sqrt,pi,hypot
import json,copy
ROOT=Path(__file__).resolve().parent
I=json.loads((ROOT/'FIXTURE_INPUT.json').read_text())
g=I['geometry']; mats=I['materials']; cat=I['catalog']; ga1=mats['gamma_a1'];ga2=mats['gamma_a2'];gw=mats['gamma_w2'];E=mats['E'];fw=mats['weld']['fw']
checks=[]
def check(id,D,R,source,**kw):
    row=dict(id=id,demand=abs(D),resistance=R,utilization=abs(D)/R,pass_=abs(D)<=R,source=source,**kw); checks.append(row);return row
def weld_q(s):return s/sqrt(2)*.6*fw/gw
def block(Av,At,mat,cts=.5):return min(.6*mat['fu']*Av+cts*mat['fu']*At,.6*mat['fy']*Av+cts*mat['fu']*At)/ga2
def vec_res(actions,about=(0,0)):
    return [sum(a['Fx'] for a in actions),sum(a['Fy'] for a in actions),sum(a['M']+(a['point'][0]-about[0])*a['Fy']-(a['point'][1]-about[1])*a['Fx'] for a in actions)]
def act(point,Fx,Fy,M=0):return dict(point=point,Fx=Fx,Fy=Fy,M=M)
def ufm(phi,P=100000):
    H=P*cos(radians(phi));V=P*sin(radians(phi));Hc=g['ec']*V/(g['eb']+g['beta']);Hb=H-Hc;Vb=g['eb']*Hb/g['alpha'];Vc=V-Vb
    return dict(H=H,V=V,Hb=Hb,Vb=Vb,Hc=Hc,Vc=Vc)
a=ufm(g['bolted_brace']['phi_deg'],I['case']['P']);H,V,Hb,Vb,Hc,Vc=[a[x] for x in ('H','V','Hb','Vb','Hc','Vc')]
P=I['case']['P'];ec=g['ec'];eb=g['eb']; B=(ec+g['alpha'],eb); C=(ec,eb+g['beta']);J=(ec,0)
# Authoritative input is COMPLETE_CUTS. Incremental conversion is an independent check only.
rawcut=I['case']['beam_cut'];D=tuple(rawcut['point']);beamcut=act(D,rawcut['Fx'],rawcut['Fy'],rawcut['M'])
T=act(J,beamcut['Fx']+Hb,beamcut['Fy']+Vb,beamcut['M']+(D[0]-ec)*beamcut['Fy']+g['alpha']*Vb-eb*Hb)
baseline=I['case']['independent_conversion_witness']
incremental_T=act(J,baseline['Fx']-Hc,baseline['Fy']+Vb,baseline['M'])
assert max(abs(T[k]-incremental_T[k]) for k in ['Fx','Fy','M'])<1e-7
# Right/upper/lower boundary actions ON assembly. Member cuts are not interface actions.
upper=I['case']['upper_column_cut'];up=act(upper['point'],upper['Fx'],upper['Fy'],upper['M'])
colgus=act(C,Hc,Vc)
lo_pt=(0,-1000); fx=-up['Fx']-T['Fx']-Hc;fy=-up['Fy']-T['Fy']-Vc
lm= -vec_res([up,T,colgus])[2] - lo_pt[0]*fy+lo_pt[1]*fx
lower=act(lo_pt,fx,fy,lm)
gusset_res=vec_res([act((0,0),H,V),act(B,-Hb,-Vb),act(C,-Hc,-Vc)])
beam_res=vec_res([beamcut,act(J,-T['Fx'],-T['Fy'],-T['M']),act(B,Hb,Vb)])
column_res=vec_res([up,lower,T,colgus]); assembly_res=vec_res([beamcut,up,lower,act((0,0),H,V)])
for rs in [gusset_res,beam_res,column_res,assembly_res]:assert max(map(abs,rs))<1e-7
# Unambiguous production convention: COMPLETE_CUTS only. This test compares independent incremental conversion.
recovered=act(J,beamcut['Fx']+Hb,beamcut['Fy']+Vb,beamcut['M']+(D[0]-ec)*beamcut['Fy']+g['alpha']*Vb-eb*Hb)
assert max(abs(recovered[k]-T[k]) for k in ['Fx','Fy','M'])<1e-7
wrong=act(J,T['Fx']-Hc,T['Fy']+Vb,T['M']);wrong_beam_res=vec_res([beamcut,act(J,-wrong['Fx'],-wrong['Fy'],-wrong['M']),act(B,Hb,Vb)],J)
# Brace-to-gusset is computed separately in build_fixture.py. Only the unchanged common mechanics remain here.
ang=cat['angle_each'];ma=mats['angle'];tg=g['gusset_t'];mg=mats['gusset']
# Body/root sections: two supported edges use their OWN normal/shear, not fictitious free-edge block paths.
seams={}
for name,Ls,N,S,recv in [('beam',hypot(g['beam_seam'][1][0]-g['beam_seam'][0][0],g['beam_seam'][1][1]-g['beam_seam'][0][1]),Vb,Hb,'beam'),('column',hypot(g['column_seam'][1][0]-g['column_seam'][0][0],g['column_seam'][1][1]-g['column_seam'][0][1]),Hc,Vc,'column')]:
    A=tg*Ls;qn=N/Ls;qs=S/Ls;q=hypot(qn,qs);matr=mats[recv];rr=cat[recv]
    check(name+'_root_weld',1.25*q,2*weld_q(6),'DG29 direct-weld 1.25 average; NBR Table9',q_raw=q)
    ny=mg['fy']*A/ga1;sy=.6*mg['fy']*A/ga1
    check(name+'_gusset_supported_section_interaction',(N/ny)**2+(S/sy)**2,1,'Conservative N2+V2 inscribed interaction; DG29 exact N2+V4 reported separately, not an NBR formula')
    check(name+'_gusset_supported_net_tension',N,mg['fu']*A/ga2,'NBR6.5.3 unperforated')
    check(name+'_gusset_supported_shear_rupture',S,.6*mg['fu']*A/ga2,'NBR6.5.5')
    # Effective depth on common gusset is min(tg,2s), never2*tg. Two receiver-side strips total2s.
    for nm,t,m in [('gusset',min(tg,12),mg),('receiver',12,matr)]:
        sig=qn/t;tau=qs/t
        check(name+'_'+nm+'_root_contact_yield',sqrt(sig**2+3*tau**2),m['fy']/ga1,'NBR6.5 combined elastic material-yield screen')
        check(name+'_'+nm+'_root_contact_normal_rupture',abs(sig),m['fu']/ga2,'NBR6.5.3')
        check(name+'_'+nm+'_root_contact_shear_rupture',abs(tau),.6*m['fu']/ga2,'NBR6.5.5')
    # k=tf deliberately lower bound: no as-rolled radius inferred. Beam endbranch conservatively applies whole seam.
    k=rr['tf'];spread=2.5 if recv=='beam' else 5
    R=1.10*(Ls+spread*k)*matr['fy']*rr['tw']/ga1
    check(name+'_receiving_web_local_yield',N,R,'NBR5.7.3 endbranch beam/interior column; uncredited root radius',k_lower_bound=k)
    footprint=tg+12;exempt=footprint<.15*rr['bf'];assert exempt
    seams[name]=dict(L=Ls,N=N,S=S,M=0,qn=qn,qs=qs,flange_bending_exempt=True,footprint=footprint,threshold=.15*rr['bf'],compression_modes='not_active_normal_is_tension')
# Joint assigned tractions: sharp rectangles intentionally leave catalog root area uncredited.
b=cat['beam'];c=cat['column'];Af=b['bf']*b['tf'];Aw=(b['d']-2*b['tf'])*b['tw'];A0=2*Af+Aw;h0=b['d']-b['tf'];N=T['Fx'];M=T['M'];nw=N*Aw/A0;ft=N*Af/A0-M/h0;fb=N*Af/A0+M/h0
assert abs(ft+fb+nw-N)<1e-7;assert abs((fb-ft)*h0/2-M)<1e-7
for name,F in [('top',ft),('bottom',fb)]:
    check('joint_'+name+'_CJP_and_beam_flange',F,Af*mats['beam']['fy']/ga1,'NBR Table9 matching CJP full throat13.2 length167; base yield',signed_force=F)
    if F>0:check('joint_'+name+'_beam_flange_net',F,Af*mats['beam']['fu']/ga2,'NBR6.5.3 tensile flange only; full unperforated area',signed_force=F)
webL=220;Rw=2*weld_q(5)*webL
check('joint_web_two_fillets',hypot(nw,T['Fy']),Rw,'NBR Table9 combined vector')
check('joint_web_base_combined',sqrt((nw/(webL*b['tw']))**2+3*(T['Fy']/(webL*b['tw']))**2),mats['beam']['fy']/ga1,'NBR6.5 elastic yield normal/shear')
check('joint_web_base_shear_rupture',T['Fy'],.6*mats['beam']['fu']*webL*b['tw']/ga2,'NBR6.5.5')

check('joint_web_column_flange_contact_yield',sqrt((nw/(webL*10))**2+3*(T['Fy']/(webL*10))**2),mats['column']['fy']/ga1,'NBR6.5 receiver substrate; two5mm contact strips')
check('joint_web_column_flange_contact_normal_rupture',nw,mats['column']['fu']*webL*10/ga2,'NBR6.5.3 receiver substrate')
check('joint_web_column_flange_contact_shear_rupture',T['Fy'],.6*mats['column']['fu']*webL*10/ga2,'NBR6.5.5 receiver substrate')
check('joint_web_receiver_local_yield_no_spread',nw,1.10*webL*c['tw']*mats['column']['fy']/ga1,'DG29 no repeated5k; NBR5.7.3 lower-bound zero spread')
# Column flange local bending applies to actual tensile bottom flange width167 >.15bf.
check('column_bottom_flange_local_bending',fb,6.25*c['tf']**2*mats['column']['fy']/ga1,'NBR5.7.2 interior distance')
# Each beam flange local normal load. Baseline unreinforced capacity shown; continuity pair carries FULL force independently.
for name,F in [('top',ft),('bottom',fb)]:
    check('column_'+name+'_web_local_yield',F,1.10*(5*c['tf']+b['tf'])*mats['column']['fy']*c['tw']/ga1,'NBR5.7.3 with k=tf lower-bound')
# Same-case overlap: no duplicated web-yield spread between top flange and upper gusset.
# Union spans actual beam-flange start through the actual end of the column gusset seam.
union_L=g['column_seam'][1][1]-(cat['beam']['d']/2-cat['beam']['tf'])
check('column_top_flange_gusset_overlap_union',abs(ft)+abs(Hc),1.10*(union_L+5*c['tf'])*mats['column']['fy']*c['tw']/ga1,'NBR5.7.3 one5k for connected overlapping spread union; absolute simultaneous forces, no cancellation credit',actual_union_span=union_L,normal_demands=[ft,Hc])
# Actual top compression makes5.7.4 active even tensileP.
crip=.66*c['tw']**2*(1+3*(b['tf']/c['d'])*(c['tw']/c['tf'])**1.5)*sqrt(E*mats['column']['fy']*c['tf']/c['tw'])/ga1
check('column_top_compression_web_crippling',ft,crip,'NBR5.7.4 interior compression branch')
# Independent actual continuity plates. Entire F assigned, without reusing web/flange resistance.
cp=g['continuity'];ts=cp['t'];bs=140;bn=110;net=2*bn*ts;gross=2*bs*ts;ms=mats['continuity']
# Supplement full stiffener-column model even though sidesway prevented and no external opposing pair.
webstrip=25*c['tw'];Aweb=webstrip*c['tw'];As=gross+Aweb
Iy=2*ts*((4.95+bs)**3-4.95**3)/3+webstrip*c['tw']**3/12
hc=c['d']-2*c['tf'];Le=.75*hc;Ne=pi*pi*E*Iy/Le**2;fy_eff=min(ms['fy'],mats['column']['fy']);lam=sqrt(As*fy_eff/Ne);chi=.658**(lam*lam) if lam<=1.5 else .877/lam**2
check('continuity_top_compression_buckling',ft,chi*As*fy_eff/ga1,'NBR5.7.9.4 optional full column supplement;25tw strip;0.75h; min fy lower bound',A=As,I=Iy,Le=Le,lambda0=lam,chi=chi)
check('continuity_top_compression_net_yield',ft,net*ms['fy']/ga1,'NBR5.7.9 actual clipped net section',An=net)
check('continuity_bottom_gross_tension',fb,gross*ms['fy']/ga1,'NBR5.7.9.1')
check('continuity_bottom_net_rupture',fb,2*100*ts*ms['fu']/ga2,'NBR5.7.9.1 connected area100mm each, excludes end5mm unwelded strips')
for name,F in [('top',ft),('bottom',fb)]:
    for edge,eff in [('loaded_flange',100),('web',207.2),('opposite_flange',100)]:
        # Opposite flange connection deliberately full-strength specified; transfer allF to web makes opposite demand0.
        demand=F*(sqrt(1+(6*85/207.2)**2) if edge=='web' else 1) if edge!='opposite_flange' else 0
        check('continuity_'+name+'_'+edge+'_weld',demand,4*weld_q(6)*eff,'NBR5.7.9; two plates, two faces; web weld includes perplate F*85/2 couple' ,effective_length_each=eff)
        check('continuity_'+name+'_'+edge+'_base_shear',demand,min(.6*ms['fy']*4*6*eff/ga1,.6*ms['fu']*4*6*eff/ga2),'NBR6.5.5 four physical contact paths')
# Actual receiving steel at each continuity weld: shared column web is counted once.
for name,F in [('top',ft),('bottom',fb)]:
    check('continuity_'+name+'_column_web_receiver_shear',F,min(.6*mats['column']['fy']*c['tw']*207.2/ga1,.6*mats['column']['fu']*c['tw']*207.2/ga2),'NBR6.5.5 common column web; min(tw,4s)=tw9.9, not four full web thicknesses')
    check('continuity_'+name+'_column_flange_receiver_shear',F,min(.6*mats['column']['fy']*2*min(c['tf'],12)*100/ga1,.6*mats['column']['fu']*2*min(c['tf'],12)*100/ga2),'NBR6.5.5 distinct column steel; two separated plate contact strips')
# Per-plate eccentric web traction: Fx uniform, Fz linear x, zero net Fz.
# Opposed plates have mirrored Fz, so common web normal stress is NOT doubled.
for name,F in [('top',ft),('bottom',fb)]:
    sigz=3*abs(F)*85/(207.2**2*12)
    taux=abs(F)/(207.2*c['tw'])
    check('continuity_'+name+'_column_web_combined_receiver',sqrt(sigz**2+3*taux**2),mats['column']['fy']/ga1,'NBR6.5 local receiver combined screen; oppositeface qz creates through-web normal stress, common web shear thickness9.9 once',sigma_z=sigz,tau_x=taux)
    check('continuity_'+name+'_column_web_normal_rupture',sigz,mats['column']['fu']/ga2,'NBR6.5.3 reciprocal normal traction')
# Normal stress yield in flange material directly aligned with continuity net footprints.
for name,F in [('top',ft),('bottom',fb)]:
    check('column_'+name+'_continuity_contact_net_yield',F,net*mats['column']['fy']/ga1,'Normal load transfer through column flange into clipped continuity pair; net contact area')
# Uniform receiving traction gives affine shear: endpoints are complete envelope.
q_b=-T['Fy'];q_a=q_b-Vb # sign convention beam internal Fy on rightward cut
beam_shear=[-T['Fy'],-T['Fy']+Vb] # left column→beam is−T; rightward balance results magnitudes25.992,50
beam_shear=[abs(T['Fy']),abs(beamcut['Fy'])]
column_shear=[abs(up['Fx']),abs(up['Fx']+Hc)]
def VR(section,mat):
    slender=(section['d']-2*section['tf'])/section['tw'];limit=1.10*sqrt(5*E/mat['fy']);assert slender<=limit
    return .6*mat['fy']*section['d']*section['tw']/ga1
Vrb=VR(b,mats['beam']);Vrc=VR(c,mats['column'])
check('beam_uniform_traction_local_web_shear',max(beam_shear),Vrb,'2021 local-web-shear uniform normal traction; NBR5.4.3',signed_endpoint_magnitudes=beam_shear)
check('column_upper_gusset_uniform_web_shear',max(column_shear),Vrc,'2021 local-web-shear uniform normal traction; NBR5.4.3',signed_endpoint_magnitudes=column_shear)
qtop=-(up['Fx']+Hc+ft);qbot=-(up['Fx']+Hc+ft+nw);Nc=max(abs(up['Fy']),abs(lower['Fy']));Npl=c['Ag']*mats['column']['fy'];fac=1 if Nc<=.4*Npl else 1.4-Nc/Npl
check('column_panel_zone',max(abs(qtop),abs(qbot)),Vrc*fac,'NBR5.7.7 actual signed panel cut with beam-web axial traction',Qtop=qtop,Qbottom=qbot,column_axial=Nc,Npl=Npl,axial_factor=fac)
check('column_lower_web_shear',abs(lower['Fx']),Vrc,'NBR5.4.3 complete lower cut')
# Local member material screen: actual bounded cut fields, no assertion of whole-member stability.
check('beam_local_NM_yield_screen',abs(beamcut['Fx'])/b['Ag']+abs(beamcut['M'])/b['Wx'],mats['beam']['fy']/ga1,'Local elastic stress screen only; global NBR5.5/member stability remains separate')
check('column_local_NM_yield_screen',Nc/c['Ag']+max(abs(up['M']),abs(lower['M']))/c['Wx'],mats['column']['fy']/ga1,'Local elastic screen with conservative concurrent envelope; not global member stability')
# Concurrent receiver material-state bounds; norm triangle, not additional capacity credit.
col_baseline=Nc/c['Ag']+max(abs(up['M']),abs(lower['M']))/c['Wx']
panel_tau=max(abs(qtop),abs(qbot))/(c['d']*c['tw'])
for name,F in [('top',ft),('bottom',fb)]:
    local_normal=3*abs(F)*85/(207.2**2*12);local_shear=abs(F)/(207.2*c['tw'])
    bound=col_baseline+local_normal+sqrt(3)*(local_shear+panel_tau)
    check('continuity_'+name+'_concurrent_column_receiver_bound',bound,mats['column']['fy']/ga1,'Conservative vonMises norm triangle combines real column N/M,panel shear,local web-weld normal/shear; no independent capacity sum',baseline_normal=col_baseline,panel_tau=panel_tau)
# Adversarial data, physically separate cases with explicit activation boundaries.
adv={}
adv['angles']=[dict(phi=p,**ufm(p),compressed_beam_receiving=ufm(p)['Vb']<0,production_behavior=('needs_gusset_compression_path' if ufm(p)['Vb']<0 else 'recompute_geometry_and_all_checks')) for p in [30,40,45,50,60,80]]
adv['offset']={'perpendicular_mm':100,'P':P,'force_point': [100*sin(radians(45)),-100*cos(radians(45))], 'positive_offset_direction':'right-hand normal(sin(phi),-cos(phi))', 'additional_M':P*100,'behavior':'UNVERIFIED until selected DG29 eccentric redistribution evaluated; cannot reusezeroM'}
adv['double_count']={'wrong_joint':wrong,'beam_equilibrium_residual_at_J':wrong_beam_res,'correct_complete_cut_recovery':recovered}
adv['panel_axial']={'upper_compression':.8*Npl,'lower_compression':.8*Npl-(V-50000),'Npl':Npl,'factor':.6,'Rd':Vrc*.6,'same_Qmax':max(abs(qtop),abs(qbot)),'utilization':max(abs(qtop),abs(qbot))/(Vrc*.6)}
# Load-zone union test: two normal forces on same web area, no duplicate5k. Use declared100mm zones.
fy=mats['column']['fy'];tw=c['tw'];k=c['tf'];ln=100;gap=10;Rone=1.10*(ln+5*k)*fy*tw/ga1;Runion=1.10*(2*ln+gap+5*k)*fy*tw/ga1
adv['overlap']={'zone_centers':[0,110],'zone_L':100,'F_each':500000,'naive_individual_R':Rone,'naive_each_utilization':500000/Rone,'union_R':Runion,'combined_utilization':1000000/Runion,'expected':'FAIL_UNION_despite_each_PASS','basis':'NBR5.7.3 used once for connected union of overlapping spread intervals; no capacity doublecount'}
adv['actual_compressed_receiver']={'brace_P_positive':P,'top_flange_signed':ft,'active_check':'column_top_compression_web_crippling','top_continuity_buckling_active':True,'expected':'PASS_COMPRESSION_CHECKS, never waive becausePpositive'}
adv['material_isolation']={'column_fy345_Rpanel':Vrc,'column_fy250_Rpanel':.6*250*c['d']*c['tw']/ga1,'beam_R_unchanged':Vrb,'angle_gross_R_unchanged':ang['Ag']*ma['fy']/ga1}
detail={'root_weld_leg':g['root_fillet_leg'],'gusset_root_lengths':{k:v['L'] for k,v in seams.items()},'continuity_geometry_unchanged':True}
# Low-degree real-root isolation (derivative recursion), independent of numpy/production.
def peval(c,x):
    v=0.
    for z in reversed(c):v=v*x+z
    return v
def pder(c):return [k*c[k] for k in range(1,len(c))]
def roots(c,lo=-1.,hi=1.):
    while len(c)>1 and abs(c[-1])<1e-14:c=c[:-1]
    if len(c)==1:return []
    if len(c)==2:
        x=-c[0]/c[1];return [x] if lo<=x<=hi else []
    critical=roots(pder(c),lo,hi);knots=[lo]+critical+[hi];ans=[]
    for x in knots:
        if abs(peval(c,x))<1e-10:ans.append(x)
    for left,right in zip(knots,knots[1:]):
        if peval(c,left)*peval(c,right)>=0:continue
        for _ in range(70):
            mid=(left+right)/2
            if peval(c,left)*peval(c,mid)<=0:right=mid
            else:left=mid
        ans.append((left+right)/2)
    return sorted(set(round(x,13) for x in ans))
def pmul(a,b):
    c=[0.]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):c[i+j]+=x*y
    return c
stiff=[];Lweb=207.2;Aeach=12*140
for name,F in [('top',ft),('bottom',fb)]:
    Fh=F/2;results=[]
    for sign in [-1,1]:
        sn=[.5+sign*6/140*7.5,.5+sign*6/140*28.75,0,-sign*6/140*21.25]
        sh=[2.25*85/Lweb,0,-2.25*85/Lweb];ss=pmul(sn,sn);tt=pmul(sh,sh)
        for i,z in enumerate(tt):ss[i]+=3*z
        ts=[-1,1]+roots(pder(ss))
        for station in ts:results.append(dict(t=station,edge=sign,VM=abs(Fh)/Aeach*sqrt(max(0,peval(ss,station)))))
    governing=max(results,key=lambda x:x['VM'])
    # Root-clipped terminal interval has N=Fh,M=Fh*(b-110)/2,A=12b.
    # Peakstress f(b)=Fh/(12b)*(4-330/b), b110..140; its only maximum atb165 lies outside, hence b140.
    clippeak=abs(Fh)/(12*140)*(4-330/140)
    check('continuity_'+name+'_plate_equilibrated_NVM',max(governing['VM'],clippeak),ms['fy']/ga1,'Statically admissible perplate load/shear/couple; exact polynomial extrema; conservative same-section normal+peak rectangular shear',governing=governing,terminal_clip_peak=clippeak)
    stiff.append(dict(name=name,F_each=Fh,webline_e=85,M_web=Fh*85,web_weld_demand_multiplier=sqrt(1+(6*85/Lweb)**2),governing=governing))
out={'purpose':'Independent arithmetic of common welded roots and full joint for compact bolted corner; no production code imports','inputs_file':'FIXTURE_INPUT.json','force_model':a,'joint_beam_to_column':T,'complete_cuts':{'beam':beamcut,'column_upper':up,'column_lower':lower},'equilibrium_residuals':{'gusset':gusset_res,'beam':beam_res,'column':column_res,'assembly':assembly_res},'seams':seams,'joint_distribution':{'area_basis_rectangles':A0,'catalog_area_extra_uncredited':b['Ag']-A0,'Af':Af,'Aw':Aw,'Nweb':nw,'Ftop':ft,'Fbottom':fb,'h0':h0},'continuity_per_plate_traction':stiff,'panel':{'Qtop':qtop,'Qbottom':qbot,'VRd':Vrc,'Nc':Nc,'factor':fac},'checks':checks,'details':detail,'adversarial':adv,'all_listed_checks_pass':all(x['pass_'] for x in checks)}
(ROOT/'COMMON_ORACLE.json').write_text(json.dumps(out,indent=2)+'\n')
print('common checks',len(checks),'all pass',out['all_listed_checks_pass'],'max',max((c['utilization'],c['id']) for c in checks))
