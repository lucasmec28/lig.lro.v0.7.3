"""Independently reconstructed fixture equations; no application/owner calculation import.
Reads frozen owner output only at comparison stage; own spot arithmetic is a separate file.
"""
from math import sqrt,pi,hypot
from pathlib import Path
import json,hashlib
from scipy.optimize import minimize_scalar
D=Path(__file__).parent;root=D.parent
ind=json.loads((D/'reviewer_checks.json').read_text());bl=json.loads((D/'reviewer_blocks.json').read_text());sec=json.loads((D/'reviewer_sections.json').read_text())
expected={}
def check(id,d,r):expected[id]=(float(abs(d)),float(r))
f=ind['forces'];Hb,Vb,Hc,Vc=[f[k] for k in ['Hb','Vb','Hc','Vc']];J=f['J'];top=f['joint_distribution']['Ftop'];bot=f['joint_distribution']['Fbottom'];nw=f['joint_distribution']['Nweb'];fy=250.;fyw=345.;fu=400.;fuw=450.;g1=1.1;g2=1.35;fw=485.
weld=lambda leg:leg/sqrt(2)*.6*fw/g2
shear=lambda fy,fu:min(.6*fy/g1,.6*fu/g2)
for label,nn,ss,tf,tw,spread in [('beam',Vb,Hb,13.2,7.6,2.5),('column',Hc,Vc,15.4,9.9,5.)]:
    check(label+'_root_weld',1.25*hypot(nn,ss)/250,2*weld(6))
    check(label+'_gusset_supported_section_interaction',(nn/(3000*fy/g1))**2+(ss/(3000*.6*fy/g1))**2,1.)
    check(label+'_gusset_supported_net_tension',nn,3000*fu/g2)
    check(label+'_gusset_supported_shear_rupture',ss,3000*.6*fu/g2)
    sn,st=nn/3000,ss/3000
    for typ,y,u in [('gusset',fy,fu),('receiver',fyw,fuw)]:
        check(label+'_'+typ+'_root_contact_yield',hypot(sn,sqrt(3)*st),y/g1)
        check(label+'_'+typ+'_root_contact_normal_rupture',sn,u/g2)
        check(label+'_'+typ+'_root_contact_shear_rupture',st,.6*u/g2)
    check(label+'_receiving_web_local_yield',nn,1.1*(250+spread*tf)*fyw*tw/g1)
for label,ff in [('top',top),('bottom',bot)]:check('joint_'+label+'_CJP_and_beam_flange',ff,167*13.2*fyw/g1)
check('joint_bottom_beam_flange_net',bot,167*13.2*fuw/g2)
check('joint_web_two_fillets',hypot(nw,J[1]),440*weld(5))
check('joint_web_base_combined',hypot(nw,sqrt(3)*J[1])/(220*7.6),fyw/g1)
check('joint_web_base_shear_rupture',J[1],.6*fuw*220*7.6/g2)
check('joint_web_column_flange_contact_yield',hypot(nw,sqrt(3)*J[1])/2200,fyw/g1)
check('joint_web_column_flange_contact_normal_rupture',nw,fuw*2200/g2)
check('joint_web_column_flange_contact_shear_rupture',J[1],.6*fuw*2200/g2)
check('joint_web_receiver_local_yield_no_spread',nw,1.1*220*9.9*fyw/g1)
check('column_bottom_flange_local_bending',bot,6.25*fyw*15.4**2/g1)
for lab,ff in [('top',top),('bottom',bot)]:check('column_'+lab+'_web_local_yield',ff,1.1*(5*15.4+13.2)*fyw*9.9/g1)
check('column_top_flange_gusset_overlap_union',abs(top)+Hc,1.1*((448.5-145.3)+5*15.4)*fyw*9.9/g1)
check('column_top_compression_web_crippling',top,.66*9.9**2*(1+3*13.2/308*(9.9/15.4)**1.5)*sqrt(200000*fyw*15.4/9.9)/g1)
area=2*140*12+25*9.9**2; inertia=24*((144.95)**3-4.95**3)/3+25*9.9**4/12;L=.75*(308-2*15.4);ne=pi*pi*200000*inertia/L**2;lam=sqrt(area*fy/ne);chi=.658**(lam*lam)
check('continuity_top_compression_buckling',top,chi*area*fy/g1)
check('continuity_top_compression_net_yield',top,2*110*12*fy/g1)
check('continuity_bottom_gross_tension',bot,2*140*12*fy/g1)
check('continuity_bottom_net_rupture',bot,2*100*12*fu/g2)
Q0=-(10000+Hc+top);Q1=Q0-nw;Q=max(abs(Q0),abs(Q1));base=500000/12360+37700000/1447000
for lab,ff in [('top',top),('bottom',bot)]:
    for name,ll,mul in [('loaded_flange',100.,1.),('web',207.2,sqrt(1+(6*85/207.2)**2)),('opposite_flange',100.,0.)]:
        check('continuity_'+lab+'_'+name+'_weld',ff*mul,4*weld(6)*ll)
        check('continuity_'+lab+'_'+name+'_base_shear',ff*mul,24*ll*shear(fy,fu))
    check('continuity_'+lab+'_column_web_receiver_shear',ff,9.9*207.2*shear(fyw,fuw))
    check('continuity_'+lab+'_column_flange_receiver_shear',ff,24*100*shear(fyw,fuw))
    sn=3*abs(ff)*85/(207.2**2*12);st=abs(ff)/(207.2*9.9)
    check('continuity_'+lab+'_column_web_combined_receiver',hypot(sn,sqrt(3)*st),fyw/g1)
    check('continuity_'+lab+'_column_web_normal_rupture',sn,fuw/g2)
    check('column_'+lab+'_continuity_contact_net_yield',ff,2*110*12*fyw/g1)
    check('continuity_'+lab+'_concurrent_column_receiver_bound',base+sn+sqrt(3)*(st+Q/(308*9.9)),fyw/g1)
    def vm(q,sign):
        fp=ff/2;N=fp*(1+q)/2;V=fp*1.5*85/207.2*(1-q*q);M=fp*(15/2+(70/4+3*15/4)*q-85*q**3/4)
        return hypot(N/(12*140)+sign*6*M/(12*140**2),sqrt(3)*1.5*V/(12*140))
    values=[vm(-1,sg) for sg in [-1,1]]+[vm(1,sg) for sg in [-1,1]]
    for sg in [-1,1]:
        for k in range(100):
            opt=minimize_scalar(lambda q:-vm(q,sg),bounds=(-1+2*k/100,-1+2*(k+1)/100),method='bounded',options={'xatol':1e-13});values.append(-opt.fun)
    values.append(abs(ff/2)/(12*140)*(4-330/140))
    check('continuity_'+lab+'_plate_equilibrated_NVM',max(values),fy/g1)
check('beam_uniform_traction_local_web_shear',50000,.6*fyw*317*7.6/g1)
check('column_upper_gusset_uniform_web_shear',10000+Hc,.6*fyw*308*9.9/g1)
check('column_panel_zone',Q,.6*fyw*308*9.9/g1)
check('column_lower_web_shear',50000,.6*fyw*308*9.9/g1)
check('beam_local_NM_yield_screen',30710.67811865475/6700+62300000/751400,fyw/g1)
check('column_local_NM_yield_screen',base,fyw/g1)
# Brace/bolt/gusset branch, both actual arrangements.
for count,lab in [(1,'1L'),(2,'2L-T')]:
    check(lab+'_angle_gross_each',100000/count,ind['angle']['yield_one']);check(lab+'_angle_net_effective_each',100000/count,ind['angle']['net_one'])
    for j in range(1,5):
        for plane in range(1,count+1):check(f'{lab}_bolt{j}_plane{plane}',25000/count,ind['bolts']['R_each_plane'])
        check(f'{lab}_angle_bearing{j}',25000/count,ind['bearing']['angle'][j-1]['R'])
    for z in ind['angle']['blocks']:
        path='connected_real_toe' if z['name']=='toe' else 'opposite_real_toe_catalog_complement'
        check(f"{lab}_angle_block_{path}_{z['k']}",z['D_1L']/count,z['R_each'])
for j in range(1,5):check(f'common_gusset_bearing{j}',25000,ind['bearing']['gusset'][j-1]['R'])
check('gusset_whitmore_gross',100000,ind['whitmore']['R_yield']);check('gusset_whitmore_net_supplement',100000,ind['whitmore']['R_net'])
for z,lab in zip(bl[:3],['negative','positive','tangent_U']):check('gusset_block_'+lab,z['maximum']['D'],z['maximum']['R'])
# Independent refined maximum versus the owner's separately refined scalar search.
check('gusset_actual_net_body_rupture',sec['max_sigma']['sigma_max'],fu/g2)
check('gusset_actual_net_body_yield',sec['max_VM']['VM'],fy/g1)
q=json.loads((root/'ORACLE.json').read_text());rows=q['checks']+q['common_full_joint']['checks'];comparisons=[]
for row in rows:
    name=row['id'];ex=expected.get(name)
    if ex is None:comparisons.append({'id':name,'pass':False,'error':'independent expression missing'});continue
    tol=1e-9
    deltas=[abs(row[k]-v)/max(1,abs(v)) for k,v in zip(['demand','resistance'],ex)]
    comparisons.append({'id':name,'pass':bool(max(deltas)<=tol),'expected_D':ex[0],'expected_R':ex[1],'relative_errors_DR':deltas,'relative_tolerance':tol})
out={'oracle_sha256':hashlib.sha256((root/'ORACLE.json').read_bytes()).hexdigest(),'input_sha256':hashlib.sha256((root/'FIXTURE_INPUT.json').read_bytes()).hexdigest(),'row_count':len(rows),'passed':sum(x['pass'] for x in comparisons),'all_pass':all(x['pass'] for x in comparisons),'common_rows':len(q['common_full_joint']['checks']),'new_bolted_rows':len(q['checks']),'comparisons':comparisons,'scope':'Independent arithmetic comparison of every listed force/resistance row. Governing supplemental section maximum refined independently; no production calculations imported.'}
(D/'FROZEN_COMPARISON.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='comparisons'},indent=2));print([x for x in comparisons if not x['pass']])
