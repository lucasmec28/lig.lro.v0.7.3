"""Independent spot checks from explicitly stated compact qualification input.
No application or owner calculation modules imported. N, mm, MPa.
"""
from math import sin, cos, radians, sqrt, tan, pi, hypot
import json
from pathlib import Path
out={}
P=100000.; phi=radians(45);c=cos(phi);s=sin(phi); H=P*c;V=P*s
b,t,Ag,ea=76.2,7.94,1148.,22.1
g=40.;tg=12.;n=4; db=16.;dh=dn=18.; pitch=60.;stations=[370.+j*pitch for j in range(n)]; ufree=335.
poly=[(184.,158.5),(454.,158.5),(454.,458.5),(154.,458.5),(154.,188.5)]
uv=lambda p:(p[0]*c+p[1]*s,-p[0]*s+p[1]*c)
xy=lambda u,v:(u*c-v*s,u*s+v*c)
pv=list(map(uv,poly))
def chord(u):
    vals=[]
    for a,b in zip(pv,pv[1:]+pv[:1]):
        if min(a[0],b[0])-1e-8<=u<=max(a[0],b[0])+1e-8:
            if abs(b[0]-a[0])<1e-8: vals.extend((a[1],b[1]))
            else: vals.append(a[1]+(u-a[0])*(b[1]-a[1])/(b[0]-a[0]))
    return min(vals),max(vals)
def segdistance(p,a,b):
    dx,dy=b[0]-a[0],b[1]-a[1];q=max(0,min(1,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/(dx*dx+dy*dy)))
    return hypot(p[0]-a[0]-q*dx,p[1]-a[1]-q*dy)
holes=[xy(u,0) for u in stations]
freeedges={'right':(poly[1],poly[2]),'top':(poly[2],poly[3]),'clip':(poly[4],poly[0])}
out['geometry']={'polygon':poly,'holes':holes,'uv_chords':{str(u):chord(u) for u in stations},'free_edge_nearest_bolt':{e:min(segdistance(p,*ab) for p in holes) for e,ab in freeedges.items()},'edge_max':min(12*tg,150),'angle_cg_v':ea-g,'single_angle_z':tg/2+ea,'physical_end_offset_moment_Nmm':[-(tg/2+ea)*V,(tg/2+ea)*H,-(ea-g)*P]}
An=Ag-dn*t;Ct=max(.5,1-ea/(stations[-1]-stations[0])); fy=250.;fu=400.;ga1=1.1;ga2=1.35;Fub=830.
def block(Agv,Anv,Ant): return min(.6*fy*Agv+.5*fu*Ant,.6*fu*Anv+.5*fu*Ant)/ga2
out['angle']={'Ag':Ag,'An':An,'Ct':Ct,'Ae':An*Ct,'yield_one':fy*Ag/ga1,'net_one':fu*An*Ct/ga2,'blocks':[]}
for k in range(1,5):
    L=35.+(k-1)*pitch
    for name,At in [('toe',(b-g-dn/2)*t),('opposite_toe',Ag-(b-g)*t-dn*t/2)]:
        R=block(L*t,(L-(k-.5)*dn)*t,At)
        out['angle']['blocks'].append({'k':k,'name':name,'Agv':L*t,'Anv':(L-(k-.5)*dn)*t,'Ant':At,'R_each':R,'D_1L':P*k/n,'util_1L':P*k/n/R})
boltR=.45*pi*db**2/4*Fub/ga2
out['bolts']={'R_each_plane':boltR,'D_1L_each_plane':P/n,'D_2LT_each_plane':P/(2*n),'1L_util':P/n/boltR,'2LT_util':P/(2*n)/boltR,'physical_bolts_both':n,'grip_1L':t+tg,'grip_2LT':2*t+tg}
# Along-force gusset exit is at x454 for phi45; y454 remains inside top458.5.
uforward=454./c
out['bearing']={'angle':[],'gusset':[]}
for j,u in enumerate(stations):
    for name,lc,th in [('angle',35.-dh/2 if j==0 else pitch-dh,t),('gusset',pitch-dh if j<n-1 else uforward-u-dh/2,tg)]:
        R=min(1.2*lc*th*fu,2.4*db*th*fu)/ga2
        out['bearing'][name].append({'j':j+1,'lc':lc,'R':R,'D_1L':P/n,'D_2LT':P/n/(2 if name=='angle' else 1),'util_1L':P/n/R})
ww=2*(stations[-1]-stations[0])*tan(pi/6)
out['whitmore']={'u':stations[0],'width':ww,'chord':chord(stations[0]),'halfwidth':ww/2,'A':ww*tg,'An':(ww-dn)*tg,'R_yield':ww*tg*fy/ga1,'R_net':(ww-dn)*tg*fu/ga2,'util_yield':P/(ww*tg*fy/ga1),'util_net':P/((ww-dn)*tg*fu/ga2)}
alpha=beta=165.;ec=154.;eb=158.5
Hc=ec*V/(eb+beta);Hb=H-Hc;Vb=eb*Hb/alpha;Vc=V-Vb
out['forces']={'H':H,'V':V,'Hb':Hb,'Vb':Vb,'Hc':Hc,'Vc':Vc,'seam_length':250.}
J=(154.,0.); D=(1000.,0.,-30710.67811865475,-50000.,62300000.);U=(0.,1000.,10000.,-500000.,10000000.)
def resultant(actions,about=(0.,0.)):
    return [sum(a[2] for a in actions),sum(a[3] for a in actions),sum(a[4]+(a[0]-about[0])*a[3]-(a[1]-about[1])*a[2] for a in actions)]
beamroot=(ec+alpha,eb,Hb,Vb,0.);colroot=(ec,eb+beta,Hc,Vc,0.)
tj=resultant([D,beamroot],J);L=tuple(-x for x in resultant([U,(*J,*tj),colroot],(0.,-1000.)))
out['forces'].update(J=tj,L=L,assembly_residual=resultant([D,U,(0.,-1000.,*L),(0.,0.,H,V,0.)]))
Af=167.*13.2;Aw=(317.-2*13.2)*7.6;At=2*Af+Aw;h0=317.-13.2
out['forces']['joint_distribution']={'Ftop':tj[0]*Af/At-tj[2]/h0,'Fbottom':tj[0]*Af/At+tj[2]/h0,'Nweb':tj[0]*Aw/At}
qR=2*6/sqrt(2)*.6*485./1.35
out['root_welds']={name:{'total_resultant':hypot(h,v),'q_design':1.25*hypot(h,v)/250.,'q_R':qR,'util':1.25*hypot(h,v)/(250*qR)} for name,h,v in [('beam',Hb,Vb),('column',Hc,Vc)]}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
