"""Bounded independent review of BC2..BC5 additions, no owner/production code import."""
import json, math,hashlib
from pathlib import Path
from scipy.optimize import minimize_scalar
D=Path(__file__).parent;R=D.parent;report=[]
for name in ['BC2_phi40','BC3_phi50','BC4_five_bolts','BC5_nondrilled']:
 p=R/'parameterized'/name;i=json.loads((p/'FIXTURE_INPUT.json').read_text());q=json.loads((p/'ORACLE.json').read_text());g=i['geometry'];b=g['bolted_brace'];a=i['catalog']['angle_each'];P=i['case']['P'];t=g['gusset_t'];st=b['bolt_stations_u'];n=len(st);fy=i['materials']['gusset']['fy'];fu=i['materials']['gusset']['fu'];ga=i['materials']['gamma_a2'];dn=b['physical_hole_diameter']+(0 if b['drilled'] else 2);r=dn/2;c=math.cos(math.radians(b['phi_deg']));s=math.sin(math.radians(b['phi_deg']));uv=lambda p:(c*p[0]+s*p[1],-s*p[0]+c*p[1]);poly=[uv(z) for z in g['gusset_polygon']];support=[(poly[0],poly[1]),(poly[3],poly[4])]
 def line(axis,val):
  hits=[]
  for a0,b0 in zip(poly,poly[1:]+poly[:1]):
   if min(a0[axis],b0[axis])-1e-9<=val<=max(a0[axis],b0[axis])+1e-9:
    if abs(b0[axis]-a0[axis])<1e-10:hits.extend((a0[1-axis],b0[1-axis]))
    else:hits.append(a0[1-axis]+(val-a0[axis])*(b0[1-axis]-a0[1-axis])/(b0[axis]-a0[axis]))
  return min(hits),max(hits)
 exit0=line(1,0)[1]
 def supported(u,lo,hi):
  for aa,bb in support:
   l,h=0.,1.
   for av,bv in [(aa[0]-u,bb[0]-u),(aa[1]-lo,bb[1]-lo),(hi-aa[1],hi-bb[1])]:
    if abs(av-bv)<1e-10:
     if av<0:l=2;break
    elif bv>av:l=max(l,-av/(bv-av))
    else:h=min(h,-av/(bv-av))
   if h-l>1e-9:return True
  return False
 def block(u,typ):
  capt=sum(z+r>=u-1e-8 for z in st);h=max([math.sqrt(max(0,r*r-(u-z)**2)) for z in st if abs(u-z)<=r]+[0.]);vl,vh=line(0,u)
  if typ=='U':
   if supported(u,-r,r):return None
   Ag=t*(line(1,-r)[1]+line(1,r)[1]-2*u);An=Ag;At=t*(2*r-2*h)
  else:
   if supported(u,-1e10 if typ=='L-' else 0,0 if typ=='L-' else 1e10):return None
   Ag=t*(exit0-u);An=Ag-t*sum(max(0,min(exit0,z+r)-max(u,z-r)) for z in st);At=t*((-vl if typ=='L-' else vh)-h)
  cap=min(.6*fy*Ag+.5*fu*At,.6*fu*An+.5*fu*At)/ga
  return {'u':u,'D':P*capt/n,'R':cap,'util':P*capt/n/cap}
 knots=sorted(set([z+d for z in st for d in [-r,0,r]]+[z[0] for z in poly]+[z[0] for ab in support for z in ab]));knots=[z for z in knots if st[0]-r<=z<=st[-1]+r]
 maxima={}
 for typ in ['L-','L+','U']:
  vals=[]
  for lo,hi in zip(knots,knots[1:]):
   if hi-lo<1e-6:continue
   lo+=1e-7;hi-=1e-7
   grid=[lo+(hi-lo)*j/20 for j in range(21)]
   for a0,b0 in zip(grid,grid[1:]):
    if block((a0+b0)/2,typ) is None:continue
    z=minimize_scalar(lambda u:-block(u,typ)['util'],bounds=(a0,b0),method='bounded',options={'xatol':1e-10});vals.extend([block(a0,typ),block(b0,typ),block(z.x,typ)])
  maxima[typ]=max([z for z in vals if z],key=lambda z:z['util'])
 H=P*c;V=P*s;Hc=g['ec']*V/(g['eb']+g['beta']);Hb=H-Hc;Vb=g['eb']*Hb/g['alpha'];Vc=V-Vb;forces=dict(H=H,V=V,Hb=Hb,Vb=Vb,Hc=Hc,Vc=Vc)
 cmp=[]
 def compare(label,x,y,tol=1e-9):cmp.append({'quantity':label,'expected':x,'actual':y,'pass':bool(abs(x-y)<=tol*max(1,abs(x)))})
 for k,v in forces.items():compare(k,v,q['common_full_joint']['force_model'][k])
 compare('An',a['Ag']-dn*a['t'],q['angle_An']);compare('Ct',max(.5,1-a['ec']/(st[-1]-st[0])),q['angle_Ct']);compare('per_gusset_hole',P/n,q['force_per_hole'])
 for typ,label in [('L-','negative'),('L+','positive'),('U','tangent_U')]:
  row=next(z for z in q['checks'] if z['id']=='gusset_block_'+label);compare('block_'+label+'_R',maxima[typ]['R'],row['resistance']);compare('block_'+label+'_D',maxima[typ]['D'],row['demand'])
 w=q['section_search_witnesses']['minimum_normal'];minimum=min(w['sigma_edges']);diagnostic=None
 if minimum< -1e-7:
  result_v=w['centroid_v']-w['M']/w['N'];vlo,vhi=w['chord_v'];d=min(result_v-vlo,vhi-result_v);triangle_width=3*d
  diagnostic={'u':w['u'],'N':w['N'],'M':w['M'],'V':w['V'],'elastic_sigma_min':minimum,'normal_resultant_v':result_v,'chord':[vlo,vhi],'normal_resultant_inside_section':vlo<result_v<vhi,'nonnegative_triangular_normal_stress_peak':2*w['N']/(triangle_width*t) if triangle_width>0 else None,'meaning':'At this section witness a nonnegative normal traction can carry N and M; negative elastic-linear screen is not necessary normal compression. This is not a global continuum/stability proof.'}
 report.append({'case':name,'all_comparisons_pass':all(z['pass'] for z in cmp),'comparison_count':len(cmp),'comparisons':cmp,'independent_block_maxima':maxima,'negative_screen_interpretation':diagnostic,'oracle_sha256':hashlib.sha256((p/'ORACLE.json').read_bytes()).hexdigest()})
out={'contract_sha256':hashlib.sha256((R/'BOLTED_CORNER_CONTRACT.md').read_bytes()).hexdigest(),'all_pass':all(z['all_comparisons_pass'] for z in report),'comparisons':sum(z['comparison_count'] for z in report),'cases':report,'go_scope':'Bounded method GO preserved; parameter witnesses are conventional strengths/detail successes, not a new physical gusset-stability solution.'}
(D/'FINAL_DELTA_REVIEW.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
