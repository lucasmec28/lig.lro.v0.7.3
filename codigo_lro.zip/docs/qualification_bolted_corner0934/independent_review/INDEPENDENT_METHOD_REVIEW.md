# Independent method review: bolted strong-axis corner gusset

## Final decision

**GO to implement and independently test the one-row ordinary static-tension 1L / symmetric2L-T corner method in BOLTED_CORNER_CONTRACT.md and the compact BC1 fixture.** The final contract was read and preserves the boundaries below. This is method/fixture qualification, not production, fabrication, or whole-frame certification. No application or owner artifact was changed by this reviewer.

## Primary sources actually checked

- ABNT NBR 8800:2024, printed71/PDF93, §6.1.8.2: applies the ordinary static/no-fatigue angle end-axis eccentricity exception to both bolt and fillet-weld groups. This supports 1L as well as symmetric2L-T, without pretending that one-sided geometry physically cancels.
- NBR printed41/PDF63, §5.2.5(c): actual centroid-to-shear-plane eccentricity and first-to-last-bolt connection length remain in shear lag. For BC1, ec22.1mm and Lc180mm, not zero ec for the symmetric pair.
- NBR printed90–92/PDF112–114, §§6.3.6–6.3.12: standard holes, grip, pitch, minimum edge and plate-specific maximum edge checks. The scanned §6.3.12 image was examined directly.
- NBR printed94–95/PDF116–117, §§6.5.3–6.5.6: tension, shear and both block-shear branches. A gusset is not automatically a bolted splice plate requiring Ae≤0.85Ag.
- AISC DG29 Example5.1, printed43–52/PDF51–60: genuine bolted double-angle strong-axis corner, two support paths, angle yield/effective rupture, physical gusset block and bearing checks, and general UFM. Its load factors are not substituted for the NBR factors.
- AISC Steel Interchange, March2015, “Maximum Spacing and Edge Distance Requirements,” primary publisher search text: relates spacing/edge limits to tight faying-surface contact and moisture exclusion. Verified publisher locator: https://www.aisc.org/globalassets/modern-steel/archives/2015/03/si.pdf (now redirects to issue archive). This explains purpose; it is not a new ABNT exemption. DG29 printed52 also permits its illustrated large unconnected gusset edge distance.

## Geometry and force model

BC1 uses a300×300×12mm five-sided gusset with30mm inner clip; actual beam/column seams are250mm, each double6mm fillet. Four M16/18mm drilled holes occur at u370,430,490,550mm on nominal row v0. The Gerdau L76.2×76.2×7.94 has Ag1148mm² and ec22.1mm. Gauge40 leaves actual angle centroid v−17.9mm. For1L its centroid is z±28.1mm. Both ordinary end offsets are transparent NBR idealizations; the 2L-T in-plane offset does not cancel. Externally imposed work-point or spatial offsets remain real.

The through-bolt count is four in both arrangements. Each1L bolt has one shear plane receiving P/4; each symmetric2L-T bolt has two planes each receiving P/8. Each gusset hole receives P/4 in both. There is one gusset thickness and one action field; its roots collectively transfer P once.

Free-edge nearest-bolt distances are65.091270,69.591270,127.815927mm against144mm maximum. Pitch60mm exceeds43.2mm minimum and is below190.56mm maximum. Angle end35mm, connected toe36.2mm, and stated heel/tool gap26.06mm pass the fixture dimensions. The heel value13.94mm is a declared example assumption, not a manufactured Gerdau radius or as-built verification.

## Independent numeric evidence

The reviewer separately transcribed dimensions and equations and imported no production or owner calculation modules. Every one of124 listed demand/resistance rows was reconstructed and compared:51 new bolted rows plus73 common joint rows, all pass. The frozen file identity and all comparisons are in FROZEN_COMPARISON.json. All124 rows agree at1e−9 relative tolerance, including the independently refined governing section value21.3487557364MPa. The owner refined its supplemental scalar search before final freeze; no sampled under-estimate remains in this witness.

Independent U/L cap calculations include circular deductions, crossing-hole force bounds, actual physical supported edges and free exits. U utilization0.142458293374 at u375.4mm. L maxima0.119527382864 and0.117410398292 at u437.814188mm. Center L caps370/430 remain supported and are inactive, while the distinct U witness remains active. Capacities of alternative paths are never added. Net/Whitmore and directional angle/gusset bearing match separately.

Common UFM results are Hb37.0493352121,Vb35.5898159462,Hc33.6613429066,Vc35.1208621725kN. Recovered COMPLETE_CUTS interface J is (+6.3386570934,−14.4101840538,+20kNm). Lower cut remains(−50,+479.289321881,+37.7). The entire body has numerical equilibrium closure. Actual top-flange compression and each continuity-plate eccentricity remain active. Shared receiver areas, panel and gusset are not multiplied by angle count.

## Essential checks and unnecessary gates

Essential: physical containment and tool/heel/root clearances; separate gross/effective-net angle resistance; each actual bolt plane; bearing in opposite directions on angle and gusset; real free/support block-path topology; perforated section geometry and actual captured force; shared roots and materials; signed complete-cut equilibrium; receiver overlap; individual continuity eccentricity and panel interaction. Parameter changes must regenerate these quantities and their extrema.

Do not demand an elastic-compatibility solution or FEA before using a stated admissible static UFM field. Do not add a fictitious second1L angle, erase actual offsets, assign double gusset capacity, add the brace twice to complete cuts, or reject an otherwise qualified connection solely because a supplemental stress screen is negative in the bolt-load introduction zone. Such a screen is not a proof of local continuum instability. Actual compression in a load-carrying ligament/root still needs its own resistance/stability branch.

The45kN minimum under NBR6.1.5.2 belongs to total qualifying connection action before splitting among angles. The actual complete-cut case must remain intact; any minimum-force design case must be explicitly constructed. The50%-capacity recommendation is separate and discretionary.

## Exact maximum-edge policy boundary

BC1 passes the stricter screen against every free polygon edge, so no ABNT applicability exception is needed for this GO. For parameterized geometry, identify each actual bolted-joint edge and use its plate thickness and nearest fastener. Keep support edges and remote relief edges separately classified. Do not silently transplant the old one-root rectangle's all-free-edge rule as a universal gusset shape limit, and do not silently exempt any failing edge. If another geometry fails the strict screen and no documented applicability interpretation covers that edge, report the exact detailing issue as unresolved while preserving the mechanical results. It is neither a strength failure nor proof that the whole gusset family is invalid.

## Final artifact identities

- FIXTURE_INPUT.json SHA256 c3eaf9447f67091621c8a44a1897e70cb346c935dd49cebb41937b8aa95e0060
- ORACLE.json SHA256 3c74a90b3ee88b7762c718b6a5a4ba3e4854f38fb1769a4e7abb3f23e93846ef
- Contract reviewed at SHA256 56ba6079fc768622b9eae0ff0cf4b25540a99d98c7dff5464557362dd6dd7251

No blocking method or BC1 numeric issue remains. Implementation still requires its own parameterized mechanics, negative/boundary tests, native-state, drawing/report and regression acceptance; an independently passing oracle is not a passing application.

## Bounded final-contract delta review

The final contract was reread at SHA25656ba6079fc768622b9eae0ff0cf4b25540a99d98c7dff5464557362dd6dd7251. Its added explicit mandatory45kN/§6.1.5.2 and distinct optional50%/§6.1.5.3 wording clarifies the existing requirement. Main BC1 ORACLE is unchanged. GO is reaffirmed at this final contract hash. A first implementation may leave P<45kN specifically incomplete until a separate minimum-force design case or a genuinely applicable exception is evaluated; actual COMPLETE_CUTS and P must not be overwritten. This limitation is not a strength failure or invalid physical geometry.

The separate BC2..BC5 changed-input files and PARAMETERIZATION_NOTES.md were read. An independently parameterized reviewer calculation checks60 selected deltas across four witnesses: transformed UFM forces, actual per-hole force, net angle area, shear lag, and independent refined U/L cap capacities/demands. All60 agree at1e−9 relative tolerance. See FINAL_DELTA_REVIEW.json and review_delta.py. This does not repeat or expand the base124-row audit into an asserted full changed-case release test.

BC2/BC3 contain genuine negative values in a *supplemental linear-elastic normal-stress screen*, not established mandatory normal compression. At the reported near-clip witnesses, the required normal-force positions v_R=vbar−M/N are56.068669mm inside[−3.282752,58.946201] and−50.042947mm inside[−52.606457,9.622496]. Nonnegative normal section tractions can therefore carry those N/M resultants; narrow triangular examples would peak at approximately20.61 and24.17MPa. This section witness is not a complete plate-continuum or stability solution, but demonstrates why the negative linear-screen value alone cannot establish a necessary compressed zone.

Precise safeguard: continue requiring a compression path for negative brace force or negative root normal, and for body resultants that necessarily require compression, including N<0, N≈0 with nonzero M, or (N>0) a normal-resultant line outside the actual physical section span. Use appropriate dimensional numerical tolerances. Preserve all reported negative screen values and conventional net/block/bearing/Whitmore/material checks. Do not translate the40°/50° diagnostics into an angle ban or silently waive independently established physical compression.

## Explicit minimum-design-case implementation guidance

Following the parent's choice to implement the minimum case now, the following bounded construction is accepted: for0≤P_actual<45kN retain the untouched actual complete-cut case, then add a labeled synthetic P_design45kN case along the declared tensile brace axis. Treat the same D/U and declared extra loads as explicit background boundary actions; recompute both gusset roots,J,derived lower cut, receivers,continuity and panel, then envelope the two cases component by component. This is a declared engineering design-strength case, not a claim that NBR prescribes a corresponding real frame-analysis combination. Keeping actual common-joint demands while raising only local brace demands would leave the synthetic force path disconnected.

The Robot lower-cut comparison applies only to the actual case. The synthetic lower cut is re-derived and must never be labeled an actual/Robot result. At P=0 the synthetic direction is the explicitly modeled +u tensile direction; negative P stays compression-unqualified and is not replaced by45kN. No duplicate case is needed when P_actual≥45kN. Apply the minimum once before physical angle/plane splitting. This checks the specified brace connection chain; it does not imply that every separate connection or global member has received every applicable code load case. The independent base and changed-input comparisons above do not themselves test this subsequently implemented synthetic-case code.
