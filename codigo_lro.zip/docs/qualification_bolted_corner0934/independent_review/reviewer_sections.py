"""Independent numerical check of constant-u net/gross section resultants.
Direct resultant integration. Supplemental stresses are not a pointwise elasticity solution.
"""
import json
from math import sqrt,hypot
from pathlib import Path
from scipy.optimize import minimize_scalar
c=s=sqrt(.5); r=9.;t=12.;P=100000.;st=[370.,430.,490.,550.]
poly=[(184.,158.5),(454.,158.5),(454.,458.5),(154.,458.5),(154.,188.5)]
uv=lambda p:(p[0]*c+p[1]*s,-p[0]*s+p[1]*c)
pv=[uv(p) for p in poly]
H=P*c;V=P*s;Hc=154*V/323.5;Hb=H-Hc;Vb=158.5*Hb/165;Vc=V-Vb
sources=[([uv((194.,158.5)),uv((444.,158.5))],(-Hb,-Vb)),([uv((154.,198.5)),uv((154.,448.5))],(-Hc,-Vc))]
def chord(u):
    v=[]
    for a,b in zip(pv,pv[1:]+pv[:1]):
        if min(a[0],b[0])-1e-8<=u<=max(a[0],b[0])+1e-8:
            if abs(a[0]-b[0])<1e-10:v.extend((a[1],b[1]))
            else:v.append(a[1]+(u-a[0])*(b[1]-a[1])/(b[0]-a[0]))
    return min(v),max(v)
def section(u,included=True):
    vl,vh=chord(u);half=max([sqrt(max(0,r*r-(u-v)**2)) for v in st if abs(u-v)<=r]+[0.])
    intervals=[(vl,vh)] if half==0 else [(vl,-half),(half,vh)]
    area=t*sum(b-a for a,b in intervals);cg=t*sum((b*b-a*a)/2 for a,b in intervals)/area
    I=t*sum(((b-cg)**3-(a-cg)**3)/3 for a,b in intervals)
    N=Vs=M=0.;active=[]
    for j,uj in enumerate(st):
        if (uj+r>=u if included else uj-r>=u):
            N+=P/4;M+=P/4*cg;active.append(j+1)
    for ends,(Fx,Fy) in sources:
        a,b=sorted(ends);u0,v0=a;u1,v1=b
        if u>=u1:continue
        low=max(u,u0);q=(u1-low)/(u1-u0);uc=(u1+low)/2;vc=v0+(uc-u0)*(v1-v0)/(u1-u0)
        nu=(Fx*c+Fy*s)*q;vv=(-Fx*s+Fy*c)*q
        N+=nu;Vs+=vv;M+=(uc-u)*vv-(vc-cg)*nu
    sig=[N/area-M*(v-cg)/I for v in [vl,vh]];tau=1.5*abs(Vs)/area
    return dict(u=u,included=included,A=area,cg=cg,I=I,N=N,V=Vs,M=M,sigma=sig,sigma_min=min(sig),sigma_max=max(map(abs,sig)),VM=hypot(max(map(abs,sig)),sqrt(3)*tau),tau=tau,bolts=active)
bounds=sorted(set([min(p[0] for p in pv)+1e-6,max(p[0] for p in pv)-1e-6]+[u+d for u in st for d in [-r,0,r]]+[p[0] for p in pv]+[p[0] for ends,F in sources for p in ends]))
bounds=[x for x in bounds if min(p[0] for p in pv)+1e-7<=x<=max(p[0] for p in pv)-1e-7]
records=[]
for lo,hi in zip(bounds,bounds[1:]):
    if hi-lo<1e-6:continue
    for incl in [False,True]:
        vals=[section(lo+(hi-lo)*j/40,incl) for j in range(41)]
        extra=[]
        for key,maximize in [('sigma_min',False),('VM',True),('sigma_max',True)]:
            for a,b in zip(vals,vals[1:]):
                q=minimize_scalar(lambda u:(-1 if maximize else 1)*section(u,incl)[key],bounds=(a['u'],b['u']),method='bounded')
                extra.append(section(q.x,incl))
        records.extend(vals+extra)
# Fixed dense grid independently verifies maxima; bounded optimization at broad selected extrema.
for key,maxi in [('sigma_min',False),('VM',True),('sigma_max',True)]:
    q=(max if maxi else min)(records,key=lambda q:q[key]);step=.02
    for lo,hi in zip(bounds,bounds[1:]):
        if lo-1e-8<=q['u']<=hi+1e-8:
            a=max(lo,q['u']-step);b=min(hi,q['u']+step)
            if b>a:
                z=minimize_scalar(lambda u:(-1 if maxi else 1)*section(u,q['included'])[key],bounds=(a,b),method='bounded',options={'xatol':1e-11});records.append(section(z.x,q['included']))
out={'min_all':min(records,key=lambda x:x['sigma_min']),'max_VM':max(records,key=lambda x:x['VM']),'max_sigma':max(records,key=lambda x:x['sigma_max']),'unperforated_to_first_hole':{'min_sigma':min((x for x in records if x['u']<=361+1e-9),key=lambda x:x['sigma_min']),'max_VM':max((x for x in records if x['u']<=361+1e-9),key=lambda x:x['VM'])},'notes':'Geometric resultants/net section and supplementary rectangular stress screen only; signs at bolt introduction are not new instability proof.'}
p=Path(__file__).with_suffix('.json');p.write_text(json.dumps(out,indent=2)+'\n');print(p.read_text())
