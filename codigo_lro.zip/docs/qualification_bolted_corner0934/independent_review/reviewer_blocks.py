"""Independent dense-grid plus bounded refinement of stated L and U cap families.
Uses direct polygon/line equations; imports no application/owner code.
"""
from math import sqrt,cos,sin,pi,hypot
from pathlib import Path
import json
from scipy.optimize import minimize_scalar
c=s=sqrt(.5);r=9.;dn=18.;tg=12.;fy=250.;fu=400.;ga=1.35;P=100000.;st=[370.,430.,490.,550.]
poly=[(184.,158.5),(454.,158.5),(454.,458.5),(154.,458.5),(154.,188.5)]
uv=lambda p:(p[0]*c+p[1]*s,-p[0]*s+p[1]*c)
pv=[uv(p) for p in poly]
supports=[(pv[0],pv[1]),(pv[3],pv[4])]
def chord(u):
    v=[]
    for a,b in zip(pv,pv[1:]+pv[:1]):
        if min(a[0],b[0])-1e-8<=u<=max(a[0],b[0])+1e-8:
            if abs(a[0]-b[0])<1e-10:v.extend((a[1],b[1]))
            else:v.append(a[1]+(u-a[0])*(b[1]-a[1])/(b[0]-a[0]))
    return min(v),max(v)
def exit(v):return min((454+v*s)/c,(458.5-v*c)/s)
def overlaps(u,side):
    # A physical support point must meet longitudinal and transverse retained halfplanes.
    for a,b in supports:
        lo,hi=0.,1.
        for qa,qb in [(a[0]-u,b[0]-u),(side*a[1],side*b[1])]:
            if abs(qb-qa)<1e-12:
                if qa<0:lo=2;break
            elif qb>qa:lo=max(lo,-qa/(qb-qa))
            else:hi=min(hi,-qa/(qb-qa))
        if hi-lo>1e-9:return True
    return False
def evalcap(u,side=1,kind='L'):
    retained=[j for j,v in enumerate(st) if v+r>=u-1e-10]
    N=P*len(retained)/4
    half=max([sqrt(max(0,r*r-(u-v)**2)) for v in st if abs(u-v)<=r]+[0.])
    if kind=='L':
        if overlaps(u,side):return None
        vl,vh=chord(u);width=vh if side>0 else -vl
        A=tg*(exit(0)-u)
        loss=sum(max(0,min(exit(0),v+r)-max(u,v-r)) for v in st)
        An=A-tg*loss;At=tg*(width-half)
    else:
        A=tg*(exit(-r)+exit(r)-2*u);An=A;At=tg*(2*r-2*half)
    R=min(.6*fy*A+.5*fu*At,.6*fu*An+.5*fu*At)/ga
    return dict(u=u,side=side,kind=kind,D=N,Agv=A,Anv=An,Ant=At,R=R,util=N/R,retained=[j+1 for j in retained])
bounds=sorted(set([st[0]-r,st[-1]+r]+[v+d for v in st for d in [-r,0,r]]+[p[0] for p in pv]+[p[0] for ab in supports for p in ab]))
bounds=[x for x in bounds if st[0]-r<=x<=st[-1]+r]
results=[]
for kind,side in [('L',-1),('L',1),('U',0)]:
    candidates=[]
    for lo,hi in zip(bounds,bounds[1:]):
        eps=1e-7
        lo+=eps;hi-=eps
        grid=[lo+(hi-lo)*k/100 for k in range(101)]
        for a,b in zip(grid,grid[1:]):
            if evalcap((a+b)/2,side,kind) is None:continue
            res=minimize_scalar(lambda u:-evalcap(u,side,kind)['util'],bounds=(a,b),method='bounded',options={'xatol':1e-11})
            candidates.extend([evalcap(a,side,kind),evalcap(b,side,kind),evalcap(res.x,side,kind)])
    candidates=[x for x in candidates if x is not None]
    results.append({'kind':kind,'side':side,'maximum':max(candidates,key=lambda q:q['util'])})
results.append({'centered_L':[evalcap(u,side) for u in st for side in [-1,1]]})
p=Path(__file__).with_suffix('.json');p.write_text(json.dumps(results,indent=2)+'\n');print(p.read_text())
