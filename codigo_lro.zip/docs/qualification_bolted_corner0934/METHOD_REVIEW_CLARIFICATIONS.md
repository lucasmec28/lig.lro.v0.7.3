# Independent method clarifications: minimum design case and support/free vertex

12 October2026. These bounded clarifications accompany the reviewed contract SHA25656ba6079fc768622b9eae0ff0cf4b25540a99d98c7dff5464557362dd6dd7251 and unchanged BC1 ORACLE SHA2563c74a90b3ee88b7762c718b6a5a4ba3e4854f38fb1769a4e7abb3f23e93846ef. They do not modify the frozen numerical input or oracle. The method reviewer communicated both directly to the implementation and engine-review owners.

## 1. Approved separate45kN design-strength case

For0≤P_actual<45kN, retain the actual full-joint case, complete cuts and actual force exactly as supplied. Add a clearly labeled synthetic design-strength case with P_design45kN along the declared tensile brace axis. Hold the named D/U cuts and explicitly supplied other loads as declared background boundary actions in that synthetic case. Recompute both gusset roots,J,the derived lower cut,receivers,continuity and panel. The actual and synthetic cases jointly govern through a component-by-component envelope with case provenance.

This is a declared engineering application of the minimum connection-strength requirement in NBR6.1.5.2. It is not a claim that NBR prescribes this real frame-analysis load combination. Increasing only the local brace demand while reusing the actual common-joint demand would disconnect the synthetic force path.

The user's Robot lower-cut comparison applies only to the actual case. The synthetic lower cut is re-derived and must not be labeled Robot or actual. At actual P=0, the synthetic case uses the explicitly modeled +u tensile direction; this does not alter the recorded zero actual force. Negative P remains compression-unqualified and must never be replaced by a positive45kN force. No duplicate minimum case is needed when actual P≥45kN. Apply the45kN total once, before splitting among physical angles and bolt shear planes. The separate50%-capacity recommendation in §6.1.5.3 remains discretionary.

This checks the specified brace connection chain. It does not assert that every separate connection or global member has received every applicable code-required load case. The described construction is approved; its later code implementation still requires independent acceptance of actual/synthetic separation, equilibrium, lower-cut handling and envelopes.

## 2. L-cap at a support/free-edge shared vertex

At BC1 u≈433.102903476760mm, the positive-side L cap reaches(154,458.5), the common endpoint of the column support and top free edge. Retained support contact length is zero. Treat this as an **active free-side limiting candidate**.

The contract's wording that a cap ending at a support is inactive means an endpoint in a supported edge's interior, or a detached region retaining a positive supported-contact segment. It does not exclude a shared vertex approached from its incident genuine free edge when no finite supported contact remains. A single geometric point contributes no finite distributed-support capacity in the selected model. Including the zero-contact free-side candidate is conservative.

Evaluate all incident boundary identities and the detached region's retained support measure. Do not decide this tie by whichever polygon edge is visited first. The floating representations u433.10290347676033 and u433.1029034767604 must receive the same classification under a declared geometric tolerance. Tolerance may merge roundoff-equivalent coordinates; it may not erase a meaningful positive contact length or create a physical free gap.

A cap on a supported-edge interior stays inactive even if some separate calculation of retained contact is numerically tiny. A vertex without an incident qualifying free edge is not a free exit. Physical support edges remain distinct from effective seam endpoints and margins.

The BC1 governing interior L cap u437.814188mm and all original124 demand/resistance comparisons are unaffected. This clarification makes the endpoint convention explicit for exact-station and parameterized acceptance.

## 3. Symmetric negative-side endpoint: explicit logical-witness amendment

The same free-side convention also applies to the negative L at the same two stored stations u433.10290347676033 and u433.1029034767604. Its cap reaches(454,158.5), the shared beam-support/right-free vertex, and the detached region retains zero supported-contact length. **Both negative-side records are active free-side limiting candidates**, just as their positive-side counterparts are.

The frozen ORACLE currently records these two negative entries, both named G_negative_433.1029034768, as inactive with reason transverse_end_on_supported_edge. Those are obsolete logical flags caused by selecting the support edge first at a shared vertex; they conflict with the now-explicit incident-edge convention. Independent engine acceptance is authorized to expect active=true for precisely these two identified source records. Preserve the original ORACLE bytes/hash and all original numerical strength comparisons. Record this amendment openly; do not silently edit expectations, suppress all inactive-path comparisons, or broadly whitelist other failures.

LOGICAL_WITNESS_AMENDMENTS.json identifies the exact oracle hash, record side/id/stations, original flag and corrected flag. It supplies an independent boundary-cap calculation as additional evidence. The boundary candidate remains less severe than the existing interior negative-L maximum; no governing strength row changes. Other support-interior or positive-contact candidates retain their existing inactive rule. This is a correction to two endpoint logic witnesses, not permission to relax capacity or geometric acceptance generally.

## 4. Long-joint boundary:950mm, not1270mm

The supplied NBR8800:2024 §6.3.8 (printed91/PDF113; axial_splice_scope/source/nbr-113.txt) specifies a1.20 multiplier on bolt-shear and hole-bearing design demands for bearing-type tension-member splices whose fastener-pattern length exceeds950mm in the external-force direction. The literal text refers to splices; it does not provide a documented brace-end exemption or a1270mm alternative. AISC's primary Bolting FAQ6.11.5 corroborates the nonuniformity mechanism and the related38in end-loaded-pattern threshold: https://www.aisc.org/aisc/solutions-center/engineering-faqs/6-bolting/ . This AISC corroboration does not replace NBR design factors.

For this first qualified corner adapter, adopt950mm as the conservative upper boundary for the uniform-per-bolt method in an ordinary end-loaded brace lap. Measure Lc between first and last bolt centers along the force direction. Lc=950mm remains within this stated boundary; Lc>950mm requires a specific UNVERIFIED long-joint-distribution component, with diagnostic mechanics preserved and overall approval withheld. This is a stated qualification boundary, not a physical or normative ban on designing longer connections.

The prior unexplained1270mm threshold is not accepted. Simply multiplying bolt/bearing demand by1.20 while claiming all new long-joint partial-block and body-force assumptions qualified would exceed the frozen method evidence. A later long-joint branch may use the source-prescribed factor with a documented nominal force/distribution treatment and independent acceptance; the factor must never inflate actual external P or be added again to COMPLETE_CUTS. No such later branch is claimed here. Ordinary BC1..BC5 inputs and frozen numerical results are unchanged.
