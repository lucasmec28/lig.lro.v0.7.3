"""Bounded changed-geometry qualification witnesses, not production validation."""
from pathlib import Path
import json,copy,math,subprocess,sys,shutil,hashlib
R=Path(__file__).resolve().parent;I=json.loads((R/'FIXTURE_INPUT.json').read_text());out=[]
for name,phi,width,height,stations,drilled in [('BC2_phi40',40,360,330,[375,435,495,555],True),('BC3_phi50',50,330,360,[375,435,495,555],True),('BC4_five_bolts',45,300,300,[375,420,465,510,555],True),('BC5_nondrilled',45,300,300,[370,430,490,550],False)]:
 d=copy.deepcopy(I);d['case']['id']=name;g=d['geometry'];ec=g['ec'];eb=g['eb'];g['alpha']=(width+30)/2;g['beta']=(height+30)/2;g['gusset_polygon']=[[ec+30,eb],[ec+width,eb],[ec+width,eb+height],[ec,eb+height],[ec,eb+30]];g['beam_seam']=[[ec+40,eb],[ec+width-10,eb]];g['column_seam']=[[ec,eb+40],[ec,eb+height-10]];bb=g['bolted_brace'];bb.update(phi_deg=phi,bolt_stations_u=stations,angle_free_end_u=stations[0]-35,drilled=drilled)
 d['case']['independent_conversion_witness']['Fx']=d['case']['beam_cut']['Fx']+d['case']['P']*math.cos(math.radians(phi))
 q=R/'parameterized'/name;q.mkdir(parents=True,exist_ok=True);(q/'FIXTURE_INPUT.json').write_text(json.dumps(d,indent=2)+'\n')
 for script in ['build_fixture.py','build_common_fixture.py']:shutil.copy2(R/script,q/script)
 p=subprocess.run([sys.executable,str(q/'build_fixture.py')],text=True,capture_output=True);(q/'run.log').write_text(p.stdout+p.stderr)
 if p.returncode:out.append(dict(id=name,completed=False,error=p.stderr));continue
 x=json.loads((q/'ORACLE.json').read_text());gr=max(x['checks']+x['common_full_joint']['checks'],key=lambda z:z['utilization']);paths={z['id']:z['witness'] for z in x['checks'] if z['component']=='gusset_block'}
 out.append(dict(id=name,completed=True,phi_deg=phi,plate_width=width,plate_height=height,bolt_stations=stations,drilled=drilled,all_strength_pass=x['all_strength_checks_pass'],all_details_pass=x['all_fixture_details_pass'],failed_details=[z for z in x['detailing'] if not z['pass_']],minimum_nominal_normal=x['minimum_nominal_section_normal'],governing_id=gr['id'],governing_utilization=gr['utilization'],Ct=x['angle_Ct'],An=x['angle_An'],Whitmore=x['Whitmore'],root_forces=x['common_full_joint']['force_model'],joint=x['common_full_joint']['joint_beam_to_column'],block_governing={k:{f:z[f] for f in ['u','demand','resistance','utilization']} for k,z in paths.items()},oracle_sha256=hashlib.sha256((q/'ORACLE.json').read_bytes()).hexdigest()))
(R/'PARAMETERIZED_VALIDATION.json').write_text(json.dumps(dict(purpose='Changed-input independent numerical witnesses, not production test suite',cases=out,complete=all(z['completed'] for z in out)),indent=2)+'\n')
print(json.dumps(out,indent=2))
