# Bolted 1L / 2L-T strong-axis corner gusset: implementation contract

12 October 2026. **GO to implement and independently test the conventional static-tension bolted adapters below.** This qualification changes no production file and is not approval of fabrication, WPS, erection, global member stability or a structure. It is a finite extension of the accepted strong-axis two-root corner family, not the weak-axis internal-fin connection and not the single-root column-web/beam-flange family.

The current immutable 0.9.33 application has welded `single_1L_welded` and `symmetric_2L_T_welded` corner adapters. It does not already implement a bolted corner. The 0.9.30 bolted 1L/2L-T family supplies qualified bolt/angle primitives but assumes a rectangular one-root gusset, so its completed connection result cannot be used as this completed connection.

## 1. Evidence and selected model

Primary supplied sources:

- NBR 8800:2024 + Errata1:2025, §6.1.8.2, PDF93/printed71, explicitly covers both bolt groups and fillet-weld groups at ordinary statically loaded angle ends. §§5.2.2/5.2.4/5.2.5 cover gross/net/effective tension sections; §§6.3.3,6.3.6–6.3.12 cover shear, bearing, holes, grip and detailing; §6.5.6 supplies both block-shear resistance branches. The clause is checked directly, not inferred from the welded adapter.
- AISC DG29, Example5.1, PDF51–60/printed43–52: bolted double-angle brace on a strong-axis corner with both supporting interfaces. Figures5-1/5-2 establish topology; bolt shear, angle net/shear-lag, angle/gusset block shear, directional bearing and Whitmore are conventional independent limit states. AppendixA supplies the already-qualified generalized UFM. NBR material/design factors replace AISC factors; no mixed phi/gamma factors or directional weld bonus.
- DG29 Example5.4, PDF106–116/printed98–108, corroborates the existing single-row bolt/angle connection and one-root mechanics, but is not substituted for the two-root joint.
- Souza's supplied text, tension-member and connection chapters, is supporting explanation. It does not override the corrected NBR edition or independently establish an exemption from a detailing clause.

AISC's public description confirms this guide's conventional lower-bound/UFM design basis and worked examples: https://www.aisc.org/news/new-aisc-design-guide-for-vertical-bracing-connections-now-available/ . The calculation evidence is the supplied guide itself, not a web summary.

The qualification is a conventional limit-state method with explicit nominal section screens. It does not require a new pointwise plate/contact elasticity solution or FEA solely because the brace bolts replace welds.

## 2. Physical adapters and nominal axes

Use common corner coordinates x right, y up, z normal to the gusset. Define u=(cosφ,sinφ), v=(-sinφ,cosφ). Bolt centers are r_j=u_j u + v_row v in the actual polygon. The brace extends in +u; its free end is before the first bolt. Initially the nominal row force axis goes through O, so v_row=0. A real user-specified work-point offset is a separate retained load eccentricity; it is not erased by the ordinary angle-end simplification.

One straight row, standard round holes, direct firm angle–gusset contact, no filler/stand-off or slip-resistance credit:

- 1L: one angle on one explicitly selected face; n physical bolts and one shear plane per bolt. Each angle gets P, each bolt plane P/n, each gusset hole P/n.
- 2L-T: two identical equal-leg angles, one per face, connected legs/heels aligned in projection, each bolt passes L–gusset–L. Each angle gets P/2, each physical shear plane P/(2n), each central gusset hole P/n. There is one gusset and one beam root plus one column root. These are not two gussets or two independent full-strength connections.
- Opposed-vertex angles, unequal pairs, more than one row, staggered/slot/oversize holes and eccentric bolt groups are separate unqualified adapters, not translations of this shared-through-bolt topology.

With gauge g measured from the heel, actual angle centroid is v=e_a−g relative to the row. In BC1 this is −17.9 mm. In 1L its actual z is ±(t_g/2+e_a)=±28.1 mm. For 100kN these correspond to ordinary raw in-plane end offset moment1.79kNm and out-of-plane magnitude2.81kNm. They are recorded, not claimed physically zero or calculated away by an opposite face. In 2L-T the symmetric z offsets cancel in the pair; the in-plane −17.9mm offset does not cancel.

NBR6.1.8.2 permits the selected ordinary static angle-end model to adopt the nominal bolt-row axis in the gusset midplane. This is the engineering connection-axis implementation of that clause, not a statement that actual centroids coincide. The bolt version therefore differs from the welded adapter's centroid-balanced heel/toe line loads. Ct still uses the actual catalog e_a and bolt first-to-last length Lc. Explicit spatial loads/couples, intended stand-offs, fatigue/seismic/reversal and a real joint-plane/work-point displacement are not covered by that idealization.

## 3. Bolt, angle and bearing contract

Retain independent angle/gusset/beam/column/continuity steels and bolt/weld grades. Use exact catalog Ag,e_a,b,t and identity; do not manufacture rolled radii. The actual heel/tool envelope and its source remain required for detailing, as in the existing bolted route.

Per angle:

- Rgross=Ag fy/γa1.
- An=Ag−dn t for this one-row section; Ct=max(0.5,1−e_a/Lc) using the existing qualified nominal conservative model, Lc=u_last−u_first. Rnet=Ct An fu/γa2. The applicable connected-area lower-bound alternative in NBR may only be used if separately implemented; it is not necessary for BC1.
- For each k-bolt angle end block, Lv=e_end+(u_k−u_first), Agv=t Lv, Anv=t[Lv−(k−0.5)dn]. The connected-toe Ant=t(b−g−dn/2); the opposite real-toe alternative uses the qualified nominal catalog-area complement Ag−(b−g)t−dn t/2. The heel is not a free edge. Demand is kP/(count·n).
- Block resistance is min(0.6fy Agv+0.5fu Ant,0.6fu Anv+0.5fu Ant)/γa2. Cts0.5 is a conservative choice, not an invented second plate.

Each physical bolt plane is checked separately with NBR shear coefficient appropriate to its thread location, gross shank area, fub and long-grip factor. One plane may have threads while the other does not. 1L has no second plane. Respect NBR's long connection/grip branches; do not silently extrapolate the uniform-load shortcut beyond an applicable long-joint limit.

Each physical contact wall is checked under the selected uniform-per-bolt hypothesis; capacities of adjacent holes are not pooled to hide an overloaded hole:

- Gusset force is +u: clear bearing length is pitch−dh at interior holes and the actual +u ray exit minus last center minus dh/2 at the end.
- Angle hole force is −u: the first angle hole uses e_end−dh/2; others use preceding pitch−dh.
- Rbearing=min(1.2 lc t fu,2.4 db t fu)/γa2 with deformation considered. Physical hole diameter dh determines bearing, while net deduction dn=dh for the qualified drilled case and dh+2mm for the other NBR deduction case. A deduction circle is not an enlarged physical hole.

## 4. Shared perforated polygon and real cut families

Use the existing actual convex corner polygon, the two full physical contact edges and effective seam segments as distinct geometry. Seam margins do not turn supported contact into free tear edges. Recalculate every intersection when angle/position/plate dimensions change; no BC1 slope or coordinate is a runtime constant.

Whitmore: one row gives nominal width2Lc tan30° at the first, support-side bolt. Intersect the actual polygon; BC1 has the complete stripe contained. Apply gross tension and the conservative supplemental net-area screen with the actual hole deduction. A clipped asymmetric stripe retains its actual section centroid/resultant moment. If spread reaches a supporting member, either qualify the actual connected-material contribution or conservatively exclude it with a justified resultant model; never count imaginary continuation. The first implementation may return the exact unqualified cross-interface/Whitmore component instead of banning all other brace angles.

Conventional shared-gusset block checks:

1. Each side of the row supplies an alternative one-shear L path: longitudinal cut v=0 from transverse cap u to the actual outward free exit, followed by the cap to the actual polygon side. Count the captured bolts once; never sum competing L capacities.
2. Clip the detached region against BOTH full physical support edges. A positive retained contact segment, or a cap ending at a support, makes that candidate inactive. In BC1 the center caps at370 and430mm are inactive for this physical reason, not because their forces vanish.
3. Keep actual circular deductions: longitudinal net deduction is the sum of hole diameter intervals intercepted by the shear cut; a cap crossing a nominal circular hole deducts its half chord h=sqrt[(dn/2)^2−(u−u_j)^2]. Keep the included/excluded force limits of a crossed hole. Without a contact-pressure distribution, the larger included-hole demand is a conservative envelope.
4. Evaluate centers, tangencies, polygon-edge switches and support-admissibility transitions. On each fixed-edge interval the cap distance has slope a. The interior minima of the rupture/yield branches inside a hole satisfy respectively x/h=−a and x/h=1.2fy/fu−a. These events prevent reintroducing the already-corrected0930 center-only block error.
5. Also retain the specified ordinary tangent-side U witness around the one row: two DISTINCT longitudinal legs v=−dn/2 and +dn/2, each ending at its actual outward free exit, and a transverse cap. Agv=t[(u_exit,left−u)+(u_exit,right−u)], Anv=Agv for these tangent legs, Ant=t[dn−2h] for a crossed cap. Ant=0 is a valid shear-only bound. At noncrossing caps h=0. Its included/excluded captured-bolt force remains P per row, not per face. For fixed tangent legs, interior cap minima have x/h=1.2fy/fu and1.2 for the two branches. Support/edge transitions remain mandatory. Do not copy the two-row U formula or combine this capacity with an L capacity.

These are identified conventional straight longitudinal/transverse limit-state paths, not a universal enumeration of curved cracks, an exact bearing-pressure field or a fracture-mechanics claim.

Actual body/net section checks use force-normal intersections through the one physical polygon. Deduct circular hole chords; recompute A, centroid and I. On the retained +u side sum all included bolt forces AND the portions of each support traction actually retained. Compute N,V,M about the net centroid; retain both one-sided point/hole force limits. For the stated CCW M convention, σ=N/A−M(v−vbar)/I. The conservative 1.5|V|/A VM screen is nominal, not a rigorous perforated shear field. Frozen exact station/resultant witnesses and numerically refined screen extrema are labeled separately; no interval certificate is claimed.

Conventional bearing/net/block/Whitmore plus both roots cannot be replaced by these body screens. Conversely, a local negative nominal stress in a bolt-introduction screen alone is not proof of continuum compression instability. Real negative root normals, a brace in compression, or an identified compressed gross gusset region require the specific compression path; they are not set to zero because P is tensile.

## 5. Roots and full-joint actions

For a nominal row through O, the sum of discrete physical bolt loads is (H,V,M)=(P cosφ,P sinφ,0), independent of 1L/2L-T or the longitudinal station u_j. Apply total P ONCE to the shared polygon. The generalized UFM stays:

Hc=e_c V/(e_b+β); Hb=H−Hc; Vb=e_b Hb/α; Vc=V−Vb.

Use actual positive root lengths and centroids α,β. The existing two-root weld/base/support models, matching beam-flange CJP, beam web fillets, N/M flange split, continuity per-plate eccentricity, shared receiver union and concurrent column-panel calculation remain valid under their existing material/sign/restraint/detail conditions. Geometry changes recompute them; 'unchanged model' does not mean unchanged600mm-fixture numbers.

Keep COMPLETE_CUTS exclusively for actual concurrent joint actions. At J, recover the beam→column action from the named complete beam cut plus its one gusset root contribution. Derive the lower column cut from the upper cut, J and the column gusset root. Do not add the brace contribution to complete cuts again. Demand origin, signs, combination and extra loads remain explicit. Actual zero P remains zero in the actual case. NBR6.1.5.2’s45kN minimum is mandatory unless its stated exception is applicable; §6.1.5.3’s50%-capacity recommendation remains distinct and optional. Any minimum/recommended connection design-force case is separate, applied once before angle/plane splitting, with its synthetic design-case actions labeled; it must not overwrite or impersonate an actual Robot cut.

A nonzero real work-point offset requires the chosen DG29 eccentric allocation; the source's permitted ordinary angle-CG/bolt-row offset does not authorize suppressing it.

## 6. Frozen BC1 numerical fixture

`FIXTURE_INPUT.json` is independent qualification input, not a proposed production-native file. `ORACLE.json` contains the new brace/perforated checks and independently recalculated common joint. `build_fixture.py` uses standard-library arithmetic and no production imports. `build_common_fixture.py` transparently adapts the earlier independent full-joint calculator; `COMMON_PROVENANCE.json` records that provenance. Fixture constants are not a parameterized runtime kernel.

BC1: unchanged Gerdau W310×52 beam/W310×97(H) column, continuity detail and independent steels; gusset300×300×12, inner clip30, roots250mm with two6mm fillets each, α=β165. Gerdau L76.2×7.94, Ag1148/e_a22.1, g40; four A325 db16/fub830 through bolts, dh=dn18 drilled at u370/430/490/550, v0,45°. Free angle end335. Explicit heel envelope13.94mm is a fixture assumption, not a catalog radius. Tool radius18 plus clearance2. Total P100kN and the named complete D/U cuts are preserved.

Results (forces kN unless stated):

- Ct0.877222222; An1005.08mm² per L. Angle gross260.909091, effective net261.238077. Angle connected-toe block governs the adapter: η0.451114855 for1L,0.225557428 for2L-T.
- Every physical bolt plane R55.627134; demand25 for1L,12.5 for2L-T. Common gusset hole demand25 in both.
- Whitmore width207.846097mm, net189.846097; Rgross566.852992, Rnet supplement675.008345; η0.176412582/0.148146317.
- Shared negative/positive L maxima η0.119527383/0.117410398 at u437.814188mm. Tangent U maxη0.142458293 at u375.4mm, including first crossed hole force. No capacity is doubled by2L.
- Supplemental body maximum21.348755736MPa at u371.298204mm, including both partial roots and all four bolt forces; minimum normal0 within numerical tolerance. Net-yield screenη0.093934525.
- Hb37.049335,Vb35.589816,Hc33.661343,Vc35.120862. J=(+6.338657,−14.410184,+20kNm). Flanges top−63.721227/bottom+67.944342, web N+2.115542. Actual top compression remains active.
- Lower cut remains (−50,+479.289322,+37.7kNm), because total brace and outer cuts are unchanged. All gusset/beam/column/assembly planar residuals close numerically.
- Common governing check is the conservative concurrent continuity/column receiver boundη0.538530300. Panel Qtop20.059884/Qbottom17.944342, R573.804, concurrent500kN column compression.
- All51 new strength rows,73 common strength rows and64 listed bolt/overlap detail comparisons pass. Counts are fixture audit evidence, not user input requirements, release-test counts or proof by themselves.

Independent reviewer results in `independent_review/` separately match UFM, complete-cut recovery, flange split, root weld, U/L cap extrema and supplemental net-section maximum without production imports.

## 7. Detailing interpretation and nonarbitrary domain

All dimensions/angles remain variable subject to real geometry and component checks. The compact fixture is not a300mm-only domain. Check physical hole, net ligament, tool/washer, angle free-end/toe/heel, root weld and flange access containment; minimum edge distance is to the actual relevant boundary, not a bounding rectangle that misses the clip.

For NBR6.3.12, evaluate each identified bolted-joint edge using that part's thickness and nearest fastener. Keep remote relief/support edges separately classified. Do not infer an exemption or invent a gusset-size cap from the one-root rectangle. BC1 satisfies even the stricter all-free-edge diagnostic (inner clip127.815927mm versus144mm limit). If another geometry fails that conservative screen and no documented applicability interpretation covers the edge, report that exact detailing interpretation as unresolved; retain all mechanics and do not call it a strength failure or an invalid gusset family. The unresolved broader edge interpretation does not invalidate BC1 or require further research before implementation of this qualified branch.

Initial domain: static ordinary tensile brace/end connection, one equal-leg1L or symmetric identical2L-T, one straight row, standard bearing-type bolts, direct contact; existing strong-axis corner support, continuity, CJP and complete-cut domains. Brace V/M/T, fatigue/seismic/reversal, compression, fillers, offset joint planes or unequal/disjoint rows require their specific additional adapter/path. Root/receiver compression already covered by the existing joint must remain active rather than being rejected merely because the brace is tensile.

## 8. Implementation acceptance and stopping boundary

Use distinct bolted topology/native state; preserve the old welded files and assumptions. Never present the one-root completed route as a corner result. Reuse physical primitives only where valid; replace welded angle fillets/footprints with bolts, exact connected leg and actual holes. Reuse the common welded roots/full joint after the new physical bolt resultant is established.

Required finite acceptance:

1. Compare both count modes against frozen BC1 demand/resistance and exact section/path witnesses; 1L face reversal changes actual z sign but no nominal plane strength. Verify one central plate and total P once.
2. Mutate bolt count/pitch/diameter/threads/grip, drilled deduction, gauge, heel/tool envelope and independent materials; verify per-hole failure cannot be hidden by a group sum. Test strength overload and real geometry failures distinctly.
3. Test actual polygon/angle/position changes, free-versus-supported caps and interior hole-cap minima. Geometry-invalid40/50-degree examples are not blanket angle prohibitions; use contained changed-position cases too.
4. Retain common welded2L/1L outputs and whole-joint sign/concurrency/receiver/continuity/panel tests; test that adding P twice fails equilibrium. Keep real compression and unsupported spatial/work-point cases specific.
5. Native save/reopen/import must identify the adapter, actual bolt plane count, units, finite values and assumptions. A rejected import must not mutate the accepted project. The drawing/report must show actual bolts/holes, one or two Ls, both welded roots, signed cuts and physical versus nominal axes.
6. Run focused and aggregate application tests and independent acceptance of the implementation before calling a release complete. Qualification GO is not a claim that the new production route, UI, Word/report or package has been implemented or tested.

No additional broad source hunt, historical missing bearing spreadsheet recovery or blanket FEA gate is needed to implement and test this contract. The finite output is the method, independent fixture, exact limitations and reviewer comparison.
