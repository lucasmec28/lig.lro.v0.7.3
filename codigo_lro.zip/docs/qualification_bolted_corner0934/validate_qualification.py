from pathlib import Path
import json,hashlib,subprocess,sys
R=Path(__file__).resolve().parent
x=json.loads((R/'ORACLE.json').read_text());allrows=x['checks']+x['common_full_joint']['checks'];assert len(allrows)==124;assert len({z['id'] for z in allrows})==124
assert x['all_strength_checks_pass'] and x['all_fixture_details_pass'];assert all(z['pass_'] for z in allrows);assert len(x['detailing'])==64
for resid in x['common_full_joint']['equilibrium_residuals'].values():assert max(map(abs,resid))<1e-6
for z in allrows:assert abs(z['utilization']-z['demand']/z['resistance'])<1e-10
for s in ['build_fixture.py','build_common_fixture.py']:assert 'from lro' not in (R/s).read_text() and 'import lro' not in (R/s).read_text()
par=json.loads((R/'PARAMETERIZED_VALIDATION.json').read_text());assert par['complete'] and len(par['cases'])==4
assert all(z['all_strength_pass'] and z['all_details_pass'] for z in par['cases']);assert min(z['minimum_nominal_normal'] for z in par['cases'])<0 # diagnostics preserved honestly, not suppressed
before={p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in ['ORACLE.json','COMMON_ORACLE.json']};subprocess.run([sys.executable,str(R/'build_fixture.py')],check=True,capture_output=True)
assert before=={p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in before},'Fixture regeneration changed frozen numeric output'
verdict=dict(method_status='GO_IMPLEMENTATION_WITHIN_CONTRACT',production_implementation_validated=False,base_strength_rows=124,unique_strength_ids=124,base_detail_rows=64,all_base_strength_details_pass=True,base_planar_equilibrium_closed=True,reproduction_identical=True,parameterized_witness_count=4,parameterized_negative_nominal_diagnostics_reported=True,source_production_edits=False)
(R/'QUALIFICATION_VALIDATION.json').write_text(json.dumps(verdict,indent=2)+'\n');print(json.dumps(verdict,indent=2))
