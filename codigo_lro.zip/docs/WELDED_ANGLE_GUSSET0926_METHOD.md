# Ligação soldada 1L → chapa de nó → mesa W

Versão 0.9.26-welded-angle-gusset-dev. Método local parametrizado, não aprovação de fabricação ou da estrutura. Acrescenta a 15ª família; as 14 anteriores mantêm seus motores e seus formatos nativos.

## Rota e entradas

Uma cantoneira laminada L100×100×12, uma aba diretamente encostada em uma face de chapa retangular sem furos; dois filetes longitudinais de igual comprimento; dois filetes contínuos na raiz inteira da chapa. A raiz está na face exterior da mesa do W, paralela ao eixo do membro e centrada na alma. Selecionar viga ou pilar altera a identificação/desenho e mantém o sistema local de cálculo.

O catálogo inicial da cantoneira é deliberadamente finito: ArcelorMittal L100×100×12, Ag2270mm², centroide29mm, raio interno12mm e raio de ponta6mm. A ponta tem6mm de face plana; não se representa L100×100×10 por esses valores. Há100 identidades de W laminado: o ArcelorMittal W310×165×52 do exemplo qualificado e99 W do catálogo existente. Cada registro preserva a fonte e dimensões próprias. Nos99 registros antigos, a altura livre é a altura reta sem concordâncias: k=(d−clear)/2, r=k−tf; só entram registros com clear>0 e k≥tf. Confirmar o produto fornecido, sem combinar o raio de um fabricante com as dimensões de outro. VS/CS/CVS soldados e HP não são implicitamente convertidos em W.

São variáveis: B,H,t da chapa; 0<θ<180°; posição s,n do centro das soldas; comprimento comum L; margem da extremidade livre; perna comum dos filetes longitudinais; perna comum dos filetes da raiz; largura física da faixa local; posições de ambas as extremidades do W. A geometria é recalculada, sem multiplicar coordenadas ou áreas do exemplo. Não há faixa de dimensões inventada em torno do exemplo. Uma mudança de topologia não implementada produz ocorrência explícita, sem reaproveitar caminhos anteriores.

Aço da cantoneira, chapa e W têm seleções separadas; as propriedades de cada produto/espessura são validadas. Os dois consumíveis E60/fw415 ou E70/fw485MPa também são independentes. Seleção de resistência não certifica material, compatibilidade metalúrgica, procedimento, execução ou inspeção. Esses requisitos continuam no projeto real.

## Equilíbrio e casos

Eixo s: raiz e eixo longitudinal do W. Eixo n: normal à mesa no plano da chapa. u segue a cantoneira e v é transversal, do talão à ponta. A transformação é s=Ps+u·cosθ+v·senθ e n=Pn+u·senθ−v·cosθ. Talão v=−50mm; ponta v=+50mm. As soldas vão de u=−L/2 a+L/2, e a extremidade livre de u=−L/2−margem. O centroide projetado da seção fica em v=−21mm.

A transferência balanceada conserva Ftalão=0,71N e Fponta=0,29N, uniformes sobre cada comprimento real. Nraiz=N·senθ; Vraiz=N·cosθ; Mraiz=sCG·Nraiz−nCG·Vraiz. Esse é um momento local derivado da excentricidade da força axial; não é momento aplicado à cantoneira. Se a linha da força passar pelo centroide da raiz, seu momento é zero (salvo arredondamento numérico). Não se zera um momento geometricamente existente. Transladar o ponto de aplicação sobre a mesma linha de força não altera Mraiz; θ>90° mantém o sinal negativo de Vraiz. A idealização estática fora do plano da NBR6.1.8.2 é declarada separadamente e não elimina shear lag.

N de entrada é tração estática. Compressão e V/M/T externos não são absorvidos pelo momento geométrico: permanecem na entrada com resultado fora do domínio. O caso real é preservado. Para N<45kN há caso separado45kN pela NBR6.1.5.2; o momento/cortante dessa força usa a mesma geometria, sem montar máximos desconexos. A recomendação50% da resistência local da barra da NBR6.1.5.3 é opção explícita do RT, não condição automática. Nenhuma capacidade global à compressão é deduzida.

## Geometria física e limites

Os quatro cantos de cada pegada longitudinal, a extremidade real da L e os extremos da faixa de introdução devem caber na chapa. A extremidade livre não pode invadir a pegada do filete de raiz. Cada raio longitudinal usa sua primeira interseção real com a borda superior ou lateral livre no sentido +u. As tampas transversais usam a interseção da reta com os quatro semiplanos do retângulo. O enumerador avalia as duas extremidades da solda e todas as projeções dos cantos dentro do intervalo carregado. Em cada intervalo, demanda e resistência de caminho são afins: basta examinar seus extremos para obter a razão governante. O bloco é recortado por u≥ucorte e v≤vlimite ou v≥vlimite. Se sua interseção com a raiz apoiada tem comprimento positivo, esse caminho é inadmissível; um contato pontual de canto é permitido. Família L sem candidato admissível com segmento carregado positivo é registrada como inativa, sem inventar uma borda livre ou rejeitar a ligação inteira. A ausência geométrica não dispensa os demais caminhos, envelopes ou o campo inteiramente tracionado.

NBR Tabela11 usa a parte menos espessa: mínimo3/5/6/8mm para t≤6,3/12,5/19/>19mm. A perna longitudinal não pode superar a face plana real6mm. Máximo na borda sem reforço: t para t<6,3mm ou t−1,5mm nos demais casos. Comprimento efetivo≥max(4s,40mm); sobreposição≥max(5tmenor,25mm); terminações conservam pelo menos uma perna até as bordas relevantes. Para cada extremidade física da pegada longitudinal, o afastamento à sua borda livre de saída é a distância normal: H−n, B/2−s ou s+B/2; no canto, ambas as bordas ativas são verificadas. A distância oblíqua ao longo do raio não substitui esse afastamento. A pegada tg+2sraiz deve caber na mesa W. A raiz inteira deve caber no membro.

O domínio inicial mantém L/s≤100 em ambas as interfaces. Comprimentos maiores exigem a redução de6.2.2.2(d) e coerência com a distribuição de transferência; a aplicação dá resultado específico fora do domínio, sem creditar integralmente uma solda longa. Abaixo desse limite não se credita reforço direcional de resistência.

## Estados limites e consolidação

- Cantoneira: escoamento bruto e ruptura efetiva, An=Ag. Ct=max(1−29/L;0,5), sem o antigo teto0,9/piso0,6. Ac=Ag/2 é uma alocação conservadora pela bissetriz das abas iguais, incluindo raiz compartilhada.
- Soldas longitudinais: garganta s/√2 e0,60fw/γw2; cada linha recebe sua parcela real. Os dois metais-base usam a área superficial conservadora sL, com fy/fu próprios.
- Bloco/rasgamento: NBR6.5.6, Cts0,5, γa2 em ambos os ramos. Quatro caminhos/limites geométricos da L, até sete famílias físicas da chapa e um envelope conservador para cada material. O exemplo75° conserva os13 testemunhos originais; exemplos alinhados45°/135° têm11 ativos e2 famílias L geometricamente inativas. Cada família L conserva todas as estações e seu governante. Coordenadas, áreas, ramos, demandas e motivos de inatividade constam do detalhe. O envelope da ponta usa6mm reais, não12mm nominais. Os limites inferiores extras descartam margem e ligamento transversal: um plano6L na L ou tL na chapa, com N integral. São limites conservadores, não fissuras exatas.
- Chapa: N,V restantes e M por intervalos formados pelos inícios/fins das soldas. Forças são lineares e momento quadrático; todos os limites e extremos estacionários de tensão normal são enumerados. O máximo separado de tensão normal e cisalhamento em cada intervalo forma um envelope VM conservador. Não há aceitação apenas pela tensão na raiz.
- Faixa local: extremos físicos na estação u=−L/2; contém as duas pegadas completas e espalha0–30° ao longo deL. Conserva M=−21N. Para N>0, largura≥126mm é necessária para campo inteiramente tracionado. A adaptação exige Ct>0, isto é,t<2L. A ruptura usa pico de tensão e Ct=3L²/(3L²+b²)·(1−t/(2L)); é adaptação conservadora de5.2.5(d), não afirmação de que as soldas reais estão nas bordas dessa faixa. O Ct da chapa inteira é1 por5.2.5(a). A faixa e os cortes horizontais alimentam os mesmos envelopes de escoamento/ruptura.
- Raiz: qn=N/B±6M/B² e qs=V/B; cada filete recebe metade. qprojeto=max(qpico,1,25qmédio dos módulos vetoriais extremos), suplemento explícito DG29. Área da chapa nunca é duplicada por haver dois filetes.
- W local: contato da raiz, cisalhamento/punção por duas faces longitudinais da mesa, escoamento local da alma por normal, cisalhamento longitudinal da alma por Vparalelo e triagem VM local. Na NBR5.7.3 o trecho5k muda para2,5k se qualquer ponto carregado estiver a≤d de uma extremidade. Flexão local da mesa é dispensada somente quando tg+2sraiz<0,15bf; fora disso é calculada, com metade da resistência quando distância à extremidade<10tf. As duas extremidades são consideradas.

Os16 modos usuais são consolidados antes da apresentação (17 se flexão da mesa ativa). Cada modo mostra o governante, sem transformar todos os caminhos em novas condições duplicadas. Todos os casos e primitivas permanecem no JSON de resultado e no Word detalhado. Falha em envelope conservador é comunicada como falha da triagem do método.

## Exportação para o membro e estado

Exporta Nnormal,Vparalelo,Mraiz na face da mesa, reação oposta e transporte ao centroide W: Mcentro=Mraiz−(d/2)Vparalelo. A variação de cortante transversal do membro é Nnormal; não se confunde com o cisalhamento longitudinal Vparalelo. As ações preexistentes são desconhecidas, nunca presumidas nulas. Um passe local não é passe global do apoio, nem da barra, nem da estrutura.

UI, desenho e Word mostram a mesma geometria e situação recalculada. O Word não confia em resultado passado pelo chamador. Edição remove Word obsoleto; importação JSON é atômica, recusa chaves repetidas/campos ausentes/unidades incompatíveis e não restaura um selo de aprovação antigo. Entradas inviáveis permanecem rastreáveis.

## Exemplo e fontes

Exemplo deliberadamente excêntrico400×300×10, θ75°, centro(0,150),L200,margem20,filetes5,faixa150; W Arcelor d317,bf167,tw7,6,tf13,2,r8; extremos±1000. Aço L S275JR275/410; chapa A36250/400; W A572Gr50345/450; E60fw415. N100kN: Nraiz96,592582629kN,V25,881904510kN,M−5,982285677kNm; envelope de caminhos da L0,681818182; solda talão0,544387028; chapa local0,539733333; raiz0,360590954. N200kN falha sem sair do domínio tracionado. Os13 caminhos têm regressões individuais com escala concorrente atéη1,01. A linha de força cruza a raiz em s=−61,933169mm; o momento deste exemplo não é inerente à inclinação.

Exemplos adicionais de bordas livres reais:

- 45° compacto e excêntrico, N100kN: chapa500×210×10, centro(55,105), L150, margem10, filetes5 e faixa140mm. Mraiz=−5,635533906kNm; ηgovernante=0,909090909. A tampa traseira intercepta a borda superior real.
- 45° alinhado, N45kN: chapa600×200×10, centro(110,198484809835;80,5), L65, margem20, filete longitudinal5, raiz6 e faixa150mm. Linha de força no centro da raiz, Mlocal≈0, Nraiz=Vraiz=31,819805kN; ηgovernante=0,944055944. As soldas têm saídas superiores/laterais reais; duas famílias L do lado+v estão inativas por contato com a raiz apoiada.
- 135° alinhado, N45kN: mesma chapa e soldas, centro(−50,801515190165006;80,5). Mlocal≈0 e Vraiz=−31,819805kN. Duas famílias L do lado−v estão inativas. O sinal de V e a direção de θ em relação ao eixo+s do W são preservados.

Esses exemplos demonstram o domínio local; não prometem que toda posição/inclinação terá campo de chapa inteiramente tracionado. Um caso Mlocal=0 na raiz ainda pode sair do domínio por compressão em corte interno.

Fontes: ABNT NBR8800:2024/Errata1:2025,5.2.2–5.2.5,5.7.1–5.7.3,6.1.5,6.1.8.2,6.2.2.2,6.2.6.2,6.5.3/5/6; AISC Design Guide29(2014), §4.2.4, pp32–33/Fig4-16 e exemplo5.4, pp105–108, para a excentricidade da barra axial em apoio único; também pp54–59,196–204 para componentes locais, soldas e seções; Souza,Ex9.6, usado para a partilha balanceada, não para aprovar chapa/apoio. Catálogo da L: https://orangebook.arcelormittal.com/node/220 . W do exemplo: https://constructalia.arcelormittal.com/files/W--0487915bad55d18fbfc679cd87133c88.pdf . Os fatores utilizados são NBR normais1,10/1,35, separados dos exemplos históricos.

Compressão, fadiga, sismo, 2L, chapas poligonais, raiz descentrada/discontínua e ligação direta à alma W permanecem outras rotas; não se exige FEA genericamente. A qualificação aqui é da formulação local delimitada e sua implementação testada.
