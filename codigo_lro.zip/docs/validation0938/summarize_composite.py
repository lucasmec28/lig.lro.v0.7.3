from pathlib import Path
from collections import Counter
import json,hashlib,xml.etree.ElementTree as ET
R=Path(__file__).resolve().parent; S=R/'source0938'; A=R/'aggregate_final'; B=R/'module_replacements'; O=R/'aggregate_composite'; O.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=json.loads((A/'RUN_MANIFEST.json').read_text());b=json.loads((B/'RUN_MANIFEST.json').read_text());assert a['runtime_and_tests_stable'] and b['runtime_and_tests_stable'];assert len(a['results'])==4
changed=set(b['files']); final=b['source_and_tests_sha256_after'];old=a['source_and_tests_sha256_after'];assert set(old)==set(final);assert {k for k in old if old[k]!=final[k]}==changed
for k,h in final.items():assert sha(S/k)==h,k
deps=json.loads((R/'portable_precision0938/inherited_fixture_dependency_commitments.json').read_text())
for k,h in deps['sha256'].items():assert sha(S/k)==h,k
for result in b['results']:assert result['exit_code']==0,result
assert sha(A/'RUN_MANIFEST.json')==b['original_manifest_sha256']
def cases(path,origin):
 rows=[]
 for c in ET.parse(path).getroot().findall('.//testcase'):
  module='tests/'+c.attrib['classname'].split('.')[-1]+'.py';node=module+'::'+c.attrib['name'];status='errors' if c.find('error') is not None else 'failed' if c.find('failure') is not None else 'skipped' if c.find('skipped') is not None else 'passed'
  row=dict(case=node,module=module,status=status,seconds=float(c.attrib.get('time',0)),provenance=origin,module_sha256=final[module])
  if status in ('failed','errors'):row['message']=c.find('failure' if status=='failed' else 'error').attrib.get('message','')
  rows.append(row)
 return rows
original=[]
for i in range(1,5):original.extend(cases(A/f'group{i}.xml',f'original/group{i}.xml'))
assert len({x['case'] for x in original})==len(original)
replacements=[]
for x in b['results']:replacements.extend(cases(B/x['junit'],'replacements/'+x['junit']))
removed=[x for x in original if x['module'] in changed];retained=[x for x in original if x['module'] not in changed]
assert {x['case'] for x in removed}=={x['case'] for x in replacements}
assert len({x['case'] for x in replacements})==len(replacements)
ledger=sorted(retained+replacements,key=lambda x:x['case']);assert len(ledger)==len(original)==len({x['case'] for x in ledger})
counts=Counter(x['status'] for x in ledger);failures=[x for x in ledger if x['status'] in ('failed','errors')]
assert counts['failed']==1 and counts['errors']==counts['skipped']==0,counts
assert failures[0]['case']=='tests/test_axial_double_angle.py::test_bolt_bearing_oracle_file_and_opposite_loaded_free_ends'
assert 'FileNotFoundError' in failures[0]['message'] and 'next_connection_scope/bolt_bearing_oracle.json' in failures[0]['message']
source_files={p.relative_to(S).as_posix() for p in S.glob('tests/test_*.py')};assert {x['module'] for x in ledger}==source_files
mapping=dict(replaced_modules=sorted(changed),removed_original_nodes=[x['case'] for x in removed],replacement_nodes=[x['case'] for x in replacements],retained_nodes=len(retained),replacement_nodes_count=len(replacements),all_original_nodes_present_exactly_once=True)
(O/'REPLACEMENT_MAPPING.json').write_text(json.dumps(mapping,indent=2)+'\n')
(O/'CASE_LEDGER0938.json').write_text(json.dumps(ledger,ensure_ascii=False,separators=(',',':'))+'\n')
summary=dict(complete=True,coverage_mode='Composite aggregate: original complete stable held run plus whole amended-module replacement slices.',single_final_test_tree_execution=False,runtime_identical_across_all_runs=True,runtime_and_tests_stable=True,stability_meaning='Each execution held its own test tree. Every retained node has the exact final module bytes; only amended modules were replaced in full. Runtime and fixture inputs unchanged throughout.',distinct_cases=len(ledger),passed=counts['passed'],failed=counts['failed'],errors=counts['errors'],skipped=counts['skipped'],test_files=len(source_files),original_distinct_cases=len(original),retained_original_cases=len(retained),replacement_cases=len(replacements),replacement_modules=sorted(changed),failures=failures,ledger_sha256=sha(O/'CASE_LEDGER0938.json'),mapping_sha256=sha(O/'REPLACEMENT_MAPPING.json'),counting='Only distinct pytest node IDs are counted. Superseded original module nodes are excluded. Focused/reviewer/visual/engine-comparison observations are different or overlapping units and are not added.',inherited_oracle_missing='Original external next_connection_scope/bolt_bearing_oracle.json absent. Inherited failure retained, not passed or fabricated.')
(R/'FINAL_AGGREGATE_SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
manifest=dict(provenance=summary['coverage_mode'],runtime_and_tests_stable=True,single_final_test_tree_execution=False,test_files=len(source_files),source_and_tests_sha256_after=final,original_manifest_sha256=sha(A/'RUN_MANIFEST.json'),replacement_manifest_sha256=sha(B/'RUN_MANIFEST.json'),dependency_seal_sha256=sha(R/'independent_precision/DEPENDENCY_REUSE0938.json'),dependency_files_reverified=len(deps['sha256']),changed_test_modules=sorted(changed),summary_sha256=sha(R/'FINAL_AGGREGATE_SUMMARY.json'),files={})
for folder,prefix in ((A,'original'),(B,'replacements')):
 for p in sorted(folder.iterdir()):
  if p.is_file():manifest['files'][prefix+'/'+p.name]=dict(bytes=p.stat().st_size,sha256=sha(p))
(O/'RUN_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
(R/'HELD_RUNTIME_TEST_HASHES.json').write_text(json.dumps(final,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False,indent=2))
