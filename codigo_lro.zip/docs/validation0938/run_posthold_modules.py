import hashlib,json,os,subprocess,sys,time
from concurrent.futures import ThreadPoolExecutor,as_completed
from datetime import datetime,timezone
from pathlib import Path
R=Path(__file__).resolve().parent;S=R/'source0938';O=R/'module_replacements';O.mkdir(exist_ok=True)
original=json.loads((R/'aggregate_final/RUN_MANIFEST.json').read_text()); assert original['runtime_and_tests_stable']
changes=json.loads((R/'POSTHOLD_TEST_ONLY_MANIFEST.json').read_text()); paths=[r['path'] for r in changes]
def hashes():
 return {p.relative_to(S).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for glob in ('app.py','lro/*.py','tests/test_*.py','data/*') for p in S.glob(glob) if p.is_file()}
before=hashes(); assert {k for k in before if before[k]!=original['source_and_tests_sha256_after'][k]}==set(paths)
manifest=dict(coverage_mode='Whole amended modules replace their original held-run nodes; all other nodes remain from the stable held run.',clock_note='Tool runtime clock is recorded separately from service UTC notices.',tool_runtime_started=datetime.now(timezone.utc).isoformat(),original_manifest_sha256=hashlib.sha256((R/'aggregate_final/RUN_MANIFEST.json').read_bytes()).hexdigest(),files=paths,source_and_tests_sha256_before=before)
(O/'RUN_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
def run(path):
 stem=Path(path).stem; env=os.environ.copy();env.update(PYTHONPATH=str(S)+os.pathsep+str(R.parent/'connections_audit/test_dependencies'),MPLCONFIGDIR='/tmp/lro0938_replacement_'+stem,XDG_CACHE_HOME='/tmp/lro0938_replacement_cache_'+stem)
 cmd=[sys.executable,'-m','pytest',str(S/path),'-q','--disable-warnings','--junitxml='+str(O/(stem+'.xml'))];start=time.monotonic()
 with (O/(stem+'.log')).open('w') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 result=dict(file=path,exit_code=p.returncode,seconds=time.monotonic()-start,log=stem+'.log',junit=stem+'.xml');print(json.dumps(result),flush=True);return result
with ThreadPoolExecutor(max_workers=3) as pool: results=list(pool.map(run,paths))
manifest.update(results=results,source_and_tests_sha256_after=hashes(),tool_runtime_finished=datetime.now(timezone.utc).isoformat());manifest['runtime_and_tests_stable']=manifest['source_and_tests_sha256_before']==manifest['source_and_tests_sha256_after'];assert manifest['runtime_and_tests_stable'];(O/'RUN_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('MODULE_REPLACEMENTS_COMPLETE',flush=True)
