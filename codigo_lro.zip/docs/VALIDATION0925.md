# Validação focada 0.9.25 · aços independentes 4ES/8ES

Versão: 0.9.25-independent-plate-steels-dev. Fonte aceita para o escopo finito descrito em INDEPENDENT_PLATE_STEELS0925_METHOD.md. Não é certificação de projeto ou fabricação, nem suíte completa.

## Ensaios efetivamente executados

- 523 testes focados de motor: end plates existentes, 4ES/8ES, auditorias 4E/rotulada e 95 novos ensaios de materiais independentes.
- 235 testes de controles nativos, importação, artefatos e navegação: 14 novas verificações duráveis de materiais/identidade e regressões diretamente afetadas; inclui o catálogo e acesso às 14 famílias.
- Total único: 758 nós pytest aprovados, zero falhas pendentes e zero saltos. Identificadores dos três arquivos JUnit foram deduplicados, prevalecendo a reexecução do único teste corrigido; execuções preparatórias/repetidas não aumentam o total.
- O lote nativo inicial teve 234 aprovações e uma falha de expectativa antiga: o teste omitia a categoria CJP soldada já presente no catálogo entregue 0.9.24. Foi corrigida somente essa lista esperada, sem alterar a navegação; a reexecução exata passou. O XML/log original foi conservado, junto ao resultado da rechecagem.
- Compilação Python de app.py, lro e novos testes concluída. Foram usados Python 3.12, Streamlit 1.65.0, pandas 2.2.3, matplotlib 3.10.8, python-docx 1.2.0 e pytest 9.1.1, com dependências de teste isoladas. Não houve alteração dos requisitos da aplicação.
- O registro executável de aceitação, comandos, contagem por arquivo, hashes e limitações está em validation_independent_steels0925/results.json. Os XML/logs finais e a lista de nós estão na mesma pasta.

## Revisões independentes, contadas separadamente

- Oito grupos de revisão de fonte/mecânica aprovados: 54 combinações finitas de materiais, casos mistos com sinais de M/N/V, juntas mais fracas, domínio de fonte, qualificação e fronteiras exatas. Essas combinações não são somadas como novos nós pytest deste total.
- 96 casos numéricos antigos e de mesmo aço foram comparados exatamente com a fonte 0.9.24, incluindo demandas/resistências/índices/casos e estados: sem alteração. As 655 entradas do manifesto original continuam com os mesmos SHA-256.
- 15 checkpoints independentes de interface/artefatos passaram: seletores, rascunhos das três variantes, troca de família, materiais, sinais, Word obsoleto, snapshot adulterado, JSON próprio e exemplos 0.9.24/4E antigo.
- Seis Word reais foram renderizados: 4ES positivo compacto 11 / detalhado 16 páginas; 8ES positivo 12 / 19; 8ES com desenvolvimento insuficiente 13 / 19. Total 90 páginas renderizadas. Foram inspecionadas visualmente oito páginas diretamente afetadas, além de três PNGs completos. Não se afirma inspeção manual de todas as 90 páginas.
- As páginas verificadas mostram seleção e propriedades de cada material, condição CJP, atual SHA/revisão e a falha 1,380 na junta real. Não foram vistos cortes ou sobreposições nas páginas inspecionadas; limites de página dos textos detalhados também foram conferidos automaticamente.

## Correções verificadas na revisão

1. O desenvolvimento de uma nervura Gr.50 contra chapa A36 falha com η 1,38, mesmo com chapa mais espessa ou menores ações. A diferença de nomes deixou de bloquear combinações que atendem.
2. Um ts uma ULP acima de 12,7 mm podia arredondar para a mesma capacidade multiplicada. A condição necessária de espessuras é agora comparada exatamente antes desses produtos; o caso não qualifica. Há seis novos ensaios duráveis para as três classes de aço nas duas variantes.
3. O JSON completo 8ES com três materiais tem 238362 bytes no formato legível nativo e excedia o limite antigo 200 kB. O limite finito passou a 1 MB, sem truncar verificações. Os bytes oferecidos pelo controle de download foram reabertos; importação acima do limite preserva atomicamente projeto e Word anteriores.

## Limites e identidade

Nenhum campo de entrada, família ou distribuição de parafusos foi acrescentado. Os resultados numéricos antigos permanecem; textos, desenho de materiais e revisão 4ES/8ES são atualizados. 4E/rotulada conservam suas revisões. Os exemplos mistos nativos são recalculados ao abrir.

A inspeção da interface foi por Streamlit AppTest real. Não se afirma revisão visual de um navegador interativo, suíte completa, publicação ou implantação. A errata DG39 de novembro de 2024 continua não consultada integralmente. A validação do empacotamento/launcher final pertence à etapa de distribuição, separada dos 758 testes da fonte.

Motor revisado: SHA-256 6f418e6e92669c6578f6b6c3835e942719024942df599a67da0f4574240d81c6.
