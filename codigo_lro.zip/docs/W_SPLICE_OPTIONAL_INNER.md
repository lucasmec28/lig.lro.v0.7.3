# Talas internas opcionais na emenda W convencional

## Alcance e resultado de referência

A opção `Considerar talas internas nas mesas` pertence à família convencional N/M/V. Ligada, conserva as oito peças F1/F2/F3/F4/F5/F6/W1/W2 e o método balanceado anterior. Desligada, remove fisicamente F2/F3/F5/F6. Permanecem F1/F4 e W1/W2. O modelo axial M004, sua partilha por áreas, esquema e resistências não são convertidos.

O caso W310×97, N=−600 kN, M=+120 kN·m e V=+100 kN continua com falha real quando as internas são removidas: a solicitação por plano de parafuso da mesa superior é 88,76452494873547 kN, sua resistência é 86,9173967493176 kN e η=1,021251536153864. A exibição de η=1,02 não altera FAIL. Esse testemunho não aprova o conjunto nem suas condições de montagem.

## Modelo físico e fontes

Fakury et al., §10.14.7, páginas impressas 311–320: a configuração original tem apenas uma tala externa por mesa e duas talas de alma; atribui toda a normal e momento às mesas, com h0=d−tf, e V à alma. A p.318 exemplifica corte simples nas mesas; a p.320 descreve a alternativa de talas externas e internas, com dois planos. As resistências continuam sendo as da NBR 8800:2024 com Er1:2025, sem importar coeficientes antigos do livro.

A posição real de cada tala externa tem e=(tf+t)/2 em relação à mesa do membro; os sinais superior e inferior são opostos. Seu centroide não é o centroide da mesa. Os resíduos N/M em h0 são da alocação convencional nominal, não uma prova de equilíbrio de chapas externas livres. O diagnóstico M(tf+t)/(d−tf) não é somado às ações ou a Ve.

A idealização de flexão secundária depende de W completos, idênticos e coaxiais, com mesas/alma intactas, talas externas simétricas nas duas mesas, ambas as talas de alma, pares de parafusos simétricos em pelo menos duas estações por lado, todos os fixadores e contato firme. O apoio do conjunto mesa–alma restringe a deformação da emenda. Kulak, Fisher e Struik, Guide to Design Criteria for Bolted and Riveted Joints, 2ª ed., §§8.1–8.3.1, pp.171–175, e §16.3, p.261, corroboram essa idealização e uma tala por mesa: https://www.boltcouncil.org/files/2ndEditionGuide.pdf.

Não se atribui excentricidade zero, equilíbrio exato de chapas livres ou uma exceção universal da NBR. Calços/frestas, peças destacadas, ausência de fixadores, montagem incompleta, assimetria entre mesas, fadiga, torção e flexão no eixo menor permanecem fora do método. `unsupported_detail` conserva resultados condicionais e falhas; não obtém atendimento local completo. K=1 e verificações existentes dos membros/talas permanecem.

## Partilha e contagens

Ftop=N/2−M/h0 e Fbottom=N/2+M/h0, com tração positiva. Ligada: a externa recebe F/2, cada tira interna F/4, bo=2bi e mesma espessura/material. Desligada: a externa recebe F integral; não há mecanismos, forças ou resistência de tiras ausentes. O esforço completo por parafuso da mesa é |F|/(2nf) nos dois modos. Por plano é |F|/(4nf) com internas e |F|/(2nf) sem internas. Os dois lados em série nunca têm capacidades somadas.

A alma conserva suas duas talas, vetores reais, dois planos por parafuso, V/2 por tala e todos os 84 caminhos físicos de bloco. Contagem total: 8nf+12 parafusos. Para nf=4: 44 parafusos; 88 linhas de plano ligadas e 56 desligadas, por caso de carga. Pega da mesa: tf+2t ou tf+t. Pega da alma: tw+2twcover. As políticas já existentes para pega >5db e junta >950 mm não foram ampliadas.

## Entrada ativa e compatibilidade

O componente é `0.9.6-w-inner-option-dev`, esquema nativo 2. `include_inner_flange_plates` exige booleano real. A configuração ligada é o padrão. Sem internas, `flange_bolt_gauge` é positivo finito e define o gramil real; bi e c ficam ausentes da entrada nativa ativa. Com internas, bi/c permanecem ativos e o gramil externo fica ausente.

A UI inicializa o gramil com a soma exata bi+c ao desligar; nenhum furo muda de posição nessa transição. O rascunho oculto bi/c permanece apenas na sessão, para restauração ao religar. Alterar dados inativos não altera resultados, hash, vínculo externo ou memória. Alterar modo ou gramil ativo invalida a memória e a base externa. O livro-caixa de valores aceitos preserva a precisão integral durante repetição, importação e mudança de família; a apresentação continua com até duas casas decimais.

O importador só migra o esquema 1 conhecido do componente `0.9.5-w-conventional-dev` depois de validar todos os seus campos, unidades e premissas exatos. Ele fornece `include_inner_flange_plates=true` e o gramil derivado exato, sem converter família. Campos ausentes, extras, premissas forjadas ou versões desconhecidas são rejeitados antes de mudar a UI.

Um vínculo externo legado é aceito apenas na configuração balanceada e quando o hash de todos os seus dados ativos legados continua exatamente igual, inclusive identidade int/float. O hash original permanece inalterado e a saída identifica a compatibilidade. Não há rebinding implícito. Projetos atuais usam o payload ativo canônico; o modo e o gramil ativo integram o hash. UI, SVG e Word reavaliam os dados atuais; uma aprovação fornecida pelo chamador não autentica resultados.

## Verificação

`tests/test_w_splice_optional_inner.py` verifica testemunhos independentes, 27 combinações de sinais, pisos assinados, topologia, contagens, geometria/pega/alcance, entradas inativas malformadas, migração estrita, vínculos, artistas e Word com falha preservada. `tests/test_w_splice_optional_inner_ui.py` cobre on→off→on repetido, gramil/precisão, rascunhos inativos, exemplos/perfis, navegação, importação rejeitada atomicamente e invalidação/revinculação explícita.

Os testemunhos numéricos foram copiados sem alteração de uma derivação independente por Fraction, sem importar funções do motor. A comparação completa de resultados contra a fonte 0.9.38 e a revisão independente ficam no recibo da integração. Esta alteração isolada não substitui a suíte agregada nem a conferência do executável combinado.
