# LRO 0.9.62 — auditoria das duas talas

## Mudanças concretas

1. Diâmetros quase iguais ao catálogo não provocam mais KeyError. São rejeitados sem alterar silenciosamente a entrada, como já fazia o importador.
2. Para cortante negativo, o momento do grupo de parafusos preserva o sinal correto. Equilíbrio e substituição do memorial ficam coerentes com Mg=V·eg. A simetria do grupo preserva os picos resistentes.
3. Erros de entrada/geometria impedem desenhar e baixar SVG; a tela explica o motivo. Geometrias válidas com pendência técnica ou falha resistente finita continuam desenháveis para revisão.

## O que a revisão técnica concluiu

O detalhe continua com primeira linha interna à coluna e afastamento inicial de 10 mm. Inspeção visual do desenho confirmou talas, calços, soldas e posição interna.

AISC Manual 15, páginas 10-125–10-128, distingue emendas com talas da chapa estendida da Figura 10-19c. A consulta delimitada não estabeleceu um método novo para a nervura interna perfurada soldada em três bordas. Falta justificar o caminho local pelos ligamentos e suas resistências/estabilidade, com as reações correspondentes nas soldas e receptores. Isso não exige estabilidade global das barras, não exige mover os parafusos e não é resolvido retirando avisos. A simplificação anterior de balanço na alma era excessivamente conservadora e não prova falha do conjunto real.

Nenhum modelo resistente novo foi adicionado. Os avisos anteriores permanecem. Esta é uma revisão de confiabilidade do aplicativo, não fechamento do dimensionamento integral do detalhe.

## Validação

- 44 novas regressões de cálculo; conjunto focado: 101 aprovados.
- Comparação direta com 0.9.61: 96 combinações, mesmas demandas, resistências, índices, status, geometria e pendências, tolerância 1e-12.
- 72 testes de interface/desenho aprovados, incluindo bloqueio, recuperação, importação e preservação do preset.
- Suíte completa de duas talas: 206 testes aprovados. Pacote compacto extraído: manifesto, SHA, compilação, launcher, famílias preservadas e fluxo de desenho/SVG aprovados.
- A expectativa histórica foi ajustada apenas nos oito tokens de momento assinado; fixture original preservado.

A base 0.9.61 foi preservada. Sem push, implantação ou operação no computador do usuário.
