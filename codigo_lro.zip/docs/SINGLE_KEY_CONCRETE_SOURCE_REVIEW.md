# Independent source review: complementary single-key concrete

Date: 2026-10-10 UTC. This is a scoped software/formula review, not structural project approval.

## Source decision

The finite complementary component is supportable for the explicitly bounded rectangular-key, normalweight cracked-concrete, static uniaxial model. The original NBR force state, bearing capacity and prescribed capacity-development weld actions must remain intact. An ACI component pass does not approve the full key, plate, anchorage or foundation.

Sources actually inspected: ACI 318-19 §§17.11.1–17.11.3, §§17.7.2.1–17.7.2.6, including original code/commentary text and relevant figures; supplied DG1 third edition pp79–87 and the source arithmetic; ACI official anchorage presentation; Richard T. Morgan's original Hilti/STRUCTURE explanation. Primary links:

- https://www.concrete.org/portals/0/files/pdf/webinars/ws_F23_Matthew%20Senecal.pdf
- https://www.hilti.com/engineering/articles/integrating-shear-lug-design-with-aci-anchoring-to-concrete-provisions
- Original ACI copy used by the source contract: https://www.ocf.berkeley.edu/~chiep/wp-content/uploads/2024/01/CE-123-ACI-318-19.pdf

### Confirmed provisions

1. Effective bearing starts at concrete surface for a plate above concrete, is limited to twice key thickness, and excludes grout. Physical embedment remains distinct for anchorage ratios. Bearing coefficient 1.7 and φ=0.65 are explicit.
2. Axial modifier uses externally applied signed axial force. Zero axial force has ψ=1 even where a moment creates anchor tension. Tension denominator uses the actual number of positive-tension anchors in the same force state and nominal ACI steel strength. Compression uses same-state contact area, or a clearly conservative upper bound for that modifier alone. This does not qualify a physically incorrect contact model.
3. Perpendicular edge distance starts at the loaded bearing face. Net projected area excludes effective bearing area; its ratio may exceed one for an extended key. Reversal selects the other loaded x face.
4. Parallel virtual check starts at key center. §17.11.3.2 incorporates §17.7.2.1(c), with factor two and ψed=1; §17.11.3.3 requires each corner surface to be considered. Both y edges are checked with the actual |V|, without inventing actual transverse shear.
5. The parallel point projection has a direct clause basis: the sibling §17.11.3.2 invokes the single-anchor-like virtual construction, including the center-origin half-pyramid in §17.7.2.1.1. §17.11.3.1.1's finite key-face area rule is subordinate to perpendicular §17.11.3.1. R17.11.3.2 and Hilti Figure 4a support this interpretation. Clipping the resulting virtual point rectangle to actual side boundaries/member thickness is coherent with that construction.
6. Vb uses Eq17.7.2.2.1b, coefficient nine in inch/psi/lbf units. §17.11.3.2 does not literally repeat this coefficient; it virtually applies the same lug breakout model. §17.11.3.1/R17.11.3.1 identify Eq(b) for lug Vb, and the original Hilti explanation gives Eq(b) immediately before its parallel/corner discussion. No invented anchor diameter or bearing length is justified to invoke the small-anchor Eq(a).
7. Omitting the thickness enhancement is conservative because both the direct anchor equation and Hilti's depth-adjusted lug explanation give a factor at least one. The small-member effective-ca1 proof is valid only in its all-clipped domain, with the reduced projection radius still reaching both side boundaries and the bottom. Then AVc is fixed, Vb/AVco scales as ca1^−1/2, and ψed does not decrease when ca1 is reduced. No proof for partially clipped geometry should be implied.
8. Four anchors, physical embedment ratios when rods are in tension, actual rod restraint and suitable filled/consolidated grout/inspection-hole detail remain prerequisites. Perimeter washer welding does not prove a rod is welded to the plate. Actual welded rods need the separately qualified concurrent shear-interaction treatment.

## Corrected source-contract defect

The original contract asserted the virtual point area was always no greater than a finite virtual-key net projection after clipping. This is false. With t=50 mm, d=60 mm, x bounds ±300 mm, ha=400 mm and virtual ca1=500 mm, both gross rectangles are fully clipped to 600×400 mm². Point area is 240000 mm²; finite-key net area is 237000 mm² after subtracting t×d. The point is larger.

This was reported immediately to parent, implementer and source-contract owner. The owner withdrew the universal area comparison, added a counterexample, and retained the direct code-authorized virtual single-anchor interpretation above. No arbitrary overlap deduction was introduced and no numerical strength changed solely because of the proof correction. The component's conservative descriptor refers to its stated no-enhancement/bounded assumptions, not a universal comparison with every possible finite-key projection.

## Grout and force-state qualification

Supplementary horizontal plate contact crosses actual grout. A concrete-only pressure bound must not silently bypass an incompatible/weak grout condition. The native application already has an explicit noncompliance and check for grout_fck≥2fck. The supplementary qualification must inherit this requirement and the compatible filled/consolidated detail; a numeric force-state solution alone is not physical qualification.

Type1 requires its declared uniform full-width rectangular-contact/external-rod topology. Type2 keeps its own C1/C2/T1/T2 domain and internal-row plate mechanism, including rejection of C3/T3/pure moment. Failure to qualify a force state must leave independent local edge results visible. Deep keys are not automatically prohibited: a separate limited-bearing-centroid force state can be qualified while preserving immutable top N/M/V.

## Independent verification artifacts

`derive_independent.py` imports no production modules. It constructs 20 exact/integrated statics fixtures, including signed compression, mixed contact, pure tension, zero-force row transitions and near-transition cases. Eight polygon/edge fixtures include the source example, one/two side clipping, bottom clipping, all clipping, small positive edge distance and parallel surfaces. Decimal precision is 70 digits. Source φbearing=70.72 kip and φbreakout=26.0640314657959235667 kip are reproduced without rounded intermediate capacities.

## Staged implementation outcome

Scoped review decision: **GO for integration of the declared complementary component**, for the exact stage hashes in `reviewed_stage_hashes.json`. This does not replace the parent's final integrated aggregate and artifact/package checks.

Final focused run: **142 passed in 8.12 s**. It comprises 81 independently written reviewer tests plus staged source/integration and artifact tests. Relevant reviewed files were hashed before that run; no reviewed hash changed during it (`test_hash_stability.json`). No full application aggregate was run by this reviewer.

Confirmed independently:

- Exact DG1 bearing and breakout values and polygon areas; source-equilibrium confinement remains fixture-only.
- Signed loaded-face selection, both virtual parallel surfaces, real clipping, no hidden positive thin/narrow factors or invented anchor shear inputs.
- Separate immutable top N/M/V, unchanged native full-depth state, separate ACI effective-depth state and pressure basis. Rationalized Type1 contact root retains tiny nonzero moments. Two rows and four physical rods satisfy force/moment residuals.
- The cancellation fixture leaves native Mbase=0 but supplementary Mbase=−2.325 kN·m, with positive-x rods carrying 3531.496813 N each. Its supplementary cone/steel checks use those same rod demands, while the native state has no anchor demand.
- A constructed axial-tension case has two active rods in the native state and four in the supplementary state. Their bearing modifiers use the proper state-local counts and the same documented nominal Nsa=140000 N, without φ in that denominator.
- Compression gain uses each state's own full-strip contact-area upper bound. Missing contact qualification falls back visibly to no gain. Weak grout cannot qualify the supplementary contact. Missing vent/fill/rod-restraint records remain explicit pending conditions.
- Actual welded rods require a separate interaction treatment; a perimeter-welded washer does not answer that restraint question.
- Anchorage ratios use physical h and actual active-row distance. Deep keys can pass the supported Type1 and Type2 numerical/contact domains; Type2 never invokes the Type1 mixed/pure-moment solver.
- Type2 unavailable force states and missing tensile area preserve independent local concrete failures. ψ≤0 gives zero positive bearing resistance/failure for positive V. Zero shear with missing nominal tensile area reports bearing not demanded while anchor tension remains pending. The pure bearing API enforces the ACI cast-in strength limit. A selected component’s numerical failure now precedes unrelated native-equilibrium pending in the overall headline. Invalid inputs and derived overflow are rejected without fabricated capacity.
- Existing native NBR bearing, prescribed weld actions, key-weld mechanical outputs, and column-top weld actions/checks remain unchanged when the optional component is enabled. All 15 native presets were mechanically identical to frozen096 in a separate read-only subprocess comparison (`frozen096_preset_comparison.json`).
- Physical qualification is distinguished from saved-result freshness: turning the optional concrete component off or editing only its reference text leaves existing column-weld evidence qualified. Changing actual V, key depth or fck makes that evidence stale. All-input result hashes may change without revoking unchanged physical qualification.
- Local component flags cannot become complete key/attachment/base/foundation approval. The receiving plate, anchor assembly, reinforcement/global foundation and any separately required transfer model remain outside this local pass.

### Frozen baseline audit

The reviewer edited only `key_concrete_review/` and no production or frozen source files. The source-contract owner separately corrected its own contract/fixtures following the reported mathematical defect.

`connections_work095/source` stayed byte-identical throughout this review. Runtime code and tests under `connections_work096/source` stayed byte-identical, but another ongoing release-finalization task changed three documentation/provenance files and added five aggregate-validation records. The exact observed delta is retained in `frozen_sources_unchanged.json` and was reported immediately to the parent; no blanket assertion that the whole096 directory was immutable is made.

### Limits of this sign-off

Tests use synthetic qualification records to verify software boundaries; they do not establish an actual project's material maturity, construction detail, rod restraint, transfer stiffness, or foundation design. Artifact tests check exported equations/data/polygons, status parity, stale-result refusal and report creation. Independent full visual page-by-page report review, the final integrated application aggregate, packaging and release belong to the parent/integration task.
