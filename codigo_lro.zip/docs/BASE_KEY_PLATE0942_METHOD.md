# Placa receptora da chave sob cortante puro

## Conclusão

A nova verificação calcula o escoamento por flexão da seção bruta ideal da placa receptora no eixo da chave. É uma verificação local distinta da flexão da própria chave. Resultado numérico favorável continua condicionado à integridade da seção; não encerra a transferência nem os metais-base das interfaces.

## Fonte e domínio

DG1 terceira edição, Exemplo 4.7-5, páginas impressas 89–90 (páginas PDF 99–100), inspecionadas no exemplar recebido. O exemplo despreza o efeito enrijecedor do pilar, toma a largura efetiva igual à largura da chave e emprega a resultante completa de contato.

Implementação limitada à base Tipo 1, chave retangular maciça centrada, sem enrijecedores, ações N=Mtopo=0 e V diferente de zero. Cada estado precisa apresentar uma única linha tracionada, contato no semiplano oposto (lc≤L/2) e equilíbrio verificado. Nenhum valor não nulo de N/M, por menor que seja, herda o domínio. Tipo 2, outras chaves, ações biaxiais e demais caminhos não são ampliados.

## Contrato matemático

Tlinha é a soma das DUAS barras da linha ativa. Para cada estado, separadamente:

- Mt=Tlinha·a
- Mc=C·(L−lc)/2
- MSd=max(Mt,Mc)
- Z=bh·tp²/4
- MRd=(fy,placa/1,10)·Z
- t_requerido=raiz[4·MSd·1,10/(fy,placa·bh)]

A resistência NBR da faixa retangular é a mesma base plástica da equação de espessura do balanço em 6.7.2.2: com m=σ·l²/2 e t=l·raiz[2σ/(fy/γa1)], resulta mRd=(fy/γa1)t²/4. Não é aplicado o fator AISC 0,90. Este check é ESCOAMENTO POR FLEXÃO, não uma aprovação de ruptura ou de todos os estados-limite da chapa.

C não é reduzido por bh/B. Mt e Mc não são somados como demanda: são momentos nas duas faces do corte; no domínio de cortante puro a soma reproduz |Mbase|. Conservam-se C=Tlinha e os resíduos do equilíbrio. A inversão de V espelha os lados, sem mudar a resistência.

O estado nativo já inclui Mbase=V[tp+(H+g)/2]. Quando o concreto ACI opcional está selecionado, usa-se também o seu estado atual de centroide limitado, Mbase=V[tp+g+min(H−g,2tchave)/2], com as reações e a pressão próprias. Não se resolve novamente o contato, não se acrescenta V·e outra vez e não se substituem as ações reais pelas ações prescritas Vw/Mw de dimensionamento das soldas. Estado opcional indisponível ou desatualizado permanece pendente.

## Integridade e mecanismos ainda abertos

Os quatro furos conhecidos dos chumbadores são confrontados geometricamente com a seção x=0. Interseção ou toque impede usar a seção bruta. Um furo em outra posição não é automaticamente uma falha dessa seção; pertence aos cortes e à transferência ainda pendentes.

O esquema atual não posiciona os respiros e outros furos auxiliares. Não se inventam suas dimensões nem uma área líquida. A confirmação narrativa existente do concreto não prova a seção íntegra. Assim, o resultado tem flexure_status numérico separado de status geral: este nunca é pass, permanecendo pending quando os números atendem e fail quando o escoamento calculado não atende.

NBR 6.2.5.1/Tabela 9 remete o metal-base de filetes à seção 6.5. Para fechar as duas interfaces é necessário definir cortes físicos na chave e na placa, resolver neles as componentes normais, cisalhantes e de momento do campo prescrito Vw/Mw, definir Ag/An/Ae e qualificar a interação/dominância aplicável. qx/qz trocam seus papéis normal/tangencial entre as faces vertical e horizontal. Não basta usar a resistência da garganta, duas áreas arbitrárias bh·t ou repetir min(t)/min(fy) do CJP. Não falta outro livro genérico; falta essa qualificação analítica específica.

Não se repetem a flexão/corte da própria chave, as seções fundidas CJP ou as faixas de tração 45° da Tipo 2. Ancoragem, concreto, distribuição transversal, outros cortes, ruptura, interação local, bloco/fundação e rigidez não são aprovados por este componente.

## Saídas e compatibilidade

Sem novas entradas persistidas ou mudança de versão/schema. O componente automático só aparece no domínio delimitado. App, JSON de resultados, desenho e seção editável Word usam o mesmo resultado atual. O t requerido exibido no app inclui o maior valor dos modos calculados, sem alterar os valores nativos do motor nem sugerir que mecanismos pendentes foram dimensionados. Exportação da memória/JSON rejeita resultado ausente ou desatualizado.

O modelo e os cálculos antigos fora do domínio ficam preservados. A comparação de 45 casos de bases conservou todos os checks, geometria nativa, resultados anteriores e avisos, descontando somente o novo componente e a atualização textual dentro do novo domínio.
