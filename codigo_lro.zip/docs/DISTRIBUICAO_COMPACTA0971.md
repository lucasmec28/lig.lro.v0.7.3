# Distribuição compacta 0.9.71

Identidade do pacote: `0.9.71-abertura-direta-catalogo-dev.1`. A versão do componente de cálculo `lro.models.VERSION` continua `0.9.44-beam-on-beam-partial-dev`, deliberadamente sem alteração de esquema ou motor.

## Correção de navegação

A foto de cada cartão também abre sua família pelo componente local do catálogo. O botão principal de cada cartão é **Abrir ligação** e abre diretamente a família representada. Quando essa família já está aberta, o botão passa a **Ver ligação atual**: retorna à ligação em andamento sem substituir o projeto por um preset. O escopo permanece disponível em uma informação secundária do cartão. A seleção exata por lista mantém a abertura explícita pelo botão superior. Buscar, filtrar ou voltar ao catálogo não muda os dados do projeto.

## Conteúdo preservado

A cópia compacta mantém os mesmos bytes da aplicação de execução, todos os módulos `lro`, dados e exemplos da fonte completa. Os documentos de método na raiz de `docs` e os manifestos históricos também são preservados. O catálogo visual opcional e o tema azul-marinho pertencem à interface; os formulários e desenhos de projeto continuam sendo os nativos das famílias. Miniaturas de presets são exemplos para navegação, não desenhos nem resultados do projeto atual.

São excluídos somente caches, suíte de testes, `artifact_qa` e subpastas volumosas de evidências históricas em `docs`. O resumo `docs/validation0971/SUMMARY.json` é mantido. A fonte integral e as evidências de teste ficam preservadas separadamente. Essa redução não exclui famílias, recursos, métodos ou exemplos.

## Integridade e execução

O ZIP externo contém exatamente quatro arquivos: `app.py`, `codigo_lro.zip`, `requirements.txt` e `README.md`. Mantenha os quatro juntos. O carregador verifica o SHA-256 do ZIP interno, caminhos de extração, arquivos obrigatórios, identidade do pacote e mistura de módulos de outra revisão no processo. Uma atualização exige reiniciar o processo Streamlit.

O manifesto `docs/CATALOG_SCOPE0971_MANIFEST.json` é criado exclusivamente em `compact/src`, na cópia de distribuição, e descreve esse conteúdo completo, exceto ele próprio. Nenhum manifesto histórico da fonte é atualizado. Execute `python verificar_pacote.py` depois de extrair o ZIP interno para conferir os arquivos da distribuição. A ausência do manifesto 0971 é um erro explícito; manifestos históricos não substituem o atual. Mudanças apenas de fim de linha LF/CRLF são aceitas pelo verificador; o carregador externo continua exigindo o SHA-256 exato do ZIP distribuído.

## Limites da evidência

A validação do pacote inclui CRC, SHA-256, inventário, manifesto, paridade byte a byte e abertura das 26 famílias pelos botões reais dos cartões via Streamlit AppTest, em processo novo e a partir do ZIP externo extraído. São verificados o seletor nativo, controles reais, projetos JSON nativos, seleção exata com abertura pelo botão superior, retorno ao catálogo e abertura repetida da família atual, um evento JSON real do componente de foto pelo protocolo de widgets AppTest, além das 12 proteções anteriores do carregador, duas verificações adicionais de ausência do módulo/frontend de foto e das salvaguardas de entrada inválida das emendas W.

AppTest é evidência funcional, não screenshot nem validação visual em navegador. Não são iniciados servidor, socket, navegador, publicação, push ou deploy. Testes de software não equivalem a aprovação estrutural de um projeto; todos os limites técnicos e pendências das famílias permanecem aplicáveis.
