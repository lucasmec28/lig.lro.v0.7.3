# Validação da versão 0.8.4

## Escopo exercitado

- Fixtures independentes da cruz e W: contato, flexão, cisalhamento, força/momento de raiz, espessura requerida e ações prescritas das soldas.
- Repartição desconhecida, igual, faixa documentada, extremos zero/um, reversão com mesas físicas preservadas e cobertura de sinal da fonte.
- Momento global com sinal, cancelamento, V zero, graute real, invariância em relação ao comprimento secundário sem crédito e ausência de duplicação de V no envelope.
- Geometria, orientação, continuidade, preenchimento, produto/material, faixas reais simétricas, exclusões, segmentos de solda e JSON com valores inválidos. NaN, infinito e inteiros além do alcance de ponto flutuante não produzem resultados favoráveis nem exceção numérica sem tratamento na validação nova.
- JSON antigo e novo, importação repetida, faixas menores importadas, alteração da geometria, alternância das três rotas e das famílias, separação do pilar e da chave, invalidação da memória e preservação de edição de solda incompleta.
- Desenho com aço físico e aço inativo, faixas reais, cotas de graute/projeção, forças dos casos alternativos e sinais. Falha no equilíbrio global não dispara desenho sem dados.
- Word com equações nativas editáveis, geometria/contato por face, repartição, ações da ligação e pendências separadas. H identifica projeção da chave; Heq identifica o braço auxiliar L/2+a no equilíbrio global.

## Evidência de cálculo

`active_plate_component_fixtures.json` contém resultados independentes esperados. `registro_numerico_v084.json` registra seis casos reproduzidos no app. São dados sintéticos, não perfis de catálogo nem dimensionamento de projeto.

A cruz de b físico 240 mm, exclusão de 20 mm e V=180 kN usa 220 mm de contato/aço e resulta em ΔM=21,744 kN·m. O W igual com V=160 kN tem faces de 200/170 mm e atende localmente; o mesmo W em envelope desconhecido não atende à flexão local. Com α=0,4, a inversão de V troca as faces e mantém as parcelas nas mesas físicas, alterando o resultado local previsto. O ΔM do W tem módulo 19,328 kN·m, em qualquer repartição.

## Rodadas de software e artefatos

Auditoria numérica independente: 430 casos e 26.562 asserções aprovados, com cálculo Decimal das capacidades/faixas, sinais/repartição, momento global único, ausência de crédito inativo, JSON e rejeição numérica. Essa auditoria é separada do pytest.

Os três exemplos finais Word (cruz, W com partilha igual e W em envelope) foram renderizados em PDF/PNG: 13 páginas cada, 39 páginas revisadas. As equações são nativas editáveis (30 na cruz; 34 em cada W). Não restaram páginas vazias, cortes, tabelas quebradas ou equações perdidas. As páginas alteradas na revisão de paginação foram reexaminadas; páginas idênticas foram comparadas por hash aos pixels já revisados.

Rodada focada de artefatos: 39 testes aprovados. Interface: 9 AppTests novos e 15 de rotas legadas aprovados. Essas contagens não são somadas à execução agregada, pois há repetição.

O registro final da execução agregada é preenchido após os testes sobre o código congelado.

Não houve publicação nem deploy. Os ensaios de software e artefatos não homologam o dispositivo completo: fixação, concreto da chave, bloco e demais exclusões continuam discriminados no produto.
