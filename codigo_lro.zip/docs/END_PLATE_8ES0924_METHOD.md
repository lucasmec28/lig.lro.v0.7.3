> Histórico do escopo original. A revisão 0.9.25 substitui a restrição de mesmo aço pela qualificação independente documentada em INDEPENDENT_PLATE_STEELS0925_METHOD.md; as equações geométricas e mecanismos desta página permanecem.

# End plate 8ES CJP · versão 0.9.24

## Escopo finito

Uma nova variante dentro da família de end plate engastada existente; continuam 14 famílias. Serviço ordinário estático com M/N/V assinados, viga I simétrica e centrada na mesa de uma coluna I contínua sem reforços. Duas nervuras externas idênticas com CJP compatível. Sem chapa fina, solução com alavanca, sismo, fadiga, viga oposta, laje participante, extremidade/abertura/emenda próxima da coluna, continuidade ou doubler. As premissas existentes de contenção da viga/coluna e axial do painel permanecem explícitas.

O nome 8ES identifica oito parafusos ativos à tração. O detalhe simétrico possui **16 parafusos físicos, oito linhas e dois parafusos por linha**. Nenhuma linha é intermediária ou recebe crédito fictício.

## Fonte e controle de edição

AISC Design Guide 39, edição 2023 fornecida: tabela 5-16 p.119, tabela A-5(a) pp269–270, tabela 5-9 p.112, exemplo 5.3-7 pp180–188; regras de desenvolvimento CJP e detalhe nas pp43,45,49,51–53. Resistências no nível NBR 8800:2024, versão corrigida 2025. A errata oficial de novembro 2024 não estava acessível e não foi declarada revisada.

O exemplo 5.3-7 tem bp=12 pol., fora do teto de 10,25 pol. +10% da tabela 5-9, e não calcula a coluna. É oráculo de componentes, não conexão completa aprovada. A ilustração da p.257 substitui h1/h4 inconsistentes com sua geometria: o oráculo mantém separados o valor literal 370,730786619 e os valores fisicamente coerentes 370,316119952 arredondado/370,347319739 exato. Isso não altera os coeficientes da tabela A-5 nem importa ações sísmicas.

## Geometria física e equações

Em mm, y=0 na face externa superior da viga, positivo para baixo. Linhas:

- −pfo−pb; −pfo; tf+pfi; tf+pfi+pb
- d−tf−pfi−pb; d−tf−pfi; d+pfo; d+pfo+pb

x=±g/2; hst=pfo+pb+de; hp=d+2hst. As linhas internas não podem cruzar ou coincidir; não são reordenadas para aparentar validade. Espaçamentos NBR, ferramenta, bordas, furos e ligamentos usam todas as linhas reais. pb padrão 70 mm, sem limite próprio inventado da tabela 5-9.

Braços ordenados do extremo tracionado: h1=d−tf/2+pfo+pb; h2=d−tf/2+pfo; h3=d−3tf/2−pfi; h4=d−3tf/2−pfi−pb. Para −M, as quatro linhas inferiores são refletidas em ordem física inversa; braços positivos idênticos.

bp,ef=min(bp;bf,viga+max(tp;25,4)); bcf,ef=min(bf,coluna;bf,viga+max(tp;25,4)). Larguras físicas continuam nos furos, seções líquidas, contato e desenho.

sP=√(bp,ef g)/2; po=min(pfo;sP); pi=min(pfi;sP).

Yp=bp,ef/2[h1/(2de)+h2/po+h3/pi+h4/sP]+2/g[h1(de+3pb/4)+h2(po+pb/4)+h3(pi+3pb/4)+h4(sP+pb/4)]+g.

Requisito estrito 0<de<sP. Igualdade fica fora da tabela 5-16 adotada. Os limites pi/po atuam apenas no Yp; não movem parafusos, braços, c, extensão ou região soldada.

sC=√(bcf,ef g)/2; c=pfo+tf+pfi.

Yc=bcf,ef/2(h1/sC+h4/sC)+2/g[h1(pb+c/2+sC)+h2(pb/2+c/4)+h3(pb/2+c/2)+h4sC]+g/2.

Os coeficientes h2·c/4 e h3·c/2 são literais. Não se usa a tabelaA-2 de 4E/4ES nem sP no lugar de sC.

## Ações e espessuras

Meq=|M|+max(N;0)(d−tf)/2; Tb=Meq/[2(h1+h2+h3+h4)]; T=8Tb; C=max(T−N;0). Vb=|V|/16 em todos os parafusos, com interação tração/cisalhamento NBR nos oito tracionados. Não se usa distribuição elástica proporcional ao braço.

tp,req ou tfc,req=√[1,10Meq·max(γa1;1/0,90)/(fy·Y)], γa1=1,10. **Ambas as espessuras**, domínio e caminho das nervuras devem estar qualificados para declarar ausência de alavanca. Não se dimensiona por uma fictícia ação igual à resistência última de todo grupo. As duas condições de espessura usam comparação exata, inclusive nos testes de um incremento de ponto flutuante.

Ff=|M|/(d−tf)+max(N;0)/2; Fc=|M|/(d−tf)+max(−N;0)/2. A alma da coluna usa max(Ff;Fc) no escoamento e Fc no enrugamento. Contato usa C; painel usa |M|/(d−tf)+|N|/2. T não é somado ou substituído por Ff.

Entrada e mínimo normativo de 45 kN são casos completos separados. f=max(1;45000/hypot(N;V)), somente para resultante não nula: escala N/V, mantém M. Cada caso verifica |N|(d−tf)≤|M|. Perda de domínio no mínimo preserva a evidência válida da Entrada e impede conclusão da conexão completa. Momento puro mantém o tratamento explícito existente, sem inventar direção para N/V nulos.

Todos os 16 blocos parciais/completos possíveis terminando nas bordas superior/inferior são calculados com as linhas físicas e as cargas correspondentes. O JSON conserva cada candidato, não apenas a resistência governante.

## Alma, nervuras e CJP

Demanda local da alma=(4/8)Ff=Ff/2. lwt=pfi+pb+152,4; hw=d−2tf; lws=min(hw−lwt;hw/2). Comprimentos físicos positivos, com zonas CJP de tração/cisalhamento disjuntas por caso. Não se descontam simultaneamente zonas de dois sinais alternativos de momento. Não se concede resistência a alma inexistente. Permanecem desenvolvimento mínimo local, metal-base receptor, CJP de mesas, tensão equivalente da seção e demais verificações retidas.

Mesmo aço qualificado A36/A572 Gr.42/A572 Gr.50 em viga/chapa/nervuras; ts≥tw·fyb/fys e ts≤min(tp;tf). E7018/fw 485 MPa, CJP contínua e compatibilidade de processo/preparação declaradas. Sem furos nas nervuras/juntas; fu/γa2≥fy/γa1 verificado, γa2=1,35. Coluna pode usar outro aço qualificado.

Nervura–chapa desenvolve fys·ts/γa1 em tração; nervura–mesa desenvolve 0,60fys·ts/γa1 em cisalhamento. Comparação de resistências de cálculo, sem misturar ação nominal com resistência reduzida. Detalhe adotado Lst≥hst/tan30°, recorte diagonal real e corridas CJP hst−recorte/Lst−recorte. Patamares de 25,4 mm são recomendação, não mínimo universal NBR. Executar alma–chapa, depois mesa–chapa, depois nervuras; sem solda pelo recorte. Esbeltez sísmica da eq3-37 não é imposta ao serviço ordinário. As duas antigas linhas de cisalhamento da extensão 4E não existem em 8ES.

## Exemplo prático e rastreabilidade

examples/end_plate_8es_cjp.json: W460×74 / W360×122(H), aços A572 Gr.50, bp210,tp12,7,g140,pfo40,pfi45,pb70,de35mm; A325 3/4 pol., fub 830 MPa; M100kNm,V40kN,N2kN; ts9,525,Lst275,clip/landing25,4mm.

Yp5685,858316317mm; Yc4102,054024211mm; tp,req7,910907026mm; tfc,req9,313729260mm. Linhas[−110,−40,59,5,129,5,327,5,397,5,497,567]mm; hp747mm. hst145mm; corridas CJP119,6/249,6mm; lwt267,4mm; lws160,6mm. O mínimo de força governa escoamento local da alma da coluna com η0,933422917955.

JSON possui revisão endplate-8es-cjp-case-envelope-0924-v1 e SHA256 das entradas; pb e campos próprios são obrigatórios. Identidade ausente não converte 8ES em4E ou rotulada. Resultado importado nunca aprova: tudo é recalculado. 4E/4ES mantêm sua identidade/digest anterior e não incluem pb inativo no JSON. Variantes mantêm rascunhos próprios; alterar entrada invalida Word antigo. SVG/PNG e Word refletem 16 furos, quatro braços, extremo ativo e duas nervuras reais. Aprovação local não substitui projeto, fornecedor, detalhamento executivo e responsável técnico.


Diâmetro no projeto nativo 8ES é a identidade exata de uma opção do seletor imperial do catálogo. Valores próximos, mas diferentes, geram diagnóstico de dado antes de qualquer busca de borda; não são arredondados nem apresentados como falha física de resistência. Essa é a mesma representação exigida pelo importador da interface. Valores legados inativos de weld, pitch, overhang e n são preservados e não impõem mínimos de filete, sobra ou número de linhas à geometria 8ES. A higiene de tipos e finitude permanece; o comportamento 4E/4ES não é alterado.
