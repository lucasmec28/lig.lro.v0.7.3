# Próxima família: cantoneiras de alma

Data: 2026-10-09. Escopo de pesquisa, sem alterações no aplicativo.

## Ordem e primeira entrega

A emenda W com compressão + M + V permanece prioritária. Esta preparação não autoriza iniciar nem publicar a família de cantoneiras antes dessa etapa; o usuário permite avançar se uma verificação ficar bloqueada aguardando material de referência.

**Primeiro candidato: R-016 / LCPP, duas cantoneiras iguais, uma de cada lado da alma da viga, parafusadas à alma e à mesa de pilar W, ligação usual sob cortante vertical.** Há roteiro analítico e exemplos suficientes para começar sem exigir elementos finitos. O primeiro caso deve ser convencional, sem recortes na viga e sem extensão intencional das abas. Expandir em seguida para R-015 e R-017, sem transformar a ausência inicial dessas variantes em impedimento da ligação convencional.

## O que existe no padrão industrial

Todos os arquivos PADRÃO DE LIGAÇÕES-1Model a -5Model têm **uma página PDF**, contendo várias páginas numeradas do caderno.

- **-2Model, R-015, página impressa 18:** duas cantoneiras; abas junto à alma soldadas à viga; abas de apoio parafusadas à mesa do pilar. Corresponde à LCSP do Gerdau. Não inverter automaticamente qual interface é soldada.
- **-2Model, R-016, página impressa 19:** duas cantoneiras, ambas as interfaces parafusadas, mesa de pilar. Corresponde à LCPP. A nota manda despachar as cantoneiras com a viga.
- **-2Model, R-017, página impressa 20:** duas cantoneiras parafusadas à alma de outra viga; aparece recorte superior e inferior, raio R12. A nota manda despachá-las com a viga, salvo indicação contrária.
- R-015/R-016 mostram tabela M16/M20/M24/M30, respectivamente e = 35/40/50/60 mm e s = 50/60/75/90 mm. O N do desenho é número de intervalos N×s, portanto n de parafusos = N+1. Z é altura livre indicada no desenho, não comprimento automático da cantoneira.
- Não identifiquei com segurança uma ligação de extremidade de viga por **cantoneira única** neste caderno. R-016 não deve ser recadastrada como cantoneira simples. As folhas 1, 3, 4 e 5 trazem notas, ligações rígidas, bases/chumbadores e miscelâneas; cantoneiras em outras funções não validam uma ligação de alma assimétrica.

## Fontes e autoridade

1. **ABNT NBR 8800:2024, versão corrigida 2025**, exemplar fornecido em baseplate_references/Automação MC: base das resistências e do detalhamento. Páginas PDF = página impressa + 22. Foram conferidas visualmente as páginas impressas 84, 85 e 95.
2. **Gerdau, Ligações para Estruturas de Aço, 7ª edição, 2018**, PDF fornecido: páginas impressas/PDF 19–27, LCPP/LCSP; p.14 gabaritos; p.22 exemplos; p.33 tabela LCPP para W360; p.50 tabela LCSP para W360. É baseado na NBR 8800:2008. Aproveitar geometria, método e casos históricos; recalcular individualmente com a NBR atual, sem fator global de conversão. A p.9 declara que os elementos de apoio não foram verificados nas tabelas.
3. **Higgins (UF, maio de 2005), tese**, exemplar completo obtido legalmente no repositório da universidade: https://ufdcimages.uflib.ufl.edu/uf/e0/00/93/61/00001/higgins_a.pdf . Cap.4, pp.20–31 (PDF31–42), distingue cantoneira simples e dupla estendidas e seus grupos excêntricos; cap.6, pp.40–47 (PDF51–58), contém exemplos separados. Serve como fundamento complementar de mecânica, não como coeficientes atuais nem validação de qualquer geometria.
4. O arquivo **Green/Sputo/Higgins, janeiro 2005**, registrado em docs/fontes.json, não existe entre os PDFs locais encontrados. O URL antigo da AISC foi localizado, mas retornou 404 ao baixar. A tese de maio é outro documento, de outro tamanho/hash: não declarar recuperação do arquivo registrado nem substituir silenciosamente sua identidade.
5. AISC disponibiliza em seu índice o exemplo atual II.A-1A, ligação dupla toda parafusada à mesa de pilar: https://www.aisc.org/media/kybevlwy/first-semester-design-examples-v160.pdf . O índice confirma geometria e exemplo, mas o download completo retornou 401/403 nesta consulta. É candidato a confronto futuro, não fixture numérica integral já conferida.
6. A página oficial https://mais.gerdau.com.br/catalogos-e-manuais/manual-de-ligacoes-para-estruturas-de-aco anuncia edição atualizada para NBR 8800:2024. O conteúdo está atrás de formulário de nome/email; não foi enviado dado pessoal e não foi obtida a nova edição. Nenhum exemplo novo de emenda W N/M/V foi confirmado nela.

## Contrato mínimo do modelo R-016

- Entrada nativa própria: quantidade de cantoneiras; lado; b da aba da viga e b da aba de apoio; t e raio de concordância; comprimento; dois gabaritos; número de linhas, passo e bordas de **cada interface**; diâmetro e tipo de furo; folga da ponta; perfis/materiais da viga e do apoio. Não aproveitar o objeto single plate supondo uma chapa equivalente 2t.
- Para a primeira rota, par simétrico e geometria convencional LCPP, reação vertical V e N = M = T externos iguais a zero. A ausência de momento externo **não elimina** excentricidades geométricas internas. Cargas axiais, momento imposto, torção ou uma só cantoneira devem seguir seu próprio ramo, nunca receber aprovação pelo resultado V-only.
- Esforço em cada cantoneira = V/2 por simetria. O parafuso comum às duas cantoneiras e à alma tem dois planos de corte; cada parafuso da interface com a mesa tem um plano. Conferir os materiais separadamente, sobretudo a alma fina entre duas abas mais espessas.
- Adotar o modelo de ligação flexível convencional documentado no Gerdau. Os gabaritos de referência são 45 mm para L76×76×6,4 e 65 mm para L102×102×8,0; não inventar um limite universal de aplicação a partir desses dois valores. Para aceitar gabarito estendido ou múltiplas colunas, explicitar excentricidade, flexão da aba e transferência de momento. Não aplicar silenciosamente uma dispensa AISC sem registrar edição e condições completas.
- A NBR 6.1.1.3 exige equilíbrio, resistência de cada componente, compatibilidade de rigidez e capacidade de deformação; 6.1.2.3 admite ligações usuais tradicionalmente rotuladas a critério do responsável técnico; 6.1.3 exige rotação adequada. Isso permite o caso usual analítico sem bloquear toda a família por ausência de FEA. Não prometer verificação automática de rigidez rotacional sem calculá-la.

## Verificações e expansões

**Parafusos e furos:** NBR 6.3.3.2 (0,45 com rosca / 0,56 sem rosca, por plano), 6.3.3.3 (contato/rasgamento, força e ligamentos reais), 6.3.6–6.3.9 (furos, pega, espaçamentos e bordas); 6.3.4 se atrito for requerido. Manter serviço/ELU distintos. A resistência total por contato é soma dos furos (p.85); se houver solução elástica por parafuso, demonstrar também a compatibilidade da distribuição, sem confundir soma normativa com n vezes o pior furo.

**Cantoneiras:** verificar as duas abas, seção bruta e líquida ao cisalhamento (6.5.5), blocos de rasgamento fisicamente possíveis (6.5.6; Cts adequado ao caminho), além de flexão e sua interação com cortante quando o modelo gerar momento. Guardar áreas, trajeto e deduções explícitos. Uma aba sem furo não recebe dedução do furo da outra. Não transplantar uma fórmula de cantoneira dupla para a simples dividindo por dois.

**Viga e apoio:** contato/rasgamento na alma apoiada e na mesa/na alma de apoio, seção local relevante, bordas livres reais, possíveis blocos e caminho até o restante do perfil. Na variante R-017 acrescentar resistência e estabilidade do trecho recortado. A resistência tabelada pelo Gerdau não aprova o apoio; conferir os estados pertinentes e registrar ações entregues ao seu dimensionamento global.

**R-015 soldada/parafusada:** calcular grupo de soldas de cada cantoneira com V/2 e momento obtido da distância entre resultante e centro do grupo. O Gerdau p.26 usa grupo excêntrico. É possível usar distribuição elástica analítica conservadora verificada; não é necessário começar por tabelas ICR. NBR 6.2.2.2, 6.2.5/Tabela9 e 6.2.6 controlam garganta, metal base/solda, comprimento e detalhes. Retornos que prejudicam a flexibilidade merecem atenção: 6.2.6.2.6-c limita seu comprimento a quatro pernas de filete. Soldas e parafusos em interfaces sucessivas transmitem a carga; não somar suas capacidades como se trabalhassem em paralelo.

**Cantoneira única:** implementar ramo próprio com excentricidade nas duas interfaces, corte simples, flexão das abas e ações fora do plano no apoio/torção transmitida à viga. A tese UF cap.4 distingue expressamente o grupo de apoio excêntrico da dupla simétrica e, no caso estendido, considera ambas as linhas excêntricas. Seu modelo idealiza a linha de apoio articulada; essa hipótese não autoriza ignorar alavanca sob N ou M. A expansão com N exige NBR 6.3.3.4/6.3.5 e resistência/flexão das abas; não liberar pelo caso V-only. Primeiro fazer convencional, depois estendida se a documentação do modelo permitir.

## Detalhamento que não pode desaparecer

Firme contato entre chapas, raio interno e acesso de chave/soquete, cabeça/porca/arruela, tolerância real da alma, roscas em cada plano, colisões com mesas, folgas de montagem e capacidade de introduzir a viga. R-016/R-017 especificam montagem das cantoneiras com a viga. Alívios de canto fora do caminho resistente são aviso de fabricação; corte que reduz área/furo/solda exige atualizar a geometria. Não impor solda máxima antiga nem gabarito industrial como se fossem resistência normativa. Folha1 nota13 usa DIN para furos: conferir com NBR e com a especificação de fabricação, sem substituir todo M20 por 3/4 polegada.

Reversão estática de V pode ser resolvida usando a borda carregada correspondente. Impacto, afrouxamento e fadiga exigem enquadramento 6.1.11 e não são cobertos apenas por um botão de sinal. O comprimento de cantoneira e seu posicionamento devem preservar a rotação e o impedimento de giro longitudinal da viga (6.1.7), sem presumir que um aviso ou confirmação do usuário substitui a verificação.

## Verificação independente antes da entrega

O arquivo fixture_plan.json separa números analíticos de componentes, casos históricos publicados e testes de geometria/interface. Os valores de componentes foram calculados sem importar qualquer módulo do aplicativo. Ainda não são comprovação de uma ligação completa.

Primeiro validar R-016 com três interfaces físicas e desenhos frontal/planta; depois JSON, relatório e testes de regressão. Gate obrigatório: nenhuma aprovação global quando faltar uma verificação aplicável ou quando a entrada mudar a topologia. Casos fora da primeira rota devem indicar precisamente o que falta, sem pedir referência já disponível nem exigir FEA genericamente.
