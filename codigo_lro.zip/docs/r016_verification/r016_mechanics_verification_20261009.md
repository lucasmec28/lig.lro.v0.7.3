# R016 / LCPP: verificacao independente de mecanica e fontes

Data: 2026-10-09. Trabalho de leitura, calculos independentes e parecer de implementacao; nenhum arquivo do aplicativo foi alterado. Unidades das equacoes abaixo: N, mm, MPa.

## Conclusao utilizavel

Existe uma rota convencional defensavel, sem FEA: duas cantoneiras iguais, simetricas, parafusadas nas duas abas, uma linha vertical de parafusos por aba, viga W sem recorte, mesa de pilar W laminado, somente reacao vertical estatica, geometria convencional documentada. O Gerdau fornece explicitamente o modelo LCPP de corte direto, incluindo cisalhamento e blocos das cantoneiras e verificacoes da alma da viga. A NBR atual permite adotar a ligacao usual tradicionalmente rotulada, a criterio do responsavel pelo projeto, mas nao transforma todo par de cantoneiras em ligacao convencional nem dispensa resistencia dos componentes.

A excentricidade geometrica nao e zero. Nesta rota, seu tratamento esta incorporado no modelo convencional flexivel, nao em um grupo elastico excentrico silenciosamente truncado. A tese UF esclarece a diferenca: para gabaritos usuais, a flexao da aba nao e uma verificacao independente da conexao padrao; nas estendidas, flexao e parafusos excentricos voltam expressamente ao modelo. Nao misturar metade de cada modelo.

A mesa do pilar deve ser verificada localmente, pelo menos por contato/rasgamento reais. O exemplo primario AISC convencional confirma essa abordagem. Podem-se acrescentar blocos L fisicamente possiveis ate as pontas reais do pilar, com NBR atual; nao criar um bloco U que atravesse a alma continua do pilar. Nao ha motivo para exigir genericamente flexao normal a mesa, esmagamento transversal da alma ou FEA sob essa unica acao vertical no plano da mesa.

## Fontes efetivamente conferidas

- NBR 8800:2024, versao corrigida2025 local: paginas impressas69/PDF91 (6.1.1.3,6.1.2.3,6.1.3),70/PDF92 (6.1.5),71/PDF93 (6.1.7,6.1.8,6.1.11),84-85/PDF106-107 (6.3.3.2-.4),94-96/PDF116-118 (6.5.1,6.5.5,6.5.6,Figura16). Conferencia visual das paginas69,70,96; textos OCR existentes confrontados com formulas ja verificadas.
- NBR impressas57-58/PDF79-80: 5.4.3.1, cortante de secao I/H/U e instabilidade da alma; os arquivos renderizados/OCR estao em `w_splice_scope/source/compression/`.
- Gerdau2018, paginas impressas/PDF9,14,19-26,33. Paginas25 e33 verificadas visualmente nesta rodada. E NBR2008: nao usar coeficiente0.4 de parafuso nem resultado329kN como norma2024.
- R016, folha industrial-2, impressa19, imagem `angle_connection_scope/source/R016_printed19.png`: conferida visualmente.
- Higgins2005 UF, local `angle_connection_scope/source/Higgins_2005_UF_thesis.pdf`, cap4 pp20-31/PDF31-42 e cap6 pp40-43/PDF51-54. Fonte primaria: https://ufdcimages.uflib.ufl.edu/uf/e0/00/93/61/00001/higgins_a.pdf . Modelo complementar historico, nao coeficientes NBR atuais.
- AISC v15.1, Example II.A-1A, paginasIIA-2 aIIA-4: https://www.aisc.org/globalassets/aisc/university-programs/teaching-aids/first-semester-design-examples---v15.1.pdf . Download completo retornou403; o indice oficial de busca disponibilizou o texto integral especifico de IIA-4 numa consulta direcionada, inclusive o paragrafo de mesa do pilar. Somente esse trecho e a geometria indexada foram confirmados. Nao e fixture integral nem recuperacao do exemploAISC16 antes faltante.

## 1. Contrato do modelo e flexao

NBR6.1.1.3 exige equilibrio, resistencia de cada componente, deformacao possivel e compatibilidade de rigidez. NBR6.1.2.3 permite a representacao usual rotulada;6.1.3 permite dimensionamento pelas reacoes compativeis com flexibilidade, exigindo rotacao sem colapso. NBR6.1.8.2 e uma dispensa para cantoneiras AXIALMENTE solicitadas e nao e a justificativa desta ligacao de alma a cortante.

Gerdau p14 usa L76x76x6.4/g45 e L102x102x8/g65. Pp19-20 caracterizam LCPP e limitacoes: comprimento da cantoneira >= metade da altura total da viga; folga de ponta10mm; disposicao dos furos e afastamentos de mesas. Para W150/W200 usa passo60 e borda30; demais, passo75 e borda40, primeiro furo75 abaixo do topo. R016 possui sua propria tabela metrica e nao deve ser fingido identico ao detalhe imperial.

Rota inicial prudente: reconhecer explicitamente os pares de secao/gabarito documentados, e detalhamento convencional R016/LCPP. Nao inferir um limite universal `g <= 65` ou `g <= b-t` desses dois exemplos, nem aceitar espessuras arbitrarias com a mesma flexibilidade. Uma geometria industrial distinta pode ser fisicamente factivel e ainda nao corresponder a linha exata de uma tabela. Separar aviso de conformidade ao padrao de falha resistente.

TeseUF p20: dupla simetrica elimina a excentricidade perpendicular ao eixo da viga para gabaritos praticaveis. Pp24-26: a flexao da aba estendida depende de e; a conexao padrao nao demanda essa verificacao separada dentro dos gabaritos especificados. Para estendida, S=t*h^2/6 por aba, M=V*e por conjunto coerentemente definido; tambem entram flexao liquida e grupo excentrico. Isso NAO autoriza aplicar apenas M/W na cantoneira e manter os parafusos em corte direto: a mesma idealizacao deve fechar equilibrio em todas as interfaces.

## 2. Minimo de acao

NBR6.1.5.2, impressa70/PDF92: para R016 de viga comum, adotar pelo menos45kN na direcao e no sentido da forca atuante. `V_adotado=sign(V_real)*max(abs(V_real),45000)` para V_real nao nulo. Se zero, deve haver convencao de sentido explicita ou verificacao dos dois sentidos, especialmente se bordas assimetricas. Manter Vreal no JSON/relatorio. As excecoes especificas de tirantes redondos, travessas, tercas e travejamento nao devem virar opcao generica para escapar do minimo.

NBR6.1.5.3 recomenda50% da resistencia AXIAL para barras tracionadas/comprimidas, nao metade do cortante resistente da viga. Integridade estrutural4.13 e suas acoes sao assunto separado: N=0 nesta rota nao aprova amarracao axial requerida por outro caso de carga.

## 3. Forcas e ligamentos por interface

Definir Vpositivo como forca descendente entregue pela viga. Cada cantoneira recebe V/2.

- Aba da viga: parafusos empurram cantoneira para baixo; usar a borda INFERIOR da cantoneira.
- Aba do pilar: parafusos empurram cantoneira para cima; usar borda SUPERIOR da cantoneira.
- Alma da viga: parafuso empurra alma para cima.
- Mesa do pilar: parafusos empurram mesa para baixo; usar ponta INFERIOR real do pilar.

Para Vnegativo, inverter tudo. O sinal da forca no furo da cantoneira nao e o mesmo no elemento contraposto.

Por furo padrao e com deformacao de servico limitada, NBR6.3.3.3:
`R_contato=min(1.2*lc,2.4*db)*t*fu/gamma_a2`.
Para furos intermediarios de uma fila: `lc=p-dh`. Furo extremo com borda livre carregada: `lc=E-dh/2`. Nao substituir dh real por d_net na pressao de contato. Nao contar duas bordas livres na mesma direcao de forca.

Na viga sem recorte, a interface da alma com a mesa nao e uma borda livre: no furo terminal voltado para a mesa continua usa-se o limite de contato `2.4*db*tw*fu/gamma_a2`; os demais furos mantem seus ligamentos `p-dh`. A fonteAISC IIA-4 confere contato e rasgamento entre furos de alma sem recorte, sem introduzir uma borda ficticia junto a mesa.

A resistencia total de contato e a SOMA normativa dos furos, NBR impressa85. Para distribuicao uniforme por parafuso, registrar adicionalmente verificacoes de cada furo com V/n ou V/(2n). Isso e conservador e compativel com essa distribuicao, mas nao rotular n vezes o pior furo como a soma normativa. Se for explorar redistribuicao ate a soma, garantir capacidade simultanea dos componentes ligados pelo mesmo parafuso: `sum(min(R_parafuso_i,R_aba_i,R_elemento_i))` e nao somente o minimo das somas. Prefixos de bloco devem usar as forcas realmente atribuidas aos furos; V*k/n pressupoe distribuicao uniforme.

Parafuso comum alma+duas cantoneiras:2planos de corte. Parafuso aba+mesa:1plano. NBR6.3.3.2 atual usa0.45*Ab*fub/gamma_a2 com rosca no plano e0.56 sem rosca. A espessura resistente da alma nunca e duplicada.

## 4. Cantoneiras: cisalhamento e blocos

Cada aba tem sua propria fila e bordas. Para duas abas homologas:
`Agv=2*h*t`; `Anv=2*(h-n*d_net)*t`.
NBR6.5.5: `Ry=0.6*fy*Agv/gamma_a1`; `Ru=0.6*fu*Anv/gamma_a2`.

BlocoL por aba, abrangendo k furos contiguos junto a borda CARREGADA:
`Agv=[E_carregada+(k-1)*p]*t`;
`Anv=Agv-(k-0.5)*d_net*t`;
`Ant=[b-g-0.5*d_net]*t`.
`Rbl=min(0.6*fu*Anv+Cts*fu*Ant,0.6*fy*Agv+Cts*fu*Ant)/gamma_a2`.
Somar2abas somente para o par simetrico efetivo. Para cada aba, demandaV/2; para um prefixok sob distribuicao uniforme, V*k/(2n).

Gerdau p25 fornece essa geometria para a cantoneira inteira. A extensao a prefixos e aplicacao mecanica conservadora da mesma superficie de falha. NBR Fig16(b), impressa96, mostra cantoneira de uma fila e caminhoL com Cts1; Fig16(c) ilustra duas filas com tensao nao uniforme e Cts0.5. A simetria global sozinha nao decide Cts de um caminho local.

## 5. Alma sem recorte e instabilidade

Gerdau p24 usa H*tw e [H-n*d_net]*tw para escoamento e ruptura por cisalhamento da alma, H=altura total do perfil. E aplicavel como verificacao local NBR6.5.5. Pode-se usar o trecho plano/altura livre menor como corte local conservador declarado; nao dizer que a NBR define Aw assim para o membro.

NBR5.4.3.1.1/.2, impressas57-58: no membro W, Aw=d*tw e Vpl=0.6*Aw*fy. Para lambda=h_plano/tw; laminado h_plano=d-2tf-2r; sem enrijecedor kv5.34; lambda_p=1.10*sqrt(kvE/fy),lambda_r=1.37*sqrt(kvE/fy). MultiplicadorCv=1 ate lambda_p; lambda_p/lambda entre limites;1.24*(lambda_p/lambda)^2 acima lambda_r. VRd=Cv*Vpl/gamma_a1. A ruptura liquida continua separada. Nao basta escoamento se alma esbelta puder instabilizar.

Gerdau p25 limita expressamente sua formula de bloco da ALMA a vigas com recorte. Alma sem recorte nao apresenta a borda livre superior/inferior necessaria ao mesmo blocoL; marcar esse mecanismo coped como nao aplicavel, com topologia registrada. Nao fingir que ele foi calculado com a borda da cantoneira. Novo recorte, furo grande ou abertura altera o modelo e deve impedir aprovacao por esta rota.

## 6. Mesa de pilar: caminho local e blocos suplementares

Na rota simetricaVonly, a forca na mesa e vertical, no seu plano. AISCIIA-4 considera a mesa adequada pela sua resistencia de contato superior a das cantoneiras mais finas. Isto sustenta a verificacao convencional da mesa por furos reais; nao sustenta omiti-la porque o Gerdau tabelou a ligacao.

Para cada fila, usar tf,fu do pilar, passo real e ponta livre carregada real. `E >= 2db+dh/2` apenas assegura que aquele furo atinge o teto de contato: NAO e criterio universal de dispensa de bloco ou de continuidade.

Uma verificacao adicional explicita e o blocoL OUTBOARD de cada fila da mesa ate a sua borda lateral livre e a ponta carregada do pilar:
`z_fila=tw_viga/2+g_apoio` quando g e medido a partir da face externa da aba junto a alma conforme desenho;
`c_toe=bf_pilar/2-abs(z_fila)`;
`Agv=[E_ponta+(k-1)*p]*tf`;
`Anv=Agv-(k-0.5)*d_net*tf`;
`Ant=[c_toe-0.5*d_net]*tf`.
Aplicar6.5.6 por lado; Cts1 para caminho independente de uma fila equivalente a Fig16(b). Cts0.5 pode ser escolhido conservadoramente, mas nao e exigido so porque ha duas cantoneiras. A formula e uma aplicacao racional suplementar da NBR, nao uma formula de apoio publicada no Gerdau.

Um bloco central entre filas cruza a juncao continua mesa-alma do pilar e nao pode ser contado como uma chapa livre destacavel. Da mesma forma, comprimento da cantoneira nao e altura de uma chapa solta do pilar. Se houver recorte, abertura, apoio soldado, assimetria ou alteracao dessa continuidade, exigir o caminho fisico pertinente; nao usar esses blocos como coringa.

Nao exigir 5.7.2 flexao normal a mesa /5.7.3 escoamento transversal da alma/5.7.4 enrugamento por uma forca exclusivamente longitudinal ao pilar no plano da mesa; esses mecanismos dependem de forcas localizadas nas direcoes previstas. RegistrarNA pela direcao/topologia. Uma normal axial da viga ou um momento imposto reabre esses mecanismos e alavanca dos parafusos.

O esforcoV e entregue ao pilar global como incremento axial; por estar numa face, ha momento de transporte em relacao ao eixo de referencia global, conforme posicao real da reacao. Exportar reacao e seu ponto, e M=r×F quando a analise global exigir. A aprovacao localR016 nao equivale a dimensionar pilar inteiro, interacao com demais vigas, flambagem ou estabilidade do edificio.

## 7. Fixtures independentes entregues

`verification/calculate_r016_fixtures.py` nao importa o aplicativo. Produz `verification/r016_full_local_fixtures.json`, com baseline R016M20,N3:4parafusos comuns,8de apoio,passo60,bordas40,h260,L76x76x6.4,g45. Viga sintetica d355,tw7.2,tf11.6,r11.9; mesa de pilar bf250,tf12; distancias reais as duas pontas500. Materiais explicitos noJSON. ComV200kN:

- Corte em cada grupo:691.150384kN.
- Cantoneiras cisalhamento bruto453.818182kN; liquido373.191111kN.
- Contato soma nas cantoneiras, cada interface650.808889kN.
- Alma contato443.52kN; escoamento480.992727kN; ruptura liquida372.96kN.
- MembroCv1.0, VRd480.992727kN.
- Mesa contato1478.4kN; bloco outboard completo3017.6kN; prefixos noJSON.
- Capacidade local entre estes estados372.96kN, ruptura liquida da alma. Esses numeros nao dispensam detalhamento/fabricacao e verificacoes de dominio.

Tambem ha reversao com e_top30/e_bottom50 para expor sinais; e apoio adversarial tf3,bf150,Ebottom30. Neste ultimo, o bloco de4furos da mesa tem180kN paraV200kN e deve falhar mesmo que a soma de contato319.2kN passe. A verificacao uniforme de furo extremo tambem falha182.4kN; ambas devem aparecer, sem esconder o apoio atras das cantoneiras.

O antigo fixtureh200,n3 continua util como componente/modelo convencional, mas nao corresponde a linha R016M20,N2 para Z331.8. Para o detalhe industrial, Z331.8 implicaN3 e4parafusos. Z e altura livre, nao comprimento de cantoneira.

## 8. Gate de completude

Podem coexistir calculos numericos e status incompleto. Bloquear aprovacao local se faltar: geometria/continuidade que determine caminhos; resistencia da alma ou mesa; material/diâmetro real; controle de rosca/pega/furos; rota compativel para gabarito estendido; verificacao de mecanismo aplicavel; acomodacao de rotacao/impedimento de giro exigida pela configuracao.

Nao criar um gate universal por ausencia deFEA, nem exigir um checkbox que finja calcular mecanismo ausente. NBR6.1.2.3 aceita a pratica usual com julgamento tecnico; identificar o dominio usual e suas fontes e a solucao pratica. AcoesN/M/T, cantoneira unica, recortes e soldas sao outros modelos e nao recebem verde porVonly.

As verificacoes do apoio podem ser completas no escopo LOCAL de ligacao, enquanto o dimensionamento global do pilar permanece no projeto estrutural. Relatorio deve distinguir esses escopos claramente e exportar a acao entregue, sem denominar o edificio globalmente aprovado.

## 9. Fechamento adicional da regra geometrica usual e materiais (21:49UTC)

Foi localizada fonte primaria complementar para a funcao da meia altura: AISC Steel Interchange, abril2010, artigos “Minimum Connection Depth” e “Beam Connection Location”, https://www.aisc.org/globalassets/modern-steel/steel-interchange/2010/042010_apr10_si_web.pdf . O texto indexado oficial explica a pratica ManualPart10 de profundidade de conexao >=T/2 para prover restricao de giro longitudinal; colocacao superior favorece estabilidade de montagem. O download integral403 permaneceu indisponivel; o trecho especifico foi obtido no indice oficial, nao em copia de terceiro. Esta opiniao tecnica e fundamento de pratica convencional, nao nova formula normativaNBR.

Aplicacao mais conservadora diretamente documentada no Gerdaup20: verificar numericamente comprimento>=H/2 e distancia do furo superior ao topo da viga<=distancia do furo inferior ao fundo. Junto com par simetrico, secao/gabarito flexivel convencional, pelo menos duas linhas horizontais de furos, mesas continuas, ausencia de recorte, contato firme e folgas de montagem, isso constitui verificacao do DOMINIO USUAL que pode sustentar6.1.2.3. Fora desse dominio, requerer analise especifica de rotacao/contencao; o aviso sozinho nao fecha o estado. Nao afirmar que esses testes calculam curvaM-theta ou substituem dimensionamento global de contraventamento.

NBR5.7.8, impressa67/PDF89, conferida visualmente: enrijecedores de apoio referem-se a vigas sem qualquer restricao de giro longitudinal E com almas nao ligadas a outras vigas ou pilares. A alma doR016 aqui e conectada ao pilar; nao impor esse enrijecedor automaticamente ao detalhe usual.

NBRTabelaA.3, impressa130/PDF152, conferida visualmente em `tmp/column-base-weld/nbr-152.png`: F3125A325/F1852 fyb635MPa,fub830MPa; F3125A490/F2280 fyb895MPa,fub1040MPa. Faixas apresentadas16<=db<=36mm e1/2<=db<=1.5in. Nao ha reducao de resistencia para A325moderno>1in nessa tabela. O825MPa dos fixtures e somente entrada explicita de ensaio numerico, nao atribuicao a classe atual.

Observacao ao primeiro engine lido: o limiteh/tw260 com referencia5.4.3.3 pertence a secoesT, naoW. Nao citar esse item como limiteW. O calculo explicitoCv em5.4.3.1 e pertinente. Uma restricao adicional de dominio pode ser conservadora, mas deve ser identificada como tal e ter base adequada.

## 10. Confronto independente com contrato do aplicativo (21:51UTC)

`verification/compare_r016_app_contract.py` calcula os esperados com equacoes independentes ANTES de importar o aplicativo, depois importa o engine apenas como objeto sob teste. Foram aprovadas228 comparacoes numericas,76por caso: corte de parafusos, areas e resistencias de cada prefixo de bloco, cisalhamento bruto/liquido, resistenciaCv, contato por furo e soma, e capacidade local governante.

Para reproduzir deliberadamente o contrato do aplicativo, esse confronto usa fub830MPa, altura local plana308mm e Cts0.5 no suporte. Nao sao os mesmos pressupostos do fixture primitivo825/H355/Cts1. Baseline retorna capacidade305280N por ruptura liquida da alma; reversao com bordas assimetricas preserva305280N e gera aviso de desvio do padrao; suporte adversarial bf170/tf3/clear228/Ebottom30 retorna175600N, com falha por blocoL da mesa. Esse ultimo tambem apresenta uma pequena falha de borda maxima lateral36.4>36mm; ela nao oculta a falha resistente independente.

O arquivo `verification/r016_app_contract_comparison.json` guarda cada esperado/obtido, estado, mecanismo governante e hipoteses. O helper original foi corrigido para incluir explicitamente `local_capacity_including_blocks`; sua antiga chave `local_capacity_uniform_per_hole_checks` e apenas o subconjunto nomeado e nao deve ser usada como capacidade completa sem os blocos.

## 11. Datum exato do gabarito transversal (21:56UTC)

Revisao final em alta resolucao do planoR016 e dos vetores do PDF industrial confirma que G e medido da FACE DE CONTATO da alma da viga ate o eixo do parafuso da aba de apoio, nao do eixo central da alma. No PDF da folha-2, o vertice da seta superior deG esta em y=1104.000; as faces da alma estao em y=1103.040 e1104.000 (centro aproximado1103.520); o eixo do parafuso inferior esta em y=1116.000. Esses valores sao coordenadas graficas doPDF, nao cotas de fabricacao. A espessura da aba da cantoneira continua para fora dessa face, distinguivel no desenho ampliado.

O detalhe ampliado Gerdau p33 mostra igualmente45 de cada face da alma ao respectivo eixo de parafuso, com a espessura da alma entre os dois pontos internos de cotagem.

Logo a implementacao `z_fila=±(tw_viga/2+g_apoio)` e consistente com AMBAS as fontes. Para tw7.2/g45: semigabarito desde o eixo48.6mm e distancia total entre eixos97.2mm. Nao substituir por90mm. Rotulo inequivoco recomendado: “g_apoio: face de contato da alma → eixo do furo”. Nao foi encontrado defeito que demande alteracao do engine congelado.

Crops de conferencia: `verification/r016_support_gauge_source_crop.png` e `verification/gerdau33_support_gauge_source_crop.png`. Nenhum arquivo do aplicativo foi alterado.

Nota da integração: os caminhos de fontes e recortes deste memorando referem-se ao acervo de pesquisa, externo ao aplicativo. PDFs e recortes de páginas protegidas não são incluídos no pacote. O motor, as equações independentes, os dados numéricos e os hashes de identificação das fontes estão no fonte distribuído.
