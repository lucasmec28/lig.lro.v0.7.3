"""Independent equations first; import the app only as the system under test."""
from pathlib import Path
import sys,json,math
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from calculate_r016_fixtures import calculate
# Independent expected numbers generated before loading any application module.
cases={
 'baseline':calculate(fub=830,local_h=308,support_Cts=.5),
 'reverse_asymmetric':calculate(e_top=30,e_bottom=50,V=-200000,fub=830,local_h=308,support_Cts=.5),
 'thin_support':calculate(tf=3,bf=170,s_top=500,s_bottom=30,V=200000,fub=830,local_h=308,support_Cts=.5),
}
sys.path.insert(0,str(HERE.parents[1]))
from lro.double_angle import DoubleAngle,evaluate
from lro.models import Profile
beam=Profile(name='Independent W355 synthetic',family='W',mass=51,d=355,bf=171,tw=7.2,tf=11.6,clear=308,area=6480,source='Independent explicit source-verification fixture, not catalog certification')
report=[]
for name,fixture in cases.items():
 inp=fixture['input'];exp=fixture['expected']
 support=Profile(name='Independent support synthetic',family='W',mass=60,d=250,bf=inp['column_bf'],tw=8,tf=inp['column_tf'],clear=250-2*inp['column_tf']-16,area=5000,source='Independent explicit source-verification fixture, not catalog certification')
 c=DoubleAngle(beam,support,length=260,angle_top=47.5,web_rows=4,support_rows=4,web_pitch=60,support_pitch=60,web_end_top=inp['edge_angle_top'],support_end_top=inp['edge_angle_top'],support_edge_top=inp['column_edge_top'],support_edge_bottom=inp['column_edge_bottom'],V=inp['V_actual'])
 actual=evaluate(c); rows={r['id']:r for r in actual['checks']}
 if not rows:raise AssertionError((name,actual['status'],actual['issues']))
 suffix='_Vpos' if inp['V_actual']>0 else '_Vneg'
 comparisons=[]
 def check(label,want,got):
  good=math.isclose(want,got,rel_tol=1e-12,abs_tol=1e-8)
  comparisons.append(dict(label=label,expected=want,actual=got,passed=good))
  if not good:raise AssertionError((name,label,want,got))
 for label,identifier,factor in [
 ('beam_bolt_group','bolt_shared_web',1),('support_bolt_group','bolt_support_negative',2),
 ('angle_shear_yield_pair','angle_negative_beam_shear_gross',2),('angle_shear_net_pair','angle_negative_beam_shear_net',2),
 ('beam_local_shear_gross_clear','beam_web_shear_gross',1),('beam_local_shear_net_clear','beam_web_shear_net',1),('beam_member_shear_Rd','beam_web_shear_buckling',1),
 ('beam_bearing_total','beam_web'+suffix+'_bearing_group',1),
 ('angle_beam_bearing_pair_total','angle_negative_beam'+suffix+'_bearing_group',2),
 ('angle_support_bearing_pair_total','angle_negative_support'+suffix+'_bearing_group',2),
 ('support_bearing_pair_total','column_flange_negative'+suffix+'_bearing_group',2)]:
  check(label,exp[label],factor*rows[identifier]['design_capacity_N'])
 for label,identifier,factor in [('beam_bearing_per_row','beam_web',1),('angle_beam_bearing_each','angle_negative_beam',1),('angle_support_bearing_each','angle_negative_support',1),('support_bearing_each','column_flange_negative',1)]:
  for i,want in enumerate(exp[label],1):check(label+str(i),want,factor*rows[identifier+suffix+f'_bearing_hole{i}']['design_capacity_N'])
 for key,prefix in [('angle_beam_blocks_pair','angle_negative_beam'),('angle_support_blocks_pair','angle_negative_support'),('support_outboard_blocks_pair','column_flange_negative')]:
  for bl in exp[key]:
   row=rows[prefix+suffix+f"_block_k{bl['k']}"]
   for ex,ac in [('Agv','Agv_mm2'),('Anv','Anv_mm2'),('Ant','Ant_mm2'),('Rd','design_capacity_N')]:check(key+str(bl['k'])+'_'+ex,bl[ex],2*row[ac])
 check('overall_local_capacity_with_blocks',exp['local_capacity_including_blocks'],actual['summary']['equivalent_total_V_capacity_N'])
 report.append(dict(case=name,status=actual['status'],global_pass=actual['global_pass'],governing=actual['summary']['governing_check_id'],expected_capacity=exp['local_capacity_including_blocks'],check_count=len(comparisons),comparisons=comparisons,issues=actual['issues']))
 print(name,actual['status'],'capacity',exp['local_capacity_including_blocks'],'comparisons',len(comparisons))
output=dict(status='ALL_NUMERICAL_COMPARISONS_PASSED',independence='Independent equations evaluated first; no app helper used for expected numbers. App imported only to obtain actual values.',known_hypotheses=['NBR TableA.3 fub830MPa instead of primitive825','Conservative app local beam.clear308 rather than Gerdau H355','Support Cts0.5 conservative rather than standard single-row1','Uniform per-hole direct model, therefore k/n block demands compatible'],results=report)
(HERE/'r016_app_contract_comparison.json').write_text(json.dumps(output,indent=2,ensure_ascii=False))
