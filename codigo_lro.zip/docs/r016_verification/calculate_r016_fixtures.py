"""Read-only independent numerical verification. No app imports; N, mm, MPa."""
import math,json
from pathlib import Path
G1=1.1;G2=1.35

def calculate(n=4,p=60,h=260,e_top=40,e_bottom=40,s_top=500,s_bottom=500,tf=12,bf=250,V=200000,fub=825,local_h=None,support_Cts=1):
 d=20;dh=22;dn=24;t=6.4;b=76;g=45;fya=250;fua=400
 H=355;tw=7.2;tfb=11.6;rb=11.9;fyb=345;fubm=450;fyc=345;fuc=450
 bolt=.45*math.pi*d*d/4*fub/G2
 def rbear(th,fu,lc): return min(1.2*lc,2.4*d)*th*fu/G2
 def bearings(th,fu,E,term_end):
  vals=[rbear(th,fu,p-dh)]*n
  vals[0 if term_end=='top' else -1]=rbear(th,fu,E-dh/2) if E is not None else 2.4*d*th*fu/G2
  return vals
 def blocks(th,fu,fy,E,c,count=1,Cts=1):
  out=[]
  for k in range(1,n+1):
   A=(E+(k-1)*p)*th;B=A-(k-.5)*dn*th;C=(c-.5*dn)*th
   R=min(.6*fu*B+Cts*fu*C,.6*fy*A+Cts*fu*C)/G2
   out.append(dict(k=k,Agv=count*A,Anv=count*B,Ant=count*C,Cts=Cts,Rd=count*R,uniform_model_demand=abs(V)*k/n,uniform_utilization=abs(V)*k/n/(count*R)))
  return out
 positive=V>=0
 abeam=bearings(t,fua,e_bottom if positive else e_top,'bottom' if positive else 'top')
 asup=bearings(t,fua,e_top if positive else e_bottom,'top' if positive else 'bottom')
 bb=bearings(tw,fubm,None,'top' if positive else 'bottom')
 sb=bearings(tf,fuc,s_bottom if positive else s_top,'bottom' if positive else 'top')
 lm=(H-2*tfb-2*rb)/tw;lp=1.10*math.sqrt(5.34*200000/fyb);lr=1.37*math.sqrt(5.34*200000/fyb)
 Cv=1 if lm<=lp else lp/lm if lm<=lr else 1.24*(lp/lm)**2
 vals={
  'bolt_one_plane':bolt,'beam_bolt_group':2*n*bolt,'support_bolt_group':2*n*bolt,
  'angle_shear_yield_pair':.6*fya*2*h*t/G1,'angle_shear_net_pair':.6*fua*2*(h-n*dn)*t/G2,
  'angle_beam_bearing_each':abeam,'angle_beam_bearing_pair_total':2*sum(abeam),
  'angle_support_bearing_each':asup,'angle_support_bearing_pair_total':2*sum(asup),
  'angle_beam_blocks_pair':blocks(t,fua,fya,e_bottom if positive else e_top,b-g,2),
  'angle_support_blocks_pair':blocks(t,fua,fya,e_top if positive else e_bottom,b-g,2),
  'beam_bearing_per_row':bb,'beam_bearing_total':sum(bb),
  'beam_shear_gross_Htw':.6*fyb*H*tw/G1,'beam_shear_net_Htw':.6*fubm*(H-n*dn)*tw/G2,
  'beam_member_shear_lambda':lm,'beam_member_shear_lambda_p':lp,'beam_member_shear_lambda_r':lr,'beam_member_shear_Cv':Cv,'beam_member_shear_Rd':.6*fyb*H*tw*Cv/G1,
  'support_bearing_each':sb,'support_bearing_pair_total':2*sum(sb),
  'support_outboard_blocks_pair':blocks(tf,fuc,fyc,s_bottom if positive else s_top,bf/2-(tw/2+g),2,support_Cts),
  'beam_interface_sum_per_row_min':sum(min(2*bolt,2*a,w) for a,w in zip(abeam,bb)),
  'support_interface_sum_per_row_min':sum(min(2*bolt,2*a,2*w) for a,w in zip(asup,sb)),
  'local_capacity_uniform_per_hole_checks':min(2*n*bolt,2*n*min(abeam),2*n*min(asup),n*min(bb),2*n*min(sb),.6*fya*2*h*t/G1,.6*fua*2*(h-n*dn)*t/G2,.6*fubm*(H-n*dn)*tw/G2)}
 if local_h is not None:
  vals['beam_local_shear_gross_clear']=.6*fyb*local_h*tw/G1
  vals['beam_local_shear_net_clear']=.6*fubm*(local_h-n*dn)*tw/G2
  vals['local_capacity_uniform_per_hole_checks']=min(vals['local_capacity_uniform_per_hole_checks'],vals['beam_local_shear_gross_clear'],vals['beam_local_shear_net_clear'])
 vals['local_capacity_including_blocks']=min(vals['local_capacity_uniform_per_hole_checks'],vals['beam_member_shear_Rd'],*[bl['Rd']*n/bl['k'] for key in ('angle_beam_blocks_pair','angle_support_blocks_pair','support_outboard_blocks_pair') for bl in vals[key]])
 inp=dict(V_actual=V,V_adopted=math.copysign(max(abs(V),45000),V),n=n,p=p,h_angle=h,b_angle=b,g_both=g,t_angle=t,edge_angle_top=e_top,edge_angle_bottom=e_bottom,d_b=d,d_h=dh,d_net=dn,angle_fy=fya,angle_fu=fua,fub=fub,beam_d=H,beam_tw=tw,beam_tf=tfb,beam_r=rb,beam_fy=fyb,beam_fu=fubm,column_bf=bf,column_tf=tf,column_fy=fyc,column_fu=fuc,column_edge_top=s_top,column_edge_bottom=s_bottom,gamma_a1=G1,gamma_a2=G2)
 return dict(input=inp,expected=vals)

if __name__ == '__main__':
 out={'status':'INDEPENDENT_CONVENTIONAL_R016_LOCAL_FIXTURES_NOT_COMPLETE_BUILDING_DESIGN','units':'N,mm,MPa','basis':'Current NBR2024 corrected2025 strengths; Gerdau conventional LCPP topology; finite column outboard L-blocks are rational supplementary checks. Material values explicit inputs. No app imports.', 'fixtures':{
  'R016_M20_N3_W355_h260':calculate(),
  'asymmetric_up':calculate(h=260,e_top=30,e_bottom=50,V=-200000),
  'asymmetric_down':calculate(h=260,e_top=30,e_bottom=50,V=200000),
  'thin_narrow_near_end_support':calculate(tf=3,bf=150,s_bottom=30,s_top=500)
 }}
 Path(__file__).resolve().with_name('r016_full_local_fixtures.json').write_text(json.dumps(out,indent=2))
 for name,f in out['fixtures'].items():
  print(name)
  for k,v in f['expected'].items():
   if not isinstance(v,list): print(' ',k,':',v)
  print(' support blocks:',f['expected']['support_outboard_blocks_pair'])
