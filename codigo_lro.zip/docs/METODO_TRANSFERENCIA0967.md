# 0.9.67 — transferência pelas horizontais e envoltória de soldas

## Avanço e domínio
Na nervura interna retangular das duas talas, sem extensão, calculam-se três campos completos: grupo elástico de soldas em três bordas; barra vertical bi-engastada Euler–Bernoulli; e sensibilidade Timoshenko com seção bruta uniforme. A geometria vem das entradas existentes. Não há seletor para escolher o campo mais favorável.

Cada solda recebe a maior utilização entre os campos pertinentes. Não se somam resistências nem se monta um vetor artificial com máximos isolados de forças e momentos. O envelope não demonstra que todos os campos reais estejam cobertos. A chapa perfurada, FLT, rotação e resistência/rigidez dos receptores permanecem sem aprovação global.

Geometrias com extensão continuam na rotina anterior; não se extrapola a barra retangular à nervura escalonada. Single plate e demais motores não foram alterados.

## Barra vertical
Eixo y entre horizontais, x para fora da alma, seção t×b, H=root_height e b=projection. Os dois extremos impedem translações e rotação no plano. Isso é premissa de análise; a resistência/fixidez das horizontais ainda precisa ser demonstrada. A solda da borda junto à alma não recebe reação primária no plano deste modelo. A contenção lateral dessa borda não é convertida em restrição torcional e não dispensa FLT.

Forças Fx,Fy por parafuso vêm do grupo elástico assinado existente. O momento de excentricidade do grupo já aparece nos Fx. Apenas o binário (xg−xc)Fy é acrescentado ao transportar cada força ao centroide bruto; não se soma outra vez V·e.

N é positivo em tração; Q em +x e M em +z na face superior do corpo livre inferior. Em cada trecho, N/Q são constantes e M é linear, com dM/dy=Q. Saltos nos furos: ΔN=−Fy; ΔQ=−Fx; ΔM=−(xg−xc)Fy. As ações transmitidas aos receptores são opostas às reações sobre a barra.

Euler–Bernoulli usa compatibilidade fechada. Timoshenko acrescenta deformação de cisalhamento uniforme, ν=0,30, G=E/2,6 e κ=5/6, hipótese clássica do retângulo íntegro. É uma sensibilidade de rigidez, não uma equivalência normativa da chapa furada. Com λ=EI/(κGA), as condições são integral M dy=0 e integral (H−y)M dy=λ integral Q dy. Ambas são resolvidas em conjunto. Não se credita aumento de resistência por nenhum desses parâmetros.

## Seções líquidas: somente informação
Cortes geométricos descontam as cordas dos furos com o diâmetro líquido do projeto, sem dupla dedução em sobreposições. Calculam-se An, centroide xn, In e Zpl. O momento concomitante é transportado: Mn=Mref+(xref−xn)N. Tensões normais nominais usam N/An+Mn(x−xn)/In.

Não se usa 1,5Q/An como prova do cisalhamento dos dois ligamentos. Não se cria interação N/NRd+M/MRd+Q/QRd. NBR 8800:2024 5.5.1.2 requer capacidades N/M qualificadas e 5.5.1.3 verifica Q separadamente; 5.5.2.3 exige tensões determinadas pela Teoria da Elasticidade. Blocos exigem caminhos físicos de ruptura. N/Q/M e propriedades líquidas, portanto, não possuem rótulo de aprovação resistente neste avanço.

## Soldas nervura–horizontais
Cada borda horizontal recebe seu vetor completo Fx,Fy,Mz. O grupo de dois filetes tem comprimento b−2a (a=alívio), garganta w/√2 e rigidez isotrópica por área de garganta. Os máximos da norma vetorial do campo linear ocorrem nas extremidades. Usa-se 0,6fw/γw2, sem aumento direcional, conforme NBR 6.2.5/Tabela 9, nota d.

Os checks anteriores de solda superior/inferior são substituídos pela envoltória, sem duplicação. A solda vertical conserva o resultado do modelo de três bordas, pois a barra atribui zero reação primária a ela.

O critério suplementar da borda da nervura também recebe a envoltória: sigma equivalente=sqrt[(qy/t)²+3(qx/t)²], com tensão paralela à borda assumida nula. Continua sendo um critério local condicionado, sem demonstrar o estado completo da chapa. Sinais físicos: σyy e τxy são −sign(yborda) vezes qy/t e qx/t, respectivamente; q é a ação transmitida ao receptor.

## Soldas horizontais–coluna: grupo 3D
Cada horizontal frontal tem três juntas: alma em x=0 e duas mesas em z=±s/2, com os comprimentos físicos após alívios. Dois filetes são projetados no plano médio y=±(H+ts)/2. Não se credita resistência a momento devida apenas à pequena separação entre os filetes. A força de entrada atua na face y=±H/2. O transporte para o plano médio inclui, portanto, a excentricidade ts/2, além da excentricidade em x.

Campo de tensão vetorial por garganta: σ(r)=F/Aw+ω×r. Com r relativo ao centroide, resolve-se [integral((r·r)I−r⊗r)dAw]ω=Mcentroide. A integração de cada segmento produz forças e momentos exatos por borda e resíduos de equilíbrio em 3D. A norma vetorial máxima do campo afim é procurada nas pontas de cada segmento.

Fy é normal à chapa horizontal. Não é convertido em cisalhamento do seu metal-base. O binário Mz solicita também torção da faixa horizontal entre mesas; a antiga faixa biapoiada solicitada apenas no plano não é reaproveitada para aprová-la. O cálculo novo qualifica o metal das soldas sob a hipótese elástica declarada, mantendo pendentes chapa, metal-base, fixidez e receptores da coluna.

A dimensão de filete e comprimento mínimo seguem os checks de interfaces já existentes. L/w>100 conserva ressalva explícita sobre aplicabilidade da redução de juntas longas, sem substituir uma resistência física por extrapolação silenciosa.

## Exemplo padrão e efeito útil
Com as ações mínimas vetoriais já existentes no app, Fx=8,049845 kN e Fy=44,274146 kN. A utilização da solda inferior nervura–horizontal muda de aproximadamente 0,116 no grupo de três bordas para 0,649 na envoltória; a superior chega a 0,311. As soldas horizontais–coluna chegam a aproximadamente 0,098. Estes valores não são aprovação do conjunto: demonstram o efeito de verificar campos alternativos completos.

## Fontes e limites
- NBR 8800:2024 corrigida 2025: 6.2.2.2, 6.2.5/Tabela 9 e 6.2.6 para soldas; 5.5.1.2–.3 e 5.5.2.3 para limites de interação e campo de tensões.
- Fakury, Castro e Silva e Caldas (2016), §§8.8.1 e10.12.3–.5: idealizações de enrijecedor/barra e separação entre áreas brutas e líquidas. As seções compostas e comprimentos daquele exemplo não foram transplantados à nervura.
- A resistência de FLT da barra maciça de referência do estudo anterior não é usada neste release como capacidade da nervura perfurada. Posição de forças fora da semialtura, perfuração e interação axial continuam requerendo qualificação própria.

Todos os resultados de solda são condicionais. Nenhuma pendência foi retirada para produzir aprovação.
