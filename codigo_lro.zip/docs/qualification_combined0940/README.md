# Corrected successor source

Only the independently reviewed 4E column-demand correction is added to the exact, immutable and undelivered 0.9.39 checkpoint, together with the approved global identity 0.9.40-4e-column-demand-dev. The cap/W/Lig18 runtime modules and their current component versions remain exact. Source0938 is the last delivered version; user-facing release notes list all four changes since it.

INTEGRATION_RECEIPT0940.json records all ten approved patch-file hashes and the two transport-only JSON restorations. The original patch omitted newline markers, so its raw replay attached two following diff headers to JSON. Exact independently reviewed candidate bytes restored those two files before the hold; no engineering assertion or expected value changed. A corrected patch addendum preserves the original receipt and documents the repair.

RUNTIME_TEST_HOLD0940.json binds the final runtime/test/data bytes. Full current aggregate, independent integration replays, affected current-source outputs and final packaged-APP checks are separate gates. The 0.9.39 source tree and receipts remain unchanged. Its inventory-order clarification is external and copied here: the old committed array is used exactly; 0.9.40 inventories explicitly sort relative POSIX path strings.

Earlier example directories and validation receipts retain their historical versions. Current selected native/results and artifact manifests must identify their actual generating 0.9.40 runtime; Word application-version lines are distinguished from genuine 4E force-demand changes.
