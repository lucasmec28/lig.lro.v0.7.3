# APP evidence locations

SELECTION_MANIFEST and COMPACT_EVIDENCE_MANIFEST describe the selected external EXEMPLOS directory. The 42 native/results are copied exactly once into examples/release0940 according to APP_NATIVE_RESULT_MAP. The external evidence/ copies have their source-APP counterparts in docs/independent_outputs0940, avoiding a duplicate proof tree here. The current runtime gate reads only APP-contained native/results and portable commitments, never optional rendering companions.
