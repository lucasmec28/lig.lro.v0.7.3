# Current LRO 0.9.40 regression examples

These artifacts were freshly generated with global application version `0.9.40-4e-column-demand-dev` and the corrected 4E column-demand source. They are regression witnesses, not project design or fabrication approval.

The selected set contains 102 artifacts: all previous 84 cap, Lig18 and optional-inner-plate W artifacts, all seven current 4E native/result pairs, and four 4E Word reports. The four selected reports are compact/detailed positive N/M (`4E_M1_N+2`) and compact/detailed negative N/M with a separately applied minimum-force case (`4E_negative_NM_minimum`). Their 41 rendered pages were all visually inspected. The other ten freshly generated 4E Word reports and all PDF/page renders remain review-only.

Component versions remain as emitted by their actual APIs. Cap components remain 0.9.39 outer-end component revisions; W remains `0.9.6-w-inner-option-dev`. These have not been relabeled to imply a new calculation method. Lig18 native global metadata and W/Lig18 Word global version lines reflect the actual new generator. The 4E method revision is `endplate-4e-column-flange-demand-20261012-v1`.

The current 4E results use local column-web yielding under `max(Ff,Fc)` and crippling under `Fc`. Bolt force and the distinct contact resultant are retained. Exact full-precision result snapshots match the independently approved correction candidate, and eight current signed/minimum case records were checked with independent arithmetic. Display rounding is separate from stored values.

Adverse states remain explicit: the angled w1 cap witnesses stay `OUTSIDE_SCOPE`, W with inner plates stays `LOCAL_CHECKS_PENDING`, W outer-only stays `VERIFIED_SUBCHECK_FAIL`, and Lig18 retains unverified assembly access plus pending local qualification of the perforated internal fin.

`SELECTION_MANIFEST.json` and `SELECTED_FILES.txt` are the exact optional-example selection. `APP_NATIVE_RESULT_MAP.json` maps the 42 current native/result JSON files once into `examples/release0940/` within APP. Drawings and Word files stay outside APP. The map and compact provenance belong under `docs/qualification_combined0940/current_examples/`.

The in-memory size measurement for these selected102 files is 16,250,995 ZIP bytes at DEFLATE level9. The selected18 new4E files occupy915,682 ZIP bytes alone. These measurements do not include other root-approved historical additions or package metadata. No release archive was built by this reviewer. The packager must verify the final EXEMPLOS archive is below20,000,000 bytes.

The final self-contained output entry point is `docs/independent_outputs0940/portable/replay_current_outputs.py`. It binds the actual four-root APP loader and archive, verifies current native/result copies and reviewed runtime/proof hashes, freshly regenerates112 artifact commitments, and runs the shipped56 UI/output tests with materialized legacy natives. It requires no old source tree or optional EXEMPLOS archive. Source-mode execution is only source qualification; an actual final-APP run remains mandatory after packaging.
