# MRE1/2 · 12 parafusos sem nervuras

Implementação 0.9.41, sucessora isolada de 0.9.40. Identidade nativa `MRE12_U`.
A seleção fica na mesma família End plate engastada; as outras 19 rotas não mudam.
O contrato matemático e de domínio está em `qualification_mre12_0941/CONTRACT.md`.

## Caminho físico

Seis linhas fixas, dois parafusos por linha. Para M positivo, linhas 1/2/3 em
tração e 4/5/6 em cisalhamento; para M negativo, grupos refletidos. V integral
vai aos seis parafusos do lado comprimido. Cada parafuso mantém x/y, identidade,
tração, cortante assinado em cada peça e interação própria. Contato por furo usa
a próxima descontinuidade física no sentido da força; coluna contínua não ganha
borda longitudinal na altura da chapa. Doze candidatos de bloco conservam todos
os furos, áreas e somente a demanda dos parafusos carregados contidos.

A chapa tem hp=d+2(pfo+de), sem somar pb ao prolongamento externo. pb define
as segundas linhas internas. Saturação de pfi ocorre apenas em Yp, jamais em
coordenadas, braços, c, soldas ou blocos. pfo não satura e não há gate de<s.

## Classificações separadas

O método continua por demanda: chapa espessa / sem alavanca na demanda de
cálculo. Ambas as espessuras requeridas devem atender, sem tolerância. Mpl e
Mcf são também comparados a 1,10Mnp nominal, em diagnóstico separado, sem
alarme resistente ou gate redundante. Só a aprovação nominal de ambas permite
a frase “sem prying até Mnp”. O nominal DG39 literal usa 90/113 ksi para
Group120/150; o nominal derivado da NBR, 0,75fubAb, permanece identificado à parte.

Ff/Fc são forças de mesa. T=6Tb e C=max(T−N;0) são resultantes distintas.
Extensão recebe Ff/3 e alma recebe 2Ff/3. CJP usa materiais independentes,
comprimentos físicos disjuntos e pisos de desenvolvimento sem N adicional.
A correção 4E de 0.9.40 foi preservada, com paridade completa em 80 testemunhos.

## Escopo e dados

N/M/V assinados, M≠0 e |N|(d−tf)≤|M|. O mínimo de 45 kN é outro caso completo,
com N/V proporcionais e M preservado. Um mínimo fora do domínio deixa os
resultados reais intactos e a pendência explícita. Momento puro não inventa uma
direção de força mínima.

Aços independentes da viga/chapa A36/A572 Gr.42/Gr.50; coluna verificada
separadamente. O consumidor do nativo deve informar `cjp_electrode` e
`cjp_compatible`; o valor padrão desta declaração é falso. O exemplo positivo
é sintético, com declaração afirmada só para a reprodução numérica, não prova
de oficina/projeto real. Não são usados campos de nervuras ou campos legados
n/pitch/overhang/weld para redefinir a geometria MRE1/2.

Sem MRE1/3, placa fina/prying resistente, reforço de coluna, contato axial
dominante, sismo, fadiga ou fabricação. Contrato A-4(a): I simétrico reconhecido,
coluna contínua, uma viga perpendicular centrada, sem viga oposta ou outras
forças locais; Ncol≤0,4Agfyc e análise global externa.

## Reprodução e evidência

- `tests/fixtures/mre12_independent0941.json`: oráculo independente, 22 casos
  positivos e controles negativos, sem importar a aplicação.
- `tests/test_end_plate_mre120941.py`: fórmulas, forças, caminhos, sinais,
  nominal/demanda, mínimo, domínio, ULPs, identidade, materiais e topologia.
- `tests/test_end_plate_mre12_artifacts0941.py`: UI real, desenho, nativo, Word,
  precisão e invalidação de artefatos.
- `docs/independent_mre12_0941/`: recibos compactos de revisão independente.
- `examples/mre12_0941/reproduce_examples.py`: gera nativos e, opcionalmente,
  SVG/PNG/Word atuais sem depender de resultados salvos.

Entradas, contas e JSON conservam precisão integral. Apresentação usa até duas
casas; conversão N↔kgf conserva a limitação de arredondamento binário já declarada.
O relatório é sempre recalculado, mesmo quando o chamador fornece resultado antigo.
Arquivos brutos exploratórios de renderização não integram a nova evidência enviada.
