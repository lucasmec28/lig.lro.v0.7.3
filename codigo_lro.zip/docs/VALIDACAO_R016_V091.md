# Validação R016 · 0.9.1-angle-dev

Data: 2026-10-09. Integração local de desenvolvimento, sem publicação ou deploy.

## Evidência independente

Os esperados de componentes foram calculados antes da implementação. O confronto do contrato completo calcula seus esperados antes de importar o motor e usa o aplicativo apenas como objeto sob teste. Comando portátil a partir da raiz do fonte:

    python docs/r016_verification/compare_r016_app_contract.py

Resultado: 228 comparações numéricas, 76 por caso, sem divergência (rel_tol1e-12/abs_tol1e-8). Registro: docs/r016_verification/r016_app_contract_comparison.json.

- Baseline: dois L76×76×6,4, L260, M20, quatro furos por interface, W355/mesa de apoio real. Limite local305.280N; ruptura líquida conservadora da alma, usando altura livre308mm.
- V invertido com bordas assimétricas: sentidos físicos e troca da borda carregada conferidos; limite local305.280N neste conjunto de entradas.
- Apoio adversarial bf170/tf3, ponta inferior30mm: limite175.600N pelo bloco L da mesa, com falha para V200.000N. O apoio não é protegido artificialmente por uma capacidade do Gerdau que o exclui.

Hipóteses diferentes do fixture primitivo são deliberadas e explícitas: fub atual830MPa versus entrada sintética825MPa; altura local conservadora308mm versus H355mm; Cts0,5 conservador no apoio versus1 no caminho uniforme clássico. Não se compara cegamente uma resistência atual com o número histórico NBR2008.

## Testes novos

- 59 testes de motor, primitivas e gates: coeficientes atuais, interfaces e espessuras, prefixos de blocos, sinais, soma normativa e compatibilidade por furo, Cv, ação mínima, domínio, erros numéricos e JSON estrito.
- 15 AppTests: perfis distintos, entradas independentes, V real/adotado, N/M/T não descartados, importação sem normalização, rascunhos ocultos/famílias, recuperação de erro, geração e invalidação da memória.
- 22 testes de artefatos: duas formas L verdadeiras em planta, parafuso comum, furos independentes, bordas reais do apoio, força com sinal, topologia não inventada, entrada usada no desenho, ausência de figura vazada, Word editável e gates defensivos de aprovação.

Os critérios convencionais L≥H/2 e grupo superior/centralizado são qualificação do modelo, não geometria universalmente impossível: teste próprio mantém geometry.valid e bloqueia por ENGINEERING_MODEL_PENDING quando a rota não se aplica.

## Word e desenho

Três conjuntos JSON/SVG/DOCX foram gerados do motor congelado: R016_cortante_positivo, R016_cortante_invertido e R016_falha_resistente. Todos os JSON reabrem sem mudança. Os três Word foram renderizados e tiveram suas 63 páginas inspecionadas visualmente, incluindo desenhos, equações OMML editáveis, tabelas e resultados. Não foi encontrado corte ou sobreposição de conteúdo. Evidências de render ficam fora do fonte distribuído.

O memorial registra cada campo de entrada, premissas fixas de contato/montagem, geometria derivada, cada condição geométrica, ação efetiva e adotada, cada check resistente, fórmulas, referências e valores auxiliares de todos os trajetos de bloco. Não filtra as verificações falhas ou as pendências do modelo. Atendimento local R016 é distinto da verificação global do pilar/estrutura.

## Preservação da base

A cópia de trabalho veio de connections_work090_w/source após confirmação de congelamento. Entre os Python pré-existentes, somente app.py (registro da família/imports) e lro/models.py (VERSION) mudaram. Nove módulos e testes W permanecem byte a byte iguais ao checkpoint090. O label e o JSON W conservam 0.9.0-w-dev e domínio axial parcial. Bases086 e demais famílias não foram reescritas.

## Agregado final

O agregado integral da árvore congelada passou **1.003 testes em519,35s**, com hashes de código, testes e exemplos idênticos antes/depois. O log e a proveniência abaixo registram esse snapshot exato.

Após esse agregado, a auditoria independente identificou uma lacuna estreita: gap=0 não era qualificado para o mecanismo flexível sem contato de extremidade. Aplicou-se apenas o gate ENGINEERING_MODEL_PENDING para folga exatamente zero, conservando geometria e resistências locais. Acrescentaram-se três regressões (motor/JSON, UI e Word). Nenhuma resistência numérica, exemplo comgap10 ou família anterior mudou.

No fonte final pós-ajuste, **96 testes R016 passaram em45,31s**:59 de motor/JSON,15 de UI e22 de artefatos. A execução ocorreu depois da última mudança de redação sobre gabaritos alternativos. A auditoria independente do responsável pela integração também passou565 asserções em37 casos, inclusive folga zero direta/importada e folgas positivas sem limite universal10mm.

As três memórias dos exemplos foram recriadas em memória com o motor final e seu word/document.xml comparado ao dos arquivos existentes: conteúdo idêntico nos três casos. Os exemplos comgap10 e suas63 páginas já inspecionadas permaneceram válidos sem nova geração de arquivos.

Não se apresenta o agregado pré-ajuste como uma nova execução integral do código pós-ajuste. A distinção e os hashes finais são registrados em R016_POST_AUDIT_GATE_PROVENANCE.json; o log afetado fica em R016_POST_AUDIT_GATE_TEST_LOG.txt.

O log integral e hashes antes/depois ficam em R016_FINAL_AGGREGATE_TEST_LOG.txt e R016_FINAL_AGGREGATE_PROVENANCE.json. As contagens de testes são evidência de execução de software; a fundamentação mecânica e o domínio continuam descritos em CANTONEIRAS_R016_V091.md.
