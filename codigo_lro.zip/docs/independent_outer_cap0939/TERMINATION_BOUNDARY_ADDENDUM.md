# Active-cap weld termination equality correction

12 October 2026. Independent read-only focused review.

## Reproduction and scoped correction

The previous candidate falsely reported `outer_normal_cut_free_termination` at the exact one-leg5.0 mm outer margin for both one-root welded1L and2L-T at theta45°,60° and135°. Bounded segment projection produced minimum gaps as small as4.999999999999955 mm. The90° comparison happened to remain exactly5.0 mm. Pre-fix values are preserved in `termination_boundary_before_fix.json`.

The correction uses the existing polygon geometry-scale tolerance only when the termination edge's semantic identity is `outer_normal_cut_free`. Original edge comparisons remain exactly strict, including old edges in active-trim geometry. No distance is rounded or altered in inputs or recorded clearances. No K, resistance, material, load-sign or geometry formula changed.

This is supported by a byte-level focused proof: restoring only the old termination-comparison block reproduces the preceding `welded_angle_gusset.py` SHA256 `fe0e3ee2c9c62ee73baf115a6e8189b7ff03393d1bc9c1af5a050807e0836449`. The corrected file SHA256 is `ba013d94e3eb93e7c00cd4d17c6920d14a88da8fb3359c2007c8b5f1f073e176`. The block diff and proof are in `termination_boundary_focused_diff.txt` and `termination_boundary_diff_proof.json`.

## Independent checks

All52 cases pass:

- Both welded families at45°,60°,90° and135°.
- e4.999 mm remains a termination failure.
- e=5−4×the geometry tolerance remains a failure.
- e=5−0.25×the geometry tolerance, exact5.0, e=5+0.25×tolerance and e5.001 do not falsely fail this cap termination comparison.
- Original and no-trim contours keep their historical strict old-edge check: a deliberately tiny top-edge shortfall still fails.
- The configured distance stays unrounded and every tested cap gauge remains tied to a real bounded dimension.

The tolerance here is numerical geometry precision, not an additional fabrication allowance. Other whole-connection failures or domain restrictions remain active and are not reclassified by the boundary check.

The complete11-group independent suite still passes. All portable replays were also rerun:11 engine groups,52 boundary cases,19 exact opposed payloads with zero differences, CC1/BCC1 compression checks, four description states and15 exact source/oracle identities. Prior review artifacts remain preserved.

## Current commitments

The amended mechanical identity is `reviewed_core_hashes_after_termination.txt`, with stable final receipt `core_hash_recheck_after_termination.json`. Exactly one of the13 mechanical files changed relative to the description-only seal; the other12 remain unchanged.

The refreshed portable bundle includes `replay_termination_boundaries.py` and the amended source-hash manifest. Copy its entire `portable/` directory, including `data/`, rather than retaining the preceding bundle's source hashes. `portable/MANIFEST.json` and `PORTABLE_VALIDATION_AFTER_TERMINATION.json` identify and verify it.

No release, manufacturing or expanded mechanical qualification is implied. The existing external bearing-oracle gap and all prior scope restrictions remain explicit.
