# Final independent mechanical qualification

Read TERMINATION_BOUNDARY_ADDENDUM.md and core_hash_recheck_after_termination.json for the current 13-file identity. Earlier reports and addenda remain historical steps, not competing final identities. The portable/data manifest is updated to the final corrected source.

The complete self-contained portable kit covers independent clipping/sections/path checks, the frozen seven-case numeric commitment, 19 exact opposed payload commitments, compression restrictions, four description states and 52 exact-one-leg boundary cases. It writes only to an explicit output directory outside source. Follow portable/README.md. No old source tree or external download is required for these release-critical checks.

These groups, geometry samples, payload commitments and case witnesses are distinct review units. They are not added to the full production test count. The historical external bolt-bearing oracle remains missing.
