"""Portable exact full-payload replay for welded/bolted opposed routes."""
import argparse,os,sys,json,hashlib
from pathlib import Path
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',default=os.environ.get('OUTER_CAP_SOURCE'));p.add_argument('--output-dir',default=os.environ.get('OUTER_CAP_OUTPUT',str(Path.cwd()/'outer_cap_replay_results')));p.add_argument('--baseline-hashes',default=str(HERE/'data/opposed_baseline_payload_hashes.json'));p.add_argument('--save-full',action='store_true');args=p.parse_args()
if not args.source:p.error('--source or OUTER_CAP_SOURCE required')
SOURCE=Path(args.source).resolve();DEST=Path(args.output_dir).resolve()
if DEST.is_relative_to(SOURCE):p.error('--output-dir must be outside candidate source')
DEST.mkdir(parents=True,exist_ok=True);sys.path.insert(0,str(SOURCE))
from dataclasses import replace
from lro import welded_opposed_angle_gusset as w,bolted_opposed_angle_gusset as b
out={}
for module in (w,b):
 for label,c in module.presets().items():
  native=c.to_dict();loaded=type(c).from_dict(native)
  assert loaded.to_dict()==native
  out[module.CONNECTION_TYPE+' / '+label]={'native':native,'result':module.evaluate(c),'loaded_result':module.evaluate(loaded)}
# Invalid but typed original-mode inputs must preserve their previous error payload.
for field,value in [('N',-100000.),('theta_deg',0.),('N',1.),('plate_width',-1.)]:
 c=replace(w.WeldedOpposedAngleGusset(),**{field:value});out['welded_invalid_'+field+'_'+str(value)]={'result':w.evaluate(c)}

expected=json.loads(Path(args.baseline_hashes).read_text())['cases'];actual={k:hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest() for k,v in out.items()}
results=[dict(case=k,expected_sha256=expected.get(k),actual_sha256=actual.get(k),match=expected.get(k)==actual.get(k)) for k in sorted(expected.keys()|actual.keys())]
base=w.WeldedOpposedAngleGusset();assert w.evaluate(replace(base,gusset_weld_end_distance=999.))==w.evaluate(base)
rejected=w.evaluate(replace(base,gusset_end_shape='normal_cut',gusset_weld_end_distance=35.));assert rejected['status']=='INVALID_INPUT' and not rejected['local_pass']
try:replace(base,gusset_end_shape='normal_cut',gusset_weld_end_distance=35.).to_dict()
except ValueError:pass
else:raise AssertionError('Unsupported opposed cut accepted')
summary=dict(cases=len(results),different_cases=sum(not x['match'] for x in results),unsupported_cut_rejected=True,inactive_field_ignored=True,results=results)
(DEST/'opposed_replay_results.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
if args.save_full:(DEST/'opposed_candidate_full.json').write_text(json.dumps(out,ensure_ascii=False,allow_nan=False))
print('Opposed full payload cases:',len(results),'differences:',summary['different_cases'])
sys.exit(1 if summary['different_cases'] else 0)
