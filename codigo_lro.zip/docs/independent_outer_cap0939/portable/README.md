# Portable independent outer-cap review replays

These are portable copies/additional replay drivers. The original review scripts, reports and historical hash receipts remain unchanged outside this directory. No candidate source is edited. The scripts disable Python bytecode writes for candidate imports and send generated results only to the selected output directory.

## Inputs and dependencies

- Python3.11 or later, NumPy and SciPy. No pytest required.
- Candidate source root containing `lro/`.
- Planning oracle directory containing `independent_cap_oracle.py` and `verify_independent_contract.py`. If omitted, it defaults to `SOURCE/docs/qualification_outer_end0939`.
- `data/` belongs beside these scripts. It contains the frozen7-case0938 original-mode baseline, compressed losslessly,19 canonical full-payload baseline digests for opposed routes, and the exact reviewed source/oracle hashes.

The original verifier used NumPy2.3.5 and SciPy1.17.0. Float serialization of full-payload digests is deliberately exact; a different interpreter/library result is a mismatch to investigate, not a tolerance-based pass.

## Replay

Run from any current working directory. Paths below are examples of arguments, not fixed locations:

```sh
python /path/to/replays/verify_source_hashes.py --source /path/to/source --oracle-dir /path/to/oracles --output-dir /path/to/results
python /path/to/replays/replay_engine.py --source /path/to/source --oracle-dir /path/to/oracles --output-dir /path/to/results
python /path/to/replays/replay_opposed.py --source /path/to/source --output-dir /path/to/results
python /path/to/replays/replay_corner_compression.py --source /path/to/source --output-dir /path/to/results
python /path/to/replays/replay_descriptions.py --source /path/to/source --output-dir /path/to/results
python /path/to/replays/replay_termination_boundaries.py --source /path/to/source --output-dir /path/to/results
```

Instead of flags, `OUTER_CAP_SOURCE`, `OUTER_CAP_ORACLE_DIR` and `OUTER_CAP_OUTPUT` supply the corresponding defaults. `--source` or its environment variable is required. The default output folder is `outer_cap_replay_results` under the caller's current directory. Choose an output directory outside the candidate source.

- `replay_engine.py`: the11 independent mechanical groups,500 cap polygons,243 corner block witnesses,39 perforated section checks, rational extrema, signs/stamps, roots/Whitmore, no-op cases and7-case original/native parity. The portable copy also asserts principal status/completeness flags against the frozen original payload. It calls `parity_dump.py` in a fresh process to regenerate the candidate comparison.
- `replay_opposed.py`:19 complete native/result/round-trip payloads checked against exact canonical baseline digests, plus active/inactive unsupported-control gates. Use `--save-full` to retain the full approximately25 MB candidate payload as well. Canonical digests preserve keys, value types, strings, numerical values and list order; dictionary key order is intentionally irrelevant.
- `replay_corner_compression.py`: CC1/BCC1 active cuts retain the real receiver failure and unchanged root/receptor/strip mechanics, while stale detail declarations are rejected.
- `replay_descriptions.py`: invalid gauge, real gauge, no-trim and root-footprint-invalid description states.
- `replay_termination_boundaries.py`:52 active-cap one-leg termination boundary cases for both welded families, including exact equality, geometry-tolerance-sized perturbations, true subminimum4.999 mm and unchanged strict original/no-trim comparisons.
- `verify_source_hashes.py`: the13 reviewed mechanical source files and2 independent oracle helpers. A mismatch means the old review seal does not apply to those bytes, even if numerical replays pass.

Every failed assertion or identity mismatch returns nonzero. Successful replays do not approve manufacturing, global stability, package delivery or release. The missing independent external bearing oracle remains disclosed and is not replaced by these checks.
