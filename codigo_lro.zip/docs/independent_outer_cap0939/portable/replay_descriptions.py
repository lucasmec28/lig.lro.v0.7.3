"""Replay physical/invalid/no-trim description semantics against candidate source."""
import argparse,os,sys,json
from pathlib import Path
sys.dont_write_bytecode=True
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',default=os.environ.get('OUTER_CAP_SOURCE'));p.add_argument('--output-dir',default=os.environ.get('OUTER_CAP_OUTPUT',str(Path.cwd()/'outer_cap_replay_results')));args=p.parse_args()
if not args.source:p.error('--source or OUTER_CAP_SOURCE required')
SOURCE=Path(args.source).resolve();DEST=Path(args.output_dir).resolve()
if DEST.is_relative_to(SOURCE):p.error('--output-dir must be outside candidate source')
DEST.mkdir(parents=True,exist_ok=True);sys.path.insert(0,str(SOURCE))
from lro import gusset_outer_end as end,bolted_angle_gusset as bolt
from dataclasses import replace
fmt=lambda v:format(v,'.2f');base=[(0.,0.),(400.,0.),(400.,300.),(0.,300.)];a=(2**-.5,2**-.5);ids=('root','right','top','left');roots={'root_support':[(0.,0.),(400.,0.)]}
invalid=end.build(base,a,[(380.,200.)],35.,'normal_cut',ids,roots);text=end.description(invalid,fmt)
assert invalid['outer_end_cut']['trimmed'] and invalid['outer_end_cut']['dimension'] is None
assert 'configuração inválida' in text and 'Não há cota física de corte válida' in text
c=replace(bolt.BoltedAngleGusset(),gusset_end_shape='normal_cut',gusset_bolt_end_distance=35.)
valid=end.one_root(c);vt=end.description(valid,fmt);assert valid['outer_end_cut']['dimension'] is not None and '35.00 mm após o centro do último parafuso físico' in vt
assert 'Raízes preservadas' not in vt and 'Exige contatos e pegadas' in vt
noop=end.one_root(replace(c,gusset_bolt_end_distance=1e6));nt=end.description(noop,fmt);assert 'não há nova face para cotar' in nt
rootloss=end.build(base,a,[(150.,150.)],100/2**.5,'normal_cut',ids,roots,[('root_weld_footprint',[(0.,5.),(400.,5.)])]);rootloss['outer_end_cut']['reference_kind']='physical_weld_end';rt=end.description(rootloss,fmt)
assert rootloss['problems'] and rootloss['outer_end_cut']['dimension'] is not None and 'Exige contatos e pegadas' in rt and 'Raízes preservadas' not in rt
result=dict(checks=4,passed=4,texts={'invalid_gauge':text,'valid_gauge':vt,'no_trim':nt,'root_footprint_invalid_with_real_gauge':rt})
(DEST/'description_replay_results.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print('Description states checked: 4, passed: 4')
