"""Replay actual-cut CC1/BCC1 compression gates and unchanged common mechanics."""
import argparse,os,sys,json,math,numbers
from pathlib import Path
sys.dont_write_bytecode=True
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',default=os.environ.get('OUTER_CAP_SOURCE'));p.add_argument('--output-dir',default=os.environ.get('OUTER_CAP_OUTPUT',str(Path.cwd()/'outer_cap_replay_results')));args=p.parse_args()
if not args.source:p.error('--source or OUTER_CAP_SOURCE required')
SOURCE=Path(args.source).resolve();DEST=Path(args.output_dir).resolve()
if DEST.is_relative_to(SOURCE):p.error('--output-dir must be outside candidate source')
DEST.mkdir(parents=True,exist_ok=True);sys.path.insert(0,str(SOURCE))
from lro import corner_gusset as c,corner_compression as cc
from dataclasses import replace

def same(a,b):
 if isinstance(a,dict) and isinstance(b,dict):return a.keys()==b.keys() and all(same(a[k],b[k]) for k in a)
 if isinstance(a,(list,tuple)) and isinstance(b,(list,tuple)):return len(a)==len(b) and all(same(x,y) for x,y in zip(a,b))
 if isinstance(a,numbers.Real) and isinstance(b,numbers.Real):return math.isclose(a,b,rel_tol=2e-12,abs_tol=2e-8)
 return a==b

results=[]
for label,base in c.presets().items():
 if not label.startswith(('CC1 ·','BCC1 ·')):continue
 old=c.analyze(base);cut=replace(base,gusset_end_shape='normal_cut',**{('gusset_bolt_end_distance' if c.is_bolted(base) else 'gusset_weld_end_distance'):35.})
 stale=c.analyze(cut);current=c.analyze(cc.declare_current_detail(cut,'Independent synthetic witness, not physical evidence'))
 assert 'compression_geometry_declaration' in [x['id'] for x in stale['issues']]
 assert 'compression_geometry_declaration' not in [x['id'] for x in current['issues']]
 assert old['status']==current['status']=='FAIL' and old['complete']==current['complete']==True
 for key in ('forces','equilibrium_residuals','joint_distribution','seams','receiver_unions','column_sections','panel'):assert same(old[key],current[key]),(label,key)
 for key in ('width','Lmax','resistance','area'):
  if key in old['compression']:assert same(old['compression'][key],current['compression'][key]),(label,key)
 results.append(dict(case=label,status=current['status'],complete=current['complete'],actual_trim=current['geometry']['outer_end_cut']['trimmed'],stale_evidence_rejected=True,root_receiver_strip_invariant=True))
assert len(results)==2
(DEST/'corner_compression_replay_results.json').write_text(json.dumps(results,indent=2,ensure_ascii=False)+'\n')
print('CC1/BCC1 active-cut compression cases passed:',len(results),'with original receiver failures retained')
