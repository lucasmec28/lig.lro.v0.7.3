"""Dump original-mode candidate payloads for portable independent parity review."""
import argparse,os,sys,json
from pathlib import Path
sys.dont_write_bytecode=True
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',default=os.environ.get('OUTER_CAP_SOURCE'));p.add_argument('--output',required=True);args=p.parse_args()
if not args.source:p.error('--source or OUTER_CAP_SOURCE required')
SOURCE=Path(args.source).resolve()
if Path(args.output).resolve().is_relative_to(SOURCE):p.error('--output must be outside candidate source')
sys.path.insert(0,str(SOURCE))
from dataclasses import replace
from lro import welded_angle_gusset as w,welded_double_angle_gusset as d,bolted_angle_gusset as b,corner_gusset as c
cases=[('welded',w.evaluate,w.WeldedAngleGusset()),('double',d.evaluate,d.WeldedDoubleAngleGusset()),('double_compression',d.evaluate,replace(d.WeldedDoubleAngleGusset(),N=-100000.)),('bolt',b.evaluate,b.BoltedAngleGusset()),('corner',c.analyze,c.CornerGusset()),('corner_bolted',c.analyze,replace(c.CornerGusset(),topology='symmetric_2L_T_bolted'))]
for key,x in c.presets().items():
 if key.startswith('BCC1 ·'):cases.append(('corner_bolt_compression',c.analyze,x))
out={}
for key,fn,cc in cases:
 r=fn(cc)
 out[key]=dict(config=cc.to_dict(),result=r)
json.dump(out,open(args.output,'w'),allow_nan=False)
