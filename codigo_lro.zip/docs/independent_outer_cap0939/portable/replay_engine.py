"""Portable independent outer-cap mechanical replay. Read-only candidate source."""
import argparse,os,sys,math,json,random,unittest,numbers,gzip,subprocess
from pathlib import Path
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source',default=os.environ.get('OUTER_CAP_SOURCE'),help='Candidate source root containing lro/. Required, or set OUTER_CAP_SOURCE.')
parser.add_argument('--oracle-dir',default=os.environ.get('OUTER_CAP_ORACLE_DIR'),help='Directory containing independent_cap_oracle.py and verify_independent_contract.py; defaults to SOURCE/docs/qualification_outer_end0939.')
parser.add_argument('--output-dir',default=os.environ.get('OUTER_CAP_OUTPUT',str(Path.cwd()/'outer_cap_replay_results')))
parser.add_argument('--baseline',default=str(HERE/'data/baseline_original.json.gz'),help='Frozen 0938 original-mode payload, JSON or JSON.gz.')
args=parser.parse_args()
if not args.source:parser.error('--source or OUTER_CAP_SOURCE is required')
SOURCE=Path(args.source).resolve();ORACLE=Path(args.oracle_dir).resolve() if args.oracle_dir else SOURCE/'docs/qualification_outer_end0939';EVIDENCE=Path(args.output_dir).resolve()
if EVIDENCE.is_relative_to(SOURCE):parser.error('--output-dir must be outside candidate source')
EVIDENCE.mkdir(parents=True,exist_ok=True)
for required in (SOURCE/'lro',ORACLE/'independent_cap_oracle.py',ORACLE/'verify_independent_contract.py'):
 if not required.exists():parser.error('Required input absent: '+str(required))
sys.path.insert(0,str(SOURCE));sys.path.insert(0,str(ORACLE))
baseline_path=Path(args.baseline)
with (gzip.open(baseline_path,'rt',encoding='utf-8') if baseline_path.suffix=='.gz' else baseline_path.open(encoding='utf-8')) as handle:baseline=json.load(handle)
(EVIDENCE/'baseline_original.json').write_text(json.dumps(baseline,ensure_ascii=False,allow_nan=False))
subprocess.run([sys.executable,str(HERE/'parity_dump.py'),'--source',str(SOURCE),'--output',str(EVIDENCE/'candidate_original.json')],check=True,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
candidate=json.loads((EVIDENCE/'candidate_original.json').read_text());diffs=[]
def compare_original_numbers(x,y,path=''):
 if type(x) in (float,int) and type(y) in (float,int):
  if x!=y:diffs.append(dict(path=path,old=x,new=y))
 elif isinstance(x,dict) and isinstance(y,dict):
  for k in x.keys()&y.keys():compare_original_numbers(x[k],y[k],path+'/'+k)
 elif isinstance(x,list) and isinstance(y,list):
  if len(x)!=len(y):diffs.append(dict(path=path,old_length=len(x),new_length=len(y)))
  else:
   for i,(a,b) in enumerate(zip(x,y)):compare_original_numbers(a,b,path+'/'+str(i))
compare_original_numbers(baseline,candidate)
(EVIDENCE/'original_numeric_diffs.json').write_text(json.dumps(diffs,indent=2)+'\n')
from dataclasses import replace
from types import SimpleNamespace
from independent_cap_oracle import *
from verify_independent_contract import rounded_rational_witness,quadrature_section
from lro import gusset_outer_end as end,gusset_outer_sections as sec,welded_angle_gusset as weld,bolted_angle_gusset as bolt,bolted_gusset_geometry as bg,corner_gusset as corner,bolted_corner as bc,one_root_compression as comp,welded_double_angle_gusset as double,corner_compression as cc
RESULTS={}
def numbers_same(a,b,atol=2e-8):
 if isinstance(a,dict) and isinstance(b,dict):return a.keys()==b.keys() and all(numbers_same(a[k],b[k],atol) for k in a)
 if isinstance(a,(list,tuple)) and isinstance(b,(list,tuple)):return len(a)==len(b) and all(numbers_same(x,y,atol) for x,y in zip(a,b))
 if isinstance(a,numbers.Real) and isinstance(b,numbers.Real):return math.isclose(a,b,rel_tol=2e-12,abs_tol=atol)
 return a==b

def trimmed(c,distance=35.):
 return replace(c,gusset_end_shape='normal_cut',**{('gusset_bolt_end_distance' if hasattr(c,'n') or corner.is_bolted(c) else 'gusset_weld_end_distance'):distance})

class EngineReview(unittest.TestCase):
 def test_001_primary_rational_section_and_signed_inverse(self):
  w=rounded_rational_witness();c=SimpleNamespace(plate_t=10.,weld_length=40.,introduction_width=140.)
  g=dict(direction=w['axis'],polygon=w['polygon'],weld_lines=[dict(start=q['start'],end=q['end'],centroid=[(q['start'][i]+q['end'][i])/2 for i in (0,1)],force_fraction=q['F']/100000) for q in w['lines']],angle_section=dict(centroid=28.,leg=100.),introduction_endpoints=w['local_introduction']['endpoints'])
  pos=sec.welded_horizontal_sections(c,g,100000.);neg=sec.welded_horizontal_sections(c,g,-100000.)
  self.assertAlmostEqual(pos['min_normal'],-7.85623377186645,places=9)
  self.assertAlmostEqual(max(q['sigma_MPa'] for q in neg['cuts']),7.85623377186645,places=9)
  for row in pos['cuts']:
   expected=quadrature_section(g['polygon'],g['direction'],w['lines'],10.,row['y'])['sigma'][0 if row['edge']=='-s' else 1]
   self.assertAlmostEqual(row['sigma_MPa'],expected,places=8)
  RESULTS['rational']={'min':pos['min_normal'],'max_compressive_case_tension':max(q['sigma_MPa'] for q in neg['cuts']),'rows_checked':len(pos['cuts'])}

 def test_002_analytic_polygon_terminal_physical_hole_and_unique_group(self):
  c=bolt.BoltedAngleGusset(plate_width=400.,plate_height=300.,plate_t=10.,theta_deg=45.,center_s=0.,center_n=200.,n=2,pitch=100*math.sqrt(2),db=19.05,gusset_end_shape='normal_cut',gusset_bolt_end_distance=35.,minimum_force=False)
  r=bolt.evaluate(c);g=r['geometry'];P=[(x-200,y) for x,y in witness()['primary']['polygon']]
  self.assertTrue(numbers_same(sorted(g['polygon']),sorted(P)))
  self.assertAlmostEqual(r['cases'][0]['bearing']['gusset'][-1]['lc'],24.68125,places=9)
  c1=replace(c,arrangement='1L');r1=bolt.evaluate(c1)
  self.assertEqual(r1['geometry']['polygon'],g['polygon']);self.assertEqual(g['physical_bolt_count'],2)
  self.assertEqual(r1['cases'][0]['bearing']['gusset'],r['cases'][0]['bearing']['gusset'])
  RESULTS['physical_bolt']={'polygon':g['polygon'],'terminal_lc':r['cases'][0]['bearing']['gusset'][-1]['lc'],'physical_count':g['physical_bolt_count'],'status':r['status']}

 def test_003_root_and_constant_u_invariance_with_changed_paths(self):
  summaries=[]
  for mod,c in [(weld,weld.WeldedAngleGusset()),(double,double.WeldedDoubleAngleGusset()),(bolt,bolt.BoltedAngleGusset())]:
   original=mod.evaluate(c);active=mod.evaluate(trimmed(c));g0,g1=original['geometry'],active['geometry']
   self.assertTrue(numbers_same(original['cases'][0]['root'],active['cases'][0]['root']))
   self.assertTrue(numbers_same(original['cases'][0]['member_actions'],active['cases'][0]['member_actions']))
   if mod is bolt:
    self.assertTrue(numbers_same(g0['Whitmore'],g1['Whitmore']))
    self.assertTrue(numbers_same(original['cases'][0]['force_normal_cuts'],active['cases'][0]['force_normal_cuts']))
    paths=[q for q in active['cases'][0]['paths'] if q['component']=='gusset']
    for p in paths:
     self.assertAlmostEqual(norm(sub(p['coordinates'][0],p['coordinates'][1]))*c.plate_t,p['Agv'],places=7)
     self.assertAlmostEqual(norm(sub(p['coordinates'][1],p['coordinates'][2]))*c.plate_t-p.get('tension_hole_deduction_length',0)*c.plate_t,p['Ant'],places=7)
     self.assertEqual(p['free_longitudinal_exit'],'outer_normal_cut_free')
     self.assertEqual(p['root_contact_length'],0.)
    self.assertLess(active['cases'][0]['bearing']['gusset'][-1]['lc'],original['cases'][0]['bearing']['gusset'][-1]['lc'])
   else:
    self.assertTrue(numbers_same(g0['introduction_endpoints'],g1['introduction_endpoints']))
    for v in (-50.,0.,50.):self.assertLess(weld._forward_exit(trimmed(c),v)['u'],weld._forward_exit(c,v)['u'])
   summaries.append({'family':mod.__name__,'roots_same':True,'physical_cut':g1['outer_end_cut']['state']})
  RESULTS['root_invariance']=summaries

 def test_004_circle_union_horizontal_sections_and_actual_chord(self):
  c=trimmed(bolt.BoltedAngleGusset(db=19.05,drilled=False,n=2,pitch=100*math.sqrt(2),plate_width=400.,plate_height=300.,plate_t=10.,theta_deg=45.,center_s=0.,center_n=200.,minimum_force=False));r=bolt.evaluate(c);g=r['geometry'];h=r['cases'][0]['horizontal_sections']
  tested=0
  for interval in h['intervals']:
   for key in ('min_sigma','max_VM','max_rupture'):
    row=interval[key]
    if row.get('zero_measure_unloaded_tip'):continue
    forces=[(j,c.N/c.n) for j,z in enumerate(row['active']) if z]
    expected=discrete_section(g['polygon'],row['y'],c.plate_t,g['bolt_centers'],g['net_hole_diameter'],forces,g['direction'])
    for name,ref in [('A','A'),('I','I'),('centroid_s','centroid_x'),('M','M'),('VM','VM')]:
     self.assertTrue(math.isclose(row[name],expected[ref],rel_tol=3e-11,abs_tol=3e-7),(name,row[name],expected[ref]))
    tested+=1
  self.assertIn('not an interval certificate',h['extrema_method'])
  RESULTS['horizontal_hole_witnesses']=tested

 def test_005_invalid_roots_bounded_exit_footprints_and_no_trim(self):
  base=[(0.,0.),(400.,0.),(400.,300.),(0.,300.)];a=(2**-.5,2**-.5);ids=('root','right','top','left');roots={'root_support':[(0.,0.),(400.,0.)]}
  bad=end.build(base,a,[(380.,200.)],35.,'normal_cut',ids,roots)
  self.assertIn('outer_end_reference_exit',[x[0] for x in bad['problems']]);self.assertIsNone(bad['outer_end_cut']['dimension'])
  q=end.build(base,a,[(150.,150.)],100/math.sqrt(2),'normal_cut',ids,roots,[('root_weld_footprint',[(0.,5.),(400.,5.)])])
  self.assertNotIn('outer_end_preserve_root_support',[x[0] for x in q['problems']]);self.assertIn('outer_end_preserve_root_weld_footprint',[x[0] for x in q['problems']])
  for ref,d,axis in [([(200.,200.)],300.,a),([(200.,200.)],100.,(0.,1.)),([(200.,200.)],300/math.sqrt(2),a)]:
   z=end.build(base,axis,ref,d,'normal_cut',ids,roots)
   self.assertEqual(z['outer_end_cut']['state'],'no_trim');self.assertIsNone(z['outer_end_cut']['dimension']);self.assertFalse(any(e['id']==end.CUT_EDGE for e in z['edges']))
  theta=math.radians(60.);axis=(math.cos(theta),math.sin(theta));limit=300*axis[1];ref=(200.,150.)
  vertex=end.build(base,axis,[ref],limit-dot(axis,ref),'normal_cut',ids,roots,[('root_weld_footprint',[(0.,5.),(400.,5.)])])
  self.assertFalse(vertex['problems']);self.assertTrue(vertex['outer_end_cut']['trimmed']);self.assertEqual(len(vertex['polygon']),4);self.assertTrue(all(e['length']>1e-8 for e in vertex['edges']))
  outside=end.build(base,a,[(500.,100.)],35.,'normal_cut',ids,roots)
  self.assertIn('outer_end_reference_exit',[x[0] for x in outside['problems']]);self.assertIsNone(outside['outer_end_cut']['reference_clearances'][0]['actual_first_exit'])
  for val in (0.,-1.,float('nan'),float('inf'),True,'35',None):
   z=end.build(base,a,[(250.,250.)],val,'normal_cut',ids,roots)
   self.assertEqual(z['outer_end_cut']['state'],'invalid_distance')

 def test_006_core_geometry_against_independent_polygon_for_500_cases(self):
  random.seed(193939);tested=0
  for k in range(500):
   B=random.uniform(80,800);H=random.uniform(80,800);theta=random.uniform(.001,179.999);a=(math.cos(math.radians(theta)),math.sin(math.radians(theta)));P=[(-B/2,0.),(B/2,0.),(B/2,H),(-B/2,H)]
   v0=min(dot(a,p) for p in P);v1=max(dot(a,p) for p in P);u=random.uniform(v0+(v1-v0)*.02,v1-(v1-v0)*.02)
   actual=end.clip(P,a,u);expected=cap(P,a,u)
   self.assertTrue(numbers_same(sorted(actual),sorted(expected)))
   ar,cg=area_centroid(expected);ar2,cg2=end.properties(actual)
   self.assertTrue(math.isclose(ar,ar2,rel_tol=2e-12,abs_tol=1e-7));self.assertTrue(numbers_same(cg,cg2))
   edges=end.tagged_edges(actual,P,('root','right','top','left'),a,u)
   for j in range(5):
    y=min(p[1] for p in actual)+(max(p[1] for p in actual)-min(p[1] for p in actual))*(j+.5)/5
    self.assertTrue(numbers_same(horizontal(expected,y),end.line_chord(actual,1,y)))
   tested+=1
  RESULTS['independent_polygon_cases']=tested

 def test_007_compression_stamps_signs_and_unchanged_strip(self):
  c=replace(double.WeldedDoubleAngleGusset(),N=-100000.,compression_root_rotation='confirmed',compression_root_source='Independent synthetic review only',compression_brace_rotation='confirmed',compression_brace_source='Independent synthetic review only',compression_receiver_relative='confirmed',compression_receiver_source='Independent synthetic review only',compression_receiver_interaction='isolated',compression_interaction_source='Independent synthetic review only')
  c=comp.bind_current_evidence(c);p=trimmed(c);old=double.evaluate(c);stale=double.evaluate(p)
  for role in ('root','brace','receiver'):self.assertNotEqual(comp.geometry_stamp(c,role),comp.geometry_stamp(p,role))
  self.assertFalse(stale['compression']['boundaries']['root']['qualified'])
  rebound=double.evaluate(comp.bind_current_evidence(p));self.assertTrue(rebound['compression']['boundaries']['root']['qualified'])
  for key in ('width','area','I','Lmax','Le','resistance','retained_v','ends','root_projections'):self.assertTrue(numbers_same(old['compression']['strip'][key],rebound['compression']['strip'][key]))
  self.assertTrue(numbers_same(old['cases'][0]['root'],rebound['cases'][0]['root']))
  for role in ('root','brace','receiver'):self.assertEqual(comp.geometry_stamp(c,role),comp.geometry_stamp(trimmed(c,1e6),role))
  for N,expected in [(0.,[0.,45000.]),(1.,[1.,45000.]),(-1.,[-1.,-45000.]),(45000.,[45000.]),(-45000.,[-45000.])]:
   r=double.evaluate(replace(p,N=N));self.assertEqual([q['N'] for q in r['cases']],expected)
   self.assertEqual([q['N_per_angle'] for q in r['cases']],[n/2 for n in expected]);self.assertEqual(r['geometry']['polygon'],stale['geometry']['polygon'])
  self.assertFalse(weld.evaluate(trimmed(replace(weld.WeldedAngleGusset(),N=-100000.))).get('local_pass',False))
  RESULTS['compression']={'stale_rejected':True,'rebound_current':True,'strip_and_roots_invariant':True,'no_op_stamp_preserved':True,'signed_cases_checked':5}

 def test_008_corner_all_four_families_invariants_and_inactive_controls(self):
  summaries=[]
  for c in [corner.CornerGusset(),replace(corner.CornerGusset(),topology='single_1L_welded',symmetric=False)]+[x for k,x in corner.presets().items() if k.startswith('BC1 · canto') and not 'negativa' in k]:
   p=trimmed(c);r0=corner.analyze(c);r1=corner.analyze(p);g0=r0['geometry'];g1=r1['geometry']
   self.assertFalse(g1.get('outer_end_geometry_problems'));self.assertTrue(g1['outer_end_cut']['trimmed'])
   for key in ('support_edges_uv','beam_seam','column_seam','whitmore','brace_footprint','brace_free_end'):self.assertTrue(numbers_same(g0[key],g1[key]),(c.topology,key))
   for key in ('forces','equilibrium_residuals','joint_distribution','seams','receiver_unions','column_sections','panel'):self.assertTrue(numbers_same(r0[key],r1[key]),(c.topology,key))
   self.assertTrue(numbers_same(r0['gusset_body'],r1['gusset_body'],atol=3e-7),(c.topology,'force-normal body'))
   inactive=replace(p,**({'gusset_weld_end_distance':999.,'brace_weld_start':999.,'brace_weld_length':123.} if corner.is_bolted(c) else {'gusset_bolt_end_distance':999.,'bolt_start':999.,'bolt_pitch':222.}))
   self.assertEqual(corner.geometry(inactive)['polygon'],g1['polygon']);self.assertEqual(cc.geometry_stamp(inactive),cc.geometry_stamp(p))
   self.assertNotEqual(cc.geometry_stamp(c),cc.geometry_stamp(p));self.assertEqual(cc.geometry_stamp(c),cc.geometry_stamp(trimmed(c,1e6)))
   edges=bc.semantic_edges(g1);self.assertEqual(sum(e['supported'] for e in edges),2)
   summaries.append(dict(topology=c.topology,status=r1['status'],complete=r1['complete'],cap=g1['outer_end_cut']['cut_u']))
  RESULTS['corner_invariance']=summaries

 def test_010_exact_contact_boundaries_and_no_trim_parity(self):
  for theta in (1.,30.,55.,89.):
   c=replace(corner.CornerGusset(),phi_deg=theta,brace_weld_length=180. if theta==30. else 220.);g=corner.geometry(c)
   q=replace(c,beam_cut_x=g['ec']+c.plate_width,upper_column_cut_y=g['eb']+c.plate_height,column_end_top=g['eb']+c.plate_height)
   r=corner.analyze(q);ids=[x['id'] for x in r['issues']]
   self.assertNotIn('complete_cut_positions',ids);self.assertNotIn('physical_supported_contact_end',ids)
   if theta==30.:self.assertTrue(g['brace_footprint_contained'])
  for mod,c in [(weld,weld.WeldedAngleGusset()),(double,double.WeldedDoubleAngleGusset()),(bolt,bolt.BoltedAngleGusset())]:
   old=mod.evaluate(c);noop=mod.evaluate(trimmed(c,1e6))
   self.assertEqual(old['checks'],noop['checks']);self.assertEqual(old['cases'],noop['cases']);self.assertEqual(old['issues'],noop['issues'])
  for c in [corner.CornerGusset()]+[x for k,x in corner.presets().items() if k.startswith(('CC1 ·','BCC1 ·','BC1 · canto 2L'))]:
   old=corner.analyze(c);noop=corner.analyze(trimmed(c,1e6))
   self.assertEqual(old['checks'],noop['checks']);self.assertEqual(old['issues'],noop['issues']);self.assertEqual(old['complete'],noop['complete'])
  RESULTS['no_trim_and_boundary_cases']={'contact_tie_angles':4,'one_root_no_trim':3,'corner_no_trim':4}

 def test_011_independent_corner_block_areas_and_tagged_endpoints(self):
  tested=0;inactive=0
  for label,c in corner.presets().items():
   if not label.startswith('BC1 · canto'):continue
   c=trimmed(c);g=corner.geometry(c);a=(g['angle_basis']['cos'],g['angle_basis']['sin']);vd=(-a[1],a[0]);P=g['polygon'];cut=g['outer_end_cut']['cut_u'];r=g['net_hole_diameter']/2;row=g['bolt_row_v'];t=c.plate_t
   for event in bc.block_events(c,g):
    # Events are source/geometry scalar stations, independent area witness below.
    u=event if isinstance(event,(int,float)) else event['u']
    for side in ('negative','positive','tangent_U'):
     state=bc.block_state(c,g,u,side)
     if not state:continue
     if not state['active']:
      inactive+=1;continue
     path=state['path_xy'];
     if side=='tangent_U':
      Agv=(norm(sub(path[0],path[1]))+norm(sub(path[3],path[2])))*t;Anv=Agv
      half=max([math.sqrt(max(0.,r*r-(u-z)**2)) for z in g['bolt_stations'] if abs(u-z)<=r]+[0.]);Ant=(2*r-2*half)*t
     else:
      span=line_interval(P,scale(vd,row),a);exit_u=span[1]
      self.assertAlmostEqual(exit_u,cut,places=8)
      Agv=norm(sub(path[0],path[1]))*t
      removed=[(z-r,z+r) for z in g['bolt_stations']]
      Anv=sum(b-a for a,b in remove_intervals((u,exit_u),removed))*t
      chord=line_interval(P,scale(a,u),vd);vb=chord[0] if side=='negative' else chord[1]
      cap_interval=tuple(sorted([row,vb]));holes=[]
      for z in g['bolt_stations']:
       if abs(u-z)<=r:
        half=math.sqrt(max(0.,r*r-(u-z)**2));holes.append((row-half,row+half))
      Ant=sum(b-a for a,b in remove_intervals(cap_interval,holes))*t
     for key,expected in [('Agv',Agv),('Anv',Anv),('Ant',Ant)]:self.assertTrue(math.isclose(state[key],expected,rel_tol=1e-10,abs_tol=1e-6),(label,side,u,key,state[key],expected))
     self.assertEqual(state['free_exit'][0],'outer_normal_cut_free')
     self.assertNotIn('support',state['free_exit'][-1]);tested+=1
  RESULTS['independent_corner_block_area_witnesses']=tested;RESULTS['inactive_corner_block_records']=inactive

 def test_009_old_native_migration_and_original_exact_numeric_parity(self):
  baseline=json.loads((EVIDENCE/'baseline_original.json').read_text());candidate=json.loads((EVIDENCE/'candidate_original.json').read_text())
  self.assertEqual(json.loads((EVIDENCE/'original_numeric_diffs.json').read_text()),[])
  classes={'welded':weld.WeldedAngleGusset,'double':double.WeldedDoubleAngleGusset,'double_compression':double.WeldedDoubleAngleGusset,'bolt':bolt.BoltedAngleGusset,'corner':corner.CornerGusset,'corner_bolted':corner.CornerGusset,'corner_bolt_compression':corner.CornerGusset}
  for key,data in baseline.items():
   c=classes[key].from_dict(data['config']);self.assertEqual(c.gusset_end_shape,'original');self.assertEqual(c.to_dict(),candidate[key]['config'])
   for flag in ('status','local_pass','complete','approved','mechanics_complete','assembly_qualified'):
    if flag in data['result']:self.assertEqual(data['result'][flag],candidate[key]['result'][flag],(key,flag))
  RESULTS['legacy_original_numeric_cases']=len(baseline)

if __name__=='__main__':
 runner=unittest.TextTestRunner(verbosity=2);result=runner.run(unittest.defaultTestLoader.loadTestsFromTestCase(EngineReview))
 RESULTS['summary']={'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors)}
 (EVIDENCE/'independent_engine_results.json').write_text(json.dumps(RESULTS,indent=2,allow_nan=False)+'\n')
 sys.exit(not result.wasSuccessful())
