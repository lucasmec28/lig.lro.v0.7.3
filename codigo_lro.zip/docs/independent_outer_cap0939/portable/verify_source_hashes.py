"""Verify the exact reviewed mechanical source and independent oracle identities."""
import argparse,os,sys,json,hashlib
from pathlib import Path
HERE=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',default=os.environ.get('OUTER_CAP_SOURCE'));p.add_argument('--oracle-dir',default=os.environ.get('OUTER_CAP_ORACLE_DIR'));p.add_argument('--output-dir',default=os.environ.get('OUTER_CAP_OUTPUT',str(Path.cwd()/'outer_cap_replay_results')));args=p.parse_args()
if not args.source:p.error('--source or OUTER_CAP_SOURCE required')
SOURCE=Path(args.source).resolve();ORACLE=Path(args.oracle_dir).resolve() if args.oracle_dir else SOURCE/'docs/qualification_outer_end0939';DEST=Path(args.output_dir).resolve()
if DEST.is_relative_to(SOURCE):p.error('--output-dir must be outside candidate source')
DEST.mkdir(parents=True,exist_ok=True)
rows=[]
for root,manifest,label in [(SOURCE,'reviewed_mechanical_source_hashes.json','mechanical'),(ORACLE,'planning_oracle_hashes.json','independent_oracle')]:
 for name,expected in json.loads((HERE/'data'/manifest).read_text()).items():
  path=root/name;actual=hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None;rows.append(dict(group=label,path=name,expected_sha256=expected,actual_sha256=actual,match=expected==actual))
result=dict(status='PASS' if all(x['match'] for x in rows) else 'CHANGED_OR_MISSING',checked_files=len(rows),files=rows)
(DEST/'source_identity_verification.json').write_text(json.dumps(result,indent=2)+'\n');print(result['status'],len(rows),'files');sys.exit(0 if result['status']=='PASS' else 1)
