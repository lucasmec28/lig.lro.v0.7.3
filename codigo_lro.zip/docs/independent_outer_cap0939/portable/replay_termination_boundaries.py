"""Independent active-cap termination-boundary check; candidate source is read-only."""
import argparse,os,sys,json,math
from pathlib import Path
sys.dont_write_bytecode=True
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',default=os.environ.get('OUTER_CAP_SOURCE'));p.add_argument('--output-dir',default=os.environ.get('OUTER_CAP_OUTPUT',str(Path.cwd()/'outer_cap_boundary_review')));args=p.parse_args()
if not args.source:p.error('--source or OUTER_CAP_SOURCE required')
SOURCE=Path(args.source).resolve();DEST=Path(args.output_dir).resolve()
if DEST.is_relative_to(SOURCE):p.error('--output-dir must be outside candidate source')
DEST.mkdir(parents=True,exist_ok=True);sys.path.insert(0,str(SOURCE))
from dataclasses import replace
from lro import welded_angle_gusset as w,welded_double_angle_gusset as d,gusset_outer_end as outer
rows=[];failures=[]
for mod,cls in [(w,w.WeldedAngleGusset),(d,d.WeldedDoubleAngleGusset)]:
 for theta in (45.,60.,90.,135.):
  base=replace(cls(),theta_deg=theta,gusset_end_shape='normal_cut',gusset_weld_end_distance=5.)
  poly=outer.one_root(base)['polygon'];tol=outer.tolerance(poly)
  for label,e,expect_fail in [('real_subminimum',4.999,True),('outside_numeric_tolerance',5.-4*tol,True),('inside_numeric_tolerance',5.-.25*tol,False),('equal',5.,False),('above_numeric_tolerance',5.+.25*tol,False),('real_above_minimum',5.001,False)]:
   c=replace(base,gusset_weld_end_distance=e);r=mod.evaluate(c);g=r['geometry'];gaps=[x['normal_gap'] for x in g['forward_termination_clearances'] if x['edge']=='outer_normal_cut_free'];actual_fail=any(i['id']=='outer_normal_cut_free_termination' for i in r['issues'])
   record=dict(family=mod.CONNECTION_TYPE,theta=theta,label=label,input_distance=e,required=c.angle_weld_leg,geometry_tolerance=tol,minimum_recorded_gap=min(gaps),expected_termination_failure=expect_fail,actual_termination_failure=actual_fail,overall_status=r['status'])
   rows.append(record)
   if actual_fail!=expect_fail:failures.append(record)
   assert g['outer_end_cut']['distance_mm']==e and g['outer_end_cut']['dimension'] is not None
 # Original and no-trim branches keep their historical strict comparison.
 tol=outer.tolerance([[-200.,0.],[200.,0.],[200.,300.],[-200.,300.]])
 original=replace(cls(),theta_deg=90.,center_n=195.+.25*tol)
 for mode,c in [('original',original),('no_trim',replace(original,gusset_end_shape='normal_cut',gusset_weld_end_distance=1e6))]:
  r=mod.evaluate(c);actual_fail=any(i['id']=='top_termination' for i in r['issues']);record=dict(family=mod.CONNECTION_TYPE,mode=mode,expected_historical_strict_failure=True,actual_termination_failure=actual_fail)
  rows.append(record)
  if not actual_fail:failures.append(record)
result=dict(tests=len(rows),failures=len(failures),failed_cases=failures,cases=rows)
(DEST/'termination_boundary_results.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print('Termination boundary cases:',len(rows),'failures:',len(failures));sys.exit(1 if failures else 0)
