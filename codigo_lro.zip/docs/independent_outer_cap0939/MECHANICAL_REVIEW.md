# Independent mechanical review: first outer normal cut

Reviewed 12 October 2026 against the authorized `review0939/source0939` candidate after `review0938/SOURCE_GO0938.json`.

## Result

No unresolved mechanical finding in the reviewed, explicitly bounded scope. The independent suite passes all11 test groups. This result is tied to `reviewed_core_hashes.txt` and its final stability recheck; it is not a release, manufacturing, global-stability or external bearing qualification.

Both actual user images were inspected during independent planning. This review covers only the first perpendicular outer cut preserving complete roots and required footprints. The second tapered outline, shortened roots, arbitrary polygons and opposed-vertex cut adapters remain outside scope. No production source was edited or cloned by the reviewer.

## Two findings resolved and rechecked

1. Exact semantic support-contact limits originally underwent an unnecessary xy→uv→xy round trip. At phi30°, a real754.0 mm beam end became754.0000000000001 mm, causing a false COMPLETE_CUTS boundary rejection. The candidate now uses authoritative semantic xy contact endpoints. Independent tests cover the exact contact/end limits at four angles. The phi30° fixture uses weld length180 mm so its actual attachment footprint is retained by the original plate; its separate pre-existing mixed-normal-stress limitation remains intact.
2. The new inactive `gusset_bolt_end_distance` leaked into `bolted_corner_compression.restraint_identity` through the expanded BOLTED_FIELDS list. Unchanged legacy BCC1 native files therefore lost their current geometry declaration. The candidate now excludes this redundant inactive control from the clamp digest, while its actual polygon still binds a physical trim. Old BCC1 native stamp parity is restored. An actual active trim still invalidates the prior declaration.

The developer also corrected no-trim corner modes adding redundant detail rows and outside-polygon cut references throwing a ray exception. Both behaviors were independently checked after correction: no-trim checks/issues match original exactly; an outside reference produces an explicit geometry problem with no false dimension.

## Independent evidence

`review_engine.py` imports candidate interfaces but uses the separate planning oracle for expected clipping, intersections, section unions, moments and distributed-force integration. It writes only this independent directory. It never imports a production test fixture as a runtime mechanics oracle. The independent planning helpers are retained under `chamfer_geometry_scope20261012/candidate_mechanics_review` and their hashes are recorded with the review artifacts.

The passing groups cover:

-500 randomized convex rectangle/cap intersections, with independent polygon vertices, area, centroid and2,500 horizontal-chord comparisons.
- The analytic45° witness: unique physical through-bolts, the correct centred-envelope polygon, and terminal Ø3/4-inch bearing clear ligament24.68124999999997 mm using physical hole20.6375 mm.1L and2L-T have the same common plate and common-hole bearing geometry. This witness remains OUTSIDE_SCOPE as a complete connection, as expected; its geometric values are not represented as a passing design.
-24 recorded welded rational extrema compared with independent numerical integration. The preserved-footprint theta64° witness returns interior compression−7.856233771866444 MPa although all event endpoints are nonnegative. Sign reversal returns+7.856233771866444 MPa at the same physical geometry. The candidate retains the conservative separate-normal/shear-maxima interpretation for VM.
-39 recorded bolted horizontal-section extrema independently reconstructed from the actual polygon chord and circular net-hole interval union, including A, centroid, I, moment and nominal VM. The existing non-interval-certified numerical-extrema qualification remains explicit.
- One-root welded1L, welded2L-T and bolted route root/member-action invariance; the unchanged introduction/Whitmore/force-normal geometry; shorter outward paths and adverse terminal bearing after the real cap. Every checked one-root block path's gross shear length and transverse net area were independently reconstructed from its physical coordinates and deductions.
-243 active corner block area/path witnesses, including longitudinal gross/net lengths, cap endpoints, bounded free-edge labels, circular transverse deduction and tangent-U geometry.72 inactive block records are retained in the enumeration. Supported contact remains distinct from a coincident free-side endpoint label.
- Four corner tensile adapters: welded1L/2L-T and bolted1L/2L-T. Each retains semantic full roots, effective seams, footprints, Whitmore and force-normal body geometry, root/receptor actions, COMPLETE_CUTS equilibrium, joint distribution, receiver unions, column fields and panel actions. Body comparisons permit at most3e−7 absolute numerical tolerance for unloaded endpoint VM cancellation; the observed tiny endpoint VM artifact is about1.85e−7 MPa and does not affect extrema or domain gates.
- Active one-root compression: stale evidence rejected, explicit synthetic rebound current, unchanged actual strip/length/root mechanics and retained real sign gates. N=0,+1,−1,+45000,−45000 preserve the existing separate signed minimum45 kN cases, with N/2 per angle and one total common-plate load.1L compression remains blocked.
- Separate CC1 and BCC1 active-cut compression probes retain their original real receiver FAIL and unchanged root/receptor/strip mechanics. The physical cap expires old evidence; rebound does not erase the receiver failure.
- Seven legacy original-mode evaluator/native cases. No original numerical value changed in the comparison; original native migration reproduces the new default-original configuration and retains the valid BCC1 stamp. The legacy comparison includes tensile and compressed routes.
- No-trim equality for three one-root and four corner examples: checks, cases where applicable, issues and completeness match original mode exactly. No fabricated cap or physical cap dimension is emitted for no-trim cases.
- Root-centreline retention with lost positive weld footprint is explicitly rejected. A valid active cap through an original free vertex remains nondegenerate. Exact original-vertex/edge no-trim ties retain original identities. An old free edge encountered before the nominal cap, and a reference outside the polygon, cannot receive a false physical gauge.
- Inactive cross-topology controls do not change the actual cap or the associated physical-evidence identity. Invalid active distance types, booleans, nonfinite and nonpositive values are rejected in the core.

## Files

- `review_engine.py`: main independent11-group regression suite.
- `independent_engine_log.txt`, `independent_engine_results.json`: current execution and numerical evidence.
- `probe_candidate.py`, `probe_results.json`: initial exploratory reproduction, including the pre-fix contact-roundoff witness. These are historical observations, not the current verdict.
- `legacy_stamp_regression.json`: historical pre-fix BCC1 declaration regression.
- `parity_dump.py`, `baseline_original.json`, `candidate_original.json`, `original_numeric_diffs.json`:7-case original/native parity evidence.
- `corner_compression_results.json`: CC1/BCC1 real-failure and invariant-mechanics checks.
- `initial_review_hashes.txt`: first candidate snapshot before fixes.
- `reviewed_core_hashes.txt`, `core_hash_recheck.json`: exact reviewed13-file mechanical identity and stable recheck.

## Limits that remain explicit

The existing independent external bearing oracle is still missing. These independently verified terminal ligaments, path areas and implemented bearing arithmetic do not replace that external benchmark. The gap must remain in the aggregate qualification/disclosure.

This review adds no NBR limit. It uses the source-reviewed scope in GEOMETRY_SPEC.md: physical versus net hole policy, existing tabulated/minimum/maximum edge screens and their interpretation limits, applicable welded termination, separate overlap/effective-length requirements and existing compression domains.35 mm remains an editable practical gauge for the selected Ø3/4-inch example, not a universal welded or bolt standard.

Existing1L compression, missing physical restraint evidence, mixed-sign stress restrictions, free inner relief and the scoped Cheng applicability gap remain active. The outer cap does not establish a different K, a shortened buckling path, new restraint, continuum stress solution or approval of the support member/global structure.

The developer's43 new cap tests and full-package regressions are separate evidence, not counted as independent tests here. UI, saved-file presentation, report/drawing geometry and package/output gates are owned by the separate delivery review. Any further change to a hashed mechanical file requires a targeted rerun and final hash recheck before applying this conclusion to the changed source.
