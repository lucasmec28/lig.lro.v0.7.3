# Final applied metadata-projection review

12 October 2026. Decision: PASS for the bounded, test-only legacy-schema adaptation.

The source owner applied the three proposed test changes. Every applied file exactly matches its independently proposed SHA-256. This reviewer made no production, test or oracle writes.

## Replayed against the actual applied helpers

The portable validator extracts and executes the helpers and the digest/canonical entry points from the hash-bound candidate test files. It has no dependency on the proposal copies. It also extracts and executes the actual amended old-native fixture constructor before its first UI operation.

- All 29 frozen digests match exactly: 17 presets and 12 long-bolt boundaries.
- All 29 mutation witnesses pass. Active/non-default controls, unknown versions/wording and contradictory active geometry cannot pass through the projection. Changes to pre-existing force, thickness, demand, resistance, utilization and root moment still alter the digest.
- Every pre-existing numeric leaf retains its path, Python numeric type and value. No old numeric field is removed or rounded.
- The default corner native comparison is restored. Its geometry and entire-result digests already match the frozen values without any new result projection.
- The actual amended 0.9.28 fixture constructor preserves the complete current dataclass, including N = -123456.78901234567 and unknown root/brace compression evidence.
- Three test files, six frozen fixtures and all 13 mechanical source files match their expected hashes before and after replay. All 14 imported lro module origins are under the selected candidate source.

The full Streamlit test is not claimed by this independent constructor replay; the source owner is running the full modules separately. The inherited NumPy 2.5.3 whole-result test condition remains unchanged; the independent exact corner digest also matches in this runtime's NumPy 2.3.5.

## Portable evidence

`portable/replay_legacy_metadata.py` accepts `--source` and `--output-dir`, or `OUTER_CAP_SOURCE` and `OUTER_CAP_OUTPUT`. Keep `portable/bindings.json` beside it. It rejects an output directory inside candidate source. `portable/README.md` describes the contract.

`applied_validation/projection_validation.json` contains the full applied-code replay and mutation witnesses. `applied_test_hash_verification.json` binds the applied test bytes to the proposal. The original proposal files and original manifest are preserved. The separate accepted outer-cap mechanics portable manifest is unchanged.

This review approves only the bounded test compatibility adaptation; it is not a release or manufacturing approval. The missing independent external bearing oracle remains disclosed.
