#!/usr/bin/env python3
"""Replay bounded legacy metadata using actual candidate test helper ASTs.

No proposed helper copy is imported; all helper, digest, canonical and UI
constructor code is read from --source. Oracle bytes remain hash-bound.
"""
import argparse,ast,sys,os,json,hashlib,math,importlib,copy,datetime
from pathlib import Path
from dataclasses import replace
sys.dont_write_bytecode=True
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source',default=os.environ.get('OUTER_CAP_SOURCE'))
parser.add_argument('--output-dir',default=os.environ.get('OUTER_CAP_OUTPUT'))
args=parser.parse_args()
if not args.source or not args.output_dir:parser.error('--source and --output-dir are required (or OUTER_CAP_SOURCE / OUTER_CAP_OUTPUT)')
SOURCE=Path(args.source).resolve();OUTPUT=Path(args.output_dir).resolve()
if OUTPUT==SOURCE or OUTPUT.is_relative_to(SOURCE):parser.error('Output must be outside candidate source')
OUTPUT.mkdir(parents=True,exist_ok=True)
BINDINGS=json.loads(Path(__file__).with_name('bindings.json').read_text())
def read_bindings():
 result={}
 for group,entries in BINDINGS.items():
  result[group]={}
  for rel,expected in entries.items():
   actual=hashlib.sha256((SOURCE/rel).read_bytes()).hexdigest()
   assert actual==expected,(group,rel,actual,expected)
   result[group][rel]=actual
 return result
before=read_bindings();hashes=before['protected_fixtures']
sys.path.insert(0,str(SOURCE))
import numpy
FIXTURE=SOURCE/'tests/fixtures/legacy_short_and_long0933_hashes.json';BASE=json.loads(FIXTURE.read_text())
def read_candidate_functions(relative,functions,constants):
 path=SOURCE/relative;tree=ast.parse(path.read_text(),filename=str(path));selected=[];found=set()
 for node in tree.body:
  if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)) and node.name in functions:
   assert not node.decorator_list;selected.append(node);found.add(node.name)
  elif isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name) and node.targets[0].id in constants:
   ast.literal_eval(node.value);selected.append(node);found.add(node.targets[0].id)
 assert found==set(functions)|set(constants),(relative,found)
 namespace=dict(deepcopy=copy.deepcopy,math=math,hashlib=hashlib,json=json)
 exec(compile(ast.Module(body=selected,type_ignores=[]),str(path),'exec'),namespace)
 return namespace
bolted=read_candidate_functions('tests/test_long_bolt_scope0934.py',
 {'_drop_default_original_controls','project_bolted0933_metadata','norm','digest'},
 {'BOLTED_CURRENT','BOLTED_LEGACY','BOLTED_NEW_EXCLUSION','BOLTED_OLD_EXCLUSION'})
corner=read_candidate_functions('tests/test_single_angle_corner0933.py',
 {'_drop_default_original_controls','project_corner0932_native_metadata','canonical'}, {'CORNER_CURRENT'})
project=bolted['project_bolted0933_metadata'];candidate_digest=bolted['digest']
corner_project=corner['project_corner0932_native_metadata'];candidate_canonical=corner['canonical']
def norm(v):
 if isinstance(v,dict):return {k:('APP_VERSION' if k=='app_version' else norm(x)) for k,x in v.items()}
 if isinstance(v,(list,tuple)):return [norm(x) for x in v]
 return v
def independent_digest(v):return hashlib.sha256(json.dumps(norm(v),sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def nums(v,path=()):
 if isinstance(v,dict):
  return {**{p:z for k,x in v.items() if k not in ('gusset_end_shape','gusset_bolt_end_distance') for p,z in nums(x,path+(k,)).items()}}
 if isinstance(v,(list,tuple)):return {p:z for i,x in enumerate(v) for p,z in nums(x,path+(i,)).items()}
 return {path:(type(v).__name__,v)} if type(v) in (int,float) else {}
records=[];first_payload=None
for row in BASE['presets']:
 m=importlib.import_module('lro.'+row['module']);c=m.presets()[row['name']];raw={'input':c.to_dict(),'output':m.evaluate(c)};snap=copy.deepcopy(raw);projected=project(raw)
 assert raw==snap and nums(raw)==nums(projected)
 actual=candidate_digest(raw);assert actual==independent_digest(projected);records.append(dict(kind='preset',module=row['module'],name=row['name'],expected=row['sha256'],actual=actual,match=actual==row['sha256']))
 if first_payload is None and row['module']=='bolted_angle_gusset':first_payload=raw
for row in BASE['boundaries']:
 m=importlib.import_module('lro.'+row['module']);Lc=row['Lc'];c=replace(next(iter(m.presets().values())),arrangement=row['arrangement'],theta_deg=90.,n=11,pitch=Lc/10,plate_height=Lc+100.,center_n=(Lc+100.)/2,N=45000.)
 r=m.evaluate(c);raw={k:v for k,v in r.items() if k not in ('status','global_pass','local_pass','summary','issues')};projected=project(raw);assert nums(raw)==nums(projected)
 actual=candidate_digest(raw);assert actual==independent_digest(projected);records.append(dict(kind='boundary',module=row['module'],arrangement=row['arrangement'],Lc=Lc,expected=row['mechanical_sha256'],actual=actual,match=actual==row['mechanical_sha256']))
 assert bool(next((i for i in r['issues'] if i['id']=='long_bolt_group'),None))==(Lc>950.)
# Every bounded-control rejection is checked in native and result input surfaces.
mutations=[]
for path in [('input','connection'),('output','inputs')]:
 for field,value in [('gusset_end_shape','normal_cut'),('gusset_bolt_end_distance',35.),('gusset_bolt_end_distance',-1.),('gusset_bolt_end_distance',True),('gusset_bolt_end_distance','0'),('gusset_bolt_end_distance',float('nan')),('gusset_bolt_end_distance',float('inf'))]:
  v=copy.deepcopy(first_payload);v[path[0]][path[1]][field]=value
  try:project(v)
  except ValueError:mutations.append(dict(kind='rejected_control',path=list(path)+( [field]),value=repr(value)))
  else:raise AssertionError(('non-default projection accepted',path,field,value))
for target in ('input','output'):
 v=copy.deepcopy(first_payload);v[target]['component_version']='unreviewed-version'
 try:project(v)
 except ValueError:mutations.append(dict(kind='rejected_version',target=target))
 else:raise AssertionError('unreviewed version accepted')
v=copy.deepcopy(first_payload);v['output']['exclusions'][2]+=' altered'
try:project(v)
except ValueError:mutations.append(dict(kind='rejected_exclusion_change'))
else:raise AssertionError('unknown exclusion accepted')
v=copy.deepcopy(first_payload);v['output']['geometry']['outer_end_cut']={'shape':'normal_cut','trimmed':True}
try:project(v)
except ValueError:mutations.append(dict(kind='rejected_active_geometry_with_inconsistent_inputs'))
else:raise AssertionError('Explicit active geometry projected')
expected=candidate_digest(first_payload)
for path in [('input','connection','N'),('output','inputs','plate_t'),('output','checks',0,'demand'),('output','checks',0,'resistance'),('output','checks',0,'utilization'),('output','cases',0,'root','M')]:
 v=copy.deepcopy(first_payload);q=v
 for key in path[:-1]:q=q[key]
 q[path[-1]]+=.125
 assert candidate_digest(v)!=expected;mutations.append(dict(kind='old_numeric_change_detected',path=list(path)))
# Corner native alone requires adaptation; old geometry/result hashes are exact without it.
from lro import corner_gusset as c
obj=c.CornerGusset();legacy=json.loads((SOURCE/'examples/corner_gusset0932/C1.json').read_text())
def canonical(v):
 v=copy.deepcopy(v);v.pop('component_version',None);return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
assert candidate_canonical(obj.to_dict())==candidate_canonical(legacy)
assert canonical(corner_project(obj.to_dict()))==canonical(legacy)
geohash=hashlib.sha256(candidate_canonical(c.geometry(obj)).encode()).hexdigest();reshash=hashlib.sha256(candidate_canonical(c.analyze(obj)).encode()).hexdigest();
assert candidate_canonical(c.geometry(obj))==canonical(c.geometry(obj))
assert candidate_canonical(c.analyze(obj))==canonical(c.analyze(obj))
assert geohash=='1c0aae6b5967ef4b39834a91eb6f83dc4f93d3c32e744e91560b6f09f5119495';assert reshash=='9b31f3b36a02d66ea6c2def98d2c502e36d6e2bb5601af229d9ed5b4153084d1'
for field,value in [('gusset_end_shape','normal_cut'),('gusset_weld_end_distance',35.),('gusset_weld_end_distance',True),('gusset_weld_end_distance',float('nan'))]:
 v=obj.to_dict();v['connection'][field]=value
 try:corner_project(v)
 except ValueError:mutations.append(dict(kind='corner_rejected_control',field=field,value=repr(value)))
 else:raise AssertionError('nondefault corner native projected')
v=obj.to_dict();v['connection']['plate_t']+=.125;assert canonical(corner_project(v))!=canonical(legacy);mutations.append(dict(kind='corner_old_numeric_change_detected',field='plate_t'))
# Narrow old0.9.28 fixture construction preserves negative input and unknown evidence.
from lro.welded_double_angle_gusset import WeldedDoubleAngleGusset as W,LEGACY_COMPONENT_VERSION,evaluate
from lro.one_root_compression import FIELDS
# Execute the actual candidate fixture constructor up to its first UI call.
ui_path=SOURCE/'tests/test_one_root_compression_ui0937.py'
ui_tree=ast.parse(ui_path.read_text(),filename=str(ui_path))
ui_function=next(n for n in ui_tree.body if isinstance(n,ast.FunctionDef) and n.name=='test_old_native_negative_project_stays_unknown_and_new_roundtrip_exact')
constructor=[]
for node in ui_function.body:
 if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='decoded' for t in node.targets):break
 constructor.append(node)
assert constructor and isinstance(constructor[-1],ast.For)
ui_ns=dict(C=W,replace=replace,FIELDS=FIELDS,LEGACY_COMPONENT_VERSION=LEGACY_COMPONENT_VERSION)
exec(compile(ast.Module(body=constructor,type_ignores=[]),str(ui_path),'exec'),ui_ns)
wc=ui_ns['c'];old=ui_ns['old']
loaded=W.from_dict(old);assert loaded==wc and loaded.N==-123456.78901234567;wr=evaluate(loaded);assert not wr['local_pass'];assert not wr['compression']['boundaries']['root']['qualified'];assert not wr['compression']['boundaries']['brace']['qualified']
after=read_bindings();assert before==after
origins={name:str(Path(m.__file__).resolve()) for name,m in sys.modules.items() if (name=='lro' or name.startswith('lro.')) and getattr(m,'__file__',None)}
assert all(Path(path).is_relative_to(SOURCE) for path in origins.values())
report=dict(recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),frozen_hash_cases=records,preset_count=len(BASE['presets']),boundary_count=len(BASE['boundaries']),failures=sum(not r['match'] for r in records),numeric_preservation='Every pre-existing numeric leaf path/type/value was preserved in all29 projected snapshots',mutation_witnesses=mutations,corner={'numpy_runtime':numpy.__version__,'native_projection_equal':True,'unmodified_geometry_hash':geohash,'unmodified_full_result_hash':reshash,'full_result_projection_needed':False},legacy_compression_ui_constructor={'class_roundtrip_exact':True,'N':loaded.N,'engine_status':wr['status'],'unknown_boundaries_retained':True,'ui_not_run_here':True},protected_hashes=hashes,decision='PASS',actual_candidate_helpers=True,actual_candidate_digest_and_canonical=True,actual_candidate_ui_constructor=True,bound_files_before=before,bound_files_after=after,imported_lro_origins=origins)
(OUTPUT/'projection_validation.json').write_text(json.dumps(report,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
print('Frozen hashes:',len(records),'matching:',sum(r['match'] for r in records));print('Mutation witnesses:',len(mutations));print('Corner geometry/full result hashes: exact, unchanged');print('Protected oracle bytes unchanged:',len(hashes));assert all(r['match'] for r in records)
