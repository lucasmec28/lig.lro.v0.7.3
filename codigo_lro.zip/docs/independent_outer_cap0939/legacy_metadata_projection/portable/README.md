# Portable applied-test metadata replay

This independent validator reads and executes the actual candidate test helpers, digest/canonical functions and the old-native fixture constructor. It does not import `proposed_helpers.py` or read `proposed_files/`.

Run from any working directory:

```sh
PYTHONDONTWRITEBYTECODE=1 python replay_legacy_metadata.py \
  --source /path/to/candidate/source \
  --output-dir /path/to/review/output
```

`OUTER_CAP_SOURCE` and `OUTER_CAP_OUTPUT` are equivalent environment variables. Output must be outside the candidate source tree. Keep `bindings.json` beside the script. Python and the candidate's scientific dependencies, including NumPy, are required.

The candidate must contain its three reviewed test modules, six existing frozen fixtures and 13 mechanical source files. Their exact reviewed hashes are checked before and after execution. Helpers and fixture-constructor code are selected by AST from those hash-bound test files, avoiding execution of pytest decorators and UI imports. The validator imports mechanics from the explicitly selected candidate and verifies all loaded `lro` module origins remain there.

Evidence covers all 17 preset and 12 boundary frozen hashes, exact preservation of every old numeric leaf, 29 rejection/change-detection mutations, the unchanged corner geometry/full-result hashes, and the actual old-0.9.28 constructor's exact negative-force roundtrip with unknown compression evidence. The full Streamlit test remains the parent's aggregate responsibility; this script makes no UI-test-pass claim.

A successful run writes `projection_validation.json` and prints a four-line summary. This test-only compatibility replay is separate from the outer-cap mechanics replay bundle, whose accepted manifest remains unchanged. It does not certify global stability, fabrication, active cuts as legacy shapes, or the outstanding external bearing oracle.
