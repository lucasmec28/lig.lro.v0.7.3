# Bounded test-only legacy metadata compatibility proposal

12 October 2026. No source, production mechanics, oracle or test file was changed. Proposed copies and the unified patch are confined to this review directory.

## Outcome

The proposed bolted metadata projection reproduces all29 frozen hashes exactly:17 preset full-state hashes and12 long-bolt boundary mechanical hashes. The frozen fixture itself remains unchanged. Every pre-existing numeric leaf path/type/value is retained by the projection; it performs no rounding, numerical replacement, exclusion of old mechanisms or removal of old numeric fields.

The allowed projection is deliberately narrow:

- Only the exact current `bolted_angle_gusset`0.9.39 metadata is projected to its prior0.9.30 component label.
- Both the native and result-input controls must explicitly be `gusset_end_shape='original'` and a finite numeric zero `gusset_bolt_end_distance`. Booleans, nonfinite values, nonzero inactive values and active cuts are rejected.
- Explicit cut geometry is also rejected, even if the result's input fields inconsistently claim an original contour.
- Exactly the known, changed exclusion sentence is restored. Unexpected wording or versions raise rather than being normalized away.
- Opposed-route payloads are left unchanged.
- The pre-existing app_version-only normalization remains as it was. No new generalized normalizer was introduced.

All29 mutation witnesses pass: forbidden controls, unreviewed versions/wording and contradictory active geometry are rejected; mutations of old force, thickness, demand, resistance, utilization and root moment still break the frozen digest. The projection works on a deep copy and does not mutate the original evaluated/native result.

## Corner test

Only its default2L welded native comparison needs adaptation: the two new default fields `gusset_end_shape` and `gusset_weld_end_distance` are removed under an explicit current-version/default-control guard. Active or nondefault controls cannot enter that legacy native comparison.

No corner geometry or whole-result projection is necessary or proposed. Their untouched digests already match:

- Geometry: `1c0aae6b5967ef4b39834a91eb6f83dc4f93d3c32e744e91560b6f09f5119495`
- Entire result, with the test's existing component_version removal: `9b31f3b36a02d66ea6c2def98d2c502e36d6e2bb5601af229d9ed5b4153084d1`

The existing NumPy2.5.3 skip contract is preserved in the proposed test. The exact hashes were also reproduced independently in the available NumPy2.3.5 runtime; this observation does not change that inherited test condition.

##0.9.28 compression UI fixture

The proposed change removes exactly `gusset_end_shape` and `gusset_weld_end_distance` in addition to the compression FIELDS already removed when constructing an old0.9.28 native record. The existing equality, session-state and NOT_VERIFIED assertions are unchanged.

Independent class-level import preserves the exact negative force−123456.78901234567 and the entire current dataclass, with unknown root/brace evidence still unqualified. The UI test itself was not run here; the parent should run it in the aggregate's UI environment after applying the reviewed test-only patch.

## Deliverables and verification

- `proposed_test_only_changes.patch`: proposed changes to exactly3 test files. No production or oracle hunk.
- `proposed_helpers.py`: isolated pure test-only projection helpers.
- `proposed_files/tests/`: syntax-checked proposed test-file copies for review.
- `validate_projection.py`, `validation_log.txt`, `projection_validation.json`: all29 frozen hashes,29 mutation witnesses, numeric preservation, native migration and6 protected oracle/source-fixture hashes.
- `proposed_callable_validation.json`: proposed helper ASTs equal the independently validated helpers; actual proposed digest/canonical definitions reproduce the expected checks when executed in isolation. Source test bytes still match their pre-proposal hashes.
- `proposed_test_file_hashes.json`: original and proposed test-file identities.

The parent remains the sole source writer and may apply this test-only proposal after review. This proposal does not weaken a mechanical gate, change a frozen oracle, approve an active cap as a legacy shape, or address the separate missing external bearing oracle.
