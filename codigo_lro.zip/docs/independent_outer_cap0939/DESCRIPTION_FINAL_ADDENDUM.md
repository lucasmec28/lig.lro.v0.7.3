# Final description-only amendment and portable replay seal

12 October 2026.

The final change in `gusset_outer_end.py` is conclusively limited to `description()`: substituting only its previously reviewed function body into the current in-memory file reproduces the exact preceding SHA256, `a609dcf19a9fd7c5878a490f24f53c1c609d77cdd12c947a9ff07640f0b0dc66`. No production file was rewritten or cloned for that proof. The function-only text diff is `description_only_diff.txt`; the executable proof and outcomes are in `check_description_delta.py` and `description_delta_verification.json`.

Four semantic states were independently verified:

1. An active trim with a nominal35 mm setting but an earlier real-edge exit, and therefore no valid dimension, is explicitly described as invalid/nonphysical.
2. A genuine35 mm bounded bolt-centre-to-cap dimension retains its physical explanation.
3. No-trim mode states that there is no new face to dimension.
4. A real gauge combined with lost root-weld footprint does not assert preserved roots; root/contact retention is stated as a requirement, and geometry problems remain authoritative.

The full11-group independent engine suite was rerun and passes. Final13-file source identity is stable in `reviewed_core_hashes_final.txt` and `core_hash_recheck_final.json`. Relative to the opposed compatibility addendum, only `gusset_outer_end.py` changed; the remaining12 reviewed files are byte-identical. The preceding reviews and historical seal files are preserved.

## Portable evidence bundle

`portable/` contains separate replay copies, not replacements for accepted scripts. No workspace-absolute paths are embedded. Candidate source, oracle and output paths are accepted by CLI/environment, and operation from a different current directory was verified. Every driver rejects output paths inside the candidate source. `portable/MANIFEST.json` gives the exact bundle file identities.

The verified portable package includes:

-11 independent engine groups plus regenerated7-case original/native parity and principal status flags.
-19 complete opposed payload identities with zero differences, including native round-trips and unsupported-cut gates.
- CC1/BCC1 active compression gates and unchanged common mechanics, preserving the existing receiver failure.
- Four description states.
- Exact identity verification for13 reviewed mechanical files and2 independent planning oracle helpers.

All portable replays passed. `PORTABLE_VALIDATION.json` and `portable_validation/` contain the validation results; the README gives invocation instructions and dependencies. The full7-case baseline is losslessly compressed. Opposed complete-payload parity uses compact canonical hashes of the already reviewed full25 MB baseline; the original full baseline remains preserved in the independent review directory.

No normative, mechanical, manufacturing or release qualification is expanded. The missing independent external bearing oracle and all prior scope restrictions remain explicit.
