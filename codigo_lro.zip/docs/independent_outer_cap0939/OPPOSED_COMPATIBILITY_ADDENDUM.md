# Opposed-route compatibility addendum

12 October 2026. Read-only comparison after the authorized presentation/payload compatibility patch in `welded_opposed_angle_gusset.py`.

Result: exact full JSON equality against source0938 for19 opposed-route cases, including welded and bolted presets and typed invalid/low/negative-load welded cases. The comparison covers the whole result, native document, and result after native round-trip, including keys, value types, strings, statuses, numerical values and lists. It does not exclude version, input or exclusion fields. Difference count is zero.

The restored excluded-polygon sentence and removal of the two unsupported inherited outer controls from result inputs preserve the old supported payload. Setting an otherwise inactive welded outer-margin value also leaves the complete opposed result unchanged. An active normal cut remains INVALID_INPUT and is rejected by native serialization; the patch does not enable opposed-vertex cap mechanics.

The main11-group independent cap suite was rerun and still passes. Final recheck is stable for all13 mechanical files in `reviewed_core_hashes_after_opposed_compatibility.txt`.

The earlier13-file reviewed set already included `welded_opposed_angle_gusset.py`. Exactly that file changed; the other12 stayed byte-identical. Its hash changed from `0d81b53b0d700b8b6ef447985832570ea61e3794e88fe3342d8d62820e5fb8b8` to `96260c016f5245f31073ee3cf7c23cb7cd1a35b199bda1e8eb5598c110cbac01`. The original review and seal files are preserved. This addendum supplies the amended identity.

Evidence:
- `opposed_payload_dump.py`, `opposed_baseline_full.json`, `opposed_candidate_full.json`
- `opposed_full_payload_diffs.json` (empty array)
- `opposed_unsupported_control_results.json`
- `opposed_compatibility_hash_delta.json`
- `independent_engine_log_after_opposed_compatibility.txt`
- `reviewed_core_hashes_after_opposed_compatibility.txt`
- `core_hash_recheck_after_opposed_compatibility.json`

The original mechanical review's scope and limits remain unchanged, including the missing external bearing oracle and the separate packaging/output/release gates. No production source was edited by this reviewer.
