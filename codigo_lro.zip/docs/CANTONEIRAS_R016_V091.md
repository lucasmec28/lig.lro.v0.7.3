# R016 · dupla cantoneira parafusada sob cortante

Checkpoint histórico 0.9.1-angle-dev, 2026-10-09. Disponibilidade de fontes reconciliada em 10/10/2026; método atual: `BOLTED_DOUBLE_ANGLES_AUDIT0915_METHOD.md`. Não publicado. Esta etapa acrescenta uma ligação física ao aplicativo, conservando a emenda W 0.9.0 como domínio axial parcial. Não fecha compressão, momento e cortante simultâneos da emenda W.

## Topologia e domínio fechado

Duas cantoneiras iguais, simétricas em relação à alma de uma viga W laminada sem recortes, ambas as abas parafusadas, apoio na mesa de um pilar W laminado. Viga e apoio possuem perfis, dimensões e aços independentes. O padrão é R016, página impressa 19 do caderno PADRÃO DE LIGAÇÕES-2Model. Não é single plate nem cantoneira simples.

O modelo admite V estático positivo ou negativo e exige N=M=T=0. Há uma coluna vertical de parafusos em cada aba, com pelo menos dois parafusos. Viga, cantoneiras e pilar devem ter contato firme direto, sem calços, folgas entre chapas, soldas participantes, aberturas ou descontinuidades locais adicionais. Montagem de parafusos, porcas e arruelas segue NBR 6.8. Os valores informados já são de cálculo.

A ligação flexível convencional está delimitada aos pares de seção/gabarito documentados no Gerdau2018: L76×76×6,4 com g=45 mm e L102×102×8 com g=65 mm nas duas abas. Não se inferiu um limite universal de gabarito nem se extrapolou a espessuras arbitrárias. Outros gabaritos/abas permanecem calculáveis como componentes diretos condicionais, mas são bloqueados por pendência de flexão das abas e grupos excêntricos compatíveis. N=M=T=0 não apaga excentricidades geométricas internas.

Condições convencionais de contenção e rotação são verificadas explicitamente: comprimento L≥H/2, grupo da alma centralizado ou mais próximo do topo, pelo menos dois parafusos, folgas e interferências. A base é Gerdau2018 p.20, prática usual de NBR6.1.2.3/6.1.3/6.1.7 e AISC Steel Interchange abril2010. Uma posição inferior ou ligação curta fica pendente; não recebe dispensa por mero aviso ou checkbox. Não é calculada curva momento–rotação.

Essas grandezas não são apresentadas como limites geométricos universais da NBR. A exigência funcional de contenção/rotação vem de6.1.3 e6.1.7; L≥H/2 e a relação entre as posições dos furos são critérios que o Gerdau p.20 adota para construir os seus detalhes e tabelas convencionais. O aplicativo os adota como qualificação explícita deste modelo limitado. A AISC abril2010 usa profundidade≥T/2 como prática usual de contenção, não prova de que toda ligação mais curta falha. Uma ligação menor ou mais baixa pode ser validada por outro mecanismo de contenção/rotação: aqui recebe ENGINEERING_MODEL_PENDING, mantém geometry.valid e não é descrita como fisicamente impossível. O afastamento industrial de10mm e as faixas Z da folha R016 são referências de detalhamento distintas, tratadas como desvio de preset quando não causam colisão. Folga de ponta exatamente zero é uma exceção de qualificação do modelo: a extremidade da viga pode encostar na mesa do pilar e alterar o caminho de forças/rotação. Como esse contato não é calculado, o estado é ENGINEERING_MODEL_PENDING, com geometria válida e resistências locais preservadas. A base é a compatibilidade de deformações de6.1.1.3(c–e) e6.1.3. Isso não transforma10mm em mínimo universal; folgas positivas seguem as demais condições declaradas.


## Ação mínima e partilha

NBR6.1.5.2: Vd=sign(Vsd)·max(|Vsd|,45 kN), aplicado uma vez ao conjunto. Para Vsd=0, os dois sentidos estáticos são avaliados com 45 kN. O valor real permanece no projeto e os índices real/adotado são separados. A recomendação axial de 50% em6.1.5.3 não foi transformada em metade do cortante da viga.

Cada cantoneira recebe |Vd|/2. Os parafusos comuns às duas cantoneiras e à alma da viga têm dois planos de corte. Há dois grupos distintos de apoio, com um plano por parafuso. A alma central nunca recebe espessura duplicada. As interfaces são sucessivas; suas capacidades não se somam.

O resultado exporta V real e o momento de transporte V·d_pilar/2 da face da mesa ao eixo do pilar. Esse transporte só deve ser acrescentado ao modelo global se a excentricidade não estiver nele. O atendimento local da ligação não dimensiona o pilar inteiro, sua estabilidade, a estrutura global ou a amarração axial de outra combinação.

## Resistências atuais e caminhos físicos

Base normativa: NBR8800:2024, versão corrigida2025. γa1=1,10; γa2=1,35. Classes A325 e A490 usam fub=830 e1040 MPa, respectivamente, conforme TabelaA.3 atual; não usam a antiga redução do A325 de grande diâmetro. Corte por plano: αAbfub/γa2 com α=0,45 com rosca ou0,56 sem rosca; redução conservadora de pega longa6.3.7 é calculada sem crédito por protensão.

Contato/rasgamento6.3.3.3: min(1,2lc;2,4db)t fu/γa2, com dh físico e o ligamento na direção efetiva. Cada grupo tem a soma normativa explícita e verificações individuais adicionais compatíveis com a distribuição uniforme. Não se rotula n·min(Ri) como soma normativa, nem se explora redistribuição plástica sem um modelo correspondente.

Com V positivo descendente:
- Aba da viga: carga para baixo e borda inferior da cantoneira.
- Aba do apoio: reação para cima e borda superior da cantoneira.
- Alma da viga: carga no furo para cima. A junção contínua com a mesa não é borda livre; o furo terminal usa o teto de contato e os demais usam p−dh.
- Mesa do pilar: carga para baixo e extremidade inferior real do pilar.

V negativo inverte essas direções. Bordas assimétricas alteram os resultados. O contato usa espessuras e materiais reais da alma, de cada aba e da mesa do pilar.

Cada uma das quatro abas possui área bruta L·t e área líquida (L−n·dn)t próprias. Calculam-se escoamento e ruptura por cisalhamento6.5.5. Cada aba também tem blocos L físicos até seu lado livre e extremidade carregada, incluindo os prefixos k=1…n. Agv=[e+(k−1)p]t; Anv=[e+(k−1)p−(k−0,5)dn]t; Ant=[b−g−dn/2]t. Cts=1 segue o caminho de uma fila da Figura16(b). Demanda Vk/(2n) é coerente com a partilha uniforme verificada por furo.

A alma da viga tem cisalhamento bruto/líquido local conservador com altura livre das raízes, sem crédito da ajuda das mesas. Em paralelo calcula-se a resistência do membro ao cortante com instabilidade5.4.3.1: Aw=d·tw, λ=h_livre/tw, kv=5,34 e os três ramos de Cv. Não se aplica à seção W o limite citado para seção T em5.4.3.3. O bloco L de viga recortada não é transplantado para a alma sem recorte.

A mesa do pilar tem seus furos reais verificados. Para cada fila calcula-se bloco L externo até a borda lateral e a extremidade real carregada do pilar. Usa-se Cts=0,5 conservador, embora Cts=1 possa corresponder ao caminho uniforme de uma fila. Esses blocos são aplicação racional suplementar de6.5.6, não fórmula de apoio copiada do Gerdau. Não se cria bloco U atravessando a junção contínua mesa–alma. Distâncias às pontas do pilar são entradas próprias, medidas do primeiro/último furo, nunca o comprimento da cantoneira.

Mecanismos de flexão normal à mesa, punção e enrugamento transversal da alma não se aplicam à única força vertical no plano da mesa deste domínio simétrico. N/M/T externos ou descontinuidades reabrem esses estados em outra rota.

## Furação, detalhamento e alertas

Os dois gabaritos partem das faces de contato correspondentes da cantoneira. Na planta, g_apoio é medido da face de contato da alma ao eixo do furo, não do eixo central da viga. A distância entre filas do pilar é tw_viga+2g_apoio; para tw7,2 e g45 resulta97,2mm. O datum foi conferido no traço vetorial da folha R016 e no detalhe Gerdau p.33.

Diâmetros métricos e imperiais têm identidades separadas. Tabela14 determina o máximo circular; o furo físico deve ser maior que db e não exceder esse máximo. A dedução líquida usa o máximo tabelado acrescido de2mm, salvo broca documentada. Assim, M24 com dh físico26 tem base27 e dedução29mm quando aplicável. Não é renomeado como3/4 pol.

Espaçamento mínimo: max(2,7db;dh+db); 3db é preferência identificada, não limite rígido. Espaçamento e bordas máximas são verificados conforme6.3.10 e6.3.12 nas partes sobrepostas/ligadas. As bordas distantes de extremidades do pilar, fora da região em contato com a cantoneira, não recebem um máximo que obrigaria furar toda a coluna. Distâncias mínimas usam Tabela16, sem automatizar sua exceção por resistência.

Furo fora da peça, sobreposição de furos e cantoneira colidindo com raízes/mesas são geometria inválida. Acesso insuficiente da ferramenta é pendência de montagem. Afastamento do preset industrial R016 é aviso distinto: ele não significa por si só falha física ou normativa. N da folha conta intervalos: n=N+1. Z é a altura livre entre mesas e não o comprimento da cantoneira. O exemplo principal tem M20, N=3, quatro parafusos comuns, oito de apoio, L260, passo60, bordas40 e Z331,8 dentro de300≤Z<360.

## Estados de resultado e exclusões

Atendimento local somente quando todos os checks resistentes, detalhamento e gates do modelo estão atendidos. Falha resistente, falha de detalhamento, geometria impossível, acesso pendente, modelo parcial e desvio de oficina são estados distintos. Resultados favoráveis de componentes nunca eliminam uma pendência aplicável.

Cantoneira única, estendida, assimétrica, múltiplas colunas, R015 soldada, R017 em alma de apoio, recortes, N/M/T, fadiga, impacto, atrito de serviço e análise global são expansões não implementadas. O ramo W permanece axial parcial, sem aprovação N/M/V.

## Fontes e limites de evidência

- Caderno fornecido, PADRÃO DE LIGAÇÕES-2Model, R016 impressa19, diagrama inspecionado.
- NBR8800:2024 corrigida2025, exemplar fornecido; referências específicas acompanham cada check.
- Gerdau, Ligações para Estruturas de Aço,7ª edição2018,p14,p19–27,p33. Geometria/modelo; resistências históricas NBR2008 não são oráculos atuais. A fonte exclui o apoio de suas tabelas.
- Higgins, tese University of Florida, maio2005: referência histórica, não recuperada nesta cópia; não se afirma leitura dos capítulos4/6. O relatório Green/Sputo/Higgins é documento distinto e também não recuperado.
- AISC P901-23W v16.0 completo recuperado: exemplo II.A-1A, PDF542–553, impressas IIA-2–IIA-13. Conferido na auditoria R016 como fonte complementar de topologia, corte duplo/simples, contato por furo e apoio, sem trocar coeficientes NBR/Gerdau. SHA-256: ec25b52e1d7b6b9ec9e5eaccc27452153208784d7d715908daa2595dd8f92423. Esta informação substitui o antigo registro de download integral indisponível.
- AISC Steel Interchange abril2010, Minimum Connection Depth/Beam Connection Location: https://www.aisc.org/globalassets/modern-steel/steel-interchange/2010/042010_apr10_si_web.pdf .
