# ELS de não deslizamento da emenda W convencional — revisão 0.9.56

## Fontes verificadas
NBR 8800:2024, exemplar fornecido: 6.3.4, páginas impressas 86–88 (PDF108–110); 6.8, pp109–114 (PDF131–136); Tabela19 p111 (PDF133). Texto e imagem da tabela conferidos. FTb são mínimos normativos selecionados para os oito pares classe/diâmetro suportados, não aproximação pela área bruta.
Kulak/Fisher/Struik, Guide to Design Criteria for Bolted and Riveted Joints, 2nd edition, §§8.1–8.3.1, pp171–175; https://www.boltcouncil.org/files/2ndEditionGuide.pdf: contexto de emendas estáticas restringidas e planos simples/duplos. Não generaliza para arrancamento de chapas livres.

## Modelo delimitado
Ff,Rk=0,80 μ Ce FTb ns [1−Ft,Sk/(0,80 FTb)]. Comparação nominal ELS, sem γe/γa. Ce=1 por ausência de enchimentos. Talas estruturais são peças conectadas. Ft,Sk=0 somente no modelo nominal qualificado de solicitações no plano; N/M nas mesas produzem corte longitudinal, não tração no eixo do parafuso. Abertura fora do plano não é modelada.

Ações: combinação rara real assinada, ou seleção explícita de 70% do caso ELU normal real. O segundo caminho não usa mínimos de resistência/envelopes sintéticos. Excepcionais continuam fora do domínio original. Caso raro totalmente nulo fica pendente. O domínio estático original e suas rejeições dinâmicas permanecem.

Cada parafuso completo é contado uma vez. Mesas: dois planos com tala interna e externa, um com apenas externa; alma: dois planos. Cada ponta recebe o esforço integral correspondente; pontas em série nunca somam capacidades. Distribuição elástica da alma conserva forças e momento. As verificações ELU existentes continuam independentes.

## Benchmark independente
W310×97: h0=292,6mm, oito parafusos por ponta de mesa, Jgrupo alma=19800mm². ELU real N=−600kN, M=120kNm,V=100kN; alternativa70%: N=−420kN,M=84kNm,V=70kN. Fmesa superior=−497081,339713N; inferior=77081,339713N. Demandas por parafuso=62135,167464N e9635,167464N. Máximo da alma=25260,465923N.
A325M20, FTb=142000N, μ=.30: dois planos68160N; um plano34080N. Índice mesa com internas=.911607503875; externa única=1.82321500775. Mesma superfície μ=.50: resistência de um plano56800N. Caso raro real −300kN/60kNm/50kN: índice da mesa externa=.781377860464. Os testes verificam sinais, limites exatos e resíduos de equilíbrio.

## Migração e resultados
Schema3 inclui base das ações, classe de superfície e N/M/V raros. Schemas1/2 são migrados sem supor ações/superfícies. Opção desligada exclui esses campos da entrada ativa, preservando resultados antigos. ELS não é inserido nas linhas resistentes ELU; seu estado e vetores completos constam em bloco próprio. Falha ELS não é apagada por ELU aprovado; ELS aprovado não apaga falha geométrica/resistente. Requisitos de execução são apresentados, sem certificar protensão efetivamente instalada.

## Evidência e limites dos testes
32 testes novos cobrem cálculo manual, oito FTb, μ, planos, sinais, ELS real/70%, negativos, migração, JSON, UI e Word recomputado. Revisão independente conferiu núcleo e fontes. Oito saídas completas sem ELS coincidem exatamente com .55. Os demais módulos mantêm bytes idênticos.
Na primeira regressão de166 testes,164 passaram. O teste histórico de vínculos iterava todos os campos de conversão, presumindo controles sempre visíveis; foi adaptado apenas para excluir campos ELS ocultos com opção desligada. Os controles ativos e sua preservação são testados separadamente. O teste test_engine_envelopes_are_primary_and_all_primitive_rows_remain_in_expander encontrou at.dataframe vazio (IndexError) após importação; passou isoladamente em .56 e .55. Logs iniciais são preservados; ver recibo final para reexecução e eventual instabilidade. Não afirmar suíte total nem aprovação estrutural.

Resultado final da revisão integrada: 166 testes herdados da emenda passaram; 63 testes ELS/B9 passaram; 142 testes U passaram. A instabilidade inicial de importação/tabela não reapareceu na execução completa final e permanece registrada como limite da automação UI. Os asserts Word foram atualizados exclusivamente para conferir a mesma conclusão em português em vez da linha de código interno removida por solicitação de apresentação. Nenhuma hipótese resistente foi alterada para satisfazer testes.
