# Distribuição compacta 0.9.70

Identidade do pacote: `0.9.70-catalogo-marinho-dev.1`. A versão do componente de cálculo `lro.models.VERSION` continua `0.9.44-beam-on-beam-partial-dev`, deliberadamente sem alteração de esquema ou motor.

## Conteúdo preservado

A cópia compacta mantém os mesmos bytes da aplicação de execução, todos os módulos `lro`, dados e exemplos da fonte completa. Os documentos de método na raiz de `docs` e os manifestos históricos também são preservados. O catálogo visual opcional e o tema azul-marinho pertencem à interface; os formulários e desenhos de projeto continuam sendo os nativos das famílias. Miniaturas de presets são exemplos para navegação, não desenhos nem resultados do projeto atual. O módulo visual reutilizável pode apoiar outros aplicativos no futuro; nenhum outro aplicativo foi alterado.

Foram excluídos somente caches, suíte de testes, `artifact_qa` e subpastas volumosas de evidências históricas em `docs`. Se presente, `docs/validation0970/SUMMARY.json` é mantido. A fonte integral e as evidências de teste ficam preservadas separadamente. Essa redução não exclui famílias, recursos, métodos ou exemplos.

## Integridade e execução

O ZIP externo contém exatamente quatro arquivos: `app.py`, `codigo_lro.zip`, `requirements.txt` e `README.md`. Mantenha os quatro juntos. O carregador verifica o SHA-256 do ZIP interno, caminhos de extração, arquivos obrigatórios, identidade do pacote e mistura de módulos de outra revisão no processo. Uma atualização exige reiniciar o processo Streamlit.

O manifesto `docs/CATALOG_SCOPE0970_MANIFEST.json` é criado exclusivamente em `compact/src`, na cópia de distribuição, e descreve esse conteúdo completo, exceto ele próprio. Nenhum manifesto histórico da fonte é atualizado. Execute `python verificar_pacote.py` depois de extrair o ZIP interno para conferir os arquivos da distribuição. A ausência do manifesto 0970 é um erro explícito; manifestos históricos não substituem o atual. Mudanças apenas de fim de linha LF/CRLF são aceitas pelo verificador; o carregador externo continua exigindo o SHA-256 exato do ZIP distribuído.

## Limites da evidência

A validação do pacote inclui CRC, SHA-256, inventário, manifesto, paridade byte a byte e rotas reais por Streamlit AppTest em processo novo. AppTest é evidência funcional, não screenshot nem validação visual em navegador. Não foram iniciados servidor, socket, navegador, publicação, push ou deploy. Testes de software não equivalem a aprovação estrutural de um projeto; todos os limites técnicos e pendências das famílias permanecem aplicáveis.
