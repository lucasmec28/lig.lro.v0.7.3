# Ligação axial 2L–chapa de nó · parafusada

Versão 0.9.20-axial-double-angle-dev. Unidades nativas N, mm, MPa e N·mm. Ramo local estático de tração, inclusive N real zero, sob combinações últimas normais (γa1=1,10; γa2=1,35).

## Corpo físico e fronteira

Duas cantoneiras laminadas de abas iguais, idênticas e simétricas, uma em cada face da mesma chapa central retangular de largura constante. Uma linha longitudinal de parafusos compartilhados possui dois planos físicos de corte; a chapa possui uma única espessura. Não há chapas de enchimento nem crédito de atrito.

O eixo nominal da força coincide com a linha de parafusos e o centro da largura da chapa, pela exceção estática de extremidades de cantoneiras da NBR 8800:2024, 6.1.8.2. A excentricidade geométrica do centroide real é declarada como omitida nesse modelo. Não se combina força no centroide real com momento nulo no eixo nominal. O corte terminal é ortogonal, centrado e situa-se além da ponta das cantoneiras e da zona de transferência; nele o modelo transmite N e M=0. Não dimensiona raiz, solda, apoio, pilar, trecho externo ou estabilidade global.

Compressão, fadiga, reversão cíclica/sísmica, N/M/V/T arbitrários, cantoneira única, assimetria, furação oblonga, múltiplas linhas, recortes, largura de chapa variável e modelos excêntricos fora da exceção estão excluídos.

## Resistência e caminhos reais

- Par de cantoneiras: escoamento bruto, ruptura líquida efetiva, Ct=1−ec/lc e piso Ac/Ag permitido para a seção aberta; não há antigo limite fixo0,6–0,9. Para abas iguais, Ac=Ag/2 por divisão simétrica no encontro das abas.
- Chapa real: Ag=b·t, An=(b−dn)·t e Ct=1. Não é chapa de emenda: não se aplica automaticamente o limite0,85Ag de6.5.3 nem a regra de emenda de6.3.8. A largura real não requer expansão arbitrária de Whitmore.
- Cada plano de corte do parafuso recebe N/(2n). Coeficientes0,45/0,56 são aplicados individualmente conforme rosca; não se usa média para esconder o plano fraco. Redução de pega6.3.7 quando aplicável; pretensão não dá crédito de atrito.
- Contato/rasgamento em cada furo usa espessura e material reais: N/(2n) em cada cantoneira e N/n na chapa. Na chapa a força de contato aponta−x; nas cantoneiras,+x; as extremidades carregadas são opostas.
- Blocos parciais de k=1…n parafusos até a borda carregada real: cada cantoneira tem caminho até sua ponta livre conectada e caminho desenvolvido até a outra ponta real. O encontro das abas não é borda livre. Cada lado da chapa é caminho alternativo, verificado com toda a força dos k parafusos; não se somam capacidades de superfícies coincidentes. Cts=1 nos ligamentos transversais da linha única.
- Furos, ligamentos, bordas, passos mínimos/máximos, raio da raiz, ferramenta e montagem são verificados com dimensões reais. Falha resistente continua visível se outra condição de detalhe impedir atendimento.

## Ações e rastreabilidade

N real não é substituído. O mínimo45kN é obrigatório nesta família quando N real é inferior: não há exceção6.1.5.2 implementada. Ele é caso separado, e um arquivo que o desative fica fora do domínio, sem aprovação; a recomendação opcional50% da resistência de tração do membro também é caso separado, sem soma de ações. Não se presume uma exceção de diagonal de treliça nem capacidade de compressão global.

Souza, PDF162, fornece para2L76×6,35: Ag do par1858mm² e ec21,3mm. Raio6mm e ferramenta18mm+folga2mm são hipóteses dimensionais editáveis do exemplo moderno, sem alegação de catálogo ou fabricante. Propriedades editadas não são sobrescritas por fórmula de seção de canto vivo.

Exemplo atual dimensionado: N200kN; A36; chapa100×12,5mm;3M16A325 fub830MPa, furos18mm broqueados; passo50mm, g35mm, bordas carregadas35mm; parafusosx35/85/135, pontaLx170 e corte200mm. Valores independentes: corte do grupo333,762804kN; ruptura efetiva2L379,951941kN; escoamento da chapa284,090909kN governante. O exemplo histórico9.2 de Souza usa coeficientes antigos e contém divergências aritméticas; não calibra o motor atual.

## Persistência e apresentação

JSON nativo estrito identifica família, versão, unidades e premissas. Importação valida integralmente antes de atualizar estado. Word/SVG/PNG reavaliam a entrada atual e ignoram resultados fornecidos; rascunhos não podem reutilizar aprovação anterior. O resumo agrupa por componente e mecanismo preservando todos os caminhos primitivos, casos, furos, áreas, forças e empates.

## Fontes inspecionadas

NBR8800:2024 com Errata1 de25/02/2025:5.2.2–5.2.5;6.1.5;6.1.8.2;6.3.3;6.3.6–6.3.7;6.5.3/6.5.5/6.5.6; Tabelas14/16/A.3. PáginasPDF1,61–64,92–93,106–107,112–114,116–118,152. Souza: exemplo9.2/figura9.5PDF120–121 e propriedadesPDF162. Validação finita independente de seções, blocos, parafusos, contato, estados e artefatos; não é auditoria integral das outras famílias ou liberação estrutural para execução.
