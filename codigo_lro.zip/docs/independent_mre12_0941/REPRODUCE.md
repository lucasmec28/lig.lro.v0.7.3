# Reprodução independente no APP extraído

Execute a partir da raiz do APP, com suas dependências de teste instaladas:

```sh
python docs/independent_mre12_0941/independent_expected.py
PYTHONPATH=.:docs/independent_mre12_0941 python -m pytest docs/independent_mre12_0941/test_mre12_independent.py -q
PYTHONPATH=. python docs/independent_mre12_0941/verify_legacy.py
```

Os núcleos independentes não importam a aplicação. O teste de integração importa
somente o APP ativo. O JSON comprimido mantém os80 estados completos da fonte
0.9.40 congelada, sem truncar nem depender da árvore anterior. A comparação é
exata, inclusive método, premissas, entradas e todas as verificações.

Adaptações para distribuição alteram somente os caminhos de leitura e a saída
do programa, sem alterar fórmulas ou expectativas independentes. Os recibos
originais da revisão conservam os hashes do runtime auditado.
