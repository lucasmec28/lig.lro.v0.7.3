"""Mechanics re-derivation outside production; never imports application code."""
import hashlib,json,math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
QUAL=ROOT/'mre12_qualification20261012'
G1=1.1;G2=1.35

def expected(p):
    d,t,pf,pi,pb,g=(p[x] for x in ('d','tf','pfo','pfi','pb','g'))
    y=[-pf,t+pi,t+pi+pb,d-t-pi-pb,d-t-pi,d+pf]
    h=[d-t/2+pf,d-1.5*t-pi,d-1.5*t-pi-pb]
    b=min(p['bp'],p['bf']+max(p['tp'],25.4))
    B=min(p['bcf'],p['bf']+max(p['tp'],25.4))
    sp=math.sqrt(b*g)*.5;sc=math.sqrt(B*g)*.5;pe=min(pi,sp);c=pf+t+pi
    # Algebraically independent grouped forms; no copied terms/table sum.
    yp=b*(h[0]/pf+h[1]/pe+h[2]/sp)/2-b/4+(2*h[1]*pe+2*h[2]*sp)/g+pb*(3*h[1]+h[2])/(2*g)+g/2
    yc=B*(h[0]+h[2])/(2*sc)+2*sc*(h[0]+h[2])/g+(3*h[0]+h[2])*(pb+c)/(2*g)+g/2
    H=2*sum(h);z=d-t;M,N,V=(p[x] for x in ('M','N','V'))
    me=abs(M)+max(N,0)*z*.5;tb=me/H;ff=abs(M)/z+max(N,0)*.5;fc=abs(M)/z+max(-N,0)*.5
    active=[0,1,2] if M>0 else [5,4,3];shear=sorted(set(range(6))-set(active))
    dh=p['db']+(1.5875 if p['db']<25.4 else 3.175);dn=dh+(0 if p['drilled'] else 2.)
    ab=math.pi*p['db']**2/4;pt=(90 if 'A325' in p['bolt'] else 113)*6.8947572931683*ab
    geometry={'rows':y,'h':h,'H':H,'bp_eff':b,'bcf_eff':B,'sP':sp,'sC':sc,'pfi_eff':pe,'c':c,'Yp':yp,'Yc':yc,'physical_bolts':12,'tension_bolts':6,'dh':dh,'dn':dn,'z':z,'hp':d+2*(pf+p['edge']),'top_edge':-pf-p['edge'],'bottom_edge':d+pf+p['edge']}
    actions={'Meq':me,'Ff':ff,'Fc':fc,'Tb':tb,'T':6*tb,'C':max(6*tb-N,0),'V_per_shear_bolt':abs(V)/6}
    nominal={'DG39_Fnt':pt/ab,'DG39_Mnp':pt*H,'Mnp':.75*p['fub']*ab*H,'Mpl':p['fyp']*p['tp']**2*yp,'Mcf':p['fyc']*p['tcf']**2*yc}
    nominal['DG39_plate_ratio']=nominal['Mpl']/nominal['DG39_Mnp'];nominal['DG39_column_ratio']=nominal['Mcf']/nominal['DG39_Mnp']
    holes=[]
    for piece,thickness,fu,sign in [('plate',p['tp'],p['fup'],-1),('column',p['tcf'],p['fuc'],1)]:
        direction=sign if V>=0 else -sign
        for i in shear:
            ny=i+direction
            lc=abs(y[ny]-y[i])-dh if 0<=ny<6 else None
            if lc is None and piece=='plate':lc=(y[i]-geometry['top_edge'] if direction<0 else geometry['bottom_edge']-y[i])-dh/2
            cap=2.4*p['db']*thickness*fu/G2
            if lc is not None:cap=min(cap,1.2*lc*thickness*fu/G2)
            holes.append({'piece':piece,'row':i,'force_direction':direction,'lc':lc,'resistance':cap})
    blocks=[]
    for side,order,edge in [('top',list(range(6)),geometry['top_edge']),('bottom',list(range(5,-1,-1)),geometry['bottom_edge'])]:
        for n,i in enumerate(order,1):
            loaded=len(set(order[:n]) & set(shear));lv=abs(y[i]-edge)
            ag=lv*p['tp'];an=(lv-(n-.5)*dn)*p['tp'];at=(p['bp']-g-dn)*p['tp']/2
            cap=2/G2*(.5*p['fup']*at+min(.6*p['fup']*an,.6*p['fyp']*ag))
            blocks.append({'edge':side,'hole_rows':n,'loaded_rows':loaded,'Agv':ag,'Anv':an,'Ant':at,'demand':loaded*abs(V)/3,'resistance':cap})
    rigid=lambda fy,Y:math.sqrt(1.1*me*max(G1,1/.9)/(fy*Y))
    return {'geometry':geometry,'actions':actions,'nominal':nominal,'active_indices':active,'shear_indices':shear,'holes':holes,'blocks':blocks,'lwt':pi+pb+152.4,'lws':min(d-2*t-pi-pb-152.4,(d-2*t)/2),'domain':bool(M and abs(N)*z<=abs(M)),'required_tp':rigid(p['fyp'],yp),'required_tcf':rigid(p['fyc'],yc)}

def close(a,b,path='',counts=None):
    if counts is None:counts=[0]
    if isinstance(a,dict):
        for k,v in a.items():close(v,b[k],path+'.'+k,counts)
    elif isinstance(a,list):
        assert len(a)==len(b),(path,len(a),len(b))
        for i,(x,y) in enumerate(zip(a,b)):close(x,y,f'{path}[{i}]',counts)
    elif isinstance(a,(int,float)) and not isinstance(a,bool):
        assert math.isclose(a,b,rel_tol=2e-12,abs_tol=2e-9),(path,a,b)
        counts[0]+=1
    else:
        assert a==b,(path,a,b);counts[0]+=1
    return counts[0]

if __name__=='__main__':
    # Packaging adaptation only: read shipped fixture; calculations above unchanged.
    root=Path(__file__).resolve().parents[2]
    fixture=root/'tests/fixtures/mre12_independent0941.json'
    data=json.loads(fixture.read_text());count=0
    allcases={**data['cases'],**data['negative_controls']}
    for name,r in allcases.items():
        q=expected(r['input'])
        compared={k:v for k,v in q.items() if not k.startswith('required_')}
        count+=close(compared,r,name)
        count+=close(q['required_tp'],r['checks'][0]['demand'],name+'.tp')
        count+=close(q['required_tcf'],r['checks'][1]['demand'],name+'.tcf')
    print(json.dumps({'fixture_sha256':hashlib.sha256(fixture.read_bytes()).hexdigest(),
                      'case_count':len(allcases),'scalar_assertions_passed':count},indent=2))
