"""Read-only exact legacy behavior fingerprint. Run with PYTHONPATH at either frozen tree.
Does not run an aggregate; writes only a requested JSON file outside app source.
"""
import hashlib,json,math,sys
from dataclasses import replace
from pathlib import Path
from lro.end_plate import presets,input_digest,verification_snapshot,method_revision

CASES={}
for name,c in presets().items():
    if c.variant not in ('4E','4ES','8ES'):
        continue
    CASES[name+' | original']=c
    for sm in (-1,1):
        for n in (-2000.,0.,2000.):
            for v in (-11000.,45000.):
                if c.kind=='pinned' and sm==-1:continue
                key=f'{name} | sign {sm} N{n:g} V{v:g}'
                CASES[key]=replace(c,M=sm*abs(c.M),N=n,V=v)
    if c.variant=='4E' and c.kind=='moment':
        for n in (1,2,3):
            CASES[name+f' | intermediate{n}']=replace(c,intermediate_n=n)
    if c.kind=='moment':
        CASES[name+' | pure_moment']=replace(c,N=0.,V=0.)
        CASES[name+' | incomplete_minimum']=replace(c,N=1000.,V=0.,M=1e6)

def safe(v):
    if isinstance(v,float) and not math.isfinite(v):return {'nonfinite':str(v)}
    if isinstance(v,dict):return {k:safe(x) for k,x in v.items()}
    if isinstance(v,(list,tuple)):return [safe(x) for x in v]
    return v
rows={}
for name,c in CASES.items():
    state=safe(dict(digest=input_digest(c),method_revision=method_revision(c),
       verification=verification_snapshot(c),assumptions=c.assumptions))
    body=json.dumps(state,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
    rows[name]={'sha256':hashlib.sha256(body.encode()).hexdigest(),'state':state}
import gzip
expected=json.loads(gzip.decompress((Path(__file__).parent/'legacy0940_expected.json.gz').read_bytes()))
assert rows==expected, 'Legacy snapshot mismatch'
print(json.dumps({'matched_complete_legacy_snapshots':len(rows)}))
