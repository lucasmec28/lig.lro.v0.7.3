from pathlib import Path
import sys,json,traceback,hashlib,math
from dataclasses import replace,asdict
from io import BytesIO
assert len(sys.argv)==3, 'Usage: probe_outputs.py ACTUAL_APP_ROOT OUTPUT_DIRECTORY'
ROOT=Path(sys.argv[1]).resolve();OUT=Path(sys.argv[2]).resolve();OUT.mkdir(parents=True,exist_ok=True)
assert (ROOT/'app.py').is_file() and (ROOT/'lro/end_plate.py').is_file()
assert not OUT.is_relative_to(ROOT), 'Write evidence outside application source'
ART=OUT/'artifacts';ART.mkdir(exist_ok=True)
sys.path.insert(0,str(ROOT))
import matplotlib.pyplot as plt
from matplotlib.patches import Circle
from docx import Document
from lro.end_plate import EndPlate,presets,evaluate,input_digest,method_revision
from lro.end_plate_drawing import figure,image_bytes
from lro.end_plate_report import create_report
c=next(c for c in presets().values() if c.variant=='MRE12_U');old=next(c for c in presets().values() if c.kind=='moment' and c.variant=='4E')
records=[]
def hashes():return {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'lro').glob('end_plate*.py')}
before=hashes()
def step(name,fn):
 try:
  result=fn();records.append({'name':name,'passed':True,'details':result});print('PASS',name,flush=True)
 except Exception as e:
  records.append({'name':name,'passed':False,'error':str(e),'traceback':traceback.format_exc()});print('FAIL',name,str(e),flush=True)
 (OUT/'OUTPUT_RESULTS.json').write_text(json.dumps({'results':records,'source_before':before,'source_after':hashes()},ensure_ascii=False,indent=2))
def approx(a,b):assert math.isclose(a,b,rel_tol=2e-14,abs_tol=1e-9),(a,b)
def doc_text(d):return '\n'.join(p.text for p in d.paragraphs)+'\n'+'\n'.join(c.text for t in d.tables for r in t.rows for c in r.cells)+'\n'+'\n'.join(d.element.xpath('.//m:t/text()'))
def drawing(v,name):
 fig=figure(v)
 try:
  fig.canvas.draw();front,side=fig.axes;holes=[p for p in front.patches if isinstance(p,Circle)]
  assert len(holes)==12
  assert sorted(p.center[1] for p in holes)==sorted(v.rows*2)
  active=[p for p in holes if p.get_gid().endswith('_tension')]
  shear=[p for p in holes if p.get_gid().endswith('_shear')]
  assert len(active)==6 and len(shear)==6
  expected=v.rows[:3] if v.M>0 else v.rows[3:]
  assert {p.center[1] for p in active}==set(expected)
  arms=[t for t in side.texts if (t.get_gid() or '').startswith('tension_arm_')]
  assert len(arms)==3
  for t,h in zip(arms,[652.2,532.6,442.6]):approx(abs(t._dimension_endpoints[1][1]-t._dimension_endpoints[0][1]),h)
  assert not any('stiffener' in (p.get_gid() or '') for ax in fig.axes for p in ax.patches)
  dims=[t for t in front.texts if (t.get_gid() or '').startswith('pb_dimension_')]
  assert len(dims)==2
  for d in dims:approx(abs(d._dimension_endpoints[1][1]-d._dimension_endpoints[0][1]),90.)
  texts='\n'.join(t.get_text() for t in fig.texts)
  for token in ['MRE1/2','12 parafusos físicos','6 ativos em tração','Tabela 5-12 / A-4(a)',input_digest(v),method_revision(v),'nominal: chapa','Demanda espessa']:
   assert token in texts,token
  assert ('mesa tracionada superior' if v.M>0 else 'mesa tracionada inferior') in texts
  fig.savefig(ART/(name+'.png'),dpi=190)
 finally:plt.close(fig)
 svg=image_bytes(v,'svg');(ART/(name+'.svg')).write_bytes(svg)
 assert svg.count(b'id="bolt_front_row_')==12
 return {'holes':12,'tension':6,'shear':6,'arms':3,'height':v.hp,'png':name+'.png','svg':name+'.svg'}
for ms in (1,-1):
 for vs in (1,-1):
  v=replace(c,M=ms*c.M,V=vs*c.V)
  def signed(v=v):
   a=evaluate(v).geometry['actual_actions'];assert len(a['bolts'])==12
   indices=[0,1,2] if v.M>0 else [5,4,3];assert a['active_indices']==indices
   for q in a['bolts']:
    active=q['row']-1 in indices
    assert q['active_tension']==active
    approx(q['tension'],a['bolt_tension'] if active else 0)
    approx(q['column_signed_shear'],0 if active else v.V/6)
    approx(q['plate_signed_shear'],0 if active else -v.V/6)
   result=drawing(v,'M'+str(ms)+'_V'+str(vs));result['signed_groups_verified']=True;return result
  step('signed_drawing_M'+str(ms)+'_V'+str(vs),signed)

def zero():
 v=replace(c,M=0.,N=0.,V=0.);fig=figure(v)
 try:
  text='\n'.join(t.get_text() for t in fig.texts)
  assert '6 ativos em tração' not in text and 'mesa tracionada inferior' not in text and 'h1=' not in text
  assert 'sem extremidade tracionada definida' in text and 'braços ativos indisponíveis' in text
  assert all(p.get_gid().endswith('_inactive') for p in fig.axes[0].patches if isinstance(p,Circle))
  assert not any((t.get_gid() or '').startswith('tension_arm_') for t in fig.axes[1].texts)
 finally:plt.close(fig)
 return {'inactive_holes':12,'invented_active_group':False}
step('zero_drawing_honesty',zero)
def zero_moment():
 for n in (0.,10000.):
  v=replace(c,M=0.,N=n,V=60000.);s=image_bytes(v,'svg').decode()
  assert '6 ativos em tração' not in s and 'mesa tracionada inferior' not in s and 'tension_arm_h' not in s
 return {'M0_nonzero_VN_no_invented_tension':True}
step('zero_moment_loaded_drawing_honesty',zero_moment)
def dormant():
 v=replace(c,stiffener_length=1e308,stiffener_t=1e308,stiffener_compatible=False)
 svg=image_bytes(v,'svg');assert svg.count(b'id="bolt_front_row_')==12
 assert evaluate(v).status==evaluate(c).status
 return {'drawing_preserved':True,'status':evaluate(v).status}
step('dormant_stiffener_output_irrelevance',dormant)

cases={
 'base':c,
 'negative_minimum':replace(c,M=-90e6,N=-10000.,V=-20000.),
 'plate_nominal_fail':replace(c,tp=16.,M=80e6,N=0.,V=30000.,norm_minimum=False),
 'column_nominal_fail':replace(c,support=replace(c.support,tf=18.),M=-80e6,N=0.,V=-30000.,norm_minimum=False),
 'independent_A36':replace(c,plate_steel='ASTM A36'),
}
for name,v in cases.items():
 for detailed in (False,True):
  def report(v=v,name=name,detailed=detailed):
   r=evaluate(v);a=r.geometry['actual_actions'];nom=a['nominal'];b=create_report(v,evaluate(old),detailed);d=Document(BytesIO(b));t=doc_text(d)
   assert input_digest(v) in t and input_digest(old) not in t and method_revision(v) in t
   for token in ['MRE1/2','5-12','A-4(a)','12 físicos; 6 ativos em tração','Ff/3','2Ff/3','T=6Tb','V/6','Diagnóstico nominal separado','DG39 literal','NBR derivada','1,10Mnp','cjp']:
    assert token.lower() in t.lower(),token
   for forbidden in ['Ff/2','T=4Ft','Tabela 5-10','Tabela 5-11','16 parafusos físicos','h4=']:
    assert forbidden not in t,forbidden
   assert len(d.inline_shapes)==1
   embeds=[rel.target_part.blob for rel in d.part.rels.values() if 'image' in rel.reltype]
   assert image_bytes(v,'png') in embeds
   if 'nominal_fail' in name:
    assert a['demand_no_prying'] and not nom['all_no_prying'];assert 'Não classificada sem prying até Mnp.' in t
    assert 'Sem prying até Mnp: ambas as condições nominais atendem.' not in t
    assert not r.method_failures,[(q.id,q.ratio) for q in r.method_failures]
   if name=='negative_minimum':
    assert len(r.case_records)==2
    assert 'Entrada · caso completo' in t and 'Mínimo de força · caso completo' in t
    assert 'Tração inferior, linhas 6, 5, 4' in t and 'cisalhamento nas linhas 1, 2, 3' in t
   if detailed:
    assert 'Parafusos físicos e sentidos de força' in t and 'V coluna, N' in t and 'V chapa, N' in t
   target=name+('_detailed' if detailed else '_compact')+'.docx';(ART/target).write_bytes(b)
   (ART/(name+'.json')).write_text(json.dumps(v.to_dict(),ensure_ascii=False,indent=2))
   return {'status':r.status,'demand_thick':a['demand_no_prying'],'nominal_plate':nom['plate_no_prying'],'nominal_column':nom['column_no_prying'],'cases':len(r.case_records),'artifact':target,'bytes':len(b)}
  step('word_'+name+('_detailed' if detailed else '_compact'),report)
print(json.dumps({'tests':len(records),'failures':sum(not r['passed'] for r in records)},indent=2))

assert all(r['passed'] for r in records), 'Independent acceptance failures; see result JSON'
assert before==hashes(), 'Application end-plate runtime mutated during acceptance'
