from pathlib import Path
import sys,json,hashlib,re,zipfile
from io import BytesIO
root=Path(sys.argv[1]);out=Path(sys.argv[2]);sys.path.insert(0,str(root))
from lro.end_plate import presets,evaluate,input_digest,method_revision
from lro.end_plate_drawing import image_bytes
from lro.end_plate_report import create_report
from lro.models import VERSION
sha=lambda x:hashlib.sha256(x).hexdigest()
rows=[]
for label,c in presets().items():
 if c.variant=='MRE12_U':continue
 r=evaluate(c);d=c.to_dict();d.pop('app_version',None)
 item={'label':label,'kind':c.kind,'variant':c.variant,'digest':input_digest(c),'method_revision':method_revision(c),'status':r.status,'native':d,'png_sha256':sha(image_bytes(c,'png'))}
 if r.checks and not any(x.severity=='error' and x.origin not in ('method','numeric') for x in r.issues):
  for detailed in (False,True):
   with zipfile.ZipFile(BytesIO(create_report(c,r,detailed))) as z:
    members={}
    for name in z.namelist():
     if name in ('docProps/core.xml',):continue
     b=z.read(name).replace(VERSION.encode(),b'VERSION_NORMALIZED')
     members[name]=sha(b)
    item['word_'+str(detailed)]=members
 rows.append(item)
out.write_text(json.dumps(rows,ensure_ascii=False,indent=2))
print(str(out),len(rows))
