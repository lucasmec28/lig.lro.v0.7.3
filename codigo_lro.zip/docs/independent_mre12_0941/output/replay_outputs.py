"""Replay against one explicitly selected source/loader-extracted APP root.
No historic source or optional EXEMPLOS fallback is read.
"""
from pathlib import Path
import argparse,gzip,hashlib,json,os,subprocess,sys,time
from artifact_commitment import commitment
p=argparse.ArgumentParser();p.add_argument('app_root');p.add_argument('output_directory');a=p.parse_args()
ROOT=Path(a.app_root).resolve();OUT=Path(a.output_directory).resolve();HERE=Path(__file__).resolve().parent
assert (ROOT/'app.py').is_file() and (ROOT/'lro/end_plate.py').is_file(),ROOT
assert not OUT.is_relative_to(ROOT),'Evidence output must be outside immutable application'
OUT.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text())
expected=read(HERE/'RUNTIME_HASHES.json')
def runtime():
 d={}
 for glob in ('app.py','lro/*.py','data/*'):
  for f in ROOT.glob(glob):
   if f.is_file():d[f.relative_to(ROOT).as_posix()]=sha(f)
 return d
before=runtime();assert before==expected,'Reviewed application runtime/data mismatch'
env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1';env['MPLCONFIGDIR']=str(OUT/'mpl');env['XDG_CACHE_HOME']=str(OUT/'cache')
# Dependency search paths may point to installed packages; imported application
# identity is explicitly checked and must be beneath the selected actual root.
code="import sys,json;from pathlib import Path;sys.path.insert(0,sys.argv[1]);import lro.end_plate as m;import lro.end_plate_ui as u;import lro.end_plate_mre12_report as w;from lro.models import VERSION;r=Path(sys.argv[1]).resolve();paths=[Path(x.__file__).resolve() for x in (m,u,w)];assert all(p.is_relative_to(r) for p in paths);print(json.dumps({'version':VERSION,'module_paths':[str(p) for p in paths]}))"
q=subprocess.run([sys.executable,'-B','-c',code,str(ROOT)],env=env,capture_output=True,text=True);assert q.returncode==0,q.stderr
binding=json.loads(q.stdout);assert binding['version']=='0.9.41-mre12-end-plate-dev'
results=[]
for script,name in [('probe_outputs.py','mre_output'),('probe_native.py','mre_native'),('probe_legacy.py','legacy')]:
 dest=OUT/name if name!='legacy' else OUT/'legacy_current.json'
 cmd=[sys.executable,'-B',str(HERE/script),str(ROOT),str(dest)];start=time.monotonic()
 with (OUT/(name+'.log')).open('w') as f:q=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 results.append({'script':script,'exit_code':q.returncode,'seconds':time.monotonic()-start})
 assert q.returncode==0,results[-1]
o=read(OUT/'mre_output/OUTPUT_RESULTS.json');n=read(OUT/'mre_native/NATIVE_RESULTS.json')
assert len(o['results'])==17 and all(x['passed'] for x in o['results'])
assert len(n['results'])==7 and all(x['passed'] for x in n['results'])
assert o['source_before']==o['source_after'] and n['source_before']==n['source_after']
legacy=json.loads(gzip.decompress((HERE/'legacy_baseline.json.gz').read_bytes()));current=read(OUT/'legacy_current.json')
assert current==legacy,'Legacy native/result/image/report parity failure'
expected_artifacts=read(HERE/'ARTIFACT_COMMITMENTS.json');actual_dir=OUT/'mre_output/artifacts'
assert set(expected_artifacts)=={p.name for p in actual_dir.iterdir()}
assert all(commitment(actual_dir/name)==value for name,value in expected_artifacts.items()),'Current artifact commitments differ'
native=sorted((HERE/'native').glob('*.json'));assert len(native)==5
assert all(p.read_bytes()==(actual_dir/p.name).read_bytes() for p in native),'Shipped native/result evidence differs from actual application'
after=runtime();assert after==before,'Application runtime/data changed during replay'
receipt={'status':'PASS_CURRENT_MRE12_OUTPUT_NATIVE_GATE','actual_app_root':str(ROOT),'binding':binding,'reviewed_runtime_sha256':expected,'runtime_unchanged':True,'output_cases':17,'native_flows':7,'legacy_presets':6,'regenerated_artifact_commitments':len(expected_artifacts),'shipped_native_results_verified':5,'proof_bundle_hashes':{p.relative_to(HERE).as_posix():sha(p) for p in HERE.rglob('*') if p.is_file() and '__pycache__' not in str(p)},'subprocesses':results,'no_historic_source_dependency':True,'no_optional_examples_dependency':True,'limitations':'No new pixel viewing is claimed by replay. Reviewed current report/drawing artifacts are matched by strict content commitments. Final packaging must additionally bind this receipt to exact outer and inner archive bytes and loader extraction.'}
(OUT/'CURRENT_OUTPUT_GATE_RECEIPT.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2));print(json.dumps({k:receipt[k] for k in ['status','output_cases','native_flows','legacy_presets','regenerated_artifact_commitments','shipped_native_results_verified']}))
