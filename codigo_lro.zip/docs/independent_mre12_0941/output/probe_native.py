from pathlib import Path
import sys,json,traceback,hashlib
from copy import deepcopy
from dataclasses import replace
from io import BytesIO
assert len(sys.argv)==3, 'Usage: probe_native.py ACTUAL_APP_ROOT OUTPUT_DIRECTORY'
ROOT=Path(sys.argv[1]).resolve();OUT=Path(sys.argv[2]).resolve();OUT.mkdir(parents=True,exist_ok=True)
assert (ROOT/'app.py').is_file() and (ROOT/'lro/end_plate.py').is_file()
assert not OUT.is_relative_to(ROOT), 'Write evidence outside application source'
sys.path.insert(0,str(ROOT))
from streamlit.testing.v1 import AppTest
from streamlit.runtime.memory_media_file_storage import MemoryMediaFileStorage
from lro.end_plate import EndPlate,presets,evaluate,input_digest,method_revision
from docx import Document
files={};original=MemoryMediaFileStorage.load_and_get_id
def tap(storage,*args,**kwargs):
 key=original(storage,*args,**kwargs);files[key]=storage._files_by_id[key].content;return key
MemoryMediaFileStorage.load_and_get_id=tap
records=[]
def hashes():return {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'lro').glob('end_plate*.py')}
before=hashes()
def save(): (OUT/'NATIVE_RESULTS.json').write_text(json.dumps({'results':records,'source_before':before,'source_after':hashes()},ensure_ascii=False,indent=2))
def step(name,fn):
 try:
  d=fn();records.append({'name':name,'passed':True,'details':d});print('PASS',name,flush=True)
 except Exception as e:
  records.append({'name':name,'passed':False,'error':str(e),'traceback':traceback.format_exc()});print('FAIL',name,str(e),flush=True)
 save()
def ok():
 assert not at.exception,[(x.message,x.stack_trace) for x in at.exception]
def button(label):return next(x for x in at.button if x.label==label)
def saved():return deepcopy(at.session_state['_end_plate_projects']['moment']['connection'])
def word():return any(x.label=='Baixar memória Word' for x in at.get('download_button'))
def load(c):
 at.get('file_uploader')[0].upload('independent_mre12.json',json.dumps(c.to_dict()).encode(),'application/json').run();button('Abrir projeto de end plate').click().run();ok();assert 'ep_import_error' not in at.session_state,at.session_state['ep_import_error']
def download(label):
 ctrl=next(x for x in at.get('download_button') if x.label==label)
 return files[Path(ctrl.proto.url).name.rsplit('.',1)[0]]
def textdoc(b):
 d=Document(BytesIO(b));return '\n'.join(p.text for p in d.paragraphs)+'\n'+'\n'.join(c.text for t in d.tables for r in t.rows for c in r.cells)
at=AppTest.from_file(str(ROOT/'app.py'),default_timeout=120)
at.session_state['connection_family']='End plate · engastada';at.run();ok()
c=next(c for c in presets().values() if c.variant=='MRE12_U')
def first():
 before=deepcopy(at.session_state['ep_model']);opts=at.selectbox(key='ep_variant').options
 assert any('12 parafusos sem nervuras' in x and 'MRE1/2' in x for x in opts),opts
 at.selectbox(key='ep_variant').set_value('MRE12_U').run();ok()
 after=deepcopy(at.session_state['ep_model']);assert after['variant']=='MRE12_U'
 assert {k:v for k,v in before.items() if k!='variant'}=={k:v for k,v in after.items() if k!='variant'}
 assert at.number_input(key='ep_pb');assert at.number_input(key='ep_intermediate_n').disabled
 assert not any(x.key and x.key.startswith('ep_stiffener_') for x in at.number_input)
 return {'options':opts,'first_switch_preserves':True}
step('first_discoverable_native_variant',first)
def witness():
 load(c);assert saved()['pb']==90.;assert any(x.value=='ATENDE ÀS VERIFICAÇÕES REALIZADAS' for x in at.success)
 captions='\n'.join(x.value for x in at.caption)
 for token in ('12 parafusos','seis','Diagnóstico nominal separado','Sem prying até Mnp.'):
  assert token in captions,token
 assert not any('necessárias pelo menos' in x.value for x in at.info)
 return {'saved_variant':saved()['variant'],'status':evaluate(c).status}
step('native_base_witness',witness)
precise=replace(c,pb=90.123456789,pfi=50.123456789,tp=25.4123456789,M=-180123456.789,N=20123.456789,V=-60123.456789,project='Independent exact native witness',notes='Independent precision preserved')
def precision():
 load(precise);before=saved()
 for k in ('pb','pfi','tp'):assert before[k]==getattr(precise,k)
 for k in ('M','N','V'):assert abs(before[k]-getattr(precise,k))<=abs(getattr(precise,k))*1e-15
 for k in ('pb','pfi','tp','M_kgfm','N_kgf','V_kgf'):assert at.number_input(key='ep_'+k).proto.format=='%.2f'
 actual=download('Salvar projeto JSON');(OUT/'native_precise.json').write_bytes(actual)
 at.get('file_uploader')[0].upload('actual_native.json',actual,'application/json').run();button('Abrir projeto de end plate').click().run();ok()
 assert saved()==before
 assert json.loads(actual)['connection']==before
 return {'native_bytes':len(actual),'pb':before['pb'],'tp':before['tp'],'actions':{k:before[k] for k in ('M','N','V')}}
step('native_exact_export_roundtrip',precision)
def artifacts():
 button('Gerar memória Word').click().run();ok();assert word()
 b=download('Baixar memória Word');(OUT/'native_precise_compact.docx').write_bytes(b)
 native=EndPlate.from_dict({'schema_version':1,'connection_type':'end_plate','connection':saved()})
 assert input_digest(native) in textdoc(b)
 for key,value in [('pb',91.123456789),('pfi',51.123456789),('M_kgfm',-18000.123456789)]:
  at.number_input(key='ep_'+key).set_value(value).run();ok();assert not word(),key
  button('Gerar memória Word').click().run();ok();assert word()
 previous=saved()
 at.selectbox(key='ep_plate_steel').set_value('ASTM A36').run();ok();assert not word()
 for key in ('beam_steel','support_steel'):assert saved()[key]==previous[key]
 assert saved()['plate_steel']=='ASTM A36'
 button('Gerar memória Word').click().run();ok();assert word()
 previous=saved();at.selectbox(key='ep_variant').set_value('4E').run();ok();assert not word()
 at.selectbox(key='ep_variant').set_value('MRE12_U').run();ok();assert all(abs(saved()[k]-v)<=abs(v)*1e-15 if k in ('M','N','V') else saved()[k]==v for k,v in previous.items()),{k:(previous.get(k),saved().get(k)) for k in set(previous)|set(saved()) if previous.get(k)!=saved().get(k)};assert not word()
 return {'tested_changes':['pb','pfi','M','plate_steel','variant'],'independent_material':True}
step('native_stale_word_and_materials',artifacts)
def invalid():
 load(c);button('Gerar memória Word').click().run();ok();assert word()
 before=saved();report=at.session_state['ep_report'];reject=[]
 for key,value in [('pb',None),('cjp_compatible',None),('layout','top'),('intermediate_n',1),('pb',300.)]:
  d=c.to_dict()
  if value is None:del d['connection'][key]
  else:d['connection'][key]=value
  at.get('file_uploader')[0].upload('invalid.json',json.dumps(d).encode(),'application/json').run();button('Abrir projeto de end plate').click().run();ok()
  assert 'ep_import_error' in at.session_state,(key,value)
  assert saved()==before and at.session_state['ep_report']==report and word(),(key,value)
  reject.append({'key':key,'value':value,'error':at.session_state['ep_import_error']})
 return reject
step('invalid_import_atomicity',invalid)

def variants():
 load(c);at.number_input(key='ep_pb').set_value(91.123456789).run();at.checkbox(key='ep_cjp_compatible').uncheck().run();ok();mre=saved()
 for variant in ('4E','8ES','4ES','MRE12_U'):
  at.selectbox(key='ep_variant').set_value(variant).run();ok()
 assert all(abs(saved()[k]-v)<=max(1.,abs(v))*1e-15 if k in ('M','N','V') else saved()[k]==v for k,v in mre.items())
 assert at.checkbox(key='ep_cjp_compatible').value is False
 at.selectbox(key='connection_family').set_value('End plate · rotulada').run();ok()
 at.selectbox(key='connection_family').set_value('End plate · engastada').run();ok();assert all(abs(saved()[k]-v)<=max(1.,abs(v))*1e-15 if k in ('M','N','V') else saved()[k]==v for k,v in mre.items())
 return {'mre_draft_restored':True,'variant_and_family_roundtrip':True}
step('four_variant_and_family_draft_roundtrip',variants)
def extra_first():
 fresh=AppTest.from_file(str(ROOT/'app.py'),default_timeout=120);fresh.session_state['connection_family']='End plate · engastada';fresh.run();assert not fresh.exception
 fresh.selectbox(key='ep_layout').set_value('top').run();fresh.number_input(key='ep_intermediate_n').set_value(2).run();prior=deepcopy(fresh.session_state['_end_plate_projects']['moment']['connection'])
 fresh.selectbox(key='ep_variant').set_value('MRE12_U').run();assert not fresh.exception
 assert fresh.session_state['ep_model']['layout']=='both' and fresh.session_state['ep_model']['intermediate_n']==0
 fresh.selectbox(key='ep_variant').set_value('4E').run();assert not fresh.exception
 assert fresh.session_state['_end_plate_projects']['moment']['connection']==prior
 return {'mre_fixed_topology':True,'prior_four_e_preserved':True}
step('first_mre_from_extra_top_only_four_e',extra_first)
print(json.dumps({'tests':len(records),'failures':sum(not x['passed'] for x in records)},indent=2))

assert all(r['passed'] for r in records), 'Independent acceptance failures; see result JSON'
assert before==hashes(), 'Application end-plate runtime mutated during acceptance'
