Independent MRE1/2 UI and output replay

Run with the Python environment satisfying the application's pinned runtime dependencies:
  python -B replay_outputs.py ACTUAL_APP_ROOT OUTPUT_DIRECTORY

ACTUAL_APP_ROOT must be the selected source root or the root extracted by the actual shipped APP loader, containing app.py, lro and data. OUTPUT_DIRECTORY must be outside it. The driver refuses changed runtime/data, verifies imported application module paths, replays 17 output cases and 7 actual Streamlit AppTest flows, regenerates and compares 23 artifact commitments, verifies all five shipped native/result snapshots, compares six legacy presets against the self-contained frozen baseline, and proves source immutability. No prior source tree or optional EXEMPLOS companion is read.

Run on the final APP only after the packaging reviewer verifies the outer and inner archive hashes and actual loader extraction. Bind those archive/loader identities to CURRENT_OUTPUT_GATE_RECEIPT.json in the packaging receipt.

Expected content is full precision. The SVG normalizer removes only its one generation timestamp and its automatically generated hexadecimal reference IDs. Word comparisons use every exact uncompressed member, including embedded PNGs and core properties; ZIP timestamps/compression are not semantic artifact content. PNG and native JSON comparisons use exact bytes. The legacy baseline allows only the explicit app version substitution in Word and excludes document core properties from its pre-existing-member comparison.

The seven native flows use real Streamlit AppTest controls. No browser screenshot/layout check is claimed. Native floating-point N/V/M unit-conversion equality permits only 1e-15 relative after a draft restore; geometric/material values and actual downloaded JSON reopening remain exact. This tolerance never influences an engineering calculation or approval.

Full aggregate, method/mechanics qualification, packaging limits, publication and structural/fabrication approval remain separate gates. Rendered document images are local review evidence and are deliberately not duplicated here.

Signed drawing reproduction: probe_outputs.py creates M1_V1, M1_V-1, M-1_V1 and M-1_V-1 PNG/SVG pairs by taking the MRE12_U preset (identical to native/base.json) and applying M and V signs independently. These use no action-unit conversion. The output result ledger is OUTPUT_RESULTS.json. The five native/*.json files include exact input and full verification results. SOURCE_REPLAY_RECEIPT.json records the successful replay of the executable proof bundle before the historical evidence JSONs and this explanatory paragraph were added; executable scripts and commitments are unchanged.

Evidence amendment 1: column_nominal_fail is a synthetic welded I-column, d=bf=600 mm, tw=19 mm, tf=18 mm, clear=564 mm, A=32316 mm², mass=253.6806 kg/m. It is an engine-level negative control and does not represent CS 600 x 377. The catalog-only UI deliberately rejects this fixture; reproduce it through EndPlate.from_dict or the shipped output runner. All other selected native examples use catalog profiles.

The prior signed acceptance and its byte-exact proof ledgers are retained under provenance/pre_synthetic_amendment. The current acceptance explicitly supersedes only the mislabeled negative-control evidence. All 17 output cases, seven native flows, six legacy presets and 23 artifact commitments passed again with unchanged held runtime. The amended compact report has five pages and the detailed report nine; all 14 pages were visually reviewed. SOURCE_REPLAY_RECEIPT.json records the tested executable bundle before these evidence-only receipt/README additions. No executable or expected-artifact changes followed the successful replay.
