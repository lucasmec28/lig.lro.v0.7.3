from pathlib import Path
import json,hashlib,zipfile,re
sha=lambda b:hashlib.sha256(b).hexdigest()
def commitment(p):
 p=Path(p)
 if p.suffix=='.docx':
  with zipfile.ZipFile(p) as z:return {'kind':'exact_uncompressed_docx_members','members':{n:sha(z.read(n)) for n in sorted(z.namelist())}}
 if p.suffix=='.svg':
  s=p.read_text();dates=re.findall(r'<dc:date>([^<]+)</dc:date>',s)
  assert len(dates)==1 and re.fullmatch(r'[0-9T:.+-]+',dates[0]),dates
  s=re.sub(r'<dc:date>[^<]+</dc:date>','<dc:date>GENERATION_TIMESTAMP</dc:date>',s)
  ids=re.findall(r'id="([pm][0-9a-f]{10})"',s)
  for i,key in enumerate(ids):s=s.replace('id="'+key+'"','id="runtime_id_'+str(i)+'"').replace('url(#'+key+')','url(#runtime_id_'+str(i)+')').replace('href="#'+key+'"','href="#runtime_id_'+str(i)+'"')
  return {'kind':'svg_without_timestamp_and_generated_reference_ids','sha256':sha(s.encode()),'normalized_id_count':len(ids)}
 return {'kind':'exact_bytes','sha256':sha(p.read_bytes())}
