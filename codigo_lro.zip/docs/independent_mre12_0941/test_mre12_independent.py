"""Independent mechanics acceptance. No writes to production and no aggregate."""
import copy,json,math
from dataclasses import replace
from pathlib import Path
import pytest
from lro.end_plate import EndPlate,evaluate,presets,input_digest,method_revision,connection_inputs
from lro.end_plate_mre12 import yield_mre12,yield_column_mre12,source_ranges,required_inputs
from independent_expected import expected,close
ROOT=Path(__file__).resolve().parents[2]
ORACLE=json.loads((ROOT/'tests/fixtures/mre12_independent0941.json').read_text())
BASE=presets()['Engastada · 12 parafusos sem nervuras (MRE1/2)']
CASES={**ORACLE['cases'],**ORACLE['negative_controls']}

def from_p(p):
    b=replace(BASE.beam,name=p['beam'],d=p['d'],bf=p['bf'],tw=p['tw'],tf=p['tf'],clear=p['hclear'])
    s=replace(BASE.support,name=p['support'],d=p['dc'],bf=p['bcf'],tw=p['tcw'],tf=p['tcf'],clear=p['hcclear'])
    keys=('beam_steel','plate_steel','bolt','db','threads','bp','tp','pfo','pfi','pb','edge','drilled','tool_radius','M','N','V')
    return replace(BASE,beam=b,support=s,support_steel=p['column_steel'],gauge=p['g'],**{k:p[k] for k in keys})

def rows(r):return {q.id:q for q in r.actual}

def eq(x,y):assert math.isclose(x,y,rel_tol=2e-12,abs_tol=2e-9),(x,y)

@pytest.mark.parametrize('name',[n for n,r in CASES.items() if r['domain']])
def test_independent_complete_oracle_cases(name):
    fixture=CASES[name];p=fixture['input'];c=from_p(p);r=evaluate(c);a=r.geometry['actual_actions'];q=expected(p);rr=rows(r)
    close(c.rows,q['geometry']['rows']);close(c.tension_arms,q['geometry']['h']);eq(c.hp,q['geometry']['hp'])
    for source,key in [('Meq','Meq'),('Ff','flange_transfer_force'),('Fc','flange_compression_force'),('Tb','bolt_tension'),('T','T'),('C','C'),('V_per_shear_bolt','bolt_shear')]:eq(a[key],q['actions'][source])
    for source,key in [('H','H'),('Yp','Yp'),('Yc','Yc'),('bp_eff','effective_bp'),('bcf_eff','effective_bfc'),('sP','plate_s'),('sC','column_s'),('pfi_eff','plate_pfi_effective'),('c','column_c')]:eq(a[key],q['geometry'][source])
    eq(a['tp_required'],q['required_tp']);eq(a['column_tf_required'],q['required_tcf']);eq(a['web_tension_length'],q['lwt']);eq(a['web_shear_weld_length'],q['lws'])
    assert a['active_indices']==q['active_indices'] and a['shear_indices']==q['shear_indices']
    close(a['active_arms'],q['geometry']['h']);assert len(a['bolts'])==12
    assert sum(b['active_tension'] for b in a['bolts'])==6 and sum(b['shear_group'] for b in a['bolts'])==6
    for b in a['bolts']:
        i=b['row_index'];assert b['row']==i+1;eq(b['y'],c.rows[i]);assert b['x'] in (-c.gauge/2,c.gauge/2)
        eq(b['tension'],q['actions']['Tb'] if i in q['active_indices'] else 0.)
        eq(b['signed_shear'],p['V']/6 if i in q['shear_indices'] else 0.)
        eq(b['plate_signed_shear'],-b['signed_shear']);eq(b['column_signed_shear'],b['signed_shear'])
        assert b['active_tension'] != b['shear_group']
    for actual,want in zip(a['bearing_paths'],q['holes']):
        assert actual['row_index']==want['row'];assert actual['piece']==want['piece'];assert actual['force_direction']==want['force_direction']
        if want['lc'] is None:assert actual['lc'] is None
        else:eq(actual['lc'],want['lc'])
        eq(actual['demand'],abs(p['V'])/6);eq(actual['resistance'],want['resistance'])
    assert len(a['bearing_paths'])==6 and len(a['plate_blocks'])==12
    for actual,want in zip(a['plate_blocks'],q['blocks']):close(want,actual)
    nom=a['nominal'];eq(nom['Mnp'],q['nominal']['DG39_Mnp']);eq(nom['Fnt'],q['nominal']['DG39_Fnt'])
    for k in ('Mpl','Mcf'):eq(nom[k],q['nominal'][k])
    eq(nom['NBR_reference']['Mnp'],q['nominal']['Mnp'])
    assert nom['plate_no_prying']==(nom['Mpl']>=1.1*nom['Mnp']);assert nom['column_no_prying']==(nom['Mcf']>=1.1*nom['Mnp'])
    mapping={'plate_demand_thick':'plate_rigidity','column_demand_thick':'column_rigidity','bolt_tension':'bolt_tension','bolt_shear':'bolt_shear','extension_gross_shear':'extension_shear_yield','extension_net_shear':'extension_shear_rupture','beam_web_local_tension':'beam_web_local_tension','CJP_web_tension':'weld_cjp_web_local','CJP_web_shear':'weld_cjp_web_shear','CJP_flange':'weld_cjp_flange_local','CJP_equivalent_stress':'weld_cjp','beam_web_shear':'beam_web','column_web_yield':'column_web_yield','column_web_crippling':'column_crippling','contact':'contact','panel':'panel','beam_flange_compact':'compact_flange','beam_web_compact':'compact_web'}
    checks={x['name']:x for x in fixture['checks']}
    for old,new in mapping.items():
        eq(rr['ep_'+new].demand,checks[old]['demand']);eq(rr['ep_'+new].resistance,checks[old]['resistance'])
    eq(rr['ep_bolt_interaction'].demand,max(b['interaction'] for b in a['bolts']))
    for piece in ('plate','column'):
        worst=max((x for x in a['bearing_paths'] if x['piece']==piece),key=lambda v:v['ratio'])
        eq(rr['ep_bearing_'+piece].demand,worst['demand']);eq(rr['ep_bearing_'+piece].resistance,worst['resistance'])
    worst=max(a['plate_blocks'],key=lambda v:v['ratio']);eq(rr['ep_block_plate'].demand,worst['demand']);eq(rr['ep_block_plate'].resistance,worst['resistance'])

@pytest.mark.parametrize('sm',[-1,1])
@pytest.mark.parametrize('sn',[-1,1])
@pytest.mark.parametrize('sv',[-1,1])
def test_actual_minimum_are_complete_sign_preserving_cases(sm,sn,sv):
    c=replace(BASE,M=sm*60e6,N=sn*2000.,V=sv*11000.);r=evaluate(c);f=45000/math.hypot(c.N,c.V)
    assert len(r.case_records)==2 and r.actual and r.minimum;eq(r.minimum_factor,f)
    assert all(x['status']=='calculated' for x in r.case_records)
    for rec in r.case_records:
        k=1 if rec['label']=='Entrada' else f
        eq(rec['actions']['N'],c.N*k);eq(rec['actions']['V'],c.V*k);eq(rec['actions']['M'],c.M)
        assert all(x.case==rec['label'] for x in rec['checks'])
    for selected in r.checks:assert selected is max((x for x in r.actual+r.minimum if x.id==selected.id),key=lambda x:x.ratio)
    assert r.geometry['minimum_actions']['bolts']!=r.geometry['actual_actions']['bolts']

def test_unresolved_minimum_preserves_actual_and_pure_moment():
    c=from_p(CASES['actual_domain']['input']);r=evaluate(c)
    assert r.actual and not r.minimum and len(r.case_records)==2
    assert r.case_records[1]['status']=='unresolved_method_scope' and r.status=='CONDIÇÕES DO MÉTODO NÃO SATISFEITAS'
    assert not c.to_dict()['verification']['approved']
    p=replace(BASE,N=0.,V=0.);a=evaluate(p)
    assert len(a.case_records)==1 and a.minimum_factor==1 and not a.minimum
    assert all(b['shear']==0 for b in a.geometry['actual_actions']['bolts'])

@pytest.mark.parametrize('part',['plate','column'])
def test_exact_one_ulp_demand_thickness_boundary(part):
    a=evaluate(BASE).geometry['actual_actions'];th=a['tp_required' if part=='plate' else 'column_tf_required']
    for v in [math.nextafter(th,-math.inf),th,math.nextafter(th,math.inf)]:
        c=replace(BASE,tp=v) if part=='plate' else replace(BASE,support=replace(BASE.support,tf=v))
        r=evaluate(c);row=rows(r)['ep_'+('plate_rigidity' if part=='plate' else 'column_rigidity')]
        assert row.passed==(v>=th)
        assert rows(r)['ep_bolt_tension'].no_prying_qualified==(v>=th)

def test_book_kernel_exact_nominal_negative_and_units():
    q=ORACLE['book'];b,g,h1,h2,h3,po,pi,pb=8.,5.,25.5,21.5,18.5,1.75,1.75,3.
    y=yield_mre12(b,g,h1,h2,h3,po,pi,pb);eq(y,q['Yp'])
    eq(90*math.pi*.875**2/4*2*(h1+h2+h3),q['Mnp']);eq(50*.875**2*y,q['Mpl'])
    assert .875>=q['demand_tp'] and not q['nominal_plate_pass']
    eq(yield_mre12(*(x*25.4 for x in (b,g,h1,h2,h3,po,pi,pb))),y*25.4)
    p=expected(ORACLE['cases']['M180_N20_V60']['input']);B=p['geometry']['bcf_eff'];h=p['geometry']['h'];cc=p['geometry']['c']
    eq(yield_column_mre12(B,150,h[0],h[2],cc,90),p['geometry']['Yc'])
    eq(yield_column_mre12(*(x/25.4 for x in (B,150,h[0],h[2],cc,90)))*25.4,p['geometry']['Yc'])

@pytest.mark.parametrize('kind',['plate_nominal_only','column_nominal_only'])
def test_nominal_failure_does_not_gate_demand(kind):
    c=from_p(CASES[kind]['input']);r=evaluate(c);a=r.geometry['actual_actions']
    assert a['demand_no_prying'] and not a['nominal']['all_no_prying']
    assert r.status=='ATENDE ÀS VERIFICAÇÕES REALIZADAS' and c.to_dict()['verification']['approved']
    assert not any('nominal' in x.id for x in r.checks)
    assert rows(r)['ep_bolt_tension'].outcome=='Atende'

@pytest.mark.parametrize('pfi',[math.nextafter(math.sqrt(250*150)/2,0),math.sqrt(250*150)/2,math.nextafter(math.sqrt(250*150)/2,math.inf),110.])
def test_saturation_only_yield_formula(pfi):
    c=replace(BASE,pfi=pfi);r=evaluate(c);a=r.geometry['actual_actions']
    assert a['plate_pfi_effective']==min(pfi,a['plate_s'])
    eq(c.rows[1],c.beam.tf+pfi);eq(c.rows[2],c.beam.tf+pfi+c.pb);eq(a['column_c'],c.pfo+c.beam.tf+pfi)
    eq(a['web_tension_length'],pfi+c.pb+152.4);assert a['active_arms']==pytest.approx(c.tension_arms)
    assert not any(x.severity=='extrapolation' and 'pfi=' in x.text for x in r.issues)


def test_no_pfo_saturation_and_no_stiffened_de_gate():
    c=replace(BASE,pfo=110,edge=105);r=evaluate(c);a=r.geometry['actual_actions']
    assert c.pfo>a['plate_s'] and c.edge>a['plate_s'] and r.actual
    assert a['plate_pfo_effective']==110
    eq(a['Yp'],yield_mre12(c.effective_bp,c.gauge,*c.tension_arms,110,c.pfi,c.pb))
    assert not any(x.severity=='error' and 's=' in x.text for x in r.issues)

@pytest.mark.parametrize('change',[{'layout':'top'},{'intermediate_n':1},{'pb':240.}])
def test_topology_controls_do_not_silently_sort_or_convert(change):
    c=replace(BASE,**change);r=evaluate(c)
    assert not r.actual and not c.to_dict()['verification']['approved']
    if 'pb' in change:assert c.rows[2]>c.rows[3]
    assert c.variant=='MRE12_U'

def test_pb_has_no_example_lock_and_all_five_spacings_check():
    assert evaluate(replace(BASE,pb=95.)).status=='ATENDE ÀS VERIFICAÇÕES REALIZADAS'
    r=evaluate(replace(BASE,pb=80.));assert r.actual and r.status=='NÃO ATENDE AO DETALHAMENTO'
    assert any('Espaçamento máximo=312.8' in x.text for x in r.issues)

@pytest.mark.parametrize('change',[{'cjp_compatible':False},{'cjp_electrode':'E6013'},{'fw':600.},{'bp':220.},{'beam_steel':'ASTM A572 Gr.60'}])
def test_cjp_and_full_width_gate_without_false_resistance_failure(change):
    c=replace(BASE,**change);r=evaluate(c)
    assert not c.to_dict()['verification']['approved']
    assert any(i.severity in ('pending','error') for i in r.issues)

@pytest.mark.parametrize('steel',['ASTM A36','ASTM A572 Gr.42','ASTM A572 Gr.50'])
def test_independent_cjp_materials_use_weaker_joint(steel):
    from lro.models import STEELS
    c=replace(BASE,plate_steel=steel);r=evaluate(c);ss=STEELS[steel];rr=rows(r)
    eq(rr['ep_weld_cjp_flange_local'].resistance,min(345,ss.fy)*229*19.6/1.1)
    eq(rr['ep_weld_cjp_web_local'].resistance,min(345,ss.fy)*11.9*292.4/1.1)
    assert not any(i.severity=='pending' and 'selecionadas' in i.text for i in r.issues)

def test_source_pf_upper_range_exact_and_pb_unranged():
    limit=139.7
    for pfi,inside in [(math.nextafter(limit,-math.inf),True),(limit,True),(math.nextafter(limit,math.inf),False)]:
        ranges={q['name']:q for q in source_ranges(replace(BASE,pfi=pfi))};assert ranges['pfi']['within']==inside
    assert not any(x['name']=='pb' for x in source_ranges(BASE))

@pytest.mark.parametrize('missing',['variant','pb','cjp_compatible','cjp_electrode','M','layout'])
def test_native_mre_required_fields_and_cache_distrust(missing):
    native=BASE.to_dict();native['connection'].pop(missing)
    with pytest.raises((ValueError,TypeError)):EndPlate.from_dict(native)

def test_native_roundtrip_active_fields_and_cache_distrust():
    native=BASE.to_dict();native['verification']['approved']=False;native['verification']['geometry']={}
    c=EndPlate.from_dict(native);assert input_digest(c)==input_digest(BASE)
    assert c.to_dict()['verification']['geometry']==BASE.to_dict()['verification']['geometry']
    for k,v in [('pb',95.),('cjp_compatible',False),('cjp_electrode','E6013'),('M',-180e6),('V',-60000.)]:assert input_digest(replace(BASE,**{k:v}))!=input_digest(BASE)
    assert method_revision(BASE)=='endplate-mre12-nbr-demand-thick-0941-v1'


def test_legacy_arbitrary_rows_never_gain_mre_credit():
    c=presets()['Engastada · extensão acima e abaixo'];e=evaluate(c);changed=evaluate(replace(c,intermediate_n=2))
    for key in ['Yp','Yc','bolt_tension','T','C']:eq(changed.geometry['actual_actions'][key],e.geometry['actual_actions'][key])
    assert not c.is_mre12 and not any(x=='A-4(a)' for x in changed.geometry['actual_actions'].values() if isinstance(x,str))

@pytest.mark.parametrize('bad',[[],{},True,None])
def test_malformed_bolt_identity_does_not_crash_or_approve(bad):
    c=replace(BASE,bolt=bad);r=evaluate(c)
    assert r.issues and not r.actual
    assert r.status=='DADOS NECESSÁRIOS AUSENTES OU INVÁLIDOS'
    native=BASE.to_dict();native['connection']['bolt']=bad
    with pytest.raises(ValueError):EndPlate.from_dict(native)

@pytest.mark.parametrize('part',['beam','support'])
@pytest.mark.parametrize('family',['RHS','C','Cantoneira','Madeira'])
def test_non_i_profile_identity_cannot_approve(part,family):
    c=replace(BASE,**{part:replace(getattr(BASE,part),family=family)})
    assert not c.to_dict()['verification']['approved']
    assert any(x.severity=='error' for x in evaluate(c).issues)

@pytest.mark.parametrize('variant',[None,'4E','4ES','8ES'])
def test_mre_only_fields_cannot_be_silently_reinterpreted(variant):
    native=BASE.to_dict();native['connection'].pop('pb')
    if variant is None:native['connection'].pop('variant')
    else:native['connection']['variant']=variant
    with pytest.raises(ValueError):EndPlate.from_dict(native)

@pytest.mark.parametrize('pb',[68.4,70.])
def test_absent_web_shear_region_not_given_fictitious_resistance(pb):
    b=replace(BASE.beam,d=300.,clear=260.8)
    c=replace(BASE,beam=b,pfi=40.,pb=pb,M=30e6,N=0.)
    r=evaluate(c);a=r.geometry['actual_actions']
    assert a['web_shear_weld_length']<=0
    assert 'ep_weld_cjp_web_shear' not in rows(r)
    assert not c.to_dict()['verification']['approved']
    assert any(x.severity=='pending' and 'CJP positiva' in x.text for x in r.issues)

@pytest.mark.parametrize('threads',[True,False])
@pytest.mark.parametrize('drilled',[True,False])
def test_threads_grip_and_nbr_hole_deduction_independent(threads,drilled):
    c=replace(BASE,threads=threads,drilled=drilled,tp=80.,support=replace(BASE.support,tf=80.,d=750.))
    r=evaluate(c);rr=rows(r);a=r.geometry['actual_actions'];ab=math.pi*c.db**2/4
    grip=max(0,1-.01*max(c.tp+c.support.tf-5*c.db,0)/1.5)
    eq(rr['ep_bolt_shear'].resistance,grip*(.45 if threads else .56)*830*ab/1.35)
    eq(c.dn,c.dh+(0 if drilled else 2.))
    eq(a['plate_blocks'][0]['Anv'],(40-.5*c.dn)*80.)

@pytest.mark.parametrize('side',[-1,0,1])
def test_exact_central_maximum_spacing_from_input_decimals(side):
    pb=math.nextafter(86.4,-math.inf) if side<0 else math.nextafter(86.4,math.inf) if side>0 else 86.4
    r=evaluate(replace(BASE,pb=pb))
    details=[i for i in r.issues if i.severity=='noncompliance' and 'Espaçamento máximo' in i.text]
    assert bool(details)==(side<0)

def test_inactive_legacy_and_stiffener_inputs_do_not_change_mre_mechanics():
    c=replace(BASE,n=999,pitch=-100.,overhang=-100.,weld=-100.,reinforced_edge=False,
        stiffener_steel='UNUSED',stiffener_t=-10.,stiffener_length=-10.,stiffener_clip=-10.,
        stiffener_landing=-10.,stiffener_weld='fillet',stiffener_electrode='UNUSED',
        stiffener_compatible=False,stiffener_clearance=False)
    a,b=evaluate(BASE),evaluate(c)
    assert a.status==b.status and a.actual==b.actual and a.geometry==b.geometry and a.issues==b.issues
    assert c.count==12 and c.rows==BASE.rows
