# Abertura direta pelo catálogo · 0.9.71

## Correção do fluxo observado

Na 0.9.70, o botão **Conferir escopo** de um cartão alterava somente o candidato no topo do catálogo. O formulário continuava na família anterior até acionar o segundo botão de abertura. Esse comportamento foi reproduzido com o cartão Console enrijecido: candidato Console, seletor e formulário Single plate. O usuário esperava que a escolha no cartão abrisse a ligação abaixo.

Na 0.9.71, **clicar na foto ou em Abrir ligação abre diretamente a família do cartão**. O painel é recolhido e o formulário nativo permanece abaixo dele. O cartão da família já ativa oferece **Ver ligação atual**, que recolhe o catálogo sem carregar outro projeto. **Ver escopo e limites** abre somente uma consulta informativa; não muda a família nem as entradas.

A lista do passo 3 ainda prepara uma escolha e indica isso explicitamente. O botão **Abrir ligação selecionada** efetiva essa escolha. O seletor direto da barra lateral, a ordem e as 26 rotas nativas permanecem disponíveis. **Voltar ao catálogo** reabre o painel mantendo a família e o projeto atuais.

## Imagem clicável e estado

A foto é o próprio conteúdo de um botão HTML nativo, com nome acessível, foco visível e ativação por teclado. O componente local não usa links de navegação, query strings de roteamento, nova página, reload, CDN ou imagens externas. Ele envia somente a identidade da família e uma sequência de evento ao Streamlit. O callback é executado antes da criação dos widgets do formulário.

O servidor confere a família correspondente à foto, o formato do evento, sua sequência e os quatro filtros atuais antes de encaminhar a abertura ao dispatcher existente. Eventos inválidos, repetidos ou de uma família fora dos filtros não abrem outra rota. O estado novo fica em chaves `nav_guide_*`; a abertura explícita pode atualizar o seletor existente `connection_family`.

Os formulários continuam renderizados com o catálogo aberto ou fechado. A abertura usa o comportamento nativo de cada família, sem importador global, alteração de schemas ou carregamento de presets das fotos. As 26 imagens ilustrativas permanecem exatamente iguais às da .70; os desenhos e resultados atuais continuam vinculados ao projeto real. Os motores, renderers, tema marinho e modelos estruturais não foram alterados.

## Verificação e limite

A reprodução da .70 e a correção são verificadas por cliques reais em botões no AppTest. O evento da foto é verificado pelo protocolo real de widget/componente do Streamlit, além de testes do JavaScript local e da estrutura acessível do botão. Essa evidência não substitui um clique real em navegador: o ambiente continua com a restrição de socket anteriormente identificada. Não são alegadas captura Chromium, conferência visual responsiva ou operação do aplicativo publicado do usuário.
