# Sugestões opcionais R016 · revisão 0.9.72

## Objetivo e limite

A busca auxilia a comparar detalhamentos usando exclusivamente o avaliador R016 existente. Não altera equações, coeficientes, materiais, fatores, modelo de forças ou domínio técnico. Nenhum código ou ativo do Osdag foi incorporado; aproveita-se apenas a ideia de enumerar candidatos e explicar a escolha.

Esta implementação trabalha com o **gabarito atual do formulário**, que deve corresponder exatamente a um destes conjuntos (aba da viga, aba do apoio, espessura, gabarito da viga, gabarito do apoio), em mm:

- 76; 76; 6,4; 45; 45
- 102; 102; 8; 65; 65

Não muda automaticamente de um conjunto para o outro. Para estudar o outro gabarito, informe-o conscientemente nos campos nativos, confira seu raio e demais condições reais e faça nova busca. Cantoneiras Gerdau com dimensões 76,2/6,35 ou 101,6/7,94 não são arredondadas para esses conjuntos. Não se toma emprestada sua massa comercial.

A família continua sendo R016, com ambas as interfaces parafusadas, alma de viga W sem recortes e mesa de pilar W, V estático e N=M=T=0. R015, soldas, abas estendidas e ampliações de modelo não participam desta busca. As pendências dessas outras soluções não são contornadas.

## Conjunto pesquisado e critério

O conjunto inclui o projeto atual e 76 padrões: diâmetros métricos 16, 20, 24 e 30 mm, de 2 a 20 linhas iguais em cada interface. Para cada diâmetro são usados os pares borda/passo industriais já presentes no módulo: 35/50, 40/60, 50/75 e 60/90 mm. O comprimento é 2e+(n−1)p. O furo físico proposto é explicitamente o valor `HOLES[db]` já usado pelo avaliador. Alterações de diâmetro e de furo são mostradas separadamente.

Projetos idênticos não são contados duas vezes. O original pode ter outra disposição ou diâmetro já admitido pelo avaliador e permanece incluído com seus valores exatos. Assim, o conjunto contém no máximo 77 candidatos distintos.

A ordenação é: menor comprimento no mesmo gabarito, depois menor número total de parafusos (linhas na alma + duas vezes linhas por cantoneira no apoio), menor diâmetro e desempate determinístico. É comparação dentro de uma busca finita, não ótimo global. Não calcula massa comercial, custo de fabricação ou disponibilidade de estoque.

A posição do topo da cantoneira, as extremidades reais do pilar, perfis, aços, classe dos parafusos, ações e seus sinais, raio, fonte/identidade de catálogo, folga, exposição, ferramenta, broca e condição de rosca permanecem os do projeto atual. Quando os furos mudam, as distâncias do primeiro/último furo às extremidades reais do pilar são derivadas novamente. Conservar os números antigos dessas distâncias moveria ficticiamente o pilar; isso não é feito.

Diâmetro novo não confirma disponibilidade, acesso real, broca ou exclusão de rosca. Essas condições continuam sendo declarações do responsável a conferir no detalhe a fabricar.

## Bloqueios e resultados

A busca não inicia com dados/geometria inválidos, falha numérica, condição fora do domínio, gabarito não documentado, pendência de raio/fonte, engenharia ou acesso. Os bloqueios são conferidos pelas ocorrências e pela completude, além do status principal: uma falha resistente pode coexistir com uma pendência e não a esconde da busca.

Uma falha exclusivamente resistente ou de detalhamento pode motivar a busca, desde que as verificações atuais estejam completas e sem pendência de modelo/acesso. Cada candidato é avaliado integralmente pelo mesmo motor. Só entra na lista aceita se tiver um dos dois estados nativos completos, geometria válida, `global_pass=True`, `complete_checks=True`, registros resistentes não vazios e todos atendidos, sem ocorrência impeditiva. Avisos de desvio do preset industrial permanecem visíveis.

Se não houver candidato, informa-se apenas que nenhum foi integralmente verificado **neste conjunto**. O projeto e seu resultado atual ficam intactos; isso não demonstra inexistência de outra solução. Atendimento local no domínio não aprova o projeto estrutural global.

## Uso, aplicação e conservação

1. Abra o painel **Sugestões de detalhamento R016 · busca opcional** e clique **Buscar sugestões R016**.
2. Escolha uma prévia. Veja as diferenças, os avisos e o índice próprios da proposta. O resultado e o desenho principais continuam correspondendo aos campos atuais.
3. Se desejar, baixe o JSON nativo completo da sugestão sem aplicá-la.
4. Clique **Aplicar sugestão** para transferi-la aos campos editáveis. A busca é executada novamente para revalidar a identidade escolhida, e o projeto/snapshot de entradas devem ser os mesmos usados na busca. Qualquer edição posterior exige nova busca.
5. Após aplicar, os desenhos, resultados, JSON e Word seguem o fluxo nativo. O projeto anterior à aplicação mais recente fica disponível para baixar ou restaurar explicitamente.

Pesquisar, selecionar, voltar ao catálogo e trocar de família não aplicam propostas. Não existe migração de schema nem importador global. Os projetos de sugestão/anterior usam o mesmo formato nativo R016. A busca e a prévia mantêm seu estado separado em `da_suggest_*`; só os callbacks explícitos de aplicar/restaurar chamam a rotina nativa de preenchimento dos campos.

## Evidência e limitações de teste

Os testes independentes enumeram o conjunto por outra implementação, comparam cada solução integralmente com o avaliador nativo e verificam os campos preservados e as extremidades reais do apoio. Os testes AppTest cobrem importação real, seleção, aplicação, restauração, edição desatualizada, ausência de solução e navegação entre famílias. O pacote compacto é conferido novamente depois de extraído.

Não há novo oráculo de resistência: as contas estruturais continuam sendo exatamente as do módulo anterior, cuja regressão é reaplicada. A independência nova é da enumeração/ordenação/conservação e da reprodução dos resultados, não uma nova qualificação normativa. Não foi feito teste visual ou clique físico em navegador, nem publicação, push ou deploy.
