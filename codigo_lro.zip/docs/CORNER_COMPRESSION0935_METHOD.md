# Compressão local do canto soldado 2L T

Esta implementação é um ramo local de compressão axial estática do canto ordinário com duas raízes soldadas, cantoneiras iguais em faces simétricas e soldas longitudinais contínuas no talão e na ponta. Permanecem 19 rotas. O sinal de N escolhe tração ou compressão; não há um segundo seletor de esforço.

## Alcance e responsabilidade

A ligação local inclui chapa, extremidades ligadas das cantoneiras, soldas/substratos, duas raízes, receptores, ligação direta viga–pilar, continuidade e painel. A conclusão não certifica estabilidade global da diagonal, membros ou pórtico, execução, fadiga ou sismo. Compressão 1L e parafusada continua não qualificada. Uma capacidade calculada não confirma uma condição de contorno desconhecida.

O detalhe ordinário de compressão requer três contenções físicas fora do plano: raiz na viga, raiz no pilar e extremidade/traspasse simétrico das 2L. Cada condição tem estado desconhecido, confirmado no detalhe ou ausente. Uma fonte/descrição identifica o recorte livre, raízes efetivas e traspasse atuais. A condição de contenção lateral da alma receptora é independente.

A ação explícita de registrar o detalhe vincula a declaração a um SHA-256 recalculado da geometria física relevante. Mudar polígono, espessura, recorte, raízes, pernas de solda, sobreposição, direção, afastamento ou detalhes físicos da ligação/continuidade expira a declaração. Mudar N, cortes completos, identificação do caso, aços, E, coeficientes, consumível, controles parafusados inativos ou a exceção lateral do receptor não a expira. A geometria é recalculada; não se lê um resultado de aprovação importado.

Não se inventa limite universal para o recorte. Todo recorte é livre. As projeções perpendiculares da faixa completa devem cair nas soldas efetivas e os trajetos ortogonais devem permanecer na chapa real. Essas verificações são necessárias, mas não substituem a declaração do modelo físico ordinário. Uma declaração com hash atual também não supera uma projeção inválida, fluxo de raízes de sinais mistos ou excentricidade real não qualificada.

## Modelo e equações

O modelo geométrico é a coluna equivalente para cantos não compactos do DG29, apêndice C, pp. impressas 374–376. Adota-se K=1 e um comprimento maior que a média das três linhas do guia: o máximo exato em toda a faixa retida. Não se usa K=0,5 nem dispensa por canto compacto.

Na extremidade de início da transferência u0, a envoltória Whitmore a 30 graus tem limites vheel−Lw tan30 e vtoe+Lw tan30. A faixa centrada no eixo nominal v=0 usa h=min(−vleft,vright), largura bw=2h e área A=bw tg. Toda a compressão atua nessa área menor; a largura assimétrica descartada não dá crédito de resistência. Não se conta extensão da largura para um membro receptor. As laterais virtuais não são bordas livres físicas para um limite de placa bw/t.

Para u=(cosφ,sinφ) e v=(−sinφ,cosφ), as projeções nominais nas faces são ubeam=(eb−v cosφ)/sinφ e ucolumn=(ec+v sinφ)/cosφ. A distância é l(v)=max(0,u0−max(ubeam,ucolumn)). Avaliam-se os dois extremos e a troca de face v*=eb cosφ−ec sinφ, se interna. Os três comprimentos convencionais e sua média também são reportados. A extensão livre não conectada antes das soldas não reduz u0.

Le=Lmax, r=tg/√12, Ne=π²EA/(Le/r)² e λ0=√(Afy/Ne). A curva NBR8800:2024/Errata1:2025 5.3 é χ=0,658^(λ0²) até 1,5 e χ=0,877/λ0² acima. Nc,Rd=min(χAfy/γa1,Afy/γa1), com χ=1 por continuidade em Le=0. O modelo equivalente de gusset fornece Aef=A; não se usa o Q da edição antiga nem Ct de tração. Não se multiplica a resistência NBR por um fator LRFD adicional.

A cópia NBR fornecida imprime Le/r≤25 nos dois itens de 6.5.4. A aplicação não altera essa citação e não toma atalho favorável: calcula a curva para todo comprimento positivo. Le/r=200 é uma recomendação da NBR5.3.7, não proibição absoluta. Acima dela, resistência e falhas permanecem calculadas, com qualificação de comportamento em serviço pendente.

Cada L recebe N/2. Sua extremidade continuamente ligada tem verificação de compressão bruta local e limite conservador AL3 b/t≤0,45√(E/fy), com largura nominal completa, sem crédito de raio desconhecido. Acima desse limite a área efetiva local fica pendente; a resistência bruta não aprova a peça esbelta. A verificação não dimensiona o comprimento livre global da diagonal.

Os quatro vetores de solda revertem com N, e as resistências não direcionais usam magnitudes. Mantêm-se os substratos e o envelope conservador de cisalhamento do comprimento uniformemente soldado, sem crédito transversal. Ct, ruptura líquida de tração e o bloco de ponta livre tracionada ficam inativos no caso comprimido. Não se usa abs(N) para transformar os antigos blocos externos da chapa em uma prova de bloco reverso. Contato retido sem bloco destacado é mecanismo inativo, não pendência automática. Tração real produzida por flexão no corpo, continuidade ou receptor continua verificada.

O UFM conserva todos os sinais. As raízes comprimidas ativam enrugamento dos receptores; as rupturas normais apenas tracionadas são filtradas pelo sinal. As forças de J, L, mesas, alma, continuidade, uniões de pegadas receptoras e painel são recalculadas no mesmo caso completo. Um limite concorrente superior conservador do receptor que excede a resistência permanece FAIL; ele não prova isoladamente escoamento físico pontual.

## Mínimo de ligação e alteração intencional de compatibilidade

O adendo independente `qualification_corner_compression0935/MINIMUM_FORCE_CLARIFICATION.md` corrige a premissa histórica do contrato: a fonte 0.9.34 aplicava o mínimo apenas ao adaptador parafusado. A NBR6.1.5.2 também exige o mínimo de 45 kN para as ligações soldadas não isentas aqui modeladas.

Agora 0<N<45 kN cria um caso separado +45 kN para 1L/2L-T soldadas. −45<N<0 cria um caso −45 kN no novo ramo soldado 2L-T. Em N=0, o caso real permanece zero e adota-se +45 kN nominal no sentido +u em tração; esse sentido é uma convenção explícita, não determinação da cláusula. 1L/parafusada comprimida continua fora do escopo.

D/U e as demais ações reais não mudam. O caso sintético as mantém como fundo explícito, recalcula a cadeia completa e deriva outro corte L, sem chamá-lo de Robot. O mínimo é aplicado ao total antes da divisão entre cantoneiras. Não há aplicação automática da recomendação de 50% da resistência do membro.

As exceções intencionais de paridade são os antigos diagnósticos N<0 de 2L-T soldadas e as entradas soldadas de baixa força/zero abrangidas por essa correção. Positivos ≥45 kN e adaptadores não afetados mantêm resultados completos após normalizar somente a versão. O arquivo nativo positivo/zero sem declaração omite o grupo inativo para preservar os estados históricos. Arquivos atuais comprimidos exigem os cinco campos completos; grupos parciais são rejeitados atomicamente. Arquivos históricos aceitos importam as contenções como desconhecidas.

## Testemunhos e evidência

CC1 usa N=−100 kN, chapa 600×600×12 mm e os cortes completos originais. bw=298,234118 mm, Lmax=429,029131 mm, Le/r=123,850042, λ0=1,393802671, χ=0,443475885 e Nc,Rd=360,708108 kN. A chapa comprimida tem η=0,277232471, mas o limite concorrente superior do receptor é 1,018850579: FAIL local, com método completo no detalhe declarado.

CC2 muda somente N para −50 kN, mantendo geometria e D/U. O receptor tem η=0,848249209 e a ligação atende no alcance local declarado. CC3 mantém −100 kN, altera a chapa para 6 mm e declara esse detalhe adverso: a chapa tem η=2,178748408, o receptor ainda falha e Le/r=247,700084 mantém a qualificação de serviço pendente. Não é uma proposta de fabricação.

Contrato, entrada, oráculo e adendo permanecem congelados em `qualification_corner_compression0935/`. São evidência de testes, nunca dados de resistência em produção. Os exemplos nativos ficam em `examples/corner_compression0935/`. O exemplo publicado DG295.1 reproduz KL/r=16,904816 e 940,5 kips usando a área comprimida impressa 20,9 in²; preserva-se a divergência com a área tracionada 21,5 in², sem calibrar geometria para escondê-la.

Ver a validação e o delta desta versão para números efetivamente executados e bloqueios residuais. Fonte de desenvolvimento; nenhuma aprovação de fabricação, implantação ou publicação é inferida desses testes.
