# Casas decimais na apresentação — 0.9.38

Esta revisão altera somente a apresentação. São mantidas as 19 rotas e os métodos de engenharia de 0.9.37. Não acrescenta o ramo de compressão 1L nem altera geometria, recortes, apoios ou mecanismos resistentes.

## Contrato

- Campos numéricos reais usam duas casas na tela. A formatação do Streamlit não arredonda o valor guardado. Contagens permanecem inteiras.
- Resultados, tabelas, legendas dos croquis e memórias novas usam no máximo duas casas decimais. Solicitações explícitas de zero ou uma casa podem continuar compactas.
- Grandezas não nulas abaixo da resolução decimal e valores muito grandes são mostrados em notação científica, com duas casas na mantissa. Não são apresentados como zero.
- Tabelas mantêm dados numéricos separados do texto de cada célula, inclusive para ordenação numérica. Vistas diagnósticas recebem uma cópia de apresentação.
- Uma utilização real superior a um continua não atendida, mesmo que o texto arredondado seja `1,00`. Escolha do governante, empates, comparações e conclusões usam os valores originais.
- Substituições numéricas geradas pelo motor são formatadas somente na fronteira de saída. Fórmulas simbólicas, constantes exatas, referências normativas, nomes de catálogo, identificadores, versões e hashes são preservados. Diagnósticos de importação rejeitada conservam o literal recebido, para distinguir um valor fora do catálogo de outro que apenas aparenta ser igual após arredondamento.
- JSON nativo, exportações numéricas, Robot, oráculos e registros históricos não são arredondados. Os arquivos históricos anteriores permanecem evidência da versão em que foram produzidos.

## Separação técnica

`lro/display_precision.py` concentra as funções de apresentação. `number_input` apenas escolhe o formato visual; `display_frame` conserva os valores numéricos em um DataFrame copiado e define separadamente as cadeias de apresentação. `display_tree` serve às vistas diagnósticas e não é usado por motores, assinaturas ou exportações de cálculo.

Coordenadas físicas de SVG e dados dos artistas do desenho mantêm sua precisão anterior. O tamanho das legendas pode mudar e deslocar exclusivamente elementos de anotação.

## Validação

Os recibos desta revisão distinguem os testes de formatação, a suíte integral, a comparação independente de motores/JSON e a revisão visual de arquivos. Resultados de execução durante edição não constituem o resultado final. O oráculo externo histórico ausente continua ausente e não será contado como aprovado.
