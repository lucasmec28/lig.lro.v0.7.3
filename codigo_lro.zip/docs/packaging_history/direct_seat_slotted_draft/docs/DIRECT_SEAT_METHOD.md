# Viga sobre viga — apoio direto entre mesas

Revisão restrita em cópia da base 0.9.44. Esta família tem esquema próprio e não
converte projetos antigos de chapa de apoio. Os módulos e resultados legados
permanecem preservados. Não há chapa intermediária nem solda sob a viga superior.

## Modelo de gravidade

W360×39 ortogonal sobre W410×38,8. A extremidade física da W360 está em x=+70 mm;
x segue a W360, y segue a W410. A alma superior está em y=0. A mesa inferior da
W360 se apoia diretamente na mesa superior da W410. O par de enrijecedores da
W410 está no mesmo plano y=0, sob sua mesa, com extremidades ajustadas e ligação
à alma e às mesas conforme o ramo de detalhamento adotado.

O caminho nominal é alma W360 → mesa inferior W360 → mesa superior W410 → alma
e enrijecedores W410. Não se cria pressão uniforme sobre o retângulo dos furos.
Os furos e as arruelas ficam fora da faixa comprimida alinhada. A projeção de
6,8 mm entre a ponta do enrijecedor e a borda da mesa não recebe automaticamente
uma carga ou um momento; não se acrescenta verificação sem esse caminho de força.

O usuário removeu expressamente a chapa soldada. Sua flexão, solda e espessura
não são pendências desta família. A Figura A1(c) do ASI DG6 é referência de
tipologia, conforme inspeção comunicada pelo revisor do pai. A figura é elevação,
não define planta, número total de parafusos ou um limite de duas posições.
A presença de quatro parafusos não invalida o modelo de gravidade por si só.

V=2610 kgf ELU=25595,3565 N; N=My=Tz=0; reação centrada. A conversão aplica
somente 9,80665. O mínimo resistente NBR de 45 kN é caso separado, na direção
vertical descendente. As resistências e coeficientes são NBR; não se importam
coeficientes AS4100, tabelas ou rotinas proprietárias ASI.

Somente V positivo, N=My=Tz=0 e eixo alinhado entram neste ramo. Valores fora do
domínio são conservados como entradas e produzem estado fora do escopo, sem
substituição silenciosa por zero. V não é corte dos quatro parafusos verticais.

## Detalhe nominal proposto

Malha de quatro M16: x=±35/y=±40 mm; passo70/gabarito80. W360: oblongos18×40
longitudinais x na mesa inferior. W410: circulares18 na mesa superior. O oblongo
fica em somente uma peça por interface. A orientação relativamente à força
horizontal deve ser revista quando se introduzir ação no plano; este ramo tem N=0.

NBR Tabelas14–17: centros70/80 ≥2,7db=43,2; folgas entre furos30/62 ≥db=16;
W360 centro até fim35 ≥34, até borda lateral24 ≥22; W410 centro até borda35 ≥22.
Margens de 1 e 2 mm na W360 devem ser garantidas na fabricação. A posição em
relação às extremidades físicas da W410 deve respeitar o mínimo de22 mm; não é
deduzida do comprimento ilimitado desenhado em planta.

Geometria nominal: W360 d353/bf128/tw6,5/tf10,7; W410 d399/bf140/tw6,4/tf8,8.
Catálogo Gerdau rev09/2017: W360 h332/d′308; W410 h381/d′357. O raio nominal
inferido é (h−d′)/2=12 mm. O catálogo chama h a distância entre faces internas e
d′ a distância entre tangências. O raio medido das peças pode diferir.

Tangências nominais: superior |y|=15,25; inferior |x|=15,20 mm. Limite conservador
para raio externo de ferramenta mais folga:24,75 mm acima e19,80 mm abaixo.
A proposta raio17+folga2 cabe nominalmente abaixo com0,80 mm de margem.
Enrijecedor inferior8 mm ocupa y=±4; furos inferiores chegam a |y|=31, deixando
27 mm até essa face. Arruela inferior Ø33 deixa19,5 mm em y até o enrijecedor e
3,30 mm em x até a tangência inferior, antes das soldas e tolerâncias.

Uma chapa-arruela60×36×8, com furo padrão18, cobre cada oblongo na posição inicial.
Na posição(+35,+40) ocupa x=5…65/y=22…58: sobra10 mm longitudinal e9 mm lateral
ao rasgo; está5 mm antes da ponta da W360 e6 mm antes da borda lateral. É arruela
externa de cobertura, não chapa intermediária de apoio. A Tabela15 exige peça de
aço estrutural com pelo menos8 mm e cobertura integral; essa dimensão mínima não
dimensiona ações de retenção inexistentes no caso de gravidade.

## Ajuste e condições obrigatórias

Contato ajustado dos enrijecedores é requisito do detalhe a executar, não atestado
de condição existente. A pressão de contato de NBR6.6.2 pressupõe superfícies
usinadas/extremidades ajustadas e área efetiva após recortes; o ramo de6.6.3 para
superfícies não usinadas não pode ser satisfeito fingindo preparação existente.
As faces de apoio direto devem ter preparação compatível especificada e conferida.

Proposta de cada enrijecedor:8×60, altura nominal381,4, recorte20 a ajustar ao raio
real. Largura disponível66,8; a ponta fica em |x|=63,2. No modelo de recorte desde
a face da alma, o início do ajuste fica em |x|=23,2; o raio nominal ocupa cerca de
12 mm, restando8 mm planos. Não chamar o recorte20 de vão físico simplesmente
apoiado. Área de extremidade ajustada proposta320 mm² por peça.

No ramo de enrijecedor integral ligado às duas mesas, a seção comprimida NBR5.7.9.4
é o par mais faixa de alma12tw no pior caso de extremidade, com comprimento0,75h.
O eixo de flexão está no plano médio da alma W410. Aço mínimo comum conservador
e critérios5.3 são explícitos. Isso não importa o0,7d1 condicional do ASI.

A revisão independente identificou uma distinção adicional: os 328,35 kN usam
Ag e Iy da seção idealizada do corpo intacto. O esmagamento desconta os recortes,
mas o cálculo de estabilidade ainda precisa fundamentar o tratamento da variação
local da seção nos alívios20×20. Esse resultado não é resistência verificada da
barra real. Os limites das almas originais são resultados separados e não resolvem
automaticamente essa idealização. A pendência aparece antes do resultado na tela.

## Movimento e limites

Ligação simples real pode transmitir momento local; não se exige rótula ideal
sem atrito para a tipologia. O detalhe deve permitir a rotação prevista e não
impedir o deslocamento longitudinal requerido. Aperto/arruela/retentores devem
ser escolhidos de modo compatível; protensão não é evidência de apoio deslizante.

Para shaft16 em slot40, o curso geométrico bruto centrado é±12 mm. Para a arruela
fixa60, cobertura integral limita |Δx| a10 mm antes de reservas. Para a arruela
do parafuso em x=+35 permanecer inteiramente apoiada na ponta móvel x=70+Δx,
é necessário Δx≥−5 mm. Portanto o intervalo geométrico conservador deste detalhe
é−5…+10 mm, antes de tolerâncias; não é demanda nem curso útil validado.

Esse é o ponto concreto que permanece para o detalhe deslizante: comparar o curso
exigido com a cobertura e a ponta móvel, incluindo reservas reais, e escolher o
aperto compatível com a rotação. Nenhum curso ou ângulo de demanda foi inventado.
O campo escalar de curso desta revisão verifica uma magnitude simétrica nos dois
sentidos. Um requisito assimétrico deve ser comparado ao intervalo geométrico por
sentido; não interpretar uma magnitude positiva como movimento apenas para +x.
Não se resolvem Ti/prying por ausência de momento global. A rotina de gravidade
não autoriza retenção sob tração, ação horizontal, inversão, fadiga ou outro regime.

Os resultados locais condicionais e os testes de código não são aprovação da
ligação completa, das vigas globais, da fabricação ou montagem.
