# LRO Ligações 0.9.44-beam-on-beam-partial-dev

Nova família de viga sobre viga com chapa única contínua: viga W superior soldada à chapa, quatro parafusos à mesa superior da viga W inferior e par inferior de enrijecedores. São 22 famílias; as 21 anteriores mantêm sua ordem e seus métodos.

O módulo calcula verificações locais parciais: corte horizontal N/4 no grupo simétrico, contato nos furos de cada peça, parcela horizontal da solda e seus metais-base, e requisitos de geometria. Trações externas totais, incluindo alavanca, só permitem verificar tração/interação após declarar o mesmo caso e conferir equilíbrio. V descendente segue por contato; o momento de transporte N×(d/2+tp) permanece explícito. Referências e demandas ausentes nunca se tornam zero.

Contato/flexão fora do plano, transferência completa das soldas, seções/caminhos da chapa, regiões locais das vigas, resistência dos enrijecedores e mínimo normativo continuam delimitados como pendências. Não há aprovação automática da ligação completa, fabricação ou montagem. Estabilidade global é escopo separado do projeto. O exemplo inicial usa as ações simultâneas informadas sem novos coeficientes de ações: V=2610 kgf e N=1000 kgf, sendo N uma hipótese de reserva, não o esforço real do Robot.

Interface, croquis e Word separam resistência, geometria e modelo. Projeto JSON e cálculos preservam precisão integral; a apresentação usa duas casas decimais. Consulte docs/BEAM_ON_BEAM_METHOD.md. A ausência histórica do oráculo externo bolt_bearing_oracle.json permanece explícita, sem substituição, skip ou aprovação inventada. Não há nova qualificação das outras famílias nem importação automática de JSON.

## Histórico preservado

# LRO Ligações 0.9.43-welded-support-angles-dev

Duas famílias novas: uma ou duas cantoneiras soldadas à mesa contínua de pilar W e parafusadas à alma da viga, para V estático descendente. As topologias, cortes de parafuso, distribuição resistente e procedimento de montagem são próprios de cada família. A ligação 2L exige sustentação temporária até concluir a solda de campo e os parafusos; o estado intermediário não recebe aprovação.

Os dezenove caminhos anteriores, os índices separados de end plate e o domínio limitado da chapa receptora 0.9.42 são preservados. Não há nova qualificação para single plate, cortante rotulado ou importação automática de JSON. Geometria de catálogo não aprova o método; materiais permanecem independentes. Cálculos e JSON mantêm precisão integral e a apresentação usa duas casas decimais.

Métodos e limites: docs/WELDED_SUPPORT_SINGLE_ANGLE0943.md e docs/WELDED_SUPPORT_DOUBLE_ANGLE0943.md. Validação dos bytes finais: docs/VALIDATION0943.json. O oráculo externo original bolt_bearing_oracle.json continua ausente e sua falha é explicitada, sem substituição, skip ou aprovação inventada. Resultados locais não aprovam fabricação, o projeto real ou o sistema estrutural completo.

## Histórico preservado

# LRO Ligações 0.9.42-result-indices-base-key-plate-dev

Dois incrementos locais sobre a versão entregue 0.9.41:

- End plate: utilização resistente separada das condições do método, geometria/detalhamento e escopo na interface, croqui, Word e bloco aditivo do JSON nativo. As equações, decisões existentes e valores nativos anteriores não mudam por esta apresentação.
- Placa de base com chave: verificação limitada de escoamento à flexão da chapa receptora no domínio declarado, baseada no modelo de faixa de AISC DG1. UI e Word incluem a necessidade adicional de espessura; a transferência completa, furos e metais-base permanecem pendentes.

O ramo rotulado com V/N continua com qualificação incompleta. Nenhum método de cortante rotulado novo entrou neste pacote. Resultados numéricos locais não aprovam fabricação nem o sistema estrutural completo. Precisão integral nos cálculos e JSON; apresentação com até duas casas decimais.

Métodos e limites: docs/RESULT_INDICES0942.md e docs/BASE_KEY_PLATE0942_METHOD.md. Validação composta e limitação histórica: docs/VALIDATION0942.json. A ausência do oráculo externo original bolt_bearing_oracle.json permanece uma falha explícita, sem substituição, skip ou aprovação inventada.

## Histórico preservado

# LRO Ligações 0.9.41-mre12-end-plate-dev

End plate engastada agora permite escolher “12 parafusos sem nervuras · MRE1/2”.
Seis linhas reais, seis parafusos ativos à tração e seis do lado comprimido
recebendo V. N/M/V assinados no domínio qualificado; chapa e perfis com aços
independentes. Permanecem as 19 famílias e as rotas 4E/4ES/8ES anteriores.

A classificação de chapa espessa na demanda e o diagnóstico nominal sem prying
até Mnp são distintos. A falha nominal isolada não cria gate redundante. O
exemplo positivo é numérico local e exige confirmação das condições físicas,
CJP e análise global. Não há aprovação de fabricação ou qualificação sísmica.

Método, limites e reprodução: docs/END_PLATE_MRE12_0941.md. Validação final:
docs/VALIDATION0941.json e .md. Agregado final: 5.949 casos, 5.948 aprovados, uma falha histórica por oráculo ausente; zero erros/pulados. Projetos antigos são recalculados, sem herdar
aprovação salva; a correção 4E de 0.9.40 foi preservada. Nativos e cálculo mantêm
precisão integral, apresentação com até duas casas decimais.

## Histórico preservado

# LRO Ligações 0.9.40-4e-column-demand-dev

Quatro alterações locais desde a última versão entregue, 0.9.38, nas mesmas 19 rotas:

- Chapa de nó: primeiro corte externo perpendicular ao eixo da diagonal, com distância própria após o último parafuso físico ou término da solda. O polígono real alimenta croqui, seções, ruptura e memória, preservando raízes e fixações completas.
- Ligação 18 interna: correção do falso alerta global de colisão. A aleta interna perfurada e o acesso real de montagem continuam com qualificação pendente. O teto necessário de contato pode reprovar; não aprova sozinho o método completo.
- Emenda W convencional: opção de retirar as talas internas das mesas, mantendo o caminho resistente e a excentricidade físicos. O exemplo adverso obrigatório continua reprovado.
- End plate 4E: escoamento local da alma do pilar passa a usar max(Ff;Fc) e enrugamento usa Fc, conforme o caminho das forças de mesa. Capacidades NBR, resultantes dos parafusos/contato e demais estados-limite permanecem. A correção pode aumentar ou diminuir a demanda; não é prova de insuficiência de uma ligação real.

A 0.9.39 foi somente um checkpoint interno, nunca entregue. O histórico abaixo é preservado como tal. Projetos anteriores são recalculados, sem reaproveitar aprovação salva. Entrada, cálculos e JSON mantêm precisão integral; a apresentação continua com até duas casas decimais. Não há segundo afunilamento, nova topologia de end plate, K novo ou liberação de compressão 1L.

Métodos: docs/OUTER_GUSSET_END0939_METHOD.md, docs/W_SPLICE_OPTIONAL_INNER.md, docs/qualification_internal_bolt_alert0939/ e docs/END_PLATE_4E_COLUMN_DEMAND_CORRECTION.md. Validação: docs/VALIDATION0940.json e .md. Suíte integral nos bytes finais: 5.823 casos distintos, 5.822 aprovados, uma falha histórica por oráculo ausente, zero erros/pulados. A falha histórica por oráculo externo de contato ausente permanece explícita. Aceitação de fonte e pacote não aprova fabricação ou o sistema estrutural completo.

## Histórico interno preservado

# LRO Ligações 0.9.39-connection-details-dev

Checkpoint interno não entregue. A sucessora 0.9.40 receberá a correção revisada do caminho de demandas da alma do pilar no 4E antes do empacotamento e da decisão de entrega. Esta versão é uma base imutável de rastreabilidade.

Três alterações locais, nas mesmas 19 rotas:

- Corte externo perpendicular ao eixo da diagonal, com distância própria após o último parafuso físico ou término de solda. Um único polígono atual alimenta o croqui, as seções, os caminhos de ruptura e a memória. Raízes completas e suas pegadas são preservadas. A segunda etapa de afunilamento não está implementada.
- Ligação 18 interna: retirada da falsa colisão global entre alma e chapa de cobertura. Geometria real, fixações e resistências já existentes continuam verificadas. O teto necessário de contato na chapa de aleta pode reprovar, mas não converte um método incompleto em aprovação.
- Emenda W convencional: opção “Considerar talas internas nas mesas”. Desligada, mantém apenas as talas externas nas mesas, usa uma interface resistente por mesa e preserva a excentricidade real. O exemplo obrigatório continua falhando com utilização maior que um.

O modo original continua padrão; projetos antigos não recebem cortes ou talas diferentes por importação. Dados nativos e cálculos conservam sua precisão integral. A apresentação mantém a camada de até duas casas decimais de 0.9.38. Compressão 1L, vínculos não comprovados e demais limites existentes não são desbloqueados.

Métodos e limites: docs/OUTER_GUSSET_END0939_METHOD.md, docs/W_SPLICE_OPTIONAL_INNER.md e docs/qualification_internal_bolt_alert0939/. O oráculo externo histórico de contato de parafusos continua ausente; não foi substituído nem contado como aprovado. Validação combinada: docs/VALIDATION0939.json e .md. Uma execução completa nos bytes finais: 5.762 casos distintos, 5.761 aprovados, uma falha histórica pelo oráculo ausente, zero erros/pulados. Esta fonte de desenvolvimento não aprova fabricação ou o projeto estrutural completo.

## Histórico preservado abaixo

Validação 0.9.38: docs/VALIDATION0938.json e .md. Cobertura integral composta: 5591 casos distintos, 5590 aprovados, 1 falha histórica por oráculo externo ausente; zero erros/pulados.

# LRO Ligações 0.9.38-display-precision-dev

Apresentação com até duas casas decimais nos campos, resultados, tabelas, croquis e memórias novas. Valores muito pequenos usam notação científica quando necessário. Os cálculos, comparações de atendimento, coordenadas físicas e dados nativos mantêm a precisão integral. Permanecem as 19 rotas e os mesmos métodos de 0.9.37.

Contrato de apresentação e limites: docs/DISPLAY_PRECISION0938.md. Uma utilização real maior que um continua não atendida mesmo que o texto arredondado pareça 1,00. Nomes de catálogo, referências, versões, hashes, exportações de cálculo e exemplos históricos não são reescritos por esta revisão.

## Histórico preservado abaixo

# LRO Ligações 0.9.37-one-root-compression-dev

Novo ramo de compressão local da ligação soldada 2L-T com uma raiz na mesa W, mantendo as 19 rotas. O sinal de N aciona o modelo DG29 Exemplo 5.4, K = 1,2; condições físicas da raiz/W, continuação da diagonal e receptor são independentes e não vêm preenchidas por padrão. Não exige outro livro ou FEA genérica.

SRC1 conserva a geometria antiga e apenas inverte 200 kN: a seção local continua **falhando com η = 1,079466667**. A resistência de instabilidade da faixa reduzida é 556,476924 kN, condicionada aos vínculos reais ainda desconhecidos. O aplicativo preserva falha e pendência juntas; não fabrica travamentos nem extrai vão lateral das distâncias às extremidades.

N mínimo mantém o sinal em caso separado. UI, JSON nativo, desenho e memória agrupada mostram ações reais, campos necessários, mecanismos inativos e evidência obsoleta. Projetos 0.9.28 continuam importáveis sem ganhar vínculos de compressão. Tração e cantos soldado/parafusado preservam seus cálculos.

Método: docs/ONE_ROOT_COMPRESSION0937_METHOD.md. Fontes e qualificação: docs/qualification0937/. Correção normativa: docs/ERRATA_NBR8800_0937.md. Exemplos novos são locais ou explicitamente sintéticos; nenhum comprova contenção física real. Validação: docs/VALIDATION0937.json e .md. Suíte integral: 5566 casos distintos, 5565 aprovados e 1 falha pelo oráculo externo histórico ausente; zero erros/pulados. Revisões independentes e paridade têm recibos separados. Nenhuma publicação, implantação ou fabricação é autorizada por este checkpoint.

## Histórico preservado abaixo

# LRO Ligações 0.9.36-bolted-corner-compression-dev

Compressão axial estática local da diagonal **2L-T simétrica parafusada**, dentro da mesma família de canto e mantendo19 rotas. O sinal negativo abre as condições necessárias: extremidade por atrito, superfícies Classe A/B, protensão e arruelas reais, continuação carregada das L e contenções físicas documentadas. Campos anteriores de parafuso, material, pega e ferramenta são reutilizados. Não exige comprimento global de diagonal nem FEA genérica.

O BCC1 hipotético reproduz chapa comprimida503,329315kN, estabilidade do intervalo de cada L260,687892kN, deslizamento72,8kN/parafuso e U interno conservador836,842473kN. **A ligação completa não atende:** o receptor comum mantémη1,010114594. O BC1 antigo e os esforços não foram ajustados para fazer passar. O diagnóstico de cap completo não substitui o U de cap zero.

N real−20kN conserva seus cortes e recebe caso sintético separado−45kN; zero real mantém a convenção nominal+45kN. Serviço de deslizamento e corte/contato ELU são separados; 0,70 só se aplica ao ELU normal identificado, sem escalar cortesD/U. Uma qualificação local não certifica estabilidade global, costuras intermediárias, fabricação ou instalação da protensão.

JSON nativo, resumo físico, memória copiável, Word compacto/expandido e desenho atual retêm hardware, sinal e identidade de contenções. A qualificação parafusada exige translação relativa e torção realmente impedidas nas estações; uma marcação ou simetria não cria apoio. Alterações geométricas e de aperto invalidam a declaração. As rotas soldadas e parafusadas positivas anteriores permanecem cobertas por paridade.

Método: `docs/BOLTED_CORNER_COMPRESSION0936_METHOD.md`. Contrato/oráculo/revisão: `docs/qualification_bolted_corner_compression0936/`. Validação final: `docs/VALIDATION0936.json` e `.md`. Suíte integral estável:5.362 casos distintos,5.361 aprovados e1 falha pelo oráculo externo histórico ausente; zero erros/pulados. Exemplos atuais: `examples/bolted_corner_compression0936/`. Sem publicação, push, deploy ou aprovação de fabricação nesta fonte. O oráculo externo histórico ausente não foi inventado.

## Histórico preservado abaixo

# LRO Ligações 0.9.35-corner-compression-dev

A família de canto agora verifica **compressão axial estática local de 2L-T simétricas continuamente soldadas**, mantendo as 19 rotas. N<0 escolhe o ramo: faixa Whitmore centrada, coluna equivalente DG29 Apêndice C com K=1 e máximo exato em toda a faixa, curva de compressão NBR8800:2024/Errata1:2025 e três contenções físicas vinculadas ao detalhe atual. Não dimensiona a estabilidade global da diagonal ou do pórtico.

CC1 (−100 kN) mantém a falha no limite concorrente conservador do receptor, η=1,018851, apesar de a chapa comprimida atender com η=0,277232. CC2 (−50 kN, mesmos cortes D/U) atende no alcance local declarado. CC3 (chapa 6 mm) preserva a falha de instabilidade, η=2,178748, e a qualificação de serviço pendente acima da recomendação Le/r=200. O limite superior conservador do receptor não é prova isolada de escoamento físico pontual.

O mínimo de ligação de 45 kN, antes omitido nas rotas de canto soldadas, passa a ser avaliado em caso sintético separado: +45 para pequena tração soldada 1L/2L-T, −45 para pequena compressão soldada 2L-T e +45 nominal em tração quando N real é zero. Os cortes e esforços reais não mudam. A convenção de zero é explicitamente adotada, não um sentido imposto pela norma. Esses casos e os antigos diagnósticos negativos de 2L-T são exceções de compatibilidade documentadas; não se afirma paridade total indiscriminada.

Compressão 1L e parafusada permanece não qualificada. Soldas, raízes, receptores comprimidos, continuidade, painel e cortes completos mantêm seus sinais e verificações. Não há novo seletor de esforço, exigência genérica de FEA, K=0,5 automático nem limite universal inventado para o recorte. Geometria alterada não herda a declaração antiga de contenção.

Método: `docs/CORNER_COMPRESSION0935_METHOD.md`. Evidência congelada e esclarecimento do mínimo: `docs/qualification_corner_compression0935/`. Exemplos: `examples/corner_compression0935/`. Validação: `docs/VALIDATION0935.json` e `.md`. Foram executados 5.270 casos distintos: 5.269 aprovados e um teste indisponível por falta do oráculo externo histórico. Os 115 testes afetados e o replay de 22 saídas foram repetidos nos bytes finais, com a única alteração de rodapé documentada e sem somar contagens sobrepostas. Esta é fonte de desenvolvimento, sem autorização de fabricação ou estabilidade global.

## Histórico preservado abaixo

# LRO Ligações 0.9.34-bolted-corner-dev

A família de canto no eixo forte permite **1L ou 2L-T parafusadas**, além das duas disposições soldadas. Permanecem as 19 rotas e os projetos nativos anteriores. Cada parafuso físico tem um plano de corte na 1L e dois no par 2L-T. Uma chapa e suas duas raízes recebem N integral uma vez. O polígono perfurado real, contato por furo, seções líquidas, blocos L/U, Whitmore e nó completo são recalculados.

O BC1 de 300×300×12 mm, quatro M16, L76,2×7,94 e N=100 kN tem utilização governante comum de 0,538530. O bloco da L alcança 0,451115 na 1L e 0,225557 no par. Materiais, roscas, pega, furo/dedução, gramil e dimensões reais de montagem são independentes. O talão demonstrativo dos exemplos é uma hipótese identificada, não um raio publicado ou uma liberação de fabricação.

O caso real COMPLETE_CUTS é preservado. Abaixo de 45 kN em tração, um caso sintético mínimo separado recalcula toda a cadeia com D/U como fundo explícito; ele não representa um corte Robot. Compressão nunca é convertida em tração. O resumo reúne governantes físicos; Word detalhado e JSON guardam todas as primitivas e casos.

A distribuição uniforme fica fora do método qualificado para Lc>950 mm, com resultados locais preservados. A mesma correção de alcance foi aplicada às duas rotas parafusadas anteriores de uma raiz, incluindo 1L, 2L-T e 2L opostas. Seus 17 presets curtos mantêm estado completo idêntico após normalizar somente a versão.

Método e limites: `docs/BOLTED_CORNER0934_METHOD.md`. Qualificação independente: `docs/qualification_bolted_corner0934/`. Exemplos nativos: `examples/bolted_corner0934/`. Validação desta fonte: `docs/VALIDATION0934.json` e `docs/VALIDATION0934.md`. A suíte herdada completa teve 5.198 casos distintos; após as correções documentadas das expectativas de catálogo/rótulo, 5.197 têm resultado aprovado e um teste permanece indisponível por falta do oráculo externo histórico. Esse teste não foi contado como aprovado. Fonte de desenvolvimento; esta etapa não inclui publicação ou implantação.

## Histórico preservado abaixo

# LRO Ligações 0.9.33-single-angle-corner-dev

A família de canto no eixo forte agora contém **1L ou 2L-T soldadas**, mantendo 19 rotas no seletor. Na configuração 1L há uma cantoneira real em uma face e dois filetes longitudinais recebendo N integral; a chapa única, as duas raízes e o nó completo continuam recebendo esse N uma única vez. A face +z ou −z é explícita; materiais de perfil, chapa, viga, pilar e continuidade permanecem independentes.

A adaptação 1L usa a idealização nominal plana estática NBR 8800:2024, 6.1.8.2, com eixo terminal adotado no plano médio da chapa. No C1, o centroide físico fica a 28,1 mm e o momento espacial bruto é 2,81 kN m: são desprezados pela idealização ordinária de extremidade, **não cancelados nem demonstrados resistentes em equilíbrio 3D**. Sem fadiga, sismo, espaçador, ações espaciais independentes, compressão integral da diagonal ou distribuição excêntrica não qualificada.

O C1 usa L76,2×7,94, dois filetes de 5×220 mm e N=100 kN. A utilização das verificações modificadas chega a 0,515228; as 77 linhas de mecânica comum mantêm o campo plano da configuração 2L. Os desenhos, projeto/resultados JSON, memória copiável e Word compacto/detalhado mostram a geometria e o alcance efetivos.

Projetos nativos 0.9.32 continuam abrindo como 2L-T. Seus dados, premissas e saídas canônicas são preservados após normalizar apenas a versão; o novo campo de face é omitido nessa configuração. As 18 outras rotas e os exemplos históricos permanecem preservados. A validação de fonte é distinta da extração do pacote, upload ou implantação.

Método: `docs/SINGLE_ANGLE_CORNER0933_METHOD.md`. Qualificação independente: `docs/qualification_single_angle_corner0933/SINGLE_ANGLE_CORNER_CONTRACT.md`. Validação atual: `docs/VALIDATION0933.json`. Exemplos: `examples/single_angle_corner0933/`.

Auditoria atual: `docs/independent_engine0933/replay.py --mode compare` usa NumPy2.5.3 e as expectativas congeladas; `--mode regenerate` usa NumPy2.3.5 para a regeneração exata. O replay histórico em `docs/independent_engine0932/` permanece preservado e vinculado somente aos hashes do runtime0.9.32. Ele não é um comando de validação do aplicativo0.9.33; não se deve ignorar nem alterar sua recusa de hash ao executá-lo contra outra versão.

## Histórico preservado abaixo

# LRO Ligações 0.9.32-corner-gusset-dev

Nova 19ª família: **gusset de canto no eixo forte, com diagonal 2L-T soldada**. A chapa tem duas raízes, na mesa da viga e na mesa do pilar. A viga é diretamente soldada ao pilar, com mesas CJP, alma em filetes e pares de chapas horizontais de continuidade alinhadas às mesas.

Ações concorrentes completas são informadas nos cortes da viga e do pilar superior; o corte inferior é derivado. O motor conserva forças e momentos assinados, compressão local real, união de regiões receptoras sobrepostas e a excentricidade individual de cada chapa de continuidade. Geometria, perfis, materiais e soldas são explícitos; centroides e propriedades são derivados. O resumo mostra a verificação governante de cada componente, com detalhe expandido e memória copiável.

Primeiro escopo: par simétrico 2L-T, tração estática, força passando pelo ponto de trabalho dos eixos. Compressão não qualificada do gusset ou deslocamento da linha de força recebe motivo específico. Sem adaptação 1L, cantoneiras opostas, canto parafusado, sismo/fadiga ou aprovação global/fabricação. A ligação de eixo fraco com nervura interna permanece separada e inalterada.

Método: `docs/CORNER_GUSSET0932_METHOD.md`. Qualificação independente: `docs/qualification_corner0932/FULL_JOINT_CONTRACT.md`. Validação atual: `docs/VALIDATION0932.json`. As 18 rotas anteriores, seus motores e seus 144 exemplos JSON permanecem preservados. A fonte só é congelada após aceitação independente; pacote, upload e publicação são etapas separadas.

## Histórico preservado abaixo

# LRO Ligações 0.9.31-opposed-bolted-gusset-dev

A rota parafusada completa acrescenta **2L opostas pelos vértices (><)** às disposições 1L e 2L-T existentes. Permanecem 18 famílias no seletor principal; três disposições físicas dentro da rota parafusada, sem duplicar seletores.

Nas opostas há duas linhas distintas e 2n parafusos físicos em corte simples: seis parafusos para três por L. Cada L recebe N/2; chapa comum, raiz dupla e W recebem N integral. Materiais independentes, cantoneiras Gerdau, inclinação real, acesso de talão/ferramenta, projeto JSON próprio, desenho físico e Word resumido/detalhado acompanham a disposição.

O exemplo prático de chapa300×300×12,5 mm, θ80° e N100kN tem utilização0,421154 no bloco da L,0,387392 na solda da raiz e0,196108 no envelope de blocos parciais. O sinal de tensão nominal no trecho perfurado é diagnóstico; compressão no ligamento real não perfurado e na raiz continua fora do domínio.

Somente tração estática, contato direto, linhas alinhadas iguais e uma raiz na mesa exterior W. Sem compressão, fadiga, canto com duas bordas apoiadas, qualificação global ou liberação de fabricação. O envelope de talão demonstrativo não é dado de catálogo. A revisão de duas talas com nervura interna permanece separada.

Método e fontes: `docs/OPPOSED_BOLTED_GUSSET0931_METHOD.md`. Estado de validação atual: `docs/VALIDATION0931.json`. A aprovação de fonte depende da revisão numérica e de saída independentes; extração e smoke do pacote são gates separados. Sem push, upload ou deploy nesta etapa.

## Histórico preservado abaixo

# LRO Ligações 0.9.30-gusset-variants-dev

Esta rodada acrescenta dois seletores de ligação completa, conservando os dezesseis anteriores: **18 famílias no seletor principal**. A família parafusada completa contém duas configurações físicas, 1L e 2L-T; essas configurações não são contadas novamente como seletores.

- **2L opostas soldadas**: vértices opostos `><`, h=tg derivado, quatro linhas longitudinais distintas. Cada L recebe N/2; uma chapa, dois filetes na raiz e o W recebem N integral. NBR8800:2024/Errata1:2025, 6.1.8.2/6.5.2, idealização estática por L: binários locais superfície–plano médio são idealizados fora, nunca declarados cancelados ou verificados como tensões tridimensionais.
- **1L / 2L-T parafusada completa**: uma linha longitudinal, chapa retangular perfurada, dois filetes na raiz e mesa exterior W. 1L tem um plano por parafuso; 2L-T tem parafusos passantes compartilhados com dois planos. Cada contato, área líquida efetiva, caminho real de bloco, Whitmore, raiz e receptor local são recalculados. As tensões nominais em cortes perfurados são triagens complementares, não campos elásticos exatos ao redor dos furos. O envelope interno real de talão e a ferramenta devem ser informados para concluir a montagem; o raio ausente no catálogo Gerdau não é inventado.

As duas rotas usam θ variável a partir do eixo local +s do W, conservam o momento real da raiz, materiais independentes, as cinquenta identidades qualificadas Gerdau e os formatos nativos anteriores. Arquivos novos têm identidades próprias; componentes parafusados antigos não viram ligações completas ao importar. A força real zero permanece zero; mínimo45kN e recomendação opcional são casos separados, aplicados uma vez antes da partilha.

Limites: somente tração estática, geometrias e materiais aceitos pelas verificações finitas. Sem compressão, fadiga, qualificação global da diagonal/W, raiz na alma, segundo apoio de canto ou opostas parafusadas. Estas últimas exigem modelo independente de duas linhas com corte simples e chapa comum perfurada. Um atendimento local não libera fabricação. O antigo oráculo externo ausente de contato de parafusos continua uma limitação histórica; os novos fixtures têm proveniência própria e não são sua recuperação.

Validação atual: consultar `docs/VALIDATION0930.json` e `docs/VALIDATION0930.md`. Gate de fonte e gate do pacote extraído são distintos. Nenhum push, upload ou deploy faz parte desta etapa.

## Histórico preservado abaixo

# LRO Ligações 0.9.29-load-conventions-dev

## Sinal axial legível e referência dos esforços

Os campos existentes agora mostram **Tração**, **Compressão** ou **Sem axial**, com o aviso de domínio quando necessário. O sinal positivo continua significando compressão nas bases e tração nas demais famílias axiais. Basta editar o campo já existente; nenhum dado precisa ser informado duas vezes.

Uma figura separada, **Convenção positiva dos esforços**, mostra somente as setas aplicáveis a cada uma das 16 famílias, sem valores. Respeita o plano da ligação, a face da emenda, a orientação viga/pilar e a inclinação das cantoneiras. É referência de sinais: não representa o caso digitado nem indica atendimento.

Cálculos, mínimos, unidades, esquemas JSON, restrições de compressão e desenhos/Word dos casos reais permanecem preservados. End plate, bases e emendas W conservam seus sentidos próprios; esforços derivados da raiz não se tornam entradas externas.

Método e limites: `docs/LOAD_CONVENTIONS0929_METHOD.md`. Validação focada: `docs/VALIDATION0929.md` e JSON. Versão de desenvolvimento para revisão técnica, sem publicação, implantação ou aprovação de fabricação.

## Histórico 0.9.28

# LRO Ligações 0.9.28-welded-double-angle-gusset-dev

## Duas cantoneiras em T soldadas à chapa de nó

Nova16ª família: duas L idênticas, uma por face de uma chapa central, talões alinhados e quatro filetes longitudinais. A entrada é N total; cada L recebe N/2, enquanto a chapa única, os dois filetes de raiz e o W recebem a força total com o momento geométrico real. Aços da dupla L/chapa/W e eletrodos das interfaces são independentes.

Tração estática, chapa retangular, apoio na mesa exterior longitudinal e centrada na alma de W laminado. O exemplo100kN atende localmente. Com200kN, os filetes das L e da raiz atendem, mas a chapa comum falha, sem duplicação artificial de capacidade. Gerdau63,5×6,35 com filete5mm exige o detalhe explícito de borda reforçada nas duas faces. Raios não publicados permanecem desconhecidos.

JSON nativo próprio, projeto isolado da rota1L, desenho proporcional com corte T e Word compacto/detalhado recalculados das entradas atuais. As quinze famílias anteriores e seus formatos continuam disponíveis. Cantoneiras opostas pelos vértices `><` ficam para o próximo escopo; não são uma opção2L-T aprovada.

Método, fontes e limites:docs/WELDED_DOUBLE_ANGLE_GUSSET0928_METHOD.md. Validação efetivamente executada:docs/VALIDATION0928.md eJSON. Versão para revisão técnica; não constitui aprovação da estrutura, fabricação, publicação ou implantação.

## Histórico0.9.27

# LRO Ligações 0.9.27-gerdau-angles-dev

## Cantoneiras Gerdau no catálogo e na chapa de nó soldada

50 seções Gerdau com dimensões métricas, área e centroide publicados, identidade própria e aço independente. O seletor prioriza abas a partir de 2½ pol. (63,5 mm exatos); tamanhos menores continuam acessíveis para uso eventual. As duas linhas sem Ag/ec foram retiradas da seleção.

A ligação 1L soldada à chapa de nó recalcula a divisão calcanhar/ponta, excentricidade, Ct, pegada, caminhos da chapa, largura local, soldas e apoio a partir da seção real selecionada. O modelo resistente Gerdau é nominal NBR; raios não publicados permanecem desconhecidos. O detalhe explícito de borda reforçada permite o filete5mm na cantoneira6,35mm e exige a instrução correspondente no desenho/Word. O legado ArcelorMittal conserva sua geometria e seus resultados.

R015/R016/R017 e 1L/2L axial também carregam o catálogo compartilhado, preservam entrada manual e aço, e conservam seus limites mecânicos anteriores. Raios necessários nessas famílias exigem declaração independente, pois não constam da tabela Gerdau.

Método, fontes e compatibilidade: docs/GERDAU_ANGLES0927_METHOD.md. Verificação executada: docs/VALIDATION0927.md. APP e exemplos pré-gerados são entregues em ZIPs independentes; não é preciso juntá-los para usar o aplicativo. Versão de desenvolvimento para revisão técnica, sem publicação ou aprovação de fabricação.

## Histórico 0.9.26

# LRO Ligações 0.9.26-welded-angle-gusset-dev

## Nova família soldada 1L → chapa de nó → mesa W

A 15ª família calcula a rota local completa da cantoneira soldada por uma aba, chapa retangular, solda da raiz e região receptora na mesa W centrada na alma. Tração estática com momento real derivado da geometria, aço independente para L/chapa/W e consumíveis independentes. Viga e pilar conservam o mesmo sistema local.

O ângulo da cantoneira é configurável em relação ao eixo longitudinal da viga ou do pilar receptor. θ não se refere à horizontal global: os eixos locais acompanham o W. Inclinações agudas e obtusas conservam os sinais de força e o momento geométrico; o desenho mostra a referência do ângulo. A geometria informada continua sujeita ao encaixe real e ao domínio tracionado.

Geometria parametrizada com coordenadas reais, caminhos de ruptura, transições nos cantos, seções internas e extremos estacionários; nenhuma aceitação baseada somente na raiz. Catálogo inicial L100×100×12 e 100 registros W identificados. Campos fora do domínio mostram o motivo. A entrada W-web está identificada como rota ainda não qualificada. Sem compressão, fadiga ou ação espacial nesta família.

O exemplo excêntrico75°/100kN atende localmente;200kN reprova. Há também exemplos45° compacto/100kN e45°/135° alinhados ao centro da raiz/45kN, estes com Mlocal≈0.16 modos físicos usuais consolidados, até13 famílias de caminhos no detalhe (famílias geometricamente inativas são identificadas), JSON nativo, desenhos e Word compacto/detalhado. As 14 famílias anteriores permanecem disponíveis e seus motores não foram modificados.

Método e limites: docs/WELDED_ANGLE_GUSSET0926_METHOD.md. Validação: docs/VALIDATION0926.md. Resultado local não certifica o membro global, fabricação ou implantação. Usar um pacote de versão única, preservando app.py, lro/, data/ e requisitos.

## Histórico 0.9.25

# LRO Ligações 0.9.25-independent-plate-steels-dev

## Aços independentes para chapa e nervuras 4ES/8ES

Viga, coluna, chapa de topo e par de nervuras conservam seleções próprias. Na rota CJP ordinária de 4ES/8ES, viga/chapa/nervuras podem combinar A36, A572 Gr.42 e Gr.50, respeitando produto, espessura e desenvolvimento real de cada junta. A igualdade dos nomes de aço deixou de ser uma condição. Permanecem as 14 famílias, a geometria, os grupos de parafusos e os casos completos de entrada/mínimo normativo.

A chapa usa seu próprio fy/fu; a viga e a coluna mantêm suas propriedades. Cada CJP de nervura usa o menor fy dos metais-base e a menor espessura conectada, conforme NBR 6.2.5.1. Uma nervura mais resistente ligada a chapa mais fraca continua podendo falhar, mesmo com chapa mais espessa. Ambas as interfaces devem desenvolver a nervura; não basta liberar o seletor. E7018/485 MPa, procedimento compatível, baixo hidrogênio e preaquecimento pelo grupo de maior resistência permanecem declarados.

Exemplos nativos mistos: examples/end_plate_4es_mixed_steels0925.json e examples/end_plate_8es_mixed_steels0925.json. Método/fontes: docs/INDEPENDENT_PLATE_STEELS0925_METHOD.md. Escopo e resultados efetivamente executados: docs/VALIDATION0925.md. JSON, controles, Word e SVG/PNG identificam os materiais efetivos. Sem novos campos de entrada, nova família, solução de chapa fina, sismo ou reforço de coluna. Revisões de cálculo 4ES/8ES atualizadas; identidade de entradas existente preservada.

Versão de desenvolvimento para revisão técnica; não constitui aprovação de projeto ou publicação.

## Histórico 0.9.24

# LRO Ligações 0.9.24-8es-endplate-dev

## End plate 8ES com 16 parafusos e duas nervuras CJP

Nova variante interna da end plate engastada, mantendo 14 famílias. Oito linhas físicas, oito parafusos ativos à tração por caso e16 totais, com kernels distintos DG39 tabela 5-16/tabela A-5(a). Serviço ordinário estático, coluna contínua sem reforços, CJP compatível e mesmo aço qualificado de viga/chapa/nervuras. Sem solução de chapa fina, alavanca ou sismo.

Exemplo W460×74/W360×122(H), chapa12,7mm e nervuras145×275×9,525mm. Espaçamentos, braços, furos/blocos e transferência da alma refletem as quatro linhas ativas. Mantidas as duas espessuras mínimas do método e os casos completos de Entrada/mínimo normativo. 4E/4ES preservam entradas, resultados, revisão e digest anteriores.

Seleção nativa com rascunhos separados por variante, passo pb compacto, JSON próprio e Word/SVG/PNG recalculados. Fontes, limitações de edição, fórmulas e exemplo: docs/END_PLATE_8ES0924_METHOD.md. Arquivo nativo: examples/end_plate_8es_cjp.json. Versão de desenvolvimento para revisão técnica; não é aprovação de projeto ou publicação.

## Histórico0.9.23

# LRO Ligações 0.9.23-welded-w-splice-dev

## Emenda W soldada CJP para vigas ou pilares

Décima quarta família, mantendo as13 famílias anteriores e a variante4ES. Dois W laminados iguais e alinhados, CJP nas duas mesas e na alma remanescente, com aberturas reais arredondadas de acesso. N/M/V assinados usam o grupo elástico nominal de Fakury e critérios atuais da NBR8800 corrigida. V integral verifica separadamente a alma receptora, incluindo redução fora do plano da solda e transporte de momento.

Geometria padrão curta, materiais/procedimento e declarações de execução explícitos; os exemplos começam com pendências de verificação. A orientação viga/pilar não modifica o cálculo. Não são aprovados picos físicos de tensão nas aberturas, fabricação, sismo ou estabilidade global dos membros. Método e limites completos: docs/WELDED_W_SPLICE0923_METHOD.md.

JSON próprio e atômico, casos reais/mínimos separados, desenho proporcional SVG/PNG e Word canônicos com envelopes e testemunhas. Validação focada, comparações independentes e conservação da versão anterior, sem suíte completa ou publicação.

## Histórico0.9.22

# LRO Ligações 0.9.22-4es-endplate-dev

## End plate 4ES com duas nervuras CJP

Nova variante dentro da família engastada existente, mantendo as 13 famílias. Tabela 5-11 do DG39, oito parafusos e duas nervuras físicas simétricas, com CJP contínua nas interfaces nervura–chapa e nervura–mesa. A rota inicial exige mesmo aço qualificado, hierarquia de espessuras e E7018 compatível. Não inclui filetes de nervura, reforços de coluna ou qualificação sísmica.

O exemplo de catálogo W410×46,1/W310×97,0(H) conserva os materiais NBR e as ações de entrada/mínima separadas. JSON nativo, desenho SVG/PNG e Word compacto/detalhado recalculam as entradas. Os valores antigos 4E foram comparados diretamente com a versão entregue 0.9.21, sem alteração numérica. Método, fontes e limites: docs/END_PLATE_4ES0922_METHOD.md.

Validação focada de motor, callbacks e artefatos, com revisão visual dos desenhos e páginas Word. Sem suíte completa ou publicação. Versão de desenvolvimento para revisão técnica.

## Histórico 0.9.21

# LRO Ligações 0.9.21-axial-single-angle-dev

## Nova ligação axial 1L–chapa retangular parafusada

Décima terceira família, acrescentada ao fim do seletor sem alterar as doze identidades existentes. Uma cantoneira de abas iguais, uma chapa retangular real e um plano de corte. Modelo nominal estático NBR6.1.8.2/6.5.2: as excentricidades físicas em plano e pela espessura são declaradas e omitidas, nunca canceladas. Não aprova carregamento no CG físico, raiz ou apoio externo.

Exemplo L76×6,35, Ag929 mm², chapa100×12,5, 3M16 e N100 kN: bloco da ponta155,457407 kN, η0,643263. A mesma geometria com N200 kN falha (η1,286526). Seções, contato e blocos recebem N integral; a chapa conserva suas capacidades. JSON próprio, resumo físico e Word/SVG/PNG canônicos. Método e procedência: `docs/AXIAL_SINGLE_ANGLE0921_METHOD.md`.

Validação focada; sem suíte completa, navegador ou publicação. Versão de desenvolvimento para revisão técnica.

## Histórico 0.9.20

# LRO Ligações 0.9.20-axial-double-angle-dev

## Nova ligação axial 2L–chapa de nó parafusada

Décima segunda família, acrescentada ao fim do seletor sem alterar as onze rotas existentes. O guia opcional inclui “Barra 2L–chapa de nó” e “Tração axial”. Duas cantoneiras simétricas, uma linha de parafusos compartilhados e uma chapa retangular real, sob tração estática no eixo nominal da ligação. Corte terminal explícito; não aprova raiz, solda ou apoio externo.

Inclui seções, planos individuais de corte, contato, blocos parciais reais, detalhamento, ações real/mínima/recomendada separadas, JSON nativo, resumo físico e Word/SVG/PNG canônicos. Método, fontes e limites: `docs/AXIAL_DOUBLE_ANGLE0920_METHOD.md`. Exemplo moderno inicial N=200kN com chapa100×12,5mm e3M16: escoamento da chapa284,091kN. Raio e envelope de ferramenta são hipóteses editáveis de fabricação.

Validação focada; sem suíte completa, navegador ou publicação. Versão de desenvolvimento para revisão técnica.

## Histórico 0.9.19

# LRO Ligações 0.9.19-guided-selection-dev

## Seleção guiada opcional, somente de catálogo

O seletor direto conserva as onze famílias, nomes e ordem. Um expansor na barra lateral permite buscar por interface, modelo nominal e família; somente o botão **Abrir família** muda a família aberta. Filtros não configuram o projeto nem comprovam rigidez ou capacidade de rotação. Confirme apoio e modelo no formulário nativo.

O guia não lê inputs físicos, rascunhos, snapshots ou resultados. Não há importador global, conversão de interfaces, migração de bases ou mudança nos motores. Projetos, importação, cálculos, desenhos e salvaguardas de exportação continuam sob responsabilidade das famílias existentes. Método de navegação, catálogo e limites: `docs/GUIDED_SELECTION0919.md`.

Validação focada com AppTest real e testes de catálogo, navegação e conservação; sem nova auditoria técnica integral, navegador ou publicação.

## Histórico 0.9.18

# LRO Ligações 0.9.18-drawing-layout-dev

## Correção finita das imagens dinâmicas

Rodada exclusivamente gráfica D1–D7: cotas curtas com referências visíveis, nomes completos com quebra medida, trajetos de líderes, chamada R015 aos dois filetes reais, sentido positivo de M na end plate, legendas de geometrias alongadas, identificadores das bases e pequenas folgas de cabeçalho.

Conservam-se as dimensões físicas, topologia, contagens, forças, sinais, estados, avisos e reavaliação canônica das APIs. Não há novo cálculo, verificação, família, esquema de entrada, importação ou liberação de fabricação. A aceitação reutiliza os 65 casos congelados de 11 famílias existentes; os desenhos continuam ilustrativos e locais.

Validação focada em SVG/PNG e testes diretamente afetados, sem navegador, suíte completa ou revisão global de Word. A folha preserva vistas proporcionais; o espaço de anotação é tratado separadamente da geometria física.

## Histórico 0.9.17

# LRO Ligações 0.9.17-coped-angles-audit-dev

## Correção finita R017: duas cantoneiras e recorte duplo

Última família da sequência de auditoria. Preservam-se as equações resistentes, as duas interfaces parafusadas, os parafusos comuns em corte duplo, uma única alma de apoio, os sinais e as condições externas do recorte. Não há novo modelo nem ampliação do domínio.

Word e SVG/PNG recalculam a entrada atual em cada chamada pública. O quadro R017 usa nomes físicos próprios e 22 envelopes sem perda de linhas, furos, prefixos, casos, governantes, empates ou falhas. O desenho avulso identifica projeto e ações reais V/N/M/T com sinal. A guarda numérica distingue falha derivada de entrada inválida ou sobrecarga finita; a importação não representável é rejeitada atomicamente.

A exceção da nota da Tabela 16 é qualificada somente para a ponta real da viga no caminho reto já implementado, mediante contato vertical e todos os blocos existentes atendidos. A borda horizontal de 25 mm permanece real e entra no bloco; não substitui o ligamento vertical de contato. Outras bordas sem qualificação implementada, caminhos curvos, invalidade física, falhas resistentes e condições externas pendentes continuam bloqueando conforme seu motivo.

A folha industrial R017, página 20, define topologia e R15, mas não possui tabela métrica de e/s. Os valores de preset herdados de R016 são identificados como adotados, sem alteração das dimensões. Fontes, método, limites e contrato finito: `docs/COPED_DOUBLE_ANGLES_AUDIT0917_METHOD.md`.

Cópia de desenvolvimento, sem publicação nem suíte completa. Atendimento local não aprova os membros globais nem dimensiona seus travamentos. Exemplos anteriores permanecem históricos e são recalculados ao abrir.

## Histórico 0.9.16

# LRO Ligações 0.9.16-welded-angles-audit-dev

## Correção R015 soldada e parafusada 0.9.16

Correção finita da família existente R015/LCSP. Permanecem o grupo elástico U excêntrico em equilíbrio, duas cantoneiras reais, uma única alma contínua, furos somente no apoio, sinais, bordas reais e piso de 45 kN uma vez no conjunto. Não foram alteradas equações ou resistências para reduzir linhas.

Toda chamada pública de Word/SVG/PNG reavalia canonicamente a entrada atual, inclusive resultado ausente, antigo, adulterado ou com a mesma entrada. O desenho avulso registra projeto e V/N/M/T reais assinados, separados do domínio do método. Falha numérica é distinta de entrada/geometria inválida, pendência, detalhamento e falha resistente finita; a interface retira elegibilidade de artefatos anteriores antes da conversão.

O resumo contém 22 envelopes físicos em português, com governantes reais/adotados e empates, preservando todos os 59/95 IDs, furos, somas de contato, prefixos, sentidos e equações no desenvolvimento e no Word. A importação comum e o estado de perfis/famílias permanecem fiéis; metadados não representáveis pelos controles são rejeitados atomicamente, com o campo identificado.

O ramo curto de 36 mm permanece sem aprovação por alternativa de método não implementada: NBR 6.2.6.2.3 admite limitação de perna efetiva a 25% do comprimento. Não se declara proibição normativa universal de 40 mm, nem se reduz silenciosamente a perna. O limite 100w também continua sendo limite da implementação.

Fontes R015, P901-23W e Souza reconciliadas com a auditoria fornecida; métodos/coeficientes alternativos não são somados. Ver `docs/WELDED_DOUBLE_ANGLES_AUDIT0916_METHOD.md`. Validação focada, sem suíte completa, próxima família, publicação ou aprovação estrutural de obra. A melhoria de rótulos longos R016 permanece fora desta rodada.

## Histórico 0.9.15

# LRO Ligações 0.9.15-bolted-angles-audit-dev

## Correção R016 parafusada 0.9.15

Correção finita da família existente de duas cantoneiras parafusadas, sem alteração das equações resistentes NBR/Gerdau. Word e SVG/PNG recalculam a entrada atual e não confiam em resultados fornecidos pelo chamador. Importação incompatível com controles é rejeitada integralmente; valores assinados e perfis personalizados permanecem fiéis.

A tela principal resume 21 envelopes físicos, preservando 73 linhas no exemplo e 132 com V=0, os governantes reais/adotados e todos os furos, prefixos e sentidos. Falha numérica, dado inválido, sobrecarga finita, detalhamento e pendências permanecem distintos. O desenho identifica projeto e V/N/M/T reais, separados da restrição do método.

Reconcilia-se a disponibilidade do P901-23W completo, exemplo II.A-1A, sem importar coeficientes americanos ou afirmar leitura da tese Higgins não recuperada. Preservam-se os planos físicos de corte, alma real única, piso45kN, inversão de V, 2,7db exato, caminhos e bordas reais. Método e limites: `docs/BOLTED_DOUBLE_ANGLES_AUDIT0915_METHOD.md`.

Cópia de desenvolvimento: sem publicação, FEA, otimização, nova família ou certificação da suíte completa. A falha antiga de aprovação por resultado obsoleto era na API avulsa; a invalidação na interface normal já funcionava. A espessura de 0,001mm é um ensaio de fronteira, sem falso atendimento ordinário demonstrado.

## Histórico 0.9.14

# LRO Ligações 0.9.14-conventional-splice-audit-dev

## Correção convencional N/M/V 0.9.14

Auditoria finita da família existente de emenda W convencional com oito talas independentes. A mesa do membro usa b=bf/2 e Aef=2 beff tf, conforme NBR 5.1.2.2.4(a), sem duplicar a faixa central. A testemunha W personalizada esbelta agora falha na tela local com resistência 499558,226079196 N e índice 1,000884329188753. Não é um cálculo de Nc,Rd global; as larguras próprias das talas não mudaram.

Importação é fiel e atômica, rascunhos W personalizados/raiz são independentes do catálogo e valores aceitos conservam a precisão de origem durante exibição em kgf. Edição real continua invalidando a base externa; não há tolerância ou vínculo automático. Word e SVG recalculam integralmente a entrada atual e não confiam em resultados fornecidos.

O quadro principal reúne 29 envelopes de componentes/mecanismos no exemplo, conservando as 649 linhas, todos os 84 caminhos por tala de alma e o caso/linha governante completo. Falha numérica, dado inválido, geometria, resistência finita, detalhamento, domínio e N/A são distintos. bo=2bi identifica a especialização atual de partilha igual. Desenhos avulsos incluem projeto e torção informada.

Método e fontes: `docs/CONVENTIONAL_SPLICE_AUDIT0914_METHOD.md`. Preservam-se compressão, sinais de M/V, casos reais/suplementares/pisos separados, estabilidade de tiras independentes, gradiente Vx, perfil W paramétrico e exclusão global/serviço. Não há extensão a talas desiguais, novo FEA obrigatório, filtro por nome W310, caixa fictícia, outra família ou certificação da suíte completa. Esta cópia de desenvolvimento não constitui publicação.

## Histórico 0.9.13

# LRO Ligações 0.9.13-axial-splice-audit-dev

## Correção axial M004 0.9.13

Auditoria finita da família existente de tração axial. Importações incompatíveis com os controles são rejeitadas antes de alterar projeto, resultado ou memória. Perfis W personalizados e seu rascunho independente permanecem disponíveis. Word e SVG recalculam a entrada atual; resultados antigos ou adulterados não autorizam conclusões.

Sem Nc,Rd selecionado, o N real e o piso de 45 kN continuam calculados, com a recomendação pendente: a falha conhecida da alma a 2,25 MN permanece visível. A tela/memória mostram 18 envelopes físicos no exemplo, preservando as 193 linhas e todos os caminhos no detalhe, sem ganho de capacidade. Falha numérica é distinta de entrada inválida e de falha resistente finita. Método e fontes: `docs/AXIAL_SPLICE_AUDIT0913_METHOD.md`.

Esta correção não amplia N>0, M=V=T=0, não recalcula compressão, não qualifica a família convencional N/M/V separada e não representa publicação ou certificação da suíte completa.


Revisão delimitada da quarta família existente, **End plate · engastada**. Entrada e força mínima mantêm casos completos e uma envoltória por mecanismo; uma força mínima favorável não esconde falha real. Gabarito/passos usam 2,7db exato; importações são atômicas, espessura personalizada persiste e a sobra inferior fica visível quando fisicamente ativa. Resultados distinguem resistência, método, detalhamento, falha numérica, extrapolação e escopo incompleto. O CJP não usa uma perna de filete oculta na folga.

Os 23 ramos numéricos permanecem, agrupados em 19 linhas somente pelas três redundâncias demonstradas. W200 conserva a distinção entre extrapolação de altura e região local da alma não representada. Não há novo mecanismo, crédito para parafusos intermediários nem refinamento da capacidade da coluna. A errata DG39 de novembro/2024 continua uma lacuna documental expressa, sem impedir as correções confirmadas. Método/fontes: `docs/MOMENT_END_PLATE_AUDIT0912_METHOD.md`. Exemplos atuais: `examples/Moment_end_plate_audit0912/`. Arquivos de versões anteriores permanecem exemplos históricos; ao abri-los todas as verificações são recalculadas.

## Histórico 0.9.11

Revisão delimitada da terceira família existente, **End plate · rotulada**. Corrige o mínimo de passo/gabarito para 2,7db e os filetes por junta física e borda real, sem trocar valores informados. Violações de detalhamento continuam calculáveis quando a geometria física é viável. Importações não representáveis rejeitam atomicamente; o rascunho de espessura personalizada persiste.

Quatro qualificações locais continuam abertas e aparecem junto à conclusão: hierarquia/momento das soldas da alma, tração dos parafusos por rotação, transferência das soldas/mesas e mecanismo simultâneo N/V, incluindo cortes da chapa, alavanca e contato. Resultados dos componentes não aprovam o nó completo. Falhas resistentes finitas, condições do método, dados ausentes, falha numérica e N/A são distintos. A end plate engastada mantém seu método e resultados. Ver `docs/PINNED_END_PLATE_AUDIT0911_METHOD.md`.

Apenas os escalares dos parafusos e o resumo da alma foram consolidados; todos os 17 ramos numéricos permanecem auditáveis. Há 14 linhas no quadro da rotulada, com derivação dos dois ramos da alma e das capacidades de parafusos. Desenhos mostram sentidos positivos de referência e cargas assinadas. O método da rotulada tem revisão própria, sem rótulo DG39.

## Histórico 0.9.10

Revisão delimitada da segunda família existente, **Alma de coluna · duas talas**: importação fiel e atômica, rascunhos condicionais persistentes e filetes conferidos por quatro juntas físicas. O filete de 3 mm na junta horizontal/mesa de 9,525/10 mm conserva a entrada e acusa mínimo de 5 mm não atendido ao detalhamento, sem inventar sobrecarga resistente.

Conclusões separam resistência finita, falha numérica, detalhamento, extrapolação e escopo incompleto. Os dois limites locais de rotação/flexibilidade e estabilidade/distribuição do conjunto ficam junto ao resultado. Resumos dos parafusos e seções preservam todos os ramos; somente a linha de corte local da coluna provadamente dominada foi removida. Mantêm-se compressão, sinais, mínimo de 45 kN, todos os esquemas e identidades de componentes. Método e limites: `docs/DOUBLE_COVER_AUDIT0910_METHOD.md`.

Reconciliação pontual Single plate: o P901 original foi recuperado e seus exemplos II.A-17B, II.A-19A e II.A-19B foram conferidos. Corrige-se apenas o ramo Bv do bloco L completo da chapa com duas colunas para Cts,V=0,5, mantendo os demais ramos. A pendência documental remanescente é o domínio integral da dispensa automática da Tabela 10-9 do Manual, não o acesso ao PDF nem a existência dos procedimentos N+V/duas colunas/estendidos. Ver `docs/SINGLE_PLATE_AUDIT099_METHOD.md`.

Os arquivos em `examples/Single_plate_audit099/` e a memória `examples/Teste_usuario_enrijecedor_oposto.docx` são snapshots históricos de regressão e podem conter a antiga pendência de acesso ao P901. Novas memórias geradas pela 0.9.10 usam a qualificação atual; veja o README daquela pasta.

Cópia de desenvolvimento: não publica, implanta, certifica os nós completos nem inicia outra família.

## Histórico 0.9.9

Revisão delimitada da família existente **Single plate**. A alma apoiada sem recorte passa a ter uma única envoltória de corte com escoamento, instabilidade e ruptura líquida. O bloco L completo de duas colunas na alma recortada usa Cts,V = 0,5 no ramo correspondente à figura 16(c) da NBR; não se estende essa alteração a todos os caminhos.

Importações e controles condicionais preservam os valores de engenharia. Resistência, condição do método, detalhamento, dados faltantes e mecanismo local não coberto têm conclusões distintas. Os resumos consolidam apenas as seis capacidades escalares da chapa, preservadas no desenvolvimento; caminhos axiais completos sem N aparecem como N/A. Word e desenho identificam os sinais de entrada, furos reais e recortes superior/inferior.

Método, fontes e limites: `docs/SINGLE_PLATE_AUDIT099_METHOD.md`. Não há nova qualificação integral P901, ampliação de famílias, alteração de esquemas JSON ou mudança das versões próprias dos demais componentes. Complemento entre mesas e enrijecedor oposto permanecem disponíveis somente para detalhamento, sem crédito resistente. Esta cópia de desenvolvimento não implica empacotamento, publicação ou implantação.

## Histórico 0.9.8

### LRO Ligações 0.9.8-base-flow-dev (registro histórico)

Revisão limitada do fluxo das bases: cada caminho de cortante exige apenas seus modos aplicáveis; dados de barras tracionadas são compartilhados; a comparação governante do grupo não é repetida. Soldas pilar–placa têm uma seção única, com estática e especificações automáticas e uma referência externa específica quando a compatibilidade de transferência realmente depende dela.

Pendência de dado/modelo é distinguida de falha resistente. A assinatura da evidência externa é separada da atualidade do resultado; registros e comprimentos importados permanecem preservados. Mantêm-se as 11 famílias, versões de componentes, esquemas e equações resistentes dos modelos ativos existentes.

Não acrescenta catálogo de ancoragens, rota tabulada completa, novos modos da placa receptora nem aprovação de fundações. Método, fontes e limites: `docs/BASE_FLOW098_METHOD.md`. Validação desta revisão: `docs/VALIDACAO_BASE098.md`. Os exemplos e registros abaixo preservam sua versão histórica.

Etapa definida na 0.9.8: revisar as ligações existentes em sequência, começando por Single plate, antes de acrescentar outras famílias. A revisão delimitada Single plate está descrita no início deste README.

## Histórico 0.9.7

# LRO Ligações 0.9.7-key-concrete-dev

Novo componente opcional **Concreto da chave retangular única · ACI 318-19 conservador**, nas bases Tipo 1 e Tipo 2. Calcula contato da chave e três superfícies reais/virtuais de ruptura, recortadas no bloco informado. Mantém o estado NBR integral e acrescenta um estado ACI de centroide limitado, sem alterar N/M/V no topo ou as ações prescritas das soldas.

Tipo 1 tem seu modelo uniforme declarado; Tipo 2 preserva C1/C2/T1/T2. Chave profunda não é proibida automaticamente. Restrições reais das barras, preenchimento/respiros, áreas documentadas quando necessárias e validade da topologia são requisitos explícitos do componente opcional. Falhas numéricas não desaparecem por pendências de detalhe/equilíbrio.

UI, desenhos e JSON/Word mostram polígonos, forças por estado, pressões, resíduos e fontes. A memória local pode ser exportada mesmo quando o equilíbrio global Tipo 2 permanece pendente. Permanecem 11 famílias e todos os esquemas/identidades anteriores. Contato NBR, soldas e a memória W final preservados.

Não aprova a chave, placa receptora, ancoragem, bloco armado, fundação ou base completa. Método: `docs/SINGLE_KEY_CONCRETE_COMPONENT.md`; revisão de fontes: `docs/SINGLE_KEY_CONCRETE_SOURCE_REVIEW.md`; evidência integrada: `docs/VALIDACAO_KEY_CONCRETE097.md` e `validation/v097/`. Evidências/exemplos anteriores abaixo conservam as versões históricas corretas.

## Correção do editor de bloco da versão 0.9.6

O defeito confirmado afeta ambas as famílias de base, Tipo 1 engastada e Tipo 2 rotulada. Ao importar/usar um bloco excêntrico, alternar de dimensões para coordenadas e voltar para dimensões, os controles ocultos podiam voltar ao modo centrado. A edição seguinte de uma dimensão podia então recentrar silenciosamente os limites físicos em ambos os eixos.

A versão 0.9.7 conserva os offsets e limites não editados e só centraliza quando essa ação é solicitada explicitamente. Projetos afetados exigem conferir/restaurar os limites reais do bloco, recalcular todas as verificações e reexportar os relatórios; um resultado anterior não fica corrigido apenas por abrir o aplicativo atualizado. Enquanto se usa 0.9.6, o contorno seguro é manter o editor em coordenadas e conferir os quatro limites antes de calcular/exportar. A correção foi testada nas duas famílias com offsets assimétricos, alternância de editor e navegação.

## Histórico 0.9.6

# LRO Ligações 0.9.6-key-weld-dev

Novo componente **Chave de chapa única · dois filetes opostos**, nas bases engastada Tipo 1 e rotulada Tipo 2. Usa as ações prescritas integrais da NBR, inclusive com V aplicado zero, o binário local entre centroides do DG1 e a resistência escalar NBR com fw=485 MPa. A perna/garganta, os dois segmentos físicos, as forças com sinais, a execução vinculada e os limites de domínio aparecem na UI, no JSON, no desenho e na memória Word.

O resultado é somente do metal dos filetes e do detalhamento local. Metal-base junto à fusão, transferência/flexão da placa, concreto da chave e caminho completo continuam separados; não há aprovação da chave ou base completa. Ações da solda não alteram o equilíbrio global já existente.

Permanecem as 11 famílias e todas as identidades de projetos/componentes anteriores, incluindo Emenda W convencional N/M/V da versão 0.9.5. Método e limites: `docs/SINGLE_KEY_WELD_COMPONENT.md`. Validação desta integração: `docs/VALIDACAO_KEY_WELD096.md`. Registros dos exemplos são sintéticos e não qualificam execução real.

## Histórico 0.9.5-nmv-dev

Nova família separada **Emenda W · convencional · N/M/V**, com compressão/tração, momento e cortante assinados, oito talas reais e perfis/chapas/parafusos variáveis dentro de critérios geométricos calculados. N/M seguem integralmente pelas mesas; V e Ve pelas talas de alma. Não altera a partilha ou o formato de projetos M004 axiais anteriores.

UI própria, resultados JSON com estado exato, projeto JSON estrito, desenho e memória Word. Resistências de talas separadas, planos reais de parafusos, contato vetorial,84 caminhos reais de bloco, compressão/torção/Aef, seções líquidas integradas e ações do membro com Vx. Política mínima fica pendente por padrão; global do membro e serviço têm alcance explícito. Veja `docs/W_CONVENTIONAL_NMV_SCOPE.md`.

Integração de desenvolvimento com11famílias. Aplicativo e carregador usam0.9.5-nmv-dev; o componente convencional possui sua versão própria0.9.5-w-conventional-dev. Os formatos e versões dos componentes anteriores são preservados. A publicação e o empacotamento são etapas separadas desta cópia de desenvolvimento.

## Histórico 0.9.4-base-weld-dev

Novo componente **Solda pilar–placa · duas mesas N/M + alma V**, disponível nas bases engastada Tipo 1 e rotulada Tipo 2. Mesas e alma têm escolhas independentes de filete/CJP, com perna/garganta, comprimentos físicos e efetivos reais, ações assinadas na face superior e verificações NBR atuais. O braço muda de d para d−tf nas mesas CJP. A memória registra alocação e comprimentos e é vinculada à combinação atual; sem qualificação, os componentes numéricos continuam visíveis como condicionais. A base completa permanece a complementar.

UI, JSON, detalhe físico e memória Word incluem forças com sinais, auditoria de equilíbrio e invalidação de documentação obsoleta. Contato preparado opcional tem área real e resistência calculada; não alivia automaticamente a compressão nas soldas. A rota anterior de tração pura Tipo 2 foi preservada. Não se usa grupo elástico geral, bônus direcional AISC nem atalho geométrico para qualificar placas flexíveis.

Método e limites: `docs/BASE_WELD_QUALIFIED_V094.md`. Exemplos com registros sintéticos são demonstrações de cálculo e estados de interface; não são comprovação real de transferência ou projetos executivos.

## Histórico 0.9.3

Nova família **Cantoneiras duplas · R017 · viga recortada**: duas cantoneiras parafusadas entre alma recortada e alma de viga perpendicular, recortes iguais rasos com R15, V com sinal, interface de apoio em uma única alma, verificações NBR atuais e instabilidade complementar Gerdau/AISC com domínio e travamentos explícitos. UI, JSON, desenho de três vistas e memória Word nativos. O preset mantém pendente o travamento na face comprimida até referência externa qualificada; os componentes calculáveis continuam disponíveis. Atendimento local não aprova os membros globais. Método e limites: `docs/CANTONEIRAS_R017_V093.md`.

As versões de componente e projetos R015/R016 anteriores foram preservadas. A expansão R017 não libera cantoneira única, recortes arbitrários, emenda W geral nem bases completas.

## Histórico 0.9.2

Nova família **Cantoneiras duplas · R015 · soldadas/parafusadas**: dois grupos de solda em U reais na alma da viga, com V/2 e excentricidade calculada por cantoneira, apoio parafusado em corte simples, metal-base da alma única e flexão/corte no plano das abas. Entrada, JSON, três vistas proporcionais, memória Word editável e exemplos independentes. Domínio usual simétrico sem recortes sob V estático, N=M=T=0; alternativas e pendências não recebem aprovação indevida. Método, fontes e limites em `docs/CANTONEIRAS_R015_V092.md`.

As famílias anteriores são preservadas. R016 continua nativa na versão de componente0.9.1; W geral com compressão/M/V, cantoneira única completa e bases com verificações pendentes não foram liberadas por esta expansão.

## Histórico0.9.1


Nova família **Cantoneiras duplas · R016 · cortante**: duas cantoneiras reais, toda parafusada, alma de viga W sem recorte na mesa de pilar W, sob V estático com sinal. Motor, UI, projeto JSON, desenho de três vistas, memória Word e exemplos próprios. Parafusos comuns da alma em corte duplo; apoio em corte simples; verificações independentes das quatro abas, alma, mesa do pilar e blocos físicos. O primeiro domínio convencional exige N=M=T=0 e geometria documentada. Cantoneira única e abas estendidas não recebem aprovação pela metade do par. Método e limites: docs/CANTONEIRAS_R016_V091.md.

Esta é uma integração de desenvolvimento, sem upload ou publicação. O atendimento R016 é local e limitado ao domínio declarado. A emenda W abaixo continua axial parcial; compressão com M/V simultâneos permanece pendente.


Histórico 0.9.0 axial: as afirmações de W geral pendente neste parágrafo descrevem aquele checkpoint. Hoje existe a família convencional N/M/V separada, sem qualificação por esta auditoria axial. Checkpoint axial parcial e interno, sem upload, publicação ou conclusão da família W solicitada. O próximo escopo requerido é compressão com momento e cortante simultâneos; seu modelo geral permanece pendente das verificações de bloco/estabilidade explicitadas em docs/M004_GENERAL_ARCHITECTURE.md. Nova família **Emenda W · M004 · tração axial**, com oito talas reais, partilha de área das mesas/alma, parafusos em corte duplo, contato/rasgamento, seções brutas/líquidas e caminhos de bloco convencionais. Somente N positivo e concêntrico; qualquer M, V, torção ou compressão impede aprovação por este modelo. Não há seletor de emenda de chapa plana.

O N real permanece separado da ação adotada de conferência. O mínimo de 45 kN é aplicado uma única vez ao conjunto; a recomendação de resistência do membro tem política explícita a critério do responsável técnico, com referência para Nc,Rd externo quando aplicável. Variação do preset industrial, falha de detalhamento, conflito físico e modelo fora do domínio são estados distintos.

A base anterior 0.8.6 permanece sem alterações no diretório original. Base técnica e limites da emenda: docs/W_SPLICE_M004_TENSION_SCOPE.md; validação: docs/VALIDACAO_W090.md. A estatística N/M/V de pesquisa é separada e não fornece resistências nem aprovação.

Histórico 0.8.6: checkpoint de desenvolvimento, ainda sem publicação. Agora há duas famílias distintas de placas de base: engastada Tipo 1 com chumbadores externos e rotulada Tipo 2 com chumbadores internos e entrada somente N/V. Projetos antigos preservam geometria e momento. Componentes ACI e solda local Tipo 2 têm domínios explícitos; as bases completas continuam com verificações a complementar. Escopo atual: docs/PLACAS_DE_BASE_V086.md. As seções históricas abaixo descrevem versões anteriores.

Cálculo local e detalhamento de ligações de aço com Streamlit, projetos JSON, desenhos proporcionais e memória Word com equações editáveis.

Desenvolvido por LRO Soluções de engenharia LTDA.

## Publicação

A distribuição pronta para GitHub contém quatro arquivos na raiz: `app.py`, `codigo_lro.zip`, `requirements.txt` e `README.md`. Envie os quatro juntos e mantenha `codigo_lro.zip` compactado. No Streamlit, use `app.py` e Python 3.12. Ao atualizar, substitua os quatro arquivos e reinicie o app.

Este README interno acompanha o código-fonte contido em `codigo_lro.zip`. Para desenvolvimento, extraia uma cópia separada e execute:

```bash
python -m pip install -r requirements-dev.txt
python -m pytest -q tests
python -m streamlit run app.py
```

## Ligações

- Emenda W M004 balanceada, oito talas, somente tração axial concêntrica.

- Single plate na alma da viga de apoio ou na mesa da coluna, com V e N de tração.
- Duas talas na alma da coluna, com V e N com sinal.
- End plate rotulada na mesa da coluna, com V e N com sinal.
- End plate engastada na mesa da coluna, com M, V e N, extensão acima e abaixo ou somente acima.

Esforços já de cálculo. Entradas em kgf e kgf·m na tela; dimensões em mm. Modelo plano, sem carregamento no eixo de menor inércia. Premissas e exclusões acompanham a tela e o final do Word.

## Melhorias incluídas desde a 0.7.4

Limites empíricos do método passam a avisos quando é possível executar as equações. A W200 pode seguir no modelo 4E com ressalva explícita de extrapolação. Espaçamento máximo e bordas máximas não atendidos deixam o resultado como **NÃO ATENDE AO DETALHAMENTO**, mas permitem calcular e exportar.

Novo campo **Linhas intermediárias entre as mesas** na end plate engastada: adiciona pares de parafusos no detalhe, considera todos os furos nos ligamentos e blocos, sem crédito resistente nem redistribuição das forças do grupo base 4E. O arranjo ampliado permanece com ressalva e exige avaliação específica para confirmar resistência e rigidez.

As cinco ligações foram auditadas; os critérios de resistência permanecem visíveis e as entradas não são corrigidas automaticamente. Veja `docs/AJUSTES_V074.md` para alcance, exemplos e bloqueios mantidos. Documentos de versões anteriores são históricos e devem ser lidos junto desta revisão.

Os exemplos W200 e W410 com linha intermediária são estudos com ressalvas; não são detalhes aprovados para execução. O exemplo W410 é uma reconstrução a partir do print, mantendo as demais entradas do JSON W200.

O pacote inclui o catálogo de perfis, módulos, exemplos, testes e documentos necessários, sem depender de instalações anteriores. `python verificar_pacote.py` verifica a integridade dos arquivos da distribuição original.


## Correções da 0.7.5

A navegação entre famílias mantém o projeto em edição; rotulada e engastada conservam rascunhos independentes. Valores numéricos não finitos nunca produzem uma verificação favorável. Os modelos estruturais da 0.7.4 foram preservados, inclusive as ressalvas da W200 e as linhas intermediárias sem crédito resistente. Veja `docs/AJUSTES_V075.md` dentro de `codigo_lro.zip`. Salve o JSON para preservar o projeto além da sessão.


## Placas de base na 0.8.0

Nova família **Placa de base · Tipo 1** para pilar I/H, quatro chumbadores externos ASTM A36 e chapa sem enrijecedores. Entradas N/M/V já majoradas; N positivo comprime a base. Seleção dos regimes C1/C2/C3 e T1/T2/T3, chapa por contato/tração, contato no concreto normal de 20–50 MPa, ruptura do aço dos chumbadores e cortante por atrito ou resistência externa documentada.

Ancoragem no concreto, bloco armado, soldas e classificação de rigidez permanecem a complementar. O dispositivo de cisalhamento não é dimensionado; sua resistência externa não soma atrito. A Tabela 18 usa a versão corrigida em 2025. Consulte docs/PLACAS_DE_BASE_V080.md.

As cinco configurações de ligações anteriores e a preservação dos projetos da 0.7.5 foram mantidas.


## Chave de chapa retangular na 0.8.1

Em Placa de base → Caminho resistente do cortante, selecione **Chave de chapa retangular · verificações locais**. Informe bh, bv, espessura e aço. O graute usa a dimensão real informada. São calculados contato local, flexão e cisalhamento da chapa, relação tpv≤tp e os efeitos globais do cortante excêntrico, com sinais: Mef=M+V[tp+(bv+en)/2]. M/V são informados na face superior, sem incluir essa parcela antecipadamente. O JSON guarda os valores de entrada.

O app apresenta as ações normativas para dimensionar as soldas na resistência de contato do concreto. **Resistência das soldas, metal-base/fixação local, ruptura do concreto e bloco armado permanecem a complementar.** Os resultados locais não aprovam o dispositivo completo. Cruciformes e trechos W continuam na rota de resistência externa documentada, com descritor claro, sem seção equivalente fictícia. Não se soma atrito.

Há exemplo didático de cortante puro, desenho de sinais/geometria, memória Word e testes de cinco casos de aceitação, inversão/cancelamento de sinais e preservação dos projetos. Veja `docs/CHAVE_RETANGULAR_V081.md` e `docs/VALIDACAO_V081.md`. As descrições da 0.8.0 acima registram o alcance daquela versão.


## Três opções de transferência do cortante

O seletor principal distingue **chumbadores**, **barra/chave de cisalhamento** e **atrito**, sem soma automática de resistências. Uma nova base abre em chumbadores com **quatro arruelas soldadas**, no domínio descrito abaixo. Atrito e resistência externa documentada continuam disponíveis. Projetos antigos conservam seu caminho e não são convertidos em aprovação nativa. Na rota externa, capacidade e referência são independentes das da chave; a confirmação de aplicabilidade é vinculada aos dados atuais e invalidada quando esses dados mudam.

A revisão geral do posicionamento de textos/cotas/chamadas nos desenhos ficou registrada como melhoria de baixa prioridade para etapa futura, conforme solicitado.


## Novo na 0.8.2: cortante nos chumbadores

O modelo nativo usa quatro barras ASTM A36 com arruelas especiais quadradas soldadas à placa, furo-padrão db+1,5 mm e dimensões reais de lado/espessura. Calcula as trações simultâneas por barra, a expressão especial da NBR 6.7.2.5, o limite adicional da interação geral de 6.3.3.4 e o limite local de concreto. Aplica o mínimo por barra antes da soma; no limite de tração, a reserva de cortante é zero. Não presume V/4 nem soma atrito ou chave.

A expressão publicada tem índice i na raiz e 1 no termo subtrativo. O app adota explicitamente a maior tração simultânea neste último termo como limite conservador e avisa quando as trações diferem. Isso não é apresentado como correção oficial da norma.

Cada solda recebe como ação de dimensionamento Fv,Rd sem redução. **Soldas, arruelas/transferência local, ancoragem no concreto, bloco e demais verificações da base continuam a complementar.** O limite local de concreto não substitui cone, arrancamento, pryout, bordas ou grupo. O resultado favorável dos componentes não aprova a base completa.

Há desenho das quatro arruelas reais, tabela de trações e resistências individuais, memória Word com equações editáveis e exemplos JSON. Método, domínio e ressalvas: `docs/CHUMBADORES_CORTANTE_V082.md`. Registro de software: `docs/VALIDACAO_V082.md`. A 0.8.1 permanece como distribuição independente.


## Cone de tração e detalhamento na 0.8.3

Verificação complementar do cone de concreto por tração conforme ACI 318-19, apoiada no AISC Design Guide 1, 3ª edição, para quatro chumbadores externos moldados no local com cabeça/porca/chapa enterrada e concreto íntegro. Considera as trações simultâneas efetivas, bordas reais do bloco, sobreposição das projeções, excentricidade do grupo e correção de embutimento por múltiplas bordas. A ancoragem completa continua a complementar: os modos não calculados são discriminados na tela e na memória. Não aplica resistência de cone a barra reta sem mecanismo definido, chumbador J ou ancoragem química.

Alma e mesas têm escolhas independentes de solda CJP ou filete; neste último, perna ou garganta, com conversão explícita para filete de pernas iguais a 90°. São especificações de detalhamento, sem resistência geral das soldas certificada. Vínculo rotulado/engastado representa a intenção do modelo, preservando N/M/V e quatro chumbadores. O par de enrijecedores no plano da alma é detalhamento sem crédito resistente. O graute desce da face inferior da placa a 45°, sem ampliar a área de contato usada no cálculo.

Veja `docs/PLACAS_DE_BASE_V083.md` para o alcance, limites e exemplos. Projetos anteriores continuam importáveis e não recebem automaticamente crédito de ancoragem no concreto.


## Chapas ativas na 0.8.4

Cruciforme: somente a chapa perpendicular contínua recebe resistência. W/I: somente as duas mesas normais a V, sem crédito da alma. Largura física, faixas reais de contato e faixas resistentes permanecem distintas; inversão de V troca as faces do W sem trocar as mesas físicas. O graute é o valor real de entrada.

O W começa em envelope de repartição desconhecida: casos alternativos (V,0) e (0,V), sem ganho de capacidade por duas mesas. A hipótese de V/2 pode ser selecionada explicitamente; faixa documentada exige referência e abrangência de sinal. Não há soma de capacidades do concreto ou do dispositivo. Mef=M+V[tp+(H+g)/2] entra uma única vez no equilíbrio, com sinais.

Resultados locais, desenhos reais, ações de solda por ambas as faces, JSON e Word usam o mesmo modelo. Ligação/soldas/metal-base/flexão local da base, concreto da chave, bloco armado e componentes inativos continuam pendentes. Não é aprovação do dispositivo completo. Veja `docs/CHAPAS_ATIVAS_V084.md`. Chapa única e as três rotas principais do cortante são preservadas.

## Arruela superior na 0.8.5

Opção explícita para quatro filetes iguais, externos e contínuos na arruela superior quadrada. Não se confunde com cabeça/chapa enterrada. Material limitado a ASTM A572 Gr.50 (ta≤100 mm) e execução SMAW/E7018 em passe único. Exige perna, furo real circular da placa e confirmação de concentricidade.

Metal das soldas: grupo elástico de linhas de raiz, F=Fv,Rd não reduzido de uma barra, inclusive com V=0. Momento conservador Mw=F(tp/2+3ta/4), envelope aditivo do app baseado na hipótese de curvatura reversa DG1, não uma fórmula NBR nem prescrição DG1 para solda. Não altera M global. Furo: pressão/rasgamento direto com fu=450 MPa, usando o mesmo F como envelope conservador de desenvolvimento de capacidade; não se atribui V/4.

Resultados separados de metal de solda, detalhe/implantação e furo. Verifica folgas e interferência em planta com filetes de coluna especificados. Dados faltantes preservam pendência; dimensões resistentemente insuficientes permanecem falhas visíveis. Flexão arruela–placa, contato combinado, demais caminhos do metal-base, execução, ancoragem completa e fundação continuam separados. JSON legado e opções ocultas permanecem compatíveis. Novas entradas e resultados constam na tela, detalhe próprio e Word.
