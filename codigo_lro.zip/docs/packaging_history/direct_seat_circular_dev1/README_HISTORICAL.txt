Historico circular dev1 e recibos anteriores preservados. Estes resultados nao sao evidencia da revisao local dev2.
