"""Independent direct-seat regression checks.

These tests cover arithmetic, declared domain and serialization. They are not
evidence that the physical connection, rotation or axial release is qualified.
Legacy fixture hashes were obtained from the untouched 0.9.44 source.
"""
from dataclasses import replace
import copy
import hashlib
import json
import math
from pathlib import Path
import unittest

from lro.beam_direct_seat import BeamDirectSeat, evaluate, input_errors, presets
from lro.beam_on_beam import BeamOnBeam, evaluate as legacy_evaluate

ROOT = Path(__file__).resolve().parents[1]
LEGACY_PROJECT = ROOT / 'examples' / 'beam_on_beam_actual_partial.json'
LEGACY_SLOTTED = ROOT / 'tests' / 'fixtures' / 'beam_direct_seat_slotted_0944.json'


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=True,
        separators=(',', ':'), allow_nan=False).encode()).hexdigest()


class DirectSeatIndependentTests(unittest.TestCase):
    def setUp(self):
        self.c = next(iter(presets().values()))

    def result(self, **updates):
        return evaluate(replace(self.c, **updates))

    def assert_incomplete(self, r):
        self.assertIs(r['global_pass'], False)
        self.assertIs(r['engineering_approved'], False)

    def checks(self,r):
        rows={row['id']:row for row in r['checks']}
        self.assertEqual(len(rows),len(r['checks']),'Check identifiers must be unique')
        return rows

    def check(self,cid,**updates):
        return self.checks(self.result(**updates))[cid]

    def test_default_actions_are_current_user_ELU(self):
        self.assertAlmostEqual(self.c.V, 2610 * 9.80665, places=10)
        self.assertEqual(self.c.N, 0.)
        self.assertEqual(self.c.applied_moment_y, 0.)
        self.assertEqual(self.c.torsion, 0.)
        self.assertEqual(self.c.reference_x, 0.)

    def test_default_nominal_geometry_is_four_shared_vertical_bolts(self):
        self.assertEqual(self.c.db, 16.)
        self.assertEqual((self.c.upper_hole, self.c.support_hole), (18.,18.))
        self.assertEqual((self.c.upper_washer_diameter,self.c.lower_washer_diameter), (33.,33.))
        self.assertEqual((self.c.bolt_pitch,self.c.bolt_gauge), (70.,80.))
        self.assertEqual(self.c.end,70.)

    def test_circular_identity_is_distinct_from_prior_deliveries(self):
        data=self.c.to_dict();r=evaluate(self.c)
        self.assertEqual(data['schema_version'],2)
        self.assertEqual(data['connection_type'],'beam_direct_seat_standard_holes')
        self.assertEqual(data['component_version'],'0.9.46-direct-seat-circular-review-dev.1')
        self.assertEqual((r['connection_type'],r['component_version']),
                         (data['connection_type'],data['component_version']))

    def test_frozen_slotted_fixture_is_preserved_as_test_evidence(self):
        self.assertEqual(hashlib.sha256(LEGACY_SLOTTED.read_bytes()).hexdigest(),
                         'bc2f257cb473e5882df83b1c5a614ea866209f95c7ec8b9c3ec6dbbd72f9924c')

    def test_old_slotted_project_is_explicitly_rejected_without_mutation(self):
        data=json.loads(LEGACY_SLOTTED.read_text(encoding='utf-8'))
        before=copy.deepcopy(data)
        self.assertEqual(data['connection_type'],'beam_direct_seat')
        with self.assertRaisesRegex(ValueError,'(?i)oblongo|anterior|slotted'):
            BeamDirectSeat.from_dict(data)
        self.assertEqual(data,before)

    def test_relabeling_old_slotted_project_as_circular_does_not_convert_it(self):
        data=json.loads(LEGACY_SLOTTED.read_text(encoding='utf-8'))
        new=self.c.to_dict()
        for key in ('schema_version','connection_type','component_version','fixed_assumptions'):
            data[key]=copy.deepcopy(new[key])
        with self.assertRaises(ValueError):BeamDirectSeat.from_dict(data)

    def test_removed_slot_and_cover_fields_are_strictly_rejected_if_injected(self):
        for key,value in (('slot_width',18.),('slot_length',40.),('cover_length',60.),
                          ('cover_width',36.),('cover_thickness',8.),('cover_hole',18.),
                          ('cover_steel','ASTM A36'),('required_travel',None)):
            data=self.c.to_dict();data['connection'][key]=value
            with self.subTest(key=key),self.assertRaises(ValueError):
                BeamDirectSeat.from_dict(data)

    def test_roundtrip_preserves_every_canonical_input(self):
        before=self.c.to_dict()
        loaded=BeamDirectSeat.from_dict(json.loads(json.dumps(before,allow_nan=False)))
        self.assertEqual(loaded,self.c)
        self.assertEqual(loaded.to_dict(),before)
        self.assertEqual(evaluate(loaded),evaluate(self.c))

    def test_non_display_precision_survives_roundtrip(self):
        c=replace(self.c,V=2610*9.80665+0.123456789,notes='Precisao plena')
        loaded=BeamDirectSeat.from_dict(json.loads(json.dumps(c.to_dict())))
        self.assertEqual(loaded.V,c.V)
        self.assertEqual(loaded.notes,c.notes)

    def test_import_does_not_mutate_caller_dict(self):
        data=self.c.to_dict();original=copy.deepcopy(data)
        BeamDirectSeat.from_dict(data)
        self.assertEqual(data,original)

    def test_exported_dict_is_detached_from_frozen_input(self):
        data=self.c.to_dict();data['connection']['V']=1.
        self.assertAlmostEqual(self.c.V,2610*9.80665,places=10)

    def test_legacy_family_is_rejected_as_direct(self):
        legacy=json.loads(LEGACY_PROJECT.read_text(encoding='utf-8'))
        with self.assertRaises(ValueError):BeamDirectSeat.from_dict(legacy)

    def test_result_object_is_not_a_project(self):
        with self.assertRaises(ValueError):BeamDirectSeat.from_dict(evaluate(self.c))

    def test_missing_or_unknown_envelope_field_rejected(self):
        for remove in (False,True):
            data=self.c.to_dict()
            if remove:data.pop('units')
            else:data['trusted_result']={'global_pass':True}
            with self.subTest(remove=remove),self.assertRaises(ValueError):
                BeamDirectSeat.from_dict(data)

    def test_missing_or_unknown_connection_field_rejected(self):
        for remove in (False,True):
            data=self.c.to_dict()
            if remove:data['connection'].pop('V')
            else:data['connection']['legacy_plate_length']=140.
            with self.subTest(remove=remove),self.assertRaises(ValueError):
                BeamDirectSeat.from_dict(data)

    def test_schema_units_family_and_component_mismatch_rejected(self):
        alterations=[('schema_version',True),('schema_version',1),('schema_version',3),
            ('connection_type','beam_on_beam_bearing_plate'),
            ('component_version','0.9.44-beam-on-beam-partial-dev'),
            ('units',{'force':'kgf','length':'mm','stress':'MPa','moment':'N mm'})]
        for key,value in alterations:
            data=self.c.to_dict();data[key]=value
            with self.subTest(key=key,value=value),self.assertRaises(ValueError):
                BeamDirectSeat.from_dict(data)

    def test_import_cannot_override_fixed_assumptions(self):
        data=self.c.to_dict();data['fixed_assumptions']={'global_pass':True}
        with self.assertRaises(ValueError):BeamDirectSeat.from_dict(data)

    def test_profile_unknown_numeric_and_family_data_rejected(self):
        data=self.c.to_dict();data['connection']['beam']['unknown_dimension']=1.
        with self.assertRaises(ValueError):BeamDirectSeat.from_dict(data)

    def test_nan_and_infinite_force_are_invalid(self):
        for value in (math.nan, math.inf, -math.inf):
            with self.subTest(value=value):
                c=replace(self.c,V=value)
                self.assertTrue(input_errors(c))
                r=evaluate(c);self.assertEqual(r['status'],'INVALID_INPUT');self.assert_incomplete(r)

    def test_nonfinite_actions_and_circular_dimensions_never_reach_resistance(self):
        for name in ('N','applied_moment_y','torsion','reference_x','upper_hole','support_hole',
                     'upper_washer_diameter','lower_washer_diameter','stiff_clip','stiff_weld_length'):
            for value in (math.nan,math.inf,-math.inf):
                with self.subTest(name=name,value=value):
                    r=self.result(**{name:value})
                    self.assertEqual(r['status'],'INVALID_INPUT')
                    self.assertEqual(r['checks'],[])
                    self.assert_incomplete(r)

    def test_bool_is_not_a_numerical_force_or_dimension(self):
        for name in ('V','N','db','upper_hole','support_hole','bolt_pitch',
                     'upper_washer_diameter','lower_washer_diameter'):
            with self.subTest(name=name):
                c=replace(self.c,**{name:True})
                self.assertTrue(input_errors(c))
                r=evaluate(c);self.assertEqual(r['status'],'INVALID_INPUT');self.assert_incomplete(r)

    def test_negative_dimension_is_invalid(self):
        for name in ('db','upper_hole','support_hole','bolt_pitch',
                     'upper_washer_diameter','lower_washer_diameter'):
            with self.subTest(name=name):
                r=self.result(**{name:-1.})
                self.assertEqual(r['status'],'INVALID_INPUT');self.assert_incomplete(r)

    def test_string_force_does_not_reach_arithmetic(self):
        r=self.result(V='2610')
        self.assertEqual(r['status'],'INVALID_INPUT');self.assert_incomplete(r)

    def test_export_rejects_invalid_input(self):
        for value in (math.nan,True,'2610'):
            with self.subTest(value=value),self.assertRaises(ValueError):
                replace(self.c,V=value).to_dict()

    def test_import_rejects_invalid_numerical_profile(self):
        for value in (True,math.nan,-1.):
            data=self.c.to_dict();data['connection']['beam']['tw']=value
            with self.subTest(value=value),self.assertRaises(ValueError):
                BeamDirectSeat.from_dict(data)

    def test_unknown_datum_remains_unknown_and_never_approved(self):
        r=self.result(reference_x=None)
        self.assertIn(r['status'],('OUTSIDE_SCOPE','INVALID_INPUT'))
        self.assert_incomplete(r)

    def test_non_boolean_detail_flag_is_invalid(self):
        r=self.result(fitted_required=1)
        self.assertEqual(r['status'],'INVALID_INPUT');self.assert_incomplete(r)

    def test_all_detail_flags_reject_nonboolean_and_keep_no_resistance(self):
        for flag in ('fitted_required','direct_bearing_faces_prepared','web_attached',
                     'loaded_flange_attached','full_height_attached_both','rotational_detail_confirmed'):
            for value in (0,1,None,'true'):
                with self.subTest(flag=flag,value=value):
                    r=self.result(**{flag:value})
                    self.assertEqual(r['status'],'INVALID_INPUT')
                    self.assertEqual(r['checks'],[])
                    self.assert_incomplete(r)

    def test_material_catalog_and_rolled_vs_plate_domains_are_respected(self):
        for field,value in (('beam_steel','Unknown'),('support_steel','USI-CIVIL 350'),
                            ('beam_steel','USI-CIVIL 300'),('stiffener_steel','ASTM A992')):
            with self.subTest(field=field,value=value):
                r=self.result(**{field:value})
                self.assertEqual(r['status'],'INVALID_INPUT')
                self.assertEqual(r['checks'],[])
                self.assert_incomplete(r)
        r=self.result(stiffener_steel='USI-CIVIL 350',stiff_thickness=5.999999)
        self.assertEqual(r['status'],'INVALID_INPUT')

    def test_outside_M16_domain_keeps_custom_diameter_in_JSON(self):
        c=replace(self.c,db=20.)
        loaded=BeamDirectSeat.from_dict(c.to_dict())
        self.assertEqual(loaded.db,20.)
        r=evaluate(loaded)
        self.assertEqual(r['status'],'OUTSIDE_SCOPE')
        self.assert_incomplete(r)

    def test_nonzero_horizontal_axial_force_is_outside_domain(self):
        for value in (-1.,1.,1000.):
            with self.subTest(value=value):
                r=self.result(N=value);self.assertEqual(r['status'],'OUTSIDE_SCOPE');self.assert_incomplete(r)

    def test_applied_moment_is_not_erased(self):
        for value in (-1.,1.):
            with self.subTest(value=value):
                c=replace(self.c,applied_moment_y=value);r=evaluate(c)
                self.assertEqual(c.applied_moment_y,value)
                self.assertEqual(r['status'],'OUTSIDE_SCOPE');self.assert_incomplete(r)

    def test_torsion_is_outside_domain(self):
        r=self.result(torsion=1.)
        self.assertEqual(r['status'],'OUTSIDE_SCOPE');self.assert_incomplete(r)

    def test_unaligned_action_datum_is_outside_domain(self):
        for value in (-.001,.001):
            with self.subTest(value=value):
                r=self.result(reference_x=value)
                self.assertEqual(r['status'],'OUTSIDE_SCOPE');self.assert_incomplete(r)

    def test_zero_or_reversed_gravity_never_approved(self):
        # Frozen contract treats reverse V as invalid input, while zero V is
        # a valid numeric value outside the positive-gravity domain.
        for value,status in ((0.,'OUTSIDE_SCOPE'),(-1.,'INVALID_INPUT')):
            with self.subTest(value=value):
                r=self.result(V=value)
                self.assertEqual(r['status'],status);self.assert_incomplete(r)
                self.assertIs(r['gravity_checks_satisfied'],False)

    def test_every_nominal_result_remains_incomplete(self):
        for c in presets().values():
            with self.subTest(project=c.project):self.assert_incomplete(evaluate(c))

    def test_profile_or_catalog_is_not_mutated_by_evaluation(self):
        before=(self.c.beam,self.c.support,self.c.to_dict())
        evaluate(self.c)
        self.assertEqual((self.c.beam,self.c.support,self.c.to_dict()),before)

    def test_legacy_canonical_roundtrip_matches_frozen_0944(self):
        raw=json.loads(LEGACY_PROJECT.read_text(encoding='utf-8'))
        c=BeamOnBeam.from_dict(raw)
        self.assertEqual(digest(c.to_dict()),'20bfaa2ffb7f9dea03884a175474bbb02c2ab7196ccfaeb6d69876f8312f7203')
        self.assertEqual(BeamOnBeam.from_dict(c.to_dict()),c)

    def test_legacy_engine_result_matches_frozen_0944(self):
        c=BeamOnBeam.from_dict(json.loads(LEGACY_PROJECT.read_text(encoding='utf-8')))
        self.assertEqual(digest(legacy_evaluate(c)),'e39e5f705c1e04f0f1cafa8f49979101a580ad884b87876ffeb12708b539770b')

    def test_legacy_profiles_models_and_engine_bytes_are_preserved(self):
        expected={
            'data/profiles.json':'42ad4ec10bb1b16773e0580ca2dbcbb79c9f8fc6927e24d95a29fbd323df2602',
            'lro/models.py':'9c5f62114299b351e94df415872cce32dd2456fbd629122ae97a38e53facd66a',
            'lro/beam_on_beam.py':'9d3d52abe7eb3533b4def96c517056ab678b47470dcd14bbb40f3b1d665180f8',
        }
        for name,sha in expected.items():
            with self.subTest(name=name):
                self.assertEqual(hashlib.sha256((ROOT/name).read_bytes()).hexdigest(),sha)

    def test_actual_ELU_and_minimum_case_are_separate(self):
        r=evaluate(self.c);a=r['actions']
        self.assertEqual(a['V_ELU_N'],25595.3565)
        self.assertEqual(a['minimum_vertical_strength_case_N'],45000.)
        self.assertEqual(a['check_force_N'],45000.)
        self.assertEqual(a['action_factor'],1.)
        self.assertIs(a['minimum_is_action_multiplier'],False)
        self.assertEqual(self.c.V,25595.3565)
        self.assertEqual(self.c.to_dict()['connection']['V'],25595.3565)

    def test_minimum_does_not_reduce_larger_actual_force(self):
        r=self.result(V=45001.23456789)
        self.assertEqual(r['actions']['V_ELU_N'],45001.23456789)
        self.assertEqual(r['actions']['check_force_N'],45001.23456789)
        for row in r['checks']:
            if row['category']=='RESISTANCE' and row['unit']=='N':
                self.assertEqual(row['demand'],45001.23456789)

    def test_domain_values_survive_canonical_JSON_before_scope_rejection(self):
        c=replace(self.c,N=-123.,applied_moment_y=456.,reference_x=.25)
        loaded=BeamDirectSeat.from_dict(c.to_dict())
        self.assertEqual((loaded.N,loaded.applied_moment_y,loaded.reference_x),(-123.,456.,.25))
        self.assertEqual(evaluate(loaded)['status'],'OUTSIDE_SCOPE')

    def test_nominal_coordinates_are_independent_oracle(self):
        g=evaluate(self.c)['geometry']
        self.assertEqual(g['bolt_coordinates_mm'],[[-35.,-40.],[35.,-40.],[-35.,40.],[35.,40.]])
        self.assertEqual(g['upper_flange_y_bounds_mm'],[-64.,64.])
        self.assertEqual(g['lower_flange_x_bounds_mm'],[-70.,70.])
        self.assertEqual(g['physical_bolts'],4)
        self.assertEqual(g['physical_stiffeners'],2)
        self.assertAlmostEqual(g['upper_root_toe_mm'],15.25)
        self.assertAlmostEqual(g['lower_root_toe_mm'],15.2)

    def test_nominal_circular_edges_have_no_long_slot_increment(self):
        rows=self.checks(evaluate(self.c))
        self.assertEqual((rows['upper_end_edge']['value'],rows['upper_end_edge']['limit']),(35.,22.))
        self.assertEqual((rows['upper_side_edge']['value'],rows['upper_side_edge']['limit']),(24.,22.))
        self.assertEqual((rows['lower_side_edge']['value'],rows['lower_side_edge']['limit']),(35.,22.))
        self.assertEqual(rows['upper_end_edge']['status'],'PASS')

    def test_upper_end_edge_boundary(self):
        self.assertEqual(self.check('upper_end_edge',end=57.)['status'],'PASS')
        r=self.result(end=56.999999)
        self.assertEqual(self.checks(r)['upper_end_edge']['status'],'FAIL')
        self.assertIs(r['gravity_checks_satisfied'],False)

    def test_upper_side_edge_boundary(self):
        self.assertEqual(self.check('upper_side_edge',bolt_gauge=84.)['status'],'PASS')
        self.assertEqual(self.check('upper_side_edge',bolt_gauge=84.000001)['status'],'FAIL')

    def test_support_side_edge_boundary(self):
        self.assertEqual(self.check('lower_side_edge',bolt_pitch=96.)['status'],'PASS')
        self.assertEqual(self.check('lower_side_edge',bolt_pitch=96.000001)['status'],'FAIL')

    def test_circular_free_spacing_matches_openings_in_both_directions(self):
        rows=self.checks(evaluate(self.c))
        self.assertEqual((rows['bolt_clear_spacing_x']['value'],rows['bolt_clear_spacing_x']['limit']),(52.,16.))
        self.assertEqual((rows['bolt_clear_spacing_y']['value'],rows['bolt_clear_spacing_y']['limit']),(62.,16.))
        self.assertEqual(rows['bolt_clear_spacing_x']['status'],'PASS')
        self.assertEqual(rows['bolt_clear_spacing_y']['status'],'PASS')

    def test_circular_free_spacing_boundary_remains_explicit(self):
        # Free34-18=16 satisfies the ligament check, but34 fails the43.2
        # center-distance requirement. Each row must retain its own result.
        for field,cid,center_id in (('bolt_pitch','bolt_clear_spacing_x','bolt_spacing_x'),
                                    ('bolt_gauge','bolt_clear_spacing_y','bolt_spacing_y')):
            with self.subTest(field=field):
                at=self.result(**{field:34.})
                below=self.result(**{field:33.999999})
                self.assertEqual(self.checks(at)[cid]['status'],'PASS')
                self.assertEqual(self.checks(at)[center_id]['status'],'FAIL')
                self.assertEqual(self.checks(below)[cid]['status'],'FAIL')
                self.assertIs(at['gravity_checks_satisfied'],False)

    def test_center_spacing_boundary(self):
        self.assertEqual(self.check('bolt_spacing_y',bolt_gauge=43.2)['status'],'PASS')
        self.assertEqual(self.check('bolt_spacing_y',bolt_gauge=43.199999)['status'],'FAIL')

    def test_max_spacing_uses_8point8_mm_thinner_flange(self):
        row=self.check('bolt_spacing_max_x')
        # The restricted contract now deliberately uses the smaller14t/180
        # branch, avoiding an unstated weather/painting condition.
        self.assertAlmostEqual(row['limit'],123.2)
        self.assertEqual(self.check('bolt_spacing_max_x',bolt_pitch=123.2)['status'],'PASS')
        self.assertEqual(self.check('bolt_spacing_max_x',bolt_pitch=123.200001)['status'],'FAIL')

    def test_both_circular_openings_must_equal_standard_18mm(self):
        for field,cid in (('upper_hole','upper_hole'),('support_hole','support_hole')):
            for value in (17.999999,18.000001,20.):
                with self.subTest(field=field,value=value):
                    r=self.result(**{field:value})
                    self.assertEqual(self.checks(r)[cid]['status'],'FAIL')
                    self.assertIs(r['gravity_checks_satisfied'],False)

    def test_upper_washer_fits_root_edge_and_end(self):
        rows=self.checks(evaluate(self.c))
        for cid,value in (('upper_washer_root',24.75),('upper_washer_edge',24.),
                          ('upper_washer_end',35.)):
            with self.subTest(cid=cid):
                self.assertEqual((rows[cid]['value'],rows[cid]['limit']),(value,16.5))
                self.assertEqual(rows[cid]['status'],'PASS')
        for cid,diameter in (('upper_washer_root',49.5),('upper_washer_edge',48.),
                             ('upper_washer_end',70.)):
            with self.subTest(cid=cid):
                self.assertEqual(self.check(cid,upper_washer_diameter=diameter)['status'],'PASS')
                self.assertEqual(self.check(cid,upper_washer_diameter=diameter+.000001)['status'],'FAIL')

    def test_lower_washer_fits_root_edge_and_stiffener(self):
        rows=self.checks(evaluate(self.c))
        for cid,value in (('lower_washer_root',19.8),('lower_washer_edge',35.),
                          ('lower_washer_stiffener',36.)):
            with self.subTest(cid=cid):
                self.assertAlmostEqual(rows[cid]['value'],value,places=10)
                self.assertEqual(rows[cid]['limit'],16.5)
                self.assertEqual(rows[cid]['status'],'PASS')
        for cid,diameter in (('lower_washer_root',39.6),('lower_washer_edge',70.),
                             ('lower_washer_stiffener',72.)):
            with self.subTest(cid=cid):
                self.assertEqual(self.check(cid,lower_washer_diameter=diameter)['status'],'PASS')
                self.assertEqual(self.check(cid,lower_washer_diameter=diameter+.000001)['status'],'FAIL')

    def test_tool_lower_root_boundary(self):
        self.assertEqual(self.check('tool_lower_root',support_radius=12.8)['status'],'PASS')
        self.assertEqual(self.check('tool_lower_root',support_radius=12.800001)['status'],'FAIL')

    def test_tool_upper_root_boundary(self):
        self.assertEqual(self.check('tool_upper_root',beam_radius=17.75)['status'],'PASS')
        self.assertEqual(self.check('tool_upper_root',beam_radius=17.750001)['status'],'FAIL')

    def test_tool_gate_is_only_necessary_shank_envelope_not_washer_radius(self):
        # A socket surrounds the head/nut, not the washer. Without actual
        # head/nut dimensions, db/2 is only a necessary shaft-size floor.
        self.assertEqual(self.check('tool_hardware',tool_radius=7.99999)['status'],'FAIL')
        self.assertEqual(self.check('tool_hardware',tool_radius=8.)['status'],'PASS')
        self.assertEqual(self.check('tool_hardware',tool_radius=16.49999)['status'],'PASS')
        self.assertIs(replace(self.c,tool_radius=8.).fixed_assumptions['actual_hardware_or_tool_attested'],False)

    def test_lower_washer_requires_positive_annulus_around_18mm_hole(self):
        for diameter in (1.,18.):
            with self.subTest(diameter=diameter):
                r=self.result(lower_washer_diameter=diameter)
                self.assertEqual(self.checks(r)['lower_washer_covers_hole']['status'],'FAIL')
                self.assertIs(r['gravity_checks_satisfied'],False)
        row=self.check('lower_washer_covers_hole',lower_washer_diameter=18.000001)
        self.assertEqual(row['status'],'PASS')
        self.assertIs(replace(self.c,lower_washer_diameter=18.000001).fixed_assumptions['actual_hardware_or_tool_attested'],False)

    def test_upper_washer_requires_positive_annulus_around_18mm_hole(self):
        for diameter in (1.,18.):
            with self.subTest(diameter=diameter):
                r=self.result(upper_washer_diameter=diameter)
                self.assertEqual(self.checks(r)['upper_washer_covers_hole']['status'],'FAIL')
                self.assertIs(r['gravity_checks_satisfied'],False)
        self.assertEqual(self.check('upper_washer_covers_hole',upper_washer_diameter=18.000001)['status'],'PASS')
        self.assertIs(replace(self.c,upper_washer_diameter=18.000001).fixed_assumptions['actual_hardware_or_tool_attested'],False)

    def test_nominal_circular_hole_clearance_is_not_verified_axial_release(self):
        self.assertEqual(self.c.upper_hole-self.c.db,2.)
        self.assertEqual(self.c.support_hole-self.c.db,2.)
        self.assertIs(self.c.fixed_assumptions['axial_release_verified'],False)
        data=self.c.to_dict();data['fixed_assumptions']['axial_release_verified']=True
        with self.assertRaises(ValueError):BeamDirectSeat.from_dict(data)

    def test_stiffener_alignment_boundary(self):
        self.assertEqual(self.check('stiff_alignment',stiff_y=0.)['status'],'PASS')
        for value in (-.000001,.000001):
            with self.subTest(value=value):
                r=self.result(stiff_y=value)
                self.assertEqual(self.checks(r)['stiff_alignment']['status'],'FAIL')
                self.assertIs(r['gravity_checks_satisfied'],False)

    def test_clip_eliminating_contact_never_calculates_positive_resistance(self):
        r=self.result(stiff_clip=60.)
        self.assertIs(r['gravity_checks_satisfied'],False)
        self.assertEqual(self.checks(r)['fitted_area_positive']['status'],'FAIL')
        self.assertFalse(any(row['id'].startswith('fitted_end_') for row in r['checks']))

    def test_missing_fitted_or_prepared_surface_is_pending_not_actual_true(self):
        for flag in ('fitted_required','direct_bearing_faces_prepared','web_attached',
                     'loaded_flange_attached','full_height_attached_both'):
            with self.subTest(flag=flag):
                r=self.result(**{flag:False})
                self.assertEqual(r['status'],'GRAVITY_SPECIFICATION_PENDING')
                self.assertIs(r['gravity_checks_satisfied'],False)
                self.assertEqual(self.checks(r)['fabrication_specification']['status'],'PENDING')
                self.assertFalse(any(row['category']=='RESISTANCE' for row in r['checks']))

    def test_proposed_flags_never_attest_actual_fabrication_or_contact_solution(self):
        c=self.c; r=evaluate(c)
        self.assertIs(c.fixed_assumptions['actual_fit_or_preparation_attested'],False)
        self.assertIs(c.fixed_assumptions['actual_hardware_or_tool_attested'],False)
        self.assertIs(c.fixed_assumptions['contact_or_prying_solved'],False)
        self.assertIs(r['engineering_approved'],False)
        self.assertIsNone(r['actions']['contact_resultant_solved_N'])
        self.assertIsNone(r['actions']['bolt_tensions_solved_N'])
        self.assertIsNone(r['actions']['vertical_bolt_shear_from_V_N'])

    def test_rotation_axial_release_and_real_endcuts_are_visible_pending(self):
        r=evaluate(self.c)
        scopes={s['id']:s for s in r['scopes']}
        self.assertEqual(scopes['rotation']['status'],'PENDING')
        self.assertEqual(scopes['member_endcuts']['status'],'PENDING')
        self.assertEqual(scopes['mounting_retention']['status'],'PENDING')
        self.assertIs(self.c.fixed_assumptions['axial_release_verified'],False)
        self.assertIs(r['gravity_checks_satisfied'],True)
        self.assert_incomplete(r)

    def test_rotational_declaration_does_not_approve_endcuts_or_axial_release(self):
        r=self.result(rotational_detail_confirmed=True)
        scopes={s['id']:s for s in r['scopes']}
        self.assertEqual(scopes['member_endcuts']['status'],'PENDING')
        self.assertEqual(scopes['mounting_retention']['status'],'PENDING')
        self.assertIs(self.c.fixed_assumptions['axial_release_verified'],False)
        self.assertIs(r['engineering_approved'],False)
        self.assert_incomplete(r)

    def test_circular_projects_and_results_have_no_moving_slot_or_cover_fields(self):
        input_keys=set(self.c.to_dict()['connection'])
        removed={'slot_width','slot_length','cover_steel','cover_length','cover_width',
                 'cover_thickness','cover_hole','required_travel'}
        self.assertTrue(input_keys.isdisjoint(removed))
        self.assertFalse(any('slot' in k or 'travel' in k for k in self.c.fixed_assumptions))
        r=evaluate(self.c)
        self.assertFalse(any('slot' in k or 'travel' in k or 'cover_positive' in k for k in r['geometry']))
        self.assertFalse(any(row['id'].startswith('cover_') or row['id']=='required_travel'
                             or row['id'].startswith('slot_') for row in r['checks']))
        self.assertNotIn('retention_sliding',{s['id'] for s in r['scopes']})

    def test_no_intermediate_plate_or_duplicate_upper_weld_is_introduced(self):
        r=evaluate(self.c)
        self.assertIs(r['geometry']['intermediate_plate'],False)
        self.assertIs(r['geometry']['upper_weld'],False)
        self.assertIs(self.c.fixed_assumptions['intermediate_plate'],False)
        self.assertIs(self.c.fixed_assumptions['upper_weld'],False)
        self.assertFalse(any('upper_weld' in row['id'] or 'plate_weld' in row['id'] for row in r['checks']))

    def test_fitted_area_and_each_force_are_independent_oracles(self):
        rows=self.checks(evaluate(self.c))
        for side in ('negative','positive'):
            row=rows['fitted_end_'+side]
            self.assertEqual(row['area_mm2'],320.)
            self.assertEqual(row['demand'],45000.)
            self.assertAlmostEqual(row['resistance'],106666.66666666667,places=8)
            self.assertAlmostEqual(row['eta'],.421875,places=12)

    def test_original_web_lower_bound_oracles(self):
        rows=self.checks(evaluate(self.c))
        expected={'upper_web_yield':59986.875,'lower_web_yield':48576.,
            'upper_web_crippling':135085.18562373891,'lower_web_crippling':119689.78783505302}
        for cid,capacity in expected.items():
            with self.subTest(cid=cid):
                self.assertAlmostEqual(rows[cid]['resistance'],capacity,places=7)
                self.assertEqual(rows[cid]['demand'],45000.)

    def test_composite_section_uses_Y_axis_and_one_effective_web_strip(self):
        row=self.check('stiffener_composite_compression')
        self.assertAlmostEqual(row['effective_web_width_mm'],76.8,places=10)
        self.assertAlmostEqual(row['area_mm2'],1451.52,places=8)
        self.assertAlmostEqual(row['Iy_mm4'],1347828.1216,places=7)
        self.assertAlmostEqual(row['Le_mm'],286.05,places=10)
        self.assertAlmostEqual(row['Ne_N'],32514744.843044877,places=6)
        self.assertAlmostEqual(row['lambda0'],.10564314977193984,places=12)
        self.assertAlmostEqual(row['chi'],.9953396724529692,places=12)
        self.assertEqual(row['fy_conservative_MPa'],250.)
        self.assertAlmostEqual(row['resistance'],328353.5093997576,places=7)
        self.assertTrue(row['axis'].startswith('Y'))

    def test_composite_body_oracle_never_qualifies_the_real_endcuts(self):
        r=evaluate(self.c)
        body=self.checks(r)['stiffener_composite_compression']
        self.assertAlmostEqual(body['resistance'],
                               328353.5093997576,places=7)
        self.assertIs(body['idealized_body_section'],True)
        self.assertIs(body['endcuts_member_verified'],False)
        scopes={s['id']:s for s in r['scopes']}
        self.assertEqual(scopes['member_endcuts']['status'],'PENDING')
        self.assertIs(r['engineering_approved'],False)
        self.assert_incomplete(r)

    def test_stiffener_weld_full_force_and_local_moment_oracles(self):
        row=self.check('stiffener_web_weld')
        self.assertEqual(row['force_N'],45000.)
        self.assertEqual(row['local_moment_Nmm'],2700000.)
        self.assertEqual(row['effective_lines'],2)
        self.assertEqual(row['effective_length_each_mm'],150.)
        self.assertEqual(row['direct_q_N_per_mm'],150.)
        self.assertEqual(row['moment_q_N_per_mm'],360.)
        self.assertEqual(row['demand'],390.)
        self.assertAlmostEqual(row['resistance'],762.1039752788345,places=10)

    def test_table11_minimum_weld_uses_less_thick_part(self):
        # NBR2024 Table11 uses LESS thick base metal. Here support web6.4,
        # stiff8 and flange8.8 all fall in >6.3..12.5, hence minimum5.
        self.assertEqual(self.check('stiff_weld_min')['limit'],5.)
        # A hypothetical thicker stiffener does not raise the web-joint
        # minimum to6: web6.4 remains the less-thick member.
        row=self.check('stiff_weld_min',stiff_thickness=16.)
        self.assertEqual(row['limit'],5.)

    def test_unsafe_local_force_reports_failure_and_no_gravity_pass(self):
        r=self.result(V=200000.)
        self.assertIs(r['gravity_checks_satisfied'],False)
        self.assertEqual(r['status'],'GRAVITY_RESISTANCE_FAILURE')
        self.assertTrue(any(row['category']=='RESISTANCE' and row['status']=='FAIL' for row in r['checks']))

    def test_geometry_results_have_no_resistant_utilization(self):
        for row in evaluate(self.c)['checks']:
            if row['category']=='GEOMETRY':
                with self.subTest(cid=row['id']):
                    self.assertIsNone(row['eta'])
                    self.assertIsNone(row['demand'])
                    self.assertIsNone(row['resistance'])

    def test_composite_full_area_compact_gate_oracles(self):
        rows=self.checks(evaluate(self.c))
        # Independent Table4 lower envelope, fyMAX345 for this mixed section.
        expected=.64*math.sqrt(.35)*math.sqrt(200000./345.)
        self.assertAlmostEqual(rows['composite_stiff_outstand_compact']['value'],7.5)
        self.assertEqual(rows['composite_web_outstand_compact']['value'],6.)
        for cid in ('composite_stiff_outstand_compact','composite_web_outstand_compact'):
            self.assertAlmostEqual(rows[cid]['limit'],expected,places=12)
            self.assertEqual(rows[cid]['status'],'PASS')
            self.assertEqual(rows[cid]['unit'],'adimensional')
        comp=rows['stiffener_composite_compression']
        self.assertEqual(comp['effective_area_mm2'],comp['area_mm2'])

    def test_noncompact_geometry_never_assumes_full_area(self):
        # bs65/ts8=8.125 is below the mixedA36/345 limit, but exceeds the
        # envelope when stiffenerfy450 is used; gate must use fyMAX.
        ordinary=self.result(stiff_width=65.)
        self.assertEqual(self.checks(ordinary)['composite_stiff_outstand_compact']['status'],'PASS')
        high=self.result(stiff_width=65.,stiffener_steel='ASTM A572 Gr.65')
        row=self.checks(high)['composite_stiff_outstand_compact']
        self.assertAlmostEqual(row['value'],8.125)
        self.assertAlmostEqual(row['limit'],.64*math.sqrt(.35)*math.sqrt(200000./450.),places=12)
        self.assertEqual(row['status'],'FAIL')
        self.assertIs(high['gravity_checks_satisfied'],False)
        self.assertNotIn('stiffener_composite_compression',self.checks(high))

    def test_continuous_weld_short_length_alternative_boundary(self):
        at=self.result(stiff_weld_length=20.)
        below=self.result(stiff_weld_length=19.999999)
        self.assertEqual(self.checks(at)['stiff_weld_length_min']['status'],'PASS')
        self.assertEqual(self.checks(below)['stiff_weld_length_min']['status'],'FAIL')
        # Dimensional acceptance of a short continuous line does not assert
        # resistance; the20mm line is grossly insufficient under45kN.
        self.assertIs(at['gravity_checks_satisfied'],False)
        self.assertEqual(at['status'],'GRAVITY_RESISTANCE_FAILURE')

    def test_other_profile_family_is_preserved_then_rejected_as_direct_domain(self):
        c=replace(self.c,beam=replace(self.c.beam,family='HP'))
        loaded=BeamDirectSeat.from_dict(c.to_dict())
        self.assertEqual(loaded.beam.family,'HP')
        r=evaluate(loaded)
        self.assertEqual(r['status'],'OUTSIDE_SCOPE');self.assert_incomplete(r)

    def test_square_relief_cannot_be_smaller_than_nominal_support_root(self):
        at=self.result(stiff_clip=12.)
        below=self.result(stiff_clip=11.999999)
        one=self.result(stiff_clip=1.)
        self.assertIs(at['gravity_checks_satisfied'],True)
        for r in (below,one):
            self.assertIs(r['gravity_checks_satisfied'],False)
            self.assertTrue(any(row['category']=='GEOMETRY' and row['status']=='FAIL' and
                'clip' in row['id'] for row in r['checks']),
                'Declared square relief must clear nominal support root radius')

    def test_larger_radius_is_not_satisfied_by_stale_square_relief(self):
        r=self.result(stiff_clip=12.,support_radius=12.000001)
        self.assertIs(r['gravity_checks_satisfied'],False)
        self.assertTrue(any(row['category']=='GEOMETRY' and row['status']=='FAIL' and
            'clip' in row['id'] for row in r['checks']))

    def test_weld_length_must_fit_intact_body_between_two_reliefs(self):
        at=self.result(stiff_weld_length=341.4)
        above=self.result(stiff_weld_length=341.400001)
        self.assertIs(at['gravity_checks_satisfied'],True)
        self.assertIs(above['gravity_checks_satisfied'],False)
        self.assertTrue(any(row['category']=='GEOMETRY' and row['status']=='FAIL' and
            'weld' in row['id'] and ('length' in row['id'] or 'body' in row['id']) for row in above['checks']),
            'Usable weld line must fit H381.4 minus2clips20 =341.4mm')


if __name__ == '__main__':unittest.main()
