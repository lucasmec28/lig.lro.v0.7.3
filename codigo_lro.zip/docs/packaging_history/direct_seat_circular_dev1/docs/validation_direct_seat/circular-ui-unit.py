"""Circular UI helper/callback tests; fresh evidence for schema2, not old-slot test approval."""
from copy import deepcopy
from dataclasses import replace
import json
from pathlib import Path
import sys
import unittest

ROOT=Path(__file__).resolve().parents[2]
LOG_DIR=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from lro import beam_direct_seat_ui as ui
from lro.beam_direct_seat import evaluate,presets
from lro.beam_on_beam import presets as old_presets

BASE=next(iter(presets().values()))


class Upload:
    def __init__(self,payload): self.payload=payload
    def getvalue(self): return self.payload


class UIHelperTests(unittest.TestCase):
    def setUp(self):
        self.original=ui.st.session_state
        self.state={}
        ui.st.session_state=self.state
        ui.seed(BASE)

    def tearDown(self): ui.st.session_state=self.original

    def upload(self,value):
        payload=value if isinstance(value,bytes) else json.dumps(value,ensure_ascii=False).encode()
        self.state[ui.PREFIX+'upload']=Upload(payload)
        ui.load_project()

    def test_seed_and_force_preserve_precision_and_subnormal(self):
        c=replace(BASE,N=1e-323,V=25595.35650000013,applied_moment_y=-12.345678901,
                  torsion=-.00123456789,upper_hole=18.,
                  beam=replace(BASE.beam,name='W medida',bf=128.123456789,source='Dimensões medidas'))
        ui.seed(c)
        self.assertEqual({key:ui._force(key) for key in ui.LOAD_UNITS},
                         {key:getattr(c,key) for key in ui.LOAD_UNITS})
        self.assertEqual(self.state[ui.PREFIX+'beam_name'],ui.CUSTOM)
        self.assertEqual(self.state[ui.PREFIX+'beam_bf'],c.beam.bf)
        self.assertEqual(self.state[ui.PREFIX+'upper_hole'],18.)
        self.assertFalse(evaluate(c)['global_pass'])

    def test_lossless_valid_import_and_export_canonical_reconstruction(self):
        c=replace(BASE,N=-123.123456789,reference_x=-.00123456789,
                  upper_washer_diameter=33.123456789,rotational_detail_confirmed=True,project='Importado')
        self.upload(c.to_dict())
        self.assertNotIn(ui.PREFIX+'import_error',self.state)
        proposed=ui._proposed_ui_state(c)
        self.assertTrue(all(self.state[k]==v for k,v in proposed.items()))
        self.assertEqual(ui._force('N'),c.N)
        self.assertEqual(self.state[ui.PREFIX+'reference_x'],c.reference_x)
        self.assertEqual(self.state[ui.PREFIX+'upper_washer_diameter'],c.upper_washer_diameter)
        self.assertTrue(self.state[ui.PREFIX+'rotational_detail_confirmed'])
        native=c.to_dict()
        self.assertEqual(json.loads(json.dumps(native,allow_nan=False)),native)

    def test_invalid_and_legacy_imports_are_atomic(self):
        before={k:deepcopy(self.state[k]) for k in ui._draft_keys()}
        wrong=deepcopy(BASE.to_dict());wrong['connection_type']='other'
        missing=deepcopy(BASE.to_dict());del missing['connection']['upper_hole']
        extra=deepcopy(BASE.to_dict());extra['result']={'global_pass':True}
        nonfinite=deepcopy(BASE.to_dict());nonfinite['connection']['reference_x']=float('nan')
        duplicate=json.dumps(BASE.to_dict()).replace('"schema_version": 2','"schema_version": 3, "schema_version": 2').encode()
        for value in (wrong,missing,extra,nonfinite,duplicate,b'{',b' '*200001,
                      next(iter(old_presets().values())).to_dict(),
                      (ROOT/'tests/fixtures/beam_direct_seat_slotted_0944.json').read_bytes()):
            with self.subTest(kind=type(value).__name__):
                self.upload(value)
                self.assertIn(ui.PREFIX+'import_error',self.state)
                self.assertEqual({k:self.state[k] for k in ui._draft_keys()},before)

    def test_unrepresentable_widget_precision_rejection_is_atomic(self):
        before=deepcopy(self.state)
        c=replace(BASE,beam=replace(BASE.beam,mass=9007199254740993))
        with self.assertRaisesRegex(ValueError,'beam.mass'):
            ui.seed(c)
        self.assertEqual(self.state,before)

    def test_rotation_signature_tracks_current_physical_data_without_notes(self):
        basis=ui._physical_signature(self.state)
        self.state[ui.PREFIX+'notes']='Somente observações'
        self.state[ui.PREFIX+'project']='Nova identificação'
        self.state[ui.PREFIX+'rotational_detail_confirmed']=True
        self.assertEqual(ui._physical_signature(self.state),basis)
        self.state[ui.PREFIX+'bolt_pitch']=72.
        self.assertNotEqual(ui._physical_signature(self.state),basis)

    def test_numeric_overflow_is_rejected_before_export(self):
        self.state[ui.PREFIX+'V_kgf']=1e308
        with self.assertRaises(ArithmeticError): ui._force('V')


if __name__=='__main__':
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(UIHelperTests)
    with (LOG_DIR/'CIRCULAR_UI_UNIT.log').open('w',encoding='utf-8') as stream:
        result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    print((LOG_DIR/'CIRCULAR_UI_UNIT.log').read_text(encoding='utf-8'),flush=True)
    raise SystemExit(0 if result.wasSuccessful() else 1)
