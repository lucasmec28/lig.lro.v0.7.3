"""One diagnostic attempt, bounded30s; no test pass is inferred from timeout."""
from pathlib import Path
import os
import subprocess
import sys

root = Path(__file__).resolve().parents[2]
log_dir = Path(__file__).resolve().parent
env = dict(os.environ, TEMP=str(root/'test-temp'), TMP=str(root/'test-temp'), PYTHONUTF8='1')
code = r'''
import faulthandler
faulthandler.enable()
faulthandler.dump_traceback_later(10,repeat=False)
print('STAGE imports',flush=True)
from streamlit.testing.v1 import AppTest
print('STAGE before AppTest.from_string',flush=True)
at=AppTest.from_string('from lro.beam_direct_seat_ui import render\nrender()',default_timeout=15)
print('STAGE before at.run',flush=True)
at.run()
print('STAGE after at.run',flush=True)
assert not at.exception,[x.message for x in at.exception]
print('PASS render',flush=True)
'''
try:
    result=subprocess.run([sys.executable,'-B','-u','-c',code],cwd=root,env=env,
                          stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=30)
    output=result.stdout.decode('utf-8',errors='replace')
    outcome='PROCESS_EXIT='+str(result.returncode)
except subprocess.TimeoutExpired as exc:
    output=(exc.stdout or b'').decode('utf-8',errors='replace')
    outcome='INCONCLUSIVE: bounded30s timeout, no functional verdict.'
    result=None
(log_dir/'direct-seat-ui-trace.log').write_text(output+'\n'+outcome+'\n',encoding='utf-8')
print(output+'\n'+outcome,flush=True)
raise SystemExit(result.returncode if result else 124)
