"""Fresh circular-hole UI integration; bounded local socket-only AppTest."""
from pathlib import Path
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
LOG = Path(__file__).resolve().parent / 'CIRCULAR_UI_SMOKE.log'
(ROOT/'test-temp').mkdir(exist_ok=True)
env = dict(os.environ, TEMP=str(ROOT/'test-temp'), TMP=str(ROOT/'test-temp'), PYTHONUTF8='1')
code = r'''
from copy import deepcopy
from dataclasses import replace
import json
from pathlib import Path
from streamlit.runtime.memory_media_file_storage import MemoryMediaFileStorage
from streamlit.testing.v1 import AppTest
from lro import beam_direct_seat_ui as ui
from lro.beam_direct_seat import presets, FAMILY, CONNECTION_TYPE, SCHEMA_VERSION
from lro.guided_selection import FAMILIES
from lro.models import KGF
files={}
original=MemoryMediaFileStorage.load_and_get_id
def tap(storage,*args,**kwargs):
    identifier=original(storage,*args,**kwargs)
    files[identifier]=storage._files_by_id[identifier].content
    return identifier
MemoryMediaFileStorage.load_and_get_id=tap
def clean(at): assert not at.exception,[x.message for x in at.exception]
def export(at):
    widget=next(w for w in at.get('download_button') if w.label=='Salvar projeto de apoio direto .json')
    return json.loads(files[Path(widget.proto.url).name.rsplit('.',1)[0]])
def current(at): return deepcopy(at.session_state[ui.STATE+'project'])
def load(at,value):
    payload=value if isinstance(value,bytes) else json.dumps(value,ensure_ascii=False).encode()
    at.file_uploader[0].upload('apoio.json',payload,'application/json').run();clean(at)
    next(w for w in at.button if w.label=='Carregar apoio direto').click().run();clean(at)
assert FAMILIES[-1].route_select_value==FAMILY
c=next(iter(presets().values()))
old=json.loads(Path('tests/fixtures/beam_direct_seat_slotted_0944.json').read_text(encoding='utf-8'))
at=AppTest.from_string("import streamlit as st\nroute=st.selectbox('Rota de ensaio',['Direto','Outra'],key='test_route')\nif route=='Direto':\n from lro.beam_direct_seat_ui import render\n render()\nelse: st.write('Outra família')",default_timeout=25)
at.session_state['_beam_direct_seat_project']=deepcopy(old)
print('STAGE initial circular render',flush=True)
at.run();clean(at)
assert current(at)==c.to_dict()==export(at)
assert current(at)['schema_version']==SCHEMA_VERSION==2
assert current(at)['connection_type']==CONNECTION_TYPE=='beam_direct_seat_standard_holes'
assert at.session_state['_beam_direct_seat_project']==old
assert not at.session_state[ui.STATE+'result']['global_pass']
assert not at.success
assert at.number_input(key=ui.PREFIX+'upper_hole').value==18.
assert at.number_input(key=ui.PREFIX+'support_hole').value==18.
assert at.number_input(key=ui.PREFIX+'upper_washer_diameter').value==33.
assert at.number_input(key=ui.PREFIX+'lower_washer_diameter').value==33.
keys={w.key for w in (*at.number_input,*at.selectbox)}
assert not any(ui.PREFIX+k in keys for k in ('slot_width','slot_length','cover_length','cover_width','cover_thickness','cover_hole','cover_steel','required_travel'))
assert any('Especificação proposta a conferir na execução' in w.value for w in at.caption)
assert any('corpo' in w.value and 'recortes de extremidade' in w.value for w in at.caption)
print('STAGE reject actual old slot draft',flush=True)
before=current(at)
load(at,old)
assert 'oblongos' in at.session_state[ui.PREFIX+'import_error']
assert current(at)==before==export(at)
print('STAGE native import/export full precision',flush=True)
custom=replace(c,V=25595.35650000013,N=-12.345678901,applied_moment_y=-.00123456789,
               torsion=1e-323,upper_hole=18.123456789,upper_washer_diameter=33.987654321,
               notes='Importação de precisão, sem conversão de topologia')
load(at,custom.to_dict())
assert current(at)==custom.to_dict()==export(at)
assert ui.PREFIX+'import_error' not in at.session_state
assert not at.session_state[ui.STATE+'result']['global_pass']
assert not at.success
print('STAGE edit/recalc and route return',flush=True)
at.number_input(key=ui.PREFIX+'N_kgf').set_value(2.123456789).run();clean(at)
assert current(at)['connection']['N']==2.123456789*KGF
assert current(at)['connection']['applied_moment_y']==custom.applied_moment_y
assert current(at)['connection']['torsion']==custom.torsion
assert current(at)==export(at)
before=current(at)
at.selectbox(key='test_route').set_value('Outra').run();clean(at)
at.selectbox(key='test_route').set_value('Direto').run();clean(at)
assert current(at)==before==export(at)
assert at.session_state['_beam_direct_seat_project']==old
assert not at.session_state[ui.STATE+'result']['global_pass']
assert not at.success
print('PASS fresh circular render, actual upload callbacks, native download bytes, old-slot rejection, schema2, precision, recalc and route preservation',flush=True)
'''
try:
    result=subprocess.run([sys.executable,'-B','-u','-c',code],cwd=ROOT,env=env,
                          stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=55)
except subprocess.TimeoutExpired as exc:
    text=(exc.stdout or b'').decode('utf-8',errors='replace')+'\nINCONCLUSIVE: bounded55s timeout.\n'
    LOG.write_text(text,encoding='utf-8');print(text,flush=True);raise SystemExit(124)
text=result.stdout.decode('utf-8',errors='replace')
LOG.write_text(text+'\nPROCESS_EXIT='+str(result.returncode)+'\n',encoding='utf-8')
print(text,flush=True)
raise SystemExit(result.returncode)
