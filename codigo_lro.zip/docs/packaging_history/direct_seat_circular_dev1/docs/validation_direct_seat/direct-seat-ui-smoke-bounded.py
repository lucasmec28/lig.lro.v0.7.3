"""Bounded real Streamlit smoke; logs evidence without modifying app data."""
from pathlib import Path
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT
LOG = Path(__file__).resolve().parent / 'direct-seat-ui-smoke.log'
env = dict(os.environ, TEMP=str(ROOT / 'test-temp'), TMP=str(ROOT / 'test-temp'), PYTHONUTF8='1')
(ROOT / 'test-temp').mkdir(exist_ok=True)
code = r'''
from copy import deepcopy
from dataclasses import replace
import sys
sys.path.insert(0,'.')
print('STAGE imports',flush=True)
from streamlit.testing.v1 import AppTest
from lro.beam_direct_seat import presets,FAMILY
from lro.guided_selection import FAMILIES
from lro.models import KGF
assert FAMILIES[-1].route_select_value == FAMILY
c=next(iter(presets().values()))
print('STAGE harness creation',flush=True)
at=AppTest.from_string("import streamlit as st\nroute=st.selectbox('Rota de ensaio',['Direto','Outra'],key='test_route')\nif route=='Direto':\n from lro.beam_direct_seat_ui import render\n render()\nelse: st.write('Outra família')",default_timeout=25)
at.run()
print('STAGE first render',flush=True)
assert not at.exception,[x.message for x in at.exception]
assert at.session_state['_beam_direct_seat_project']==c.to_dict()
assert not at.session_state['_beam_direct_seat_result']['global_pass']
assert not at.success
at.number_input(key='bds_N_kgf').set_value(2.123456789).run()
assert not at.exception,[x.message for x in at.exception]
assert at.session_state['_beam_direct_seat_project']['connection']['N']==2.123456789*KGF
assert not at.session_state['_beam_direct_seat_result']['global_pass']
before=deepcopy(at.session_state['_beam_direct_seat_project'])
at.selectbox(key='test_route').set_value('Outra').run()
at.selectbox(key='test_route').set_value('Direto').run()
assert not at.exception,[x.message for x in at.exception]
assert at.session_state['_beam_direct_seat_project']==before
assert at.number_input(key='bds_required_travel').value is None
print('PASS real render, recalc of retained outside-scope N, route/draft preservation, unknown travel, no global approval',flush=True)
'''
try:
    result = subprocess.run([sys.executable, '-B', '-u', '-c', code], cwd=WORK, env=env,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=55)
except subprocess.TimeoutExpired as exc:
    output = exc.stdout or b''
    text = output.decode('utf-8', errors='replace') + '\nINCONCLUSIVE: bounded subprocess timeout55s; not a functional test verdict.\n'
    LOG.write_text(text, encoding='utf-8')
    print(text, flush=True)
    raise SystemExit(124)
text = result.stdout.decode('utf-8', errors='replace')
LOG.write_text(text + '\nPROCESS_EXIT=' + str(result.returncode) + '\n', encoding='utf-8')
print(text, flush=True)
raise SystemExit(result.returncode)
