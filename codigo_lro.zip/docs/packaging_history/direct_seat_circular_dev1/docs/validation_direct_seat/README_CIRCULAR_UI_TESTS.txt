Fresh circular UI verification, schema2.

From the repository, use the Python3.12 environment with requirements-dev.txt installed:
  .\.venv\Scripts\python.exe -B docs\validation_direct_seat\circular-ui-unit.py
  .\.venv\Scripts\python.exe -B docs\validation_direct_seat\circular-ui-smoke-bounded.py

The scripts derive the repository from their own path; .venv can be elsewhere by substituting its interpreter path. Streamlit1.65 was used. The smoke sets TEMP/TMP inside repository/test-temp and is bounded55 seconds. Python asyncio needs local loopback sockets; the restricted sandbox was previously unable to create its socketpair, so this fresh circular smoke used one approved unsandboxed execution.

The six helper methods passed, with nine invalid-import subcases. The real AppTest passed36 executed assertions (28 main and eight exception checks), with eight reruns: the original four-step render/edit/away/return cycle plus four reruns for two actual upload/load callbacks. Native downloads were read through real Streamlit media storage. The old slot fixture was rejected explicitly without changing the current project or old saved namespace.

No old-slot passed log is used as proof of the circular variant. The harness renders the new UI with a dummy other route; packaged-app and browser-pixel verification are separate. No test approves fabrication, axial release, rotation or the complete structural connection. The actual recut member stability closure remained pending at this tested snapshot and is undergoing separate analysis.
