UI diagnostic verification

The scripts derive the repository from their own file location, independent of the caller current directory. Use an existing Python3.12 environment with requirements-dev.txt installed (tested: Streamlit1.65).

From the repository in PowerShell:
  .\.venv\Scripts\python.exe -B docs\validation_direct_seat\direct-seat-ui-unit.py
  .\.venv\Scripts\python.exe -B docs\validation_direct_seat\direct-seat-ui-smoke-bounded.py

Replace the interpreter path with the available environment when .venv is elsewhere. The bounded smoke uses that same interpreter for its child process, sets TEMP/TMP under this repository's test-temp folder, and terminates after55 seconds.

The local Python asyncio socketpair must be permitted. In the restricted execution environment it stalled in socket.accept before app code ran; that attempt is inconclusive. The approved unsandboxed smoke passed all11 assertions and4 reruns; the same test passed again after adding only the visible requirements caption. The earlier passed log/receipt are retained separately. The optional direct-seat-ui-trace-bounded.py records a traceback after10 seconds and stops after30 seconds; do not loop retries.

The helper suite passed6 test methods, including8 invalid-import subcases. These exercise callbacks/serialization/precision independently of rendering. AppTest rendered the isolated new UI with a dummy other route, not the full dispatcher or browser pixels. Browser verification was unavailable because the CUA Windows platform helper did not initialize.

The retained logs and UI_TEST_RECEIPT.json document the observed attempts. Running scripts again replaces their corresponding local log. No result approves the structural connection, sliding/rotation detail or fabrication.
