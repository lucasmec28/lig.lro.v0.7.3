# Viga sobre viga com apoio direto e furos circulares

Revisao para revisao na copia revised0946-circular-direct-seat. O nucleo proprio
tem schema2, connection_type beam_direct_seat_standard_holes e componente
0.9.46-direct-seat-circular-review-dev.1. Perfis, motores e JSON legados ficam
preservados. Projetos de outra identidade nao sao convertidos automaticamente.

A conclusao e condicional aos requisitos propostos de fabricacao e montagem.
A capacidade de 328,35 kN descreve o corpo cruciforme idealizado: o efeito dos
recortes localizados e a compatibilidade das faixas na barra real permanecem
pendentes de fundamentacao. A ligacao completa nao esta aprovada; global_pass
e engineering_approved permanecem false. Testes de software nao qualificam a
engenharia ou a execucao.

## Modelo de gravidade e acoes

A mesa inferior da W360x39 apoia diretamente na mesa superior da W410x38,8.
x segue a viga superior, y a viga de apoio e z e vertical. A extremidade fisica
da W360 esta em x=+70 mm; a alma superior e o par proposto de enrijecedores da
W410 estao no plano y=0. O caminho declarado e alma W360, mesa inferior W360,
mesa superior W410, alma e par de enrijecedores W410. Nao existe chapa
intermediaria nem solda sob a viga superior nesta familia.

A Figura A1(c) do ASI DG6 identifica a tipologia, conforme conferencia do
revisor do pai e aceite do usuario. A figura e uma elevacao; nao impomos uma
contagem de parafusos deduzida dela. A presenca de quatro parafusos nao invalida
o caminho de gravidade por si. As resistencias e fatores usados sao da NBR.

V=2610 kgf ja em ELU=25595,3565 N, N=My=Tz=0, referencia da reacao x=0.
A conversao kgf-N aplica somente9,80665. O minimo resistente NBR6.1.5.2 para
a viga de piso e um caso separado de45000 N na mesma direcao descendente;
nao altera ou remajora a acao ELU fornecida. Valores nao nulos de N, My, Tz
ou referencia excentrica sao preservados e retornam fora do escopo. V deve
ser descendente positivo. V nao e corte dos parafusos verticais.

## Geometria e materiais propostos

W360: d353, bf128, tw6,5, tf10,7 mm. W410: d399, bf140, tw6,4, tf8,8 mm.
Vigas ASTM A572 Gr50, fy345 MPa; enrijecedores ASTM A36, fy250 MPa;
consumivel classe70, fuw485 MPa. Identificacao real dos produtos a conferir.
E=200000 MPa; gamma_a1=1,10 e gamma_a2=gamma_w2=1,35, fixos no nucleo.

Quatro M16 nos centros x=+/-35 e y=+/-40 mm, passo70/gabarito80.
Furos padrao circulares diametro18 mm na mesa inferior da W360 E na mesa
superior da W410. Arruelas circulares externas diametro33 mm em ambas.
Classes, furos internos, cabecas/porcas, comprimento e aperto reais permanecem
a conferir; dimensoes nominais de envelope nao dimensionam a retencao.

Os centros70/80 superam2,7db=43,2 mm. As distancias livres entre bordas dos
furos sao52/62 mm, maiores que db16. O menor ramo de espacamento maximo
adotado e min(14t,180)=123,2 mm, sem presumir pintura ou ambiente do projeto.
A borda longitudinal superior e35 mm contra22 mm, margem13; borda lateral
superior24 contra22, margem2. Borda transversal da W41035 contra22. As
extremidades fisicas da W410 e suas distancias aos furos devem ser conferidas.

R nominal12 mm nas duas vigas, inferido de(h-d')/2 no catalogo Gerdau09/2017:
W360 h332/d'308 e W410 h381/d'357. O raio medido nao foi atestado.
Tangencias nominais: superior |y|15,25; apoio |x|15,20 mm. Limite de raio
externo de ferramenta mais folga:24,75 mm no lado W360 e19,80 no lado W410.
Proposta raio17+folga2 deixa0,80 mm nominal no lado governante.

Arruela superior diametro33: margem8,25 mm ate a tangencia,7,50 ate a borda
lateral e18,50 ate o fim. Arruela inferior:3,30 mm ate a tangencia e18,50 ate
a borda transversal. A ferramenta envolve cabeca ou porca; nao precisa
circundar a arruela. O filtro raio>=db/2 e somente condicao necessaria da haste,
sem atestar dimensoes da ferragem real. Insercao axial e sequencia a conferir.

## Enrijecedores contato e soldas

Par proposto8x60 mm, altura nominal381,4 mm, y=0, ligado a alma e a ambas
as mesas no ramo adotado, incluindo a mesa carregada. Ajuste fitted e preparo
usinado/compatibilizado das interfaces creditadas sao requisitos propostos,
nao observacoes de obra. Limpeza ou remocao de pintura sozinhas nao estabelecem
o contato usinado/ajustado exigido pelo caminho NBR6.6.2. NBR6.6.3 para
superficies nao usinadas nao pode ser atendido fingindo preparacao existente.

Envelopes de alivio quadrado20x20 mm nas duas extremidades da raiz, com c>=R
nominal para este contorno proposto. Outro contorno deve ser fundamentado por
sua geometria real. Area ajustada proposta40x8=320 mm2 por extremidade, depois
dos recortes; dimensoes e ajuste real a conferir. Largura disponivel66,8 mm;
a ponta do enrijecedor fica em|x|63,2. A projecao restante6,8 mm nao recebe
uma carga ou momento automaticamente. O recorte20 nao e vao simplesmente
apoiado demonstrado.

Filetes a alma: perna5 mm, duas linhas efetivas continuas150 mm por grupo,
no corpo intacto381,4-2x20=341,4 mm. Menor espessura rege Tabela11; a opcao de
filete continuo curto limita perna de calculo a25% de seu comprimento.
Verificacao elastica de garganta por comprimento usa o caso integral45 kN,
eccentricidade limitada pela largura60 mm e grupo simetrico. Nao soma essa
capacidade a capacidade de contato e nao resolve contato C ou tensoes Ti.

## Resultados condicionais implementados

| Componente | Caso resistente | Resistencia nominal condicionada |
| --- | --- | --- |
| Alma W360 escoamento local | 45,00 kN | 59,986875 kN |
| Alma W360 enrugamento | 45,00 kN | 135,085186 kN |
| Alma W410 escoamento local | 45,00 kN | 48,576000 kN |
| Alma W410 enrugamento | 45,00 kN | 119,689788 kN |
| Extremidade fitted cada peca | 45,00 kN integral | 106,666667 kN |
| Corpo cruciforme idealizado | 45,00 kN | 328,353509 kN |
| Garganta do grupo a alma | 390 N/mm | 762,103975 N/mm |

Limites de alma NBR5.7.3/5.7.4: menor ramo de extremidade, ln tendendo a zero,
k>=tf, somente compressao local transversal centrada em W laminado. Nao
se inventa comprimento fisico de contato nem pressao uniforme do retangulo
de parafusos. Cada extremidade fitted e cada grupo de solda recebe45 kN no
ensaio de componente, sem divisaoV/2 e sem afirmar que foi resolvido C.

NBR5.7.9.4/5.3: corpo idealizado do par mais faixa de alma12tw, eixoY no plano
da alma inferior, Le0,75h. Usa fy minimo250 para resistencia e fy maximo345
para menor envelope AL da Tabela4; somente se esse gate permitir Aef=Ag.
A=1451,52 mm2, Iy=1347828,1216 mm4, Le=286,05 mm; o valor328,35 kN NAO
qualifica a barra real recortada. As faixas externas nos recortes nao estao
ligadas a alma naquela secao; a compatibilidade e rigidez necessarias para
o modelo composto em toda a altura devem ser fundamentadas. Um limite
obtido substituindo apenas A/Iy nao cria esses vinculos fisicos.

## Montagem rotacao e limites

As flags fitted, preparo e fixacoes indicam especificacao proposta. Retirar
um requisito do modelo leva a pendencia, sem calcular resistencias. Aprovar
montagem exige conferir os produtos, preparo, raio, contornos, soldas,
ferragens e ferramentas reais e as tolerancias de borda/acesso.

A compatibilidade de rotacao da extremidade permanece pendente e nao e,
por si, uma falha resistente demonstrada dos componentes de gravidade.
Furos circulares nao demonstram liberacao axial do apoio. O nucleo registra
axial_release_verified=false; nao resolve restricao axial, C/Ti ou alavanca.
N=0 e uma acao de entrada, nao prova da liberacao fisica do sistema.

Esta distribuicao e REVISAO PARA REVISAO. Nao qualifica acao horizontal,
tracao/retencao, inversao de V, fadiga, estabilidade global das vigas ou do
sistema, nem fabrica ou montagem executada. A fundamentacao da barra real
recortada e a compatibilidade de montagem e rotacao continuam essenciais.
