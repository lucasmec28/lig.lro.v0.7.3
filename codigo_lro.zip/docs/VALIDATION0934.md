# Validação da fonte 0.9.34

## Resultado

Os revisores independentes deram GO ao motor limitado de tração estática e às saídas da fonte. Há uma limitação herdada de infraestrutura: o teste de contato de parafuso em `test_axial_double_angle.py` exige `next_connection_scope/bolt_bearing_oracle.json`, arquivo externo ausente da entrega recebida. Ele permanece registrado como falha por arquivo indisponível, sem reconstrução, substituição ou contagem como aprovação.

O pacote extraído isoladamente tem aceitação própria, posterior ao congelamento desta fonte. Este documento não declara publicação, implantação, aprovação global ou liberação de fabricação.

## Suíte completa e reruns

A execução completa, em quatro processos com arquivos de teste disjuntos, cobriu **5.198 casos distintos em 144 arquivos**. O resultado bruto foi **5.154 aprovados, 44 falhas, zero erros de coleta e zero pulados**, em cerca de 17 minutos e 34 segundos. Todos os módulos de runtime mantiveram os mesmos hashes durante a execução.

Das 44 falhas, 43 pertenciam às expectativas de catálogo ou de rótulo visual em dois testes históricos. As listas canônicas e os índices antigos foram mantidos; somente as expectativas de apresentação/adição das 19 famílias foram atualizadas. A nova família continua sendo a 19ª, sem criar outra rota. Os 130 casos do guia e os 20 casos do seletor W foram reexecutados e passaram. As falhas historicamente obsoletas foram reproduzidas primeiro no 0.9.33 imutável. O rótulo de canto novo era uma mudança intencional de 0.9.34: os 130 casos originais passavam no 0.9.33.

O conjunto final de observações, deduplicado por caso, tem **5.197 aprovados e uma falha por oráculo externo indisponível**, zero falhas inesperadas e zero casos pulados. Os reruns se sobrepõem à suíte e não aumentam a cobertura de 5.198. Não se declara uma segunda execução completa integralmente verde. Logs, XML originais, hashes antes/depois e o histórico de cada caso estão em `validation0934/`; `CASE_LEDGER0934.json` identifica a evidência exata de cada resultado final.

A tentativa sequencial inicial foi interrompida e está preservada como tentativa incompleta. Não entra nas contagens da suíte completa.

## Verificação focal e independente

- Execuções focais próprias: 212 testes de canto, depois 42 testes do motor final e 38 testes da correção de alcance dos grupos longos. São execuções sobrepostas, sem soma às contagens anteriores.
- Revisão independente do motor: 88.979 comparações numéricas escalares, 251 observações de persistência nativa, 27 casos de parâmetros, 105 presets antigos nas 19 rotas e sete importações soldadas antigas. Os 202 testes focais independentes passaram.
- Grupos longos nas rotas anteriores: 15 comparações independentes do estado diagnóstico e 18 casos de fronteira. Os valores locais continuam disponíveis acima de 950 mm; o alcance deixa de ser aprovado. Exatamente 950 mm continua admitido.
- Revisão independente de saídas: 17 cenários de downloads reais do aplicativo, seis grupos de callbacks, 43 testes de UI, quatro estados de UI dos grupos longos, 53 páginas Word revisadas e sete SVG rasterizados independentemente. O relatório resumido tem 15 componentes físicos.

Recibos completos: `ENGINE_ACCEPTANCE0934.json` e `independent_outputs0934/SOURCE_OUTPUT_ACCEPTANCE.json`. Os testes de UI usam Streamlit AppTest e callbacks reais; não se confundem com cliques no DOM de navegador, diálogo de download do sistema operacional ou interação com clipboard.

## Limites de engenharia

Somente o escopo estático ordinário qualificado: uma linha de furos-padrão, contato direto e 1L ou 2L-T simétricas no canto. Compressão, fadiga, sismo, cargas espaciais independentes, folgas/espaçadores e distribuição longa não recebem aprovação indevida. A idealização nominal de extremidade não prova equilíbrio espacial físico. As telas de tensão no corpo perfurado são diagnósticos nominais suplementares; não são solução pontual de contato nem prova intervalar de todos os extremos. Montagem, WPS, execução e estabilidade global continuam separadas.

## Emenda restrita do replay portátil

O primeiro pacote revelou uma hipótese excessivamente estrita no teste portátil: os SVG das duas rotas parafusadas antigas têm um `dc:date` gerado e IDs aleatórios de definições. A emenda aceita apenas esse texto de data e a renomeação bijetiva dos IDs gerados e suas referências exatas; todos os demais bytes SVG continuam iguais. SVG do canto novo, PNG, projeto/resultados nativos e XML/mídia Word conservam comparação exata. Quatro pares antigos têm pixels RGBA idênticos a144dpi. Duas variações permitidas foram aceitas e cinco mutações significativas rejeitadas.

O motor, UI, geradores, dependências e todos os testes da suíte permanecem byte-idênticos. Não se repetiram nem somaram os5.198 casos. A fonte anterior, seus manifestos, o primeiro pacote e a falha inicial foram preservados. A nova cópia exige reconstrução do pacote e replay portátil sobre seu novo hash. Evidência e limites exatos: `HARNESS_AMENDMENT0934.json`.
