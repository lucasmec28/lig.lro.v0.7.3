PORTABLE INDEPENDENT 4E COLUMN-DEMAND REPLAY
Frozen 2026-10-12. Method: endplate-4e-column-flange-demand-20261012-v1.

Run in a fresh Python interpreter with the APP's declared dependencies:
  python replay_4e.py /path/to/actual/four-root/APP /path/to/evidence

The APP argument contains exactly the delivered app.py, codigo_lro.zip,
README.md and requirements.txt. This replay calls the unmodified delivered
app.py prepare_code() and its archive digest, checks that the same proof
files are shipped inside codigo_lro.zip, then imports only that extracted
runtime. Evidence must be written outside the APP directory.

For initial source qualification only:
  python replay_4e.py /path/to/source /path/to/evidence --source
This mode is explicitly reported SOURCE_ONLY. It is not packaged-APP proof.
There is no generator, update-expected or accept-current mode.

The four files to ship together at docs/independent_4e_column_demands are:
  replay_4e.py
  expected.json
  PORTABLE_MANIFEST.json
  README.txt
No frozen source tree, external fixture directory or optional audit companion
is required. No absolute construction-time path is used by the replay.

WHAT IS FROZEN
expected.json contains five full literal connection-input templates, explicit
per-case overrides, each input digest, 61 exact engine/native commitments and
12 compact/detailed Word text commitments. It also contains independent hand
force/capacity values per calculated moment case and exact source hashes for
end_plate.py, end_plate_report.py and column_checks.py. Input defaults and
presets are not used when replaying. All imported lro origins are required to
be inside the shipped payload, and their actual hashes are recorded.

Coverage:
- 36 signed N/M/V and top/symmetric 4E inputs, including original and minimum
  force cases with separate complete governing rows.
- 12 synthetic arithmetic capacities between old and corrected demands,
  each changing only the intended local failure from pass to fail.
- 6 synthetic pfo40 cases where source-based correction removes an old local
  failure. No artificial max(old demand,new demand) envelope is introduced.
- Negative-M top-only rejection, an unresolved minimum-force scope case and
  pure moment.
- Exact unchanged 4ES, 8ES and two PINNED engine/native/report-text outputs.
- Native roundtrips and reimports with forged approval/saved results.

VERSION NORMALIZATION
Only the native top-level app_version is removed after confirming it equals
models.VERSION. Only that exact VERSION string is replaced by {APP_VERSION}
in report text. A 0.9.40 global integration version can therefore replay.
No demand, capacity, source label, method revision, input value, result,
assumption, tolerance, status or mechanics is normalized.

ORIGIN AND INDEPENDENCE
The literal inputs were frozen from the separately reviewed 4E candidate on
2026-10-12 after independent review. The corrected expressions were checked
against hand calculations, signed/minimum cases, and the visually inspected
NBR 8800:2024 corrected-2025 printed pp.64-65 (PDF86-87). DG39 force-route
proof was visually supplied by the parent source reader (§3.5 p37, §3.7.6
Eq3-48 and Example5.3-1 p132), not newly pixel-inspected by this reviewer.

Ff=abs(M)/(d-tf)+max(N,0)/2; Fc=abs(M)/(d-tf)+max(-N,0)/2.
Yield demand=max(Ff,Fc); crippling demand=Fc.
Yield capacity=1.10*2.5*tfc*fyc*twc/1.10 (k=tfc, ln=0).
Crippling capacity=0.33*twc^2*sqrt(200000*fyc*tfc/twc)/1.10.
The unchanged T/C contact route is checked independently from bolt arms.

Unchanged 4ES/8ES/PINNED hashes and report text were compared exactly with the
frozen0938 baseline during construction. Both directions of synthetic status
change were also checked against that baseline before freezing. The replay
itself never needs or reads the baseline. Full-result/native/text hashes are
regression commitments, not independent normative oracles; the independent
source-based arithmetic checks supplement them. Synthetic sections deliberately
serve arithmetic thresholds, not physical catalog or structural design claims.

LIMITS
This is bounded source/engine/native/report-text acceptance, not a full test
aggregate, browser-pixel or Word pagination/layout gate. It adds no MRE,
column reinforcement, arbitrary rows, thin-plate prying, global stability,
seismic/cyclic, fabrication or structural-project approval. The actual package
must still run this replay; a successful --source run is insufficient to
claim packaged-APP acceptance. Reference PDFs/images are not shipped here.
