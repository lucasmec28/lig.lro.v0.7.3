"""Read-only bounded 4E gate. No expectation generation or acceptance-update mode.
Usage: python replay_4e.py FOUR_ROOT_APP OUTPUT
For source qualification only: python replay_4e.py SOURCE OUTPUT --source
"""
import argparse, copy, dataclasses, hashlib, importlib, json, math, os, runpy, sys
from io import BytesIO
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
P = argparse.ArgumentParser(description=__doc__)
P.add_argument('app'); P.add_argument('output'); P.add_argument('--source', action='store_true')
A = P.parse_args(); APP = Path(A.app).resolve(); OUT = Path(A.output).resolve()
assert not OUT.is_relative_to(APP), 'Evidence OUTPUT must be outside the read-only application'
OUT.mkdir(parents=True, exist_ok=True)
for child in ('mpl','cache'): (OUT/child).mkdir(exist_ok=True)
os.environ.setdefault('MPLCONFIGDIR', str(OUT/'mpl'))
os.environ.setdefault('XDG_CACHE_HOME', str(OUT/'cache'))
def sha(data): return hashlib.sha256(data).hexdigest()
def clean(value):
    if dataclasses.is_dataclass(value): return clean(dataclasses.asdict(value))
    if isinstance(value, dict): return {str(k):clean(v) for k,v in value.items()}
    if isinstance(value, (tuple,list)): return [clean(v) for v in value]
    if isinstance(value, float) and not math.isfinite(value): return {'nonfinite':str(value)}
    if value is None or isinstance(value, (str,int,float,bool)): return value
    raise TypeError(type(value))
def digest(value):
    return sha(json.dumps(clean(value),ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode())
def near(got,want):
    assert math.isclose(got,want,rel_tol=2e-13,abs_tol=1e-8), (got,want)
manifest = json.loads((HERE/'PORTABLE_MANIFEST.json').read_text())
for name, expected in manifest['files'].items():
    data=(HERE/name).read_bytes(); assert len(data)==expected['bytes'] and sha(data)==expected['sha256'], name
commit = json.loads((HERE/'expected.json').read_text())
assert not any(k=='lro' or k.startswith('lro.') for k in sys.modules), 'Start a clean interpreter'
holder=None; root_before=None
if A.source:
    ROOT=APP; mode='SOURCE_ONLY'
else:
    expected_roots={'app.py','codigo_lro.zip','README.md','requirements.txt'}
    assert {p.name for p in APP.iterdir() if p.is_file()}==expected_roots, 'Expected actual four-root APP directory'
    root_before={n:sha((APP/n).read_bytes()) for n in sorted(expected_roots)}
    loader=runpy.run_path(str(APP/'app.py'),run_name='independent_4e_loader')
    assert loader['BUNDLE_NAME']=='codigo_lro.zip'
    archive=(APP/loader['BUNDLE_NAME']).read_bytes()
    assert sha(archive)==loader['BUNDLE_SHA256'], 'Loader/archive mismatch'
    ROOT,holder=loader['prepare_code'](archive,loader['BUNDLE_SHA256']); ROOT=Path(ROOT).resolve()
    mode='ACTUAL_FOUR_ROOT_APP_LOADER'
    # Prove that the replay and commitments in use are the ones actually shipped.
    shipped=ROOT/'docs/independent_4e_column_demands'
    for name, expected in manifest['files'].items():
        assert sha((shipped/name).read_bytes())==expected['sha256'], ('shipped proof mismatch',name)
    assert (shipped/'PORTABLE_MANIFEST.json').read_bytes()==(HERE/'PORTABLE_MANIFEST.json').read_bytes()
source_before={name:sha((ROOT/name).read_bytes()) for name in commit['runtime_sha256']}
assert source_before==commit['runtime_sha256'], 'Reviewed 4E source hash mismatch'
sys.path.insert(0,str(ROOT))
ep=importlib.import_module('lro.end_plate'); rep=importlib.import_module('lro.end_plate_report')
models=importlib.import_module('lro.models')
from docx import Document

def normalized_native(obj):
    native=clean(obj.to_dict()); version=native.pop('app_version')
    assert version==models.VERSION
    return native

def report_text(obj,result,detailed):
    doc=Document(BytesIO(rep.create_report(obj,result,detailed=detailed)))
    texts=[p.text for p in doc.paragraphs]
    texts += [cell.text for table in doc.tables for row in table.rows for cell in row.cells]
    for sec in doc.sections:
        for container in (sec.header,sec.footer):
            texts += [p.text for p in container.paragraphs]
            texts += [cell.text for table in container.tables for row in table.rows for cell in row.cells]
    # Normalize only this exact global version string; all forces, sources,
    # method revisions, capacity expressions and outcomes remain exact.
    return [text.replace(models.VERSION,'{APP_VERSION}') for text in texts]

records=[]; reports_checked=0; hand_cases=0; reductions=0; increases=0
for entry in commit['cases']:
    inputs=copy.deepcopy(commit['base_inputs'][entry['base']]);inputs.update(copy.deepcopy(entry['overrides']))
    assert digest(inputs)==entry['input_sha256'], ('literal input mismatch',entry['id'])
    envelope={'schema_version':1,'connection_type':'end_plate','connection':inputs}
    obj=ep.EndPlate.from_dict(envelope)
    assert clean(ep.connection_inputs(obj))==inputs, ('input defaults/identity changed',entry['id'])
    result=ep.evaluate(obj); native=normalized_native(obj)
    assert digest(result)==entry['result_sha256'], ('engine result mismatch',entry['id'])
    assert digest(native)==entry['native_sha256'], ('native mismatch',entry['id'])
    assert result.status==entry['status'], entry['id']
    assert ep.method_revision(obj)==entry['method_revision'], entry['id']
    # Re-import a stale/forged result: inputs alone determine the new outcome.
    forged=copy.deepcopy(envelope);forged['verification']={'approved':True,'status':'FORGED','checks':[],'method_revision':'obsolete'}
    assert normalized_native(ep.EndPlate.from_dict(forged))==native, ('saved result trusted',entry['id'])
    assert normalized_native(ep.EndPlate.from_dict(obj.to_dict()))==native, ('roundtrip',entry['id'])
    if obj.kind=='moment':
        calculated=[x for x in result.case_records if x['status']=='calculated']
        assert len(calculated)==len(entry['hand_cases'])
        for case, expected in zip(calculated,entry['hand_cases']):
            actions=case['actions']; assert actions==expected['actions']
            n,m=actions['N'],actions['M'];z=obj.beam.d-obj.beam.tf
            ff=abs(m)/z+max(n,0)/2;fc=abs(m)/z+max(-n,0)/2
            s=obj.support; fy=commit['steel_fy'][obj.support_steel]
            ry=1.10*2.5*s.tf*fy*s.tw/1.10
            rk=.33*s.tw**2*math.sqrt(200000.*fy*s.tf/s.tw)/1.10
            h1=obj.beam.d-obj.beam.tf/2+obj.pfo;h2=obj.beam.d-1.5*obj.beam.tf-obj.pfi
            arms=[h1+obj.pb,h1,h2,h2-obj.pb] if obj.variant=='8ES' else [h1,h2]
            nb=8 if obj.variant=='8ES' else 4
            tb=(abs(m)+max(n,0)*z/2)/(2*sum(arms));t=nb*tb;contact=max(t-n,0)
            manual={'Ff':ff,'Fc':fc,'yield':max(ff,fc),'crippling':fc,'Ry':ry,'Rk':rk,'Tb':tb,'T':t,'C':contact}
            for name,val in manual.items():near(val,expected['values'][name])
            rows={x.id:x for x in case['checks']}
            for cid,demand,capacity in [('ep_column_web_yield',max(ff,fc),ry),('ep_column_crippling',fc,rk)]:
                near(rows[cid].demand,demand);near(rows[cid].resistance,capacity)
            near(rows['ep_bolt_tension'].demand,tb);near(rows['ep_contact'].demand,contact)
            geom=result.geometry['actual_actions' if case['label']=='Entrada' else 'minimum_actions']
            near(geom['C'],contact);near(geom['column_web_yield_force'],max(ff,fc));near(geom['column_crippling_force'],fc)
            if obj.variant=='4E':
                assert 'FSd=max(Ff;Fc)' in rows['ep_column_web_yield'].equation
                assert 'FSd=Fc' in rows['ep_column_crippling'].equation
                for cid in ('ep_column_web_yield','ep_column_crippling'):
                    assert '3.5 p.37' in rows[cid].reference and 'p.132' in rows[cid].reference
                    assert 'Ff=' in rows[cid].substitution and 'Fc=' in rows[cid].substitution
            hand_cases+=1
        for row in result.checks:
            candidates=[r for r in result.actual+result.minimum if r.id==row.id]
            assert clean(row)==clean(max(candidates,key=lambda r:r.ratio))
    if 'threshold' in entry:
        target=entry['threshold'];rows={x.id:x for x in result.actual};row=rows[target['id']]
        if target['direction']=='increase':
            assert target['old_demand']<row.resistance<row.demand and not row.passed
            assert [x.id for x in result.resistance_failures]==[target['id']];increases+=1
        else:
            assert row.demand<row.resistance<target['old_demand'] and row.passed
            assert result.status=='ATENDE ÀS VERIFICAÇÕES REALIZADAS';reductions+=1
    for detailed, wanted in entry.get('report_text_sha256',{}).items():
        texts=report_text(obj,result,detailed=='true')
        assert digest(texts)==wanted, ('report text mismatch',entry['id'],detailed)
        if obj.kind=='moment' and obj.variant=='4E':
            alltext='\n'.join(texts)
            for label in ('Coluna 4E sem reforço','max(Ff;Fc)','enrugamento sob Fc','C=max(T−N;0)',commit['four_e_revision']):assert label in alltext
        reports_checked+=1
    records.append({'id':entry['id'],'status':result.status,'result_sha256':digest(result),'native_sha256':digest(native)})
imports={}
for name,module in tuple(sys.modules.items()):
    if name=='lro' or name.startswith('lro.'):
        origin=Path(module.__file__).resolve()
        assert origin.is_relative_to(ROOT), ('foreign runtime import',name,str(origin))
        imports[name]={'path':str(origin.relative_to(ROOT)),'sha256':sha(origin.read_bytes())}
assert {name:sha((ROOT/name).read_bytes()) for name in source_before}==source_before
if root_before:assert {n:sha((APP/n).read_bytes()) for n in root_before}==root_before
result={'pass':True,'mode':mode,'global_app_version':models.VERSION,'normalization':'Only top-level native app_version and exact global VERSION string in report text. No mechanics/source/method normalization.','runtime_sha256':source_before,'root_files_sha256':root_before,'module_origins':imports,'cases':records,'case_count':len(records),'hand_calculated_cases':hand_cases,'report_text_checks':reports_checked,'increased_demand_thresholds':increases,'reduced_demand_thresholds':reductions,'explicit_input_expectations':True,'frozen_source_or_optional_companion_used':False,'full_aggregate_or_browser_pixels_or_report_layout_claimed':False,'expected_sha256':sha((HERE/'expected.json').read_bytes()),'manifest_sha256':sha((HERE/'PORTABLE_MANIFEST.json').read_bytes())}
(OUT/'PORTABLE_4E_REPLAY.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps({k:result[k] for k in ('pass','mode','case_count','hand_calculated_cases','report_text_checks','increased_demand_thresholds','reduced_demand_thresholds')}))
