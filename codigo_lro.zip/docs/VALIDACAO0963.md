# Validação 0.9.63 — end plates

Correções finitas: desenhos de entradas inválidas/extremas; proteção de entradas não finitas/overflow; Word SCI recalculado pelo projeto atual; vírgula decimal na apresentação SCI. Premissas CJP/acesso preservadas e diferenciadas de inspeção.

A regressão direcionada cobre todos os sete exemplos, larguras NaN/Inf/negativas/extremas, pfo extremo, extensões e nervuras extremas sem erro geométrico, cargas normais/negativas e troca de dados após memorial antigo. A interface real cobre erro e recuperação, conservação do último projeto e bloqueio de exportações após overflow. A revisão independente reproduziu as três falhas adicionais de extensão e confirmou seu fechamento nos formatos PNG/SVG.

A suíte histórica das end plates e a execução do pacote extraído são registradas em docs/validation0963/SUMMARY.json. Fonte completa, testes e evidências preservados separadamente; o pacote compacto conserva todos os módulos, dados e exemplos. Nenhuma equação resistente, fator ou família foi alterado. Testes de software não equivalem à aprovação estrutural.

Ver AUDITORIA_END_PLATES0963.md para matriz de achados e pendências normativas preservadas.
