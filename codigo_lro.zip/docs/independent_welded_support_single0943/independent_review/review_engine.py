"""Read-only evaluation of isolated 0943 engine; no source edits."""
import sys, math, json, random, io, contextlib, runpy, hashlib
from pathlib import Path
from dataclasses import replace
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'source0943'))
from lro.welded_support_single_angle import (WeldedSupportSingleAngle,presets,evaluate,support_weld_segments,support_leg_envelope,elastic_line_group,hardware_envelope)
from lro.double_angle import bearing_resistance,bolt_shear_resistance,GAMMA_A2,HOLES
from lro.models import STEELS,BOLTS
with contextlib.redirect_stdout(io.StringIO()):
    ref=runpy.run_path(str(Path(__file__).with_name('section_oracle.py')))
reference_section=ref['section']
c=next(iter(presets().values()))
results={}
source=ROOT/'source0943/lro/welded_support_single_angle.py'
results['source_sha256']=hashlib.sha256(source.read_bytes()).hexdigest()
results['preset']=evaluate(c)
assert results['preset']['global_pass']
# Source weld and section benchmark, in millimetres and unit N.
witness=replace(c,beam=replace(c.beam,tw=.380*25.4),support_leg=3*25.4,length=11.5*25.4,t=.375*25.4,weld_leg=.1875*25.4)
max_errors={k:0. for k in ['N','V','B','von_mises','heel_B','force','moment','mirror_q']}
random.seed(100943)
cases=[witness]+[replace(c,support_leg=random.uniform(65,105),length=random.uniform(180,300),t=random.uniform(6.35,9.525),beam=replace(c.beam,tw=random.uniform(5,12.7))) for _ in range(100)]
for a in cases:
    rr=reference_section(a.length,a.support_leg,a.t,a.beam.tw,F=-1.)
    records=[]
    for side in ['positive_z','negative_z']:
        cc=replace(a,side=side)
        g=elastic_line_group(support_weld_segments(cc),0.,-1.,0.,cc.length/2)
        s=support_leg_envelope(cc,g)
        for name in ['N','V','B']:
            error=abs(abs(s['maxima'][name]['resultant'])-rr['maximum_abs_'+name][0])
            max_errors[name]=max(max_errors[name],error)
            assert error<1e-10
        error=abs(s['equivalent_stress_bound_MPa']-rr['von_mises_bound'])
        max_errors['von_mises']=max(max_errors['von_mises'],error);assert error<1e-12
        error=abs(s['heel']['B_Nmm']+cc.beam.tw/2)
        max_errors['heel_B']=max(max_errors['heel_B'],error);assert error<1e-10
        eq=g['equilibrium']
        max_errors['force']=max(max_errors['force'],abs(eq['integrated_Fx_N']),abs(eq['integrated_Fy_N']+1))
        max_errors['moment']=max(max_errors['moment'],abs(eq['integrated_M_about_origin_Nmm']))
        assert abs(eq['integrated_M_about_origin_Nmm'])<1e-10
        records.append(g)
    max_errors['mirror_q']=max(max_errors['mirror_q'],abs(records[0]['max_resultant_N_per_mm']-records[1]['max_resultant_N_per_mm']))
results['oracle_comparisons']=dict(cases=len(cases),sides_per_case=2,max_errors=max_errors)
wg=elastic_line_group(support_weld_segments(witness),0,-1,0,witness.length/2)
# convert stress and force units only; use actual AISC electrode strength and phi.
ksi=6.894757293168361;kip=4448.2216152605
phiRn=.75*.6*70*ksi*(witness.weld_leg/math.sqrt(2))/wg['max_resultant_N_per_mm']/kip
assert math.isclose(phiRn,34.22020916966496,rel_tol=1e-12)
results['elastic_aisc_LRFD_kip']=phiRn
results['table_aisc_LRFD_kip']=.75*2.2*3*11.5
# Mirrored full evaluations must have equal capacities and opposite centroid Mx.
left=evaluate(replace(c,side='negative_z'));right=evaluate(c)
assert left['global_pass']==right['global_pass']
assert math.isclose(left['summary']['equivalent_total_V_capacity_N'],right['summary']['equivalent_total_V_capacity_N'],rel_tol=1e-12)
assert math.isclose(left['welds']['actual_centroid_Mx_Nmm'],-right['welds']['actual_centroid_Mx_Nmm'],rel_tol=1e-12)
assert abs(left['welds']['actual_origin_Mx_Nmm'])<1e-6
results['side_mirror']='PASS'
# Scope and minimum force.
mutations={'negative_V':dict(V=-90000),'zero_V':dict(V=0),'N':dict(N=1),'M':dict(M=1),'T':dict(torsion=1),'support_web':dict(kind='girder_web'),'extra_column':dict(web_columns=2),'fifth_bolt':dict(web_rows=5),'eccentricity':dict(beam_gauge=76.200001),'halfweb':dict(beam=replace(c.beam,tw=12.700002)),'full_top':dict(top_return=c.support_leg),'discontinuity':dict(support_continuous=False),'cope':dict(cope='top'),'contact':dict(gap=0),'zero_inertia':dict(length=0)}
results['scope_tests']={}
for label,params in mutations.items():
    o=evaluate(replace(c,**params));assert not o['global_pass'],label
    results['scope_tests'][label]=o['status']
small=evaluate(replace(c,V=1000))
assert small['load_model']['Vd_N']==45000 and small['load_model']['web_bolt_force_N']==45000/4
assert small['load_model']['column_reference_transport']['F_N']==[0,-1000,0]
results['minimum_once_actual_transport']='PASS'
# Bearing direction regression: beam receives upward forces, top is no-free-edge terminal.
tight=replace(c,web_pitch=54.,web_end_top=48.)
t=evaluate(tight);rows={r['id']:r for r in t['checks']}
actual=[rows['web_bearing_'+str(i+1)].get('clear_distance_mm') for i in range(c.web_rows)]
expected=[None]+[tight.web_pitch-tight.hole_diameter]*(tight.web_rows-1)
results['web_bearing_direction']=dict(actual_lc=actual,expected_lc=expected,pass_=actual==expected)
results['overall']='SCOPED_GO' if actual==expected else 'FIX_WEB_BEARING_TERMINAL_DIRECTION_THEN_SCOPED_GO'
# One physical bolt plane and web.
assert t['bolts']['shear_planes']==1 and t['bolts']['physical_beam_webs']==1
assert t['bolts']['grip_mm']==c.t+c.beam.tw
assert math.isclose(rows['bolts_single_shear']['design_capacity_N'],c.web_rows*bolt_shear_resistance(c.db,BOLTS[c.bolt],False),rel_tol=1e-12)
results['single_plane_web_grip']='PASS'
# Explicit reinforced-edge detail: only permitted maximum changes, no strength bonus.
# M16 fixture envelope corrected from15 to17mm to cover F436M washer OD34mm.
# No load, material, weld dimension or resistance formula changed.
thin=replace(c,beam_leg=63.5,support_leg=63.5,t=6.35,root_radius=7.,beam_gauge=38.,db=16.,hole_diameter=18.,tool_radius=17.,weld_leg=5.,top_return=10.,V=45000.)
plain=evaluate(thin);reinforced=evaluate(replace(thin,reinforced_weld_edge=True))
assert plain['status']=='DETAIL_FAIL' and not plain['global_pass']
assert reinforced['global_pass']
plain_weld=next(x for x in plain['checks'] if x['id']=='weld_L')
reinforced_weld=next(x for x in reinforced['checks'] if x['id']=='weld_L')
assert plain_weld['design_capacity_N']==reinforced_weld['design_capacity_N']
assert any(x['severity']=='warning' and 'Borda especificada' in x['text'] for x in reinforced['issues'])
assert evaluate(replace(thin,reinforced_weld_edge=1))['status']=='INVALID_INPUT'
assert not evaluate(replace(thin,reinforced_weld_edge=True,weld_leg=thin.t+1e-6,top_return=2*(thin.t+1e-6)))['global_pass']
round_trip=WeldedSupportSingleAngle.from_dict(replace(thin,reinforced_weld_edge=True).to_dict())
assert round_trip.reinforced_weld_edge is True
results['reinforced_edge_addition']=dict(unreinforced_status=plain['status'],reinforced_status=reinforced['status'],same_weld_capacity_N=plain_weld['design_capacity_N'],warning_present=True,strict_boolean=True,native_round_trip=True,upper_limit_still_t=True)
# Manual zero radius is retained for correction but cannot approve rolled-angle access.
zero_root=replace(c,root_radius=0.,beam_gauge=40.)
zero_result=evaluate(zero_root)
real_root_result=evaluate(replace(zero_root,root_radius=10.))
assert zero_result['status']=='ENGINEERING_MODEL_PENDING'
assert zero_result['global_pass'] is False and zero_result['summary']['complete_checks'] is False
assert zero_result['inputs']['root_radius']==0. and zero_result['checks']
assert any(x['severity']=='engineering_pending' and 'Raio interno zero' in x['text'] for x in zero_result['issues'])
assert real_root_result['global_pass'] is False
assert any(x['severity']=='access_pending' for x in real_root_result['issues'])
zero_round_trip=WeldedSupportSingleAngle.from_dict(zero_root.to_dict())
assert zero_round_trip.root_radius==0. and not evaluate(zero_round_trip)['global_pass']
assert evaluate(replace(c,root_radius=-1.))['status']=='INVALID_INPUT'
assert evaluate(c)['global_pass']
results['zero_manual_root_correction']=dict(zero_status=zero_result['status'],zero_preserved=True,zero_global_pass=False,zero_complete_checks=False,native_round_trip_preserved=True,actual_10mm_root_access_pending=True,negative_radius_rejected=True,default_positive_radius_unchanged=True)
# Hardware dimensions independently checked against the stated manufacturer tables.
metric_data={16.:(31.18,34.),20.:(39.26,42.),22.:(41.57,44.),24.:(47.34,50.),27.:(53.12,56.),30.:(57.74,60.)}
imperial_data={12.7:(1.010,1.063),15.875:(1.227,1.313),19.05:(1.443,1.469),22.225:(1.660,1.750),25.4:(1.876,2.),28.575:(2.093,2.25),31.75:(2.309,2.5)}
assert set(HOLES)==set(metric_data)|set(imperial_data)
hardware_tests=[]
for db in HOLES:
    if db in metric_data:
        corners,washer=metric_data[db]
    else:
        ci,wi=imperial_data[db];corners=ci*25.4;washer=(wi+.0313)*25.4
    floor=max(corners,washer)/2
    hh=hardware_envelope(db)
    assert math.isclose(hh['head_nut_max_corners_mm'],corners,rel_tol=1e-14)
    assert math.isclose(hh['washer_max_outside_mm'],washer,rel_tol=1e-14)
    assert math.isclose(hh['minimum_hardware_radius_mm'],floor,rel_tol=1e-14)
    transitions=[]
    for radius,expected in [(floor-1e-8,False),(floor,True),(floor+5,True)]:
        r=evaluate(replace(c,db=db,hole_diameter=HOLES[db],tool_radius=radius))
        physical=next(x for x in r['geometry']['checks'] if x['id']=='tool_physical')
        root_check=next(x for x in r['geometry']['checks'] if x['id']=='tool_root')
        assert physical['passed']==expected
        assert r['geometry']['hardware_envelope']['declared_hardware_tool_radius_mm']==radius
        assert root_check['limit']==radius+c.fabrication_clearance
        if not expected:assert not r['global_pass']
        transitions.append(physical['passed'])
    hardware_tests.append(dict(db_mm=db,floor_mm=floor,below_at_above=transitions))
assert hardware_envelope(20.)['minimum_hardware_radius_mm']==21.
assert hardware_envelope(16.)['minimum_hardware_radius_mm']==17.
assert hardware_envelope(19.05)['minimum_hardware_radius_mm']!=21.
assert not evaluate(replace(c,db=20.,tool_radius=10.,beam_gauge=36.))['global_pass']
assert not evaluate(replace(c,db=20.,tool_radius=21.,beam_gauge=36.))['global_pass']
assert math.isclose(plain_weld['design_capacity_N'],130591.50225789647,rel_tol=1e-14)
results['hardware_envelope_correction']=dict(diameters_tested=len(hardware_tests),rows=hardware_tests,complete_declared_envelope_preserved=True,no_wrench_size_inferred=True,M16_fixture_radius_changed_from_15_to_17=True,resistance_unchanged=True)
# Output in independent reviewer-owned directory only.
(Path(__file__).with_suffix('.json')).write_text(json.dumps(results,indent=2,allow_nan=False))
print(json.dumps({k:v for k,v in results.items() if k!='preset'},indent=2))
