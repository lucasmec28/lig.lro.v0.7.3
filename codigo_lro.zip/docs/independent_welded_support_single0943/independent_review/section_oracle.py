"""L weld support-leg section oracle. No application imports."""
import math,json,random

def section(h,b,t,tw,F=-1.):
    L=h+b;xc=b*b/(2*L);yc=h*h/(2*L)
    J=(h**3+b**3)/3-L*(xc*xc+yc*yc)
    M=F*(b+tw/2-xc);K=M/J;A=F/L-K*xc
    N=lambda u:-K*h*(h/2-yc)+K*yc*u
    V=lambda u:A*(h+u)+K*u*u/2
    B=lambda u:K*h**3/12-u*h*A-A*u*u/2-K*u**3/6+K*h*yc*u/2
    npts=[0.,b];vpts=[0.,b];bpts=[0.,b]
    if K:
        root=-A/K
        if 0<root<b:vpts.append(root)
    aa=-K/2;bb=-A;cc=-h*A+K*h*yc/2
    if abs(aa)<1e-15:
        if abs(bb)>1e-15:
            root=-cc/bb
            if 0<root<b:bpts.append(root)
    else:
        discriminant=bb*bb-4*aa*cc
        if discriminant>=0:
            for s in [-1,1]:
                root=(-bb+s*math.sqrt(discriminant))/(2*aa)
                if 0<root<b:bpts.append(root)
    nm=max((abs(N(u)),u) for u in npts)
    vm=max((abs(V(u)),u) for u in vpts)
    bm=max((abs(B(u)),u) for u in bpts)
    sn=nm[0]/(t*h)+6*bm[0]/(t*h*h)
    tau=1.5*vm[0]/(t*h)
    eq=math.hypot(sn,math.sqrt(3)*tau)
    # Simpson quadrature is independent and exact for these line polynomials.
    def quad(fn,l):return l/6*(fn(0)+4*fn(l/2)+fn(l))
    qx=lambda x,y:-K*(y-yc)
    qy=lambda x,y:A+K*x
    max_quad_error=0.
    for u in [0.,b*.13,b*.49,b*.87,b]:
        nq=quad(lambda y:qx(0,y),h)+quad(lambda x:qx(x,0),u)
        vq=quad(lambda y:qy(0,y),h)+quad(lambda x:qy(x,0),u)
        bq=quad(lambda y:-u*qy(0,y)-(y-h/2)*qx(0,y),h)+quad(lambda x:(x-u)*qy(x,0)+h/2*qx(x,0),u)
        errors=[abs(nq-N(u)),abs(vq-V(u)),abs(bq-B(u))]
        max_quad_error=max(max_quad_error,*errors)
        assert max(errors)<1e-10*max(1,abs(F),abs(F*b))
    for i in range(1001):
        u=b*i/1000
        assert abs(N(u))<=nm[0]+1e-10
        assert abs(V(u))<=vm[0]+1e-10
        assert abs(B(u))<=bm[0]+1e-10
        point_vm=math.hypot(abs(N(u))/(t*h)+6*abs(B(u))/(t*h*h),math.sqrt(3)*1.5*abs(V(u))/(t*h))
        assert point_vm<=eq+1e-10
    assert abs(N(b))<1e-10 and abs(V(b)-F)<1e-10
    assert abs(B(b)-F*tw/2)<1e-10
    return dict(geometry=dict(h=h,b=b,t=t,tw=tw),force=F,A=A,K=K,
        candidates=dict(N=npts,V=vpts,B=bpts),
        maximum_abs_N=nm,maximum_abs_V=vm,maximum_abs_B=bm,
        heel=dict(N=N(b),V=V(b),B=B(b)),
        sigma_normal_bound=sn,tau_bound=tau,von_mises_bound=eq,
        max_quadrature_residual=max_quad_error)

r=section(11.5,3.,.375,.380)
random.seed(943)
for _ in range(100):
    h=random.uniform(3.,16.);b=random.uniform(2.,6.);t=random.uniform(.2,.6);tw=random.uniform(.2,.5)
    section(h,b,t,tw,F=random.choice([-1.,1.]))
r['fy50_gamma1_1_section_capacity_kip']=50/1.1/r['von_mises_bound']
r['tests']='100 randomized geometries, 5 exact independent Simpson integrations each, 1001-point cross-check each; passed.'
print(json.dumps(r,indent=2))
