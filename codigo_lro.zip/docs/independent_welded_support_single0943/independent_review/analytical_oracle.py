"""Independent analytical oracle; no application imports. Units: kip, in."""
import json, math

def group(h=11.5,b=3.,load_x=3.19,F=-1.,w=.1875,Fexx=70.):
    L=h+b; xc=b*b/(2*L); yc=h*h/(2*L)
    J=(h**3+b**3)/3-L*(xc**2+yc**2)
    M=(load_x-xc)*F
    points=[]
    for x,y in [(0.,0.),(0.,h),(b,0.)]:
        qx=-M*(y-yc)/J; qy=F/L+M*(x-xc)/J
        points.append(dict(x_in=x,y_in=y,qx_kip_per_in=qx,qy_kip_per_in=qy,q_kip_per_in=math.hypot(qx,qy)))
    qmax=max(p['q_kip_per_in'] for p in points)
    A=F/L-M*xc/J; K=M/J
    # Closed-form integration over vertical line plus bottom line.
    Fx=-K*(h*h/2-h*yc)+K*yc*b
    Fy=h*A+A*b+K*b*b/2
    Mo=K*h**3/3-K*yc*h*h/2+A*b*b/2+K*b**3/3
    Mc=Mo-xc*Fy+yc*Fx
    assert abs(Fx)<1e-12 and abs(Fy-F)<1e-12
    assert abs(Mc-M)<1e-12 and abs(Mo-F*load_x)<1e-12
    throat=w/math.sqrt(2)
    return dict(L_in=L,xc_in=xc,yc_in=yc,Jline_in3=J,Mcentroid_kip_in=M,
        eccentricity_in=load_x-xc,throat_in=throat,points=points,qmax_per_unit_V_per_in=qmax/abs(F),
        equilibrium=dict(Fx_kip=Fx,Fy_kip=Fy,Morigin_kip_in=Mo,Mcentroid_kip_in=Mc),
        weld_nominal_kip=.6*Fexx*throat/qmax*abs(F),
        weld_LRFD_kip=.75*.6*Fexx*throat/qmax*abs(F),
        weld_ASD_kip=.6*Fexx*throat/qmax*abs(F)/2)

h=11.5;t=.375;db=.75;dh=.8125;dn=.875;fy=50.;fu=65.;edge=1.25
ag=(h-edge)*t;an=(h-edge-3.5*dn)*t;ant=(edge-.5*dn)*t
components={
    'weld_table_LRFD_kip':.75*2.20*3*h,
    'weld_table_ASD_kip':2.20*3*h/2,
    'bolt_single_LRFD_kip':.75*54*math.pi*db**2/4,
    'bolt_group_LRFD_kip':4*.75*54*math.pi*db**2/4,
    'angle_yield_LRFD_kip':.6*fy*h*t,
    'angle_rupture_LRFD_kip':.75*.6*fu*(h-4*dn)*t,
    'angle_block_LRFD_kip':.75*(min(.6*fy*ag,.6*fu*an)+fu*ant),
    'angle_edge_bearing_LRFD_kip':.75*min(1.2*(edge-dh/2),2.4*db)*t*fu,
    'angle_nonedge_bearing_LRFD_kip':.75*min(1.2*(3-dh),2.4*db)*t*fu,
    'beam_nonedge_bearing_LRFD_kip':.75*min(1.2*(3-dh),2.4*db)*.380*fu,
    'support_min_thickness_in':3.09*3/65,
    'support_actual_thickness_in':.710,
    'block_areas_in2':dict(Agv=ag,Anv=an,Ant=ant),
}
r=group();reverse=group(F=1.)
assert math.isclose(r['weld_LRFD_kip'],34.22020916966496,abs_tol=1e-10)
assert math.isclose(r['weld_LRFD_kip'],reverse['weld_LRFD_kip'],abs_tol=1e-10)
for p,q in zip(r['points'],reverse['points']):
    assert math.isclose(p['qx_kip_per_in'],-q['qx_kip_per_in'],abs_tol=1e-12)
    assert math.isclose(p['qy_kip_per_in'],-q['qy_kip_per_in'],abs_tol=1e-12)
qfactor=r['qmax_per_unit_V_per_in']/25.4
out=dict(benchmark_AISC=components,elastic_L_downward=r,
    mathematical_reversal_only=reverse,
    NBR_component_only=dict(fuw_MPa=485.,gamma_a2=1.35,
        qfactor_per_mm=qfactor,
        same_4_7625mm_leg_weld_kN=.6*485*(4.7625/math.sqrt(2))/1.35/qfactor/1000,
        five_mm_leg_weld_kN=.6*485*(5/math.sqrt(2))/1.35/qfactor/1000),
    warning='NBR figures are weld-component resistances, not full-connection approval. Reversal of an in-plane field does not qualify physical reversed loading.')
print(json.dumps(out,indent=2))
