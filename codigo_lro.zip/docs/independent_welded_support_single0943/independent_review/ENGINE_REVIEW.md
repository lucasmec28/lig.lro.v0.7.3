# Revisão focada do motor 1L 0.9.43

13/10/2026. Arquivo revisado exclusivamente na cópia isolada:
`source0943/lro/welded_support_single_angle.py`

SHA256 após a correção verificada:
`0a5eea069003c580e522c8544800f18d9e41fe6bf8b174c7b57719492bfdd6d9`

## Resultado: GO no domínio estreito declarado

A formulação numérica, orientação física da solda e controles do domínio são coerentes com a qualificação convencional descendente registrada em METHOD_CONTRACT.md. Esta conclusão é somente do motor e do seu contrato local; não revisa UI, desenho, Word, integração ou a resistência global da estrutura.

## Defeito encontrado e corrigido pelo implementador

O contato da alma usava o parafuso inferior como extremo sem borda vertical livre, repetindo a direção da força sobre a cantoneira. As ações das interfaces são opostas: a cantoneira é carregada para baixo e a alma para cima. O extremo sem próximo furo no sentido carregado da alma é o superior.

Correção confirmada: `web_lc=None if i==0 else pitch-dh`; a cantoneira mantém a borda inferior em `i==n-1`. Os resultados agora registram `loaded_direction='up'` na alma e `'down'` na cantoneira. Caso p54mm, dh22mm: a sequência correta da alma é [None,32,32,32]mm. A regressão independente passou.

Não foi encontrada outra falha concreta bloqueante nesta passagem.

## Verificações independentes executadas

O script `review_engine.py` só lê/importa a cópia isolada e grava `review_engine.json` nesta pasta de revisão. Foi executado com geração de bytecode desativada.

- 101 geometrias, incluindo o testemunho publicado, em ambos os lados físicos: máximos N/V/B e envelope de von Mises comparados ao oráculo independente anterior.
- Maior diferença de B: 2,85e−14 Nmm por1N; de von Mises:4,34e−19MPa por1N.
- Equilíbrio da solda: força vertical unitária, força transversal zero e momento na origem do plano médio da alma zero; resíduos máximos de momento inferiores a6e−14Nmm por1N.
- No talão: N≈0, V=F e B=F·tw/2. A meia-alma não foi omitida ou somada duas vezes.
- Espelho: resistência idêntica; momento Mx no centroide com sinal oposto. As coordenadas globais(z,y) possuem momento escalar igual a−Mx, conforme declarado no motor.
- Testemunho elástico AISC:34,220209169665kip LRFD. Tabelado corrigido:56,925kip. Não houve calibração da elasticidade ao ICR.
- Parafusos: um plano, uma alma, pega t+tw; força por parafuso Vd/n; capacidade por plano e grupo conferidas.
- Vd mínimo45kN aplicado uma vez; Vsd real preservado no transporte global. Caso Vsd1kN manteve1kN na resultante global e45kN nas conferências locais.
- Quinze casos de exclusão/entrada inválida: V<0, V=0, N/M/T externos, receptor na alma, segunda coluna, quinto parafuso, e acima76,2mm, meia-alma acima6,35mm, topo fechado, descontinuidade no pilar, recorte, contato da ponta e comprimento zero. Todos impediram aprovação.
- Preset operacional: aprovado localmente, capacidade111,611758kN, governado pela solda; V90kN tem utilização0,80636665.

## Observações de escopo confirmadas

O envelope da aba é exato nas resultantes e conservador nas tensões retangulares de seção; a documentação não o apresenta como elasticidade bidimensional pontual. A solda superior curta é física e explicitamente não recebe crédito no grupo resistente L. O momento fora do plano não foi adicionado como engaste incompatível com a hipótese convencional.

O receptor usa uma única espessura tf, separada da cantoneira. Os limites locais junto à solda não são apresentados como verificação global do pilar; a continuidade do receptor é uma condição de entrada. O transporte face-centro do pilar é realizado com Vsd real e braço d_pilar/2, com aviso contra dupla contagem.

A dispensa de excentricidade do grupo de parafusos é identificada como a hipótese convencional AISC e limitada a e≤76,2mm. As restrições dimensionais e o filtro AL3 estão corretamente identificados no contrato como seleção conservadora da implementação, sem alegação de regra NBR universal de flexibilidade.

Nota prática não bloqueante: estar dentro do intervalo nominal de espessura não garante detalhamento viável. Quando ambas as partes soldadas excedem6,3mm, o mínimo5mm combinado com máximo t−1,5mm reprova t6,35mm sem borda reforçada. O motor mantém essa reprovação, corretamente; não se deve anunciar que todo perfil do intervalo6,35–9,525mm passa automaticamente.

Os testemunhos antigos intitulados `NO_GO_FOR_GENERAL_CONNECTION_IMPLEMENTATION` podem ser preservados como evidência histórica de que não se aprovou um catálogo irrestrito; seu estado não deve ser confundido com a presente aprovação restrita do motor corrigido.

## Atualização final: borda reforçada explícita

Verificada uma vez após a revisão inicial. `reinforced_weld_edge` é booleano estrito, falso por padrão e persistido no projeto nativo. A ativação altera somente o limite geométrico da perna para w≤t, com aviso de exigência de reforço na execução e detalhamento, conforme a exceção da NBR6.2.6.2.2(b). Não existe aumento da garganta ou da fórmula resistente por marcar o campo.

Teste independente L63,5×63,5×6,35, filete5mm: falso produz DETAIL_FAIL; verdadeiro produz aprovação local. A capacidade da solda permanece exatamente130.591,50225789647N em ambos. Entrada inteira1 em vez de booleano é rejeitada; w>t permanece reprovado; round-trip nativo conserva a opção. O conjunto anterior de101 geometrias e testes de domínio também passou novamente. O GO restrito permanece, agora associado ao hash atualizado acima. A presença da indicação exigida nos desenhos será conferida pela revisão de artefatos, fora deste exame do motor.

## Correção final confirmada: raio interno manual zero

O revisor final identificou um caso antes aprovado com raio manual zero e gabarito40mm, apesar de o raio real10mm bloquear o acesso. A correção foi verificada nesta passagem, sem editar a fonte: `root_radius=0` permanece salvo/importável para correção, mas acrescenta `engineering_pending` antes das conferências. O resultado é ENGINEERING_MODEL_PENDING, `global_pass=false` e `complete_checks=false`; os subcálculos permanecem disponíveis sem aprovação local. Não foi introduzido raio positivo presumido nem mínimo numérico arbitrário.

O round-trip nativo mantém zero e a pendência; r10mm/g40mm continua com `access_pending`; raio negativo continua inválido e o preset com raio positivo válido permanece aprovado. Os testes independentes anteriores, incluindo101 geometrias em dois lados e a borda reforçada, passaram novamente. Essa correção foi conferida no hash115723a26178cb606bb4a3c598cc65f8944cd65843edeab8ba78a2c69a53056b; o recibo vigente acompanha a revisão mais recente abaixo. GO restrito mantido após essa correção específica.

## Correção final confirmada: envelope físico de cabeça, porca e arruela

Conferido no motor congelado0a5eea069003c580e522c8544800f18d9e41fe6bf8b174c7b57719492bfdd6d9. O antigo limite db/2 foi substituído pelo raio mínimo do envelope heavy-hex/F436, max(cantos máximos da cabeça/porca, diâmetro externo máximo da arruela)/2. A dimensão completa maior declarada para ferragem e ferramenta permanece usada nas folgas; o piso não é tratado como tamanho de chave ou certificado de acesso.

Foram abertas independentemente as fontes [BAPP A325M, páginas2–3](https://www.bapp.co.uk/_files/ugd/62c08a_5c990aa9e9ca4e71ba760aee1b788405.pdf), [Portland Bolt, parafusos estruturais](https://www.portlandbolt.com/products/bolts/structural/), [Portland Bolt, porcas heavy-hex](https://www.portlandbolt.com/products/nuts/heavy-hex-nut/) e [Anchor Bolt Express, arruelas F436](https://www.anchorboltexpress.com/F844-F436-washer-chart/). Os13 diâmetros foram conferidos, mantendo séries métricas/imperiais separadas e a tolerância imperial positiva0,0313in antes da conversão por25,4.

Os testes imediatamente abaixo, exatamente no piso e5mm acima passaram para todos os13 diâmetros. M20 usa21mm, e M16 usa17mm; são governados pelos diâmetros máximos42mm e34mm das respectivas arruelas. O valor declarado maior permanece intacto na saída e no limite de acesso junto à raiz. O caso M20/g36mm permanece sem aprovação tanto com raio declarado10mm como21mm, por motivos físicos de ferragem/acesso.

Apenas o envelope de montagem da fixture independente M16 foi corrigido de15 para17mm. Nenhuma ação, dimensão de solda, propriedade resistente ou fórmula mudou; a capacidade de solda continua exatamente130.591,50225789647N. O teste de borda reforçada continua separando DETAIL_FAIL/PASS sem alterar resistência. A correção anterior do raio zero e todos os101×2 casos do oráculo, equilíbrio, escopo e demais verificações passaram novamente.

GO restrito mantido. Recibo atual: `review_engine.json`, com o mesmo hash de fonte indicado no cabeçalho deste relatório. Nenhuma fonte da aplicação foi editada nesta revisão.
