# Candidata 1L para revisão e integração futura

13/10/2026. Implementação local concluída, com snapshot estável e sem bloqueio conhecido no domínio documentado. Não é uma liberação de projeto, fabricação ou software.

## Resultado

- Uma cantoneira soldada à mesa contínua de pilar W, parafusada à alma de viga W, com V positivo descendente. Identidade própria: `welded_support_single_angle_shear`.
- Motor, UI, desenho, Word com equações OMML editáveis, arquivo nativo estrito e testes. O receptor usa uma mesa do pilar e o grupo usa um plano de corte; não há divisão de uma ligação 2L.
- 107 casos pytest aprovados no snapshot corrigido e estável: 68 de motor, 28 de UI/artefatos e 11 de desenho. Zero falhas, erros ou skips. O lote anterior de 708 regressões afetadas passou antes das duas correções de acesso específicas da 1L; o recibo separa essas fases. Não se apresenta a soma de 815 como agregado executado no mesmo snapshot. Uma advertência de depreciação preexistente ocorreu no lote anterior.
- Revisão mecânica independente: 101 geometrias em ambos os lados, equilíbrio, máximos de seção, sinal dos momentos, sentidos opostos de contato na cantoneira/alma, domínio e testemunhos adversos.
- UI: AppTest real, dispatcher app.py, uploads/downloads, importação atômica e resultado recalculado para exportar. Não houve inspeção por screenshot de navegador de uma UI Streamlit servida.
- Word: 11 casos verificados, relatório padrão de 17 páginas inteiramente inspecionado visualmente, prancha A3 e fórmulas OMML por verificação.

## Evidência principal

- `METHOD_CONTRACT.md`: fontes, fórmulas, qualificações e restrições exatas; cópia idêntica no novo documento de source0943/docs.
- `FINAL_RECEIPT.json`: hashes, delta, contagem deduplicada, evidências e limites da validação.
- `validation/FINAL_NEW_CHECKS_MANIFEST.json`: hashes antes/depois da execução final; estável.
- `independent_review/ENGINE_REVIEW.md` e `review_engine.json`: revisão independente do motor corrigido.
- `artifact_qa/ARTIFACT_UI_RECEIPT.json`: recibo dos artefatos, hashes e revisão visual.
- `artifact_qa/report/boundary_review_20261013/default_render`: render final aprovado visualmente. As pastas `default_render`, `final_render` e `review_render` diretamente em report são tentativas anteriores; não usar suas páginas para identificar o estado final.
- `artifact_qa/ui`: arquivos efetivamente baixados pela UI nos testes.

## Pontos de engenharia que a integração deve preservar

1. A errata oficial AISC de 02/06/2025 corrige o testemunho II.A-29 para kl=3in, k=0,261, x=0,0280, a=0,250 e C=2,20. Capacidade tabelada corrigida LRFD=56,925kip. A disponibilidade da errata foi confirmada por extração indexada oficial; o servidor bloqueou download direto com403. Não se declara inspeção visual desse PDF.
2. A imagem original de IIA285 confirma meia-alma <1/4in. A dispensa de excentricidade no grupo de parafusos somente vale no domínio convencional verificado, incluindo e≤3in. Não aplicar a um catálogo irrestrito ou a outra interface.
3. A solução elástica independente para o detalhe publicado fornece34,220209169665kip, abaixo dos54kip solicitantes do exemplo. O caso adverso permanece reprovado. Não se calibra elasticidade para reproduzir o ICR.
4. O preset operacional próprio V=90kN tem capacidade local equivalente111,61175823134376kN, governada pela solda. Sob250kN reprova. Esta capacidade depende integralmente das entradas do preset e não é uma capacidade genérica da família.
5. O retorno superior curto é executado, mas não recebe crédito resistente; a flexibilidade convencional é condição explícita. Não se adiciona engastamento artificial fora do plano. As resultantes da aba são exatas no modelo de linha; o envelope de tensões retangulares é uma idealização conservadora de seção, sem alegação de solução pontual 2D.
6. V≤0, N/M/T externos, alma de viga de apoio, recortes e demais saídas do domínio são preservados e bloqueados. L64 é o piso de seleção, não garantia de aprovação. Faixa de espessura inicial e filtro AL3 são limites documentados da candidata, não teoremas universais de ductilidade NBR.
7. Borda reforçada é opção explícita falsa por padrão. Ela só modifica o máximo geométrico do filete conforme exceção NBR, sem aumentar capacidade. O aviso de execução aparece nos artefatos.
8. O mínimo45kN é aplicado uma vez às verificações locais. A resultante global usa Vsd real e o braço da face ao centro do pilar; o aviso evita dupla contagem. Verificação local não aprova o dimensionamento global do pilar.
9. Decisões usam valores sem arredondar; apresentação usa duas casas. Importação nativa rejeita família/versão/unidades/resultados adulterados sem sobrescrever estado válido.

## Correções da revisão final

- Raio interno manual zero continua digitável e persistido, mas não permite aprovação da cantoneira laminada. A correção não inventa um raio positivo mínimo.
- O envelope informado deve abranger cabeça, porca, arruela e ferramenta reais. O piso físico usa dimensões máximas publicadas dos componentes heavy-hex padrão e F436/F436M, não apenas db/2. M20: cabeça/porca 39,26 mm e arruela 42 mm, resultando no piso de 21 mm. Esse piso não certifica espaço da chave; o valor maior declarado continua governando.
- Testemunhos preservados: r=0/g=40 pendente; M20 com envelope=10/g=36 pendente; elevar o envelope para 21 ainda não resolve a falta de acesso junto à raiz. Os testes reais de UI e os exports atuais não reutilizam PASS anterior.
- A ficha BAPP foi baixada, preservada com SHA256 e inspecionada visualmente nas páginas 2–3: references/HARDWARE_SOURCE_RECEIPT.json.
- Os recibos e o patch do primeiro congelamento estão em validation/pre_root_radius_fix apenas como histórico; não identificam a candidata corrigida.

## Como integrar

Snapshot: `source0943`. Ele foi copiado da fonte congelada0941 e permanece com a versão global0.9.41 deliberadamente. A versão própria do componente é0.9.43-1l-column-dev. Não copiar a árvore inteira por cima da0942: o pai deve integrar o delta na futura fonte e então atualizar a versão de release.

Patch local: `WELDED_SUPPORT_SINGLE_ANGLE0943.patch`.
SHA256: `c84c0ab0dd80668ad04eaab54813aade0cc187de00d1a8ce83e55dffe6bb3c57`.
Aplicado em diretório temporário com os originais necessários, com igualdade exata de hashes nos dez arquivos reconstruídos.

Apenas três arquivos preexistentes mudaram na cópia: app.py, lro/guided_selection.py e tests/test_guided_selection0919.py. Há sete arquivos novos. A nova família foi acrescentada ao fim das dezenove anteriores, sem reordená-las.

Os2378 arquivos da fonte congelada0941 foram novamente conferidos e estão inalterados. A0942 não foi utilizada nem alterada. Não há push, deploy, pacote de release ou resultado de agregado completo da aplicação nesta entrega.

## Reexecução

Usar o Python disponível com PYTHONDONTWRITEBYTECODE=1, PYTHONPATH apontando à candidata e a connections_audit/test_dependencies, MPLCONFIGDIR e XDG_CACHE_HOME próprios. Não é necessário instalar dependências. `run_final_new_checks.py` reproduz o lote de 107 testes e registra hashes. Os arquivos/logs/XML de regressão afetada estão em validation/AFFECTED_REGRESSION.*.
