"""Reproducible, dependency-light report QA; writes only this QA directory."""
from copy import deepcopy
from dataclasses import asdict, fields, replace
from io import BytesIO
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'source0943'))
from lro.welded_support_single_angle import evaluate, presets
from lro.welded_support_single_angle_report import create_report, _value

OUT = Path(__file__).resolve().parent
NS = {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main',
      'm': 'http://schemas.openxmlformats.org/officeDocument/2006/math'}


def document(data):
    with ZipFile(BytesIO(data)) as z:
        assert not any(name.endswith('.json') for name in z.namelist())
        xml = z.read('word/document.xml')
        tree = ET.fromstring(xml)
        assert tree.findall('.//m:oMath', NS), 'No editable equations'
        return xml, tree, '\n'.join(e.text or '' for e in tree.iter() if e.tag.endswith('}t'))


class Poison:
    def get(self, *args, **kwargs):
        raise AssertionError('Supplied result was consulted')


def main():
    base = next(iter(presets().values()))
    rows = []
    cases = {
        'default': base,
        'minimum': replace(base, V=12000.123456),
        'negative': replace(base, V=-98765.432198),
        'zero': replace(base, V=0.),
        'tiny_external': replace(base, N=1e-9, M=-1e-9, torsion=3.21e-12),
        'overload': replace(base, V=1e6),
        'detail_fail': replace(base, weld_leg=4.),
        'invalid_geometry': replace(base, length=100.),
        'invalid_input': replace(base, t=float('nan')),
        'mirror': replace(base, side='negative_z'),
        'reinforced': replace(base, reinforced_weld_edge=True),
    }
    for name, connection in cases.items():
        before = repr(asdict(connection))
        result = evaluate(connection)
        data = create_report(connection, Poison())
        xml, tree, text = document(data)
        assert repr(asdict(connection)) == before, name + ': input mutated'
        assert result['status'] in text, name + ': fresh status absent'
        for field in fields(connection):
            if field.name not in ('beam', 'support'):
                assert field.name in text, name + ': input field omitted: ' + field.name
        for role in ('beam', 'support'):
            for field in fields(getattr(connection, role)):
                assert field.name in text, name + ': profile field omitted: ' + field.name
        maths = [e.text or '' for e in tree.findall('.//m:t', NS)]
        for check in result['checks']:
            assert check['id'] in text
            assert check['formula'] in maths, name + ': primitive formula not editable'
            assert check['reference'] in text, name + ': primitive reference missing'
        if result['status'] != 'COMPLETE_CHECKS_PASS_WITHIN_SCOPE':
            assert 'SEM APROVAÇÃO LOCAL' in text
            assert 'Atendimento local dentro do domínio declarado.' not in text
        for action in ('V', 'N', 'M', 'torsion'):
            assert _value(getattr(connection, action)) in text, name + ': action missing'
        assert 'retorno superior' in text.lower()
        assert 'não de um coeficiente normativo de ductilidade' in text
        # Stale/adulterated results are not a source of geometry or approval.
        fake = deepcopy(result)
        fake.update(status='FORGED_STATUS', global_pass=True)
        fake['summary'] = {'governing_label': 'FORGED_WITNESS'}
        fake['inputs'] = {'project': 'FORGED_INPUT'}
        _, _, forged_text = document(create_report(connection, fake))
        assert text == forged_text
        assert 'FORGED_' not in forged_text
        (OUT / (name + '.docx')).write_bytes(data)
        rows.append({'case': name, 'status': result['status'], 'checks': len(result['checks']),
                     'omml_equations': len(tree.findall('.//m:oMath', NS)), 'bytes': len(data),
                     'inputs_unchanged': True, 'supplied_result_ignored': True})
    for value in (0., 1e-9, -1e-12, 123.456789, 123456.123456, 1e15):
        shown = _value(value)
        numeric = shown.replace('.', '').replace(',', '.')
        mantissa = numeric.lower().split('e')[0]
        assert len(mantissa.split('.')[-1]) <= 2
        if value != 0:
            assert float(numeric) != 0.
    (OUT / 'checks.json').write_text(json.dumps({'passed': True, 'cases': rows}, indent=2), encoding='utf-8')
    print(json.dumps({'passed': True, 'cases': rows}, indent=2))


if __name__ == '__main__':
    main()
