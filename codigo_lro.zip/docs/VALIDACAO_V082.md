# Validação da versão 0.8.2

Escopo: incremento limitado ao cortante local de quatro chumbadores externos ASTM A36 com quatro arruelas quadradas soldadas, na placa de base Tipo 1. Os demais modelos estruturais foram preservados. Testes de software e consistência das equações não homologam um projeto para execução.

## Verificações realizadas

- Suíte automatizada final: 420 testes aprovados. Abrange modelos anteriores, cálculo, interface Streamlit AppTest, JSON, desenho e Word.
- Sete casos analíticos de aceitação com Decimal de 55 dígitos, originados independentemente do motor: C1, T1, T2, C3, T3, limite exato de tração e limite local de concreto. Comparação de α, Ft,Rd, Fv,Rd, limite de concreto, tração/capacidade individual, soma e ação de cada solda.
- Conferência adicional de fechamento com Decimal de 60 dígitos: os sete casos de referência e nove casos adicionais de diâmetro, espessura, concreto e trações desiguais, total de 16 casos numéricos. Inclui um caso em que barras diferentes têm limites governantes diferentes: a soma dos mínimos é estritamente menor que o mínimo das somas. Valores em registro_numerico_v082.json.
- Quatro grupos de conferência de estado/limite: JSON externo legado e confirmação vinculada aos dados; soma por barra e limite exato; folga geométrica nula; esforços nulos com pendências de ancoragem preservadas.
- Dezoito testes independentes de aceitação das ligações anteriores, incluindo W200, hipóteses fora da faixa ensaiada, solicitações com sinais e memória Word.
- Interface: nova base com arruelas soldadas; espessura comercial e personalizada; dimensões reais; troca de caminho/família; campos externos ocultos; importação repetida; JSON 0.8.1 preservado como externo; invalidação do Word após editar dados.
- Desenho: quatro posições reais, lado/espessura/furo real das arruelas, espessura real do graute, sentido de V e linha tracionada com sinais de M. O cortante é referido à face superior e não ganha transporte global automático.
- Word: equações nativas editáveis, frações/radicais/índices, tabela de trações e capacidades por barra, coeficiente literal 0,533, limite adicional separado e ação de solda Fv,Rd sem redução. O exemplo detalhado foi renderizado em nove páginas; as nove imagens finais foram inspecionadas. O XML do documento foi comparado com nova geração pelo código final e é idêntico.
- Compilação e distribuição: código compilável, manifesto SHA-256, ZIP interno íntegro e pacote de quatro arquivos na raiz. Verificação de extração limpa e abertura independente, sem depender da árvore de trabalho anterior.
- Abertura limpa: passagem pelas cinco famílias, importação W200 e Word, nova base nativa e Word, importação repetida do exemplo T2 com arruelas reais e Word, chave retangular e invalidação após edição. Guardas para ZIP ausente e ZIP de versão diferente exercitadas.

O primeiro agregado encontrou duas expectativas antigas de testes de interface, ligadas à mudança planejada do padrão para cálculo nativo e à inclusão de um exemplo na lista. Os testes passaram a verificar o modelo nativo com aviso de soldas/ancoragem e a selecionar o exemplo histórico pelo nome, em vez da posição. Não se alterou equação estrutural durante o fechamento desta versão.

Ambiente de teste: Python 3.12.14; Streamlit 1.65.0; pandas 2.2.3; matplotlib 3.10.8; python-docx 1.2.0. Bibliotecas de execução fixadas em requirements.txt. A interface foi exercitada com Streamlit AppTest, sem homologação em navegador real ou publicação no GitHub/Streamlit Cloud.

## Limitações que permanecem visíveis

O índice 1/i impresso em 6.7.2.5 não é silenciosamente corrigido: adota-se Ft,máx no termo subtrativo como limite conservador, documentado e avisado para trações desiguais. A interação geral de 6.3.3.4 é aplicada separadamente; não substitui o coeficiente 0,533 da expressão especial.

Resistência/detalhamento das soldas de arruela, arruelas/transferência local, metal-base, pressão e rasgamento dos furos, ancoragem no concreto, efeitos de grupo e borda, cone, arrancamento, pryout, bloco/fundação, soldas do pilar e classificação de rigidez permanecem a complementar. A seleção de arruelas soldadas adota o detalhe, mas não equivale a verificar a solda. O limite 5db²σc,Rd não comprova a ancoragem completa.

Não há distribuição calculada de V aplicado por barra. A soma das capacidades condicionais não afirma V/4 nem resolve compatibilidade ou comportamento do grupo de concreto. A rota externa documentada permanece para outro detalhe validado.

A distribuição 0.8.1 original foi preservada. Método completo, referências e hipóteses: CHUMBADORES_CORTANTE_V082.md.
