"""Replay 7 accepted positive/zero one-root and 12 corner native/result states.
Historical equality is proved by SOURCE_POSITIVE_PARITY.json and the legacy
corner receipt; this replay uses the accepted final 0937 state, with no version
or result-content normalization.
"""
from pathlib import Path
import sys,json,hashlib,importlib
from replay_support import prepare_runtime,runtime_provenance
source=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();out.mkdir(parents=True,exist_ok=True);root,boot=prepare_runtime(source)
canonical=lambda x:hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
records=[]
for ex in json.loads((Path(__file__).resolve().parent/'RETAINED_STATE_EXPECTATIONS.json').read_text()):
 module=importlib.import_module('lro.'+ex['adapter']);ui=importlib.import_module('lro.'+ex['adapter']+'_ui');c=ui.decode_project(json.dumps(ex['input'],ensure_ascii=False))
 assert c.to_dict()==ex['input'],(ex['tag'],'native')
 result=(module.analyze if ex['adapter']=='corner_gusset' else module.evaluate)(c)
 assert canonical(result)==ex['canonical_result_sha256'],(ex['tag'],'result')
 records.append({'tag':ex['tag'],'adapter':ex['adapter'],'pass':True})
assert len(records)==19
(out/'RETAINED_STATE_REPLAY.json').write_text(json.dumps({'status':'PASS','records':records,'provenance':runtime_provenance(boot,root)},indent=2)+'\n');print('PASS',len(records),'retained native/result states')
