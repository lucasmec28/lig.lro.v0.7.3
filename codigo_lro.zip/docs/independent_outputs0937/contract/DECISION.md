# One-root 2L-T flange compression: bounded decision

**GO to develop the conditional DG29/NBR method. Existing specimen: FAIL + real restraint UNVERIFIED. No production release approved.**

The supplied DG29 Example 5.4 already covers a one-root gusset connected only to a W beam flange. Its compression model uses K=1.2 with rotational restraint while allowing sidesway. It supplies the missing conventional method; neither a second gusset root nor another book is needed.

Qualification boundaries:
- Keep the existing symmetric welded 2L-T, rectangular plate, continuous web-centred W-flange root, ordinary static axial compression and signed real force line.
- Identify the actual brace-end rotational condition and the W/root torsional/rotational support detail. Symmetry and weld continuity cannot invent those restraints.
- Resolve receiving-W sidesway through a real relative-flange restraint or the actual NBR5.7.5 inputs. W end distances are not lateral-brace spans.
- Retain local yielding, weld/substrate shear, root transfer, web yielding/crippling, local normal/shear and flange shear. Deactivate purely tensile resistance mechanisms in the compression case.

Independent fixture: the existing 400×300×10 mm, 200 kN specimen with its load sign reversed, without resizing. Retained Whitmore width266.724617 mm; conservative K1.2 length96.652683 mm; buckling resistance556.476924 kN. The original local-introduction yielding screen still **fails at1.079466667**. Unknown real boundary data stay unknown.

The current delivered engine correctly reports compression OUTSIDE_SCOPE with no strength rows. This review does not change it.

Separate verified source correction: the supplied NBR's Errata1, PDF page1, resolves6.5.4(b) as **Le/r >25**. Earlier always-full-curve compression arithmetic stays conservative and unchanged. Amend active interpretation notes only during the next authorized increment; preserve frozen historical releases.

Files: METHOD_CONTRACT.md, FIXTURE_INPUT.json, ORACLE.json, build_fixture.py, CURRENT_KERNEL_DIAGNOSTIC.json, ERRATA_CORRECTION.md, and independent_review/.
