# One-root welded 2L-T compression: bounded qualification

12 October 2026. Qualification only. Immutable application examined: `review0936/source0936`. No production implementation, package, publication, or fabrication approval.

## Decision

**GO to implement and independently test the explicitly conditional standard model below. NO-GO for approving the existing candidate as supplied.**

The supplied DG29 already provides a one-root flange-connected compression calculation. Example 5.4 uses a gusset connected to the beam flange only and K=1.2 to allow sidesway. It is not necessary to obtain another general textbook or invoke generic FEA. This does not establish K=1.2 for an arbitrary freely rotating brace/support assembly: the rotational end conditions must match the model.

The existing native one-root inputs contain neither that physical boundary evidence nor the receiving-W sidesway data. Those omissions must remain specific UNVERIFIED results. They must not be defaulted from symmetry, welded attachment, a member's end distance, or a single generic “restrained” checkbox.

SRC1 is the existing `2L-T soldada · N total200kN · falha da chapa comum` preset, with **only N changed from +200 to −200 kN**. It retains the original geometry and materials. It independently fails the local gusset introduction yielding screen: **245.333333 MPa / 227.272727 MPa = 1.079466667**. No plate, weld, force, steel, or boundary is resized to obtain a pass. Conditional gusset LOAM buckling resistance is 556.476924 kN (utilization 0.359403942), so fixing only buckling would not erase the real yield failure.

## 1. Sources actually inspected

- Supplied AISC Design Guide 29 (2014), Example 5.4: Figure 5-10, printed 98/PDF106, visibly shows the gusset connected to the beam flange only; printed103–104/PDF111–112 checks Whitmore compression using K1.2 and a 6.5 in unbraced length. Its first 0.5 in plate fails, 96.5 kip versus 100 kip; that published failure is retained. Printed108–109/PDF116–117 gives receiving-web yielding and crippling. The bolt/brace adapter in that worked example is not being relabeled as a welded adapter.
- DG29 Appendix C.1, printed374–376/PDF382–384, explains LOAM and lists Single Brace K0.7 with l1 separately from corner models. This contract deliberately takes no K0.7 credit and no corner compactness or two-root K0.5/1.0 credit.
- The originating research, Dowswell (2006), printed94 and97, identifies idealized rotational restraints and a single-brace calibration using nine finite-element specimens: https://ej.aisc.org/index.php/engj/article/download/877/876 . It corroborates the need to identify boundary conditions; it is not evidence that every welded 2L end has infinite rotational restraint.
- Supplied corrected NBR8800:2024/Er1:2025, PDF1 **explicitly corrects 6.5.4(b) to Le/r >25** and accepts effective lengths from elastic stability analysis or methods accepted by the technical/scientific community. Body PDF117 still contains the superseded inequality. For this contract use the errata, not the old body's typo. PDF67–69/printed45–47 supplies the compression curve/effective-area provisions; PDF86–88/printed64–66 supplies receiving-flange/web provisions. PDF93/printed71 and PDF116–117/printed94–95 govern connection assumptions, local parts, shear, and compression.
- Supplied Souza was checked as supporting background, not as a replacement for the corrected NBR2024 formulation. The existing qualified welded adapter supplies the four physical fillets and catalog geometry; the earlier corner compression work supplies only applicable local angle/transfer primitives, never its two-root stability boundary.

Source page images are retained in `source_reading/`; the independent reviewer retains separate NBR/DG29 page evidence.

## 2. Exact first domain

One rectangular, unperforated planar gusset, one continuous double-fillet root along the exterior flange of a rolled W, longitudinal and centred on the W web. Two identical equal angles form the existing symmetric T arrangement, one per gusset face, heel/toe directions identical in-plane. Four continuous equal-length longitudinal welds, equal materials and forces, real access on both faces, no stand-off/fillers. Existing geometric containment, interference, weld-size/length, catalog and fabrication gates remain.

Ordinary static axial compression in normal ultimate combinations; input N remains signed. No independent brace V/M/T, imposed out-of-plane action, 1L, opposed angles, bolted adapter, holes, arbitrary polygon, interrupted root, direct W-web attachment, seismic hinge, fatigue, or global brace/member/frame certification. In-plane load-line eccentricity is retained exactly. First automatic branch requires all modeled body/local-introduction normal stresses and root normal tractions to be nonpositive, within numerical tolerance. Mixed-sign fields receive a precise separate-model issue, not abs(N) substitution.

### Physical boundary contract

K1.2 is the conservative fixed-rotation/sidesway-permitted conventional model used in DG29 Example5.4. It does **not** require artificially fixing lateral translation at the brace end. It **does** require the actual receiving-W/support system and the actual brace continuation to supply the model's rotational restraint.

Record separate, detail-linked evidence for:
1. The gusset root and connected W/frame detail's out-of-plane rotational boundary, including whether the W can twist or its loaded flange can rotate.
2. The brace-end/continuation rotational boundary. Two mirrored angles, zero net out-of-plane eccentricity, and weld continuity establish force symmetry/attachment but do not alone prove this boundary.
3. The receiving-W relative-flange displacement restraint, or the independent inputs required to calculate NBR5.7.5. These are distinct from 1 and 2.

A conventional engineered restraint detail can establish these conditions; a new finite-element model or global brace redesign is not an automatic prerequisite. If its real boundary is different or unknown, retain conditional diagnostics and mark that condition UNVERIFIED. Do not increase K arbitrarily to conceal a mechanism, invent a second gusset root, add fictitious lateral supports, or silently infer a bracing point from a W end coordinate. Changing restraint-relevant geometry invalidates the old evidence until reconciled.

## 3. Gusset and load transfer

Use the existing coordinates x=cs+u cosθ+v sinθ, y=cn+u sinθ−v cosθ. The balanced physical force axis is v0=ec−b/2, not the midpoint between heel and toe. Each L receives N/2; its heel receives fraction1−ec/b and toe ec/b. The common gusset/root/W receive total N once.

At the support-side weld end u0=−Lw/2, build the conventional 30° Whitmore interval [−b/2−Lw tan30°, b/2+Lw tan30°]. Intersect it with the actual rectangle and with the brace-parallel ray projections to the actual connected root. Select the largest interval symmetric about v0 wholly within those constraints. Apply the **full** compression to that reduced width. Omitted width gives no resistance credit. This is a disclosed conservative reduction, not a claim that stress disappears outside the strip. A disconnected/nonpositive interval remains unqualified.

For every retained v, l(v)=y(u0,v)/sinθ, with root intercept xroot=x−l(v)cosθ. Require positive lengths and root intercepts within the real continuous root. Set L=max l(v); because this is affine in v, the two interval endpoints establish the exact maximum. This declines the shorter centreline-length credit used in the example. A virtual Whitmore boundary is not a new physical free plate edge.

A=bw t, I=bw t³/12, r=t/√12, Le=1.2L, Ne=π²EI/Le², λ0=√(Afy/Ne). Use NBR χ=0.658^(λ0²) for λ0≤1.5 and χ=0.877/λ0² otherwise; Nc,Rd=χAfy/γa1. Applying the full curve also below25 is an explicit conservative choice. Do not use tensile shear-lag Ct in compression or manufacture a local-plate reduction from the fictitious Whitmore sides. Report Le/r and retain the prior conservative automatic≤200 service-behavior gate with its correct status as a qualified-domain choice, not an absolute NBR prohibition.

Retain the exact signed horizontal-section and actual local-introduction N/V/M yield screens. Weld vector magnitudes and local substrate shear resistances remain valid on reversal. Each connected angle receives a local gross-compression and conservative full-leg AL3 compactness check. These are local connection checks, not the built-up brace's global stability.

Use the qualified conservative uniformly loaded weld-run shear-only transfer bound where appropriate (common gusset once; each real angle separately). Preserve actual minimum toe geometry for the legacy catalog section. Do not credit a transverse tensile ligament to a compression exit. Deactivate the tensile Ct·Ag·fu capacity, the old outward free-tip tension blocks, and negative-normal tensile rupture. Shear yielding/rupture and genuine weld transfer remain active. If expanding to a geometry not covered by that shear-only bound, qualify its actual reversed physical paths rather than reusing an outward tensile block with absolute load.

## 4. Root and receiving W

Derive Nroot=N sinθ, Vroot=N cosθ, Mroot=N[xforce sinθ−yforce cosθ]. Root traction qn=Nroot/B±6Mroot/B²; qs=Vroot/B. Keep signs for mechanism activation. The existing weld design envelope max(qpeak,1.25qaverage) remains nondirectional and counts two weld throats, one gusset.

For the wholly compressive first branch define Neq=B max(0,−qn_left,−qn_right). This is a conservative uniform peak-pressure envelope; it is not an extra load in equilibrium. Use signed actual N/V/M when exporting member actions.

- Root/gusset/W-contact combined yielding and shear rupture remain active. Normal tensile rupture is inactive when normal traction is negative.
- NBR5.7.3 web local yielding remains active; use actual root length and nearest loaded-point-to-member-end distance. NBR5.7.4 web crippling is added in compression, with the interior/end and loaded-length branches. The existing longitudinal web shear, conservative simultaneous web normal/shear screen, and two-longitudinal-surface flange shear screen remain.
- NBR5.7.2 local flange bending applies to tension in the web; it is inactive for this wholly compressed root. It is not a mandatory compression row.
- NBR5.7.5 sidesway must be resolved separately. If actual relative-flange motion is restrained, record that real detail. Otherwise provide maximum actual laterally unbraced length ℓ involving both flanges and loaded-flange rotation condition. Use h=d−2k for the rolled section. Taking Cr=16E throughout is a disclosed conservative choice when the global bending-yield state is not supplied. Compute the relevant 5.7.5.2 branch unless the strict 5.7.5.3 ratio exclusion applies. Unknown ℓ or rotation status remains UNVERIFIED, not a default2m pass.
- An unrestrained loaded-flange rotation calculation under5.7.5 is not evidence that the gusset root meets the K1.2 rotational model.
- NBR5.7.6 opposing-flange compression-pair buckling activates only if that physical concurrent pair exists. The isolated one-flange local case does not invent one. Concurrent nearby/opposite actions must be identified; an interacting receiver/panel condition outside this local contract must not be silently omitted. The W's global concurrent actions remain unknown/exported, not assumed zero.

## 5. Fixture and acceptance conditions

`build_fixture.py` uses only standard-library arithmetic and no application imports. `FIXTURE_INPUT.json`/`ORACLE.json` are qualification evidence, never production resistance data. The oracle explicitly retains actual restraint unknowns and does not claim a completed local pass.

SRC1: plate400×300×10mm; L100×100×12/Ag2270/ec29mm per angle; θ75°; weld centre(0,150)mm; Lw200mm; both weld legs5mm; local introduction150mm; W310×165×52; N−200kN.

- Raw Whitmorev=[−165.470054,+165.470054]mm. The raw lower side projects beyond the actual root. Root clipping and centring aboutv0=−21 give retainedv=[−154.362308,+112.362308], bw266.724617mm, rather than pretending a longer root exists.
- Root projections[−200.000000,+76.133643]mm. Lmax96.652683mm; Le/r40.177766; χ0.917987433; Nc,Rd556.476924kN.
- Nroot−193.185165kN; Vroot−51.763809kN; Mroot+11.964571kNm; qn[−931.634339,−34.291487]N/mm. Neq372.653736kN. Both root ends remain compressed.
- W local yielding η0.280880943; web crippling η0.370130677; root weld η0.721181907. Local introduction yield **FAIL η1.079466667**, unchanged.
- DG29 source benchmark: exact unrounded column arithmetic gives96.242703kip versus source table/rounded96.5kip; both fail100kip. No forced agreement by changing source dimensions or rounding.

Before implementation acceptance, independently verify sign/minimum-load handling, physical force count, rotation/restraint loss, actual root clipping, θ reflection, all-compression/mixed-sign boundary, λ0=1.5, zero/short lengths, local-shear transfer, receiver end branches,5.7.5 boundaries and changed ℓ. A nonzero |N|<45kN gets a separate signed minimum case before dividing into angles; zero stays a separate real zero case with the established nominal minimum convention. Preserve diagnostic strength failures even when a boundary is unverified.

## Smallest information needed for the actual candidate

No additional general book is needed. To decide whether **this actual detail** can use the model, identify a real sketch/calculation showing the W support/torsional or flange restraint and the brace continuation/end rotational condition, plus the actual W lateral-brace span if5.7.5 is not exempt by a real restraint. The existing geometry by itself cannot supply these facts. This request is separate from, and does not repeat, the already requested internal-fin or one-root-W-web worked examples.
