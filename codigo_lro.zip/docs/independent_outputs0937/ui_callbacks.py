from pathlib import Path
from dataclasses import replace
from copy import deepcopy
import sys,json,hashlib,traceback
SOURCE=Path(sys.argv[1]).resolve();OUT=Path(sys.argv[2]).resolve();OUT.mkdir(parents=True,exist_ok=True);sys.path.insert(0,str(SOURCE))
from replay_support import prepare_runtime, runtime_provenance
ENTRY=SOURCE/'app.py';SOURCE,BOOT=prepare_runtime(SOURCE)
from streamlit.testing.v1 import AppTest
from lro.welded_double_angle_gusset import WeldedDoubleAngleGusset as C,FAMILY,evaluate,presets
from lro.welded_double_angle_gusset_ui import PROJECT,RESULT,REPORT,TEMPLATE,ACCEPTED,DRAFT,_key,decode_project,checks_complete
from lro.one_root_compression import FIELDS,bind_current_evidence,geometry_stamp
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def hashes():return {str(p.relative_to(SOURCE)):sha(p) for pattern in ('app.py','lro/*.py','data/*.json','requirements*.txt') for p in SOURCE.glob(pattern)}
before=hashes();src1=replace(presets()['2L-T soldada · N total200kN · falha da chapa comum'],N=-200000.)
bound=bind_current_evidence(replace(src1,compression_root_rotation='confirmed',compression_root_source='Hypothetical QA root R1',compression_brace_rotation='confirmed',compression_brace_source='Hypothetical QA continuation B1',compression_receiver_relative='confirmed',compression_receiver_source='Hypothetical QA receiver W1',compression_receiver_interaction='isolated',compression_interaction_source='Hypothetical QA isolated load I1'))
def button(at,label):return next(x for x in at.button if x.label==label)
def fresh(c=src1):
 at=AppTest.from_file(str(ENTRY),default_timeout=300);at.session_state['connection_family']=FAMILY;at.session_state[PROJECT]=c.to_dict();at.run();assert not at.exception,[x.message for x in at.exception];return at
def native(at):return decode_project(json.dumps(at.session_state[PROJECT]))
def snap(at):return {k:deepcopy(at.session_state[k]) for k in (PROJECT,RESULT,REPORT,TEMPLATE,ACCEPTED,DRAFT) if k in at.session_state}
def upload(at,payload):
 at.get('file_uploader')[0].upload('independent0937.json',payload if isinstance(payload,bytes) else json.dumps(payload).encode(),'application/json').run();button(at,'Carregar 2L-T soldada').click().run();assert not at.exception
def generate(at):
 b=button(at,'Gerar memória 2L-T soldada');assert not b.disabled;b.click().run();assert not at.exception and REPORT in at.session_state
records=[]
def record(name,fn):
 print('RUN',name,flush=True)
 try:r=fn();records.append(dict(name=name,pass_=True,detail=r));print('PASS',name,flush=True)
 except Exception as exc:traceback.print_exc();records.append(dict(name=name,pass_=False,error=repr(exc)));print('FAIL',name,flush=True)
 (OUT/'CALLBACK_RECEIPT.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
def strict():
 data=bound.to_dict();reject=[]
 for field,orig in data['connection'].items():
  variants=[]
  if type(orig) in (int,float):variants=[True,float('nan'),float('inf'),-float('inf'),'1']
  if field in FIELDS and type(orig) is str:variants=[True,1,None]
  if field in ('compression_root_rotation','compression_brace_rotation','compression_receiver_relative','compression_flange_rotation','compression_receiver_interaction'):variants.append('approved')
  for v in variants:
   bad=deepcopy(data);bad['connection'][field]=v
   try:decode_project(json.dumps(bad));raise AssertionError('Accepted '+field+':'+repr(v))
   except (TypeError,ValueError):pass
   reject.append([field,repr(v)])
 for f in FIELDS:
  bad=deepcopy(data);bad['connection'].pop(f)
  try:decode_project(json.dumps(bad));raise AssertionError('Accepted missing '+f)
  except (TypeError,ValueError):pass
  reject.append([f,'missing'])
 old=json.loads((SOURCE/'examples/welded_double_angle_gusset0928_am200_shared_fail.json').read_text());old['connection']['N']=-200000.
 migrated=decode_project(json.dumps(old));assert migrated.N==-200000.
 assert all(getattr(migrated,f)==getattr(C(),f) for f in FIELDS)
 return {'rejections':len(reject),'witnesses':reject,'old_schema_migrates_without_inventing_evidence':True}
record('strict native fields and legacy migration',strict)
def mutations():
 changed=[]
 for f,v in {'support_member':'column','support_profile':'W360x51','plate_width':402.,'plate_height':302.,'plate_t':11.,'theta_deg':74.5,'center_s':1.,'center_n':151.,'weld_length':201.,'end_margin':21.,'angle_weld_leg':5.1,'angle_weld_edge_detail':'reinforced','root_weld_leg':5.1,'support_end_left':1001.,'support_end_right':1001.,'accessible_both_faces':False}.items():
  c=replace(bound,**{f:v});assert all(geometry_stamp(c,role)!=getattr(bound,'compression_'+role+'_stamp') for role in ('root','brace','receiver')),f;changed.append(f)
 for f,v in {'N':-100000.,'project':'Changed label','gusset_steel':'ASTM A572 Gr.50','notes':'Updated QA note'}.items():
  c=replace(bound,**{f:v});assert all(geometry_stamp(c,role)==getattr(bound,'compression_'+role+'_stamp') for role in ('root','brace','receiver')),f
 c=replace(bound,compression_unbraced_length=2000.);assert geometry_stamp(c,'receiver')!=bound.compression_receiver_stamp and geometry_stamp(c,'root')==bound.compression_root_stamp and geometry_stamp(c,'brace')==bound.compression_brace_stamp
 return {'physical_mutations':changed,'independent_receiver_stamp':True,'loads_materials_labels_preserve_geometry':True}
record('separate stamp geometry identity',mutations)
def sign_navigation():
 at=fresh(bound);assert len(at.selectbox(key='connection_family').options)==19;generate(at)
 for n in (-20.,0.,100.,-100.,-200.):
  at.number_input(key=_key(('N',))).set_value(n).run();assert not at.exception;assert native(at).N==1000*n and REPORT not in at.session_state
  assert all(getattr(native(at),f)==getattr(bound,f) for f in FIELDS)
  controls={x.key for kind in ('selectbox','text_input','number_input') for x in getattr(at,kind)}
  assert (_key(('compression_root_rotation',)) in controls)==(n<0)
  if n==-20.:assert [x['N'] for x in at.session_state[RESULT]['cases']]==[-20000.,-45000.]
  if n==0.:assert [x['N'] for x in at.session_state[RESULT]['cases']]==[0.,45000.]
 saved=deepcopy(at.session_state[PROJECT]);other=next(x for x in at.selectbox(key='connection_family').options if x!=FAMILY);at.selectbox(key='connection_family').set_value(other).run();assert not at.exception;at.selectbox(key='connection_family').set_value(FAMILY).run();assert not at.exception;assert at.session_state[PROJECT]==saved
 upload(at,saved);assert at.session_state[PROJECT]==saved;generate(at)
 at.checkbox(key='wdag_report_detailed').check().run();assert REPORT not in at.session_state;generate(at)
 at.number_input(key=_key(('center_n',))).set_value(151.).run();assert not at.exception and REPORT not in at.session_state;r=at.session_state[RESULT];assert not checks_complete(r);assert set(('compression_root_boundary','compression_brace_boundary','compression_receiver_evidence'))<=set(r['summary']['unverified_ids']);generate(at)
 stale=deepcopy(at.session_state[PROJECT]);upload(at,stale);assert at.session_state[PROJECT]==stale and not checks_complete(at.session_state[RESULT])
 button(at,'Vincular fontes informadas à geometria atual').click().run();assert not at.exception and REPORT not in at.session_state
 assert all(getattr(native(at),'compression_'+role+'_stamp')==geometry_stamp(native(at),role) for role in ('root','brace','receiver'))
 return {'routes':19,'signed_actual_and_minimum':True,'reopen_exact':True,'report_invalidates_for_force_geometry_detail_setting':True,'stale_geometry_stays_pending_after_reopen':True,'explicit_rebind':True}
record('real signed callbacks save reopen route switch stale reports',sign_navigation)
def independent():
 at=fresh(bound);generate(at);tested=[]
 for role in ('root','brace'):
  for state in ('unknown','absent'):
   at.selectbox(key=_key(('compression_'+role+'_rotation',))).set_value(state).run();assert not at.exception;r=at.session_state[RESULT];assert r['status']=='CHECKS_FAIL_AND_UNVERIFIED' and not r['global_pass'];assert 'compression_'+role+'_boundary' in r['summary']['unverified_ids'];assert r['summary']['failed_check_ids'];generate(at);tested.append(role+':'+state)
  at.selectbox(key=_key(('compression_'+role+'_rotation',))).set_value('confirmed').run();assert not at.exception
 at.selectbox(key=_key(('compression_receiver_relative',))).set_value('absent').run();assert not at.exception;r=at.session_state[RESULT];assert 'compression_receiver_span' in r['summary']['unverified_ids'];assert r['compression']['boundaries']['root']['qualified'] and r['compression']['boundaries']['brace']['qualified'];assert native(at).compression_unbraced_length==0
 at.number_input(key=_key(('compression_unbraced_length',))).set_value(2000.).run();at.selectbox(key=_key(('compression_flange_rotation',))).set_value('free').run();assert not at.exception;assert 'compression_receiver_evidence' in at.session_state[RESULT]['summary']['unverified_ids'];button(at,'Vincular fontes informadas à geometria atual').click().run();assert not at.exception
 assert native(at).compression_root_stamp==bound.compression_root_stamp and native(at).compression_brace_stamp==bound.compression_brace_stamp
 at.selectbox(key=_key(('compression_root_rotation',))).set_value('unknown').run();assert 'compression_root_boundary' in at.session_state[RESULT]['summary']['unverified_ids']
 return {'independent_absence':tested,'receiver_free_rotation_does_not_prove_root':True,'unknown_span_zero_not_defaulted':True,'receiver_changes_do_not_erase_separate_root_brace_sources':True}
record('boundary loss and receiver independence',independent)
def atomic():
 at=fresh();generate(at);original=snap(at);bads=[]
 for f,v in [('compression_unbraced_length',True),('compression_unbraced_length',float('nan')),('compression_flange_rotation','fixed'),('compression_root_stamp',1),('compression_root_source',False),('compression_receiver_relative','yes'),('N','-200000')]:
  b=deepcopy(original[PROJECT]);b['connection'][f]=v;bads.append(b)
 b=deepcopy(original[PROJECT]);b['connection'].pop('compression_brace_source');bads.append(b)
 for b in bads:
  upload(at,b);assert any('Não foi possível abrir' in x.value for x in at.error);assert snap(at)==original
 return {'rejected_uploads':len(bads),'all_state_preserved':list(original)}
record('atomic actual upload rejection preserves diagnostic report',atomic)
def sentinel_sources():
 witnesses=[]
 for field in ('compression_root_source','compression_brace_source','compression_receiver_source','compression_interaction_source'):
  for value in ('', ' ', 'Não informado','unknown','none','-'):
   c=bind_current_evidence(replace(bound,**{field:value}));r=evaluate(c);assert not r['global_pass'] and not checks_complete(r)
   issue={'compression_root_source':'compression_root_boundary','compression_brace_source':'compression_brace_boundary','compression_receiver_source':'compression_receiver_evidence','compression_interaction_source':'compression_receiver_interaction'}[field]
   assert issue in r['summary']['unverified_ids'];witnesses.append([field,value])
 at=fresh(bound)
 for field in ('compression_root_source','compression_brace_source','compression_receiver_source','compression_interaction_source'):
  at.text_input(key=_key((field,))).set_value('Não informado').run();assert not at.exception;button(at,'Vincular fontes informadas à geometria atual').click().run();assert not at.exception;assert not checks_complete(at.session_state[RESULT]);generate(at)
 return {'source_sentinel_witnesses':len(witnesses),'witnesses':witnesses,'actual_callback_source_losses':4,'pending_reports_remain_available':True}
record('placeholder sources cannot qualify actual physical boundary',sentinel_sources)
after=hashes();(OUT/'RUNTIME_PROVENANCE.json').write_text(json.dumps({**runtime_provenance(BOOT,SOURCE),'before':before,'after':after,'unchanged':before==after,'not_claimed':['Browser DOM','OS file dialog']},indent=2)+'\n');assert before==after,'Runtime changed';assert all(x['pass_'] for x in records)
