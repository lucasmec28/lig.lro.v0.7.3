"""Prepared immutable actual-APP gate. No source-checkout fallback is allowed.

Run with only pinned test dependencies on PYTHONPATH, e.g.:
  python -B replay_finalapp.py /path/to/extracted_APP /path/to/external/evidence
No packaging, extraction by this harness, installation, or upload is performed.
The application's own hash-bound outer wrapper must extract its embedded runtime.
"""
from pathlib import Path
from zipfile import ZipFile
import sys,json,hashlib,subprocess,os
here=Path(__file__).resolve().parent;app=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();out.mkdir(parents=True,exist_ok=True)
assert (app/'app.py').is_file() and (app/'codigo_lro.zip').is_file(),'Actual APP outer entry/bundle required'
assert not (app/'lro').exists(),'Do not substitute extracted source checkout'
assert not out.is_relative_to(app),'Evidence must stay outside immutable APP'
sha=lambda b:hashlib.sha256(b).hexdigest()
def inventory(root):return {str(p.relative_to(root)):sha(p.read_bytes()) for p in sorted(root.rglob('*')) if p.is_file()}
outer_before=inventory(app);approved=json.loads((here/'SOURCE_RUNTIME_HASHES.json').read_text());held=json.loads((here/'HELD_RUNTIME_TEST_HASHES.json').read_text())
with ZipFile(app/'codigo_lro.zip') as z:
 names=set(z.namelist())
 for name,value in held.items():assert name in names and sha(z.read(name))==value,('Embedded held runtime/test mismatch',name)
 for name,value in approved.items():
  if name=='requirements-dev.txt' and name not in names:continue
  assert name in names and sha(z.read(name))==value,('Embedded runtime mismatch',name)
def run(script,*args):
 env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
 with (out/(Path(script).stem+'.log')).open('w') as log:subprocess.run([sys.executable,'-B',str(here/script),*map(str,args)],stdout=log,stderr=subprocess.STDOUT,env=env,check=True)
run('capture_outputs.py',app,out/'captures');run('compare_outputs.py',out/'captures')
run('ui_callbacks.py',app,out/'callbacks');run('artifact_semantics.py',app,out/'captures')
run('replay_retained_states.py',app,out/'retained_states')
run('legacy/legacy_long_group_callbacks.py',app,out/'legacy')
run('legacy/compare_replay.py',out/'legacy','--output',out/'LEGACY_REPLAY_COMPARISON.json')
run('legacy/validate_legacy_normalizer.py',out/'legacy/bolted_angle_gusset_950.svg',out/'LEGACY_NORMALIZER_MUTATION_PROOF.json')
provenances=[]
for path in ('captures/RUNTIME_PROVENANCE.json','callbacks/RUNTIME_PROVENANCE.json'):
 p=json.loads((out/path).read_text());assert p['before']==p['after'] and p['unchanged']
 assert p['actual_outer_entry']==str(app/'app.py') and p['outer_entry_sha256']==outer_before['app.py']
 assert p['embedded_bundle_sha256']==outer_before['codigo_lro.zip'];runtime=Path(p['loaded_runtime_root'])
 assert p['wrapper_extraction']['root']==str(runtime) and p['wrapper_extraction']['prefix'].startswith('lro_ligacoes_')
 assert runtime!=app and not runtime.is_relative_to(here)
 for name,value in p['after'].items():assert approved[name]==value,('Observed runtime mismatch',name)
 for name,m in p['loaded_application_modules'].items():
  assert Path(m['path']).is_relative_to(runtime) and approved[m['relative_path']]==m['sha256'],('Loaded module mismatch',name)
 provenances.append({'receipt':path,'runtime':str(runtime),'wrapper_extraction':p['wrapper_extraction'],'application_modules':len(p['loaded_application_modules'])})
legacy=json.loads((out/'legacy/RUNTIME_PROVENANCE.json').read_text());assert legacy['before']==legacy['after']
for name,value in legacy['after'].items():assert approved[name]==value
callbacks=json.loads((out/'callbacks/CALLBACK_RECEIPT.json').read_text());assert len(callbacks)==6 and all(x['pass_'] for x in callbacks)
outer_after=inventory(app);assert outer_before==outer_after,'APP was modified'
receipt={'status':'GO','scope':'0.9.37 actual immutable APP-only native UI/callback/export replay','outer_files_before':outer_before,'outer_files_after':outer_after,'held_runtime_test_files':len(held),'held_manifest_sha256':sha((here/'HELD_RUNTIME_TEST_HASHES.json').read_bytes()),'capture_scenarios':14,'callback_groups':6,'retained_native_result_states':19,'legacy_long_group_callback_states':4,'observed_runtime_provenance':provenances,'output_comparison':'captures/REPLAY_COMPARISON.json','legacy_comparison':'LEGACY_REPLAY_COMPARISON.json','visual_basis':'All Word ZIP members, PNG/native/full results exact; SVG exact except inherited narrow generated dc:date and bijective generated defs IDs/references. Source visual receipts therefore apply to identical content.','not_claimed':['Browser DOM or OS file dialog','New dependency installation','Physical evidence truth','Global/fabrication structural approval','Upload or deployment']}
(out/'FINALAPP_OUTPUT_ACCEPTANCE.json').write_text(json.dumps(receipt,indent=2)+'\n');print('GO actual immutable APP output replay',out/'FINALAPP_OUTPUT_ACCEPTANCE.json')
