"""Read-only source/actual-APP bootstrap and observed module provenance."""
from pathlib import Path
import sys,json,hashlib
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def prepare_runtime(source):
 source=Path(source).resolve();entry=source/'app.py';assert entry.is_file()
 assert not any(n=='lro' or n.startswith('lro.') for n in sys.modules),'Bootstrap must run before application imports'
 sys.path.insert(0,str(source));record={'actual_outer_entry':str(entry),'outer_entry_sha256':sha(entry),'embedded_bundle_sha256':None,'wrapper_extraction':None}
 if (source/'codigo_lro.zip').exists():
  assert not (source/'lro').exists(),'APP mode must use actual outer wrapper, not an extracted source checkout'
  from streamlit.testing.v1 import AppTest
  import tempfile
  events=[];original=tempfile.TemporaryDirectory
  def observe(*args,**kwargs):
   holder=original(*args,**kwargs);events.append({'root':str(Path(holder.name).resolve()),'prefix':kwargs.get('prefix')});return holder
  tempfile.TemporaryDirectory=observe
  try:
   boot=AppTest.from_file(str(entry),default_timeout=300).run();assert not boot.exception,[x.message for x in boot.exception]
  finally:tempfile.TemporaryDirectory=original
  root=Path(sys.modules['lro'].__file__).resolve().parent.parent
  extraction=next((e for e in events if e['root']==str(root)),None)
  assert extraction and extraction['prefix'].startswith('lro_ligacoes_'),'Runtime must be observed real wrapper allocation'
  record.update(embedded_bundle_sha256=sha(source/'codigo_lro.zip'),wrapper_extraction=extraction)
 else:root=source
 record['loaded_runtime_root']=str(root)
 return root,record

def runtime_provenance(record,root):
 root=Path(root).resolve();modules={}
 for name,module in sorted(sys.modules.items()):
  if name=='lro' or name.startswith('lro.'):
   p=Path(module.__file__).resolve();assert p.is_relative_to(root),(name,str(p));modules[name]={'path':str(p),'relative_path':str(p.relative_to(root)),'sha256':sha(p)}
 return dict(record,loaded_application_modules=modules)
