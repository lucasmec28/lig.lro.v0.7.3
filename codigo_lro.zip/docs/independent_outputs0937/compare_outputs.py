"""Exact portable output replay against accepted source artifacts.

SVG normalization is limited to generated dc:date text and bijective generated
path/clip IDs with exact references. All Word ZIP members must be byte-identical;
ZIP container timestamps/ordering are not a document-content normalization.
"""
from pathlib import Path
from zipfile import ZipFile
import sys,json,hashlib
from legacy_svg_normalization import normalize_svg
here=Path(__file__).resolve().parent;out=Path(sys.argv[1]).resolve()
sha=lambda b:hashlib.sha256(b).hexdigest()
expected=json.loads((here/'SOURCE_EXPECTED_OUTPUTS.json').read_text());actual=json.loads((out/'DOWNLOAD_RECEIPT.json').read_text());assert len(expected)==len(actual)==14
actual={r['tag']:r for r in actual};records=[]
for ex in expected:
 tag=ex['tag'];got=actual[tag]
 for k in ('status','complete','diagnostic_report_ready','detailed','check_count','input_sha256'):assert got[k]==ex[k],(tag,k)
 assert set(got['exports'])==set(ex['exports']),(tag,'export membership')
 for ext,want in ex['exports'].items():
  data=(out/(tag+ext)).read_bytes()
  assert sha(data)==got['exports'][ext]['sha256'],(tag,ext,'capture receipt')
  if ext=='.svg':assert normalize_svg(data)['sha256']==ex['svg_normalized_sha256'],(tag,'strict SVG normalized bytes')
  elif ext=='.docx':
   with ZipFile(out/(tag+ext)) as z:members={n:sha(z.read(n)) for n in z.namelist()}
   assert members==ex['all_docx_members'],(tag,'all Word members')
  else:assert sha(data)==want['sha256'],(tag,ext)
 assert sha((out/(tag+'.results.json')).read_bytes())==ex['result_sha256'],(tag,'full result bytes')
 records.append({'tag':tag,'pass':True,'word_all_members_exact':'.docx' in ex['exports'],'SVG_generated_metadata_only':'.svg' in ex['exports']})
result={'status':'PASS','scenarios':len(records),'records':records};(out/'REPLAY_COMPARISON.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS',len(records),'output scenarios')
