from pathlib import Path
from zipfile import ZipFile
import json,hashlib,shutil,datetime,sys
HERE=Path(__file__).resolve().parent;SOURCE=HERE.parent/'source0937';FINAL=HERE/'final';LEG=HERE/'legacy_review/final_checkpoint'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
heldpath=HERE.parent/'HELD_RUNTIME_TEST_HASHES.json';assert sha(heldpath)=='a6df6dab4fc40bede86a7bbc14aa36ff11dbb075135795967964497a7b16eac1';held=read(heldpath);assert len(held)==288
assert all(sha(SOURCE/k)==v for k,v in held.items())
runtime={str(p.relative_to(SOURCE)):sha(p) for pattern in ('app.py','lro/*.py','data/*.json','requirements*.txt') for p in SOURCE.glob(pattern)}
assert len(runtime)==141
for p in [FINAL/'captures/RUNTIME_PROVENANCE.json',FINAL/'callbacks/RUNTIME_PROVENANCE.json']:
 r=read(p);assert r['unchanged'] and r['before']==r['after']==runtime
assert all(runtime[k]==v for k,v in held.items() if k in runtime)
assert read(LEG/'REVIEW_RESULT.json')['status']=='GO';assert read(LEG/'SOURCE_RUNTIME_HASHES.json')==runtime
cb=read(FINAL/'callbacks/CALLBACK_RECEIPT.json');assert len(cb)==6 and all(x['pass_'] for x in cb)
sem=read(FINAL/'captures/ARTIFACT_SEMANTICS.json');assert len(sem['records'])==14 and sem['status']=='PASS'
assert read(FINAL/'positive_parity/POSITIVE_PARITY.json')['pass']
# Every final Word page is directly inspected or precisely matched to recorded inspection.
pages=read(FINAL/'WORD_PAGE_MATCHES.json')
for row in pages:
 if not row['review_basis']:
  assert row['page']==6 and row['document'] in ('negative_minimum','qualified_numeric_pass')
  row['review_basis']={'direct_full_resolution_view_image':True,'notes':'Le/r = 200 wording corrected; equations and receiving-W conditional status remain readable'}
 row['pass']=True;assert sha(HERE/row['path'])==row['sha256']
assert len(pages)==69
write(HERE/'WORD_VISUAL_REVIEW.json',{'status':'PASS','documents':7,'pages':69,'method':'Every final rendered page directly inspected full-page or exact PNG SHA256 matched to a documented direct inspection; no contact-sheet/text-only acceptance','open_issues':[],'resolved':['WORD-LE-EQUATION: literal Le token corrupted the original OMML render, now native subscript L_e and structured powers','WORD-INACTIVE-CT: compression primitive Ct now None and basis explicitly INATIVO','WORD-SERVICE-LIMIT: Le/r=200 conservative automatic-domain limit now explicit'],'pages_reviewed':pages})
# Independent SVG raster visual lineage; full-resolution direct checks are recorded by exact pixel digest.
known={}
reviewed=[('round3',x) for x in ('SRC1_compact','negative_minimum','zero_minimum')]+[('round5',x) for x in ('mixed_sign','conditional_numeric_pass','qualified_numeric_pass')]+[('final',x) for x in ('SRC1_compact','negative_minimum','zero_minimum','qualified_SRC1_fail','receiver_span_free','stale_root_geometry','positive_legacy','source_example_compact')]
for stage,tag in reviewed:
 p=HERE/stage/'svg_pixels'/(tag+'.png');known[sha(p)]={'direct_full_resolution_view_image':True,'stage':stage,'tag':tag,'path':str(p.relative_to(HERE))}
drawings=[]
for p in sorted((FINAL/'svg_pixels').glob('*.png')):
 h=sha(p);basis=known.get(h)
 if not basis:
  # Detailed mode never changes the drawing.
  counterpart={'SRC1_detailed':'SRC1_compact','source_example_detailed':'source_example_compact'}.get(p.stem)
  assert counterpart and sha(FINAL/'svg_pixels'/(counterpart+'.png'))==h,(p,h)
  basis=known[h]
 drawings.append(dict(tag=p.stem,svg_sha256=sha(FINAL/'captures'/(p.stem+'.svg')),png_sha256=sha(FINAL/'captures'/(p.stem+'.png')),raster_sha256=h,raster=str(p.relative_to(HERE)),review_basis=basis,pass_=True))
assert len(drawings)==13
write(HERE/'DRAWING_VISUAL_REVIEW.json',{'status':'PASS','drawing_scenarios':13,'unique_raster_views':len(set(x['raster_sha256'] for x in drawings)),'open_issues':[],'resolved':['MIXED-STRIP-FOOTER: no None values or assertion of absent purple strip; precise unqualified-strip diagnostic','MIXED-TOE-LABEL: negative theta45 toe callout and +s label separated without changing positive branch'],'drawings':drawings,'physical_checks':'Real plotted annotation direction checked from Matplotlib coordinates and rendered image; four physical fillet IDs preserved; root projections remain on actual connected root. The existing Annotation gid is not emitted by SVG and is not asserted as XML evidence.'})
# Exact source example artifact checks, including all Word members, not ZIP timestamps.
examples=SOURCE/'examples/one_root_compression0937';exreceipt=[]
for name,h in read(examples/'MANIFEST.json').items():assert sha(examples/name)==h
for detailed in (False,True):
 tag='source_example_'+('detailed' if detailed else 'compact');orig=examples/('SRC1_'+('detailed' if detailed else 'compact')+'.docx');capt=FINAL/'captures'/(tag+'.docx')
 with ZipFile(orig) as a,ZipFile(capt) as b:
  am={n:hashlib.sha256(a.read(n)).hexdigest() for n in a.namelist() if n.startswith('word/')};bm={n:hashlib.sha256(b.read(n)).hexdigest() for n in b.namelist() if n.startswith('word/')};assert am==bm
 exreceipt.append(dict(tag=tag,source_sha256=sha(orig),captured_sha256=sha(capt),word_members_equal=True,word_members=am))
assert read(examples/'SRC1_project.json')==read(FINAL/'captures/source_example_compact.json')
assert read(examples/'SRC1_results.json')==read(FINAL/'captures/source_example_compact.results.json')
assert sha(examples/'SRC1.png')==sha(FINAL/'captures/source_example_compact.png')
write(HERE/'SOURCE_EXAMPLE_ARTIFACT_CHECKS.json',{'status':'PASS','examples_manifest_sha256':sha(examples/'MANIFEST.json'),'native_result_png_exact':True,'Word':exreceipt,'visual_receipt':'SOURCE_EXAMPLE_VISUAL_REVIEW.json'})
expected=[]
for row in read(FINAL/'captures/DOWNLOAD_RECEIPT.json'):
 rec={k:row[k] for k in ('tag','status','complete','diagnostic_report_ready','detailed','check_count','input_sha256')};rec['exports']={ext:{k:r[k] for k in ('sha256','bytes','label')} for ext,r in row['exports'].items()};rec['result_sha256']=sha(FINAL/'captures'/(row['tag']+'.results.json'))
 if '.docx' in row['exports']:
  with ZipFile(row['exports']['.docx']['path']) as z:rec['word_members']={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.startswith('word/')}
 expected.append(rec)
write(HERE/'SOURCE_EXPECTED_OUTPUTS.json',expected);write(HERE/'SOURCE_RUNTIME_HASHES.json',runtime);shutil.copy2(heldpath,HERE/'HELD_RUNTIME_TEST_HASHES.json')
write(HERE/'FORMAL_HOLD_VERIFICATION.json',{'status':'PASS','held_sha256':sha(heldpath),'held_count':len(held),'all_current_held_paths_match':True,'all_final_capture_callback_runtime_before_after_match':True,'independent_runtime_count':len(runtime),'extra_requirements_hashes':{k:v for k,v in runtime.items() if k not in held}})
receipt={'status':'GO','scope':'Independent 0.9.37 source UI/native/report/drawing and retained legacy regression acceptance only','recorded_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_root':str(SOURCE),'held_manifest_sha256':sha(heldpath),'held_runtime_test_files':288,'independent_runtime_files':141,'capture_scenarios':14,'genuine_callback_groups':6,'strict_native_mutation_rejections':144,'actual_atomic_rejected_uploads':8,'physical_geometry_identity_mutations':16,'placeholder_source_witnesses':24,'placeholder_source_actual_UI_edits':4,'retained_positive_zero_one_root_fixtures':7,'legacy_corner_native_result_states':12,'legacy_long_group_callback_states':4,'legacy_strict_comparisons':90,'legacy_svg_mutation_witnesses':7,'rendered_word_documents':7,'rendered_word_pages':69,'drawing_scenarios':13,'unique_drawing_raster_views':11,'SRC1_local_yield_eta':1.0794666666666668,'SRC1_status':'CHECKS_FAIL_AND_UNVERIFIED','SRC1_unverified_conditions':6,'original_geometry_preserved':True,'no_open_output_blockers':True,'source_example_long_title_checked':True,'preserved_exploratory_and_historical_evidence':True,'final_root':'final','not_claimed':['Numerical-method approval (separate engine review)','Full aggregate suite (production writer)','Actual installed restraint truth or execution certification','Global brace/W/frame approval','Fabrication approval','Browser DOM/OS file dialog/clipboard interaction','APP-only replay','Packaging/archive','Upload or deployment']}
write(HERE/'SOURCE_OUTPUT_ACCEPTANCE.json',receipt)
# Inventory all retained evidence, excluding inventories that would recursively change themselves.
manifest={str(p.relative_to(HERE)):dict(sha256=sha(p),bytes=p.stat().st_size) for p in HERE.rglob('*') if p.is_file() and 'portable_evidence' not in p.parts and p.name not in ('RETAINED_EVIDENCE_MANIFEST.json',)}
write(HERE/'RETAINED_EVIDENCE_MANIFEST.json',{'root':str(HERE),'files':manifest,'historical_root_manifest':'INHERITED_EVIDENCE_MANIFEST.json','all_earlier_rounds_retained':True})
print(json.dumps(receipt,ensure_ascii=False,indent=2))
