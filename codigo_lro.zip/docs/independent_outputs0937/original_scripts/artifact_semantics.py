from pathlib import Path
from zipfile import ZipFile
import sys,json,math,hashlib,xml.etree.ElementTree as ET
source=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();sys.path.insert(0,str(source));from lro.welded_double_angle_gusset_presentation import physical_envelopes
from lro.welded_double_angle_gusset_ui import decode_project
from lro.welded_double_angle_gusset import evaluate
from lro.welded_double_angle_gusset_drawing import figure,input_fingerprint
from lro.welded_double_angle_gusset_report import create_report
from docx import Document
from io import BytesIO
oracle=json.loads((source.parent.parent/'one_root_compression_scope20261012/ORACLE.json').read_text());records=[]
for row in json.loads((out/'DOWNLOAD_RECEIPT.json').read_text()):
 tag=row['tag'];c=decode_project((out/(tag+'.json')).read_bytes());r=json.loads((out/(tag+'.results.json')).read_text());assert evaluate(c)==r
 groups=physical_envelopes(r);members=[m['id'] for g in groups for m in g['members']];assert sorted(members)==sorted(x['id'] for x in r['checks'])
 if c.N<0:
  for g in groups:
   if g['mechanism']=='compression_buckling':assert g['conditional']==(not all(r['compression']['boundaries'][x]['qualified'] for x in ('root','brace')))
  if r['checks']:
   for case in r['cases']:
    ids={x['id'] for x in r['checks'] if x['case_id']==case['id']};assert len([x for x in ids if '__angle_weld_' in x])==4
    assert sum(x['N'] for x in case['angle_forces'])==case['N'];assert len(case['angle_forces'])==2
    assert all(x['heel_N']<0 and x['toe_N']<0 for x in case['angle_forces'])
    assert case['plate_sections']['local']['Ct'] is None and 'INATIVO' in case['plate_sections']['local']['Ct_basis']
  if r.get('compression',{}).get('strip'):
   strip=r['compression']['strip'];assert max(abs(x) for x in strip['root_projections'])<=c.plate_width/2+1e-8
 if tag in ('SRC1_compact','SRC1_detailed','source_example_compact','source_example_detailed'):
  s=r['compression']['strip'];mapping={'width':'width','Lmax':'length_upper_bound','Le':'Le','Le_over_r':'slenderness','resistance':'Nc_Rd'}
  for k,v in mapping.items():assert math.isclose(s[k],oracle['geometry'][v],rel_tol=2e-12,abs_tol=1e-10),(tag,k)
  for k,v in [('N','root_N'),('V','root_V'),('M','root_M')]:assert math.isclose(r['root'][k],oracle['signed'][v],rel_tol=2e-12,abs_tol=1e-8)
  assert len(r['summary']['failed_check_ids'])==1 and not r['global_pass'] and not r['local_pass']
 if '.svg' in row['exports']:
  tree=ET.fromstring((out/(tag+'.svg')).read_text());ids={e.attrib.get('id') for e in tree.iter()} # Annotation group IDs are not emitted by this legacy Matplotlib route; capture_outputs verifies the real artist coordinates.
  welds={k for k in ids if k and k.startswith('angle_weld_')};assert len(welds)==4
  assert input_fingerprint(c) in (out/(tag+'.svg')).read_text()
  if tag=='mixed_sign':
   text=' '.join(''.join(e.itertext()) for e in tree.iter() if e.tag.endswith('text'));assert 'None' not in text and 'faixa não qualificada' in text;assert 'compression_whitmore_retained' not in ids
 if '.docx' in row['exports']:
  with ZipFile(out/(tag+'.docx')) as z:
   doc=Document(BytesIO(z.read('word/document.xml'))) if False else None
   xml=z.read('word/document.xml').decode();assert '<m:oMath' in xml
  txt=(out/(tag+'_word.txt')).read_text()
  if c.N<0:assert 'Le/r = 200' in txt
  if not r['global_pass']:assert 'aprovam o detalhe real' in txt if c.N<0 else True
  if tag=='negative_minimum':assert '-20,00000' in txt and '-45,00000' in txt and '-65,00000' not in txt
  if tag=='conditional_numeric_pass':assert 'NOT_VERIFIED' in txt and 'Sem atendimento local completo' in txt
 records.append(dict(tag=tag,pass_=True,physical_envelopes=len(groups),row_count=len(r['checks']),conditional=any(g.get('conditional') for g in groups)))
(out/'ARTIFACT_SEMANTICS.json').write_text(json.dumps({'status':'PASS','records':records,'oracle_source':'one_root_compression_scope20261012/ORACLE.json','oracle_sha256':hashlib.sha256((source.parent.parent/'one_root_compression_scope20261012/ORACLE.json').read_bytes()).hexdigest()},indent=2))
print('PASS',len(records),'artifact semantic groups')
