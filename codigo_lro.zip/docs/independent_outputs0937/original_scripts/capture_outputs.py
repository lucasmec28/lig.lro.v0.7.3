from pathlib import Path
from dataclasses import replace
from copy import deepcopy
from zipfile import ZipFile
from io import BytesIO
import sys,json,hashlib,traceback
HERE=Path(__file__).resolve().parent;SOURCE=Path(sys.argv[1]).resolve();OUT=Path(sys.argv[2]).resolve();OUT.mkdir(parents=True,exist_ok=True);sys.path.insert(0,str(SOURCE))
from streamlit.testing.v1 import AppTest
from streamlit.runtime.memory_media_file_storage import MemoryMediaFileStorage
from lro.welded_double_angle_gusset import WeldedDoubleAngleGusset as C,FAMILY,evaluate,presets
from lro.welded_double_angle_gusset_ui import PROJECT,RESULT,REPORT,_key,decode_project,checks_complete
from lro.one_root_compression import bind_current_evidence,geometry_stamp
from lro.welded_double_angle_gusset_drawing import image_bytes,input_fingerprint,figure
from lro.welded_double_angle_gusset_presentation import physical_envelopes
from docx import Document
sha=lambda b:hashlib.sha256(b).hexdigest()
def hashes():return {str(p.relative_to(SOURCE)):sha(p.read_bytes()) for pattern in ('app.py','lro/*.py','data/*.json','requirements*.txt') for p in SOURCE.glob(pattern)}
before=hashes();files={};old=MemoryMediaFileStorage.load_and_get_id
def observe(storage,*args,**kwargs):
 ident=old(storage,*args,**kwargs);files[ident]=storage._files_by_id[ident].content;return ident
MemoryMediaFileStorage.load_and_get_id=observe
original=presets()['2L-T soldada · N total200kN · falha da chapa comum'];src1=replace(original,N=-200000.)
assert all(getattr(src1,k)==getattr(original,k) for k in src1.__dataclass_fields__ if k!='N')
bound=bind_current_evidence(replace(src1,compression_root_rotation='confirmed',compression_root_source='Independent QA hypothetical root restraint detail R1',compression_brace_rotation='confirmed',compression_brace_source='Independent QA hypothetical brace continuation detail B1',compression_receiver_relative='confirmed',compression_receiver_source='Independent QA hypothetical receiver relative-flange detail W1',compression_receiver_interaction='isolated',compression_interaction_source='Independent QA local concurrent-action isolation detail I1'))
cases=[('SRC1_compact',src1,False),('SRC1_detailed',src1,True),('conditional_numeric_pass',replace(src1,N=-100000.),False),('qualified_numeric_pass',replace(bound,N=-100000.),False),('qualified_SRC1_fail',bound,False),('negative_minimum',replace(src1,N=-20000.),False),('zero_minimum',replace(src1,N=0.),False),('positive_legacy',replace(src1,N=100000.),False),('stale_root_geometry',replace(bound,center_n=151.),False),('receiver_span_free',bind_current_evidence(replace(bound,compression_receiver_relative='absent',compression_unbraced_length=2000.,compression_flange_rotation='free')),False),('mixed_sign',replace(src1,theta_deg=45.),False),('unsupported_extra_shear',replace(src1,V=1000.),False)]
example=decode_project((SOURCE/'examples/one_root_compression0937/SRC1_project.json').read_bytes())
cases += [('source_example_compact',example,False),('source_example_detailed',example,True)]
records=[]
for tag,c,detailed in cases:
 print('CAPTURE',tag,flush=True);at=AppTest.from_file(str(SOURCE/'app.py'),default_timeout=300);at.session_state['connection_family']=FAMILY;at.session_state[PROJECT]=c.to_dict();at.run();assert not at.exception,[x.message for x in at.exception]
 assert len(at.selectbox(key='connection_family').options)==19;assert at.session_state[PROJECT]==c.to_dict();r=at.session_state[RESULT];assert r==evaluate(c)
 ready=(checks_complete(r) or r['summary'].get('diagnostic_checks')) and r['geometry']['valid'] and not r['status'].startswith(('INVALID','NUMERICAL','OUTSIDE'))
 if detailed:at.checkbox(key='wdag_report_detailed').check().run();assert not at.exception
 btn=next(x for x in at.button if x.label=='Gerar memória 2L-T soldada');assert btn.disabled!=ready
 if ready:btn.click().run();assert not at.exception and REPORT in at.session_state
 exports={}
 for x in at.get('download_button'):
  data=files[Path(x.proto.url).name.rsplit('.',1)[0]];ext='.png' if data.startswith(b'\x89PNG') else '.svg' if b'<svg' in data[:1000] else '.docx' if data.startswith(b'PK') else '.json';p=OUT/(tag+ext);p.write_bytes(data);exports[ext]={'path':str(p),'sha256':sha(data),'bytes':len(data),'label':x.label}
 assert '.json' in exports
 assert ({'.png','.svg'}<=set(exports))==bool(r.get('geometry',{}).get('valid'))
 assert decode_project((OUT/(tag+'.json')).read_bytes())==c
 assert ('.docx' in exports)==bool(ready)
 (OUT/(tag+'.results.json')).write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
 visible='\n'.join(str(x.value) for kind in ('title','caption','info','warning','error','success','markdown','text_area','code') for x in getattr(at,kind));(OUT/(tag+'_ui.txt')).write_text(visible)
 controls=[{'kind':kind,'key':getattr(x,'key',None),'label':getattr(x,'label',None),'value':getattr(x,'value',None)} for kind in ('number_input','text_input','selectbox','checkbox','radio') for x in getattr(at,kind)];(OUT/(tag+'_controls.json')).write_text(json.dumps(controls,ensure_ascii=False,indent=2,default=str))
 if ready:
  doc=Document(OUT/(tag+'.docx'));txt='\n'.join([p.text for p in doc.paragraphs]+[c.text for t in doc.tables for rr in t.rows for c in rr.cells]);(OUT/(tag+'_word.txt')).write_text(txt)
  with ZipFile(OUT/(tag+'.docx')) as z:media=[z.read(n) for n in z.namelist() if n.startswith('word/media/')]
  assert (OUT/(tag+'.png')).read_bytes() in media
  if c.N<0:
   assert 'Resultados condicionais não aprovam' in txt and 'Errata1 PDF1' in txt
   assert not any(x['mechanism'] in ('tension','net_rupture','tension_rupture') for x in r['checks'])
  if detailed:assert all(x['id'] in txt for x in r['checks'])
 if c.N<0 and r.get('cases'):
  assert len(r['geometry']['weld_lines'])==4 and sum(x['force_fraction'] for x in r['geometry']['weld_lines'])==1
  assert r['cases'][0]['N']==c.N and r['cases'][0]['N_per_angle']==c.N/2
  assert all(x['N']<=0 for x in r['cases'])
  assert not r.get('root') or r['root']['N']<0
 if tag.startswith('SRC1'):
  failure=next(x for x in r['checks'] if x['component']=='gusset' and x['mechanism']=='yielding' and x['case_id']=='actual');assert abs(failure['utilization']-1.0794666666666668)<1e-12 and failure['status']=='FAIL'
  assert r['status']=='CHECKS_FAIL_AND_UNVERIFIED' and not r['global_pass'] and not checks_complete(r)
  assert set(('compression_root_boundary','compression_brace_boundary','compression_receiver_span'))<=set(r['summary']['unverified_ids'])
 if tag in ('mixed_sign','unsupported_extra_shear'):assert r['status']=='OUTSIDE_SCOPE' and not ready and not r['global_pass']
 if tag=='conditional_numeric_pass':assert r['status']=='NOT_VERIFIED' and not r['global_pass'] and max(x['utilization'] for x in r['checks'])<1
 if tag=='qualified_numeric_pass':assert r['local_pass'] and r['summary']['complete_checks']
 if tag=='negative_minimum':assert [x['N'] for x in r['cases']]==[-20000.,-45000.]
 if tag=='zero_minimum':assert [x['N'] for x in r['cases']]==[0.,45000.]
 # Inspect canonical plotting coordinates, not only visible labels.
 fig=figure(c,{'status':'COMPLETE_CHECKS_PASS_WITHIN_SCOPE','global_pass':True});artists={a.get_gid():a for ax in fig.axes for a in ax.get_children() if a.get_gid()};assert ('actual_force_arrow' in artists)==bool(c.N and r.get('geometry',{}).get('valid'))
 if c.N and 'actual_force_arrow' in artists:
  ar=artists['actual_force_arrow'];head=ar.xy;tail=ar.xyann;direction=r['geometry']['direction'];dot=sum((head[i]-tail[i])*direction[i] for i in (0,1));assert (dot>0)==(c.N>0)
 if c.N<0 and r.get('compression',{}).get('strip'):
  strip=r['compression']['strip'];assert all(abs(x)<=c.plate_width/2+1e-8 for x in strip['root_projections'])
  for i in (0,1):assert list(artists['compression_root_projection_'+str(i)].get_ydata())==[strip['ends'][i][1],0]
 import matplotlib.pyplot as plt;plt.close(fig)
 row={'tag':tag,'status':r['status'],'complete':checks_complete(r),'diagnostic_report_ready':bool(ready),'detailed':detailed,'check_count':len(r['checks']),'input_sha256':input_fingerprint(c),'exports':exports,'pass':True};records.append(row);(OUT/'DOWNLOAD_RECEIPT.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n');print('PASS',tag,r['status'],len(r['checks']),flush=True)
after=hashes();(OUT/'RUNTIME_PROVENANCE.json').write_text(json.dumps({'before':before,'after':after,'unchanged':before==after,'not_claimed':['Browser DOM','OS file dialog','Numerical method approval','Actual physical restraints']},indent=2)+'\n');assert before==after,'Source changed during capture'
