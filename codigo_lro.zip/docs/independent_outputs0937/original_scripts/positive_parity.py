from pathlib import Path
import subprocess,sys,json,hashlib
source=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();out.mkdir(parents=True,exist_ok=True);old=source.parent.parent/'review0936/source0936'
code="""from pathlib import Path
import sys,json,hashlib
root=Path(sys.argv[1]);sys.path.insert(0,str(root));from lro.welded_double_angle_gusset_ui import decode_project
from lro.welded_double_angle_gusset import evaluate
rows=[]
for p in sorted(root.glob('examples/welded_double_angle_gusset0928_*.json')):
 c=decode_project(p.read_bytes());rows.append(dict(tag=p.stem,native=c.to_dict(),result=evaluate(c)))
print(json.dumps(rows,ensure_ascii=False))
"""
for tag,root in [('old',old),('new',source)]:
 r=subprocess.run([sys.executable,'-B','-c',code,str(root)],capture_output=True,text=True,check=True);(out/(tag+'.json')).write_text(r.stdout)
a=json.loads((out/'old.json').read_text());b=json.loads((out/'new.json').read_text());assert len(a)==len(b)==7
keys=['status','global_pass','local_pass','issues','checks','cases','geometry','root','sections','paths','materials','member_actions','summary','family','connection_type','units','fixed_assumptions','global_member_verified'];records=[]
for x,y in zip(a,b):
 assert x['tag']==y['tag'];diff=[k for k in keys if x['result'][k]!=y['result'][k]];assert not diff,(x['tag'],diff)
 assert all(y['native']['connection'][k]==v for k,v in x['native']['connection'].items())
 extra=set(y['native']['connection'])-set(x['native']['connection']);assert len(extra)==13 and all(k.startswith('compression_') for k in extra)
 assert all(y['native'][k]==x['native'][k] for k in ('schema_version','connection_type','units','fixed_assumptions'))
 records.append(dict(tag=x['tag'],pass_=True,exact_result_groups=keys,legacy_input_preserved=True,expected_added_native_fields=sorted(extra),metadata_change={'component_version':[x['result']['component_version'],y['result']['component_version']],'scope':[x['result']['scope'],y['result']['scope']],'exclusions':[x['result']['exclusions'],y['result']['exclusions']]}))
(out/'POSITIVE_PARITY.json').write_text(json.dumps({'pass':True,'records':records,'frozen_source':str(old),'candidate':str(source)},ensure_ascii=False,indent=2))
print('PASS all seven positive/zero one-root retained fixtures, all mechanical result groups exact')
