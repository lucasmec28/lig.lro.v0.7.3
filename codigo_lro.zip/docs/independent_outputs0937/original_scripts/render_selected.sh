#!/bin/bash
set -e
HERE=$(dirname "$0")
ROUND=$1
for tag in SRC1_compact SRC1_detailed negative_minimum conditional_numeric_pass qualified_numeric_pass source_example_compact source_example_detailed; do
 PATH=/opt/codex/runtimes/codex-primary-runtime/dependencies/bin/override:$PATH "$CODEX_PRIMARY_RUNTIME_PYTHON" /home/agent/.codex/skills/builtins/documents/render_docx.py "$HERE/$ROUND/captures/$tag.docx" --output_dir "$HERE/$ROUND/rendered/$tag" --emit_pdf > "$HERE/$ROUND/render_$tag.log" 2>&1
done
