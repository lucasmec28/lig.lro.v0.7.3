#!/usr/bin/env python3
"""Portable digest-only replay of the accepted strict legacy output comparisons.

No golden raw drawings, DOCX files, or result-state files are required.
Only SVG dc:date/generated defs-ID nondeterminism is normalized, by the exact
retained normalizer. Every DOCX ZIP member payload is compared; ZIP envelope
compression and timestamps are not document content and are not compared.
"""
from pathlib import Path
from zipfile import ZipFile
import argparse,datetime,hashlib,json,sys
from legacy_svg_normalization import normalize_svg

META=('adapter','length','status','global_pass','complete_checks','diagnostic_checks','report_blocked')
TAGS={(a,n) for a in ('bolted_angle_gusset','bolted_opposed_angle_gusset') for n in (950,1000)}
EXTS=('.json','.results.json','.png','.svg','.docx')
sha=lambda b:hashlib.sha256(b).hexdigest()

def compare(fresh,current,frozen):
 fresh=Path(fresh).resolve();checks=[];records=[]
 def check(name,ok,**detail):checks.append({'name':name,'pass':bool(ok),**detail})
 def index(rows,label):
  keys=[(r['adapter'],r['length']) for r in rows]
  check(label+' exactly four unique accepted states',len(keys)==4 and len(set(keys))==4 and set(keys)==TAGS)
  if len(keys)!=4 or len(set(keys))!=4 or set(keys)!=TAGS:raise ValueError(label+' must contain exactly the four accepted unique states')
  return dict(zip(keys,rows))
 try:
  expected=index(current,'current golden');historical=index(frozen,'frozen golden')
  receipt_path=fresh/'LEGACY_LONG_GROUP_UI_ACCEPTANCE.json'
  receipt=index(json.loads(receipt_path.read_text()),'fresh callback receipt')
  for key in sorted(TAGS):
   e,h,r=expected[key],historical[key],receipt[key];tag=key[0]+'_'+str(key[1]);start=len(checks)
   for k in META:check(tag+' metadata '+k,r[k]==e[k]==h[k],actual=r[k],current=e[k],frozen=h[k])
   extensions=set(e['exports'])
   check(tag+' golden export sets',extensions==set(h['exports']))
   check(tag+' fresh receipt export set',extensions==set(r['exports']))
   discovered={ext for ext in EXTS if (fresh/(tag+ext)).is_file()}
   check(tag+' actual exported file set',discovered==extensions,actual=sorted(discovered),expected=sorted(extensions))
   if not extensions<=set(EXTS):raise ValueError(tag+' has unrecognized golden export extensions')
   for ext in sorted(extensions):
    path=fresh/(tag+ext);data=path.read_bytes();digest=sha(data);m=e['exports'][ext];hm=h['exports'][ext]
    check(tag+ext+' fresh receipt describes emitted bytes',r['exports'][ext]['sha256']==digest and r['exports'][ext]['bytes']==len(data),actual_sha256=digest,actual_bytes=len(data))
    if ext in ('.json','.results.json','.png'):
     check(tag+ext+' exact accepted bytes',digest==m['sha256']==hm['sha256'] and len(data)==m['bytes']==hm['bytes'],actual_sha256=digest,current_sha256=m['sha256'],frozen_sha256=hm['sha256'],actual_bytes=len(data),expected_bytes=m['bytes'])
    elif ext=='.svg':
     normalized=normalize_svg(data)
     check(tag+ext+' narrowly normalized bytes',normalized['sha256']==e['svg_normalized_sha256']==h['svg_normalized_sha256'],actual_normalized_sha256=normalized['sha256'],expected_normalized_sha256=e['svg_normalized_sha256'],actual_raw_sha256=digest,rules=normalized['rules'])
    elif ext=='.docx':
     with ZipFile(path) as z:
      names=z.namelist();check(tag+ext+' no duplicate ZIP members',len(names)==len(set(names)))
      members={n:sha(z.read(n)) for n in names}
      check(tag+ext+' entire accepted ZIP member set',set(members)==set(e['all_docx_members']),actual=sorted(members),expected=sorted(e['all_docx_members']))
      for name in sorted(set(members)|set(e['all_docx_members'])):
       check(tag+ext+' exact member '+name,members.get(name)==e['all_docx_members'].get(name),actual_sha256=members.get(name),expected_sha256=e['all_docx_members'].get(name))
      word={n:v for n,v in members.items() if n.startswith('word/')}
      check(tag+ext+' frozen/current every Word XML/media hash',word==e['word_members']==h['word_members'],actual=word,expected=h['word_members'])
   state=(fresh/(tag+'_state.json')).read_bytes()
   check(tag+' full result state exact accepted bytes',sha(state)==e['full_result_state_sha256'],actual_sha256=sha(state),expected_sha256=e['full_result_state_sha256'],actual_bytes=len(state))
   records.append({'adapter':key[0],'length':key[1],'pass':all(c['pass'] for c in checks[start:]),'checks':checks[start:]})
 except Exception as exc:
  check('replay completed without missing/malformed input',False,error=type(exc).__name__+': '+str(exc))
 status='PASS' if checks and all(c['pass'] for c in checks) and len(records)==4 else 'FAIL'
 return {'status':status,'fresh_callback_directory':str(fresh),'compared_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'states':len(records),'total_checks':len(checks),'records':records,'failures':[c for c in checks if not c['pass']],'comparison':'Exact SHA-256 and expected byte lengths for native/results/PNG; exact SHA-256 for full result states; inherited dc:date/generated defs-ID SVG normalization only; every DOCX ZIP member name and decompressed byte digest.','not_compared':['SVG raw generated date and bijective generated defs IDs','DOCX archive envelope timestamps/compression']}

def main():
 here=Path(__file__).resolve().parent
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('fresh_callback_directory',type=Path)
 ap.add_argument('current_golden',type=Path,nargs='?',default=here/'CAPTURED_OUTPUT_HASHES.json')
 ap.add_argument('frozen_golden',type=Path,nargs='?',default=here/'LEGACY_EXPECTED_OUTPUTS.json')
 ap.add_argument('--output',type=Path,help='Optional JSON acceptance receipt; otherwise JSON is printed to stdout.')
 args=ap.parse_args()
 try:
  current=json.loads(args.current_golden.read_text());frozen=json.loads(args.frozen_golden.read_text())
  result=compare(args.fresh_callback_directory,current,frozen)
  result['golden_files']={str(p.resolve()):sha(p.read_bytes()) for p in (args.current_golden,args.frozen_golden)}
 except Exception as exc:result={'status':'FAIL','failures':[{'name':'load golden expectations','error':type(exc).__name__+': '+str(exc)}]}
 encoded=json.dumps(result,ensure_ascii=False,indent=2)+'\n'
 if args.output:args.output.write_text(encoded)
 else:print(encoded,end='')
 print(result['status']+' portable strict legacy replay',file=sys.stderr)
 return 0 if result['status']=='PASS' else 1
if __name__=='__main__':raise SystemExit(main())
