# Portable strict legacy output evidence

This compact kit contains accepted digest expectations, receipts, and replay scripts. It contains no raw drawing, DOCX, or large result-state baseline. Historical receipt paths are retained as provenance, not as replay prerequisites.

## Capture and compare

With the candidate app and its Streamlit/test dependencies available, capture the four genuine 950/1000 mm callback states:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$CANDIDATE:$TEST_DEPENDENCIES" \
MPLCONFIGDIR="$CACHE/mpl" XDG_CACHE_HOME="$CACHE/xdg" \
python -B legacy_long_group_callbacks.py "$CANDIDATE" "$FRESH_CALLBACKS"
```

Then use the standard-library-only comparator (and the adjacent inherited SVG normalizer):

```sh
python -B compare_replay.py "$FRESH_CALLBACKS" \
  CAPTURED_OUTPUT_HASHES.json LEGACY_EXPECTED_OUTPUTS.json \
  --output replay_receipt.json
```

The two golden paths are optional and default to the files beside the comparator. A failure or malformed/missing input yields exit status 1; acceptance yields exit status 0. The comparator never writes candidate or fresh output files.

## What is enforced

- Exactly four unique callback receipt states with the accepted status, report gating, check counts, and exported file sets.
- Native JSON, exported result JSON, and PNG: exact SHA-256 and byte count against both accepted-current and frozen-historical expectations.
- Full result-state captures: exact SHA-256 against the accepted-current digest, previously proven byte-identical to the frozen baseline in `LEGACY_OUTPUT_PARITY.json`.
- SVG: only the single generated `dc:date` text and bijective generated defs identifiers/references may vary. The exact inherited normalizer preserves every other byte, semantic identifier, geometry, style, and visible label. Its normalized digest must match both goldens.
- DOCX: the complete ZIP member-name set and every decompressed member byte digest must match accepted current content; every `word/` member must also match frozen expectations. ZIP envelope timestamps/compression are excluded. No XML or media content is normalized.
- Fresh export receipt digests and sizes must describe the actual emitted files.

`PORTABLE_REPLAY_SELF_TEST.json` records acceptance against the final independent callbacks. `PORTABLE_REPLAY_GUARD_TESTS.json` records 17 disposable-fixture trials: accepted baseline, native/result/PNG/full-state byte changes, all seven SVG witnesses, and five whole-DOCX tests. Refresh them with:

```sh
python -B test_replay_guards.py "$FRESH_CALLBACKS" --output guard_receipt.json
python -B validate_legacy_normalizer.py "$FRESH_CALLBACKS/bolted_angle_gusset_950.svg" normalizer_receipt.json
```

The guard test replaces only files in disposable fixture directories beneath this kit, and deletes those fixtures afterward. It never changes the fresh captures.

## Provenance and scope

`REVIEW_RESULT.json`, `FORMAL_HOLD_VERIFICATION.json`, source/runtime hashes, and the legacy UI/corner parity receipts preserve the accepted held-source review. `CAPTURED_OUTPUT_HASHES.json` seals current full states and every DOCX member; `LEGACY_EXPECTED_OUTPUTS.json` preserves the older frozen output expectations.

The 12 corner native/result-state comparison receipts are included. Their original harness and the original raw-baseline comparison harness are preserved under `audit/` solely for audit; those two historical scripts retain original-path dependencies and are not the portable replay entry point.

This kit covers strict legacy output regression only. It does not constitute a browser DOM test, whole-release approval, packaging/publication approval, or fabrication approval.
