"""Compare full positive/welded native+result states to retained accepted evidence.

Only exact component_version values are normalized, at keys of that exact name.
No numerical, geometric, status, source, reason or semantic content is ignored.
"""
from pathlib import Path
import sys,json,hashlib,traceback,subprocess
source=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();out.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(source));here=Path(__file__).resolve().parent;old=here.parent.parent/'review0935'
from lro.corner_gusset import CornerGusset as C,analyze,COMPONENT_VERSION
from lro.corner_gusset_ui import decode_project
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def hashes():return {str(p.relative_to(source)):sha(p) for pattern in ('app.py','lro/*.py','data/*.json') for p in source.glob(pattern)}
before=hashes();records=[];cases=[]
for name in ('BC1_2LT','BC1_1L_positive','BC1_1L_negative'):
 root=old/'source0935/examples/bolted_corner0934';inp=root/(name+'.json');expected=root/(name+'_results.json')
 cases.append((name,inp,expected,False))
root=old/'independent_output_acceptance/final_source_outputs'
for tag in ('CC1_compact','CC2_compact','CC3_pending_failure','negative_actual_minimum','zero_actual_minimum','tension_welded_2LT','welded_1L_compression','received_0932_welded_2LT','received_0933_welded_1L'):
 inp=root/(tag+'.json');ep=root/(tag+'.results.json')
 if tag.startswith('received_'):
  # These two native receipts were retained but no final capture file existed.
  # Recompute their old state in an isolated process using only frozen 0935.
  inp=old/'independent_output_acceptance/inputs'/(tag+'.json')
  ep=out/(tag+'_regenerated0935_expected.json')
  old_runtime=old/'source0935'
  code="import sys,json,hashlib;from pathlib import Path;root=Path(sys.argv[1]);sys.path.insert(0,str(root));from lro.corner_gusset import CornerGusset,analyze;p=Path(sys.argv[2]);c=CornerGusset.from_dict(json.loads(p.read_text()));print(json.dumps({'input':c.to_dict(),'result':analyze(c),'runtime':{str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest() for pat in ('app.py','lro/*.py','data/*.json') for f in root.glob(pat)}},ensure_ascii=False))"
  with ep.open('w') as stream:subprocess.run([sys.executable,'-B','-c',code,str(old_runtime),str(inp)],stdout=stream,check=True)
 cases.append((tag,inp,ep,True))
versions={'0.9.32-corner-gusset-dev','0.9.33-single-angle-corner-dev','0.9.34-bolted-corner-dev','0.9.35-corner-compression-dev',COMPONENT_VERSION}
def normalize(x):
 if isinstance(x,dict):return {k:('COMPONENT_VERSION' if k=='component_version' and v in versions else normalize(v)) for k,v in x.items()}
 if isinstance(x,list):return [normalize(v) for v in x]
 return x
def differences(a,b,path=''):
 if type(a)!=type(b):return [{'path':path,'old':repr(a)[:240],'new':repr(b)[:240]}]
 if isinstance(a,dict):
  d=[]
  for k in sorted(set(a)|set(b)):
   if k not in a or k not in b:d.append({'path':path+'/'+k,'old':'MISSING' if k not in a else repr(a[k])[:240],'new':'MISSING' if k not in b else repr(b[k])[:240]})
   else:d+=differences(a[k],b[k],path+'/'+k)
  return d
 if isinstance(a,list):
  if len(a)!=len(b):return [{'path':path,'old_length':len(a),'new_length':len(b)}]
  return sum((differences(v,w,path+'/'+str(i)) for i,(v,w) in enumerate(zip(a,b))),[])
 return [] if a==b else [{'path':path,'old':a,'new':b}]
for tag,inp,ep,wrapped in cases:
 print('COMPARE',tag,flush=True)
 try:
  expected=json.loads(ep.read_text());expected=expected['result'] if wrapped else expected
  c=decode_project(inp.read_bytes());actual=analyze(c)
  d=differences(normalize(expected),normalize(actual));nd=differences(normalize(json.loads(inp.read_text())),normalize(c.to_dict()))
  (out/(tag+'_actual.json')).write_text(json.dumps({'input':c.to_dict(),'result':actual},ensure_ascii=False,indent=2)+'\n')
  records.append({'tag':tag,'pass':not d and not nd,'result_differences':d,'native_differences':nd,'expected_native':str(inp),'expected_native_sha256':sha(inp),'expected_result':str(ep),'expected_result_sha256':sha(ep)})
  print('PASS' if not d and not nd else 'FAIL',tag,len(d),'result differences',len(nd),'native differences',flush=True)
 except Exception as e:
  traceback.print_exc();records.append({'tag':tag,'pass':False,'error':repr(e)})
 (out/'LEGACY_CORNER_PARITY.json').write_text(json.dumps({'normalization':'Only values at component_version keys, exact documented 0932/0933/0934/0935/0936 values','records':records},ensure_ascii=False,indent=2)+'\n')
after=hashes();assert before==after
(out/'RUNTIME_PROVENANCE.json').write_text(json.dumps({'before':before,'after':after,'runtime_unchanged':True},indent=2)+'\n')
if not all(r['pass'] for r in records):raise SystemExit(1)
