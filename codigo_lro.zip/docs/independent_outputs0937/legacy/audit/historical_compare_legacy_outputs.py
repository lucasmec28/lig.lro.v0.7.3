"""Read-only independent strict legacy comparator; no ignored semantic fields."""
from pathlib import Path
from zipfile import ZipFile
import sys,json,hashlib,datetime
here=Path(__file__).resolve().parent
sys.path.insert(0,str(here/'inherited'))
from legacy_svg_normalization import normalize_svg
source=Path(sys.argv[1]).resolve()
old=source.parent.parent/'review0936/independent_outputs0936/final_stable/legacy'
actual=here/'callbacks'
sha=lambda b:hashlib.sha256(b).hexdigest()
expected=json.loads((here/'inherited/LEGACY_EXPECTED_OUTPUTS.json').read_text())
records=json.loads((actual/'LEGACY_LONG_GROUP_UI_ACCEPTANCE.json').read_text())
assert len(expected)==len(records)==4
checks=[];comparison=[]
def check(name,ok,**details):
 checks.append({'name':name,'pass':bool(ok),**details})
for e,r in zip(expected,records):
 tag=e['adapter']+'_'+str(e['length']); row={'tag':tag,'checks':[]}
 start=len(checks)
 for k in ('adapter','length','status','global_pass','complete_checks','diagnostic_checks','report_blocked'):
  check(tag+' metadata '+k,r[k]==e[k],expected=e[k],actual=r[k])
 check(tag+' exported member set',set(e['exports'])==set(r['exports']),expected=sorted(e['exports']),actual=sorted(r['exports']))
 for ext,m in e['exports'].items():
  p=actual/(tag+ext);b=p.read_bytes();historical=(old/(tag+ext)).read_bytes()
  if ext in ('.json','.results.json','.png'):
   check(tag+ext+' strict bytes',b==historical and sha(b)==m['sha256'] and len(b)==m['bytes'],actual_sha256=sha(b),retained_sha256=sha(historical),expected_sha256=m['sha256'],actual_bytes=len(b),expected_bytes=m['bytes'])
  elif ext=='.svg':
   n=normalize_svg(b);hn=normalize_svg(historical)
   check(tag+ext+' strictly normalized SVG',n['sha256']==hn['sha256']==e['svg_normalized_sha256'],actual_raw_sha256=sha(b),retained_raw_sha256=sha(historical),actual_normalized_sha256=n['sha256'],retained_normalized_sha256=hn['sha256'],expected_normalized_sha256=e['svg_normalized_sha256'],allowed_nondeterminism=['single generated dc:date text','bijective generated [mp][0-9a-f]{10} defs IDs and exact references'])
   (here/(tag+'_SVG_NORMALIZATION.json')).write_text(json.dumps({'actual':n,'retained':hn},indent=2)+'\n')
  elif ext=='.docx':
   with ZipFile(p) as z,ZipFile(old/(tag+ext)) as hz:
    names=z.namelist();hnames=hz.namelist()
    check(tag+ext+' complete ZIP member set',len(names)==len(set(names)) and sorted(names)==sorted(hnames),actual=sorted(names),retained=sorted(hnames))
    whashes={n:sha(z.read(n)) for n in names if n.startswith('word/')}
    check(tag+ext+' expected every Word member hash',whashes==e['word_members'],actual=whashes,expected=e['word_members'])
    members=[]
    for name in names:
     b2=z.read(name);hb2=hz.read(name);same=b2==hb2
     members.append({'member':name,'pass':same,'actual_sha256':sha(b2),'retained_sha256':sha(hb2),'bytes':len(b2)})
     check(tag+ext+' strict ZIP member '+name,same,actual_sha256=sha(b2),retained_sha256=sha(hb2),bytes=len(b2))
    row['docx']={'members':members,'all_members_compared_byte_exact':True,'zip_envelope_compared':False,'reason':'Archive envelope timestamps are not document XML or media.'}
  else:raise AssertionError(ext)
 p=actual/(tag+'_state.json');hp=old/(tag+'_state.json');b=p.read_bytes();hb=hp.read_bytes()
 check(tag+' full result state strict bytes',b==hb,actual_sha256=sha(b),retained_sha256=sha(hb),actual_bytes=len(b),retained_bytes=len(hb))
 row['checks']=checks[start:];row['pass']=all(x['pass'] for x in row['checks']);comparison.append(row)
report={'status':'PASS' if all(x['pass'] for x in checks) else 'FAIL','compared_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':str(source),'retained_baseline':str(old),'legacy_states':len(records),'total_checks':len(checks),'records':comparison,'not_claimed':['Browser DOM','OS download dialog','Unchanged DOCX ZIP timestamps']}
(here/'LEGACY_OUTPUT_PARITY.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(report['status'],len(records),'genuine callback states;',len(checks),'strict comparisons')
for x in checks:
 if not x['pass']:print('FAIL',x['name'])
raise SystemExit(0 if report['status']=='PASS' else 1)
