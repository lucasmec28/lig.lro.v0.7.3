#!/usr/bin/env python3
"""Prove portable replay guards using disposable fixtures, never baseline writes."""
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile,ZIP_DEFLATED,ZipInfo
from io import BytesIO
import argparse,hashlib,json,re
from compare_replay import compare
from legacy_svg_normalization import normalize_svg
here=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('fresh',type=Path);ap.add_argument('--output',type=Path,default=here/'PORTABLE_REPLAY_GUARD_TESTS.json');args=ap.parse_args()
current=json.loads((here/'CAPTURED_OUTPUT_HASHES.json').read_text());frozen=json.loads((here/'LEGACY_EXPECTED_OUTPUTS.json').read_text());fresh=args.fresh.resolve();checks=[]
TAG='bolted_angle_gusset_950';OTAG='bolted_opposed_angle_gusset_950'

def put(q,name,data):
 p=q/name
 if p.exists() or p.is_symlink():p.unlink()
 p.write_bytes(data)

def replace_export(q,tag,ext,data):
 put(q,tag+ext,data)
 rows=json.loads((q/'LEGACY_LONG_GROUP_UI_ACCEPTANCE.json').read_text())
 row=next(r for r in rows if r['adapter']+'_'+str(r['length'])==tag)
 row['exports'][ext]['sha256']=hashlib.sha256(data).hexdigest();row['exports'][ext]['bytes']=len(data)
 put(q,'LEGACY_LONG_GROUP_UI_ACCEPTANCE.json',(json.dumps(rows,ensure_ascii=False,indent=2)+'\n').encode())

def trial(name,change,should_pass):
 with TemporaryDirectory(prefix='replay_guard_',dir=here) as tmp:
  q=Path(tmp)
  for p in fresh.iterdir():
   if p.is_file():(q/p.name).symlink_to(p)
  change(q);r=compare(q,current,frozen);actual=r['status']=='PASS';assert actual==should_pass,(name,r['failures'])
  checks.append({'name':name,'expected_pass':should_pass,'actual_pass':actual,'guard_verified':True,'failures':r['failures']})

trial('untouched accepted exports',lambda q:None,True)
for name,tag,ext in [('native JSON byte change',TAG,'.json'),('result JSON byte change',OTAG,'.results.json'),('PNG byte change',TAG,'.png')]:
 trial(name,lambda q,tag=tag,ext=ext:replace_export(q,tag,ext,(q/(tag+ext)).read_bytes()+b'\n'),False)
trial('full result state byte change',lambda q:put(q,TAG+'_state.json',(q/(TAG+'_state.json')).read_bytes()+b'\n'),False)
raw=(fresh/(TAG+'.svg')).read_text();normalized=normalize_svg(raw.encode())
renamed=raw
for i,m in enumerate(normalized['bijective_id_mapping']):
 new=m['original_id'][0]+f'{i+1:010x}';assert new not in raw;renamed=renamed.replace(m['original_id'],new)
changes=[('SVG timestamp only',re.sub(r'<dc:date>[^<]+</dc:date>','<dc:date>2000-01-01T00:00:00</dc:date>',raw),True),('SVG bijective generated defs IDs only',renamed,True),('SVG geometry changed',re.sub(r'(d="M\s+)(-?\d+(?:\.\d+)?)',lambda m:m[1]+str(float(m[2])+0.25),raw,count=1),False),('SVG style changed',re.sub(r'(stroke-width:\s*)(\d+(?:\.\d+)?)',lambda m:m[1]+str(float(m[2])+0.5),raw,count=1),False),('SVG visible semantic text changed',re.sub(r'(<text[^>]*>)([^<]+)',lambda m:m[1]+m[2]+' CHANGED',raw,count=1),False),('SVG semantic action ID changed',raw.replace('id="actual_force_arrow"','id="actual_force_arrow-changed"',1),False)]
for m in normalized['bijective_id_mapping']:
 token='url(#'+m['original_id']+')'
 if token in raw:changes.append(('SVG reference redirected',raw.replace(token,'url(#missing-clip)',1),False));break
assert len(changes)==7
for name,changed,expected in changes:
 assert changed!=raw
 trial(name,lambda q,s=changed:replace_export(q,TAG,'.svg',s.encode()),expected)

original_docx=(fresh/(TAG+'.docx')).read_bytes()
def rewrite_docx(change=None,extra=False,omit=None):
 stream=BytesIO()
 with ZipFile(BytesIO(original_docx)) as old,ZipFile(stream,'w',ZIP_DEFLATED) as new:
  for name in old.namelist():
   if name==omit:continue
   data=old.read(name)
   if name==change:data+=b'\n'
   info=ZipInfo(name,date_time=(2000,1,1,0,0,0));info.compress_type=ZIP_DEFLATED;new.writestr(info,data)
  if extra:new.writestr('extra-unapproved-member.xml',b'<extra/>')
 return stream.getvalue()
for name,data,expected in [('DOCX ZIP envelope timestamp only',rewrite_docx(),True),('DOCX document XML changed',rewrite_docx(change='word/document.xml'),False),('DOCX image media changed',rewrite_docx(change='word/media/image1.png'),False),('DOCX extra ZIP member',rewrite_docx(extra=True),False),('DOCX omitted ZIP member',rewrite_docx(omit='docProps/app.xml'),False)]:
 trial(name,lambda q,b=data:replace_export(q,TAG,'.docx',b),expected)
result={'status':'PASS','tests':len(checks),'fresh_baseline':str(fresh),'method':'Disposable symlink-based fixture directories; modified files and their fresh export receipts are replaced locally, leaving original artifacts untouched. No raw baseline artifact is retained in the portable kit.','checks':checks}
args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print('PASS',len(checks),'portable comparator guard trials')
