LRO 0.9.37 independent source output acceptance and portable replay evidence

SOURCE STATUS: GO, bound to HELD_RUNTIME_TEST_HASHES.json (288 runtime/test files),
SHA256 a6df6dab4fc40bede86a7bbc14aa36ff11dbb075135795967964497a7b16eac1.
The separate SOURCE_RUNTIME_HASHES.json has 141 app/runtime/data/requirements files.

The accepted unchanged SRC1 geometry at N=-200 kN retains physical local failure
eta=1.0794666666666668, CHECKS_FAIL_AND_UNVERIFIED, and six independent pending
conditions. Missing root, brace, receiver and interaction evidence is not invented.
Conditional strip resistance is not real-detail approval. All four physical weld
lines, signed force distribution and real-root clipped Whitmore geometry are
retained. Negative/zero actual and supplemental minimum demands remain distinct.

Source acceptance covers 14 genuine AppTest captures; six callback groups; 144
strict native-field rejects; eight actual atomic upload rejects; 16 geometry stamp
mutations; 24 placeholder-source witnesses plus four actual source edits; seven
retained positive/zero one-root states; 12 welded/bolted corner states; four legacy
long-group callback states and strict 0934 legacy SVG parity; and all 19 route IDs.
See SOURCE_OUTPUT_ACCEPTANCE.json for precise scope and exclusions.

VISUAL GATE
Seven Word documents / 69 rendered pages, including final compact/detailed source
examples with the longer project title, were checked using the canonical document
renderer. Pages were directly viewed or exact PNG-matched to documented direct
inspection. Thirteen drawing scenarios / 11 unique raster views were checked.
WORD_VISUAL_REVIEW.json, DRAWING_VISUAL_REVIEW.json and source-example receipts
bind final content to those views. All raw pages, PDFs, captures, intermediate
findings and corrections remain in the external independent_outputs0937 folder.
RETAINED_EVIDENCE_MANIFEST.json and INHERITED_EVIDENCE_MANIFEST.json retain their
hash/path provenance; raw binaries are intentionally not copied into this payload.

PRODUCTION FIXES VERIFIED
- Native structured L_e/subscript/power OMML replaced ambiguous raw Le equations.
- Compression Ct is inactive with an explicit basis, not presented as active tension.
- Automatic Le/r = 200 conservative-domain wording is explicit.
- Mixed-sign/out-of-domain drawing has a real unqualified-strip diagnostic, no None
  capacities or invented purple strip, and no toe-force/+s text collision.

PORTABILITY
Original exact reviewed scripts are under original_scripts/. Current portable
capture_outputs.py and ui_callbacks.py add only actual-wrapper bootstrap/provenance.
artifact_semantics.py uses the copied ORACLE and the same bootstrap. See
PORTABLE_ADAPTATIONS.json. Source-mode portable smoke is separately recorded.
SOURCE_EXPECTED_OUTPUTS.json retains original artifact hashes and adds whole DOCX
ZIP member digests and strictly normalized SVG hashes. No geometry, text, style or
semantic label is omitted from SVG comparison. The only allowed SVG differences
are generated dc:date text and bijectively renamed generated defs IDs/references.
DOCX replay compares every ZIP member byte, not ZIP-container timestamps.

REPLAY SOURCE
Use the same pinned Python/test dependencies as the app. Set PYTHONDONTWRITEBYTECODE=1,
MPLCONFIGDIR and XDG_CACHE_HOME to writable external locations. From this directory:
  python -B capture_outputs.py SOURCE_DIR EXTERNAL_OUTPUT/captures
  python -B compare_outputs.py EXTERNAL_OUTPUT/captures
  python -B ui_callbacks.py SOURCE_DIR EXTERNAL_OUTPUT/callbacks
  python -B artifact_semantics.py SOURCE_DIR EXTERNAL_OUTPUT/captures
  python -B replay_retained_states.py SOURCE_DIR EXTERNAL_OUTPUT/retained_states
The legacy README gives its independent strict replay and mutation guards.

PREPARED ACTUAL-APP REPLAY
  python -B replay_finalapp.py ACTUAL_EXTRACTED_APP_DIR EXTERNAL_OUTPUT
Only the outer app.py/codigo_lro.zip/requirements.txt distribution is needed; no
optional companion or historical source checkout is used. Run with only pinned
test dependencies on PYTHONPATH, not an application source directory. The actual
outer wrapper performs its own extraction. The harness observes that allocation,
checks all held runtime/test hashes in the bundle, inspects loaded module hashes,
regenerates native UI/callbacks/outputs/legacy states, compares content to viewed
source artifacts and verifies outer files unchanged. This runner was prepared
here; actual immutable APP execution is a separate later gate. It does not create
archives, install software, upload, deploy, or certify physical restraints.

AUDIT NOTES
Early exploratory logs are preserved, including a harness-only assumption that
Matplotlib would emit an Annotation gid to SVG; actual artist coordinates and
rendered arrows are independently checked instead. A temporary synthetic legacy
schema migration witness was replaced with the genuine retained old native file.
The first legacy replay was superseded while source edits were still occurring;
only final_checkpoint stable replay supports GO. Neither exploratory failure is
silently erased. The final formal hold and every final source comparison passed.
