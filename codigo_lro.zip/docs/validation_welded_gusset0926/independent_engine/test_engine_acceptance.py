"""Independent production acceptance for the bounded welded-angle route."""
import json,math,sys,copy
from pathlib import Path
from dataclasses import replace
import pytest
from independent_kernel import Geometry,calc
from free_boundary_kernel import rectangle_paths
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'review0926/source0926'))
from lro.welded_angle_gusset import WeldedAngleGusset as C,evaluate,minimum_fillet,root_actions

def near(a,b,atol=1e-7):assert math.isclose(a,b,rel_tol=2e-10,abs_tol=atol),(a,b)
def check(r,id,case='actual'):return next(x for x in r['checks'] if x['id']==case+'__'+id)
def ref(c):
 mats={'S275JR':(275.,410.),'ASTM A36':(250.,400.),'ASTM A572 Gr.42':(290.,415.),'ASTM A572 Gr.50':(345.,450.)}
 a,g,w=mats[c.angle_steel],mats[c.gusset_steel],mats[c.support_steel]
 W=json.loads((Path(__file__).parent/'frozen_support_inputs.json').read_text())[c.support_profile]
 gref=Geometry(N=c.N,B=c.plate_width,H=c.plate_height,tg=c.plate_t,theta=c.theta_deg,sx=c.center_s,ny=c.center_n,L=c.weld_length,end=c.end_margin,sh=c.angle_weld_leg,st=c.angle_weld_leg,sr=c.root_weld_leg,strip=c.introduction_width,d=W['d'],bf=W['bf'],tf=W['tf'],tw=W['tw'],k=(W['d']-W['clear'])/2,fw_a=415 if c.angle_electrode=='E60' else 485,fw_r=415 if c.root_electrode=='E60' else 485,fy_a=a[0],fu_a=a[1],fy_g=g[0],fu_g=g[1],fy_w=w[0],fu_w=w[1],end_left=c.support_end_left-c.plate_width/2,end_right=c.support_end_right-c.plate_width/2)
 e=calc(gref)
 branch=rectangle_paths(gref)
 e['paths']=e['paths'][:5]+branch['paths']
 e['inactive_paths']=branch['not_applicable']
 pts=[p for q in branch['paths'] for p in q.get('coords',[])]
 pts += [p for q in e['lines'] for p in [q['low'],q['high']]]
 e['fit']=all(-c.plate_width/2-1e-8<=x<=c.plate_width/2+1e-8 and -1e-8<=y<=c.plate_height+1e-8 for x,y in pts)
 e['topfit']=True
 return e

def verify_case(c,expect_pass=None):
 r=evaluate(c); e=ref(c)
 assert r['cases'],r['issues']
 if expect_pass is not None:assert r['local_pass']==expect_pass,(r['status'],r['issues'])
 for key in ['N','V','M']:near(r['root'][key],e['root'][key])
 for key in ['heel','toe']:near(check(r,'angle_weld_'+key)['utilization'],e[key+'_weld_ratio'])
 near(check(r,'root_weld')['utilization'],e['root_weld_ratio'])
 near(r['sections']['local']['Ct'],e['strip_Ct'])
 near(r['sections']['local']['sigma_max'],e['strip_sigma'][1])
 near(r['sections']['local']['sigma_min'],e['strip_sigma'][0])
 near(check(r,'W_web_normal')['resistance'],e['w_normal_R'])
 near(check(r,'W_web_combined')['demand'],e['w_VM'])
 near(r['member_actions']['introduced_moment_about_member_centroid'],e['member_M'])
 near(min(x['sigma_MPa'] for x in r['sections']['cuts']),e['tensile_min'])
 assert max(x['von_mises_envelope'] for x in r['sections']['intervals'])>=e['VM']-1e-7
 assert len(r['paths'])==len(e['paths'])
 for p,q in zip(r['paths'],e['paths']):
  assert p['id'].replace('-partial','')==q['id'],(p['id'],q['id'])
  for key in ['Agv','Ant','demand','resistance']:near(p[key],q[key])
  near(p['utilization'],q['ratio'])
  for xy,z in zip(p['path_xy_mm'],q.get('coords',[])):
   for a,b in zip(xy,z):near(a,b)
  for x,y in p['path_xy_mm']:
   assert -c.plate_width/2-1e-8<=x<=c.plate_width/2+1e-8 and -1e-8<=y<=c.plate_height+1e-8
 assert r['global_member_verified'] is False
 assert r['member_actions']['existing_member_actions'] is None
 for key,opposite in [('N','N_normal'),('V','V_parallel'),('M','M_root')]:
  near(r['member_actions']['applied_to_support'][opposite],e['root'][key]);near(r['member_actions']['equal_opposite_on_gusset'][opposite],-e['root'][key])
 return r

@pytest.mark.parametrize('changes',[{},dict(N=200000.),dict(theta_deg=80.),dict(theta_deg=90.),dict(center_s=20.),dict(center_n=160.),dict(plate_width=450.),dict(plate_height=350.),dict(plate_t=12.),dict(weld_length=180.),dict(weld_length=220.),dict(angle_weld_leg=6.,root_weld_leg=6.),dict(angle_steel='ASTM A36'),dict(gusset_steel='ASTM A572 Gr.50'),dict(support_steel='ASTM A36'),dict(angle_electrode='E70'),dict(root_electrode='E70'),dict(support_end_left=250.),dict(support_end_right=517.),dict(support_end_right=math.nextafter(517.,math.inf)),dict(end_margin=25.),dict(introduction_width=126.),dict(introduction_width=175.)])
def test_parameterized_numeric_oracles(changes):verify_case(replace(C(),**changes),changes.get('N',100000.)<148000)

def test_all_named_paths_cross_unit_ratio_on_same_geometry():
 base=evaluate(C())
 for p in base['paths']:
  force=100000*1.01/p['utilization'];r=evaluate(replace(C(),N=force))
  q=next(x for x in r['paths'] if x['id']==p['id']);near(q['utilization'],1.01)
  assert not r['local_pass']

def test_reference_and_magnitude():
 r=verify_case(C(),True);near(r['summary']['utilization'],.6818181818181819)
 r=verify_case(replace(C(),N=200000),False)
 for id in ['angle_block','angle_weld_heel','gusset_yield']:assert check(r,id)['status']=='FAIL'

@pytest.mark.parametrize('changes',[dict(N=-1),dict(N=-100000),dict(theta_deg=60),dict(center_s=-20),dict(theta_deg=80,center_s=100,plate_height=350),dict(center_n=143,weld_length=220),dict(weld_length=240),dict(angle_weld_leg=6.1),dict(introduction_width=125),dict(plate_width=150),dict(plate_height=200),dict(end_margin=0),dict(plate_t=6.3,root_weld_leg=5),dict(root_weld_leg=4),dict(angle_weld_leg=4),dict(support_face='web'),dict(static=False),dict(fatigue=True),dict(seismic=True),dict(V=1),dict(M=1),dict(torsion=1),dict(minimum_force=False,N=10000)])
def test_no_false_green(changes):
 r=evaluate(replace(C(),**changes));assert not r['local_pass'],r
 assert r['status']!='COMPLETE_LOCAL_CHECKS_PASS_WITHIN_SCOPE'

def test_internal_compression_is_not_inferred_from_root_only():
 r=evaluate(replace(C(),theta_deg=80,center_s=100,plate_height=350));assert r['root']
 assert min(r['root']['q_n_ends_N_per_mm'])>0
 assert min(x['sigma_MPa'] for x in r['sections']['cuts'])<-1.7
 assert any('compressed_section' in x['id'] for x in r['issues'])
 assert not r['local_pass']

def test_minimum_force_keeps_concurrent_direction_and_moment():
 for N in [0.,1.,10000.,math.nextafter(45000.,0),45000.,45001.]:
  r=evaluate(replace(C(),N=N));assert r['local_pass']
  cases={x['id']:x for x in r['cases']}
  assert ('minimum_45kN' in cases)==(N<45000)
  actual=cases['actual'];near(actual['N'],N)
  if N<45000:
   e=calc(replace(Geometry(),N=45000.))
   for key in ['N','V','M']:near(cases['minimum_45kN']['root'][key],e['root'][key])
 r=evaluate(replace(C(),N=0,recommend_half_capacity=True))
 assert 'recommended_half' in [x['id'] for x in r['cases']]
 near(next(x['N'] for x in r['cases'] if x['id']=='recommended_half'),283750.)
 assert not r['local_pass']

@pytest.mark.parametrize('threshold,below,above',[(6.3,3.,5.),(12.5,5.,6.),(19.,6.,8.)])
def test_minimum_fillet_exact_thresholds(threshold,below,above):
 assert minimum_fillet(threshold)==below
 assert minimum_fillet(math.nextafter(threshold,math.inf))==above

def test_materials_are_independent():
 base=evaluate(C());ids={x['id']:x for x in base['checks']}
 for field,affected in [('angle_steel',{'angle'}),('gusset_steel',{'gusset','gusset_root'}),('support_steel',{'support_contact','support_web','support_flange'})]:
  r=evaluate(replace(C(),**{field:'ASTM A36' if field!='gusset_steel' else 'ASTM A572 Gr.50'}))
  for x in r['checks']:
   if x['component'] not in affected:
    near(x['demand'],ids[x['id']]['demand']);near(x['resistance'],ids[x['id']]['resistance'])
  for role in ['angle','gusset','support']:
   if field!=role+'_steel' and not(field=='gusset_steel' and role=='gusset'):assert r['materials'][role]==base['materials'][role]
 for field,affected in [('angle_electrode',{'angle_weld'}),('root_electrode',{'root_weld'})]:
  r=evaluate(replace(C(),**{field:'E70'}))
  for x in r['checks']:
   near(x['demand'],ids[x['id']]['demand'])
   if x['component'] not in affected:near(x['resistance'],ids[x['id']]['resistance'])

def test_translation_along_force_line_and_member_rotation():
 for theta in [15,60,75,90,105,160]:
  p=[100.,150.];a=root_actions(100000,theta,p)
  q=[p[0]+123.4*math.cos(math.radians(theta)),p[1]+123.4*math.sin(math.radians(theta))]
  b=root_actions(100000,theta,q)
  for k in ['N','V','M']:near(a[k],b[k])
 beam=evaluate(C());column=evaluate(replace(C(),support_member='column'))
 assert beam['checks']==column['checks'];assert beam['member_actions']==column['member_actions']

@pytest.mark.parametrize('theta',[91.,95.,100.,105.,110.,115.,120.])
def test_signed_obtuse_interface_and_recomputed_corner_paths(theta):
 r=verify_case(replace(C(),theta_deg=theta),True)
 assert r['root']['V']<0
 if theta>=105:assert any(x['partial_fraction']<1 for x in r['paths'] if x['id'].startswith('G-L-left'))


def test_short_run_Ct_conservative_connected_element_allocation():
 for L in [40.,50.,57.999999999,58.,60.]:
  c=replace(C(),N=45000.,weld_length=L,introduction_width=126.)
  r=evaluate(c);assert r['cases'],r['issues']
  near(r['cases'][0]['angle_Ct'],max(.5,1-29/L))
  assert r['cases'][0]['angle_Ae']<=2270.


def test_flange_bending_exemption_and_end_exact_boundaries():
 c=replace(C(),plate_t=13.05,root_weld_leg=6.)
 r=evaluate(c);assert not r['root']['flange_bending_exempt']
 near(check(r,'W_flange_bending')['resistance'],6.25*345*13.2**2/1.1)
 for d,half in [(332.,False),(math.nextafter(332.,0),True),(math.nextafter(332.,math.inf),False)]:
  z=evaluate(replace(c,support_end_left=d));near(check(z,'W_flange_bending')['resistance'],6.25*345*13.2**2/1.1/(2 if half else 1))
 for tp,exempt in [(13.05,False),(math.nextafter(13.05,0),True),(math.nextafter(13.05,math.inf),False)]:
  z=evaluate(replace(c,plate_t=tp));assert z['root']['flange_bending_exempt']==exempt


def test_long_weld_uniform_transfer_scope_boundary():
 # Large geometry retains physical topology and tension while crossing100s.
 c=replace(C(),plate_width=600.,plate_height=700.,center_n=350.,theta_deg=90.,weld_length=500.,root_weld_leg=6.)
 r=evaluate(c);assert r['local_pass'],(r['status'],r['issues'])
 r=evaluate(replace(c,weld_length=math.nextafter(500.,math.inf)))
 assert not r['local_pass']
 assert any('long' in i['id'] or 'length' in i['id'] for i in r['issues'])


def test_all_rolled_support_catalog_entries_use_actual_dimensions():
 catalog=json.loads((Path(__file__).parent/'frozen_support_inputs.json').read_text())
 for name,profile in catalog.items():
  c=replace(C(),support_profile=name)
  r=verify_case(c)
  W=r['geometry']['support_catalog']
  for key in ['d','bf','tf','tw']:near(W[key],profile[key])
  near(W['k'],(profile['d']-profile['clear'])/2)
  assert W['r']>=0
  near(check(r,'W_web_shear')['resistance'],.6*345*profile['tw']*400/1.1)
  if c.plate_t+2*c.root_weld_leg>=.15*profile['bf']:
   near(check(r,'W_flange_bending')['resistance'],6.25*345*profile['tf']**2/1.1)


def test_flange_transverse_physical_fit():
 c=replace(C(),plate_t=158.,root_weld_leg=6.,N=45000.,theta_deg=90.)
 r=evaluate(c)
 assert not r['local_pass']
 assert any(i['id']=='flange_footprint_fit' for i in r['issues'])


def test_randomized_admissible_geometry_recomputes_every_path():
 import random
 random.seed(92619);computed=passed=0;records=[]
 for i in range(600):
  c=replace(C(),N=random.uniform(45000.,190000.),theta_deg=random.uniform(64.,122.),center_s=random.uniform(-35.,65.),center_n=random.uniform(140.,200.),plate_width=random.uniform(350.,580.),plate_height=random.uniform(300.,450.),plate_t=random.uniform(8.,16.),weld_length=random.uniform(120.,260.),end_margin=random.uniform(10.,30.),angle_weld_leg=random.choice([5.,6.]),root_weld_leg=random.choice([5.,6.,8.]),introduction_width=random.uniform(126.,200.))
  r=evaluate(c)
  if r['cases']:
   verify_case(c);computed+=1
  if r['local_pass']:
   e=ref(c);passed+=1
   assert e['fit'] and e['topfit']
   assert e['tensile_min']>=-1e-7 and min(e['strip_sigma'])>=-1e-7
   assert all(p['ratio']<=1+1e-12 for p in e['paths'])
   assert max(e['heel_weld_ratio'],e['toe_weld_ratio'],e['root_weld_ratio'],e['strip_yield_ratio'],e['strip_rupture_ratio'])<=1+1e-12
  records.append(dict(index=i,status=r['status'],computed=bool(r['cases']),N=c.N,theta=c.theta_deg,B=c.plate_width,H=c.plate_height,L=c.weld_length))
 assert computed>250 and passed>80,(computed,passed)
 (Path(__file__).parent/'randomized_results.json').write_text(json.dumps(dict(seed=92619,total=600,computed=computed,passed=passed,cases=records),indent=2))


def test_thin_gusset_longitudinal_substrate_cannot_exceed_real_thickness():
 c=replace(C(),N=45000.,theta_deg=90.,plate_width=300.,plate_t=3.,angle_weld_leg=6.,root_weld_leg=3.)
 r=evaluate(c);assert r['local_pass'],(r['status'],r['issues'])
 p=check(r,'gusset_substrate')
 near(p['resistance'],.6*250*3*200/1.1)
 near(p['utilization'],.3905)
 assert all(x['area']==600. for x in p['details']['candidates'])
 near(check(r,'angle_substrate')['resistance'],.6*275*6*200/1.1)


def test_nonpositive_adapted_strip_Ct_has_specific_scope_result():
 c=replace(C(),plate_t=80.,weld_length=40.,introduction_width=126.,root_weld_leg=6.)
 for t in [80.,math.nextafter(80.,math.inf)]:
  r=evaluate(replace(c,plate_t=t));assert r['status']=='OUTSIDE_SCOPE'
  assert any(i['id']=='local_strip_Ct' for i in r['issues'])
 r=evaluate(replace(c,plate_t=math.nextafter(80.,0)))
 assert r['status']=='COMPLETE_CHECKS_FAIL'
 assert r['sections']['local']['Ct']>0
