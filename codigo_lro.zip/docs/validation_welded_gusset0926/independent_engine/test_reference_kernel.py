"""Self-check independent reference against closed source oracles/direct equilibrium."""
import json,math,random
from pathlib import Path
from dataclasses import replace
from independent_kernel import Geometry,calc
ROOT=Path(__file__).resolve().parents[2]

def near(a,b):assert math.isclose(a,b,rel_tol=1e-10,abs_tol=1e-7),(a,b)

def test_all_source_paths_and_interfaces():
 src=json.loads((ROOT/'welded_gusset_scope/COMPLETE_GEOMETRY_ORACLE.json').read_text())
 r=calc(Geometry())
 for p,s in zip(r['paths'],src['angle_paths']+src['gusset_paths']):
  for a,b in [('Agv','Agv_mm2'),('Ant','Ant_mm2'),('demand','demand_N'),('resistance','resistance_N'),('ratio','utilization')]:near(p[a],s[b])
 for a,b in [('N','N'),('V','V'),('M','M')]:near(r['root'][a],src['root'][b])
 near(r['root_weld_ratio'],src['root']['weld_utilization'])
 near(r['heel_weld_ratio'],src['longitudinal_weld_and_base_metal']['heel']['weld_utilization'])
 near(r['strip_Ct'],src['local_gusset_introduction_screen']['Ct_extra_conservative_adaptation'])
 near(r['strip_rupture_ratio'],src['local_gusset_introduction_screen']['rupture_utilization'])
 near(r['w_normal_R'],src['W_local']['normal_web_yield_R'])
 near(r['w_VM'],src['W_local']['web_combined_conservative_VM_MPa'])
 near(r['member_M'],src['W_local']['introduced_moment_about_member_centroid_Nmm'])

def test_stationary_envelopes_bound_direct_equilibrium():
 random.seed(926)
 for i in range(120):
  g=replace(Geometry(),N=random.uniform(1e3,6e5),theta=random.uniform(65,120),sx=random.uniform(-40,80),ny=random.uniform(140,180),L=random.uniform(150,220),B=random.uniform(350,550),H=400,tg=random.uniform(7,15))
  r=calc(g);s,c=math.sin(math.radians(g.theta)),math.cos(math.radians(g.theta))
  for j in range(501):
   y=g.H*j/500;N=V=M=0.
   for v,F in [(-g.leg/2,g.N*(1-g.ec/g.leg)),(g.leg/2,g.N*g.ec/g.leg)]:
    ulo=max(-g.L/2,min(g.L/2,(y-g.ny+v*c)/s));length=g.L/2-ulo
    ucent=(ulo+g.L/2)/2;x=g.sx+c*ucent+s*v;n=g.ny+s*ucent-c*v
    f=F*length/g.L;N+=f*s;V+=f*c;M+=x*f*s-(n-y)*f*c
   A=g.tg*g.B;S=g.tg*g.B*g.B/6
   sig1=N/A+M/S;sig2=N/A-M/S;vm=math.sqrt(max(abs(sig1),abs(sig2))**2+3*(1.5*V/A)**2)
   assert min(sig1,sig2)>=r['tensile_min']-1e-7
   assert vm<=r['VM']+1e-7
   interval=next(p for p in r['intervals'] if p['lo']-1e-8<=y<=p['hi']+1e-8)
   for label,v in [('N',N),('V',V),('M',M)]:near(sum(co*y**k for k,co in enumerate(interval[label])),v)
