"""Independent review of actual free-boundary/corner completion and angle-axis semantics."""
import math,json,random
from pathlib import Path
from dataclasses import replace
import pytest
from test_engine_acceptance import C,evaluate,near,verify_case,ref,ROOT

SOURCE=json.loads((ROOT/'welded_gusset_scope/RECTANGLE_FREE_EDGE_BRANCH_ORACLES.json').read_text())
MAPPING={'negative-v-heel':'G-L-left-heel','negative-v-both':'G-L-left-both','positive-v-toe':'G-L-right-toe-partial','positive-v-both':'G-L-right-both-partial'}

def source_input(f):
 g=f['geometry']
 return replace(C(),N=g['N'],theta_deg=g['theta'],plate_width=g['B'],plate_height=g['H'],plate_t=g['t'],center_s=g['center_s'],center_n=g['center_n'],weld_length=g['L'],end_margin=g['end_margin'],root_weld_leg=g['root_weld_leg'],introduction_width=g['introduction_width'])

@pytest.mark.parametrize('f',SOURCE['fixtures'],ids=lambda f:f['name'])
def test_source_free_edge_oracles_all_stations_and_captured_forces(f):
 c=source_input(f);r=verify_case(c,True)
 paths={p['id']:p for p in r['paths']}
 inactive={p['id']:p for p in r['geometry']['inactive_path_families']}
 for sp in f['paths']:
  if sp['id'].startswith('U-'):p=paths['G-'+sp['id']]
  else:
   family=sp['id'].split('@')[0]
   p=next(p for p in paths[MAPPING[family]]['station_candidates'] if abs(p['cut_u']-sp['u_cut'])<1e-7)
  for a,b in [('Agv','Agv'),('Ant','Ant'),('demand','demand'),('resistance','R'),('utilization','utilization')]:near(p[a],sp[b])
  for xy,uv in zip(p['path_xy_mm'],sp['path_xy']):
   for a,b in zip(xy,uv):near(a,b)
 for fam in f['L_families']:
  id=MAPPING[fam['family']]
  if fam['governing'] is None:assert id in inactive
  prod=paths[id] if id in paths else inactive[id]
  for sr in fam['station_records']:
   pr=next(x for x in prod['station_records'] if abs(x['u_cut']-sr['u_cut'])<1e-7)
   near(pr['supported_root_contact_length'],sr['supported_root_contact_length'])
   near(pr['captured_force'],sr.get('demand',sr.get('captured_force')))
   if sr['supported_root_contact_length']>1e-7 and pr['captured_force']>0:assert pr['status']=='inadmissible-supported-root'
  if fam['governing'] is not None:near(prod['utilization'],fam['governing']['utilization'])
 for k in ['N','V','M']:near(r['root'][k],f['root'][k])

@pytest.mark.parametrize('f',SOURCE['fixtures'],ids=lambda f:f['name'])
def test_every_new_source_path_same_geometry_failure(f):
 c=source_input(f)
 for sp in f['paths']:
  force=c.N*1.01/sp['utilization'];r=evaluate(replace(c,N=force))
  paths={p['id']:p for p in r['paths']}
  if sp['id'].startswith('U-'):p=paths['G-'+sp['id']]
  else:
   id=MAPPING[sp['id'].split('@')[0]]
   p=next(x for x in paths[id]['station_candidates'] if abs(x['cut_u']-sp['u_cut'])<1e-7)
  near(p['utilization'],1.01);assert not r['local_pass']

@pytest.mark.parametrize('theta',[45.,135.])
def test_true_zero_moment_uses_actual_balanced_axis_and_root_centroid(theta):
 s,c=math.sin(math.radians(theta)),math.cos(math.radians(theta));ny=80.5;sx=(ny*c+21)/s
 inp=replace(C(),N=45000.,theta_deg=theta,plate_width=600.,plate_height=200.,center_s=sx,center_n=ny,weld_length=65.,root_weld_leg=6.)
 r=verify_case(inp,True)
 assert abs(r['root']['M'])<1e-7
 assert abs(r['geometry']['force_line_root_s'])<1e-10
 lines=r['geometry']['weld_lines']
 for component,idx in [('N',1),('V',0)]:near(sum(inp.N*l['force_fraction']*r['geometry']['direction'][idx] for l in lines),r['root'][component])
 moment=sum(inp.N*l['force_fraction']*(l['centroid'][0]*s-l['centroid'][1]*c) for l in lines)
 near(moment,r['root']['M'])
 near(r['root']['M'],inp.N*(sx*s-ny*c-21))
 assert inp.M==0.0
 assert r['geometry']['root_centroid']==[0.,0.]
 assert len(r['paths'])==11
 assert len(r['geometry']['inactive_path_families'])==2
 assert r['member_actions']['global_member_verified'] is False


def test_compact_45_and_135_use_actual_signed_directions():
 for theta,sx in [(45.,55.),(135.,-55.)]:
  c=replace(C(),theta_deg=theta,plate_width=500.,plate_height=210.,center_s=sx,center_n=105.,weld_length=150.,end_margin=10.,introduction_width=140.)
  r=verify_case(c,True);near(r['summary']['utilization'],.9090909090909091)
  assert r['root']['V']*(1 if theta<90 else -1)>0
  assert len(r['paths'])==13


def test_zero_root_moment_does_not_waive_compressed_internal_field():
 theta=45.;s,c=math.sin(math.radians(theta)),math.cos(math.radians(theta));ny=150.;sx=(ny*c+21)/s
 r=evaluate(replace(C(),theta_deg=theta,plate_width=600.,plate_height=300.,center_s=sx,center_n=ny,root_weld_leg=6.))
 assert abs(r['root']['M'])<1e-7
 assert r['sections']['min_normal']<-2.1
 assert r['status']=='OUTSIDE_SCOPE'
 assert any('compressed_section' in i['id'] for i in r['issues'])


def test_independent_root_halfspace_contact_for_all_randomized_branches():
 random.seed(92645);computed=passed=0;edges=set();inactive_count=0
 for i in range(600):
  c=replace(C(),N=random.uniform(45000.,130000.),theta_deg=random.uniform(25.,155.),plate_width=random.uniform(400.,800.),plate_height=random.uniform(220.,400.),plate_t=12.,center_s=random.uniform(-90.,110.),center_n=random.uniform(100.,200.),weld_length=random.uniform(65.,230.),end_margin=10.,root_weld_leg=8.,introduction_width=140.)
  r=evaluate(c)
  if not r['cases']:continue
  computed+=1;verify_case(c);e=ref(c)
  epaths={p['id']:p for p in e['paths']};einactive={p['id']:p for p in e['inactive_paths']}
  for p in [*r['paths'],*r['geometry']['inactive_path_families']]:
   if 'station_records' not in p:continue
   id=p['id'].replace('-partial','')
   q=epaths.get(id,einactive.get(id))
   assert q is not None
   for pr in p['station_records']:
    qr=next(z for z in q['station_records'] if abs(z['cut_u']-pr['u_cut'])<1e-6)
    near(pr['supported_root_contact_length'],qr['root_contact'],1e-6)
    near(pr['captured_force'],qr['demand'],1e-6)
   for z in p.get('station_candidates',[]):
    edges.add((z['forward_free_edge'],z['transverse_free_edge']))
    assert z['supported_root_contact_length']<=1e-6
  inactive_count+=len(r['geometry']['inactive_path_families'])
  passed+=r['local_pass']
 assert computed>250 and passed>50,(computed,passed)
 assert ('top','top') in edges and any('left' in p for p in edges) and any('right' in p for p in edges)
 (Path(__file__).parent/'free_branch_randomized_results.json').write_text(json.dumps(dict(total=600,computed=computed,passed=passed,inactive_family_count=inactive_count,observed_edge_pairs=sorted(edges)),indent=2))


def test_actual_side_termination_uses_normal_clearance_exactly():
 theta=45.;s,c=math.sin(math.radians(theta)),math.cos(math.radians(theta));ny=80.5;sx=(ny*c+21)/s
 end_x=sx+32.5*c+55*s;at=2*(end_x+5)
 inp=replace(C(),N=45000.,theta_deg=theta,plate_height=200.,center_s=sx,center_n=ny,weld_length=65.,root_weld_leg=6.)
 for B,fails in [(350.,True),(at,False),(math.nextafter(at,0),True),(math.nextafter(at,math.inf),False)]:
  r=evaluate(replace(inp,plate_width=B))
  assert any(i['id']=='right_termination' for i in r['issues'])==fails,(B,r['issues'])
  assert r['geometry']['forward_termination_clearances']


def test_actual_zero_branch_records_are_not_replaced_by_minimum_load():
 inp=replace(source_input(SOURCE['fixtures'][1]),N=0.)
 r=evaluate(inp);assert r['local_pass']
 cases={x['id']:x for x in r['cases']}
 actual=cases['actual']['inactive_path_families'];minimum=cases['minimum_45kN']['inactive_path_families']
 assert actual==r['geometry']['inactive_path_families']
 assert all(p['captured_force']==0 for x in actual for p in x['station_records'])
 assert any(p['captured_force']>0 for x in minimum for p in x['station_records'])
 assert all(p['demand']==0 for p in cases['actual']['paths'])
 assert any(p['demand']>0 for p in cases['minimum_45kN']['paths'])
