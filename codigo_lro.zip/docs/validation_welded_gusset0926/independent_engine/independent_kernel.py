"""Independent finite-geometry reference. No imports from production engine.

Qualified equations and topology: QUALIFIED_GEOMETRY.md, NBR supplied pages.
Units N, mm, MPa. This is a method regression oracle, not project approval.
"""
from dataclasses import dataclass,asdict,replace
import math,json
import numpy as np
from numpy.polynomial import Polynomial as P

@dataclass(frozen=True)
class Geometry:
 N:float=100000.; B:float=400.; H:float=300.; tg:float=10.
 theta:float=75.; sx:float=0.; ny:float=150.; L:float=200.; end:float=20.
 leg:float=100.; ta:float=12.; ri:float=12.; rt:float=6.; ec:float=29.; Ag:float=2270.
 sh:float=5.; st:float=5.; sr:float=5.; fw_a:float=415.; fw_r:float=415.
 fy_a:float=275.; fu_a:float=410.; fy_g:float=250.; fu_g:float=400.; fy_w:float=345.; fu_w:float=450.
 d:float=317.; bf:float=167.; tf:float=13.2; tw:float=7.6; k:float=21.2
 end_left:float=800.; end_right:float=800.; strip:float=150.

def roots(poly,lo,hi):
 return [float(r.real) for r in poly.roots() if abs(r.imag)<1e-7 and lo+1e-8<r.real<hi-1e-8]
def calc(g):
 s,c=math.sin(math.radians(g.theta)),math.cos(math.radians(g.theta))
 vs=(-g.leg/2,g.leg/2); forces=(g.N*(1-g.ec/g.leg),g.N*g.ec/g.leg)
 def xy(u,v):return [g.sx+c*u+s*v,g.ny+s*u-c*v]
 lines=[dict(v=v,F=f,low=xy(-g.L/2,v),high=xy(g.L/2,v)) for v,f in zip(vs,forces)]
 intervals=sorted({0.,g.H,*[pt[1] for line in lines for pt in [line['low'],line['high']]]})
 points=[]; polys=[]
 for lo,hi in zip(intervals,intervals[1:]):
  mid=(lo+hi)/2; npoly=P([0.]);vpoly=P([0.]);mpoly=P([0.])
  for line in lines:
   low,high=line['low'][1],line['high'][1]
   if mid<low: remain=P([1.])
   elif mid>high:remain=P([0.])
   else:remain=P([high/(s*g.L),-1/(s*g.L)])
   q=remain*line['F'];npoly+=q*s;vpoly+=q*c
   mpoly+=q*P([g.sx*s-g.ny*c+line['v'],c])
  a,b=npoly/(g.tg*g.B)+mpoly*6/(g.tg*g.B*g.B),npoly/(g.tg*g.B)-mpoly*6/(g.tg*g.B*g.B)
  tau=vpoly*1.5/(g.tg*g.B);vma=a*a+3*tau*tau;vmb=b*b+3*tau*tau
  ys={lo,hi,*roots(a.deriv(),lo,hi),*roots(b.deriv(),lo,hi),*roots(vma.deriv(),lo,hi),*roots(vmb.deriv(),lo,hi)}
  vals=[dict(y=y,N=float(npoly(y)),V=float(vpoly(y)),M=float(mpoly(y)),sig1=float(a(y)),sig2=float(b(y)),VM=math.sqrt(max(0.,vma(y),vmb(y)))) for y in sorted(ys)]
  points+=vals;polys.append(dict(lo=lo,hi=hi,N=npoly.coef.tolist(),V=vpoly.coef.tolist(),M=mpoly.coef.tolist(),points=vals))
 root=points[0];minimum=min(min(p['sig1'],p['sig2']) for p in points);vmmax=max(p['VM'] for p in points)
 qn=[root['N']/g.B+6*root['M']/g.B**2,root['N']/g.B-6*root['M']/g.B**2];qs=root['V']/g.B
 qe=[math.hypot(x,qs) for x in qn];qd=max(max(qe),1.25*sum(qe)/2)
 weldR=lambda fw: .6*fw/1.35
 paths=[]
 def path(name,av,at,demand,steel,coords=None):
  fy,fu=steel;ry=(.6*fy*av+.5*fu*at)/1.35;ru=(.6*fu*av+.5*fu*at)/1.35;r=min(ry,ru)
  v=dict(id=name,Agv=av,Ant=at,demand=demand,resistance=r,ratio=demand/r if r>0 else math.inf,yield_branch=ry,rupture_branch=ru)
  if coords is not None:v['coords']=coords
  paths.append(v)
 long=(g.L+g.end)*g.ta;ah=g.ta*g.leg+g.ri*g.ta+(g.ri*g.ri-g.rt*g.rt)*(1-math.pi/4);at=g.rt*g.ta-g.rt*g.rt*(1-math.pi/4)
 path('A-H',long,ah,forces[0],(g.fy_a,g.fu_a));path('A-T',long,at,forces[1],(g.fy_a,g.fu_a));path('A-B',long,ah,g.N,(g.fy_a,g.fu_a))
 path('A-T-limit',(g.L+g.end)*(g.ta-g.rt),0,forces[1],(g.fy_a,g.fu_a));path('A-all',g.L*(g.ta-g.rt),0,g.N,(g.fy_a,g.fu_a))
 u0=-g.L/2
 def utop(v):return (g.H-g.ny+c*v)/s
 for label,v0,v1,demand in [('G-U-both',vs[0]-g.sh,vs[1]+g.st,g.N),('G-U-heel',vs[0]-g.sh,vs[0],forces[0]),('G-U-toe',vs[1],vs[1]+g.st,forces[1])]:
  path(label,(utop(v0)+utop(v1)-2*u0)*g.tg,(v1-v0)*g.tg,demand,(g.fy_g,g.fu_g),[xy(utop(v0),v0),xy(u0,v0),xy(u0,v1),xy(utop(v1),v1)])
 def side_x(side):return side*g.B/2
 # actual lower-corner station at which the side ray first becomes available.
 for side,label,v,demand in [(-1,'G-L-left-heel',vs[0],forces[0]),(-1,'G-L-left-both',vs[1]+g.st,g.N),(1,'G-L-right-toe',vs[1],forces[1]),(1,'G-L-right-both',vs[0]-g.sh,g.N)]:
  corner=(side_x(side)-g.sx)*c-g.ny*s
  u=max(u0,corner); vb=(side_x(side)-g.sx-c*u)/s
  rem=max(0.,min(1.,(g.L/2-u)/g.L))
  path(label,(utop(v)-u)*g.tg,abs(vb-v)*g.tg,demand*rem,(g.fy_g,g.fu_g),[xy(utop(v),v),xy(u,v),xy(u,vb)])
 path('G-all',g.L*g.tg,0,g.N,(g.fy_g,g.fu_g))
 e=g.ec-g.leg/2;stripsig=(g.N/(g.strip*g.tg)-abs(g.N*e)*6/(g.tg*g.strip**2),g.N/(g.strip*g.tg)+abs(g.N*e)*6/(g.tg*g.strip**2))
 stripct=3*g.L*g.L/(3*g.L*g.L+g.strip*g.strip)*(1-g.tg/(2*g.L)) # NBR5.2.5(d) conservative effective-strip adaptation
 allcoords=[xy(u,v) for u in [-g.L/2,g.L/2] for v in [vs[0]-g.sh,vs[1]+g.st]]+[xy(-g.L/2-g.end,v) for v in vs]+[xy(-g.L/2,v) for v in [-g.strip/2,g.strip/2]]
 allcoords += [q for p in paths for q in p.get('coords',[])]
 fit=all(-g.B/2-1e-9<=x<=g.B/2+1e-9 and -1e-9<=y<=g.H+1e-9 for x,y in allcoords)
 topfit=all(-g.B/2-1e-9<=xy(utop(v),v)[0]<=g.B/2+1e-9 for v in [vs[0]-g.sh,vs[1]+g.st])
 edgeclear=min(g.H-line['high'][1] for line in lines)
 near=min(g.end_left,g.end_right)
 normalR=(g.B+(5 if near>g.d else 2.5)*g.k)*g.tw*g.fy_w
 wnormal=abs(root['N'])+6*abs(root['M'])/g.B
 wvm=math.hypot(wnormal/(g.B*g.tw),math.sqrt(3)*1.5*root['V']/(g.tw*g.B))
 return dict(input=asdict(g),root={k:root[k] for k in ['N','V','M','sig1','sig2']},lines=lines,intervals=polys,tensile_min=minimum,VM=vmmax,fit=fit,topfit=topfit,edgeclear=edgeclear,paths=paths,
   angle_Ct=max(.5,1-g.ec/g.L),angle_yield=g.Ag*g.fy_a/1.1,angle_rupture=max(.5,1-g.ec/g.L)*g.Ag*g.fu_a/1.35,
   heel_weld_ratio=forces[0]/(g.L*g.sh/math.sqrt(2)*weldR(g.fw_a)),toe_weld_ratio=forces[1]/(g.L*g.st/math.sqrt(2)*weldR(g.fw_a)),
   root_q=qn,root_qs=qs,root_qdesign=qd,root_weld_ratio=qd/(2*g.sr/math.sqrt(2)*weldR(g.fw_r)),
   strip_sigma=stripsig,strip_Ct=stripct,strip_yield_ratio=max(stripsig)/(g.fy_g/1.1),strip_rupture_ratio=max(stripsig)/(stripct*g.fu_g/1.35),
   w_normal_R=normalR,w_normal_demand=wnormal,w_shear_yield_R=.6*g.fy_w*g.tw*g.B/1.1,w_shear_rupture_R=.6*g.fu_w*g.tw*g.B/1.35,w_VM=wvm,
   flange_exempt=(g.tg+2*g.sr)<.15*g.bf,member_M=root['M']-g.d/2*root['V'])

if __name__=='__main__':
 base=Geometry();vectors={}
 for name,args in [('reference',{}),('double_load',{'N':200000.}),('negative',{'N':-100000.}),('low_load',{'N':10000.}),('theta80',{'theta':80.}),('theta90',{'theta':90.}),('theta60',{'theta':60.}),('offset_plus20',{'sx':20.}),('offset_minus20',{'sx':-20.}),('projection_center160',{'ny':160.}),('width450',{'B':450.}),('height350',{'H':350.}),('plate12',{'tg':12.}),('length180',{'L':180.}),('length220',{'L':220.}),('leg_sizes6',{'sh':6.,'st':6.,'sr':6.}),('angle_A36',{'fy_a':250.,'fu_a':400.}),('plate_Gr50',{'fy_g':345.,'fu_g':450.}),('support_A36',{'fy_w':250.,'fu_w':400.}),('topology_bad',{'theta':45.}),('profile10_flat4',{'ta':10.})]:
  vectors[name]=calc(replace(base,**args))
 print(json.dumps(vectors,indent=2,allow_nan=False))
