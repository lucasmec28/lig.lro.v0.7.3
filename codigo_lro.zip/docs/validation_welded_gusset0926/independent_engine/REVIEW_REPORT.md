# Independent engine acceptance: 0.9.26 welded 1L–gusset–W flange

Date: 2026-10-11. Scope: independent mechanics and engine review, not UI/report qualification, fabrication approval, or global member/frame verification.

## Decision

**ACCEPTED for the bounded parameterized local-connection method.** No remaining engine blocker was found in the final reviewed source.

Reviewed file: `review0926/source0926/lro/welded_angle_gusset.py`.

Reviewed SHA-256: `3d0414c4e07d93230925bc5348b0bc44d135a3025fb9257ce8b9a1e6a4865d6a`.

This is not a fixture whitelist. Actual plate width/height/thickness, angle direction and position, equal longitudinal weld length, free-end margin, local-strip width, both interface weld sizes, materials/electrodes, rolled-W catalog dimensions, and support-end distances feed the coordinates, forces, paths and checks. The catalog angle remains the actually qualified L100×100×12, with real radii, centroid, catalog area, and 6 mm toe flat. Other angle sections, unequal runs, arbitrary polygons, compression/stability, direct W-web attachment, fatigue/seismic/spatial action and global member capacity are not silently admitted.

## Independent references and equations

Read the supplied `QUALIFIED_GEOMETRY.md`, `COMPLETE_GEOMETRY_ORACLE.json`, and final addendum of `INDEPENDENT_REVIEW.md`, plus the supplied NBR page images/text for §5.2.5, §5.7.2–5.7.3, §6.1.5/6.1.8, §6.2.2.2 and §6.2.6.2. No additional literature or invented FEA requirement was introduced.

The independent kernel imports no production engine code. It derives the remaining line-load resultants in each interval, solves polynomial stationary points for both normal edges and squared combined-stress envelopes, and independently reconstructs all 13 angle/gusset rupture cases. Its self-validation includes 120 randomized geometries × 501 direct-equilibrium section stations, or 60,120 section checks, and every source-fixture area, resistance, root action and key utilization.

- Reference root: Nnormal 96.592582629 kN, Vparallel 25.881904510 kN, M −5.982285677 kNm.
- Governing angle-path envelope 0.6818181818; heel weld 0.5443870279; local gusset yielding 0.5397333333; root weld 0.3605909536.
- Block branches retain γa2 for both branches and Cts=0.5; gross/net identity does not remove rupture.
- Both actual and limiting rounded-toe paths use the actual 6 mm minimum toe thickness, not nominal 12 mm.
- Left/right paths use the real free-side corner transitions, including partial load at active-weld intersections. The supported root is not falsely treated as a free edge.
- Full horizontal normal-field extrema and local eccentric strip are checked. The production combined-stress calculation uses an explicitly conservative per-interval separate-maxima bound. Independent exact polynomial maxima confirm that this bounds the modeled combined stress.
- Root welds use two throats; gusset root does not acquire two plate thicknesses. Longitudinal receiving substrate uses the smaller physical thickness/contact footprint where appropriate.
- W normal local yielding, separate longitudinal transfer shear, conservative simultaneous web stress, flange contact and punching, and applicable local flange bending are explicit. Interface signs and transport to the member centroid remain intact. Existing global member actions remain unspecified, never assumed zero.

## Acceptance coverage

Final independent execution: **85 test groups passed** (`engine_final.log`). It covers:

1. Fixture equality and all 13 named paths independently driven to utilization 1.01 by concurrent whole-load scaling. The 200 kN fixture produces explicit angle-path, heel-weld and gusset-yield failures.
2. Non-fixture geometries: changed θ, offsets, plate dimensions/thickness, equal weld length, end margin, weld legs, local-strip width and independent strengths.
3. Signed obtuse directions 91–120 degrees. All forces, moments and side/corner transitions are recomputed. A 105-degree example has Vparallel −25.881905 kN and M +1.782285677 kNm.
4. A physically contained case with both root edges tensile but an internal compressed section: θ80°, s0=100 mm, H350 mm. Root stresses are +43.907775/+5.332613 MPa; internal minimum is −1.714582 MPa. It is correctly outside scope.
5. Actual physical failure cases: root-fillet collision, weld exceeding toe flat, strip not wholly tensile, invalid plate containment, flange footprint exceeding actual flange width, support-end bounds and unqualified direction/load domains.
6. NBR minimum 45 kN preserves force direction and all geometric concurrent root N/V/M. Actual zero load is retained as a separate case. Optional 50% recommendation is separate; it is not silently treated as a mandatory blanket rule.
7. Exact and one-ULP boundaries for minimum weld table thresholds, W end proximity, strict flange-bending exemption, half flange resistance near an end, and local-strip Ct positivity. Angle Ct uses the method review's conservative equal-leg connected-area allocation, Ct=max(1−29/L,0.5), including short-run cases.
8. Long-weld uniform-transfer scope boundary L/s=100; beyond it full unreduced length cannot receive a green result.
9. Independent angle/gusset/support steel and independent electrode effects. Altering one does not silently change other resistance records. Beam/column rigid orientation preserves local results; moving a point along the same force line preserves root moment.
10. All 100 eligible rolled-W records, compared to independently frozen inputs from the existing 0.9.25 catalog and the explicit Arcelor fixture. k is derived from the catalog's straight clear web height, rather than transplanting one producer's radius. This checks arithmetic using those identified inputs; it is not an independent re-certification of every supplied catalog dimension.
11. **Initial 600 randomized geometries:** 498 admitted to actual calculation and compared to the separate kernel, including every primitive path; 179 complete local passes. Every green case satisfies the independent containment, tensile-field and strength bounds.
12. A 3 mm gusset with a 6 mm longitudinal weld verifies that substrate capacity is clipped to the real 3 mm plate thickness. It cannot receive six millimetres of plate shear area.

## Review changes resolved through implementation owner

The final source includes the conservative actual-length W web combined-stress screen (65.160931947 MPa in the fixture), conservative half-area short-weld Ct floor, mirrored side-corner transitions, strict source end-distance comparison, long-weld scope limit, physical root/flange interference checks, thin-plate substrate clipping, and a specific nonpositive local-strip Ct scope result. All changes were made by the implementation owner and independently rerun.

## Legacy parity

**527 preset and signed/magnitude load-perturbation vectors across all 14 pre-existing UI families remain byte-identical**, comparing complete serialized results while excluding only component/version/digest metadata. The 13 modules contain both end-plate families. This includes status, issues, checks, geometry, material-dependent numbers, demands, capacities, ratios, and pass/fail state, not merely a preset smoke test.

All original 0.9.25 `lro/*.py` hashes remain unchanged. Evidence: `legacy_parity_report.json`, `baseline_legacy.json`, `candidate_legacy.json`, `baseline_lro.sha256`, `baseline_integrity.log`.

## Reproduction

From the workspace root:

`PYTHONPATH=/tmp/lro0925-test-deps python -m pytest -q review0926/independent_engine_acceptance/test_reference_kernel.py review0926/independent_engine_acceptance/test_engine_acceptance.py review0926/independent_engine_acceptance/test_free_branch_acceptance.py`

`python review0926/independent_engine_acceptance/collect_legacy.py review0925/source0925 > baseline.json`

`python review0926/independent_engine_acceptance/collect_legacy.py review0926/source0926 > candidate.json`

`cmp baseline.json candidate.json`

Independent mechanics evidence is contained in `independent_kernel.py`, `independent_vectors.json`, `randomized_results.json`, `frozen_support_inputs.json` and the three independent test files. No production engine edit or publication was performed by this reviewer.


## Finite free-boundary completion and angle-axis follow-up

This final hash also incorporates the independently source-reviewed finite rectangular free-edge completion in `welded_gusset_scope/RECTANGLE_FREE_EDGE_BRANCH_ORACLES.json`. It supersedes the initial top-only longitudinal/rear-side topology restriction. It does **not** change the plate section stress model, waive compression, or generalize to arbitrary polygons.

- Each forward shear ray stops at its first actual top/left/right free edge. Rear transverse paths may end at the top or a side.
- All in-range rectangle-corner stations and weld endpoints are enumerated. An independent root-segment halfspace clipping calculation verifies every reported supported-root contact length. A block retaining root contact is not a detached failure path.
- A path family with no admissible positive-force detached block is explicitly inactive; it is not fabricated as a full-force path or made into a whole-geometry rejection. Further ordinary partial paths retain the conservative G-all lower envelope.
- Weld-end detailing follows the actual forward exit: the normal edge clearance is at least one weld leg, checking both active edges at a corner tie. Exact/one-ULP side-clearance witnesses are covered. The old top-only termination check was not allowed to stand in for this new branch.
- Additional randomized review covers 600 geometries spanning 25–155 degrees: 466 computed and independently compared, 113 complete passes, 354 explicitly inactive L-family records. All nine combinations of forward/transverse free-edge types (left/top/right) were exercised. Combined randomized coverage is **1,200 geometries, 964 computed, 292 complete local passes**.
- Every source branch station and its area, demand, resistance, force fraction and root-contact length agrees with the independent ray kernel. All 19 named source branch/station examples also reach utilization 1.01 under concurrent same-geometry load scaling.
- Actual zero-load inactive-path witnesses remain separate from the supplemental 45 kN case. Neither case overwrites the other.

### Verified 45-degree and 135-degree examples

1. **45 degrees, 100 kN:** plate 500×210×10 mm; weld-group center (55,105) mm; two equal 150×5 mm longitudinal welds; 10 mm free-end margin; 5 mm root fillets; local introduction strip 140 mm. Other angle/W/material choices remain the reference choices. All local checks pass; governing conservative angle-path ratio 0.9090909091. Root N=V=70.710678119 kN; M=−5.635533906 kNm. The plate field is wholly tensile within roundoff. The 135-degree counterpart with center (−55,105) also passes with the same governing ratio and correctly reversed parallel-force direction. This is a computed illustrative configuration, not a universal sizing recommendation.
2. **45 degrees, 45 kN, true zero root moment:** plate 600×200×10 mm; group center (110.19848480983501,80.5) mm; equal 65×5 mm welds; 20 mm free-end margin; 6 mm root fillets; local strip 150 mm. The 135-degree counterpart uses center (−50.801515190165,80.5). Both pass all local checks; angle-path ratio 0.9440559441. Nnormal=31.819805153 kN; Vparallel=±31.819805153 kN; Mroot is zero within 1e−7 N mm. Both modeled plate fields remain tensile. Two L families are genuinely inactive, leaving eleven admissible primitive family entries.
3. A separate 45-degree zero-root-moment geometry with the original 200 mm weld length has a compressed internal modeled section. It remains outside scope. Zero root moment is never used as a substitute for checking the whole introduction field.

### Axial-only bar versus derived root moment

The bar input remains axial N with externally applied bar moment zero. The actual balanced heel/toe force line is 21 mm from the weld-group center in local v. About the actual centroid of the full root weld group, the derived moment is

`Mroot = N (center_s sinθ − center_n cosθ − 21 mm)`.

The independent sum of the two distributed weld resultants reproduces this moment. Setting `center_s=(center_n cosθ+21)/sinθ` gives zero root moment, as verified above. No arbitrary plate-centroid moment, duplicated eccentricity, or imposed bar bending moment was found. The nonzero local-strip moment is about that strip's own center and is a separate section reference, not a second applied load.

Additional evidence: `free_boundary_kernel.py`, `free_boundary_vectors.json`, `test_free_branch_acceptance.py`, `free_branch_randomized_results.json`, `axis_moment_witnesses.json`, and `zero_moment_45_lower_load.json`. The last two preserve diagnostic snapshots from before branch completion; the executable final tests and this final report supersede their historical scope statuses.
