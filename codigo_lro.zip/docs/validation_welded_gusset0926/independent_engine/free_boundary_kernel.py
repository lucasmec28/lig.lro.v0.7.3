"""Independent exact ray/rectangle rupture paths for the finite free-edge completion.

Reuses only independent angle paths/material arithmetic; no production imports.
"""
from independent_kernel import Geometry,calc
from dataclasses import replace
import math,json


def rectangle_paths(g):
 s,c=math.sin(math.radians(g.theta)),math.cos(math.radians(g.theta));rear=-g.L/2;front=g.L/2
 lo,hi=-g.leg/2-g.sh,g.leg/2+g.st
 def xy(u,v):return (g.sx+c*u+s*v,g.ny+s*u-c*v)
 def ray(u,v,du,dv):
  x,y=xy(u,v);dx=c*du+s*dv;dy=s*du-c*dv
  hits=[]
  if dx>1e-14:hits.append(((g.B/2-x)/dx,'right'))
  elif dx< -1e-14:hits.append(((-g.B/2-x)/dx,'left'))
  if dy>1e-14:hits.append(((g.H-y)/dy,'top'))
  elif dy< -1e-14:hits.append((-y/dy,'root'))
  hits=[(max(0.,a),b) for a,b in hits if a>=-1e-8]
  t=min(a for a,b in hits);edges=[b for a,b in hits if abs(a-t)<=1e-8]
  # A side/root corner has an actual free-side endpoint; label free side.
  edge=next((e for e in edges if e!='root'),'root')
  return dict(u=u+du*t,v=v+dv*t,point=xy(u+du*t,v+dv*t),edge=edge,all_edges=edges,distance=t)
 def path(id,av,at,f,coords,**details):
  y=(.6*g.fy_g*av+.5*g.fu_g*at)/1.35;r=(.6*g.fu_g*av+.5*g.fu_g*at)/1.35;cap=min(y,r)
  return dict(id=id,Agv=av,Ant=at,demand=f,resistance=cap,ratio=f/cap,coords=coords,**details)
 def root_contact(u,v,side):
  low,high=-g.B/2,g.B/2
  # Clip root segment by two independent linear halfspaces a*x+b>=0.
  constraints=[(c,-g.sx*c-g.ny*s-u)]
  constraints.append((-s,v+g.sx*s-g.ny*c) if side<0 else (s,-g.sx*s+g.ny*c-v))
  for a,b in constraints:
   if abs(a)<1e-14:
    if b<0:return 0.
   elif a>0:low=max(low,-b/a)
   else:high=min(high,-b/a)
  return max(0.,high-low)
 out=[];omitted=[]
 for id,va,vb,F in [('G-U-both',lo,hi,g.N),('G-U-heel',lo,-g.leg/2,g.N*(1-g.ec/g.leg)),('G-U-toe',g.leg/2,hi,g.N*g.ec/g.leg)]:
  a,b=ray(rear,va,1,0),ray(rear,vb,1,0)
  assert a['edge']!='root' and b['edge']!='root'
  out.append(path(id,(a['distance']+b['distance'])*g.tg,(vb-va)*g.tg,F,[a['point'],xy(rear,va),xy(rear,vb),b['point']],free_edges=[a['edge'],b['edge']]))
 for id,v,dv,F in [('G-L-left-heel',-g.leg/2,-1,g.N*(1-g.ec/g.leg)),('G-L-left-both',hi,-1,g.N),('G-L-right-toe',g.leg/2,1,g.N*g.ec/g.leg),('G-L-right-both',lo,1,g.N)]:
  stations=sorted({rear,front,*[(x-g.sx)*c+(y-g.ny)*s for x in [-g.B/2,g.B/2] for y in [0.,g.H] if rear<(x-g.sx)*c+(y-g.ny)*s<front]})
  candidates=[];records=[]
  for u in stations:
   side=ray(u,v,0,dv)
   contact=root_contact(u,v,dv)
   rem=(front-u)/g.L
   records.append(dict(cut_u=u,root_contact=contact,demand=F*max(rem,0),edge=side['edge']))
   if side['edge']=='root' or contact>1e-8 or rem<=0:continue
   exit=ray(u,v,1,0)
   rem=(front-u)/g.L
   candidates.append(path(id,exit['distance']*g.tg,side['distance']*g.tg,F*rem,[exit['point'],xy(u,v),side['point']],free_edges=[exit['edge'],side['edge']],partial_fraction=rem,cut_u=u))
  if candidates:
   governing=max(candidates,key=lambda p:p['ratio']);out.append(dict(governing,station_candidates=candidates,station_records=records))
  else:
   omitted.append(dict(id=id,station_records=records,reason='No actual free transverse boundary captures positive force; supported root is not a free boundary'))
 out.append(path('G-all',g.L*g.tg,0.,g.N,[],conservative=True))
 return dict(paths=out,not_applicable=omitted)

if __name__=='__main__':
 n=80.5;theta=45.;s=math.sin(math.radians(theta));c=math.cos(math.radians(theta))
 variants={
  'compact45_100kN':replace(Geometry(),theta=45,B=500,H=210,sx=55,ny=105,L=150,end=10,strip=140),
  'compact135_100kN':replace(Geometry(),theta=135,B=500,H=210,sx=-55,ny=105,L=150,end=10,strip=140),
  'zero45_45kN':replace(Geometry(),N=45000,theta=theta,B=600,H=200,sx=(n*c+21)/s,ny=n,L=65,sr=6),
  'reference':Geometry(),
 }
 print(json.dumps({k:dict(input=vars(g),**rectangle_paths(g)) for k,g in variants.items()},indent=2))
