"""Run in a clean Python process, passing source root. Independent 14-family parity."""
import sys, importlib, dataclasses, json, math
sys.path.insert(0,sys.argv[1])
MODULES=['examples','double_cover','end_plate','base_plate','pinned_base_plate','w_splice','w_splice_conventional','double_angle','welded_double_angle','coped_double_angle','axial_double_angle','axial_single_angle','welded_w_splice']
def data(x):
 if dataclasses.is_dataclass(x): return data(dataclasses.asdict(x))
 if isinstance(x,dict):return {str(k):data(v) for k,v in x.items() if k not in {'component_version','version','input_digest'}}
 if isinstance(x,(list,tuple)): return [data(i) for i in x]
 if isinstance(x,float) and not math.isfinite(x):return str(x)
 return x
out=[]
for mod in MODULES:
 m=importlib.import_module('lro.'+mod)
 ev=importlib.import_module('lro.engine').evaluate if mod=='examples' else m.evaluate
 for name,base in m.presets().items():
  cases=[('preset',base)]
  for fld in ['N','V','M']:
   if fld in {f.name for f in dataclasses.fields(base) if f.init}:
    val=getattr(base,fld)
    for scale in [-1.,0.,2.]:cases.append((fld+'*'+str(scale),dataclasses.replace(base,**{fld:val*scale})))
  for label,c in cases:
   r=ev(c)
   result=data(r)
   if not isinstance(r,dict) and hasattr(r,'status'): result['status']=r.status
   out.append(dict(module=mod,name=name,case=label,result=result))
print(json.dumps(out,ensure_ascii=False,indent=2,allow_nan=False))
