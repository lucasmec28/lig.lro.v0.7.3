# Detailed Word pixel review receipt

Result: PASS for the requested rendered-output acceptance checks. No blocking visual defect found.

- Source: `positive_detailed.docx`
- Source SHA-256: `7ef3c807e70ff991801bb5ff3da5ad9871429d55dee09c5b0109d20a8539b0d3`
- Rendered PDF SHA-256: `9f8f203191889971e4c55a724b3f221810e21b4d85d8763d7e1fd1dfd62b306c`
- Render: `render_positive_detailed/`; renderer exit 0; 17 pages; no page-boundary violations reported by `render_summary.json`.
- Visually inspected with `view_image`, at original image resolution: pages 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, and 17. Text/XML checks were supplementary, not a substitute for page inspection.

## Checks

- Pages 1–2: scoped positive status and all 16 consolidated physical checks render legibly. “Atende localmente no domínio” and the explicit exclusion of whole-system/fabrication approval are visible.
- Page 3: current-input drawing is unclipped. Plan, physical angle section, two root fillets, longitudinal W support, dimensions, 71/29 percent distribution, 100 kN load, and model caveats are readable without text/geometry collisions.
- Pages 1, 3–6: project `Independent positive detailed100kN`, input identity `5558672d432fa09e34d555d20ff16fc2f5b7ff3f8e02076f6ea0d8b247143527`, L100x100x12 / W310x165x52, 400x300x10 plate, 75 degrees, 200 mm welds, 5 mm legs, and independent material selections are consistent across the visible report and captured JSON.
- Pages 7–11: equations, physical limitations, all 13 active path families, admissible station tables, supported-root exclusions, zero-demand stations, section extrema, and local-strip witnesses are visible. The text explains geometry-dependent active/inactive families and distinguishes conservative bounds from exact fracture paths. Pages 9–10 visibly label inadmissible supported-root and no-positive-demand stations.
- Pages 12–16: consolidated checks and witness tables remain legible across page breaks. No visually missing, cropped, or overlapping rows found.
- Regression check, page 13: BOTH heel and toe witness tables visibly contain `details.length = 200`, `details.leg = 5`, and `details.force_fraction = 0.71` / `0.29`. The earlier toe-row disappearance is absent in this render.
- Pages 16–17: references, limitations, and conclusion remain within the page. The conclusion explicitly excludes global W resistance, system stability, assembly, and fabrication release.

## Issues and limitations

- No blocking clipping, overlap, unreadable glyphs, broken table continuation, or current-input identity mismatch observed.
- Minor presentation observation: page 16 has a header-only “Testemunho / Valor” table under the combined W-web check. The DOCX source itself contains only that header row; this is not a dropped-row rendering defect. Optional polish would omit a witness table when it has no data.
- This is a rendered-document acceptance review, not independent structural-design certification or an audit of every engineering equation.
