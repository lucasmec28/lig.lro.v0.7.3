# Independent UI, native-project and rendered-artifact acceptance — 0.9.26

**PASS.** Final source acceptance completed on 2026-10-11. The exact packaged outer-loader smoke remains a separate final packaging gate.

## Accepted source

- Engine: `3d0414c4e07d93230925bc5348b0bc44d135a3025fb9257ce8b9a1e6a4865d6a`
- UI: `8c28461868d121ca25cd67add47e892241f96cadd63e8d133e64728b0a5807d8`
- Drawing: `3586187b586eef073c921259e820f59171e20e7da2e54a6d6af1b2c302e65770`
- Word report: `8c63768e1cf138926dc753699963b8f159be8265d5a6c0111c4679c81951f140`

App/lro/data hashes remained unchanged during the fresh final native run and subsequent review. Earlier intermediate captures remain preserved separately; `release_final`, `angle_axis`, `compact_angle`, `compact_angle135` and `released_example` contain current evidence.

## Native acceptance

Fresh Streamlit AppTest passed all 18 checkpoints. Actual native download bytes were captured through the media storage layer, without replacing parsers, evaluators or UI functions.

- All 15 guide/direct family routes are unique. The previous fourteen identities remain unchanged. Guide filtering and clearing preserve project, result and generated Word/JSON. Legacy Single plate, 8ES and bolted1L checkpoints passed.
- Exact JSON round-trip preserves every connection leaf, high-precision force, notes, independent angle/gusset/W grades, and both weld consumables. Beam/column labels share the same physical checks and actions. Alternate W150 dimensions and identity propagate correctly.
- Malformed JSON, duplicate keys, nonfinite/wrong-type/null values, missing required geometry/material/force fields, changed fixed assumptions and forged verification results reject atomically. The current project/result/report remains intact.
- Changing current inputs or report detail invalidates stale Word. Invalid drafts survive route switches. Finite 200 kN resistance failure remains explicit. Direct drawing/report exports disregard supplied stale approval.
- Direct W-web support, compression, fatigue and external V/M/T do not appear approved or offer an approved Word. Actual zero load remains separate from the 45 kN supplementary case.

## Angle and moment clarification

The theta input explicitly references the receiving W longitudinal +s axis. Actual 80°,90°,105° native cases change geometry and signed root actions; beam and column results agree. Fractional80.123456789° round-trips exactly. Invalid/outside angles do not silently reset or inherit approval.

The independently qualified compact 600×200×10, 45 kN centered-force fixtures pass native import/export and Word generation at45° and135°, each with beam/column presentation. Their axial lines pass through the root-weld centroid G, e_s≈0 and Mroot≈0; parallel root shear reverses sign. This is a qualified finite example, not a promise that arbitrary angles or geometries pass. No oversized850mm fixture was used as practical validation.

## Drawing and Word pixels

Actual PNG downloads, independently rendered SVG downloads, and Word-embedded images were reviewed. Word embeds the exact current native PNG bytes. The diagram preserves one free angle leg, real6mm toe face, heel/toe fillets and71/29 transfer,400mm reference plate/root geometry,20mm free end, actual support section and end clearances. Directed theta, +s, G, physical force-line extension and signed e_s are readable. Axial N is distinct from the locally derived root moment; no global-member or fabrication approval is implied.

Final compact positive/mixed/failing documents are8 pages each; final detailed is17 pages. Centered45°/135° beam/column documents and the105° column document are8 pages each. The exact released long-project-name compact example is8 pages and wraps cleanly. Every page was covered by direct visual inspection or verified pixel identity to an already inspected page; detailed17-page review has its own receipt. All table labels and unique cells longer than4 normalized characters survive PDF rendering, with no page-boundary text violations. The detailed toe length200/leg5/fraction0.29 rows, which previously disappeared in rendering, are now present.

Nonblocking polish: detailed page16 contains an empty witness-table header matching an empty source table. No technical row is missing. No further source edit is required for this release.

## Scope and evidence

This is software/native-export acceptance, not structural design certification, a browser-layout test, a global-member check or fabrication release. Mechanics/source qualification was reviewed independently by the engine reviewer. Reports retain those limits.

Package the concise `REVIEW_REPORT.md`, `FINAL_ACCEPTANCE.json` and `release_final/detailed_pixel_receipt.md`. Full logs, native artifacts, DOCX/PDF/pages and earlier defect evidence remain in this review directory. The outer-loader receipt will be appended after the exact package is supplied.
