# Full-height pinned end plate: bounded SCI option

## Outcome
A separate selectable SCI/Eurocode UK shear-only routine is implemented within the existing pinned end-plate family. It does not close the generic NBR N/V option and does not convert ASTM materials to EN grades. No release, deployment, PC access or integration-source change occurred.

## Files to integrate after review
- `src/lro/end_plate_sci.py`: strict input/domain, calculation and JSON schema.
- `src/lro/end_plate_sci_ui.py`: separate inputs, own frontal/lateral drawing, CSV, editable Word, project save/load and stale-report invalidation.
- `src/lro/end_plate_ui.py`: six-line method selector at start of `render('pinned')`; existing NBR branch preserved.
- `src/tests/test_end_plate_sci_closure.py`: focused regression tests.

The release module manifest must include the two new modules. Do not copy this entire source directory over a newer version. No dependencies beyond existing Streamlit, matplotlib and python-docx are introduced.

## Reference and reproducible oracle
Official primary source: https://www.steelconstruction.info/images/a/a9/SCI_P358.pdf
SCI/BCSA P358 (2014), §4.7 printed pp83–95, example1 §4.8 pp97–101, Appendix C.2 weld hierarchy. Source PDF and relevant figures inspected. No proprietary figure, table or source text is reproduced in the app.

Example: 406×178×74 UKB, 305×305×137 UKC, S275, 150×412.8×10 plate, 8 M20 grade8.8 bolts, pitch70, gauge90, first row90 from top, weld leg6, V400kN. Numerical results (not rounded during calculation):
- Beam effective shear area4184.4mm²; shear resistance664.362728kN.
- Bolt resistance94.08kN per bolt; reduced group resistance602.112kN.
- Support web resistance749.536327kN per shear plane; demand200kN per plane.
- Net-section support resistance792.904517kN per plane.
- Weld required throat3.80mm versus available4.242641mm.
Book area is rounded4184; that explains the tiny beam-capacity difference. Support is the COLUMN WEB (13.8mm), not flange. The 21.7mm flange controls the support grade thickness band, giving fy265MPa.

## Consistent method
Native UK Eurocode factors: γM0=1; section net-fractureγM2=1.1; joint/boltγM2=1.25. No NBR resistance factor enters.
Four grouped strength results cover weld hierarchy, beam shear, bolts/plate/support bearing and supporting web local shear. Source Check9 is not applicable to full-depth plate. The 0.8 factor is applied only to bolt shear as prescribed to accommodate rotation-induced tension. Accidental tying is separate and excluded; no simultaneous generic N/V claim.

## Delimited applicability
- One rolled I beam, unnotched, to column WEB, continuous column, vertical positive design shear only; N=M=0.
- Real specified S275/S355 beam and support, S275 plate10 or12mm, two M20 grade8.8 bolts per row, standard22mm holes, gauge90–140mm, 2–10 rows.
- Full-height plate, continuous web/flange welds, fit/spacing/tool envelope and shear-slenderness gates.
- Profile geometry and area consistency, finite inputs, unknown schema/options, beam-to-column flange interference checked. Invalid domain produces no strength approval.
- Generic ASTM A36/A572/A325 use is NOT supported by this variant. Gerdau geometries can be selected, but that alone does not certify EN material. UI and Word explicitly explain this and require material confirmation; default is pending.
- No global member stability added. No generic N/V extension, column-flange support or accidental tying approval.

## Imports and scope preservation
JSON uses its own schema and its own visible uploader in the SCI option. Global app autodetection is not extended; users must choose this option to load its project. Invalid files preserve current inputs. Imported beam/support geometries remain distinct even with identical labels. First-row position is explicit and need not be centered. Switching SCI/NBR preserves the existing NBR draft. Word export is invalidated after edits.

## QA
Independent reviewer confirmed source/model and all identified blockers resolved, including beam interference, stale area, malformed data and role-catalog collision. The focused test suite and legacy regression results are recorded separately. Editable Word rendered to two pages and both visually inspected: readable tables and own frontal/lateral view, no clipping or overlap. Software tests are not approval of a real fabricated connection.

## Practical status for Lucas
This is an executable, reference-backed additional method for the exact EN-material domain. It is NOT a shortcut to approve typical Gerdau ASTM stock in the generic NBR option. Closing that NBR full-height N/V domain still needs a consistent NBR rotation/detailing/local-support model; neither renaming steel nor transferring a Eurocode0.8 factor is defensible.

Final run: 164 tests passed in27.44s:40 new focused tests plus124 existing end-plate/app regression tests. Actual uploader and family-switch tests passed. Independent reviewer independently reran38 tests before the final2 integration tests. Final documentation-only assumption explicitly identifies protected interior conditions for adopted spacing limits.
