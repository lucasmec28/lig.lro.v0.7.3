# Canto com diagonal parafusada 1L ou 2L T

## Alcance

A versão0.9.34 acrescenta dois adaptadores à mesma família de canto no eixo forte, sem criar uma20ª rota: uma L em uma face com parafusos em corte simples, ou duas L idênticas em T com parafusos passantes comuns em corte duplo. Existe uma única linha, uma chapa de nó e duas raízes soldadas. O total N é aplicado uma vez antes de dividir entre cantoneiras e planos de corte. Cada furo da chapa recebe N/n.

O método independente está congelado em `qualification_bolted_corner0934/BOLTED_CORNER_CONTRACT.md`; os esclarecimentos posteriores de vértice e mínimo45kN estão em `METHOD_REVIEW_CLARIFICATIONS.md` no mesmo diretório. O oráculo independente é dado de teste, nunca importado pelo motor. Nenhum número do BC1 é usado como constante resistente do aplicativo.

## Geometria e estados limites

A geometria é o polígono de canto real recortado. Centros dos furos, saídas de raios, comprimentos e centroides das raízes, seções normais, apoios retidos e extremos dos caminhos são recalculados para as dimensões atuais. Os parâmetros não ficam presos ao exemplo300×300mm ou à inclinação45graus.

São verificados separadamente área bruta e líquida efetiva da L, cada plano físico do parafuso, contato/rasgamento em cada parede real, blocos parciais da L para pontas livres, Whitmore real, blocos L e U tangente da chapa compartilhada, ambas as raízes, ligação direta, continuidade, receptores e painel concorrentes. Mínimos interiores dos furos e as transições de borda/apoio fazem parte dos candidatos. Não se somam capacidades de caminhos alternativos.

Um contato apoiado retido com comprimento positivo desativa o candidato destacado. Um vértice compartilhado com borda livre genuína, sem comprimento apoiado retido, é o limite do lado livre; esse critério não depende da ordem de iteração das arestas nem do arredondamento da coordenada. As duas flags lógicas negativas de vértice do oráculo original são substituídas pelo esclarecimento independente, sem alterar as resistências congeladas ou o governante BC1.

O furo físico segue a tabela de diâmetros-padrão. A dedução líquida é dh nos furos da política broqueada qualificada, ou dh+2mm na alternativa normativa; isso não aumenta o furo físico para contato. Rosca, pega, protensão e aço do parafuso são dados separados. O ramo de distribuição uniforme de ligação longa acima de950mm permanece explicitamente não verificado. NBR6.3.8 prescreve1,20 nas solicitações de corte/contato de emendas tracionadas; para esta extremidade em transpasse adota-se conservadoramente o mesmo limite de método uniforme. Aplicar apenas1,20 aos parafusos não qualificaria automaticamente a distribuição e os caminhos parciais longos. O limite não é proibição física de ligações mais longas.

Os cinco metais base são independentes. A seleção de aço exibe fy/fu e conserva seus limites de produto/espessura. Ag e ec vêm da identidade exata de catálogo Gerdau. Raios não publicados não são estimados. O envelope interno do talão, sua origem, ferramenta, folga e arruelas precisam corresponder ao detalhe real; ausência de talão mantém montagem pendente mesmo quando a mecânica é calculável.

## Eixos reais e nominais

NBR8800:2024,6.1.8.2 permite o modelo ordinário estático do eixo terminal na linha de parafusos e no plano médio da chapa. O centroide real da L continua afastado dessa linha em ec−g e em z. Em1L não há cancelamento espacial; em2L-T só os afastamentos simétricos em z se cancelam, não o afastamento no plano. Ct usa ec real e o comprimento entre o primeiro e o último parafuso. Deslocamento real do ponto de trabalho não é apagado por essa idealização e exige alocação excêntrica própria.

As seções de corpo perfurado usam áreas, centroides e inércias reais com deduções circulares, forças de parafusos e partes retidas das duas raízes. A tensão N/A−M(v−vbar)/I e a tela VM com1,5V/A são triagens nominais complementares, não uma solução elástica de contato ou certificado de intervalo. Há estações exatas e refinamento numérico de extremos observados, identificados separadamente.

Uma tensão linear de borda negativa não prova por si só instabilidade do contínuo. A necessidade de compressão é preservada quando N<0, quando existe momento sem N, ou quando a posição da resultante normal sai do trecho físico. Compressão da diagonal e normais negativas nas raízes continuam sem aprovação pelo método de tração.

## Caso real e mínimo normativo

COMPLETE_CUTS continua sendo a única convenção de entrada: cortes completos D e U, cargas adicionais explícitas e corte L derivado. O aplicativo não soma a diagonal novamente aos cortes completos. A comparação com L do Robot se aplica somente ao caso real.

Para0≤Nreal<45kN, o motor conserva o caso real, inclusive zero, e cria um caso de resistência sintético de45kN na direção+u declarada. Mantém D/U e demais ações como fundo explicitamente identificado, aplica45kN uma vez à cadeia antes das divisões, e recalcula raízes, J, L, receptores, continuidade e painel. O resumo toma o governante entre os dois casos. O caso sintético é uma construção de dimensionamento transparente para NBR6.1.5.2, não uma combinação real prescrita pela norma e não um corte Robot. Não transforma compressão em tração. Não acrescenta outro caso quando Nreal≥45kN.

A recomendação opcional de50% da resistência de cálculo da barra não é aplicada automaticamente nem confundida com o mínimo45kN. O usuário deve avaliar sua necessidade em um caso de dimensionamento próprio. O mínimo aqui não afirma que todo membro global ou toda ligação distinta já recebeu todos os casos normativos necessários.

## Persistência e saída

Projetos0.9.32 e0.9.33 conservam suas premissas soldadas. Os novos projetos usam topologias nativas próprias e exigem todos os campos de parafusos, face explícita para1L, unidades e hipóteses exatas. Campos de filetes da diagonal não são aceitos no ramo parafusado. Importação rejeitada não altera o projeto aceito, a memória ou o rascunho.

O resumo reúne governantes por componente físico. Os detalhes mantêm cada parafuso/plano, parede, caminho, caso e fonte. Desenhos mostram o número real de parafusos e planos, as duas raízes soldadas, os cortes assinados e os eixos reais/nominais. Memória copiável, Word resumido/detalhado e resultados JSON são recalculados a partir das entradas atuais; um resultado antigo fornecido por um chamador não autoriza aprovação.

## Limites preservados

Tração ordinária estática, contato direto, uma linha reta e furos-padrão; sem fadiga, sismo, reversão, espaçadores, furos especiais, linhas desiguais/múltiplas, arranjo oposto ou ações espaciais independentes. Whitmore cruzando uma interface apoiada recebe o componente não qualificado específico, sem contar material imaginário. Exceder a triagem conservadora de borda livre máxima exige interpretar aquela borda; não é tratado como falha resistente nem como proibição arbitrária do tamanho da chapa.

A conferência local não libera fabricação, execução/WPS, montagem real, inspeção, estabilidade global ou a ligação de eixo fraco com nervura interna. Fonte de desenvolvimento, pacote extraído, publicação e implantação têm verificações separadas.

## Correção de alcance das rotas parafusadas anteriores

Na revisão de0.9.34, a mesma lacuna foi reproduzida nas rotas anteriores de uma raiz:1L,2L-T e2L opostas. Um grupo com11 parafusos, passo100mm e Lc1000mm era aprovado pelo método uniforme de0.9.33. A correção de alcance acrescenta somente a questão `long_bolt_group` com severidade `outside_scope` para Lc>950mm, após o cálculo geométrico e sem invalidar a geometria. Todos os casos, forças, verificações locais e falhas resistentes continuam disponíveis para diagnóstico; o resumo não aprova o conjunto fora do método qualificado. Protensão e Nreal=0 não dispensam essa fronteira, e o caso mínimo45kN continua separado.

Os17 presets curtos anteriores dessas duas rotas preservam o estado completo, com normalização exclusiva da versão do aplicativo. Doze estados mecânicos de fronteira foram comparados por hash ao0.9.33 imutável, incluindo950−0,001,950,950+0,001 e1000mm nos três arranjos. Essa alteração intencional de alcance é a única correção adicional nos dois motores antigos; não há fator resistente inventado nem mudança nos valores locais.
