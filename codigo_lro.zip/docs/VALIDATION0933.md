# Validação 0.9.33

Gate de fonte aprovado após aceitação numérica e de saída independentes, com hashes de runtime coincidentes. 541 testes pytest distintos passaram; reexecuções sobrepostas não são somadas. As observações independentes e os352 itens da qualificação anterior são categorias separadas, não testes adicionais da implementação.

A adaptação1L pertence à rota de canto existente; permanecem19 rotas. Uma L e dois filetes recebem N integral. O modelo estático nominal NBR6.1.8.2 adota o eixo terminal no plano médio, mantendo declarados o afastamento físico e o momento espacial bruto sem cancelamento ou afirmação de equilíbrio exato3D. Aços, geometrias, dois apoios, cortes concorrentes, continuidade e painel preservam seus próprios cálculos.

As86 linhas independentes foram comparadas:9 de diagonal modificadas e77 mecânicas comuns invariantes;9 casos parametrizados e8 caminhos físicos de gusset são cobertos. O registro JSON identifica contagens e tolerâncias da revisão independente sem somá-las ao pytest. Os1061 arquivos originais0.9.32 e seus134 arquivos de runtime permanecem imutáveis;314 arquivos de exemplos anteriores permanecem copiados integralmente. O pacote traz14 novas entradas e4 Word recalculados, com figuras e MC da configuração real.

Fonte principal: `VALIDATION0933.json`. Aceitações: `ENGINE_ACCEPTANCE0933.json` e `UI_ACCEPTANCE0933.json`. Evidência portátil: `independent_engine0933/` e `independent_outputs0933/`. Os contratos de NumPy das auditorias0.9.32 e0.9.33 ficam separados; expectativas congeladas não foram alteradas para forçar igualdade em outra versão.

A suíte histórica inteira não foi executada. Modos fora do domínio, estabilidade global, fabricação e o antigo oráculo externo ausente continuam com seus limites explícitos. Sem upload, push ou implantação. Extração e smoke do pacote final são um gate separado.
