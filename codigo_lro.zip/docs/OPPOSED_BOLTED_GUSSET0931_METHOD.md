# 2L opostas parafusadas à chapa de nó · 0.9.31

## Arranjo e alcance

Duas cantoneiras iguais de abas iguais, opostas pelos vértices (><), em contato direto com faces opostas de uma única chapa retangular. O afastamento entre talões é h=tg. Cada linha fica em v=±(tg/2+g). Para n parafusos por L há 2n parafusos físicos, cada um com um plano de corte. Não são os n parafusos passantes em corte duplo do arranjo T.

A força N é o total do par. Cada L recebe N/2, cada parafuso recebe N/(2n), e chapa, raiz e receptor W recebem N uma única vez. A força real nula é conservada; o mínimo normativo de 45 kN é um caso separado, aplicado antes da partilha. A recomendação opcional também usa a resistência total do par.

Método limitado a tração estática, linhas alinhadas com mesmo número/passo/estações, mesmas cantoneiras, carregamento compatível e uma raiz longitudinal centrada sobre a alma, na mesa exterior de W laminado. Exclui compressão, fadiga/reversão, ações espaciais impostas, enchimentos, afastadores, apoio direto na alma, duas bordas apoiadas em canto e qualificação global dos membros. O atendimento local não libera fabricação.

## Resistências e hipóteses

- NBR 8800:2024 e Errata 1:2025: tração bruta/líquida efetiva da L, shear lag individual, corte simples do parafuso, contato direcional, detalhamento e caminhos reais de bloco; materiais separados para L, chapa, W, parafuso e eletrodo.
- NBR 6.1.8.2: idealização estática de excentricidade em cada extremidade L. Os binários locais são idealizados fora deste modelo; não se afirma cancelamento físico ponto a ponto nem verificação tridimensional.
- Chapa comum: todos os furos, união de cordas interceptadas, máscaras simultâneas de forças, blocos L/U e suas envoltórias contínuas, n² cadeias líquidas em zigue-zague, Whitmore agregado e triagens por linha com espessura alocada tg/2.
- Blocos parciais: o limite conservador de cada perna usa a mesma posição real da tampa, deduções remanescentes e carga capturada. A resistência transversal é desprezada. Não combina tampa tardia com todos os furos e a força completa da linha.
- Cortes perfurados: tensões N/A+Mx/I e 1,5V/A são triagens nominais complementares. O sinal negativo no trecho de introdução é diagnóstico, sem rejeição automática. As verificações materiais permanecem obrigatórias.
- Ligamento não perfurado: do apoio até a primeira borda de furo físico, verifica-se a tração nas seções extremas. Compressão neste ligamento ou na raiz continua fora do domínio. O diâmetro físico não é substituído pela dedução líquida majorada.
- Raiz: duas soldas reais e metal-base recebem o N/V/M total atual. Mantém o momento real, os efeitos locais condicionais da mesa/alma do W, extremidades e transporte ao centroide. Ações globais concomitantes do W permanecem externas a esta qualificação.

Catálogo Gerdau: usam-se identidades, Ag e ec reais. O catálogo não fornece raio interno de talão; o envelope de exclusão do talão, ferramenta e folga são dimensões reais de detalhamento. O valor 12,35 mm do exemplo é hipótese manual demonstrativa, não propriedade de catálogo.

## Exemplo prático de referência

L Gerdau p3R29, 76,2×76,2×6,35 mm, Ag=929 mm² e ec=21,3 mm por L; chapa B=H=300 mm e tg=12,5 mm; θ=80°; N=100 kN; 3 M16 por L, 6 parafusos em corte simples, furos físicos de 18 mm, g=40 mm e p=50 mm. Soldas de raiz de 5 mm, fw=415 MPa. Aços L/chapa 250/400 MPa e W 345/450 MPa.

Resultados independentes esperados: bloco da L 0,421153774; solda de raiz 0,387391955; envoltória parcial refinada 0,196108418; tensão normal mínima do ligamento real 12,369685867 MPa. Diagnósticos nominais mínimos na introdução: −0,499890618 MPa horizontal e −0,507075416 MPa normal à barra. Esses sinais não invalidam o exemplo.

## Proveniência e auditoria

Contrato completo: `qualification_opposed_bolted0931/QUALIFICATION.md`. Aceitação independente do método: `qualification_opposed_bolted0931/reviewer/INDEPENDENT_METHOD_VERDICT.md`. Os 17 fixtures e 21 cargas de falha têm cálculo próprio sem importação de módulos de produção. A comparação independente refinada contém 736 verificações aprovadas. Os antigos limites excessivamente conservadores ficam somente como histórico diagnóstico, nunca como critérios de produção.

As famílias anteriores conservam seus formatos e motores. A disposição nova fica dentro da rota parafusada completa, com identidade nativa distinta, sem converter projetos 1L/T. Não muda o modelo de duas talas de alma de coluna; a revisão com nervura interna continua separada.
