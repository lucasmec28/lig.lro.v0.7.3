# Validação da revisão 0.9.8-base-flow-dev

A linha-base é o código extraído do pacote 0.9.7 entregue. Foi preservada sem edições. A cópia 0.9.8 contém o delta delimitado em BASE_FLOW098_METHOD.md; as 11 famílias e versões/esquemas dos componentes foram conservados.

## Resultado final de software

Foi executado um único agregado completo de 1.820 casos, com código e testes congelados: **1.810 passaram e 10 falharam**, em 2.130,37 s, saída 1. Os arquivos acompanhados permaneceram idênticos durante essa execução. Não se apresenta esse resultado como um agregado integralmente verde.

As dez falhas foram examinadas individualmente. Não exigiram mudança de produção:

- Três casos de interface ainda procuravam avisos repetidos, substituídos pelo resumo único dos caminhos locais e responsabilidades externas.
- Três casos de estado/texto ainda exigiam a frase antiga de complemento global ou a redação anterior do escopo de ancoragem.
- Um caso de Word exigia as duas comparações de grupo redundantes removidas. As fórmulas especiais e gerais por barra, o coeficiente 0,533, as capacidades intermediárias, o mínimo governante e sua soma continuavam presentes. O teste passou a conferir essas expressões e os valores da tabela exportada.
- Três casos de preservação comparavam o resultado inteiro da solda após uma mudança de entrada, incluindo a nova assinatura completa de atualidade. A revisão independente confirmou igualdade de todos os demais campos. Agora somente essa assinatura é comparada ao seu próprio projeto; todas as igualdades numéricas, geométricas, de forças e verificações continuam estritas. Desligar o componente opcional preserva o dado físico de restrição das barras.

Após corrigir apenas essas expectativas em oito arquivos de teste, foram repetidos **todos os dez casos completos**, inclusive os fluxos AppTest e suas exportações/invalidações, mais dois casos específicos de Word e ação integral de solda. Resultado: **12 passaram**, em 42,12 s, saída 0. Produção permaneceu idêntica à do agregado. Essa evidência combinada cobre os 1.820 casos; não representa uma segunda execução integral nem soma os dois casos de confirmação como casos novos.

## Revisões independentes e verificações focadas

- Revisão técnica: **143/143 assertivas**, em 46 instantâneos das duas famílias, mais **22/22** verificações de vínculo e atualidade. Comparação isolada com a 0.9.7 confirmou os resultados ativos preservados, os vetores reais de linhas próximas/distantes e a reconstrução independente da soma dos mínimos por barra.
- Revisão de interface: primeira rodada com **41/43** assertivas; as duas falhas eram a omissão da Ase,N e sua referência no Word. Após correção, **19/19** verificações direcionadas passaram, cobrindo as duas famílias, relatórios completos/locais e rascunhos inválidos inativos/restaurados. A revisão encerrou com aceite do delta delimitado.
- Ensaios focados anteriores incluíram 271 casos corrigidos de cálculo/estado e 83 casos finais de estado/interface, além dos quatro casos de aceitação independentes. São execuções sobrepostas, não contagens adicionais de testes únicos.
- Os dois relatórios Word locais corrigidos da chave foram renderizados em PDF/imagens: cinco páginas por família, dez páginas inspecionadas. A área compartilhada e sua fonte estavam legíveis, sem cortes ou sobreposições observados nesses exemplos. Os relatórios completos também passaram pela conferência independente de conteúdo.

## Pacote e limites

A verificação da extração limpa do ZIP final, identidade dos módulos carregados, navegação das 11 famílias e exportações reais pertence à etapa de empacotamento. Há um ensaio portátil separado para essa etapa; este registro de código-fonte não antecipa seu resultado.

Streamlit AppTest verifica widgets, estado, navegação, dados e resultados. O Chromium real não pôde iniciar por restrição de sockets do ambiente; não se atribui a esses ensaios inspeção visual pixel a pixel ou validação responsiva. Relatórios e desenhos mantêm verificações programáticas de conteúdo, equações, geometria e atualidade.

Os resultados são evidência de software e de coerência dos modelos delimitados; não certificam um projeto estrutural real nem execução em obra. A próxima etapa solicitada é a auditoria sequencial das famílias existentes, começando por Single plate, antes de novas famílias.
