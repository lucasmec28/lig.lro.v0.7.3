"""Independent tighter partial-path bounds and unperforated ligament audit.
Derived from NBR6.5.6 and actual circle intervals; no production/author imports.
"""
import json, math
from pathlib import Path
from scipy.optimize import minimize_scalar
O=Path(__file__).parent

def calc(B=300.,theta=80.,dn=18.,N=100000.,t=12.5):
 c,s=math.cos(math.radians(theta)),math.sin(math.radians(theta));r=dn/2;rows=[-(t/2+40),t/2+40];us=[-50.,0.,50.]
 def point(u,v):return c*u+s*v,150+s*u-c*v
 def exit_u(v):
  answers=[]
  for target in [-B/2,B/2]:
   if abs(c)>1e-12:
    u=(target-s*v)/c;x,y=point(u,v)
    if u>50 and 0<=y<=300:answers.append(u)
  u=(150+c*v)/s;x,y=point(u,v)
  if -B/2<=x<=B/2:answers.append(u)
  return min(answers)
 rows_out=[]
 for v in rows:
  E=min(exit_u(v-r),exit_u(v),exit_u(v+r))
  def val(q,k):
   av=t*(E-q);ded=sum(max(0,min(E,uj+r)-max(q,uj-r)) for uj in us);anv=t*(E-q-ded)
   ry=.6*250*av/1.35;rr=.6*400*anv/1.35;D=k*N/6
   return dict(u=q,captured=k,Agv=av,Anv=anv,Ant_credit=0.,R_yield=ry,R_rupture=rr,R=min(ry,rr),D=D,utilization=D/min(ry,rr))
  exact=[val(uj+r,3-j) for j,uj in enumerate(us)]
  # Independent dense cap/interhole interval validation of the analytic end witnesses.
  dense=[];events=sorted([u+z for u in us for z in [-r,0.,r]])
  for a,b in zip(events,events[1:]):
   k=sum(uj+r>=(a+b)/2 for uj in us)
   if not k:continue
   for i in range(101):dense.append(val(a+(b-a)*i/100,k))
  gov=max(exact,key=lambda z:z['utilization']);test=max(dense,key=lambda z:z['utilization'])
  assert abs(gov['utilization']-test['utilization'])<1e-12
  rows_out.append(dict(v=v,footprint=[v-r,v+r],minimum_forward_free_exit=E,candidates=exact,governing=gov,dense_check_max=test['utilization']))
 # root-to-first nominal hole edge, with all six forces included below that edge.
 yfirst=min(point(u,v)[1]-9. for u in us for v in rows) # Actual hole is18mm even when nominal net deduction is20mm
 nr=N*s;vr=N*c;mr=-150*N*c;A=B*t;I=t*B**3/12
 ligament=[]
 for y in [0.,yfirst]:
  M=mr+y*vr;sig=[nr/A+M*x/I for x in [-B/2,B/2]];tau=1.5*abs(vr)/A
  ligament.append(dict(y=y,A=A,I=I,N=nr,V=vr,M=M,sigma=sig,VM=math.sqrt(max(abs(z) for z in sig)**2+3*tau*tau)))
 return dict(B=B,H=300.,theta=theta,dn=dn,N=N,t=t,occupied_row_cap_bounds=rows_out,guard_utilization=max(z['governing']['utilization'] for z in rows_out),
  unperforated_ligament_endpoints=ligament,unperforated_min_normal=min(min(z['sigma']) for z in ligament),unperforated_max_VM=max(z['VM'] for z in ligament))
results=[calc(),calc(B=340),calc(B=340,theta=90),calc(B=340,theta=100),calc(N=150000),calc(dn=20),calc(theta=75),calc(theta=70),calc(theta=90),calc(theta=100),calc(t=8,N=220000),calc(B=340,t=8,N=220000)]
report=dict(scope='Tighter conservative occupied-leg shear-only lower bound; actual captured load and actual hole intersection intervals kept correlated. Source-standard local checks still mandatory.',
 proof='In a fixed captured-bolt interval, Av and Anv are nonincreasing affine or piecewise affine functions of u, while D is constant. Both resistance branches are nonincreasing. The maximum utilization is attained at u_j+r from the captured side. Any pair of unequal prefixes is bounded because D1+D2 <= min(Y1,R1)+min(Y2,R2) <= min(Y1+Y2,R1+R2).',
 root_sign_scope='Require tension in actual unperforated root-to-first-hole ligament and supported root. Sign of supplemental fictitious all-mask section stress inside load introduction is diagnostic, not a physical compression/buckling oracle.',results=results)
(O/'REFINED_PARTIAL_AND_LIGAMENT_REVIEW.json').write_text(json.dumps(report,indent=2)+'\n')
for z in results:
 print(json.dumps({k:z[k] for k in ['B','theta','dn','N','t','guard_utilization','unperforated_min_normal','unperforated_max_VM']}))
 print('governing',json.dumps([q['governing'] for q in z['occupied_row_cap_bounds']]))
