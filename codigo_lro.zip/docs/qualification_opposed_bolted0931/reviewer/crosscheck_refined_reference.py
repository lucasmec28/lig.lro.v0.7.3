"""Compare the new author's fixtures to independently generated reviewer expectations.
No production imports. Expectations were completed before author output inspection.
"""
import json, math
from pathlib import Path
p=Path(__file__).parent
own=json.loads((p/'INDEPENDENT_OPPOSED_GUSSET_REVIEW.json').read_text())
author=json.loads((p.parent/'NEW_OPPOSED_BOLTED_FIXTURES.json').read_text())
refined=json.loads((p/'REFINED_PARTIAL_AND_LIGAMENT_REVIEW.json').read_text())
checks=[]
def eq(name,a,b,rel=2e-7,abs_=2e-6):
    okay=math.isclose(a,b,rel_tol=rel,abs_tol=abs_);checks.append(dict(name=name,independent=a,author=b,passed=okay))
for th,B in [(80,340),(90,340),(100,340),(80,300)]:
    a=next(x for x in author['fixtures'] if x['inputs']['theta']==th and x['inputs']['plate']==[B,300.,12.5] and x['inputs']['N']==100000 and x['inputs']['drilled'] and x['inputs']['materials']['gusset']==[250.,400.])
    z=next(x for x in own['results'] if x['theta']==th and x['B']==B)
    prefix=f'{B}:{th}:'
    ref=next(x for x in refined['results'] if x['B']==B and x['theta']==th and x['dn']==18 and x['N']==100000 and x['t']==12.5)
    for h,hh in zip(z['holes'],a['holes']):
        for k,j in [('x',0),('y',1)]:eq(prefix+h['id']+':'+k,h[k],hh['xy'][j])
    for k in ['N','V','M']:eq(prefix+'root:'+k,z['root'][k],a['root'][k])
    mapid={'U_both_rows':'U_both','L_row0_negative_v_single':'L0_-1','L_row0_positive_v_both':'L0_1','L_row1_negative_v_both':'L1_-1','L_row1_positive_v_single':'L1_1'}
    for h in z['block_center_cases']:
        hh=next(x for x in a['gusset_center_witnesses'] if x['id']==mapid[h['path']] and x['u']==h['q'])
        for k,kk in [('Agv','Agv'),('Anv','Anv'),('Ant','Ant'),('R','R'),('D','demand')]:eq(prefix+h['path']+f':{h["q"]}:'+k,h[k],hh[kk])
    for k,kk in [('R','R'),('q','u'),('utilization','utilization')]:eq(prefix+'cap_governing:'+k,z['governing_block'][k],a['gusset_governing'][kk],rel=1e-6,abs_=3e-5)
    eq(prefix+'horizontal_min_loaded',min(z['horizontal_screen']['min_loaded_normal']['sigma_edges']),min(x['min_sigma']['sigma_min'] for x in a['horizontal_sections'] if x['min_sigma']['active']))
    eq(prefix+'horizontal_max_vm',z['horizontal_screen']['max_vm']['vm_nominal'],max(x['max_VM']['VM'] for x in a['horizontal_sections']))
    eq(prefix+'forcenormal_min_loaded',min(z['force_normal_screen']['min_loaded_normal']['sigma_edges']),min(min(x['sigma']) for x in a['force_normal_sections'] if x['active']))
    eq(prefix+'forcenormal_max',max(z['force_normal_screen']['max_normal']['sigma_edges']),max(max(x['sigma']) for x in a['force_normal_sections']))
    for h in z['net_chains']:
        hh=next(x for x in a['zigzag_net_chains'] if x['u_left']==h['u_negative_row'] and x['u_right']==h['u_positive_row'])
        for k,kk in [('net_area','An'),('R','R')]:eq(prefix+f'chain:{h["u_negative_row"]},{h["u_positive_row"]}:'+k,h[k],hh[kk])
    for ri,row in enumerate(ref['occupied_row_cap_bounds']):
        for h in row['candidates']:
            hh=next(x for x in a['unequal_partial_U_bounds'] if x['row']==ri and x['start']==h['u'])
            for k,kk in [('Agv','Agv'),('Anv','Anv'),('R_yield','R_yield'),('R_rupture','R_rupture'),('R','R'),('D','demand'),('utilization','utilization')]:eq(prefix+f'partialrow:{ri}:{h["u"]}:'+k,h[k],hh[kk])
    eq(prefix+'ligament_end',ref['unperforated_ligament_endpoints'][1]['y'],a['solid_root_ligament']['end'])
    for h,hh in zip(ref['unperforated_ligament_endpoints'],a['solid_root_ligament']['cuts']):
        for k in ['N','V','M','A','I','VM']:eq(prefix+f'ligament:{h["y"]}:'+k,h[k],hh[k])
        for i in range(2):eq(prefix+f'ligament:{h["y"]}:sigma{i}',h['sigma'][i],hh['sigma'][i])
    wh=a['Whitmore'][0]
    for k,kk in [('A','Ag'),('An','An'),('yield_R','R_yield'),('rupture_R','R_net')]:eq(prefix+'Whitmore:'+k,z['whitmore'][k],wh[kk])
    for hh in a['Whitmore'][1:]:
        w=200*math.tan(math.pi/6);eq(prefix+hh['id']+':yield',w*6.25*250/1.1,hh['R_yield']);eq(prefix+hh['id']+':net',(w-18)*6.25*400/1.35,hh['R_net'])
    # Independent closed-form connected-toe stationary cap, NBR block gross-yield branch.
    q=50-9*.75/math.sqrt(1+.75**2);ant=(36.2-math.sqrt(81-(q-50)**2))*6.35;agv=(q+85)*6.35
    rd=(.6*250*agv+.5*400*ant)/1.35
    eq(prefix+'angle_cap_R',rd,a['angle_governing']['R'])
    eq(prefix+'bolt_single_plane',.45*math.pi*16**2/4*830/1.35,a['bolt']['single_plane_R'])
report=dict(passed=all(x['passed'] for x in checks),count=len(checks),failures=[x for x in checks if not x['passed']],checks=checks)
(p/'AUTHOR_REFINED_CROSSCHECK.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['passed','count','failures']},indent=2))
