# Refined independent qualification: opposed bolted 2L and one rectangular gusset

11 October 2026. Qualification only. No application modules were imported, no production source was changed, and no historical numerical oracle was recreated.

## Final decision

**GO for the explicitly bounded conventional static-tension method**, including the practical **B300/H300/t12.5, theta80-degree, N100kN** fixture. B340/80, B340/90 and B340/100 remain independent positive references. The B300 example is qualified by actual source-supported load-introduction checks and a tensile unperforated ligament/root. Its negative supplementary all-mask stress inside the bolted region remains visible as a diagnostic; it is not used as a physical buckling oracle.

The two changes from the initial review are justified method refinements, not silent waivers:
1. Correlate each partial shear path's actual cap position, remaining hole deductions and captured load. The original all-holes/latest-cap/full-row combination was a valid but unnecessarily weak bound that combined mutually incompatible conditions.
2. Retain the full-width perforated-section stress calculation and its material envelopes, but do not demand a wholly tensile sign from a field already disclosed to be a supplemental fictitious beam-section/contact-mask envelope. Retain the tensile sign requirement in the actual unperforated root-to-first-hole ligament and at the receiving root.

The finite remaining work before production exposure is implementing and independently accepting this arrangement, the explicit revised contract and its exclusions. No further primary-case mechanics calculation, generic FEA gate or broad reference hunt was identified. Verified hardware/heel clearance remains an ordinary assembly input. This is not fabrication or whole-structure approval.

## Sources and verification

The actual supplied NBR8800:2024 corrected in2025 was visually checked at PDF61-62 (tension, net area and stagger), PDF93 (§6.1.8.2 static-angle end idealization), PDF106-107 (single-plane bolt shear and directional bearing), and PDF116-118 (§§6.5.3-6.5.6 connection tension, compression, shear, block equation and Fig.16). Both block branches use gamma_a2=1.35; Cts0.5 remains conservative in the explicit block checks.

The supplied DG29 Example5.4, PDF106-116, supplies the conventional angle/bolt/gusset/Whitmore/root continuation. Fig.5-10 was visually inspected. Its shared double-shear bolt topology is not the opposed arrangement; its AISC factors, shaped plate, compression case, capacity redistribution and plastic root convention are not silently transplanted into the new NBR rectangle.

DG29 PDF110-112 checks bearing, block shear and the Whitmore tension section for introduction. PDF114-116 checks the actual gusset-to-support interface actions, plate stresses, weld and local support effects. NBR6.5.3/6.5.5/6.5.6 provides the required tension/shear/block resistances; §6.5.4 applies when the connection element is compressed. These sources do not prescribe, or establish as a continuum solution, an everywhere-positive all-mask beam field through every hole cap. The revised distinction between a physical unperforated load-path check and a supplemental introduction-zone diagnostic is a source-grounded engineering interpretation, not a quotation of a new code rule.

**736 independent comparisons passed** against the refined author's B340/80,90,100 and B300/80 fixtures. They cover positions, reactions, 15 centered U/L paths per fixture, continuous circular-cap extrema, all-mask horizontal/force-normal extrema, nine zigzag chains, six tighter partial-path witnesses, the unperforated ligament endpoints, Whitmore, bolt shear and the angle cap closed form.

Files:
- INDEPENDENT_OPPOSED_GUSSET_REVIEW.json and review_opposed_new.py: independently generated geometry, paths, all-mask screens and initial conservative-bound observations. The initial bound values are not the final acceptance guard.
- REFINED_PARTIAL_AND_LIGAMENT_REVIEW.json and review_practical_refinement.py: final correlated partial-path proof and real unperforated ligament calculations, including an independent dense interval check.
- AUTHOR_REFINED_CROSSCHECK.json and crosscheck_refined_reference.py: final736/736 comparison record.
- INITIAL_SUPERSEDED_METHOD_VERDICT.md: clearly marked initial conservative interpretation retained for audit, superseded by this document.

## Physical topology and equilibrium

With h=tg12.5 and gauge40, rows are v=+-46.25mm, each at u=-50,0,50. Six distinct physical bolts have one shear plane each and demandN/6=16.666667kN. Each L receivesN/2. The common gusset and one root receive N once. They are not three shared double-shear bolts.

NBR6.1.8.2 is explicitly applied to each ordinary statically loaded angle end. This does not prove that spatial face couples physically cancel. Fatigue, cyclic reversal, standoffs, imposed spatial actions, unequal members/loading and a second receiving interface remain excluded.

At theta80 the holes(s,n), mm, are:
- negative-v: (-54.229767,108.790841), (-45.547359,158.031228), (-36.864950,207.271616)
- positive-v: (36.864950,92.728384), (45.547359,141.968772), (54.229767,191.209159)

Cross-row distance92.5mm and longitudinal pitch50mm are actual spatial distances. Cross-row n offset16.062456mm is smaller than hole diameter18, so horizontal hole-cap projections overlap despite the large spatial separation. Subtract the union of all actual spatial chords and retain every crossing-force mask.

Summing all six forces gives root Nn98.480775301kN, Vs17.364817767kN, M-2.604722665kNm. Each intermediate section instead uses its actual captured bolt subset and moment about its own net centroid. No arbitrary extra moment, duplicate gusset or second root is introduced.

## Common plate, standard blocks and net chains

The contained aggregate Whitmore width is207.970053838mm, gross area2599.625672974mm2 and conservative net area2149.625672974mm2. Gross yielding is590.824016585kN; supplemental net rupture is636.926125326kN. Individual-row half-thickness Whitmore checks are a conservative explicit allocation of distinct material, not a DG29-prescribed new formula. Their yielding utilization is0.304840942; overlapping full-thickness cones must not be summed as independent capacities.

At B300/theta80, the actual same-station two-hole force-normal section has An3357.849794572mm2. The nine different-station chains must also be retained despite aligned rows: the oblique rectangle's free-side exits vary with station. The governing zigzag pair u_negative=-50/u_positive=0, and its translated counterpart, has An3332.104891088mm2 and R987.290338100kN after the NBR s²/(4g) credit. Keep actual captured demand and the separately disclosed conservative full-N comparison.

The U block uses two distinct shear rays, with actual forward exits u144.158868925 and160.469114641. Its full centered resistance is699.946273471kN against100kN. An outward L contains one row; an inward L contains both and deducts one half chord plus a full chord on its transverse cap. Never sum alternative L capacities. All relevant primary-fixture exits are free edges, without a retained positive segment of supported root.

Circular-cap interior extrema remain necessary. At B300/theta80 the governing ordinary L-both cap occurs at u=-48.309609348, R592.796777336kN against100kN, utilization0.168691875. The counterpart at B340 hasR630.405170369kN and utilization0.158628141. A hole-center-only search misses these minima.

The angle's independent connected-toe cap stationary point is u44.6, with R118.721481481kN per L against50kN, utilization0.421153774. This is weaker than the older center-only witness. The B300 primary fixture's root weld utilization is0.387391955, so the ordinary angle cap governs the listed primary conventional/material checks.

## Final partial-path proof: correlated actual cap and capture

The finite additional family is unchanged: ordinary straight +u shear legs inside an occupied row's nominal footprint v=row+-dn/2, terminating at the actual free boundary. It includes unequal prefixes, ordinary leg offsets and narrow-U variations in those footprints. It does not claim every arbitrary curved microscopic crack surface.

For a given cap u and occupied row:
- E is the minimum actual forward free exit over the nominal row footprint;
- Agv=t(E-u);
- Anv=t[(E-u)-sum(length([u,E] intersect [uj-r,uj+r]))];
- Ant credit is zero;
- captured upper-limit demand is k(u)N/(2n), where k counts uj+r>=u.

Using each full center-line diameter interval over-deducts any smaller off-center chord. Using the earliest footprint exit underestimates each actual shear-leg length. Thus the gross/net values are conservative while preserving correlations between geometry and force capture.

Within any fixed captured-bolt interval, demand is constant and both resistance branches are nonincreasing, piecewise affine functions of u. Consequently evaluating u=uj+r from the captured side is sufficient; all intervals, including hole interiors, were independently sampled to confirm these endpoint extrema. There is no smooth-cap tensile term because no transverse strength is credited in this supplemental bound.

At theta80, B300 or B340, t12.5, dn18, N100kN:
- negative-v critical u=-41, k3: Agv2294.649076234, Anv1844.649076234mm2; R254.961008470kN against50kN, utilization0.196108418
- positive-v critical u=-41, k3: Agv2498.527147678, Anv2048.527147678mm2; R277.614127520kN against50kN, utilization0.180106108

Every unequal-row combination follows from D1+D2<=min(Y1,R1)+min(Y2,R2)<=min(Y1+Y2,R1+R2), before crediting any joining tension. A zero-capture row needs no force allowance. The older latest-cap/all-holes/full-N-per-row combination is no longer the guard.

At N150kN the guard utilization is0.294162627 and no longer creates an artificial rejection. With nondrilled nominal deduction20mm at N100kN it is0.197373183. Those earlier rejection examples are superseded, not evidence of physical strengthening or a changed hole diameter for contact. Actual bearing continues to use the physical18mm hole.

## Load introduction diagnostic versus real ligament gate

The all-mask N/A+M(x-xbar)/I and1.5|V|/A expressions remain useful supplemental material screens. Areas, centroids, inertias and discrete resultants are exact within their geometry/point-force representation, but the resulting beam stress expressions are not an exact perforated-plate/contact field. Retain their absolute stress/material checks and signed diagnostic values. Do not convert a tiny negative artificial-mask value into proven compression buckling, and do not claim all introduction-zone material is tensile.

B300/theta80 retains horizontal minimum-0.499890618MPa and force-normal minimum-0.507075416MPa as diagnostics. Its maximum horizontal nominalVM is41.916974884MPa, well inside the stated material envelope. All actual source-supported introduction checks remain mandatory: each angle/plane/contact, actual U/L and partial paths, Whitmore with shared-material accounting, and real net/zigzag sections.

The actual unperforated ligament extends from the root n0 to the first physical18mm hole edge n83.728384132mm. All six forces are above every section in this ligament. Its conventional rectangular-section moment is M(n)=Mroot+nVroot, and edge stresses are affine in n, so endpoint checks bound the entire ligament:
- minimum normal stress12.369685867MPa
- maximum nominalVM41.916974884MPa
- both root normal-traction edges are tensile

Use the physical hole diameter for this geometric ligament boundary even when the normative net deduction is20mm. Do not waive actual root/ligament compression: B300/theta70 has minimum-2.303141578MPa at the root and remains outside this tension-only route. Compression, required stability checks, geometric/detail failures or material failures are not excused by the diagnostic reinterpretation.

## Detail and release conditions

The Gerdau catalog does not publish the inside heel radius. With gauge40, tool radius18 and clearance2, require a verified heel exclusion extent<=20mm; equivalently inside radius<=13.65mm if extent=tL+r. The declared12.35mm manual fixture extent leaves7.65mm margin and must stay labelled as manual detail, not catalog data.

Keep independent angle/gusset/W/bolt/electrode records, the actual one-plane grip, directional bearing, pitch/free edges, access/overlap, root weld/base material and receiving W checks. Apply a connection minimum load once before row/plane division; a real zero case stays zero. The existing one-root/W continuation remains valid with the verified total resultant. No local pass approves the W member's concurrent global actions or a whole structure.

Implementation acceptance must reproduce these final correlated partial bounds, preserve the signed introduction diagnostics and material checks, enforce the unperforated ligament/root gate, and retain actual physical assembly checks. The initial conservative report is explicitly superseded.
