"""NEW source/math-derived opposed bolted reference, 2026-10-11.
No production imports or production outputs used as expected values.
NBR8800 supplied §§5.2,5.7,6.3,6.5; DG29 conventional gusset/root model.
"""
import math,json,hashlib,itertools
from pathlib import Path
import numpy as np
from scipy.optimize import minimize_scalar
PTH=Path(__file__).parent
GA1,GA2=1.10,1.35

def section(parts,t):
    A=t*sum(b-a for a,b in parts);Q=t*sum((b*b-a*a)/2 for a,b in parts)
    c=Q/A;I=t*sum((b**3-a**3)/3 for a,b in parts)-A*c*c
    return A,c,I

def subtract(interval,holes):
    out=[interval]
    for h0,h1 in sorted(holes):
        new=[]
        for a,b in out:
            if h1<=a or h0>=b:new.append((a,b));continue
            if h0>a:new.append((a,min(h0,b)))
            if h1<b:new.append((max(h1,a),b))
        out=new
    return out

def block(Av,Anv,Ant,fy,fu,D,**kwargs):
    rY=(.6*fy*Av+.5*fu*Ant)/GA2;rR=(.6*fu*Anv+.5*fu*Ant)/GA2
    return dict(Agv=Av,Anv=Anv,Ant=Ant,Cts=.5,R_yield=rY,R_rupture=rR,R=min(rY,rR),demand=D,utilization=D/min(rY,rR),**kwargs)

def build(theta=80.,N=100000.,B=340.,H=300.,tg=12.5,drilled=True,plate_fy=250.,plate_fu=400.,s0=0.,n0=150.,g=40.,n=3,pitch=50.):
    C,S=math.cos(math.radians(theta)),math.sin(math.radians(theta));v0=tg/2+g
    rows=[-v0,v0];stations=[(j-(n-1)/2)*pitch for j in range(n)];d=16.;dh=18.;dn=18. if drilled else 20.;r=dn/2
    b,ta,Ag,ec,e=76.2,6.35,929.,21.3,35.
    fy,fu,fub,fw=250.,400.,830.,415.;fyp,fup=plate_fy,plate_fu
    F=N/(2*n)
    def xy(u,v):return np.array([s0+u*C+v*S,n0+u*S-v*C])
    def uv(point):x,y=point;return np.array([(x-s0)*C+(y-n0)*S,(x-s0)*S-(y-n0)*C])
    holes=[dict(id=f'{ri}:{j}',row=ri,u=u,v=v,xy=xy(u,v).tolist(),force=F) for ri,v in enumerate(rows) for j,u in enumerate(stations)]
    def exit(point,vec):
        opts=[]
        for ax,lims in [(0,[-B/2,B/2]),(1,[0,H])]:
            if abs(vec[ax])<1e-13:continue
            for lim in lims:
                l=(lim-point[ax])/vec[ax];z=point+l*np.array(vec)
                if l>=-1e-8 and -B/2-1e-7<=z[0]<=B/2+1e-7 and -1e-7<=z[1]<=H+1e-7:opts.append((max(0.,l),z))
        return min(opts,key=lambda z:z[0])
    ends=[exit(xy(0,v),[C,S])[0] for v in rows]
    def root_length(u,vlo,vhi):
        cuts=[-B/2,B/2]
        if abs(C)>1e-13:cuts.append(s0+(u+n0*S)/C)
        for v in [vlo,vhi]:
            if math.isfinite(v):cuts.append(s0+(v-n0*C)/S)
        cuts=sorted(set(max(-B/2,min(B/2,x)) for x in cuts));total=0
        for a,bb in zip(cuts,cuts[1:]):
            uu,vv=uv(((a+bb)/2,0))
            if uu>=u-1e-9 and vlo-1e-9<=vv<=vhi+1e-9:total+=bb-a
        return total
    def q(u,uc):return math.sqrt(max(0,r*r-(u-uc)**2)) if abs(u-uc)<=r else 0.
    def line_net(u,v,end):
        ded=sum(max(0.,min(end,uc+r)-max(u,uc-r)) for uc in stations)
        return end-u-ded
    fams=[dict(id=f'L{j}_{sign}',kind='L',row=j,sign=sign,lo=(-math.inf if sign<0 else rows[j]),hi=(rows[j] if sign<0 else math.inf)) for j in [0,1] for sign in [-1,1]]
    fams.append(dict(id='U_both',kind='U',lo=rows[0],hi=rows[1]))
    def cap(u,fam,force_ids=None):
        lo,hi=fam['lo'],fam['hi'];root=root_length(u,lo,hi)
        if root>1e-7:return None
        if fam['kind']=='L':
            ri=fam['row'];v=rows[ri];dist,pt=exit(xy(u,v),[fam['sign']*S,-fam['sign']*C]);vend=uv(pt)[1]
            low,high=sorted([v,vend]);dedT=0
            for h in holes:
                hh=q(u,h['u']);dedT+=max(0.,min(high,h['v']+hh)-max(low,h['v']-hh))
            Lv=ends[ri]-u;av=Lv*tg;anv=line_net(u,v,ends[ri])*tg;at=(dist-dedT)*tg
            coords=[xy(ends[ri],v).tolist(),xy(u,v).tolist(),pt.tolist()]
        else:
            av=sum(end-u for end in ends)*tg;anv=sum(line_net(u,v,end) for v,end in zip(rows,ends))*tg
            dedT=0
            for h in holes:
                hh=q(u,h['u']);dedT+=max(0.,min(rows[1],h['v']+hh)-max(rows[0],h['v']-hh))
            at=(rows[1]-rows[0]-dedT)*tg
            coords=[xy(ends[0],rows[0]).tolist(),xy(u,rows[0]).tolist(),xy(u,rows[1]).tolist(),xy(ends[1],rows[1]).tolist()]
        if min(av,anv,at)<-1e-7:return None
        incl=[h['id'] for h in holes if lo-1e-9<=h['v']<=hi+1e-9 and h['u']+r>=u-1e-8]
        excl=[h['id'] for h in holes if lo-1e-9<=h['v']<=hi+1e-9 and h['u']-r>u+1e-8]
        ids=incl if force_ids is None else force_ids
        if not ids:return None
        return block(av,anv,max(0,at),fyp,fup,F*len(ids),id=fam['id'],u=u,path=coords,captured_ids=ids,including_crossing=incl,excluding_crossing=excl,positive_supported_root_length=root)
    corners=[uv((x,y))[0] for x in [-B/2,B/2] for y in [0,H]]
    bounds=sorted(set([u+z for u in stations for z in [-r,0.,r]]+[u for u in corners if stations[0]-r<u<stations[-1]+r]))
    caps=[];center=[]
    for fam in fams:
        center.extend(z for u in stations if (z:=cap(u,fam)))
        for ua,ub in zip(bounds,bounds[1:]):
            mid=(ua+ub)/2
            ids=[h['id'] for h in holes if fam['lo']-1e-9<=h['v']<=fam['hi']+1e-9 and h['u']+r>mid]
            if not ids:continue
            vals=[]
            def eval_(u):return cap(float(u),fam,ids)
            for x in [ua,ub]:
                z=eval_(x)
                if z:vals.append(z)
            for a,bb in zip(np.linspace(ua,ub,17),np.linspace(ua,ub,17)[1:]):
                opt=minimize_scalar(lambda u:-(eval_(u) or {'utilization':-1e99})['utilization'],bounds=(a,bb),method='bounded',options={'xatol':1e-10})
                if z:=eval_(opt.x):vals.append(z)
            if vals:caps.append(dict(interval=[ua,ub],**max(vals,key=lambda z:z['utilization'])))
    # Angle free-end caps. Fully source-derived nominal toe/complement geometry.
    angle_caps=[];angle_end=stations[0]-e
    for side,transgross in [('connected_toe',(b-g)*ta),('far_toe_complement',Ag-(b-g)*ta)]:
        for ua,ub in zip(bounds,bounds[1:]):
            k=sum(u-r<(ua+ub)/2 for u in stations)
            if not k:continue
            def ac(u):
                ded=sum(max(0,min(u,uc+r)-max(angle_end,uc-r)) for uc in stations)
                av=(u-angle_end)*ta;anv=(u-angle_end-ded)*ta;at=transgross-sum(q(u,uc)*ta for uc in stations)
                return block(av,anv,at,fy,fu,k*F,id='A_'+side,u=u,k=k)
            vals=[ac(ua),ac(ub)]
            for a,bb in zip(np.linspace(ua,ub,13),np.linspace(ua,ub,13)[1:]):
                opt=minimize_scalar(lambda u:-ac(u)['utilization'],bounds=(a,bb),method='bounded',options={'xatol':1e-11});vals.append(ac(opt.x))
            angle_caps.append(dict(interval=[ua,ub],**max(vals,key=lambda z:z['utilization'])))
    # Actual directional contact: each gusset hole only receives one single-shear bolt force F.
    bearing=[]
    for h in holes:
        j=stations.index(h['u']);ri=h['row']
        for part,th,uf,lc in [('angle',ta,fu,e-dh/2 if j==0 else pitch-dh),('gusset',tg,fup,pitch-dh if j<n-1 else ends[ri]-stations[-1]-dh/2)]:
            R=min(1.2*lc*th*uf,2.4*d*th*uf)/GA2;bearing.append(dict(hole=h['id'],part=part,lc=lc,R=R,demand=F,utilization=F/R))
    # Whitmore: aggregate two-row segment + actual per-row half-thickness screens, overlap never doubles material.
    w1=2*(n-1)*pitch*math.tan(math.pi/6);wa=2*v0+w1
    wh=[]
    for ident,vc,w,t_eff,D,nh in [('aggregate',0.,wa,tg,N,2),('left_half_depth',-v0,w1,tg/2,N/2,1),('right_half_depth',v0,w1,tg/2,N/2,1)]:
        pts=[xy(stations[0],vc-w/2),xy(stations[0],vc+w/2)];contained=all(-B/2<=p[0]<=B/2 and 0<=p[1]<=H for p in pts)
        wh.append(dict(id=ident,width=w,thickness=t_eff,net_holes=nh,Ag=w*t_eff,An=(w-nh*dn)*t_eff,D=D,R_yield=w*t_eff*fyp/GA1,R_net=(w-nh*dn)*t_eff*fup/GA2,
          yield_utilization=D/(w*t_eff*fyp/GA1),net_utilization=D/((w-nh*dn)*t_eff*fup/GA2),endpoints=[z.tolist() for z in pts],contained=contained))
    # All force-normal sections: two holes, actual centroid. No invented stagger.
    normal=[]
    for uc in stations:
        _,pL=exit(xy(uc,0),[-S,C]);_,pR=exit(xy(uc,0),[S,-C]);vl,vr=uv(pL)[1],uv(pR)[1]
        ints=subtract((vl,vr),[(v-r,v+r) for v in rows]);A,cg,I=section(ints,tg)
        fixed=[h for h in holes if h['u']>uc];crossing=[h for h in holes if h['u']==uc]
        for mask in itertools.product([0,1],repeat=len(crossing)):
            ids=fixed+[h for h,on in zip(crossing,mask) if on];D=F*len(ids);M=F*sum(h['v']-cg for h in ids)
            sig=[D/A+M*(v-cg)/I for v in [vl,vr]]
            normal.append(dict(u=uc,active=[h['id'] for h in ids],parts=ints,An=A,cg=cg,I=I,N=D,M=M,sigma=sig,yield_utilization=max(map(abs,sig))/(fyp/GA1),rupture_utilization=max(map(abs,sig))/(fup/GA2)))
    normal_centers=normal
    # Continuous force-normal cuts: every hole cap, not just center stations.
    normal=[]
    def nc(uc,ids):
        _,pL=exit(xy(uc,0),[-S,C]);_,pR=exit(xy(uc,0),[S,-C]);vl,vr=uv(pL)[1],uv(pR)[1]
        cuts=[]
        for h in holes:
            hh=q(uc,h['u'])
            if hh>0:cuts.append((h['v']-hh,h['v']+hh))
        ints=subtract((vl,vr),cuts);A,cg,I=section(ints,tg);D=F*len(ids);M=F*sum(holes[i]['v']-cg for i in ids)
        sig=[D/A+M*(v-cg)/I for v in [vl,vr]]
        return dict(u=uc,active=[holes[i]['id'] for i in ids],parts=ints,An=A,cg=cg,I=I,N=D,M=M,sigma=sig,min_sigma=min(sig),max_sigma=max(map(abs,sig)),yield_utilization=max(map(abs,sig))/(fyp/GA1),rupture_utilization=max(map(abs,sig))/(fup/GA2))
    for a,bb in zip(bounds,bounds[1:]):
        mid=(a+bb)/2;fixed=[i for i,h in enumerate(holes) if h['u']-r>mid];crossing=[i for i,h in enumerate(holes) if abs(h['u']-mid)<r]
        for mask in itertools.product([0,1],repeat=len(crossing)):
            ids=fixed+[i for i,on in zip(crossing,mask) if on];vals=[nc(a,ids),nc(bb,ids)]
            for key,sign in [('min_sigma',1),('max_sigma',-1)]:
                for xa,xb in zip(np.linspace(a,bb,9),np.linspace(a,bb,9)[1:]):
                    z=minimize_scalar(lambda u:sign*nc(float(u),ids)[key],bounds=(xa,xb),method='bounded',options={'xatol':1e-10});vals.append(nc(float(z.x),ids))
            normal.extend([min(vals,key=lambda z:z['min_sigma']),max(vals,key=lambda z:z['max_sigma'])])
    # Every monotone two-row zigzag chain; actual free side caps and NBR s²/(4g).
    chains=[]
    for ul,ur in itertools.product(stations,repeat=2):
        dl,pl=exit(xy(ul,rows[0]),[-S,C]);dr,pr=exit(xy(ur,rows[1]),[S,-C])
        bg=dl+(rows[1]-rows[0])+dr;credit=(ur-ul)**2/(4*(rows[1]-rows[0]));bn=bg-2*dn+credit
        ids=[h['id'] for h in holes if h['u']>=([ul,ur][h['row']])];D=F*len(ids);R=bn*tg*fup/GA2
        chains.append(dict(u_left=ul,u_right=ur,gross_width=bg,hole_deduction=2*dn,stagger_credit=credit,net_width=bn,An=bn*tg,R=R,captured_ids=ids,D=D,actual_captured_utilization=D/R,conservative_full_N_utilization=N/R,path=[pl.tolist(),xy(ul,rows[0]).tolist(),xy(ur,rows[1]).tolist(),pr.tolist()]))
    # Tight finite occupied-leg bound: actual remaining holes AND actual captured force.
    # At each source-hole forward cap edge, k=n-j bolts are conservatively captured.
    # Gross/net shear branches are nonincreasing within each fixed-k interval.
    # Any unequal-start U sum is bounded because sum(min(Yj,Rj)) <= min(sumYj,sumRj).
    partial_bounds=[]
    for ri,v in enumerate(rows):
        endmin=min(exit(xy(0,vv),[C,S])[0] for vv in [v-r,v,v+r])
        for j,uj in enumerate(stations):
            start=uj+r;k=len(stations)-j;Lmin=endmin-start
            ded=sum(max(0.,min(endmin,uc+r)-max(start,uc-r)) for uc in stations)
            netmin=Lmin-ded
            if netmin<=0:
                partial_bounds.append(dict(row=ri,Lmin=Lmin,netmin=netmin,R=0.,demand=k*F,utilization=1e99));continue
            partial_bounds.append(block(Lmin*tg,netmin*tg,0.,fyp,fup,k*F,id='occupied_leg_actual_capture_bound',row=ri,end_min=endmin,start=start,k=k,Lmin=Lmin,netmin=netmin,footprint_v=[v-r,v+r],remaining_hole_deduction=ded))
    # Horizontal cut removes UNION of ALL circular chords and enumerates every crossing mask.
    def hs(y,active):
        chords=[]
        for h in holes:
            xh,yh=h['xy'];hh=math.sqrt(max(0,r*r-(y-yh)**2)) if abs(y-yh)<=r else 0
            if hh>0:chords.append((xh-hh,xh+hh))
        parts=subtract((-B/2,B/2),chords);A,cg,I=section(parts,tg)
        D=F*len(active);nr=D*S;vr=D*C;M=F*sum((holes[i]['xy'][0]-cg)*S-(holes[i]['xy'][1]-y)*C for i in active)
        sig=[nr/A+M*(x-cg)/I for x in [-B/2,B/2]];tau=1.5*abs(vr)/A;vm=math.sqrt(max(map(abs,sig))**2+3*tau*tau)
        return dict(y=y,active=[holes[i]['id'] for i in active],chords=chords,A=A,cg=cg,I=I,N=nr,V=vr,M=M,sigma=sig,sigma_min=min(sig),VM=vm,
            yield_utilization=vm/(fyp/GA1),rupture_utilization=max(max(map(abs,sig))/(fup/GA2),tau/(.6*fup/GA2)))
    hb=sorted(set([0.,H]+[h['xy'][1]+z for h in holes for z in [-r,0.,r]]));hres=[]
    for ya,yb in zip(hb,hb[1:]):
        ym=(ya+yb)/2;fixed=[i for i,h in enumerate(holes) if h['xy'][1]-r>ym];opt=[i for i,h in enumerate(holes) if abs(h['xy'][1]-ym)<r]
        for mask in itertools.product([0,1],repeat=len(opt)):
            active=fixed+[i for i,on in zip(opt,mask) if on]
            cand=[hs(ya,active),hs(yb,active)]
            for key,sign in [('sigma_min',1),('VM',-1),('rupture_utilization',-1)]:
                for a,bb in zip(np.linspace(ya,yb,9),np.linspace(ya,yb,9)[1:]):
                    z=minimize_scalar(lambda y:sign*hs(float(y),active)[key],bounds=(a,bb),method='bounded',options={'xatol':1e-9});cand.append(hs(float(z.x),active))
            hres.append(dict(interval=[ya,yb],crossing_ids=[holes[i]['id'] for i in opt],min_sigma=min(cand,key=lambda z:z['sigma_min']),max_VM=max(cand,key=lambda z:z['VM']),max_rupture=max(cand,key=lambda z:z['rupture_utilization'])))
    # Two-shear W-root formulas recomputed from total opposed-pair resultant.
    sr=5.;dw,bf,tf,tw,kw=317.,167.,13.2,7.6,21.2;fyw,fuw=345.,450.
    nr=N*S;vr=N*C;mr=N*(s0*S-n0*C)
    qn=[nr/B-6*mr/B**2,nr/B+6*mr/B**2];qs=vr/B;qe=[math.hypot(z,qs) for z in qn];qpeak=max(qe);qdesign=max(qpeak,1.25*sum(qe)/2)
    def contact(t,fy,fu):
        sn=max(map(abs,qn))/t;tt=abs(qs)/t;return max(math.sqrt(sn*sn+3*tt*tt)/(fy/GA1),sn/(fu/GA2),tt/(.6*fu/GA2))
    neq=nr+6*abs(mr)/B
    root=dict(N=nr,V=vr,M=mr,qn=qn,qs=qs,qpeak=qpeak,qdesign=qdesign,weld_u=qdesign/(math.sqrt(2)*sr)/(.6*fw/GA2),gusset_contact_u=contact(min(tg,2*sr),fyp,fup),W_contact_u=contact(2*sr,fyw,fuw),flange_punch_u=qpeak/(2*tf)/min(.6*fyw/GA1,.6*fuw/GA2),flange_width=tg+2*sr,flange_exempt=tg+2*sr<.15*bf,web_normal_u=neq/(1.10*(5*kw+B)*fyw*tw/GA1),web_longitudinal_u=abs(vr)/min(.6*B*tw*fyw/GA1,.6*B*tw*fuw/GA2),web_VM_u=math.sqrt((max(map(abs,qn))/tw)**2+3*(1.5*vr/(B*tw))**2)/(fyw/GA1),member_M=mr-dw*vr/2,transverse_shear_jump=nr)
    # Real unperforated load-path ligament, below the lowest physical hole.
    solid_end=min(h['xy'][1]-dh/2 for h in holes)
    solid_cuts=[]
    for yy in [0.,solid_end]:
        A=B*tg;I=tg*B**3/12;M=mr+yy*vr
        sig=[nr/A+M*xx/I for xx in [-B/2,B/2]];tau=1.5*abs(vr)/A
        solid_cuts.append(dict(y=yy,N=nr,V=vr,M=M,A=A,I=I,sigma=sig,min_sigma=min(sig),VM=(max(map(abs,sig))**2+3*tau*tau)**.5))
    solid_tension=min(z['min_sigma'] for z in solid_cuts)>=-1e-8
    Ct=max(1-ec/((n-1)*pitch),.5);Ab=math.pi*d*d/4;rp=.45*Ab*fub/GA2
    details=dict(holes_physical_count=2*n,shear_planes_per_bolt=1,row_v=rows,row_spacing=2*v0,h=tg,actual_heel_extent=12.35,heel_extent_source='additional manual fixture dimension, NOT Gerdau catalog data',tool_radius=18.,clearance=2.,tool_margin=g-12.35-20.,opposite_row_tool_clearance=2*v0-40.,physical_min_hole_center_distance=min(np.linalg.norm(np.array(a['xy'])-np.array(bb['xy'])) for i,a in enumerate(holes) for bb in holes[i+1:]),hole_min_edge=min(min(x+B/2,B/2-x,y,H-y) for x,y in [z['xy'] for z in holes]),nearest_free_edge_max=max(min(h['xy'][0]+B/2 for h in holes),min(B/2-h['xy'][0] for h in holes),min(H-h['xy'][1] for h in holes)),edge_limit=min(12*tg,150.),single_bolt_grip_without_washers=tg+ta,
      root_to_angle_min=min(xy(angle_end,v)[1] for v in [-tg/2-b,-tg/2,tg/2,tg/2+b])-sr,
      root_footprint_in_flange=tg+2*sr<=bf,assembly_source_verified=False)
    util=dict(angle_gross=N/(2*Ag*fy/GA1),angle_net=N/(2*Ct*(Ag-dn*ta)*fu/GA2),bolt_shear=F/rp,angle_contact=max(z['utilization'] for z in bearing if z['part']=='angle'),gusset_contact=max(z['utilization'] for z in bearing if z['part']=='gusset'),angle_block=max(z['utilization'] for z in angle_caps),gusset_block=max(z['utilization'] for z in caps),Whitmore_yield=max(z['yield_utilization'] for z in wh),Whitmore_net=max(z['net_utilization'] for z in wh),force_normal_net=max(max(z['yield_utilization'],z['rupture_utilization']) for z in normal),nominal_horizontal_yield=max(z['max_VM']['yield_utilization'] for z in hres),nominal_horizontal_rupture=max(z['max_rupture']['rupture_utilization'] for z in hres))
    util['gusset_unequal_partial_bound']=max(z['utilization'] for z in partial_bounds)
    util['gusset_zigzag_net']=max(z['conservative_full_N_utilization'] for z in chains)
    util.update({'root_'+k:v for k,v in root.items() if k.endswith('_u')})
    return dict(id=f'NEW_OPPOSED_BOLTED_{theta:g}_{N:g}',inputs=dict(theta=theta,N=N,plate=[B,H,tg],P=[s0,n0],angle=dict(id='GERDAU_EQUAL_ANGLE_P03_R29',b=b,t=ta,Ag=Ag,ec=ec),g=g,e=e,n_per_row=n,pitch=pitch,bolt_d=d,dh=dh,dn=dn,drilled=drilled,materials=dict(angle=[fy,fu],gusset=[fyp,fup],W=[fyw,fuw],bolt_fub=fub,weld_fw=fw)),holes=holes,details=details,angle=dict(Ct=Ct,Ag_pair=2*Ag,An_pair=2*(Ag-dn*ta),yield_R=2*Ag*fy/GA1,net_R=2*Ct*(Ag-dn*ta)*fu/GA2),bolt=dict(Ab=Ab,single_plane_R=rp,demand_per_physical_bolt=F,group_R=2*n*rp),bearing=bearing,
      gusset_center_witnesses=center,gusset_cap_envelope=caps,gusset_governing=max(caps,key=lambda z:z['utilization']),angle_cap_envelope=angle_caps,angle_governing=max(angle_caps,key=lambda z:z['utilization']),Whitmore=wh,force_normal_sections=normal,force_normal_center_witnesses=normal_centers,zigzag_net_chains=chains,unequal_partial_U_bounds=partial_bounds,horizontal_sections=hres,solid_root_ligament=dict(end=solid_end,cuts=solid_cuts,tensile=solid_tension),root=root,utilizations=util,strength_pass=max(util.values())<1,
      nominal_tension_domain=solid_tension,load_introduction_sign_diagnostic_nonnegative=min(min(z['min_sigma']['sigma_min'] for z in hres),min(min(z['sigma']) for z in normal))>=-1e-8,nominal_min_sigma=min(min(z['min_sigma']['sigma_min'] for z in hres),min(min(z['sigma']) for z in normal)),geometric_domain=all(z['contained'] for z in wh) and details['nearest_free_edge_max']<=details['edge_limit'] and details['hole_min_edge']>=22 and details['root_to_angle_min']>0 and details['tool_margin']>=0 and b-g>=22)

if __name__=='__main__':
    variants=[{},dict(theta=90),dict(theta=100),dict(N=300000),dict(drilled=False),dict(plate_fy=345,plate_fu=450),dict(B=300),dict(B=650),dict(tg=8.,N=220000.,theta=90.,B=280.,H=290.,n0=145.),dict(g=30.),dict(N=0.),dict(N=45000.),dict(N=150000.),dict(n=2),dict(n=5,B=400.,H=450.,n0=200.),dict(theta=50.),dict(B=240.)]
    ans=[]
    for j,kw in enumerate(variants):
        f=build(**kw);f['id']+=f'_CASE{j+1}';f['variant_inputs']=kw
        conventional={k:v for k,v in f['utilizations'].items() if k!='gusset_unequal_partial_bound'}
        f['status']=('INVALID_GEOMETRY_OR_DETAIL' if not f['geometric_domain'] else 'OUTSIDE_UNPERFORATED_LIGAMENT_TENSION_DOMAIN' if not f['nominal_tension_domain'] else 'CONVENTIONAL_OR_NOMINAL_CHECK_FAIL' if max(conventional.values())>1 else 'CONSERVATIVE_QUALIFICATION_ENVELOPE_FAIL' if not f['strength_pass'] else 'METHOD_PASS_GIVEN_DECLARED_DETAIL')
        ans.append(f)
        print(f['id'],max(f['utilizations'],key=f['utilizations'].get),max(f['utilizations'].values()),'normalmin',f['nominal_min_sigma'],'geom',f['geometric_domain'],flush=True)
    assert ans[0]['strength_pass'] and ans[0]['nominal_tension_domain'] and ans[0]['geometric_domain']
    assert math.isclose(ans[0]['root']['M'],-ans[2]['root']['M'],rel_tol=1e-12)
    assert math.isclose(max(ans[0]['utilizations'].values()),max(ans[2]['utilizations'].values()),rel_tol=1e-10)
    assert not ans[3]['strength_pass'] and not ans[6]['load_introduction_sign_diagnostic_nonnegative'] and ans[6]['nominal_tension_domain'] and not ans[7]['geometric_domain']
    assert ans[12]['strength_pass'] and ans[12]['utilizations']['angle_block']<1
    assert not ans[15]['nominal_tension_domain']
    assert ans[8]['utilizations']['Whitmore_yield']>1 and ans[8]['utilizations']['angle_block']<1
    assert not ans[9]['geometric_domain'] and ans[10]['inputs']['N']==0
    failures=[dict(target=k,N=ans[0]['inputs']['N']*1.01/u,scale=1.01/u,all_utilizations={name:val*1.01/u for name,val in ans[0]['utilizations'].items()}) for k,u in ans[0]['utilizations'].items() if u>0]
    sources={}
    for key,fn in [('NBR','baseplate_references/Automação MC/NBR 8800-24-25-projeto-de-estruturas-de-aco-e-de-estruturas-mistas-20250710-000231_compress.pdf'),('DG29','welded_gusset_scope/source/348443843-AISC-Design-Guide-29-Vertical-Bracing-Connections-pdf.pdf'),('Gerdau','gerdau_catalog_audit/Barras-e-Perfis-Tabela-de-bolso-Gerdau.pdf')]:sources[key]={'path':fn,'sha256':hashlib.sha256(Path(fn).read_bytes()).hexdigest()}
    data=dict(created='2026-10-11',sources=sources,same_geometry_failure_loads=failures,origin='New independent geometry and source calculations; no production imports; no old oracle reconstruction',fixtures=ans)
    (PTH/'NEW_OPPOSED_BOLTED_FIXTURES.json').write_text(json.dumps(data,indent=2,default=lambda value:value.item())+'\n')
