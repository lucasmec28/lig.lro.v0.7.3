# Opposed 2L bolted to one gusset: bounded complete-route qualification

11 October 2026. NEW qualification and independently computed examples only. No production code or immutable0.9.30 file was modified. This is a GO for a specified conventional calculation method and subsequent independent implementation testing, not permission to fabricate or approval of the complete structure.

## 1. Decision and finite domain

**GO for the opposed, direct-contact, static-tension arrangement described here**, provided the ordinary resistance/detail checks and the refined source-compatible finite envelopes pass. Revision2 removes an unnecessarily weakened partial-path bound and stops using an unproved introduction-zone stress-sign diagnostic as a code rejection. The earlier strict results are preserved in `SUPERSEDED_GUARD_DIAGNOSTICS.json` for audit only. The shared plate, two rows, all holes and each row's force location are recalculated. This is not the T engine with another sketch.

The domain is a rectangular gusset, one identical equal-leg L on each face, heel gap h=tg, opposite connected-leg directions, equal gauge, equal bolt number/pitch and longitudinal row stations, and compatible centered axial loading. The two rows are aligned longitudinally, not staggered. Theta is variable within0<theta<180 degrees, including90, with actual geometry, path, material and qualified unperforated-ligament tension checks at every input. There is no fixed80-degree or zero-root-moment restriction. N is total pair force, not force per angle.

Only ordinary static tension under normal ultimate combinations is included. Apply the existing NBR6.1.8.2 end-eccentricity idealization separately to each L, as in the already qualified single-angle bolted route. This projects each load transfer into the gusset plane; it does NOT prove cancellation of local face couples or a3D stress field. Keep actual distinct in-plane row positions. No fatigue, reversal, imposed spatial actions, unequal members/loading, fillers, stand-offs, free-standing angle prying, compression, direct W-web, two-edge corner gusset or global member expansion.

The first receiving member remains a rolled W exterior flange, root longitudinal and centered over its web, one equal continuous root fillet on each gusset face. Beam/column selection is a rigid local rotation. Carry all qualified conditional W local checks and both member-end effects; do not insert a second root or continuation into a corner frame.

The finite deliverable is complete. No further broad literature search or blanket FEA gate is required within this declared model. Implementation must still independently verify numerical search, topology, persistence, UI/drawings/reports, material separation and regressions before release.

## 2. Correct physical bolts and force positions

Use axes u along the brace, v transverse in the gusset plane, z normal to the plate; plate axes s along the root/W and n away from the flange. Let P0=(s0,n0) be on the middle pair axis. Transform:

s=s0+u cos(theta)+v sin(theta)
n=n0+u sin(theta)−v cos(theta).

The positive-face L has its heel atv=+tg/2, connected toe atv=+(tg/2+b), facez=+tg/2. The negative-face L is rotated180 degrees, with heel/toe/face of opposite sign. Each row is atv=±(tg/2+g), whereg is measured from its own outside heel towards its connected toe.

For n bolts per row, there are **2n physical bolts, each with ONE shear plane**, because the connected legs occupy disjoint in-plane intervals. Each physical bolt and gusset-hole wall receives N/(2n); each L receives N/2. Grip is tg+tL plus actual relevant hardware, not tg+2tL. Threads are evaluated in that one plane. Do not reuse n T through-bolts, a two-plane bolt resistance, or N/n at these distinct gusset holes.

The nominal row force line is the selected NBR6.1.8.2 angle-end model; shear lag still uses actual catalog ec for EACH L. The pair's actual centroid lies at the center by its defined symmetry, but the individual centroid-to-row and face eccentricities are not zero. In-plane first moments cancel only when all equal rows are summed: ΣvF=0. Partial cuts can retain only one row's force and must keep its v moment.

The root receives Nn=N sin(theta), Vs=N cos(theta), Mz=N(s0 sin(theta)−n0 cos(theta)). Root moment generally is nonzero. Moving P0 along the same middle force line leaves it invariant. The physical local face-to-midplane moment scale is (N/2)(tg/2) per face; opposite totals do not mean pointwise cancellation. That local end effect is expressly idealized under the static clause, while in-plane row moments and root transport remain.

Nreal0 is retained. The required45kN minimum is a separate WHOLE-connection case, divided after selection; the optional50% recommendation uses the actual pair resistance, also separately. No duplicated minimum, invented external brace moment or silent substitution of absolute force.

## 3. Ordinary NBR member, bolts, bearing and access checks

Retain NBR8800:2024/Errata1:2025 factors gamma_a1=1.10 and gamma_a2=gamma_w2=1.35. L, gusset, W, bolt and root electrode remain separate material records.

For each L: exact catalog Ag/ec/b/t, one actual hole per straight perpendicular section, An=Ag−dn*t, Ct=max(1−ec/Lc,0.5) for the equal-leg section partition, Ae=Ct An. Lc=(n−1)p. Check gross yield and effective rupture with N/2. Never replace catalog Ag with a sharp-corner approximation or set ec=0 from the pair centroid.

M16 standard physical hole is18mm. Net deductiondn=18mm for drilled holes; otherwise20mm under5.2.4.1(a). Keep physical18mm for contact, positions and ordinary hardware, even when using nominal20mm net circles/chords. Bolt per-plane resistance is .45Ab fub/gamma_a2 when threaded, .56 only when that plane actually excludes threads. Apply actual grip/long-grip effects, no friction credit.

Directional bearing: min(1.2 lc t fu,2.4 d t fu)/gamma_a2, deformation-limited branch. Angle forces point towards their free ends; plate forces point forward towards the actual row/free-boundary intersection. The two plate-row forward lengths differ at an oblique angle. Each hole receives N/(2n); evaluate each one, not only a summed group. Use actual materials/thicknesses, nearest holes/free edges and both directions.

Keep6.3.6–6.3.12/Table14/16 detail checks, minimum pitch2.7d and clear spacingd, relevant maximum pitch/exposure, edge minima, nearest-fastener maximum free-edge distances, hardware seats, angle overlap, free ends and root-weld interference. Each opposite-face nut/head must fit the bare gusset side without hitting the other L. Distinct row spacing must be checked, not assumed from a sketch.

As before, the Gerdau table supplies Ag/ec and nominalb/t but no heel radius. No new guessed catalog field or attestation checkbox is warranted. The complete reference declares a separate manual heel-exclusion dimension for tool access. The actual detail must supply that dimensional envelope through the existing bolt-detail input mechanism. A catalog label alone does not verify tool clearance.

## 4. One perforated plate: net paths and local introduction

The common plate has TWO holes at an aligned force-normal station. Deduct both, preserve the true net centroid/inertia, and sum forces at their own row coordinates. Do not add two independent full-thickness plate approvals.

Also enumerate all monotone two-row NBR5.2.4.1(b–c) zigzag chains. Aligned rows do not make different-station chains irrelevant when the plate sides are oblique to the brace. For a chain through(uL,vL),(uR,vR), with actual transverse side exits:

bn=lleft+(vR−vL)+lright−2dn+(uR−uL)^2/[4(vR−vL)].

Record gross geometry, hole deductions, stagger credit, captured forward-bolt subset and its demand. The new reference additionally applies totalN as a conservative net-chain capacity screen. Forn rows' longitudinal stations there aren² two-row chains; do not use a chain rule with transverse spacingg=0 to subtract multiple longitudinal holes from one ordinary section.

Aggregate Whitmore width is row separation+2Lc tan30degrees at the rootward last transfer station. Clip it to the actual plate; all endpoints must remain within connected material. For the principal case the whole segment fits. Check gross yield and a disclosed supplemental net-Whitmore rupture screen using two deductions.

To avoid giving both rows the same material twice where individual spreading strips overlap, add explicit per-row screens using width2Lc tan30degrees and allocated thickness tg/2, each underN/2 with its own centered row. Each deducts its one hole. These are conservative supplemental in-plane allocations, not a DG29-prescribed formula or a physical3D stress solution. The allocated thicknesses total tg; aggregate plate area is never doubled.

## 5. Complete ordinary block families and hole-cap extrema

NBR6.5.6 uses R=min(.6fu Anv+Cts fu Ant, .6fy Agv+Cts fu Ant)/gamma_a2. Use conservativeCts=.5 for this qualification. Both branches use gamma_a2. Each angle has its own free-end/toe and developed opposite-toe paths withN/2; the heel is not a free edge. The catalog-area complement remains a nominal far-toe path, not a recovered rolled contour.

For the gusset, explicitly retain:
- each outer L path: one row's shear line and outward transverse cap, capturing that row's actual suffix;
- each inward L path: shear line through one row, transverse cap crossing the OTHER row and ending on the far free side; it can capture BOTH rows and must carry their combined force;
- U paths between the two row shear lines, with both actual forward exits and a connecting transverse segment;
- partial captured groups in each of those families, plus the unequal-row/offset U bound below.

Each candidate records actual coordinates, cap station, gross/net areas, free exits, included/excluded crossing-hole sets and demand. A positive supported-root segment inside the detached region makes the candidate inactive; a corner point alone is not a supported segment. Force capture is based on actual holes, not a family name.

Hole-cap lesson: center/end/corner witnesses are insufficient. Let q=sqrt(r²−(u−uj)²) be the HALF chord at an intersected hole, r=dn/2. For aligned row caps, a single-row outward L deducts q from its transverse length; an inward L deducts q+2q=3q; the central U deducts q+q=2q. Longitudinal net shear removes the actual clipped intervals of every hole along each shear leg. The gross-yield and net-rupture branches can have separate interior extrema. Compute these on every hole/corner topology interval, retain both branches and all one-sided capture limits. Do the same for each angle's free-end caps. Do not transplant the old one-row critical offset to these new chord multipliers.

The fixture uses independently bracketed scalar searches over continuous intervals, including endpoints; it is a reproducible numerical qualification, not certified interval arithmetic or a microscopic crack-field proof. The implementation may solve stationary equations analytically or use a independently bounded numerical approach, but cannot return to center-only sampling.

### Unequal-row partial U and narrow/offset blocks: refined finite closure

A join between unequal start stations need not receive an invented diagonal-tension resistance. For each occupied row, consider straight +u shear legs within that row's nominal hole footprint [vrow−dn/2,vrow+dn/2]. Let E be the earliest actual forward free exit over that interval. At EACH cap stationu, use:

Av,min=tg(E−u)
Anv,min=tg[(E−u)−sum length(intersection([u,E],[uj−dn/2,uj+dn/2]))]
Ant=0; D=k(u)N/(2n), with k(u) countinguj+dn/2>=u in the upper capture limit.

The row-center full-hole intervals conservatively contain any smaller hole intersections on an offset shear leg, and E is no later than its actual exit. Deducting these actual remaining intervals gives lower net/gross shear areas; discarding joining tension is conservative. Crucially, the remaining holes and captured demand refer to the SAME cap position. It is unnecessary and misleading to combine the latest cap with ALL past holes and the fullN/2.

For each constant-k interval, gross/net resistances are affine and nonincreasing (net resistance is constant while crossing a hole). Thus evaluate the finite upper cap boundariesu=uj+dn/2 with k=n−j, together with any actual topology/free-boundary transition. Compare each row's actual captured force with its lower resistance. For unequal row starts:

sum min(Yj,Rj) <= min(sum Yj,sum Rj).

Therefore each row passing its occupied-leg bound also bounds the U with both distinct shear legs and any nonnegative joining resistance. This is not summing alternative L capacities. For a one-row narrow U, crediting only one necessary shear leg is likewise conservative. The argument covers the stated ordinary straight-leg footprint family, not arbitrary curved cracks.

Principal negative/positive row maxima are .196108418 and .180106108, far below the old .760856764 guard. The old guard was needlessly weakened by incompatible simultaneous assumptions; it is withdrawn as an acceptance condition. If the refined bound fails, label it failure of this conservative method envelope, not proven physical block collapse. No blanket FEA requirement follows.

## 6. Both continuous section directions and the root

For horizontal and brace-normal cuts, subtract the UNION of ALL intercepted nominal hole chords. Their vertical projections may overlap even though the physical holes are far apart. Keep every simultaneous crossing-hole force mask, including one-row-only limits. Compute actual A, first moment, I and discrete N/V/M about that net centroid.

Use the previously disclosed nominal sigma=N/A+M(x−xc)/I and supplemental shear1.5|V|/A calculations, with their limitations. They are not exact stresses near a hole or an exact hole-split shear distribution. Their conservative material-strength screens remain identified as supplemental. Retain hole-edge/center/corner and interior extrema in BOTH section directions; center-only brace-normal cuts miss a boundary minimum at ulast+r.

**The SIGN of this hypothetical field in the perforated load-introduction zone is informative only.** NBR does not prescribe that field or require it to stay wholly tensile at every artificial all-mask cut. A small or large negative value is not itself an actual compressive force, an established instability demand, or permission to assert physical buckling. Do not enlarge gussets solely to eliminate this diagnostic or call it a NBR failure. Introduction is qualified by actual bolts/bearing, net and zigzag sections, continuous block paths/refined partial-U bounds, aggregate Whitmore and the explicit per-row allocated-thickness screens. This follows the conventional DG29 route, which does not require an exact microscopic contact field.

**The unperforated ligament remains a real model-domain restriction:** from the root to the lowest PHYSICAL hole boundary, all discrete bolt loads remain on the far side and the actual resultantN/V/M is defined. Test the ordinary full-width section at the root and that boundary; the unloaded ligament moment varies linearly, so endpoints bound its normal-stress extremes. Compressed normal resultants in this ligament or root remain outside the first tension-only method and require the corresponding local stability/compression route. That genuine restriction is not waived. Root/W effects, deformation/detail restrictions and all ordinary resistance checks also remain.

This deliberately distinguishes the physical load path and its conventional code model from an unproved contact-zone stress visualization. It does not approve global brace/W stability or allow externally applied compression/spatial action.

The root/W calculations are the already qualified equations, freshly fed by total current N/V/M. Two root fillets, one plate thickness; qn=Nn/B±6M/B², qs=Vs/B; weld demand=max(peak,1.25 endpoint-average), with that1.25 identified as DG29 supplemental. Keep correct contact normal/shear envelopes on gusset and W, qpeak-based flange punching, actual flange-bending footprint/exemption, web local yielding including tension, longitudinal shear/interaction, both W ends and action transport. Root application point and member-centroid export remain explicit. Global concurrent W actions are separate and cannot be presumed zero.

## 7. New complete reference and independent results

`calculate_opposed_reference.py` imports no production module and uses no production result as expected data. `NEW_OPPOSED_BOLTED_FIXTURES.json` holds all forces, holes, continuous cap/section candidates, nine zigzag paths for the3+3 case, occupied-leg bounds, local plate screens, root/W values and signed/failure/detail variants. `SUPERSEDED_GUARD_DIAGNOSTICS.json` explicitly marks old overconservative rejection values as withdrawn audit evidence, never regression targets. Source hashes are embedded.

Principal geometry:
- Gerdau p3R29 L76.2×76.2×6.35, Ag929mm² and ec21.3mm per L; Lsteel250/400MPa
- gusset340×300×12.5mm, independently250/400MPa; h=tg12.5; g40; rowsv=±46.25
- three M16 per row, SIX physical single-shear bolts; standard18mm drilled holes; p50; u=−50,0,50; both L free endsu=−85
- P0=(0,150), theta80degrees, Ntotal100kN
- root two5mm E60/fw415 fillets over340mm; W310×165×52 Arcelor d317,bf167,tf13.2,tw7.6,k21.2, steel345/450, ends±1000
- independent manual heel exclusion12.35mm, tool radius18+clearance2; gauge40 gives7.65mm tool margin.12.35 is NOT Gerdau manufacturer data. Root-to-angle minimum clearance46.974049mm; other-row tool clearance52.5mm; physical minimum bolt spacing50mm; nearest-free-edge maximum115.770233mm<150mm

Hole coordinates(s,n)mm:
negative-v row: (−54.229767,108.790841),(−45.547359,158.031228),(−36.864950,207.271616).
positive-v row: (36.864950,92.728384),(45.547359,141.968772),(54.229767,191.209159).
Their vertical projected offset16.062456mm is less than the18mm hole diameter; simultaneous horizontal caps MUST be handled, despite92.5mm actual row separation.

Main results:
- each physical bolt force16.666667kN; one-plane resistance55.627134kN; pair member gross422.272727kN and effective-net379.951941kN; Ct.787
- each angle's continuous-cap block governs at u44.6, R118.721481kN versus50kN, utilization.421153774. The center-only witness gives a different higher resistance
- ordinary gusset block governing inward L at u−48.30960949, R630.405170kN versus100kN, utilization.158628141; it contains BOTH rows and uses3q transverse deduction
- refined unequal/offset occupied-row bounds:254.961008kN and277.614128kN versus50kN per row at the critical actual cap; maximum.196108418. The angle cap at.421153774 now governs the principal example
- aggregate Whitmore width207.970054mm, yield590.824017kN, supplemental net636.926125kN; per-row half-depth screen governs local yield at.304840942
- weakest two-hole zigzag chain at uleft−50/uright0 (also0/50): An3839.818197mm²; net capacity1137.723910kN. This is25.7449mm² smaller than an aligned-station chain, so do not skip zigzag just because rows are aligned
- continuous loaded nominal minima: horizontal+.088543MPa; brace-normal+.059570MPa at u59 with one crossing-row force. These introduction-zone signs are diagnostic; zero-resultant regions legitimately give zero. Root/unperforated-ligament checks are separately recorded and remain tensile
- rootN98.480775kN,V17.364818kN,M−2.604723kNm; root weld utilization.328090137, contact gusset.190940001, Wweb normal.123520598, local Wscreen.186724071; footprint22.5mm<25.05mm flange-bending exemption limit
- W-centroid exported moment−5.357046kNm; transverse member-shear jump98.480775kN

At100degrees V/M reverse and row/side paths mirror with the same governing utilization.90degrees is regular, not the only approved inclination. The340mm width is an oracle dimension, not a hidden universal minimum.

## 8. Honest failure and boundary cases

The file distinguishes normative checks, model restrictions, supplemental envelopes and diagnostics:
- same340/80 geometry at150kN PASSES after the finite refinement: angle-cap utilization.631730661; refined partial-U bound.294162627. It was rejected only by the withdrawn weakened guard
- same at300kN fails conventional angle-cap resistance1.263461322, preserving a real failure witness
- nondrilled dn20 with physical18mm holes at100kN PASSES; refined occupied-row bound.197373183. The withdrawn1.004661670 value is audit evidence only
- B300, same80degree loading, PASSES the conventional route and refined envelopes. Its introduction-zone nominal diagnostic retains brace-normal−.507075MPa and horizontal−.499891MPa. The real unperforated ligament/root remain tensile; the diagnostic is not mislabeled as physical compression
- a narrowerB240 variant tests practical geometry with fully contained Whitmore strips and current root/W checks, rather than forcing every project to the wider benchmark
- theta50 provides a genuine root/unperforated-ligament compression-domain rejection; it is distinct from the harmless diagnostic witness
- B650 fails maximum free-edge distance, even though lower stresses might look attractive
- gauge30 fails the stated actual tool-access envelope; do not repair it by inventing a smaller manufacturer's radius
- independent plate steel345/450 changes plate checks only, not L/bolt capacity
- a thinner8mm, perpendicular280×290 plate example at220kN (P0=(0,145)) fails the supplemental common per-row Whitmore yield screen1.047890739 while angle resistance remains below1; its geometry is valid
- Nreal0 and the separate45kN case preserve total-force semantics
- additional2+2 and5+5 bolt variants exercise changed connection length, repeated interior cap intervals, net chains and counted physical bolts

Classification for implementation:
1. Normative resistances/detailing: NBR member gross/effective net resistance, bolt shear and directional contact, prescribed hole/edge/grip/detail rules, ordinary block shear on the actual named paths, weld metal/base metal and conditional receiving-W local modes.
2. Explicit conventional/supplemental models: DG29 Whitmore/load-path modeling with separately identified NBR factors, net-Whitmore/per-row half-thickness screens, refined zero-transverse partial-U envelope, conservative material-stress screens and elastic root moment/weld supplement. A failure is labeled with that exact model, not invented as a numbered NBR rule.
3. Domain: actual static tension/direct contact/equal loading/defined rows; unperforated-ligament and root wholly tensile under the adopted local section model; geometry/material/receiving-interface restrictions. Real compressed root/body regions are still unqualified.
4. Informative diagnostic: all-mask normal-stress SIGN inside the perforated introduction region. Preserve negative witnesses and explanations; it cannot independently setglobal_pass false.

Concurrent failure-load references scale every demand together. A single-check target value is not falsely presented as another fully approved connection.

## 9. Inputs, reuse and release obligations

Keep existing catalogs/materials and ordinary detail inputs; do not add guessed manufacturer data. Derive h=tg and row locations±(tg/2+g). For this first branch rows share n,p,stations and angle free-end geometry; asymmetric/staggered rows require a separate qualification. Accept n>=2 with the actual counted/path checks and positive finite dimensions, rather than freezing the three-bolt benchmark.

Reuse scalar material/bolt/root/W primitives only where their contracts match. Recompute geometry, every hole, net chains, force masks, partial blocks and plate/root resultants. A T physical bolt has two planes, whereas an opposed bolt has one: no shared-bolt boolean that merely changes the drawing. Do not reuse a previous global_pass or compose two independent full-thickness gussets. Native family identity, drawings and report must expose2n single-shear bolts, actual row gauge/separation, partial paths and the nominal end-eccentricity assumption.

Implementation acceptance must reproduce new independent numbers and declared rejects, including all cap minima; both signed inclinations;90 regularity; changingn/p/g/tg and root position; clipping/free-side changes and root-attached inactive blocks; simultaneous chords/masks; two-row zigzag enumeration; real tool/edge/grip boundaries; each independent material; drilled/nondrilled policy; minimum45 exactly once; current-input recomputation and exact topology through serialization/drawings/reports. Preserve0.9.30 unchanged until an authorized new-version implementation.

## 10. Sources and evidence

- Supplied NBR8800:2024 + Errata1:2025: PDF61–64/printed39–42,§5.2 tension/net/stagger/shear lag; PDF93/71,§6.1.8.2 static angle exception; PDF106–107/84–85 bolt shear/contact; PDF112–114/90–92 holes/grip/pitch/edges; PDF116–118/94–96 connection elements/eccentricity/block shear andFig16; PDF85–86/63–64 exteriorW local checks; PDF97,100,102–103/75,78,80–81 welds; factorsPDF47/25.
- Supplied DG29(2014): Ex5.4/Fig5-10 PDF106/98; PDF107–112/99–104 angle/bolts/gusset conventional checks; PDF113–116/105–108 nonzero interface moment/root/W. This establishes the one-root conventional route, not a published terminal drawing of the opposed pair. General one-root§4.2.4 PDF40–41/32–33; interface/local transferPDF62–67/54–59 and204–212/196–204.
- Actual supplied Gerdau pocket catalogPDF2 nominal/tolerances; PDF3R29 b76.2,t6.35,Ag9.29cm²,ec2.13cm; no rolled heel radius.
- Actual confirmed opposed image and original supplied M-009/M-010/t/M-011/t pages77–79 establish the section arrangement; those original details are bar interconnectors, not a fabricated terminal qualification.
- Qualified static end-idealization rationale: `opposed_angle_gusset_scope/eccentricity_review/REVIEW.md`; previous one-row contract: `bolted_gusset_scope/CONTRACT.md`. Reused sources/assumptions are distinguished from newly calculated opposed geometry.
-0.9.30's `review0930/independent_engine_acceptance/BOLTED_CAP_FIX_REVIEW.json` was read solely as an implementation lesson about missed cap extrema. No production resistance or result was used as this packet's oracle.
- Primary W catalog remains https://constructalia.arcelormittal.com/files/W--0487915bad55d18fbfc679cd87133c88.pdf , PDF3/printed157; audited original dimensions317/167/7.6/13.2/r8, not merged with another manufacturer's geometry.

Final independent signoff is `reviewer/INDEPENDENT_METHOD_VERDICT.md`; the refined receipt `reviewer/AUTHOR_REFINED_CROSSCHECK.json` has736/736 passing comparisons. `reviewer/INITIAL_SUPERSEDED_METHOD_VERDICT.md` and `SUPERSEDED_GUARD_DIAGNOSTICS.json` retain the withdrawn conservative restrictions as audit evidence only. Independent review and recomputation are in `reviewer/`. They supplement, rather than replace, the original references. No historical missing bolt-bearing oracle was recovered or imitated.
