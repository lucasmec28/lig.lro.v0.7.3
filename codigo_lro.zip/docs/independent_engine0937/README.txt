INDEPENDENT ENGINE REVIEW EVIDENCE, 0.9.37

Scope: held engine source review only. This is not the full application aggregate, UI/drawing review, release packaging, or actual SRC1 approval. SRC1 remains FAIL eta1.079466667 plus real restraints UNVERIFIED.

Counts and units:
-13 independent test groups, not13 individual assertions.
-177 deterministic random feasible geometry cases:137 all-compression,40 mixed-sign. Ten zero-path cases are a subset of137, not extra cases.
-Six intentional in-memory mechanical mutants detected, with no production file mutation.
-Seven nonnegative/zero preset selected result objects compared byte-for-byte against frozen0936.
-288 held runtime/test file hashes verified; this count is source identity verification, not tests executed by this reviewer.
The application full aggregate remains separate and is not claimed here.

Contents:
review_engine.py computes scalar expectations independently before importing the reviewed code; independent_scalar_values.json retains those expectations. FIXTURE_INPUT.json is the supplied qualification input, not resistance lookup data. RESULTS.json/run.log preserve the final pass. REVIEW.txt and FINAL_SEAL.json record held engine acceptance. DISCOVERED_FIX_RECORD.json documents the resolved zero-path defect. The exact frozen positive output, authentic negative native fixture, probe script and comparison receipt preserve regression evidence. HELD_RUNTIME_TEST_HASHES.json is the exact owner-held manifest. BASELINE_RUNTIME_IDENTITY.json pins the external immutable0936 runtime/data against its original frozen manifest.

Replay from this workspace:
PYTHONDONTWRITEBYTECODE=1 REVIEW_SOURCE_ROOT=/workspace/scratch/200bd23c4a9b/review0937/source0937 python review_engine.py
PYTHONDONTWRITEBYTECODE=1 python legacy_probe.py /workspace/scratch/200bd23c4a9b/review0937/source0937 > replay_candidate_positive.json
cmp frozen0936_positive_outputs.json replay_candidate_positive.json

The first command runs from this evidence directory and rewrites RESULTS.json and independent_scalar_values.json here. It does not write to production or frozen source. It requires the actual held0937 runtime source and Python dependencies; those are not bundled. For another location, set REVIEW_SOURCE_ROOT accordingly. For safety retain this sealed directory unchanged and replay from a separate writable copy.

External baseline limitation:
The preserved exact baseline output supports candidate regression comparison without executing0936. Regenerating the baseline itself requires /workspace/scratch/200bd23c4a9b/review0936/source0936 and its dependencies, matching BASELINE_RUNTIME_IDENTITY.json. No replacement or guessed baseline is included. An authentic0936 negative native fixture is retained for migration tests.

Source-scope acceptance is conditional on exact held hashes. Synthetic boundary declarations exist only inside formula tests and establish no actual brace, root or receiver restraint.
