import sys,json
from dataclasses import replace
sys.path.insert(0,sys.argv[1])
from lro import welded_double_angle_gusset as m
cases={name:c for name,c in m.presets().items() if c.N>=0}
kept=['status','global_pass','local_pass','checks','cases','geometry','root','sections','paths','member_actions','summary']
out={name:{k:r[k] for k in kept} for name,c in cases.items() for r in [m.evaluate(c)]}
print(json.dumps(out,sort_keys=True,allow_nan=False))
