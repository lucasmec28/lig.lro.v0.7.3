"""Independent one-root arithmetic/guards: no expected scalar from production output.
Writes only beside this script. PYTHONDONTWRITEBYTECODE=1 recommended.
"""
import os,sys,json,math,hashlib,random,copy,traceback
from pathlib import Path
from dataclasses import replace,fields
HERE=Path(__file__).resolve().parent
SRC=Path(os.environ.get('REVIEW_SOURCE_ROOT',str(HERE.parents[1]/'source0937')))
FIX=json.loads((HERE/'FIXTURE_INPUT.json').read_text())
# Constants and original data are supplied qualification inputs, not production outputs.
E=200000.;ga=1.1;gr=1.35
W=dict(d=317.,bf=167.,tw=7.6,tf=13.2,k=21.2)
A=dict(b=100.,t=12.,Ag=2270.,ec=29.,toe=6.)

def curve(area,t,Le,fy=250.):
    I=area*t*t/12;ne=math.pi**2*E*I/(Le*Le)
    lam2=area*fy/ne;chi=.658**lam2 if lam2<=2.25 else .877/lam2
    return dict(Ne=ne,lambda0=math.sqrt(lam2),chi=chi,r=t/math.sqrt(12),Le_over_r=Le*math.sqrt(12)/t,resistance=chi*area*fy/ga)

def oracle(c):
    B,H,t,L=c.plate_width,c.plate_height,c.plate_t,c.weld_length
    C,S=math.cos(math.radians(c.theta_deg)),math.sin(math.radians(c.theta_deg));u=-L/2;v0=A['ec']-A['b']/2
    # Affine strip clipping at the actual station/root. Generic interval intersection.
    lo,hi=-A['b']/2-L/math.sqrt(3),A['b']/2+L/math.sqrt(3)
    def restrict(x0,k,low,high):
        nonlocal lo,hi
        if k==0:
            if not low<=x0<=high:raise ValueError('empty')
        else:
            q=sorted(((low-x0)/k,(high-x0)/k));lo=max(lo,q[0]);hi=min(hi,q[1])
    restrict(c.center_s+u*C,S,-B/2,B/2)
    restrict(c.center_n+u*S,-C,0,H)
    # Intersect root x(v) determined by solving y=0 along the brace-parallel ray.
    restrict(c.center_s-c.center_n*C/S,1/S,-B/2,B/2)
    a=min(v0-lo,hi-v0)
    if a<=0:raise ValueError('empty centered strip')
    vs=[v0-a,v0+a];xy=[[c.center_s+u*C+v*S,c.center_n+u*S-v*C] for v in vs]
    ls=[p[1]/S for p in xy]
    positive_paths=min(ls)>1e-10*max(1.,B,H,L)
    bw=2*a;Le=1.2*max(ls)
    xp,yp=c.center_s+v0*S,c.center_n-v0*C
    Nr,Vr,Mr=c.N*S,c.N*C,c.N*(xp*S-yp*C)
    q=[Nr/B-6*Mr/B**2,Nr/B+6*Mr/B**2];qs=Vr/B
    qvec=[math.hypot(x,qs) for x in q];qd=max(max(qvec),1.25*sum(qvec)/2)
    Neq=-B*min(q)
    local=[c.N/(c.introduction_width*t)+s*6*c.N*v0/(c.introduction_width**2*t) for s in [-1,1]]
    # Remaining resultants above horizontal cut by direct line integration.
    lines=[]
    for v,f in [(-50,.71),(50,.29)]:
        x0,y0=c.center_s-L/2*C+v*S,c.center_n-L/2*S-v*C
        x1,y1=c.center_s+L/2*C+v*S,c.center_n+L/2*S-v*C
        lines.append((x0,y0,x1,y1,f))
    def cut(y):
        ny=vx=m=0.
        for x0,y0,x1,y1,f in lines:
            start=max(y0,min(y,y1));fraction=(y1-start)/(y1-y0)
            ym=(start+y1)/2;xm=x0+(ym-y0)*C/S;force=c.N*f*fraction
            ny+=force*S;vx+=force*C;m+=force*(xm*S-(ym-y)*C)
        return ny,vx,m
    bounds=sorted(set([0,H]+[z for l in lines for z in (l[1],l[3])]))
    normals=[];vm=[]
    for left,right in zip(bounds[:-1],bounds[1:]):
        h=right-left;vals=[]
        for sign in [-1,1]:
            def stress(z):
                n,v,m=cut(z);return n/(B*t)+sign*6*m/(B*B*t)
            f0,fm,f1=stress(left),stress((left+right)/2),stress(right)
            aa=2*(f1+f0-2*fm)/(h*h);bb=(f1-f0-aa*h*h)/h
            vals += [f0,f1]
            if aa and 0<-bb/(2*aa)<h:vals.append(stress(left-bb/(2*aa)))
        shear=1.5*max(abs(cut(y)[1]) for y in (left,right))/(B*t)
        vm.append(math.sqrt(max(abs(v) for v in vals)**2+3*shear*shear));normals+=vals
    end=min(c.support_end_left,c.support_end_right)-B/2
    wy=1.1*345*W['tw']*((2.5 if end<=W['d'] else 5)*W['k']+B)/ga
    wc=cripple(B,end)
    return dict(positive_paths=positive_paths,width=bw,retained_v=vs,root_projections=[p[0]-p[1]*C/S for p in xy],Lmax=max(ls),Le=Le,
                **curve(bw*t,t,Le),N=Nr,V=Vr,M=Mr,q=q,qs=qs,Neq=Neq,weld_stress=qd/(math.sqrt(2)*c.root_weld_leg),
                local=local,max_body=max(normals),yield_demand=max(max(vm),max(abs(x) for x in local)),yield_eta=max(max(vm),max(abs(x) for x in local))/(250/ga),
                W_web_normal=wy,W_web_crippling=wc,M_member=Mr-W['d']/2*Vr)

def cripple(B,end):
    interior=end>=W['d']/2;ratio=B/W['d'];term=3*ratio if interior or ratio<=.2 else 4*ratio-.2
    return (.66 if interior else .33)*W['tw']**2*(1+term*(W['tw']/W['tf'])**1.5)*math.sqrt(E*345*W['tf']/W['tw'])/ga

def sway(length,rotation):
    h=W['d']-2*W['k'];ratio=h*W['bf']/(W['tw']*length);threshold=2.3 if rotation=='restrained' else 1.7
    excluded=length<(h/W['tw'])*W['bf']/threshold
    return dict(ratio=ratio,status='NOT_APPLICABLE_RATIO' if excluded else 'CALCULATED',resistance=None if excluded else 16*E*W['tw']**3*W['tf']/(ga*h*h)*((.94 if rotation=='restrained' else 0)+.37*ratio**3))

# Only now import implementation under review; expected functions above do not call it.
sys.path.insert(0,str(SRC))
from lro import welded_double_angle_gusset as m
from lro import one_root_compression as oc
from lro import corner_compression as cc
results=[];failures=[]
def run(name,fn):
    try:fn();results.append(dict(name=name,status='PASS'))
    except Exception as e:failures.append(dict(name=name,error=repr(e),traceback=traceback.format_exc()));results.append(dict(name=name,status='FAIL',error=repr(e)))
def close(a,b,label='',rel=2e-11,abs_tol=2e-8):
    assert math.isclose(a,b,rel_tol=rel,abs_tol=abs_tol),(label,a,b)
def row(r,id,case='actual'):
    return next(x for x in r['checks'] if x['id']==case+'__'+id)
def issue(r,id):return any(x['id']==id for x in r['issues'])
c=replace(m.WeldedDoubleAngleGusset(),N=-200000.)
expected=oracle(c)
(HERE/'independent_scalar_values.json').write_text(json.dumps(dict(note='Calculated independently from supplied inputs; not a native approval.',SRC1=expected,sidesway_hypothetical={str(L)+rot:sway(L,rot) for L in [2000.,4000.,8000.] for rot in ['free','restrained']}),indent=2))
def baseline():
    r=m.evaluate(c)
    assert r['status']=='CHECKS_FAIL_AND_UNVERIFIED';assert not r['local_pass'];assert not r['global_member_verified']
    assert row(r,'gusset_yield')['status']=='FAIL';close(row(r,'gusset_yield')['utilization'],expected['yield_eta'])
    close(expected['yield_eta'],1.0794666666666668)
    for k in ['N','V','M']:close(r['root'][k],expected[k],k)
    for k in ['width','Lmax','Le','Ne','lambda0','chi','resistance','Le_over_r']:close(r['compression']['strip'][k],expected[k],k)
    for a,b in zip(r['compression']['strip']['root_projections'],expected['root_projections']):close(a,b)
    close(row(r,'W_web_normal')['resistance'],expected['W_web_normal']);close(row(r,'W_web_crippling')['resistance'],expected['W_web_crippling'])
    close(row(r,'root_weld')['demand'],expected['weld_stress'])
    close(r['member_actions']['introduced_moment_about_member_centroid'],expected['M_member'])
    assert len(r['geometry']['weld_lines'])==4
    assert not r['paths']
    for x in r['checks']:assert x['mechanism'] not in ['tension','block_tearout','normal_rupture']
    close(sum(f['heel_N']+f['toe_N'] for f in r['cases'][0]['angle_forces']),c.N)
    assert len([x for x in r['checks'] if x['mechanism']=='weld_heel'])==2
    assert len([x for x in r['checks'] if x['mechanism']=='weld_toe'])==2
    close(row(r,'angle_weld_heel_face_positive')['demand'],71000.)
    close(row(r,'angle_weld_toe_face_negative')['demand'],29000.)
    close(row(r,'gusset_shear_transfer')['resistance'],.6*250*200*10/1.35)
    close(row(r,'angle_shear_transfer_face_positive')['resistance'],.6*275*200*6/1.35)
    for id in ['compression_root_boundary','compression_brace_boundary','compression_receiver_evidence','compression_receiver_span','compression_receiver_rotation','compression_receiver_interaction']:assert issue(r,id)
    assert r['compression']['receiver_sidesway']['status']=='UNVERIFIED'
run('SRC1 signed equilibrium, preserved failure and unverified boundaries',baseline)

# These declarations are formula-only synthetic fixtures and never native approvals.
def hypot(base=c,relative='absent',length=4000,rotation='free'):
    return oc.bind_current_evidence(replace(base,compression_root_rotation='confirmed',compression_root_source='HYPOTHETICAL formula fixture root R-1',compression_brace_rotation='confirmed',compression_brace_source='HYPOTHETICAL formula fixture brace B-2',compression_receiver_relative=relative,compression_receiver_source='HYPOTHETICAL formula fixture receiver W-3',compression_unbraced_length=length,compression_flange_rotation=rotation,compression_receiver_interaction='isolated',compression_interaction_source='HYPOTHETICAL local action inventory I-4'))

def boundary_tests():
    h=hypot();r=m.evaluate(h)
    assert not r['summary']['unverified_ids'];assert r['status']=='COMPLETE_CHECKS_FAIL'
    assert row(r,'W_web_sidesway')['status']=='FAIL';close(row(r,'W_web_sidesway')['resistance'],sway(4000,'free')['resistance'])
    for role in ['root','brace']:
        for change in [{f'compression_{role}_rotation':'unknown'},{f'compression_{role}_rotation':'absent'},{f'compression_{role}_source':''},{f'compression_{role}_stamp':''}]:
            rr=m.evaluate(replace(h,**change));assert issue(rr,f'compression_{role}_boundary');assert not rr['local_pass']
    for change in [dict(compression_receiver_source=''),dict(compression_receiver_stamp='')]:
        rr=m.evaluate(replace(h,**change));assert issue(rr,'compression_receiver_evidence')
    rr=m.evaluate(replace(h,compression_unbraced_length=2000));assert issue(rr,'compression_receiver_evidence')
    rr=m.evaluate(replace(h,compression_flange_rotation='restrained'));assert issue(rr,'compression_receiver_evidence')
    rr=m.evaluate(replace(h,compression_receiver_interaction='interactive'));assert issue(rr,'compression_receiver_interaction')
    rr=m.evaluate(replace(h,compression_interaction_source=''));assert issue(rr,'compression_receiver_interaction')
    for key,value in [('plate_width',402.),('plate_height',305.),('plate_t',11.),('theta_deg',76.),('center_s',1.),('center_n',151.),('weld_length',201.),('end_margin',21.),('angle_weld_leg',5.1),('root_weld_leg',5.1),('support_end_left',1001.)]:
        rr=m.evaluate(replace(h,**{key:value}))
        for role in ['root','brace']:assert issue(rr,'compression_'+role+'_boundary'),key
        assert issue(rr,'compression_receiver_evidence'),key
    rr=m.evaluate(replace(h,N=-100000.,project='Label change',notes='No geometry change'))
    assert not rr['summary']['unverified_ids']
    rr=m.evaluate(hypot(relative='confirmed',length=0,rotation='unknown'))
    assert rr['compression']['receiver_sidesway']['status']=='NOT_APPLICABLE_REAL_RELATIVE_RESTRAINT';assert not rr['summary']['unverified_ids']
    rr=m.evaluate(replace(hypot(relative='confirmed',length=0,rotation='unknown'),compression_root_rotation='unknown'))
    assert issue(rr,'compression_root_boundary')
run('Separate real-boundary gates and stale evidence mutation',boundary_tests)

def receiver_tests():
    for end in [0.,W['d']/2-1e-9,W['d']/2,W['d']/2+1e-9,W['d']-1e-9,W['d'],W['d']+1e-9,800.]:
        for B in [W['d']*.2-1e-9,W['d']*.2,W['d']*.2+1e-9,400.]:
            close(oc.crippling(W,345,B,end)['resistance'],cripple(B,end))
            assert oc.crippling(W,345,B,end)['interior']==(end>=W['d']/2)
    for end in [0.,W['d']-1e-8,W['d'],W['d']+1e-8]:
        r=m.evaluate(replace(c,support_end_left=200+end))
        close(row(r,'W_web_normal')['resistance'],1.1*345*7.6*((2.5 if end<=317 else 5)*21.2+400)/1.1)
    for rot in ['free','restrained']:
        threshold=(W['d']-2*W['k'])/W['tw']*W['bf']/(1.7 if rot=='free' else 2.3)
        for length in [2000,4000,8000,math.nextafter(threshold,0),threshold,math.nextafter(threshold,math.inf)]:
            a,b=oc.sidesway(W,length,rot),sway(length,rot)
            assert a['status']==b['status'],(rot,length,a,b)
            if a['resistance'] is not None:close(a['resistance'],b['resistance'])
        assert oc.sidesway(W,threshold,rot)['status']=='CALCULATED'
    for length,rot in [(0,'free'),(2000,'unknown')]:assert oc.sidesway(W,length,rot)['status']=='UNVERIFIED'
run('NBR5.7.3/.4/.5 end, loaded length and strict ratio boundaries',receiver_tests)

def curve_tests():
    # lambda=1.5 assembled independently from Ne=Af/2.25.
    for lam in [.01,.25,1.5-1e-10,1.5,1.5+1e-10,3,10]:
        Le=lam*math.pi*10/math.sqrt(12)*math.sqrt(E/250)
        actual=cc.reduction(E,250,3000,10,Le,ga);exp=curve(3000,10,Le)
        for k in exp:close(actual[k],exp[k],k)
    Le=25*10/math.sqrt(12);assert cc.reduction(E,250,3000,10,Le,ga)['chi']<1
run('NBR chi transition and full curve below25',curve_tests)

def signed_cases():
    for load,expected_loads in [(-1,[-1.,-45000.]),(-44999.9,[-44999.9,-45000.]),(-45000,[-45000.]),(-45000.1,[-45000.1]),(0,[0.,45000.]),(1,[1.,45000.])]:
        r=m.evaluate(replace(c,N=load));assert [x['N'] for x in r['cases']]==expected_loads
        for case in r['cases']:assert case['N_per_angle']==case['N']/2
        if load<0:
            assert all(x['mechanism']!='tension' for x in r['checks'])
            assert all(f['N']<=0 for x in r['cases'] for f in x['angle_forces'])
    r=m.evaluate(replace(c,N=-10000,minimum_force=False));assert r['status']=='OUTSIDE_SCOPE';assert not r['checks']
    r=m.evaluate(replace(c,recommend_half_capacity=True));assert issue(r,'compression_recommended_half');assert not any(x['id']=='recommended_half' for x in r['cases'])
run('Signed actual/minimum forces and no compression Ct reuse',signed_cases)

def geometry_cases():
    rng=random.Random(937)
    count=0;all_comp=0;mixed=0;zero_violations=[];zero_count=0
    for n in range(180):
        cn=rng.uniform(125,170);L=rng.uniform(130,200);theta=rng.uniform(60,120);cs=rng.uniform(-40,40)
        candidate=replace(c,N=-rng.uniform(45000,250000),theta_deg=theta,center_s=cs,center_n=cn,weld_length=L,plate_height=350,root_weld_leg=5)
        r=m.evaluate(candidate)
        if r['status'] in ('INVALID_GEOMETRY','DETAILING_FAIL'):continue
        exp=oracle(candidate);tol=1e-10*max(1.,-candidate.N/(candidate.plate_width*candidate.plate_t))
        direct=max(exp['max_body'],max(exp['local']))<=tol and max(exp['q'])<=tol*candidate.plate_t
        assert bool(r['cases'][0]['compression_domain']['all_normal_nonpositive'])==direct,(candidate,r['status'],exp)
        for k in ['N','V','M']:close(r['root'][k],exp[k])
        if direct:
            all_comp+=1
            if exp['positive_paths']:
                for k in ['width','Lmax','Le','Ne','lambda0','chi','resistance']:close(r['compression']['strip'][k],exp[k],k)
            else:
                zero_count+=1
                if not issue(r,'actual_compression_strip'):zero_violations.append(dict(theta=candidate.theta_deg,center_s=candidate.center_s,center_n=candidate.center_n,L=candidate.weld_length))
            close(row(r,'gusset_yield')['demand'],exp['yield_demand'])
            if r['compression'].get('strip'):
                for x in r['compression']['strip']['root_projections']:assert abs(x)<=candidate.plate_width/2+1e-8
        else:
            mixed+=1;assert r['status']=='OUTSIDE_SCOPE';assert not r['checks'];assert issue(r,'actual_compression_mixed_sign')
        count+=1
    assert count>=100 and all_comp>20 and mixed>20,(count,all_comp,mixed)
    results.append(dict(name='Random geometry counts',tested=count,compression=all_comp,mixed=mixed,zero_paths=zero_count,zero_path_guard_violations=zero_violations))
    assert not zero_violations,('Mathematically zero paths must be unverified',zero_violations)
run('Independent geometry/body extrema including theta>90 and mixed sign',geometry_cases)

def mixed_boundary():
    # Root qright=0 when force line xroot=-B/6; change center_s through this exact boundary.
    C,S=math.cos(math.radians(75)),math.sin(math.radians(75));cs=-400/6+150*C/S+21/S
    for shift in [-1e-6,0,1e-6]:
        cand=replace(c,center_s=cs+shift);r=m.evaluate(cand)
        if shift<0:assert issue(r,'actual_compression_mixed_sign')
        else:assert not issue(r,'actual_compression_mixed_sign')
    for bad in [replace(c,weld_length=0),replace(c,plate_width=0),replace(c,theta_deg=0),replace(c,theta_deg=180)]:assert not m.evaluate(bad)['local_pass']
run('All-compression/mixed-sign exact root edge and degenerate lengths',mixed_boundary)

def native_inputs():
    h=hypot();obj=h.to_dict();assert m.WeldedDoubleAngleGusset.from_dict(obj)==h
    legacy=json.loads((HERE/'legacy0936_negative_native.json').read_text())
    assert legacy['component_version']==m.LEGACY_COMPONENT_VERSION
    old=m.WeldedDoubleAngleGusset.from_dict(legacy)
    assert old.compression_root_rotation==old.compression_brace_rotation==old.compression_receiver_relative=='unknown'
    assert not m.evaluate(old)['local_pass']
    for field in ['N','plate_width','theta_deg','compression_unbraced_length']:
        for val in [float('nan'),float('inf'),-float('inf'),True,None,'4000']:
            invalid=replace(c,**{field:val});r=m.evaluate(invalid)
            assert r['status']=='INVALID_INPUT',(field,val,r['status'])
            try:invalid.to_dict();assert False
            except ValueError:pass
    for field in ['compression_root_rotation','compression_root_source','compression_root_stamp','compression_brace_source','compression_receiver_relative','compression_receiver_source','compression_flange_rotation']:
        r=m.evaluate(replace(c,**{field:None}));assert r['status']=='INVALID_INPUT'
    for mutation in ['missing','extra','unknown_version','corrupt_units','corrupt_assumptions','hybrid_legacy']:
        bad=copy.deepcopy(obj)
        if mutation=='missing':del bad['connection']['compression_root_source']
        if mutation=='extra':bad['connection']['imaginary_K']=.7
        if mutation=='unknown_version':bad['component_version']='0.9.99'
        if mutation=='corrupt_units':bad['units']['force']='kN'
        if mutation=='corrupt_assumptions':bad['fixed_assumptions']['gusset_count']=2
        if mutation=='hybrid_legacy':bad['component_version']=m.LEGACY_COMPONENT_VERSION
        try:m.WeldedDoubleAngleGusset.from_dict(bad);assert False,mutation
        except ValueError:pass
run('Strict native roundtrip/legacy unknowns and non-finite/type inputs',native_inputs)

def zero_strip_and_service():
    zero=replace(c,N=-110548.12621580549,theta_deg=115.10025097687452,center_s=18.52104161821078,center_n=148.0391803747295,weld_length=197.86115931658208,plate_height=350.)
    r=m.evaluate(hypot(zero))
    assert issue(r,'actual_compression_strip'),('zero-path accepted',r['status'],r.get('compression',{}).get('strip'))
    assert not r['local_pass']
    tall=replace(c,N=-50000.,theta_deg=90.,center_n=800.,plate_height=1000.)
    r=m.evaluate(hypot(tall,relative='confirmed',length=0,rotation='unknown'))
    assert issue(r,'actual_compression_service');assert not r['local_pass'];assert row(r,'gusset_one_root_buckling')['resistance']>0
run('Zero-length clipped endpoint and conservative service domain',zero_strip_and_service)

def near_zero_geometry():
    theta=105.;S=math.sin(math.radians(theta));C=math.cos(math.radians(theta));L=200.
    rawlo=-50-L/math.sqrt(3)
    touch=L*S/2+rawlo*C
    for delta in [-1e-5,-1e-7,0.,1e-9,1e-8,1e-7,1e-5]:
        cand=replace(c,N=-60000.,theta_deg=theta,center_n=touch+delta)
        r=m.evaluate(hypot(cand,relative='confirmed',length=0,rotation='unknown'))
        assert r['status'] not in ['INVALID_GEOMETRY','OUTSIDE_SCOPE'],(delta,r['status'])
        if delta<=1e-8:assert issue(r,'actual_compression_strip'),delta
        else:
            assert not issue(r,'actual_compression_strip'),delta
            close(min(r['compression']['strip']['three_lengths']),delta/S,abs_tol=1e-12)
    # Isolated arithmetic helper threshold: c dimensions determine epsilon=4e-8.
    for delta in [-1e-8,0,1e-8,4e-8,8e-8]:
        cand=replace(c,theta_deg=90.,center_n=100.+delta)
        g={'direction':[0.,1.],'angle_section':{'leg':100.,'centroid':29.}}
        try:res=oc.whitmore(cand,g,250.)
        except ValueError:assert cand.center_n-100<=4e-8
        else:assert cand.center_n-100>4e-8
run('Neighboring zero/short/positive strip endpoints',near_zero_geometry)

def mutation_sensitivity():
    import inspect
    witnesses=[]
    def inject(name,module,attribute,replacement,test):
        original=getattr(module,attribute);setattr(module,attribute,replacement)
        detected=False
        try:test()
        except (AssertionError,StopIteration,TypeError,KeyError):detected=True
        finally:setattr(module,attribute,original)
        assert detected,('mutation not detected',name)
        witnesses.append(name)
    reduction_original=oc.reduction
    def resistance_doubled(*args,**kwargs):
        r=reduction_original(*args,**kwargs);r['resistance']*=2;return r
    inject('Doubled Whitmore resistance',oc,'reduction',resistance_doubled,baseline)
    wm_original=oc.whitmore
    def uncut_width(*args,**kwargs):
        r=wm_original(*args,**kwargs);r['width']=r['raw_v'][1]-r['raw_v'][0];return r
    inject('Borrowed raw uncut Whitmore width',oc,'whitmore',uncut_width,baseline)
    calculate_original=oc.calculate_case
    def half_common(c,g,N,*args,**kwargs):return calculate_original(c,g,N/2,*args,**kwargs)
    inject('N/2 incorrectly sent to common gusset and root',oc,'calculate_case',half_common,baseline)
    root_original=oc.base.root_actions
    def absolute_force(N,*args,**kwargs):return root_original(abs(N),*args,**kwargs)
    inject('Unsigned root equilibrium',oc.base,'root_actions',absolute_force,baseline)
    sidesway_original=oc.sidesway
    def exempt_equality(W,length,rotation):
        r=sidesway_original(W,length,rotation)
        threshold=(W['d']-2*W['k'])/W['tw']*W['bf']/(2.3 if rotation=='restrained' else 1.7)
        if length==threshold:r.update(status='NOT_APPLICABLE_RATIO',resistance=None)
        return r
    inject('Non-strict sidesway ratio exemption at equality',oc,'sidesway',exempt_equality,receiver_tests)
    source=inspect.getsource(oc.whitmore).replace('min(lengths)<=length_tolerance','min(lengths)<=0')
    context=dict(vars(oc));exec(compile(source,'<review-only-mutant>','exec'),context)
    inject('Removed scale-aware zero-path guard',oc,'whitmore',context['whitmore'],zero_strip_and_service)
    results.append(dict(name='Mutation witnesses',detected=witnesses))
run('Independent tests detect six consequential mutations',mutation_sensitivity)

def placeholder_and_inactive_tests():
    for source in ['', ' ', 'Não informado', ' NÃO INFORMADO ', 'unknown', 'UNKNOWN', 'none', ' None ', '-']:
        for role in ['root','brace','receiver']:
            candidate=replace(hypot(),**{'compression_'+role+'_source':source})
            # Matching forged stamp cannot replace an identified source.
            candidate=replace(candidate,**{'compression_'+role+'_stamp':oc.geometry_stamp(candidate,role)})
            r=m.evaluate(candidate)
            id='compression_receiver_evidence' if role=='receiver' else 'compression_'+role+'_boundary'
            assert issue(r,id),(source,role)
            assert not r['local_pass']
        candidate=oc.bind_current_evidence(replace(hypot(),compression_interaction_source=source))
        assert issue(m.evaluate(candidate),'compression_receiver_interaction'),source
    r=m.evaluate(c)
    assert r['sections']['local']['Ct'] is None
    assert 'INATIVO' in r['sections']['local']['Ct_basis']
    assert all(case['plate_sections']['local']['Ct'] is None for case in m.evaluate(replace(c,N=-1))['cases'])
    positive=m.evaluate(replace(c,N=200000.))
    assert isinstance(positive['sections']['local']['Ct'],float)
run('Placeholder evidence cannot qualify; tension Ct inactive in compression',placeholder_and_inactive_tests)

def semantic_native_checks():
    compression=c.to_dict()
    assert compression['fixed_assumptions']['rupture_envelope']=='compression_uniform_run_shear_only_Ant0_no_tensile_Ct'
    assert compression['fixed_assumptions']['compression_model']==oc.MODEL
    assert 'no_normal_tensile_rupture' in compression['fixed_assumptions']['root_contact_model']
    restored=m.WeldedDoubleAngleGusset.from_dict(json.loads((HERE/'legacy0936_negative_native.json').read_text()))
    assert restored.N==-200000.
    assert restored.compression_root_rotation==restored.compression_brace_rotation==restored.compression_receiver_relative=='unknown'
    assert restored.to_dict()['fixed_assumptions']==compression['fixed_assumptions']
    assert m.evaluate(restored)['status']=='CHECKS_FAIL_AND_UNVERIFIED'
    for original in [c,replace(c,N=200000.),replace(c,N=0.)]:
        stale=original.to_dict();stale['connection']['N']=200000. if original.N<0 else -200000.
        try:m.WeldedDoubleAngleGusset.from_dict(stale);assert False,'stale native method accepted'
        except ValueError:pass
run('Compression semantic native premises and genuine0936 migration',semantic_native_checks)

report=dict(source_hashes={str(p.relative_to(SRC)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [SRC/'lro/one_root_compression.py',SRC/'lro/welded_double_angle_gusset.py',SRC/'lro/welded_angle_gusset.py',SRC/'lro/corner_compression.py']},results=results,failures=failures)
(HERE/'RESULTS.json').write_text(json.dumps(report,indent=2,allow_nan=False))
for result in results:print(result)
print('FAILURES:',len(failures))
for x in failures:print(x['traceback'])
sys.exit(bool(failures))
