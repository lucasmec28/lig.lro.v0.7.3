# Aços independentes na end plate 4ES/8ES · 0.9.25

## Escopo finito

A seleção de material é própria de cada componente: viga, coluna, chapa de topo e par de nervuras. As duas nervuras do detalhe simétrico continuam iguais entre si. Na rota CJP qualificada desta revisão, cada aço da viga/chapa/nervuras pode ser ASTM A36, ASTM A572 Gr.42 ou ASTM A572 Gr.50, sujeito ao catálogo de produtos e espessuras. A coluna conserva sua seleção já independente. Outros aços permanecem selecionáveis quando compatíveis com o produto, mas fora desta qualificação CJP finita, explicitamente sinalizada; isso não constitui proibição normativa universal.

Preservam-se 4ES tabela 5-11 e coluna tabela A-2, 8ES tabela 5-16 e coluna tabela A-5(a), chapa e coluna espessas, coluna contínua não enrijecida, ações estáticas no plano, casos Entrada e Mínimo de força separados. Não há mudança no kernel, número/participação dos parafusos, braços, furos, blocos, força de mesa, regiões disjuntas de solda, hipóteses externas ou domínio de aplicação. Não se adicionam soluções de chapa fina, alavanca, filetes nas nervuras, compressão de gusset, punção, extensão enrijecida ao cisalhamento ou sismo.

## Fontes consultadas

- AISC Design Guide 39, edição 2023 fornecida, §3.7.4, p.43, eq.3-36: ts ≥ tw Fyb/Fys. A relação admite propriedades distintas de viga e nervura.
- DG39 §3.7.5, p.45: a solda nervura–chapa deve desenvolver o escoamento da nervura à tração; a junta nervura–mesa deve desenvolver o escoamento ao cisalhamento.
- DG39 §4.1.3, p.50: registra chapas A36 ensaiadas com vigas e colunas Grade 50, e alerta para falhas locais com vigas significativamente mais resistentes. Diferença entre materiais não equivale a falha nem a aprovação.
- DG39 exemplo 5.3-7, pp.184–185: mantém as exclusões e o desenvolvimento das nervuras da 8ES, admitindo a alternativa CJP. Equações de plastificação permanecem nas tabelas já qualificadas, pp.114,119,264,269–270.
- ABNT NBR 8800:2024, versão corrigida 2025, §6.2.5.1, p.76: área efetiva de metal-base igual ao comprimento conectado vezes a menor espessura conectada; fy igual ao menor dos dois metais-base.
- NBR tabela 8, p.77, nota a: grupos diferentes são admitidos. Consumível compatível com o grupo de menor resistência exige baixo hidrogênio; preaquecimento conforme grupo de maior resistência. A rota E7018 é tabelada para A36 e A572 Gr.42/Gr.50.
- NBR tabela 9, p.78: para CJP compatível, tração AMB fy/γa1 e cisalhamento 0,60 AMB fy/γa1, controlados pelo metal-base.
- Souza, documento fornecido, §§8.3.6–8.3.9, páginas PDF109–112, complementa preparação/garganta da junta. A referência histórica à NBR2008 não substitui a tabela 9 atual.

As páginas NBR acima correspondem às páginas PDF98–100 do exemplar fornecido. A fonte DG39 consultada continua sendo 2023. A errata oficial de novembro/2024 não foi recuperada integralmente (acesso403); não se declara sua revisão.

## Propriedades e interfaces

Mantêm-se γa1=1,10 e γa2=1,35, em N, mm e MPa.

1. Espessura da nervura: ts,req = tw fyb/fys.
2. Desenvolvimento de cálculo: qT,dev = fys ts/γa1; qV,dev = 0,60 fys ts/γa1.
3. CJP nervura–chapa: qT,Rd = min(fys;fyp) min(ts;tp)/γa1.
4. CJP nervura–mesa: qV,Rd = 0,60 min(fys;fyb) min(ts;tf)/γa1.
5. Ambas as comparações qdev≤qRd devem atender antes de qualificar o mecanismo de plastificação da chapa e os parafusos sem alavanca. Aplicar M menor não dispensa desenvolvimento integral.
6. Comprimentos reais continuam hst−recorte e Lst−recorte. Demanda e capacidade totais são os valores por comprimento multiplicados pelo mesmo trecho real.

O produto dos mínimos de fy e espessura é a definição normativa adotada, não uma aproximação a substituir por min(fy·t) dos receptores. A hierarquia ts≤min(tp;tf) é uma consequência necessária do desenvolvimento integral, mantida como evidência geométrica na mesma linha existente. A comparação exata de espessuras é feita também antes dos produtos de ponto flutuante, pois uma insuficiência de uma ULP pode arredondar para capacidades iguais. Não é nova resistência ou tolerância.

A chapa usa fyp/fup em plastificação, rigidez, contato, seção e blocos. Viga usa fyb em escoamento local, mínimos de desenvolvimento e compacidade. Coluna usa fyc nas suas verificações. As juntas viga–chapa conservam min(fyb;fyp) e a menor espessura física; a escolha de chapa A36 pode fazer uma dessas juntas falhar mesmo com a espessura de plastificação atendida.

A condição sem furos fu/γa2≥fy/γa1 é agora conferida separadamente em viga/chapa/nervuras. Razões: A36 1,303703703704; Gr.42 1,166028097063; Gr.50 1,062801932367. Não se cria uma linha redundante de ruptura nesses três materiais; um material fora da rota ou condição não satisfeita impede a qualificação.

A declaração existente de compatibilidade CJP abrange consumível/processo/preparação, baixo hidrogênio e preaquecimento do grupo de maior resistência. Não há nova caixa de confirmação ou aprovação automática de WPS. A comparação isolada fw≥fu não constitui regra geral de compatibilidade.

## Testemunhas independentes

O arquivo tests/fixtures/independent_plate_steels0925.json contém nove vetores calculados diretamente das equações sem importar o motor. Grandezas esperadas referem-se ao caso Entrada, não à envoltória.

- 4ES W410×46,1/W310×97, ambos Gr.50; chapa A36 160×19,05; nervuras A36 ts10: ts,req9,66; tp,req7,201533011346; qT2272,727272727273; qV1363,636363636364 N/mm. CJP da mesa da viga: η0,9108.
- 8ES W460×74/W360×122, ambos Gr.50; chapa A36 210×15,875; nervuras A36 ts12,7: ts,req12,42; tp,req9,293211552736; qT2886,363636363636; qV1731,818181818182 N/mm. CJP da mesa: η0,9108.
- Ambas também passam com chapa Gr.42 e nervuras A36, comprovando três materiais distintos.
- 4ES com nervura A36 ts9,525 falha contra ts,req9,66; ts12,7 falha no desenvolvimento à mesa com η1,133928571429.
- 8ES com chapa A36 tp12,7 e nervura A36 ts12,7 passa a espessura de plastificação, mas falha na CJP da mesa da viga com η1,039889763780.
- Nervura Gr.50 contra chapa A36, mesmo mais espessa, falha no desenvolvimento à tração com η1,38. A geometria e a escolha são preservadas, sem troca automática de material.

## Identidade e conservação

Nenhum campo de entrada ou esquema JSON foi acrescentado. Seletores existentes permanecem independentes e importações continuam atômicas. Alteração real de qualquer material invalida Word anterior; APIs avulsas recalculam a entrada atual e não aceitam snapshot adulterado como autorização. Word e desenhos identificam os materiais dos quatro componentes.

Revisões: endplate-4es-independent-steels-0925-v1 e endplate-8es-independent-steels-0925-v1. Identidade de entrada SHA-256 não muda para o mesmo conjunto de entradas. 4E/rotulada mantêm suas revisões. Os resultados numéricos de casos antigos com materiais iguais devem permanecer idênticos, embora textos, revisão de método e desenho de materiais 4ES/8ES sejam atualizados.

A validação executada, limitações e regressões estão em VALIDATION0925.md. Não se afirma suíte completa nem certificação de projeto/fabricação.
