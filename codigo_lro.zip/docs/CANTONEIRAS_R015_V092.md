# R015 / LCSP: duas cantoneiras soldadas à viga e parafusadas ao pilar

Versão 0.9.2-angle-dev · 9 de outubro de 2026.

## Resultado e alcance

A nova família é nativa e independente da R016: dois grupos reais de solda em U na alma da viga, duas abas de apoio com parafusos em corte simples, projetos JSON, três vistas proporcionais e memória Word editável. Não existem parafusos nem furos na interface da alma. As resistências das interfaces sucessivas não são somadas.

O domínio convencional é um par igual e simétrico, viga e pilar W laminados, apoio na mesa do pilar, viga sem recortes, cortante vertical estático de cálculo com sinal, N=M=T externos iguais a zero, uma coluna vertical de parafusos por aba. O momento geométrico nos grupos de solda é calculado mesmo quando M externo é zero.

A avaliação local não substitui o dimensionamento global, flambagem dos membros, análise do pórtico, estabilidade lateral, integridade estrutural por amarração, especificação/qualificação da soldagem e liberação de fabricação. Não calcula rigidez rotacional nem curva momento–rotação. O modelo usual flexível tem base documental e não exige genericamente análise por elementos finitos.

## Geometria efetiva

Eixo x: face do apoio em x=0, positivo para dentro da viga. Eixo y do grupo: topo da cantoneira em y=0, positivo para baixo. A elevação do desenho adiciona angle_top. Os três segmentos de cada U são:

1. Superior: (weld_start,0) → (beam_leg,0)
2. Vertical externo: (beam_leg,0) → (beam_leg,length)
3. Inferior: (beam_leg,length) → (weld_start,length)

O início real da solda é independente da folga da viga. A folha industrial não fornece todos esses extremos; o programa exige geometria explícita e não supõe automaticamente que o comprimento horizontal efetivo seja b−folga. As pernas do U ficam na aba junto à alma. Não há solda na aba saliente do apoio nem fechamento do talão. Retornos nessa outra aba mudariam a topologia e não são creditados.

As cantoneiras convencionais documentadas são L76×76×6,4 com gabarito de apoio45mm e L102×102×8 com gabarito65mm. Esses valores definem a cobertura verificada atual, sem criar máximos/mínimos normativos universais. Outras geometrias fisicamente válidas recebem cálculos locais e a pendência precisa de modelo da aba de apoio. Colisão física, não atendimento de detalhamento e diferença de preset são estados separados.

## Grupo excêntrico: integração analítica

Para cada segmento de comprimento li e centro ci:

- Lw=Σli
- centroide=(Σli·ci)/Lw
- Jlinha=Σ[li·distância(ci,centroide)²+li³/12], em mm³
- F=Vd/2 por cantoneira, aplicado na linha do apoio x=0
- Mgrupo=−x̄F
- qx=−Mgrupo(y−ȳ)/Jlinha
- qy=F/Lw+Mgrupo(x−x̄)/Jlinha
- q=√(qx²+qy²), em N/mm

A distribuição é afim em cada segmento; q² é convexa. Seu máximo é obtido exatamente em um dos extremos, sem discretização por malha. O resultado guarda cada vetor, centroide, inércia e resíduos de equilíbrio. Integração numérica independente conferiu força resultante e momento nulo em torno da linha do apoio.

Garganta a=w/√2; resistência linear do metal de solda=0,60 fuw a/γw2. Adota-se γw2=1,35 para combinações últimas normais, E7018 com fuw485MPa, sem ganho direcional, penetração adicional ou coeficiente ICR. O Gerdau2018 usa ICR; suas resistências históricas não são metas de igualdade deste modelo elástico atual.

## Metal-base e flexão no plano

A Tabela9 da NBR remete o metal-base de filetes à seção6.5. O programa não transplanta a linha de solda de penetração para filetes.

Junto à solda, a comparação conservadora por unidade de comprimento usa:

- Ruptura local: |q|≤0,60 fu t/γa2
- Limite elástico conservador: |q|≤fy t/(√3 γa1)

O segundo limite decorre de √(qn²+3qt²)≤√3·|q|. Trata-se de um suplemento racional conservador, e não de uma fórmula textual do Gerdau nem solução completa das tensões através da espessura. A comparação local de ruptura para o U de cantoneiras encontra apoio na discussão específica da AISC “Keeping Fillet”, julho2016, Figura3.

As duas soldas opostas atuam na mesma alma. O motor soma as duas demandas e usa a espessura única tw; equivalentemente, cada grupo só poderia receber tw/2. Não duplica a capacidade do metal-base da viga.

Além disso, a aba soldada é verificada à interação elástica de flexão e corte no plano, a partir do campo real de solda. Para F=Vd/2, s=weld_start, u=x−s, qa=F/Lw+Mgrupo(s−x̄)/J, k=Mgrupo/J:

- Antes da solda, Vcorte=F e Mcorte=F·x
- Nos ramos horizontais, Vcorte=F−2qa·u−k·u²
- Mcorte=F·x−qa·u²−k·u³/3+Mgrupo·L²·u/(2J)

O último termo é o binário das forças horizontais opostas no topo e base do U. São avaliados extremos e raízes das derivadas: V é quadrático, M é cúbico. O envelope conservador usa σ=6Mmax/(tL²), τ=1,5Vmax/(tL) e √(σ²+3τ²)≤fy/γa1. As máximas podem ocorrer em cortes diferentes: combiná-las é uma limitação deliberadamente conservadora, sem crédito plástico.

As duas abas de cada cantoneira têm seções de cisalhamento próprias. Na aba soldada Ag=An=L·t; os furos da aba de apoio não são descontados dela. A alma contínua também não perde furos inexistentes. Há cisalhamento bruto/líquido e instabilidade da alma da viga. Não se inventa bloco L com uma borda livre horizontal onde a viga não tem recorte.

## Parafusos e apoio

Cada parafuso do apoio tem um plano de corte. Usa-se 0,45 com rosca ou0,56 sem rosca no plano, fub830MPa para A325 e1040MPa para A490, γa2=1,35, com redução de pega quando pertinente. Diâmetros métricos e imperiais são mantidos distintos.

O contato verifica a soma normativa e a compatibilidade individual dos furos com a partilha direta. A aba da cantoneira e a mesa do pilar têm materiais, espessuras e bordas próprios. São calculados todos os prefixos de blocos L físicos até a borda lateral e a extremidade real, com Cts1 na aba e0,5 conservador na mesa do pilar. A junção mesa–alma não é borda livre destacável.

V positivo para baixo: a aba de apoio recebe força para cima dos parafusos e usa sua borda superior; o pilar recebe força para baixo e usa sua extremidade inferior real. V negativo inverte esses caminhos. V=0 aciona a conferência mínima de45kN uma vez no conjunto e ambos os sentidos estáticos; não é análise de fadiga.

A reação e o momento de transporte da face da mesa ao centro do pilar são entregues ao dimensionamento global. O momento não deve ser somado novamente se o modelo global já contém a excentricidade.

## Detalhamento atual

- Comprimento efetivo é o comprimento uniforme real, incluindo os trechos efetivos. Não se subtrai2w automaticamente.
- Tabela11: perna mínima pela peça mais fina. Até6,3mm→3mm; até12,5→5; até19→6; acima19→8. A rota declara filetes em passe único e exige procedimento de execução qualificado.
- 6.2.6.2.2: máximo na borda é t abaixo6,3mm; senão t−1,5mm. A exceção exige borda explicitamente reforçada no desenho/procedimento para assegurar a garganta. A opção correspondente imprime essa especificação; não majora a resistência da garganta.
- Não arredondar4,9 para5mm: L6,4 com filete5 é falha de detalhamento sem essa especificação. O exemplo histórico Gerdau não autoriza sozinho a exceção.
- A rota de perna integral adota comprimento ≥ max(4w, 40 mm). Segmentos menores ficam pendentes por alternativa não implementada: NBR6.2.6.2.3 permite limitar a perna considerada a 25% do comprimento. Não é proibição normativa universal e não se reduz a perna silenciosamente. Atualização0.9.16: ver WELDED_DOUBLE_ANGLES_AUDIT0916_METHOD.md.
- Sobreposição física b−folga≥máx(5·espessura mais fina,25mm), NBR6.2.6.2.5.
- A rota verificada limita cada comprimento a100w. Acima disso há pendência específica da aplicação coerente da redução/modelo da solda longa conforme6.2.2.2(d), e não declaração de impossibilidade física ou máximo normativo universal.
- A regra de retornos4w em6.2.6.2.6(c) não é imposta indevidamente aos ramos resistentes superiores/inferiores do U; diz respeito aos retornos que restringem a flexibilidade da parte saliente. Não existe solda na aba de apoio deste modelo.
- Furos, bordas, sobreposição, raízes, espaço de ferramenta e folgas são verificações separadas. Folga zero mantém pendência de contato/rotação.

## Evidência e exemplo

Baseline analítico do aplicativo: W360×32,9; tw5,8mm; par L76×76×6,4; L260mm; weld_start20mm; filete4mm; apoio W310×97; quatro M20 por aba, passo60, bordas40; Vsd100kN.

A Vsd200kN, cada grupo recebe100kN:

- Lw372mm; centroide(67,569892473;130)mm
- Jlinha3448107,182795699mm³; Mgrupo−6,756989247kNm
- qmax442,683062837N/mm; resistência E70609,683180223N/mm
- Capacidade total equivalente do metal de solda275,449065666kN
- Capacidade total equivalente da alma única no limite elástico local conservador237,247076794kN, governante
- Envelope da aba: Mmax2,870596048kNm em x74,741901870mm; σ39,810411167MPa; τ90,144230769MPa; σeq161,129810588MPa

São fixtures independentes por componentes/modelo, não um exemplo publicado completo da ligação com a NBR2024. O código do oráculo não importa módulos do aplicativo e confirma os resultados também por quadratura. Os resultados históricos LCSP339kN (sem recorte) permanecem separados. Há uma inconsistência na fonte antiga: texto p22 atribui301kN à W360×39 com dois recortes; a tabela p50 dá282kN para essa linha e301kN para W360×44,6. Não se usa o número discrepante como aprovação.

## Fontes

1. ABNT NBR8800:2024, versão corrigida2025, exemplar fornecido:6.1;6.2.2.2;6.2.5/Tabela9;6.2.6;6.3;6.5;TabelasA.3/A.4. Página PDF corresponde à impressa+22.
2. Gerdau, Ligações para Estruturas de Aço, 7ªedição2018, exemplar fornecido, pp19–27 e50. Método e geometria históricos; tabelas baseadas em2008, sem verificação do apoio.
3. Padrão industrial fornecido, PADRÃO DE LIGAÇÕES-2Model, R015, página impressa18: interfaces, montagem e tabela métrica N×s.
4. AISC, Modern Steel Construction, julho2016, “Keeping Fillet”: https://www.aisc.org/globalassets/modern-steel/archives/2016/07/keeping.pdf . Discussão específica de comparação do metal-base no grupo em C de cantoneiras. Trecho relevante conferido pelo índice público; não se declara leitura integral do PDF quando o acesso direto foi bloqueado.
5. AISC360-16, J2.2/comentários, distinção dos retornos na aba saliente; referência complementar, sem substituição dos coeficientes NBR.

Os módulos R016, emenda W axial e bases anteriores mantêm seus escopos; esta família não libera as verificações ainda pendentes deles.
