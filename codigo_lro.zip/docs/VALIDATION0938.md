# Validação da fonte 0.9.38

Alteração de apresentação: números calculados com até duas casas decimais na interface, croquis e memórias. Valores pequenos não nulos usam notação científica. O estado importado, os cálculos, as comparações, os arquivos nativos e os catálogos permanecem numericamente exatos.

Cobertura integral composta: **5591 casos distintos, 5590 aprovados, 1 falha histórica, 0 erros e 0 pulados**. Não foi uma execução única da árvore final de testes: a execução integral original manteve runtime e testes estáveis; sete módulos tiveram somente expectativas antigas de apresentação corrigidas e foram reexecutados integralmente. O registro exclui todos os casos originais desses módulos e inclui os substitutos uma única vez. Os módulos reutilizados têm exatamente os bytes finais; runtime e entradas de teste herdadas permaneceram idênticos. Manifestos, XMLs, logs, diferenças e o mapa de IDs estão em validation0938.

A única falha é a ausência do arquivo externo original next_connection_scope/bolt_bearing_oracle.json. Não se criou substituto nem se contou esse teste como aprovado. As 106 comparações de paridade, 19 rotas AppTest, 404 controles, 84 tabelas, 19 SVGs, 19 PNGs e 31 memórias Word são unidades de evidência distintas e não são somadas aos testes pytest. A precisão importada e a distinção real PASS/FAIL junto de 1,00 foram verificadas.

O gate físico compara 623 grupos SVG nomeados e 322 formas não textuais em quatro rotas sem IDs. O número anterior de 694 incluía 71 definições de glifos de fonte; a classificação foi corrigida explicitamente, sem alterar tolerâncias geométricas. Há inspeção visual separada de desenhos e páginas Word; não há comprovação de pixels de navegador real.

A aplicação geradora é 0.9.38-display-precision-dev. As versões de componentes de engenharia e de seus formatos nativos foram preservadas: por exemplo, o componente 2L soldadas continua 0.9.37 e o 1L soldada continua 0.9.27. Esses rodapés podem aparecer em saídas recém-geradas e não representam uma versão antiga da aplicação.

A fonte 0.9.37 foi conferida sem alterações. Não há mudança de método resistente, chanfro, opção de tala ou aprovação física adicional nesta versão. A aceitação é da fonte; o pacote extraído ainda precisa das revisões APP-only autorizadas.
