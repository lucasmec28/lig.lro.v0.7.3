# Distribuição compacta 0.9.72

Identidade do pacote: `0.9.72-candidatos-r016-dev.1`. A versão do componente de cálculo `lro.models.VERSION` continua `0.9.44-beam-on-beam-partial-dev`, sem alteração do avaliador R016 ou dos renderizadores nativos.

## Sugestões opcionais R016

A busca usa somente o gabarito atual já qualificado, L76×76×6,4/g45 ou L102×102×8/g65, sem trocar perfis, materiais, ações, raio, sentido ou hipóteses. O projeto atual e os padrões métricos 16/20/24/30 mm com 2 a 20 linhas iguais são avaliados pelo motor existente. A ordenação por comprimento, total de parafusos e diâmetro vale apenas nesse conjunto finito, sem ótimo global ou estimativa de massa. Pendências e condições fora do domínio não são resolvidas silenciosamente.

Buscar, selecionar prévia e baixar a sugestão conservam o projeto nativo. Somente **Aplicar sugestão** transfere os novos dados aos controles e recalcula pelo fluxo nativo. O JSON anterior é preservado para baixar ou restaurar explicitamente. A busca fica bloqueada para aplicação se as entradas mudarem. Os extremos físicos do pilar permanecem fixos; as bordas são recalculadas para a posição proposta dos furos.

## Conteúdo preservado

A cópia compacta mantém exatamente os mesmos bytes da aplicação de execução, módulos `lro`, dados e exemplos da fonte congelada. Os documentos na raiz de `docs` e os manifestos históricos também são preservados. O catálogo visual de 26 famílias mantém a abertura direta por foto/cartão, a seleção exata, o projeto editado em abertura repetida e o tema opcional. As miniaturas continuam exemplos de presets, não resultados do projeto atual.

São excluídos somente caches, suíte de testes, `artifact_qa` e subpastas volumosas de evidências históricas em `docs`. O resumo `docs/validation0972/SUMMARY.json` é mantido. A fonte integral e as evidências de teste ficam preservadas separadamente. Essa redução não exclui famílias, recursos, métodos ou exemplos.

## Integridade e execução

O ZIP externo contém exatamente quatro arquivos: `app.py`, `codigo_lro.zip`, `requirements.txt` e `README.md`. Mantenha os quatro juntos. O carregador verifica SHA-256 do ZIP interno, caminhos de extração, arquivos obrigatórios, identidade do pacote e mistura de módulos de outra revisão. Uma atualização exige reiniciar o processo Streamlit.

O manifesto `docs/CATALOG_SCOPE0972_MANIFEST.json` é criado exclusivamente em `compact/src`, na cópia de distribuição, e descreve seu conteúdo completo, exceto ele próprio. Nenhum manifesto histórico da fonte é atualizado. Execute `python verificar_pacote.py` depois de extrair o ZIP interno para conferir a distribuição. A ausência do manifesto 0972 é um erro explícito; manifestos históricos não substituem o atual. Mudanças apenas de LF/CRLF são aceitas pelo verificador; o carregador externo exige o SHA-256 exato do ZIP distribuído.

## Limites da evidência

A validação do pacote abrange CRC, SHA-256, inventário, compilação, manifesto, paridade byte a byte com a fonte congelada e preservação dos manifestos históricos. Em processos novos, o ZIP externo extraído abre as 26 famílias pelos cartões reais via Streamlit AppTest, confirma controles e JSON nativos, seleção exata, retorno ao catálogo, abertura repetida da família atual e evento real de foto via protocolo de widgets. Conserva as 14 proteções anteriores e acrescenta a ausência de cada um dos dois módulos R016, totalizando 16; preserva também as salvaguardas de entradas inválidas nas emendas W.

O fluxo R016 do pacote executa a busca, troca a prévia sem modificar exportação, aplica explicitamente, confere o resultado e os renderizadores nativos, baixa o projeto anterior e restaura a exportação original. No projeto inicial, a primeira sugestão é L200/M20/3 linhas e o original é L260/M20/4 linhas. Isso é uma expectativa de teste do exemplo, não recomendação estrutural geral.

AppTest é evidência funcional, não screenshot nem validação visual em navegador. Não são iniciados servidor, socket, navegador, publicação, push ou deploy. Testes de software não equivalem a aprovação estrutural de um projeto; todos os limites técnicos e pendências das famílias permanecem aplicáveis.
