# Shear-plate Word test contract amendment

## Decision

SCOPED GO for this one test-only change. No runtime, report generator, calculation, original patch or previous GO receipt is changed. Application to the held combined source belongs to the release integrator after its current aggregate ends and the hold is deliberately renewed.

## Diagnosis

The original test rejects every raw XML occurrence of qSd or qRd. The final report contains no calculated weld demand/resistance with those labels. The only new qRd occurrence is the explicit statement that weld-throat resistance and the minimum CJP fused section are not capacities of the two connected-base-metal interfaces. That correct exclusion is part of the separately reviewed receiving-plate qualification boundary.

The original test fails in a byte-equivalent isolated source copy for that exact sentence. See BASELINE_REPRODUCED.log. This is a test-contract conflict, not a change in weld Vw/Mw or a newly qualified interface.

## Minimal amendment

Only tests/test_shear_plate_artifacts.py changes, in test_weld_actions_are_not_capped_by_steel_or_applied_shear. All existing fixture values and four positive witness assertions remain unchanged, including the exact 801,43 and 76,14 displayed Vw/Mw values, the uncapped-action narrative, and the no-calculated-weld-resistance narrative.

The replacement parses the XML already available in the test. Every editable native equation is joined across runs, whitespace-normalized and checked for absence of qSd/qRd. The equations must be present. Every Word paragraph is joined across runs; the entire list of paragraphs mentioning either token must equal exactly one complete, literal exclusion paragraph. This rejects foreign capacities/demands in prose, altered qualifications, duplicate notices and additions to the allowed paragraph. The expected literal is not imported from production, so changing production wording does not silently change the assertion.

The replacement does not weaken the report to a section-only check or remove an adverse witness. It is intentionally narrow and will require deliberate review if the exclusion paragraph is changed later.

## Evidence

- Original isolated test: fails at the original blanket qSd/qRd assertion.
- Amended complete artifact test file: 7 passed.
- Related shear-plate engine, single-key weld engine/artifacts, and receiving-plate tests: 187 passed.
- Author mutation harness: 21 cases passed, consisting of 2 valid accepted forms and 19 rejected corruptions.
- Independent reviewer: complete artifact file 7 passed and 24 mutation cases passed, consisting of 2 accepted forms and 22 rejected corruptions. Its AST check proves that original witnesses and all other tests are unchanged. Evidence: review_shear_plate_test0942/MUTATION_REVIEW.json and CANDIDATE_TARGETED.log/.xml.
- All 354 files in the original combined runtime/test hold remain unchanged. Only this test differs in the isolated copy. Reverse patch dry-run is clean.

These are focused test results, not a replacement for the final combined aggregate. Full transfer, unknown holes and both base-metal interfaces remain pending under the original engineering scope.

## Files

SHEAR_PLATE_TEST0942.patch is the integrator's patch. AMENDMENT_RECEIPT.json binds original/changed test hashes, patch, source hold, focused logs and independent review. source_snapshot is an isolated testing copy only. No release archive was created.
