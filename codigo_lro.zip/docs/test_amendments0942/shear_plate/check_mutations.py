"""Exercise the actual proposed test using deliberately corrupted report XML."""
from pathlib import Path
from copy import deepcopy
import hashlib
import importlib.util
import json
import sys
import xml.etree.ElementTree as ET

base = Path(__file__).resolve().parent
source = base / 'source_snapshot'
sys.path.insert(0, str(source))
spec = importlib.util.spec_from_file_location('amended_test', source / 'tests/test_shear_plate_artifacts.py')
test = importlib.util.module_from_spec(spec)
spec.loader.exec_module(test)
c = test.fixture(a2=180., lug_bh=200., lug_bv=150., lug_t=31.75, tp=38.1, fck=30.)
original = test.doc_xml(c)
(base / 'WITNESS_DOCUMENT.xml').write_text(original)
ns = {'m': 'http://schemas.openxmlformats.org/officeDocument/2006/math',
      'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
for prefix, uri in ns.items():
    ET.register_namespace(prefix, uri)
def node(tag, text=None):
    prefix, name = tag.split(':')
    element = ET.Element('{' + ns[prefix] + '}' + name)
    element.text = text
    return element

def altered(operation):
    root = ET.fromstring(original)
    operation(root)
    return ET.tostring(root, encoding='unicode')

def add_prose(root, pieces):
    p = node('w:p')
    for piece in pieces:
        r = node('w:r'); r.append(node('w:t', piece)); p.append(r)
    root.find('w:body', ns).insert(0, p)

def add_math(root, pieces, subscript=False):
    p = node('w:p'); math = node('m:oMath'); p.append(math)
    if subscript:
        sub = node('m:sSub'); math.append(sub)
        for tag, text in [('m:e', pieces[0]), ('m:sub', pieces[1])]:
            part=node(tag); r=node('m:r'); r.append(node('m:t', text)); part.append(r); sub.append(part)
    else:
        for piece in pieces:
            r=node('m:r');r.append(node('m:t',piece));math.append(r)
    root.find('w:body', ns).insert(0, p)

def notice(root):
    return next(p for p in root.findall('.//w:p', ns) if 'qRd' in ''.join(p.itertext()))

def append_notice(root):
    r=node('w:r');r.append(node('w:t', ' A interface está aprovada.'));notice(root).append(r)

def duplicate_notice(root):
    root.find('w:body', ns).insert(0, deepcopy(notice(root)))

def split_notice(root):
    p = notice(root); text=''.join(p.itertext());p.clear()
    for piece in text.split(' '):
        r=node('w:r');r.append(node('w:t', piece+' '));p.append(r)
    p[-1][0].text=p[-1][0].text.rstrip()

cases=[('unchanged_positive',original,True), ('same_notice_split_runs',altered(split_notice),True)]
for token in ('qSd','qRd'):
    cases.extend([
        (token+'_equation',altered(lambda root,t=token:add_math(root,[t+'=123 N/mm'])),False),
        (token+'_equation_split_runs',altered(lambda root,t=token:add_math(root,list(t))),False),
        (token+'_equation_subscript',altered(lambda root,t=token:add_math(root,[t[0],t[1:]],True)),False),
        (token+'_equation_whitespace',altered(lambda root,t=token:add_math(root,[t[0], ' '+t[1:]])),False),
        (token+'_foreign_prose',altered(lambda root,t=token:add_prose(root,[t+' = 123 N/mm'])),False),
        (token+'_prose_split_runs',altered(lambda root,t=token:add_prose(root,[t[0],t[1:]+' = 123 N/mm'])),False),
    ])
cases.extend([
    ('qualification_appended_to_notice',altered(append_notice),False),
    ('duplicate_allowed_notice',altered(duplicate_notice),False),
    ('notice_negation_removed',original.replace('não são resistências dessas interfaces.', 'são resistências dessas interfaces.'),False),
    ('Vw_witness_removed',original.replace('801,43','0,00'),False),
    ('Mw_witness_removed',original.replace('76,14','0,00'),False),
    ('uncapped_weld_actions_notice_removed',original.replace('Não se limita Vw pela menor resistência da chapa',''),False),
    ('no_calculated_weld_resistance_notice_removed',original.replace('Não se calcula resistência de solda',''),False),
])
results=[]
for name,xml,expected in cases:
    test.doc_xml=lambda c, detailed=True, xml=xml:xml
    try:
        test.test_weld_actions_are_not_capped_by_steel_or_applied_shear()
        accepted=True
    except AssertionError:
        accepted=False
    results.append({'name':name,'expected_accept':expected,'actual_accept':accepted,'passed':expected==accepted})
report={'candidate_test_sha256':hashlib.sha256((source/'tests/test_shear_plate_artifacts.py').read_bytes()).hexdigest(),
        'witness_xml_sha256':hashlib.sha256(original.encode()).hexdigest(),
        'total':len(results),'passed':sum(r['passed'] for r in results),'cases':results}
(base/'MUTATION_RESULTS.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
assert all(r['passed'] for r in results)
