from pathlib import Path
import importlib.util,xml.etree.ElementTree as ET,json,copy,hashlib,ast
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('review_candidate',HERE/'test_shear_plate_artifacts_review.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
name='test_weld_actions_are_not_capped_by_steel_or_applied_shear';f=getattr(m,name)
c=m.fixture(a2=180.,lug_bh=200.,lug_bv=150.,lug_t=31.75,tp=38.1,fck=30.)
xml=m.doc_xml(c);(HERE/'REAL_REPORT_DOCUMENT.xml').write_text(xml)
W='http://schemas.openxmlformats.org/wordprocessingml/2006/main';M='http://schemas.openxmlformats.org/officeDocument/2006/math';ns={'w':W,'m':M}
root=ET.fromstring(xml)
allowed=('Tabela 9 remete o metal-base dos filetes à NBR 6.5. Faltam cortes físicos e '
'áreas efetivas/líquidas com as ações locais combinadas da mesma junta; '
'qRd da garganta e a seção fundida mínima de CJP não são resistências dessas interfaces.')
paragraphs=root.findall('.//w:p',ns);p=next(p for p in paragraphs if ''.join(p.itertext())==allowed)
records=[]
def run(case,value,want):
 m.doc_xml=lambda *args,**kwargs:value
 try:f();passed=True
 except AssertionError:passed=False
 assert passed==want,(case,passed,want)
 records.append(dict(case=case,expectation='pass' if want else 'reject',actual='pass' if passed else 'reject'))
def add_prose(parts):
 r=copy.deepcopy(root);body=r.find('w:body',ns);p=ET.SubElement(body,'{'+W+'}p')
 for text in parts:
  rr=ET.SubElement(p,'{'+W+'}r');ET.SubElement(rr,'{'+W+'}t').text=text
 return ET.tostring(r,encoding='unicode')
def add_math(parts,subscript=False):
 r=copy.deepcopy(root);body=r.find('w:body',ns);p=ET.SubElement(body,'{'+W+'}p');o=ET.SubElement(p,'{'+M+'}oMath')
 if subscript:
  ss=ET.SubElement(o,'{'+M+'}sSub');slots=[ET.SubElement(ss,'{'+M+'}e'),ET.SubElement(ss,'{'+M+'}sub')]
 else:slots=[o]*len(parts)
 for parent,text in zip(slots,parts):
  rr=ET.SubElement(parent,'{'+M+'}r');ET.SubElement(rr,'{'+M+'}t').text=text
 return ET.tostring(r,encoding='unicode')
run('actual_report',xml,True)
# Equivalent run fragmentation of the exact exclusion remains valid.
r=copy.deepcopy(root);p=next(p for p in r.findall('.//w:p',ns) if ''.join(p.itertext())==allowed)
for child in list(p):p.remove(child)
for text in [allowed[:170],allowed[170:175],allowed[175:]]:
 rr=ET.SubElement(p,'{'+W+'}r');ET.SubElement(rr,'{'+W+'}t').text=text
run('allowed_exclusion_split_runs',ET.tostring(r,encoding='unicode'),True)
for token in ('qSd','qRd'):
 run('prose_'+token,add_prose([token+' = 123 N/mm']),False)
 run('prose_split_'+token,add_prose([token[0],token[1:], ' = 123 N/mm']),False)
 run('equation_'+token,add_math([token+' = 123']),False)
 run('equation_split_'+token,add_math([token[0],token[1:]+' = 123']),False)
 run('equation_whitespace_'+token,add_math([token[0]+' ',token[1:]+' = 123']),False)
 run('equation_subscript_'+token,add_math([token[0],token[1:]],True),False)
run('exclusion_duplicate',add_prose([allowed]),False)
run('exclusion_replaced_by_approval',xml.replace('não são resistências dessas interfaces.','são resistências suficientes dessas interfaces.'),False)
run('exclusion_missing',xml.replace(allowed,''),False)
run('exclusion_appended_strength',xml.replace(allowed,allowed+' qRd = 123 N/mm.'),False)
run('exclusion_prefixed_strength',xml.replace(allowed,'qSd = 20 N/mm. '+allowed),False)
for witness in ('801,43','76,14','Não se limita Vw pela menor resistência da chapa','Não se calcula resistência de solda'):
 run('missing_witness_'+witness,xml.replace(witness,'REMOVED'),False)
# An exact whitelist paragraph placed in native math must still be rejected.
run('allowed_exclusion_in_equation',add_math([allowed]),False)
# Check that every function except the target is AST-identical to original.
oldpath=Path('review0942/source0942/tests/test_shear_plate_artifacts.py');newpath=HERE/'test_shear_plate_artifacts_review.py'
a=ast.parse(oldpath.read_text());b=ast.parse(newpath.read_text());oldtarget=next(x for x in a.body if getattr(x,'name',None)==name);newtarget=next(x for x in b.body if getattr(x,'name',None)==name)
assert [ast.dump(x) for x in oldtarget.body[:-1]]==[ast.dump(x) for x in newtarget.body[:len(oldtarget.body)-1]]
a.body=[x for x in a.body if getattr(x,'name',None)!=name];b.body=[x for x in b.body if getattr(x,'name',None)!=name];assert ast.dump(a)==ast.dump(b)
result=dict(status='PASS',mutation_cases=len(records),positive_cases=sum(x['actual']=='pass' for x in records),negative_cases=sum(x['actual']=='reject' for x in records),original_witnesses_unchanged=True,other_module_AST_unchanged=True,candidate_sha256=hashlib.sha256(newpath.read_bytes()).hexdigest(),records=records)
(HERE/'MUTATION_REVIEW.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='records'},indent=2))
