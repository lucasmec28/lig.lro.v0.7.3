# Revisão 0.9.65 — soldas da nervura em três bordas

A base 0.9.64 foi preservada. O avanço é o grupo elástico das soldas da nervura à alma da coluna e aos dois horizontais, com dois filetes por borda, comprimentos reais descontados dos alívios e gargantas distintas. Parafusos, talas, alma da viga e contato direcional mantêm seus cálculos anteriores.

## Modelo e fontes

A hipótese de distribuição é de peças e apoios rígidos no plano e rigidez linear isotrópica por área de garganta. AISC Manual 15ª edição, páginas 8-12/8-13, equações 8-5 a 8-11, fornece o método elástico de linhas. A ponderação por áreas de gargantas distintas é a extensão analítica declarada desse método, verificada por integração independente.

NBR 8800:2024, versão corrigida 2025, 6.2.2.2 e Tabela 9: a=w/√2; área de garganta = Σ2aL; resultante vetorial local ≤0,60fw/1,35. Tensões não uniformes são verificadas por unidade de comprimento, sem aumento direcional. O método adotado limita L/w a 100; acima disso registra extrapolação e revisão da aplicabilidade de redução por solda longa, sem inventar β ou reprovar o detalhe automaticamente.

O centroide e a inércia polar são ponderados pelas gargantas. O momento na origem V·pin_x é transferido ao centroide: MG=M0−xG·V+yG·N. A integração de cada borda conserva Fx, Fy e M, incluindo o binário local da distribuição. Não se soma novamente o momento dos parafusos ao momento total.

## Resultados e alcance

Os três ramos das soldas aparecem em uma única envoltória resumida. O metal-base do lado da nervura recebe apenas uma verificação suplementar de escoamento local sob tensão paralela à borda assumida nula, também resumida por uma envoltória. Essa hipótese não é uma cota conservadora universal do campo completo da chapa. Resultados positivos ou negativos destes ramos são expressamente condicionados à hipótese elástica.

A alma da coluna e os horizontais recebem componentes normais aos seus próprios planos; não se aplica uma resistência fictícia de corte simples à resultante completa. A capacidade desses receptores, suas soldas posteriores, a membrana perfurada e a estabilidade da nervura continuam pendentes. O cálculo independente dos cordões não libera a ligação integralmente.

No preset governante: Aw=3468,359 mm²; xG=21,710 mm; J=60.745.325,332 mm⁴. Utilização máxima das gargantas=0,11577; critério suplementar local da nervura=0,13190. Esses índices não representam a utilização integral do conjunto.

## Validação

A revisão independente montou matriz de rigidez de movimento rígido 3×3 e integrou por quadratura de Gauss, sem reutilizar fórmulas de centroide da produção: 42.557 comparações aprovadas em 250 geometrias aleatórias e 1.000 avaliações transformadas. Foram conferidos forças, momentos, gargantas diferentes, translação, rotação, reflexão, sentidos dos segmentos e ações nulas. Um segundo oráculo comparou 18 casos completos de três bordas, somente alma e somente horizontais.

A regressão agregada passou em 340 testes. Após o ajuste exclusivamente textual dos separadores das substituições, os 41 testes focados foram reexecutados e passaram; os artefatos são novamente conferidos no estado final. O resumo acompanha esta distribuição. Testes não constituem aprovação estrutural. Consulte COMPARACAO_CAMINHOS0965.md para a envoltória das alternativas sugeridas e CRITERIOS_PENDENTES0965.md para a lista sintética de fechamento.
