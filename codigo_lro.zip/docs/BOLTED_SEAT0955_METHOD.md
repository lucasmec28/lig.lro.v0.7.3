# B9 existente: fechamento delimitado do caminho vertical

Revisão privada de desenvolvimento, 15/10/2026. Pacote de revisão privada; não é aprovação estrutural de projeto. Não cria família. A opção parafusada já existia no esquema da cantoneira e permanecia bloqueada.

## Domínio e caminho

Quatro M20 classe 8.8N/S conforme AS/NZS 1252, malha 2×2 simétrica, um plano de corte com rosca, furos 22 mm, sem calços. Cantoneira laminada Grade 300 não enrijecida, assento por gravidade estática, viga horizontal sem esconsidade, apoio exclusivamente na mesa de coluna W contínua. Sem furos adicionais, entalhes ou ações concorrentes na zona de transferência. Não há modelo de tração normal, arrancamento, torção, fadiga ou sismo.

DG6 B9 pp.34–37 define Vdes=min(Vc,Vd,Vf,Vg): Vc é o equilíbrio alma/flexão já implementado; Vd é flambagem local da alma; Vf é o limite superior específico; Vg é a fixação. Conservam-se as verificações de cortante da viga. DG6 B5 p.25 limita a evidência a tw≤14,3 mm; a nova linha impede aprovação além desse domínio. Mantêm-se limites de ta=9,5–25 mm, comprimentos, contato e excentricidade, sem aplicar o clamp contraditório de p.28.

Vf: x=Rf/(fy La ta), raiz positiva de 16x⁴+x²+(2−4ra/ta)x−2=0; Vf=0,9Rf. Polinômio estritamente convexo para x≥0, negativo em zero e positivo no infinito: há uma raiz positiva. Bisseção devolve limite inferior. Verificação independente usa Newton decimal de 60 dígitos; exemplo B12.2 arredondado em p.43 é apenas benchmark.

Vg: quatro vezes a menor resistência por parafuso. Corte deriva de 0,8×0,62×830×225=92.628 N, kr=1: HB 1 pp.17–18. Não se usa área de tração 245 mm². Para cada peça, contato=0,9×3,2d t fu e rasgamento=0,9 ae t fu, DG6 p.36 e HB 1 pp.15–17. ae entre furos=passo−12 mm; ae até borda física=distância de centro−1 mm. O mesmo menor ae de todos os parafusos limita conservadoramente o grupo. Cantoneira recebe força dos parafusos para cima; mesa da coluna, para baixo. Não se usa metade da espessura da mesa: essa regra do exemplo do guia é para dois assentos opostos na alma.

DG6 B6 p.26 despreza a tração adicional da excentricidade no modelo empírico parafusado. Ela não é chamada inexistente nem calculada arbitrariamente. O momento Mc=V[max(100,c+bs/2)+dc/2] é entregue ao projeto do membro coluna. A dispensa do check local da alma em assento na mesa é explícita em DG6 p.41. Não se mistura AS com coeficientes NBR.

## Geometria, montagem e outras verificações

Bordas adotam conservadoramente 1,75d para todos os cortes; não se aproveitam reduções por bordas laminadas/serradas. Passos e gabaritos mínimos 2,5d, máximos min(15t,200), linha externa na direção de V min(4t+100,200), borda mais próxima máxima min(12t,150), HB 1 p.26. Espaço físico é testado separadamente de resistência. Mesa deve cobrir o assento completo; geometria sem ligamentos positivos não recebe resistência de furos.

Cabeças na cantoneira, porcas atrás da mesa; montagem antes de apoiar a viga. Envelope informado não pode ser inferior ao soquete manual M20 de referência: raio 24,15 mm e comprimento 65 mm, HB 1 p.12. Verificam-se raiz da cantoneira, raiz do pilar, filas, colunas e espaço axial entre mesas. O raio do pilar é extraído da altura livre reta efetivamente informada. Ferramenta, arruelas, comprimento e engajamento reais pertencem à execução especificada; seleção não é certificado de montagem.

B9 não enumera um oitavo check de seção líquida/bloco. Não se afirma que rasgamento individual comprova qualquer caminho de bloco. Grupo arbitrário, cortes ou furos adicionais e outra topologia estão excluídos; seção líquida da coluna sob N/M e estabilidade do membro são externas. HB 1 discute blocos gerais separadamente, sem incorporá-los expressamente a B9. Parafusos de localização da viga não recebem V/4; V/4 aplica-se exclusivamente aos quatro parafusos de fixação do assento.

## Correção material B1 autorizada junto da revisão

HB 1 Tabela 29 p.78: Grade 300 tem fy 320 MPa abaixo de 11 mm, fy 300 de 11 a 17 inclusive, fy 280 acima de 17, fu 440 MPa. B9 usa essas faixas. B1 mantém 300 conservador abaixo de 11 e seus resultados anteriores até 17 mm; somente acima de 17 troca 300 por 280 e publica fy efetivo. Não se preserva a sobreestimativa anterior por compatibilidade histórica.

## Dados e apresentação

Nova versão do componente; identidade do pacote atualizada para 0.9.55-bolted-seat-dev.1 após revisão independente. JSON antigo .52/.54 migra sete dimensões de parafusos/montagem para zero e mantém B9 pendente: nunca se presume geometria de importação antiga. Campos extras, ausentes na versão nova ou tipos inválidos são rejeitados. Exemplo B9 é uma ação explícita da interface. Os sete campos sobrevivem à troca de variantes e soldado/parafusado. Campos de solda são inativos no B9. Word, SVG e PNG são gerados dos dados correntes; quatro furos reais do grupo aparecem no desenho. Texto e croqui são originais, sem incorporar scans ou tabelas editoriais.

## Preservação e evidência

Somente quatro arquivos existentes de apoios foram modificados; novo módulo bolted_seat.py. Fonte .54 original intocada. U2 .53, viga sobre viga .51 e todos os demais arquivos existentes ficam idênticos byte a byte. Comparação de 14 saídas preserva A1(a), A1(e) e B1 com ta≤17, incluindo sobrecargas. Registro dos testes e artefatos fica na pasta de evidências desta revisão. Testes históricos que exigem B9 sempre incompleto são superados pelo novo contrato; nenhuma falha histórica é apresentada como passe.

Referências locais: ASI DG6, primeira edição 2007, pp.25–29,34–38,41–43; ASI Handbook1, primeira edição 2007, pp.12,15–18,26–27,78. Base histórica AS 4100; sem alegação de conformidade atual automática. Respeitar licença/autorizações antes de distribuição ou uso comercial. Houve somente empacotamento local autorizado após revisão; sem push, deploy, upload nem uso do computador do usuário.
