# Validação do checkpoint axial W M004

**Historical checkpoint.** This document records its original axial/research stage. A separate conventional N/M/V family now exists in `lro/w_splice_conventional.py`, with its own `W_CONVENTIONAL_NMV_SCOPE.md`. Statements below that general W work is pending describe that historical stage, not the current selector as a whole. The 0.9.13 audit is solely the axial M004 family; see `AXIAL_SPLICE_AUDIT0913_METHOD.md`.


Versão interna: 0.9.0-w-dev. Esta revisão não conclui a emenda W sob compressão, momento e cortante simultâneos e não foi publicada. A 0.8.6 original foi preservada.

## Implementação

- Oito talas reais: duas na alma, duas externas às mesas e quatro tiras internas.
- Mesmas seções W e materiais por componente, talas balanceadas, dois planos de corte e duas metades em série.
- 193 verificações físicas no exemplo com quatro linhas longitudinais nas mesas; 44 parafusos reais.
- N real e ação adotada da conferência separados em tela, JSON e Word.
- Ct corrigido; dedução líquida baseada no máximo da Tabela 14 e contato pelo furo físico informado.
- Área líquida conservadora do W completo; áreas locais de mesa sem crédito de raiz, mas demandas alocadas incluindo a parcela de raiz.
- Caminhos de bloco reais: alma do membro sem falsas bordas junto às mesas; mesa do membro com L1 lateral real; talas livres com U/L, tiras internas de uma coluna sem U artificial.
- Política de mínimos explícita; ações de integridade na entrada e fonte exigida quando Nc,Rd externo for adotado.
- Colisão física, detalhe normativo, acesso/fabricação, variação do preset e domínio não implementado são estados distintos.

## Evidência independente

`tests/fixtures/w_splice_axial_independent.json` contém quatro casos gerados com aritmética racional, sem importação do aplicativo. Todos os 89 checks representativos foram cruzados com cada uma das 193 cópias físicas pertinentes. O fub do fixture é um valor numérico conservador de 800 MPa; o cadastro métrico ASTM usa 830 MPa, com ajuste explícito dessa única diferença nos testes dos parafusos.

- Piso recomendado conservador: Nd=1.938.272,727 N, verificações resistentes atendidas
- N=2.200.000 N: atendidas
- N=2.250.000 N: falha apenas no bloco U da alma do próprio W
- Capacidade equivalente desse domínio: 2.211.601,732 N, sem soma das metades

O desvio dimensional do exemplo, borda externa de 35 mm frente ao preset M004 de 40 mm, é informado separadamente; o mínimo normativo de 26 mm é atendido.

A auditoria independente expandida documentada em `W_SPLICE_KERNEL_AUDIT.md` e `W_SPLICE_KERNEL_AUDIT_RESULTS.json` passou 61.608 comparações numéricas. Incluiu 57 casos numéricos, 22 casos de domínio/limites, 8 políticas, 268 entradas malformadas, 8 adulterações de JSON e 4 casos de estática assinada. Corrigiu e revalidou a soma da folga de fabricação ao raio da ferramenta e a rejeição de eixos duplicados/degenerados no helper de estática.

## Artefatos e interação

Desenho SVG/PNG de três vistas, com as oito talas identificadas individualmente, furos, folga e dimensões reais. Word com 15 páginas no exemplo, todos os 193 checks, equações editáveis, critérios/fontes e prancha. Renderização inspecionada visualmente. Exemplos locais em `examples/Emenda_W_M004_tracao.*` e `examples/Emenda_W_M004_falha_bloco_alma.*`.

Seis testes de interface verificam importação/exportação, retorno entre famílias, invalidação de Word após edição, bloqueio de M não nulo, recuperação após geometria impossível, políticas de mínimos e retenção do furo M24 explicitamente editado. Vinte testes específicos cobrem os artefatos. Os testes de kernel/estática e artefatos finais somaram 81 aprovações no conjunto focado; os 6 fluxos de UI também passaram.

## Agregado final

Agregado final concluído: **910 testes passaram em 467,07 s (7 min 47 s)**. Código de saída 0. Os hashes de todos os módulos alterados e dos testes W são idênticos antes e depois da execução. Evidências locais: `W_SPLICE_FINAL_TEST_LOG.txt` e `W_SPLICE_FINAL_TEST_PROVENANCE.json`. O agregado foi iniciado somente após todas as correções de auditoria, incluindo acesso com folga de fabricação e eixos duplicados/degenerados. Duas execuções preliminares foram interrompidas intencionalmente após correções; seus logs não são evidência de aprovação. O manifesto da fonte congelada 0.8.6 original também foi conferido sem divergências.

O helper de cortes externo ao source recebeu mais 14 testes próprios; o revisor cruzou 504 valores de seis combinações reais W310×97, sem divergências significativas. Isso verifica somente estática, sem resistência ou aprovação geral N/M/V.

## Limitação restante da família W

O helper `w_splice_equilibrium.py` calcula forças assinadas N/M/V e verifica equilíbrio, sem resistências ou aprovação. A interação de bloco com momento residual, a estabilidade das talas comprimidas e os demais gates gerais permanecem separados. Ver `M004_GENERAL_ARCHITECTURE.md`. O checkpoint axial não deve ser divulgado como conclusão da ligação W geral.
