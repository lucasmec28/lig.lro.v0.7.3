# Pacote compacto 0.9.7

O código de execução, os testes e os exemplos JSON foram preservados. A árvore de evidências de revisão e 24 arquivos W DOCX/PNG pré-renderizados foram omitidos da distribuição; a geração dinâmica permanece disponível. O agregado completo da fonte congelada teve 1.790 testes aprovados. A verificação deste pacote é registrada separadamente.
