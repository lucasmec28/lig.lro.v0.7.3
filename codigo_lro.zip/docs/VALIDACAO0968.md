# Validação 0.9.68

Escopo: somente apresentação de entradas nas bases I/H engastada, I/H rotulada e U com dois/quatro chumbadores. Valores ocultos conservados em JSON; cone, ruptura por borda, chumbadores e respectivas pendências não foram suprimidos.

Cinco testes novos de alternância/JSON/Word e 31 testes existentes U/2 passaram. Regressão ampliada das bases, projeções, JSON e Word também executada conforme resumo. Motores resistentes, desenhos e relatórios idênticos em bytes à 0.9.67. Word U/2 renderizado em três páginas, inspecionadas sem cortes ou sobreposição; hef e projeções conferidos.

A interface foi exercitada por Streamlit AppTest. Captura gráfica de navegador não concluída: Chromium não conseguiu criar socket no ambiente. Não declarar inspeção visual completa da tela.

Não há modo PROJETAR autônomo nem novos mínimos resistentes. Fck, bordas e embutimento não são inventados. Testes de software não aprovam um projeto estrutural. Sem alterações de duas talas/chapa de três bordas.
