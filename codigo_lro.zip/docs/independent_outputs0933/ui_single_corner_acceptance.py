"""Independent actual new 1L adapter callbacks. No UI/result replacement mocks."""
from pathlib import Path
from dataclasses import replace
from copy import deepcopy
import sys,json,hashlib
source=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();out.mkdir(parents=True,exist_ok=True);sys.path.insert(0,str(source))
from streamlit.testing.v1 import AppTest
from streamlit.runtime.memory_media_file_storage import MemoryMediaFileStorage
if (source/'codigo_lro.zip').exists():
 boot=AppTest.from_file(str(source/'app.py'),default_timeout=300).run();assert not boot.exception
from lro.corner_gusset import CornerGusset as C,FAMILY,analyze,MATERIALS,LEGACY_COMPONENT_VERSION
from lro.corner_gusset_ui import PROJECT,RESULT,REPORT,DRAFT,ACCEPTED,TEMPLATE,decode_project,checks_complete
from lro.corner_gusset_presentation import memory_text,input_fingerprint,physical_envelopes
files={};original=MemoryMediaFileStorage.load_and_get_id
def tap(storage,*args,**kwargs):
 identity=original(storage,*args,**kwargs);files[identity]=storage._files_by_id[identity].content;return identity
MemoryMediaFileStorage.load_and_get_id=tap
records=[]
def record(name,**kw):
 records.append({'name':name,'passed':True,**kw});(out/'UI_SINGLE_ACCEPTANCE.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n');print('PASS',name,flush=True)
def run(at):
 at.run();assert not at.exception,[x.message for x in at.exception];return at
def button(at,name):return next(x for x in at.button if x.label==name)
def export(at,label):
 item=next(x for x in at.get('download_button') if x.label==label);return files[Path(item.proto.url).name.rsplit('.',1)[0]]
def native(at):return export(at,'Salvar projeto de canto .json')
def upload(at,data):
 if not isinstance(data,bytes):data=json.dumps(data,ensure_ascii=False).encode()
 at.get('file_uploader')[0].upload('independent-single.json',data,'application/json').run();button(at,'Carregar projeto de canto').click();return run(at)
def mc(at):
 items=[x.value for x in at.text_area if 'MEMÓRIA LOCAL' in str(x.value)];assert len(items)==1;return items[0]
def snap(at):return {item.label:export(at,item.label) for item in at.get('download_button')}
def visible(at):return '\n'.join(str(x.value) for k in ('title','caption','info','warning','error','success','markdown','text_area','code') for x in getattr(at,k))
def fresh(c):
 at=AppTest.from_file(str(source/'app.py'),default_timeout=300);at.session_state['connection_family']=FAMILY;at.session_state[PROJECT]=c.to_dict();return run(at)
base=C(topology='single_1L_welded',symmetric=False);at=fresh(base)
assert at.session_state[RESULT]['status']=='PASS'
assert len(at.selectbox(key='connection_family').options)==19
assert at.session_state[PROJECT]==base.to_dict() and decode_project(native(at))==base
assert mc(at)==memory_text(base)
assert '28,1' in visible(at) and '2,81' in visible(at) and 'não se cancelam' in visible(at)
assert [m.value for m in at.metric[:2]]==['100','100']
assert all('quatro soldas' not in x.label.lower() for x in list(at.number_input)+list(at.selectbox))
assert not any(x.key=='cg_symmetric' for x in at.checkbox)
assert len(physical_envelopes(at.session_state[RESULT]))<len(at.session_state[RESULT]['checks'])
record('C1 1L actual controls, whole-force metric, units, concise summary and explicit spatial caveat')

# Explicit topology changes must retain exact actions/materials/geometry.
precise=replace(base,P=123456.78901234567,phi_deg=45.000000000000014,beam_cut_M=62300000.12345679,project='Independent preserved edits')
upload(at,precise.to_dict());button(at,'Gerar memória de canto').click();run(at);assert REPORT in at.session_state
snap1=snap(at);before=deepcopy(at.session_state[PROJECT]['connection']);at.selectbox(key='cg_topology').set_value('symmetric_2L_T_welded');run(at)
pair=replace(precise,topology='symmetric_2L_T_welded',symmetric=True);assert at.session_state[PROJECT]==pair.to_dict()
assert REPORT not in at.session_state and mc(at)==memory_text(pair)
assert [m.value for m in at.metric[:2]]==['123,457','61,7284']
assert 'single_angle_face' not in json.loads(native(at))['connection']
at.selectbox(key='cg_topology').set_value('single_1L_welded');run(at)
assert at.session_state[PROJECT]==precise.to_dict() and mc(at)==memory_text(precise)
for key in before:assert at.session_state[PROJECT]['connection'][key]==before[key],key
record('1L to 2L-T to 1L toggle preserves exact input precision, complete actions, materials and geometry; retires stale Word')

# Face physically mirrors the section and keeps only one angle/weld face.
upload(at,base.to_dict());button(at,'Gerar memória de canto').click();run(at);pos=snap(at)
at.selectbox(key='cg_single_angle_face').set_value('negative');run(at)
negative=replace(base,single_angle_face='negative');assert at.session_state[PROJECT]==negative.to_dict()
assert at.session_state[RESULT]['brace']['weld_count']==2 and at.session_state[RESULT]['brace']['angle_count']==1
assert at.session_state[RESULT]['brace']['centroid_z']==-28.1
assert mc(at)==memory_text(negative) and REPORT not in at.session_state
neg=snap(at)
for label in ('Salvar projeto de canto .json','Baixar resultados completos de canto .json','Baixar desenho de canto .png','Baixar desenho de canto .svg'):assert pos[label]!=neg[label],label
assert at.session_state[RESULT]['forces']==analyze(base)['forces']
button(at,'Gerar memória de canto').click();run(at);assert REPORT in at.session_state
at.selectbox(key='cg_topology').set_value('symmetric_2L_T_welded');run(at)
at.selectbox(key='cg_topology').set_value('single_1L_welded');run(at)
assert at.session_state[PROJECT]==base.to_dict()
record('Real positive/negative face changes current artifacts and moment sign while preserving nominal planar force path')

# Current MC may never stay cached after effort or individual material changes.
upload(at,base.to_dict());a=snap(at);at.number_input(key='cg_P_kN').set_value(150);run(at)
changed=replace(base,P=150000.);assert at.session_state[PROJECT]==changed.to_dict() and mc(at)==memory_text(changed)
assert '4,215' in visible(at)
for label,old in a.items():assert old!=export(at,label),label
for key in ('angle_steel','gusset_steel','beam_steel','column_steel','continuity_steel'):
 before=deepcopy(at.session_state[PROJECT]['connection']);target=next(v for v in MATERIALS if v!=before[key]);at.selectbox(key='cg_'+key).set_value(target);run(at)
 after=at.session_state[PROJECT]['connection'];assert {k:v for k,v in before.items() if k!=key}=={k:v for k,v in after.items() if k!=key}
 assert mc(at)==memory_text(decode_project(native(at)))
record('Load changes update all four exports, 4.215 kNm raw moment and MC; five steels stay separate')

# True old-version project import has no adapter-side state and remains 2L-T.
old=C().to_dict();old['component_version']=LEGACY_COMPONENT_VERSION
upload(at,old);assert at.session_state[PROJECT]['connection']==old['connection'];assert at.session_state[RESULT]['status']=='PASS'
assert at.selectbox(key='cg_topology').value=='symmetric_2L_T_welded'
assert mc(at)==memory_text(C())
record('Old 0.9.32 2L-T native import with no face stays backward compatible and preserves every scalar')

upload(at,base.to_dict());button(at,'Gerar memória de canto').click();run(at)
for tag,mutate in [
 ('missing_face',lambda d:d['connection'].pop('single_angle_face')),
 ('invalid_face',lambda d:d['connection'].update(single_angle_face='both')),
 ('angle_count',lambda d:d['fixed_assumptions'].update(angle_count=2)),
 ('weld_count',lambda d:d['fixed_assumptions'].update(brace_weld_count=4)),
 ('legacy_single',lambda d:d.update(component_version=LEGACY_COMPONENT_VERSION)),
 ('units',lambda d:d['units'].update(moment='kN m'))]:
 saved={k:deepcopy(at.session_state[k]) for k in (PROJECT,RESULT,REPORT,DRAFT,ACCEPTED,TEMPLATE)};bad=deepcopy(base.to_dict());mutate(bad)
 upload(at,bad)
 assert any('Não foi possível abrir' in x.value for x in at.error),tag
 for key,val in saved.items():assert at.session_state[key]==val,(tag,key)
record('Six malformed 1L identity/count/face/schema/unit imports reject atomically with old outputs intact')

for tag,c in [('wrong_single_symmetry',replace(base,symmetric=True)),('missing',replace(base,other_loads_excluded=False)),('compressed',replace(base,phi_deg=40,brace_weld_start=700)),('mixed',replace(base,P=1e6,workpoint_offset=100)),('negative',replace(base,P=-100000.))]:
 upload(at,c.to_dict());r=at.session_state[RESULT]
 assert r['status']!='PASS' and not r['complete'] and not at.success
 assert REPORT not in at.session_state and button(at,'Gerar memória de canto').disabled
 assert mc(at)==memory_text(c)
 if r['status']=='FAIL':assert 'INCOMPLETA' in visible(at)
record('Missing load, compressed gusset, mixed FAIL+UNVERIFIED and negative brace never emit resistant Word or favorable success')

upload(at,base.to_dict());button(at,'Gerar memória de canto').click();run(at)
saved={k:deepcopy(at.session_state[k]) for k in (PROJECT,RESULT,REPORT)}
# Interrupted uploader and subsequent navigation must retain same accepted report.
at.get('file_uploader')[0].upload('unapplied.json',json.dumps(replace(base,P=77777.).to_dict()).encode(),'application/json').run()
for k,v in saved.items():assert at.session_state[k]==v,k
options=at.selectbox(key='connection_family').options
for family in options:
 if family==FAMILY:continue
 at.selectbox(key='connection_family').set_value(family);run(at)
at.selectbox(key='connection_family').set_value(FAMILY);run(at)
for k,v in saved.items():assert at.session_state[k]==v,k
assert mc(at)==memory_text(base)
record('Accepted single-angle project/report survive interrupted upload and all eighteen other routes without state collision')
print('COMPLETE',len(records),'independent single-adapter callback groups',flush=True)

upload(at,base.to_dict());before=deepcopy(at.session_state[PROJECT]['connection'])
at.selectbox(key='cg_angle_profile').set_value('GERDAU_EQUAL_ANGLE_P03_R34');run(at)
row34=replace(base,angle_profile='GERDAU_EQUAL_ANGLE_P03_R34');assert at.session_state[PROJECT]==row34.to_dict()
assert at.session_state[RESULT]['status']=='PASS' and mc(at)==memory_text(row34)
assert '31,2' in visible(at) and '3,12' in visible(at)
assert all(at.session_state[PROJECT]['connection'][key]==before[key] for key in before if key!='angle_profile')
record('Single-angle Gerdau row34 selection recalculates catalog centroid, actual offset31.2 mm/raw3.12 kNm, MC and native state without changing steels')
