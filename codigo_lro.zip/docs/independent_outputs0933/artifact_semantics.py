"""Independent emitted SVG-coordinate and Word provenance checks."""
from pathlib import Path
from io import BytesIO
import sys,json,math,re,hashlib,xml.etree.ElementTree as ET,zipfile
import numpy as np
from docx import Document
capture=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();out.mkdir(parents=True,exist_ok=True)
records=[]
def pts(root,gid):
 g=next(x for x in root.iter() if x.get('id')==gid)
 p=next(x for x in g.iter() if x.tag.endswith('path'))
 nums=[float(x) for x in re.findall(r'[-+]?(?:\d*\.\d+|\d+)(?:[eE][-+]?\d+)?',p.get('d'))]
 assert len(nums)%2==0,(gid,p.get('d'));return np.asarray(nums).reshape((-1,2))
def mapping(a,b):
 transform=np.linalg.lstsq(np.c_[a,np.ones(len(a))],b,rcond=None)[0]
 assert np.max(np.abs(np.c_[a,np.ones(len(a))]@transform-b))<2e-5
 return lambda x:np.c_[np.asarray(x),np.ones(len(x))]@transform

def close(actual,expected,gid):
 assert actual.shape==expected.shape,(gid,actual,expected)
 assert np.max(np.abs(actual-expected))<2e-5,(gid,actual,expected)
for native in sorted(capture.glob('*.json')):
 if native.name.endswith('.results.json') or native.name=='DOWNLOAD_RECEIPT.json':continue
 try:data=json.loads(native.read_text())
 except:continue
 if 'connection' not in data:continue
 tag=native.stem;c=data['connection'];res=json.loads(native.with_suffix('.results.json').read_text())
 assert res['input']==data;r=res['result'];svg=native.with_suffix('.svg').read_text();root=ET.fromstring(svg)
 digest=hashlib.sha256(json.dumps(data,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest();assert digest in svg
 # These finite captures retain the frozen commercial profile fixture; only
 # declared load, angle, offset and plate dimensions vary.
 assert c['beam_profile']=='W 310 x 52,0' and c['column_profile']=='W 310 x 97,0 (H)'
 assert c['angle_profile'] in ('GERDAU_EQUAL_ANGLE_P03_R30','GERDAU_EQUAL_ANGLE_P03_R34')
 leg,centroid,tL=(76.2,22.1,7.94) if c['angle_profile'].endswith('R30') else (88.9,25.2,7.94)
 ec,eb=154.,158.5;w,h,clip=c['plate_width'],c['plate_height'],c['corner_clip']
 polygon=np.asarray([(ec+clip,eb),(ec+w,eb),(ec+w,eb+h),(ec,eb+h),(ec,eb+clip)])
 trans=mapping(polygon,pts(root,'gusset-clipped-polygon'))
 expected={'beam-root-double-fillet':[(ec+clip+c['beam_seam_start_margin'],eb),(ec+w-c['beam_seam_end_margin'],eb)],'column-root-double-fillet':[(ec,eb+clip+c['column_seam_start_margin']),(ec,eb+h-c['column_seam_end_margin'])], 'beam-upper-CJP':[(ec,145.3),(ec,158.5)],'beam-lower-CJP':[(ec,-158.5),(ec,-145.3)],'beam-web-two-fillets':[(ec,-c['beam_web_weld_length']/2),(ec,c['beam_web_weld_length']/2)]}
 phi=math.radians(c['phi_deg']);u=np.asarray([math.cos(phi),math.sin(phi)]);v=np.asarray([-math.sin(phi),math.cos(phi)]);origin=-c['workpoint_offset']*v
 single=c['topology']=='single_1L_welded'
 faces=[c['single_angle_face']] if single else ['positive','negative']
 for face in faces:
  for name,V in [('heel',-centroid),('toe',leg-centroid)]:expected['brace-'+face+'-'+name+'-fillet']=[origin+c['brace_weld_start']*u+V*v,origin+(c['brace_weld_start']+c['brace_weld_length'])*u+V*v]
 for gid,p in expected.items():close(pts(root,gid),trans(p),gid)
 # One actual angle section and exactly two fillets on its selected side.
 ids={x.get('id') for x in root.iter() if x.get('id')}
 if single:
  face=c['single_angle_face']; sign=1 if face=='positive' else -1
  forbidden='negative' if face=='positive' else 'positive'
  assert 'T-'+forbidden+'-L' not in ids
  assert not any('brace-'+forbidden+'-'+k+'-fillet' in ids for k in ('heel','toe'))
  assert not any('T-'+forbidden+'-'+k+'-fillet' in ids for k in ('heel','toe'))
  heel,toe,tg=-centroid,leg-centroid,c['plate_t']
  section=np.asarray([(heel-20,-tg/2),(toe+20,-tg/2),(toe+20,tg/2),(heel-20,tg/2),(heel-20,-tg/2)])
  secpts=pts(root,'T-central-gusset')
  if len(secpts)==4:section=section[:4]
  sec=mapping(section,secpts)
  z=sign*tg/2
  outline=[(heel,z),(toe,z),(toe,z+sign*tL),(heel+tL,z+sign*tL),(heel+tL,z+sign*leg),(heel,z+sign*leg)]
  close(pts(root,'T-'+face+'-L'),sec(outline),'actual one-angle section')
  for side,V,d in [('heel',heel,-1),('toe',toe,1)]:
   a=c['brace_weld_leg'];close(pts(root,'T-'+face+'-'+side+'-fillet'),sec([(V,z),(V+d*a,z),(V,z+sign*a)]),'section '+side)
  close(pts(root,'nominal-midplane-axis-z0'),sec([(heel-18,0),(toe+18,0)]),'nominal axis')
 # Independent true plan geometry: two clipped plates per level and all six
 # projected effective weld lines, each explicitly designated double fillets.
 xr,zw,cpw,cclip=138.6,4.95,c['continuity_width'],c['continuity_clip']
 reference=np.asarray([(-xr,zw+cclip),(-xr+cclip,zw),(xr-cclip,zw),(xr,zw+cclip),(xr,zw+cpw),(-xr,zw+cpw)])
 cp=mapping(reference,pts(root,'continuity-positive-clipped-plate'))
 for sign,face in [(1,'positive'),(-1,'negative')]:
  outline=reference.copy();outline[:,1]*=sign;close(pts(root,'continuity-'+face+'-clipped-plate'),cp(outline),face)
  wx=xr-cclip-c['continuity_web_end_margin'];close(pts(root,'continuity-'+face+'-web-double-fillet'),cp([(-wx,sign*zw),(wx,sign*zw)]),face+'web')
  z0=zw+cclip+c['continuity_flange_start_margin'];z1=zw+cpw-c['continuity_flange_end_margin']
  for side,x in [('loaded',xr),('opposite',-xr)]:close(pts(root,'continuity-'+face+'-'+side+'-double-fillet'),cp([(x,sign*z0),(x,sign*z1)]),face+side)
 # Every generated complete-cut moment arc has the correct signed orientation.
 for key in ('beam_cut','upper_column_cut','lower_column_cut'):
  a=r.get('forces',{}).get(key)
  if not a or not a['M']:continue
  path=pts(root,key+'-actual-M');center=trans([a['point']])[0];v1,v2=path[0]-center,path[1]-center
  cross=v1[0]*v2[1]-v1[1]*v2[0];assert cross*a['M']<0,(tag,key,cross,a['M'])
 text=' '.join(x.text or '' for x in root.iter() if x.tag.endswith('text'))
 for term in ('CJP','2 níveis, 4 chapas','Raios não publicados','Não' if False else 'Tração'):assert term in text,(tag,term)
 if single:
  for term in ('uma face, dois filetes','N integral','Não há cancelamento','NBR 6.1.8.2','não exato 3D'):
   assert term in text,(tag,term)
 docpath=native.with_suffix('.docx');docrec=None
 if docpath.exists():
  raw=docpath.read_bytes();doc=Document(BytesIO(raw));doctext='\n'.join([x.text for x in doc.paragraphs]+[x.text for t in doc.tables for row in t.rows for x in row.cells])
  assert digest in doctext and r['status'] in doctext
  for term in ('COMPLETE_CUTS','D · viga completo','U · pilar superior completo','L · pilar inferior DERIVADO','quatro chapas','CJP','fabricação','estabilidade global'):assert term in doctext,(tag,term)
  if r['status']=='FAIL':assert 'não tem conclusão local favorável completa' in doctext
  if single:
   for term in ('Cantoneira única 1L','Esses momentos não se cancelam','eixo terminal nominal adotado em z=0'):
    assert term in doctext,(tag,term)
  if 'detailed' in tag:assert all(x['id'] in doctext for x in r['checks'])
  z=zipfile.ZipFile(BytesIO(raw));media=[z.read(n) for n in z.namelist() if n.startswith('word/media/')]
  assert native.with_suffix('.png').read_bytes() in media,tag
  (out/(tag+'_word.txt')).write_text(doctext)
  docrec={'bytes':len(raw),'embedded_actual_png_identical':True,'input_fingerprint_verified':True,'all_primitive_ids_in_detailed':True if 'detailed' in tag else None}
 else:assert r['status'] in ('UNVERIFIED','INVALID','NUMERICAL_FAILURE') or (r['status']=='FAIL' and r.get('complete') is False),tag
 records.append({'tag':tag,'status':r['status'],'main_coordinate_paths_verified':len(expected),'continuity_clipped_polygons_verified':2,'continuity_effective_weld_paths_verified':6,'signed_moment_arcs_verified':bool(r.get('forces')),'word':docrec})
result={'passed':True,'cases':records,'scope':'Actual exported SVG coordinates and moment orientation, exact native/result input identity, physical continuity paths, Word statuses and embedded downloadable PNG provenance. Pixels are separately reviewed.'}
(out/'ARTIFACT_SEMANTICS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False,indent=2))
