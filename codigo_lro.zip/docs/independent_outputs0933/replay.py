"""Portable output replay; requires application and external evidence-output roots."""
from pathlib import Path
import argparse,sys,json,hashlib,subprocess,importlib.metadata,zipfile
p=argparse.ArgumentParser();p.add_argument('runtime',type=Path);p.add_argument('output',type=Path);p.add_argument('--mode',choices=['all','captures','callbacks','navigation'],default='all');p.add_argument('--functional-only',action='store_true');a=p.parse_args()
r=Path(__file__).resolve().parent;s=a.runtime.resolve();out=a.output.resolve();out.mkdir(parents=True,exist_ok=True)
assert not out.is_relative_to(s),'Keep generated replay evidence outside the application.'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
canonical=lambda x:hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
expected=json.loads((r/'EXPECTED_OUTPUTS.json').read_text());h=json.loads((r/'RUNTIME_HASHES.json').read_text())
if (s/'codigo_lro.zip').exists():
 with zipfile.ZipFile(s/'codigo_lro.zip') as z:assert all(hashlib.sha256(z.read(k)).hexdigest()==v for k,v in h.items())
else:assert all(sha(s/k)==v for k,v in h.items())
if not a.functional_only:
 assert sys.version_info[:2]==(3,12),'Exact replay requires recorded Python 3.12.'
 for k,v in expected['package_versions'].items():assert importlib.metadata.version(k)==v,(k,v,importlib.metadata.version(k))
def run(name,dest,*extra):
 with (out/(name+'.log')).open('w') as log:
  subprocess.run([sys.executable,'-B',str(r/name),str(s),str(dest),*map(str,extra)],stdout=log,stderr=subprocess.STDOUT,check=True)
checks=[]
if a.mode in ('all','captures'):
 cap=out/'captures';run('capture_single_corner.py',cap)
 with (out/'semantics.log').open('w') as log:subprocess.run([sys.executable,'-B',str(r/'artifact_semantics.py'),str(cap),str(out/'semantics')],stdout=log,stderr=subprocess.STDOUT,check=True)
 if not a.functional_only:
  for row in expected['cases']:
   tag=row['tag'];assert json.loads((cap/(tag+'.json')).read_text())==row['native'];assert canonical(json.loads((cap/(tag+'.results.json')).read_text()))==row['result_json_sha256'];assert sha(cap/(tag+'.png'))==row['png_sha256']
   if row['resistant_report_ready']:
    with zipfile.ZipFile(cap/(tag+'.docx')) as z:assert {n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.startswith('word/')}==row['word_content_sha256']
 checks.append('14 actual capture scenarios and independent SVG/Word semantics')
if a.mode in ('all','callbacks'):
 run('ui_single_corner_acceptance.py',out/'single_callbacks');run('ui_legacy_corner_acceptance.py',out/'legacy_callbacks');checks.append('9 single-adapter and 13 legacy callback groups')
if a.mode in ('all','navigation'):
 run('route_snapshot.py',out/'navigation')
 if not a.functional_only:
  got=json.loads((out/'navigation/ROUTE_NATIVE_SNAPSHOT.json').read_text());assert {k:canonical(v) for k,v in got.items()}==expected['routes']
 # Outer APP has no source import path; convention properties are already in the source/runtime gate.
 if not (s/'codigo_lro.zip').exists():
  keys=out/'convention_keys.json';keys.write_text(json.dumps(expected['old_convention_keys']));run('conventions_snapshot.py',out/'conventions.json',keys)
  if not a.functional_only:assert canonical(json.loads((out/'conventions.json').read_text()))==expected['conventions_sha256']
 checks.append('19 routes forward and reverse; prior convention comparison when source root supplied')
receipt={'passed':True,'mode':a.mode,'exact_recorded_environment':not a.functional_only,'runtime_files_verified':len(h),'checks':checks,'not_claimed':['Browser/clipboard clicks','Automatic visual inspection','Numerical method approval']}
(out/'OUTPUT_REPLAY_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
