# Independent output replay evidence

Finite output acceptance for the 1L adapter inside the existing 19-route application. See OUTPUT_ACCEPTANCE.json and VISUAL_ACCEPTANCE.json. The 134-file runtime identity is RUNTIME_HASHES.json. This folder contains no report or image binaries.

Original acceptance exercised actual Streamlit AppTest callbacks and actual emitted media bytes, not browser download or clipboard clicks. Fourteen cases produced native/result JSON and drawings; nine complete cases produced Word. Incomplete and mixed failure/unverified cases blocked resistant Word. All nineteen routes were traversed forward and reverse. The original final source gate inspected 57 downloaded-report pages and 31 distributed-report pages. Visual reinspection is not automated by this replay.

Use Python 3.12 and the package versions recorded in EXECUTION_ENVIRONMENT.json for exact output replay. Run replay.py with the application source root (or an extracted APP-only root) and an external output directory. All modes verify the accepted runtime hashes first. The exact mode requires the recorded versions before comparing result/PNG/Word-content and route hashes. The functional-only option runs the callback assertions without making cross-version byte-equivalence claims. It does not replace the pinned exact gate.

Examples: python -B replay.py /path/to/app /path/to/replay-output --mode all
Use --mode captures, callbacks or navigation to select a subset. This wrapper was assembled from the independently executed scripts and validated structurally; the original source receipt establishes source acceptance. The final extracted APP-only gate is separate and still pending; no final package acceptance is asserted here.

The expected file preserves small native inputs and hashes of larger original artifacts; the large original rendered pages and route snapshots remain review evidence outside the application bundle. Distributed example artifacts are under examples/single_angle_corner0933. Numerical qualification and full spatial/fatigue/seismic/global/fabrication behavior remain outside this output replay.
