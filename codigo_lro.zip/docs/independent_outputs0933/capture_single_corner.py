"""Independent actual main-app callbacks and media bytes. No production edits."""
from pathlib import Path
from dataclasses import replace
import sys,json,hashlib,os
source=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();out.mkdir(parents=True,exist_ok=True);sys.path.insert(0,str(source))
from streamlit.testing.v1 import AppTest
from streamlit.runtime.memory_media_file_storage import MemoryMediaFileStorage
if (source/'codigo_lro.zip').exists():
 at=AppTest.from_file(str(source/'app.py'),default_timeout=300).run();assert not at.exception
 runtime=Path(sys.modules['lro'].__file__).resolve().parent.parent
 (out/'LOADER_BOOTSTRAP.json').write_text(json.dumps({'actual_outer_entry':str(source/'app.py'),'loaded_runtime_root':str(runtime),'standalone_root_files':sorted(p.name for p in source.iterdir())},indent=2))
from lro.corner_gusset import CornerGusset as C,FAMILY,analyze
from lro.corner_gusset_ui import PROJECT,RESULT,REPORT,decode_project,checks_complete
from lro.corner_gusset_presentation import input_fingerprint
files={};original=MemoryMediaFileStorage.load_and_get_id
def tap(storage,*args,**kwargs):
 identity=original(storage,*args,**kwargs);files[identity]=storage._files_by_id[identity].content;return identity
MemoryMediaFileStorage.load_and_get_id=tap

def button(at,label):return next(x for x in at.button if x.label==label)
def visible(at):return '\n'.join(str(x.value) for k in ('title','caption','info','warning','error','success','markdown','text_area','code') for x in getattr(at,k))
def capture(c,tag,detailed=False):
 at=AppTest.from_file(str(source/'app.py'),default_timeout=300)
 at.session_state['connection_family']=FAMILY;at.session_state[PROJECT]=c.to_dict();at.run()
 assert not at.exception,[x.message for x in at.exception]
 assert len(at.selectbox(key='connection_family').options)==19
 assert at.session_state[PROJECT]==c.to_dict();r=at.session_state[RESULT];assert r==analyze(c)
 if detailed:at.checkbox(key='cg_report_detailed').check().run();assert not at.exception
 ready=checks_complete(r)
 if ready:button(at,'Gerar memória de canto').click().run();assert not at.exception
 else:assert button(at,'Gerar memória de canto').disabled
 exports={}
 for item in at.get('download_button'):
  data=files[Path(item.proto.url).name.rsplit('.',1)[0]]
  ext='.png' if data.startswith(b'\x89PNG') else '.docx' if data.startswith(b'PK') else '.svg' if b'<svg' in data[:1000] else '.json' if data.lstrip().startswith(b'{') else '.txt'
  if ext=='.json' and 'connection' not in json.loads(data):ext='.results.json'
  target=out/(tag+ext);target.write_bytes(data);exports[ext]={'path':str(target),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'label':item.label}
 assert {'.png','.svg','.json','.results.json'}<=set(exports),exports
 assert json.loads(Path(exports['.json']['path']).read_text())==c.to_dict()
 assert decode_project(Path(exports['.json']['path']).read_bytes())==c
 assert json.loads(Path(exports['.results.json']['path']).read_text())=={'input':c.to_dict(),'result':r}
 assert ('.docx' in exports)==ready
 assert input_fingerprint(c) in Path(exports['.svg']['path']).read_text()
 (out/(tag+'_ui.txt')).write_text(visible(at))
 return {'tag':tag,'status':r['status'],'issues':r.get('issues'),'report_detailed':detailed,'resistant_report_ready':ready,'input_sha256':input_fingerprint(c),'exports':exports}
base=C(topology='single_1L_welded',symmetric=False)
cases=[('C1_positive_compact',base,False),('C1_positive_detailed',base,True),('C1_negative_compact',replace(base,single_angle_face='negative'),False),('N150_current',replace(base,P=150000.),False),('gerdau_row34',replace(base,angle_profile='GERDAU_EQUAL_ANGLE_P03_R34'),False),('high_force_failure',replace(base,P=1e6),False),('missing_other_load_declaration',replace(base,other_loads_excluded=False),False),('eccentric_line',replace(base,workpoint_offset=100),False),('shifted40_compressed',replace(base,phi_deg=40,brace_weld_start=700.),False),('phi40_current',replace(base,phi_deg=40),False),('phi50_current',replace(base,phi_deg=50),False),('mixed_offset_failure',replace(base,workpoint_offset=100.,P=1e6),False),('mixed_cjp_failure',replace(base,matching_cjp=False,P=1e6),False),('zero_brace_frame_retained',replace(base,P=0.),False)]

records=json.loads((out/'DOWNLOAD_RECEIPT.json').read_text()) if os.environ.get('ONLY') and (out/'DOWNLOAD_RECEIPT.json').exists() else []
for tag,c,detailed in cases:
 if os.environ.get('ONLY') and os.environ['ONLY'] not in tag:continue
 print('CAPTURE',tag,flush=True);record=capture(c,tag,detailed);records=[x for x in records if x['tag']!=tag];records.append(record);(out/'DOWNLOAD_RECEIPT.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n');print('PASS',tag,records[-1]['status'],flush=True)
