"""Independent actual Streamlit callbacks, native imports and state failures."""
from pathlib import Path
from dataclasses import replace
from copy import deepcopy
import sys,json,hashlib
source=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();out.mkdir(parents=True,exist_ok=True);sys.path.insert(0,str(source))
from streamlit.testing.v1 import AppTest
from streamlit.runtime.memory_media_file_storage import MemoryMediaFileStorage
if (source/'codigo_lro.zip').exists():
 boot=AppTest.from_file(str(source/'app.py'),default_timeout=300).run();assert not boot.exception
from lro.corner_gusset import CornerGusset as C,FAMILY,analyze,MATERIALS,MEMBER_CATALOG
from lro.corner_gusset_ui import PROJECT,RESULT,REPORT,DRAFT,ACCEPTED,TEMPLATE,decode_project,checks_complete
from lro.corner_gusset_presentation import memory_text,input_fingerprint,physical_envelopes
from lro.angle_catalog import catalog,label
files={};original=MemoryMediaFileStorage.load_and_get_id
def tap(storage,*args,**kwargs):
 identity=original(storage,*args,**kwargs);files[identity]=storage._files_by_id[identity].content;return identity
MemoryMediaFileStorage.load_and_get_id=tap
records=[]
def record(name,**kw):
 records.append({'name':name,'passed':True,**kw});(out/'UI_CALLBACK_ACCEPTANCE.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n');print('PASS',name,flush=True)
def run(at):
 at.run();assert not at.exception,[x.message for x in at.exception];return at
def button(at,name):return next(x for x in at.button if x.label==name)
def export(at,label):
 item=next(x for x in at.get('download_button') if x.label==label);return files[Path(item.proto.url).name.rsplit('.',1)[0]]
def native(at):return export(at,'Salvar projeto de canto .json')
def upload(at,data):
 if not isinstance(data,bytes):data=json.dumps(data,ensure_ascii=False).encode()
 at.get('file_uploader')[0].upload('independent-corner.json',data,'application/json').run();button(at,'Carregar projeto de canto').click();return run(at)
def current_mc(at):
 items=[x.value for x in at.code if 'MEMÓRIA LOCAL' in x.value]+[x.value for x in at.text_area if 'MEMÓRIA LOCAL' in str(x.value)]
 assert len(items)==1,items;return items[0]
def fresh(c=None):
 at=AppTest.from_file(str(source/'app.py'),default_timeout=300);at.session_state['connection_family']=FAMILY;at.session_state[PROJECT]=(c or C()).to_dict();return run(at)

base=C();at=fresh()
assert at.session_state[RESULT]['status']=='PASS'
assert len(at.selectbox(key='connection_family').options)==19
assert at.session_state[PROJECT]==base.to_dict() and decode_project(native(at))==base
assert at.number_input(key='cg_P_kN').value==100
assert at.number_input(key='cg_beam_cut_M_kNm').value==62.3
assert at.number_input(key='cg_upper_column_cut_Fy_kN').value==-500
assert current_mc(at)==memory_text(base)
r=at.session_state[RESULT];assert len(physical_envelopes(r))<len(r['checks'])
assert not any(k in [str(x.key) for x in at.number_input] for k in ('cg_alpha','cg_beta','cg_beam_seam_length','cg_column_seam_length','cg_N0','cg_V0','cg_M0'))
assert json.loads(export(at,'Baixar resultados completos de canto .json'))=={'input':base.to_dict(),'result':r}
record('C1 native, complete-cut units, current MC and concise default envelopes',primitive_checks=len(r['checks']),physical_components=len(physical_envelopes(r)))

# Imported raw scalar precision survives reruns and unrelated material edits.
precise=replace(base,P=123456.78901234567,phi_deg=45.000000000000014,beam_cut_M=62300000.12345679)
upload(at,precise.to_dict());assert at.session_state[PROJECT]==precise.to_dict();assert decode_project(native(at))==precise
at.selectbox(key='cg_column_steel').set_value('ASTM A36');run(at)
changed=replace(precise,column_steel='ASTM A36');assert at.session_state[PROJECT]==changed.to_dict();assert current_mc(at)==memory_text(changed)
for material in ('angle_steel','gusset_steel','beam_steel','continuity_steel'):assert at.session_state[PROJECT]['connection'][material]==getattr(precise,material)
record('Exact imported precision and isolated column steel with current MC')

upload(at,base.to_dict())
for key in ('angle_steel','gusset_steel','beam_steel','column_steel','continuity_steel'):
 before=deepcopy(at.session_state[PROJECT]['connection']);target=next(v for v in MATERIALS if v!=before[key]);at.selectbox(key='cg_'+key).set_value(target);run(at)
 after=at.session_state[PROJECT]['connection'];assert {k:v for k,v in before.items() if k!=key}=={k:v for k,v in after.items() if k!=key}
for key in ('fw_brace','fw_root','fw_joint','fw_continuity'):
 before=deepcopy(at.session_state[PROJECT]['connection']);at.number_input(key='cg_'+key).set_value(before[key]+10);run(at)
 after=at.session_state[PROJECT]['connection'];assert {k:v for k,v in before.items() if k!=key}=={k:v for k,v in after.items() if k!=key}
record('Five independent steels and four independent consumables')

upload(at,base.to_dict());at.checkbox(key='cg_include_small_angles').check();run(at)
ger=[k for k in catalog() if k.startswith('GERDAU_')];assert len(ger)==50
assert all(label(k) in at.selectbox(key='cg_angle_profile').options for k in ger)
assert set(MEMBER_CATALOG)==set(at.selectbox(key='cg_beam_profile').options)==set(at.selectbox(key='cg_column_profile').options)
record('All fifty Gerdau angles and actual member catalog choices',gerdau_count=len(ger),member_count=len(MEMBER_CATALOG))

upload(at,base.to_dict());button(at,'Gerar memória de canto').click();run(at);assert REPORT in at.session_state
report=at.session_state[REPORT];run(at);assert at.session_state[REPORT]==report
at.number_input(key='cg_P_kN').set_value(150);run(at);assert REPORT not in at.session_state
assert current_mc(at)==memory_text(replace(base,P=150000.))
at.number_input(key='cg_P_kN').set_value(1000);run(at);assert at.session_state[RESULT]['status']=='FAIL';assert not at.success
button(at,'Gerar memória de canto').click();run(at);assert REPORT in at.session_state
record('Repeated valid report retained, edit retires stale report, real resistance failure stays reportable')

for tag,c,status,issue in [('missing',replace(base,other_loads_excluded=False),'UNVERIFIED','missing_other_loads'),('eccentric',replace(base,workpoint_offset=100),'UNVERIFIED','UNVERIFIED_ECCENTRIC_DISTRIBUTION'),('compression',replace(base,phi_deg=80,plate_height=1600,brace_weld_start=1300,column_seam_end_margin=1010,upper_column_cut_y=1900.,upper_column_cut_M=19000000.),'UNVERIFIED','UNVERIFIED_COMPRESSION_COMPONENT')]:
 upload(at,c.to_dict());r=at.session_state[RESULT];assert r['status']==status and issue in [i['id'] for i in r['issues']]
 assert not at.success and REPORT not in at.session_state and button(at,'Gerar memória de canto').disabled
 assert current_mc(at)==memory_text(c)
record('Missing loading, eccentric distribution and compressed gusset remain specifically unverified with no favorable report')

upload(at,base.to_dict());button(at,'Gerar memória de canto').click();run(at)
# Upload without clicking Load must not apply it or retire accepted outputs.
other=replace(base,P=77777.)
saved={k:deepcopy(at.session_state[k]) for k in (PROJECT,RESULT,REPORT,ACCEPTED,TEMPLATE)}
at.get('file_uploader')[0].upload('interrupted.json',json.dumps(other.to_dict()).encode(),'application/json').run();assert not at.exception
for k,v in saved.items():assert at.session_state[k]==v,k
run(at)
for k,v in saved.items():assert at.session_state[k]==v,k
record('Interrupted uploader and repeated rerun preserve the accepted project and report')

for corrupt in ('missing','null','unknown','wrong_units','wrong_identity','fixed_assumptions','boolean','nan','duplicate','old_family'):
 saved={k:deepcopy(at.session_state[k]) for k in (PROJECT,RESULT,REPORT,DRAFT,ACCEPTED,TEMPLATE)};bad=deepcopy(base.to_dict())
 if corrupt=='missing':bad['connection'].pop('beam_cut_Fy')
 elif corrupt=='null':bad['connection']['upper_column_cut_M']=None
 elif corrupt=='unknown':bad['connection']['fake_N0']=0
 elif corrupt=='wrong_units':bad['units']['force']='kN'
 elif corrupt=='wrong_identity':bad['connection_type']='welded_double_angle_gusset'
 elif corrupt=='fixed_assumptions':bad['fixed_assumptions']['gusset_count']=2
 elif corrupt=='boolean':bad['connection']['P']=True
 elif corrupt=='nan':bad['connection']['beam_cut_Fx']=float('nan')
 elif corrupt=='duplicate':bad=json.dumps(bad).replace('"connection": {','"connection": {"P": 0,').encode()
 elif corrupt=='old_family':
  from lro.welded_double_angle_gusset import WeldedDoubleAngleGusset
  bad=WeldedDoubleAngleGusset().to_dict()
 upload(at,bad);assert any('Não foi possível abrir' in x.value for x in at.error),corrupt
 for key,value in saved.items():assert at.session_state[key]==value,(corrupt,key)
record('Ten malformed or wrong-family imports reject atomically; missing actions never default to zero')

upload(at,base.to_dict());at.number_input(key='cg_P_kN').set_value(1e308);run(at)
assert at.session_state[RESULT]['status'] in ('INVALID','NUMERICAL_FAILURE') and PROJECT not in at.session_state and REPORT not in at.session_state
assert not at.get('download_button')
at.number_input(key='cg_P_kN').set_value(100);run(at);assert at.session_state[RESULT]['status']=='PASS';assert current_mc(at)==memory_text(base)
record('Unrepresentable conversion retires all stale exports; ordinary edit recovers')

# Explicit case declaration and signed lower-cut comparison.
upload(at,replace(base,compare_lower_cut=True).to_dict());assert at.session_state[RESULT]['status']=='PASS'
at.number_input(key='cg_lower_column_check_Fx_kN').set_value(-49);run(at);assert at.session_state[RESULT]['status']!='PASS'
upload(at,base.to_dict());at.text_area(key='cg_other_loads_json').set_value('[');run(at);assert PROJECT not in at.session_state and REPORT not in at.session_state
at.text_area(key='cg_other_loads_json').set_value('[]');run(at);assert at.session_state[RESULT]['status']=='PASS'
record('Same-cut comparison rejects disagreement; interrupted freeform other-load list fails closed and recovers')
print('COMPLETE',len(records),'independent groups',flush=True)
# Actual external load list is explicit and enters the same free body once.
load={'label':'Carga independente de ensaio','member':'beam','point':[900.,0.],'Fx':1000.,'Fy':-2000.,'M':10000.}
explicit=replace(base,other_loads_excluded=False,other_loads=(load,))
upload(at,explicit.to_dict());assert at.session_state[PROJECT]==explicit.to_dict()
r=at.session_state[RESULT];assert r['status']=='PASS'
assert abs(r['forces']['lower_column_cut']['Fx']-(-51000.))<1e-7
assert abs(r['forces']['lower_column_cut']['Fy']-481289.32188134524)<1e-7
assert current_mc(at)==memory_text(explicit)
record('Explicit valid other load enters the same-cut lower equilibrium once')

button(at,'Gerar memória de canto').click();run(at)
saved={k:deepcopy(at.session_state[k]) for k in (PROJECT,RESULT,REPORT)}
options=at.selectbox(key='connection_family').options
for other_family in options:
 if other_family==FAMILY:continue
 at.selectbox(key='connection_family').set_value(other_family);run(at)
at.selectbox(key='connection_family').set_value(FAMILY);run(at)
for k,v in saved.items():assert at.session_state[k]==v,k
assert current_mc(at)==memory_text(explicit)
record('Edited nineteenth-route project and report survive visiting all eighteen other routes')
print('COMPLETE',len(records),'independent groups including full edited-route return',flush=True)

for c in (replace(base,workpoint_offset=100.,P=1e6),replace(base,matching_cjp=False,P=1e6),replace(base,P=-100000.)):
 upload(at,c.to_dict());r=at.session_state[RESULT]
 assert r['status']=='FAIL' and r['complete'] is False
 assert not checks_complete(r) and button(at,'Gerar memória de canto').disabled and REPORT not in at.session_state
 assert any('INCOMPLETA' in str(x.value) for kind in ('error','warning','caption') for x in getattr(at,kind))
record('Mixed resistance failures and unqualified methods stay explicitly incomplete and block resistant Word')
print('COMPLETE',len(records),'final independent callback groups',flush=True)
