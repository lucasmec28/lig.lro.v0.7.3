import sys,hashlib,json
from pathlib import Path
from dataclasses import asdict
sys.path.insert(0,str(Path(sys.argv[1]).resolve()))
from lro import load_conventions as m
keys=json.loads(Path(sys.argv[3]).read_text()) if len(sys.argv)>3 else list(m.CONVENTIONS)
result=[]
for key in keys:
 result.append(dict(kind='record',key=key,data=asdict(m.CONVENTIONS[key])))
 result.append(dict(kind='legend',key=key,data=m.sign_legend(key)))
 for value in [-100000.,0.,100000.,None]:result.append(dict(kind='axial_nature',key=key,N=value,data=m.axial_nature(key,value)))
 for orient in ['beam','column']:
  result.append(dict(kind='description',key=key,orientation=orient,data=m.reference_description(key,orientation=orient)))
  for theta in [15.,45.,90.,135.]:
   svg=m.convention_svg(key,orientation=orient,theta_deg=theta)
   result.append(dict(kind='svg',key=key,orientation=orient,theta=theta,sha256=hashlib.sha256(svg.encode()).hexdigest()))
Path(sys.argv[2]).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
if len(sys.argv)<=3:Path(sys.argv[2]).with_name('OLD_CONVENTION_KEYS.json').write_text(json.dumps(keys)+'\n')
print(len(keys),'legacy conventions;',sum(x['kind']=='svg' for x in result),'SVG variants')
