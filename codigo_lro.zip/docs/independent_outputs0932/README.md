# Evidência independente de interface e saídas

Os recibos, scripts e treze entradas capturadas foram copiados sem alteração. `PACKAGE_MANIFEST.json` registra os hashes e a fronteira de distribuição. Caminhos absolutos nos recibos originais registram a execução de revisão; as imagens/páginas maiores daquele diretório não são alegadas como arquivos do APP. Figuras e relatórios C1/phi50 distribuídos estão em `examples/corner_gusset0932`.

Com os requisitos do aplicativo instalados, a partir da raiz da fonte, estes comandos reproduzem os callbacks e os bytes reais de exportação em uma pasta nova:

```sh
python -B docs/independent_outputs0932/ui_corner_acceptance.py . replay_outputs0932/callbacks
python -B docs/independent_outputs0932/capture_corner.py . replay_outputs0932/captures
python -B docs/independent_outputs0932/artifact_semantics.py replay_outputs0932/captures replay_outputs0932/semantics
```

Os scripts de captura recebem caminhos explícitos e não alteram a fonte. O motor é qualificado separadamente por `docs/ENGINE_ACCEPTANCE0932.json`. A aceitação de interface usa callbacks Streamlit e bytes de mídia reais, não cliques em navegador completo ou área de transferência. A revisão visual original inspecionou 54 páginas; o relatório resumido de ações todas nulas tem sete páginas por preservar empates de utilização zero. O caso C1 resumido tem cinco e o detalhado dezesseis.
