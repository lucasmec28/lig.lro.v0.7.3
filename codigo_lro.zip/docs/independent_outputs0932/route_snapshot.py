import sys,json,re,hashlib
from pathlib import Path
SOURCE=Path(sys.argv[1]).resolve();OUT=Path(sys.argv[2]).resolve();OUT.mkdir(parents=True,exist_ok=True);sys.path.insert(0,str(SOURCE))
from streamlit.testing.v1 import AppTest
from streamlit.runtime.memory_media_file_storage import MemoryMediaFileStorage
files={};original=MemoryMediaFileStorage.load_and_get_id

def tap(storage,*args,**kwargs):
 key=original(storage,*args,**kwargs);files[key]=storage._files_by_id[key].content;return key
MemoryMediaFileStorage.load_and_get_id=tap
at=AppTest.from_file(str(SOURCE/'app.py'),default_timeout=120).run();assert not at.exception
options=at.selectbox(key='connection_family').options
record={}
def snap():
 exports={}
 for item in at.get('download_button'):
  data=files[Path(item.proto.url).name.rsplit('.',1)[0]]
  if data.lstrip().startswith(b'{'):
   try:exports[item.label]=json.loads(data)
   except:pass
 return exports
for family in options:
 print('ROUTE',family,flush=True);at.selectbox(key='connection_family').set_value(family).run();assert not at.exception,[x.message for x in at.exception]
 exports=snap();assert exports,family
 record[at.selectbox(key='connection_family').value]={'exports':exports,'title':[x.value for x in at.title], 'result': {k:v for k,v in at.session_state._state.filtered_state.items() if 'result' in k and isinstance(v,dict) and ('status' in v or 'checks' in v)}}
# Repeated routes must preserve native projects after traversing every other route.
for family in reversed(options):
 at.selectbox(key='connection_family').set_value(family).run();assert not at.exception
 assert snap()==record[at.selectbox(key='connection_family').value]['exports'],family
(OUT/'ROUTE_NATIVE_SNAPSHOT.json').write_text(json.dumps(record,ensure_ascii=False,indent=2,default=str))
print('PASS',len(options),'forward+reverse routes',flush=True)
