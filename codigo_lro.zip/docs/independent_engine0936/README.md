# Portable engine/native evidence replay

This directory is evidence, not an application package. Nothing is archived, published or installed. It contains byte-identical original acceptance records and legacy numerical baseline, two path-only script adaptations, their provenance, and a separate replay wrapper.

## Run

Use an existing Python environment with the application dependencies and pytest available:

    python replay.py --source /absolute/path/to/application/code --output /absolute/path/to/new/empty/output

The source directory must contain `lro/` and `data/`. The default qualification directory is:

    SOURCE/docs/qualification_bolted_corner_compression0936

Use `--qualification /absolute/path/to/approved/qualification` to select another location. Use repeatable `--dependency-dir /absolute/path/to/existing/python/dependencies` when dependencies are installed outside the selected Python environment. The wrapper installs nothing. If `--output` is omitted, it creates and prints a fresh system temporary directory.

The wrapper verifies all six final accepted engine hashes before and after replay, all original evidence and portable-copy hashes, the saved legacy snapshot, and all approved qualification manifest entries. It writes only to the separate output directory, with bytecode generation disabled.

## Exact counts and preservation limitation

- Original source acceptance: **287 passed**, zero skipped. Original records remain unchanged under `original/`.
- Portable implementation replay: **286 tests**, zero skipped, with the one source-only test explicitly deselected.
- Portable legacy replay: **22 cases and 148,262 numerical/status comparisons** against the saved baseline, without running or needing the earlier source.
- The deselected `test_immutable0935_tree_preserved` originally checked all 1,740 files in the immutable 0.9.35 source tree. That absent tree cannot be rechecked portably. The wrapper separately verifies the integrity of the original successful preservation receipt and its complete stored hash list. This is not counted as a replacement implementation test, and no new claim is made about absent files.

`ADAPTATION_PROVENANCE.json` records original and adapted hashes. `PATH_ONLY_ADAPTATIONS.diff` shows all changes to copied test/parity scripts: only path resolution, an `os` import, and the new output location. Mechanical assertions, parameters, tolerances, and parity comparisons are unchanged.

No original workspace path or original 0.9.35 source is needed. The caller supplies only the current application code, its approved qualification data, existing Python dependencies and a writable result destination.

## Outcome

The output includes `PORTABLE_ENGINE_TESTS.xml`, test and parity logs, `LEGACY_PARITY0936.json`, and `PORTABLE_REPLAY_RECEIPT.json`. A successful portable receipt requires exactly 286 passing implementation tests, all 22 legacy cases and 148,262 comparisons, and matching accepted source hashes before and after execution.

This replay does not run the full application aggregate, UI, drawing, report, packaging or release gates. It does not authorize fabrication or verify global brace/member stability. BCC1 must remain a calculated full-joint FAIL despite passing local compression checks.
