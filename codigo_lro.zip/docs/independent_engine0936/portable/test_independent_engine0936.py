"""Independent finite engine/native acceptance for the approved bounded method.

Tests consume the frozen reviewed ORACLE as data, never the candidate calculator.
Legacy parity data were captured read-only before implementation readiness.
"""
from copy import deepcopy
from dataclasses import replace
from functools import lru_cache
import hashlib,json,math,os,re,sys
from pathlib import Path
import pytest

HERE=Path(os.environ['LRO_EVIDENCE_ORIGINAL']).resolve()
WORK=HERE.parents[1]
SOURCE=Path(os.environ['LRO_ACCEPT_SOURCE']).resolve()
SCOPE=Path(os.environ['LRO_QUALIFICATION']).resolve()
sys.path.insert(0,str(SOURCE))
from lro.corner_gusset import CornerGusset,analyze,geometry,presets,MATERIALS
from lro.corner_compression import declare_current_detail,geometry_stamp,RESTRAINT_FIELDS

ORACLE=json.loads((SCOPE/'ORACLE.json').read_text())
FIXTURE=json.loads((SCOPE/'FIXTURE_INPUT.json').read_text())
MANIFEST=json.loads((SCOPE/'MANIFEST.json').read_text())
FRICTION_FIELDS=('bolt_friction_type','bolt_surface_class','bolt_installation_source',
 'bolt_hardened_washer_count','bolt_washer_location','bolt_washer_diameter',
 'bolt_angle_continuation','bolt_continuation_source','combination_type')
DETAIL='Independent acceptance: frozen hypothetical BCC1 ordinary corner, real welded roots and Class B direct-contact pretensioned two-angle stations restrain transverse translation and twist. Local scope only.'


def bcc(**kw):
    """Construct the reviewed physical input independently of the product preset."""
    values=dict(plate_width=300.,plate_height=300.,plate_t=12.,corner_clip=30.,
        topology='symmetric_2L_T_bolted',P=-100000.,bolt_start=385.,bolt_pitch=60.,
        bolt_count=4,bolt_gauge=40.,bolt_angle_end=35.,bolt_diameter=16.,
        bolt_heel_extent=13.94,bolt_heel_extent_source='Frozen qualification assumption t+6 mm; no rolled-radius inference.',
        bolt_pretensioned=True,bolt_washer_stack=4.,bolt_friction_type=True,
        bolt_surface_class='B',bolt_installation_source='Hypothetical qualification Class B preparation, pretension and inspection detail.',
        bolt_hardened_washer_count=1,bolt_washer_location='rotating',bolt_washer_diameter=32.,
        bolt_angle_continuation=60.,bolt_continuation_source='Intact angle continuing at least60 mm clear beyond last hole.',
        combination_type='normal_ultimate',case_id='BCC1_INDEPENDENT_ENGINE_ACCEPTANCE')
    values.update(kw)
    return declare_current_detail(replace(CornerGusset(),**values),DETAIL)


@lru_cache(maxsize=16)
def main_result(p=-100000.):return analyze(bcc(P=p))
def rows(r):return {x['id']:x for x in r['checks']}
def issues(r):return {x['id'] for x in r['issues']}
def slips(r):return {k:v for k,v in rows(r).items() if re.fullmatch(r'bolt\d+_service_slip',k)}
def assert_close(a,b,rel=1e-9,abs_=1e-6):
    if isinstance(b,(list,tuple)):
        assert len(a)==len(b)
        for aa,bb in zip(a,b):assert_close(aa,bb,rel,abs_)
    elif isinstance(b,dict):
        for k,v in b.items():assert_close(a[k],v,rel,abs_)
    else:assert a==pytest.approx(b,rel=rel,abs=abs_)


@pytest.mark.parametrize('name',list(MANIFEST['files']))
def test_binding_source_hashes(name):
    assert hashlib.sha256((SCOPE/name).read_bytes()).hexdigest()==MANIFEST['files'][name]['sha256']


def test_approved_fixture_is_exact_and_not_rescued():
    c=bcc();r=main_result();g=r['geometry']
    assert c.P==-100000. and c.plate_width==c.plate_height==300.
    assert g['bolt_stations']==[385.,445.,505.,565.]
    assert_close(g['polygon'],FIXTURE['geometry']['gusset_polygon'])
    assert_close(g['beam_seam'],FIXTURE['geometry']['beam_seam'])
    assert_close(g['column_seam'],FIXTURE['geometry']['column_seam'])
    assert_close(g['bolt_grip'],31.88)
    assert g['physical_gusset_count']==1 and g['physical_shear_planes']==2
    assert r['brace']['weld_count']==0 and r['brace']['physical_bolt_count']==4
    assert r['status']=='FAIL' and r['complete'] and r['mechanics_complete'] and r['assembly_qualified']
    assert not r['approved']
    recv=rows(r)['continuity_top_concurrent_column_receiver_bound']
    assert recv['status']=='FAIL'
    assert_close(recv['utilization'],1.0101145936065872)
    assert not recv.get('diagnostic_only',False)
    preset=next(c for n,c in presets().items() if n.startswith('BCC1 ·'))
    for k in ('P','plate_width','plate_height','plate_t','corner_clip','bolt_start','bolt_pitch','bolt_count','bolt_diameter','bolt_washer_stack','beam_cut_Fx','beam_cut_Fy','beam_cut_M','upper_column_cut_Fx','upper_column_cut_Fy','upper_column_cut_M'):
        assert getattr(preset,k)==getattr(c,k)


def production_row_id(oracle_id):
    z=re.fullmatch(r'bolt(\d+)_shear_plane(\d+)',oracle_id)
    if z:return f'2L-T_bolt{z[1]}_plane{z[2]}'
    z=re.fullmatch(r'(angle|gusset)_bearing(\d+)',oracle_id)
    if z:return ('2L-T_' if z[1]=='angle' else 'common_')+oracle_id
    return {'gusset_whitmore_compression_buckling':'gusset_centered_whitmore_compression_buckling',
        'gusset_actual_net_body_VM_yield_supplement':'gusset_actual_net_body_yield'}.get(oracle_id,oracle_id)


@pytest.mark.parametrize('expected',ORACLE['checks'],ids=lambda x:x['id'])
def test_all_27_independent_local_strength_witnesses(expected):
    got=rows(main_result())[production_row_id(expected['id'])]
    for k in ('demand','resistance','utilization'):assert_close(got[k],expected[k])
    assert got['status']=='PASS' and got['pass_'] is True
    if 'force_direction' in expected:
        assert got['force_direction']==expected['force_direction']
        assert_close(got['lc'],expected['lc'])


@pytest.mark.parametrize('p',[-100000.,-20000.,-45000.,0.,45000.])
def test_all_five_common_signed_chains(p):
    r=main_result(p);ex=ORACLE['common_cases'][str(p)];rr=rows(r)
    for k in ('H','V','Hb','Vb','Hc','Vc'):assert_close(r['forces'][k],ex[k])
    for name,ref in (('joint','J'),('lower_column_cut','lower_cut')):
        assert_close([r['forces'][name][k] for k in ('Fx','Fy','M')],ex[ref])
    for k in ('Ftop','Fbottom','Nweb'):assert_close(r['joint_distribution'][k],ex[k])
    for k in ('Qtop','Qbottom'):assert_close(r['panel'][k],ex[k])
    assert_close(rr['continuity_top_concurrent_column_receiver_bound']['demand'],ex['concurrent_receiver']['top_concurrent_bound'])
    assert_close(rr['continuity_top_concurrent_column_receiver_bound']['utilization'],ex['concurrent_receiver']['utilization'])
    for residual in r['equilibrium_residuals'].values():assert_close(residual,[0.,0.,0.],abs_=1e-6)
    assert_close(r['brace']['physical_bolt_resultant'],[ex['H'],ex['V'],0.],abs_=1e-6)
    assert r['brace']['per_angle_force']==p/2
    assert r['brace']['per_plane_force']==p/8
    assert r['brace']['force_per_gusset_hole']==p/4


def test_compression_geometry_and_selected_zero_cap_not_nested_full_cap():
    r=main_result();cp=r['compression'];ex=ORACLE['plate_compression']
    for k in ('A','r','Le','Le_over_r','lambda0','chi','resistance','u0','width','l1','l2','l3','three_line_average','K'):
        assert_close(cp[k],ex[k])
    assert_close(cp['Lmax'],ex['Le'])
    assert cp['Lmax']>max(cp['l1'],cp['l2'],cp['l3'])
    for root in ('beam','column'):
        p=cp['root_projections'][root]
        assert p['contained_in_effective_seam'] and p['uninterrupted_plate_path']
        assert_close(p['stripe_projection'],ex['projection_checks'][root]['stripe'])
    u=rows(r)['gusset_inward_tangent_U_zero_cap']
    selected=ORACLE['zero_cap_shear_only_witness']
    assert_close(u['resistance'],selected['conservative_zero_cap_resistance'])
    assert u['resistance']!=pytest.approx(selected['resistance'])
    assert_close(u['witness']['u'],556.)
    assert_close(u['witness']['Agv'],7531.58225864658)
    assert_close(u['witness']['Anv'],7531.58225864658)
    assert u['witness']['captured_bolts_including_crossing']==[1,2,3,4]
    assert u['witness']['captured_bolts_excluding_crossing']==[1,2,3]
    assert_close(u['witness']['demand_limits'],[75000.,100000.])
    assert u['witness']['free_exit']==['clip_free','clip_free']
    assert not u['witness']['support_hits']
    assert r['gusset_paths']['admissible']
    assert not any(z['side']!='tangent_U' for z in r['gusset_paths']['admissible'])
    assert all(z['support_hits'] for z in r['gusset_paths']['rejected_supported'] if z['side']!='tangent_U')


def test_pure_compression_no_ct_or_abs_tensile_rupture():
    r=main_result();rr=rows(r)
    assert 'Ct' not in r['brace']
    assert not any(k.startswith('2L-T_angle_block_') or k=='2L-T_angle_net_effective_each' or k=='gusset_actual_net_body_rupture' or k.startswith('gusset_block_') for k in rr)
    for root in ('beam','column'):
        assert root+'_receiving_compression_web_crippling' in rr
        assert root+'_receiver_root_contact_normal_rupture' not in rr
        assert root+'_gusset_root_contact_normal_rupture' not in rr
    assert 'joint_bottom_beam_flange_net' in rr  # actual tensile bending survives
    assert 'joint_web_base_normal_rupture' not in rr
    vm=r['gusset_body']['governing']
    assert_close(vm['u'],ORACLE['body_governing']['u'],rel=1e-8,abs_=2e-5)
    assert_close(vm['nominal_VM'],ORACLE['body_governing']['VM'])
    assert max(vm['sigma_edges'])<0


@pytest.mark.parametrize('p',[-44999.,-20000.,-1.,0.,1.,20000.,44999.])
def test_minimum45_is_one_separate_signed_whole_chain(p):
    c=bcc(P=p);r=analyze(c);d=r['design_cases'];assert len(d)==1
    case=d[0];minimum=case['result'];signforce=-45000. if p<0 else 45000.
    assert (case['actual_P'],case['design_P'])==(p,signforce)
    assert not case['robot_lower_comparison']
    assert 'sintét' in case['origin'].lower() or 'synthet' in case['origin'].lower()
    assert bool(case.get('zero_force_convention'))==(p==0.)
    for key in ('beam_cut','upper_column_cut'):assert minimum['forces'][key]==r['forces'][key]
    assert minimum['forces']['lower_column_cut']!=r['forces']['lower_column_cut']
    assert_close(r['forces']['H'],p/math.sqrt(2))
    assert_close(minimum['forces']['H'],signforce/math.sqrt(2))
    for z in minimum['checks']:assert z['case_id']=='minimum_45kN' and z['id'].startswith('minimum45__')
    assert not minimum.get('design_cases')
    assert minimum['brace']['per_plane_force']==signforce/8
    if p==-20000.:
        assert_close([r['forces']['lower_column_cut'][k] for k in ('Fx','Fy','M')],ORACLE['common_cases']['-20000.0']['lower_cut'])
        assert_close([minimum['forces']['lower_column_cut'][k] for k in ('Fx','Fy','M')],ORACLE['common_cases']['-45000.0']['lower_cut'])
        actual=r['forces']['lower_column_cut']
        checked=analyze(replace(c,compare_lower_cut=True,lower_column_check_Fx=actual['Fx'],lower_column_check_Fy=actual['Fy'],lower_column_check_M=actual['M']))
        assert not any('mismatch' in x for x in issues(checked))
    slip=rows(minimum)['minimum45__bolt1_service_slip']
    assert_close(slip['demand'],7875.)


@pytest.mark.parametrize('p',[-100000.,-45000.,45000.,100000.])
def test_minimum_not_duplicated_at_or_above_threshold(p):assert not main_result(p).get('design_cases')


@pytest.mark.parametrize('surface,mu', [('A',.3),('B',.5)])
@pytest.mark.parametrize('diameter,pretension',[(16.,91000.),(15.875,85000.)])
@pytest.mark.parametrize('p',[-100000.,100000.])
def test_slip_class_metric_inch_and_positive_same_detail(surface,mu,diameter,pretension,p):
    r=analyze(bcc(P=p,bolt_surface_class=surface,bolt_diameter=diameter))
    ss=slips(r);assert len(ss)==4
    for z in ss.values():
        assert_close(z['demand'],.7*abs(p)/4)
        assert_close(z['resistance'],.8*mu*pretension*2)
    # Ultimate shear never receives favorable slip resistance.
    rr=rows(r)
    assert_close(rr['2L-T_bolt1_plane1']['resistance'],.45*math.pi*diameter**2/4*830/1.35)


@pytest.mark.parametrize('combination',['unknown','special_ultimate','exceptional_ultimate'])
def test_unidentified_and_non_normal_cases_never_receive_automatic_point7(combination):
    r=analyze(bcc(combination_type=combination))
    assert not r['complete'] and r['status']!='PASS'
    assert 'friction_service_case' in issues(r)
    assert not any(z['status']=='PASS' and not z.get('diagnostic_only') for z in slips(r).values())


@pytest.mark.parametrize('kw',[{'bolt_friction_type':False},{'bolt_surface_class':'unknown'},
 {'bolt_pretensioned':False},{'bolt_installation_source':'Não informado'},
 {'bolt_hardened_washer_count':0},{'bolt_washer_location':'none'},
 {'bolt_washer_stack':0.},{'bolt_washer_diameter':0.},
 {'bolt_angle_continuation':31.999},{'bolt_continuation_source':'Não informado'}])
def test_physical_friction_hardware_continuation_required(kw):
    r=analyze(bcc(**kw))
    assert not r['complete'] and r['status']!='PASS'
    assert any(i['severity'] in ('unverified','outside_scope','invalid_geometry','invalid_input','detail_pending') for i in r['issues'])


@pytest.mark.parametrize('root',['beam','column','brace'])
@pytest.mark.parametrize('state',['unknown','absent'])
def test_missing_actual_restraint_stays_unverified_even_with_receiver_flag(root,state):
    c=replace(bcc(),**{'compression_'+root+'_restraint':state},lateral_restraint=True)
    r=analyze(c)
    assert 'compression_'+root+'_restraint' in issues(r)
    assert not r['complete'] and r['status']=='FAIL'
    assert rows(r)['continuity_top_concurrent_column_receiver_bound']['status']=='FAIL'


GEOMETRY_CHANGES=[{'bolt_count':5},{'bolt_start':386.},{'bolt_pitch':61.},{'bolt_gauge':41.},
 {'bolt_diameter':15.875},{'bolt_drilled':False},{'bolt_angle_end':36.},
 {'bolt_washer_stack':5.},{'bolt_washer_diameter':33.},{'bolt_hardened_washer_count':2},
 {'bolt_washer_location':'both'},{'bolt_pretensioned':False},{'bolt_friction_type':False},
 {'bolt_surface_class':'A'},{'bolt_heel_extent':14.},{'bolt_tool_radius':19.},
 {'bolt_fabrication_clearance':3.},{'bolt_angle_continuation':65.},
 {'corner_clip':31.},{'plate_t':11.},{'beam_seam_end_margin':11.},
 {'column_seam_start_margin':11.},{'continuity_t':14.},{'root_weld_leg':5.},{'phi_deg':44.}]
@pytest.mark.parametrize('kw',GEOMETRY_CHANGES)
def test_bolted_physical_identity_cannot_reuse_stale_restraint(kw):
    c=bcc();changed=replace(c,**kw)
    assert geometry_stamp(changed)!=c.compression_geometry_stamp
    r=analyze(changed)
    assert 'compression_geometry_declaration' in issues(r)
    assert not r['complete']


@pytest.mark.parametrize('kw',[{'P':-50000.},{'case_id':'Other normal case'},{'beam_cut_M':62000000.},
 {'gusset_steel':'ASTM A572 Gr.50'},{'angle_steel':'ASTM A572 Gr.50'},{'gamma_a1':1.2},{'E':210000.},
 {'lateral_restraint':False},{'brace_weld_start':999.},{'fw_brace':500.}])
def test_material_action_and_unused_weld_controls_do_not_expire_bolted_geometry(kw):
    c=bcc();changed=replace(c,**kw)
    assert geometry_stamp(changed)==c.compression_geometry_stamp
    assert 'compression_geometry_declaration' not in issues(analyze(changed))


@pytest.mark.parametrize('increment,bad',[(.2513,False),(.2515,True)])
def test_nominal_column_projection_margin_is_not_rounded_away(increment,bad):
    r=analyze(bcc(column_seam_start_margin=10.+increment))
    assert ('compression_column_projection' in issues(r)) is bad
    assert r['compression']['root_projections']['column']['contained_in_effective_seam'] is not bad


def test_legacy_BC1_geometry_is_not_silently_qualified_by_sign_flip():
    r=analyze(bcc(bolt_start=370.))
    assert {'compression_beam_projection','compression_column_projection'}<=issues(r)
    assert not r['complete']


@pytest.mark.parametrize('kw',[{'angle_profile':'GERDAU_EQUAL_ANGLE_P03_R28'},
 {'bolt_pitch':375.1},{'corner_clip':0.},{'corner_clip':150.},
 {'workpoint_offset':1.},{'phi_deg':80.}])
def test_qualified_declaration_cannot_cure_method_domain_loss(kw):
    r=analyze(bcc(**kw))
    assert r['status']!='PASS' and not r['complete']
    assert any(i['severity'] in ('unverified','outside_scope','invalid_geometry','invalid_input','detail_pending') for i in r['issues'])


@pytest.mark.parametrize('topology',['single_1L_bolted','single_1L_welded'])
def test_unqualified_single_angle_compression_is_not_symmetric_branch(topology):
    r=analyze(bcc(topology=topology,symmetric=False,P=-20000.))
    assert not r['complete'] and 'UNVERIFIED_BRACE_COMPRESSION' in issues(r)
    assert not r.get('design_cases')


@pytest.mark.parametrize('name',FRICTION_FIELDS+RESTRAINT_FIELDS)
def test_native_atomic_new_and_restraint_groups(name):
    c=bcc();native=c.to_dict();assert CornerGusset.from_dict(native)==c
    assert all(k in native['connection'] for k in FRICTION_FIELDS+RESTRAINT_FIELDS)
    broken=deepcopy(native);broken['connection'].pop(name)
    with pytest.raises((ValueError,TypeError)):CornerGusset.from_dict(broken)
    broken=deepcopy(native);broken['connection'][name]=None
    with pytest.raises((ValueError,TypeError)):CornerGusset.from_dict(broken)


@pytest.mark.parametrize('name', ['bolt_washer_diameter','bolt_angle_continuation','bolt_hardened_washer_count'])
def test_native_new_numbers_reject_bools(name):
    raw=bcc().to_dict();raw['connection'][name]=True
    with pytest.raises((ValueError,TypeError)):CornerGusset.from_dict(raw)


def test_native_forged_outputs_and_stale_detail_are_recomputed():
    native=bcc().to_dict()
    for target in ('approved','checks','result'):
        bad=deepcopy(native);bad[target]=True
        with pytest.raises(ValueError):CornerGusset.from_dict(bad)
    bad=deepcopy(native);bad['connection']['bolt_pitch']=61.
    result=analyze(CornerGusset.from_dict(bad))
    assert 'compression_geometry_declaration' in issues(result) and not result['complete']


def test_legacy_negative_native_does_not_invent_new_qualification():
    old=json.loads((HERE/'LEGACY0935_BASELINE.json').read_text())
    native=deepcopy(next(v['native'] for n,v in old.items() if n.startswith('BC1 · canto 2L')))
    native['connection']['P']=-100000.
    c=CornerGusset.from_dict(native);r=analyze(c)
    assert not c.bolt_friction_type and c.compression_brace_restraint=='unknown'
    assert not r['complete']
    assert 'compression_brace_restraint' in issues(r) or 'UNVERIFIED_BRACE_COMPRESSION' in issues(r)


def test_immutable0935_tree_preserved():
    base=WORK/'review0935/source0935'
    hashes=json.loads((HERE/'IMMUTABLE0935_HASHES.json').read_text())
    changed=[name for name,sha in hashes.items() if not (base/name).is_file() or hashlib.sha256((base/name).read_bytes()).hexdigest()!=sha]
    assert changed==[]


@pytest.mark.parametrize('ex',ORACLE['paths'],ids=lambda z:f"{z['side']}@{z['u']:.9f}")
def test_all_93_frozen_reversed_paths(ex):
    from lro.bolted_corner_compression import inward_path
    c=bcc();got=inward_path(c,geometry(c),ex['u'],ex['side'])
    assert got['active'] is ex['active']
    assert_close(got['path_uv'],ex['path_uv'])
    if ex['active']:
        for k in ('Agv','Anv','Ant','demand'):assert_close(got[k],ex[k])
        assert_close(got['zero_cap_resistance'],ex['conservative_zero_cap_resistance'])
        assert_close(got['full_cap_diagnostic']['resistance'],ex['resistance'])
        assert_close(got['demand_limits'],ex['demand_limits'])
        assert got['free_exit']==ex['free_exits']
        assert got['captured_bolts_including_crossing']==ex['captured_bolts']
        assert got['captured_bolts_excluding_crossing']==ex['excluded_crossed_bolts']
    else:assert got['support_hits']


def test_full_cap_stationary_diagnostic_is_separate_and_not_selected_strength():
    r=main_result();z=r['gusset_paths']['full_cap_diagnostic'];ex=ORACLE['block_governing']
    for k in ('u','Agv','Anv','Ant','demand'):assert_close(z[k],ex[k])
    assert_close(z['full_cap_diagnostic']['resistance'],ex['resistance'])
    assert 'diagnostic' in z['full_cap_diagnostic']['model']
    assert_close(z['u'],565.-9.*(.75/math.hypot(1.,.75)))
    rr=rows(r)
    assert len([k for k in rr if k.startswith('gusset_inward')])==1
    assert_close(rr['gusset_inward_tangent_U_zero_cap']['resistance'],836842.4731829532)


@pytest.mark.parametrize('count',[2,3,4])
def test_physical_count_never_doubles_gusset_or_slip_interfaces(count):
    r=analyze(bcc(bolt_count=count));rr=rows(r);g=r['geometry'];p=100000.
    assert r['brace']['angle_count']==2 and g['physical_gusset_count']==1
    assert len(slips(r))==count and r['service_slip']['interfaces']==2
    for j in range(1,count+1):
        assert_close(rr[f'bolt{j}_service_slip']['demand'],.7*p/count)
        assert_close(rr[f'common_gusset_bearing{j}']['demand'],p/count)
        for plane in (1,2):assert_close(rr[f'2L-T_bolt{j}_plane{plane}']['demand'],p/(2*count))
    assert_close(r['brace']['physical_bolt_resultant'],[-p/math.sqrt(2),-p/math.sqrt(2),0.])


def test_one_plane_friction_arithmetic_is_diagnostic_and_not_new_qualified_1L():
    r=analyze(bcc(topology='single_1L_bolted',symmetric=False,P=100000.))
    assert not r['complete'] and 'friction_topology' in issues(r)
    assert r['service_slip']['interfaces']==1
    assert_close(r['service_slip']['per_bolt_resistance'],36400.)
    assert_close(r['service_slip']['per_interface_demand'],17500.)
    assert_close(rows(r)['1L_bolt1_plane1']['demand'],25000.)
    assert not any('plane2' in k for k in rows(r))


@pytest.mark.parametrize('pitch',[45.,55.,60.])
@pytest.mark.parametrize('continuation',[16.,32.,60.])
def test_each_reversed_bearing_wall_uses_its_actual_loaded_clear_length(pitch,continuation):
    c=bcc(bolt_pitch=pitch,bolt_angle_continuation=continuation);r=analyze(c);g=r['geometry'];rr=rows(r)
    # Independent intersection of the nominal row with each physical polygon edge.
    poly=g['poly_uv'];cross=[]
    for a,b in zip(poly,poly[1:]+poly[:1]):
        if min(a[1],b[1])<=0<=max(a[1],b[1]):
            if a[1]==b[1]:cross.extend((a[0],b[0]))
            else:cross.append(a[0]+(0-a[1])/(b[1]-a[1])*(b[0]-a[0]))
    entrance=min(cross)
    for j,u in enumerate(g['bolt_stations'],1):
        lc_a=pitch-18. if j<4 else continuation
        lc_g=u-entrance-9. if j==1 else pitch-18.
        for part,lc,t,D,prefix in [('angle',lc_a,7.94,12500.,'2L-T_'),('gusset',lc_g,12.,25000.,'common_')]:
            z=rr[prefix+part+f'_bearing{j}']
            assert_close(z['lc'],lc)
            assert_close(z['resistance'],min(1.2*lc*t*400.,2.4*16.*t*400.)/1.35)
            assert_close(z['demand'],D)
            assert z['force_direction']==('+u' if part=='angle' else '-u')
    assert ('angle_compression_continuation' in issues(r)) is (continuation<32.)


@pytest.mark.parametrize('plane',[1,2])
def test_thread_selection_changes_only_its_physical_plane(plane):
    before=rows(main_result());after=rows(analyze(bcc(**{f'bolt_threads_excluded_{plane}':True})))
    for j in range(1,5):
        assert_close(after[f'2L-T_bolt{j}_plane{plane}']['resistance']/before[f'2L-T_bolt{j}_plane{plane}']['resistance'],.56/.45)
        assert after[f'2L-T_bolt{j}_plane{3-plane}']==before[f'2L-T_bolt{j}_plane{3-plane}']
        assert after[f'bolt{j}_service_slip']==before[f'bolt{j}_service_slip']


def test_net_hole_policy_changes_net_supplements_never_physical_wall_bearing():
    a=main_result();b=analyze(bcc(bolt_drilled=False));aa,bb=rows(a),rows(b)
    assert b['geometry']['hole_diameter']==a['geometry']['hole_diameter']==18.
    assert b['geometry']['net_hole_diameter']==20.
    assert 'friction_standard_drilled_holes' in issues(b) and not b['complete']
    for k,z in aa.items():
        if 'bearing' in k:assert z==bb[k]
    assert_close(bb['each_angle_net_compression_yield_supplement']['resistance'],(1148.-20.*7.94)*250./1.1)
    assert bb['gusset_whitmore_net_compression_yield_supplement']['resistance']<aa['gusset_whitmore_net_compression_yield_supplement']['resistance']


@pytest.mark.parametrize('changes',[
 {'angle_steel':'ASTM A572 Gr.50'},{'gusset_steel':'ASTM A572 Gr.50'},
 {'gamma_a1':1.2},{'gamma_a2':1.5},{'E':210000.}])
def test_local_material_reductions_are_recomputed_not_oracle_fixtures(changes):
    c=bcc(**changes);r=analyze(c);rr=rows(r);ma=MATERIALS[c.angle_steel];mg=MATERIALS[c.gusset_steel]
    ratio=60./15.;lam=ratio/math.pi*math.sqrt(ma['fy']/c.E);chi=.658**(lam**2)
    assert_close(rr['each_angle_local_segment_compression']['resistance'],chi*1148.*ma['fy']/c.gamma_a1)
    assert_close(rr['each_angle_net_compression_yield_supplement']['resistance'],(1148.-18.*7.94)*ma['fy']/c.gamma_a1)
    u=rr['gusset_inward_tangent_U_zero_cap'];A=u['witness']['Agv']
    assert_close(u['resistance'],min(.6*mg['fy'],.6*mg['fu'])*A/c.gamma_a2)
    assert_close(rr['bolt1_service_slip']['resistance'],72800.)


@pytest.mark.parametrize('phi',[44.5,45.5])
def test_valid_nonfixture_geometry_is_not_restricted_to_300mm_45deg(phi):
    c=bcc(P=-50000.,phi_deg=phi,plate_width=320.,plate_height=320.,plate_t=13.,corner_clip=40.,bolt_start=395.,bolt_pitch=55.)
    r=analyze(c)
    assert r['complete'] and r['status']=='PASS' and r['compression']['qualified']
    assert_close(r['compression']['width'],2.*165.*math.tan(math.pi/6))
    assert r['compression']['Lmax']!=pytest.approx(ORACLE['plate_compression']['Le'])
    assert_close(r['brace']['physical_bolt_resultant'],[-50000.*math.cos(math.radians(phi)),-50000.*math.sin(math.radians(phi)),0.])


@pytest.mark.parametrize('change,issue',[
 ({'angle_profile':'GERDAU_EQUAL_ANGLE_P03_R28'},'angle_compression_effective_area'),
 ({'bolt_pitch':375.1},'angle_compression_short_interval'),
 ({'corner_clip':0.},'compression_inward_U_topology'),
 ({'corner_clip':240.},'compression_inward_L_topology')])
def test_named_domain_diagnostic_survives_a_new_restraint_declaration(change,issue):
    r=analyze(bcc(**change))
    assert issue in issues(r) and not r['complete']


@pytest.mark.parametrize('field,value',[
 ('bolt_surface_class','C'),('bolt_washer_location','head'),('combination_type','service'),
 ('bolt_hardened_washer_count',1.0),('bolt_hardened_washer_count',-1),
 ('bolt_friction_type',1),('bolt_washer_diameter',float('inf')),
 ('bolt_angle_continuation',float('nan'))])
def test_new_native_enum_and_type_contract(field,value):
    raw=bcc().to_dict();raw['connection'][field]=value
    with pytest.raises((ValueError,TypeError)):CornerGusset.from_dict(raw)


def independent_section(c,g,ff,u,include,net):
    """Fresh equilibrium/section reconstruction; no production geometry helpers."""
    co=math.cos(math.radians(c.phi_deg));si=math.sin(math.radians(c.phi_deg))
    eu=(co,si);ev=(-si,co);intersections=[]
    def dot(x,y):return sum(a*b for a,b in zip(x,y))
    def cross(x,y):return x[0]*y[1]-x[1]*y[0]
    def sub(x,y):return [a-b for a,b in zip(x,y)]
    poly=[[dot(p,eu),dot(p,ev)] for p in g['polygon']]
    for p,q in zip(poly,poly[1:]+poly[:1]):
        if min(p[0],q[0])-1e-9<=u<=max(p[0],q[0])+1e-9:
            if abs(p[0]-q[0])<1e-10:intersections.extend((p[1],q[1]))
            else:intersections.append(p[1]+(u-p[0])/(q[0]-p[0])*(q[1]-p[1]))
    if not intersections:return None
    vl,vr=min(intersections),max(intersections);rad=g['net_hole_diameter']/2
    h=max([math.sqrt(max(0.,rad**2-(u-b)**2)) for b in g['bolt_stations'] if abs(u-b)<=rad]+[0.]) if net else 0.
    lo=max(vl,-h);hi=min(vr,h);ded=max(0.,hi-lo)
    area=c.plate_t*(vr-vl-ded)
    if area<1e-8:return None
    first=c.plate_t*((vr**2-vl**2)-(hi**2-lo**2 if ded else 0.))/2
    vc=first/area
    inertia=c.plate_t*((vr**3-vl**3)-(hi**3-lo**3 if ded else 0.))/3-area*vc**2
    if inertia<1e-8:return None
    origin=[u*eu[k]+vc*ev[k] for k in (0,1)];forces=[];moments=[]
    for b in g['bolt_stations']:
        keep=u<=b+rad+1e-8 if include else u<b-rad-1e-8
        if keep:
            f=[c.P/c.bolt_count*x for x in eu];p=[b*x for x in eu]
            forces.append(f);moments.append(cross(sub(p,origin),f))
    for root,force in [('beam',[-ff['Hb'],-ff['Vb']]),('column',[-ff['Hc'],-ff['Vc']])]:
        p,q=sorted(g[root+'_seam'],key=lambda z:dot(z,eu));pl,ql=dot(p,eu),dot(q,eu)
        if u>=ql:continue
        fraction=min(1.,(ql-u)/(ql-pl));start=[q[k]-fraction*(q[k]-p[k]) for k in (0,1)]
        at=[(q[k]+start[k])/2 for k in (0,1)];f=[fraction*x for x in force]
        forces.append(f);moments.append(cross(sub(at,origin),f))
    N=sum(dot(f,eu) for f in forces);V=sum(dot(f,ev) for f in forces);M=sum(moments)
    sigma=[N/area-M*(v-vc)/inertia for v in (vl,vr)]
    return dict(A=area,centroid_v=vc,I=inertia,N=N,V=V,M=M,sigma_edges=sigma,
        nominal_VM=max(math.hypot(z,math.sqrt(3)*1.5*V/area) for z in sigma))


@pytest.mark.parametrize('mutated',[False,True])
def test_independent_physical_sections_keep_partial_roots_and_both_cut_hole_limits(mutated):
    from lro.bolted_corner import section
    c=bcc(**(dict(P=-50000.,phi_deg=44.5,plate_width=320.,plate_height=320.,plate_t=13.,corner_clip=40.,bolt_start=395.,bolt_pitch=55.) if mutated else {}))
    r=analyze(c);g=r['geometry'];co=math.cos(math.radians(c.phi_deg));si=math.sin(math.radians(c.phi_deg));rad=g['net_hole_diameter']/2
    events={co*p[0]+si*p[1] for p in g['polygon']}
    events|={co*p[0]+si*p[1] for key in ('beam_seam','column_seam') for p in g[key]}
    events|={b+delta for b in g['bolt_stations'] for delta in (-rad,-.6*rad,0.,.6*rad,rad)}
    events.add(ORACLE['body_governing']['u'])
    comparisons=0
    for u in sorted(events):
        for include in (False,True):
            for net in (False,True):
                expected=independent_section(c,g,r['forces'],u,include,net)
                got=section(c,g,r['forces'],u,include,net)
                if expected is None:assert got is None;continue
                for k,value in expected.items():assert_close(got[k],value,rel=2e-8,abs_=2e-5)
                comparisons+=1
    assert comparisons>=80


def test_service_actual_and_synthetic_are_distinct_and_do_not_rewrite_background_cuts():
    r=main_result(-20000.);a=r['service_slip'];m=r['design_cases'][0]['result']['service_slip']
    assert_close(a['signed_local_service_force'],-14000.)
    assert_close(m['signed_local_service_force'],-31500.)
    assert 'actual normal' in a['case_provenance']
    assert 'synthetic' in m['case_provenance'] and 'not an actual' in m['case_provenance']
    assert a['ultimate_friction_capacity_added'] is m['ultimate_friction_capacity_added'] is False
    assert r['compression']['local_scope'].lower().find('global')>=0
    assert r['brace']['global_member_stability']=='outside_scope'
