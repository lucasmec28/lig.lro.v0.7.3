#!/usr/bin/env python3
"""Portable, read-only replay of the hash-bound LRO 0.9.36 engine evidence.

No original workspace, earlier source tree, package, or network is required.
The explicit source and qualification inputs are never written. All new logs,
pytest cache, parity output and the portable receipt go to a separate directory.
"""
import argparse,datetime,hashlib,json,os,subprocess,sys,tempfile
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT=Path(__file__).resolve().parent
BOUND_ACCEPTANCE_SHA256='a683f0955897174082c264635f95d8aea772876c45f39f63aeb960d0904eb0a0'
BOUND_PROVENANCE_SHA256='a0f51fbed282328c70a86a51e73e01918fb165ecef157c26a2e429db1e3b8eaf'
SOURCE_ONLY_TEST='test_immutable0935_tree_preserved'


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):return json.loads(path.read_text())
def require(condition,message):
    if not condition:raise ValueError(message)


def verify_inputs(source,qualification):
    original=ROOT/'original';portable=ROOT/'portable'
    require(sha(original/'ENGINE_ACCEPTANCE0936.json')==BOUND_ACCEPTANCE_SHA256,'Historical engine acceptance receipt hash mismatch.')
    require(sha(ROOT/'ADAPTATION_PROVENANCE.json')==BOUND_PROVENANCE_SHA256,'Path-adaptation provenance hash mismatch.')
    provenance=read(ROOT/'ADAPTATION_PROVENANCE.json');acceptance=read(original/'ENGINE_ACCEPTANCE0936.json')
    for name,record in provenance['original_preservation'].items():
        require(sha(original/name)==record['sha256'],f'Original evidence hash mismatch: {name}')
    for name,record in provenance['path_only_copies'].items():
        require(sha(portable/name)==record['portable_sha256'],f'Portable path-only copy hash mismatch: {name}')
        require(sha(original/name)==record['original_sha256'],f'Adaptation input hash mismatch: {name}')
    require(acceptance['decision']=='PASS_BOUNDED_LOCAL_ENGINE_AND_NATIVE_ACCEPTANCE','Historical engine decision is not PASS.')
    require(acceptance['independent_test_count']==287 and acceptance['failures_or_errors']==0 and acceptance['skipped']==0,'Historical 287-test receipt is inconsistent.')
    require(acceptance['immutable0935_changed']==[],'Historical preservation receipt contains changed files.')
    old_files=read(original/'IMMUTABLE0935_HASHES.json')
    require(len(old_files)==acceptance['immutable0935_files_checked']==1740,'Historical immutable-source evidence count mismatch.')
    legacy=read(original/'LEGACY_PARITY0936.json')
    require(legacy['baseline_sha256']==sha(original/'LEGACY0935_BASELINE.json'),'Saved 22-case legacy baseline hash mismatch.')
    actual={}
    require(len(acceptance['source_hashes'])==6,'Expected exactly six accepted engine identities.')
    for name,expected in acceptance['source_hashes'].items():
        actual[name]=sha(source/name)
        require(actual[name]==expected,f'Current source differs from final accepted engine: {name}')
    require(sha(qualification/'MANIFEST.json')==provenance['qualification_manifest_sha256'],'Qualification manifest differs from accepted method evidence.')
    method=read(qualification/'MANIFEST.json')
    for name,record in method['files'].items():
        require(sha(qualification/name)==record['sha256'],f'Qualification evidence hash mismatch: {name}')
    return acceptance,actual


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',required=True,type=Path,help='Application code directory containing lro/ and data/.')
    parser.add_argument('--qualification',type=Path,help='Approved qualification directory. Default: SOURCE/docs/qualification_bolted_corner_compression0936.')
    parser.add_argument('--dependency-dir',action='append',type=Path,default=[],help='Optional existing Python dependency directory; repeat if needed. Nothing is installed.')
    parser.add_argument('--output',type=Path,help='New or empty writable output directory. Default: a fresh system temporary directory.')
    args=parser.parse_args()
    source=args.source.resolve();qualification=(args.qualification or source/'docs/qualification_bolted_corner_compression0936').resolve()
    acceptance,source_hashes=verify_inputs(source,qualification)
    output=args.output.resolve() if args.output else Path(tempfile.mkdtemp(prefix='lro0936-engine-replay-')).resolve()
    for protected in (source,qualification,ROOT/'original',ROOT/'portable'):
        require(not output.is_relative_to(protected),'Output must be outside the source, qualification, original evidence and portable-code directories.')
    require(not output.exists() or not any(output.iterdir()),'Output directory must be new or empty; prior evidence is never overwritten.')
    output.mkdir(parents=True,exist_ok=True)
    env=os.environ.copy()
    env.update(PYTHONDONTWRITEBYTECODE='1',LRO_ACCEPT_SOURCE=str(source),LRO_QUALIFICATION=str(qualification),
               LRO_EVIDENCE_ORIGINAL=str(ROOT/'original'),LRO_REPLAY_OUTPUT=str(output))
    paths=[str(source)]+[str(p.resolve()) for p in args.dependency_dir]
    if env.get('PYTHONPATH'):paths.append(env['PYTHONPATH'])
    env['PYTHONPATH']=os.pathsep.join(paths)
    test=ROOT/'portable/test_independent_engine0936.py'
    pytest_command=[sys.executable,'-m','pytest','-q','-o',f'cache_dir={output/"pytest_cache"}',
        f'--junitxml={output/"PORTABLE_ENGINE_TESTS.xml"}',str(test),
        '-k',f'not {SOURCE_ONLY_TEST}']
    started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (output/'portable_engine_tests.log').open('w') as log:
        completed=subprocess.run(pytest_command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
    tree=ET.parse(output/'PORTABLE_ENGINE_TESTS.xml') if (output/'PORTABLE_ENGINE_TESTS.xml').exists() else None
    suites=list(tree.getroot().iter('testsuite')) if tree else []
    counts={key:sum(int(s.attrib.get(key,0)) for s in suites) for key in ('tests','failures','errors','skipped')}
    test_pass=completed.returncode==0 and counts=={'tests':286,'failures':0,'errors':0,'skipped':0}
    with (output/'portable_legacy_parity.log').open('w') as log:
        parity_run=subprocess.run([sys.executable,str(ROOT/'portable/compare_legacy.py')],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
    parity=read(output/'LEGACY_PARITY0936.json') if (output/'LEGACY_PARITY0936.json').exists() else None
    parity_pass=parity_run.returncode==0 and parity is not None and parity['pass'] and parity['case_count']==22 and parity['comparisons']==148262
    # Detect mutation during replay rather than assigning an earlier hash to a
    # later runtime silently.
    source_still_bound=all(sha(source/name)==value for name,value in source_hashes.items())
    result={
        'decision':'PASS_PORTABLE_ENGINE_REPLAY' if test_pass and parity_pass and source_still_bound else 'FAIL_PORTABLE_ENGINE_REPLAY',
        'started_utc':started,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source':str(source),'qualification':str(qualification),'output':str(output),
        'current_engine_hashes':source_hashes,'source_hashes_verified_before_and_after':source_still_bound,
        'implementation_tests':counts,'implementation_test_exit_code':completed.returncode,
        'legacy_cases':parity['case_count'] if parity else None,'legacy_comparisons':parity['comparisons'] if parity else None,
        'legacy_pass':parity_pass,
        'historical_receipt_integrity_verified':True,
        'historical_original_test_count':acceptance['independent_test_count'],
        'source_only_tests_not_rerun':[{'name':SOURCE_ONLY_TEST,'reason':'Requires the immutable 0.9.35 source tree. This portable replay verifies the preserved original receipt and 1,740-file hash list integrity, not those absent files.'}],
        'path_only_adaptations':'ADAPTATION_PROVENANCE.json and PATH_ONLY_ADAPTATIONS.diff',
        'scope':'Read-only engine/native test replay. Not an application/package/release gate and no publishing.'}
    (output/'PORTABLE_REPLAY_RECEIPT.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    return 0 if result['decision']=='PASS_PORTABLE_ENGINE_REPLAY' else 1

if __name__=='__main__':
    try:raise SystemExit(main())
    except (OSError,ValueError,KeyError) as error:
        print(f'Portable replay blocked: {error}',file=sys.stderr)
        raise SystemExit(2)
