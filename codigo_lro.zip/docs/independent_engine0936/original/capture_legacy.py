"""Read-only parity capture. The production module path is the only argument.

No fixture builder or implementation test is imported. PYTHONDONTWRITEBYTECODE=1
keeps immutable source byte-for-byte unchanged.
"""
import sys,json
from pathlib import Path
from dataclasses import replace
sys.path.insert(0,str(Path(sys.argv[1]).resolve()))
from lro.corner_gusset import analyze,presets,CornerGusset
from lro.corner_compression import declare_current_detail
records={}
for name,c in presets().items():
    if name.startswith('BCC'): continue
    r=analyze(c)
    records[name]={'native':c.to_dict(),'result':r}
# Exercise actual and synthetic sign chains on the inherited welded branch and
# inherited ordinary-bearing positive bolted detail, retaining all backgrounds.
welded=declare_current_detail(replace(CornerGusset(),P=-20000.),'Independent parity baseline: declared ordinary welded corner detail.')
bc=next(c for c in presets().values() if c.topology=='symmetric_2L_T_bolted' and c.P>0)
for p in (-20000.,-45000.,-50000.,-100000.):
    c=replace(welded,P=p)
    records['welded_sign_'+str(p)]={'native':c.to_dict(),'result':analyze(c)}
for p in (0.,1.,20000.,45000.,100000.):
    c=replace(bc,P=p)
    records['bolted_positive_'+str(p)]={'native':c.to_dict(),'result':analyze(c)}
json.dump(records,sys.stdout,ensure_ascii=False,indent=2,allow_nan=False)
