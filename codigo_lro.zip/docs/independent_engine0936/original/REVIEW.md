# Independent engine/native acceptance: LRO 0.9.36

Decision: PASS_BOUNDED_LOCAL_ENGINE_AND_NATIVE_ACCEPTANCE.

The reviewed bounded local bolted symmetric 2L-T compression implementation passes 287 independent tests, with 0 failures/errors and 0 skipped. All 22 inherited native cases retain their checked behavior across 148,262 numerical/status comparisons. All 1,740 files in immutable 0.9.35 remain byte-identical.

## Critical results

- BCC1 is still a complete, calculated full-joint FAIL. The common concurrent receiver remains 1.0101145936065872; no alternative force or fixture geometry was substituted.
- The primary inward-U strength row selects 836842.4731829532N at u556mm. The full-cap 852842.4731829534N at u559.6mm is separately retained as a diagnostic; it is neither selected nor added.
- All 27 approved local strength witnesses, all 93 frozen inward path states, all five signed common chains, local angle properties and full-stripe plate stability match the frozen independent oracle.
- Physical split/direction tests cover each bolt plane, each hole wall, one shared gusset, and two slip interfaces. Metric 16 mm A325 uses 91 kN pretension; inch 15.875 mm uses 85 kN. Class A/B friction is separate from ultimate bolt/bearing resistance.
- Actual −20 kN and synthetic −45 kN whole-chain cases retain different lower cuts, identical explicit background D/U actions, independent local service demands and distinct provenance. Zero retains the existing explicitly labeled +45 kN tensile minimum convention.
- Geometry-bound declarations expire for bolt, hole, washer, contact, pretension, root, plate and support changes. Unknown/absent restraints, unidentified/special/exceptional combinations, missing physical hardware/continuation and method domain losses remain unverified at named components.
- Fresh physical-section reconstruction verifies partial tractions from both roots and both included/excluded cut-hole limits for gross and circular-net sections in the frozen fixture and a changed valid geometry. Pure negative normal stress does not become tensile rupture demand; actual tensile receiving surfaces remain checked.
- Two valid nonfixture cases at 44.5°/45.5°, 320×320×13mm, 40 mm clip and 55 mm pitch pass their complete results, demonstrating parameterized operation beyond 300 mm/45°.
- Native import requires complete new/detail groups, rejects forged outputs and malformed values, and recomputes stale geometry. Older native inputs do not invent friction/restraint qualification.

## Review and reproducibility

`test_independent_engine0936.py` was authored outside production and imports no candidate calculator. Its data source is the approved frozen qualification oracle with per-file SHA256 verification. `compare_legacy.py` replays native inputs recorded read-only before implementation; it checks every inherited numeric/boolean/status leaf. Exact engine hashes are in `ENGINE_ACCEPTANCE0936.json`.

Run from the workspace root with PYTHONDONTWRITEBYTECODE=1 and PYTHONPATH=review0936/source0936:connections_audit/test_dependencies. Invoke pytest on this directory's test file, directing cache and JUnit outputs here, then run compare_legacy.py. The parent owns aggregate and separate presentation acceptance.

## Limits

This is finite acceptance of the approved conventional local engineering model. It does not measure physical restraint stiffness, certify actual pretension/surface execution, authorize fabrication, or verify global member/frame/stitch stability. Nominal section extrema are numerical screens, not interval proofs or pointwise hole-contact stresses. Unsupported 1L friction/compression and alternative inward exit/L topologies remain outside the automatic route.

No production file was edited by this reviewer. No packaging, upload, publishing or release was performed.
