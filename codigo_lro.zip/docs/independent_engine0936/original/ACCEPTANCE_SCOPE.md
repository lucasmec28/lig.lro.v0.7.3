# Independent engine/native acceptance scope for 0.9.36

The reviewer did not write production code. Execution will begin only when the implementer marks the engine ready. Every new test and output stays in this directory. No package, upload, release, or publication is performed.

## Binding reference

The reviewed 12 October 2026 bolted compression contract, fixture, oracle, final independent review, and manifest in `bolted_corner_compression_scope20261012` define the domain. The 95 independent numeric comparisons and 28 fixture-integrity checks are prior method evidence, not implementation acceptance. Acceptance checks their hashes against the signed manifest and compares the final runtime against the approved data. Tests import no candidate calculator.

## Acceptance coverage

- Exact BCC1 geometry and independent steels, including metric16 A325 minimum pretension91kN, actual31.88mm grip, washer4mm ×32mm, and one shared gusset.
- All27 approved new local strength witnesses, physical load splits and directions, root projections, local angle properties, full-strip buckling, selected zero-cap inward-U envelope and separate full-cap diagnostic.
- All five signed common chains; BCC1 common receiver failure1.010114593606587 retained. The −20kN actual case and −45kN synthetic whole-chain case retain distinct lower cuts and provenance; zero retains declared +45kN tension convention.
- ClassA/B service slip separate from ultimate shear/bearing; physical plane/interface counts; metric versus inch pretension; positive-case friction checks; unknown/special/exceptional case rejection.
- Compression bearing reversal at each wall; continuation, pitch, hole net diameter and materials mutation; no absolute-value tensile rupture in pure compression.
- Missing/stale beam, column and brace restraint; bolt/hole/contact/hardware identity; fixture’s very small projection margin; compactness, short-interval restriction and inward path topology domain loss.
- Strict complete native import of the new field group and restraint group; unknown values, nulls, booleans-as-numerics and forged outputs rejected; pre-0.9.36 imports do not invent compression qualification.
- Numeric/check/status parity against22 frozen inherited cases produced read-only from the immutable0.9.35 engine; prior source tree hash preservation verified after acceptance.

## Evidence limits

This finite suite validates the declared local engineering model and native interchange. It is not construction verification, whole-member stability or fabrication approval, and it is not an exhaustive proof over all real geometries. Presentation/drawing/report/UI acceptance is a separate assigned review.
