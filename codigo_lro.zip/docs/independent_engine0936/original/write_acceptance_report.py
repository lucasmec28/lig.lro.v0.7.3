"""Create a hash-bound acceptance receipt after the final command completes."""
from pathlib import Path
import hashlib,json,xml.etree.ElementTree as ET,datetime
R=Path(__file__).resolve().parent;S=R.parent/'source0936';W=R.parents[1]
xml=ET.parse(R/'FINAL_ENGINE_TESTS.xml').getroot()
suites=list(xml.iter('testsuite'))
tests=sum(int(x.attrib.get('tests',0)) for x in suites)
failed=sum(int(x.attrib.get('failures',0))+int(x.attrib.get('errors',0)) for x in suites)
skipped=sum(int(x.attrib.get('skipped',0)) for x in suites)
parity=json.loads((R/'LEGACY_PARITY0936.json').read_text())
files=['lro/corner_gusset.py','lro/corner_compression.py','lro/bolted_corner.py','lro/bolted_corner_compression.py','lro/angle_catalog.py','data/gerdau_equal_angles.json']
source_hashes={p:hashlib.sha256((S/p).read_bytes()).hexdigest() for p in files}
old_hashes=json.loads((R/'IMMUTABLE0935_HASHES.json').read_text())
changed=[p for p,h in old_hashes.items() if hashlib.sha256((W/'review0935/source0935'/p).read_bytes()).hexdigest()!=h]
receipt={
 'decision':'PASS_BOUNDED_LOCAL_ENGINE_AND_NATIVE_ACCEPTANCE' if failed==0 and skipped==0 and parity['pass'] and not changed else 'FAIL',
 'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'independent_test_count':tests,'failures_or_errors':failed,'skipped':skipped,
 'legacy_case_count':parity['case_count'],'legacy_comparisons':parity['comparisons'],'legacy_pass':parity['pass'],
 'immutable0935_files_checked':len(old_hashes),'immutable0935_changed':changed,
 'source_hashes':source_hashes,
 'critical_witnesses':{
  'BCC1_full_joint_status':'FAIL','BCC1_complete':True,
  'BCC1_concurrent_receiver_utilization':1.0101145936065872,
  'selected_zero_cap_resistance_N':836842.4731829532,
  'selected_zero_cap_u_mm':556.,
  'full_cap_diagnostic_resistance_N':852842.4731829534,
  'full_cap_diagnostic_u_mm':559.6,
  'per_bolt_service_slip_resistance_N':72800.,
  'each_angle_segment_resistance_N':260687.89198705883,
  'gusset_equivalent_column_resistance_N':503329.31451562914},
 'scope':'Independent finite implementation acceptance of the reviewed bounded local engine and native schema only. No production modifications, fabrication approval, global brace stability claim, package, upload or publishing.',
 'presentation_acceptance':'Separately assigned; not part of this engine receipt.',
 'required_release_gate':'Parent must run applicable aggregate tests and independent UI/report/drawing acceptance on final source.'}
(R/'ENGINE_ACCEPTANCE0936.json').write_text(json.dumps(receipt,indent=2)+'\n')
report=f'''# Independent engine/native acceptance: LRO 0.9.36

Decision: {receipt['decision']}.

The reviewed bounded local bolted symmetric 2L-T compression implementation passes {tests} independent tests, with {failed} failures/errors and {skipped} skipped. All 22 inherited native cases retain their checked behavior across {parity['comparisons']:,} numerical/status comparisons. All {len(old_hashes):,} files in immutable 0.9.35 remain byte-identical.

## Critical results

- BCC1 is still a complete, calculated full-joint FAIL. The common concurrent receiver remains 1.0101145936065872; no alternative force or fixture geometry was substituted.
- The primary inward-U strength row selects 836842.4731829532N at u556mm. The full-cap 852842.4731829534N at u559.6mm is separately retained as a diagnostic; it is neither selected nor added.
- All 27 approved local strength witnesses, all 93 frozen inward path states, all five signed common chains, local angle properties and full-stripe plate stability match the frozen independent oracle.
- Physical split/direction tests cover each bolt plane, each hole wall, one shared gusset, and two slip interfaces. Metric 16 mm A325 uses 91 kN pretension; inch 15.875 mm uses 85 kN. Class A/B friction is separate from ultimate bolt/bearing resistance.
- Actual −20 kN and synthetic −45 kN whole-chain cases retain different lower cuts, identical explicit background D/U actions, independent local service demands and distinct provenance. Zero retains the existing explicitly labeled +45 kN tensile minimum convention.
- Geometry-bound declarations expire for bolt, hole, washer, contact, pretension, root, plate and support changes. Unknown/absent restraints, unidentified/special/exceptional combinations, missing physical hardware/continuation and method domain losses remain unverified at named components.
- Fresh physical-section reconstruction verifies partial tractions from both roots and both included/excluded cut-hole limits for gross and circular-net sections in the frozen fixture and a changed valid geometry. Pure negative normal stress does not become tensile rupture demand; actual tensile receiving surfaces remain checked.
- Two valid nonfixture cases at 44.5°/45.5°, 320×320×13mm, 40 mm clip and 55 mm pitch pass their complete results, demonstrating parameterized operation beyond 300 mm/45°.
- Native import requires complete new/detail groups, rejects forged outputs and malformed values, and recomputes stale geometry. Older native inputs do not invent friction/restraint qualification.

## Review and reproducibility

`test_independent_engine0936.py` was authored outside production and imports no candidate calculator. Its data source is the approved frozen qualification oracle with per-file SHA256 verification. `compare_legacy.py` replays native inputs recorded read-only before implementation; it checks every inherited numeric/boolean/status leaf. Exact engine hashes are in `ENGINE_ACCEPTANCE0936.json`.

Run from the workspace root with PYTHONDONTWRITEBYTECODE=1 and PYTHONPATH=review0936/source0936:connections_audit/test_dependencies. Invoke pytest on this directory's test file, directing cache and JUnit outputs here, then run compare_legacy.py. The parent owns aggregate and separate presentation acceptance.

## Limits

This is finite acceptance of the approved conventional local engineering model. It does not measure physical restraint stiffness, certify actual pretension/surface execution, authorize fabrication, or verify global member/frame/stitch stability. Nominal section extrema are numerical screens, not interval proofs or pointwise hole-contact stresses. Unsupported 1L friction/compression and alternative inward exit/L topologies remain outside the automatic route.

No production file was edited by this reviewer. No packaging, upload, publishing or release was performed.
'''
(R/'REVIEW.md').write_text(report)
print(json.dumps({k:receipt[k] for k in ('decision','independent_test_count','failures_or_errors','legacy_comparisons','immutable0935_changed')},indent=2))
