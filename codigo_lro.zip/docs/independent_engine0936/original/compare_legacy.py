"""Replay22 actual old native inputs and compare every inherited numeric leaf.

New diagnostic metadata may be added. Existing check identities, check outcomes,
case counts, physical numeric results, and all named status booleans must survive.
No earlier production file is edited, imported, or re-executed here.
"""
import json,sys,math,hashlib
from pathlib import Path
HERE=Path(__file__).resolve().parent
SOURCE=HERE.parent/'source0936'
sys.path.insert(0,str(SOURCE))
from lro.corner_gusset import CornerGusset,analyze
old=json.loads((HERE/'LEGACY0935_BASELINE.json').read_text())
comparisons=0;changes=[];records=[]
STATUS_KEYS={'status','complete','mechanics_complete','assembly_qualified','pass_','approved','diagnostic_only','case_id','id','all_required_checks_pass','all_listed_checks_pass'}

def compare(expected,actual,path):
 global comparisons
 if isinstance(expected,dict):
  if not isinstance(actual,dict):changes.append({'path':path,'old_type':'dict','new_type':type(actual).__name__});return
  for k,v in expected.items():
   if k not in actual:
    # Version/method prose may be legitimately replaced; numeric or structured
    # fields are not silently forgiven.
    if isinstance(v,(int,float,bool,list,dict)) or k in STATUS_KEYS:changes.append({'path':path+'/'+k,'reason':'missing'})
   else:compare(v,actual[k],path+'/'+k)
 elif isinstance(expected,list):
  if not isinstance(actual,(list,tuple)) or len(expected)!=len(actual):changes.append({'path':path,'old_len':len(expected),'new_len':len(actual) if isinstance(actual,(list,tuple)) else None});return
  for i,(a,b) in enumerate(zip(expected,actual)):compare(a,b,path+'/'+str(i))
 elif isinstance(expected,bool):
  comparisons+=1
  if type(actual) is not bool or actual!=expected:changes.append({'path':path,'old':expected,'new':actual})
 elif isinstance(expected,(int,float)):
  comparisons+=1
  if isinstance(actual,bool) or not isinstance(actual,(int,float)) or not math.isclose(actual,expected,rel_tol=1e-12,abs_tol=1e-8):changes.append({'path':path,'old':expected,'new':actual})
 elif path.rsplit('/',1)[-1] in STATUS_KEYS:
  comparisons+=1
  if actual!=expected:changes.append({'path':path,'old':expected,'new':actual})

for name,z in old.items():
 start=len(changes)
 try:
  c=CornerGusset.from_dict(z['native']);result=analyze(c)
  compare(z['result'],result,name)
  records.append({'name':name,'status':result['status'],'changes':len(changes)-start})
 except Exception as e:
  changes.append({'path':name,'error':repr(e)})
  records.append({'name':name,'error':repr(e)})
report={'pass':not changes,'case_count':len(old),'comparisons':comparisons,'cases':records,'changes':changes,
        'baseline_sha256':hashlib.sha256((HERE/'LEGACY0935_BASELINE.json').read_bytes()).hexdigest()}
(HERE/'LEGACY_PARITY0936.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({'pass':not changes,'case_count':len(old),'comparisons':comparisons,'changes':changes[:25]},indent=2))
sys.exit(bool(changes))
