# Implementation record: single-key concrete component

Isolated implementation based on the reviewed source contract below. Source record and formulas were qualified 2026-10-10. The implemented virtual parallel construction follows the corrected direct ACI single-anchor interpretation; the withdrawn universal finite-key-net-area inequality is not used.

Implementation: `lro/single_key_concrete.py`; optional UI and independent drawing/Word/JSON modules. The two explicit states are `native_nbr_full_depth` and `aci_limited_bearing_centroid`. All original NBR calculations remain unchanged. Anchor tension modes consume each state's own real Ti; no anchor shear vector is fabricated. The optional model reuses the existing block bounds, physical rod geometry and documented Ase,N.

Independent arithmetic: `validation/verify_single_key_concrete.py` generates `tests/fixtures/single_key_concrete_independent.json` at 50-digit Decimal precision, with no production imports. Run focused tests with `python -m pytest -q tests/test_single_key_concrete.py tests/test_single_key_concrete_artifacts.py tests/test_single_key_concrete_app.py`. Other existing native regression tests are listed in the integration handoff. Whole-app aggregate and release are separate gates.

A missing/unsupported supplementary force state does not erase local edge or no-gain bearing calculations. Numeric failure precedes unrelated pending detail. Every local pass is conditional on actual physical prerequisites and never approves the complete key, anchorage, plate transfer, block or foundation.

---

# Single rectangular shear-key concrete: finite feasibility decision

Date: 2026-10-10 UTC. Reviewed baseline: `connections_work095/source`. No production changes; neither095 nor096 was edited. This is a source/implementation contract, not project engineering approval.

## Decision

**GO** for an explicitly selected, complementary, conservative ACI318-19 §17.11 component calculating (1) key concrete bearing and (2) concrete edge breakout, for one centered solid rectangular key transferring the entire signed uniaxial V. Existing real block dimensions and offsets are sufficient. A deep key is not automatically prohibited: retain the existing full-depth NBR state and create a separately named limited-bearing-centroid supplementary state. Do not alter the original column-top actions.

**GO for a bounded automatic supplementary Type1 force state**, subject to the uniform-bearing/contact assumptions below. **No automatic transfer of the Type1 high-moment model to Type2.** Type2 retains its own admissible C1/C2/T1/T2 topology and can support its own supplementary state only within that topology. Its valid local numeric concrete results must survive a pending supplementary-equilibrium condition.

The concrete strength kernel is finite now. There is no missing formula requiring another broad source search. Missing *project data* are actual rod restraint, a compatible cast-in/grouted detail with vent holes, and nominal rod steel information in axial tension when not already supplied. Full standard-enhanced thin/narrow geometry is not required for the conservative first branch specified here. It must be named a **conservative ACI-based component**, not an implementation of every optional provision or a complete foundation design.

## 1. Source record and verification

1. Supplied AISC DG1 third edition, file `new_references_20261009/AISC-Design-Guide-01-Base-Connection-Design-for-Steel-Structures-3rd-Ed.pdf`: printed pp78-80 (general key requirements), pp80-87 (Ex4.7-5, anchor equilibrium and concrete), pp38-46 (§§4.3.6/4.3.7 uniform-bearing mechanics). PDF page = printed+10. Printed79 and86 were rendered and visually inspected; matching text is retained in `source_pages`.
2. ACI318-19 actual code/commentary: printed277-283/PDF279-285, §§17.11.1-.3; printed261-269/PDF263-271, §17.7.2. Actual clauses and figures, including bearing-area definition, axial factors, anchorage ratios, virtual parallel-edge rule, corner requirement and thin-member formula, were read. Printed269,280-283 were rendered and inspected. Downloaded from the [university-hosted code copy](https://www.ocf.berkeley.edu/~chiep/wp-content/uploads/2024/01/CE-123-ACI-318-19.pdf). Do not bundle the full code or its scans with application deliverables.
3. ACI's [official anchorage presentation](https://www.concrete.org/portals/0/files/pdf/webinars/ws_F23_Matthew%20Senecal.pdf), slides132-140, independently confirms four anchors, anchorage ratios, vent holes, bearing limit and key projection.
4. Richard T. Morgan, P.E., [original Hilti technical article](https://www.hilti.com/engineering/articles/integrating-shear-lug-design-with-aci-anchoring-to-concrete-provisions), especially Figures3-4. Its virtual parallel-edge drawing originates at the key center; this supports the separately prescribed single-anchor-like construction, not an inequality between point and finite-key net areas. Its thin-member modification uses sqrt[(hef,sl+1.5ca1)/ha], whereas the directly incorporated anchor equation prints sqrt[1.5ca1/ha]. This first branch avoids quietly choosing or blending these positive enhancements: psi_h=1 explicitly.
5. [AISC DG1 third-edition errata, May23,2025](https://www.aisc.org/globalassets/aisc/publications/revisions-and-errata/design-guide-1-3rd-ed.-revisions-and-errata-list.pdf) corrects p80's accidental “Vu” to “distance.” No change to pp85-87 concrete arithmetic is listed. ACI's official errata page was checked but the dynamic document selector did not expose a specific318-19 errata file. Do not claim a comprehensive edition/errata reconciliation; the stated formulas are verified against the actual2019 clauses and supplied DG1.

## 2. Exact physical domain and source conditions

- One unstiffened solid rectangular vertical key, centered below a rectangular plate; x follows actual signed V, y follows key width, z is downward. Key thickness t=`lug_t`; width b=`lug_bh`; total below-plate projection H=`lug_bv`; grout g=`grout_t`.
- Actual concrete key embedment h=H−g>0. Effective ACI depth d=min(h,2t). This starts at the **concrete surface**, not the underside of the baseplate and not the grout top. Effective bearing area Aef=b d. No grout area is added.
- Rectangular monolithic block, actual bounds xmin/xmax/ymin/ymax and depth ha=`block_h`, all specified boundaries treated as free edges. Require xmin<−t/2<t/2<xmax; ymin<−b/2<b/2<ymax; ha>h. Integral continuation into a larger footing cannot be credited by inventing a missing free edge. Hollows, open pockets, sleeves, joints or blockouts without a qualified filled transfer detail do not inherit intact-concrete strength.
- Normalweight cracked concrete, lambda_a=psi_c,V=1; no supplementary-reinforcement enhancement; actual strength maturity. App fck20-50MPa is inside the ACI cast-in strength limit. Use that value as the explicitly adopted complementary f'c, without dividing it by gamma_c.
- Static single-axis action, no torsion, biaxial V, ribs, cruciform, W-key, cyclic/seismic/fatigue or pre-grout transfer.
- At least four anchors, and all demanded Chapter17 tension modes remain separately required. ACI17.11 does not create a key pryout check using an anchor diameter: the plate/anchors provide moment restraint, and the key bearing and edge-breakout modes are the prescribed local concrete modes.
- Whenever any real anchor is in tension in a required force state: hef >=2.5h AND hef >=2.5csl. Here h is **physical** key embedment, not limited d. csl is the distance along actual V from key centerline to the nearest tension-active anchor row; for the centered symmetric4-rod layouts it is c.a, not a diagonal distance. Existing geometry supplies these quantities.
- Actual rods welded to the attachment require the §17.11.1.1.3 shear-interaction provision. **A washer welded around its perimeter does not establish that the rod itself is welded or has identical restraint.** Store/reference the actual rod-to-plate detail. The first component can admit confirmed unwelded/non-rigidly-attached rods; unknown restraint is pending, actually welded rods require the separately supported concurrent shear-interaction model. Do not infer Vi=0 or Vi=V/4 from a weld label.
- Minimum one25.4mm inspection/vent hole near each long key face, flowable nonshrink grout/consolidation detail. This is an ACI model prerequisite, not a universal NBR prohibition. Missing holes do not mean an otherwise valid NBR result must be discarded. Holes must be addressed in the applicable plate/contact model; this concrete component does not prove their plate-strength effects.

## 3. Bearing and actual axial state

For each relevant state:

Vbrg=1.7 f'c Aef psi_brg; Rbrg=0.65 Vbrg; demand=abs(Vactual).

Pu is original applied signed N, positive compression. Do not replace Pu by contact force C, sum of anchor tensions, or a moment-equivalent force.

- N=0: psi_brg=1, even if the induced moment tensions two rods.
- N<0: psi_brg=1+N/(n Nsa) <=1; n is the number of **actual positive Ti** in this same state. Identical rod Nsa=Ase,N min(futa,1.9fya,125000psi). Use nominal ACI rod steel strength, not native NBR design strength, gross rod area or phiNsa. Current native rod grade is A36/fy250/fu400MPa; `ConcreteComponents.area_tension` and its source can provide the documented area. No Ase,N: this bearing branch is pending. If n=0 with N<0, the state is invalid. If psi<=0, positive shear has no positive bearing resistance and fails; never abs() the factor or let another passing mode erase the failure.
- N>0: psi_brg=min[2,1+4N/(Abp f'c)]. Abp is the actual contact area, supplied by the same qualified contact state. A gross full-width contact strip B*lc is available from current mechanics, but holes/cutouts matter. If it is explicitly an upper bound on actual contact area, using it only in the modifier is conservative, and must be labeled Abp_used_upper_bound. This does **not** qualify an incorrect pressure/contact model. If actual contact is unqualified, either leave the gain pending or deliberately select psi=1 with the label “compression enhancement not credited”; do not assume a smaller invented area. N>0 and no contact is an invalid equilibrium.

The ACI check runs beside unchanged NBR full-depth contact [1.7 fck/gamma_c] b h. Do not replace the NBR check, reduce its capacity-development weld actions, add friction, or feed the ACI bearing resistance back as actual V.

## 4. Physical edge areas and conservative first-release strength

### Edge normal to V

For V>0: loaded edge is x=xmax and ca1=xmax−t/2. For V<0: loaded edge is x=xmin and ca1=−xmin−t/2. This is distance from **loaded key face**, not from the rod or key center. The opposite x edge is not a second opposing actual load. Reversal changes the selected face and edge.

Let r=1.5ca1; c2−=−b/2−ymin; c2+=ymax−b/2.

W=b+min(r,c2−)+min(r,c2+)
D=min(ha,d+r)
AVc=W D−b d
AVco=4.5ca1²
psi_ed=min[1,0.7+0.3 min(c2−,c2+)/r]
Vb=9 lambda_a sqrt(f'c_psi) ca1_in^1.5 [lbf]
Rperp=0.65 (AVc/AVco) psi_ed psi_c psi_h_used Vb.

The projected gross rectangle on the actual loaded block side is y∈[max(ymin,−b/2−r), min(ymax,b/2+r)], z∈[0,min(ha,d+r)]. Remove the effective key rectangle y∈[−b/2,b/2], z∈[0,d]. Report both polygons and their net area. **Do not cap AVc at AVco:** DG1's example legitimately has AVc/AVco>1 because the key is extended.

### Both edges parallel to actual V

ACI17.11.3.2 permits the §17.7.2.1(c) virtual perpendicular construction with ca1 measured from the edge to the **key center**, and the parallel multiplier2. Figure4a of the primary Hilti article illustrates that virtual origin. Evaluate both y edges with the same actual abs(V); this is a failure-surface check, not a new physical Vy.

The finite first branch uses the **virtual single-anchor construction directly authorized by ACI17.11.3.2**, with the key center replacing the single-anchor axis. Section17.11.3.1.1's finite-key area belongs to the immediately preceding *perpendicular* subsection17.11.3.1; it is not the geometry stated by the sibling parallel-edge clause. Section17.11.3.2 instead points to17.7.2.1(c), which assumes a perpendicular virtual load and invokes17.7.2.1(a); its ordinary projected half-pyramid area is defined in17.7.2.1.1 from the selected axis. CommentaryR17.11.3.2 expressly states the single-anchor analogy. HiltiFigure4a independently shows the point-origin plan wedge. The resulting projected area is clipped to the actual member side/height under17.7.2.1.1.

Thus use a **virtual point projection** from (x,z)=(0,0), without inventing a fictitious key width/depth for that construction:

ca1=ymax or −ymin; r=1.5ca1
AVc_parallel=[min(r,−xmin)+min(r,xmax)] min(r,ha)
AVco=4.5ca1²; psi_ed=psi_ec=1; psi_c=psi_h_used=1
Rparallel=0.65*2*(AVc_parallel/AVco)*Vb.

This is the separately code-authorized virtual edge construction, **not** an alleged geometric lower bound on finite-key net area; **no rod diameter, rod embedment, seven-coefficient small-anchor formula, pryout or rod force allocation enters it**. Do not call the existing full anchor shear kernel with invented rod inputs. The three candidate surfaces are the loaded x face and both y faces; the minimum resistance governs. Corner conditions therefore cannot disappear just because V has no y component.

### Thin/narrow policy: calculate, do not reject

Use actual ca1 and psi_h_used=1 in the first branch. Show when bottom and/or side clipping occurs. Do not automatically take the positive thickness enhancement, and do not apply a hidden narrow-member effective-ca1 increase.

This is a lower-bound policy, not an assertion that ACI's exact modifier always equals1. §17.7.2.6.1 prints sqrt(1.5ca1/ha)>=1; Hilti's explicit key adaptation uses sqrt[(d+1.5ca1)/ha]>=1. Both are >=1, so omitting the enhancement is conservative. The no-effective-ca1-enhancement proof is restricted to the actual all-clipped condition in§17.7.2.1.2: both transverse clear distances and ha are less than r=1.5ca1. The code's replacement r'=1.5ca1' is at least the greater transverse distance and ha (a nonnegative spacing term may only enlarge that bound). Therefore both old and replaced projections remain clipped to the same side width and ha. For the normal-key projection its fixed subtraction b*d is unchanged; for the virtual point there is no such subtraction. In **this domain only**, AVc is constant, Vb/AVco is proportional to ca1^−1/2, and psi_ed cannot decrease as ca1 is reduced. Retaining physical ca1 and omitting the nonnegative enhancement gives no greater resistance than that corrected construction. Do not extend this proof to one-sided clipping, partial height clipping, an arbitrary ca1 replacement, or different geometries. It avoids inventing an anchor spacing from key width.

**Correction,2026-10-10:** the earlier universal claim that virtual-point area never exceeds finite-key net area was false and is withdrawn. Once gross side widths are fully clipped, a finite-key model still subtracts its projected steel rectangle, while the distinct point model does not. For t50,d60,x±300,ha400,ca1=500mm, the point area is240000mm², whereas a separately invented finite-key-side net area would be237000mm². Neither may be substituted for the other based on a claimed area ordering. The parallel route is justified only by the direct17.11.3.2 single-anchor construction described above; do not append an ad hoc t*d or overlap deduction. If a future interpretation requires finite-key area in the parallel direction, it is a different geometry contract and must be reviewed explicitly.

**A failure means failure of this declared conservative model, not proof that reinforcement or a more refined code calculation cannot work.** A passing result may close this numerical component when its prerequisites are met. Taking all exact thin/narrow enhancements later requires a separately reviewed geometric contract; it is not a blocker for the defined lower-bound component.

## 5. Force states: retain real global equilibrium

Original top actions are immutable {N,Mtop,Vtop}. Native NBR state remains exactly as shipped:

e_native=tp+g+h/2 =tp+(H+g)/2;
Mbase_native=Mtop+Vactual e_native.

Separate ACI-limited bearing state:

e_aci=tp+g+d/2;
Mbase_aci=Mtop+Vactual e_aci.

Do not use prescribed Vw/Mw, do not replace c.M, and do not fake a shifted top M merely to call an old helper. Column weld still sees original column-top N/M/V. Local key bending/receiving plate and anchor effects use their actual named interface actions. Keep both states and compare applicable checks per state; do not combine one state's contact, another's anchor count, or the largest unrelated forces into a fictitious concurrent state.

### Type1 finite statics contract

The supplied DG1 §§4.3.6/4.3.7 and Ex4.7-5 support a **uniform full-width rectangular contact stress block**, actual external rod rows x=±a, equal tension in the two rods of an active row, and no prying or stiffener redistribution. This is the same broad force topology as the present Type1 model. The component must declare this model and preserve its plate-transfer qualification boundary; merely satisfying equilibrium does not establish arbitrary flexible-plate compatibility.

Use a pure force-region solver with explicit inputs N, signed Mbase, real L/B/a and pressure_limit. Return contact interval/area/centroid, all4 signed rod locations with nonnegative Ti, state case, residualN/M and model identifier. No mutation of BasePlate or call through the entire evaluator.

For the separate ACI state, a bounded no-confinement pressure basis is fpu=0.65*0.85f'c, A2/A1=1, DG1 J8/§4.3.7. Do not import the source example's A2/A1=4 automatically. This pressure basis is distinct from native0.85fck/1.4. A declared different mechanically justified bearing state is possible later, but must not be silently inferred from block dimensions.

With qmax=fpu*B, K=L/2+a, m=abs(Mbase):

- Compression-only admissible when N>0 and m/N <=(L−N/qmax)/2: lc=L−2m/N; C=N; Ti=0.
- Tension-only admissible when N<0 and m<=abs(N)*a: two high-row rods carry abs(N)/4+m/(4a), and two low-row rods abs(N)/4−m/(4a).
- Mixed contact/tension: lc=K−sqrt[K²−2(m+Na)/qmax]; use rationalized smaller root; C=qmax*lc; high-row Ti=(C−N)/2; low-row Ti=0. Check radicand, 0<=lc<=L and all forces. Restore sign through actual row coordinates.
- Zero N/M gives zero contact/rod force. Positive V still has concrete demand.

Check C−sum(Ti)=N and C*xC−sum(Ti*xi)=Mbase. Evaluate each demanded ACI anchor mode using its state's own Ti. Both native and complementary cases may be checked with ACI strengths as separate force idealizations; no gamma_NBR*phi_ACI product. Existing native NBR plate/rod checks remain intact. Any new supplementary plate checks retain explicitly identified NBR capacities and applicable physical plate sections; do not claim that this statics helper itself verifies plate bending or key-to-plate transfer.

### Type2: exact separate boundary

Current `pinned_base_plate.reactions` uses its own C1/C2 or T1/T2 mechanics and internal rows a=a2/2. Its T1/T2 plate mechanism has l0=min[dcolumn,a2+1.75(a2−tw)] and cannot use Type1 external-strip bending. It intentionally rejects C3/T3/pure moment. This contract does not change that domain.

A Type2 supplementary implementation may parameterize **that same** existing C1/C2/T1/T2 solver with the separately transported Mbase and explicit pressure limit, preserving its own contact and plate-strip formulas. Compression-only contact remains B*lc; tension-only states remain zero contact with4 real internal rods. It must independently establish that those same physical regions remain applicable to the changed key reaction. No Type1 high-moment fallback is allowed. If an ACI-pressure/centroid state requires C3/T3/pure moment or its contact-strip qualification is absent, report that exact supplementary-state prerequisite pending, while retaining any independent bearing/breakout numeric checks and unchanged native Type2 results. A qualified documented Type2 force/contact state is a finite alternate input; general FEA is not required.

## 6. Existing inputs versus genuinely missing information

Already present: key b/H/t/g; plate thickness/dimensions; original signed N/M/V (Type2 Mtop=0); block xmin/xmax/ymin/ymax/ha; concrete/grout strengths;4 real rod coordinates; hef; rod type/detail record; actual native Ti and contact lc/C; documented Ase,N and source if the ACI anchor component was configured. Block offsets are already represented by unequal bounds. Do not ask for a new arbitrary “edge distance” that can conflict with them.

New finite data/selection:

1. Explicit complementary key-concrete model selection and the stated conservative projection/no-enhancement policy.
2. Actual rod restraint: not welded/not rigidly attached, welded/rigidly attached, or unknown, with a detail reference. Washer perimeter weld alone cannot answer it.
3. Consolidation/filled-key detail and vent-hole compliance record. This is not blanket confirmation of whole-base strength.
4. If N<0, documented nominal ACI rod tension area/material; reuse existing qualified area data rather than duplicate them.
5. If compression enhancement is credited, qualified contact area/area upper-bound policy for that state, otherwise explicitly no gain.
6. State qualification/status: Type1 supported uniform-bearing topology; Type2 supported native topology or documented compatible alternative. Store signature across dimensions, N/M/V, d, pressure basis, rod coordinates and detail changes.

Missing proof of full anchor tension modes, head/plate/thread assembly, receiving plate transfer or reinforcement can remain existing separate pending paths. Numeric concrete failures must precede those pending labels. A component pass must not become complete key, attachment, anchorage or base.

## 7. Independent fixtures and source arithmetic

`independent_fixtures.py` uses50-digit Decimal, exact in/lbf/psi conversion and no production imports. `independent_fixtures.json` contains15 local cases, source concrete fixture, source equilibrium fixture and the cancellation trap. It was executed successfully with assertions enabled. These are arithmetic/geometry references, not production integration tests or full project proofs.

- DG1 Ex4.7-5: b8in, t1in, physical/effective h2in, fc4000psi, ca1=14.5in. Aef16in²; AVc1207.125in²; AVco946.125in². Exact phi bearing70.72kip; exact phi breakout26.0640314658kip. Source prints70.9kip because it rounds nominal108.8 to109 before multiplying by0.65; prints26.1kip for breakout. Do not force fixtures to reproduce premature rounded intermediate values.
- Source equilibrium, bottom-plate action plane, M75kipin, B=L15in,a4.25in, explicitly qualified source confinementA2/A1=4: independently reproduces contact/anchor values on pp82-83. That confinement is **fixture-only**, not application default.
- Practical lower-bound pass: b100,H100,g40,t50.8mm,fc20MPa, block x±600,y±500,ha700mm,V50kN,N0. Governing x-edge ratio0.828638315. Reversing V in a symmetric block gives identical capacity and reflected face.
- Same geometry,V200kN: local failure ratio3.314553259.
- Offset block xmin−950/xmax250: positive and negative V select different real ca1; their results differ. Under the explicitly conservative physical-ca1 policy, a more distant loaded face is not guaranteed to increase strength when the same finite projected side is fully clipped. Do not use assumed monotonicity to skip surfaces.
- Near parallel edge ymin−80: virtual y− surface governs at V50kN, ratio3.191227858; ignoring parallel edges would miss it.
- Thin block180mm, x±300,y±1000,V10kN: physically clipped model still calculates and passes ratio0.601743696. ha50mm with physical keyh60 is invalid, not a zero-area pass.
- N positive modifier including cap2; N negative/n4/Nsa98kN; missing Nsa pending; psi=0 failure; V0 not demanded; deep key requiring supplementary state.
- Signed cancellation trap: tp38.1,g40,H150,t31.75mm,V100kN,Mtop−13.31kNm. Native e133.1mm gives Mbase0. ACI d63.5,e109.85mm gives Mbase−2.325kNm. With independent Type1 L370,B260,a145,fc30, no-confinement ACI pressure, two rods carry3531.496813N each. Native zero-anchor demand cannot be reused. A larger native lever is demonstrably not always conservative.

## 8. Integration acceptance and stopping condition

Minimum tests: source values; b/h/t/grout mapping; h<2t, h=2t,h>2t; both V signs and V0; positive/zero/negative N; tension-active2 versus4 rods and near-zero rod transition; missing area; psi<=0; actual face versus center distances; both parallel edges; bottom/one-side/two-side clipping; physical no-fit; arithmetic overflow; all geometry and source policies in report; noV/4; no NBR bearing/weld-action regression; unchanged top weld actions; unchanged native state; independent state residuals; Type2 remains in its own domain; rods welded versus washer-only distinction; missing vent detail limited to optional ACI status; stale signature; JSON round trip; numeric failures survive unrelated pending data.

Stop after these finite components and state plumbing, with reports showing resistance basis, real polygons, actual/supplementary state and residuals. No general anchor or key redesign is needed. NBR6118 reinforced-block/global member design, development of reinforcement crossing breakout surfaces, footing/soil transfer, construction joints, erection and full local steel transfer remain external project work. If the conservative concrete branch fails, refining the specific surface or designing reinforcement is a defined project alternative, not an indefinite research task.
