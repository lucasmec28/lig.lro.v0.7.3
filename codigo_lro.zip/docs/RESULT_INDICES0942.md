# Separação dos índices de resultado de end plate

Candidato isolado de apresentação sobre a fonte imutável 0.9.41. Não altera a versão distribuída, não entrega novo pacote e não amplia nenhum método de cálculo.

## O problema e a correção

O máximo indiscriminado de todos os checks incluía resistência e condições do método. No exemplo rotulado de V e tração, o valor 0,9525 vem do limite construtivo de espessura da rótula. A maior utilização resistente disponível é 0,16091197042435612, na interação local N/V da alma. Exibir o primeiro como aproveitamento resistente era ambíguo.

A interface, o croqui e as duas rotas Word passam a distinguir:

- Utilização resistente: máximo bruto, finito e aplicável, exclusivamente das linhas classificadas pelo motor como Resistência. O mecanismo e seu caso governante acompanham o valor e conservam o resultado do motor, inclusive Não atende ou Não qualificado.
- Condições do método: máximo separado das linhas já classificadas como Condição do método, com mecanismo, caso e resultado próprios. Inclui critérios geométricos, espessura, compacidade e desenvolvimento previamente existentes. Esse índice não é utilização resistente.
- Geometria e detalhamento: alertas já produzidos pelo motor, sem inventar uma razão numérica para restrições que só têm diagnóstico. Ausência de alertas detectados não significa aprovação de toda a geometria física.
- Escopo: pendências locais, extrapolações, exclusões e casos requeridos sem conclusão. Falhas numéricas e dados ausentes ficam explícitos, mesmo quando há outras comparações finitas disponíveis.

As categorias físicas existentes não são reinterpretadas. O contrato não constitui uma nova verificação de engenharia. As tabelas-resumo Word identificam o tipo de cada linha. O croqui usa espaço adicional de anotação, sem mudar os dados das coordenadas, furos, dimensões ou forças.

## Contrato do JSON nativo

O campo verification.result_indices é aditivo e contém contract_revision=endplate-result-indices-0942-v1. Ele é recalculado a partir das entradas atuais e não é lido como autorização na importação.

- resistance e method_conditions contêm max_ratio, governing e available_checks.
- governing contém identidade, nome, caso, categoria, razão bruta e resultado da linha selecionada.
- Um máximo sem linha finita e aplicável é null, nunca zero. Uma falha numérica não vira capacidade infinita ou aprovação.
- A procura das falhas numéricas percorre as linhas de todos os casos, além da envoltória. Um resultado finito da Entrada não oculta um caso mínimo inválido.
- geometry_and_detailing_issues, method_issues, pending_scope_issues, outside_scope_issues e data_or_numeric_issues preservam os diagnósticos originais. invalid_checks e unresolved_cases apontam os mecanismos/casos sem conclusão.
- O campo legado verification.max_ratio e todos os demais campos anteriores continuam com os mesmos valores. legacy_max_ratio_basis declara que esse campo legado mistura condições do método e não é a utilização resistente. Novos consumidores devem usar result_indices.resistance.max_ratio para a utilização resistente.
- Nenhum campo de aprovação é acrescentado ao novo bloco. status, approved, complete_within_declared_scope, revisões do método e decisões existentes não foram alterados.

O resumo usa as linhas brutas da envoltória, antes dos agrupamentos de exibição: uma condição de espessura não esconde o ramo resistente de plastificação.

## Precisão e limites

O contrato numérico não arredonda nem altera entradas, demandas, resistências ou decisões. A apresentação usa duas casas decimais, com notação científica para valores pequenos não nulos. O índice 1,000000001 aparece como 1,00 acompanhado do resultado Não atende. A escolha do governante usa a precisão integral.

Rotulada com N/V continua com qualificação local incompleta; nenhuma melhoria de texto fecha essa pendência. Variantes 4E, 4ES, 8ES e MRE1/2 mantêm exatamente seus domínios, ações assinadas N/V/M, casos mínimos e requisitos físicos existentes. Os números locais não aprovam fabricação nem estabilidade global.

## Evidência e testes

O diretório de trabalho result_indices0942/evidence contém a paridade de 225 configurações contra a fonte 0941, antes e depois da alteração. Após remover apenas o bloco aditivo, todos os campos nativos anteriores e resultados do motor são idênticos, incluindo status, mecanismos governantes, razões brutas e resultados das linhas.

O novo arquivo tests/test_end_plate_result_indices0942.py cobre separação resistente/método, N/V e N/V/M assinados, todas as variantes, entrada/mínimo, valores ausentes/não finitos, zero sem mecanismo ativo, precisão, governante, importação adulterada, UI, invalidação Word, croqui e Word compacto/detalhado.

Três expectativas de apresentação históricas foram atualizadas explicitamente: o texto genérico Índice máximo passa a Utilização resistente; as testemunhas resistentes reprovadas 1.06 e 1.38 passam aos rótulos Utilização resistente: 1,06 e Utilização resistente: 1,38. A segunda conserva a testemunha bruta 1,3821057275761033 e o mecanismo ep_beam_web_local_tension. O teste histórico que exige as ressalvas no início do Word foi mantido sem alteração: as ressalvas aparecem imediatamente após o status, antes do novo resumo. Nenhuma asserção física foi removida ou flexibilizada. Os diffs completos fazem parte do patch.

O teste histórico que depende de next_connection_scope/bolt_bearing_oracle.json permanece sem alteração. Busca de arquivos locais e arquivos ZIP, inclusive conteúdos internos e deduplicação SHA-256, não encontrou o original. Não foi criado oráculo a partir do motor, substituído resultado nem pulado teste. A falha permanece explicitamente contabilizada.
