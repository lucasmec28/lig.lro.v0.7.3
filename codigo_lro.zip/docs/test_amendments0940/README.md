# Bounded test amendments for 0.9.40

Only three inherited test files change: two explicit global application version expectations in the corner/navigation guards and the explicit legacy-import 4E method revision in test_end_plate_4es0922.py. Component schemas, assertions of engineering state, cases, parameterizations and tolerances are otherwise retained. Exact internal-0.9.39 test bytes and the full diff are preserved here.

The correction adds 61 dedicated force-source regressions. All inherited fixture files, including W-option commitments, are byte-identical. Existing 0.9.39 metadata projections and all their frozen hashes/mutation witnesses are retained unchanged. No old engineering oracle is edited to make the correction pass. The absent external axial bolt-bearing oracle remains a genuine failed test.
