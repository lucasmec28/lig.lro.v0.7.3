# Alterações 0.9.43

Base: versão entregue 0.9.42-result-indices-base-key-plate-dev.

- Novas rotas independentes 1L e 2L soldadas à mesa do pilar e parafusadas à alma da viga.
- Novos motores, entradas nativas estritas, interface, desenho, Word editável e testes para os domínios documentados.
- Dezenove rotas anteriores mantidas em seus índices, com preservação da separação dos índices resistentes/método e da chapa receptora 0.9.42.
- Ajustes documentados exclusivamente de identidade da release e tamanho do catálogo nos testes históricos.
- Sem importação automática de JSON, ampliação de single plate/cortante rotulado, publicação ou implantação.
