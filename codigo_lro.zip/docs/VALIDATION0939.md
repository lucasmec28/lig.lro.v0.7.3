# Validação da fonte 0.9.39

**Checkpoint interno, não entregue e não destinado a empacotamento.** A direção de entrega foi suspensa para corrigir na sucessora 0.9.40 uma discrepância legada confirmada no caminho das demandas da alma do pilar do modelo 4E. Essa constatação de fonte/método não demonstra falta de capacidade de uma ligação real. Os bytes deste checkpoint permanecem como base rastreável.

As três alterações autorizadas são o primeiro corte externo perpendicular e limitado da chapa de nó, a correção de alerta geométrico da Ligação 18 e a opção de talas internas na emenda W convencional. Permanecem as 19 rotas e a apresentação de até duas casas decimais; cálculos e arquivos nativos conservam a precisão integral.

## Suíte completa nos bytes finais

**5.762 casos distintos: 5.761 aprovados, uma falha histórica, zero erros e zero pulados.** Houve uma execução completa da árvore final, repartida em quatro grupos disjuntos de arquivos. Os 341 arquivos de runtime, testes, entradas e catálogos foram idênticos antes e depois e coincidem com o hold v4. A coleção e o registro individual não têm casos omitidos ou duplicados. Logs, XMLs, manifesto e registro individual estão em validation0939/aggregate. Execuções incompletas anteriores são preservadas como diagnóstico e não contam para esta cobertura.

A falha é a ausência do arquivo original next_connection_scope/bolt_bearing_oracle.json, no teste test_bolt_bearing_oracle_file_and_opposite_loaded_free_ends. Não há substituto inventado, skip ou transformação em aprovação.

## Revisões independentes e compatibilidade

A revisão mecânica cobre o polígono limitado, raízes e pegadas, seções reais, caminhos L/U, sinais, contatos, estresse extremo racional e condições de compressão herdadas. Sete compromissos numéricos originais e 19 payloads completos de rotas opostas permanecem exatos. Há 52 casos independentes de término de solda, inclusive a igualdade exata de uma perna de filete.

As adaptações de testes antigos são restritas e documentadas em test_amendments0939: todos os 29 hashes congelados permanecem exatos; 29 mutações comprovam que grandezas antigas, falhas, versões inesperadas e cortes ativos não desaparecem na comparação. Os 41 arquivos de fixtures herdados permanecem byte a byte. A mudança de arranjo parafusado tem nove verificações independentes, com rejeição atômica sem ajuste de valores e descarte de memória obsoleta.

As contagens de revisão, polígonos, compromissos, páginas e artefatos são unidades diferentes e não se somam aos 5.762 testes. Os comandos portáteis e compromissos compactos ficam no APP; a conferência crítica não exige a fonte antiga nem os acompanhantes opcionais.

## Exemplos, alcance e entrega

Os 84 arquivos selecionados foram gerados no hold v3. Sua identidade real é mantida, com ponte revisada para o hold v4, cuja alteração de runtime é somente o callback de interface. Os 28 JSONs nativos/de resultados no APP são cópias exatas dos selecionados. Versões de componentes não são rebatizadas. Falhas, estados fora do alcance e pendências permanecem visíveis.

Não há segundo afunilamento, K novo, liberação de compressão 1L, aprovação por Cheng nem método novo de base ou end plate. A Ligação 18 interna continua pendente quanto à aleta perfurada e ao acesso real de montagem. O corte físico reduz resistências quando aplicável; não é um efeito cosmético.

A fonte 0.9.38 foi conferida sem alteração. Esta aceitação é da fonte; construção isolada do pacote, revisão APP-only real e decisão de entrega são gates separados. Não aprova fabricação ou o sistema estrutural completo.
