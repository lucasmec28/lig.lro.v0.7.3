# Strong-axis beam-and-column corner gusset: bounded method qualification

11 October 2026. Read-only source/method pass. No production edits. This is distinct from the weak-axis internal-fin/Ligação 18 family.

## Decision

**GO for the force method and finite component architecture; a complete real-profile local fixture is required before production strength implementation.** There is a conventional finite calculation path, with directly relevant primary sources. No exact-matching published detail, exact elastic compatibility solution, new book hunt, or finite-element analysis is a prerequisite.

The useful first branch is a planar corner gusset welded to the exterior column flange AND beam flange, centered on both member webs, with the beam flange/web welded to the column flange and explicitly designed transverse continuity plates at beam-flange levels. Start with static tensile 1L and symmetric T-2L brace-to-gusset variants already qualified as local brace attachments; their new common gusset, two support seams, receiving regions and beam-column joint must be checked afresh. For the static 1L branch, preserve the qualified NBR 6.1.8.2 ordinary angle-eccentricity idealization explicitly; it does not erase in-plane force-line offsets, root moments, shear lag or arbitrary externally specified out-of-plane actions. Keep plate, angle, beam, column, stiffener and electrode materials independently selectable. Keep the Gerdau selection/default policy (leg at least 63.5 mm by default, not a universal structural minimum).

**This is a force-method GO, not approval of a particular fabricated joint or a release containing only seam checks.** The next bounded task is a complete, dimensioned real-profile example closing the actual plate, receiver, stiffener and joint paths, before production strength implementation. It is a calculation task, not another reference hunt. The numerical witnesses supplied here establish the force model, moment bookkeeping and selected resistance primitives without falsely calling incomplete fabrication geometry approved.

### Simplest selected force model

Use the **generalized UFM in DG29 Appendix A**, with the actual seam centroids. It removes the familiar geometric alpha/beta constraint while preserving an explicitly selected equilibrated force field. Adjustable brace angle therefore does not require resizing the gusset to one hard-coded angle or inventing a restriction such as alpha = beta.

For the first fully checked sub-branch, show and select the conventional work point at the beam/column gravity-axis intersection. Do not infer that location from Lucas's wording. Store/draw the actual brace transfer line and its offset. A custom or inner-corner work point activates DG29 §4.2.2 eccentric-force superposition; until its selected distribution is evaluated, it cannot receive a concentric-UFM pass. This is a visible geometry/method choice, not a need to ask the user for another reference now.

A finite alternative is the ordinary beta-fixed UFM with the residual moment retained on the beam seam. Its source is equally sound, but generalized UFM is the simpler zero-seam-moment first implementation. The conventional alternative is retained as an independent regression witness, not mixed into generalized demands.

## 1. Verified primary-source chain

Printed pages and physical PDF pages are both listed to avoid navigation ambiguity.

1. **Supplied AISC DG29 (2014), §1.2 and §§4.1–4.2:** printed p.1/PDF9, pp.17–21/PDF25–29 and pp.24–27/PDF32–35. Statically admissible force systems are permitted when the necessary component strength and deformation conditions are met. Classical zero-couple UFM requires its geometric constraint; a concurrent brace line alone does not prove zero seam moments.
2. **DG29 Appendix A, §§A.1.1–A.1.4:** printed pp.347–350/PDF355–358, Figs. A-1, A-2, A-3, Eqs. A-11 through A-16. Explicit generalized force equations, actual centroids, beam/column free bodies and load redistribution. Original pixels inspected.
3. **DG29 §§4.2.2 and 4.2.6:** printed pp.29–30/PDF37–38 and pp.34–37/PDF42–45, Figs.4-13, 4-14, 4-18. Eccentric work points and frame-distortion actions. Frame moment/pinching can matter even with tensile brace force. The guide's usual static/nonseismic simplification is not authority to erase supplied concurrent member actions.
4. **DG29 Example 6.1a:** printed pp.303–317/PDF311–325. Both gusset edges welded; beam flange/web directly welded to column; web and flange weld checks; column local checks; continuity-plate need; no double-counting the 5k web spread. In particular pp.305–312/PDF313–320 are the receiving/joint precedent. Its remote hinge means its displayed zero joint moment cannot be copied into an arbitrary fully welded node. Sources inspected as images.
5. **DG29 Example 5.1:** printed pp.52–59/PDF60–67, Fig.5-3, for interface force flow, gusset section interaction, gusset weld ductility demand and beam receiving local checks. Printed p.56's plastic interaction is a supplemental model, not an NBR-numbered formula.
6. **ABNT NBR 8800:2024 with the supplied 2025 correction:** §5.2 brace tension; §§5.4.3, 5.5.1 member shear/combined actions; §§5.7.1–5.7.9 local flange/web, panel and stiffeners; §§6.1–6.2 connection/weld rules; §§6.5.3–6.5.6 plate strength. Original printed pp.63–70/PDF85–92 were inspected by the independent reviewer. §6.1.1.3 requires equilibrium, strength, deformation and realistic stiffness; §6.1.2.3 permits conventional joint idealization at the responsible designer's discretion. Neither demands FEA for this ordinary topology.
7. **Sabelli, Saxey, Li and Thornton (2021), Engineering Journal 58(4), pp.223–266**, official AISC source: https://ej.aisc.org/index.php/engj/article/view/1184 . Printed pp.224–225, Figs.1–2 close the finite local beam/column web-shear checks; pp.228–229 retain gravity/frame shear; pp.235–237 permit beam moment carried by the flange connection rather than credited to the gusset. Advanced bypass/haunch optimization is optional. Downloaded original and inspected images retained in component_review.
8. **DG29 Appendix D, printed pp.383–386/PDF391–394:** concurrent member forces and transfer-force bookkeeping. Independent maxima do not form a valid load combination.

DG39/Souza need not be re-searched for this branch: the above sources close the selected route. The earlier internal-fin review contributes only its lesson about admissible force design; no internal-fin or perforated-fin equations were imported.

## 2. Coordinates and force equations

Use global-in-joint x right, y up, origin at the beam/column centerline work point. Column flange face x=ec; beam upper flange y=eb. Positive brace P is tension away from the joint, at angle phi **from horizontal**. DG29's theta is from vertical, so phi = 90 degrees - theta.

- H = P cos(phi), V = P sin(phi).
- alpha = horizontal distance from column face to the actual beam-seam centroid.
- beta = vertical distance from beam flange to the actual column-seam centroid.
- Hc = ec V / (eb + beta).
- Hb = H - Hc.
- Vb = eb Hb / alpha.
- Vc = V - Vb.

These are DG29 A-11–A-14 after conversion of angle convention. No square-root control-point construction is needed in code. Finite positive seam lengths and physically meaningful alpha, beta are geometry checks, not calibrated angle restrictions.

On the gusset the support actions are (-Hb,-Vb) at (ec+alpha,eb) and (-Hc,-Vc) at (ec,eb+beta). In this chosen distribution their brace-induced couples are zero. Show the equilibrium residuals and reciprocal forces.

The brace-path beam-to-column action at the column-face beam centroid J=(ec,0) is **(-Hc,+Vb,0)**, not (Hb,Vb,0). DG29's beam free body includes the remote beam axial action (-H,0). Omitting that force is a serious sign/load-path error.

### Moment witness that prevents false zeroing

For ordinary beta-fixed UFM, retain Hc and Hb above but use Vb=eb V/(eb+beta), Vc=V-Vb. Then the couple ON THE BEAM at its gusset seam is:

Mb = eb Hb - alpha Vb.

The gusset receives -Mb. A centerline work point can coexist with Mb != 0. The numeric fixture gives -0.606092 kNm; it must not be dropped.

### Work-point offsets

Record the actual force line. Its moment about the centerline work point is m0=xP V-yP H and is invariant when P is translated along that line. DG29 §4.2.2 gives the finite eccentricity superposition and a strength-based or stiffness-based moment fraction eta. A 100 mm perpendicular offset at 100 kN produces 10 kNm, not zero. Store the selected eta/derivation and member actions; do not silently presume the inner flange corner is the centerline intersection. The standard centerline first branch requires no eta input.

## 3. Concurrent actions and welded joint

Support one unambiguous input convention per case:

- Incremental convention: N0,V0,M0 are additional, concurrent beam-to-column actions at J excluding the brace-path contribution; add (-Hc,+Vb,0).
- Complete-member convention: supplied signed end/cut actions already include the brace. Recover the interface from the complete joint free body; do not add the brace twice.

Keep the combination ID, signs, reference cut and source of every action. Retain beam gravity/collector forces, column axial load/shear/moment above and below the panel, and any other connected-member contribution needed by equilibrium. Unknown is not zero. Global stability/member certification remains outside the local connection calculation; the local checks still need their actual concurrent inputs.

A useful finite welded-joint distribution for a symmetric I beam is all V to the web, N split in proportion to area, M carried as a flange couple:

Nw=N Aw/Ag; Ftop=N Af/Ag-M/h0; Fbottom=N Af/Ag+M/h0.

Here h0 is the flange-centroid spacing. For the declared beam-to-column actions, moment closure is M=(Fbottom-Ftop)h0/2 because the top force acts at positive y. DG29 supplies the axial/web-shear precedent; adding the flange couple is elementary statically admissible section mechanics, explicitly labeled as such. Check actual weld groups and base metal for those simultaneous signed forces. CJP flange welds or physically drawn fillet segments must have their real effective throat/length and access geometry. Do not infer CJP merely from “beam welded to column.” A declared flange-couple path does not claim the gusset provides joint moment resistance.

## 4. Component closure required in implementation

- **Brace and brace attachment:** per-angle gross/effective tension strength, shear lag, each weld/bolt path, local base metal and actual tear paths. Reuse verified resistance primitives, not one-root force geometry. Count the common gusset once. The first welded branch avoids adding a new perforated-gusset topology at the same time.
- **Gusset body:** actual outline, load-introduction width/length, physical Whitmore width (maximum 30-degree spread), yielding and rupture, physically possible block/tear paths, and both supported-edge N/V/M sections. A supported edge is not a free tear-out edge. Do not transplant one-root free-outstand formulas or require every artificial rectangular cut of a two-edge UFM plate to reproduce the old single-root tensile field.
- **Both seams:** actual effective endpoints, clips and centroids; own electrode/throat. For the selected uniform two-sided fillet seam qn=N/L, qs=V/L; DG29 direct-weld demand is max(qpeak,1.25 qavg), equal to 1.25 hypot(qn,qs) here. NBR nondirectional resistance is 2a(0.60fw/gamma_w2). Check each side's base metal and minimum/maximum/length/access rules. The 1.25 supplement is not an NBR coefficient.
- **Beam/column receiving flanges and webs:** applicable NBR 5.7 local modes using actual normal load footprint, material, end distance and restraint. Normal tension still needs web-yielding checks. Compression-only modes activate by actual demand/geometry. Beam-level stiffeners do not reinforce every point of the upper column seam. Check longitudinal transfer and local cross-sectional web shear separately.
- **Local web shear:** for zero seam moment, integrate the uniform normal traction and check both endpoints and concurrent baseline shear. For nonzero seam M, use a single consistent traction model for weld/gusset/receiver; the 2021 paper's plastic Vmid=M/(L/2)+N/2 cannot be silently combined with an elastic linear-traction interior peak. A conservative elastic primitive can integrate qn(s) and check endpoints plus qn=0 stations instead.
- **Welded beam-column joint:** full signed N/V/M as above, web/flange welds, flange/web base metal and column receiving regions. Respect DG29's explicit warning not to count the same 5k region independently under beam-web and beam-flange loads. Partition or conservatively envelope overlapping receiving regions.
- **Continuity plates:** actual count/sides/levels, root clips, net widths, depth, thickness and material; tension or compression/buckling as applicable; flange/web/opposite-flange weld or fitted-contact transfer. NBR 5.7.9 defines the finite checks, including the required effective web strip/design length for compression. “Stiffener present” is not a passing resistance.
- **Panel zone:** algebraic flange/column-cut free body, NBR 5.7.7 with Aw=dc tw and shear resistance from 5.4.3. For Npl=Ag fy, FRd=VRd at NSd<=0.4 Npl; otherwise FRd=VRd(1.4-NSd/Npl). Stiffeners may affect kv, not erase panel demand or create unprovided doubler area.

Keep independent materials and resistance factors. Do not carry AISC phi/Omega factors or directional weld enhancements into the NBR calculation by accident. Preserve the corrected NBR 6.5.4 logic.

### Compression boundary

First release can be static tensile brace P without qualifying the full compression member. However, retain negative interface forces and concurrent moment. Any actual compressed gusset region, receiving component or continuity plate must receive its applicable strength/stability check; otherwise return an explicit unverified compression mode for that case. There is no hard-coded brace-angle restriction and no assertion that the real detail is impossible.

DG29 Appendix C contains geometry-specific gusset compression methods and compactness distinctions. They are available for a deliberate next qualification; do not apply an unrelated universal K. Full compression also needs 1L/2L member buckling, lengths, restraints and connection-induced effects, so it is a separate finite method increment.

## 5. Independent numerical witnesses

Files: INDEPENDENT_NUMBERS.json and independent_fixture.py; independently checked force_oracle.json and verify_force_oracle.py under force_review. No application calculation function was imported.

Geometry: eb=ec=150 mm; beam weld x=175…750 mm, Lb=575 mm, alpha=312.5 mm; column weld y=175…700 mm, Lc=525 mm, beta=287.5 mm; corner clearance 25 mm. Plate 600x550x10 mm in its local flange-corner coordinates. P=100 kN, phi=45 degrees, selected centerline work point.

Generalized results, kN:
- Hb=46.467017; Vb=22.304168.
- Hc=24.243661; Vc=48.406510.
- Force residual below 4e-12 N; moment residual below 2e-9 Nmm.
- Conventional beta-fixed alternative: Vb=24.243661, Vc=46.467017, Mb=-0.606092 kNm on beam. Same complete assembly equilibrium.

Two 6 mm fillets on each seam, fw=485 MPa, gamma_w2=1.35: seam weld ratios 0.061261 beam and 0.070474 column, including DG29's 1.25. These low values are a numerical witness, not an optimized design.

Concurrent additional actions transmitted beam→column at J: N0=+40 kN, V0=-50 kN, M0=+20 kNm. Total joint actions: (+15.756339,-27.695832,+20). The 20 kNm survives the brace-only zero-couple construction. Full column resultant including the direct gusset seam, referred to the centerline WP, is (+40,+20.710678,+12.5) kN/kNm.

Prescribed numerical receiver section (not a claimed commercial profile): d=300,bf=200,tf=16,tw=10,Ag=9500,k=30 mm; fy=345 MPa. With flange area3200 mm² and h0=284 mm: Ftop=-65.115137 kN, Fbottom=+75.729934 kN, Nweb=+5.141542 kN. A compression flange is present despite the tensile brace. With two6mm web fillets of effective length240mm, resultant demand28.169035kN and weld ratio0.064170. CJP flange base-yield checks are illustrative; actual weld execution and all receiving/stiffener details still require verification.

A separate panel primitive test explicitly prescribes 100kN algebraic panel shear and 600kN column compression; it obtains FRd=564.545455kN and ratio0.177134. It is labeled separate because those panel cut actions cannot be invented from P alone.

A traceable brace-side component test uses Gerdau R30 L76.2x7.94, Ag1148mm²/ec22.1mm per angle, symmetric2L T, P/2=50kN, each longitudinal weld180mm, fy250/fu400MPa: Ct0.877222, yielding ratio0.191638, effective rupture0.167568, heel5mm-weld ratio0.258777. The catalogue's unpublished toe/root geometry remains unknown; no physical tear-path/access pass is invented. The full Whitmore width284.046097mm is a geometric component witness and must be clipped to actual boundaries when necessary.

These witnesses intentionally separate known arithmetic from as-yet-unspecified fabrication details. They do not combine unrelated component tests into a fictitious whole-node pass.

## 6. What is an input, and what would actually block a case

No new general reference or user question is required to begin the complete-fixture calculation. That finite fixture must close before production strength implementation. The application must request or derive from a drawn detail:

- actual brace line/work point and angle convention;
- actual gusset outline, brace weld/bolt coordinates, plate thickness and seam endpoints;
- beam/column profiles and separate steel, end distances, centered web planes and applicable restraint;
- signed concurrent beam/column actions, reference cuts, and whether the brace is already included;
- every weld's type/size/effective length/electrode and access clip;
- continuity-plate count, geometry, steel, clipping, weld/contact extent and panel bounds.

These cannot be inferred from “welded to both” or the existence of stiffeners. A missing member action/essential weld/stiffener dimension produces a specific incomplete check, not zero demand and not a broad request for FEA. The ordinary centerline geometry is a labeled diagram default; custom eccentricity requires its declared distribution. Nonplanar eccentricity, seismic cyclic ductility, fatigue, arbitrary multi-brace node optimization and global member/frame verification stay outside this first route.

## 7. Implementation and release estimate

A medium-to-large new connection family, not another one-root flag. Plan **two implementation slices plus independent acceptance**:

0. Complete real-profile fixture: actual brace-to-gusset tear/access geometry, plate paths, both receiver regions, concurrent joint and stiffener/panel free bodies. No invented receiver section or unrelated panel demand may stand in for this gate.
1. UFM geometry/force lineage, common gusset/two seams and receiving local/shear checks, welded1L/T2L adapters, editable angle/materials, proportional force-path diagram.
2. Concurrent welded beam-column joint, continuity plates/panel, complete signed cases, native serialization and clear compact/detailed reports.
3. Independent full-joint oracle and adversarial tests: angle changes; classic/generalized differences; custom WP moment; load-case/sign/double-counting; material isolation; clips/end effects; support-edge tear-path exclusions; overlapping column load zones; compressed flange/stiffener; panel axial reduction; zero loads; branch unsupported reasons; exports/native round trips.

Planning estimate: roughly **1–2 focused engineering days** for implementation plus review, depending on reuse and report/drawing work. This is an order-of-magnitude estimate, not a delivery commitment. Further literature searching is not on the critical path.

Stop condition of this source pass is reached: source chain, finite chosen model, explicit required inputs, component closure, independently reproduced force fixture and implementation gate are recorded. Production remains unchanged.
