"""Compare independently computed numerical outputs after both calculations exist."""
import json,math,hashlib
from pathlib import Path
R=Path(__file__).parent
prod=json.loads((R.parent/'ORACLE.json').read_text())
gus=json.loads((R/'INDEPENDENT_GUSSET_REVIEW.json').read_text())
joint=json.loads((R/'INDEPENDENT_JOINT_REVIEW.json').read_text())
ecc=json.loads((R/'INDEPENDENT_CONTINUITY_ECCENTRIC_REVIEW.json').read_text())
rows=[]
def equal(name,a,b):
 assert math.isclose(a,b,rel_tol=1e-11,abs_tol=1e-8),(name,a,b)
 rows.append(dict(id=name,producer=a,reviewer=b,pass_=True))
for k,v in joint['forces'].items():equal('forces.'+k,prod['force_model'][k],v)
for label,other in [('beam','beam'),('column_upper','upper_column'),('column_lower','lower_column')]:
 for k in ['Fx','Fy','M']:equal('complete_cut.'+label+'.'+k,prod['complete_cuts'][label][k],joint['complete_cuts'][other][k])
for p,k in [('Ftop','Ftop'),('Fbottom','Fbottom'),('Nweb','Nw')]:equal('joint.'+p,prod['joint_distribution'][p],joint['flange_distribution'][k])
for p,k in [('Qtop','Q_top_N'),('Qbottom','Q_bottom_N'),('VRd','compact_web_V_R_N')]:equal('panel.'+p,prod['panel'][p],joint['panel'][k])
checks={x['id']:x for x in prod['checks']}
equal('gusset_actual_body_chord_gross',checks['gusset_actual_body_chord_gross']['utilization'],gus['actual_body_chord']['yield_ratio'])
equal('gusset_actual_body_chord_rupture',checks['gusset_actual_body_chord_rupture']['utilization'],gus['actual_body_chord']['rupture_ratio'])
equal('continuity_bottom_net_rupture',checks['continuity_bottom_net_rupture']['utilization'],joint['continuity']['actually_welded_net_tension_ratio'])
for case in ecc['cases']:
 n=case['level'];equal(n+'_eccentric_weld',checks['continuity_'+n+'_web_weld']['utilization'],case['weld_ratio'])
 equal(n+'_plate_NVM',checks['continuity_'+n+'_plate_equilibrated_NVM']['utilization'],case['VM_ratio'])
 equal(n+'_receiver_combined',checks['continuity_'+n+'_column_web_combined_receiver']['utilization'],case['receiver_common_web']['local_VM_ratio'])
equal('same_case_overlap_union_demand',checks['column_top_flange_gusset_overlap_union']['demand'],abs(joint['flange_distribution']['Ftop'])+joint['forces']['Hc'])
equal('same_case_overlap_union_R',checks['column_top_flange_gusset_overlap_union']['resistance'],(748.5-145.3+5*15.4)*345*9.9)
equal('same_case_overlap_union_ratio',checks['column_top_flange_gusset_overlap_union']['utilization'],0.03579798620509543)
assert prod['all_listed_checks_pass'] and all(c['pass_'] for c in prod['checks'])
assert len(checks)==len(prod['checks'])
for k in ['joint_web_column_flange_contact_yield','joint_web_column_flange_contact_normal_rupture','joint_web_column_flange_contact_shear_rupture','continuity_top_column_web_receiver_shear','continuity_bottom_column_web_receiver_shear']:
 assert k in checks and checks[k]['pass_']
assert 'no Ct1 inferred' in checks['gusset_whitmore_net_rupture_peak']['source']
assert 'inscribed' in checks['beam_gusset_supported_section_interaction']['source'].lower()
out=dict(status='PASS_BOUNDED_FULL_JOINT_GO',comparisons=rows,producer_check_count=len(prod['checks']),all_producer_checks_pass=True,
 hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [R.parent/'FIXTURE_INPUT.json',R.parent/'ORACLE.json',R.parent/'build_oracle.py',R.parent/'FULL_JOINT_CONTRACT.md',R.parent/'VALIDATION.json',R.parent/'source_evidence'/'SOURCE_REGISTER.md']},
 additional_independent_check='Conservative common-web simultaneous baseline/local stress bound passes at maximum0.5665793424032987. See eccentric continuity review.',
 scope='One fully dimensioned static tensile numerical fixture and selected conventional strength method; not production, fabrication, WPS or global member certification.')
(R/'CROSS_REVIEW_VALIDATION.json').write_text(json.dumps(out,indent=2)+'\n')
print(out['status'],len(rows),'independent numerical comparisons;',len(prod['checks']),'producer checks.')
