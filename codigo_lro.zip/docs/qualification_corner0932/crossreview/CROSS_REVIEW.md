# Independent full-joint corner-gusset cross-review

11 October 2026. One static, tensile, strong-axis, symmetric Gerdau 2L-T fixture. No production files edited or production functions imported.

## Decision

**Finite bounded-method GO.** The receiving-base-metal, per-plate eccentricity and labeling revisions below have been saved and independently verified. The independent full-cut, gusset, panel and continuity calculations pass. This is qualification of a calculation route and regression fixture, not a fabrication/WPS approval or whole-frame/member stability certificate.

No new reference search, finite-element analysis, exact matching published joint, or exact-elastic force split is necessary to close this fixture. The complete external member cuts are genuine, concurrent and in equilibrium. The declared all-moment-to-beam-flanges route does not credit gusset haunch action.

## Independently reproduced results

The companion scripts independently transcribe the fixture inputs. They import neither the producer's oracle nor its calculation functions.

- Gusset actions, kN: Hb 47.712907411; Vb 24.007923253; Hc 22.997770708; Vc 46.702754866.
- Beam→column at J=(154,0), kN/kNm: (+17.002229292, −25.992076747, +20).
- Complete beam boundary at (1000,0): (−30.710678119, −50, +62.3).
- Complete upper column boundary at (0,1000): (+10, −500, +10).
- Complete lower column boundary at (0,−1000): (−50, +479.289321881, +37.7).
- Gusset, beam, column and whole assembly each close. Maximum residual is below 2e−9 Nmm or 2e−11 N in the independent calculation.
- Rectangular component allocation A0=6617.36 mm² intentionally does not claim the catalog's additional rolled-root area. Ftop=−60.168937777 kN; Fbottom=+71.496631677 kN; Nweb=+5.674535393 kN. Top compression is retained. Moment closure is (Fbottom−Ftop)h0/2=+20 kNm.

## Gusset: real boundaries, local spread and fracture

The brace's two planar load lines at v=−22.1 and +54.1 mm carry fractions 0.7099737533 and 0.2900262467. Their combined line is exactly v=0. Through-thickness symmetry cancels the out-of-plane couple; it does not license equal heel/toe forces or a second gusset area.

The full Whitmore width is 330.234118443 mm at u=650 mm. Both endpoints lie inside the actual clipped polygon. Its midpoint is v=16 mm, so the retained eccentric moment is +1.6 kNm. The local elastic tension extremes are 17.898845813 and 32.570399295 MPa; gross-yield utilization is 0.143309757. This check is deliberately more restrictive than uniform P/A alone.

The actual whole-body chord at u=650 mm is 838.998013089 mm wide, with midpoint v=3.181980515 mm. It transfers P=100 kN and M=0.318198052 kNm. Peak normal stress is 10.158502167 MPa; gross-yield utilization 0.044697410; unperforated body-section rupture utilization 0.034284945. On 650≤u≤870 mm, the chord width is 2(1069.499006545−u), its midpoint stays fixed, and captured load is P(870−u)/220. The demand/resistance ratios decrease throughout this interval, so the endpoint is the exact maximum of this declared section family.

This whole-body section is not a physical flat strip directly connected by longitudinal welds along its two free edges. NBR 5.2.5(d)'s width is the actual distance between those edge welds; it cannot be imposed on the virtual Whitmore boundaries, which have no welds. NBR 5.2.4.2 establishes An=Ag without holes, but does not itself establish Ct=1. The producer's former statement “no holes Ct1” should therefore be removed. The actual body-section fracture check, explicit U/L blocks, and local weld substrates establish the ordinary unperforated fracture paths. A deliberately adapted virtual-strip Ct=0.555506233 gives rupture utilization 0.197882744 and is available as a sensitivity only; it is not represented as a directly prescribed NBR gusset equation.

Eight explicit U/L paths were independently clipped against the polygon. Their ends lie on real free top/right boundaries. Both full beam and column contact edges were treated as supported, including contact lengths outside the effective weld endpoints. Every supported-edge point has u≤645.235 mm; the loaded tail starts at u=650 mm. Thus none of these detached blocks secretly remains attached to a positive support length.

Maximum named-path utilization is 0.086765586 for the between-roots U path. A separate conservative ordinary-path lower bound, using only one captured longitudinal shear area tL and no tension resistance, gives 0.340909091. This is a bound for the stated longitudinal/transverse path family, not an assertion that every conceivable curved fracture mechanism was enumerated. Opposite-face forces are summed; the common plate is counted once. Cts=0.5 is used conservatively.

The two supported plate edges have their own N/V checks. The literal DG29 zero-moment interaction N²+V⁴ is 0.0002640681 at the beam and 0.0002423166 at the column. The producer's N²+V² screen is conservative within the accepted individual-capacity domain, but must be labeled an inscribed conservative interaction, not quoted as the DG29 equation. These connected edges are not free-edge tear paths.

## Panel and column shear

Let X+ be the upper column boundary horizontal action. A horizontal panel cut gives:

Q(y)=−[X+ + Hc + Ftop + Nweb_above(y)].

The beam-web horizontal axial force is included over its actual −110…110 mm transfer range. Panel endpoints are +27.171167069 and +21.496631677 kN. Their difference is Nweb, so replacing this with M/h0 alone would lose a real action. With dc tw=308×9.9 mm² and fy345 MPa, compact-web VRd=573.804 kN. Maximum concurrent column compression is conservatively 500 kN, below 0.4Npl; no axial reduction applies. Panel utilization is 0.047352697.

The local cut sequence retains the upper gusset normal-traction shear rise, both signed flange jumps, the web axial distribution, and the lower column shear. The selected actual member web slenderness satisfies the conservative unstiffened kv=5 compact-web branch; the continuity plates are not used to invent doubler area.

## Continuity plates and welds

Two actual 12 mm plates at each flange-centroid level extend across the column clear depth. Their root clips reduce each flange face width from 140 to 110 mm. The actual flange weld length is 100 mm, and each plate has two 207.2 mm web fillets.

The chosen path is loaded column flange → continuity pair → column web. All of the corresponding flange force is assigned to this path; no parallel receiving-web capacity is added. Thus the loaded-flange weld and web weld each transfer the same force. The opposite-flange weld is physically provided but has zero required force in this selected static path. It must not also be counted as transferring the full force simultaneously.

Independent strengths and ratios:

- Top pair clipped compression area 2640 mm²; yielding resistance 600 kN; utilization 0.100281563.
- Supplementary NBR 5.7.9.4 column model: web strip25tw=247.5 mm; A=5810.25 mm²; I about the axis in the web plane=24,382,820.817 mm⁴; Le=0.75h=207.9 mm; χ=0.999454168. Using fy250 throughout conservatively understates the stronger column web. Resistance1319.790586 kN; utilization0.045589761.
- Width/thickness b/t=11.6667 is below 0.56√(E/fy)=15.8392. Width and thickness minimum rules also pass. The minimum-width reference should include the actual column flange width305 mm.
- Bottom gross tension utilization0.093626541. A conservative effective tension area based on the actual welded100 mm per plate is2400 mm², giving rupture resistance711.111111 kN and utilization0.100542138. This avoids silently crediting the unwelded5 mm at each end of the110 mm net face.
- Loaded-flange weld pair resistance365.809908 kN; maximum utilization0.195447499.
- Web weld pair resistance757.958130 kN. The centroid-only axial utilization0.094327944 is superseded by the per-plate eccentric traction check below, whose governing utilization is0.250607894.

The full stiffener-column check is a consciously conservative supplement. NBR5.7.9.4 is expressly tied to the 5.7.9.3 instability cases; it is not asserted that every compressed stiffener requires that exact composite section. Here actual top compression is checked rather than waived because the brace is tensile.

## Closure revisions verified in the producer oracle

1. Include explicit column-flange receiving base metal at the beam-web double5 mm seam under simultaneous Nweb and Vjoint. A width2s=10 mm over220 mm is the declared contact screen; use the column's own fy/fu.
2. Include explicit column-web receiving base metal at continuity seams. Coincident opposite faces must not each acquire an independent full web thickness. A conservative single common-web cap or a documented two-through-thickness-plane model is acceptable. Preserve the receiver's material separately from the continuity plate's.
3. Use actual welded100 mm widths for the conservative bottom effective tension section, or document the source-supported larger width.
4. Correct DG29 interaction attribution and the “no holes Ct1” description as above; include the actual whole-body section calculation.

All four revisions are present in the saved oracle and pass. The final per-plate eccentricity issue was also closed as follows; no local-component method gap remains for this stated fixture.

## Final per-plate eccentric force-path closure

Pair-level cancellation alone is insufficient to justify zero local moment. Each continuity plate receives Fp=F/2 at z=±89.95 mm and transfers axial force to its web weld at z=±4.95 mm, leaving an85 mm eccentricity. The accepted statically admissible path retains the local couple Fp×85 rather than hiding it in overall symmetry.

Use uniform axial web traction qx=−Fp/L and zero-resultant transverse traction qz(x)=(Fp×85)x/(L³/12), with L207.2 mm. Both welds on each plate share the local vector equally. Mirroring the opposite plate cancels the net out-of-plane force and couple, while retaining opposite face reactions and the actual through-thickness normal stress in the common column web.

For a=L/2 and dimensionless coordinate ξ=x/a, the right-part per-plate free body gives:

- N/Fp=(1+ξ)/2
- Vz/Fp=(1.5×85/L)(1−ξ²)
- My/Fp=7.5+28.75ξ−21.25ξ³ mm

These resultants all vanish at ξ=−1; at ξ=+1 they are Fp,0,15Fp, matching the plate's gross-section centroid. In the final30 mm root-clipped interval, width decreases140→110 mm and the section centroid shifts74.95→89.95 mm, reducing the eccentricity15→0. Thus the full plate free body and every stated section family close.

Exact polynomial stationary-point calculations, performed independently using polynomial roots, give:

- Bottom plate normal extrema−2.085976346 and+37.043938263 MPa. The small compressed edge is retained; “bottom flange in tension” is not used to waive it.
- Bottom conservative section VM maximum42.183884202 MPa, utilization0.185609090. Top maximum35.500406722 MPa, utilization0.156201790.
- Eccentric weld multiplier √[1+(6×85/207.2)²]. Bottom web-weld utilization0.250607894; top0.210902394.
- Common-web peak σz35.388733004 MPa and conservative τ=F/(Ltw)=34.854642797 MPa use the single actual9.9 mm web. Combined local material utilization0.223117812.
- A separate conservative stress triangle adds the existing column N/M envelope, local σz, and √3 times the sum of local and panel shear. Maximum177.699884663 MPa, utilization0.566579342. It provides a same-case bound without relying on cancellation of concurrent pre-existing stress.

Plate b/t remains non-slender and the full-pair compression supplement remains checked. The independent calculation is `independent_continuity_eccentric_review.py`; full numerical extrema and scope are in `INDEPENDENT_CONTINUITY_ECCENTRIC_REVIEW.json`.

## Final verification record

`validate_cross_review.py` compared the independently calculated values with the saved producer oracle:33 numerical comparisons passed; all86 listed producer checks passed. It verifies the actual reciprocal receiver checks,100 mm effective welded continuity area, corrected source labels, body section and eccentric per-plate path. `CROSS_REVIEW_VALIDATION.json` records file hashes so that this signoff is tied to the evaluated input/code/output snapshot. Subsequent edits should rerun the validator.

## Primary-source audit

- Supplied AISC DG29, Appendix A, printed347–350: generalized force system and member free bodies; Example5.1 printed51 and54–57: Whitmore spread, supported-edge resistance and interaction; Example6.1a printed305–312: directly welded beam, local receiving checks and no duplicated5k spread. Relevant supplied text and original rendered pixels were checked.
- Supplied ABNT NBR8800:2024, corrected supplied edition: printed40–42 (§5.2.4–5.2.5); printed64–68 (§5.7.2–5.7.9); printed80–81 (§6.2.6); printed94–96 (§6.5). Original pixels were inspected for the critical Ct, panel and stiffener provisions. OCR was used only as a locator.
- Sabelli, Saxey, Li and Thornton, 2021, “Design for Local Web Shear at Brace Connections,” Engineering Journal58(4),223–266: https://ej.aisc.org/index.php/engj/article/view/1184 . Verified official publication page; supplied paper and existing page audit establish the finite endpoint shear model.

## Deliberate scope boundaries

This GO applies to the one declared static tensile case and to implementing its explicitly guarded calculation route. Arbitrary offset work points, force cases producing compressed gusset regions, unequal/nonplanar brace arrangements, brace-compression member buckling, seismic/fatigue qualification, WPS approval, material certification and whole-frame/member stability remain outside this fixture. Their exclusion does not leave the evaluated local load path incomplete, nor does this one numerical pass approve every changed angle or load case.

## Final contract review, 23:11 UTC

The producer's FULL_JOINT_CONTRACT.md and source register were read against the85-check snapshot. The component route, limits, complete-cut convention and numerical statements match the independently checked fixture. The validator was rerun successfully and refreshed the evaluated hashes.

One precise contact-geometry clarification was returned to the producer: the continuity plate occupies y145.9…157.9 mm, but its double6 mm web fillets occupy contact bands y139.9…145.9 and157.9…163.9 mm. The upper band therefore overlaps the gusset's credited local-yield spread starting160 mm by3.9 mm. These footprints must not be described as disjoint. The selected full-force continuity path already avoids adding parallel bare-web capacity; an explicit one-capacity union absolute-demand check makes that conservative shared-region closure readily auditable.

## Final frozen-snapshot signoff, 23:13 UTC

**GO remains verified.** The final86-row producer snapshot passes all listed checks;33 numerical comparisons with independent calculations pass. The authoritative fixture input now declares the complete beam cut directly, and its joint action is recovered by free-body equilibrium; the incremental baseline is only a separately checked witness. This preserves the intended single input convention.

The actual contact overlap is correctly stated in the contract and explicitly checked: |Ftop|+Hc=83.166708485 kN; one connected union span603.2 mm plus a single5k contribution gives2323.2231 kN, utilization0.0357979862. No false disjointness or favorable sign cancellation is credited. The source-register relative paths are corrected.

The producer's finite angle/adversarial validation was read:40/45/50-degree geometries are contained,30/60/80-degree geometries are not contained for this same fixed outline, and80 degrees also activates negative beam normal action. None is mislabeled as an independently strength-qualified changed case.

CROSS_REVIEW_VALIDATION.json now records fresh hashes for the final input, code, output, full contract, producer validation and source register. No unresolved material contract misstatement or local method gap remains. No production files were edited.
