"""Independent exact-polynomial per-continuity-plate equilibrium/stress review.
No parent calculation or output imports. Polynomial roots identify all stationary points.
"""
import json,math
from pathlib import Path
from numpy.polynomial import Polynomial as Poly
L=207.2;e=85.;a=L/2;th=12.;b=140.;A=th*b;Z=th*b*b/6;Fbottom=71496.63167650238;Ftop=-60168.9377770855
rows=[]
for name,F in [('top',Ftop),('bottom',Fbottom)]:
 p=F/2;N=p*Poly([.5,.5]);V=p*(1.5*e/L)*Poly([1,0,-1]);M=p*Poly([7.5,28.75,0,-21.25]);shear=1.5*V/A
 stresses=[N/A+M/Z,N/A-M/Z]
 normals=[];vms=[]
 for edge,sigma in enumerate(stresses):
  stations=[-1.,1.]+[float(t.real) for t in sigma.deriv().roots() if abs(t.imag)<1e-10 and -1<t.real<1]
  normals += [dict(edge=edge,t=t,x_mm=t*a,sigma_MPa=float(sigma(t))) for t in stations]
  vm2=sigma*sigma+3*shear*shear
  stations=[-1.,1.]+[float(t.real) for t in vm2.deriv().roots() if abs(t.imag)<1e-10 and -1<t.real<1]
  vms += [dict(edge=edge,t=t,x_mm=t*a,VM_MPa=math.sqrt(max(0,float(vm2(t))))) for t in stations]
 weldfactor=math.sqrt(1+(6*e/L)**2);qeach=abs(F)/(4*L)*weldfactor;rw=6/math.sqrt(2)*.6*485/1.35
 # Common web: one total tw for Fx, two opposed face-normal reactions for qz.
 qz_peak=6*abs(p)*e/L**2;sz=qz_peak/(2*6);tau=abs(F)/(L*9.9)
 receiver_vm=math.sqrt(sz*sz+3*tau*tau)
 # Additional deliberately conservative triangle bound combines pre-existing
 # 500kN/Ag +37.7kNm/W column stress and panel shear with local introduction.
 baseline_normal=500000/12360+37.7e6/1447000
 panel_shear=27171.167069011943/(308*9.9)
 combined_bound=baseline_normal+sz+math.sqrt(3)*(tau+panel_shear)
 row=dict(level=name,Fpair_N=F,Fplate_N=p,N_poly=tuple(N.coef),V_poly=tuple(V.coef),M_poly=tuple(M.coef),
  equilibrium_at_start=[float(N(-1)),float(V(-1)),float(M(-1))],equilibrium_at_end=[float(N(1)),float(V(1)),float(M(1))],
  normal_extrema=normals,min_normal_MPa=min(n['sigma_MPa'] for n in normals),max_normal_MPa=max(n['sigma_MPa'] for n in normals),
  VM_candidates=vms,max_VM_MPa=max(x['VM_MPa'] for x in vms),VM_ratio=max(x['VM_MPa'] for x in vms)/(250/1.1),
  clip_region_peak_abs_sigma_MPa=max(abs(p/(th*b)+6*p*15/(th*b*b)),abs(p/(th*b)-6*p*15/(th*b*b)),abs(p/(th*110))),
  web_weld_eccentric_factor=weldfactor,q_each_weld_peak_N_per_mm=qeach,weld_ratio=qeach/rw,
  receiver_common_web=dict(qz_one_face_peak_N_per_mm=qz_peak,sigma_z_peak_MPa=sz,tau_x_conservative_common_web_MPa=tau,local_VM_MPa=receiver_vm,local_VM_ratio=receiver_vm/(345/1.1),concurrent_stress_triangle_bound_MPa=combined_bound,concurrent_stress_bound_ratio=combined_bound/(345/1.1)))
 assert max(abs(t) for t in row['equilibrium_at_start'])<1e-8
 assert row['VM_ratio']<1 and row['weld_ratio']<1 and row['receiver_common_web']['concurrent_stress_bound_ratio']<1
 rows.append(row)
result=dict(status='PASS_explicit_per_plate_equilibrium_and_strength',model='Uniform axial web traction plus zero-resultant linearly varying transverse web traction. Mirrored plates cancel overall z resultant/couple, but each plate and each weld retains its local eccentricity.',
 dimensions=dict(L=L,e=e,plate_width=b,thickness=th,loaded_flange_force_z=89.95,web_line_z=4.95,plate_centroid_z=74.95),
 plate_local_stability=dict(b_over_t=b/th,non_slender_limit=.56*math.sqrt(200000/250),passes=b/th<=.56*math.sqrt(200000/250),note='Local plate outstand is non-slender; the separate full-pair NBR5.7.9.4 axial supplement remains in the joint review. Tiny bending-induced compressed edges are not waived.'),
 cases=rows,
 notes=['Dimensionless polynomial coordinate t=x/(L/2) on −1..+1; actual plate thickness is named th in code.',
 'On x103.6..108.6, full plate width and right-end N/M persist. On clip108.6..138.6, width reduces140→110, centroid74.95→89.95, eccentricity15→0. Stress maximum is at the full-width end of the clip region.',
 'Stress VM uses section-edge normal and simultaneous maximum transverse shear as a conservative section envelope; it is not claimed to be an exact pointwise elasticity solution.',
 'The receiver combined triangle bound is an intentionally conservative supplement; it adds maxima of existing column stress, local through-thickness normal, local common-web shear and panel shear without favorable cancellation.'])
Path(__file__).with_name('INDEPENDENT_CONTINUITY_ECCENTRIC_REVIEW.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps([dict(level=r['level'],min_sigma=r['min_normal_MPa'],max_sigma=r['max_normal_MPa'],max_VM=r['max_VM_MPa'],VMratio=r['VM_ratio'],weldratio=r['weld_ratio'],receiver=r['receiver_common_web']) for r in rows],indent=2))
