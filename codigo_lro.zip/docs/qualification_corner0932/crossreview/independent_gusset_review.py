"""Independent one-geometry oracle. Standard library only; no parent oracle imports.
Units N, mm, MPa. Bounded ordinary U/L block paths; supports are NOT free edges.
"""
import math,json
from pathlib import Path
rt=math.sqrt(2); P=100000.; t=12.; fy=250.; fu=400.; g1=1.1;g2=1.35
poly=[(184.,158.5),(754.,158.5),(754.,758.5),(154.,758.5),(154.,188.5)]
# All coordinates and force-line positions independently transcribed from task message.
beam_seam=[(194.,158.5),(744.,158.5)]
column_seam=[(154.,198.5),(154.,748.5)]
u0,u1=650.,870.; heel,toe=-22.1,54.1;sw=5.;L=u1-u0
fh,ft=54.1/76.2,22.1/76.2

def uv(p):return ((p[0]+p[1])/rt,(p[1]-p[0])/rt)
def xy(p):return ((p[0]-p[1])/rt,(p[0]+p[1])/rt)
uvpoly=[uv(p) for p in poly]

def clip(poly,n,c):
    out=[]
    for p,q in zip(poly,poly[1:]+poly[:1]):
        dp=n[0]*p[0]+n[1]*p[1]-c;dq=n[0]*q[0]+n[1]*q[1]-c
        pin=dp>=-1e-9;qin=dq>=-1e-9
        if pin:out.append(p)
        if pin!=qin:
            frac=dp/(dp-dq);out.append(tuple(p[i]+frac*(q[i]-p[i]) for i in range(2)))
    return out

def segment_intersection_parameter(p,q,n,c):
    vp=n[0]*p[0]+n[1]*p[1]-c;vq=n[0]*q[0]+n[1]*q[1]-c
    if vp>=-1e-9 and vq>=-1e-9:return 0.,1.
    if vp< -1e-9 and vq< -1e-9:return None
    f=vp/(vp-vq)
    return (0.,f) if vp>=-1e-9 else (f,1.)

def support_overlap(planes):
    hits=[]
    # Test whole lower and left flange-contact edges, not just effective seams.
    for name,edge in [('beam',poly[:2]),('column',[poly[3],poly[4]])]:
        a,b=map(uv,edge);lower,upper=0.,1.
        for n,c in planes:
            ran=segment_intersection_parameter(a,b,n,c)
            if ran is None:upper=-1.;break
            lower=max(lower,ran[0]);upper=min(upper,ran[1])
        length=max(0.,upper-lower)*math.dist(a,b)
        if length>1e-7:hits.append({'support':name,'length_mm':length})
    return hits

def chord_u(a):
    vs=[]
    for p,q in zip(uvpoly,uvpoly[1:]+uvpoly[:1]):
        if min(p[0],q[0])-1e-9<=a<=max(p[0],q[0])+1e-9:
            if abs(q[0]-p[0])<1e-9:vs.extend([p[1],q[1]])
            else:vs.append(p[1]+(a-p[0])/(q[0]-p[0])*(q[1]-p[1]))
    return min(vs),max(vs)

def forward_exit(v):
    us=[]
    for p,q in zip(uvpoly,uvpoly[1:]+uvpoly[:1]):
        if min(p[1],q[1])-1e-9<=v<=max(p[1],q[1])+1e-9:
            if abs(q[1]-p[1])<1e-9:us.extend([p[0],q[0]])
            else:us.append(p[0]+(v-p[1])/(q[1]-p[1])*(q[0]-p[0]))
    return max(us)

def block(id,a,limits,frac,kind):
    planes=[((1.,0.),a)]
    if kind=='U':
        va,vb=limits;planes += [((0.,1.),va),((0.,-1.),-vb)]
        shear=forward_exit(va)+forward_exit(vb)-2*a;tension=vb-va
        path=[(forward_exit(va),va),(a,va),(a,vb),(forward_exit(vb),vb)]
    else:
        side,vb=limits;vlo,vhi=chord_u(a)
        bound=vlo if side=='negative' else vhi
        planes.append(((0.,-1.),-vb) if side=='negative' else ((0.,1.),vb))
        shear=forward_exit(vb)-a;tension=abs(bound-vb)
        path=[(forward_exit(vb),vb),(a,vb),(a,bound)]
    polygon=uvpoly[:]
    for n,c in planes:polygon=clip(polygon,n,c)
    hits=support_overlap(planes)
    demand=P*frac*max(0.,min(1.,(u1-a)/L))
    av=t*shear;at=t*tension
    r_y=(.6*fy*av+.5*fu*at)/g2;r_u=(.6*fu*av+.5*fu*at)/g2
    return dict(id=id,u_cut_mm=a,kind=kind,admissible=not hits,support_overlap=hits,
        block_xy_mm=[xy(p) for p in polygon],path_xy_mm=[xy(p) for p in path],
        Agv_mm2=av,Anv_mm2=av,Ant_mm2=at,Cts=.5,demand_N=demand,
        R_yield_branch_N=r_y,R_rupture_branch_N=r_u,R_N=min(r_y,r_u),
        utilization=demand/min(r_y,r_u))

stations=sorted({u0,u1}|{u for u,v in uvpoly if u0<u<u1})
paths=[]
for a in stations:
    if a>=u1:continue
    for id,lims,frac in [('G-U-both-footprints',(heel-sw,toe+sw),1.),('G-U-heel',(heel-sw,heel),fh),('G-U-toe',(toe,toe+sw),ft),('G-U-between-roots',(heel,toe),1.)]:
        paths.append(block(id,a,lims,frac,'U'))
    for id,lims,frac in [('G-L-negative-heel',('negative',heel),fh),('G-L-negative-both',('negative',toe+sw),1.),('G-L-positive-toe',('positive',toe),ft),('G-L-positive-both',('positive',heel-sw),1.)]:
        paths.append(block(id,a,lims,frac,'L'))
W=toe-heel+2*L*math.tan(math.pi/6);vmid=(heel+toe)/2
A=W*t;Z=t*W**2/6;M=P*vmid
normal=[P/A-M/Z,P/A+M/Z]
ct=3*L**2/(3*L**2+W**2)*(1-t/(2*L))
wlo,whi=heel-L*math.tan(math.pi/6),toe+L*math.tan(math.pi/6)
vl,vh=chord_u(u0)
H=V=P/rt;ec=154.;eb=158.5;alpha=beta=315.
Hc=ec*V/(eb+beta);Hb=H-Hc;Vb=eb*Hb/alpha;Vc=V-Vb
seams=[]
for name,normal_force,parallel_force,length in [('beam',Vb,Hb,550.),('column',Hc,Vc,550.)]:
    area=t*length;rn=area*fy/g1;rv=.6*area*fy/g1
    s=normal_force/area;tau=parallel_force/area
    seams.append(dict(name=name,N_N=normal_force,V_N=parallel_force,M_Nmm=0.,area_mm2=area,
        N_yield_R_N=rn,V_yield_R_N=rv,N_rupture_R_N=area*fu/g2,V_rupture_R_N=.6*area*fu/g2,
        DG29_N2_V4_interaction=(normal_force/rn)**2+(parallel_force/rv)**4,
        conservative_plane_stress_VM_MPa=math.sqrt(s*s+3*tau*tau),
        VM_ratio=math.sqrt(s*s+3*tau*tau)/(fy/g1)))
bodyW=vh-vl;bodymid=(vl+vh)/2;bodysig=P/(bodyW*t)+6*P*abs(bodymid)/(t*bodyW**2)
result=dict(actual_body_chord=dict(u_mm=u0,width_mm=bodyW,midpoint_v_mm=bodymid,force_N=P,moment_Nmm=P*bodymid,peak_normal_MPa=bodysig,yield_ratio=bodysig/(fy/g1),rupture_ratio=bodysig/(fu/g2),explanation='Actual whole-plate section. Over650..870, width decreases linearly and captured load=P*(870-u)/220; resulting elastic peak-demand ratios strictly decrease. This is not a virtual flat plate directly loaded through two welded free edges.'),status='geometry_and_bounded_gusset_checks_pass',scope='One numerical fixture, not fabrication certification or arbitrary-gusset solver',
    source='Task geometry + NBR 8800:2024 6.5.3/6.5.5/6.5.6; DG29 pp51,54–57',
    polygon_xy_mm=poly,polygon_uv_mm=uvpoly,brace_line_v_mm=0.,
    weld_lines=[dict(v_mm=heel,force_fraction=fh,xy_start=xy((u0,heel)),xy_end=xy((u1,heel))),dict(v_mm=toe,force_fraction=ft,xy_start=xy((u0,toe)),xy_end=xy((u1,toe)))],
    load_line_residual_Nmm=P*(fh*heel+ft*toe),
    stations_u_mm=stations,maximum_supported_edge_u_mm=max(uv(p)[0] for p in [poly[0],poly[1],poly[3],poly[4]]),
    whitmore=dict(width_mm=W,ends_v_mm=[wlo,whi],ends_xy_mm=[xy((u0,wlo)),xy((u0,whi))],
        whole_plate_chord_v_mm=[vl,vh],fits_inside_polygon=vl<=wlo<=whi<=vh,
        eccentricity_mm=vmid,M_Nmm=M,A_mm2=A,Z_mm3=Z,elastic_normal_extremes_MPa=normal,
        gross_yield_R_N=A*fy/g1,gross_yield_ratio=P/(A*fy/g1),elastic_peak_yield_ratio=max(normal)/(fy/g1),
        gross_rupture_R_N=A*fu/g2,conservative_adapted_flat_strip_Ct=ct,
        adapted_strip_peak_rupture_ratio=max(normal)/(ct*fu/g2),
        Ct_note='Supplement only: applying flat-strip longitudinal-weld expression to virtual Whitmore strip is not a direct NBR clause for this gusset topology.'),
    rupture_paths=paths,
    ordinary_path_zero_tension_lower_bound=dict(A_min_mm2=t*L,R_N=.6*fy*t*L/g2,demand_N=P,ratio=P*g2/(.6*fy*t*L),
        explanation='For the stated ordinary longitudinal/transverse paths, at least one shear segment extends over captured weld length; no transverse tension credit. Bound does not purport to enumerate arbitrary curved mechanisms.'),
    support_edge_sections=seams,
    notes=['Connected beam/column contact edges were both tested as supported, even beyond effective weld endpoints.',
      'All vertices have u outside open (650,870); every path demand and resistance branch is affine on the one active interval. Endpoint ratio envelope is exact for these families.',
      'Coincident opposite-face demands are summed in the single 12mm plate. No twice-counted gusset area.',
      'No hole deductions; Cts=0.5 conservatively used for every transverse tear segment.',
      'Gusset support sections are force-transfer sections, not candidate detached free-edge tears.',
      'CJP joint, receivers, continuity plates and panel still require independent same-case review.'])
assert abs(result['load_line_residual_Nmm'])<1e-8
assert result['whitmore']['fits_inside_polygon']
assert all(p['admissible'] and p['utilization']<1 for p in paths)
assert result['whitmore']['elastic_peak_yield_ratio']<1
assert min(normal)>0
assert all(s['DG29_N2_V4_interaction']<1 for s in seams)
Path(__file__).with_name('INDEPENDENT_GUSSET_REVIEW.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'whitmore':result['whitmore'],'paths':[{k:p[k] for k in ['id','Agv_mm2','Ant_mm2','demand_N','R_N','utilization']} for p in paths], 'support_edge_sections':seams},indent=2))
