"""Independent complete assembly, panel and continuity plate numerical check.
No imported input/oracle/production outputs. Input values independently transcribed.
"""
import math,json
from pathlib import Path
P=1e5;H=V=P/math.sqrt(2);ec=154.;eb=158.5;alpha=beta=315.
Hc=ec*V/(eb+beta);Hb=H-Hc;Vb=eb*Hb/alpha;Vc=V-Vb
N=40000-Hc;Sj=-50000+Vb;Mj=2e7
J=(ec,0.);B=(ec+alpha,eb);C=(ec,eb+beta)
Af=167*13.2;Aw=(317-2*13.2)*7.6;A0=2*Af+Aw;h0=317-13.2
Nw=N*Aw/A0;Ft=N*Af/A0-Mj/h0;Fb=N*Af/A0+Mj/h0
beam_cut=dict(point=[1000.,0.],Fx=N-Hb,Fy=Sj-Vb,M=Mj-(1000-ec)*(Sj-Vb))
upper=dict(point=[0.,1000.],Fx=10000.,Fy=-500000.,M=1e7)
lower=dict(point=[0.,-1000.],Fx=-40000-upper['Fx'],Fy=-V+50000-upper['Fy'])
# External upper + column-side gusset + beam joint + lower = 0 about O.
def moment(v):return v['M']+v['point'][0]*v['Fy']-v['point'][1]*v['Fx']
joint=dict(point=list(J),Fx=N,Fy=Sj,M=Mj)
cgusset=dict(point=list(C),Fx=Hc,Fy=Vc,M=0.)
lower['M']=-(moment(upper)+moment(cgusset)+moment(joint))+lower['point'][1]*lower['Fx']
def sum_actions(actions):return [sum(a[k] for a in actions) for k in ['Fx','Fy']]+[sum(moment(a) for a in actions)]
def reverse(a):return dict(point=a['point'],Fx=-a['Fx'],Fy=-a['Fy'],M=-a['M'])
brace=dict(point=[0.,0.],Fx=H,Fy=V,M=0.)
bgusset=dict(point=list(B),Fx=Hb,Fy=Vb,M=0.)
residuals=dict(gusset=sum_actions([brace,reverse(bgusset),reverse(cgusset)]),beam=sum_actions([beam_cut,bgusset,reverse(joint)]),column=sum_actions([upper,lower,joint,cgusset]),assembly=sum_actions([upper,lower,beam_cut,brace]))
# Internal column horizontal-cut resultant acting on upper part. All beam shear V
# and beam axial web share Nw have uniform transfer over y=-110..110 at x=154.
def strip_result(y,ylo,yhi,Fx,Fy):
    start=max(y,ylo)
    if start>=yhi:return (0.,0.,0.)
    frac=(yhi-start)/(yhi-ylo);fx=Fx*frac;fy=Fy*frac;cy=(start+yhi)/2
    return fx,fy,ec*fy-(cy-y)*fx

def column_cut(y):
    fx=upper['Fx'];fy=upper['Fy'];mo=upper['M']-(1000-y)*upper['Fx']
    for lo,hi,xforce,yforce in [(198.5,748.5,Hc,Vc),(-110.,110.,Nw,Sj)]:
        dx,dy,dm=strip_result(y,lo,hi,xforce,yforce);fx+=dx;fy+=dy;mo+=dm
    for level,F in [(h0/2,Ft),(-h0/2,Fb)]:
        if y<level:fx+=F;mo-=(level-y)*F
    return dict(y_mm=y,Fx_N=-fx,Fy_N=-fy,M_Nmm=-mo)
levels=[1000.,748.5,198.5,h0/2+1e-6,h0/2-1e-6,110.,0.,-110.,-h0/2+1e-6,-h0/2-1e-6,-1000.]
cuts=[column_cut(y) for y in levels]
Qtop=-(upper['Fx']+Hc+Ft);Qbottom=Qtop-Nw
fycol=345.;Agcol=12360.;tw=9.9;d=308.;Npl=Agcol*fycol
max_compression=max(abs(x['Fy_N']) for x in cuts)
web_shear_R=.6*fycol*d*tw/1.1
reduction=1. if max_compression<=.4*Npl else 1.4-max_compression/Npl
panel=dict(Q_top_N=Qtop,Q_bottom_N=Qbottom,governing_N=max(abs(Qtop),abs(Qbottom)),max_column_compression_N=max_compression,Npl_N=Npl,axial_reduction=reduction,compact_web_V_R_N=web_shear_R,FRd_N=web_shear_R*reduction,ratio=max(abs(Qtop),abs(Qbottom))/(web_shear_R*reduction))
# Continuity plates: independent area/inertia integration of paired plate strips.
t=12.;b=140.;clip=30.;hw=277.2;z0=tw/2;z1=z0+b;webstrip=25*tw
Aplate=2*b*t;An=2*(b-clip)*t;Acomp=Aplate+webstrip*tw
Iy=2*t*(z1**3-z0**3)/3+webstrip*tw**3/12
r=math.sqrt(Iy/Acomp);Le=.75*hw;Ne=math.pi**2*200000*Iy/Le**2
# Conservative transformed material all at fy250 incl column web fy345.
lam=math.sqrt(Acomp*250/Ne);chi=.658**(lam**2) if lam<=1.5 else .877/(lam**2)
Ncr=chi*Acomp*250/1.1
wr_line=6/math.sqrt(2)*.6*485/1.35
flange_wr=4*100*wr_line;web_wr=4*207.2*wr_line
cont=dict(plate_gross_A_mm2=Aplate,plate_flange_net_A_mm2=An,
    plate_pair_gross_tension_R_N=Aplate*250/1.1,plate_pair_net_tension_R_N=An*400/1.35,
    actually_welded_tension_Ae_mm2=2*100*t,actually_welded_net_tension_R_N=2*100*t*400/1.35,actually_welded_net_tension_ratio=Fb/(2*100*t*400/1.35),
    compression_net_yield_R_N=An*250/1.1,
    compression_column_supplement=dict(webstrip_width_mm=webstrip,A_mm2=Acomp,I_axis_in_web_plane_mm4=Iy,r_mm=r,Le_mm=Le,Ne_N=Ne,lambda0=lam,chi=chi,R_N=Ncr,note='NBR5.7.9.4 supplement; web fy conservatively reduced to plate250MPa; no independent parallel web capacity is credited.'),
    loaded_flange_pair_weld_R_N=flange_wr,web_pair_weld_R_N=web_wr,
    plate_width_minimum_mm=305/3-tw/2,plate_t_minimum_mm=max(15.4/2,b/16),
    levels=[dict(y_mm=h0/2,force_N=Ft,kind='compression',net_yield_ratio=abs(Ft)/(An*250/1.1),buckling_ratio=abs(Ft)/Ncr,loaded_flange_weld_ratio=abs(Ft)/flange_wr,web_weld_ratio=abs(Ft)/web_wr),dict(y_mm=-h0/2,force_N=Fb,kind='tension',gross_yield_ratio=Fb/(Aplate*250/1.1),net_rupture_ratio=Fb/(An*400/1.35),loaded_flange_weld_ratio=Fb/flange_wr,web_weld_ratio=Fb/web_wr)],
    transfer='Loaded flange→plate pair→column web. Same force assigned to loaded-flange weld and web weld; opposite-flange weld has zero required force in this selected static path, though identical detailing offers reserve.')
result=dict(status='complete_cut_panel_and_selected_continuity_transfer_arithmetic_pass',forces=dict(H=H,V=V,Hb=Hb,Hc=Hc,Vb=Vb,Vc=Vc),joint=joint,flange_distribution=dict(A0=A0,Af=Af,Aw=Aw,Nw=Nw,Ftop=Ft,Fbottom=Fb,h0=h0,force_residual=Nw+Ft+Fb-N,moment_residual=(Fb-Ft)*h0/2-Mj),complete_cuts=dict(beam=beam_cut,upper_column=upper,lower_column=lower),equilibrium_residuals=residuals,column_internal_cuts=cuts,panel=panel,continuity=cont,limits=['This does not independently qualify final CJP weld procedure, beam/column member stability, or full receiver-local checks.','Panel compact-web capacity must separately establish kv and web slenderness.','Compression supplement alone does not certify local plate buckling: b/t=11.6667, applicable outstand limit must be documented.'])
assert all(abs(v)<1e-7 for r in residuals.values() for v in r)
assert abs(result['flange_distribution']['force_residual'])<1e-8
assert abs(result['flange_distribution']['moment_residual'])<1e-7
assert panel['ratio']<1
assert all(row['loaded_flange_weld_ratio']<1 and row['web_weld_ratio']<1 for row in cont['levels'])
Path(__file__).with_name('INDEPENDENT_JOINT_REVIEW.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'residuals':residuals,'joint':joint,'flanges':result['flange_distribution'],'cuts':result['complete_cuts'],'panel':panel,'continuity':cont},indent=2))
