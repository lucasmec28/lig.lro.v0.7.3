# 2L em T soldadas → gusset único → mesa exterior W

Versão 0.9.28-welded-double-angle-gusset-dev. Incremento de desenvolvimento para revisão técnica, sem aprovação de fabricação, estabilidade global, publicação ou implantação. O corte T foi confirmado pelo usuário em 11/10/2026. A configuração oposta pelos vértices `><` permanece somente no roteiro futuro.

## Corpo físico e hipóteses

Duas cantoneiras laminadas de abas iguais, idênticas, uma em cada face da mesma chapa retangular. Talões alinhados na projeção; ambas as abas conectadas apontam do talão à ponta no mesmo sentido no plano. As abas livres abrem para ±z. Quatro filetes longitudinais, talão e ponta em cada face, com mesmo comprimento e pernas, sem retorno transversal, parafuso ou partilha mista. As duas faces precisam permanecer acessíveis para execução e inspeção.

O aço e a seção são comuns às duas L. Chapa, receptor W e eletrodos das interfaces L/chapa e chapa/W têm seleções independentes. A declaração de carga simétrica inclui a extremidade oposta da diagonal. Não existe porcentagem arbitrária de repartição editável.

A raiz tem apenas dois filetes, um por face da chapa, contínuos em B. A chapa fica no plano da alma de W laminado, na face exterior da mesa, com raiz longitudinal centrada na alma. Os dois extremos do W são considerados. Viga e pilar diferem por rotação rígida do sistema local. Outro suporte, alma W direta, raiz transversal ou descentrada não pertencem ao ramo.

## Equilíbrio e escalas de força

N de entrada é a força total do par em tração estática. Cada cantoneira recebe N/2. Para aba b e centroide catalogado ec, cada face transfere:

- Talão: (N/2)(1−ec/b)
- Ponta: (N/2)(ec/b)

As quatro soldas são registros físicos distintos. As duas linhas projetadas coincidentes recebem as somas N(1−ec/b) e N(ec/b); os caminhos comuns e as seções da chapa são calculados uma única vez com essas somas. A área da chapa na raiz é Bt, nunca 2Bt. Não são somadas resistências coincidentes.

A simetria ±z anula o momento externo resultante fora do plano, mas não zera a excentricidade individual ou o centroide dentro do plano. Mantêm-se vc=ec−b/2 e o ponto P=(s0+vc senθ,n0−vc cosθ). O campo de forças chega à raiz por Nraiz=N senθ, Vraiz=N cosθ e Mraiz=sP Nraiz−nP Vraiz. Deslocar P sobre a mesma linha não altera Mraiz. θ90° é regular e θ>90° preserva Vraiz negativo, se a geometria e o domínio tracionado forem válidos.

O mínimo45kN é aplicado uma única vez à ligação completa e dividido após a seleção do caso. N real, inclusive zero, permanece intacto. A recomendação opcional50% usa metade da capacidade do par, em caso separado. Não há soma de forças reais, mínimas e recomendadas.

## Resistências e reutilização

O novo motor importa primitivas puras da rota1L congelada, sem modificar esse módulo ou reutilizar sua aprovação. Executa as primitivas com N total para as famílias comuns e com N/2 para cada lado físico; monta novos resultados, etiquetas, casos e verificações2L. O método não é a simples duplicação da resistência1L.

Para cada L: Ag individual, An=Ag sem furos, Ct=max(1−ec/L,0,5), Ae=CtAg, escoamento bruto e ruptura efetiva. A verificação adicional do par soma apenas as duas áreas físicas distintas, preservando Ct por L. A área individual nunca já inclui o par.

Cada filete e seu contato longitudinal com a L/chapa recebem a parcela da própria face. Os caminhos de rasgamento das L são duplicados fisicamente com N/2; os U/L da chapa recebem a soma das faces com uma espessura, inclusive estações parciais, mudanças de borda/canto e exclusão de caminho que ainda toca a raiz apoiada. Nenhuma face apoiada é chamada de borda livre.

São preservados a contenção, a faixa local, os intervalos de seções horizontais, extremos estacionários, força e momento locais, comprimento/terminações, sobreposição, limites de filete e solda longa da rota0.9.27. Normal compressiva em qualquer seção modelada deixa o ramo fora do domínio de estabilidade, ainda que N total da barra seja de tração.

A chapa comum conserva escoamento, ruptura e interação. A raiz e o W conservam metal de solda, contatos normal/cisalhamento, punção da mesa, flexão de mesa quando aplicável, escoamento normal da alma, transferência de cisalhamento longitudinal e interação local. Não se dispensa escoamento de alma em tração.

### Convenção da raiz: revisão2 dos fixtures

qn=Nraiz/B±6Mraiz/B², qs=Vraiz/B. Cada filete recebe metade. O metal da solda usa qprojeto=max(qpico,1,25×qmédia), sendo qpico o maior módulo dos dois vetores extremos e qmédia sua média aritmética. O fator1,25 é suplemento DG29 da solda.

No contato do único gusset, δ=min(t,2sraiz). No contato W, δ=2sraiz. Usam-se σ=max|qn|/δ e τ=|qs|/δ, com envelope:

- √(σ²+3τ²)/(fy/γa1)
- σ/(fu/γa2)
- τ/(0,6fu/γa2)

A punção/cisalhamento da mesa usa qpico/(2tf), sem aplicar automaticamente qprojeto. A revisão1 dos novos fixtures usava outro campo puro-cisalhamento, que foi retirado como alvo. Os testes incluem t8<2sraiz10 e caso Mraiz0 onde1,25qmédia controla a solda e qpico controla a punção.

## Catálogo, geometria e materiais

Mantidos os50 registros Gerdau e a identidade ArcelorMittal original. A propriedade Ag/ec de cada registro não é substituída pelo perfil mais próximo. GerdauR25 é63,5×6,35, Ag767mm², ec18,3mm por L. Raios geométricos não publicados continuam desconhecidos. O contorno Gerdau é nominal esquemático, com incertezas gráficas explícitas; não há raio inventado nem uso de raio de giração como contorno.

A geometria ArcelorMittal100×100×12 mantém Ag2270mm², ec29mm, raiz12mm, ponta6mm e seus caminhos curvos publicados. Aço é seleção independente da identidade comercial.

Em R25, o filete5mm supera o máximo ordinário6,35−1,5=4,85mm. A seleção ordinária reprova. A seleção reforçada exige instrução e inspeção da garganta efetiva s/√2 nas duas L e nas duas faces, conforme NBR6.2.6.2.2(b), mantendo o limite nominal herdado s≤t. Não representa autorização irrestrita para sobreespessura.

## Saídas, casos de referência e arquivos nativos

A entrada nativa tem connection_type=welded_double_angle_gusset, schema_version1 e versão específica0.9.28. Todos os campos, unidades e premissas são estritos. Importar arquivo1L como2L, arquivo2L como1L, esquema parcial, campos extras ou premissa adulterada é recusado. Os arquivos antigos e o comportamento da rota1L permanecem preservados.

Geometria tem dois registros de L, quatro soldas físicas, duas linhas projetadas, uma chapa e dois filetes de raiz. Casos identificam N total, N por L, Ct/Ae por L e áreas do par. Verificações e testemunhas identificam a face ou o componente comum; o relatório compacto consolida mecanismos físicos sem apagar falhas e o detalhado mantém as testemunhas.

Os desenhos e relatórios recalculam as entradas atuais; resultado previamente aprovado não autoriza exportar uma entrada alterada. O desenho contém plano proporcional e corte T explícito. O resultado global_pass é somente um nome histórico da API para conclusão local; global_member_verified permanece falso.

Referências numéricas novas e independentes, revisão2:

- Arcelor100kN total:50kN por L; talão/ponta35,5/14,5kN por face; Ct0,855; área do par4540mm² e raiz4000mm². Mraiz−5,982285677kNm. Solda de talãoη0,272193514; raizη0,360590954; faixa comumη0,539733333. Atende ao escopo local.
- Mesmo detalhe200kN: talãoη0,544387028 e raizη0,721181907 atendem. A chapa comum falha: escoamento1,079466667 e ruptura adaptada1,008461538.
- GerdauR25 reforçada100kN: Mraiz−5,227285677kNm; talãoη0,272887808; raizη0,339102163; faixa comumη0,451146667.

Nenhum exemplo é projeto executivo certificado. As fontes dos fixtures são independentes do aplicativo, não reconstruções do oráculo histórico de contato de parafuso ausente.

## Limites e entrega ao verificador do membro

Ações exportadas na face e no centroide W: Mcentro=Mraiz−(d/2)Vraiz. Nraiz corresponde ao salto transversal e Vraiz à transferência longitudinal. Ações existentes do membro são desconhecidas, não zero, e devem ser combinadas pelo responsável.

Fora do escopo: compressão, fadiga, sismo, V/M/T externos arbitrários, vértices opostos, cantoneiras diferentes, partilha desigual, interface parafusada ou mista, estabilidade global do par/W/estrutura, travamentos intermediários, WPS, fabricação e inspeção. O campo elástico local é adaptação conservadora declarada, não solução exata do contínuo nem prova universal de estabilidade de chapas finas. O fator elástico6 não é atribuído ao fator plástico4 do DG29.

## Fontes

- ABNT NBR8800:2024 + Errata1:2025, fonte fornecida:§5.2 (tração/Ct),§5.7.2–5.7.3 (mesa/alma),§6.1.5 (forças mínimas/recomendadas),§6.1.8.2 (idealização estática de cantoneiras),§6.1.9,§6.2 (soldas, borda reforçada),§6.5 (elementos e rasgamento).
- AISC Design Guide29(2014), fonte fornecida:Fig3-7,Fig5-10 eEx5.4 como precedente de par abraçando gusset e cadeia local;§4.2.4 para apoio único/momento; solda da raiz com normal/cisalhamento. O exemplo parafusado de chapa recortada não qualifica por si só uma nova rota retangular perfurada.
- Gerdau, Barras e Perfis, tabela de bolso fornecida,p2–3: dimensões,Ag,ec; não publica raios do contorno.
- ArcelorMittal Orange Book, https://orangebook.arcelormittal.com/node/220; catálogoW, https://constructalia.arcelormittal.com/files/W--0487915bad55d18fbfc679cd87133c88.pdf. Dados geométricos conferidos na qualificação independente11/10/2026.
- Métodos herdados:WELDED_ANGLE_GUSSET0926_METHOD.md eGERDAU_ANGLES0927_METHOD.md. Testes específicos e limitações da entrega:VALIDATION0928.md/JSON.
