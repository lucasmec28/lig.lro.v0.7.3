# O que está verificado e o que falta

## Síntese da ligação de duas talas com nervura interna

| Parte | Situação na 0.9.65 | Alcance e próximo fechamento |
|---|---|---|
| Parafusos, talas e faixa conectada da alma da viga | Calculados | Corte dos dois grupos, contato/rasgamento, blocos, seções locais e interações já implementadas. Um eventual não atendimento continua sendo mostrado; não se confunde com ausência de modelo. |
| Contato nos furos da nervura | Calculado por direção da força | Usa furos e contorno reais. Quando o caminho encontra uma borda soldada, a transferência pela chapa continua pendente; esse trecho não é tratado como borda livre. |
| Soldas da nervura à alma e aos dois horizontais | Calculáveis e implementadas sob hipótese explícita | Grupo elástico com chapa/apoios rígidos, gargantas distintas, equilíbrio de N/V/M, tensões e reações por borda. Inclui um controle suplementar de escoamento local da nervura junto à junta. Não exige resolver primeiro toda a membrana para calcular os cordões. |
| Nervura perfurada entre furos e bordas | Modelo integral ainda pendente | Definir um campo/caminho resistente admissível que permita conferir escoamento combinado, ruptura por seções/blocos reais e estabilidade local dos trechos comprimidos/cisalhados. A equação das soldas não fornece esse campo interno. |
| Horizontais e alma da coluna que recebem a nervura | Capacidade local ainda pendente | As forças e momentos de entrada agora são conhecidos dentro da hipótese elástica. Falta conferir flexão/transferência local desses receptores e as soldas dos horizontais com a coluna. Há componentes normais aos seus planos, que não podem ser aprovadas como simples corte de chapa. |

Assim, restam principalmente **dois grupos de fechamento resistente: a nervura perfurada e seus receptores**. Além deles, a aplicação como ligação nominalmente rotulada conserva as condições de rotação/flexibilidade e de montagem/acesso já declaradas. Não se está acrescentando verificação de estabilidade global das barras.

## O que a NBR oferece para a estabilidade local

A NBR 8800:2024 corrigida em 2025 fornece caminhos úteis, mas é necessário escolher o elemento e a largura física antes de aplicar a equação:

- Item 5.1.2.2, página 38: AA e AL são definidos pelas bordas **longitudinais em relação à compressão**, não pelo número total de bordas soldadas do retângulo.
- Item 5.3.4 e Tabela 4, páginas 46–47: no domínio de elementos de barras comprimidas, o limite de esbeltez pode dispensar a redução de área. Exemplos: chapas de diafragma AA do grupo 1, b/t ≤ 1,40√(E/fy); elementos AL do grupo 4, b/t ≤ 0,56√(E/fy). Outros elementos possuem outros limites. Atender ao limite não comprova sozinho a resistência da placa perfurada.
- Item 5.4.3.1, páginas 57–58: os coeficientes de flambagem por cisalhamento dependem da tipologia e das condições do painel. O valor kv=5,34 de determinadas almas I/H/U não pode ser transplantado automaticamente para esta nervura.

A pista da NBR é válida como ferramenta para fechar um modelo equivalente justificado. A lacuna não é a inexistência de fórmulas: é identificar a região comprimida/cisalhada, a largura, os apoios efetivos e o efeito dos furos compatíveis com as forças discretas. Uma solução analítica aceita, um modelo equivalente com conservadorismo demonstrado ou uma análise de estabilidade podem resolver isso; não se afirma que somente elementos finitos servem.

## Duas hipóteses conservadoras propostas

As hipóteses de transmitir tudo pela alma ou tudo pelos horizontais podem ser avaliadas por inteiro e envolvidas pela **maior utilização de cada componente**, usando as componentes concomitantes da mesma hipótese. O oráculo confirma o equilíbrio de ambas. Essa é uma envoltória dos modelos examinados, não uma demonstração automática de que qualquer comportamento real esteja contido entre os dois. A compatibilidade e a capacidade dos receptores precisam acompanhar essa escolha.

No preset, as utilizações máximas das gargantas são 0,116 para três bordas, 0,255 para somente alma e 0,205 para somente horizontais. Portanto, uma eventual reprovação do cordão vertical numa hipótese que lhe atribui tudo não demonstraria, por si só, falha do grupo de três bordas. Consulte COMPARACAO_CAMINHOS0965.md para os casos e limites.

## Como interpretar os resultados

- “Não atende” em uma verificação já aplicável não é mera pendência documental.
- “Não atende à hipótese elástica” significa que o modelo explicitado excede seu limite e requer revisão; não comprova sozinho falha física do conjunto real.
- “Pendente” significa que falta um modelo aplicável ou sua validação. Não significa que a peça foi reprovada.
- Um conjunto de linhas locais atendidas não equivale à aprovação integral da ligação.
