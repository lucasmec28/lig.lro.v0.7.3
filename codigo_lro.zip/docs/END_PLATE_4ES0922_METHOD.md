> Histórico do escopo original. A revisão 0.9.25 substitui a restrição de mesmo aço pela qualificação independente documentada em INDEPENDENT_PLATE_STEELS0925_METHOD.md; as equações geométricas e mecanismos desta página permanecem.

# End plate 4ES com nervuras CJP — método finito 0.9.22

A variante 4ES é uma opção dentro da família de end plate engastada existente. O seletor conserva as 13 famílias e sua ordem. O ramo 4E e a end plate rotulada preservam suas contas anteriores.

## Fontes e escopo

Resistências: ABNT NBR 8800:2024, versão corrigida 2025. Fonte complementar: AISC Design Guide 39 (2023), tabela 5-11 (p.114), tabela A-2 (p.264), equações 3-36 e 3-38–3-48, figura 4-3 e exemplo 5.3-2. Foram conferidas as páginas renderizadas dos PDFs fornecidos e as tabelas 8/9 da NBR. A errata oficial DG39 de novembro de 2024 não estava acessível; não é declarada revisada.

Uma viga I duplamente simétrica, centrada na mesa de uma coluna I contínua, sem viga oposta, reforço de coluna, laje participante, fadiga ou sismo. São oito parafusos em duas colunas, duas nervuras externas iguais e extensões simétricas. Sem linhas intermediárias. O sinal de M determina qual mesa está tracionada em cada caso estático; os dois extremos são preparados para tração.

## Linhas de plastificação e ações

s = sqrt(bp,ef g)/2; de < s estritamente. Na igualdade e acima dela a tabela 5-11 não é extrapolada e o cálculo deste mecanismo é bloqueado. Para Yp somente: po=min(pfo,s), pi=min(pfi,s).

Yp = bp,ef/2 [h1(1/po+1/(2de))+h2(1/pi+1/s)] + 2/g [h1(po+de)+h2(pi+s)].

h1=d−tf/2+pfo; h2=d−3tf/2−pfi. Os braços e as posições dos parafusos continuam físicos, sem limitar os passos. bp,ef=min(bp,bf+max(tp,25,4)). Mantêm-se os limites de domínio ensaiado da tabela 5-9, acrescidos de ±10%, identificados como domínio DG39, sem convertê-los em exigências NBR de fabricação.

Meq=|M|+max(N,0)(d−tf)/2; Tb=Meq/[2(h1+h2)]; T=4Tb; C=max(T−N,0). A distribuição existente de V aos parafusos principais e a interação elíptica NBR permanecem. A expressão de coluna contínua existente é equivalente à tabela A-2 porque h1−h2=pfo+tf+pfi; as nervuras da end plate não são reforços da coluna.

Ff=|M|/(d−tf)+max(N,0)/2 e Fc=|M|/(d−tf)+max(−N,0)/2 são ações das mesas. A alma da coluna recebe max(Ff,Fc) no escoamento e Fc no enrugamento. O contato entre chapa e coluna recebe C, grandeza distinta. Estas alterações de demanda aplicam-se apenas à nova variante 4ES.

A entrada e o caso de força mínima de 45 kN são calculados separadamente. Cada linha da envoltória conserva a demanda, resistência e referência do seu caso completo. |N|(d−tf)≤|M| é exigido por caso. Um caso mínimo não resolvido impede a conclusão completa sem apagar a entrada válida.

## Nervuras e CJP

hst=pfo+de; ts≥tw fyb/fys; Lst≥hst/tan30°. O comprimento mínimo é condição do detalhe DG39 adotado. Patamares de aproximadamente 25,4 mm são recomendação de terminação, sem inventar um mínimo NBR. O recorte diagonal de canto tem pernas iguais; os trechos efetivamente conectados são hst−recorte e Lst−recorte. Recorte e patamares devem produzir polígono físico; não há solda através do recorte. O requisito de comprimento mínimo de filete não se aplica a estas juntas CJP.

A rota inicial admite somente:
- O mesmo aço catalogado na viga, chapa e nervuras: A36, A572 Gr.42 ou A572 Gr.50, respeitados produto e espessura
- ts≤min(tp,tf), como hierarquia suficiente dos receptores desta implementação
- Duas juntas CJP contínuas por nervura, sem furos nas nervuras e nas regiões de solda
- E7018 classe 70, fw=485 MPa, com declaração explícita de processo/preparação compatíveis segundo a NBR tabela 8. fw≥fu é necessário, mas isoladamente não comprova compatibilidade
- Acesso e sequência declarados: executar a junta mesa–chapa antes da instalação das nervuras; o recorte deve liberar a junta e sua preparação

O desenvolvimento é comparado no mesmo nível de resistência de cálculo: qT=fys ts/γa1 na chapa; qV=0,60 fys ts/γa1 na mesa. A capacidade CJP é a do metal-base conectado, limitada à menor resistência/espessura. As resistências integrais dos receptores também ficam no registro numérico. Verifica-se fu/γa2≥fy/γa1 no material sem furos; somente neste domínio dispensa-se uma linha duplicada de ruptura.

As linhas de desenvolvimento são condições do método, não forças externas adicionais. Uma condição de nervura, compatibilidade, acesso ou domínio não atendida retira a qualificação do mecanismo 4ES e dos parafusos sem alavanca, mesmo com ambas as espessuras numericamente atendidas. Falhas resistentes finitas permanecem identificadas separadamente.

Não se aplica a esbeltez sísmica da eq.3-37 como requisito ordinário. Não se atribui Ff/2 integralmente a uma tensão direta na nervura. As verificações 4E de cisalhamento do prolongamento são ausentes em 4ES, conforme DG39 p.141; não são apresentadas como aprovadas.

## Exemplo e evidência

O exemplo nativo usa W410×46,1/W310×97,0(H), aço A572 Gr.50, chapa160×19,05 mm, g100, pfi45, pfo40, de35 mm, duas nervuras ts9,525×hst75×Lst150 mm, recorte/patamares25,4 mm; A3253/4 pol.; M40 kN·m, V40 kN, N2 kN. O valor independente esperado é Yp=3807,618802183 mm e tp,req=6,130352007 mm na entrada. O arquivo examples/end_plate_4es_cjp.json contém o retrato recalculado.

O exemplo publicado 5.3-2 serve de oráculo de fórmulas e componentes, não de aprovação completa: sua coluna necessita reforços fora deste ramo. Os casos independentes com braços arredondados produzem Yp232,772871285 pol. e tp,req0,908403872 pol.

Os testes novos cobrem fórmula/unidades, fronteiras estritas, nervuras, consumível, sinais, casos, domínio, restauração/importação, artefatos recalculados e callbacks reais. O registro de validação acompanha a cópia final; não representa suíte integral nem publicação.
