# Cortante nos chumbadores com arruelas soldadas na versão 0.8.2

## Alcance

O incremento acrescenta à placa de base Tipo 1 o cálculo local do cortante em quatro chumbadores externos ASTM A36, rosqueados e simétricos, com quatro arruelas especiais quadradas idênticas soldadas à face superior da placa. A seleção desta rota adota explicitamente esse detalhe: todas as quatro barras devem estar efetivamente mobilizadas por furos-padrão nas arruelas. Um furo alargado na placa ou uma arruela solta não comprova essa mobilização.

A interface mantém três caminhos exclusivos: chumbadores, barra/chave de cisalhamento e atrito. Dentro de chumbadores, há o cálculo nativo com arruelas soldadas e a resistência externa documentada. Não se somam resistências entre caminhos. Os projetos anteriores conservam a rota externa ou o atrito que já usavam; não são convertidos em aprovações nativas.

Ações estáticas de cálculo N, M no eixo forte e V no mesmo plano, referidas à face superior da placa. N positivo comprime; V positivo atua em +x; M positivo comprime +x e traciona −x. M é preservado nesta rota: não se acrescenta V·tp, V·graute ou outro transporte global. O braço local tp+ta/2 já pertence ao parâmetro da expressão especial. Outra excentricidade global requer avaliação específica.

## Fontes e duas ressalvas da expressão

A base é a ABNT NBR 8800:2024, versão corrigida 2025: 6.3.2.2; 6.3.3.1 a 6.3.3.4; 6.6.5; 6.7.2.5; e Tabela 18 substituída pela Errata 1 de 2025. Conferência na documentação fornecida: páginas impressas 83–85, 99 e 108–109; Tabela 18 nas páginas 3–4 da errata. O AISC Design Guide 1, terceira edição, páginas 33–35 e exemplo 4.7-6 (páginas 91–94), foi usado para apoiar as cautelas sobre engajamento, furos-padrão, flexão local da barra e separação da ancoragem no concreto. Não se misturam seus fatores e coeficientes com a NBR.

1. A expressão impressa em 6.7.2.5 usa Ft,Sd,i dentro da raiz e Ft,Sd,1 no termo subtrativo. Não se encontrou na errata fornecida uma correção desse índice. O app preserva a tração individual na raiz e adota Ft,máx, a maior tração simultânea, no termo subtrativo de todas as barras. É um limite conservador explícito para as duas leituras, não uma transcrição literal nem uma correção oficial da norma. A tela e o Word alertam quando as trações diferem. Com trações iguais, as leituras coincidem.
2. Conserva-se o coeficiente 0,533 da expressão especial. Ela isoladamente pode dar reserva positiva de cortante quando Ft=Ft,Rd. Por isso, aplica-se simultaneamente o limite adicional da interação geral de barras rosqueadas de 6.3.3.4. Esse limite tem referência própria; não altera a expressão especial. No limite isolado de tração, a reserva de cortante é zero.

## Entradas e equações

Unidades internas N, mm e MPa. db é o diâmetro nominal real da bitola, por exemplo 1 polegada=25,4 mm. Aço da barra: fy,b=250 MPa e fub=400 MPa. Roscas atravessam a seção de corte; γa1=1,10, γa2=1,35 e γc=1,40. Concreto normal: 20≤fck≤50 MPa.

- Ab=πdb²/4.
- Ft,Rd=0,75Ab·fub/γa2.
- Fv,Rd=0,45Ab·fub/γa2, para um plano de corte com rosca. Não se multiplica novamente por 0,75.
- h=tp+ta/2, com a espessura real ta da arruela.
- α=1,45(h/db)(fub/fy,b)(γa1/γa2).
- Vaço,Rd,i=max[0; {√[(1+α²)Fv,Rd²−(0,533Ft,Sd,i)²]−α(0,533Ft,máx)}/(1+α²)].
- Vint,Rd,i=Fv,Rd√[1−(Ft,Sd,i/Ft,Rd)²], para 0≤Ft,Sd,i≤Ft,Rd.
- σc,Rd=0,85fck/γc, com A2/A1=1, sem ganho de confinamento.
- VRd,i=min(Vaço,Rd,i; Vint,Rd,i; 5db²σc,Rd).
- VRd,grupo=ΣVRd,i, somando os quatro mínimos individuais; |V|≤VRd,grupo.

O fy,b em α é da barra, não da arruela ou da placa. O limite 5db²σc,Rd é local; não é a resistência completa da ancoragem no concreto. A2/A1=4, prescrito para a chave em 6.7.2.4, não é transferido para os chumbadores.

As trações são as reações concorrentes da mesma combinação N–M: C1/C2, quatro zeros; T1, quatro valores U/4; T2, dois valores maiores e dois menores; C3/T3/momento puro, dois valores maiores e dois zeros. Inverter M troca o lado físico; inverter V preserva as capacidades do detalhe simétrico. Não se resolve uma distribuição de cortante aplicado por barra nem se presume V/4 para trações desiguais.

Tração maior que Ft,Rd mantém a falha à tração e retira o crédito resistente do grupo nativo. Radical inválido não é ocultado. Dimensões e forças não finitas ou tipos numéricos inválidos são rejeitados. Com V=0 e reserva zero no limite de tração, não se usa uma razão artificial 0/0 como aprovação.

## Arruelas reais e referência tabulada

Aço da arruela fy=345 MPa. O furo-padrão da arruela é db+1,5 mm, diferente do furo maior df da placa. A tela, o JSON, o desenho e a memória guardam o lado quadrado e a espessura real informados. Espessuras comerciais são convertidas exatamente; o botão de referência seleciona uma espessura comercial que atende ao mínimo. O app não aumenta dimensões automaticamente durante o cálculo.

Referência corrigida por bitola, espessura mínima e lado em mm: 3/4: 6,3 e 50; 7/8: 6,3 e 65; 1: 8 e 75; 1 1/4: 9,5 e 75; 1 1/2: 9,5 e 90; 1 3/4: 12,5 e 100; 2: 16 e 125. O exemplo de 1 polegada usa ta=9,525 mm, não o mínimo de 8 mm.

Verificam-se os mínimos de referência e a folga g=min(a1−lado/2; (a2−lado)/2)>0 entre arruelas, perfil e borda. g=0 não passa. A folga positiva não comprova espaço suficiente para um cordão ainda não dimensionado. Dimensão abaixo da referência ou sem folga permanece visível como não conformidade; os demais resultados calculáveis continuam disponíveis.

## Pendências obrigatórias e domínio excluído

Cada solda superior deve ser dimensionada para Fv,Rd sem redução da sua barra, conforme 6.7.2.5. Não se usa VRd,i reduzido nem V/4. Para db=25,4 mm, a ação de cada solda é 67,560997 kN. Nesta versão a ação é calculada, mas a resistência, utilização e detalhamento da solda não são calculados.

Permanecem a complementar: material/processo e geometria das soldas, comprimentos efetivos e garganta, filetes mínimos/máximos, acesso, metal-base, pressão/rasgamento dos furos conforme 6.3.3.3, flexão/seção líquida das arruelas e transferência local à placa. A referência da Tabela 18 não prova esses estados-limites para qualquer esforço.

A ancoragem no concreto requer geometria, embutimento, cabeça/porca, hipótese de fissuração, bordas, grupo realmente mobilizado, armaduras, interação tração–corte e modos aplicáveis de cone, arrancamento, pryout e ruptura lateral. Bloco/fundação, soldas do pilar e classificação de rigidez são verificações separadas.

Não abrangidos: barras diferentes de A36, chumbadores químicos ou pós-instalados, rosca fora do plano de corte, arruelas diferentes entre si, furos de arruela alargados/rasgados, menos de quatro barras mobilizadas, arruelas ausentes ou não soldadas, folga livre sem graute, graute danificado, bainhas na transferência, torção, flexão biaxial, aplicação global excêntrica não transformada, ações cíclicas, sismo, fadiga ou incêndio. Use uma memória específica/rota externa para outro detalhe.

O resultado favorável vale para as verificações locais calculadas. Não aprova os chumbadores instalados, a ancoragem ou a base completa.

## Valores de aceitação

Os sete casos analíticos de referência usam aritmética Decimal de 55 dígitos, independente do motor. Constam em tests/fixtures/anchor_native_benchmarks.json. Geometria comum: d=300, bf=150, a1=50, a2=100 mm; db=25,4, tp=25,4, ta=9,525 mm; fck=30 MPa.

- C1, sem tração: VRd,grupo=109,968061179 kN.
- T1, 25 kN por barra: 89,801307647 kN.
- T2, pares de 37,5/12,5 kN: 79,805857224 kN. A interpretação por i nos dois termos daria 89,711867735 kN; o app usa o limite conservador declarado.
- C3, N=400 kN e M=120 kN·m: 57,171577838 kN.
- T3, N=−100 kN e M=40 kN·m: 50,976575354 kN.
- Quatro barras em Ft=Ft,Rd: zero; o resultado positivo da expressão especial isolada não aprova V>0.
- tp=6,35 mm, fck=20 MPa e sem tração: o limite local de concreto governa, com 39,170428571 kN por barra e 156,681714286 kN no grupo. É um caso do núcleo de cortante, não uma base inteiramente aprovada.

Veja VALIDACAO_V082.md para o registro dos testes e suas limitações.
