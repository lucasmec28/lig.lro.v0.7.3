# Validação da distribuição 0.9.3-angle-dev

A versão inclui a R017 e a correção de segurança da end plate engastada pelo DG39.

- Execução agregada: 1.293 testes passaram em 678,22 s, após as correções estruturais.
- Durante essa execução houve apenas ajuste do desenho para impedir sobreposição da faixa de pendência e adição de seu teste geométrico. As equações estruturais permaneceram idênticas.
- Código final afetado da end plate: 98 testes focados passaram, incluindo a correção visual. Auditoria independente da end plate: 23 testes passaram.
- R017: 284 testes no estado final e 7.645 comparações independentes.
- Regressões independentes anteriores: 18 passaram.
- Memórias novas e exemplos históricos atualizados foram renderizados e conferidos.

Os registros específicos estão em VALIDACAO_R017_V093.md e END_PLATE_DG39_FINAL_PROVENANCE_V093.json. A verificação de pacote limpo é executada separadamente antes da entrega. Não houve publicação automática em GitHub/Streamlit nem homologação de produção em navegador.

Reabra e recalcule projetos anteriores de end plate engastada e exporte novas memórias. Três exemplos de falha demonstram estados limites ausentes nas versões anteriores. W200 e geometrias fora do domínio mantêm cálculos úteis e pendências explícitas, sem aprovação automática.
