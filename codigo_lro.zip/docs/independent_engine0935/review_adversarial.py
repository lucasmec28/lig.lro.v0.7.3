"""Independent physical-domain, sign, native mutation and guard acceptance."""
from pathlib import Path
from dataclasses import replace,fields
from copy import deepcopy
import sys,json,math,hashlib,datetime
H=Path(__file__).resolve().parent;S=Path(sys.argv[1]).resolve()
O=Path(sys.argv[2]).resolve() if len(sys.argv)>2 else H;O.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(S))
import lro.corner_gusset as cg
from lro.corner_gusset import CornerGusset,analyze
from lro.corner_compression import declare_current_detail,geometry_stamp,RESTRAINT_FIELDS
from body_reference import body
from independent_model import derive,cross
runtime_files=['lro/corner_gusset.py','lro/corner_compression.py','lro/bolted_corner.py','lro/models.py','lro/angle_catalog.py']
def hashes():return {f:hashlib.sha256((S/f).read_bytes()).hexdigest() for f in runtime_files}
start=hashes();rows=[];failures=[];states=[];counts={}
def check(name,passed,detail=None,category='domain'):
    row=dict(id=name,passed=bool(passed),category=category,detail=detail)
    rows.append(row);counts[category]=counts.get(category,0)+1
    if not passed:failures.append(row)
def close(name,a,b,category='body_numeric'):
    check(name,type(a) in (int,float) and math.isclose(a,b,rel_tol=1e-8,abs_tol=1e-6),dict(actual=a,expected=b),category)
def checks(o):return {r['id']:r for r in o['checks']}
def ids(o):return {r['id'] for r in o['issues']}
def declare(c):return declare_current_detail(c,'Independent adversarial witness: explicit ordinary restraint detail for current geometry, local method test only.')
def observe(name,c):
    o=analyze(c);states.append(dict(id=name,status=o['status'],complete=o['complete'],issue_ids=sorted(ids(o)),failed_ids=[r['id'] for r in o['checks'] if r['status']=='FAIL']))
    return o
base=declare(replace(CornerGusset(),P=-50000.));base_out=analyze(base)
check('CC2_control_PASS',base_out['approved'])
for root in ['beam','column','brace']:
    for state in ['unknown','absent']:
        name=root+'_'+state;o=observe(name,replace(base,**{'compression_'+root+'_restraint':state}))
        check(name+'/blocks',not o['approved'] and 'compression_'+root+'_restraint' in ids(o) and not o['compression']['qualified'])
        check(name+'/strength_retained','gusset_centered_whitmore_compression_buckling' in checks(o))
        failed=observe(name+'_CC1',replace(base,P=-100000.,**{'compression_'+root+'_restraint':state}))
        check(name+'/concurrent_fail_not_hidden',failed['status']=='FAIL' and checks(failed)['continuity_top_concurrent_column_receiver_bound']['status']=='FAIL')
o=observe('all_unknown_existing_lateral_true',replace(CornerGusset(),P=-50000.,lateral_restraint=True))
check('existing_lateral_is_insufficient',not o['approved'] and all('compression_'+r+'_restraint' in ids(o) for r in ['beam','column','brace']))
for key,issue in [('compression_detail_source','compression_detail_source'),('compression_geometry_stamp','compression_geometry_declaration')]:
    for value in ['', '   ']:
        for thickness in [12.,6.]:
            c=declare(replace(base,P=-100000.,plate_t=thickness));c=replace(c,**{key:value})
            name='blank_'+key+'_'+repr(value)+'_t'+str(thickness);o=observe(name,c)
            check(name+'/pending_failure',o['status']=='FAIL' and issue in ids(o) and checks(o)['continuity_top_concurrent_column_receiver_bound']['status']=='FAIL')
            if thickness==6.:check(name+'/buckling_failure',checks(o)['gusset_centered_whitmore_compression_buckling']['status']=='FAIL')
            round_trip=CornerGusset.from_dict(c.to_dict());check(name+'/native_unknown_preserved',getattr(round_trip,key)==value and not analyze(round_trip)['approved'],category='native')
o=observe('receiver_lateral_absent',replace(base,lateral_restraint=False))
check('receiver_lateral_distinct_gate',not o['approved'] and o['compression']['declaration_matches_geometry'] and o['compression']['qualified'],ids(o))

geometry_changes=[('plate_width',620.),('plate_height',620.),('plate_t',13.),('corner_clip',40.),
 ('beam_seam_start_margin',15.),('beam_seam_end_margin',15.),('column_seam_start_margin',15.),('column_seam_end_margin',15.),
 ('root_weld_leg',7.),('phi_deg',40.),('workpoint_offset',5.),('brace_weld_start',620.),('brace_weld_length',200.),
 ('brace_weld_leg',4.5),('brace_free_end_extension',25.),('angle_profile','GERDAU_EQUAL_ANGLE_P03_R34'),
 ('beam_web_weld_length',210.),('beam_web_weld_leg',6.),('beam_access_radius',20.),('continuity_width',135.),
 ('continuity_t',14.),('continuity_clip',25.),('continuity_flange_weld_leg',5.5),('continuity_web_weld_leg',5.5),
 ('column_end_top',2100.),('column_end_bottom',-2100.),('matching_cjp',False)]
for key,value in geometry_changes:
    c=replace(base,**{key:value});o=observe('stale_'+key,c)
    check('stale_'+key,geometry_stamp(c)!=base.compression_geometry_stamp and 'compression_geometry_declaration' in ids(o) and not o['approved'])
    raw=c.to_dict();imported=CornerGusset.from_dict(deepcopy(raw));again=analyze(imported)
    check('stale_import_'+key,not again['approved'] and 'compression_geometry_declaration' in ids(again),'Native import retains stale evidence; does not restamp.',category='native')
for key,value in [('P',-60000.),('E',180000.),('gusset_steel','ASTM A572 Gr.50'),('angle_steel','ASTM A572 Gr.50'),('gamma_a1',1.15),('case_id','CHANGED_CASE'),('project','CHANGED_PROJECT')]:
    c=replace(base,**{key:value});o=observe('nongeometry_'+key,c)
    check('nongeometry_'+key,geometry_stamp(c)==base.compression_geometry_stamp and 'compression_geometry_declaration' not in ids(o))

for name,changes,expected in [
 ('beam_short',dict(beam_seam_end_margin=260.),'compression_beam_projection'),
 ('column_short',dict(column_seam_end_margin=260.),'compression_column_projection'),
 ('clip_interference',dict(corner_clip=250.),'compression_beam_projection'),
 ('offset',dict(workpoint_offset=30.),'compression_axial_domain'),
 ('mixed_sign',dict(phi_deg=80.),'compression_direct_load_flow'),
 ('nonsymmetric',dict(symmetric=False),'compression_axial_domain')]:
    o=observe(name,declare(replace(base,**changes)))
    check(name+'/specific_gate',expected in ids(o) and not o['approved'],sorted(ids(o)))
    check(name+'/retained_buckling','gusset_centered_whitmore_compression_buckling' in checks(o))
o=observe('new_ordinary_clip100',declare(replace(base,corner_clip=100.)))
check('no_invented_30mm_limit',o['compression']['qualified'] and 'compression_geometry_declaration' not in ids(o),sorted(ids(o)))
o=observe('zero_root',replace(base,beam_seam_end_margin=570.))
check('zero_root_rejected',not o['approved'] and o['status']=='INVALID')
for phi in [0.,90.,180.,-45.]:
    o=observe('angle_outside_'+str(phi),replace(base,phi_deg=phi))
    check('angle_outside_'+str(phi),not o['approved'])
for key,value in [('plate_t',0.),('E',0.),('gamma_a1',0.),('brace_weld_length',0.),('root_weld_leg',0.)]:
    o=observe('nonpositive_'+key,replace(base,**{key:value}))
    check('nonpositive_'+key,not o['approved'] and o['status']=='INVALID')

for topology in ['single_1L_welded','single_1L_bolted','symmetric_2L_T_bolted']:
    c=replace(CornerGusset(),P=-50000.,topology=topology,symmetric=not topology.startswith('single'),
              plate_width=300. if 'bolted' in topology else 600.,plate_height=300. if 'bolted' in topology else 600.,
              bolt_heel_extent=13.94,bolt_heel_extent_source='Explicit independent assumed detail')
    o=observe('excluded_'+topology,c)
    check('excluded_'+topology,not o['approved'] and 'compression' not in o)
    low=observe('excluded_low_'+topology,replace(c,P=-20000.))
    check('excluded_low_'+topology,not low['approved'] and not low.get('design_cases'))

# Signed local tension generated by in-plane body flexure is retained even
# while actual axial P is compressive; the independent search uses no app rows.
for phi in [35.,45.,55.]:
    changes=dict(P=-50000.,phi_deg=phi);o=observe('body_phi'+str(phi),declare(replace(base,phi_deg=phi)))
    ref=body(changes);max_tension=ref['maximum']('sigma');max_vm=ref['maximum']('VM');rr=checks(o)
    close('body/'+str(phi)+'/VM',rr['gusset_actual_body_chord_gross']['demand'],max_vm['value'])
    if max_tension['value']>1e-7:
        check('body/'+str(phi)+'/tension_row_retained','gusset_actual_body_chord_rupture' in rr)
        close('body/'+str(phi)+'/tension',rr['gusset_actual_body_chord_rupture']['demand'],max_tension['value'])
    else:check('body/'+str(phi)+'/pure_compression_rupture_inactive','gusset_actual_body_chord_rupture' not in rr)
    for i,state in enumerate(o['gusset_body']['candidates']):
        want=ref['at'](state['u'],state['edge'])
        for key in ['b','centroid_v','N','V','M','VM']:close('body/'+str(phi)+'/'+str(i)+'/'+key,state[key],want[key])

# Both positive and negative local components of the shared assembly persist.
rr=checks(base_out)
check('compression_top_tension_bottom',base_out['joint_distribution']['Ftop']<0<base_out['joint_distribution']['Fbottom'])
check('positive_flange_net_retained','joint_bottom_beam_flange_net' in rr and 'joint_top_beam_flange_net' not in rr)
check('web_pure_compression_rupture_inactive','joint_web_base_normal_rupture' not in rr and 'joint_web_column_flange_contact_normal_rupture' not in rr)
check('continuity_bending_tension_retained',all('continuity_'+level+'_column_web_normal_rupture' in rr for level in ['top','bottom']))
for index,group in enumerate(base_out['receiver_unions']):
    close('union/'+str(index)+'/sum',group['demand'],sum(abs(v) for v in group['forces']))
    close('union/'+str(index)+'/capacity',group['resistance'],1.1*(group['span']+group['spread_multiplier']*15.4)*345*9.9/1.1)

# Native rejection may not replace, mutate or clear the last valid object.
accepted=base.to_dict();saved=json.dumps(accepted,sort_keys=True,ensure_ascii=False)
output_saved=json.dumps(base_out,sort_keys=True,ensure_ascii=False)
rt=CornerGusset.from_dict(deepcopy(accepted));check('roundtrip_negative',rt.to_dict()==accepted and analyze(rt)==base_out,category='native')
mutations=[]
for key in accepted:mutations.append(('missing_root_'+key,lambda d,k=key:d.pop(k)))
for key in RESTRAINT_FIELDS:mutations.append(('missing_compression_'+key,lambda d,k=key:d['connection'].pop(k)))
mutations.extend([('extra_root',lambda d:d.update(extra=1)),('extra_field',lambda d:d['connection'].update(extra=1)),
 ('wrong_family',lambda d:d.update(connection_type='other')),('wrong_version',lambda d:d.update(component_version='0.9.99')),
 ('bool_schema',lambda d:d.update(schema_version=True)),('wrong_units',lambda d:d['units'].update(force='kN')),
 ('bad_assumption',lambda d:d['fixed_assumptions'].update(angle_count=1)),('bad_topology',lambda d:d['connection'].update(topology='one_root'))])
for key in ['beam_profile','column_profile','angle_profile','gusset_steel','angle_steel','beam_steel','column_steel','continuity_steel']:
    mutations.append(('unknown_'+key,lambda d,k=key:d['connection'].update({k:'DOES_NOT_EXIST'})))
for key in ['P','plate_t','phi_deg','brace_weld_start','E','gamma_a1','beam_cut_Fx','upper_column_cut_M','root_weld_leg']:
    for label,value in [('NaN',float('nan')),('positive_infinity',float('inf')),('negative_infinity',-float('inf')),('bool',True),('string','1'),('none',None)]:
        mutations.append((key+'_'+label,lambda d,k=key,v=value:d['connection'].update({k:v})))
for key in ['compression_beam_restraint','compression_column_restraint','compression_brace_restraint']:
    for value in [True,1,None,'yes','',False]:mutations.append((key+'_'+repr(value),lambda d,k=key,v=value:d['connection'].update({k:v})))
for key in ['compression_detail_source','compression_geometry_stamp']:
    for value in [True,1,None,False]:mutations.append((key+'_'+repr(value),lambda d,k=key,v=value:d['connection'].update({k:v})))
for key in ['symmetric','lateral_restraint','matching_cjp','other_loads_excluded']:
    for value in [0,1,'false',None]:mutations.append((key+'_'+repr(value),lambda d,k=key,v=value:d['connection'].update({k:v})))
for name,mutate in mutations:
    raw=deepcopy(accepted);mutate(raw);rejected=False
    try:CornerGusset.from_dict(raw)
    except (ValueError,TypeError):rejected=True
    check('native_reject/'+name,rejected and json.dumps(base.to_dict(),sort_keys=True,ensure_ascii=False)==saved,category='native')
check('native_rejections_output_unchanged',json.dumps(analyze(base),sort_keys=True,ensure_ascii=False)==output_saved,category='native')
positive=CornerGusset().to_dict()
check('positive_default_group_omitted',not set(RESTRAINT_FIELDS)&set(positive['connection']),category='native')
for key in RESTRAINT_FIELDS:
    raw=deepcopy(positive);raw['connection'][key]=getattr(base,key);rejected=False
    try:CornerGusset.from_dict(raw)
    except (ValueError,TypeError):rejected=True
    check('positive_partial_group_rejected/'+key,rejected,category='native')
explicit_positive=replace(base,P=50000.);native_positive=explicit_positive.to_dict()
check('positive_explicit_group_retained',all(key in native_positive['connection'] for key in RESTRAINT_FIELDS) and CornerGusset.from_dict(native_positive).compression_geometry_stamp==base.compression_geometry_stamp,category='native')

for key in ['P','plate_t','phi_deg','E','gamma_a1','beam_cut_Fx','upper_column_cut_M']:
    for label,value in [('nan',float('nan')),('infinity',float('inf')),('overflow',1e150),('bool',True),('text','bad')]:
        o=observe('direct_invalid_'+key+'_'+label,replace(base,**{key:value}))
        check('direct_invalid_'+key+'_'+label,not o['approved'] and o['status']=='INVALID',category='invalid_input')
for key in ['beam_profile','column_profile','angle_profile']:
    o=observe('direct_unknown_'+key,replace(base,**{key:'not_a_profile'}))
    check('direct_unknown_'+key,not o['approved'] and o['status']=='INVALID',category='invalid_input')

# The old native negative fixture has no declaration; import cannot infer one.
legacy=json.loads((H/'CC1_NATIVE_DIAGNOSTIC_INPUT.json').read_text())
legacy_obj=CornerGusset.from_dict(legacy);lo=observe('legacy_negative_safe_import',legacy_obj)
check('legacy_negative_no_silent_approval',not lo['approved'] and all(getattr(legacy_obj,'compression_'+r+'_restraint')=='unknown' for r in ['beam','column','brace']),category='native')

# A corrupted assembly that counts the diagonal twice must activate equilibrium.
original=cg._resultant
def doubled(actions,about=(0.,0.)):
    actions=deepcopy(actions)
    if len(actions)==4 and actions[-1].get('point')==[0.,0.]:actions.append(deepcopy(actions[-1]))
    return original(actions,about)
try:
    cg._resultant=doubled;o=observe('seeded_doubled_brace',base)
finally:cg._resultant=original
check('seeded_doubled_brace_rejected',not o['approved'] and 'equilibrium' in ids(o),sorted(ids(o)))
lower=base_out['complete_cuts']['column_lower']
o=observe('wrong_supplied_lower',replace(base,compare_lower_cut=True,lower_column_check_Fx=2*lower['Fx'],lower_column_check_Fy=lower['Fy'],lower_column_check_M=lower['M']))
check('wrong_supplied_lower_rejected','lower_cut_mismatch' in ids(o) and not o['approved'])

extras=({'label':'Explicit extra beam action','member':'beam','point':[900.,0.],'Fx':5000.,'Fy':3000.,'M':1000000.},
        {'label':'Explicit extra column action','member':'column','point':[50.,500.],'Fx':-1000.,'Fy':-2500.,'M':2000000.})
c=replace(base,P=-20000.,other_loads_excluded=False,other_loads=extras)
o=observe('minimum_with_other_loads',c);design=o['design_cases'][0]['result']
for label,P,result in [('actual',-20000.,o),('synthetic',-45000.,design)]:
    ref=derive({'P':P});lower_ref=list(ref['lower'])
    lower_ref[0]-=sum(a['Fx'] for a in extras);lower_ref[1]-=sum(a['Fy'] for a in extras)
    lower_ref[2]-=sum(a['M']+cross([a['point'][0],a['point'][1]+1000.],[a['Fx'],a['Fy']]) for a in extras)
    for key,want in zip(['Fx','Fy','M'],lower_ref):close('other_loads/'+label+'/lower/'+key,result['complete_cuts']['column_lower'][key],want,'minimum_numeric')
    joint_ref=[ref['J'][0]+5000.,ref['J'][1]+3000.,ref['J'][2]+1000000.+(900.-154.)*3000.]
    for key,want in zip(['Fx','Fy','M'],joint_ref):close('other_loads/'+label+'/joint/'+key,result['joint_beam_to_column'][key],want,'minimum_numeric')
check('minimum_other_loads_actual_preserved',c.other_loads==extras and o['design_cases'][0]['robot_lower_comparison'] is False)

for topology,count in [('symmetric_2L_T_welded',2),('single_1L_welded',1)]:
    for P in [0.,1.,20000.,44999.,45000.]:
        c=replace(CornerGusset(),topology=topology,symmetric=count==2,P=P);o=observe('minimum_'+topology+'_'+str(P),c)
        check('minimum/'+topology+'/'+str(P)+'/actual_preserved',o['forces']['H']==P/math.sqrt(2) or math.isclose(o['forces']['H'],P/math.sqrt(2)))
        if P<45000.:
            design=o['design_cases'][0];check('minimum/'+topology+'/'+str(P)+'/once',len(o['design_cases'])==1 and design['design_P']==45000.)
            rr=checks(design['result']);id='minimum45__angle_'+('each_' if count==2 else 'single_')+'gross'
            close('minimum/'+topology+'/'+str(P)+'/per_angle',rr[id]['demand'],45000./count,'minimum_numeric')
        else:check('minimum/'+topology+'/at_boundary_no_synthetic',not o.get('design_cases'))

check('runtime_unchanged',start==hashes(),category='provenance')
report=dict(checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),result='PASS' if not failures else 'FAIL',counts=counts,
            observation_count=len(rows),scenario_count=len(states),failures=failures,rows=rows,states=states,source_hashes=start,
            counting='Independent observations/comparisons, not source pytest case counts; parameter search diagnostics are not counted passed tests.')
(O/'ADVERSARIAL_ACCEPTANCE.json').write_text(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False,default=list)+'\n')
print(json.dumps(dict(result=report['result'],counts=counts,observations=len(rows),scenarios=len(states),failures=failures),ensure_ascii=False,indent=2))
sys.exit(bool(failures))
