# Independent engine acceptance: welded symmetric 2L-T corner compression

Baseline: immutable 0.9.34 harness-amended source. Candidate is executed only at owner-announced checkpoints. No production writes.

## Separate evidence classes

- Independent method/reference scalar comparisons, fixed before candidate execution
- Parameterized runtime comparisons against independent arithmetic
- Adversarial physical/domain/native observations
- Complete-state legacy parity, exact except version tags; all intentional differences recorded by path
- Source pytest cases and applicable aggregate counts, reported separately without adding overlapping runs

## Mechanical matrix

1. CC1: centered Whitmore area, exact full-interval maximum length (including face-switch station), K=1, NBR reduction and no mixed LRFD factor. Gusset eta 0.277232471; common receiver conservative bound FAIL at 1.018850579. This failure is not proof of actual material yielding.
2. CC2: same geometry and complete background cuts at -50 kN, receiver eta 0.848249209, gusset eta 0.138616235; qualified local PASS only if all remaining rows/detail gates pass.
3. CC3: 6 mm gusset eta 2.178748408, receiver failure retained and Le/r=247.700084 service qualification pending. Neither the pending flag nor another failure removes any computed failure.
4. Independent variations: phi 40/50, t16, fy changes for angle and gusset independently, wider/slenderer catalog angles, weld start 600/700, length 180/260, shifted effective seams, E180GPa, gamma1.15, and separately changed concurrent cuts.
5. Curve boundaries: length zero by continuity, lambda0 1.5 and both sides, long column. Full reduction remains at short positive length; no yielding-only shortcut.
6. Signed physical weld vectors, root normals/shears, receiver compression modes, J/lower cuts, flange signs, web action, continuity bending tension, concurrent panel and receiving union. No double counting of the common gusset or per-angle doubling of minimum force.
7. Pure compression removes tensile net rupture/end-tip blocks; positive local bending tensile stress remains active. Shared weld-run shear-only envelope remains, not a fictitious outward tensile tear path.

## Qualification and adversarial matrix

Each physical restraint independently unknown or absent; all declarations still require current geometry-bound source/detail. Existing lateral-restraint flag alone cannot qualify the compression model. Geometry changes and stale imported signatures cannot silently remain approved.

Exercise shortened/root-interfered paths, enlarged clips with and without explicit renewed detail, contained shifted geometry, force-line offsets, mixed-sign root field, invalid/nonfinite numbers/profiles/steels, 1L and bolted compression, nonsymmetry/unsupported topology. Test loss of receiver sidesway restraint independently. Confirm all strength failures survive missing qualification. Seed incorrect/doubled lower-cut load so equilibrium must refuse approval.

## Minimum-force amendment approved by parent

0.9.34 omitted welded minimum-force cases. For 0<P<45 kN, welded 1L and 2L-T now gain a separate +45 kN full-chain case. For -45<P<0, only the qualified welded 2L-T compression branch gains -45 kN. At zero, actual P remains zero and +45 kN is the explicitly labelled nominal tensile minimum convention, not a normative statement of force sense. Actual cuts are immutable; D/U and other loads are retained as synthetic background, lower cut recomputed and not labelled actual Robot. P>=45 kN old positive full states must remain unchanged.

## Native and parity matrix

Native save/reopen preserves signed force, known/unknown restraints, detail source and geometry binding; geometry mutation cannot inherit earlier declaration. Bad import is rejected or stays unverified without mutating the accepted object. Legacy corner import remains compatible with historical versions. Hash complete native/result states of all old 19 routes and presets, including all checks/fields/properties; record all deliberately changed old negative diagnostic and minimum-case paths instead of deleting fields to force parity.

The missing historical external bearing oracle remains explicitly unavailable and is not searched again, recreated, or counted passed.
