"""Portable, read-only exact-runtime and independent-engine acceptance.

The full forensic historical snapshots are optional audit evidence. All native
and output fields still enter the compact legacy canonical hash gate.
"""
from pathlib import Path
import argparse,json,sys,subprocess,hashlib,datetime,os
p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--output',required=True);args=p.parse_args()
H=Path(__file__).resolve().parent;S=Path(args.source).resolve();O=Path(args.output).resolve();O.mkdir(parents=True,exist_ok=True)
receipt=json.loads((H/'ENGINE_ACCEPTANCE0935.json').read_text())
for file,expected in receipt['accepted_engine_source_hashes'].items():
    actual=hashlib.sha256((S/file).read_bytes()).hexdigest()
    if actual!=expected:raise SystemExit('Runtime hash mismatch for '+file+'; this frozen qualification belongs to the recorded 0.9.35 engine, not another version.')
manifest=json.loads((H/'PAYLOAD_MANIFEST.json').read_text())
for file,expected in manifest['files'].items():
    actual=hashlib.sha256((H/file).read_bytes()).hexdigest()
    if actual!=expected:raise SystemExit('Qualification payload hash mismatch: '+file)
commands=[('reference',[sys.executable,str(H/'validate_reference.py'),str(O/'reference')]),
          ('numeric',[sys.executable,str(H/'review_runtime.py'),str(S),str(O/'numeric')]),
          ('adversarial',[sys.executable,str(H/'review_adversarial.py'),str(S),str(O/'adversarial')]),
          ('legacy',[sys.executable,str(H/'legacy/replay_legacy_compact.py'),'--source',str(S),'--output',str(O/'LEGACY_FULL_STATE_REPLAY.json')])]
runs=[]
environment=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
for name,command in commands:
    result=subprocess.run(command,capture_output=True,text=True,env=environment)
    (O/(name+'.log')).write_text(result.stdout+'\n'+result.stderr)
    runs.append(dict(name=name,exit_code=result.returncode,log=name+'.log'))
    print(json.dumps(runs[-1]),flush=True)
    if result.returncode:print(result.stdout[-5000:]+result.stderr[-5000:],flush=True)
success=all(r['exit_code']==0 for r in runs)
summary=dict(checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),passed=success,runs=runs,
             source_hashes=receipt['accepted_engine_source_hashes'],counting='Reference/numeric/logical/full-state comparisons are distinct from source pytest tests and aggregate tests; do not add overlapping counts.')
if success:
    ref=json.loads((O/'reference/INDEPENDENT_REFERENCE_VALIDATION.json').read_text())
    num=json.loads((O/'numeric/RUNTIME_COMPARISON.json').read_text())
    adv=json.loads((O/'adversarial/ADVERSARIAL_ACCEPTANCE.json').read_text())
    legacy=json.loads((O/'LEGACY_FULL_STATE_REPLAY.json').read_text())
    summary.update(reference_comparisons=ref['comparisons'],runtime_comparisons=num['counts'],adversarial_observations=adv['observation_count'],
                   legacy_full_state_rows=legacy['total_full_state_rows'],legacy_exact_old_rows=legacy['exact_old_state_rows'],
                   explicitly_reviewed_changed_rows=legacy['explicitly_reviewed_changed_rows'],scope_assertions=legacy['scope_assertions'])
(O/'FINAL_ENGINE_REPLAY0935.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False,indent=2));sys.exit(not success)
