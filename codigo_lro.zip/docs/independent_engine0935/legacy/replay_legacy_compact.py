"""Compact full-state gate: immutable old hashes + reviewed changed fingerprints.

No forensic snapshot is needed. Nothing is removed from the required native/
output digest. Every changed-case actual-state invariant uses an immutable-old
hash. Full old/new field-delta evidence belongs to the separate audit payload.
"""
from pathlib import Path
import argparse,json,datetime,sys
from full_state import Runtime,digest,sha_file,required_state,model_observation
parser=argparse.ArgumentParser();parser.add_argument('--source',required=True);parser.add_argument('--output');parser.add_argument('--expect-baseline',action='store_true',help='Check all original 0.9.34 hashes, without expecting the reviewed 0.9.35 scope additions.');args=parser.parse_args()
root=Path(__file__).resolve().parent
expected_path=root/'COMPACT_FULL_STATE_EXPECTATIONS0934_0935.json'
e=json.loads(expected_path.read_text());runtime=Runtime(args.source)
if runtime.numpy.__version__!=e['numpy']:raise SystemExit('Exact legacy replay requires NumPy '+e['numpy']+'; found '+runtime.numpy.__version__)
provenance=runtime.provenance();rows=[];scope_rows=[];errors=[];failures=[]
required_negative_issues={'compression_beam_restraint','compression_column_restraint','compression_brace_restraint','compression_detail_source','compression_geometry_declaration'}

def verify_scope(identifier,state):
    invariant=e['scope_invariants'][identifier];out=state['output'];checks={}
    def check(name,value):
        checks[name]=bool(value)
        if not value:failures.append({'id':identifier,'scope_check':name})
    if invariant['kind']=='authorized_minimum_force_scope_change':
        retained={key:out.get(key) for key in invariant['retained_output_keys']}
        check('all_other_old_output_fields_exact',digest(retained)==invariant['retained_output_sha256'])
        check('native_input_exact',digest(state['input'])==invariant['native_input_sha256'])
        count=invariant['old_check_count'];actual=out['checks'][:count]
        check('all_old_checks_retained_in_order',len(actual)==count and all(item.get('case_id')=='actual' for item in actual))
        check('every_old_check_field_exact',digest([{key:val for key,val in item.items() if key!='case_id'} for item in actual])==invariant['old_checks_sha256'])
        cases=out.get('design_cases',[]);check('one_synthetic_minimum_case',len(cases)==1)
        if len(cases)==1:
            case=cases[0]
            check('minimum_is_plus_45kN',case.get('design_P')==45000.0 and case.get('actual_P')==invariant['P'] and case.get('id')=='minimum_45kN')
            check('minimum_is_not_robot_real_combination',case.get('robot_lower_comparison') is False and 'não combinação real' in case.get('origin',''))
            check('zero_convention_explicit_only_for_zero',bool(case.get('zero_force_convention'))==(invariant['P']==0))
            check('actual_force_case_exact',digest(out.get('force_cases',{}).get('actual'))==invariant['actual_forces_sha256'])
            check('synthetic_force_case_consistent',out.get('force_cases',{}).get('minimum_45kN')==case['result'].get('forces'))
            check('synthetic_checks_appended_once',len(out['checks'])==count+len(case['result']['checks']))
            check('synthetic_check_labels_explicit',all(item.get('case_id')=='minimum_45kN' and item['id'].startswith('minimum45__') for item in out['checks'][count:]))
    else:
        check('old_negative_input_never_approved',out.get('approved') is False and out.get('complete') is False)
        check('old_negative_input_not_pass',out.get('status')!='PASS')
        check('all_missing_declaration_guards_present',required_negative_issues<={issue['id'] for issue in out.get('issues',[])})
        check('actual_complete_cuts_preserved',digest(out.get('complete_cuts'))==invariant['actual_complete_cuts_sha256'])
        check('actual_forces_preserved',digest(out.get('forces'))==invariant['actual_forces_sha256'])
        if -45000<invariant['P']<0:
            cases=out.get('design_cases',[])
            check('negative_minimum_45kN_separate',len(cases)==1 and cases[0].get('design_P')==-45000 and cases[0].get('actual_P')==invariant['P'])
        else:check('no_unnecessary_minimum_case',not out.get('design_cases'))
    scope_rows.append({'id':identifier,'checks':checks,'passed':all(checks.values())})

def verify(group,spec,callback):
    identifier=spec['id'];row={'group':group,'id':identifier,'expected_old_sha256':spec['canonical_complete_state_sha256']}
    try:
        state=callback();actual=digest(required_state(state));exact=actual==spec['canonical_complete_state_sha256']
        reviewed=e['accepted_changed_states'].get(identifier) if group=='diagnostics' and not args.expect_baseline else None
        passed=actual==(reviewed['accepted_new_sha256'] if reviewed else spec['canonical_complete_state_sha256'])
        row.update(actual_sha256=actual,exact_old_state=exact,accepted_changed_state=reviewed is not None,accepted_changed_sha256=reviewed['accepted_new_sha256'] if reviewed else None,passed=passed,input_model_observation_sha256=digest(model_observation(state)),input_model_observation_matches_old=digest(model_observation(state))==spec['input_model_observation_sha256'])
        if not passed:failures.append({'group':group,'id':identifier,'reason':'complete state hash mismatch'})
        if group=='native_round_trips':
            row['native_round_trip_unchanged']=state['native_input']==state['native_round_trip']
            if not row['native_round_trip_unchanged']:failures.append({'group':group,'id':identifier,'reason':'native round trip changed'})
        if reviewed:verify_scope(identifier,state)
    except Exception as error:
        row.update(passed=False,error={'type':type(error).__name__,'message':str(error)});errors.append({'group':group,'id':identifier,'error':row['error']})
    rows.append(row)

for spec in e['cases']:verify('cases',spec,lambda spec=spec:runtime.preset_state(spec['module'],spec['name'],spec['route']))
for spec in e['native_round_trips']:verify('native_round_trips',spec,lambda spec=spec:runtime.native_state(spec['input']))
for spec in e['diagnostics']:verify('diagnostics',spec,lambda spec=spec:runtime.diagnostic_state(spec))
source_unchanged=runtime.provenance()['source_files']==provenance['source_files']
if not source_unchanged:errors.append({'reason':'source changed during replay'})
result={'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'expect_baseline':args.expect_baseline,'route_count':e['route_count'],'legacy_presets':len(e['cases']),'legacy_corner_native_round_trips':len(e['native_round_trips']),'supplemental_cases':len(e['diagnostics']),'total_full_state_rows':len(rows),'exact_old_state_rows':sum(row.get('exact_old_state',False) for row in rows),'explicitly_reviewed_changed_rows':sum(row.get('accepted_changed_state',False) for row in rows),'scope_assertions':sum(len(row['checks']) for row in scope_rows),'passed':not errors and not failures,'exact_all_rows_old_parity':all(row.get('exact_old_state',False) for row in rows),'failures':failures,'execution_errors':errors,'full_state_rows':rows,'scope_rows':scope_rows,'normalization':e['normalization'],'canonical_rules':e['canonical_rules'],'expectations_sha256':sha_file(expected_path),'source_unchanged':source_unchanged,'provenance':provenance,'audit_provenance':e['audit_provenance'],'changed_state_interpretation':e['changed_state_interpretation'],'external_bearing_oracle':e['external_bearing_oracle']}
if args.output:Path(args.output).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({key:result[key] for key in ('route_count','legacy_presets','legacy_corner_native_round_trips','supplemental_cases','total_full_state_rows','exact_old_state_rows','explicitly_reviewed_changed_rows','scope_assertions','passed','exact_all_rows_old_parity','failures','execution_errors','source_unchanged')},ensure_ascii=False,indent=2))
raise SystemExit(2 if errors else 1 if failures else 0)
