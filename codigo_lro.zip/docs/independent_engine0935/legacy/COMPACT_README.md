# Compact full-state legacy gate

This small APP payload needs no forensic snapshots. It covers 19 legacy routes, 108 presets, 10 legacy native corner round trips, and 38 supplemental cases, totaling 156 complete native/output states.

Run with the application's dependencies and exactly NumPy 2.5.3:

```sh
python replay_legacy_compact.py --source /path/to/source0935 --output COMPACT_REPLAY0935.json
python test_canonical_contract.py
```

All 141 unaffected states must equal immutable 0.9.34 whole-state SHA-256 expectations. The remaining 15 explicitly reviewed states must equal locked, complete 0.9.35 fingerprints: ten welded low/zero-force minimum-chain cases and five old undeclared negative-compression diagnostics. They are reported as changed states, never as old-state parity. Their post-review fingerprints are not represented as an independent compression numerical oracle; the separate mechanical reference tests supply that validation.

Another 150 scope assertions use immutable-baseline hashes to retain every original physical output field/check except the expressly changed check/envelope summaries, verify actual/synthetic case provenance, and keep old undeclared compression inputs unapproved. There is no numerical tolerance, field deletion, status suppression, or text normalization. Exact app/component version tags are the only normalized fields. Every output dataclass field/property and every input dataclass public property enters the complete digest. Raw input-model inactive defaults are separately observed and hashed; native serialization intentionally omits inactive adapter fields.

The expectation file stores complete old-state digests, original native files, supplemental input specifications, baseline-derived scope-invariant digests, explicitly accepted changed-state digests, and provenance tying them to the full review. Changing any required state outside version tags fails the gate, including a change in any newly added output field.

For baseline-only verification:

```sh
python replay_legacy_compact.py --source /path/to/source0934_harness_amended --expect-baseline --output BASELINE_SELF_REPLAY.json
```

That mode requires all 156 immutable old-state hashes and does not expect the new minimum/compression diagnostics. It is not a candidate acceptance mode.

The full audit payload separately retains the immutable compressed old states, full candidate state, and every before/after changed leaf path, including all 80,191 required-state differences and all raw-model observations. Those forensic files are optional for running this compact hash gate; omitting them does not change a single expected digest or invariant. The unavailable historical external bearing oracle is explicitly unexecuted and excluded from pass counts.
