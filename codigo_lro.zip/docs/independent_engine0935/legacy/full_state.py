"""Lossless JSON-domain state capture; only exact app/component tags normalize."""
from __future__ import annotations
import dataclasses, hashlib, importlib, json, math, platform, sys
from pathlib import Path

MODULES = ['engine','double_cover','end_plate','base_plate','pinned_base_plate','w_splice','w_splice_conventional','double_angle','welded_double_angle','coped_double_angle','axial_double_angle','axial_single_angle','welded_w_splice','welded_angle_gusset','welded_double_angle_gusset','welded_opposed_angle_gusset','bolted_angle_gusset','bolted_opposed_angle_gusset','corner_gusset']
NORMALIZATION = {'app_version': 'Replace only the selected source lro.models.VERSION at an app_version field with NORMALIZED_APP_VERSION.', 'component_version': 'Replace only a recognized corner adapter version at a component_version field with NORMALIZED_CORNER_VERSION.', 'other_values': 'No other value, field, issue, status, explanation, public dataclass property, inactive model field, or output is removed, rounded, zeroed, or substituted.'}
CANONICAL_RULES = 'UTF-8; ensure_ascii=False; sorted object keys; compact separators; allow_nan=False. List/tuple order retained. Nonfinite floats retained as {nonfinite: repr(value)}. Sets sorted by canonical member encoding. Dataclass fields and all inherited public properties included.'

def encoded(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode('utf-8')

def digest(value):
    return hashlib.sha256(encoded(value)).hexdigest()

def sha_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

class Runtime:
    def __init__(self, source):
        self.source = Path(source).resolve()
        sys.dont_write_bytecode = True
        sys.path.insert(0, str(self.source))
        import numpy
        self.numpy = numpy
        from lro import models, corner_gusset
        self.models = models
        self.corner = corner_gusset
        self.app_version = models.VERSION
        self.corner_versions = {getattr(corner_gusset, key) for key in ('COMPONENT_VERSION','PREVIOUS_COMPONENT_VERSION','LEGACY_COMPONENT_VERSION') if hasattr(corner_gusset,key)}
        # This is the recorded immutable old tag, needed on replay of old native inputs.
        self.corner_versions.add('0.9.34-bolted-corner-dev')
        self.modules = {}
        self.presets = {}

    def normalize(self, value):
        if value is None or type(value) in (str, int, bool):
            return value
        if isinstance(value, float):
            return value if math.isfinite(value) else {'nonfinite': repr(value)}
        if isinstance(value, dict):
            if any(not isinstance(key, str) for key in value):
                raise TypeError('Non-string dictionary key would make canonicalization lossy')
            output = {}
            for key, item in value.items():
                if key == 'app_version' and item == self.app_version:
                    output[key] = 'NORMALIZED_APP_VERSION'
                elif key == 'component_version' and isinstance(item, str) and item in self.corner_versions:
                    output[key] = 'NORMALIZED_CORNER_VERSION'
                else:
                    output[key] = self.normalize(item)
            return output
        if isinstance(value, (list, tuple)):
            return [self.normalize(item) for item in value]
        if isinstance(value, set):
            return sorted((self.normalize(item) for item in value), key=encoded)
        if dataclasses.is_dataclass(value) and not isinstance(value, type):
            output = {field.name: self.normalize(getattr(value, field.name)) for field in dataclasses.fields(value)}
            properties = {name for cls in type(value).__mro__ for name, member in vars(cls).items() if isinstance(member, property) and not name.startswith('_')}
            for name in sorted(properties):
                try:
                    output['property:' + name] = self.normalize(getattr(value, name))
                except Exception as error:
                    output['property:' + name] = {'property_error': type(error).__name__ + ':' + str(error)}
            return output
        raise TypeError('Unsupported canonical value ' + repr(type(value)))

    def provider(self, name):
        if name not in self.modules:
            module = importlib.import_module('lro.' + name)
            self.modules[name] = module
            provider = importlib.import_module('lro.examples') if name == 'engine' else module
            self.presets[name] = provider.presets()
        return self.modules[name], self.presets[name]

    def preset_state(self, module, name, route):
        api, presets = self.provider(module)
        model = presets[name]
        return self.normalize({'module': module, 'route': route, 'name': name, 'input': model.to_dict(), 'input_model': model, 'output': api.evaluate(model)})

    def native_state(self, old_native):
        model = self.corner.CornerGusset.from_dict(old_native)
        return self.normalize({'native_input': old_native, 'native_round_trip': model.to_dict(), 'model_round_trip': model, 'output': self.corner.analyze(model)})

    def diagnostic_state(self, spec):
        _, presets = self.provider('corner_gusset')
        model = dataclasses.replace(presets[spec['base_preset']], **spec['replace'])
        return self.normalize({'module': 'corner_gusset', 'name': spec['name'], 'input': model.to_dict(), 'input_model': model, 'output': self.corner.analyze(model)})

    def provenance(self):
        paths = sorted(p for folder in ('lro','data') for p in (self.source/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc')
        files = {str(path.relative_to(self.source)): sha_file(path) for path in paths}
        return {'source': str(self.source), 'app_version': self.app_version, 'corner_component_version': self.corner.COMPONENT_VERSION, 'python': sys.version, 'python_executable': sys.executable, 'platform': platform.platform(), 'numpy': self.numpy.__version__, 'numpy_file': self.numpy.__file__, 'source_files': files, 'source_manifest_sha256': digest(files)}


def differences(before, after, path=''):
    """Every differing leaf, missing subtree, or added subtree, without truncation."""
    if type(before) is not type(after):
        return [{'path': path or '/', 'kind': 'type_or_value', 'before': before, 'after': after}]
    if isinstance(before, dict):
        result = []
        for key in sorted(set(before) | set(after)):
            child = path + '/' + key.replace('~', '~0').replace('/', '~1')
            if key not in before:
                result.extend(presence(after[key], child, 'added'))
            elif key not in after:
                result.extend(presence(before[key], child, 'removed'))
            else:
                result.extend(differences(before[key], after[key], child))
        return result
    if isinstance(before, list):
        result = []
        if len(before) != len(after):
            result.append({'path': path or '/', 'kind': 'length', 'before': len(before), 'after': len(after)})
        for index in range(max(len(before), len(after))):
            child = path + '/' + str(index)
            if index >= len(before): result.extend(presence(after[index], child, 'added'))
            elif index >= len(after): result.extend(presence(before[index], child, 'removed'))
            else: result.extend(differences(before[index], after[index], child))
        return result
    return [] if encoded(before) == encoded(after) else [{'path': path or '/', 'kind': 'value', 'before': before, 'after': after}]


def presence(value, path, kind):
    """Expand all added/removed leaves so the delta has every changed field path."""
    if isinstance(value, dict) and value:
        return [item for key in sorted(value) for item in presence(value[key], path+'/'+key.replace('~','~0').replace('/','~1'), kind)]
    if isinstance(value, list) and value:
        return [item for index, child in enumerate(value) for item in presence(child, path+'/'+str(index), kind)]
    return [{'path': path, 'kind': kind, 'after' if kind == 'added' else 'before': value}]


def required_state(state):
    """Native inputs, complete output, and every input dataclass public property.

    Raw input dataclass fields are supplementary observations because native
    adapters deliberately exclude fields inactive for the selected topology.
    All of them remain in the forensic archive and a separate observation hash.
    """
    output = {key:value for key,value in state.items() if key not in ('input_model','model_round_trip')}
    model = state.get('input_model', state.get('model_round_trip', {}))
    output['input_dataclass_public_properties'] = {key:value for key,value in model.items() if key.startswith('property:')}
    return output


def model_observation(state):
    return state.get('input_model', state.get('model_round_trip', {}))
