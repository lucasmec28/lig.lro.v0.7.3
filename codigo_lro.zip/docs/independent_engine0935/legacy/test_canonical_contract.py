"""Portable canonicalization/delta contract tests; imports no application source."""
import dataclasses, json, math, unittest
from full_state import Runtime, differences, digest, required_state, model_observation

class CanonicalContract(unittest.TestCase):
    def setUp(self):
        self.runtime = Runtime.__new__(Runtime)
        self.runtime.app_version = '0.9.34'
        self.runtime.corner_versions = {'0.9.34-bolted-corner-dev'}

    def test_only_exact_version_fields_normalize(self):
        before = {'app_version':'0.9.34', 'component_version':'0.9.34-bolted-corner-dev','explanation':'0.9.34','status':'failed','issues':[{'code':'compression'}],'ratio':0.9999999999999}
        actual = self.runtime.normalize(before)
        self.assertEqual(actual['app_version'],'NORMALIZED_APP_VERSION')
        self.assertEqual(actual['component_version'],'NORMALIZED_CORNER_VERSION')
        for key in ('explanation','status','issues','ratio'): self.assertEqual(actual[key],before[key])
        self.assertEqual(self.runtime.normalize({'app_version':'unrecognized'}), {'app_version':'unrecognized'})

    def test_dataclass_fields_and_inherited_public_properties(self):
        class Parent:
            @property
            def inherited(self): return self.value + 1
        @dataclasses.dataclass
        class Child(Parent):
            value: float = 3.0
            @property
            def fail(self): raise ValueError('record this failure')
        self.assertEqual(self.runtime.normalize(Child()), {'value':3.0,'property:inherited':4.0,'property:fail':{'property_error':'ValueError:record this failure'}})

    def test_nonfinite_values_remain_distinct(self):
        self.assertEqual(self.runtime.normalize([float('inf'),float('-inf'),float('nan')]),[{'nonfinite':'inf'},{'nonfinite':'-inf'},{'nonfinite':'nan'}])

    def test_added_removed_subtrees_include_every_leaf(self):
        delta=differences({'removed':{'x':[1,2]}},{'added':{'a/b':3,'c~d':[]}})
        self.assertEqual({item['path'] for item in delta},{'/removed/x/0','/removed/x/1','/added/a~1b','/added/c~0d'})

    def test_type_order_and_signed_zero_not_hidden(self):
        for before,after in [(1,1.0),(False,0),(-0.0,0.0),([1,2],[2,1])]:
            self.assertNotEqual(digest(before),digest(after))
            self.assertTrue(differences(before,after))
        self.assertEqual(digest({'a':1,'b':2}),digest({'b':2,'a':1}))
        self.assertFalse(differences({'a':1,'b':2},{'b':2,'a':1}))

    def test_inactive_model_fields_remain_separate_not_normalized(self):
        state={'input':{'active':1},'input_model':{'active':1,'inactive':2,'property:public':3},'output':{'checks':[4]}}
        self.assertEqual(required_state(state),{'input':{'active':1},'output':{'checks':[4]},'input_dataclass_public_properties':{'property:public':3}})
        self.assertEqual(model_observation(state)['inactive'],2)

if __name__=='__main__': unittest.main(verbosity=2)
