"""Independent 0.9.35 reference arithmetic, with no production imports.

Sources: locked method contract, physical fixture, published angle catalog.
Root forces are solved from four free-body equations instead of copying UFM
assignments. Column extremes use an independently interpolated quadratic.
"""
import math
import json
from pathlib import Path
from copy import deepcopy

HERE = Path(__file__).resolve().parent
FIXTURE = json.loads((HERE / 'FIXTURE_INPUT.json').read_text())
ANGLES = {x['id']: x['normalized_numeric'] for x in json.loads((HERE / 'ANGLE_CATALOG_INPUT.json').read_text())['rows']}
STEEL = {'ASTM A36': (250., 400.), 'ASTM A572 Gr.50': (345., 450.), 'ASTM A572 Gr.42': (290., 415.)}

def cross(p, f):
    return p[0]*f[1] - p[1]*f[0]

def solve(a, rhs):
    a = [list(map(float, row))+[float(b)] for row, b in zip(a, rhs)]
    for j in range(len(a)):
        pivot = max(range(j, len(a)), key=lambda i: abs(a[i][j]))
        a[j], a[pivot] = a[pivot], a[j]
        den = a[j][j]
        a[j] = [v/den for v in a[j]]
        for i in range(len(a)):
            if i != j:
                fac = a[i][j]
                a[i] = [v-fac*w for v, w in zip(a[i], a[j])]
    return [row[-1] for row in a]

def curve(area, fy, elastic, length, radius, gamma):
    slender = length/radius
    lam = slender*math.sqrt(fy/elastic)/math.pi
    chi = .658**(lam*lam) if lam <= 1.5 else .877/(lam*lam)
    resistance = min(1., chi)*area*fy/gamma
    return dict(A=area, r=radius, Le=length, slenderness=slender, lambda0=lam,
                chi=chi, R=resistance, recommended_200=slender <= 200.)

def derive(changes=None):
    p = dict(P=-100000., phi_deg=45., plate_width=600., plate_height=600., plate_t=12.,
             corner_clip=30., beam_seam_start_margin=10., beam_seam_end_margin=10.,
             column_seam_start_margin=10., column_seam_end_margin=10., root_weld_leg=6.,
             brace_weld_start=650., brace_weld_length=220., brace_weld_leg=5.,
             brace_free_end_extension=20., angle_profile='GERDAU_EQUAL_ANGLE_P03_R30',
             angle_steel='ASTM A36', gusset_steel='ASTM A36', beam_steel='ASTM A572 Gr.50',
             column_steel='ASTM A572 Gr.50', E=200000., gamma_a1=1.1, gamma_a2=1.35,
             gamma_w2=1.35, fw_brace=485., fw_root=485., workpoint_offset=0.,
             beam_cut_x=1000., beam_cut_y=0., beam_cut_Fx=-30710.67811865475,
             beam_cut_Fy=-50000., beam_cut_M=62300000., upper_column_cut_x=0.,
             upper_column_cut_y=1000., upper_column_cut_Fx=10000.,
             upper_column_cut_Fy=-500000., upper_column_cut_M=10000000.,
             lower_column_cut_x=0., lower_column_cut_y=-1000.)
    p.update(changes or {})
    b, col = FIXTURE['catalog']['beam'], FIXTURE['catalog']['column']
    a = ANGLES[p['angle_profile']]
    ab, at, ag, ac = [a[k] for k in ('leg_mm', 'thickness_mm', 'Ag_mm2', 'centroid_x_mm')]
    c, s = math.cos(math.radians(p['phi_deg'])), math.sin(math.radians(p['phi_deg']))
    ec, eb = col['d']/2, b['d']/2
    beam = [[ec+p['corner_clip']+p['beam_seam_start_margin'], eb],
            [ec+p['plate_width']-p['beam_seam_end_margin'], eb]]
    column = [[ec, eb+p['corner_clip']+p['column_seam_start_margin']],
              [ec, eb+p['plate_height']-p['column_seam_end_margin']]]
    bm = [sum(q[i] for q in beam)/2 for i in (0, 1)]
    cm = [sum(q[i] for q in column)/2 for i in (0, 1)]
    j = [ec, 0.]
    def xy(u, v): return [u*c-v*s, u*s+v*c]
    raw = [-ac-p['brace_weld_length']/math.sqrt(3), ab-ac+p['brace_weld_length']/math.sqrt(3)]
    h = min(-raw[0], raw[1])
    width = 2*h
    vstar = eb*c-ec*s
    def length(v):
        x, y = xy(p['brace_weld_start'], v)
        return max(0., min((x-ec)/c, (y-eb)/s))
    stations = [-h, 0., h]+([vstar] if -h <= vstar <= h else [])
    lengths = [length(v) for v in stations]
    fy, fu = STEEL[p['gusset_steel']]
    cg = curve(width*p['plate_t'], fy, p['E'], max(lengths), p['plate_t']/math.sqrt(12), p['gamma_a1'])
    cg.update(b=width, raw=raw, centered=[-h, h], length_stations=list(zip(stations, lengths)),
              average3=sum(lengths[:3])/3, utilization=abs(p['P'])/cg['R'])
    projections=[]
    for v in [-h, h]:
        x,y=xy(p['brace_weld_start'],v)
        projections.append(dict(v=v,beam_foot=[x,eb],column_foot=[ec,y],
                                beam_inside=beam[0][0]<=x<=beam[1][0],
                                column_inside=column[0][1]<=y<=column[1][1]))
    cg['root_projections']=projections
    # Four unknown root forces, two global balances and two moment balances.
    fb = [p['P']*c, p['P']*s]
    matrix = [[1,0,1,0],[0,1,0,1],[-(bm[1]-j[1]),bm[0]-j[0],0,0],
              [-bm[1],bm[0],-cm[1],cm[0]]]
    hb,vb,hc,vc = solve(matrix, fb+[0.,0.])
    d = [p['beam_cut_x'],p['beam_cut_y']]
    df = [p['beam_cut_Fx'],p['beam_cut_Fy']]
    u = [p['upper_column_cut_x'],p['upper_column_cut_y']]
    uf = [p['upper_column_cut_Fx'],p['upper_column_cut_Fy']]
    lo = [p['lower_column_cut_x'],p['lower_column_cut_y']]
    jf = [df[0]+hb,df[1]+vb]
    jm = p['beam_cut_M']+cross([d[i]-j[i] for i in (0,1)],df)+cross([bm[i]-j[i] for i in (0,1)],[hb,vb])
    lf = [-df[0]-uf[0]-fb[0],-df[1]-uf[1]-fb[1]]
    lm = -(p['beam_cut_M']+cross(d,df)+p['upper_column_cut_M']+cross(u,uf)+cross(lo,lf))
    af, aw = b['bf']*b['tf'],(b['d']-2*b['tf'])*b['tw']
    h0 = b['d']-b['tf']
    nw = jf[0]*aw/(2*af+aw)
    ft = jf[0]*af/(2*af+aw)-jm/h0
    fbot = jf[0]*af/(2*af+aw)+jm/h0
    qt, qb = -(uf[0]+hc+ft), -(uf[0]+hc+ft+nw)
    def field(y, side):
        fx, fy, mm=uf[0],uf[1],p['upper_column_cut_M']+cross([u[0],u[1]-y],uf)
        for level,f in [(h0/2,ft),(-h0/2,fbot)]:
            if level>y or level==y and side=='below':fx+=f;mm-=f*(level-y)
        for ya,yb,f in [(column[0][1],column[1][1],[hc,vc]),(-110.,110.,[nw,jf[1]])]:
            if y>=yb:continue
            yl=max(y,ya); frac=(yb-yl)/(yb-ya); part=[v*frac for v in f]
            fx+=part[0];fy+=part[1];mm+=cross([ec,(yb+yl)/2-y],part)
        return [-fx,-fy,-mm]
    ys=sorted({lo[1],u[1],h0/2,-h0/2,-110.,110.,column[0][1],column[1][1]})
    values=[]
    for yl,yh in zip(ys,ys[1:]):
        mid=(yl+yh)/2;half=(yh-yl)/2
        left,center,right=field(yl,'above'),field(mid,'above'),field(yh,'below')
        qa=(left[2]+right[2])/2-center[2];qq=(right[2]-left[2])/2
        values += [left,right]
        if abs(qa)>1e-8 and -1<-qq/(2*qa)<1:values.append(field(mid-half*qq/(2*qa),'above'))
    nmax=max(abs(lf[1]),abs(uf[1]),*[abs(v[1]) for v in values])
    mmax=max(abs(lm),abs(p['upper_column_cut_M']),*[abs(v[2]) for v in values])
    base=nmax/col['Ag']+mmax/col['Wx']
    cp=FIXTURE['geometry']['continuity']
    lw=cp['effective_web_weld_x'][1]-cp['effective_web_weld_x'][0]
    eccentricity=sum(cp['effective_flange_weld_z_each_positive'])/2-col['tw']/2
    ptau=max(abs(qt),abs(qb))/(col['d']*col['tw'])
    receiver={}
    for label, force in [('top',ft),('bottom',fbot)]:
        normal=3*abs(force)*eccentricity/(lw*lw*2*cp['web_fillet_leg'])
        shear=abs(force)/(lw*min(col['tw'],4*cp['web_fillet_leg']))
        bound=base+normal+math.sqrt(3)*(shear+ptau)
        resistance=STEEL[p['column_steel']][0]/p['gamma_a1']
        receiver[label]=dict(demand=bound,resistance=resistance,utilization=bound/resistance,
                             baseline_normal=base,panel_tau=ptau,local_normal=normal,local_shear=shear)
    roots={}
    for name,seam,n,sh,mem,steel,interior in [('beam',beam,vb,hb,b,p['beam_steel'],False),('column',column,hc,vc,col,p['column_steel'],True)]:
        length_root=math.dist(*seam);ratio=length_root/mem['d']
        mult=3*ratio if interior or ratio<=.2 else 4*ratio-.2
        crip=(.66 if interior else .33)*mem['tw']**2*(1+mult*(mem['tw']/mem['tf'])**1.5)*math.sqrt(p['E']*STEEL[steel][0]*mem['tf']/mem['tw'])/p['gamma_a1']
        roots[name]=dict(N=n,S=sh,L=length_root,weld_demand=1.25*math.hypot(n,sh)/length_root,
                         weld_resistance=2*p['root_weld_leg']/math.sqrt(2)*.6*p['fw_root']/p['gamma_w2'],crippling_R=crip)
    ay,au=STEEL[p['angle_steel']]
    weld_R=p['brace_weld_leg']/math.sqrt(2)*.6*p['fw_brace']*p['brace_weld_length']/p['gamma_w2']
    # One ordinary longitudinal cut over the uniformly captured run gives
    # the conservative partial-block shear bound, with gamma_a2 and no
    # transverse tension credit. The common gusset receives total P once.
    shear_g=.6*fy*p['plate_t']*p['brace_weld_length']/p['gamma_a2']
    shear_a=.6*ay*at*p['brace_weld_length']/p['gamma_a2']
    return dict(changes=changes or {},compression=cg,forces=dict(H=fb[0],V=fb[1],Hb=hb,Vb=vb,Hc=hc,Vc=vc),
                J=jf+[jm],lower=lf+[lm],Ftop=ft,Fbottom=fbot,Nweb=nw,panel=[qt,qb],
                max_N=nmax,max_M=mmax,receiver=receiver,roots=roots,
                angle=dict(b_over_t=ab/at,limit=.45*math.sqrt(p['E']/ay),gross_R=ag*ay/p['gamma_a1'],
                           demand=abs(p['P'])/2,shear_R=shear_a),
                brace_weld=dict(heel_signed=p['P']/2*(1-ac/ab),toe_signed=p['P']/2*ac/ab,R=weld_R),
                gusset_shear_R=shear_g,
                residual=[df[0]+uf[0]+lf[0]+fb[0],df[1]+uf[1]+lf[1]+fb[1],
                          p['beam_cut_M']+cross(d,df)+p['upper_column_cut_M']+cross(u,uf)+lm+cross(lo,lf)])

CASES=[
    ('CC1',{}),('CC2',{'P':-50000.}),('CC3',{'plate_t':6.}),
    ('minimum_actual',{'P':-20000.}),('minimum_synthetic',{'P':-45000.}),
    ('zero_actual',{'P':0.}),('zero_tensile_minimum',{'P':45000.}),
    ('phi40',{'phi_deg':40.}),('phi50',{'phi_deg':50.}),
    ('plate_thicker',{'plate_t':16.}),('gusset_steel345',{'gusset_steel':'ASTM A572 Gr.50'}),
    ('angle_steel345',{'angle_steel':'ASTM A572 Gr.50'}),
    ('angle_wider',{'angle_profile':'GERDAU_EQUAL_ANGLE_P03_R34'}),
    ('angle_slender',{'angle_profile':'GERDAU_EQUAL_ANGLE_P03_R28'}),
    ('weld_start600',{'brace_weld_start':600.}),('weld_start700',{'brace_weld_start':700.}),
    ('weld_length180',{'brace_weld_length':180.}),('weld_length260',{'brace_weld_length':260.}),
    ('seams_shifted',{'beam_seam_start_margin':25.,'column_seam_end_margin':25.}),
    ('E180GPa',{'E':180000.}),('gamma_a1_115',{'gamma_a1':1.15}),
    ('cuts_changed',{'beam_cut_Fx':-45000.,'beam_cut_Fy':-20000.,'beam_cut_M':52000000.,
                     'upper_column_cut_Fx':-5000.,'upper_column_cut_Fy':-350000.,'upper_column_cut_M':-15000000.}),
]

if __name__=='__main__':
    import hashlib
    expected={'provenance':'Independent arithmetic; no production imports; never runtime resistance data.',
              'cases':[dict(name=name,**derive(ch)) for name,ch in CASES]}
    (HERE/'EXPECTED_PARAMETERIZED.json').write_text(json.dumps(expected,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'cases':len(CASES),'CC1':expected['cases'][0]},indent=2))
