"""Independent physical body cut: polygon intersections + retained line loads.

This is a sampled/bracketed numerical cross-check of the implementation's exact
rational extrema, not a replacement runtime model. No production imports.
"""
import math
from independent_model import derive, ANGLES

def body(changes=None):
    p=dict(P=-100000.,phi_deg=45.,plate_width=600.,plate_height=600.,plate_t=12.,corner_clip=30.,
           beam_seam_start_margin=10.,beam_seam_end_margin=10.,column_seam_start_margin=10.,column_seam_end_margin=10.,
           brace_weld_start=650.,brace_weld_length=220.,angle_profile='GERDAU_EQUAL_ANGLE_P03_R30')
    p.update(changes or {});r=derive(changes)
    c,s=math.cos(math.radians(p['phi_deg'])),math.sin(math.radians(p['phi_deg']))
    def uv(x,y):return (x*c+y*s,-x*s+y*c)
    ec,eb=154.,158.5
    polygon=[uv(x,y) for x,y in [(ec+p['corner_clip'],eb),(ec+p['plate_width'],eb),(ec+p['plate_width'],eb+p['plate_height']),
                                  (ec,eb+p['plate_height']),(ec,eb+p['corner_clip'])]]
    a=ANGLES[p['angle_profile']];u0=p['brace_weld_start'];u1=u0+p['brace_weld_length']
    vheel=-a['centroid_x_mm'];vtoe=a['leg_mm']-a['centroid_x_mm']
    lines=[((u0,vheel),(u1,vheel),p['P']*(1-a['centroid_x_mm']/a['leg_mm']),0.),
           ((u0,vtoe),(u1,vtoe),p['P']*a['centroid_x_mm']/a['leg_mm'],0.)]
    for name,points in [('beam',[(ec+p['corner_clip']+p['beam_seam_start_margin'],eb),(ec+p['plate_width']-p['beam_seam_end_margin'],eb)]),
                        ('column',[(ec,eb+p['corner_clip']+p['column_seam_start_margin']),(ec,eb+p['plate_height']-p['column_seam_end_margin'])])]:
        fx,fy=(-r['forces']['Hb'],-r['forces']['Vb']) if name=='beam' else (-r['forces']['Hc'],-r['forces']['Vc'])
        lines.append((uv(*points[0]),uv(*points[1]),fx*c+fy*s,-fx*s+fy*c))
    end=max(u1,*[v[0] for line in lines for v in line[:2]])
    stations=sorted({u0,end}|{u for u,v in polygon if u0<u<end}|{q[0] for line in lines for q in line[:2] if u0<q[0]<end})
    def at(u,edge):
        cuts=[]
        for (xa,ya),(xb,yb) in zip(polygon,polygon[1:]+polygon[:1]):
            if abs(xb-xa)<1e-12:
                if abs(u-xa)<1e-8:cuts.extend([ya,yb])
            elif min(xa,xb)-1e-9<=u<=max(xa,xb)+1e-9:cuts.append(ya+(u-xa)*(yb-ya)/(xb-xa))
        low,high=min(cuts),max(cuts);width=high-low;centroid=(low+high)/2
        n=vs=m=0.
        for pa,pb,N,V in lines:
            a,b=sorted([pa,pb]);ua,ub=a[0],b[0]
            if u>=ub:continue
            cut=max(u,ua);fraction=(ub-cut)/(ub-ua)
            midu=(cut+ub)/2;midv=a[1]+(midu-ua)*(b[1]-a[1])/(ub-ua)
            nn,vv=fraction*N,fraction*V;n+=nn;vs+=vv;m+=(midu-u)*vv-(midv-centroid)*nn
        sigma=n/(p['plate_t']*width)+edge*6*m/(p['plate_t']*width**2)
        vm=math.sqrt(sigma*sigma+3*(1.5*vs/(p['plate_t']*width))**2)
        return dict(N=n,V=vs,M=m,b=width,centroid_v=centroid,sigma=sigma,VM=vm)
    def maximum(key,absolute=False):
        best=(-math.inf,None,None)
        def val(u,e):
            z=at(u,e)[key];return abs(z) if absolute else z
        for lo,hi in zip(stations,stations[1:]):
            for edge in [-1,1]:
                samples=[lo+(hi-lo)*i/1000 for i in range(1001)]
                values=[val(u,edge) for u in samples]
                candidates=[(values[0],samples[0]),(values[-1],samples[-1])]
                for i in range(1,1000):
                    if values[i]>=values[i-1] and values[i]>=values[i+1]:
                        a,b=samples[i-1],samples[i+1];ratio=(math.sqrt(5)-1)/2
                        x=b-ratio*(b-a);y=a+ratio*(b-a);fx,fy=val(x,edge),val(y,edge)
                        for _ in range(75):
                            if fx<fy:a=x;x=y;fx=fy;y=a+ratio*(b-a);fy=val(y,edge)
                            else:b=y;y=x;fy=fx;x=b-ratio*(b-a);fx=val(x,edge)
                        u=(a+b)/2;candidates.append((val(u,edge),u))
                for v,u in candidates:
                    if v>best[0]:best=(v,u,edge)
        return dict(value=best[0],u=best[1],edge=best[2],state=at(best[1],best[2]))
    return dict(stations=stations,at=at,maximum=maximum)
