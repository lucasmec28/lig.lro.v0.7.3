# Static compression of the ordinary two-root strong-axis corner

12 October 2026. Bounded method qualification, not production implementation or structural approval.

## Decision

**GO to implement and independently test a first compression branch for the existing symmetric, continuously welded 2L-T corner.** A finite published conventional method is available. No additional book, generic FEA, pointwise weld/contact continuum, or global brace redesign is needed to implement this local branch.

The proposed branch uses DG29 Appendix C's equivalent-column method, deliberately declines both compact-corner yielding-only credit and automatic K=0.5, and applies the NBR compression curve to a conservative centered Whitmore stripe. Existing signed full-joint, receiver, continuity and panel checks remain active.

The unchanged C1 specimen at P=−100 kN passes the proposed gusset buckling check but **fails the existing concurrent top continuity/column receiver screen, η=1.018850579**. This is a real fixture failure and must remain visible. CC2 is one predeclared lower-force case, P=−50 kN with the same explicitly retained complete cuts; its common receiver screen is η=0.848249209. CC3 is one adverse t=6 mm sensitivity at P=−100 kN: gusset buckling η=2.178748408. Neither variant rewrites or rescues CC1.

Bolted compression is **not an end-to-end GO in this pass**. Its finite remaining implementation qualification is stated below, with reversed-bearing and inner-clip block witnesses. No new source request is the blocker. 1L compression, arbitrary eccentric/spatial loading, extended seismic hinges, weak-axis internal-fin connections, one-root gussets, fatigue and global brace/member stability remain outside this decision.

## 1. Sources and controlled interpretation

1. Supplied AISC DG29, Example 5.1, printed pp.43–51 / PDF pp.51–59, establishes the strong-axis two-root corner and gives a worked compression check on p.51. It uses K=0.50 and explicitly requires support on both edges. L=9.76 in, t=1 in, KL/r=16.9. Its printed compression Ag=20.9 in² gives 940.5 kips rounded to941; the preceding tensile Whitmore calculation instead gives21.5 in². Preserve that unexplained source discrepancy, rather than calibrating a geometry routine to it.
2. DG29 Appendix C.1, printed pp.374–376 / PDF pp.382–384, Figures C-1–C-4 and Table C-1, supplies the selected ordinary corner model. Compactness can justify yielding-only; noncompact corners use K=1.0 with the mean of three brace-parallel lengths. This contract deliberately uses a greater length and no compactness exemption.
3. The official source of that model is Dowswell, Engineering Journal43(2),2006: https://ej.aisc.org/index.php/engj/article/download/877/876 . This is a semi-empirical conventional design model, not a literal prismatic strip cut free from its surrounding gusset.
4. Corrected supplied NBR8800:2024/Errata1:2025:6.5.1 locally affected connection parts;6.5.4 compression;5.3.2–5.3.4 compression reduction and effective area; Table4 local angle slenderness;6.1.8.2 static angle-end idealization;6.1.11.1 reversible-stress fastening;6.3.3 bearing/shear;6.5.5/6.5.6 shear and block paths. PDF67–69/printed45–47, PDF93/printed71 and PDF116–117/printed94–95 were inspected.
5. Supplied Souza supports general compression and connection mechanics but refers to the older NBR2008 Q-factor formulation. Do not replace the corrected NBR2024 Aef formulation with that older expression.

Important source transcription: supplied NBR6.5.4(b), PDF117, visibly prints Le/r≤25 for the instability branch, as does(a) for yielding. This is internally anomalous. This contract does not exploit the ambiguity or assert a repaired normative inequality: it computes the full5.3 reduction for every positive effective length, including short lengths, always bounded by gross yielding. No yielding-only shortcut at25 is used.

## 2. First physical domain and essential inputs

Same topology as the accepted welded corner: one planar gusset, two adjoining welded roots to the beam flange and strong-axis column exterior flange, welded beam-to-column joint, and the existing continuity-plate arrangement. Two identical angles are attached symmetrically, one per gusset face, by continuous longitudinal heel/toe welds. No spacer, deliberate out-of-plane offset, independent brace V/M/T, or work-point offset.

All geometric and material data already exist in the native family:

- Actual gusset polygon/thickness, inner relief and effective root weld endpoints
- Beam/column faces and real receiving sections, independent steels, continuity/CJP detail
- Brace direction, nominal force line, weld start/end, actual free end, angle identity/Ag/centroid/b/t and all physical weld sizes
- Signed total brace P, identified complete concurrent D/U cuts, explicit other loads or their exclusion, and derived L cut

Add only physical restraint information needed by the compression model, with a source/detail description:

- Beam-side attachment actually restrains gusset out-of-plane motion/rotation through the connected beam/frame detail
- Column-side attachment actually provides the assumed out-of-plane restraint
- The symmetric attached brace end/overlap has the out-of-plane restraint assumed by the equivalent-column model; it is not a free sidesway tip or intentionally flexible seismic hinge

These may be three explicit statuses under one “compression restraint detail” group. Unknown or absent restraint produces that specific unverified component. A checkbox cannot create a physical restraint. The existing lateral_restraint boolean only supports the receiver-web sidesway exception and does not establish all three conditions. Numeric rotational springs and a fresh FEA are not mandatory for the qualified conventional detail.

For this first branch, keep the ordinary rectangular outer-edge corner. Require the compression stripe and brace footprint to lie within the actual plate, and the perpendicular projections of the full selected stripe onto both roots to fall within their actual effective weld segments. Root relief must not interrupt these orthogonal plate/restraint paths. The nominal-face length projection across the ordinary corner relief is a declared idealization; the clip itself is never supported. DG29 supplies no universal maximum clip dimension. An enlarged cut, interrupted/remote root, or intentional hinge that no longer matches this restraint model needs its specific boundary qualification, not a silently larger K.

The ordinary-detail declaration must identify the current actual relief and root layout, not be a blanket “small clip” checkbox. Projection tests are necessary, not a universal proof of restraint. Bind its validity to the restraint-relevant geometry/topology; importing or changing that geometry cannot silently inherit approval of a previous detail. The declared CC1 geometry is the numerical qualification witness. Other ordinary details may use this same conventional model with their own explicit boundary-model declaration; there is no invented universal30mm code limit and no automatic permission for arbitrary enlarged notches.

Retain exact physical validation rather than fixture-only width/angle limits. In the initial direct-compression branch require the selected UFM root-force components to have the direct load-flow sign (component/P≥0 within tolerance), positive effective root lengths, zero real work-point offset and no independent gusset couple. A mixed-sign root field is identified for separate review, not reclassified as a plate-strength failure or silently forced into this model.

No brace unbraced member length, opposite-end connection, stitch spacing outside the gusset, global member effective length, or Robot buckling certificate is needed to calculate this local connection. State separately that global brace/member/frame stability is outside the output; do not imply the local PASS verifies it. The structural designer remains responsible for those member checks and the supplied axial force/restraint assumptions.

## 3. Finite gusset compression calculation

Use u=(cosφ,sinφ), v=(−sinφ,cosφ), with signed P<0 compression. Keep P signed for equilibrium and use C=−P only for positive demand magnitudes.

### Whitmore stripe

At the support-side end of load transfer u0, use the existing30-degree envelope from the farther weld end. For welded2L, v_left=v_heel−Lw tan30°, v_right=v_toe+Lw tan30°. The force axis is v0=0 in this bounded branch. Select h=min(v0−v_left,v_right−v0) and the centered stripe[v0−h,v0+h]; intersect/check the real plate. Use bw=2h and A=bw tg. This deliberately discards asymmetric excess width and applies the FULL C to the retained stripe. It does not move the actual brace force or claim the discarded plate carries no stress. DG29 printedp.209 provides analogous symmetric width reduction as a geometry precedent; its weak-axis receiver is not adopted.

No supported-member continuation is counted. A noncontained stripe or a stripe crossing an unqualified receiver interface retains its specific geometry issue. No net-tension shear-lag Ct enters compression. The virtual Whitmore side lines are not physical free plate edges; do not impose an AL local-plate width limit on bw/tg as if that fictitious strip were cut out of the plate.

### Effective length and reduction

Let the nominal beam face be y=eb and column face x=ec. For a point(u0,v) of the retained stripe:

u_beam(v)=(eb−v cosφ)/sinφ
u_column(v)=(ec+v sinφ)/cosφ
l(v)=max[0,u0−max(u_beam,u_column)].

Evaluate the stripe endpoints and the face-switch station v*=eb cosφ−ec sinφ if it lies inside the interval. Because these expressions are affine between the switch, this gives the exact maximum Lmax of the nominal-face projection over the retained stripe. Also report l1/l2/l3 and their average so the conventional source is traceable.

Use Le=1.0·Lmax. This is a conservative enlargement of DG29's K1·lavg for the noncompact-corner model; it is an explicit implementation choice, not a verbatim source equation. Use the start of actual force transfer rather than any unconnected angle-tip extension as u0, increasing length conservatively. This is not a substitute for real restraint.

r=tg/√12; Ne=π²EA/[(Le/r)²]; λ0=√(Afy/Ne).
χ=0.658^(λ0²) forλ0≤1.5; otherwiseχ=0.877/λ0².
Nc,Rd=χ A fy/γa1, bounded byAfy/γa1. The equivalent width/effective-column model is the DG29 gusset model; NBR supplies the compression curve and design factor. No LRFDφ multiplies an NBRγ resistance. AtLe=0, defineχ=1 by continuity but preserve the physical scope checks.

This single conventional plate-stability check supplies the missing ordinary-corner compression mode. Keep root combined normal/shear yielding, actual body-section yielding and all receiver/continuity/panel checks. Do not retain the former blanket “any negative gusset stress is unqualified” when the compressed region belongs to this qualified direct axial corner model. Negative stress from an independent unmodeled couple or outside this restraint domain remains specific and unverified.

NBR5.3.7 recommends slenderness not exceeding200, and provides for project-responsible service-behavior limits above it. Report Le/r explicitly. The initial automatic branch may conservatively require Le/r≤200; above it, retain computed resistance/failure diagnostics and identify the missing service-behavior qualification. Do not label200 an unconditional code prohibition. This connection's chosen effective-length ratio is the model diagnostic; no global brace slenderness is inferred.

## 4. Welded brace-end and signed common-joint changes

Each physical L receivesP/2; heel/toe share remains based on its actual catalog centroid. The four weld force vectors reverse withP. NBR nondirectional weld shear and local substrate shear use the same magnitudes/capacities. The central gusset is counted once.

For the locally connected angle portion:

- Check each angle's local gross compression C/2≤Ag fy/γa1
- Require the conservative Table4AL3 b/t≤0.45√(E/fy); use full published b so unknown rolled radii do not create favorable credit
- Continuous heel/toe welds provide the connected-leg attachment; no disconnected interval or free stand-off is accepted
- Keep shear/substrate checks and the conservative uniform-weld-run shear-only envelope, with no transverse tensile capacity credit. For any captured force fraction, at least one ordinary longitudinal cut spans the captured uniformly loaded weld length. Apply the shared gusset totalP once. This is a direction-independent conservative shear envelope, not a statement that a tension end-block opens in compression.

Do not label Ct·Ag·fu/γa2 a compression resistance. Tension net rupture and the angle's support-side free-tip tension block are inactive for a purely compressive case. Reversed shared-gusset crack candidates, if displayed, must be evaluated toward their actual loaded free exits; an old outward tear path withabs(P) is not a physical compression-path result. The shear-only uniform-run bound may remain as the conservative first-branch envelope; unsupported/retained-contact “no detached block” is an inactive mechanism, not by itself an unresolved connection.

Retain generalized UFM with signedP:
H=Pcosφ; V=Psinφ; Hc=ecV/(eb+β); Hb=H−Hc; Vb=ebHb/α; Vc=V−Vb.

The actual root tractions are signed. Both root weld resultant magnitudes remain valid. Compression activates receiving-web crippling and the existing receiving-web sidesway/restraint conditions; tension-only flange local bending/normal rupture are activated by positive normal traction, notabs(normal). Avoid retaining a “tension rupture” row under negative normal merely because the common check helper takesabsolutevalues. Normal/shear material yielding and shear rupture remain appropriate in either direction. Similar sign filtering is needed at the direct web-joint normal-rupture rows; local tensile surfaces produced by bending remain checked.

Recompute J, lower cutL, flange signs, continuity plate actions, receiver unions, local member cuts and panel from the same complete concurrent case. Do not just reverse the gusset and reuse the tension joint demand. Retain the union of overlapping receiver footprints and one shared receiving web. All required real compressive modes remain active even if another check fails.

For0<|Pactual|<45kN, retain actualP and complete cuts unchanged, then create a separate minimum-strength casePdesign=sign(Pactual)·45kN with D/U and other loads explicitly retained as background, exactly as the prior tension contract does. Recompute the full chain once before dividing physical angles. The actual zero case stays zero; retain the existing+45kN nominal tensile minimum convention atzero rather than inventing a compression sign. The synthetic lower cut is not a Robot/actual case. No50%-member-capacity recommendation is automatically applied.

Ordinary static tension/compression cases can be checked separately without claiming fatigue or seismic-cycle qualification. Welds satisfy the fastening-type requirement ofNBR6.1.11.1 for reversed stresses. This does not certify fatigue resistance or a ductile seismic hinge.

## 5. Independent fixtures and exact limits

build_fixture.py is standard-library arithmetic and imports no application module. FIXTURE_INPUT.json is qualification input, not a production-native approval. ORACLE.json is test evidence and must never be runtime resistance data. CURRENT_KERNEL_DIAGNOSTIC.json and COVERAGE_CURRENT_KERNEL_DIAGNOSTIC.json deliberately record the still-unqualified existing kernel; those are diagnostics, not completed compression results.

CC1 retains600×600×12mm gusset,30mm inner clip,550mm effective roots,45-degree diagonal, L76.2×7.94,220mm brace weld and the original explicitly supplied complete cuts. Only signedP is−100kN:

- Raw Whitmorev=[−149.117059,+181.117059]mm; retained centered width298.234118mm; A3578.809421mm²
- l1=425.847150mm; l2/l3=276.730091/283.094052mm; full-interval maximum429.029131mm atv3.181981mm
- K1; Le/r123.850042; λ0=1.393802671; χ0.443475885; Nc,Rd360.708108kN; η0.277232471
- Each-angleb/t9.59697733 < conservativeAL3 limit12.7279221; each-angle local gross compression resistance260.909091kN, demand50kN
- Signed(Hb,Vb,Hc,Vc)=(−47.712907,−24.007923,−22.997771,−46.702755)kN
- J=(−78.423586,−74.007923,+20.000000kNm); lower cut=(+91.421356,+620.710678,−103.721356kNm)
- Flanges top−91.957546kN and bottom+39.708023kN; direct web axial−26.174062kN
- Both gusset-root receiver compression branches activate. Beam/column web crippling capacities748.262523/2291.503730kN
- PanelQtop104.955317/Qbottom131.129379kN. The independent piecewise-quadratic column free-body reconstruction gives maximum|N|620.710678kN, maximum|M|103.721356kNm
- Existing concurrent top receiver bound319.548591MPa exceeds313.636364MPa: η1.018850579. Four free-body assemblies close; independent total residuals are below1e−6N/Nmm

CC2: P−50kN, same geometry AND same declared D/U cuts. Gussetη0.138616235; concurrent top receiver bound266.041797MPa,η0.848249209. Existing kernel diagnostic reports no strength-row failures, while its old compression gates necessarily remain. A future completed branch must not present this old diagnostic as already production-qualified.

CC3: P−100kN, same declared cuts, plate6mm. λ0=2.787605342; χ0.112859213; Nc,Rd45.897911kN; η2.178748408. The original receiver failure also remains. This is an adverse mechanism witness, not a proposed fabricated detail.

Its Le/r=247.700084 also exceeds the conservative automatic200 recommendation gate and therefore needs a separate service-behavior qualification. Preserve both that applicability flag and its computed strength failure; do not call this a fully qualified passing-domain case.

## 6. Bolted compression: finite next adapter work

The same plate-stability model can be reused after a separate reversed physical adapter is qualified. Neither shear-lag tension capacity nor absolute-valued old bearing/block geometry is sufficient.

ForP<0, gusset-hole force is−u and angle-hole force is+u:

- Gusset first hole: lc=u_first−actual inward ray exit−dh/2; later holes:preceding pitch−dh
- Angle interior holes:following pitch−dh; last hole loads into the continuing brace, so verify that actual continuation/nearest hole or free boundary and do not pretend the support-side angle tip is its loaded edge
- Per-plane bolt shear magnitudes are unchanged; common gusset-hole demand remains|P|/n, and each L gets|P|/(2n)
- Rebuild L/U candidates in the loaded direction against the actual polygon and supported-contact exclusions. The inner corner clip is a genuine free edge: compression does not allow every gusset block check to be switched off
- Pure compression does deactivate the previous angle free-tip tension blocks. They do not reopen merely by applyingabs(P)
- Compression needs local angle net/gross bearing and compactness/attachment checks, with no Ct rupture capacity. A local net-yield screen can be retained conservatively, separately from the conventional gross effective-column model
- If the same real bolts serve static tension/compression reversals, require high-strength pretension perNBR6.1.11.1; this provides no friction/slip resistance credit and does not establish a fatigue/seismic qualification
- Verify the built-up member's end-connection requirements without claiming global2L buckling from this local connection. NBR5.3.6.2 requires welded or pretensioned high-strength end connections for its specified built-up-member procedure; an ordinary-tight bearing-bolt tension preset must not silently become that compressive member detail

BC1 reversed-direction witness inORACLE.json: inner axis clip exitu242.184073mm; first gusset clear bearing length118.815927mm, remaining42mm. Every gusset bearing capacity136.533333kN; each angle90.339556kN under the stated continued-member geometry. An inward tangent-U candidate around the first hole, transverse legsv±9mm, hasu_cap364.6mm, Agv=Anv2937.982259mm², Ant43.2mm², R332.842473kN and conservative included-hole demand25kN,η0.075110606. Its longitudinal legs end on the real clip with zero supported-contact length.

That one path is a sign/direction oracle, not an exhaustive compression-block envelope. The outstanding finite work is a direction-aware parameterized block/bearing adapter with partial-hole and support-transition tests, plus brace-end compression attachment checks and bolt-reversal detailing. There is no missing generic reference, need for continuum reconstruction, or request to the driving user.

## 7. Finite implementation acceptance and stop

1. Reproduce the published length/slenderness benchmark without hiding its area discrepancy, then independently reproduceCC1/CC2/CC3 and the signed−20→−45kN synthetic chain.
2. Test λ0=1.5 on both sides; lengthzero; thin/thick sensitivity; material changes; loss of each restraint; root shortening/relief interference; shifted angles/positions that remain physically contained; work-point offsets; mixed-sign root fields; 1L and extended/one-root exclusions.
3. Preserve sign-aware root/receiver tension versus compression modes, lower-cut equilibrium, both flanges, continuity eccentricity, receiver unions and concurrent panel. A seeded doubled brace load must fail equilibrium. Verify actual and synthetic lower-cut labels separately.
4. Disable obsolete blanket compression gates only inside the qualified branch. Preserve specific unknown restraint, geometry or local/member method issues. A failed common receiver must not be hidden by a passing gusset check.
5. Native import/save and all report/drawing paths must preserve signedP, restraint assumptions, selected effective width/length, governing component and local-only scope. Historic tension presets must remain unchanged.
6. Perform one independent engine/output acceptance against the final implementation and applicable aggregate tests. No production file, release artifact, Library upload, deployment, or fabrication approval is part of this bounded source/fixture pass.

Stop here once the method/fixtures and bounded review are recorded. Do not broaden this qualification to a general seismic gusset solver, global2L member design, or unresolved internal-fin route.
