# Independent engine acceptance, 0.9.35

Decision: GO for the bounded static welded symmetric 2L-T corner-compression implementation. This is source-engine acceptance, not fabrication/global stability approval. UI/output, the applicable aggregate and actual APP-only extraction remain separate gates.

## Verified results

- CC1: gusset resistance 360.708108 kN, utilization 0.277232471. Common concurrent receiver conservative screen still fails at 1.018850579. Its bound failure does not prove actual material yielding.
- CC2: same declared complete background cuts, -50 kN; receiver utilization 0.848249209 and local overall PASS.
- CC3: 6 mm gusset resistance 45.897911 kN, utilization 2.178748408; common receiver failure and service-qualification pending at Le/r=247.700084 both remain visible.
- Centered Whitmore stripe, full-strip maximum length including the interior switch, K=1, all NBR curve branches, zero-length continuity and no mixed LRFD factors were independently reconstructed.
- Signed roots, weld vectors, J/lower cuts, flanges, shared receiving unions and panel agree. Small real tensile body stresses at phi35/55 remain checked; pure compression rupture mechanisms are inactive. A doubled-brace mutation triggers equilibrium rejection.
- Every restraint and geometry-bound stale import is checked. Unknown/absent/blank declarations retain strength diagnostics. Malformed input/native types remain invalid. Bolted and 1L compression remain outside qualification.
- Signed minimum force is applied once to the total brace and then split physically. Actual actions/cuts and explicit additional member loads are retained; the synthetic lower cut is separately labelled. At actual zero, the +45 kN tensile convention is explicit.

## Evidence counts, kept separate

- 234 independent reference comparisons
- 2,394 runtime comparisons across 22 parameter cases
- 566 adversarial observations across 134 scenarios
- 236 distinct source tests: 72 new compression, 164 inherited corner tests, four disjoint files
- 156 full-state parity rows across 19 routes: 141 exactly match the old state after version-only normalization; 15 explicitly reviewed welded minimum/negative-diagnostic changes pass 150 scoped preservation assertions

All 108 old presets and 10 old corner-native round trips are exact. The 15 changed rows are ten welded low/zero-force cases and five old negative-2L diagnostics. Full before/after differences and original states are preserved in the separate audit evidence; compact replay hashes every original native/output field, including dataclass public result properties.

The unavailable historical external bearing oracle was not searched again, reconstructed, or counted passed. These independent counts are not added to overlapping owner aggregate tests.

## Portable replay

Run from an extracted APP whose ordinary dependencies are installed:

    python docs/independent_engine0935/replay.py --source . --output /tmp/lro0935-engine-replay

The exact legacy canonical gate requires recorded NumPy 2.5.3. A dependency-version or engine-hash refusal is explicit, not hidden by broader normalization. The replay writes only to the requested output directory and never rewrites an oracle or baseline. Full forensic snapshots are not needed for the gate.

`ENGINE_ACCEPTANCE0935.json` records the exact accepted engine hashes and separate evidence counts. `PAYLOAD_MANIFEST.json` verifies the independent payload.
