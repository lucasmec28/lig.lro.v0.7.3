"""Freeze independent expectations before executing the new production kernel."""
import json, hashlib, math, sys
from pathlib import Path
from independent_model import derive, curve, CASES
H=Path(__file__).resolve().parent
O=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else H
O.mkdir(parents=True,exist_ok=True)
LOCKS={'COMPRESSION_CORNER_CONTRACT.md':'1ece7177739f6050ce7349a1eb6f27b3fe2189628296ab5b352bdf909e1bcd92',
       'FIXTURE_INPUT.json':'8baa55d87805e7331d20d04b0ea5bce7da3297e491031152707b10a896b376f4',
       'ORACLE.json':'1a70ff5a7cf6a2ecf5b0df2236443b7b099ace708206e0f9a48c9b2038b7b365'}
for file,sha in LOCKS.items():assert hashlib.sha256((H/file).read_bytes()).hexdigest()==sha,file
o=json.loads((H/'ORACLE.json').read_text());checks=[]
def eq(name,x,y):
    if isinstance(y,(tuple,list)):
        assert len(x)==len(y),name
        for i,(a,b) in enumerate(zip(x,y)):eq(name+'/'+str(i),a,b)
        return
    passed=math.isclose(x,y,rel_tol=1e-10,abs_tol=1e-6)
    checks.append(dict(id=name,actual=x,expected=y,passed=passed))
    assert passed,(name,x,y)

for name,changes,oracle in [('CC1',{},o['main_case']),('CC2',{'P':-50000.},o['declared_coverage_cases']['CC2_lower_demand']['case']),
     ('minimum_actual',{'P':-20000.},o['signed_minimum_witness']['actual']),
     ('minimum_synthetic',{'P':-45000.},o['signed_minimum_witness']['synthetic']),
     ('zero_actual',{'P':0.},o['signed_minimum_witness']['zero_actual_unchanged']),
     ('zero_positive_minimum',{'P':45000.},o['signed_minimum_witness']['zero_existing_positive_minimum'])]:
    r=derive(changes)
    for key in ['H','V','Hb','Vb','Hc','Vc']:eq(name+'/'+key,r['forces'][key],oracle[key])
    for key,target in [('J','J'),('lower','lower_cut'),('Ftop','Ftop'),('Fbottom','Fbottom'),('Nweb','Nweb')]:eq(name+'/'+key,r[key],oracle[target])
    eq(name+'/panel',r['panel'],[oracle['Qtop'],oracle['Qbottom']])
    eq(name+'/receiver',r['receiver']['top']['utilization'],oracle['concurrent_receiver']['utilization'])
    for label,root in r['roots'].items():
        for a,b in [('N','signed_normal'),('S','signed_shear'),('L','length'),('weld_demand','weld_line_demand'),('weld_resistance','weld_line_resistance'),('crippling_R','receiver_web_crippling_resistance')]:
            eq(name+'/'+label+'/'+a,root[a],oracle['roots'][label][b])
    eq(name+'/residual',r['residual'],[0.,0.,0.])
r=derive();w=o['Whitmore']
for a,b in [('b','b'),('A','A'),('r','r'),('Le','Le'),('slenderness','slenderness'),('lambda0','lambda0'),('chi','chi'),('R','Nc_Rd'),('utilization','utilization'),('raw','raw_v_range'),('centered','centered_v_range')]:eq('CC1/compression/'+a,r['compression'][a],w[b])
a=o['brace_end_local']
for k,j in [('b_over_t','angle_b_over_t'),('limit','conservative_AL3_limit'),('gross_R','per_angle_local_gross_compression_resistance'),('demand','angle_each_demand'),('shear_R','angle_uniform_partial_weld_run_shear_envelope')]:eq('CC1/angle/'+k,r['angle'][k],a[j])
eq('CC1/shared_shear',r['gusset_shear_R'],a['gusset_uniform_partial_weld_run_shear_envelope'])
for tag in ['heel','toe']:
    eq('CC1/'+tag+'_signed',r['brace_weld'][tag+'_signed'],a[tag]['signed_each_face_force'])
    eq('CC1/'+tag+'_R',r['brace_weld']['R'],a[tag]['weld_resistance_each'])
r=derive({'plate_t':6.})['compression'];w=o['declared_coverage_cases']['CC3_thinner_gusset']
for a,b in [('r','r'),('slenderness','Le_over_r'),('lambda0','lambda0'),('chi','chi'),('R','R'),('utilization','utilization')]:eq('CC3/'+a,r[a],w[b])
curve_cases=[]
for lam in [0.,1.5-1e-9,1.5,1.5+1e-9,3.]:
    length=lam*math.pi*math.sqrt(200000./250.)
    actual=curve(1000.,250.,200000.,length,1.,1.1)
    expected=(.658**(lam*lam) if lam<=1.5 else .877/(lam*lam))
    eq('curve_'+str(lam),actual['chi'],expected)
    curve_cases.append(dict(lambda0=lam,Le=length,expected_chi=expected,expected_R=expected*1000*250/1.1))
eq('published_DG29_KLr',.5*9.76/(1/math.sqrt(12)),o['published_DG29_Ex5_1_replay']['KL_over_r'])
eq('published_DG29_LRFD',.9*50*20.9,o['published_DG29_Ex5_1_replay']['LRFD_kip'])
report=dict(result='PASS',comparisons=len(checks),checks=checks,curve_cases=curve_cases,
    source_files=LOCKS,source_discrepancy='Printed DG29 compression Ag=20.9 in² is retained separately from preceding tensile Whitmore 21.5 in²; no geometry calibration.',
    counting='Independent numeric comparisons only; not source tests; candidate not executed.')
(O/'INDEPENDENT_REFERENCE_VALIDATION.json').write_text(json.dumps(report,indent=2)+'\n')
files=list(LOCKS)+['ANGLE_CATALOG_INPUT.json','EXPECTED_PARAMETERIZED.json','independent_model.py','INDEPENDENT_REFERENCE_VALIDATION.json']
(O/'PRE_RUNTIME_REFERENCE_LOCK.json').write_text(json.dumps(dict(files={f:hashlib.sha256((H/f).read_bytes()).hexdigest() for f in files}),indent=2)+'\n')
print(json.dumps(dict(result='PASS',comparisons=len(checks),physical_parameter_cases=len(CASES)),indent=2))
