"""Read-only runtime acceptance against pre-execution independent expectations."""
from pathlib import Path
from dataclasses import replace
import sys,json,math,hashlib,datetime
H=Path(__file__).resolve().parent
S=Path(sys.argv[1]).resolve();O=Path(sys.argv[2]).resolve() if len(sys.argv)>2 else H
O.mkdir(parents=True,exist_ok=True);sys.path.insert(0,str(S))
from lro.corner_gusset import CornerGusset,analyze
from lro.corner_compression import declare_current_detail,reduction
LOCK=json.loads((H/'PRE_RUNTIME_REFERENCE_LOCK.json').read_text())
for file,sha in LOCK['files'].items():assert hashlib.sha256((H/file).read_bytes()).hexdigest()==sha,('reference changed',file)
expected=json.loads((H/'EXPECTED_PARAMETERIZED.json').read_text())
reference=json.loads((H/'INDEPENDENT_REFERENCE_VALIDATION.json').read_text())
runtime_files=['lro/corner_gusset.py','lro/corner_compression.py','lro/bolted_corner.py','lro/models.py','lro/angle_catalog.py','data/profiles.json','data/gerdau_equal_angles.json']
def hashes():return {f:hashlib.sha256((S/f).read_bytes()).hexdigest() for f in runtime_files}
start_hash=hashes();rows=[];failures=[];states=[];counts={}
def compare(name,actual,want,category='numeric'):
    if isinstance(want,(tuple,list)):
        if not isinstance(actual,(tuple,list)) or len(actual)!=len(want):
            compare(name+'/array_shape',False,True,'logical');return
        for i,(a,b) in enumerate(zip(actual,want)):compare(name+'/'+str(i),a,b,category)
        return
    if type(want) in (int,float):
        passed=type(actual) in (int,float) and math.isfinite(actual) and math.isclose(actual,want,rel_tol=1e-9,abs_tol=1e-5)
    else:passed=type(actual)==type(want) and actual==want
    counts[category]=counts.get(category,0)+1
    row=dict(id=name,actual=actual,expected=want,passed=passed,category=category);rows.append(row)
    if not passed:failures.append(row)
def checks(out):return {r['id']:r for r in out['checks']}
def check_row(name,rr,id,demand=None,resistance=None,utilization=None):
    if id not in rr:compare(name+'/'+id+'/present',False,True,'logical');return
    r=rr[id]
    for k,v in [('demand',demand),('resistance',resistance),('utilization',utilization)]:
        if v is not None:compare(name+'/'+id+'/'+k,r.get(k),v)
    compare(name+'/'+id+'/source',bool(r.get('source')),True,'logical')
outputs={}
for exp in expected['cases']:
    name=exp['name'];changes=exp['changes'];c=replace(CornerGusset(),P=-100000.,**{k:v for k,v in changes.items() if k!='P'})
    if 'P' in changes:c=replace(c,P=changes['P'])
    c=declare_current_detail(c,'Independent parameter witness '+name+': ordinary connected-frame boundary declared for this exact geometry only; not fabrication approval.')
    out=analyze(c);outputs[name]=out;rr=checks(out)
    states.append(dict(name=name,status=out['status'],complete=out['complete'],issues=out['issues']))
    for k,v in exp['forces'].items():compare(name+'/forces/'+k,out['forces'].get(k),v)
    for key,target in [('joint_beam_to_column','J')]:compare(name+'/'+key,[out[key][k] for k in ['Fx','Fy','M']],exp[target])
    compare(name+'/lower',[out['complete_cuts']['column_lower'][k] for k in ['Fx','Fy','M']],exp['lower'])
    for k in ['Ftop','Fbottom','Nweb']:compare(name+'/joint_distribution/'+k,out['joint_distribution'][k],exp[k])
    compare(name+'/panel',[out['panel'][k] for k in ['Qtop','Qbottom']],exp['panel'])
    compare(name+'/column/N',out['column_sections']['maximum_compression'],exp['max_N'])
    compare(name+'/column/M',out['column_sections']['maximum_abs_moment'],exp['max_M'])
    for assembly,residual in out['equilibrium_residuals'].items():compare(name+'/residual/'+assembly,residual,[0.,0.,0.])
    for label,root in exp['roots'].items():
        for k in ['N','S','L']:compare(name+'/root/'+label+'/'+k,out['seams'][label][k],root[k])
        check_row(name,rr,label+'_root_weld',root['weld_demand'],root['weld_resistance'])
        if root['N']<0:check_row(name,rr,label+'_receiving_compression_web_crippling',abs(root['N']),root['crippling_R'])
    for label,want in exp['receiver'].items():
        check_row(name,rr,'continuity_'+label+'_concurrent_column_receiver_bound',want['demand'],want['resistance'],want['utilization'])
    for label in ['heel','toe']:
        check_row(name,rr,'brace_'+label+'_weld_each_face',abs(exp['brace_weld'][label+'_signed']),exp['brace_weld']['R'])
    if c.P<0:
        cc=out.get('compression',{})
        for actual,want in [('width','b'),('A','A'),('r','r'),('Le','Le'),('Le_over_r','slenderness'),('lambda0','lambda0'),('chi','chi'),('resistance','R'),('three_line_average','average3'),('raw_v_range','raw'),('selected_v_range','centered')]:compare(name+'/compression/'+actual,cc.get(actual),exp['compression'][want])
        compare(name+'/compression/K',cc.get('K'),1.)
        check_row(name,rr,'gusset_centered_whitmore_compression_buckling',abs(c.P),exp['compression']['R'],exp['compression']['utilization'])
        check_row(name,rr,'angle_each_local_gross_compression',abs(c.P)/2,exp['angle']['gross_R'])
        check_row(name,rr,'angle_each_compression_local_slenderness',exp['angle']['b_over_t'],exp['angle']['limit'])
        check_row(name,rr,'angle_each_uniform_run_shear_envelope',abs(c.P)/2,exp['angle']['shear_R'])
        check_row(name,rr,'gusset_uniform_run_shear_envelope',abs(c.P),exp['gusset_shear_R'])
        for root in ['beam','column']:
            compare(name+'/'+root+'/compression_active',out['seams'][root]['compression_modes'],'active','logical')
            for material in ['gusset','receiver']:
                compare(name+'/'+root+'/'+material+'/no_tension_rupture',root+'_'+material+'_root_contact_normal_rupture' not in rr,True,'logical')
        for id in ['angle_each_effective_rupture','angle_each_nominal_through_leg_block','gusset_whitmore_net_rupture_peak','gusset_whitmore_gross_peak_tension']:
            compare(name+'/'+id+'/inactive',id not in rr,True,'logical')
        for line in out['brace']['signed_weld_vectors']:
            want=exp['brace_weld'][line['id'].split('_')[0]+'_signed']
            compare(name+'/weld_vector/'+line['id']+'/force',line['force'],want)
            compare(name+'/weld_vector/'+line['id']+'/magnitude',line['magnitude'],abs(want))
        compare(name+'/no_obsolete_blanket_gate',not any(i['id'] in ['UNVERIFIED_COMPRESSION_COMPONENT','whitmore_compression','gusset_ordinary_tear_family'] for i in out['issues']),True,'logical')
    if name in ['CC1','CC2','CC3']:
        compare(name+'/status',out['status'],'PASS' if name=='CC2' else 'FAIL','logical')
    if name=='CC3':
        compare('CC3/service_pending','compression_slenderness_service' in {i['id'] for i in out['issues']},True,'logical')
        compare('CC3/receiver_fail_preserved',rr['continuity_top_concurrent_column_receiver_bound']['status'],'FAIL','logical')
        compare('CC3/buckling_fail_preserved',rr['gusset_centered_whitmore_compression_buckling']['status'],'FAIL','logical')
    print(json.dumps(dict(case=name,status=out['status'],failure_count=len(failures))),flush=True)

for case in reference['curve_cases']:
    actual=reduction(200000.,250.,1000.,math.sqrt(12),case['Le'],1.1)
    compare('curve/'+str(case['lambda0'])+'/chi',actual['chi'],case['expected_chi'],'curve_numeric')
    compare('curve/'+str(case['lambda0'])+'/resistance',actual['resistance'],case['expected_R'],'curve_numeric')
    compare('curve/'+str(case['lambda0'])+'/gross_bound',actual['resistance']<=1000*250/1.1,True,'logical')

# The force case is derived once on total P, then physically split into angles.
minimum=outputs['minimum_actual'];syn=minimum['design_cases'][0]
compare('minimum/actual_P',syn['actual_P'],-20000.)
compare('minimum/design_P',syn['design_P'],-45000.)
compare('minimum/one_synthetic',len(minimum['design_cases']),1,'logical')
compare('minimum/not_Robot',syn['robot_lower_comparison'],False,'logical')
for key in ['beam','column_upper']:compare('minimum/background/'+key,syn['result']['complete_cuts'][key]==minimum['complete_cuts'][key],True,'logical')
for key in ['H','V','Hb','Vb','Hc','Vc']:compare('minimum/full_chain/'+key,syn['result']['forces'][key],outputs['minimum_synthetic']['forces'][key])
compare('minimum/lower',syn['result']['complete_cuts']['column_lower']==outputs['minimum_synthetic']['complete_cuts']['column_lower'],True,'logical')
compare('minimum/per_angle',checks(syn['result'])['minimum45__angle_each_local_gross_compression']['demand'],22500.)
zero=outputs['zero_actual'];compare('zero/actual_H',zero['forces']['H'],0.)
compare('zero/synthetic_positive',zero['design_cases'][0]['design_P'],45000.)
compare('zero/convention_label',bool(zero['design_cases'][0]['zero_force_convention']),True,'logical')
compare('zero/no_compression_model','compression' not in zero,True,'logical')
compare('source_unchanged_during_run',hashes()==start_hash,True,'logical')
report=dict(checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),result='PASS' if not failures else 'FAIL',counts=counts,physical_cases=len(states),
            rows=rows,failures=failures,states=states,source_hashes=start_hash,
            expected_lock_sha256=hashlib.sha256((H/'PRE_RUNTIME_REFERENCE_LOCK.json').read_bytes()).hexdigest(),
            tolerance={'relative':1e-9,'absolute':1e-5},counting='Scalar numeric/logical comparisons, not source tests. No overlapping source test counts are added.',
            scope='Qualified local welded symmetric 2L-T only; receiver failure is failure of a conservative screen, not proof of actual yielding.')
(O/'RUNTIME_COMPARISON.json').write_text(json.dumps(report,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
print(json.dumps(dict(result=report['result'],counts=counts,failures=failures[:30],failure_count=len(failures)),indent=2))
sys.exit(bool(failures))
