# Revisão 0.9.64 — contato direcional da nervura interna

Base 0.9.63 preservada, incluindo correções de end plates e de duas talas anteriores. Escopo: substituir o teto isolado de contato da nervura por avaliação local direcional por furo, em uma única linha governante. Não acrescentar modelo integral de nervura, blocos internos, estabilidade, soldas ou receptores.

A distância livre é obtida entre contornos físicos por segmentos paralelos à força individual. Para furos oblíquos, a reta pelo centro não basta: transladar o círculo na direção da força encontra o primeiro contato com outro círculo ou um segmento físico. Distâncias em outras direções não reduzem a capacidade. A geometria identifica bordas livres e trechos soldados. Quando o primeiro contato ocorre em trecho soldado, a parcela de transferência fica pendente e permanece apenas o teto necessário de esmagamento.

Fonte: NBR 8800:2024 corrigida 2025, item 6.3.3.3, páginas impressas 84–85, inspecionadas no PDF original fornecido. A interpretação geométrica paralela é explicitamente declarada; a norma não oferece um algoritmo de interseção de círculos. Não se atribui resistência às soldas por essa interpretação.

Roark, 7ª edição, Tabela 11.4, caso 10, p. 513, refere-se a carregamento transversal. Tabela 15.2 contém flambagem por esforços nas bordas, sem caso verificado equivalente à placa perfurada carregada pelos parafusos internos. Nenhuma dessas tabelas foi usada para conceder resistência integral ao detalhe.

## Validação e resultado

- 282 testes de regressão passaram (duas talas, UI, geometria, forças com sinais e segurança de end plates herdada da 0.9.63).
- 4 testes adicionais passaram: igualdade entre projeto JSON, forças/resistências por furo e memória Word, para ações positivas, negativas e contato com trecho soldado.
- Revisão independente confrontou a fonte normativa e oito geometrias analíticas: borda normal e inclinada, extremidade de segmento, furos alinhados/oblíquos, tangência, reversão e solda. Casos adicionais automatizados verificam rotação, sinais e força nula.
- Inspeção visual das oito páginas de cada um dos dois memoriais, incluindo tabela por furo: sem corte, sobreposição ou perda de informação. Permanece uma quebra de página pouco compacta anterior a esta revisão.
- Preset inicial: lf = 39,391; 52,466; 117,538 mm. As três resistências permanecem em 107,527 kN; maior solicitação 22,448 kN. Nenhuma penalização por distância em outra direção foi aplicada.

O resultado do critério geométrico local não qualifica a placa integralmente. Um não atendimento que dependa somente da redução direcional recebe indicação de revisão do critério, distinguindo-se da ultrapassagem do teto necessário de contato. Outros estados-limite efetivamente não atendidos mantêm sua classificação.

## Lacuna específica para a nervura de três bordas

Falta um modelo validado de membrana para esforços discretos transmitidos pelos furos internos, com redistribuição às três bordas soldadas, contorno real e interação de tensões. A estabilidade e os percursos físicos de ruptura também precisam ser compatíveis com esse campo. A simples distribuição equilibrada no grupo de soldas não resolve a resistência da chapa.

Uma referência aplicável deverá especificar: (1) condições de deslocamento nas três bordas; (2) introdução e contato das forças nos furos; (3) tensão equivalente e interação N/V/M; (4) estabilidade da chapa perfurada, quando relevante; (5) validação para esta topologia. Não foi encontrado caso fechado de Roark que cumpra esses cinco requisitos nesta revisão.

Fontes consultadas: Roark, 7ª ed., capítulos 11 e 15; NBR 8800:2024 corrigida 2025, itens 6.3.3.3 e 6.5; MIT Structural Mechanics, Unit 8, elasticidade plana. Testes de software não constituem aprovação estrutural.
