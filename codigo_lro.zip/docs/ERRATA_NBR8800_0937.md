# Source correction: NBR8800 section6.5.4(b)

12 October2026. Source correction only. No frozen release or prior evidence edited.

## Exact source identity

Supplied file: `baseplate_references/Automação MC/NBR 8800-24-25-projeto-de-estruturas-de-aco-e-de-estruturas-mistas-20250710-000231_compress.pdf`

SHA-256: `2289dd360ae938982f44ce6b0633968652199604867172e9d0d454e71256b16d`

PDF page1 (one-based), titled **ABNT NBR8800:2024, ERRATA1**, published25.02.2025, reference **ABNT NBR8800:2024/Er1:2025**, printed errata page1. Visually verified image: `source_reading/nbr_errata_pdf1.png`. This errata page is included at the beginning of the same supplied PDF; it is not an inferred change from a later third-party source.

## Exact correction text

“Página95, seção6.5.4, alínea b)
Substituir por:
b) para o estado-limite último de instabilidade, aplicável quando Le/r >25, devem ser conforme5.3, em que Le é o comprimento destravado do elemento comprimido, obtido por meio de análise de estabilidade elástica ou por métodos aceitos pela comunidade técnico-científica.”

Spacing above is normalized and the printed mathematical subscripts are transcribed as plain Le. The controlling inequality is **Le/r >25**.

## Scope and impact

The supplied PDF's uncorrected body at PDF117/printed95 displays the earlier erroneous ≤25 in6.5.4(b). The included errata resolves it; it should no longer be described as an unresolved normative ambiguity. The prior corner qualification elected to use the full NBR5.3 compression reduction at every positive length, including short lengths, without exploiting the typo. That calculation remains conservative and is unchanged. This discovery does not reopen completed numerical, UI, drawing or audit acceptance.

At the next authorized source increment, amend active interpretation notes to cite this errata explicitly, while retaining the original historical evidence and identifying the correction. Do not silently overwrite frozen release documents or present this as a newly discovered resistance failure. No production source, prior release, drawing or deliverable was changed in this bounded review.

Independent source confirmation is recorded by the independent reviewer in `independent_review/REVIEW.txt`.
