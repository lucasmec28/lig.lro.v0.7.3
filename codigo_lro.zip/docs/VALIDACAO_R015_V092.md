# Validação R015 — versão 0.9.2-angle-dev

Data: 9 de outubro de 2026. A integração foi concluída em uma cópia independente da versão 0.9.1, que permaneceu intacta.

## Resultado verificável

- 1.133 testes passaram no agregado de todas as famílias, em599,94s.
- 172 testes passaram no fonte R015 final congelado, em77,89s:60 do motor,41 de interface,36 de artefatos e35 adversariais independentes.
- 233 assertivas de confronto com fontes e oráculos independentes passaram contra o motor final.
- 18 regressões independentes do legado passaram contra a versão 0.9.2.
- 25 hashes de código, testes e exemplos ficaram inalterados durante a bateria final de172 testes.
- Os244 arquivos arquivados da versão 0.9.1 permaneceram idênticos ao pacote entregue.

O agregado de1.133 testes foi iniciado antes dos últimos ajustes de apresentação, declaração de passe único, proteção contra resultado desatualizado e adição de testes R015. Portanto, não se declara que todos esses testes foram executados numa única passagem sobre o fonte final congelado. Os caminhos afetados foram rechecados integralmente na bateria final de172 testes, incluindo os novos casos. Os números não são somados como se fossem testes distintos.

O diretório final de testes coleta 1.143 casos. Os dez testes adicionados após a coleta do agregado (dois do motor e oito dos artefatos) estão incluídos na bateria final de 172.

## Confronto numérico independente

O oráculo não importa o motor para obter resultados esperados. São oito fixtures de grupos de solda, sete envelopes de cortes na cantoneira, integração de equilíbrio por quadratura, verificação de todos os vetores extremos, excentricidades e sinais, capacidade E70485MPa, A325830MPa, espessura única da alma e caminhos do apoio. O conjunto adversarial adicional contém100 grupos U aleatórios comparados com integração de Gauss e30 casos aleatórios de cortes com sinal comparados com quadratura.

A avaliação usual do exemplo V100kN tem59 verificações locais e capacidade equivalente governante237,247076794kN. Trata-se de limite elástico local conservador da alma junto aos dois grupos; não é o valor histórico ICR do Gerdau.

## Interface e persistência

Foram conferidos seleção de família, entrada nativa distinta da R016, quantidade real de peças, ausência de parafusos/furos fictícios na alma, ações com sinal, unidades kgf/N, importação exata e rejeição de campos desconhecidos, perfis personalizados independentes, geometrias e enums fora do domínio preservados, edição seguida de troca de família, dados ocultos, invalidar a memória ao alterar entradas ou resultados, recuperação após geometria inválida e estados parciais sem mensagem verde indevida.

N/M/T não nulos, cantoneira única, múltiplas colunas, apoio em alma, recortes, atrito, fadiga, material/processo fora da rota e grupos diferentes do U implementado não recebem aprovação. Gabaritos alternativos fisicamente possíveis mantêm pendência de cobertura. Curto segmento, borda de solda sem reforço, sobreposição insuficiente e falha resistente têm diagnósticos próprios.

## Desenho e Word

O desenho representa duas cantoneiras L independentes, uma alma física, os três trechos do U de cada lado, somente parafusos no apoio, bordas reais do pilar e sentido de V. Estados visíveis são em português; a codificação interna permanece disponível no SVG. Topologia diferente não é desenhada como se fosse o par convencional.

A memória contém todos os campos de entrada, premissas, ações, fórmulas editáveis, todas as59 verificações, valores auxiliares, vetores do grupo de solda, equilíbrio e exclusões. As APIs públicas de desenho e Word vinculam resultado e entrada; um resultado calculado para outro projeto é rejeitado explicitamente. Um dicionário diagnóstico sem vinculação não pode conferir aprovação.

A memória do baseline foi renderizada e revisada visualmente em todas as25 páginas. A memória com pendência também foi renderizada em25 páginas. Ambas tiveram zero ocorrências de texto fora da página. O desenho com V negativo foi inspecionado e mostra a seta para cima.

## Exemplos distribuídos

Cada exemplo tem JSON nativo, SVG e DOCX; os cinco foram reabertos e conferidos após geração:

1. R015_cortante_positivo: atendimento local dentro do domínio
2. R015_cortante_invertido: atendimento local no sentido estático inverso
3. R015_falha_resistente:500kN, resistência não atendida
4. R015_gabarito_alternativo_pendente:g50mm fisicamente válido, modelo complementar pendente
5. R015_filete5_borda_sem_reforco:filete5mm em borda6,4mm sem reforço especificado, detalhamento não atendido

Não há liberação de fabricação, análise geral do edifício nem extensão silenciosa às famílias com verificações ainda pendentes.

## Evidência reproduzível

- docs/R015_VALIDATION_RECORD.json:resumo, proveniência e hashes
- docs/R015_FINAL_SOURCE_HASHES.json:hashes e revisão final independente
- docs/R015_INDEPENDENT_COMPARISON.json:233 assertivas e oráculos
- tests/fixtures/r015_independent_fixtures.json e calculate_r015_fixtures.py
- tests/test_welded_double_angle.py
- tests/test_welded_double_angle_app.py
- tests/test_welded_double_angle_artifacts.py
- validation/v092/test_r015_independent_adversarial.py
- validation/v092/:logs da sequência e inspeção dos artefatos

Para repetir os testes do pacote, instale requirements-dev.txt, execute python -m pytest -q tests e depois python -m pytest -q validation/v092/test_r015_independent_adversarial.py. A preparação de publicação, integridade do ZIP e smoke test da extração limpa são etapas separadas deste registro de implementação.
