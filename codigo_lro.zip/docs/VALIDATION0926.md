# Validação 0.9.26-welded-angle-gusset-dev

Escopo: implementação local parametrizada da 15ª família, uma L100×100×12 soldada por uma aba à chapa retangular e raiz longitudinal dupla na mesa W centrada na alma. A aceitação é de código, cálculo e artefatos dentro desse domínio. Não é aprovação global do membro/estrutura ou de fabricação.

## Resultado executado

- 331 identidades pytest distintas aprovadas, zero falhas e zero testes ignorados. Execuções repetidas não somadas.
- 85 grupos independentes do motor aprovados, apresentados separadamente da contagem pytest do pacote.
- 1.200 geometrias aleatórias independentes, 964 comparações efetivamente calculadas e 292 passes locais completos; nove pares de bordas livres exercitados.
- 527 vetores de entrada/carga das 14 famílias anteriores com resultado serializado idêntico, excluindo somente metadados de versão/digest.
- 100 registros W avaliados com suas dimensões e identidade. Isso valida a aritmética desses dados identificados, sem recertificar todo o catálogo.
- Interface nativa, importação atômica, invalidação de Word antigo, downloads reais, desenho e Word verificados independentemente. O relatório independente e as receitas específicas estão em validation_welded_gusset0926/independent_ui/.
- 29 arquivos de exemplos nativos/PNG/SVG/Word regenerados a partir dos módulos finais; identidade de bytes em WELDED_ANGLE_GUSSET0926_ARTIFACTS.json.

## Identidades únicas por arquivo

- tests/test_guided_selection0919.py: 90.
- tests/test_axial_single_angle_routes.py: 16.
- tests/test_welded_w_splice_ui0923.py: 41.
- tests/test_end_plate_8es_artifacts0924.py: 23.
- tests/test_welded_angle_gusset0926.py: 107.
- tests/test_welded_angle_gusset_free_edges0926.py: 14.
- tests/test_welded_angle_gusset_ui0926.py: 22.
- tests/test_welded_angle_gusset_artifacts0926.py: 18.

FOCUSED_TEST_NODES0926.json enumera cada identidade e sua receita final. Os três XML finais são authoritative para a execução focada; arquivos de execuções anteriores não são somados. As evidências independentes têm contagens e alcance próprios.

## Casos adicionais validados

Exemplo75° excêntrico N100kN e falha N200kN; compacto45° N100kN com momento real; alinhados45°/135° N45kN com Mlocal≈0; mínimo45kN separado do caso real zero; materiais e consumíveis independentes; V assinado em ângulos obtusos; campo interno comprimido apesar da raiz tracionada; interferência com raiz; espessura real de substrato; limites de comprimento/filete e distâncias às bordas/cantos. Caminhos usam as bordas finitas reais, sem converter raiz apoiada em borda livre; famílias L geometricamente inexistentes ficam explicitamente inativas.

## Identidade e limites

Motor final SHA-256: 3d0414c4e07d93230925bc5348b0bc44d135a3025fb9257ce8b9a1e6a4865d6a.
RUNTIME_SOURCE_SHA256.json identifica app.py, lro/ e data/ usados nos resultados. A versão exata e release_gate estão em VALIDACAO_PACOTE0926.json e validation_welded_gusset0926/results.json.

Não foi executada a suíte histórica inteira. Uma advertência de depreciação do pytest no parametrizador existente do guia não é falha funcional. Dependências extras foram acrescentadas depois dos pacotes instalados; compilação de app.py, módulos e novos testes concluída.

Compressão/estabilidade, fadiga/sismo, ação espacial, ligação direta à alma W, cantoneiras arbitrárias, soldas desiguais/L/s>100, chapas poligonais e raiz descentrada/descontínua continuam fora do método. Ações concorrentes são exportadas para a verificação real do membro; suas ações preexistentes não são presumidas nulas. Não houve publicação, envio, implantação ou alteração da versão-base entregue.
