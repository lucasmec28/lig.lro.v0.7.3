# Complete bolted angle–gusset–exterior-W-flange route: bounded qualification

11 October 2026. Qualification only; no production source, frozen version, deployed package or historical fixture was edited. All calculations in this directory are NEW source-derived calculations, not recovery of the absent historical bolt-bearing oracle. This document does not approve fabrication, a loaded beam/column, or a whole structure.

## Decision

**GO at method level for a separately identified complete 2L-T route and 1L route**, ordinary static tension, standard bearing-type bolts, one straight bolt line, one rectangular gusset and one longitudinal web-centered root on a rolled W exterior flange, subject to the explicit geometry/material/detail inputs and checks below. The 1L route adopts the stated ordinary static-angle end-eccentricity idealization; the T route additionally has actual through-thickness symmetry. A new implementation and its independent acceptance still have to reproduce these results and exclusions. A pass of the old axial strip component is not this GO.

**Variable brace angle remains part of the allowed finite input domain.** The 90-degree case is a useful reference case, not a replacement for inclined diagonals. The principal new example is at 80 degrees with a nonzero root moment. Any 0<theta<180 degrees can be evaluated if the actual geometry, detailing, load-path and stated tension-domain checks pass. This is a geometry/check-bounded domain, not a promise that every angle/position works. Theta=100 degrees is the sign-reversed in-plane mirror of the main example. Theta=75 degrees with the otherwise identical main example creates a compressed root edge and is outside this first tension-only gusset model.

**NO-GO to sharing the same bolt-group model with the confirmed opposed-vertex pair.** That section requires two distinct single-shear rows, not shared double-shear bolts. Its finite remaining task is in Section 9; it does not require redoing the already qualified T/1L root/W components or a blanket FEA gate.

No further owner clarification is essential for this method qualification. The already confirmed T and opposed cross-sections are unambiguous. Real project dimensions, bolt hardware/tool access and materials remain ordinary actual design inputs, not a yes/no external-verification checkbox.

## 1. Physical arrangements, action line and force conservation

Coordinates: s along the root and W axis; n normal to the flange in the gusset plane; z normal to the gusset. Theta is measured from +s towards +n. The gusset occupies -B/2<=s<=B/2, 0<=n<=H. Its root is n=0, one equal continuous fillet each face, longitudinal and centered above the W web. Beam versus column is a rigid rotation of this local arrangement.

Define the bolt-row direction u=(cos(theta),sin(theta)) and v=(sin(theta),-cos(theta)), with row reference P=(sP,nP). Every bolt center is P+u*u_j. The connected leg's exterior heel is v=-g and toe is v=b-g; its free longitudinal end is a specified distance e before the first bolt. Angle members extend towards +u. Gusset bolt forces point +u; angle hole forces point -u. The free loaded ends are therefore opposite. The selected nominal row force line is a deliberate use of NBR6.1.8.2 for statically loaded angle ends; it is not a physical assertion that the member centroid moved onto the row. The actual per-angle centroid ec is still used for shear lag.

- **1L:** one angle on one face; n physical bolts, one shear plane per bolt; each bolt and gusset hole receives N/n; the angle hole receives N/n. The ordinary direct-contact angle-end eccentricity is idealized according to6.1.8.2. Out-of-plane local couples are not claimed to have canceled or to have been resolved by a 3D model. Stand-offs/fillers, imposed spatial actions, fatigue and reversal are outside this application.
- **2L-T:** identical angle on each face; heels line up in projection; connected legs point in the same in-plane direction, so both holes overlap. Each physical bolt passes through angle–gusset–angle and has two physical shear planes. With equal symmetric members and contact, each angle receives N/2, each shear plane N/(2n), and the one central gusset hole N/n. N is the TOTAL pair force. Do not count two gusset thicknesses or double the root.
- **2L opposed:** confirmed section rotates one L180 degrees; connected legs point into disjoint +v and -v intervals, separated at the heels by h=tg. A bolt through one connected leg and gusset cannot also cross the other leg. See Section9.

For both qualified nominal planar routes:

Nroot=N sin(theta), Vroot=N cos(theta), Mroot=sP Nroot−nP Vroot.

The same formula follows by summing all discrete bolt forces and their lever arms. Moving P along the same row leaves Mroot unchanged. Do not carry a physical centroid force into the root and then set the transport moment to zero. Do not request an arbitrary user moment to model what is already fixed by the brace line.

N real zero remains zero. NBR6.1.5 minimum45 kN is a separate connection case, applied ONCE before dividing between angles/planes. Optional50%-of-member-resistance recommendation is also a separate case; for2L it uses the pair resistance. Neither replaces, adds to, or is added twice to N real. Compression and external V/M/T are reported as outside this family, not converted to tension.

## 2. Source basis and what is new

The supplied AISC DG29 Example5.4, Fig5-10 (printed98 / PDF106), is an oblique **2L–shared bolts–gusset–double root fillet–W flange** connection. Printed99–104/PDF107–112 check the two angles, double-shear bolts, both opposing bearing directions, gusset block shear and Whitmore section. Printed105–108/PDF113–116 retain interface force/moment and check the root weld and local W web. It is direct precedent for this load-path method; it is not a rectangular NBR numerical oracle.

Its plate is shaped; its member/bolts are imperial and its factors are AISC360-10. Its published connection redistributes bearing/bolt resistance and includes compression, which controls the thickness change from1/2 to5/8 in. Its root uses the stated plastic4M/B convention. This contract instead uses actual rectangular boundaries, separate NBR2024/Errata2025 material factors, uniform per-bolt design demand checked individually, tension only, and conservative elastic6M/B root envelope. Do not silently copy any of those source choices.

The full-width perforated section calculation below is a **nominal supplemental section screen**, not an exact continuum/contact stress solution. It cannot replace Whitmore, hole contact, effective/net fracture or real free-edge block paths. Keeping these separate source-supported limit states closes the conventional design model without pretending equilibrium proves a microscopic stress field.

## 3. Bolts, net sections and bearing

Normal-combination factors: gamma_a1=1.10; gamma_a2=gamma_w2=1.35. All material records are independent: L, gusset, W, bolts and root electrode. Sharing numerical fy/fu in one fixture does not merge their records.

Angle: use exact catalog Ag for ONE L, exact ec, actual b/t, and correct catalog identity. Agpair=2Ag only for2L. One critical transverse cut of a straight longitudinal row crosses one hole per L. An=Ag−dn*t; Ae=Ct*An, Ct=max(1−ec/Lc,Ac/Ag); for the equal-leg symmetric partition Ac/Ag=.5. Lc is first-to-last bolt-center length, not n*p. Check gross yielding and effective rupture. Do not set ec=0 because the pair is symmetric through the gusset.

NBR5.2.4.1: dn is Table14 maximum hole width+2mm, except drilled holes may use the maximum hole dimension itself. Physical hole diameter controls contact clearance; dn controls net-area deductions. Standard M16 hole is18mm; metric M16 is not the15.875mm imperial5/8-in system. Two longitudinal holes are not two deductions in the same ordinary perpendicular section. Multiple transverse rows/staggered patterns are excluded from this one-row route.

NBR6.3.3.2: each plane Rd=alpha*Ab*fub/gamma_a2, alpha=.45 when threaded and .56 only when the plane truly misses threads; Ab=pi*d²/4. Check each plane, never average thread conditions. Apply actual grip and6.3.7 reduction, if triggered; no slip resistance is credited. For T the central hole and bolt carry N/n total while each L/plane carries N/(2n).

Use the deformation-limited contact branch6.3.3.3(a): Rd=min(1.2*lc*t*fu,2.4*d*t*fu)/gamma_a2. lc is along the FORCE ON THAT PART to the next actual hole or free boundary. A supported root is not a free edge. Angle end hole normally points towards its free member end; gusset end hole points the opposite way, towards the free polygon edge. Preserve their different lc. The new fixture assumes uniform bolt loading: every hole must pass its individual demand as well as any summed-strength display. It does not silently use DG29's capacity-redistributed group resistance to excuse one overloaded hole.

Detail checks use NBR6.3.6–6.3.12, Tables14/16: minimum center pitch2.7d (3d preferred), clear gap>=d, correct free-edge minimum, maximum pitch by exposure and thinner part, actual nearest-fastener distance to every free edge<=min(12t,150mm), grip and physical overlap.6.3.8's>950mm provision is for the stated tension-splice scope, not an automatic universal gusset multiplier; the finite fixtures are100mm long anyway. Root weld/angle footprint/tool envelopes cannot overlap.

## 4. Gusset transfer and actual paths

At the last load-transfer row towards the root, use the conventional DG29 Whitmore section: width of the extreme bolt lines plus2Lc*tan30 degrees. A single row starts with zero transverse line separation but Lc>0 gives a finite width. Clip this segment to the real connected plate; do not count beyond its boundary or across unsupported imaginary material. The main fixture's entire115.470054mm segment fits. Check gross yielding; retain a separately disclosed conservative net-Whitmore rupture screen with actual hole deduction. NBR6.5.3 splice-plate .85Ag cap is not automatically attached to a gusset.

Also inspect actual force-normal net sections through the bolt stations, clipped to the rectangle, including their net centroid/inertia and the N/M about that centroid. At any oblique physical cut use its own load reference; do not call a noncentral net section centered. Actual plate gross/net tension, shear and root region are retained under6.5.3/6.5.5.

NBR6.5.6 block equation:
R=min(0.6fu Anv+Cts fu Ant,0.6fy Agv+Cts fu Ant)/gamma_a2.
Both branches use gamma_a2, including the gross-shear-yield branch. Cts=1 is available for the appropriate uniform transverse tensile path; the new worked fixtures conservatively use .5, explicitly, for every path. Do not manufacture a stronger Cts without its geometry basis.

One straight bolt line has standard L paths towards each side and each physically possible longitudinal free end; it does not acquire a two-row U block by counting the same bolt line twice. Evaluate k=1...n captured-bolt prefixes for each angle and suffixes for the gusset. Every path records coordinates, actual free exits, hole fractions, Av/Ant and the force captured. Each L's far path continues through the heel to the other real toe; the heel is not a free edge. Catalog Ag minus the connected-toe strip gives a conservative nominal far-path area without reconstructing nonexistent catalog radii. The opposite gusset side is an alternative path carrying the captured total, not half the force; never add alternative path capacities.

For parameter variations, intersect each path with the actual bounded rectangle. A path touching a positive segment of the supported root does not detach a free block and is inactive, with the reason recorded. Include polygon-corner transitions and every change in intercepted bolt set; within a no-hole/corner interval the demand is constant and ordinary path lengths/capacities are affine, so extrema occur at interval ends. The complete main fixture has both transverse exits on free sides for everyk and longitudinal exit on its free top; no root contact is hidden. Individual-hole bearing already checks the short ligaments between successive holes. Named NBR/DG29 paths are the conventional limit-state family, not a claimed enumeration of every possible microscopic crack curve.

Discrete-section audit: at each horizontal cut, sum the included physical bolt force vectors and moments about the actual net centroid. Subtract the intersected circular-hole chords using the net deduction dn; calculate A, first moment and I from the remaining section. At a hole-crossing station retain the pre/post force limits instead of assuming a physical contact-pressure distribution. The NEW JSON records all hole-edge/center intervals and numerically optimized nominal extrema.

For the supplemental nominal elastic screen use sigma=N/A+M(s−sbar)/I and a stated1.5|V|/A shear envelope. The latter is inherited solid-rectangle screening, **not an exact hole-split-section shear solution**. Require the screen to remain tensile and to pass its material envelopes for this bounded implementation; a failed screen means this method does not qualify the input, not proof of physical buckling or a universal FEA requirement. Within the unperforated root ligament, normal stresses and their endpoint bounds have their ordinary rectangular-section meaning. Within the bolted transfer zone the independent Whitmore/net/bearing/block checks, not this screen alone, provide conventional local qualification.

## 5. Root and receiving W: one consistent continuation

The root has two equal full-length fillets; each carries half the total line demand. For the combined two-line system:
qn=Nroot/B±6Mroot/B², qs=Vroot/B.
qpeak=max(hypot(qn,qs)); qavg is the arithmetic mean of endpoint resultants; qdesign=max(qpeak,1.25qavg), a disclosed DG29 weld supplement. Root weld stress=qdesign/(sqrt(2)*sroot), compared with0.6fw/gamma_w2; no concentric directional enhancement. Keep NBR throat, minimum by LESS-thick material, effective length, edge maximum, process/material compatibility and weld access checks.

Check both root base materials with their own fy/fu. Gusset effective contact depth=min(tg,2sroot); W contact depth=2sroot. Normal/shear yield uses sqrt(sigma²+3tau²), plus separate normal/shear rupture. Do not treat qdesign as pure shear in the base metal. W flange punching/shear uses qpeak/(2tf), not the weld-only1.25 average factor.

NBR5.7.1 external web-centered flange domain only. Preserve flange local bending or its actual transverse-footprint exemption; local W-web yielding for tension too; both W ends/end reductions; longitudinal web shear under Vroot and its local interaction screen. The main fixture has all tensile root normal traction, so compression-only crippling/sidesway checks are inactive. An actual compressed region leaves this first route. Built-up welded I, direct W web, transverse or laterally offset root, stiffeners, second root/second receiving member and corner-UFM allocation are separate geometries.

Export face Nroot,Vroot,Mroot and at the W centroid Mcentroid=Mroot−dW*Vroot/2. The added transverse member-shear jump is Nroot, distinct from longitudinal interface shear Vroot. Actual concurrent support-member actions must be combined in its own member analysis; do not assume zero or call an isolated local pass a whole-member approval.

## 6. New worked complete-route cases

`NEW_COMPLETE_BOLTED_FIXTURES.json` and `calculate_new_fixtures.py` import no application modules. They preserve actual supplied source hashes and contain the published DG29 arithmetic replay, seven new geometries/material/load variants, two negative geometries and same-geometry load-scaling failures for each check family.

Principal case: Gerdau p3 R29, **L76.2×76.2×6.35**, Ag929mm², ec21.3mm per angle; gauge40mm; angle free end35mm before first bolt. The historical b76 alias is not used. Each angle A36fy250/fu400; independent gusset record initiallyfy250/fu400; Wfy345/fu450; bolt fub830; root E60fw415. Three M16, standard18mm drilled holes, threads in all planes, p50mm. Rectangular gusset240×300×12.5; P=(0,150); theta80degrees; root two5mm fillets. W310×165×52 Arcelor: d317,bf167,tf13.2,tw7.6,k21.2; ends±1000. Ntotal100kN.

Bolt centers (s,n)mm: (-8.682409,100.759612),(0,150),(8.682409,199.240388). Row forward free exit=(26.449047,300). Whitmore endpoints=(-65.540311,110.785195),(48.175493,90.734030). All coordinates refer to this ONE plate and root, not disconnected component strips.

Additional tool-access fixture input: inside-heel exclusion extent12.35mm from outer heel (equivalent to an assumed6mm internal root radius), tool radius18mm and clearance2mm, leaving7.65mm margin atg40. **This12.35mm is a declared detail assumption, not supplied by the Gerdau table and not certified by this research.** The method can accept a verified maximum heel extent instead of an exact radius. The exact finite acceptance criterion is kheel<=20mm at this gauge/tool envelope (equivalently r<=13.65mm if kheel=t+r). If this real detail is not supplied, mechanics may be shown but physical assembly stays pending. Do not insert an unknown catalog radius or use gyration radius.

Results for2L-T:
- angle Ct=.787; pair yielding422.272727kN; pair effective rupture379.951941kN
- each threaded shear plane55.627134kN; group333.762804kN; plane demand16.666667kN
- most-loaded angle end bearing58.702222kN versus16.666667kN; central-gusset per-hole bearing142.222222kN versus33.333333kN (its long top edge is not falsely replaced by the angle's35mm end)
- Cts.5 full connected-toe block120.838148kN per L versus50kN; gusset left/right full blocks473.648774/506.301919kN versus100kN each as alternatives
- Whitmore gross yield328.039926kN, net screen361.000199kN; actual force-normal net section area2821.279836mm² at the lowest hole, net centroid offset9.519462mm retained
- Nroot98.480775kN,Vroot17.364818kN,Mroot−2.604723kNm; qnormal681.661841/139.011286N/mm
- root weld utilization.525594925, governing among listed conventional/supplemental checks; gusset contact.304957748; W web normal.180331435; W local combined screen.296650211
- loaded flange transverse footprint22.5mm<.15bf=25.05mm; flange bending exempt; closest root point880mm from either W end
- every modeled nominal section remains tensile; unperforated root min normal11.120903MPa. This is a nominal model statement, not pointwise continuum stress certification

At theta90, Mroot=0; same complete geometry passes. At theta100, V/M reverse and utilization is mirrored. At N200kN with theta80, root weld utilization1.051189849 fails: doubling the angle count never doubles gusset/root capacity. The1L same-geometry N100kN reference uses one shear plane and full100kN on one L; nominal angle-toe block utilization.827553232 governs, conditional on the stated static end idealization and real access input. Its gusset/root actions and capacities are unchanged.

Independent plate-steel mutation changes only gusset checks; nondrilled holes use dn20 and lower net areas while retaining physical18mm contact clearances. The400mm-wide negative plate violates the maximum free-edge distance with this one-row/t12.5 detail; a broad rectangle is not automatically a valid bolted gusset. The75-degree fixture fails the root tension-domain screen. JSON failure loads scale ALL actions concurrently to a target utilization1.01, rather than forging isolated check demands.

## 7. Minimum inputs and reuse boundaries

Inputs can be reduced to physically necessary selections, not a proliferation of proof checkboxes:
1. arrangement1L or symmetric2L-T, selected catalog/manual angle and independent material records;
2. gusset B/H/t and steel; receiving rolled W identity/steel, root longitudinal position and both member-end distances;
3. brace theta and bolt-row reference point/line, actual N cases and minimum/recommendation switches with fixed semantics;
4. n, pitch, gauge, member free-end offset, bolt diameter/class, actual standard-hole system/manufacture, thread position per plane, grip/washer stack, exposure and pretension status;
5. actual tool/hardware clearance envelope and inside-heel extent if not furnished by the section source;
6. root fillet size/electrode/detail. Full-length equal root fillets and direct contact are fixed family geometry, not multiple unconstrained options.

Catalog identification supplies b/t/Ag/ec automatically but does not certify material or missing internal radius. Do not add guessed manufacturer-radius fields to the catalog or an attestation checkbox. Reuse the existing bolted-detail input mechanism where possible; a supplied actual clearance/heel envelope is detail geometry, not manufacturer metadata. Preserve the approved50 Gerdau identities; the incomplete2.50mm rows remain excluded. Do not reassign catalog sources, round76.2 to76, or inherit source-absent radii.

Reuse compatible material/catalog/bolt scalar routines, retested against new source-derived oracles. Reuse qualified unperforated root/W equations after passing THIS bolt-row resultant and actual plate geometry. **Do not reuse the axial module's terminal cut, old global_pass, old output JSON results, welded continuous load-transfer polynomials or no-hole tear paths.** New native family/schema, report, drawing and UI must identify holes, topology, planes, force split, current inputs and root/W completeness. Do not silently upgrade an old component project into an approved complete connection.

## 8. Acceptance tests before implementation release

Recompute source replay, principal fixture and all negative/scaled cases independently. Check row-reference translation invariance, rigid beam/column rotation, theta100 sign mirror, signed component arrows, angle one/two switch, individual shear planes and bearing forces, each independent material/electrode mutation, net18/20 policy, actual nearest free-edge limits, root end proximity, theta90, min45 case exactly once, Nreal0 preservation and optional pair recommendation.

Adversarial geometric tests: root-touching block inactive, side/top free exit change, corner transitions, nonpositive ligaments, holes/tool/root collision, Whitmore clipping, maximum edge/pitch boundaries, asymmetric2L, fillers, invalid through-bolt topology and opposed section rejection. Nominal section criteria cannot be replaced by root-only utilization. Exports must recompute rather than trust stored results. Every result retains source/formula/purpose (normative versus supplemental nominal screen) and path coordinates.

The one-line rectangle domain is intentionally finite. Missing a new arbitrary polygon solver is not a reason to block this route; accepting an unqualified topology by renaming it is not a shortcut.

## 9. Opposed-pair remaining finite task

For the confirmed opposed image, choose the section midpoint as v0, heel gap h=tg, equal gaugeg. Its connected-leg intervals lie on opposite sides. Two equal single-shear rows are at v=±(h/2+g); each physical bolt joins ONE L to the common gusset and carries N/(2n). There are2n physical bolts, not n shared bolts. Each gusset hole now receives N/(2n), not N/n. The group resultant may be centered in-plane and in z for symmetric rows, but local face-couple transfer is not a physical cancellation proof.

NBR6.1.8.2 may be expressly applied per ordinary direct-contact L, as for the welded opposed qualification, but that does not itself supply bolted two-row resistance. The remaining calculation is finite:
- establish actual row centers/stagger, angle end positions, gap/gauge/hardware access and same/equal symmetry assumptions;
- enumerate the central gusset's two-hole transverse net section and any zigzag hole chains (not two independent single-hole plate passes);
- two-row U blocks containing both rows, L blocks containing one/both rows, partial rows and hole intersections, with true free/root boundaries and captured forces;
- verify per-row single-shear bolt/bearing and plane effects, local introduction/Whitmore and the full shared perforated plate, preserving all equal-and-opposite local assumptions;
- one new complete numerical fixture and an independent review before exposing this arrangement in production.

No missing single-row theory, historic oracle, or general FEA requirement remains. The specific missing deliverable is that actual **two-row perforated-gusset model/fixture**, which this pass does not pretend to provide. Source pointer: NBR5.2.4.1(b–d),6.3,6.5.6/Fig16 and DG29 Chapters3–4 plus the applicable two-row geometry. Do not defer current1L/T work merely to wait for it.

## 10. Auditable source pointers

Physical PDF pages are1-based. Sources and SHA-256 hashes are in the JSON.

- Supplied NBR8800:2024 with Errata1:2025: PDF47/printed25 factors;61–64/39–42 tension/net/shear lag;85–86/63–64 W exterior-flange local rules;91–93/69–71 realistic equilibrium, minimum strength and static-angle exception;97/75 and100/78 weld area/strength;102–103/80–81 fillet detail;106–107/84–85 bolt shear/contact;112–114/90–92 holes/grip/pitch/edges;116–118/94–96 connection elements/net/block;152/130 bolt/electrode materials.
- Supplied AISC DG29(2014): Fig5-10 PDF106/98; brace/bolt/bearing/gusset PDF107–112/99–104; root force/moment and weld/W PDF113–116/105–108. General one-root interface statics§4.2.4 PDF40–41/32–33; flange checks PDF62–67/54–59; normal/moment and W transfer AppendixA/B PDF204–212/196–204.
- Supplied Gerdau pocket table PDF2 nominal/tolerances; PDF3 R29 supplies76.2,6.35,Ag9.29cm²,ec2.13cm. It supplies no inside-heel/toe radius. The separate Gerdau connections manual is secondary topology corroboration, not the source of current2024 coefficients.
- Primary W catalog: https://constructalia.arcelormittal.com/files/W--0487915bad55d18fbfc679cd87133c88.pdf , PDF3/printed157, W310×165×52:317/167/7.6/13.2/r8. Verified11 October2026. No dimensions from another producer are merged into that identity.
- Existing immutable implementation contracts inspected for compatibility only: `review0929/source0929/docs/AXIAL_DOUBLE_ANGLE0920_METHOD.md`, `lro/axial_double_angle.py`, qualified welded-gusset/root contracts. These are not substituted for normative sources.

Future corner gusset with TWO receiving interfaces is a distinct user-requested later task: DG29§4.2 uniform-force method and its corner examples are the pointer only. It is not included in this one-root route.
