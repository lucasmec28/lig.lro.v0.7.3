"""NEW 2026-10-11 source-derived reference calculations; no application imports.
Explicit conventional strength model, not a continuum solution or construction approval.
"""
from pathlib import Path
import math, json, hashlib
import numpy as np
from scipy.optimize import minimize_scalar
OUT=Path(__file__).parent
G1,G2=1.10,1.35

def block(Av,Anv,Ant,fy,fu,D,id,**kw):
    by=(.6*fy*Av+.5*fu*Ant)/G2
    br=(.6*fu*Anv+.5*fu*Ant)/G2
    return dict(id=id,Agv=Av,Anv=Anv,Ant=Ant,Cts=.5,R_yield=by,R_rupture=br,R=min(by,br),demand=D,utilization=D/min(by,br),**kw)

def fixture(theta=80.,count=2,N=100000.,fyp=250.,fup=400.,drilled=True,B=240.,H=300.,tp=12.5):
    C,S=math.cos(math.radians(theta)),math.sin(math.radians(theta))
    b,ta,Ag,ec=76.2,6.35,929.,21.3 # exact Gerdau p3 R29, not legacy b76
    n,p,g,e,d,dh=3,50.,40.,35.,16.,18.
    dn=dh if drilled else dh+2.
    fy,fu,fyw,fuw,fw=250.,400.,345.,450.,415.
    ujs=[-50.,0.,50.]; P=(0.,150.);r=dh/2
    def xy(u,v):return [P[0]+u*C+v*S,P[1]+u*S-v*C]
    holes=[xy(u,0) for u in ujs]
    def ray_exit(point,vec):
        candidates=[]
        for axis,bounds in [(0,[-B/2,B/2]),(1,[0,H])]:
            if abs(vec[axis])<1e-12:continue
            for end in bounds:
                a=(end-point[axis])/vec[axis]
                z=[point[j]+a*vec[j] for j in [0,1]]
                if a>=-1e-9 and -B/2-1e-8<=z[0]<=B/2+1e-8 and -1e-8<=z[1]<=H+1e-8:
                    candidates.append((max(0,a),z,'root' if axis==1 and end==0 else 'free'))
        return min(candidates,key=lambda x:x[0])
    plate_exit=ray_exit(P,[C,S]); ue=plate_exit[0]
    # NBR nominal member path: member continues +u, angle end at u=-85.
    angle_blocks=[]
    for k in range(1,4):
        Lv=e+(k-1)*p; Av=Lv*ta; Anv=(Lv-(k-.5)*dn)*ta
        for side,At in [('connected_toe',(b-g-dn/2)*ta),('opposite_toe_area_complement',Ag-(b-g)*ta-dn*ta/2)]:
            angle_blocks.append(block(Av,Anv,At,fy,fu,N*k/(count*n),f'A-{side}-{k}',copies=count,k=k,Lv=Lv))
    plate_blocks=[]
    # Source conventional one-row L paths through each included end hole; both physical sides.
    for j,u in enumerate(ujs):
        k=n-j;Lv=ue-u
        for sign in [-1,1]:
            le,pt,kind=ray_exit(xy(u,0),[sign*S,-sign*C])
            # For this finite case there is no root overlap in either side block.
            if kind=='root':continue
            plate_blocks.append(block(Lv*tp,(Lv-(k-.5)*dn)*tp,(le-dn/2)*tp,fyp,fup,N*k/n,f'G-L-{sign:+d}-{k}',k=k,Lv=Lv,transverse_length=le,path=[plate_exit[1],xy(u,0),pt],free_transverse_exit=kind))
    Ct=max(1-ec/(2*p),.5);An=Ag-dn*ta
    Ar=math.pi*d*d/4;Rplane=.45*Ar*830/G2
    angle_bear=[];plate_bear=[]
    for j in range(n):
        la=e-dh/2 if j==0 else p-dh
        lp=p-dh if j<n-1 else ue-ujs[-1]-dh/2
        for out,lc,t,f,dem in [(angle_bear,la,ta,fu,N/(count*n)),(plate_bear,lp,tp,fup,N/n)]:
            rr=min(1.2*lc*t*f,2.4*d*t*f)/G2
            out.append(dict(hole=j+1,lc=lc,tearout_R=1.2*lc*t*f/G2,bearing_cap_R=2.4*d*t*f/G2,R=rr,demand=dem,utilization=dem/rr))
    # Exact 30-degree Whitmore segment at lower/last load-transfer row.
    w=2*(n-1)*p*math.tan(math.pi/6)
    Whit=[xy(ujs[0],-w/2),xy(ujs[0],w/2)]
    assert all(-B/2<=x<=B/2 and 0<=y<=H for x,y in Whit)
    whit=dict(width=w,endpoints=Whit,gross_area=w*tp,net_area=(w-dn)*tp,
       R_yield=w*tp*fyp/G1,R_net=(w-dn)*tp*fup/G2,
       yield_utilization=N/(w*tp*fyp/G1),net_utilization=N/((w-dn)*tp*fup/G2),
       net_note='Conservative supplementary net-Whitmore screen; actual free-edge net and block paths also checked.')
    # Actual force-normal sections crossing each hole, boundary clipped; force centroid stays on row.
    normal_cuts=[]
    for j,u in enumerate(ujs):
        left=ray_exit(xy(u,0),[-S,C]);right=ray_exit(xy(u,0),[S,-C])
        width=left[0]+right[0];cent=(right[0]-left[0])/2;A=(width-dn)*tp
        # physical section net centroid after removing centered hole
        cnet=width*cent/(width-dn)
        I=tp*(width**3/12+width*cent**2-dn**3/12)-(width-dn)*tp*cnet*cnet
        D=N*(n-j)/n;M=-D*cnet
        end=[-left[0]-cnet,right[0]-cnet]
        sig=[D/A+M*x/I for x in end]
        normal_cuts.append(dict(u=u,width=width,net_area=A,net_centroid_v=cnet,I=I,demand_envelope=D,moment_about_net_centroid=M,sigma_edges=sig,
          yield_utilization=max(map(abs,sig))/(fyp/G1),rupture_utilization=max(map(abs,sig))/(fup/G2),endpoints=[left[1],right[1]]))
    # NOMINAL perforated horizontal section/jump envelope. No physical bearing-arc assertion.
    def cut(y,active):
        widths=[]
        for xh,yh in holes:
            rad=dn/2 # net geometry uses mandated hole deduction, not bolt diameter
            widths.append(2*math.sqrt(max(0,rad*rad-(y-yh)**2)) if abs(y-yh)<=rad else 0.)
        A=tp*(B-sum(widths));Q=-tp*sum(h*x for h,(x,_) in zip(widths,holes));cg=Q/A
        I=tp*(B**3/12-sum(h**3/12+h*x*x for h,(x,_) in zip(widths,holes)))-A*cg*cg
        nr=N*S*sum(active)/n;vr=N*C*sum(active)/n
        m=sum(a*N/n*((x-cg)*S-(yh-y)*C) for a,(x,yh) in zip(active,holes))
        sig=[nr/A+m*(x-cg)/I for x in [-B/2,B/2]]
        tau=1.5*abs(vr)/A;vm=math.sqrt(max(abs(x) for x in sig)**2+3*tau*tau)
        return dict(y=y,A=A,centroid_s=cg,I=I,N=nr,V=vr,M=m,active=active,sigma_edges=sig,tau_envelope=tau,
            sigma_min=min(sig),sigma_max=max(map(abs,sig)),VM=vm,utilization_yield=vm/(fyp/G1),
            utilization_rupture=max(max(map(abs,sig))/(fup/G2),tau/(.6*fup/G2)))
    rad=dn/2
    bounds=sorted(set([0.,H]+[yy+a for xx,yy in holes for a in [-rad,0,rad]]))
    results=[]
    for y0,y1 in zip(bounds,bounds[1:]):
        mid=(y0+y1)/2
        optional=[j for j,(x,y) in enumerate(holes) if abs(mid-y)<rad]
        base=[int(y>mid) for x,y in holes]
        masks=[base]
        if optional:
            j=optional[0];masks=[]
            for bit in [0,1]:z=base[:];z[j]=bit;masks.append(z)
        for active in masks:
            candidates=set([y0,y1])
            for key,sign in [('sigma_min',1),('sigma_max',-1),('VM',-1),('utilization_rupture',-1)]:
                # Split interval for stable independent scalar optimization, endpoints retained.
                grid=np.linspace(y0,y1,33)
                for a,b_ in zip(grid,grid[1:]):
                    opt=minimize_scalar(lambda y:sign*cut(float(y),active)[key],bounds=(a,b_),method='bounded',options={'xatol':1e-10})
                    candidates.add(float(opt.x))
            vals=[cut(y,active) for y in candidates]
            results.append(dict(interval=[y0,y1],active=active,
              min_sigma=min(vals,key=lambda x:x['sigma_min']),max_VM=max(vals,key=lambda x:x['VM']),
              max_rupture=max(vals,key=lambda x:x['utilization_rupture'])))
    # Root, both contact materials, exterior W local checks.
    nr,vr=N*S,N*C;mr=N*(P[0]*S-P[1]*C)
    qn=[nr/B-6*mr/B**2,nr/B+6*mr/B**2];qs=vr/B
    qe=[math.hypot(x,qs) for x in qn];peak=max(qe);avg=sum(qe)/2;qd=max(peak,1.25*avg)
    sr=5.;tf,tw,k,dw,bf=13.2,7.6,21.2,317.,167.
    def contact(depth,f,y):
        sn=max(map(abs,qn))/depth;ta_=abs(qs)/depth
        return dict(depth=depth,sigma=sn,tau=ta_,yield_u=math.sqrt(sn*sn+3*ta_*ta_)/(f/G1),normal_rupture_u=sn/(y/G2),shear_rupture_u=ta_/(.6*y/G2))
    neq=nr+6*abs(mr)/B
    root=dict(N=nr,V=vr,M=mr,B=B,t=tp,area=B*tp,q_normal=qn,q_parallel=qs,q_peak=peak,q_average=avg,q_design=qd,
        weld_leg=sr,weld_utilization=qd/(math.sqrt(2)*sr)/(.6*fw/G2),
        gusset_contact=contact(min(tp,2*sr),fyp,fup),W_contact=contact(2*sr,fyw,fuw),
        W_flange_shear_u=peak/(2*tf)/min(.6*fyw/G1,.6*fuw/G2),
        W_web_Neq_elastic=neq,W_web_local_yield_R=1.10*(5*k+B)*fyw*tw/G1,
        W_web_normal_u=neq/(1.10*(5*k+B)*fyw*tw/G1),
        W_longitudinal_shear_yield_u=abs(vr)/(.6*B*tw*fyw/G1),
        W_longitudinal_shear_rupture_u=abs(vr)/(.6*B*tw*fuw/G2),
        W_web_VM_u=math.sqrt((max(map(abs,qn))/tw)**2+3*(1.5*abs(vr)/(B*tw))**2)/(fyw/G1),
        flange_footprint=tp+2*sr,flange_bending_exempt=tp+2*sr<.15*bf,
        closest_W_end=1000-B/2,W_centroid_M=mr-dw*vr/2,transverse_member_shear_jump=nr)
    allu=dict(angle_yield=N/(count*Ag*fy/G1),angle_net=N/(count*Ct*An*fu/G2),bolt_shear=N/(count*n*Rplane),
      angle_bearing=max(z['utilization'] for z in angle_bear),plate_bearing=max(z['utilization'] for z in plate_bear),
      angle_block=max(z['utilization'] for z in angle_blocks),plate_block=max(z['utilization'] for z in plate_blocks),
      Whitmore_yield=whit['yield_utilization'],Whitmore_net=whit['net_utilization'],
      normal_net_yield=max(z['yield_utilization'] for z in normal_cuts),normal_net_rupture=max(z['rupture_utilization'] for z in normal_cuts),
      nominal_perforated_yield=max(z['max_VM']['utilization_yield'] for z in results),nominal_perforated_rupture=max(z['max_rupture']['utilization_rupture'] for z in results),
      root_weld=root['weld_utilization'],root_gusset_contact=max(v for k,v in root['gusset_contact'].items() if k.endswith('_u')),root_W_contact=max(v for k,v in root['W_contact'].items() if k.endswith('_u')),
      W_flange_shear=root['W_flange_shear_u'],W_web_normal=root['W_web_normal_u'],W_longitudinal_shear=max(root['W_longitudinal_shear_yield_u'],root['W_longitudinal_shear_rupture_u']),W_web_VM=root['W_web_VM_u'])
    return dict(id=f'NEW_{count}L_{theta:g}DEG_{N:g}N',inputs=dict(angle_count=count,topology='2L-T' if count==2 else '1L',N=N,theta=theta,angle_catalog='GERDAU_EQUAL_ANGLE_P03_R29',b=b,t_angle=ta,Ag_one=Ag,ec=ec,gauge=g,angle_end=e,materials=dict(angle=[fy,fu],gusset=[fyp,fup],W=[fyw,fuw],bolt_fub=830,weld_fw=fw),plate=[B,H,tp],root=[[-B/2,0],[B/2,0]],P=P,bolt_centers=holes,bolt_diameter=d,hole_diameter=dh,net_deduction=dn,drilled=drilled,bolt_planes=count,threads_in_all_planes=True,W=dict(d=dw,bf=bf,tf=tf,tw=tw,k=k,ends=[-1000,1000])),
      angle=dict(Ct=Ct,An_one=An,yield_R_total=count*Ag*fy/G1,net_R_total=count*Ct*An*fu/G2),bolts=dict(Ab=Ar,R_per_plane=Rplane,force_each_plane=N/(count*n),group_R=count*n*Rplane,grip_without_washers=count*ta+tp),
      bearing=dict(angle=angle_bear,gusset=plate_bear),angle_blocks=angle_blocks,gusset_blocks=plate_blocks,Whitmore=whit,force_normal_cuts=normal_cuts,
      horizontal_sections=dict(model='nominal net-section beam stress screen with uncertain hole-crossing point-load jump envelope; not exact continuum stress/contact solution',min_sigma=min(z['min_sigma']['sigma_min'] for z in results),intervals=results),root=root,utilizations=allu,
      checks_all_below_one=max(allu.values())<1,normal_tension_domain=min(z['min_sigma']['sigma_min'] for z in results)>=-1e-8,
      limitations=['No production code imported.','Method-level only; fabrication and member-global verification not granted.','k_heel/tool clearance is a separately declared real detail input, never invented from Gerdau gyration radii.'])

# Published-source arithmetic replay retains source factors and is NOT an NBR implementation oracle.
Ar=math.pi*.875**2/4;bolt=.75*54*Ar*2
endG=.75*1.2*(1.5-.9375/2)*.5*58
endA=.75*1.2*(1.5-.9375/2)*.375*2*58
N,V,M,t,B=50.5,86.3,123.,.625,22.
sn=N/(t*B);sm=M/(t*B*B/4);tau=V/(t*B);qp=math.hypot(sn+sm,tau);qa=(qp+math.hypot(sn-sm,tau))/2
published=dict(id='NEW_RECALC_DG29_EX5_4',source='DG29 printed99–108 / PDF107–116',factors='AISC360-10 LRFD, retained solely for reference reproduction',Ag_pair=5.72,An_pair=5.72-2*.375*1.0,U=1-1.13/6,bolt_double_shear_kip=bolt,
  effective_end_gusset_kip=endG,effective_middle_kip=bolt,effective_end_angles_kip=endA,effective_group_kip=endG+bolt+endA,
  gusset_block_R_kip=.75*min(.6*58*2.50+58*2.25,.6*36*3.75+58*2.25),Whitmore_width_in=12*math.tan(math.pi/6),Whitmore_yield_R_kip=.9*36*.5*12*math.tan(math.pi/6),
  root_normal_kip=N,root_shear_kip=V,root_moment_kip_in=M,root_plastic_normal_stress_ksi=sn+sm,root_shear_stress_ksi=tau,root_peak_ksi=qp,root_average_ksi=qa,root_design_ksi=max(qp,1.25*qa),root_web_Nequiv_plastic_kip=N+4*M/B,
  warning='Published end forces intentionally unequal after capacity redistribution. New NBR fixture assumes uniform force and checks every hole; do not calibrate one model against the other. Source uses plastic4M/B; new elastic root uses6M/B. Source changed gusset0.5in to0.625in for compression, which is excluded from the new family.')
fx=[fixture(),fixture(theta=90),fixture(count=1),fixture(N=200000),fixture(theta=100),fixture(fyp=345,fup=450),fixture(drilled=False)]
fx[5]['id']='NEW_2L_80DEG_100000N_GUSSET_A57250'
fx[6]['id']='NEW_2L_80DEG_100000N_NONDRILLED_NET20'
# Pure geometry adversarial domains. Strength-only source example is not reused as a full project.
neg=[fixture(theta=75),fixture(B=400)]
neg[1]['id']='NEW_2L_80DEG_100000N_B400_EDGE_FAIL'
for f in fx:print(f['id'],max(f['utilizations'],key=f['utilizations'].get),max(f['utilizations'].values()),f['root']['M'],f['horizontal_sections']['min_sigma'])
# Tool access is deliberately an additional fixture dimension, not a catalog radius.
for f in fx+neg:
    inp=f['inputs'];plate=inp['plate'];holes=inp['bolt_centers'];ta=inp['t_angle'];g=inp['gauge'];b=inp['b'];dh=inp['hole_diameter'];d=inp['bolt_diameter']
    detail=dict(nominal_inner_heel_extent_declared_mm=12.35,heel_extent_provenance='additional fixture/detail input: k_heel=t+6; 6 mm is NOT claimed to be a Gerdau catalog radius',tool_radius_mm=18,clearance_mm=2,
       access_margin_mm=g-12.35-20,angle_toe_center_edge=b-g,angle_end_center_edge=35.,pitch=50.,minimum_pitch=2.7*d,minimum_clear_hole_spacing=d,
       actual_clear_hole_spacing=50.-dh,table16_min_edge=22.,plate_min_center_edge=min(min(x+plate[0]/2,plate[0]/2-x,y,plate[1]-y) for x,y in holes),
       maximum_free_side_center_distance=max(max(plate[0]/2-min(x for x,y in holes),plate[0]/2+max(x for x,y in holes)),plate[1]-max(y for x,y in holes)),
       plate_maximum_permitted_edge=min(12*plate[2],150.),root_minimum_fillet=5.,root_actual_fillet=5.,root_ordinary_max_fillet=plate[2]-1.5,
       root_longitudinal_weld_length=plate[0],flange_bending_exemption_limit=.15*inp['W']['bf'])
    # NBR6.3.12 uses nearest fastener to each free edge, NOT the farthest hole.
    detail['maximum_free_side_center_distance']=max(min(x+plate[0]/2 for x,y in holes),min(plate[0]/2-x for x,y in holes),min(plate[1]-y for x,y in holes))
    detail['bolt_edge_domain']=detail['maximum_free_side_center_distance']<=detail['plate_maximum_permitted_edge']
    detail['tool_access_input_sufficient']=detail['access_margin_mm']>=0
    detail['tool_access_catalog_verified']=False
    f['detailing']=detail
    f['full_method_pass_given_declared_detail']=f['checks_all_below_one'] and f['normal_tension_domain'] and detail['bolt_edge_domain'] and detail['tool_access_input_sufficient']
failures=[]
for key,u in fx[0]['utilizations'].items():
    scale=1.01/u
    failures.append(dict(id='SAME_GEOMETRY_FAIL_'+key,target=key,N=100000*scale,scale=scale,target_utilization=1.01,all_utilizations={k:v*scale for k,v in fx[0]['utilizations'].items()},note='New same-geometry concurrent load-scaling reference; all demands scale together, not an isolated force edit.'))
sources={}
for label,path in [('NBR','baseplate_references/Automação MC/NBR 8800-24-25-projeto-de-estruturas-de-aco-e-de-estruturas-mistas-20250710-000231_compress.pdf'),('DG29','welded_gusset_scope/source/348443843-AISC-Design-Guide-29-Vertical-Bracing-Connections-pdf.pdf'),('Gerdau','gerdau_catalog_audit/Barras-e-Perfis-Tabela-de-bolso-Gerdau.pdf')]:
    sources[label]=dict(path=path,sha256=hashlib.sha256(Path(path).read_bytes()).hexdigest())
obj=dict(created='2026-10-11',origin='NEW independent source-derived calculations',historical_oracle_recovered=False,production_imports=False,source_files=sources,published_source_replay=published,fixtures=fx,adversarial_geometry=neg,same_geometry_failure_cases=failures)
(OUT/'NEW_COMPLETE_BOLTED_FIXTURES.json').write_text(json.dumps(obj,indent=2)+'\n')
assert fx[0]['checks_all_below_one'] and fx[0]['normal_tension_domain']
assert fx[1]['root']['M']<1e-6 and fx[1]['normal_tension_domain']
assert fx[2]['checks_all_below_one']
assert math.isclose(fx[0]['bolts']['group_R'],2*fx[2]['bolts']['group_R'])
assert math.isclose(fx[0]['root']['weld_utilization'],fx[2]['root']['weld_utilization'])
assert fx[3]['utilizations']['root_weld']>1
assert math.isclose(fx[0]['root']['M'],-fx[4]['root']['M'])
assert math.isclose(fx[0]['angle']['net_R_total'],fx[5]['angle']['net_R_total'])
assert fx[6]['angle']['net_R_total']<fx[0]['angle']['net_R_total']
assert not neg[0]['normal_tension_domain']
assert not neg[1]['detailing']['bolt_edge_domain']
assert len({f['id'] for f in fx+neg})==len(fx+neg)
print('Internal source-arithmetic consistency assertions PASS')
