# Revisão independente: interface 2L-T parafusada e extensão 1L

Data: 11/10/2026. Revisão de método e fixtures, sem alteração de produção e sem autorização para fabricação ou execução.

## Veredito

**GO de método para a ligação completa convencional 2L-T -> parafusos compartilhados -> gusset retangular -> dois filetes de raiz -> mesa exterior W**, dentro das hipóteses declaradas e das verificações geométricas e resistentes abaixo. Não há motivo técnico identificado para impor uma nova exigência genérica de MEF. O ângulo relativo ao W pode continuar variável: o caso oblíquo de 80 graus foi recalculado independentemente, e 90/100 graus são regressões distintas. Isto não significa aprovação automática de toda posição, inclinação, chapa ou caminho de ruptura.

**GO de método para 1L**, usando explicitamente a idealização estática do eixo nominal permitida pela NBR 6.1.8.2. A única L recebe N, cada parafuso tem um plano físico com N/n, e a chapa/raiz continuam recebendo N total. A disposição de uma face não tem a simetria física fora do plano de 2L-T. Sua excentricidade de extremidade é desprezada pela hipótese normativa; não deve ser descrita como fisicamente nula. Esta extensão não cobre fadiga, reversão cíclica, ações espaciais impostas, torção ou outro comportamento fora dessa idealização.

O **GO é do método convencional de estados-limite**. A aprovação geométrica de montagem do exemplo Gerdau exige um raio/envelope real informado ou uma condição dimensional explícita. O catálogo fornecido não publica o raio interno.

## Fontes efetivamente verificadas

- AISC DG29, arquivo PDF fornecido: exemplo 5.4, PDF106–116 / impresso98–108. A figura5-10 foi inspecionada visualmente; o exemplo tem duas L aparafusadas à mesma chapa, chapa soldada a uma mesa W, carga oblíqua e momento na interface. A geometria publicada é recortada; suas capacidades não são um oráculo do retângulo novo.
- DG29 PDF107–110 / impresso99–102: tração bruta/líquida das L, shear lag, parafusos em corte duplo, contato de chapa/L com sentidos opostos e distribuição por capacidades individuais no exemplo publicado.
- DG29 PDF110–113 / impresso102–105: bloco da chapa até borda livre, Whitmore e bloco das L. O exemplo publicado usa fatores AISC e também compressão; o ramo novo conserva fatores NBR e exclui compressão.
- DG29 PDF114–116 / impresso106–108: equilíbrio da interface, tração/cisalhamento da chapa, solda com maior entre pico e1,25média e escoamento local da alma. O termo plástico publicado4M/B não substitui silenciosamente o termo elástico6M/B do modelo novo.
- NBR8800:2024 + Errata1:2025 fornecida: PDF61–64 / impresso39–42 (§5.2); PDF93 / impresso71 (§6.1.8.2); PDF106–107 / impresso84–85 (§6.3.3); PDF116–118 / impresso94–96 (§6.5). Figura16 foi inspecionada visualmente. Os arquivos OCR auxiliares foram conferidos com imagens relevantes do PDF original.
- Gerdau, tabela de bolso fornecida, PDF3, inspecionada visualmente: L76,2x6,35, área929mm² e centroide21,3mm por L; não confundir com o antigo b76 nem inferir raio do contorno a partir de raios de giração. A página2 identifica dimensões nominais sujeitas a tolerâncias.

## O que fecha a transferência parafusada

A sequência convencional é: L bruta/líquida efetiva -> cada plano do parafuso -> cada contato direcional -> blocos reais de L e chapa -> seção Whitmore contida -> seções líquidas reais -> trecho até a raiz -> raiz e efeitos locais no W. Ela precisa ser recalculada com os materiais reais de cada componente. Não se compõem dois resultados legados já aprovados e não se usa o corte terminal centrado do componente axial como substituto da chapa completa.

Para os três parafusos igualmente solicitados, cada plano de 2L recebe N/6, cada parede de furo de cada L recebe N/6 e a chapa comum recebe N/3. O contato sobre as L aponta para a extremidade livre em -u; na chapa aponta para +u. O exemplo DG29 redistribui forças conforme capacidades individuais: isso é outra hipótese, não autorização para ignorar uma falha de um furo no fixture de distribuição uniforme.

Os blocos das L usam k=1,2,3 até a extremidade real: Lv=35+(k-1)50. O caminho de ponta conectada usa largura36,2mm antes da dedução; o outro deve atravessar o encontro das abas e alcançar a outra ponta. O talão não é borda livre. A formulação nova por complemento de área de catálogo, subtraindo a faixa nominal de ponta, é identificada como complemento nominal conservador, e não como medição de um contorno arredondado desconhecido.

Na chapa, a linha longitudinal avança até a borda realmente encontrada pelo raio +u; as tampas transversais devem terminar em bordas livres efetivas. Cada caminho lateral é uma alternativa com toda a força dos parafusos capturados; não se somam capacidades coincidentes. Em outras geometrias, um bloco que ainda retém comprimento de raiz apoiada é inadmissível, não uma borda livre fictícia. A verificação de interseção com o segmento de raiz deve acompanhar a generalização do código além dos fixtures atuais.

Cts=0,5 utilizado pelo novo fixture é conservador em relação aos exemplos de linha única Cts=1 da Figura16 e ao Ubs=1 adotado no exemplo DG29. Ambas as parcelas do bloco usam gamma_a2. Não é preciso introduzir uma busca universal por todas as superfícies possíveis de trinca para aplicar esse modelo convencional de estados-limite.

## Seções perfuradas: separar dados exatos de hipótese de tensões

As forças/resultantes de cada parafuso, os saltos de resultante e as áreas/centroides/inércias das seções líquidas são dados geométricos ou de equilíbrio bem definidos. Na representação de força pontual, ambos os lados de cada estação precisam ser conservados; numa faixa que corta um furo, o envelope com/sem a força daquele parafuso evita escolher implicitamente uma distribuição de contato desconhecida.

As expressões sigma=N/A+M(x-xc)/I e tau=1,5V/A, entretanto, são **triagens nominais complementares**, não uma solução elástica exata em torno de furos. O fator1,5 de uma seção retangular maciça não prova o cisalhamento local de uma seção interrompida por um furo. Amostrar/otimizar essas expressões não transforma a hipótese em prova de campo contínuo, nem prova ausência de qualquer pequena região local comprimida.

É aceitável manter a triagem de sinais e resistência com esse significado declarado, juntamente com Whitmore, contato, rasgamento e seções líquidas. Não é aceitável remover os últimos e declarar que os cortes de largura integral sozinhos provaram a introdução local. A liberação resultante é do método convencional; não é uma prova universal de estabilidade de placa fina.

Para furos broqueados dn=18mm; na alternativa não broqueada dn=20mm é a dedução normativa de seção líquida. Este segundo círculo é uma geometria nominal de dedução, não um furo físico de20mm. Os cálculos de contato mantêm o furo físico18mm.

## Recomputação independente do caso80 graus

Caso: N100kN; B240/H300/t12,5; P(0,150); parafusos u=-50,0,50; furos18 broqueados; Gerdau R29; aços das L e chapa250/400MPa; parafusos830MPa; raiz dupla5mm E60; W do contrato existente.

- Furos: (-8,682408883;100,759612349), (0;150), (8,682408883;199,240387651)mm.
- Raiz: N98,480775301kN; V17,364817767kN; M-2,604722665kN.m.
- Par2L: Ag1858; An1629,4mm²; Ct0,787; escoamento422,272727273kN; ruptura efetiva379,951940741kN.
- Whitmore: largura115,470053838mm, extremos(-65,540311014;110,785194561) e(48,175493247;90,734030137), ambos contidos. Capacidade bruta328,039925676kN; líquida suplementar361,000199400kN.
- Cada plano do parafuso: resistência55,627133920kN; demanda16,666666667kN.
- Contato extremo de cada L:58,702222222kN; demanda16,666666667kN.
- Com Cts0,5, utilização máxima de bloco da L0,4137766158; da chapa0,2111269054.
- Triagem nominal de cortes: sigma máxima54,532947309MPa, VM complementar56,568498427MPa, utilização0,2489013931; mínimo nominal zero nas regiões sem resultante.
- Solda da raiz: utilização0,5255949245, governante do conjunto de verificações resistentes do fixture.
- A1L do mesmo caso conserva raiz e chapa; suas solicitações de L/plano dobram e blocoL governa0,8275532316.
- N200kN no2L: raiz1,0511898491, falha expressa.

Arquivos independentes nesta pasta: `independent_review_calc.py`, `INDEPENDENT_ARITHMETIC_80.json` e `PARENT_FIXTURE_CROSSCHECK.json`. Não importam código de produção. O primeiro usa Cts1 para confronto de fonte; o último recompõe os blocos Cts0,5 do fixture do autor. Não são recuperação do oráculo histórico ausente.

## Condições e correções antes de chamar um exemplo de integralmente elegível

1. O envelope de acesso requer g-t-r >= raio_ferramenta+folga. Com g40,t6,35,ferramenta18,folga2: **r <=13,65mm**. Raio6mm pode ser hipótese declarada do novo fixture, com origem de detalhe manual; não é valor publicado pelo catálogo. Sem essa declaração/medição, a mecânica pode passar enquanto a montagem permanece pendente.
2. Conservar folgas à raiz, pontas/arruelas/ferramentas, passos e bordas mínimos/máximos, pega, extremos reais do W e detalhe da solda. Um fixture B400 com chapa12,5mm não fica aprovado apenas porque resistências passam; seu limite de borda precisa ser testado e exposto separadamente.
3. Preservar propriedades independentes de L, chapa, W, parafuso e eletrodo. O total real não muda ao escolher1L/2L, e o mínimo45kN é caso da ligação inteira, repartido depois.
4. Foram encontrados identificadores repetidos nos casos de aço de chapa alterado e furo não broqueado. Exigir IDs únicos antes de usá-los como chaves de regressão. Isto é uma correção de artefato, não falha da equação resistente.
5. Uma implementação variável em theta precisa executar as interseções/caminhos e triagens em cada entrada, com ramo regular em90 graus e preservação do sinal de V/M. As verificações positivas em80/90/100 e negativas em75 não concedem aprovação a uma faixa irrestrita por interpolação.
6. Os resultados de otimização escalar são uma verificação numérica independente da triagem; não devem receber o nome de certificação por intervalos. Se for necessário declarar extremos matematicamente certificados dessa triagem, essa certificação exige procedimento próprio.

**Conclusão:** método completo convencional qualificado para implementar e testar a família delimitada, se autorizado. Nenhuma falha mecânica do novo caso80 graus foi identificada. O único dado físico não publicado que impede afirmar montagem verificada sem hipótese adicional é o envelope do raio interno/ferramenta; o critério exato está acima. Produção, montagem real e estrutura global continuam fora desta revisão.
