# Independent engine acceptance: 0.9.30 gusset variants

GO for the bounded opposed-welded and complete bolted 1L/2L-T engines at the exact hashes in ENGINE_ACCEPTANCE.json. `passed` is true.

Independent source-derived calculations covered total versus per-angle/per-plane force, signed root equilibrium and W-centroid transport, physical four-line clipping and partial capture, independently reconstructed section extrema, actual net-hole geometry, individual contact, alternative block paths, clipped Whitmore, materials, minimum cases, detail gates, root substrate thickness, and peak versus weld-average demands. No production calculator or fixture generator was used as the independent arithmetic oracle.

20 opposed whole-case variants passed 23,674 assertions. 29 bolted whole-route variants passed 37,111 assertions. A separate numerical cap-envelope reconstruction passed 2,122 assertions across 13 variants. Nine fresh bolted fixture geometries also passed 540 primitive arithmetic checks.

Two review findings were corrected: internal circular-hole cap extrema (including the first lower half-hole), and exhausted grip-factor input classification. The principal bolted full cap envelope is 0.212268705525; its unchanged conventional centered-path witness is 0.211126905388. The root weld still governs at 0.5255949245. Explicit pre/post crossing-hole force limits are conservative model bounds, not a microscopic contact-pressure solution. Original qualification files were not rewritten to hide the stronger check.

All 817 files in the frozen 0.9.29 source remain intact. Complete outputs of 24 relevant legacy presets are byte-identical by canonical digest. The 16 old load-convention records, descriptions, axial-state responses, and 128 SVG variants remain identical. Shared mechanics/catalog dependencies are unchanged; models.py only changes VERSION metadata.

This verdict excludes opposed bolted, UI/report/package acceptance, publication, fabrication, field verification, and global member/structure approval. The missing historical external bolt-bearing fixture remains missing. New independent calculations are not represented as that old fixture.
