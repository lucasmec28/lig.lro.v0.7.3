"""Independent arithmetic review, no production imports or production edits.
N, mm, MPa. Perforated-section stresses are supplementary nominal screens.
"""
from math import *
import json
from pathlib import Path
from scipy.optimize import minimize_scalar

OUT=Path(__file__).parent
N=100000.; B=240.; H=300.; tp=12.5; theta=radians(80)
C=cos(theta); S=sin(theta); dh=dn=18.; r=dh/2
fy=250.; fu=400.; ga1=1.1; ga2=1.35
p=50.; n=3; bL=76.2; tL=6.35; AgL=929.; ec=21.3; g=40.; eL=35
bolts=[dict(index=i+1,u=u,x=u*C,y=150+u*S) for i,u in enumerate([-50.,0.,50.])]
def Rblock(Agv,Anv,Ant):
    return min(.6*fu*Anv+fu*Ant,.6*fy*Agv+fu*Ant)/ga2

def section(y,count):
    chords=[dict(x=p['x'],width=2*sqrt(max(0.,r*r-(y-p['y'])**2))) for p in bolts if abs(y-p['y'])<=r]
    width=B-sum(q['width'] for q in chords)
    A=tp*width
    xc=-sum(q['x']*q['width'] for q in chords)/width
    I0=tp*(B**3/12-sum(q['width']*q['x']**2+q['width']**3/12 for q in chords))
    I=I0-A*xc*xc
    Nr=N*count/n*S; Vr=N*count/n*C
    M=N*count/n*(-xc*S-(150-y)*C)
    sigma=[Nr/A+M*(x-xc)/I for x in (-B/2,B/2)]
    tau=1.5*abs(Vr)/A
    return dict(y=y,enclosed_bolt_count=count,chords=chords,A=A,xc=xc,I=I,N=Nr,V=Vr,M=M,sigma_edges=sigma,
                tau_supplementary=tau,vm_supplementary=hypot(max(map(abs,sigma)),sqrt(3)*tau))

angle_blocks=[]
for k in range(1,n+1):
    Lv=eL+(k-1)*p
    for name,w in [('connected_toe',bL-g),('far_toe_unfolded',g+bL-tL)]:
        Agv=Lv*tL;Anv=(Lv-(k-.5)*dn)*tL;Ant=(w-dn/2)*tL
        R=Rblock(Agv,Anv,Ant); D=N*k/(2*n)
        angle_blocks.append(dict(k=k,path=name,Lv=Lv,width=w,Agv=Agv,Anv=Anv,Ant=Ant,R=R,D_per_angle=D,utilization=D/R))

gusset_blocks=[]
ue=150/S
for j,bolt in enumerate(bolts):
    k=n-j; uj=bolt['u'];Lv=ue-uj
    vlo=(-B/2-uj*C)/S;vhi=(B/2-uj*C)/S
    for name,ve in [('negative_v',vlo),('positive_v',vhi)]:
        width=abs(ve); Agv=Lv*tp;Anv=(Lv-(k-.5)*dn)*tp;Ant=(width-dn/2)*tp
        R=Rblock(Agv,Anv,Ant);D=N*k/n
        gusset_blocks.append(dict(k=k,path=name,u=uj,shear_exit=[ue*C,300],transverse_exit=[uj*C+ve*S,150+uj*S-ve*C],
                                  Lv=Lv,width=width,Agv=Agv,Anv=Anv,Ant=Ant,R=R,D=D,utilization=D/R))

# Diagnostic stationary searches of smooth arc parameterizations; independent
# crosscheck only, not an interval-certified continuum stress-field solution.
cuts=[section(0,3),section(H,0)]
for j,bolt in enumerate(bolts):
    for count in [n-j,n-j-1]:
        for phi in [-pi/2,0,pi/2]:cuts.append(section(bolt['y']+r*sin(phi),count))
        for obj in ['max_sigma','min_sigma','vm']:
            def f(phi):
                row=section(bolt['y']+r*sin(phi),count)
                return {'max_sigma':-max(row['sigma_edges']),'min_sigma':min(row['sigma_edges']),
                        'vm':-row['vm_supplementary']}[obj]
            opt=minimize_scalar(f,bounds=(-pi/2+1e-8,pi/2-1e-8),method='bounded',options={'xatol':1e-13})
            row=section(bolt['y']+r*sin(opt.x),count);row.update(search=obj,optimizer_success=bool(opt.success));cuts.append(row)

bearing=[]
for j,bolt in enumerate(bolts):
    lcL=eL-dh/2 if j==0 else p-dh
    lcG=ue-bolt['u']-dh/2 if j==n-1 else p-dh
    for component,t,lc,D in [('L_each',tL,lcL,N/(2*n)),('gusset',tp,lcG,N/n)]:
        R=min(1.2*lc*t*fu,2.4*16*t*fu)/ga2
        bearing.append(dict(bolt=j+1,component=component,lc=lc,R=R,D=D,utilization=D/R))

lw=2*(n-1)*p*tan(pi/6)
ct=max(1-ec/((n-1)*p),.5)
result=dict(scope='Independent finite arithmetic review; conventional design method, not construction approval',
    source_convention='NBR8800:2024+Errata2025 resistances; DG29 Ex5.4 load path and Whitmore model',
    inputs=dict(N=N,B=B,H=H,tp=tp,theta_deg=80,bolt_diameter=16,dh=dh,dn=dn,drilled=True,fyL=fy,fuL=fu,fyG=fy,fuG=fu,
                angle=dict(catalog='Gerdau R29',b=bL,t=tL,Ag=AgL,ec=ec,gauge=g,free_end_u=-85)),
    bolts=bolts,root=dict(N=N*S,V=N*C,M=-150*N*C),
    angle_pair=dict(Ag=2*AgL,An=2*(AgL-dn*tL),Ct=ct,yield_R=2*AgL*fy/ga1,fracture_R=2*(AgL-dn*tL)*ct*fu/ga2),
    whitmore=dict(width=lw,gross_A=lw*tp,net_A=(lw-dn)*tp,yield_R=lw*tp*fy/ga1,fracture_R=(lw-dn)*tp*fu/ga2,
                  endpoints=[[bolts[0]['x']+v*S,bolts[0]['y']-v*C] for v in [-lw/2,lw/2]]),
    bolt_shear=dict(R_per_plane=.45*pi*16**2/4*830/ga2,D_per_plane=N/(2*n),grip=2*tL+tp),
    bearing=bearing,angle_blocks=angle_blocks,gusset_blocks=gusset_blocks,
    geometry_condition=dict(root_radius_max_for_tool=40-6.35-20,tool_radius=18,clearance=2,
                            warning='Root radius unavailable in catalog; inequality is an acceptance condition, not a verified physical fact'),
    diagnostic_cuts=cuts,
    cut_summary=dict(max_normal=max(max(q['sigma_edges']) for q in cuts),min_normal=min(min(q['sigma_edges']) for q in cuts),
                     max_vm_supplementary=max(q['vm_supplementary'] for q in cuts),
                     disclaimer='Exact area/resultants; nominal N/A+M/I and 1.5V/A screen, not exact local hole stress or stability proof'))
(OUT/'INDEPENDENT_ARITHMETIC_80.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['root','angle_pair','whitmore','cut_summary']},indent=2))
