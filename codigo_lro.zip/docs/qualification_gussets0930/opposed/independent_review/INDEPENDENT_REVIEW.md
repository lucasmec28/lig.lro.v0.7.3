# Independent opposed-angle welded fixture review

11 October 2026. Read-only review of the emitted new fixture and a separate arithmetic reconstruction. No application runtime, application module, or fixture generator was imported. The only writes were made in this independent-review directory. The approved OPPOSED_SECTION.png was visually inspected.

## Decision

**GO for the selected bounded planar method: geometry, equilibrium, sectional signs, component arithmetic, and ordinary rupture-path accounting pass.** No numerical or geometrical correction is required in the reviewed fixture. The final `QUALIFICATION.md` and the completed dedicated `../eccentricity_review/REVIEW.md` were read. Their explicit adoption of NBR 6.1.8.2 per angle is consistent with the model reviewed here and closes that separately assigned source/model decision; it is no longer a pending research gate. This review does not establish that physical local out-of-plane couples vanish, and the new half-thickness bookkeeping screen is not a three-dimensional stress solution.

The result is a bounded method qualification for this static-tension example, not approval for fabrication, the complete W member, intermediate interconnectors, fatigue, compression, or arbitrary thin/other gusset geometry. No generic finite-element-analysis gate is imposed.

## Independence and validation

- `recompute_independent.py` reconstructs equilibrium, all section polynomials and their extrema, ten initial contiguous U-blocks, side/corner paths, each angle's rounded paths, four line contacts, the local introduction strip, root and receiving W.
- `INDEPENDENT_NUMBERS.json` contains that reconstruction.
- `validate_emitted_fixture.py` reads only the final emitted JSON. It independently checks force allocation, transformed line endpoints, section polynomials against direct line-force integration, path areas against the actual drawn vertices, captured partial demands, material/factor arithmetic, all reported utilization families, and 76 named-path negative-load scalings.
- `EMITTED_FIXTURE_VALIDATION.json` records **9,661 checks, zero failures**, the three fixture IDs, and the reviewed file SHA-256. The baseline, N330 kN shared-plate failure, and theta105-degree mirror all pass this validation. This is independent fixture validation, not a claim that application implementation tests have run.

## Concrete findings at N120 kN

The four physical weld lines at v = -106, -6, +6, +106 mm carry 17.4, 42.6, 42.6, 17.4 kN respectively. Each angle receives 60 kN. Their first moments sum to zero both in v and z globally. They must remain four separate projected loads: collapsing them onto the two T-detail lines changes internal cuts and rupture paths.

Root actions are Nn = 115.911099155 kN, Vs = 31.058285412 kN, and Mz = -6.056365655 kN·m. The root has one plate area of 6,480 mm² and two welds. Its edge normal stresses are +7.502800529 and +28.272230074 MPa.

At a horizontal cut n = y, each remaining line force is its full force multiplied by clamp[(n_end-y)/(240 sin75°), 0, 1]. Its in-plane contribution about the section center is F_remaining [v + (y-195) cos75°]. This gives piecewise-linear N/V and piecewise-quadratic M, with nine intervals including the unloaded top tail. Both edge-stress polynomials and the concurrent von Mises polynomial were checked at endpoints and any real internal stationary points.

- Whole-plate minimum normal stress is numerical zero at the last loaded termination n338.345917936 mm. Every nonzero modeled section remains tensile.
- Maximum concurrent VM is 30.893076626 MPa at the root, utilization 0.135929537.
- The centered 260 mm introduction strip has endpoints (-156.628642830,112.735376709) and (94.512072005,45.442424982) mm, both inside the actual plate. Its width exceeds the 222 mm physical footprint by 19 mm per side, a 4.526475-degree spread over the 240 mm transfer length.
- Aggregate local normal stress is 38.461538462 MPa. The disclosed full-t effective-strip Ct adaptation is 0.700831947, giving yield utilization 0.169230769 and adapted rupture utilization 0.185219428.
- The supplemental per-face allocation uses **6 mm + 6 mm of the same 12 mm plate**, N/2 each, v-centroid eccentricity ±35 mm, and the same full-t Ct for a conservative bound. Its stresses are +7.396449704/+69.526627219 MPa; yield/rupture utilizations are 0.305917160/0.334819735. No second physical plate or extra capacity is created.
- As an additional independent diagnostic, full-width horizontal cuts of each allocated half-thickness also remain tensile. The negative-face field has an interior normal stationary point at n157.157404366 mm, stress 5.616472596 MPa; maximum VM is 37.595998194 MPa at the root. These supplementary half-thickness calculations are consistent with, but do not replace, the separate treatment of physical out-of-plane transfer.

## Four-line rupture and contact accounting

There are ten contiguous nonempty subsets of four ordered weld footprints. The emitted fixture explicitly records these U families at the controlling finite stations, left-prefix and right-suffix L families, and a separately identified conservative path envelope. The 66 records comprise 65 polygon-based candidates and one conservative lower bound, not 66 different physical cracks.

The critical topology stations are u = -120, -118.474393949 (bottom-right corner), +108.815135686 (top-left corner), and +120 mm. At u = -120 the rightward tension ray reaches the supported root, not the free right side; those candidates are excluded and logged. The first right-free-side limit is the bottom-right corner and uses partial demand. Forward shear extensions reach the free top for the selected footprint bounds. Interior station demand and capacity are linear within each fixed topology, so their ratio is monotonic or constant; the zero-demand forward endpoint need not produce a capacity-controlling record. Disjoint unions cannot exceed the maximum ratio of their separately checked components.

Both footprint-edge and weld-root-side cuts are included conservatively where applicable. Areas match the drawn cut lengths times the **single** plate thickness; captured forces are summed across whichever of the four lines lie in the selected block. Crossed weld resistance is omitted rather than silently added. Root-connected material is never treated as a free edge.

The conservative ordinary-path plate envelope assigns all 120 kN to one 240 × 12 mm shear plane and discards transverse capacity. Its resistance is 320 kN and utilization 0.375. It is an explicitly conservative screening envelope, not a newly asserted exact crack. It governs this fixture. The old T-detail capacity was not reused.

Each L has its own 60 kN demand, Ct = 1-29/240 = 0.879166667, catalog Ag = 2,270 mm², and actual rounded paths. The rounded toe retains 6 mm flat thickness. Each angle's ordinary-path lower envelope has resistance 176 kN and utilization 0.340909091. Each physical 5 mm × 240 mm contact is checked separately against its own angle and gusset material. Heel-weld utilization is 0.272193514; the governing line-substrate utilization is 0.260333333 on the gusset side. There is no doubling of plate area, merging of physically distinct line contacts, or replacement of angle shear lag by the zero pair-centroid eccentricity.

## Root and W

The independent endpoint root tractions are qn = 339.266760891/90.033606348 N/mm and qs = 57.515343356 N/mm. Peak resultant 344.107468340 N/mm controls over 1.25 times the endpoint-vector average. Two 6 mm root fillets give utilization 0.219868124.

Gusset and W contact checks correctly use normal-plus-shear interaction, with depths min(12,2×6) = 12 mm and 2×6 = 12 mm respectively. They do not apply the weld overstrength factor as pure base-metal shear. The W flange punch screen uses the elastic peak resultant, not the weld design multiplier.

The actual loaded flange footprint is 24 mm, below 0.15bf = 25.05 mm, so the flange-bending exemption applies to this exact detail. The nearest loaded-root point is 930 mm from a support end; the normal far-end web-yield branch is valid. The elastic normal equivalent is 183.204050881 kN against web local yielding 1,693.812 kN. Longitudinal shear yielding/rupture are 772.298181818/820.800 kN against 31.058285412 kN. The local W VM utilization is 0.155525786. No compression-only mode is activated by these all-tensile root tractions.

The exported transverse member-shear jump is 115.911099155 kN; the transported moment at the W centroid is -10.979103893 kN·m. Existing member actions are not assumed zero. These exports and the longitudinal interface shear have distinct meanings.

## Physical local couples and stopping point

At n195 mm the physical surface-force first moment is sum(zF) = -28,134.665205 N·mm, giving Ms = +27,175.999736 N·mm and Mn = -7,281.787183 N·mm under the stated axes. This is nonzero even though the global root out-of-plane resultant vanishes. The fixture appropriately labels the physical surface-couple diagnostic separately from the qualified planar idealization. The completed parallel source/model review accepts that explicit bounded engineering application of the exception; nothing in this numerical review may be quoted as proof of physical cancellation.

At N330 kN, the single-plate conservative envelope is 1.03125 while the angle envelope is 0.9375. That is a useful shared-plate screening failure. It is not a claim of measured ultimate strength. At theta105 degrees, Vs and M reverse and the relevant mirrored geometry and capacity results remain consistent. All 76 named-path scaled failures independently reach their intended ratio 1.01.

No further geometry, numerical, or ordinary-path correction is required for the reviewed fixture. Application implementation, serialization, drawing/report integration, force-minimum options, and adversarial runtime regressions remain future engineering work if authorized; none was performed in this review.

## Final contract read

The final `QUALIFICATION.md` is consistent with the emitted fixture, independent arithmetic, actual footprint/section geometry, source-review limits, and one-plate/two-root-weld bookkeeping. The per-face surface-to-midplane transport magnitude 0.36 kN·m is correct. The full-t Ct is retained in the supplemental half-thickness screen. No conflicting numeric or source claim requiring correction was found. The stated GO is for implementing and independently testing this method, with production release and fabrication approval explicitly excluded.
