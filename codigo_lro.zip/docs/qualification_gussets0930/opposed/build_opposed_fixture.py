"""New independent finite opposed-angle qualification calculation, 2026-10-11.
No application, test output, T fixture, or prior generator is imported.
N, mm, MPa. Physical four-line geometry is projected to the planar static
end-connection idealization expressly allowed/adopted under NBR6.1.8.2.
"""
from pathlib import Path
import json, math
from numpy.polynomial import Polynomial as P
O=Path(__file__).resolve().parent
G1,G2=1.10,1.35
B,H,T,L,EM,CS,CN=540.,380.,12.,240.,20.,0.,195.
b,ta,Ag,c,r1,r2=100.,12.,2270.,29.,12.,6.
h=T;SW,SR=5.,6.
FYA,FUA,FYG,FUG,FYW,FUW,FW=275.,410.,250.,400.,345.,450.,415.
W=dict(d=317.,bf=167.,tf=13.2,tw=7.6,k=21.2,ends=[-1200.,1200.])

def extrema(p,a,z):
    pts=[a,z]
    if len(p.coef)>1:
        pts += [float(x.real) for x in p.deriv().roots() if abs(x.imag)<1e-8 and a<x.real<z]
    return [dict(n_mm=x,value=float(p(x))) for x in pts]

def contact(qn,qs,depth,fy,fu):
    sig=max(map(abs,qn))/depth;tau=abs(qs)/depth
    parts=dict(yield_VM=math.hypot(sig,math.sqrt(3)*tau)/(fy/G1),normal_rupture=sig/(fu/G2),shear_rupture=tau/(.6*fu/G2))
    return dict(depth_mm=depth,sigma_MPa=sig,tau_MPa=tau,utilizations=parts,utilization=max(parts.values()))

def block(label,Av,At,D,fy,fu,**meta):
    ry=(.6*fy*Av+.5*fu*At)/G2;rr=(.6*fu*Av+.5*fu*At)/G2
    return dict(id=label,Agv=Av,Anv=Av,Ant=At,Cts=.5,demand_N=D,R_yield_N=ry,R_rupture_N=rr,R_N=min(ry,rr),utilization=D/min(ry,rr),**meta)

def calc(N,theta=75.,id='OPPOSED_AM120'):
    C,S=math.cos(math.radians(theta)),math.sin(math.radians(theta))
    def xy(u,v):return (CS+u*C+v*S,CN+u*S-v*C)
    def uv(p):return ((p[0]-CS)*C+(p[1]-CN)*S,(p[0]-CS)*S-(p[1]-CN)*C)
    rect=[(-B/2,0.),(B/2,0.),(B/2,H),(-B/2,H)]
    def clip(poly,fn):
        out=[]
        for A,Q in zip(poly,poly[1:]+poly[:1]):
            fa,fq=fn(A),fn(Q);ina,inq=fa>=-1e-8,fq>=-1e-8
            if ina:out.append(A)
            if ina!=inq:
                t=fa/(fa-fq);out.append((A[0]+t*(Q[0]-A[0]),A[1]+t*(Q[1]-A[1])))
        return out
    def region(a,lo=None,hi=None):
        q=clip(rect,lambda p:uv(p)[0]-a)
        if lo is not None:q=clip(q,lambda p:uv(p)[1]-lo)
        if hi is not None:q=clip(q,lambda p:hi-uv(p)[1])
        return q
    def root_length(poly):
        xs=[x for x,y in poly if abs(y)<1e-7]
        return max(xs)-min(xs) if xs else 0.
    def exit_u(v):
        possible=[]
        for bound in [0.,H]:
            u=(bound-CN+v*C)/S;x,y=xy(u,v)
            if -B/2-1e-7<=x<=B/2+1e-7:possible.append((u,'root' if bound==0 else 'top'))
        if abs(C)>1e-10:
            for bound in [-B/2,B/2]:
                u=(bound-CS-v*S)/C;x,y=xy(u,v)
                if -1e-7<=y<=H+1e-7:possible.append((u,'left' if bound<0 else 'right'))
        # Forward free exit after the active line interval.
        options=[q for q in possible if q[0]>=L/2-1e-7]
        return min(options)
    def chord(a):
        intersections=[]
        for A,Q in zip(rect,rect[1:]+rect[:1]):
            ua,uq=uv(A)[0],uv(Q)[0]
            if (ua-a)*(uq-a)<=0 and abs(uq-ua)>1e-9:
                f=(a-ua)/(uq-ua);p=(A[0]+f*(Q[0]-A[0]),A[1]+f*(Q[1]-A[1]));intersections.append((uv(p)[1],p))
        return min(intersections),max(intersections)
    lines=[]
    for sign in [-1,1]:
        for name,v,f in [('heel',sign*h/2,(1-c/b)/2),('toe',sign*(h/2+b),(c/b)/2)]:
            # Each physical weld extends outside the corresponding leg edge.
            outward=-sign if name=='heel' else sign
            vlo,vhi=sorted([v,v+outward*SW])
            lines.append(dict(id=f'{"minus" if sign<0 else "plus"}_{name}',face_sign=sign,z_face_mm=sign*T/2,v_mm=v,fraction=f,F_N=N*f,footprint_v=[vlo,vhi],start=xy(-L/2,v),end=xy(L/2,v)))
    lines.sort(key=lambda p:p['v_mm'])
    assert math.isclose(sum(p['F_N'] for p in lines),N)
    assert abs(sum(p['F_N']*p['v_mm'] for p in lines))<1e-7
    assert abs(sum(p['F_N']*p['z_face_mm'] for p in lines))<1e-7
    allpoints=[xy(u,v) for p in lines for u in[-L/2,L/2] for v in p['footprint_v']]
    angleends=[xy(-L/2-EM,v) for v in[-h/2-b,-h/2,h/2,h/2+b]]
    wi=260.;intro=[xy(-L/2,v) for v in[-wi/2,wi/2]]
    assert all(-B/2<=x<=B/2 and 0<=y<=H for x,y in allpoints+angleends+intro)
    # Angle geometry, catalogue Ag retained; curved path areas independently derived.
    flat=ta-r2
    Aheel=(ta+r1)*ta+(b-ta)*ta+(1-math.pi/4)*(r1*r1-r2*r2)
    Atoe=r2*ta-(1-math.pi/4)*r2*r2
    apaths=[]
    for face in ['minus','plus']:
        for label,av,at,f in [('heel_L',(L+EM)*ta,Aheel,1-c/b),('toe_L',(L+EM)*ta,Atoe,c/b),('both_L',(L+EM)*ta,Aheel,1.),('rounded_toe_limit',(L+EM)*flat,0.,c/b),('ordinary_path_lower_envelope',L*flat,0.,1.)]:
            apaths.append(block(face+'_'+label,av,at,N/2*f,FYA,FUA,component='angle',face=face,basis='one_angle',copies_counted=1))
    # Plate all contiguous U blocks and both L families at every force/corner station.
    stations=sorted(set([-L/2,L/2]+[uv(p)[0] for p in rect if -L/2<uv(p)[0]<L/2]))
    gpaths=[];inactive=[]
    for a in stations:
        frac=max(0.,min(1.,(L/2-a)/L))
        if frac<=1e-12:continue
        for i in range(4):
            for j in range(i,4):
                lo=lines[i]['footprint_v'][0];hi=lines[j]['footprint_v'][1]
                poly=region(a,lo,hi);root=root_length(poly)
                name=f'G_U_{i+1}_{j+1}_u{a:.9f}'
                if root>1e-7:inactive.append(dict(id=name,reason='positive_supported_root_contact',length_mm=root));continue
                ul,el=exit_u(lo);ur,er=exit_u(hi)
                D=sum(p['F_N'] for p in lines[i:j+1])*frac
                if min(ul,ur)<=a:continue
                gpaths.append(block(name,((ul-a)+(ur-a))*T,(hi-lo)*T,D,FYG,FUG,component='gusset',kind='U',u=a,captured_lines=[p['id'] for p in lines[i:j+1]],vertices=[xy(ul,lo),xy(a,lo),xy(a,hi),xy(ur,hi)],block_polygon=poly,forward_edges=[el,er],root_contact_mm=root))
        (vlo,plo),(vhi,phi)=chord(a)
        cuts=sorted(set(v for p in lines for v in p['footprint_v']))
        for cut in cuts:
            if not vlo-1e-8<=cut<=vhi+1e-8:continue
            end,edge=exit_u(cut)
            for side in ['negative','positive']:
                selected=[p for p in lines if p['v_mm']<=cut+1e-8] if side=='negative' else [p for p in lines if p['v_mm']>=cut-1e-8]
                if not selected:continue
                poly=region(a,hi=cut) if side=='negative' else region(a,lo=cut)
                root=root_length(poly);name=f'G_L_{side}_v{cut:g}_u{a:.9f}'
                if root>1e-7:inactive.append(dict(id=name,reason='positive_supported_root_contact',length_mm=root));continue
                if end<=a:continue
                pfree=plo if side=='negative' else phi;bound=vlo if side=='negative' else vhi
                D=sum(p['F_N'] for p in selected)*frac
                gpaths.append(block(name,(end-a)*T,abs(cut-bound)*T,D,FYG,FUG,component='gusset',kind='L',u=a,v=cut,captured_lines=[p['id'] for p in selected],vertices=[xy(end,cut),xy(a,cut),pfree],block_polygon=poly,forward_edge=edge,root_contact_mm=root))
    gpaths.append(block('G_ordinary_path_lower_envelope',T*L,0.,N,FYG,FUG,component='gusset',kind='conservative_lower_bound',basis='single_common_plate_total_force',note='Entire N assigned to one minimum length L shear plane; transverse resistance discarded. Partial-load scaling uses the same remaining length fraction. Not an exact physical crack.'))
    for p in gpaths:
        for x,y in p.get('vertices',[]):assert -B/2-1e-6<=x<=B/2+1e-6 and -1e-6<=y<=H+1e-6
    # Piecewise full-width equilibrium field, independent polynomial extrema.
    bounds=sorted(set([0.,H]+[p[k][1] for p in lines for k in ['start','end']]))
    intervals=[];sigmin=1e99;vmmax=0;sigmax=0;taumax=0
    for a,z in zip(bounds,bounds[1:]):
        mid=(a+z)/2;pn=P([0]);pv=P([0]);pm=P([0]);p_zF=P([0])
        for line in lines:
            F=P([line['F_N']]) if mid<line['start'][1] else P([0]) if mid>line['end'][1] else line['F_N']/L*P([L/2+(CN-line['v_mm']*C)/S,-1/S])
            pn+=S*F;pv+=C*F;pm+=F*P([CS*S-CN*C+line['v_mm'],C]);p_zF+=line['z_face_mm']*F
        edges=[pn/(B*T)+pm/(T*B*B/6),pn/(B*T)-pm/(T*B*B/6)]
        vals=[extrema(q,a,z) for q in edges]
        lo=min(v['value'] for q in vals for v in q);hi=max(abs(v['value']) for q in vals for v in q)
        maxshear=max(abs(float(1.5*pv(x)/(B*T))) for x in[a,z]);env=math.hypot(hi,math.sqrt(3)*maxshear)
        sigmin=min(sigmin,lo);sigmax=max(sigmax,hi);taumax=max(taumax,maxshear);vmmax=max(vmmax,env)
        intervals.append(dict(n_interval=[a,z],N_coeff=list(pn.coef),V_coeff=list(pv.coef),M_coeff=list(pm.coef),edge_normal_extrema=vals,VM_separate_extrema_envelope_MPa=env,physical_surface_sum_zF_coeff=list(p_zF.coef),surface_couple_status='diagnostic excluded by explicit static end-eccentricity idealization, not claimed zero or stress-verified'))
    nr,vr,mr=N*S,N*C,N*(CS*S-CN*C)
    qn=[nr/B-6*mr/B**2,nr/B+6*mr/B**2];qs=vr/B
    qe=[math.hypot(q,qs) for q in qn];qpeak=max(qe);qavg=sum(qe)/2;qdesign=max(qpeak,1.25*qavg)
    Ct=max(1-c/L,.5)
    rw=SW/math.sqrt(2)*L*.6*FW/G2
    welds=[dict(line=p['id'],demand_N=p['F_N'],R_N=rw,utilization=p['F_N']/rw) for p in lines]
    subs=[]
    for p in lines:
        for member,th,fy,fu in [('angle',ta,FYA,FUA),('gusset',T,FYG,FUG)]:
            area=min(SW,th)*L;Ry=.6*fy*area/G1;Ru=.6*fu*area/G2
            subs.append(dict(line=p['id'],member=member,contact_area_mm2=area,demand_N=p['F_N'],Ry_N=Ry,Ru_N=Ru,utilization=p['F_N']/min(Ry,Ru)))
    sigintro=N/(wi*T);Cti=3*L*L/(3*L*L+wi*wi)*(1-T/(2*L))
    # Conservative local face screen: two allocated half-thickness regions sum to the one plate.
    # Retain each face's in-plane centroid +/- (h/2+c); do not invent two full plates.
    eface=h/2+c;Mface=N/2*eface;Zhalf=(T/2)*wi*wi/6
    sigface=[sigintro-Mface/Zhalf,sigintro+Mface/Zhalf]
    assert min(sigface)>0
    # Use lower full-thickness adapted Ct conservatively for both allocated regions.
    neq=nr+6*abs(mr)/B;webR=1.1*(5*W['k']+B)*FYW*W['tw']/G1
    webshearR=min(.6*FYW*B*W['tw']/G1,.6*FUW*B*W['tw']/G2)
    webVM=math.hypot(max(map(abs,qn))/W['tw'],math.sqrt(3)*1.5*vr/(B*W['tw']))
    pieces={
      'angle_yield':(N/2)/(Ag*FYA/G1),'angle_effective_rupture':(N/2)/(Ct*Ag*FUA/G2),
      'angle_weld':max(x['utilization'] for x in welds),'angle_gusset_line_substrate':max(x['utilization'] for x in subs),
      'angle_paths':max(x['utilization'] for x in apaths),'gusset_paths':max(x['utilization'] for x in gpaths),
      'gusset_section_yield':vmmax/(FYG/G1),'gusset_section_normal_rupture':sigmax/(FUG/G2),'gusset_section_shear_rupture':taumax/(.6*FUG/G2),
      'introduction_yield':sigintro/(FYG/G1),'introduction_adapted_rupture':sigintro/(Cti*FUG/G2),
      'introduction_half_thickness_face_yield':max(sigface)/(FYG/G1),'introduction_half_thickness_face_rupture':max(sigface)/(Cti*FUG/G2),
      'root_weld':qdesign/(math.sqrt(2)*SR)/(.6*FW/G2),
      'root_gusset_contact':contact(qn,qs,min(T,2*SR),FYG,FUG)['utilization'],
      'root_W_contact':contact(qn,qs,2*SR,FYW,FUW)['utilization'],
      'W_flange_punch':qpeak/(2*W['tf'])/min(.6*FYW/G1,.6*FUW/G2),
      'W_web_local_yield':neq/webR,'W_longitudinal_shear':abs(vr)/webshearR,'W_local_VM':webVM/(FYW/G1)
    }
    allclear=min(H-y for x,y in allpoints if y>CN)
    minroot=min(y for x,y in angleends)-SR
    detail=dict(all_angle_welds_min_leg_mm=5.,root_min_leg_mm=5.,angle_weld_max_ordinary_leg_mm=ta-1.5,physical_toe_flat_mm=flat,sw_fits_toe=SW<=flat,
      weld_length_over_leg=L/SW,minimum_effective_length_mm=max(40.,4*SW),angle_overlap_minimum_mm=max(50.,5*min(ta,T)),provided_overlap_mm=L+EM,
      min_angle_end_to_root_fillet_clearance_mm=minroot,min_forward_free_edge_normal_clearance_mm=allclear,all_footprints_and_intro_contained=True,
      support_flange_loaded_width_mm=T+2*SR,flange_bending_exemption_threshold_mm=.15*W['bf'],flange_bending_exempt=T+2*SR<.15*W['bf'],nearest_W_end_distance_mm=1200-B/2,
      no_compression_full_plate=min(sigmin,0.)>=-1e-7,zero_net_out_of_plane_root_moment=True,physical_local_face_couple_eliminated_by_cancellation=False)
    assert detail['flange_bending_exempt'] and minroot>0 and allclear>=SW
    return dict(id=id,N_total_N=N,method='explicit static planar 4-line opposed2L direct-contact qualification; no physical 3D stress or global member approval',inputs=dict(theta_deg=theta,plate=[B,H,T],center=[CS,CN],h=h,angle=dict(b=b,t=ta,Ag_each=Ag,c_each=c,r_heel=r1,r_toe=r2),L=L,end_margin=EM,angle_weld_leg=SW,root_weld_leg=SR,W=W,local_intro_width=wi,fy_fu=dict(angle=[FYA,FUA],gusset=[FYG,FUG],W=[FYW,FUW]),fw=FW,factors=[G1,G2]),
      geometry=dict(lines=lines,footprint_points=allpoints,angle_end_points=angleends,intro_points=intro,pair_centroid_v_z=[0.,0.],all_path_stations=stations),detailing=detail,
      angle=dict(Ct=Ct,pair_gross_area=2*Ag,R_yield_each=Ag*FYA/G1,R_effective_rupture_each=Ct*Ag*FUA/G2,rounded_heel_transverse_area=Aheel,rounded_toe_transverse_area=Atoe,paths=apaths),welds=welds,line_substrates=subs,
      gusset=dict(actual_paths=gpaths,inactive_path_candidates=inactive,single_plate_root_area=B*T,sections=intervals,min_normal_MPa=sigmin,max_VM_envelope_MPa=vmmax,local_introduction=dict(width=wi,stress_MPa=sigintro,M_local_Nmm=0.,Ct_adapted=Cti,face_screen=dict(allocated_thickness_each=T/2,N_each=N/2,e_inplane_each=eface,M_magnitude_each=Mface,sigma_endpoints_each=sigface,Ct_lower_full_thickness=Cti,interpretation='Supplemental conservative in-plane face/half-thickness allocation. One physical plate; no physical 3D field or exact fracture claim.'),spread_angle_deg=math.degrees(math.atan((wi/2-(h/2+b+SW))/L)),adaptation='conservative effective-strip rupture screen inherited as a stated adaptation, not literal NBR edge-weld geometry')),
      root=dict(N_N=nr,V_N=vr,M_Nmm=mr,q_normal_endpoints=qn,q_parallel=qs,q_peak=qpeak,q_average=qavg,q_design=qdesign,gusset_contact=contact(qn,qs,min(T,2*SR),FYG,FUG),W_contact=contact(qn,qs,2*SR,FYW,FUW),root_weld_count=2),
      support=dict(web_equivalent_tension_N=neq,web_local_yield_R_N=webR,longitudinal_shear_R_N=webshearR,local_VM_MPa=webVM,member_transverse_shear_jump_N=nr,exported_M_at_W_centroid_Nmm=mr-W['d']/2*vr,existing_member_actions='not assumed zero in project; export only'),
      utilizations=pieces,governing=max(pieces,key=pieces.get),max_utilization=max(pieces.values()),result='PASS_BOUNDED_PLANAR_METHOD' if max(pieces.values())<=1 and sigmin>=-1e-7 else 'FAIL_STRENGTH' if max(pieces.values())>1 else 'OUTSIDE_TENSILE_SECTION_DOMAIN')

positive=calc(120000.)
negative=calc(330000.,id='OPPOSED_AM330_FAIL_SHARED_PLATE')
mirror=calc(120000.,105.,'OPPOSED_AM120_THETA105_MIRROR')
# Concurrent load scalings exercise each named physical path without inventing a different force pattern.
scaled=[]
for component,key in [('angle','paths'),('gusset','actual_paths')]:
    for q in positive[component][key]:
        if q['demand_N']>0:scaled.append(dict(path=q['id'],component=component,N_total_for_eta1_01=positive['N_total_N']*1.01/q['utilization'],expected_target_eta=1.01,not_a_joint_pass='Other paths may fail first; this is only a named-path negative arithmetic check.'))
assert positive['result']=='PASS_BOUNDED_PLANAR_METHOD'
assert negative['result']=='FAIL_STRENGTH' and negative['utilizations']['gusset_paths']>1 and negative['utilizations']['angle_weld']<1
assert mirror['result']==positive['result']
assert math.isclose(mirror['root']['M_Nmm'],-positive['root']['M_Nmm'],rel_tol=1e-10)
assert math.isclose(mirror['root']['V_N'],-positive['root']['V_N'],rel_tol=1e-10)
assert math.isclose(mirror['max_utilization'],positive['max_utilization'],rel_tol=1e-10)
output=dict(created='2026-10-11',origin='New independent source-equation calculation; no production imports, T fixture imports or runtime output copies.',scope='method-level static planar qualification only, conditioned on documented static end-eccentricity exception; not fabrication/global approval',fixtures=[positive,negative,mirror],named_path_failure_scalings=scaled)
(O/'NEW_OPPOSED_WELDED_FIXTURES.json').write_text(json.dumps(output,indent=2,ensure_ascii=False)+'\n')
for x in output['fixtures']:
 print(x['id'],x['result'],x['governing'],x['max_utilization'],'M',x['root']['M_Nmm'],'sigma_min',x['gusset']['min_normal_MPa'],'actual_paths',len(x['gusset']['actual_paths']))
print('Assertions: positive, shared-plate negative, mirrored-angle signs and utilization passed.')
