# Qualificação finita: 2L opostas soldadas → gusset → mesa exterior W

11/10/2026. Geometria confirmada pelo usuário em Sentinel_a27228c1dc108191b421e3206e20dd54: uma L por face, giradas180° entre si, abas conectadas em sentidos opostos e h=tg. Nenhum arquivo de produção, versão0.9.29 ou qualificação anterior foi alterado.

## Resultado

**GO de método para implementar e revisar o ramo plano estático delimitado descrito aqui.** O novo caso inteiro120kN passa; o mesmo corpo sob330kN falha no envelope conservador da chapa comum. Não se trata de aprovação da estrutura ou liberação de fabricação. A montagem, material certificado, adequação da idealização e dimensionamento global permanecem decisões do responsável técnico.

A dúvida geométrica anterior está encerrada. Este arquivo supersede o gate pendente de geometria/excentricidade no contrato anterior, somente para o presente método soldado. A interface parafusada é trabalho separado, não se soma capacidade de parafusos e soldas na mesma interface.

## 1. Fechamento do efeito local fora do plano

O arranjo original está nas pranchas fornecidas M-009/M-010/t/M-011/t, páginas impressas77–79 de PADRÃO DE LIGAÇÕES-5Model.pdf; elas tratam de interligadores da barra, não de um nó terminal completo. O terminal qualificado é a geometria expressamente confirmada.

A revisão dedicada `../eccentricity_review/REVIEW.md` fecha a hipótese de método:

- NBR8800:2024,6.1.8.2 (PDF93/impressa71) permite desprezar a excentricidade ordinária de extremidade de cantoneiras simples/duplas sob solicitação estática, sem fadiga. Não limita a dupla à forma T.
- A própria6.5.2 (PDF116/impressa94), sobre ligações excêntricas, remete à6.1.8.2.
-6.1.1.2–.3 (PDF91/impressa69) conserva equilíbrio, rigidez/deformação e os estados-limite de cada componente. DG29§1.2 (PDF9/impressa1) conserva os limites de campo admissível/ductilidade.

**Aplicação adotada:** a mesma idealização estática fora do plano já qualificada para1L é aplicada individualmente a cada L. As fontes de força são projetadas no plano médio do gusset, mas suas quatro coordenadas v permanecem distintas. A partilha N/2 exige L, materiais, ligações e carregamentos compatíveis; não decorre apenas de olhar uma seção geometricamente centrada.

Não se afirma que os binários físicos locais desapareçam. No caso120kN, cada face transmite um binário superfície→plano médio de0,36kNm, e cortes parciais podem ter Σ(zᵢFᵢ)≠0. Essa parcela é expressamente **desprezada pela idealização estática**, não calculada e aprovada como tensão tridimensional. Ct continua independente. O relatório futuro deve dizer isso claramente, sem afirmar “não há flexão fora do plano por simetria”.

Não foi identificada razão técnica/normativa para exigir um novo modelo espacial somente pela rotação de180° das ligações ordinárias diretas. Outra análise é necessária se houver fadiga, ações espaciais externas, afastadores/enchimentos, carregamento desigual imposto, L/detalhes diferentes, impedimento espacial adicional relevante ou necessidade de verificar deformação/rotação fora do plano. Não existe exigência genérica de MEF neste escopo.

## 2. Geometria completa nova

O gerador `build_opposed_fixture.py` não importa aplicativo, resultado de execução, fixture T ou gerador anterior. Todas as forças/áreas/capacidades são recomputadas da geometria abaixo.

- Uma chapa retangular B540×H380×t12mm, raiz em n=0, −270≤s≤270. Afastamento entre talões h=t=12mm.
- Duas Arcelor L100×100×12 idênticas; área catalogada2270mm² e c29mm por L; raio interno12mm, raio de ponta6mm, face plana de ponta6mm. Aço275/410MPa. A geometria catalogada e os caminhos curvos são os previamente auditados; não são substituídos por uma L retangular de espessura fictícia na ponta.
- Gusset250/400MPa; W345/450MPa; E60/fw415MPa nas duas interfaces, mantidas como propriedades independentes.
- Eixo da barra θ75°; centro P0=(0,195)mm. Transformação s=u cosθ+v sinθ; n=195+u sinθ−v cosθ.
- Quatro filetes longitudinais5mm, u=−120…+120mm. Talões em v=±6mm, pontas em v=±106mm. Ftalão=42,6kN e Fponta=17,4kN por face para Ntotal120kN.
- Projeções físicas dos filetes: [−111,−106], [−6,−1], [1,6], [106,111]mm. Não são as duas linhas coincidentes do T.
- Ambas as L terminam em u=−140mm, margem20mm. As quatro soldas são acessíveis pelo lado livre de sua face. Contatos diretos, sem interligador no trecho de solda, sem solda transversal/retorno dividindo força.
- Raiz: dois filetes6mm em toda largura540mm, exterior da mesa W, longitudinais ao W e centrados sobre sua alma. W310×165×52: d317/bf167/tf13,2/tw7,6/k21,2mm. Extremidades W em s=±1200mm.
- Faixa local260mm em u=−120, v=±130. Suas extremidades estão dentro da chapa. Espalhamento além da projeção externa é19mm por lado em240mm, ângulo4,5265°, inferior a30° e explicitamente escolhido, não Whitmore ilimitado.

Folgas verificadas:26,3356mm entre ponta da L e pé da solda de raiz;40,3600mm mínimo normal até borda livre adiante dos filetes. Contenção de todos os extremos/footprints/faixa local. Solda de ângulo5mm cabe na face plana6mm e respeita mínimos/máximo ordinário; raiz6mm respeita mínimo5mm. L/s=48; comprimento240mm supera40mm/4s; sobreposição260mm supera60mm. Duas faces executáveis/inspecionáveis devem continuar sendo premissa física.

## 3. Equilíbrio e chapa comum

Cada L leva60kN. Os centroides projetados individuais são v=±35mm; o centroide do par é v=0. Portanto:

Nraiz=N senθ; Vraiz=N cosθ; Mraiz=N(s0 senθ−n0 cosθ).

Não existe o deslocamento comum c−b/2 do T. O resultado não é Mraiz0 por definição. No caso novo:

- Nraiz115,911099kN; Vraiz31,058285kN; Mraiz−6,056366kNm.
- A raiz da única chapa tem6480mm². São dois filetes de raiz, não quatro.
- Tensões normais na raiz7,502801/28,272230MPa.
- Nove intervalos de cortes horizontais entre inícios/fins dos quatro filetes; N/V lineares por trecho, M quadrático. Extremos interiores das tensões são resolvidos, não apenas avaliados nas bordas.
- Mínimo normal0, dentro do arredondamento numérico; máximo envelope VM30,8930766MPa, utilização0,135929537.

Faixa local260mm: força centrada120kN, tensão38,4615385MPa. A adaptação conservadora de ruptura da faixa conserva Ct=0,700831947 e é rotulada como adaptação, não como se as quatro soldas estivessem nas duas bordas de uma chapa da fórmula literal.

Para não depender apenas do agregado centrado, acrescenta-se um **screen conservador por face com meia espessura**: cada parcela60kN utiliza260×6mm, conservando seu momento no plano de módulo2,1kNm por v=±35. As duas alocações somam a espessura real12mm, sem duplicar chapa. Tensões7,396450/69,526627MPa, todas tracionadas. Conserva-se o menor Ct calculado com a espessura total12mm. Utilizações de escoamento0,305917160 e ruptura0,334819735. É um screen suplementar de seção no plano, não prova de um campo físico tridimensional ou de uma superfície de fratura.

## 4. Ruptura: quatro linhas e bordas reais

Sem furos, áreas líquidas=brutas. NBR6.5.6:

R=min(0,60fu·Anv+0,5fu·Ant; 0,60fy·Agv+0,5fu·Ant)/1,35.

Cts0,5 é conservador para tensão não uniforme. Não se usaγa1 na parcela de escoamento do bloco. Os limites independentes de6.5.3/6.5.5 e contato local continuam.

Quatro footprints ordenados geram **dez subconjuntos U contíguos não vazios**. Todos são registrados, assim como blocos L que capturam prefixos/sufixos pelas duas bordas e os cortes nos extremos dos footprints. Grupos não contíguos separados são limitados pelas razões individuais; não se soma resistência de caminhos alternativos.

Para cada caminho: interseção do raio/chord com o retângulo real, polígono destacado, forças capturadas, áreas, coordenadas e ambas as resistências. Qualquer segmento de contato positivo com a raiz apoiada torna o bloco inadmissível; um canto isolado não cria comprimento de apoio. Cortes parciais capturam somente a fração remanescente de solda e desconsideram conservadoramente resistência do metal de solda atravessado.

Estações finitas u: −120; **−118,474393949** (canto inferior direito, crucial porque o caminho direito inicial ainda toca raiz); **108,815135686** (canto superior esquerdo); +120mm. Em cada intervalo de topologia constante, demanda e resistências são afins; a razão é monótona/constante. No JSON há66 caminhos admissíveis incluindo o envelope abaixo, além dos candidatos inativos com motivo geométrico. Não se inventa borda livre na raiz.

Exemplos no início das soldas:

- U envolvendo todos: Agv7476,626241mm², Ant2664mm², demanda120kN, R1225,402916kN.
- U dos dois talões: Agv7476,626241mm², Ant144mm², demanda85,2kN, R852,069582kN.
- U com as três primeiras linhas: demanda102,6kN, Ant1404mm², R1001,223362kN. Ignorar grupos parciais perderia este caso.

Além dos caminhos físicos, conserva-se o limite inferior qualificado para caminhos ordinários paralelos/transversais: atribuir Ntotal a **uma** seção de cisalhamento mínima tL=2880mm², sem contribuição transversal. R320kN, η0,375. É envelope conservador de método, não um caminho de fissura exato. Para forças parciais, comprimento e força diminuem pela mesma fração. A semelhança de fórmula com outros nós não vem de copiar capacidade: nova área2880 e nova carga120kN são recomputadas.

Cada L possui seus próprios caminhos talão, ponta, ambos, limite de ponta arredondada e envelope ordinário, comN/2. A menor espessura real6mm da ponta evita dobrar indevidamente a área. Os dois corpos não compartilham suas resistências. Contato/metais-base são conferidos em cada um dos quatro filetes: área de contato1200mm² por superfície, com o material próprio.

## 5. Quatro soldas, raiz e W

NBR5.2 mantém Ct individual1−29/240=0,879166667 e área efetiva, sem zerar excentricidade por centroide global. Resistências de cada L: escoamento567,5kN; ruptura efetiva606,104012kN.

No caso120kN:

- Solda de talãoη0,272193514; contato local governanteη0,260333333.
- Envelope de caminhos da Lη0,340909091.
- Raiz: qn339,266761/90,033606N/mm; qs57,515343N/mm. qpeak344,107468 e qdesign=max(pico,1,25média)=344,107468N/mm. Soldaη0,219868124.
- Contato de raiz gussetη0,129649714, Wη0,093949068, por tensão normal/cisalhamento combinados. A profundidade do gusset émin(t,2s)=12mm; não duas chapas.
- Mesa: punção/cisalhamento local comqpeak/(2tf), η0,069264788. A largura real carregada t+2s=24mm é menor que0,15bf=25,05mm: dispensa de flexão local5.7.2 aplicável.
- Alma W: escoamento localNBR5.7.3, demanda elástica equivalente183,204051kN, resistência1693,812kN, η0,108160794. Distância mínima930mm até as extremidades, fora das reduções de extremidade.
- Transferência longitudinal:η0,040215407. Screen local combinado Wη0,155525786.
- Exportação: salto de cortante transversal115,911099kN; M transportado ao centroideW−10,979104kNm. Isso não verifica o membro W com ações preexistentes; elas não podem ser presumidas nulas num projeto.

Ações só tracionadas na região qualificada não acionam por conveniência os modos exclusivos de compressão. Se uma geometria futura exigir região comprimida, o ramo inicial deve recusá-la com motivo, sem declarar que a ligação real é impossível.

## 6. Casos independentes e falhas

`NEW_OPPOSED_WELDED_FIXTURES.json` contém:

1. **OPPOSED_AM120:** passa o método completo acima; ηmáx0,375 no envelope da chapa comum.
2. **OPPOSED_AM330_FAIL_SHARED_PLATE:** mesmos corpos/materiais/geometria sob330kN; ηchapa1,03125 falha. Solda de talãoη0,748532163 e envelope da Lη0,9375 ainda passam. Logo não é uma falsa soma de duas capacidades completas nem uma falha causada pela compressão.
3. **OPPOSED_AM120_THETA105_MIRROR:** mesmo120kN, θ105°. V e Mraiz trocam sinal; Nnormal e utilização governante permanecem. Os caminhos se espelham e os mínimos normais ficam em zero numérico.
4. Escalas concorrentes independentes para cada caminho nomeado, levando sua razão a1,01. Outros caminhos podem falhar antes; esses controles são oráculos de aritmética do modo nomeado, não outros nós aprovados.

O script verifica contenção, Ntotal, primeiros momentos do par, sinais da variante105°, aprovação120 e falha330. As fontes/fórmulas do novo ramo não são equivalentes a chamar o motor1L duas vezes e somar aprovações.

## 7. Fontes e limites de reutilização

Fontes-base: NBR8800:2024 com Errata1:2025,5.2.2–5.2.5;5.7.2–5.7.3;6.1.5;6.1.8.2;6.2.2.2;6.2.5/6.2.6.2;6.5.2/3/5/6. Páginas físicas47,61–64,85–87,91–93,97–104,116–118 do PDF fornecido. DG29§4.2.4, pp32–33 impressas/PDF40–41 para apoio único/momento; pp54–59 e196–204 para componentes, seções e suplemento elástico da solda. Os fatores são NBR atuais do exemplar fornecido, não AISC históricos.

Propriedades reais deL/W e materiais independentes: registros já auditados em `welded_gusset_scope/QUALIFIED_GEOMETRY.md`, `double_angle_gusset_scope/source_review.md` e fontes originais ali identificadas. As fórmulas de contorno da L foram recomputadas neste gerador; a capacidade T e sua faixa150mm não foram reaproveitadas.

Reutilizar primitivas de materiais, catálogos, soldas e raiz/W quando geometricamente aplicáveis. **Substituir integralmente** a geometria de duas linhas, centroides, somas por corte e enumeração de blocos da chapa. Novo tipo/identidade de arquivo deve distinguir opostas e T; não converter JSON legado silenciosamente. Desenho e relatório devem mostrar quatro linhas/demandas e uma chapa/duas soldas de raiz.

Antes da liberação de código, executar revisão independente do motor/detalhamento, sinais/θ90/θ>90, materiais, mínimos de força, família fora do domínio, serialização, desenhos/Word e caso330 que obrigatoriamente falha na chapa. Este pacote conclui a qualificação de método e fornece oráculos; não executa essas etapas de implementação.
