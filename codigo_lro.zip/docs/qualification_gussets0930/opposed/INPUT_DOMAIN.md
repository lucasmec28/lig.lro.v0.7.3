# Allowed input domain versus benchmark

This is the implementation contract for the finite method, not a list of mandatory benchmark dimensions. It supplements QUALIFICATION.md and does not expand the existing material, weld-detail, rolled-angle, or W-root primitive qualifications.

## Permitted variables

- Exactly two identical rolled equal-leg L sections, one existing qualified section record used twice. Preserve the already qualified Arcelor contour adapter and, if exposed, the already qualified Gerdau nominal adapter and explicit reinforced-edge conditions; do not invent missing radii. Both L have the same section, material, length/termination detail and compatible axial loading. Manual/asymmetric/unequal-leg shapes are not newly authorized.
- One rectangular gusset B×H×tg, positive finite dimensions, with independent plate material. **h=tg is derived and fixed in this first branch**, not an independent user parameter. The centroidal force line uses the middle of the opposed pair. No filler, stand-off, second orthogonal plate or square-bar interconnector in the terminal weld region.
- Four longitudinal fillets with common effective length L and common leg sw, equal per-face end margin and physically accessible heel/toe detail. One member-axis station interval shared by all four lines. No transverse weld/return or bolted parallel capacity.
- Let a=tg/2. Physical weld roots are (v,z)=(−a−b,−tg/2),(−a,−tg/2),(+a,+tg/2),(+a+b,+tg/2). Projected resistance sources use the same four v coordinates at z=0, under the explicitly stated NBR6.1.8.2 static end-eccentricity idealization. Face heel/toe fractions are (1−c/b)/2 and (c/b)/2 of total N. Physical drawings keep actual z.
- θ may vary within0<θ<180°, including90°, with positionP0=(s0,n0), subject to all containment, finite free-edge, root-interference and wholly tensile section-domain conditions. Do not lock the UI to75° or105°. No blanket moment-zero assumption and no added external moment required. Nraiz=Nsinθ, Vraiz=Ncosθ, Mraiz=N(s0sinθ−n0cosθ).
- The local introduction width is a physical selected width, not fixed at260mm and not silently reused from T. It must encompass the entire four-footprint projection, remain inside the rectangle at the checked section, and satisfy the qualified limited-spreading geometry (no greater than30°). Check the aggregate strip plus the selected conservative per-face half-thickness screen with each projected centroid±(tg/2+c). All evaluated normal stresses must stay nonnegative within tolerance. Use the lower full-tg adapted Ct for the half-thickness screens.
- Static axial tension Ntotal≥0, normal ultimate factors, no fatigue/seismic/reversal/compression or externally applied V/M/T. Preserve actual N=0; evaluate the existing minimum45kN once for the entire connection, then split. Optional50% reference derives from the actual pair strength and is a separate load case. No arbitrary minimum on each L.
- Support may be beam or column by rigid rotation of local coordinates. Preserve only the existing qualified rolled-W exterior-flange route: root longitudinal to W and centered over its web, with the same catalog/material validation, end effects, local checks and action export. Do not add W-web, eccentric/transverse roots, built-up supports or other support topology.
- Angle/gusset/W materials and the two weld electrodes remain independent choices within their already qualified product/thickness ranges.

## Geometry/path obligations for those variables

The benchmark's10 contiguous U subsets and recorded L candidates are an instance of the following general rule, not a frozen list of coefficients:

1. Build actual four footprint bounds and root lines, sorted by projected v. Use their real positions, not the T's two averaged lines.
2. For every candidate detached polygon, compute demand from **all actual loaded source lines it captures**, including partial remaining length. If projected footprints overlap or touch, use the actual union/capture test; never assume a nominal subset excludes another captured line. Coincident material is not counted twice. Do not silently drop a loaded source when a footprint bound crosses it.
3. Resolve forward and transverse intersections with the bounded rectangle. Keep root-attached candidates inactive. Enumerate weld-end and rectangle-corner stations and endpoint/one-sided force-topology changes as appropriate. Root/free corner contact alone is admissible; positive supported-root length is not.
4. Recompute U, both L families and the conservative ordinary-path lower envelope for the one common plate. Keep angle paths per physical L withN/2 and physical contour/nominal adapter conditions.
5. Recompute every four-line plate interval and all interior stress extrema. Recompute the local introduction and per-face allocated-thickness screens. Then feed the actual total N/V/M into the existing root/W checks. Approval from T or from two independent full-thickness plates is never reused.

Any parameter set violating a geometry/resistance condition fails that condition or falls outside this bounded method. The benchmark's sizes,75° angle,120kN load and far-end W placement are **not** independent domain gates; the actual equations and detailing conditions govern.

## Numerical benchmark only

B540/H380/tg=h12, L240, end margin20, sw5, root legs6, L100×100×12/c29/Ag2270, P0=(0,195), local width260, θ75° and105°, W ends±1200, N120/330kN. These values define independently reviewed oracle inputs and are not hidden substitute inputs for the user's design.

Implementation still requires its own numerical/geometry, serialization and artifact tests; this packet authorizes no release without those checks. It requires no additional broad source hunt or new spatial analysis for the ordinary direct-contact static branch just described.
