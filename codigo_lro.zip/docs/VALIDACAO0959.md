# Verificação da integração 0.9.59

Integração da opção SCI P358 no menu existente de end plate rotulada. A fonte completa 0.9.58 foi preservada. Os motores anteriores não foram modificados; a mudança no renderizador existente acrescenta somente a seleção do método antes do ramo NBR.

## Cobertura
- 155 testes direcionados passaram: 40 da nova opção, motor e interface da end plate anterior, índices de resultados e diagnóstico de módulos obrigatórios, incluindo os dois módulos SCI.
- Após correção de persistência do rascunho SCI, os 40 testes SCI e cinco testes adicionais de integração passaram (45 no lote).
- O lote final de integração contém seis casos: preservação de edições NBR e SCI ao alternar métodos, importação real no app, geração/invalidação Word, conteúdo CSV, rejeição de importação inválida sem apagar entradas e manutenção visível do rascunho inválido.
- São 161 casos distintos cobertos nesta revisão; repetições não são somadas. A suíte integral da .58 não foi repetida, pois os demais motores mantêm igualdade de bytes.
- Pacote extraído: CRC externo/interno, vínculo SHA, manifesto atual, compilação, base U com Word, seleção SCI no aplicativo real, Word SCI, invalidação após edição e alternância SCI/NBR.

## Correção encontrada na integração
O rascunho NBR era preservado, mas a opção SCI perdia edições ao sair e voltar. Foi acrescentado estado separado para conservar o rascunho SCI, inclusive uma geometria temporariamente inválida que precisa continuar visível para correção. O contrato JSON externo continua estrito e não permite importar dados fora do domínio. Nenhuma equação ou coeficiente foi alterado na integração.

## Limites
O exemplo de referência e os testes de software não aprovam uma ligação real. A opção SCI usa materiais EN, fatores Eurocode UK, apenas V vertical e apoio na alma da coluna. Não fecha o modelo NBR genérico N/V e não torna equivalentes materiais ASTM. A confirmação de materiais permanece pendente até declaração do usuário.
