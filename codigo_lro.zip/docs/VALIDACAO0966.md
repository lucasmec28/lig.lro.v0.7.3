# Validação delimitada 0.9.66

## Mudança
Grupo elástico de soldas em três bordas também na single plate entre mesas; núcleo compartilhado com duas talas. As verificações antigas da transferência exclusiva à alma são substituídas, não somadas. O complemento conserva pendências de chapa, receptores e rotação. Referências retangulares nominais são identificadas como condicionais, sem produzir aprovação ou falha física fictícia do conjunto.

## Evidência independente
- 30 casos convencionais: igualdade exata com a versão0.9.65 em verificações, casos de entrada, alertas, status e nota de cobertura.
- 24.923 comparações numéricas independentes em 456 avaliações, incluindo 150 geometrias, gargantas desiguais, reflexão, rotação/translação de origem e cargas nulas/invertidas. Integração de Gauss e sistema de rigidez3×3 construídos independentemente.
- Agregado de regressão: 792 testes aprovados em153,45s. Revisões focadas adicionais de core, UI, JSON e Word documentadas separadamente; resumo em validation0966/SUMMARY.json.
- Geometria útil, alívios, gargantas, mínimos de comprimento, projeção física do receptor e status condicionado conferidos. Momentos de origem, centroide e binários por borda rastreáveis.
- Arquivos de projeto anteriores continuam importáveis. VERSION/schema legado é preservado; identificação do pacote no aplicativo e no Word é0.9.66.

## Limites
Testes de software não são aprovação estrutural de um projeto. O cálculo novo qualifica somente as soldas sob hipótese explícita de partes rígidas. Não representa validação integral da single plate full-depth ou da nervura das duas talas. Nenhuma dispensa de FLT nem resistência de barra íntegra foi aplicada à chapa perfurada. Detalhes físicos e condições dos receptores devem corresponder às premissas e aos intervalos modelados.
