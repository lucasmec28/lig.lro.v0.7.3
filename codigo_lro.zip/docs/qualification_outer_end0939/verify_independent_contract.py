"""Run independent geometric and mechanical planning checks with unittest."""
import json
import math
import unittest
from pathlib import Path
from scipy.integrate import quad
from independent_cap_oracle import *

BASE=[(-200.,0.),(200.,0.),(200.,300.),(-200.,300.)]


def rounded_rational_witness():
    theta=64.;a=(math.cos(math.radians(theta)),math.sin(math.radians(theta)));v=(a[1],-a[0]);centre=(20.,110.);L=40.;e=6.;t=10.
    xy=lambda u,s:add(centre,add(scale(a,u),scale(v,s)))
    poly=cap(BASE,a,dot(a,centre)+L/2+e)
    lines=[dict(start=xy(-L/2,s),end=xy(L/2,s),F=100000*f) for s,f in [(-50.,.72),(50.,.28)]]
    ints=weld_intervals(poly,a,lines,t)
    uncut=weld_intervals(BASE,a,lines,t)
    rows=[dict(row,edge=edge['edge'],interval=interval['interval']) for interval in ints for edge in interval['edges'] for row in edge['candidates']]
    minimum=min(rows,key=lambda r:r['sigma'])
    footprint=[xy(u,s) for u in (-L/2-20.,L/2) for s in (-55.,55.)]
    return dict(scope='Independent geometry and section witness; no material/catalog or complete-connection approval',
        theta_deg=theta,center=centre,weld_length=L,outer_weld_margin=e,plate_t=t,
        nominal_leg=100.,nominal_centroid=28.,force_total=100000.,axis=a,polygon=poly,lines=lines,
        root_footprint=[(-200.,0.),(200.,0.),(200.,5.),(-200.,5.)],source_footprint=footprint,
        horizontal_intervals=ints,uncut_horizontal_intervals=uncut,
        minimum_normal=minimum,all_boundary_min=min(r['sigma'] for r in rows if r['kind']=='boundary'),
        uncut_minimum=min(r['sigma'] for interval in uncut for edge in interval['edges'] for r in edge['candidates']),
        local_introduction=dict(width=140.,sigma_min=100000/(140*t)-6*2200000/(140*140*t),
            spread_angle_deg=math.degrees(math.atan((140-100)/(2*L))),
            endpoints=[xy(-L/2,s) for s in (-70.,70.)]))


def quadrature_section(poly,axis,lines,t,y):
    # Independent numerical integration over retained portions of each source.
    lo,hi=horizontal(poly,y);A=t*(hi-lo);cg=(lo+hi)/2;I=t*(hi-lo)**3/12
    N=V=M=0.
    for line in lines:
        p,q,F=line['start'],line['end'],line['F']
        u0=max(0.,min(1.,(y-p[1])/(q[1]-p[1])))
        N+=quad(lambda u:F*axis[1],u0,1.,epsabs=1e-8)[0]
        V+=quad(lambda u:F*axis[0],u0,1.,epsabs=1e-8)[0]
        def moment(u):
            x=p[0]+u*(q[0]-p[0]);yy=p[1]+u*(q[1]-p[1])
            return F*((x-cg)*axis[1]-(yy-y)*axis[0])
        M+=quad(moment,u0,1.,epsabs=1e-8)[0]
    return dict(sigma=[N/A+M*(x-cg)/I for x in (lo,hi)],N=N,V=V,M=M,A=A,cg=cg,I=I)


class IndependentGeometryContract(unittest.TestCase):
    def test_primary_witness_and_boundary_self_checks(self):
        r=self_test();self.assertAlmostEqual(r['primary']['outer_ligament_3_4_inch'],24.68125,places=10)

    def test_rational_fixture_retains_every_required_witness(self):
        w=rounded_rational_witness();p=w['polygon']
        for q in w['root_footprint']+w['source_footprint']+w['local_introduction']['endpoints']:
            for x,y in zip(p,p[1:]+p[:1]):self.assertGreaterEqual(cross(sub(y,x),sub(q,x)),-1e-8)
        self.assertGreater(w['local_introduction']['sigma_min'],0.)
        self.assertLess(w['local_introduction']['spread_angle_deg'],30.)

    def test_interior_compression_missed_by_all_event_endpoints(self):
        w=rounded_rational_witness()
        self.assertGreaterEqual(w['all_boundary_min'],-1e-10)
        self.assertGreaterEqual(w['uncut_minimum'],-1e-10)
        self.assertAlmostEqual(w['minimum_normal']['y'],137.6251795574754,places=8)
        self.assertAlmostEqual(w['minimum_normal']['sigma'],-7.85623377186645,places=8)
        self.assertEqual(w['minimum_normal']['kind'],'stationary')

    def test_rational_extrema_against_numerical_source_integration(self):
        w=rounded_rational_witness()
        for interval in w['horizontal_intervals']:
            low,high=interval['interval']
            for edge in interval['edges']:
                index=0 if edge['edge']=='left' else 1
                for row in edge['candidates']:
                    actual=quadrature_section(w['polygon'],w['axis'],w['lines'],w['plate_t'],row['y'])['sigma'][index]
                    self.assertAlmostEqual(actual,row['sigma'],places=8)
                    if row['kind']=='stationary':
                        h=1e-3
                        ys=[row['y']-h,row['y']+h]
                        vals=[quadrature_section(w['polygon'],w['axis'],w['lines'],w['plate_t'],y)['sigma'][index] for y in ys]
                        self.assertLess(abs((vals[1]-vals[0])/(2*h)),1e-7)
                # Dense numerical integration checks extrema envelope independently.
                values=[quadrature_section(w['polygon'],w['axis'],w['lines'],w['plate_t'],low+(high-low)*j/250)['sigma'][index] for j in range(251)]
                minimum=min(r['sigma'] for r in edge['candidates']);maximum=max(r['sigma'] for r in edge['candidates'])
                self.assertGreaterEqual(min(values),minimum-1e-8)
                self.assertLessEqual(max(values),maximum+1e-8)

    def test_sign_reversal_keeps_shape_and_reverses_equilibrium(self):
        w=rounded_rational_witness();lines=[dict(q,F=-q['F']) for q in w['lines']]
        y=w['minimum_normal']['y']
        pos=quadrature_section(w['polygon'],w['axis'],w['lines'],w['plate_t'],y)
        neg=quadrature_section(w['polygon'],w['axis'],lines,w['plate_t'],y)
        for key in ('N','V','M'):self.assertAlmostEqual(pos[key],-neg[key],places=8)
        self.assertAlmostEqual(neg['sigma'][0],7.85623377186645,places=8)

    def test_vertex_rotation_preserves_semantic_contacts(self):
        p=[(30.,0.),(500.,0.),(500.,500.),(0.,500.),(0.,30.)];a=(2**-.5,2**-.5);c=650*a[0]
        roles=['beam_support','right_free','top_free','column_support','inner_relief']
        for offset in range(len(p)):
            P=p[offset:]+p[:offset];R=roles[offset:]+roles[:offset];q=cap(P,a,c);es=edge_roles(q,P,R,a,c)
            for role,target in [('beam_support',470.),('column_support',470.),('inner_relief',30*math.sqrt(2))]:
                self.assertAlmostEqual(sum(e['length'] for e in es if role in e['roles']),target,places=8)

    def test_reference_is_physical_unique_end_and_not_load_sign(self):
        w=witness();centres=w['primary']['centres'];a=w['primary']['axis']
        self.assertEqual(max(dot(a,p) for p in centres),max(dot(a,p) for p in centres+centres))
        last=max(dot(a,p) for p in centres)
        self.assertAlmostEqual(max(dot(a,p) for p in [(x+30*a[0],y+30*a[1]) for x,y in centres])-last,30.)

if __name__=='__main__':
    dest=Path(__file__).with_name('rounded_rational_expectations.json')
    dest.write_text(json.dumps(rounded_rational_witness(),indent=2,allow_nan=False)+'\n')
    unittest.main(verbosity=2)
