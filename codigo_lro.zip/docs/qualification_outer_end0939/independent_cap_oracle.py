"""Independent scalar/polygon oracle, not production code or a design certificate.

Uses only Python standard library. No production imports, no production writes.
Clipping is constructed from retained original vertices and edge-plane crossing
points, independently sorted around their centroid. Supports convex polygons.
"""
from __future__ import annotations
import json
import math
from pathlib import Path

EPS = 1e-9


def dot(a, b): return sum(x*y for x, y in zip(a,b))
def add(a,b): return tuple(x+y for x,y in zip(a,b))
def sub(a,b): return tuple(x-y for x,y in zip(a,b))
def scale(a,k): return tuple(x*k for x in a)
def cross(a,b): return a[0]*b[1]-a[1]*b[0]
def norm(a): return math.hypot(*a)
def close(a,b,tol=EPS): return abs(a-b)<=tol*max(1.,abs(a),abs(b))


def area_centroid(poly):
    s = sx = sy = 0.
    for p,q in zip(poly,poly[1:]+poly[:1]):
        z=cross(p,q); s+=z; sx+=(p[0]+q[0])*z;sy+=(p[1]+q[1])*z
    if s<=0: raise ValueError('Expected positive counterclockwise polygon')
    return s/2,(sx/(3*s),sy/(3*s))


def cap(poly, axis, cut):
    points=[tuple(p) for p in poly if dot(axis,p)<=cut+EPS]
    for p,q in zip(poly,poly[1:]+poly[:1]):
        fp,fq=dot(axis,p)-cut,dot(axis,q)-cut
        if fp*fq<0:
            points.append(add(p,scale(sub(q,p),-fp/(fq-fp))))
    unique=[]
    for p in points:
        if all(norm(sub(p,q))>EPS for q in unique):unique.append(p)
    if len(unique)<3:raise ValueError('Degenerate retained polygon')
    mid=tuple(sum(p[i] for p in unique)/len(unique) for i in (0,1))
    result=sorted(unique,key=lambda p:math.atan2(p[1]-mid[1],p[0]-mid[0]))
    area_centroid(result)
    return result


def segment_distance(p,a,b):
    q=sub(b,a);q2=dot(q,q)
    if q2<=EPS*EPS:raise ValueError('Zero-length edge')
    k=max(0.,min(1.,dot(sub(p,a),q)/q2))
    foot=add(a,scale(q,k))
    return norm(sub(p,foot)),foot,k


def line_interval(poly, origin, direction):
    """Solve all convex edge half-plane inequalities for line origin+t*direction."""
    lo,hi=-math.inf,math.inf
    for p,q in zip(poly,poly[1:]+poly[:1]):
        edge=sub(q,p);b=cross(edge,sub(origin,p));a=cross(edge,direction)
        if abs(a)<1e-13:
            if b < -EPS: return None
        elif a>0:lo=max(lo,-b/a)
        else:hi=min(hi,-b/a)
    if lo>hi+EPS:return None
    return lo,hi


def horizontal(poly,y):
    span=line_interval(poly,(0.,y),(1.,0.))
    if span is None:return None
    return tuple(float(v) for v in span)


def edge_roles(poly, original, original_roles, axis, cut):
    out=[]
    for p,q in zip(poly,poly[1:]+poly[:1]):
        roles=[]
        for a,b,role in zip(original,original[1:]+original[:1],original_roles):
            if segment_distance(p,a,b)[0]<EPS and segment_distance(q,a,b)[0]<EPS:roles.append(role)
        if abs(dot(axis,p)-cut)<EPS and abs(dot(axis,q)-cut)<EPS:roles.append('outer_normal_cut_free')
        out.append(dict(start=p,end=q,length=norm(sub(q,p)),roles=roles))
    return out


def retained_segment(poly,a,b):
    return all(line_interval(poly,p,(1.,0.)) is not None for p in (a,b)) and all(
        cross(sub(q,p),sub(r,p))>=-EPS for p,q in zip(poly,poly[1:]+poly[:1]) for r in (a,b))


def circle_retained(poly,point,radius):
    return all(cross(sub(q,p),sub(point,p))/norm(sub(q,p))>=radius-EPS
        for p,q in zip(poly,poly[1:]+poly[:1]))


def remove_intervals(chord,holes):
    lo,hi=chord;ans=[];cur=lo
    for a,b in sorted(holes):
        a=max(a,lo);b=min(b,hi)
        if b<=cur:continue
        if a>cur:ans.append((cur,a))
        cur=max(cur,b)
    if cur<hi:ans.append((cur,hi))
    return ans


def section(intervals,t):
    b=sum(hi-lo for lo,hi in intervals)
    cg=sum((hi**2-lo**2)/2 for lo,hi in intervals)/b
    I=t*sum(((hi-cg)**3-(lo-cg)**3)/3 for lo,hi in intervals)
    return dict(width=b,A=t*b,centroid_x=cg,I=I)


def discrete_section(poly,y,t,centres,net_diameter,forces,axis):
    chord=horizontal(poly,y);r=net_diameter/2
    removed=[]
    for xh,yh in centres:
        if abs(y-yh)<r:
            half=math.sqrt(r*r-(y-yh)**2);removed.append((xh-half,xh+half))
    intervals=remove_intervals(chord,removed);s=section(intervals,t)
    V=sum(f for _,f in forces)*axis[0];N=sum(f for _,f in forces)*axis[1]
    M=sum(f*((centres[j][0]-s['centroid_x'])*axis[1]-(centres[j][1]-y)*axis[0]) for j,f in forces)
    sigma=[N/s['A']+M*(x-s['centroid_x'])/s['I'] for x in chord]
    tau=1.5*abs(V)/s['A']
    return dict(**s,y=y,chord=chord,net_intervals=intervals,N=N,V=V,M=M,sigma_edges=sigma,
        tau=tau,VM=math.hypot(max(map(abs,sigma)),math.sqrt(3)*tau))


def weld_intervals(poly,axis,lines,t):
    """Exact low-order rational extrema, local coordinate s=y-low.

    Each line has start/end points parallel to axis and total scalar force F.
    Uses direct equilibrium to recover its affine remaining force on each event
    interval. Each edge normal stress has numerator degree <=2 and width^2
    denominator. The derivative has at most one nonconstant real root.
    """
    events=sorted(set([p[1] for p in poly]+[p[1] for line in lines for p in (line['start'],line['end'])]))
    out=[]
    for low,high in zip(events,events[1:]):
        if high-low<EPS:continue
        mid=(low+high)/2
        s0=horizontal(poly,low);s1=horizontal(poly,high)
        if s0 is None or s1 is None:continue
        d=high-low
        wl=s0[1]-s0[0];wr=s1[1]-s1[0];w1=(wr-wl)/d
        if min(wl,wr)<=EPS:continue
        c0=sum(s0)/2;c1=(sum(s1)/2-c0)/d
        n0=n1=v0=v1=m0=m1=m2=0.
        C,S=axis
        for line in lines:
            p,q,F=line['start'],line['end'],line['F'];ys,ye=p[1],q[1]
            if mid<=ys:f0,f1=F,0.
            elif mid>=ye:f0,f1=0.,0.
            else:f0,f1=F*(ye-low)/(ye-ys),-F/(ye-ys)
            k=p[0]*S-p[1]*C+low*C
            n0+=S*f0;n1+=S*f1;v0+=C*f0;v1+=C*f1
            m0+=k*f0;m1+=k*f1+C*f0;m2+=C*f1
        # Moment about the actual moving chord centroid, not the base-envelope centre.
        m0-=n0*c0;m1-=n0*c1+n1*c0;m2-=n1*c1
        records=[]
        for sign in (-1.,1.):
            p0=n0*wl+sign*6*m0
            p1=n0*w1+n1*wl+sign*6*m1
            p2=n1*w1+sign*6*m2
            d0=p1*wl-2*p0*w1;d1=2*p2*wl-p1*w1
            points=[(0.,'boundary'),(d,'boundary')]
            if abs(d1)>1e-12:
                s=-d0/d1
                if 1e-8<s<d-1e-8:points.append((s,'stationary'))
            rows=[dict(y=low+s,kind=kind,sigma=(p0+p1*s+p2*s*s)/(t*(wl+w1*s)**2)) for s,kind in points]
            records.append(dict(edge='left' if sign<0 else 'right',numerator=[p0,p1,p2],derivative_numerator=[d0,d1],candidates=rows))
        tau=max(1.5*abs(v0+v1*s)/(t*(wl+w1*s)) for s in (0.,d))
        sig=max(abs(r['sigma']) for e in records for r in e['candidates'])
        out.append(dict(interval=[low,high],width_coeff=[wl,w1],centroid_coeff=[c0,c1],N_coeff=[n0,n1],V_coeff=[v0,v1],M_about_centroid_coeff=[m0,m1,m2],edges=records,
            tau_max=tau,sigma_abs_max=sig,conservative_VM=math.hypot(sig,math.sqrt(3)*tau)))
    return out


def witness():
    C=1/math.sqrt(2);axis=(C,C);base=[(0.,0.),(400.,0.),(400.,300.),(0.,300.)]
    holes=[(150.,150.),(250.,250.)];ref=max(dot(axis,p) for p in holes);cut=ref+35.;poly=cap(base,axis,cut)
    roles=edge_roles(poly,base,['root_support','right_free','top_free','left_free'],axis,cut)
    b=discrete_section(base,200.,10.,holes,20.6375,[(1,50000.)],axis)
    s=discrete_section(poly,200.,10.,holes,20.6375,[(1,50000.)],axis)
    assert close(s['width'],349.4974746830583)
    assert close(s['VM'],30.017451128321)
    area,cg=area_centroid(poly)
    vdir=(-C,C);u0=dot(axis,holes[0]);ends=[]
    for v in (-10.,10.):
        start=add(scale(axis,u0),scale(vdir,v))
        ends.append(dict(v=v,uncut=line_interval(base,start,axis)[1]+u0,cut=line_interval(poly,start,axis)[1]+u0))
    ligament=35.-20.6375/2
    chord_before=line_interval(base,scale(axis,u0),vdir);chord_after=line_interval(poly,scale(axis,u0),vdir)
    assert all(close(x,y) for x,y in zip(chord_before,chord_after))
    assert close(sum(x['cut']-u0 for x in ends),352.842712474619)
    # Actual nearest-segment gauge differs from nominal plane offset here.
    bad_ref=(380.,200.);bad_cut=dot(axis,bad_ref)+35.;bad_poly=cap(base,axis,bad_cut)
    plane_foot=add(bad_ref,scale(axis,35.));cap_edge=next(e for e in edge_roles(bad_poly,base,['root_support','right_free','top_free','left_free'],axis,bad_cut) if 'outer_normal_cut_free' in e['roles'])
    foot_distance=segment_distance(plane_foot,cap_edge['start'],cap_edge['end'])[0]
    assert foot_distance>1. and line_interval(bad_poly,bad_ref,axis)[1]<35.
    return dict(scope='Geometry-only witnesses; no full connection design or independent external bearing qualification',
        primary=dict(base=base,axis=axis,centres=holes,reference_u=ref,cut_u=cut,polygon=poly,edges=roles,
            area=area,centroid=cg,removed_area=120000.-area,outer_ligament_3_4_inch=ligament,
            horizontal_uncut=b,horizontal_capped=s,force_normal_at_first_uncut=chord_before,force_normal_at_first_capped=chord_after,
            U_path_exits=ends,old_gross_shear_length=sum(x['uncut']-u0 for x in ends),capped_gross_shear_length=sum(x['cut']-u0 for x in ends)),
        old_edge_before_cap=dict(reference=bad_ref,cut_u=bad_cut,polygon=bad_poly,plane_foot=plane_foot,
            foot_misses_bounded_cut_by=foot_distance,actual_outward_exit=line_interval(bad_poly,bad_ref,axis)[1],nominal_gauge=35.))


def self_test():
    r=witness();base=r['primary']['base'];a=r['primary']['axis'];cut=r['primary']['cut_u']
    poly=cap(base,a,cut)
    # Mirror 45 -> 135 with translated mirror axis x=200.
    mirrored_base=[(400-x,y) for x,y in reversed(base)]
    mirrored=cap(mirrored_base,(-a[0],a[1]),cut-400*a[0])
    assert close(area_centroid(poly)[0],area_centroid(mirrored)[0])
    vertical=cap(base,(0.,1.),285.)
    assert close(area_centroid(vertical)[0],114000.)
    assert retained_segment(poly,(0.,0.),(400.,0.))
    assert all(circle_retained(poly,p,20.6375/2) for p in r['primary']['centres'])
    no_trim=cap(base,a,max(dot(a,p) for p in base)+1.)
    assert close(area_centroid(no_trim)[0],120000.)
    assert not any('outer_normal_cut_free' in e['roles'] for e in edge_roles(no_trim,base,['root_support','right_free','top_free','left_free'],a,max(dot(a,p) for p in base)+1.))
    # Cap through a supported endpoint retains line but removes positive footprint.
    root_tie=cap(base,a,400*a[0])
    assert retained_segment(root_tie,(0.,0.),(400.,0.))
    assert not retained_segment(root_tie,(0.,5.),(400.,5.))
    corner=[(30.,0.),(500.,0.),(500.,500.),(0.,500.),(0.,30.)]
    corner_cut=cap(corner,a,650*a[0])
    er=edge_roles(corner_cut,corner,['beam_support','right_free','top_free','column_support','inner_relief'],a,650*a[0])
    lengths={role:sum(e['length'] for e in er if role in e['roles']) for role in ('beam_support','column_support','inner_relief')}
    assert close(lengths['beam_support'],470.) and close(lengths['column_support'],470.) and close(lengths['inner_relief'],30*math.sqrt(2))
    # Hole interval unions use real chord, overlap/clip at final polygon boundaries.
    s=discrete_section(poly,250.,10.,r['primary']['centres'],22.6375,[(1,50000.)],a)
    assert close(s['width'],299.4974746830583-22.6375)
    r['boundary_cases']=dict(mirrored_polygon=mirrored,vertical_polygon=vertical,vertical_area=114000.,no_trim_polygon=no_trim,
        root_endpoint_tie_polygon=root_tie,root_line_retained_but_5mm_footprint_removed=True,
        corner_polygon=corner_cut,corner_edges=er,corner_supported_lengths=lengths,horizontal_net_hole_case=s)
    return r

if __name__=='__main__':
    result=self_test()
    dest=Path(__file__).with_name('independent_expectations.json')
    dest.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print('Independent geometry checks passed; wrote',dest)
