from independent_cap_oracle import *
import random
random.seed(391939)
base=[(-200.,0.),(200.,0.),(200.,300.),(-200.,300.)]
def inside(poly,p):return all(cross(sub(q,a),sub(p,a))>=-EPS for a,q in zip(poly,poly[1:]+poly[:1]))
best=None
for k in range(25000):
    theta=random.uniform(30,150);C=math.cos(math.radians(theta));S=math.sin(math.radians(theta));a=(C,S);vdir=(S,-C)
    center=(random.uniform(-120,120),random.uniform(70,230));L=random.uniform(50,200);e=random.uniform(5,60);leg=5.;ec=28.;width=100.;F=100000.
    xy=lambda u,v:add(center,add(scale(a,u),scale(vdir,v)))
    cut=dot(a,center)+L/2+e
    try:poly=cap(base,a,cut)
    except ValueError:continue
    if close(area_centroid(poly)[0],120000.):continue
    if not all(inside(poly,p) for p in [(-200,5),(200,5)]+[xy(u,v) for u in (-L/2-20,L/2) for v in (-width/2-leg,width/2+leg)]):continue
    lines=[dict(start=xy(-L/2,v),end=xy(L/2,v),F=F*ff) for v,ff in ((-width/2,1-ec/width),(width/2,ec/width))]
    intervals=weld_intervals(poly,a,lines,10.)
    for interval in intervals:
        if abs(interval['width_coeff'][1])<1e-8:continue
        for edge in interval['edges']:
            rows=edge['candidates'];bounds=[abs(x['sigma']) for x in rows if x['kind']=='boundary']
            for row in rows:
                if row['kind']=='stationary' and abs(row['sigma'])>max(bounds)*1.001:
                    ratio=abs(row['sigma'])/max(bounds)
                    if best is None or ratio>best[0]:best=(ratio,dict(theta_deg=theta,center=center,L=L,e=e,leg=leg,ec=ec,width=width,F=F,polygon=poly,axis=a,cut=cut,lines=lines,interval=interval,stationary=row,edge=edge['edge'],all_intervals=intervals))
if best:
    Path(__file__).with_name('independent_rational_witness.json').write_text(json.dumps(best[1],indent=2)+'\n')
    print('Best stationary/boundary ratio',best[0]);print(json.dumps({k:v for k,v in best[1].items() if k not in ('all_intervals','interval','lines')},indent=2))
else:print('No witness')
