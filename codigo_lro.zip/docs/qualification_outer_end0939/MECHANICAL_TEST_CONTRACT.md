# Independent outer-cap mechanical test contract

Prepared 12 October 2026, read-only planning phase. Both actual user images were opened and inspected before reviewing geometry. The second tapered sketch is deferred. The only intended increment is the first perpendicular outer end cut, with all complete physical roots and required footprints preserved.

No production file was edited or cloned. `review0938/source0938` was not read, imported, or executed in this preparation. Selected immutable `review0937/source0937` interfaces were read to understand result contracts. No candidate verdict is given: `review0939/source0939` has not yet been supplied for review.

## Results available now

The standalone `independent_cap_oracle.py` imports no production modules. Its construction of the clipped polygon, half-plane line intersections, bounded segment distances, section unions, polygon moments, and rational section extrema is independent of the application implementation. `verify_independent_contract.py` adds independent numerical integration of distributed weld forces with SciPy and runs seven test groups successfully. Shapely is not installed; no claim of Shapely verification is made.

The prepared expected values are in `independent_expectations.json` and `rounded_rational_expectations.json`. The execution record is `independent_test_log.txt`.

### Witness 1: same roots and first force-normal chord, changed horizontal mechanics

The geometry in the supplied specification is reproduced independently:

- Base polygon: [0,400] × [0,300] mm, thickness10 mm, theta45°.
- Physical hole centres: (150,150), (250,250) mm. The second centre defines the final physical +u reference.
- Cap plane: x+y=549.497474683058 mm, axial centre-to-cap distance35 mm.
- Standard Ø3/4-inch physical hole:20.6375 mm. Terminal clear ligament:24.68125 mm, provided the new segment is the actual first outward exit.
- At y200 mm, capped width349.497474683058, centroid174.748737341529, inertia35575489.1478327 mm4.
- With the remaining second-hole force50 kN, capped M892766.952966370 N mm and nominal VM30.017451128321 MPa, against24.606274606287 MPa uncut.
- Illustrative U-path gross shear length falls424.264068711929 →352.842712474619 mm.
- Full root and constant-u chord at the first transfer station remain identical.

This is a geometry/mechanics witness, not a complete passing connection or a bearing-capacity benchmark.

### Witness 2: an interior sign change that all event endpoints miss

A compact deterministic welded witness exercises the rational extrema and existing mixed-sign gate:

- P0=[−200,200]×[0,300] mm; t10 mm; theta64°; attachment centre(20,110) mm.
- Two physical longitudinal lines at v=−50,+50 mm; L40 mm; force fractions0.72/0.28; total N100 kN. Nominal leg100 mm and centroid28 mm define this independent mathematical source, not an adopted catalog record.
- New outer weld margin6 mm from physical ends. Weld leg5 mm, support-side free extension20 mm.
- The cap retains all of the root and its positive 5 mm interior collar, the source/free-end footprint, and an introduction strip140 mm wide. Local introduction stress minimum4.081632653 MPa and spread26.565051177°.
- Final polygon: (−200,0),(200,0),(200,51.135784510500),(−200,246.228819936844) mm.
- Every horizontal event endpoint is nonnegative within roundoff (−9.55e−15 MPa minimum). The complete uncut section field is nonnegative.
- The capped left edge reaches −7.856233771866 MPa at interior y137.625179557475 mm. This is an actual section-model compression value, not roundoff.
- All endpoint and interior stresses agree with independent numerical source integration. Dense interval checks lie inside the analytic extrema envelope. Numerical differentiation confirms stationary points.
- Reversing N reverses N,V,M and both edge stresses without rotating or relocating the cap. The interior value becomes +7.856233771866 MPa, so the existing wholly-compressed domain must also reject this reversed-sign field if applied.

The fixture is not a full connection qualification. Its purpose is to distinguish correct variable-chord equilibrium/extrema from endpoint-only or rectangle-preserving implementations. No production rule should be specialized to it.

## Required candidate gates

### G1. Physical identity and exact geometry

1. Derive a unit +u direction from the physical attachment orientation independently of load sign, N=0, the45 kN candidate case, and tension/compression sign.
2. Bolted Uref must be max(a·centre) over unique physical through-bolts. 2L-T must not create twice as many holes, shift Uref, or cut from a diameter surface. Welded Uref must use actual physical outward weld endpoints; inactive bolt fields must not influence it. Conversely, inactive weld parameters must not set a bolted cap.
3. A count/pitch/row-offset change must move the reference with the physical last bolt. A weld-length/position change must move it with physical ends. Old support-side `angle_end`, `end_margin`, and `brace_free_end_extension` remain independent.
4. P must be exactly P0 intersect the cap half-plane, with positive convex area, preserved winding, unique vertices and positive-length edges. Cover45°,90°,135°, valid near-axis cases, old-vertex intersections and mirrored shapes. Disallowed geometry is rejected, never repaired by changing an input or trimming a root.
5. Cap crossings must preserve every complete supported contact segment, every effective seam and required root-weld/fabrication footprint. Endpoint containment proves segment containment for a convex polygon, but centreline endpoints alone do not prove footprint containment. The oracle includes a cap through a root endpoint that retains the whole support line while removing a positive5 mm collar: it must fail a footprint requirement.
6. Preserve physical/net hole circles separately, hardware/tool envelopes, overlap, free angle end, weld footprints and local introduction. Do not require the entire brace continuation to lie within the plate.
7. Full physical roots must remain explicit semantic objects. Rotating a vertex list or inserting a cap vertex cannot relabel a root, inner relief, seam, root allowance or receiver-contact extent. Cap-vertex ties preserve all incident identities.

### G2. Actual edge distances and terminal bearing

1. The promised editable gauge is valid as an actual centre/end-to-cap dimension only if its perpendicular foot lies on the bounded final cap segment and that segment is the first outward ray exit. A nominal infinite-plane offset alone is insufficient.
2. The oracle gives an active-cap counterexample from reference(380,200) in the primary rectangle: nominal35 mm, but the old right edge is encountered at28.284271247462 mm; the nominal cap foot lies beyond the actual segment. Reject the promised gauge geometry or explicitly expose its non-governing status. Never print35 mm as the physical exit distance.
3. The last gusset bearing/tear-out clearance is outward ray distance minus half the physical hole diameter. Pitch ligaments for interior bolts and angle-side reverse-force clearances remain separate. Gusset demand remains total N divided by physical bolt count; angle demand respects per-angle force without duplicating the gusset.
4. Use20.6375 mm physical hole for selected Ø3/4-inch standard holes. Net deductions use the independently declared drilled policy. Changing contour-cut technology does not declare drilled holes.
5. Keep Table16 minimum25 mm at Ø3/4 as the current conservative application screen, with its source caveat. Keep existing min(12t,150 mm) applicability and the corner interpretation's unverified status. Do not invent a35 mm universal minimum, diameter table, weld standard or laser-specific rule.
6. Existing external bearing qualification gap remains disclosed. These geometric/scalar checks are not a replacement for the missing independent external bearing oracle and must not be relabeled as such.

### G3. Rupture paths and net polygons

1. Every outward longitudinal U/L exit stops on the actual tagged boundary; the positive cap at fixed u has zero du_exit/dv slope wherever it controls. Dispatch by an old edge-name category must not accidentally reuse a horizontal/vertical slope.
2. Recompute shear lengths, transverse gross/net lengths, all path point coordinates and free-edge identities, keeping both existing NBR branches. Do not sum alternative path capacities.
3. Retain relevant vertex events, hole centre/tangency events, crossing-force inclusion/exclusion limits and interior-cap extrema. A changed cap cannot silently retain a stale list of geometry intervals or root-contact statuses.
4. At all constant-u sections below the cap, transverse chords are unchanged, but their consumers must reference the final polygon or independently prove containment against it. An outward longitudinal exit is not covered by that invariant.
5. Positive supported-contact length keeps a block path inactive even when an endpoint simultaneously touches a free edge. Tied display labels must not erase physical support contact. Retain complete support-contact checks with tolerance expressed in physical length.

### G4. Horizontal and force-normal sections

1. Actual horizontal chord endpoints depend on y and include every new polygon-vertex y in their event partition. Use the final polygon height/domain: a cap can remove the entire old top edge, leaving no material up to the old H input. Net hole intervals are intersected/subtracted from actual chords; area, centroid and inertia use the resulting union. Handle a zero-width terminal vertex with zero remaining force as an inactive zero-measure endpoint without division by zero; do not discard a positive-demand or positive-measure section.
2. Recompute moment about the actual section centroid. Keeping the old origin-centred moment with a moved centroid is wrong even when N and V are unchanged.
3. For welded intervals use xL(y),xR(y), w(y)=xR−xL and c(y)=(xR+xL)/2. End normal stresses are [N(y)w(y)±6Mcentroid(y)]/[t w(y)^2]. With affine N,V,w,c and quadratic Mcentroid, normal stress is rational, not the old quadratic. Enumerate derivative roots and interval endpoints. The numerator of dσ/dy is at most affine after cancellation; a constant stress is not an isolated stationary root.
4. Tau=1.5|V|/(tw) is a ratio of affine functions. Its extrema lie at interval boundaries except its nondifferentiable zero (a minimum); a verified conservative VM may combine separate normal and shear maxima as before. If claiming exact pointwise VM extrema, solve its rational derivative rather than relabeling the conservative envelope.
5. The deterministic sign-change fixture must return the interior negative value and trigger the existing tension-domain restriction; after sign reversal it must retain the existing compression-domain restriction.
6. Bolted sections retain their explicit supplemental-nominal, non-interval-certified status. Merely increasing sampling does not establish a mathematical proof or continuum/contact qualification.

### G5. Root, Whitmore, receiver and full-joint invariance

1. If every transfer station lies below the cap, constant-u chords and a previously contained force-normal/Whitmore strip stay geometrically identical. Check all final endpoints and root projections before declaring the invariant. A reduced P never restores missing inner-root support.
2. Root actions, force point, complete roots, weld-group properties and receiver inputs must be freshly recomputed and compared with the original geometry. Equality is expected only where all of their physical inputs are unchanged.
3. For2L-T, N/2 belongs to each physical angle; N once belongs to the common plate, roots and receptor. Shared through-bolts are counted once in physical geometry.
4. Preserve COMPLETE_CUTS equilibrium, load signs and exact physical beam/column contact extents. Remove fixed polygon-index dependencies rather than relying on one insertion order preserving a y coordinate by coincidence.
5. Do not change K, invent a new buckling boundary, shorten a compression length automatically or apply an absolute-value tension substitution. Existing1L compression remains unverified. Existing2L compression retains every physical-evidence and mixed-stress gate.

### G6. Inactive fields, no-op geometry and native evidence

1. Existing native files migrate to `original` with all prior unrounded results reproduced. New controls round-trip exactly through the appropriate version schema; invalid enum/type/bool-as-number/nonfinite inputs are rejected consistently.
2. Disabled cap controls never change P or mechanics. If inactive positive distance controls are accepted and stored, their meaning must be explicitly inactive; their values must not leak into the active route's reference or signature as physical changes.
3. A plane beyond P0, exactly touching one original vertex, or coinciding with an original edge removes no material. Record inactive/no-trim state; do not create a new positive-length fabricated edge or a false dimension. Preserve original edge identities at coincidence.
4. Effective polygon changes invalidate applicable geometry-bound restraint evidence. Using a changed active control that actually changes P cannot leave a stale declared stamp current. A no-op change can preserve a physical-geometry digest consistently; conservative invalidation is also acceptable if clearly presented.
5. One-root and corner compression stamps must receive actual final geometry. Native read/load must recompute current results and cannot trust a serialized previous polygon or approval.
6. Opposed-vertex routes remain unchanged/outside this initial cut scope. A shared base class must not silently expose the new feature to an unconverted route.

### G7. Evidence and release

The mechanical review will compare the candidate to these independent scalar/polygon results plus its prior uncut regressions. The root parent must supply the exact candidate path and source GO before candidate work starts. Final scope needs tests for all routes actually enabled, native/migration checks, status/sign/evidence cases, and visualization/report/export agreement on the same polygon. Drawing/report review is separate from this mechanical contract. No read-only planning pass or isolated fixture makes the feature released, manufacturing-approved, or externally bearing-qualified.

## Normative review boundary

This review uses the visually checked NBR clauses recorded in `GEOMETRY_SPEC.md`: Table14 physical holes; Table16 and6.3.11.1 edge screening;6.3.12 maximum distance;6.2.6.2.6(a) and Figure12 weld termination; and the separate overlap/effective-length provisions. It adds no numerical design limit. It does not independently reread the NBR page images in this preparation.
