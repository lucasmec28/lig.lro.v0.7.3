# End plate rotulada: correção delimitada 0.9.11

10 de outubro de 2026. Terceira família existente do seletor; não cria outra família, não reaudita o engaste e não certifica o nó completo. Revisão própria: `endplate-pinned-nbr-scoped-0911-v1`. Esquema JSON 1 e identidades dos 17 ramos preservados.

## Topologia e ações preservadas

Viga I ortogonal à mesa de coluna I contínua, centrada na alma da coluna. Chapa de altura total soldada continuamente à alma e às duas mesas da viga; duas colunas de parafusos, 2 a 10 linhas, unindo chapa e coluna. A viga apoiada não possui furos. Não há solda direta viga–coluna, calço, recorte, enrijecedor adicional nem momento externo modelado.

N positivo é tração normal à chapa, N negativo é compressão por contato; V é vertical. A conferência mínima de 45 kN mantém a direção e o sinal da resultante N/V e aparece separada da entrada. O vetor zero não define direção e é dado necessário ausente, não geometria impossível. A tolerância |M| ≤ 1e-9 N·mm é zero numérico; a interface normaliza explicitamente esse resíduo antes de aceitar o projeto. Valores maiores são rejeitados.

## Resistência e qualificações locais

NBR 8800:2024, versão corrigida 2025, permanece a camada de resistências. SCI P358 (2014), seção 4.7/Check 1, é referência complementar para detalhamento convencional de rótula. A adoção convencional pode ser feita pelo responsável conforme NBR 6.1.2.3; a ausência de curva momento–rotação não exige automaticamente FEA.

As contas existentes para a parcela N/V são conservadas: tração atribuída à alma, N+/2n nos parafusos, interação elíptica, duas condições locais para omissão de alavanca, compressão por contato, soldas da alma e metal-base, blocos parciais/completos, contato nos furos, alma da viga e efeitos locais da coluna. As quatro qualificações abaixo NÃO estão fechadas:

1. Hierarquia das soldas alma–chapa ou cálculo com momento coexistente da rotação, nos materiais efetivos.
2. Tração de parafusos induzida pela rotação, ou reserva justificada, combinada com N/V.
3. Transferência pelas soldas das mesas e efeitos locais, com distribuição compatível entre alma e mesas.
4. Mecanismo simultâneo de N/V, tração e compressão, para a topologia de altura total; distribuição, cortes físicos/interações da chapa, alavanca nula e contato.

Essas lacunas aparecem junto ao resultado no aplicativo, JSON, SVG e Word. Nenhum caso é aprovado como qualificação local completa. O diagnóstico de reserva de 20% da auditoria não foi incorporado como fórmula NBR. Os valores 0,40tw/0,48tw do SCI são dependentes dos materiais da fonte e também não foram transplantados.

O critério de ductilidade da nota 4 do SCI é identificado como complemento de distribuição plástica em amarração, sem alegar que qualifica o N/V ordinário ou toda a rotação. Sobra até 10 mm e grupo abrangendo d/2 são limites da aplicação, sem atribuição indevida ao Check 1. Extrapolações permanecem explícitas. Condições de alavanca não satisfeitas impedem que um resultado de parafusos numericamente favorável seja apresentado como qualificado; a sobrecarga finita, se presente, continua não atendida.

## Correções de detalhamento

- Passo e gabarito mínimos: 2,7db, conforme NBR 6.3.9 (p.91/PDF113 da cópia fornecida). Não usar 8db/3 nem citar 6.3.7, que trata de pega longa. A igualdade decimal exata é admitida. O limite é construído com aritmética decimal do diâmetro de catálogo e do coeficiente 2,7, sem criar tolerância de fabricação; valores realmente abaixo continuam não conformes. Furos sobrepostos, sem ligamento livre positivo ou fora do material são geometria inválida. Distâncias fisicamente viáveis abaixo dos mínimos adotados são não conformidade de detalhamento, com cálculo disponível e entradas preservadas.
- Bordas mínimas tabuladas permanecem limites do detalhe suportado; a exceção normativa mediante contato não está qualificada nesta implementação. Não são apresentadas como mínimos normativos sem exceção.
- Mínimo de filete por junta: menor espessura real de alma–chapa e mesa–chapa, separadamente. NBR 6.2.6.2.1/Tabela 11 (p.80/PDF102): até 6,3 → 3 mm; acima de 6,3 até 12,5 → 5 mm; acima de 12,5 até 19 → 6 mm; acima de 19 → 8 mm. Espessura comercial 6,35 não é arredondada para 6,3.
- Máximo por cada borda física: espessura integral abaixo de 6,3 mm; na igualdade e acima, espessura−1,5 mm, salvo reforço de borda declarado. A borda exposta é a extremidade da alma (tw) ou da mesa (tf) da viga. A chapa recebe a solda pela face: tp não cria um máximo de borda fictício. O filete comum atende aos dois máximos das bordas da viga, NBR 6.2.6.2.2 (p.80–81/PDF102–103). O único filete informado deve atender às duas juntas. Violações de mínimo/máximo são detalhamento; comprimento resistente L=clear−2w não positivo é geometria inválida.

## Conclusões e resumos

Falha resistente finita tem precedência sobre lacuna independente, não conformidade, condição do método ou falha numérica em outro ramo. Capacidade não finita/zero, resultado não finito e exceção aritmética são falha numérica, não prova de sobrecarga. O quadro distingue resistência, condição do método e N/A. Caminhos sem demanda completa ficam N/A, inclusive alavanca por N≤0, contato por N≥0 e blocos por V=0. Essa ativação é própria do modelo atual; deverá ser revisada se a demanda de rotação for qualificada.

O JSON mantém todos os 17 ramos originais em `checks`; `summary_checks` é a apresentação de 14 linhas, com categorias, aplicabilidade e resultado. Demandas/resistências não finitas são `null`, nunca infinito JSON. O resumo remove somente aprovações escalares de parafusos implicadas pela elipse e apresenta a envoltória dos dois ramos da alma. As capacidades/demandas de parafusos e as equações de ambos os ramos da alma continuam na memória, com índice e ramo governante. Cv para alma esbelta NÃO é eliminado. Não se acrescenta dedução de furos inexistentes na viga.

A álgebra da auditoria para um caminho tentativo de cisalhamento líquido de altura total hp é restrita a esse corte e aos limites A36 examinados. Não qualifica todos os cortes menores entre mesas, internos ou parciais. Nenhuma dispensa genérica de caminho líquido da chapa foi implementada. A definição dos cortes físicos permanece na quarta qualificação local acima. Blocos existentes continuam calculados.

## Fidelidade dos dados e artefatos

Antes de substituir o projeto, a interface rotulada verifica controles numéricos ativos, avaliação e identidade completa dos perfis de catálogo. fw=0,5 MPa, raio=0,5 mm e sobra=0,05 mm são rejeitados com campo, valor e motivo; projeto e Word anteriores permanecem intactos. Não se cria editor de perfis personalizados. Espessuras não comerciais e quase comerciais ficam exatas, sem seleção por proximidade. Campos inativos de engaste permanecem intactos. N↔kgf é permitido dentro do erro normal de ponto flutuante, verificado até 2 ULP nos casos exercitados; não há arredondamento de engenharia.

O rascunho de espessura personalizada tem armazenamento separado do seletor comercial e do widget condicional. Sobrevive a personalizado→comercial→rerun→personalizado e à navegação, inclusive quando o rascunho é inválido. Novo projeto/exemplo substitui conscientemente esse rascunho.

JSON, SVG e as duas variantes Word derivam da entrada atual, com SHA-256 comum; relatórios não confiam em aprovação importada nem resultado passado pelo chamador. Alterações e troca de variante invalidam downloads anteriores. O desenho identifica as setas como sentidos positivos de referência e imprime N/V assinados. É ilustração proporcional, não desenho completo para fabricação.

## Evidência e limite desta etapa

Teste delimitado inclui 136 substituições independentes, fronteiras exatas de todos os sete diâmetros e 6,3/12,5/19 mm, dois presets e exemplo existente, casos de sinais/compressão/mínimo, erro numérico versus falha finita, leitor real AppTest, navegação/rascunhos e downloads reais. Exemplos desta família foram recalculados. A regressão compartilhada do engaste compara entradas, premissas, saídas e metadados anteriores, sem reabrir a auditoria daquela família.

Não foi executada a suíte inteira. AppTest e imagens renderizadas dos documentos/desenhos não equivalem à inspeção visual do navegador, indisponível por restrição de socket. Não há empacotamento, upload, publicação ou implantação nesta implementação.
