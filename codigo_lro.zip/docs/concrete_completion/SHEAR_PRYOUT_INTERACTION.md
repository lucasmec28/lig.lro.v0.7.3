# Cast-in anchor concrete shear, pryout and interaction: implementation contract

2026-10-09. Research/specification only. Do not replace NBR checks. Read together with `gap_matrix.md`, `../concrete_anchor_scope/specification.md`, and the headed-anchor tension scope. This closes equations within a stated static regular-group domain, not the complete column base or reinforced foundation.

## 1. Recommended supported scope and minimum extra information

A regular rectangular 2×2 group of four identical cast-in mechanically headed or buried-nut rods; common physical embedment; actual intact rectangular concrete prism; normalweight cracked concrete; no reinforcement strength credit; no seismic/fatigue/impact/fire. NBR actions remain factored and concurrent. The existing strong-axis x shear is signed and has no plan torsion or transverse component. The group and applied shear line are symmetric in y. A wider generic vector/torsion model is outside this increment.

Already needed: real concrete bounds/depth/fc; actual head/nut detail; physical hef excluding grout; actual rod coordinates and same-combination tensions Ti. New information truly needed:

1. Thread series/pitch or documented effective tensile/shear areas Ase,N/Ase,V. ACI uses actual effective area, not NBR's nominal-area coefficient. Existing inch diameter alone does not prove pitch.
2. Material ductility classification/reference if the higher ACI factors are wanted. For existing A36 rod, do not silently declare ACI ductility from fy/fu alone. A conservative explicit unverified-ductility route can use brittle factors until certified otherwise.
3. Shear engagement model: qualified equal sharing among all four identical rods, selected near-row sharing, or a documented external concurrent per-rod distribution. A numeric aggregate group resistance is NOT a force distribution. Do not infer V/4 from four drawn rods.
4. For equal sharing, one explicit engineering declaration plus detail reference must establish four standard-hole upper washers genuinely engaging their own rods, welded to the plate with adequate load transfer/stiffness and verified construction fit, identical relevant rod stiffness, a sufficiently stiff fixture for the assumed shear sharing, and no sleeves/voids/standoff through the shear-transfer zone. The declaration must be tied to geometry/actions/details; changing those invalidates it. Actual dimensions should be reused, not duplicated. It is not a substitute for the still-open washer/baseplate mechanics.
5. Built-up grout pad flag comes from real geometry, not a discretionary strength toggle. Use the ACI0.80 steel-shear reduction where present.

DG1 pp.33–34 cautions that hole tolerances may leave unequal rod forces and discusses selective transfer, standard-hole welded plate washers, and setting plates. It permits an engineered equalizing detail; a welded upper washer is distinct from an anchor shank continuously welded to the attachment. Do NOT apply the enhanced Vb coefficient8 or rigid-welded-anchor rear-row-only route just because the washer perimeter is welded.

## 2. Units and independent design bases

Keep the public API N/mm/MPa, but convert once for ACI/DG1 formulas to inch/psi/lbf. Constants: 1in=25.4mm; 1lbf=4.4482216152605N; 1psi=0.006894757293168361MPa. The coefficients7,9,24,160 are US-unit coefficients; never insert them into an MPa/mm formula.

fc is specified cylinder strength f'c, not NBR fcd. Use existing20–50MPa normalweight range and disclose the adopted supplementary ACI design basis for NBR-factored actions. Apply ACI phi once, no additional gamma_c or second load factor. The result is not a claim that ACI resistance and NBR actions are one calibrated code system.

## 3. Source-prescribed shear breakout row cases

Keep actual force-transfer assumptions separate from concrete failure-mechanism demand. The app currently has no actual qi. Before computation establish qi>=0 in the selected shear direction, sum(qi)=abs(V), and zero plan torsion, with paired equal qi across y for this bounded model. The normal-direction two rows can carry different amounts if independently documented; the simple qualified equal-sharing route uses qi=abs(V)/4. This is a declared mechanical assumption, not a formula silently extracted from the current NBR aggregate resistance.

For the edge TOWARD which V acts, let c_front be its physical distance to the near x row, s_parallel the x-row separation, and c_back=c_front+s_parallel. Use physical distances to select the cases, before any narrow-member computational reduction.

- When s_parallel>=c_front, check Case1 at the near row with the sum of the actual two near-row qi, AND Case2 at the back row with the total |V|. For equal sharing these are V/2 and V. The two mechanism demands are not simultaneous duplicate external loads.
- When s_parallel<c_front, Case3 uses the near row with the total |V|.
- Each selected row is two collinear anchors at the same ca1, with its own actual transverse spacing and edge distances. A group has overlapping projections; if transverse spacing>3ca1_calc, evaluate the two disconnected anchor components separately, with their corresponding column shares. Do not sum independent component capacities to hide an overloaded component.
- Case2 does not authorize arbitrary plastic redistribution of steel or fixtures. The adopted force-transfer design must establish the required load path. Where only the near row is deliberately credited as the physical path (DG1 Example4.7-4), its two rods and attachments each carry V/2 and the remote rods receive no shear credit. Where all four are qualified as equal-sharing, preserve that actual distribution in the steel checks and separately identify the ACI concrete mechanism demand. Flag the source/detail interpretation for engineering review if claiming a complete joint; do not silently change NBR from four-rod to two-rod geometry.

Primary supplied source: DG1Example4.7-4, pp.76–78, explicitly treats a 2×2 group using Case3 and limits the credited steel/concrete path to the near pair. Public primary explanation of ACI commentary cases: Hilti's official [October2025 shear guide, p4](https://viewer.joomag.com/design-guide-for-considering-concrete-breakout-in-shear-using-aci-318-anchoring-to-concrete-provisions-october-2025/0323980001758646474/p4) and [p5](https://viewer.joomag.com/design-guide-for-considering-concrete-breakout-in-shear-using-aci-318-anchoring-to-concrete-provisions-october-2025/0323980001758646474/p5). Its multi-anchor row extension is explained on [p6](https://viewer.joomag.com/design-guide-for-considering-concrete-breakout-in-shear-using-aci-318-anchoring-to-concrete-provisions-october-2025/0323980001758646474/p6). Identify that extension as such, rather than claiming the commentary diagram explicitly draws every2×2 case.

### Optional conservative row envelope

If deliberately selected, check full |V| at each candidate near/back row and both side-edge rows. This bounds the source row demand comparisons for the same nonnegative load direction. Label it a conservative application envelope; it is not mandatory ACI and does not describe simultaneousV applied to several rows. It must not be the hidden default, nor cure unknown rod/washer engagement, unknown concrete geometry or torsion. No arbitrary15-subset default is proposed.

## 4. One row / component shear-breakout kernel

Use a local coordinate u perpendicular to a selected free edge and v along it. ca1_physical is distance to that edge; row anchor coordinates are vi; concrete limits are vmin/vmax; ha is actual structural concrete depth, excluding grout. For the two-rod row:

c2_left=min(vi)-vmin; c2_right=vmax-max(vi); s_perp=max(vi)-min(vi).

### Narrow-member correction, ACI17.7.2.1.2

If BOTH c2_left and c2_right AND ha are strictly below1.5ca1_physical:

ca1_calc=min(ca1_physical, max(max(c2_left,c2_right)/1.5, ha/1.5, s_perp/3)).

Otherwise ca1_calc=ca1_physical. Apply ca1_calc to all shear-breakout geometry, Vb, AVco, psi_ec, psi_ed and psi_h. Keep actual ca1 for physical fitting and row-case selection. This rule differs from the tension narrow-pedestal hef rule; do not reuse one as the other. For singleton s_perp=0. Relevant reproduced clause and modifiers: [Hilti guide p169](https://viewer.joomag.com/profis-design-guide-ac-318-19-july-2022/0546853001659024142/p169); ACI's [official anchorage lecture, slides101–102](https://www.concrete.org/portals/0/files/pdf/webinars/ws_F23_Matthew%20Senecal.pdf).

### Projected failure area

For each selected anchor, project a rectangle on the concrete side face: v from vi−1.5c to vi+1.5c, z from0 to1.5c, with c=ca1_calc. Clip to vmin/vmax and0..ha. AVc is their actual union area, not a plan-view tension cone and not a box spanning disjoint rectangles. For a connected two-anchor row:

AVc=[min(1.5c,c2_left)+s_perp+min(1.5c,c2_right)]*min(1.5c,ha).

AVco=4.5c². Respect AVc<=n*AVco. For disconnected rows, split components and their associated demand. The side-face projection starts at structural concrete top, not plate or grout top. References: DG1pp.35–36 and Example4.7-4; [Hilti p167](https://viewer.joomag.com/profis-design-guide-ac-318-19-july-2022/0546853001659024142/p167), [p168](https://viewer.joomag.com/profis-design-guide-ac-318-19-july-2022/0546853001659024142/p168).

### Basic strength and modifiers

For a constant-section cast-in rod, le=min(hef_physical,8da). Never use the narrow tension-cone hcalc instead of physical le, and never use grout thickness as embedment.

Vb1=7*(le/da)^0.2*sqrt(da)*lambda_a*sqrt(fc)*c^1.5.
Vb2=9*lambda_a*sqrt(fc)*c^1.5.
Vb=min(Vb1,Vb2).

The sqrt(da) is important: DG1p35 was visually inspected (render `dg1_p35.png`). The coefficient8 welded-anchor exception is excluded here. lambda_a=1 for this normalweight domain. See also [Hilti p184](https://viewer.joomag.com/profis-design-guide-ac-318-19-july-2022/0546853001659024142/p184).

psi_ec=1/[1+eV/(1.5c)] for a group; singleton1. For this symmetric uniaxial mode, each selected equal-force pair has eV=0. A documented unequal pair uses the perpendicular offset of its shear resultant from that pair's geometric centroid; do not use column M/N or anchor tension eccentricity. Keep generic torsion outside scope.

psi_ed=min(1,0.7+0.3*min(c2_left,c2_right)/(1.5c)).
psi_c=1 for cracked concrete without supplementary reinforcement credit.
psi_h=max(1,sqrt(1.5c/ha)).
Vcbg=(AVc/AVco)*psi_ec*psi_ed*psi_c*psi_h*Vb.
phiVcbg=0.70*Vcbg.

Singleton omits group eccentricity. The thickness factor has a SQUARE ROOT: plain extracted web text often loses it. Sources: DG135–36; ACI17.7.2.3–.6 as reproduced in [Hilti p180](https://viewer.joomag.com/profis-design-guide-ac-318-19-july-2022/0546853001659024142/p180), [p196](https://viewer.joomag.com/profis-design-guide-ac-318-19-july-2022/0546853001659024142/p196), and ACI lecture slide102.

### Parallel free edges and corners

Always check both actual y edges for shear parallel to those edges; absence of Vy does not make them irrelevant. For a genuinely parallel force, ACI17.7.2.1(c) permits twice the corresponding perpendicular-edge strength with psi_ed=1.0. Build the side-edge geometry in its own local axes and use the same actual force magnitude for its associated shear-active group, not zeroVy. Other modifiers remain applicable, including the narrow-member rule. No equivalent "infinite edge" may be invented merely because a distance looks large.

Implementation refinement for the regular qualified zero-torsion layout: expose an explicit `virtual_perpendicular` choice. Rotate the same assigned nonnegative force magnitudes toward each parallel edge, preserving anchor coordinates. Apply the source near/back-row mechanism construction in those local axes, including the tangent resultant eccentricity and disconnected components, then apply factor2 and psi_ed=1. This is an engineering implementation of the code's stated assumed-perpendicular construction, not an arbitrary duplicated-V envelope. The returned mechanism demands are alternative failure comparisons. Keep the chosen interpretation in the report and obtain responsible-engineer acceptance with the physical sharing qualification.

If this explicit interpretation is not selected, parallel-edge status remains pending but perpendicular and pryout results stay visible. Arbitrary torsion/opposite-sign rod forces and irregular shear-active groups remain unsupported. The reviewed sources establish the component formula and source row cases, not every optimized unequal multirow generalization. Formula/corner source: [Hilti p200](https://viewer.joomag.com/profis-design-guide-ac-318-19-july-2022/0546853001659024142/p200), reproducing ACI17.7.2.1(c–d); official ACI lecture slides103–104.

## 5. Pryout, ACI17.7.3

The pryout group is the actual group carrying SHEAR. Recalculate nominal tension-breakout geometry for that group and its shear-force eccentricity. Do not use existing `evaluate_cone()` output blindly: in C3 only two rods may be tensile while four carry shear, and in pure compression the tension cone is not demanded but pryout still is.

For cast-in anchors, Ncp=Ncb or Ncpg=Ncbg calculated by17.6.2.1 for the shear-active group. Reuse the pure cone geometry kernel with shear demands as positive weights only after deliberately selecting that group; retain the same physical concrete bounds and commonhef. Reapply the narrow-member tension rule for THIS group; do not borrow hcalc or eccentricity from the tension-active case. Basic24sqrt(fc)h^1.5 is the chosen existing policy, with no optional deep-embedment gain.

kcp=1 if physicalhef<2.5in;2 if physicalhef>=2.5in. Keep physicalhef and fictitioushef separate. kcp's embedment threshold is a physical anchor-embedment classification; the reducedhef is used in Ncp's tension-breakout calculation. Do not double phi: Vcp=kcp*Ncp; phiVcp=0.70*Vcp, including groups. Supplementary reinforcement cannot raise this pullout/pryout phi to0.75.

Check each disconnected shear-active component's actual demand separately. In the qualified equal-four model, use all four shear-active rods with equal weights and totalV; this is distinct from a near-pair-only physical transfer detail. If specific source row redistribution states are used as actual alternative force paths, their steel and pryout capacities must be checked consistently; a concrete breakout mechanism is not permission to leave an alternative path unchecked.

Sources: DG1p37 and Example4.7-7 pp.101–102; [Hilti p211](https://viewer.joomag.com/profis-design-guide-ac-318-19-july-2022/0546853001659024142/p211) explains shear-active geometry/eccentricity, [p214](https://viewer.joomag.com/profis-design-guide-ac-318-19-july-2022/0546853001659024142/p214) reproduces17.7.3, and [p237](https://viewer.joomag.com/profis-design-guide-ac-318-19-july-2022/0546853001659024142/p237) gives Table17.5.3(c).

## 6. ACI steel checks required for ACI interaction

DG1p37 specifically says keep the AISC steel and ACI anchorage checks separate because their interaction models differ. The same separation is needed here for NBR steel. Do not populate ACI interaction denominators with NBR `Ft_Rd` or the NBR alpha-reduced group shear resistance.

futa_eff=min(futa,1.9fya,125000psi).
Nsa=Ase,N*futa_eff.
Vsa=0.6*Ase,V*futa_eff.
If built-up grout pad is present, multiply Vsa by0.80.

Apply phi_N,steel=0.75 and phi_V,steel=0.65 only to a documented ACI-ductile steel element. If ductility is unverified, either pending or deliberately use the brittle factors0.65/0.60; do not silently grant ductile credit. DG1 confirms ductility for ASTM F1554, which does not automatically certify the existing A36 rod. Official-primary corroboration of brittle factors: ICC-ES/Hilti [ESR3814 Table26](https://www.hilti.com/media-canonical/ASSET_DOC_LOC_5506285_APC_RAW), and Hilti [ER678 shear table note2](https://www.hilti.com/media-canonical/ASSET_DOC_LOC_13309779_APC_RAW). These support the factor values, not an A36 material classification.

For standard UNC rod, DG1Eq4-21 gives Ase,N=pi/4*(da−0.9743/n)^2 with da in inches and n threads/inch. Use the documented governing section for Ase,V; threads crossing shear need their effective section. Do not use nominal Ab solely because the NBR rod check does. Metric or other threads require the correct standard or documented areas. Require appropriate matched nuts/head engagement; numerical area does not establish thread stripping strength.

Compare Ti/phiNsa for each rod. Compare its qualified actual qi/phiVsa for each rod. Retain individual NBR simultaneous conditional-shear checks using the SAME qi when a physical sharing model is selected; aggregate NBR capacity alone can hide a rod overloaded by the adopted sharing. Existing NBR checks, their factors and washer design actions remain unchanged.

## 7. Interaction, ACI17.8: ratios, not mixed raw forces

For the SAME combination and force-transfer model:

beta_N=max of applicable individual ACI steel tension ratios, individual pullout ratios, tension-breakout group/component ratios, and side-face group/singleton ratios.
beta_V=max of applicable individual ACI steel shear ratios, concrete shear-breakout mechanism/component ratios, and pryout group/component ratios.

This correctly compares each demand with its corresponding individual/group capacity. It does not divide total tension by a single rod capacity or combine minimum capacities with unrelated numerators. DG1Example4.7-7 p102 explicitly combines the governing group-tension ratio with the governing individual-steel-shear ratio.

All individual/group checks must first satisfy beta_N<=1 and beta_V<=1. If either is<=0.2, additional interaction may be neglected. Otherwise require beta_N+beta_V<=1.2. A convenient reported utilization is max(beta_N,beta_V,(beta_N+beta_V)/1.2 when both>0.2). Preserve raw ratios and the branch decision; don't round before testing0.2 or1.0.

If ANY applicable capacity or required force allocation is unknown/unsupported, interaction status is PENDING, never pass. A concrete-only interaction screen may be displayed if clearly labelled partial; it must not replace the ACI steel-included result. The confirmed zero-anchor-shear path (e.g. a fully verified alternate shear transfer) has beta_V=0; merely selecting friction/key is insufficient to waive an unverified load path.

Source: [Hilti p353](https://viewer.joomag.com/profis-design-guide-ac-318-19-july-2022/0546853001659024142/p353), reproducing17.8.1–.3 and explaining governing ratios; DG1pp.37,101–102.

## 8. Result semantics, fixtures and release gates

Every result includes source/method version, simultaneous combination ID, actual versus assumed qi, sharing qualification reference, selected source cases, real/virtual edge orientation, physical/calculation ca1, physical/conehef, row/component IDs, projected area, Vb branches, modifiers, phi, demand and utilization. Persist these distinctions through JSON, drawing and Word.

No friction+anchor+key sum. No head area inferred from upper washer. No reinforcement credit inferred from visible reinforcing bars. No hidden unit changes. Missing geometry or qualification produces pending, not zero capacity or green. V=0 marks shear/pryout not demanded, not all anchorage complete.

Independent arithmetic fixtures are in `shear_benchmarks.json` and generated by `make_benchmarks.py` without importing app code. Cover DG1Example4.7-4, small-diameter Vb1 branch, corner and thin-member modifiers, narrow correction, parallel-edge factor, eccentric row, Case1/2 versus3 transition, disconnected projections, physical versus fictitious embedment, steel grout factor, all interaction branches and a fail.

Before full release: independent engineer review must settle the parallel-row/actual-sharing interpretation and verify controlling ACI text/errata under legitimate complete access. The equations above are adequate for a useful bounded native component implementation, but not an excuse to claim the currently unverified whole fixed/pinned base complete.
