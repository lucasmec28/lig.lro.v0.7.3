# Fixed and pinned baseplate completion: actual-code gap matrix

Reviewed 2026-10-09 against frozen `connections_work085/source`; this file does not change application code. The sibling family task owns fixed/pinned geometry and integration. The frozen Type 1 equilibrium cannot be renamed a pinned model; rotational classification is not calculated.

| Physical path / mode | 0.8.5 actual status | Next completion dependency |
|---|---|---|
| Type 1 external four-anchor plate bending, N–M equilibrium and concrete/grout contact | Implemented in `lro/base_plate.py`, corrected NBR8800:2024/Er1:2025, centered I/H, unstiffened, uniaxial | Preserve domain and independent fixtures; family-specific pinned formulation is separate |
| Rod-steel tension and native special-washer shear | Implemented, simultaneous individual tensions; conservative interpretation of NBR ambiguous index; aggregate conditional shear resistance | Concrete shear needs an explicit physically justified shear distribution; aggregate resistance is not a force allocation |
| Upper washer perimeter weld metal and hole bearing/tear-out | Implemented opt-in local checks in `lro/upper_washer.py` | Washer/baseplate coupled deformation and complete metal-base transfer remain open |
| Concrete tension breakout | Implemented opt-in `lro/concrete_anchorage.py`, actual free edges and loaded groups, ACI complementary basis | Retain physical vs computational embedment and splitting/detail gates |
| Head/nut concrete pullout | Not implemented | Add documented net bearing area, one-anchor demand; do not assume buried thin plate is rigid |
| Side-face blowout | Not implemented | Physical-depth screen plus verified single/corner and two-anchor edge-row group checks |
| Concrete shear edge breakout | Not implemented | Real block geometry, signed shear, engagement policy, nearest/farthest row cases, parallel edges, corner/thin-member modifiers |
| Concrete pryout | Not implemented | Shear-active group geometry, separate breakout evaluation from tension-active cone; verified physical kcp branch and phi |
| ACI tension/shear interaction | Not implemented | Every relevant ACI steel + concrete ratio must be known; retain separate NBR checks; cannot mix NBR rod capacities into ACI equation |
| Buried head/nut/plate structural transfer | Not implemented | Defined nut/head rating; plate bending/bearing/thread proof if plate area credited |
| Splitting/minimum edges, cover and reinforced block/member design | No complete native verification | Actual installation torque classification, detailing, NBR6118 foundation design; ordinary reinforcement gives no breakout credit |
| Column-to-base weld complete N–M–V path | Not implemented | Effective force path consistent with flexible plate and exterior rods, compression contact preparation, weld and both base metals |
| Single-plate shear key | Local contact, bending and shear implemented | Full key welds, local baseplate transfer, concrete breakout/edges and block reinforcement remain open |
| Other active shear-key shapes | Component scopes only | Do not claim complete concrete or attachment path |
| Stiffeners | Geometry/detail only | Resistance/distribution and weld paths need a distinct verified model |
| Hook J / adhesive / pockets / sleeves | Unsupported native complete path | J may be deferred; adhesive is product-specific; supplied C drawings include foam pockets outside intact-concrete scope |

## Practical order
1. Complete independent head/nut pullout and side-face modes, with honest unresolved head-plate mechanics gates.
2. Complete a bounded static 2×2 cast-in anchor shear/pryout/ACI interaction path with explicitly chosen shear engagement; this closes much more useful anchorage scope than more catalogue shapes.
3. Resolve complete column-base and washer/baseplate load paths and common stiffener variant; resolve shear key completely only when that alternative is selected.
4. Treat actual reinforced foundation/member design as a separate engineering deliverable, never implicitly passed by the connection calculator.
5. Simplify input UI only after canonical family geometry, reference surfaces, mutually exclusive shear paths and applicability gates are stable.

No number of green component checks makes these remaining paths complete. A user-facing overall connection pass must be conditional on every applicable supported mode and verified prerequisite, with unsupported and externally documented modes visible.
