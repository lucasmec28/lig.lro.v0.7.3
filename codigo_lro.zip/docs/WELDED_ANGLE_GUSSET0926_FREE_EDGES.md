# Finite rectangle free-edge branches: rear-top and forward-side exits

Date: 2026-10-11. **GO for this geometric extension of the already qualified NBR 8800:2024 6.5.6 block-shear calculation.** No new resistance equation, FEA requirement, or relaxation of the existing weld, local-introduction, full-width section-sign, or receiving-W checks is introduced. Application edits belong to the implementation owner.

## 1. Correct admissibility rule

A transverse tension segment may terminate on any actual free rectangle edge: left, right, or top. Its associated longitudinal shear segment may reach either the top or the forward side. The NBR formula depends on shear/tension areas, not the global name of the free edge. The original mandatory-left/right and mandatory-top gates described only one topology and unnecessarily excluded other ordinary physical blocks.

The fracture path plus the actual free boundary must enclose the assigned loaded weld portion without retaining a positive-length segment of the supported root. A single intersection at a root/free-side corner is allowed; it does not supply a connected root length. If every positive-demand candidate in an L family retains root attachment, that family is **inadmissible/inactive**, not a failure of the whole connection. Never fabricate an end at the infinite continuation of an edge, count the supported root as free, or assign load to a block after its last weld segment.

## 2. Coordinates and exact ray/chord intersections

Retain the established angle coordinates, physical heel/toe spacing, fillet footprints and balanced load split. Let C=cos(theta), S=sin(theta), 0<theta<180 degrees, hence S>0. With actual weld-group center(cs,cn):

x(u,v)=cs+u C+v S; y(u,v)=cn+u S−v C.

The rectangle is -B/2≤x≤B/2, 0≤y≤H. The weld interval is a0=-L/2 to a1=L/2. Force fractions are heel0.71 atv=-50 and toe0.29 atv50. Actual 5mm fillet footprint bounds are -55,-50,50,55.

Forward shear-ray exit at fixed v:

u_top=(H−cn+v C)/S.

If C>0, u_side=(B/2−cs−v S)/C. If C<0, u_side=(-B/2−cs−v S)/C. If C=0, there is no finite forward side intersection. Then u_exit(v)=min(u_top,u_side). The actual endpoint must lie on the bounded rectangle; the direction is positive u. This handles top, right, left and tied corner exits without dividing by zero at90 degrees.

At a fixed transverse cut u=a, calculate the rectangle chord in v. From the side edges:

v_x_low=(-B/2−cs−a C)/S; v_x_high=(B/2−cs−a C)/S.

For C>0, v_y_low=(cn+a S−H)/C and v_y_high=(cn+a S)/C. For C<0 those two roles reverse. For C=0, y=cn+a S must be inside[0,H] and supplies no v bound. The real chord is:

v_low=max(v_x_low,v_y_low); v_high=min(v_x_high,v_y_high).

Use the appropriate active bound to label the free edge. At90 degrees use only the side-derived bounds. A general positive-ray/rectangle intersection is equivalent and often simpler to test.

## 3. Areas, demand and finite station enumeration

U paths enclosing both welds or a single footprint retain their existing transverse footprint width. Their two shear legs each use the **actual** u_exit for its own v; they may terminate on different free edges. For bounds v1<v2 and rear cut a:

Agv=Anv=t[(u_exit(v1)−a)+(u_exit(v2)−a)], Ant=Agt=t(v2−v1).

For an L path whose longitudinal shear line is v_b:

Agv=Anv=t[u_exit(v_b)−a].

The negative-v family uses Ant=t[v_b−v_low(a)]; positive-v uses Ant=t[v_high(a)−v_b]. All segment lengths must be nonnegative and the points must be physically in the plate. The block is the rectangle clipped by u≥a and the selected half-plane v≤v_b or v≥v_b. Inspect its intersection with y=0: any positive root-contact length makes that candidate inadmissible. This geometric test applies equally to rear-top and mirrored rear-top branches.

Capture only the weld lines/footprints inside that block, with partial remaining demand:

D(a)=N sum(f_i) max(0,min(1,(a1−a)/L)).

For cuts through an active weld, omit the crossed weld-metal resistance conservatively as already done in the original corner-clipped paths. Do not invent an additional load or erase the finite angle-to-root eccentricity.

Enumerate a0,a1 and the u projection of every rectangle corner lying in[a0,a1]. This includes both lower supported/free corner transitions and upper side/top transitions. On each interval, the geometry branch is fixed; shear area, tension area and remaining demand are affine. Each NBR resistance branch is affine, so demand/resistance is monotone or constant. Endpoints suffice, with the minimum of the two resistance branches evaluated explicitly. There is no unbounded search. The existing conservative zero-tension tL gusset envelope also remains a check; it does not replace recording actual named path geometry.

R=min[0.60 fu Anv+0.5 fu Ant, 0.60 fy Agv+0.5 fu Ant]/1.35.

The initial steel is fy250,fu400 MPa, no holes, Cts0.5. Material independence is unchanged. A path family with no admissible positive-demand candidate must be reported as inactive with its geometric reason, not as zero capacity or a global outside-scope flag.

## 4. Exact numerical fixtures

Full coordinates, clipped block polygons, free-edge labels, finite station records, captured forces and both resistance branches are in RECTANGLE_FREE_EDGE_BRANCH_ORACLES.json.

### A. Compact45-degree100kN fixture

B500,H210,t10 mm; center(55,105) mm; angle L100×100×12; two150mm longitudinal welds;10mm angle end margin;5mm fillets at both interfaces; local introduction width140mm. Materials and W remain those of the complete qualified fixture. The140mm introduction width is important: a150mm rear corner would cross the root. Root N=V=70.710678 kN,M=-5.635533906 kNm. This moment follows the actual force line and is not imposed merely because the brace is inclined.

The existing full-width plate field is wholly tensile, apart from floating-point zero. The rear negative-v ray reaches the free top. Forward rays still reach the top.

At rear a=-75 mm:

- Heel L: Agv=Ant1734.924240492 mm², demand71kN, R449.795173461kN.
- Both-weld L: Agv=Ant2784.924240492 mm², demand100kN, R722.017395683kN.
- Both-weld U: Agv4469.848480983, Ant1100 mm², R659.612794183kN.

The positive-v root/free-side transition is a=63.639610307mm. It produces partial toe and both-weld demand2.196342007 and7.573593129kN; the JSON contains their actual areas. This fixture passes the newly admitted rupture branches without removing any existing strength check.

### B. Compact true-zero-root-moment45-degree45kN fixture

B600,H200,t10 mm; center_n80.5mm; center_s=(80.5cos45+21)/sin45=110.198484809835mm; two65mm longitudinal welds;20mm angle end margin; angle fillet5mm, root fillets6mm; introduction width150mm. N45kN is an explicit test load, not a silent replacement for a100kN request.

The actual force-line point is(95.349242405,95.349242405)mm. Root N=V31.819805153kN and M=0 within roundoff. The original balanced angle eccentricity is counted once. Root clearance is2.02155mm after the6mm fillet footprint; all endpoints and the local strip fit.

Existing section checks independently give minimum normal stress0, horizontal envelope15.225551MPa, local introduction maximum55.2MPa. Existing angle conservative block envelope utilization0.94405594 and heel-weld utilization0.75376665 pass. The local adapted Ct=.3326226013 and rupture utilization.56009423 also pass.

Rear a=-32.5mm:

- Heel L: Agv=Ant1514.985207036, demand31.95kN, R392.773942565kN; both endpoints are on the top.
- Both-weld L: forward exit is on the right, rear transverse exit is on the top; Agv2459.198769409, Ant2564.985207036, demand45kN, R653.242116162kN.
- Both-weld U: one forward leg exits top and one right; Agv3924.183976445, Ant1100, R598.983404790kN.

Both positive-v L families are inactive: their positive-demand clipped regions retain supported-root length. The lower-corner station occurs after the active weld end, so there is no detached positive-load right-L block. This is not a reason to reject the geometry; the U, rear-top L, local substrate and conservative path-envelope checks still apply.

### C. Opposite135-degree true-zero-root-moment branch

Keep fixtureB's dimensions/load but use theta135 degrees and center_s=(-80.5cos45+21)/sin45=-50.801515190165mm. The same angle orientation retains heel0.71 atv=-50; this is an opposite-angle example, not an assertion that the asymmetric71/29 section was physically mirrored without changing its orientation.

The rear positive-v L family now reaches the free top, and the negative-v L families are inactive from supported-root contact. Both-weld L has Agv=Ant2564.985207036, demand45kN, R664.996164787kN. Root moment is zero to roundoff. This checks the other sign of cos(theta) and avoids hard-coding the missing branch to only one side.

## 5. Actual free-edge weld termination

The existing NBR6.2.6.2.6(a) termination-distance check follows the actual forward exit edge, not always the top. At every outer footprint endpointu=L/2 require a conservative normal edge clearance at least the angle fillet leg: H−y_end for top, B/2−x_end for right, x_end+B/2 for left. A tied corner checks both active free-edge clearances. Along-ray length alone at leasts is weaker when the edge is oblique, so it is not the adopted screen. This refines the existing termination-detail row rather than adding another limit state. Root interference and physical containment remain separate. All three saved fixtures satisfy this generalized detailing check.

## 6. Guardrails and negative tests

1. Compare every new geometry with the same true root-action formula. Mroot0 does not imply M(y)=0 in internal plate sections when Vroot is nonzero.
2. Preserve the existing full-width section-sign gate separately. A compact45-degree100kN Mroot0 candidate can have compressed regions in that chosen section idealization; qualifying these fracture paths alone does not prove a whole-route pass or prove that the physical plate fails. Report that as a model-domain result.
3. Require all path endpoints inside/on the rectangle and all purported free endpoints on an actual free segment. A ray landing on root remains inadmissible until the finite corner transition; do not re-label it as top/side.
4. Each saved positive path has a same-geometry concurrent-load scaling regression producing utilization1.01. Other checks may fail earlier; these are named-path arithmetic oracles.
5. At90 degrees the equations use their finite side/top limits. At a tied corner, do not create a negative area, duplicate demand, or an unsupported free-root assumption.
6. An inactive family is neither a zero-resistance failure nor a claimed passing physical path. Record why it encloses no detached positive-load block.

**Terminal result: rear-top, mirrored rear-top, forward-side U/L exits, and inactive root-connected L families are finitely qualified. Existing code-equation sources suffice; no further literature pass is needed.**
