# Reprodução independente da ligação de canto

Os arquivos listados em `PACKAGE_MANIFEST.json` foram copiados sem alteração da revisão numérica independente. Seus hashes originais são preservados, incluindo o construtor de expectativas e o registro prévio ao uso do motor. Nenhum desses arquivos é usado pelo motor de produção para calcular resistência.

A reprodução exata tem um contrato de ambiente separado do aplicativo: NumPy **2.5.3**, conforme `requirements_replay.txt`, além dos requisitos do aplicativo. O aplicativo não passa a exigir essa versão; seus requisitos e os 134 arquivos de execução aceitos permanecem inalterados. Use um ambiente de auditoria separado que satisfaça os dois arquivos de requisitos. A execução validada usou Python 3.12.14 e NumPy 2.5.3.

NumPy 2.3.5 pode produzir diferenças da ordem de 1e-12 nos candidatos de extremos polinomiais, sem reproduzir os mesmos bytes JSON. Por isso, o adaptador encerra com código 2 e `REPLAY_PREREQUISITE_NOT_MET` antes de gerar arquivos se a versão não for 2.5.3. Não há instalação, atualização automática, regeneração do oráculo congelado ou relaxamento de sua igualdade exata.

No ambiente de auditoria correto, a partir da raiz do aplicativo:

```sh
python -B docs/independent_engine0932/replay.py --output-dir replay_corner0932
```

O adaptador copia os scripts originais e apenas `lro`/`data` para um diretório temporário com a disposição original. Reproduz as expectativas independentes, exige a igualdade exata de seu hash e compara o motor aceito. Os registros de saída são escritos na pasta indicada; as evidências congeladas não são modificadas. O hash exigido de `EXPECTED_PARAMETERIZED.json` permanece `04364b63ac8a80452dae819e8cde03eba8ef8434b7b19d5c890b180192230c3e`. Mesmo com a versão exigida, uma divergência desse hash continua bloqueando a reprodução e requer exame do ambiente; não é aceita por tolerância.

`PACKAGED_REPLAY_RECEIPT.json` registra a execução inicial deste adaptador, no ambiente já disponível com NumPy 2.5.3: 54 comparações de fórmulas, 1.356 comparações numéricas, 112 comparações de caminhos, 323 observações adversariais e 76 rejeições de esquema. A emenda de contrato e seus novos testes ficam em `REPLAY_CONTRACT_AMENDMENT.json`. Esses números não são somados ao total de testes pytest, e a suíte de 1.083 testes não foi reexecutada por uma alteração apenas documental/de auditoria.

`ENGINE_ACCEPTANCE.json` é o recibo original de GO numérico limitado. `ENGINE_RUNTIME_HASHES.json` vincula o motor e suas dependências. Os registros preservam o contexto e os caminhos da execução original; o manifesto e este adaptador fornecem a localização transportável.

Os dois grandes snapshots completos das rotas legadas são material suplementar do arquivo opcional AUDITORIA. Seus hashes constam de `LEGACY_PARITY.json`. Eles não são necessários para executar o aplicativo nem esta reprodução. O dump integral `RUNTIME_OUTPUTS.json` também é reproduzido temporariamente e não precisa ser distribuído.

Esta revisão não aprova estabilidade global, execução de soldagem, fabricação ou inspeção. A revisão independente de interface, figuras e relatórios é um gate separado.
