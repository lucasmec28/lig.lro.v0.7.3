"""Replay original independent numerical scripts without modifying frozen evidence.
Run in the separate audit environment documented by requirements_replay.txt.
The exact independent expectation bytes require NumPy 2.5.3. Optional
--output-dir writes the new replay receipts there, never over acceptance inputs.
"""
from pathlib import Path
import argparse,hashlib,json,shutil,subprocess,sys,tempfile
HERE=Path(__file__).resolve().parent;SOURCE=HERE.parents[1]
p=argparse.ArgumentParser();p.add_argument('--output-dir',type=Path);args=p.parse_args()
REQUIRED_NUMPY='2.5.3'
try:
 import numpy as np
 actual_numpy=np.__version__
except ImportError:
 actual_numpy=None
if actual_numpy!=REQUIRED_NUMPY:
 prerequisite=dict(status='REPLAY_PREREQUISITE_NOT_MET',required_numpy=REQUIRED_NUMPY,
                   actual_numpy=actual_numpy,requirements='docs/independent_engine0932/requirements_replay.txt',
                   message='Use a separate audit environment with NumPy 2.5.3. Application dependencies are unchanged. No expected files were regenerated.')
 print(json.dumps(prerequisite,indent=2),file=sys.stderr)
 raise SystemExit(2)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((HERE/'PACKAGE_MANIFEST.json').read_text())
assert all(sha(HERE/n)==h for n,h in manifest['copied_originals'].items()),'Evidence hash mismatch'
accepted=json.loads((HERE/'ENGINE_RUNTIME_HASHES.json').read_text())
assert all(sha(SOURCE/n)==h for n,h in accepted.items()),'Accepted engine/dependency hash mismatch'
with tempfile.TemporaryDirectory(prefix='corner0932_replay_') as folder:
 root=Path(folder);work=root/'independent_engine_acceptance';shutil.copytree(HERE,work)
 target=root/'source0932';target.mkdir()
 for name in ['lro','data']:shutil.copytree(SOURCE/name,target/name,ignore=shutil.ignore_patterns('__pycache__','.pytest_cache'))
 for script in ['build_expected.py','check_expected_source.py','review_runtime.py','check_tear_paths.py','adversarial_hardening.py']:
  with (work/(script+'.log')).open('w') as log:subprocess.run([sys.executable,'-B',str(work/script)],check=True,stdout=log,stderr=subprocess.STDOUT)
  if script=='build_expected.py':assert sha(work/'EXPECTED_PARAMETERIZED.json')==manifest['copied_originals']['EXPECTED_PARAMETERIZED.json'],'Exact independent expectation hash mismatch despite the required NumPy version; preserve the frozen oracle and inspect the audit environment. No numerical tolerance replaces this hash gate.'
 numerical=json.loads((work/'RUNTIME_COMPARISON.json').read_text());tear=json.loads((work/'TEAR_PATH_REVIEW.json').read_text());adversarial=json.loads((work/'ADVERSARIAL_HARDENING.json').read_text());reproduction=json.loads((work/'INDEPENDENT_SOURCE_REPRODUCTION.json').read_text())
 assert not numerical['failures'] and numerical['source_stable']
 assert not tear['failures'] and not adversarial['failures'] and reproduction['passed']
 receipt=dict(passed=True,version='0.9.32-corner-gusset-dev',audit_environment=dict(numpy=actual_numpy,python=sys.version.split()[0],requirements='docs/independent_engine0932/requirements_replay.txt'),exact_expected_sha256=sha(work/'EXPECTED_PARAMETERIZED.json'),engine_sha256=sha(SOURCE/'lro/corner_gusset.py'),independent_formula_comparisons=reproduction['numerical_comparisons'],runtime_numeric_comparisons=numerical['comparisons'],tear_comparisons=tear['golden_comparisons'],adversarial_checks=adversarial['checks'],schema_rejections=adversarial['schema_rejections'],original_evidence_unchanged=True,global_approval=False)
 if args.output_dir:
  args.output_dir.mkdir(parents=True,exist_ok=True)
  for name in ['RUNTIME_COMPARISON.json','TEAR_PATH_REVIEW.json','ADVERSARIAL_HARDENING.json','INDEPENDENT_SOURCE_REPRODUCTION.json']:shutil.copyfile(work/name,args.output_dir/name)
  (args.output_dir/'REPLAY_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps(receipt,indent=2))
