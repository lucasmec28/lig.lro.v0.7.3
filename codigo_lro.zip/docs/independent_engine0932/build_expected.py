"""Independent parameterized mechanics oracle. No application imports or runtime values.
Sources: visually checked DG29 Appendix A A11-A16; supplied NBR8800:2024,
full-joint frozen contract sec9. Geometry and changed-case inputs transcribed here.
This script intentionally does NOT import the producer fixture or its outputs.
"""
from pathlib import Path
from copy import deepcopy
import json,math,hashlib
from numpy.polynomial import Polynomial as Poly
ROOT=Path(__file__).resolve().parent
S=math.sqrt
BASE=dict(P=100000.,phi=45.,beam=dict(d=317.,bf=167.,tf=13.2,tw=7.6,Ag=6700.,Wx=751400.),column=dict(d=308.,bf=305.,tf=15.4,tw=9.9,Ag=12360.,Wx=1447000.),angle=dict(b=76.2,t=7.94,Ag=1148.,ec=22.1),fy=dict(angle=250.,gusset=250.,beam=345.,column=345.,continuity=250.),fu=dict(angle=400.,gusset=400.,beam=450.,column=450.,continuity=400.),fw=485.,E=200000.,g1=1.1,g2=1.35,gw=1.35,gusset_w=600.,gusset_h=600.,gusset_clip=30.,gusset_t=12.,root_leg=6.,seam_gap=10.,u0=650.,u1=870.,brace_free_u=630.,brace_leg=5.,cp_width=140.,cp_clip=30.,cp_t=12.,cp_leg=6.,cp_weld_gap=5.,joint_web_leg=5.,joint_web_y=[-110.,110.],beam_cut=dict(point=[1000.,0.],Fx=-30710.67811865475,Fy=-50000.,M=62300000.),upper_cut=dict(point=[0.,1000.],Fx=10000.,Fy=-500000.,M=10000000.),lower_point=[0.,-1000.])

def cross(p,f):return p[0]*f[1]-p[1]*f[0]
def moment(a,at=(0.,0.)):return a['M']+cross([a['point'][i]-at[i] for i in range(2)],[a['Fx'],a['Fy']])
def roots_on(p,lo,hi):
 return [float(x.real) for x in p.roots() if abs(x.imag)<1e-8 and lo<float(x.real)<hi]
def extreme_poly(p,lo=-1.,hi=1.):return [(x,float(p(x))) for x in [lo,hi]+roots_on(p.deriv(),lo,hi)]
def chord(poly,u):
 vs=[]
 for a,b in zip(poly,poly[1:]+poly[:1]):
  if abs(a[0]-u)<1e-7:vs.append(a[1])
  if min(a[0],b[0])<u<max(a[0],b[0]):vs.append(a[1]+(u-a[0])*(b[1]-a[1])/(b[0]-a[0]))
 if len(vs)<2:return None
 return min(vs),max(vs)
def body_envelope(poly,u0,u1,P,t):
 """Enumerate polygon vertices, zero centroid, rational stationary points.
 Only valid if every physical support point is behind u0.
 """
 stations=sorted(set([u0,u1]+[a[0] for a in poly if u0<a[0]<u1]))
 results=[]
 for lo,hi in zip(stations,stations[1:]):
  eps=(hi-lo)*1e-4
  vl1,vh1=chord(poly,lo+eps);vl2,vh2=chord(poly,hi-eps)
  def affine(a,b):
   slope=(b-a)/(hi-lo-2*eps);return Poly([a-slope*(lo+eps),slope])
  bot,top=affine(vl1,vl2),affine(vh1,vh2);width=top-bot;center=(top+bot)/2;force=P/(u1-u0)*Poly([u1,-1.])
  for sign in (-1,1):
   numer=force*(width+6*sign*center);den=t*width*width
   deriv=numer.deriv()*den-numer*den.deriv()
   candidates=[lo,hi]+roots_on(center,lo,hi)+roots_on(deriv,lo,hi)
   for u in candidates:
    if sign*float(center(u)) < -1e-7:continue
    if float(width(u))<=0:continue
    results.append(dict(u=u,width=float(width(u)),center_v=float(center(u)),force=float(force(u)),peak_MPa=float(numer(u)/den(u))))
 return max(results,key=lambda x:x['peak_MPa']),results

def integrated_body(poly,u0,u1,P,t,brace_lines,root_segments):
 """Independent section free-body: captured brace plus negative root tractions.
 Every section is evaluated against actual polygon chord. The load tail includes
 support traction past that section, even when a support remains attached.
 """
 breaks=sorted(set([u0,u1]+[a[0] for a in poly if u0<a[0]<u1]+[a[0] for seg in root_segments for a in seg['points'] if u0<a[0]<u1]))
 def forces(u):
  vlow,vhigh=chord(poly,u);vc=(vlow+vhigh)/2
  fx=fy=moment=0.
  for v,part in brace_lines:
   start=max(u,u0)
   if start<u1:
    force=P*part*(u1-start)/(u1-u0)
    fx+=force;moment-=(v-vc)*force
  for segment in root_segments:
   a,b=segment['points'];q=segment['force']
   if a[0]>b[0]:a,b=b,a
   if u>=b[0]:continue
   frac=1. if u<=a[0] else (b[0]-u)/(b[0]-a[0])
   start=a if u<=a[0] else [u,a[1]+(u-a[0])*(b[1]-a[1])/(b[0]-a[0])]
   mean=[(start[j]+b[j])/2 for j in range(2)]
   ff=[v*frac for v in q];fx+=ff[0];fy+=ff[1];moment+=(mean[0]-u)*ff[1]-(mean[1]-vc)*ff[0]
  return fx,fy,moment,vhigh-vlow,vc
 candidates=[]
 for lo,hi in zip(breaks,breaks[1:]):
  # Each subinterval has affine width/N/V and quadratic moment. Use local
  # dimensionless coordinate for robust polynomial reconstruction.
  mid=(lo+hi)/2;half=(hi-lo)/2
  zz=[-.75,0.,.75];values=[forces(mid+half*z) for z in zz]
  N=Poly.fit(zz,[v[0] for v in values],1).convert();V=Poly.fit(zz,[v[1] for v in values],1).convert();M=Poly.fit(zz,[v[2] for v in values],2).convert();width=Poly.fit(zz,[v[3] for v in values],1).convert()
  denominator=t*width*width
  for sign in [-1,1]:
   num=N*width+sign*6*M
   shear_num=1.5*V*width
   vmnum=num*num+3*shear_num*shear_num
   vmden=denominator*denominator
   normalstation=roots_on(num.deriv()*denominator-num*denominator.deriv(),-1.,1.)
   vmstation=roots_on(vmnum.deriv()*vmden-vmnum*vmden.deriv(),-1.,1.)
   for z in [-1.,1.]+normalstation+vmstation:
    uu=mid+half*z;ff=forces(uu)
    candidates.append(dict(u=uu,N=ff[0],V=ff[1],M=ff[2],width=ff[3],center_v=ff[4],edge=sign,sigma=float(num(z)/denominator(z)),VM=math.sqrt(max(0.,float(vmnum(z)/vmden(z))))))
 return dict(stations=breaks,peak_VM=max(candidates,key=lambda a:a['VM']),max_sigma=max(a['sigma'] for a in candidates),min_sigma=min(a['sigma'] for a in candidates),candidates=candidates)

def evaluate(c):
 b,k=c['beam'],c['column'];ec=k['d']/2;eb=b['d']/2;phi=math.radians(c['phi']);co,si=math.cos(phi),math.sin(phi)
 H,V=c['P']*co,c['P']*si;clip=c['gusset_clip'];W,T=c['gusset_w'],c['gusset_h'];gap=c['seam_gap']
 polygon=[[ec+clip,eb],[ec+W,eb],[ec+W,eb+T],[ec,eb+T],[ec,eb+clip]]
 bu=[ec+clip+gap,ec+W-gap];cu=[eb+clip+gap,eb+T-gap]
 lb,lc=bu[1]-bu[0],cu[1]-cu[0];alpha=sum(bu)/2-ec;beta=sum(cu)/2-eb
 Hc=ec*V/(eb+beta);Hb=H-Hc;Vb=eb*Hb/alpha;Vc=V-Vb
 # Complete beam actions refer to their stated point. The brace seam has its own lever arm.
 bd=c['beam_cut'];up=c['upper_cut'];J=[ec,0.];B=[sum(bu)/2,eb];C=[ec,sum(cu)/2]
 joint=dict(Fx=bd['Fx']+Hb,Fy=bd['Fy']+Vb,M=moment(bd,J)+cross([B[0]-ec,B[1]],[Hb,Vb]))
 lower=dict(point=c['lower_point'],Fx=-bd['Fx']-up['Fx']-H,Fy=-bd['Fy']-up['Fy']-V)
 lower['M']=-moment(bd)-moment(up)-cross(lower['point'],[lower['Fx'],lower['Fy']])
 N,Q,M=joint['Fx'],joint['Fy'],joint['M'];Af=b['bf']*b['tf'];Aw=(b['d']-2*b['tf'])*b['tw'];A=2*Af+Aw;h=b['d']-b['tf'];Ft=N*Af/A-M/h;Fb=N*Af/A+M/h;Nw=N*Aw/A
 Qtop=-(up['Fx']+Hc+Ft);Qbottom=Qtop-Nw
 # Upper-part column section force including all above distributed and concentrated tractions.
 def cut(y):
  fx,fy=up['Fx'],up['Fy'];mm=moment(up,(0.,y))
  for ylo,yhi,xforce,yforce in [(cu[0],cu[1],Hc,Vc),(*c['joint_web_y'],Nw,Q)]:
   start=max(y,ylo)
   if start<yhi:
    frac=(yhi-start)/(yhi-ylo);dx,dy=xforce*frac,yforce*frac
    fx+=dx;fy+=dy;mm+=ec*dy-((start+yhi)/2-y)*dx
  for level,force in [(h/2,Ft),(-h/2,Fb)]:
   if y<level:fx+=force;mm-=(level-y)*force
  return dict(y=y,Fx=-fx,Fy=-fy,M=-mm)
 ys=sorted(set([up['point'][1],lower['point'][1],*cu,*c['joint_web_y'],h/2,-h/2]))
 # On each interval moment is quadratic. Derivative = internal Fx plus axial-transfer lever slope.
 trials=[]
 for lo,hi in zip(ys,ys[1:]):
  for y in [lo+1e-8,hi-1e-8]:trials.append(cut(y))
  # Exact quadratic interpolation finds potential M stationary points without assuming Q alone.
  a,mid,z=lo+1e-6,(lo+hi)/2,hi-1e-6
  polyM=Poly.fit([a,mid,z],[cut(a)['M'],cut(mid)['M'],cut(z)['M']],2).convert()
  trials.extend(cut(y) for y in roots_on(polyM.deriv(),a,z))
 maxN=max(0.,max(r['Fy'] for r in trials));maxM=max(abs(r['M']) for r in trials)
 fy=c['fy'];fu=c['fu'];g1,g2=c['g1'],c['g2'];fycol=fy['column'];Npl=k['Ag']*fycol
 rho=1. if maxN<=.4*Npl else 1.4-maxN/Npl
 def shear(section,fy):
  lam=(section['d']-2*section['tf'])/section['tw'];lp=1.1*S(5*c['E']/fy);lr=1.37*S(5*c['E']/fy)
  reduction=1. if lam<=lp else lp/lam if lam<=lr else 1.24*(lp/lam)**2
  return dict(slenderness=lam,lambda_p=lp,lambda_r=lr,R=.6*fy*section['d']*section['tw']/g1*reduction)
 sv=shear(k,fycol);panelRd=sv['R']*rho
 # Weld root transfer, each receiver material retained.
 rw=lambda s:s/S(2)*.6*c['fw']/c['gw']
 roots={}
 for name,L,n,s,sec in [('beam',lb,Vb,Hb,b),('column',lc,Hc,Vc,k)]:
  normalRd=1.10*(L+(2.5 if name=='beam' else 5)*sec['tf'])*sec['tw']*fy[name]/g1
  roots[name]=dict(L=L,N=n,V=s,weld_ratio=1.25*math.hypot(n,s)/(2*L*rw(c['root_leg'])),yield_R=normalRd,yield_ratio=abs(n)/normalRd,flange_bending_exempt=(c['gusset_t']+2*c['root_leg'])<=.15*sec['bf'])
 # General continuity shape derives actual centroids rather than C1 constants.
 width=c['cp_width'];cl=c['cp_clip'];th=c['cp_t'];L=k['d']-2*k['tf']-2*cl-2*c['cp_weld_gap'];Lfl=width-cl-2*c['cp_weld_gap'];d=width/2;delta=(cl+c.get('cp_fl_start_margin',c['cp_weld_gap'])-c.get('cp_fl_end_margin',c['cp_weld_gap']))/2;e=d+delta;Lfl=width-cl-c.get('cp_fl_start_margin',c['cp_weld_gap'])-c.get('cp_fl_end_margin',c['cp_weld_gap'])
 rows={}
 for level,F in [('top',Ft),('bottom',Fb)]:
  p=F/2;np=p*Poly([.5,.5]);vp=p*(1.5*e/L)*Poly([1.,0.,-1.]);mp=p*Poly([delta/2,d/4+3*delta/4,0.,-e/4]);aa=width*th;zz=th*width**2/6
  extrema=[];vm=[]
  for sign in (-1,1):
   sigma=np/aa+sign*mp/zz;vms=sigma*sigma+3*(1.5*vp/aa)**2
   extrema+=extreme_poly(sigma);vm+=extreme_poly(vms)
  # Outside weld before clip: unchanged full section. Inside clip b(x) affine,
  # centroid shifts by (b-width)/2; resultants N=p,V=0,M=p*(zload-zbar).
  clipstations=[0.,cl]
  xx=Poly([0.,1.]);bw=width-xx;ecc=delta-xx/2
  for sign in (-1,1):
   num=p*(bw+sign*6*ecc);den=th*bw*bw
   for x in roots_on(num.deriv()*den-num*den.deriv(),0.,cl):clipstations.append(x)
   extrema += [(2.+x,float(num(x)/den(x))) for x in clipstations]
   vm += [(2.+x,float(num(x)/den(x))**2) for x in clipstations]
  fact=S(1+(6*e/L)**2);sz=6*abs(p)*e/L**2/(2*c['cp_leg']);tau=abs(F)/(L*k['tw'])
  concurrent=maxN/k['Ag']+maxM/k['Wx']+sz+S(3)*(tau+max(abs(Qtop),abs(Qbottom))/(k['d']*k['tw']))
  rows[level]=dict(F=F,Fplate=p,Npoly=list(np.coef),Vpoly=list(vp.coef),Mpoly=list(mp.coef),sigma_min=min(v for _,v in extrema),sigma_max=max(v for _,v in extrema),max_VM=S(max(v for _,v in vm)),VM_ratio=S(max(v for _,v in vm))/(fy['continuity']/g1),web_weld_factor=fact,web_weld_ratio=abs(F)/(4*L*rw(c['cp_leg']))*fact,flange_weld_ratio=abs(F)/(4*Lfl*rw(c['cp_leg'])),receiver_sigma_z=sz,receiver_tau=tau,receiver_VM=S(sz*sz+3*tau*tau),receiver_VM_ratio=S(sz*sz+3*tau*tau)/(fycol/g1),concurrent_triangle=concurrent,concurrent_ratio=concurrent/(fycol/g1))
 # Polygon coordinates in brace axes; u normal to each physical body section.
 polyuv=[[x*co+y*si,-x*si+y*co] for x,y in polygon]
 supportU=max(polyuv[i][0] for i in [0,1,3,4]);body,body_candidates=body_envelope(polyuv,c['u0'],c['u1'],c['P'],c['gusset_t'])
 angle=c['angle'];vl=-angle['ec'];vh=angle['b']-angle['ec'];wl=c['u1']-c['u0'];spread=wl*math.tan(math.pi/6);vleft=vl-spread;vright=vh+spread;bw=vright-vleft;vcen=(vright+vleft)/2;ch=chord(polyuv,c['u0']);whitmore_contained=bool(ch and ch[0]<=vleft and vright<=ch[1])
 p_each=c['P']/2;heel_fraction=(angle['b']-angle['ec'])/angle['b'];Ct=max(.5,1-angle['ec']/wl)
 to_uv=lambda xy:[xy[0]*co+xy[1]*si,-xy[0]*si+xy[1]*co]
 rootsegments=[dict(points=[to_uv([xx,eb]) for xx in bu],force=to_uv([-Hb,-Vb])),dict(points=[to_uv([ec,yy]) for yy in cu],force=to_uv([-Hc,-Vc]))]
 integrated=integrated_body(polyuv,c['u0'],c['u1'],c['P'],c['gusset_t'],[(vl,heel_fraction),(vh,1-heel_fraction)],rootsegments)
 brace=dict(Ct=Ct,gross_R=angle['Ag']*fy['angle']/g1,effective_R=Ct*angle['Ag']*fu['angle']/g2,heel_fraction=heel_fraction,heel_weld_ratio=p_each*heel_fraction/(wl*rw(c['brace_leg'])),nominal_block_R=.6*min(fy['angle'],fu['angle'])*angle['t']*wl/g2)
 overlap=max(cu[0]-2.5*k['tf'],h/2+c['cp_t']/2+c['cp_leg'])-min(cu[0]-2.5*k['tf'],h/2+c['cp_t']/2+c['cp_leg'])
 # Actual connected union includes CP double fillet outermost bounds and full gusset seam.
 unionlo=min(h/2-th/2-c['cp_leg'],cu[0]);unionhi=max(h/2+th/2+c['cp_leg'],cu[1]);unionRd=1.10*(unionhi-unionlo+5*k['tf'])*k['tw']*fycol/g1
 flangeunionlo=min(h/2-b['tf']/2,cu[0]);flangeunionhi=max(h/2+b['tf']/2,cu[1]);flangeunionRd=1.10*(flangeunionhi-flangeunionlo+5*k['tf'])*k['tw']*fycol/g1
 return dict(flange_union=dict(span=flangeunionhi-flangeunionlo,R=flangeunionRd,demand=abs(Ft)+abs(Hc),ratio=(abs(Ft)+abs(Hc))/flangeunionRd),input=c,geometry=dict(ec=ec,eb=eb,alpha=alpha,beta=beta,polygon=polygon,brace_axes_polygon=polyuv,support_u_max=supportU,body_detached_valid=c['u0']>supportU,whitmore_contained=whitmore_contained,body_at_u0=ch,body_peak=body,integrated_body=integrated,body_candidates=body_candidates,whitmore_width=bw,whitmore_centroid=vcen,whitmore_peak=(c['P']/(c['gusset_t']*bw))*(1+6*abs(vcen)/bw)),forces=dict(H=H,V=V,Hb=Hb,Vb=Vb,Hc=Hc,Vc=Vc),joint=joint,lower_cut=lower,beam_components=dict(A0=A,Af=Af,Aw=Aw,Nweb=Nw,Ftop=Ft,Fbottom=Fb,h0=h),column_extrema=dict(max_compression=maxN,max_abs_M=maxM),panel=dict(Qtop=Qtop,Qbottom=Qbottom,Npl=Npl,axial_reduction=rho,R=panelRd,ratio=max(abs(Qtop),abs(Qbottom))/panelRd),root=roots,brace=brace,continuity=dict(L=L,flange_L=Lfl,width=width,clip=cl,e=e,d=d,delta=delta,rows=rows),union=dict(basis='actual continuity web fillet envelope union',span=unionhi-unionlo,R=unionRd,demand=abs(Ft)+abs(Hc),ratio=(abs(Ft)+abs(Hc))/unionRd))

cases={}
def add(name,edits=None):
 c=deepcopy(BASE)
 for path,v in (edits or {}).items():
  p=c;ss=path.split('.')
  for s in ss[:-1]:p=p[s]
  p[ss[-1]]=v
 cases[name]=evaluate(c)
add('C1')
for angle in [40.,50.,80.]:add(f'phi{int(angle)}_unchanged',dict(phi=angle))
for angle in [40.,50.]:add(f'phi{int(angle)}_detached',dict(phi=angle,u0=700.,u1=920.,brace_free_u=680.))
add('continuity_width130_clip20',dict(cp_width=130.,cp_clip=20.))
add('continuity_width120_clip30',dict(cp_width=120.))
add('continuity_weld_gap10',dict(cp_weld_gap=10.))
add('continuity_asymmetric_flange_margins',dict(cp_fl_start_margin=15.,cp_fl_end_margin=5.))
add('angle_catalog_R34',{'angle.b':88.9,'angle.t':7.94,'angle.Ag':1350.,'angle.ec':25.2})
add('column_material250',{'fy.column':250.,'fu.column':400.})
add('upper_column_high_axial',{'upper_cut.Fy':-.8*12360.*345.})
add('beam_cut_relocated',{'beam_cut.point':[1300.,40.],'beam_cut.M':62300000.-300.*(-50000.)+40.*(-30710.67811865475)})
add('upper_cut_relocated',{'upper_cut.point':[20.,1200.],'upper_cut.M':10000000.-20.*(-500000.)+200.*10000.})
add('beam_catalog_W310x44_5',{'beam.d':313.,'beam.bf':166.,'beam.tf':11.2,'beam.tw':6.6,'beam.Ag':5720.,'beam.Wx':(6.6*(313-2*11.2)**3/12+2*(166*11.2**3/12+166*11.2*((313-11.2)/2)**2))*2/313})
add('column_catalog_W310x107',{'column.d':311.,'column.bf':306.,'column.tf':17.,'column.tw':10.9,'column.Ag':13640.,'column.Wx':(10.9*(311-2*17)**3/12+2*(306*17**3/12+306*17*((311-17)/2)**2))*2/311})
add('asymmetric_seam_lengths',dict(gusset_w=650.,gusset_h=580.,u0=700.,u1=920.,brace_free_u=680.))
record=dict(derivation='Independent mechanics and source-transcribed formulas; no production functions, fixture builders or runtime outputs imported. Changed-section Wx uses independent sharp rectangle integration, leaving rolled roots uncredited. This is a conservative derivation, not a published modulus.',cases=cases)
output=ROOT/'EXPECTED_PARAMETERIZED.json';output.write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:{'Hb':v['forces']['Hb'],'body_MPa':v['geometry']['body_peak']['peak_MPa'],'detached':v['geometry']['body_detached_valid'],'cp_e':v['continuity']['e'],'cp_VM':v['continuity']['rows']['bottom']['max_VM'],'panel':v['panel']['ratio']} for k,v in cases.items()},indent=2))
