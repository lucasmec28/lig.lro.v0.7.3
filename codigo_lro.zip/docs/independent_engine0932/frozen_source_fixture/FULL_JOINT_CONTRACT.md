# Full numerical qualification: strong-axis beam–column corner gusset

11 October 2026. Independent numerical qualification only. No production code, release, upload or deployment changed.

## Decision

**GO to implement this bounded static-strength family against this full-joint acceptance fixture.** The same coherent, dimensioned commercial-profile joint passes the listed local components and signed equilibrium, including a genuinely compressed receiving region and continuity plates. This supersedes the earlier force-only illustrative fixture as the numerical acceptance basis; it does not change that earlier force-method derivation.

This is not a fabricated-joint certificate or a blanket pass for every angle, offset, profile or load case. Adjustable inputs must regenerate geometry and signed demands. Full brace compression, a nonzero work-point offset without its selected eccentric-force distribution, seismic/fatigue and nonplanar actions remain unqualified increments. Global brace/beam/column member stability and execution/WPS inspection remain outside a local connection module. These exclusions do not conceal an unverified local component in C1.

Two derivations are provided: build_oracle.py and three separately authored crossreview scripts, with independently transcribed inputs and no production calculation imports. Main ORACLE.json has 86 passing local/detail/material rows; the independent gusset file adds eight physical tear paths and a proven conservative partial-path envelope. Rows are not additive capacities and their count is not itself the acceptance criterion.

## 1. One actual geometry and independently selected materials

FIXTURE_INPUT.json is authoritative; FIXTURE.svg shows the web-plane arrangement. Coordinates x right, y up, z normal to both webs; CCW M positive. O=(0,0) is the deliberately selected beam/column centerline work point, not a fact inferred from the user's sketch.

Catalog facts:

- Beam Gerdau W310×52: d317,bf167,tf13.2,tw7.6,Ag6700mm².
- Column Gerdau W310×97(H): d308,bf305,tf15.4,tw9.9,Ag12360mm².
- Each of two Gerdau P03R30 equal angles: L76.2×76.2×7.94,Ag1148mm²,centroid22.1mm from heel exterior. Root/toe radii remain unknown.

All remaining dimensions and loads are declared example assumptions. Gusset12mm, corner coordinates(154,158.5), outer square600×600, inner30×30clip. Polygon in order: (184,158.5),(754,158.5),(754,758.5),(154,758.5),(154,188.5). Actual effective beam seam x194…744 at y158.5 and column seam y198.5…748.5 at x154; both550mm. Thus alpha=beta315mm. Each has two6mm fillets, one each face. Effective starts are10mm beyond the clip, ends10mm before the outer edge. Physical contact edges remain supported beyond the effective weld ends; they are never labeled free tear edges.

Brace line is v=0 in coordinates u=(x+y)/sqrt2,v=(y−x)/sqrt2. P=100kN,phi45° from horizontal. Each angle is on one face z=±6 with identical same-direction toes. Four5mm longitudinal fillets have u650…870, heel v−22.1,toe v54.1. Angle free end u630. Per-angle fractions heel0.7099737533/toe0.2900262467 put the load resultant at v0, exactly through O. Nominal inscribed5mm fillets are specified; no unpublished microscopic rolled contour is invented. The existing qualified Gerdau nominal through-leg model applies.

Beam flanges are matching CJP across full167×13.2mm; the design specifies complete throat, prepared single-bevel groove, backing/runoff removal and qualified WPS. This is not inferred from 'welded beam'. Beam web has two5mm fillets, y−110…110 at the column face. Actual25mm-radius web access holes fit within35.3mm from weld termination to each inner flange face; only the220mm effective web length is credited.

Two horizontal continuity plates at each y=±151.9: thickness12, depth277.2 between column flange interiors x±138.6, width140 on each web side z4.95…144.95 and mirrored. Four inner root clips30×30 per paired level leave net110mm per plate at each flange. Double6mm fillets:100mm effective at loaded/opposite flange per plate;207.2mm at web per plate. No fitted-contact strength is used. Opposite flange welds are present but have zero required transfer in the selected all-to-web static load path; their material/geometry is not counted as extra resistance.

Steel values are separate: angle/gusset/continuity fy250,fu400; beam/column fy345,fu450MPa; electrodes fw485;E200000;gamma_a1=1.10,gamma_a2=gamma_w2=1.35. These are chosen grade/design values, to be matched by actual material certification. Changing column steel must not change angle, gusset, beam or continuity properties.

## 2. Force field and complete-cut convention

Generalized DG29 AppendixA UFM with actual seam centroids:

Hc=ec V/(eb+beta); Hb=H−Hc; Vb=eb Hb/alpha; Vc=V−Vb.

C1 kN: H=V70.710678119; Hb47.712907411,Vb24.007923253,Hc22.997770708,Vc46.702754866. Brace-induced seam moments are zero for this chosen force field. Both support normal forces are tensile. Ordinary beta-fixed UFM would generally retain its seam moment; it is not interchangeable with these demands.

**Production input contract: COMPLETE_CUTS.** Enter signed concurrent actions on the isolated connection assembly at named beam and upper-column cuts, plus brace force/line, load-combination ID and any other actual loads between cuts. Derive the lower-column cut by equilibrium for this one-beam/one-brace topology; optionally compare it with the matching Robot lower cut. Do not ask for a redundant independent N0/V0/M0 set in this mode. Unknown existing loads must be supplied or explicitly excluded by topology/loading; absence of data is not zero.

C1 actual cuts, kN/kNm:

- Beam D=(1000,0): Fx−30.710678119,Fy−50,M+62.3.
- Upper column U=(0,1000): Fx+10,Fy−500,M+10.
- Derived lower column L=(0,−1000): Fx−50,Fy+479.289321881,M+37.7.
- No other connected members or distributed loads exist between these cuts in this example. Column physical ends lie beyond y±2000. Beam actually ends at the column face; its receiving calculation conservatively uses the member-end branch.

Recover interface beam→column at J=(154,0) from the isolated beam: TJ=beam_cut+gusset_on_beam, transporting moments to J. Result(+17.002229292,−25.992076747,+20). For independent comparison only, the incremental baseline at J is(+40,−50,+20), excluding brace path(−Hc,+Vb,0). Both calculations agree.

Adding the brace path again to the recovered complete interface gives an unbalanced beam residual(+Hc,−Vb,0) at J. The oracle records this nonzero double-counting witness. No panel or column demand is synthesized from P alone.

Gusset, beam, column and whole-assembly force residuals are below1e−7N and moment residuals below1e−7Nmm. The full column load from beam+gusset referred to O is(+40,+20.710678119,+12.3), not the interface moment20.

## 3. Gusset, brace and both support paths

Each angle carries50kN. Ct=1−22.1/220=0.899545455; gross resistance260.909kN, effective rupture305.979kN. Nominal through-leg block resistance194.089kN per angle discards all transverse-tension credit. Each heel weld carries35.498688kN, resistance167.663kN; its angle/gusset nominal local substrate utilization0.236658. Shared gusset resistance is counted once.

Whitmore at u650: v−149.117059…181.117059,b330.234118mm, wholly within actual polygon. Its centroid is v16, so the actual1.6kNm section moment is retained. Normal stresses17.898846…32.570399MPa; gross-yield utilization0.143310. No Ct=1 is inferred merely from absence of holes. The Whitmore fu row is explicitly a supplemental gross-stress rupture screen, not an invented NBR edge-weld rule.

Actual body fracture section at u650 is the full polygon chord b838.998013mm,centroidv3.181981. Peak normal stress10.158502MPa; gross/net rupture screen utilization0.034285. For650≤u≤870, captured force is P(870−u)/220 and chord b=2(1069.4990065−u), with constant centroidv3.181981. Differentiating the corresponding N/A+|M|/Z verifies its maximum at650. This is a physical entire-body section, not a virtual strip falsely called welded on its edges.

Independent crossreview/INDEPENDENT_GUSSET_REVIEW.json provides eight complete U/L paths, actual polygons and line coordinates, force captured by each path and both NBR6.5.6 branches with Cts0.5. Maximum named utilization0.086766. Every detached block reaches real upper/right free boundaries and no supported edge. Over the active weld interval all relevant lengths/demands are affine, so endpoint ratios close those path families. Discarding transverse resistance and free-end extensions gives the ordinary partial-path envelope Rt=0.6fy tg L/gamma_a2=293.333kN, utilization0.340909. This is a finite conservative envelope of the stated ordinary longitudinal/transverse families, not a claim to enumerate arbitrary curved microscopic fracture surfaces.

Both supported-edge sections retain their own normal/shear demand over A6600mm² and zero moment. DG29 supplemental N²+V⁴ interactions are0.000264068/0.000242317; the main oracle additionally uses the stronger N²+V²≤1 envelope and labels it correctly. Net tension/shear rupture and actual root contact planes are separate. A support edge is not relabeled a free tear-out edge.

Both root fillets use max(qpeak,1.25qaverage) from DG29 and nondirectional NBR weld resistance. Beam/column weld utilizations0.066369/0.064686. One common gusset contact depth min(tg,2s)=12mm is used; receiver material is separately checked. No AISC phi/Omega or directional weld bonus is imported.

## 4. Receiving members and complete welded N/V/M joint

Normal seam load footprints are24mm. They are below0.15bf=25.05mm beam/45.75mm column, establishing the actual NBR5.7.2 local-flange-bending exemptions. Normal web yielding still applies: receiving beam utilization0.015706, column0.010739. k=tf is deliberately a lower-bound strength input with no rolled-radius dispersion credit; it is not a catalog radius. Beam uses2.5k end branch, column5k interior branch.

Uniform normal tractions are integrated with concurrent baseline shear. Relevant beam endpoint magnitudes25.992/50kN; column above/below upper gusset10/32.998kN. NBR5.4.3 uses kv5 and deliberately enlarged clear height d−2tf; beam/column h/tw38.237/28 are below1.10sqrt(5E/fy)=59.222. Their compact web resistances453.368/573.804kN. No stiffener enhancement is needed. Longitudinal weld/base-metal transfer is checked separately from this cross-sectional web shear.

Joint distribution uses unrounded rectangle area A0=6617.36mm²,Af2204.4,Aw2208.56, and leaves catalog root area82.64mm² uncredited. All V goes to web; N is shared by these physical areas; all M is the flange couple. With CCW beam→column M:

Ftop=N Af/A0−M/h0=−60.168937777kN;
Fbottom=N Af/A0+M/h0=+71.496631677kN;
Nweb=N Aw/A0=+5.674535393kN; h0=303.8mm.

Force and couple close exactly. The gusset receives no share of the20kNm frame moment. CJP/base flange max utilization0.103411; web fillet resultant26.604293kN, utilization0.079339. Column flange substrate at this web weld receives simultaneous normal/shear, not only a web yielding row.

The top column receiving region is genuinely compressed despite tensile P. Web crippling NBR5.7.4 is active, Rd649.615kN, utilization0.092622; top web yielding0.195304. Bottom tensile column-flange local bending utilization0.153793 and web yielding0.232073. Web spread for the beam-web attachment receives zero extra5k, so no beam-flange area is counted twice. For the main no-radius strength geometry the top-flange spread ends197.0mm and column-gusset spread begins160.0mm: these intervals do overlap. The full flange demand is assigned to its designed continuity path; no parallel flange/web resistance is added. The two6mm web fillets around the12mm upper continuity plate extend over y139.9…145.9 and157.9…163.9, so their upper contact also overlaps the gusset spread by3.9mm. An explicit same-case absolute-load union check therefore uses |Ftop|+Hc=83.166708485kN and one5k over the combined actual footprint span603.2mm; Rd2323.2231kN, utilization0.035798. Neither contact disjointness nor favorable tension/compression cancellation is claimed. The overlap adversarial case separately demonstrates the failure that duplicated web spread can hide.

NBR5.7.5 sidesway is inapplicable at the beam-flange force levels because relative lateral displacement is restrained by the full-depth connected continuity pair. NBR5.7.6 external opposed-compression pair does not occur. Rolled W sections have no built-up flange/web fabrication weld to invent. Compressed gusset normal forces at other angles are never suppressed by P>0.

## 5. Continuity path, including each plate's eccentricity

The whole top/bottom flange force is assigned to the corresponding continuity pair, with no added parallel web resistance. Gross pair area3360mm²; clipped net area2640. Tensile effective connected area uses only two100mm actually welded widths, Ae2400, rupture711.111kN. Compression net yield600kN. Width140 and thickness12 satisfy NBR5.7.9.5; actual outstand b/t11.667 is below Table4 AL-group4 limit15.839. Thus even small bending-induced compressed edges of the otherwise tensile bottom plate remain covered.

A pair-only cancellation is insufficient to explain each weld. For the positive-z plate, the loaded-flange resultant is atz89.95 and web line atz4.95, eccentricity85mm. Each plate receives Fp=Fpair/2. Select uniform axial web traction and a zero-resultant linear transverse traction qz(x)=Fp·85·x/Iline, with Iline=L³/12,L207.2. Mirror the signs on the opposite plate. Each plate individually equilibrates, and equal/opposite transverse web-face actions have no net whole-joint z force.

For t=x/(L/2),−1≤t≤1, actual plate resultants are:
N=Fp(1+t)/2;
Vz=Fp(1.5·85/L)(1−t²);
My=Fp(7.5+28.75t−21.25t³).

At the inner end N,V,M all vanish; at the loaded-side web termination they become Fp,0,15Fp. The outer35mm transition and30mm root clip move the section centroid to the actual flange-weld centroid, yielding M0 at the flange. Exact polynomial stationary points and clip-end limits close this finite section family. Maximum conservative same-section normal/shear VM is42.183884MPa on the bottom plate, utilization0.185609. It contains a small actual compressive edge; it is not waived.

Web weld demands therefore include multiplier sqrt[1+(6·85/207.2)²]=2.656... over axial-only demand. Maximum continuity web-weld utilization0.250608, not the earlier centroid-only0.094328. Loaded-flange weld max0.195447. Plate contact/base metal and reciprocal column receiver are independently checked. Common column web thickness9.9 is counted once, not four times. Opposed transverse weld tractions create local through-web normal stress35.388733MPa; the conservative common-web shear is34.854643MPa. Local receiver VM utilization0.223118. A von-Mises norm-triangle envelope including concurrent column N/M and actual panel shear remains0.566579; it is a conservative combined-state bound, not an added capacity or calibrated guard.

A supplementary full compression-member calculation to NBR5.7.9.4 uses the two plates plus25tw web strip, Le0.75h=207.9,A5810.25,I24382820.817. The stronger column strip is conservatively assigned the plate's fy250 for this bound: lambda0=0.0361173,chi0.999454,Rd1319.791kN, utilization0.045590. This is shown despite sidesway being restrained; it does not replace actual clipped net strength, local compactness or the per-plate mixed stress calculation.

## 6. Panel from these same complete actions

A horizontal cut through the panel, on the upper-column free body, gives
Q(y)=−[Xupper+Hc+Ftop+Nweb_above(y)].

The upper gusset is entirely above the panel. The real beam-web Nshare is distributed over y−110…110, so panel extrema occur at its endpoints:
Qtop=+27.171167069kN, Qbottom=+21.496631677kN.

All column internal cuts, their N and M, are independently integrated in crossreview/INDEPENDENT_JOINT_REVIEW.json. Maximum actual column compression500kN; Npl=4264.2kN; N/Npl0.117255<0.4. NBR5.7.7 resistance573.804kN; utilization0.0473527. Continuity plates provide neither a fictitious zero panel demand nor doubler area.

## 7. Adversarial acceptance and precise unsupported cases

- Adjustable phi40/50: regenerate brace weld footprint and generalized forces; no alpha=beta angle lock. Angle30/60 with this SAME finite outline may lose geometric containment, a real geometry failure, not a prohibited angle.
- Phi80: Vb becomes negative; activate the real compressed beam/gusset path. Until its gusset compression model is evaluated, return UNVERIFIED_COMPRESSION_COMPONENT, never an all-tension pass. This does not ban tensile braces at80°.
- Actual main-case compression: Ftop−60.169kN activates receiving web crippling, continuity compression and mixed plate stress, even though P+100kN.
- Offset: move force line100mm in right-hand normal(sinphi,−cosphi); moment+10kNm. Return UNVERIFIED_ECCENTRIC_DISTRIBUTION until the selected DG29§4.2.2 allocation is evaluated. Do not reuse zero-seam moment.
- Complete versus incremental: both correct constructions agree; adding the brace twice leaves nonzero force residual.
- Materials: reducing only columnfy345→250 reduces column/panel resistance; angle/gusset/beam/stiffener values do not change.
- Overlapping load zones: two100mm footprints110mm apart, each500kN. Separate spread capacities604.5435kN misleadingly pass each0.82707. Their connected union gets one5k:980.2485kN, total utilization1.020149, correctly FAIL.
- Panel axial reduction: change upper compression to0.8Npl=3411.36kN and update lower cut by the same equilibrium. Q is unchanged, factor0.6,Rd344.2824kN, utilization0.0789212. This is a panel-function adversarial witness, not blanket global-member approval at high compression.

## 8. Production gate and stopping boundary

Genuinely closed for C1: physical geometry, exact brace resultant, four welds and local bases, angle nominal tension/tear, actual gusset gross/Whitmore/body fracture/free-edge families, both supported sections/root seams/base contacts, receiving NBR local modes, concurrent uniform web shear, complete welded beam N/V/M, clipped continuity plates and their actual per-plate eccentric weld transfer, reciprocal receivers, and panel with concurrent axial reduction.

Not certified here: fabrication/WPS execution or inspection, mill/as-built tolerance verification, fatigue/seismic behavior, arbitrary three-dimensional forces, global frame/member stability, full compression brace or an unevaluated compressed gusset, and unevaluated eccentric-WP redistribution. Those are explicit scope boundaries rather than missing equations for the selected C1 local joint.

Production may implement this bounded family now. Release still requires comparing its own outputs to these independent values, geometry/adversarial tests, input serialization, reports/drawings, and independent acceptance. Never import ORACLE.json as runtime capacity logic. There is no further broad reference hunt or FEA prerequisite for this stated static branch.

Implementation presentation: these instrumented primitive rows are not86 required user fields or top-level report checks. Derive seams/centroids/material properties from the drawn detail and catalogs; keep one complete-cut load convention. A compact report should show each component's governing check, with detailed force lineage available for review. Suppress genuinely inapplicable tension/compression modes with their signed reason.

## 9. Exact parameterization domain for implementation

The enabled first adapter is **symmetric welded T-2L only**. This full-joint fixture does not qualify the1L corner adapter. Present per-component governing summaries; detailed primitive rows remain available for audit rather than appearing as redundant user inputs.

The generalized force equations are parameterized by actual positive seam lengths, actual centroids, actual brace line and signed concurrent actions. Their equilibrium identity is not a license to extrapolate the resistance geometry. phi40/50 witnesses prove geometric containment and equilibrium only, not a complete changed-case strength qualification.

The numeric continuity polynomial7.5+28.75t−21.25t³ belongs ONLY to this140mm-wide rectangular plate, loaded resultantz89.95, weblinez4.95, gross centroidz74.95, centered continuous207.2mm web weld and the stated clips entirely outside its effective interval. Changing width, clip shape, effective weld endpoints, force centroid, plate symmetry or traction distribution requires re-derivation from actual geometry. In the same rectangular/continuous-line family, define d=zbar−zweb,delta=zload−zbar,e=d+delta, and t=2(x−xweb_centroid)/L. Then the explicitly derived moment is Fp[delta/2+(d/4+3delta/4)t−(d+delta)t³/4], with the same N/Fp=(1+t)/2 and Vz/Fp=(1.5e/L)(1−t²). Derive the outside-weld/clip sections separately. If a clip crosses the effective weld interval, welds are discontinuous/unequal, or the actual plate section is not this connected rectangular family, the stated polynomial does not apply. Return the specific unevaluated geometry/traction component until its finite path is implemented; do not silently reuse85mm or these coefficients.

Likewise, the gusset chord b=2(1069.4990065−u), centroidv3.181981, and the one-interval endpoint proof are C1 geometry results. Changed brace angle or polygon requires actual line/polygon intersections, section-force integration and all vertex/weld-end/support-contact stations. Re-evaluate which U/L candidate blocks close on real free edges and which remain supported. A new physical boundary, hole, re-entrant notch, support segment or weld interruption can change that family and its extrema; return the precise unqualified path/section if the implemented solver does not cover it. Do not infer 'pass' from the C1 path names or substitute a single-root rectangle.

Root weld, receiving-member and panel equations remain within their explicitly verified material, sign, restraint and NBR branch conditions. Compressed gusset sections, a custom work-point offset, out-of-plane force, unequal opposite-face parts or an absent essential concurrent action produce a specific incomplete/unsupported component. They are not erased, assigned zero, or converted into an arbitrary blanket angle ban. Geometry/data errors, strength failures and unqualified methods are distinct statuses.
