# Independent corner-gusset engine acceptance

**GO, bounded static local connection scope.** Final engine SHA256: `3febc356237ad9d5ac3457aa272a904feed707e9300eeffa214e0440c9644749`.

The reviewer derived 18 parameterized fixtures without importing application code, locked the expected source and numbers before runtime comparison, and independently reproduced 54 key source quantities. Runtime passes 1356 numerical comparisons, including every demand, resistance and ratio in the 86-row full-joint C1 fixture. All 112 frozen tear-path comparisons and physical boundaries of 36 admissible blocks at 40/45/50 degrees pass.

The final API/state review passes 323 adversarial observations and 76 strict missing/extra/type schema mutations. It covers coordinate-only moment transport, CJP consumable and weaker/thinner recipient bases, exact receiver end-distance and flange-footprint thresholds, one-capacity overlapping dispersion, thin shared-gusset material, unsupported assemblies/compression/offsets, outside-cut loads and controlled numeric failure.

All 18 legacy routes and 98 complete preset outputs, including public derived result/check properties, are identical after normalizing only app-version metadata. All 933 immutable 0.9.31 source hashes remain intact. The historical missing external bolt-bearing oracle has not been restored or claimed as a new pass.

The changed 40/50-degree standard cases are now genuinely checked through actual retained-support traction, not copied C1 body constants. Moving those brace welds to 700…920 mm produces small real compressed body edges and correctly remains UNVERIFIED. Changed continuity widths/clips and asymmetric flange margins regenerate actual centroids, moment polynomials and per-plate transfer.

The acceptance applies to the implemented static tensile symmetric welded T-2L rolled W strong-axis local joint. It does not approve arbitrary offsets, compressed gussets, full brace compression, non-W assembly welds, nonplanar/cyclic work, global members or fabrication. Unsupported methods stay explicit; optional member diagnostics cannot alone reject the connection. Full UI/report/drawing release acceptance is separate.

The machine-readable receipt is ENGINE_ACCEPTANCE.json. Its dependency and result hashes bind this decision to the exact tested snapshot. Any later dependency edit requires reconsideration/rerun. No production file was edited by this reviewer; no upload or deployment was performed.
