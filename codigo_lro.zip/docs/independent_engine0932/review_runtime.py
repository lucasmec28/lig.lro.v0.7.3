"""Independent locked expected-value comparison against runtime; no production edits."""
from pathlib import Path
from dataclasses import replace
import sys,json,math,hashlib,datetime
HERE=Path(__file__).resolve().parent;SRC=HERE.parent/'source0932';sys.path.insert(0,str(SRC))
lock=json.loads((HERE/'EXPECTED_PRE_RUNTIME_LOCK.json').read_text())
for n,h in lock['files'].items():assert hashlib.sha256((HERE/n).read_bytes()).hexdigest()==h,n
from lro.corner_gusset import CornerGusset,analyze
prehash=hashlib.sha256((SRC/'lro/corner_gusset.py').read_bytes()).hexdigest()
cases={
 'C1':{},'phi40_unchanged':{'phi_deg':40.},'phi50_unchanged':{'phi_deg':50.},'phi80_unchanged':{'phi_deg':80.},
 'phi40_detached':{'phi_deg':40.,'brace_weld_start':700.},'phi50_detached':{'phi_deg':50.,'brace_weld_start':700.},
 'continuity_width130_clip20':{'continuity_width':130.,'continuity_clip':20.},
 'continuity_width120_clip30':{'continuity_width':120.},
 'continuity_weld_gap10':{'continuity_web_end_margin':10.,'continuity_flange_start_margin':10.,'continuity_flange_end_margin':10.},
 'continuity_asymmetric_flange_margins':{'continuity_flange_start_margin':15.},
 'angle_catalog_R34':{'angle_profile':'GERDAU_EQUAL_ANGLE_P03_R34'},
 'column_material250':{'column_steel':'ASTM A36'},
 'upper_column_high_axial':{'upper_column_cut_Fy':-.8*12360.*345.},
 'beam_cut_relocated':{'beam_cut_x':1300.,'beam_cut_y':40.,'beam_cut_M':62300000.-300.*(-50000.)+40.*(-30710.67811865475)},
 'upper_cut_relocated':{'upper_column_cut_x':20.,'upper_column_cut_y':1200.,'upper_column_cut_M':10000000.-20.*(-500000.)+200.*10000.},
 'beam_catalog_W310x44_5':{'beam_profile':'W 310 x 44,5'},'column_catalog_W310x107':{'column_profile':'W 310 x 107,0 (H)'},
 'asymmetric_seam_lengths':{'plate_width':650.,'plate_height':580.,'brace_weld_start':700.}}
expected=json.loads((HERE/'EXPECTED_PARAMETERIZED.json').read_text())['cases'];numeric=[];failures=[];summaries=[];outputs={}
def cmp(case,label,actual,expected,rel=1e-8,abs_=1e-5):
 passed=isinstance(actual,(float,int)) and math.isfinite(actual) and math.isclose(actual,expected,rel_tol=rel,abs_tol=abs_)
 row=dict(case=case,quantity=label,actual=actual,expected=expected,passed=passed);numeric.append(row)
 if not passed:failures.append(row)
for case,edit in cases.items():
 c=replace(CornerGusset(),**edit);o=analyze(c);outputs[case]=o;e=expected[case];cks={r['id']:r for r in o['checks']}
 summaries.append(dict(case=case,status=o['status'],issues=o['issues'],checks=len(cks),failed_ids=[r['id'] for r in o['checks'] if r['status']=='FAIL']))
 if not o['forces']:
  failures.append(dict(case=case,missing='forces'));continue
 for k,v in e['forces'].items():cmp(case,'forces.'+k,o['forces'][k],v)
 for k,v in e['joint'].items():cmp(case,'joint.'+k,o['joint_beam_to_column'][k],v)
 for k in ['Fx','Fy','M']:cmp(case,'lower.'+k,o['complete_cuts']['column_lower'][k],e['lower_cut'][k])
 for k,s in [('A0','area_basis_rectangles'),('Af','Af'),('Aw','Aw'),('Nweb','Nweb'),('Ftop','Ftop'),('Fbottom','Fbottom'),('h0','h0')]:cmp(case,'components.'+k,o['joint_distribution'][s],e['beam_components'][k])
 for k,s in [('Qtop','Qtop'),('Qbottom','Qbottom'),('axial_reduction','factor')]:cmp(case,'panel.'+k,o['panel'][s],e['panel'][k])
 cmp(case,'panel.R',cks['column_panel_zone']['resistance'],e['panel']['R'])
 cmp(case,'panel.ratio',cks['column_panel_zone']['utilization'],e['panel']['ratio'])
 for k,s in [('gross_R','angle_each_gross'),('effective_R','angle_each_effective_rupture'),('nominal_block_R','angle_each_nominal_through_leg_block')]:cmp(case,'brace.'+k,cks[s]['resistance'],e['brace'][k])
 for label in ['beam','column']:
  cmp(case,label+'.root_weld_ratio',cks[label+'_root_weld']['utilization'],e['root'][label]['weld_ratio'])
  cmp(case,label+'.receiver_yield_R',cks[label+'_receiving_web_local_yield']['resistance'],e['root'][label]['yield_R'])
 cmp(case,'gusset.body_VM',cks['gusset_actual_body_chord_gross']['demand'],e['geometry']['integrated_body']['peak_VM']['VM'])
 cmp(case,'gusset.body_min_normal',o['gusset_body']['minimum_normal'],e['geometry']['integrated_body']['min_sigma'])
 cmp(case,'gusset.whitmore',cks['gusset_whitmore_gross_peak_tension']['demand'],e['geometry']['whitmore_peak'])
 for label in ['top','bottom']:
  r=e['continuity']['rows'][label]
  for k,s,f in [('max_VM','plate_equilibrated_NVM','demand'),('web_weld_ratio','web_weld','utilization'),('flange_weld_ratio','loaded_flange_weld','utilization'),('receiver_VM','column_web_combined_receiver','demand'),('receiver_sigma_z','column_web_normal_rupture','demand'),('concurrent_triangle','concurrent_column_receiver_bound','demand')]:cmp(case,label+'.'+k,cks['continuity_'+label+'_'+s][f],r[k])
  plate=next(v for v in o['continuity_per_plate_traction'] if v['name']==label)
  cmp(case,label+'.sigma_min',plate['minimum_normal'],r['sigma_min'])
  cmp(case,label+'.sigma_max',plate['maximum_normal'],r['sigma_max'])
  for i,term in enumerate(r['Mpoly']):cmp(case,label+'.Mpoly'+str(i),plate['M_poly'][i],term)
 # Compare the independent positive/minus term rather than the differently named optional union.
 if 'column_top_flange_gusset_overlap_union' in cks:
  for a,b in [('demand','demand'),('resistance','R'),('utilization','ratio')]:cmp(case,'union.'+a,cks['column_top_flange_gusset_overlap_union'][a],e['flange_union'][b])
# Every frozen full-joint source check, not only maxima.
golden=json.loads((HERE/'frozen_source_fixture/ORACLE.json').read_text());c1={r['id']:r for r in outputs['C1']['checks']}
for row in golden['checks']:
 if row['id'] not in c1:failures.append(dict(case='C1_SOURCE_ALL86',missing=row['id']));continue
 for k in ['demand','resistance','utilization']:cmp('C1_SOURCE_ALL86',row['id']+'.'+k,c1[row['id']][k],row[k])
# Deterministic finite serialized outputs; Infinity is unacceptable in any of these cases.
for name,o in outputs.items():
 try:json.dumps(o,allow_nan=False)
 except ValueError as err:failures.append(dict(case=name,nonfinite=str(err)))
posthash=hashlib.sha256((SRC/'lro/corner_gusset.py').read_bytes()).hexdigest()
result=dict(checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256_before=prehash,source_sha256_after=posthash,source_stable=prehash==posthash,comparisons=len(numeric),failures=failures,summary=summaries,numeric=numeric)
(HERE/'RUNTIME_COMPARISON.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
(HERE/'RUNTIME_OUTPUTS.json').write_text(json.dumps(outputs,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:result[k] for k in ['source_stable','comparisons','failures','summary']},indent=2))
