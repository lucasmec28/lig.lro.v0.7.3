"""Independent API/model-state adversaries, no production writes."""
import sys,json,math,copy,hashlib,datetime
from pathlib import Path
from dataclasses import fields,replace
HERE=Path(__file__).resolve().parent;SRC=HERE.parent/'source0932';sys.path.insert(0,str(SRC))
from lro.corner_gusset import CornerGusset,analyze,geometry,receiving_union
base=CornerGusset();records=[];bad=[]
def run(name,c,predicate=None):
 try:
  out=analyze(c)
  finite=True
  try:json.dumps(out,allow_nan=False)
  except ValueError:finite=False
  ok=bool(out and out.get('status') in ('PASS','FAIL','INVALID','UNVERIFIED')) and finite
  if predicate is not None:ok=ok and predicate(out)
  row=dict(name=name,passed=ok,status=out.get('status'),finite=finite,approved=out.get('approved'),complete=out.get('complete'),issues=[i['id'] for i in out.get('issues',[])],failed_ids=[x['id'] for x in out.get('checks',[]) if x.get('status')=='FAIL'])
 except Exception as ex:
  row=dict(name=name,passed=False,error=type(ex).__name__+':'+str(ex));out=None
 records.append(row)
 if not row['passed']:bad.append(row)
 return out
# Required missing/malformed numeric/boolean fields may not silently default.
for f in fields(base):
 v=getattr(base,f.name)
 if type(v) in (int,float):
  for label,z in [('none',None),('nan',float('nan')),('inf',float('inf')),('bool',True),('string','1')]:run('numeric_'+f.name+'_'+label,replace(base,**{f.name:z}),lambda o:o['status']=='INVALID')
 elif type(v) is bool:run('boolean_'+f.name,replace(base,**{f.name:1}),lambda o:o['status']=='INVALID')
# Every native key required, every unrecognized native field rejected.
raw=base.to_dict();schema_checks=0
for key in raw['connection']:
 x=copy.deepcopy(raw);del x['connection'][key]
 try:CornerGusset.from_dict(x);bad.append(dict(name='missing_native_'+key,passed=False))
 except ValueError:schema_checks+=1
for edit in [('top','extra',1),('connection','extra',1),('top','schema_version',True),('top','component_version','old'),('units','force','kN')]:
 x=copy.deepcopy(raw);where=x if edit[0]=='top' else x[edit[0]];where[edit[1]]=edit[2]
 try:CornerGusset.from_dict(x);bad.append(dict(name='schema_'+str(edit),passed=False))
 except ValueError:schema_checks+=1
rt=CornerGusset.from_dict(json.loads(json.dumps(raw)));assert rt==base
# Real scope, errors and compression are distinct from ordinary strength failure.
for name,edit in [
 ('missing_other_loads',{'other_loads_excluded':False}),('offset',{'workpoint_offset':100.}),('negative_brace',{'P':-100000.}),
 ('not_symmetric',{'symmetric':False}),('one_angle',{'topology':'1L'}),('opposed',{'topology':'opposed_2L'}),
 ('wrong_convention',{'load_convention':'INCREMENTAL'}),('no_CJP',{'matching_cjp':False}),('no_restraint',{'lateral_restraint':False}),
 ('mismatched_lower',{'compare_lower_cut':True,'lower_column_check_Fx':-40000.}),('wrong_material_plate',{'gusset_steel':'ASTM A992'}),
 ('cp_clips_intrude',{'continuity_clip':140.}),('negative_clip',{'corner_clip':-1.}),('zero_gamma',{'gamma_a1':0.}),
 ('zero_root_weld',{'root_weld_leg':0.}),('outside_footprint',{'plate_width':300.}),('tiny_cp_weld',{'continuity_web_weld_leg':2.})]:
 run(name,replace(base,**edit),lambda o:not o['approved'] and o['status']!='PASS')
run('correct_lower',replace(base,compare_lower_cut=True),lambda o:o['status']=='PASS')
run('zero_brace_actual_frame',replace(base,P=0.))
run('heavy_panel_compression',replace(base,upper_column_cut_Fy=-1.4*12360.*345.),lambda o:not o['approved'])
run('extreme_finite_force',replace(base,P=1e200),lambda o:not o['approved'])
# Matching CJP is a selected consumable/base-metal compatibility, not a Boolean.
for fw in [415.,450.,484.99]:
 run('CJP_undermatched_'+str(fw),replace(base,fw_joint=fw),lambda o:not o['approved'])
run('CJP_A57250_matching',replace(base,fw_joint=485.),lambda o:o['approved'])
run('CJP_A36_matching_E60',replace(base,beam_steel='ASTM A36',column_steel='ASTM A36',fw_joint=415.),lambda o:o['approved'])
run('CJP_A57265_under',replace(base,beam_steel='ASTM A572 Gr.65',column_steel='ASTM A572 Gr.65',fw_joint=485.),lambda o:not o['approved'])
# A field whose target lies outside these cuts is not an in-assembly load.
for member,pt in [('column',[0.,-1500.]),('column',[0.,1500.]),('beam',[1500.,0.]),('beam',[100.,0.])]:
 load=dict(label='outside',member=member,point=pt,Fx=5000.,Fy=-30000.,M=400000.)
 run('outside_cut_'+member+'_'+str(pt),replace(base,other_loads_excluded=False,other_loads=(load,)),lambda o:o['status']=='INVALID')
for member in ['beam_profile','column_profile']:
 run('built_up_'+member,replace(base,**{member:'CS 600 x 281'}),lambda o:any(i['severity'] in ['unverified','outside_scope','invalid_input'] and ('member' in i['id'] or 'profile' in i['id'] or 'section' in i['id']) for i in o['issues']))
# An incomplete strength case must preserve its incompleteness despite a separate failure.
run('mixed_failure_and_unverified',replace(base,workpoint_offset=100.,continuity_web_weld_leg=1.),lambda o:not o['approved'] and not o['complete'])
# NBR6.2.5.1 Awb and fy depend on both joined bases.
weaker=run('CJP_weaker_column',replace(base,column_steel='ASTM A36'))
thinner=run('CJP_thinner_column',replace(base,column_profile='W 310 x 60,0*',continuity_width=90.,continuity_clip=20.))
for label,out,expected in [('weaker_column',weaker,167.*13.2*250./1.1),('thinner_column',thinner,167.*13.1*345./1.1)]:
 if out:
  row=next(q for q in out['checks'] if q['id']=='joint_top_CJP_and_beam_flange')
  r=dict(name='CJP_'+label+'_base_capacity',passed=math.isclose(row['resistance'],expected,rel_tol=1e-12),actual=row['resistance'],expected=expected);records.append(r)
  if not r['passed']:bad.append(r)
# Coincident weld lines on opposite faces cannot acquire two full shared plate depths.
thin=run('thin_shared_gusset',replace(base,plate_t=6.,brace_weld_leg=5.,root_weld_leg=3.))
if thin:
 row=next(q for q in thin['checks'] if q['id']=='brace_heel_gusset_face_substrate_each_face')
 expected=min(.6*250.*220.*min(5.,6./2)/1.1,.6*400.*220.*min(5.,6./2)/1.35)
 r=dict(name='thin_shared_gusset_capacity',passed=math.isclose(row['resistance'],expected,rel_tol=1e-12),actual=row['resistance'],expected=expected);records.append(r)
 if not r['passed']:bad.append(r)
# Supported material exists beyond effective weld endpoints; cuts must enclose it.
run('physical_column_contact_beyond_end',replace(base,column_end_top=750.,upper_column_cut_y=750.),lambda o:o['status']=='INVALID')
run('column_cut_crosses_physical_contact',replace(base,upper_column_cut_y=750.),lambda o:o['status']=='INVALID')
run('beam_cut_crosses_physical_contact',replace(base,beam_cut_x=749.),lambda o:o['status']=='INVALID')
# Coordinate re-expression leaves the identical physical actions unchanged.
c1=run('C1',base,lambda o:o['status']=='PASS')
upper=run('upper_reference_x100',replace(base,upper_column_cut_x=100.,upper_column_cut_M=60e6))
beam=run('beam_reference_y1000',replace(base,beam_cut_y=1000.,beam_cut_M=62.3e6+1000.*base.beam_cut_Fx))
for name,out in [('upper_reference_x100',upper),('beam_reference_y1000',beam)]:
 if not out:continue
 a={x['id']:x for x in out['checks']};ref={x['id']:x for x in c1['checks']}
 differences=[dict(id=k,field=f,base=ref[k][f],modified=a[k][f]) for k in ref.keys()&a.keys() for f in ('demand','resistance','utilization') if not math.isclose(ref[k][f],a[k][f],rel_tol=1e-10,abs_tol=1e-6)]
 row=dict(name=name+'_same_physics',passed=not differences,differences=differences);records.append(row)
 if differences:bad.append(row)
# End branch source witness, no global analysis fabricated.
near=run('column_near_end',replace(base,column_end_top=760.,upper_column_cut_y=760.))
if near:
 row=next(x for x in near['checks'] if x['id']=='column_receiving_web_local_yield');expected=1.10*(550+2.5*15.4)*345*9.9/1.1
 r=dict(name='column_near_end_capacity',passed=math.isclose(row['resistance'],expected,rel_tol=1e-10),actual=row['resistance'],expected=expected);records.append(r)
 if not r['passed']:bad.append(r)
# Exact NBR5.7.3 transition: interior requires distance strictly greater than d.
for delta in [-1e-6,0.,1e-6]:
 exact=run('column_end_at_d_'+str(delta),replace(base,column_end_top=781.5+delta,upper_column_cut_y=760.))
 if exact:
  row=next(x for x in exact['checks'] if x['id']=='column_receiving_web_local_yield')
  expected=1.10*(550+(5. if delta>0 else 2.5)*15.4)*345*9.9/1.1
  r=dict(name='column_end_at_d_capacity_'+str(delta),passed=math.isclose(row['resistance'],expected,rel_tol=1e-10),actual=row['resistance'],expected=expected);records.append(r)
  if not r['passed']:bad.append(r)
# Source-motivated duplicate5k trap.
group=receiving_union([(0.,100.,500000.),(110.,210.,500000.)],15.4,345.,9.9)[0]
assert math.isclose(group['resistance'],980248.5,rel_tol=1e-12) and group['utilization']>1
# At exact 0.15bf, flange bending exemption is not permitted.
threshold=run('root_footprint_at_point15bf',replace(base,plate_t=.15*167.-12.))
if threshold:
 r=dict(name='strict_flange_exemption',passed=not threshold['seams']['beam']['flange_bending_exempt']);records.append(r)
 if not r['passed']:bad.append(r)
result=dict(checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),runtime_sha256=hashlib.sha256((SRC/'lro/corner_gusset.py').read_bytes()).hexdigest(),checks=len(records),schema_rejections=schema_checks,failures=bad,records=records)
(HERE/'ADVERSARIAL_HARDENING.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['checks','schema_rejections','failures']},indent=2))
