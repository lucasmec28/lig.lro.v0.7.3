"""Compare independent formulas to frozen source fixture before runtime use."""
import json,math,hashlib,datetime
from pathlib import Path
p=Path(__file__).resolve().parent
ind=json.loads((p/'EXPECTED_PARAMETERIZED.json').read_text())['cases']['C1']
src=json.loads((p/'frozen_source_fixture/ORACLE.json').read_text());checks={r['id']:r for r in src['checks']}
rows=[]
def check(k,a,b):
 assert math.isclose(a,b,rel_tol=1e-9,abs_tol=1e-5),(k,a,b)
 rows.append(dict(key=k,independent=a,source=b))
for k,v in ind['forces'].items():check('forces.'+k,v,src['force_model'][k])
for k,v in ind['joint'].items():check('joint.'+k,v,src['joint_beam_to_column'][k])
for k in ['Fx','Fy','M']:check('lower.'+k,ind['lower_cut'][k],src['complete_cuts']['column_lower'][k])
for k,s in [('A0','area_basis_rectangles'),('Af','Af'),('Aw','Aw'),('Nweb','Nweb'),('Ftop','Ftop'),('Fbottom','Fbottom'),('h0','h0')]:check('components.'+k,ind['beam_components'][k],src['joint_distribution'][s])
for name in ['beam','column']:
 for k,s in [('weld_ratio',name+'_root_weld'),('yield_ratio',name+'_receiving_web_local_yield')]:check(name+'.'+k,ind['root'][name][k],checks[s]['utilization'])
 check(name+'.yield_R',ind['root'][name]['yield_R'],checks[name+'_receiving_web_local_yield']['resistance'])
for k,s in [('gross_R','angle_each_gross'),('effective_R','angle_each_effective_rupture'),('nominal_block_R','angle_each_nominal_through_leg_block')]:check('brace.'+k,ind['brace'][k],checks[s]['resistance'])
check('heel_weld',ind['brace']['heel_weld_ratio'],checks['brace_heel_weld_each_face']['utilization'])
check('Ct',ind['brace']['Ct'],src['brace']['Ct'])
check('heel_fraction',ind['brace']['heel_fraction'],src['brace']['fheel'])
for k,s in [('Qtop','Qtop'),('Qbottom','Qbottom'),('R','VRd'),('axial_reduction','factor')]:check('panel.'+k,ind['panel'][k],src['panel'][s])
for name in ['top','bottom']:
 row=ind['continuity']['rows'][name]
 for k,s in [('max_VM','plate_equilibrated_NVM'),('receiver_VM','column_web_combined_receiver'),('receiver_sigma_z','column_web_normal_rupture'),('concurrent_triangle','concurrent_column_receiver_bound')]:check(name+'.'+k,row[k],checks['continuity_'+name+'_'+s]['demand'])
 for k,s in [('web_weld_ratio','web_weld'),('flange_weld_ratio','loaded_flange_weld')]:check(name+'.'+k,row[k],checks['continuity_'+name+'_'+s]['utilization'])
 check(name+'.eccentricity',ind['continuity']['e'],next(r for r in src['continuity_per_plate_traction'] if r['name']==name)['webline_e'])
check('body_peak',ind['geometry']['integrated_body']['peak_VM']['VM'],checks['gusset_actual_body_chord_gross']['demand'])
check('whitmore_peak',ind['geometry']['whitmore_peak'],checks['gusset_whitmore_gross_peak_tension']['demand'])
for k,s in [('R','resistance'),('demand','demand'),('ratio','utilization')]:check('union.'+k,ind['flange_union'][k],checks['column_top_flange_gusset_overlap_union'][s])
record=dict(passed=True,numerical_comparisons=len(rows),before_runtime_execution=True,rows=rows)
(p/'INDEPENDENT_SOURCE_REPRODUCTION.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'passed':True,'comparisons':len(rows)}))
