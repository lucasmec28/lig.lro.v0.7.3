# 2L soldadas ao pilar: estado final, viga sem recorte

13/10/2026. Candidata isolada para revisão0.9.43. A fonte0.9.41 é apenas base de leitura;0.9.42 e a candidata1L não são alteradas. Este documento substitui a pendência de montagem da primeira qualificação desta pasta. A avaliação final da candidata depende da revisão focada e dos testes registrados, não deste título.

## Topologia e montagem delimitadas

Duas cantoneiras laminadas iguais e simétricas; uma aba de cada lado da única alma de viga W, com parafusos comuns em dois planos de corte. As abas de apoio são soldadas à mesma mesa contínua de pilar W, cada uma por uma linha vertical na borda externa e retorno superior curto sem crédito resistente. Não há solda inferior, no talão ou na alma apoiada; não há parafuso no pilar.

O usuário esclareceu a montagem em13/10/2026: uma cantoneira pré-soldada ao pilar, segunda posição marcada; viga içada até a fixa, segunda cantoneira colocada com parafuso comum; segunda soldada em campo; todos os parafusos instalados/apertados. Informou manter a viga içada até completar os parafusos. Esta é uma alternativa excepcional. A memória registra a condição final com soldas e parafusos concluídos. Não calcula estabilidade da fase de uma cantoneira/um parafuso, içamento, apoio temporário ou procedimento de soldagem; não autoriza liberar o içamento.

A montagem proposta evita introduzir a viga entre duas cantoneiras já fixas: o lado oposto da alma fica aberto até a colocação da segunda. A sequência geométrica deixa de exigir que uma mesa da viga atravesse um encaixe bilateral fechado. O motor exige cantoneiras entre as raízes da viga, folga positiva de ponta, ferramenta junto aos furos/raízes e filetes dentro da mesa do pilar. `weld_tool_radius` é o envelope real declarado para soldagem de campo; deve caber acima e abaixo da solda até as regiões das mesas/raízes. Não existe valor mínimo universal de equipamento inventado; o exemplo assume20mm explicitamente. Equipamento real, estrutura adjacente e acesso do edifício permanecem condições de execução.

## Fontes que fundamentam esta rota

- Companion AISCv16 II.A-2A, IIA-40–49/PDF580–589, documento fornecido e desenho inspecionado. Topologia exata:2L4×3½×⅜SLBB,8parafusos¾in, soldasB verticais5/16in, retorno2w. Fonte: https://www.aisc.org/media/kybevlwy/first-semester-design-examples-v160.pdf . A excentricidade4in é a aba transversal no apoio; a distância face-parafusos2⅛in é outra dimensão. O exemplo tem recorte inferior de montagem, substituído aqui pela sequência explicitada pelo usuário, sem crédito resistente desse recorte inexistente.
- AISC, Detailing for Steel Construction2, errata2003, pp3-26–27: detalhe genérico de2L, casos de soldagem ao apoio e retorno superior2w sem comprimento resistente; preservar flexibilidade, sem solda superior integral. https://www.aisc.org/media/a3mjwxyh/errata-to-detailing-for-steel-construction-2nd-ed.pdf . Trecho oficial indexado consultado; não é qualificação automática de qualquer geometria.
- AISC, Steel Interchange fevereiro2016, gabarito≤3in com uma linha vertical e furos apropriados; a omissão convencional local não elimina os momentos reais do sistema. https://www.aisc.org/globalassets/modern-steel/archives/2016/02/si.pdf . Essa idealização fica explícita; não é uma dispensa genérica da NBR.
- AISC, Modern Steel janeiro2024 p19: soldasB mudaram do método elástico paraICR na16ªedição. https://www.aisc.org/globalassets/modern-steel/archives/2024/january2024.pdf . Esta candidata usa elasticidade conservadora, não reproduzICR.
- AISC, Steel Interchange dezembro2023 p9: fórmula elástica histórica com contato emL/6 e denominador1+12,96e²/L². https://www.aisc.org/globalassets/modern-steel/archives/2023/december2023.pdf . A candidata não credita esse contato: seu denominador é1+36e²/L², com menor resistência para o mesmo detalhe planar.
- NBR8800:2024/Errata1:2025 fornecida: soldas6.2/tabelas9,11; parafusos e contato6.3; elementos de ligação6.5; cisalhamento da viga5.4.3.1; retornos flexíveis≤4w em6.2.6.2.6(c). A revisão1L disponibilizou a inspeção visual do mesmo texto normativo; o reuso aqui é de normas/componentes, não de sua topologia.

## Domínio inicial

Duas cantoneiras iguais, simétricas, viga e pilarW laminados; V>0 descendente estático; N=M=T externos nulos;2–8parafusos em uma coluna; furo circular padrão; e da face do pilar ao eixo dos parafusos≤76,2mm; comprimento da cantoneira≥metade da altura da viga; sem recortes, calços ou exigência de atrito. Mesa do pilar contínua, sem borda/extremidade ou descontinuidade local participante. SMAW/E7018fuw485MPa. Materiais cadastrados compatíveis; aço de viga, pilar e cantoneiras independentes.

Abas a partir de63,5mm, designaçãoL64; espessuras6,35–9,525mm; b_apoio/t≥8; filtro b/t≤0,45√(E/fy) nas duas abas. São limites deliberados da primeira implementação, não máximos/mínimos normativos universais nem demonstração isolada de ductilidade. O filtro superior é inspirado emNBR tabela4AL3, originalmente para compressão longitudinal, e não substitui os envelopes resistentes ou o detalhe convencional. O intervalo inferior evita estender a cantoneiras excessivamente curtas/espessas sem revisão. Catálogo não concede aprovação automática.

O catálogo Gerdau mantém dimensões métricas publicadas. Raio interno não publicado exige declaração independente; raio manual zero também impede aprovação. `tool_radius` representa cabeça, porca, arruela e ferramenta reais. A triagem inferior usa dimensões máximas publicadas de ferragem heavy-hex/F436, sem reduzir um envelope maior nem escolher uma chave. Fonte/reprodução dos13diâmetros em `evidence/HARDWARE_SOURCE_RECEIPT.json`: BAPP A325M pp2–3 para métricos; https://www.portlandbolt.com/products/bolts/structural/ e https://www.portlandbolt.com/products/nuts/heavy-hex-nut/ para cantos imperiais; https://www.anchorboltexpress.com/F844-F436-washer-chart/ para OD básicoF436 com tolerância positiva0,0313in. A mesma especificação física foi revisada em1L; os dados imperiais foram novamente conferidos nesta passagem2L. Não há duplicação de hardware: um parafuso atravessa t+tw+t.

Retorno físico2w≤r≤min(4w;b/2), deixando o talão superior livre. Sem crédito do retorno no comprimento ou resistência. Comprimento vertical efetivo real≥max(4w;40mm) e≤100w nesta rota; segmentos longos exigem outra qualificação. Filete mínimo pela peça mais fina; máximo t−1,5mm, salvo borda explicitamente reforçada e w≤t. O reforço não aumenta a garganta calculada.

## Corpo livre e método

Globais:x ao longo da viga, y para cima,z transversal. Cada cantoneira recebe F_y=−V/2 na linha de seu talão z=±tw/2. Sua solda está emz=±(tw/2+b). Cada grupo é calculado separadamente. O sinal do momento planar do núcleo(z,y) é oposto aMx global. A soma dos doisMx na origem é zero por simetria; cada excentricidade localb continua integralmente calculada. Não se junta o par num grupo centrado que apagaria os binários locais.

A distribuição direta dos parafusos é a idealização convencional delimitada. Não se mistura a ela um engaste3D nem um binário horizontal de outro modelo de parafusos. A reação realVsd é entregue à face; o transporte face-centro do pilar usa d_pilar/2 e só deve entrar no modelo global quando ainda não representado. O piso45kN é aplicado uma vez à ligação: Vd=max(Vsd;45kN), com Vd/2 por cantoneira; não substitui a reação real no modelo global.

Para cada linha vertical de alturaH, P=Vd/2, excentricidadeb e garganta a=w/√2:

- qy=−P/H
- |qz|max=6Pb/H²
- qmax=(P/H)√[1+(6b/H)²]
- qRd=0,60fuw·a/γa2, sem ganho direcional

Capacidade total de solda=2qRd/qmax(P=1). O cálculo preserva vetores nos extremos, equilíbrio por segmento e os dois grupos físicos. O retorno não participante continua no desenho.

## Aba no apoio, metal-base e receptor

Seção vertical emu, medida da borda soldada até o talão,0≤u≤b. A integração das trações da linha forneceN(u)=0, V(u)=F e B(u)=F(b−u). No talão:B=0; na solda:|B|=|F|b. Usam-se σmax=6|F|b/(tH²), τmax=1,5|F|/(tH), √(σmax²+3τmax²)≤fy/γa1. É um envelope conservador de seções, não solução pontual exata de placa nem crédito plástico.

Em cada linha, metal-base da cantoneira e mesa do pilar: q≤fy·t/(√3γa1) e q≤0,60fu·t/γa2. Duas regiões de solda na mesma mesa são registradas sem criar duas espessuras de pilar. O modelo é local em seu plano e pressupõe mesa contínua; não pretende verificar o pilar global ou inventar uma borda livre na junção mesa-alma.

A aba perfurada tem corte bruto/líquido, contato em cada furo e todos os prefixos de blocoL pela borda inferior carregada. Sua força éV/2. A aba soldada tem seção bruta sem furos, resistência ao corte e o envelopeV/M explícito. A flexibilidade fora do plano e a distribuição direta da aba parafusada pertencem ao detalhe convencional delimitado, não a uma hipótese de ligação rígida.

## Parafusos e única alma

Pega tw+2t. Dois planos por parafuso: cada plano recebe metade da força do parafuso, com0,45ou0,56Abfub/γa2 conforme posição da rosca. A alma única recebeV/n por furo; cada cantoneira recebeV/(2n). Contato da cantoneira é para baixo; contato da alma é para cima. A alma sem recortes não tem borda vertical livre acima do furo superior. São verificadas capacidades individuais, somas normativas e soma das transferências mínimas em série. Não se somam resistências de interfaces sucessivas.

A soma de transferência é Σmin(2Rv;2Rb,cantoneira;Rb,alma). Prefixos de bloco recebem a respectiva fração deV/2. A alma também recebe corte com instabilidadeCv. Não se inventa bloco arrancável até a junção contínua com as mesas.

## Testemunhos e exclusões

AISC publicado: parafusos286,27763kip; soldaICR318,13125kip; elasticidade planar sem crédito de contato228,88041kip. Diferenças não são calibradas. Ensaios de componentes históricos permanecem separados.

Novo exemplo local: W410×38,8/W310×97; duasL101,6×101,6×9,52, H240, g65,4M20p60, filete5, retorno10, V100kN. Capacidade esperada da solda planar134,007991kN. Não é o exemplo AISC nem um projeto de fabricação. O caso500kN deve falhar; V≤0 permanece fora do domínio. GeometriasGerdau viáveis terão testemunhos próprios, com fonte do raio explicitamente sintética nos testes e nunca apresentada como certificação do fabricante.

## Interface e aprovação

Nova identidade `welded_support_double_angle_shear`; não altera R015/R016/1L. Importações estritas, atômicas, sem resultados serializados. UI/Word/desenho recalculam da entrada atual. Entradas brutas e resultados preservados; apenas apresentação usa duas casas. Relatório separa resistência, geometria/acesso e condições de método/execução. Nenhum resultado verde certifica o estágio provisório ou o edifício.
