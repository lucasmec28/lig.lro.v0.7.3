# Revisão 0.9.61 — nervuras de detalhamento

Base engastada: opção nova e independente de duas nervuras alinhadas à alma, além das mesas externas e unidas às mesas e à placa. Contorno com patamares de 20 mm; espessura inicial no primeiro tamanho comercial estritamente superior à alma, editável. Projetos legados com web_pair preservam sua identificação anterior.

End plate engastada: detalhamento opcional nas variantes sem nervuras estruturais. As variantes 4ES e 8ES conservam seus modelos e nervuras estruturais. A opção geométrica não substitui esses modelos.

Cálculos permanecem no modelo base aplicável, sem crédito resistente ou de rigidez dessas nervuras. Nervuras e suas soldas não são dimensionadas nesta opção. Falhas resistentes, verificações de chave/ancoragem e interferências físicas continuam válidas. Dados inválidos de geometria não são convertidos em aprovação.

Desenhos, projetos JSON e memoriais incluem a opção. Testes cobrem equivalência de resultados, permanência de falhas, migração de assinaturas legadas válidas sem aceitar registros obsoletos, dimensões e alternância da interface. Suíte de regressão e revisão independente ficam preservadas com a fonte completa. Testes de software não constituem aprovação estrutural de um projeto.
