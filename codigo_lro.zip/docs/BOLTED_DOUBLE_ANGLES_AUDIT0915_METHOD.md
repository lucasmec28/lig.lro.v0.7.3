# R016 Duas cantoneiras parafusadas Auditoria 0.9.15

Data: 10/10/2026. Correção finita da família existente; cópia de desenvolvimento não publicada.

## Método e domínio preservados

Duas cantoneiras físicas iguais, ambas as abas parafusadas; alma única de viga W sem recorte e apoio na mesa de pilar W. Preserva-se a rota flexível convencional NBR 8800:2024 corrigida 2025 / Gerdau 2018, sob cortante vertical estático e N=M=T externos nulos. A excentricidade geométrica permanece. Não se acrescentou parte isolada de modelo rígido, FEA, mecanismos axiais de gusset, soldas participantes ou outra família.

Os parafusos comuns atravessam as duas cantoneiras e uma única alma, em dois planos; cada grupo independente no apoio recebe V/2 em corte simples. As interfaces são sucessivas, sem soma de resistências. A alma mantém sua espessura real, a seção local conservadora de altura livre e o ramo do membro ao cortante. A diferença de tratamento da alma entre AISC e Gerdau não autoriza eliminar o ramo NBR/Gerdau.

Preservam-se o piso de 45 kN uma vez por conjunto, V real assinado, os dois sentidos quando V=0, gabaritos documentados, furo físico e dedução líquida distintos, 2,7db exato e ligamento livre mínimo db. Contato por furo, soma normativa e distribuição uniforme são registrados separadamente. Blocos usam prefixos, forças, bordas carregadas e extremidades reais; não há caminho fictício através da alma contínua do pilar.

## Correções de confiabilidade e apresentação

- Word e SVG/PNG recalculam a entrada atual. O argumento opcional de resultado é mantido por compatibilidade, mas é ignorado para conclusões, capacidades e detalhes. Resultado omitido, antigo, adulterado ou de outra entrada não autoriza exportação favorável. A interface normal já invalidava corretamente a memória ao editar; o defeito confirmado era a chamada direta dos exportadores.
- Importação prepara e valida integralmente o estado representável antes de alterar controles/projeto. Espessura nativa finita de 0,001 mm incompatível com o mínimo de 0,01 mm é rejeitada, sem correção silenciosa. Trata-se de testemunha de fronteira, sem demonstração de falso atendimento para uma ligação ordinária. Perfis personalizados, valores assinados e ações subnormais conservam a origem canônica até edição real.
- A figura avulsa identifica projeto e V/N/M/T reais assinados e distingue esses dados da restrição do método N=M=T=0.
- NUMERICAL_FAILURE identifica falha aritmética de entrada finita. INVALID_INPUT identifica dado inválido; VERIFIED_SUBCHECK_FAIL continua identificando sobrecarga resistente finita. A conversão kgf é protegida e não mantém artefato antigo elegível após erro de cálculo/construção.
- A apresentação reúne 21 envelopes físicos/mecanismos: três grupos de parafusos, quatro cisalhamentos de abas, um cisalhamento da alma, sete contatos e seis blocos. Todas as 73 linhas no exemplo e 132 com V=0 permanecem no desenvolvimento, com identificadores e registros governantes completos, casos/sentidos e empates. Nenhuma resistência é removida ou aumentada. A soma normativa de contato não substitui a compatibilidade da distribuição uniforme.

## Fontes efetivamente disponíveis

A auditoria anterior confrontou visualmente a NBR fornecida (impressas 84–85, 90–92 e 95–96), Gerdau 7ª edição 2018 (pp.14 e 19–25) e o detalhe R016 do PADRÃO DE LIGAÇÕES-2Model (impressa19). Os coeficientes Gerdau/NBR2008 históricos não substituem os atuais. N na folha industrial conta intervalos; n de parafusos=N+1.

O P901-23W v16.0 completo foi recuperado. SHA-256: ec25b52e1d7b6b9ec9e5eaccc27452153208784d7d715908daa2595dd8f92423. O exemplo II.A-1A está nas páginas PDF542–553, impressas IIA-2–IIA-13, confrontado na auditoria R016 como apoio à topologia, corte duplo/simples, contato por furo e apoio. Esta reconciliação corrige a antiga alegação de acesso integral indisponível; não importa coeficientes americanos ou amplia o método.

Não foram recuperados nesta cópia a tese Higgins e o relatório Green/Sputo/Higgins; não se afirma leitura integral. Os exemplos Souza de dupla cantoneira axial/gusset e junta soldada são outras topologias. Não foi necessária nova leitura de Fakury para fechar estas correções delimitadas.

## Validação e limites

O oráculo independente preservado não importa equações do aplicativo: 18 entradas e 10.920 comparações de capacidades, frações, ações, índices e estados. O número não representa 10.920 casos independentes. Testes focados cobrem exportadores, classificação, fronteira 2,7db, importação, fidelidade, estado e downloads reais registrados pelo Streamlit AppTest. Renderização Word/desenho é delimitada às páginas/casos críticos declarados no relatório de implementação.

Não se executou a suíte completa nem se verificaram pixels ou transporte de download de navegador Chromium. Não há publicação, implantação, otimização de capacidade, qualificação global da estrutura ou início da família seguinte. Arquivos de exemplo de versões anteriores permanecem históricos; novas exportações recalculam canonicamente a entrada.
