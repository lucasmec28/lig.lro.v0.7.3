# Validação restrita · catálogo marinho 0.9.70

Pacote `0.9.70-catalogo-marinho-dev.1`, derivado da base íntegra `0.9.69-estado-emendas-W-dev.1`. Componente de cálculo e schemas continuam em `0.9.44-beam-on-beam-partial-dev`.

## Evidência funcional final da fonte

97 casos únicos passaram, sem falhas, erros ou pulos, em três módulos focados: 80 de navegação, 4 de conservação e 13 de assets/limites de apresentação. Reexecuções e ensaios exploratórios não são somados. Os IDs individuais e hashes dos resultados ficam em `docs/validation0970/SUMMARY.json`.

- 26 famílias abertas por controles reais do AppTest, com seletor, formulário, projeto exportado e resultado nativos conferidos; 29 associações de interface/modelo mantidas exatamente.
- Cartão apenas seleciona candidato; abertura explícita usa o dispatcher existente. Filtros AND, candidato obsoleto, aviso da família atual fora dos filtros e retorno ao catálogo verificados. Duas talas continua acessível.
- Ao abrir uma família, as imagens ilustrativas deixam de ser processadas enquanto o painel está fechado. Os filtros e o formulário permanecem renderizados. Voltar ao catálogo restaura cartões sem trocar o projeto.
- Importação real não padrão, rejeição atômica, JSON/Word/SVG, campos, resultados, drafts, troca/retorno de família e controles de apresentação verificados. Base Tipo 1 legada não é migrada para Tipo 2.
- Guardas existentes das duas emendas W preservadas: uma edição inválida não mantém resultado ou arquivo anterior disponível e a correção recupera o fluxo nativo.
- O desenho atual foi observado chamando o renderer real: alterar o pitch modifica sua geometria e imagem. Miniaturas de presets não substituem essa vista.
- 26 PNGs originais conferidos por hash; erros de instalação, caminhos, arquivos alterados, duplicação de famílias e grupos inválidos rejeitados. Contraste dos pares centrais da identidade e limites de leitura/escrita de estado conferidos.

O primeiro rerun de single plate pode serializar `a=120` e `gap=80` como `120.0` e `80.0`. Esse comportamento foi reproduzido identicamente na base .69, sem mudança de valor físico. A conservação binária foi avaliada após esse ciclo inicial existente.

## Congelamento e distribuição

A comparação com a base admite somente três arquivos existentes alterados: `app.py` (integração e guardas), `lro/package_identity.py` (identidade do pacote) e `verificar_pacote.py` (manifesto atual). Todos os demais módulos existentes, o seletor, o dispatcher e o código dos formulários permanecem idênticos. As adições são os dois módulos visuais, manifesto e 26 miniaturas, testes e documentação da revisão. Nenhum manifesto histórico foi substituído.

A distribuição mantém quatro arquivos externos. A cópia compacta conserva byte a byte a aplicação, os módulos, dados e exemplos. O manifesto atual é gerado exclusivamente nessa cópia. A verificação posterior do ZIP extraído inclui CRC, SHA-256, inventário, compilação em memória, guardas do carregador e AppTest das rotas em processo novo; seu recibo é separado deste resumo de fonte.

## Limites

Não houve validação visual real em navegador: a restrição de socket impediu Chromium no ambiente. AppTest não é captura de tela. Layout responsivo, zoom e contraste de todos os controles nativos exigem conferência no navegador de uso. Não foi executada a suíte histórica inteira, nem uma nova auditoria estrutural. Nenhum teste de software representa aprovação de projeto. Todos os limites e pendências de cada método continuam vigentes. Nenhum outro aplicativo foi alterado, publicado ou implantado.
