# Placas de base Tipo 1 na versão 0.8.0

## Objetivo e alcance

Calcular a placa sem enrijecedores, o contato no concreto e a ruptura à tração do aço de quatro chumbadores externos de uma base de pilar I/H, sob uma combinação estática de N, M no eixo de maior inércia e V no mesmo plano. A referência é a ABNT NBR 8800:2024, versão corrigida em 2025, itens 6.6.5 e 6.7 e Tabela 18 corrigida.

Esta família mantém o fluxo das ligações anteriores: entradas em kgf, kgf·m e mm; resultados rastreáveis; desenho proporcional; JSON e memória Word editável. Internamente, as unidades são N, mm e MPa. As ações são informadas já majoradas, na face superior da placa. Nesta família, N positivo é compressão e N negativo é tração. A tela e o Word explicitam essa convenção.

## Modelo disponível

- Geometria Tipo 1 com quatro chumbadores externos simétricos. L=d+4a1 e B=a2+2a1. A distância mesa–linha de chumbadores e a distância linha–borda são ambas a1.
- Chumbadores ASTM A36, diâmetros imperiais de 3/4 a 2 polegadas e porcas pesadas. A resistência calculada da barra não representa a resistência de sua ancoragem no concreto.
- Concreto de densidade normal, 20 ≤ fck ≤ 50 MPa, com A2/A1=1. Não se presume ganho de confinamento. Argamassa expansiva de assentamento com resistência característica de pelo menos 2fck.
- Regimes C1/C2/C3 e T1/T2/T3 selecionados automaticamente, incluindo o limite de momento puro. O bloco equivalente uniforme de compressão é o do método normativo; não é uma distribuição elástica triangular/trapezoidal ou uma previsão de abertura da base.
- Sinal de M preservado e refletido no lado tracionado. Os resíduos de equilíbrio são mostrados para conferência numérica.
- Espessura da chapa por contato e tração; a maior parcela governa. Pressão de contato, ruptura do aço da barra, largura e graute conferidos separadamente.
- Cortante por atrito placa/graute ou comparação com uma resistência externa documentada. No segundo modo, o dispositivo resiste sozinho ao cortante total; não se soma atrito. O dispositivo não é dimensionado neste módulo.

A Tabela 18 corrigida fornece bitolas, furos, arruelas, dimensões e armadura mínima de referência. Valores de referência não comprovam ancoragem, bloco ou armadura do projeto. Quando a1/a2 diferem do detalhe tabulado, a verificação específica permanece declarada.

## O que ainda precisa de cálculo próprio

Ancoragem no concreto e seus modos de ruptura, arrancamento, efeitos de borda e grupo, armaduras e dimensionamento do bloco, ligação à fundação, soldas pilar–placa e rigidez rotacional. O resultado favorável de um componente não aprova a base completa nem a classifica como rótula ou engaste.

Bases enrijecidas, placas com outro arranjo de chumbadores, perfis tubulares, bases embutidas, flexão biaxial, chumbadores químicos/pós-instalados, sismo, fadiga, ações cíclicas e incêndio não são modelos implementados. Outra configuração pode ser tecnicamente viável; sua geometria precisa de outro procedimento.

## Uso rápido

1. Selecione Placa de base · Tipo 1 e um perfil.
2. Informe N, M e V de cálculo, conferindo a convenção do axial.
3. Escolha a placa, chumbadores, a1/a2 e concreto/graute. O botão da Tabela 18 aplica suas dimensões de referência apenas quando solicitado.
4. Confira os componentes, avisos e o caminho completo do cortante.
5. Salve o JSON e gere o Word. O rascunho sobrevive à navegação entre famílias durante a sessão; o JSON é necessário para armazenamento permanente.

Há seis exemplos didáticos para os regimes de N–M. Eles não representam um projeto executado ou aprovado. Os modelos e projetos das ligações anteriores permanecem compatíveis.
