# MRE1/2 qualification contract for a future implementation

Status: bounded method/numerical qualification, not a production implementation. Frozen 0.9.40 is unchanged. No full application aggregate was run. This document and oracle do not approve fabrication or a structural project.

## Decision

Implement a distinct **MRE1/2, unstiffened extended end plate**, with the actual six-row/twelve-bolt symmetric geometry of DG39 Table 5-12 and continuous unreinforced I-column mechanism A-4(a). It is a practical way to credit the additional inner rows. Adding arbitrary intermediate rows to 4E must never select, imitate or receive credit from MRE1/2.

The branch supports signed M, N and V in the existing application's moment-dominant scope. A missing earlier published N benchmark is not a reason to prohibit N: DG39 §3.5 provides its mechanism and the new independent witness exercises it. The initial branch is not a general axial-dominant/contact solver.

Retain the existing app's **thick at design demand** procedure and name it precisely: “chapa espessa / sem alavanca na demanda de cálculo.” Also report the **separate nominal no-prying classification** for both plate and column, without turning that stronger classification into an unnecessary extra gate on the demand-based procedure. Only claim “sem prying até Mnp” when both nominal conditions hold. The book's Example 5.3-3 is a positive demand-size check and a negative nominal check. It is not the positive full-witness case.

The first supported shear route assigns all V to the six bolts next to the compressed flange. It explicitly tracks per-bolt forces and loaded block paths. Do not silently inherit V/12 from the existing 4E/8ES code. Both ±M and ±V must select actual geometry and signs.

## 1. Physical inputs and source boundaries

Explicit method identity, e.g. MRE12_U, is required. Inputs active in this branch: beam and column profiles/materials; plate steel, bp, tp; bolt specification/diameter, threads and drilled-hole flag; g, pfo, pfi, pb and end-plate edge distance de; signed M/N/V; the normative minimum-force option; physical tool envelope and CJP qualification. No stiffener inputs affect this branch. Old generic n, pitch, overhang, weld-leg and intermediate_n values cannot covertly redefine it.

- Symmetric I beam, full flange width connected, beam perpendicular and centered on a continuous I-column flange; no composite slab participation.
- Exactly six rows of two bolts, no extra holes/rows or external stiffeners. Column A-4(a) only: no continuity plates, cap plate, end/edge mechanism, doubler, opposite beam, nearby opening or splice.
- Standard holes, bearing connection, high-strength pretensioned bolts with no slip/friction credit; no shims; declared contact and compatible workshop CJP joints in beam flanges and web.
- A36/A572 Gr.42/Gr.50 can be selected independently for connected beam/plate; product/thickness and compatible E7018 procedure remain checked. Column retains its independently checked material. Nominal 50 ksi and NBR 345 MPa are identified grade conventions, not proof that any arbitrary fy=345 material is qualified.
- A325/Group120 and A490/Group150 are the tested bolt families; map nominal DG39 Fnt explicitly to90ksi and113ksi respectively (Eq3-21 p.34/PDF44, source-reader visual confirmation). Exclude A307. Do not invent Group144 equivalence. Source's diameter ceiling is 1.5 in; the existing app's listed selector ceiling is 1.25 in and is a UI/catalog limit, not a DG39 mechanical limit.
- Ordinary gravity/wind/static service, no seismic prequalification, cyclic/fatigue or fire claims. Compact beam and restraint/global-analysis assumptions remain those of the existing local model.
- Ncol,Sd≤0.4 Ag,col fyc and no other joint forces are declared conditions for the inherited conservative panel model. Full column/global member analysis stays external.

DG39 Table 5-9, printed p.112 / PDF122: pf=1–5 in for MRE1/2 (the general 2.5 in upper bound is not its bound); pext=2.5–7.5 in; g=2.75–7 in; d=15.75–72 in; bp=5–10.25 in; tbf=0.375–1 in. The guide's ±10% extension is reported as adopted source-domain handling; being outside the band is extrapolation, not a fabricated resistance failure. pb has no independent numerical range in that table. It is controlled by physical topology, bolt spacing, ligaments, access and the other lengths. Do not require pb=3 in just because the example uses it.

Do not import stiffened-family de<s or pfo saturation. pfi>s is supported by the Table 5-12 effective-pfi instruction within the Yp block. Combining that note with physical hi definitions in§3.4p.34 supports the inference that saturation changes only that variable in Yp, never the physical rows, arms, c, weld lengths or block paths. This is a source-compatible inference, not a worked algorithm printed in the example. There is no reason to prohibit it solely because the original example did not exercise it.

## 2. Geometry and active groups

Use the existing app convention y=0 at the top beam face, y positive downward; M>0 means top-flange tension. Physical rows, never sorted to rescue a crossing:

1. −pfo
2. tf+pfi
3. tf+pfi+pb
4. d−tf−pfi−pb
5. d−tf−pfi
6. d+pfo

Every row has x=−g/2 and +g/2. hp=d+2(pfo+de), with no external pb addition. Require row 3 < row 4, positive arms, positive net paths and physical hole ligaments; check all five vertical spacings and transverse g, including the central gap. Distinguish physically impossible geometry, NBR detailing noncompliance and source extrapolation.

M>0 active tension rows are [1,2,3]; compressed-side shear rows [4,5,6]. M<0 tension is [6,5,4] in that order and shear [1,2,3]. Pivots are d−tf/2 and tf/2 respectively. Maintain per-bolt x/y, active_tension, shear_group, signed shear, tension and row identity in results and exports. Twelve physical and six tension-active are different counts.

h1=d−tf/2+pfo; h2=d−3tf/2−pfi; h3=h2−pb; H=2(h1+h2+h3). All active physical pivot distances must equal these values after the sign-dependent selection.

Effective widths: bp_eff=min(bp,bf_beam+max(tp,25.4)); B=min(bf_column,bf_beam+max(tp,25.4)). Physical widths remain in net sections, contact and detail. sP=√(bp_eff g)/2; sC=√(B g)/2; pi=min(pfi,sP); c=pfo+tf+pfi=h1−h2.

Yp=bp_eff/2[h1/pfo+h2/pi+h3/sP−1/2]+2/g[h2(pi+3pb/4)+h3(sP+pb/4)]+g/2.

The −1/2 is outside h3/sP, not multiplied by h3. No pfo=min(pfo,sP) in this unstiffened formula.

Yc=B/2[(h1+h3)/sC]+2/g[h1(sC+3pb/4+3c/4)+h3(sC+pb/4+c/4)]+g/2.

Y has dimension length, with mm, N and MPa internally. References: Table5-12 p.115/PDF125 and Fig5-12 p.153/PDF163; A-4(a) pp.267–268/PDF277–278; sC definition p.263/PDF273.

## 3. Actions, demand thickness and nominal classification

N positive is axial tension. z=d−tf:

Meq=|M|+max(N,0)z/2;
Tb=Meq/H; T=6Tb; C=max(T−N,0).
Ff=|M|/z+max(N,0)/2;
Fc=|M|/z+max(−N,0)/2.

These are three different types of quantities: individual bolt tension/resultant; contact resultant; beam-flange transfer forces. Do not substitute T or C for Ff/Fc in local column-web checks. Preserve corrected 4E quantities and outputs unchanged.

DG39 Eq3-30, §3.5 pp.36–37/PDF46–47 supports the tension equivalent moment. Compression adds half its magnitude to the compression-flange check, with benefit to plate bending optionally ignored. Existing adopted gate |N|z≤|M|, M≠0 is retained for each complete case; this is a conservative application scope, not a universal DG39 failure theorem. The source calls for mechanism investigation beyond its threshold. This retained gate also leaves physical moment-side compression |M|/z−max(N,0)/2≥|M|/(2z)>0, so N alone does not swap the shear group or invalidate its compression pivot. A zero compression-flange force at added axial moment=|M| is outside this scope.

For each complete case:

tp,req=√[1.10 Meq max(γa1,1/0.90)/(fyp Yp)];
tcf,req=√[1.10 Meq max(γa1,1/0.90)/(fyc Yc)].

γa1=1.10. These must pass without an approval tolerance. They preserve the NBR capacity requirement and the guide's explicit demand-thickness criterion. Both must qualify before bolt tension is labeled without prying at demand. Plate yielding MRd=fyp tp²Yp/γa1 may be retained in detailed output but is mathematically implied by the governing thick criterion and should not be another redundant summary alarm.

Nominal diagnostic, Eq3-18/19 p.34/PDF44:

Mpl=fyp tp²Yp; Mcf=fyc tcf²Yc; Mnp=Pt H.
Check independently Mpl≥1.10Mnp and Mcf≥1.10Mnp.

Pt=Fnt Ab is nominal, never Ft,Rd with another reduction. Keep the published DG39 Fnt by source bolt group separate from the NBR-derived nominal Pt,NBR=0.75 fub Ab. Group120 Fnt=90 ksi=620.528156 MPa differs from 0.75×830=622.5 MPa; Group150 Fnt=113ksi=779.107574MPa differs from0.75×1040=780MPa. The oracle reports both its NBR-derived nominal reference and the literal DG39 source-group reference; the book reproduction uses exactly90ksi. A small numerical difference is not a reason to call these identical. No φ is to be applied twice; do not convert all AISC resistances with one blanket factor.

The 45 kN minimum is a second complete load case: f=max(1,45000/hypot(N,V)); scale N and V by f; preserve M. Keep actual case results when the minimum case leaves the declared axial domain. Do not create a fictitious force direction for pure moment. The new branch inherits existing pure-moment handling.

## 4. NBR force-path contract

NBR 8800:2024 corrected2025: γa1=1.10, γa2=1.35, E=200000 MPa. These are existing verified mechanisms, not AISC resistances imported from the source component examples.

### Bolts, bearing and blocks

Ft,Rd=0.75 fub Ab/γa2; Fv,Rd=kgrip α fub Ab/γa2, α=0.45 with threads or0.56 without, kgrip=max(0,1−0.01max(tp+tcf−5db,0)/1.5). Use the currently supported bolt diameter identity exactly. NBR hole diameter dh and net deduction dn remain separate; do not import the example's AISC additional 1/16 in deduction.

V transfers through six compressed-side bolts. Each has |V|/6 and zero model tension; the other six have Tb and zero model shear. Keep per-bolt NBR interaction available, η=(Tb/Ft,Rd)²+(Vb/Fv,Rd)². This route does not claim twelve shear-resisting paths. If later an all-twelve route is offered, qualify it independently including interaction, prying applicability and every plate path.

For each assigned shear bolt, bearing/tearout in each receiving piece is R=min(1.2lc t fu,2.4db t fu)/γa2. lc follows the actual force direction and physical next hole/free edge. The bolt reaction on the end plate and transmitted force on the column have opposite signs. A continuous column has no fictitious longitudinal edge at the plate's outline. Under ±V and ±M, recompute which paths are loaded. As a conservative baseline, the app's minimum-ligament capacity may be used for all loaded bolts, but preserve that choice explicitly.

Plate-block candidates use every physical hole, even those assigned no shear. For both side strips ending at a physical top/bottom edge:
Agv=lv tp; Anv=[lv−(j−0.5)dn]tp; Ant=[(bp−g−dn)/2]tp;
Rblock=2min(0.6fu Anv+0.5fu Ant,0.6fy Agv+0.5fu Ant)/γa2.
Demand is the sum of assigned shear forces inside the candidate, not j/6 of total V unless all those rows are actually loaded. The qualification oracle retains a conservative two-end candidate envelope and every candidate's hole count, loaded count and areas. Do not add a fake longitudinal block path in the continuous column; any different free-edge topology is outside A-4(a).

### Local extension, beam and CJP transfer

Extension demand=Ff/3, never V/3 or 2Tb substituted without qualification. Ag=bp tp, An=(bp−2dn)tp; compare against0.6fyp Ag/γa1 and0.6fup An/γa2.

Web local tension=2Ff/3. lwt=pfi+pb+152.4; hw=d−2tf; lws=min(hw−lwt,hw/2). These are real, disjoint local tension/shear regions for that moment sign; do not subtract both alternative tension regions at once. Require positive lws when V≠0, and no resistance attributed to web absent from the physical beam.

- Beam local web yield: fyb tw lwt/γa1.
- CJP web tension demand=max(2Ff/3,0.60fyb tw lwt); capacity=min(fyb,fyp)min(tw,tp)lwt/γa1.
- CJP web shear demand=|V|; capacity=0.60min(fyb,fyp)min(tw,tp)lws/γa1.
- CJP flange demand=max(Ff,Fc,0.60fyb bf tf); capacity=min(fyb,fyp)min(bf,bp)min(tf,tp)/γa1.
- Axial is inside Ff/Fc, never added to the development floor.
- Retain beam-web shear with Cv and the gross-section elastic equivalent-stress check as distinct global-section checks. Neither replaces local transfer.

CJP requires compatible consumable/procedure/preparation, full connected width and relevant product/strength hierarchy. fw≥fu alone is not a complete compatibility declaration. No new fillet route or welded column reinforcement is implied. Source: §3.7.5 p.44–45/PDF54–55; Example5.3-3 pp.155–159/PDF165–169.

### Column and panel

Corrected Ff/Fc demands are mandatory:
- Web yielding demand=max(Ff,Fc); conservative capacity1.10(2.5tcf+ln)fyc twc/γa1 with ln=0.
- Web crippling demand=Fc; conservative capacity0.33twc²√(E fyc tfc/twc)/γa1.
- Contact demand=C; capacity=min(fyp,fyc)bf tf/γa1.
- Panel demand=|M|/z+|N|/2 under one-beam declared scope; no favorable column-shear deduction. Capacity0.60fyc hc twc Cv/γa1, retaining web instability through Cv and no flange gain.

The source's paired-opposite-flange compression-buckling mechanism is not automatically applicable to the one-sided joint; do not add it as a redundant failure. General panel Eq3-34: Rr=Mr1/(d1−tf1)+Mr2/(d2−tf2)−Vrc−(Pr1+Pr2)/2. Knee Eq3-35: Rr=Mr/(d−tf)−Pr/2. Source Fig3-15 gives Pr1 tension on the left beam, Pr2 compression on the right beam, and knee Pr compression. These source Pr signs are not a uniform tension-positive input convention. Map force diagrams before substituting; column axial force in the panel resistance is yet another quantity. The bounded conservative app formula does not replace general joint equilibrium. NBR capacities are unchanged from0.9.40. Source: §3.7.3 pp.40–43/PDF50–53; §3.7.6 pp.46–48/PDF56–58. The 0.9.40 correction supplies direct NBR source qualification.

## 5. Independent numerical evidence

`independent_mre12_witness.py` is a standard-library oracle, never importing the app. `INDEPENDENT_WITNESSES.json` contains full per-case quantities, per-bolt paths and all block candidates. Literal catalog dimensions were copied read-only and are disclosed; this does not verify current supplier availability or manufacturing tolerances.

Positive complete local numeric witness: W610×125 (d612,bf229,tw11.9,tf19.6,hclear541) and CS600×377 (d600,bf600,tw19,tfc31.5,hclear537), A572Gr50 all members, plate bp250,tp25.4, g150,pfo=pfi50,pb90,de40, A3253/4in. M=180kN·m,N=20kN,V=60kN. No reinforcement and no pfi saturation in the base case.

- Rows=[−50,69.6,159.6,452.4,542.4,662] mm. Central spacing292.8 mm stays below the inherited300mm maximum. A seemingly harmless pb80 would give312.8mm and fail that detail; the witness does not conceal it.
- h=[652.2,532.6,442.6] mm; H3254.8mm; Yp5084.474952687602mm; Yc4602.769512844260mm.
- Meq185.924kN·m; Tb57.123018kN; T342.738110kN; C322.738110kN.
- Ff313.848751kN; Fc303.848751kN; V/6=10kN per compressed-side bolt. Web209.232501kN and extension104.616250kN.
- NBR-derived nominal Mnp577.488718kN·m; Mpl1131.703452kN·m; Mcf1575.648827kN·m. NBR-derived ratios1.95969794 and2.72844954 exceed1.10. Exact DG39 Group120 Mnp575.659453kN·m instead gives ratios1.96592524 and2.73711969, also exceeding1.10. Both demand thicknesses pass.
- lwt292.4mm; lws280.4mm. Largest base numeric utilization0.6600 from CJP development floors; column-web yield0.607991. These are arithmetic local checks, not application GO or project approval.

Twenty-two numeric cases cover both M and V signs, N tension/compression/zero, separate actual and45kN-minimum cases, and pfi110>sP with unchanged physical coordinates. Additional negative controls retain passing demand thickness but fail plate or column nominal classification, and demonstrate an actual-domain pass becoming a minimum-domain failure. The script reproduces the source book's exact Yp/Mnp/Mpl without intermediate rounding and checks unit invariance. Counts and review results are recorded in `QUALIFICATION_RESULT.json` after the review.

## 6. Required production tests and integration seams

This qualification authorizes no production change by itself. A future isolated implementation should use these precise acceptance targets:

1. Pure independent geometry/Yp/Yc kernels: book reproduction, SI positive, pfi saturation at/below/above sP, no pfo saturation, nonzero pb, distinct plate/column widths; sign-reflected physical arms and groups.
2. Twelve bolts/six tension-active; reject top-only, extra-row and crossed-row geometry as unsupported rather than silently convert/sort. Regression proves arbitrary 4E intermediate rows still gain no MRE credit.
3. Complete ±M/±N/±V and actual/minimum cases with per-bolt paths, matching independent fixtures and Ff/Fc/T/C separately. Keep the source's axial caution distinct from resistance failure.
4. Demand-thick versus nominal classification: published demand-pass/nominal-fail; independent nominal pass for both; individual plate/column nominal failures; exact one-ULP thickness boundaries; no reduced bolt strength in nominal classification.
5. V/6 compressed group, opposite-force directions on the two pieces, unequal edge/interior bearing, threads/grip effects, plate block subsets with unloaded but deducted holes; every path’s action/capacity/case retained.
6. Web2/3 and extension1/3, lwt/lws, zero/negative available shear region, independent CJP base materials, floor versus axial placement, local and gross checks distinguished.
7. Column capacities unchanged, correct flange-force demands, single-beam panel boundaries/Cv; no unsupported cap/continuity credit or paired-compression check.
8. Input/import/export identity requires MRE variant and pb; old4E/4ES/8ES digests and semantics unchanged. Current connection_inputs strips pb on every non-8ES route and must be extended explicitly. Cached results never approve imported data; recalculate with method revision.
9. UI, SVG/PNG and compact/detailed Word show twelve actual holes, correct active three rows and three arms, no stiffeners, real plate height, correct source tables and separate classifications. Changing active MRE data invalidates old artifacts. No fake nominal “sem prying” label.
10. Focused regressions preserve corrected4E column demands and existing4ES/8ES/PINNED behavior. Run the full current aggregate only once a production revision is actually ready; this method-qualification task runs no new full aggregate.

Source seams in0.9.40: lro/end_plate.py geometry271–366; source validation570–724; mechanics727–919; connection_inputs922–925; complete-case envelope1001–1037. UI/report/drawing require explicit branch handling rather than treating “not8ES” as4E. The independent read-only review accompanies this contract.

## 7. Known limits and honest completion boundary

Not qualified here: MRE1/3; column A-4(b–e); thin/intermediate prying-capacity design; axial-dominant contact migration; asymmetry; skew; narrow partial flange connection; seismic/cyclic qualification; reinforcement design; arbitrary extra rows; fabrication or global frame rigidity.

N≠0 and pfi>s are **not** left as artificial exclusions: this task supplies their formula-based witness within the bounded method. This is different from supporting arbitrary axial-dominant loading or another column topology. An inaccessible future erratum, supplier section confirmation or a future UI test must not be represented as already verified. The existing DG39 reader visually confirmed the final shear, axial, panel, width, saturation and Group150 questions on2026-10-13UTC. This removes the targeted source blockers for the stated contract. Independent audit still does not constitute production integration or an executed UI/artifact test.
