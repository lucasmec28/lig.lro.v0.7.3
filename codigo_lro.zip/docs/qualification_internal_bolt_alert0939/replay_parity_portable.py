"""Read-only, deterministic parity checks against the immutable 0938 baseline.
Writes no files in either source tree. Run from any working directory.
"""
import json
import os
from pathlib import Path
import subprocess
import sys

if not os.environ.get('LRO_BASE_SOURCE'):
    raise SystemExit('Set LRO_BASE_SOURCE to the extracted immutable 0.9.38 source. No baseline is downloaded.')
BASELINE=Path(os.environ['LRO_BASE_SOURCE']).resolve()
DRAFT=Path(os.environ.get('LRO_SOURCE',Path(__file__).resolve().parents[2])).resolve()


def run(source, internal):
    program = r'''
import json, random
from dataclasses import asdict, replace
from lro.double_cover import presets, strength
b=next(iter(presets().values()))
rng=random.Random(27334)
internal=INTERNAL
out=[]
keep={'dc_bolt_fin','dc_bolt_beam','dc_bearing_beam','dc_block_beam','dc_bearing_cover','dc_block_cover','dc_yield_cover','dc_net_cover','dc_stability_cover','dc_yield_beam','dc_net_beam','dc_stability_beam'}
for _ in range(100 if internal else 300):
    c=replace(b,extension=rng.uniform(0,30) if internal else rng.uniform(61,220),N=rng.uniform(-1e6,1e6),V=rng.uniform(-1e6,1e6),fin_t=rng.uniform(4,20),cover_t=rng.uniform(4,18),gap=rng.uniform(1,35),edge_x=rng.uniform(35,45) if internal else rng.uniform(25,45),n=rng.randint(2,5),pitch=rng.uniform(55,90),edge_v=rng.uniform(30,65),root_height=rng.uniform(250,600))
    rows,actions=strength(c,c.V,c.N,'review')
    if internal: rows=[r for r in rows if r.id in keep]
    out.append({'rows':[asdict(r) for r in rows],'actions':actions})
print(json.dumps(out,sort_keys=True))
'''.replace('internal=INTERNAL', 'internal='+repr(internal))
    env=dict(os.environ, PYTHONPATH=str(source), PYTHONDONTWRITEBYTECODE='1')
    result=subprocess.run([sys.executable, '-c', program],env=env,cwd=source,check=True,capture_output=True,text=True)
    return json.loads(result.stdout)

results={}
for internal,name,n in [(False,'external_full_strength_rows',300),(True,'internal_retained_strength_rows',100)]:
    old,new=run(BASELINE,internal),run(DRAFT,internal)
    equal=old==new
    results[name]={'cases':n,'exact_all_fields_and_actions_match':equal,'rows_per_case':len(new[0]['rows'])}
    assert equal,name
print(json.dumps(results,indent=2))
