"""Read-only probes of the frozen alert/domain correction, not fin qualification."""
from dataclasses import replace
from io import BytesIO
import json
import os
import math
from pathlib import Path
import random
import sys

SOURCE=Path(os.environ.get('LRO_SOURCE',Path(__file__).resolve().parents[2])).resolve()
sys.path.insert(0,str(SOURCE))
from lro.double_cover import presets,evaluate,geometry
from lro.double_cover_report import create_report
from docx import Document
BASE=next(iter(presets().values()))


def horizontal_flag(c):
    return any(i.origin=='tool_envelope' and 'horizontais' in i.text for i in geometry(c)[0])

# The two review counterexamples.
r=evaluate(replace(BASE,extension=46.2,tool_radius=.1))
assert r.geometry['assembly_access']=='unverified'
assert any(i.origin=='assembly_access' for i in r.issues)
assert not horizontal_flag(replace(BASE,extension=80.,root_height=240.,clearance=0.,tool_radius=50.))
assert horizontal_flag(replace(BASE,extension=0.,tool_radius=120.))

# Finite slabs: bolts entirely beyond the slab need not hit it.
assert not horizontal_flag(replace(BASE,extension=0.,n=2,pitch=140.,root_height=40.,tool_radius=18.))
# All centers: intermediate bolts may hit although the extreme bolts clear.
assert horizontal_flag(replace(BASE,extension=0.,n=4,pitch=70.,root_height=80.,tool_radius=18.))

# Independent clamped closest-point calculation against the stated conservative
# rectangles, for both horizontal levels and all bolt centers.
rng=random.Random(93193)
for _ in range(500):
    c=replace(BASE,extension=rng.uniform(0,200),root_height=rng.uniform(30,600),n=rng.randint(2,8),pitch=rng.uniform(52,110),tool_radius=rng.uniform(.1,140))
    low=c.root_height/2-c.weld_fin_stiffener
    high=c.root_height/2+c.stiffener_t+c.weld_stiffener_column
    rectangles=[(0.,c.projection+c.weld_stiffener_column,low,high),(0.,c.projection+c.weld_stiffener_column,-high,-low)]
    expected=False
    for i in range(c.n):
        x=c.fin_group_x;z=(i-(c.n-1)/2)*c.pitch
        for xmin,xmax,zmin,zmax in rectangles:
            closest_x=min(xmax,max(xmin,x));closest_z=min(zmax,max(zmin,z))
            if math.dist((x,z),(closest_x,closest_z))<c.tool_radius:expected=True
    assert horizontal_flag(c)==expected,(c,expected)

c=replace(BASE,extension=0.)
r=evaluate(c)
assert r.status=='REVISAR CONDIÇÕES DE APLICAÇÃO' and len(r.checks)==13
assert not any(i.origin in ('material_collision','tool_envelope','weld_envelope') for i in r.issues)
doc=Document(BytesIO(create_report(c,r)))
text='\n'.join(p.text for p in doc.paragraphs)
assert 'K=2 na faixa da alma da viga.' in text
assert 'K=2 nas faixas da nervura e da alma da viga.' not in text
assert 'A resistência dos horizontais, soldas e receptores desta nervura perfurada não está qualificada.' in text
assert 'não está abrangida pela verificação de H no plano' not in text
print(json.dumps({'review_counterexamples':'pass','true_tool_collision':'pass','finite_slab_clearance':'pass','all_bolt_centers':'pass','independent_random_envelope_cases':500,'u0_pending_and_13_rows':'pass','conditioned_internal_report_text':'pass'},indent=2))
