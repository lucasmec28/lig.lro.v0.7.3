# Lig18 integration into 0.9.39

The reviewed patch was manually integrated over the immutable 0.9.38 source. Presentation-only conflict resolution retains display_precision helpers, two-decimal zero-extension SVG text and the previously reviewed conditional method wording. No alternative fin method was added.

The combined-source replay preserves all fields/actions in 300 external cases (29 checks each) and all 12 retained checks in 100 internal cases. The independent 500-case physical tool-envelope replay and its explicit counterexamples also pass. Original draft qualification remains separately identified; the final combined aggregate is recorded in ../VALIDATION0939.json.

Portable commands from the source root, with required Python dependencies already available:

    LRO_BASE_SOURCE=/path/to/extracted/source0938 python docs/qualification_internal_bolt_alert0939/replay_parity_portable.py
    python docs/qualification_internal_bolt_alert0939/replay_geometry_portable.py

LRO_SOURCE may select a different candidate root. These scripts do not edit either source and do not install or download dependencies. The parity baseline is the preserved previous release, not a generated approval oracle.
