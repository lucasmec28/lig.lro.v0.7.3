# Lig18 / duas talas: ocupação interna não é colisão

Rascunho delimitado, 12/10/2026. Base imutável: `review0937/source0937`. Nenhuma integração, publicação ou alteração de 0.9.37/0.9.38 foi realizada. A revisão 0.9.38 tem mudanças próprias de precisão de apresentação: este patch deve ser mesclado, não copiado por cima dela.

## Resultado

A posição da primeira coluna de parafusos no vão entre as mesas da coluna é uma geometria prevista. O aplicativo confundia o retângulo exterior da coluna com aço maciço, exigindo que a tala e a ferramenta ficassem para fora da ponta da mesa. Essa exigência foi removida no rascunho. Continuam separados:

1. Colisão com material conhecido da alma/mesas, filetes e envelopes informados.
2. Acesso axial de montagem ainda não verificado porque cabeça, porca, ponta de parafuso e profundidade da ferramenta não estão definidos.
3. Qualificação resistente pendente da nervura interna perfurada.

O rascunho aceita u = 0 (nervura rente) e u = 10 mm. Nenhum desses valores concede aprovação estrutural ou de fabricação.

## Evidência da imagem

Imagem recebida `libfile_4b7696c3bed0819192d2823f51787ac1`, versão 0; materializada pela Library e pixels efetivamente inspecionados. Mostra versão 0.9.37, ligação “Alma de coluna · duas talas”, três linhas por grupo, u = 10, e = 40, g = 10, p = 70, H = 353, h = 220 e L da tala = 170 mm. O grupo da nervura está desenhado no vão entre mesas.

Alertas visíveis, provenientes de `double_cover.geometry()`:

- `extension < 2*edge_x + clearance`: “A tala invade a coluna: adote u ≥ 2e + folga de montagem.”
- `extension - edge_x < tool_radius + weld_stiffener_column`: “Grupo na nervura sem acesso para porca/ferramenta junto à mesa da coluna.”

Esses testes usavam somente distâncias até a ponta da mesa; nenhum verificava a interseção com o aço da coluna. A captura não mostra os valores completos dos esforços, portanto os fixtures anexos reproduzem a geometria do preset com u alterado, não pretendem reconstruir a solicitação completa da imagem.

## Coordenadas e detecção

O croqui existente já usa a geometria correta: x = 0 na face frontal da alma; b = (bf − tw)/2 na ponta da mesa; xg = b + u − e no grupo da nervura; início da tala xs = b + u − 2e. A região interna entre mesas está vazia, exceto pelas chapas efetivas.

Para o preset HP250 com u = 10: b = 122,75; xg = 92,75; xs = 52,75 mm. A face interna de cada mesa está em y = ±112,30 mm, e a face exterior do pacote talas/peça central está em y = ±11,90625 mm. A mera posição xg < b não representa colisão material.

O rascunho testa:

- xs < 0: tala intercepta a alma.
- Pacote talas/calços alcançando as mesas, somente onde há superposição em x.
- Haste xg − db/2 < 0: interseção com a alma.
- Furo xg − dh/2 < 0: furo fora da nervura, erro geométrico.
- Envelope radial da ferramenta contra a alma e envelopes conservadores finitos de horizontais/filetes. Usa distância ponto–retângulo, não simples sobreposição das caixas x/z.
- Folga lateral informada e verificações anteriores de altura, concordâncias, alívios e filetes.

A presença do furo na região interna é detectada pelo contorno físico do furo: xg − dh/2 < b. Isso inclui a transição entre nervura interna e aba externa, mesmo quando o centro do furo já está além de b. Acesso interno nunca é considerado verificado por diminuir o raio de ferramenta. As dimensões axiais de cabeça/porca/ferramenta não são inferidas desse raio.

## Fronteira resistente

A correção do alerta não qualifica uma chapa finita perfurada. No ramo interno ficam 12 verificações existentes de parafusos, talas e alma da viga, numericamente preservadas, mais um teto necessário de contato da nervura. Ficam excluídas do quadro conclusivo as antigas faixas da nervura (aba livre e trecho interno sem furos), seu bloco e verificações de transferência para horizontais, soldas e receptores que dependem desse modelo.

O teto da nervura usa a parcela 2,4 db t fu / γa2, já adotada no ramo com deformação limitada desta família, com o fator de calços aplicável. Uma força acima desse teto demonstra não atendimento. Um valor abaixo aparece como “Limite necessário não excedido”, jamais como qualificação de contato/rasgamento ou da nervura completa. A espessura da nervura não é duplicada pela existência de duas talas.

As ações globais do caminho declarado permanecem disponíveis como equilíbrio, com aviso explícito de que não demonstram a repartição local. Não foi proposto um novo modelo de chapa ou exigida FEA. Permanecem pendentes o fluxo pelas faixas de furos, ligamentos laterais e pontes compartilhadas, os apoios/receptores e as qualificações anteriores de estabilidade/rotação. Falhas finitas dos mecanismos retidos e não conformidades de detalhamento continuam visíveis e prioritárias.

## Arquivos alterados

- `lro/double_cover.py`: diagnósticos geométricos, u não negativo, domínio resistente interno e teto necessário.
- `lro/double_cover_ui.py`: u = 0 no controle/importador; textos de geometria e escopo.
- `lro/double_cover_drawing.py`: cota u = 0, grupo interno/transição e aviso de alcance.
- `lro/double_cover_report.py`: escopo, equação do teto necessário e remoção de afirmações de verificações internas não apresentadas.
- `tests/test_double_cover.py`: retirada de uma expectativa obsoleta que exigia o falso alerta para u = 70.
- Dois testes novos: casos finitos de geometria/domínio/paridade e importação real/UI/memória/navegação.

`internal_bolt_alert.patch` contém somente essas mudanças contra 0.9.37. `source/` é cópia isolada de trabalho, não fonte pronta para substituir uma versão posterior.

## Conferências e integração

A revisão independente está em `independent_review/REVIEW.md`, com script e resultados reproduzíveis. Conferiu paridade exata dos 29 resultados de 300 casos externos e dos 12 resultados retidos de 100 casos internos. Encontrou e fez corrigir dois casos de fronteira: raio minúsculo não pode declarar acesso externo e uma ferramenta circular pode passar por um canto mesmo com caixas de contorno superpostas.

O teste herdado que exigia “invade a coluna” falhou na primeira rodada pela alteração intencional. Seu registro foi preservado; a expectativa foi substituída pelos novos testes de colisão real. Os registros exploratórios não são somados à contagem final. A execução final contra os bytes congelados passou 150 testes, sem falhas, erros ou pulados, em 160,27 s. Os hashes permaneceram estáveis e idênticos aos revisados. Resultados: `VALIDATION.json` e `DRAFT_FREEZE.sha256`. O croqui de u = 0 foi inspecionado visualmente; a memória Word teve conteúdo/equações/escopo conferidos, sem revisão visual de todas as páginas. A suíte integral de todas as famílias não foi executada para este rascunho delimitado.

Antes de integração: mesclar sobre a fonte escolhida após o congelamento atual; manter a precisão de apresentação da 0.9.38; repetir a suíte focada contra os bytes mesclados e as verificações gerais de versão/empacotamento que o responsável exigir. Não aplicar somente a remoção dos avisos sem a distinção de domínio resistente, nem transportar o ramo interno sem seus testes. Este rascunho não implementa campos novos para concluir acesso de montagem e não qualifica a ligação completa.
