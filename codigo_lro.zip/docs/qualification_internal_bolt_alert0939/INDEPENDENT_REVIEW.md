# Independent review: internal two-cover bolt alert draft

Reviewed scope: `source/lro/double_cover*.py` compared with immutable `review0937/source0937`. This is a bounded geometry-alert and calculation-domain review. It does not qualify the perforated fin, axial installation access, or the complete connection and does not approve production integration.

## Final finding

No remaining blocking issue was identified in the final frozen source recorded by `DRAFT_FREEZE.sha256`. Both blocking findings and the two minor report-wording notes have been corrected and independently rechecked. No source files in the draft or baseline were edited by this reviewer.

### Corrections found and verified

1. Internal axial-access pending was controlled only by the freely editable tool radius. The reproducible case `extension=46.2, tool_radius=0.1` had an internal hole but incorrectly reported `assembly_access='legacy_external'`. Final `double_cover.py:291` includes `internal_fin_perforation` independently, and this case now reports unverified access with an explicit pending issue.
2. The tool/horizontal test treated overlapping x/z bounding boxes as a circular-envelope collision. The reproducible case `extension=80, root_height=240, clearance=0, tool_radius=50` cleared even the conservative inflated corner by 56.400 mm but was flagged. Final `double_cover.py:297-306` uses the minimum point-to-rectangle distance for all bolt centers and both finite conservative horizontal/filet rectangles. The false flag is gone, while the internal `tool_radius=120` case retains web and horizontal tool-envelope collision warnings.

## Geometry and safety observations

- The origin, projection, cover start, fin-group coordinates and flange clear span are consistent with the drawing: the front column-web face is x=0, and the open region between column flanges is not solid steel.
- `u=0` and the screenshot's `u=10` are supported positions; they retain internal-fin and assembly-access pending notices.
- Actual web/cover/shaft and flange/pack interference branches remain present. The horizontal/filet radial test is explicitly a conservative envelope rather than a representation of every weld contour.
- Internal cases retain the 12 existing bolt/cover/beam rows and add one necessary fin-bearing ceiling. Invalid legacy solid-root/fin/transfer rows are excluded. Finite failures in the retained checks still take precedence over pending qualifications.
- A ceiling below unity is labeled only as a necessary limit not exceeded, rather than a complete fin approval. The drawing, UI and report retain the incomplete-domain warning.
- Signed support actions remain available as equilibrium under the declared load path; the report expressly states that these do not qualify the internal perforated fin, welds or receivers.
- Report text referring to the legacy horizontal/web weld envelope and horizontal strip has been conditioned, with explicit internal-case exclusions.

## Independent verification

The reproducible `verify_parity.py` uses seed 27334 and fresh Python processes with bytecode writes disabled:

- 300 external cases: all 29 strength rows match immutable 0937 exactly, including every serialized field and support actions.
- 100 internal cases: all 12 retained legacy rows match immutable 0937 exactly, including every serialized field and support actions.
- `verify_geometry.py` re-evaluated the two review regression inputs against the final frozen source, together with a true tool collision and `u=0`.
- Finite-slab and intermediate-bolt probes passed: a bolt beyond the finite slab is not falsely flagged, while an intermediate bolt that intersects is detected even if the extreme bolts clear.
- 500 deterministic randomized tool-envelope cases matched an independent clamped closest-point calculation for all bolt centers and both finite conservative horizontal/filet rectangles.
- Generated internal-report text was checked: K=2 is now attributed only to the beam-web strip, and horizontal/weld/receiver capacity is explicitly unqualified.
- Both immutable baseline and final draft-freeze checksum verification passed for all four reviewed source files. `reviewed_files.sha256` now records that final state.

These checks are not a substitute for the parent's full focused UI/report/regression suite. No new normative mechanics were introduced or qualified by this review.

## Presentation follow-up resolved

The two minor wording notes in `double_cover_report.py:147` and `:151` are now conditioned for internal perforations and have been checked in generated report text. No open review findings remain within this bounded scope.
