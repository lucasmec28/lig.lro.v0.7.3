"""Strict Lig18 SVG replay normalization, including bijective generated hatch-pattern IDs.
Only timestamp and generated defs IDs vary. All element geometry/text/styles stay exact.
"""
import re,xml.etree.ElementTree as ET
from legacy_svg_normalization import normalize_svg
S='{http://www.w3.org/2000/svg}'
def normalize_lig18_svg(data):
 text=data.decode();root=ET.fromstring(data);parent={c:p for p in root.iter() for c in p};seen=[x.get('id') for x in root.iter() if x.get('id')];assert len(seen)==len(set(seen));rows=[]
 for e in root.iter():
  old=e.get('id','')
  if not re.fullmatch(r'h[0-9a-f]{10}',old):continue
  assert e.tag==S+'pattern' and parent[e].tag==S+'defs'
  new='generated-hatch-'+str(len(rows));assert new not in text
  forms=['id="'+old+'"','url(#'+old+')'];counts=[text.count(x) for x in forms]
  assert counts[0]==1 and counts[1]>0 and text.count(old)==sum(counts)
  for f in forms:text=text.replace(f,f.replace(old,new))
  rows.append({'old':old,'normalized':new,'references':counts[1]})
 assert len(rows)==1,'Reviewed Lig18 drawings have exactly one generated hatch definition'
 result=normalize_svg(text.encode());result['hatch_ids']=rows;return result
