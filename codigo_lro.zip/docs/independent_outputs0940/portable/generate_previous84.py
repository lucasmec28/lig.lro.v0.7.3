"""Freshly generate prior 84 selected artifacts, using only explicit current source and bundled inputs.
Not an expected-results generator. Baseline checks are performed separately by review_comparisons.py.
Usage: python -B generate_previous84.py SOURCE OUTPUT --expected-version VERSION
"""
from pathlib import Path
import argparse,sys,json,hashlib,importlib,platform
from dataclasses import asdict
p=argparse.ArgumentParser();p.add_argument('source');p.add_argument('output');p.add_argument('--expected-version',required=True);a=p.parse_args();S=Path(a.source).resolve();O=Path(a.output).resolve();HERE=Path(__file__).resolve().parent
assert not O.is_relative_to(S);sys.path.insert(0,str(S));sys.dont_write_bytecode=True
from lro import models
assert models.VERSION==a.expected_version
sha=lambda b:hashlib.sha256(b).hexdigest()
jb=lambda x:json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False).encode()
def source_hashes():return {str(p.relative_to(S)):sha(p.read_bytes()) for p in sorted(S.rglob('*')) if p.is_file() and (p.suffix=='.py' or p.parent.name=='data') and '__pycache__' not in str(p)}
before=source_hashes();records={}
def write(name,data):
 p=O/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);return {'path':name,'size':len(data),'sha256':sha(data)}
def run(name,route,cls,native,folder):
 m=importlib.import_module('lro.'+route);d=importlib.import_module('lro.'+route+'_drawing');r=importlib.import_module('lro.'+route+'_report');c=getattr(m,cls).from_dict(native);res=getattr(m,'evaluate',getattr(m,'analyze',None))(c);result=asdict(res) if route=='double_cover' else res
 stem=folder+'/'+name;w=folder=='w';files=[write(stem+('.json' if w else '_native.json'),jb(c.to_dict())),write(stem+('_results.json' if w else '_result.json'),jb(result))]
 for fmt in ('png','svg'):files.append(write(stem+'.'+fmt,d.drawing_svg(c).encode() if w and fmt=='svg' else d.image_bytes(c,fmt=fmt)))
 for detailed in (False,True):
  mode='detailed' if detailed else 'concise' if w else 'compact';b=r.create_report(c,res,detailed=detailed) if route=='double_cover' else r.create_report(c,detailed=detailed);files.append(write(stem+'_'+mode+'.docx',b))
 records[name]={'route':route,'files':files,'native_metadata':{k:v for k,v in c.to_dict().items() if k!='connection'},'status':result.get('status'), 'fresh_current_api_generation':True};print(name,flush=True)
expected=json.loads((S/'docs/independent_outer_outputs0939/portable/EXPECTED_ACTIVE_FIXTURES.json').read_text())
for name,e in expected['fixtures'].items():
 route='welded_angle_gusset' if name.startswith('w1_') else 'welded_double_angle_gusset' if name.startswith('w2_') else 'bolted_angle_gusset' if name.startswith(('b1_','b2_')) else 'corner_gusset';cls={'welded_angle_gusset':'WeldedAngleGusset','welded_double_angle_gusset':'WeldedDoubleAngleGusset','bolted_angle_gusset':'BoltedAngleGusset','corner_gusset':'CornerGusset'}[route]
 run(name,route,cls,e['native'],'cap')
for u in (0,10):run('lig18_u'+str(u),'double_cover','DoubleCoverConnection',json.loads((HERE/'inputs'/('lig18_u'+str(u)+'_native.json')).read_text()),'lig18')
for name in ('inner_on','outer_only'):run(name,'w_splice_conventional','WConventional',json.loads((HERE/'inputs'/(name+'.json')).read_text()),'w')
modules={}
for name,m in sorted(sys.modules.items()):
 if name=='lro' or name.startswith('lro.'):
  if getattr(m,'__file__',None):
   p=Path(m.__file__).resolve();assert p.is_relative_to(S);modules[name]={'path':str(p.relative_to(S)),'sha256':sha(p.read_bytes())}
assert source_hashes()==before
receipt={'status':'PASS_FRESH_GENERATION','actual_app_version':models.VERSION,'python':platform.python_version(),'source':str(S),'source_unchanged':True,'module_origins':modules,'groups':records,'artifact_count':sum(len(g['files']) for g in records.values()),'input_provenance':'Cap frozen expected native inputs shipped in current source. Lig18 and W native inputs copied unchanged from the prior selected set, imported and freshly evaluated by current APIs. Original source artifacts and archived receipts never relabeled.'}
write('PRIOR84_GENERATION_PROVENANCE.json',jb(receipt));assert receipt['artifact_count']==84
