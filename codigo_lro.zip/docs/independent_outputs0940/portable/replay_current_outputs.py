"""Read-only corrected0940 final output gate, solely APP-contained inputs and commitments.
Usage: python -B replay_current_outputs.py FOUR_ROOT_APP OUTPUT
Source qualification only: append --source. No baseline or auxiliary ZIP dependency.
"""
from pathlib import Path
import argparse,hashlib,json,os,runpy,sys,subprocess,zipfile
sys.dont_write_bytecode=True
P=argparse.ArgumentParser(description=__doc__);P.add_argument('app');P.add_argument('output');P.add_argument('--source',action='store_true');A=P.parse_args();APP=Path(A.app).resolve();O=Path(A.output).resolve();H=Path(__file__).resolve().parent
assert not O.is_relative_to(APP);O.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();canon=lambda v:sha(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode())
manifest=json.loads((H/'PORTABLE_MANIFEST.json').read_text())
for name,row in manifest['files'].items():assert sha((H/name).read_bytes())==row['sha256'] and (H/name).stat().st_size==row['size'],name
commit=json.loads((H/'EXPECTED_CURRENT_OUTPUTS.json').read_text());runtime=json.loads((H/'RUNTIME_COMMITMENTS.json').read_text());holder=None;root_before=None
if A.source:S=APP;mode='SOURCE_ONLY'
else:
 roots={'app.py','codigo_lro.zip','README.md','requirements.txt'};assert {p.name for p in APP.iterdir() if p.is_file()}==roots
 root_before={k:sha((APP/k).read_bytes()) for k in sorted(roots)};loader=runpy.run_path(str(APP/'app.py'),run_name='independent_current_outputs_loader');assert loader['BUNDLE_NAME']=='codigo_lro.zip';archive=(APP/'codigo_lro.zip').read_bytes();assert sha(archive)==loader['BUNDLE_SHA256'];S,holder=loader['prepare_code'](archive,loader['BUNDLE_SHA256']);S=Path(S).resolve();mode='ACTUAL_FOUR_ROOT_APP_LOADER'
 shipped=S/'docs/independent_outputs0940/portable'
 for name,row in manifest['files'].items():assert sha((shipped/name).read_bytes())==row['sha256'],('shipped replay mismatch',name)
 assert (shipped/'PORTABLE_MANIFEST.json').read_bytes()==(H/'PORTABLE_MANIFEST.json').read_bytes()
def held():return {k:sha((S/k).read_bytes()) for k in runtime['files']}
assert held()==runtime['files'],'Runtime differs from reviewed hold'
native_map=json.loads((H/'APP_NATIVE_RESULT_MAP.json').read_text());assert native_map['file_count']==42
assert (S/'docs/qualification_combined0940/current_examples/APP_NATIVE_RESULT_MAP.json').read_bytes()==(H/'APP_NATIVE_RESULT_MAP.json').read_bytes(),'Shipped current JSON map differs'
for entry in native_map['files']:
 p=S/entry['app_path'];assert p.stat().st_size==entry['size'] and sha(p.read_bytes())==entry['sha256'],('Shipped current native/result mismatch',entry['app_path'])
def run(script,args,log):
 env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONPATH':str(S)+os.pathsep+os.environ.get('PYTHONPATH',''),'MPLCONFIGDIR':str(O/'mpl'),'XDG_CACHE_HOME':str(O/'cache')}
 with (O/log).open('w') as stream:r=subprocess.run([sys.executable,'-B',str(script),*map(str,args)],cwd=O,env=env,stdout=stream,stderr=subprocess.STDOUT)
 assert r.returncode==0,(script,log,r.returncode)
run(H/'generate_previous84.py',[S,O/'generated','--expected-version',commit['actual_app_version']],'prior84.log')
run(S/'docs/qualification_4e_column_demands/generate_current_witnesses.py',[S,O/'generated/4e','--expected-version',commit['actual_app_version']],'four_e.log')
sys.path.insert(0,str(H));from legacy_svg_normalization import normalize_svg
from normalize_lig18_svg import normalize_lig18_svg
checked=[]
for name,want in sorted(commit['artifacts'].items()):
 p=O/'generated'/name;b=p.read_bytes();mode2=want['mode']
 if mode2=='canonical_json':got=canon(json.loads(b));assert got==want['sha256'],name
 elif mode2=='zip_members':
  with zipfile.ZipFile(p) as z:got={n:sha(z.read(n)) for n in z.namelist()}
  assert got==want['members'],name
 elif mode2 in ('legacy_svg','lig18_svg'):
  got=(normalize_lig18_svg if mode2=='lig18_svg' else normalize_svg)(b)['sha256'];assert got==want['sha256'],name
 else:got=sha(b);assert got==want['sha256'],name
 checked.append({'path':name,'size':len(b),'sha256':sha(b),'commitment_mode':mode2})
# The source UI/output kit owns its own 56-case count; no historic source is opened.
run(S/'docs/independent_outer_outputs0939/portable/replay_final_outputs.py',[S,O/'output_kit'],'output_kit_driver.log')
kit=json.loads((O/'output_kit/FINAL_REPLAY_PROVENANCE.json').read_text());assert kit['junit_counts']=={'tests':56,'failures':0,'errors':0,'skipped':0} and kit['unchanged'] and not kit['legacy_source_dependency']
assert held()==runtime['files']
if root_before:assert root_before=={k:sha((APP/k).read_bytes()) for k in root_before}
R={'status':'PASS_CURRENT_OUTPUT_GATE','mode':mode,'actual_app_version':commit['actual_app_version'],'root_before':root_before,'runtime_files_verified':len(runtime['files']),'runtime_unchanged':True,'self_contained_ui_output_tests':kit['junit_counts'],'current_artifact_commitments_passed':len(checked),'current_native_results_shipped_verified':42,'artifacts':checked,'manifest_sha256':sha((H/'PORTABLE_MANIFEST.json').read_bytes()),'legacy_source_dependency':False,'auxiliary_examples_dependency':False,'warning':'Source-only mode does not establish actual packaged loader acceptance. Bounded output parity does not certify fabrication or structural design.'}
(O/'CURRENT_OUTPUT_GATE_RECEIPT.json').write_text(json.dumps(R,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in R.items() if k not in ('artifacts','root_before')}))
