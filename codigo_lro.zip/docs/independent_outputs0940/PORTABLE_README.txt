Corrected0940 independent final-output acceptance

Integrator instructions:
1. Copy the portable/ directory verbatim to APP source docs/independent_outputs0940/portable/, excluding caches and bytecode.
2. Keep existing docs/independent_outer_outputs0939/portable/ and docs/qualification_4e_column_demands/generate_current_witnesses.py at their reviewed bytes.
3. Copy the42 mapped current JSONs exactly once into examples/release0940/{cap,lig18,w,4e}/. Preserve APP_NATIVE_RESULT_MAP.json in docs/qualification_combined0940/current_examples/.
4. Keep PNG/SVG/Word/PDF outputs and raw render directories outside APP. The selected optional artifact list is in current_examples_final/SELECTION_MANIFEST.json.
5. After actual packaging, invoke the shipped replay entry:
   python -B replay_current_outputs.py FOUR_ROOT_APP OUTPUT
   OUTPUT must be outside APP. Ordinary installed application/test dependencies are required. Provide writable MPLCONFIGDIR/XDG_CACHE_HOME and PYTHONDONTWRITEBYTECODE=1. In this workspace the dependency environment includes connections_audit/test_dependencies; no old-source code is imported from there.

The entry runs the actual loader, verifies BUNDLE_SHA256, verifies the replay copied from APP, asserts all reviewed runtime/data/UI-proof hashes, verifies42 shipped native/result files, regenerates84 cap/Lig18/W and28 corrected4E artifacts, compares full-precision JSON plus raw PNG, exact uncompressed Word members and strictly normalized SVG, and runs the shipped56-case UI/output kit. No expectation-update mode is exposed.

Source-mode qualification uses the explicit --source option. It is not a package release or actual-loader receipt. This review does not build, upload or deploy a release.

The SVG normalizer accepts only the reviewed generated timestamp and bijective defs IDs. Lig18 additionally has exactly one generated hatch-pattern ID; geometry/styles/text and all references remain strict. Negative controls demonstrate rejection of runtime/native/map mutations and sensitivity to hatch geometry/label changes.

Original0938 source is not used by the replay. Internal0939 remains immutable and undelivered. Historical receipts are retained rather than rewritten. The earlier full replay reached112 artifact matches and56/56 tests but failed the source-inventory guard when the integrator added an unrelated docs replay script. It is retained as a provenance-only interrupted attempt; the final quiet-window source replay is distinct.
