# Validação de 0.9.32

Gate de fonte aprovado após GO numérico e de saída independentes, vinculados aos hashes atuais: 1083 casos pytest distintos passaram, sem falhas ou skips nos relatórios incluídos. Reexecuções sobrepostas não são somadas. As 86 linhas e 33 comparações da qualificação independente prévia não são testes adicionais da implementação.

Nova família de canto no eixo forte: par simétrico 2L-T, duas raízes de gusset, ligação direta viga–pilar, continuidade individual excêntrica e painel do mesmo caso. O seletor tem 19 rotas; as 18 anteriores e os 144 JSON nativos anteriores permanecem preservados. Todos os 933 arquivos da fonte 0.9.31 original continuam com seus hashes congelados. Nenhum motor físico anterior foi alterado; apenas versão, navegação e convenção foram integradas.

Ações completas e assinadas nos cortes da viga e do pilar superior; corte inferior por equilíbrio. Sem repetição da força de diagonal. A geometria e os caminhos são recalculados para as entradas atuais; modos efetivamente não qualificados ficam explícitos. Tração na diagonal não elimina compressão real nos receptores ou na continuidade.

Evidências e limites detalhados: `VALIDATION0932.json`, `ENGINE_ACCEPTANCE0932.json`, `UI_ACCEPTANCE0932.json`, `LEGACY_PARITY0932.json`, `EXAMPLE_ARTIFACTS0932.json` e `EXAMPLE_VISUAL_ACCEPTANCE0932.json`. Todos os caminhos de evidência no registro principal são relativos à raiz da fonte.

A suíte histórica inteira não foi executada. O antigo oráculo externo ausente de contato de parafusos continua uma limitação histórica. Sem aprovação global/fabricação, upload, push ou implantação. As figuras mostram diagonal, cortes D/U/L e J; cargas adicionais avançadas constam das tabelas e do equilíbrio, mas não recebem setas individuais. Extração e smoke do pacote final constituem gate separado.

## Emenda documental do ambiente de reprodução

A reprodução independente exata requer NumPy 2.5.3 em ambiente de auditoria separado. NumPy diferente/ausente é detectado antes da geração, com mensagem de pré-requisito explícita. O hash do JSON independente continua obrigatório e inalterado. Não houve instalação, atualização dos requisitos do aplicativo nem alteração de nenhum dos 134 arquivos de execução aceitos. Os 1.083 testes pytest anteriores permanecem vinculados ao mesmo runtime; não foram reexecutados por esta emenda. A reprodução correta e a rejeição do ambiente incompatível foram verificadas novamente, inclusive por revisão numérica independente a partir de cópia descartável da extração APP. O pacote reconstruído mantém seu gate próprio de extração. Evidências: `independent_engine0932/REPLAY_CONTRACT_AMENDMENT.json` e `REPLAY_CONTRACT_INDEPENDENT.json`.
