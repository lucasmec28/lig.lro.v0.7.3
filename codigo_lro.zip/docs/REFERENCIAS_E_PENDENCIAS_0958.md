# Referências e próximos fechamentos

15/10/2026. Os pontos abaixo são locais da ligação. Não representam pedido para recalcular a estabilidade global das barras dentro do app.

## End plate rotulada de altura total

Há material útil já disponível: Manual Gerdau de Ligações, capítulo 4, LCHE, páginas 65–68, e §12.2.1, páginas 355–359. A rotina LCHE e o exemplo foram reproduzidos separadamente: para o detalhe LCHE20-B, resistência vertical aproximada de 187 kN; a resistência axial de aproximadamente 22 kN corresponde à condição tabulada com V igual à metade dessa resistência vertical (cerca de 93 kN), não a 187 kN simultaneamente. Essa comparação não foi incorporada ao cálculo de geometrias arbitrárias.

Próximo fechamento viável: implementar o domínio geométrico e a posição real dos parafusos do detalhe de referência na família existente. O exemplo usa primeira linha a 75 mm, enquanto a geometria atual centraliza o grupo e resulta em 92,5 mm. Também é necessário representar o local de aplicação do esforço e a interação correspondente. Não basta retirar a mensagem de pendência.

O ASI DG4 §7–8, páginas 9–10, não valida diretamente a configuração com solda nas duas mesas: a Figura 11 exclui solda na mesa inferior. Portanto, não deve ser usada como equivalência direta.

## Duas talas na alma da coluna

A planilha original foi recuperada. Ela ajuda no detalhamento, mas não é um oráculo completo: há diferença entre os diâmetros e quantidades de parafusos do cálculo e do resumo; também há demanda de parafuso por máximo de N e V, que não substitui a resultante simultânea.

O exemplo de Fakury, capítulo 10, §10.14.11, páginas 330–331, é uma chapa simples estendida até a alma da coluna. É uma analogia útil, porém não comprova integralmente a nervura interna perfurada com duas talas e ações N/V.

Falta fechar o caminho da nervura pelos ligamentos até as soldas e os enrijecedores horizontais/receptores, respeitando a primeira coluna de parafusos dentro da coluna. O documento mais útil seria uma solução calculada dessa topologia exata, ou a solução comentada do exemplo de Fakury para desenvolver a correlação com limites explícitos. Não é necessário reenviar a planilha já recebida.

## A1(e): viga contínua sobre chapa no topo da coluna

O ASI DG6, Figura A1(e), página 2, e Figura A4, página 6, identificam o arranjo, mas não fornecem uma solução geral para toda chapa de topo configurável. F/A verifica contato; não substitui flexão, cisalhamento e transferência na chapa.

Roark, 7ª edição, capítulo 11, Tabela 11.4, caso 7, páginas 507–508, foi examinado. A área parcial de carga, a relação de lados e as condições de contorno do caso atual não coincidem com a tabela; não foi extrapolada para declarar aprovação.

Falta selecionar um modelo de placa com apoios reais da coluna e área carregada da viga, compatível com a geometria admitida no app, ou obter um exemplo calculado dessa placa de topo. Não é uma lacuna a resolver por pressão média isolada.

## Apoio direto entre mesas e par inferior

O cálculo local DG6 A1(c)/A3 disponível permanece separado do suplemento NBR. NBR 8800, 5.7.9.2, admite dimensionamento do reforço para o incremento em relação à alma original. Entretanto, a rotina experimental revelou que contato e solda podem atender enquanto a chapa entre o contato e o início da solda não transmite esse incremento. A revisão não incorpora esse protótipo nem atribui ganho resistente ao par.

Próximo fechamento: definir detalhe de transferência local com geometria de recortes e início/continuidade de solda e conferir sua resistência. Não misturar fatores ASI e NBR nem usar aprovação do membro inferior para ocultar falha do superior.

## Viga sobre viga com chapa intermediária

Permanece uma alternativa parcial, distinta do apoio direto entre mesas. Falta a distribuição local fora do plano da chapa e a transferência aos elementos receptores. A solução do apoio direto não deve ser automaticamente aplicada à chapa soldada intermediária.

## Bases e dados de concreto

A interface foi simplificada, mas não há algoritmo de busca de dimensões mínimas de concreto nesta revisão. Embutimento, bordas, espaçamento e dimensões do bloco são acoplados: aumentar o embutimento nominal nem sempre aumenta a resistência ao cone. Propostas de mínimos precisam partir do material e do sistema de ancoragem reais e ser confirmadas pelo responsável pelo concreto.
