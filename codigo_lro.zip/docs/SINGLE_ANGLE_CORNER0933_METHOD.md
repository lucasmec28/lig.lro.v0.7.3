# Cantoneira única no gusset de canto

## Modelo físico e nominal

Uma L laminada de abas iguais, ligada diretamente a uma face da chapa por dois filetes longitudinais iguais. A outra face não contém L nem soldas de diagonal. As duas raízes do gusset continuam duplas, com dois filetes em cada borda apoiada. Viga e pilar têm almas no mesmo plano; a viga encontra a mesa exterior do pilar no eixo forte.

N total atua na única L. As frações do talão e da ponta são 1−ec/b e ec/b, com linhas v=−ec e b−ec. Sua resultante no plano passa pelo ponto de trabalho quando o afastamento é zero. O campo plano completo na chapa comum é idêntico ao antigo par simétrico, pois a soma dos dois meios campos antigos é o novo campo integral. Nenhuma resistência comum é duplicada.

A fonte NBR 8800:2024, 6.1.8.2, permite desprezar o desalinhamento ordinário entre eixo da barra e eixo terminal em ligação estática de cantoneira. O módulo declara a adoção do eixo terminal no plano médio z=0; essa projeção numérica é a implementação de engenharia da exceção, não texto numérico prescrito na norma. A geometria física permanece z_face=±tg/2 e z_CG=±(tg/2+ec). São publicados os momentos espaciais brutos e suas parcelas. Não há cancelamento por L inexistente, nem afirmação de equilíbrio exato tridimensional ou resistência espacial calculada.

O C1 tem tg12 mm, ec22,1 mm, z_CG28,1 mm e N100 kN: momento bruto2,81 kN m, parcelas2,21+0,60. Todos são ordinários do mesmo contato direto e omitidos no modelo nominal declarado. Ações espaciais independentes, espaçadores, deslocamento do plano da chapa, fadiga/sismo e geometrias não ordinárias não fazem parte desse adaptador. Campos nativos adicionais não reconhecidos são recusados; não existe escape de “verificação externa”.

## Resistências e transferência comum

Uma resistência de cantoneira recebe N integral. Escoamento bruto usa Ag do catálogo. Ruptura usa Ct=max(0,5,1−ec/L) e área efetiva. O bloco nominal através da aba conserva Av=tL×L e At=0, com o mínimo das duas expressões NBR6.5.6 dividido por γa2. Não há crédito transversal ou raio inventado. Cada fillet recebe sua tração real; o metal base de cada material usa L×min(s,t_material) e o aço independente correspondente.

O solver comum continua recalculando polígono, Whitmore, seções de corpo, blocos físicos U/L, envelope parcial, duas raízes, receptores, corte completo D/U, corte inferior L derivado, interface J, continuidade excêntrica individual e painel. A tração da diagonal não apaga compressão real em receptores ou chapas de continuidade. Compressão de região do gusset permanece não qualificada. Falha resistente, invalidade física e método ausente são estados diferentes; falha coexistente pode ter status FAIL, mas complete=false bloqueia emissão de aprovação.

## Compatibilidade e evidência

A topologia `single_1L_welded` exige `symmetric=false` e face `positive` ou `negative`. O projeto1L deve registrar a face explicitamente. Em projetos2L, a ausência do campo novo mantém a configuração antiga, com padrão interno positivo sem efeito físico. O adaptador anterior `symmetric_2L_T_welded`, a identidade de rota e as premissas antigas permanecem; o projeto 2L não serializa o campo novo. Importação 0.9.32 é explícita e restrita à topologia antiga. Os desenhos não introduzem um segundo plano de capacidade, e a convenção de sinais continua separada do caso carregado.

As 86 linhas da qualificação são um subconjunto mecânico completo congelado; as verificações adicionais de detalhe do aplicativo são contadas separadamente. Os 352 testes/comparações da qualificação não são adicionados ao número de testes da implementação. Os 9 casos parametrizados e 8 caminhos de chapa vêm das expectativas independentes, sem recalibrar valores após observar o motor.

O replay histórico0.9.32 mantém seu contrato de auditoria NumPy2.5.3 e seus hashes originais intactos. Ele é exclusivo para o runtime0.9.32, não deve ser executado contra0.9.33 e não autoriza ignorar recusa de hash. O runtime atual usa apenas o novo replay em independent_engine0933. A geração exata das expectativas qualificadas1L usa NumPy2.3.5; comparar a implementação sob NumPy2.5.3 usa tolerâncias de engenharia declaradas. Não se altera uma expectativa congelada para forçar igualdade de bytes em outro ambiente.

Consulte `VALIDATION0933.json` para os testes efetivamente executados e aceitação independente. Suíte histórica completa, publicação, implantação, estabilidade global e liberação de fabricação não são afirmadas.
