"""Independent one-root compression arithmetic; no production imports.
Qualification-only, no approval of undocumented real restraint or member stability.
"""
import json, math
from pathlib import Path
P=Path(__file__).resolve().parent
F={
 'candidate_id':'SRC1_existing_2LT_200kN_sign_reversed',
 'source_preset':'2L-T soldada · N total200kN · falha da chapa comum',
 'geometry':dict(B=400.,H=300.,t=10.,theta_deg=75.,center_s=0.,center_n=150.,Lw=200.,end_margin=20.,angle_fillet=5.,root_fillet=5.,introduction_width=150.,support_end_left=1000.,support_end_right=1000.),
 'angle':dict(name='L100x100x12',manufacturer='ArcelorMittal',b=100.,t=12.,Ag=2270.,ec=29.,toe_flat=6.,fy=275.,fu=410.),
 'W':dict(name='W310x165x52',d=317.,bf=167.,tw=7.6,tf=13.2,r=8.,k=21.2,fy=345.,fu=450.),
 'material':dict(gusset_fy=250.,gusset_fu=400.,E=200000.,fw_angle=415.,fw_root=415.,gamma_a1=1.1,gamma_a2=1.35,gamma_w2=1.35),
 'load':dict(N=-200000.,V=0.,M=0.,T=0.),
 'boundary_model':dict(model='DG29_Ex5.4_one_root_sidesway_K1.2',K=1.2,actual_restraint_evidence=None,qualification_only=True,production_status='unverified until real root and brace rotational-restraint detail is identified',receiver_relative_flange_restraint=None,receiver_unbraced_length=None),
}
(P/'FIXTURE_INPUT.json').write_text(json.dumps(F,indent=2,ensure_ascii=False)+'\n')
g,a,w,m=F['geometry'],F['angle'],F['W'],F['material']; N=F['load']['N']; Cn=-N
B,H,t,L=g['B'],g['H'],g['t'],g['Lw']; th=math.radians(g['theta_deg']); c,s=math.cos(th),math.sin(th); cs,cn=g['center_s'],g['center_n']; vc=a['ec']-a['b']/2; u0=-L/2
xy=lambda u,v:[cs+u*c+v*s,cn+u*s-v*c]
spread=L/math.sqrt(3); raw=[-a['b']/2-spread,a['b']/2+spread]
# All inequalities on v, at Whitmore station and at the actual root intercept.
constraints=[('Whitmore_30deg',*raw),('plate_x_at_Whitmore',(-B/2-cs-u0*c)/s,(B/2-cs-u0*c)/s),('actual_connected_root',(-B/2-cs)*s+cn*c,(B/2-cs)*s+cn*c)]
# n(v) = cn+u0*s-v*c; general sign-safe bounds.
if abs(c)>1e-14:
 vals=[(cn+u0*s)/c,(cn+u0*s-H)/c]; constraints.append(('plate_y_at_Whitmore',min(vals),max(vals)))
lo=max(x[1] for x in constraints);hi=min(x[2] for x in constraints);h=min(vc-lo,hi-vc)
assert h>0
vl,vr=vc-h,vc+h;bw=2*h; area=bw*t; I=bw*t**3/12;r=math.sqrt(I/area)
length=lambda v:xy(u0,v)[1]/s
root_x=lambda v:xy(u0,v)[0]-length(v)*c
ls=[length(v) for v in [vl,vc,vr]];Lm=max(ls);K=1.2;Le=K*Lm;Ne=math.pi**2*m['E']*I/Le**2;lam=math.sqrt(area*m['gusset_fy']/Ne);chi=.658**(lam*lam) if lam<=1.5 else .877/(lam*lam);Rc=chi*area*m['gusset_fy']/m['gamma_a1']
checks=[]
def row(name,demand,resistance,**kw):
 assert demand>=0 and resistance>0
 checks.append(dict(id=name,demand=demand,resistance=resistance,utilization=demand/resistance,status='PASS' if demand<=resistance else 'FAIL',**kw))
row('gusset_LOAM_compression',Cn,Rc,scope='conditional on stated K1.2 physical boundary')
row('angle_local_gross_compression_each',Cn/2,a['Ag']*a['fy']/m['gamma_a1'])
row('angle_local_compactness_conservative_full_leg',a['b']/a['t'],.45*math.sqrt(m['E']/a['fy']),unit='ratio')
fh=1-a['ec']/a['b'];ft=1-fh;forces=[]
for face in ['positive','negative']:
 for label,v,f in [('heel',-a['b']/2,fh),('toe',a['b']/2,ft)]:
  force=N*f/2;forces.append(dict(face=face,label=label,force=force,start=xy(-L/2,v),end=xy(L/2,v),centroid=xy(0,v)))
  row('weld_'+label+'_'+face,abs(force),L*g['angle_fillet']/math.sqrt(2)*.6*m['fw_angle']/m['gamma_w2'])
  for part,fy,fu,depth in [('angle',a['fy'],a['fu'],min(g['angle_fillet'],a['toe_flat'])),('gusset',m['gusset_fy'],m['gusset_fu'],min(g['angle_fillet'],t))]:
   row('weld_substrate_'+part+'_'+label+'_'+face,abs(force),min(.6*fy*L*depth/m['gamma_a1'],.6*fu*L*depth/m['gamma_a2']))
row('angle_uniform_run_shear_envelope_each',Cn/2,min(.6*a['fy'],.6*a['fu'])*L*a['toe_flat']/m['gamma_a2'],purpose='direction-independent conservative shear transfer, no free-tip tension block')
row('gusset_uniform_run_shear_envelope_once',Cn,min(.6*m['gusset_fy'],.6*m['gusset_fu'])*L*t/m['gamma_a2'])
# Direct integration of each distributed physical weld load at each horizontal cut.
# Independent construction: remaining active interval on every weld, its centroid,
# and force resultant. Derivative extrema computed from three interpolated samples.
A=B*t;Z=B*B*t/6
ystations=sorted({0.,H,*[q['start'][1] for q in forces],*[q['end'][1] for q in forces]})
def cut(y):
 nr=vr=mr=0.
 for q in forces:
  y0,y1=q['start'][1],q['end'][1]
  if y>=y1:continue
  low=max(y,y0);fraction=(y1-low)/(y1-y0);f=q['force']*fraction
  ym=(low+y1)/2;xm=q['start'][0]+(ym-y0)*c/s
  nr+=f*s;vr+=f*c;mr+=xm*f*s-(ym-y)*f*c
 return dict(y=y,N=nr,V=vr,M=mr,sigma_left=nr/A-mr/Z,sigma_right=nr/A+mr/Z,tau=1.5*vr/A)
intervals=[]
for ya,yb in zip(ystations[:-1],ystations[1:]):
 ym=(ya+yb)/2; half=(yb-ya)/2;left,mid,right=[cut(y) for y in [ya,ym,yb]];pts=[left,right]
 for key in ['sigma_left','sigma_right']:
  qa=(left[key]+right[key]-2*mid[key])/2;qb=(right[key]-left[key])/2
  if abs(qa)>1e-13 and -1<-qb/(2*qa)<1:pts.append(cut(ym+half*(-qb/(2*qa))))
 maxnormal=max(abs(z[k]) for z in pts for k in ['sigma_left','sigma_right']);maxshear=max(abs(left['tau']),abs(right['tau']));
 intervals.append(dict(y=[ya,yb],extrema=pts,maxnormal=maxnormal,maxshear=maxshear,VM=math.hypot(maxnormal,math.sqrt(3)*maxshear)))
normal_values=[z[k] for it in intervals for z in it['extrema'] for k in ['sigma_left','sigma_right']]
row('gusset_body_combined_yield',max(q['VM'] for q in intervals),m['gusset_fy']/m['gamma_a1'],unit='MPa')
bi=g['introduction_width']; Ai=bi*t; Zi=bi*bi*t/6;Mi=N*vc;intro=[N/Ai-Mi/Zi,N/Ai+Mi/Zi]
row('gusset_existing_local_introduction_yield',max(map(abs,intro)),m['gusset_fy']/m['gamma_a1'],unit='MPa')
row('gusset_body_shear_rupture',max(it['maxshear'] for it in intervals),.6*m['gusset_fu']/m['gamma_a2'],unit='MPa')
rt=cut(0);Nr,Vr,Mr=rt['N'],rt['V'],rt['M'];qn=[Nr/B-6*Mr/B**2,Nr/B+6*Mr/B**2];qs=Vr/B;qvec=[math.hypot(q,qs) for q in qn];qd=max(max(qvec),1.25*sum(qvec)/2);qp=max(qvec);np=max(0.,*qn);nc=max(0.,*[-q for q in qn]);Nc_eq=B*nc
assert max(qn)<0
row('root_weld',qd/(math.sqrt(2)*g['root_fillet']),.6*m['fw_root']/m['gamma_w2'],unit='MPa')
for part,fy,fu,depth in [('gusset',m['gusset_fy'],m['gusset_fu'],min(t,2*g['root_fillet'])),('W_contact',w['fy'],w['fu'],2*g['root_fillet'])]:
 row(part+'_root_contact_combined_yield',math.hypot(nc/depth,math.sqrt(3)*qs/depth),fy/m['gamma_a1'],unit='MPa')
 row(part+'_root_contact_shear_rupture',abs(qs)/depth,.6*fu/m['gamma_a2'],unit='MPa')
end=min(g['support_end_left']-B/2,g['support_end_right']-B/2);spreadk=5 if end>w['d'] else 2.5
row('W_web_local_yield',Nc_eq,1.10*w['fy']*w['tw']*(B+spreadk*w['k'])/m['gamma_a1'])
interior=end>=w['d']/2;ratio=B/w['d']; mult=3*ratio if interior or ratio<=.2 else 4*ratio-.2
crip=(.66 if interior else .33)*w['tw']**2*(1+mult*(w['tw']/w['tf'])**1.5)*math.sqrt(m['E']*w['fy']*w['tf']/w['tw'])/m['gamma_a1']
row('W_web_compression_crippling',Nc_eq,crip)
row('W_web_longitudinal_shear',abs(Vr),min(.6*w['fy']*w['tw']*B/m['gamma_a1'],.6*w['fu']*w['tw']*B/m['gamma_a2']))
row('W_web_combined_local_yield',math.hypot(Nc_eq/(w['tw']*B),math.sqrt(3)*1.5*Vr/(w['tw']*B)),w['fy']/m['gamma_a1'],unit='MPa')
row('W_flange_two_surface_shear',qp/(2*w['tf']),min(.6*w['fy']/m['gamma_a1'],.6*w['fu']/m['gamma_a2']),unit='MPa')
# Preserve DG29 published failure, separate exact formula from rounded table values.
lb=6.5;tg=.5;bw_in=2*6*math.tan(math.pi/6);Ag=bw_in*tg;sl=1.2*lb/(tg/math.sqrt(12));Fe=math.pi**2*29000/sl**2;Fcr=.658**(36/Fe)*36;phiPn=.9*Fcr*Ag
O=dict(candidate_id=F['candidate_id'],calculation='standard-library independent arithmetic, no runtime oracle use',
 status='METHOD_FIXTURE_FAIL_AND_REAL_RESTRAINT_UNVERIFIED',
 geometry=dict(whitmore_u=u0,force_axis_v=vc,raw_v=raw,clip_constraints=constraints,clipped_v=[lo,hi],retained_v=[vl,vr],width=bw,area=area,I=I,r=r,three_lengths=ls,length_upper_bound=Lm,K=K,Le=Le,slenderness=Le/r,lambda0=lam,chi=chi,Nc_Rd=Rc,Whitmore_endpoints=[xy(u0,vl),xy(u0,vr)],root_projections=[root_x(vl),root_x(vr)]),
 signed=dict(weld_forces=forces,root_N=Nr,root_V=Vr,root_M=Mr,root_q_normal=qn,root_q_shear=qs,root_q_design=qd,root_compression_equivalent=Nc_eq,root_tension_peak=np,body_normal_extrema=[min(normal_values),max(normal_values)],local_introduction_normal=intro,member_force_and_moment=dict(N_normal=Nr,V_parallel=Vr,M_root=Mr,M_about_W_centroid=Mr-w['d']/2*Vr)),
 body_intervals=intervals,checks=checks,failed=[q for q in checks if q['status']=='FAIL'],
 inactive=['angle net-tension/shear-lag capacity','outward free-tip tension blocks','gusset normal rupture under negative normal stress','root normal tensile rupture under negative traction','W flange local tension bending: qn<0','NBR5.7.6 opposing-flange compression pair: no such pair within defined isolated local case'],
 unresolved=['Actual root/brace rotational-restraint detail for K1.2 is not in the old native input','Actual receiving-W relative flange restraint or NBR5.7.5 inputs are not in old native input'],
 source_benchmark=dict(source='DG29 Ex5.4 printed103–104/PDF111–112',K=1.2,L_in=6.5,t_in=.5,width_in=bw_in,slenderness=sl,Fcr_ksi=Fcr,phiPn_kip_exact_formula=phiPn,published_rounded_capacity_kip=96.5,demand_kip=100.,status='FAIL_PRESERVED_NO_RESIZE'),
 invariants=dict(total_weld_force=sum(q['force'] for q in forces),equilibrium_normal=sum(q['force']*s for q in forces)-Nr,equilibrium_parallel=sum(q['force']*c for q in forces)-Vr,equilibrium_moment=sum(q['centroid'][0]*q['force']*s-q['centroid'][1]*q['force']*c for q in forces)-Mr))
assert math.isclose(sum(q['force'] for q in forces),N);assert O['failed'];assert phiPn<100
(P/'ORACLE.json').write_text(json.dumps(O,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({k:O[k] for k in ['candidate_id','status','geometry','failed','source_benchmark','invariants']},indent=2))
