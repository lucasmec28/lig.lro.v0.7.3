# Validação focal da abertura direta · 0.9.71

Pacote `0.9.71-abertura-direta-catalogo-dev.1`. Componente de cálculo preservado: `0.9.44-beam-on-beam-partial-dev`.

## Defeito reproduzido e correção

O clique exato em **Conferir escopo** no cartão Console da .70 deixava o candidato como Console, mas mantinha o seletor, entradas e resultados de Single plate. A lista também apenas preparava uma escolha. Não se tratava de troca de cálculo ou de geometria: era um fluxo de duas ações que não correspondia à expectativa de abrir a ligação pelo cartão.

A .71 usa abertura direta pela foto e pelo botão principal. O escopo é consultado em painel secundário identificado como informativo. A lista do passo 3 continua explicitamente preparando uma escolha, seguida de **Abrir ligação selecionada**. A abertura recolhe o catálogo e mantém o formulário nativo abaixo; **Voltar ao catálogo** retorna à galeria. Reabrir a família ativa mantém o projeto em andamento.

## Evidência focal na fonte

Foram aprovados **121 casos distintos** nas quatro suítes abaixo. Reexecuções e testes suplementares sobrepostos não são somados novamente. A lista exata de identificadores está em `docs/validation0971/SUMMARY.json`.

- 42 casos de abertura direta: reprodução do botão .70, cliques reais AppTest nos cartões .71 das 26 rotas, seletor e controle nativos, JSON e resultado da família, valores editados preservados, reabertura ativa, retorno Single plate → Console → Single plate, seleção pelo passo 3 e botão superior, rejeição de cliques desatualizados pelos filtros. A reprodução .70 é evidência adicional, fora da contagem de 121.
- 62 casos da foto: execução do JavaScript distribuído em Node VM/DOM mínimo, clique no elemento `img` propagado para seu botão nativo, protocolo JSON real do componente no AppTest nas 26 rotas, eventos inválidos/repetidos/desatualizados, dados de Console editados conservados e os 26 PNG idênticos à .70.
- 13 casos reaplicados de assets/limites: catálogo completo, integridade das imagens, identidade marinho e fronteira da camada de apresentação.
- 4 casos atuais de conservação/importação: upload real de Single plate com geometria e ações não padrão, rejeição atômica de arquivo inválido, Word e desenho nativos, base Tipo 1 legada sem migração silenciosa para Tipo 2 e proteções das duas emendas W contra entradas inválidas. A cópia .71 do teste adapta apenas os rótulos e a preparação de candidato ao fluxo atual; a suíte histórica permanece inalterada.

O primeiro rerun nativo de Single plate normaliza a serialização dos defaults `a=120` e `gap=80` para `120.0` e `80.0`. O mesmo ocorre em um rerun normal sem foto, sem mudança de valor, desenho ou cálculo. A comparação estrita de bytes estabiliza esse rerun antes do snapshot inicial. Essa observação foi registrada, não corrigida no motor.

## Preservação e distribuição

O inventário .70 foi comparado novamente com seu congelamento: todos os arquivos originais permanecem intactos. Na .71, os únicos arquivos preexistentes de execução alterados são `app.py` (guardas/identidade), `lro/package_identity.py`, `lro/catalogue_ui.py` e `verificar_pacote.py`. São novos o componente local `lro/catalogue_image.py` e seu `index.html`. Motores, renderers, formulários nativos, schemas, guia de famílias, tema marinho e as 26 imagens permanecem byte a byte iguais. O seletor direto e todo o corpo do dispatcher/formulário nativo em `app.py` também são idênticos.

O congelamento e o delta da fonte ficam nas evidências de desenvolvimento. Depois dele, a distribuição compacta é gerada e testada separadamente a partir do ZIP extraído em processo novo: 26 aberturas por cartão, seleção exata, retorno e reabertura sem perder projeto, evento JSON da foto, 14 proteções do carregador, salvaguardas W, manifesto, hashes e paridade. O recibo dessa etapa é externo ao ZIP para evitar alterar a distribuição já testada. O resumo interno registra os testes de fonte; não antecipa o resultado da validação posterior do pacote.

## Limites

AppTest testa o fluxo real do Streamlit; Node VM executa o JavaScript real com DOM mínimo. Não foi realizado clique físico, navegação por teclado, verificação responsiva ou captura em navegador. O botão HTML nativo, seu nome acessível e foco visível foram verificados por contrato estático. Não houve contorno da restrição de socket, servidor, publicação, push ou deploy. Esta revisão não requalifica nenhum método estrutural; miniaturas continuam exemplos, e todos os limites técnicos das famílias permanecem aplicáveis.
