# Final caption correction, hold v2

This addendum resolves the last pending caption finding in REVIEW.md. It leaves the original review and its hash receipts unchanged.

The replacement runtime/test/data hold SHA-256 is `0812857731a1ad5539209521641d364523ca0b45cd48dbda001be48c99661db9`. Only `lro/gusset_outer_end_drawing.py` differs from hold v1. All 341 held files matched before and after.

Four rendered-bounding-box no-trim checks pass. All four regenerated actual PNGs were inspected. The new bolted compact Word/PDF page 1 and corner compact Word/PDF page 2 were inspected after rendering; the two-line notice is readable and no longer overlaps theta/centroid, hole, or U-cut labels. Each Word embeds the exact current PNG.

Ten principal active fixtures were regenerated: 10 PNGs are byte-identical; 10 SVGs match after removing only the generated timestamp and bijective generated definition identifiers; all members of the 20 compact/detailed DOCX archives match. Seven mutation checks demonstrate that geometry, style, visible semantic text, semantic IDs, and reference-only changes are not ignored by SVG comparison.

Evidence: caption_hold/CAPTION_DELTA_BINDING.json, caption_hold/no_trim_layout.xml, caption_hold/SVG_NORMALIZER_MUTATION_PROOF.json, caption_hold/render_b2_no_trim_compact/page-1.png and caption_hold/render_cw2_no_trim_compact/page-2.png. The earlier byte-only SVG comparison stopped on permitted generated metadata and is retained as exploratory evidence.

A subsequent welded exact-boundary tolerance correction requires hold v3. This addendum closes the caption/layout finding only and is not final source approval.
