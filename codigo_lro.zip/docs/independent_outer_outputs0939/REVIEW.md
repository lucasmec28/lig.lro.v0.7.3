# Independent outer-gusset output review

12 October 2026. Candidate: `review0939/source0939`. Read-only reviewer; source changes were made only by the integration owner. No upload or release action was taken.

## Status

The 341-file runtime/test/data hold with SHA-256 `5983a2b59c505af9ee307d719a1a99f2a49e8dd0dd939b2dec113640372866d6` passed 43 independent UI/native/drawing/report tests and 25 retained display-precision tests. A final explicit no-trim PNG inspection then found a caption-placement defect. The parent was notified; acceptance remains pending correction and a replacement hold. All active-cut findings below were corrected and independently rechecked before that last finding.

## Reviewed scope

Both actual user reference images, `GEOMETRY_SPEC.md`, and `MECHANICAL_TEST_CONTRACT.md` were read/viewed first. The review covers the first perpendicular outer cut, not the deferred tapered-side sketch, manufacturing approval or a new compression/bearing qualification.

Covered views: welded 1L/2L-T and one-row bolted 1L/2L-T on one root; all four welded/bolted 1L/2L-T corner adapters; one-root 45-, 90- and 135-degree cases; invalid physical gauge, no-trim and mixed-stress states. The two opposed routes remain without these controls.

## Verified behavior

- Actual Streamlit route callbacks, native-file uploads and main-app imports/downloads preserve the exact high-precision cut controls. Unrelated rerenders do not round native values.
- User enablement seeds 35 mm only for a still-zero bolted field with selected diameter 19.05 mm. Other admitted diameters are not seeded. Previously entered gauges remain exact. Loading an already-enabled native zero does not seed it. Welded zero remains zero and invalid when enabled.
- Old 0.9.38 natives were generated in separate baseline processes with bytecode writes disabled. Migration preserves every old connection value exactly and selects original contour with inactive zero gauges.
- Current-input edits recompute result geometry and invalidate prior Word. Injected stale result dictionaries never authorize an old polygon or favorable result.
- Exact evaluated polygon coordinates, full root seams and physical cap/gauge endpoints match the figure artists. Brace continuation extends beyond the plate. Corner roots are read from actual semantic geometry, not polygon index guesses.
- PNG and SVG exports preserve the current cut. For all ten principal fixtures, every compact and detailed Word document embeds the exact PNG bytes exported from the same current input, even when supplied a stale result.
- A real short-weld mixed-stress case preserves OUTSIDE_SCOPE, its compression warning, finite FAIL rows and an unfavorable conclusion in both Word forms. The invalid finite-gauge case retains INVALID_GEOMETRY and does not fabricate a physical dimension.
- No-trim states preserve the original polygon, report that no material is removed and create no fictitious cut edge or gauge. Caption readability is the remaining pre-correction finding.
- The 0.9.38 two-decimal presentation tests pass, including precise raw/native values, tiny nonzero scientific notation and failing utilizations that display as 1.00. Catalog identities and stable numerical path IDs intentionally remain unchanged.

## Findings corrected by the owner

1. Welded one-root domain boilerplate called the active plate rectangular. Both report domains now describe its rectangular base envelope with optional outer normal cut; the bolted AISC-method distinction was clarified too.
2. Welded crop drawings labeled the base height H even when the 90-degree cap reduced actual plate height. They now label H_env when trimmed.
3. New active cap labels obscured the corner axial-force label and the one-root bolted continuation callout. Route-specific offsets correct both; rendered bounding-box guards and PNG review passed.
4. Invalid requested gauges were described as a genuine physical distance. The current description explicitly calls them invalid/nonphysical and does not assert root preservation unconditionally.
5. The SVG physical dimension arrow lacked its artist identity on the child arrow path. It now has the explicit exported GID, while endpoints and physical length remain unchanged.

## Remaining finding at this receipt

The no-trim notice at axes position (.02,.98) overlaps the welded theta/centroid line, the one-root bolted physical-hole line, and the corner upper-cut label. Evidence: `final_hold/w1_no_trim.png`, `b2_no_trim.png`, `cw2_no_trim.png`. Geometry and status are correct. A four-route rendered-box regression is prepared in `portable/test_no_trim_layout.py`.

## Visual review evidence

All 13 active/mirrored/vertical/mixed-stress PNGs in `final_hold/` were viewed. Representative final LibreOffice-rendered pages were inspected after regeneration:

- w1_90 compact: pages 3–4 (8 rendered pages)
- w2_75 compact: pages 4–5 (11 rendered pages)
- b2_80 compact: pages 1 and 3 (9 rendered pages)
- cw2 compact: pages 2–3 (5 rendered pages)
- cb2 detailed: pages 2–3 and 18 (19 rendered pages)
- mixed stress compact: pages 1 and 8 (8 rendered pages)

Earlier equivalent layout pages also checked the report openings, tables and detailed audit material. This is representative visual review, not a claim that every page of all generated detailed reports was visually inspected. No clipping, broken tables, unreadable cap labels or hidden failure states were found in the active-cut final pages.

## Lig18 integrated-fix follow-up

Both u=0 and u=10 PNGs were viewed; compact and detailed Word were generated. Representative rendered pages 1, 2, 7 of the u=0 compact and 1, 3, 7 of u=10 detailed were viewed. The internal-fin qualification and axial assembly-access pending warnings remain prominent. The necessary fin-bearing ceiling is labeled only as a limit not exceeded, not a complete approval. Geometry-alert corrections did not create a new local qualification. All four double-cover source hashes match the initial generated-artifact state and the held source.

## Reproducibility and boundaries

Authoritative 43-test output is in `final_hold/independent_output_replay.xml` and `.log`; `RUNTIME_PROVENANCE.json` records matching source-before/source-after hashes. `hold_verified_before.json` and `hold1_verified_after.json` bind the 341 held runtime/test/data files. Retained precision evidence is `retained_precision.xml`/`.log`. Earlier failed exploratory harness runs remain on disk; incorrect assumed brace GIDs and the nonexistent separate bolted-opposed UI module were corrected in the harness, not production.

The portable directory accepts explicit source, baseline and output paths. `replay_outputs.py` is the original 43-test replay; `replay_outputs_with_no_trim.py` adds the four new layout tests. `verify_caption_delta.py` can bind a bounded drawing-only correction to the prior receipt with exact active PNG/SVG equality and full Word ZIP-member equality, followed by the four no-trim checks. It never modifies source.

Independent mechanical review, full aggregate regression, immutable packaging and a fresh delivered-APP replay are separate gates. This review does not claim release, fabrication or external bearing qualification.
