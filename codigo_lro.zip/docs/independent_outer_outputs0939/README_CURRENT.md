# Final independent output qualification

Read FINAL_UI_TRANSITION_ACCEPTANCE.json first. It binds final hold v4 (341 runtime/test/data files), the contained bolted arrangement callback and the retained output review. The earlier FINAL_OUTPUT_ACCEPTANCE.json and its addenda apply to hold v3; REVIEW.md is the preserved pre-caption receipt. None is silently relabeled as a fresh run.

The bounded review chain comprises the original 43 output tests and 25 retained precision checks; four no-trim caption checks and strict active-artifact parity; the isolated weld termination-boundary correction; and nine final normal/active/atomic-import/rejected-transition callback checks. Ten full result trees and 40 active cap artifacts were regenerated and compared again against their commitments on the final hold. Full production regression is separate.

The 84 selected examples retain their actual v3 generation identity. The independent CURRENT_HOLD_REBIND.json in ../qualification_combined0939/current_examples proves the v4 delta is UI/test-only, with their engine/drawing/report/data dependencies and all selected bytes unchanged. Its APP_NATIVE_RESULT_MAP.json binds the 28 native/result copies shipped in APP.

Portable expected artifacts and independently materialized old-native inputs permit the current self-contained replay without the prior source or optional rendering companions. Follow portable/README.md; the self-contained adapter acceptance states its exact replay coverage. AppTest is not a real-browser pixel or download-click proof. Only named representative Word pages were visually inspected; no all-page human review is claimed.
