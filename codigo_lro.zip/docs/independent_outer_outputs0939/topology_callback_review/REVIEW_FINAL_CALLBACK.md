# Bolted topology callback: final-callback checkpoint review

## Result

No unresolved blocking finding in the reviewed callback fix. The two independently discovered pre-existing rejection boundaries are now contained. Both portable regression tests passed in 22.53 seconds against unchanged UI SHA-256:

51ef7d05dbe6ccfe37cc295afad07c1b73f736fb92522d001a8c5a108729fafd

This is the final-callback checkpoint. Bind it to final hold v4 only if its recorded source hashes match. This reviewer made no source edits and did not run the aggregate suite.

## Review conclusions

- The explicit UI conversion removes only the unsupported bolted cap fields when the target is opposed. It does not add the cap option to the opposed engine or modify its rectangular topology.
- Exact accepted raw values are retained for untouched common controls; successful conversion creates the target's canonical native identity through staged strict serialization.
- Native decoding still chooses a strict parser by connection_type and does not use the UI conversion. The opposed parser requires an exact field set, so even inactive cap fields remain unsupported and rejected.
- change_arrangement now stages conversion before mutation and catches numeric/schema failures. It restores the prior topology selector, retires Word, removes an inapplicable cut-removal notice and displays an explicit failed-transition message. It does not clamp input values.
- The next render withdraws PROJECT/RESULT before recomputation. An invalid common numeric draft remains invalid; no target-family result or prior report is admitted.

Relevant source locations: bolted_angle_gusset_ui.py lines 120–135 (strict decode/staged seed), 138–168 (raw-value reconstruction/explicit conversion), 178–196 (contained callback), 355–372 (fresh render and notices). Opposed native field-set validation remains in BoltedOpposedAngleGusset.from_dict.

## Independent regression coverage

1. Opposed n=51 to 1L: target rejection is handled, selector stays opposed, n remains exactly 51, native/template/accepted/draft retain the current opposed inputs, current opposed results are recomputed, old Word remains unavailable. Correcting n to 3 then permits a deliberate 1L transition with default original/0 cap fields.
2. Overflowing 1e308 kN draft to opposed: selector stays 2L-T, the user's invalid force is retained, status remains NUMERICAL_FAILURE with no project, checks, downloads or Word. Correcting force to 100 kN then permits the opposed transition and produces its evaluated result.

Source hashes before and after matched for the UI, both bolted native models and the cap kernel. Portable test hash:
e44c7d083b79cca1c705ec90d6e3e9c5cc7e146309fac595a951ab262d560c39

The parent separately ran seven normal/active-cut/import/main-app tests on the same UI hash; those are not counted as this reviewer's runs.

## Evidence and replay

- test_callback_boundaries.py: portable focused tests; requires explicit LRO_REVIEW_SOURCE and LRO_REVIEW_OUTPUT.
- final_callback_verified/pytest.log and pytest.xml: successful final focused replay.
- final_callback_verified/callback_boundary_hashes.json: exact before/after source and test hashes.
- preexisting_edges.json and preexisting_edges.log: preserved reproduction of both earlier uncaught callback failures.
- final_callback_checkpoint/: preserved initial test run. n=51 passed; the overflow test reached all safe-rejection assertions but failed an overbroad equality check on a transient report-display preference. Streamlit cleans up bag_report_detailed when invalid rendering omits that checkbox. The final test excludes only that presentation control while requiring all native draft fields to remain exact; no source change was made to satisfy this assertion.

Use the source's documented test dependencies on PYTHONPATH, set PYTHONDONTWRITEBYTECODE=1, and run pytest with -p no:cacheprovider or an output-local cache. Outputs and source paths must be supplied explicitly by the replay caller.
