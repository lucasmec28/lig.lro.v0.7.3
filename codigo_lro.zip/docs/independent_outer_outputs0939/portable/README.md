# Independent outer-cut UI and artifact replay

Run `python -B replay_outputs.py SOURCE_ROOT OUTPUT_DIR --baseline BASE0938` with the already-installed pytest, Streamlit, NumPy, matplotlib and python-docx dependencies. The two roots must be explicit; the output directory must remain outside the source. Omit `--baseline` only when the old native migration input is unavailable; the receipt will then show four skipped migration tests. `--collect-only` checks imports and test collection without exercising the application.

The replay performs real Streamlit main-app/route callbacks, imports/downloads, exact-state and stale-result checks, conditional bolt-gauge seeding, inactive and no-trim checks, opposed-route exclusion, evaluated polygon/root/cap/physical dimension comparisons, embedded PNG equality in compact/detailed Word, 90-degree/mirrored output, mixed-stress disclosure and annotation overlap guards. It writes a complete source-before/source-after hash receipt and never changes source files.

The replay does not render Word with LibreOffice. Human visual QA of PNGs and selected rendered Word/PDF pages is documented in the independent review receipt; reproducing it needs the standard document renderer in addition to these scripts. Full application regression, independent mechanical qualification and final packaged-APP replay remain separate gates.

## Supplementary holds and portable expected artifacts

`replay_outputs_with_no_trim.py` runs the same 43 tests plus four no-trim layout tests. The earlier 43-test receipt remains unchanged. `verify_caption_delta.py SOURCE PRIOR_OUTPUT NEW_OUTPUT HOLD PRIOR_HOLD_RECEIPT` checks a bounded drawing-only delta, ten active fixtures and four no-trim captions. `verify_boundary_delta.py` uses the same arguments but requires exactly the later welded evaluation/test-file delta and also compares the ten full evaluated results. The delta scripts require the principal fixture files from the prior output directory; they accept explicit paths and never infer sibling source paths.

Artifact comparison uses exact PNG bytes, all uncompressed DOCX ZIP-member bytes, and strict SVG equality after only the generated timestamp and generated definition identifiers are normalized bijectively. It does not ignore polygon coordinates, styling, visible text, semantic IDs or redirected references. `validate_legacy_normalizer.py SAMPLE_SVG OUTPUT_JSON` exercises seven positive/negative mutation witnesses.

`EXPECTED_ACTIVE_FIXTURES.json` carries portable native inputs and expected hashes/member hashes for the ten principal fixtures. Its values come from the preserved 43-test output receipt. Source review against later holds is bound by the separate caption/boundary receipts and addenda; no old receipt is relabeled as a fresh full replay.

## Final bolted topology callback containment

`replay_bolted_topology_transition.py SOURCE OUTPUT` executes seven independent actual Streamlit tests: exact three-way round trips, supported active-cut retention, explicit cut removal on opposed selection, stale result/report retirement, strict rejected-native atomicity, and actual main-app callbacks. `replay_bolted_topology_all.py SOURCE OUTPUT` adds the two independently reproduced invalid-target/overflow-draft cases and successful user-corrected recovery. The two test modules use explicit LRO_REVIEW_SOURCE/LRO_REVIEW_OUTPUT variables and are portable. Their final reviewed execution consists of seven plus two separately logged passing runs, not an unperformed combined nine-test run.

`verify_ui_delta.py` uses the same five explicit arguments as the earlier delta verifiers. It permits only the final shared bolted UI and six specifically named test files, then repeats ten full result/40 active artifact comparisons and four no-trim layout checks. `seal_ui_transition.py SOURCE HOLD PRIOR_HOLD REVIEW_OUTPUT EXAMPLES_OUTPUT` binds those existing receipts and the still-byte-identical 84 selected artifacts to the final hold. It preserves the generation-v3 manifest and adds a separate current-hold bridge; it does not pretend the original generation used later UI bytes.
