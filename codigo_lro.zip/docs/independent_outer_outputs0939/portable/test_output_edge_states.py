from pathlib import Path
import sys,importlib,json,subprocess,os,math
from dataclasses import replace
from io import BytesIO
from zipfile import ZipFile
import pytest
from docx import Document
from streamlit.testing.v1 import AppTest
from streamlit.runtime.memory_media_file_storage import MemoryMediaFileStorage
ROOT=Path(os.environ['LRO_REVIEW_SOURCE']).resolve();OUT=Path(os.environ['LRO_REVIEW_OUTPUT']).resolve();sys.path.insert(0,str(ROOT))
from lro.welded_angle_gusset import WeldedAngleGusset as W,evaluate as ew
from lro.bolted_angle_gusset import presets as bp,evaluate as eb

def textof(b):
 d=Document(BytesIO(b));return '\n'.join([p.text for p in d.paragraphs]+[c.text for t in d.tables for r in t.rows for c in r.cells])

@pytest.mark.parametrize('route,kind',[('welded_angle_gusset','welded'),('welded_double_angle_gusset','welded'),('bolted_angle_gusset','bolted'),('corner_gusset','welded')])
def test_actual_main_app_import_and_native_download(route,kind,monkeypatch):
 module=importlib.import_module('lro.'+route);ui=importlib.import_module('lro.'+route+'_ui')
 cls=getattr(module,{'welded_angle_gusset':'WeldedAngleGusset','welded_double_angle_gusset':'WeldedDoubleAngleGusset','bolted_angle_gusset':'BoltedAngleGusset','corner_gusset':'CornerGusset'}[route])
 c=next(iter(bp().values())) if kind=='bolted' else cls()
 field='gusset_bolt_end_distance' if kind=='bolted' else 'gusset_weld_end_distance'
 c=replace(c,gusset_end_shape='normal_cut',**{field:35.123456789012345})
 files={};original=MemoryMediaFileStorage.load_and_get_id
 def tap(storage,*args,**kwargs):
  fid=original(storage,*args,**kwargs);files[fid]=storage._files_by_id[fid].content;return fid
 monkeypatch.setattr(MemoryMediaFileStorage,'load_and_get_id',tap)
 at=AppTest.from_file(str(ROOT/'app.py'),default_timeout=120);at.session_state['connection_family']=module.FAMILY;at.run();assert not at.exception
 at.get('file_uploader')[0].upload('precision-cut.json',json.dumps(c.to_dict(),ensure_ascii=False).encode(),'application/json').run()
 next(x for x in at.button if x.label.startswith('Carregar')).click().run();assert not at.exception
 assert at.session_state[ui.PROJECT]==c.to_dict()
 for x in at.get('download_button'):
  if '.json' in x.label:
   b=files[Path(x.proto.url).name.rsplit('.',1)[0]];native=json.loads(b)
   if native.get('connection_type')==c.to_dict()['connection_type']:
    assert native==c.to_dict();(OUT/(route+'_mainapp_download.json')).write_bytes(b);break
 else:pytest.fail('No actual native download')
 at.run();assert at.session_state[ui.PROJECT]==c.to_dict()
 assert at.session_state[ui.RESULT]==getattr(module,'evaluate',getattr(module,'analyze',None))(c)

@pytest.mark.parametrize('route,cls',[('welded_angle_gusset','WeldedAngleGusset'),('welded_double_angle_gusset','WeldedDoubleAngleGusset'),('bolted_angle_gusset','BoltedAngleGusset'),('corner_gusset','CornerGusset')])
def test_real_0938_native_migration_to_original(route,cls):
 if not os.environ.get('LRO_REVIEW_BASELINE'):pytest.skip('Optional immutable 0.9.38 baseline not supplied')
 baseline=Path(os.environ['LRO_REVIEW_BASELINE']).resolve()
 code=f'from lro.{route} import {cls}; import json; print(json.dumps({cls}().to_dict(),ensure_ascii=False))'
 env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONPATH':str(baseline)+os.pathsep+os.environ.get('PYTHONPATH','')}
 native=json.loads(subprocess.check_output([sys.executable,'-B','-c',code],env=env,text=True,cwd=str(OUT)))
 assert 'gusset_end_shape' not in native['connection']
 c=getattr(importlib.import_module('lro.'+route),cls).from_dict(native)
 assert c.gusset_end_shape=='original'
 assert getattr(c,'gusset_weld_end_distance',0.)==0. and getattr(c,'gusset_bolt_end_distance',0.)==0.
 for k,v in native['connection'].items():assert c.to_dict()['connection'][k]==v
 (OUT/(route+'_legacy0938_native.json')).write_text(json.dumps(native,ensure_ascii=False,indent=2))

@pytest.mark.parametrize('route',['welded_opposed_angle_gusset','bolted_opposed_angle_gusset'])
def test_opposed_controls_not_exposed(route):
 if route=='bolted_opposed_angle_gusset':
  from lro.bolted_opposed_angle_gusset import presets
  from lro.bolted_angle_gusset_ui import PROJECT
  at=AppTest.from_string('from lro.bolted_angle_gusset_ui import render\nrender()',default_timeout=120)
  at.session_state[PROJECT]=next(iter(presets().values())).to_dict();at.run()
 else:at=AppTest.from_string('from lro.'+route+'_ui import render\nrender()',default_timeout=120).run()
 assert not at.exception
 assert not any('gusset_end_shape' in str(x.key) for x in at.selectbox)
 assert not any('gusset_weld_end_distance' in str(x.key) or 'gusset_bolt_end_distance' in str(x.key) for x in at.number_input)

@pytest.mark.parametrize('name,theta',[('bolt90',90.),('bolt135',135.)])
def test_bolt_mirror_and_vertical_outputs(name,theta):
 from lro.bolted_angle_gusset_drawing import image_bytes
 c=replace(next(iter(bp().values())),db=19.05,pitch=60.,theta_deg=theta,gusset_end_shape='normal_cut',gusset_bolt_end_distance=35.)
 r=eb(c);assert r['geometry']['valid']
 (OUT/(name+'.png')).write_bytes(image_bytes(c));(OUT/(name+'.svg')).write_bytes(image_bytes(c,fmt='svg'))
 seg=r['geometry']['outer_end_cut']['cut_segment']
 if theta==90.:assert seg[0][1]==pytest.approx(seg[1][1])
 (OUT/(name+'_result.json')).write_text(json.dumps(r,ensure_ascii=False,indent=2))

def test_mixed_stress_failure_kept_in_both_word_forms_and_drawing():
 from lro.welded_angle_gusset_drawing import image_bytes
 from lro.welded_angle_gusset_report import create_report
 c=replace(W(),theta_deg=64.,center_s=20.,center_n=110.,weld_length=40.,introduction_width=140.,gusset_end_shape='normal_cut',gusset_weld_end_distance=6.)
 r=ew(c);assert r['status']=='OUTSIDE_SCOPE' and any(i['id']=='actual_compressed_section' for i in r['issues'])
 assert next(i for i in r['issues'] if i['id']=='actual_compressed_section')['minimum_normal_MPa']<-7.
 stale=ew(W());(OUT/'mixed_stress.png').write_bytes(image_bytes(c,stale))
 for detailed in (False,True):
  b=create_report(c,stale,detailed=detailed);name='mixed_stress_'+('detailed' if detailed else 'compact')
  text=textof(b);assert 'OUTSIDE_SCOPE' in text and 'contém compressão' in text and 'sem conclusão favorável completa' in text
  (OUT/(name+'.docx')).write_bytes(b);(OUT/(name+'.txt')).write_text(text)

def test_rejected_actual_gauge_is_not_called_physical():
 from lro.gusset_outer_end import description
 c=replace(next(iter(bp().values())),db=19.05,plate_width=400.,plate_height=300.,theta_deg=45.,n=2,pitch=60.,center_s=180-30/math.sqrt(2),center_n=200-30/math.sqrt(2),gusset_end_shape='normal_cut',gusset_bolt_end_distance=35.)
 r=eb(c);assert r['status']=='INVALID_GEOMETRY'
 cut=r['geometry']['outer_end_cut'];assert cut['dimension'] is None
 d=description(r['geometry'],str)
 assert '35.0 mm após o centro' not in d
 assert 'inválid' in d.lower() or 'não é uma cota' in d.lower() or 'não valid' in d.lower()
 (OUT/'invalid_gauge_description.txt').write_text(d)

@pytest.mark.parametrize('route',['welded_angle_gusset','welded_double_angle_gusset'])
def test_vertical_crop_height_identifies_base_envelope(route):
 cls=getattr(importlib.import_module('lro.'+route),'WeldedAngleGusset' if route=='welded_angle_gusset' else 'WeldedDoubleAngleGusset')
 c=replace(cls(),theta_deg=90.,gusset_end_shape='normal_cut',gusset_weld_end_distance=35.)
 svg=importlib.import_module('lro.'+route+'_drawing').image_bytes(c,fmt='svg')
 assert b'H_env' in svg

@pytest.mark.parametrize('corner,single',[(False,False),(False,True),(True,False),(True,True)])
def test_cap_label_does_not_hide_existing_force_or_continuation(corner,single):
 import matplotlib.pyplot as plt
 from matplotlib.text import Text
 if corner:
  from lro.corner_gusset import presets,analyze
  from lro.corner_gusset_drawing import _physical
  c=replace(next(iter(presets().values())),gusset_end_shape='normal_cut',gusset_bolt_end_distance=35.)
  if single:c=replace(c,topology='single_1L_bolted',symmetric=False)
  fig=_physical(c,analyze(c));target='N='
 else:
  from lro.bolted_angle_gusset_drawing import figure
  c=replace(next(iter(bp().values())),db=19.05,pitch=60.,arrangement='1L' if single else '2L-T',gusset_end_shape='normal_cut',gusset_bolt_end_distance=35.)
  fig=figure(c);target='Continuação da diagonal'
 fig.canvas.draw();renderer=fig.canvas.get_renderer()
 label=next(o for o in fig.findobj() if o.get_gid()=='outer_end_dimension_label')
 box=label.get_bbox_patch().get_window_extent(renderer)
 targets=[t for ax in fig.axes for t in ax.texts if t.get_text().startswith(target)]
 assert targets
 for t in targets:assert not box.overlaps(Text.get_window_extent(t,renderer)),(box,Text.get_window_extent(t,renderer),t.get_text())
 plt.close(fig)
