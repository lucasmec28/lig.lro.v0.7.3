"""Prove SVG comparator only tolerates its two declared nondeterministic fields."""
from pathlib import Path
import sys,re,json
from legacy_svg_normalization import normalize_svg
sample=Path(sys.argv[1]).read_bytes();out=Path(sys.argv[2]);raw=sample.decode();baseline=normalize_svg(sample);records=[]
def check(name,changed,expected):
 assert changed!=raw
 try:same=normalize_svg(changed.encode())['sha256']==baseline['sha256']
 except (AssertionError,ValueError):same=False
 assert same==expected,(name,same)
 records.append({'name':name,'passes_comparator':same,'expected':expected})
check('timestamp only',re.sub(r'<dc:date>[^<]+</dc:date>','<dc:date>2000-01-01T00:00:00</dc:date>',raw),True)
renamed=raw
for i,m in enumerate(baseline['bijective_id_mapping']):
 new=m['original_id'][0]+f'{i+1:010x}'
 assert new not in raw
 renamed=renamed.replace(m['original_id'],new)
check('bijective generated defs identifiers only',renamed,True)
geometry=re.sub(r'(d="M\s+)(-?\d+(?:\.\d+)?)',lambda m:m[1]+str(float(m[2])+0.25),raw,count=1)
check('geometry changed',geometry,False)
style=re.sub(r'(stroke-width:\s*)(\d+(?:\.\d+)?)',lambda m:m[1]+str(float(m[2])+0.5),raw,count=1)
check('style changed',style,False)
text=re.sub(r'(<text[^>]*>)([^<]+)',lambda m:m[1]+m[2]+' CHANGED',raw,count=1)
check('visible semantic text changed',text,False)
assert 'id="actual_force_arrow"' in raw
semantic=raw.replace('id="actual_force_arrow"','id="actual_force_arrow-changed"',1)
check('semantic action identifier changed',semantic,False)
for m in baseline['bijective_id_mapping']:
 token='url(#'+m['original_id']+')'
 if token in raw:
  check('reference only redirected',raw.replace(token,'url(#missing-clip)',1),False);break
else:raise AssertionError('No URL reference for mutation proof')
out.write_text(json.dumps({'status':'PASS','sample':str(Path(sys.argv[1])),'rules':baseline['rules'],'checks':records},ensure_ascii=False,indent=2)+'\n')
print('PASS',len(records),'normalizer mutation witnesses')
