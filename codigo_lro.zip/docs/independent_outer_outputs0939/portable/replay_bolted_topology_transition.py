"""Actual bolted topology callbacks; explicit source and evidence roots."""
import argparse,subprocess,sys,os,json,hashlib
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('source');p.add_argument('output');a=p.parse_args()
source=Path(a.source).resolve();out=Path(a.output).resolve();assert not out.is_relative_to(source);out.mkdir(parents=True,exist_ok=True)
def hashes():
 return {str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(source.rglob('*')) if p.is_file() and (str(p.relative_to(source))=='app.py' or str(p.relative_to(source)).startswith(('lro/','data/'))) and '__pycache__' not in str(p)}
before=hashes();env={**os.environ,'LRO_REVIEW_SOURCE':str(source),'LRO_REVIEW_OUTPUT':str(out),'PYTHONDONTWRITEBYTECODE':'1','MPLCONFIGDIR':str(out/'mpl'),'XDG_CACHE_HOME':str(out/'cache')}
with (out/'topology_replay.log').open('w') as log:r=subprocess.run([sys.executable,'-B','-m','pytest','-q','-p','no:cacheprovider',str(Path(__file__).parent/'test_bolted_topology_transition.py'),'--junitxml='+str(out/'topology_replay.xml')],cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT)
after=hashes();receipt={'source':str(source),'before':before,'after':after,'unchanged':before==after,'exit_code':r.returncode}
(out/'TOPOLOGY_PROVENANCE.json').write_text(json.dumps(receipt,indent=2));print(json.dumps({'unchanged':before==after,'exit_code':r.returncode}));assert before==after;sys.exit(r.returncode)
