"""56-test final output replay: baseline or APP-self-contained legacy fixture mode.
Usage: python -B replay_final_outputs.py SOURCE OUTPUT [--baseline OLD_SOURCE | --legacy-fixtures FIXTURE_DIR] [--collect-only | --legacy-only]
Default is reviewed materialized fixtures bundled beside this script. No installs/uploads.
"""
from pathlib import Path
import argparse,os,sys,subprocess,json,hashlib,xml.etree.ElementTree as ET
p=argparse.ArgumentParser();p.add_argument('source');p.add_argument('output');g=p.add_mutually_exclusive_group();g.add_argument('--baseline');g.add_argument('--legacy-fixtures');m=p.add_mutually_exclusive_group();m.add_argument('--collect-only',action='store_true');m.add_argument('--legacy-only',action='store_true');a=p.parse_args()
source=Path(a.source).resolve();out=Path(a.output).resolve();here=Path(__file__).resolve().parent;assert not out.is_relative_to(source);out.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def hashes():return {str(p.relative_to(source)):sha(p) for p in sorted(source.rglob('*')) if p.is_file() and (p.suffix=='.py' or p.parent.name=='data') and '__pycache__' not in str(p)}
before=hashes();env={**os.environ,'LRO_REVIEW_SOURCE':str(source),'LRO_REVIEW_OUTPUT':str(out),'PYTHONDONTWRITEBYTECODE':'1','MPLCONFIGDIR':str(out/'mpl'),'XDG_CACHE_HOME':str(out/'cache')};fixture_proof=None
files=['test_output_contract.py','test_output_edge_states.py','test_no_trim_layout.py','test_bolted_topology_transition.py','test_callback_boundaries.py']
selector=[]
if a.baseline:
 assert not a.legacy_only,'--legacy-only is for materialized fixture mode'
 env['LRO_REVIEW_BASELINE']=str(Path(a.baseline).resolve());env.pop('LRO_REVIEW_LEGACY_FIXTURES',None);mode='baseline-source'
else:
 fixture=Path(a.legacy_fixtures).resolve() if a.legacy_fixtures else here/'legacy0938';mp=fixture/'MANIFEST.json';fm=json.loads(mp.read_text());assert len(fm['files'])==4
 for r in fm['files']:assert (fixture/r['file']).stat().st_size==r['size'] and sha(fixture/r['file'])==r['sha256']
 fixture_proof={'manifest_sha256':sha(mp),'files':fm['files']};env['LRO_REVIEW_LEGACY_FIXTURES']=str(fixture);env.pop('LRO_REVIEW_BASELINE',None);mode='APP-self-contained-materialized-natives'
 files=['test_materialized_legacy_imports.py'] if a.legacy_only else files+['test_materialized_legacy_imports.py'];selector=[] if a.legacy_only else ['-k','not test_real_0938_native_migration_to_original']
args=[sys.executable,'-B','-m','pytest','-q','-p','no:cacheprovider',*[str(here/f) for f in files],*selector]
if a.collect_only:args+=['--collect-only']
else:args+=['--junitxml='+str(out/'final_output_replay.xml')]
with (out/'final_output_replay.log').open('w') as log:r=subprocess.run(args,cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT)
after=hashes();counts=None
if not a.collect_only and (out/'final_output_replay.xml').exists():
 root=ET.parse(out/'final_output_replay.xml').getroot();suites=[root] if root.tag=='testsuite' else root.findall('testsuite');counts={k:sum(int(s.get(k,0)) for s in suites) for k in ('tests','failures','errors','skipped')}
receipt={'mode':mode,'source':str(source),'before':before,'after':after,'unchanged':before==after,'exit_code':r.returncode,'collect_only':a.collect_only,'legacy_only':a.legacy_only,'expected_test_count':4 if a.legacy_only else 56,'junit_counts':counts,'legacy_fixture_proof':fixture_proof,'legacy_source_dependency':bool(a.baseline),'old_source_migration_tests_replaced_not_skipped':not bool(a.baseline),'test_files':{f:sha(here/f) for f in files}}
(out/'FINAL_REPLAY_PROVENANCE.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2));print(json.dumps({k:receipt[k] for k in ('mode','unchanged','exit_code','expected_test_count','junit_counts')}));assert before==after
if r.returncode==0 and counts:assert counts=={'tests':receipt['expected_test_count'],'failures':0,'errors':0,'skipped':0}
sys.exit(r.returncode)
