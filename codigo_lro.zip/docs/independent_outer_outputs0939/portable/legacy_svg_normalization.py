"""Strict legacy SVG comparison: only generated date and bijective defs IDs vary."""
import hashlib,re,xml.etree.ElementTree as ET

RULES={'metadata':'Replace only the single dc:date text inside SVG metadata; preserve element, namespaces and every other byte.','ids':'Rename only generated [mp][0-9a-f]{10} IDs on defs/path or defs/clipPath elements, in definition order; update exact id, url(#id), and href="#id" occurrences bijectively. Preserve every other byte, geometry, text, style and semantic/action label.'}
SVG='{http://www.w3.org/2000/svg}';DC='{http://purl.org/dc/elements/1.1/}'
def normalize_svg(data):
 text=data.decode('utf-8');root=ET.fromstring(data);parent={c:p for p in root.iter() for c in p}
 dates=root.findall('.//'+SVG+'metadata//'+DC+'date');assert len(dates)==1
 date=dates[0].text;assert re.fullmatch(r'\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d+)?',date)
 pattern='<dc:date>'+date+'</dc:date>';assert text.count(pattern)==1
 text=text.replace(pattern,'<dc:date>GENERATED_TIMESTAMP</dc:date>')
 all_ids=[e.attrib['id'] for e in root.iter() if 'id' in e.attrib];assert len(all_ids)==len(set(all_ids))
 mappings=[]
 for e in root.iter():
  old=e.get('id','')
  if not re.fullmatch(r'[mp][0-9a-f]{10}',old):continue
  assert parent[e].tag==SVG+'defs' and e.tag in (SVG+'path',SVG+'clipPath'),('Unqualified ID definition',old)
  assert (old[0]=='p')==(e.tag==SVG+'clipPath')
  new='generated-id-'+str(len(mappings));assert new not in data.decode('utf-8')
  forms=['id="'+old+'"','url(#'+old+')','xlink:href="#'+old+'"','href="#'+old+'"']
  # Bare href matching excludes xlink:href, which is accounted separately.
  counts=[text.count(forms[0]),text.count(forms[1]),text.count(forms[2]),len(re.findall(r'(?<![\w:])'+re.escape(forms[3]),text))]
  assert counts[0]==1 and text.count(old)==sum(counts),('Unexpected random-ID occurrence',old,counts)
  for form in forms[:3]:text=text.replace(form,form.replace(old,new))
  text=re.sub(r'(?<![\w:])'+re.escape(forms[3]),forms[3].replace(old,new),text)
  mappings.append({'original_id':old,'normalized_id':new,'definition_kind':e.tag.split('}')[1],'definition_count':counts[0],'url_references':counts[1],'xlink_references':counts[2],'href_references':counts[3]})
 assert mappings and len({r['normalized_id'] for r in mappings})==len(mappings)
 ET.fromstring(text)
 return {'sha256':hashlib.sha256(text.encode('utf-8')).hexdigest(),'generated_timestamp':date,'bijective_id_mapping':mappings,'rules':RULES}
