"""Real current-main-app imports of four reviewed native inputs; no old source."""
from pathlib import Path
import os,sys,json,hashlib,importlib
import pytest
from streamlit.testing.v1 import AppTest
from streamlit.runtime.memory_media_file_storage import MemoryMediaFileStorage
ROOT=Path(os.environ['LRO_REVIEW_SOURCE']).resolve();OUT=Path(os.environ['LRO_REVIEW_OUTPUT']).resolve();sys.path.insert(0,str(ROOT))
FIXTURES=Path(os.environ.get('LRO_REVIEW_LEGACY_FIXTURES',str(Path(__file__).parent/'legacy0938'))).resolve()
MANIFEST=json.loads((FIXTURES/'MANIFEST.json').read_text())
CLASSES={'welded_angle_gusset':'WeldedAngleGusset','welded_double_angle_gusset':'WeldedDoubleAngleGusset','bolted_angle_gusset':'BoltedAngleGusset','corner_gusset':'CornerGusset'}

@pytest.mark.parametrize('entry',MANIFEST['files'],ids=lambda x:x['route'])
def test_materialized_0938_import_through_current_main_app(entry,monkeypatch):
 assert not os.environ.get('LRO_REVIEW_BASELINE'),'Fixture mode must not use legacy source'
 p=FIXTURES/entry['file'];payload=p.read_bytes();assert len(payload)==entry['size'] and hashlib.sha256(payload).hexdigest()==entry['sha256']
 old=json.loads(payload);assert 'gusset_end_shape' not in old['connection'];assert not any(k in old for k in ('result','geometry','approved'))
 route=entry['route'];m=importlib.import_module('lro.'+route);ui=importlib.import_module('lro.'+route+'_ui');c=getattr(m,CLASSES[route]).from_dict(old)
 assert c.gusset_end_shape=='original' and getattr(c,'gusset_weld_end_distance',0.)==0. and getattr(c,'gusset_bolt_end_distance',0.)==0.
 for k,v in old['connection'].items():assert c.to_dict()['connection'][k]==v,k
 files={};original=MemoryMediaFileStorage.load_and_get_id
 def tap(storage,*args,**kwargs):
  identity=original(storage,*args,**kwargs);files[identity]=storage._files_by_id[identity].content;return identity
 monkeypatch.setattr(MemoryMediaFileStorage,'load_and_get_id',tap)
 at=AppTest.from_file(str(ROOT/'app.py'),default_timeout=120);at.session_state['connection_family']=m.FAMILY;at.run();assert not at.exception
 at.get('file_uploader')[0].upload(entry['file'],payload,'application/json').run();next(x for x in at.button if x.label.startswith('Carregar')).click().run();assert not at.exception
 assert at.session_state[ui.PROJECT]==c.to_dict()
 assert at.session_state[ui.RESULT]==getattr(m,'evaluate',getattr(m,'analyze',None))(c)
 downloaded=None
 for item in at.get('download_button'):
  if '.json' not in item.label:continue
  raw=files[Path(item.proto.url).name.rsplit('.',1)[0]];native=json.loads(raw)
  if native.get('connection_type')==c.to_dict()['connection_type']:downloaded=native;break
 assert downloaded==c.to_dict()
 for k,v in old['connection'].items():assert downloaded['connection'][k]==v,k
 OUT.mkdir(parents=True,exist_ok=True)
 (OUT/(route+'_materialized0938_import.json')).write_text(json.dumps({'source_fixture_sha256':entry['sha256'],'accepted_current_native':downloaded,'current_status':at.session_state[ui.RESULT]['status'],'main_app':str(ROOT/'app.py'),'legacy_source_used':False},ensure_ascii=False,indent=2))
