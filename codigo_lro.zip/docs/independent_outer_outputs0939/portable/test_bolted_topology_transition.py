"""Independent real-callback review of supported-cut to opposed topology transitions."""
from pathlib import Path
from dataclasses import replace
from copy import deepcopy
import os,sys,json
import pytest
from streamlit.testing.v1 import AppTest
ROOT=Path(os.environ['LRO_REVIEW_SOURCE']).resolve();OUT=Path(os.environ['LRO_REVIEW_OUTPUT']).resolve();sys.path.insert(0,str(ROOT))
from lro import bolted_angle_gusset as b,bolted_opposed_angle_gusset as o,bolted_angle_gusset_ui as ui
CAP={'gusset_end_shape','gusset_bolt_end_distance'}

def fresh(c,main=False):
 at=AppTest.from_file(str(ROOT/'app.py'),default_timeout=120) if main else AppTest.from_string('from lro.bolted_angle_gusset_ui import render\nrender()',default_timeout=120)
 if main:at.session_state['connection_family']=b.FAMILY
 at.session_state[ui.PROJECT]=c.to_dict();at.run();assert not at.exception
 return at

def checked(at,arrangement):
 native=deepcopy(at.session_state[ui.PROJECT]);assert native['connection']['arrangement']==arrangement
 m=o if arrangement=='2L-opposed' else b;cls=o.BoltedOpposedAngleGusset if arrangement=='2L-opposed' else b.BoltedAngleGusset
 c=cls.from_dict(native);assert at.session_state[ui.RESULT]==m.evaluate(c)
 assert ui.decode_project(json.dumps(native))==c
 assert not at.exception
 return native

def choose(at,arrangement):
 at.selectbox(key='bag_arrangement').set_value(arrangement).run();return checked(at,arrangement)

def generate(at):
 button=next(x for x in at.button if x.label=='Gerar memória completa parafusada');assert not button.disabled
 button.click().run();assert ui.REPORT in at.session_state
 return deepcopy(at.session_state[ui.REPORT])

def active():
 return replace(next(iter(b.presets().values())),arrangement='1L',db=19.05,pitch=60.,N=100000.123456789,gusset_end_shape='normal_cut',gusset_bolt_end_distance=35.123456789012345)

def test_default_three_way_roundtrip_preserves_every_native_bit():
 c=replace(next(iter(o.presets().values())),N=100000.123456789,center_s=.123456789012345,theta_deg=80.1234567890123)
 at=fresh(c);before=deepcopy(at.session_state[ui.PROJECT])
 for arrangement in ('1L','2L-T','2L-opposed'):
  native=choose(at,arrangement)
  for key,value in before['connection'].items():
   if key!='arrangement':assert native['connection'][key]==value,key
 assert at.session_state[ui.PROJECT]==before
 assert not CAP.intersection(before['connection'])
 assert not any(x.key in {'bag_'+s for s in CAP} for x in list(at.selectbox)+list(at.number_input))
 (OUT/'three_way_roundtrip_native.json').write_text(json.dumps(at.session_state[ui.PROJECT],indent=2))

def test_active_cap_supported_switch_then_opposed_resets_and_recalculates():
 c=active();at=fresh(c);old=checked(at,'1L');generate(at)
 pair=choose(at,'2L-T');assert ui.REPORT not in at.session_state
 assert pair['connection']['gusset_bolt_end_distance']==c.gusset_bolt_end_distance and pair['connection']['gusset_end_shape']=='normal_cut'
 generate(at);previous_result=deepcopy(at.session_state[ui.RESULT]);opposed=choose(at,'2L-opposed')
 assert ui.REPORT not in at.session_state and previous_result!=at.session_state[ui.RESULT]
 assert not CAP.intersection(opposed['connection']) and not CAP.intersection(at.session_state[ui.TEMPLATE]['connection'])
 for key,value in old['connection'].items():
  if key not in CAP|{'arrangement'}:assert opposed['connection'][key]==value,key
 assert any('corte externo anterior foi desativado' in x.value for x in at.info)
 assert 'outer_end_cut' not in at.session_state[ui.RESULT]['geometry']
 assert not any(x.key in {'bag_'+s for s in CAP} for x in list(at.selectbox)+list(at.number_input))
 returned=choose(at,'1L');assert returned['connection']['gusset_end_shape']=='original' and returned['connection']['gusset_bolt_end_distance']==0.
 assert ui.REPORT not in at.session_state
 assert not any('corte externo anterior foi desativado' in x.value for x in at.info)
 for key,value in old['connection'].items():
  if key not in CAP|{'arrangement'}:assert returned['connection'][key]==value,key
 (OUT/'active_to_opposed_native.json').write_text(json.dumps(opposed,indent=2));(OUT/'return_to_supported_native.json').write_text(json.dumps(returned,indent=2))

@pytest.mark.parametrize('bad_fields',[{'gusset_end_shape':'normal_cut','gusset_bolt_end_distance':35.},{'gusset_bolt_end_distance':0.},{'gusset_end_shape':'original'}])
def test_native_opposed_cap_injection_rejected_atomically(bad_fields):
 at=fresh(active());generate(at)
 keys=(ui.PROJECT,ui.RESULT,ui.DRAFT,ui.REPORT,ui.TEMPLATE,ui.ACCEPTED)
 saved={k:deepcopy(at.session_state[k]) for k in keys}
 widgets={x.key:x.value for x in list(at.number_input)+list(at.selectbox)+list(at.text_input)+list(at.checkbox) if x.key}
 bad=next(iter(o.presets().values())).to_dict();bad['connection'].update(bad_fields)
 at.get('file_uploader')[0].upload('unsupported-native.json',json.dumps(bad).encode(),'application/json').run()
 next(x for x in at.button if x.label=='Carregar projeto completo parafusado').click().run()
 assert not at.exception and any('Não foi possível abrir' in x.value for x in at.error)
 for k,v in saved.items():assert at.session_state[k]==v,k
 for k,v in widgets.items():assert at.session_state[k]==v,k

@pytest.mark.parametrize('cut',[False,True])
def test_actual_main_app_three_way_callbacks(cut):
 c=active() if cut else replace(active(),gusset_end_shape='original',gusset_bolt_end_distance=0.)
 at=fresh(c,main=True)
 for arrangement in ('2L-T','2L-opposed','1L'):
  native=choose(at,arrangement)
  if arrangement=='2L-opposed':assert not CAP.intersection(native['connection'])
 assert native['connection']['gusset_end_shape']=='original' and native['connection']['gusset_bolt_end_distance']==0.
 assert native['connection']['N']==c.N
 (OUT/('mainapp_'+('active' if cut else 'original')+'_roundtrip.json')).write_text(json.dumps(native,indent=2))
