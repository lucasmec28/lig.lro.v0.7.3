"""Supplementary no-trim caption and native-report consistency guard."""
from pathlib import Path
import os,sys,importlib
from dataclasses import replace
from io import BytesIO
from zipfile import ZipFile
import pytest
from matplotlib.text import Text
import matplotlib.pyplot as plt
ROOT=Path(os.environ['LRO_REVIEW_SOURCE']).resolve();OUT=Path(os.environ['LRO_REVIEW_OUTPUT']).resolve();sys.path.insert(0,str(ROOT))

@pytest.mark.parametrize('name,route,cls,field,target',[
 ('w1','welded_angle_gusset','WeldedAngleGusset','gusset_weld_end_distance','θ='),
 ('w2','welded_double_angle_gusset','WeldedDoubleAngleGusset','gusset_weld_end_distance','θ='),
 ('b2','bolted_angle_gusset','BoltedAngleGusset','gusset_bolt_end_distance','Ø físico='),
 ('cw2','corner_gusset','CornerGusset','gusset_weld_end_distance','U · corte superior')])
def test_no_trim_caption_clear_of_existing_labels(name,route,cls,field,target):
 m=importlib.import_module('lro.'+route);drawing=importlib.import_module('lro.'+route+'_drawing')
 c=next(iter(m.presets().values())) if name=='b2' else getattr(m,cls)()
 c=replace(c,gusset_end_shape='normal_cut',**{field:10000.})
 r=getattr(m,'evaluate',getattr(m,'analyze',None))(c)
 fig=drawing._physical(c,r) if name=='cw2' else drawing.figure(c)
 fig.canvas.draw();renderer=fig.canvas.get_renderer()
 label=next(o for o in fig.findobj() if o.get_gid()=='outer_end_no_trim');bbox=label.get_bbox_patch().get_window_extent(renderer)
 targets=[t for ax in fig.axes for t in ax.texts if t.get_text().startswith(target)];assert targets
 assert all(not bbox.overlaps(Text.get_window_extent(t,renderer)) for t in targets)
 plt.close(fig)
 png=drawing.image_bytes(c);(OUT/(name+'_no_trim.png')).write_bytes(png)
 b=importlib.import_module('lro.'+route+'_report').create_report(c)
 with ZipFile(BytesIO(b)) as z:assert any(z.read(n)==png for n in z.namelist() if n.startswith('word/media/'))
 (OUT/(name+'_no_trim_compact.docx')).write_bytes(b)
