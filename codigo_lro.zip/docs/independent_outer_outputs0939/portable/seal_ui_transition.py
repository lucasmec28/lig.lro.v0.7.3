"""Seal a bounded UI-only hold replacement without relabeling previous receipts.
Usage: python -B seal_ui_transition.py SOURCE HOLD PRIOR_HOLD REVIEW_OUTPUT EXAMPLES_OUTPUT
Required reviewed receipts live under the explicitly supplied output directories.
"""
from pathlib import Path
import sys,json,hashlib,datetime
source,holdp,oldholdp,review,examples=map(lambda x:Path(x).resolve(),sys.argv[1:])
assert not review.is_relative_to(source) and not examples.is_relative_to(source)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();H=json.loads(holdp.read_text());old=json.loads(oldholdp.read_text());h=sha(holdp)
actual={k:sha(source/k) for k in H['files']};assert actual==H['files']
delta={k:{'old':old['files'].get(k),'new':v} for k,v in H['files'].items() if old['files'].get(k)!=v}
assert set(delta)=={'lro/bolted_angle_gusset_ui.py','tests/test_bolted_opposed_angle_gusset_ui0931.py','tests/test_corner_integration0932.py','tests/test_guided_selection0919.py','tests/test_long_bolt_scope0934.py','tests/test_one_root_compression_ui0937.py','tests/test_single_angle_corner0933.py'}
assert set(H['files'])==set(old['files'])
corep=review/'topology_callback_review/contained_callback/TOPOLOGY_PROVENANCE.json';core=json.loads(corep.read_text());assert core['unchanged'] and core['exit_code']==0
for k,v in core['before'].items():assert H['files'][k]==v and core['after'][k]==v
boundaryp=review/'topology_callback_review/final_callback_verified/callback_boundary_hashes.json';boundary=json.loads(boundaryp.read_text());assert boundary['unchanged']
for k,v in boundary['source_sha256_before'].items():assert H['files'][k]==v and boundary['source_sha256_after'][k]==v
parityp=review/'ui_hold/UI_DELTA_BINDING.json';parity=json.loads(parityp.read_text());assert parity['hold_sha256']==h and parity['source_unchanged'] and len(parity['active_artifact_parity'])==40 and parity['exact_evaluated_result_parity']==10
prior_seal=review/'FINAL_OUTPUT_ACCEPTANCE.json';assert json.loads(prior_seal.read_text())['final_runtime_test_hold_sha256']==sha(oldholdp)
manifestp=examples/'SELECTION_MANIFEST.json';M=json.loads(manifestp.read_text());assert M['source_hold_sha256']==sha(oldholdp) and M['selected_count']==84
for x in M['selected_artifacts']:
 p=examples/x['path'];assert p.resolve().is_relative_to(examples) and p.stat().st_size==x['size'] and sha(p)==x['sha256']
G=json.loads((examples/'CAP_LIG18_PROVENANCE.json').read_text())
for x in G['module_origins'].values():assert H['files'][str(Path(x['path']).relative_to(source))]==x['sha256']
W=json.loads((examples/'w/SOURCE_PROVENANCE.json').read_text())
for k,x in W['source_modules'].items():assert H['files'][k]==x['sha256']
for k,x in W['data_files'].items():assert H['files'][k]==x['sha256']
def rec(p):return {'path':str(p),'size':p.stat().st_size,'sha256':sha(p)}
refs=[holdp,oldholdp,prior_seal,corep,boundaryp,parityp,manifestp,review/'topology_callback_review/contained_callback/topology_replay.xml',review/'topology_callback_review/final_callback_verified/pytest.xml',examples/'CAP_LIG18_PROVENANCE.json',examples/'w/SOURCE_PROVENANCE.json']
receipt={'decision':'GO within UI/native/drawing/report scope','sealed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'final_hold_sha256':h,'prior_hold_sha256':sha(oldholdp),'held_file_count':len(H['files']),'source_delta':delta,'independent_callback_tests':{'normal_active_atomic_and_actual_mainapp':7,'rejected_transition_and_recovery':2,'same_final_ui_sha256':H['files']['lro/bolted_angle_gusset_ui.py']},'active_artifact_parity':{'full_results':10,'png_svg_word_artifacts':40,'repeated_no_trim_layout_tests':4},'fresh_example_rebinding':{'selected_manifest_sha256':sha(manifestp),'artifact_count':84,'selected_identity_sha256':M['selected_identity_sha256'],'all_selected_files_still_match':True,'all_used_engine_drawing_report_data_hashes_unchanged':True,'original_generation_hold_sha256':sha(oldholdp),'note':'Original v3 generation provenance and artifact manifest remain unchanged. The v4 delta is UI/test-only; active cap artifacts were independently regenerated and compared again. W/Lig18 module/data dependencies and all selected artifact bytes remain unchanged.'},'evidence_files':[rec(p) for p in refs],'portable_files':[rec(p) for p in sorted(Path(__file__).parent.iterdir()) if p.is_file()],'remaining_output_blockers':[],'separate_gates':['independent mechanics','combined aggregate','immutable packaging','actual shipped outer-loader review'],'visual_limits':'Original representative cap/Lig18 visual coverage retained through strict artifact parity. W four first pages and two PNGs freshly inspected; 117 other W pages pixel-identical to reviewed previews. No new claim of all-page human review.','held_files':H['files']}
assert {k:sha(source/k) for k in H['files']}==H['files']
(review/'FINAL_UI_TRANSITION_ACCEPTANCE.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2))
rebind={'final_hold_sha256':h,'generation_hold_sha256':sha(oldholdp),'decision':'84 selected examples valid under final UI-only hold replacement','source_delta':delta,'selection_manifest':rec(manifestp),'selection_identity_sha256':M['selected_identity_sha256'],'all_selected_artifacts_byte_unchanged':True,'all_artifact_engine_drawing_report_data_dependencies_unchanged':True,'current_output_acceptance':rec(review/'FINAL_UI_TRANSITION_ACCEPTANCE.json'),'selected_count':84,'original_receipts_preserved':True}
(examples/'CURRENT_HOLD_REBIND.json').write_text(json.dumps(rebind,ensure_ascii=False,indent=2))
print(json.dumps({'acceptance':rec(review/'FINAL_UI_TRANSITION_ACCEPTANCE.json'),'examples_rebind':rec(examples/'CURRENT_HOLD_REBIND.json')}))
