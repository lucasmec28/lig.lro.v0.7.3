# Final self-contained output replay

Run `python -B replay_final_outputs.py CURRENT_RUNTIME_ROOT OUTPUT_DIR` with the documented Python test dependencies already available. Output must be outside the read-only current runtime. The default mode uses the four reviewed native JSON files in `legacy0938/`, verified against their manifest before execution. No old source tree is needed, generated, imported or consulted by the replacement migration checks.

The full suite has 56 executed tests:

- 39 original output checks that do not need the old source
- Four real current-main-app import/download tests using the materialized old natives
- Four no-trim caption checks
- Seven normal, active-cut, strict-import and main-app topology callback checks
- Two rejected-transition and user-corrected recovery checks

The four original old-source migration functions are deliberately deselected and replaced one-for-one, not counted as skipped. Successful execution requires 56 tests, zero failures/errors and zero skips in JUnit. `--legacy-only` runs just the four substitutions. `--collect-only` checks collection without claiming execution.

To retain the old baseline-generation path, use `--baseline OLD_SOURCE_ROOT`; this selects the original four subprocess-generated migration tests and does not select the materialized replacements. The original replay_outputs.py and its old receipts remain unchanged. A nondefault location for the bundled four inputs can be supplied with `--legacy-fixtures DIRECTORY`; every file hash must still match that directory's reviewed manifest.

The four fixture files are copied byte-for-byte from the preserved earlier output review, including their actual old component versions. The tests require absent outer-cap fields in those files, preserve every old connection value, verify original/zero defaults after migration, use actual upload/load callbacks, compare the recalculated current result and inspect the native download. No stored approval or result is trusted.

SELF_CONTAINED_ACCEPTANCE.json records fixture provenance/hashes, adapter/test hashes and the successful source replay. That source replay remains distinct from the actual delivered-APP gate: the latter must bootstrap through the shipped outer loader, prove the imported lro origins belong to its extracted bundle, redirect actual-main-app calls to that outer entry, and bind archive/root-file identities without original-source or optional-companion fallback. The same 56 test assertions are used there.
