"""Read-only regression checks for rejected deliberate topology transitions.

These exercise pre-existing callback boundaries contained by the current fix;
they do not authorize relaxing either native engine's parser or changing inputs.
"""
from copy import deepcopy
from dataclasses import replace
import hashlib
import json
import os
from pathlib import Path
import sys

import pytest

SOURCE=Path(os.environ['LRO_REVIEW_SOURCE']).resolve()
OUTPUT=Path(os.environ['LRO_REVIEW_OUTPUT']).resolve()
assert (SOURCE/'lro/bolted_angle_gusset_ui.py').is_file()
sys.path.insert(0,str(SOURCE))

from streamlit.testing.v1 import AppTest

from lro.bolted_angle_gusset import BoltedAngleGusset, presets as old_presets
from lro.bolted_opposed_angle_gusset import BoltedOpposedAngleGusset, evaluate as opposed_evaluate, presets
from lro.bolted_angle_gusset_ui import PROJECT, RESULT, REPORT, TEMPLATE, ACCEPTED, DRAFT

RUNNER='from lro.bolted_angle_gusset_ui import render\nrender()'


def source_hashes():
    return {name:hashlib.sha256((SOURCE/name).read_bytes()).hexdigest() for name in (
        'lro/bolted_angle_gusset_ui.py','lro/bolted_angle_gusset.py',
        'lro/bolted_opposed_angle_gusset.py','lro/gusset_outer_end.py')}


@pytest.fixture(scope='module',autouse=True)
def audit_final_source():
    before=source_hashes()
    yield
    after=source_hashes()
    OUTPUT.mkdir(parents=True,exist_ok=True)
    record={'source':str(SOURCE),'source_sha256_before':before,
            'source_sha256_after':after,'unchanged':before==after,
            'test_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (OUTPUT/'callback_boundary_hashes.json').write_text(json.dumps(record,indent=2))
    assert before==after, 'Reviewed source changed during the focused callback replay.'


def fresh(c):
    at=AppTest.from_string(RUNNER, default_timeout=180)
    at.session_state[PROJECT]=c.to_dict()
    at.run()
    assert not at.exception
    return at


def report_button(at):
    return next(item for item in at.button if item.label=='Gerar memória completa parafusada')


def no_word(at):
    assert REPORT not in at.session_state
    assert not any(item.label=='Baixar memória completa parafusada .docx' for item in at.get('download_button'))


def test_opposed_n51_rejects_1L_without_clamping_or_identity_mismatch():
    initial=next(iter(presets().values()))
    at=fresh(initial)
    report_button(at).click().run()
    assert REPORT in at.session_state
    # n=51 remains a valid strict opposed scalar even though this particular
    # physical layout is invalid. Its target 1L model forbids values above 50.
    at.number_input(key='bag_n').set_value(51).run()
    assert not at.exception
    source=replace(initial,n=51)
    expected=source.to_dict()
    assert BoltedOpposedAngleGusset.from_dict(expected)==source
    assert at.session_state[PROJECT]==expected
    before={key:deepcopy(at.session_state[key]) for key in (PROJECT,RESULT,TEMPLATE,ACCEPTED,DRAFT)}
    no_word(at)
    at.selectbox(key='bag_arrangement').set_value('1L').run()
    assert not at.exception
    assert at.selectbox(key='bag_arrangement').value=='2L-opposed'
    assert at.number_input(key='bag_n').value==51
    assert at.session_state[PROJECT]==expected
    assert at.session_state[RESULT]==opposed_evaluate(source)
    assert at.session_state[RESULT]['family']==before[RESULT]['family']
    for key in (PROJECT,TEMPLATE,ACCEPTED,DRAFT):
        assert at.session_state[key]==before[key],key
    assert any('Alteração de arranjo não aplicada' in item.value for item in at.error)
    no_word(at)
    # A user correction permits a subsequent deliberate transition, and the
    # former rejection cannot strand the selector in the wrong native family.
    at.number_input(key='bag_n').set_value(3).run()
    at.selectbox(key='bag_arrangement').set_value('1L').run()
    assert not at.exception
    c=BoltedAngleGusset.from_dict(at.session_state[PROJECT])
    assert c.arrangement=='1L' and c.n==3
    assert c.gusset_end_shape=='original' and c.gusset_bolt_end_distance==0.
    assert 'bag_arrangement_error' not in at.session_state
    no_word(at)


def test_overflow_draft_rejects_opposed_keeps_numeric_edit_and_recovers():
    initial=next(iter(old_presets().values()))
    at=fresh(initial)
    report_button(at).click().run()
    assert REPORT in at.session_state
    at.number_input(key='bag_N_kN').set_value(1e308).run()
    assert not at.exception
    assert at.session_state[RESULT]['status']=='NUMERICAL_FAILURE'
    assert PROJECT not in at.session_state
    no_word(at)
    before={key:deepcopy(at.session_state[key]) for key in (TEMPLATE,ACCEPTED,DRAFT)}
    at.selectbox(key='bag_arrangement').set_value('2L-opposed').run()
    assert not at.exception
    assert at.selectbox(key='bag_arrangement').value=='2L-T'
    assert at.number_input(key='bag_N_kN').value==1e308
    assert PROJECT not in at.session_state
    assert at.session_state[RESULT]['status']=='NUMERICAL_FAILURE'
    assert at.session_state[RESULT]['global_pass'] is False
    assert at.session_state[RESULT]['checks']==[]
    for key in (TEMPLATE,ACCEPTED):
        assert at.session_state[key]==before[key],key
    # On an invalid render Streamlit cleans up the absent report-only checkbox.
    # It is not an engineering input. All native draft data must stay exact.
    def native_draft(draft):
        return {key:value for key,value in draft.items() if key!='bag_report_detailed'}
    assert native_draft(at.session_state[DRAFT])==native_draft(before[DRAFT])
    assert any('Alteração de arranjo não aplicada' in item.value for item in at.error)
    assert not at.get('download_button')
    no_word(at)
    # Correcting the numeric field is the user's action; no automatic clamping
    # or recovery-to-an-earlier-load is allowed during the rejected transition.
    at.number_input(key='bag_N_kN').set_value(100.).run()
    assert not at.exception
    assert at.session_state[PROJECT]['connection']['arrangement']=='2L-T'
    assert at.session_state[PROJECT]['connection']['N']==100000.
    at.selectbox(key='bag_arrangement').set_value('2L-opposed').run()
    assert not at.exception
    c=BoltedOpposedAngleGusset.from_dict(at.session_state[PROJECT])
    assert c.arrangement=='2L-opposed' and c.N==100000.
    assert 'bag_arrangement_error' not in at.session_state
    assert at.session_state[RESULT]==opposed_evaluate(c)
    no_word(at)
