"""After a bounded caption correction, preserve prior receipts and bind active artifacts.
Usage: python -B verify_caption_delta.py SOURCE PRIOR_OUTPUT NEW_OUTPUT HOLD PRIOR_HOLD_RECEIPT
"""
from pathlib import Path
import sys,json,hashlib,os,subprocess,importlib
from zipfile import ZipFile
from io import BytesIO
from legacy_svg_normalization import normalize_svg
source,old,out,hold,prior=map(lambda s:Path(s).resolve(),sys.argv[1:])
assert not out.is_relative_to(source);out.mkdir(parents=True,exist_ok=True);sys.path.insert(0,str(source))
H=json.loads(hold.read_text());P=json.loads(prior.read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
def held():return {k:sha((source/k).read_bytes()) for k in H['files']}
assert held()==H['files'];delta={k:{'old':P['files'].get(k),'new':v} for k,v in H['files'].items() if P['files'].get(k)!=v}
allowed={'lro/gusset_outer_end_drawing.py','lro/welded_angle_gusset_drawing.py','lro/welded_double_angle_gusset_drawing.py','lro/bolted_angle_gusset_drawing.py','lro/corner_gusset_drawing.py'}
assert set(delta)<=allowed,delta
records={}
for native in sorted(old.glob('*_native.json')):
 name=native.name[:-len('_native.json')]
 if name.startswith(('welded_','bolted_','corner_')):continue
 route='welded_angle_gusset' if name.startswith('w1_') else 'welded_double_angle_gusset' if name.startswith('w2_') else 'bolted_angle_gusset' if name.startswith(('b1_','b2_')) else 'corner_gusset'
 cls={'welded_angle_gusset':'WeldedAngleGusset','welded_double_angle_gusset':'WeldedDoubleAngleGusset','bolted_angle_gusset':'BoltedAngleGusset','corner_gusset':'CornerGusset'}[route]
 c=getattr(importlib.import_module('lro.'+route),cls).from_dict(json.loads(native.read_text()))
 d=importlib.import_module('lro.'+route+'_drawing');r=importlib.import_module('lro.'+route+'_report')
 for fmt in ('png','svg'):
  b=d.image_bytes(c,fmt=fmt);previous=(old/(name+'.'+fmt)).read_bytes()
  if fmt=='svg' and b!=previous:
   n1=normalize_svg(b);n0=normalize_svg(previous);assert n1['sha256']==n0['sha256'],(name,fmt)
   records[name+'.'+fmt]={'new_sha256':sha(b),'prior_sha256':sha(previous),'strict_normalized_svg_equality':True,'normalization':n1}
  else:
   assert b==previous,(name,fmt)
   records[name+'.'+fmt]={'sha256':sha(b),'byte_identical_to_prior':True}
 for detailed in (False,True):
  filename=name+('_detailed' if detailed else '_compact')+'.docx';b=r.create_report(c,detailed=detailed)
  with ZipFile(BytesIO(b)) as z,ZipFile(old/filename) as oldz:
   assert z.namelist()==oldz.namelist()
   members={n:sha(z.read(n)) for n in z.namelist()};assert members=={n:sha(oldz.read(n)) for n in oldz.namelist()},filename
  records[filename]={'prior_sha256':sha((old/filename).read_bytes()),'all_zip_members_identical_to_prior':True,'members':members}
env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','LRO_REVIEW_SOURCE':str(source),'LRO_REVIEW_OUTPUT':str(out),'MPLCONFIGDIR':str(out/'mpl'),'XDG_CACHE_HOME':str(out/'cache')}
with (out/'no_trim_layout.log').open('w') as log:
 r=subprocess.run([sys.executable,'-B','-m','pytest','-q','-p','no:cacheprovider',str(Path(__file__).parent/'test_no_trim_layout.py'),'--junitxml='+str(out/'no_trim_layout.xml')],cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT)
assert r.returncode==0,'No-trim layout test failed'
assert held()==H['files']
receipt={'hold_sha256':sha(hold.read_bytes()),'prior_hold_sha256':P['hold_sha256'],'delta':delta,'active_artifact_parity':records,'no_trim_tests':4,'source_unchanged':True,'files':H['files']}
(out/'CAPTION_DELTA_BINDING.json').write_text(json.dumps(receipt,indent=2));print(json.dumps({'changed':list(delta),'active_artifacts_verified':len(records),'no_trim_tests_passed':4,'source_unchanged':True}))
