import sys,json,hashlib,math,importlib,os
from pathlib import Path
from dataclasses import replace
from copy import deepcopy
from io import BytesIO
import pytest
import numpy as np
from docx import Document
from streamlit.testing.v1 import AppTest
from streamlit.runtime.memory_media_file_storage import MemoryMediaFileStorage
ROOT=Path(os.environ['LRO_REVIEW_SOURCE']).resolve()
sys.path.insert(0,str(ROOT))
from lro.welded_angle_gusset import WeldedAngleGusset as W,evaluate as ew
from lro.welded_double_angle_gusset import WeldedDoubleAngleGusset as D,evaluate as ed
from lro.bolted_angle_gusset import BoltedAngleGusset as B,presets as bp,evaluate as eb
from lro.corner_gusset import CornerGusset as C,presets as cp,analyze as ec
OUT=Path(os.environ['LRO_REVIEW_OUTPUT']).resolve()
ROUTES=[('welded_angle_gusset','wag_',W(),ew),('welded_double_angle_gusset','wdag_',D(),ed),('bolted_angle_gusset','bag_',replace(next(iter(bp().values())),db=19.05,pitch=60.),eb),('corner_gusset','cg_',C(),ec)]

def fresh(module,c):
 ui=importlib.import_module('lro.'+module+'_ui')
 at=AppTest.from_string('from lro.'+module+'_ui import render\nrender()',default_timeout=120)
 at.session_state[ui.PROJECT]=c.to_dict();at.run();assert not at.exception
 return at,ui

def btn(at,sub):return next(x for x in at.button if x.label.startswith(sub))
def txt(b):
 d=Document(BytesIO(b));return '\n'.join([p.text for p in d.paragraphs]+[c.text for t in d.tables for r in t.rows for c in r.cells])

@pytest.mark.parametrize('module,prefix,c,evaluator',ROUTES)
def test_real_ui_import_precision_stale_report_and_result(module,prefix,c,evaluator):
 bolted=isinstance(c,B);field='gusset_bolt_end_distance' if bolted else 'gusset_weld_end_distance'
 c=replace(c,gusset_end_shape='normal_cut',**{field:35.123456789012345})
 at,ui=fresh(module,replace(c,gusset_end_shape='original'))
 payload=json.dumps(c.to_dict(),ensure_ascii=False,allow_nan=False).encode()
 at.get('file_uploader')[0].upload('outer-cut-precise.json',payload,'application/json').run()
 btn(at,'Carregar').click().run();assert not at.exception
 assert at.session_state[ui.PROJECT]==c.to_dict()
 assert at.session_state[ui.RESULT]==evaluator(c)
 assert at.number_input(key=prefix+field).value==getattr(c,field)
 assert at.number_input(key=prefix+field).proto.format=='%.2f'
 at.run();assert at.session_state[ui.PROJECT]==c.to_dict()
 # Generate current report when route permits, then demand that actual edits invalidate it.
 generate=btn(at,'Gerar memória')
 if not generate.disabled: generate.click().run();assert ui.REPORT in at.session_state
 old=deepcopy(at.session_state[ui.RESULT])
 at.number_input(key=prefix+field).set_value(37.65432109876543).run();assert not at.exception
 assert ui.REPORT not in at.session_state
 changed=type(c).from_dict(at.session_state[ui.PROJECT])
 assert getattr(changed,field)==37.65432109876543
 assert at.session_state[ui.RESULT]==evaluator(changed)
 assert old['geometry']['polygon']!=at.session_state[ui.RESULT]['geometry']['polygon']
 # Fake saved approval has no authority on a fresh rerender.
 at.session_state[ui.RESULT]={'global_pass':True,'status':'PASS','geometry':{'polygon':[[1,2],[3,4],[5,6]]}}
 at.run();assert at.session_state[ui.RESULT]==evaluator(changed)
 (OUT/(module+'_ui_native.json')).write_text(json.dumps(at.session_state[ui.PROJECT],ensure_ascii=False,indent=2))

@pytest.mark.parametrize('module,prefix,c,evaluator',[ROUTES[2],('corner_gusset','cg_',replace(next(iter(cp().values())),bolt_diameter=19.05),ec)])
def test_gauge_seed_is_only_explicit_19_05_enable(module,prefix,c,evaluator):
 dfield='db' if isinstance(c,B) else 'bolt_diameter';field='gusset_bolt_end_distance'
 for diameter,initial,expected in [(19.05,0.,35.),(20.,0.,0.),(19.05,32.123456789,32.123456789)]:
  fixture=replace(c,**{dfield:diameter,field:initial})
  # 20 mm is not an admitted bolt family, so test non-3/4 with admitted 5/8.
  if diameter==20.:fixture=replace(c,**{dfield:15.875,field:initial})
  at,ui=fresh(module,fixture)
  assert at.number_input(key=prefix+field).disabled
  at.selectbox(key=prefix+'gusset_end_shape').set_value('normal_cut').run();assert not at.exception
  assert at.number_input(key=prefix+field).value==expected
  assert at.session_state[ui.PROJECT]['connection'][field]==expected
 # Native import enabled with zero must not invoke a user-enable default.
 at,ui=fresh(module,replace(c,gusset_end_shape='normal_cut',**{field:0.}))
 assert at.number_input(key=prefix+field).value==0.
 assert not at.session_state[ui.RESULT].get('global_pass',at.session_state[ui.RESULT].get('pass',False))

@pytest.mark.parametrize('module,prefix,c,evaluator',[ROUTES[0],ROUTES[1],ROUTES[3]])
def test_weld_enable_does_not_seed_gauge(module,prefix,c,evaluator):
 at,ui=fresh(module,c)
 at.selectbox(key=prefix+'gusset_end_shape').set_value('normal_cut').run();assert not at.exception
 assert at.number_input(key=prefix+'gusset_weld_end_distance').value==0.
 assert at.session_state[ui.RESULT]['status'] not in ('PASS','COMPLETE_LOCAL_CHECKS_PASS_WITHIN_SCOPE')

@pytest.mark.parametrize('name,c,route,evaluator',[
 ('w1_45',replace(W(),theta_deg=45.,gusset_end_shape='normal_cut',gusset_weld_end_distance=35.),'welded_angle_gusset',ew),
 ('w1_90',replace(W(),theta_deg=90.,gusset_end_shape='normal_cut',gusset_weld_end_distance=35.),'welded_angle_gusset',ew),
 ('w1_135',replace(W(),theta_deg=135.,gusset_end_shape='normal_cut',gusset_weld_end_distance=35.),'welded_angle_gusset',ew),
 ('w2_75',replace(D(),gusset_end_shape='normal_cut',gusset_weld_end_distance=35.),'welded_double_angle_gusset',ed),
 ('b1_80',replace(next(iter(bp().values())),arrangement='1L',db=19.05,pitch=60.,gusset_end_shape='normal_cut',gusset_bolt_end_distance=35.),'bolted_angle_gusset',eb),
 ('b2_80',replace(next(iter(bp().values())),db=19.05,pitch=60.,gusset_end_shape='normal_cut',gusset_bolt_end_distance=35.),'bolted_angle_gusset',eb),
 ('cw1',replace(C(),topology='single_1L_welded',symmetric=False,gusset_end_shape='normal_cut',gusset_weld_end_distance=20.),'corner_gusset',ec),
 ('cw2',replace(C(),gusset_end_shape='normal_cut',gusset_weld_end_distance=20.),'corner_gusset',ec),
 ('cb1',replace(next(iter(cp().values())),topology='single_1L_bolted',symmetric=False,gusset_end_shape='normal_cut',gusset_bolt_end_distance=35.),'corner_gusset',ec),
 ('cb2',replace(next(iter(cp().values())),gusset_end_shape='normal_cut',gusset_bolt_end_distance=35.),'corner_gusset',ec),
])
def test_current_polygon_dimension_root_brace_and_reports(name,c,route,evaluator):
 r=evaluator(c);drawing=importlib.import_module('lro.'+route+'_drawing');report=importlib.import_module('lro.'+route+'_report')
 stale=evaluator(replace(c,gusset_end_shape='original'))
 fig=drawing._physical(c,r) if route=='corner_gusset' else drawing.figure(c,stale)
 objects={o.get_gid():o for o in fig.findobj() if o.get_gid()}
 p=objects['gusset-clipped-polygon' if route=='corner_gusset' else 'gusset_polygon']
 assert np.allclose(p.get_xy()[:-1],r['geometry']['polygon'],atol=1e-10,rtol=0)
 cut=r['geometry']['outer_end_cut']; line=objects['outer_normal_cut_free']
 assert np.allclose(np.column_stack(line.get_data()),cut['cut_segment'],atol=1e-10,rtol=0)
 dim=objects['outer_end_physical_dimension']
 assert np.allclose(dim.xy,cut['dimension'][1]);assert np.allclose(dim.xyann,cut['dimension'][0])
 assert math.dist(*cut['dimension'])==pytest.approx(cut['distance_mm'],abs=1e-9)
 assert (cut['dimension'][1][0]-cut['dimension'][0][0])*cut['axis'][1]-(cut['dimension'][1][1]-cut['dimension'][0][1])*cut['axis'][0]==pytest.approx(0.,abs=1e-9)
 if route=='corner_gusset':
  for gid,key in [('beam-root-double-fillet','beam_seam'),('column-root-double-fillet','column_seam')]:assert np.allclose(np.column_stack(objects[gid].get_data()),r['geometry'][key])
  brace=objects['brace-single-projection' if c.topology.startswith('single') else 'brace-pair-projection'].get_xy()
 else:
  assert np.allclose(np.column_stack(objects['root_weld_line'].get_data()),[[-c.plate_width/2,0],[c.plate_width/2,0]])
  brace=objects['connected_angle_leg_projection' if route=='bolted_angle_gusset' else 'two_connected_angle_legs_projected' if route=='welded_double_angle_gusset' else 'connected_angle_leg_plan'].get_xy()
 assert max(np.dot(q,cut['axis']) for q in brace)>cut['cut_u']
 import matplotlib.pyplot as plt;plt.close(fig)
 for fmt in ('png','svg'):
  data=drawing.image_bytes(c,stale,fmt=fmt);(OUT/(name+'.'+fmt)).write_bytes(data)
  if fmt=='svg':assert b'outer_end_physical_dimension' in data and b'outer_end_dimension_label' in data and b'outer_normal_cut_free' in data
 # Compact and detailed Word factory must contain the exact current PNG even with stale result.
 png=drawing.image_bytes(c,fmt='png')
 from zipfile import ZipFile
 for detailed in (False,True):
  b=report.create_report(c,stale,detailed=detailed)
  label='detailed' if detailed else 'compact';(OUT/(name+'_'+label+'.docx')).write_bytes(b)
  text=txt(b);(OUT/(name+'_'+label+'.txt')).write_text(text)
  assert 'Corte externo perpendicular' in text and 'Área retida' in text
  assert r['status'] in text
  z=ZipFile(BytesIO(b));assert any(z.read(n)==png for n in z.namelist() if n.startswith('word/media/'))
 (OUT/(name+'_result.json')).write_text(json.dumps(r,ensure_ascii=False,indent=2))
 (OUT/(name+'_native.json')).write_text(json.dumps(c.to_dict(),ensure_ascii=False,indent=2))

@pytest.mark.parametrize('module,prefix,c,evaluator',ROUTES)
def test_no_trim_has_no_fictitious_edge_or_gauge(module,prefix,c,evaluator):
 field='gusset_bolt_end_distance' if isinstance(c,B) else 'gusset_weld_end_distance'
 c=replace(c,gusset_end_shape='normal_cut',**{field:10000.})
 r=evaluator(c);drawing=importlib.import_module('lro.'+module+'_drawing');report=importlib.import_module('lro.'+module+'_report')
 svg=drawing.image_bytes(c,fmt='svg')
 assert b'outer_end_no_trim' in svg and b'outer_normal_cut_free' not in svg and b'outer_end_physical_dimension' not in svg
 text=txt(report.create_report(c));assert 'sem remoção de material' in text and 'não há nova face para cotar' in text
 (OUT/(prefix+'no_trim.svg')).write_bytes(svg)
