"""Run independent source output review. Source is read-only; evidence goes outside it.
Usage: python -B replay_outputs.py SOURCE_ROOT OUTPUT_DIR [--baseline BASE0938]
Dependencies must already be installed or present on PYTHONPATH. No install/upload.
"""
import argparse,subprocess,sys,os,json,hashlib
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('source');p.add_argument('output');p.add_argument('--baseline');p.add_argument('--collect-only',action='store_true');a=p.parse_args()
source=Path(a.source).resolve();out=Path(a.output).resolve();here=Path(__file__).resolve().parent
assert (source/'app.py').is_file() and (source/'lro').is_dir(),'An extracted source root is required'
assert not out.is_relative_to(source),'Evidence must be outside immutable source'
out.mkdir(parents=True,exist_ok=True)
def hashes():return {str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(source.rglob('*')) if p.is_file() and (p.suffix=='.py' or p.parent.name=='data') and '__pycache__' not in str(p)}
before=hashes();env={**os.environ,'LRO_REVIEW_SOURCE':str(source),'LRO_REVIEW_OUTPUT':str(out),'PYTHONDONTWRITEBYTECODE':'1','MPLCONFIGDIR':str(out/'mpl'),'XDG_CACHE_HOME':str(out/'cache')}
if a.baseline:env['LRO_REVIEW_BASELINE']=str(Path(a.baseline).resolve())
else:env.pop('LRO_REVIEW_BASELINE',None)
args=[sys.executable,'-B','-m','pytest','-q','-p','no:cacheprovider',str(here/'test_output_contract.py'),str(here/'test_output_edge_states.py'),str(here/'test_no_trim_layout.py')]
if a.collect_only:args+=['--collect-only']
else:args+=['--junitxml='+str(out/'independent_output_replay.xml')]
with (out/'independent_output_replay.log').open('w') as log:r=subprocess.run(args,cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT)
after=hashes();receipt={'source':str(source),'before':before,'after':after,'unchanged':before==after,'exit_code':r.returncode,'collect_only':a.collect_only}
(out/'RUNTIME_PROVENANCE.json').write_text(json.dumps(receipt,indent=2));print(json.dumps({k:receipt[k] for k in ('source','unchanged','exit_code','collect_only')}))
assert before==after,'Source changed during replay'
sys.exit(r.returncode)
