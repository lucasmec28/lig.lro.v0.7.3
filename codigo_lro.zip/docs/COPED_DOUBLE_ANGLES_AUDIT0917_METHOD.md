# R017: auditoria e correção finita 0.9.17

Data: 10/10/2026. Nova cópia de desenvolvimento; sem publicação. O esquema nativo 0.9.3-angle-dev permanece compatível.

## Método que permanece

Duas cantoneiras físicas iguais, com ambas as interfaces parafusadas, ligam uma alma W com recortes superior e inferior iguais e rasos a uma única alma W perpendicular, interior e íntegra. Os parafusos comuns da viga têm dois planos de corte; os grupos de apoio têm corte simples e furos físicos distintos na mesma alma. Interfaces em série não somam capacidades. Não se usa tf ou 2tw no apoio, nem se importa um bloco de borda de mesa de pilar.

O caminho convencional flexível LCPP conserva componentes NBR 8800:2024, versão corrigida 2025, e o modelo complementar elástico de recorte Gerdau/AISC. O braço é c + folga; W1 = tw h0²/6. O coeficiente 350600 MPa corresponde a 35060 kN/cm², já de cálculo, sem segunda divisão por γ. Primeiro escoamento e instabilidade continuam separados. Não há ganho plástico, ajuste para tabela histórica, grupo rígido excêntrico acrescentado ou novo modelo resistente.

V positivo é entregue para baixo ao apoio; o contato na alma apoiada é para cima e carrega a borda superior. A inversão refaz bordas, prefixos e a mesa comprimida. Para V=0 ambos os sentidos são verificados sob o piso local de 45 kN, conservando zero como ação física. As duas colunas de apoio recebem V/2, sem impor reações globais iguais nos vãos.

Recortes desiguais não são promediados. Permanecem as fronteiras c≤2d e dc≤0,2d, caminho reto dos furos e contenção lateral qualificada da mesa comprimida na face do recorte. Referência, sistema e posição são condições externas declaradas: não constituem dimensionamento da resistência ou rigidez do travamento. Apoio global, flexão, torção, estabilidade e demais ações continuam externos. N/M/T diferentes de zero, outra topologia, apoio descontínuo ou caminho arredondado não recebem aprovação silenciosa.

## Exceção delimitada da Tabela 16

A nota da Tabela 16 da NBR, impressa 92 / PDF 114, permite distância inferior à tabulada quando a equação aplicável de 6.3.3.3 atende. A correção qualifica apenas a ponta horizontal real da viga quando o caminho reto de contato e blocos já está implementado. Não há dispensa geral de bordas.

São exigidos todos os contatos por furo, a soma normativa e todos os prefixos de bloco L nos sentidos aplicáveis. A geometria válida, as dimensões reais, os identificadores, as fórmulas, as capacidades e o caso governante ficam no registro `geometry.table16_exceptions`. A comparação tabulada é conservada como `nominal_passed=False`; a aprovação do detalhe depende da qualificação explícita. Caminho ausente mantém o detalhamento não atendido com sua lacuna; furo atravessando a borda permanece geometria inválida; qualquer falha resistente continua bloqueando.

No caso M20, g=45 mm e folga=20 mm, a ponta real fica a 25 mm em vez dos 26 mm tabulados. A força é vertical: os ligamentos de contato são 46,5 mm no extremo e 38 mm entre furos, nunca 25−dh/2. Para |V|=100 kN, os contatos individuais são 25 kN contra 115,20/109,44 kN; a soma normativa é 443,52 kN. O bloco usa a ponta horizontal: Ant=(25−24/2)×7,2=93,6 mm², e o bloco completo resiste 252,24 kN. O primeiro escoamento do recorte, com braço 150 mm, continua governando a ligação em 218,353636 kN. Para ±500 kN, contato e bloco falham e a exceção não se qualifica. Não há arredondamento para 26 mm nem alteração de resistência.

## Integridade e apresentação

Toda exportação pública Word/SVG/PNG reavalia canonicamente a entrada atual, inclusive resultado ausente, de outra entrada, incompleto ou adulterado. A memória identifica abas parafusadas junto à viga e ao apoio, sem rótulos soldados da R015. Vinte e dois envelopes próprios preservam todos os IDs, sentidos, máximos reais/adotados, governantes, empates e falhas, com desenvolvimento individual completo. Mecanismo ausente por domínio não recebe envelope aprovado presumido.

O SVG avulso identifica projeto e V/N/M/T reais com sinal, separados da hipótese V-only. A guarda numérica separa dado inválido, geometria inválida, falha derivada, método pendente, detalhamento e falha resistente finita. A interface retira elegibilidade antiga antes de converter ou serializar o novo estado. NaN, infinito, booleanos e números não representáveis pelos controles são rejeitados atomicamente, com o campo informado. Importações usuais e perfis personalizados continuam fiéis.

## Fontes efetivamente conferidas

- PADRÃO DE LIGAÇÕES-2Model, R017, impressa 20: topologia parafusada, G, L, N×s e dois R15. A folha não contém tabela métrica de e/s. Os valores herdados da tabela R016, impressa 19, são um preset adotado para a montagem R017; as dimensões reais não foram alteradas para fingir uma tabela R017 inexistente.
- Gerdau, Ligações para Estruturas de Aço, 7ª edição, 2018, pp. 19–20 e 23–27: geometria e mecanismos. Valores históricos NBR 2008 não substituem coeficientes atuais. O estudo de 170 mm não é teto universal; a discrepância histórica de 266 kN na p.33 versus 233,950 kN de primeiro escoamento permanece sem reconciliação exata e não é alvo de calibração.
- NBR 8800:2024, versão corrigida 2025: componentes, furação, contato dirigido pela força, Tabelas 14/16, cisalhamento e blocos / Figura 16(b). Tabela 16 e sua nota conferidas visualmente.
- Dowswell e Whyte (2014), Local Stability of Double-Coped Beams, Engineering Journal 51(1), pp. 43–52. PDF integral de 10 páginas recuperado, com pp. 43–46 e Figura 1 inspecionadas. Fonte primária: https://ej.aisc.org/index.php/engj/article/download/1055/1054/1054 . O domínio antigo e as contenções corroboram a rota implementada; a proposta plástica ampliada é outra rota.
- P901-23W completo: II.A-4, impressas IIA-67 em diante, é uma ligação parafusada de recorte somente superior. II.A-8 tem vigas de ambos os lados. São referências de mecanismos, sem validade como oráculo integral desta R017 de recorte duplo. Souza, exemplo 10.1, também não constitui esse oráculo.

## Aceite e limites da validação

Repetição finita dos 23 fixtures e 13.624 comparações independentes, preservando números resistentes e modificando apenas a qualificação explícita aplicável. Matriz da exceção ±100/±500 kN, controles de pré-requisitos, estado numérico, contrato canônico, envelopes, AppTest com uploader e bytes de download reais, mais renderização delimitada de Word/SVG. O relatório de implementação registra comandos e contagens finais. Nenhuma suíte completa, Chromium, qualificação estrutural global, expansão de catálogo ou nova família integra este aceite.
