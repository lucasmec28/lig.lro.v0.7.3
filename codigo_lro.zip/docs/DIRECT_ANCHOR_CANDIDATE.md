# Contato direto placa e chumbador

Candidata local de revisão de 17/10/2026. A EN 1993-1-8 é um complemento explicitamente selecionado. Não se declara conformidade integral da ligação com a EN nem aprovação da fundação. Os arquivos e rotas anteriores foram preservados.

## Resultado por família

- I/H Tipo 2, quatro furos internos: composição nominal delimitada de N/V com introdução real na placa e SCI P358 Check 9. O comprimento hp é o trecho físico contínuo comum da alma, nunca o comprimento total L da placa. Inclui seções bruta/líquida, bloco completo, flexão no plano quando aplicável e todos os prefixos laterais. Exceder um limite suficiente não prova isoladamente ruptura física. Só há atendimento da rota quando todas as demais verificações e domínios também atendem.
- I/H Tipo 1, quatro furos externos: composição nominal SCI P398 e cortes/blocos reais. A candidata restringe a aplicação ao envelope opcional de placa basal robusta descrito abaixo. Ações N/M e verificações existentes permanecem na combinação original. Não há modelo membranar próprio.
- Nas duas famílias simples, tração positiva em qualquer haste conserva pendente a transferência axial local por arruela/porca superior, ainda não calculada nesta composição. O atendimento mostrado nos exemplos favoráveis não libera automaticamente casos com levantamento. Arruela não soldada jamais recebe crédito lateral.
- Base nervurada: rota separada N+M+V com componentes normais publicados P398/P207, nervuras e seus receptores reais, consumidores integrais de V, EN haste/bearing, ACI em todos os estados e componente nominal da placa externa. O envelope opcional pode fechar esse escopo sem retirar o benefício das nervuras em N/M. Arruela superior é verificada somente para sua função axial. O exemplo de referência mantém as dimensões e ações originais e atende ao escopo selecionado. Não aprova fundação, solo, execução, estabilidade global ou rigidez rotacional.
- Bases U de duas/quatro hastes: haste, bearing, ACI e introdução local são calculados quando os dados permitem, mas a transferência completa da placa ainda não está qualificada. Continuam parciais, com pendência explícita e exportável.

Famílias I/H reconhecidas: W, HP, CS, CVS, VS e Soldado, com as verificações de geometria e integridade aplicáveis. Uma assinatura documental atual não transforma outro perfil em I/H, nem comprova o conteúdo da memória informada.

## Como selecionar

Bases clássicas: Caminho resistente → Chumbadores → modelo Contato direto placa–chumbador, EN complementar. A rota de arruela soldada continua independente.

Nervurada: menu Base nervurada · N + M + V · direta · revisão. A rota anterior N/M conserva sua restrição original V=0. Os exemplos são carregados somente por ação explícita. Seus registros são demonstrações, não certificados de produtos ou do projeto real.

## Hastes, materiais, estados e concreto

EN §6.2.2: VRd=min(F1,Rd,F2,Rd). A redução de rosca e de junta longa, quando aplicável, fica em F1; não se multiplica F2 silenciosamente pelo mesmo redutor. Bearing da placa é independente e usa cada furo real, inclusive os inativos no estado. Interação tração/corte usa as trações concomitantes reais, incluindo os efeitos normais já calculados.

Quatro hastes em duas linhas exigem três estados únicos: uniforme, linha dianteira e envelope conservador da linha oposta. Os núcleos conferem as distribuições, não apenas o equilíbrio global. O envelope oposto é uma precaução do aplicativo, não regra literal atribuída ao DG1. ACI recebe esses mesmos estados e trações. Os aços reais substituem o antigo fy=250/fu=400 fixo no ramo direto.

Fatores independentes: EN γM2=1,25 para haste/bearing e blocos EN; EN γM0=1,00 nos componentes de seção; NBR γa1=1,10 e γa2=1,35 nos modos NBR; ACI φ e demais reduções próprias, inclusive corte sobre graute. Capacidades de sistemas diferentes não são somadas. Não há atrito, chave ou engaste fictício da haste nesta rota.

A36 não equivale automaticamente a aço EN. O protocolo complementar exige norma/edição, fabricação final, qualidade, ductilidade, rastreabilidade e aceite específico. UNC não é proibida por simples ausência de rosca métrica: são exigidas área As, propriedades e geometria verificáveis. Áreas calculadas por ASME não são certificados. Dados antigos não recebem qualificação automática.

## Domínio físico inicial

Graute integral curado, sem stand-off/bainha livre; 0<tg≤40 mm; resistência do graute ≥max(fck concreto,30 MPa), além dos limites NBR da família. Furos circulares normais, sem rasgos ou alargamento: folga diametral ≤2 mm para d≤24 mm e ≤3 mm acima, conforme o protocolo complementar implementado. Impacto, fadiga e torção não são liberados.

Contornos físicos de furos, filetes e arruelas devem caber sem interferências. A largura da arruela precisa exceder o furo e permanecer dentro da placa; isso é geometria, não comprovação da resistência axial. A perna física do filete, e não só a garganta ou distância de charneira, é usada nas interferências. CJP não ganha filete fictício.

ELS: d0−d é apenas folga geométrica, não deslocamento total calculado, limite superior ou promessa de δ=0. Exigência de não deslizamento ou de deslocamento total numérico fica pendente.

## Placa externa e envelope opcional do aplicativo

Geometria calculada: placa monolítica retangular, quatro furos simétricos (±a,±g/2), linhas além das mesas, eixos transversais dentro das pontas das mesas, distâncias e espaçamentos EN, fonte horizontal real da alma fora das bandas laterais. A restrição transversal decorre dos padrões de linhas de plastificação efetivamente avaliados no P398 p.70, não da exigência de copiar dimensões de um exemplo.

A composição conserva N/M em seus componentes próprios e V integral na alma, sem atribuir V às nervuras. Os cortes nominais são: duas bandas laterais reais; prefixos de uma/duas hastes por banda; seção normal e bloco da dupla somente na linha externa tracionada pelo sentido de V. Não se inventa barra comprimida para a linha oposta. Furos inativos permanecem nas áreas líquidas. NBR na banda usa dedução d0+2 mm conservadora, sem presumir fabricação por furação; componentes EN usam d0. O fator 0,5 dos blocos é limite suficiente conservador. L é comprimento geométrico do corte, nunca hp ou largura efetiva criada.

Como limite opcional desta implementação, a placa basal sem crédito das nervuras precisa resistir à tração nominal não reduzida da dupla de hastes. São avaliados os quatro padrões não circulares e dois circulares da Tabela 5.3 do P398 com as dimensões reais, mx=a−d/2−0,8z e leff mínimo. A referência da dupla é 2×0,9fuAs/1,25, sem redução kthread para ampliar o domínio. Essa condição não é exigência normativa geral de bases nervuradas; não substitui Ti real; não remove benefício resistente das nervuras em N/M; e capacidade de tração NÃO implica capacidade de V. V é verificado pelos consumidores próprios acima. Fora do envelope significa escopo não qualificado por esta implementação, não falha física automática.

As restrições existentes dos componentes nervurados são preservadas: nervura longa no domínio adotado, bordas efetivamente conectadas, geometria de pé/raiz e receptor real, fan de compressão contido, parâmetros das linhas de plastificação no intervalo publicado, estabilidade e conexões internas. Nenhuma guarda foi apagada para aprovar o caso.

## Exportação e limites de conclusão

Cobertura calculada e atendimento resistente são estados distintos. Falhas, pendências, domínios e entradas reais permanecem exportáveis em Word/JSON. Atendimento da rota nominal delimitada não equivale a aprovação integral da construção. Bloco armado, fendilhamento/detalhamento global, fundação, solo e verificação global do pilar exigem projeto próprio.

## Referências verificadas

EN 1993-1-8:2005 corrigida, §§3.3,3.6.1/Tabela3.4,3.7,3.8,3.10.2,3.12,6.2.2; EN 1993-1-1 §6.2.3; SCI P358 Check9 p.23; SCI P398 pp.64,70–72 e Tabela5.3; SCI P207 §6.8; AISC Design Guide1 3ª edição; NBR8800:2024 corrigida2025; ACI318-19 nos componentes retidos. P398 e DG1 não excluem toda base nervurada: as limitações são de fórmulas/padrões específicos, não proibição geral do domínio.

## Revisão editorial da memória N/M/V

O Word apresenta cobertura por componente e critérios governantes por família, modo, fonte e unidade. Toda falha ou pendência continua individualizada. IDs C0001 em diante remetem à ordem da lista checks_flat no JSON completo, disponível como anexo opcional. As fontes e resultados resistentes estão preservados; a exportação lê os resultados armazenados, sem nova análise. Exemplos de estudo são ilustrativos e não representam dados reais do usuário.
