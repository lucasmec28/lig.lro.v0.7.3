# Emenda W soldada CJP para vigas ou pilares — 0.9.23

## Domínio local e identidade

Décima quarta família, independente das emendas parafusadas M004 e convencional. Dois W laminados iguais, alinhados em seus eixos e planos, sob N assinado (tração positiva), M no eixo principal (tração em y positivo) e V no plano da alma. Na face +x do membro A, N positivo aponta em +x e V positivo em −y; M positivo é o binário coerente com σ=N/A+My/I e M(x)=M0−Vx. Na vista de viga, +y aponta para a mesa inferior, V positivo para cima e M positivo é anti-horário. A face oposta tem os vetores opostos. A seleção viga/pilar só muda a orientação de apresentação. As ações já são de cálculo, estáticas, de combinações últimas normais. Unidades nativas: N, mm, MPa, N mm.

Não há crédito de contato de topo, solda PJP, backing, abas de saída, cantoneiras ou parafusos de montagem. Torção, momento no eixo fraco, cortante transversal, fadiga, impacto, sismo e diferenças medidas de alinhamento/seção ficam fora do domínio; nunca são zerados silenciosamente. Diferença de designação dos perfis também bloqueia. Materiais iniciais: ASTM A572 Gr.50 e ASTM A992, fy345/fu450 MPa, γa1=1,10 e γa2=1,35, SMAW/E7018 com procedimento aplicável declarado.

O cálculo é local. A estabilidade global/lateral, classificação e instabilidade flexional do membro íntegro, comprimentos, travamentos, segunda ordem, montagem e verificação do sistema pertencem ao projeto dos membros/sistema. Isso não retira os controles locais abaixo.

## Fontes e interpretação

- ABNT NBR 8800:2024, Errata1:2025: 6.1.1–6.1.5 (ações, componentes, equilíbrio/compatibilidade, mínimos); 6.1.12–6.1.13 (perfis pesados e acesso); 6.2.2.1,6.2.4–6.2.5/Tabelas8–9 (CJP, materiais, comprimento/garganta reais); 6.2.6.1 (PJP); 6.5.1/.3/.4/.5 (recebedores); 5.4.3.1 (cortante da alma adjacente); 12.2.1.2/Figura25 e12.2.1.7.5 (execução e diferenças).
- Fakury, Castro e Silva e Caldas, Dimensionamento de Elementos Estruturais de Aço e Mistos de Aço e Concreto, parte4, pp275–277,10.10.2–10.10.3.1: Eqs10.19–10.22 e10.23–10.27. Método mecânico explicativo; critérios atuais de material/detalhe são da NBR2024 corrigida.
- Gerdau, Manual Ligações, pp189–194: precedente construtivo EP1/EP2, sem transferência de capacidade das peças auxiliares para esta emenda direta. Cantoneira de posicionamento não garante estabilidade de montagem.
- AISC DG21(2006),3.9.2 e3.12.1: explicação de CJP e acesso. Não se importam coeficientes resistentes AISC.

A qualificação e a revisão independente inspecionaram as páginas originais fornecidas. O método é um campo NOMINAL elástico do grupo CJP, não tensão física máxima no contorno das aberturas. Não se exige um modelo FEM inventado; também não se afirma que equilíbrio sozinho prova qualquer detalhe real.

## Geometria executável e desenho

Seções formadas por três retângulos coerentes: duas mesas bf×tf, com inércia própria mantida, e alma tw×(d−2tf−2H0). H0 é a profundidade removida de cada abertura junto ao plano da junta, medida desde a face interna da mesa. Não é a altura da alma remanescente. A área de catálogo não substitui a área conectada; os filetes de raiz não recebem crédito de área/inércia.

As aberturas superior/inferior de cada lado são espelhadas. Os lados A/B podem ter L/Hmax/R próprios, mas compartilham H0 na junta. A curva analítica é uma construção finita das alternativas1/2 da Figura25: círculo de centro(L−R,Hmax−R), tangente superior desde(0,0), tangente inferior desde(0,H0), e arco direito entre elas. O desenho usa a mesma função geométrica. Requer tangentes reais, pontos dentro do envelope, inclinação superior positiva, Hmax≥H0, L≥2R e Hmax>2R. Alternativa3 não é atribuída a W laminado.

Controles: H0≥20mm e H0>tw; L≥40mm e L>1,5tw; R≥10mm; H0 libera o raio/k real mais folga declarada. A altura plana da alma deve ser d−2tf−2r. Geometria usada: H0=Hmax25mm,L45mm,R10mm,raio de raiz16,1mm e folga2mm. São dimensões declaradas do exemplo, não uma WPS ou medição certificada. R12,5 não é universalmente proibido; com Hmax25 ele produz tangente superior horizontal, fora deste ramo inclinado específico.

O domínio inicial curto exige L≤max(45mm;1,5tw+5mm;2R+5mm), Hmax≤50mm e nenhuma alteração adicional das mesas/seções. Esse teto longitudinal é uma escolha explícita de implementação, NÃO um máximo normativo NBR ou proibição universal de detalhes maiores. Rasgos maiores ficam fora desta rota, sem supor que a verificação global do membro os resolva. tf>50mm é identificado como perfil pesado fora do detalhe qualificado inicial; não recebe resultado global favorável, pois requer tenacidade/preparo adicionais. Não se usa o limiar antigo de44mm.

Comprimento e garganta CJP declarados devem coincidir com toda a largura/espessura das duas mesas e toda a alma remanescente. Diferenças bloqueiam por detalhamento, mostram medidas declaradas/exigidas e suspendem as verificações resistentes. Não se publicam capacidades hipotéticas da seção integral para uma solda incompleta.

## Campo nominal no plano da junta

Aew=ΣAi; Ix=Σ(Ii,própria+Ai·yi²), incluindo inércia própria das mesas. σ(y)=N/Aew+M·y/Ix; τ=V/Aew assinado. Cada extremidade de cada retângulo recebe:

- |σ|≤fy/γa1
- |τ|≤0,60fy/γa1
- sqrt(σ²+3τ²)≤fy/γa1 quando ambos coexistem

O terceiro é critério suplementar de Fakury10.27, não uma equação da Tabela9 atual. Integração exata por região recupera N,M,V, sem momento no eixo fraco ou torção espúrios. Tolerância escalada:1e−9×max(1,|ação|,Σ|resultantes das regiões|). A fração de V calculada para a solda da alma nunca substitui o V integral exigido do recebedor.

## Recebedores em série

Cada membro possui seu envelope nominal separado: Amin e Imin dos retângulos remanescentes após a remoção máxima Hmax. A(x)≥Amin e I(x)≥Imin para a geometria simétrica especificada. Sem cargas adicionais dentro da abertura, M(x)=M0−Vx, x∈[−La,0] ou[0,Lb], logo |M(x)|≤|M0|+|V|L. Não se somam capacidades dos membros A/B.

1. Envelope nominal da seção: σf,b=|N|/Amin+(|M|+|V|L)(d/2)/Imin, τgrupo,b=|V|/Amin; normal, cisalhamento e interação suplementar.
2. Controle nominal independente da alma: σw,b=|N|/Amin+(|M|+|V|L)(d/2−tf)/Imin e τw=|V|/Aw,min; normal/cisalhamento/interação. Esse campo de controle não é apresentado como uma segunda solução de equilíbrio ou tensão máxima física.
3. V integral≤min(0,60fyAgv/γa1;0,60fuAnv/γa2), com Agv=Anv=Aw,min real reduzida. A fração de V do grupo não entra aqui.
4. A alma íntegra adjacente usa NBR5.4.3.1, h plano/tw,kv5,34,Aw=d·tw,λp1,10sqrt(kvE/fy),λr1,37sqrt(kvE/fy) e os três ramos normativos. É controle separado da alma reduzida.

Com estes aços e mesmas Ag=An=Ae, fy/1,10=313,636MPa<fu/1,35=333,333MPa: escoamento governa ruptura. Essa dominância, áreas e resistências ficam registradas, sem inventar desconto0,85Ag de emenda parafusada ou bloco de cisalhamento de parafusos inexistentes.

Quando algum caso tem N<0, este primeiro ramo exige seção íntegra não esbelta conforme NBR5.3.4.1/Tabela4: bf/(2tf)≤0,56sqrt(E/fy),hplano/tw≤1,49sqrt(E/fy), grupos4/2, dimensões5.1.2.2.3/.4. É restrição de domínio para compressão axial, não falha resistente universal, compacidade à flexão ou prova de estabilidade de aberturas arbitrárias. Não se aplica apenas porque a orientação é pilar ou uma borda está comprimida por M. O detalhe padrão curto não cria colunas fictícias independentes de mesa/alma.

## Casos, mínimos e condições declaradas

Todos os casos reais assinados são conservados. Convenção existente do aplicativo para6.1.5.2: se0<hypot(N,V)<45kN, acrescenta-se caso independente com(N,V) escalados uniformemente até45kN na mesma direção/sentido e M independente inalterado. A convenção é uma interpretação declarada de força resultante, não fórmula impressa na cláusula. R=0 não inventa direção ou momento mínimo. A recomendação proporcional à resistência do membro de6.1.5.3 permanece discricionária; não se exige cálculo global fictício. A declaração de integridade confirma inclusão dos casos aplicáveis pelo responsável.

Os exemplos começam NOT_VERIFIED. Números favoráveis não removem ausência de certificado de material, compatibilidade, WPS identificada/qualificada, plano de inspeção, geometria medida, corte/qualidade, acesso à raiz, alinhamento e casos de integridade. Essas declarações são entradas do responsável, não auditoria independente do documento pelo programa.

## Contrato nativo e saídas

JSON próprio schema1, connection_type=welded_w_splice, versão do componente0.9.23. Todos os campos, unidades e premissas são obrigatórios. Campos desconhecidos/omitidos, booleanos no lugar de números, NaN/Infinity, casos malformados, identificadores repetidos/reservados e unidade/família incompatível são rejeitados atomicamente. Não migra para emenda parafusada. A UI usa estado isolado wws_, mantém rascunhos por família e preserva valores nativos exatos de esforços sem edição. Mudança de entrada invalida Word anterior.

SVG/PNG/Word recalculam a entrada atual em cada API pública; resultados fornecidos pelo chamador não têm autoridade. Envelopes agrupam somente componente/mecanismo e preservam casos/governantes/empates e todas as testemunhas. O Word detalhado inclui os dados completos. Desenhos são ilustrativos locais e não desenhos de fabricação.

## Controle numérico reproduzível

W310×97,d308,bf305,tf15,4,tw9,9,H025mm: Aew11643,28mm²,Ix210927543,422933mm⁴,Aw2249,28mm². Para N−600kN,M+120kNm,V+100kN: índice de grupo0,446178589; alma receptora sob V integral0,236253808. O envelope nominal adicional da alma com normal+V governa o conjunto em0,490946350. PureV500kN passa no grupo(0,228200716) mas falha na alma reduzida(1,181269042). Esses controles não aprovam fabricação ou uma WPS.

Validação final, contagens únicas e revisões independentes: VALIDACAO_PACOTE0923.json. A versão é de desenvolvimento técnico, sem alteração dos13 motores anteriores ou da variante4ES.
