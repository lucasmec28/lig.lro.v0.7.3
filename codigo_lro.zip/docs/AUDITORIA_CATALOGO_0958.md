# Situação das ligações existentes

Revisão de 15/10/2026. Foram identificadas 25 famílias no menu e testada a abertura de todas, sem exceções nessa verificação. Também foram executados os exemplos cadastrados para observar os estados reais do cálculo.

“Escopo local disponível” significa que existe uma rotina delimitada e exemplos que atendem às suas verificações. Não significa aprovação de qualquer geometria, fabricação, montagem ou estabilidade global. Um exemplo reprovado pode ser um teste intencional; não indica necessariamente defeito do aplicativo.

| Nº | Família | Situação observada | Limite ou próximo ajuste relevante |
|---|---|---|---|
| 1 | Single plate | Escopo local disponível na mesa de coluna; exemplos na alma de viga permanecem parciais | Separar claramente apoio e ações admitidos. Complemento e enrijecedor oposto não recebem crédito automático. Há exemplo intencionalmente reprovado. |
| 2 | Alma de coluna com duas talas | Parcial | Exemplos de tração/compressão calculam componentes, mas não concluem o conjunto local. Nervura interna perfurada exige caminho pelos ligamentos até soldas/receptores. Exemplo inicial da planilha tem geometria inválida. |
| 3 | End plate rotulada de altura total | Parcial | N/V calculados; faltam qualificação local da distribuição, efeitos de rotação nos parafusos/soldas e caminho pelas mesas. Não confundir com estabilidade global. |
| 4 | End plate engastada | Escopo local disponível nas variantes cadastradas | Exemplos 4E, 4ES, 8ES e MRE12_U atendem. Respeitar domínio de cada variante, juntas CJP onde exigidas e limites para linhas adicionais. |
| 5 | Placa de base W engastada | Componentes locais disponíveis, conforme dados/opções | Há exemplos atendidos, um exemplo com cortante de resistência externa pendente e outro com falha resistente. Ancoragem depende dos dados físicos e do método ativado. |
| 6 | Placa de base W rotulada | Componentes locais disponíveis, conforme dados/opções | Exemplos com atrito e arruelas soldadas atendem; exemplo com chave apresenta falha resistente. Quatro chumbadores internos e N/V sem momento externo. |
| 7 | Placa de base U rotulada | Exemplos iniciais com condições pendentes | Dois ou quatro chumbadores. Nos exemplos, comprimento reto entre raízes/acesso ainda precisa confirmação; tração também tem hipóteses/dados ACI pendentes. Simplificar entradas sem transformar dimensões nominais em medições reais. |
| 8 | Emenda W M004, tração axial | Escopo local disponível com desvio do exemplo de referência indicado | Tração estática, perfis iguais/coaxiais, oito talas. Exemplo tem borda diferente do preset de referência, registrada; perfil estreito de teste é inválido. Não admite N/M/V geral. |
| 9 | Emenda W convencional N/M/V | Rotina disponível; exemplos aguardam escolha de política de projeto | Declarar uso da recomendação de resistência do membro ou ações de projeto, separando essa escolha do mínimo obrigatório. Deslizamento ELS é verificação própria. Há exemplo de falha resistente. |
| 10 | Cantoneiras duplas R016, parafusadas | Escopo local disponível | Exemplos de V positivo/invertido atendem; carga elevada reprova. Duas cantoneiras na alma de viga sem recorte, parafusadas à mesa de coluna. |
| 11 | Cantoneiras duplas R015, soldadas/parafusadas | Escopo local disponível | Cantoneiras soldadas à viga e parafusadas à mesa de coluna. V estático; exemplo de carga elevada reprova. |
| 12 | Cantoneiras duplas R017, viga recortada | Modelo condicionado a dado de travamento | Exemplos aguardam qualificação do travamento junto ao recorte. Verificar se é requisito local do modelo empregado e apresentar como tal, sem pedir análise global inteira. |
| 13 | Ligação axial 2L–chapa, parafusada | Escopo da extremidade disponível | Tração no modelo nominal. Verifica cantoneiras/parafusos/chapa; não inclui raiz da chapa nem apoio a jusante. Não apresentar como gusset completo. |
| 14 | Ligação axial 1L–chapa, parafusada | Escopo da extremidade disponível | Tração e modelo nominal explicitado; excentricidades físicas não são automaticamente canceladas. Raiz/apoio a jusante ficam fora. |
| 15 | Emenda W soldada N/M/V | Rotina condicionada a declarações e procedimento | Exemplos permanecem não verificados enquanto materiais, juntas, geometria e procedimento de soldagem não forem declarados. Há caso específico de falha da alma. Melhorar agrupamento dessas confirmações. |
| 16 | 1L–gusset–mesa W soldada | Escopo local disponível em tração | Exemplos Gerdau e legado atendem dentro de seus limites; não restringir indevidamente o guia a L100×100×12. Compressão fora desta rota. |
| 17 | 2L em T–gusset–mesa W soldada | Tração local disponível; compressão condicionada | Exemplos tracionados atendem. Exemplo comprimido contém falhas e vínculos pendentes; não generalizar aprovação da tração para compressão. |
| 18 | 2L opostas pelos vértices–gusset–mesa W soldada | Escopo local disponível em tração | Geometria própria, quatro filetes; não equivale ao arranjo T. Compressão/ações espaciais não admitidas pela rota. |
| 19 | 1L/2L-T/2L opostas–gusset–mesa W parafusada | Escopo local disponível nas topologias admitidas | Exemplos 1L/2L-T atendem; conferir geometria de talão/ferramenta e raiz. Par oposto usa distribuição e contagem de parafusos distintas. |
| 20 | Gusset de canto viga/pilar | Escopo local disponível com cortes completos | Exemplos soldados/parafusados atendem. É necessário manter esforços concorrentes de viga/pilar, posição e topologia; compressão só onde a subrota qualificada permite. |
| 21 | Cantoneira simples soldada ao pilar | Escopo local disponível para V descendente | Exemplo V90kN atende; reversão está fora e carga elevada reprova. Não converter apoio na alma sem outro modelo. |
| 22 | Cantoneiras duplas soldadas ao pilar | Escopo local disponível para o estado final | Exemplo V100kN atende. Montagem com segunda cantoneira soldada em campo não é uma fase temporária calculada; manter procedimento de içamento separado. |
| 23 | Viga sobre viga com chapa contínua intermediária | Parcial | Componentes calculados; caminho local da chapa fora do plano permanece pendente. Não confundir com a alternativa de apoio direto já disponível. |
| 24 | Viga sobre viga, apoio direto entre mesas | Escopo local DG6 disponível | Exemplo V2610kgf atende no escopo local DG6 A1(c)/A3. Suplemento NBR tem resultado independente. Par de enrijecedores inferior permanece sem crédito resistente nesta revisão. |
| 25 | Apoios de viga A1(a), A1(e), B1/B9 | Situação varia com a subtipologia | A1(a) direto sem chapa/ancoragem e B1 soldada têm exemplos com caminho metálico atendido. B9 parafusada depende da geometria própria. A1(e) permanece parcial por chapa de topo e introdução na coluna. A2 é detalhe sem crédito resistente. |

## Ajustes já incorporados à cópia em revisão

- Guia de seleção passou a contemplar as 25 rotas, incluindo base U e apoios de viga.
- Descrições alinhadas aos modelos atuais: apoio direto DG6, MRE12_U e cantoneiras do catálogo.
- Na ligação de duas talas, a indicação de escopo incompleto passa a prevalecer sobre a mensagem de interferência. Isso corrige o título sem apagar verificações ou pendências.
- Campos inativos dos assentos receberam tratamento para que opções de outra subtipologia não impeçam o cálculo atual; os dados preservados não devem ser silenciosamente substituídos ao reabrir o projeto.
- O protótipo de cálculo do reforço inferior não integra esta revisão: falta qualificar a transferência de compressão no trecho da chapa antes da primeira solda. O par já desenhado continua sem ganho resistente automático.

## Prioridades para concluir o que existe

1. Fechar um modelo local claramente delimitado para nervura interna com duas talas, end plate rotulada de altura total e chapa intermediária de viga sobre viga. Evitar esconder lacunas com simples alteração de status.
2. Finalizar a chapa de topo A1(e), distinguindo pressão de contato de resistência da chapa e transferência à coluna.
3. Reduzir perguntas repetidas nas bases e nos procedimentos de solda, mantendo visíveis somente dados que alterem o cálculo; premissas propostas precisam aparecer no memorial.
4. Uniformizar resultados: separar resistência, geometria, condição do método e dado faltante. “Não atende” não deve significar indistintamente todas essas situações.
5. Conferir desenhos, dados, unidades e tabelas como um conjunto antes de cada nova entrega.

Esta varredura identifica disponibilidade e lacunas. Não substitui a conferência independente das equações, dos domínios normativos ou dos dados reais de um projeto.

## Resultado dos testes desta revisão

A suíte principal registrou 4.921 testes aprovados, 266 subtestes aprovados e um teste omitido. O lote restante concluiu 84 arquivos: 1.934 aprovações e cinco falhas por dependência de uma pasta histórica .37 indisponível. O teste histórico foi preservado; um contrato novo e explicitamente identificado compara os cinco casos com a .57 entregue, com 24/24 testes no arquivo revisto. No conjunto atual são 6.860 testes e 266 subtestes aprovados. A comparação histórica .37 não foi reproduzida. Estes números demonstram regressão de software, não aprovação estrutural das ligações.
