# Validação da fonte 0.9.35

Decisão: GO do ramo local delimitado, com a indisponibilidade histórica de um oráculo externo explicitamente preservada. Esta decisão não libera fabricação, estabilidade global, upload ou implantação.

## Testes efetivamente executados

A suíte completa foi dividida em quatro grupos sem sobreposição: 5.270 casos distintos em 145 arquivos. Resultado: 5.269 aprovados, um teste falhou por ausência do oráculo externo histórico de contato de parafusos, zero erros e zero pulados. O teste indisponível não foi contabilizado como aprovado nem substituído por um oráculo inventado.

Os grupos tiveram 1.370/1.370, 1.085/1.085, 1.116/1.117 e 1.698/1.698 casos aprovados. O livro de casos e os quatro JUnit/logs originais estão em `validation0935/`.

O runtime não permaneceu byte a byte idêntico durante toda a agregação: somente `lro/corner_gusset_drawing.py` mudou para distinguir geometria vinculada de contenções físicas desconhecidas/ausentes no rodapé de um desenho isolado. Os hashes inicial e final estão preservados, sem reescrever o registro bruto. Motor, demais arquivos runtime e testes ficaram estáveis.

Depois desse ajuste, os 115 testes dos arquivos afetados foram reexecutados nos bytes finais: 72 testes do motor de compressão e 43 de UI/artefatos, todos aprovados. São os mesmos nós presentes na agregação e não se somam aos 5.270. O replay independente final verificou 22 cenários de saídas realmente emitidas, incluindo dois desenhos com geometria atual e contenção pendente; as 20 saídas anteriormente aceitas ficaram idênticas.

## Revisões independentes

O aceite independente de motor verifica 234 comparações de referência, 2.394 comparações runtime e 566 observações adversariais em 134 cenários. O conjunto focal de fonte passou 236 testes, incluindo os 72 novos, com contagem sobreposta à suíte. Foram preservadas 141 observações completas antigas e revisadas 15 mudanças expressamente delimitadas. Não há declaração de paridade total para casos negativos ou pequenos esforços soldados que mudaram de propósito.

O aceite de saídas cobre 22 cenários, oito grupos de callbacks, rejeições atômicas nativas, desenhos PNG/SVG com sinais e memórias Word. Foram revisadas 95 páginas Word; os rodapés pendentes adicionais têm testemunhos próprios. Hashes e detalhes exatos estão nos recibos `independent_engine0935/ENGINE_ACCEPTANCE0935.json` e `independent_outputs0935/SOURCE_OUTPUT_ACCEPTANCE.json`.

## Resultados preservados

CC1: chapa comprimida atende com η=0,277232, mas o limite superior conservador do receptor é η=1,018851 e a ligação permanece FAIL. CC2: η do receptor=0,848249, PASS no detalhe local declarado. CC3: η da chapa=2,178748, falha do receptor mantida e qualificação de serviço pendente acima de Le/r=200. Nenhum exemplo é uma aprovação de fabricação.

Os casos reais e seus cortes completos permanecem separados do mínimo sintético assinado de 45 kN. O adendo de método registra que aplicar esse mínimo aos ramos soldados corrige uma omissão anterior; zero adota +45 nominal em tração explicitamente, sem atribuir esse sentido à cláusula normativa.

## Limites da entrega de fonte

Compressão 1L/parafusada, estabilidade global, sismo/fadiga e execução permanecem fora do ramo. A verificação da extração APP e sua igualdade com a fonte congelada ocorre em etapa separada. A única indisponibilidade de teste é o arquivo histórico externo `next_connection_scope/bolt_bearing_oracle.json`, já ausente na versão anterior.
