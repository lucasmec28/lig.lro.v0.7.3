"""Fresh acceptance calculator: standard-library only; no production imports.
Derived from the frozen contract and elementary segment/section mechanics.
Coordinate transformation and interval arithmetic are implemented independently.
"""
import math
from copy import deepcopy

BASE=dict(P=100000.,count=1,phi=45.,ec=154.,eb=158.5,w=300.,h=300.,t=12.,clip=30.,
          beam_start=10.,beam_end=10.,column_start=10.,column_end=10.,
          stations=[370.,430.,490.,550.],db=16.,dh=18.,drilled=True,g=40.,e_end=35.,
          angle_b=76.2,angle_t=7.94,angle_A=1148.,angle_ec=22.1,angle_fy=250.,angle_fu=400.,
          gusset_fy=250.,gusset_fu=400.,fub=830.,threads=[False,False],washers=0.,pretension=False,
          gamma1=1.1,gamma2=1.35,beam_cut=[1000.,0.,-30710.67811865475,-50000.,62300000.],
          upper_cut=[0.,1000.,10000.,-500000.,10000000.],lower_point=[0.,-1000.])

def setup(**kw):
 p=deepcopy(BASE);p.update(kw);p['r']=(p['dh']+(0 if p['drilled'] else 2))/2
 q=math.radians(p['phi']);p['c'],p['s']=math.cos(q),math.sin(q)
 ec,eb,w,h,k=p['ec'],p['eb'],p['w'],p['h'],p['clip']
 p['polygon']=[[ec+k,eb],[ec+w,eb],[ec+w,eb+h],[ec,eb+h],[ec,eb+k]]
 p['supports']={'beam':[p['polygon'][0],p['polygon'][1]],'column':[p['polygon'][3],p['polygon'][4]]}
 p['seams']={'beam':[[ec+k+p['beam_start'],eb],[ec+w-p['beam_end'],eb]],'column':[[ec,eb+k+p['column_start']],[ec,eb+h-p['column_end']]]}
 p['uv']=[uv(p,pt) for pt in p['polygon']]
 p['alpha']=sum(pt[0] for pt in p['seams']['beam'])/2-ec
 p['beta']=sum(pt[1] for pt in p['seams']['column'])/2-eb
 H,V=p['P']*p['c'],p['P']*p['s'];Hc=ec*V/(eb+p['beta']);Hb=H-Hc;Vb=eb*Hb/p['alpha'];Vc=V-Vb
 p['roots']={'beam':[-Hb,-Vb],'column':[-Hc,-Vc]};p['ufm']={'H':H,'V':V,'Hb':Hb,'Vb':Vb,'Hc':Hc,'Vc':Vc}
 return p

def uv(p,pt):return [pt[0]*p['c']+pt[1]*p['s'],-pt[0]*p['s']+pt[1]*p['c']]
def xy(p,pt):return [pt[0]*p['c']-pt[1]*p['s'],pt[0]*p['s']+pt[1]*p['c']]
def cross(a,b):return a[0]*b[1]-a[1]*b[0]

def chord(p,axis,value):
 vals=[];other=1-axis
 for a,b in zip(p['uv'],p['uv'][1:]+p['uv'][:1]):
  d=b[axis]-a[axis]
  if abs(d)<1e-10:
   if abs(a[axis]-value)<1e-7:vals.extend([a[other],b[other]])
  else:
   f=(value-a[axis])/d
   if -1e-9<=f<=1+1e-9:vals.append(a[other]+f*(b[other]-a[other]))
 return [min(vals),max(vals)] if vals else None

def segment_interval(a,b,constraints):
 """Parameter interval satisfying independent linear lower/upper coordinate bounds."""
 lo,hi=0.,1.
 for axis,bound,direction in constraints:
  v=(a[axis]-bound)*direction;d=(b[axis]-a[axis])*direction
  if abs(d)<1e-12:
   if v < -1e-8:return None
  elif d>0:lo=max(lo,-v/d)
  else:hi=min(hi,-v/d)
 if lo>hi+1e-10:return None
 return max(0.,lo),min(1.,hi)

def support_hits(p,u,side):
 constraints=[(0,u,1)]
 if side=='negative':constraints.append((1,0.,-1))
 elif side=='positive':constraints.append((1,0.,1))
 else:constraints.extend([(1,-p['r'],1),(1,p['r'],-1)])
 out={}
 for name,seg in p['supports'].items():
  a,b=[uv(p,x) for x in seg];iv=segment_interval(a,b,constraints)
  if iv and iv[1]-iv[0]>1e-8:out[name]=(iv[1]-iv[0])*math.dist(*seg)
 return out

def captured(p,u):
 r=p['r'];inc=[j+1 for j,x in enumerate(p['stations']) if x+r>=u-1e-8];exc=[j+1 for j,x in enumerate(p['stations']) if x-r>u+1e-8]
 return inc,exc

def block(p,u,side):
 r,t=p['r'],p['t'];lims=chord(p,0,u)
 if not lims:return None
 hits=support_hits(p,u,side);inc,exc=captured(p,u)
 h=sum(math.sqrt(max(0.,r*r-(u-x)**2)) for x in p['stations'] if abs(u-x)<=r)
 if side=='tangent_U':
  exits=[chord(p,1,-r)[1],chord(p,1,r)[1]];gross=t*(sum(exits)-2*u);net=gross;ant=t*(2*r-2*h)
  path=[[exits[0],-r],[u,-r],[u,r],[exits[1],r]]
 else:
  exit=chord(p,1,0.)[1];end=lims[0 if side=='negative' else 1]
  gross=t*(exit-u);net=t*(exit-u-sum(max(0.,min(exit,x+r)-max(u,x-r)) for x in p['stations']));ant=t*(abs(end)-h)
  path=[[exit,0.],[u,0.],[u,end]]
  # A cap at a supported edge interior is inactive. A zero-measure shared free vertex is the free-side limit.
  endpoint=xy(p,[u,end])
  for name,seg in p['supports'].items():
   if abs(cross([seg[1][0]-seg[0][0],seg[1][1]-seg[0][1]],[endpoint[0]-seg[0][0],endpoint[1]-seg[0][1]]))<1e-6 and min(seg[0][0],seg[1][0])-1e-8<=endpoint[0]<=max(seg[0][0],seg[1][0])+1e-8 and min(seg[0][1],seg[1][1])-1e-8<=endpoint[1]<=max(seg[0][1],seg[1][1])+1e-8 and math.dist(endpoint,seg[0])>1e-7 and math.dist(endpoint,seg[1])>1e-7:hits.setdefault(name,0.)
 active=not hits and gross>=0 and net>=-1e-6 and ant>=-1e-6
 ry=(.6*p['gusset_fy']*gross+.5*p['gusset_fu']*ant)/p['gamma2'];ru=(.6*p['gusset_fu']*net+.5*p['gusset_fu']*ant)/p['gamma2'];d=len(inc)*p['P']/len(p['stations'])
 return dict(u=u,side=side,active=active,support_hits=hits,Agv=gross,Anv=net,Ant=ant,Ryield=ry,Rrupture=ru,resistance=min(ry,ru),demand=d,utilization=d/min(ry,ru) if min(ry,ru)>0 else None,path_uv=path,captured_bolts_including_crossing=inc,captured_bolts_excluding_crossing=exc)

def section(p,u,include=True,net=True):
 bounds=chord(p,0,u)
 if not bounds:return None
 low,high=bounds;r,t=p['r'],p['t'];holes=[]
 if net:
  for station in p['stations']:
   if abs(station-u)<r:
    h=math.sqrt(r*r-(station-u)**2);holes.append([-h,h])
 intervals=[];at=low
 for a,b in sorted(holes):
  if b<=low or a>=high:continue
  a,b=max(a,low),min(b,high)
  if a>at:intervals.append([at,a])
  at=max(at,b)
 if high>at:intervals.append([at,high])
 A=t*sum(b-a for a,b in intervals)
 if A<1e-8:return None
 vbar=t*sum((b*b-a*a)/2 for a,b in intervals)/A
 I=t*sum((b**3-a**3)/3 for a,b in intervals)-A*vbar*vbar
 F=[0.,0.];MO=0.;sources=[]
 def add(name,point,force):
  nonlocal MO
  F[0]+=force[0];F[1]+=force[1];MO+=cross(point,force);sources.append(name)
 for i,station in enumerate(p['stations']):
  crossing=abs(station-u)<=r+1e-8
  retained=(crossing and include) or (not crossing and station>u)
  if retained:add('bolt'+str(i+1),xy(p,[station,0.]),[p['P']*p['c']/len(p['stations']),p['P']*p['s']/len(p['stations'])])
 for name,seg in p['seams'].items():
  a,b=[uv(p,x) for x in seg];iv=segment_interval(a,b,[(0,u,1)])
  if iv and iv[1]-iv[0]>1e-10:
   mid=(iv[0]+iv[1])/2;point=[seg[0][j]+mid*(seg[1][j]-seg[0][j]) for j in range(2)];force=[v*(iv[1]-iv[0]) for v in p['roots'][name]];add(name+'_root',point,force)
 N=F[0]*p['c']+F[1]*p['s'];V=-F[0]*p['s']+F[1]*p['c'];M=MO-cross(xy(p,[u,vbar]),F)
 stress=[N/A-M*(v-vbar)/I for v in bounds];vm=max(math.hypot(s,math.sqrt(3)*1.5*V/A) for s in stress)
 return dict(u=u,include_cut_hole=include,net=net,chord_v=bounds,A=A,centroid_v=vbar,I=I,hole_half_chord=sum((b-a)/2 for a,b in holes),N=N,V=V,M=M,sigma_edges=stress,nominal_VM=vm,retained_sources=sources)

def primitives(p):
 rows={};n=len(p['stations']);P=p['P'];count=p['count'];ta=p['angle_t'];dn=2*p['r'];Lc=p['stations'][-1]-p['stations'][0]
 def add(id,d,r,**extra):rows[id]=dict(demand=d,resistance=r,utilization=d/r,**extra)
 Ct=max(.5,1-p['angle_ec']/Lc);An=p['angle_A']-dn*ta
 add('angle_gross_each',P/count,p['angle_A']*p['angle_fy']/p['gamma1'])
 add('angle_net_effective_each',P/count,Ct*An*p['angle_fu']/p['gamma2'],Ct=Ct,An=An,Lc=Lc)
 grip=p['t']+count*ta+p['washers'];grip_factor=1. if p['pretension'] else max(0.,1-max(0,grip-5*p['db'])/150.)
 for j,u in enumerate(p['stations']):
  for plane in range(count):
   coef=.56 if p['threads'][plane] else .45
   add(f'bolt{j+1}_plane{plane+1}',P/(count*n),coef*math.pi*p['db']**2/4*p['fub']/p['gamma2']*grip_factor,grip=grip,grip_factor=grip_factor)
  lc=p['e_end']-p['dh']/2 if j==0 else u-p['stations'][j-1]-p['dh']
  add(f'angle_bearing{j+1}',P/(count*n),min(1.2*lc*ta*p['angle_fu'],2.4*p['db']*ta*p['angle_fu'])/p['gamma2'],lc=lc)
  lc=(p['stations'][j+1]-u-p['dh']) if j<n-1 else chord(p,1,0)[1]-u-p['dh']/2
  add(f'common_gusset_bearing{j+1}',P/n,min(1.2*lc*p['t']*p['gusset_fu'],2.4*p['db']*p['t']*p['gusset_fu'])/p['gamma2'],lc=lc)
  k=j+1;Lv=p['e_end']+u-p['stations'][0];agv=ta*Lv;anv=ta*(Lv-(k-.5)*dn)
  for side,ant in [('connected_real_toe',ta*(p['angle_b']-p['g']-dn/2)),('opposite_real_toe_catalog_complement',p['angle_A']-ta*(p['angle_b']-p['g'])-ta*dn/2)]:
   ry=(.6*p['angle_fy']*agv+.5*p['angle_fu']*ant)/p['gamma2'];ru=(.6*p['angle_fu']*anv+.5*p['angle_fu']*ant)/p['gamma2']
   add(f'angle_block_{side}_{k}',k*P/(count*n),min(ry,ru),Agv=agv,Anv=anv,Ant=ant,Ryield=ry,Rrupture=ru)
 width=2*Lc*math.tan(math.pi/6);lims=chord(p,0,p['stations'][0]);actual=min(width/2,lims[1])-max(-width/2,lims[0])
 add('gusset_whitmore_gross',P,actual*p['t']*p['gusset_fy']/p['gamma1'],width=actual)
 add('gusset_whitmore_net_supplement',P,(actual-dn)*p['t']*p['gusset_fu']/p['gamma2'],net_width=actual-dn)
 return rows

def joint(p):
 # External beam cut and gusset-on-beam action recover beam-on-column action at J.
 D=p['beam_cut'];J=[p['ec'],0.];roots={}
 for name,seg in p['seams'].items():
  center=[sum(q[j] for q in seg)/2 for j in range(2)];force=[-f for f in p['roots'][name]];roots[name]=(center,force)
 bp,bf=roots['beam'];jointF=[D[2]+bf[0],D[3]+bf[1]];jointM=D[4]+cross([D[0]-J[0],D[1]-J[1]],D[2:4])+cross([bp[0]-J[0],bp[1]-J[1]],bf)
 U=p['upper_cut'];cp,cf=roots['column'];low=p['lower_point'];F=[-(U[2]+jointF[0]+cf[0]),-(U[3]+jointF[1]+cf[1])]
 M=-(U[4]+cross(U[:2],U[2:4])+jointM+cross(J,jointF)+cross(cp,cf)+cross(low,F))
 return dict(J=[*J,*jointF,jointM],lower=[*low,*F,M])
