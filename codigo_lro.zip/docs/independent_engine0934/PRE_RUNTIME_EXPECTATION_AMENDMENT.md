# Pre-runtime expectation amendment

Before any production comparison, the independently transcribed threads-excluded coefficient was checked against the supplied NBR 8800:2024 §6.3.3.2(b), physical PDF106/printed84, available in axial_splice_scope/source/bolt-106.txt. It is 0.56 for high-strength bolts, not the initially transcribed 0.50. The expected mixed-thread/threads-excluded cases were corrected on that source evidence. Thread-included BC1 is unchanged. The initial lock is preserved; the amended lock identifies the actual acceptance expectations.

A second catalog angle case was added using the immutable Gerdau source table's P03/R34 dimensions and published properties: leg88.9mm, thickness7.94mm, Ag1350mm², centroid25.2mm. No rolled radius is inferred.

The bolt-grade mutation uses the accepted catalog A490 fub1040MPa, rather than the initial arbitrary1035MPa input. Production exposes a grade selector, not arbitrary fub; the immutable model catalog establishes that material datum. No runtime result was used to choose the expectation.

Post-initial-sweep clarification, from the independent method reviewer: a zero-length support/free shared vertex is an active free-side limiting path; a cap ending in the interior of a supported edge or retaining positive support length remains inactive. The fresh helper now implements this convention. All 27 pre-runtime arbitrary-station expected values remain byte-for-byte unchanged because none is at the shared-vertex boundary. The frozen source witness and governing resistance are unchanged.
