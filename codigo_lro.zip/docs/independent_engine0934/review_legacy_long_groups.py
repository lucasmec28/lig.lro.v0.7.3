"""Replay intentional legacy applicability delta with full diagnostic-state hashes."""
from pathlib import Path
import sys,json,hashlib,subprocess,datetime
import numpy as np
if np.__version__!='2.5.3':raise SystemExit('Exact legacy diagnostic hash replay requires recorded NumPy2.5.3.')
H=Path(__file__).resolve().parent;S=Path(sys.argv[1]).resolve();O=Path(sys.argv[2]).resolve();O.mkdir(parents=True,exist_ok=True)
current=O/'LEGACY_LONG_GROUP_CURRENT.json'
subprocess.run([sys.executable,str(H/'capture_legacy_long_groups.py'),str(S),str(current)],check=True,stdout=subprocess.DEVNULL)
old=json.loads((H/'LEGACY_LONG_GROUP_BASELINE.json').read_text());new=json.loads(current.read_text());assert len(old['cases'])==len(new['cases'])==15
errors=[];rows=[]
for a,b in zip(old['cases'],new['cases']):
 assert (a['module'],a['arrangement'],a['Lc'])==(b['module'],b['arrangement'],b['Lc'])
 issues=[r for r in b['issues'] if r['id']=='long_bolt_group'];same=a['protected_mechanics_sha256']==b['protected_mechanics_sha256'];guard=len(issues)==int(b['Lc']>950)
 behavior=(b['status']==a['status'] and b['local_pass']==a['local_pass']) if b['Lc']<=950 else not b['global_pass'] and not b['local_pass'] and not b['complete']
 row=dict(module=b['module'],arrangement=b['arrangement'],Lc=b['Lc'],native_round_trip=b['native_round_trip'],original_status=a['status'],corrected_status=b['status'],diagnostic_mechanics_unchanged=same,exact_guard_presence=guard,status_scope_correct=behavior,protected_mechanics_sha256=b['protected_mechanics_sha256']);row['passed']=same and guard and behavior and b['native_round_trip'];rows.append(row)
 if not row['passed']:errors.append(row)
result=dict(checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),cases=len(rows),failures=errors,rows=rows,protected_mechanics_fields=old['cases'][0]['protected_mechanics_fields'],scope='Parent-authorized applicability-only correction to both old bolted kernels;15 probes include intentionally invalid1100mm geometry. The length guard alone does not qualify all other geometry.',baseline_sha256=hashlib.sha256((H/'LEGACY_LONG_GROUP_BASELINE.json').read_bytes()).hexdigest(),current_sha256=hashlib.sha256(current.read_bytes()).hexdigest())
(O/'LEGACY_LENGTH_SAFETY_ACCEPTANCE.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(cases=len(rows),failures=errors),indent=2));sys.exit(bool(errors))
