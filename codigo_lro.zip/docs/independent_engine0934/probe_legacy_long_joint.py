"""Read-only public-API scope probe. Writes only its explicitly requested JSON evidence."""
from __future__ import annotations
import argparse
from dataclasses import replace
from pathlib import Path
import hashlib
import importlib
import json
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', required=True, type=Path)
    parser.add_argument('--expect', choices=['baseline', 'guarded'], required=True)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    source = args.source.resolve()
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(source))
    modules = {name: importlib.import_module('lro.' + name) for name in ('bolted_angle_gusset', 'bolted_opposed_angle_gusset')}
    probes = []
    failures = []
    cases = [(949.9, 45000., False), (950., 45000., False),
             (950.0001, 45000., False), (1000., 45000., False),
             (1000., 0., False), (1000., 45000., True)]
    for name, arrangement in [('bolted_angle_gusset', '1L'), ('bolted_angle_gusset', '2L-T'), ('bolted_opposed_angle_gusset', '2L-opposed')]:
        module = modules[name]
        assert Path(module.__file__).resolve() == source / 'lro' / (name + '.py')
        base = next(iter(module.presets().values()))
        for length, load, pretensioned in cases:
            c = replace(base, arrangement=arrangement, theta_deg=90., n=11,
                        pitch=length / 10., plate_height=length + 100.,
                        center_n=(length + 100.) / 2., N=load, pretensioned=pretensioned)
            native = c.to_dict()
            roundtrip = type(c).from_dict(native) == c
            result = module.evaluate(c)
            blocked = args.expect == 'guarded' and length > 950.
            observed_issues = result.get('issues', [])
            checks = {
                'native_roundtrip': roundtrip,
                'length_preserved': result.get('geometry', {}).get('Lc') == length,
                'explicit_scope_status': result['status'] == ('OUTSIDE_SCOPE' if blocked else 'COMPLETE_LOCAL_CHECKS_PASS_WITHIN_SCOPE'),
                'global_pass': result['global_pass'] is (not blocked),
                'local_pass': result['local_pass'] is (not blocked),
                'completeness': result['summary']['complete_checks'] is (not blocked),
                'diagnostic_geometry_preserved': result.get('geometry', {}).get('valid') is True,
                'diagnostic_cases_preserved': len(result.get('cases', [])) == (2 if load == 0. else 1),
                'diagnostic_strength_preserved': len(result.get('checks', [])) > 0,
                'actual_load_preserved': bool(result.get('cases')) and result['cases'][0]['N'] == load,
                'specific_scope_issue': any(i['severity'] == 'outside_scope' and i['id'] == 'long_bolt_group' for i in observed_issues) if blocked else not observed_issues,
            }
            label = f'{arrangement}:Lc={length}:N={load}:pretensioned={pretensioned}'
            failed = [key for key, passed in checks.items() if not passed]
            if failed:
                failures.append({'case': label, 'failed': failed})
            probes.append({'case': label, 'checks': checks, 'status': result['status'],
                           'issues': observed_issues, 'summary': result['summary'],
                           'inputs': native['connection'],
                           'case_forces': [{'id': x['id'], 'N': x['N'], 'force_split': x['force_split']} for x in result.get('cases', [])]})
            print(label, result['status'], 'OK' if not failed else 'FAIL ' + ', '.join(failed), flush=True)
    hashes = {str(Path('lro') / (name + '.py')): hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest() for name, module in modules.items()}
    evidence = {'expectation': args.expect, 'source': str(source), 'source_sha256': hashes,
                'passed': not failures, 'probe_count': len(probes), 'failures': failures, 'probes': probes}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(evidence, indent=2, ensure_ascii=False) + '\n')
    return 1 if failures else 0


if __name__ == '__main__':
    raise SystemExit(main())
