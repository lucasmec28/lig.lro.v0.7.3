"""Independent strict native-state rejection and no-mutation acceptance."""
from pathlib import Path
from copy import deepcopy
from dataclasses import replace
import sys,json,hashlib,datetime
H=Path(__file__).resolve().parent;S=Path(sys.argv[1]).resolve();sys.path.insert(0,str(S))
O=Path(sys.argv[2]).resolve() if len(sys.argv)>2 else H;O.mkdir(parents=True,exist_ok=True)
from lro.corner_gusset import CornerGusset,analyze,BOLTED_FIELDS,WELDED_BRACE_FIELDS
rows=[];errors=[]
def canonical(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
for topology in ['single_1L_bolted','symmetric_2L_T_bolted']:
 base=replace(CornerGusset(),topology=topology,symmetric=topology.startswith('symmetric'),plate_width=300.,plate_height=300.,bolt_heel_extent=13.94,bolt_heel_extent_source='Independent native fixture, explicit assumption')
 accepted=base.to_dict();frozen=canonical(accepted);before=canonical(analyze(base));reopened=CornerGusset.from_dict(deepcopy(accepted));same=canonical(reopened.to_dict())==frozen
 rows.append(dict(topology=topology,case='valid native round trip',passed=same))
 if not same:errors.append(rows[-1])
 mutations=[]
 for key in sorted(WELDED_BRACE_FIELDS):
  present=key in accepted['connection'];row=dict(topology=topology,case='obsolete welded-only field absent: '+key,passed=not present);rows.append(row)
  if present:errors.append(row)
  mutations.append(('forbidden welded-only '+key,lambda d,k=key:d['connection'].update({k:getattr(base,k)})))
 for key in accepted:mutations.append(('missing root '+key,lambda d,k=key:d.pop(k)))
 mutations.extend([('extra root',lambda d:d.update(extra=True)),('wrong family',lambda d:d.update(connection_type='bolted_angle_gusset')),('old component version',lambda d:d.update(component_version='0.9.33-single-angle-corner-dev')),('unknown component version',lambda d:d.update(component_version='0.0')),('boolean schema version',lambda d:d.update(schema_version=True)),('wrong force units',lambda d:d['units'].update(force='kN')),('extra units',lambda d:d['units'].update(angle='deg')),('wrong physical planes',lambda d:d['fixed_assumptions'].update(physical_shear_planes=9)),('fake exact3D',lambda d:d['fixed_assumptions'].update(exact_3D_equilibrium_claimed=True)),('foreign assumptions',lambda d:d['fixed_assumptions'].update(external_verified=True)),('extra connection',lambda d:d['connection'].update(unknown=1)),('unknown topology',lambda d:d['connection'].update(topology='future_bolted_adapter'))])
 for key in sorted(BOLTED_FIELDS):mutations.append(('missing '+key,lambda d,k=key:d['connection'].pop(k)))
 if topology=='single_1L_bolted':mutations.append(('missing explicit physical face',lambda d:d['connection'].pop('single_angle_face')))
 for key in ['P','phi_deg','plate_width','bolt_start','bolt_pitch','bolt_diameter','bolt_gauge','bolt_angle_end','bolt_tool_radius','bolt_heel_extent','bolt_washer_stack']:
  for label,bad in [('NaN',float('nan')),('infinite',float('inf')),('boolean',True),('string','16'),('null',None)]:mutations.append((key+' '+label,lambda d,k=key,v=bad:d['connection'].update({k:v})))
 for key in ['bolt_drilled','bolt_threads_excluded_1','bolt_threads_excluded_2','bolt_pretensioned']:
  for bad in [0,1,'false',None]:mutations.append((key+' wrong bool '+repr(bad),lambda d,k=key,v=bad:d['connection'].update({k:v})))
 for bad in [True,4.0,'4',None,0,1,-4,4000000000]:mutations.append(('bolt_count '+repr(bad),lambda d,v=bad:d['connection'].update(bolt_count=v)))
 for label,mutate in mutations:
  raw=deepcopy(accepted);mutate(raw);rejected=False;err=None
  try:CornerGusset.from_dict(raw)
  except (ValueError,TypeError) as exc:rejected=True;err=str(exc)
  same=canonical(base.to_dict())==frozen
  row=dict(topology=topology,case=label,rejected=rejected,accepted_object_unchanged=same,passed=rejected and same,reason=err);rows.append(row)
  if not row['passed']:errors.append(row)
 if canonical(analyze(base))!=before:errors.append(dict(topology=topology,case='accepted evaluation changed after rejection loop'))
report=dict(checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),observations=len(rows),failures=errors,rows=rows,engine_sha256=hashlib.sha256((S/'lro/corner_gusset.py').read_bytes()).hexdigest(),scope='Pure engine native import round trip and no mutation; UI session-state import belongs to output reviewer.')
(O/'NATIVE_ACCEPTANCE.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(observations=len(rows),failures=errors),ensure_ascii=False,indent=2));sys.exit(bool(errors))
