# Legacy bolted-route long-joint qualification gap

Date: 2026-10-12. Bounded independent read-only review of immutable received 0.9.33 source. No production files modified. This is a length-admission and approval audit, not a re-audit of all methods.

## Conclusion

**Confirmed reachable gap in both legacy kernels**, covering all three exposed arrangements: 1L, 2L-T and opposed 2L. Uniform-force end-loaded bolt groups longer than 950 mm are admitted by native import and can return `COMPLETE_LOCAL_CHECKS_PASS_WITHIN_SCOPE`, `global_pass=true`, `local_pass=true`, `complete_checks=true`, and zero issues. These flags remain a local connection conclusion; `global_member_verified` stays false.

18 independent public-API probes completed against immutable baseline. All 18 returned complete local PASS with zero issues, including immediately above 950 mm, 1000 mm, a zero-actual-load/minimum-45-kN case and pretensioned high-strength bolts. These are baseline defect witnesses; the script's baseline success means it reproduced current behavior, not that the long-joint method is qualified.

Evidence:
- `BASELINE_BOUNDARY_ACCEPTANCE.json`: all 18 cases, exact native inputs, preserved actual/synthetic case forces, expectations and file hashes.
- `BASELINE_PROBES.json`: initial 12 below/at/above-boundary probes.
- `SOURCE_SHA256.json`: hashes of the two kernels, shared UI and existing W-splice guard.
- `probe_legacy_long_joint.py`: independent public-API acceptance executable for either baseline or guarded candidate. It imports only the explicitly supplied source directory and does not modify it.

## Compact exact reproducer

Import `lro.bolted_angle_gusset` or `lro.bolted_opposed_angle_gusset`. Take `next(iter(module.presets().values()))`, retaining that preset's explicit heel-envelope detail. Apply:

- arrangement: `1L`, `2L-T`, or `2L-opposed`, using the appropriate class
- theta_deg = 90.0
- n = 11
- pitch = 100.0
- plate_height = 1100.0
- center_n = 550.0
- N = 45000.0

All other values remain the first public preset, including B240 for 1L/T and B300 for opposed. This gives Lc=(n−1)×pitch=1000 mm. The strict `type(c).from_dict(c.to_dict()) == c` round-trip succeeds.

Observed results:
- 1L: 158 checks, governing utilization 0.21313240043057052
- 2L-T: 169 checks, governing utilization 0.17970522488739443
- opposed 2L: 812 checks, governing utilization 0.14376417990991552

All three: complete local PASS, no issues. The first discovery also used n21/p50 at the same 1000-mm span: one-root 309 checks and opposed 1752 checks, likewise full local PASS.

## Source mechanisms and reachability

Paths below are relative to `internal_fin_workbook_received20261012/current_app/extracted/source`.

- `lro/bolted_angle_gusset.py:175–177`: native n is 2–50, which admits n11 and n21; no total group-length cap.
- `lro/bolted_opposed_angle_gusset.py:180–182`: native n is integer >=2; no total group-length cap.
- `lro/bolted_angle_gusset.py:268`, opposed `:282`: actual method length is explicitly `(n−1)*pitch`.
- One-root `:294–297`: min/max pitch does not cap number of bolts or total length. In the reproducer p100 is below its painted 24t=152.4-mm limit.
- One-root `:559,570–571`: shear N/(angle_count*n), bearing N/(angle_count*n) on each angle and N/n on the shared gusset. No long-joint multiplier.
- Opposed `:391,410–430`: F=N/(2*n) for each physical bolt and both bearing interfaces. No long-joint multiplier.
- Shared UI `lro/bolted_angle_gusset_ui.py:121–127`: strict native import uses the respective engine from_dict and widget representability only.
- Shared UI `:209–220`: numeric scalar widgets have no additional min/max bounds; `:402,410` expose n/pitch and plate dimensions.
- Shared UI `:425–440`: evaluate feeds result/status directly; the demonstrated flags give a successful local-connection banner and report readiness.
- One-root `_finalize` `:651–666` and opposed `:548–563`: an `outside_scope` issue is already sufficient to prevent complete checks and both pass flags.

A live UI reproduction was unnecessary to establish the admitted domain and was not completed here. Plain interpreter lacks Streamlit; the root explicitly directed that corrected live UI behavior be checked by the existing output reviewer rather than duplicated.

The existing W-splice kernel is already separately guarded: `lro/w_splice.py:276–278` computes its conservative extreme span and issues `unsupported_scope` above 950 mm. Do not replace this splice-specific metric with a gusset metric as part of the bounded correction.

## Exact normative statement and qualification interpretation

Primary source: supplied ABNT NBR 8800:2024, §6.3.8, printed page 91 / PDF page 113. Text extraction `axial_splice_scope/source/nbr-113.txt:43–49`. PDF:
`baseplate_references/Automação MC/NBR 8800-24-25-projeto-de-estruturas-de-aco-e-de-estruturas-mistas-20250710-000231_compress.pdf`
SHA256 `2289dd360ae938982f44ce6b0633968652199604867172e9d0d454e71256b16d`.

Literal provision: bearing-type tension-member splices longer than 950 mm in the external-force direction require bolt-shear and hole-bearing design demands multiplied by 1.20 for nonuniform bolt distribution. The text says splices. It does not explicitly name all brace-to-gusset end connections, and this bounded report does not claim an unambiguous literal brace-end-code violation.

The new corner method's independent clarification, `bolted_corner_scope20261012/METHOD_REVIEW_CLARIFICATIONS.md §4`, adopts Lc<=950 mm as a conservative qualification boundary for uniform-per-bolt ordinary end-loaded brace laps. The legacy routes have the same end-loaded longitudinal lap mechanism and equally use uniform bolt loads. No separate long-joint distribution qualification or documented exemption appears in their admitted methods. Extending that boundary is the narrow, conservative correction, rather than claiming a blanket normative ban on long connections. Root authorized that applicability guard during this review.

The pretension exception in the immediately preceding §6.3.7 concerns long grip. It is not an exception to §6.3.8 or to this end-loaded length qualification boundary. A factor of 1.20 on bolt/bearing demands alone would not qualify all existing partial-block/captured-load assumptions. Do not increase actual N, actual exported root/W actions, or external equilibrium to implement a local design-demand factor.

## Minimal corrective hook

In each evaluate(), after `_geometry` is assigned into `out['geometry']`, issue a specifically identified `outside_scope` long-joint-distribution finding when `g['Lc'] > 950.0`. Exact 950 is admitted. Keep the computed geometry and diagnostic strength cases/checks available; do not change the public native schema, ordinary loads, capacities or short-joint results.

One-root hook: immutable source approximately lines 721–726. Opposed hook: approximately lines 616–622. Leaving geometric validity as computed allows diagnostic calculation; existing `_finalize` then withholds approval and completeness. The shared UI's status/complete logic blocks its successful conclusion and report-ready path. Owner may choose equivalent placement with these semantics.

Recommended message: uniform-distribution method unqualified above 950 mm; a specific long-joint distribution method is required. Identify NBR6.3.8 plus the conservative end-loaded-lap method boundary. Do not present the issue as inadequate strength or an absolute prohibition on longer connections.

## Candidate acceptance

Run independently:

`python legacy_bolt_length_scope0934/probe_legacy_long_joint.py --source review0934/source0934 --expect guarded --output <evidence.json>`

18 cases:
- every arrangement at Lc949.9, exactly950, 950.0001 and1000
- every arrangement at Lc1000, actual N0 with independent minimum45-kN case
- every arrangement at Lc1000, pretensioned=true

For >950: expect explicit long_bolt_group issue, OUTSIDE_SCOPE, false local/global pass and complete_checks; diagnostic geometry/cases/checks preserved; actual external loads unchanged. For <=950: preserve complete local PASS and no new issues. Separate engine reviewer owns full-state ordinary-preset parity. Existing output reviewer owns visible corrected UI/report gating. Full application release acceptance remains with the engine and output reviewers; this report now includes the bounded candidate check below.


## Bounded candidate acceptance after owner patch

The implementation owner added the authorized guard in each candidate kernel. This reviewer made no production edits. The finalized independent executable passed **18/18** cases against `review0934/source0934`, with no failed assertions. Evidence: `GUARDED_BOUNDARY_ACCEPTANCE.json`.

- Exact `long_bolt_group` outside_scope issue above 950 mm
- OUTSIDE_SCOPE, incomplete checks, false local/global approval above 950 mm
- Complete local PASS below and exactly at 950 mm
- Diagnostic geometry, strength checks and actual/minimum cases retained
- Actual N unchanged; N=0 remains zero while the separate 45-kN case is retained
- Pretensioned bolts do not bypass the applicability boundary

Final checker SHA256: `67420edc9a664f98151299f6d7a298ba77db025b7c94794225d78341c74fb4a5`.

Tested candidate source SHA256:
- `lro/bolted_angle_gusset.py`: `f6731494a9694b228b5f60c2b12a3d734374535cb5cd2a209fa4dfd638ad3766`
- `lro/bolted_opposed_angle_gusset.py`: `44fc3d741c0cfa9782187862ac4b82532046def97487aa45753de60f713e0ba0`

The final engine reviewer is independently checking full diagnostic-state equality for long groups and full-state ordinary-preset parity. The output reviewer owns live UI/report checks. This bounded acceptance does not replace either wider review.
