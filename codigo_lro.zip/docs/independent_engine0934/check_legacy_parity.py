"""Full native/result legacy replay; version token normalization only."""
from pathlib import Path
from copy import deepcopy
import json,sys,hashlib,datetime
H=Path(__file__).resolve().parent;S=Path(sys.argv[1]).resolve();sys.path.insert(0,str(S))
from lro.corner_gusset import CornerGusset,analyze,COMPONENT_VERSION
old=json.loads((H/'LEGACY_COMPLETE0933.json').read_text());new=json.loads((H/'LEGACY_COMPLETE0934.json').read_text())
by={(r['module'],r['name']):r for r in new['cases']};fail=[];rows=[];natives=[]
def norm(x):
 if isinstance(x,dict):return {k:('NORMALIZED_CORNER_VERSION' if k=='component_version' and v in ('0.9.32-corner-gusset-dev','0.9.33-single-angle-corner-dev',COMPONENT_VERSION) else norm(v)) for k,v in x.items()}
 if isinstance(x,list):return [norm(v) for v in x]
 return x
def differences(a,b,path=''):
 if type(a)!=type(b):return [(path,'type',str(type(a)),str(type(b)))]
 if isinstance(a,dict):
  out=[(path,'keys',sorted(set(a)-set(b)),sorted(set(b)-set(a)))] if set(a)!=set(b) else []
  for k in set(a)&set(b):out.extend(differences(a[k],b[k],path+'/'+k))
  return out
 if isinstance(a,list):
  out=[(path,'length',len(a),len(b))] if len(a)!=len(b) else []
  for j,(x,y) in enumerate(zip(a,b)):out.extend(differences(x,y,path+'/'+str(j)))
  return out
 return [(path,a,b)] if a!=b else []
for row in old['cases']:
 key=(row['module'],row['name']);other=by.get(key);diff=differences(norm(row),norm(other)) if other else [('missing',key)]
 record=dict(module=key[0],preset=key[1],identical_after_version_only_normalization=not diff,differences=diff[:30]);rows.append(record)
 if diff:fail.append(record)
 if key[0]=='corner_gusset':
  c=CornerGusset.from_dict(row['input']);o=analyze(c)
  native=dict(preset=key[1],unchanged_native=norm(c.to_dict())==norm(row['input']),unchanged_result=norm(o)==norm(row['output']))
  native['passed']=native['unchanged_native'] and native['unchanged_result'];natives.append(native)
  if not native['passed']:fail.append(native)
result=dict(checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),routes=old['route_count'],route_names=old['routes'],old_presets=len(rows),current_presets=new['case_count'],new_presets=[dict(module=m,name=n) for m,n in sorted(set(by)-{(r['module'],r['name']) for r in old['cases']})],failures=fail,normalized_fields=['app_version (only application VERSION)','component_version (only old/new corner adapter tags)'],rows=rows,legacy_native_corner_round_trips=natives,engine_sha256=hashlib.sha256((S/'lro/corner_gusset.py').read_bytes()).hexdigest())
(H/'LEGACY_PARITY.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['routes','old_presets','current_presets','new_presets','failures']},ensure_ascii=False,indent=2));sys.exit(bool(fail))
