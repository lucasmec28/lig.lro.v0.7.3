"""Bounded legacy guard witness; no source edits and no numerical oracle imports."""
from pathlib import Path
from dataclasses import replace
import sys,json,hashlib,importlib,datetime
S=Path(sys.argv[1]).resolve();O=Path(sys.argv[2]).resolve();sys.path.insert(0,str(S))
rows=[]
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
for mod in ['bolted_angle_gusset','bolted_opposed_angle_gusset']:
 m=importlib.import_module('lro.'+mod);base=next(iter(m.presets().values()))
 for arrangement in (['1L','2L-T'] if mod=='bolted_angle_gusset' else ['2L-opposed']):
  for Lc in [949.999,950.,950.001,1000.,1100.]:
   # At1100mm the domain may also reject physical end containment; do not claim
   # that the length guard alone qualifies the complete chosen geometry.
   c=replace(base,arrangement=arrangement,theta_deg=90.,n=21,pitch=Lc/20,plate_height=1100.,center_n=550.,N=45000.)
   reopened=type(c).from_dict(c.to_dict());r=m.evaluate(reopened)
   protected=['checks','cases','geometry','root','sections','paths','materials','member_actions','inputs']
   mechanics={k:r[k] for k in protected if k in r}
   row=dict(module=mod,arrangement=arrangement,Lc=Lc,actual_Lc=(c.n-1)*c.pitch,native_round_trip=c.to_dict()==reopened.to_dict(),status=r['status'],local_pass=r['local_pass'],global_pass=r['global_pass'],complete=r['summary']['complete_checks'],check_count=len(r['checks']),issues=r['issues'],protected_mechanics_fields=protected,protected_mechanics_sha256=digest(mechanics),source_sha256=hashlib.sha256((S/'lro'/f'{mod}.py').read_bytes()).hexdigest())
   rows.append(row)
result=dict(checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source=str(S),cases=rows)
O.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps([dict(module=r['module'],arrangement=r['arrangement'],Lc=r['Lc'],status=r['status'],issues=[i['id'] for i in r['issues']]) for r in rows],ensure_ascii=False,indent=2))
