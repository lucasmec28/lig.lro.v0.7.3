"""Independent mechanical comparison of the declared bolted corner kernel.
Expected JSON is generated and locked without production imports.
"""
from pathlib import Path
from dataclasses import replace
import sys,json,math,datetime,hashlib
H=Path(__file__).resolve().parent;S=Path(sys.argv[1]).resolve();sys.path.insert(0,str(S))
O=Path(sys.argv[2]).resolve() if len(sys.argv)>2 else H;O.mkdir(parents=True,exist_ok=True)
from lro.corner_gusset import CornerGusset,analyze,geometry
from lro.bolted_corner import section,block_state
Q=H.parents[1]/'bolted_corner_scope20261012'
if not Q.exists():Q=S/'docs/qualification_bolted_corner0934'
reference_lock=json.loads((H/'PRE_RUNTIME_REFERENCE_LOCK.json').read_text())
assert hashlib.sha256((Q/'ORACLE.json').read_bytes()).hexdigest()==reference_lock['files']['ORACLE.json'], 'Frozen mechanical oracle hash mismatch; expectations must not be overwritten.'
EXPECT=json.loads((H/'EXPECTED_PARAMETERIZED.json').read_text())
AMEND=json.loads((Q/'LOGICAL_WITNESS_AMENDMENTS.json').read_text())
assert AMEND['oracle_sha256']==reference_lock['files']['ORACLE.json']
AMEND_BY={(r['id'],r['side'],r['u']):r for r in AMEND['records']}
counts={};errors=[];notes=[];states=[]
def compare(got,want,path,category='parameter_numeric'):
 if isinstance(want,bool):
  counts[category+'_logical']=counts.get(category+'_logical',0)+1
  if type(got) is not bool or got!=want:errors.append(dict(path=path,actual=got,expected=want))
 elif isinstance(want,(int,float)):
  counts[category]=counts.get(category,0)+1
  if not isinstance(got,(int,float)) or not math.isclose(got,want,rel_tol=1e-8,abs_tol=1e-5):errors.append(dict(path=path,actual=got,expected=want))
 elif isinstance(want,list):
  if not isinstance(got,(list,tuple)) or len(got)!=len(want):errors.append(dict(path=path,actual=got,expected=want));return
  for i,w in enumerate(want):compare(got[i],w,path+'/'+str(i),category)
 else:
  counts[category+'_logical']=counts.get(category+'_logical',0)+1
  if got!=want:errors.append(dict(path=path,actual=got,expected=want))
def build(changes=None,**more):
 changes=changes or {};kw=dict(topology='single_1L_bolted',symmetric=False,plate_width=300.,plate_height=300.,bolt_heel_extent=13.94,bolt_heel_extent_source='Independent BC1 assumption t+6 mm, not catalog radius',case_id='INDEPENDENT_BC1',project='Independent acceptance BC1')
 mapping={'P':'P','phi':'phi_deg','w':'plate_width','h':'plate_height','t':'plate_t','clip':'corner_clip','beam_start':'beam_seam_start_margin','beam_end':'beam_seam_end_margin','column_start':'column_seam_start_margin','column_end':'column_seam_end_margin','db':'bolt_diameter','drilled':'bolt_drilled','g':'bolt_gauge','e_end':'bolt_angle_end','washers':'bolt_washer_stack','pretension':'bolt_pretensioned'}
 for k,v in changes.items():
  if k in mapping:kw[mapping[k]]=v
 if changes.get('count')==2:kw.update(topology='symmetric_2L_T_bolted',symmetric=True)
 if 'stations' in changes:
  st=changes['stations'];kw.update(bolt_count=len(st),bolt_start=st[0],bolt_pitch=st[1]-st[0])
 if 'threads' in changes:kw.update(bolt_threads_excluded_1=changes['threads'][0],bolt_threads_excluded_2=changes['threads'][1])
 if changes.get('angle_fy')==345.:kw['angle_steel']='ASTM A572 Gr.50'
 if changes.get('gusset_fy')==345.:kw['gusset_steel']='ASTM A572 Gr.50'
 if changes.get('angle_b')==88.9:kw['angle_profile']='GERDAU_EQUAL_ANGLE_P03_R34'
 if changes.get('fub')==1040.:kw['bolt']='ASTM F3125 A490'
 for key,prefix in [('beam_cut','beam_cut'),('upper_cut','upper_column_cut')]:
  if key in changes:
   for suffix,v in zip(['x','y','Fx','Fy','M'],changes[key]):kw[prefix+'_'+suffix]=v
 kw.update(more);return replace(CornerGusset(),**kw)
def checkrows(result):return {r['id']:r for r in result['checks']}
def comp_row(got,want,path,cat):
 for k in ('demand','resistance','utilization'):
  if k not in got:errors.append(dict(path=path+'/'+k,error='missing'));continue
  compare(got[k],want[k],path+'/'+k,cat)
 if not isinstance(got.get('source'),str) or not got['source'].strip():errors.append(dict(path=path,error='missing engineering source'))
def common_checks(result,oracle,name):
 got=checkrows(result)
 for row in oracle['checks']:
  if row['id'] not in got:errors.append(dict(path=name+'/'+row['id'],error='missing frozen row'));continue
  comp_row(got[row['id']],row,name+'/'+row['id'],'frozen_strength_numeric')

def frozen():
 oracle=json.loads((Q/'ORACLE.json').read_text())
 for count in [1,2]:
  c=build({'count':count});out=analyze(c);rows=checkrows(out);prefix='1L_' if count==1 else '2L-T_';name='BC1_'+prefix
  for row in oracle['checks']:
   if row['id'].startswith(('1L_','2L-T_')) and not row['id'].startswith(prefix):continue
   if row['id'] not in rows:errors.append(dict(path=name+row['id'],error='missing frozen row'));continue
   comp_row(rows[row['id']],row,name+row['id'],'frozen_strength_numeric')
  common_checks(out,oracle['common_full_joint'],name)
  g=out['geometry'];forces=out['forces']
  for row in oracle['gusset_block_paths']:
   got=block_state(c,g,row['u'],row['side']);path=name+'/frozen_block/'+row['id']
   if got is None:errors.append(dict(path=path,error='missing path'));continue
   amend=AMEND_BY.get((row['id'],row['side'],row['u']))
   expected_active=amend['reviewed_active'] if amend else row['active']
   compare(got['active'],expected_active,path+'/active','frozen_path')
   if amend:
    assert row['active']==amend['source_active']
    for key,value in amend['independent_boundary_numeric_witness'].items():
     mapped={'D':'demand','R':'resistance'}.get(key,key)
     compare(got.get(mapped),value,path+'/explicit_amendment/'+mapped,'amended_boundary_numeric')
   for k in ('Agv','Anv','Ant','Ryield','Rrupture','resistance','demand','utilization','path_uv','captured_bolts_including_crossing','captured_bolts_excluding_crossing'):
    if k in row:compare(got.get(k),row[k],path+'/'+k,'frozen_path')
  for i,row in enumerate(oracle['section_station_oracles']+list(oracle['section_search_witnesses'].values())):
   if row is None:continue
   got=section(c,g,forces,row['u'],row['include_cut_hole'],row['net']);path=name+'/frozen_section/'+str(i)
   if got is None:errors.append(dict(path=path,error='missing section'));continue
   for k in ('A','centroid_v','I','N','V','M','sigma_edges','nominal_VM','retained_sources'):compare(got.get(k),row[k],path+'/'+k,'frozen_section')
  compare(out['status'],'PASS',name+'/status','frozen_state')
  states.append(dict(name=name,status=out['status'],complete=out.get('complete'),issues=out['issues']))

def parameterized():
 for case in EXPECT['cases']:
  c=build(case['changes']);out=analyze(c);name=case['name'];g=out['geometry'];forces=out['forces'];got=checkrows(out);prefix='1L_' if c.topology=='single_1L_bolted' else '2L-T_'
  states.append(dict(name=name,status=out['status'],complete=out.get('complete'),issues=out['issues']))
  if not forces:errors.append(dict(path=name,error='no actual mechanics'));continue
  for key,want in case['ufm'].items():compare(forces[key],want,name+'/ufm/'+key)
  for key,action in [('J',out['joint_beam_to_column']),('lower',out['complete_cuts']['column_lower'])]:
   compare(action['point']+[action[k] for k in ['Fx','Fy','M']],case['joint'][key],name+'/joint/'+key)
  for key,row in case['primitives'].items():
   id=key if key.startswith(('common_','gusset_')) else prefix+key
   if id not in got:errors.append(dict(path=name+'/'+id,error='missing primitive'));continue
   for k,v in row.items():compare(got[id].get(k),v,name+'/'+id+'/'+k)
  for i,row in enumerate(case['block_paths']):
   actual=block_state(c,g,row['u'],row['side']);path=name+'/block/'+str(i)
   if actual is None:errors.append(dict(path=path,error='missing path'));continue
   compare(actual['active'],row['active'],path+'/active','parameter_path')
   for k in ('path_uv','captured_bolts_including_crossing','captured_bolts_excluding_crossing'):
    if k in actual:compare(actual[k],row[k],path+'/'+k,'parameter_path')
   if row['active']:
    for k in ('Agv','Anv','Ant','Ryield','Rrupture','resistance','demand','utilization'):
     compare(actual.get(k),row[k],path+'/'+k,'parameter_path')
  for i,row in enumerate(case['sections']):
   actual=section(c,g,forces,row['u'],row['include_cut_hole'],row['net']);path=name+'/section/'+str(i)
   if actual is None:errors.append(dict(path=path,error='missing section'));continue
   for k in ('A','centroid_v','I','N','V','M','sigma_edges','nominal_VM','retained_sources'):compare(actual.get(k),row[k],path+'/'+k,'parameter_section')
  print(json.dumps(dict(case=name,status=out['status'],errors=len(errors))),flush=True)

def main():
 frozen();parameterized()
 hashes={str(p.relative_to(S)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [S/'lro/corner_gusset.py',S/'lro/bolted_corner.py',S/'lro/models.py',S/'lro/angle_catalog.py',S/'lro/bolted_angle_gusset.py',S/'lro/bolted_opposed_angle_gusset.py',S/'data/gerdau_equal_angles.json',S/'data/profiles.json']}
 report=dict(checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),counts=counts,case_statuses=states,failures=errors,notes=notes,source_hashes=hashes,tolerance=dict(relative=1e-8,absolute=1e-5),counting_policy='Scalar numeric and logical comparisons, not unique tests or new qualification source rows. Production pytest counts are separate.')
 (O/'RUNTIME_COMPARISON.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(dict(counts=counts,failures=errors[:25],failure_count=len(errors)),ensure_ascii=False,indent=2));return bool(errors)
if __name__=='__main__':sys.exit(main())
