"""Physical accounting, complete-cut/minimum cases, materials and domain witnesses."""
from pathlib import Path
from copy import deepcopy
from dataclasses import replace
import sys,json,math,datetime,hashlib
H=Path(__file__).resolve().parent;S=Path(sys.argv[1]).resolve();sys.path.insert(0,str(S))
O=Path(sys.argv[2]).resolve() if len(sys.argv)>2 else H;O.mkdir(parents=True,exist_ok=True)
import independent_model as im
from review_runtime import build
from lro.corner_gusset import analyze,geometry
rows=[];failures=[];numeric=0;logical=0

def eq(label,a,b,tol=1e-8):
 global numeric,logical
 if isinstance(b,(float,int)) and not isinstance(b,bool):
  numeric+=1;ok=isinstance(a,(float,int)) and math.isclose(a,b,rel_tol=tol,abs_tol=1e-5)
 else:logical+=1;ok=a==b
 row=dict(label=label,passed=ok,actual=a,expected=b);rows.append(row)
 if not ok:failures.append(row)

def cr(o):return {r['id']:r for r in o['checks']}
def issue(o,id):return any(i['id']==id for i in o['issues'])
def actionrow(a):return a['point']+[a[k] for k in ['Fx','Fy','M']]
def compare_action(label,actual,want):
 for i,(a,b) in enumerate(zip(actionrow(actual),want)):eq(label+'/'+str(i),a,b)
base=build();one=analyze(base);two=analyze(build({'count':2}));negativeface=analyze(replace(base,single_angle_face='negative'));rone,rtwo=cr(one),cr(two)
# One shared plate/full joint, one or two shear planes, actual centroids stay physical.
for o,count in [(one,1),(two,2)]:
 b=o['brace'];g=o['geometry'];s=o['spatial_idealization'];name=str(count)+'L'
 eq(name+'/physical_bolts',b['physical_bolt_count'],4);eq(name+'/shear_planes',b['shear_planes_per_bolt'],count);eq(name+'/one_gusset',g['physical_gusset_count'],1)
 eq(name+'/angle_force',b['per_angle_force'],100000./count);eq(name+'/plane_force',b['per_plane_force'],25000./count);eq(name+'/gusset_hole_force',b['force_per_gusset_hole'],25000.)
 for i,v in enumerate([100000/math.sqrt(2),100000/math.sqrt(2),0.]):eq(name+'/discrete_resultant/'+str(i),b['physical_bolt_resultant'][i],v)
 eq(name+'/real_v_offset',s['physical_angle_centroid_v'],-17.9);eq(name+'/raw_Mz',s['raw_inplane_Mz_Nmm'],1790000.);eq(name+'/nominal_z',b['nominal_connection_axis_z'],0.)
 eq(name+'/exact3D',s['exact_3D_equilibrium_claimed'],False);eq(name+'/physical_inplane_offset_not_cancelled',s['inplane_centroid_offset_cancels'],False)
 eq(name+'/z_symmetry_claim_only_pair',s['assumed_spatial_cancellation'],count==2)
eq('face_negative_physical_z',negativeface['geometry']['brace_centroid_z'],-28.1)
eq('face_positive_physical_z',one['geometry']['brace_centroid_z'],28.1)
eq('face_flip_same_checks',negativeface['checks'],one['checks']);eq('face_flip_same_complete_forces',negativeface['forces'],one['forces'])
for key in sorted(set(rone)&set(rtwo)):
 for field in ['demand','resistance','utilization']:eq('shared_once/'+key+'/'+field,rtwo[key][field],rone[key][field])
eq('actual_top_flange_compressed',one['joint_distribution']['Ftop']<0,True)
eq('actual_top_crippling_remains', 'column_top_compression_web_crippling' in rone,True)
eq('actual_top_continuity_buckling_remains','continuity_top_compression_buckling' in rone,True)
# Each native minimum case holds concurrent D/U as named background and rederives lower cut.
for count in [1,2]:
 for P in [0.,1.,20000.,44999.,45000.,100000.,-1.]:
  c=build({'count':count},P=P);out=analyze(c);name=f'minimum/{count}/{P}';p=im.setup(count=count,P=P);expected=im.joint(p)
  for k,v in p['ufm'].items():eq(name+'/actual_'+k,out['forces'][k],v)
  eq(name+'/actual_brace_P',out['brace']['per_angle_force'],P/count)
  compare_action(name+'/actual_J',out['joint_beam_to_column'],expected['J']);compare_action(name+'/actual_L',out['complete_cuts']['column_lower'],expected['lower'])
  synthetic=out.get('design_cases',[])
  eq(name+'/case_count',len(synthetic),1 if 0<=P<45000 else 0)
  if synthetic:
   case=synthetic[0];s=case['result'];sp=im.setup(count=count,P=45000.);sj=im.joint(sp)
   eq(name+'/synthetic_id',case['id'],'minimum_45kN');eq(name+'/actual_label',case['actual_P'],P);eq(name+'/design_label',case['design_P'],45000.)
   eq(name+'/synthetic_not_Robot',case['robot_lower_comparison'],False)
   eq(name+'/background_D_unchanged',s['complete_cuts']['beam'],out['complete_cuts']['beam']);eq(name+'/background_U_unchanged',s['complete_cuts']['column_upper'],out['complete_cuts']['column_upper'])
   for k,v in sp['ufm'].items():eq(name+'/synthetic_'+k,s['forces'][k],v)
   compare_action(name+'/synthetic_J',s['joint_beam_to_column'],sj['J']);compare_action(name+'/synthetic_L',s['complete_cuts']['column_lower'],sj['lower'])
   eq(name+'/split_once',s['brace']['per_plane_force'],45000./(count*4));eq(name+'/same_gusset_once',s['brace']['force_per_gusset_hole'],11250.)
   prefixed=[r for r in out['checks'] if r['id'].startswith('minimum45__')];eq(name+'/all_synthetic_checks_preserved',len(prefixed),len(s['checks']))
   eq(name+'/unique_all_check_ids',len({r['id'] for r in out['checks']}),len(out['checks']))
   for r in s['checks']:
    rr=next(q for q in prefixed if q['id']==r['id'])
    for field in ['demand','resistance','utilization']:eq(name+'/'+rr['id']+'/'+field,rr[field],r[field])
  if P<0:eq(name+'/compression_never_approved',out['approved'],False)
# A minimum-only physical bolt failure must govern while zero actual forces stay zero.
small=analyze(replace(base,P=0.,bolt='ASTM A307',bolt_diameter=12.7,bolt_count=2,bolt_pitch=90.))
actual_rows=[r for r in small['checks'] if not r['id'].startswith('minimum45__')]
eq('minimum_only_failure/actual_strengths_pass',all(r['pass_'] for r in actual_rows),True)
eq('minimum_only_failure/envelope_fails',small['status'],'FAIL')
eq('minimum_only_failure/actual_zero_preserved',small['brace']['per_plane_force'],0.)
smallrows=cr(small);smallcapacity=.45*math.pi*12.7**2/4*415./1.35
eq('minimum_only_failure/independent_bolt_capacity',smallrows['minimum45__1L_bolt1_plane1']['resistance'],smallcapacity)
eq('minimum_only_failure/minimum_split_once',smallrows['minimum45__1L_bolt1_plane1']['demand'],22500.)
eq('minimum_only_failure/source_preserved',bool(smallrows['minimum45__1L_bolt1_plane1']['source']),True)
eq('minimum_only_failure/case_identity',smallrows['minimum45__1L_bolt1_plane1']['case_id'],'minimum_45kN')
# Actual-only supplied Robot lower cut, including zero force.
zero_lower=im.joint(im.setup(P=0.))['lower'];zc=replace(base,P=0.,compare_lower_cut=True,lower_column_check_Fx=zero_lower[2],lower_column_check_Fy=zero_lower[3],lower_column_check_M=zero_lower[4]);zo=analyze(zc)
eq('Robot_zero_actual_matches',issue(zo,'lower_cut_mismatch'),False);eq('Robot_zero_synthetic_does_not_reuse_actual_comparison',issue(zo['design_cases'][0]['result'],'lower_cut_mismatch'),False)
bad=analyze(replace(zc,lower_column_check_M=zero_lower[4]+1e6));eq('Robot_wrong_actual_cut_rejected',issue(bad,'lower_cut_mismatch'),True);eq('Robot_wrong_actual_not_approved',bad['approved'],False)
dup=analyze(replace(base,compare_lower_cut=True,beam_cut_Fx=base.beam_cut_Fx+one['forces']['H'],beam_cut_Fy=base.beam_cut_Fy+one['forces']['V']))
eq('brace_added_twice_conflicts_Robot',issue(dup,'lower_cut_mismatch'),True)
# Independent material mutation capacities and unaltered mechanical force accounting.
for field,steel,target,factor in [
 ('beam_steel','ASTM A36','beam_uniform_traction_local_web_shear',250/345),
 ('column_steel','ASTM A36','column_panel_zone',250/345),
 ('continuity_steel','ASTM A572 Gr.50','continuity_bottom_gross_tension',345/250),
 ('gusset_steel','ASTM A572 Gr.50','gusset_whitmore_gross',345/250),
 ('angle_steel','ASTM A572 Gr.50','1L_angle_gross_each',345/250)]:
 out=analyze(replace(base,**{field:steel}));rc=cr(out);eq(field+'/capacity',rc[target]['resistance'],rone[target]['resistance']*factor)
 for key in ['H','V','Hb','Vb','Hc','Vc']:eq(field+'/force_'+key,out['forces'][key],one['forces'][key])
 for other in ['1L_angle_gross_each','gusset_whitmore_gross','beam_uniform_traction_local_web_shear','column_panel_zone','continuity_bottom_gross_tension']:
  if other!=target:eq(field+'/isolated_'+other,rc[other]['resistance'],rone[other]['resistance'])
root=cr(analyze(replace(base,fw_root=410.)))
for target in ['beam_root_weld','column_root_weld']:eq('root_electrode/'+target,root[target]['resistance'],rone[target]['resistance']*410/485)
for target in ['joint_web_two_fillets','continuity_top_web_weld']:eq('root_electrode/isolation/'+target,root[target]['resistance'],rone[target]['resistance'])
# Specific failures and bounded-domain diagnostics must remain visible.
variants={
 'overload':dict(P=300000.),'offset':dict(workpoint_offset=25.),'no_heel':dict(bolt_heel_extent=0.),
 'remote_edge_interpretation':dict(plate_t=10.),'bad_tool':dict(bolt_tool_radius=70.),'negative_clearance':dict(bolt_fabrication_clearance=-1.),
 'bolt_plane_weak':dict(P=230000.),'outside_angle':dict(phi_deg=40.),'long_connection':dict(plate_width=2000.,plate_height=2000.,bolt_count=20,bolt_start=1000.,bolt_pitch=60.),
 'root_compression':dict(phi_deg=80.,plate_height=1250.,bolt_start=1200.),'numeric_extreme':dict(P=1e101)
}
for name,kwargs in variants.items():
 out=analyze(replace(base,**kwargs));eq('domain/'+name+'/not_approved',out['approved'],False)
 if name=='overload':eq('domain/overload/status',out['status'],'FAIL')
 if name=='offset':eq('domain/offset/exact_reason',issue(out,'UNVERIFIED_ECCENTRIC_DISTRIBUTION'),True)
 if name=='root_compression':eq('domain/root_compression/signed_normal_retained',out['forces']['Vb']<0,True)
 if name=='numeric_extreme':eq('domain/numeric_extreme/adapter_retained',out['assumptions']['brace_adapter'],'single_1L_bolted')
 if name=='bolt_plane_weak':
  rr=cr(out);eq('individual_plane_overload_not_hidden',rr['1L_bolt1_plane1']['utilization']>1,True)
pooled=cr(analyze(replace(base,P=310000.)))
eq('per_hole_bearing_failure_visible',pooled['1L_angle_bearing1']['utilization']>1,True)
eq('pooled_bearing_sum_would_mislead',sum(pooled[f'1L_angle_bearing{j}']['resistance'] for j in range(1,5))>310000.,True)
# Two changed support-member profiles: dimensions are independent immutable catalog data.
from lro.bolted_corner import section as production_section
for label,kw,ind in [
 ('beam_W360x64',dict(beam_profile='W 360 x 64,0'),dict(eb=173.5)),
 ('column_W360x91',dict(column_profile='W 360 x 91,0 (H)*',continuity_width=110.,plate_width=340.,plate_height=340.,bolt_start=410.),dict(ec=176.5,w=340.,h=340.,stations=[410.,470.,530.,590.]))]:
 c=replace(base,**kw);out=analyze(c);p=im.setup(**ind);expected=im.joint(p)
 for k,v in p['ufm'].items():eq(label+'/UFM/'+k,out['forces'][k],v)
 compare_action(label+'/J',out['joint_beam_to_column'],expected['J']);compare_action(label+'/L',out['complete_cuts']['column_lower'],expected['lower'])
 primitive=im.primitives(p);runtime=cr(out)
 for k,v in primitive.items():
  id=k if k.startswith(('common_','gusset_')) else '1L_'+k
  for field in ['demand','resistance','utilization']:eq(label+'/'+id+'/'+field,runtime[id][field],v[field])
 for station in p['stations']:
  for delta in [-8.,-3.,0.,3.,8.]:
   for inc in [False,True]:
    want=im.section(p,station+delta,inc,True);got=production_section(c,out['geometry'],out['forces'],station+delta,inc,True)
    for field in ['A','centroid_v','I','N','V','M','nominal_VM']:eq(label+'/section/'+str(station+delta)+'/'+str(inc)+'/'+field,got[field],want[field])
# Physical support edges, not the shorter weld seams, determine detachment.
from lro.bolted_corner import block_state as production_block
for label,c,p in [('BC1',base,im.setup()),('phi40',build({'phi':40.,'w':360.,'h':330.,'stations':[375.,435.,495.,555.]}),im.setup(phi=40.,w=360.,h=330.,stations=[375.,435.,495.,555.]))]:
 g=geometry(c)
 for side,point in [('negative',p['polygon'][1]),('positive',p['polygon'][3])]:
  vertex_u=im.uv(p,point)[0]
  for delta,want in [(-.001,False),(-.000001,False),(0.,True),(.000001,True),(.001,True)]:
   path=production_block(c,g,vertex_u+delta,side);eq('support_transition/'+label+'/'+side+'/'+str(delta),path['active'],want)
for side in ['negative','positive']:
 eq('full_contact_not_seam/'+side,production_block(base,one['geometry'],430.,side)['active'],False)
# Explicit conservative long-group qualification boundary, source-reviewed at950mm.
for Lc in [949.999,950.,950.001,1000.,1270.]:
 c=replace(base,plate_width=900.,plate_height=900.,bolt_count=6,bolt_start=370.,bolt_pitch=Lc/5,beam_cut_x=1600.,upper_column_cut_y=1600.,column_end_top=3000.)
 out=analyze(c);eq('long_group/'+str(Lc)+'/specific_qualification_boundary',issue(out,'bolt_long_joint_distribution'),Lc>950.)
 eq('long_group/'+str(Lc)+'/actual_force_unchanged',out['brace']['force_per_gusset_hole'],100000./6)
 if Lc>950.:eq('long_group/'+str(Lc)+'/not_complete',out['complete'],False)
# Explicit additional point actions are retained at their stations.
extra=[{'label':'Independent beam point','member':'beam','point':[600.,40.],'Fx':4000.,'Fy':-2500.,'M':1000000.},{'label':'Independent column point','member':'column','point':[0.,300.],'Fx':-3000.,'Fy':1500.,'M':-300000.}]
out=analyze(replace(base,other_loads_excluded=False,other_loads=tuple(extra)));j=im.joint(im.setup());e=extra[0];wantJ=j['J'][:];wantJ[2]+=e['Fx'];wantJ[3]+=e['Fy'];wantJ[4]+=e['M']+(e['point'][0]-154)*e['Fy']-e['point'][1]*e['Fx'];compare_action('extra_actions/J',out['joint_beam_to_column'],wantJ)
wantL=j['lower'][:]
for e in extra:
 wantL[2]-=e['Fx'];wantL[3]-=e['Fy'];wantL[4]-=e['M']+e['point'][0]*e['Fy']-(e['point'][1]+1000)*e['Fx']
compare_action('extra_actions/L',out['complete_cuts']['column_lower'],wantL)
for label,res in out['equilibrium_residuals'].items():
 for i,v in enumerate(res):eq('extra_actions/equilibrium/'+label+'/'+str(i),v,0.)
report=dict(checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),numeric_comparisons=numeric,logical_observations=logical,failures=failures,rows=rows,source_hashes={f:hashlib.sha256((S/f).read_bytes()).hexdigest() for f in ['lro/corner_gusset.py','lro/bolted_corner.py','lro/bolted_angle_gusset.py','lro/bolted_opposed_angle_gusset.py']})
(O/'ADVERSARIAL_ACCEPTANCE.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(numeric_comparisons=numeric,logical_observations=logical,failures=failures),ensure_ascii=False,indent=2));sys.exit(bool(failures))
