"""Freeze independent acceptance expectations before loading the production kernel."""
from pathlib import Path
import hashlib,json,datetime,sys
from independent_model import setup,primitives,block,section,joint
H=Path(__file__).resolve().parent
if len(sys.argv)!=2:raise SystemExit('Supply a separate output directory; frozen expectations are never overwritten.')
O=Path(sys.argv[1]).resolve()
if O==H:raise SystemExit('Use a separate output directory; frozen expectations are immutable.')
O.mkdir(parents=True,exist_ok=True)
CASES={
 'BC1_1L':{},'BC1_2LT':{'count':2},
 'phi40_actual_polygon':{'phi':40.,'w':360.,'h':330.,'stations':[375.,435.,495.,555.]},
 'phi50_actual_polygon':{'phi':50.,'w':330.,'h':360.,'stations':[375.,435.,495.,555.]},
 'five_bolts':{'stations':[375.,420.,465.,510.,555.]},
 'three_bolts':{'stations':[370.,430.,490.]},
 'net_deduction20_physical18':{'drilled':False},
 'diameter20_hole22':{'db':20.,'dh':22.},
 'threads_excluded_1L':{'threads':[True,False]},
 'mixed_threads_2LT':{'count':2,'threads':[False,True]},
 'long_grip_1L':{'washers':90.},
 'long_grip_2LT':{'count':2,'washers':90.},
 'pretension_long_grip':{'washers':90.,'pretension':True},
 'gauge44':{'g':44.},
 'angle_catalog_R34':{'angle_b':88.9,'angle_A':1350.,'angle_ec':25.2},
 'angle_steel345':{'angle_fy':345.,'angle_fu':450.},
 'gusset_steel345':{'gusset_fy':345.,'gusset_fu':450.},
 'bolt_A490_fub1040':{'fub':1040.},
 'plate320':{'w':320.,'h':320.},
 'plate_thickness10':{'t':10.},
 'inner_clip50':{'clip':50.},
 'asymmetric_seam_margins':{'beam_start':20.,'column_end':25.},
 'per_hole_weak_angle_end':{'e_end':13.},
 'force_zero':{'P':0.},
 'force_overload300kN':{'P':300000.},
 'force_45kN_synthetic':{'P':45000.},
 'changed_signed_cuts':{'beam_cut':[920.,40.,25000.,-70000.,-35000000.],'upper_cut':[20.,1100.,-32000.,-700000.,-55000000.]}
}
rows=[]
for name,changes in CASES.items():
 p=setup(**changes);r=p['r']
 # Deliberately different exact stations than the production optimizer will choose.
 stations=sorted(set([sum(x[0] for x in p['uv'])/len(p['uv'])]+[u+d*r for u in p['stations'] for d in [-1.,-.75,-.125,0.,.25,.6,.9375,1.]]))
 paths=[block(p,u,side) for u in stations for side in ['negative','positive','tangent_U']]
 sections=[section(p,u,inc,net) for u in stations for inc in [False,True] for net in [False,True]]
 rows.append(dict(name=name,changes=changes,ufm=p['ufm'],joint=joint(p),primitives=primitives(p),block_paths=[r for r in paths if r],sections=[r for r in sections if r]))
x=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),method='Independently transcribed published contract, elementary coordinate/segment interval arithmetic and free-body integration; no production imports.',cases=rows)
text=json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n';(O/'EXPECTED_PARAMETERIZED.json').write_text(text)
lock={f:hashlib.sha256(((O if f=='EXPECTED_PARAMETERIZED.json' else H)/f).read_bytes()).hexdigest() for f in ['independent_model.py','build_expected.py','EXPECTED_PARAMETERIZED.json']}
(O/'REGENERATED_PARAMETER_HASHES.json').write_text(json.dumps(lock,indent=2)+'\n')
print(json.dumps({'cases':len(rows),'path_witnesses':sum(len(r['block_paths']) for r in rows),'section_witnesses':sum(len(r['sections']) for r in rows),'sha256':lock},indent=2))
