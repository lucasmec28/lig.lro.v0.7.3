"""Portable exact full-state parity for 19 legacy routes / 105 presets.

All original native fields, output fields, checks, issues and dataclass public
properties enter each digest. The optional full old snapshot is needed only for
forensic field diffs. This command never changes the expected baseline.
"""
from pathlib import Path
import argparse,sys,json,math,dataclasses,importlib,hashlib,datetime
parser=argparse.ArgumentParser();parser.add_argument('--source',required=True);parser.add_argument('--output');args=parser.parse_args()
H=Path(__file__).resolve().parent;S=Path(args.source).resolve();sys.path.insert(0,str(S))
import numpy as np
if np.__version__!='2.5.3':raise SystemExit('Exact canonical legacy replay requires the recorded NumPy 2.5.3 dependency; this is not a mechanical comparison failure.')
from lro.models import VERSION
from lro.corner_gusset import CornerGusset,analyze,COMPONENT_VERSION
expected=json.loads((H/'LEGACY_FULL_STATE_HASH_BASELINE.json').read_text())
def normalize(x):
 if isinstance(x,str):return x
 if x is None or type(x) in (int,bool):return x
 if isinstance(x,float):return x if math.isfinite(x) else {'nonfinite':repr(x)}
 if isinstance(x,dict):
  out={}
  for k,v in x.items():
   if k=='app_version' and v==VERSION:out[str(k)]='NORMALIZED_APP_VERSION'
   elif k=='component_version' and v in ('0.9.33-single-angle-corner-dev',COMPONENT_VERSION):out[str(k)]='NORMALIZED_CORNER_VERSION'
   else:out[str(k)]=normalize(v)
  return out
 if isinstance(x,(list,tuple)):return [normalize(v) for v in x]
 if isinstance(x,set):return sorted(normalize(v) for v in x)
 if dataclasses.is_dataclass(x):
  d={f.name:normalize(getattr(x,f.name)) for f in dataclasses.fields(x)}
  props={k for cls in type(x).__mro__ for k,v in vars(cls).items() if isinstance(v,property)}
  for k in sorted(props):
   try:d['property:'+k]=normalize(getattr(x,k))
   except Exception as e:d['property:'+k]={'property_error':type(e).__name__+':'+str(e)}
  return d
 raise TypeError(type(x))
def digest(x):return hashlib.sha256(json.dumps(normalize(x),ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
rows=[];errors=[];modules={};presets={}
for want in expected['cases']:
 mod,name=want['module'],want['name']
 if mod not in modules:
  modules[mod]=importlib.import_module('lro.'+mod);provider=importlib.import_module('lro.examples') if mod=='engine' else modules[mod];presets[mod]=provider.presets()
 if name not in presets[mod]:errors.append(dict(module=mod,name=name,error='missing legacy preset'));continue
 c=presets[mod][name];actual=dict(module=mod,route=want['route'],name=name,input=c.to_dict(),output=modules[mod].evaluate(c));sha=digest(actual)
 row=dict(module=mod,name=name,actual_sha256=sha,expected_sha256=want['canonical_complete_state_sha256'],passed=sha==want['canonical_complete_state_sha256']);rows.append(row)
 if not row['passed']:errors.append(row)
natives=[]
for old in expected['old_welded_corner_native_inputs']:
 c=CornerGusset.from_dict(old['input']);same_native=normalize(c.to_dict())==normalize(old['input']);sha=digest(analyze(c));row=dict(name=old['name'],native_unchanged=same_native,result_sha256=sha,passed=same_native and sha==old['canonical_output_sha256']);natives.append(row)
 if not row['passed']:errors.append(row)
result=dict(checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),routes=expected['route_count'],old_presets=len(rows),welded_native_round_trips=len(natives),failures=errors,full_state_rows=rows,old_welded_native_rows=natives,normalization=expected['normalization'],canonical_rules='UTF-8, ensure_ascii=False, sorted object keys, compact separators, allow_nan=False; list order retained; nonfinite legacy floats tagged as {nonfinite: repr(value)}, never zeroed or omitted.',expected_baseline_sha256=hashlib.sha256((H/'LEGACY_FULL_STATE_HASH_BASELINE.json').read_bytes()).hexdigest())
if args.output:Path(args.output).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(routes=result['routes'],presets=len(rows),native_round_trips=len(natives),failures=errors),ensure_ascii=False,indent=2));sys.exit(bool(errors))
