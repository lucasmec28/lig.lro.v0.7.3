# Independent engine acceptance plan, 0.9.34

Prepared before the production checkpoint. This is a finite engineering acceptance of the declared ordinary static, direct-contact, nominal connection-axis adapter. It is not a structure/fabrication certificate, a proof of exact 3D centroid closure, or a pointwise contact-stress solution.

## Independent references

- Frozen BC1 input and 51 new / 73 common strength rows; actual demand, resistance, utilization, pass state and source remain distinct.
- Exact 102 conventional block-path witnesses and 160 gross/net station witnesses, including the included/excluded crossed-hole load limits. Numerical screen extrema remain distinct from interval-certified results.
- Fresh standard-library parameterized calculator in this directory: polygon intersections, retained support fractions, discrete force/moment summation, circular section deductions, physical L/U blocks, material/bolt primitives and COMPLETE_CUTS equilibrium. It imports no production module and no production formula helper.
- Immutable received 0.9.33 app is the only legacy parity baseline. Full native state, checks, diagnostics and public result properties are compared. Normalization is limited to app/component version tokens and fingerprints mathematically derived from those tokens, if present.

## Finite matrix

1. BC1 1L positive, 1L negative, 2L-T: all applicable new and common strength rows; exact cut/path witnesses; one central plate, P once, one/two physical planes; same shared mechanics.
2. Fresh actual mutations: bolt number, first station, pitch, diameter, thread location on each plane, long grip and drilled/net-hole distinction; gauge, angle profile/steel, gusset steel, beam steel, column steel, continuity steel, root weld grade; plate width/height/thickness/clip, angle, support seam margins.
3. Geometric/force-sign adversaries: support-retained L candidates inactive, remote free exits, U distinct legs, hole interior extrema and tangencies; contained non45-degree placements; actual negative receiving normals retained; failure versus unqualified detailing explicit; actual P=0, negative P and excessive P; minimum45kN separately labeled from unchanged complete actual cuts.
4. Per-hole overload cannot pass through pooled group capacity. 2L does not double gusset/roots/joint. A face flip changes physical centroid z, not nominal plane resistance. Explicit work-point/spatial offsets remain outside the selected model.
5. Native JSON: both topologies round-trip, strict fields and versions, fixed assumptions, physical plane count, units and finite types; missing/extra/wrong-type/NaN/Inf/incorrect-family/incorrect-axis combinations reject without mutating the accepted model. Legacy welded payloads retain exact behavior.
6. All existing nineteen routes and every legacy preset: full-result parity and old welded corner cases. Runtime files and receipt hashes recorded. Production test counts reported separately, never substituted for independent engineering comparisons.

## Decisions

GO only when numerical rows, physical force/geometry witnesses, domain status behavior, native state and historical parity all agree at the reviewed source hashes. UI/drawing/report/package verification is separately owned. Missing historical external bearing spreadsheet is already known and not newly claimed restored. Additional FEA is not introduced as an artificial gate.
