# Independent engine acceptance and replay, 0.9.34

Run from the extracted APP source root. Ordinary application use needs no optional audit archive. Python dependencies are those of the APP; exact historical digest replay requires the recorded NumPy 2.5.3. Numerical mechanical comparison uses the stated engineering tolerance.

## APP-only replay

Choose a separate writable output directory. The following commands do not alter frozen expectations:

```
python docs/independent_engine0934/review_runtime.py . /tmp/engine0934
python docs/independent_engine0934/review_adversarial.py . /tmp/engine0934
python docs/independent_engine0934/review_native.py . /tmp/engine0934
python docs/independent_engine0934/replay_legacy_hashes.py --source . --output /tmp/engine0934/LEGACY_PARITY_REPLAY.json
python docs/independent_engine0934/review_legacy_long_groups.py . /tmp/engine0934
python docs/independent_engine0934/probe_legacy_long_joint.py --source . --expect guarded --output /tmp/engine0934/LEGACY_SCOPE_PROBE.json
python -m pytest -q tests/test_corner_gusset0932.py tests/test_single_angle_corner0933.py tests/test_bolted_corner0934.py tests/test_long_bolt_scope0934.py
```

The mechanical replay verifies the exact frozen oracle hash and the explicitly reviewed two-record boundary amendment. The historical replay reevaluates every old preset and compares a SHA256 over its complete input/result/public state. Missing or differing rows fail. It never overwrites the baseline to accept a mismatch.

Expected numerical generation is independent of production imports. To reproduce its27 case values in a separate directory:

```
python docs/independent_engine0934/build_expected.py /tmp/engine0934/regenerated
```

Compare the cases array with EXPECTED_PARAMETERIZED.json. Only generation time is nondeterministic; no mechanical field is removed or normalized. The delivered EXPECTED_REGENERATION_CHECK.json records equality of every generated case field.

## Optional full historical evidence

The optional AUDITORIA companion contains only docs/independent_engine0934/LEGACY_COMPLETE0933.json:50,145,517 bytes, SHA256539f43232cbb9594b9fec51a65fede583a65e3b0cc8e9a294297ff9455d13c70. It enables forensic field-level inspection of the old full output. It is not required for ordinary use or the APP-only105-preset exact hash replay.

If installed in this directory, legacy_snapshot_all.py can capture a current full snapshot and check_legacy_parity.py can compare both complete records. These optional commands write full snapshots and are intentionally separate from the lightweight APP-only gate.

The two historical one-root adapters receive an explicit >950mm applicability-only safety guard. The15-case legacy diagnostic replay confirms unchanged complete mechanical fields; the18-case scope probe checks boundaries, actualzero/minimum and pretension. These intentional long-group status changes are separate from the105 ordinary presets, which remain unchanged.

See SOURCE_INDEPENDENCE_AND_LIMITS.md, the qualified method and the acceptance receipt for the exact model boundaries. Passing this engine replay is not UI, drawing/report, package, fabrication or whole-structure approval.
