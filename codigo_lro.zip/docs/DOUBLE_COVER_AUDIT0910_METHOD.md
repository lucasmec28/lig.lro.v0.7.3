# Duas talas: revisão delimitada 0.9.10

10 de outubro de 2026. Segunda família existente revisada, na sequência definida após Single plate. Não acrescenta família, capacidade global ou novo mecanismo de cálculo.

## Método mantido e conclusão

Mantêm-se as resistências NBR 8800:2024, versão corrigida 2025; o grupo elástico de parafusos; as duas talas iguais; os sinais de N/V e o equilíbrio local da coluna; e os limites de componentes isolados já implementados. A conferência mínima de 45 kN é caso separado, na mesma direção da ação original. Compressão continua calculável: não foi transplantada a restrição de tração da Single plate.

Quando as verificações locais atendem, a conclusão é **VERIFICAÇÕES LOCAIS ATENDEM · ESCOPO INCOMPLETO**. Duas qualificações locais seguem expressas junto ao resultado, na interface e na memória:

1. Rotação/flexibilidade da emenda com duas talas e do conjunto soldado, incluindo aplicabilidade do atalho db/2 + 1,6 mm e da rótula nominal no meio da folga.
2. Estabilidade acoplada e compatibilidade da distribuição de forças na nervura escalonada, horizontais frontais e coluna, incluindo contenção lateral efetiva.

Uma futura conclusão integral exige método analítico publicado aplicável à topologia ou modelo analítico explícito de estabilidade/deformação, com contenções e domínio demonstrados. Não se exige genericamente FEA, restrição inventada de perfil ou texto do usuário para validar cálculos rotineiros. As responsabilidades globais dos membros são separadas e não encerram essas duas questões locais.

Falha resistente finita permanece **NÃO ATENDE**, mesmo junto a uma falha numérica independente ou pendência de escopo. Falha numérica sem falha resistente comprovada recebe conclusão própria. Detalhamento, geometria/dados inválidos, extrapolação e ações nulas têm categorias distintas. Demanda nula de um mecanismo é N/A; momento local e compressão continuam ativos nos ramos correspondentes.

## Correções confirmadas

- Importação atômica: valores aceitos precisam ser representáveis pelos controles sem substituição silenciosa. Perfis completos são preservados, mesmo com nome coincidente com catálogo. Área, massa, produto, proveniência, dimensões não comerciais e sinais não são recriados por inferência. Uma rejeição mantém projeto e memória anteriores. Rascunhos condicionais ficam separados dos controles transitórios.
- Filetes: cada interface física tem suas espessuras e comprimento real: nervura/alma, nervura/horizontal, horizontal/mesa e horizontal/alma. A perna compartilhada dos horizontais deve satisfazer ambas as juntas. NBR 6.2.6.2.1–.2/Tabela 11: a testemunha de filete 3 mm em junta 9,525/10 mm viola o mínimo de 5 mm. Trata-se de detalhamento não atendido; todas as suas resistências calculadas continuam atendendo. O valor informado é conservado.
- A linha `dc_col_web` foi retirada por dominância estrita: com L=H−2c, Rbase=L·min(sfin;sweb) ≤ L·sweb < 2H·sweb=Rcol, sob a mesma demanda |V|. Mantém-se o metal-base da interface real. Isso não elimina uma verificação independente exigível de apoio.
- Um resumo dos parafusos reúne os dois lados; ambos os cálculos, pegas e calços permanecem disponíveis. Cada seção física tem uma envoltória dos ramos elástico, líquido e de estabilidade; os 12 ramos e ambos os parafusos são desenvolvidos mesmo na memória compacta. Não se descartou o limite elástico nem a ruptura líquida. Total: 29 cálculos retidos e 20 linhas de resumo, sem usar contagem como aprovação do nó.
- O corte líquido da alma da viga já está em `dc_net_beam`, An=(hp−n·dn)tw. Não se acrescentou o ramo copiado de altura total da Single plate, redundante quando hp<d. Cts=0,5 e a envoltória absoluta dos blocos U/L permanecem escolhas conservadoras declaradas para esta topologia de uma linha por lado.
- Errata 1:2025 corrige NBR 6.5.4 para Le/r>25. A curva χ em todos os comprimentos é mantida como escolha conservadora explícita, sem mudar números incidentalmente. A idealização isolada Q=1 e K/L não demonstra a contenção efetiva do conjunto.
- Cortes e braços são explícitos: talas/alma, e+g/2; aba livre da nervura, u+g/2; trecho interno, b+u+g/2. São envoltórias resistentes locais, não uma distribuição física simultânea única. As soldas horizontais/alma sob H integral não reduzem as demais demandas.

## Fontes e fronteira da verificação

NBR: 6.1.1–6.1.3 para compatibilidade e rotação; 6.1.5.2 para mínimo resistente; 6.2.5 e 6.2.6.2/Tabela 11 para soldas; 6.3 para parafusos/furos; 6.5.3–6.5.7 para chapas, compressão, corte, bloco e calços. Errata de 25/02/2025 diretamente conferida. O complemento de flexão é a primitiva F11 já implementada com Cb=1 e γa1; esta revisão não afirma nova verificação integral do AISC 360-22 e erratas.

Gerdau, Souza e Fortney/Thornton foram usados para topologia, primitivas e identificação da qualificação faltante. Não são somados como procedimentos completos alternativos. A reconciliação P901 de Single plate é separada e não qualifica esta montagem por analogia.

Os desenhos continuam ilustrativos: não representam um mapa completo de soldagem para fabricação. Word recalcula a partir do projeto canônico recebido, evitando misturar resultado antigo e dados novos. Invalidação por entrada e por variante detalhada permanece ativa.

## Validação finita

Testes focados incluem ações assinadas/mínimo, compressão, calços 6,3/19 mm, limites de filete sem arredondamento, falhas finitas/numéricas, não conformidade de detalhamento, escopo local, todos os ramos retidos e memória fiel. Os três presets e três exemplos originais conservam exatamente cada demanda/resistência retida; a geometria original da planilha continua inválida, sem ajuste para verde. Testes AppTest usam o uploader real e os bytes efetivos de download, além de rascunhos ocultos/navegação e rejeição atômica.

Não houve teste de pixels em navegador: a restrição de socket do ambiente foi respeitada. Testes focados não significam aprovação de toda a suíte, do conjunto estrutural ou das demais famílias. Não houve publicação ou implantação.
