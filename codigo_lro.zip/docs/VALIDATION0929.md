# Validação focada · 0.9.29-load-conventions-dev

## Resultado

Gate de fonte aprovado: **488 testes distintos passaram**, nenhum falhou. O agregado executou 488 casos; os 223 testes do helper foram repetidos depois dos ajustes finais de acessibilidade e espaçamento e não foram somados novamente. O único aviso é a depreciação de um iterador de parametrização herdado nos testes de seleção guiada.

- Natureza axial exata nas 16 famílias para positivo, negativo, zero, zero negativo, notação científica, valores minúsculos e subnormais; entradas não finitas não recebem aprovação.
- Setas somente dos componentes aplicáveis, em eixos e sentidos próprios; bases, end plate, emendas W, orientação pilar e cantoneiras inclinadas testadas. Nenhum valor de esforço no SVG.
- Helper sem escrita em estado, com referência invariante ao sinal do caso. SVG acessível e alternativa textual no elemento de imagem Streamlit.
- Catálogo/navegação direta e guiada, importações nativas, idas e voltas entre famílias, rejeições atômicas e controles legados cobertos pelos testes focados.
- Aceitação independente de interface e representações gráficas: `LOAD_CONVENTIONS0929_UI_ACCEPTANCE.json`. Contrato de sinais/eixos: `LOAD_CONVENTIONS0929_SIGN_ACCEPTANCE.json`.
- Comparação AST de todos os 110 módulos Python preexistentes: idênticos após retirar somente os novos pontos de apresentação e a identificação de versão. Dados de catálogo preservados; 809 arquivos originais de 0.9.28 permanecem íntegros.

## Limites do registro

Não foi executada a suíte histórica completa, nem uma nova auditoria mecânica integral. A ausência histórica do oráculo externo de contato de parafusos não é tratada como teste aprovado nesta rodada. Não houve alteração de requisitos, instalação de dependências, upload, publicação, implantação, ampliação de domínio ou aprovação de fabricação.

O JSON de validação contém a lista deduplicada dos testes, os hashes finais de runtime e o escopo exato. O congelamento completo da fonte serve de entrada ao empacotamento; extração e smoke dos ZIPs finais pertencem ao gate separado do pacote.
