# Validação da fonte 0.9.40

Desde a última versão entregue, 0.9.38, esta fonte reúne quatro mudanças: corte externo perpendicular limitado da chapa de nó; correção de falso alerta geométrico da Ligação 18; opção de talas internas na emenda W convencional; e correção do caminho das demandas locais da alma do pilar no 4E. A 0.9.39 foi apenas um checkpoint interno, preservado e nunca entregue.

## Execução integral final

**5.823 casos distintos: 5.822 aprovados, uma falha histórica, zero erros e zero pulados.** Uma execução completa da árvore final, dividida em quatro grupos disjuntos de arquivos, manteve idênticos os 342 arquivos de runtime, testes, fixtures e catálogos antes e depois. A coleção e o registro de casos coincidem exatamente, sem duplicação ou omissão. Não se somam a estes números os casos de revisões independentes, imagens, páginas ou amostras geométricas.

A única falha é test_axial_double_angle.py::test_bolt_bearing_oracle_file_and_opposite_loaded_free_ends, pela ausência do arquivo externo original next_connection_scope/bolt_bearing_oracle.json. Não foi inventado substituto, criado skip ou declarado resultado aprovado. Os logs, XMLs e identidades estão em validation0940/aggregate.

## Correção 4E e limites preservados

O escoamento local da alma do pilar usa max(Ff;Fc); o enrugamento usa Fc. T dos parafusos e C do contato continuam em seus próprios caminhos. As resistências NBR permanecem inalteradas. A correção pode aumentar ou diminuir a demanda conforme os braços reais; não se impõe envelope fictício entre método antigo e corrigido. Os casos real e mínimo mantêm ações e sinais próprios. 4ES, 8ES e PINNED conservam seus compromissos exatos, exceto a versão global explicitamente enumerada.

A revisão independente tem 61 entradas literais, 78 casos manuais, 12 verificações de texto Word e limiares adversos nos dois sentidos. As verificações herdadas de cap, W e Lig18 permanecem ligadas aos bytes aprovados; não há método novo de base/end plate, segunda etapa de afunilamento, alteração de K ou desbloqueio de compressão 1L. As três alterações de testes antigos são somente identidades de versão global/método, com originais e diferenças preservados. Todos os 42 arquivos de fixtures herdados continuam exatos.

## Saídas e proveniência

Os exemplos selecionados atuais são regenerados na fonte corrigida 0.9.40 e identificam seus dados nativos, resultados integrais, Word e imagens. A aplicação geradora é separada da versão de cada componente: os caps conservam identidades de esquema 0.9.39 e o W convencional conserva 0.9.6-w-inner-option-dev. Alterações de rodapé/linha de versão são diferenciadas das mudanças reais de demanda no 4E. Os exemplos antigos permanecem explicitamente históricos.

Os compromissos compactos e comandos críticos ficam no APP, sem dependência da fonte anterior ou dos acompanhantes opcionais. A revisão de fonte é separada da conferência do carregador no APP efetivamente entregue. Não há alegação de inspeção visual humana de todas as páginas; a cobertura precisa está no aceite independente de saídas.

Esta aceitação de fonte não autoriza fabricação, certifica um projeto estrutural real ou substitui a qualificação do pacote. Empacotamento isolado, gate APP-only e decisão final de entrega são etapas posteriores.
