# Narrow expectation changes in 0.9.37

All existing pytest cases remain. No inherited tests or frozen evidence were deleted.

- Application VERSION is0.9.37; the unchanged corner component remains0.9.36. The integration assertion now tests those separate identities.
- The guide keeps all19 route IDs and existing category ID axial_tension; its display says axial domain depends on family. Only the expected display label changes.
- Load convention for the welded one-root symmetric2L-T route becomes conditional_compression; all exact-sign cases remain, including subnormals and zero. Other family domains are unchanged.
- The old negative-N one-root engine/UI cases now expect diagnostic NOT_VERIFIED, signed minimum45kN, no approval, and an available diagnostic memory. V/M/T, unsupported topology and geometry cases preserve their original blockers.
- Compression controls appear only for N<0; native values stay retained while hidden. The original default-field UI test still checks every non-compression field is visible and all new hidden values equal the accepted native input.

New suites test the reviewed source fixture, actual unknown boundaries, native legacy migration and strict method premises, boundary loss/staleness, signed minimum/zero, receiver branches, compactness, full curve and transition, physical root clipping, mixed signs, numerical/type validation, diagnostic artifacts, independent root/receiver evidence and report invalidation.

Exploratory failing logs remain in review0937. They are not final coverage. The inherited missing external bolt-bearing oracle is not fabricated or counted as passed.
