# Selected examples and exact APP inputs

The 84 selected artifacts were freshly generated on 0.9.39 runtime/test hold v3 (SHA-256 9529de4824ec95b791742d35213c8f8393e5e89954a991d1951822f465c65283). This is their actual generation provenance, not a claim of regeneration on a later hold. Their engine, drawing and report bytes remain unchanged through the final UI/test-only correction; the independent bridge records that relationship.

APP_NATIVE_RESULT_MAP.json binds the 28 native/result copies in APP to the external selected set. SELECTION_MANIFEST.json binds all 84 artifacts and preserves their component versions, failures and pending states. PNG, SVG and Word artifacts are delivered separately in EXEMPLOS; their full-precision models and reproducible checks remain in APP.

Cap fixtures preserve the bounded physical cut and all roots. The 45/135-degree welded examples remain outside scope. W inner-on remains pending and outer-only retains its required failure at utilization 1.021251536153864. Lig18 still has incomplete perforated-fin and assembly-access qualification. None of these examples is fabrication approval.
