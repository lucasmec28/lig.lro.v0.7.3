"""Read-only final-source selected cap/Lig18 examples. Explicit source/output/hold roots."""
from pathlib import Path
import argparse,sys,json,hashlib,importlib,os,platform
from dataclasses import asdict,is_dataclass
from io import BytesIO
from zipfile import ZipFile
p=argparse.ArgumentParser();p.add_argument('source');p.add_argument('output');p.add_argument('hold');p.add_argument('expected_cap');p.add_argument('lig18_input');p.add_argument('prior_lig18');p.add_argument('normalizer_dir');a=p.parse_args()
source=Path(a.source).resolve();out=Path(a.output).resolve();assert not out.is_relative_to(source)
sys.path[:0]=[str(source),str(Path(a.normalizer_dir).resolve())]
from legacy_svg_normalization import normalize_svg
sha=lambda b:hashlib.sha256(b).hexdigest();holdpath=Path(a.hold).resolve();H=json.loads(holdpath.read_text())
def held():return {k:sha((source/k).read_bytes()) for k in H['files']}
assert held()==H['files'];expected=json.loads(Path(a.expected_cap).read_text());records={};origins={}
def write(path,data):
 path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data);return {'path':str(path.relative_to(out)),'size':len(data),'sha256':sha(data)}
def jbytes(x):return json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False).encode()
def canonical(x):return sha(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode())
def members(b):
 with ZipFile(BytesIO(b)) as z:return {k:sha(z.read(k)) for k in z.namelist()}
def load(route):
 m=importlib.import_module('lro.'+route);d=importlib.import_module('lro.'+route+'_drawing');r=importlib.import_module('lro.'+route+'_report')
 for x in (m,d,r):origins[x.__name__]={'path':x.__file__,'sha256':sha(Path(x.__file__).read_bytes())}
 return m,d,r
for name,e in expected['fixtures'].items():
 route='welded_angle_gusset' if name.startswith('w1_') else 'welded_double_angle_gusset' if name.startswith('w2_') else 'bolted_angle_gusset' if name.startswith(('b1_','b2_')) else 'corner_gusset'
 cls={'welded_angle_gusset':'WeldedAngleGusset','welded_double_angle_gusset':'WeldedDoubleAngleGusset','bolted_angle_gusset':'BoltedAngleGusset','corner_gusset':'CornerGusset'}[route]
 m,d,r=load(route);c=getattr(m,cls).from_dict(e['native']);result=getattr(m,'evaluate',getattr(m,'analyze',None))(c)
 assert c.to_dict()==e['native'];assert canonical(result)==e['evaluated_result_canonical_sha256']
 files=[write(out/'cap'/(name+'_native.json'),jbytes(c.to_dict())),write(out/'cap'/(name+'_result.json'),jbytes(result))]
 for fmt in ('png','svg'):
  b=d.image_bytes(c,fmt=fmt)
  if fmt=='png':assert sha(b)==e['png_sha256']
  else:assert (sha(b) if e['svg']['mode']=='raw' else normalize_svg(b)['sha256'])==e['svg']['sha256']
  files.append(write(out/'cap'/(name+'.'+fmt),b))
 for detailed in (False,True):
  mode='detailed' if detailed else 'compact';b=r.create_report(c,detailed=detailed);assert members(b)==e['docx_members'][mode]
  files.append(write(out/'cap'/(name+'_'+mode+'.docx'),b))
 records[name]={'route':route,'native_metadata':{k:v for k,v in c.to_dict().items() if k!='connection'},'result_canonical_sha256':canonical(result),'accepted_fixture_equality':True,'files':files}
from lro.double_cover import DoubleCoverConnection
from lro import models
m,d,r=load('double_cover');prior=Path(a.prior_lig18).resolve()
for u in (0,10):
 name='lig18_u'+str(u);input_path=Path(a.lig18_input)/('fixture_u'+str(u)+'.json');c=DoubleCoverConnection.from_dict(json.loads(input_path.read_text()));result=m.evaluate(c);payload=asdict(result)
 assert c.extension==u and c.internal_fin_perforation and result.geometry['assembly_access']=='unverified'
 files=[write(out/'lig18'/(name+'_native.json'),jbytes(c.to_dict())),write(out/'lig18'/(name+'_result.json'),jbytes(payload))]
 comparison={'result_exact':payload==json.loads((prior/(name+'_result.json')).read_text())};assert comparison['result_exact']
 for fmt in ('png','svg'):
  b=d.image_bytes(c,fmt=fmt);files.append(write(out/'lig18'/(name+'.'+fmt),b))
  if fmt=='png':comparison['png_byte_exact']=b==(prior/(name+'.png')).read_bytes();assert comparison['png_byte_exact']
 for detailed in (False,True):
  mode='detailed' if detailed else 'compact';b=r.create_report(c,result,detailed=detailed);files.append(write(out/'lig18'/(name+'_'+mode+'.docx'),b));comparison[mode+'_word_members_exact']=members(b)==members((prior/(name+'_'+mode+'.docx')).read_bytes());assert comparison[mode+'_word_members_exact']
 records[name]={'route':'double_cover','input_path':str(input_path.resolve()),'input_sha256':sha(input_path.read_bytes()),'native_metadata':{k:v for k,v in c.to_dict().items() if k!='connection'},'pending_internal_fin_and_access_preserved':True,'comparison_to_previously_viewed_outputs':comparison,'files':files}
assert held()==H['files']
receipt={'source':str(source),'hold_sha256':sha(holdpath.read_bytes()),'source_held_unchanged':True,'held_files':H['files'],'app_version':models.VERSION,'python':platform.python_version(),'module_origins':origins,'groups':records,'cap_fixture_count':10,'cap_prior_full_result_matches':10,'cap_prior_artifact_matches':40,'lig18_fixture_count':2,'source_input_provenance':'Cap inputs copied exactly from accepted portable fixture commitments. Lig18 inputs read from original u0/u10 fixture files and canonicalized by current final-source APIs.'}
(out/'CAP_LIG18_PROVENANCE.json').write_bytes(jbytes(receipt));print(json.dumps({'cap':10,'lig18':2,'artifacts':sum(len(x['files']) for x in records.values()),'held_source_unchanged':True,'hold_sha256':receipt['hold_sha256']}))
