# Fourteen-group outer-cut acceptance map

The source specification and independent challenge remain the scope authority. This index identifies evidence without adding unlike case counts. Manufacturing and global structural approval are outside this review.

1. Analytic 45-degree polygon, physical last bolt, 35 mm gauge, 20.6375 mm physical hole, common 1L/2L-T bolt count: test_outer_gusset_end0939.py and independent mechanical group 002.
2. 90-degree crop, reflected 135-degree detail, near-axis primitive, old-vertex ties, no-trim and invalid distances: new core tests, independent mechanical group 011, independent output fixtures and no-trim layout guards.
3. Last physical row/end updates and independent old angle-end margins: new core reference test and actual UI/import tests.
4. Root contacts/positive footprints, bounded actual exits, holes, tools and local strip containment: independent 500-polygon group, preserved-footprint counterexample and new core invalid-margin/first-exit tests; inherited physical assembly tests remain active.
5. Tabulated minimum, actual free-edge maximum and applicable one-leg weld termination: explicit minus/equal/plus tests in test_outer_gusset_end0939.py. The exact one-leg cap boundary now uses only the shared dimensional geometry tolerance, with unchanged original-edge comparisons. Standard physical hole and net deduction policies remain separate.
6. Polygon area/centroid/chords and rational horizontal extrema: independent analytic witness plus 500 polygons/2,500 chords; 24 rational records and 39 perforated-section records. The adverse cap changes stress/path capacity while roots remain unchanged.
7. Real longitudinal exits, L/U paths and supported-contact exclusions: 243 independent corner block witnesses, one-root path reconstruction and tangent/interior-event checks.
8. Root/member/receiver actions and COMPLETE_CUTS: independent four-adapter comparison, exact semantic contact-end boundary regressions and unchanged source-identical unrelated receiver modules.
9. Signed loads and minimum-force cases: independent N=0, +/-1 and +/-45,000 probes; N/2 per L with one total common-plate/root force.
10. Old/current strict native schema, exact precision, recomputation and stale evidence: seven-case numeric baseline commitment, 19 exact opposed payload commitments, real UI uploads/downloads and input/geometry mutation checks.
11. Compression domains: independent one-root, CC1 and BCC1 probes preserve K, root/strip mechanics, real receiver failure and actual evidence rebinding; 1L remains unqualified.
12. Physical drawing: independent source polygon/semantic roots/physical gauge assertions, active and reflected PNG/SVG inspection, separate inner-relief label and preserved brace continuation.
13. Current-state UI/native/compact and detailed Word/PDF: independent output replays verify current embedded PNG identity, precise native values and stale-result rejection. The retained display-precision suite is run separately and also belongs to the full aggregate.
14. Final gates: independent source hash seals plus the complete held combined aggregate and package-only artifact gate. The aborted early caption run is retained as incomplete and contributes no final coverage. The final aggregate result and immutable source inventory are issued only after completion.

References: ../independent_outer_cap0939/, ../qualification_outer_end0939/, ../independent_outer_outputs0939/ and ../VALIDATION0939.json. Large rendered review pages are retained outside APP; the replay inputs, equations, scripts and expected commitments needed for the release-critical checks remain inside APP. The historical missing external bearing oracle remains explicitly unqualified.
