# Release-critical APP-only replays

Use the extracted APP source after the outer loader has performed its normal extraction. Install the declared requirements and development requirements in the selected Python environment. Keep all output outside immutable APP; use absolute paths and PYTHONDONTWRITEBYTECODE=1. The original review dependency versions are recorded in EXECUTION_ENVIRONMENT0939.json. Different floating-point or rendering-library bytes are discrepancies to investigate, not permission to relax an exact comparison.

No following critical check requires source0938 or optional examples/source companions. The prior-source comparison scripts remain historical diagnostics, not prerequisites for this gate.

## Mechanical cap and compatibility

Under docs/independent_outer_cap0939/portable, run each script with --source APP --output-dir OUTPUT:

- verify_source_hashes.py
- replay_engine.py
- replay_opposed.py
- replay_corner_compression.py
- replay_descriptions.py
- replay_termination_boundaries.py

The adjacent frozen commitments and independent oracle helpers in docs/qualification_outer_end0939 ship in APP. This includes seven original numeric commitments and 19 complete opposed payload hashes. The exact-one-leg test contains 52 cases. Source hashes, numerical values and failed/pending states must remain exact.

Run docs/independent_outer_cap0939/legacy_metadata_projection/portable/replay_legacy_metadata.py with the same arguments. It executes the actual candidate test helpers and old-native constructor, preserves 29 legacy hashes and checks 29 mutation witnesses. Its six protected oracle fixtures and 13 mechanical source bindings cannot change.

## Current outputs and UI

Follow docs/independent_outer_outputs0939/portable/README.md for the self-contained final output mode. It uses four hashed old-native fixtures in place of importing old source and runs 56 tests: 43 original output contracts, four no-trim layouts and nine final arrangement callbacks. Zero migration skips are required. Expected active native/result/PNG/Word-member commitments ship with the replay; optional rendered companions are not required. The current-source fresh replay and actual packaged outer-loader replay are distinct gates.

## W option and Lig18

With PYTHONPATH set to APP and LRO_SOURCE=APP, run pytest on both docs/qualification_w_inner0939/test_independent_option_portable.py and test_independent_ui_portable.py. Set LRO_REPLAY_OUT to an external directory. All 80 checks must pass; the compact legacy-native baseline and force witnesses ship in APP.

Run docs/qualification_internal_bolt_alert0939/replay_geometry_portable.py with LRO_SOURCE=APP. It checks the 500 independent physical envelope witnesses, counterexamples, real collision, retained internal pendency and report text. The historical 300-external/100-internal source-comparison replay requires the old source explicitly and is not part of the self-contained package gate.

## Production suite and evidence

The complete production suite is pytest APP/tests with APP on PYTHONPATH. docs/validation0939 contains the one complete four-group execution of the final held runtime and test tree, its exact collection and case ledger. The runner copied there is historical invocation provenance; its original workspace paths are not the APP-only command.

The inherited test test_axial_double_angle.py::test_bolt_bearing_oracle_file_and_opposite_loaded_free_ends remains a real failure because its independent external bolt-bearing oracle is absent. Do not fabricate, skip or count it as passed. Source acceptance expects exactly this disclosed failure, zero other failures, zero errors and zero skips.

Selected inputs/results are mapped by current_examples/APP_NATIVE_RESULT_MAP.json. Rendered examples retain their true generation hold v3 and are tied to final hold v4 by CURRENT_HOLD_REBIND.json; this is an explicit reviewed dependency bridge, not relabeling or a claim of regeneration after the callback fix.
