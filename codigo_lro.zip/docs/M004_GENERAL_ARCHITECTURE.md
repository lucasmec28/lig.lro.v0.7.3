# W M004: integration boundary for signed N/M/V

**Historical checkpoint.** This document records its original axial/research stage. A separate conventional N/M/V family now exists in `lro/w_splice_conventional.py`, with its own `W_CONVENTIONAL_NMV_SCOPE.md`. Statements below that general W work is pending describe that historical stage, not the current selector as a whole. The 0.9.13 audit is solely the axial M004 family; see `AXIAL_SPLICE_AUDIT0913_METHOD.md`.


This document records implementation architecture, not an approved resistance method. The current 0.9.0-w-dev source is an internal axial-tension checkpoint. The requested complete W family must include simultaneous compression, strong-axis moment and shear. If a verification is blocked, retain its exact gap, await reference material and proceed to other connection families as requested.

## Already implemented and independently checked

- `lro/w_splice.py`: eight-cover balanced physical topology, pure-tension transfer, corrected holes, materials, conventional axial net/block/bearing/bolt checks, individual construction/access states and project persistence.
- `lro/w_splice_equilibrium.py`: signed N/M/V statics only. Area/inertia partition, baseline flange forces, a separate full-M flange demand envelope, left/right web group couples, vector force of each bolt, group equilibrium and whole-cover equilibrium. No resistance or approval result.
- `tests/test_w_splice_equilibrium.py`: the P398 independent benchmark, pure force/couple/shear, independent signs and complete reversal. The scalar group resultant is never treated as a substitute for the group's couple.

The axial evaluator rejects any M/V/T or negative N before calculating an axial capacity. General inputs must not bypass that gate or relabel an axial result as a beam-splice approval.

## Proposed general evaluation pipeline

1. Validate physical topology and actual same-section properties, including the strong-axis inertia and explicit root envelope. Balanced flange and web stacks remain required. No thickness transitions or fillers without a separate model.
2. Read each real simultaneous factored load case. Retain N/M/V signs. State where loads are referenced and whether global second-order and integrity actions are included. Do not independently floor every force component or silently apply the tension-only minimum policy to the general case.
3. Calculate and save the baseline statically admissible allocation. Derive flange envelope design actions separately; the full-M envelope is a conservative design envelope, not a second equilibrium solution.
4. For every left/right web group, save actual bolt coordinates and force vectors on both the continuous covers and the member. Each equal cover takes half the vector; each bolt plane takes the corresponding half force. Preserve physical loaded directions for bearing and free edges.
5. Recover cover/member actions at both sides of every bolt station and at interval endpoints using a cut free body. Between force stations, moments vary linearly. A small butt gap is not automatically the unsupported plate length.
6. Run only source-closed component checks. Each result includes a physical component ID, case ID, mechanism, actual demand/resultants, formula/source, conditional premises and a supported/pending state.
7. Aggregate by the most restrictive necessary mechanism. A required pending check prevents general approval even when every computed bolt/plate subcheck passes. Distinguish physical impossibility, code detailing failure, access/fabrication review, verified strength failure and an unsupported analytical model.

## Exact resistance gates

### General web block rotation (known open gate)

For every real U/L/corner/partial block B and a declared reference O:

- FX = sum(qx)
- FY = sum(qy)
- C = sum((x-xO) qy - (y-yO) qx)

Reference translation must transform C consistently. The missing analytical basis is a justified N/V/C resistance interaction for the actual failure boundary, with the bolt-bearing contribution and NBR factors. The scalar NBR block expression plus Cts=0.5 does not provide a residual-moment capacity. Pure moment produces zero net group force and nonzero couple, so a resultant-only check would erase demand. This exact gap is already established; do not repeat an unbounded search or invent an interaction.

### Compression covers and web N/M/V interaction

Required source closure: effective restraints and unsupported spans; flexural/plate/torsional stability as applicable; force interaction; hole-weakened connection region. Cover restraint is a declared engineering premise that must be justified, not inferred solely from a bolt row or a small gap. For the existing corrected NBR 6.5.4 stocky branch, Le/r<=25 is conditional on the applicable strip restraint; the branch does not itself establish plate local stability or combined-action resistance.

### Member net sections and minimum actions

The tensile all-hole envelope is conservative only for the current pure-tension model. General N/M/V requires simultaneous stresses/actions at actual critical member stations. Member-strength recommendations and minimum connection actions require an explicit general load envelope; do not reuse max(N,45 kN) on signed compression/M/V without a verified rule.

## Partial-result contract

A research result may contain:

- Geometry and source-supported applicability
- Exact signed force/bolt equilibrium and section cuts
- Verified per-bolt/per-plane shear, directional bearing or other specifically closed checks
- An exact list of pending mandatory mechanisms and the input/reference needed to close each

Its aggregate state remains `ENGINEERING_MODEL_PENDING`; `COMPLETE_CHECKS_PASS` is unavailable until all necessary checks are supported. A partial result must not be exported with a complete W-connection approval headline.

## Follow-on sequence

If the named analytical gate cannot close with the available references, retain this checkpoint and the precise missing basis, await the promised materials and advance to the supplied single-angle and double-angle details. This does not mean the general W splice has been completed.
