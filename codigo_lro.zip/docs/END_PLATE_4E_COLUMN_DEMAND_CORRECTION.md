# 4E: força de mesa nas verificações locais da alma da coluna

Correção isolada de 2026-10-12. Identidade do método 4E:
`endplate-4e-column-flange-demand-20261012-v1`.
Não altera a versão global, topologia, domínio de validade ou capacidades.

## Demanda e resistência correspondentes

Para cada caso completo, com N positivo de tração e z=d−tf:

- Ff=|M|/z+max(N;0)/2.
- Fc=|M|/z+max(−N;0)/2.
- Escoamento local da alma da coluna: FSd=max(Ff;Fc).
- Enrugamento da alma da coluna: FSd=Fc.

N é dividido entre as mesas. Ignora-se o alívio favorável da outra mesa, como
na rota de transferência já adotada. A inversão de M troca a mesa física em
tração no detalhe simétrico; não altera esses módulos. O detalhe apenas
superior continua rejeitando M negativo. O caso mínimo de 45 kN usa seu
próprio N/V escalado, mantém M e não substitui a Entrada.

O 4E legado usava max(T;C) e C nesses dois estados-limite. T=4Tb é a resultante
dos parafusos, e C=max(T−N;0) é a resultante de contato. Essas grandezas não
são a força de mesa que solicita a alma da coluna nos estados-limite
citados. Seus próprios cálculos, verificações de contato e interações dos
parafusos permanecem intactos. A correção pode aumentar **ou diminuir** a
demanda da coluna conforme os braços reais; não se inventa um envelope
max(demanda antiga; demanda corrigida).

As resistências NBR existentes permanecem, com E=200000 MPa e γa1=1,10:

- Escoamento: FRd=1,10(2,5k+ln) fyc twc/γa1, k=tfc e ln=0.
- Enrugamento: FRd=0,33 twc² √(E fyc tfc/twc)/γa1.

São limites conservadores de extremidade e comprimento carregado nulo,
sem crédito ao raio, ao espalhamento ou a enrijecedores. A coluna física
continua sujeita às premissas já declaradas de continuidade, contenção,
ausência de cargas locais concorrentes e alcance apenas local. O uso da
menor capacidade não transforma T/C em força de mesa nem dispensa corrigir
a demanda. Não se importam fatores LRFD ou capacidades americanas para as
resistências NBR.

## Fontes conferidas

- DG39 (2023), §3.5, p.37: metade da compressão axial é acrescentada à força
  da mesa comprimida nas verificações pertinentes da coluna.
- DG39 §3.7.6, pp.47–48, eq.3-48: verificação da coluna baseada nas forças de
  mesa da eq.3-39.
- DG39 exemplo 5.3-1 (4E), p.132, página PDF142: Pu=2510/(24−3/8)=106,243386243
  kip, comparado ao escoamento local de 47,7 kip e enrugamento de 62,7 kip.
  Esse exemplo confirma a natureza da demanda, não as capacidades NBR.
- DG39 exemplo 5.3-2 (4ES), pp.147–148: a força de mesa de 337 kip confirma a
  mesma separação física. A rota 4ES já usava Ff/Fc e não foi modificada.
- NBR 8800:2024, versão corrigida 2025, §§5.7.3.1/5.7.3.2(b) e
  5.7.4.1/5.7.4.2(b), pp.64–65 impressas / pp.86–87 do PDF fornecido:
  escoamento sob força localizada de tração ou compressão e enrugamento
  sob compressão. Com ln=0, as expressões acima são seus limites adotados.

DG39 foi confirmado visualmente pelo leitor do material fornecido;
os trechos NBR foram conferidos visualmente por revisor independente.
A revisão não afirma ter examinado integralmente a errata DG39 em PDF.

## Testemunha numérica sem alteração de capacidades

Viga W410×38,8 / coluna CS600×281, pfo=60 mm, pfi=45 mm,
M=±40 kN·m, V=45 kN, z=390,2 mm, h1=454,6 mm e h2=340,8 mm.
Valores em kN; ambos os sinais de M dão os mesmos módulos:

| N | Escoamento anterior | Escoamento corrigido | Enrugamento anterior | Enrugamento corrigido | Contato C preservado |
|---:|---:|---:|---:|---:|---:|
| −2 | 102,578325371 | 103,511532547 | 102,578325371 | 103,511532547 | 102,578325371 |
| 0 | 100,578325371 | 102,511532547 | 100,578325371 | 102,511532547 | 100,578325371 |
| +2 | 101,559466935 | 103,511532547 | 99,559466935 | 102,511532547 | 99,559466935 |

Resistências inalteradas: escoamento 224 kN; enrugamento 642,554900378 kN;
contato 280 kN. As seis testemunhas continuam atendendo às verificações
realizadas. Seções sintéticas exclusivamente aritméticas nos testes colocam
a capacidade entre a demanda antiga e a corrigida e demonstram mudanças de
estado sem esconder falhas em outros mecanismos. Não representam perfis de
catálogo nem liberação de projeto ou fabricação.

## Rastreabilidade e regressão

As linhas da coluna mostram FSd, Ff/Fc, referência, capacidade NBR e caso
governante. O JSON nativo adiciona column_web_yield_force e
column_crippling_force aos parâmetros 4E e conserva T/C. A memória Word
compacta/detalhada explica a separação. Entradas, digest de entrada e sinais
permanecem; snapshots antigos são recalculados com a nova revisão do método.

`tests/test_end_plate_4e_column_demands.py` cobre sinais N/M/V, detalhes
superior e simétrico, casos real/mínimo, capacidades manuais, limiares
sintéticos nos dois sentidos de mudança, limites de alcance, JSON e rótulos
Word. A única expectativa histórica ajustada é a identidade **4E** no teste
de importação legado em `test_end_plate_4es0922.py`.

Paridade independente exige 4ES, 8ES e PINNED integralmente iguais, bem como
todas as linhas 4E fora dos dois estados-limite corrigidos. Não se acrescentam
MRE, linhas resistentes, reforços de coluna, alavanca fina, sismo ou análises
globais; nenhum limite físico ou tolerância de aprovação foi relaxado.

O replay autocontido em `docs/independent_4e_column_demands/` usa entradas
literais e compromissos congelados, incluindo equações manuais independentes.
Seu modo APP usa o carregador real dos quatro arquivos entregues e confere
origens dos módulos; `--source` é somente evidência de fonte.

`docs/qualification_4e_column_demands/generate_current_witnesses.py` regenera
sete testemunhas em JSON nativo, resultados e Word compacto/detalhado a partir
da fonte corrigida explicitamente selecionada, exigindo sua versão global.
Os artefatos são escritos fora da fonte. Não reutiliza resultados anteriores.
São exemplos de regressão; a geração por si só não qualifica paginação,
instalação final, projeto estrutural ou fabricação.
