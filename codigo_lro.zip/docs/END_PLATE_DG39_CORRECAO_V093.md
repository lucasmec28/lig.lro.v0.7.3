# Revisão local das end plates na versão 0.9.3

Esta revisão corrige estados-limite ausentes da família **end plate engastada 4E não enrijecida**, sem alterar as entradas dos projetos anteriores. O atendimento da tensão elástica global das juntas CJP não demonstrava a transferência local de forças junto aos parafusos. Foram reproduzidos três casos de catálogo antes aprovados pelas verificações antigas, mas reprovados nas verificações locais agora incluídas. Não se deve interpretar resultados anteriores como demonstração desses estados-limite.

## Fontes e divisão entre normas

- AISC Design Guide 39 (2023), §3.7.5, pp.44–45, eq.3-38 a 3-41 e figura 3-17: demandas e regiões de transferência entre viga e chapa; exemplo p.129.
- DG39 exemplo 5.3-1, pp.125–126: escoamento e ruptura por cisalhamento do prolongamento não enrijecido, solicitados por metade da força da mesa tracionada.
- DG39 §4.2.2, pp.51–52, eq.4-3: largura efetiva limitada tanto para a chapa quanto para a mesa da coluna.
- DG39 §4.1.3, p.50: materiais de viga ou coluna acima de 55 ksi não avaliados pelo procedimento.
- ABNT NBR 8800:2024, versão corrigida 2025, §6.2.5.1 e tabela 9, pp.76 e 78: resistência das juntas de penetração total com metal de adição compatível; §6.5.1/6.5.3(a), p.94: escoamento local à tração; §6.5.5(a,b), p.95: escoamento e ruptura por cisalhamento.

O DG39 fornece o modelo local, a distribuição e o mínimo complementar de desenvolvimento da junta. As resistências usam a NBR, com γa1=1,10 e γa2=1,35. Não se trocam automaticamente fatores LRFD por fatores NBR nem se usa a dedução líquida AISC de 1/16 pol. no lugar da dedução NBR do projeto.

## Transferência local incluída

Para cada caso de ações, com z=d−tf:

- Ff=|M|/z+max(N;0)/2, sem crédito ao alívio por compressão axial.
- Fc=|M|/z+max(−N;0)/2, no lado comprimido.
- A alma junto à linha interna e o prolongamento ativo da chapa recebem **Ff/2**, pelo grupo 4E com dois parafusos por linha. Ff é diferente da resultante calculada dos parafusos. O cortante vertical V não substitui essas demandas.
- lwt=pfi+152,4 mm, contado a partir da face interna da mesa tracionada; hw=d−2tf.
- lws=min(hw−lwt;hw/2), fora da região de tração ativa, no lado comprimido. Para M negativo, as regiões são espelhadas. O arranjo de extensão somente acima continua limitado a M positivo.

Novas verificações, cada uma identificada no motor, na tabela da interface, na memória e no retrato JSON:

1. ep_beam_web_local_tension: Ff/2 ≤ fyb·tw·lwt/γa1.
2. ep_extension_shear_yield: Ff/2 ≤ 0,6fyp·bp·tp/γa1. Usa a largura física da chapa.
3. ep_extension_shear_rupture: Ff/2 ≤ 0,6fup·(bp−2dn)·tp/γa2. São dois furos na seção transversal; dn=dh para furos executados com broca conforme opção do projeto, ou dh+2 mm nos demais casos.
4. ep_weld_cjp_flange_local: max(Ff;Fc;0,60fyb·bf·tf) ≤ min(fyb;fyp)·min(bp;bf)·min(tp;tf)/γa1.
5. ep_weld_cjp_web_local: max(Ff/2;0,60fyb·tw·lwt) ≤ min(fyb;fyp)·min(tp;tw)·lwt/γa1.
6. ep_weld_cjp_web_shear: |V| ≤ 0,6min(fyb;fyp)·min(tp;tw)·lws/γa1.

O produto dos menores fy e espessura nas juntas é conservador em relação às duas partes conectadas. O mínimo complementar de 60% é uma demanda de desenvolvimento da junta, não uma resistência calculada por LRFD. O critério elástico da seção inteira foi mantido como verificação adicional.

Na plastificação da mesa da coluna, Yc agora usa bfc,ef=min(bfc;bf+max(tp;25,4 mm)). A largura física permanece no desenho e nas demais verificações em que é aplicável. Não se confunde esse limite de largura efetiva com uma restrição geométrica que proíbe colunas largas.

## Pendências e domínio

- Se lwt exceder hw, o motor não cria área de alma inexistente: conserva as demais contas, omite as três verificações locais da região de alma não representada e emite **VERIFICAÇÃO LOCAL INCOMPLETA**. Isso se aplica, por exemplo, ao estudo W200 anterior. Não há bloqueio arbitrário da geometria nem aprovação dessa transferência.
- Se bp<bf, a junta de mesa só recebe crédito por min(bp;bf), mas a transferência para a junta parcial fica explicitamente pendente de modelo e detalhamento próprios.
- As faixas empíricas do DG39 continuam como avisos de extrapolação; não foram convertidas em impossibilidades físicas. Materiais de viga/coluna com fy>380 MPa, limite arredondado de 55 ksi, também recebem ressalva.
- Linhas intermediárias continuam sem crédito resistente e com ressalva do arranjo ampliado. Nervuras, sismo, fadiga, lajes com participação resistente, detalhes inclinados e ligações fora do grupo 4E não foram liberados.
- As juntas CJP dependem de execução e qualificação compatíveis, sem furos de acesso que alterem a geometria calculada. A integração global da estrutura e a classificação rotacional fora do domínio declarado permanecem externas.

## Casos independentes que demonstram a correção

Todos os esforços abaixo são ações já de cálculo. V=45.000 N e N=0 nos três casos.

- VS 450×95 → CS 550×498, todos os aços A572 Gr.50; bp=250, tp=38,1, g=150, db=31,75, pfi=pfo=60, e=45 mm, M=500 kN·m: escoamento local da alma, Sd=580.046,403712 N; Rd=419.683,090909 N; η=1,382105728. A tensão elástica global anterior atendia.
- W 410×85,0 → CS 550×498, todos A572 Gr.50; bp=181, tp=22,6, g=85, db=31,75, pfi=pfo=50, e=45 mm, M=400 kN·m: ruptura da extensão, Sd=501.504,513541 N; Rd=484.318 N; η=1,035486010. A alma local e a tensão elástica global atendem.
- Mesmo VS 450×95 do primeiro caso, chapa A36 e M=360 kN·m: junta CJP da alma, Sd=417.633,410673 N; Rd=304.118,181818 N; η=1,373260251. A alma isolada tem η=0,995116124 e a tensão elástica global atende.

## Rastreabilidade e validação

O JSON exporta um retrato recalculado das verificações, referências, substituições, pendências, geometria de cálculo e SHA-256 das entradas. O retrato importado nunca concede aprovação: abrir um arquivo antigo ou alterado recalcula os resultados. Memória Word e SVG apresentam o estado atual e a mesma assinatura; o Word recalcula a partir das entradas mesmo se receber um resultado antigo. Todos os seis novos itens constam também da memória resumida.

Oráculos independentes: validation/v093/test_endplate_dg39_independent.py. Regressão dos artefatos: tests/test_end_plate_dg39_artifacts.py. Os testes anteriores da rotulada permanecem, e as expectativas históricas foram alteradas somente onde a nova cobertura adiciona verificações ou a informação da largura efetiva. A versão 0.9.2 congelada não foi modificada.
