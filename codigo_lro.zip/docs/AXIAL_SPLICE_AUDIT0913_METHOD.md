# Axial W M004 finite audit correction

Date: 10 October 2026. Application 0.9.13-axial-splice-audit-dev. The serialized axial component/schema identifier remains 0.9.0-w-dev so existing honest projects remain compatible. Work is in a new source copy; source0912 is immutable.

## Mechanical scope and sources

This remains two identical coaxial W members joined by eight continuous balanced covers under static positive axial tension only. Any nonzero M, V or T, or negative N, remains outside this family. The separate conventional N/M/V family is unchanged and is not qualified by this audit. No member compression design, slip qualification, generalized block interaction, new family or fabrication release is introduced.

Controlling resistance source: supplied corrected ABNT NBR 8800:2024 with Errata1 dated25 February2025; SHA256 2289dd360ae938982f44ce6b0633968652199604867172e9d0d454e71256b16d. Relevant printed pages:39–42 gross/net tension and corrected Ct=1;70 mandatory45kN and discretionary member recommendation;83–85 bolt-plane shear and bearing;90–92 physical holes, net deduction policy, spacing and edge checks;94–96 cover effective-area cap and block failure. Normal ULS factors remain γa1=1.10 and γa2=1.35, with both block shear branches divided by γa2.

Supplied M004 drawing, PADRÃO DE LIGAÇÕES-5Model, printed72, SHA256 fa3dd2c170b395fc513c4a5e75cb4669d460621224c5394fdaa7ca9532e97d5b, establishes the eight-cover geometry. Its10mm clearances and bolt dimensions are workshop presets, not substituted NBR minima. SCI/BCSA P398 printed53 supports only axial area allocation. SSB Part5 AppendixA printed60 supports root-area allocation to flange force; printed67–68 and76–77 support the physical block-path distinctions. Their Eurocode resistance/slip provisions are not imported. Source registry entries are in fontes.json. The read-only predecessor audit recorded inspection of these sources; this correction does not claim a new full-book review.

Gerdau chapter9 EP1/EP2 describes different details and is not an eight-cover formula source. P901 II.A-20/21 single-plate shear examples do not replace this axial model. DG39 and its errata are not dependencies here. Historical general-W-pending architecture/validation notes are explicitly historical because the separate conventional family now exists.

Unchanged equations and physical distinctions:

- Aw=(d−2tf)tw, allocated force to each flange=N(1−Aw/A)/2, web=N Aw/A. Root residual remains in flange demand; local flange resistance uses its conservative rectangle.
- Balanced bo=2bi and equal thickness/material/length give outer F/2, each inner F/4, and each web cover Nw/2. Both real shear planes and serial member ends remain explicit.
- Whole-W net area A−4dn tf−3dn tw retains all seven holes, including noncoincident stations without unproved stagger credit. Covers alone retain Ae=min(An,0.85Ag).
- Physical holes and Table14 net deductions stay distinct. Actual member butt and cover outboard loaded ends, all physical U/L paths, path prefixes and mirrors are retained.
- Exact2.7db spacing (54mm for M20), material/product/thickness restrictions, 2–6 flange rows, fixed2×3 web grid, 950mm span and5db grip bounds remain unchanged.

## Import and artifact integrity

The real uploader parses the strict schema, then validates complete widget representability before touching live widget/project/report state. Unsupported family, material, bolt, diameter, row count, hidden grid, or below-control dimensions reject with their exact field/value/reason. No HP→W relabel, material fallback, bolt snapping or row repair is permitted. Supported custom W remains available; a separate persistent custom draft/root envelope survives catalogue and family navigation. Accepted signed loads and ordinary representable decimals remain exact apart from normal unit-conversion roundoff.

Word and drawing entry points ignore caller-supplied result dictionaries and recalculate from the current immutable input. Status, input dimensions, force allocation and primitive rows therefore share a current snapshot. SHA256 input metadata is diagnostic only; a forged digest cannot authorize a result. Compatibility arguments remain accepted. Diagnostic Word is available for blocked inputs and is marked unapproved; no fake favorable index is generated for an uncalculated case.

## Known loads when selected Nc is absent

For complete data, every demand is f_i N with fixed positive f_i and load-independent R_i. Nd=max(Nreal,45kN,Nrecommendation)≥Nreal, so ηi(Nd)≥ηi(Nreal). This proof allows one monotone envelope; no moment-family multi-case machinery is added.

When the selected slenderness recommendation lacks Nc,Rd, member_recommendation_N is null, never a fabricated zero resistance. Only known Nd=max(Nreal,45kN) is calculated; supplementary_complete and adopted_action_complete are false, and missing Nc and/or source fields are explicit. An actual finite failure remains the headline beside the unresolved recommendation. At N=2,250,000N, member_web_block_U_columns1to3_k2 has Agv1980, Anv1267.2, Ant712.8mm², Rd491040N and actual η1.0173621985593488. Access and integrity pending premises remain visible simultaneously. N=0 remains unevaluated.

Finite numerical overflow or nonfinite intermediate calculations return NUMERICAL_FAILURE/numerical_failure, with no capacity approval. This is separate from malformed INVALID_INPUT, physical INVALID_GEOMETRY, unsupported scope, detailing failure, finite resistance failure and missing engineering context. All safe stops remain.

## Consolidation without resistance gain

The 193 baseline primitive rows remain unchanged. Eighteen principal envelopes group five physical component classes by section, bearing and block mechanism, plus the whole W and two bolt-plane groups. Every envelope carries a copied complete governing primitive row, all primitive IDs, physical component IDs and serial-region IDs. Governing demand, capacity, fraction, formula, reference and path are never assembled from different rows. No piece-count or serial-side multiplication changes resistance.

Exact symmetry and balanced outer/inner section ratios permit grouping. The normative bearing sum is dominated by the end/interior equal-force hole checks in this N-only model. Member-web gross ratio equals whole-W gross ratio algebraically. No universal equivalence is asserted between gross/net, bearing/block, member/cover, or distinct U/L paths. All primitive branches stay in the detailed appendix and result dictionary.

## Finite verification record

The implementation evidence is maintained beside the source under review0913/axial_w_splice_audit. The existing independent oracle is retained at26 deterministic fixtures and46,829 comparisons; only the expected missing-Nc behavior, numerical category and source path are updated. No expanded fuzz campaign or whole-suite certification is claimed. Focused axial engine/import/artifact and affected family-navigation regressions, actual Streamlit AppTest download evidence, and rendered Word verification are separate coverage claims. AppTest is not browser-pixel evidence. No Chromium socket restriction is bypassed.

See the frozen implementation manifest, delta and deduplicated verification-command record supplied for independent review. This is a development correction; no upload, deployment or next-family work is authorized by it.
