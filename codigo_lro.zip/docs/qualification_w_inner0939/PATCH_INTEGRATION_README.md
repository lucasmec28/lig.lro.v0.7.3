# Optional conventional W inner flange plate patch

## Apply only to the combined candidate

Base: immutable review0938/source0938, SOURCE GO tree SHA256 930be0b2544a39e8442c5b617e11c9fcf6da8cb1e7ee5046aca907dffb38e054; runtime 4c9d862ca57e321b6431c18aa6a31963037242f8ef033652b11c574469778c55. All 1,861 frozen base file hashes were rechecked unchanged.

Apply optional_inner_splice.patch with `patch -p1` from the integration source root. Eleven changed/new files: seven W splice modules, two focused test modules, copied independent force witnesses and one method/compatibility document. No app.py, models.py, global VERSION or README changes. The exact patch was replayed on base copies and all eleven resulting file hashes matched the held candidate.

The complete source used for this patch is source_candidate/, also archived in w_inner_option_source_candidate.zip. PATCH_SOURCE_RECEIPT.json records the patch/archive/inventory hashes. HELD_SOURCE_HASHES.json identifies every changed/new file. CANDIDATE_SOURCE_FILES.json inventories the complete 1,865-file candidate, excluding caches. The inherited release_manifest.json is intentionally not rebuilt: this is an isolated patch, not a released distribution. The integration owner must rebuild package integrity metadata and run the combined full gate.

## Behavior

The conventional option is named “Considerar talas internas nas mesas”. It removes F2/F3/F5/F6 together. Default true and the balanced model's primitive values remain unchanged. Off has F1/F4/W1/W2, full force in each outer flange plate, one physical flange shear plane and two web planes. Exact gauge bi+c is captured on toggling off, then stored independently. Inactive geometry is absent from calculation/native/artifact/binding payloads. Versioned known old conventional projects are strictly validated, migrate to true, retain their exact old binding compatibility and visibly report the upgrade. Axial M004 is unchanged.

The required -600/+120/+100 witness must FAIL: flange-plane demand 88764.52494873547 N, resistance 86917.3967493176 N, η=1.021251536153864. No dimensions or loads were changed to make it pass. The real flange offset e=(tf+t)/2 is explicit and the intact-W restraint idealization is documented with primary sources. Unsupported assembly retains its bounded status.

## Evidence and remaining release work

Independent acceptance: independent_review/INDEPENDENT_REVIEW.md and its receipts. It verifies 31 conventional baseline cases, three exact axial result/PNG/Word cases, 80 independent tests, migration notice, adversarial inactive values/bindings and final rendered Word pages.

Focused final JUnit/log: focused_final.xml/log. Report-only final replay: report_replay_final.xml/log. Legacy UI/artifact final replay: legacy_ui_artifacts_final.xml/log. Earlier exploratory logs remain for provenance and are not extra distinct coverage. Final source report text was clarified after the first frozen run; final report-targeted replay and rendered artifacts use its final hash 7e9b6432579a7e36a2c8f730389000eec51acf59650c7f6d2c71bc4bf99a87f8.

preview/ contains on/off native projects, full results, three-view PNG/SVG and concise/detailed Word. These are demonstrative default inputs, preserving PENDING on the balanced case and FAIL on outer-only; they do not establish actual-project restraint or global stability. Reports were generated from the final source. Rendered PDF/PNG directories and RENDER_QA.json are inspection evidence, not alternative released source.

No deploy, push or upload was performed. This patch needs the integration owner's complete aggregate gate, regenerated manifest, actual executable/artifact verification and normal release delivery before being described as the combined production release.
