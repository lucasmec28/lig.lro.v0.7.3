import os
from copy import deepcopy
from dataclasses import replace
from pathlib import Path
import json,math,itertools
import pytest
from lro.w_splice_conventional import WConventional, evaluate,presets,capacity_binding,input_digest,active_engineering_payload
from lro.w_splice_conventional_drawing import drawing_svg,image_bytes
from lro.w_splice_conventional_report import create_report
SOURCE=Path(os.environ.get('LRO_SOURCE',Path(__file__).resolve().parents[2])).resolve()
OUT=Path(os.environ.get('LRO_REPLAY_OUT','replay_w_inner_output')).resolve();OUT.mkdir(parents=True,exist_ok=True)
BASE=next(iter(presets().values()))
OFF=replace(BASE,include_inner_flange_plates=False,flange_bolt_gauge=BASE.flange_inner_width+BASE.inner_clear_band)
WITNESSES=json.loads((SOURCE/'tests/fixtures/optional_inner_splice/independent_force_witnesses.json').read_text())

def flange(r):return [v for v in r['checks'] if ':bolt_flange_' in v['id']]
def other(r):return {v['id']:v for v in r['checks'] if v['component'].startswith(('member','web','bolt_web'))}

@pytest.mark.parametrize('w',WITNESSES,ids=lambda w:w['case'])
def test_independent_witnesses(w):
 c=replace(OFF,N=w['N'],M=w['M'],V=w['V']);r=evaluate(c);m=r['load_model'];p=flange(r)
 for key,expected in [('top_force_N',w['top']),('bottom_force_N',w['bottom']),('top_outer_force_N',w['top_outer_off']),('top_cover_centroid_offset_mm',w['offset']),('nominal_centroid_couple_discrepancy_Nmm',w['nominal_centroid_couple_delta'])]:assert m[key]==pytest.approx(expected,rel=1e-14)
 assert max(v['demand'] for v in p)==pytest.approx(w['max_single_plane'],rel=1e-14)
 assert max(v['utilization'] for v in p)==pytest.approx(w['max_single_plane_ratio'],rel=1e-14)
 assert r['geometry']['flange_grip_mm']==w['flange_grip_off']
 if w['max_single_plane_ratio']>1:assert any(v['status']=='FAIL' for v in p)

@pytest.mark.parametrize('N,M,V',itertools.product((-600e3,0.,600e3),(-120e6,0.,120e6),(-100e3,0.,100e3)))
def test_signed_topology_and_unchanged_web_member(N,M,V):
 on=replace(BASE,N=N,M=M,V=V);off=replace(OFF,N=N,M=M,V=V);a=evaluate(on);b=evaluate(off)
 assert len(a['physical_covers'])==8 and len(b['physical_covers'])==4
 assert len(flange(a))==64 and len(flange(b))==32
 assert other(a)==other(b)
 assert b['bolts']['total_bolts']==44
 assert len([v for v in b['checks'] if ':bolt_' in v['id']])==56
 assert not any('inner' in v['id'] or 'inner' in v['component'] for v in b['checks'])
 assert not any('inner' in k for k in b['components'])
 assert not any('inner' in k for k in b['physical_regions'])
 for pos in ('top','bottom'):
  assert b['components']['outer_'+pos]['force_N']==2*a['components']['outer_'+pos]['force_N']
  for id,v in {v['id']:v for v in a['checks'] if v['component']=='outer_'+pos}.items():
   vv=next(x for x in b['checks'] if x['id']==id)
   assert vv['capacity']==v['capacity'] and vv['demand']==2*v['demand']
 assert b['load_model']['web_groups']==a['load_model']['web_groups']
 assert b['geometry']['web_grip_mm']==a['geometry']['web_grip_mm']
 ids=[i for e in b['mechanism_envelopes'] for i in e['member_check_ids']]
 assert sorted(ids)==sorted(v['id'] for v in b['checks'])

@pytest.mark.parametrize('bi,c',[(-1.,-900.),(0.,float('nan')),('bad',None),(float('inf'),float('-inf'))])
def test_inactive_data_no_effect(bi,c):
 a=replace(OFF,flange_inner_width=bi,inner_clear_band=c)
 assert evaluate(a)==evaluate(OFF)
 assert a.to_dict()==OFF.to_dict()
 assert input_digest(a)==input_digest(OFF) and capacity_binding(a)==capacity_binding(OFF)
 assert WConventional.from_dict(a.to_dict()).to_dict()==OFF.to_dict()

@pytest.mark.parametrize('bad',[None,True,0,-1,float('nan'),float('inf'),'170'])
def test_bad_active_gauge(bad):
 c=replace(OFF,flange_bolt_gauge=bad)
 assert evaluate(c)['status']=='INVALID_INPUT'
 with pytest.raises(ValueError):c.to_dict()

@pytest.mark.parametrize('bad',[None,0,1,'true','false',[],{}])
def test_strict_flag(bad):
 c=replace(BASE,include_inner_flange_plates=bad)
 assert evaluate(c)['status']=='INVALID_INPUT'
 with pytest.raises(ValueError):c.to_dict()

@pytest.mark.parametrize('field,value',[('assembly_detail','unsupported_detail'),('flange_rows',1),('web_rows',1),('web_levels',2),('concentric',False),('static',False),('torsion',1.),('normal_combination',False)])
def test_unsupported_detail_not_pass(field,value):
 c=replace(OFF,N=0.,M=0.,V=0.,minimum_action_policy='actual_actions_engineer_choice',minimum_reference='Bounded test only',**{field:value})
 r=evaluate(c)
 assert r['status']!='LOCAL_CHECKS_PASS_WITHIN_SCOPE'


def test_native_current_legacy_and_external_binding():
 legacy=json.loads((Path(__file__).parent/'legacy_native_baseline.json').read_text())['native'];c=WConventional.from_dict(legacy)
 assert c.include_inner_flange_plates is True and c.flange_bolt_gauge==c.flange_inner_width+c.inner_clear_band
 assert c.member_capacity_binding==legacy['connection']['member_capacity_binding']
 assert evaluate(c)['member_external']['status']=='EXTERNAL_SUPPLIED_CHECKED'
 assert evaluate(replace(c,N=c.N+1))['member_external']['status']=='EXTERNAL_INPUT_STALE'
 off=replace(c,include_inner_flange_plates=False)
 assert evaluate(off)['member_external']['status']=='EXTERNAL_INPUT_STALE'
 off=replace(off,member_capacity_binding=capacity_binding(off))
 assert evaluate(off)['member_external']['status']=='EXTERNAL_SUPPLIED_CHECKED'
 assert evaluate(replace(off,flange_inner_width='dormant',inner_clear_band=None))['member_external']['status']=='EXTERNAL_SUPPLIED_CHECKED'
 assert evaluate(replace(off,flange_bolt_gauge=off.flange_bolt_gauge+1))['member_external']['status']=='EXTERNAL_INPUT_STALE'
 for base in (legacy,BASE.to_dict(),OFF.to_dict()):
  for mutation in ('missing','foreign','forged','extra_profile','missing_assumption'):
   data=deepcopy(base)
   if mutation=='missing':data['connection'].pop('flange_t')
   if mutation=='foreign':data['connection_type']='w_splice_m004_balanced_axial_tension'
   if mutation=='forged':data['fixed_assumptions']['topology']='two_outer_four_inner_two_web_covers' if base==OFF.to_dict() else 'bogus'
   if mutation=='extra_profile':data['connection']['profile']['extra']=1
   if mutation=='missing_assumption':data['fixed_assumptions'].pop('no_end_bearing_credit')
   with pytest.raises(ValueError):WConventional.from_dict(data)


def test_current_native_requires_active_fields_only():
 for c in (BASE,OFF):
  data=c.to_dict()
  assert data['schema_version']==2 and WConventional.from_dict(data).to_dict()==data
  inactive=['flange_bolt_gauge'] if c.include_inner_flange_plates else ['flange_inner_width','inner_clear_band']
  for field in inactive:
   assert field not in data['connection']
   bad=deepcopy(data);bad['connection'][field]=1
   with pytest.raises(ValueError):WConventional.from_dict(bad)


def test_no_forged_balanced_artifact_pass():
 forged=evaluate(BASE);forged['status']='LOCAL_CHECKS_PASS_WITHIN_SCOPE'
 for row in forged['checks']:row['status']='PASS'
 svg=drawing_svg(OFF,forged)
 assert 'VERIFIED_SUBCHECK_FAIL' in svg
 assert input_digest(OFF) in svg
 for label in ('cover_F2','cover_F3','cover_F5','cover_F6','F1 sobre F2'):
  assert label not in svg
 assert 'cover_F1' in svg and 'cover_F4' in svg
 (OUT/'outer_only.svg').write_text(svg)
 (OUT/'outer_only.png').write_bytes(image_bytes(OFF,forged))
 (OUT/'inner_on.png').write_bytes(image_bytes(BASE))
 from docx import Document
 from io import BytesIO
 for detailed in (False,True):
  payload=create_report(OFF,forged,detailed=detailed)
  doc=Document(BytesIO(payload));text='\n'.join(p.text for p in doc.paragraphs)+'\n'+'\n'.join(c.text for t in doc.tables for row in t.rows for c in row.cells)
  assert 'VERIFIED_SUBCHECK_FAIL' in text
  assert input_digest(OFF) in text
  assert 'flange_inner_width' not in text and 'inner_clear_band' not in text
  assert 'F2 F3 F5 F6' not in text
  (OUT/('outer_only_detailed.docx' if detailed else 'outer_only_concise.docx')).write_bytes(payload)
  (OUT/('outer_only_detailed.txt' if detailed else 'outer_only_concise.txt')).write_text(text)

@pytest.mark.parametrize('N,V,M,minN,minV,minM',[(-1000.,2000.,120000000.,3000.,-4000.,-2000000.),(1000.,-2000.,-120000000.,-3000.,4000.,2000000.),(0.,1000.,0.,0.,-1000.,0.),(-1000.,0.,0.,1000.,0.,0.)])
def test_signed_supplemental_and_floor_all_cases(N,V,M,minN,minV,minM):
 on=replace(BASE,N=N,V=V,M=M,minimum_action_policy='provided_envelope',minimum_N=minN,minimum_V=minV,minimum_M=minM,minimum_reference='Independent finite floor case')
 off=replace(on,include_inner_flange_plates=False,flange_bolt_gauge=170.)
 a=evaluate(on);b=evaluate(off)
 assert len(a['load_cases'])==len(b['load_cases'])==4
 for load in b['load_cases']:
  if 'floor' in load['case_id']:
   assert math.hypot(load['N_N'],load['V_N'])==pytest.approx(45000.)
   source=next(v for v in b['load_cases'] if v['case_id']==load['case_id'].split('_force_floor')[0])
   assert load['M_Nmm']==source['M_Nmm']
   for k in ('N_N','V_N'):assert load[k]*source[k]>=0
  assert load['top_outer_force_N']==load['top_force_N']
  assert load['bottom_outer_force_N']==load['bottom_force_N']
 assert other(a)==other(b)
 assert len(flange(b))==32*4
 assert sorted(i for e in b['mechanism_envelopes'] for i in e['member_check_ids'])==sorted(v['id'] for v in b['checks'])


def test_gauge_geometry_and_real_access():
 collision=replace(OFF,flange_inner_width=240.,inner_clear_band=200.)
 assert evaluate(collision)==evaluate(OFF)
 assert evaluate(replace(collision,include_inner_flange_plates=True))['status']!='LOCAL_CHECKS_PASS_WITHIN_SCOPE'
 a=evaluate(OFF);b=evaluate(replace(OFF,flange_bolt_gauge=160.))
 assert a['geometry']['flange_gauge_mm']==170. and b['geometry']['flange_gauge_mm']==160.
 assert a['geometry']['flange_outer_edge_mm']==35. and b['geometry']['flange_outer_edge_mm']==40.
 pa=next(v for v in a['checks'] if ':bolt_flange_' in v['id']);pb=next(v for v in b['checks'] if ':bolt_flange_' in v['id'])
 assert abs(pa['details']['transverse_mm'])==85. and abs(pb['details']['transverse_mm'])==80.
 for c in (replace(OFF,flange_bolt_gauge=60.),replace(OFF,tool_radius=80.)):
  r=evaluate(c);assert any(v['severity']=='access_pending' for v in r['issues'])
  assert r['status']!='LOCAL_CHECKS_PASS_WITHIN_SCOPE'
 assert a['geometry']['web_to_member_flange_clearance_mm']==(OFF.profile.d-2*OFF.profile.tf-OFF.web_height)/2


def test_grip_and_joint_thresholds_retain_real_stack_policy():
 for over in (0.,1e-6):
  c=replace(OFF,flange_t=5*OFF.db-OFF.profile.tf+over)
  r=evaluate(c)
  assert r['geometry']['flange_grip_mm']==5*OFF.db+over
  matching=[v for v in r['issues'] if v.get('code')=='BOLT_GRIP_OR_LONG_JOINT_REDUCTION_PENDING' and 'pega' in v['text']]
  assert bool(matching)==bool(over)
 for extreme in (950.,950.00001):
  pitch=((extreme-OFF.gap)/2-OFF.flange_member_end)/(OFF.flange_rows-1)
  r=evaluate(replace(OFF,flange_pitch=pitch))
  assert r['geometry']['flange_extreme_bolt_span_mm']==extreme
  matching=[v for v in r['issues'] if v.get('code')=='BOLT_GRIP_OR_LONG_JOINT_REDUCTION_PENDING' and '>950' in v['text']]
  assert bool(matching)==(extreme>950.)

@pytest.mark.parametrize('key,value',[('no_end_bearing_credit',1),('compression_K',True),('web_grid',[2.,3.])])
@pytest.mark.parametrize('mode',['legacy','on','off'])
def test_fixed_assumption_types_exact(key,value,mode):
 data=json.loads((Path(__file__).parent/'legacy_native_baseline.json').read_text())['native'] if mode=='legacy' else (BASE if mode=='on' else OFF).to_dict()
 data=deepcopy(data);data['fixed_assumptions'][key]=value
 with pytest.raises(ValueError):WConventional.from_dict(data)


def test_word_no_false_m004_preset_or_free_cover_equilibrium_label():
 from docx import Document
 from io import BytesIO
 for detailed in (False,True):
  payload=create_report(OFF,detailed=detailed)
  doc=Document(BytesIO(payload))
  text='\n'.join(p.text for p in doc.paragraphs)
  assert 'O afastamento de 10 mm do desenho M004' not in text
  assert 'Concentricidade: sim' not in text and 'Membros coaxiais: sim' in text
  assert 'Resíduo de equilíbrio global da tala (N·mm)' not in text
  assert 'Resíduo de equilíbrio global da tala de alma (N·mm)' in text
  assert 'Cada vetor do parafuso completo da alma se divide igualmente' in text
  assert 'Entrada ativa registrada' in text
  assert 'seis casas' not in text
