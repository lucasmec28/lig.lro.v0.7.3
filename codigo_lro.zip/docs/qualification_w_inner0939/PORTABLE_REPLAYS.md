# Independent W-option replay adapters

The two *_portable.py files preserve the review assertions and replace only original workspace/output paths. Run with the candidate source root on PYTHONPATH and an already-installed pytest/Streamlit environment:

    PYTHONPATH=. LRO_SOURCE=. LRO_REPLAY_OUT=/tmp/w_option_review python -m pytest docs/qualification_w_inner0939/test_independent_option_portable.py docs/qualification_w_inner0939/test_independent_ui_portable.py -q

The standalone patch acceptance remains the original review unit. The combined source reproduces all 11 held changed/new file hashes exactly; COMBINED_SOURCE_INTEGRATION.json binds that result. Full combined regression is a separate gate.

Both path-adapted files were replayed from APP-contained inputs on the combined 0.9.39 source: 80 passed. The compact legacy_native_baseline.json is shipped beside the tests; the old 23 MB worker snapshot is not required. w_portable_final.log/xml preserve this replay, separate from the production aggregate.
