# Independent review: optional conventional W-splice inner flange covers

Date: 2026-10-12. Reviewer did not edit candidate production source, deploy, or upload.

## Decision

The final held implementation passes this independent finite engineering, state, schema and artifact review. No open blocker remains. Final report-only clarifications passed targeted text/XML tests and regenerated Word page-6/page-8 pixel inspection. The package-wide release gate remains the implementation owner's responsibility; these finite tests do not certify unrelated connection families or a real structural project.

## Independent methods and outcomes

- Read the full implementation contract and Fraction-derived numerical witness file. Visually inspected the actual user screenshot: the blue arrow identifies an inner upper flange strip in the conventional N/M/V route.
- Compared complete result trees generated independently in separate baseline and candidate Python processes. For 27 N/M/V sign-grid cases plus four conventional presets, all existing primitive calculations, capacities, demands, signs, checks and statuses are unchanged with the option enabled. Differences are version/topology/binding/presentation metadata and the new explicit flange-bolt inventory. Existing web-bolt groups match exactly by stable ID.
- Three axial M004 preset result trees have zero differences. Independently generated three axial PNGs and three axial Word reports from each source: PNG bytes and every unzipped DOCX-part SHA256 match exactly.
- Final combined independent pytest run: 80 passed in 70.08 seconds (77 engine/schema/artifact cases and three actual Streamlit AppTest flows).
- Subsequent changes were confined to the conventional report file and were checked by a two-test artifact replay: 2 passed. A separate actual AppTest replay verifies the explicit legacy migration notice while preserving active inputs and the original legacy external binding: 1 passed.
- The only pytest warning is an independent harness use of itertools.product accepted by the current pytest but deprecated for pytest 10; it does not affect application behavior or test assertions.

## Physical and mechanics witnesses

- Physical covers change from eight to four, retaining F1/F4/W1/W2. Inner components, primitive checks, compression strips and physical regions are absent off.
- For nf=4, actual bolts remain 44; plane checks per case change 88 to 56. Flange planes change two to one; web groups and two web planes remain unchanged.
- Default outer-only N=-600000 N, M=120000000 N mm, V=100000 N: Ftop=-710116.1995898838 N; Fbottom=110116.1995898838 N. Maximum flange demand per sole plane is 88764.52494873547 N versus resistance 86917.3967493176 N, utilization 1.021251536153864. The result is VERIFIED_SUBCHECK_FAIL even when passed a forged balanced PASS artifact.
- Outer demands double without changing their capacities for an unchanged active geometry. Every web/member primitive remains exactly unchanged across the 27 sign-grid on/off pairs.
- Actual eccentricity e=(tf+t)/2=15.7 mm and actual top outer centroid 162 mm are recorded. Nominal allocation retains h0=d-tf=292.6 mm. The complete-W restraint idealization and its bounded conditions are explicit; unsupported assembly, missing grid/stations, noncoaxial members, torsion and nonstatic conditions cannot achieve a complete local pass.
- Signed actual, supplementary and separate 45 kN floor cases preserve action direction and independent M. Every primitive maps to exactly one presentation envelope.
- Grip is 47.4 to 31.4 mm at flanges, with web grip unchanged at 29.9 mm. Exact 5db and 950 mm boundaries preserve existing policy. Active gauge changes real bolt locations and edge geometry; tool/root restrictions remain active. Dormant inner collisions do not contaminate off calculations and return when enabled.

## Serialization, exact values and UI

- Version-2 payload contains active dimensions only: off excludes bi/c; on excludes the inactive explicit gauge. Inactive invalid strings, nulls, infinities and negatives have no effect on result, binding, digest or native payload.
- Strict mode booleans and positive finite active gauge are enforced. Current payloads require their exact active field set. Full known legacy native data are validated before migration, including typed assumptions; forged/missing assumptions, wrong family, extra profile fields and missing engineering fields are rejected.
- Exact native integer/float values and old bound hashes are preserved. Unchanged balanced legacy bindings remain valid through the explicit compatibility branch; action, mode or active gauge edits make them stale. No silent external rebinding occurs.
- Actual AppTest sequences cover high-precision import, repeated reruns, on/off/on, gauge edit, native reload, dormant draft mutation, report invalidation, explicit rebinding, strict malformed import atomicity, and legacy notice presentation. Initial off gauge is exactly the current accepted bi+c; returning on restores the earlier balanced payload exactly.
- Dormant edits preserve active result/native payload/report. Active topology/gauge edits invalidate the existing report and external basis.

## Artifacts and resolved review findings

Independent PNG inspection confirms correct on/off cross-section, elevation and plan; no F2/F3/F5/F6 artists/labels off; F4 retains its identity. Off drawing shows one flange/two web planes, e=15.70 mm, the correct FAIL and no clipping/overlap.

Inspected generated off Word concise pages 1, 3, 4, 5 and 6 and detailed pages 12 and 13. After the final report-only edits, independently inspected regenerated concise page 6 (explicit web-only two-plane statement) and page 8 (active input and displayed-precision header), and confirmed the final detailed PDF has the same corrected statements. Geometry, signed actions, force formulas, real offset, support scope and individual plane1 FAIL tables are clear and legible; 88,764.52 / 86,917.40 and displayed utilization 1.02 remain FAIL. Native precision is preserved despite two-decimal display.

Findings raised during review and fixed by the owner:
1. Off Word retained an unconditional M004 10 mm preset statement. It is now mode-aware and refers to the real member-flange clearance.
2. Off Word's generic 'Concentricidade: sim' could imply zero local offset. It now says 'Membros coaxiais: sim'.
3. Python dictionary equality admitted bool/int/float substitutions in supposedly exact fixed assumptions. Recursive type-aware validation now rejects these in both schema-1 and schema-2 imports.
4. A global-cover residual label actually described the web-cover equilibrium. It now identifies the 'tala de alma'.
5. The web two-plane explanatory sentence continued onto a separate Word page without explicitly saying web. The final report now says 'Cada vetor do parafuso completo da alma...'.
6. The owner also corrected inherited precision/input-table wording: the report states up to two displayed decimals, identifies active inputs only, and directs readers to native JSON for full precision. Final replay and page-8 pixels verify the correction.

## Evidence and source identity

- `final_independent.log`: 80-test combined held-source pass.
- `final_report_replay.log`: final report-only pass.
- `legacy_notice_ui.log`: explicit legacy-notice AppTest pass.
- `final_parity_summary.json`, `parity_diffs_final.json`: numerical parity evidence.
- `axial_artifacts_baseline.json`, `axial_artifacts_candidate.json`: matching axial image and DOCX-part hashes.
- `held_source_manifest.json`: all 459 Python files at the first hold.
- `source_changes_after_first_hold.json`: sole subsequent Python change, conventional report wording.
- `final_source_manifest.json`: renewed-hold source hashes.

Final conventional report SHA256: `7e9b6432579a7e36a2c8f730389000eec51acf59650c7f6d2c71bc4bf99a87f8`.
