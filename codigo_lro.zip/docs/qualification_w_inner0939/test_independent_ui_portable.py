import os
from copy import deepcopy
from dataclasses import replace
from pathlib import Path
import json
from streamlit.testing.v1 import AppTest
from lro.w_splice_conventional import WConventional,FAMILY,evaluate,capacity_binding,input_digest
from lro.w_splice_conventional_ui import BASE
APP=str(Path(os.environ.get('LRO_SOURCE',Path(__file__).resolve().parents[2])).resolve()/'app.py')
SOURCE=Path(os.environ.get('LRO_SOURCE',Path(__file__).resolve().parents[2])).resolve()
OUT=Path(os.environ.get('LRO_REPLAY_OUT','replay_w_inner_output')).resolve();OUT.mkdir(parents=True,exist_ok=True)

def launch():
 a=AppTest.from_file(APP,default_timeout=120);a.session_state['connection_family']=FAMILY;a.run();assert not a.exception;return a

def load(a,data):
 a.get('file_uploader')[0].upload('adversarial.json',json.dumps(data).encode(),'application/json').run()
 next(b for b in a.button if b.label=='Carregar W convencional').click().run()
 assert not a.exception

def native(a):return deepcopy(a.session_state['_w_conventional_project'])
def result(a):return a.session_state['_w_conventional_result']

def test_toggle_precision_binding_artifact_flow():
 c=replace(BASE,flange_inner_width=120.1234567890123,inner_clear_band=50.9876543210987,flange_outer_width=240.2469135780246,N=-123456.78901234,M=120000000.987654,member_Nc_Rd=2000000,member_Nt_Rd=3000000,member_M_Rd=500000000,member_V_Rd=1000000,member_capacity_reference='Independent supplied test')
 c=replace(c,member_capacity_binding=capacity_binding(c))
 a=launch();load(a,c.to_dict());before=native(a);before_digest=result(a)['input_digest']
 a.button(key='wc_generate_report').click().run();assert not a.exception
 assert 'wc_report' in a.session_state
 a.checkbox(key='wc_include_inner_flange_plates').uncheck().run();assert not a.exception
 off=native(a);off_data=off['connection']
 assert off_data['flange_bolt_gauge']==c.flange_inner_width+c.inner_clear_band
 assert 'flange_inner_width' not in off_data and 'inner_clear_band' not in off_data
 assert 'wc_report' not in a.session_state
 assert result(a)['member_external']['status']=='EXTERNAL_INPUT_STALE'
 assert result(a)['input_digest']!=before_digest
 keys={v.key for v in a.number_input}
 assert 'wc_flange_inner_width' not in keys and 'wc_inner_clear_band' not in keys
 assert 'wc_flange_bolt_gauge' in keys
 for _ in range(2):a.run();assert not a.exception;assert native(a)==off
 a.button(key='wc_generate_report').click().run();saved_report=a.session_state['wc_report'];saved_result=deepcopy(result(a))
 # Dormant controls do not change active inputs/result/export/report.
 a.session_state['wc_flange_inner_width']=c.flange_inner_width+13.2
 a.session_state['wc_inner_clear_band']=c.inner_clear_band+8.9
 a.run();assert not a.exception
 assert native(a)==off and result(a)==saved_result and a.session_state['wc_report']==saved_report
 a.number_input(key='wc_flange_bolt_gauge').set_value(168.1234567890123).run();assert not a.exception
 assert 'wc_report' not in a.session_state
 a.button(key='wc_bind_external').click().run();assert result(a)['member_external']['status']=='EXTERNAL_SUPPLIED_CHECKED'
 off=native(a);load(a,off);assert native(a)==off
 # Explicitly load the previous high-precision balanced native state, then on/off/on restores it exactly.
 load(a,before)
 a.checkbox(key='wc_include_inner_flange_plates').uncheck().run()
 a.number_input(key='wc_flange_bolt_gauge').set_value(169.2222222222).run()
 a.checkbox(key='wc_include_inner_flange_plates').check().run();assert not a.exception
 assert native(a)==before and result(a)['input_digest']==before_digest
 assert result(a)['member_external']['status']=='EXTERNAL_SUPPLIED_CHECKED'
 for _ in range(2):a.run();assert not a.exception;assert native(a)==before


def test_malformed_native_import_atomic_off():
 a=launch();a.checkbox(key='wc_include_inner_flange_plates').uncheck().run()
 a.button(key='wc_generate_report').click().run();before=native(a);report=a.session_state['wc_report']
 for path,value in [(['connection','include_inner_flange_plates'],0),(['connection','include_inner_flange_plates'],'false'),(['connection','flange_bolt_gauge'],None),(['connection','flange_bolt_gauge'],float('nan')),(['fixed_assumptions','flange_shear_planes_per_bolt'],2),(['connection','flange_inner_width'],100.)]:
  data=deepcopy(before);target=data
  for k in path[:-1]:target=target[k]
  target[path[-1]]=value;load(a,data)
  assert 'wc_import_error' in a.session_state and native(a)==before and a.session_state['wc_report']==report


def test_legacy_bound_import_toggle_and_return_exact():
 legacy=json.loads((Path(__file__).parent/'legacy_native_baseline.json').read_text())['native'];c=WConventional.from_dict(legacy)
 a=launch();load(a,legacy)
 assert 'wc_import_notice' in a.session_state
 notice=a.session_state['wc_import_notice']
 assert 'legado validado' in notice and 'esquema 2' in notice and 'oito talas' in notice
 assert any(v.value==notice for v in a.caption)
 assert native(a)==c.to_dict() and result(a)['member_external']['status']=='EXTERNAL_SUPPLIED_CHECKED'
 for _ in range(2):a.run();assert not a.exception;assert native(a)==c.to_dict()
 a.checkbox(key='wc_include_inner_flange_plates').uncheck().run();assert not a.exception
 assert native(a)['connection']['flange_bolt_gauge']==170.
 assert result(a)['member_external']['status']=='EXTERNAL_INPUT_STALE'
 a.checkbox(key='wc_include_inner_flange_plates').check().run();assert not a.exception
 assert native(a)==c.to_dict() and result(a)['member_external']['status']=='EXTERNAL_SUPPLIED_CHECKED'
