"""Finite direct comparisons across13 prior families and4ES; not pytest tests."""
from pathlib import Path
import subprocess,os,sys,json,hashlib
ROOT=Path(__file__).resolve().parents[2]
SCRIPT=r'''
import json,importlib
from dataclasses import replace,asdict,is_dataclass
from lro import engine,examples
out=[]
def save(label,r):
 out.append(dict(case=label,result=asdict(r) if is_dataclass(r) else r))
save('single_plate:first_preset',engine.evaluate(next(iter(examples.presets().values()))))
for module in ['double_cover','base_plate','pinned_base_plate','w_splice','w_splice_conventional','double_angle','welded_double_angle','coped_double_angle','axial_double_angle','axial_single_angle']:
 mod=importlib.import_module('lro.'+module)
 save(module+':first_preset',mod.evaluate(next(iter(mod.presets().values()))))
from lro.end_plate import presets,evaluate
for name,c in presets().items():save('end_plate:'+name,evaluate(c))
c=presets()['Engastada · 4ES com enrijecedores CJP']
for m in [-120e6,-40e6,40e6,120e6]:
 for n in [-10000.,10000.]:
  for v in [-40000.,40000.]:
   save('4ES:%g,%g,%g'%(n,m,v),evaluate(replace(c,N=n,M=m,V=v)))
print(json.dumps(out,sort_keys=True,allow_nan=True))
'''
def run(path):
 env=dict(os.environ,PYTHONPATH=str(path),PYTHONDONTWRITEBYTECODE='1')
 return json.loads(subprocess.check_output([sys.executable,'-c',SCRIPT],env=env,text=True))
a=run(ROOT/'review0922/source0922');b=run(ROOT/'review0923/source0923')
differences=[x['case'] for x,y in zip(a,b) if x!=y]
assert len(a)==len(b) and not differences,differences
baseline=ROOT/'review0922/source0922'
manifest=json.loads((ROOT/'review0922/SOURCE0922_FINAL_MANIFEST.json').read_text())
assert len(manifest)==571
bad=[q['path'] for q in manifest if hashlib.sha256((baseline/q['path']).read_bytes()).hexdigest()!=q['sha256']]
assert not bad,bad
result=dict(passed=True,comparisons=len(a),prior_families_covered=13,explicit_4es_signed_comparisons=16,
 comparison='Exact JSON equality of complete engine result per scenario; no tolerance/normalization; independent subprocesses.',
 case_ids=[x['case'] for x in a],baseline_files_verified=len(manifest),baseline_manifest_sha256=hashlib.sha256((ROOT/'review0922/SOURCE0922_FINAL_MANIFEST.json').read_bytes()).hexdigest())
Path(__file__).with_name('BASELINE_PARITY0923.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(result,indent=2,ensure_ascii=False))
