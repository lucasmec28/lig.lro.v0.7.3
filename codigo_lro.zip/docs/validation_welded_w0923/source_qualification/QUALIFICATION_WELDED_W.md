# Welded W splice for beams or columns: bounded source qualification

Date: 2026-10-11. Status: **GO for the bounded, published elastic CJP weld-group method and explicit local receiver checks.** Real-project acceptance remains conditional on valid detail, material, procedure and demand inputs. This supersedes the initial inference that a separate access-hole shear-redistribution/FEM model was mandatory.

This is a read-only future-scope study. No application code, baseline, existing bolted splice, or active end-plate work was modified. It is not a fabrication design or an approval of any real splice.

## 1. Recommendation and resolved method

Choose a distinct family consisting of **two identical, aligned rolled W profiles with CJP butt welds in both flanges and the web**, with real weld-access openings and a documented welding procedure. It can serve a beam, column, or beam-column under signed axial force, major-axis bending and web-plane shear. There is no engineering reason to restrict the family to columns or to remove either sign of axial force.

The supplied sources now close the following issues:

- Current NBR CJP effective lengths, throats, compatible consumables and base-metal-governed resistance.
- A source-supported additional combined-stress criterion, including its square root: Fakury Eq. (10.27), not a new interaction invented for this module.
- Current NBR access-opening dimensions, construction provisions and heavy-section requirements.
- The need for actual N/M/V equilibrium, compatible deformation and checking the connected material.

The practical calculation route is Fakury's **published elastic CJP weld-group method**, not a new full-continuum shear solution and not the old bolted splice allocation. It uses the actual remaining weld group, with the same-point base-metal checks, plus the actual reduced receiving sections. The receiving web must separately resist the full web-plane V; the fraction of V assigned to its weld by the weld-group method is not permission to reduce the member-web demand.

No inspected NBR clause or supplied example explicitly requires a bespoke access-hole shear-redistribution/FEM proof for every standard compliant CJP detail. That proposed blocker was an engineering inference and is withdrawn. Conversely, do not describe the published F/A weld-group field as the exact continuum shear distribution in the W. Use its proper source and scope. Standard compliant access geometry, minimum remaining sections, local resistance and applicable stability/detail requirements remain necessary.

## 2. What Gerdau actually supports

Source: supplied *Manual Gerdau Ligações para Estruturas de Aço*, SHA256 d3dda5581c3db88c561e72e5c1c2c30d9fdb6332735baa3df7da5738df020dc5. Printed and PDF pages coincide.

- **p.189, §§9.1–9.1.2:** EP1 joins profiles with the same clear distance h between inside flange faces; EP2 addresses different h. Neither description means necessarily identical cross-sections. The upper-piece positioning angle is auxiliary. Welds subject to design forces are specified as CJP. Both EP types require lower-piece flange width and thickness at least those of the upper piece; EP2 limits nominal-depth difference to 50 mm.
- **p.190, §9.2:** the examples select EP1 for W310×117/HP310×79 and EP2 for W410×75/W360×32.9. They do not calculate N/M/V resistance, a stress interaction, or a local receiving-section resistance.
- **pp.191–193, §9.3 EP1:** the drawings contain the positioning angle, bolts, plate and subsidiary weld details; p.191 specifies a 12.5-mm A36 plate, E70XX, 4 three-quarter-inch A325N bolts, and an L102×102×9.5 angle. The note expressly says the angle only positions the piece and does not guarantee erection stability. Those components cannot be assigned unverified structural resistance in a new simplified family.
- **p.194 onward, EP2:** the transition plate is a different load path. Do not silently import EP2, its thick plates, or its resistance assumptions into an aligned identical-W butt splice.

The EP1 drawings are valuable precedent for welded column splices, but not a complete dimensioned access-hole/WPS or N/M/V calculation for the proposed new family. The manual uses NBR 8800:2008; current NBR controls the calculation. No current CJP capacity is taken from its old tables.

## 3. Current NBR route, verified on page pixels

Source: supplied NBR 8800:2024 PDF including Errata 1:2025, SHA256 2289dd360ae938982f44ce6b0633968652199604867172e9d0d454e71256b16d. Main printed pages are PDF page minus 22. The official ABNT catalogue currently lists **ABNT NBR 8800:2024 Versão Corrigida:2025**: https://www.abntcatalogo.com.br/ . The supplied errata cover and relevant correction were inspected, rather than assuming OCR is the corrected text.

### Demand, equilibrium and scope

- **§6.1.1.1, printed p.68 / PDF90:** Section 6 is for static metal connections; fatigue has a separate route.
- **§6.1.1.2–.3, p.69 / PDF91:** each component must resist its demand; adopted forces must equilibrate the applied actions; deformation capacity and stiffness compatibility matter. Equilibrium alone is necessary but insufficient.
- **§6.1.4, p.70 / PDF92:** combined effects must be considered where rigid/semi-rigid action applies. It is not permission to invent a combined-capacity equation.
- **§6.1.5, p.70 / PDF92:** retain applicable integrity actions and the 45-kN connection-force minimum. The recommendation based on a proportion of member resistance is discretionary and must not become a hidden mandatory member-design task. Do not invent an independent minimum moment. Keep actual and supplemental cases separate.
- **§6.1.6, p.70 / PDF92:** contact-bearing rules apply when that load-transfer mechanism is actually used. The proposed common CJP family transmits the signed actions through the welded joint, without taking end-bearing credit or assuming N<0 makes tension/shear weld design unnecessary.

### CJP weld resistance

- **§6.2.1.1–.2, p.73 / PDF95:** AWS D1.1 governs welding subject to the explicit NBR replacements; specify welds on drawings and applicable lengths/returns on fabrication/erection drawings.
- **§6.2.2.1(a–c), p.73 / PDF95:** effective area is effective length times throat; the effective length is actual length and equals the width of the connected part; CJP throat is the thinner joined thickness. A profile's catalogue gross area is not automatically the effective weld area, especially with access openings.
- **§6.2.4 and §6.2.5.1, p.76 / PDF98:** identify the base material and process/consumable; Table 8 defines compatibility, with AWS qualification references. A_MB is length times the thinner base thickness; f_y is the smaller base-metal yield strength.
- **Table 8, p.77 / PDF99:** A572 Gr.50 and A992 lie in the group that permits, among other specified SMAW consumables, E7018. “E70XX” by strength number alone is not an exhaustive compatibility/process specification.
- **Table 9, p.78 / PDF100:** CJP normal tension and normal compression are base-metal checks A_MB f_y/γa1; CJP shear uses 0.6 A_MB f_y/γa1. Matching compatibility is required for tension and shear, with the table's specific exceptions. Do not reuse the fillet formula 0.6 A_w f_w/γw2 as the governing CJP formula. Do not claim that the row for stress parallel to the weld axis exempts transverse butt-splice demand.
- **Table 9 footnote d:** nonuniform stress is checked using unit effective lengths. Integrating a tensile and compressive region to a small net resultant must not hide their peaks.
- **§6.2.6.1, p.80 / PDF102:** PJP welds cannot be used in splices of bent members. Full CJP is consequently the clean common family for general beam/column N/M/V; there is no need to pursue PJP variants in this pass.

### Access, receiving material and fabrication

- **§6.1.13, p.72 / PDF94:** openings must accommodate backing when used; length >1.5t_w and not less than 40 mm; height >t_w and not less than 20 mm; rounded/transition geometry and radius at least 10 mm are specified.
- **§12.2.1.2.2–.7 and Fig.25, pp.119–120 / PDF141–142:** no notches; thermal-cut quality/finish requirements; Fig.25 alternatives 1 and 2 suit rolled profiles or profiles assembled before making the opening. Alternative 3 belongs to built-up profiles assembled after the opening and cannot be casually assigned to rolled W. The figure's height need not exceed 50 mm. The figure uses maximum expressions; choosing 45-mm length, 25-mm height and R=12.5 mm for the proposed numerical W example avoids treating the prose's strict “greater than” as equality. Those example values do not define every transition or prove tool access.
- **§6.1.12, p.72 / PDF94; §6.2.4.2, p.76 / PDF98; §12.2.1.5, p.121 / PDF143:** tension in heavy CJP-spliced profiles activates material/weld toughness and preparation requirements. Current trigger is the stated 50-mm thickness, not Fakury's older 44-mm rolled-flange threshold. Do not copy the book's old temperature rule as a current universal WPS.
- **§6.5.1/.3/.4, pp.94–95 / PDF116–117, with Errata PDF1:** connected regions affected locally are within connection design. Account for applicable net tension rupture, compression and actual ligaments; corrected §6.5.4(b) says L_e/r>25. Review applicability to the real local element; this does not prescribe fictitious independent flange/web columns or a new full-member stability calculation for every ordinary access opening.
- **§6.5.5–.6, p.95 / PDF117:** check applicable local shear yielding/rupture and actual tear-out paths. Do not manufacture bolt-style block-shear paths where the welded detail has none, but do not claim openings have no local effect.
- **§5.5.2.3, p.63 / PDF85:** elasticity-based normal/shear checks do not erase applicable instability. Do not misuse this general member framework to demand a bespoke stress/stability model for every standard welded detail when the published connection method applies.
- **§12.2.1.7.5, pp.121–122 / PDF143–144:** real permitted depth variations at butt splices must be accommodated in the weld profile while retaining required minimum section and AWS slope provisions. “Same nominal W” is not a licence to ignore mismatch.

## 4. Sourced combined-stress method

Fakury, Castro e Silva and Caldas, supplied part 4, Library libfile_ad58e3ddd5588191a9275402cfd63667, **printed pp.275–277 / PDF22–24, §§10.10.2–10.10.3.1**. Pixels inspected. This is a 2008-NBR-era explanatory source, used for mechanics and the explicit supplementary interaction; current NBR material/detail rules take precedence.

For centroidal principal axes of a weld group, Eq. (10.19) gives the elastic normal field:

σ = F_z/A_ew + M_x y/I_x − M_y x/I_y.

Equations (10.20–.22) define the in-plane shear components/resultant for that weld-group idealization. With web-plane V and no torsion, the direct shear demand is **τ = |V|/A_ew**. Fakury p.277 explicitly equates the CJP base-metal demands to those weld-group equations. This is therefore a supplied calculation method, not an invented distribution. Apply it only to the actual weld effective patches. Separately check the full receiving-web V on the actual remaining web area; never claim the ordinary W web is relieved because this weld-group model distributes part of V to the flange welds.

For matching CJP, Eqs. (10.23–.26) reduce the normal/shear checks to base-metal yielding on the effective connected area:

|σ| ≤ f_y/γa1; |τ| ≤ 0.60 f_y/γa1.

Where normal and shear stress coexist **at the same point**, Eq. (10.27) adds:

sqrt(σ² + 3τ²) ≤ f_y/γa1.

Use coincident values from this published field, not the largest normal stress from one location and a favourable shear from another. Here the direct shear is constant, so the largest absolute normal stress also locates the largest equivalent stress. For more general approved groups use the actual extrema of the relevant expressions. Do not substitute a guessed sum of N/N_Rd, M/M_Rd and V/V_Rd, or call Eq. (10.27) an equation printed in current NBR Table 9.

The method has a finite oracle for the symmetric W case: compute the area and second moments of the actual remaining flange/web patches; evaluate normal stresses at each patch's y extrema; calculate the constant group shear; check normal, shear and same-point equivalent stresses. Retain intrinsic flange inertia, not just concentrated flange forces. Integrating the field must recover N and M exactly, and τ A_ew recovers V.

Duane K. Miller, **AISC DG21 (2006), printed p.34/PDF45, §3.3.3; pp.45–46/PDF56–57, §3.9.2; p.50/PDF61, §3.12.1**, supplies consistent explanatory background: proper matching CJP develops connected-material strength, but access holes also prevent intersecting shrinkage fields. Its Fig.3-25 specifically depicts the problem with a beam splice without access holes. Neither “matching” nor omission of a weld-metal rupture calculation approves an unexamined base-metal receiver. Do not import the old AISC resistance factors.

## 5. Practical initial input/detail contract

These are useful first-family defaults, not arbitrary permanent restrictions on future welded splices:

1. Identical rolled W designations, same orientation, centroids and flange/web planes aligned; record measured/detail mismatch, not just profile name.
2. Signed N (positive tension), signed major-axis M and signed web-plane V at a named splice cut; supply complete design load cases and any independent minimum/integrity envelope. Beam/column selection does not silently change these forces.
3. Both flanges and the remaining web joined by CJP; no credit for end bearing, backing steel, run-off tabs, angle or temporary bolts. If a component is made structurally participating, that is a new explicitly checked path.
4. Practical material preset: ASTM A572 Gr.50 on both sides and a compatible low-hydrogen E7018 SMAW procedure; f_y=345 MPa, f_u=450 MPa, γa1=1.10 for normal ultimate combinations. Process, exact consumable and WPS remain explicit. An approved alternative process is not excluded by this choice.
5. Both-side access with backgouging where the chosen qualified procedure requires it is a useful shop default. A single-sided/backed field detail needs its own qualified preparation. Do not choose an arbitrary root gap/angle or label a sketch “AWS prequalified” without the exact applicable detail.
6. Access openings described by actual cut curves on BOTH members: length, height, transition slope/curve, radius, position, real root radius/k region, remaining weld lengths and local receiving sections. Defaults for a moderate W may start at 45×25 mm with R=12.5 mm, then verify the complete geometry and WPS access.
7. Static ultimate actions, including sign reversals across different cases. Torsion, weak-axis bending, biaxial shear, fatigue, impact and seismic qualification are additional models, not silently zeroed values. Heavy sections use the extra requirements rather than a fabricated universal thickness ban.

The application currently stores W d, b_f, t_w, t_f, clear height and area, but not a generally authoritative full inertia/root-curve model. Do not fabricate I from catalogue area and mix it with rectangle-only weld properties. New weld/receiver geometry must have a self-consistent area, centroid and inertias.

## 6. What changes between beams and columns

- The local stress/resistance kernel and sign convention can be the same. Horizontal/vertical placement changes drawing labels and fabrication access, not the resistance equations.
- A beam may carry nonzero axial force; a column may carry substantial moment and shear. Never infer a reduced load vector from the label.
- Column staging, temporary supports and positioning/erection are important, but Gerdau's angle is explicitly not an erection-stability system. A beam splice also needs supported construction stages.
- A bearing-type compression splice would invoke the separate §6.1.6 mechanism; this family does not use that shortcut.
- Global member buckling, lateral-torsional buckling, member length/restraints, second-order frame analysis and service-system verification remain with the structural member/system design. They need not be recomputed by a local splice tool. The local receiver checks below remain in scope. A nonstandard long slot, unusual cope, locally slender connection element or a changed load path cannot be excused as “global,” but do not manufacture such elements for the ordinary standard opening.

## 7. Acceptance contract and finite oracle

An overall “adequate” result needs **all** gates below. A passing component is never promoted across a pending gate.

**G1, geometry/fabrication:** actual positive-area weld/receiver geometry, CJP along actual connected widths, openings meeting current provisions, documented compatible material/consumable/process and qualified detail. No inaccessible root hidden by a simplified drawing.

**G2, published demand model:** use Fakury Eqs.10.18/19 and 10.20–22 on the actual CJP group. For the symmetric N/M/V family use σ=N/A_ew+My/I_x and τ=|V|/A_ew, with the declared axes/sign convention. Exclude access openings, absent fillet/root material, backing, run-off and temporary parts. Do not substitute the bolted family or an intact catalogue area. No extra FEM gate is imposed.

**G3, equilibrium:** integrate the normal and shear tractions over the actual cut to recover signed N, M and V. Verify zero spurious minor-axis moment/torsion for the symmetric candidate. At other local cuts, use the correct moment change caused by V and cut offset. Both members are serial paths; their capacities cannot be added. Numerical tolerances must be scaled and documented.

**G4, resistance/receiver:** pointwise/unit-length Table9 normal and shear checks and Fakury Eq.10.27 where applicable. Both connected sides must have adequate actual remaining/net material, including a deeper access-hole bulb if it governs outside the weld plane. For the receiving web check **full |V| ≤ min(0.60f_y A_gv/γa1, 0.60f_u A_nv/γa2)** under §6.5.5, and applicable §5.4.3 web stability/member-shear conditions. Do not use 0.193V just because that is the numerical fixture's web-weld group share. For tension use §6.5.3 on actual A_e/A_n; no bolted-splice 0.85A_g cap is imported. With matching A572 Gr.50 and A_e=A_n=A_remaining, f_y/1.10=313.636 MPa < f_u/1.35=333.333 MPa, so yielding on that same area also bounds tensile rupture; the proportional shear strengths have the same dominance. Report the dominance instead of a redundant invented check. Review §6.5.4 applicability to any real compressed connection element; standard access geometry alone is not an automatic requirement for independent-column strips or FEM. No added component, unusual recut, mismatch or unsupported force may silently inherit this standard-detail approval.

**G5, cases and serialization:** preserve signs and all design cases; incompatible W, material, procedure, omitted hole or unsupported action cannot fall through to an old bolted family. Missing geometry/detail/material evidence remains NOT_VERIFIED, even at low loads. Name the published elastic-group model in outputs.

The accompanying `numerical_controls.json` provides material/unit-strip controls, a passing local N/M/V elastic-group calculation and receiving-web check, exact N/M/V equilibrium, sign reversals and a failing interaction case. The arithmetic fixture describes idealized design dimensions and a bounded standard-opening envelope; it is not a certified fabricated splice or a completed WPS. For a real project, require the exact opening curves/critical sections and welding detail before promoting numerical component results to an accepted design.

Numerical control: W310×97 dimensions d=308, b_f=305, t_f=15.4, t_w=9.9 mm; top/bottom web opening heights 25 mm; remaining web length 227.2 mm. A_ew=11,643.28 mm², I_x=210,927,543.422933 mm⁴. For N=−600 kN, M=+120 kN·m and V=+100 kN, σ_outer=−139.144895/+36.081154 MPa, τ_group=8.588645 MPa and max σ_eq=139.937830 MPa. Governing group ratio is **0.446178589**. The receiving web uses the full 100 kN against its own area 2,249.28 mm², not the 19.318 kN weld-group share. See JSON for capacities and exact force integration.

## 8. Reuse from review0921/source0921 without carrying the wrong model

Read-only baseline observations:

- `lro/models.py`: reuse canonical N/mm/MPa units, finite-number validation, profile/material identities and product/thickness restrictions after verification.
- `lro/w_splice_conventional.py`: signed case handling, distinct serialized family, explicit external/global scope and minimum-action provenance are useful patterns. Its all-N/M-in-flanges and bolted-web allocation are a different mechanical model and must not become CJP defaults.
- `lro/w_splice_equilibrium.py`: useful illustration that signs and integrated residuals are testable; its bolt-group geometry, partition and covers are not the CJP method.
- Existing M004 remains axial bolted; conventional N/M/V remains bolted. Use a new family identifier if future implementation is authorized. Do not migrate stored projects silently.

## 9. Next finite decision and correction of the initial inference

**GO to a distinct future implementation of this source-labeled elastic CJP family**, after the active priority, with the finite contract above. The standard-detail geometry, actual weld/net sections, WPS and applicable receiver checks are implementation inputs/gates, not a reason for indefinite literature research. The initially proposed requirement for a bespoke local access-hole elasticity/FEM model is withdrawn: it was not expressly required by the inspected NBR provisions and overlooked Fakury's explicit application of its group equations to CJP base metal. No blanket claim about exact continuum shear, automatic whole-member adequacy, or special nonstandard openings is made.
