# Independent welded-W source qualification

Date: 2026-10-11. Scope: source qualification only; no application or baseline changes.

## Decision

**GO for implementation of a bounded same-profile, aligned, static CJP splice**, with per-case adequacy dependent on the ordinary weld, receiving-material and detailing checks below. This accepts a calculation scope, not any fabricated splice or an unchecked overall-adequacy verdict.

The proposed requirement for a newly developed access-hole shear-redistribution or finite-element model is **inferred, not an explicit requirement found in the inspected sources**. It must not be presented as a normative blocker. A documented, applicable published connection model is an appropriate finite basis; the supplied Fakury model is such a source for the nominal CJP weld-group checks.

**The computed stresses are nominal elastic weld-group stresses, not verified physical peak stresses around the access holes.** Neither equilibrium alone nor the absence of a prescribed finite-element check proves every receiving-material limit state.

## Exact source findings

All following references were inspected on actual supplied page images in `../source/`; the additional DG21 PDF-page-57 image is retained here as `dg21-057.png`.

1. **Fakury, Castro e Silva and Caldas, printed pp.275–277, §§10.10.2–10.10.3.1, part-4 PDF pp.22–24** (`fakury4-022.png` through `fakury4-024.png`): Eq.10.19 supplies the elastic normal weld-group field; Eqs.10.20–10.22 supply direct in-plane shear plus torsion and its resultant. Page 277 expressly relates CJP base-metal stresses to those group equations. Eqs.10.23–10.26 require normal and shear resistance checks; Eq.10.27 adds the coincident interaction `sqrt(sigma^2 + 3*tau^2) <= fy/gamma_a1`. These pages do not prescribe a separate local access-hole finite-element calculation. Use the full source method, with its declared idealization, rather than claiming that uniform group shear is the physical W-section shear distribution.

2. **ABNT NBR 8800:2024, corrected by the supplied 2025 errata, §6.1.1.1–.3, printed pp.68–69 / PDF pp.90–91** (`nbr-090.png`, `nbr-091.png`): static connection scope; component resistance, equilibrium, deformation capacity and stiffness compatibility. These general conditions do not specifically require finite-element analysis or a newly invented shear-flow method.

3. **NBR §6.2.2.1, printed p.73 / PDF p.95** (`nbr-095.png`): real effective weld lengths and the thinner joined thickness define CJP effective area. **§6.2.4, §6.2.5.1 and Tables 8–9, printed pp.76–78 / PDF pp.98–100** (`nbr-098.png` through `nbr-100.png`): material/process compatibility and base-metal-governed CJP normal and shear resistance. Table 9 footnote d addresses nonuniform stresses by unit effective lengths. Do not use a fillet-weld resistance equation as the CJP governing equation.

4. **NBR §6.1.13, printed p.72 / PDF p.94** (`nbr-094.png`), and **§12.2.1.2.2–.7 / Fig.25, printed pp.119–120 / PDF pp.141–142** (`nbr-141.png`, `nbr-142.png`): access-hole dimensions, transitions, radii, applicable geometric alternatives and workmanship. These are real mandatory detail requirements; they do not add a specific local redistribution/FEM check. In particular, Fig.25 alternative 3 is not the generic alternative for an existing rolled W.

5. **NBR §6.5.1/.3/.4, printed pp.94–95 / PDF pp.116–117** (`nbr-116.png`, `nbr-117.png`; `nbr-001.png` verifies the erratum changing §6.5.4(b) to `Le/r > 25`), and **§6.5.5/.6, p.95 / PDF p.117**: locally affected receiving parts remain in connection scope. Check applicable tension yield/rupture, shear yield/rupture and compression/local stability on real remaining/net sections. Do not carry the bolted-splice `0.85 Ag` provision into a welded splice, fabricate bolt-style block-shear paths, or create independent compression-column strips without a justified physical model. **§5.4.3 and §5.5.1.3** retain receiving-member web-plane shear capacity; a weld-group `V/Aew` does not replace that check.

6. **Gerdau, Manual Ligações para Estruturas de Aço, printed/PDF pp.189–190, §§9.1–9.2** (`gerdau-189.png`, `gerdau-190.png`): practical welded-column-splice precedent with force-carrying CJP welds, not a worked direct-butt N/M/V method. **EP1 pp.191–193** includes a plate and positioning components. Its resistance cannot be silently transferred to a different direct-butt detail. No inspected source establishes a flange-only `N/2 +/- M/d` allocation as the method for this CJP family.

7. **AISC DG21 (2006), §3.9.2 printed pp.45–46 / PDF pp.56–57, and §3.12.1 printed p.50 / PDF p.61**: matching CJP develops connected-material strength; access holes also separate intersecting shrinkage fields. This is explanatory background, not a source for current Brazilian resistance factors or a new local redistribution requirement.

## Finite implementation acceptance contract

- Same rolled W profile, orientation and aligned flange/web planes and centroids; record and accommodate real mismatch. Signed design N, major-axis M and web-plane V; static actions. Unsupported actions or other details must be explicit rather than silently discarded.
- Both flanges and the actual remaining web use full CJP. Compute a self-consistent effective area, centroid and inertias from real connected patches, excluding access openings. No structural credit for backing, erection angles, temporary bolts or run-off tabs.
- Apply the complete Fakury nominal elastic-group method and current NBR CJP resistance. Retain separate normal/shear checks plus the supplementary coincident interaction. Do not relabel the book's interaction as an equation printed in current NBR Table 9.
- Verify the ordinary receiving-material checks on **both** members. Include the reduced receiving-web area in the web-plane shear check, even if the nominal weld-group model assigns part of V to the flange welds. Account for any smaller section at the access-hole bulb away from the splice plane and the associated section actions; a splice-plane check is not automatically that check.
- Check tension/net rupture and shear/net rupture where applicable. Where identical remaining/effective areas and material resistances make a check provably subordinate, report that dominance rather than require duplicate calculations. The numerical material preset uses `fy=345`, `fu=450`, `gamma_a1=1.10`, `gamma_a2=1.35`: yield stress 313.636 MPa is below rupture stress 333.333 MPa when the same area applies. That comparison does not waive a smaller effective/net area elsewhere.
- Determine applicability of compression/local stability using actual geometry. No new universal FEM gate; no unsupported blanket statement that all local stability is absent. Full-member buckling, lateral-torsional buckling and frame analysis remain the member/system designer's scope.
- Satisfy current access-hole geometry, workmanship, material/consumable compatibility, qualified welding procedure, inspection and applicable heavy-section requirements. The nominal strength calculation is not fabrication approval.

## Independent numerical controls

Run `python next_welded_w_scope/independent_review/run_fixture.py` from the workspace root. It creates `fixture_results.json` beside itself.

The runner independently derives exact rectangular-patch area/inertias using rational arithmetic and verifies resultant recovery by two-point Gaussian integration. It covers the W310x97 nominal-group case, full-reversal symmetry, coincident interaction, and an intentionally excessive pure-shear case that passes the nominal group check but fails the separate reduced-web check. Fakury Eq.10.27 is applied as the additional source requirement where normal and shear coexist. For a pure-shear case the source-governing group ratio uses `0.60 fy/gamma_a1`; the separately reported von Mises value is only an additional conservative screen, not a replacement pure-shear limit. It does **not** use application code and does **not** claim a complete access-region, local-instability, WPS or real-splice approval.

The source worker agreed that the original special redistribution/FEM gate was inferred and is replacing it with this finite source contract. The independent application-engine check remains a later task after implementation is ready.

## Agreed finite geometry/load contract for the first implementation

The implementation owner proposed the following standard-access envelope on 2026-10-11. Its acceptance is an engineering-model qualification, not a claim that every listed formula or shape restriction is an NBR-prescribed detail.

- Top and bottom cuts are mirror symmetric within each member. The two members may have different opening lengths `L` and maximum depths `Hmax`; their common splice-plane opening depth is `H0`, measured inward from the flange inner face. `Hmax >= H0` includes the deepest bulb and all root-region/transition removal. Do not omit additional removal required by actual fabrication.
- The nominal weld plane consists of two `bf*tf` rectangles and a `tw*(d-2tf-2H0)` web rectangle. The minimum receiver envelope on each side substitutes that side's `Hmax`. No root-fillet area credit is taken. Both sides are serial paths.
- At every local section, the declared envelope establishes `A(x) >= Amin` and `I(x) >= Imin`. For no additional external load applied within the local access region, `|M(x)| <= |M0|+|V|L`. Therefore `|N|/Amin + (|M0|+|V|L)*ymax/Imin` bounds the absolute **nominal elastic-section normal stress**: use `ymax=d/2` for the flange and `ymax=d/2-tf` for the web. This does not bound physical stress concentrations.
- Keep the nominal reduced-group receiver control (`tau_group=|V|/Amin`) and a separate receiving-web control (`tau_web=|V|/Aw_min`). For the latter, use the web normal-stress envelope and the additional coincident interaction where both occur. This is a conservative combined control within the declared nominal receiver model. `V/Aw_min` is not represented as a physical maximum shear stress. Do not merge these two checks into one purported equilibrated traction field; the actual nominal weld-group equilibrium remains separately verified.
- An explicit tangent-line/circular-bulb construction is sufficient for the first branch; arbitrary CAD curves are unnecessary. A reproducible choice has circle centre `(L-R, Hmax-R)`, tangents from upper mouth `(0,0)` and lower mouth `(0,H0)`, and the right circular arc joining the proper upper/lower tangent points. Validate real tangencies, positive upper-transition slope, noncrossing boundaries, tangent locations within `0<x<=L`, and the whole removed region inside `0<=x<=L`, `0<=depth<=Hmax`. For this particular construction, require `L>=2R` and `Hmax>2R`; these are branch geometry guards, not new universal NBR restrictions. Existing NBR dimensional/radius/detail requirements also apply.
- The example `H0=Hmax=25`, `L=45`, `R=10` gives circle centre `(35,15)`, a positive upper tangent and a horizontal lower tangent at depth 25. In contrast, `R=12.5` with `Hmax=25` produces a horizontal upper tangent and is outside this chosen inclined-upper-transition branch. Root/k-region clearance, the complete material removed across the real rolled root and qualified welding access remain explicit detail applicability requirements. This illustration is not a fabrication-certified WPS.
- The owner will reuse the application's stated supplemental minimum-force convention: `Rforce=hypot(N,V)`; for `0<Rforce<45 kN`, scale the signed force pair by `45 kN/Rforce` and retain the original moment. Actual and supplemental cases remain separate; `Rforce=0` creates no fictional force direction. No invented minimum moment or unconditional four-direction code requirement is introduced. Applicable integrity actions remain an explicit designer declaration; no unrequested member-capacity calculation is invented.

This contract removes the need for an arbitrary local-curve mesh or new finite-element proof. The later independent engine review must verify that the implemented construction, bounds and output labels actually satisfy it.

### Final member-versus-connection boundary

The parent confirmed the finite boundary on 2026-10-11: published nominal CJP/receiver checks, real reduced sections and the prescribed standard access detail are the local-splice method. Intact-member flexural, local and global buckling remain member-design verifications; this module does not add a pure-moment member-classification workflow. Arbitrary custom long slots are outside the first detail route, not prohibited by NBR in all circumstances.

If retained, the Table 4 non-slender criterion applies as a deliberately restricted first **axial-compression** branch for cases with `N<0`. It is an implementation-domain condition, never a universal structural failure of the splice, flexural-compactness proof or analysis of every possible cutout. Source pixels were independently confirmed: NBR §5.1.2.2.3(a)/.4(a), printed p.38/PDF60 (`nbr-060.png`), defines rolled-web flat width as the clear distance minus the two root radii and I/H/T flange width as half the full flange width; §5.3.4.1, printed p.46/PDF68 (`nbr-068.png`), establishes `Aef=Ag` when all elements satisfy Table 4; printed p.47/PDF69 (`nbr-069.png`) supplies `0.56 sqrt(E/fy)` for Group 4 rolled flanges and `1.49 sqrt(E/fy)` for Group 2 webs. These are not compact-bending limits.

The owner's selected short-opening limit `L <= max(45 mm, 1.5 tw + 5 mm, 2R + 5 mm)` and initial `Hmax <= 50 mm`, if retained, must be labeled initial implementation choices, not universal normative maxima. No new source or theoretical proof is pending before the independent engine review.
