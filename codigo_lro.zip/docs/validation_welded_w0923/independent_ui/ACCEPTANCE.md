# Independent welded W UI and export acceptance

ACCEPTED for the finite qualified 0.9.23 local CJP scope. Final actual outer-loader smoke remains pending the parent package; this report does not claim deployment or fabrication approval.

## Final source identity

SOURCE_MANIFEST.json records exact before/after SHA-256 values and stable=true for the final-source three-workflow run. Final production files:

- app.py: d607952ef065d0c26ccd62d58ae8c610ab8ad31bbaaf43ceb8cee74d19f49110
- lro/models.py: fc647aaec743d160cb848e678b9be5f195bc437e51e72a07631480aa831c769e
- lro/guided_selection.py: 3ffa5594d2078db16716982242bab80cf6ee8dfa0a5973f1fe013670dc667388
- lro/welded_w_splice.py: 55ee95f5ab5a937eb2361764cf1313c9c4d73923eba5dd9e8ae595b77cfecce9
- lro/welded_w_splice_ui.py: 10fa2b8b7d90705f3c9d8d08d14a540d049999f034a5a7dc751cfc8f1cf0413d
- lro/welded_w_splice_drawing.py: 053e9495c60ae4da2e51dbe30f0006669719c3499ec56d94740018931211fa81
- lro/welded_w_splice_presentation.py: 0454244532b4249a2d8dc3feb13716ed497a05d491c0163294f8e9f08255ecc3
- lro/welded_w_splice_report.py: cb57440a16a3d49891149c5237abea4b91d3833e3582df014baaea34f4507dad

Only reviewer tests and receipts were written by this reviewer. No implementation edit, upload, release packaging or deployment was performed.

## Executed workflow evidence and one harness correction

1. The first actual Streamlit AppTest workflow opened every one of the 14 families through the real guide filters and explicit open button. Selecting filters never changed the current family before open. It passed; pytest_partial_harness.log retains that completed node. The app, guide, UI and kernel hashes above were unchanged through this and subsequent runs.
2. In that run, all 27 real native-upload rejection iterations completed their assertions before capture: 20 missing required CJP/detail/procedure/declaration fields, four malformed force values, incomplete load-case V, unknown T, and duplicate JSON N. Accepted project, widget draft, accepted-value storage, current Word and exported JSON remained unchanged. The reviewer capture then incorrectly asserted that the registered display PNG bytes equal the downloadable PNG. Streamlit normally resizes the former to 1460 pixels wide. This reviewer-only assertion was interrupted, not counted as a fully passing test, and corrected without editing the application.
3. Only the remaining three original workflows ran on the final frozen production hashes: signed/minimum/zero/fail/outside/orientation exports, legacy-family state isolation, and public export reevaluation. All three passed in 86.47 seconds; pytest.log and junit.xml. The completed 14-route pass was not repeated.
4. One focused recovery workflow completed the interrupted capture using a new real missing-web-throat atomic rejection, then imported and captured asymmetric access curves. It passed in 15.22 seconds; junit_capture_recovery.xml and RECOVERY_RECEIPT.json. No repetition of the entire 27-import matrix was needed.
5. ARTIFACT_IDENTITY_RECEIPT.json verifies 16 final native captures. Each downloaded PNG is byte-identical to a fresh public export of its actual native input. Every registered display PNG has pixel-identical content to Streamlit's documented-in-installed-code bilinear resize of that downloadable image. Every applicable Word embedded drawing is byte-identical to the current-input figure at the report's crop/DPI. JSON, SVG and Word text bind to the current input SHA-256. The original pre-correction atomic image is retained as historical evidence and excluded from final identity checks.

The initial drawing/report hashes were c3c4e86b50ce397490f3be347b53b9913de92dda62cb9d496193fa81c425cd9d and b6562fa543cf3dc199805d0d4126a82a84a2e5a44ebc107f159d847bf8466cbf. Their output corrections are covered by the final captures above, not by a claim that the interrupted run was immutable.

## Accepted UI and export behavior

- Exact native JSON upload uses the actual file uploader and open callback, not a mocked importer. Signed loads and all explicit declarations retain their native values. The pending default cannot show success merely because its conditional checks pass.
- Beam and column selections produce identical complete check, group-case and receiver-case structures. Only orientation/input identity and drawing presentation change.
- Signed actual, reverse and zero cases produce five records when the two applicable 45 kN supplemental force cases are added. N and V scale together in the same direction and sense; M remains unchanged. The zero real case gets no invented force direction. The standalone zero fixture remains one case.
- The signed/minimum detailed Word contains all 155 primitive check IDs. Both UI case rows and component envelopes match the current canonical result, preserving governors and ties.
- The full-V reduced-web failure is visible even while the weld-group rows pass. An additional large-force fixture fails. Neither shows a green global result.
- The deliberately restricted N<0/Table 4 domain produces OUTSIDE_SCOPE for the deep-web compression fixture. The otherwise same pure-moment fixture passes local checks. Outputs label the restriction as an initial implementation domain, not universal splice failure or flexural compactness.
- Nonzero torsion, weak-axis M and transverse V are retained in native data and marked outside scope, never silently discarded. A shortened web CJP run produces DETAIL_FAIL, empty resistance checks and disabled Word; the actual incomplete red run remains visibly short in the image.
- Existing bolted M004 W, conventional bolted W, pinned endplate and moment endplate projects remain isolated and unchanged through navigation. The welded W project, draft and report namespace survive navigation. A real welded input edit invalidates only its stale Word.
- Public figure, SVG, PNG and Word entry points reevaluate absent, unrelated and tampered caller results. A forged approval never hides the actual failing current input. Detailed forged-result output still retains every actual primitive check ID.

## Visual and geometric acceptance

A real drawing convention defect was found and corrected by its owner: V+ on member A's positive-x cut initially pointed in the wrong direction for the frozen M(x)=M0−Vx convention. The source reviewer independently confirmed the correct convention. Final V+ points upward for the beam and leftward for the rotated column, with the acted-on face explicitly labeled. N and M signs are consistent with the same face and local +y convention. No kernel change was requested for that correction.

Actual registered beam, column, signed-minimum, zero, asymmetric-access and incomplete-CJP pixels were inspected. They show both members, two flange CJP runs and the remaining-web run, real openings on both members, rounded bulb/radius leaders, explicit LA/LB/h0 dimensions, current load-cut arrows and all case rows. There are no invented fillet welds, cover plates, bolts or root-area credit. Zero forces have no fictitious force arrows. Text and leaders do not overlap the physical detail or one another in the accepted fixtures.

DRAWING_GEOMETRY_RECEIPT.json independently checks artist geometry against input and engine access outlines: the three CJP runs, section lengths/throats, four cut curves, both members' flange/web regions, radius endpoints and beam-to-column rotation are numerically faithful. The actual asymmetric native capture has LA=40, LB=45, RA=10, RB=12, HmaxA=25 and HmaxB=32 mm, and its picture preserves those distinct curves.

Word render QA used the actual downloaded files, not newly substituted report files. Beam compact output has 9 pages; signed/minimum detailed output has 52 pages; web-failure compact output has 9 pages. Selected pixels inspected:

- Beam pages 1, 4, 6 and 8: current-input cover, signed case, embedded geometry, materials/declarations, equations including the square root, scope and receiver/equilibrium records.
- Signed/minimum detailed pages 1, 10, 39 and 40: all five case rows, full-V receiver records, primitive check tables, signed regional stresses/resultants and reversal equilibrium.
- Web-failure pages 1 and 2: clear LOCAL_CHECKS_FAIL, no positive overall conclusion, and explicit failing full-web and coincident receiver rows while weld-group rows remain passing.

These selected pages are legible with no clipping, overlap or broken equation glyphs. This reviewer does not claim a pixel-by-pixel inspection of all 52 detailed pages. The artifact owner separately reports complete default compact/detailed render QA.

## Boundaries

This acceptance covers the specified finite UI/export contract. The independent mechanics/source qualification and aggregate application regression are separate evidence. AppTest exercises the actual application and native widgets but is not an HTTP/browser or deployed-site test. No FEM gate, hidden global member redesign or new load path was introduced. All outputs remain local calculation evidence, not fabrication approval.
