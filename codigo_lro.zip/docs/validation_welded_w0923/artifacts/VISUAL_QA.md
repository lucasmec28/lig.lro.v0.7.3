# Welded W splice artifact QA

Source version 0.9.23-welded-w-splice-dev. Final source hashes are in ARTIFACT_MANIFEST.json.

- Final focused run: 17 tests passed. Exact collected node IDs: TEST_NODES.json. JUnit receipt: tests.xml. Full run: focused_tests.log.
- Runtime dependencies were not replaced. The existing pytest fallback directory was appended after installed runtime packages; exact versions, module location, and search order are in DEPENDENCIES.json.
- Actual rendered pixels inspected for default beam, reversed column, unequal deeper B opening with real and supplemental signed cases, and short-weld diagnostic.
- Actual DOCX page pixels inspected for the compact 9-page record and detailed 19-page record. All content fits the page and table cells, equations render natively, repeated table headers persist, and no clipping or overlap was observed.
- Detailed primitive-table numeric display was shortened to eight decimal places after a 15-digit utilization wrapped its last digit. Full witness metadata remains recorded; display values never re-enter calculation.
- Opening outlines use the engine's exact tangent/circle construction and show all four physical openings. Flange and remaining-web CJP runs are distinct and match the declared dimensions. Radius leaders, mouth height, lengths, local axes, and a named load-cut diagram have separate annotation space.
- The depicted cut is member A's positive-x face. Positive N points along +x; positive M produces tension at +y; positive V points along -y, consistent with M(x)=M(0)-Vx. Column orientation rotates the same diagram and does not change the kernel.
- Zero actual loads draw no force/moment direction arrows. Every supplied and supplemental case remains in the public SVG/PNG; the figure height expands for long case lists. Word records complete cases separately from its cropped physical drawing.
- Material, procedure, geometry, inspection, and integrity declarations are retained as pending by default. No export presents an accepted fabrication detail, a physical hole-stress peak solution, or complete global member stability approval.
- Mismatched CJP lengths/throats display the declared geometry and a declared-versus-required table, with no computed strength. Forged/cached caller results are ignored by all public drawing and Word exports.

Evidence build can be reproduced with the primary-runtime Python using build_evidence.py. PDF and page PNG render products are review evidence, not alternate deliverables.
