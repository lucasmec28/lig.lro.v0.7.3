# Independent engine acceptance: welded W splice 0.9.23

Date: 2026-10-11. **Accepted for the agreed bounded local-splice method.** No outstanding engine blocker was found in this review. This is not fabrication approval, physical hole-peak analysis, full-member design, UI approval or a full-suite certification.

## Frozen identity and test results

- Kernel: `review0923/source0923/lro/welded_w_splice.py`
- Accepted SHA256: `55ee95f5ab5a937eb2361764cf1313c9c4d73923eba5dd9e8ae595b77cfecce9`
- Imported `lro/models.py` SHA256: `fc647aaec743d160cb848e678b9be5f195bc437e51e72a07631480aa831c769e`
- Independent runner: **156/156 named controls passed**, including **1,616 sampled cuts** of the actual tangent/circular-hole geometry, evaluated using exact line/circle intersections rather than SVG polygon approximations.
- Owner's focused kernel suite, independently rerun: **180 passed**.
- No UI tests or whole-application suite were run. Output/visual acceptance is assigned separately.

Commands/evidence:

- `python review0923/independent_engine_acceptance/audit_engine.py`
- `results.json`: each independent named control and final hash
- `owner_focused_tests.xml`: focused pytest results
- `accepted_sha256.txt`: final checked identities
- `default_evaluated_snapshot.json`: default declared fixture result

## Verified coverage

1. **Signed N/M/V and true nominal-group equilibrium.** All 27 signed/zero combinations were checked. Independent Gaussian integration of the engine's reported endpoint stresses over rectangles reconstructed from the inputs recovers N, M and V, including intrinsic flange inertia. Complete reversal reverses the stress field while preserving utilization. Beam/column labels do not change the force kernel.
2. **Source oracle.** Independent rational-arithmetic reference properties are reproduced: A=11,643.28 mm², Ix=210,927,543.422933 mm⁴ and Iy=72,841,441.827733 mm⁴. The default N=-600 kN, M=120 kNm, V=100 kN gives nominal group utilization 0.446178588902 and separate full reduced-web shear utilization 0.236253808411.
3. **Receiver transport and actual shape envelope.** Both serial members retain separate receiving checks. Signed endpoint moments follow `M(x)=M0-V*x`; the bound `|M0|+|V|L` covers both sides. Exact intersections of the real tangent lines and circular arc establish the actual removed interval at each sample. Actual remaining area, inertia and web area never fall below the declared minimum envelope; sampled nominal normal/shear values remain below the stored receiver bounds. The check is a nominal-section envelope, not a claimed physical stress-concentration bound or second equilibrated load field.
4. **Full receiving-web V.** A 600-kN pure-shear witness passes the nominal weld-group check and fails the actual reduced-web check, correctly preventing approval. Source-required separate pure-shear resistance is retained; the additional Fakury interaction is applied where normal and shear coexist.
5. **Material and rupture.** All four A572 Gr.50/A992 side combinations use the qualified material preset. Same-area tensile/shear yield dominance over rupture is demonstrated; no bolted-splice `0.85 Ag` cap or sum of serial-side capacities is introduced.
6. **Geometry and applicability.** Tangency, radius, upper-transition slope, complete hole bounds, root clearance, actual web height, wrong lengths/throats, impossible geometry, unsupported profiles/materials/actions and numerical overflow block approval. Independent exact-curve samples include asymmetric sides, deeper bulbs and the larger-radius shape within the declared initial detail domain.
7. **Local/member boundary.** Current adjacent-web shear branches use kv=5.34. The initial Table 4 axial-compression eligibility applies to `N<0`; neither a pure-M compression edge nor the column display label activates it. Intact-member flexural/local/global buckling remains member design. The short-opening domain is explicitly an implementation boundary, not a universal NBR maximum or prohibition on larger compliant details.
8. **45-kN supplemental cases.** Original combinations remain intact. For `0<hypot(N,V)<45 kN`, signed N/V are scaled along the same direction, original M is retained, and source-case provenance is recorded. Zero force creates no fictional direction or minimum moment. An added failing real case is not hidden by a passing minimum case.
9. **Fail-closed declarations/import.** Every missing native connection field is rejected rather than defaulted. Missing compatibility, actual geometry, root access, inspection/WPS or other required declarations cannot turn green, even with zero actions. Forged assumptions, units and boolean types are rejected. Canonical round-trip preserves actions, extra cases and negative zero.

## Scoped correction made during review

The original ready kernel `9ba63e9b73396a4ab6195822c015c3e871ad901f3c5ab10753481a4ebeb7dca1` passed 152 independent controls and 166 focused tests. The owner then raised a real presentation/model-fidelity concern that was confirmed in the source: a declared CJP run/throat mismatch blocked overall approval but still exposed hypothetical full-section strength numbers.

The agreed narrow correction is now verified on the accepted hash. Any of the four declared run/throat mismatches returns `DETAIL_FAIL`, empty strength/group/receiver results and `complete_checks=false`. Apparent actual Aew/Ix/Iy/Aw are null and patches empty. Required ideal full-CJP properties remain only in a separately labeled reference object, with explicit declared-versus-required dimensions. No overall false-green existed before this change; the correction prevents misleading component-strength presentation.

Prior results are retained as `results_before_cjp_dimension_guard.json` and `owner_focused_tests_before_guard.xml`. The new focused test count also includes the owner's added material interaction/subnormal-force controls and mismatch cases; it is not represented as an unchanged test population.

## Source and scope boundaries retained

The exact inspected source basis and agreed geometry contract are recorded in `../../next_welded_w_scope/independent_review/REVIEW.md` and the source qualification package. Fakury §§10.10.2–10.10.3.1 provides the nominal elastic CJP group method and supplementary interaction; current NBR controls resistance, material compatibility, effective areas, receiving material and standard access detailing.

**Nominal weld-group stresses are not physical hole-peak stresses.** No inferred mandatory FEM/shear-redistribution prerequisite was reinstated. Declared actual detail, material, WPS, quality/inspection and the excluded member/system verifications remain genuine requirements; this review does not certify them for any real project. Any later kernel change requires a scoped recheck against its new hash.
