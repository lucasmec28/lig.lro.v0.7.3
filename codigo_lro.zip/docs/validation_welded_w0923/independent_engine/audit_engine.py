"""Independent bounded engine acceptance; no UI or complete application suite."""
from dataclasses import fields, replace
from fractions import Fraction
import copy
import hashlib
import itertools
import json
import math
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / 'source0923'
KERNEL = SOURCE / 'lro/welded_w_splice.py'
EXPECTED_HASH = '55ee95f5ab5a937eb2361764cf1313c9c4d73923eba5dd9e8ae595b77cfecce9'
sys.path.insert(0, str(SOURCE))
from lro import welded_w_splice as w

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

assert digest(KERNEL) == EXPECTED_HASH, 'Kernel differs from owner readyhash'
C = replace(w.WeldedWSplice(), **{k: True for k in w.DECLARATIONS}, procedure_id='independent numeric fixture')
records = []
samples = 0

def near(a, b, atol=1e-7):
    assert math.isclose(a, b, rel_tol=3e-12, abs_tol=atol), (a, b)

def check(name, fn):
    try:
        fn()
        records.append({'name': name, 'status': 'PASS'})
    except Exception as exc:
        records.append({'name': name, 'status': 'FAIL', 'error': repr(exc)})

def rectangles(c, removed):
    h = c.d - 2*c.tf - 2*removed
    return [(c.bf, -c.d/2, -c.d/2+c.tf), (c.tw, -h/2, h/2),
            (c.bf, c.d/2-c.tf, c.d/2)]

def props(c, removed):
    p = rectangles(c, removed)
    return (sum(b*(z-y) for b,y,z in p),
            sum(b*(z**3-y**3)/3 for b,y,z in p),
            c.tw*(c.d-2*c.tf-2*removed))

def group_case(n, m, v):
    c = replace(C, N=n, M=m, V=v)
    out = w.evaluate(c)
    assert out['summary']['complete_checks']
    a, ix, aw = props(c, c.access_h0)
    g = out['group_cases'][0]
    # Integrate the engine's reported endpoint stresses rather than its own
    # resultants, independently using Gauss quadrature on input rectangles.
    N = M = V = 0.
    for j, (b, lo, hi) in enumerate(rectangles(c, c.access_h0)):
        p, q = g['stresses'][2*j:2*j+2]
        near(p['sigma'], n/a+m*lo/ix)
        near(q['sigma'], n/a+m*hi/ix)
        near(p['tau'], v/a)
        near(q['tau'], v/a)
        center, half = (hi+lo)/2, (hi-lo)/2
        for sign in (-1, 1):
            y = center+sign*half/math.sqrt(3)
            sigma = p['sigma']+(q['sigma']-p['sigma'])*(y-lo)/(hi-lo)
            weight = b*half
            N += sigma*weight
            M += sigma*y*weight
            V += p['tau']*weight
    for actual, target in ((N,n),(M,m),(V,v)):
        near(actual,target)
    assert g['equilibrium']['verified'] and not g['physical_hole_peak_claim']
    for key, val in [('N',N),('M',M),('V',V)]:
        near(g['equilibrium']['integrated'][key],val)
    if v == 0 or (n == 0 and m == 0):
        assert all(not p['interaction_applicable'] for p in g['stresses'])

for n,m,v in itertools.product((-600000.,0.,600000.),(-120e6,0.,120e6),(-100000.,0.,100000.)):
    check(f'signed_group_{n}_{m}_{v}', lambda n=n,m=m,v=v: group_case(n,m,v))

def reference_fixture():
    raw = json.loads((HERE.parents[1]/'next_welded_w_scope/independent_review/fixture_results.json').read_text())
    out = w.evaluate(C)
    near(out['geometry']['Aew'], raw['geometry']['Aew'])
    near(out['geometry']['Ix'], raw['geometry']['Ix'])
    near(out['geometry']['Iy'], raw['geometry']['Iy'])
    near(out['group_cases'][0]['group_utilization'], raw['base_case']['interaction_utilization'])
    near(out['receiver_cases'][0]['full_web_shear_utilization'], raw['base_case']['separate_reduced_web_shear_utilization'])
    assert out['status'] == 'LOCAL_CHECKS_PASS_WITHIN_SCOPE'

check('independent_fraction_oracle', reference_fixture)

def reversal_and_orientation():
    out = w.evaluate(C)
    rev = w.evaluate(replace(C,N=-C.N,M=-C.M,V=-C.V))
    assert w.evaluate(replace(C,orientation='column')) == out
    for p,q in zip(out['checks'],rev['checks']):
        near(p['utilization'],q['utilization'])
    for p,q in zip(out['group_cases'][0]['stresses'],rev['group_cases'][0]['stresses']):
        near(p['sigma'],-q['sigma']);near(p['tau'],-q['tau'])

check('full_reversal_and_member_orientation', reversal_and_orientation)

def void_at_x(curve, x):
    """Exact intersections of the declared lines/circle, no sampled SVG."""
    vals=[]
    for mouth,tan in [((0.,0.),curve['upper_tangent']),((0.,curve['H0']),curve['lower_tangent'])]:
        if -1e-10 <= x <= tan[0]+1e-10:
            vals.append(mouth[1]+(tan[1]-mouth[1])*x/tan[0])
    cx,cy=curve['center'];r=curve['R']
    rad=r*r-(x-cx)**2
    if rad >= -1e-8:
        for y in (cy-math.sqrt(max(0.,rad)),cy+math.sqrt(max(0.,rad))):
            t=math.atan2(y-cy,x-cx)
            if curve['angle_start']-1e-10<=t<=curve['angle_end']+1e-10:
                vals.append(y)
    assert vals, (x,curve)
    return min(vals),max(vals)

def geometry_envelope(hma,hmb,la,lb,ra,rb,sign):
    global samples
    c=replace(C,access_hmax_a=hma,access_hmax_b=hmb,access_length_a=la,access_length_b=lb,
              access_radius_a=ra,access_radius_b=rb,N=-600000.*sign,M=120e6*sign,V=-100000.*sign)
    out=w.evaluate(c)
    assert out['status'] == 'LOCAL_CHECKS_PASS_WITHIN_SCOPE', out['issues']
    full_a,full_i,full_aw=props(c,0.)
    for side in ('a','b'):
        sec=out['geometry']['receiver_'+side]
        rec=next(z for z in out['receiver_cases'] if z['side']==side)
        curve=sec['curve'];cx,cy=curve['center'];r=curve['R'];L=curve['L']
        for mouth,tan in [((0.,0.),curve['upper_tangent']),((0.,curve['H0']),curve['lower_tangent'])]:
            near(math.dist(tan,(cx,cy)),r)
            near((tan[0]-cx)*(tan[0]-mouth[0])+(tan[1]-cy)*(tan[1]-mouth[1]),0.)
        assert curve['upper_slope']>0 and r>=10
        near(sec['Amin'],props(c,curve['Hmax'])[0])
        near(sec['Imin'],props(c,curve['Hmax'])[1])
        near(rec['M_bound'],abs(c.M)+abs(c.V)*L)
        for stored,x in zip(rec['signed_M_endpoints'],sec['x_interval']):
            near(stored,c.M-c.V*x)
        for j in range(101):
            t=L*j/100
            u,l=void_at_x(curve,t)
            assert -1e-8<=u<=l+1e-8 and l<=curve['Hmax']+1e-8
            a=full_a-2*c.tw*(l-u)
            yf=c.d/2-c.tf
            ix=full_i-2*c.tw*((yf-u)**3-(yf-l)**3)/3
            aw=full_aw-2*c.tw*(l-u)
            assert a>=sec['Amin']-1e-7 and ix>=sec['Imin']-1e-5 and aw>=sec['Aw_min']-1e-7
            x=-t if side=='a' else t
            mx=c.M-c.V*x
            sf=abs(c.N)/a+abs(mx)*(c.d/2)/ix
            sw=abs(c.N)/a+abs(mx)*yf/ix
            assert sf<=rec['section']['sigma']+1e-9
            assert sw<=rec['web_nominal']['sigma']+1e-9
            assert abs(c.V)/a<=rec['section']['tau']+1e-9
            assert abs(c.V)/aw<=rec['web_nominal']['tau']+1e-9
            samples+=1
        assert rec['envelope_not_second_equilibrium_field']

shapes=[(25.,25.,45.,45.,10.,10.),(30.,40.,40.,45.,10.,11.),
        (49.,35.,44.,42.,12.,10.),(50.,25.,53.,45.,24.,10.)]
for shape,sign in itertools.product(shapes,(-1,1)):
    check(f'actual_curve_envelope_{shape}_{sign}',lambda s=shape,k=sign:geometry_envelope(*s,k))

def full_web_witness():
    out=w.evaluate(replace(C,N=0.,M=0.,V=600000.))
    assert out['group_cases'][0]['group_utilization']<1
    assert out['status']=='LOCAL_CHECKS_FAIL' and not out['global_pass']
    for rec in out['receiver_cases']:
        assert rec['full_web_shear_utilization']>1
        near(rec['full_web_shear_utilization'],600000./423273.6)
    assert all(not p['interaction_applicable'] for p in out['group_cases'][0]['stresses'])

check('full_V_reduced_web_failure_despite_group_pass',full_web_witness)

def material_dominance(name_a,name_b):
    out=w.evaluate(replace(C,steel_a=name_a,steel_b=name_b))
    assert out['global_pass']
    for rec in out['receiver_cases']:
        q=rec['rupture_dominance']
        assert q['yield_dominates'] and q['Ae']==q['An']==q['Ag']
        assert q['no_bolted_085_cap']
        near(q['normal_yield'],345/1.1);near(q['normal_rupture'],450/1.35)
        assert q['shear_rupture']>q['shear_yield']

for ma,mb in itertools.product(('ASTM A572 Gr.50','ASTM A992'),repeat=2):
    check(f'material_and_real_net_area_{ma}_{mb}',lambda a=ma,b=mb:material_dominance(a,b))

def expected_status(changes,status):
    out=w.evaluate(replace(C,**changes))
    assert out['status']==status, (changes,out['status'],out['issues'])
    assert not out['global_pass']

invalids=[({'access_hmax_a':24.},'INVALID_GEOMETRY'),({'access_radius_a':12.5},'INVALID_GEOMETRY'),
          ({'access_length_a':19.},'INVALID_GEOMETRY'),({'access_radius_a':9.},'DETAIL_FAIL'),
          ({'root_clearance':10.},'DETAIL_FAIL'),({'root_radius':24.},'DETAIL_FAIL'),
          ({'clear_web_height':250.},'DETAIL_FAIL'),({'access_length_a':39.},'DETAIL_FAIL'),
          ({'access_length_a':46.},'OUTSIDE_SCOPE'),({'access_hmax_a':51.},'DETAIL_FAIL'),
          ({'web_weld_length':230.},'DETAIL_FAIL'),({'flange_weld_throat':15.},'DETAIL_FAIL'),
          ({'access_h0':140.},'INVALID_GEOMETRY'),({'tf':0.},'INVALID_GEOMETRY'),
          ({'tw':float('nan')},'INVALID_INPUT'),({'N':True},'INVALID_INPUT'),
          ({'M':1e308},'NUMERICAL_FAILURE'),({'torsion':1.},'OUTSIDE_SCOPE'),
          ({'weak_M':1.},'OUTSIDE_SCOPE'),({'transverse_V':1.},'OUTSIDE_SCOPE'),
          ({'steel_a':'ASTM A36'},'OUTSIDE_SCOPE'),({'consumable':'E70XX'},'OUTSIDE_SCOPE'),
          ({'profile_b_name':'different W'},'OUTSIDE_SCOPE'),({'offset_y':.01},'OUTSIDE_SCOPE'),
          ({'static':False},'OUTSIDE_SCOPE')]
for ch,status in invalids:
    check(f'invalid_or_unsupported_{ch}',lambda x=ch,s=status:expected_status(x,s))

def incomplete_cjp_has_no_hypothetical_strength(field, value):
    out=w.evaluate(replace(C,**{field:value}))
    assert out['status']=='DETAIL_FAIL' and not out['global_pass']
    assert not out['summary']['complete_checks']
    assert out['checks']==[] and out['group_cases']==[] and out['receiver_cases']==[]
    assert all(out['geometry'][key] is None for key in ('Aew','Ix','Iy','Aw'))
    assert out['geometry']['patches']==[]

for field,value in [('flange_weld_length',304.),('flange_weld_throat',15.),
                    ('web_weld_length',226.),('web_weld_throat',9.)]:
    check('declared_incomplete_CJP_no_hypothetical_strength_'+field,
          lambda f=field,v=value:incomplete_cjp_has_no_hypothetical_strength(f,v))

def minimum_case(n,v,m):
    c=replace(C,N=n,V=v,M=m)
    out=w.evaluate(c);cases=out['cases']
    assert (cases[0]['N'],cases[0]['V'],cases[0]['M'])==(n,v,m)
    R=math.hypot(n,v)
    if 0<R<45000:
        assert len(cases)==2
        q=cases[1]
        near(math.hypot(q['N'],q['V']),45000.)
        near(q['N'],n/R*45000.);near(q['V'],v/R*45000.)
        assert q['M']==m and q['kind']=='minimum' and q['source_case']=='actual'
        assert len(out['group_cases'])==2 and len(out['receiver_cases'])==4
    else:
        assert len(cases)==1

for n,v,m in [(3000.,-4000.,-2e6),(-3000.,4000.,2e6),(0.,0.,2e6),(0.,0.,0.),
              (45000.,0.,0.),(-45000.,0.,0.),(0.,100.,-1e6),(1.,0.,0.)]:
    check(f'actual_and_supplemental_minimum_{n}_{v}_{m}',lambda n=n,v=v,m=m:minimum_case(n,v,m))

def minimum_and_added_failure():
    c=replace(C,N=3000.,V=4000.,M=0.,load_cases=(w.LoadCase(id='high',N=0.,M=0.,V=-600000.),))
    out=w.evaluate(c)
    assert out['status']=='LOCAL_CHECKS_FAIL'
    assert [z['id'] for z in out['cases']]==['actual','high','actual_force_floor']
    assert len(out['group_cases'])==3 and len(out['receiver_cases'])==6
    assert any('high::receiver_' in row for row in out['summary']['governing'])
    assert w.evaluate(replace(C,N=100.,V=0.,M=0.,minimum_force=False))['status']=='DETAIL_FAIL'

check('additional_failure_not_hidden_by_minimum',minimum_and_added_failure)

def local_global_scope():
    d=replace(C,d=700.,clear_web_height=637.,web_weld_length=619.2,N=0.,M=120e6)
    a=w.evaluate(d);b=w.evaluate(replace(d,orientation='column'));z=w.evaluate(replace(d,N=-1.))
    assert a['status']==b['status']=='LOCAL_CHECKS_PASS_WITHIN_SCOPE'
    assert z['status']=='OUTSIDE_SCOPE'
    assert not a['local_section_eligibility']['applied']
    assert z['local_section_eligibility']['applied']
    assert a['local_section_eligibility']['flexural_member_classification_external']
    assert a['local_section_eligibility']['global_member_buckling_external']
    near(z['local_section_eligibility']['flange_limit'],.56*math.sqrt(200000/345))
    near(z['local_section_eligibility']['web_limit'],1.49*math.sqrt(200000/345))
    assert 'máximo normativo' in w.evaluate(replace(C,access_length_a=46.))['issues'][0]['message']

check('axial_compression_domain_not_pure_M_or_column_gate',local_global_scope)

def shear_stability_branch(lam):
    # N=0 permits testing adjacent-web branches without the explicitly
    # separate initial non-slender axial-compression eligibility gate.
    h=lam*C.tw;d=h+2*C.tf+2*C.root_radius
    c=replace(C,N=0.,M=0.,V=100000.,d=d,clear_web_height=h,web_weld_length=d-2*C.tf-2*C.access_h0)
    out=w.evaluate(c);q=out['adjacent_web']
    lp=1.10*math.sqrt(5.34*200000/345);lr=1.37*math.sqrt(5.34*200000/345)
    f=1. if lam<=lp else lp/lam if lam<=lr else 1.24*(lp/lam)**2
    near(q['VRd'],.6*345*(d*C.tw)*f/1.1)
    assert q['kv']==5.34

for lam in (25.,70.,100.):
    check(f'current_adjacent_web_shear_branch_{lam}',lambda x=lam:shear_stability_branch(x))

for declaration in w.DECLARATIONS:
    check('missing_declaration_'+declaration,lambda k=declaration:expected_status({k:False,'N':0.,'M':0.,'V':0.},'NOT_VERIFIED'))
check('missing_procedure_no_green',lambda:expected_status({'procedure_id':''},'NOT_VERIFIED'))

def missing_native(field):
    raw=C.to_dict();del raw['connection'][field]
    try:w.WeldedWSplice.from_dict(raw)
    except ValueError:return
    raise AssertionError('Missing native field silently accepted: '+field)

for field in fields(C):
    check('native_missing_'+field.name,lambda n=field.name:missing_native(n))

def canonical_contract():
    c=replace(C,N=-0.,load_cases=(w.LoadCase(id='second',N=1234.,M=-4321000.,V=-8765.),))
    raw=c.to_dict();clone=w.WeldedWSplice.from_dict(json.loads(json.dumps(raw,allow_nan=False)))
    assert clone==c and w.evaluate(clone)==w.evaluate(c)
    assert math.copysign(1.,clone.N)==-1
    for location,key,value in [('units','force','kN'),('fixed_assumptions','physical_hole_peak_claim',True),
                               ('fixed_assumptions','gamma_a1',True),('connection','material_certified','true')]:
        bad=copy.deepcopy(raw);bad[location][key]=value
        try:w.WeldedWSplice.from_dict(bad)
        except ValueError:continue
        raise AssertionError('Noncanonical import accepted')

check('canonical_roundtrip_and_forged_imports',canonical_contract)
check('kernel_hash_unchanged',lambda: (_ for _ in ()).throw(AssertionError('Kernel changed')) if digest(KERNEL)!=EXPECTED_HASH else None)
report={'scope':'Independent bounded numerical engine acceptance; no UI/full suite',
        'kernel_sha256':digest(KERNEL),'models_sha256':digest(SOURCE/'lro/models.py'),
        'case_count':len(records),'passed':sum(x['status']=='PASS' for x in records),
        'failed':sum(x['status']=='FAIL' for x in records),'actual_curve_sample_cuts':samples,
        'checks':records,'physical_hole_peak_claim':False}
(HERE/'results.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='checks'},indent=2))
for r in records:
    if r['status']=='FAIL':print(r)
sys.exit(bool(report['failed']))
