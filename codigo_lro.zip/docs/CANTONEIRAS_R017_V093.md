# Cantoneiras duplas R017 · recorte duplo · 0.9.3-angle-dev

Nota de manutenção: a correção finita 0.9.17 está em `COPED_DOUBLE_ANGLES_AUDIT0917_METHOD.md`. A versão do esquema nativo 0.9.3 é preservada para compatibilidade.

## Resultado e alcance

A ligação local R017 foi implementada separadamente das famílias R016 e R015. São duas cantoneiras iguais convencionais, ambas parafusadas, entre a alma de uma viga W recortada e a alma de outra viga W perpendicular. A primeira rota cobre somente V estático com sinal, N=M=T=0, recortes superior/inferior iguais e rasos e apoio interior íntegro. O programa não declara dimensionamento completo da viga de apoio nem projeta o sistema de travamento.

O preset inicial é uma geometria prática W360×51/W360×51, quatro parafusos M20 comuns à alma e quatro por cantoneira no apoio, L76×76×6,4, passos60, bordas40, comprimento260, topo47,5, recortes c130/dc30 e R15, folga10. Sem referência externa do travamento da mesa comprimida na face do recorte, a saída é **VERIFICAÇÃO COMPLEMENTAR PENDENTE**. Os valores calculáveis continuam disponíveis. A exigência é localizada e justificada pelo modelo de instabilidade, não uma exigência genérica de análise por elementos finitos ou de toda a estrutura.

### Estados

- Dados inválidos: tipo, valor não finito ou faixa de entrada não utilizável.
- Falha numérica: entrada finita cuja conversão ou resultado derivado não é representável; sem aprovação ou artefato antigo elegível.
- Geometria fisicamente inválida: interferência real, furo interceptando corte ou área líquida não positiva; não fornece capacidades.
- Fora do domínio R017: topologia/ações não cobertas; não descarta N/M/T.
- Falha resistente: pelo menos uma verificação calculada não atende. Pendências simultâneas continuam registradas.
- Falha de detalhamento: geometria calculável, mas requisito de detalhamento não atendido.
- Modelo pendente: componente/caminho/condição de contorno sem qualificação.
- Atendimento local: verificações locais completas no domínio e condição externa explicitamente qualificada. `local_pass` é o indicador. `global_pass` permanece falso e o membro global é `EXTERNAL_NOT_EVALUATED`.

Uma variação do gabarito industrial ou da cobertura de uma tabela não é tratada automaticamente como impossibilidade física. Gabaritos alternativos ainda sem qualificação mecânica recebem a pendência específica de compatibilidade/flexão das abas e grupos.

## Geometria e sinais

- x da viga apoiada é medido da face da alma de apoio em direção à viga. A ponta está em x=folga, a face do recorte em x=folga+c. c é medido desde a ponta, não desde os parafusos.
- y da viga apoiada é medido para baixo desde o topo. dc superior/inferior parte da superfície externa da mesa correspondente. `beam_level` é a diferença de nível dos topos.
- Arco superior: centro `(folga+c−R, dc−R)` e quarto de círculo de `(folga+c−R,dc)` a `(folga+c,dc−R)`. Inferior é o espelho. Há cálculo da distância exata ao corte para a integridade do círculo do furo.
- Desenho industrial R017, p.20: **R15** nos dois cantos. O mínimo aproximado12mm Gerdau p.19 é outra afirmação. Raio digitado não é silenciosamente alterado.
- Na primeira rota, o círculo inteiro do furo comum deve preceder o início da concordância para aplicar os blocos/ligamentos retos. Uma linha de furos no arco recebe contorno real e diagnóstico físico, mas o caminho resistente curvo permanece pendente.
- Folgas de flange são geométricas; envelope conservador de concordância do apoio e acesso da ferramenta são verificados separadamente. Um envelope conservador não é rebatizado como uma colisão real de flange.
- V>0 é reação vertical para baixo entregue ao apoio. Os parafusos comuns empurram a alma apoiada para cima; portanto sua borda livre carregada é o recorte superior. As cantoneiras recebem forças opostas em suas abas. Reversão troca bordas e prefixos; V=0 verifica ambos os sentidos com o mínimo local45kN.

## Componentes NBR 8800 atual

ABNT NBR 8800:2024, versão corrigida2025. γa1=1,10 e γa2=1,35. Materiais e faixas de produto são os cadastrados; dimensões métricas e imperiais mantêm seus valores exatos.

1. Mínimo45kN aplicado uma única vez ao conjunto, item6.1.5.2. Vsd real e Vd adotado são registrados; o apoio global recebe Vsd, não a carga mínima artificial.
2. Parafusos: coeficientes0,45 com rosca no plano e0,56 sem rosca; item6.3.3.2 e redução de pega6.3.7. n parafusos comuns em corte duplo;2n parafusos de apoio em corte simples. A espessura de nenhuma alma é duplicada.
3. Contato/rasgamento: `min(1,2lc;2,4db)t fu/γa2`, limitação conservadora de deformação em serviço, item6.3.3.3. São calculadas a soma normativa e a verificação individual compatível com força direta uniforme por furo.
4. Furação, dedução líquida, espaçamentos/bordas, pega e acesso:6.3.6–6.3.12. O furo físico é dh; dedução líquida é a maior dimensão da Tabela14+2mm, salvo furação por broca explicitamente documentada.
5. Cada uma das quatro abas físicas: cisalhamento bruto e líquido6.5.5, contato e blocos L6.5.6, todos os prefixos carregados, Cts=1.
6. Alma apoiada: h0=d−dc_sup−dc_inf, Ag=h0tw, An=(h0−n dn)tw,6.5.5. Blocos L da borda livre real do recorte à ponta da viga, Cts=1 conforme Fig.16(b). Para k furos: Agv=[E+(k−1)p]tw; Anv=Agv−(k−0,5)dn tw; Ant=(g−folga−dn/2)tw. Demanda de cada prefixo=kV/n.
7. Cisalhamento5.4.3.1 da seção W íntegra após o recorte é identificado separadamente. **kv=5,34 não é aplicado à tira recortada com duas bordas livres.**

## Recorte: modelo complementar qualificado

Gerdau7ª edição2018 p.25 fornece duas resistências distintas. A base empírica e o domínio original do modelo são corroborados por Dowswell & Whyte, Engineering Journal51(1),2014, pp.43–52, DOI10.62913/engj.v51i1.1055.

- Primeiro escoamento: VRd=fyW1/[1,1(c+folga)].
- Instabilidade: Fbc,d=350600[tw²/(c h0)](3,5−7,5dc/d), em MPa/mm. VRd=Fbc,d W1/(c+folga).
- W1=tw h0²/6. Mantém seção elástica e cap de primeiro escoamento, sem ganho plástico.
-350600MPa é o mesmo coeficiente impresso35060kN/cm². Fbc,d já é de cálculo: **não recebe outra divisão porγ**. Não se insere adicionalmente0,9fy nem se migra parcialmente ao modelo mais novo.
- Domínio: recortes superior/inferior de iguais comprimento/profundidade, c≤2d, dc≤0,2d, condições de restrição lateral abaixo.170mm é cobertura de estudo/tabulação, não teto universal da equação.
- Recortes desiguais não recebem comprimento/profundidade médios. Não é calculada resistência de instabilidade fora do modelo; identificam-se a rota mais ampla e a qualificação ainda necessárias.

### Condições de contorno que não podem ser presumidas

O modelo antigo pressupõe restrição fora do plano na ligação, distribuída na altura conectada da alma, e restrição da translação lateral da mesa comprimida na face do recorte. **Não fixa toda a seção contra torção**; a fonte permite movimento da borda tracionada e do centro de cisalhamento.

A topologia convencional de duas cantoneiras e parafusos verticalmente separados é registrada para a restrição na ligação. Isso não calcula resistência/rigidez de um travamento e não prova restrição em x=folga+c. L≥d/2 e grupo centralizado ou superior são condições documentais convencionais verificadas separadamente.

Para V>0, exigir registro da mesa superior; V<0, inferior; V=0, ambos. O registro contém sistema físico, referência da verificação independente de resistência/rigidez e coordenada x que deve coincidir com a face do recorte. O programa assume a condição externa declarada e não certifica o documento referenciado. Nem a presença de laje, continuidade da mesa, as cantoneiras ou um checkbox substituem essa condição.

Exemplos didáticos com referência sintética servem apenas para testar o contrato matemático. Não documentam um travamento real de obra.

## Uma alma de apoio, sem mecanismo fictício

As duas colunas ficam em x_girder=±(tw_viga/2+g_apoio). Cada uma introduz V/2 através de n furos distintos em uma única alma de espessura tw_apoio. A rota local convencional verifica corte dos parafusos, contato/rasgamento direcional, detalhe e acesso. Para o furo terminal sem borda livre na direção do carregamento, adota-se o cap de contato2,4dbtwfu/γa2; uma junção com mesa contínua não vira borda livre.

- Não existe bloco L de mesa de pilar transplantado, borda fictícia no fim da cantoneira ou tira arbitrária de alma com demandaV/2.
- NBR5.7.1 se refere às forças normais à face externa da mesa; as fórmulas de força localizada de flange não substituem os furos carregados verticalmente na alma. O requisito geral de restrição6.1.7 não é descartado.
- Um apoio com aberturas/entalhes/ligação sobreposta está fora dessa primeira rota e exige caminhos/demandas reais próprios.
- AISC “Table Talk”, fev2024, e “Simple Shear Connection Limit States”, fev2008, corroboram essa introdução local convencional por corte/contato/rasgamento. O acesso disponível foi texto primário indexado; PDFs integrais retornaram403. O benchmark132kip é somente da interface de transferência, não da viga inteira.

## Exportação ao modelo global

A saída preserva reação real, duas posições de introdução, coordenada de aplicação e excentricidade declarada. Eixos globais do apoio: x longitudinal, y vertical para cima, z normal à alma. Para F=(0,−V,0), Mx=Vez; ez=0 no modelo de força no plano da alma. Não se usa d_apoio/2 como braço de torção.

Uma excentricidade não nula é exportada e mantém pendente a transferência local do torque. Outras forças/momentos de entrada não são descartados.

A função opcional `support_boundary_actions` é somente equilíbrio, sem aprovação de seção: recebe VL,VR,ML e posições reais, verifica VL−VR=V e calcula cortante intermediária VL−V/2. VL300kN,VR100kN,V200kN fecha com200kN entre colunas. O45kN mínimo da ligação não é imposto aos esforços globais. Flexão, cisalhamento, seções perfuradas, torção, outras cargas e estabilidade exigem análise própria do membro.

## Evidência independente e discrepância histórica

As oracles foram congeladas antes da comparação, com gerador stdlib sem imports do app e hashes dos dados/fontes. Há fixtures de unidades, primeiro escoamento, instabilidade governante, mudança de folga, reversão, prefixos, alma de apoio fraca, rosca, grupos/grades, raio real e equilíbrio.

- d400/tw8/dc40/c130/folga10: primeiro escoamento305870,129870N; instabilidade1446578,168498N.
- d400/tw3/dc40/c300/folga10: instabilidade14928,774194N, menor que o piso45kN. O comprimento está fora da tabela curta, mas dentro do domínio geométrico original.
- Baseline W355/tw7,2/dc30/c130/folga10: primeiro escoamento233950,324675N; instabilidade1013245,872973N.
- A linha histórica266kN Gerdaup.33 não é oracle exata: faltam reconciliação do catálogo/perfil e premissas originais da tabela. Nenhum coeficiente, recorte ou braço foi ajustado para forçar266kN.

Fontes e fronteiras: `r017_verification/source_boundary_contract.md`. Estatísticas finais e hashes de validação constam em `VALIDACAO_R017_V093.md` e `R017_VALIDATION_RECORD.json` após fechamento.
