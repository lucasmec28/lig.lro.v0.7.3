# R015 corrigida em 0.9.16

## Escopo e modelo preservados

A auditoria fornecida de 10/10/2026 não encontrou nova aprovação resistente indevida nos vinte fixtures e 10.088 comparações independentes. A presente intervenção não muda resistência, partilha de forças ou topologia. Mantém o método convencional LCSP/NBR elástico em equilíbrio, os dois U com extremos reais, uma alma de viga, ações com sinal, piso de 45 kN aplicado uma vez, parafusos em corte simples, furos e extremidades reais. Não soma coeficientes ou ações de métodos alternativos.

## Correções

1. Cada exportação Word, SVG ou PNG reavalia a entrada atual. Resultados fornecidos, inclusive com a mesma fotografia da entrada e números/flags adulterados, são argumentos de compatibilidade sem autoridade. Omitir o resultado também produz avaliação canônica.
2. O desenho avulso registra projeto e ações reais V/N/M/T assinadas. A condição V estático, N=M=T=0 está identificada como domínio do método. Fora dele, a geometria não se transforma em outro arranjo suportado.
3. INVALID_INPUT, INVALID_GEOMETRY, NUMERICAL_FAILURE, OUTSIDE_R015_SCOPE, ENGINEERING_MODEL_PENDING, DETAIL_FAIL e VERIFIED_SUBCHECK_FAIL são distintos. Falha de operação derivada finita não vira erro do dado. A UI retira resultado/memória obsoletos antes da conversão em N; falhas numéricas não deixam downloads elegíveis. Importações inválidas são atômicas e conservam o estado anterior.
4. Vinte e dois envelopes de apresentação preservam todas as 59 linhas ordinárias e 95 em V=0. O agrupamento não calcula nem soma resistências: conserva cada ID uma vez, dados completos, furos/soma normativa, prefixos, sentido, equação, referência, máximos reais/adotados, governantes e empates. A UI mantém detalhes expansíveis; o Word mantém o desenvolvimento completo e nomes A1/A2 em português.
5. Valores nativos incompatíveis com representação exata dos controles, inclusive a testemunha limitada de massa9007199254740993, são rejeitados atomicamente com identificação do campo. Isso é fidelidade de metadado, sem alegação de defeito resistente ou nova restrição física.

## Limite do ramo curto

O caso x0=40, b=76, Lhorizontal=36 mm e w=4 mm conserva as 59 resistências e índice0,4941542418. Antes era DETAIL_FAIL por40mm. Agora é ENGINEERING_MODEL_PENDING, sem aprovação: NBR6.2.6.2.3 oferece a alternativa de perna considerada limitada a25% do comprimento, não implementada nesta rota de garganta uniforme integral. Não se reduz a entrada silenciosamente, não se implementa um grupo de pesos diferentes e não se libera a alternativa sem avaliação coerente. Não é a regra de solda intermitente6.2.6.2.4. O limite100w existente também permanece limite do método adotado, sem proibição universal da norma.

## Fontes reconciliadas

O registro fontes.json individualiza R015 p.18 no PDF industrial já fornecido. Gerdau2018 pp19,21,26,50 apoia a topologia LCSP; seu ICR/NBR2008 não é o resultado-alvo do grupo elástico atual. A versão NBR2024 corrigida2025 permanece a base dos coeficientes.

P901-23W completo está disponível: II.A-2A PDF580/IIA-40 tem solda no apoio e parafusos na alma, interfaces inversas; II.A-5 PDF615/IIA-75 tem viga recortada e apoio parafusado na alma. Souza10.1 PDF134–138, Figs10.4–10.7, é uma alternativa elástica pertinente para L64×6,3 e VS/CVS, com momentos de extremidade que geram tração nos parafusos/momento lateral. Nenhum desses casos é transplantado como validação integral da R015 corrente. Não se somam esforços alternativos ou coeficientes históricos.

Os pontos acima vêm da inspeção documentada na auditoria fornecida. O artigo AISC Keeping Fillet teve abertura integral403; não se declara nova leitura completa. Continua ausente um exemplo publicado integral com a mesma geometria e coeficientes atuais. Isso não invalida as verificações componentes explicitamente calculadas.

## Limites desta entrega

Validação focada dos testes R015, vinte fixtures independentes, paridade dos auxiliares compartilhados, AppTest real e bytes registrados dos downloads, e inspeção limitada de Word/desenho. Sem suíte completa, outra família, FEA, mudança geral de layout, publicação ou certificação da estrutura. O backlog de rótulos longos R016 permanece separado. Logs, comandos deduplicados, delta e manifestos acompanham a revisão0.9.16.
