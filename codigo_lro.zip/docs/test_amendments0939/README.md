# Test amendments for the 0.9.39 source

All nine amended inherited test files retain their exact 0.9.38 originals here. EXISTING_TEST_CHANGES.diff and TEST_AMENDMENT_MANIFEST.json bind every amendment; all 41 inherited fixture files remain byte-identical. The release adds new tests separately. No frozen engineering oracle was replaced or weakened to hide an adverse result.

## Old-schema fixture construction

- test_corner_compression0935.py removes the two new cap controls when constructing a genuinely old corner payload.
- test_one_root_compression0937.py and test_one_root_compression_ui0937.py remove those controls alongside the already excluded later compression fields when constructing 0.9.28 welded-double projects.

A hybrid old-version/new-field payload remains invalid. Actual import validation is strict and unchanged by these test adapters.

## Explicit legacy metadata projections

- test_long_bolt_scope0934.py maps only the enumerated supported component versions, the two default/inactive controls and one exact known scope sentence back to the frozen legacy metadata. It rejects active/nonzero controls, unknown versions and altered wording. The 29 expected frozen hashes are unchanged. Preexisting numeric paths, types and values are retained exactly.
- test_single_angle_corner0933.py removes only the two default cap controls from the default welded-double native payload. Its geometry and complete-result hashes are compared without projection and remain exact.

The independent applied-code validator loads the actual amended helper and digest/canonical ASTs, protects frozen fixtures, exercises numeric/geometry/status/version mutations and the actual old-schema constructor. Its receipts are delivered with the independent mechanical review. This is a bounded schema comparison, not a general normalization of engineering state.

## Intended behavior and current identities

- test_double_cover.py replaces the obsolete blanket internal-bolt collision expectation with the reviewed physical-geometry behavior. Applicable fin qualification and access pendency remain required; external mechanics and applicable internal mechanical checks retain exact parity.
- test_bolted_opposed_angle_gusset_ui0931.py adds active-cap route conversion and rejected-transition rollback regressions. An explicit conversion to unsupported opposed topology resets the cut visibly; invalid conversions keep the previous topology without clamping and retire stale reports.
- test_corner_integration0932.py and test_guided_selection0919.py update only explicit application/component-version expectations to the current 0.9.39 identities. Navigation boundaries and installation-guard assertions remain intact.

The known absent external bearing oracle remains a genuine failed test, with no skip, fabricated expected value or passing reclassification.
