# Cantoneiras Gerdau · 0.9.27-gerdau-angles-dev

## Catálogo, identidade e aço

A fonte é a tabela fornecida pelo usuário, Barras-e-Perfis-Tabela-de-bolso-Gerdau.pdf, página física 3. SHA-256 do PDF: 3c7024ae143f4f57c010812eda8abd796e5b4a6cb599fe6616e644847ee72bc4. A transcrição integral em data/gerdau_equal_angles.json preserva a ordem original, valores impressos, precisão decimal, unidades, proveniência e lacunas; SHA-256 b412b9af03a073110627dfb055cde103cd86f9d2c699db122a45e1a2605c1a60.

O catálogo operacional contém 50 seções. As duas primeiras linhas da fonte, L15,880×2,50 e L19,050×2,50, não publicam Ag/ec e foram retiradas da seleção a pedido do usuário. Os IDs das demais linhas não foram renumerados. Os seletores mostram inicialmente abas ≥63,5 mm (2½ pol., chamada correntemente L64). As seções menores restantes continuam acessíveis pela opção de uso eventual; uma seção menor importada permanece visível. Nenhuma dimensão é arredondada para satisfazer um limite do modelo.

Ag e ec são publicados; raios de concordância, raio de ponta e face plana da ponta não são. rx/ry/rz são raios de giração, não raios do contorno. As propriedades métricas impressas prevalecem sobre conversões recalculadas das legendas em polegadas. L101,600×12,70 Gerdau tem Ag2419 mm²/ec30 mm: é outra identidade, distinta da ArcelorMittal L100×100×12, Ag2270/ec29, mantida exatamente para projetos legados.

Para 5 pol. × 7/16 pol. (linha 46), utiliza-se Ag26,96 cm² publicada, menor que a área inferida da massa. A massa publicada 23,52 kg/m permanece separada. Não se gera peso próprio automaticamente, nem se altera o estado de verificação por essa escolha resolvida. A transcrição original continua preservada.

Aço e geometria são independentes. Selecionar um fabricante não seleciona aço nem certifica fornecimento. Os limites de produto e espessura continuam aplicados ao aço escolhido.

## 1L soldada à chapa de nó: adaptação nominal

A nova rota Gerdau usa o modelo nominal de seção da NBR 8800:2024/Errata1:2025. Não reconstrói um contorno laminado real sem os raios publicados, nem afirma um limite geométrico exato para uma ponta arredondada microscópica. O desenho seccional identifica essa representação nominal.

Para aba b, espessura t, centroide ec e duas soldas longitudinais iguais de comprimento L:

- Calcanhar v=−b/2; ponta v=+b/2
- Fponta=N·ec/b; Fcalcanhar=N·(1−ec/b)
- Centroide projetado v=ec−b/2
- Ct=max(1−ec/L; 0,5), com piso Ac/Ag por simetria das abas iguais
- Pegada nominal v=[−b/2−s; −b/2; +b/2; +b/2+s]
- Faixa local entre b+2s e b+2L·tan30°, conservando o momento N·(ec−b/2)

As interseções com bordas reais da chapa, comprimentos/caminhos, extremos internos, contenção, sinais de tensão, momento da raiz e ações transmitidas ao W são recalculados. Ag vem da tabela, não de retângulos ideais. Tração bruta/efetiva e recomendação opcional de meia capacidade usam Ag/ec e aço efetivos.

A ruptura local da cantoneira usa o envelope nominal pela aba: Agv=Anv=tL, Ant=0, demanda N integral. R=min(0,60fu·tL; 0,60fy·tL)/1,35. Não há contribuição transversal nem margem livre creditada. No modelo nominal de transferência uniforme, o trecho parcial δ captura no máximo Nδ/L e contém a superfície nominal tδ, justificando o envelope. Não é chamado de fissura física exata.

Permanece a verificação separada do metal-base junto a cada filete, com sua parcela real de N: A=L·min(s,t) na cantoneira e A=L·min(s,tg) na chapa, usando fy/fu de cada material, γa1=1,10 e γa2=1,35. Permanecem todos os caminhos reais U/L da chapa, seções horizontais, faixa local, solda da raiz e região receptora W. A rota ArcelorMittal legada conserva seus caminhos arredondados e face plana publicada, sem substituição pelo modelo Gerdau.

## Filete e borda reforçada

s é a perna do triângulo inscrito no filete e a garganta efetiva especificada é a=s/√2, sem ganho por penetração ou direção. Deve ser obtida por procedimento, execução e inspeção. Raios desconhecidos não viram uma face plana nominal t. A antiga condição suficiente de encaixe na face plana ArcelorMittal não é uma restrição universal adicionada à NBR.

O mínimo usa a peça menos espessa. Na borda ordinária, o máximo é t para t<6,3 mm; para t≥6,3 mm é t−1,5 mm. Comprimento efetivo, sobreposição, término, contenção e domínio L/s≤100 continuam ativos.

No detalhe de borda reforçada, NBR6.2.6.2.2(b), a execução reforçada para obter a garganta integral deve estar explicitamente indicada no desenho e no Word. Esta versão limita s≤t e não aumenta resistência de material nem elimina o mínimo. É uma escolha de detalhamento, não uma confirmação de fabricação. L63,5×6,35 sobre chapa10 com s5 falha na borda ordinária (máximo4,85); o detalhe reforçado admite s5 e emite a instrução obrigatória de execução/inspeção.

Referências NBR: 5.2.2/5.2.5 (tração/Ct), 6.1.8.2 (idealização estática da cantoneira por uma aba), 6.2.2.2 (filete inscrito/garganta), 6.2.6.2 e Tabela11 (mínimos), 6.2.6.2.2(b) (borda reforçada), 6.5.5/6.5.6 (metal-base/cisalhamento/bloco). A geometria e os demais limites da chapa/W permanecem descritos em WELDED_ANGLE_GUSSET0926_METHOD.md, substituindo apenas as constantes da seção pela adaptação acima.

## Outras famílias de cantoneiras

R015, R016, R017 e 1L/2L axial compartilham o seletor Gerdau. Ele carrega b/t e, nas famílias axiais, Ag/ec (Ag do par=2·Ag da seção). Preserva o aço, os demais parâmetros e a opção manual. Raios internos exigidos para folgas/interferências nessas rotas precisam de valor positivo, fonte independente e declaração explícita; não são herdados de Souza ou de outra cantoneira.

A troca de catálogo não amplia o domínio mecânico existente de R015/R016/R017: seções exatas Gerdau não são arredondadas às antigas combinações qualificadas de b/t/gabarito. Pendências dessas rotas permanecem identificadas. Editar valores de uma identidade catalogada exige usar a opção manual, sem conservar uma falsa identidade Gerdau.

## Compatibilidade e exemplos

Projetos 0.9.26 da 1L soldada importam a identidade ArcelorMittal e o detalhe ordinário originais; não há migração aproximada para Gerdau. O arquivo atual registra 0.9.27, seleção exata e detalhe da borda. As outras famílias aceitam o conjunto original completo de campos ou o novo conjunto completo com identidade/proveniência, rejeitando campos desconhecidos ou metadados parciais. Importações inválidas permanecem atômicas.

Quatro novos JSON estão em examples/gerdau_welded_gusset0927_01.json a _04.json: L63,5×6,35 reforçada; L101,6×12,70; L203,2×19,05; e L50,8×4,76 de uso eventual. Desenhos e Word pré-gerados novos pertencem ao pacote complementar de exemplos; o APP permanece separado e limitado a menos de20MB. Os exemplos não são aprovações de fabricação, projeto global, estabilidade, fadiga, sismo ou implantação.
