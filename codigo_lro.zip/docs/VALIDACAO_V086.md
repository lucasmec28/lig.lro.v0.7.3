# Validação do checkpoint 0.8.6-dev

Data: 9 de outubro de 2026. Estado: fonte integrada de desenvolvimento, sem publicação ou deploy. A solicitação de concluir ambas as bases permanece aberta pelos limites de engenharia descritos em PLACAS_DE_BASE_V086.md.

## Escopo integrado

Famílias distintas de placa engastada Tipo 1 e rotulada Tipo 2, persistência e estados independentes, migração sem alteração de geometria ou apagamento de M, ancoragem complementar por modos ACI, estados alternativos reais de cortante, submodelo local de solda Tipo 2 em tração pura, preservação das arruelas superiores de 0.8.5 e simplificações de entrada sem presumir dados físicos.

## Evidência independente

- Tipo 2: 86 casos numéricos, cinco fixtures e nove projetos legados reais; 2.985 comparações aprovadas. Inclui sinais, limites C2/T2, cone, M imutável e migração sem vínculo inventado.
- Concreto: 122 asserções independentes dos kernels e 29 dos estados de força; 151 aprovadas. A auditoria distingue diagnóstico sem conclusão, modo calculado e aprovação da ancoragem completa. A rodada focada posterior ao congelamento desses módulos aprovou 144 testes de produção.
- Solda Tipo 2: 42 campos de fixtures Decimal, 26 comparações com produção e 25 condições independentes aprovados. A correção de tenacidade do metal de solda em CJP de seção espessa tracionada foi reexaminada.
- Os núcleos e os domínios desses ensaios não abrangem a solda geral pilar–placa sob N/M/V nem a aprovação da ligação completa.

## Execução agregada e rechecagem

A execução agregada de 823 testes terminou com 822 aprovados e uma expectativa antiga de teste reprovada: exigia que um projeto novo de BasePlate nascesse com vínculo unspecified. A família nova é explicitamente fixed; somente a ausência de intenção em arquivo legado deve permanecer unspecified. A expectativa foi atualizada sem mudar o comportamento de produção, já coberto pela auditoria de migração.

Depois dos ajustes de apresentação e dessa expectativa, a rechecagem focada de catálogo, defaults, componentes, núcleo existente e artefatos aprovou 110 testes. Uma última adição de referências bibliográficas foi coberta por dois testes de exportação aprovados. Não se somam essas contagens às 823, pois há repetição. O agregado não foi repetido integralmente após as mudanças estritamente editoriais; os registros mantêm esse histórico, em vez de declarar uma rodada única de 823 aprovações que não ocorreu.

As quatro regressões de simplificação de entrada também passaram, incluindo adoção separada de espaçamento/graute, preservação exata dos limites importados do bloco, edição explícita da centração e rascunhos ocultos por aplicabilidade. Fazem parte do conjunto agregado.

## Edições após o início do agregado

Não houve mudança de fórmula resistente, equilíbrio ou condição de domínio. Foram alterados:

- lro/base_component_report.py: quebra de equações longas para evitar corte e ambiguidade de notação.
- lro/base_plate_report.py: paginação sem página vazia, explicação Tipo 2 da Tabela 18, texto que reconhece os modos de ancoragem separados e referências dos novos componentes.
- lro/base_plate.py: somente o texto de um aviso, para distinguir os modos complementares calculáveis das pendências da ancoragem completa.
- lro/pinned_base_plate_drawing.py: unidade kgf nas reações de tração.
- tests/test_baseplate_details_artifacts.py: expectativa do vínculo inicial da família nova.
- tests/test_base_plate_catalog.py: asserção da unidade kgf no desenho de tração.

Os hashes numéricos auditados de concrete_components.py e concrete_force_states.py permaneceram idênticos aos da auditoria.

## Artefatos revisados

Dois projetos sintéticos reproduzíveis geraram Word, desenho PNG/SVG e PDF: Engastada_086 e Rotulada_086. Não são projetos reais nem exemplos de aprovação da base completa. O exemplo engastado reprova o estado alternativo governante; o rotulado atende aos componentes calculados, conservando as pendências do conjunto.

Foram inspecionadas as 21 páginas da memória engastada e as 20 páginas da rotulada. Após as últimas correções, as dez páginas alteradas foram reinspecionadas; as demais permaneceram idênticas por hash aos pixels revisados. Verificação adicional dos limites de texto do PDF não encontrou conteúdo fora da página nem páginas vazias. Equações permanecem editáveis em Word. As reações de tração Tipo 2 estão explicitamente em kgf.

As pastas autoritativas desta revisão são qa/Engastada_render_checked e qa/Rotulada_render_checked no workspace de validação, junto aos respectivos projetos e ao script de reprodução. Renderizações anteriores são intermediárias de revisão, não artefatos finais.

## Conclusão limitada

O checkpoint integra duas famílias de cálculo reais e os componentes suportados. Continuam abertos o campo geral de forças da solda pilar–placa compatível com placa flexível sob N/M/V, a transferência local completa entre peças, os detalhes não comprovados, o fendilhamento/armaduras/bloco e a classificação da rigidez/rotação. Os ensaios de software não substituem revisão por engenheiro responsável, os documentos normativos controladores ou as verificações fora do domínio declarado.
