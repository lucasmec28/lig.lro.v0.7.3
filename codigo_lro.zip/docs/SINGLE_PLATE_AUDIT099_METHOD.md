# Single plate: revisão delimitada 0.9.9 e fechamento da fonte P901

Data: 10 de outubro de 2026. Esta revisão trata somente da família existente Single plate. Não amplia famílias, não revisa placas de base e não certifica integralmente o procedimento complementar P901. Os esquemas JSON e as versões próprias dos demais componentes permanecem inalterados.

## Caminho resistente e fontes

Uma viga I perpendicular ao apoio, ligada por uma chapa à sua alma, uma ou duas colunas de furos-padrão alinhados e dois filetes verticais de oficina. O apoio pode ser a alma de outra viga ou a mesa de pilar alinhada à alma. Não se representa uma ligação à alma do pilar. N positivo é tração; V tem sinal. Compressão permanece fora do método.

A ABNT NBR 8800:2024, versão corrigida em 2025, governa as resistências. Os procedimentos complementares existentes AISC/P901 e SCI conservam seus mecanismos e adaptações declaradas. O Manual de Ligações Gerdau, 7ª edição, §5, é uma conferência independente do caminho resistente, sem importar coeficientes da NBR antiga. A ligação de Souza §10.1 é de cantoneiras duplas e não é usada como modelo desta chapa.

### Alma apoiada sem recorte: envoltória de corte

A linha `beam_v` reúne três resistências, todas sob |V|:

- Escoamento local: Agv,local = h_livre tw; Vy = 0,60 fy Agv,local / γa1.
- Instabilidade: Vb = Cv Vy, mantendo a altura livre e o modelo existente NBR 5.4.3.1, kv = 5,34, sem crédito de enrijecedor transversal.
- Ruptura líquida: Anv = (d − n dn) tw; Vu = 0,60 fu Anv / γa2. Aqui d é a altura total da viga; n é o número de linhas, com um furo por linha no plano vertical escolhido, mesmo com duas colunas alinhadas.

Adota-se VRd = min(Vy; Vb; Vu), γa1 = 1,10 e γa2 = 1,35. O desconto líquido dn é o diâmetro-padrão acrescido de 2 mm, salvo furação com broca. Furo real e diâmetro de desconto líquido permanecem diferentes quando o acréscimo é aplicável. A resistência e a fórmula usam o aço da viga apoiada.

NBR 6.5.1 e 6.5.5 requerem os caminhos locais bruto e líquido. Gerdau §5.4.1, p.98, define o plano líquido com H total, identificado na nomenclatura p.374. A área local de escoamento/instabilidade, baseada na altura livre, é conservadora e foi preservada; o relatório distingue expressamente as duas definições de área. Não existe uma segunda linha resumida `beam_buckling` repetindo esse ramo.

Contraexemplo independente: W 460 × 52,0, d = 450 mm, tw = 7,6 mm, sete linhas, dn = 22,6375 mm, fu = 450 MPa. Anv = 2.215,685 mm²; Vu = 443.137 N. Para V = ±450.000 N, V/Vu = 1,015487309794. A revisão deve registrar falha, sem arredondar o índice para aprovação. Os demais caminhos não substituem essa seção líquida.

Com recorte, `beam_v` conserva sua expressão bruta anterior. O corte líquido e a instabilidade da seção remanescente já estão em `cope_interaction`; não se acrescenta o plano líquido sem recorte sobre esse mecanismo.

### Bloco da alma recortada

NBR 6.5.6: R = min(0,60 fu Anv + Cts fu Ant; 0,60 fy Agv + Cts fu Ant)/γa2. Cts pertence ao caminho e ao ramo tracionado, não ao tipo de parafuso nem a todas as verificações de bloco.

No caminho L completo da alma recortada com duas colunas, o ramo solicitado por V usa Cts,V = 0,5 no termo de tração, conforme figura 16(c). A coluna única usa 1,0 conforme figura 16(b). A adaptação rotacionada de Rn para N mantém Cts,N = 1,0; a figura 16(c) não valida essa adaptação. Caminhos parciais de coluna externa e os outros caminhos existentes permanecem separados e não recebem a alteração indiscriminadamente. O relatório mostra orientação, coeficiente, áreas e borda governante. No recorte duplo, as duas bordas livres são avaliadas; a envoltória dos dois sinais de V permanece declarada.

### Bloco L completo da chapa: correção após recuperação do P901

O P901 II.A-19A, p.IIA-209/PDF749, e II.A-19B, p.IIA-224/PDF764, identificam tensão não uniforme no ligamento terminal do bloco L completo de duas colunas sob V e adotam Ubs = 0,5. A condição física mapeia para Cts = 0,5 da NBR 8800, 6.5.6; os coeficientes brasileiros e γa2 = 1,35 permanecem. Assim, somente Bv da chapa com duas colunas passa a usar Cts,V = 0,5. Bv de coluna única, o L rotacionado sob N (Bn), o U axial (Bu) e os caminhos parciais continuam com 1,0. O caminho da alma recortada já corrigido em 0.9.9 não é alterado.

Para o primeiro exemplo do app alterado apenas para duas colunas, Bv passa de 337.593,634 N a 248.171,817 N; Bn permanece 387.247,106 N. A interação do L completo passa de 0,01763146 a 0,03225910, ainda abaixo dos demais caminhos. Em 66 geometrias válidas da comparação delimitada, não foi demonstrada aprovação global insegura adicional: todas já falhavam em outros itens. Em 40 delas, os dois caminhos parciais da chapa ainda atendiam enquanto o L completo corrigido falhava, mostrando que os parciais não substituem universalmente o caminho completo.

## Ações, combinações e apresentação

A entrada é preservada com sinal e precisão em N, mm e MPa; os valores usuais são também apresentados em kgf e kgf·m. O mínimo de 45 kN da NBR 6.1.5.2 é um caso adicional na mesma direção do vetor informado. Ele não substitui a entrada. Zero não define direção. N negativo não é convertido para zero ou tração.

M = |V|e + |N eN| é uma envoltória local. As verificações de grupo de parafusos e solda com momento completo são limites conservadores; não se soma duas vezes o momento para inventar uma condição física simultânea. SCI P358 §5.4, p.111, explicita os limites de apoio flexível/rígido. Mantém-se a contenção eficaz da viga apoiada como hipótese fixa fornecida pelo projeto, com My = 0.

O resumo mantém as duas interações da chapa, os caminhos físicos de bloco completos e parciais, os parafusos, contato em ambas as peças, alma apoiada, metal da solda, metal-base adjacente e componentes do apoio. Somente as seis capacidades escalares da chapa N/V/M são retiradas do resumo. Elas continuam no desenvolvimento, inclusive no Word compacto, com fórmulas e substituições. Axial completo da alma e blocos U completos ficam N/A se N = 0; caminhos parciais ainda solicitados pelo momento continuam ativos.

### Conclusões independentes

- Falha resistente real: `NÃO ATENDE`, com a maior falha resistente visível mesmo quando coexistem limites de método ou dados faltantes.
- Somente hierarquia/condição de método falha: `CONDIÇÕES DO MÉTODO NÃO SATISFEITAS`; esses índices não são utilização resistente sob a força aplicada.
- Detalhamento normativo não atendido: `NÃO ATENDE AO DETALHAMENTO`; cálculo disponível não aprova a fabricação.
- Dado necessário ausente: `DADOS NECESSÁRIOS AUSENTES`.
- Compressão fora do método, extrapolação, material fora do domínio e falha numérica têm rótulos específicos. Nenhum vira resultado verde por alterar a entrada.
- Interação fora do plano da alma do apoio sob N+V ou N excêntrico: mecanismo local não calculado, junto à conclusão. Se todos os caminhos incluídos atendem, o estado é `VERIFICAÇÕES LOCAIS ATENDEM · ESCOPO INCOMPLETO`.
- Responsabilidades externas: membros globais, sistema de contenção, integridade, ações e situações não modeladas. Essas responsabilidades não absorvem nem ocultam um mecanismo local que falta.

## Qualificação do método complementar

O PDF original P901-23W foi recuperado e conferido: Companion v16.0, Volume 1, Design Examples (2023), 1.054 páginas, 19.699.680 bytes, SHA256 ec25b52e1d7b6b9ec9e5eaccc27452153208784d7d715908daa2595dd8f92423. A antiga pendência de acesso está encerrada. A conferência abrangeu as páginas, equações e figuras dos exemplos relevantes; não é uma certificação integral de todas as adaptações do app.

II.A-17B, IIA-180–193/PDF720–733, trata expressamente de N+V na mesa de coluna. II.A-19A, IIA-205–212/PDF745–752, e II.A-19B, IIA-213–229/PDF753–769, tratam de detalhes estendidos de duas colunas, respectivamente sob V e N+V, com apoio na alma de coluna. Seus mecanismos da chapa/parafusos, equações de interação e hierarquia explícita são compatíveis com a arquitetura declarada; as resistências NBR são substituídas explicitamente. Os exemplos confirmam a contenção longitudinal/contra rotação no eixo de menor inércia que fundamenta My = 0. A laje é um meio dessa contenção no exemplo 19B; a efetividade de uma contenção equivalente continua sendo condição do projeto.

Permanece a confirmar somente o domínio completo da dispensa automática de ductilidade adotada, conforme a Tabela 10-9 e sua discussão no Manual. O exemplo 17A, IIA-174–175/PDF714–715, demonstra o atalho para quatro linhas, furos-padrão, uma das espessuras dentro do limite e ambas as bordas horizontais de pelo menos 2db. Os exemplos 19A/B exercitam a hierarquia explícita; não reproduzem toda a divisão de linhas, faixas de material e geometrias elegíveis da tabela, nem qualificam uma dispensa geral para duas colunas ou detalhes estendidos. Essa ressalva não cria uma proibição: mantêm-se o atalho existente e as capacidades, sem inventar limite universal de a, veto por perfil, exigência de FEA ou justificativa autoral para cálculos normativos usuais incorporados.

As diferenças declaradas permanecem: e até o centroide das colunas na envoltória local, em vez de copiar indiscriminadamente e=a/2 ou a dos exemplos; acréscimo |N eN| e Cb=1 para N excêntrico; adaptações lineares N/SCI/recortes e faixa conectada conservadora da alma. Os exemplos em alma de coluna não completam a interação fora do plano da alma de uma VIGA de apoio sob N+V; essa exclusão local continua visível. O PDF recuperado tampouco elimina a ruptura líquida NBR já reparada, estende o domínio de compressão do app ou concede crédito resistente aos reforços de detalhamento.

Fontes complementares verificadas na auditoria: SCI/BCSA P358 (2014), §5.4; Muir e Hewitt (2009), Engineering Journal 46(2), p.67–80, especialmente p.71; Muir e Thornton (2011), Engineering Journal 48(2), p.141–150. As adaptações lineares sob N e o modelo combinado existente continuam identificados como implementação, não como equações NBR.

## Geometria, estado da interface e artefatos

Importação aceita deve preservar a representação e os valores de engenharia; entrada inválida deve ser recusada atomicamente, sem substituir o projeto aberto. Nome de catálogo não autoriza sobrescrever dimensões diferentes. Valores de controles ocultos são rascunhos persistentes, incluindo passo horizontal, recortes, desnível, espessura real e distância livre do apoio. Os resultados são recalculados a partir do mesmo estado; mudanças dependentes invalidam Word obsoleto.

JSON, Word e desenho usam a mesma topologia e objeto de entrada. Furos físicos são n × número de colunas; a contagem não se confunde com n furos em um plano líquido vertical. O desenho identifica separadamente comprimento × profundidade superior e inferior quando ambos os recortes existem.

Complemento entre mesas e enrijecedor oposto continuam selecionáveis em viga–viga apenas como detalhamento. Não recebem área resistente, espessura equivalente, solda resistente adicional, rigidez ou redistribuição. Mudar contorno resistente exige atualizar os dados e recalcular. Referências antigas à retirada da seleção são históricas e não descrevem a interface atual.

## Limites da verificação desta revisão

A aceitação é delimitada a Single plate: testes independentes de resistência, testes do fluxo Streamlit e coerência estrutural/representativa dos artefatos. AppTest não comprova aparência no navegador. A indisponibilidade de Chromium por restrição de sockets permanece uma limitação de inspeção visual de browser; não foi contornada. Renderizações DOCX/SVG, quando concluídas, comprovam somente os artefatos e as configurações registradas. Não se afirma suíte integral, auditoria das outras famílias, liberação de pacote, publicação ou implantação a partir destes testes.
