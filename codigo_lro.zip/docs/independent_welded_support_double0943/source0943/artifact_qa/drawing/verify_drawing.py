"""Reproducible current-input/topology/export checks for the independent 2L drawing.

Run with Python from any directory. Outputs stay beside this script.
"""
import copy
from dataclasses import asdict, replace
import hashlib
import json
import os
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parents[1]
os.environ.setdefault('MPLCONFIGDIR', '/tmp/lro-2l-drawing-mpl')
sys.path.insert(0, str(SOURCE))
import matplotlib.pyplot as plt
from lro.welded_support_double_angle import presets, evaluate
from lro.welded_support_double_angle_drawing import (
    image_bytes, drawing_svg, _figure, _approved, validated_result, drawing,
)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    c = next(iter(presets().values()))
    good = evaluate(c)
    before = asdict(c)
    raw = copy.deepcopy(good)
    assert _approved(good)
    for key, value in [('global_pass', False), ('status', 'INVALID_INPUT'),
                       ('checks', []), ('summary', {}), ('geometry', {})]:
        forged = copy.deepcopy(good)
        forged[key] = value
        assert not _approved(forged)
    for value in (None, True, {}, {'geometry': None}):
        assert not _approved(value)
    cases = {
        'nominal': c,
        'high_shear': replace(c, V=500000),
        'negative_V': replace(c, V=-100000),
        'external_moment': replace(c, M=1),
        'zero_root': replace(c, root_radius=0),
        'wrong_angle_count': replace(c, angle_count=1),
        'nonsymmetric': replace(c, symmetric=False),
        'wrong_weld_layout': replace(c, weld_layout='toe_bottom_short_top'),
        'cope': replace(c, cope='top'),
        'wrong_assembly': replace(c, assembly='both_shop_welded'),
        'negative_dimension': replace(c, t=-1),
        'nonfinite': replace(c, beam_leg=float('nan')),
        'boolean_dimension': replace(c, db=True),
        'bad_profile': replace(c, beam=None),
        'scale': replace(c, beam_leg=1e300),
        'null': None,
    }
    diagnostic = {
        'wrong_angle_count', 'nonsymmetric', 'wrong_weld_layout', 'cope',
        'wrong_assembly', 'negative_dimension', 'nonfinite',
        'boolean_dimension', 'bad_profile', 'scale', 'null',
    }
    outcomes = []
    for name, current in cases.items():
        fig = _figure(current, good)
        gids = {artist.get_gid(): artist for artist in fig.findobj() if artist.get_gid()}
        actual = validated_result(current, good)
        assert gids['approval_status'].get_text() == (
            'ATENDIMENTO LOCAL' if _approved(actual) else 'SEM APROVAÇÃO GLOBAL'), name
        if name != 'nominal':
            assert not _approved(actual), name
        if name in diagnostic:
            assert 'diagnostic_only' in gids and len(fig.axes) == 0, name
        fig.canvas.draw()
        if name in ('nominal', 'wrong_weld_layout', 'negative_V', 'nonfinite'):
            fig.savefig(HERE/(name+'.png'), dpi=170)
        outcomes.append({'case': name, 'status': actual['status'],
                         'diagnostic_only': 'diagnostic_only' in gids, 'passed': True})
        plt.close(fig)
    assert asdict(c) == before and good == raw
    fig = drawing(c, good)
    gids = {artist.get_gid(): artist for artist in fig.findobj() if artist.get_gid()}
    assert len(fig.axes) == 4
    left = gids['shop_physical_angle_L_plan'].get_path().vertices
    right = gids['field_physical_angle_L_plan'].get_path().vertices
    assert (left[:, 0] == right[:, 0]).all() and (left[:, 1] == -right[:, 1]).all()
    for side, sign in [('shop', -1), ('field', 1)]:
        assert gids[side+'_angle_beam_leg_grip'].get_width() == c.t
        toe = gids[side+'_weld_vertical_toe_front']
        assert list(toe.get_xdata()) == [sign*(c.beam.tw/2+c.support_leg)]*2
        assert abs(toe.get_ydata()[1]-toe.get_ydata()[0]) == c.length
        ret = gids[side+'_weld_short_top_return_uncredited_front']
        assert abs(ret.get_xdata()[1]-ret.get_xdata()[0]) == c.top_return
        shear = gids[side+'_shear_plane_grip']
        assert list(shear.get_xdata()) == [sign*c.beam.tw/2]*2
    assert gids['single_beam_web_grip'].get_width() == c.beam.tw
    assert gids['common_three_plate_hole_grip'].get_width() == c.beam.tw+2*c.t
    assert len([key for key in gids if key.startswith('common_web_hole_elevation_')]) == c.web_rows
    assert not any('weld_bottom' in key or 'weld_heel' in key or 'support_bolt' in key for key in gids)
    notes = gids['physical_topology_notes'].get_text()
    assert 'raio=20.00 mm' in notes and 'folga de fabricação=3.00 mm' in notes
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    labels = [gids['dimension_label_shop_support_leg'], gids['dimension_label_field_support_leg']]
    assert not labels[0].get_window_extent(renderer).overlaps(labels[1].get_window_extent(renderer))
    assert gids['physical_topology_notes'].get_window_extent(renderer).y0 > gids['scope_note'].get_window_extent(renderer).y1
    plt.close(fig)
    svg = drawing_svg(c, {'status': 'INVALID_INPUT', 'global_pass': False})
    ET.fromstring(svg)
    assert 'ATENDIMENTO LOCAL' in svg and '100.00' in svg and '25.44' in svg
    (HERE/'nominal.svg').write_text(svg, encoding='utf-8')
    for fmt in ('png', 'pdf'):
        data = image_bytes(c, fmt=fmt)
        assert len(data) > 1000
        (HERE/('nominal.'+fmt)).write_bytes(data)
    module = SOURCE/'lro/welded_support_double_angle_drawing.py'
    outputs = ['nominal.png', 'nominal.svg', 'nominal.pdf', 'wrong_weld_layout.png', 'negative_V.png', 'nonfinite.png']
    receipt = {
        'result': 'PASS',
        'source_file': str(module.relative_to(SOURCE)),
        'source_sha256': sha(module),
        'test_script_sha256': sha(Path(__file__)),
        'nominal_load_N': c.V,
        'nominal_status': good['status'],
        'input_scenarios': outcomes,
        'assertions': [
            'Current input reevaluated despite stale or forged result',
            'Approval requires all local gates and exact 2L topology',
            'Input and supplied result unmodified',
            'Two independent mirrored physical L plan paths',
            'One web plus two angle grip layers',
            'Two vertical toe welds and two uncredited short top returns',
            'No bottom/heel weld or support-bolt artists',
            'Common web holes and shank; two shear planes',
            'Field welding radius and fabrication clearance declared',
            'Front dimension labels and footer bands nonoverlapping',
            'PNG, SVG and PDF export successful',
        ],
        'pixel_review': 'Nominal, wrong weld topology, and reverse load PNGs visually inspected; two angles, open lower/heel borders, uncredited returns, uncut beam, shop/field distinction, and unclipped labels confirmed.',
        'artifacts': {filename: {'sha256': sha(HERE/filename), 'bytes': (HERE/filename).stat().st_size} for filename in outputs},
    }
    (HERE/'verification_receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'result': receipt['result'], 'input_scenarios': len(outcomes),
                      'source_sha256': receipt['source_sha256'],
                      'receipt': str(HERE/'verification_receipt.json')}, indent=2))


if __name__ == '__main__':
    main()
