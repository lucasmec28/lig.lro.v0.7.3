"""Read-only engine exercise against independent formulae and adverse inputs."""
from pathlib import Path
from dataclasses import replace
import math, sys, json, random, hashlib
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'source0943'))
from lro.welded_support_double_angle import evaluate,presets,hardware_envelope
from lro.models import profiles
c=next(iter(presets().values()))
source=ROOT/'source0943/lro/welded_support_double_angle.py'
source_hash=hashlib.sha256(source.read_bytes()).hexdigest()
checks=[]
def assert_test(name,condition,details=None):
    if not condition: raise AssertionError((name,details))
    checks.append({'name':name,'passed':True,'details':details})
def near(a,b): return math.isclose(a,b,rel_tol=1e-10,abs_tol=1e-6)
# Own material, hole and diameter inputs: do not import production helpers/tables.
materials={'ASTM A36':(250.,400.),'ASTM A572 Gr.50':(345.,450.),'ASTM A572 Gr.55':(380.,485.),'ASTM A992':(345.,450.)}
def oracle(x):
    fy,fu=materials[x.angle_steel];bfy,bfu=materials[x.beam_steel];sfy,sfu=materials[x.support_steel]
    H,t,b=x.length,x.t,x.support_leg;n=x.web_rows;d=x.db;dh=x.hole_diameter
    dn=dh+(0 if x.drilled else 2) # cases use exact standard round maxima
    q=math.sqrt(1/H**2+(6*b/H**2)**2)
    capacities={'weld_vertical_each':2*(.6*485*x.weld_leg/math.sqrt(2)/1.35)/q,
      'angle_weld_base_yield':2*fy*t/(math.sqrt(3)*1.10*q),
      'angle_weld_base_rupture':2*.6*fu*t/(1.35*q),
      'column_weld_base_yield':2*sfy*x.support.tf/(math.sqrt(3)*1.10*q),
      'column_weld_base_rupture':2*.6*sfu*x.support.tf/(1.35*q),
      'support_leg_elastic_each':2*fy/1.10/math.sqrt((6*b/(t*H**2))**2+3*(1.5/(t*H))**2),
      'angle_beam_gross':2*.6*fy*H*t/1.10,'angle_beam_net':2*.6*fu*(H-n*dn)*t/1.35,
      'angle_support_gross':2*.6*fy*H*t/1.10,'angle_support_net':2*.6*fu*H*t/1.35}
    grip=x.beam.tw+2*t;alpha=.56 if x.web_threads_excluded else .45;fub=1040 if x.bolt.endswith('A490') else 830
    rb=alpha*math.pi*d*d/4*fub/1.35*max(0,1-.01*max(0,grip-5*d)/1.5)
    capacities['bolts_double_shear']=2*n*rb
    end=H-x.web_end_top-(n-1)*x.web_pitch
    ra=[];rw=[]
    for i in range(n):
        lc=end-dh/2 if i==n-1 else x.web_pitch-dh
        ra.append(min(1.2*lc,2.4*d)*t*fu/1.35)
        rw.append((2.4*d if i==0 else min(1.2*(x.web_pitch-dh),2.4*d))*x.beam.tw*bfu/1.35)
        capacities['angle_bearing_'+str(i+1)]=2*n*ra[-1]
        capacities['web_bearing_'+str(i+1)]=n*rw[-1]
    capacities['angle_bearing_sum']=2*sum(ra)
    capacities['web_bearing_sum']=sum(rw)
    capacities['transfer_sum']=sum(min(2*rb,2*a,w) for a,w in zip(ra,rw))
    for k in range(1,n+1):
        Lv=end+(k-1)*x.web_pitch
        Agv=Lv*t;Anv=(Lv-(k-.5)*dn)*t;Ant=(x.beam_leg-x.beam_gauge-dn/2)*t
        capacities['angle_block_'+str(k)]=(min(.6*fu*Anv,.6*fy*Agv)+fu*Ant)/1.35*2*n/k
    lam=x.beam.clear/x.beam.tw;lp=1.1*math.sqrt(5.34*200000/bfy);lr=1.37*math.sqrt(5.34*200000/bfy)
    Cv=1 if lam<=lp else lp/lam if lam<=lr else 1.24*(lp/lam)**2
    capacities['beam_shear']=.6*bfy*x.beam.d*x.beam.tw*Cv/1.10
    return capacities

def compare(x,label):
    r=evaluate(x)
    assert_test(label+':engine_has_checks',bool(r['checks']),r['status'])
    exp=oracle(x);actual={v['id']:v['equivalent_total_V_capacity_N'] for v in r['checks']}
    assert_test(label+':all_capacities_match',actual.keys()==exp.keys() and all(near(actual[k],v) for k,v in exp.items()),{'count':len(exp),'max_relative_error':max(abs(actual[k]/v-1) for k,v in exp.items())})
    assert_test(label+':minimum_and_actual_actions',r['load_model']['Vd_N']==max(x.V,45000) and r['load_model']['each_angle_force_N']==max(x.V,45000)/2 and all(near(z['actual_demand_N'],x.V*z['demand_fraction_of_total_V']) for z in r['checks']))
    assert_test(label+':symmetric_weld_equilibrium',near(r['welds']['paired_equilibrium']['force_y_N'],-x.V) and near(r['welds']['paired_equilibrium']['Mx_origin_Nmm'],0))
    for item in r['welds']['actual_per_angle']:
        g=item['group'];s=item['side']
        assert_test(label+':signed_group_'+str(s),near(g['moment_about_centroid_Nmm'],s*x.V/2*x.support_leg) and near(item['actual_Mx_origin_Nmm'],s*x.V/2*x.beam.tw/2))
    return r
r=compare(c,'preset')
assert_test('preset_capacity_independent',near(r['summary']['equivalent_total_V_capacity_N'],134007.991278356))
for load in [1,44999.999,45000,45000.001,100000,134007.991278,134007.991279,500000]:
    result=compare(replace(c,V=load),'load_'+str(load))
    assert_test('load_status_'+str(load),result['global_pass']==(load<=134007.991278356))
for key,value in [('web_threads_excluded',True),('drilled',True),('bolt','ASTM F3125 A490'),('angle_steel','ASTM A36'),('support_steel','ASTM A36'),('beam_steel','ASTM A36')]:compare(replace(c,**{key:value}),key+'_'+str(value))
rng=random.Random(4043)
for i in range(100):
    t=rng.uniform(9.4,9.525);H=rng.uniform(235,280);b=rng.uniform(85,100);p=rng.uniform(55,62)
    x=replace(c,length=H,angle_top=(c.beam.d-H)/2,t=t,support_leg=b,web_pitch=p,V=rng.uniform(1,450000))
    compare(x,'random_'+str(i))
# Full 2-to-8-row conventional domain, different real W members.
for n,H,pitch in [(2,200,140),(3,220,80),(4,240,60),(5,300,60),(6,400,68),(7,440,380/6),(8,480,60)]:
    beam=c.beam if n<=5 else profiles()['W 610 x 82,0']
    x=replace(c,beam=beam,length=H,angle_top=(beam.d-H)/2,web_rows=n,web_pitch=pitch,V=45000)
    z=compare(x,'rows_'+str(n))
    assert_test('row_domain_pass_'+str(n),z['global_pass'],z['issues'])
# Numerical integration of the prescribed line tractions, independent of kernel J.
# F=-1, toe coordinate z=0, load at z=b, moment -b. Integrate with Simpson.
for H,b in [(240,101.6),(480,85),(200,100),(596.9,101.6)]:
    h=H/1000
    samples=[j*h for j in range(1001)]
    qy=-1/H
    def integ(fun):
        return h/3*(fun(0)+fun(H)+sum((4 if j%2 else 2)*fun(y) for j,y in enumerate(samples[1:-1],1)))
    qz=lambda y:12*b*(y-H/2)/H**3
    for u in [0,.125*b,.5*b,.875*b,b]:
        N=integ(qz);V=integ(lambda y:qy);B=integ(lambda y:-u*qy-(y-H/2)*qz(y))
        assert_test('section_integration_'+str((H,b,u)),near(N,0) and near(V,-1) and near(B,-(b-u)),{'N':N,'V':V,'B':B})
# Guarded actions and topology remain preserved rather than coerced.
for key,value in [('kind','girder_web'),('V',0),('V',-100000),('N',1),('M',1),('torsion',1),('angle_count',1),('symmetric',False),('assembly','both_shop_welded'),('web_columns',2),('web_rows',9),('beam_gauge',76.20000001),('cope','bottom'),('support_continuous',False),('static',False),('normal_combination',False),('no_slip_required',True),('weld_layout','toe_bottom_short_top'),('weld_process','GMAW'),('electrode_fuw',490),('exposure','unknown'),('t',9.526),('root_radius',0),('tool_radius',10),('weld_tool_radius',56),('angle_top',20),('gap',0),('root_radius',60),('hole_diameter',30),('top_return',25),('top_return',9),('weld_leg',4)]:
    z=evaluate(replace(c,**{key:value}));assert_test('guard_'+key+'_'+str(value),not z['global_pass'] and z['inputs'][key]==value,z['status'])
# Exact field-access and conventional gauge boundaries.
for wr,passes in [(54.999999,True),(55.,True),(55.000001,False)]:assert_test('weld_tool_boundary_'+str(wr),evaluate(replace(c,weld_tool_radius=wr))['global_pass']==passes)
for gauge,scope in [(76.2,False),(76.200001,True)]:
    z=evaluate(replace(c,angle_steel='ASTM A36',beam_leg=110,beam_gauge=gauge))
    assert_test('gauge_scope_boundary_'+str(gauge),(z['status']=='OUTSIDE_SUPPORTED_SCOPE')==scope,z['status'])
# Independent hardware floors for all 13 supported diameters.
metric={16:(31.18,34),20:(39.26,42),22:(41.57,44),24:(47.34,50),27:(53.12,56),30:(57.74,60)}
inch={12.7:(1.010,1.063),15.875:(1.227,1.313),19.05:(1.443,1.469),22.225:(1.660,1.750),25.4:(1.876,2),28.575:(2.093,2.25),31.75:(2.309,2.5)}
holes={12.7:14.2875,15.875:17.4625,19.05:20.6375,22.225:23.8125,25.4:28.575,28.575:31.75,31.75:34.925,16:18,20:22,22:24,24:27,27:30,30:33}
for d in holes:
    a,b=metric[d] if d in metric else (inch[d][0]*25.4,(inch[d][1]+.0313)*25.4)
    floor=max(a,b)/2
    assert_test('hardware_numeric_'+str(d),near(hardware_envelope(d)['minimum_hardware_radius_mm'],floor))
    for delta,want in [(-1e-7,False),(0,True),(1e-7,True)]:
        z=evaluate(replace(c,db=d,hole_diameter=holes[d],tool_radius=floor+delta))
        row=next(a for a in z['geometry']['checks'] if a['id']=='tool_physical')
        assert_test('hardware_boundary_'+str(d)+'_'+str(delta),row['passed']==want and near(z['geometry']['hardware_envelope']['declared_hardware_tool_radius_mm'],floor+delta))
# Receiver and web weakening should never vanish behind paired-angle factors.
for role,field,value in [('support','tf',3),('beam','tw',3),('beam','tw',1)]:
    x=replace(c,**{role:replace(getattr(c,role),**{field:value})})
    z=compare(x,role+'_'+field+'_'+str(value))
    assert_test(role+'_'+field+'_capacity_lowers_'+str(value),z['summary']['equivalent_total_V_capacity_N']<r['summary']['equivalent_total_V_capacity_N'] or value==3 and role=='beam')
# Published-source arithmetic independent of the engine, not a fabricated matching target.
L,b,w=23.5,4.,.3125
qrd=.75*.6*70*w/math.sqrt(2)
benchmark={'AISC_tabulated_weld_kip':.75*3.61*5*L,'AISC_elastic_no_contact_weld_kip':2*qrd*L/math.sqrt(1+36*b*b/(L*L)), 'AISC_eight_bolt_double_shear_kip':8*2*.75*54*math.pi*.75**2/4,'AISC_support_minimum_in':3.09*5/65}
assert_test('source_example_values',near(benchmark['AISC_tabulated_weld_kip'],318.13125) and 228<benchmark['AISC_elastic_no_contact_weld_kip']<229 and 286<benchmark['AISC_eight_bolt_double_shear_kip']<287)
assert_test('engine_source_unchanged_during_run',source_hash==hashlib.sha256(source.read_bytes()).hexdigest())
output={'source_sha256':source_hash,'check_count':len(checks),'all_passed':True,'published_benchmark':benchmark,'preset':r['summary'],'checks':checks}
(ROOT/'independent_review/ENGINE_REVIEW.json').write_text(json.dumps(output,indent=2,ensure_ascii=False))
print(json.dumps({k:v for k,v in output.items() if k!='checks'},indent=2))
