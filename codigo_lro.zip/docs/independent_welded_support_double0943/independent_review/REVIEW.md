# Revisão mecânica independente da candidata 2L

13/10/2026. Parecer limitado ao estado final local. Não é GO de release, projeto de fabricação, verificação da fase provisória nem autorização para retirar o içamento.

## Resultado

**Método e motor aceitos dentro do domínio estreito documentado em `../METHOD_CONTRACT.md`.** Não foi encontrado defeito resistente que exija alterar o motor atual. A aprovação não se estende a outros receptores, V invertido, ações externas N/M/T, recortes, solda no talão/inferior, ligação rígida ou catálogo ilimitado.

O caminho de carga local está fechado na idealização convencional: uma alma apoiada → um grupo físico de parafusos em corte duplo → duas abas perfuradas com V/2 cada → duas abas no apoio → dois grupos de solda excêntrica independentes → metal-base da mesma mesa contínua do pilar. Não se transforma a simetria em licença para eliminar a excentricidade de cada solda; não se duplica a alma ou a espessura do pilar.

Motor revisto: `source0943/lro/welded_support_double_angle.py`, SHA256 `ca4ab82fbc6134f5b36bd6558c65e51e2fa5f1f7d674530a8a4bf2c0b26ecb81`. As fontes0.9.41/0.9.42 e a candidata1L não foram alteradas. O script de revisão importa o motor apenas para obter os resultados confrontados; suas expressões esperadas não usam as primitivas resistentes da aplicação.

## Fontes confrontadas

- Companion AISC v16, II.A-2A, IIA-40–49/PDF580–589: texto local completo das páginas e inspeção visual da figura40. Topologia, oito parafusos, duas cantoneiras, alma única, soldasB, retorno curto e recorte inferior de montagem foram confirmados. O recorte não é ignorado: a sequência de montagem distinta está explicitada no contrato atual. Fonte oficial: https://www.aisc.org/media/kybevlwy/first-semester-design-examples-v160.pdf .
- AISC Steel Interchange, fevereiro2016: confirmado no texto oficial indexado o domínio de uma linha vertical, furos padrão/curtos apropriados e gabarito face do apoio–parafuso≤3in. A fonte também adverte que a omissão convencional local não elimina os momentos distribuídos no sistema. https://www.aisc.org/globalassets/modern-steel/archives/2016/02/si.pdf .
- AISC Steel Interchange, dezembro2023: confirmado no texto oficial indexado o uso histórico de elasticidade com contato e a mudança da16ªedição paraICR. O motor adota, separadamente, elasticidade sem crédito desse contato ou ganho direcional. https://www.aisc.org/globalassets/modern-steel/archives/2023/december2023.pdf .
- AISC Steelwise, fevereiro2008, matriz de estados-limite: o ramo soldado ao apoio inclui soldas excêntricas, elementos de ligação, contato na alma e ruptura local do receptor junto à solda. Os mecanismos de alma associados a recortes não devem ser inventados numa alma sem recorte. Essa matriz histórica não substitui a alteração de método da16ªedição. https://www.aisc.org/globalassets/modern-steel/steelwise/022008_30774_steelwise.pdf .
- NBR8800:2024/Errata1:2025 fornecida: os componentes existentes, fatores e limites foram confrontados com os extratos disponíveis da revisão1L e com o contrato. Tabela11 usa a parte menos espessa; o limite t−1,5mm admite o detalhe explícito de borda reforçada; o retorno flexível é limitado a4w. Não se transportam coeficientes AISC para a base NBR.

As consultas oficiais acima tiveram conteúdo indexado disponível; os downloads diretos que retornaram403 não foram apresentados como PDFs visualmente inspecionados. O Companion local foi inspecionado diretamente.

## Verificação independente e números

`check_engine.py` e `ENGINE_REVIEW.json`: **880 asserções aprovadas**, fonte mecânica inalterada durante a execução.

- Todos os27 resultados resistentes do preset e cada resultado de100 geometrias variadas confrontados com expressões independentes, materiais/fatores explícitos.
- Casos admissíveis para2–8parafusos com perfisW reais; variações de rosca, furação, A325/A490 e materiais de cada componente.
- Força mínima45kN aplicada uma única vez; demanda real preservada; V/2 por solda/cantoneira; V/n na única alma; V/(2n) no contato de cada cantoneira.
- Cada solda equilibra sua força e momento local. Os momentos globais laterais do par cancelam. Integração numérica independente das trações confirma N(u)=0, V(u)=F e B(u)=F(b−u), inclusiveB=0 no talão.
- Verificação por furo e somas em série usam min(2Rv;2Rb,L;Rb,alma). A cantoneira é carregada para baixo; a alma, para cima. Somente o furo superior da alma contínua não tem próximo furo/borda livre no sentido carregado. Prefixos de bloco da cantoneira partem da borda inferior.
- V≤0, N/M/T, assimetria, outro receptor/detalhe, recorte, falta de continuidade, atrito requerido, raio zero, acesso e geometria insuficientes impedem aprovação sem apagar a entrada.
- Fronteiras exatas de e76,2mm, equipamento de soldagem, e todos os13pisos físicos de cabeça/porca/arruela: imediatamente abaixo, no limite e acima. O envelope informado maior não é reduzido.

Preset W410×38,8/W310×97,0;2L101,6×101,6×9,52;H240;4M20p60;g65;filete5: capacidade independente **134,007991kN**, governada pelas soldas excêntricas. EmV100kN, utilização0,746224. V500kN falha. A redução sintética de tf do receptor para3mm torna o escoamento local do receptor governante, capacidade95,522022kN, reprovando100kN. A redução de tw não é compensada por uma segunda alma: contato/cortante da alma passam a controlar e reprovar.

Fonte AISC, mesma geometria publicada: soldaICR0,75×3,61×5×23,5=**318,13125kip**; oito parafusos em corte duplo=**286,277631kip**; elasticidade planar sem contato=**228,880412kip**. Espessura mínima americana3,09×5/65=0,237692in. As diferenças para números arredondados da fonte e entreICR/elasticidade são mantidas; não houve calibração. Esses números da fonte são referências separadas, não a resistência NBR do preset.

## Fechamento de geometria, abas e receptor

O desenho atual foi gerado em leitura do motor e inspecionado (`preset_geometry.png`). As quatro vistas mantêm duas peças, uma alma, dois planos de corte, duas soldas na mesa, retorno curto não participante, raízes e ausência de soldas inferior/no talão. Não foi identificado conflito entre desenho e modelo físico.

Para o preset: folgas verticais às raízes59 e58mm, superiores ao envelope declarado20+3mm; folga lateral da solda à borda da mesa47,7mm; pega25,44mm; envelope mínimo físicoM20=21mm e declarado22mm. O raio informado10mm é preservado. Esses valores provam o encaixe do modelo declarado, não certificam a ferramenta ou o raio de uma peça real.

Uma cantoneira pré-fixada deixa o outro lado da alma aberto; a segunda é colocada após a viga. Portanto a mesa da viga não precisa atravessar um encaixe bilateral fechado. Isso fecha a diferença geométrica de montagem para o detalhe sem recorte. A responsabilidade por acesso externo, equipamento real e execução fica expressa. Nenhuma capacidade da fase de uma cantoneira/um parafuso é inferida.

A aba no apoio possui envelope elástico explícito deV/M, além de corte e metal-base. Os filtros de espessura/b/t são limites deliberados de qualificação inicial, não prova universal de ductilidade ou flambagem. A aba na viga, os parafusos e a flexibilidade fora do plano seguem o modelo convencional publicado e seu gabarito limitado, sem acrescentar um engaste3D inconsistente.

No receptor, cada linha usa a espessura física da mesma mesa, limites locais conservadores por unidade de comprimento e distância real à borda. Isso é suficiente para a rota convencional local de mesaW contínua aqui delimitada; não pretende conferir o pilar global, uma extremidade local cortada, alma de viga receptora, torção ou outro mecanismo fora desse escopo. O transporte da reação real até o eixo do pilar permanece documentado e não deve ser contado duas vezes no modelo global.

## Correções e condição de uso

Não foi solicitada mudança do motor. A única correção de documentação identificada foi a rastreabilidade das sete ferragens imperiais: a primeira cópia de `HARDWARE_SOURCE_RECEIPT.json` só documentava os seis diâmetros métricos. O implementador corrigiu o registro para incluir os13valores e fontes de cabeças/porcas/arruelas, com tolerância imperial explícita. A conferência numérica independente já cobria todos os13.

O parecer permite continuar integração e QA da candidata dentro desse contrato. Release, regressão completa, UI/Word/importação e produto final têm seus próprios gates. Não se aprova procedimento de soldagem de campo, içamento, estabilidade provisória, capacidade de um parafuso isolado, liberação de montagem ou segurança global da estrutura.
