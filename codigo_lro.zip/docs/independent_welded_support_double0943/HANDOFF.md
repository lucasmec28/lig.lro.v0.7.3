# Handoff2L0943

Estado: GO delimitado para integração pelo responsável, não release. `FINAL_RECEIPT.json` vincula fonte, patch, revisões e testes.

## Integração

Aplicar somente `WELDED_SUPPORT_DOUBLE_ANGLE0943.patch` ou os12 arquivos listados em `SOURCE_RECEIPT.json`. A candidata partiu de0.9.41; **não copiar a árvore inteira sobre0.9.42**. Os três pontos compartilhados são `app.py`, `lro/guided_selection.py` e `tests/test_guided_selection0919.py`: combinar aditivamente com1L, mantendo os19 índices anteriores. O teste novo2L localiza a família por label, sem pressupor o índice final ou quantidade total.

O patch foi aplicado sobre cópias dos três arquivos originais; reproduziu exatamente os12 hashes finais. Nenhum arquivo de0.9.41/0.9.42/1L foi editado. A versão global ficou intacta para o integrador.

## Evidência

- Motor:75 testes; revisão independente880 assertivas, inclusive100 geometrias variadas e todos os27 resultados resistentes
- UI/artefatos:34 testes no snapshot final;141 regressões de guia/importação
- Regressões R015/R016/catálogo/precisão:196 testes
- Desenho:16 cenários; Word:8 casos adversos/precisão,20 páginas inspecionadas integralmente,66 equações editáveis e17 frações
- Não apresentar esses números como agregado integral do aplicativo combinado: são baterias focadas e há sobreposição de cobertura

Contrato mecânico: `METHOD_CONTRACT.md`; parecer: `independent_review/REVIEW.md`.

## Replay portátil

`PYTHONPATH=<dependências> python source0943/artifact_qa/generate_artifacts.py --source <fonte atual> --output-dir <saída>`

Gera6casos, cada um com JSON nativo, JSON de resultado separado, SVG, PNG e DOCX, além de recibo de hashes. O gerador verifica o caminho do módulo importado. É necessário renderizar/inspecionar o Word novamente no destino quando o código combinado ou a rotaAPP alterar a exportação.

## Domínio final

Duas cantoneiras simétricas, soldas verticais externas no pilar com retorno superior curto sem crédito, parafusos comuns em dois planos e uma única alma de viga sem recorte. V descendente, N/M/T externos nulos. Não éR015 invertida nem duplica a alma. Capacidade elástica do exemploV100kN:134,007991kN.

A montagem deixa um lado aberto até colocar a segunda cantoneira e fecha a diferença de encaixe sem recorte. O cálculo considera apenas o estado final: soldas concluídas e todos os parafusos instalados/apertados. Não aprova fase provisória de uma cantoneira/um parafuso, estabilidade, içamento, procedimento de soldagem ou liberação do içamento.
