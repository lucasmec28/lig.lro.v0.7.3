# M-004 balanced W splice: bounded pure-tension completion

Original source review: 2026-10-09. Updated 2026-10-10 for the finite 0.9.13 axial-splice audit corrections. Earlier numerical checkpoints below are historical evidence, not validation of later UI/artifact code.

## Decision

A useful **actual W-to-W splice**, retaining both web covers and all six flange covers, has a defensible conventional ULS baseline for **positive, concentric, static axial tension only**. This is not the earlier standalone plate component. It is a dimensioned, balanced specialization of the supplied industrial M-004 topology.

The independent full-assembly fixture uses the catalogue **W 310 × 97,0 (H)**. Its 89 representative resistance checks and explicit geometric checks pass at an adopted conservative minimum force of **1,938.272727 kN** and at **2,200 kN**. At **2,250 kN**, the real, full-width member-web end U block fails, while every other enumerated resistance check passes. Its conventional envelope capacity is **2,211.601732 kN**. Symmetric physical copies have equal utilizations; the two splice sides are in series, never added as capacities.

This closes the previously identified mechanics gates **for this N-only subfamily**. It does not close signed N/M/V, compressive actions, general block rotation, slip resistance, fatigue, fabrication approval, or whole-building/member design. The current axial implementation retains these equations and bounds. The 0.9.13 correction addresses import fidelity, fresh artifact binding, known-load results with missing selected Nc,Rd, numerical-state separation and presentation. Its finite verification record is `AXIAL_SPLICE_AUDIT0913_METHOD.md`. A separate conventional N/M/V family now exists; this axial audit neither changes nor independently qualifies it.

Deliverables: `axial_tension_completion_fixtures.json` and the application-independent generator/checker `verify_axial_tension_completion.py`. Run `python w_splice_scope/verify_axial_tension_completion.py --check`.

## 1. Primary evidence actually inspected

1. Supplied ABNT NBR 8800:2024 with Errata 1, 25 February 2025. Existing source manifest identifies the PDF and SHA256. Original document pages are normally physical PDF page = printed page + 22.
   - Printed 39–42 / physical 61–64: §§5.2.2–5.2.5, gross/net tensile resistance, net-hole chains and Ct. Extracts in `../axial_splice_scope/source/nbr-61.*` through `nbr-64.*`.
   - Errata p.1: §5.2.5(a) corrected to **Ct=1.0**, and §6.5.4(b) corrected to Le/r > 25. Visually checked `source/nbr-1.png`.
   - Printed 70 / physical 92: §6.1.5 in `../axial_splice_scope/source/nbr-92.png` and `.txt`, visually checked.
   - Printed 71 / physical 93: centroid alignment §6.1.8 and installation limits §6.1.11.
   - Printed 83–85 / physical 105–107: §6.3.1–3 bolt areas, shear, bearing/end tearout; existing `bolt-105.*` through `bolt-107.*`.
   - Printed 90–92 / physical 112–114: holes, long grip/joint, spacing and edges.
   - Printed 94–96 / physical 116–118: §§6.5.3, 6.5.6 and Fig.16, visually checked.
   - Printed 36–37 / physical 58–59: §4.13 integrity. Newly rendered `source/nbr-58.png`, `source/nbr-59.png`.
2. Supplied `PADRÃO DE LIGAÇÕES-5Model.pdf`, M-004 printed p.72. `source/M004.png` and `M004-section.png` visually rechecked. The 10 mm dimensions and bolt e/s table are workshop-detail presets, not universal code minima or resistance values.
3. Gerdau official **Perfis Estruturais — Segmento Industrial**, p.3, [official PDF](https://gsn.gerdau.com/sites/gsn_gerdau/files/downloadable_files/Folder%20Perfis%20Estruturais%20Gerdau%20-%20Segmento%20Industrial.pdf). Downloaded and visually checked `source/gerdau_industrial.pdf`, table image `source/gerdau_industrial_table.png`. Confirms W310×97: d=308, bf=305, tw=9.9, tf=15.4 mm; A=123.6 cm²; flat web depth d′=245 mm. Published rounded internal depth h=277 mm is not substituted for exact d−2tf=277.2 mm in calculations. This is a catalogue geometry source, not a certificate for supplied steel or bolt materials.
4. SCI/BCSA **Single-Storey Steel Buildings, Part 5**, [official industry guide PDF](https://www.steelconstruction.info/images/f/f0/SBE_SS5.pdf), Appendix A, printed 67–68, 76–77 / PDF75–76,84–85. Figs.A9,A13,A14 directly show web end U paths, actual flange-side paths and cover-plate alternatives. Downloaded `source/SBE_SS5.pdf`; Fig.A13 visually inspected in `source/SBE_SS5-flange-block.png`. Only path geometry is used; all resistance coefficients/factors below remain NBR.
5. SCI/BCSA [P398](https://www.steelconstruction.info/images/5/5d/SCI_P398.pdf), §4 and Appendix D: allocation of the axial action by component area and direct component design. Used for mechanics, not Eurocode strength factors or service classification.

## 2. Exact boundary and adopted idealization

- Identical coaxial doubly symmetric W profiles; no notches, coping, missing bolts, packing, weld sharing, taper or thickness transition.
- All combinations admitted by this subfamily have N>0, M=V=weak-axis moment=torsion=0. No negative action can be silently clipped or replaced by absolute value.
- Two identical web covers, centered rectangular two-longitudinal-row × three-transverse-level grid at each member end. Flanges have two bolt columns, each through the centerline of its matching inner strip, and 2–6 aligned longitudinal rows per side.
- Each flange: one outer cover bo, two equal inner covers bi, identical thickness tc, material, length and longitudinal bolt stations. **bo=2bi**, centered outer plate, inner clear band c, gauge gf=c+bi.
- Conventional bearing-type static ULS. No claim of a slip-critical or rigid moment connection. A project requiring service no-slip, reverse/cyclic forces, fatigue or moment continuity needs another supported model.
- Exact M-004 preset conformity is separate from engineering adequacy of an explicitly dimensioned variation. Geometry/tooling/root data are explicit inputs.

Allocation uses a non-overlapping area partition:

Aw=(d−2tf)tw; Af,alloc=(A−Aw)/2; Nw=(Aw/A)Nd; Ftop=Fbottom=(Af,alloc/A)Nd.

Thus 2F+Nw=Nd exactly. A is the actual catalogue/input gross area; replacing it with 2bf tf+Aw would lose the fillet/root contribution. The residual catalogue area is allocated to flange demands. For the conservative **local rectangular flange** gross/net/block checks, only bf tf and tf-based ligaments are credited, with no added fillet resistance. The intact web/flange restraint is not credited as extra strength in the component checks. No extra coupled N/V/M interaction is needed when all admitted applied forces are parallel, tensile, and the selected plate stack is balanced.

There is no general-source proof here for arbitrary curved or coupled fracture surfaces. The result is the conventional aligned-path code design model, as used in the cited splice examples. Adding eccentricity, stagger, notches, a different allocation or unbalanced plates invalidates this closure.

### Cover sharing and bolt shear planes

Ao=bo tc=2bi tc=Ai,total. Equal material/length makes the outer and combined inner axial stiffness equal. Equal tc makes the cover centroids equally offset from the member flange midplane. Net areas remain balanced too: (bo−2dn)tc=2(bi−dn)tc.

One flange force F therefore produces F/2 in its outer cover and F/4 in each inner strip. With nf longitudinal rows, each of 2nf bolts per member end carries F/(2nf), with F/(4nf) on each shear plane. Each inner strip receives only its own nf bolts. The web has six bolts per side: full bolt force Nw/6, Nw/12 per plane, and Nw/2 per cover. Member axial tension is bolt **shear**, not bolt axial tension. The zero nominal out-of-plane eccentricity is derived from the qualified balanced stack, not inferred solely from two shear planes.

## 3. Gross/net checks and the entire perforated W

Corrected §5.2.5(a) gives **Ct=1.0** because forces are directly transferred by bolts to both flanges and the web. This is not the flange-only/web-only shear-lag case of §5.2.5(c). Every individual cover/strip is a directly connected flat plate. Bolted covers nevertheless have the separate §6.5.3 cap Ae=min(An,0.85Ag); the cap is not imposed on the original W member.

Normal ULS factors: γa1=1.10, γa2=1.35.

Rg=fy Ag/γa1; Rn=fu Ae/γa2.

Use the supplied actual physical hole for bearing and clearance. Section5.2.4.1(a) refers to the maximum hole dimension specified in6.3.6: for this bounded implementation use **dn=dh,Table14+2 mm**, or dn=dh,Table14 for documented drilled holes. Keep that diameter separate from the drawing's physical hole. For the first M20 fixture both the drawing and Table14 maximum are22mm, so dn=24mm. For M24 the workshop drawing26mm remains26mm in bearing/clearance, while the Table14 maximum27mm gives **dn=29mm**, or27mm with the documented drilled-hole branch. Using28mm merely because the drawing says26mm is not the conservative literal Table14 implementation and is not accepted here. This clarification supersedes the looser actual-hole wording of the earlier specification checkpoint.

Whole-W conservative net envelope:

An*=A−4dn tf−3dn tw.

It deducts two holes in each flange and three in the web, using the actual A. For coincident stations it is the straight net section. If flange and web stations differ, it intentionally over-deducts all component minima without any positive stagger correction; report it as a **conservative envelope**, not the exact critical station. A path restricted to these aligned longitudinal hole lines cannot lose more than one hole at each transverse line; NBR zig-zag correction adds nonnegative area. Arbitrary stagger/multiple extra holes are outside this first bound.

Also check the full allocated component force against local minima: flange (bf−2dn)tf; web Aw−3dn tw; outer (bo−2dn)tc; inner (bi−dn)tc; web cover (hwc−3dn)twc. Comparing full transferred component force with each minimum net area is conservative through the overlap. At the gap, each continuous cover carries its full assigned force and is unperforated; the smaller perforated cover check covers it.

## 4. Physical block paths

Use §6.5.6:

Rblock={min(0.60fu Anv,0.60fy Agv)+Cts fu Ant}/γa2.

Both branches have γa2. Cts=1 is used only for the stated uniform one-column or symmetric U model; one-sided blocks containing multiple columns use Cts=0.5. For k rows from the relevant **real loaded end**, Lk=e+(k−1)p and the one-leg net length is Lk−(k−0.5)dn. Evaluate every prefix and physical mirror. The cover's relevant free end is its remote plate end, not the butt gap; the member's free end is the butt.

### Original W flange

At each real outer flange edge, an L1 block includes one bolt column:

Agv=Lk tf; Anv=[Lk−(k−0.5)dn]tf; Ant=[(bf−gf)/2−dn/2]tf; demand=kF/(2nf); Cts=1.

Fig.A13 of the truss splice guide uses the two mirrored flange-side blocks and explicitly accounts for the attached web. A central U or whole-width L2 copied from a free rectangular plate would cross the attached web. It is not called an isolated physical flange failure here. Do not confuse an optional isolated-strip conservative screen with a demonstrated actual W rupture.

### Free outer flange cover

For plate width bo, two columns at gauge gf:

- U: two shear legs, Ant=(gf−dn)tc, Cts=1, demand=k(F/2)/nf.
- Each L1: one shear leg, Ant=[(bo−gf)/2−dn/2]tc, Cts=1, demand=k(F/2)/(2nf).
- Each L2: one shear leg, Ant=[(bo+gf)/2−1.5dn]tc, Cts=0.5, demand=k(F/2)/nf.

### One-column inner strip

Each actual side-L uses one shear leg, Ant=(bi/2−dn/2)tc, Cts=1, demand=k(F/4)/nf. Check both true side edges. The full force on the centered bolt line is used for each candidate, conservatively; it is not divided in half between two hypothetical duplicate columns. No zero-width U is generated.

### Original web and its covers

For every contiguous m=2 pair and m=3 full group of transverse levels with pitch py:

U has two shear legs; Ant=(m−1)(py−dn)t; Cts=1; demand=kmT/6. T=Nw in the member and Nw/2 in each cover. For three levels, the tension line deducts two full dn equivalents: two boundary half holes plus the middle whole hole. Omitting the middle hole is a tested error.

Each cover also has real upper/lower free edges. For m=1,2,3 counted from either edge, ey=(hwc−2py)/2:

L has one shear leg; Ant=[ey+(m−1)py−(m−0.5)dn]t; demand=kmT/6; Cts=1 for m=1 and 0.5 otherwise.

The web/flange junction is **not** a free side edge of the original web. Do not transplant these cover L paths to it. Single-column local end tearout is covered independently by hole bearing/tearout, not a fictitious zero-width U.

## 5. Bolts, bearing and detailing

Per-plane bolt shear: Rv=0.45Ab fub/γa2 with threads in plane (default), or 0.56Ab fub/γa2 only with documented excluded threads. Ab=πdb²/4. Both actual planes are verified; no addition of left/right splice-side capacities.

For standard holes with hole deformation a design limit:

Rb=min(1.2lc t fu,2.4db t fu)/γa2.

This includes local end/inter-hole tearout under §6.3.3.3. Along the admitted axial direction, lc=e−dh/2 at a loaded end and lc=p−dh between holes. Check each hole with the equal-bolt demand and the NBR sum of all hole resistances per group. In the fixture the main member and cover end distances coincide; in a variable design each uses its own actual e. These checks are separate for the member flange, outer cover, matching inner strip, member web and each web cover.

Preserve minimum center spacing max(2.7db,dh+db), preferred3db, maximum contact spacing min(24tmin,300mm) for painted/non-corrosive conditions, Table16 edge limits and max edge min(12t,150mm). Corrosion branch has different maxima. A below-Table16 edge can invoke only the explicit bearing-based code exception with documented handling; it is not an impossible-geometry cure. First subfamily bounds grip≤5db and total extreme-bolt span≤950mm, avoiding unsupported long-grip and long-joint simplifications. The 950mm convention is intentionally conservative.

Geometry independently verifies bo≤bf, c+2bi≤bf, positive ligaments, roots, face collisions and actual installation tool envelopes. M-004's 10mm inner-strip/web-cover clearance and flange-cover/web-cover clearance are preset checks; smaller positive values require a dimensioned variant, not an invented universal NBR failure. The benchmark outer M20 edge is35mm, above the NBR26mm minimum but below the drawing40mm preset. Its dimensional specialization is explicitly reported.

## 6. Minimum action: exact clause and engineering choice

The following is transcribed from the **user-supplied** NBR §6.1.5.3, printed70, physical92, `../axial_splice_scope/source/nbr-92.png`:

> Recomenda-se, a critério do responsável técnico pelo projeto, que as ligações de barras tracionadas ou comprimidas sejam dimensionadas para no mínimo 50 % da força axial resistente de cálculo da barra, referente ao tipo de solicitação que comanda o dimensionamento da respectiva barra (tração ou compressão), exceto se o dimensionamento for comandado pelo critério de esbeltez máxima, conforme 5.2.8 ou 5.3.7. Nesse caso, recomenda-se que as ligações sejam dimensionadas para no mínimo 100 % da força axial de compressão resistente de cálculo da barra, conforme 5.3.2, mesmo que ela esteja submetida apenas a forças de tração, respeitando-se o disposto em 4.13 e 6.1.5.2.

Correct interpretation:

1. §6.1.5.2 is the required45kN floor, with listed exceptions. The ordinary W tension-member splice is not one of the automatically exempt listed types. The floor acts on the **assembly N**, not independently on every plate/bolt.
2. §6.1.5.3 is expressly a **recommendation at the responsible designer's discretion**, not a universal mandatory50% rule.
3. Its slenderness alternative applies only when the **member design is governed by the maximum-slenderness criterion** referenced in5.2.8/5.3.7. It does not mean all W profiles or all long tension members must be designed as compressed members. The fact that this splice only accepts positive N does not itself establish the global member-design criterion.
4. For this benchmark, the explicit engineering selection is that tensile resistance governs the member design and the50% recommendation is adopted. Use the conservative reference Rref=Ag fy/γa1, so Nrec=0.5Rref. Since Nt,Rd≤Rg, this is at least50% of the actual tensile design resistance and avoids weakening the recommendation merely by enlarging splice holes. It is an adopted conservative choice, not a quote of the standard.
5. A designer may explicitly record non-adoption of the recommendation, retaining all mandatory minima and applicable integrity forces. Do not infer a waiver from silence. If the slenderness branch is expressly selected and the recommendation adopted, require the already-designed member's Nc,Rd and its source, or report that missing input. Do not invent an effective length or run compression checks on the positive-tension splice just to create this number.

For the selected case:

Nd=max(Nspecified,45kN,Nintegrity_if_applicable,0.5Ag fy/γa1).

§4.13 remains project-contextual. It may require additional integrity actions, including the75kN/1% horizontal-tie provisions of4.13.7 or specified column-splice tie force in4.13.8 when applicable. These are not a universal extra force for every W splice. The project must supply/confirm its applicable axial envelope; this module cannot certify the whole building from a member's shape and axial force. Do not confuse these with §6.1.6 contact-bearing compressed-member splice alternatives, which do not apply to this tension-only non-contact-transfer model.

## 7. No compression/stability check is falsely applied

Every admitted component force is positive tension; the symmetric qualified stack creates no nominal secondary plate moment. Consequently plate/member compression buckling, Le/r25, beam lateral-torsional buckling and local compressed-element slenderness checks are **not applicable to the calculated load state**. This is why the former G2 compression/stability gate can be closed as nonapplicable for this subfamily, rather than merely waived.

The member's overall tensile service/slenderness recommendations in §5.2.8, erection stability, tolerances and global load derivation remain project responsibilities and affect the minimum-action selection as described above. A negative, moment-bearing or eccentric combination must leave this supported subfamily. No 'tension-dominant' shortcut is permitted.

## 8. Independent integrated fixture and decisive expected values

Catalogue W310×97: A12360, d308, bf305, tf15.4, tw9.9 mm. Member fy345/fu450 MPa; covers fy250/fu400 MPa. Numerical bolt input fub800 MPa is explicitly declared conservative, not silently mapped to an ASTM grade. M20; dh22/dn24mm; threads included.

Flanges: bo240, bi120, c50, gf170, tc16mm; four longitudinal rows per side, p60mm, member/cover end40mm. Each of two outer covers and four inner strips is continuous530mm long. Web: two200×10mm covers, two-by-three grid per end, pitches60mm, ends40mm, length290mm. Butt gap10mm. Total bolt count44:32 flange plus12 web, all double shear. Tool radius25mm, root envelope z22mm/y122.5mm and fabrication clearance3mm are declared fixture inputs that must be project-verified.

- Aw=2744.28mm²; Af,alloc=4807.86mm²; local rectangle bf tf=4697mm²; residual root area221.72mm².
- Nrequested=1000kN; Nrec=Nd=1938.272727kN.
- Nweb=430.353kN; each flange753.959864kN; each outer376.979932kN; each inner188.489966kN; each web cover215.1765kN.
- An,whole*=10168.8mm²; whole gross/net resistances3876.545455/3389.6kN.
- Bolt resistance83.775804kN **per plane**; flange plane demand47.122491kN; web plane35.862750kN.
- Governing member-web U(k2,m3): Agv1980, Anv1267.2, Ant712.8mm²; R491.040kN; utilization0.8764112903.
- Governing cover L(k2,m3): R259.259259kN **per cover**; utilization0.8299665.
- Whole-splice conventional envelope2,211.601732kN. This is a model/check envelope, not a certified supplied-product or project load rating.

`catalog_W_2p2MN_PASS`: all89 representative strength checks pass. `catalog_W_2p25MN_web_U_FAIL`: only the member-web full U fails; the second source-side and opposite member-end mirror fail identically. `catalog_W_3p5MN_multiple_FAIL` also activates the whole-W net check and additional member/bolt checks. Every fixture has passing explicit NBR geometry checks; the named M-004 preset deviation remains visible.

### Required implementation gates/regressions

- Any N≤0, nonzero M/V/torsion, imbalance, different thickness, missing component or hole pattern change is outside this scope, never green.
- Exact catalogue A survives save/load; gross/net root contribution is not silently dropped or counted twice.
- All7 holes deducted at coincident stations; noncoincident stations either correctly enumerated or conservatively enveloped and labeled.
- Web3hole Ant deducts the middle hole; inner strip remains one column; original web side boundaries are not free.
- Whole-W net rupture, local sections, all conventional blocks, per-plane bolts and per-hole/group bearing all contribute to aggregate status.
- Minimum recommendation, RT decision, member criterion and applicable integrity load are explicit/reportable; no universal compression branch.
- Dimensioned drawing shows all8 covers, every bolt station, real lengths/ends, gauge and gap. The industrial10mm/e/s presets are distinguished from code checks.
- Benchmarks must be reproduced by the independent implementation without importing this oracle or deriving expected values from application output.

## 9. Implementation cross-check at this checkpoint

Read-only review of `connections_work090_w/source/lro/w_splice.py` was performed after the implementer adopted the clarified Table14 net deduction, an explicit integrity-included input, and an external compression-resistance source field for the optional slenderness recommendation branch. The original generic review gate was then removed for this bounded subfamily.

All89 oracle representative checks were matched against the corresponding application checks for each of4 independent fixtures: **356 demand/capacity pairs, zero differences** at relative tolerance1e−10. Application bolt fub830MPa versus fixture800MPa was explicitly adjusted by830/800 in the per-plane shear capacity only; demands and all other capacities were unchanged. The complete application enumerates additional equal-utilization physical flange/cover/group copies.

Additional checks verified rejection of nonzero M, nonzero V, negative N, zero N, imbalance, missing integrity inclusion, missing slenderness Nc,Rd, and unrecorded waiver. The M24 physical26/Table14max27/net29 regression produced An*=9712.3mm²; that geometry intentionally retains60mm pitches and therefore has an independent M24 detailing failure.

See `implementation_crosscheck.json` for the reviewed engine hash and exact results. This is numerical/scope review, not UI, drawing, persistence, integration-test or release approval; later engine changes require renewed affected checks.
