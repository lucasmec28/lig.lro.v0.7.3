import hashlib,json,os,subprocess,sys,time
from concurrent.futures import ThreadPoolExecutor,as_completed
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parent/'source0940'
OUT=ROOT.parent/'aggregate_final';OUT.mkdir(exist_ok=True)
old=json.loads((ROOT/'docs/validation0934/aggregate/RUN_MANIFEST.json').read_text())
files=sorted(ROOT.glob('tests/test_*.py'))
groups=[[ROOT/'tests'/Path(name).name for name in group['files']] for group in old['groups']]
assigned={p.name for group in groups for p in group}
extra=[p for p in files if p.name not in assigned]
groups[1].extend(extra)
assert {p.name for group in groups for p in group}=={p.name for p in files}
assert sum(map(len,groups))==len(files)
def hashes():
 result={}
 for glob in ('app.py','lro/*.py','tests/**/*.py','tests/fixtures/**/*','data/*'):
  for p in ROOT.glob(glob):
   if p.is_file():result[p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
 return result
manifest={'service_started_utc':datetime.now(timezone.utc).isoformat(),'tool_runtime_started':datetime.now(timezone.utc).isoformat(),'test_files':len(files),'source_and_tests_sha256_before':hashes(),'groups':[{'id':i+1,'files':[p.relative_to(ROOT).as_posix() for p in group]} for i,group in enumerate(groups)],'provenance':'Disjoint complete test groups on final held 0.9.40 runtime and tests. Earlier focused exploratory failures remain retained and are not final coverage.'}
(OUT/'RUN_MANIFEST.json').write_text(json.dumps(manifest,indent=2))
def run(i,paths):
 env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(ROOT)+os.pathsep+str(ROOT.parents[1]/'connections_audit/test_dependencies'),MPLCONFIGDIR='/tmp/lro0940_aggregate_mpl'+str(i),XDG_CACHE_HOME='/tmp/lro0940_aggregate_cache'+str(i))
 cmd=[sys.executable,'-m','pytest',*[str(p) for p in paths],'-q','--disable-warnings','--junitxml='+str(OUT/f'group{i}.xml')]
 begin=time.monotonic()
 with (OUT/f'group{i}.log').open('w') as out:p=subprocess.run(cmd,env=env,stdout=out,stderr=subprocess.STDOUT)
 item={'id':i,'exit_code':p.returncode,'seconds':time.monotonic()-begin,'log':f'group{i}.log','junit':f'group{i}.xml'}
 (OUT/f'group{i}_status.json').write_text(json.dumps(item,indent=2))
 return item
with ThreadPoolExecutor(max_workers=4) as pool:
 futures=[pool.submit(run,i+1,paths) for i,paths in enumerate(groups)]
 results=[]
 for future in as_completed(futures):
  item=future.result();results.append(item);print(json.dumps(item),flush=True)
manifest.update(tool_runtime_finished=datetime.now(timezone.utc).isoformat(),source_and_tests_sha256_after=hashes(),results=sorted(results,key=lambda x:x['id']))
manifest['runtime_and_tests_stable']=manifest['source_and_tests_sha256_before']==manifest['source_and_tests_sha256_after']
(OUT/'RUN_MANIFEST.json').write_text(json.dumps(manifest,indent=2))
print('FINAL_AGGREGATE_COMPLETE',flush=True)
