# Validação da integração 0.9.7-key-concrete-dev

Base: cópia nova da fonte final 096, cujo agregado terminou com 1641 testes aprovados. Aplicou-se somente o delta declarado de 5 arquivos existentes e 14 arquivos novos, mais a versão global em app.py/models.py. Não se copiou a pasta antiga inteira de desenvolvimento da chave.

## Identidade preservada

Permanecem 11 famílias; bases com schema_version 2 e connection_type próprios; versões de componente existentes não mudaram. Todos os 66 arquivos app/lro não afetados, o utilitário verificar_pacote.py e 87 arquivos de testes/referências existentes são byte-idênticos à fonte final 096. Nenhuma asserção antiga de versão global exigiu alteração. O SHA da memória W final está em validation/v097/INTEGRATION_IDENTITY_CHECK.json.

## Componente e fronteiras

Contato ACI da chave e 3 superfícies de ruptura: face normal real no sentido de V e 2 bordas paralelas virtuais, recortadas no bloco físico. Mantêm-se os estados NBR e ACI de centroide limitado, com seus próprios contatos, barras, pressões e resíduos. Não se alteram N/M/V no topo nem ações prescritas de solda. Tipo 2 permanece C1/C2/T1/T2, sem extrapolação de alto momento do Tipo 1.

A interpretação paralela deriva diretamente de ACI 17.11.3.2/17.7.2.1(c)/17.7.2.1.1. A alegação anterior de área pontual sempre inferior à área líquida de chave finita foi retirada; o contraexemplo permanece testado. Não se adiciona dedução arbitrária de t×d. As omissões de incrementos positivos de espessura/membro estreito continuam explícitas.

Não há aprovação da chave, ancoragem, placa receptora, bloco armado NBR 6118, fundação/solo ou base completa. Qualificações nos testes são sintéticas.

## Evidência anterior à integração

Revisão independente: GO para o escopo limitado; 142 testes focados, 81 deles escritos independentemente, com hashes estáveis. Outros 145 testes combinados do componente passaram no estágio, além de uma bateria de 354 testes focados de regressão adjacente. As fontes/derivações independentes usam Decimal com 50/70 dígitos, sem importar funções de produção como oráculo. Os 15 presets nativos da fonte 096 foram comparados sem alteração mecânica.

A UI/Word/SVG/JSON recebeu ensaios focados e inspeção visual do desenho, da seção nova na memória completa e de todas as 4 páginas da memória local Tipo 2 com equilíbrio pendente. Os resultados de pré-integração conservam sua origem e não são reclassificados como agregado 097.

## Evidência integrada

O agregado completo terminou com 1790 testes aprovados em 1234.31 s, saída 0. Os hashes dos 81 arquivos de produção e 95 arquivos de testes/fixtures permaneceram idênticos antes e depois da execução. O gate focado integrado aprovou 184 testes; as emendas anteriores ao congelamento tiveram 9 testes contextuais e 6 de regressão do editor. A revisão independente integrada aprovou 32 testes sensíveis à integração, 1 teste adicional de tração real com N positivo e 8 testes de offsets/callbacks. Os 15 presets nativos preservaram os resultados mecânicos da fonte 096.

Logs terminais, congelamentos, revisão independente e smoke portátil estão indexados em validation/v097/EVIDENCE_INDEX.json. A documentação e os índices foram finalizados depois dos testes, sem alterar a produção ou os testes congelados. A fonte 096 permaneceu idêntica ao seu inventário final; a memória W final e os 87 arquivos anteriores de testes/fixtures foram preservados.

O smoke portátil aceita fonte ou pacote bootstrap e confirma as 11 famílias, identidades, ambas as bases, bordas normais/paralelas, chave profunda/cancelamento, políticas axiais, falhas/pendências, qualificação/entradas inativas, recuperação de memória obsoleta e os bytes reais dos downloads Word/JSON. O ensaio na fonte não substitui uma futura execução no pacote extraído real.

Empacotamento e upload pertencem ao responsável pela entrega e não são executados nesta integração.

## Correção contextual anterior ao agregado

A revisão integrada encontrou que o editor compartilhado podia recentrar um bloco excêntrico ao editar uma dimensão depois de alternar os modos coordenadas/dimensões. O estado físico continuava correto até a edição, mas controles ocultos reapareciam com centro/offsets padrão. O callback agora usa somente o campo deliberadamente editado e conserva todas as demais dimensões/posições a partir dos limites canônicos; uma sombra não vinculada a widgets preserva o estado de edição. O clique explícito de centralização mantém semântica separada. A regressão exata foi reproduzida e corrigida nas duas famílias; nenhum cálculo de força/resistência foi alterado.

Também se tornou acessível o mesmo editor do bloco quando apenas o concreto da chave é selecionado, sem obrigar escolha de cabeça/cone e sem duplicar distâncias. A indicação de Ase,N segue qualquer Ti>0, inclusive com N positivo. A primeira bateria integrada passou 184 testes; a bateria contextual passou 9 e a correção de offsets passou 6, todos antes do congelamento do agregado. Registros e hashes estão nas duas emendas declaradas em validation/v097.

## Correção do editor de bloco da versão 0.9.6

O defeito confirmado afeta ambas as famílias de base, Tipo 1 engastada e Tipo 2 rotulada. Ao importar/usar um bloco excêntrico, alternar de dimensões para coordenadas e voltar para dimensões, os controles ocultos podiam voltar ao modo centrado. A edição seguinte de uma dimensão podia então recentrar silenciosamente os limites físicos em ambos os eixos.

A versão 0.9.7 conserva os offsets e limites não editados e só centraliza quando essa ação é solicitada explicitamente. Projetos afetados exigem conferir/restaurar os limites reais do bloco, recalcular todas as verificações e reexportar os relatórios; um resultado anterior não fica corrigido apenas por abrir o aplicativo atualizado. Enquanto se usa 0.9.6, o contorno seguro é manter o editor em coordenadas e conferir os quatro limites antes de calcular/exportar. A correção foi testada nas duas famílias com offsets assimétricos, alternância de editor e navegação.


## Smoke portátil da fonte final

O smoke portátil completo terminou PASS, saída 0, em 240,543 s na fonte 097 já contendo a correção do editor. Verificou 72 importações provenientes do pacote, 11 famílias, esquemas/versões preservados, 20 referências independentes de forças, 8 referências de borda, os dois ciclos de UI e os bytes reais Word/JSON/SVG. Incluiu importação exata, offsets assimétricos preservados após alternância/navegação/redimensionamento, dados inativos, qualificação e recuperação de relatórios obsoletos. Os arquivos de produção ficaram inalterados.

A memória local Tipo 2 com equilíbrio pendente teve 334868 bytes; a memória com falha numérica conhecida preservada teve 336235 bytes. Isso comprova geração/bytes do artefato, não aprovação estrutural. O modo de diretório bootstrap está implementado no script, mas seu uso no pacote de entrega extraído real ainda é um gate próprio do empacotamento.
