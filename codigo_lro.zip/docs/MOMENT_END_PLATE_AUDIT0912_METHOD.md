# End plate engastada: correção delimitada 0.9.12

Revisão de desenvolvimento da quarta família existente, 10/10/2026. Revisão de método `endplate-moment-case-envelope-0912-v1`. Não amplia a família, não recalibra a coluna, não certifica o nó completo e não publica o aplicativo.

## Casos completos e conclusão

A Entrada e, quando necessária, a conferência de força mínima de 45 kN são calculadas independentemente. O fator mantém direção/sentido de N/V e não majora M novamente. Com N=V=0 e M não nulo, há somente o caso de momento puro: nenhuma direção de força é inventada. Os mínimos de desenvolvimento DG39 continuam ativos.

A envoltória por mecanismo escolhe a linha completa de maior índice, incluindo caso, demanda, resistência, fonte, equação e substituição. Não combina demanda de um caso com capacidade de outro. Aumentar tração axial com M constante pode reduzir compressão de contato; por isso a conferência mínima nunca substitui a Entrada. O caso W410×38,8/CS550×498, N=1000 N, V=0, M=115 kN·m, tp=31,75 mm, placa A572 Gr.50 tem contato de Entrada 296124,322930/280000=1,057586868 e falha, embora o caso mínimo tenha 274266,185195/280000=0,979522090.

Caso suplementar fora de |N|(d−tf)≤|M| permanece explicitamente requerido e não resolvido; cálculos válidos da Entrada são conservados, sem capacidade inventada. Os JSON contêm actual_checks, minimum_checks, cases, governing_envelope e os ramos resumidos. Word compacto/detalhado preserva quadros dos dois casos; os resumos e o SVG identificam o caso governante. Toda exportação é recalculada e vinculada ao digest das entradas.

## Detalhamento e integridade de entrada

Passos e gabarito têm mínimo exato 2,7db e ligamento livre ≥db, NBR 6.3.9, impressa91/PDF113. Dimensões decimais derivadas são comparadas em Decimal antes da subtração de coordenadas binárias; não há tolerância arbitrária nem ajuste do valor informado. Furos fisicamente sobrepostos/fora do material são geometria inválida; ligamentos positivos abaixo do mínimo são não conformidade de detalhamento, com cálculos disponíveis. Bordas viáveis abaixo do mínimo adotado têm a mesma distinção.

Importação da engastada valida tipos, finitude, valores representáveis nos controles e identidade exata dos perfis de catálogo antes de qualquer substituição de estado. Não aceita booleanos como números nem texto inválido. Rejeição mantém projeto e memória válidos. Espessura personalizada persiste fora do estado efêmero do controle, inclusive navegação e troca para espessura comercial.

A folga CJP não depende da antiga perna de filete oculta; o valor salvo continua preservado. Na extensão somente acima, a sobra inferior física tem controle próprio. Na extensão dupla, seu rascunho fica inativo e preservado. Não se inventa uma dimensão genérica de solda CJP. As setas do desenho são referências positivas e as ações assinadas aparecem expressamente; N/V nulos não recebem setas fictícias.

## Categorias e três consolidações provadas

Falha resistente finita, detalhamento, condição do método, extrapolação, qualificação local incompleta, entrada ausente/inválida, falha numérica e N/A são distintos. Um índice resistente finito reprovado permanece destacado junto às demais ressalvas. Overflow/valores intermediários não finitos não produzem aprovação nem sobrecarga finita fabricada. Tração/interação sem alavanca só ficam qualificadas quando ambas as condições de espessura de chapa e mesa da coluna atendem, no respectivo caso.

Somente três redundâncias de exibição são agrupadas, sem suprimir contas:
1. Interação elíptica dos parafusos, com suas duas demandas e capacidades escalares.
2. Espessura do método e plastificação da chapa; η_plastificação=0,9η_espessura². Falha de espessura não é automaticamente escoamento.
3. Tração local da alma e transferência CJP local. O CJP tem demanda maior/igual e resistência menor/igual neste modelo exato.

Há 23 ramos numéricos e 19 linhas resumidas nos presets. Cisalhamento global da alma, cisalhamentos de extensão, contato, escoamento/enrugamento da alma da coluna, painel e blocos parciais permanecem distintos.

## Método coerente e limites preservados

Uma viga I ortogonal centrada na mesa de uma coluna I contínua; duas colunas de parafusos; mecanismo base 4E, sem nervuras; juntas CJP de alma e mesas; N/V/M estáticos no plano; sem laje participante, viga oposta, furos de acesso ou reforço externo. Extensão superior isolada suporta somente M positivo. Linhas intermediárias são apenas detalhamento, com todos os furos deduzidos e sem crédito resistente. Restrições de compacidade são condições conservadoras do método.

As correções locais 0.9.3 continuam: tração local da alma, cisalhamento bruto/líquido da extensão, desenvolvimento CJP de mesas/alma, região CJP de cisalhamento sem sobreposição e largura efetiva da mesa da coluna. W200 não tem proibição nominal: lwt=pfi+152,4≤d−2tf mantém os três ramos locais com ressalva de extrapolação de altura; região maior que a altura física deixa o caminho específico incompleto. Cortante em região pequena pode falhar de fato.

Escoamento/enrugamento da alma da coluna mantêm limites inferiores conservadores de posição de extremidade/comprimento carregado zero. Contato mantém a área inferior adotada bf·tf e menor fy, sem afirmar que é fórmula fechada normativa ou capacidade ótima. Instabilidade por forças compressivas opostas é inaplicável na hipótese sem viga oposta; contenção lateral permanece premissa. Dimensionamento global da coluna/membros, sismo/ciclos, detalhamento final de fabricação e responsabilidade técnica são externos. As lacunas de rotação da família rotulada não foram transferidas para a engastada.

## Fontes efetivamente conferidas

DG39 (2023): §3.5 pp.36–37; §3.7.1–2 pp.39–40; §3.7.5 pp.44–45, eq.3-38–41/Fig3-17; §3.7.6 pp.46–48/eq.3-44; §4.1 pp.49–50; §4.2.2 pp.51–52/eq.4-3; §5.1.1 pp.55–56/eq.5-3–4; §5.3.1 tabelas5-9/5-10 pp.112–113; exemplo5.3-1 pp.124–126/129. Exemplo publicado: Yp=185,868570 in e tp=0,589235726 in, compatíveis com186/0,589 publicados. DG39 define mecanismo/detalhamento; NBR fornece coeficientes resistentes e dedução brasileira de furos.

NBR8800:2024 corrigida2025: §§6.1.4/6.1.5.2 pp.70;6.3.9 p.91;5.7.3.2/5.7.4.2 pp.64–65;6.2.5.1/Tabela9 pp.76/78;6.3.3 pp.83–85;6.5.1/6.5.3 p.94;6.5.5/6.5.6 p.95. A edição e hashes estão em fontes.json.

Lacuna documental delimitada: a errata oficial DG39 de novembro/2024 foi identificada em https://www.aisc.org/globalassets/aisc/publications/revisions-and-errata/dg-39_revisions-and-errata-list-printed-copy_compiled-nov-2024.pdf, mas não recuperada após acesso403 e busca finita nos arquivos fornecidos. Não se presume irrelevância de suas alterações. Esta limitação não impede as correções de software e espaçamento NBR demonstradas; nenhum novo método foi atribuído à errata.

## Validação finita

Compara-se cada caso completo com substituições independentes, incluindo sinais, reversão, extensão superior, linhas intermediárias, pfi limitado, furos/rosca, W200 e os três exemplos de falha0.9.3. Há testes exatos abaixo/igual/acima de2,7db nos sete diâmetros, inclusive dimensões de passos derivadas. AppTest usa os callbacks reais de upload/abertura e os bytes reais dos downloads. Memórias Word e desenhos são renderizados para revisão de pixels; AppTest não equivale a teste de pixels de navegador. Nenhuma restrição de Chromium/socket foi contornada. A família rotulada tem comparação independente de paridade com0.9.11; as demais fontes de mecanismos não foram alteradas.
