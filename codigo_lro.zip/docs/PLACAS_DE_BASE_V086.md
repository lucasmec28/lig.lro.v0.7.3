# Placas de base 0.8.6 em desenvolvimento

Estado: checkpoint integrado, sem publicação. A solicitação de concluir as duas bases permanece aberta. Os resultados favoráveis são dos componentes e domínios identificados, não uma aprovação da base completa.

## Famílias reais e preservação de projetos

- Placa de base engastada: NBR Tipo 1, quatro chumbadores externos, N/M/V aplicados. O nome indica a família solicitada; a rigidez rotacional do engaste não foi demonstrada.
- Placa de base rotulada: NBR Tipo 2, quatro chumbadores internos em (±a2/2, ±a2/2). Entradas N/V; M aplicado é fixo em zero e não existe no JSON. Geometria a=a2/2, L=d+4a1 e B=a2+2a1. A família admite C1/C2/T1/T2; C3/T3 e momento puro permanecem fora do domínio.
- A flexão por tração Tipo 2 usa t=√[4 Ft,máx(a2−tw)/(l0 fy/γa1)] com l0=min[d;a2+1,75(a2−tw)]. Não reutiliza a linha de plastificação dos chumbadores externos.
- A chave com geometria explícita gera Mlocal=V eV, com sinal e uma única vez. Não há campo de momento aplicado na base rotulada. Capacidade externa escalar sem posição de reação é rejeitada nessa família; isso não declara que a geometria física seja inviável.
- Projetos schema1/base_plate continuam legíveis. Indicação antiga pinned é preservada como base_plate_type1_legacy, sem alterar chumbadores externos nem apagar M. A interface e a memória explicam que essa indicação antiga era somente metadado. Intenção ausente continua unspecified; não é inventado um vínculo.
- Novos arquivos usam schema2/base_plate_fixed ou base_plate_pinned. Estado, anexos locais, modelos opcionais e qualificações são independentes por família. Importação cruzada não converte geometria.

## Componentes acrescidos

### Ancoragem ACI complementar

São disponibilizados pullout por área efetiva qualificada, ruptura lateral em domínio retangular limitado, ruptura ao cortante com linhas/bordas, pryout, resistência do aço ACI com áreas efetivas documentadas e interação numérica entre modos/estados qualificados. Mantêm-se φACI e γNBR separados.

A área efetiva não pode superar a projeção líquida geométrica da peça. Para porca, também respeita a área líquida já documentada; para chapa enterrada, desconta o furo real. Geometria fornece somente um limite superior, nunca capacidade automática. A área creditada exige fonte, correspondência ao detalhe atual e, para chapa enterrada, resistência mecânica documentada. Peças enterradas individuais na mesma cota não podem ter envelopes sobrepostos sem outro modelo.

As áreas efetivas Ase,N/Ase,V são documentadas e limitadas pela seção bruta. A rota de mesma seção rosqueada exige Ase,V≤Ase,N; outra seção exige modelo próprio. O nome ASTM A36 não comprova ductilidade ACI. Na falta de comprovação de ductilidade, os fatores explicitamente conservadores do ramo não dúctil são utilizados.

Não há distribuição V/4 implícita. O vetor de forças informado deve ser referenciado/qualificado, somar |V| e manter pares iguais, sem torção. A qualificação perde efeito quando mudam ações, bloco, coluna, chumbadores, arruelas/furo/soldas ou demais detalhes pertinentes. O vetor efetivo é comparado à resistência NBR individual de cada barra, além das verificações agregadas.

A interação avalia separadamente o vetor físico e os estados alternativos reais de redistribuição entre linhas x exigidos pelos Casos 2/3. Cada estado mantém as trações Ti e usa seus próprios Vi, aço ACI, concreto, pryout ativo e limites NBR por barra. Governa o maior índice; estados não são somados. As construções virtuais das bordas paralelas são somente comparações resistentes, nunca cargas físicas giradas ou estados com torção. Demandas máximas de transferência por barra são apresentadas separadamente; quando a arruela local está calculada, sua ação de projeto é comparada a essas demandas.

A interação numérica pode ser concluída para os modos e estados enumerados quando suas premissas estão presentes. Cone ausente sob tração, apoio/área sem comprovação, distribuição não qualificada, bordas paralelas pendentes ou geometria diagnóstica impedem conclusão. Resultados diagnostic_only permanecem visíveis, mas não viram aprovação, reprovação ou resistência de interação.

### Solda pilar placa Tipo 2 em tração pura

Submodelo limitado a N<0 e M=V=0, com faixas completas de 45° até a alma, baseado no DG1 exemplo 4.7-3. Verifica filetes ou CJP qualificada, escoamento/ruptura local da alma e flexão/cisalhamento suplementares das faixas reais da placa. O comprimento efetivo da solda é real e explícito; não se substitui por l0 da placa. CJP utiliza uma seção fundida, não duas capacidades por duas faces. Procedimento, inspeção e requisitos aplicáveis de tenacidade, incluindo metal de solda em seções espessas tracionadas, são necessários.

As verificações de solda/furo da arruela superior introduzidas em 0.8.5 permanecem, inclusive sua ação Fv,Rd não reduzida com V=0.

## Limites que continuam abertos

1. Campo geral de forças e dimensionamento das soldas pilar–placa sob N/M/V, coerente com a flexibilidade da placa, especialmente na família engastada. Não se presume distribuição elástica rígida nem transporte do momento da fundação para a solda superior. Aguarda-se apresentação/memória trabalhada indicada pelo usuário ou outra fonte específica verificável.
2. Transferência local completa arruela–placa e pilar–placa: flexão acoplada, contato, fusão e demais rupturas do metal-base, interação flexão/cisalhamento, furos/arruelas e capacidade de rotação.
3. Peças enterradas e demais detalhes não cobertos por comprovação mecânica aplicável; fendilhamento, cobrimentos/detalhamento, armaduras e bloco/fundação.
4. Domínios explicitamente rejeitados ou pendentes nos módulos: outras geometrias, carregamento biaxial/torção, ações cíclicas/sísmicas, ancoragens químicas/pós-instaladas, enrijecedores e reações externas sem modelo de excentricidade.

Esses limites não são contornados com checkboxes de “base completa” ou capacidades fictícias. Fontes de componentes: PINNED_BASEPLATE_SCOPE.md, HEADED_ANCHORS_V086.md, concrete_completion/SHEAR_PRYOUT_INTERACTION.md e COLUMN_BASE_WELD_V086.md.

## Entradas simplificadas sem alterar as verificações

- A família rotulada não mostra seletores com uma única opção para chumbadores/enrijecedores.
- O cálculo local Tipo 2 da solda aparece na família adequada; dados importados incompatíveis permanecem explícitos.
- Forças de corte da ancoragem e hipóteses de borda aparecem quando V é transferido pelos chumbadores. Rascunhos ocultos são preservados. A arruela não é ocultada simplesmente porque V=0.
- Adoção de espaçamento da Tabela 18 é separada da adoção do graute. Botões declaram exatamente quais campos alteram; nenhum bloco real é preenchido com mínimo tabulado.
- O bloco pode ser editado por dimensões reais e posição, com centração explícita, ou pelos quatro limites x/y. Trocar o editor não recalcula valores canônicos intactos. Blocos excêntricos importados conservam offsets e limites exatos.

Nenhuma simplificação transforma uma dimensão física, material, área efetiva ou hipótese de distribuição desconhecida em dado automaticamente verificado.
