# Parametric addendum: conventional W splice

Date: 2026-10-10. This addendum **supersedes the fixed-W310/fixed-dimensions admission restriction** in the earlier contract. That numerical detail is a benchmark, not the universal domain. No production changes.

## Decision and actual boundary

**GO for a computed parametric domain.** Permit other identical rolled W members, cover widths/thicknesses, standard bolt sizes, pitches, gauges, end distances and gaps when the tests below pass. Preserve the conventional allocation, symmetric eight-cover arrangement, balanced flange covers and complete regular2×3 web grid on each side. These are the model's physical topology; a particular profile designation is not.

When a test fails, retain calculations that remain meaningful and identify the exact failed/pending check. A geometry/access failure, an unverified scalar-block mapping or a failed strength inequality are different results. None is a reason to hide unrelated computed capacities.

## 1. Geometry and ordinary detailing

Let bo be outer-flange-cover width, bi each inner-strip width, c the inner clear band, tfc common flange-cover thickness, hw/twc web-cover height/thickness, g the vertical web pitch, p the longitudinal web pitch, em/ec member/cover web end distances, and s the butt gap.

Require bo=2bi, the same flange-cover material/thickness, centered regular bolt lines, positive contact/overlap dimensions and two identical web covers. Flange bolt gauge gf=c+bi. Actual fit and access are computed:

- bo≤bf; c+2bi≤bf; (c−tw−2twc)/2≥required clearance.
- (d−2tf−2tfc−hw)/2≥required clearance.
- c/2−tw/2−root radius≥fabrication clearance; (verified clear root height−hw)/2≥fabrication clearance.
- Actual washer/tool envelopes must clear roots, web covers and inner flange strips; use their supplied dimensions, not a hard-coded profile whitelist.
- Hole spacing, edge distances, grip, material-product/thickness limits and required long-joint reductions follow the already qualified current-NBR rules. M16/M20/M24/M30 are demonstrated here; another standard diameter needs the correct table mapping, not a change in statics.
- Physical dh remains separate from net deduction dn: currentTable14 maximum plus2mm unless the documented drilled-hole rule permits omission. Use actual dh for contact/clearance.
- All actual net ligaments/path areas must be positive. In particular g>dn, p>dn, s+2em>dn and hw/2−g>dn/2. A nonpositive ligament is a local geometric/section failure, not a numerical exception to suppress.

The source drawing's preferred10mm gaps are not universal NBR minimums. If a smaller positive gap fits actual roots/bolts/tools and applicable fabrication requirements, show the dimension and deviation rather than declaring every such design impossible. A requested minimum clearance remains binding.

Flange row count may vary with a regular complete grid and its actual transfer length. At least two rows per side make the row-supported model explicit. If a long-joint or grip reduction is required but not implemented, flag that precise bolt rule while retaining other calculations; do not replace it with a profile-name gate.

## 2. Exact dimensionless web-force test

Define:

- a=p/2; b=s/2+em; e=b+a.
- Four whole-cover bolt columns: [−b−p,−b,+b,+b+p].
- Each half-group's local x=±a and y=−g,0,+g.
- J=6a²+4g².

For complete bolts, at unit positive V:

- qx=e y/J.
- qy=side/6−e xlocal/J, where side=−1 for the left group and+1 for the right.
- Multiply both by signed V. Each actual cover/shear plane takes one half.

This preserves each group's required shear and Cg=−eV, and global force/moment equilibrium. N and M do not enter this web field.

For nonzero V, admit the conservative scalar source convention when BOTH computed tests pass:

1. e a/J≤1/6: individual qy values retain the group's shear direction.
2. For every contiguous whole-cover column subset and each top/bottom prefix of1,2,3 vertical levels, the magnitude of the vector sum of the **per-cover** unit-V forces is≤1/2.

The second condition is finite enumeration, not a guessed eccentricity limit. Keep the vector sums and governing subset in the output. It is intentionally conservative and preserves the full |V|/2 path-demand envelope. A simple bound on e alone is not needed; wider vertical gauges can legitimately accommodate larger e.

For negative V, multiply the field by−1 and mirror the loaded regions. Admission and utilization use normalized magnitudes and are unchanged. When V=0, the web has exactly zero force and zero Ve. The scalar-block mapping is not required for that load case; do not leave pure N/M pending merely because a hypothetical nonzero-V geometry would fail the above tests.

If either test fails with nonzero V, return **WEB_SCALAR_BLOCK_ECCENTRICITY_MAPPING_PENDING**, show both actual values/limits and the offending subset, and keep bolts, directional bearing, cut forces, compression and other independent checks available. Do not automatically increase scalar block demand and imply that this proves a new arbitrary rotation-dominated domain.

Example: the benchmark with em90 gives e125mm, e a/J=.189394>1/6 and max subset=.757576>.5. Its scalar web-block conclusion is pending, while compression and other capacities still calculate. Setting V=0 removes this inactive web gate.

## 3. All84 real-cover paths; no unnecessary bridge/pitch restriction

Cover free edges: x=±X, X=b+p+ec; y=±Y, Y=hw/2. The splice line and member butt edges are not cover free edges.

For each top/bottom y edge and k=1,2,3:

- Lv=Y−g+(k−1)g; Lvn=Lv−(k−.5)dn.
- Enumerate every contiguous U span of2,3,4 columns:6 possibilities. For m included columns, Ant=[xmax−xmin−(m−1)dn]twc; Agv=2Lv twc; Anv=2Lvn twc.
- From each real x free edge, enumerate L spans including the nearest1,2,3,4 columns:8 possibilities. If the furthest included column is xc, Ant=[|xc−xfree|−(m−.5)dn]twc; Agv=Lv twc; Anv=Lvn twc.

Thus2 vertical edges×3 prefixes×(6U+8L)=84 explicit paths per physical cover. Use Cts=.5 and the current6.5.6 capacity, with full |V|/2 on each. Identical opposing covers have equal results; each is separately represented, never given the sum of both capacities.

The previous36 representatives are only a report optimization after actual net-area/capacity dominance is established. **Do not require s+2em≥p.** If the central bridge is shorter than p, the cross-splice U path may be weaker than a same-half U path; simply retain all84. The fixture with a68mm bridge and90mm pitch is admitted and exercises this case.

Keep the original member distinction: no fictional top/bottom member-web free edge. Its uncut web is checked by actual bolt bearing/tearout, gross/net shear and connected-member/hole checks. A cope or cut that changes these boundaries gets a specific topology qualification requirement.

## 4. Actual spans, stocky and slender compression, current Aeff

Lf=max(s+2ef_member, every actual flange overlap-row interval). Lb,web=max(s+2em, p). Use K=1 and the declared physical row-contact/bolt/member restraint detail. Neither span is the empty butt gap. A missing support or unattached erection state is a targeted support prerequisite, not a default capacity.

For each actual separate rectangular outer plate and each inner strip, calculate both flexural Euler loads and the conservative torsion bound GJ/r0² with positive warping stiffness omitted. Use Ne=min of the applicable modes. **Longer spans or thinner plates are not automatically outside scope.** They change Ne, lambda0, chi and resistance.

Current5.3.3: lambda0=√(Ag fy/Ne), chi=.658^(lambda0²) forlambda0≤1.5, otherwise.877/lambda0². The reduced-slenderness numerator uses **gross Ag**, not Aeff.

Current5.3.4/Table4/Table5, visually checked atPDF68–70 / printed46–48:

- Outer local elements: AA width gf and two AL widths(bo−gf)/2.
- Each inner strip: two AL widths bi/2.
- beta=bplate/t; beta_lim=1.40√(E/fy) for bolted AA, and.56√(E/fy) for projecting AL.
- AA coefficients c1=.18,c2=1.31; AL c1=.22,c2=1.49.
- If beta≤beta_lim/√chi, beff=bplate.
- Otherwise sigma_el=[c2 beta_lim/beta]²fy; z=√[sigma_el/(chi fy)]; beff=bplate(1−c1 z)z.
- Aeff=tΣbeff; compressionRd=chi Aeff fy/γa1 when the5.3 branch is required.

Do not mark all local slenderness pending; compute the current effective widths. The overlap's actual AA/AL geometry provides the width classification; the finite bridge still uses its separate flexural/torsional bar calculation, with no invented continuous backing across the empty gap. Applying the reduced area to the whole conservative bar capacity retains the local limitation.

Use the6.5.4(a) gross-yield shortcut only when Le/r≤25 **and** local elements are non-slender **and** the checked torsional bound does not undercut gross squash. Otherwise run the complete5.3 mode/effective-area calculation, even for a numerically short element. This is a conservative route rather than an unsupported exemption from local or torsional behavior. It does not turn a stocky-but-wide plate into an automatic rejection.

Effective-width arithmetic fixtures:

- AL b100,t4,chi.9: beff77.723951mm.
- AA b200,t4,chi.9: beff175.663746mm.
- AL b60,t16,chi.9: beff60mm.
- An actual140×2mm strip atLe100 givesAg280,Aeff275.734760mm², chi.218472961 andRc13.691043kN. This thin-strip arithmetic case does not waive its separate bolt detailing requirements.

## 5. General exact hole integration and bending

For the symmetric three-hole web cut, integrate the retained y intervals of [−hw/2,+hw/2] after removing [yi−dn/2,yi+dn/2] at yi=−g,0,+g. Do not use a special W310 constant. Because this section stays symmetric, its net centroid/plastic axis remains y0:

- An=Σtwc(v−u).
- Inet=Σtwc(v³−u³)/3.
- Znet=Σtwc[v|v|−u|u|]/2.
- Wnet=Inet/(hw/2).

This automatically includes the central hole's twc dn²/4 deduction. If admitted geometry later loses symmetry, recompute the actual neutral/plastic axes rather than reusing these centered expressions.

Use actual rectangular dimensions in currentAnnexD LTB. Calculate actual cut moments before/after all bolt stations and choose Menv=max(e|V|/2, maximum actual per-cover |Mcut|). This preserves the source envelope when it bounds the real cut field and safely accommodates any numerical variation; group moment and cut moment remain separately labelled.

Keep the earlier separate gross/net shear, LTB, net bending, gross combined and explicitly supplementary net linear screen. No imaginary normal web share is reintroduced.

For the main-member tension-flange hole cap,5.4.2.6 was visually checked atPDF78/printed56:

- Yt=1.0 when fy/fu≤.8; otherwise1.10.
- If fu Afn≥Yt fy Afg, this hole clause adds no cap.
- Otherwise MRd,hole=(fu Afn/Afg)Wt/γa1, with Wt the gross elastic modulus on the tensile side.

Do not confuse itsγa1 denominator with cover net bending fu Znet/γa2. Both M signs must be handled; the actual member N/M interaction and V-dependent moment gradient remain separate checks.

## 6. Independent varied-profile fixtures

Run `python w_splice_scope/conventional_qualification/verify_parametric_domain.py`; output is `parametric_fixtures.json`. It imports only the preceding independent research oracle, never production formulas. Profile dimensions are independently transcribed from the supplied Gerdau catalogue printedp3; roots, tools and fabrication clearances are declared fixture inputs.

The following pass parametric admission and the newly qualified subchecks. Values below are one outer compression capacity and minimum one-cover block capacity; these are not whole-assembly capacities:

- W250×73/M16: e65mm, outer200×12.5, web170×8, p/g50/50; Rc568.182kN, Rblock60.741kN.
- W310×97/M20 benchmark: e75mm, outer240×16, web200×10, p/g60/60; Rc872.727kN, Rblock85.926kN.
- W360×91/M20: e75mm, outer204×16, web240×10, p/g60/80; Rc741.818kN, Rblock85.926kN.
- W610×155/M24: e95mm, outer260×20, web360×12, p/g80/120; Rc1181.818kN, Rblock143.111kN.
- W610×155/M30: e110mm, outer272×25, web400×16, p/g90/130; Rc1545.455kN, Rblock225.185kN.
- W360×91/M16 with bridge68<p90: all84 paths remain; Rc741.818kN, Rblock60.741kN;36-path dominance is explicitly false without rejecting the design.
- W610×155/M24 with flange/web bridge170, outer260×12: full slender compression branch, Rc601.466kN; Rblock119.259kN.

The same file includes an admitted negative-V case with identical utilization, the zero-V/excess-e case with no inactive web gate, a500kN shear strength failure inside the admitted domain, a wrong-width/profile fit failure that retains useful numbers, the excessive-e scalar-mapping pending case, and isolated local-effective-width tests.

For every admitted active-web case, the maximum normalized subset resultant is.5. Full force data, areas, all84 paths, cut moments, compression modes and detailed geometric inequalities are persisted. Independent engineering implementation validation can therefore compare actual variable geometry rather than treating one fixture as a universal prohibition.

## Final implementation direction

Remove the W310-only/name/dimension equality gate. Keep topology and force allocation explicit, then calculate the conditions above. Preserve finite outputs and targeted statuses on failure; never let a pending scalar-block interpretation suppress a known bolt or compression failure. The original contract's local-check list and global/member/service scope notes remain in force, with this parametric addendum taking precedence over its fixed-dimension language.
