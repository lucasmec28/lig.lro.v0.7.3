# Viga sobre viga com chapa contínua de apoio

## Identidade e conclusão permitida

Família independente `beam_on_beam_bearing_plate`, componente `0.9.44-beam-on-beam-partial-dev`. Implementação isolada sobre cópia da base congelada 0.9.43, com identidade de distribuição 0.9.44 autorizada após revisão do escopo parcial. A fonte congelada 0.9.43 permanece intacta; sem publicação.

O resultado é uma **coleção de verificações locais parciais**. `global_pass` permanece `False`. Um `PASS` resistente corresponde apenas à demanda identificada naquela linha. O programa não declara a ligação completa verificada, não autoriza fabricação e não utiliza um enrijecedor desenhado como resistência comprovada.

A transferência local fora do plano é uma pendência agregada, abrangendo contato, flexão das peças, tração e alavanca, parcela normal e momento da solda, estados locais das almas e forças dos enrijecedores. A estabilidade global das vigas e do sistema é uma exclusão de escopo distinta; delegá-la não elimina o momento local N vezes a altura.

## Topologia física e coordenadas

- Duas vigas W ortogonais, a superior terminando sobre a inferior.
- Uma única chapa contínua, horizontal, soldada sob a mesa inferior da superior.
- Quatro parafusos em grupo simétrico 2 por 2 atravessam a chapa e a mesa superior da inferior. Existe um plano de corte por parafuso.
- Um par de enrijecedores na alma da inferior, um de cada lado, sob a região de apoio.
- V descendente é transmitido por contato. A parcela horizontal N é transferida pela solda, chapa, parafusos e mesa inferior. Não se toma V/4 como cortante dos parafusos verticais.

Convenção do programa: x ao longo da viga superior; y ao longo da viga inferior; z para cima. O é a interseção das almas no plano de contato entre a chapa e a mesa superior da inferior. `plate_length` e `bolt_pitch` são dimensões em x; `plate_width` e `bolt_gauge` são dimensões em y. O contrato de pesquisa usa nomes de eixos trocados; a geometria física é a mesma e a transformação é explícita aqui.

Coordenadas dos quatro parafusos: `(-pitch/2,-gauge/2)`, `(+pitch/2,-gauge/2)`, `(-pitch/2,+gauge/2)`, `(+pitch/2,+gauge/2)`. A numeração das trações externas segue exatamente essa ordem.

## Caso informado e origem das ações

Superior W360×39: d=353 mm, bf=128 mm, tw=6,5 mm e tf=10,7 mm. Inferior W410×38,8: d=399 mm, bf=140 mm, tw=6,4 mm e tf=8,8 mm. Valores nominais de catálogo não substituem tolerâncias e conferência do produto.

As ações simultâneas são V=2610 kgf e N=+1000 kgf. O fator exato 9,80665 N/kgf produz V=25595,3565 N e N=9806,65 N. V vem da reação informada; N é reserva artificial escolhida pelo usuário, com esforço real no Robot próximo de zero. Essa proveniência consta das observações do caso. Nenhum coeficiente adicional de ações é aplicado. Os coeficientes de resistência γa1=1,10 e γa2=1,35 permanecem nas fórmulas.

Geometria inicial editável, sem dimensionamento implícito: chapa 140 mm em x por 260 mm em y, tp=10 mm; parafusos M16 em 80 mm por 200 mm; furos de 18 mm; filetes de 6 mm em duas linhas efetivas de 128 mm; enrijecedores de 6 mm por 60 mm, altura declarada de 381,4 mm. A escolha dessas dimensões não é aprovação de flexão, contato ou resistência dos enrijecedores. O comprimento paralelo longitudinal é limitado conservadoramente a no mínimo a distância entre as duas linhas, conforme 6.2.6.2.3; o comprimento efetivo real ainda depende do detalhe de extremidade.

## Transporte e desconhecidos

Para F=(N,0,−V), r=(xref,0,d_superior/2+tp):

`My,O = My,A + N*(d_superior/2+tp) + V*xref`

No caso inicial, o braço de N é 186,5 mm e sua parcela de momento é 1828940,225 N mm. A entrada `reference_x=None` informa que a posição longitudinal do referencial das ações não foi declarada. A parcela V*xref e o momento total permanecem `None`; o programa não transforma a ausência em zero. O usuário pode declarar zero explicitamente quando fisicamente cabível. Não duplicar o mesmo transporte já existente no modelo de origem.

No grupo simétrico e sem torção aplicada no plano, a parcela de corte é `Si=abs(N)/4`, ou 2451,6625 N por parafuso no caso inicial. A reversão de N mantém a demanda de corte em módulo, muda a parcela de momento e troca as bordas carregadas. O modo com torção não continua dividindo por quatro como se fosse simétrico.

`contact_resultant`, `contact_x`, `contact_y` e `bolt_tension_1` a `bolt_tension_4` são opcionais e começam ausentes. `tensions_include_prying=False` e `external_same_case=False` exigem declaração positiva; não são confirmados automaticamente. O modelo externo deve ter identificação em `local_model_reference`.

Conferências de equilíbrio de um modelo externo:

`C - sum(Ti) = V`

`C*xc - sum(Ti*xi) = My,O`

`C*yc - sum(Ti*yi) = 0`

Essas igualdades são necessárias e não suficientes: não comprovam rigidez, distribuição/área de contato, flexão ou resistência de todos os componentes. Nunca se inventam C=V, Ti=M/g, fator de alavanca, ou V/2 por enrijecedor.

## Verificações resistentes disponíveis

### Corte simples dos parafusos

ABNT NBR 8800:2024 com Errata 1:2025, 6.3.2 e 6.3.3.2:

`Ab=pi*db^2/4`

`Fv,Rd=alpha*Ab*fub/gamma_a2*k_pega`

`alpha=0,45` para rosca interceptando o plano ou parafuso comum; `alpha=0,56` somente para parafuso de alta resistência com rosca fora do plano. A redução por pega usa a geometria real. Uma interface não é contada duas vezes.

### Contato nos furos de cada peça

NBR 6.3.3.3, ramo com deformação em serviço limitada e furos padrão:

`Fc,Rd=min(1,2*lf,2,4*db)*t*fu/gamma_a2`

`lf` é o ligamento livre no sentido da força da peça. Chapa e mesa inferior têm materiais e espessuras próprios e forças opostas. Avaliam-se os quatro furos e as respectivas bordas carregadas; não se soma duas vezes o mesmo ligamento. A resistência ao contato do furo não verifica o contato vertical chapa/mesa.

### Solda e metais base para N horizontal

O grupo de duas linhas iguais e simétricas recebe a parcela horizontal centrada:

`q=abs(N)/(2*Le)`

`qw,Rd=0,60*fuw*(w/sqrt(2))/gamma_a2`

No metal-base de cada peça, verificam-se separadamente `0,60*fy*t/gamma_a1` e `0,60*fu*t/gamma_a2`, conforme NBR 6.2, Tabela 9 e estados de cisalhamento de 6.5.5. A chapa usa tp; a mesa da superior usa tf_superior. Não se soma a espessura dos dois componentes como se fosse uma peça única.

O nome e as notas dessas linhas identificam a parcela horizontal. Não há aprovação integral da solda sob momento e força normal. Tampouco se lança V integral na solda ao mesmo tempo em que se conta contato integral sem modelo declarado. A ligação das linhas de solda a seções completas, escoamento/ruptura da chapa e caminhos reais de bloco ainda exige qualificação específica; não se inventa um bloco de largura total que duplicaria os caminhos laterais.

### Tração e interação a partir de demandas externas

NBR 6.3.3.1 e 6.3.3.4:

`Ft,Rd=0,75*Ab*fub/gamma_a2`

`(Ti/Ft,Rd)^2+(Si/Fv,Rd)^2 <= 1`

A tração deve incluir alavanca e pertencer ao caso simultâneo declarado. Ausência gera `PENDING` e `eta=None`; não gera um passe com eta=0. A interação parcial não encerra a transferência local.

## Geometria e enrijecedores

Furos padrão e distâncias usam NBR Tabela 14, Tabela 16 e 6.3.9 a 6.3.12. Para M16: furo máximo de 18 mm e borda nominal mínima de 22 mm. Espaçamento mínimo max(2,7db,dh+db). Máximo entre centros min(24t_min,300 mm), para a hipótese explícita de contato contínuo e ambiente pintado; aço patinável exposto exige outro ramo. A borda máxima é min(12t,150 mm). A relação demanda/limite em geometria não é utilização resistente: um mínimo atendido pode ter razão maior que 1.

O envelope de ferragem compreende cabeça/porca/arruela. `tool_radius=None` deixa acesso pendente; o raio de ferramenta declarado deve cobrir a ferragem e as folgas reais. `support_root_radius=None` não se torna raio zero. Acesso axial, sequência de montagem, ferragens reais e tolerâncias exigem conferência física. Um soquete de outro sistema não certifica o conjunto ASTM escolhido.

A montagem e o aperto são requisitos próprios, conforme NBR 6.3.1 e 6.8. Parafusos A490 sob tração ou tração combinada com corte exigem protensão; a interface não autoriza aperto simples irrestrito. A protensão não recebe crédito como resistência ao deslizamento nesta rota. A declaração de demandas externas na interface refere-se às ações, geometria, materiais e detalhe dos enrijecedores atuais; alterações físicas a invalidam sem apagar os valores fornecidos.

`support_end_negative` e `support_end_positive` medem a distância da interseção das almas às duas extremidades físicas da viga inferior ao longo de y. Iniciam `None`; a ausência não representa extensão infinita nem borda zero. Essa informação é separada do referencial longitudinal das ações da superior. `reference_x` não fornece a cota do término físico da viga superior; a terminação executiva continua não especificada.

O par de enrijecedores recebe somente verificações de detalhe. NBR 5.7.9.5:

`bs+tw/2 >= largura_carregada/3`

`ts >= max(t_carregada/2,bs/16)`

Também são examinados encaixe, extensão mínima, recortes e filetes. A resistência das placas e de suas soldas exige forças reais por placa, eventual flexão/tração e o estado local pretendido. As condições específicas de 5.7.9.2 a 5.7.9.4 não autorizam automaticamente V/2, área efetiva adicional duplicada ou alma central sob contato excêntrico.

## Organização de resultados e exportação

- `RESISTANCE`: demandas e capacidades locais com fonte e escopo.
- `GEOMETRY`: medidas, limites e relações de detalhe; não compõem aprovação resistente.
- `MODEL`: equilíbrio, origem e limites da transferência externa.
- `PASS`, `FAIL`, `PENDING` e `OUTSIDE_SCOPE` são estados por verificação. Falhas locais não são apagadas pela pendência agregada.
- Cada linha registra `id`, `name`, `demand`, `resistance`, `eta`, `unit`, `reference`, `equation`, `notes`, `status` e `category`.
- O mínimo de resistência da NBR 6.1.5.2 permanece nota normativa até definir categoria de membro e interpretação direcional. Não se inventam 45 kN independentes em N e V.

`lro.beam_on_beam_report.build_docx(c, result=None)` retorna bytes de DOCX editável. `create_report` é alias do mesmo exportador. O argumento `result` é ignorado sem ser lido: a exportação chama `evaluate(c)` incondicionalmente. O desenho usa `image_bytes(c)` e também reavalia sua entrada. Não há atalho de aprovação por resultado salvo, cache ou objeto fornecido pelo chamador.

Tabelas e equações OMML são editáveis no Word. Apresentação numérica com duas casas decimais, notação científica para evitar falso zero; constantes exatas, designações e referências são preservadas. A apresentação não retroalimenta o motor nem altera o projeto JSON de precisão integral. O Word distingue limites geométricos, capacidades resistentes e estado de modelo, inclui todas as entradas e mantém explícitos os desconhecidos.

## Fontes e limite da evidência

1. ABNT NBR 8800:2024, exemplar corrigido fornecido com Errata 1:2025. SHA256 `2289dd360ae938982f44ce6b0633968652199604867172e9d0d454e71256b16d`. Cláusulas de ações, parafusos, furos, soldas e enrijecedores foram inspecionadas no trabalho de qualificação em 13/10/2026.
2. [AISC Manual Companion v16](https://www.aisc.org/aisc/publications/steel-construction-manual/manual-companion-for-16th-edition/), P901-23W, exemplo J.7, J-24 a J-27. SHA256 `ec25b52e1d7b6b9ec9e5eaccc27452153208784d7d715908daa2595dd8f92423`. Esse exemplo trata estados locais da inferior e assume a superior previamente verificada. Não qualifica a chapa intermediária com N, a alavanca dos parafusos ou o par inferior deste detalhe.
3. [Gerdau Perfis Estruturais Segmento Industrial](https://gsn.gerdau.com/sites/gsn_gerdau/files/downloadable_files/Folder%20Perfis%20Estruturais%20Gerdau%20-%20Segmento%20Industrial.pdf), tabela dimensional visualmente conferida, página 3. Não fornece tolerâncias fabris completas nem certifica o aço comprado.

O contrato-fonte `IMPLEMENTATION_CONTRACT.md` e o recibo `QUALIFICATION_RECEIPT.json` são evidências de auditoria retidas separadamente do código, junto ao trabalho de qualificação de 13/10/2026. Não se pressupõe um caminho relativo externo disponível no pacote da aplicação. Este documento registra o método da implementação parcial, sem ampliar a qualificação das fontes.

## Ensaios do relatório

`tests/test_beam_on_beam_report.py` verifica reavaliação obrigatória, rejeição de autoridade de resultados fornecidos, preservação integral da entrada, categoria de cada check, todos os campos de entrada, equações Word nativas, desconhecidos explícitos, casos adversos e entrada inválida. O DOCX de exemplo deve ser renderizado pelo fluxo de documentos e todas as páginas inspecionadas antes de declarar qualidade visual. Teste estrutural de XML não substitui inspeção do desenho e das páginas renderizadas.
