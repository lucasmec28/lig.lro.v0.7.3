"""Regenerate affected 4E examples from explicitly selected corrected SOURCE.

Usage: python generate_current_witnesses.py SOURCE OUTPUT --expected-version VERSION
Writes native JSON, current result snapshots, and compact/detailed Word only in
OUTPUT. It does not load saved results or fall back to another source checkout.
For the four-root APP use the separate independent_4e_column_demands replay.
"""
from pathlib import Path
import argparse
from dataclasses import replace
import hashlib
import json
import sys

p = argparse.ArgumentParser()
p.add_argument('source'); p.add_argument('output'); p.add_argument('--expected-version', required=True)
a = p.parse_args(); root = Path(a.source).resolve(); out = Path(a.output).resolve()
assert (root/'lro/end_plate.py').is_file(), 'Explicit unpacked source required'
assert out != root and not out.is_relative_to(root), 'Keep generated artifacts outside the selected source'
assert not any(k == 'lro' or k.startswith('lro.') for k in sys.modules), 'Start a clean Python process'
sys.path.insert(0, str(root)); sys.dont_write_bytecode = True
from lro import end_plate as ep
from lro.end_plate_report import create_report
from lro.models import VERSION
assert VERSION == a.expected_version, (VERSION, a.expected_version)
assert ep.MOMENT_REVISION == 'endplate-4e-column-flange-demand-20261012-v1'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
watched = ['lro/end_plate.py', 'lro/end_plate_report.py', 'lro/column_checks.py', 'lro/models.py']
before = {k: sha(root/k) for k in watched}
base = replace(ep.presets()['Engastada · extensão acima e abaixo'], pfo=60., pfi=45., V=45000.)
inputs = [(f'4E_M{sign}_N{n:+g}', replace(base, M=sign*40e6, N=n*1000.))
          for sign in (-1, 1) for n in (-2, 0, 2)]
inputs.append(('4E_negative_NM_minimum', replace(base, M=-40e6, N=-2000., V=40000.)))
out.mkdir(parents=True, exist_ok=True); records = []
for label, c in inputs:
    r = ep.evaluate(c); assert r.status == 'ATENDE ÀS VERIFICAÇÕES REALIZADAS'
    native = c.to_dict(); assert ep.EndPlate.from_dict(native) == c
    files = {'native': out/(label+'.json'), 'results': out/(label+'_results.json'),
             'compact': out/(label+'_compact.docx'), 'detailed': out/(label+'_detailed.docx')}
    files['native'].write_text(json.dumps(native, ensure_ascii=False, indent=2, allow_nan=False))
    files['results'].write_text(json.dumps(ep.moment_snapshot(c,r), ensure_ascii=False, indent=2, allow_nan=False))
    for mode in ('compact', 'detailed'):
        files[mode].write_bytes(create_report(c, r, detailed=mode=='detailed'))
    records.append({'label': label, 'input_sha256': ep.input_digest(c),
                    'N': c.N, 'V': c.V, 'M': c.M, 'pfo': c.pfo, 'pfi': c.pfi,
                    'cases': [{'label':x['label'], 'actions':x['actions']} for x in r.case_records],
                    'files': {k:{'name':v.name,'sha256':sha(v)} for k,v in files.items()}})
modules = {}
for name, mod in sorted(sys.modules.items()):
    if (name == 'lro' or name.startswith('lro.')) and getattr(mod,'__file__',None):
        path = Path(mod.__file__).resolve(); assert path.is_relative_to(root), (name, path)
        modules[name] = {'relative_path':str(path.relative_to(root)), 'sha256':sha(path)}
assert before == {k:sha(root/k) for k in watched}, 'Selected runtime changed during generation'
receipt = {'status':'PASS_GENERATED_FROM_CORRECTED_CURRENT_SOURCE', 'app_version':VERSION,
           'method_revision':ep.MOMENT_REVISION, 'runtime_sha256':before, 'module_origins':modules,
           'witnesses':records, 'warning':'Regression examples only, not structural project or fabrication approval.'}
(out/'CURRENT_WITNESSES_RECEIPT.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2))
print(json.dumps({'status':receipt['status'],'witnesses':len(records),'output':str(out)}))
