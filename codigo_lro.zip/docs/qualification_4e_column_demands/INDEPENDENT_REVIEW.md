# Independent review: bounded 4E column-demand correction

Reviewed 2026-10-12 UTC. Read-only target: `moment_4e_column_correction20261012/candidate`; baseline: frozen `review0938/source0938`. No candidate edits by this reviewer. Original and 0939 are untouched by this reviewer.

## Decision

**The changed demand/capacity pair is coherent for the existing finite 4E MOMENT route.** Correcting column-web local yielding to `max(Ff,Fc)` and crippling to `Fc` is consistent with the supplied DG39 source evidence and the independently inspected NBR capacity definitions. This does not qualify additional end-plate topologies, column reinforcement, arbitrary geometry, global stability, seismic behavior, fabrication, or project safety.

**GO for this bounded source correction.** Independent numerical/native/report-content checks pass. The final six-module regression slice has **489 passed, zero failed/errors/skipped**. The initial obsolete 4E method-revision assertion was updated exactly and the entire original slice rerun, with the 61 new dedicated cases included. No other pre-existing assertion was changed in this correction.

## Primary-source capacity inspection

Independently rendered and visually read the local supplied NBR 8800:2024 corrected-2025 PDF, printed pp.63–65, PDF pages85–87. Source PDF SHA-256: `2289dd360ae938982f44ce6b0633968652199604867172e9d0d454e71256b16d`. Reviewer image receipts: `nbr-085.png`, `nbr-086.png`, `nbr-087.png`.

- §5.7.1 applies to localized forces perpendicular to I/H flange faces and centered on the web.
- §5.7.3.1 covers local web yielding under tension **or** compression caused by a force on a flange. §5.7.3.2(b) is `FRd=1.10(2.5k+ln)fy tw/γa1`; `k` includes flange thickness plus the weld-root/radius contribution and `ln` is loaded length along the member. Thus the existing `k=tf, ln=0` implementation discards nonnegative contributions and retains the weaker end-position branch.
- §5.7.4.1 covers local web crippling under compression caused by a force on a flange. §5.7.4.2(b), at `ln/d=0`, reduces to `FRd=0.33 tw² sqrt(E fy tf/tw)/γa1`. The existing function remains this expression. Positive loaded length and the internal-position branch provide no reason to reduce this retained lower-bound capacity.
- Therefore yielding receives the envelope of positive tension/compression flange-force magnitudes and crippling receives only the compression magnitude. The NBR force definitions do not require replacing those demands by the distinct bolt/contact resultants.

The DG39 force-route evidence was provided by the parent/source reader: §3.5 printed p.37 adds half axial compression to compression flange force; §3.7.6 printed pp.47–48, Eq.3-48 uses the flange-force route of Eq.3-39; Example5.3-1 printed p.132 uses Pu=2510/(24−3/8)=106.243kip against yielding/crippling. This reviewer did not independently reopen DG39 and does not present the relay as its own pixel inspection.

## Implementation review

- Only 4E obtains changed numerical column demands. The selector now uses `kind=='moment'`; existing 4ES/8ES already used the same Ff/Fc expressions.
- `Ff=abs(M)/(d−tf)+max(N,0)/2`, `Fc=abs(M)/(d−tf)+max(−N,0)/2`. Ignoring beneficial axial force on the opposite flange preserves the existing conservative signed-force convention.
- Both capacities and `column_checks.py` remain byte-identical. No new loading length, end distance, radius or reinforcement credit is introduced.
- Bolt tension, `T`, `C=max(T−N,0)` and the separate contact check are unchanged. In the reviewed 40kNm, N=−2kN, pfo60/pfi45 witness, column demand is 103.511532547kN while contact remains 102.578325371kN. This difference is intentional.
- Reversing M retains force magnitudes and changes the physical active side in symmetric details. Top-only negative M remains rejected. Each minimum-force case uses its own N/V with original M, and the governing row is preserved whole. The unresolved-minimum domain case retains its original result and stays blocked.
- A 4E-specific method revision is necessary and appropriate: old native inputs are accepted/recalculated without old saved results authorizing the changed method. Input digests are preserved. 4ES/8ES/PINNED revisions remain exact.
- The changed rows contain explicit source, force equations, Ff/Fc substitutions and separate-contact wording. Native geometry exposes the two column forces. Compact/detailed Word text states the same force route and unchanged capacity assumptions.

## Independent execution

`review_pair.py` loads baseline and candidate under separate package names, compares unchanged data exactly, and evaluates force/capacity expressions independently of the application helpers.

- 168 signed/preset configurations, including 161 calculated MOMENT case records. This is a separate evidence count from the existing pytest cases.
- 12 local-capacity threshold checks: both signs of M; utilization 1−1e−8, 1, 1+1e−8 for both mechanisms. Existing comparison policy is preserved and above-threshold rows fail.
- 6 old native reimports, exact input-digest retention, roundtrip verification and forged-snapshot rejection/recalculation.
- 12 compact/detailed Word content checks. PINNED/4ES/8ES report text is exact versus baseline.
- Separate `review_fixture_parity.py`: 23 historic end-plate native fixtures plus113 row-geometry/scope perturbations, all passing. No historical fixture status changed in this set. Inputs, issues and every non-column numerical row are preserved; 4ES/8ES/PINNED native snapshots are exact.
- Independent pytest slice: the five pre-existing modules for end plates, 4ES, 8ES, MOMENT case audit and PINNED audit, plus the dedicated 4E correction module. Final result: **489 passed, zero failed/errors/skipped** (`final_amended_regressions.log/.xml`). The initial 427-pass/1-stale-revision run is retained in `existing_regressions.log/.xml`, not added to the final count.
- The dedicated tests were read: the 12 synthetic-capacity fixtures place the retained capacity between old/new demands and verify that the intended local resistance failure alone changes overall status. They are labeled arithmetic fixtures, not catalog sections or design qualification. The report test deliberately passes a stale result and verifies current-input recalculation.

Machine-readable receipts: `INDEPENDENT_PAIR_RECEIPT.json` and `INDEPENDENT_FIXTURE_PARITY.json`; reproducible scripts and source hashes are retained beside this note.

## Verification limits

This is bounded source and engine/native/report-text acceptance. This reviewer did not run the entire application aggregate, browser/pixel UI acceptance, or visual pagination/layout review of generated Word files. It did not modify or validate the pending 0939 package. Regression comparison does not substitute for full structural qualification.


## Portable integration replay, final amendment

The dedicated test module now includes six pfo40 cases showing that the source-consistent correction can also remove an old column-only failure. Both directions were independently replayed against frozen0938 with unchanged contact. The final six-module slice is 489/489; the earlier 483-case run is superseded, not additive.

Reviewed the final `docs/END_PLATE_4E_COLUMN_DEMAND_CORRECTION.md`, including its final paragraphs distinguishing source-only generation from actual packaged-loader replay. It is consistent with the reviewed mechanics and limits.

`portable_4e/` contains a self-contained, no-generation-mode replay and explicit frozen expectations. Final source replay: 61 literal input cases, 78 hand-calculated case records, 12 compact/detailed report-text checks, 12 increasing-demand synthetic thresholds and 6 reducing-demand thresholds. Unchanged 4ES/8ES/PINNED commitments were checked against baseline 0938 before freezing. Native roundtrips and forged saved results are checked. Only the global app version is normalized. A copy-only guard test passed with VERSION changed to 0.9.40-integration-replay-test and rejected an intentional end_plate.py byte mutation.

The APP mode invokes the actual four-root loader, binds its archive digest, checks the shipped replay files, verifies the three reviewed source hashes and requires every imported lro module to originate in that extracted payload. **The actual integrated APP must still run this gate; only source-mode and copy-only guard tests were executed by this reviewer at this stage.** No frozen-source or optional-companion runtime dependency is present.

The parent reports a 656-test/12-module source suite and visual review of 22 representative Word pages. Those are parent evidence, not additional independent executions by this reviewer, and are not added to the 489-test count above.
