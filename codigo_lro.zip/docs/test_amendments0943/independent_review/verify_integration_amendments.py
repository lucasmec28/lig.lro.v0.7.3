"""Independent read-only verification of the final integration and test contract.

Writes evidence only beneath integration_review. It never edits application source
or imports/runs the integrator's source-mutating scripts.
"""
from pathlib import Path
import ast, hashlib, json, difflib, subprocess, sys, os, datetime, shutil

W=Path(__file__).resolve().parents[2]
R=W/'review0943'; S=R/'source0943'; B=W/'review0942/source0942'
O=Path(__file__).resolve().parent
OLD='0.9.42-result-indices-base-key-plate-dev'; NEW='0.9.43-welded-support-angles-dev'
EXPECTED_HOLD='60011ca5081591fd853dfbacf437630d67e669428931061ba7692debddf4d4d8'
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
HB=lambda b:hashlib.sha256(b).hexdigest()
HT=lambda t:HB(t.encode())
J=lambda p:json.loads(Path(p).read_text())
def save(p,v):Path(p).write_text(json.dumps(v,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
def inventory(root):
 return sorted([dict(path=p.relative_to(root).as_posix(),bytes=p.stat().st_size,sha256=H(p)) for p in root.rglob('*') if p.is_file() and not {'__pycache__','.pytest_cache'} & set(p.relative_to(root).parts) and p.suffix not in {'.pyc','.pyo'}],key=lambda r:r['path'])
def runtime():
 return {p.relative_to(S).as_posix():H(p) for pat in ('app.py','lro/*.py','tests/**/*.py','tests/fixtures/**/*','data/*') for p in S.glob(pat) if p.is_file()}
def one(text,old,new):
 assert text.count(old)==1,(old,text.count(old)); return text.replace(old,new)
def ast_dump(node):return ast.dump(node,include_attributes=False)
def assignment(path,name):
 return next(n.value for n in ast.parse(path.read_text()).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets))
def route_selector(path):
 nodes=[n for n in ast.walk(ast.parse(path.read_text())) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='selectbox' and any(k.arg=='key' and isinstance(k.value,ast.Constant) and k.value.value=='connection_family' for k in n.keywords)]
 assert len(nodes)==1;return nodes[0].args[1]
def line(text,prefix):
 rows=[x+'\n' for x in text.splitlines() if x.startswith(prefix)];assert len(rows)==1,(prefix,len(rows));return rows[0]

def main():
 assert H(R/'RUNTIME_TEST_HOLD0943.json')==EXPECTED_HOLD
 held=J(R/'RUNTIME_TEST_HOLD0943.json');assert held['version']==NEW
 before=runtime();assert before==held['files']
 rows=J(W/'review0942/SOURCE_FILES0942.json')['files']
 assert len(rows)==2520 and inventory(B)==rows
 base={x['path']:x for x in rows}
 tree=HB(json.dumps(rows,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
 assert tree=='dc069d4ff41ba5538b2596a3a0de42016ad62c873334902dabee0725f93f03f0'
 integrated=J(R/'INTEGRATED_PATCH_RECEIPT.json')
 assert [p['component'] for p in integrated['patches']]==['1L','2L']
 expected_bindings=[
  {'implementation_receipt':'3e85dc75e266cd36139131202d93f22aa79518249fc0ebd6419427613c14f998','patch':'c84c0ab0dd80668ad04eaab54813aade0cc187de00d1a8ce83e55dffe6bb3c57','independent_scoped_GO':'ccb270267f71ea423df10b6e6dbed9966cdac7c1fe9f5e1604ee3b1dd61a4182'},
  {'implementation_receipt':'fd295f3ac09de86ea75bc1db43013e03e56209d9575143d7ac218789707c72ed','source_receipt':'bb2acc0f5838cf34568ac5f98a5dfda5486f87a342b2628b16b6fe6f8ff5fe2d','patch':'7f3dbfdbeea6866e1f44345fe5295e2622af816c8de0cc0cd306d9b50c695fdf','independent_scoped_GO':'a6a8883c4d871379d130cc19821228f9b743e1ec98d5fcf91cd899a4f6c30d4c'}]
 component_files={};sources=[];replays=[]
 for i,entry in enumerate(integrated['patches']):
  for key,want in expected_bindings[i].items():assert entry[key]['sha256']==want==H(entry[key]['path'])
  reviewed=J(entry['independent_scoped_GO']['path']);assert 'GO' in reviewed['status'] and not reviewed.get('blocking_findings',[])
  root=Path(entry['implementation_receipt']['path']).parent;candidate=root/'source0943';sources.append(candidate)
  sr=J(root/'FINAL_RECEIPT.json')['source_delta'] if i==0 else J(root/'SOURCE_RECEIPT.json')
  hashes=sr['sha256'] if i==0 else sr['source_sha256']
  assert set(sr['modified'])=={'app.py','lro/guided_selection.py','tests/test_guided_selection0919.py'}
  for n,h in hashes.items(): assert H(candidate/n)==h
  replay=O/f'component_patch_replay_{i+1}';replay.mkdir(exist_ok=True)
  # Exact original 0941 inputs are reconstructed sparsely, outside source.
  for n in sr['modified']:
   dest=replay/n;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(W/'review0941/source0941'/n,dest)
  for n in sr['new']:
   dest=replay/n
   if dest.exists():dest.unlink()
  cmd=['patch','-p1','--batch','--fuzz=0','-i',entry['patch']['path']]
  run=subprocess.run(cmd,cwd=replay,capture_output=True,text=True)
  (O/f'component_patch_replay_{i+1}.log').write_text(run.stdout+run.stderr)
  assert run.returncode==0,(cmd,run.stdout,run.stderr)
  assert all(H(replay/n)==h for n,h in hashes.items())
  replays.append({'component':entry['component'],'files_reproduced':len(hashes),'patch_sha256':entry['patch']['sha256'],'no_fuzz':True})
  for n in sr['new']:
   assert n not in base and H(S/n)==hashes[n]
   component_files[n]=hashes[n]
 # Compare app in reverse: remove only the exact reviewed additions and undo
 # release identity. Equality proves every inherited byte and runtime branch remains.
 app=(S/'app.py').read_text();stripped=app
 modules=['single','double'];symbols=['WELDED_SUPPORT_SINGLE_ANGLE_FAMILY','WELDED_SUPPORT_DOUBLE_ANGLE_FAMILY']
 for source,mod,symbol in zip(sources,modules,symbols):
  original=(source/'app.py').read_text()
  required=line(original,f"    'welded_support_{mod}_angle',")
  imp=f'from lro.welded_support_{mod}_angle import FAMILY as {symbol}\n'
  dispatch=f'if family=={symbol}:\n    from lro.welded_support_{mod}_angle_ui import render\n    render()\n    st.stop()\n\n'
  assert required in original and imp in original and dispatch in original
  stripped=one(stripped,required,'');stripped=one(stripped,imp,'');stripped=one(stripped,dispatch,'')
 stripped=one(stripped,',WELDED_SUPPORT_SINGLE_ANGLE_FAMILY,WELDED_SUPPORT_DOUBLE_ANGLE_FAMILY]',']')
 assert stripped.replace(NEW,OLD)==(B/'app.py').read_text()
 base_routes=route_selector(B/'app.py').elts;final_routes=route_selector(S/'app.py').elts
 assert len(base_routes)==19 and len(final_routes)==21
 assert list(map(ast_dump,final_routes[:19]))==list(map(ast_dump,base_routes))
 assert [ast_dump(n) for n in final_routes[19:]]==["Name(id='WELDED_SUPPORT_SINGLE_ANGLE_FAMILY', ctx=Load())","Name(id='WELDED_SUPPORT_DOUBLE_ANGLE_FAMILY', ctx=Load())"]
 # Exact 19-family catalogue, including all scopes/captions, is preserved.
 guide=(S/'lro/guided_selection.py').read_text();removed_guide=guide
 ids=['welded_support_single_angle','welded_support_double_angle_shear']
 for source,id_ in zip(sources,ids):removed_guide=one(removed_guide,line((source/'lro/guided_selection.py').read_text(),f"    Family('{id_}',"),'')
 removed_guide=one(removed_guide,'Catalogue-only navigation for the implemented connection families.','Catalogue-only navigation for the nineteen implemented connection families.')
 assert removed_guide==(B/'lro/guided_selection.py').read_text()
 old_f=assignment(B/'lro/guided_selection.py','FAMILIES').elts;new_f=assignment(S/'lro/guided_selection.py','FAMILIES').elts
 assert len(old_f)==19 and len(new_f)==21 and list(map(ast_dump,old_f))==list(map(ast_dump,new_f[:19]))
 assert [ast.literal_eval(n.args[0]) for n in new_f[19:]]==ids
 assert ast.literal_eval(new_f[18].args[0])=='corner_gusset'
 # Reconstruct the guided-selection contract independently from original source
 # and exact reviewed rows. No mechanical expectation is changed.
 expected_guided=(B/'tests/test_guided_selection0919.py').read_text()
 marker=line(expected_guided,"    ('corner_gusset',")
 additions=''.join(line((src/'tests/test_guided_selection0919.py').read_text(),f"    ('{id_}',") for src,id_ in zip(sources,ids))
 expected_guided=one(expected_guided,marker,marker+additions)
 expected_guided=one(expected_guided,"'welded_double_angle_r015'),","'welded_double_angle_r015', 'welded_support_single_angle', 'welded_support_double_angle_shear'),")
 guided_repl=[('len(guide.FAMILIES) == len(set(ids(guide.FAMILIES))) == 19','len(guide.FAMILIES) == len(set(ids(guide.FAMILIES))) == 21'),('len({f.route_select_value for f in guide.FAMILIES}) == 19','len({f.route_select_value for f in guide.FAMILIES}) == 21'),('sum(len(f.interface_tags) for f in guide.FAMILIES) == 20','sum(len(f.interface_tags) for f in guide.FAMILIES) == 22')]
 for a,b in guided_repl:expected_guided=one(expected_guided,a,b)
 expected_guided=expected_guided.replace(OLD,NEW)
 assert expected_guided==(S/'tests/test_guided_selection0919.py').read_text()
 # Explicit review whitelist, not inferred from the integrator's receipt.
 catalog={
 'tests/test_one_root_compression_ui0937.py':[('assert len(FAMILIES)==19','assert len(FAMILIES)==21')],
 'tests/test_end_plate_mre12_artifacts0941.py':[("assert len(a.selectbox(key='connection_family').options)==19","assert len(a.selectbox(key='connection_family').options)==21")],
 'tests/test_opposed_bolted_integration0931.py':[('assert len(guide.FAMILIES) == 19','assert len(guide.FAMILIES) == 21')],
 'tests/test_welded_double_angle_gusset_ui0928.py':[('assert len(FAMILIES) == 19','assert len(FAMILIES) == 21')],
 'tests/test_welded_opposed_angle_gusset_ui0930.py':[('assert len(FAMILIES) == 19','assert len(FAMILIES) == 21')],
 'tests/test_welded_angle_gusset_ui0926.py':[('assert len(FAMILIES)==19','assert len(FAMILIES)==21'),("assert len(at.selectbox(key='connection_family').options)==19","assert len(at.selectbox(key='connection_family').options)==21")],
 'tests/test_corner_integration0932.py':[('assert len(guide.FAMILIES) == 19','assert len(guide.FAMILIES) == 21'),("guide.FAMILIES[-1].id == 'corner_gusset'","guide.FAMILIES[18].id == 'corner_gusset'"),('guide.FAMILIES[-1].route_select_value == FAMILY','guide.FAMILIES[18].route_select_value == FAMILY'),("assert 'BOLTED_ANGLE_GUSSET_FAMILY,CORNER_GUSSET_FAMILY]' in s","assert 'BOLTED_ANGLE_GUSSET_FAMILY,CORNER_GUSSET_FAMILY,WELDED_SUPPORT_SINGLE_ANGLE_FAMILY,WELDED_SUPPORT_DOUBLE_ANGLE_FAMILY]' in s")],
 'tests/test_end_plate_8es_artifacts0924.py':[("assert len(at.selectbox(key='connection_family').options)==19","assert len(at.selectbox(key='connection_family').options)==21")],
 'tests/test_axial_single_angle_routes.py':[('assert len(selector.options) == 19','assert len(selector.options) == 21')]}
 version_paths={'app.py','lro/models.py','tests/test_end_plate_mre12_artifacts0941.py','tests/test_corner_integration0932.py','tests/test_guided_selection0919.py'}
 expected_pre_version={'app.py':app.replace(NEW,OLD),'tests/test_guided_selection0919.py':expected_guided.replace(NEW,OLD)}
 versions=J(S/'docs/test_amendments0943/VERSION_ONLY_AMENDMENTS.json');assert {r['path'] for r in versions}==version_paths
 for r in versions:
  n=r['path'];initial=expected_pre_version.get(n,(B/n).read_text());updated=initial.replace(OLD,NEW)
  assert r['before_sha256']==HT(initial) and r['after_sha256']==HT(updated)
  assert r['old_token']==OLD and r['new_token']==NEW and r['replacement_count']==initial.count(OLD) and r['only_literal_version_changed'] is True
 catalog_receipt=J(S/'docs/test_amendments0943/CATALOG_ONLY_AMENDMENTS.json')
 assert {x['path'] for x in catalog_receipt['amendments']}==set(catalog)
 patch=[]
 for n,pairs in catalog.items():
  orig=(B/n).read_text();pre=orig.replace(OLD,NEW) if n in version_paths else orig;expected=pre
  for a,b in pairs:expected=one(expected,a,b)
  assert expected==(S/n).read_text(),n
  rec=next(x for x in catalog_receipt['amendments'] if x['path']==n)
  assert rec['before_sha256']==HT(pre) and rec['after_sha256']==HT(expected)
  assert rec['replacements']==[{'old':a,'new':b} for a,b in pairs]
  patch.extend(difflib.unified_diff(pre.splitlines(True),expected.splitlines(True),fromfile='a/'+n,tofile='b/'+n))
 assert ''.join(patch)==(S/'docs/test_amendments0943/CATALOG_ONLY_AMENDMENTS.patch').read_text()
 allowed_changed=set(catalog)|version_paths|{'lro/guided_selection.py','README.md'}
 actual_changed={n for n,r in base.items() if not (S/n).is_file() or H(S/n)!=r['sha256']}
 assert actual_changed==allowed_changed,(actual_changed^allowed_changed)
 assert (S/'lro/models.py').read_text()==(B/'lro/models.py').read_text().replace(OLD,NEW)
 # Full immutable 0942 preservation includes engines, presentation/report modules,
 # old tests/fixtures, data, and support/base-plate domain boundaries.
 untouched=[r for r in rows if r['path'] not in allowed_changed]
 assert all(H(S/r['path'])==r['sha256'] for r in untouched)
 assert H(S/'lro/load_conventions.py')==H(B/'lro/load_conventions.py')
 assert H(S/'tests/test_load_conventions0929.py')==H(B/'tests/test_load_conventions0929.py')
 assert 'assert len(lc.CONVENTIONS) == 19' in (S/'tests/test_opposed_bolted_integration0931.py').read_text()
 conventions=assignment(S/'lro/load_conventions.py','CONVENTIONS');assert len(conventions.keys)==19
 # The only permitted portability edit removes path-import/bootstrap lines.
 draw_source=W/'welded_support_1l0943/artifact_qa/drawing/test_single_angle_drawing.py'
 draw_target=S/'tests/test_welded_support_single_angle_drawing0943.py'
 original=draw_source.read_text();portable=original
 removed=['from pathlib import Path\n','import sys\n','ROOT = Path(__file__).resolve().parents[2]\n',"sys.path.insert(0, str(ROOT/'source0943'))\n"]
 for x in removed:portable=one(portable,x,'')
 assert portable==draw_target.read_text()
 def funcs(text):return {n.name:ast_dump(n) for n in ast.parse(text).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
 assert funcs(original)==funcs(portable)
 drawing_tests=[n for n in funcs(original) if n.startswith('test_')];assert len(drawing_tests)==11
 port=J(S/'docs/test_amendments0943/SINGLE_DRAWING_TEST_PORTABILITY.json')
 assert port['source_sha256']==H(draw_source) and port['target_sha256']==H(draw_target)
 expected_runtime_additions={n for n in component_files if n.startswith(('lro/','tests/'))}|{draw_target.relative_to(S).as_posix()}
 actual_runtime_additions={n for n in before if n not in base}
 assert actual_runtime_additions==expected_runtime_additions
 collection=(R/'COLLECTION0943_FINAL.txt').read_text();caseids=[ln for ln in collection.splitlines() if ln.startswith('tests/') and '::' in ln]
 assert len(caseids)==len(set(caseids))==6311
 drawing_caseids=[x for x in caseids if x.startswith('tests/test_welded_support_single_angle_drawing0943.py::')]
 assert len(drawing_caseids)==11 and {x.split('::')[1] for x in drawing_caseids}==set(drawing_tests)
 oracle_case='tests/test_axial_double_angle.py::test_bolt_bearing_oracle_file_and_opposite_loaded_free_ends'
 assert oracle_case in caseids and H(S/'tests/test_axial_double_angle.py')==H(B/'tests/test_axial_double_angle.py')
 oracle_path=(S/'tests/test_axial_double_angle.py').resolve().parents[3]/'next_connection_scope/bolt_bearing_oracle.json'
 assert not oracle_path.exists()
 # Reviewer runs only the eleven portable drawing cases and one inherited
 # missing-oracle case; the complete aggregate remains the integrator's gate.
 env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(S)+os.pathsep+str(W/'connections_audit/test_dependencies'),MPLBACKEND='Agg')
 focused=[]
 for label,case,expected_rc in [('portable_drawing','tests/test_welded_support_single_angle_drawing0943.py',0),('inherited_missing_oracle',oracle_case,1)]:
  xml=O/(label+'.xml');log=O/(label+'.log')
  cmd=[sys.executable,'-m','pytest','-q','-p','no:cacheprovider',case,'--junitxml='+str(xml)]
  with log.open('w') as f:pr=subprocess.run(cmd,cwd=S,env=env,stdout=f,stderr=subprocess.STDOUT)
  assert pr.returncode==expected_rc,(label,pr.returncode,log.read_text()[-2000:])
  import xml.etree.ElementTree as ET
  root=ET.parse(xml).getroot();cases=list(root.iter('testcase'));counts={'tests':len(cases),'failures':sum(c.find('failure') is not None for c in cases),'errors':sum(c.find('error') is not None for c in cases),'skips':sum(c.find('skipped') is not None for c in cases)}
  assert counts==({'tests':11,'failures':0,'errors':0,'skips':0} if label=='portable_drawing' else {'tests':1,'failures':1,'errors':0,'skips':0})
  if label=='inherited_missing_oracle':assert 'FileNotFoundError' in log.read_text() and 'bolt_bearing_oracle.json' in log.read_text()
  focused.append({'label':label,'returncode':pr.returncode,'command':cmd,'counts':counts,'junit':str(xml),'junit_sha256':H(xml),'log':str(log),'log_sha256':H(log)})
 assert runtime()==before==held['files'] and H(R/'RUNTIME_TEST_HOLD0943.json')==EXPECTED_HOLD
 assert inventory(B)==rows
 evidence={
  'status':'SCOPED_GO_INTEGRATION_AND_TEST_AMENDMENTS_ONLY_NOT_RELEASE','completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'blocking_findings':[],
  'scope':'Final held source: reviewed-delta identity, additive integration, inherited runtime/test preservation, version/catalog-only test amendments, and exact eleven-test drawing portability. This is not a mechanical requalification or full application/package approval.',
  'application_source_edited_by_reviewer':False,'full_aggregate_run_by_reviewer':False,
  'hold':{'path':str(R/'RUNTIME_TEST_HOLD0943.json'),'sha256':EXPECTED_HOLD,'runtime_test_fixture_data_files':len(before),'unchanged_through_review':True},
  'baseline':{'path':str(B),'inventory_path':str(W/'review0942/SOURCE_FILES0942.json'),'inventory_sha256':H(W/'review0942/SOURCE_FILES0942.json'),'tree_sha256':tree,'files':len(rows),'all_immutable_files_match':True},
  'component_bindings':expected_bindings,'independent_patch_replays':replays,'exact_reviewed_new_component_files':component_files,
  'additive_shared_merge':{'app_original_bytes_equal_after_removing_only_reviewed_additions_and_new_version':True,'guide_original_bytes_equal_after_removing_two_reviewed_rows_and_docstring_count':True,'guided_test_exact_independent_reconstruction':True,'original_route_indices':list(range(19)),'corner_index':18,'append_order':['1L','2L'],'total_routes':21,'interface_tag_total':22},
  'inherited_files':{'byte_identical':len(untouched),'changed_whitelist':sorted(allowed_changed),'test_files_changed':sorted(n for n in actual_changed if n.startswith('tests/')),'all_other_tests_fixtures_runtime_and_data_unchanged':True,'models_change_only_global_version':True,'end_plate_result_index_and_base_plate_runtime_preserved_byte_for_byte':True},
  'amendments':{'version_receipt_sha256':H(S/'docs/test_amendments0943/VERSION_ONLY_AMENDMENTS.json'),'catalog_receipt_sha256':H(S/'docs/test_amendments0943/CATALOG_ONLY_AMENDMENTS.json'),'catalog_patch_sha256':H(S/'docs/test_amendments0943/CATALOG_ONLY_AMENDMENTS.patch'),'receipt_hash_chains_independently_verified':True,'load_conventions_count':19,'load_conventions_runtime_and_own_test_unchanged':True,'no_mechanical_expected_values_tolerances_or_skip_changes':True},
  'drawing_portability':{'source':str(draw_source),'source_sha256':H(draw_source),'target':str(draw_target),'target_sha256':H(draw_target),'removed_lines':removed,'all_function_ASTs_identical':True,'exact_all_other_text':True,'test_count':11,'tests':drawing_tests,'all_eleven_in_final_collection':True},
  'collection':{'path':str(R/'COLLECTION0943_FINAL.txt'),'sha256':H(R/'COLLECTION0943_FINAL.txt'),'unique_caseids':len(caseids),'is_a_test_pass':False},
  'focused_runs':focused,
  'known_unresolved_failure':{'caseid':oracle_case,'missing_path':str(oracle_path),'test_unchanged':True,'still_collected':True,'independently_reproduced_FileNotFoundError':True,'counted_as_failure_not_skip_xfail_or_pass':True,'scope_note':'Inherited missing external bolt_bearing_oracle.json remains unresolved and must remain an explicit failure in the aggregate/release qualification.'},
  'remaining_gates':['Complete held-source regression aggregate','Final runtime UI/artifact freshness and independent actual APP/loader release review'],
  'review_script':{'path':str(Path(__file__).resolve()),'sha256':H(__file__)},
  'integrator_inputs':{n:H(R/n) for n in ['prepare_final_run.py','integrate_double.py','SINGLE_ANGLE_INTEGRATION.json','INTEGRATED_PATCH_RECEIPT.json']}}
 save(O/'FINAL_INTEGRATION_REVIEW_RECEIPT.json',evidence)
 diff=''
 for n in sorted(actual_changed):
  diff+=''.join(difflib.unified_diff((B/n).read_text().splitlines(True),(S/n).read_text().splitlines(True),fromfile='source0942/'+n,tofile='source0943/'+n))
 (O/'INDEPENDENT_INHERITED_DIFF.patch').write_text(diff)
 print(json.dumps({'status':evidence['status'],'receipt':str(O/'FINAL_INTEGRATION_REVIEW_RECEIPT.json'),'sha256':H(O/'FINAL_INTEGRATION_REVIEW_RECEIPT.json'),'focused_runs':[x['counts'] for x in focused]},indent=2))

if __name__=='__main__':main()
