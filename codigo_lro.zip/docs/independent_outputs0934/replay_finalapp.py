"""FINALAPP-only output gate using approved source evidence and external test inputs.

Run from this evidence folder's environment, with only pinned test dependencies on
PYTHONPATH. The application source is loaded solely through the extracted APP.
"""
from pathlib import Path
import argparse,subprocess,sys,json,hashlib
from zipfile import ZipFile
from legacy_svg_normalization import normalize_svg,RULES as SVG_NORMALIZATION_RULES
p=argparse.ArgumentParser();p.add_argument('runtime',type=Path);p.add_argument('output',type=Path);a=p.parse_args()
here=Path(__file__).resolve().parent;app=a.runtime.resolve();out=a.output.resolve();out.mkdir(parents=True,exist_ok=True)
assert (app/'app.py').is_file() and (app/'codigo_lro.zip').is_file(),'Expected actual FINALAPP outer entry and embedded source ZIP'
assert not (app/'lro').exists(),'Do not substitute an already extracted source checkout for FINALAPP'
assert not out.is_relative_to(app),'Evidence stays outside application directory'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
approved=json.loads((here/'SOURCE_RUNTIME_HASHES.json').read_text())
expected=json.loads((here/'SOURCE_EXPECTED_OUTPUTS.json').read_text())
outer_before={p.name:sha(p) for p in app.iterdir() if p.is_file()}
with ZipFile(app/'codigo_lro.zip') as z:
 names=set(z.namelist());missing=[]
 for name,value in approved.items():
  if name=='requirements-dev.txt':continue
  if name not in names:missing.append(name);continue
  assert hashlib.sha256(z.read(name)).hexdigest()==value,('Embedded runtime differs',name)
 assert not missing,('Missing approved runtime',missing)

def run(script,*args):
 with (out/(Path(script).stem+'.log')).open('w') as log:
  subprocess.run([sys.executable,'-B',str(here/script),*map(str,args)],check=True,stdout=log,stderr=subprocess.STDOUT)
run('capture_cases.py',app,here/'CASES.json',out/'captures')
run('ui_callbacks.py',app,out/'callbacks')
run('artifact_semantics.py',out/'captures',out/'semantics')
run('legacy_long_group_callbacks.py',app,out/'legacy_long_group')
actual={x['tag']:x for x in json.loads((out/'captures/DOWNLOAD_RECEIPT.json').read_text())}
comparisons=[]
for row in expected:
 got=actual[row['tag']]
 assert got['status']==row['status'] and got['complete']==row['complete']
 for ext,ex in row['exports'].items():
  if ext=='.docx':continue
  assert got['exports'][ext]['sha256']==ex['sha256'],(row['tag'],ext)
 if 'word_members' in row:
  with ZipFile(got['exports']['.docx']['path']) as z:members={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.startswith('word/')}
  assert members==row['word_members'],(row['tag'],'Word XML/media differs')
 comparisons.append({'tag':row['tag'],'native_results_png_svg_exact':True,'word_xml_and_media_exact':'word_members' in row})
legacy_svg_comparisons=[]
legacy_actual={(x['adapter'],x['length']):x for x in json.loads((out/'legacy_long_group/LEGACY_LONG_GROUP_UI_ACCEPTANCE.json').read_text())}
for ex in json.loads((here/'LEGACY_EXPECTED_OUTPUTS.json').read_text()):
 got=legacy_actual[(ex['adapter'],ex['length'])]
 for key in ('status','global_pass','complete_checks','diagnostic_checks','report_blocked'):assert got[key]==ex[key],(ex['adapter'],ex['length'],key)
 for ext,record in ex['exports'].items():
  if ext=='.svg':
   normalized=normalize_svg(Path(got['exports'][ext]['path']).read_bytes())
   assert normalized['sha256']==ex['svg_normalized_sha256'],(ex['adapter'],ex['length'],'SVG differs beyond generated metadata/IDs')
   legacy_svg_comparisons.append({'adapter':ex['adapter'],'length':ex['length'],'source_raw_sha256':record['sha256'],'app_raw_sha256':got['exports'][ext]['sha256'],'all_other_svg_bytes_exact':True,'normalization':normalized})
  elif ext!='.docx':assert got['exports'][ext]['sha256']==record['sha256'],(ex['adapter'],ex['length'],ext)
 if 'word_members' in ex:
  with ZipFile(got['exports']['.docx']['path']) as z:members={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.startswith('word/')}
  assert members==ex['word_members'],(ex['adapter'],ex['length'],'Word XML/media differs')
legacy_prov=json.loads((out/'legacy_long_group/RUNTIME_PROVENANCE.json').read_text())
assert legacy_prov['before']==legacy_prov['after']
for name,value in legacy_prov['after'].items():assert approved[name]==value,('Legacy loaded runtime mismatch',name)
prov=json.loads((out/'captures/RUNTIME_PROVENANCE.json').read_text());runtime=Path(prov['loaded_runtime_root'])
assert prov['actual_outer_entry']==str(app/'app.py')
assert prov['outer_entry_sha256']==outer_before['app.py']
assert prov['embedded_bundle_sha256']==outer_before['codigo_lro.zip']
assert prov['wrapper_extraction'] and prov['wrapper_extraction']['root']==str(runtime),'Runtime is not the observed wrapper-created private extraction'
assert prov['wrapper_extraction']['prefix'].startswith('lro_ligacoes_')
assert runtime!=app and not runtime.is_relative_to(here),'Source/replay checkout substituted for wrapper extraction'
assert prov['runtime_files_unchanged']
for name,record in prov['loaded_application_modules'].items():
 mod=Path(record['path']);assert mod.is_relative_to(runtime),(name,str(mod))
 rel=str(mod.relative_to(runtime));assert approved[rel]==record['sha256'],(name,'Loaded hash mismatch')
outer_after={p.name:sha(p) for p in app.iterdir() if p.is_file()};assert outer_before==outer_after
receipt={'status':'GO','scope':'FINALAPP-only UI/native/export replay','outer_entry':str(app/'app.py'),'outer_files_before':outer_before,'outer_files_after':outer_after,'loaded_runtime_root':str(runtime),'wrapper_extraction':prov['wrapper_extraction'],'loaded_module_count':len(prov['loaded_application_modules']),'runtime_hashes_match_source':True,'runtime_unchanged_during_capture':True,'capture_scenarios':len(actual),'callback_groups':len(json.loads((out/'callbacks/CALLBACK_RECEIPT.json').read_text())),'legacy_long_group_ui_states':len(json.loads((out/'legacy_long_group/LEGACY_LONG_GROUP_UI_ACCEPTANCE.json').read_text())),'comparisons':comparisons,'legacy_svg_comparisons':legacy_svg_comparisons,'legacy_svg_normalization_rules':SVG_NORMALIZATION_RULES,'visual_basis':'Corner SVG bytes exact; legacy SVG bytes exact after only generated dc:date text and bijective generated-defs-ID/reference normalization. PNG/native/results bytes and every Word XML/media member exact. No geometry, text, style or semantic/action-label exclusions.','not_claimed':['Browser DOM click','OS download dialog','Clipboard click','Installation into a new dependency environment','Global structural or fabrication approval']}
(out/'FINALAPP_OUTPUT_ACCEPTANCE.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(receipt,ensure_ascii=False,indent=2))
