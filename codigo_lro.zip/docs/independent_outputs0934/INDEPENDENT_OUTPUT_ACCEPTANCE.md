# Independent 0.9.34 source output acceptance

Decision: GO for the reviewed source UI/native/export implementation. The FINALAPP-only package gate is separate and remains pending.

## What was executed

- 17 genuine main-app Streamlit AppTest capture scenarios: 2L-T compact/detailed, 1L both faces and detailed, overload, unknown heel, overload plus unknown heel, offset-invalid/pending geometry, mixed steels, actual zero with minimum-force design case, both welded adapters, contained 40°/50°, five bolts and non-drilled deduction.
- Six independent callback groups: strict decoder; actual atomic rejected uploads; adapter switch/reopen/navigation; received 0.9.32/0.9.33 welded imports; independent materials/consumables; pending assembly with retained real failure.
- 71 malformed new-field decoder probes and four actual malformed upload attempts. Accepted project, draft, result, report, accepted precision and template remained unchanged after rejected imports.
- Four additional actual main-app legacy states cover the two older bolted adapters: Lc=1000 imports show the specific >950 scope warning, preserve 169/812 diagnostic checks, prevent complete approval and block Word. Real controls return each to Lc=950 with complete passing checks and emitted Word. Both captured diagnostic PNG status banners visibly say outside the qualified domain. This narrow added gate does not expand the corner visual review to every legacy long-group layout.
- 43 existing old/new corner UI/native/artifact regression tests passed in 80.86 seconds.
- Actual emitted native/results JSON, PNG, SVG and compact/detailed Word bytes were captured. Hashes, input fingerprints, labels and media provenance are in the download receipts. This observes real emitted media bytes; it does not claim browser DOM/download or clipboard clicks.

## Physical and visible behavior

The 19-route selector is retained. Bolted 1L/2L-T remain adapters of the strong-axis corner route. Native state distinguishes bolted/welded inputs, one/two physical planes and one central gusset. Actual holes/bolts replace only the diagonal fillets; both welded roots, beam CJP/web joint, continuity and signed complete D/U/L cuts remain. Current drawings, results and memory follow callbacks; old reports invalidate after edits.

Five steels and the three remaining welded-interface consumables are independent. Unknown heel envelope stays incomplete and blocks resistant Word. A real overloaded strength check remains FAIL when assembly detail is pending. Condensed memory/UI/Word use 15 physical-component governors; the detailed report retains all primitive IDs, source references and witnesses. Actual P=0 stays zero in actual cuts; the synthetic minimum45 case is separately named and traced.

## Visual acceptance

Two collisions identified in the first checkpoint were corrected: the beam-root/clip caption area, and the 1L section’s axis/diameter/face captions. Seven actual SVG downloads were independently rasterized and inspected after correction.

Rendered Word coverage is 53 pages across 2L-T compact (5), 2L-T detailed (19), 1L detailed (19), negative-face 1L compact (5), and actual-zero compact (5). Each distinct page image was inspected; repeated page images are linked by exact PNG equality. No clipped text, overlapping labels/media, broken table widths, or orphan explanatory-note page was found. Detailed raw IDs wrap within their cells; they remain readable and are confined to detailed trace.

After the final long-group applicability changes, all 17 scenarios were recaptured. Their native/results JSON, PNG/SVG and every Word XML/media member are identical to the visually inspected outputs, so the visual evidence remains bound to final output bytes.

## Provenance and limits

`SOURCE_RUNTIME_HASHES.json` records 137 runtime files. Its SHA-256 is `1266a5374e3ad881daf5f8014de892c72ae90d15f5b9d21da0994b8876b3623a`. The capture records 37 actually loaded application-module paths and hashes. Final source hashes were unchanged during capture and rechecked afterward.

This is an implementation/output acceptance, not an independent numerical-method approval or a claim about every possible geometry. Numerical/oracle acceptance and all-route engine parity belong to the separate engineering gate. No source files were edited by this reviewer. No browser/clipboard, global structure, fabrication, execution/WPS, publication or deployment claim is made.

Machine-readable decision and evidence paths: `SOURCE_OUTPUT_ACCEPTANCE.json`. Portable final-package replay: `replay_finalapp.py` with the approved hash map, expected output members, and independent test inputs.

Retained evidence is indexed by exact relative path, byte count and SHA-256 in `RETAINED_EVIDENCE_MANIFEST.json`. The compact distributable receipt/replay folder is separate from these retained page images and download bytes.
