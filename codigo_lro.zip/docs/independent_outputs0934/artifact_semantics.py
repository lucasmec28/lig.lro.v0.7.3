"""Inspect emitted output bytes without importing application code."""
from pathlib import Path
from io import BytesIO
from zipfile import ZipFile
import sys,json,xml.etree.ElementTree as ET,hashlib
from docx import Document
cap=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True);records=[]
for receipt in json.loads((cap/'DOWNLOAD_RECEIPT.json').read_text()):
 tag=receipt['tag'];native=json.loads((cap/(tag+'.json')).read_text());c=native['connection'];r=json.loads((cap/(tag+'.results.json')).read_text())['result']
 svg=(cap/(tag+'.svg')).read_bytes();root=ET.fromstring(svg);ids=[e.get('id') for e in root.iter() if e.get('id')];single=c['topology'].startswith('single');bolted=c['topology'].endswith('bolted')
 for key in ['beam-root-double-fillet','column-root-double-fillet','beam_cut-named-cut','upper_column_cut-named-cut','lower_column_cut-named-cut','beam-upper-CJP','beam-lower-CJP','T-central-gusset']:
  assert key in ids,(tag,key)
 for side in ['positive','negative']:
  assert ('T-'+side+'-L' in ids)==(not single or c.get('single_angle_face')==side),(tag,side)
 if bolted:
  assert sum(i.startswith('corner-bolt-') for i in ids)==c['bolt_count'],tag
  assert sum(i.startswith('corner-hole-') for i in ids)==c['bolt_count'],tag
  assert sum(i.startswith('T-shear-plane-') for i in ids)==(1 if single else 2),tag
  assert not any(i.startswith(('brace-','T-')) and i.endswith('-fillet') for i in ids),tag
  assert native['fixed_assumptions']['gusset_count']==1
  assert native['fixed_assumptions']['physical_shear_planes']==(1 if single else 2)
  assert r['geometry']['physical_bolt_count']==c['bolt_count']
 if receipt['resistant_report_ready']:
  docbytes=(cap/(tag+'.docx')).read_bytes();d=Document(BytesIO(docbytes));text='\n'.join([p.text for p in d.paragraphs]+[cell.text for t in d.tables for row in t.rows for cell in row.cells])
  for term in ['COMPLETE_CUTS','D · viga completo','U · pilar superior completo','DERIVADO','CJP','continuidade']:
   assert term in text,(tag,term)
  if bolted:
   for term in ['parafusada',str(c['bolt_count'])+' físicos','6.1.8.2','Furo físico=','Envelope interno real do talão']:
    assert term in text,(tag,term)
   assert 'Duas soldas da diagonal' not in text and 'Quatro soldas da diagonal' not in text
   assert 'Quatro soldas 2L–chapa' not in text and 'Duas soldas 1L–chapa' not in text
  if receipt['detailed']:assert all(row['id'] in text for row in r['checks'])
  else:assert 'Auditoria detalhada' not in text
  with ZipFile(BytesIO(docbytes)) as z:
   media={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.startswith('word/media/')}
  assert hashlib.sha256((cap/(tag+'.png')).read_bytes()).hexdigest() in media.values()
 else:media={}
 mc=(cap/(tag+'_mc.txt')).read_text()
 assert 'RESUMO POR COMPONENTE' in mc and 'LINHAGEM' in mc
 # Compact MC contains group governors and force lineage, not raw check-id rows.
 check_mentions=sum(row['id'] in mc for row in r['checks'])
 assert check_mentions<len(r['checks'])/2,(tag,check_mentions)
 records.append({'tag':tag,'pass':True,'single':single,'bolted':bolted,'svg_physical_bolts':sum(i.startswith('corner-bolt-') for i in ids),'svg_shear_planes':sum(i.startswith('T-shear-plane-') for i in ids),'raw_check_ids_in_condensed_mc':check_mentions,'checks':len(r['checks']),'word_media':media})
(out/'ARTIFACT_SEMANTICS.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
print('PASS',len(records),'artifact scenarios')
