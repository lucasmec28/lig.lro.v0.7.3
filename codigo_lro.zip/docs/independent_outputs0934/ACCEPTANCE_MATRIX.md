# Independent 0.9.34 UI, native and output acceptance

Scope: Review the implementation candidate, not the already-qualified engineering method. No production-source edits are made by this reviewer. The source gate and FINALAPP-only packaged gate are separate. No source gate is claimed until the owner identifies a ready candidate.

## Evidence boundaries

- Baseline: `internal_fin_workbook_received20261012/current_app/extracted/source` (immutable received 0.9.33 source).
- Candidate: `review0934/source0934`, owner `/root/implement_bolted_corner_release`.
- Method: `bolted_corner_scope20261012/BOLTED_CORNER_CONTRACT.md`; frozen qualification input/oracle remain independent of runtime.
- Actual Streamlit AppTest callbacks, state and emitted download bytes are to be exercised. This does not claim a browser DOM click, operating-system download, or clipboard click.
- PNG/SVG raster pixels and rendered Word pages are to be visually inspected. Text/XML-only checks do not satisfy visual review.
- Numerical mechanics/oracle and all-route result parity are owned by the independent engine reviewer; this gate verifies their visible identity, state and artifacts.

## Required source matrix

1. Main-app routing: 19 existing routes, welded 1L/2L-T and new bolted 1L/2L-T remain variants of the strong-axis corner route. Unrelated route drafts survive navigation.
2. Actual callback flow: select 1L, choose each face, switch welded/bolted/count modes, alter physical dimensions and loads, regenerate current results, invalidate prior reports, navigate away/back, repeat controls and reopen saved state.
3. Native persistence: exact bolted save/decode/reopen; old 0.9.32/0.9.33 welded native import; topology, physical count/planes, units and declared assumptions are unambiguous. New values reject unknowns, booleans as numbers, NaN/infinity and invalid enums. Rejected upload/import preserves PROJECT, DRAFT, RESULT, REPORT, ACCEPTED and TEMPLATE.
4. Physical interpretation: n physical through bolts, 1 or 2 physical planes, one central gusset, total brace action once, actual single-face z sign. New bolts replace brace fillets, both welded gusset roots and complete signed beam/column cuts remain.
5. Inputs: independent angle, gusset, beam, column, continuity steels and bolt/weld data; practical primary controls without redundant inputs. Unknown heel/tool or advanced assembly facts stay pending rather than silently passing. Remote edge interpretation is identified specifically without a blanket dimension/angle ban.
6. Failure status: overload, pending geometry/detail/assembly and mixed real failure plus pending. A real FAIL survives a pending component; report permission and warning match completeness; diagnostics remain visible/current.
7. Condensed memory: grouped physical mechanisms, not all raw station/check rows. Detailed view/report retains check IDs, formulas/assumptions and source trace.
8. Actual emitted native/results JSON, PNG, SVG and compact/detailed Word: capture bytes, MIME/labels, SHA-256 and current input fingerprint. Report image media equals the current downloaded drawing/convention. Stale-result injection does not produce stale exports.
9. Visual review: all selected drawing variants and compact/detailed Word pages, checking actual bolt/plane/count/face, root symbols, signed cut arrows/labels, physical versus nominal axes, readability, no overlap or misdirected leader.
10. Runtime provenance: record Python/packages and every loaded application module path/hash. Hash candidate runtime before/after review to detect concurrent edits. No passing evidence is silently carried across changed bytes.

## FINALAPP-only gate

After source approval and packaging: extract only the delivered APP archive into a fresh isolated directory; run its outer app.py with no optional examples ZIP or source path on PYTHONPATH. Verify loaded runtime hashes against approved source, execute main-app bolted 1L/2L callbacks/import/reopen/failure/pending flows and actual downloads, inspect retained outputs, and recheck packaged runtime immutability. Report never-run or blocked steps separately.

## Status

Prepared 2026-10-12. Waiting for owner's ready-candidate notification. No implementation pass claimed.
