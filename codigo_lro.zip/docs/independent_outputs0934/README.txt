Independent 0.9.34 UI/native/output acceptance payload

Source decision: SOURCE_OUTPUT_ACCEPTANCE.json and INDEPENDENT_OUTPUT_ACCEPTANCE.md.
Retained visual/download bytes: RETAINED_EVIDENCE_MANIFEST.json gives exact paths, sizes and hashes. The large evidence tree is retained separately, not an application dependency.

Final-package replay (with pinned test dependencies available):
PYTHONDONTWRITEBYTECODE=1 python -B replay_finalapp.py /path/to/extracted/APP /path/outside/APP/to/evidence

Only the APP outer app.py and embedded codigo_lro.zip supply runtime code. All test inputs are self-contained here. No optional examples ZIP is used. The replay compares exact PNG/native/results and corner SVG bytes, normalized legacy SVG bytes as specified below, and all Word XML/media members, plus real callback states and loaded-runtime hashes.
Browser DOM, OS download dialogs and clipboard clicks are not claimed.

Legacy adapter SVG comparison excludes only the single generated dc:date text and bijectively mapped generated defs IDs, with references preserved. All remaining SVG bytes must match. Raw SVG hashes and exact normalization rules are recorded in the final receipt. Corner SVG comparison remains exact. PNG, native/results JSON and Word XML/media equality remains exact for every route.
