"""Independent actual main-app UI/native state probes; no production edits."""
from pathlib import Path
from dataclasses import replace
from copy import deepcopy
import sys,json,hashlib,math,os,traceback
source=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();out.mkdir(parents=True,exist_ok=True);sys.path.insert(0,str(source))
from streamlit.testing.v1 import AppTest
if (source/'codigo_lro.zip').exists():
 at=AppTest.from_file(str(source/'app.py'),default_timeout=300).run();assert not at.exception
from lro.corner_gusset import CornerGusset as C,FAMILY,analyze,presets,BOLTED_FIELDS,WELDED_BRACE_FIELDS
from lro.corner_gusset_ui import PROJECT,RESULT,REPORT,TEMPLATE,ACCEPTED,DRAFT,_key,decode_project,checks_complete
from lro.corner_gusset_presentation import input_fingerprint,physical_envelopes,memory_text,approved
base=list(presets().values())[0];records=[]
def fresh(c=base):
 at=AppTest.from_file(str(source/'app.py'),default_timeout=300);at.session_state['connection_family']=FAMILY;at.session_state[PROJECT]=c.to_dict();at.run();assert not at.exception;return at
def button(at,label):return next(x for x in at.button if x.label==label)
def snap(at):return {k:deepcopy(at.session_state[k]) for k in (PROJECT,RESULT,REPORT,TEMPLATE,ACCEPTED,DRAFT) if k in at.session_state}
def upload(at,payload):
 data=payload if isinstance(payload,bytes) else json.dumps(payload).encode()
 at.get('file_uploader')[0].upload('independent.json',data,'application/json').run();button(at,'Carregar projeto de canto').click().run();assert not at.exception

def record(name,fn):
 if os.environ.get('ONLY') and os.environ['ONLY'] not in name:return
 print('RUN',name,flush=True)
 try:detail=fn();records.append({'name':name,'pass':True,'detail':detail});print('PASS',name,flush=True)
 except Exception as exc:traceback.print_exc();records.append({'name':name,'pass':False,'error':repr(exc)});print('FAIL',name,repr(exc),flush=True)
 (out/'CALLBACK_RECEIPT.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')

def strict_decoder():
 tested=[];native=base.to_dict()
 for field in BOLTED_FIELDS:
  raw=native['connection'][field]
  for label,val in [('missing',None),('wrong_type', True if type(raw) in (float,int) else 3 if isinstance(raw,str) else 'true')]:
   bad=deepcopy(native)
   if label=='missing':bad['connection'].pop(field)
   else:bad['connection'][field]=val
   try:decode_project(json.dumps(bad));raise AssertionError('Accepted '+field+' '+label)
   except (TypeError,ValueError):pass
   tested.append(field+':'+label)
  if type(raw) in (int,float):
   for val in [float('nan'),float('inf'),-float('inf')]:
    bad=deepcopy(native);bad['connection'][field]=val
    try:decode_project(json.dumps(bad));raise AssertionError('Accepted nonfinite '+field)
    except (TypeError,ValueError):pass
    tested.append(field+':'+str(val))
 for change in [('unknown',lambda x:x['connection'].update(unrecognized_bolt_field=4)),('weldfield',lambda x:x['connection'].update(brace_weld_leg=5)),('assumption',lambda x:x['fixed_assumptions'].update(physical_shear_planes=1)),('unit',lambda x:x['units'].update(force='kN')),('fractional_count',lambda x:x['connection'].update(bolt_count=4.5)),('unknown_bolt',lambda x:x['connection'].update(bolt='mystery')),('unknown_exposure',lambda x:x['connection'].update(bolt_exposure='unknown'))]:
  bad=deepcopy(native);change[1](bad)
  try:decode_project(json.dumps(bad));raise AssertionError('Accepted '+change[0])
  except (TypeError,ValueError):pass
  tested.append(change[0])
 return {'rejections':len(tested),'tests':tested}
record('strict new-field decoder',strict_decoder)

def atomic():
 at=fresh();button(at,'Gerar memória de canto').click().run();assert REPORT in at.session_state
 initial=snap(at)
 variants=[]
 bad=deepcopy(initial[PROJECT]);bad['connection']['unknown_bolt']=1;variants.append(bad)
 bad=deepcopy(initial[PROJECT]);bad['connection']['bolt_pitch']=float('inf');variants.append(bad)
 bad=deepcopy(initial[PROJECT]);bad['fixed_assumptions']['physical_shear_planes']=99;variants.append(bad)
 bad=deepcopy(initial[PROJECT]);bad['connection'].pop('bolt_heel_extent_source');variants.append(bad)
 for bad in variants:
  upload(at,bad);assert any('Não foi possível abrir' in x.value for x in at.error)
  assert snap(at)==initial
 return {'rejected_uploads':len(variants),'preserved':list(initial)}
record('atomic rejected uploads',atomic)

def callback_cycle():
 at=fresh(replace(base,P=100000.12345678901));button(at,'Gerar memória de canto').click().run();assert REPORT in at.session_state
 at.number_input(key=_key('bolt_pitch')).set_value(58.).run();assert REPORT not in at.session_state
 assert at.session_state[PROJECT]['connection']['P']==100000.12345678901
 at.selectbox(key=_key('topology')).set_value('single_1L_bolted').run();at.selectbox(key=_key('single_angle_face')).set_value('negative').run()
 c=C.from_dict(at.session_state[PROJECT]);r=at.session_state[RESULT]
 assert c.single_angle_face=='negative' and c.topology=='single_1L_bolted'
 assert r['geometry']['physical_shear_planes']==1 and r['geometry']['physical_bolt_count']==4
 assert at.metric[1].value==at.metric[0].value
 one=deepcopy(at.session_state[PROJECT]);upload(at,one);assert at.session_state[PROJECT]==one
 old_routes=at.selectbox(key='connection_family').options;assert len(old_routes)==19
 other=old_routes[0];at.selectbox(key='connection_family').set_value(other).run();assert not at.exception
 at.selectbox(key='connection_family').set_value(FAMILY).run();assert not at.exception and at.session_state[PROJECT]==one
 at.selectbox(key=_key('topology')).set_value('single_1L_welded').run();assert not at.exception
 assert not set(BOLTED_FIELDS)&set(at.session_state[PROJECT]['connection'])
 at.selectbox(key=_key('topology')).set_value('single_1L_bolted').run();assert not at.exception
 assert at.session_state[PROJECT]==one
 assert at.session_state['cg_mc_current']==memory_text(C.from_dict(one))
 return {'routes':old_routes,'face':c.single_angle_face,'native_exact_after_navigation':True,'branch_restore':True}
record('adapter callbacks reopen and navigation',callback_cycle)

def old_native():
 paths=[Path(__file__).resolve().parent/'inputs'/name for name in ['received_0932_welded_2LT.json','received_0933_welded_1L.json']]
 at=fresh();result=[]
 for path in paths:
  raw=json.loads(path.read_text());c=decode_project(path.read_bytes());upload(at,path.read_bytes())
  assert at.session_state[PROJECT]==c.to_dict()
  assert at.session_state[RESULT]==analyze(c)
  assert not set(BOLTED_FIELDS)&set(at.session_state[PROJECT]['connection'])
  result.append({'path':str(path),'original_component_version':raw['component_version'],'topology':c.topology})
 return result
record('received old welded native imports',old_native)

def materials():
 at=fresh();original=base.to_dict()['connection'];result={}
 for key in ['angle_steel','gusset_steel','beam_steel','column_steel','continuity_steel']:
  target='ASTM A572 Gr.50' if original[key]!='ASTM A572 Gr.50' else 'ASTM A36'
  at.selectbox(key=_key(key)).set_value(target).run();assert not at.exception
  raw=at.session_state[PROJECT]['connection'];assert raw[key]==target
  for other in ['angle_steel','gusset_steel','beam_steel','column_steel','continuity_steel']:
   if other!=key:assert raw[other]==original[other],(key,other)
  at.selectbox(key=_key(key)).set_value(original[key]).run();result[key]=target
 for key in ['fw_root','fw_joint','fw_continuity']:
  at.number_input(key=_key(key)).set_value(490.).run();assert not at.exception
  raw=at.session_state[PROJECT]['connection']
  for other in ['fw_root','fw_joint','fw_continuity']:
   if other!=key:assert raw[other]==original[other]
  at.number_input(key=_key(key)).set_value(original[key]).run()
 return result
record('five independent steels and three welded interfaces',materials)

def pending_fail():
 at=fresh();at.number_input(key=_key('bolt_heel_extent')).set_value(0.).run();assert not at.exception
 r=at.session_state[RESULT];assert not r['complete'] and not approved(r) and button(at,'Gerar memória de canto').disabled
 assert r['status']=='UNVERIFIED' and any(x['id']=='bolt_heel_extent_missing' for x in r['issues'])
 at.number_input(key=_key('P')).set_value(1000.).run();assert not at.exception
 r=at.session_state[RESULT];assert r['status']=='FAIL' and not r['complete'] and not approved(r)
 assert any(x['status']=='FAIL' for x in r['checks']) and button(at,'Gerar memória de canto').disabled
 assert any('VERIFICAÇÃO INCOMPLETA' in x.value for x in at.error)
 assert at.session_state['cg_mc_current']==memory_text(C.from_dict(at.session_state[PROJECT]))
 return {'status':r['status'],'complete':r['complete'],'issue_ids':[x['id'] for x in r['issues']]}
record('assembly unknown and real failure retained',pending_fail)

print(json.dumps({'passed':all(x['pass'] for x in records),'groups':len(records)},indent=2),flush=True)
if not all(x['pass'] for x in records):raise SystemExit(1)
