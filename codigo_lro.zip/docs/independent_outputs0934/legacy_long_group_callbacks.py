"""Actual main-app import/download and exact950 callbacks for two legacy adapters."""
from pathlib import Path
from dataclasses import replace
from copy import deepcopy
import sys,json,hashlib,importlib
source=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();out.mkdir(parents=True,exist_ok=True);sys.path.insert(0,str(source))
from streamlit.testing.v1 import AppTest
from streamlit.runtime.memory_media_file_storage import MemoryMediaFileStorage
if (source/'codigo_lro.zip').exists():
 boot=AppTest.from_file(str(source/'app.py'),default_timeout=300).run();assert not boot.exception
from lro.bolted_angle_gusset import FAMILY
from lro.bolted_angle_gusset_ui import PROJECT,RESULT,REPORT,_key,checks_complete,decode_project
files={};original=MemoryMediaFileStorage.load_and_get_id

def observe(storage,*args,**kwargs):
 identity=original(storage,*args,**kwargs);files[identity]=storage._files_by_id[identity].content;return identity
MemoryMediaFileStorage.load_and_get_id=observe
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
runtime=Path(sys.modules['lro'].__file__).resolve().parent.parent
before={str(p.relative_to(runtime)):sha(p) for p in (runtime/'lro').glob('*.py')}
def button(at,label):return next(x for x in at.button if x.label==label)
def visible(at):return '\n'.join(str(x.value) for kind in ['title','warning','error','success','caption','code'] for x in getattr(at,kind))
def capture(at,tag):
 exports={}
 for x in at.get('download_button'):
  data=files[Path(x.proto.url).name.rsplit('.',1)[0]]
  ext='.png' if data.startswith(b'\x89PNG') else '.svg' if b'<svg' in data[:1000] else '.docx' if data.startswith(b'PK') else '.json'
  if ext=='.json' and 'connection' not in json.loads(data):ext='.results.json'
  p=out/(tag+ext);p.write_bytes(data);exports[ext]={'path':str(p),'sha256':sha(p),'bytes':len(data),'label':x.label}
 (out/(tag+'_ui.txt')).write_text(visible(at));(out/(tag+'_state.json')).write_text(json.dumps(at.session_state[RESULT],ensure_ascii=False,indent=2))
 assert {'.json','.png','.svg'}<=set(exports)
 assert json.loads(Path(exports['.json']['path']).read_text())==at.session_state[PROJECT]
 return exports
records=[]
for name in ['bolted_angle_gusset','bolted_opposed_angle_gusset']:
 mod=importlib.import_module('lro.'+name);base=next(iter(mod.presets().values()))
 long=replace(base,theta_deg=90.,n=11,pitch=100.,plate_height=1100.,center_n=550.,N=45000.)
 at=AppTest.from_file(str(source/'app.py'),default_timeout=300);at.session_state['connection_family']=FAMILY;at.session_state[PROJECT]=base.to_dict();at.run();assert not at.exception
 button(at,'Gerar memória completa parafusada').click().run();assert REPORT in at.session_state
 payload=json.dumps(long.to_dict(),ensure_ascii=False).encode();at.get('file_uploader')[0].upload(name+'_1000.json',payload,'application/json').run();button(at,'Carregar projeto completo parafusado').click().run();assert not at.exception
 assert at.session_state[PROJECT]==long.to_dict();r=at.session_state[RESULT];assert r==mod.evaluate(long)
 issue=next(x for x in r['issues'] if x['id']=='long_bolt_group')
 assert issue['actual']==1000. and issue['qualified_limit']==950.
 assert r['status']=='OUTSIDE_SCOPE' and not r['global_pass'] and not r['local_pass'] and not checks_complete(r)
 assert r['checks'] and r['cases'] and r['geometry']['valid']
 assert button(at,'Gerar memória completa parafusada').disabled and REPORT not in at.session_state
 assert 'Lc>950 mm' in visible(at) and 'diagnóstico' in visible(at)
 exports=capture(at,name+'_1000');assert '.docx' not in exports
 records.append({'adapter':name,'length':1000,'status':r['status'],'global_pass':r['global_pass'],'complete_checks':r['summary']['complete_checks'],'diagnostic_checks':len(r['checks']),'specific_warning':issue['message'],'report_blocked':True,'exports':exports})
 # Use actual controls, not session-state replacement, to get the contained exact950 case.
 at.number_input(key=_key(('pitch',))).set_value(95.).run();at.number_input(key=_key(('plate_height',))).set_value(1050.).run();at.number_input(key=_key(('center_n',))).set_value(525.).run();assert not at.exception
 c=decode_project(json.dumps(at.session_state[PROJECT]));r=at.session_state[RESULT]
 assert r['geometry']['Lc']==950. and not any(x['id']=='long_bolt_group' for x in r['issues'])
 assert r['global_pass'] and r['local_pass'] and checks_complete(r)
 assert not button(at,'Gerar memória completa parafusada').disabled
 button(at,'Gerar memória completa parafusada').click().run();assert not at.exception and REPORT in at.session_state
 exports=capture(at,name+'_950');assert '.docx' in exports
 records.append({'adapter':name,'length':950,'status':r['status'],'global_pass':r['global_pass'],'complete_checks':r['summary']['complete_checks'],'diagnostic_checks':len(r['checks']),'report_blocked':False,'exports':exports})
 (out/'LEGACY_LONG_GROUP_UI_ACCEPTANCE.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
 print('PASS',name,'1000 scope guard and exact950 callbacks',flush=True)
after={str(p.relative_to(runtime)):sha(p) for p in (runtime/'lro').glob('*.py')};assert before==after
(out/'RUNTIME_PROVENANCE.json').write_text(json.dumps({'runtime_root':str(runtime),'before':before,'after':after,'runtime_unchanged':True,'not_claimed':['Browser DOM click','OS download dialog','Clipboard interaction','Numerical sweep']},indent=2)+'\n')
