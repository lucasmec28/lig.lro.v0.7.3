# Reprodução dos exemplos atuais 0.9.42

Execute com dependências do APP instaladas, em uma cópia extraída. Saída deve ficar fora do fonte:

python docs/current_examples0942/replay_wrapper.py docs/independent_result_indices0942/replay_current_examples.py --source-root . --out /caminho/saida/endplate --ui
python docs/current_examples0942/replay_wrapper.py docs/independent_base_key_plate0942/run_app_only.py . /caminho/saida/base

O wrapper fixa somente a data do SVG e a semente de seus identificadores gráficos. Não altera valores, entradas, resultados, algoritmos ou versões. Projetos/JSON e pixels PNG são comparados exatamente; DOCX é comparado pelos membros descompactados, ignorando apenas timestamps do contêiner ZIP. Nada aqui encerra as pendências físicas declaradas.

Os documentos de revisão mantêm o contexto e a versão original da revisão isolada. A identidade runtime do incremento integrado consta em CURRENT_EXAMPLES0942.json e na validação 0942. Os scripts históricos de comparação contra 0941 requerem a fonte anterior preservada; os dois comandos acima dependem só do APP atual.
