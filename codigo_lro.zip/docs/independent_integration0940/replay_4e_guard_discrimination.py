"""Read-only checks of the shipped 4E proof's narrow normalization and guards.

Usage: python replay_4e_guard_discrimination.py SOURCE OUTPUT
All mutation witnesses are detached payloads or a disposable three-file copy.
No production or expectation file is changed.
"""
import argparse
import ast
import copy
import dataclasses
import hashlib
import importlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace

sys.dont_write_bytecode = True
p = argparse.ArgumentParser(description=__doc__)
p.add_argument('source'); p.add_argument('output')
a = p.parse_args()
source = Path(a.source).resolve(); out = Path(a.output).resolve()
assert not out.is_relative_to(source)
out.mkdir(parents=True, exist_ok=True)
kit = source/'docs/independent_4e_column_demands'
proof_path = kit/'replay_4e.py'
proof = proof_path.read_bytes()
commit = json.loads((kit/'expected.json').read_text())
sha = lambda b: hashlib.sha256(b).hexdigest()
before = {n:sha((source/n).read_bytes()) for n in commit['runtime_sha256']}
assert before == commit['runtime_sha256']
sys.path.insert(0, str(source))
ep = importlib.import_module('lro.end_plate')
models = importlib.import_module('lro.models')
namespace = dict(dataclasses=dataclasses, hashlib=hashlib, json=json,
                 math=math, models=models)
selected = {'sha', 'clean', 'digest', 'normalized_native'}
tree = ast.parse(proof, filename=str(proof_path))
nodes = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in selected]
assert {n.name for n in nodes} == selected
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(proof_path), 'exec'), namespace)
norm = lambda payload: namespace['normalized_native'](SimpleNamespace(to_dict=lambda: copy.deepcopy(payload)))
digest = namespace['digest']
entry = next(c for c in commit['cases'] if c['base']=='4E') if any(c['base']=='4E' for c in commit['cases']) else commit['cases'][0]
inputs = copy.deepcopy(commit['base_inputs'][entry['base']]); inputs.update(copy.deepcopy(entry['overrides']))
obj = ep.EndPlate.from_dict({'schema_version':1, 'connection_type':'end_plate', 'connection':inputs})
assert obj.kind == 'moment' and obj.variant == '4E'
native = obj.to_dict(); normalized = norm(native)
exact = copy.deepcopy(native); exact.pop('app_version')
assert normalized == namespace['clean'](exact)
assert native == obj.to_dict(), 'normalizer mutated caller payload'
rows = native['verification']['checks']
column_row = next(i for i,r in enumerate(rows) if r['id']=='ep_column_web_yield')
paths = [
    ('connection','N'), ('connection','M'), ('connection','V'),
    ('verification','checks',column_row,'demand'),
    ('verification','checks',column_row,'resistance'),
    ('verification','checks',column_row,'ratio'),
    ('verification','checks',column_row,'passed'),
    ('verification','checks',column_row,'equation'),
    ('verification','checks',column_row,'reference'),
    ('verification','checks',column_row,'substitution'),
    ('verification','method_revision'), ('verification','status'),
    ('verification','approved'), ('verification','complete_within_declared_scope'),
    ('verification','cases',0,'actions','N'),
    ('verification','cases',0,'status'),
]
witnesses = []
for path in paths:
    changed = copy.deepcopy(native); cursor = changed
    for key in path[:-1]: cursor = cursor[key]
    old = cursor[path[-1]]
    cursor[path[-1]] = not old if isinstance(old,bool) else old+.125 if isinstance(old,(float,int)) else old+' UNREVIEWED_MUTATION'
    assert digest(norm(changed)) != digest(normalized), path
    witnesses.append({'path':list(path),'mutation_detected':True})
changed = copy.deepcopy(native); changed['verification']['app_version'] = models.VERSION
assert norm(changed)['verification']['app_version'] == models.VERSION
assert digest(norm(changed)) != digest(normalized)
changed = copy.deepcopy(native); changed['app_version'] = 'unreviewed-global-version'
try: norm(changed)
except AssertionError: invalid_version_rejected = True
else: raise AssertionError('Unreviewed top-level version accepted')
report_func = next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='report_text')
returns = [n for n in ast.walk(report_func) if isinstance(n,ast.Return)]
assert len(returns)==1
report_norm = ast.Expression(body=returns[0].value)
strings = [models.VERSION, ep.MOMENT_REVISION, 'NÃO ATENDE', 'FSd=max(Ff;Fc)', 'Ff=123.125; Fc=45.5']
report_projection = eval(compile(report_norm, str(proof_path), 'eval'), {'models':models,'texts':strings})
assert report_projection == ['{APP_VERSION}']+strings[1:]
copy_root = out/'mutated_source'
for name in commit['runtime_sha256']:
    target=copy_root/name; target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes((source/name).read_bytes())
with (copy_root/'lro/end_plate.py').open('ab') as f: f.write(b'\n# Disposable guard witness; not production.\n')
proc=subprocess.run([sys.executable,str(proof_path),str(copy_root),str(out/'rejected_guard_output'),'--source'],
                    capture_output=True,text=True,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
(out/'source_mutation_rejection.log').write_text(proc.stdout+proc.stderr)
assert proc.returncode != 0 and 'Reviewed 4E source hash mismatch' in proc.stderr
assert {n:sha((source/n).read_bytes()) for n in before} == before
assert proof_path.read_bytes() == proof
origins={name:str(Path(module.__file__).resolve()) for name,module in sys.modules.items()
         if (name=='lro' or name.startswith('lro.')) and getattr(module,'__file__',None)}
assert all(Path(path).is_relative_to(source) for path in origins.values())
result={'pass':True,'proof_sha256':sha(proof),'source_hashes':before,
        'payload_mutation_witnesses':witnesses,'nested_app_version_not_projected':True,
        'wrong_global_version_rejected':invalid_version_rejected,
        'report_projection':'Exact global VERSION string only; method revision, status, force labels and values preserved.',
        'source_hash_mutation_rejected':True,'production_and_oracles_unchanged':True,
        'module_origins':origins,'limits':'Detached guard witnesses; no APP loader, browser, Word layout or full aggregate claim.'}
(out/'GUARD_DISCRIMINATION.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'pass':True,'mechanical_and_status_mutations_detected':len(witnesses),
                  'source_mutation_rejected':True,'normalization_scope_exact':True}))
