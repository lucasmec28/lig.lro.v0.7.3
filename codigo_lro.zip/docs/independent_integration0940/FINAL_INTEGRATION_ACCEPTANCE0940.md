# Independent corrected-source integration acceptance

Decision: GO for the bounded 0.9.40 source/integration scope, subject to the separate final aggregate, packaging and delivered-APP gates. This review does not authorize upload or delivery and does not claim that the four-root APP has been tested.

## Identity and authorized delta

The immutable internal-undelivered 0.9.39 source inventory was independently rehashed: 2,124 files, tree SHA-256 c0b294ed2068bd81688cecec6d444aa5185257d7a69756bf1ed07cf71bfb2f86. The 0.9.40 runtime/test/data hold SHA-256 is 883aabab14cc52a28794229a4cada25433543fc790df35dc3be724ca163dc653; all 342 bound files matched before completion.

The held delta is exactly four runtime files and four test paths: app.py/models.py global-version literals; end_plate.py/end_plate_report.py correction; two test global-version literals; one existing 4E method-identity expectation; and one new 61-case test module. No capacity, minimum-case, contact, bolt, tolerance or unrelated mechanics change was found. For 4E moment only, column yielding now uses max(Ff,Fc) and crippling Fc. Existing 4ES/8ES/PINNED routes remain equal to their frozen engine/native/report-text commitments after the explicitly permitted global-version treatment.

All ten reviewed patch afterhashes, including the two newline-sensitive JSON files, match the accepted candidate and corrected transport addendum. The amended transport does not change runtime or commitments.

The initial whole-source delta contained 14 paths; documentation and evidence were subsequently added by the sole integrator. This acceptance binds the held runtime/test/data and enumerated proof bytes, not an evolving whole-source tree seal. Apart from README and the seven authorized existing runtime/test paths, all 2,116 inherited files remain byte-exact, including the 424 identified fixture/example files and inherited proof directories. No frozen fixture or numeric oracle was amended.

## Fresh verification on source0940

- 4E portable replay: all 61 literal inputs, 78 independent hand-calculated action cases, 12 compact/detailed Word-text commitments, 12 isolated adverse increase thresholds and 6 reduced-demand thresholds passed. Imports were confined to source0940; no legacy source or external optional fixture tree was used. Actual/minimum governing rows, source references, retained T/C/contact and signed forces were checked. The same commitments passed under both NumPy 2.3.5 and 2.5.3; these are repeated environments, not 122 distinct cases.
- 4E proof discrimination: the actual shipped normalization functions preserved every field except the enumerated top-level app_version; 16 numerical/mechanical/status mutations were detected. Nested versions remained observable, an unreviewed global version was rejected, and the report normalizer retained method/source/status/force strings. A disposable source mutation was rejected by the exact hash gate. Production and expectation bytes were untouched.
- Outer cap: 13 mechanical files and two independent oracle helpers matched. All 11 portable mechanical groups passed, including 500 polygons, 39 perforated sections, 243 independent block-area witnesses and seven exact original-mode numerical commitments. All 19 opposed payloads matched exactly; two compression receiver failures remained failures; four description states and 52 termination boundaries passed.
- Existing metadata replay: 17 presets and 12 boundaries matched their original frozen hashes; all 29 mutation witnesses passed. The actual candidate helper functions were executed; all pre-existing numeric leaf paths, types and values remained. Corner geometry/full-result hashes were exact, with no full-result projection. Six protected fixtures and bound source/test files stayed unchanged.
- W7 retained option: 77 portable engineering/native/report-content tests passed. The three UI adapter tests and visual report pagination were not run here. One pytest deprecation warning was non-failing. An initial system-environment attempt found pytest absent and was replaced by the already-installed test dependencies; no package was installed.
- Lig18 retained correction: 500 independent clamped-envelope probes and explicit counterexamples passed; u=0 retained pending status and 13 checks, and the conditional report wording remained correct. The old external baseline parity driver was not re-executed or relabelled as fresh evidence. Its runtime files are unchanged from the verified internal0939 source.

These review units are separate and are not added to the production aggregate's collected test count of 5,823.

## Dependencies and portability

Python 3.12.14, SciPy 1.17.0 and python-docx 1.2.0 were used. Exact inherited outer/metadata payload commitments ran with the original NumPy 2.3.5. W7 and the second 4E replay used the installed audit dependency directory with NumPy 2.5.3 and pytest 9.1.1. PYTHONDONTWRITEBYTECODE=1 and external writable cache/output directories were used throughout. No numeric assertion was relaxed and no new metadata projection was necessary.

The 4E four-file kit, outer-cap kit and existing metadata kit manifests were independently verified in source0940. These commitments are ready to ship together and replay. The actual four-root APP must still run the 4E kit through its unmodified prepare_code loader, confirm archive digest and shipped proof equality, and constrain module origins to its extracted payload. Source-only success does not close that gate.

## Explicit limitations

No full source aggregate was duplicated by this reviewer; its owner must report its actual final outcome, including the inherited missing external bolt-bearing oracle. No new normative PDF visual inspection, browser/pixel gate, Word layout/pagination acceptance, package loader execution, manufacturing, structural-project, seismic/cyclic or global stability approval is claimed. Normative support is the separately accepted correction and its source provenance; current replay independently rechecks arithmetic and exact regression commitments.

For evidence transfer, copy the final receipt, this report, the listed logs/JSON/XML and optional guard driver. The disposable guard_discrimination/mutated_source directory is a deliberately invalid test witness and must not be included as production source or an expected runtime.
