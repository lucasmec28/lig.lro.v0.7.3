# Bolted symmetric 2L T corner compression qualification

12 October 2026. One bounded candidate, accepted subject to the exact domain by the independent review recorded beside this contract. This is an engineering-method qualification and implementation specification, not production implementation, fabrication approval or global brace design.

## Decision and exact first domain

GO to implement and independently test the following local compression branch. No additional source is needed from the user for this bounded branch. The supplied DG29, corrected NBR8800 and Gerdau catalog supply the needed conventional methods. The earlier compression contract's statement that pretension alone was enough for this bolted end needs correction: NBR6.1.11.2(c) also requires a friction-type end connection for the built-up-member procedure referenced in5.3.6.2.

The first domain is one ordinary strong-axis two-root corner, with the same welded gusset roots, beam-column joint, continuity plates and receiving members already qualified. Two identical equal-leg angles form a symmetric T, one per gusset face. One straight row of at least two high-strength through bolts directly clamps L–gusset–L, with standard round drilled holes and uniform nominal load per bolt. No filler, stand-off, intentional offset, independent brace V/M/T, single angle, opposed pair, seismic hinge or fatigue claim is included. Retain0<phi<90 degrees and the actual contained polygon/contact geometry; there is no fixture-only300mm or45-degree rule.

For this first automatic route require:

- Pretensioned high-strength bolts, qualified Class A or B faying surfaces, no applied external bolt tension or prying, and the separate service-slip check below. Installation/inspection, required hardened washer hardware under the rotating element, and the actual surface preparation must be identified. Include the actual washer stack in bolt grip and access geometry. A software result cannot certify pretension execution.
- Actual beam-root, column-root and brace-end out-of-plane restraint, including the intended relative translation and twist restraint at the angle's connected bolt stations. Identify the physical detail and bind the declaration to the actual root, brace, bolt, hole/contact and supporting geometry. Symmetry, a checkbox or the existing receiver-only lateral-restraint flag cannot create these restraints.
- Full selected Whitmore stripe contained in the real plate, with its orthogonal projections lying inside both effective root weld segments and uninterrupted by the actual relief. Retain the welded contract's ordinary-corner boundary idealization, direct signed UFM root flow and no real work-point offset. An unqualified larger notch, remote root or flexible brace end requires that specific boundary model; increasingK does not cure it.
- Actual angle legs satisfy conservative NBR Table4 AL3 using full publishedb, and the connected bolt intervals satisfy the explicitly selected short-interval restrictionp_max/r_min<=25. The latter is a bounded implementation domain, not a universal code bolt-pitch limit. Use publishedr_min; do not infer it from a radius invented for the rolled heel. Ordinary pitch/edge/washer/tool/grip/long-joint limits remain independently active.
- The angle continues intact beyond the outermost bolt. Identify the next hole/free boundary in the loaded+u direction, or state and verify an uninterrupted continuation sufficient for the bearing cap. The first implementation can require clear length>=2db, which saturates the deformation-considered bearing resistance. This local-to-member boundary is not a free end.
- Shared gusset reverse L paths are all excluded by actual retained support contact or supported cap endpoints; the admitted tangent-U family has two distinct longitudinal legs reaching the real inner free clip. This is an explicit geometric first-domain restriction. If a different layout has an active reverse L path or a different exit topology, retain its diagnostic and identify that additional path family as outside this first automatic branch rather than silently deleting it. The qualification does not enumerate every conceivable curved crack.

Global brace buckling, the far end and intermediate stitch requirements ofNBR5.3.6 remain outside the local output. Neither global member lengths nor genericFEA are required to calculate this local branch. Its PASS must explicitly say that it verifies only the connection and connected angle portions under the declared restraints. A project detail with unknown restraint remains unverified at the named component.

## Sources and verified page map

Page numbers below are one-based PDF page/printed page in the supplied files.

- DG29 Example5.1, PDF51–60/printed43–52: bolted double-angle strong-axis corner, bolt shear/bearing/block/Whitmore, and compression at59/51. AppendixC.1, PDF382–384/printed374–376: bolt/weld Whitmore load introduction and equivalent-column geometry; TableC-1 noncompact cornerK1. AppendixC p389/printed381 distinguishes its ordinary worked corner compression from tension block cases. The first branch deliberately retains the accepted conservative full-strip maximum length rather than the three-line mean and declines compactness/K0.5 credits.
- Corrected NBR8800:2024 with Errata1:2025, PDF93–94/printed71–72,6.1.8.2 and6.1.11.1–.2: static angle-end axis exception includes compression; reversible static stresses require pretension; built-up ends under5.3.6.2 require friction-type bolts. PDF73–74/printed51–52:5.3.6 does not let local end checks certify the whole built-up member.
- PDF106–107/printed84–85,6.3.3: bolt-plane shear and directional hole bearing, including the loaded clear ligament. PDF108–110/printed86–88,6.3.4: standard holes use service slip, with ordinary ultimate shear/bearing retained. PDF133/printed111,6.8.4.1/Table19: metric16mm A325 minimum pretension91kN; do not substitute the5/8in85kN entry.
- PDF114/printed92,6.3.10–.12: spacing and edge details. PDF69/printed47,Table4 AL3; PDF67–68/printed45–46,5.3 reduction; PDF116–117/printed94–95,6.5.4–.6 local compression, shear and block failure.
- Gerdau supplied pocket catalog physicalp3 row30, already preserved in frozen data/gerdau_equal_angles.json: L76.2×7.94,Ag1148mm²,e22.1mm,r_min15.00mm. This property exists in the source JSON although the current angle_catalog top-level adapter omitsr_min.
- Souza chapter5 gives useful compression interpretation but uses the older2008Q formulation. It does not replace corrected2024Aef or establish restraint merely because a connection is bolted.
- Official Dowswell source supporting DG29's conventional geometry/restraint model: https://ej.aisc.org/index.php/engj/article/download/877/876 . No added pointwise elasticity/FEA premise is introduced.

NBR6.5.4(b) visibly repeatsLe/r<=25, creating an internal textual anomaly. As in the accepted welded method, calculate the fullNBR5.3 reduction at every positive length and do not exploit a yielding-only threshold or silently repair the printed inequality.

## Signed transfer and independent attachment checks

Defineu outward along the continuing brace andv transverse in the gusset. KeepP<0 as the actual signed compression;C=-P only labels demand magnitudes. Each L receivesP/2, each physical bolt shear planeP/(2n), and each central gusset holeP/n. One shared gusset and two real slip interfaces are counted exactly once.

The physical bearing directions reverse: the gusset receives-u; each angle receives+u. Therefore:

- First gusset hole:lc=u_first-u_inner_exit-dh/2. Remaining holes:preceding pitch-dh.
- Interior angle holes:following pitch-dh. Last angle hole:actual clear continuation to the next hole/free boundary, not the support-side free tip.
- Each wall independently satisfiesR=min(1.2lc t fu,2.4db t fu)/gamma_a2. Hole-wall force uses physicaldh. No adjacent-hole pooling hides a failed wall.
- Each bolt plane retains its correct thread-dependent0.45 or0.56 coefficient, actual shank area, fub and applicable grip/detail factors. Pretension is not added to shear capacity.

For the selected standard-hole friction-type end,NBR6.3.4.4 gives per complete boltF_Rk=0.80 mu Ce F_Tb ns when there is no imposed bolt tension. HereCe=1 andns=2. ClassA mu=.30; ClassB mu=.50. Compare the rare-service shear or the permitted0.70 times normal-ultimate shear. The initial automatic fixture uses an explicitly identified normal-ultimate case. Do not apply0.70 to an unidentified/special/exceptional combination. A separate service resultant can be supported later; no new member analysis need be reconstructed from complete cuts for this local slip check. Check each interface consistently when surfaces differ; first domain uses the same qualified class on both faces. Slip, bolt shear and bearing are separate limit states and their resistances are never summed.

The nominal row axis atv0,z0 retains theNBR6.1.8.2 ordinary static end simplification. Actual angle centroids and their ordinary end offsets remain recorded. Pairedz eccentricities cancel; the in-plane centroid offset does not physically vanish. The clause is not permission to suppress a real work-point offset or independent couple.

Each angle's local attached portion receives fullC/2 conservatively: gross compressionAg fy/gamma_a1; supplemental net compression yield(Ag-dn t)fy/gamma_a1; and a short connected-segment compression check. For that last check useK1,Le=p_max, exactr_min, compactAef=Ag and the fullNBR5.3chi curve. This is a declared conventional local segment idealization under the actual station restraints, not a claim thatNBR explicitly places an ideal pin at every bolt. It uses neither a global brace length nor a fictitious continuous weld restraint. The free tip before the first bolt has no compressive axial load under the selected stepped transfer. The continuing member beyond the last bolt is outside the local result.

Ct fu net tensile rupture and the old support-side angle tension block are inactive for a pure compression case. They are not retained underabs(P). Do not add a second unreferenced tensile rupture screen to compression. NBR Table4 compactness, local segment stability, compression net yielding and directional bearing address different retained modes.

## Gusset load introduction and inward free-edge paths

Atu0=u_first, the one-row Whitmore width is2Lc tan30 degrees, spreading from the outermost bolt toward the roots. Use its centered contained stripe, apply the fullC, and follow the accepted welded branch'sK1 full-width maximum of brace-parallel distances to the nominal beam/column faces. The starting point is the first force-transfer bolt, not the unconnected angle tip. Use grossA=bw tg for this conventional DG29 equivalent column and the fullNBRchi curve; noCt or net tensile rupture enters it. A separate(bw-dn)tg fy/gamma_a1 yield screen is a deliberately conservative compression ligament supplement. The entire physical polygon's gross/netN,V,M sections retain both partial root tractions and both limits of a cut-hole force; theirVM yield screen is nominal, not a pointwise hole-contact field. A genuinely positive tensile surface produced by these signed resultants retains its relevant tensile check; purely negative normal stress does not activate tensile rupture via an absolute value.

Compression of the brace does not imply that every potential crack cap is compressed. The inward-U detached region liesu<=u_cap, is forced-u toward the free clip and separates from retained+u material across its transverse cap. That cap opens in tension in this specific local mechanism. It is therefore legitimate to evaluate the local shear+tension areas underNBR6.5.6. Old outward tension paths remain inactive.

Reflect the accepted conventional L/U paths into the inward load direction. Reject any detached region retaining a positive length of either full physical support edge, even outside the effective weld length, and reject L caps ending on supports. For the admitted U, legs lie atv=±dn/2, reach their actual inward free exits, and are distinct:

Agv=Anv=tg[2u_cap-u_exit,left-u_exit,right]; Ant=tg[dn-2h], whereh=sqrt[(dn/2)^2-(u_cap-u_j)^2] inside a crossed hole and0 otherwise. Use the twoNBR6.5.6 branches with conservativeCts=.5. The captured-bolt demand isC times the included bolt fraction, once per central gusset, and preserve the smaller excluded-hole force limit as metadata. No assumed contact pressure is used to interpolate favorably.

Evaluate hole tangencies/centers, polygon and support transitions, plus interior minima: for U,x/h=-1.2fy/fu in the yield branch and-1.2 in rupture. Reversed L diagnostics usex/h=-a for rupture and-1.2fy/fu-a for yield when the cap boundary-distance slope isa. These prevent center-only sampling. All first-domain L candidates must be physically inactive as stated above.

The selected first implementation gives the U cap zero tensile credit:Rd=min(0.6fy Agv,0.6fu Anv)/gamma_a2. This is a lower bound on the stated block resistance, not a second simultaneous capacity. With tangent legs fixed, its worst included-hole prefix is found at that prefix's earliest tangent; preserve geometry/support events too. Both full-cap and zero-cap numerical witnesses are frozen. Only the zero-cap model supplies the first branch strength row; the full-cap result remains a direction/derivative diagnostic. Do not sum them.

## Whole joint and minimum45

Reuse the qualified signed UFM and complete-cut chain. Bolts at different longitudinalu stations on the same nominal axis still sum to(H,V,M)=(Pcosphi,Psinphi,0). Recompute both roots,J,the derived lower cut, beam-flange split, direct web actions, continuity plates, overlapping receiver unions and concurrent column panel from that same signed case. Real root and receiver compression modes stay active, and tensile rupture rows are conditional on actual tension or tensile bending surfaces.

0.9.35 already performs this whole-chain recomputation and separately labels the minimum45 design case for the welded compression branch. Its negative minimum trigger still depends on the welded-onlycompression_candidate, so the bolted extension must extend that exact-domain trigger; the current release does not already do it for negative boltedP.

For-45<P_actual<0kN, preserve actualP and completeD/U cuts, createP_design=-45kN once before the physical splits, retainD/U/other loads explicitly as background and recompute the entire synthetic chain. Actual and synthetic lower cuts have different provenance; the latter is not a Robot cut or actual frame combination. For actualzero, retainzero and the existing declared+45kN tensile convention, with no fabricated negative force. Positive inherited minimum behavior remains. The optional50%-member-capacity recommendation is separate and is not activated here. Friction detailing is a property of the physical connection, so when a positive case is evaluated for that same friction-type detail its slip check also applies.

## Frozen prospective BCC1 and finite acceptance

BCC1 was declared before the calculation: inherited300×300×12mm gusset,30mm clip,250mm roots, independent steels and completeD/U cuts; four metric16mm A325 through bolts at u385/445/505/565,phi45 degrees; L76.2×7.94; ClassB pretension91kN; one hardened qualification washer4mm thick and32mm outside diameter under the rotating nut, explicitly assumed dimensions rather than a catalog claim; grip31.88mm and tool radius18mm; continuation clear60mm;P=-100kN. This is a hypothetical restraint/detail qualification witness. ExistingBC1 atu370/430/490/550 fails this branch's full-stripe root projection and is not silently approved by sign reversal. The +15mm fixture shift is recorded, not a mutation of production or of the old fixture.

New independent results, forces in kN:

- Whitmorebw207.846097mm,Ag2494.153163mm²;Lmax164.029131mm,Le/r47.351131,chi.887936241,Nc,Rd503.329315,eta.198677083.
- Both root projections198.751418–345.720803mm fit. Column lower-end margin is only.251418mm; nominal geometry is not fabrication tolerance approval. Its variation must be tested rather than rounded away.
- Per-plane bolt demand12.5/R55.627134. Each gusset hole25/R136.533333; each angle wall12.5/R90.339556. First gussetlc133.815927mm; interior42mm; last angle60mm.
- Per complete bolt slip demand17.5/R72.8,eta.240384615, or8.75/36.4 per physical interface.
- Each angle localp/r_min4,chi.999152199,R260.687892; net compression yieldR228.427273. AL3b/t9.596977<12.727922.
- All reverse L candidates retain support and are inactive. Full-cap U maximum atu559.6mm hasAgv=Anv7617.982259mm²,Ant43.2mm²,R852.842473, demand100,eta.117254948. Its cap includes/excludes the last hole at100/75kN. Zero-cap U envelope atu556 givesR836.842473 andeta.119496803. Both legs exit the real clip.
- Supplemental net-bodyVM maximum21.651909711MPa atu386.165902mm;eta.095268403. Its resultant includes retained portions of both roots and all four included bolt forces.
- Signed(Hb,Vb,Hc,Vc)=(-37.049335,-35.589816,-33.661343,-35.120862).J=(-67.760013,-85.589816,+20kNm); lower cut=(+91.421356,+620.710678,-103.721356kNm).Top flange-88.405257,bottom+43.260313;panelQtop112.066600/Qbottom134.681669.
- The unchanged common top continuity/column receiver boundFAILS:316.808668MPa/313.636364MPa,eta1.010114594. The27 new local strength rows pass, but BCC1 is not a passing full connection. This real failure is preserved and no alternative load is used to rescue it.
- The separate-20 to-45kN minimum witness gives actual lower cut(+34.852814,+564.142136,-47.152814kNm) and synthetic(+52.530483,+581.819805,-64.830483kNm). Their concurrent receiver ratios are.744141191 and.827257879 respectively; they retain the same declared backgroundD/U.

Implementation acceptance must compare the frozen independent numerical witnesses; exercise both slip classes/plane counts and metric versus inch pretension; reverse each bearing wall; vary continuation/pitch/dn/materials; reject unsupported L/exit topology, absent/stale restraints, projection loss and local segment domain loss; preserve actual and minimum signed complete cuts; test common receiver failures and no doubledP. Native import, report and drawing must retain the detail/surface/pretension and restraint geometry identity. Existing tension and welded source results must remain covered. A final independent implementation review and applicable aggregate tests are required before any release. No implementation, packaging, upload or publishing is authorized by this method contract alone. Stop the study after this candidate and review.
