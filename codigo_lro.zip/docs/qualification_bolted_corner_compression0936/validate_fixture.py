"""Finite fixture and evidence-integrity validation; not production tests."""
from pathlib import Path
import json, math, hashlib, ast
R=Path(__file__).resolve().parent
f=json.loads((R/'FIXTURE_INPUT.json').read_text());o=json.loads((R/'ORACLE.json').read_text());baseline=json.loads((R.parent/'bolted_corner_scope20261012/FIXTURE_INPUT.json').read_text());records=[]
def test(name,condition,**detail):
 records.append(dict(name=name,passed=bool(condition),**detail))
def close(a,b,atol=1e-7):return abs(a-b)<=atol
fingerprints=json.loads((R/'FROZEN_SOURCE_PRESERVATION.json').read_text())
test('Immutable controlling production files unchanged',all(hashlib.sha256((R.parent/'review0935/source0935'/p).read_bytes()).hexdigest()==sha for p,sha in fingerprints.items()))
test('Actual complete D and U cuts unchanged from BC1',all(f['case'][k]==baseline['case'][k] for k in ['beam_cut','upper_column_cut']))
test('Input hash matches computed witness',hashlib.sha256((R/'FIXTURE_INPUT.json').read_bytes()).hexdigest()==o['input_sha256'])
test('One predeclared candidate has negative actual force',f['case']['P']==-100000 and f['geometry']['bolted_brace']['bolt_stations_u']==[385,445,505,565])
for name in ['build_fixture.py','common_case.py']:
 tree=ast.parse((R/name).read_text());imports=[(n.module if isinstance(n,ast.ImportFrom) else ','.join(a.name for a in n.names)) for n in ast.walk(tree) if isinstance(n,(ast.Import,ast.ImportFrom))]
 test(name+' does not import production',not any('lro' in (s or '') for s in imports),imports=imports)
plate=o['plate_compression'];test('Full selected stripe contained and both projected root intervals supported',plate['contained'] and all(p['pass_'] for p in plate['projection_checks'].values()))
test('Column projection margin is retained unrounded and positive',0<plate['projection_checks']['column']['stripe'][0]-plate['projection_checks']['column']['seam'][0]<.3)
test('Old BC1 is not admitted by the new projection condition',all(v['stripe'][0]<v['seam'][0] for v in o['legacy_BC1_projection_failure'].values()))
test('Lmax includes interior support switch and exceeds l1 and three-line mean',plate['Le']>plate['l1'] and plate['Le']>plate['three_line_average'])
test('All reverse L paths physically inactive',all(not p['active'] and p.get('reason') in ['retained_supported_contact','cap_on_supported_edge'] for p in o['paths'] if p['side']!='tangent_U'))
test('U paths have distinct inward legs on free clip with no retained root',all(p['path_uv'][0][1]!=p['path_uv'][-1][1] and p['free_exits']==['clip_free','clip_free'] and not p['support_hits'] for p in o['paths'] if p['active']))
full=o['block_governing'];zero=o['zero_cap_shear_only_witness'];test('Included and excluded last-hole force limits preserved',full['captured_bolts']==[1,2,3,4] and full['excluded_crossed_bolts']==[1,2,3] and full['demand_limits']==[75000,100000])
test('Cap interior stationary point not replaced by center-only check',close(full['u'],559.6) and full['Ant']>0)
test('Zero-cap capacity is not added to full-cap resistance',zero['conservative_zero_cap_resistance']<full['resistance'] and close(zero['u'],556.))
test('Service branch tied to explicit normal ultimate classification',f['case']['combination_type']=='normal_ultimate' and o['service_cases']['-100000.0']['signed_local_brace_service_force']==-70000)
test('Two real slip interfaces without double counting central-hole force',all(close(z['resistance'],72800.) and close(z['demand'],17500.) for z in o['checks'] if z.get('component')=='slip'))
test('Ultimate bolt shear and bearing remain distinct from friction',len([z for z in o['checks'] if z.get('component')=='bolt_shear'])==8 and len([z for z in o['checks'] if z.get('component')=='bearing'])==8)
test('No Ct/tensile rupture rows in pure compression fixture',not any('rupture' in z['id'] or 'Ct' in z['id'] for z in o['checks']))
test('Angle published rmin, AL3 and local interval are separate',o['local_angle']['r']==15. and o['local_angle']['Le_over_r']==4. and o['local_angle']['AL3_ratio']<o['local_angle']['AL3_limit'])
test('Body witness includes both retained roots and all four bolt loads',set(o['body_governing']['sources'])=={'bolt1','bolt2','bolt3','bolt4','beam_root','column_root'})
test('Each new local strength row passes but is not called full joint pass',all(z['pass_'] for z in o['checks']) and o['common_cases']['-100000.0']['concurrent_receiver']['utilization']>1)
for tag,x in o['common_cases'].items():test('Complete assembly equilibrium '+tag,max(map(abs,x['assembly_residual']))<1e-6)
a=o['common_cases']['-20000.0'];d=o['common_cases']['-45000.0'];test('Actual and synthetic minimum lower cuts differ and roots scale signed',a['lower_cut']!=d['lower_cut'] and all(close(d[k],2.25*a[k]) for k in ['Hb','Vb','Hc','Vc']))
result=dict(status='PASS' if all(r['passed'] for r in records) else 'FAIL',scope='Independent candidate arithmetic/evidence validation only; no production implementation tests',count=len(records),checks=records)
(R/'VALIDATION.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
assert result['status']=='PASS'
