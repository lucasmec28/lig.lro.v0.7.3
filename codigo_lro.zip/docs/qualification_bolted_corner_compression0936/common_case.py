"""Independent common equilibrium calculator copied from prior bounded compression study; no application import. Function source provenance is recorded in PROVENANCE.md."""
import math
def case(P):
 H=P*co; V=P*si; Hc=ec*V/(eb+g['beta']); Hb=H-Hc; Vb=eb*Hb/g['alpha']; Vc=V-Vb
 D=c['beam_cut']; U=c['upper_column_cut']; xj=ec
 Jx=D['Fx']+Hb; Jy=D['Fy']+Vb
 Jm=D['M']+(D['point'][0]-xj)*D['Fy']-D['point'][1]*D['Fx']+g['alpha']*Vb-eb*Hb
 Lx=-(U['Fx']+Jx+Hc); Ly=-(U['Fy']+Jy+Vc)
 ly=c['lower_column_cut_point'][1]
 Lm=-(U['M']+U['point'][0]*U['Fy']-(U['point'][1]-ly)*U['Fx']+Jm+xj*Jy+ly*Jx+ec*Vc-(eb+g['beta']-ly)*Hc)
 Af=b['bf']*b['tf']; Aw=(b['d']-2*b['tf'])*b['tw']; A0=2*Af+Aw; h0=b['d']-b['tf']; Nw=Jx*Aw/A0; Ft=Jx*Af/A0-Jm/h0; Fb=Jx*Af/A0+Jm/h0
 Qtop=-(U['Fx']+Hc+Ft); Qbottom=Qtop-Nw
 roots={}
 for name,normal,shear,mem,interior in [('beam',Vb,Hb,b,False),('column',Hc,Vc,col,True)]:
  ends=g[name+'_seam']; length=math.dist(*ends); q=math.hypot(normal,shear)/length; ratio=length/mem['d']; mult=3*ratio if interior or ratio<=.2 else 4*ratio-.2
  crip=(.66 if interior else .33)*mem['tw']**2*(1+mult*(mem['tw']/mem['tf'])**1.5)*math.sqrt(E*m[name]['fy']*mem['tf']/mem['tw'])/ga
  roots[name]={'signed_normal':normal,'signed_shear':shear,'length':length,'weld_line_demand':1.25*q,'weld_line_resistance':2*g['root_fillet_leg']/math.sqrt(2)*.6*m['weld']['fw']/m['gamma_w2'],'receiver_web_crippling_resistance':crip,'compression_mode_active':normal<0}
 # Independent column free-body field. Fit its exact quadratic moment on
 # each load-station interval using three values, then test vertex/endpoints.
 ytop=(b['d']-b['tf'])/2; wl=220.; sy0,sy1=[p[1] for p in g['column_seam']]
 def field(y,branch_y):
  xx=U['Fx']; yy=U['Fy']; mm=U['M']- (U['point'][1]-y)*U['Fx']
  for py,px in [(ytop,Ft),(-ytop,Fb)]:
   if py>branch_y:xx+=px;mm-=(py-y)*px
  for low,high,fx,fyline in [(sy0,sy1,Hc,Vc),(-wl/2,wl/2,Nw,Jy)]:
   frac=1. if branch_y<=low else 0. if branch_y>=high else (high-y)/(high-low)
   yc=(low+high)/2 if branch_y<=low else (high+y)/2
   xx+=frac*fx; yy+=frac*fyline; mm+=ec*frac*fyline-(yc-y)*frac*fx
  return -xx,-yy,-mm
 stations=sorted(set([ly,U['point'][1],sy0,sy1,-wl/2,wl/2,-ytop,ytop])); fields=[]
 for lo,hi in zip(stations,stations[1:]):
  mid=(lo+hi)/2; halfspan=(hi-lo)/2
  p0,p1,p2=[field(y,mid) for y in (lo,mid,hi)]; fields.extend([p0,p2])
  aa=(p0[2]+p2[2])/2-p1[2]; bb=(p2[2]-p0[2])/2
  if abs(aa)>1e-8:
   z=-bb/(2*aa)
   if -1<z<1:fields.append(field(mid+z*halfspan,mid))
 Nmax=max([abs(U['Fy']),abs(Ly)]+[abs(z[1]) for z in fields]); Mmax=max([abs(U['M']),abs(Lm)]+[abs(z[2]) for z in fields])
 baseline=Nmax/col['Ag']+Mmax/col['Wx']; panel_tau=max(abs(Qtop),abs(Qbottom))/(col['d']*col['tw'])
 cp=g['continuity']; cpL=cp['effective_web_weld_x'][1]-cp['effective_web_weld_x'][0]; cpE=sum(cp['effective_flange_weld_z_each_positive'])/2-col['tw']/2; weld=cp['web_fillet_leg']
 local_normal=3*abs(Ft)*cpE/(cpL**2*(2*weld));local_shear=abs(Ft)/(cpL*min(col['tw'],4*weld)); bound=baseline+local_normal+math.sqrt(3)*(local_shear+panel_tau)
 receiver={'Nmax':Nmax,'Mmax':Mmax,'baseline_normal':baseline,'panel_tau':panel_tau,'local_normal':local_normal,'local_shear':local_shear,'top_concurrent_bound':bound,'resistance':m['column']['fy']/ga,'utilization':bound/(m['column']['fy']/ga)}
 residual=[D['Fx']+U['Fx']+Lx+H,D['Fy']+U['Fy']+Ly+V,D['M']+D['point'][0]*D['Fy']-D['point'][1]*D['Fx']+U['M']+U['point'][0]*U['Fy']-U['point'][1]*U['Fx']+Lm-ly*Lx]
 return {'P':P,'H':H,'V':V,'Hb':Hb,'Vb':Vb,'Hc':Hc,'Vc':Vc,'J':[Jx,Jy,Jm],'lower_cut':[Lx,Ly,Lm],'Ftop':Ft,'Fbottom':Fb,'Nweb':Nw,'Qtop':Qtop,'Qbottom':Qbottom,'roots':roots,'concurrent_receiver':receiver,'assembly_residual':residual}
