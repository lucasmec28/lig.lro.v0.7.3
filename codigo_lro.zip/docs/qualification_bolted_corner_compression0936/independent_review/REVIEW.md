# Final independent method review: bolted symmetric 2L-T corner compression

12 October 2026. One final independent review of the bounded candidate. No production edits or publishing.

## Decision

**GO to implement and independently test the bounded local branch, read together with the limitations and clarifications below.** No additional source or generic FEA is required for this explicitly restrained, compact, short-interval ordinary detail. This is method qualification only. The production adapter, UI, imports, drawings and reports remain to be implemented and independently accepted.

**BCC1 is not a passing full joint.** Its unchanged concurrent top continuity/column receiver screen has utilization1.010114593606587. The passing new local checks must not hide that failure. The fixture is a hypothetical numerical/restraint witness and is not evidence that any built connection has the assumed restraints or installed pretension.

Select the **zero-cap-tension inward tangent-U shear envelope** as the first implementation's strength model. The full-cap result is retained as a diagnostic witness of physically reversed block kinematics and interior extrema. Never add their capacities or select the favorable result.

## Source applicability and local/global boundary

NBR6.1.11.2(c), PDF94/printed72, explicitly points to ends of built-up members under5.3.6.2. NBR5.3.6.2 concerns two same-section profiles working together, directly contacting or separated by spacer-plate thickness and intermittently connected along the member. It is a member-system provision whose end-connection condition applies at the actual load-introduction end of such a member. A brace-to-gusset attachment at that end is not exempt merely because this program reports a local result.

Conversely, the presence of two mirrored angles at one joint, by itself, does not prove that every possible two-angle member belongs to that whole-member procedure or that its global requirements are met. The candidate correctly makes pretensioned ClassA/B friction-type ends an **explicit initial-domain restriction**, rather than a universal inference that all objects called2L must receive the same code classification. This restriction is accepted. It closes the local end fastening requirement without certifying the member's far end, global buckling, intermediate stitches, the0.75 slenderness condition, or modified member buckling under5.3.6.3. Those excluded member checks are neither inputs invented for this local calculator nor a local PASS.

For standard holes,6.3.4.2 assigns slip to the service limit state. The accepted local service check uses6.3.4.4 and the separately identified normal-ultimate combination's permitted0.70 shortcut. It does not convert the complete frame cuts into an actual service analysis. No unknown, special or exceptional ultimate case may be automatically scaled by0.70. The separately labeled minimum-force slip safeguard is conservative implementation bookkeeping and is not a real rare-service combination supplied by NBR.

Ultimate bolt shear and bearing under6.3.3 remain independent. Metric16mm A325 pretension is91kN from Table19; the5/8-inch85kN row is different. ClassB μ0.50, Ce1, and the two physical slip interfaces give72.8kN per through-bolt. Service demand is17.5kN at the actual−100kN normal-ultimate force. Same-class per-interface checking gives8.75/36.4kN. Friction capacity is not added to ultimate shear capacity.

## Accepted local brace-end model

The p_max/r_min≤25 restriction is a selected short-connection-interval domain, not a general normative bolt-pitch rule. For the actual restrained stations, K1 and fullC/2 throughout each interval are a conservative conventional local segment idealization. The full5.3 compression curve is computed even for very short lengths; the known duplicated≤25 source inequality is not exploited. AL3 compactness, gross compression, supplemental net compression yielding, segment stability and each physical hole wall remain separate checks.

AL3 uses the actual angle legs and does not pretend that the bolt row is a continuous weld. The exact published Gerdau r_min15.00mm is available, givingp/r=4.00. No new global brace length, fictitious root radius or global2L stability certificate is needed.

**Actual restraint remains essential.** Relative translation/twist restraint at each assumed bolt station and the overall brace-end out-of-plane restraint must be supported by the actual clamp/contact/hardware and connected detail. Merely pairing angles, satisfying pitch, or adding a confirmation checkbox is insufficient. Unknown or absent physical restraint gives that specific unverified component. A geometry-bound declaration may record the responsible designer's conventional detail model; this mathematical review does not measure restraint stiffness or certify construction.

The unloaded support-side angle tip is not the loaded compression bearing edge. The continuing angle beyond the last bolt supplies the required actual clear loaded direction; no free-end bearing length may be invented there. The continuing global member remains outside the local result.

## Independent numerical evidence

The independent calculators in this directory import neither production modules nor the candidate calculators. The final review reconstructs root forces with a4×4 equilibrium solve; derives the lower cut directly from whole-assembly equilibrium; reconstructs the column section field piecewise; computes physical gross/net body sections by polygon half-plane clipping and global force/moment sums; searches body extrema independently with96 subdivisions per smooth interval; and evaluates analytical U stationary points. The oracle was read only after those calculations completed.

All95 final comparisons pass. Earlier independent local arithmetic separately matches gusset stability, angle segment, slip, bearing and zero-cap prefixes.

- Gusset width207.846096908mm; Lmax164.029130879mm; chi0.887936240970; resistance503.329314516kN.
- Angle segment chi0.999152199254; resistance260.687891987kN each; net compression yield228.427272727kN each; AL3 ratio9.59697733<12.72792206.
- Zero-cap U governing capu556mm; Agv=Anv7531.582258647mm²; resistance836.842473183kN; demand100kN; utilization0.119496802809.
- Full-cap diagnostic governing capu559.6mm; Agv=Anv7617.982258647mm²; Ant43.2mm²; resistance852.842473183kN; utilization0.117254948181. The included/excluded last-hole demand bounds are100/75kN.
- The inward L blocks retain positive support contact. The tangent-U strip lies between both full support edges and reaches the genuine free clip. For this45-degree witness the root-admissibility result also follows directly: all inward negative-side L regions retain beam contact and positive-side regions retain column contact; v±9mm lies between the nearest beam v−18.031mm and column v+24.395mm endpoints.
- Body peakVM21.651909710885MPa at independently locatedu386.165901856mm, compared with candidate386.165901564mm. The included cut-hole limit retains all four bolts and partial tractions from both roots. Body maxima remain numerical extrema, not an interval certificate or pointwise hole-pressure solution. Maximum tensile normal stress in the sampled/refined BCC1 family is approximately1.3×10^−12MPa, hence zero within roundoff.
- Roots(Hb,Vb,Hc,Vc)=(-37.049335212,-35.589815946,-33.661342907,-35.120862172)kN.
- J=(-67.760013331,-85.589815946,+20)kN/kNm; lower cut(+91.421356237,+620.710678119,-103.721356237)kN/kNm.
- Top/bottom flange forces−88.405256738/+43.260312716kN; Qtop/Qbottom112.066599644/134.681668953kN.
- The concurrent receiver resistance313.636363636MPa is exceeded by316.808667995MPa. This exact failure is retained.
- All five cases−100,−20,−45,0,+45kN reproduce the candidate signed common chain and close whole-assembly force/moment equilibrium within1e−6N/Nmm. Actual−20 and synthetic−45kN lower cuts and provenance remain distinct.
- The nominal column root-projection margin is only0.251418473mm. This satisfies the fixture's mathematical test; it is not a fabrication tolerance allowance. LegacyBC1 still fails that projection domain.

## Binding clarifications for implementation

These clarify the accepted candidate without a second geometry/load candidate or changed numerical witness.

1. The selected zero-cap capacity is the oracle field `conservative_zero_cap_resistance` at `zero_cap_shear_only_witness`,836842.473182953N. That object's ordinary `resistance` and `utilization` fields still describe the full-cap formula evaluated at the same station. They must not be mistaken for the selected zero-cap result. The final primary strength row `gusset_inward_tangent_U_zero_cap` correctly uses836842.473182953N and utilization0.119496802809; its nested full-cap diagnostic fields remain distinguishable by the explicit model label.
2. The inherited `slip_credit=false` fixture flag means no favorable friction addition to ultimate bearing/shear; it must not suppress the explicitly required service slip check. Native state must express that distinction clearly.
3. The inherited generic fixture sentence mentioning1L is historical data and does not expand this compression domain. Single-angle compression remains excluded.
4. The final fixture explicitly specifies one hardened washer under the rotating nut,4mm thick and32mm outside diameter, as hypothetical qualification dimensions. This satisfies the stated6.8.4.2 hardware position; it is not a product conformity claim. The resulting grip31.88mm is below5db=80mm, and washer radius16mm fits the existing18mm tool envelope. The correction changes no plate, bolt-position, load or strength witness. Actual hardware compliance, thickness, access and grip remain validated inputs included in restraint-relevant geometry.
5. The bolted restraint identity must include count, stations, pitch, gauge, holes, connected footprint/contact, hardware and relevant pretension/surface/detail status. The existing welded function's deliberate exclusion of bolt controls is not reusable unchanged. A material/action change need not invalidate a geometric declaration unless it changes the actual restraint detail, but a change of clamping condition does.
6. Retain actual positive tensile body or receiver surfaces when signed bending produces them. An absolute value of compressive stress must not become a tensile rupture demand. BCC1 itself has no substantive positive body surface. An independent couple or mixed root flow remains outside this direct axial model.
7. The geometry restriction is substantive: all reverse L paths must remain physically inactive and the admitted U paths must reach the qualified real inner free edge without retaining a support. Different exit topology or a newly active L mechanism is a specific future adapter qualification, not silently ignored and not declared a generic strength failure.

## Stop boundary

This completes the one requested independent method review. No further source hunt, alternate fixture rescue, production edit, release packaging, publishing or fabricated-detail approval is part of this result. Implementation must still reproduce the selected conservative checks, retain real common failures, pass the contract's finite mutation/sign/provenance tests, and receive independent acceptance against the completed output.

## Exact reviewed identities

- BOLTED_COMPRESSION_CONTRACT.md: `e67f6b7d2bc5db6736477331ded1fcf420ad36a51ecb33ed2dd82a0bf9894365`
- FIXTURE_INPUT.json: `3f5e99c01dcb2e5f03716f62dc1c5962f4de05ba33cdd23e0ee9e9010c273716`
- ORACLE.json: `ca0decbf092195401de787f52aad48a354f32ce21609da5232eaae3e8c69d648`
- build_fixture.py: `aee689834ac59158d944d36e72e931e9a96e669fdb0b5a709d911b9f307f17dc`
- common_case.py: `4a20cbb3dbb29da6f8bb780480d79708f3f516d3917ea5cc7339f231a36918bd`
