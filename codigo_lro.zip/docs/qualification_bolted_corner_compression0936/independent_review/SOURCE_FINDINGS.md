# Independent source findings for bolted 2L-T compression qualification

12 October 2026. Review notes for the candidate method; no production implementation or fabrication approval.

## Material finding

NBR 8800:2024 / Errata1:2025 PDF94 / printed72, clause6.1.11.2(c), explicitly requires welds or high-strength friction-type connections at built-up member ends under5.3.6.2. Pretension and ClassA/B surface identification cannot substitute for every slip check. A conservative initial bolted 2L-T compression domain may impose that requirement on all admitted ends, while retaining ultimate bolt shear and bearing checks independently.

## Verified page map and factors

- PDF73 / printed51, 5.3.6.1: component length between adjacent interconnections divided by its minimum radius must not exceed0.75 of the governing built-up-member slenderness, and at least two uniformly spaced interconnections are required along the member. This is a whole-member condition. It cannot be verified using local gusset pitch alone and must not be claimed as a local PASS.
- Same page,5.3.6.2: the specified two-identical-profile built-up compression procedure requires welded end connections or bolts pretensioned against ClassA/B contact surfaces. PDF74 / printed52,5.3.6.3 gives the modified member buckling rule; the welded/pretensioned intermediate-connection branch changes at component slenderness40. Neither40 nor a presumed global member slenderness is needed as an invented local connection input.
- PDF94 / printed72,6.1.11.2(c): built-up ends per5.3.6.2 use friction-type high-strength bolts or welds. PDF93 / printed71,6.1.11.1 separately requires pretension for ordinary stress reversal; that is weaker than satisfying the built-up-end slip requirement.
- PDF108 / printed86,6.3.4.1: slip design still must satisfy6.3.3 ultimate shear/bearing. Clause6.3.4.2 assigns standard round holes to service slip, not ultimate slip.
- PDF110 / printed88,6.3.4.4: standard-hole nominal service slip resistance per physical bolt is0.80 μ Ce F_Tb ns times the applied-bolt-tension reduction [1−F_t,Sk/(0.80F_Tb)]. Compare the rare-service shear or the expressly permitted simplified0.70 times normal-ULS shear. Unknown action classification does not establish applicability of that simplification.
- PDF109 / printed87: μA0.30; μB0.50. Ce1.0 for this direct L–gusset–L stack without fillers. Two real sliding interfaces per through bolt. There is no extra hole factor in the selected standard-round-hole service branch. Class surface extent/preparation must be physically specified; classification is not a freely chosen numerical coefficient.
- PDF132 / printed110,6.8.4.1 and PDF133 / printed111,Table19: metric16mm A325 minimum pretension91kN. The separate5/8-inch row is85kN. Do not use the nominal diameter16mm with a silently selected imperial pretension. Table19 and the actual fastener grade/size must stay coupled.
- PDF69 / printed47,Table4AL3 covers single/multiple angle legs with spacer plates using0.45sqrt(E/fy). Do not grant the continuously attached AL4 coefficient to a discretely bolted leg.
- PDF93 / printed71,6.1.8.2 covers ordinary statically axially loaded simple/double angles; its text does not restrict the angle-end axis exception to tension. It does not manufacture out-of-plane restraint or erase real work-point offsets.
- PDF116–117 / printed94–95,6.5.4 provides connection-element compression equations and points to5.3. The duplicate ≤25 inequality is a visible source anomaly. Computing the full5.3 reduction for all positive local lengths avoids exploiting it.

## Local brace-end compression interpretation

A bounded conventional end-region calculation is feasible without any global brace length. Treat each directly clamped angle interval between actual through bolts as a local compression element only when the physical detail supports the assumed relative lateral translation and twist restraint at those stations. K1 and full C/2 in each interval are conservative selected local modeling choices, not a verbatim NBR pin-at-every-bolt rule. AL3 addresses local plate slenderness; it does not supply missing discrete attachment restraint. The first automatic domain may restrict p_max/r_min≤25 and retain full5.3 reduction rather than a yielding-only shortcut.

Gerdau P03R30 provides r_min15.00mm directly; it is not a rolled root radius. Thus p60mm/r_min=4.00. The existing catalog JSON preserves this exact value even though the top-level runtime angle mapping does not expose it. Use the actual producer identity and independent material. Retain full-force net compression yielding as a conservative supplemental section screen; do not call Ct·An·fu a compression resistance.

A physical restraint declaration must identify the current bolt stack, pretensioned contact, hardware/access and the actual detail resisting relative translation/twist. The independent overall brace-overlap out-of-plane boundary of the gusset equivalent-column model must also exist. Two mirrored angles alone prove neither restraint. Unknown or absent details are exact blockers; they do not require a general FEA demand or a fabricated global brace length.

The first/last connection bolts delimit the local load-transfer region. The support-side free angle tip is unloaded in pure compression; the continuing member beyond the last bolt is outside the local connection result. Its actual hole-free continuation must still establish the last angle-hole bearing length. Global member stiffness, global flexural/flexural-torsional buckling and intermediate stitches remain with the member designer and are not a local strength PASS.

## Physical reversal and block mechanism

For compression, force on gusset holes points−u and force on each angle hole points+u. The first gusset hole sees the real inward ray exit; subsequent gusset holes see the preceding clear pitch. Angle interior holes see the following clear pitch. The last angle hole sees actual continuing material/next discontinuity, never the old support-side free tip.

An inward gusset U block occupies u≤cap. Under−u loading it pulls away from the retained+u plate across its transverse cap; the local cap can therefore be tensile although the brace is compressed. A no-cap-tension-credit shear-only U resistance is a conservative alternative for that real detachable geometry. Existing outward angle-tip tension blocks are inactive.

DG29 AppendixC printed381 says ordinary corner examples tend to be controlled by LOAM in compression and block tearout in tension. This is not a prohibition on a real reversed loaded-free-edge path. Its examples do not establish that an inward free clip can be ignored. NBR6.5.6 defines local shear and transverse tension areas, consistent with the reversed mechanism above.

For the announced BC-C1 polygon, the inward L alternatives retain positive full physical beam/column contact and are inactive. Tangent-U legs at v±9mm reach the real inner clip without retaining either support. Dropping the transverse tensile term makes the force-inclusion tangencies and support/geometry transitions sufficient candidate events for that declared shear-only family; a numerical maximization alone would not prove an arbitrary full family.

## Evidence integrity

The supplied corrected searchable text file contains only298 page breaks and no searchable standard text. Findings above were checked against existing or newly rendered corrected PDF page images. OCR is an index, not authority for equations. The ordinary AISC built-up-end wording differs from the explicit NBR6.1.11.2(c); do not silently replace the latter with an AISC user note.

The independent local numeric calculator imports standard-library arithmetic only. It does not import production or parent-calculator modules. The final method decision remains pending inspection of the parent's complete candidate contract and frozen witness.
