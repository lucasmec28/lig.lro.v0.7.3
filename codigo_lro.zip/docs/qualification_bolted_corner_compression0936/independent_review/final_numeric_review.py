"""Final independent arithmetic review. No production or candidate-code imports."""
import json, math, hashlib
from pathlib import Path
R=Path(__file__).resolve().parent;BASE=R.parent
f=json.loads((BASE/'FIXTURE_INPUT.json').read_text());g=f['geometry'];m=f['materials'];cat=f['catalog'];c=f['case'];a=cat['angle_each'];b=cat['beam'];col=cat['column'];bolt=g['bolted_brace']
ca=math.cos(math.radians(bolt['phi_deg']));sa=math.sin(math.radians(bolt['phi_deg']));eu=[ca,sa];ev=[-sa,ca]
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def cross(a,b):return a[0]*b[1]-a[1]*b[0]
def sub(a,b):return [x-y for x,y in zip(a,b)]
def mid(a,b):return [(x+y)/2 for x,y in zip(a,b)]
def solve(A,y):
 rows=[list(map(float,row))+[float(x)] for row,x in zip(A,y)]
 for k in range(len(rows)):
  ix=max(range(k,len(rows)),key=lambda i:abs(rows[i][k]));rows[k],rows[ix]=rows[ix],rows[k]
  d=rows[k][k];rows[k]=[v/d for v in rows[k]]
  for i in range(len(rows)):
   if i==k:continue
   d=rows[i][k];rows[i]=[v-d*w for v,w in zip(rows[i],rows[k])]
 return [row[-1] for row in rows]
B=mid(*g['beam_seam']);K=mid(*g['column_seam']);Jp=g['beam_joint']['point_J'];lp=c['lower_column_cut_point'];D=c['beam_cut'];U=c['upper_column_cut']
Aeq=[[1,0,1,0],[0,1,0,1],[-(B[1]-Jp[1]),B[0]-Jp[0],0,0],[-B[1],B[0],-K[1],K[0]]]
def common(P):
 F=[P*z for z in eu];Hb,Vb,Hc,Vc=solve(Aeq,F+[0.,0.]);dr=[D['Fx'],D['Fy']];ur=[U['Fx'],U['Fy']]
 LF=[-sum(x) for x in zip(dr,ur,F)];LM=-(D['M']+cross(D['point'],dr)+U['M']+cross(U['point'],ur)+cross(lp,LF))
 JF=[dr[0]+Hb,dr[1]+Vb];JM=D['M']+cross(sub(D['point'],Jp),dr)+cross(sub(B,Jp),[Hb,Vb])
 Af=b['bf']*b['tf'];Aw=(b['d']-2*b['tf'])*b['tw'];At=2*Af+Aw;hh=b['d']-b['tf'];Nw=JF[0]*Aw/At;Ft=JF[0]*Af/At-JM/hh;Fb=JF[0]*Af/At+JM/hh
 Qt=-(U['Fx']+Hc+Ft);Qb=Qt-Nw
 def field(y,branch):
  forces=[[U['Fx'],U['Fy']]];moments=[U['M']+cross(sub(U['point'],[0,y]),ur)]
  for yy,Fx in [(hh/2,Ft),(-hh/2,Fb)]:
   if yy>branch:forces.append([Fx,0]);moments.append(cross([g['ec'],yy-y],[Fx,0]))
  for lo,hi,load in [(g['column_seam'][0][1],g['column_seam'][1][1],[Hc,Vc]),(-110,110,[Nw,JF[1]])]:
   if branch>=hi:continue
   start=lo if branch<=lo else y;frac=(hi-start)/(hi-lo);part=[z*frac for z in load];forces.append(part);moments.append(cross([g['ec'],(hi+start)/2-y],part))
  return [-sum(v[0] for v in forces),-sum(v[1] for v in forces),-sum(moments)]
 ys=sorted({lp[1],U['point'][1],hh/2,-hh/2,-110,110,*[p[1] for p in g['column_seam']]});vals=[]
 for l,h in zip(ys,ys[1:]):
  md=(l+h)/2;q0,q1,q2=[field(x,md) for x in [l,md,h]];vals.extend([q0,q2]);aa=(q0[2]+q2[2])/2-q1[2];bb=(q2[2]-q0[2])/2
  if abs(aa)>1e-8 and -1<-bb/(2*aa)<1:vals.append(field(md-(h-l)/2*bb/(2*aa),md))
 Nmax=max(abs(LF[1]),abs(U['Fy']),*[abs(v[1]) for v in vals]);Mmax=max(abs(LM),abs(U['M']),*[abs(v[2]) for v in vals]);cp=g['continuity'];Lw=cp['effective_web_weld_x'][1]-cp['effective_web_weld_x'][0];e=sum(cp['effective_flange_weld_z_each_positive'])/2-col['tw']/2;s=cp['web_fillet_leg']
 bound=Nmax/col['Ag']+Mmax/col['Wx']+3*abs(Ft)*e/(Lw*Lw*2*s)+math.sqrt(3)*(abs(Ft)/(Lw*min(col['tw'],4*s))+max(abs(Qt),abs(Qb))/(col['d']*col['tw']))
 return {'roots':[Hb,Vb,Hc,Vc],'J':JF+[JM],'lower':LF+[LM],'flanges':[Ft,Fb],'Nweb':Nw,'panel':[Qt,Qb],'receiver_eta':bound/(m['column']['fy']/m['gamma_a1']),'receiver_bound':bound,'residual':[sum(x) for x in zip(dr,ur,F,LF)]+[D['M']+cross(D['point'],dr)+U['M']+cross(U['point'],ur)+LM+cross(lp,LF)]}
commons={str(P):common(P) for P in [-100000.,-20000.,-45000.,0.,45000.]};ff=commons[str(float(c['P']))];Hb,Vb,Hc,Vc=ff['roots'];us=bolt['bolt_stations_u'];rad=bolt['physical_hole_diameter']/2;t=g['gusset_t'];P=c['P']
# Clip the infinite force-normal line against the five polygon half-planes.
poly=g['gusset_polygon']
def section_bounds(u):
 base=[u*z for z in eu];lo=-math.inf;hi=math.inf
 for q,r in zip(poly,poly[1:]+poly[:1]):
  edge=sub(r,q);const=cross(edge,sub(base,q));coef=cross(edge,ev)
  if abs(coef)<1e-12:
   if const< -1e-8:return None
  elif coef>0:lo=max(lo,-const/coef)
  else:hi=min(hi,-const/coef)
 return None if hi-lo<1e-8 else [lo,hi]
root_forces=[('beam',[-Hb,-Vb]),('column',[-Hc,-Vc])]
def body(u,inc,net):
 bounds=section_bounds(u)
 if bounds is None:return None
 lo,hi=bounds;hh=max([math.sqrt(max(0,rad*rad-(u-z)**2)) for z in us if abs(u-z)<=rad]+[0]) if net else 0.
 area=t*(hi-lo-2*hh);vbar=t*(hi*hi-lo*lo)/(2*area);I=t*(hi**3-lo**3-2*hh**3)/3-area*vbar*vbar
 origin=[u*eu[k]+vbar*ev[k] for k in [0,1]];forces=[];mom=[]
 for z in us:
  retain=(u<=z+rad+1e-8) if inc else (u<z-rad-1e-8)
  if retain:
   force=[P/len(us)*k for k in eu];point=[z*k for k in eu];forces.append(force);mom.append(cross(sub(point,origin),force))
 for name,force in root_forces:
  pp,qq=sorted(g[name+'_seam'],key=lambda p:dot(p,eu));uu=dot(pp,eu);vv=dot(qq,eu)
  if u>=vv:continue
  q=max(0,(u-uu)/(vv-uu));start=[pp[k]+q*(qq[k]-pp[k]) for k in [0,1]];part=[(1-q)*v for v in force];forces.append(part);mom.append(cross(sub(mid(start,qq),origin),part))
 N=sum(dot(v,eu) for v in forces);V=sum(dot(v,ev) for v in forces);M=sum(mom);sigs=[N/area-M*(v-vbar)/I for v in [lo,hi]]
 return {'u':u,'include':inc,'net':net,'A':area,'centroid':vbar,'I':I,'N':N,'V':V,'M':M,'sigma':sigs,'VM':max(math.hypot(s,math.sqrt(3)*1.5*V/area) for s in sigs)}
events=sorted({dot(p,eu) for p in poly}|{u+d for u in us for d in [-rad,0,rad]}|{dot(p,eu) for name,_ in root_forces for p in g[name+'_seam']});events=[x for x in events if x<=us[-1]+rad]
def maximize(fn,left,right):
 for _ in range(90):
  x=left+(right-left)*.3819660112501051;y=left+(right-left)*.6180339887498949
  if fn(x)>fn(y):right=y
  else:left=x
 return (left+right)/2
bodyrows=[]
for inc in [False,True]:
 for net in [False,True]:
  for lo,hi in zip(events,events[1:]):
   grid=[lo+(hi-lo)*k/96 for k in range(97)];rows=[body(x,inc,net) for x in grid];bodyrows.extend(x for x in rows if x)
   for k in range(1,96):
    if rows[k] and rows[k-1] and rows[k+1] and rows[k]['VM']>max(rows[k-1]['VM'],rows[k+1]['VM']):
     best=maximize(lambda x:body(x,inc,net)['VM'],grid[k-1],grid[k+1]);bodyrows.append(body(best,inc,net))
bestbody=max(bodyrows,key=lambda z:z['VM'])
# Exact full-cap U derivative events; the clip is x+y=ec+eb+30 for this witness.
clip=(g['ec']+g['eb']+30)/math.sqrt(2);Urows=[]
for k,uj in enumerate(us,1):
 for ratio in [None,0.,-1.2*m['gusset']['fy']/m['gusset']['fu'],-1.2]:
  cap=uj-rad if ratio is None else uj+rad*ratio/math.hypot(1.,ratio);hh=0 if ratio is None else math.sqrt(max(0,rad*rad-(cap-uj)**2));Agv=2*(cap-clip)*t;Ant=(2*rad-2*hh)*t
  Ry=(.6*m['gusset']['fy']*Agv+.5*m['gusset']['fu']*Ant)/m['gamma_a2'];Rr=(.6*m['gusset']['fu']*Agv+.5*m['gusset']['fu']*Ant)/m['gamma_a2'];D=-P*k/len(us)
  Urows.append({'u':cap,'Agv':Agv,'Ant':Ant,'resistance':min(Ry,Rr),'demand':D,'eta':D/min(Ry,Rr),'zero_cap_R':min(.6*m['gusset']['fy']*Agv,.6*m['gusset']['fu']*Agv)/m['gamma_a2']})
bestU=max(Urows,key=lambda z:z['eta']);zeroU=max(Urows,key=lambda z:z['demand']/z['zero_cap_R'])
# Oracle is first read after independent arithmetic completes.
o=json.loads((BASE/'ORACLE.json').read_text());checks=[]
def check(label,x,y,abstol=1e-6,reltol=1e-9):
 ok=math.isclose(x,y,abs_tol=abstol,rel_tol=reltol);checks.append({'id':label,'independent':x,'oracle':y,'pass':ok});assert ok,(label,x,y)
for p,x in commons.items():
 y=o['common_cases'][p]
 for k,name in enumerate(['Hb','Vb','Hc','Vc']):check(p+'_'+name,x['roots'][k],y[name])
 for k in range(3):check(p+'_J'+str(k),x['J'][k],y['J'][k]);check(p+'_lower'+str(k),x['lower'][k],y['lower_cut'][k])
 for k,name in enumerate(['Ftop','Fbottom']):check(p+'_'+name,x['flanges'][k],y[name])
 check(p+'_Nweb',x['Nweb'],y['Nweb']);check(p+'_Qtop',x['panel'][0],y['Qtop']);check(p+'_Qbottom',x['panel'][1],y['Qbottom']);check(p+'_receiver',x['receiver_eta'],y['concurrent_receiver']['utilization']);assert max(map(abs,x['residual']))<1e-6
for name in ['u','Agv','Ant','resistance','demand']:check('fullU_'+name,bestU[name],o['block_governing'][name])
check('zeroU_u',zeroU['u'],o['zero_cap_shear_only_witness']['u']);check('zeroU_R',zeroU['zero_cap_R'],o['zero_cap_shear_only_witness']['conservative_zero_cap_resistance'])
for name in ['A','centroid','I','N','V','M','VM']:check('body_'+name,bestbody[name],o['body_governing'][name],abstol=.001,reltol=1e-6)
check('body_u',bestbody['u'],o['body_governing']['u'],abstol=.0001)
result={'result':'PASS','comparison_count':len(checks),'checks':checks,'body':bestbody,'maximum_body_tensile_stress':max(max(x['sigma']) for x in bodyrows),'full_U':bestU,'zero_cap_U':zeroU,'common_cases':commons,'input_sha256':hashlib.sha256((BASE/'FIXTURE_INPUT.json').read_bytes()).hexdigest(),'contract_sha256':hashlib.sha256((BASE/'BOLTED_COMPRESSION_CONTRACT.md').read_bytes()).hexdigest(),'oracle_sha256':hashlib.sha256((BASE/'ORACLE.json').read_bytes()).hexdigest(),'scope':'Independent numeric review, no production/candidate imports; body peak numerical, no interval certificate.'}
(R/'FINAL_NUMERIC_REVIEW.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['result','comparison_count','body','maximum_body_tensile_stress','full_U','zero_cap_U']},indent=2))
