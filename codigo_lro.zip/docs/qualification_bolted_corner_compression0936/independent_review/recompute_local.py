"""Independent qualification arithmetic, no production or parent-calculator imports."""
import json, math
from pathlib import Path
root=Path(__file__).resolve().parent
sq=math.sqrt(2);co=si=1/sq
E=200000.;fy=250.;fu=400.;ga1=1.1;ga2=1.35
C=100000.;n=4;db=16.;dh=dn=18.;tg=12.;ta=7.94
u0=385.;pitch=60.;us=[u0+j*pitch for j in range(n)]
ec=154.;eb=158.5
w=2*(us[-1]-us[0])*math.tan(math.pi/6);h=w/2
length=lambda v:max(0.,u0-max((eb-v*co)/si,(ec+v*si)/co))
vs=[-h,0.,h,eb*co-ec*si]
L=max(map(length,vs));r=tg/math.sqrt(12)
def red(slender):
    lam=slender/math.pi*math.sqrt(fy/E)
    chi=.658**lam**2 if lam<=1.5 else .877/lam**2
    return {'slenderness':slender,'lambda0':lam,'chi':chi}
res=red(L/r);res.update(Lmax=L,width=w,A=w*tg,R= res['chi']*w*tg*fy/ga1)
angle=red(pitch/15);angle.update(Ag=1148.,rmin=15.,pitch=pitch,AgR=angle['chi']*1148*fy/ga1,An=1148-dn*ta,net_yield_R=(1148-dn*ta)*fy/ga1,AL3_ratio=76.2/ta,AL3_limit=.45*math.sqrt(E/fy))
# For this 45-degree corner the inner clip x+y=ec+eb+30 gives constant u exit.
inward_exit=(ec+eb+30)/sq
bears=[]
for j,u in enumerate(us):
    glc=u-inward_exit-dh/2 if j==0 else pitch-dh
    # Last angle has documented clear continuation sufficient for 2.4dbtFu cap.
    alc=pitch-dh if j<n-1 else 42.
    bears.append({'bolt':j+1,'gusset_lc':glc,'gusset_R':min(1.2*glc*tg*fu,2.4*db*tg*fu)/ga2,'angle_lc_lower_bound':alc,'angle_R':min(1.2*alc*ta*fu,2.4*db*ta*fu)/ga2})
# No cap tensile resistance. Left/right tangent legs exit at same clip station.
# Every inward prefix conservative-included-hole maximum begins at u_j-r.
U=[]
for j,u in enumerate(us):
    cap=u-dn/2;Agv=2*(cap-inward_exit)*tg
    R=min(.6*fy*Agv,.6*fu*Agv)/ga2
    U.append({'cap':cap,'captured':j+1,'Agv':Agv,'Anv':Agv,'R':R,'D':C*(j+1)/n,'eta':C*(j+1)/n/R})
slip={'Ftb':91000.,'mu':.5,'Ce':1.,'ns':2,'R_each_bolt':.8*.5*91000*2,'D_each_bolt':.7*C/n};slip['eta']=slip['D_each_bolt']/slip['R_each_bolt']
out={'basis':'BC-C1 announced before numerical results: u385,445,505,565; local-only independent arithmetic','gusset':res,'angle_segment':angle,'bearing':bears,'slip':slip,'inward_clip_exit':inward_exit,'inward_tangent_U_shear_only':U,'root_projected_endpoint_ranges':{'beam_x':sorted([u0*co+h*si,u0*co-h*si]),'column_y':sorted([u0*si+h*co,u0*si-h*co])}}
(root/'INDEPENDENT_LOCAL_RECOMPUTE.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
