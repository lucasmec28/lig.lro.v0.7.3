# Bolted corner compression decision

GO for implementation and independent testing of one bounded local method. Existing supplied references are sufficient. No production changes or release packaging were made.

The admitted connection has two symmetric identical angles, one direct-contact through-bolt row, standard round drilled holes, two welded gusset roots and an explicitly supported ordinary corner detail. It uses pretensioned high-strength friction-type ends under the selected NBR 5.3.6.2 route, with Class A/B surfaces, required hardened washers, a separate service-slip check, and ordinary ultimate shear/bearing checks.

Essential limits are real beam, column and brace-end out-of-plane restraint; contained Whitmore stripe projected onto both effective roots; compact angle legs; short, actually restrained bolt intervals; and verified loaded-direction angle continuation. The first block model requires all inward L alternatives to retain support and uses a conservative zero-tension-cap U envelope to the actual free clip. Purely compressive sections do not receive tensile rupture checks.

The prospective BCC1 gusset has 503.329 kN compression resistance for a 100 kN demand. Its local attachment checks pass. Its unchanged concurrent column receiver fails at utilization 1.010115, which is preserved. This fixture is not a passing full-connection design.

The independent reviewer reproduced the local and signed common arithmetic. The negative minimum45 case needs a bolted-domain extension, while the existing complete-cut recomputation can be reused. Actual forces and cuts remain unchanged; synthetic minimum actions retain their own labels.

Read BOLTED_COMPRESSION_CONTRACT.md for the exact method, sources, geometry and input requirements; ORACLE.json for the computed witnesses; and independent_review/ for the independent decision and arithmetic. Global brace/member/frame stability, fabrication inspection and all excluded connection families remain outside this local result.
