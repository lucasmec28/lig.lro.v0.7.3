"""Bounded BCC1 engineering fixture. Standard library; no production imports.
Only this independent file writes the candidate oracle. Geometry and signed
common formulas are recomputed; no previous numeric oracle is imported.
"""
from pathlib import Path
import json, math, hashlib
import common_case
R=Path(__file__).resolve().parent
f=json.loads((R/'FIXTURE_INPUT.json').read_text());g=f['geometry'];m=f['materials'];cat=f['catalog'];a=cat['angle_each'];b=g['bolted_brace'];c=f['case']
P=c['P'];C=-P;t=g['gusset_t'];fy=m['gusset']['fy'];fu=m['gusset']['fu'];E=m['E'];ga=m['gamma_a1'];ga2=m['gamma_a2'];co=math.cos(math.radians(b['phi_deg']));si=math.sin(math.radians(b['phi_deg']));ec=g['ec'];eb=g['eb'];us=b['bolt_stations_u'];n=len(us);dh=b['physical_hole_diameter'];dn=dh if b['drilled'] else dh+2.;rad=dn/2;db=b['bolt_diameter']
for name,value in [('g',g),('m',m),('b',cat['beam']),('col',cat['column']),('c',c),('co',co),('si',si),('ec',ec),('eb',eb),('E',E),('ga',ga)]:setattr(common_case,name,value)
common={str(force):common_case.case(force) for force in [P,-20000.,-45000.,0.,45000.]}
F=common[str(P)]
xy=lambda u,v:[co*u-si*v,si*u+co*v]
uv=lambda p:[co*p[0]+si*p[1],-si*p[0]+co*p[1]]
poly=[uv(p) for p in g['gusset_polygon']];supports={'beam':[poly[0],poly[1]],'column':[poly[3],poly[4]]}
checks=[]
def row(id,D,Rd,**kw):
 z=dict(id=id,demand=D,resistance=Rd,utilization=D/Rd,pass_=D<=Rd*(1+1e-10),**kw);checks.append(z);return z

def reduction(area,radius,Le,fy0):
 slender=Le/radius;lam=slender*math.sqrt(fy0/E)/math.pi;chi=.658**(lam*lam) if lam<=1.5 else .877/lam**2
 return dict(A=area,r=radius,Le=Le,Le_over_r=slender,lambda0=lam,chi=chi,resistance=chi*area*fy0/ga)

def intersections(axis,z):
 values=[]
 for p,q in zip(poly,poly[1:]+poly[:1]):
  d=q[axis]-p[axis]
  if abs(d)<1e-11:
   if abs(z-p[axis])<1e-8:values.extend((p[1-axis],q[1-axis]))
  else:
   w=(z-p[axis])/d
   if -1e-9<=w<=1+1e-9:values.append(p[1-axis]+w*(q[1-axis]-p[1-axis]))
 return [min(values),max(values)] if values else None

def edge_id(u,v):
 point=xy(u,v);hits=[]
 for k,(p,q) in enumerate(zip(g['gusset_polygon'],g['gusset_polygon'][1:]+g['gusset_polygon'][:1])):
  if abs((point[0]-p[0])*(q[1]-p[1])-(point[1]-p[1])*(q[0]-p[0]))<1e-6 and all(min(p[j],q[j])-1e-8<=point[j]<=max(p[j],q[j])+1e-8 for j in [0,1]):hits.append(['beam_support','right_free','top_free','column_support','clip_free'][k])
 return next((h for h in hits if h.endswith('_free')),hits[0] if hits else 'unknown')

def support_hits(cap,vlo,vhi):
 result={}
 for key,(p,q) in supports.items():
  l,h=0.,1.
  for dp,dq in [(cap-p[0],cap-q[0]),(p[1]-vlo,q[1]-vlo),(vhi-p[1],vhi-q[1])]:
   if abs(dp)<1e-9:dp=0.
   if abs(dq)<1e-9:dq=0.
   if dp<0 and dq<0:h=-1.;break
   if (dp>=0)!=(dq>=0):
    z=dp/(dp-dq)
    if dp<0:l=max(l,z)
    else:h=min(h,z)
  length=max(0.,h-l)*math.dist(p,q)
  if length>1e-7:result[key]=length
 return result

# Bolts and hole walls. Slip and post-slip ultimate checks are independent;
# they are never added as parallel capacities.
Ab=math.pi*db**2/4
for j,u in enumerate(us):
 for plane in [1,2]:
  coeff=.56 if b['threads_excluded'][plane-1] else .45
  row(f'bolt{j+1}_shear_plane{plane}',C/(2*n),coeff*Ab*b['fub']/ga2,component='bolt_shear')
 row(f'bolt{j+1}_service_slip',.70*C/n,.80*b['mu']*1.*b['F_Tb_minimum']*2,component='slip',service_basis='NBR6.3.4.4 permitted 0.70 normal ULS',ns=2,mu=b['mu'],external_bolt_tension=0.)
 for part,lc,th,fy0,fu0,D in [('gusset',u-intersections(1,0)[0]-dh/2 if j==0 else u-us[j-1]-dh,t,fy,fu,C/n),('angle',us[j+1]-u-dh if j<n-1 else b['angle_clear_continuation_beyond_last_hole'],a['t'],m['angle']['fy'],m['angle']['fu'],C/(2*n))]:
  row(f'{part}_bearing{j+1}',D,min(1.2*lc*th*fu0,2.4*db*th*fu0)/ga2,component='bearing',lc=lc,force_direction='-u' if part=='gusset' else '+u')

# Local angle section and deliberately short directly restrained bolt intervals.
An=a['Ag']-dn*a['t'];pmax=max(y-x for x,y in zip(us,us[1:]));local=reduction(a['Ag'],a['rmin'],pmax,m['angle']['fy'])
row('each_angle_local_gross_compression',C/2,a['Ag']*m['angle']['fy']/ga,component='angle')
row('each_angle_net_compression_yield_supplement',C/2,An*m['angle']['fy']/ga,component='angle',An=An,no_Ct=True)
row('each_angle_local_segment_compression',C/2,local['resistance'],component='angle',**{k:v for k,v in local.items() if k!='resistance'})
local['AL3_ratio']=a['b']/a['t'];local['AL3_limit']=.45*math.sqrt(E/m['angle']['fy']);local['short_interval_domain']=pmax/a['rmin']<=25

# Single-row Whitmore section and full-width maximum along nominal support faces.
u0=us[0];h=(us[-1]-us[0])*math.tan(math.pi/6);width=2*h
length=lambda v:max(0.,u0-max((eb-v*co)/si,(ec+v*si)/co))
switch=eb*co-ec*si
stations=[-h,h]+([switch] if -h<=switch<=h else [])
L=max(length(v) for v in stations);plate=reduction(width*t,t/math.sqrt(12),L,fy)
plate.update(u0=u0,width=width,selected_v_range=[-h,h],face_switch=switch,length_stations=[{'v':v,'length':length(v)} for v in stations],l1=length(0),l2=length(-h),l3=length(h),three_line_average=sum(length(v) for v in [0,-h,h])/3,K=1.,projection_checks={})
for name,axis in [('beam',0),('column',1)]:
 coords=sorted(xy(u0,v)[axis] for v in [-h,h]);seam=sorted(p[axis] for p in g[name+'_seam'])
 plate['projection_checks'][name]=dict(stripe=coords,seam=seam,pass_=seam[0]<=coords[0] and coords[1]<=seam[1])
plate['contained']=intersections(0,u0)[0]<=-h and h<=intersections(0,u0)[1]
row('gusset_whitmore_compression_buckling',C,plate['resistance'],component='plate_compression')
row('gusset_whitmore_net_compression_yield_supplement',C,(width-dn)*t*fy/ga,component='plate_net_compression_yield')

# Reversed inward detached L and U candidates. The U cap is behind the moving
# inner free-clip block and therefore opens in tension under this mechanism.
def path(cap,side):
 chord=intersections(0,cap)
 if not chord:return None
 captured=[j+1 for j,z in enumerate(us) if z-rad<=cap+1e-8]
 excluded=[j+1 for j,z in enumerate(us) if z+rad<cap-1e-8]
 if not captured:return None
 hh=max([math.sqrt(max(0.,rad**2-(cap-z)**2)) for z in us if abs(cap-z)<=rad]+[0.]);ex=intersections(1,0)[0]
 if side in ['negative','positive']:
  vb=chord[0 if side=='negative' else 1];vlo,vhi=(-1e9,0.) if side=='negative' else (0.,1e9)
  hits=support_hits(cap,vlo,vhi);pts=[[ex,0],[cap,0],[cap,vb]]
  ded=sum(max(0.,min(cap,z+rad)-max(ex,z-rad)) for z in us)
  Agv=(cap-ex)*t;Anv=(cap-ex-ded)*t;Ant=(abs(vb)-hh)*t
 else:
  if chord[0]>-rad or chord[1]<rad:return None
  ex0=intersections(1,-rad)[0];ex1=intersections(1,rad)[0];pts=[[ex0,-rad],[cap,-rad],[cap,rad],[ex1,rad]]
  hits=support_hits(cap,-rad,rad);Agv=(2*cap-ex0-ex1)*t;Anv=Agv;Ant=(2*rad-2*hh)*t;vb=None
 z=dict(u=cap,side=side,active=not hits,path_uv=pts,support_hits=hits,captured_bolts=captured,excluded_crossed_bolts=excluded)
 if hits:z['reason']='retained_supported_contact';return z
 if vb is not None and edge_id(cap,vb).endswith('support'):z.update(active=False,reason='cap_on_supported_edge');return z
 Ry=(.6*fy*Agv+.5*fu*Ant)/ga2;Rr=(.6*fu*Anv+.5*fu*Ant)/ga2;D=C*len(captured)/n
 z.update(Agv=Agv,Anv=Anv,Ant=Ant,Ryield=Ry,Rrupture=Rr,resistance=min(Ry,Rr),demand=D,utilization=D/min(Ry,Rr),conservative_zero_cap_resistance=min(.6*fy*Agv,.6*fu*Anv)/ga2,demand_limits=[C*len(excluded)/n,D],free_exits=[edge_id(*pts[0]),edge_id(*pts[-1])])
 return z

events={z+k for z in us for k in [-rad,0.,rad]}|{p[0] for p in poly if us[0]-rad<=p[0]<=us[-1]+rad}
for p,q in supports.values():
 for v in [-rad,0.,rad]:
  if (p[1]-v)*(q[1]-v)<0:
   z=p[0]+(v-p[1])*(q[0]-p[0])/(q[1]-p[1])
   if us[0]-rad<=z<=us[-1]+rad:events.add(z)
base=sorted(events)
for lo,hi in zip(base,base[1:]):
 mid=(lo+hi)/2;j=next((j for j,z in enumerate(us) if abs(z-mid)<rad),None)
 if j is None:continue
 cl=intersections(0,lo);ch=intersections(0,hi)
 for side in [0,1]:
  slope=(abs(ch[side])-abs(cl[side]))/(hi-lo)
  for K in [-slope,-1.2*fy/fu-slope]:
   z=us[j]+rad*K/math.hypot(1.,K)
   if lo<z<hi:events.add(z)
 for K in [-1.2*fy/fu,-1.2]:
  z=us[j]+rad*K/math.hypot(1.,K)
  if lo<z<hi:events.add(z)
paths=[p for cap in sorted(events) for side in ['negative','positive','tangent_U'] if (p:=path(cap,side))]
active=[p for p in paths if p['active']];worst=max(active,key=lambda p:p['utilization'])
zero_cap=max(active,key=lambda p:p['demand']/p['conservative_zero_cap_resistance'])
row('gusset_inward_tangent_U_zero_cap',zero_cap['demand'],zero_cap['conservative_zero_cap_resistance'],component='gusset_block',witness=zero_cap,model='Selected conservative zero-cap branch; full-cap witness is diagnostic only')

# Independent actual gross/net body section resultants, including retained root
# tractions and both one-sided crossing-hole force limits; no tensile rupture row.
seams=[]
for label,Fx,Fy in [('beam',-F['Hb'],-F['Vb']),('column',-F['Hc'],-F['Vc'])]:
 ends=sorted(uv(p) for p in g[label+'_seam']);seams.append((label,ends,co*Fx+si*Fy,-si*Fx+co*Fy))
def section(u,inc,net):
 chord=intersections(0,u)
 if chord is None or chord[1]-chord[0]<1e-8:return None
 vl,vh=chord;hh=max([math.sqrt(max(0.,rad**2-(u-z)**2)) for z in us if abs(u-z)<=rad]+[0.]) if net else 0.
 A=t*(vh-vl-2*hh);vc=t*(vh**2-vl**2)/(2*A);Iz=t*((vh**3-vl**3)/3-2*hh**3/3)-A*vc**2
 N=V=M=0.;sources=[]
 for j,z in enumerate(us):
  keep=(z+rad>=u-1e-8) if inc and abs(z-u)<=rad+1e-8 else (z-rad>u+1e-8) if abs(z-u)<=rad+1e-8 else z>u
  if keep:N+=P/n;M+=vc*P/n;sources.append(f'bolt{j+1}')
 for name,(s,q),nn,tt in seams:
  if u>=q[0]:continue
  fraction=1. if u<=s[0] else (q[0]-u)/(q[0]-s[0]);start=s if u<=s[0] else [u,s[1]+(u-s[0])*(q[1]-s[1])/(q[0]-s[0])]
  uc=(start[0]+q[0])/2;vv=(start[1]+q[1])/2
  N+=fraction*nn;V+=fraction*tt;M+=fraction*((uc-u)*tt-(vv-vc)*nn);sources.append(name+'_root')
 sig=[N/A-M*(z-vc)/Iz for z in [vl,vh]];vm=max(math.hypot(z,math.sqrt(3)*1.5*V/A) for z in sig)
 return dict(u=u,include_cut_hole=inc,net=net,A=A,centroid=vc,I=Iz,N=N,V=V,M=M,sigma=sig,VM=vm,sources=sources)
body_events=sorted(events|{p[0] for p in poly if p[0]<=us[-1]+rad}|{p[0] for _,ends,_,_ in seams for p in ends if p[0]<=us[-1]+rad})
def maximize(fn,lo,hi):
 q=(math.sqrt(5)-1)/2
 for k in range(80):
  x=hi-q*(hi-lo);y=lo+q*(hi-lo)
  if fn(x)>fn(y):hi=y
  else:lo=x
 return (lo+hi)/2
body=[]
for inc in [False,True]:
 for net in [False,True]:
  for lo,hi in zip(body_events,body_events[1:]):
   grid=[lo+(hi-lo)*j/32 for j in range(33)];rows=[section(x,inc,net) for x in grid];body.extend(z for z in rows if z)
   vals=[z['VM'] if z else 0. for z in rows]
   for j in range(1,32):
    if vals[j]>=vals[j-1] and vals[j]>=vals[j+1] and (vals[j]>vals[j-1]+1e-10 or vals[j]>vals[j+1]+1e-10):body.append(section(maximize(lambda x:section(x,inc,net)['VM'],grid[j-1],grid[j+1]),inc,net))
worstbody=max(body,key=lambda p:p['VM']);row('gusset_actual_net_body_VM_yield_supplement',worstbody['VM'],fy/ga,component='body_sections',witness=worstbody)

# Geometry checks are conservative finite witnesses, not proof of real restraint.
def distance(point,p,q):
 dx=q[0]-p[0];dy=q[1]-p[1];w=max(0,min(1,((point[0]-p[0])*dx+(point[1]-p[1])*dy)/(dx*dx+dy*dy)));return math.hypot(point[0]-p[0]-w*dx,point[1]-p[1]-w*dy)
free_edges=[(idx,g['gusset_polygon'][idx],g['gusset_polygon'][(idx+1)%5]) for idx in [1,2,4]]
geometry_diagnostics={'bolt_grip':2*a['t']+t+b['washer_stack'],'washer_stack':b['washer_stack'],'hardened_washer_radius':b['hardened_washer']['outside_diameter']/2,'declared_tool_radius':b['tool_radius'],'free_edge_maximum':[{'edge':idx,'distance':min(distance(xy(u,0),p,q) for u in us),'limit':min(12*t,150.)} for idx,p,q in free_edges], 'angle_connected_interval': [us[0],us[-1]], 'first_bolt_to_free_tip':us[0]-b['angle_free_end_u'],'pitch_max':pmax,'pitch_detail_limit':min(24*min(t,a['t']),300.),'last_angle_clear_continuation':b['angle_clear_continuation_beyond_last_hole'],'last_angle_clear_for_saturated_bearing':2*db}
# Explicit legacy preflight: same BC1 at u370 fails the full-stripe root projection.
legacy_projection={name:{'stripe':sorted(xy(370.,v)[axis] for v in [-h,h]),'seam':sorted(p[axis] for p in g[name+'_seam'])} for name,axis in [('beam',0),('column',1)]}
service_cases={str(v):{'signed_local_brace_service_force':.70*v,'per_complete_bolt_demand':.70*abs(v)/n,'per_interface_demand':.70*abs(v)/(2*n),'normal_ultimate_basis_force':v,'basis':'NBR6.3.4.4 permitted shortcut only for identified normal ultimate combination; local slip force, not a newly analyzed service frame cut','case_provenance':'actual normal ULS' if v==P else 'synthetic minimum design safeguard; not actual rare-service combination'} for v in [P,-45000.]}
output=dict(service_cases=service_cases,status='CANDIDATE_METHOD_FIXTURE_NOT_PRODUCTION_RESULT',input_sha256=hashlib.sha256((R/'FIXTURE_INPUT.json').read_bytes()).hexdigest(),checks=checks,plate_compression=plate,local_angle=local,paths=paths,block_governing=worst,zero_cap_shear_only_witness=zero_cap,body_governing=worstbody,body_search='Exact geometric/hole events, 32 subinterval samples and bounded numerical extrema; no interval certificate.',common_cases=common,geometry_diagnostics=geometry_diagnostics,legacy_BC1_projection_failure=legacy_projection,missing_global_member_inputs='Intentionally excluded; no global brace stability or stitch compliance claimed.',engineering_status='Review pending')
(R/'ORACLE.json').write_text(json.dumps(output,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
print(json.dumps({'checks':len(checks),'failed':[z['id'] for z in checks if not z['pass_']],'plate':plate,'local_angle':local,'block':worst,'body':worstbody,'common':F,'geometry':geometry_diagnostics},indent=2))
