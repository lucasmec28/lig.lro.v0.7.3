# Validação 0.9.69 — emendas W: estado após entrada inválida

## Defeito e alcance
Nas UIs M004 e convencional, gerar Word e depois introduzir 1e308 kgf causava overflow na conversão para N. A serialização lançava ValueError antes de invalidar o cache: permaneciam resultado e Word anteriores em sessão. Trata-se de robustez contra entrada extrema/inválida; não foi identificada mudança de resistência para ações usuais.

## Correção
A validação/serialização atual é protegida. Falhando, remove-se o Word anterior, registra-se INVALID_INPUT sem verificações, bloqueiam-se downloads e apresenta-se orientação de correção. O último projeto aceito é mantido. Corrigir a entrada restaura o cálculo e a exportação, sem substituir o projeto por dados inválidos.

## Limites
Nenhum motor resistente, método, catálogo, desenho ou gerador Word foi alterado. Não é aprovação estrutural. A auditoria funcional não foi uma nova revisão normativa integral. Não houve nova implementação ou nova auditoria das famílias paralisadas pelo usuário. Não houve push, deploy ou operação no computador do usuário.

## Evidências
Consulte validation0969/SUMMARY.json para contagens finais e verificação do pacote. Testes AppTest exercitam controles e estado Streamlit; não constituem inspeção visual por navegador. NaN/infinito são verificados pela importação nativa, pois o transporte de AppTest normaliza tais valores quando fornecidos diretamente ao controle numérico. O fluxo real de edição usa números finitos extremos que transbordam na conversão. Projetos importados rejeitados mantêm o projeto e o Word aceitos, porque não substituem a entrada atual.

## Testes históricos de navegação
A bateria ampla registrou 380 aprovações e três falhas de expectativas antigas: os testes exigiam 25 famílias, enquanto a 0.9.68 já contém 26. As mesmas três falhas foram reproduzidas na fonte 0.9.68 preservada. Somente as contagens esperadas foram atualizadas; verificações de identidade, ordem e rotas foram mantidas. O reteste dos três casos passou. Esses ajustes não mudam o aplicativo.
