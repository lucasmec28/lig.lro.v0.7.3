# Auditoria focada das end plates — 0.9.63

16/10/2026. Cópia independente da 0.9.62; sem publicação remota ou mudança de equações.

## Matriz de achados antes das correções

| Área | Reprodução/achado | Tratamento |
|---|---|---|
| Desenho 4E | bp=1e308: motor retorna GEOMETRIA INVÁLIDA; interface cai em Singular matrix ao gerar figura. pfo=1e308: limites não finitos no Matplotlib. | Impedir desenho proporcional quando o motor identifica erro de dados/geometria. Mostrar indicação textual, sem geometria inventada. |
| Word SCI | Entradas V=700 kN e resultado antigo calculado com V=400 kN geravam situação ATENDE; cálculo real de 700 kN é NÃO ATENDE. | Recalcular na exportação a partir das entradas recebidas. Rejeitar memorial se não houver verificações válidas. |
| Valores não finitos | Conversão de ação finita extrema em kgf para N pode exceder representação. | Preservar último projeto e ocultar exportações até correção; JSON SCI estrito, sem NaN/Infinity. |
| Português/unidades SCI | Alguns valores de entrada no Word, desenho e tabela ainda tinham ponto decimal. | Vírgula decimal na apresentação; JSON continua numérico conforme padrão. |
| Defaults e famílias | Sete exemplos existentes mantêm seus estados; 4E, 4ES, 8ES e MRE1/2 são rotas distintas. | Nenhuma nova família ou escolha automática de método. |
| Compatibilidade CJP | 4ES/8ES carregam premissas de compatibilidade/acesso; MRE1/2 exige seus dados próprios. | Defaults preservados. UI/memorial distinguem premissas de cálculo de atestado de inspeção/execução. |
| Linhas adicionais | 4E/4ES: sem crédito resistente, descontando furos e sinalizando extrapolação. 8ES/MRE1/2: linhas físicas fixas do método. | Não atribuir resistência fictícia a todas as linhas nem suprimir a pendência. |
| Exportações | NBR/DG39 possui JSON, SVG e Word; SCI possui JSON, CSV e Word. | Ausência de CSV na rota antiga não foi tratada como defeito de cálculo nem duplicada em nova rota. |

## Pendências técnicas preservadas e fontes existentes

- Rotulada NBR de altura total com N/V: permanece escopo incompleto. Manual Gerdau, capítulo 4 LCHE pp.65–68 e §12.2.1 pp.355–359, fornece detalhe de referência; sua primeira linha a 75 mm não coincide com grupo centrado atual (92,5 mm no testemunho). Interação N/V e local de aplicação precisam acompanhar a geometria. ASI DG4 Fig.11 não valida diretamente solda nas duas mesas. Ver REFERENCIAS_E_PENDENCIAS_0958.md e PINNED_END_PLATE_AUDIT0911_METHOD.md.
- SCI P358 §4.7: cisalhamento vertical somente, alma de coluna contínua, materiais EN S275/S355 e M20 8.8 especificados. Não converte ASTM em EN nem fatores Eurocode em NBR. Ver SCI_ENDPLATE_0959.md e https://www.steelconstruction.info/images/a/a9/SCI_P358.pdf.
- 4E/4ES/8ES/MRE1/2: conservar os mecanismos DG39 específicos, braços, distribuição e condição de chapa/coluna espessas. Linhas adicionais não qualificadas, prying resistente, reforços de coluna, sismo e fadiga não foram introduzidos. Ver MOMENT_END_PLATE_AUDIT0912_METHOD.md, END_PLATE_4ES0922_METHOD.md, END_PLATE_8ES0924_METHOD.md, END_PLATE_MRE12_0941.md e INDEPENDENT_PLATE_STEELS0925_METHOD.md.
- Nervuras geométricas da 0.9.61 continuam sem crédito resistente e não substituem nervuras estruturais de 4ES/8ES. Nenhum aviso técnico foi removido para obter aprovação.

Testes de software não equivalem à aprovação estrutural, certificação de materiais ou inspeção de fabricação. Esta auditoria não requalifica a literatura nem encerra as pendências acima.
