# Validação focada de 0.9.30

Gate de fonte aprovado: 684 casos pytest distintos passaram, sem falha. Reruns sobrepostos não são somados. As contagens de assertivas do revisor independente ficam separadas dos casos pytest. Escopo: novos ramos completos 2L opostas soldadas e 1L/2L-T parafusadas, estados nativos, desenhos, Word, sinais/eixos e regressão de navegação.

O seletor tem 18 famílias: 16 anteriores preservadas e 2 novas. A nova família parafusada tem configurações 1L e 2L-T, sem contar cada configuração novamente como seletor. Todo resultado é local e limitado ao domínio explícito.

Aceitação numérica independente: `ENGINE_ACCEPTANCE0930.json`. Aceitação independente de interface e artefatos: `UI_ACCEPTANCE0930.json`. Contrato: `GUSSET_VARIANTS0930_METHOD.md`. Os 817 arquivos congelados de 0.9.29 foram verificados intactos; motores físicos preexistentes permanecem idênticos, com alteração isolada de identificação global de versão. `LEGACY_PARITY0930.json` documenta os pontos de apresentação alterados.

Não foi executada toda a suíte histórica. O antigo oráculo externo ausente de contato de parafusos continua explicitamente não recuperado. Fixtures novos têm fontes e revisão próprias. Sem upload, push, deploy, qualificação global do membro ou liberação de fabricação. A extração/smoke do pacote final é um gate separado; o manifesto de distribuição é renovado pelo empacotador.
