"""Portable current-source output replay, independent of cached saved outcomes.

Run: python replay_current_examples.py --source-root /path/to/source --out /path/to/evidence
Optional --ui exercises current Streamlit import, metrics, and Word paths.
No release building, uploading, publishing, or engineering changes are performed.
"""
from pathlib import Path
import argparse,hashlib,json,os,sys

parser=argparse.ArgumentParser()
parser.add_argument('--source-root',type=Path,required=True)
parser.add_argument('--out',type=Path,required=True)
parser.add_argument('--ui',action='store_true')
args=parser.parse_args()
source=args.source_root.resolve();out=args.out.resolve();out.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(source));os.environ.setdefault('MPLCONFIGDIR',str(out/'mpl'))
os.environ.setdefault('XDG_CACHE_HOME',str(out/'cache'))
os.environ['PYTHONDONTWRITEBYTECODE']='1'
from lro.models import VERSION
from lro.end_plate import EndPlate,presets,evaluate,input_digest,method_revision
from lro.end_plate_presentation import result_indices,summary_lines,ratio_text,CONTRACT_REVISION
from lro.end_plate_drawing import image_bytes
from lro.end_plate_report import create_report
from docx import Document
from io import BytesIO

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def body(doc):return '\n'.join(p.text for p in doc.paragraphs)+'\n'+'\n'.join(c.text for t in doc.tables for r in t.rows for c in r.cells)
chosen={}
for label,c in presets().items():
 name='pinned' if c.kind=='pinned' else c.variant.lower()
 if name not in chosen:chosen[name]=(label,c)
receipt={'version':VERSION,'presentation_contract':CONTRACT_REVISION,'source_root':str(source),'source_hashes':{str(p.relative_to(source)):sha(p) for p in sorted((source/'lro').glob('end_plate*.py'))},'cases':[],'limitations':'Current-output replay only. Does not certify fabrication, global stability, source physics or release packaging.'}
for name,(label,c) in chosen.items():
 folder=out/name;folder.mkdir(exist_ok=True)
 result=evaluate(c);snapshot=c.to_dict();indices=result_indices(result)
 native=folder/'project.json';native.write_text(json.dumps(snapshot,ensure_ascii=False,indent=2,allow_nan=False))
 assert EndPlate.from_dict(json.loads(native.read_text()))==c
 assert snapshot['verification']['result_indices']==indices
 files=[native]
 for fmt in ('png','svg'):
  path=folder/('drawing.'+fmt);path.write_bytes(image_bytes(c,fmt));files.append(path)
 assert 'Utilização resistente' in (folder/'drawing.svg').read_text()
 words={}
 for detailed in (False,True):
  path=folder/('detailed.docx' if detailed else 'compact.docx');path.write_bytes(create_report(c,result,detailed));files.append(path)
  doc=Document(path);text=body(doc)
  # Standard end plate identifies the version in its closing signature; MRE
  # identifies it in the footer. Both must bind to this current source.
  version_text=text+'\n'+'\n'.join(p.text for section in doc.sections for p in section.footer.paragraphs)
  assert VERSION in version_text
  assert all(line in text for line in summary_lines(result))
  words['detailed' if detailed else 'compact']={'summary_lines_present':True,'bytes':path.stat().st_size}
 item={'name':name,'preset':label,'version':VERSION,'input_sha256':input_digest(c),'method_revision':method_revision(c),'status':result.status,'indices':indices,'legacy_max_ratio':snapshot['verification']['max_ratio'],'word':words,'files':{str(p.relative_to(out)):sha(p) for p in files}}
 if args.ui:
  from streamlit.testing.v1 import AppTest
  app=AppTest.from_file(str(source/'app.py'),default_timeout=120)
  app.session_state['connection_family']='End plate · '+('rotulada' if c.kind=='pinned' else 'engastada')
  app.run();assert not app.exception
  app.get('file_uploader')[0].upload(native.name,native.read_bytes(),'application/json').run()
  next(b for b in app.button if b.label=='Abrir projeto de end plate').click().run();assert not app.exception
  displayed=next(m.value for m in app.metric if m.label=='Utilização resistente')
  # The UI may perform reversible kgf input conversions; compare its own fresh
  # saved inputs to its metric, never a cached verification or rounded value.
  current=EndPlate.from_dict(app.session_state['_end_plate_projects'][c.kind])
  current_result=evaluate(current)
  assert displayed==ratio_text(result_indices(current_result)['resistance']['max_ratio'])
  assert current.kind==c.kind and current.variant==c.variant
  assert not any(m.label=='Maior índice finito' for m in app.metric)
  ui_words=[]
  for detailed in (False,True):
   app.checkbox(key='ep_detailed').set_value(detailed).run()
   next(b for b in app.button if b.label=='Gerar memória Word').click().run();assert not app.exception
   text=body(Document(BytesIO(app.session_state['ep_report'][2])))
   assert all(line in text for line in summary_lines(evaluate(current)))
   ui_words.append({'detailed':detailed,'summary_lines_present':True})
  item['ui']={'metric_label':'Utilização resistente','metric_value':displayed,'recalculated':True,'word':ui_words,'family_count':len(app.selectbox(key='connection_family').options)}
 receipt['cases'].append(item)
 (out/'CURRENT_EXAMPLES_RECEIPT.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2))
 print(name+' PASS',flush=True)
receipt['passed']=True
(out/'CURRENT_EXAMPLES_RECEIPT.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2))
print('CURRENT_EXAMPLES_REPLAY_PASS',VERSION,flush=True)
