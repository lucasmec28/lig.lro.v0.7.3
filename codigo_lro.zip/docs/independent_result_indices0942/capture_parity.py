"""Run separately against each source; compares engines and all legacy native fields."""
from dataclasses import asdict,replace
import json
from pathlib import Path
import sys
from lro.end_plate import presets,evaluate
rows=[]
for label,c in presets().items():
 configs=[c]
 for N,V in [(0.,0.),(0.,45000.),(45000.,0.),(-45000.,0.),(2000.123456789,-11000.123456789),(-2000.123456789,11000.123456789)]:
  for sign in ([-1.,0.,1.] if c.kind=='moment' else [1.]):
   for factor in [.5,1.]:configs.append(replace(c,N=N,V=V,M=sign*c.M,tp=factor*c.tp))
 configs += [replace(c,gauge=50.),replace(c,norm_minimum=False)]
 for index,item in enumerate(configs):
  r=evaluate(item);native=item.to_dict()
  native['verification'].pop('result_indices',None)
  rows.append({'key':label+'/'+str(index),'native':native,'engine':asdict(r),
   'status':r.status,'governing':asdict(r.governing) if r.governing else None,
   'ratios':[(q.id,q.case,q.ratio,q.passed,q.outcome) for q in r.checks]})
Path(sys.argv[1]).write_text(json.dumps(rows,ensure_ascii=False,sort_keys=True,separators=(',',':')))
print(len(rows))
