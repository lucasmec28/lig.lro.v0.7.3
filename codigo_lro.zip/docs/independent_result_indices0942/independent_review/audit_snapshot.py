"""Independent read-only snapshot and engineering-AST preservation checks."""
from pathlib import Path
from dataclasses import asdict, replace
from copy import deepcopy
from math import isfinite
import ast, hashlib, json
from lro.end_plate import presets, evaluate, EndPlate, MomentEndPlateCheck, MomentEndPlateResult
from lro.end_plate_presentation import result_indices, summary_lines
ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
BASE=ROOT/'review0941/source0941'
NEW=ROOT/'result_indices0942/source0942'

def tree(path):
    t=ast.parse(path.read_text())
    t.body=[n for n in t.body if not isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) or n.name not in ('moment_snapshot','verification_snapshot')]
    return ast.dump(t,include_attributes=False)
assert tree(BASE/'lro/end_plate.py')==tree(NEW/'lro/end_plate.py')
changes=[]
for p in sorted(NEW.glob('lro/*.py')):
    q=BASE/p.relative_to(NEW)
    if not q.exists() or p.read_bytes()!=q.read_bytes():changes.append(p.relative_to(NEW).as_posix())
expected=['lro/end_plate.py','lro/end_plate_drawing.py','lro/end_plate_mre12_report.py','lro/end_plate_presentation.py','lro/end_plate_report.py','lro/end_plate_ui.py']
assert changes==expected,(changes,expected)
assert (BASE/'app.py').read_bytes()==(NEW/'app.py').read_bytes()
checks=[]
for label,c in presets().items():
    configs=[('preset',c),('signed',replace(c,N=-23456.789012345,V=-87654.321098765,M=-c.M)),('zero',replace(c,N=0,V=0,M=0)),('geometry',replace(c,gauge=50.)),('thin',replace(c,tp=.5*c.tp))]
    for tag,case in configs:
        r=evaluate(case); before=deepcopy(asdict(r)); indices=result_indices(r)
        for category,key in [('Resistência','resistance'),('Condição do método','method_conditions')]:
            eligible=[q for q in r.checks if q.category==category and all(isfinite(v) for v in (q.demand,q.resistance)) and q.resistance>0 and q.numerically_valid and q.applicable]
            expected_value=max((abs(q.demand)/q.resistance for q in eligible),default=None)
            assert indices[key]['max_ratio']==expected_value
            assert indices[key]['available_checks']==len(eligible)
            if eligible:
                q=max(eligible,key=lambda q:abs(q.demand)/q.resistance)
                assert (indices[key]['governing']['id'],indices[key]['governing']['case'])==(q.id,q.case)
        assert asdict(r)==before
        snapshot=case.to_dict()['verification']
        assert snapshot['result_indices']==indices
        if case.kind=='pinned':assert not snapshot['approved'] and not snapshot['complete_within_declared_scope']
        assert not any(k in indices for k in ('approved','passed','complete','status'))
        json.dumps(indices,ensure_ascii=False,allow_nan=False)
        checks.append({'case':label+'/'+tag,'status':r.status,'indices':indices,'summary':summary_lines(r)})
# Synthetic failure in the minimum case may be hidden by a finite envelope; the new view must preserve it.
good=MomentEndPlateCheck('ep_plate_yield','raw yielding',1.000000001,1.,'N','source','formula','','')
bad=replace(good,case='Mínimo de força',demand=float('inf'))
r=MomentEndPlateResult(checks=[good],actual=[good],minimum=[bad],case_records=[{'label':'Entrada','status':'calculated'},{'label':'Mínimo de força','status':'numerical_failure','reason':'failure witness'}])
s=result_indices(r)
assert s['resistance']['max_ratio']==1.000000001 and not good.passed
assert s['invalid_checks']==[{'id':'ep_plate_yield','case':'Mínimo de força'}]
assert s['unresolved_cases']==[{'label':'Mínimo de força','status':'numerical_failure','reason':'failure witness'}]
assert 'Utilização resistente: 1,00' in summary_lines(r)
assert any('Não atende' in t for t in summary_lines(r))
assert any('sem conclusão' in t for t in summary_lines(r))
# Snapshot import is untrusted; imported result claims must not authorize the connection.
c=next(iter(presets().values())); native=c.to_dict()
native['verification']['approved']=True
native['verification']['result_indices']['resistance']['max_ratio']=0.
assert EndPlate.from_dict(native)==c
assert not EndPlate.from_dict(native).to_dict()['verification']['approved']
report={'verdict':'PASS','scope':'Read-only presentation index contract, not global application qualification','engineering_ast_unchanged_except_two_snapshot_functions':True,'runtime_changed_files':changes,'independent_case_count':len(checks),'cases':checks,'minimum_case_numeric_failure_witness':s,'runtime_sha256':{p:hashlib.sha256((NEW/p).read_bytes()).hexdigest() for p in changes}}
(OUT/'INDEPENDENT_SNAPSHOT_RESULTS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in report.items() if k not in ('cases','minimum_case_numeric_failure_witness')},ensure_ascii=False,indent=2))
