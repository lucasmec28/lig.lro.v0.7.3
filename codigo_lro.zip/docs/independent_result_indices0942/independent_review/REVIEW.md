# Independent review: end-plate result presentation candidate

Verdict: GO for the narrow, presentation-only patch reviewed here. This is not a release approval, full-application qualification, or independent qualification of an engineering method.

Reviewed patch SHA-256: `2769903a9964d6f8fb7265f40596a2daae3df960d076be22b96f758c5ab29f1f`.
Baseline: `review0941/source0941`. Candidate: `result_indices0942/source0942`. Review completed 2026-10-13, approximately 12:02 UTC. Source was not modified by this reviewer.

## What was verified

- Exactly six runtime files differ: `end_plate.py`, `end_plate_drawing.py`, `end_plate_mre12_report.py`, new `end_plate_presentation.py`, `end_plate_report.py`, and `end_plate_ui.py`. `app.py` and the other runtime modules are unchanged. The complete patch also adds one contract document and changes three test files.
- An AST comparison of `end_plate.py`, excluding only the two snapshot functions, is identical to the baseline. Their reviewed diff only imports the presentation view and adds its `result_indices` field. No engine equations, loads, capacities, classification rules, tolerances, acceptance decisions, or method revisions changed.
- Independently reexecuted the supplied 225-case baseline/candidate regression capture in separate processes. Dataclass engine results, raw ratios/outcomes, governing rows, and all legacy native fields are byte-identical after removing only the new additive field. Both captures hash to `e3631b61ddc4714261438ac5c7d0b0d18f845ee1db336dc381b668d3db4a6f17`.
- A separately authored audit exercises 35 cases across all seven presets: baseline, signed actions, zero actions, geometric failure, and reduced thickness. It compares each new maximum with the eligible raw demand/resistance rows, verifies identity/case and exact precision, checks non-mutation, and confirms pinned incomplete-scope approval remains false.
- Additional synthetic witnesses verify that an invalid minimum-force case is still visible behind a finite envelope; missing/invalid values never fabricate a zero utilization; `1.000000001` remains a failure while displayed as `1,00`; and forged imported approval/index fields cannot alter recalculation.
- Final focused tests: **149 passed**, covering the new contract file and both changed historical presentation-test files. This includes Streamlit AppTest, high-precision inputs/reruns, JSON, stale Word invalidation, all variants, compact/detailed Word generation, and drawing assertions. Runtime hashes were unchanged across this final focused run.
- Applied the patch in dry-run and then to independent copies of the ten baseline/added files. Every resulting file is byte-identical to the final candidate.
- Reviewed the final contract document against the implementation. Native `verification.max_ratio` intentionally retains its legacy mixed basis; the new block explicitly labels that basis, exposes the resistant maximum separately, and introduces no approval field.

## Numeric witness

The default pinned V/traction example retains legacy maximum **0.9525**, governed by the rotation thickness condition `ep_rotation`. Its resistant maximum is **0.16091197042435612**, governed by the beam-web N/V interaction in the minimum-force case. UI/drawing/Word show **0,16** for resistance and **0,95** for method conditions. The four local scope gaps remain visible and native approval/completeness remain false.

## Visual review and defects closed

All seven preset drawing PNGs were inspected. The new resistance, method, geometry/detailing and scope labels are distinct; the old unqualified maximum label is absent; no new header overlap was observed.

Word review found three presentation defects in the initial renders: scientific exponents split mid-number in the new index column, orphan sign/thickness notes, and a narrow MRE unit column. These were reported and corrected. The v3 pinned render then exposed a blank page from the isolated break paragraph; v4 moves the break onto the following heading and removes it.

Final v4 reports: pinned compact 5 pages, 4E detailed 13, MRE compact 6, MRE detailed 9. All 33 pages passed automated checks for blank pages and text spans outside the page. Affected cover/table/pagination pages were visually reinspected, with scientific numbers and `kgf·m` intact. The separate one-page typography witness also visually preserves exponents -03, -10, -100, +100, -308 and +308 in both real table layouts. This review does not claim full visual inspection of every unchanged calculation paragraph or a real-browser UI qualification.

## Remaining boundary

At this review's completion, the implementation worker's full disjoint aggregate in `evidence/aggregate_final` is still running. Its final receipt must be read before making any aggregate or application-wide pass claim. The historical `tests/test_axial_double_angle.py` still depends on the absent original `next_connection_scope/bolt_bearing_oracle.json`; this unchanged dependency was not manufactured, skipped, or repaired by this patch. No release, deployment, distribution archive, or local-computer action is authorized by this GO.

## Evidence

- `final_focused_tests.log` / `.xml`: 149 final focused tests.
- `audit_snapshot.py`, `INDEPENDENT_SNAPSHOT_RESULTS.json`: separate 35-case audit and final runtime hashes.
- `baseline_parity.json`, `candidate_parity.json`: independent reruns of the 225-case parity capture.
- `INDEPENDENT_PATCH_APPLY.json`, `patch_dry_run.log`, `patch_apply.log`: exact ten-file patch replay.
- `WORD_RENDER_CHECKS.json`: final v4 PDF hashes/page counts and boundary checks.
- `../visual/word_*_v4/`: final reviewed render evidence; `../visual/scientific_columns_qa/`: typography witness.
