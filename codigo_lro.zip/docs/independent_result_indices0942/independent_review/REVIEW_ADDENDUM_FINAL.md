# Final scoped review addendum

Verdict: **GO for the presentation-only result-index candidate**, with the cosmetic limitation recorded below. This addendum applies to final patch SHA-256 `d48ca014ed42e028a096f35a1a165a6b6a7fba3baf0488e236af5600e49dc366`. It supersedes the prior patch-specific verdict for integration purposes; the prior review and receipts remain untouched as history. Completed 2026-10-13, approximately 12:32 UTC.

## Honest aggregate reconciliation

The earlier complete standalone run on patch `2769903a...` finished with **6006 passed, 3 failed, 0 errors, 0 skipped**, out of 6009 tests. The reviewer independently read the four JUnit files and verified these exact totals and failures:

1. Historical absent `next_connection_scope/bolt_bearing_oracle.json`, referenced by `test_axial_double_angle.py`.
2. A historical DG39 SVG assertion still looking for `1.38` instead of the new explicitly labeled Portuguese display `Utilização resistente: 1,38`.
3. A genuine Word qualifier-placement regression: the newly inserted summary had pushed the applicability disclaimer beyond the first eight paragraphs.

That standalone run remains a three-failure run. The follow-up focused runs do not relabel it. No second standalone full-tree aggregate was run by this reviewer. The final **COMBINED integration aggregate is the sole final full-tree authority** and remains outside this scoped GO.

## Follow-up changes reviewed

- The DG39 display test now checks the explicit new label, retains status and input binding checks, and adds the exact mechanism ID and a tight raw-ratio witness assertion. A separate direct baseline/candidate capture established identical full engine results for this case: `ep_beam_web_local_tension`, raw ratio **1.3821057275761033**, outcome **Não atende**, overall **NÃO ATENDE**. Both captures hash to `6937d598861c42431721db2b25f3666620c7024b398e326e62501436ac47d8a0`.
- Coverage and calculation disclaimers were moved immediately after status and before the new numerical summary. MRE coverage notes were moved similarly. `test_v074.py` is byte-for-byte unchanged from baseline. The disclaimer test was fixed by restoring the document behavior, not weakening the test.
- The additional W200 render showed an orphan page containing only actions and sign convention. The parent-authorized final layout adjustment preserves those two paragraphs literally and places them immediately after the Dimensions heading. The drawing is kept with its caption. No engineering values or decisions changed.
- Contract documentation now records the three explicit historical display-expectation changes and the unchanged qualifier-position test.

## Final independent evidence

- **183/183 focused tests passed on final v6 bytes**, across the new result-index contract tests and the four affected historical suites: moment audit, 8ES artifacts, DG39 artifacts and v074. Runtime hashes remained stable during the final run. The preceding 183-pass v5 run is preserved separately.
- The independent **35-case snapshot audit** passed again and confirmed unchanged engineering AST outside the two additive snapshot functions.
- Re-captured the final candidate's **225 legacy-output cases** and compared them with the independently captured immutable baseline. Outputs remain byte-identical, hash `e3631b61ddc4714261438ac5c7d0b0d18f845ee1db336dc381b668d3db4a6f17`.
- An independent five-case document check verifies every applicable coverage/calculation qualifier appears after status, before resistant utilization and within the first eight paragraphs. Cases include W200, W410, W410 with intermediate bolts, pinned and a thin-plate MRE case. Each remains unapproved.
- Final patch dry-run/application to independent baseline copies succeeded for all **11 files**, producing the exact final candidate bytes. No implementation source was edited by this reviewer.
- Eight v6 Word reports, **66 pages**, pass automated blank-page and page-boundary text checks. All paragraph text multisets and table values are identical to v5 after the layout move. Priority affected cover/Dimensions pages were visually inspected, confirming visible qualifiers, intact indices and elimination of the W200 action-only page. This is not a claim to visual inspection of every unchanged calculation paragraph.

## Residual limitation and scope

The final W200 report retains a sparse final page (page 9) containing only the development credit. It contains no engineering finding, hides no qualifier and loses no data. Per the parent direction, further cosmetic refinement is deferred and recorded rather than expanding the frozen patch again.

This GO covers the presentation/read-only native-index patch only. It neither qualifies new engineering methods nor closes the pinned scope gaps or absent historical oracle dependency. It grants no release, deployment, publishing or local-computer authority. Integration must preserve the final COMBINED receipt and separately review any Word changes made there.

## Evidence locations

- `followup/focused_tests_v6.log` and `.xml`: final 183-pass run.
- `followup/INDEPENDENT_SNAPSHOT_RESULTS.json`: final 35-case audit and runtime hashes.
- `followup/candidate_parity_final.json`: exact 225-case final parity capture.
- `followup/baseline_failure_witness.json` and `current_failure_witness.json`: DG39 failure witness.
- `followup/QUALIFIER_ORDER.json`: five-case disclaimer-position check.
- `followup/FINAL_PATCH_AND_LAYOUT.json`: final eleven-file replay and eight rendered report receipts.
- `followup/patch_dry_run_final.log`, `patch_apply_final.log`: final patch replay.
