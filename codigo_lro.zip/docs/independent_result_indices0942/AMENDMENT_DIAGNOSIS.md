# Diagnóstico do agregado e correção restrita

O agregado standalone executou os 6.009 casos previstos sobre a fonte congelada do patch 2769903a9964d6f8fb7265f40596a2daae3df960d076be22b96f758c5ab29f1f. Resultado preservado: 6.006 aprovados, três falhas, zero erros e zero testes pulados. Esse resultado não foi convertido em aprovação retrospectiva.

## Falhas e disposições

1. O oráculo externo next_connection_scope/bolt_bearing_oracle.json continua ausente. Não houve alteração do teste, substituição do oráculo, fabricação de referência ou dispensa da falha.
2. O teste SVG de DG39 ainda exigia o texto decimal 1.38. A testemunha bruta é idêntica na fonte 0941 e na candidata: ep_beam_web_local_tension = 1.3821057275761033, caso Entrada, resultado Não atende e status NÃO ATENDE. A expectativa agora exige Utilização resistente: 1,38 e acrescenta asserções explícitas do mecanismo e do valor bruto. Não mudou nenhuma tolerância ou resultado físico.
3. O teste v074 exigia ressalvas nos primeiros oito parágrafos do Word. A falha foi tratada como regressão de apresentação: as ressalvas voltaram para imediatamente após o status e antes dos índices. O teste v074 permanece byte a byte igual ao da baseline. A rota MRE também mantém sua nota de cobertura antes dos índices.

A inspeção dos renders identificou, ainda, duas linhas de ações/convenção isoladas após o croqui no W200. A alteração final de paginação move essas duas linhas literalmente para o início da seção de dimensões e mantém croqui/legenda juntos. Não há alteração de números, fórmulas, casos, identidade das entradas ou escopo de aprovação. Eventual página esparsa de crédito final é limitação cosmética registrada, sem novo ciclo amplo de layout.

## Evidência

- STANDALONE_AGGREGATE_BEFORE_AMENDMENT.json e evidence/aggregate_final: execução integral original e ledger exatos, com as três falhas.
- evidence/pre_final_amendment: patch, inventário e arquivos afetados anteriores ao seguimento.
- evidence/final_amendment_focus_v6.xml e .log: regressão focada dos oito arquivos afetados na fonte final.
- evidence/PARITY_AFTER_AMENDMENT.json: paridade exata em 225 configurações, sem mudança de resultado físico, status ou campo nativo anterior.
- visual/word_*_v6: renders finais para a correção das ressalvas/paginação.
- independent_review: revisão inicial histórica e addendum independente do patch final, com testemunho bruto, aplicação do patch e renders.

Por orientação do coordenador, não se repetiu outro agregado standalone de 6.009 testes após essa emenda. O agregado final combinado, a ser executado na fonte integrada, será a autoridade de validação integral antes de qualquer decisão de release. O GO deste trabalho é restrito ao patch de apresentação e permite sua integração; não é aprovação de publicação, fabricação ou estabilidade global.
