# Enrijecedor oposto — versão 0.7.2

## Revisão da distribuição — 09/10/2026

Os erros recebidos (`lro.double_cover_ui`, `lro.end_plate_ui` e `Issue.origin_label`) não se reproduziram na extração limpa do ZIP original: os arquivos e a propriedade estavam presentes. A distribuição revisada mantém esses módulos e acrescenta diagnóstico de instalação antes da abertura das telas, um verificador do pacote por manifesto e instruções de envio ao GitHub/Streamlit Cloud. O ZIP agora contém `app.py` diretamente na raiz. Foram acrescentados testes do aviso pendente, da exportação Word nesse estado e da detecção de arquivos ausentes/diferentes. As equações desta versão não foram modificadas nesta revisão de distribuição.

## Uso

Na família **Single plate**, selecione **Alma de viga — viga a 90°** e marque **Enrijecedor no lado oposto da single plate**, no detalhamento. Funciona com chapa retangular ou com complemento entre mesas. Ajuste espessura, largura, alívio de canto, filete e aço. A altura acompanha as faces internas das mesas do apoio. O alívio do enrijecedor é independente do alívio do complemento.

O enrijecedor é coplanar à single plate, do outro lado da alma da viga de apoio. O detalhe especifica dois filetes na alma e em cada mesa, interrompidos nos alívios. O material de adição é o mesmo selecionado para a ligação. Não se cria solda entre a viga apoiada e a viga de apoio.

Dimensões, materiais e soldas aparecem no desenho, na memória Word e no projeto JSON. A opção não existe para a ligação na mesa da coluna. Ao mudar para esse apoio, o aplicativo a desativa. Os parâmetros do enrijecedor são preservados ao ocultar seus campos. Projetos antigos continuam aceitos; quando não há alívio independente salvo, usa-se a cota de alívio do complemento que existia no arquivo.

## Alcance do cálculo

O enrijecedor é uma **opção de detalhamento, sem crédito de resistência**. As verificações existentes da single plate usam a alma original e não somam a espessura do enrijecedor à do apoio. Ativar a opção não elimina nem aprova a condição de punção. Não se presume outra viga chegando ao lado oposto.

Não se dimensionam a chapa do enrijecedor, suas soldas, sua estabilidade ou a redistribuição para as mesas. A nota correspondente aparece nas premissas finais, no app e no Word. São conferidas a consistência das dimensões, a faixa de produto do aço e o mínimo geométrico do filete; essas conferências não constituem dimensionamento do reforço.

Alívios menores que a concordância estimada e largura além da projeção das mesas geram avisos de interferência. Como nas demais opções, esses avisos permitem calcular e exportar quando os dados resistentes são válidos. Não há correção automática de contorno.

Não foi estabelecido, nas fontes consultadas, um procedimento aplicável e validado que quantifique a contribuição desse reforço para a punção no caso geral de cortante mais tração. Um eventual ganho depende do caminho de forças, das soldas, das mesas e da deformação do conjunto. Portanto, essa contribuição não foi incorporada às equações.

## Correção da alternativa de punção sob cortante puro

A conferência visual do **SCI P358 (2014), página 128, Check 10** identificou um erro de transcrição no termo rigoroso das versões anteriores. O produto correto é `ts·tp`, e não `ts²`:

`tp ≤ ts·tp·fu,s·hp² / (6·V·e·γa2)`

Para espessura positiva, equivale a:

`6·V·e·γa2 ≤ ts·fu,s·hp²`.

O termo à direita da primeira forma depende da espessura de chapa informada; não é uma espessura máxima independente. A transcrição foi corrigida no motor, na equação editável do Word e nos testes. A adaptação existente usa `γa2 = 1,35` da NBR; não se apresenta esse fator como o coeficiente original do Eurocódigo.

Permanece a alternativa conservadora `tp ≤ ts·fu,s/(fy,p·γa2)`. Para cortante puro, aceita-se uma das duas alternativas; sob tração simultânea, continua apenas a conservadora. Não se trata de uma verificação completa da flexão fora do plano da alma. A correção independe da opção de enrijecedor e não altera o caso do usuário com N > 0.

Conferência independente do limite: para ts = 5,8 mm, fu,s = 450 MPa, hp = 120 mm e e = 90 mm, o limite rigoroso é V = 51 555,56 N. Os testes avaliam pontos abaixo, sobre e acima desse valor, para duas espessuras de chapa; a fronteira rigorosa permanece a mesma.

## Referências consultadas

- SCI/BCSA. **Joints in Steel Construction: Simple Joints to Eurocode 3**, P358, 2014, p.128, Check 10. Fonte da condição contra punção, conferida no PDF original disponível no projeto.
- SCI, **AD 422**, 2018. Esclarece o coeficiente parcial original dessa condição: <https://www.newsteelconstruction.com/wp/ad-422-punching-shear-check-for-fin-plates-in-p358/>. Mantida explicitamente a adaptação brasileira preexistente.
- Quiksoft, **Quikjoint software notice**, item QJ R7.40-34: registra que tp aparece nos dois lados da expressão rigorosa do P358. Corroboração da leitura, sem adoção de fórmulas proprietárias: <https://quiksoft.co.uk/downloads/Quiksoft/Quikjoint/ReadMe.pdf>.
- SDS2, **Shear Connection / Stiffener opposite**: referência de organização do detalhe na face oposta da alma, não de resistência: <https://techsupport.sds2.com/main/Topics/sys_jshr.htm>.

## Exemplo entregue

`Teste_usuario_enrijecedor_oposto.json/.docx/.svg` usa o projeto recebido W150×13,0 em W250×22,3 e adiciona complemento e enrijecedor, ambos com largura ilustrativa de 45 mm. O enrijecedor usa A36, 5/16”, alívio de 20 mm e filete de 5 mm. Os esforços, a single plate, seus parafusos e a solda original não foram redimensionados. O resultado permanece **NÃO ATENDE**, com as mesmas 24 verificações do arquivo recebido. É um exemplo do recurso de detalhamento, não uma solução aprovada para fabricação.

Os JSON anteriores são preservados para reprodução. Recalcule-os e gere novas memórias no app atualizado; as memórias e desenhos estáticos antigos foram retirados deste pacote para evitar o uso de resultados desatualizados.
