# Current and historical output provenance

The current release is 0.9.40-4e-column-demand-dev. The selected current native inputs and full results are in examples/release0940. Their manifest identifies the exact corrected source and the related freshly generated rendered artifacts. Current 4E examples are regenerated after the column-web force-route correction; saved historical verification is not treated as current approval.

All older versioned example and review directories are preserved as historical evidence. In particular, examples/outer_gusset_end0939, w_inner_option0939 and internal_bolt_alert0939 originate from the internal, undelivered 0.9.39 checkpoint. Their old native inputs can be imported and recalculated, but those stored results and rendered outputs are not relabeled as 0.9.40. The 0.9.39 artifact dependency bridge remains valid only for its explicitly named old holds.

Component identifiers need not match the global release: current cap native schemas retain 0.9.39 component identities and the W conventional component retains 0.9.6-w-inner-option-dev. Their exact inherited mechanics are intentional. Application-version lines in current Word reports identify their actual generating source and are distinguished from the changed 4E physical demands.

The package's selected examples manifest binds actual native/result/rendered bytes. PNG, SVG, Word and any review PDF remain outside the APP source; compact native/result inputs and self-contained acceptance commitments stay in APP. No historical snapshot supplies fabrication, physical-restraint or global-system approval.
