# Ligação de canto no eixo forte · 0.9.32

Nova família independente: par simétrico de cantoneiras 2L-T soldado à chapa de nó de canto, apoiada por soldas na mesa da viga e na mesa do pilar. As mesas da viga são ligadas por CJP ao pilar; a alma usa dois filetes. Em cada nível de mesa há duas chapas horizontais de continuidade, uma de cada lado da alma. As dezoito rotas anteriores permanecem disponíveis, sem alterar seus motores físicos. Esta família não modifica a ligação de duas talas/nervura interna no eixo fraco.

## Método e ações

O método de forças escolhido é o UFM generalizado do AISC DG29, Apêndice A. Usa comprimentos e centroides reais das duas raízes, derivados do contorno e das margens das soldas. Não exige igualdade entre os parâmetros geométricos nem um ângulo único da diagonal. O ponto de trabalho inicial é a interseção dos eixos da viga e do pilar. Um deslocamento real da linha de força permanece nos dados e no desenho, mas exige distribuição excêntrica própria antes de obter atendimento.

Há uma única convenção de entrada: COMPLETE_CUTS. Fx positivo aponta para a direita; Fy positivo, para cima; M positivo é anti-horário. São ações externas concorrentes sobre o corpo livre isolado, nos cortes nomeados da viga D e do pilar superior U. A diagonal é informada por sua força total e inclinação a partir da horizontal. O corte inferior L é derivado por equilíbrio e pode ser comparado com o corte correspondente do Robot. Não se soma novamente a contribuição da diagonal a uma ação completa. A combinação e a origem precisam ser identificadas; a ausência de outras cargas entre cortes é uma declaração explícita, nunca consequência de um campo em branco.

Na ligação direta viga–pilar, V vai integralmente à alma; N é dividido pelas áreas retangulares físicas; M é resistido pelo binário das mesas. A área adicional de concordância do perfil não é inventada nessa partilha. Isso é uma distribuição estática admissível explícita, não uma solução de compatibilidade elástica nem um crédito de efeito de mísula da chapa de nó.

## Caminhos físicos

Cada cantoneira recebe P/2; sua divisão talão/ponta usa o centroide de catálogo. Os quatro filetes são distintos. A chapa comum e cada caminho receptor não ganham capacidade duplicada pela existência de duas faces. Aços da cantoneira, chapa, viga, pilar e continuidade são independentes. Gerdau mantém a política de seleção com abas a partir de 63,5 mm por padrão; tamanhos menores continuam acessíveis. Raios não publicados permanecem desconhecidos, sem crédito de dispersão.

O contorno real recortado define as seções, as interseções de Whitmore e os caminhos livres de ruptura. Bordas de contato com viga/pilar continuam apoiadas mesmo além dos términos efetivos das soldas. A mudança de ângulo exige recalcular as interseções e as parcelas das trações de apoio efetivamente capturadas por cada seção. As fórmulas numéricas particulares de C1 não são constantes universais.

As duas raízes conservam suas demandas normal/cortante, seus materiais e seus comprimentos. A resistência de filete é não direcional, conforme a NBR; o acréscimo de demanda de 1,25 sobre a média provém do DG29 e é identificado como suplemento. São separadas a resistência da solda, o contato dos metais-base e os modos locais da mesa/alma receptora.

Regiões receptoras sobrepostas usam a união física com uma única dispersão 5k. Não se somam capacidades calculadas sobre a mesma alma. O cisalhamento local dos membros integra as trações das raízes e os esforços concorrentes dos cortes, além de verificar o painel do mesmo caso. A redução do painel por compressão axial do pilar permanece ativa.

## Continuidade e compressão real

A força completa de cada mesa é atribuída ao seu par de chapas de continuidade no caminho mesa carregada → chapas → alma. A solda da mesa oposta é presente no detalhe, mas não recebe força fictícia adicional na distribuição escolhida. Os recortes reduzem as larguras líquidas, e só as larguras realmente soldadas recebem crédito na área efetiva conectada.

A simetria do par não cancela a excentricidade de cada chapa. Derivam-se de suas dimensões os centroides do carregamento, da seção e da linha de solda à alma; a transferência inclui força axial, cortante transversal e momento. As seções fora do comprimento soldado e nos recortes são verificadas separadamente. Também são verificados os contatos recíprocos na alma comum do pilar, contada uma só vez, com o estado concorrente do nó.

A tração da diagonal não impede compressão na mesa superior, na região receptora do pilar ou em uma borda da continuidade. Esses modos reais de compressão são verificados. Compressão da própria diagonal ou um trecho comprimido de gusset sem modelo qualificado gera resultado específico não verificado; não é transformada em força nula.

## Base independente e limites

A qualificação independente completa está em `qualification_corner0932/FULL_JOINT_CONTRACT.md`, incluindo seu §9 sobre parâmetros. `FIXTURE_INPUT.json` e `ORACLE.json` são evidências de teste, nunca dados de resistência carregados pelo motor. Há 86 linhas primitivas no oráculo original, 33 comparações independentes e oito caminhos físicos detalhados. Esses números não são contagem de campos nem de componentes exigidos do usuário. O resumo mostra o modo governante de cada componente; o detalhe mantém as equações e a origem dos esforços.

C1 usa viga W310×52, pilar W310×97(H), duas L76,2×7,94, chapa de nó de 12 mm e diagonal tracionada de 100 kN. Os cortes completos resultam em ação viga→pilar (+17,002229 kN; −25,992077 kN; +20 kN·m), mesa superior −60,168938 kN e inferior +71,496632 kN. A excentricidade individual de continuidade é 85 mm nesse exemplo; ela deve ser derivada novamente quando a geometria mudar.

Escopo: ligação plana estática, simétrica, sem fadiga/sismo, uma viga e uma diagonal, duas raízes contínuas, continuidade retangular recortada e ações concorrentes declaradas. Sem qualificação global dos membros/pórtico, aprovação de fabricação, execução ou inspeção de WPS. 1L, cantoneiras opostas e gusset de canto parafusado não são adaptadores qualificados por esta entrega. Alterações fora dos caminhos avaliados apresentam o componente e o motivo específicos, em vez de extrapolar o exemplo.

Estado efetivamente testado, hashes e ressalvas: `VALIDATION0932.json`. Aceitação de fonte e smoke do pacote extraído são etapas diferentes. Sem push, upload ou implantação nesta etapa.

## Limite gráfico das ações adicionais

As figuras físicas mostram a diagonal, as ações assinadas nos cortes D/U/L e a interface J derivada. Cargas adicionais explícitas do grupo avançado são incluídas no equilíbrio e nas tabelas de ações da interface/Word e no JSON de resultados, mas não recebem setas individuais na figura. A figura sozinha não substitui a tabela completa do caso concorrente.
