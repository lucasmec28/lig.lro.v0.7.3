# Independent 4ES core acceptance

2026-10-11. Result: GO for the tested core math/domain implementation. No implementation files were edited by this reviewer.

## Tested identity

- Engine: `review0922/source0922/lro/end_plate.py`
- Accepted SHA-256: `4c2fa393ba4ceef0f6e7abfff73e7ccff92031e52bf5506232806c094a0bc308`
- Hash was unchanged before/after the final run.
- Contract: `next_endplate_scope/FINAL_4ES_CJP_CONTRACT.md`, which supersedes the earlier fillet proposal.
- Command: `PYTHONDONTWRITEBYTECODE=1 python3 next_endplate_scope/independent_review/engine_acceptance/run_acceptance.py`
- Result: 87 passed, 0 failed. Full machine-readable results: `acceptance_results.json`.

## Independent evidence

The suite uses the earlier independent source vectors rather than the owner's tests or production-generated expected numbers.

- Nine Table 5-11 vectors: published exact source geometry, inch/mm scaling, final catalog fixture, individual and simultaneous pitch caps, strict `de<s` boundary one floating-point step below/at/above equality.
- Three integrated cap cases verify that physical lever arms and bolt coordinates remain uncapped while only the yield-line expression caps pitches.
- Twelve signed action combinations: both M signs, both V signs, positive/negative/zero N. Direct source arithmetic checks Ff/Fc, web yielding demand `max(Ff,Fc)`, compression crippling Fc, separate bolt/contact quantities and mirrored tension side. No fictitious 4E extension-shear rows are present.
- Independent failures of plate and column thick gates disable no-prying qualification. Source/stiffener guards cover thickness, length, receiver hierarchy, mixed steel, wrong weld/electrode, missing or false compatibility, unconfirmed clearance, erased runs, invalid landings, one-sided layout, extra rows, zero moment and axial-domain violation.
- Exact allowed stiffness boundaries remain admitted. A 20 mm landing is not falsely rejected as failing an exact one-inch requirement. A positive CJP connected run shorter than the fillet minimum is not falsely rejected by fillet rules.
- Final prescribed stock-stiffener fixture passes. Actual and minimum-force cases exist; every governing row remains an entire row from one case and takes the applicable maximum ratio. A required minimum-force case outside axial scope remains unresolved and prevents approval without erasing valid actual-case checks.
- Every one of the nine required explicit-4ES stiffener fields is tested missing on import. All now reject instead of manufacturing declarations or geometry.

## Defect found and closed

At earlier tested hash `cc287164cf454b5e5c4033e8ae2c61f83dca2f1437f3507167b30f0d4a9212db`, removing `connection.stiffener_compatible` from an exported 4ES preset caused `EndPlate.from_dict` to default the missing statement to True and yield approved status. This violated the explicit-declaration contract. It was reported directly to the owner and parent.

The owner added a guard restricted to explicit moment/4ES imports, rejecting any missing member of `STIFFENER_FIELDS`. The accepted hash above was rerun across all 87 checks, including clearance and all other missing route fields. The branch guard leaves legacy absent-variant -> 4E migration in place. The owner's broader exact 24 old-4E + 2 pinned parity run was reported separately; it is not counted as this reviewer's independent testing.

## Acceptance boundaries

This is core equation, force assignment, domain, qualification and envelope acceptance. It does not certify the live UI, exports, drawing/Word pixels, release packaging, or a real building connection. Those remain the parent's separate acceptance work. The supplied DG39 2023 edition limitation and declared static/continuous-unreinforced-column scope remain unchanged.

If the engine changes after the accepted hash, the owner must disclose the precise delta and rerun affected independent cases. A different hash is not covered merely by this receipt.
