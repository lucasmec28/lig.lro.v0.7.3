# Independent 4ES UI and output acceptance

ACCEPTED for the finite source contract after one visual correction. Awaiting the parent’s outer package for a small package smoke.

## Evidence

- Broad independent real Streamlit AppTest run: 5 workflow tests passed in 104.12 seconds. Source hashes were unchanged throughout. Actual file-uploader actions and registered JSON/SVG/Word bytes were used; media capture only observed storage.
- Drawing correction recheck: 2 affected workflow tests passed in 20.82 seconds, with stable final source hashes.
- Source and native artifact SHA-256 hashes: ACCEPTANCE_MANIFEST.json. Logs and JUnit: pytest.log/junit.xml and pytest_drawingfix.log/junit_drawingfix.xml. Individual project snapshots, live tables and export files are next to these receipts.

## Accepted behavior

1. Catalog preset loads W 410 x 46,1 and W 310 x 97,0 (H), Gr.50 beam/plate/stiffeners, tp=19.05, ts=9.525 and CJP.
2. 4ES to 4E and back preserves geometry, materials, fabrication fields and signed actions; conditional stiffener fields survive family navigation. A real input change hides stale Word.
3. Native JSON file uploads reject each of the nine missing stiffener fields atomically. Five malformed CJP/type cases are also rejected. The active project, current Word and JSON remain intact. Merely selecting another file does not open it.
4. Negative M/V/N fixture stays signed and export-consistent, with bottom tension identified. Actual and 45 kN minimum-force cases retain their separate actions and rows; M is not magnified by that minimum-force case.
5. Missing CJP or clearance declarations, mixed steel, excessive stiffener thickness, short stiffener, invalid clip, outside layout, exact de=s boundary and finite overload never appear green.
6. Unit-conversion overflow retains the visible numeric entry plus the last valid project/report and hides exports. Derived finite-input numerical failure retains the actual huge input, shows the numerical-failure status, and hides stale Word.
7. Every actual/minimum numerical row, row order and outcome is present in downloaded compact/detailed Word; all three UI tables agree with current results. No false 4E extension-yield/rupture rows occur.
8. Forged JSON verification is ignored. Public Word export reevaluates absent, unrelated and same-input tampered result objects. JSON/SVG/Word identities bind to the active current input.

## Visual acceptance

The first drawing review found the upper stiffener slope crossing the “CJP à chapa” text. The owner moved the callout into a clear lane, preserving its leader to the physical plate CJP run. Final drawing hash is 99e83618df76ab0932b78312a8cb18ef783696c3cce38e8f064154eda80977dc.

Final actual downloaded SVG and registered PNGs, including signed negative actions, show two external beam stiffeners, four physical CJP runs, open corner clips without invented weld on the clip, correct interface leaders and no fictitious column stiffeners or stiffener fillet leg. Labels are clear on the accepted fixture. Downloaded compact and detailed Word covers were rerendered and pixel-inspected after the fix. Selected material, equation, actual/minimum row and unqualified-result pages are readable without clipping or overlap.

UI and reports explicitly state finite same-steel/CJP scope, compatible E7018 process, ordinary/static service rather than seismic/cyclic qualification, no column reinforcement credit, and the unavailable November 2024 DG39 errata limitation.

## Limits

This is bounded source acceptance, not the engine’s independent 87-check qualification, a full application suite, browser/deployed-site verification, or fabrication approval. Selected Word pages suffice because the last correction changes only the figure on page 1; this review does not claim every page was independently pixel-reviewed. Existing kgf conversion introduces binary action roundoff (2000 becomes 2000.0000000000002 N); geometry and other stored fields remain exact. No package, upload or deployment was performed by this reviewer.
