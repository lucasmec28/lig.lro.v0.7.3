# Ligação axial 1L–chapa retangular · parafusada

Versão 0.9.21-axial-single-angle-dev. Componente local nominal de extremidade sob tração estática e combinações últimas normais. Unidades N, mm, MPa e N·mm; γa1=1,10 e γa2=1,35.

## Método e fronteira finitos

Uma cantoneira laminada de abas iguais encosta firmemente por uma aba em uma única face de uma chapa retangular real de largura constante. Uma linha longitudinal centrada de parafusos, exatamente um plano físico de corte. Sem enchimento, segunda cantoneira, segunda linha, abertura ou crédito de atrito.

A NBR 8800:2024/Errata 1:2025, 6.1.8.2, permite desprezar a excentricidade de extremidade de cantoneiras simples e duplas sob carregamento estático. A seção 6.5.2 remete à mesma disposição para elementos de ligação. Esta família adota expressamente essa idealização nominal local; não demonstra equilíbrio tridimensional de uma carga aplicada no centro de gravidade físico. Os dois deslocamentos físicos são omitidos, não cancelados por simetria.

O eixo nominal de entrada e saída é x, y=bch/2, z=0. O corte terminal perpendicular atravessa a largura integral real da chapa, depois da ponta da cantoneira e de toda a transferência. Nele N é transmitido na mesma linha nominal, M=V=0. Uma mudança do ponto de referência apenas transforma esse mesmo resultante por r×N; não desloca a carga para o CG físico. Raiz da chapa, soldas, apoio e estabilidade global não são verificados.

No exemplo: chapa y=0…100 e faces z=±6,25; cantoneira na face positiva, talão y=15, ponta livre conectada y=91, linha dos parafusos y=50. CG físico y=36,3 e z=27,55. Excentricidade em plano ec−g=−13,7 mm; pela espessura tp/2+ec=+27,55 mm; separação dos planos médios (tp+t)/2=9,425 mm. Todas são mostradas. ec=21,3 mm continua ativo no Ct de shear lag. Um modelo diferente com N=100 kN aplicado no CG físico produziria My=2,755 e Mz=1,370 kN·m sobre a origem nominal: esses valores diagnósticos não são combinados com a resistência nominal. Esse modelo físico acoplado está fora do domínio.

## Resistências e forças

A cantoneira recebe N integral, com Ag de uma cantoneira, não N/2. A chapa também recebe N integral. Cada parafuso possui um plano solicitado por N/n; ambas as verificações de contato usam N/n, respectivas espessuras e materiais. A pega é t+tp. Corte por plano: coeficiente 0,45 com rosca ou 0,56 sem rosca, respeitando o tipo de parafuso e redução de pega longa.

Cantoneira: escoamento bruto, ruptura líquida efetiva e Ct=1−ec/lc com piso permitido Ac/Ag=0,5 para abas iguais. Ag e ec são propriedades catalogadas editáveis, nunca substituídas por seção de canto vivo. Chapa: Ag=b·tp, An=(b−dn)·tp, Ct=1 segundo 5.2.5(a) corrigido. A chapa real constante não requer Whitmore nem vira chapa de emenda sujeita automaticamente a 0,85Ag ou à regra 6.3.8.

Blocos parciais de k=1…n: ponta livre da aba conectada e outra ponta real pelo trajeto desenvolvido g+bL−t; o talão não é borda livre. Cada bloco recebe kN/n. Na chapa, os dois blocos laterais são alternativas, cada uma recebe integralmente kN/n; resistências não são somadas. Cts=1 e resistência min(0,6fuAnv+fuAnt; 0,6fyAgv+fuAnt)/1,35. Não se acrescenta cisalhamento puro em um corte que não libera bloco sem ligamento de tração. Forças de contato na cantoneira +x e na chapa −x preservam as extremidades carregadas opostas.

Furos padrão, deduções líquidas de broca/punção, bordas, passos, acesso de ferramenta e geometria são verificados. Um erro de domínio/detalhamento não esconde uma falha resistente calculável. Overflow e dados não finitos têm estado numérico/inválido próprio, nunca aprovação.

## Exemplo, procedência e ações

L76×6,35, Ag=929 mm², ec=21,3 mm, A36. Souza PDF162 registra o par igual com Ag=1858 mm² e espessura 6,35 mm: a metade fornece a área individual. PDF160 confirma a cantoneira simples com Ag=9,29 cm² e Xg=Yg=2,13 cm, mas arredonda t para 6,3 mm; esse arredondamento não substitui a dimensão 6,35 mm explicitamente adotada. Raio de raiz 6 mm e envelope de ferramenta/ferragem de raio 18 mm mais folga 2 mm são hipóteses físicas editáveis, sujeitas a confirmação, sem alegação de dimensões de fornecedor. Comprimento do parafuso, arruelas e posição da rosca devem corresponder às entradas.

Chapa100×12,5 mm, 3M16 A325 fub830 MPa, furos18 mm broqueados; passo50, g35, bordas carregadas35. Parafusos x35/85/135, ponta da cantoneira170, corte200. A geometria é idêntica à do exemplo 2L; a carga inicial é100 kN.

Oráculo independente: cantoneira An814,7; Ct0,787; Ae641,1689 mm²; escoamento211,136364 kN e ruptura189,975970 kN. Chapa escoamento284,090909 e ruptura303,703704 kN (inalteradas em relação à mesma chapa 2L). Grupo de parafusos166,881402 kN; bloco completo da ponta conectada155,457407 kN governa. N100 kN: η0,643263. N200 kN com a mesma geometria: η1,286526, falha; também falham corte dos parafusos e ruptura líquida da cantoneira.

N real é conservado, inclusive zero; compressão é fora do domínio. O mínimo45 kN de6.1.5 é caso separado obrigatório quando aplicável, sem opção implementada de exceção. Desativá-lo não dá aprovação. A recomendação opcional50% de capacidade local de tração é um terceiro caso distinto; não implica estabilidade ou resistência global à compressão.

## Persistência e artefatos

Esquema nativo exclusivo axial_single_angle_bolted; importação integral e atômica, sem inferir/converter 2L. Exatamente um estado de rosca; campos extras, assimetria, plano adicional e carregamento no CG físico são rejeitados, não ignorados. Word/SVG/PNG reavaliam a entrada atual e ignoram resultados externos. Resumos físicos preservam todos os caminhos/casos primitivos e suas testemunhas. Desenhos são ilustrativos, proporcionais e locais, sem autorização de fabricação ou suporte. O Word usa páginas A4 para texto e tabelas e uma folha dedicada A3 em paisagem para o desenho, preservando a legibilidade das cotas; não é um relatório de paginação inteiramente A4.

## Fontes e limites da verificação

NBR páginas PDF93/116:6.1.8.2 e6.5.2, explicitamente inspecionadas; PDF62–64:5.2.4/5.2.5/Figura4; PDF105–107:contato, corte por plano e contato de furos; PDF112–114:Tabelas14/16 e detalhamento; PDF116–118:seções e blocos reais. Souza PDF118–119, Exemplo9.1, mostra uma sobreposição simples com um plano e N/n (não é exemplo de cantoneira simples nem oráculo de coeficientes modernos); PDF160/162:propriedades. O Exemplo9.2 é de duas cantoneiras e não foi rebatizado como 1L.

Validação focada da nova família, catálogo e 13 rotas reais; sem suíte integral, navegador, implantação ou nova qualificação das 12 famílias anteriores. A cópia fonte anterior permanece imutável.
