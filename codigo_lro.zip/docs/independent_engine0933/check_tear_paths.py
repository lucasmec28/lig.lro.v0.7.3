"""Frozen eight-path golden plus independent physical-boundary audit."""
import json,math,hashlib,sys
from pathlib import Path
from dataclasses import replace
p=Path(__file__).resolve().parent;src=p.parent/'source0933';sys.path.insert(0,str(src))
from lro.corner_gusset import analyze,CornerGusset
source=json.loads((p/'frozen_source_fixture/fixture/GUSSET_PATHS.json').read_text());rows=[];bad=[]
def compare(label,a,b):
 ok=math.isclose(a,b,rel_tol=1e-9,abs_tol=1e-6);r=dict(label=label,actual=a,expected=b,passed=ok);rows.append(r)
 if not ok:bad.append(r)
base=replace(CornerGusset(),topology='single_1L_welded',symmetric=False,single_angle_face='positive');c1=analyze(base);paths=c1['gusset_paths']['admissible']
for r in source['rupture_paths']:
 if r['u_cut_mm']>=870.-1e-9:continue
 ident=r['id'][2:].replace('-','_')
 exact=next(q for q in paths if q['id']==ident and abs(q['u']-r['u_cut_mm'])<1e-7)
 for a,b in [('Agv','Agv_mm2'),('Anv','Anv_mm2'),('Ant','Ant_mm2'),('Cts','Cts'),('demand','demand_N'),('resistance','R_N'),('utilization','utilization')]:compare(ident+'.'+a,exact[a],r[b])
 for i,(u,v) in enumerate(exact['path_uv']):
  compare(ident+'.path_x'+str(i),(u-v)/math.sqrt(2),r['path_xy_mm'][i][0]);compare(ident+'.path_y'+str(i),(u+v)/math.sqrt(2),r['path_xy_mm'][i][1])
# Independent endpoint classification and positive support contact intersection.
def support_overlap(block,a,b):
 # Polygon CCW or CW accepted: use signed area for half-plane orientation.
 orient=sum(x[0]*y[1]-x[1]*y[0] for x,y in zip(block,block[1:]+block[:1]));sign=1 if orient>0 else -1
 low,high=0.,1.
 for x,y in zip(block,block[1:]+block[:1]):
  def side(z):return sign*((y[0]-x[0])*(z[1]-x[1])-(y[1]-x[1])*(z[0]-x[0]))
  sa,sb=side(a),side(b)
  sa=0. if abs(sa)<1e-7 else sa;sb=0. if abs(sb)<1e-7 else sb
  if sa < -1e-7 and sb < -1e-7:return 0.
  if (sa<0)!=(sb<0):
   at=sa/(sa-sb)
   if sa<0:low=max(low,at)
   else:high=min(high,at)
 return max(0.,high-low)*math.dist(a,b)
summary=[]
for phi in [40.,45.,50.]:
 out=analyze(replace(base,phi_deg=phi));co=math.cos(math.radians(phi));si=math.sin(math.radians(phi));g=out['geometry'];poly=g['polygon'];right=max(v[0] for v in poly);top=max(v[1] for v in poly)
 def xy(uv):return [uv[0]*co-uv[1]*si,uv[0]*si+uv[1]*co]
 for row in out['gusset_paths']['admissible']:
  path=[xy(v) for v in row['path_uv']];block=[xy(v) for v in row['block_uv']]
  endvalid=all(abs(q[0]-right)<1e-6 or abs(q[1]-top)<1e-6 for q in (path[0],path[-1]))
  overlap=max(support_overlap(block,poly[0],poly[1]),support_overlap(block,poly[3],poly[4]))
  ok=endvalid and overlap<1e-6
  if not ok:bad.append(dict(phi=phi,id=row['id'],u=row['u'],endvalid=endvalid,support_overlap=overlap))
 summary.append(dict(phi=phi,admissible=len(out['gusset_paths']['admissible']),rejected_supported=len(out['gusset_paths']['rejected_supported'])))
record=dict(golden_comparisons=len(rows),failures=bad,rows=rows,geometry_cases=summary,runtime_sha256=hashlib.sha256((src/'lro/corner_gusset.py').read_bytes()).hexdigest())
(p/'TEAR_PATH_REVIEW.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:record[k] for k in ['golden_comparisons','failures','geometry_cases']},indent=2))
