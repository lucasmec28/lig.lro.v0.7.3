# Independent single-angle corner acceptance and portable replay

Decision: bounded GO for the declared static nominal planar 1L adapter. See ENGINE_ACCEPTANCE.json and ENGINE_ACCEPTANCE.md. This is numerical connection acceptance, not a fabricated-joint certificate, global-member approval, arbitrary spatial resistance or deployment authorization.

## Two separate audit environments

The frozen source expectation was independently authored with NumPy 2.3.5. The application comparison was performed with NumPy 2.5.3. These are deliberately separate contracts. Neither changes application dependencies, the historical 0.9.32 audit, nor any frozen expected value.

From an extracted APP, in the appropriate audit environment:

- Compare the shipped runtime: `python -B docs/independent_engine0933/replay.py --mode compare --output-dir /tmp/corner0933_compare`
- Exactly regenerate the independent source expectation: `python -B docs/independent_engine0933/replay.py --mode regenerate --output-dir /tmp/corner0933_source`

Use `requirements_compare.txt` for compare (NumPy 2.5.3), and `requirements_regenerate.txt` for regenerate (NumPy 2.3.5). Use separate empty output directories. Running from an unrelated current directory is supported; use an absolute script path. `--app-dir` is optional when the wrapper is installed at `APP/docs/independent_engine0933`.

A wrong or missing NumPy version yields exit code 2 and JSON `REPLAY_PREREQUISITE_NOT_MET` on stderr before any output directory or temporary staging is created. Frozen expectation SHA256 is `57c9c26bc0a577fb02450d2a690ea8c1396135c953ad3d967d6e33ad0019646e`. Exact generation writes a separate output copy and requires byte equality. Compare never regenerates expectations: it verifies packaged source hashes and final runtime dependency hashes, then compares mechanical fields with stated numerical tolerances. Schema fields, physical counts, issue IDs, severity/status and canonical legacy diagnostics are not discarded or relaxed. Full body source identity is allowed to reflect the actual two-versus-four physical brace tractions; integrated forces and aggregated line tractions are compared.

The comparison replay runs five independent scripts: the frozen nine-case/86-row runtime comparison, new 1L adversaries/native rejection, physical U/L tear paths real one-face/raw-moment geometry, and all five original corner2L native/result states. It does not rerun the large 19-route legacy snapshot or the complete application pytest suite. Those are retained as separate exact-hash acceptance receipts and must not be counted again as replay tests.

`PACKAGE_MANIFEST.json` lists every required audit file and exact hash. The implementation never reads these files as resistance logic. The original source provenance and frozen contracts explain the reused independent mechanics, the newly transcribed nine brace checks and narrow NBR6.1.8.2 idealization. No production engine was imported to generate expected values.

## Historical0.9.32 runner versus current0.9.33 replay

`docs/independent_engine0932/replay.py` is intentionally historical and bound to the accepted0.9.32 engine/dependency hashes. Its files remain immutable; it is not the current0.9.33 application replay entrypoint and will correctly reject a changed0.9.33 runtime hash even under its required NumPy2.5.3. Use the0933 wrapper above for this release.

The current comparison includes `replay_legacy_corner.py` and `FROZEN_CORNER_2L0932.json.gz`: five original0.9.32 corner native inputs and complete outputs captured before new implementation, preserving every diagnostic issue/state, geometry and check. They are reopened/evaluated under the current runtime and must be exactly equal after only the two known corner-version tags are normalized. No numeric tolerance or selective row omission applies to that whole-state legacy comparison. The compressed snapshot records its original full19-route/103-preset baseline hash. The other18 routes' exact accepted parity remains in LEGACY_PARITY.json; the current portable replay does not rerun those large snapshots.
