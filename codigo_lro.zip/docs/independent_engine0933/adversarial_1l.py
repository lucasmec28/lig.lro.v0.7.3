"""New 1L API, geometry, physical-load and schema adversaries. No production writes."""
from pathlib import Path
from dataclasses import fields,replace
import sys,json,math,copy,hashlib,datetime
HERE=Path(__file__).resolve().parent;SRC=HERE.parent/'source0933';sys.path.insert(0,str(SRC))
from lro.corner_gusset import CornerGusset,analyze,geometry
base=replace(CornerGusset(),topology='single_1L_welded',symmetric=False,single_angle_face='positive')
records=[];bad=[];outputs={}
def note(name,ok,**details):
 row=dict(name=name,passed=bool(ok),**details);records.append(row)
 if not ok:bad.append(row)
def run(name,edit,predicate=None):
 try:
  c=replace(base,**edit);o=analyze(c);json.dumps(o,allow_nan=False)
  ok=o.get('status') in ['PASS','FAIL','INVALID','UNVERIFIED'] and (predicate(o) if predicate else True)
  note(name,ok,status=o['status'],approved=o.get('approved'),complete=o.get('complete'),issues=[x['id'] for x in o.get('issues',[])],failed=[x['id'] for x in o.get('checks',[]) if x['status']=='FAIL'])
  outputs[name]=o;return o
 except Exception as e:note(name,False,error=repr(e));return None
def ck(o,k):return next(x for x in o['checks'] if x['id']==k)
def close(a,b):return type(a) in (int,float) and math.isclose(a,b,rel_tol=1e-9,abs_tol=1e-6)
c1=run('base_positive_1L',{},lambda o:o['approved'] and o['status']=='PASS')
neg=run('negative_face_1L',{'single_angle_face':'negative'},lambda o:o['approved'] and o['status']=='PASS')
# Deliberate round trips and no silent source mode changes.
raw=base.to_dict();rt=CornerGusset.from_dict(json.loads(json.dumps(raw)))
note('native_1L_round_trip',rt==base and rt.to_dict()==raw)
for f in fields(base):
 val=getattr(base,f.name)
 if type(val) in (int,float):
  for name,z in [('none',None),('nan',float('nan')),('inf',float('inf')),('bool',True),('string','1')]:run('1L_numeric_'+f.name+'_'+name,{f.name:z},lambda o:o['status']=='INVALID' and not o['approved'])
 elif type(val) is bool:run('1L_boolean_'+f.name,{f.name:1},lambda o:o['status']=='INVALID')
for face in [None,'',0,False,[],{},'both','POSITIVE','negative_face',float('nan')]:run('invalid_face_'+repr(face),{'single_angle_face':face},lambda o:o['status']=='INVALID' and not o['approved'])
for topology in ['','1L','single_angle','opposed_2L','single_1L_bolted',None,1]:run('invalid_mode_'+repr(topology),{'topology':topology},lambda o:not o['approved'] and o['status']!='PASS')
run('inconsistent_single_symmetric',{'symmetric':True},lambda o:not o['approved'])
run('inconsistent_pair_not_symmetric',{'topology':'symmetric_2L_T_welded','symmetric':False},lambda o:not o['approved'])
schema=[]
def reject(name,data):
 try:CornerGusset.from_dict(data);ok=False
 except (ValueError,TypeError):ok=True
 schema.append(dict(name=name,passed=ok))
 if not ok:bad.append(schema[-1])
for k in raw['connection']:
 x=copy.deepcopy(raw);del x['connection'][k];reject('missing_1L_'+k,x)
for k in raw:
 x=copy.deepcopy(raw);del x[k];reject('missing_envelope_'+k,x)
for k in ['angle_count','brace_weld_count','spacer','out_of_plane_force','fatigue','seismic','spatial_mode','neglect_spatial']:
 x=copy.deepcopy(raw);x['connection'][k]=True;reject('unrecognized_spatial_or_count_'+k,x)
for at,key,val in [('root','extra',1),('root','schema_version',True),('root','connection_type','welded_angle_gusset'),('root','component_version','0.9.32-corner-gusset-dev'),('units','force','kN'),('fixed_assumptions','angle_count',2)]:
 x=copy.deepcopy(raw);where=x if at=='root' else x[at];where[key]=val;reject('native_tamper_'+at+'_'+key,x)
for name,edit in [
 ('missing_other_loads',{'other_loads_excluded':False}),('offset100',{'workpoint_offset':100.}),('negative_brace',{'P':-100000.}),
 ('wrong_convention',{'load_convention':'INCREMENTAL'}),('no_CJP',{'matching_cjp':False}),('no_restraint',{'lateral_restraint':False}),
 ('mismatched_lower',{'compare_lower_cut':True,'lower_column_check_Fx':-40000.}),('cp_clips_intrude',{'continuity_clip':140.}),
 ('negative_clip',{'corner_clip':-1.}),('zero_gamma',{'gamma_a1':0.}),('zero_root_weld',{'root_weld_leg':0.}),
 ('outside_footprint',{'plate_width':300.}),('tiny_cp_weld',{'continuity_web_weld_leg':2.}),('huge_force',{'P':1e200}),
 ('huge_panel_compression',{'upper_column_cut_Fy':-1.4*12360.*345.}),('phi80_same_outline',{'phi_deg':80.}),
 ('missing_angle_section',{'angle_profile':'NOT_A_CATALOG_SECTION'}),('unknown_angle_material',{'angle_steel':'NOT_A_MATERIAL'}),
 ('undermatched_CJP',{'fw_joint':415.}),('cut_crosses_gusset',{'beam_cut_x':749.})]:run(name,edit,lambda o:not o['approved'] and o['status']!='PASS')
run('correct_lower_complete',{'compare_lower_cut':True},lambda o:o['status']=='PASS')
run('zero_brace_actual_frame',{'P':0.},lambda o:len(o['checks'])>0)
run('mixed_failure_and_unverified',{'workpoint_offset':100.,'continuity_web_weld_leg':1.},lambda o:not o['approved'] and not o['complete'])
for phi in [40.,50.]:run('shifted_compressed_'+str(phi),{'phi_deg':phi,'brace_weld_start':700.},lambda o:o['status']=='UNVERIFIED' and not o['complete'])
for member,pt in [('column',[0.,-1500.]),('column',[0.,1500.]),('beam',[1500.,0.]),('beam',[100.,0.])]:
 load=dict(label='outside',member=member,point=pt,Fx=5000.,Fy=-30000.,M=400000.)
 run('outside_cut_'+member+str(pt),{'other_loads_excluded':False,'other_loads':(load,)},lambda o:o['status']=='INVALID')
# A source-qualified single substrate uses one gusset depth rather than a ghost opposite face.
thin=run('thin_single_gusset',{'plate_t':6.,'root_weld_leg':3.})
if thin:
 r=ck(thin,'brace_heel_gusset_face_substrate_positive_face');expected=min(.6*250*220*min(5,6)/1.1,.6*400*220*min(5,6)/1.35)
 note('thin_single_gusset_full_oneface_contact',close(r['resistance'],expected),actual=r['resistance'],expected=expected)
# Material choices are current and independent; every altered numeric result is freshly calculated.
for part in ['angle','gusset','beam','column','continuity']:
 target='ASTM A572 Gr.50' if part in ['angle','gusset','continuity'] else 'ASTM A36'
 o=run('independent_material_'+part,{part+'_steel':target})
 if o:
  expected=1148.*(345. if part=='angle' else 250.)/1.1
  note('material_'+part+'_angle_gross',close(ck(o,'angle_single_gross')['resistance'],expected),expected=expected,actual=ck(o,'angle_single_gross')['resistance'])
  for component in ['angle_single_gross','beam_root_weld','column_root_weld']:
   if component=='angle_single_gross' and part=='angle':continue
   old=ck(c1,component);new=ck(o,component)
   note('material_'+part+'_unchanged_'+component,all(close(old[k],new[k]) for k in ['demand','resistance','utilization']))
# Source relation between load and ordinary end eccentricity, plus actual strength failure.
for P in [50000.,194088.8888888889,210000.,400000.]:
 o=run('load_'+str(P),{'P':P})
 if o:
  r=ck(o,'angle_single_nominal_through_leg_block');note('load_full_one_angle_'+str(P),close(r['demand'],P) and close(r['resistance'],.6*250*7.94*220/1.35))
  if P>194088.888888889:note('load_strength_failure_'+str(P),o['status']=='FAIL' and not o['approved'] and r['status']=='FAIL')
# Changed physical section: independent catalog numbers, no sharp-angle area substitution.
r34=run('catalog_R34',{'angle_profile':'GERDAU_EQUAL_ANGLE_P03_R34'})
if r34:
 note('R34_actual_area',close(ck(r34,'angle_single_gross')['resistance'],1350.*250/1.1))
 note('R34_actual_centroid',close(ck(r34,'brace_heel_weld_positive_face')['demand'],100000.*(1-25.2/88.9)))
# The full nominal planar force sum retains all brace load once. Complete beam cut input is not incremental.
if c1:
 f=c1['forces'];j=c1['joint_beam_to_column'];lo=c1['complete_cuts']['column_lower']
 note('fullN_common_roots',close(f['Hb']+f['Hc'],100000/math.sqrt(2)) and close(f['Vb']+f['Vc'],100000/math.sqrt(2)))
 note('complete_joint_no_brace_doublecount',close(j['Fx'],base.beam_cut_Fx+f['Hb']) and close(j['Fy'],base.beam_cut_Fy+f['Vb']) and close(j['M'],20e6))
 note('complete_lower_equilibrium',close(lo['Fx'],-base.beam_cut_Fx-base.upper_column_cut_Fx-f['H']) and close(lo['Fy'],-base.beam_cut_Fy-base.upper_column_cut_Fy-f['V']))
 note('real_top_compression_retained',c1['joint_distribution']['Ftop']<0 and 'column_top_compression_web_crippling' in [r['id'] for r in c1['checks']])
 note('perplate_eccentricity_not_waived',close(ck(c1,'continuity_bottom_web_weld')['utilization'],.25060789371344605) and ck(c1,'continuity_bottom_plate_equilibrated_NVM')['demand']>40.)
# Negative-face labels are actual face-specific; no positive-face brace row remains.
if neg:
 one={r['id']:r for r in c1['checks']};nr={r['id']:r for r in neg['checks']}
 note('negative_face_row_names',not any(k.startswith('brace_') and 'positive_face' in k for k in nr) and sum(k.startswith('brace_') and 'negative_face' in k for k in nr)==6)
 diffs=[]
 for k,r in one.items():
  n=nr.get(k.replace('positive_face','negative_face'))
  if n is None or any(r.get(f)!=n.get(f) for f in ['demand','resistance','utilization','status','diagnostic_only']):diffs.append(k)
 note('negative_face_nominal_strength_invariant',not diffs,differences=diffs)
result=dict(checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),observations=len(records),schema_rejections=len(schema),failures=bad,records=records,schema=schema,engine_sha256=hashlib.sha256((SRC/'lro/corner_gusset.py').read_bytes()).hexdigest())
(HERE/'ADVERSARIAL_1L.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n');(HERE/'ADVERSARIAL_OUTPUTS.json').write_text(json.dumps(outputs,indent=2,allow_nan=False)+'\n');print(json.dumps({k:result[k] for k in ['observations','schema_rejections','failures']},indent=2));sys.exit(bool(bad))
