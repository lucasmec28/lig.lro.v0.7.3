"""Independently transcribed actual1L geometry and nominal-axis separation checks."""
from pathlib import Path
from dataclasses import replace
import sys,json,math,hashlib
H=Path(__file__).resolve().parent;S=H.parent/'source0933';sys.path.insert(0,str(S))
from lro.corner_gusset import CornerGusset,analyze
rows=[];bad=[]
def check(case,name,a,b):
 ok=math.isclose(a,b,rel_tol=1e-10,abs_tol=1e-6) if type(a) in (int,float) and type(b) in (int,float) else a==b
 row=dict(case=case,quantity=name,actual=a,expected=b,passed=ok);rows.append(row)
 if not ok:bad.append(row)
expected=json.loads((H/'EXPECTED_PHYSICAL_SINGLE_FACE.json').read_text())
for i,e in enumerate(expected):
 c=replace(CornerGusset(),topology='single_1L_welded',symmetric=False,single_angle_face=e['face'],P=e['P'],plate_t=e['t'],root_weld_leg=3. if e['t']==6 else 6.,angle_profile='GERDAU_EQUAL_ANGLE_P03_R34' if e['b']==88.9 else 'GERDAU_EQUAL_ANGLE_P03_R30')
 o=analyze(c);g=o['geometry'];a=o['spatial_idealization'];case=str(i)+'_'+e['face']
 check(case,'one_actual_angle',g['brace_angle_count'],1);check(case,'two_actual_fillets',g['brace_weld_count'],2)
 check(case,'physical_line_count',len(g['brace_weld_lines']),2);check(case,'face_count',len(g['brace_connected_surface_z']),1)
 check(case,'z_face',g['brace_connected_surface_z'][0],e['z_face']);check(case,'z_centroid',g['brace_centroid_z'],e['z_centroid'])
 for j in [0,1]:check(case,'z_bound'+str(j),g['brace_angle_z_bounds'][j],e['z_bounds'][j])
 check(case,'nominal_axis',g['nominal_connection_axis_z'],0.);check(case,'raw_Mout',a['raw_Mout_Nmm'],e['raw_Mout'])
 for k in ['Mx','My']:check(case,'raw_'+k,a['raw_spatial_moment_Nmm'][k],e['raw_'+k])
 check(case,'no_spatial_cancellation',a['assumed_spatial_cancellation'],False);check(case,'no_exact3D_equilibrium',a['exact_3D_equilibrium_claimed'],False)
 check(case,'no_raw_moment_resistance',a['raw_moment_resistance_verified'],False);check(case,'only_planar_equilibrium',a['nominal_equilibrium_components'],['Fx','Fy','Mz'])
 check(case,'full_offset_recorded',a['neglected_ordinary_end_axis_offset_mm'],e['z_centroid'])
 check(case,'midplane_axis_declared',a['nominal_force_axis_v_z'][1],0.);check(case,'scope_static',all(x in a['scope'] for x in ['static','no fatigue','no spacer']),True)
 check(case,'source_declared','6.1.8.2' in a['source'],True)
 check(case,'raw_angle_part',abs(a['raw_moment_partition_Nmm']['angle_centroid_to_faying']),e['centroid_faying_Mout'])
 check(case,'raw_faying_part',abs(a['raw_moment_partition_Nmm']['faying_to_gusset_midplane']),e['faying_midplane_Mout'])
 check(case,'line_fraction_full_P',sum(x['force_fraction'] for x in g['brace_lines']),1.)
 check(case,'line_moment_inplane',sum(c.P*x['force_fraction']*x['v'] for x in g['brace_lines']),0.)
 check(case,'each_line_actual_face',all(x['z']==e['z_face'] for x in g['brace_lines']),True)
 for label in ['beam','column']:
  r=next(q for q in o['checks'] if q['id']==label+'_root_weld')
  # The accepted source double6mm roots retain fullN; same geometry ordinary-thickness case.
  check(case,label+'_root_two_sided_line_resistance',r['resistance'],2*c.root_weld_leg/math.sqrt(2)*.6*c.fw_root/c.gamma_w2)
 record={'cases':len(expected),'comparisons':len(rows),'failures':bad,'rows':rows,'engine_sha256':hashlib.sha256((S/'lro/corner_gusset.py').read_bytes()).hexdigest()}
(H/'PHYSICAL_1L_REVIEW.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:record[k] for k in ['cases','comparisons','failures']},indent=2));sys.exit(bool(bad))
