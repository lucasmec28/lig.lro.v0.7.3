"""Exact full-state parity of all previously existing routes and native corner2L inputs.
Only explicit app_version and the corner adapter's component_version are normalized.
No diagnostic status, issue, check, public property, geometry or material is removed.
"""
from pathlib import Path
from copy import deepcopy
import json,sys,hashlib,datetime
H=Path(__file__).resolve().parent;S=H.parent/'source0933';sys.path.insert(0,str(S))
from lro.corner_gusset import CornerGusset,analyze
old=json.loads((H/'LEGACY_COMPLETE0932.json').read_text());new=json.loads((H/'LEGACY_COMPLETE0933.json').read_text())
by={(r['module'],r['name']):r for r in new['cases']};fail=[];rows=[];natives=[]
def norm(x):
 if isinstance(x,dict):return {k:('NORMALIZED_CORNER_VERSION' if k=='component_version' and v in ('0.9.32-corner-gusset-dev','0.9.33-single-angle-corner-dev') else norm(v)) for k,v in x.items()}
 if isinstance(x,list):return [norm(v) for v in x]
 return x
for row in old['cases']:
 key=(row['module'],row['name']);other=by.get(key);same=other is not None and norm(row)==norm(other)
 record=dict(module=key[0],preset=key[1],identical_after_version_only_normalization=same);rows.append(record)
 if not same:fail.append(record)
 if key[0]=='corner_gusset':
  c=CornerGusset.from_dict(row['input']);o=analyze(c)
  native=dict(preset=key[1],old_payload_had_face='single_angle_face' in row['input']['connection'],new_native_has_face='single_angle_face' in c.to_dict()['connection'],unchanged_native=norm(c.to_dict())==norm(row['input']),unchanged_result=norm(o)==norm(row['output']))
  native['passed']=not native['old_payload_had_face'] and not native['new_native_has_face'] and native['unchanged_native'] and native['unchanged_result'];natives.append(native)
  if not native['passed']:fail.append(native)
result=dict(checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),routes=old['route_count'],route_names=old['routes'],old_presets=len(rows),current_presets=new['case_count'],new_presets=[dict(module=m,name=n) for m,n in sorted(set(by)-{(r['module'],r['name']) for r in old['cases']})],failures=fail,normalized_fields=['app_version (only application VERSION)','component_version (only old/new corner adapter tags)'],rows=rows,legacy_native_corner_round_trips=natives,engine_sha256=hashlib.sha256((S/'lro/corner_gusset.py').read_bytes()).hexdigest())
(H/'LEGACY_PARITY.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['routes','old_presets','current_presets','new_presets','failures']},indent=2));sys.exit(bool(fail))
