#!/usr/bin/env python3
"""Portable independent0933 audit. Two intentionally distinct dependency contracts.
compare: NumPy2.5.3; compare immutable expected values to the shipped runtime.
regenerate: NumPy2.3.5; independently regenerate exact frozen source expectations.
Neither mode changes the application, its evidence or frozen expectations.
"""
from pathlib import Path
import argparse,sys,json,hashlib,subprocess,tempfile,shutil,os
H=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--mode',choices=['compare','regenerate'],default='compare')
p.add_argument('--output-dir',required=True,type=Path)
p.add_argument('--app-dir',type=Path,help='Normally auto-detected from docs/independent_engine0933 or the development review directory')
a=p.parse_args();required='2.5.3' if a.mode=='compare' else '2.3.5'
try:
 import numpy
 actual=numpy.__version__
except ImportError:actual=None
# This gate precedes creation of the output directory or temporary staging.
if actual!=required:
 print(json.dumps(dict(status='REPLAY_PREREQUISITE_NOT_MET',mode=a.mode,required_numpy=required,actual_numpy=actual,message='Use the dedicated audit requirements for this mode. No output directory, staging, expected regeneration or application changes were made.')),file=sys.stderr);sys.exit(2)
sha=lambda x:hashlib.sha256(x.read_bytes()).hexdigest()
try:
 manifest=json.loads((H/'PACKAGE_MANIFEST.json').read_text())
 for name,want in manifest['files'].items():
  if sha(H/name)!=want:raise ValueError('Packaged audit file hash mismatch: '+name)
 expected_hash='57c9c26bc0a577fb02450d2a690ea8c1396135c953ad3d967d6e33ad0019646e'
 if sha(H/'EXPECTED_PARAMETERIZED.json')!=expected_hash:raise ValueError('Frozen expected hash mismatch')
 output=a.output_dir.resolve()
 if output.exists() and any(output.iterdir()):raise ValueError('Choose an empty or nonexistent output directory; existing output is not overwritten.')
 if a.mode=='compare':
  candidates=[a.app_dir.resolve()] if a.app_dir else [H.parent/'source0933',H.parent.parent]
  app=next((q for q in candidates if (q/'lro/corner_gusset.py').is_file()),None)
  if app is None:raise ValueError('Cannot locate the APP runtime; supply --app-dir.')
  runtime_hashes=json.loads((H/'ENGINE_RUNTIME_HASHES.json').read_text())
  for name,want in runtime_hashes.items():
   if sha(app/name)!=want:raise ValueError('Runtime dependency hash mismatch: '+name)
 with tempfile.TemporaryDirectory(prefix='independent0933_replay_') as td:
  stage=Path(td);work=stage/'independent_engine_acceptance';work.mkdir()
  for name in manifest['staging_files']:
   dest=work/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(H/name,dest)
  env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
  receipts={}
  if a.mode=='regenerate':
   original=work/'EXPECTED_PARAMETERIZED.json';original.unlink()
   run=subprocess.run([sys.executable,'-B',str(work/'build_expected.py')],cwd=stage,env=env,capture_output=True,text=True,timeout=120)
   if run.returncode:raise RuntimeError(run.stderr or run.stdout)
   generated_hash=sha(original)
   if generated_hash!=expected_hash:raise ValueError('Exact independent source reproduction mismatch; frozen original is unchanged.')
   receipt=dict(passed=True,mode=a.mode,python=sys.version.split()[0],numpy=actual,exact_expected_sha256=expected_hash,regenerated_sha256=generated_hash,parameterized_cases=9,source_regeneration_only=True,runtime_executed=False,expected_original_unchanged=sha(H/'EXPECTED_PARAMETERIZED.json')==expected_hash)
   emitted=['EXPECTED_PARAMETERIZED.json']
   (work/'regenerate.stdout.log').write_text(run.stdout);emitted.append('regenerate.stdout.log')
  else:
   (stage/'source0933').symlink_to(app,target_is_directory=True)
   scripts=[('review_runtime.py','RUNTIME_COMPARISON.json'),('adversarial_1l.py','ADVERSARIAL_1L.json'),('check_tear_paths.py','TEAR_PATH_REVIEW.json'),('review_physical_1l.py','PHYSICAL_1L_REVIEW.json'),('replay_legacy_corner.py','REPLAY_LEGACY_CORNER_PARITY.json')]
   emitted=[]
   for script,report in scripts:
    run=subprocess.run([sys.executable,'-B',str(work/script)],cwd=stage,env=env,capture_output=True,text=True,timeout=120)
    if run.returncode:raise RuntimeError(script+' failed: '+run.stdout+'\n'+run.stderr)
    r=json.loads((work/report).read_text())
    if r['failures']:raise ValueError(script+' reported failures')
    receipts[report]=r;(work/(script+'.stdout.log')).write_text(run.stdout);emitted.extend([report,script+'.stdout.log'])
   for name,want in runtime_hashes.items():
    if sha(app/name)!=want:raise ValueError('Runtime changed during replay: '+name)
   receipt=dict(passed=True,mode=a.mode,python=sys.version.split()[0],numpy=actual,exact_expected_sha256=expected_hash,engine_sha256=runtime_hashes['lro/corner_gusset.py'],runtime_dependency_hashes=runtime_hashes,runtime_numeric_comparisons=receipts['RUNTIME_COMPARISON.json']['numerical_comparisons'],runtime_logical_observations=receipts['RUNTIME_COMPARISON.json']['logical_observations'],adversarial_observations=receipts['ADVERSARIAL_1L.json']['observations'],native_schema_rejections=receipts['ADVERSARIAL_1L.json']['schema_rejections'],tear_comparisons=receipts['TEAR_PATH_REVIEW.json']['golden_comparisons'],physical_single_face_comparisons=receipts['PHYSICAL_1L_REVIEW.json']['comparisons'],numeric_tolerance=receipts['RUNTIME_COMPARISON.json']['tolerance'],expectations_regenerated=False,expected_original_unchanged=sha(H/'EXPECTED_PARAMETERIZED.json')==expected_hash,global_or_fabrication_approval=False,legacy_corner_full_state_cases=receipts['REPLAY_LEGACY_CORNER_PARITY.json']['cases'],legacy_corner_full_state_parity_reexecuted=True,all19route_legacy_parity_reexecuted=False)
  # Check immutable package evidence again, then emit only successful results.
  for name,want in manifest['files'].items():
   if sha(H/name)!=want:raise ValueError('Packaged audit changed during replay: '+name)
  output.mkdir(parents=True,exist_ok=True)
  for name in emitted:shutil.copyfile(work/name,output/name)
  (output/'REPLAY_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
  print(json.dumps(receipt,indent=2))
except Exception as exc:
 print(json.dumps(dict(status='REPLAY_FAILED',mode=a.mode,error=str(exc))),file=sys.stderr);sys.exit(1)
