"""Independent complete-output snapshot of all pre-existing nineteen routes.
Run each source in a separate process; only version strings are normalized.
Includes all native presets and result/check derived public properties.
"""
from pathlib import Path
import sys,json,math,dataclasses,importlib,hashlib
source=Path(sys.argv[1]).resolve();sys.path.insert(0,str(source))
from lro.models import VERSION

def normalize(x):
 if isinstance(x,str):return x
 if x is None or type(x) in (int,bool):return x
 if isinstance(x,float):return x if math.isfinite(x) else {'nonfinite':repr(x)}
 if isinstance(x,dict):return {str(k):('NORMALIZED_APP_VERSION' if k=='app_version' and v==VERSION else normalize(v)) for k,v in x.items()}
 if isinstance(x,(list,tuple)):return [normalize(v) for v in x]
 if isinstance(x,set):return sorted(normalize(v) for v in x)
 if dataclasses.is_dataclass(x):
  d={f.name:normalize(getattr(x,f.name)) for f in dataclasses.fields(x)}
  props={k for cls in type(x).__mro__ for k,v in vars(cls).items() if isinstance(v,property)}
  for k in sorted(props):
   try:d['property:'+k]=normalize(getattr(x,k))
   except Exception as e:d['property:'+k]={'property_error':type(e).__name__+':'+str(e)}
  return d
 raise TypeError(type(x))
mods=['engine','double_cover','end_plate','base_plate','pinned_base_plate','w_splice','w_splice_conventional','double_angle','welded_double_angle','coped_double_angle','axial_double_angle','axial_single_angle','welded_w_splice','welded_angle_gusset','welded_double_angle_gusset','welded_opposed_angle_gusset','bolted_angle_gusset','bolted_opposed_angle_gusset','corner_gusset']
rows=[];routes=set()
for mod in mods:
 m=importlib.import_module('lro.'+mod);ps=importlib.import_module('lro.examples') if mod=='engine' else m
 for name,c in ps.presets().items():
  r=m.evaluate(c);route=mod
  if mod=='end_plate':route=mod+('_moment' if c.kind=='moment' else '_pinned')
  if mod=='bolted_opposed_angle_gusset':route='bolted_angle_gusset'
  routes.add(route)
  rows.append(dict(module=mod,route=route,name=name,input=normalize(c.to_dict()),output=normalize(r)))
result=dict(route_count=len(routes),routes=sorted(routes),case_count=len(rows),cases=rows)
text=json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n';Path(sys.argv[2]).write_text(text)
print(json.dumps({'source':str(source),'route_count':len(routes),'case_count':len(rows),'sha256':hashlib.sha256(text.encode()).hexdigest()}))
