"""Independent 0933 engine comparison against pre-runtime frozen source expectations.
No production imports in expectation generation. Comparisons target physical values;
polynomial candidate-list byte equality is not used across dependency versions.
"""
from pathlib import Path
from dataclasses import replace
import sys,json,math,hashlib,datetime
HERE=Path(__file__).resolve().parent;SRC=HERE.parent/'source0933';sys.path.insert(0,str(SRC))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
lock=json.loads((HERE/'EXPECTED_PRE_RUNTIME_LOCK.json').read_text())
for n,h in lock['files'].items():assert sha(HERE/n)==h,n
from lro.corner_gusset import CornerGusset,analyze
import numpy
prehash=sha(SRC/'lro/corner_gusset.py')
base=replace(CornerGusset(),topology='single_1L_welded',symmetric=False,single_angle_face='positive')
cases={
 'C1_1L':{},'phi40_1L':{'phi_deg':40.},'phi50_1L':{'phi_deg':50.},
 'phi40_shifted_compression':{'phi_deg':40.,'brace_weld_start':700.},
 'phi50_shifted_compression':{'phi_deg':50.,'brace_weld_start':700.},
 'angle_catalog_R34_1L':{'angle_profile':'GERDAU_EQUAL_ANGLE_P03_R34'},
 'column_material250_1L':{'column_steel':'ASTM A36'},
 'continuity_width120_clip30_1L':{'continuity_width':120.},
 'beam_cut_relocated_1L':{'beam_cut_x':1300.,'beam_cut_y':40.,'beam_cut_M':62300000.-300.*(-50000.)+40.*(-30710.67811865475)}}
expected=json.loads((HERE/'EXPECTED_PARAMETERIZED.json').read_text())['cases'];numeric=[];failures=[];summaries=[];outputs={};invariants=[]
def cmp(case,label,actual,expected,rel=1e-8,abs_=1e-5):
 passed=type(actual) in (float,int) and math.isfinite(actual) and math.isclose(actual,expected,rel_tol=rel,abs_tol=abs_)
 row=dict(case=case,quantity=label,actual=actual,expected=expected,passed=passed);numeric.append(row)
 if not passed:failures.append(row)
def record(label,passed,**data):
 r=dict(label=label,passed=bool(passed),**data);invariants.append(r)
 if not passed:failures.append(r)
def physical_equal(a,b,skip_source_ids=False):
 if type(a) in (int,float) and type(b) in (int,float):return math.isclose(a,b,rel_tol=1e-9,abs_tol=1e-5)
 if type(a)!=type(b):return False
 if isinstance(a,dict):
  ka=set(a)-({'sources'} if skip_source_ids else set());kb=set(b)-({'sources'} if skip_source_ids else set())
  return ka==kb and all(physical_equal(a[k],b[k],skip_source_ids) for k in ka)
 if isinstance(a,list):return len(a)==len(b) and all(physical_equal(x,y,skip_source_ids) for x,y in zip(a,b))
 return a==b
def aggregate_lineage(body):
 result={}
 for r in body['sources']:
  name=r['id'].removesuffix('_positive').removesuffix('_negative')
  if name not in result:result[name]=dict(Nu=0.,Vv=0.,ends=r['ends'])
  result[name]['Nu']+=r['Nu'];result[name]['Vv']+=r['Vv']
 return result
def row_compare(case,actual,expect):
 for k in ['demand','resistance','utilization']:cmp(case,expect['id']+'.'+k,actual[k],expect[k])
for case,edit in cases.items():
 c=replace(base,**edit);o=analyze(c);outputs[case]=o;e=expected[case];cks={r['id']:r for r in o['checks']}
 summaries.append(dict(case=case,status=o['status'],issues=o['issues'],checks=len(cks),failed_ids=[r['id'] for r in o['checks'] if r['status']=='FAIL']))
 if not o['forces']:
  failures.append(dict(case=case,missing='forces'));continue
 for k,v in e['forces'].items():cmp(case,'forces.'+k,o['forces'][k],v)
 for k,v in e['joint'].items():cmp(case,'joint.'+k,o['joint_beam_to_column'][k],v)
 for k in ['Fx','Fy','M']:cmp(case,'lower.'+k,o['complete_cuts']['column_lower'][k],e['lower_cut'][k])
 for k,s in [('A0','area_basis_rectangles'),('Af','Af'),('Aw','Aw'),('Nweb','Nweb'),('Ftop','Ftop'),('Fbottom','Fbottom'),('h0','h0')]:cmp(case,'components.'+k,o['joint_distribution'][s],e['beam_components'][k])
 for k,s in [('Qtop','Qtop'),('Qbottom','Qbottom'),('axial_reduction','factor')]:cmp(case,'panel.'+k,o['panel'][s],e['panel'][k])
 cmp(case,'panel.R',cks['column_panel_zone']['resistance'],e['panel']['R']);cmp(case,'panel.ratio',cks['column_panel_zone']['utilization'],e['panel']['ratio'])
 for k,s in [('gross_R','angle_single_gross'),('effective_R','angle_single_effective_rupture'),('nominal_block_R','angle_single_nominal_through_leg_block')]:cmp(case,'brace.'+k,cks[s]['resistance'],e['brace'][k])
 for k,s in [('gross_ratio','angle_single_gross'),('effective_ratio','angle_single_effective_rupture'),('nominal_block_ratio','angle_single_nominal_through_leg_block'),('heel_weld_ratio','brace_heel_weld_positive_face')]:cmp(case,'brace.'+k,cks[s]['utilization'],e['brace'][k])
 cmp(case,'brace.angle_demand',cks['angle_single_gross']['demand'],e['brace']['angle_demand'])
 for label in ['beam','column']:
  cmp(case,label+'.root_weld_ratio',cks[label+'_root_weld']['utilization'],e['root'][label]['weld_ratio']);cmp(case,label+'.receiver_yield_R',cks[label+'_receiving_web_local_yield']['resistance'],e['root'][label]['yield_R'])
 cmp(case,'gusset.body_VM',cks['gusset_actual_body_chord_gross']['demand'],e['geometry']['integrated_body']['peak_VM']['VM']);cmp(case,'gusset.body_min_normal',o['gusset_body']['minimum_normal'],e['geometry']['integrated_body']['min_sigma']);cmp(case,'gusset.whitmore',cks['gusset_whitmore_gross_peak_tension']['demand'],e['geometry']['whitmore_peak'])
 for label in ['top','bottom']:
  r=e['continuity']['rows'][label]
  for k,s,f in [('max_VM','plate_equilibrated_NVM','demand'),('web_weld_ratio','web_weld','utilization'),('flange_weld_ratio','loaded_flange_weld','utilization'),('receiver_VM','column_web_combined_receiver','demand'),('receiver_sigma_z','column_web_normal_rupture','demand'),('concurrent_triangle','concurrent_column_receiver_bound','demand')]:cmp(case,label+'.'+k,cks['continuity_'+label+'_'+s][f],r[k])
  plate=next(v for v in o['continuity_per_plate_traction'] if v['name']==label)
  cmp(case,label+'.sigma_min',plate['minimum_normal'],r['sigma_min']);cmp(case,label+'.sigma_max',plate['maximum_normal'],r['sigma_max'])
  for i,term in enumerate(r['Mpoly']):cmp(case,label+'.Mpoly'+str(i),plate['M_poly'][i],term)
 if 'column_top_flange_gusset_overlap_union' in cks:
  for a,b in [('demand','demand'),('resistance','R'),('utilization','ratio')]:cmp(case,'union.'+a,cks['column_top_flange_gusset_overlap_union'][a],e['flange_union'][b])
 should_compress='shifted_compression' in case
 record(case+'.compression_status',o['status']=='UNVERIFIED' and not o['approved'] and not o['complete'] if should_compress else o['status']=='PASS',actual=o['status'])
 # Same physical in-plane load, no forced status override. Compare the complete common rows.
 two=analyze(replace(c,topology='symmetric_2L_T_welded',symmetric=True));tcks={r['id']:r for r in two['checks']}
 unchanged=[k for k in cks if not(k.startswith('angle_single_') or k.startswith('brace_heel_') or k.startswith('brace_toe_'))]
 diffs=[dict(id=k,field=f,one=cks[k].get(f),two=tcks.get(k,{}).get(f)) for k in unchanged for f in ['demand','resistance','utilization','status','diagnostic_only'] if cks[k].get(f)!=tcks.get(k,{}).get(f)]
 record(case+'.all_common_rows_exact',not diffs,rows=len(unchanged),differences=diffs)
 record(case+'.diagnostic_status_preserved',o['status']==two['status'] and o['complete']==two['complete'] and physical_equal(o['issues'],two['issues']),one_status=o['status'],two_status=two['status'])
 for name in ['forces','joint_beam_to_column','complete_cuts','joint_distribution','continuity_per_plate_traction','panel','gusset_paths']:
  record(case+'.one_two_'+name,o[name]==two[name])
 record(case+'.one_two_body_physics',physical_equal(o['gusset_body'],two['gusset_body'],True))
 record(case+'.one_two_aggregated_lineage',physical_equal(aggregate_lineage(o['gusset_body']),aggregate_lineage(two['gusset_body'])))
 record(case+'.actual_lineage_counts',len(o['gusset_body']['sources'])==4 and len(two['gusset_body']['sources'])==6)
# Frozen C1 fixture has exactly 86 source checks, of which nine are the 1L adaptation.
golden=json.loads((HERE/'frozen_source_fixture/fixture/ORACLE.json').read_text());c1={r['id']:r for r in outputs['C1_1L']['checks']}
for row in golden['checks']:
 if row['id'] not in c1:failures.append(dict(case='C1_SOURCE_ALL86',missing=row['id']));continue
 row_compare('C1_SOURCE_ALL86',c1[row['id']],row)
changed=[x for x in golden['checks'] if x['id'].startswith(('angle_single_','brace_heel_','brace_toe_'))]
record('frozen_source_row_partition',len(golden['checks'])==86 and len(changed)==9,source_rows=len(golden['checks']),changed=len(changed),unchanged=len(golden['checks'])-len(changed))
oldc1={r['id']:r for r in analyze(CornerGusset())['checks']}
for row in changed:
 oldid=row['id'].replace('angle_single_','angle_each_').replace('_positive_face','_each_face');newrow=c1[row['id']];oldrow=oldc1[oldid]
 record('C1_nine_doubled.'+row['id'],all(math.isclose(newrow[k],oldrow[k]*(2. if k!='resistance' else 1.),rel_tol=1e-12,abs_tol=1e-8) for k in ['demand','resistance','utilization']))

# Direct fresh source formulas, independent of producer fixture builder and runtime.
c=base;P=c.P;b=76.2;t=7.94;Ag=1148.;ec=22.1;L=220.;s=5.;fh=1-ec/b;Ft=P*(1-fh);Fh=P*fh;Ct=max(.5,1-ec/L)
fresh={'angle_single_gross':(P,Ag*250/1.1),'angle_single_effective_rupture':(P,Ct*Ag*400/1.35),'angle_single_nominal_through_leg_block':(P,min(.6*250*t*L,.6*400*t*L)/1.35),'brace_heel_weld_positive_face':(Fh,L*s/math.sqrt(2)*.6*485/1.35),'brace_toe_weld_positive_face':(Ft,L*s/math.sqrt(2)*.6*485/1.35)}
for name,force in [('heel',Fh),('toe',Ft)]:
 for material in ['angle','gusset_face']:fresh[f'brace_{name}_{material}_substrate_positive_face']=(force,min(.6*250*L*5/1.1,.6*400*L*5/1.35))
for name,(demand,resistance) in fresh.items():
 for k,v in [('demand',demand),('resistance',resistance),('utilization',demand/resistance)]:cmp('FRESH_NINE_BRACE_ROWS',name+'.'+k,c1[name][k],v)
record('fresh_line_force_equilibrium',abs(Fh+Ft-P)<1e-8 and abs(-ec*Fh+(b-ec)*Ft)<1e-7)
for name,o in outputs.items():
 try:json.dumps(o,allow_nan=False)
 except ValueError as err:failures.append(dict(case=name,nonfinite=str(err)))
posthash=sha(SRC/'lro/corner_gusset.py')
result=dict(checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),python=sys.version,numpy=numpy.__version__,source_sha256_before=prehash,source_sha256_after=posthash,source_stable=prehash==posthash,numerical_comparisons=len(numeric),logical_observations=len(invariants),frozen_source_checks=86,changed_brace_rows=9,invariant_source_rows=77,parameterized_cases=len(cases),tolerance=dict(relative=1e-8,absolute=1e-5),failures=failures,summary=summaries,numeric=numeric,invariants=invariants)
(HERE/'RUNTIME_COMPARISON.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n');(HERE/'RUNTIME_OUTPUTS.json').write_text(json.dumps(outputs,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:result[k] for k in ['source_stable','numerical_comparisons','logical_observations','failures','summary']},indent=2));sys.exit(bool(failures) or prehash!=posthash)
