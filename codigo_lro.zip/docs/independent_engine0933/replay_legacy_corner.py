"""Current0933 runtime against immutable old0932 full native/results, not partial checks."""
from pathlib import Path
import sys,json,gzip,hashlib
H=Path(__file__).resolve().parent;S=H.parent/'source0933';sys.path.insert(0,str(S))
from lro.corner_gusset import CornerGusset,analyze
frozen=H/'FROZEN_CORNER_2L0932.json.gz';old=json.loads(gzip.decompress(frozen.read_bytes()));records=[];bad=[]
def norm(v):
 if isinstance(v,dict):return {k:('NORMALIZED_CORNER_VERSION' if k=='component_version' and x in ['0.9.32-corner-gusset-dev','0.9.33-single-angle-corner-dev'] else norm(x)) for k,x in v.items()}
 if isinstance(v,list):return [norm(x) for x in v]
 return v
for row in old['cases']:
 c=CornerGusset.from_dict(row['input']);actual=analyze(c)
 record=dict(preset=row['name'],input_face_required=False,native_unchanged=norm(c.to_dict())==norm(row['input']),full_result_unchanged=norm(actual)==norm(row['output']),old_status=row['output']['status'],current_status=actual['status'],old_issue_ids=[x['id'] for x in row['output']['issues']],current_issue_ids=[x['id'] for x in actual['issues']])
 record['passed']=record['native_unchanged'] and record['full_result_unchanged'] and 'single_angle_face' not in c.to_dict()['connection'];records.append(record)
 if not record['passed']:bad.append(record)
result=dict(passed=not bad,cases=len(records),failures=bad,rows=records,normalization='Only known corner component_version metadata; no diagnostic, geometry, numeric, issue or check state removed.',frozen_snapshot_sha256=hashlib.sha256(frozen.read_bytes()).hexdigest(),parent_baseline_sha256=old['parent_baseline_sha256'],engine_sha256=hashlib.sha256((S/'lro/corner_gusset.py').read_bytes()).hexdigest())
(H/'REPLAY_LEGACY_CORNER_PARITY.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));sys.exit(bool(bad))
