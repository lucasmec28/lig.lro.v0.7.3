# Source and calculation provenance

12 October 2026. Bounded engineering qualification only. No production imports, execution, edits, upload or deployment.

This work intentionally extends an already qualified family rather than re-deriving its unchanged full joint as if new. `fixture/build_fixture.py` is an explicitly identified adaptation of the accepted independent C1 `build_oracle.py`: angle demand changes from P/2 to P, face/count labels become single/positive, and the physical 1L/nominal-axis assumptions are added. Its independent angle/gusset/beam/column/continuity materials, complete-cut equilibrium, all receiver, weld, continuity and panel equations remain. It produces all 86 listed local/detail/material rows afresh. It is independent of production software, not claimed to be independently authored from the earlier qualification arithmetic.

`fixture/build_gusset_paths.py` reuses the previously independent real-boundary U/L construction, now with one face supplying the same total planar line tractions. It computes eight physical detached blocks, two support sections and the conservative partial-path envelope. Existing output JSON is not imported to create expected values.

`parameterized/build_expected.py` adapts the engine reviewer's separate independent mechanics source. It introduces angle_count to the actual angle demand only; it independently recomputes both 1L and 2L versions of nine changed-input witnesses. This source imports no producer/runtime module or previous output. The same complete geometry and loads produce identical full-plane response and doubled per-angle/weld demand. The two shifted 40/50-degree cases retain their real compressed gusset edges and are explicitly unverified. These are parameterized mechanics witnesses, not a claim that a 1L production route exists or has passed release acceptance.

`crosscheck/` is a newly authored crosscheck by a separate reviewer, with independently transcribed numeric inputs. Its source review inspects the original NBR page image. It imports neither production nor the adapted fixture builders.

The comparison/validator reads old independent JSON only after newly computed outputs exist, to verify the claimed transfer invariants. Old runtime output is never an expected oracle. Source hashes bind the original contracts, independent scripts, catalog and primary clause pixels. Production hashes are captured before and after; the independent release-document replay repair is outside this task and is not modified.

Primary basis:
- User-supplied ABNT NBR 8800:2024 corrected edition, physical PDF93/printed71, §6.1.8.1–2: ordinary static/no-fatigue single-angle end-axis eccentricity may be neglected. This is a permitted design idealization, not actual spatial cancellation. PDF116/printed94, §6.5.2, cross-refers to that end-eccentricity rule.
- Same source PDF61–64/printed39–42: angle gross/effective tension, e_c/L and lower bound; PDF97–103/printed75–81: fillet throat and detail; PDF117/printed95: local shear/block strength. No AISC resistance factor or directional weld bonus is imported.
- Gerdau user pocket catalog page3 row30: L76.2×76.2×7.94, Ag1148 mm², centroid22.1 mm. Page2 identifies nominal dimensions/tolerances. Rolled root/toe radii remain unknown. The accepted nominal-section qualification supplies the conservative through-leg model; this is not exact as-rolled microscopic tear-surface analysis.
- Same real W310×52 beam and W310×97(H) column are retained from the full-joint source register. Independent material selections remain mandatory. k=tf remains a lower-bound receiver strength input, never a fabricated rolled radius.
- DG29 AppendixA force method and the accepted full-joint/receiver/continuity/panel clause review remain unchanged because the nominal planar traction field is unchanged. Their source limits and guards transfer in full.

No new broad reference search is needed to change the ordinary angle-end adapter. This qualification is not a construction certificate, global member stability review, or arbitrary 3D/end-standoff approval.
