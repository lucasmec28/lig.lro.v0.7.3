# Independent single-angle corner source and numerical crosscheck

12 October 2026. **GO for the explicitly declared static tensile nominal planar 1L extension.** No source limitation found contradicts that narrow decision. This independently checks the changed angle attachment and the invariant planar load path; it is not an as-built certificate, an exact three-dimensional solution, or a new application-engine acceptance. No production module or production result was imported; no production edit, upload or deployment was made.

## Source scope and essential interpretation

The original NBR 8800:2024 supplied PDF, physical page 93 / printed page 71, §6.1.8.1–6.1.8.2, was inspected in its page image as well as text. The general terminal-group centering rule has an explicit exception for axially loaded simple/double angles and similar bars: ordinary mismatch between member axis and terminal connection axis may be neglected in static loading, but must be considered for fatigue. The wording is not limited to a gusset with one supported edge. It is a permitted static idealization, not evidence of actual through-thickness symmetry.

The accepted one-root 1L qualification explicitly retains this one-face nominal planar idealization, independently of shear lag and all real in-plane force-line transport. Changing the gusset from one supported edge to two does not itself change the angle-end exception. The original two-root full-joint contract and 0.9.32 engine acceptance nevertheless qualify T-2L only; the present 1L scope needs its own deliberate extension, rather than relabeling that old acceptance.

**The indispensable declaration is the adopted terminal connection axis at the gusset midplane z=0.** The positive-face 1L has gusset face z=+6 mm and catalog centroid z=+28.1 mm. The full ordinary one-sided angle-end axis offset is therefore 28.1 mm. At 100 kN its raw spatial moment has magnitude 2.81 kNm and components (−1.986970055,+1.986970055,0) kNm in the declared global axes. Its parts are 2.21 kNm from centroid to faying face and 0.60 kNm from face to gusset midplane. None is canceled by a nonexistent second angle. Applying only a 22.1 mm exemption while retaining force at z=6 would leave the 0.60 kNm residual and would not support unchanged spatial root actions.

The source does not itself prescribe a numerical gusset midplane projection. Adopting that connection axis is the transparent engineering implementation of the ordinary static angle-end exception, consistent with the accepted one-root 1L nominal route. This permits a **nominal planar equilibrium** claim under that idealization. It must never become an assertion of exact 3D equilibrium or a general waiver for an offset gusset, sideways flange attachment, independently specified spatial load/couple, or an unrelated remote joint eccentricity.

The exception also does not waive shear lag, nominal angle block/tear-out, either base metal, gusset physical fracture paths, weld throat/detailing, in-plane work-point offsets and root moments, compressed local components, concurrent beam/column actions, continuity transfer, panel shear, fatigue/seismic behavior, or member stability/fabrication requirements.

## Source and geometry records

- Primary NBR: `baseplate_references/Automação MC/NBR 8800-24-25-projeto-de-estruturas-de-aco-e-de-estruturas-mistas-20250710-000231_compress.pdf`; page evidence under `welded_gusset_scope/nbr/`. Relevant physical/printed pages: 61/39 tension; 62–64/40–42 shear lag and connected-area floor; 93/71 angle-end exception; 97/75 inscribed throat/effective length; 100/78 weld resistance; 102–103/80–81 min/max fillet and detailing; 117/95 shear and block resistance.
- Gerdau primary `gerdau_catalog_audit/Barras-e-Perfis-Tabela-de-bolso-Gerdau.pdf`, page 3; original page pixels inspected. P03R30 gives b76.2,t7.94,Ag1148,ec22.1 mm. Radius-of-gyration data are not corner radii; root/toe radii and toe flat remain unknown.
- Prior nominal acceptance: `gerdau_catalog_audit/qualification/GERDAU_NOMINAL_SECTION_CONTRACT.md` and `review0927/independent_catalog_review/REVIEW.md`.
- Prior one-root scope: `welded_gusset_scope/QUALIFIED_GEOMETRY.md`, `MOMENT_SOURCE_REVIEW.md`, and `review0927/source0927/docs/validation_welded_gusset0926/independent_engine/REVIEW_REPORT.md`.
- Two-root baseline: `corner_gusset_strong_axis_scope/full_joint_fixture/FULL_JOINT_CONTRACT.md`, `FIXTURE_INPUT.json` and `review0932/independent_engine_acceptance/ENGINE_ACCEPTANCE.md`. These supplied geometry/material/action contracts, not executable calculation imports.

One angle takes the whole 100 kN. Two longitudinal fillets, s5 mm, u650…870 mm, heel v−22.1 and toe v54.1. Angle free end u630. Nominal angle fy250/fu400; gusset12 mm fy250/fu400; fw485; gamma_a1=1.10 and gamma_a2=gamma_w2=1.35. These are design material assumptions, not material grades inferred from the catalog. No size/detail change is needed for this case: minimum fillet5, ordinary edge maximum7.94−1.5=6.44, L/s44, long-weld factor1, minimum effective length40 mm and overlap minimum39.7 mm. The specified inscribed throat is3.535533906 mm. Unknown rolled toe geometry is not falsely reconstructed.

## Independent angle and weld calculation

Using the actual catalog section, not sharp-corner area:

- Gross yielding: Rd260.909090909 kN; utilization0.383275261.
- Ct=max(1−22.1/220,0.5)=0.899545455; Ae1032.678181818 mm². Effective rupture Rd305.978720539 kN; utilization0.326820113.
- Nominal through-leg envelope Av=7.94×220=1746.8 mm²; At=0; full100 kN demand. Both §6.5.6 branches use gamma_a2: shear-yield branch194.088888889 kN; shear-rupture branch310.542222222 kN. Governing utilization0.515227845. This is the accepted nominal family envelope, not an exact microscopic curved-toe fracture prediction.
- Heel fraction0.709973753281 gives70.997375328 kN; toe fraction0.290026246719 gives29.002624672 kN. Their force sum is100 kN and their first moment about v0 is zero.
- Each weld Rd167.662874561 kN; heel/toe utilization0.423453168/0.172981793. No directional enhancement.
- Each line on each material has contact area220×min(5,t)=1100 mm². Yield/rupture resistances150.000000/195.555556 kN. Heel yield/rupture utilization0.473315836/0.363054760; toe0.193350831/0.148308876. The entire100 kN is not assigned to each line and no opposite-face contact capacity is credited.

These all pass. Compared with the original per-angle half-P detail, each remaining angle and line has doubled demand; corresponding capacities are unchanged. The governing changed-component utilization is0.515227845.

## Why the gusset and complete planar joint remain invariant

Old projected heel traction equals2×(P/2)×f_heel/L; new traction equalsP×f_heel/L, and likewise at the toe. The actual planar geometry, total line load at every station, and total first moment are identical. Consequently every unchanged planar section and physical detached block captures the same force, and the common gusset area is still counted once. This is a load-field identity, not an assumption that one angle carries only half the load.

Independent polygon intersections give Whitmore width330.234118443 mm and centroidv16 mm. The actual1.6 kNm section moment gives normal stresses17.898845813…32.570399295 MPa, yield utilization0.143309757. Whole-body chord at u650 is838.998013089 mm with centroidv3.181980515; peak10.158502167 MPa and supplemental gross/net rupture screen0.034284945. A direct derivative proof establishes the body maximum at u650 on650…870. Seven independently reconstructed representative U/L blocks close on actual right/top free edges and pass; their maximum ratio is0.086432281. They are crosschecks, not a claim to replace the accepted solver's eight-path enumeration. The full-P nominal ordinary partial-path envelope is293.333333333 kN, ratio0.340909091; its affine captured-load/length argument survives unchanged. Supported contact edges must not be reclassified as free edges.

Independently deriving the generalized planar root field gives, in kN: Hb47.712907411,Vb24.007923253,Hc22.997770708,Vc46.702754866. Both seam moments remain zero for this chosen force field. Double6 mm root-fillet utilizations remain0.066369000/0.064685969.

The complete cuts independently recover beam→column at J as(+17.002229292,−25.992076747,+20.000000) kN/kNm. Lower cut is(−50,+479.289321881,+37.7). Combined column actions about O are(+40,+20.710678119,+12.3). Beam, column and whole-assembly residuals are below1e−7 N/Nmm.

Actual flange forces remain top−60.168937777 and bottom+71.496631677 kN, with web axial share5.674535393 kN; web-weld vector resultant26.604292991 kN. Panel extremes remain27.171167069/21.496631677 kN. Top receiving compression, continuity mixed stress and the83.166708485 kN absolute overlap union remain active. No flange moment is transferred fictitiously through the gusset, no interface load is added twice, and no compressed local mode is removed because P is tensile. Since these forces, geometry, materials and restraints are unchanged, the already accepted corresponding local capacities remain invariant in this nominal planar extension.

## Reproduction and stopping boundary

Run `python single_angle_corner_scope/crosscheck/independent_check.py`. It uses only Python standard-library geometry/statics and independently transcribed inputs; results are `INDEPENDENT_RESULTS.json`. `run.log` contains the terminal calculation summary; `SHA256SUMS` binds these files.

This bounded pass supports the stated source-qualified 1L fixture and its unchanged planar joint mechanics. It does not retrospectively extend the0.9.32 runtime/UI acceptance, guarantee untested changed geometries, or qualify explicit spatial actions, fatigue/cyclic loading, global members or fabrication. There is no additional literature hunt or FEA prerequisite for the declared static nominal plane model.
