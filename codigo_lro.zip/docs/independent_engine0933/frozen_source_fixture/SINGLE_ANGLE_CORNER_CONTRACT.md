# Single-angle strong-axis corner gusset: bounded qualification contract

12 October 2026. **GO to implement and independently test a parameterized welded 1L adapter within the existing nominal planar static-strength corner family.** No production implementation, upload, deployment or release change is made by this qualification. The accepted 0.9.32 T-2L engine and its 134 runtime files remain immutable.

The missing-reference outcome does not apply to this stated nominal model: NBR 8800:2024 §6.1.8.2 explicitly permits the ordinary static/no-fatigue single-angle end-axis eccentricity idealization, and does not condition it on whether the gusset has one or two support roots. It does not qualify arbitrary 3D loads, spacers, an intentionally displaced joint plane, fatigue, seismic behavior or full brace compression. The decision is a source-qualified method extension, not certification of a fabricated joint.

## 1. Exact scope and real load introduction

One catalogued equal-leg rolled angle, one connected leg directly against one face of a constant-thickness gusset, two equal-length longitudinal heel/toe fillets. The gusset stays in the common rolled-W beam/column web plane; the beam end meets the column exterior flange in strong-axis topology. There is one brace and one beam, two full supported gusset edges, the same complete welded beam N/V/M path, actual continuity plates and panel checks. The existing receiver/end-distance/material/geometry guards remain mandatory.

C1-1L retains all dimensions and independent materials of the accepted C1-2L joint, but removes the negative-face angle and transfers **all P=100 kN** through the positive-face angle. No larger section or longer weld is needed:

- Gerdau P03R30 L76.2×76.2×7.94, catalog Ag1148 mm² and centroid e_a22.1 mm; angle fy250/fu400 MPa.
- Gusset12 mm, fy250/fu400; exact clipped600×600 polygon and effective550 mm beam/column root seams remain. Root seams each retain two6 mm fillets, one each side of the gusset.
- Angle free end u630; both effective longitudinal fillets u650…870 (L220), nominal inscribed leg5 mm and throat5/√2. Ordinary angle edge maximum7.94−1.5=6.44 mm and minimum5 mm are satisfied. No unknown toe/root radius or exact pre-weld toe flat is invented.
- u is the brace direction at45 degrees, v its in-plane transverse direction. Heel weld root v=−22.1 and toe v=+54.1 mm. The connected exterior leg face is z=+6 mm; the angle extends nominally to z=+82.2, with actual catalog centroid v=0,z=+28.1 mm. The standing leg is on the heel side. This is one physical angle, not half of a virtual pair.
- f_h=1−e_a/b=0.70997375328084 and f_t=e_a/b=0.29002624671916. Uniform longitudinal line forces are P f_h and P f_t. Their in-plane resultant is v=0 because f_h(−e_a)+f_t(b−e_a)=0. The projected force line passes through O=(0,0) exactly. Equal heel/toe demands are not assumed.
- Beam Gerdau W310×52 and column Gerdau W310×97(H), separately fy345/fu450; actual joint CJP and web fillets, paired12 mm continuity plates and their independent fy250/fu400 remain. E70 fw485 MPa, gamma_a1=1.10, gamma_a2=gamma_w2=1.35.

`fixture/FIXTURE_INPUT.json` is the full dimensioned input, including all named complete cuts. `fixture/FIXTURE.svg` depicts the elevation and real 1L section; rounded microscopic contours are intentionally not represented as measured geometry.

## 2. NBR idealization: exact permission and its limit

The actual one-sided physical geometry has a centroid-to-gusset-midplane offset28.1 mm. It comprises22.1 mm from angle centroid to the faying plane and6 mm from that plane to the gusset midplane. Thus the unidealized axial force has an out-of-plane moment magnitude2.81 kNm about the midplane (at45 degrees Mx=−1.986970055 kNm, My=+1.986970055 kNm). The corresponding subdivisions are2.21 and0.60 kNm. **They do not cancel.** There is no opposite-face brace to supply cancellation.

The clause does not prescribe a numerical midplane projection; that is the transparent engineering implementation of its ordinary end-axis exception. For this ordinary direct single-angle end connection, the selected nominal static model adopts the connection axis at the gusset midplane z=0 and neglects this ordinary bar/end-connection eccentricity. That scope includes the ordinary faying-surface-to-midplane part of the same direct end connection. The clause is an end-axis design simplification; it is not a statement that the actual centroid, weld plane and gusset midplane coincide. The existing qualified 1L route used this same nominal planar end idealization; changing the gusset from one supported edge to two does not introduce a new end-axis exemption.

If a calculation instead waives only22.1 mm and then applies P at z=6, the remaining0.60 kNm must be carried. Such a calculation is NOT the nominal midplane model qualified here and cannot claim a zero spatial residual. Likewise, the raw2.81 kNm is retained as geometry/idealization information, not used as a fictitious extra applied load in the nominal plane model and not claimed to have been resisted by uncalculated components.

All equilibrium residuals reported as closed here are the two in-plane forces and in-plane moment of the explicitly idealized model. Exact three-dimensional equilibrium/continuum stress is not claimed. A request for full spatial transfer, a supplied out-of-plane force/couple, actual spacer/stand-off, gusset displacement from the common web plane, intentional joint-plane offset or a nonordinary end assembly requires that specific spatial path to be qualified; none may be silently zeroed by this clause. No blanket FEA requirement is imposed.

The exception also does not waive:
- in-plane force-line offsets and their selected DG29 distribution;
- angle shear lag and nominal local tear/block resistance;
- either longitudinal fillet or either material substrate;
- actual Whitmore/body-section centroid moments, physical gusset tear paths or compressed regions;
- both root force paths, receiver interaction, complete concurrent joint actions, per-continuity-plate eccentricity or panel demand;
- global member/frame stability, WPS execution and inspection.

## 3. What changes from T-2L

There is one angle resistance, not two. Each angle limit state now receives P rather than P/2. Two physical longitudinal fillets replace four. Each remaining heel/toe fillet and its angle/gusset-face substrate receives twice the old per-face demand; no negative-face weld capacity is credited.

All updated C1 local values, kN unless stated:

| Check | Demand | Resistance | Utilization |
|---|---:|---:|---:|
| Single-angle gross yield |100.000000|260.909091|0.383275261|
| Single-angle effective rupture |100.000000|305.978721|0.326820113|
| Nominal through-leg block |100.000000|194.088889|0.515227845|
| Positive-face heel fillet |70.997375|167.662875|0.423453168|
| Positive-face toe fillet |29.002625|167.662875|0.172981793|
| Heel local substrate, angle separately |70.997375|150.000000|0.473315836|
| Heel local substrate, gusset separately |70.997375|150.000000|0.473315836|
| Toe local substrate, each material separately |29.002625|150.000000|0.193350831|

Ct=max(0.5,1−e_a/L)=0.899545455 remains. The source-qualified nominal angle through-leg envelope uses Av=7.94×220, At=0 and the minimum of both NBR6.5.6 branches divided by gamma_a2. No transverse tension credit, angle-count factor or rounded-contour claim is used. Each local substrate uses L min(s,t_material), separate fy/fu, and its actual line demand.

## 4. What transfers unchanged, and why

In the nominal plane, the old pair supplied two coincident projected heel tractions P f_h/(2L), summing to P f_h/L, and similarly at the toe. The new single angle supplies exactly those summed tractions. Therefore the complete planar loading of the **one shared gusset** is identical, not half and not double. Both supporting seams collectively transfer the same P once.

The following invariant results were regenerated from independent nonproduction calculations and compared:

- Beam seam Hb47.712907411,Vb24.007923253 kN; column seam Hc22.997770708,Vc46.702754866 kN. Selected brace-induced seam moments remain0. Both actual normal seam forces are tensile for C1.
- Complete beam cut D=(1000,0): Fx−30.710678119 kN,Fy−50 kN,M+62.3 kNm; upper column U=(0,1000): +10,−500,+10. Derived lower L=(0,−1000): −50,+479.289321881,+37.7. No other loads between cuts are assumed only because this fixture explicitly declares none.
- Recovered beam→column at J=(154,0): +17.002229292,−25.992076747,+20. This already includes the brace path. Adding it again fails equilibrium. Lower actions and panel demand are never manufactured from P alone.
- Joint Ftop−60.168937777 kN,Fbottom+71.496631677,Nweb+5.674535393. Actual top compression remains; nothing is waived because the brace is in tension. All20 kNm frame moment is carried by the specified beam flange couple, with none credited to the gusset.
- Root weld utilizations beam0.066369 and column0.064686; local receivers, web shear and common-gusset contact depth retain their previous single-capacity basis.
- Whitmore width330.234118 mm, actual center v16 mm, retained1.6 kNm moment, peak32.570399 MPa. Actual u650 body chord838.998013 mm retains0.318198052 kNm and10.158502 MPa peak. Neither is replaced by a zero-moment or fictitious directly edge-welded strip.
- Eight complete physical U/L gusset blocks remain: the same geometry, captured total loads and resistances. Maximum named utilization0.086765586. The conservative ordinary partial-path envelope remains0.340909091. Both real supported edges remain supported even beyond effective weld ends. A one-face weld does not create a second plate or turn a support into a free fracture edge. Microscopic through-thickness face peeling is not claimed to be explicitly solved; the stipulated nominal NBR connection-axis model and separate local substrate checks are the scope.
- Continuity plates keep each actual85 mm eccentric transfer and their transverse weld tractions. Bottom plate mixed-stress utilization0.185609090, bottom web-weld utilization0.250607894, common web local VM0.223117812 and conservative same-case receiver bound0.566579342 remain. This independent per-plate eccentricity is unrelated to and is not erased by the angle-end exception.
- Panel Qtop27.171167069,Qbottom21.496631677 kN, resistance573.804 kN, utilization0.047352697, with concurrent500 kN column compression and explicit axial factor. Root/gusset/continuity shared regions still receive only one thickness and one applicable spread contribution.

The full86-row C1-1L fixture passes. Nine changed brace/local-base rows double demand/utilization; the remaining77 rows retain their original demands/resistances. Physical tear/path results are separately verified. Passing-row count alone is not the qualification criterion.

## 5. Parameterized extension, not a fixed-size exception

The adapter contract is based on load-line equality, so it transfers to every geometry already supported by the corner's common solver when all existing guards pass. Required per-case computations are:

1. Read the exact chosen producer/section b,t,Ag,e_a and independent materials. Reject missing Ag/e_a; never fabricate radii or substitute another producer.
2. Place one actual angle on the selected face, derive z_face=±t_g/2 and z_angle=±(t_g/2+e_a), and publish the ordinary static end-axis idealization. Opposite-face choice mirrors actual geometry and the raw offset sign, without changing nominal planar strengths. No extra face is implied.
3. Use v_h=−e_a, v_t=b−e_a relative to the projected line through the selected work point; f_h=1−e_a/b and f_t=e_a/b. Regenerate finite weld footprints and angle-end containment. If the angle/toe orientation is mirrored in plane, mirror the full geometry and tractions together; do not keep old path constants.
4. Apply full P to the one angle and two fillets. Apply total line tractions once to the common polygon, common roots, receiver and complete joint. Recompute e_a/L, nominal block, each base material and fillet details.
5. Reuse the accepted actual polygon/traction integration, all vertex/weld/support stations, genuine free/support path classification, root/receiver sign logic, complete cuts, continuity derivation and panel. Recompute geometry-dependent constants. Old C1 chord formulas, continuity polynomial coefficients and path names are not universal constants.

Nine independently calculated cases cover C1, ordinary 40/50-degree geometry, two shifted-weld 40/50-degree examples, real Gerdau row 34, column fy250, continuity width120 and a coordinate-only relocation of the beam cut. The one- versus two-angle nominal plane fields are identical for each; individual angle demands double. The standard40/50 examples retain nonnegative body normal stresses to numerical tolerance. Moving their welds to700…920 creates actual negative edge stresses−0.461908 and−0.237297 MPa, so those two cases remain UNVERIFIED_COMPRESSED_GUSSET. These parameterized witnesses exercise the extension and its guards; they do not claim an unimplemented production 1L route has passed full release testing.

## 6. Required implementation acceptance and precise refusals

No implementation is authorized by this calculation-only deliverable. If later authorized, introduce a distinct 1L adapter/state with angle_count1 and actual face geometry; do not silently relax the old symmetric-T2L flag. Keep the old T2L outputs and native schema semantics unchanged. Present compact governing-component results with detailed force lineage and the explicit nominal end-axis scope; do not turn internal rows into dozens of extra user inputs or require an 'externally verified' escape checkbox.

Before a later release: compare every full C1 demand/resistance against the independently frozen fixture, run count/face/material/catalog/detail mutations and changed-geometry boundary tests, verify native save/reopen, reports and drawing show exactly one angle/two brace fillets but both double-sided roots, preserve2L/legacy regression and complete concurrent cuts. Reject missing/extra/nonfinite state as appropriate. Verify the baseline134 runtime hashes until an explicitly authorized implementation starts.

Specific nonapproval states remain:
- static/fatigue/seismic or explicit spatial action outside the selected exemption: UNVERIFIED_SPATIAL_OR_CYCLIC_COMPONENT;
- spacer or extra joint-plane offset: UNVERIFIED_SPATIAL_END_TRANSFER;
- in-plane nonzero work-point offset without chosen DG29 allocation: UNVERIFIED_ECCENTRIC_DISTRIBUTION;
- actually compressed gusset region: UNVERIFIED_COMPRESSION_COMPONENT;
- missing concurrent complete cut or unknown outside-cut load: incomplete/invalid data, never assumed zero;
- physical containment/detail or capacity failure: actual INVALID/FAIL, distinct from a missing method;
- global member stability/WPS/as-built qualification: explicitly outside local connection certification.

There is no remaining source/calculation gap for implementing the bounded nominal planar static 1L adapter described here. Full spatial resistance remains a different, precisely identified scope; no cancellation, unverified strength or blanket finite-element prerequisite is invented.
