# Independent numerical engine acceptance: single-angle corner

Decision: GO for the bounded static nominal planar 1L adapter at engine SHA256 `cf1d5aa352404bc661f1ad520e1bbf6ed20951a9add229fb7c9b831331ee22b0`.

The physically single angle takes full P through exactly two longitudinal fillets on the chosen face. Common gusset, two double-sided support seams, receiving members, beam–column complete joint, continuity plates and panel retain full common actions once. The actual positive-face C1 offset is 28.1 mm; raw spatial moment is 2.81 kNm at 100 kN. Both signs, their 22.1 mm and 6 mm partitions, and signed global raw moments are retained. The output explicitly disclaims spatial cancellation, exact 3D equilibrium and verification of raw spatial resistance. Acceptance applies only to the declared NBR6.1.8.2 ordinary static direct end-axis projection to the gusset midplane.

## Evidence and counts

Counts are separate categories, not an additive claim of unique new tests:

- Frozen C1 mechanical fixture: all 86 rows; exactly 9 brace/local-substrate rows double demand and utilization from the pair's per-angle state, while 77 rows remain unchanged. Capacity is not doubled.
- Nine independently calculated parameterized cases: ordinary 40/50-degree and catalog/material/continuity/cut-coordinate changes pass. The shifted 40/50-degree cases retain real compressed gusset edges and UNVERIFIED status.
- 879 numerical comparisons comprise 258 frozen-row values, 594 parameterized values and 27 freshly transcribed brace-formula values. There are 128 separate logical/invariance observations.
- Ten actual face/load/thickness/catalog variants yield 270 physical-geometry and nominal-versus-raw-spatial comparisons.
- Eight C1 physical U/L paths yield 112 frozen path/coordinate comparisons; 36 admissible blocks across 40/45/50 degrees independently close on real free boundaries without detaching retained supports.
- 362 new-1L adversarial observations and 92 native-state rejections cover missing/invalid mode/face, nonfinite values, loads, independent materials, catalog variation, containment/detailing, incomplete cases and actual strength failures.
- Nineteen prior routes and all 103 old presets retain complete canonical inputs, outputs and public derived properties after only known version metadata normalization. Five old corner native payloads reopen with no new required field. Two new presets bring the current total to 105. No status, diagnostic row or issue was normalized away.
- Production tests re-executed: 76 new single-angle tests plus 46 existing corner regression tests, 122 passed. These are not added to the independent counts or the historical qualification's 352 comparisons.

The source qualification manifest's 27 files and all 134 baseline 0.9.32 runtime hashes remain unchanged. No production file was edited by this reviewer. Exact current engine dependency hashes, all-runtime inventory and numerical-library/executable provenance accompany the machine-readable receipt.

## Resolved finding and harness precision

A valid 1L native payload originally accepted deletion of the face field and silently defaulted positive. The owner corrected this: the 1L field is now required; old 2L state remains compatible without it. The corrected engine passes the entire final independent run.

Body-source lists legitimately change from four brace tractions to two. The review verifies their independently aggregated force field and integrated body values, while retaining exact diagnostic identity and classifications; tiny numeric diagnostic payload rounding uses declared tolerances. Root-weld primitive capacities are force per unit length (N/mm), so their independent two-sided check uses the proper line capacity rather than total seam capacity. These were test representation/unit clarifications, not relaxed physical acceptance.

## Reproduction

The frozen nine-case independent source expectation reproduces exactly under NumPy 2.3.5. Runtime review uses Python 3.12.14 and NumPy 2.5.3 from the specified test dependencies. Expected values are never regenerated from production or changed to force byte equality across environments.

See README.md and replay.py: compare mode requires NumPy 2.5.3 and uses immutable source expectations with declared engineering tolerances; regenerate mode requires NumPy 2.3.5 and demands exact expected-file SHA256. Wrong/missing NumPy must stop with exit code 2 before output or staging. Portable replay reopens all five original2L corner native payloads and requires exact whole-result/native parity after known version metadata normalization. It excludes the other18 routes’ large snapshot rerun and the full application suite; their separately bound receipts remain explicit. The historical0.9.32 runner remains immutable and bound to its original runtime; the0.9.33 wrapper is the current entrypoint.

No full member/frame stability, fabrication/WPS execution, mill/as-built verification, arbitrary spatial force, stand-off, fatigue/seismic, compressed-gusset or unevaluated eccentric-workpoint approval is granted. Actual detailing/capacity failure and missing-method states remain distinct. The historical absent external bolt-bearing oracle remains unclaimed. UI/report/drawing and release-package acceptance are separate; no upload or deployment was performed.
