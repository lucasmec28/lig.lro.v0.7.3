# Validação focada 0.9.24 · end plate 8ES CJP

Versão de desenvolvimento para revisão técnica. Não é aprovação de projeto, fabricação, rigidez global, estabilidade dos membros ou ação sísmica. Não houve publicação ou implantação nesta etapa.

## Motor e preservação

- 174 testes focados da nova variante: kernels e unidades, fonte independente, caps, limites exatos, 16 furos/blocos, equilíbrio, casos assinados, duas espessuras, CJP, geometria real, dados inválidos e identidade nativa.
- 160 testes existentes de end plates passaram na fonte final.
- 253 controles numéricos independentes passaram. Essa contagem é separada da suíte pytest, e alguns controles contêm várias comparações.
- 65 comparações exatas com a base congelada 0.9.23 passaram, cobrindo as 14 famílias, resultados assinados de 4ES e retratos completos de 4E/4ES. Todos os 622 arquivos do manifesto da base permaneceram inalterados.
- Os PNG padrão de 4E e 4ES são idênticos, byte por byte, aos da base 0.9.23. Revisões e digests antigos são preservados, sem serializar o novo pb inativo.

## Interface e artefatos

- 15 testes de navegação: as 14 rotas reais e conservação do seletor de famílias.
- 96 testes nativos/de artefatos: variantes, rascunhos, importação atômica, valores assinados, invalidação de Word, geometria SVG/PNG e regressões de relatórios.
- Total único: 447 nós pytest. Reexecuções não são somadas. Não foi executada a suíte completa.
- Após duas correções isoladas de validação 8ES, 16 testes selecionados de artefatos foram repetidos na fonte final. Eles já estão no total de 447 e não são contados novamente.
- Word compacto com 12 páginas e detalhado com 19 páginas foram renderizados e inspecionados. XML do documento e PNG incorporado foram comparados exatamente com a geração pela fonte final: conteúdos idênticos, preservando a validade da inspeção das 31 páginas.
- SVG rasterizado e PNG foram inspecionados para os dois sinais de M: 16 parafusos, oito ativos, quatro braços físicos, quatro passos pb, duas nervuras e quatro corridas CJP reais. A entrada extrema pb=1e308 produz somente diagnóstico, conserva a entrada e não deixa Word antigo disponível.

A captura da tela interativa via Chromium não foi concluída neste ambiente: criação do socket process_singleton bloqueada com EPERM. A interface real foi exercitada com Streamlit AppTest; não se afirma uma inspeção de pixels da tela interativa. A inspeção visual dos desenhos e páginas Word foi concluída.

O desenho 8ES com M=N=V=0 não inventa extremo tracionado, parafusos ativos, braços ou pivô. Essa correção teve 9 testes afetados aprovados, com 2 nós novos e 7 repetidos; os PNG válidos de ±M e os antigos 4E/4ES permaneceram idênticos.

A revisão independente da interface e dos exports foi aceita na fonte final. O replay de 8 capturas nativas confirmou JSON e PNG canônicos; os 7 arquivos Word calculados conservaram exatamente XML e imagem incorporada. O caso nulo foi verificado após a correção, sem Word ou destaque ativo falso. Esses controles independentes não aumentam a contagem de 447 testes pytest.

## Correções limitadas encontradas pela revisão

1. Diâmetro quase igual ao catálogo podia passar por uma tolerância legada e causar KeyError na busca de borda. 8ES agora valida a identidade exata do diâmetro nativo, como já exigido pelo seletor imperial; retorna erro de dado sem arredondar a entrada. Não é nova falha física de resistência.
2. Campos legados inativos weld, pitch, overhang e n não podem impor geometria ou mínimos de filete à variante CJP. Valores finitos são preservados, sem alterar resultados 8ES; higiene de tipos/finitude permanece. 4E/4ES não foram alterados.

Motor aceito: SHA-256 19cefa9a24703fe6184bf5ca06194a85a7ff6b8880b8916108e3a67f4adf1a50.

Método e limites: END_PLATE_8ES0924_METHOD.md. Exemplo: examples/end_plate_8es_cjp.json. A fonte DG39 2023 e as limitações dos exemplos/errata são explicitadas, sem afirmar revisão de errata indisponível.
