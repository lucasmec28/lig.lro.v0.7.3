# 1L soldada à mesa do pilar e parafusada à alma da viga

13/10/2026. Candidata isolada para revisão e futura integração 0.9.43. Base somente lida: `review0941/source0941`. A fonte 0.9.42 em entrega não foi utilizada nem alterada. Sem publicação, pacote de release ou aprovação de fabricação.

## Decisão e alcance

A revisão independente em `independent_review/REVIEW.md` fecha uma **rota convencional descendente estreita**, com solda elástica conservadora e componentes NBR. Não é a R015 invertida nem metade de uma ligação 2L. O receptor é somente a mesa contínua de pilar W; alma de viga de apoio continua outra topologia.

O V informado positivo significa força descendente sobre a ligação. V≤0, N/M/T externos não nulos, recortes e outras interfaces retornam fora do domínio, sem apagar a entrada ou converter o sinal. A capacidade local nunca é aprovação da estrutura global.

Restrições iniciais: uma cantoneira laminada; uma coluna de 2 a 4 parafusos F3125; furos circulares padrão; e da face do pilar ao eixo dos parafusos ≤76,2 mm; meia-alma ≤6,35 mm; viga sem recortes e sem contato da ponta com o apoio; E7018/SMAW 485 MPa; ações estáticas em combinação última normal. Não há atrito de serviço, calços, solda no talão nem solda superior integral.

As abas são ≥63,5 mm (L64). Espessura 6,35 a 9,525 mm; b_apoio/t≥8; ambas as abas atendem ao filtro b/t≤0,45√(E/fy). Estes três limites são **restrições deliberadas da qualificação inicial**, não uma regra normativa universal de flexibilidade. O último toma a Tabela4 AL3 da NBR como filtro conservador de compacidade; sua origem é compressão longitudinal de cantoneiras, não uma prova isolada de flambagem da placa transversal ou de ductilidade. Não se usa esse filtro para substituir o detalhe convencional ou o envelope N/V/M. A ampliação além da faixa exige revisão, não atualização automática do catálogo.

## Evidência e correções

1. P901-23W/Companion v16, exemplo II.A-29, IIA-284–292/PDF824–832, SHA256 `ec25b52e1d7b6b9ec9e5eaccc27452153208784d7d715908daa2595dd8f92423`. Figura e dimensões inspecionadas. É exatamente uma L soldada ao pilar e parafusada à alma.
2. [Errata oficial de 02/06/2025](https://www.aisc.org/media/12lltkmv/manual-companion-v160_vol-1-errata.pdf): corrige kl para3in, k0,261, x0,0280, a0,250, C2,20 e capacidade56,9kip LRFD/38,0kip ASD. Texto oficial indexado confirmado por duas URLs; o download direto retornou403. Não se afirma inspeção visual desse PDF. A antiga inconsistência kl4in/aba3in está resolvida pela errata.
3. IIA-285: a meia-alma limite da tabela10-12a é **1/4in**, não4in. Inspeção visual preservada em `references/p901_IIA285.png`; o extrato textual antigo perdeu a fração.
4. [AISC Steel Interchange, fevereiro2005](https://www.aisc.org/globalassets/modern-steel/steel-interchange/2005/2005v02_si_web.pdf): a flexibilidade do topo da aba permite a idealização convencional sem o momento de engaste fora do plano. O momento excêntrico no plano da solda permanece. Texto oficial indexado, download403.
5. [Errata de Detailing for Steel Construction, 2ª edição](https://www.aisc.org/media/a3mjwxyh/errata-to-detailing-for-steel-construction-2nd-ed.pdf): detalhe genérico de cantoneira única com solda vertical externa, inferior e retorno superior curto. Fundamenta o uso de abas iguais sem exigir exatamente a seção desigual do exemplo. Texto oficial indexado, download403.
6. NBR8800:2024 com Errata1:2025 fornecida: SHA256 `2289dd360ae938982f44ce6b0633968652199604867172e9d0d454e71256b16d`. Soldas §§6.2.5–6.2.6, tabela9/11; parafusos/contato §§6.3.3 e6.3.7; cisalhamento/bloco §§6.5.5–6.5.6. PDF103/impressa81 inspecionada: retornos de elementos que exigem flexibilidade têm limite4w. Tabela4 AL3 conferida pela revisão independente.

## Geometria, montagem e liberdade de rotação

Uma cantoneira é soldada na oficina à face da mesa do pilar. A viga sem recorte é posicionada junto à sua única aba livre e parafusada à alma; não existe a interferência bilateral de montagem da2L. Acesso de ferramenta junto à concordância e às mesas da viga, folgas, furos e ocupação da solda na mesa do pilar são verificados a partir das dimensões reais. Instalações vizinhas não modeladas continuam sendo responsabilidade de detalhamento.

A solda efetiva é um L: linha vertical no toe externo e linha inferior do toe ao talão. O retorno superior físico tem2w≤r≤min(4w;b_apoio/2); permanece afastado da raiz. Ele é mostrado e registrado, mas não recebe crédito resistente. Não se acrescenta uma segunda solda vertical no talão nem se fecha o topo.

O catálogo Gerdau mantém suas dimensões métricas publicadas, não conversões imperiais refeitas. O raio interno não é publicado: seleção Gerdau exige valor e fonte independente declarados. A escolha geométrica não escolhe aço nem amplia o domínio.

O raio interno manual também representa a concordância física de uma cantoneira laminada. O valor zero pode ser digitado, importado e preservado para correção, mas produz pendência de engenharia e impede aprovação local, inclusive quando o modelo idealizado de raiz aguda aparenta deixar espaço para a ferramenta. Deve-se informar o raio real positivo antes de aprovar as folgas; não se inventa raio de catálogo nem um limite positivo universal. Testemunho de fronteira: no preset com g=40 mm, r=0 permanece pendente por falta da geometria física; r=10 mm demonstra a pendência de acesso real.

### Envelope físico da ferragem e ferramenta

`tool_radius` é o raio envolvente declarado do conjunto real de cabeça, porca, arruela e ferramenta. O cálculo de folgas sempre usa esse valor completo e não o reduz automaticamente. Uma triagem adicional exige que ele seja pelo menos metade do maior diâmetro físico padrão: distância máxima entre cantos da cabeça/porca heavy-hex e diâmetro externo máximo da arruela F436/F436M. Esse piso não é dimensão de chave nem certificação de acesso: a ferramenta real pode exigir mais espaço. A representação das cabeças no desenho é esquemática, não prova dimensional de montagem. Somente cabeças heavy-hex estruturais padrão A325/A490; cabeças especiais/modificadas S precisam de outro detalhe qualificado.

Fontes primárias de produto para a triagem: [BAPP, conjunto estrutural A325M, páginas 2–3](https://www.bapp.co.uk/_files/ugd/62c08a_5c990aa9e9ca4e71ba760aee1b788405.pdf) para dimensões métricas da cabeça, porca A563M e arruela F436M; [Portland Bolt, parafusos estruturais](https://www.portlandbolt.com/products/bolts/structural/) e [porcas heavy-hex](https://www.portlandbolt.com/products/nuts/heavy-hex-nut/) para cantos imperiais; [Anchor Bolt Express, tabela F436](https://www.anchorboltexpress.com/F844-F436-washer-chart/) para OD básico imperial somado à tolerância positiva publicada de0,0313in. Métrico e imperial continuam separados. A nomenclatura A325/A490 não muda a geometria heavy-hex padrão usada nesta triagem. A tabela não substitui seleção e certificação dos componentes reais.

Dados máximos, em mm, para M16/M20/M22/M24/M27/M30: cantos31,18/39,26/41,57/47,34/53,12/57,74 e arruela34/42/44/50/56/60. Para1/2,5/8,3/4,7/8,1,1 1/8,1 1/4in: cantos1,010/1,227/1,443/1,660/1,876/2,093/2,309in e OD básico da arruela1,063/1,313/1,469/1,750/2,000/2,250/2,500in. Usar a tolerância indicada antes da conversão exata por25,4.

Testemunho: M20, g=36 mm e raio declarado10 mm permanecem editáveis, porém com acesso pendente; o piso físico é21 mm, governado pela arruela. Elevar a21 mm ainda reprova a folga junto à raiz nessa geometria. Um valor maior informado nunca é reduzido ao piso. Os testes verificam o valor imediatamente abaixo, exatamente no piso e acima, em todos os treze diâmetros cadastrados.

O máximo do filete em borda não reforçada é t−1,5 mm para esta faixa de espessuras. O campo explícito `reinforced_weld_edge`, falso por padrão, permite o detalhamento de borda reforçada durante a execução, limitado nesta rota a w≤t, conforme NBR6.2.6.2.2(b). A garganta não recebe bônus de resistência. O desenho/procedimento registra a exigência. Isso pode viabilizar um filete5mm em L6,35mm; sem esse detalhe, o conflito5mm mínimo/4,85mm máximo continua reprovado. Estar no intervalo nominal de espessuras não garante viabilidade de todo perfil.

## Corpo livre e coordenadas

Eixos globais: x ao longo da viga, y para cima, z transversal. F=(0,−V,0). O transporte geométrico geral é r×F=(Vz,0,−Vx); não se acrescenta momento externo fictício.

No grupo de solda, as coordenadas são (z_global,y acima da borda inferior). Para lado+s, toe=s(tw/2+b), talão=s·tw/2, linha de aplicação no plano médio da alma z=0. O núcleo bidimensional retorna o momento escalar zFy−yFz, que é **−Mx global**. O espelho muda os sinais corretos, não a capacidade. A soma das trações transportada ao plano médio da alma dá F e momento globalMx zero, enquanto o momento local em torno do centroide de cada grupo é preservado.

A reação real entregue à face é Vsd; seu transporte ao centro do pilar tem braço d_pilar/2. Esse transporte só é somado no modelo estrutural se ele ainda não estiver representado. O mínimo45kN é uma conferência local uma vez no conjunto; não é uma reação global artificial.

A distribuição direta nos parafusos é a idealização convencional AISC para uma linha e e≤3in, com o detalhe flexível descrito. Não é uma dispensa genérica da NBR nem um engaste elástico completo. Esta decisão fica explícita na entrada nativa e no resultado. Não se aplica silenciosamente o mesmo modelo a grupo estendido, outra topologia ou ação ascendente.

## Solda e aba do apoio

Em coordenadas locais u do toe ao talão, a linha vertical tem H e a inferior b. L=H+b; uc=b²/(2L); yc=H²/(2L); J=(H³+b³)/3−L(uc²+yc²). F é a força vertical assinada; M=F(b+tw/2−uc).

q_u=−M(y−yc)/J; q_y=F/L+M(u−uc)/J. O máximo exato do módulo ocorre nas extremidades dos segmentos retos. Resistência uniforme sem aumento direcional: qRd=0,60fuw(w/√2)/γa2. A capacidade é qRd/qmax(F=1). O método elástico é demonstrado separadamente no P901 II.A-27; não reproduz os coeficientes ICR8-10.

Para cada seção vertical0≤u≤b, A0=F/L−Muc/J e K=M/J:

- N(u)=−KH(H/2−yc)+Kyc u
- V(u)=A0(H+u)+Ku²/2
- B(u)=KH³/12−uHA0−A0u²/2−Ku³/6+KHyc u/2

No talão, N=0, V=F, B=F·tw/2. Máximos de|N| nos extremos; de|V| também emu=−A0/K; de|B| também nas raízes reais interiores de B′=−HA0−A0u−Ku²/2+KHyc/2. Isso é integração exata de resultantes; não uma solução pontual exata de elasticidade bidimensional.

O envelope conservador de tensões da seção é σb=Nmax/(tH)+6Bmax/(tH²), τb=1,5Vmax/(tH), σeq=√(σb²+3τb²)≤fy/γa1. Metal-base junto à solda também recebe os limites locais por comprimento fy·t/(√3γa1) e0,60fu·t/γa2, aplicados separadamente à cantoneira e à única mesa do pilar. Não se duplica espessura nem resistência. Não se usa essa conferência local como prova de resistência global do pilar ou de um receptor cortado na borda.

## Parafusos, alma e cantoneira

Um único grupo físico atravessa t+tw e tem um plano de corte. Cada parafuso recebe Vd/n. Corte por plano usa0,45Abfub/γa2 com rosca e0,56 sem rosca, mais redução de pega quando aplicável. Contato usa a ramificação de deformação limitada min(1,2lc;2,4db)t fu/γa2, com ligamentos reais; a alma contínua não recebe uma borda vertical livre inventada.

São registrados: cada furo, somas normativas de contato e soma das transferências mínimas em série; escoamento/ruptura da aba perfurada e da aba sem furos; todos os prefixos de bloco L a partir da borda inferior carregada; cortante com instabilidade da alma da viga. O desconto líquido é o furo máximo da tabela14 mais2mm, salvo furação por broca documentada. A viga sem recorte não recebe um bloco de ruptura fictício até a junção contínua alma/mesa.

## Testemunhos que não serão ajustados para passar

O AISC corrigido dá56,925kip na solda ICR e passa54kip. O mesmo L elástico dá34,220209kip e **não passa**54kip. Parafusos simples71,569408kip; escoamento129,375; ruptura87,75; bloco93,691406. Diferenças de arredondamento do exemplo não são calibradas.

Na caracterização SI, o filete original3/16in=4,7625mm é inferior ao mínimo NBR5mm; isso permanece reprovado. A adaptação usa resistências materiais/fatores NBR próprios, sem escalar o C americano.

O exemplo operacional é novo e explicitamente local: W410×38,8/W310×97,0; uma L manual101,6×101,6×9,52; H240; quatroM20, p60; g65; solda5 e retorno10; V90kN. Ele não é o exemplo AISC nem comprova um edifício real. O caso adverso usa a mesma geometria e250kN e deve falhar. V invertido permanece fora do alcance.

## Artefatos e integração

Identidade nativa `welded_support_single_angle_shear`, versão própria. As rotas antigas permanecem intactas. Importação é estrita e atômica; nenhum resultado salvo autoriza exportação. UI, desenho e Word recalculam da entrada atual. Cálculo/JSON com precisão integral; camada de apresentação com até duas casas.

Antes de integração: revisar o motor, executar testes mecânicos/limites, conferir desenho/Word/UI e regressão R015/R016/catálogo na cópia isolada. A qualificação local não autoriza push, deploy ou pacote de entrega.
