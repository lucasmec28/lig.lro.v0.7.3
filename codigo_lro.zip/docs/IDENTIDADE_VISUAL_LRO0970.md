# Identidade visual LRO e catálogo integrado · 0.9.70

## O que esta revisão entrega

O aplicativo mantém o seletor direto com suas 26 rotas e acrescenta um catálogo visual opcional acima do formulário. Os filtros de grupo, texto, interface e modelo consultam somente metadados. A miniatura escolhe um candidato; somente **Abrir família** aciona o dispatcher nativo. **Voltar ao catálogo** reabre o painel sem trocar a família nem recriar o projeto. O painel e a identidade marinho podem ser desligados separadamente na barra lateral.

O formulário nativo e os controles de busca continuam sendo renderizados com o catálogo aberto ou fechado. Somente as miniaturas têm carregamento adiado enquanto o painel está fechado, evitando reprocessar exemplos a cada edição do projeto. Esta decisão evita que o ciclo de vida de widgets do Streamlit elimine campos ainda não salvos. A organização detalhada das entradas, vistas e resultados de cada família continua sendo a do módulo existente; esta revisão não reestrutura 26 formulários simultaneamente.

As 26 miniaturas são PNGs originais dos renderers/exemplos da base 0.9.69, sem recoloração, desenho geométrico inventado ou reaproveitamento de marcas Osdag. O manifesto `data/catalogue_native.json` identifica preset, renderer e SHA-256 de cada arquivo. São exemplos ilustrativos: qualquer valor, estado ou verificação impresso na miniatura pertence somente ao exemplo. Nenhum preset é carregado ao pesquisar, selecionar uma miniatura ou abrir uma família. As vistas do formulário continuam vinculadas às entradas do projeto atual.

A família de duas talas permanece acessível; a pausa de sua evolução técnica não remove o módulo. As ressalvas nominais, de rotação/flexibilidade e estabilidade continuam explícitas. Filtros não comprovam compatibilidade física ou rigidez. A base Tipo 1 legada não é convertida em Tipo 2.

## Camada reutilizável

`lro/visual_identity.py` concentra `TOKENS`, `shell_css`, `render_header` e `render_project_heading`. É independente de motores, projetos, Streamlit no import e bibliotecas de cálculo. Os renderizadores recebem o objeto de interface somente na chamada. A paleta usa marinho `#0a2342`, acento `#12365b`, fundo `#f3f6fa`, superfície branca, borda `#d7e1ec`, texto `#172b43` e texto secundário `#50637b`. Tipografia: Segoe UI / Roboto / Arial / sans-serif, sem fontes remotas. Classes próprias têm prefixo `lro-shell-`; variáveis têm prefixo `--lro-`.

O CSS altera a moldura visual, o cabeçalho e botões primários. Não aplica filtros a imagens, não reescreve paletas técnicas e não substitui cores semânticas de alertas ou estados de cálculo. Não grava configuração global do Streamlit.

A mesma camada poderá ser adotada incrementalmente em viga de rolamento, combinações e monovia: importar os tokens e o cabeçalho; manter a identidade e os contrastes; preservar widgets/keys, motores, imagens técnicas e exportações de cada aplicativo; testar conservação antes de distribuir. Esses aplicativos não foram alterados na 0.9.70. A versão do componente de cálculo e dos schemas permanece `0.9.44-beam-on-beam-partial-dev`; a identidade externa do pacote é `0.9.70-catalogo-marinho-dev.1`.

## Regras e limites

- Estado de apresentação novo restrito a `nav_guide_*`; abertura explícita pode atualizar somente o seletor existente `connection_family`.
- Pesquisa textual ignora maiúsculas e acentos, combina todos os termos com AND e consulta ID, nome, título e escopo. Um termo pode ocorrer numa exclusão do escopo; confira o texto completo antes de abrir.
- Não há importador global, migração silenciosa, inferência a partir de inputs/drafts/snapshots, novos cálculos ou alteração de resultados/exportações.
- Validação funcional com AppTest e invariantes de fonte/artefatos. O ambiente não permitiu abrir Chromium por restrição de socket; não há alegação de teste visual real em navegador. A revisão conserva essa limitação para a conferência local posterior.
- Próximo incremento seguro: revisão visual no navegador instalado e, depois, organização gradual de um formulário por vez, mantendo as mesmas entradas, vistas e resultados nativos.
