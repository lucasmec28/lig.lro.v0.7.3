# Base U com dois chumbadores no eixo de simetria

## Geometria e identidade

A configuração `two_symmetry` contém A1=(0,−ay) e A2=(0,+ay). Uma barra está atrás do dorso da alma; a outra está à frente da abertura. O U mantém centroide de catálogo (0,ey), com dorso y=ey−ec. As arruelas quadradas precisam manter margens positivas aos obstáculos locais (alma e mesas), às soldas, à placa e à outra arruela. A abertura do U não é obstáculo sólido; a arruela frontal pode ocupar esse vão. Para as mesas utiliza-se envelope retangular conservador com a maior espessura nominal da raiz e, quando menor, o limite do trecho reto T. A expansão por weld_size em ambos os eixos conserva a reserva de solda e é conservadora nos cantos. Geometria real de raízes e acesso de montagem continuam exigindo confirmação independente. `anchor_x` fica armazenado para retorno ao arranjo antigo, mas é inativo no arranjo de duas barras.

Ausência de `anchor_layout` em JSON esquema1 continua significando quatro barras. A origem .52-dev2 permanece intacta. Novos valores de catálogo não são inventados: área/centroide Gerdau e hipótese nominal 16,14% permanecem da .50.

## Ações e equilíbrio

N positivo comprime; N negativo traciona. O cortante V é paralelo à alma (+x). Sem M externo ou torção. Na compressão, contato integral requer |ey|≤B/6. O contato é o mesmo de quatro barras: q(y)=N/(LB)[1+12ey y/B²]; placa dimensionada pelo envelope qmax e projeções reais do U. Não se usa modelo I/H como substituição geométrica.

Na tração sem contato, U=max(−N,0), Ti=U/2[1+ey yi/ay²], com |ey|≤ay e Ti≥0. Os resíduos ΣN, ΣMx e ΣMy são publicados. O fator 1,4 de alavanca herdado é envelope de projeto, separado do equilíbrio nominal.

Para cada barra, bt é a distância até a face real da alma do seu lado; be=min(2bt+dh,T). T é o trecho reto verificado, não automaticamente d−2tf. A faixa centrada em x=0 cabe inteiramente no trecho reto. A placa usa o envelope herdado max(1,4Ti bt;0,4Ti eout) e resistência plástica por unidade de largura fy tp²/(4γa1). Trata-se de adaptação mecânica explicitada do balanço genérico de Ranzi e Kneen §5.2.2, não aplicação dos mecanismos de barras internas das Figs.47–52. O envelope de alavanca e apoio externo não é solução universal de contato/deformabilidade.

## Cortante e ancoragem

Corte por barras exige ey=0 quando V≠0. Duas barras idênticas mobilizadas em y=±ay, sem torção, recebem |V|/2. Cada uma é comparada individualmente com a capacidade condicionada à tração simultânea; a soma das capacidades não substitui essa comparação. Não se soma atrito.

O adaptador ACI aceita explicitamente somente uma linha 1×2 em x=0 e y=±ay. Recebe vetor documentado e qualificado que identifica exatamente A1/A2, soma |V| e tem componentes iguais. O kernel existente verifica uma fila de duas barras para a borda perpendicular e filas de uma barra para as construções virtuais das bordas paralelas, quando explicitamente selecionadas. Pryout usa somente as barras reais. O cone utiliza o grupo real e as trações de projeto. Não se duplicam barras ou capacidades para obter um grupo 2×2 fictício.

As expressões de resistência NBR são usadas como modelos mecânicos de componentes com seus fatores declarados. A configuração U/2 não é disposição literal da NBR8800/Tabela18, cuja nota(a) trata 4–8 barras. Não se creditam mínimos de arruela da Tabela18 como aprovação do detalhe de duas barras. As resistências ACI mantêm seus próprios φ, sem combinação com γNBR.

## Interface com a civil

A entrada de concreto serve às resistências locais dos chumbadores e ao contato: fck, hef, bordas reais, altura útil e apoio enterrado. Bloco armado, fundação, solo e estabilidade global são responsabilidades da disciplina civil. A memória entrega as ações externas e as reações nominais/de projeto identificadas. Dados mínimos ausentes mantêm a verificação pertinente pendente.

## Verificação de software

`verify_legacy_parity.py` compara resultados completos e assinaturas de 54 combinações de quatro barras. `test_channel_two_anchor0953.py` verifica geometria, equilíbrio, fórmulas independentes das faixas, paridade da compressão/solda, JSON antigo/novo, ACI, sinais de V, rejeição de torção, desenhos, Word e alternância persistente dois/quatro. Isso verifica implementação; não é certificação física do detalhe.

## Detalhe de arruela com apoio direto

A rota nova `fitted_direct`, exclusiva de duas barras, exige Dbase+2δ≤dh, com dh=db+1,5 mm. δ é zero somente pela especificação explícita de furação conjunta após a solda; alternativamente é uma tolerância positiva informada. Arruela e placa assentam continuamente, sem vazios ou calços. O programa não reduz furos importados: uma abertura alargada incompatível reprova esse domínio.

A porca é ASTM A563 Grade A heavy hex UNC, com engate integral e acabamento compatível. A adequação normalizada usa prova mínima 75 ksi (galvanizada; sem revestimento 100 ksi)≥fu,min 400 MPa da barra; isso não transforma carga de prova em resistência NBR da porca. Princípio de compatibilidade de ASTM F1554§6.7.2 adaptado à barra A36 e explicitamente também ao diâmetro 3/8.

Geometria ASME B18.2.2-2010: Dface=0,95Fmin−kFmax, k=0,04 até 1½ polegada e 0,06 acima; rebaixo máximo db+0,762 mm em 3/8 e 1,08db acima. A barra pode deslocar ebar=(dh−db)/2; assim, di=max(drebaixo,2dh−db) e Dútil=min(Dface,lado−2ebar). Acont=π(Dútil²−di²)/4. A circunferência externa conservadora da porca 2Fmax/√3 e a folga da barra também precisam caber na arruela, evitando contato com os filetes externos.

Contato axial: q=Td/Acont≤min(fy,arruela;fy,placa)/1,10, critério elástico próprio de engenharia, não equação normativa de apoio NBR 6.6.2. Td é a tração de projeto que já contém 1,4, sem repetir esse fator. Não há ponte axial da arruela sobre vazio no domínio aceito.

Corte: por arruela, F=Fv,Rd não reduzido; L=4s e q=F/L. Comparam-se solda 0,6fw a/1,35; pressão/rasgamento do furo min(1,2lc ta fu;2,4db ta fu)/1,35; e metal-base local das quatro raízes, usando o mínimo entre escoamento/ruptura 0,6fy t/1,10 e 0,6fu t/1,35 da arruela e da placa. As áreas são L×ta e L×tp, contínuas e sem furo nas raízes. Conservam-se detalhamento do filete, sobreposição, folgas e alcance material A572 Gr.50 até 100 mm. Não se inventa binário adicional F(tp/2+3ta/4) na solda: o modelo de curvatura reversa do DG1 permanece na barra.

Fontes dimensionais e materiais verificadas:
- AISC Design Guide 1, 3ª edição, §4.5.3 e Exemplo 4.7-6, pp.95–96.
- https://www.aftfasteners.com/heavy-hex-nuts-dimensions-technical-information/
- https://www.portlandbolt.com/technical/faqs/hex-vs-heavy-hex-dimensions/
- https://www.zzsteels.com/knowledge/asme-b18.2.2-2010.pdf

A rota de quatro barras e o modelo anterior de arruela são preservados. Falta de seleção ou dado necessário mantém a verificação correspondente pendente; furo grande não é convertido automaticamente em detalhe ajustado.
