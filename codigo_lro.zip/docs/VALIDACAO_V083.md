# Validação focada da versão 0.8.3

Foram exercitados cone de concreto, controles independentes de solda, conversão perna/garganta preservando o filete físico, importação repetida de JSON, alternância de família e modos ocultos, invalidação da memória, desenho de graute e componentes enterrados, equações Word e compatibilidade da rota de chumbadores.

A rodada focada de 81 testes terminou com 80 aprovados e uma regressão de texto legado no Word; a correção foi confirmada em uma rodada de 25 testes de artefatos, detalhe e integridade da instalação, todos aprovados. Não somar essas contagens: há testes repetidos. O teste agregado e a aceitação do pacote final ainda pertencem à etapa de liberação.

O exemplo cone083 foi regenerado e suas 12 páginas Word foram renderizadas e inspecionadas. A indicação do graute foi deslocada para chamada própria, sem conflito com a cota da altura do bloco. O desenho do par de enrijecedores também foi regenerado; capacidade dos enrijecedores não foi atribuída.

Não houve deploy nem homologação no navegador de produção. O cone complementar não completa a ancoragem no concreto e as novas escolhas de solda/vínculo/enrijecedores são detalhamento nos limites documentados.


## Liberação final

A suíte agregada passou: 453 testes em 204,18 s. As 18 verificações independentes legadas passaram, assim como os 16 casos numéricos independentes de chumbadores e quatro grupos de estado. As verificações independentes do cone são documentadas em seus testes e referências; os testes de software não constituem homologação de engenharia.
