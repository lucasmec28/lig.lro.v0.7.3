# Corte externo perpendicular da chapa de nó

## Uso e alcance

A opção é desligada por padrão. Projetos antigos conservam o contorno original. Selecionar “Corte perpendicular ao eixo” e informar a distância externa. O aplicativo não altera posição, diâmetro, carga, largura ou altura para fazer o corte caber.

- Parafusada: distância do centro do último parafuso físico à face externa, no sentido que se afasta da raiz. Ao ativar a opção com Ø3/4 selecionado, um campo ainda não informado recebe o gabarito prático editável de35mm. Outros diâmetros exigem um valor informado; o aplicativo não converte M20 em Ø3/4.
- Soldada: distância do término físico dos cordões longitudinais à face externa. O valor deve ser informado;35mm não é uma regra universal de solda.
- As margens antigas `angle_end`, `end_margin` e `brace_free_end_extension` pertencem à extremidade da cantoneira em sentido oposto. Continuam independentes.

Abrange uma raiz com1L/2L-T soldadas ou uma linha de parafusos1L/2L-T, e os quatro adaptadores de canto1L/2L-T soldados/parafusados. Cantoneiras opostas pelo vértice não recebem esta opção. A compressão conserva exatamente seus métodos, fatores K, condições e limitações anteriores;1L comprimida continua não qualificada.

Este incremento é apenas o primeiro corte transversal. Não implementa o afunilamento das duas laterais nem encurta raízes. Isso delimita o modelo calculado; não proíbe essas geometrias na engenharia.

## Polígono físico único

Seja a o versor da diagonal para fora dos apoios, independentemente do sinal de N. Uref é o maior produto a·p entre centros dos parafusos físicos, ou términos físicos de solda. A chapa é P=P0∩{a·p≤Uref+e}. P0 mantém o envelope original e, nos cantos, o alívio interno existente.

O kernel deduplica vértices e identifica arestas por seu papel físico. Todos os contatos apoiados completos e as pegadas efetivas das soldas de raiz são conservados. Conter apenas o centroide da raiz ou sua linha média não basta. Furos físicos/líquidos, ferramentas/hardware informado, sobreposição, pontas das L, pegadas de solda e faixas de introdução permanecem contidos.

A projeção perpendicular da referência deve pertencer ao segmento real cortado e ser a primeira saída axial. Uma borda antiga que é atingida antes torna a cota proposta inválida. Um plano que não remove material aparece como “sem remoção”, sem nova face fictícia e sem cota física de corte.

Croqui, geometria exportada e verificações usam P. B/H continuam entradas do envelope; onde o corte reduz a altura, o desenho a identifica como H_env. A área fabricada retida é obtida do polígono, sem arredondar suas coordenadas.

## Verificações resistentes

- Contato/rasgamento terminal: primeira interseção +a com a borda real, menos metade do diâmetro físico. Passos interiores e a extremidade oposta da L são independentes.
- Blocos L/U: novas saídas, comprimentos e áreas brutas/líquidas; dois ramos NBR preservados; caminhos alternativos não são somados. Contato apoiado positivo impede tratar um bloco como destacado. Eventos de vértices e de furos e extremos interiores permanecem enumerados.
- Seções horizontais perfuradas: uniões líquidas limitadas pela corda real, área, centroide, inércia e momento transportado. O método continua uma triagem nominal suplementar por busca escalar, não uma certificação intervalar ou solução de contato nos furos.
- Seções horizontais soldadas: limites e centroide afins entre eventos, N/V afins e momento no centroide quadrático. As tensões são racionais: σ±=[Nw±6Mc]/(tw²). São avaliadas fronteiras e raízes da derivada racional. O cisalhamento é uma razão afim; o VM conserva o envelope conservador dos máximos separados. Uma ponta sem largura e sem força é um limite de medida nula, nunca uma seção carregada descartada.
- Seções de u constante abaixo do corte são geometricamente invariantes, desde que suas pegadas estejam contidas. Whitmore e introdução usam/confirmam o polígono final. Raízes, receptores e COMPLETE_CUTS são recalculados a partir de contatos sem alterações e permanecem comparados por paridade.
- O corte pode produzir tensão normal de sinal misto. Falhas e restrições existentes continuam visíveis. Não se muda K, não se substitui compressão por tração em módulo nem se cria um vínculo físico.

A evidência de contenção é vinculada à geometria física atual. Um polígono alterado invalida a declaração antiga. Distâncias inativas ou um plano sem recorte efetivo não alteram o vínculo geométrico. Nenhuma operação de importação confia em um resultado ou aprovação salvos.

## Fonte normativa e limites

ABNT NBR8800:2024/Errata1:2025 fornecida pelo usuário:

- Tabela14, página impressa90: para Ø3/4, furo padrão13/16=20,6375mm. Dedução líquida mantém a política de furação declarada, separada da técnica de corte do contorno.
- 6.3.11.1/Tabela16, página92:25mm é a triagem tabulada de centro à borda para esse furo padrão. A nota permite distância menor se a equação aplicável de6.3.3.3 for satisfeita; este aplicativo conserva a triagem tabulada existente e não afirma que a norma proíbe absolutamente valores menores. Furos alargados/alongados não são qualificados por esta opção.
- 6.3.12: limite min(12t,150mm) mantém a interpretação/aplicabilidade anterior de cada rota. A interpretação conservadora de toda borda livre no canto continua marcada não verificada quando excedida.
- 6.2.6.2.6(a), páginas81–82: no transpasse tracionado especificado, interromper o filete ao menos uma perna antes da borda tensionada. Não é gabarito universal de35mm para solda. A margem externa não substitui sobreposição nem comprimento efetivo de6.2.6.2.5/6.2.6.2.3.

A verificação externa histórica de contato de parafusos cujo oráculo está ausente continua pendente. Os novos testemunhos de polígono e equações escalares não substituem nem recebem o nome desse oráculo. Revisão do aplicativo não é aprovação de fabricação, WPS, instalação, inspeção, estabilidade global ou projeto completo.

## Compatibilidade e apresentação

Novos arquivos usam versões de componente0.9.39 e guardam os controles exatos. Leitores anteriores permanecem explicitamente aceitos, sem inserir um corte. Arquivo híbrido que mistura versão antiga com campos novos é rejeitado. As superfícies de apresentação mantêm a camada0.9.38 de até duas casas, sem arredondar cálculo, estado nativo, limites ou coordenadas.
