# Independent bounded W-splice kernel audit

**Historical checkpoint.** This document records its original axial/research stage. A separate conventional N/M/V family now exists in `lro/w_splice_conventional.py`, with its own `W_CONVENTIONAL_NMV_SCOPE.md`. Statements below that general W work is pending describe that historical stage, not the current selector as a whole. The 0.9.13 audit is solely the axial M004 family; see `AXIAL_SPLICE_AUDIT0913_METHOD.md`.


Date: 2026-10-09. Read-only application audit; no application source edits and no full-suite run by this reviewer.

## Result

The corrected kernel reproduces the supplied independent pure-tension model. No outstanding material resistance or domain-gate defect was found for the closed family: actual eight-cover, balanced M004-type W splice, N>0, M=V=T=0. This is a kernel verdict only; it does not approve the UI, drawings, fabrication, a supplied product, global members/buildings, compression or general N/M/V.

One concrete access-completeness defect was identified, reported, fixed by the implementer, and independently rechecked. A small research-helper input-hardening issue was also reported, fixed by the implementer and independently rechecked; it had no resistance/approval exposure.

## Evidence and reproducibility

- Closed basis: `w_splice_scope/axial_tension_completion.md`, its four-case fixture JSON, and standalone `verify_axial_tension_completion.py` (Fraction arithmetic, no application import).
- Primary clauses checked from supplied extracts: `axial_splice_scope/source/nbr-113.txt` (NBR 6.3.7–6.3.9) and `nbr-114.txt` (6.3.10–6.3.12).
- ASTM's primary publication page confirms the metric 830/1040 MPa F3125M tensile-strength classes: https://store.astm.org/f3125_f3125m-21.html. The app's 830 MPa A325 metric calculation must be distinguished from the source oracle's deliberately conservative 800 MPa numerical fixture input. Tests explicitly account for that known difference; no 800→830 claim about an actual material certificate is made.
- Parent script: `connections_work090_w/parent_qa/audit_w_tension_kernel.py`.
- Machine-readable evidence: `connections_work090_w/parent_qa/w_tension_kernel_results.json`.
- Use bundled Python with `PYTHONPATH=/workspace/scratch/200bd23c4a9b/connections_audit/test_dependencies`.

Validated hashes after access-margin fix:

- `source/lro/w_splice.py`: `fc572d24ff7d0269685b9a9128e49d4a7fd4eb12b0811270612dc0412d6dba96`
- `source/lro/w_splice_equilibrium.py`: `8e9262e9a0b0b8ae0de42e67b6267ab14c3ae7226955df56bc442d39f7fb435d`

Results:

- Standalone oracle `--check`: PASS, all four fixed fixtures.
- Focused existing kernel/equilibrium tests after both fixes: 61 passed in0.13 s.
- Independent expanded audit: 61,608 numeric comparisons passed.
- 57 numeric cases: original four, flange rows2–6, unequal actual member/cover loaded ends, longitudinal/transverse pitches, cover widths/thicknesses, changed steel classes, A490, documented thread exclusion, M16/M20/M24/M30, physical-hole variation, drilled/non-drilled deductions, mandatory45 kN assembly floor, and30 deterministic mixed-geometry cases.
- 22 domain/boundary cases,8 minimum-action/access/detail policy cases,268 malformed field cases,8 JSON mutation cases and4 independent signed-equilibrium fixtures passed their expected checks.

## Resolved finding: declared fabrication margin omitted from tool checks

Original kernel hash: `f09994d1b80002ba364d30a2baa3f65d48e78be69707896109e3d940c438e023`.

At original lines241–244, all four tool-envelope checks compared available clearance with `tool_radius`, omitting the separately declared `fabrication_clearance`. The independent source fixture requires the additive margin for tool clearances.

Reproduction: set the default W310×97 case's tool radius to61 mm; leave fabrication clearance3 mm. The original code returned `COMPLETE_CHECKS_PASS_WITH_PRESET_DEVIATION`. Available web-bolt-to-inner-flange-cover distance was62.6 mm, less than the required64 mm. Root distances63 and61.55 mm also could not accommodate the declared margin.

The implementer changed all four thresholds to tool radius plus fabrication clearance. Parent rerun now returns `ENGINEERING_MODEL_PENDING`, retaining valid physical geometry and all193 diagnostic strength checks. This preserves the required distinction between assembly access pending and impossible geometry. Baseline25 mm tool still passes. A matching focused regression was added by the implementer.

The bundled scope document initially retained the old physical-hole-plus2 wording; the implementer has refreshed it to the corrected Table14 convention.

## Mechanics verified

1. Catalogue area A=12360 mm² is retained. Aw=2744.28 mm²; each allocated flange area4807.86 mm²; each local rectangular flange area4697 mm². Root residual221.72 mm² increases flange demands without creating fictitious local flat-plate capacity. All component and cover forces close to the whole N.
2. Eight real covers,11 representative components,22 physical transfer regions and44 bolts are modeled in the baseline. Opposite splice sides are serial transfers, not additive capacities. Each flange has one outer cover and two one-column inner strips.
3. Whole-W conservative net area is10168.8 mm² at dn24 mm, with corrected Ct=1.0. All four flange and three web holes enter the conservative envelope. Covers alone use Ae=min(An,0.85Ag).
4. Physical-hole diameter is used by bearing and clearances; Table14 maximum plus2 mm is used for ordinary net deductions. M24 physical26 mm produces dn29 mm, not28 mm; drilled M24 produces dn27 mm.
5. Gross, net, end and interior per-hole bearing, bearing-group sums, all admitted block prefixes and their physical mirrors agree with the independent model. Original flange keeps real external L1 paths only; original web has U paths only. Every inner strip has one real column, and its two L candidates each receive the full appropriate strip force.
6. The three-level web U includes the middle full hole: at baseline full-prefix Agv1980, Anv1267.2, Ant712.8 mm². Resistance491040 N; it governs the assembly envelope at2211601.7316017314 N.
7. Baseline floor and2200 kN pass;2250 kN fails only the member-web full U among the89 representative checks;3500 kN has multiple failures. Copying symmetric physical checks does not increase capacity.
8. Double-shear bolts use both actual planes; each bolt's action is divided between them. A325830 MPa and A4901040 MPa are used explicitly. Thread-excluded branch changes only bolt capacity by0.56/0.45 and requires an explicit boolean.
9. Member and cover product/thickness gates are enforced; unsupported steels receive no fallback strength. Additional A572 cover cases agree with independent fy/fu values.

## Editable geometry, long joints, grip and unsupported packing

NBR6.3.8 multiplies bolt shear and bearing demands by1.20 for bearing-type tension splices beyond950 mm. Rather than applying a partial long-joint model, this family conservatively refuses resistance evaluation whenever the total extreme-bolt span exceeds950 mm. This span includes both splice sides and gap, so it is deliberately more restrictive than one transfer region.

- Flange rows6, pitch86 mm, member end40 and gap10: span950 mm, remains evaluable.
- Pitch86.000001: span950.00001 mm, `OUTSIDE_BALANCED_M004_SCOPE`, no strength checks.
- Web pitch430: span950 mm, diagnostic strengths remain available but maximum-spacing detailing fails, appropriately avoiding a complete pass.
- Web pitch430.000001: span>950 mm, outside scope, no strength checks.

NBR6.3.7 requires the applicable long-grip shear reduction beyond5db, apart from its pretensioned high-strength-bolt exception. This model takes no advantage of that exception and gates all such grips.

- M20 flange cover thickness42.3 mm yields member15.4+2×42.3=100 mm=5db: calculations remain possible, subject to separate detailing/access gates.
- Thickness42.300001 mm gives grip100.000002>5db: outside scope and no strengths.
- An adjusted web stack above5db likewise produces no capacity calculation.

The flange-row limit2–6 and fixed2×3 web pattern are independently enforced. Unsupported packings are explicitly excluded by the family contract; adding `packing_thickness` to project JSON is rejected rather than silently folded into a double-shear calculation. Changed web patterns, eccentricity, nonzero moment/shear/torsion, non-static loads, slip-required design and altered balance do not produce axial approval.

## Minimum forces and project context

The45 kN floor is applied once to assembly N before partition. The50% gross-member tensile reference is an explicitly selected conservative recommendation under6.1.5.3, not a geometry criterion or mandatory universal compression check.

The slenderness-selected branch requires positive supplied Nc,Rd and a reference; it does not fabricate an effective length or compression resistance. Missing Nc,Rd is pending with no adopted design action; missing reference retains diagnostic calculations and pending status. Explicit RT non-adoption requires a recorded decision and retains the mandatory floor. Integrity inclusion is an explicit input premise; setting it false retains diagnostic checks but blocks a complete status. No global4.13 claim is made.

## Serialization and malformed data

Exact family/version/schema and field sets, units and fixed assumptions are verified. Numeric booleans, nonfinite values, oversized integers, malformed strings/lists/objects and malformed profile fields do not produce a capacity result. Result objects remain strict-JSON serializable. Unknown packing and extra load-axis fields are rejected. N=0 is not evaluated and cannot become a green45 kN result; negative N and even tiny nonzero M leave the supported family.

## Resolved research-helper hardening

The original `w_splice_equilibrium.py` verified list lengths but not distinct coordinates on each grid axis. With web_x=[0,0], web_y=[0,0], it raised raw ZeroDivisionError; with web_x=[0,0], web_y=[-60,0,60], it accepted coincident duplicate columns. The implementer added unique-coordinate and positive/finite J checks. Both repros now consistently raise ValueError, and the full independent parent script was rerun successfully against the updated helper hash above.

This helper is explicitly research statics only and never selected by public axial evaluation for nonzero M/V. No unsafe resistance pass follows from this defect. Valid independent signed fixtures reproduce allocation and total cover equilibrium to the stated tolerance. The corrected helper preserves all four valid independent signed fixtures. Both fixes are now covered by independently rerun parent evidence.
