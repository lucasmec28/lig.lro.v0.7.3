# Column-to-base welds: implementable kernel and finite supported domains

2026-10-09. Source/specification only. No application files changed.

## Result and integration decision

The useful new increment is a **Type 2, concentric uplift, web-strip model** and a shared NBR fillet/CJP resistance kernel. A general fixed-base N/M/V approval is still not established. This is a finite finding, not a recommendation for another broad literature-search cycle.

Use three distinct statuses: (1) demand field established for this case, (2) particular weld/base-metal checks pass or fail, and (3) complete connection load path verified or pending. A selected CJP, an electrode number, a plate-thickness pass, or a full-strength weld-capacity screen cannot establish status (3).

The previous note remains valid for prepared-bearing compression plus web shear. This note adds actual CJP capacities and the Type 2 uplift field; it does not supersede that note's unresolved general fixed load-path finding.

## 1. Coordinates, actions, and mandatory equilibrium checks

Use x along column depth and V, y across flange width, z up the column. N is positive compression. N, M_top and V are factored actions at the **upper surface of the baseplate**. For Type 2, M_top=0 by the family definition. Lower shear-device eccentricity contributes to the plate/foundation equilibrium, not automatically to column weld demand.

A general supplied/generated weld-and-bearing field must satisfy, with one consistent sign convention:

- Integral of all normal weld tractions plus signed bearing resultants equals -N.
- Integral of x times those normal tractions equals M_top.
- Integral of all in-plane shear tractions equals V.
- Transverse resultants, minor-axis moment, and torsion are zero in this plane model.

Check these identities before applying the resistance kernel. Anchor-row forces alone generally do not satisfy them at the column interface. DG1 Example 4.7-9 itself has a 47.0 kip anchor-row force but a 65.9 kip flange-weld force; substituting the former for the latter would understate the example weld demand.

## 2. Shared resistance kernel: exact NBR provisions

### Fillets

For equal orthogonal legs s, no penetration credit: a=s/sqrt(2). For a weld element carrying line traction (qx,qy,qz), all in N/mm:

- q_resultant=sqrt(qx^2+qy^2+qz^2)
- q_w,Rd=0.6*fw*a/1.35
- U_w=q_resultant/q_w,Rd

NBR Table 9 expressly uses the vector resultant of the forces causing normal or shear stress on the parts' contact surface. Apply this per unit effective length when stress is nonuniform, as required by Table 9 footnote d. Never use leg area as throat area. No 1.5 directional bonus is used in this kernel.

For uniform demand over a legitimate length L, multiply q_w,Rd by L. The calculation does not establish that L is effective. Different weld types are evaluated separately under 6.2.3; do not combine their capacities without a compatible force distribution.

### CJP groove welds

NBR 6.2.5.1 defines A_MB as length times the thinner connected base-metal thickness and fy as the smaller yield strength of the two base metals. For a qualified CJP segment of effective length L:

- t_min=min(t_column_part,tp)
- fy_min=min(fy_column,fy_plate)
- A_MB=t_min*L
- R_normal=A_MB*fy_min/1.10, for tension or compression normal to the effective section
- R_shear=0.6*A_MB*fy_min/1.10, for the shear vector on that section

The two sides of a CJP preparation are **one fused section**, not two CJP resistances. Do not multiply A_MB by two because both web faces are accessible. The flange and web have distinct actual effective lengths and thicknesses.

Table 9's normal and shear rows are not a supplied general interaction equation. Checking both separately at U<=1 is not proof of simultaneous N/V adequacy. If an analyst chooses a von-Mises stress interaction or conservative linear interaction, identify it as an additional mechanics model and validate the actual base-metal stress field; do not label it an explicit Table 9 combined-action formula.

CJP normal/shear Table 9 checks do not replace applicable connected-material checks under 6.5, local plate bending, net sections, tearing, or member stability. In particular, an access hole reduces the connected material and cannot be ignored by using the gross catalog area.

## 3. Verified new demand generator: Type 2 pure concentric uplift

### Domain

- Centered doubly symmetric I/H column; four identical rods at (x,y)=(±a2/2,±a2/2), all inside the flanges and beside the web.
- N<0, M_top=0, V=0 for the fully sourced force-path increment.
- Unstiffened plate, no eccentric load, no plate opening/cutout affecting a transfer strip, and no fatigue/cyclic/seismic action.
- The plate is explicitly checked for one-way cantilever strips from the rods to the web, consistently with DG1 Example 4.7-3. Do not assume NBR's l0 is a weld length.
- Two actual continuous web fillets, or a qualified CJP web connection, covering the straight accessible region. Actual root/cope/access-hole exclusions and setbacks must be known.

### Geometry and normal line forces

For each rod:

- e=(a2-tw)/2, the distance from rod centerline to the relevant web face
- b_eff=2e=a2-tw
- T_i=-N/4
- I_i=[x_i-e,x_i+e], with x_i=±a2/2

For this symmetric square layout the two intervals on one web face do not overlap: the gap between them is tw. Require both entire intervals to fall within the actual accessible weld. Do not silently clip an interval and lose load, or use a clipped length while leaving an unexamined eccentric resultant. If an interval does not fit, this particular demand generator is unavailable; a different justified spread/plate model is needed.

On each web face, qz=T_i/b_eff inside each I_i and zero outside. The two faces together integrate to -N and zero M_top. The entire physical web weld may remain continuous; the unused length receives no uplift resistance credit.

Fillet check on **each face**: qz <= 0.6*fw*a/1.35.

CJP normal check on the **one web section**: 2*qz <= min(tw,tp)*min(fy_column,fy_plate)/1.10.

### Direct local column-web checks

With unperforated material across the actual transfer interval:

- Normal force per unit x length is 2*qz.
- sigma_web=2*qz/tw.
- Check sigma_web <= fy_column/1.10, and sigma_web <= fu_column/1.35.

These are the local normal yielding and rupture checks of NBR 6.5.3, using actual net material if reduced. DG1 Example 4.7-3 checks the corresponding local web stress after designing each face's weld. Do not add two web areas.

### Consistent plate check

For each rod's strip:

- m_strip=T_i*e/b_eff (N·mm per mm)
- t_req=sqrt(4*m_strip*1.10/fy_plate), from plastic strip bending

This is the DG1 strip mechanics with NBR yield strength/factor, explicitly identified as that combination. It is a supplementary load-path requirement; retain the native NBR Type 2 thickness checks too. Usually the 45° weld strip is shorter than NBR's l0, so passing the native l0 plate calculation does not itself justify the longer weld.

The following plate-side checks remain distinct: shear on the actual strip section, local fusion/base-metal failure, simultaneous bending/shear where material, rod-hole/washer region, and termination/tearing paths. A bending-only and web-normal-only pass must not claim the entire welded connection is verified. The source example does not provide a universal adjacent-plate section or interaction formula for all app geometry. This is the precise boundary of this sourced increment.

### Extension to N+V: exact kernel, incomplete field validation

DG1 4.3.4 requires combined normal and shear weld demand. If a separately justified load path assigns all V to two equal continuous web fillets of length Lw, qx=V/(2Lw), combine it with the above qz at each station using hypot(qz,qx). Outside the uplift intervals only qx acts.

The normal web stress is 2qz/tw and nominal shear is V/(tw*Lw). A supplemental mechanics screen is sigma_vm=sqrt(sigma_web^2+3*tau_web^2), but this is not a substitute for identifying/validating plate-side combined force transfer. In particular, do not feed unequal foundation rod tensions created by V*eV into the pure-uplift generator without re-establishing column-interface equilibrium.

Therefore this N+V calculation is a **weld-metal check for an explicitly assumed field**, not a completed Type 2 assembly model. It may be displayed as such, with the unresolved plate/base-metal component kept pending.

## 4. Finite useful fixed-family domain and exact remaining gap

The current fixed-family geometry can legitimately use the existing prepared-bearing domain: N>=0, M_top=0, V parallel to the web; compression through qualified contact, two equal web fillets carrying V. This is a useful compression/shear result even if the global structural model calls the support fixed. Naming the family fixed does not create a nonzero M requirement for every combination.

DG1 Example 4.7-9 additionally verifies a particular pure-moment layout using exterior flange welds and a force couple F=M/d. Its weld faces are separated by d. A CJP flange-centroid model would instead have lever d-tf; do not interchange these levers. The numerical fixture reproduces the example's demand and deliberately recomputes its resistance with the NBR default fillet rule, so its AISC 1.5 transverse bonus is not imported.

For a general two-flange model, statics could write signed normal resultants -N/2±M/h. That algebra alone does not establish the chosen lines, the neglect of web normal transfer, the effective lengths under flexible plates, compression contact, or compatibility with the app's plate/rod model. Consequently it is not a general fixed-base implementation specification.

The **smallest missing validation** is a finite, documented column-interface load-path model for the actual four-exterior-rod NBR geometry:

1. Establish flange/web/bearing normal traction fields for compression-only, partial uplift, and full uplift, with both M signs and several rod/flange-width ratios.
2. Demonstrate the force/moment identities in section 1 and effective transfer widths consistent with the actual plate model.
3. Establish the adjacent column and plate base-metal sections and simultaneous normal/shear/local-bending checks.
4. Validate these fields and limits against a published matching model or an independently checked shell/solid/contact model. A transparent analytical model is acceptable if its load path and conservatism are established; FEA is not categorically required.

This is the missing engineering model. It is not an absent safety factor or a missing CJP checkbox. Additional isolated weld-resistance references cannot close it.

## 5. Material, fabrication, bearing, and detailing gates

### Material/procedure

- Add explicit column steel. It cannot silently inherit plate steel.
- Check product type and thickness domain for both materials.
- Record electrode/process and a procedure/detail reference. NBR Tables 8–9 determine compatibility; fw alone is insufficient. A deliberately supported initial combination is SMAW E7018 (fw=485 MPa) with Table-8-compatible A36/A572 Gr.42/50/55/A992, subject to the actual product and thickness domain. Do not extrapolate this to the entire app steel list.
- Table 9 footnote d requires the higher class where Table 8 offers two strengths for nonuniform weld stress.
- Mixed-strength base metals: observe Table 8's compatibility choice, low-hydrogen requirement for the lower-strength matching option, and preheat based on the stronger group. Using min(fy) in the resistance formula does not waive these conditions.
- A CJP gate needs actual joint preparation and full penetration, WPS/prequalified-or-qualified procedure, effective uninterrupted length, access/root/backing detail, execution and inspection specification. NBR 6.2.4.2 requires weld-metal Charpy 27 J at at most 4 °C for CJP T/corner joints with backing left in place. It also specifies heavy-section tensile-splice cases; do not silently omit applicable thick-material toughness requirements of 12.2.1.5.

### Compression contact

- Qualified contact is a distinct declared load path. NBR 6.6.3 assigns compression transfer through welds for non-machined surfaces.
- NBR 12.2.1.6/.8 permits suitable saw-cut preparation and gives plate-finishing exceptions; do not insist that every thin plate must be milled. Column ends require machining, with saw cutting an example, unless the CJP exception applies.
- Plates <=50 mm need satisfactory bearing but may be unplaned; (50,100] mm may be pressed or machined; >100 mm require machining except stated cases. Grouted lower faces need not be planed. The CJP exception does not certify a merely selected CJP detail.
- Numeric prepared-bearing capacity under 6.6.2 is 1.8*A_contact*min(fy_column,fy_plate)/1.35. A_contact is an actual qualifying area, not the plate footprint or an automatic full column area. Under moment, bearing and weld tractions need a joint equilibrium model.
- Missing bearing qualification means retain weld-carried compression demand or pending force path; never set compression demand to zero.

### Fillet geometry

- Table 11 minimum legs using the thinner part: <=6.3:3 mm; <=12.5:5; <=19:6; >19:8, subject to the table's single-pass note.
- Along an applicable free edge, maximum s=t for t<6.3; otherwise t-1.5 unless the actual reinforced detail is specified and feasible. A T-joint surface away from a free edge must not acquire an invented generic free-edge limit.
- Effective segment length >=40 mm and >=4s for the simple implementation; preserve both rules and do not silently increase capacity for a shorter segment.
- Long-weld reduction is conditional on nonuniform longitudinal transfer under 6.2.2.2(d), not a universal correction on every transversely loaded uplift segment. For an initial general longitudinal kernel, restricting L/s<=100 avoids the reduction. When implemented, beta=clamp(1.2-0.002 L/s,0.6,1), with Leff=180s when L>300s.
- Use actual flat accessible lengths and documented setbacks; no automatic radius/toe/return credit. Check plate shelf, root/access-hole geometry, washer/rod/stiffener interference, and weld terminations. Do not count a fillet and a CJP twice at the same joint.

## 6. Independent numerical fixtures and regression gates

`component_fixtures_v2.json` contains seven independent high-precision Decimal fixtures; no application imports were used:

1. CJP flange normal: R=490.909 kN, U=0.814815.
2. CJP web shear failure: R=283.636 kN, V=300 kN, U=1.057692.
3. Type 2 uplift strips: N=-300 kN, a2=120, tw=8, beff=112 mm; qz=669.642857 N/mm per face; s=6 E70 fillet R=914.524770 N/mm; U=0.732230. Web sigma=167.410714 MPa; supplementary strip thickness=25.690465 mm for plate fy=250.
4. Same given field with V=100 kN and Lw=250: qx=200 N/mm per face; resultant=698.871631 N/mm; fillet U=0.764191. This fixture does not approve combined plate-side transfer.
5. DG1 pure moment demand with NBR fillet resistance: F=293.289 kN; NBR R=269.104 kN; U=1.089875. Required leg=6.920705 mm, so the example's 1/4-inch fillet does not pass this deliberately different resistance convention.
6. CJP thinner-plate control: A_MB=1200 mm2, R=272.727 kN; no column-thickness shortcut.
7. Qualified compression-bearing/double-web shear: V_Rd=381.052 kN, U=0.262431 for V=100 kN, L=250 and s=5.

Regression gates: V-sign mirror; M-sign mirror where the force model supports M; actions at upper plate plane unchanged by lower shear-device choice; beff interval outside actual weld; missing column steel/procedure; incompatible filler; CJP web not doubled; wrong/absent contact preparation; active net-section holes; nonfinite dimensions; exact detailing thresholds; and no overall pass inferred from any passing component fixture.

## Sources

- Supplied corrected NBR 8800: printed pp.75–81 (6.2, Tables 8–11); pp.94–95 (6.5); p.98 (6.6.2/.3); pp.121–122 (12.2.1.5–.8); Table A.4 p.130. Table 9 PDF page 100 visually rechecked during this review.
- Supplied AISC DG1 3rd edition: 4.3.2 p.26; 4.3.4/.5 p.37; 4.5.1/.2 pp.53–54; Example 4.7-3 pp.71–73; Examples 4.7-5 and 4.7-8 web-shear checks; Example 4.7-9 p.114.
- Official AISC welding FAQ search result corroborates that fillet directionality has compatibility restrictions: https://www.aisc.org/aisc/solutions-center/engineering-faqs/8-welding/ . Direct page fetch returned 403; no additional design conclusion relies on that unavailable page.
