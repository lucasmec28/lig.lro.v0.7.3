# Emenda W convencional N/M/V revisão finita 0.9.14

## Correção normativa da mesa do membro

A NBR 8800:2024 corrigida com Er1:2025, 5.1.2.2.4(a), impressa38/PDF60, define b da mesa I/H/T como metade da largura total: b=bf/2. Na redução local pela 5.3.4/tabela4, Aef=bf tf−2(b−beff)tf=2 beff tf. Não se acrescenta tw tf. O χ=1 desta tela local não calcula a estabilidade global Nc,Rd. As larguras AA entre linhas de parafusos e AL de borda livre à primeira linha, próprias das talas, ficam inalteradas.

Testemunha declarada W personalizada: d308, bf305, tw9.9, tf8, clear258, A7770.8 mm², fy250 MPa, oito linhas por lado, N−1 MN, M=V=0. Cada mesa recebe500 kN. b152.5 mm, beff137.37851217177902 mm, Aef2198.0561947484643 mm²; R499558.22607919644 N; η1.000884329188753. Ambas as telas locais efetivas falham. Não se afirma produto de catálogo, colapso nem estabilidade global.

## Modelo e fontes mantidos

Fakury et al., parte4, §10.14.7, impressas310–320, PDF57–67 da parte4 recuperada. As páginas314,315,317 foram inspecionadas no audit, além da leitura da seção. pp.311–312: N/M integralmente nas mesas e V/Ve na alma;313–314: apoio por filas, caso fonte K0.65;315–318: blocos L/U, Cts0.5, V/2 e flexão líquida;318–319: grupo excêntrico/contato;320: talas externas e internas, reverificação do membro e serviço. Coeficientes NBR2008 e Q históricos não substituem as regras atuais NBR2024/Er1:2025.

Duas externas, quatro tiras internas e duas talas de alma, membros idênticos/coaxiais. Ftop=N/2−M/(d−tf); Fbottom=N/2+M/(d−tf). bo=2bi com mesmo material/espessura define a especialização atual de partilha igual: externaF/2 e cada internaF/4. Não é requisito universal NBR. Peças e lados em série, sem soma de capacidade ou crédito de contato de topo.

Mantidos: compressão assinada, reversões M/V, casos reais e suplementares separados, piso45kN na resultante N/V independente de M, 84 caminhos reais por tala, malha regular2×3, grupo vetorial e bordas reais, estabilidade de cada tira em dois eixos e torção, intervalo máximo entre linhas portantes/K1, área efetiva atual, FLT retangular, seção líquida integrada com furo central, telas adicionais conservadoras declaradas e gradiente do membro M−Vx. PureM não cria direção de força fictícia. Fora do domínio escalar exato, a pendência específica preserva os demais valores calculáveis.

Capacidades globais externas são opcionais e vinculadas exatamente ao caso; não se inferem de talas. Serviço/deslizamento, rigidez de pórtico, sistema, montagem e excluídos topológicos permanecem externos. Não há whitelist de catálogo, caixa fictícia, novo pré-requisito genérico de FEA, extensão desigual ou nova família.

## Integridade de entrada e artefatos

O carregador valida toda a representabilidade antes de alterar projeto ou memória. HP, materiais/parafusos desconhecidos, diâmetro não listado, dimensões inferiores aos controles e conversão que zeraria ação não nula são rejeitados com campo/valor/motivo. Domínios diagnósticos preservados não são corrigidos silenciosamente. Valores decimais suportados e o W personalizado permanecem disponíveis.

Valores de engenharia aceitos e valores exibidos têm registro separado. Se o controle não mudar, usa-se o valor original exato, inclusive identidade inteiro/float relevante ao vínculo. Edição real atualiza só aquele valor e mantém o vínculo anterior, que passa a obsoleto. Não há tolerância nem revinculação automática. Rascunho personalizado com raiz é separado do perfil ativo de catálogo.

Cada Word/SVG usa avaliação nova da entrada atual. Cópias caller-controlled de inputs, PASS, contagem ou linhas não autorizam a conclusão. Snapshot desatualizado/adulterado é descartado. Projeto, torção e status atual acompanham o desenho avulso. JSON da UI nasce da mesma entrada aceita; nenhuma conclusão é importada como autoridade.

## Envelopes de apresentação e estados

Os envelopes atribuem cada linha primitiva exatamente uma vez a componente físico/mecanismo, atravessando casos reais, suplementares e pisos. Escolhem o máximo índice e retêm a linha completa: demanda, resistência, unidade, fórmula, fonte, detalhes/caminho e caso. Não envelopam demanda/resistência separadamente nem aumentam capacidade. IDs de peças e todos os membros do grupo permanecem no JSON e todas as primitivas no detalhe da tela/Word.

Simetria das talas de alma, planos iguais, razões de tração externa/interna e dominância local bruta/efetiva permitem reduzir repetição visual. Compressão de externa e tira, contato vetorial/tela x-y, bloco, FLT e interação não são trocados entre si. Bruto/líquido da alma ficam dentro da tela líquida conservadora que os limita; a tela não vira lei normativa de fratura combinada. No exemplo649 linhas→29 envelopes; duas ações mais dois pisos mantêm2596 linhas. Toda enumeração84permanece, inclusive ponte menor que passo.

Demanda nula é NOT_APPLICABLE com resistência rastreável, não aprovação independente. Todos os casos nulos continuam NOT_EVALUATED. Entrada malformada, geometria impossível, detailing, domínio de método, pré-requisito/serviço, resistência finita e NUMERICAL_FAILURE têm estados/categorias próprios. Falhas resistentes finitas permanecem explícitas com pendências não relacionadas. A impossibilidade numérica não impõe teto genérico de carregamento nem vira sobrecarga física ordinária.

## Limites de validação

Validação delimitada aos34casos independentes/121408comparações, testemunha esbelta e sua fronteira local, casos reais AppTest, artefatos diretos falsificados e regressões compartilhadas pertinentes. AppTest não é evidência de pixels de navegador. Renderização Word é documentada separadamente. A revisão não certifica a suíte inteira nem outra família. Exemplos anteriores guardam a versão histórica; novas avaliações usam a revisão vigente.
