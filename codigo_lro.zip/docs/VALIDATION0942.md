# Validação composta 0.9.42

6091 casos distintos cobertos, com 6090 resultados aprovados após as etapas descritas e uma falha histórica não resolvida. Não é uma execução única da árvore final de testes emendada.

A execução integral original terminou com 6089 aprovados e duas falhas. Uma é o FileNotFoundError pelo oráculo externo original bolt_bearing_oracle.json ausente. A outra era uma asserção textual que proibia qRd até na frase que explicitamente exclui a resistência da garganta como qualificação do metal-base. O histórico original permanece intacto.

Após revisão independente, somente esse teste foi emendado para permitir exatamente a ressalva e continuar proibindo resistências/demandas inventadas em equações e outros textos. Todo o módulo de sete casos foi reexecutado: sete aprovados. Os sete casos repetidos substituem os respectivos resultados na visão final e não aumentam a contagem distinta. Runtime e dados foram idênticos em todas as etapas; a única diferença da árvore de testes está registrada por hashes antes/depois. Zero erros e zero pulados nas duas etapas.

As revisões independentes e replays possuem contagens separadas. End plate recebe apresentação separada sem nova qualificação física. A chapa receptora recebe somente escoamento à flexão da seção bruta no domínio declarado; furos, transferência completa e metais-base permanecem pendentes. Favorável não significa ligação completa.

O fonte 0.9.41 permanece imutável. Este congelamento não é aprovação de pacote, implantação, fabricação ou projeto real. O APP efetivamente distribuído recebe gates separados de carregador, rotas e reprodução.
