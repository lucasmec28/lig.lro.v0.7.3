"""Portable exact-current 1L artifact replay, without external review dependencies."""
from pathlib import Path
from dataclasses import replace
import argparse,hashlib,json,sys,os
from zipfile import ZipFile
p=argparse.ArgumentParser();p.add_argument('--source-root',required=True,type=Path);p.add_argument('--out',required=True,type=Path);a=p.parse_args();S=a.source_root.resolve();O=a.out.resolve();assert O!=S and not O.is_relative_to(S);O.mkdir(parents=True,exist_ok=True);sys.path.insert(0,str(S));sys.dont_write_bytecode=True
from lro.models import VERSION
from lro.welded_support_single_angle import WeldedSupportSingleAngle,evaluate,presets,COMPONENT_VERSION
from lro.welded_support_single_angle_drawing import image_bytes
from lro.welded_support_single_angle_report import create_report
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,sort_keys=True,indent=2,allow_nan=False)+'\n')
runtime={p.relative_to(S).as_posix():sha(p) for p in [S/'app.py',*(S/'lro').glob('*.py'),*(S/'data').glob('*')] if p.is_file()}
base=next(iter(presets().values()));cases={'default':base,'overload':replace(base,V=250000.),'minimum':replace(base,V=12000.123456),'zero':replace(base,V=0.),'upward':replace(base,V=-90000.),'external_N':replace(base,N=1e-9),'root_radius_zero':replace(base,root_radius=0.,beam_gauge=40.),'hardware_below_floor':replace(base,tool_radius=10.,beam_gauge=36.),'hardware_floor_insufficient_access':replace(base,tool_radius=21.,beam_gauge=36.)}
expected={'default':'COMPLETE_CHECKS_PASS_WITHIN_SCOPE','overload':'VERIFIED_SUBCHECK_FAIL','minimum':'COMPLETE_CHECKS_PASS_WITHIN_SCOPE','zero':'OUTSIDE_SUPPORTED_SCOPE','upward':'OUTSIDE_SUPPORTED_SCOPE','external_N':'OUTSIDE_SUPPORTED_SCOPE','root_radius_zero':'ENGINEERING_MODEL_PENDING','hardware_below_floor':'ENGINEERING_MODEL_PENDING','hardware_floor_insufficient_access':'ENGINEERING_MODEL_PENDING'}
rows=[]
for name,c in cases.items():
 d=O/name;d.mkdir(exist_ok=True);r=evaluate(c);native=c.to_dict();assert WeldedSupportSingleAngle.from_dict(native)==c;assert r['status']==expected[name],(name,r['status']);assert not r['global_pass'] if name not in ('default','minimum') else r['global_pass'];save(d/'project.json',native);save(d/'result.json',r)
 if name in ('default','overload','root_radius_zero'):
  for fmt in ('png','svg'):(d/('drawing.'+fmt)).write_bytes(image_bytes(c,fmt=fmt))
  if name=='default':
   report=create_report(c,{'global_pass':True,'status':'FORGED_CACHED_RESULT'});(d/'report.docx').write_bytes(report)
   with ZipFile(d/'report.docx') as z:
    document=z.read('word/document.xml').decode();assert 'FORGED_CACHED_RESULT' not in document and r['status'] in document and '<m:oMath' in document
 rows.append({'case':name,'status':r['status'],'global_pass':r['global_pass'],'input_roundtrip_exact':True,'files':{p.relative_to(O).as_posix():sha(p) for p in d.iterdir() if p.is_file()}})
assert all(sha(S/n)==h for n,h in runtime.items());save(O/'SINGLE_ANGLE_REPLAY.json',{'status':'PASS','version':VERSION,'component_version':COMPONENT_VERSION,'cases':rows,'runtime_sha256':runtime,'runtime_unchanged':True,'limits':'Current local numerical/artifact replay. Out-of-domain native values remain intact; no fabrication or global structural approval.'});print('PASS_SINGLE_ANGLE_CURRENT_REPLAY',len(rows))
