"""Read-only final combined Word review; writes evidence and renders only here."""
from pathlib import Path
from zipfile import ZipFile
import os, sys, json, hashlib, subprocess, concurrent.futures, datetime, re
import xml.etree.ElementTree as ET
import fitz
W=Path('/workspace/scratch/200bd23c4a9b'); R=W/'review0943'; S=R/'source0943'; O=R/'final_combined_word0943'
OLD='0.9.42-result-indices-base-key-plate-dev'; NEW='0.9.43-welded-support-angles-dev'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
bsha=lambda b:hashlib.sha256(b).hexdigest()
def save(name,v): (O/name).write_text(json.dumps(v,indent=2,ensure_ascii=False,sort_keys=True)+'\n')
def run(cmd): return subprocess.check_output(cmd,text=True,stderr=subprocess.STDOUT).strip()
ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main','m':'http://schemas.openxmlformats.org/officeDocument/2006/math','a':'http://schemas.openxmlformats.org/drawingml/2006/main'}
FILES={'single_default':'single/default/report.docx','double_default':'double/default.docx','pinned_compact':'endplate/pinned/compact.docx','mre_compact':'endplate/mre12_u/compact.docx','mre_detailed':'endplate/mre12_u/detailed.docx','base_positive_full':'base/deep_key_positive_full.docx','base_negative_full':'base/deep_key_negative_full.docx'}
RENDERER=Path('/home/agent/.codex/skills/builtins/documents/render_docx.py')

def docx_info(p):
 with ZipFile(p) as z:
  assert z.testzip() is None
  members={n:bsha(z.read(n)) for n in sorted(z.namelist())}
  root=ET.fromstring(z.read('word/document.xml')); text='\n'.join(e.text or '' for e in root.findall('.//w:t',ns))
  fonts=set()
  for n in z.namelist():
   if n.startswith('word/') and n.endswith('.xml'):
    rr=ET.fromstring(z.read(n))
    for el in rr.findall('.//w:rFonts',ns):
     fonts.update(v for k,v in el.attrib.items() if k.rsplit('}',1)[-1] in ('ascii','hAnsi','cs','eastAsia'))
  return {'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size,'decompressed_members_sha256':members,'editable_omml_equations':len(root.findall('.//m:oMath',ns)),'structured_fractions':len(root.findall('.//m:f',ns)),'drawings':len(root.findall('.//w:drawing',ns)),'media_members':{n:h for n,h in members.items() if n.startswith('word/media/')},'declared_fonts':sorted(fonts),'version_present':NEW in text,'document_text_sha256':bsha(text.encode())}

def compare_old():
 rows={}
 for kind in ('endplate','base'):
  oldroot=W/'review0942/current_examples'/kind
  for old in sorted(oldroot.rglob('*.docx')):
   rel=old.relative_to(W/'review0942/current_examples'); new=R/'current_examples'/rel
   with ZipFile(old) as a, ZipFile(new) as b:
    aa=set(a.namelist());bb=set(b.namelist());diff=[];normalized=[];hashes={}
    for n in sorted(aa&bb):
     av,bv=a.read(n),b.read(n)
     h={'old_sha256':bsha(av),'new_sha256':bsha(bv)}
     if av!=bv:
      if av.replace(OLD.encode(),NEW.encode())==bv: normalized.append(n);h['version_only']=True
      else: diff.append(n);h['version_only']=False
     hashes[n]=h
    rows[str(rel)]={'old_docx_sha256':sha(old),'current_docx_sha256':sha(new),'old_path':str(old),'current_path':str(new),'members_added':sorted(bb-aa),'members_removed':sorted(aa-bb),'version_only_members':normalized,'unexplained_changed_members':diff,'exact_after_version_only_normalization':not (aa^bb or diff),'members':hashes}
 save('PRESERVATION_MEMBERS.json',{'allowed_normalization':{'old':OLD,'new':NEW,'method':'Literal byte replacement in decompressed members only. No XML reserialization, timestamp, whitespace, numeric, warning or media normalization.'},'documents':rows,'all_exact':all(v['exact_after_version_only_normalization'] for v in rows.values())})
 return rows

def identity():
 dep=Path(os.environ['CODEX_PRIMARY_RUNTIME'])/'dependencies';soffice=dep/'native/libreoffice-headless/libreoffice/program/soffice.bin'
 env=os.environ.copy();env['XDG_CACHE_HOME']=str(O/'cache');(O/'cache').mkdir(exist_ok=True)
 inventory={}
 for p in subprocess.check_output(['fc-list','-f','%{file}\n'],text=True,env=env).splitlines():
  if Path(p).is_file():inventory[p]=sha(p)
 objects={'python':Path(sys.executable).resolve(),'renderer':RENDERER,'soffice_binary':soffice,'soffice_wrapper':dep/'bin/override/soffice','pdftoppm_wrapper':dep/'bin/override/pdftoppm','pdfinfo_wrapper':dep/'bin/override/pdfinfo'}
 return {'python_version':sys.version,'files':{k:{'path':str(p),'sha256':sha(p)} for k,p in objects.items()},'soffice_version':run([str(dep/'bin/override/soffice'),'--version']),'font_files_sha256':inventory,'font_inventory_count':len(inventory),'environment':{'CODEX_PRIMARY_RUNTIME':os.environ.get('CODEX_PRIMARY_RUNTIME'),'PYTHONPATH':os.environ.get('PYTHONPATH'),'FONTCONFIG_FILE':os.environ.get('FONTCONFIG_FILE'),'FONTCONFIG_PATH':os.environ.get('FONTCONFIG_PATH')}}

def render(item):
 name,rel=item;p=R/'current_examples'/rel;out=O/name;out.mkdir(exist_ok=True)
 cmd=[sys.executable,str(RENDERER),str(p),'--output_dir',str(out),'--emit_pdf']
 env=os.environ.copy();env['XDG_CACHE_HOME']=str(O/'cache');env['PYTHONDONTWRITEBYTECODE']='1'
 proc=subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env=env)
 (O/(name+'.log')).write_text(proc.stdout)
 assert proc.returncode==0,(name,proc.stdout)
 pdf=out/(p.stem+'.pdf'); d=fitz.open(pdf);pages=[];outliers=[];fonts=set()
 for i,page in enumerate(d,1):
  txt=page.get_text();pagepath=out/f'page-{i}.png';assert pagepath.is_file()
  (out/f'page-{i}.txt').write_text(txt)
  for b in page.get_text('dict')['blocks']:
   for line in b.get('lines',[]):
    for span in line.get('spans',[]):
     box=span['bbox']
     if box[0]<-.5 or box[1]<-.5 or box[2]>page.rect.width+.5 or box[3]>page.rect.height+.5:outliers.append({'page':i,'text':span['text'],'box':box})
  fonts.update(f[3] for f in page.get_fonts())
  pages.append({'page':i,'png_path':str(pagepath),'png_sha256':sha(pagepath),'text_sha256':bsha(txt.encode()),'text_chars':len(txt.strip()),'width_pt':page.rect.width,'height_pt':page.rect.height})
 result={'docx_path':str(p),'docx_sha256':sha(p),'pdf_path':str(pdf),'pdf_sha256':sha(pdf),'page_count':len(d),'pages':pages,'text_spans_outside_page':outliers,'blank_text_pages':[v['page'] for v in pages if v['text_chars']==0],'pdf_font_names':sorted(fonts),'command':cmd}
 save(name+'_RENDER.json',result);print(name,len(d),flush=True);return name,result

if __name__=='__main__':
 assert '--run' in sys.argv,'Only run after parent confirms held runtime and current outputs.'
 hold=R/'RUNTIME_TEST_HOLD0943.json';h=json.loads(hold.read_text());assert h['version']==NEW
 assert all(sha(S/n)==v for n,v in h['files'].items()),'Runtime/test hold mismatch'
 before={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'version':NEW,'runtime_test_hold_path':str(hold),'runtime_test_hold_sha256':sha(hold),'runtime_test_files':h['files'],'source_root':str(S),'runtime_identity':identity(),'documents':{name:docx_info(R/'current_examples'/rel) for name,rel in FILES.items()},'preservation_docx':{str(p.relative_to(R/'current_examples')):sha(p) for kind in ('endplate','base') for p in (R/'current_examples'/kind).rglob('*.docx')},'prior_receipts':{str(p):sha(p) for p in [W/'review0942/final_combined_word0942/FINAL_COMBINED_WORD_RECEIPT.json',W/'review0942/final_combined_base_word0942/WORD_REVIEW_RECEIPT.json',W/'welded_support_1l0943/FINAL_RECEIPT.json',W/'welded_support_2l0943/FINAL_RECEIPT.json']}}
 save('INPUT_BINDING.json',before)
 comparisons=compare_old();print('PRESERVATION',len(comparisons),all(v['exact_after_version_only_normalization'] for v in comparisons.values()),flush=True)
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=dict(pool.map(render,FILES.items()))
 save('RENDERED_DOCUMENTS.json',results)
 assert all(sha(S/n)==v for n,v in h['files'].items()),'Source changed during review'
 assert all(sha(v['path'])==v['sha256'] for v in before['documents'].values()),'DOCX changed during review'
 print('RENDER_AND_STRUCTURAL_REVIEW_READY',flush=True)
