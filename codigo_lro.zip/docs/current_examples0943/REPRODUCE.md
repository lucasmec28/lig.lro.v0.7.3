# Exemplos atuais 0.9.43

Os quatro scripts recebem a fonte atual e uma pasta de saída separada. O wrapper fixa apenas a data SVG e a semente dos identificadores gráficos; cálculos, entradas, decisões e valores não são normalizados.

python docs/current_examples0943/replay_wrapper.py docs/independent_result_indices0942/replay_current_examples.py --source-root . --out /saida/endplate --ui
python docs/current_examples0943/replay_wrapper.py docs/independent_base_key_plate0942/run_app_only.py . /saida/base
python docs/current_examples0943/replay_wrapper.py docs/current_examples0943/replay_single_angle.py --source-root . --out /saida/single
python docs/current_examples0943/replay_wrapper.py docs/current_examples0943/replay_double_angle.py --source-root . --out /saida/double

O gerador2L original artifact_qa/generate_artifacts.py também foi preservado, com opção para os seis documentos completos. O replay de release publica o documento padrão e nativos/resultados dos casos adversos. Os nativos e resultados ficam no APP; as renderizações de exemplo ficam no arquivo opcional EXEMPLOS. JSON/PNG/SVG são comparados por bytes. DOCX é comparado por todos os membros descompactados, desconsiderando apenas timestamps do contêiner ZIP. Os testes de UI verificam callbacks, importação atômica e invalidação de resultados anteriores. AppTest não é qualificação visual de navegador.

Estes exemplos não aprovam fabricação ou o sistema estrutural. Na2L o estado provisório e liberação do içamento permanecem não verificados.
