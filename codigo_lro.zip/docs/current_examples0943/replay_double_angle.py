"""Portable current2L default artifacts and explicit adverse native-state replays."""
from pathlib import Path
from dataclasses import replace
import argparse,hashlib,json,sys,runpy
p=argparse.ArgumentParser();p.add_argument('--source-root',required=True,type=Path);p.add_argument('--out',required=True,type=Path);a=p.parse_args();S=a.source_root.resolve();O=a.out.resolve();assert O!=S and not O.is_relative_to(S);O.mkdir(parents=True,exist_ok=True);sys.path.insert(0,str(S));sys.dont_write_bytecode=True
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,sort_keys=True,indent=2,allow_nan=False)+'\n')
runtime={p.relative_to(S).as_posix():sha(p) for p in [S/'app.py',*(S/'lro').glob('*.py'),*(S/'data').glob('*')] if p.is_file()}
gen=S/'artifact_qa/generate_artifacts.py';sys.argv=[str(gen),'--source',str(S),'--output-dir',str(O),'--default-only'];runpy.run_path(str(gen),run_name='__main__')
from lro.models import VERSION
from lro.welded_support_double_angle import WeldedSupportDoubleAngle,evaluate,presets,COMPONENT_VERSION
base=next(iter(presets().values()));cases={'default':base,'high_load':replace(base,V=500000.,project='2L · resistência não atendida'),'reverse_load':replace(base,V=-100000.,project='2L · V ascendente fora do domínio'),'field_weld_access_pending':replace(base,weld_tool_radius=100.,project='2L · envelope de soldagem pendente'),'zero_radius_pending':replace(base,root_radius=0.,project='2L · raio interno pendente'),'wrong_assembly':replace(base,assembly='both_shop_welded',project='2L · montagem fora do domínio')}
expected={'default':'COMPLETE_CHECKS_PASS_WITHIN_SCOPE','high_load':'VERIFIED_SUBCHECK_FAIL','reverse_load':'OUTSIDE_SUPPORTED_SCOPE','field_weld_access_pending':'ENGINEERING_MODEL_PENDING','zero_radius_pending':'ENGINEERING_MODEL_PENDING','wrong_assembly':'OUTSIDE_SUPPORTED_SCOPE'};rows=[]
for name,c in cases.items():
 r=evaluate(c);native=c.to_dict();assert WeldedSupportDoubleAngle.from_dict(native)==c;assert r['status']==expected[name],(name,r['status']);assert r['global_pass']==(name=='default');assert r['load_model']['temporary_stage_verified'] is False if r.get('load_model') else not r['global_pass']
 if name=='default':assert json.loads((O/'default.json').read_text())==native and json.loads((O/'default.result.json').read_text())==json.loads(json.dumps(r,allow_nan=False))
 else:save(O/(name+'.json'),native);save(O/(name+'.result.json'),r)
 rows.append({'case':name,'status':r['status'],'global_pass':r['global_pass'],'input_roundtrip_exact':True,'temporary_stage_verified':False,'files':{p.relative_to(O).as_posix():sha(p) for p in O.glob(name+'.*') if p.is_file()}})
assert all(sha(S/n)==h for n,h in runtime.items());save(O/'DOUBLE_ANGLE_REPLAY.json',{'status':'PASS','version':VERSION,'component_version':COMPONENT_VERSION,'cases':rows,'runtime_sha256':runtime,'runtime_unchanged':True,'generator_path':'artifact_qa/generate_artifacts.py','generator_sha256':sha(gen),'limits':'Current-input final-state local artifacts. Hoisting and intermediate assembly remain unverified; no fabrication or global structural approval.'});print('PASS_DOUBLE_ANGLE_CURRENT_REPLAY',len(rows))
