"""Deterministic rendering wrapper; applies no engineering or expected-value changes."""
import os,runpy,sys
os.environ['SOURCE_DATE_EPOCH']='0'
import matplotlib
matplotlib.rcParams['svg.hashsalt']='lro0943-final-output-replay'
path=sys.argv[1];sys.argv=sys.argv[1:];runpy.run_path(path,run_name='__main__')
