# Pinned baseplate: verified native model

## Result and files

Implemented independent four-interior-anchor NBR Type 2 in `connections_work086/source/lro/pinned_base_plate.py`. It shares peripheral component kernels but has its own geometry, reaction solver, uplift yield-line equation, validation, identity and serialization. Frozen085 was not edited.

- Tests: `connections_work086/source/tests/test_pinned_base_plate.py`: 26 pass.
- Independent fixtures: `connections_work086/source/tests/fixtures/pinned_baseplate_benchmarks.json`, five numerical cases.
- Independent generator: `tmp/baseplate-review/generate_pinned_benchmarks.py`; no production imports.
- Initial focused regression, pinned/base_plate/concrete_anchorage/anchor_native: 137 passed.

## Verified source evidence

User-supplied corrected NBR8800 PDF: errata p2 replaces Figure21 with external Type1 and four-interior Type2. NBR6.7.1.4, printed101/physicalPDF123, explicitly limits Type2 to C1/C2/T1/T2. NBR6.7.2.1, printed102-103/PDF124-125, defines geometry and nb=4 for Type2. NBR6.7.2.2(d), printed106/PDF128, supplies a distinct Type2 plate-uplift expression, reused for maximum T2 rod force by item(e). NBR6.7.2.3-5, printed107-109, supplies the three shear routes. Corrected Table18 is errata pp3-4; use it instead of the original printed104 table.

Industrial `PADRÃO DE LIGAÇÕES-4Model.pdf`, inspected visually: B-001 drawingp59 is external multirow/stiffened. B-002 p60 is two interior rods. B-003 p61 is four interior rods in a square pattern and is the proper initial geometric precedent. B-001 must not be relabeled pinned. B-003's free H/B and 2A dimensions are reference geometry, not proof of capacity or stiffness.

DG1 third edition4.3.2, printed26-27, requires a consistent column/weld/plate/rod/concrete load path and permits web cantilever or compatible two-way analysis for interior rods. Example4.7-3 pp70-73 uses four interior rods in a4in square and a web cantilever model. It corroborates a practical four-rod layout but does not justify replacing NBR material factors. Two rods are real (B-002), not prohibited generally; they require a separate model from NBR's explicit nb=4 Type2.

## Geometry and identity

Coordinates x along column depth and y along flange width. Centered I/H, unstiffened rectangular plate, four rods `(±a2/2,±a2/2)`. Thus a=a2/2, NOT L/2−a1. L=d+4a1 and B=a2+2a1≥bf+25mm. Effective internal length l0=min[d,a2+1.75(a2−tw)], respecting the source's upper bound without inventing an exclusion of wide sections.

Actual washers must fit beside web, between inner flange faces, inside plate edges, apart from adjacent washers and clear of specified weld toes. Four-edge washer welds also need their actual shelf. Physical interference is invalid geometry, never auto-corrected.

Pinned dataclass exposes N and V only. M is immutable0, absent from JSON and forbidden on import even if0. `connection_type=base_plate_pinned`, schema2. Legacy external bases retain geometry and any M in their own family; they are never converted by discarding M. The chosen pinned global idealization is not a demonstrated rotational hinge/stiffness/rotation capacity.

## Corrected Table18 nuance

Errata p4 note(f) permits a1 between10mm and tabulated value ONLY in the L/x direction. The transverse a1 is not covered by that relaxation. This initial implementation has one a1 in both directions; if it differs from the table, detail remains pending, not falsely described as the permitted longitudinal reduction. Introducing an independent longitudinal projection later could use that permission without changing transverse edge distance.

Note(g): Type2 minimum plate-edge→block-face margin=a3_table−a1_table, BOTH from the table. Do not use a reduced/chosen a1 here. For1in rod margin160−50=110mm. Corrected reference dimensions: Nb=max(Nb,min,L+2en,L+2margin), Bb=max(B+2en,B+2margin), Ab=max(h1+100,Nb). Block/reinforcement still need NBR6118 design. `matches_spacing` requires both a1 and a2 to match the tabulated arrangement; departures still allow mechanics with explicit pending detailing.

Fixture tabulated package: db25.4mm; a1=50,a2=100,df45,washer75×75×8; ASTM A36 rods, washerfy345, fck_min25. On d300,bf150,tw8,tf12 this is truly interior and fits.

## N/V equilibrium and plate/steel equations

Internal N/mm/MPa, factored N>0 compression. gamma_a1=1.10,gamma_a2=1.35,gamma_c=1.40. s=0.85fck/gamma_c, no confinement credit; F=fy/gamma_a1. m=(L−0.95d)/2,n=(B−0.80bf)/2,n0=sqrt(d bf)/4. X=[4d bf/(d+bf)^2]P/(LBs), requireX≤1; lambda=min[1,2sqrt(X)/(1+sqrt(1−X))].

Compression P=N>0:
- C1:Mlocal0,C=P,lc=L,sigma=P/(LB),rodT0.
- C2:e=abs(Mlocal)/P≤(L−P/(sB))/2; lc=L−2e,C=P,sigma=P/(Blc),rodT0.
- If lc≥m,lmax=max(m,n,lambda n0); otherwise lmax=max(sqrt[lc(2m−lc)],n). t_contact=lmax sqrt(2sigma/F).
- RejectP>sLB. BeyondC2 local moment requiresC3, outside nativeType2. Never substitute exterior formulas.

Uplift U=−N>0:
- T1:Mlocal0,eachFt=U/4,C0.
- T2:e=abs(Mlocal)/U≤a. Two rods atx=−sign(Mlocal)a carry Ftmax=U/4+abs(Mlocal)/(4a); other two Ftmin=U/4−abs(Mlocal)/(4a). No contact. At e=a the zero-tension row is excluded from active cone groups.
- Interior plate t_tension=sqrt[4Ftmax(a2−tw)/(l0F)], NOT external2nbFt(m−a1)/(BF).
- Steel Ft,Rd=0.75(pi db²/4)400/gamma_a2; db,min=sqrt[4Ftmax/(0.75pi(400/gamma_a2))]. No concrete strength implied.
- e>a needsT3 and is unsupported; N0 with nonzeroMlocal also needs simultaneous tension/contact outside these cases. N=Mlocal0 avoids division by zero and invents no normal resistance.
- Calculate force/moment residuals using actual C and rod locations; V sign reversal mirrors the lug-loaded side.

## Three shear paths and local moment

1. Friction on qualified expansive grout: VRd=min(0.45C/gamma_a2,tauLB),tau=min(0.2fck/gamma_c,4MPa). T1/T2 have C0 and zero friction. Follow native NBR contact idealization.
2. Four anchors with welded special washers and standard holes: NBR6.7.2.5 uses actual Type2 per-rod T and coordinates. Local bendingtp+ta/2 already entersalpha; do not add another automaticVtp on this top-reference detail. Current kernel usesFtmax for ambiguous printed subtrahend index as a conservative envelope, plus independent6.3.3.4 steel interaction. Oversized base holes alone do not mobilize equal shear. Individual washer weld design demand is unreducedFv,Rd, notV/4. Local washer results remain partial.
3. Key/documented device: fullV alone, no addition to friction. Rectangular key eV=tp+(bv+en)/2, Mlocal=VeV, signed, derived internally once. Active cruciform/W variants use actual active contact height and existing verified component kernels. This can moveC1→C2,T1→T2, or exceed the nativeType2 domain. Unknown documented-device reaction geometry must be explicitly covered in its external memory; scalar capacity alone does not eliminate an unknown lever.

Rectangular key: sigma_lug=1.7fck/gamma_c; bearingRd=sigma_lug bh(bv−en); tkey,min=sqrt[2abs(V)(bv+en)/(bh fy_key/gamma_a1)]; tkey≤tplate. Normative weld demands Vw=bearingRd,Mw=Vw(bv+en)/2 are distinct from the overall foundation-transfer lever. Local key checks do not approve welds/concrete/block.

## Cone mapping

Reuse only the pure ACI318-19/DG1 group kernel with actual interior rod coordinates and concurrent tension. C1/C2 have no demanded tension cone, not a cone pass. T2 uses all positive rods and actual resultant eccentricity; at e=a only two rods are active. Never blindly useU/4, exterior coordinates or sum isolated capacities.

Existing complementary limits remain: cast-in mechanical head/nut/plate, intact cracked normalweight concrete, real free edges and hef, phi0.70 ConditionB, no second NBRgamma. Optional subset envelope stays explicit and separate. Tension cone does not cover pullout/shear/pryout/interaction/etc.

## Five independent numerical fixtures

Common d300,bf150,tw8,tf12,a1=50,a2=100,L500,B200,a50,l0=261mm; fy250,fck30MPa; db25.4,tp25.4mm. Lugbh200,bv150,en40→eV120.4mm. Washer75×75×8mm. These test mechanics, not whole-design approval.

1.C1 friction,N400000N,V100000N: Mlocal0,lc500,sigma4MPa,t_req20.1687877672mm,C400000N,T0,frictionRd133333.333333N.
2.T1 washer shear,N−100000N,V20000N: eachFt25000N,t_req12.4537458397mm,contact/friction0. Interior conehef250 with distant edges: area722500mm²,area0=562500mm²,phiNcb195511.179823N.
3.C2 lug,N400000N,V100000N: Mlocal12040000Nmm,e30.1mm,lc439.8mm,t_req21.5048880301mm,T0.
4.T2 lug,N−100000N,V20000N: Mlocal2408000Nmm,e24.08mm,Ftmax37040N,Ftmin12960N,t_req15.1588230318mm; conepsi_ec=1/(1+24.08/375),phiNcb183714.273915N. EqualU/4 mapping would overstate cone strength.
5.C2 boundary,N400000N,Vselected forMlocal78039215.6862745Nmm: e195.0980392157mm,lc109.8039215686mm,sigma18.2142857143MPa,t_req43.0383757328mm. Greater local moment must reject. HighV/key checks can fail; this is an equilibrium boundary, not a passing design.

Independent DG1 corroboration:17.5kip/rod,g4in,tw0.350in→a1.825in,beff3.650in,Fy50ksi,phi0.90→t=sqrt[4ra/(beff phi Fy)]=0.8819171in, matching published rounded0.882in. Separate AISC example, not NBR rule.

## Precise pending checks

- Column-to-plate welds/base metal, effective web/flange force path, local web strength.
- Key-to-plate local bending and transfer; coupled washer/plate bending and prying where significant; fabrication/weld access/tolerances.
- Anchor pullout, blowout, splitting, shear breakout, pryout, tension/shear interaction; buried head/nut/plate local resistance.
- Key welds/base metal, concrete breakout/reinforcement, pedestal/footing/block perNBR6118 and erection-stage design.
- Rotational stiffness/rotation capacity/global-model consistency; biaxial,torsion,cyclic/seismic,fatigue,fire outside release.
- FinalUI/report QA: no appliedM field, independent drafts/JSON, actual interior coordinates in each view, Type2 equation, signed derived local moment, corrected detailing, clear partial-result status.
