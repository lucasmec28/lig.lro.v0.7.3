# Validação da fonte 0.9.37

GO da fonte para o ramo local delimitado, com a indisponibilidade histórica explicitamente preservada. A suíte integral executou **5566 casos distintos: 5565 aprovados, 1 falha, 0 erros, 0 pulados**, em quatro grupos disjuntos, com os mesmos bytes de runtime e testes antes e depois. A única falha depende do arquivo externo original next_connection_scope/bolt_bearing_oracle.json, ainda ausente; não foi inventado nem contado como aprovado.

Os 344 testes focados finais e 48 testes de UI anterior/atual sobrepõem a suíte. As 13 categorias de revisão independente do motor, 177 geometrias, 6 mutações detectadas, estados de paridade, callbacks e páginas renderizadas são unidades diferentes, não uma soma adicional de testes. Receipts e hashes detalhados estão no JSON de validação e nos diretórios independent_engine0937, independent_outputs0937 e validation0937.

SRC1 mantém a geometria original, somente com o sinal de 200 kN invertido. Continua com falha física de escoamento η = 1,079466667 e vínculos reais não verificados. A resistência condicional da faixa, 556,476924 kN, não aprova o detalhe. Nenhum vão, travamento ou segundo apoio foi fabricado. Os cenários de declaração completa são sintéticos e verificam somente as fórmulas.

A revisão encontrou e encerrou um caminho Whitmore matematicamente nulo que arredondava positivo, uma representação incorreta de Le no Word, um Ct tracionado residual na tabela detalhada e um rodapé de desenho sem faixa qualificada. Reproduções, versões exploratórias e renders foram preservados; não são recontados como resultados finais. A fonte anterior 0.9.36 e suas 1604 entradas entregáveis foram conferidas sem alteração. A correção de interpretação NBR aplica a Errata 1, PDF 1; não reescreve a evidência histórica.

Esta aceitação é de fonte. Não comprova pacote APP extraído, upload, publicação, deploy ou fabricação. O build isolado e as revisões APP-only são a próxima etapa autorizada condicionalmente após este GO da fonte. A indisponibilidade histórica não impede os checks novos independentes, mas a suíte integral não é apresentada como integralmente aprovada.
