# R017 independent verification result

Date: 2026-10-09. Result: **PASS for the implemented bounded local-connection model**, subject to the explicitly declared external restraint and member-design conditions. No production files were edited by this verification worker.

- Final engine SHA256: `9b5f58144f1b64818dea9b00984eefcdebf9f48048cb55a1e6fc9a3898396f30`.
- Independent source/numerical/adversarial comparator: **7,645 assertions, zero failures**.
- Eleven end-to-end numerical cases, additional source-domain/round-cope probes, independent intact-member shear and long-grip bolt probes.
- A separate exact narrow-cope geometry regression verifies c73 gives9.038262 mm actual flange clearance and an assembly/access pending condition, not a false physical collision.
- Frozen R016 and R015 engines are byte-identical to their0.9.2 versions. Packaged fixture generators and numerical JSON files match the independent originals exactly.

## Strength results

The pinned W360×51 / L76×76×6.4 / fourM20 / c130 / dc30 / gap10 fixture has local capacity233.950325 kN, governed by first gross flexural yield. The complementary instability value is1013.245873 kN. A larger setback20 produces218.353636 kN first-yield capacity using the actual150 mm lever; it also correctly reports the separate beam-end edge-detail deficiency.

A synthetic d400/tw3/dc40/c300 fixture genuinely exercises instability:14.928774 kN, below the45 kN sizing floor. A separate synthetic1.5 mm supporting web governs at182.4 kN through its real hole-bearing demand and fails atV200 kN. The production model does not double that physical web.

All angle and supported-web block prefixes, gross/net areas, per-hole directional bearing, normative bearing sums, physical bolt planes, material factors, per-component demand fractions, reversal and zero-force sizing agree with the independent equations.

## Approval and boundaries

The untouched default produces useful conditional component results and requires the missing compression-flange cope-face restraint. Conventional double angles supply the modeled out-of-plane connection restraint topology; they do not establish that separate face brace. A qualified external-boundary fixture receives `local_pass=true`, while `global_pass=false` and supporting-member global status remain external. ReversedV requires the lower face, andV0 evaluates both directions at the45 kN sizing floor while exporting actual zero load to the girder.

The old complementary model is restricted to equal shallow copes, c≤2d and dc≤0.2d, with350600 MPa already including its source resistance factor. Arbitrary170 mm limits, duplicated gamma, plastic-section substitution, fictitious flange-root free edges and V·support-depth/2 torque are absent. A fitting bolt column reaching the curved cope retains a specific unresolved curved-path model condition; it does not receive an invented straight-block approval. Unequal/deeper/single copes, externalN/M/T, alternative angle/gauge systems, open/notched/overlapped supporting webs and nonzero retained out-of-web eccentricity cannot leak into local approval.

No whole-girder global analysis is demanded to close conventional local bolt/bearing transfer. Actual girder section actions, global/perforated-section strength, member stability and independent brace design are explicitly outside this local result. The optional equilibrium helper checks the real shear jump and moments, without inventing equal global span reactions or claiming member capacities.

## Historical limit

The Gerdau historical table266 kN versus explicit printed-formula233.950325 kN discrepancy is retained as unresolved and is not used as a regression target. Reproducing that historical table would require its exact supplier-section dataset and calculation assumptions. No factors or dimensions were fitted to force agreement.

## Reproduction and artifacts

Run `python angle_connection_scope/r017_verification/calculate_r017_fixtures.py`, then `calculate_r017_supplemental.py`, then `compare_r017_implementation.py` from this workspace. The production package contains a path-adapted portable comparator and unchanged oracle files under `tests/fixtures/`.

Detailed source/qualification contract: `source_boundary_contract.md`. Primary comparison: `r017_implementation_comparison.json`. Independence/final hashes and package equality: `final_verification_manifest.json`, `oracle_frozen_sha256.txt`, `source_hashes.json`. Source equations were independently transcribed without production imports; the comparator imports the engine only as the subject under test.


## Reexecução no texto/esquema final

O relatório acima preserva a revisão independente original. Após tornar explícitos os referenciais das coordenadas exportadas e corrigir três espaçamentos de texto, o comparador independente inalterado foi reexecutado pela implementação: 7.645 assertivas, zero falhas, SHA256 final do motor `4244bfd94663850f0453bcb52b0e3bcdd26adb0362b039e4316fc8de13959f81`. As equações e oracles não foram alteradas. Ver `r017_implementation_comparison.json` e o registro geral de validação.
