# R017 independent source and model audit

Date: 2026-10-09. Source analysis and test artifacts only. Production code belongs to the implementation worker.

## Practical result and default

A bounded local R017 module is supported by the available evidence: two symmetric conventional angles, bolts on both legs, a rolled-W supported beam with equal shallow top/bottom copes, static vertical reaction, and one intact interior supporting-girder web. It uses current NBR component equations and the separately identified complementary Gerdau/AISC cope model. No complete supporting-girder global analysis is required merely to calculate and close conventional local bolt and web-hole bearing transfer.

The physically detailed baseline is W360×51 (explicit geometry d355/bf171/tw7.2/tf11.6/clear308) on the same supporting section, two L76×76×6.4 angles, r_angle8, L260, top47.5, both g45, four bolts per angle leg at p60/end40, shared four beam bolts and eight support bolts, M20/dh22/dnet24, gap10, equal c130/dc30/R15, equal beam levels. A572 Gr50 beam/support and A36 angles. This is an explicit geometric fixture, not an assertion that an undimensioned industrial sheet universally prescribes this cope.

The default may calculate every applicable local resistance. It must not claim unconditional cope stability when the required compression-flange-face restraint is unspecified. A passing numerical example must be clearly marked as assuming independently qualified external restraints, not presented as a completed design of those restraints or the complete girder.

## Two different restraint locations

The official Dowswell and Whyte paper (2014), pp.43–45, Figure1 and Eq1–4, identifies the old equal-cope method and its boundaries:

1. At the connection end, an out-of-plane restraint is shown over the connected web depth. Paired angles with vertically separated bolts connected to a stable supporting web supply the conventional physical restraint topology. Gerdau p.20 requires connection length at least half the beam depth and a group near the upper region or centered. A source-supported conventional-connection assumption may be stated here; do not pretend the present V-only bolt checks separately design all brace forces and stiffness.
2. At the compression-flange cope face, the old finite-element models were laterally braced. This is a separate position at x=gap+c from the supporting contact face. The ordinary angle pair does not establish a restraint at that location. Flange continuity is not such a brace; slab presence alone is not a verified connection to a brace.
3. The source explicitly allows movement of the tension edge and movement/twist of the reduced-section shear center. Do not demand or claim a fully fixed cope-face cross-section as the boundary condition. Conversely, do not remove the compression-flange-face restraint because the end connection is restrained.
4. For the adopted positive-downward beam-delivered reaction, the conventional supported-beam end region has upper-edge compression. Reversal requires the corresponding lower-flange-face lateral restraint. A zero-force case sized at the 45 kN minimum must either state its selected direction or evaluate both; the implementation intends both.

A practical external qualification record identifies the physical restraint system, actual location and relevant side, independent calculation/detail reference and the load direction(s) covered. The module checks those records for applicability and declares the boundary condition; it does not certify a brace merely because text or a checkbox was supplied. No numerical brace-force or stiffness threshold is invented from this paper. Real adequacy remains the responsibility of that independently supplied design basis.

## Analytical model and resistance conventions

- Use equal c and dc; c≤2d and dc≤0.2d for the old method. These are the actual old-model limits from the primary paper. Gerdau's 80/130/170 mm table values and its 170 mm study limit are not universal structural prohibitions.
- h0=d−2dc and W1=tw·h0²/6.
- e=c+gap, measured from the reaction support face to the cope face. The printed +1.0 cm corresponds to a 10 mm setback, not a bolt-centroid lever.
- First gross bending yield: V_Rd=fy·W1/(1.10·e).
- Complementary instability: Fbc,design=350600·tw²/(c·h0)·(3.5−7.5dc/d) MPa, then V_Rd=Fbc,design·W1/e. The printed kN/cm coefficient is35060. Its resistance factor is already embedded; do not divide by another gamma. The independent estimate0.9·0.62·π·200000=350601.740MPa corroborates, but does not replace, the printed rounded coefficient.
- Do not replace W1 by plastic Z or fit factors to a table. This release is not an implementation of the paper's later unequal/deep-cope proposal or its plastic moment-shear equations.
- Do not apply an intact I-web kv5.34 calculation to the doubly free coped strip as a substitute for this stability model.

## Real rounded geometry

The industrial R017 sheet, printed p.20, specifies R15 at both corners. Gerdau's approximately12 mm minimum is a different statement. With c defined to the vertical cut and dc to the deepest horizontal cut, the standard upper fillet joins (c−R,dc) and (c,dc−R), centered at(c−R,dc−R), measured from the beam end. Inside that interval, top boundary y=dc−R+sqrt[R²−(x−(c−R))²]. The lower boundary is its mirror for equal copes.

This exact boundary belongs in fitting, drawings and hole-to-boundary geometry. A whole circular hole must fit, which requires shortest-distance checks to the horizontal segment, quarter-circle arc and vertical segment, not merely a boundary value at the hole center. Bearing clear distance follows the actual force direction. A straight-edge prefix-block expression is not automatically validated for a bolt line in the rounded segment. The bounded production plan leaves such a physically fitting but unqualified block path pending rather than approving it with an invented straight path.

## Current NBR force and physical path audit

NBR8800:2024 corrected2025, printed pp.69–71,84–85,90–96 (PDF pages+22) establishes:

- Ordinary beam minimum connection sizing force45 kN, retained separately from the real delivered girder reaction.
- Bolt shear0.45Ab·fub/1.35 with threads,0.56 without, per physical plane; actual grip reductions apply.
- Supported beam has n shared double-shear bolts. Support interface has2n single-shear bolts through one physical support web. Neither web has doubled thickness.
- Bearing min(1.2lc,2.4db)·t·fu/1.35 for the conservative deformation-limited standard-hole branch. Keep the normative sum and also each actual per-bolt demand under the equal direct-force model.
- Angle leg gross and net shear use their actual length and holes, for each physical angle and each interface.
- Supported web gross/net shear use h0·tw and(h0−n·dnet)·tw at the straight bolted strip.
- For positive delivered V the supported web is pushed upward. Its loaded free edge is the upper cope; angle beam legs are pushed downward, support angle legs upward, supporting web downward. Reverse all loaded edges with V.
- All k-hole prefixes of a physically possible straight L block are checked under k/n of that interface load. Agv=[E+(k−1)p]tw; Anv=Agv−(k−0.5)dnet·tw; Ant=(g−gap−dnet/2)tw for the supported web. NBR Figure16(b) directly illustrates Cts1 for one vertical coped-beam bolt column. Use the same source equation[ min(0.6fu·Anv,0.6fy·Agv)+Cts·fu·Ant]/1.35, including the tension term only once.
- The supporting web's flange junction is not a free cut edge. It does not inherit the supported beam cope or angle end. Its intact terminal directional bearing hole uses the bearing cap, not a fictitious short ligament; its neighboring holes retain p−dh. The two support columns sum distinct hole capacities once.
- A conventional intact supporting web has no transplanted R016 column-toe L block. Nearby actual openings, notches, ends or overlapping connections change scope and require their physical paths. NBR5.7 outer-flange patch loading is a different load introduction from vertical bearing directly through web holes.

## Supporting member scope

The ordinary local connection assumes the real reaction is idealized in the girder web plane. Export the real reaction, physical support-hole coordinates and stated application/reference plane. Do not export the minimum45 kN as an extra actual member load. Do not copy the R016 column lever V·d_support/2.

If a physical out-of-web eccentricity ez is retained, r=(0,0,ez) and F=(0,−V,0) give girder torsion Mx=V·ez. Optional girder-section checks need actual section actions; V/2 per angle is not V/2 to each girder span. No optional section check is needed merely to approve the restricted bolt/bearing interface. Global/perforated-member section strength and member stability are explicitly external, as are the independently qualified braces.

## Oracle evidence and exact limitations

The independent generator imports only Python standard-library modules and freezes equations, materials and geometry before production evaluation. Numerical oracles cover all component checks, equal/opposite loading, asymmetric bolt positioning, the45 kN minimum, actual setback, threads excluded, a thin supporting web and genuine instability-governed thin coped web. The dedicated rounded-boundary points are geometric probes. Some deliberately unfavorable synthetic profiles/details are component/model fixtures and must not become passing fabrication presets.

The historical Gerdau p.33 row says266 kN; d355/tw7.2/dc30/c130/gap10 in its printed first-yield equation gives233.950325 kN. That discrepancy is retained as unresolved. The exact historical supplier section/table calculation assumptions would be needed for reproduction. It is not calibrated away and is not an exact regression target.

## Sources inspected

- Supplied industrial sheet crop: angle_connection_scope/source/R017_printed20.png.
- Supplied Gerdau2018 PDF: references/Automação MC/Manual Gerdau Ligações para Estruturas de Aço.pdf; p.20 text and p.25 rendered equation image inspected, with source-scope report covering pp.9,19–26,33.
- Supplied current NBR PDF: baseplate_references/Automação MC/NBR 8800-24-25-projeto-de-estruturas-de-aco-e-de-estruturas-mistas-20250710-000231_compress.pdf. Rendered6.5.5/6.5.6 and Figure16 inspected; supporting-web source audit contains other verified pages.
- Official full Dowswell/Whyte PDF and rendered pp.43–45: angle_connection_scope/r017_scope/sources/. Official DOI and article metadata rechecked: https://ej.aisc.org/index.php/engj/article/view/1055 ; full PDF: https://ej.aisc.org/index.php/engj/article/download/1055/1054/1054 . This is the2014 paper, not an AISC Manual download.
- Supporting-web source audit retained at angle_connection_scope/r017_scope/support_web/support_web_audit.md. Its2024/2008 AISC support-interface corroboration is explicitly indexed primary text; full PDFs were403, not visually inspected fixtures. No new missing-source loop is needed for this bounded interface model.
