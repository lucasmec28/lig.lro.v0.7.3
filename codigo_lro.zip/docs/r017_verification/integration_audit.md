# R017 independent integration and adversarial audit

Date: 2026-10-09 UTC. Audit production target: `connections_work093/source`.

## Outcome

Two concrete defects were identified, reported to the implementation owner, and corrected:

1. **Physical interference versus assembly allowance.** The previous flange check evaluated the real-steel collision at the flange projection plus an added fabrication allowance. A baseline with c_top=c_bottom=73 mm, gap=10 mm and R15 has its true supporting-flange tip at x=81.9 mm, before the cope face at x=83 mm. The rounded cope boundary there is y=20.638262144 mm, leaving 9.038262144 mm above the support flange thickness of 11.6 mm. The old evaluation at x=84.9 mm falsely returned a physical collision. The fixed implementation checks real steel at its true tip and separately reports the expanded assembly/root envelope as pending access. A c=71 mm countercase retains a genuine physical collision.
2. **Unambiguous reaction-coordinate export.** The unused support_hole_z_mm alias duplicated support_hole_x_mm even though the actual hole coordinates have z=0. It is removed. Hole geometry explicitly states y downward from the support top; the member-action frame separately states y upward from the support mid-height. Their conversion is regression tested, including a nonzero beam level and off-center support bolt group.

No unsafe local or global approval was found in the audited input/export paths. A complete local result remains conditional on the stated external restraint records. The app does not verify those external designs and does not approve the complete girder or members.

## Independent tests

The parent-owned files are `test_r017_adversarial.py` and `test_r017_state_adversarial.py`.

- Exact independent prefix-block areas/resistances and k/n force allocation for both V signs, with an asymmetric bolt group.
- Dense geometric sampling of the straight cut, R15 quarter circle and vertical cut; an independent geometric error bound avoids using the implementation as an oracle.
- True physical flange clearance and collision; separate fabrication/access pending conditions.
- Separate supported/support webs with different thicknesses, materials and bolt-row counts; distinct support holes; real bolt counts and shear planes; absence of invented support-edge blocks.
- Exported actual reaction versus the 45 kN design minimum, positive/reversed/zero force, and the explicitly external global-member state.
- Strict unknown/missing JSON fields, incompatible family/version/unit/assumption records, invalid types and nonfinite/extreme numeric inputs.
- Result-to-input binding for every native dataclass field. Stale input cannot generate a current drawing/report.
- Word/SVG outputs for pending, failed, invalid and unsupported cases cannot confer local approval.
- UI rollback after malformed import, preservation of custom profiles and unsupported material across family navigation, and removal of an old passing report after load reversal.

The independently frozen source/mechanics oracle is maintained by the separate verification worker; this audit does not replace it. Its final package comparator is included in the production engine tests.

## Presentation spot check

Visually inspected the worker-rendered qualified report first page and the three-view R017 drawing. Both explicitly distinguish local completion from external global-member verification. The drawing shows two real L pieces, two support bolt columns in one continuous support web, actual rounded double copes, and the downward positive-V arrow. This is a spot check; the artifact worker owns complete rendered-page QA.

## Legacy preservation

Comparison of all preexisting noncache files between work092 and work093 found changes only in README.md, app.py and lro/models.py. The latter changes the application version only; app.py adds the R017 modules/router and version guards. No existing family implementation was changed or removed. `prior_source_diff.json` records this comparison. The original work092 source tree was also hashed before and after the audit, independently of this comparison.

## Final verification record

The exact final code passed **284 tests** in 110.30 seconds, with zero failures. All six recorded implementation/router/version hashes were unchanged before and after the run, and all 287 original work092 noncache files remained unchanged. Final tests and before/after source hashes are recorded in `final_exact_hash_validation.log` and `FINAL_AUDIT_RECORD.json`. The full application aggregate suite is owned by the implementation worker and is not represented as this audit's own run.

## Bounded scope and exact open limits

This is verification of the restricted R017 implementation, not engineering certification. Unequal/deep/single copes, unqualified rounded-hole load paths, unsupported actions/topology, incomplete fabrication access and missing external compression-flange restraints remain nonapproving. The historical Gerdau 266 kN row remains outside the exact-oracle claim; reproducing it needs its precise section dataset and calculation assumptions. No additional broad source search or generic FEA demand was introduced.
