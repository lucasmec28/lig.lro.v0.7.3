# Validação 0.9.60

Integração em cópia da .59. Console independente revisado: 138 testes e 266 subtestes, incluindo 29 combinações receptor/material. Testes direcionados da integração, navegação e pacote extraído descritos em validation0960/SUMMARY.json.

Todos os 26 editores abriram sem exceção em AppTest. As equações das famílias existentes permanecem byte a byte iguais à .59, exceto double_cover.py que recebeu somente nome de preset, propriedade geométrica de folga e configuração inicial: nenhuma equação resistente foi alterada. Interface e relatórios de duas talas receberam a cota correspondente.

Console: resultado local qualificado, AISC LRFD no domínio explicitado. A aprovação de testes de software não equivale a aprovação estrutural. A opção NBR N/V de end plate permanece parcial e a SCI mantém domínio EN/UK separado. Não houve comparação com fonte histórica .37 indisponível; a paridade .57 registrada na .58 é somente ausência de regressão relativa àquela entrega, não validação estrutural nem substituição silenciosa do contrato .37.

Não repetida a suíte integral de 6.860 testes da .58. A integração concentra testes nos módulos e rotas afetados, exportações e preservação do método NBR. A distribuição compacta mantém todos os módulos, dados e exemplos; remove somente testes, caches e evidências históricas duplicadas da distribuição de uso. Fontes completas anteriores preservadas.
