# Placas de base na versão 0.8.3

## Verificação nova

Cone de ruptura do concreto por tração como verificação complementar ACI 318-19, 17.6.2, apoiada no AISC Design Guide 1, 3ª edição, 4.3.2.2. O modelo NBR da placa e do aço não foi substituído. Entradas permanecem esforços já de cálculo; não se reaplicam coeficientes às ações nem γc à resistência ACI. O responsável pelo projeto deve confirmar a compatibilidade da base normativa complementar.

Domínio: quatro barras externas do Tipo 1, moldadas no local, com cabeça forjada, porca enterrada ou chapa rígida de apoio retida por porca; concreto normal fissurado e íntegro. São obrigatórios detalhe identificado/confirmado, embutimento até a face superior de apoio enterrada, dimensões da peça e limites/altura reais do bloco. Bolsões vazios, espuma, bainhas livres e ancoragem química não são presumidos como concreto íntegro. Barra reta sem mecanismo definido e gancho J ficam sem resistência de cone atribuída.

O cálculo usa as trações simultâneas de cada barra, considera somente barras tracionadas, união exata das áreas projetadas, bordas reais, excentricidade do grupo e correção do embutimento de cálculo para três ou mais bordas próximas. Cones desconectados são verificados separadamente. A expressão básica de resistência é mantida em todos os embutimentos, sem ganho opcional para grandes profundidades. φ=0,70, Condição B, sem crédito de armadura suplementar. O envelope opcional de subconjuntos é conservador da aplicação e não uma exigência literal da ACI.

Pullout, ruptura lateral, fendilhamento/detalhamento, cortante/pryout/interação no concreto, resistência da peça enterrada e bloco armado continuam discriminados como verificações a complementar. Aprovação do cone não aprova a ancoragem completa. Dados opcionais insuficientes impedem apenas a avaliação do cone; o restante do cálculo e a exportação permanecem disponíveis quando seus próprios dados são válidos.

## Soldas e detalhe

Alma e mesas da coluna possuem escolhas independentes: solda de chanfro com penetração total (CJP) ou filete. Filete de pernas iguais a 90° pode ser informado por perna z ou garganta a, com a=z/√2. Alternar a unidade geométrica preserva o tamanho físico. Escolha, tamanho e conversão são salvos em JSON, mostrados no desenho e registrados no Word. Resistência geral N/M/V, metal-base, procedimento e inspeção das soldas não são certificados por essas escolhas.

Rotulada/engastada registra intenção do modelo global, sem certificar rigidez nem zerar momento informado; continuam quatro chumbadores externos. Dois enrijecedores triangulares no plano da alma, além das mesas, são a interpretação inicial para o detalhe solicitado. Não recebem ganho resistente; uma base enrijecida exige modelo de distribuição específico. Interferências físicas aparecem como avisos próprios.

Graute parte da face inferior da placa e desce a 45° até o concreto. Sua projeção inferior mede L+2e por B+2e, sem aumentar a área de contato usada no cálculo. A arruela superior soldada à placa para cisalhamento e a peça enterrada de ancoragem são desenhadas e identificadas separadamente.

## Compatibilidade e exemplos

Projetos antigos importam com as opções novas não especificadas e cone desligado. Opções, dimensões escondidas e escolhas independentes são preservadas na navegação. Alterações invalidam o Word previamente gerado. Exemplos 0.8.3 são didáticos, com dados hipotéticos; não são detalhes liberados para execução.
