# Headed-anchor pullout and side-face blowout: bounded calculation contract

Research date: 2026-10-09. Research and independent fixture work only. No application code is changed. This extends, rather than replaces, `concrete_anchor_scope/specification.md`. It is a complementary ACI 318-19/318-19(22) calculation beside NBR 8800, not a claim of complete NBR anchorage design or a sealed design.

## 1. Findings that control implementation

1. Pullout is **per anchor**: `phi*Npn = 0.70*psi_cP*8*Abrg*f'c`; use each actual concurrent `T_i`. With identical heads, the highest tensile force governs. Never average four anchor forces.
2. Side-face blowout uses **physical** embedment: susceptible when `hef > 2.5*c`. A fictitious reduced depth used by the tension-breakout narrow-member rule must never suppress this mode.
3. Single-anchor corner correction: `alpha_corner=(1+ca2/ca1)/4` for `1 <= ca2/ca1 < 3`; otherwise 1. `ca1` is the nearest edge; `ca2` is the nearer perpendicular edge, not the opposite parallel face. At equal perpendicular edge distances the factor is 0.5.
4. The side-face **group** formula uses the basic `Nsb` **without the perpendicular-edge correction**. Applying `alpha_corner` to the group formula is not the published ACI expression. Hilti's reproduced §17.6.4.2 and its explicit implementation discussion agree on this point.
5. Group demand is the sum of actual tensile forces on the loaded anchors adjacent to the face being checked. It is not the sum on all four rods unless all four are the actual susceptible group. There is no side-face eccentricity factor in the verified expressions. Do not import the tension-breakout `psi_ec,N`.
6. A regular 2x2 layout does not by itself establish an unambiguous single susceptible row: very deep embedment can make both rows susceptible to the same face. The first exact native path below intentionally excludes that geometry. Do not silently merge unequal edge-distance rows or apply the near-row capacity to the full group as though this were the exact ACI solution.
7. Net concrete-bearing area must belong to a real, mechanically engaged head or buried nut. Full buried-plate area is unavailable until the plate and its retaining nut/thread load path have a traceable structural verification. Merely entering thickness or ticking “rigid” is insufficient.

## 2. Evidence and limitations

### Supplied reference

AISC Design Guide 1, 3rd edition, `baseplate_references/Automação MC/900064977-AISC-Design-Guide-01-Base-Connection-Design-for-Steel-Structures-3rd-Ed.pdf`:
- Printed p.8: recommends heads or threaded rods with buried nuts; plate washers are possible but require appropriate detailing.
- Printed pp.29-30: Eq.4-25, pullout phi, net head/nut bearing area and heavy-hex-nut Table4-2.
- Printed pp.31-33, physical pp.41-43: side-face trigger, both square roots in `160*ca1*sqrt(Abrg)*lambda_a*sqrt(f'c)`, group factor and outer-anchor spacing. These pages were visually inspected; rendered images are beside this file.
- DG1's summary does not include the single-corner reduction or the explicit no-corner-modifier qualification for groups. It is therefore insufficient on its own for the new side-face branch.

### Publisher-produced ACI-excerpt corroboration

Hilti *North American PROFIS Engineering Anchoring to Concrete Design Guide, ACI 318-19*, July 2022, published by Hilti through Joomag:
- [p.87, basic pullout and bearing areas](https://viewer.joomag.com/profis-design-guide-ac-318-19-july-2022/0546853001659024142/p87): §17.6.3.2.2(a), `Np=8*Abrg*f'c`.
- [p.86, cracking factor](https://viewer.joomag.com/profis-design-guide-ac-318-19-july-2022/0546853001659024142/p86): §17.6.3.3.1, cracked 1.0, justified uncracked 1.4.
- [p.101, pullout phi](https://viewer.joomag.com/profis-design-guide-ac-318-19-july-2022/0546853001659024142/p101): Table17.5.3(c), cast-in pullout phi=0.70. This is not the side-face/breakout table, and supplementary reinforcement does not raise this pullout phi to0.75.
- [p.108, group demand](https://viewer.joomag.com/profis-design-guide-ac-318-19-july-2022/0546853001659024142/p108): uses the actual tension on anchors in the edge row.
- [p.109, group equation](https://viewer.joomag.com/profis-design-guide-ac-318-19-july-2022/0546853001659024142/p109): §17.6.4.2; group uses unmodified basic single-head strength, with no perpendicular-edge multiplier.
- [p.112, edge definitions](https://viewer.joomag.com/profis-design-guide-ac-318-19-july-2022/0546853001659024142/p112): §2.2 notation, §17.6.4.1/.1.1/.2; nearest face, perpendicular second face and the corner ratio bounds.
- [p.119, spacing](https://viewer.joomag.com/profis-design-guide-ac-318-19-july-2022/0546853001659024142/p119): center-to-center outer-anchor span along the face. Hilti's `s<=6ca1` cap is a software policy, not a general code cap on all possible many-anchor groups.
- [p.120, corner calculation](https://viewer.joomag.com/profis-design-guide-ac-318-19-july-2022/0546853001659024142/p120): `alpha_corner` only for the single-anchor branch.
- [p.130, side-face phi](https://viewer.joomag.com/profis-design-guide-ac-318-19-july-2022/0546853001659024142/p130): Table17.5.3(b), phi=0.70 without qualifying supplementary reinforcement. The explanatory prose on this page loosely refers to pullout under table(b); use the reproduced tables and p.101 instead, which correctly put pullout in table(c).

These are primary documentation for Hilti's implementation and reproduced ACI excerpts, not a licensed copy of the complete ACI code. Several transcribed explanatory lines in pp.111/119 omit the leading “1+” in prose while their displayed formula includes it. Use the displayed equation, corroborated by DG1, not that transcription slip.

The ACI official [2008 side-face group Q&A abstract](https://www.concrete.org/publications/internationalconcreteabstractsportal.aspx?id=20083&m=details) confirms that multi-anchor spacing interpretation is a known topic, but its answer was not accessible in the inspected abstract. It is not evidence for extending this implementation beyond two anchors along one face.

The [AISC May2025 DG1 errata PDF](https://www.aisc.org/media/22mmv1en/design-guide-1-3rd-ed-revisions-and-errata-list-1.pdf) returned403 on this pass. Earlier research's indexed errata excerpt did not change these strength equations, but this report does not claim a complete errata review. Final engineering release review should check legitimate controlling ACI text and current errata. No third-party full-code mirrors are relied upon.

## 3. Design basis and shared gates

Use the existing factored simultaneous NBR combination reactions, with their physical rod IDs and coordinates. Do not refactor as ASCE7 and do not mix maxima from different combinations. Preserve existing NBR steel/baseplate factors. State that the ACI resistance model and factors are a complementary basis whose combination with NBR actions requires the responsible engineer's acceptance.

Native material/loading scope: normalweight concrete (`lambda_a=1`), cracked concrete, static monotonic loading, four identical cast-in mechanically headed or buried-nut anchors, one common physical embedment. No seismic, cyclic, fatigue, fire, impact, adhesive/post-installed, hooked/plain unheaded rod, or supplementary/anchor-reinforcement capacity credit. Use specified cylinder strength `f'c`, not `fcd`. The existing20–50MPa range stays within the ACI cast-in calculation-strength ceiling10000psi.

Real concrete is an intact rectangular prism aligned with the regular anchor rows. Require actual plan bounds, depth, anchor locations, physical embedment and full buried assembly fit. Grout, an unfilled foam pocket, sleeve/void changing the load path, damaged concrete or an undefined head cannot be treated as intact structural concrete. Existing C-003 drawing detail has a near-surface foam pocket; selecting that drawing must not automatically satisfy this gate.

`hef` is from the structural concrete top to the upper load-bearing face of the head/nut/qualified plate. Exclude grout and above-concrete projection. `hef+below_face_assembly_extent+required_bottom_cover <= actual_member_depth`; use actual rod-end/nut/head extent, not only plate thickness. Check all head footprints remain inside the prism and do not overlap. Require finite physical dimensions, positive net area, real mechanical engagement, valid shaft/hole geometry and declared concrete placement/detail reference.

Spacing, cover, splitting control and member reinforcement/detailing remain distinct prerequisites. The ACI17.9 cast-in minimums distinguish torqued and not-torqued installation; see the existing breakout specification. Do not invent a universal cover value or import post-installed member-thickness limits. Failure to establish these prerequisites prevents a complete anchorage approval even when the two numerical modes are computed.

## 4. Net bearing area and mechanical load-path contract

### Accepted direct-head/nut path

Require an identified head/nut family and a dimensional/catalog/drawing reference matched to the actual rod diameter. Permitted area sources:
- An applicable tabulated standard head/nut net bearing area, with its table edition and selected size recorded.
- The actual plane area in direct concrete contact less shaft/hole/void area, with the dimensional source recorded.

DG1 Table4-2 heavy-hex nut benchmarks: d=7/8in, Abrg=1.19in²; d=1in, Abrg=1.50in². Hilti's head table uses1.188 and1.501in² for those heavy-hex heads; these small dimensional/rounding differences are real source choices. Do not silently combine their values and demand exact equality with DG1's rounded nut table.

For an unchamfered circular bearing face: `Abrg=pi*(Dface²-dvoid²)/4`. For a fully effective rectangular face: `Abrg=Bface*Lface-pi*dhole²/4`. An arbitrary ideal hex outline is not proof of the actual nut contact face; a verified standard table is preferable to guessing from wrench size. Store both the geometric area and credited effective area; credited area cannot exceed actual available bearing area.

The steel head/nut, thread engagement and attached rod still need their own strength. The concrete equations do not prove that a nut cannot strip or that a forged head is adequate. A numerical pullout pass must carry the separate mechanical verification status; missing mechanical proof is not an implicit pass.

### Buried bearing plate

A plate may furnish extra area only if a traceable verification establishes the effective footprint and load capacity of that exact assembly, including plate bending, local bearing, punching/shear where applicable, material, thickness, nut/thread engagement and the force transfer from rod to plate. Record its design resistance, source, units, load basis and applicable geometry; verify the same concurrent per-anchor demand does not exceed it.

The first native head/nut-only release should reject the extra plate area when that verification is missing. A bare “rigid plate verified” checkbox, a positive thickness, gross BxL, or an upper special washer welded to the baseplate is not such evidence. Do not substitute the buried nut-only area when the nut does not directly bear on concrete because a plate intervenes. A deliberately restricted effective area under the nut may be used only if its plate/load-path check is separately substantiated. No universal minimum plate thickness is established by this research.

## 5. Pullout computation

Recommended canonical units are inch/psi/lbf, consistent with the supplied DG1 and the breakout fixtures. Convert at one boundary:1in=25.4mm,1lbf=4.4482216152605N,1psi=0.006894757293168MPa.

For each actual tensile anchor i:

`Np_i = 8 * Abrg_i * fc_psi`

`Npn_i = psi_cP * Np_i`

`Rd_pullout_i = 0.70 * Npn_i`

`eta_i = T_i / Rd_pullout_i`

Native `psi_cP=1`. The verified uncracked factor is1.4, but is not enabled without a supported service-level no-cracking analysis. Do not use breakout's1.25 here. No friction/bond contribution is added. The coefficient8 is compatible directly with N/mm²/MPa as well, but one common conversion path avoids implementation inconsistency.

No positive T means `no_tension_demand`, not an anchorage approval. With identical heads, `max(T_i)` governs; showing all four rows preserves force mapping. With different head areas, per-anchor pullout remains mathematically defined, but unequal heads are outside the first common-head side-face contract.

## 6. Bounded side-face computation

### 6.1 Physical screening and exact supported geometry

Use only anchors with positive concurrent tension after equilibrium-scale roundoff cleanup. For each actual vertical free face e, compute each active anchor's normal center-to-face distance `c_i,e`.

`S_e = {i: T_i>0 and hef_physical>2.5*c_i,e}`.

At equality the strict ACI trigger is false. Return `not_applicable_for_geometry` only if every S_e is empty. Do not replace `hef_physical` by a smaller breakout depth. No active anchors gives `no_tension_demand` instead.

The bounded native row path requires, for each susceptible face, that S_e consists of one aligned row at a common positive face distance, one or two loaded anchors, common bearing area and common embedment. Thus unequal tensile forces within that row ARE supported. Unequal row spacings `sx != sy` ARE supported: use the actual tangent spacing for each face. More than one susceptible normal-distance row, rotated/skewed rows or unequal heads is outside this verified row path. This is a deliberate application boundary, not a claim that ACI forbids those arrangements.

The facewise enumeration and exclusion of non-susceptible back rows are engineering implementation choices grounded in Hilti's illustrated nearest-loaded-row method. They are not verbatim additional ACI clauses. Check every eligible physical face, retaining rod IDs and actual row demands. If two different rows are susceptible to the same face, do not take only the nearest row and announce that the entire side-face mode is complete.

### 6.2 Single/isolated anchor and corner

For an isolated tensile anchor, choose its closest physical face as the primary face, `ca1=min(all four distances)`. `ca2` is the smaller distance to either face perpendicular to that primary face. By construction `ca2>=ca1`. Ties between closest perpendicular faces give the same result. A computed ratio below1 means the axes were selected incorrectly; do not silently clamp it upward.

`Nsb0 = 160 * ca1 * sqrt(Abrg) * lambda_a * sqrt(fc_psi)`

`alpha_corner = min(1,(1+ca2/ca1)/4)` for this correctly ordered geometry.

`Rd_single = 0.70 * alpha_corner * Nsb0`

`eta_single = T_i/Rd_single`.

If screening a singleton on a non-nearest candidate face, do not swap only ca1 while leaving the perpendicular direction unchanged. Re-orient the single-anchor calculation to its actual nearest face and deduplicate its result. Its global nearest-face check is the controlling singleton check in the supported ordinary edge/corner geometry.

This report does not establish additional opposing-side or bottom-face reductions for a thin/narrow member. When the local geometry is subject to more than the ordinary edge or two-perpendicular-edge corner model, retain an explicit geometry-review gate rather than multiply ad hoc extra corner factors.

### 6.3 Two anchors in one susceptible row

For face e with two susceptible active anchors at common distance c, let `s` be their **center-to-center tangent spacing**, not clear shaft spacing, diagonal distance, or spacing normal to the face. The group row demand is `Tedge=T1+T2` from this combination.

For `0<s<6*c`:

`Nsb0_e = 160*c*sqrt(Abrg)*lambda_a*sqrt(fc_psi)`

`alpha_group = 1+s/(6*c)`

`Nsbg_e = alpha_group*Nsb0_e`

`Rd_group_e = 0.70*Nsbg_e`

`eta_group_e = Tedge/Rd_group_e`.

Do not multiply by `alpha_corner`, by n, by a tension-breakout eccentricity factor, by a cracking increase, or by a second NBR material partial factor. No second uncracked increase was found in the side-face equation.

For `s>=6*c`, use independent single-anchor checks with each anchor's own applicable corner geometry and actual demand. At exact6c the pair's unmodified sum is2*Nsb0, matching the limit from below in the no-corner case. Do not treat2*Nsb0 as a shared pool that can hide one locally overloaded anchor. This independent branch is the implementation inference from the code's strict group-interaction threshold for a two-anchor row. Larger many-anchor row partition rules are not established here.

### 6.4 Unequal forces and optional conservative local envelope

The published group formula contains a group sum; it does not equalize T1 andT2. Report `T1`, `T2` and `Tedge`. A row of1kip+39kip is not the same physical local state as20kip+20kip even though the group sum matches.

A defensible extra application envelope is to also calculate each active anchor's isolated nearest-face/corner resistance and compare its own T_i, even where the exact row-group expression applies. Keep this result separate, titled **additional conservative isolated-anchor envelope**, and state that the retrieved ACI group provision does not mandate these subset checks. This envelope preserves both exact group calculation and local overload warning; it must not be presented as a hidden corner modifier on the group formula. When enforced for application acceptance, report the conservative governing result and its policy separately from the primary code-group result.

### 6.5 Fallback for unsupported geometries

Recommended release behavior for multiple susceptible depths, dissimilar heads or unresolved thin/narrow-member conditions: `sideface_status=unsupported_geometry`, list the affected face and anchors, preserve any independently computable supported rows, and require a separately verified calculation. Pullout can still be shown when its own gates are met.

An optional conservative **screen only** can compare total susceptible tensile demand to the minimum applicable isolated-head design resistance, granting no spacing increase and no load sharing. It is deliberately severe and is not established here as an exact ACI group solution or a proven lower bound for every unsupported geometry. A passing screen must NOT turn `unsupported_geometry` into a completed side-face check. A failing screen calls for the proper calculation, not a declaration of physical failure. This is preferable to a plausible-looking unsupported group capacity.

## 7. Output and acceptance contract

Keep applicability, prerequisites, exact-vs-conservative method and numerical result separate. Recommended values:
- `computed_bounded`, `not_applicable_for_geometry`, `no_tension_demand`, `unsupported_geometry`, `unsupported_detail`, `invalid_input`.
- For each computable candidate: source edition, method ID, physical hef, face, rod IDs, demand, ca1/ca2, area and source, phi, factors, nominal/design resistance, utilization and pass/fail.
- Group source `17.6.4.2` and exact no-corner-modification result separately from isolated-envelope candidates.
- Entire mode is not complete if one applicable physical face or physical prerequisite is unresolved. Never null->0 demand, null->infinite resistance, or unsupported->PASS.
- Preserve the NBR combination ID, coordinates, source data and assumptions through save/load and report export.

Passing these modes does not complete anchorage. Tension breakout, rod/head/nut/plate steel, splitting/cover/detailing, concrete shear breakout, pryout, combined tension/shear interaction, the shear-transfer path and concrete member design retain their own explicit statuses. In particular V!=0 cannot disappear because pullout and side-face pass.

## 8. Numerical checks

`benchmarks.json` and `generate_benchmarks.py` contain independent calculations; no production functions are imported. They cover DG1 nut pullout, per-anchor overload hidden by pooling, single-face/corner strength, uncorrected group strength, unequal row forces, strict physical-embedment trigger,6c spacing, actual row loads with unequal rectangular spacing, direction reversal, unit conversion and area qualification failures. `fixture_validation.txt` records the executed assertions.

## 9. Implemented pure-kernel contract (2026-10-09)

`lro/concrete_headed.py` exports `evaluate_headed(anchors, bounds, hef, fc, bearing_area, detail)` in N/mm/MPa. Bounds are `(xmin,ymin,xmax,ymax)`. Anchors have `{id,x,y,tension}` with text IDs and concurrent nonnegative forces. One to four actual anchors can be supplied for independent single/row tests; susceptible group geometry remains bounded to aligned rows within two coordinate levels in each direction.

Required detail keys: `family` (`headed`, `buried_nut`, `buried_plate_nut`), `bearing_area_ref`, `effective_area_qualified=True`, `detail_confirmed=True`, `detail_ref`. Optional `mechanical_resistance` is an external **design** resistance in N, with `mechanical_ref`; it is not a nominal strength to which another phi is applied. `isolated_envelope` defaults false.

Optional `qualified_bearing_area` must match the current credited area. Optional `actual_available_bearing_area` is a separate geometric upper bound calculated by the caller from real head/plate dimensions, holes and any applicable actual nut-area limit. Credited area above that cap is rejected, even when the qualification reference matches it. A matching qualification value by itself is never evidence that the area fits physically. When the cap is omitted, the caller is responsible for deriving and validating the actual footprint/void bound as part of the explicit detail confirmation. The app adapter must do that validation; the kernel does not infer unknown head dimensions from rod diameter.

Results contain `pullout` and `sideface`, each with `status`, `checks`, `reasons`; statuses are `calculated`, `pending`, `not_applicable`, `not_demanded`, or `invalid`. `calculated` means the arithmetic is available, not that demand passes. Each numerical check includes `id,label,ids,demand,resistance,ratio,nominal,phi,method`, with relevant edge/factors. The `prerequisites` dict separately exposes detail, effective area and mechanical verification/failure. `source`, assumptions, physical hef and actual rod mapping are retained.

A direct head/nut may show concrete results with mechanical proof pending or failing. An intervening buried plate gets no effective-area credit when its assembly proof/resistance is missing or inadequate for the actual concurrent demand. Missing area can be displayed as pending in the outer UI; a literal zero supplied to the numerical helper is invalid.

The explicit narrow-member gate is: if the **same tensile anchor** satisfies `hef>2.5*c` for both opposing x faces or both opposing y faces, side-face completion stays pending for geometry review. Existing numerical face checks remain diagnostic and are marked `diagnostic_only`; pullout remains available. This is a bounded-application support limit for the unresolved opposing-face condition identified above, not an additional ACI resistance reduction.

When a single-anchor face screen refers to a non-nearest edge, the calculation reorients to correctly ordered nearest/perpendicular distances. Its check is explicitly tagged `conservative_nearest_face_reorientation`, rather than being presented as an exact calculation about the original farther face. The optional additional isolated-anchor envelope has its own `supplemental_isolated_envelope` basis. Neither is a hidden corner multiplier on the group equation.

Numerical boundaries use a small scale-aware binary64 roundoff guard (32 rounding units based on the actual coordinate/subtraction scale). Exact `hef=2.5c` is assigned to not-applicable; exact `s=6c` is assigned to independent anchor checks even when coordinate subtraction produces a microscopically smaller stored spacing. This is not a physical detailing tolerance. Independent QA added the7in/42in spacing counterexample, where an erroneous pooled branch would hide a500000N local demand, and the7.5in/3in embedment equality case.
