# Chaves cruciformes e W por chapas ativas — 0.8.4

## Alcance e escolha

**Verificação local por chapas ativas — idealização de componentes.** Esta versão permite resultados locais úteis de contato, flexão e cisalhamento, mantendo a ligação e o dispositivo completo pendentes. As equações da chapa única da NBR 8800:2024 corrigida 2025 são reutilizadas por analogia declarada; não se afirma que cruz/W sejam geometrias expressamente abrangidas por essa cláusula. Não há requisito genérico de elementos finitos.

As três rotas principais de cortante continuam sendo chumbadores, barra/chave e atrito. Dentro de barra/chave permanecem chapa retangular única e resistência externa documentada, acrescentando cruz por chapa perpendicular contínua e W por duas mesas ativas. Nada é somado ao atrito. O cone complementar dos chumbadores e os detalhes da 0.8.3 são preservados.

## Geometria real

Eixos: x paralelo a L e V, y paralelo a B e à largura da chapa ativa, z positivo para baixo a partir da face inferior da base. H é projeção total abaixo da base, g é espessura real do graute e H−g é penetração no concreto. Pressão age somente entre g e H. O botão de referência da Tabela 18 preserva g quando esta rota está ativa.

São distintas e persistidas:
- largura física b_steel, sempre desenhada por inteiro;
- intervalos de contato efetivamente expostos por chapa e por sinal de V;
- b_contact, soma dos comprimentos desses intervalos;
- b_calc=b_contact, apenas faixas contínuas de aço atrás do concreto exposto.

A banda central oculta não recebe crédito por redistribuição lateral. Cada faixa recebe força proporcional à largura, com pressão uniforme. Geometria importada pode usar faixas simétricas menores do que o contato canônico; nenhuma faixa pode invadir a junção obstruída. Faixas variáveis com a profundidade, assimétricas, sobrepostas, invertidas ou fora da largura física não entram neste modelo.

Exigem-se H>g, t≤tp, encaixe físico sob a base, aço conforme limites do produto, continuidade das chapas ativas e concreto efetivamente preenchendo as regiões creditadas. Confirmar continuidade também afirma ausência de furos/rasgos/recortes e variação de espessura nas faixas ativas. Alterações não são corrigidas silenciosamente.

### Cruz

Somente a chapa inteira passante perpendicular a V recebe V total. A secundária permanece desenhada e tem resistência/enrijecimento zero. As meias chapas secundárias podem se ligar às duas faces da primária. c+ e c− são obstruções reais de cada face, no mínimo a espessura secundária e incluindo soldas/folgas. O contato canônico é [−b/2,−c/2] e [c/2,b/2]. Comprimento secundário maior, isoladamente, não aumenta resistência.

### W/I

Perfil com eixo vertical e mesas normais a V; d ao longo de x, bf ao longo de y. F+ permanece em x=+(d−tf)/2 e F− em x=−(d−tf)/2. A alma tem crédito zero. A geometria da chave é independente da seção do pilar.

V positivo carrega a face externa de F+ e a interna de F−. V negativo troca as faces sem trocar a identidade das mesas. Face externa tem contato bf; interna bf−c_inner. Para raio conhecido, c_inner≥tw+2r. Sem raio conhecido, é obrigatória referência da exclusão conservadora real. Para fabricado, informar pegada real de solda/junção. Aços de perfis laminados, como A992, são aceitos nos limites próprios; não se aplica indevidamente a restrição de produtos de chapa.

Girar o W 90° mantendo V global não representa duas mesas normais e é rejeitado nesta rota, com possibilidade de rota externa. Girar uma cruz para solicitar meias chapas sem continuidade também exige outro modelo.

## Repartição

1. Padrão: envelope desconhecido, α∈[0,1]. Casos alternativos (V,0) e (0,V). Cada mesa é verificada para |V|, sem ganho de capacidade por duas mesas. As duas demandas máximas da tabela não são um caso de força 2V.
2. Igual: α=0,5, seleção explícita. Supõe restrição comum e engajamento suficiente. Igualdade metálica não prova igualdade das reações do concreto, principalmente com face interna interrompida. Não é uma prescrição NBR.
3. Faixa documentada: 0≤αmin≤αmax≤1, fonte e sinais cobertos. F+ é verificada em αmax V, F− em (1−αmin)V. Os casos extremos reais são registrados separadamente. Faixa exata usa extremos iguais. A parcela continua atribuída à mesma mesa física na inversão de V; uma fonte para um único sinal não cobre automaticamente o outro.

O envelope só cobre parcelas não negativas. Não limita forças opostas autoequilibrantes, pré-carga, transferência resistente pela alma, torção ou mecânica de conjunto diversa. Não há soma de resistências do concreto/dispositivo.

## Equações locais em N, mm, MPa

Para cada chapa i, γa1=1,10; γa2=1,35; γc=1,40:

- σRd=1,7fck/γc
- A_i=b_contact,i(H−g); Rcontato,i=σRd A_i
- zR=(H+g)/2; Mraiz,i=F_i zR, com sinal
- t_req,i=√[2|F_i|(H+g)/(b_calc,i(fy/γa1))]
- Rflexão,i=b_calc,i(fy/γa1)t_i²/[2(H+g)]
- Rescoamento,i=0,60fy b_calc,i t_i/γa1
- Rruptura,i=0,60fu b_calc,i t_i/γa2, faixas sem furos

Cada verificação tem sua própria demanda, resistência e índice. A largura física do aço não é trocada pela largura reduzida nos dados geométricos. O coeficiente de contato horizontal da placa continua A2/A1=1.

## Soldas e equilíbrio global

Ações prescritas por analogia à NBR: Vw,i=Rcontato,i e Mw,i=Rcontato,i zR, sem limitar pela solicitação ou menor resistência de aço. As duas faces/sinais constam dos resultados. São ações de dimensionamento local, não novas ações aplicadas à base.

Segmentos reais de soldas podem ser registrados em JSON por chapa e face, por exemplo {"P":{"positive":[[-120,-10],[10,120]],"negative":[[-120,-10],[10,120]]}}. Campo vazio {} significa desconhecido. A resistência da solda não é calculada, mesmo com segmentos conhecidos; não se transforma solda externa contínua e interna interrompida em um par equivalente completo.

Em cada caso físico, ΣF_i=V e ΣMraiz,i=V(H+g)/2. Ações de entrada referidas à face superior, sem incluir previamente esta parcela:

- eV=tp+(H+g)/2
- Mef=M+V eV, soma algébrica uma única vez

Sem fator 2, sem d/2 e sem somar ações prescritas das soldas. V=0 conserva geometria e faces, sem divisão por V. O momento global resultante alimenta o equilíbrio existente da placa/chumbadores.

## Pendências separadas

- Soldas, metal-base, ligação das chapas e flexão local da base
- Ruptura/arrancamento do concreto da chave, bordas e grupo
- Bloco armado e transferência à fundação
- Ligações/estabilidade da alma ou chapa secundária ignorada
- Exclusões já existentes de ancoragem, soldas do pilar e rigidez

O cone ACI complementar dos chumbadores não comprova o concreto da chave nem a interação. Atendimento local não aprova a base ou dispositivo completo.

## Referências e validação

Base da analogia: NBR 8800:2024, versão corrigida 2025, §§6.7.2.4, 6.6.5 e 6.5.5. A distribuição por faixas, a hipótese de duas mesas, a repartição e as exclusões são idealização de engenharia explicitamente declarada. Não foi acrescentado limite ACI de profundidade/axial nem soma de áreas de contato sobrepostas.

Fixtures sintéticos independentes em `active_plate_component_fixtures.json` e regressões em `test_active_shear_key.py`; não são perfis de catálogo nem dimensionamento de projeto. Compatibilidade preservada com os projetos anteriores e demais rotas.
