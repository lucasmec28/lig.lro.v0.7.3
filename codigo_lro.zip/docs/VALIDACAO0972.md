# Validação focal · sugestões R016 0.9.72

Pacote `0.9.72-candidatos-r016-dev.1`; componente `lro.models.VERSION` preservado em `0.9.44-beam-on-beam-partial-dev`.

## O que a validação demonstra

A enumeração nova foi conferida independentemente, sem chamar o gerador de candidatos de produção. O oráculo de software constrói o conjunto limitado a partir das regras documentadas, avalia cada detalhe com o avaliador nativo e compara conjuntos aceitos/rejeitados, ordem, projetos completos, resultados completos e campos preservados. Isso demonstra reprodução e seleção conservadora; não cria um novo oráculo de resistência ou amplia a qualificação estrutural do módulo.

Nas entradas padrão, cada um dos dois gabaritos exatos produz 76 candidatos distintos e quatro aceitos, nesta ordem: L200/M20/3 linhas; L220/M16/4 linhas; L250/M24/3 linhas; original L260/M20/4 linhas. Os dois primeiros conservam avisos de desvio do preset industrial. Com 350 ou 500 kN, nenhum candidato desse conjunto é integralmente atendido. V invertido e V=0 seguem exatamente as direções e o piso mínimo já definidos no avaliador nativo.

A busca mantém fixos os extremos reais do pilar; não mantém artificialmente constantes as distâncias dos furos às bordas quando muda o grupo. Não arredonda dimensões de catálogo nem atribui massa de outro perfil. Entradas não pesquisadas, incluindo materiais, perfis, ações, raio e condições de montagem, são comparadas integralmente.

## Casos distintos de fonte

O resumo `docs/validation0972/SUMMARY.json` traz os IDs exatos e deduplicados dos casos aprovados:

- 89 casos independentes da busca: conjuntos e ordenação, os dois gabaritos, sentidos de V, nenhum candidato, bloqueios explícitos e mascarados sob FAIL, metadados de catálogo, preservação de campos/extremos, original fora da grade, parafuso imperial original, deduplicação numérica, payloads inválidos e IDs obsoletos/forjados.
- 82 regressões históricas do avaliador R016 e de sua auditoria, reaplicadas sem modificar esses testes ou o motor.
- 37 regressões históricas da interface R016 e dos artefatos, reaplicadas sem modificar esses testes ou os renderers.
- Testes atuais da interface opcional: importação real, busca/prévia sem mudanças em projeto/resultado/Word/desenho, aplicação/restauração nos dois gabaritos, ações assinadas e de alta precisão, edição simultânea ao clique Apply, ID adulterado, bloqueios e ausência de solução, avisos preservados e retorno entre famílias. Incluem M24/furo27 aplicado exatamente, repetição do evento de um botão Apply já removido e restauração repetida.

As comparações de JSON e Word em cache são byte a byte. O SVG nativo contém data de geração e IDs randômicos do Matplotlib, que já variam num rerun ordinário: sua comparação canônica retira apenas esses identificadores/metadados, preservando geometria, textos, estilos e referências. Os renderers reais também são observados para provar que recebem o projeto original antes da aplicação, a proposta depois dela e o original restaurado. Não há mock do cálculo.

As falhas iniciais dos testes AppTest eram do harness: acesso não suportado a `session_state.filtered_state` e tentativa de serializar uma opção forjada antes de renderizá-la. Foram diagnosticadas e corrigidas nos testes, sem mudar produção nem relaxar os invariantes de conservação.

## Preservação e pacote

A fonte .71 é imutável e conferida pelo seu inventário congelado. Na .72, o avaliador R016, todos os demais motores, schemas, renderers, relatórios, dados, miniaturas, guia e tema continuam byte a byte iguais. A interface R016 recebe somente três linhas para renderizar o painel opcional, que vive em módulo separado. O seletor nativo de 26 rotas e o corpo do dispatcher em `app.py` permanecem iguais.

Depois do congelamento, a distribuição compacta é validada em processo novo a partir do ZIP extraído: 26 cartões nativos, foto, seleção exata, retorno/reabertura, 16 guardas do carregador, salvaguardas W e o fluxo R016 pesquisar → prévia → aplicar → backup → restaurar com cálculo/desenhos/Word nativos. O manifesto atual é criado apenas nessa distribuição. O recibo final fica fora do ZIP para não alterar o pacote já conferido; este documento descreve o protocolo, sem antecipar o resultado posterior dessa etapa.

## Limites

Testes focados, não a suíte inteira do aplicativo. AppTest não é clique físico nem validação visual em navegador. Não houve servidor, contorno de socket, publicação, push, deploy ou uso do computador do usuário. Não houve incorporação de fórmulas ou ativos Osdag, atualização normativa, expansão de domínio, fechamento de soldas ou retomada das duas talas. As limitações técnicas anteriores continuam aplicáveis.
