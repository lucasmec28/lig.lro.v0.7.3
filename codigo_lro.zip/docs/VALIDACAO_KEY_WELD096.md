# Validação da integração 0.9.6-key-weld-dev

Base de integração: código final 0.9.5-nmv-dev, já contendo a última correção da memória da emenda W convencional. Aplicou-se somente o delta declarado do componente de solda da chave, sem copiar os arquivos antigos da emenda W presentes no diretório de trabalho.

## Identidade e escopo

Permanecem as 11 famílias e suas identidades de projeto/componente. O aplicativo e seu carregador usam 0.9.6-key-weld-dev; a emenda W convencional preserva 0.9.5-w-conventional-dev. As duas bases mantêm schema_version=2 e seus connection_type próprios. Arquivos antigos sem single_key_weld carregam com o novo componente desligado.

Todos os módulos de produção preexistentes fora dos adaptadores declarados e da versão global permanecem byte-idênticos à versão final 095. A memória W convencional preservada tem SHA-256 0cda5e975b860b594636bb78cd8c12a215c5c570b0c0a943a4a045fd084ebe2a. Não se modificaram suas fórmulas, apresentação final ou identidade de projeto.

O novo resultado verifica somente o metal dos dois filetes e os requisitos locais de detalhamento no domínio documentado. Não aprova a ligação completa, a chave, o concreto/fundação nem a base. Metal-base junto à fusão e transferência/flexão da placa continuam separados. Falhas numéricas conhecidas não desaparecem por falta de execução/documentação.

## Evidência independente anterior à integração

- Revisão independente final: GO para o componente limitado; 159 testes passaram, incluindo 79 casos escritos independentemente, com 42 hashes estáveis entre início e fim.
- Comparação Decimal de quatro referências: erro relativo máximo da comparação de produção 3,876394098100557e−16. Derivação independente das referências confirma 47 valores a aproximadamente 6e−50.
- 479 testes focados de implementação e regressão adjacente passaram; após uma correção final exclusivamente da legenda de geometria inválida, 11 testes de artefatos passaram.
- Todas as 13 páginas da memória representativa e cinco diagramas foram inspecionados individualmente. A última correção não alterou os quatro diagramas válidos nem a memória completa.

Essa evidência é preservada como anterior à integração, sem relabelar os artefatos históricos como ensaio agregado da nova versão. A revisão e os hashes estão em validation/v096/independent_review. Exemplos numéricos e QA de artefatos estão em validation/single_key_weld.

## Verificação integrada

A primeira bateria integrada passou: 90 testes em 72,88 s. O smoke portátil também passou na fonte real 096, verificando bytes reais Word/JSON e ambas as famílias. A revisão independente da integração passou 28 testes em 56,62 s, confirmou os 78 arquivos de produção contra o congelamento e a preservação dos módulos/testes 095 não afetados, sem bloqueios.

O agregado completo terminou com 1641 testes aprovados em 1103.07 s, código de saída 0. Todos os arquivos de produção e testes permaneceram byte-idênticos entre o início e o fim; não houve emenda de código durante o agregado. Os logs terminais e os dois congelamentos estão em validation/v096. A fonte final 095 usada como base também permaneceu intacta. Documentos e cópias da evidência terminal foram finalizados depois, sem modificar produção ou testes.

O smoke portátil recebe como argumento o diretório de código ou do pacote bootstrap, captura os bytes reais exportados em JSON/Word e verifica ambas as famílias, seleção da chave, pass/fail, reversão, V=0, equivalência perna/garganta, invalidação/recuperação de execução e memória, além das 11 famílias e da versão ativa.

Empacotamento, publicação e upload pertencem à etapa de entrega, separada desta validação do código-fonte.
