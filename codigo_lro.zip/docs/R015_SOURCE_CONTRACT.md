# R015 / LCSP source and mechanics contract

Originally verified 2026-10-09. Source-boundary reconciliation 2026-10-10 (0.9.16), using the supplied R015 audit evidence. This is an independent source/model audit, not a signed connection design. No production engine was imported to derive the fixtures. Release 091 was read-only.

## Findings that determine implementation

1. R015 is welded at the BEAM WEB and bolted at the W-column FLANGE. The support bolt group has one shear plane per bolt, with one vertical bolt line per angle. There is no beam-web hole, no common double-shear web bolt, and no reason to deduct a fictitious web-hole diameter from the beam or welded angle leg.
2. Gerdau2018 p19 Fig1b and p50 explicitly show three welded edges per beam leg: upper transverse branch, vertical toe, lower transverse branch. The heel is open. This is a U/C-shaped group in the web plane. Industrial R015 printed p18 agrees on interface; it does not dimension the start/end positions of every weld.
3. Explicit actual weld endpoints are therefore required. The historical dimension b76 and beam gap10 do not automatically prove every transverse weld has exactly66mm of uniform effective length. A fixture with x_start10 is a clearly stated geometric idealization, not a measured weld length. The proposed baseline x_start20, toe76, height260 is likewise a defined analytical fixture.
4. Use two identical groups, each with V/2 and its eccentric moment. With x from support face into beam, y downward, and support reaction line x0, the per-angle group demand is F=V/2 and M=(0-xbar)F. Neither symmetry nor external M=0 removes this in-plane moment. Symmetry removes the pair's out-of-web-plane imbalance.
5. The support bolts remain under direct conventional flexible-connection shear in this bounded case. That is the documented flexible LCSP idealization, not an assumption of zero geometric eccentricity everywhere. Arbitrary extended support gauge, one angle, unequal angles, axial force, imposed moment, torsion, copes, fatigue or support-web geometry need their own model.
6. NBR allows the traditional flexible idealization with responsibility for appropriate rotation and restraints. Do not demand FEA generically. Do not turn a user checkbox into a strength/rotation calculation.

## Sources actually inspected

- Supplied `references/Automação MC/PADRÃO DE LIGAÇÕES-2Model.pdf`, printed p18 (one very wide PDF page). The cropped source image `../source/R015_printed18.png` was visually inspected. It identifies R015, bolts M16/M20/M24/M30, e35/40/50/60, s50/60/75/90 and N intervals. Bolt count per line is N+1, not N. Z is the indicated clear height, not automatically angle length. Two angles at beam web are welded, support legs bolted to column flange.
- Supplied `references/Automação MC/Manual Gerdau Ligações para Estruturas de Aço.pdf`, 7th edition2018, printed/PDF pp9,19–27,50. Pages19 and50 visually rendered in this folder. P19 defines the topology and calls both LCPP and LCSP flexible. P20 gives geometric/length provisions. P21 gives LCSP checks. P26 expressly requires eccentric-weld ICR analysis, citing AISC13 Table8-8. P50 depicts three beam-leg welds, 5mm, L76x76x6.4x230, gap10 and support gauge45. It is a historical2008 design, not current2024 strengths.
- Supplied `baseplate_references/Automação MC/NBR 8800-24-25-projeto-de-estruturas-de-aco-e-de-estruturas-mistas-20250710-000231_compress.pdf`. Printed pages+22=PDF pages. Source images/OCR reused from `tmp/shear-key-verification/nbr-097` through`104`, and`116`–`118`; Table9 and Table11 visually checked this pass. General flexible model clauses read from earlier independent R016 verification: printed69–71/PDF91–93.
- Supplementary primary AISC article, Modern Steel Construction July2016, “Keeping Fillet”: https://www.aisc.org/globalassets/modern-steel/archives/2016/07/keeping.pdf . Search index exposed the relevant base-metal discussion and Fig3 description. Direct PDF open returned403, so no page-number or full-PDF visual review is claimed. It specifically supports comparing base-metal shear-rupture line capacity with the C-shaped double-angle beam-web weld when the local web path cannot be directly calculated. This is supplementary mechanical support; NBR coefficients are recomputed independently.
- Supplementary primary AISC360-16, J2.2 user note / commentary: https://www.aisc.org/globalassets/aisc/publications/standards/a360-16-spec-and-commentary_june-2018.pdf . Indexed text identifies limited end returns specifically on the OUTSTANDING support leg and notes beam-web angle welds are not end-loaded axial welds. Direct PDF fetch unavailable; no whole-file validation claimed.

## NBR weld rules in this route

- 6.2.2.2, printed75: effective area = effective throat times actual uniform effective length. Ordinary orthogonal equal-leg fillet throat=w/sqrt(2). Do not add the submerged-arc allowance without the specified process. Full uniform weld length includes returns; there is no general mandatory 2w end deduction.
- Same clause: long end-loaded/nonuniform longitudinal joints have beta=clamp(1.2-0.002L/w,0.6,1.0), with L_eff=180w above300w. Do not confuse the elastic group's moment-induced line-force variation with the end-loaded shear-lag phenomenon. Baseline260/4=65 means beta1 even under a conservative application. If a future case enters that reduction range, implement the effective geometry/weights coherently or stop at the exact missing long-weld model.
- Table9, printed78: use resultant line-force magnitude and q_Rd=0.6*f_w*(w/sqrt(2))/gamma_w2. gamma_w2=1.35 for normal/special/construction and1.15 for exceptional combinations. The present fixtures use1.35. No directional strength enhancement is included, and no ICR coefficient is claimed.
- Table9 note(d): nonuniform weld stresses are checked per unit effective length; where Table8 gives two weld-strength classes, use the higher class. For A36 with E60/E70 options this route uses E70. Material/process compatibility remains required.
- Table9 refers FILLET BASE METAL to6.5. It does not itself prescribe the penetration-weld0.6fy*A_MB equation for a fillet. Do not cite the wrong table row.
- Table11 and6.2.6.2.1, printed80: minimum leg based on THINNER joined base part: t<=6.3→3;6.3<t<=12.5→5;12.5<t<=19→6; t>19→8mm. Table11 single-pass condition applies.
- 6.2.6.2.2, printed80–81: maximum along an edge is t for t<6.3, otherwise t−1.5mm, unless the drawing specifies reinforcement during execution to achieve the desired full throat. Thus angle6.4+5mm weld exceeds plain-edge4.9; do not round this away or use a generic “approved” checkbox. Gerdau historical5mm alone does not establish the current reinforced-edge execution detail.
- 6.2.6.2.3: the integral-leg route adopts at least4w and40mm. The clause also permits limiting the effective leg considered to25% of length. This alternative is not implemented: shorter segments are ENGINEERING_MODEL_PENDING, not a universal normative prohibition or automatic DETAIL_FAIL; the geometric leg/throat is not silently reduced. Baseline transverse56 and vertical260 satisfy both. Intermittent weld6.2.6.2.4 has its own segment minimum and is outside this continuous-U route.
- 6.2.6.2.5: overlap at least5 times thinner thickness and25mm. Beam overlap b−gap66 in the baseline; weld start is not a substitute for physical overlap.
- 6.2.6.2.6: terminations, tension-edge setback, cyclic returns and common-corner interruptions depend on actual detail. For flexibility-required projecting elements, added returns cannot exceed4w. The full upper/lower branches in the documented beam-side U are the load-carrying transverse welds, not automatically the support-leg returns discussed by this rule. R015 has no support-leg weld. A new weld around the heel or on the projecting support leg changes the model and is not silently included.

## Elastic group calculation and independent fixtures

For line segment i of length li, midpoint(ci_x,ci_y), equal throat:

- L=sum(li); xbar=sum(li*ci_x)/L; ybar=sum(li*ci_y)/L.
- J_line=sum(li*((ci_x−xbar)^2+(ci_y−ybar)^2)+li^3/12).
- Fx=0; Fy=V/2; M=(x_load−xbar)*Fy.
- qx=−M*(y−ybar)/J_line.
- qy=Fy/L+M*(x−xbar)/J_line.
- q=sqrt(qx^2+qy^2). For a straight segment q^2 is convex, so its maximum occurs at an endpoint. Check every segment endpoint; no sampling approximation is needed for the maximum.
- Aw=throat*L and Jw=throat*J_line, equivalently stress=q/throat.

For U geometry height260, x20–76, V200kN, w4 and fw490:

- L372mm; centroid(67.569892473,130)mm; J_line3448107.182795699mm^3.
- Per-angle moment−6.756989247kNm.
- qmax442.683062837N/mm at either open U endpoint; q_Rd615.968573834N/mm; utilization0.718678000.
- Weld pair-equivalent V_Rd278.288746755kN.
- ReversingV flips every qx,qy andM while preserving all magnitudes. Loaded support edges reverse separately.
- Artificial concentric control x_load=xbar gives q268.817204301; it is only an anti-regression fixture, not R015 support geometry.

The Python script uses exact segment integrals and a separate composite-Simpson integration to confirm force and moment equilibrium, including zero moment about support line. No production module or earlier fixture module is imported. The JSON also covers shorter transverse branches, thin web, minimum45kN demand, historical230mm idealization and asymmetrical support edges.

## Base metal and physical paths

Each beam leg is unholed. Support leg is holed. Retain their separate6.5.5 gross/net shear checks and support-leg6.5.6 actual blocks. The gross beam-leg root shear section uses its actual full height and thickness; the support leg net section deducts only its own holes.

The shared beam web is one physical plate, not two. Identical opposed groups have coincident in-plane tractions. Per-angle comparison must allocate t_web/2, or sum both demands against full t_web. Compare rupture line traction against0.6*fu*t_alloc/gamma_a2. This is a conservative comparative local base-metal model supported by the AISC explanation, using current NBR6.5.5 material resistance. It is not an invented beam-web block surface.

An additional conservative elastic yielding screen is q <= fy*t_alloc/(sqrt(3)*gamma_a1). For a membrane cut with normal traction qn and tangential tractionqt, sqrt(qn^2+3qt^2)<=sqrt(3)*q. Thus this bound limits combined local normal/shear elastic stress without claiming that0.6fy*q is an exact von-Mises interaction. This supplemental conservative screen is distinct from normative gross-section0.6fy*Agv/gamma_a1 and rupture checks. It is not a complete through-thickness stress-field solution.

For baseline angle6.4 fy250/fu400, web5.8 fy345/fu450:
- Angle line rupture1137.777777778N/mm; conservative yield bound839.782209730N/mm.
- Shared-web per-angle line rupture580N/mm; conservative yield bound525.126313022N/mm.
- The latter produces equivalent V237.247076794kN and utilization0.843003011 at200kN. It is a conservative added local screen, not the historic Gerdau limit state.

Global beam-web6.5.5 shear uses unholed area, without fictitious holes. Also retain the beam member's shear-buckling check where applicable. Gerdau's beam-web block-L formula p25 is explicitly for coped beams. In the first uncut W route, its supposed upper/lower free edge is absent; do not reuse the angle end as a beam free edge. Copes/openings create a different physical path and must leave this route.

## Support load path and sign

For positive downwardV: beam applies downward load to angles, while support bolts apply upward load to their support legs. Therefore support-angle bearing/blocks use TOP edge; column bearing/blocks use real LOWER column end. ReverseV uses bottom angle/top column end. Use finite actual end distance, real lateral flange edge and hole ligaments. Do not assign the angle's end as a column free edge.

Column flange has two independent bolt rows. Its local load is in its own plane. Check actual bearing/tearout and plausible outboard L blocks to each lateral edge and actual column end. A central block crossing the continuous flange–web junction is not a freely detachable plate. Transverse flange bending, web crippling and prying are not automatically invoked by pure in-plane vertical shear; an axial beam force/out-of-plane force reopens them.

The column receives the sumV as local axial increment and a transported global moment because it is applied at the flange face. Record the physical load point and r×F for global member analysis. Local R015 approval does not check column buckling, the building frame, other simultaneous connections or beam-to-column integrity tie forces.

## Historical discrepancies and bounded gaps

- Gerdau p22 LCSP example says W360x39 with two copes has301kN, but p50 gives282kN for that row;301 belongs to W360x44.6. Flag the inconsistency rather than bless the p22 number.
- P50's uncut339kN is2008/ICR and may be governed by a component other than the weld. It must not be an equality target for this elastic2024 model.
- The supplied industrial detail does not provide a fully dimensioned fabrication weld termination drawing or an independent modern whole-connection worked example with current NBR coefficients. These precise references remain unavailable. That does not block the traceable explicit-geometry elastic component model.
- A supported partial result is acceptable if an applicable detail or physical path cannot be verified. Record the exact item. Do not replace a missing endpoint/detail with mandatory FEA or generic “reference missing.” Do not make an unsupported global approval.

## Additional verification: E70 and in-plane angle cut

NBR TableA.4, printed130/PDF152, was subsequently visually checked from `tmp/column-base-weld/nbr-152.png`: class70 is485MPa (class60 is415, class80 is550). Fixture490MPa is an explicit synthetic material value and MUST NOT be labeled the NBR E70 default. Added fixture `R015_U260_56_w4_E70_485_V200_down` gives q_Rd609.683180223N/mm, utilization0.726087052, weld pair-equivalent V_Rd275.449065666kN. TableA.3 on the same page gives A325 fub830MPa; support-fixture825 is explicit synthetic input, not a grade conversion.

A conservative in-plane beam-leg section check can be made without abandoning the flexible LCSP idealization. Integrate actual top/bottom weld tractions against the support force. For x before transverse weld start s, Vcut=F and Mext=F*x. For x=s+u, define qa=F/L+Mw*(s−xbar)/J, k=Mw/J, c=Mw*H^2/(2J):

- Vcut=F−2*qa*u−k*u^2.
- Mext=F*x−qa*u^2−k*u^3/3+c*u.

The c term is the bending couple from opposite horizontal qx tractions on upper/lower welds; omitting it breaks equilibrium. Evaluate extrema by endpoints and roots of dM/du=F+c−2qa*u−k*u^2 and dV/du=−2qa−2k*u. Then an intentionally conservative envelope is sigma_max=6*Mmax/(t*H^2), tau_max=1.5*Vmax/(t*H), sqrt(sigma_max^2+3*tau_max^2)<=fy/gamma_a1. Maxima are permitted to be noncoincident because this is an upper-bound screen; no full section plastic capacity is claimed.

The independent script numerically reintegrates tractions at every candidate section to verify these resultants. BaselineV200kN gives Vmax100000N, Mmax2870596.047887570Nmm at x74.74190187016569mm, sigma39.810411167MPa, tau90.144230769MPa, VM161.129810588MPa, utilization0.708971167. This explicit rational elastic supplement closes the in-plane moment bookkeeping; it is not stated to be a formula printed in Gerdau.

## Implementation audit result

The completed `connections_work092/source/lro/welded_double_angle.py` was compared with this independent oracle using `compare_r015_implementation.py`. Result: 233 assertions passed. Coverage includes all eight line-group fixtures, every endpoint q vector, centroid and moment integrals, seven independent angle-cut envelopes, actual E70=485MPa capacities, shared-web accounting, current A325830MPa, support-angle sign reversal and all four prefix blocks,45kN floor, no fictitious web bolts/holes, JSON topology tamper rejection, and fail-closed out-of-scope/adversarial inputs. The exact audited engine and oracle SHA256 values are retained in `r015_implementation_comparison.json`.

The implementation corrected the long-weld reference to6.2.2.2(d), declares its100w domain as an implementation bound, and added physical overlap6.2.6.2.5. Weld start is physically bounded by the beam end x_start>=gap; crossing the angle root's simplified region is a model-pending issue rather than proof of physical impossibility. Weld continuity/geometry remains explicit.

No unclosed applicable strength-model issue was found for the declared conventional uncut, symmetric, V-only route after those changes. This audit does not validate arbitrary extensions, process qualification, structural analysis, production fabrication, or a building-level design. Independent numerical component verification and bounded analytical local approval are the extent of the result. Historical geometry and strengths remain separate and their discrepancies are disclosed above.

## Source reconciliation 0.9.16 (supplied audit of 2026-10-10)

- The same supplied industrial PDF now has R015 printed18 explicitly registered in fontes.json, alongside the existing R016 entry. No newly recovered industrial file is claimed.
- P901-23W full supplied file is available (SHA256 ec25b52e1d7b6b9ec9e5eaccc27452153208784d7d715908daa2595dd8f92423). II.A-2A PDF580/IIA-40 welds the support leg and bolts the beam web: reversed interfaces. II.A-5 PDF615/IIA-75 uses a coped beam welded to angles and support bolts in another beam web. Neither is a whole-connection oracle for this uncut beam to column-flange R015.
- Souza, example10.1 PDF134–138, Figs10.4–10.7, uses L64×6.3 and VS/CVS in a different elastic end-moment idealization, transmitting bolt tension/lateral moment. It is relevant as an alternative, not confined to unrelated axial/gusset examples. Its forces and historical coefficients are not stacked onto the current flexible LCSP/NBR route. No missing rule requiring replacement of the chosen method was demonstrated.
- NBR6.2.6.2.3 and the 36mm branch evidence require accurate method-boundary wording. The100w limit also remains a method bound without universal prohibition. Neither correction implements weighted segments, an effective-leg branch or a long-weld model.
- Gerdau2018 pp19,21,26,50 and supplied NBR PDF97,100,102–103,112,152 were checked in the supplied audit. That evidence does not turn historical2008/ICR capacities into current elastic-NBR targets. The AISC Keeping Fillet full-PDF attempt remained403; no new integral reading is claimed here.

Twenty finite fixtures agreed in10,088 independent numeric/state comparisons before correction. The0.9.16 correction preserves their numerical resistant outputs and repeats them in a copied audit harness. The short36mm branch only changes classification; it remains without approval.
