# Independent 8ES interface and export acceptance

ACCEPTED for the finite 8ES interface/export scope. All calculated cases preserve current inputs, source qualification and complete case rows. The independently found zero-input active-end presentation issue was corrected and the affected actual AppTest/artifact path passed. The final packaged-loader result will be appended below when the package is built.

This reviewer made no production-code edits, Library uploads or deployments. The independent engine/source review is separate; no complete mechanics suite was repeated.

## Current source and evidence

SOURCE_MANIFEST.json and FINAL_ARTIFACT_IDENTITY.json bind the final-source checks to exact hashes. Runtime code was explicitly frozen by the implementation owner in review0924/SOURCE0924_RUNTIME_FREEZE_RECEIPT.json. Principal hashes at the completed artifact replay:

- app.py: b2c6f44aec608d851ea3582a131ab3111970092721b91816c96bf82e8cf341ea
- lro/models.py: 1d12a98e0e07173d13e09551d1bd163c9922cea7950e38435910a1e237140faa
- lro/guided_selection.py: d696ab7d866f09c0adbc75e5570c1933aed1ede84d14696d198a095f3f159d84
- lro/end_plate.py: 19cefa9a24703fe6184bf5ca06194a85a7ff6b8880b8916108e3a67f4adf1a50
- lro/end_plate_ui.py: 4b1286eae124705307967c08356f370f0a0ba9109a20467463614a43e98d50fa
- lro/end_plate_drawing.py: c08dee1bdac2dad7f774e10eb64a00f1c532ba3eb0cd65aedee26ce40977e9bb (final zero-input presentation correction)
- lro/end_plate_report.py: a709c88b2e43a6649998f1ffe7e50be30a70fdb5f6a4cdec53c41b88d7e4e9da

## Actual workflows and qualified test accounting

The runner is test_acceptance.py. It uses actual Streamlit AppTest widgets and the native file uploader/open callback. Registered download bytes are observed through Streamlit's real memory-media storage; no application callbacks, imports, results or exports are mocked.

The runner was corrected incrementally for reviewer assumptions, so there is intentionally no claim that the first whole pytest invocation passed. Original logs/JUnit files remain intact:

1. pytest_initial_harness.log: 1 passed, 3 failed in 39.44 seconds. The actual draft/legacy workflow completed. The other three stopped on reviewer-only assumptions: exact equality across N↔kgf round trips, reading st.write through AppTest's text collection rather than markdown, and expecting unlocalized Word substitution strings.
2. pytest_final.log: 3 passed, 1 failed, 1 deselected, 1 teardown error in 82.19 seconds. All 20 native atomic rejections, public export forgery/physical geometry, and targeted guide/extreme-pb workflows completed. The capture helper expected compact Word to include every substitution; compact correctly includes every case row while detailed includes every substitution. The source hash guard also correctly caught the owner's exact-diameter engine validation fix during this run. SOURCE_MANIFEST_diameter_delta.json preserves that evidence; the atomic matrix was not needlessly repeated.
3. pytest_capture_final.log: 2 passed, 1 failed, 2 deselected in 55.90 seconds, on stable final engine 19cefa9 and drawing 10ddfc9. The draft/legacy and targeted guide/extreme-pb nodes passed. Positive compact and negative unequal-pitch detailed captures completed all identity and case-row assertions before the following moment-only capture reached a reviewer assumption that N/A UI ratios should be numeric zero. The application correctly displays a blank/NaN for nonapplicable rows.
4. pytest_remaining_cases.log: the unfinished five case captures all completed and saved receipts; the node then stopped in the reviewer helper because it tried to parse the deliberately invalid zero input using the strict native importer. The application had already displayed zero non-green with no checks and disabled/hidden Word. A direct construction of the live invalid input is required for inspection, not an importer that correctly rejects it.
5. pytest_zero_recovery.log: 1 passed, 4 deselected in 8.54 seconds; only the zero live-control recovery was run.
6. check_final_identity.py then verified all eight registered captures against the final frozen production engine and artifact code. Native JSON equals freshly reevaluated canonical JSON; canonical PNG bytes equal saved PNG bytes; registered UI PNG pixels equal the canonical image or its exact bilinear resize. All seven downloaded Word document.xml parts and embedded PNG bytes equal a fresh canonical export. This passes with stable before/after hashes in FINAL_ARTIFACT_IDENTITY.json.

RECEIPT.json is incremental and records which complete assertions finished before each reviewer-harness stop. No incomplete node is relabeled a passing pytest test. The completed UI behavior is supported by those receipts plus the final canonical replay, not by adding unrelated or partial test counts together.

## Accepted behavior

- The application still has 14 families. 8ES is the third internal endplate moment variant, alongside 4E and 4ES.
- First activation of 8ES changes only variant identity. It preserves the actual member profiles, forces, materials and dimensions, and does not turn inherited 4E geometry into a passing 8ES project. The practical 8ES example is loaded only through explicit selection and the actual Carregar exemplo button.
- Separate 4E, 4ES and 8ES drafts preserve custom thickness, notes, project labels, dimensions and actions through repeated variant transitions and pinned/moment family navigation. Old 4ES remains the four-row/eight-physical-bolt detail, while 8ES is genuinely eight-row/sixteen-physical-bolt geometry.
- Exact native 8ES upload preserves arbitrary pb and stiffener-length precision. Only the established floating-point N↔kgf round trip can differ by a tiny numerical unit. Imported forged approval fields are discarded and recalculated.
- Ten missing fields (pb and all nine stiffener fields) and ten malformed/topology cases reject atomically. Tests included boolean/string/infinite/zero pb, nonboolean compatibility/clearance, unsupported stiffener weld/electrode, one-sided layout and extra intermediate rows. The live project, model, per-variant drafts, prior Word and actual downloadable JSON remain unchanged.
- Editing pb hides stale Word. A fresh Word contains the new digest. Switching variants hides the previous variant's Word; revisiting 8ES retains its edited pb rather than restoring old geometry.
- Positive and reversed negative moment produce correct active-end row identities. Negative unequal pfi/pfo/pb and signed N/V remain signed; the supplemental 45 kN case scales N/V together and retains M.
- Moment-only has one complete case and no invented minimum-force direction. A minimum-force axial-domain departure retains all 26 actual-case checks, records the required supplemental case as unresolved with zero checks, and leaves the whole connection non-green.
- A finite overload is non-green with actual resistance failures. A pfo source-range departure is non-green and source-unqualified without inventing material overload. An undeclared CJP route is non-green and unqualified despite favorable numeric ratios. Zero input is invalid, non-green, has no checks, and cannot generate or expose stale Word.
- Normal captures contain 26 primitive rows per calculated case and 22 display envelopes. UI envelope names, outcomes, demands, resistances, ratios and governing-case labels match current canonical complete rows. Both compact and detailed Word contain every primitive case row with matching Sd/Rd/unit/ratio/outcome. Detailed Word also preserves all case-specific substitutions.
- JSON, SVG, registered PNG and Word bind to current input digests/revisions. Word embeds the exact current canonical drawing. Public Word ignores a forged/unrelated supplied result, and native JSON import ignores forged verification. Drawing entry points accept only current inputs and always reevaluate them.
- Extreme finite pb=1e308 remains stored unchanged. The drawing is explicitly diagnostic-only, contains no invented proportional geometry or bolt artists, and Word stays disabled.

## Routing and unchanged legacy evidence

The implementation owner's current review0924/evidence/routes0924.xml reports 14 direct AppTest family starts plus one guide-catalog assertion (15 passed). It is not described here as fourteen actual guide-open flows. The independent reviewer additionally exercised actual endplate guide filters, confirmed selection alone did not navigate, and clicked the explicit open button. The app differs from accepted 0.9.23 only in version-gate strings; the guide differs only in the moment-endplate description, retaining all routing IDs/tags/order. Therefore a redundant full fourteen-guide matrix was not repeated.

The existing qualified welded-W native upload still passes, its default remains NOT_VERIFIED, and its project remains isolated from endplate drafts. WELDED_W_UNCHANGED.json proves all five welded-W production modules are byte-identical to accepted 0.9.23. Owner evidence artifacts/LEGACY_DRAWING_COMPARISON.json also records byte-identical default 4E/4ES PNGs after restoring their exact old caption. Independent actual old4E/4ES navigation/draft checkpoints passed on final source hashes.

## Visual inspection

Actual registered positive and negative-unequal PNGs, actual negative-unequal SVG raster, finite-failure/source-outside/zero PNGs and the extreme-pb diagnostic PNG were inspected. The calculated views show sixteen physical bolts, eight actual active tension bolts, the four real inside/outside pb spans, all four arms to the correct compression pivot, two physical stiffeners and four real CJP runs. Default hst=40+70+35=145 mm; unequal-pitch capture shows hst=148.375 mm and hp=753.75 mm. CJP leaders meet their intended connected interfaces and avoid text/polygon overlaps. No continuity plates, column stiffeners, fictitious column-reinforcement credit or 4E extension-shear rows are introduced.

The N/V/M arrows are explicitly positive-reference arrows; the actual signed input values and active flange are separately shown. They are not claimed to flip direction with the numerical sign. SVG raster inspection used a local renderer with font substitution; canonical/registered PNGs carry the production font rendering.

The actual downloaded Word files were rendered, not substituted by owner-generated files. RENDER_REVIEW.json records hashes, page counts and selected pages:

- Positive compact: 12 pages; inspected 1, 3, 8 and 10. Current profiles/forces, full geometry, domain/same-steel CJP route, actual/minimum cases, complete rows, four-arm Yp/Yc expressions and distinct column coefficients are legible.
- Negative unequal-pitch detailed: 19 pages; inspected 1, 9, 12 and 17. Lower active rows and pivot, actual negative actions, four unequal arms, physical partial/full plate blocks and source equations are legible.
- Minimum-case-outside compact: 11 pages; inspected 1 and 8. The unresolved whole-connection status is clear while complete valid actual-case evidence remains visible.

No clipping, broken glyphs or overlapping content was seen on those selected pages. This reviewer does not claim full pixel inspection of all pages; the Word owner separately reviewed all default compact/detailed pages and verified final-source XML/image equivalence.

## Boundaries

This is finite local AppTest/export acceptance, not a browser/HTTP/deployed-site test or fabrication approval. No full mechanics or source-equation suite was rerun. The source route remains ordinary static in-plane service, same qualified beam/plate/stiffener steel and compatible CJP, with the disclosed DG39 November 2024 errata review limitation.

## Zero presentation disposition

Fixed and accepted. The owner made an 8ES all-zero-only drawing correction. pytest_zero_final.log/junit_zero_final.xml record the actual AppTest recovery: 1 passed, 4 deselected in 8.52 seconds, with stable final source hashes. The actual registered image and SVG now have sixteen neutral physical bolts, no invented tension end, no active-arm artists or compression pivot, and an unavailable maximum index. The zero status remains red/invalid and Word remains disabled/hidden. Positive-reference M is still explicitly labeled as a reference arrow. Original zero artifacts are retained in zero_before_fix/ for the finding history.

The owner's ZERO_FIX_PARITY.json confirms byte-identical valid positive/negative 8ES and prior 4E/4ES PNGs; the independent final artifact replay also verifies all eight current captures and all seven valid Word XML/image payloads against final code. No completed atomic-import or mechanics matrix was repeated for this presentation fix.

## Actual outer-loader smoke

Prepared at outer_smoke/run_outer_smoke.py. Waiting for the parent's final package and exact outer/inner hashes; it has not yet been run. It will be one small fresh-process actual-loader smoke with downloaded 8ES artifacts, complete-row identity, atomic missing-pb rejection, old4ES/weldedW checkpoints and byte matching of the executed inner app and every loaded LRO module. It will not repeat the mechanics or broad UI matrix.
