# Independent engine acceptance: finite 8ES CJP

GO for the bounded engine implementation reviewed on 2026-10-11.

- Engine: `review0924/source0924/lro/end_plate.py`
- Tested SHA256: `19cefa9a24703fe6184bf5ca06194a85a7ff6b8880b8916108e3a67f4adf1a50`
- Independent result: **253 passed, 0 failed**
- Hash was identical before and after the final run.
- Reusable runner: `run_acceptance.py`
- Machine-readable receipt: `acceptance_results.json`

These are 253 named independent checks, some containing multiple comparisons. They are not the owner's pytest count. No owner tests, full suite, UI inspection or document rendering are counted in this receipt.

## Verified

- Accepted Table 5-16 and A-5(a) oracle vectors, exact coefficients, independent plate/column effective widths, inches/mm and additional length scaling. Forty-eight fresh asymmetric kernel cases supplement the original vectors.
- Four physical tension arms, pfi/pfo caps confined to Yp, unchanged physical c and coordinates, sixteen physical bolts/eight active tension bolts, both moment signs, T=8Tb, V/16 and component-specific flange/contact/column demands.
- Actual and 45 kN minimum-force cases, complete-row envelopes, signed N/V/M, preserved actual evidence when the required minimum case leaves its axial domain, and unchanged M when N/V are scaled.
- All sixteen partial/full plate block paths and actual-hole bearing for three pb values. Geometry changes propagate to extension, all rows, source kernels and web-transfer lengths.
- Strict de<s one floating-point step below/at/above the boundary; both required-thickness gates independently, including exact required thickness and adjacent representable values; real thin-plate/column cases; source-range qualification boundaries.
- CJP material/receiver/compatibility/access/thickness/length/real-run prerequisites, no-hole rupture invariant, no fictitious fillet minimum, and recommended landing dimensions kept distinct from mandatory checks.
- Changed lwt=pfi+pb+152.4 and disjoint lws geometry; real-web-length boundaries without nonexistent area or deduction of both alternative tension regions.
- No 4E-only extension shear rows and no ordinary-service failure from the high-seismic stiffener slenderness equation.
- Required import fields, malformed/nonfinite/oversize-number data, input identity, forged approval snapshots, fixed topology, catalog-diameter diagnostics and preservation of dormant legacy fields without adding 8ES geometry requirements.

The all-catalog fixture passes with independently verified actual Yp=5685.85831631679 mm, Yc=4102.054024211062 mm, required plate=7.910907025989466 mm and required column flange=9.313729259824717 mm. The required minimum-force case is separately verified.

## Bounded corrections closed

1. Initial engine hash `6e5871534f45989867be714cb125a87dd92a117317c0a0fb55f6b45a2bc96c9f` accepted near-catalog diameters through the inherited tolerance check, then raised KeyError at an exact edge-distance lookup. The owner added an 8ES-only exact nominal-catalog input guard. Both one-ULP neighbors of all seven catalog diameters now produce data diagnostics, and imports reject them without silently normalizing input. This is a native catalog-format condition, not a physical resistance or DG39 applicability failure.
2. Intermediate engine hash `68b84d932f55732c2abcfecf85b2989828a0799aa28e139438f7a7c7fbcb5b51` still applied positive legacy weld/pitch/overhang and n-range restrictions to the fixed 8ES topology. The owner removed these semantic restrictions for 8ES only while keeping numeric/type/finite hygiene. Zero and negative finite values of each dormant field preserve exact result/geometry equality and round-trip values. The eight reproduced pre-fix failures are saved in `pre_dormant_fix_results.json`.

Both corrections are conditional on the 8ES branch. Production changes were made by the owner; this reviewer wrote only this independent acceptance directory. No further engine fix is requested.

## Remaining release boundary

This receipt accepts the engine within the previously accepted finite source contract. It does not independently claim the owner's full legacy suite, UI/export QA, release packaging or deployment. Those remain separately recorded evidence. The source-example width exceedance, p257 inconsistent substituted arms and unavailable November 2024 errata retain the disclosures in the source qualification; this engine acceptance does not expand their scope.
