# Independent source qualification: finite DG39 8ES CJP branch

Reviewed 2026-10-11. GO for the exact finite contract in `../CONTRACT_8ES_CJP.md`, with the corrected `../practical_fixture.json` (A325 `fub=830 MPa`). This is source/model qualification, not production-engine acceptance, a release claim, or approval of a project connection. No production files were edited. Existing 4E/4ES behavior remains outside the authorized change scope.

## Scope accepted

One centered doubly symmetric I beam, perpendicular to one continuous unstiffened I-column flange; ordinary static signed in-plane M/N/V. Symmetric 8ES geometry has eight physical vertical rows, two bolts per row, sixteen total bolts, and exactly eight active tension bolts per moment case. Both external stiffeners are identical, centered on the web, with continuous compatible CJP at both interfaces. No extra/intermediate rows, one-sided detail, thin-plate/prying solution, seismic/cyclic/fatigue qualification, column end/cap/continuity/doubler configuration, opposing beam, composite slab participation or axial-dominant solution is accepted.

The existing NBR resistance basis, declared beam/column restraint and panel-axial assumptions, material/product limits and actual/minimum complete-case treatment remain explicit. This review does not introduce an arbitrary new bolt-pitch testing envelope or import seismic restrictions.

## Independently verified equations and geometry

Printed DG39 Table 5-16 p119 was read from pixels. With physical arms

`h1=d-tf/2+pfo+pb`, `h2=d-tf/2+pfo`, `h3=d-3tf/2-pfi`, `h4=d-3tf/2-pfi-pb`,

and `sP=sqrt(bp_eff*g)/2`, `po=min(pfo,sP)`, `pi=min(pfi,sP)`, the exact equation is:

`Yp=bp_eff/2*[h1/(2de)+h2/po+h3/pi+h4/sP] + 2/g*[h1*(de+3pb/4)+h2*(po+pb/4)+h3*(pi+3pb/4)+h4*(sP+pb/4)] + g`.

The strict selected-table applicability condition is `0<de<sP`. Equality is outside this branch. Only the pfi/pfo terms within Yp are capped. Bolt coordinates, four arms, c, pb, stiffener height, web-transfer length and all physical hole deductions retain their input dimensions.

Printed Table A-5(a) p269 and Fig A-5(a) p270 were read from pixels. `c=pfo+tf+pfi=h2-h3`, `sC=sqrt(bcf_eff*g)/2`, and:

`Yc=bcf_eff/2*(h1/sC+h4/sC) + 2/g*[h1*(pb+c/2+sC)+h2*(pb/2+c/4)+h3*(pb/2+c/2)+h4*sC] + g/2`.

The h2 coefficient is literally c/4 and the h3 coefficient is literally c/2. Eq 6-17 repeats this. Do not symmetrize them, reuse the 4E/4ES column equation, or interchange sP and sC. The effective plate and column widths are independently limited by beam flange width plus max(tp,25.4 mm), per the accepted Eq 4-3 interpretation. Physical widths remain in physical section and detailing checks.

The coordinate list in the accepted contract has all eight rows and preserves the central separation `d-2tf-2pfi-2pb`. Coincident or crossed inner groups cannot be made valid by sorting. Minimum/maximum spacing, actual hole ligaments, edge distances and assembly clearances must use all eight physical rows. Negative moment reflects the active group and compression pivot, retaining the same ordered arm magnitudes in the symmetric arrangement.

## Forces, qualification gates and local transfer

- Per active bolt: `Tb=Meq/[2*(h1+h2+h3+h4)]`; `T=8Tb`, `C=max(T-N,0)`. The primary-group shear allocation is `abs(V)/16`, combined with tension on the active eight bolts under existing NBR interaction. The remaining eight physical bolts carry their allocated shear. No elastic h/sum(h²) tension distribution is substituted.
- `Meq=abs(M)+max(N,0)*(d-tf)/2`. Both plate and column flange must pass the accepted required-action thick-plate convention. Valid source/domain/CJP-stiffener prerequisites are an additional necessary condition. A plate-only thickness pass is insufficient to qualify a no-prying bolt result.
- The required-action sizing route is supported by DG39 p49 and Eq 5-4. It must not be silently changed into a full-bolt-capacity thickness hierarchy or represented as a claim about ultimate failure behavior.
- `Ff=abs(M)/(d-tf)+max(N,0)/2`, `Fc=abs(M)/(d-tf)+max(-N,0)/2`. Column web yield receives max(Ff,Fc), compression crippling receives Fc, and contact receives C. DG39 pp46-48 connects these column-local comparisons to the flange force. Do not substitute bolt resultant T or invent max(T,Ff).
- DG39 8ES Example 5.3-7 p186 explicitly uses four web-adjacent tension bolts out of eight. Thus web local demand remains Ff/2, while its physical length is `lwt=pfi+pb+152.4 mm`. The shear length is `lws=min(d-2tf-lwt,(d-2tf)/2)`, as explicitly demonstrated p187. These are disjoint per static case. Do not deduct both possible opposing tension regions from the same case.
- Retain local beam-web yielding, the compatible CJP local tension development minimum, actual remaining web shear transfer, main flange CJP development and the whole-section check. The latter does not replace the local mechanisms. A nonexistent web transfer area cannot be credited.
- Required 45 kN resultant cases scale N/V while retaining M. Case-specific axial-domain failure must block overall completion without erasing valid actual-case evidence. Envelopes select complete rows, including source, case and qualification.

## CJP route and exclusions

Both stiffener interfaces have direct 8ES source support: p185 explicitly names CJP as an alternative for stiffener-to-flange and stiffener-to-endplate welds. The ordinary-service discussion on p45 states the same options and the distinct tensile/shear development directions.

The already reviewed NBR Table 8/Table 9 compatible-CJP route can therefore be reused, limited to the same qualified beam/endplate/stiffener steel, no holes in these weld regions, `ts>=tw*fyb/fys`, `ts<=min(tp,tbf)`, explicit process/preparation/electrode compatibility, and the no-hole design rupture/design yield invariant. Column steel may differ within its existing checks. The finite E7018/class 70 route uses fw=485 MPa; a numerical fw threshold alone is insufficient to prove compatibility. Development is compared consistently at design-strength level, rather than comparing nominal yield to its own reduced resistance.

Use the source 30-degree detail as an explicitly adopted finite-detail condition: `hst=pfo+pb+de`, `Lst>=hst/tan30°`. Actual CJP connected runs are `hst-clip` and `Lst-clip`, both positive. The corner clip clears the completed main weld and never contains a fictitious weld. Approximately 25.4 mm landings are a fabrication recommendation and default; they are not subtracted again from connected runs and are not a universal NBR minimum. No fillet leg/minimum-length rule applies to this CJP route. Preserve valid polygon, weld access, preparation and construction sequence.

Source p43 assigns Eq 3-37 stiffener slenderness to high-seismic ductility. It is not an ordinary-service failure. Source p184 expressly removes shear yielding and rupture of the extended plate portion from stiffened extended plates. Neither these 4E-only rows nor invented full-stiffener-compression/gusset/punching rows belong in the finite 8ES result. This does not waive actual receiving-beam/plate strength or execution prerequisites.

## Domain is distinct from resistance and recommendations

Table 5-9 p112 applies its tested ranges with plus/minus ten percent. In mm, the accepted intervals are:

- pfi,pfo: 22.86 to 69.85
- extension pext: 57.15 to 209.55
- gauge: 62.865 to 195.58
- beam depth: 360.045 to 2011.68
- plate width: 114.3 to 286.385
- beam flange thickness: 8.5725 to 27.94

There is no independent pb tested-range entry. The four-wide go entry is irrelevant. Actual NBR detailing and real ligaments still apply to pb. Departure from a tested range is extrapolation/unqualified method, not a fabricated material-overload result. The strict de<sP equation condition is separate and cannot be relaxed by the source's general discussion of other large-edge mechanisms.

## Examples: exact reproduction and source limitations

Example 5.3-7 exact geometry gives:

- h = [41.18,37.43,32.49,28.74] in, sP=4.0620192023 in
- Yp=545.7165088958 in, sum(ni hi)=279.68 in
- db,required=1.2481835578 in; tp,required=1.0172144703 in
- Web local tension demand=330.3775743707 kip; lwt=11.75 in; lws=17.01 in
- Stiffener required thickness=0.625 in; hst=7.5 in; Lst,required=12.9903810568 in

Its printed rounded h values and s=4.06 give Yp=545.5776372593 in, matching displayed 546. Using displayed Yp=546 and sum(ni hi)=280 reproduces tp=1.0169503597 in and db=1.2474701062 in, displayed as 1.02 and 1.25.

That source example has bp=12 in, exceeding the Table 5-9 plus-ten-percent ceiling of 11.275 in. It also defers its column checks. It is a component oracle, never a whole-app passing/default connection.

The separate p257 column component has a printed-substitution inconsistency. The literal substituted arms [41.4,37.4,32.5,28.5] produce Yc=370.7307866192 in, rather than displayed 370. The p251 rounded physical arms [41.2,37.4,32.5,28.7] give 370.3161199525 in, and exact physical geometry gives 370.3473197387 in, both consistent with displayed 370. The oracle records all three separately. No equation coefficient or seismic action/factor was changed to force agreement.

## Practical catalog fixture

Exact member dimensions were read independently from immutable `review0922/source0922/data/profiles.json`. Beam W460x74: d457,bf190,tw9,tf14.5,clear404 mm. Column W360x122(H)*: d363,bf257,tw13,tf21.7,clear288 mm. Catalog qualification still requires checking actual supplier stock, as the catalog itself states.

All selected steel is A572 Gr.50, fy345/fu450 MPa. Plate bp210,tp12.7 mm, gauge140,pfo40,pfi45,pb70,de35 mm. A325 3/4-inch bolts have current catalog fub830 MPa. Two 9.525 mm CJP stiffeners have hst145,Lst275,clip/landing25.4 mm. M=100 kNm, V=40 kN, N=2 kN, with the required minimum-force case enabled.

Independent actual-case values:

- Yp=5685.85831631679 mm; Yc=4102.054024211062 mm
- Required plate=7.910907025989466 mm; column flange=9.313729259824717 mm
- Tb=28534.801136363636 N; T=228278.4090909091 N; C=226278.4090909091 N
- lwt=267.4 mm; lws=160.6 mm
- Actual connected stiffener runs=119.6 and 249.6 mm; required Lst=251.1473670975 mm

The minimum-force case has N=2247.1927624751506 N, V=44943.855249503016 N, unchanged M, required plate=7.913060495338131 mm and column flange=9.316264598745642 mm. Both remain inside the axial domain. All Table 5-9 intervals are satisfied. The hierarchy is 9<=9.525<=12.7 mm, and fu/gamma_a2>=fy/gamma_a1.

Notably, this ordinary-service fixture exceeds the inapplicable Eq 3-37 high-seismic slenderness limit. It is a useful regression against accidentally importing that restriction. These calculations qualify the source route and specific new mechanisms; later engine acceptance must verify every retained resistance, all actual holes/blocks and exports.

## Independent runner and next acceptance boundary

`check_oracle.py` has no application imports and edits no production files. Its executed output is `independent_oracle.json`. It passes eleven independent groups: exact/rounded source plate and bolt kernels; literal/consistent column example; exact catalog geometry and CJP hierarchy; individual/both pitch caps preserving physical arms; inches/mm scaling; fourteen exact source-domain boundaries; de one floating-point step below/at/above s; twelve combinations of signed M/N/V; actual/minimum axial-domain separation; five plate/column/stiffener no-prying gate cases; and actual-row collision detection.

Nine reusable kernel vectors and twelve signed-load vectors are included. They are independent numerical expectations, not a claim that isolated kernel inputs pass every assembly-clearance or source-domain check.

The accepted contract's bounded implementation tests remain required, especially mutation detection for missing +g/wrong pb fractions/wrong column coefficient, all sixteen physical holes in bearing/block calculations and drawing/export, source qualification propagation, real web-length boundaries, exact new input identity, and unchanged delivered 4E/4ES regressions. A later separately requested independent engine pass will inspect those results.

## Source identity and edition control

The source PDFs are the supplied 2023 volumes. SHA256:

- Part 1: `1348d0279880afe41f78309c442e0da3f07f2353e7620edab13c6a2e8598b702`
- Part 2: `31a0f92f16743a97171375e7b61e4c405b1298fdc0b2c6873b68fc9cd379af74`

Part 1 PDF page = printed page +10; part 2 PDF page = printed page -195. Equation/diagram pixels were inspected, including a separately rendered p257 stored here. The previously unavailable November 2024 errata was not fetched again, and no claim is made that it was reviewed. This known edition-control limitation remains disclosed in the accepted route.

GO for this finite implementation contract. No remaining weld-alternative or source-equation decision is open.
