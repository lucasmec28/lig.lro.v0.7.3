# GO: source-qualified DG39 8ES CJP contract

2026-10-11. Qualification only. No production implementation has been changed. Delivered 4E and 4ES are immutable for this work. One new 8ES branch is the full bounded expansion; this is not a general multirow, flush, thin-plate, prying, or seismic module.

## Decision and finite scope

GO for this finite DG39 8ES contract, independently accepted in independent_review/REVIEW_8ES.md. Subsequent production implementation acceptance remains required. Use ordinary static signed in-plane M/N/V, a centered doubly symmetric I beam perpendicular to the flange of one continuous unstiffened I column, symmetric endplate extensions and two identical external stiffeners. No nearby column end/splice/opening; no opposing beam or concurrent concentrated column load, continuity plates, doubler plate, participating slab, weak-axis moment, horizontal shear, fatigue/cyclic/seismic qualification, or axial-dominant case. Keep the existing column lateral restraint, beam restraint, and panel axial-force assumptions explicitly stated.

The source provides an unstiffened-column model specifically for the eight-tension-bolt/four-row topology: Table A-5(a), p269. Beam-side stiffeners provide no reinforcement credit to the column. A finite column failure is a failed unreinforced connection; it must not trigger invented reinforcement or automatic approval.

## Source identity and pixel citations

Supplied DG39 (2023), part1 Library libfile_ed93bc93f054819187eafa28f853b6cc and part2 libfile_d2c004e7e2508191897ba4ed127dc278. Files remain in ../next_endplate_scope. For part 1, PDF page = printed page + 10. For part 2, PDF page = printed page - 195. The following actual rendered pages were inspected; files are relative to this directory:

- source_pixels/part1_pdf129.png: printed119, Table 5-16, complete geometry, four tension rows, plate equation, strict de < s, both pitch caps, and no-prying bolt model.
- source_pixels/part2_pdf74.png and part2_pdf75.png: printed269–270, Table A-5(a) and Fig. A-5(a), continuous unstiffened eight-bolt/four-row column model.
- source_pixels/part1_pdf190.png through part1_pdf198.png: printed180–188, Example 5.3-7. Geometry and symmetric 16-bolt detail p181; stiffener height/length p182; bolt/plate kernel pp183–184; CJP alternatives and development directions p185; local web tension and available shear length pp186–187; column checks referred elsewhere p188.
- source_pixels/part1_pdf53.png: printed43, Eq. 3-36 and explicit seismic-only scope of Eq. 3-37.
- source_pixels/part1_pdf55.png: printed45, ordinary-service CJP/groove stiffener option, tensile/shear development directions, and disjoint web tension/shear transfer zones.
- source_pixels/part1_pdf59.png: printed49, BOTH endplate and column-flange thick-plate conditions and significance of tested-range departures.
- source_pixels/part1_pdf61.png, part1_pdf62.png and part1_pdf63.png: printed51–53, gauge/width, both effective widths, weld sequence, clip, 30-degree detail, and approximately 1-in landings.
- source_pixels/part1_pdf122.png: printed112, Table 5-9 tested ranges and ±10%, no separate pb range, warning that large de changes mechanism.
- source_pixels/part2_pdf22.png and part2_pdf62.png: printed217/257, literal same unstiffened-column equation and a numerical component illustration. Only this geometric Yc cross-check is used; NO seismic demands, factors, conditions or design procedure are adopted.

The supplied DG39 November 2024 errata remains unverified after the already-known 403. It was not fetched again. This is an edition-control limitation, not a claim that the errata has no relevant correction. Official publication identity was corroborated at https://www.aisc.org/news/aisc-releases-end-plate-moment-connection-design-guide/; it is not a substitute for the supplied equation pixels.

## Physical topology and coordinates

8ES means EIGHT ACTIVE TENSION BOLTS. This symmetric first branch has SIXTEEN physical bolts: eight vertical rows, two bolts per row at x=±g/2. It does not have eight total bolts, and it is not 4ES plus arbitrary credited intermediate bolts.

Let y=0 at the top beam outer face and y increase downward. One positive-moment convention puts the upper flange in tension. The eight physical row coordinates are:

1. -pfo-pb
2. -pfo
3. tf+pfi
4. tf+pfi+pb
5. d-tf-pfi-pb
6. d-tf-pfi
7. d+pfo
8. d+pfo+pb

Endplate extension hst=pext=pfo+pb+de at each end; total plate height hp=d+2hst. pb is the equal physical separation between the two outside rows and the two inside rows of EACH flange group. pfi and pfo may differ; the entire top detail is reflected at the bottom. All eight rows are primary, with zero intermediate rows. Reject inconsistent topology, one-sided layout, additional rows, coincident/crossing rows, and nonpositive physical ligaments. Do not silently sort crossed groups into an apparently valid group.

For top tension, rows 1–4 are active, ni=2 each; the compression pivot is y=d-tf/2:

h1=d-tf/2+pfo+pb
h2=d-tf/2+pfo
h3=d-3tf/2-pfi
h4=d-3tf/2-pfi-pb
c=pfo+tf+pfi=h2-h3

Require all four hi positive, h1-h2=pb, h3-h4=pb, and inner group separation d-2tf-2pfi-2pb>0 with actual bolt spacing/clear-ligament checks. For negative M the lower four rows are active in reversed physical order, about the upper compression flange. Their ordered arms are numerically identical in a symmetric detail. Drawing, report and JSON must identify the actual active end and all four arms, not retain h1/h2-only labels.

## Exact plate and column kernels, units and no-prying conditions

All lengths in a kernel use the same unit. Yp and Yc have dimension length. With fy in N/mm² and thickness in mm, fy*t²*Y is Nmm. Never insert inches in the production N/mm/MPa kernel.

Effective widths retained from DG39 Eq. 4-3:

bp_eff=min(bp,bf_beam+max(tp,25.4mm))
bcf_eff=min(bf_column,bf_beam+max(tp,25.4mm))

Use bp_eff for plate and bcf_eff for column. Physical widths remain in drawings, actual edge distances, contact areas and physical net sections.

Table 5-16 p119:

sP=sqrt(bp_eff*g)/2
po=min(pfo,sP); pi=min(pfi,sP)
Yp=bp_eff/2*[h1/(2de)+h2/po+h3/pi+h4/sP]
   +2/g*[h1*(de+3pb/4)+h2*(po+pb/4)+h3*(pi+3pb/4)+h4*(sP+pb/4)]+g

STRICT 0<de < sP. Equality is outside this finite Table 5-16 branch. This was verified directly for 8ES; it is not transplanted from 4ES. Cap only pfi/pfo inside Yp. Do not cap actual row coordinates, hi, c, pb, extension or web-transfer length.

Table A-5(a) p269:

sC=sqrt(bcf_eff*g)/2
Yc=bcf_eff/2*(h1/sC+h4/sC)
   +2/g*[h1*(pb+c/2+sC)+h2*(pb/2+c/4)+h3*(pb/2+c/2)+h4*sC]+g/2

The h2 c/4 and h3 c/2 coefficients are literal and pixel-verified. Eq. 6-17 p217 repeats them. Do not substitute the 4E/4ES Table A-2 equation; do not substitute a stiffened-column expression or transplant plate sP into column sC. Require finite positive Yp/Yc.

For each complete actual/minimum-force case, retain the established conservative NBR/DG39 thick-required convention:

z=d-tf
Meq=abs(M)+max(N,0)*z/2
thick_required(M,fy,Y)=sqrt[1.10*M*max(gamma_a1,1/0.90)/(fy*Y)]
gamma_a1=1.10; gamma_r=1.0

Plate tp must meet thick_required(Meq,fyp,Yp) AND column tfc must meet thick_required(Meq,fyc,Yc). Source/domain/stiffener qualification must ALSO be valid. Only then may bolt tension/interaction be called qualified without prying. Plate plastic resistance remains fyp*tp²*Yp/gamma_a1; keep the full independent numeric evidence while consolidating the proved plate display redundancy. Do not substitute thickness sized against full bolt resistance when the adopted source procedure sizes against required action; do not claim behavior at ultimate failure or a moment-rotation curve.

## Forces and complete cases

For one tension bolt: Tb=Meq/[2*(h1+h2+h3+h4)]. There are 8 active tension bolts, so T=8Tb and contact C=max(T-N,0). This is the equal-tension thick-plate model in Table 5-16; do not use an elastic hi/sum(hi²) distribution.

Retain the existing finite NBR shear allocation to ALL primary physical bolts: Vb=abs(V)/16, including the 8 tension bolts, with full NBR tension/shear interaction on the active group. The other 8 carry only allocated shear. This is the established NBR combined-force allocation, distinct from the optional DG39 compression-side-only shear simplification. No additional bolt credit. Bearing and every partial/full plate block must use the actual 8-row holes and corresponding physical loads. Do not retain divisions by 8 total or 4 active from 4ES.

Beam flange and local column forces:
Ff=abs(M)/z+max(N,0)/2
Fc=abs(M)/z+max(-N,0)/2
Local column web yield demand=max(Ff,Fc); column crippling demand=Fc; contact uses C. Panel force remains abs(M)/z+abs(N)/2 under the declared existing panel scope. Do not substitute bolt resultant T for Ff or add a fictitious max(T,Ff) load.

Retain actual and required 45 kN resultant-force cases as COMPLETE separate cases. f=max(1,45000/hypot(N,V)) when a nonzero resultant and minimum option applies; multiply N,V by f, leave M unchanged. Check abs(N)*z<=abs(M) separately for each required case. If the minimum case leaves domain, preserve valid actual results but the whole connection remains unresolved. For zero N,V retain the existing explicit moment-only handling. Reversal means separate static ±M cases with mirrored active flanges and identical resistance envelopes; it is not seismic/cyclic qualification. Do not select a demand from one case and resistance/qualification from another. Preserve export/input identity and complete source substitutions.

## New web-transfer geometry; retained components

Example 5.3-7 pp186–187 directly gives ntrib/n=4/8. Therefore local tensile web demand remains Ff/2, but lwt CHANGES to pfi+pb+152.4mm, measured from the active flange inner face. The region must fit in physical hw=d-2tf; no resistance for nonexistent web.

lws=min(hw-lwt,hw/2), positive where nonzero shear is present. CJP web tension and shear regions are disjoint PER load case, mirrored for reversed M. Do not deduct both opposing possible tension regions from one static case. Retain local beam web yielding, compatible CJP tension-development minimum max(Ff/2,0.60*fyb*tw*lwt), CJP shear on lws, and connected-base-metal hierarchy. Main flange CJP keeps the existing local flange force/minimum-development check, and the whole-section elastic combined-stress check does not replace these local checks.

Retain the existing qualified beam shear/compactness, column web yield/crippling, column panel and contact checks, bolt grip/material/hole conventions, bearing, and actual-hole partial/full plate block tearout model. Generalize only row count/geometry/forces and relevant citations. Stiffened-extension shear yielding and shear rupture are NOT limit states (p184); remove/N/A those 4E-only rows, do not show invented passed checks. Do not introduce an unrelated full-stiffener-compression or generic gusset check.

## Compatible-CJP stiffener route

DG39 p45 and 8ES example p185 expressly permit CJP at both stiffener interfaces. Reuse the already independently qualified NBR Table 8/Table 9 route from ../next_endplate_scope/FINAL_4ES_CJP_CONTRACT.md ONLY for its applicable same-steel compatible-CJP provisions:

- Same qualified steel for beam, endplate and both stiffeners. Column steel may differ within its own qualified checks. This is a finite implementation restriction, not a normative prohibition of mixed steels.
- ts>=tw_beam*fy_beam/fy_stiffener (Eq. 3-36) and ts<=min(tp,tf_beam). No holes in stiffeners or connected weld regions. Check actual fu/gamma_a2>=fy/gamma_a1 for the material; gamma_a2=1.35.
- Continuous full penetration and compatible preparation/process/electrode explicitly declared at both interfaces. Retain the finite E7018/fw485 MPa route for qualified A36/A572 Gr42/A572 Gr50. fw>=all connected Fu alone does not prove process compatibility.
- Plate-side CJP develops stiffener design tensile yield qT=fys*ts/gamma_a1 N/mm. Beam-flange-side CJP develops design shear yield qV=0.60*fys*ts/gamma_a1 N/mm. Same-material receiver hierarchy supports full development. Compare at the same NBR design-strength level; no tautological nominal-yield-versus-reduced-yield failure.
- hst=pfo+pb+de. Adopt Lst>=hst/tan30deg from Eq. 4-4 and Fig. 4-3, also checked by this ordinary-service example. Both stiffeners centered on beam web. Beam web/endplate weld is completed before beam flange/endplate weld, and beam flange is welded before stiffeners are installed.
- Diagonal equal-leg corner clip c: plate-side actual run=hst-c; flange-side actual run=Lst-c; both positive. No weld through the clip. The clip must provide verified clearance/preparation/access. Default clip 25.4 mm is a practical detail, not a universal mandatory minimum.
- Default end-landings 25.4 mm follow source recommendation; they shape the free edge and are not deducted again from connected runs. Retain physical positive non-self-intersecting polygon and meaningful clip/landing dimensions. Do not impose a fillet minimum-length/leg rule on CJP.
- DO NOT impose hst/ts<=0.56sqrt(E/fys) as an ordinary-service pass/fail rule. p43 explicitly assigns Eq. 3-37 to high-seismic ductility despite the worked example checking it. Endplate stiffeners are not ordinarily designed to resist compression in this rotational model.

No fillet, PJP, mixed-steel receiver, seismic slenderness, or alternative gusset model is being added. The already-qualified CJP hierarchy avoids redundant invented receiver punching/block checks, while preserving the real receiving plate/beam mechanisms and execution prerequisites.

## Source domain versus mandatory detailing

Table 5-9 p112 tested ranges, inches before ±10%: pfi and pfo: 1–2.5; pext: 2.5–7.5; g: 2.75–7; d: 15.75–72; bp: 5–10.25; tf: 0.375–1. The ±10% range is the source design-equation envelope. Record out-of-range values as extrapolation/unqualified method, not a fabricated NBR resistance failure. The four-wide go range is irrelevant to two-wide 8ES. There is NO separate pb tested-range entry; apply real spacing, ligaments, row ordering and selected-mechanism geometry without inventing a pb cap.

Keep source material limits and existing rounded SI domain convention explicit: plate fy<=345MPa (50ksi); beam/column fy<=380MPa (55ksi); qualified A325/A490 catalog bolts and size range. Gauge<=beam flange width is the source force-path condition. Keep applicable NBR actual minimum/maximum bolt spacings and edge distances, using the 8 physical rows and positive actual ligaments. Existing supported maximum in protected contacting region is min(24*min(tp,tfc),300mm). Tool/weld/fillet-radius access interference remains a distinct practical check, not invented material failure. The CJP same-steel branch itself may restrict materials more tightly than source strength limits.

Do not label recommended approximately 25.4mm landings, the adopted 30-degree detail, or the tested ranges as universal mandatory NBR dimensions. Conversely, strict de < s is the selected Table 5-16 applicability condition and is not relaxed to the large-edge regime mentioned elsewhere.

## Practical catalog default and acceptance limits

Use practical_fixture.json, in N, mm and MPa:

- Beam W 460 x 74,0: d=457, bf=190, tw=9, tf=14.5, clear=404 mm.
- Column W 360 x 122,0 (H)*: d=363, bf=257, tw=13, tf=21.7, clear=288 mm.
- All four steel selections: ASTM A572 Gr.50, fy=345 and fu=450 MPa.
- Plate: bp=210, tp=12.7 mm. Gauge=140, pfo=40, pfi=45, pb=70, de=35 mm.
- Bolts: A325, 3/4 in diameter, threads included; catalog fub=830 MPa. Keep existing NBR hole, net deduction and grip conventions.
- Actions: M=100 kNm, V=40 kN, N=2 kN; minimum-force case enabled.
- Stiffeners: ts=9.525, hst=145, Lst=275, clip=25.4, landing=25.4 mm; declared compatible CJP with E7018 and fw=485 MPa.

Rows are [-110, -40, 59.5, 129.5, 327.5, 397.5, 497, 567] mm. The plate spans y=[-145, 602], with hp=747 mm. The central bolt gap is 198 mm, cross-flange gap 99.5 mm, repeated pb 70 mm, and plate side/top edge 35 mm. Arms are [559.75, 489.75, 390.25, 320.25] mm. sP=85.7321409974 mm and sC=86.8274150254 mm; de=35 mm is safely inside the strict source domain. Stiffener runs are 119.6 and 249.6 mm, required Lst=251.1473670975 mm, and 9 <= 9.525 <= 12.7 mm satisfies the thickness hierarchy. lwt=267.4, hw=428 and lws=160.6 mm.

Executed source-equation values are Yp=5685.85831631679 mm and Yc=4102.054024211062 mm. Actual-case required plate/column flange thicknesses are 7.91090702599 and 9.31372925982 mm. Tb=28534.8011364 N, T=228278.409091 N and C=226278.409091 N. The 45 kN case has proportional factor 1.12359638124. Column web local yielding governs the independent practical physical-resistance screen at ratio 0.933422917955.

This is a source-equation/catalog fixture, not an already-tested release or project approval. Read-only 4ES retained-check screening found every listed retained resistance passing; its 338 mm central-gap detailing failure disappears only when the actual 8ES rows are included. The new geometry-dependent calculations independently screen all 16 top/bottom partial plate blocks, bolt forces/interaction, hole bearing, plate and column thicknesses, local web/CJP transfer, contact and column web yielding for both actual and minimum cases. See screen_practical_fixture.py and practical_screen.json. Production 8ES acceptance must still verify every row/case and qualification gate. No reference example is assumed to be a whole-application pass.

## Oracles and exact example qualifications

Example 5.3-7, pp.180–187 uses the following inch-unit geometry: d=35.9, tf=0.940, tw=0.625, bf=bp=12, tp=1.125, g=5.5, pfo=pfi=2, pb=3.75, de=1.75 and db=1.25 in. Its material/action data are fy=50 ksi, Fnt=90 ksi and Mu=23100 kip-in. Exact arms [41.18, 37.43, 32.49, 28.74] in give Yp=545.716508895827 in, required db=1.248183557819 in and required tp=1.017214470273 in.

Source-rounded arms [41.2, 37.4, 32.5, 28.7] and s=4.06 in give Yp=545.5776372593 in, displayed as 546. Using the published Yp=546 gives tp_req=1.01695035975 in, displayed as 1.02. Using the published sum(ni*hi)=280 in gives db_req=1.24747010617 in, displayed as 1.25. Do not round internal production values to source display precision.

The example bp=12 in exceeds the Table 5-9 upper value of 10.25 in plus 10%, or 11.275 in. Its beam material/designation prose also differs from the proposed same-material catalog route. It omits actual column-side calculations and points to other examples. It is therefore only a plate/bolt/local-web component oracle, not an all-domain passing connection.

The column component illustration on p.257 has a printed-substitution inconsistency: h1=41.4 and h4=28.5 in are substituted where the underlying geometry gives 41.18 and 28.74 in, rounded to 41.2 and 28.7. The literal misprinted substitution with sC=4.21 gives Yc=370.730786619 in; correct rounded arms give 370.316119952 in; exact geometry gives 370.347319739 in, consistent with the displayed 370. Preserve this distinction. Table A-5 coefficients are not changed; neither seismic actions nor its 1.11/phi_d thickness procedure enters this branch.

## Bounded implementation acceptance

1. Reproduce independent plate/column source kernels in inches and converted SI, with exact versus published-rounded fixtures separately identified. Mutation tests must detect missing +g, wrong pb fractions, column c/4 changed to c/2, reuse of the 4E column formula, and sP/sC interchange.
2. Test the exact de < s boundary just below, equal and above; unequal pfi/pfo; and both pitch caps simultaneously/separately while keeping physical arms unchanged. Require positive finite kernels and flag unsupported geometry.
3. Verify exactly eight rows, 16 physical bolts and eight active tension bolts under both moment signs. Changing pb must change all four same-group spacings, hst, h1/h4, local web length and partial block holes. Reject extra/intermediate rows, one-sided 8ES, crossing inner groups and invalid input JSON without silently supplying missing new data.
4. Independently fail plate thickness, column thickness, source range, stiffener thickness/receiver/material/compatibility/access and actual connected runs. A numerical bolt pass must be explicitly unqualified when any no-prying prerequisite fails. Preserve finite resistance failures separately.
5. Test actual/minimum complete-case envelopes, minimum force leaving axial domain, both signs of N/V/M, and the distinctions between plate, contact and column forces. T=8Tb and Vb=V/16. Cases retain complete row identity and source substitutions.
6. Verify lwt=pfi+pb+152.4 and lws=min(hw-lwt,hw/2), including physical-length boundaries and reversal. No nonexistent web area, repeated inactive-tension-zone deduction, reinstated extension-shear check or seismic slenderness requirement.
7. Check CJP same-material hierarchy, ts boundaries, fu/fy invariant, actual receiver strengths, clip/landing geometry, continuous source welds and execution conditions. No fillet settings or fictitious Ff/2/(ts*hst) check.
8. Run the practical catalog fixture and overload/boundary cases. All delivered 4E/4ES regression inputs/results remain unchanged. Verify saved method revision, input digest, JSON recalculation and widget selection/export invalidation.
9. Visually inspect the real UI, compact/detailed Word, JSON and SVG/PDF as applicable: 16 actual holes, eight active bolts, four arms, correct pb/extension dimensions, two 145×275 mm CJP stiffeners, actual clip, no fabricated column reinforcement, and distinct new-variant title. Keep the nonredundant summary while preserving every numeric case/source branch.

The independent source oracle is independent_review/check_oracle.py, with executed outputs in independent_review/independent_oracle.json. It imports no application calculation code. It includes exact and source-rounded plate/bolt vectors, the correctly distinguished column-source vectors, nine kernel cases, 12 signed-action cases, five no-prying-gate cases, strict one-ULP edge boundaries, source range checks, topology checks and the catalog fixture. Additional retained-component screening is separately labelled and is not a production acceptance result. Source PDFs and actual inspected pixels are hashed in source_manifest.json.
