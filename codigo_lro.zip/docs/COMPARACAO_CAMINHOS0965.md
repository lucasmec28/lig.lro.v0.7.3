# Comparação de caminhos de carga da nervura interna

## Pergunta considerada

Comparar duas hipóteses completas e adotar a mais conservadora por componente: toda a ligação pela alma da coluna ou toda a ligação pelos dois horizontais. Não se escolhe a hipótese favorável para cada peça. Cada utilização deve ser calculada com as componentes concomitantes N/V/M da mesma hipótese; a envoltória é aplicada às utilizações completas.

## Modelos comparados

1. Três bordas soldadas: grupo elástico ponderado pelas áreas de garganta, com nervura e apoios idealizados rígidos. É o modelo implementado na 0.9.65.
2. Somente borda da alma: os horizontais não recebem carga neste modelo idealizado. O cordão vertical recebe N, V e o momento completo.
3. Somente horizontais: a borda da alma não recebe carga neste modelo idealizado. Os horizontais recebem todas as forças e o momento. A componente vertical é perpendicular ao plano dos horizontais, exigindo verificação própria destes receptores.

Todos usam a mesma carga, geometria e excentricidade real. Momento na origem = V·pin_x; momento no centroide = momento na origem − xc·V + yc·N. As forças integradas de cada borda incluem também um binário local, pois substituir uma distribuição linear somente por uma força no ponto médio perde parte do momento.

## Resultado do oráculo independente

Foi feita integração por quadratura de Gauss independente da rotina de produção. Os 18 casos (seis conjuntos de ações em três modelos) fecham N, V e momento e coincidem com as integrais analíticas implementadas.

Utilização máxima das gargantas, com os mesmos materiais e filetes do preset:

| Ações | Três bordas | Somente alma | Somente horizontais |
|---|---:|---:|---:|
| Preset, incluindo mínimo resistente | 0,11577 | 0,25524 | 0,20453 |
| Axial 45 kN | 0,06019 | 0,09313 | 0,17016 |
| Cortante 45 kN | 0,11099 | 0,24370 | 0,19590 |
| N=70 kN; V=45 kN | 0,18202 | 0,38161 | 0,37636 |
| N=70 kN; V=−45 kN | 0,18202 | 0,38161 | 0,37636 |
| Cortante 200 kN, caso ilustrativo | 0,49329 | 1,08309 | 0,87065 |

O caso ilustrativo de 200 kN mostra diretamente a solda vertical isolada excedendo seu limite enquanto o grupo de três bordas não o excede. Isso compara somente as soldas: outros componentes da ligação podem não atender a essa carga.

Esses valores são solicitações/resistências das gargantas, sob as hipóteses indicadas. Não são índices da chapa inteira nem aprovação dos apoios.

## O que a envoltória permite concluir

A maior utilização por componente entre as duas hipóteses é uma envoltória dos dois modelos examinados. Neste conjunto de casos, as hipóteses isoladas penalizam mais as soldas que a distribuição de três bordas. Isso explica por que reprovar somente o cordão vertical, carregado artificialmente com tudo, não prova falha do grupo real.

A envoltória de duas soluções não demonstra automaticamente que toda distribuição real possível esteja contida entre elas. Para convertê-la em suficiência estrutural, ainda é necessário justificar a compatibilidade/redistribuição de forças com a rigidez dos horizontais, alma da coluna e nervura perfurada; verificar os receptores sob suas forças e momentos concomitantes; e tratar os estados-limite da chapa. A aplicação de um modelo de single plate também requer que suas condições geométricas e de introdução de carga cubram os parafusos internos deste detalhe.

Não foram acrescentadas duas verificações redundantes à interface nem concedida aprovação da nervura por esta comparação.
