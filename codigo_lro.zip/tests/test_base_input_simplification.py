from dataclasses import replace
import copy,json
import pytest
from lro.base_plate import BasePlate,presets,DETAIL
from lro.pinned_base_plate import PinnedBasePlate
from lro.column_base_weld import MODEL_QUALIFIED
from test_base_plate_catalog import app,button,FIXED,PINNED


@pytest.mark.parametrize('family,prefix,loader',[(FIXED,'bp',BasePlate),(PINNED,'pp',PinnedBasePlate)])
def test_spacing_and_grout_adoptions_are_separate(family,prefix,loader):
    at=app(family)
    at.number_input(key=prefix+'_a1').set_value(45.).run()
    at.number_input(key=prefix+'_a2').set_value(110.).run()
    at.number_input(key=prefix+'_grout_t').set_value(67.).run()
    label='Adotar a₁/a₂ da Tabela 18' if prefix=='bp' else 'Adotar a₁ da Tabela 18'
    button(at,label).click().run();assert not at.exception
    project=at.session_state['_base_plate_project' if prefix=='bp' else '_pinned_base_plate_project']
    c=loader.from_dict(project,validate_values=False);ref=DETAIL[at.selectbox(key=prefix+'_db_label').value]
    assert c.a1==ref['a1'] and c.grout_t==67.
    assert c.a2==(ref['a2'] if prefix=='bp' else 110.)
    button(at,'Adotar graute de referência da Tabela 18').click().run();assert not at.exception
    c=loader.from_dict(at.session_state['_base_plate_project' if prefix=='bp' else '_pinned_base_plate_project'],validate_values=False)
    assert c.grout_t==ref['en']


def test_block_editors_preserve_exact_imports_until_explicit_edit():
    c=replace(presets()['Chumbadores · arruelas soldadas'],anchor_type='headed',
        block_xmin=-510.123456789,block_xmax=801.345678901,block_ymin=-600.111111111,block_ymax=713.222222222)
    at=app();at.get('file_uploader')[0].upload('offset.json',json.dumps(c.to_dict()).encode(),'application/json').run()
    button(at,'Abrir placa de base JSON').click().run();assert not at.exception
    before=copy.deepcopy(at.session_state['_base_plate_project'])
    assert not at.checkbox(key='bp_block_centered').value
    for mode in ['coordinates','dimensions','coordinates','dimensions']:
        at.selectbox(key='bp_block_editor_mode').set_value(mode).run()
        assert not at.exception and at.session_state['_base_plate_project']==before
    at.selectbox(key='connection_family').set_value(PINNED).run()
    at.selectbox(key='connection_family').set_value(FIXED).run()
    assert not at.exception and at.session_state['_base_plate_project']==before
    L=c.block_xmax-c.block_xmin;B=c.block_ymax-c.block_ymin
    at.checkbox(key='bp_block_centered').check().run()
    now=BasePlate.from_dict(at.session_state['_base_plate_project'])
    assert now.block_xmin==-L/2 and now.block_xmax==L/2
    assert now.block_ymin==-B/2 and now.block_ymax==B/2
    at.number_input(key='bp_block_length').set_value(L+100.).run()
    now=BasePlate.from_dict(at.session_state['_base_plate_project'])
    assert now.block_xmax-now.block_xmin==pytest.approx(L+100.)


def test_conditional_controls_preserve_drafts_and_zero_v_washer():
    at=app(PINNED)
    assert not any(x.key=='pp_stiffener_detail' for x in at.selectbox)
    assert not any(x.key=='pp_anchor_shear_model' for x in at.selectbox)
    at.selectbox(key='pp_cc_model').set_value('aci318_19').run()
    at.number_input(key='pp_cc_force_a1').set_value(123.).run()
    at.number_input(key='pp_V_kgf').set_value(0.).run()
    assert not any(x.key=='pp_cc_force_a1' for x in at.number_input)
    assert any(x.key=='pp_uw_model' for x in at.selectbox)
    assert at.session_state['_pinned_base_plate_project']['connection']['concrete_components']['force_a1']==pytest.approx(123.*9.80665)
    at.number_input(key='pp_V_kgf').set_value(100.).run()
    assert at.number_input(key='pp_cc_force_a1').value==123.
    at.selectbox(key='connection_family').set_value(FIXED).run()
    # 094 intentionally exposes the qualified two-flange component in Type1.
    # Off remains the default; family selection does not qualify transfer.
    assert at.selectbox(key='bp_cw_model').value=='off'
    at.selectbox(key='bp_cw_model').set_value(MODEL_QUALIFIED).run()
    assert not at.exception
    assert at.button(key='bp_cw_bind_qualification').disabled
    current=at.session_state['_base_plate_project']['connection']['column_weld']
    assert current['model']==MODEL_QUALIFIED and current['qualification_signature']==''
