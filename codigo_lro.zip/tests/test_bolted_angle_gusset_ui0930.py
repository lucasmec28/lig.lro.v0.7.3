"""Actual Streamlit callbacks, native fidelity and cross-family lifecycle."""
from copy import deepcopy
from dataclasses import replace
import json
from pathlib import Path
import pytest
from streamlit.runtime.memory_media_file_storage import MemoryMediaFileStorage
from streamlit.testing.v1 import AppTest
from lro.angle_catalog import catalog
from lro.bolted_angle_gusset import BoltedAngleGusset, FAMILY, evaluate, presets
from lro.bolted_angle_gusset_ui import PROJECT,RESULT,DRAFT,REPORT,TEMPLATE,ACCEPTED,checks_complete,decode_project,import_ui_values,_key,_walk
from lro.welded_double_angle_gusset import FAMILY as WELDED_FAMILY, WeldedDoubleAngleGusset
from lro.welded_double_angle_gusset_ui import PROJECT as WELDED_PROJECT,RESULT as WELDED_RESULT,DRAFT as WELDED_DRAFT

RUNNER='''
import streamlit as st
from lro.bolted_angle_gusset import FAMILY
from lro.welded_double_angle_gusset import FAMILY as WELDED_FAMILY
family=st.selectbox('Família de ensaio',[FAMILY,WELDED_FAMILY],key='test_family')
if family==FAMILY:
    from lro.bolted_angle_gusset_ui import render
else:
    from lro.welded_double_angle_gusset_ui import render
render()
'''


@pytest.fixture
def media(monkeypatch):
    files={};original=MemoryMediaFileStorage.load_and_get_id
    def tap(storage,*args,**kwargs):
        file_id=original(storage,*args,**kwargs);files[file_id]=storage._files_by_id[file_id].content;return file_id
    monkeypatch.setattr(MemoryMediaFileStorage,'load_and_get_id',tap);return files


def fixture(**changes):return replace(next(iter(presets().values())),**changes)


def fresh(c=None):
    at=AppTest.from_string(RUNNER,default_timeout=120);at.session_state[PROJECT]=(c or fixture()).to_dict();at.run()
    assert not at.exception;return at


def button(at,text):return next(x for x in at.button if x.label==text)


def download(at,media,text):
    item=next(x for x in at.get('download_button') if x.label==text)
    return media[Path(item.proto.url).name.rsplit('.',1)[0]]


def upload(at,payload):
    if not isinstance(payload,bytes):payload=json.dumps(payload,ensure_ascii=False).encode()
    at.get('file_uploader')[0].upload('bolted-complete.json',payload,'application/json').run()
    button(at,'Carregar projeto completo parafusado').click().run();assert not at.exception


def test_native_fields_and_exports_are_current(media):
    c=fixture();at=fresh(c)
    assert at.session_state[PROJECT]==c.to_dict() and at.session_state[RESULT]==evaluate(c)
    assert checks_complete(at.session_state[RESULT]) and at.session_state[RESULT]['global_pass']
    keys={x.key for kind in ('number_input','text_input','text_area','checkbox','selectbox') for x in getattr(at,kind)}
    assert {_key(path) for path,_ in _walk(c.to_dict()['connection'])}<=keys
    assert decode_project(download(at,media,'Salvar projeto completo parafusado .json'))==c
    assert download(at,media,'Baixar desenho completo parafusado .png').startswith(b'\x89PNG')
    assert b'physical_hole_1' in download(at,media,'Baixar desenho completo parafusado .svg')
    button(at,'Gerar memória completa parafusada').click().run()
    assert download(at,media,'Baixar memória completa parafusada .docx').startswith(b'PK')


@pytest.mark.parametrize('corrupt',['unknown','missing','boolean','nan','duplicate','family','units','utf8'])
def test_rejected_import_is_atomic(corrupt):
    at=fresh();at.text_input(key='bag_project').set_value('Entrada protegida').run()
    button(at,'Gerar memória completa parafusada').click().run()
    saved={key:deepcopy(at.session_state[key]) for key in (PROJECT,RESULT,DRAFT,REPORT,TEMPLATE,ACCEPTED)}
    bad=deepcopy(saved[PROJECT])
    if corrupt=='unknown':bad['connection']['obsolete']=1
    elif corrupt=='missing':bad['connection'].pop('heel_extent')
    elif corrupt=='boolean':bad['connection']['N']=True
    elif corrupt=='nan':bad['connection']['theta_deg']=float('nan')
    elif corrupt=='duplicate':bad=json.dumps(bad).replace('"connection": {','"connection": {"N": 1,').encode()
    elif corrupt=='family':bad=WeldedDoubleAngleGusset().to_dict()
    elif corrupt=='units':bad['units']['force']='kN'
    else:bad=b'\xff!'
    upload(at,bad)
    assert any('Não foi possível abrir' in x.value for x in at.error)
    for key,value in saved.items():assert at.session_state[key]==value,key


def test_switch_1L_T_updates_native_topology_and_total_root_only_once():
    at=fresh();pair=deepcopy(at.session_state[RESULT]);button(at,'Gerar memória completa parafusada').click().run()
    at.selectbox(key='bag_arrangement').set_value('1L').run()
    assert not at.exception and REPORT not in at.session_state
    c=BoltedAngleGusset.from_dict(at.session_state[PROJECT]);single=at.session_state[RESULT]
    assert c.arrangement=='1L' and at.session_state[PROJECT]['fixed_assumptions']['physical_shear_planes']==1
    assert single['root']==pair['root']
    at.selectbox(key='bag_arrangement').set_value('2L-T').run()
    assert at.session_state[RESULT]==pair


def test_missing_heel_is_geometry_input_not_attestation_and_recovers():
    at=fresh(BoltedAngleGusset())
    assert not at.session_state[RESULT]['global_pass']
    assert at.number_input(key='bag_heel_extent').value is None
    assert not any('heel' in str(x.key) for x in at.checkbox)
    at.number_input(key='bag_heel_extent').set_value(12.35).run()
    at.text_input(key='bag_heel_extent_source').set_value('Medição de ensaio declarada').run()
    assert at.session_state[RESULT]['global_pass']
    at.number_input(key='bag_heel_extent').set_value(24.).run()
    assert not at.session_state[RESULT]['global_pass']
    upload(at,fixture().to_dict())
    at.number_input(key='bag_heel_extent').set_value(None).run()
    assert at.session_state[PROJECT]['connection']['heel_extent'] is None
    assert at.session_state[RESULT]['status']=='DETAILING_PENDING'


def test_exact_native_load_and_independent_materials(media):
    c=fixture(N=123456.78901234567);at=fresh();upload(at,c.to_dict())
    assert at.session_state[PROJECT]==c.to_dict()
    at.selectbox(key='bag_gusset_steel').set_value('ASTM A572 Gr.50').run()
    updated=BoltedAngleGusset.from_dict(at.session_state[PROJECT])
    assert updated.N==c.N and (updated.angle_steel,updated.support_steel,updated.bolt,updated.root_electrode)==(c.angle_steel,c.support_steel,c.bolt,c.root_electrode)
    assert decode_project(download(at,media,'Salvar projeto completo parafusado .json'))==updated


def test_all_50_gerdau_choices_and_out_of_default_small_section_preservation():
    at=fresh();at.checkbox(key='bag_include_small_angles').check().run()
    available=at.selectbox(key='bag_angle_profile').options
    from lro.angle_catalog import label
    gerdau=[identity for identity in catalog() if identity.startswith('GERDAU_')]
    assert len(gerdau)==50
    assert all(label(identity) in available for identity in gerdau)


def test_stale_artifacts_repeated_navigation_and_invalid_draft_isolation():
    at=fresh();button(at,'Gerar memória completa parafusada').click().run();word=at.session_state[REPORT]
    at.run();assert at.session_state[REPORT]==word
    at.checkbox(key='bag_report_detailed').check().run();assert REPORT not in at.session_state
    at.number_input(key='bag_plate_width').set_value(-240.).run()
    assert not at.exception and REPORT not in at.session_state and not at.session_state[RESULT]['global_pass']
    draft=deepcopy(at.session_state[DRAFT])
    at.selectbox(key='test_family').set_value(WELDED_FAMILY).run();assert not at.exception
    at.text_input(key='wdag_project').set_value('Soldada preservada').run()
    welded={key:deepcopy(at.session_state[key]) for key in (WELDED_PROJECT,WELDED_RESULT,WELDED_DRAFT)}
    at.selectbox(key='test_family').set_value(FAMILY).run();assert not at.exception
    assert at.number_input(key='bag_plate_width').value==-240. and at.session_state[DRAFT]==draft
    for key,value in welded.items():assert at.session_state[key]==value
    at.number_input(key='bag_plate_width').set_value(240.).run()
    assert checks_complete(at.session_state[RESULT]) and REPORT not in at.session_state


def test_overflow_withdraws_all_old_artifacts_and_recovers():
    at=fresh();button(at,'Gerar memória completa parafusada').click().run()
    at.number_input(key='bag_N_kN').set_value(1e308).run()
    assert not at.exception and at.session_state[RESULT]['status']=='NUMERICAL_FAILURE'
    assert PROJECT not in at.session_state and REPORT not in at.session_state and not at.get('download_button')
    at.number_input(key='bag_N_kN').set_value(100.).run()
    assert at.session_state[PROJECT]['connection']['N']==100000.
    with pytest.raises(ValueError):import_ui_values(fixture(N=5e-324))


def test_main_app_complete_route():
    app=Path(__file__).resolve().parents[1]/'app.py'
    at=AppTest.from_file(str(app),default_timeout=120);at.session_state['connection_family']=FAMILY;at.run()
    assert not at.exception and at.session_state[PROJECT]['connection_type']=='bolted_angle_gusset'
    assert at.session_state[RESULT]['status']=='DETAILING_PENDING'
