"""Bounded welded two-root compression. Frozen oracle is test data only."""
from copy import deepcopy
from dataclasses import replace
import hashlib
import json
import math
from pathlib import Path
import pytest
from lro.corner_gusset import CornerGusset, analyze, geometry, presets, MATERIALS, ANGLE_CATALOG
from lro.corner_compression import reduction, declare_current_detail, geometry_stamp, RESTRAINT_FIELDS

ROOT=Path(__file__).resolve().parents[1]
ORACLE=json.loads((ROOT/'docs/qualification_corner_compression0935/ORACLE.json').read_text())
def cc(P=-100000., **kw):
    return declare_current_detail(replace(CornerGusset(),P=P,**kw),'Test detail: current ordinary corner relief, continuous effective roots and symmetric welded overlap physically restrained.')
def rows(r):return {x['id']:x for x in r['checks']}
def issues(r):return {x['id'] for x in r['issues']}

@pytest.mark.parametrize('filename,digest',[
 ('COMPRESSION_CORNER_CONTRACT.md','1ece7177739f6050ce7349a1eb6f27b3fe2189628296ab5b352bdf909e1bcd92'),
 ('FIXTURE_INPUT.json','8baa55d87805e7331d20d04b0ea5bce7da3297e491031152707b10a896b376f4'),
 ('ORACLE.json','1a70ff5a7cf6a2ecf5b0df2236443b7b099ace708206e0f9a48c9b2038b7b365'),
 ('MINIMUM_FORCE_CLARIFICATION.md','635b613ea7c22ddda6486b9b127ee31e6c61be26104501a52d85be70f060c9d5')])
def test_frozen_source_hashes(filename,digest):
    assert hashlib.sha256((ROOT/'docs/qualification_corner_compression0935'/filename).read_bytes()).hexdigest()==digest

@pytest.mark.parametrize('P,t,status,complete,R,eta',[
 (-100000.,12.,'FAIL',True,360708.10819776217,.2772324705969013),
 (-50000.,12.,'PASS',True,360708.10819776217,.13861623529845065),
 (-100000.,6.,'FAIL',False,45897.910750266376,2.178748408486537)])
def test_declared_CC_witnesses(P,t,status,complete,R,eta):
    r=analyze(cc(P,plate_t=t)); cp=r['compression']; got=rows(r)
    assert (r['status'],r['complete'])==(status,complete)
    assert cp['resistance']==pytest.approx(R,rel=1e-12)
    assert got['gusset_centered_whitmore_compression_buckling']['utilization']==pytest.approx(eta)
    assert cp['Lmax']==pytest.approx(429.0291308792039)
    assert cp['Lmax']>max(cp['l1'],cp['l2'],cp['l3'])
    assert cp['width']==pytest.approx(298.23411844343536)
    assert 'compression_slenderness_service' in issues(r) if t==6 else not issues(r)
    assert got['continuity_top_concurrent_column_receiver_bound']['utilization']==pytest.approx(1.018850578758671 if P==-100000 else .8482492091525684)


def test_all_frozen_signed_common_actions_and_modes():
    r=analyze(cc());ex=ORACLE['main_case'];got=rows(r)
    for k in ('H','V','Hb','Vb','Hc','Vc'):assert r['forces'][k]==pytest.approx(ex[k])
    for key,ref in [('joint','J'),('lower_column_cut','lower_cut')]:
        assert [r['forces'][key][k] for k in ('Fx','Fy','M')]==pytest.approx(ex[ref])
    for k in ('Ftop','Fbottom','Nweb'):assert r['joint_distribution'][k]==pytest.approx(ex[k])
    for k in ('Qtop','Qbottom'):assert r['panel'][k]==pytest.approx(ex[k])
    for root in ('beam','column'):
        assert got[root+'_receiving_compression_web_crippling']['resistance']==pytest.approx(ex['roots'][root]['receiver_web_crippling_resistance'])
        assert root+'_receiver_root_contact_normal_rupture' not in got
        assert root+'_gusset_root_contact_normal_rupture' not in got
    assert 'joint_web_base_normal_rupture' not in got and 'joint_web_column_flange_contact_normal_rupture' not in got
    assert 'joint_bottom_beam_flange_net' in got
    assert not any('effective_rupture' in k or 'peak_tension' in k or k.startswith('gusset_tear_') for k in got)
    assert 'Ct' not in r['brace']
    vectors=r['brace']['signed_weld_vectors'];assert len(vectors)==4
    assert sum(x['force'] for x in vectors)==pytest.approx(-100000)
    assert sum(x['Fx'] for x in vectors)==pytest.approx(ex['H'])
    assert all(x['force']<0 and x['magnitude']==-x['force'] for x in vectors)
    for residual in r['equilibrium_residuals'].values():assert residual==pytest.approx([0,0,0],abs=1e-6)

@pytest.mark.parametrize('lam',[0.,1e-9,.2,1.499999999,1.5,1.500000001,3.,8.])
def test_full_nbr_curve(lam):
    E=200000.;fy=250.;t=12.;L=lam*math.pi*math.sqrt(E/fy)*t/math.sqrt(12)
    z=reduction(E,fy,3200.,t,L,1.1)
    expected=.658**(lam*lam) if lam<=1.5 else .877/(lam*lam)
    assert z['chi']==pytest.approx(expected)
    assert z['resistance']<=z['gross_resistance']
    assert z['Ne'] is None if lam==0 else z['Ne']>0

@pytest.mark.parametrize('P',[-44999.,-20000.,-1.,0.,1.,20000.,44999.])
def test_minimum_signed_separate_full_chain(P):
    c=cc(P);r=analyze(c);case=r['design_cases'][0];minimum=case['result'];design=-45000 if P<0 else 45000
    assert case['actual_P']==P and case['design_P']==design
    assert r['forces']['H']==pytest.approx(P/math.sqrt(2))
    assert minimum['forces']['H']==pytest.approx(design/math.sqrt(2))
    for k in ('beam_cut','upper_column_cut'):assert minimum['forces'][k]==r['forces'][k]
    assert minimum['forces']['lower_column_cut']!=r['forces']['lower_column_cut']
    assert not case['robot_lower_comparison']
    assert bool(case.get('zero_force_convention'))==(P==0)
    assert all(x.get('case_id') in ('actual','minimum_45kN') for x in r['checks'])

@pytest.mark.parametrize('root',['beam','column','brace'])
@pytest.mark.parametrize('state',['unknown','absent'])
def test_missing_physical_restraint_retains_failure(root,state):
    r=analyze(replace(cc(),**{'compression_'+root+'_restraint':state}))
    assert 'compression_'+root+'_restraint' in issues(r)
    assert r['status']=='FAIL' and not r['complete']
    assert rows(r)['continuity_top_concurrent_column_receiver_bound']['status']=='FAIL'
    assert rows(r)['gusset_centered_whitmore_compression_buckling']['status']=='PASS'

@pytest.mark.parametrize('kw',[{'corner_clip':31.},{'plate_t':11.},{'brace_weld_start':660.},{'brace_weld_length':210.},
 {'beam_seam_end_margin':20.},{'column_seam_start_margin':15.},{'phi_deg':44.},{'continuity_t':14.},{'root_weld_leg':5.}])
def test_geometry_change_cannot_reuse_declaration(kw):
    c=cc();changed=replace(c,**kw);assert geometry_stamp(changed)!=c.compression_geometry_stamp
    r=analyze(changed);assert 'compression_geometry_declaration' in issues(r);assert not r['complete']

@pytest.mark.parametrize('kw',[{'P':-50000.},{'beam_cut_M':63000000.},{'upper_column_cut_Fx':12000.},{'case_id':'another case'},
 {'gusset_steel':'ASTM A572 Gr.50'},{'angle_steel':'ASTM A572 Gr.50'},{'E':210000.},{'gamma_a1':1.2},
 {'lateral_restraint':False},{'bolt_pitch':999.},{'fw_brace':500.}])
def test_irrelevant_force_material_controls_do_not_expire_geometry(kw):
    c=cc();changed=replace(c,**kw);assert geometry_stamp(changed)==c.compression_geometry_stamp
    assert 'compression_geometry_declaration' not in issues(analyze(changed))

@pytest.mark.parametrize('kw,issue',[
 ({'beam_seam_end_margin':250.},'compression_beam_projection'),
 ({'column_seam_start_margin':250.},'compression_column_projection'),
 ({'corner_clip':240.},'compression_beam_projection'),
 ({'workpoint_offset':10.},'compression_axial_domain'),
 ({'phi_deg':80.},'compression_direct_load_flow')])
def test_specific_physical_guards_even_after_new_declaration(kw,issue):
    r=analyze(cc(**kw));assert issue in issues(r);assert not r['complete']

@pytest.mark.parametrize('P',[-100000.,-20000.])
@pytest.mark.parametrize('topology',['single_1L_welded','symmetric_2L_T_bolted','single_1L_bolted'])
def test_unqualified_compression_adapters_stay_unqualified(topology,P):
    base=next(c for c in presets().values() if c.topology==topology)
    r=analyze(replace(base,P=P));assert 'UNVERIFIED_BRACE_COMPRESSION' in issues(r)
    assert 'compression' not in r and 'design_cases' not in r and not r['complete']


def test_native_atomic_fields_and_stale_approval_recomputed():
    c=cc();native=c.to_dict();assert CornerGusset.from_dict(native)==c
    for field in RESTRAINT_FIELDS:
        bad=deepcopy(native);bad['connection'].pop(field)
        with pytest.raises(ValueError):CornerGusset.from_dict(bad)
    bad=deepcopy(native);bad['approved']=True
    with pytest.raises(ValueError):CornerGusset.from_dict(bad)
    bad=deepcopy(native);bad['connection']['corner_clip']=40.
    r=analyze(CornerGusset.from_dict(bad));assert 'compression_geometry_declaration' in issues(r)
    for legacy in ('0.9.34-bolted-corner-dev','0.9.33-single-angle-corner-dev','0.9.32-corner-gusset-dev'):
        old=CornerGusset().to_dict();old['component_version']=legacy;old['connection']['P']=-100000.
        r=analyze(CornerGusset.from_dict(old));assert 'compression_geometry_declaration' in issues(r)
        assert all('compression_'+root+'_restraint' in issues(r) for root in ('beam','column','brace'))
    assert not (set(RESTRAINT_FIELDS)&set(CornerGusset().to_dict()['connection']))


def test_published_benchmark_area_discrepancy_retained():
    ex=ORACLE['published_DG29_Ex5_1_replay']
    assert .5*9.76/(1/math.sqrt(12))==pytest.approx(16.904816,rel=1e-7)
    assert 20.9*50*.9==pytest.approx(940.5)
    assert 20.9!=21.5


def test_seeded_double_brace_load_fails_complete_lower_cut_equilibrium():
    actual=cc();r=analyze(actual);lower=r['forces']['lower_column_cut']
    wrong=replace(actual,P=2*actual.P,compare_lower_cut=True,
                  lower_column_check_Fx=lower['Fx'],lower_column_check_Fy=lower['Fy'],lower_column_check_M=lower['M'])
    result=analyze(wrong)
    assert result['status']=='INVALID' and 'lower_cut_mismatch' in issues(result)
    assert result['forces']['lower_column_cut']!=lower


def test_local_angle_slenderness_does_not_approve_gross_area():
    name=next(k for k,a in ANGLE_CATALOG.items() if a['Ag'] and a['centroid'] and a['leg']/a['t']>13)
    c=cc(angle_profile=name);r=analyze(c)
    assert 'angle_compression_effective_area' in issues(r)
    assert rows(r)['angle_each_compression_local_slenderness']['status']=='UNVERIFIED'
    assert not r['complete']

@pytest.mark.parametrize('P',[0.,1.,20000.,44999.])
def test_corrected_positive_single_angle_minimum_without_compression_qualification(P):
    c=replace(CornerGusset(),topology='single_1L_welded',symmetric=False,P=P)
    r=analyze(c);case=r['design_cases'][0]
    assert case['design_P']==45000
    assert r['forces']['H']==pytest.approx(P/math.sqrt(2))
    assert case['result']['brace']['per_angle_force']==45000
    assert 'compression' not in r


@pytest.mark.parametrize('field',['compression_detail_source','compression_geometry_stamp'])
@pytest.mark.parametrize('value',['','   '])
def test_blank_declaration_is_unknown_and_retains_diagnostics(field,value):
    c=replace(cc(),**{field:value});native=c.to_dict();restored=CornerGusset.from_dict(native)
    r=analyze(restored)
    expected='compression_detail_source' if field=='compression_detail_source' else 'compression_geometry_declaration'
    assert expected in issues(r)
    assert r['status']=='FAIL' and not r['complete']
    assert rows(r)['continuity_top_concurrent_column_receiver_bound']['status']=='FAIL'
    assert rows(r)['gusset_centered_whitmore_compression_buckling']['status']=='PASS'
    native['connection'][field]=None
    with pytest.raises(ValueError):CornerGusset.from_dict(native)
