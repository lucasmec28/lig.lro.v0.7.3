"""Finite nineteenth-route contract, without changing legacy force conventions."""
import ast
from dataclasses import replace
from pathlib import Path
import xml.etree.ElementTree as ET

import pytest
from lro import guided_selection as guide
from lro import load_conventions as loads
from lro.corner_gusset import CornerGusset, FAMILY, COMPONENT_VERSION, CONNECTION_TYPE
from lro.models import VERSION


def test_nineteenth_route_has_one_distinct_native_identity():
    assert VERSION == COMPONENT_VERSION == '0.9.35-corner-compression-dev'
    assert CONNECTION_TYPE == 'corner_gusset'
    assert len(guide.FAMILIES) == 19
    assert guide.FAMILIES[-1].id == 'corner_gusset'
    assert guide.FAMILIES[-1].route_select_value == FAMILY
    assert [x.id for x in guide.search_families('corner_gusset_strong_axis','corner_complete_cuts')] == ['corner_gusset']
    assert guide.FAMILIES[1].id == 'column_web_double_cover'
    assert 'pendente' in guide.FAMILIES[1].scope_caption
    assert guide.FAMILIES[17].id == 'bolted_angle_gusset'


def test_new_guide_changes_no_connection_until_explicit_open():
    state={'connection_family':'Single plate','nav_guide_interface':'corner_gusset_strong_axis','nav_guide_model':'all','physical_load':123.4}
    guide.interface_changed(state)
    assert state['connection_family']=='Single plate' and state['physical_load']==123.4
    state['nav_guide_candidate']='corner_gusset'
    assert guide.open_family(state)
    assert state['connection_family']==FAMILY and state['physical_load']==123.4
    assert not guide.open_family(state)
    guide.clear_filters(state)
    assert state['connection_family']==FAMILY


def test_corner_reference_states_full_cut_signs_without_inventing_N0():
    note=loads.reference_description('corner_gusset')
    assert all(x in note for x in ('Fx','Fy','anti-horário','Corte L derivado','completas'))
    assert 'N0' not in note
    assert loads.axial_nature('corner_gusset',100.)=='Tração'
    assert 'fora do domínio' in loads.axial_nature('corner_gusset',-100.)
    assert loads.axial_nature('corner_gusset',0.)=='Sem axial'


@pytest.mark.parametrize('phi',[35.,40.,45.,50.,55.,80.])
def test_corner_reference_is_deterministic_and_has_no_actual_force_values(phi):
    a=loads.convention_svg('corner_gusset',theta_deg=phi)
    assert a==loads.convention_svg('corner_gusset',theta_deg=phi)
    root=ET.fromstring(a)
    text=' '.join(''.join(node.itertext()) for node in root.iter() if node.tag.endswith('text'))
    assert 'Fx' in text and 'Fy' in text and 'M' in text
    assert not any(unit in text for unit in ('kN','MPa','kgf','N·mm'))
    assert '100000' not in text


def test_new_app_dispatch_is_once_and_requires_all_new_modules():
    app=Path(__file__).resolve().parents[1]/'app.py';s=app.read_text()
    ast.parse(s)
    assert s.count('if family==CORNER_GUSSET_FAMILY:')==1
    assert 'from lro.corner_gusset_ui import render' in s
    for name in ('corner_gusset','corner_gusset_ui','corner_gusset_drawing','corner_gusset_report','corner_gusset_presentation'):
        assert "'"+name+"'" in s
    assert 'BOLTED_ANGLE_GUSSET_FAMILY,CORNER_GUSSET_FAMILY]' in s
