"""Benchmarks independentes NBR 6.7, domínio e semântica de escopo."""
from dataclasses import replace
from pathlib import Path
from io import BytesIO
import json,math,zipfile
import pytest
from lro.models import Profile,KGF
from lro.base_plate import BasePlate,evaluate,reactions,presets,detail_reference,DETAIL,ANCHORS,G1,G2

FIXTURE=json.loads((Path(__file__).parent/'fixtures'/'base_plate_benchmarks.json').read_text())
P=Profile('I 300 × 150','Soldado',40.,300.,150.,8.,12.,276.,7008.)
BASE=BasePlate(P,a1=50.,a2=100.,db=25.4,tp=50.8,N=400000.)

@pytest.mark.parametrize('row',FIXTURE['cases'],ids=lambda row:row['name'])
def test_independent_nbr_benchmarks(row):
    c=replace(BASE,N=row['N'],M=row['M']);a=reactions(c)
    mapping={'lc':'lc','C':'C','sigma':'sigma','T_total':'T_total','Ft_max':'Ft_max','Ft_min':'Ft_min',
             't_comp':'t_contact','t_tension':'t_tension','t_min':'t_required','db_min':'db_required'}
    for expected,actual in mapping.items():
        assert a[actual]==pytest.approx(row[expected],abs=1e-7,rel=1e-10)
    assert abs(a['residual_N'])<1e-7
    assert abs(a['residual_M'])<1e-6
    assert evaluate(c).geometry['friction_rd']==pytest.approx(row['V_friction_Rd'])

@pytest.mark.parametrize('row',FIXTURE['cases'],ids=lambda row:row['name'])
def test_negative_mirror_preserves_strength_and_swaps_rows(row):
    pos=reactions(replace(BASE,N=row['N'],M=row['M']))
    neg=reactions(replace(BASE,N=row['N'],M=-row['M']))
    for key in ('lc','C','Ft_max','Ft_min','t_required','db_required'):
        assert pos[key]==pytest.approx(neg[key])
    if row['M']:
        assert pos['C_x']==-neg['C_x']
        assert pos['T_max_x']==-neg['T_max_x']
    assert abs(neg['residual_M'])<1e-6

@pytest.mark.parametrize('name',list(presets()))
def test_presets_roundtrip(name):
    c=presets()[name]
    loaded=BasePlate.from_dict(json.loads(json.dumps(c.to_dict())))
    assert loaded==c
    r=evaluate(loaded)
    assert r.geometry and not any(x.severity=='error' for x in r.issues)
    assert any(x.severity=='pending' and 'Ancoragem' in x.text for x in r.issues)
    assert r.status!='ATENDE ÀS VERIFICAÇÕES REALIZADAS'

@pytest.mark.parametrize('kwargs',[{'N':math.nan},{'M':math.inf},{'V':True},{'a1':1e308},
    {'N':1e308},{'a2':0},{'tp':-1},{'fck':19},{'fck':51},{'db':16.},
    {'column':replace(P,tf=200.)},{'column':replace(P,clear=500.)}])
def test_invalid_data_never_returns_strength_pass(kwargs):
    r=evaluate(replace(BASE,**kwargs))
    assert not r.geometry and not r.checks
    assert r.status=='DADOS OU GEOMETRIA INVÁLIDOS'


def test_domain_cannot_create_nan_or_silent_capacity():
    for c in (replace(BASE,N=BASE.sigma_rd*BASE.L*BASE.B+1),replace(BASE,M=1e12)):
        r=evaluate(c)
        assert not r.geometry and r.component_status=='EQUILÍBRIO NÃO DEMONSTRADO'
        assert not any(x.id in ('bp_plate_contact','bp_plate_tension','bp_anchor_steel') for x in r.checks)


def test_lc_small_positive_uses_stable_root():
    u=100000.;m=u*BASE.a+1e-4
    a=reactions(replace(BASE,N=-u,M=m))
    assert 0<a['lc']<1e-7
    assert a['C']>0 and math.isfinite(a['t_required'])
    assert abs(a['residual_M'])<1e-6


def test_pure_bending_continuity_in_forces():
    pure=reactions(replace(BASE,N=0.,M=40e6))
    for n in (-1e-5,1e-5):
        r=reactions(replace(BASE,N=n,M=40e6))
        assert r['C']==pytest.approx(pure['C'],abs=1e-4)
        assert r['Ft_max']==pytest.approx(pure['Ft_max'],abs=1e-4)


def test_shear_is_full_external_capacity_not_additive():
    c=replace(BASE,V=200000.,shear_path='external',external_shear_rd=100000.,external_shear_ref='MC 23 revisão 2')
    r=evaluate(c);row=next(x for x in r.checks if x.id=='bp_shear_external')
    assert row.demand==200000. and row.resistance==100000. and not row.passed
    assert r.geometry['friction_rd']>0 and r.geometry['shear_rd']==100000.
    assert not any(x.id=='bp_shear' for x in r.checks)


def test_shear_without_contact_and_missing_device_report_pending():
    r=evaluate(replace(BASE,N=-10000.,M=0.,V=1000.))
    assert r.geometry['friction_rd']==0
    assert r.component_status=='NÃO ATENDE AO DETALHAMENTO'
    r=evaluate(replace(BASE,shear_path='external',external_shear_rd=1000.,external_shear_ref=''))
    assert r.component_status=='VERIFICAÇÃO DO CORTANTE COM DADOS PENDENTES'
    assert not any(x.id=='bp_shear_external' for x in r.checks)


def test_zero_load_does_not_invent_resistance_or_divide_by_zero():
    r=evaluate(replace(BASE,N=0.,M=0.,V=0.))
    assert r.geometry['case']=='SEM N/M'
    assert r.geometry['C']==r.geometry['T_total']==r.geometry['t_required']==0
    assert {x.id for x in r.checks}=={'bp_grout','bp_width'}

@pytest.mark.parametrize('label,expected',list(zip(ANCHORS,[900,900,900,1100,1300,1600,1800])))
def test_corrected_table_18_dimensions(label,expected):
    d=DETAIL[label];c=replace(BASE,db=ANCHORS[label],a1=d['a1'],a2=d['a2'])
    r=detail_reference(c)
    assert r['Nb_min']==expected
    assert r['Nb']==max(expected,c.L+2*d['en'],c.L+2*(d['a3']-c.a1))
    assert r['Ab']==max(r['h1']+100,r['Nb'])
    assert r['washer_hole']==pytest.approx(c.db+1.5)
    assert r['matches_spacing']


def test_different_spacing_is_explained_without_false_impossibility():
    r=evaluate(replace(BASE,a2=200.))
    assert r.geometry
    assert any('Geometria distinta' in x.text for x in r.issues)
    assert not any(x.severity=='error' for x in r.issues)


def test_json_strict_import_and_invalid_draft_restoration():
    for bad in ({},{'schema_version':1,'connection_type':'end_plate','connection':{}},
                {**BASE.to_dict(),'schema_version':True}):
        with pytest.raises(ValueError):BasePlate.from_dict(bad)
    bad=BASE.to_dict();bad['connection']['M_minor']=100
    with pytest.raises(ValueError,match='não reconhecidos'):BasePlate.from_dict(bad)
    bad=replace(BASE,a1=.1).to_dict()
    with pytest.raises(ValueError):BasePlate.from_dict(bad)
    assert BasePlate.from_dict(bad,validate_values=False).a1==.1


def test_docx_has_native_equations_scope_and_corrected_reference():
    from lro.base_plate_report import create_report
    from lro.base_plate_drawing import image_bytes
    c=replace(BASE,N=-100000.,M=-40e6);r=evaluate(c)
    data=create_report(c,r,True)
    with zipfile.ZipFile(BytesIO(data)) as z:
        xml=z.read('word/document.xml').decode()
        assert '<m:oMath>' in xml and '<m:rad>' in xml
        assert 'Ancoragem no concreto' in xml and 'versão corrigida 2025' in xml
        assert 'kgf·m' in xml and 'não aprovam a base completa' in xml
        assert not any(x in xml for x in ('nan','>inf<','꜀'))
    svg=image_bytes(c,r,'svg').decode()
    assert '<svg' in svg and 'PLANTA DA PLACA' in svg and 'a₁=' in svg
