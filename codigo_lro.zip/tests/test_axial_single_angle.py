"""Finite acceptance for the qualified nominal 1L local end component.

The JSON witness is copied unchanged from the independent qualification oracle;
it imports no production code. It is intentionally distinct from the 2L tests.
"""
from copy import deepcopy
from dataclasses import fields, replace
import json
import math
from pathlib import Path

import pytest

from lro.axial_single_angle import (
    AxialSingleAngle, COMPONENT_VERSION, CONNECTION_TYPE, FAMILY, LOAD_MODEL,
    bearing_resistance, block_resistance, bolt_shear_resistance, evaluate,
    input_errors, presets, terminal_resultants,
)

ORACLE = json.loads((Path(__file__).parent / 'fixtures' /
                     'axial_single_angle_independent_oracle.json').read_text())


def fixture(**changes):
    return replace(AxialSingleAngle(), **changes)


def row(result, primitive, case='actual'):
    return next(r for r in result['checks'] if r['id'] == primitive + '__' + case)


def finite_tree(value):
    if isinstance(value, dict):
        for child in value.values():
            finite_tree(child)
    elif isinstance(value, (list, tuple)):
        for child in value:
            finite_tree(child)
    elif isinstance(value, (float, int)):
        assert math.isfinite(value)


def test_independent_complete_100kn_fixture():
    c, r = fixture(), evaluate(fixture())
    assert FAMILY == 'Ligação axial 1L–chapa retangular · parafusada'
    assert COMPONENT_VERSION == '0.9.21-axial-single-angle-dev'
    assert CONNECTION_TYPE == 'axial_single_angle_bolted'
    assert c.Ag == 929 and c.N == 100000 and c.angle_count == 1
    assert r['global_pass'] and r['status'] == 'COMPLETE_CHECKS_PASS_WITHIN_SCOPE'
    assert r['summary']['complete_checks'] and r['issues'] == []
    assert len(r['checks']) == 27
    assert set(r['sections']) == {'angle', 'plate', 'terminal'}
    for component in ['angle', 'plate']:
        s, o = r['sections'][component], ORACLE['sections'][component]
        for key in ['Ag', 'An', 'Ct', 'Ae']:
            source_key = key if key == 'Ct' else key + '_mm2'
            if component == 'plate' and key == 'Ae':
                source_key = 'An_mm2'  # Ct=1 for the full real rectangular plate.
            assert s[key] == pytest.approx(o[source_key])
        assert s['yield_capacity_N'] == pytest.approx(o['yield_N'])
        assert s['fracture_capacity_N'] == pytest.approx(o['rupture_N'])
    assert r['summary']['governing_capacity_N'] == pytest.approx(ORACLE['governing_capacity_N'])
    assert r['summary']['utilization'] == pytest.approx(ORACLE['utilization'])
    assert r['summary']['governing_id'] == 'angle_block_toe_k3__actual'
    assert r['summary']['governing_ties'] == ['angle_block_toe_k3__actual']
    assert r['bolts']['single_plane_capacity_N'] == pytest.approx(ORACLE['bolts']['one_plane_threaded_N'])
    assert r['bolts']['sum_group_capacity_N'] == pytest.approx(ORACLE['bolts']['group_N'])
    assert r['bolts']['compatible_uniform_group_capacity_N'] == pytest.approx(ORACLE['bolts']['group_N'])
    finite_tree(r)
    json.dumps(r, allow_nan=False)


def test_unchanged_200kn_geometry_must_fail_without_two_angle_sharing():
    a, b = evaluate(fixture()), evaluate(fixture(N=200000))
    assert a['geometry'] == b['geometry']
    assert a['sections'] == b['sections']
    assert b['status'] == 'COMPLETE_CHECKS_FAIL' and not b['global_pass']
    assert b['summary']['utilization'] == pytest.approx(ORACLE['unchanged_200kN_case_utilization'])
    for primitive in ['angle_block_toe_k3', 'angle_effective_net_fracture', 'bolt_1_plane_1']:
        assert row(b, primitive)['status'] == 'FAIL'
    assert row(b, 'plate_gross_yield')['status'] == 'PASS'
    assert row(b, 'plate_net_fracture')['status'] == 'PASS'
    for actual in b['checks']:
        original = row(a, actual['primitive_id'])
        assert actual['demand'] == 2 * original['demand']
        assert actual['resistance'] == original['resistance']


def test_all_bolts_one_plane_both_bearing_materials_full_n_per_n():
    r = evaluate(fixture())
    assert r['geometry']['bolt_x'] == [35, 85, 135]
    assert r['geometry']['angle_end_x'] == 170 and r['geometry']['terminal_x'] == 200
    assert r['geometry']['grip'] == pytest.approx(18.85)
    assert r['geometry']['physical_shear_planes'] == r['geometry']['physical_angle_count'] == 1
    shears = [c for c in r['checks'] if c['mechanism'] == 'bolt_shear']
    assert len(shears) == 3 and {c['shear_plane'] for c in shears} == {1}
    for witness in ORACLE['bolts']['rows']:
        i = witness['i']
        b = row(r, f'bolt_{i}_plane_1')
        assert b['demand'] == pytest.approx(witness['demand_plane_N'])
        assert b['resistance'] == pytest.approx(ORACLE['bolts']['one_plane_threaded_N'])
        assert b['path'] == 'angle_plate_interface'
        for component in ['angle', 'plate']:
            a = row(r, f'{component}_bearing_{i}')
            assert a['demand'] == pytest.approx(witness[component + '_demand_N'])
            assert a['resistance'] == pytest.approx(witness[component + '_bearing_N'])
            assert a['clear_distance'] == pytest.approx(witness['clear_' + component + '_mm'])
            assert a['loaded_direction'] == ('+x' if component == 'angle' else '-x')
        assert row(r, f'plate_bearing_{i}')['thickness'] == 12.5
    assert row(r, 'plate_bearing_1')['path'] == 'loaded_free_end'
    assert row(r, 'angle_bearing_3')['path'] == 'loaded_free_end'
    assert not any('angle_1' in c['id'] or 'angle_2' in c['id'] or 'pair' in c['component'] for c in r['checks'])


def test_every_partial_block_matches_independent_real_path_and_full_force():
    r = evaluate(fixture())
    names = {'angle_toe': 'angle_block_toe', 'angle_far_toe': 'angle_block_far_toe_unfolded',
             'plate_side_left': 'plate_block_lower_side', 'plate_side_right': 'plate_block_upper_side'}
    for witness in ORACLE['blocks']:
        k = witness['k']
        b = row(r, names[witness['member']] + f'_k{k}')
        assert b['areas'] == pytest.approx({a: witness[a + '_mm2'] for a in ['Agv', 'Anv', 'Ant']})
        assert b['resistance'] == pytest.approx(witness['Rd_N'])
        assert b['demand'] == pytest.approx(witness['demand_N'])
        assert b['equivalent_capacity_N'] == pytest.approx(witness['equivalent_N_capacity'])
        assert b['utilization'] == pytest.approx(witness['utilization'])
        assert b['demand_fraction'] == pytest.approx(k / 3)
        assert b['Cts'] == b['physical_shear_surfaces'] == 1
        assert b['alternative_path'] and not b['heel_is_free_edge']
        if b['component'] == 'angle':
            assert b['bolt_indices'] == list(range(4 - k, 4)) and b['free_end_x'] == 170
        else:
            assert b['bolt_indices'] == list(range(1, k + 1)) and b['free_end_x'] == 0
            assert b['demand_basis'] == 'full_enclosed_bolt_force_alternative_side_paths'
    assert row(r, 'angle_block_far_toe_unfolded_k3')['gross_tension_width'] == pytest.approx(104.65)
    assert len([c for c in r['checks'] if c['mechanism'] == 'block_tearout']) == 12
    assert not any(c['mechanism'] == 'pure_shear' for c in r['checks'])


@pytest.mark.parametrize('N', [0, 12345., 100000., 200000.])
def test_nominal_equilibrium_each_material_and_every_candidate_case(N):
    r = evaluate(fixture(N=N, recommend_half_capacity=True))
    model = r['load_model']
    assert model['model'] == LOAD_MODEL
    assert model['angle_bolt_force_sum_x'] == -model['plate_bolt_force_sum_x'] == N
    assert model['terminal_actual']['N'] == N
    for case in r['cases']:
        for component in ['angle', 'plate']:
            forces = [x['demand'] for x in r['checks'] if x['component'] == component and
                      x['mechanism'] == 'bearing' and x['case_id'] == case['id']]
            assert sum(forces) == pytest.approx(case['N'])
        forces = [x['demand'] for x in r['checks'] if x['mechanism'] == 'bolt_shear' and x['case_id'] == case['id']]
        assert sum(forces) == pytest.approx(case['N'])
        terminal = next(t for t in model['terminal_actions'] if t['case_id'] == case['id'])
        assert terminal['N'] == case['N'] and terminal['Mx'] == terminal['My'] == terminal['Mz'] == 0


def test_physical_offsets_are_omitted_not_cancelled_and_ec_still_active():
    r = evaluate(fixture())
    g, m = r['geometry'], r['load_model']
    assert g['angle_heel_y'] == 15 and g['angle_toe_y'] == 91
    assert m['physical_CG_y'] == pytest.approx(36.3)
    assert m['physical_CG_z'] == pytest.approx(27.55)
    assert m['physical_CG_offset_y_omitted'] == pytest.approx(-13.7)
    assert m['physical_CG_offset_z_omitted'] == pytest.approx(27.55)
    assert not m['physical_CG_offsets_cancelled'] and not g['physical_CG_offsets_cancelled']
    assert m['ec_shear_lag'] == r['sections']['angle']['ec'] == 21.3
    assert m['connected_leg_to_plate_midplanes'] == pytest.approx(9.425)
    assert (m['axis_y'], m['axis_z']) == (50, 0)
    diagnostic = m['diagnostic_only_actual_CG_moments']
    assert diagnostic['My'] == 2755000 and diagnostic['Mz'] == 1370000
    assert not diagnostic['used_in_resistance_checks'] and not m['actual_CG_export_permitted']
    assert m['terminal_actual']['My'] == m['terminal_actual']['Mz'] == 0
    assert m['bolt_tension'] == 0
    assert not any(x['mechanism'] in {'bolt_tension', 'bolt_bending', 'prying'} for x in r['checks'])


def test_terminal_nominal_transport_r_cross_n_and_both_signs():
    c = fixture()
    t = terminal_resultants(c, reference_x=0, reference_y=20, reference_z=10)
    assert t['N'] == t['Fx'] == 100000 and t['Fy'] == t['Fz'] == t['Mx'] == 0
    assert t['My'] == -1000000 and t['Mz'] == t['M'] == -3000000
    assert (t['x'], t['y'], t['z']) == (200, 50, 0)
    assert t['valid_for_input'] and not t['actual_CG_export_permitted']
    other = terminal_resultants(c, reference_x=-100, reference_y=80, reference_z=-10)
    assert other['My'] == 1000000 and other['Mz'] == 3000000
    assert terminal_resultants(c, reference_x=-100)['My'] == terminal_resultants(c, reference_x=-100)['Mz'] == 0
    assert terminal_resultants(c, N=45000, reference_z=10)['My'] == -450000
    for bad in [math.inf, math.nan, True, '0']:
        with pytest.raises(ValueError):
            terminal_resultants(c, reference_z=bad)
    with pytest.raises(ArithmeticError):
        terminal_resultants(c, reference_z=1e308)


def test_gauge_changes_omitted_y_and_block_not_nominal_forces_or_ct():
    a, b = evaluate(fixture()), evaluate(fixture(gauge=45))
    assert b['load_model']['physical_CG_offset_y_omitted'] == pytest.approx(-23.7)
    assert a['load_model']['terminal_actual'] == b['load_model']['terminal_actual']
    assert a['sections']['angle']['Ct'] == b['sections']['angle']['Ct']
    assert row(a, 'bolt_1_plane_1')['demand'] == row(b, 'bolt_1_plane_1')['demand']
    assert row(b, 'angle_block_toe_k3')['resistance'] < row(a, 'angle_block_toe_k3')['resistance']


def test_plate_thickness_changes_its_resistance_grip_and_z_never_angle_ag():
    a, b = evaluate(fixture()), evaluate(fixture(plate_t=16))
    assert b['global_pass']
    assert a['sections']['angle'] == b['sections']['angle']
    assert b['sections']['plate']['Ag'] == 1600
    assert row(b, 'plate_gross_yield')['resistance'] == pytest.approx(row(a, 'plate_gross_yield')['resistance'] * 16 / 12.5)
    assert row(b, 'plate_bearing_1')['resistance'] == pytest.approx(row(a, 'plate_bearing_1')['resistance'] * 16 / 12.5)
    assert b['geometry']['grip'] == pytest.approx(22.35)
    assert b['load_model']['physical_CG_offset_z_omitted'] == pytest.approx(29.3)
    assert b['load_model']['connected_leg_to_plate_midplanes'] == pytest.approx(11.175)
    assert a['load_model']['terminal_actual'] == b['load_model']['terminal_actual']


def test_single_thread_flag_changes_only_single_plane_coefficient():
    a, b = evaluate(fixture()), evaluate(fixture(threads_excluded=True))
    assert a['sections'] == b['sections'] and a['geometry'] == b['geometry']
    assert a['load_model'] == b['load_model']
    for result in b['checks']:
        original = row(a, result['primitive_id'])
        if result['mechanism'] == 'bolt_shear':
            assert result['coefficient'] == .56 and original['coefficient'] == .45
            assert result['resistance'] == pytest.approx(original['resistance'] * .56 / .45)
            assert result['demand'] == original['demand']
        else:
            assert result == original
    assert b['bolts']['sum_group_capacity_N'] == pytest.approx(3 * 69224.87776656763)


def test_drilling_policy_changes_net_deductions_not_physical_clear_distances():
    a, b = evaluate(fixture()), evaluate(fixture(drilled=False))
    assert b['geometry']['hole_diameter'] == 18 and b['geometry']['net_hole_diameter'] == 20
    assert b['sections']['angle']['An'] == pytest.approx(802)
    assert b['sections']['plate']['An'] == 1000
    for component in ['angle', 'plate']:
        for i in [1, 2, 3]:
            assert row(a, f'{component}_bearing_{i}') == row(b, f'{component}_bearing_{i}')
    assert row(b, 'angle_block_toe_k3')['resistance'] < row(a, 'angle_block_toe_k3')['resistance']


def test_ct_floor_single_connected_area_and_no_old_cap_or_splice_import():
    short, long = evaluate(fixture(n=2, pitch=30)), evaluate(fixture(n=21))
    assert short['sections']['angle']['Ac'] == 464.5
    assert short['sections']['angle']['Ct_raw'] == pytest.approx(.29)
    assert short['sections']['angle']['Ct'] == .5
    assert long['global_pass'] and long['sections']['angle']['Ct'] == pytest.approx(.9787)
    assert row(long, 'bolt_1_plane_1')['demand'] == pytest.approx(100000 / 21)
    wide = evaluate(fixture(plate_width=200))
    assert wide['sections']['plate']['An'] == (200 - 18) * 12.5
    assert wide['sections']['plate']['Ae'] > .85 * wide['sections']['plate']['Ag']
    assert not wide['sections']['plate']['splice_cap_applied']
    assert not any('whitmore' in x['id'].lower() for x in wide['checks'])


def test_grip_reduction_uses_single_lap_and_only_supported_pretension_exemption():
    r, exempt = evaluate(fixture(plate_t=90)), evaluate(fixture(plate_t=90, pretensioned=True))
    factor = 1 - .01 * (96.35 - 80) / 1.5
    assert r['geometry']['grip_factor'] == pytest.approx(factor)
    assert row(r, 'bolt_1_plane_1')['resistance'] == pytest.approx(ORACLE['bolts']['one_plane_threaded_N'] * factor)
    assert exempt['geometry']['grip_factor'] == 1 and exempt['geometry']['grip_pretension_exemption']
    exhausted = evaluate(fixture(plate_t=250))
    assert not exhausted['global_pass'] and row(exhausted, 'bolt_1_plane_1')['resistance'] == 0
    common = evaluate(fixture(bolt='ASTM A307', db=15.875, plate_t=90, threads_excluded=True, pretensioned=True))
    assert common['status'] == 'OUTSIDE_SCOPE'
    assert row(common, 'bolt_1_plane_1')['coefficient'] == .45
    assert not common['geometry']['grip_pretension_exemption']
    assert bolt_shear_resistance(16, 415, True, common=True) == bolt_shear_resistance(16, 415, False, common=True)


def test_zero_actual_minimum_and_optional_half_remain_separate():
    r = evaluate(fixture(N=0, recommend_half_capacity=True))
    assert r['global_pass']
    assert [c['id'] for c in r['cases']] == ['actual', 'minimum_45kN', 'recommended_half']
    assert [c['N'] for c in r['cases']] == pytest.approx([0, 45000, 94987.98518518518])
    assert r['cases'][2]['member_governing'] == 'angle_effective_net_fracture'
    assert r['load_model']['N_actual'] == r['load_model']['terminal_actual']['N'] == 0
    assert row(r, 'angle_gross_yield')['demand'] == row(r, 'angle_gross_yield')['utilization'] == 0
    assert row(r, 'angle_gross_yield', 'minimum_45kN')['demand'] == 45000
    assert len(r['checks']) == 81
    disabled = evaluate(fixture(N=0, minimum_force=False))
    assert disabled['status'] == 'OUTSIDE_SCOPE' and not disabled['global_pass']
    assert row(disabled, 'angle_gross_yield')['demand'] == 0
    assert any(i['id'] == 'minimum_force_disabled' for i in disabled['issues'])
    assert evaluate(fixture(N=45000, minimum_force=False))['global_pass']


@pytest.mark.parametrize('changes', [
    {'N': -1}, {'V': 1}, {'M': 1}, {'torsion': 1}, {'static': False},
    {'normal_combination': False}, {'angle_count': 2}, {'angle_count': 3},
    {'n': 1}, {'exposure': 'underwater'}, {'plate_steel': 'ASTM A992'},
    {'angle_steel': 'USI-CIVIL 350'},
])
def test_unsupported_domain_never_approved_and_preserves_resistances(changes):
    r = evaluate(fixture(**changes))
    assert r['status'] == 'OUTSIDE_SCOPE' and not r['global_pass']
    assert not r['summary']['complete_checks'] and r['checks']
    assert any(i['severity'] == 'outside_scope' for i in r['issues'])
    assert not any(i['severity'] == 'numerical_failure' for i in r['issues'])
    if 'N' in changes:
        assert r['load_model']['N_actual'] == -1
    if any(k in changes for k in ['V', 'M', 'torsion']):
        assert not r['load_model']['terminal_actions_valid_for_actual_input']
        for key, value in changes.items():
            assert r['load_model']['actual_actions'][key] == value
    if changes.get('n') == 1:
        assert r['sections']['angle']['Ct'] is None
        assert not row(r, 'angle_effective_net_fracture')['method_applicable']
    finite_tree(r)


@pytest.mark.parametrize('extension', [0, -1, -30, -50, -200])
def test_invalid_terminal_position_does_not_hide_overloaded_capacity(extension):
    r = evaluate(fixture(terminal_extension=extension, N=200000))
    assert r['status'] == 'INVALID_GEOMETRY' and not r['global_pass']
    assert len(r['checks']) == 27
    assert row(r, 'angle_block_toe_k3')['status'] == 'FAIL'
    assert not r['sections']['terminal']['physical_continuity']
    assert not r['load_model']['terminal_actions_valid_for_actual_input']
    assert any(i['id'] == 'terminal_beyond_angle' for i in r['issues'])


def test_detail_and_geometry_flags_keep_capacity_failures_visible():
    detail = evaluate(fixture(tool_radius=24))
    assert detail['status'] == 'DETAILING_FAIL' and detail['summary']['complete_checks']
    assert any(i['id'] == 'root_tool_access' for i in detail['issues'])
    bad = evaluate(fixture(gauge=20, N=900000, static=False))
    assert not bad['global_pass'] and len(bad['checks']) == 27
    assert any(i['severity'] == 'invalid_geometry' for i in bad['issues'])
    assert any(i['severity'] == 'outside_scope' for i in bad['issues'])
    assert row(bad, 'angle_gross_yield')['status'] == row(bad, 'plate_gross_yield')['status'] == 'FAIL'
    edge = evaluate(fixture(angle_end=20, N=200000))
    assert any(i['id'] == 'angle_end_min' for i in edge['issues'])
    assert row(edge, 'angle_bearing_3')['status'] == 'FAIL'


@pytest.mark.parametrize('changes', [
    {'N': math.nan}, {'N': math.inf}, {'N': -math.inf}, {'N': True}, {'N': '100000'},
    {'pitch': 0}, {'pitch': -1}, {'n': True}, {'n': 3.0}, {'n': 0}, {'n': 101},
    {'angle_count': False}, {'drilled': 1}, {'threads_excluded': 1},
    {'pretensioned': 'false'}, {'t': []}, {'notes': {}}, {'db': None}, {'Ag': 10 ** 1000},
])
def test_invalid_types_and_nonfinite_are_json_safe(changes):
    c = fixture(**changes)
    assert input_errors(c)
    r = evaluate(c)
    assert r['status'] == 'INVALID_INPUT' and not r['global_pass'] and r['checks'] == []
    finite_tree(r)
    json.dumps(r, allow_nan=False)
    with pytest.raises(ValueError):
        c.to_dict()


@pytest.mark.parametrize('changes', [
    {'leg': 1e308}, {'pitch': 1e308}, {'plate_width': 1e308}, {'Ag': 1e308},
    {'t': 1e200}, {'plate_t': 1e308}, {'N': 1e308}, {'terminal_extension': 1e308},
    {'leg': 5e-324}, {'plate_t': 5e-324}, {'Ag': 5e-324},
])
def test_finite_extremes_never_crash_or_approve(changes):
    r = evaluate(fixture(**changes))
    # A long empty terminal extension alone is finite and no strength limit applies.
    if changes == {'terminal_extension': 1e308}:
        assert r['global_pass'] and r['geometry']['terminal_x'] == 1e308
    else:
        assert not r['global_pass']
        assert r['issues'] or any(x['status'] == 'FAIL' for x in r['checks'])
    finite_tree(r)
    json.dumps(r, allow_nan=False)


def test_nonpositive_net_areas_visible_without_clamping():
    r = evaluate(fixture(plate_width=17))
    assert r['status'] == 'NUMERICAL_FAILURE'
    p = row(r, 'plate_net_fracture')
    assert p['areas']['An'] == -12.5 and p['resistance'] < 0
    assert p['utilization'] is None and not p['numerical_valid'] and p['status'] == 'FAIL'
    assert r['summary']['numerical_failures_visible']


def test_unknown_materials_or_diameter_do_not_get_fallbacks():
    for changes in [{'db': 16.01}, {'bolt': 'unknown'}, {'plate_steel': 'unknown'}]:
        r = evaluate(fixture(**changes))
        assert r['status'] == 'OUTSIDE_SCOPE' and not r['global_pass'] and r['checks'] == []
    assert fixture(db=15.875).hole_diameter == 17.4625
    assert fixture(db=16).hole_diameter == 18


def test_custom_single_catalog_properties_retained_and_physically_checked():
    r = evaluate(fixture(Ag=930, ec=22, profile_name='Custom sourced equal leg', profile_source='Survey'))
    assert r['global_pass'] and r['sections']['angle']['Ag'] == 930
    assert r['sections']['angle']['ec'] == 22 and r['sections']['angle']['profile_source'] == 'Survey'
    assert r['geometry']['profile_sharp_corner_comparator'] != 930
    for changes in [{'Ag': 1858}, {'Ag': 450}, {'ec': 60}, {'ec': 0}]:
        assert not evaluate(fixture(**changes))['global_pass']


def test_native_exact_roundtrip_and_single_plane_fixed_schema():
    c = fixture(N=34567, gauge=40, notes='Round-trip', recommend_half_capacity=True)
    data = json.loads(json.dumps(c.to_dict(), allow_nan=False))
    assert AxialSingleAngle.from_dict(data) == c
    assert set(data['connection']) == {f.name for f in fields(AxialSingleAngle)}
    assert data['connection_type'] == CONNECTION_TYPE
    assert data['fixed_assumptions']['shear_planes'] == data['fixed_assumptions']['angle_count'] == 1
    assert data['fixed_assumptions']['load_model'] == LOAD_MODEL
    assert not data['fixed_assumptions']['actual_CG_export_permitted']
    assert 'threads_excluded' in data['connection']
    assert not {'symmetric', 'threads_excluded_1', 'threads_excluded_2'} & set(data['connection'])
    mutations = [
        lambda d: d.update(result={'global_pass': True}),
        lambda d: d['connection'].update(unknown=1),
        lambda d: d['connection'].pop('N'),
        lambda d: d.update(schema_version=True),
        lambda d: d.update(component_version='old'),
        lambda d: d.update(connection_type='axial_double_angle_bolted'),
        lambda d: d['units'].update(force='kN'),
        lambda d: d['fixed_assumptions'].update(shear_planes=2),
        lambda d: d['fixed_assumptions'].update(angle_count=True),
        lambda d: d['fixed_assumptions'].update(actual_CG_export_permitted=True),
        lambda d: d['fixed_assumptions'].update(load_model='actual_CG'),
        lambda d: d['connection'].update(N=math.inf),
        lambda d: d['connection'].update(n=3.0),
        lambda d: d['connection'].update(drilled=1),
        lambda d: d['connection'].update(angle_count=2),
        lambda d: d['connection'].update(angle_count=True),
    ]
    for name, value in [('symmetric', False), ('threads_excluded_1', True), ('threads_excluded_2', False),
                        ('load_model', 'actual_CG'), ('terminal_axis', 'actual_CG'), ('opening_force', 1),
                        ('filler_t', 1), ('rows', 2), ('angle_2', {}), ('leg_2', 80)]:
        mutations.append(lambda d, name=name, value=value: d['connection'].update({name: value}))
    for mutate in mutations:
        bad = deepcopy(data)
        mutate(bad)
        with pytest.raises(ValueError):
            AxialSingleAngle.from_dict(bad)
    with pytest.raises(ValueError):
        fixture(angle_count=2).to_dict()


def test_standalone_primitive_formulas_and_presets():
    assert block_resistance(222.25, 165.1, 203.2, 250, 400) == pytest.approx(84901.85185185185)
    assert bearing_resistance(16, 26, 6.35, 400) == pytest.approx(58702.22222222222)
    assert bolt_shear_resistance(16, 830) == pytest.approx(.45 * math.pi * 16 ** 2 / 4 * 830 / 1.35)
    assert [c.N for c in presets().values()] == [100000, 0, 200000]
    assert all(isinstance(c, AxialSingleAngle) for c in presets().values())
