"""Actual callbacks, atomic native state and branch-accurate artifacts."""
from copy import deepcopy
from dataclasses import replace
from io import BytesIO
from pathlib import Path
from zipfile import ZipFile
import json,xml.etree.ElementTree as ET
import pytest
from docx import Document
from streamlit.testing.v1 import AppTest
from lro.corner_gusset import CornerGusset,analyze,presets,BOLTED_FIELDS,WELDED_BRACE_FIELDS
from lro.corner_gusset_ui import PROJECT,RESULT,REPORT,TEMPLATE,ACCEPTED,DRAFT,_key,decode_project
from lro.corner_gusset_presentation import memory_text,physical_envelopes
from lro.corner_gusset_drawing import image_bytes,effort_convention_svg
from lro.corner_gusset_report import create_report
RUNNER="""
import streamlit as st
from lro.corner_gusset_ui import render
page=st.selectbox('Página',['Canto','Outra'],key='test_page')
if page=='Canto':render()
else:st.text_input('Outro projeto',key='other_project')
"""
def bc(single=False,**kw):return replace(list(presets().values())[1 if single else 0],**kw)
def fresh(c=None):
    at=AppTest.from_string(RUNNER,default_timeout=120);at.session_state[PROJECT]=(c or bc()).to_dict();at.run();assert not at.exception;return at
def button(at,label):return next(x for x in at.button if x.label==label)
def body(data):
    d=Document(BytesIO(data));return '\n'.join([p.text for p in d.paragraphs]+[c.text for t in d.tables for r in t.rows for c in r.cells])

@pytest.mark.parametrize('single',[False,True])
def test_conditional_ui_native_and_material_independence(single):
    c=bc(single);at=fresh(c);assert at.session_state[PROJECT]==c.to_dict();assert at.session_state[RESULT]==analyze(c)
    keys={x.key for x in at.number_input};assert _key('bolt_count') in keys;assert _key('brace_weld_leg') not in keys
    checks={x.key for x in at.checkbox};assert (_key('bolt_threads_excluded_2') in checks)==(not single)
    assert len(at.selectbox(key=_key('topology')).options)==4
    at.selectbox(key=_key('gusset_steel')).set_value('ASTM A572 Gr.50').run();assert not at.exception
    raw=at.session_state[PROJECT]['connection'];assert raw['gusset_steel']=='ASTM A572 Gr.50'
    for key in ('angle_steel','beam_steel','column_steel','continuity_steel'):assert raw[key]==getattr(c,key)
    assert any('fy=345' in x.value and 'fu=450' in x.value for x in at.caption)


def test_actual_adapter_switch_roundtrip_and_navigation_preserves_bolt_controls():
    at=fresh();at.number_input(key=_key('bolt_pitch')).set_value(58.).run();at.number_input(key=_key('P')).set_value(100.0000001).run()
    bolt=deepcopy(at.session_state[PROJECT])
    at.selectbox(key=_key('topology')).set_value('single_1L_bolted').run();assert not at.exception
    at.selectbox(key=_key('single_angle_face')).set_value('negative').run();single=deepcopy(at.session_state[PROJECT])
    at.selectbox(key='test_page').set_value('Outra').run();at.text_input(key='other_project').set_value('Outro').run();at.selectbox(key='test_page').set_value('Canto').run()
    assert at.session_state[PROJECT]==single
    at.selectbox(key=_key('topology')).set_value('symmetric_2L_T_welded').run();assert not at.exception
    assert not set(BOLTED_FIELDS)&set(at.session_state[PROJECT]['connection'])
    at.selectbox(key=_key('topology')).set_value('symmetric_2L_T_bolted').run();assert not at.exception
    assert at.session_state[PROJECT]==bolt
    assert not set(WELDED_BRACE_FIELDS)&set(bolt['connection'])


def test_edit_count_import_export_and_atomic_rejection():
    at=fresh();at.number_input(key=_key('bolt_count')).set_value(5).run();assert not at.exception
    native=deepcopy(at.session_state[PROJECT]);assert type(native['connection']['bolt_count']) is int
    assert decode_project(json.dumps(native)).bolt_count==5
    # Return to contained preset before report testing.
    at.selectbox(key='cg_example').set_value(list(presets())[0]).run();button(at,'Usar exemplo de canto').click().run()
    button(at,'Gerar memória de canto').click().run();assert REPORT in at.session_state
    snapshot={k:deepcopy(at.session_state[k]) for k in (PROJECT,RESULT,REPORT,TEMPLATE,ACCEPTED,DRAFT)}
    bad=deepcopy(snapshot[PROJECT]);bad['connection'].pop('bolt_count')
    at.get('file_uploader')[0].upload('bad.json',json.dumps(bad).encode(),'application/json').run();button(at,'Carregar projeto de canto').click().run()
    assert not at.exception and any('Não foi possível abrir' in x.value for x in at.error)
    for k,v in snapshot.items():assert at.session_state[k]==v,k
    at.number_input(key=_key('bolt_pitch')).set_value(58.).run();assert REPORT not in at.session_state

@pytest.mark.parametrize('single',[False,True])
def test_bolted_drawing_has_physical_bolts_and_no_diagonal_welds(single):
    c=bc(single);svg=image_bytes(c,fmt='svg');ids={e.get('id') for e in ET.fromstring(svg).iter()}
    assert sum(str(i).startswith('corner-bolt-') for i in ids)==4
    assert sum(str(i).startswith('corner-hole-') for i in ids)==4
    assert sum(str(i).startswith('T-shear-plane-') for i in ids)==(1 if single else 2)
    assert 'beam-root-double-fillet' in ids and 'column-root-double-fillet' in ids
    assert not any(str(i).startswith('brace-') and str(i).endswith('-fillet') for i in ids)
    assert not any(str(i).startswith('T-') and str(i).endswith('-fillet') for i in ids)
    assert svg==image_bytes(c,result={'approved':True},fmt='svg')
    signs=effort_convention_svg(c);assert signs==effort_convention_svg(replace(c,P=700000.));assert 'kN' not in signs

@pytest.mark.parametrize('single',[False,True])
@pytest.mark.parametrize('detailed',[False,True])
def test_word_branch_summary_traceability_and_current_images(single,detailed):
    c=bc(single);r=analyze(c);doc=create_report(c,detailed=detailed);s=body(doc)
    for text in ('parafusada','4 físicos','6.1.8.2','Contato','furo','COMPLETE_CUTS'):assert text in s,text
    assert 'Quatro soldas 2L–chapa' not in s and 'Duas soldas 1L–chapa' not in s
    assert 'Duas soldas da diagonal' not in s and 'Quatro soldas da diagonal' not in s
    if detailed:assert all(z['id'] in s for z in r['checks'])
    else:assert 'Auditoria detalhada' not in s
    with ZipFile(BytesIO(doc)) as z:assert image_bytes(c) in [z.read(n) for n in z.namelist() if n.startswith('word/media/')]
    mc=memory_text(c);assert '4 parafusos físicos' in mc and 'N por furo da chapa=25' in mc
    groups=physical_envelopes(r);assert all('soldas' not in e['component_label'].lower() for e in groups if e['component'] in ('bolts','angles','angle_bearing','gusset_bearing','angle_block'))


def test_zero_actual_ui_keeps_complete_synthetic_minimum_separate():
    at=fresh(bc(P=0.));r=at.session_state[RESULT]
    assert r['forces']['H']==0 and r['design_cases'][0]['design_P']==45000.
    assert not button(at,'Gerar memória de canto').disabled
    assert any('caso sintético separado' in x.value for x in at.info)
    button(at,'Gerar memória de canto').click().run();s=body(at.session_state[REPORT][2])
    assert 'Caso sintético de resistência mínima45kN' in s and 'L sintético derivado' in s
    assert 'CASO SINTÉTICO MÍNIMO45kN' in at.session_state['cg_mc_current']
