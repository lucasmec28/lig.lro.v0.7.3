"""Independent source/math fixtures, explicit topology and native-boundary acceptance.

Expected numbers are read from the immutable, separately authored qualification
packet. No production result is used to generate expected values.
"""
from dataclasses import replace
import copy
import json
import math
from pathlib import Path
import pytest
from lro.bolted_opposed_angle_gusset import (BoltedOpposedAngleGusset, evaluate, presets,
    CONNECTION_TYPE, COMPONENT_VERSION, input_errors, _geometry)
from lro.bolted_angle_gusset import BoltedAngleGusset
from lro.bolted_opposed_gusset_geometry import rupture_paths
from lro.welded_angle_gusset import MATERIALS

PACKET = Path(__file__).parents[1]/'docs'/'qualification_opposed_bolted0931'
DATA = json.loads((PACKET/'NEW_OPPOSED_BOLTED_FIXTURES.json').read_text())
BASE = next(iter(presets().values()))


def fixture_input(f):
    i = f['inputs']
    return replace(BASE, N=i['N'], theta_deg=i['theta'], plate_width=i['plate'][0],
        plate_height=i['plate'][1], plate_t=i['plate'][2], center_s=i['P'][0], center_n=i['P'][1],
        gauge=i['g'], angle_end=i['e'], n=i['n_per_row'], pitch=i['pitch'], drilled=i['drilled'],
        gusset_steel='ASTM A572 Gr.50' if i['materials']['gusset'][0] == 345 else 'ASTM A36')


@pytest.fixture(scope='module')
def fixture_results():
    return {f['id']: evaluate(fixture_input(f)) for f in DATA['fixtures']}


@pytest.mark.parametrize('f', DATA['fixtures'], ids=lambda f:f['id'])
def test_seventeen_independent_complete_routes(f, fixture_results):
    result = fixture_results[f['id']]
    expected_pass = f['status'] == 'METHOD_PASS_GIVEN_DECLARED_DETAIL'
    assert result['local_pass'] == expected_pass
    assert result['global_member_verified'] is False
    if not result['cases']:
        assert f['status'] == 'INVALID_GEOMETRY_OR_DETAIL'
        return
    actual = result['cases'][0]
    for key, value in f['utilizations'].items():
        assert actual['utilizations'][key] == pytest.approx(value, rel=3e-8, abs=1e-10), key
    for a, e in zip(result['geometry']['bolt_centers'], f['holes']):
        assert a == pytest.approx(e['xy'], rel=1e-12, abs=1e-10)
    for key in ('N', 'V', 'M'):
        assert actual['root'][key] == pytest.approx(f['root'][key], abs=1e-7)
    assert actual['root']['W_centroid_M'] == pytest.approx(f['root']['member_M'], abs=1e-7)
    assert actual['root']['weld_utilization'] == pytest.approx(f['root']['weld_u'])
    assert actual['solid_root_ligament']['end'] == pytest.approx(f['solid_root_ligament']['end'])
    assert actual['solid_root_ligament']['tensile'] == f['solid_root_ligament']['tensile']
    for a, e in zip(actual['solid_root_ligament']['cuts'], f['solid_root_ligament']['cuts']):
        for key in ('y', 'N', 'V', 'M', 'A', 'I', 'VM'):
            assert a[key] == pytest.approx(e[key], abs=1e-7)
        assert a['sigma'] == pytest.approx(e['sigma'], abs=1e-10)
    assert actual['nominal_min_sigma'] == pytest.approx(f['nominal_min_sigma'], rel=1e-7, abs=1e-8)
    assert len(actual['zigzag_net_chains']) == f['inputs']['n_per_row']**2
    for a, e in zip(actual['zigzag_net_chains'], f['zigzag_net_chains']):
        for key in ('An', 'R', 'D', 'stagger_credit', 'gross_width', 'net_width'):
            assert a[key] == pytest.approx(e[key], rel=1e-10, abs=1e-8)
        assert a['captured_ids'] == e['captured_ids']
    for a, e in zip(actual['unequal_partial_U_bounds'], f['unequal_partial_U_bounds']):
        for key in ('Agv', 'Anv', 'Ant', 'R', 'demand', 'start', 'end_min'):
            assert a[key] == pytest.approx(e[key], rel=1e-10, abs=1e-8)
    for e in f['gusset_center_witnesses']:
        a = next(p for p in actual['paths'] if p['component'] == 'gusset' and
            p['event'] == 'bolt_center' and p['family_id'] == e['id'] and abs(p['u']-e['u']) < 1e-9)
        for key in ('Agv', 'Anv', 'Ant', 'R', 'demand'):
            assert a[key] == pytest.approx(e[key], rel=1e-10, abs=1e-8)
    for component, expected in [('angle', f['angle_governing']), ('gusset', f['gusset_governing'])]:
        a = max((p for p in actual['paths'] if p['component'] == component), key=lambda p:p['utilization'])
        if f['inputs']['N'] > 0:
            assert a['R'] == pytest.approx(expected['R'], rel=2e-9)
            assert a['u'] == pytest.approx(expected['u'], abs=2e-5)
    assert result['member_actions']['existing_member_actions'] is None


@pytest.mark.parametrize('failure', DATA['same_geometry_failure_loads'], ids=lambda f:f['target'])
def test_all_concurrent_reference_failure_loads(failure):
    r = evaluate(replace(BASE, plate_width=340., N=failure['N']))
    assert not r['local_pass']
    for key, value in failure['all_utilizations'].items():
        assert r['utilizations'][key] == pytest.approx(value, rel=3e-8, abs=1e-10), key
    assert r['utilizations'][failure['target']] == pytest.approx(1.01, rel=3e-8)


def test_practical_sign_diagnostic_does_not_reject_or_waive_ligament():
    r = evaluate(BASE)
    assert r['local_pass']
    assert r['summary']['utilization'] == pytest.approx(.42115377416174804)
    assert r['root']['weld_utilization'] == pytest.approx(.38739195486544087)
    diagnostic = r['introduction_sign_diagnostic']
    assert diagnostic['affects_acceptance'] is False
    assert diagnostic['horizontal_min_sigma'] == pytest.approx(-.49989061791740674, abs=1e-8)
    assert diagnostic['force_normal_min_sigma'] == pytest.approx(-.5070754162818636, abs=1e-8)
    bad = evaluate(replace(BASE, theta_deg=70.))
    assert bad['status'] == 'OUTSIDE_SCOPE'
    assert bad['solid_root_ligament']['min_sigma'] == pytest.approx(-2.303141578, abs=1e-8)
    assert any(i['id'].endswith('compressed_solid_ligament') for i in bad['issues'])


def test_physical_bolts_rows_grip_and_contact_are_not_T_shortcut():
    r = evaluate(BASE); g = r['geometry']; a = r['cases'][0]
    assert g['row_v'] == [-46.25, 46.25]
    assert g['physical_bolt_count'] == 6
    assert g['shear_planes_per_bolt'] == 1
    assert g['grip'] == pytest.approx(18.85)
    assert len(a['bolt_planes']) == len(a['bearing']['gusset']) == 6
    assert {p['plane'] for p in a['bolt_planes']} == {1}
    assert all(p['demand'] == pytest.approx(100000/6) for p in a['bolt_planes'])
    assert a['bearing']['gusset'][2]['lc'] != a['bearing']['gusset'][5]['lc']
    assert a['force_split']['each_gusset_hole'] == pytest.approx(100000/6)
    assert a['force_split']['common_gusset'] == a['force_split']['root'] == 100000
    changed = evaluate(replace(BASE, threads_excluded_2=True))['cases'][0]['bolt_planes']
    assert [p['coefficient'] for p in changed] == [.45]*3+[.56]*3
    assert [p['demand'] for p in changed] == [100000/6]*6
    assert len({x['id'] for x in r['checks']}) == len(r['checks'])


def test_all_simultaneous_force_masks_are_enumerated_and_hole_union_subtracted():
    r = evaluate(BASE)
    crossing = [x for x in r['sections']['intervals'] if len(x['crossing_bolts']) == 2]
    assert crossing
    intervals = {tuple(x['interval']) for x in crossing}
    for interval in intervals:
        masks = {tuple(x['force_mask']) for x in crossing if tuple(x['interval']) == interval}
        assert masks == {(0, 0), (0, 1), (1, 0), (1, 1)}
    normal = r['force_normal_cuts']
    assert any(len(x['active_ids']) == 1 for x in normal)
    witness = min(normal, key=lambda x:x['min_sigma'])
    assert witness['u'] == pytest.approx(59., abs=1e-8)
    assert len(witness['active_ids']) == 1
    for x in normal:
        assert x['net_area'] == pytest.approx(BASE.plate_t*sum(b-a for a,b in x['net_segments']))


def test_refined_bounds_are_correlated_and_never_the_superseded_guard():
    r = evaluate(BASE)
    left, right = r['unequal_partial_U_bounds'][::3]
    assert left['start'] == -41
    assert left['k'] == 3
    assert left['remaining_hole_deduction'] == 36
    assert left['R'] == pytest.approx(254961.00847041968)
    assert right['R'] == pytest.approx(277614.127519816)
    assert r['utilizations']['gusset_unequal_partial_bound'] == pytest.approx(.19610841791048358)
    for p in r['unequal_partial_U_bounds']:
        assert p['Ant'] == 0
        assert p['demand'] == pytest.approx(p['k']*BASE.N/(2*BASE.n))
    assert evaluate(replace(BASE, N=150000.))['local_pass']
    nondrilled = evaluate(replace(BASE, drilled=False))
    assert nondrilled['local_pass']
    assert nondrilled['geometry']['hole_diameter'] == 18
    assert nondrilled['geometry']['net_hole_diameter'] == 20
    assert nondrilled['solid_root_ligament']['end'] == r['solid_root_ligament']['end']
    assert nondrilled['utilizations']['gusset_unequal_partial_bound'] == pytest.approx(.197373183, abs=1e-9)


def test_minimum_and_optional_recommendation_are_whole_connection_cases():
    r = evaluate(replace(BASE, N=0., recommend_half_capacity=True))
    assert [x['id'] for x in r['cases']] == ['actual', 'minimum_45kN', 'recommended_half']
    actual, minimum, recommendation = r['cases']
    assert actual['N'] == 0 and actual['root']['N'] == 0
    assert all(v == 0 for v in actual['utilizations'].values())
    assert minimum['N'] == 45000 and minimum['force_split']['each_angle'] == 22500
    assert minimum['force_split']['each_bolt'] == 7500
    assert recommendation['N'] == pytest.approx(.5*min(actual['angle']['yield_R_total'], actual['angle']['net_R_total']))


def test_mirror_rigid_member_rotation_and_force_line_transport():
    a = evaluate(BASE); b = evaluate(replace(BASE, theta_deg=100.))
    assert a['summary']['utilization'] == pytest.approx(b['summary']['utilization'])
    assert a['root']['V'] == pytest.approx(-b['root']['V'])
    assert a['root']['M'] == pytest.approx(-b['root']['M'])
    column = evaluate(replace(BASE, support_member='column'))
    assert column['checks'] == a['checks'] and column['root'] == a['root']
    angle = math.radians(BASE.theta_deg)
    shifted = evaluate(replace(BASE, center_s=8*math.cos(angle), center_n=150+8*math.sin(angle), row_offset=-8.))
    for x, y in zip(shifted['geometry']['bolt_centers'], a['geometry']['bolt_centers']):
        assert x == pytest.approx(y)
    assert shifted['root']['M'] == pytest.approx(a['root']['M'])
    assert shifted['summary']['utilization'] == pytest.approx(a['summary']['utilization'])


@pytest.mark.parametrize('change', [dict(n=True), dict(n=3.0), dict(n=1), dict(N=float('nan')),
    dict(center_s=float('inf')), dict(heel_extent=True), dict(threads_excluded_1=1), dict(static='yes')])
def test_strict_input_types(change):
    r = evaluate(replace(BASE, **change))
    assert r['status'] == 'INVALID_INPUT'
    json.dumps(r, allow_nan=False)


def test_no_arbitrary_bolt_count_cap():
    assert not input_errors(replace(BASE, n=51))
    assert replace(BASE, n=51).to_dict()['connection']['n'] == 51


@pytest.mark.parametrize('change', [dict(arrangement='2L-T'), dict(arrangement='1L'), dict(support_face='web'),
    dict(theta_deg=0.), dict(theta_deg=180.), dict(N=-1.), dict(V=1.), dict(M=1.), dict(torsion=1.),
    dict(fatigue=True), dict(seismic=True), dict(static=False), dict(normal_combination=False),
    dict(support_profile='built up'), dict(angle_profile='unknown'), dict(db=16.1), dict(exposure='unknown'),
    dict(bolt='ASTM A307', pretensioned=True)])
def test_unqualified_domain(change):
    assert not evaluate(replace(BASE, **change))['local_pass']


@pytest.mark.parametrize('change', [dict(plate_t=0.), dict(pitch=0.), dict(gauge=0.), dict(angle_end=0.),
    dict(tool_radius=0.), dict(root_weld_leg=0.), dict(fabrication_clearance=-1.), dict(washer_stack=-1.),
    dict(center_n=30.), dict(center_s=200.), dict(gauge=30.), dict(pitch=17.)])
def test_actual_geometry_boundaries(change):
    assert not evaluate(replace(BASE, **change))['local_pass']


def test_materials_and_electrode_are_independent():
    base = evaluate(BASE)
    for changes, unchanged, changed in [
        (dict(gusset_steel='ASTM A572 Gr.50'), 'angle_block', 'plate_block'),
        (dict(angle_steel='ASTM A572 Gr.50'), 'plate_block', 'angle_block'),
        (dict(support_steel='ASTM A36'), 'angle_block', 'W_web_VM'),
        (dict(root_electrode='E70'), 'plate_block', 'root_weld')]:
        r = evaluate(replace(BASE, **changes))
        assert r['utilizations'][unchanged] == base['utilizations'][unchanged]
        assert r['utilizations'][changed] != base['utilizations'][changed]
    missing = evaluate(BoltedOpposedAngleGusset())
    assert missing['status'] == 'DETAILING_PENDING'
    assert missing['summary']['mechanics_pass']
    assert not missing['geometry']['heel_extent_catalog_verified']


def test_native_strict_identity_and_recomputation():
    native = BASE.to_dict()
    assert native['connection_type'] == CONNECTION_TYPE
    assert native['component_version'] == COMPONENT_VERSION
    assert BoltedOpposedAngleGusset.from_dict(json.loads(json.dumps(native))) == BASE
    assert evaluate(BoltedOpposedAngleGusset.from_dict(native))['local_pass']
    with pytest.raises(ValueError):
        BoltedAngleGusset.from_dict(native)
    with pytest.raises(ValueError):
        BoltedOpposedAngleGusset.from_dict(BoltedAngleGusset().to_dict())
    mutations = [('schema_version', True), ('connection_type', 'axial_double_angle'),
        ('component_version', '0.9.30-gusset-variants-dev')]
    for key, value in mutations:
        bad = copy.deepcopy(native); bad[key] = value
        with pytest.raises(ValueError):
            BoltedOpposedAngleGusset.from_dict(bad)
    for alteration in ('extra', 'missing', 'units', 'premises', 'threads', 'arrangement', 'results'):
        bad = copy.deepcopy(native)
        if alteration == 'extra': bad['connection']['second_gusset_t'] = 12.5
        elif alteration == 'missing': del bad['connection']['n']
        elif alteration == 'units': bad['units']['force'] = 'kN'
        elif alteration == 'premises': bad['fixed_assumptions']['shear_planes_per_bolt'] = 2
        elif alteration == 'threads': bad['connection']['threads_excluded_2'] = 1
        elif alteration == 'arrangement': bad['connection']['arrangement'] = '2L-T'
        else: bad['results'] = {'global_pass': True}
        with pytest.raises(ValueError):
            BoltedOpposedAngleGusset.from_dict(bad)
    edited = copy.deepcopy(native); edited['connection']['N'] = 300000.
    assert not evaluate(BoltedOpposedAngleGusset.from_dict(edited))['local_pass']


def test_supported_root_segments_are_inactive_and_mirror_correctly():
    c = replace(BASE, theta_deg=40., center_n=135., plate_width=400.)
    r = evaluate(c)
    inactive = r['geometry']['inactive_path_families']
    assert inactive and all(p['root_contact_length'] > 0 for p in inactive)
    assert all(p['active'] is False for p in inactive)
    assert all(p['root_contact_length'] <= 1e-8 for p in r['paths'] if p['component'] == 'gusset')
    # Independent rectangle/root half-plane intersection for this witness.
    theta = math.radians(40.)
    expected = 200.-(-50.+135.*math.sin(theta))/math.cos(theta)
    witness = next(p for p in inactive if p['family_id'] == 'L0_1' and p['u'] == -50.)
    assert witness['root_contact_length'] == pytest.approx(expected)
    mirrored = evaluate(replace(c, theta_deg=140.))
    assert len(mirrored['geometry']['inactive_path_families']) == len(inactive)
    assert not r['local_pass'] and not mirrored['local_pass']


def test_actual_whitmore_free_side_clipping_without_width_guard():
    c = replace(BASE, plate_width=200.)
    r = evaluate(c)
    assert r['local_pass']
    w = r['Whitmore']
    assert w['clipped']
    assert w['endpoints'][0][0] == pytest.approx(-100.)
    C, S = math.cos(math.radians(80.)), math.sin(math.radians(80.))
    left = (-100.-(-50.*C))/S
    right = 46.25+100.*math.tan(math.pi/6)
    assert w['width'] == pytest.approx(right-left)
    assert w['gross_area'] == pytest.approx((right-left)*12.5)
    assert sum(p['thickness'] for p in r['Whitmore_rows']) == 12.5


def test_receiving_W_both_ends_and_single_plane_long_grip():
    baseline = evaluate(BASE)
    left = evaluate(replace(BASE, support_end_left=200.))
    right = evaluate(replace(BASE, support_end_right=200.))
    assert left['root']['W_web_local_yield_R'] == right['root']['W_web_local_yield_R']
    assert left['root']['W_web_local_yield_R'] < baseline['root']['W_web_local_yield_R']
    long = evaluate(replace(BASE, washer_stack=100.))
    pretension = evaluate(replace(BASE, washer_stack=100., pretensioned=True))
    assert long['geometry']['grip'] == pytest.approx(118.85)
    expected_factor = 1.-.01*(118.85-5*16.)/1.5
    assert long['geometry']['grip_factor'] == pytest.approx(expected_factor)
    assert long['utilizations']['bolt_shear'] == pytest.approx(baseline['utilizations']['bolt_shear']/expected_factor)
    assert pretension['utilizations']['bolt_shear'] == baseline['utilizations']['bolt_shear']
