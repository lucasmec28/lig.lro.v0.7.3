from pathlib import Path
from streamlit.testing.v1 import AppTest


def test_qualified_weld_modules_guarded_before_import(tmp_path):
    root=Path(__file__).resolve().parents[1]
    (tmp_path/'app.py').write_bytes((root/'app.py').read_bytes())
    at=AppTest.from_file(str(tmp_path/'app.py'),default_timeout=30).run()
    assert not at.exception
    assert any('Instalação incompleta' in x.value for x in at.error)
    for name in ('base_weld_qualified','column_base_weld_drawing','column_base_weld_report'):
        assert any('lro/'+name+'.py' in x.value for x in at.code)
