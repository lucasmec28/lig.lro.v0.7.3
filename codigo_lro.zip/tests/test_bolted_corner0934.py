"""Finite bolted two-root adapter, source-derived oracle and adversarial input."""
from copy import deepcopy
from dataclasses import replace
import json,math
from pathlib import Path
import pytest
from lro.corner_gusset import CornerGusset,analyze,geometry,presets,BOLTED_FIELDS,WELDED_BRACE_FIELDS
from lro.bolted_corner import block_state,section
ROOT=Path(__file__).resolve().parents[1]
ORACLE=json.loads((ROOT/'docs/qualification_bolted_corner0934/ORACLE.json').read_text())
AMENDMENTS=json.loads((ROOT/'docs/qualification_bolted_corner0934/LOGICAL_WITNESS_AMENDMENTS.json').read_text())['records']
def bc(single=False,**kw):
    return replace(list(presets().values())[1 if single else 0],**kw)
def rows(r):return {z['id']:z for z in r['checks']}

@pytest.mark.parametrize('single',[False,True])
def test_independent_BC1_all_new_and_common_strengths(single):
    c=bc(single);r=analyze(c);got=rows(r);prefix='1L' if single else '2L-T'
    assert r['status']=='PASS' and r['complete'] and r['mechanics_complete'] and r['assembly_qualified']
    expected=[z for z in ORACLE['checks'] if z['id'].startswith((prefix+'_','common_','gusset_'))]+ORACLE['common_full_joint']['checks']
    for z in expected:
        for key in ('demand','resistance','utilization'):assert got[z['id']][key]==pytest.approx(z[key],rel=1e-9,abs=1e-7),(z['id'],key)
    assert r['utilization']==pytest.approx(.5385303003488986)
    assert r['brace']['angle_count']==(1 if single else 2)
    assert r['brace']['physical_bolt_count']==4 and r['brace']['force_per_gusset_hole']==25000
    assert r['geometry']['physical_gusset_count']==1
    assert not r['geometry']['brace_weld_lines'] and r['brace']['weld_count']==0
    assert max(abs(v) for x in r['equilibrium_residuals'].values() for v in x)<1e-7

@pytest.mark.parametrize('single',[False,True])
def test_all_exact_section_and_path_witnesses(single):
    c=bc(single);g=geometry(c);r=analyze(c)
    for ex in ORACLE['section_station_oracles']:
        if ex is None:continue
        z=section(c,g,r['forces'],ex['u'],ex['include_cut_hole'],ex['net'])
        for key in ('A','centroid_v','I','N','V','M','nominal_VM'):assert z[key]==pytest.approx(ex[key],rel=1e-9,abs=1e-6)
    for ex in ORACLE['gusset_block_paths']:
        z=block_state(c,g,ex['u'],ex['side'])
        # METHOD_REVIEW_CLARIFICATIONS.md supersedes the old first-edge
        # classification only at the exact free/support shared vertex.
        amended=next((a for a in AMENDMENTS if (a['id'],a['side'],a['u'])==(ex['id'],ex['side'],ex['u'])),None)
        if amended:
            assert ex['active'] is amended['source_active'] and z['active'] is amended['reviewed_active']
            assert z['path_xy'][-1]==pytest.approx(amended['endpoint_xy'],abs=1e-7)
            for actual,expected in [('Agv','Agv'),('Anv','Anv'),('Ant','Ant'),('demand','D'),('resistance','R'),('utilization','utilization')]:
                assert z[actual]==pytest.approx(amended['independent_boundary_numeric_witness'][expected],rel=1e-10)
            continue
        assert z['active']==ex['active']
        if z['active']:
            for key in ('Agv','Anv','Ant','demand','resistance'):assert z[key]==pytest.approx(ex[key],rel=1e-9,abs=1e-7)


def test_face_mirror_and_two_angles_do_not_double_the_shared_plate():
    one=analyze(bc(True));neg=analyze(bc(True,single_angle_face='negative'));two=analyze(bc())
    assert one['forces']==neg['forces']==two['forces']
    assert rows(one)['common_gusset_bearing4']==rows(two)['common_gusset_bearing4']
    assert one['geometry']['brace_centroid_z']==-neg['geometry']['brace_centroid_z']
    assert not one['spatial_idealization']['assumed_spatial_cancellation']
    assert two['spatial_idealization']['assumed_spatial_cancellation']
    assert not two['spatial_idealization']['inplane_centroid_offset_cancels']
    assert one['spatial_idealization']['physical_angle_centroid_v']==pytest.approx(-17.9)

@pytest.mark.parametrize('P',[0.,1.,20000.,44999.])
def test_minimum45_complete_separate_design_case(P):
    c=bc(P=P);r=analyze(c);actual=r['forces'];minimum=r['design_cases'][0]['result']
    assert actual['H']==pytest.approx(P/math.sqrt(2));assert r['design_cases'][0]['design_P']==45000.
    assert minimum['forces']['H']==pytest.approx(45000/math.sqrt(2))
    for prefix in ('beam_cut','upper_column_cut'):
        assert actual[prefix]==minimum['forces'][prefix]
    assert actual['lower_column_cut']!=minimum['forces']['lower_column_cut']
    for row in minimum['checks']:assert row['case_id']=='minimum_45kN' and row['id'].startswith('minimum45__')
    assert minimum['forces']['equilibrium_residuals']['assembly']==pytest.approx([0,0,0],abs=1e-7)
    assert minimum['brace']['force_per_gusset_hole']==11250
    assert r['force_cases']['actual']==actual
    checked=analyze(replace(c,compare_lower_cut=True,lower_column_check_Fx=actual['lower_column_cut']['Fx'],lower_column_check_Fy=actual['lower_column_cut']['Fy'],lower_column_check_M=actual['lower_column_cut']['M']))
    assert not any('mismatch' in i['id'] for i in checked['issues'])

@pytest.mark.parametrize('P',[45000.,100000.,-1.,-100000.])
def test_minimum_not_duplicated_or_applied_to_compression(P):
    r=analyze(bc(P=P));assert not r.get('design_cases')
    if P<0:assert not r['complete'] and any(i['id']=='UNVERIFIED_BRACE_COMPRESSION' for i in r['issues'])

@pytest.mark.parametrize('field,value',[(k,True) for k in ('bolt_count','bolt_diameter','bolt_start','bolt_pitch','bolt_gauge','bolt_tool_radius')]+[('bolt_count',4.0),('bolt_count',1),('bolt_diameter',float('nan')),('bolt','bad')])
def test_new_native_values_are_strict(field,value):
    raw=bc().to_dict();raw['connection'][field]=value
    with pytest.raises((ValueError,TypeError)):CornerGusset.from_dict(raw)


def test_branch_native_legacy_defaults_and_forbidden_weld_fields():
    for c in (bc(),bc(True),bc(True,single_angle_face='negative')):
        d=c.to_dict();assert CornerGusset.from_dict(d)==c
        assert set(BOLTED_FIELDS)<=set(d['connection']);assert not set(WELDED_BRACE_FIELDS)&set(d['connection'])
        d['connection']['brace_weld_length']=1
        with pytest.raises(ValueError):CornerGusset.from_dict(d)
    for path in (ROOT/'examples/corner_gusset0932/C1.json',ROOT/'examples/single_angle_corner0933/C1_1L_positive.json'):
        if path.exists():
            d=json.loads(path.read_text());c=CornerGusset.from_dict(d)
            assert not set(BOLTED_FIELDS)&set(c.to_dict()['connection'])


def test_drilled_hole_policy_changes_net_not_bearing():
    a=analyze(bc());b=analyze(bc(bolt_drilled=False));ra,rb=rows(a),rows(b)
    assert a['geometry']['hole_diameter']==b['geometry']['hole_diameter']==18.
    assert b['geometry']['net_hole_diameter']==20.
    for k in ra:
        if 'bearing' in k:assert ra[k]==rb[k]
    assert b['brace']['An']<a['brace']['An'] and rb['gusset_block_tangent_U']['utilization']>ra['gusset_block_tangent_U']['utilization']


def test_thread_planes_and_grip_are_individual():
    a=rows(analyze(bc()));b=rows(analyze(bc(bolt_threads_excluded_1=True)))
    assert b['2L-T_bolt1_plane1']['resistance']/a['2L-T_bolt1_plane1']['resistance']==pytest.approx(.56/.45)
    assert b['2L-T_bolt1_plane2']==a['2L-T_bolt1_plane2']
    c=analyze(bc(bolt_washer_stack=100.));assert c['geometry']['bolt_grip_factor']<1
    d=analyze(bc(bolt_washer_stack=100.,bolt_pretensioned=True));assert d['geometry']['bolt_grip_factor']==1

@pytest.mark.parametrize('change,expected',[(dict(bolt_heel_extent=0.),'UNVERIFIED'),(dict(bolt_tool_radius=100.),'INVALID'),(dict(bolt_gauge=70.),'INVALID'),(dict(bolt_start=100.),'INVALID'),(dict(workpoint_offset=1.),'UNVERIFIED'),(dict(P=1000000.),'FAIL')])
def test_distinct_strength_geometry_and_qualification_states(change,expected):
    r=analyze(bc(**change));assert r['status']==expected
    if change.get('bolt_heel_extent')==0:assert r['mechanics_complete'] and not r['assembly_qualified']

@pytest.mark.parametrize('phi,w,h',[(40.,360.,330.),(50.,330.,360.)])
def test_contained_changed_angles_have_no_negative_linear_stress_ban(phi,w,h):
    r=analyze(bc(phi_deg=phi,plate_width=w,plate_height=h,bolt_start=375.))
    assert r['status']=='PASS';assert r['gusset_body']['minimum_normal']<0
    assert not any('COMPRESSION' in i['id'] for i in r['issues'])
    assert any(i['id']=='nominal_section_negative_stress' for i in r['issues'])


def test_gusset_edge_interpretation_is_not_strength_failure():
    r=analyze(bc(plate_width=450.,plate_height=450.))
    issues=[i for i in r['issues'] if 'maximum_interpretation' in i['id']]
    assert issues and all(i['severity']=='unverified' for i in issues)
    assert not r['complete']

@pytest.mark.parametrize('single',[False,True])
def test_numeric_guard_keeps_requested_bolted_identity(single):
    c=bc(single,P=1e101);r=analyze(c)
    assert r['status']=='INVALID' and not r['checks']
    assert r['assumptions']['brace_adapter']==c.topology and 'parafusada' in r['family']

@pytest.mark.parametrize('Lc,unqualified',[(949.999,False),(950.,False),(950.001,True),(1100.,True),(1270.,True)])
def test_specific_long_connection_method_boundary(Lc,unqualified):
    from lro.bolted_corner import detailing
    c=bc(bolt_count=2,bolt_pitch=Lc);g=geometry(c);out={'checks':[],'issues':[]}
    detailing(c,g,out)
    found=[i for i in out['issues'] if i['id']=='bolt_long_joint_distribution']
    assert bool(found) is unqualified
    if found:assert found[0]['severity']=='unverified' and 'NBR6.3.8' in found[0]['message'] and 'diagnósticos' in found[0]['message']
