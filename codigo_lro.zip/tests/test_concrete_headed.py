"""Expected values are independent research arithmetic, not production helpers."""
import copy
import json
import math
from pathlib import Path
import pytest
from lro.concrete_headed import evaluate_headed

MM_IN=25.4
N_LBF=4.4482216152605
MPA_PSI=0.006894757293168361
FIX={r['id']:r for r in json.loads((Path(__file__).parents[1]/'docs/HEADED_ANCHORS_BENCHMARKS_V086.json').read_text())['cases']}


def rod(id='A1',x=4,y=20,t=30000):
    return dict(id=id,x=x*MM_IN,y=y*MM_IN,tension=t*N_LBF)


def detail(**kw):
    d=dict(family='headed',bearing_area_ref='DG1 Table4-2 actual heavy-hex detail',effective_area_qualified=True,
           detail_confirmed=True,detail_ref='AN-01 intact prism and actual assembly fit')
    d.update(kw)
    return d


def run(rods=None,bounds=None,hef=12,fc=4000*MPA_PSI,area=1.5*MM_IN**2,d=None):
    return evaluate_headed(rods if rods is not None else [rod()],bounds or (0,0,80*MM_IN,80*MM_IN),
                           hef*MM_IN,fc,area,detail() if d is None else d)


def test_dg1_pullout_nut_fixtures_and_pending_head_mechanics():
    for key,a in [('P01_DG1_7_8_nut',1.19),('P02_DG1_one_in_nut',1.50)]:
        got=run(area=a*MM_IN**2,d=detail(family='buried_nut'));c=got['pullout']['checks'][0]
        assert got['pullout']['status']=='calculated'
        assert c['resistance']==pytest.approx(FIX[key]['expected']['Rd_lbf']*N_LBF,rel=1e-12)
        assert c['phi']==.70 and c['factors']['psi_cP']==1
        assert got['prerequisites']['mechanical']['status']=='pending'
        assert got['prerequisites']['status']=='pending'


def test_pullout_never_pools_unequal_actual_demands():
    rods=[rod('A1',4,20,1000),rod('A2',4,32,1000),rod('A3',14,20,1000),rod('A4',14,32,40000)]
    got=run(rods)['pullout']
    assert len(got['checks'])==4
    assert max(c['ratio'] for c in got['checks'])==pytest.approx(40000/33600)
    assert max(got['checks'],key=lambda c:c['ratio'])['ids']==['A4']
    assert sum(r['tension'] for r in rods)<sum(c['resistance'] for c in got['checks'])
    assert any(c['ratio']>1 for c in got['checks'])


@pytest.mark.parametrize('y,key,alpha',[(20,'S01_single_remote_corner',1),(6,'S02_single_corner',.625),(4,'S03_equal_corner_edges',.5)])
def test_single_corner_source_fixtures(y,key,alpha):
    got=run([rod(y=y)])['sideface']
    assert got['status']=='calculated' and len(got['checks'])==1
    c=got['checks'][0]
    assert c['resistance']==pytest.approx(FIX[key]['expected']['Rd_lbf']*N_LBF,rel=1e-12)
    assert c['factors']['alpha_corner']==alpha
    assert c['ca1']==pytest.approx(4*MM_IN) and c['phi']==.7


def test_group_corner_is_not_a_single_factor_and_envelope_is_explicit():
    rods=[rod('A1',4,6,30000),rod('A2',4,18,10000)]
    got=run(rods)['sideface'];assert got['status']=='calculated' and len(got['checks'])==1
    c=got['checks'][0]
    assert c['method']=='ACI 17.6.4.2' and c['basis']=='source'
    assert c['factors']['alpha_group']==1.5
    assert c['factors']['perpendicular_edge_modifier_applied'] is False
    assert 'alpha_corner' not in c['factors']
    assert c['resistance']==pytest.approx(52052.89617302768*N_LBF,rel=1e-12) and c['ratio']<1
    extra=run(rods,d=detail(isolated_envelope=True))['sideface']
    assert len(extra['checks'])==3
    assert next(q for q in extra['checks'] if q['basis']=='source')==c
    conservative=[q for q in extra['checks'] if q['basis']=='supplemental_isolated_envelope']
    assert max(q['ratio'] for q in conservative)==pytest.approx(30000/21688.706738761535)
    assert any(q['ratio']>1 for q in conservative)


def test_actual_edge_row_sum_uses_tangent_spacing_not_whole_group():
    rods=[rod('LB',4,20,5000),rod('LT',4,32,15000),rod('RB',14,20,10000),rod('RT',14,32,20000)]
    s=run(rods,bounds=(0,0,42*MM_IN,60*MM_IN))['sideface']
    assert s['status']=='calculated' and len(s['checks'])==1
    c=s['checks'][0]
    assert c['ids']==['LB','LT'] and c['demand']==pytest.approx(20000*N_LBF)
    assert c['spacing']==pytest.approx(12*MM_IN)
    assert c['ratio']==pytest.approx(20000/52052.89617302768)
    assert all(not s['edges'][e]['ids'] for e in ('right','bottom','top'))


def test_moment_reversal_preserves_loaded_physical_ids():
    bounds=(0,0,42*MM_IN,60*MM_IN)
    near=[rod('LB',4,20,10000),rod('LT',4,32,10000),rod('RB',14,20,0),rod('RT',14,32,0)]
    far=[rod('LB',4,20,0),rod('LT',4,32,0),rod('RB',14,20,10000),rod('RT',14,32,10000)]
    assert run(near,bounds)['sideface']['status']=='calculated'
    rev=run(far,bounds)
    assert rev['sideface']['status']=='not_applicable' and rev['sideface']['checks']==[]
    assert {c['ids'][0] for c in rev['pullout']['checks']}=={'RB','RT'}


def test_physical_embedment_strict_trigger_and_no_fictitious_override():
    assert run(hef=10)['sideface']['status']=='not_applicable'
    assert run(hef=10.000001)['sideface']['status']=='calculated'
    assert run(hef=9.999999)['sideface']['status']=='not_applicable'
    assert run(hef=12,d=detail(breakout_fictitious_h=9*MM_IN))['sideface']['status']=='calculated'


def test_six_c_boundary_keeps_local_demands_and_no_pool():
    s=run([rod('A1',4,20,1000),rod('A2',4,44,40000)])['sideface']
    assert len(s['checks'])==2 and s['edges']['left']['branch']=='independent_single_anchors'
    assert all(c['resistance']==pytest.approx(34701.930782018455*N_LBF) for c in s['checks'])
    assert max(c['ratio'] for c in s['checks'])>1
    assert sum(c['demand'] for c in s['checks'])<sum(c['resistance'] for c in s['checks'])
    below=run([rod('A1',4,20,1000),rod('A2',4,43.999999,40000)])['sideface']
    assert len(below['checks'])==1
    assert below['checks'][0]['resistance']==pytest.approx(FIX['S09_six_c_just_below']['expected']['Rd_lbf']*N_LBF)


def test_partial_supported_face_survives_unequal_susceptible_depths():
    rods=[rod('A1',4,4,5000),rod('A2',4,30,5000),rod('A3',14,4,5000),rod('A4',14,30,5000)]
    got=run(rods,hef=40)
    assert got['pullout']['status']=='calculated' and len(got['pullout']['checks'])==4
    assert got['sideface']['status']=='pending' and got['sideface']['edges']['left']['status']=='pending'
    assert any(c.get('edge')=='bottom' for c in got['sideface']['checks'])
    assert any('mais de uma' in reason for reason in got['sideface']['reasons'])
    assert not any(c.get('edge')=='left' and c['basis']=='source' for c in got['sideface']['checks'])


def test_no_plate_area_credit_without_qualified_adequate_mechanical_proof():
    for d in [detail(family='buried_plate_nut'),detail(family='buried_plate_nut',mechanical_resistance=1e6),
              detail(family='buried_plate_nut',mechanical_ref='PL-01'),
              detail(family='buried_plate_nut',mechanical_resistance=1e6,mechanical_ref='PL-01',effective_area_qualified=False)]:
        r=run(d=d)
        assert r['pullout']['status']=='pending' and r['pullout']['checks']==[] and r['sideface']['status']=='pending'
    adequate=detail(family='buried_plate_nut',mechanical_resistance=1e6,mechanical_ref='PL-01',qualified_bearing_area=1.5*MM_IN**2)
    assert run(d=adequate)['pullout']['status']=='calculated'
    stale=copy.deepcopy(adequate);stale['qualified_bearing_area']*=2
    assert run(d=stale)['pullout']['status']=='pending'
    weak=copy.deepcopy(adequate);weak['mechanical_resistance']=100
    failed=run(d=weak)
    assert failed['pullout']['status']=='pending' and failed['prerequisites']['mechanical']['status']=='failed'
    assert failed['prerequisites']['mechanical']['checks'][0]['ratio']>1


def test_direct_head_mechanical_failure_visible_beside_concrete():
    got=run(d=detail(mechanical_resistance=100,mechanical_ref='HD-01'))
    assert got['pullout']['status']=='calculated'
    assert got['prerequisites']['mechanical']['status']=='failed' and got['prerequisites']['status']=='failed'
    assert got['prerequisites']['mechanical']['checks'][0]['phi'] is None


@pytest.mark.parametrize('d',[detail(detail_confirmed=False),detail(detail_ref=''),detail(effective_area_qualified=False),
                             detail(bearing_area_ref=''),detail(family='hook_j'),detail(intact_concrete=False),
                             detail(normalweight=False),detail(cracked=False),detail(seismic=True)])
def test_detail_material_scope_gates(d):
    got=run(d=d)
    assert got['pullout']['status']=='pending' and got['sideface']['status']=='pending'
    assert not got['pullout']['checks'] and got['prerequisites']['status']=='pending'


@pytest.mark.parametrize('value',[True,False,None,'100',float('nan'),float('inf'),-1,0,10**1000])
def test_invalid_bearing_area(value):
    r=run(area=value)
    assert r['pullout']['status']=='invalid' and not r['pullout']['checks']


@pytest.mark.parametrize('field,value',[('x',True),('y',float('nan')),('tension',float('inf')),('tension',-1),('id','')])
def test_invalid_anchor_inputs(field,value):
    r=rod();r[field]=value
    assert run([r])['pullout']['status']=='invalid'


@pytest.mark.parametrize('kw',[{'mechanical_resistance':True},{'mechanical_resistance':float('nan')},{'mechanical_resistance':0},
                              {'qualified_bearing_area':False},{'effective_area_qualified':1},{'detail_confirmed':'true'}, {'isolated_envelope':1}])
def test_invalid_detail_fields(kw):
    assert run(d=detail(**kw))['pullout']['status']=='invalid'


def test_malformed_entries_never_escape():
    for anchors in (None,{},[],[None],[False],[1],[[]],[{}],[{'id':'A'}]):
        assert evaluate_headed(anchors,(0,0,100,100),50,30,200,detail())['pullout']['status']=='invalid'
    for d in (None,[],True,1):
        assert evaluate_headed([rod()],(0,0,3000,3000),300,30,900,d)['pullout']['status']=='invalid'
    for bounds in (None,[],{},[1],(0,0,1),False):
        assert evaluate_headed([rod()],bounds,300,30,900,detail())['pullout']['status']=='invalid'


def test_invalid_bounds_coordinates_duplicates():
    assert run(bounds=(0,0,0,100))['pullout']['status']=='invalid'
    assert run(bounds=(False,0,100,100))['pullout']['status']=='invalid'
    assert run([rod(x=0)])['pullout']['status']=='invalid'
    assert run([rod(),rod('A2')])['pullout']['status']=='invalid'
    assert run([rod(),rod('A1',x=14)])['pullout']['status']=='invalid'


def test_no_tension_not_an_anchorage_approval():
    got=run([rod(t=0)])
    assert got['pullout']['status']=='not_demanded' and got['sideface']['status']=='not_demanded'
    assert got['prerequisites']['mechanical']['status']=='pending' and got['prerequisites']['remaining_modes']


def test_metric_fixture_uses_us_sideface_coefficient():
    got=evaluate_headed([dict(id='A',x=100,y=1000,tension=1000)],(0,0,4000,4000),300,30,900,detail())
    expected=FIX['U01_canonical_US_metric_input']['expected']
    assert got['pullout']['checks'][0]['resistance']==pytest.approx(151200)
    assert got['sideface']['checks'][0]['resistance']==pytest.approx(expected['sideface_Rd_N'],rel=1e-12)
    assert got['sideface']['checks'][0]['resistance']!=pytest.approx(.7*13*100*math.sqrt(900)*math.sqrt(30),rel=1e-4)


def test_area_scaling_permutation_and_inputs_unmodified():
    rods=[rod('A2',4,32,10000),rod('A1',4,20,10000)];d=detail();before=copy.deepcopy((rods,d))
    r1=run(rods,d=d);r4=run(rods,d=d,area=6*MM_IN**2)
    assert r4['pullout']['checks'][0]['resistance']/r1['pullout']['checks'][0]['resistance']==pytest.approx(4)
    assert r4['sideface']['checks'][0]['resistance']/r1['sideface']['checks'][0]['resistance']==pytest.approx(2)
    assert (rods,d)==before and run(list(reversed(rods)),d=d)==r1


def test_irregular_layout_blocks_only_sideface():
    got=run([rod('A1',4,20),rod('A2',8,30),rod('A3',14,32)])
    assert got['pullout']['status']=='calculated' and got['sideface']['status']=='pending'


def test_high_fc_not_silently_capped():
    got=run(fc=10001*MPA_PSI)
    assert got['pullout']['status']=='pending'
    assert any('10000psi' in s for s in got['pullout']['reasons'])


def test_overflow_never_passes():
    got=run(area=1e308)
    assert got['pullout']['status']=='invalid' and got['pullout']['checks']==[]


def test_single_non_nearest_face_reorientation_is_labelled():
    got=run([rod('A1',4,3),rod('A2',14,3)])['sideface']
    assert any(c['method']=='ACI 17.6.4.2' for c in got['checks'])
    c=next(c for c in got['checks'] if c['ids']==['A1'])
    assert c['ca1']<=c['ca2'] and c['basis']=='conservative_nearest_face_reorientation'
    assert 'conservadora' in c['label']


def test_actual_available_area_cap_is_distinct_from_qualification_reference():
    area=1.5*MM_IN**2
    got=run(area=area,d=detail(qualified_bearing_area=area,actual_available_bearing_area=.5*area))
    assert got['pullout']['status']=='pending' and got['sideface']['status']=='pending'
    assert any('geometricamente' in s for s in got['prerequisites']['bearing_area']['reasons'])
    assert run(area=area,d=detail(actual_available_bearing_area=area))['pullout']['status']=='calculated'
    assert run(area=area,d=detail(actual_available_bearing_area=area*(1-1e-12)))['pullout']['status']=='calculated'
    assert run(d=detail(actual_available_bearing_area=True))['pullout']['status']=='invalid'


def test_same_anchor_susceptible_to_opposing_faces_stays_pending_with_diagnostics():
    # One tensile anchor in an8in-wide member, both x faces at4in and hef12in.
    got=run([rod()],bounds=(0,0,8*MM_IN,80*MM_IN))
    assert got['pullout']['status']=='calculated'
    assert got['sideface']['status']=='pending'
    assert got['sideface']['opposing_faces']=={'A1':[('left','right')]}
    assert got['sideface']['checks'] and all(c['diagnostic_only'] for c in got['sideface']['checks'])
    assert got['sideface']['edges']['left']['status']=='pending'
    assert got['sideface']['edges']['right']['status']=='pending'
    assert any('limite de escopo do aplicativo' in s for s in got['sideface']['reasons'])


def test_exact_six_c_after_coordinate_subtraction_cannot_pool_overloaded_anchor():
    # Independent audit counterexample: the stored subtraction is microscopically
    # below6c, although the input geometry is the exact42in=6*7in boundary.
    rods=[dict(id='A1',x=7*MM_IN,y=100*MM_IN,tension=1),
          dict(id='A2',x=7*MM_IN,y=142*MM_IN,tension=500000)]
    got=evaluate_headed(rods,(0,0,1000*MM_IN,1000*MM_IN),20*MM_IN,4000*MPA_PSI,1.5*MM_IN**2,detail())
    s=got['sideface']
    assert s['status']=='calculated' and len(s['checks'])==2
    assert s['edges']['left']['branch']=='independent_single_anchors'
    assert max(c['ratio'] for c in s['checks'])==pytest.approx(500000/270133.2875427343)
    assert max(c['ratio'] for c in s['checks'])>1.85


def test_exact_hef_boundary_with_binary_roundoff_is_not_susceptible():
    got=run([rod(x=3)],hef=7.5)
    assert got['sideface']['status']=='not_applicable'
    above=run([rod(x=3)],hef=7.500001)
    assert above['sideface']['status']=='calculated'
