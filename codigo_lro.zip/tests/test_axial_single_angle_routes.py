"""Focused actual current-route smoke and explicit 1L guide opening; no full UI suite."""
from copy import deepcopy
from pathlib import Path
import pytest
from streamlit.testing.v1 import AppTest
from lro.guided_selection import FAMILIES, route_label
from lro.axial_single_angle import AxialSingleAngle, FAMILY
from lro.axial_double_angle import FAMILY as DOUBLE_FAMILY

APP = Path(__file__).resolve().parents[1] / 'app.py'

@pytest.mark.parametrize('family', FAMILIES, ids=[f.id for f in FAMILIES])
def test_actual_registered_routes_smoke(family):
    at = AppTest.from_file(str(APP), default_timeout=120)
    at.session_state['connection_family'] = family.route_select_value
    at.run()
    assert not at.exception
    selector = at.sidebar.selectbox[0]
    assert selector.key == 'connection_family'
    assert selector.options == [route_label(f.route_select_value) for f in FAMILIES]
    assert selector.value == family.route_select_value
    assert len(selector.options) == 19
    assert not any('Instalação incompleta' in item.value for item in at.error)


def test_actual_guide_single_angle_requires_explicit_open_and_preserves_double_angle():
    at = AppTest.from_file(str(APP), default_timeout=120)
    at.session_state['connection_family'] = DOUBLE_FAMILY
    at.run()
    assert not at.exception
    old = deepcopy(at.session_state['_axial_double_angle_project'])
    old_result = deepcopy(at.session_state['_axial_double_angle_result'])
    at.selectbox(key='nav_guide_interface').set_value('axial_single_angle_plate').run()
    at.selectbox(key='nav_guide_model').set_value('axial_tension').run()
    assert at.session_state['connection_family'] == DOUBLE_FAMILY
    at.selectbox(key='nav_guide_candidate').set_value('axial_single_angle_bolted').run()
    assert at.session_state['connection_family'] == DOUBLE_FAMILY
    assert at.session_state['_axial_double_angle_project'] == old
    assert at.session_state['_axial_double_angle_result'] == old_result
    at.button(key='nav_guide_open').click().run()
    assert not at.exception
    assert at.session_state['connection_family'] == FAMILY
    new = AxialSingleAngle.from_dict(at.session_state['_axial_single_angle_project'])
    assert new.N == 100000 and new.Ag == 929
    assert at.session_state['_axial_double_angle_project'] == old
    at.sidebar.selectbox[0].set_value(DOUBLE_FAMILY).run()
    assert not at.exception
    assert at.session_state['_axial_double_angle_project'] == old
    assert at.session_state['_axial_double_angle_result'] == old_result
