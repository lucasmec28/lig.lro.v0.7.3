"""Bounded audit regressions; no new mechanical scope or randomized campaign."""
from copy import deepcopy
from dataclasses import replace
from io import BytesIO
import json
import math
import xml.etree.ElementTree as ET
import zipfile

import pytest
from lro.w_splice import evaluate, input_digest, presets
from lro.w_splice_drawing import drawing_svg
from lro.w_splice_report import create_report

BASE=next(iter(presets().values()))


def word_text(c,supplied):
    blob=create_report(c,supplied)
    with zipfile.ZipFile(BytesIO(blob)) as archive:
        root=ET.fromstring(archive.read('word/document.xml'))
        return '\n'.join(root.itertext()),archive.read('docProps/core.xml').decode()


@pytest.mark.parametrize('N,expected',[(10000.,'ENGINEERING_MODEL_PENDING'),(500000.,'ENGINEERING_MODEL_PENDING'),(2250000.,'VERIFIED_SUBCHECK_FAIL')])
def test_missing_Nc_keeps_known_actual_and_floor_without_invented_target(N,expected):
    c=replace(BASE,N=N,minimum_action_policy='slenderness')
    r=evaluate(c);reference=evaluate(replace(c,minimum_action_policy='engineer_waived',notes='Finite test decision'))
    assert r['status']==expected
    assert r['checks']==reference['checks']
    assert r['load_model']['Nd_N']==max(N,45000.)
    assert r['load_model']['member_recommendation_N'] is None
    assert r['load_model']['recommendation_missing_fields']==['compression_resistance','compression_reference']
    assert not r['summary']['complete_checks'] and not r['summary']['supplementary_complete']
    if N==2250000.:
        row=next(x for x in r['checks'] if x['id']=='member_web_block_U_columns1to3_k2')
        assert row['actual_utilization']==pytest.approx(1.01736219855935,abs=1e-14)
        assert row['design_capacity_N']==pytest.approx(491040.)
        assert r['summary']['actual_failed_check_ids']==[row['id']]


def test_unrecorded_waiver_retains_checks_without_claiming_supplementary_completion():
    r=evaluate(replace(BASE,minimum_action_policy='engineer_waived',notes=''))
    assert r['checks'] and r['status']=='ENGINEERING_MODEL_PENDING'
    assert not r['summary']['supplementary_complete']
    assert r['load_model']['recommendation_missing_fields']==['notes']


def test_finite_failure_and_independent_pending_premises_coexist():
    r=evaluate(replace(BASE,N=2250000.,minimum_action_policy='slenderness',tool_radius=61.,integrity_included=False))
    assert r['status']=='VERIFIED_SUBCHECK_FAIL'
    assert {'engineering_pending','access_pending'} <= {x['severity'] for x in r['issues']}
    assert not r['summary']['complete_checks']
    assert r['summary']['actual_strength_status']=='FAIL'


def test_numerical_inability_distinct_from_malformed_input_and_finite_overload():
    r=evaluate(replace(BASE,profile=replace(BASE.profile,area=1e308)))
    assert r['status']=='NUMERICAL_FAILURE'
    assert r['issues'][0]['severity']=='numerical_failure'
    assert not r['checks'] and not r['capacity_calculation_permitted']
    json.dumps(r,allow_nan=False)
    assert evaluate(replace(BASE,N=float('nan')))['status']=='INVALID_INPUT'
    assert evaluate(replace(BASE,N=3000000.))['status']=='VERIFIED_SUBCHECK_FAIL'


@pytest.mark.parametrize('changes',[{}, {'N':2250000.}, {'flange_rows':2,'N':45000.,'minimum_action_policy':'engineer_waived','notes':'RT fixture'}, {'flange_member_end':48.1,'flange_cover_end':39.2,'web_member_end':47.3,'web_cover_end':39.4}])
def test_envelopes_preserve_every_primitive_and_whole_governing_row(changes):
    r=evaluate(replace(BASE,**changes));byid={x['id']:x for x in r['checks']}
    assert len(r['check_groups'])==18
    identifiers=[id for g in r['check_groups'] for id in g['primitive_ids']]
    assert len(identifiers)==len(set(identifiers))==len(byid)
    assert set(identifiers)==set(byid)
    for g in r['check_groups']:
        rows=[byid[id] for id in g['primitive_ids']]
        governing=g['governing']
        assert governing==byid[governing['id']]
        assert governing['utilization']==max(x['utilization'] for x in rows)
        assert g['serial_sides_do_not_add']
        assert g['physical_component_ids']==list(dict.fromkeys(x['component'] for x in rows))
        assert all(x['actual_utilization']<=x['utilization'] for x in rows)
    assert min(g['governing']['equivalent_total_N_capacity_N'] for g in r['check_groups'])==pytest.approx(r['summary']['equivalent_total_N_capacity_N'])
    assert len(r['physical_covers'])==8
    assert r['bolts']['total_bolts']==8*(changes.get('flange_rows',4))+12


@pytest.mark.parametrize('forgery',['stale','empty_checks','all_fail','digest_only'])
def test_direct_artifacts_recompute_current_snapshot_despite_forgery(forgery):
    c=replace(BASE,N=3000000.,project='Current audited load')
    supplied=evaluate(BASE)
    if forgery=='empty_checks':supplied['checks']=[]
    if forgery=='all_fail':
        for row in supplied['checks']:row['status']='FAIL'
    if forgery=='digest_only':supplied={'status':'COMPLETE_CHECKS_PASS_WITHIN_SCOPE','input_digest':input_digest(c)}
    before=deepcopy(supplied)
    text,metadata=word_text(c,supplied);svg=drawing_svg(c,supplied)
    assert 'VERIFIED_SUBCHECK_FAIL' in text and 'VERIFIED_SUBCHECK_FAIL' in svg
    assert 'REGISTRO DIAGNÓSTICO NÃO APROVADO' in text
    assert 'COMPLETE_CHECKS_PASS_' not in text and 'COMPLETE_CHECKS_PASS_' not in svg
    assert input_digest(c) in text and input_digest(c) in metadata and input_digest(c) in svg
    assert c.project in text and c.project in svg
    assert supplied==before


def test_report_retains_known_failure_and_pending_and_all_primitive_ids():
    c=replace(BASE,N=2250000.,minimum_action_policy='slenderness')
    r=evaluate(c);text,_=word_text(c,{'status':'COMPLETE_CHECKS_PASS_WITHIN_SCOPE'})
    assert 'VERIFIED_SUBCHECK_FAIL' in text and 'Envelope suplementar incompleto' in text
    assert '1,017362' in text
    assert all(row['id'] in text for row in r['checks'])
    assert '18 envelopes' in text and '193 linhas primitivas' in text
    assert 'compression_resistance' in text and 'compression_reference' in text


def test_numerical_diagnostic_word_is_available_and_unapproved():
    c=replace(BASE,profile=replace(BASE.profile,area=1e308))
    text,_=word_text(c,evaluate(BASE))
    assert 'NUMERICAL_FAILURE' in text and 'REGISTRO DIAGNÓSTICO NÃO APROVADO' in text
    assert 'Não há verificações resistentes calculadas' in text


def test_diagnostic_word_keeps_tiny_signed_actions_visible():
    text,_=word_text(replace(BASE,M=-1e-10,V=1e-10,torsion=-1e-10),None)
    assert 'OUTSIDE_BALANCED_M004_SCOPE' in text
    assert '-1,01971621298e-14' in text
    assert '1,01971621298e-11' in text


def test_extreme_finite_diagnostic_numbers_use_legible_scientific_display():
    c=replace(BASE,profile=replace(BASE.profile,area=1e308))
    text,_=word_text(c,None)
    assert 'A=1e+308 mm²' in text
    assert 'NUMERICAL_FAILURE' in text
