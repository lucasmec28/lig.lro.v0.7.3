"""Regressões: detalhamento do enrijecedor não pode aprovar punção nem outras falhas."""
from dataclasses import replace
from io import BytesIO
import json
from pathlib import Path

import pytest
from docx import Document
from matplotlib import pyplot as plt
from matplotlib.patches import Polygon
from streamlit.testing.v1 import AppTest

from lro.models import Connection, OPPOSITE_STIFFENER_ASSUMPTION
from lro.engine import evaluate
from lro.examples import presets
from lro.detailing import stiffener_outline, polygon_area
from lro.drawing import connection_figure
from lro.report import create_report

ROOT=Path(__file__).resolve().parents[1]
PROJECT=ROOT/'examples'/'Projeto_usuario_W150_W250.json'

def user_case():return Connection.from_dict(json.loads(PROJECT.read_text()))

@pytest.mark.parametrize('shape',['rectangular','between_flanges'])
@pytest.mark.parametrize('case',['user','pure_v','pure_n'])
def test_opposite_stiffener_preserves_all_numerical_checks(shape,case):
    c=user_case() if case=='user' else next(iter(presets().values()))
    if case=='pure_v':c=replace(c,N=0)
    if case=='pure_n':c=replace(c,V=0,plate_top=(c.beam.d-c.hp)/2,support_edge_distance=1000)
    c=replace(c,plate_shape=shape,root_width=45)
    base=evaluate(c)
    stiff=replace(c,opposite_stiffener=True,stiffener_width=45,stiffener_clip=15)
    r=evaluate(stiff)
    assert r.checks and r.checks==base.checks and r.actual==base.actual
    assert r.minimum_factor==base.minimum_factor
    assert any(i.text==OPPOSITE_STIFFENER_ASSUMPTION for i in r.issues)
    assert not any(x.id.startswith(('full_','opposite_')) for x in r.checks)
    assert stiff.to_dict()['fixed_assumptions']['opposite_stiffener']=='detailing_only_no_strength_credit'
    assert Connection.from_dict(stiff.to_dict())==stiff
    if case=='user':
        punch=next(x for x in r.checks if x.id=='support_punch')
        assert not punch.passed and punch.ratio==pytest.approx(1.23168103448)
        assert r.status=='NÃO ATENDE'

@pytest.mark.parametrize('shape',['rectangular','between_flanges'])
def test_opposite_stiffener_outline_in_both_views_and_word(shape):
    c=replace(user_case(),plate_shape=shape,root_width=45,opposite_stiffener=True,
              stiffener_width=45,stiffener_clip=15,corner_clip=22)
    pts=stiffener_outline(c)
    assert min(y for x,y in pts)==c.support.tf
    assert max(y for x,y in pts)==c.support.d-c.support.tf
    assert max(x for x,y in pts)==-c.support.tw
    assert min(x for x,y in pts)==-c.support.tw-c.stiffener_width
    assert polygon_area(pts)==pytest.approx(c.root_height*c.stiffener_width-c.stiffener_clip**2)
    fig=connection_figure(c)
    # O polígono deve existir também sem complemento na face da single plate.
    assert any(isinstance(p,Polygon) and list(map(tuple,p.get_xy()[:-1]))==pts for p in fig.axes[0].patches)
    assert any('Enrijecedor oposto' in t.get_text() for t in fig.axes[1].texts)
    plt.close(fig)
    doc=Document(BytesIO(create_report(c,evaluate(c))))
    paragraphs='\n'.join(p.text for p in doc.paragraphs)
    cells='\n'.join(cell.text for table in doc.tables for row in table.rows for cell in row.cells)
    assert paragraphs.index(OPPOSITE_STIFFENER_ASSUMPTION)>paragraphs.index('Premissas adotadas')
    assert 'Enrijecedor oposto' in cells and 'Soldas do enrijecedor' in cells
    assert 'cₑ = 15,00' in cells and 'NÃO ATENDE' in paragraphs

def test_legacy_stiffener_clip_migration():
    data=replace(user_case(),opposite_stiffener=True,corner_clip=12).to_dict()
    data['schema_version']=4;data['app_version']='0.7.1'
    data['connection'].pop('stiffener_clip')
    imported=Connection.from_dict(data)
    assert imported.stiffener_clip==12
    assert imported.V==user_case().V and imported.N==user_case().N
    assert evaluate(imported).checks

@pytest.mark.parametrize('tp',[7.9375,9.525])
@pytest.mark.parametrize('factor,passes',[(.99,True),(1.,True),(1.01,False)])
def test_sci_rigorous_punching_boundary_independent_of_plate_thickness(tp,factor,passes):
    # SCI P358 p.128: cancelando tp, Vcrit = ts fu hp²/(6 e γa2).
    # Caso calculado à mão: 5,8 * 450 * 120²/(6 * 90 * 1,35).
    c=replace(user_case(),N=0,V=51555.55555555556*factor,tp=tp)
    ck=next(x for x in evaluate(c).checks if x.id=='support_punch')
    assert ck.ratio==pytest.approx(factor)
    assert ck.passed is passes
    opposite=next(x for x in evaluate(replace(c,opposite_stiffener=True)).checks if x.id=='support_punch')
    assert ck==opposite

@pytest.mark.parametrize('changes',[
    {'stiffener_width':0}, {'stiffener_t':-1}, {'stiffener_clip':-1},
    {'stiffener_clip':1000}, {'stiffener_clip':float('nan')}, {'stiffener_weld':0},
    {'stiffener_steel':'ASTM A992'}, {'stiffener_steel':'USI-CIVIL 350','stiffener_t':5},
])
def test_invalid_stiffener_data_cannot_be_silently_accepted(changes):
    c=replace(user_case(),opposite_stiffener=True,**changes)
    assert not evaluate(c).checks

def test_stiffener_contacts_are_nonblocking():
    c=replace(user_case(),opposite_stiffener=True,stiffener_width=100,stiffener_clip=0)
    r=evaluate(c)
    assert r.checks==evaluate(user_case()).checks
    assert sum(i.severity=='interference' and 'enrijecedor oposto' in i.text for i in r.issues)==2

def test_import_toggle_retain_export_and_support_switch_in_streamlit():
    c=replace(user_case(),opposite_stiffener=True,stiffener_width=45,stiffener_clip=15,stiffener_t=8.)
    at=AppTest.from_file(str(ROOT/'app.py'),default_timeout=30).run()
    at.get('file_uploader')[0].upload('projeto.json',json.dumps(c.to_dict()).encode(),'application/json').run()
    next(x for x in at.button if x.label=='Abrir arquivo').click().run()
    assert not at.exception and 'import_error' not in at.session_state
    assert at.checkbox(key='opposite_stiffener').value
    assert at.selectbox(key='stiffener_t').value==8.
    at.number_input(key='stiffener_width').set_value(42.).run()
    at.checkbox(key='opposite_stiffener').uncheck().run()
    assert not any(x.key=='stiffener_width' for x in at.number_input)
    at.checkbox(key='opposite_stiffener').check().run()
    assert at.number_input(key='stiffener_width').value==42.
    assert at.number_input(key='stiffener_clip').value==15.
    at.selectbox(key='plate_shape').set_value('between_flanges').run()
    assert at.checkbox(key='opposite_stiffener').value
    next(x for x in at.button if x.label=='Gerar memória Word').click().run()
    assert not at.exception and at.session_state['report'][2][:2]==b'PK'
    at.selectbox(key='kind').set_value('column_flange').run()
    assert not at.exception and at.session_state['opposite_stiffener'] is False
    assert not any(x.key=='opposite_stiffener' for x in at.checkbox)
    at.selectbox(key='kind').set_value('beam_web').run()
    assert not at.checkbox(key='opposite_stiffener').value
    at.checkbox(key='opposite_stiffener').check().run()
    assert at.number_input(key='stiffener_width').value==42.
