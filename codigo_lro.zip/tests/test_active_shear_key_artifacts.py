"""Exact active-strip drawings, separated allocations and editable Word evidence."""
from dataclasses import replace
from io import BytesIO
import json
import zipfile
import xml.etree.ElementTree as ET

import pytest

from lro.models import Profile
from lro.base_plate import BasePlate, evaluate
from lro.active_shear_key import ActiveShearKey
from lro.base_plate_drawing import image_bytes
from lro.base_plate_report import create_report


PROFILE=Profile('I 300 × 150','Soldado',40.,300.,150.,8.,12.,276.,7008.)


def fixture(shape='cross_active_plate', **changes):
    key=ActiveShearKey(continuous=True,concrete_filled=True,t=50.8,
                       product='fabricated' if shape=='cross_active_plate' else 'rolled',
                       radius=10.,geometry_ref='Geometria sintética de aceitação; r=10 mm')
    c=BasePlate(PROFILE,a1=50.,a2=180.,db=19.05,tp=50.8,N=0.,M=-30e6,
                V=180e3 if shape=='cross_active_plate' else 160e3,fck=20.,grout_t=40.,
                shear_path=shape,active_key=key)
    return replace(c,**changes)


def xml(c):
    content=create_report(c,evaluate(c),True)
    with zipfile.ZipFile(BytesIO(content)) as archive:
        return archive.read('word/document.xml').decode()


def capture(monkeypatch,c):
    import lro.active_shear_key_drawing as drawing
    captured=[]
    close=drawing.plt.close
    def remember(fig):
        if hasattr(fig,'axes'):captured.append(fig)
        close(fig)
    monkeypatch.setattr(drawing.plt,'close',remember)
    svg=image_bytes(c,evaluate(c),'svg').decode()
    fig=captured[-1]
    patches={p.get_gid():p for ax in fig.axes for p in ax.patches if p.get_gid()}
    return svg,fig,patches


def test_cross_draws_full_steel_actual_grout_and_exclusions(monkeypatch):
    c=fixture(grout_t=30.)
    k=replace(c.active_key,H=130.,cross_exclusion_positive=30.,cross_exclusion_negative=40.)
    c=replace(c,active_key=k)
    svg,fig,p=capture(monkeypatch,c)
    primary=p['active_plate_plan_P']
    assert (primary.get_x(),primary.get_y(),primary.get_width(),primary.get_height())==(-25.4,-120.,50.8,240.)
    ignored=p['inactive_crossing_plan']
    assert (ignored.get_width(),ignored.get_height())==(200.,10.)
    assert p['contact_P_positive_0'].get_y()==-120.
    assert p['contact_P_positive_0'].get_height()==105.
    assert p['contact_P_negative_0'].get_height()==100.
    assert (p['excluded_P_positive_0'].get_y(),p['excluded_P_positive_0'].get_height())==(-15.,30.)
    assert p['active_plate_section_P'].get_y()==-130.
    assert p['active_plate_section_P'].get_height()==130.
    assert list(p['active_actual_grout'].get_xy()[:,1])==[0.,0.,-30.,-30.,0.]
    assert p['active_pressure_extent_P'].get_y()==-130.
    assert p['active_pressure_extent_P'].get_height()==100.
    assert p['active_applied_shear']._posA_posB[0][1]==c.tp
    assert p['active_total_reaction']._posA_posB[0][1]==-80.
    assert 'g = 30' in svg and 'eV = tp + (H + g)/2 = 130.8' in svg


@pytest.mark.parametrize('V',[160e3,-160e3])
def test_w_envelope_draws_alternative_cases_never_simultaneous_2v(monkeypatch,V):
    c=fixture('w_flange_plates',V=V,M=-20e6)
    svg,fig,p=capture(monkeypatch,c)
    result=evaluate(c).geometry['active_key']
    assert len(result['allocation_cases'])==2
    for i,case in enumerate(result['allocation_cases']):
        assert sum(case)==V
        assert len([gid for gid in p if gid.startswith(f'active_case_{i}_') and gid.endswith('_force')])==1
    assert 'CASO ALTERNATIVO 1' in svg and 'CASO ALTERNATIVO 2' in svg
    assert 'nunca 2V simultâneo' in svg
    assert 'inactive_web_plan' in p and 'inactive_projection_section' in p
    assert len([gid for gid in p if gid.startswith('inactive_root_radius_')])==4
    assert p['active_plate_plan_F+'].get_x()==75.
    assert p['active_plate_plan_F-'].get_x()==-100.
    assert p['active_plate_plan_F+'].get_height()==200.
    assert p['contact_F+_positive_0'].get_height()==200.
    assert p['contact_F+_negative_0'].get_height()==85.
    assert p['contact_F-_positive_0'].get_height()==85.
    assert p['contact_F-_negative_0'].get_height()==200.
    assert result['delta_M']==V*120.8
    reaction=p['active_total_reaction']._posA_posB
    assert (reaction[1][0]-reaction[0][0])*V<0


def test_equal_share_is_one_simultaneous_case_and_two_half_forces(monkeypatch):
    c=fixture('w_flange_plates')
    c=replace(c,active_key=replace(c.active_key,sharing='equal'))
    svg,fig,p=capture(monkeypatch,c)
    assert 'ALOCAÇÃO SIMULTÂNEA' in svg
    assert len([gid for gid in p if gid.startswith('active_case_0_') and gid.endswith('_force')])==2
    assert not any(gid.startswith('active_case_1_') for gid in p)
    assert 'F = +80.000 kN' in svg


def test_exact_contact_and_weld_intervals_survive_reload_and_draw(monkeypatch):
    c=fixture()
    contacts={'P':{'positive':[[-120.,-40.],[40.,120.]],'negative':[[-100.,-20.],[20.,100.]]}}
    welds={'P':{'positive':[[-120.,-40.],[40.,120.]],'negative':[[-100.,-20.],[20.,100.]]}}
    c=replace(c,active_key=replace(c.active_key,contact_intervals=contacts,weld_geometry=welds))
    loaded=BasePlate.from_dict(json.loads(json.dumps(c.to_dict())))
    svg,fig,p=capture(monkeypatch,loaded)
    assert p['active_plate_plan_P'].get_height()==240.
    assert p['contact_P_positive_0'].get_height()==80.
    assert p['excluded_P_positive_0'].get_height()==80.
    assert p['excluded_P_negative_0'].get_height()==20.
    lines={line.get_gid():line for ax in fig.axes for line in ax.lines if line.get_gid()}
    assert list(lines['root_weld_P_positive_0'].get_ydata())==[-120.,-40.]
    assert len(lines)==4
    assert 'resistência não verificada' in svg
    out=xml(loaded)
    assert '-120,000; -40,000' in out
    assert 'Geometria de solda de raiz declarada' in out
    assert evaluate(loaded).geometry['active_key']['attachment']=='pending'


@pytest.mark.parametrize('shape',['cross_active_plate','w_flange_plates'])
def test_zero_shear_keeps_both_faces_without_demand_arrows(monkeypatch,shape):
    c=fixture(shape,V=0.,M=-2e6)
    svg,fig,p=capture(monkeypatch,c)
    assert not any(gid.endswith('_force') for gid in p)
    assert 'active_applied_shear' not in p and 'active_total_reaction' not in p
    assert any('_positive_' in gid for gid in p) and any('_negative_' in gid for gid in p)
    assert 'eV = tp + (H + g)/2 = 120.8' in svg
    assert 'Mef = M + ΔM = -2.000 + (+0.000) = -2.000' in svg


def test_word_contains_all_native_equations_and_separate_statuses():
    c=fixture()
    out=xml(c)
    root=ET.fromstring(out)
    ns={'m':'http://schemas.openxmlformats.org/officeDocument/2006/math'}
    maths=[''.join(node.itertext()) for node in root.findall('.//m:oMath',ns)]
    for row in evaluate(c).checks:
        if row.id.startswith('bp_active_'):
            assert row.equation in maths
    assert any('Rcontato,i' in expr for expr in maths)
    assert any('Vw,i' in expr for expr in maths)
    assert '<m:f>' in out and '<m:rad>' in out
    assert 'Verificação local por chapas ativas' in out
    assert 'ATENDEM AO MODELO' in out and 'PENDENTE' in out
    assert '320,571429' in out and '22,440000' in out
    assert '21,744000' in out and '-8,256000' in out
    assert 'M informado não inclui previamente esta excentricidade' in out
    assert 'cone de tração dos chumbadores' in out
    assert 'não verifica automaticamente a ruptura da chave' in out
    assert 'Dispositivo externo para o cortante total' not in out


def test_word_w_range_reversal_preserves_physical_flange_labels():
    c=fixture('w_flange_plates',V=-160e3,M=-20e6)
    c=replace(c,active_key=replace(c.active_key,sharing='verified_range',alpha_min=.4,alpha_max=.4,share_ref='MC partilha 17',share_signs='both'))
    out=xml(c)
    assert 'F+ / −x' in out and 'F- / −x' in out
    assert '64,0000' in out and '96,0000' in out
    assert '170,00' in out and '200,00' in out
    assert 'MC partilha 17' in out
    assert '247,714286' in out and '291,428571' in out
    assert '17,340000' in out and '20,400000' in out
    assert 'ATENDEM AO MODELO' in out
    assert '-19,328000' in out


def test_word_unknown_share_failed_local_is_not_a_device_verdict():
    out=xml(fixture('w_flange_plates'))
    assert 'NÃO ATENDEM AO MODELO' in out
    assert 'nunca duas forças V simultâneas ou soma 2V' in out
    assert 'Resistência de solda PENDENTE' in out
    assert 'Uma face exterior contínua e uma face interior interrompida' in out
    assert '19,328000' in out
    assert '38,656000' not in out


def test_sourced_exclusion_without_radius_is_not_drawn_as_known_zero(monkeypatch):
    c=fixture('w_flange_plates')
    c=replace(c,active_key=replace(c.active_key,radius=None,geometry_ref='MC exclusão conservadora 30 mm'))
    svg,fig,p=capture(monkeypatch,c)
    assert 'Raio/contorno real da junção não especificado' in svg
    assert 'não um raio zero presumido' in svg
    assert not any(gid.startswith('inactive_root_radius_') for gid in p)
    assert p['excluded_F+_negative_0'].get_height()==30.
