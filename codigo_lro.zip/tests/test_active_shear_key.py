"""Independent accepted numerical fixtures and component-model boundary tests."""
from dataclasses import replace
import json
from pathlib import Path
import pytest
from lro.active_shear_key import ActiveShearKey, active_key_actions, contact_intervals, validate_active_key
from lro.base_plate import BasePlate, evaluate, presets
from lro.models import Profile

P=Profile('I 300x150','Soldado',40.,300.,150.,8.,12.,276.,7008.)
DATA=json.loads((Path(__file__).parents[1]/'docs/active_plate_component_fixtures.json').read_text())


def fixture(shape='cross_active_plate',**kwargs):
    k=ActiveShearKey(continuous=True,concrete_filled=True,t=50.8,radius=10.,geometry_ref='Synthetic independent regression fixture')
    c=BasePlate(P,a1=50.,a2=180.,tp=50.8,N=0.,M=-30e6,V=180000.,fck=20.,grout_t=40.,
                shear_path=shape,active_key=k)
    if shape=='w_flange_plates':c=replace(c,M=-20e6,V=160000.,active_key=replace(k,sharing='equal'))
    return replace(c,**kwargs)


def key_change(c,**kw):return replace(c,active_key=replace(c.active_key,**kw))


MAPPING={'b_contact_mm':'b_contact','b_calc_mm':'b_calc','contact_area_mm2':'contact_area',
         'sigma_Rd_MPa':'sigma_rd','F_N':'force','M_root_Nmm':'M_root',
         't_required_mm':'t_required','bearing_Rd_N':'bearing_rd','bending_Rd_N':'bending_rd',
         'yield_Rd_N':'yield_rd','rupture_Rd_N':'rupture_rd','weld_V_N':'weld_V','weld_M_Nmm':'weld_M'}


def check_numbers(plate,expected):
    for source,target in MAPPING.items():assert plate[target]==pytest.approx(expected[source],rel=1e-10),target


def test_cross_independent_fixture():
    c=fixture();r=evaluate(c);a=r.geometry['active_key'];exp=DATA['cross']['expected']
    check_numbers(a['plates'][0],exp['plate'])
    assert a['plates'][0]['strip_forces']==pytest.approx(exp['strip_forces_N'])
    assert a['plates'][0]['b_steel']==240.
    assert a['eV']==120.8
    assert a['delta_M']==pytest.approx(exp['delta_M_Nmm'])
    assert a['M_effective']==pytest.approx(exp['M_effective_Nmm'])
    assert a['local_pass'] is True and a['attachment']==a['device']=='pending'
    assert 'ESCOPO LOCAL DECLARADO' in r.status
    reverse=evaluate(replace(c,V=-c.V)).geometry
    assert reverse['M_effective']==pytest.approx(exp['M_effective_after_V_reversal_Nmm'])
    assert reverse['active_key']['plates'][0]['M_root']==-12.6e6
    assert abs(reverse['residual_M'])<1e-6


def test_w_equal_independent_fixture_and_weld_faces():
    c=fixture('w_flange_plates');r=evaluate(c);a=r.geometry['active_key'];exp=DATA['w_equal']['expected']
    for p,name in zip(a['plates'],('flange_plus','flange_minus')):check_numbers(p,exp[name])
    assert a['local_pass'] is True
    assert a['allocation_cases']==[[80000.,80000.]]
    assert a['delta_M']==pytest.approx(19.328e6)
    assert a['M_effective']==pytest.approx(-.672e6)
    assert a['plates'][0]['faces']['negative']['b_contact']==170.
    assert a['plates'][1]['faces']['negative']['b_contact']==200.
    assert a['plates'][0]['faces']['negative']['weld_V']==pytest.approx(247714.28571428574)
    assert 'shear_rd' not in r.geometry # no summed concrete/device capacity


def test_envelope_is_alternative_extremes_not_double_global_force():
    c=key_change(fixture('w_flange_plates'),sharing='unknown_envelope')
    a=evaluate(c).geometry['active_key'];e=DATA['w_envelope']['expected']
    assert a['allocation_cases']==e['alternative_cases_forces_N']
    assert all(sum(case)==c.V for case in a['allocation_cases'])
    assert all(p['force']==c.V for p in a['plates'])
    assert all(not p['local_pass'] for p in a['plates'])
    assert a['delta_M']==e['delta_M_Nmm']
    assert len([x for x in evaluate(c).checks if x.id.startswith('bp_active_')])==8


def test_unequal_share_stays_on_physical_flange_with_reversal():
    c=key_change(fixture('w_flange_plates'),sharing='verified_range',alpha_min=.4,alpha_max=.4,share_ref='Fixture, both signs')
    for sign,name in [(1,'positive_V'),(-1,'negative_V')]:
        a=evaluate(replace(c,V=sign*160000.)).geometry['active_key'];e=DATA['w_unequal']['expected'][name]
        assert [p['force'] for p in a['plates']]==e['forces_N']
        assert [p['b_contact'] for p in a['plates']]==e['contact_widths_mm']
        assert [p['local_pass'] for p in a['plates']]==e['bending_pass']
        assert [p['id'] for p in a['plates']]==['F+','F-']
        assert [p['x'] for p in a['plates']]==[87.5,-87.5]


def test_verified_range_and_sign_coverage():
    c=key_change(fixture('w_flange_plates'),sharing='verified_range',alpha_min=.2,alpha_max=.7,
                 share_ref='Physical flange range for positive V',share_signs='positive')
    a=evaluate(c).geometry['active_key']
    assert [p['force'] for p in a['plates']]==[112000.,128000.]
    assert a['allocation_cases'][0]==pytest.approx([112000.,48000.])
    assert a['allocation_cases'][1]==pytest.approx([32000.,128000.])
    assert any('sinal atual' in x.text for x in validate_active_key(replace(c,V=-c.V)))


@pytest.mark.parametrize('shape',['cross_active_plate','w_flange_plates'])
def test_zero_shear_keeps_both_faces_geometry_and_no_division(shape):
    c=fixture(shape,V=0.,M=3e6);a=evaluate(c).geometry['active_key']
    assert a['M_effective']==3e6 and a['delta_M']==0
    assert a['eV']==120.8 and a['local_pass']
    for p in a['plates']:
        assert p['force']==0 and p['t_required']==0
        assert set(p['contact_by_sign'])=={'positive','negative'}
        assert p['faces']['negative']['bearing_rd']>0


def test_cross_secondary_length_no_credit_but_footprint_matters():
    c=fixture();base=active_key_actions(c)['plates'][0]
    longer=active_key_actions(key_change(c,secondary_length=350.))['plates'][0]
    assert longer['bearing_rd']==base['bearing_rd'] and longer['bending_rd']==base['bending_rd']
    smaller=active_key_actions(key_change(c,cross_exclusion_positive=40.))['plates'][0]
    assert smaller['b_steel']==base['b_steel'] and smaller['b_calc']==200.
    assert smaller['bearing_rd']<base['bearing_rd']


@pytest.mark.parametrize('shape',['cross_active_plate','w_flange_plates'])
@pytest.mark.parametrize('changes',[
    {'orientation':'rotated_90'}, {'continuous':False},{'concrete_filled':False},{'contact_full_depth':False},
    {'H':40.},{'H':39.},{'H':float('nan')},{'H':float('inf')}, {'H':True},
])
def test_reject_invalid_model_or_geometry(shape,changes):
    c=key_change(fixture(shape),**changes);r=evaluate(c)
    assert any(i.severity=='error' for i in r.issues)
    assert not r.geometry and not r.checks


@pytest.mark.parametrize('changes',[
    {'t':60.},{'b':999.},{'secondary_length':999.},{'secondary_length':20.},
    {'cross_exclusion_positive':240.},{'cross_exclusion_negative':9.}
])
def test_cross_reject_invalid_geometry(changes):
    assert any(i.severity=='error' for i in evaluate(key_change(fixture(),**changes)).issues)


@pytest.mark.parametrize('changes',[
    {'tf':60.},{'d':999.},{'bf':999.},{'d':40.},{'junction_exclusion':200.},
    {'junction_exclusion':29.},{'geometry_ref':''},{'alpha_min':-.1},{'alpha_max':1.1},
    {'alpha_min':.9,'alpha_max':.8},{'sharing':'unrecognized'},
    {'sharing':'verified_range','share_ref':''}
])
def test_w_reject_invalid_geometry_or_share(changes):
    assert any(i.severity=='error' for i in evaluate(key_change(fixture('w_flange_plates'),**changes)).issues)


@pytest.mark.parametrize('intervals',[
    [[-130,-10],[10,130]], [[-120,20],[10,120]], [[-120,-10],[10,115]],
    [[-120,-10],[10,10]], [[-120,-10],[float('nan'),120]], [[-120,120]],
    [[10,120],[-120,-10]], []
])
def test_contact_interval_validation(intervals):
    k=fixture().active_key
    contacts=contact_intervals(k,'cross_active_plate');contacts['P']['positive']=intervals
    assert any(i.severity=='error' for i in evaluate(key_change(fixture(),contact_intervals=contacts)).issues)


def test_actual_narrower_contact_patches_and_known_weld_segments_roundtrip():
    c=fixture();contacts=contact_intervals(c.active_key,c.shear_path)
    contacts['P']['positive']=[[-110.,-20.],[20.,110.]]
    c=key_change(c,contact_intervals=contacts,weld_geometry={'P':{'positive':[[-120.,120.]],'negative':[[-120.,-10.],[10.,120.]]}})
    data=c.to_dict();c2=BasePlate.from_dict(json.loads(json.dumps(data)))
    assert c2.to_dict()==data
    a=evaluate(c2).geometry['active_key'];assert a['plates'][0]['b_contact']==180.
    assert a['attachment']=='pending'
    assert c2.active_key.weld_geometry['P']['negative']==[[-120.,-10.],[10.,120.]]
    inactive=replace(c2,shear_path='friction')
    assert BasePlate.from_dict(inactive.to_dict()).active_key.contact_intervals==contacts


def test_rolled_material_accepted_without_plate_product_restriction():
    c=key_change(fixture('w_flange_plates'),steel='ASTM A992')
    assert not [i for i in evaluate(c).issues if i.severity=='error']
    bad=key_change(c,product='fabricated')
    assert any('produto' in i.text and i.severity=='error' for i in evaluate(bad).issues)


def test_no_radius_invented_and_explicit_exclusion_reference_is_sufficient():
    c=key_change(fixture('w_flange_plates'),radius=None,junction_exclusion=40.,geometry_ref='Conservative measured full junction footprint 40 mm')
    r=evaluate(c);assert not [i for i in r.issues if i.severity=='error']
    assert r.geometry['active_key']['plates'][1]['b_contact']==160.
    assert c.active_key.radius is None


def test_grout_is_actual_not_detail_table_and_global_equilibrium_once():
    c=key_change(fixture('w_flange_plates',grout_t=32.),sharing='unknown_envelope')
    r=evaluate(c);a=r.geometry['active_key']
    assert a['z_R']==66. and a['eV']==116.8
    assert a['plates'][0]['contact_area']==200.*68.
    assert abs(r.geometry['residual_M'])<1e-6
    assert a['delta_M']==160000.*116.8


def test_old_json_without_active_key_loads_identically_on_legacy_paths():
    for shape in ('friction','external','plate','anchors'):
        c=fixture(shear_path=shape)
        data=c.to_dict();data['connection'].pop('active_key')
        loaded=BasePlate.from_dict(data)
        assert loaded.shear_path==shape
        assert evaluate(loaded).geometry.get('M_effective')==evaluate(c).geometry.get('M_effective')
        assert 'active_key' not in evaluate(loaded).geometry


def test_overflow_cannot_produce_favorable_component_result():
    c=key_change(fixture(),H=1e308)
    r=evaluate(c)
    assert any(i.severity=='error' for i in r.issues) and not r.checks


def test_radius_must_fit_between_physical_flanges():
    c=key_change(fixture('w_flange_plates'),d=100.,radius=30.,junction_exclusion=70.)
    assert any('altura livre' in i.text for i in evaluate(c).issues)


def test_both_sign_asymmetric_cross_footprint_recomputes_exposure():
    c=key_change(fixture(),cross_exclusion_negative=40.)
    positive=evaluate(c).geometry['active_key']['plates'][0]
    negative=evaluate(replace(c,V=-c.V)).geometry['active_key']['plates'][0]
    assert positive['b_contact']==220. and negative['b_contact']==200.
    assert positive['b_steel']==negative['b_steel']==240.
    assert negative['M_root']==-positive['M_root']
    assert negative['weld_V']<positive['weld_V']


@pytest.mark.parametrize('geometry',[
    {'unknown':{}},{'P':{'front':[[0.,10.]]}}, {'P':{'positive':[[-130.,0.]]}},
    {'P':{'positive':[[0.,20.],[10.,30.]]}}, {'P':{'negative':[[0.,0.]]}}
])
def test_invalid_weld_segments_do_not_approve(geometry):
    assert any(i.severity=='error' for i in evaluate(key_change(fixture(),weld_geometry=geometry)).issues)


@pytest.mark.parametrize('alpha',[0.,1.])
def test_exact_endpoint_share_has_zero_unloaded_plate_and_one_total_force(alpha):
    c=key_change(fixture('w_flange_plates'),sharing='verified_range',alpha_min=alpha,alpha_max=alpha,share_ref='Endpoint fixture')
    a=evaluate(c).geometry['active_key']
    assert len(a['allocation_cases'])==1 and sum(a['allocation_cases'][0])==c.V
    assert [p['force'] for p in a['plates']]==[alpha*c.V,(1-alpha)*c.V]
    zero=next(p for p in a['plates'] if p['force']==0)
    assert zero['local_pass'] and zero['M_root']==0 and zero['t_required']==0
    assert zero['weld_V']>0 # capacity-based design action remains distinct from applied force


@pytest.mark.parametrize('field',['H','alpha_min','b'])
def test_json_oversized_integer_rejected_before_float_conversion(field):
    c=key_change(fixture(),**{field:10**1000})
    r=evaluate(c)
    assert any(i.severity=='error' and 'finito' in i.text for i in r.issues)
    assert not r.checks and not r.geometry


def test_json_oversized_contact_and_weld_endpoint_rejected():
    c=fixture();huge=10**1000
    contacts=contact_intervals(c.active_key,c.shear_path)
    contacts['P']['positive']=[[-120.,-10.],[10.,huge]]
    for modified in (key_change(c,contact_intervals=contacts),key_change(c,weld_geometry={'P':{'positive':[[0.,huge]]}})):
        r=evaluate(modified)
        assert any(i.severity=='error' and 'finitos' in i.text for i in r.issues)
        assert not r.checks and not r.geometry
    data=c.to_dict();data['connection']['active_key']['H']=huge
    with pytest.raises(ValueError,match='finito'):
        BasePlate.from_dict(json.loads(json.dumps(data)))


def test_json_oversized_width_rejected_during_contact_normalization():
    data=fixture().to_dict();data['connection']['active_key']['b']=10**1000
    with pytest.raises(ValueError):
        BasePlate.from_dict(json.loads(json.dumps(data)))


@pytest.mark.parametrize('field',['V','M','N','grout_t','fck','tp','hef','weld_web_size'])
def test_active_key_integration_rejects_oversized_base_numbers(field):
    c=replace(fixture('w_flange_plates'),**{field:10**1000})
    r=evaluate(c)
    assert any(i.severity=='error' and 'finito' in i.text for i in r.issues)
    assert not r.checks and not r.geometry
    data=fixture('w_flange_plates').to_dict();data['connection'][field]=10**1000
    with pytest.raises(ValueError,match='finito'):
        BasePlate.from_dict(json.loads(json.dumps(data)))


def test_active_key_integration_rejects_oversized_column_dimension():
    c=fixture('w_flange_plates');c=replace(c,column=replace(c.column,d=10**1000))
    r=evaluate(c)
    assert any(i.severity=='error' and 'finito' in i.text for i in r.issues)
    assert not r.checks and not r.geometry
