"""Independent primitives, physical interfaces and explicit R016 safety gates."""
from dataclasses import replace
from copy import deepcopy
import json
import math
import pytest
from lro.double_angle import (DoubleAngle,evaluate,presets,bolt_shear_resistance,
    shear_resistances,block_resistance,bearing_resistance,HOLES)
from lro.models import profiles


def fixture(**changes):
    return replace(next(iter(presets().values())),**changes)


def get(result,key):return next(x for x in result['checks'] if x['id']==key)


def test_independent_825_MPa_primitive_oracle():
    # Values fixed before the module existed: angle_connection_scope/fixture_plan.json.
    rb=bolt_shear_resistance(20.,825.)
    assert rb==pytest.approx(86393.79797371931,rel=1e-12)
    assert 3*2*rb==pytest.approx(518362.78784231585,rel=1e-12)
    assert 6*rb==pytest.approx(518362.78784231585,rel=1e-12)
    gross,net=shear_resistances(2560.,1638.4,250.,400.)
    assert gross==pytest.approx(349090.90909090906,rel=1e-12)
    assert net==pytest.approx(291271.11111111107,rel=1e-12)
    assert block_resistance(2048.,1280.,243.2,250.,400.,1.)==pytest.approx(299614.8148148148,rel=1e-12)
    end=bearing_resistance(20.,29.,6.4,400.)
    interior=bearing_resistance(20.,38.,6.4,400.)
    assert end==pytest.approx(65991.11111111111,rel=1e-12)
    assert interior==pytest.approx(86471.11111111111,rel=1e-12)
    assert 2*(end+2*interior)==pytest.approx(477866.6666666666,rel=1e-12)


def test_real_baseline_R016_table_counts_intervals_not_bolts():
    c=fixture();r=evaluate(c)
    assert r['status']=='COMPLETE_CHECKS_PASS_WITHIN_SCOPE'
    assert r['global_pass']
    assert len(r['physical_angles'])==2
    assert c.beam!=c.support
    assert r['geometry']['industrial_N_intervals']==3
    assert r['geometry']['shared_web_bolt_count']==4
    assert r['geometry']['each_support_leg_bolt_count']==4
    assert r['geometry']['total_bolt_count']==12
    assert r['geometry']['industrial_Z_min_mm']==300
    assert r['geometry']['industrial_Z_max_mm']==360
    assert r['geometry']['industrial_Z_mm']==pytest.approx(331.8)


def test_component_fixture_matches_real_four_leg_checks_without_equivalent_plate():
    r=evaluate(fixture(length=200.,angle_top=77.5,web_rows=3,support_rows=3))
    legs=[x for x in r['components'] if x.startswith('angle_')]
    assert len(legs)==4
    for leg in legs:
        assert r['components'][leg]['Ag_mm2']==1280.
        assert r['components'][leg]['An_mm2']==819.2
        assert get(r,leg+'_shear_net')['design_capacity_N']*2==pytest.approx(291271.11111111107)
        assert get(r,leg+'_Vpos_block_k3')['design_capacity_N']*2==pytest.approx(299614.8148148148)
    assert r['global_pass'] and r['status']=='COMPLETE_CHECKS_PASS_WITH_PRESET_DEVIATION'


def test_shared_web_has_two_planes_and_support_six_or_eight_separate_single_planes():
    c=fixture();r=evaluate(c)
    groups={x['id']:x for x in r['bolts']['groups']}
    assert groups['shared_web']['shear_planes']==2
    assert groups['support_negative']['shear_planes']==groups['support_positive']['shear_planes']==1
    assert groups['shared_web']['each_plane_force_N']==groups['support_negative']['each_plane_force_N']
    assert get(r,'bolt_shared_web')['design_capacity_N']==2*get(r,'bolt_support_negative')['design_capacity_N']
    changed=evaluate(replace(c,web_threads_excluded=True))
    assert get(changed,'bolt_shared_web')['design_capacity_N']/get(r,'bolt_shared_web')['design_capacity_N']==pytest.approx(.56/.45)
    assert get(changed,'bolt_support_negative')['design_capacity_N']==get(r,'bolt_support_negative')['design_capacity_N']


def test_beam_web_thickness_never_doubled():
    c=fixture();r=evaluate(c)
    row=get(r,'beam_web_Vpos_bearing_hole1')
    assert row['thickness_mm']==c.beam.tw
    assert row['design_capacity_N']==pytest.approx(2.4*c.db*c.beam.tw*450/1.35)
    thin=evaluate(replace(c,beam=replace(c.beam,tw=c.beam.tw/2)))
    assert get(thin,'beam_web_shear_net')['design_capacity_N']==pytest.approx(.5*get(r,'beam_web_shear_net')['design_capacity_N'])


def test_bearing_sum_not_n_times_worst_and_uniform_compatibility_is_separate():
    c=fixture(length=200.,angle_top=77.5,web_rows=3,support_rows=3);r=evaluate(c)
    row=get(r,'angle_negative_beam_Vpos_bearing_group')
    vals=row['per_hole_capacities_N']
    assert vals==pytest.approx([86471.11111111111,86471.11111111111,65991.11111111111])
    assert row['design_capacity_N']==pytest.approx(sum(vals))
    assert row['design_capacity_N']>min(vals)*3
    assert get(r,'angle_negative_beam_Vpos_bearing_hole3')['demand_N']==pytest.approx(c.V/6)


def test_opposite_physical_force_directions_at_serial_interfaces():
    r=evaluate(fixture())
    assert get(r,'angle_negative_beam_Vpos_bearing_hole4')['loaded_direction']=='down'
    assert get(r,'angle_negative_support_Vpos_bearing_hole1')['loaded_direction']=='up'
    assert get(r,'beam_web_Vpos_bearing_hole1')['loaded_direction']=='up'
    assert get(r,'column_flange_negative_Vpos_bearing_hole4')['loaded_direction']=='down'
    assert get(r,'beam_web_Vpos_bearing_hole1')['clear_distance_mm'] is None
    assert not any('beam_web' in x['id'] and '_block_' in x['id'] for x in r['checks'])


def test_signed_V_swaps_loaded_angle_end_and_preserves_actual_direction():
    c=fixture(web_end_top=30.);plus=evaluate(c);minus=evaluate(replace(c,V=-c.V))
    assert get(plus,'angle_negative_beam_Vpos_bearing_hole4')['clear_distance_mm']==39.
    assert get(minus,'angle_negative_beam_Vneg_bearing_hole1')['clear_distance_mm']==19.
    assert minus['load_model']['Vsd_N']==minus['load_model']['Vd_N']==-100000.
    assert get(minus,'angle_negative_support_Vneg_bearing_hole4')['loaded_direction']=='down'


def test_zero_V_has_both_static_minimum_directions_and_no_fatigue_claim():
    r=evaluate(fixture(V=0.))
    assert r['load_model']['directions_evaluated']==[1,-1]
    assert r['load_model']['Vsd_N']==0
    assert abs(r['load_model']['Vd_N'])==45000.
    assert all(x['actual_demand_N']==0 for x in r['checks'])
    assert any('_Vneg_' in x['id'] for x in r['checks'])
    assert any('_Vpos_' in x['id'] for x in r['checks'])


@pytest.mark.parametrize('V',[1000.,-1000.,44999.,-44999.,45000.,-45000.,60000.,-60000.])
def test_minimum_applied_once_to_connection_and_actual_retained(V):
    r=evaluate(fixture(V=V));load=r['load_model']
    assert load['Vsd_N']==V
    assert load['Vd_N']==math.copysign(max(abs(V),45000.),V)
    assert load['each_angle_force_N']==max(abs(V),45000.)/2
    assert get(r,'bolt_shared_web')['actual_demand_N']==abs(V)


def test_independent_patterns_deduct_own_holes_only():
    c=fixture(support_rows=3,support_pitch=80.,support_end_top=50.);r=evaluate(c)
    assert r['geometry']['valid']
    beam=get(r,'angle_negative_beam_shear_net');sup=get(r,'angle_negative_support_shear_net')
    assert beam['deducted_holes']==4 and sup['deducted_holes']==3
    assert sup['An_mm2']-beam['An_mm2']==pytest.approx(24*c.t)
    assert r['geometry']['each_support_leg_bolt_count']==3


def test_actual_column_end_not_angle_end_controls_outboard_blocks():
    c=fixture();r=evaluate(c)
    x=get(r,'column_flange_negative_Vpos_block_k1')
    assert x['Agv_mm2']==c.support_edge_bottom*c.support.tf
    assert x['Ant_mm2']==pytest.approx((c.support.bf/2-(c.beam.tw/2+c.support_gauge)-12.)*c.support.tf)
    assert x['Cts']==.5
    assert x['force_fraction_of_component']==1/4
    assert not any(x.get('path_family')=='U' and x['component'].startswith('column') for x in r['checks'])
    changed=evaluate(replace(c,support_edge_bottom=30.))
    assert get(changed,'column_flange_negative_Vpos_block_k1')['design_capacity_N']<x['design_capacity_N']


def test_local_web_shear_buckling_component_is_independent():
    c=fixture();r=evaluate(c)
    row=get(r,'beam_web_shear_buckling')
    assert row['Aw_mm2']==c.beam.d*c.beam.tw
    assert row['lambda_web']==c.beam.clear/c.beam.tw
    assert row['Cv']==1.
    slim=replace(c.beam,tw=1.5)
    rr=evaluate(replace(c,beam=slim))
    assert get(rr,'beam_web_shear_buckling')['Cv']<1
    assert not rr['global_pass']


@pytest.mark.parametrize('change',[{'angle_count':1},{'symmetric':False},{'N':1.},{'M':1.},{'torsion':1.},
    {'kind':'beam_web'},{'cope':'top'},{'static':False},{'normal_combination':False},{'no_slip_required':True},
    {'hole_type':'slot'},{'web_columns':2},{'support_columns':2},{'web_rows':1},{'support_rows':1},
    {'beam_steel':'Unknown'},{'db':18.},{'bolt':'ASTM A307'}])
def test_unsupported_mechanism_never_passes(change):
    r=evaluate(fixture(**change))
    assert not r['global_pass']
    assert r['status'] in ('OUTSIDE_R016_SCOPE','INVALID_GEOMETRY')
    assert not r['checks']


@pytest.mark.parametrize('change',[{'beam_gauge':46.},{'support_gauge':46.},{'t':7.},{'beam_leg':80.}])
def test_nonstandard_geometry_keeps_explicit_eccentric_flexure_gate(change):
    r=evaluate(fixture(**change))
    assert not r['global_pass']
    assert any(x['severity']=='engineering_pending' and 'flexão' in x['text'] for x in r['issues'])


def test_physically_impossible_geometry_and_industrial_deviation_are_distinct():
    invalid=evaluate(fixture(beam_gauge=100.))
    assert invalid['status']=='INVALID_GEOMETRY'
    assert not invalid['checks']
    deviation=evaluate(fixture(web_pitch=61.,support_pitch=61.,angle_top=46.))
    assert deviation['geometry']['valid']
    assert any(x['severity']=='preset_deviation' for x in deviation['issues'])
    assert deviation['status']=='COMPLETE_CHECKS_PASS_WITH_PRESET_DEVIATION'


def test_detail_failure_keeps_component_results_without_green_pass():
    r=evaluate(fixture(web_pitch=52.,web_end_top=52.))
    assert r['geometry']['valid']
    assert r['status']=='DETAIL_FAIL'
    assert r['checks'] and not r['global_pass']


def test_high_demand_has_resistance_failure_not_scope_suppression():
    r=evaluate(fixture(V=1000000.))
    assert r['status']=='VERIFIED_SUBCHECK_FAIL'
    assert r['summary']['failed_check_ids']
    assert not r['global_pass']


def test_tool_clearance_is_pending_not_impossible_geometry():
    r=evaluate(fixture(tool_radius=40.))
    assert r['geometry']['valid']
    assert r['status']=='ENGINEERING_MODEL_PENDING'
    assert not r['global_pass']
    assert any(x['severity']=='access_pending' for x in r['issues'])


def test_physical_hole_independent_of_net_deduction_and_drilling():
    c=fixture(db=24.,hole_diameter=26.,web_pitch=75.,support_pitch=75.,length=325.,angle_top=15.,web_end_top=50.,support_end_top=50.)
    # This tall angle is a geometry diagnostic; Table14 dmax remains27 despite physical26.
    r=evaluate(c)
    assert r['geometry']['dh']==26.
    assert r['geometry']['dn']==29.
    assert evaluate(replace(c,drilled=True))['geometry']['dn']==27.
    base=fixture(hole_diameter=21.)
    a=evaluate(base);b=evaluate(replace(base,hole_diameter=22.))
    assert a['geometry']['dn']==b['geometry']['dn']==24.
    assert get(a,'angle_negative_beam_shear_net')['design_capacity_N']==get(b,'angle_negative_beam_shear_net')['design_capacity_N']
    assert get(a,'angle_negative_beam_Vpos_bearing_hole4')['design_capacity_N']>get(b,'angle_negative_beam_Vpos_bearing_hole4')['design_capacity_N']


def test_metric_and_imperial_remain_distinct_in_JSON_and_calculation():
    metric=fixture();imperial=replace(metric,db=19.05,hole_diameter=20.6375)
    assert metric.to_dict()!=imperial.to_dict()
    assert DoubleAngle.from_dict(json.loads(json.dumps(imperial.to_dict())))==imperial
    a=evaluate(metric);b=evaluate(imperial)
    assert a['geometry']['dn']==24.
    assert b['geometry']['dn']==22.6375
    assert get(a,'bolt_shared_web')['design_capacity_N']!=get(b,'bolt_shared_web')['design_capacity_N']


def test_strict_roundtrip_preserves_every_field_and_rejects_tampering():
    c=fixture(N=100.,V=-32123.,support_gauge=61.,notes='Fonte específica da peça')
    d=c.to_dict();assert DoubleAngle.from_dict(json.loads(json.dumps(d)))==c
    for key,value in [('units',{'force':'kgf'}),('fixed_assumptions',{}),('connection_type','single_angle')]:
        bad=deepcopy(d);bad[key]=value
        with pytest.raises(ValueError):DoubleAngle.from_dict(bad)
    bad=deepcopy(d);bad['connection']['future_secret']=1
    with pytest.raises(ValueError):DoubleAngle.from_dict(bad)


@pytest.mark.parametrize('change',[{'V':float('nan')},{'t':float('inf')},{'web_rows':True},{'support_rows':2.5},{'symmetric':1},{'beam_leg':-1.},{'db':10**1000}])
def test_invalid_numeric_inputs_cannot_give_favourable_check(change):
    c=fixture(**change);r=evaluate(c)
    assert r['status']=='INVALID_INPUT' and not r['global_pass'] and not r['checks']
    with pytest.raises(ValueError):c.to_dict()


def test_no_addition_of_serial_capacities_and_result_finite():
    r=evaluate(fixture())
    assert r['summary']['equivalent_total_V_capacity_N']==min(x['equivalent_total_V_capacity_N'] for x in r['checks'])
    assert r['summary']['equivalent_total_V_capacity_N']==305280.
    json.dumps(r,allow_nan=False)


def test_restraint_depth_and_group_location_are_mechanical_gates_not_warning_waivers():
    shallow=evaluate(fixture(length=160.,angle_top=97.5,web_rows=2,support_rows=2,web_pitch=80.,support_pitch=80.))
    assert shallow['geometry']['valid'] and not shallow['global_pass']
    assert any(x.get('field')=='conventional_restraint_depth' and x['severity']=='engineering_pending' for x in shallow['issues'])
    lower=evaluate(fixture(angle_top=55.))
    assert lower['geometry']['valid'] and not lower['global_pass']
    assert any(x.get('field')=='conventional_upper_location' and x['severity']=='engineering_pending' for x in lower['issues'])


def test_zero_end_clearance_is_model_pending_direct_and_JSON_without_universal_10mm_minimum():
    c=fixture(gap=0.)
    restored=DoubleAngle.from_dict(json.loads(json.dumps(c.to_dict())))
    assert restored==c
    for case in (c,restored):
        r=evaluate(case)
        assert r['status']=='ENGINEERING_MODEL_PENDING'
        assert r['geometry']['valid'] and r['checks'] and not r['global_pass']
        assert any(x['severity']=='engineering_pending' and 'Folga de ponta igual a zero' in x['text'] for x in r['issues'])
        assert all(x['status']=='PASS' for x in r['checks'])
    for gap in (.1,1.,5.,10.,15.):
        r=evaluate(fixture(gap=gap))
        assert r['geometry']['valid'] and r['global_pass']
        assert not any(x['severity']=='engineering_pending' and 'Folga de ponta' in x['text'] for x in r['issues'])
