"""Fluxos nativos: padrão, dimensões reais, estados ocultos, importação repetida."""
from dataclasses import replace
from pathlib import Path
import json
import pytest
from streamlit.testing.v1 import AppTest
from lro.base_plate import BasePlate,evaluate,presets

APP=Path(__file__).resolve().parents[1]/'app.py'
FAMILY='Placa de base · Tipo 1'
def button(at,label):return next(x for x in at.button if x.label==label)
def open_native():
    at=AppTest.from_file(str(APP),default_timeout=60).run()
    at.selectbox(key='connection_family').set_value(FAMILY).run()
    assert not at.exception
    return at

def current(at):return BasePlate.from_dict(at.session_state['_base_plate_project'])


def test_new_base_native_washers_commercial_thickness_and_generation():
    at=open_native()
    assert at.selectbox(key='bp_shear_mechanism').value=='anchors'
    assert at.selectbox(key='bp_anchor_shear_model').value=='welded_washer'
    assert at.selectbox(key='bp_anchor_washer_t_label').value=='1/4"'
    c=current(at)
    assert c.anchor_washer_t==6.35 and c.anchor_washer_side==50
    assert not any(x.key.startswith('bp_anchor_confirm_') for x in at.checkbox)
    assert any('Soldas/arruelas/fixação local' in x.value for x in at.warning)
    at.selectbox(key='bp_db_label').set_value('1"').run()
    button(at,'Usar arruelas da Tabela 18 e espessura comercial').click().run()
    assert at.selectbox(key='bp_anchor_washer_t_label').value=='3/8"'
    assert current(at).anchor_washer_t==9.525 and current(at).anchor_washer_side==75
    button(at,'Gerar memória da placa de base').click().run()
    assert not at.exception and at.session_state['bp_report'][2][:2]==b'PK'
    at.number_input(key='bp_anchor_washer_side').set_value(78.).run()
    assert 'bp_report' not in at.session_state


def test_actual_washer_dimensions_survive_hidden_mode_and_family():
    at=open_native()
    at.selectbox(key='bp_anchor_washer_t_label').set_value('Personalizada').run()
    at.number_input(key='bp_anchor_washer_t').set_value(8.25).run()
    at.number_input(key='bp_anchor_washer_side').set_value(60.).run()
    original=current(at)
    at.selectbox(key='bp_anchor_shear_model').set_value('external').run()
    at.number_input(key='bp_anchor_shear_kgf').set_value(5000.).run()
    at.text_input(key='bp_anchor_shear_ref').set_value('Memória externa CH02').run()
    next(x for x in at.checkbox if x.key.startswith('bp_anchor_confirm_')).check().run()
    assert current(at).anchor_capacity_confirmed
    at.selectbox(key='bp_shear_mechanism').set_value('friction').run()
    at.selectbox(key='connection_family').set_value('Single plate').run()
    at.selectbox(key='connection_family').set_value(FAMILY).run()
    at.selectbox(key='bp_shear_mechanism').set_value('anchors').run()
    assert at.number_input(key='bp_anchor_shear_kgf').value==5000.
    at.selectbox(key='bp_anchor_shear_model').set_value('welded_washer').run()
    assert not at.exception
    assert at.selectbox(key='bp_anchor_washer_t_label').value=='Personalizada'
    assert current(at).anchor_washer_t==original.anchor_washer_t
    assert current(at).anchor_washer_side==original.anchor_washer_side
    assert evaluate(current(at)).geometry['shear_rd']!=current(at).anchor_shear_rd


def test_repeated_import_keeps_actual_washers_signed_loads_and_native_mode():
    at=open_native()
    c=replace(presets()['Chumbadores · arruelas soldadas'],N=-60000.,M=-2e6,V=-10000.,
              anchor_washer_t=7.25,anchor_washer_side=65.,a1=45.,a2=120.)
    for _ in range(2):
        raw=json.dumps(c.to_dict()).encode()
        at.get('file_uploader')[0].upload('arruelas.json',raw,'application/json').run()
        button(at,'Abrir placa de base JSON').click().run()
        assert not at.exception
        loaded=current(at)
        assert loaded.native_anchor_shear
        assert loaded.anchor_washer_t==7.25 and loaded.anchor_washer_side==65.
        assert loaded.M==pytest.approx(-2e6) and loaded.V==pytest.approx(-10000.)
        a=evaluate(loaded).geometry
        assert a['M_effective']==loaded.M and a['delta_M']==0.
        assert any('índice' in x.value for x in at.warning)
    at.number_input(key='bp_anchor_washer_side').set_value(130.).run()
    assert not at.exception
    assert any('NÃO ATENDE' in x.value for x in at.error)
    assert evaluate(current(at)).geometry['anchor_shear']


def test_import_081_anchors_retains_external_model_and_pending_declaration():
    at=open_native()
    data=presets()['Chumbadores · resistência externa'].to_dict()
    data['app_version']='0.8.1'
    for key in ('anchor_shear_model','anchor_washer_t','anchor_washer_side'):
        data['connection'].pop(key)
    raw=json.dumps(data).encode()
    at.get('file_uploader')[0].upload('base081.json',raw,'application/json').run()
    button(at,'Abrir placa de base JSON').click().run()
    assert not at.exception
    assert at.selectbox(key='bp_anchor_shear_model').value=='external'
    assert any('DADOS PENDENTES' in x.value for x in at.warning)
    assert not any('anchor_shear'==k for k in evaluate(current(at)).geometry)
