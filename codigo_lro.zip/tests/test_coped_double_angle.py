"""R017 mechanics, topology and adversarial scope tests; frozen oracle separate."""
import json
import math
from dataclasses import replace, asdict
import pytest
from lro.coped_double_angle import (CopedDoubleAngle,presets,evaluate,cope_model,cope_boundary,
    cope_edge_distance,support_boundary_actions,CONNECTION_TYPE,COMPONENT_VERSION)

BASE=next(iter(presets().values()))

def qualified(c=BASE,both=False):
    c=replace(c,restraint_top_system='FIXTURE ONLY: independent lateral support',
        restraint_top_ref='FIXTURE ONLY: external strength/stiffness record TOP',restraint_top_x=c.gap+c.c_top)
    if both or c.V<=0:c=replace(c,restraint_bottom_system='FIXTURE ONLY: independent lateral support',
        restraint_bottom_ref='FIXTURE ONLY: external strength/stiffness record BOTTOM',restraint_bottom_x=c.gap+c.c_bottom)
    return c

def row(r,key):return next(x for x in r['checks'] if x['id']==key)


def test_default_is_useful_but_external_cope_restraint_not_invented():
    r=evaluate(BASE)
    assert r['status']=='ENGINEERING_MODEL_PENDING' and r['checks'] and not r['local_pass']
    assert not r['global_pass'] and not r['summary']['complete_checks']
    assert r['summary']['capacity_is_conditional']
    assert r['summary']['governing_check_id']=='cope_first_yield'
    assert r['summary']['equivalent_total_V_capacity_N']==pytest.approx(233950.32467532466)
    assert r['cope']['stability_N']==pytest.approx(1013245.8729732239)
    assert r['restraints']['connection']['strength_stiffness_design_performed'] is False
    assert not r['restraints']['twist_fixity_assumed']


def test_qualified_external_boundary_allows_only_complete_local_status():
    c=qualified();r=evaluate(c)
    assert r['local_pass'] and r['summary']['complete_checks']
    assert r['status']=='COMPLETE_LOCAL_CHECKS_PASS_WITHIN_SCOPE'
    assert r['global_pass'] is False and r['member_global_status']=='EXTERNAL_NOT_EVALUATED'
    assert not r['summary']['member_global_checks_complete']
    assert r['inputs']==asdict(c)


@pytest.mark.parametrize('change',[{'restraint_top_system':''},{'restraint_top_ref':''},{'restraint_top_x':130.},
    {'restraint_top_x':140.1}])
def test_external_record_requires_system_design_reference_exact_location(change):
    r=evaluate(replace(qualified(),**change))
    assert not r['local_pass'] and r['status']=='ENGINEERING_MODEL_PENDING'


def test_reversal_changes_actual_cope_blocks_and_compression_restraint():
    c=qualified(replace(BASE,angle_top=40.))
    a=evaluate(c);b=evaluate(replace(c,V=-c.V))
    assert a['restraints']['required_compression_faces']==['top']
    assert b['restraints']['required_compression_faces']==['bottom'] and not b['local_pass']
    b=evaluate(qualified(replace(c,V=-c.V)))
    assert b['local_pass']
    pa=row(a,'beam_web_Vpos_block_k1');pb=row(b,'beam_web_Vneg_block_k1')
    assert pa['gross_shear_length_mm']==50.
    assert pb['gross_shear_length_mm']==65.
    assert pa['design_capacity_N']!=pb['design_capacity_N']
    assert pa['free_boundary']=='actual_cope_top_and_beam_end'
    assert pb['free_boundary']=='actual_cope_bottom_and_beam_end'
    assert a['cope']['stability_N']==b['cope']['stability_N']
    assert a['cope']['actual_cope_moment_Nmm']==-b['cope']['actual_cope_moment_Nmm']


def test_zero_checks_both_signs_and_exports_actual_zero_not_floor():
    r=evaluate(qualified(replace(BASE,V=0.),both=True))
    assert r['local_pass'] and r['load_model']['Vd_N']==45000.
    assert r['load_model']['directions_evaluated']==[1,-1]
    assert r['restraints']['required_compression_faces']==['top','bottom']
    assert r['load_model']['girder_delivered_vertical_force_N']==0.
    assert all(x['force_actual_N']==0 for x in r['load_model']['girder_force_columns'])
    assert r['summary']['actual_governing_utilization']==0.
    assert any(x['id']=='beam_web_Vneg_block_k4' for x in r['checks'])


def test_one_actual_support_web_and_three_real_bolt_groups():
    r=evaluate(qualified())
    assert r['support_web']['physical_web_count']==1
    assert r['support_web']['hole_count']==8
    assert len(r['support_web']['hole_coordinates_mm'])==8
    assert {x['x'] for x in r['support_web']['hole_coordinates_mm']}=={-48.6,48.6}
    assert [b['shear_planes'] for b in r['bolts']['groups']]==[2,1,1]
    assert r['geometry']['support_grip_mm']==pytest.approx(13.6)
    assert r['geometry']['total_bolt_count']==12
    assert not r['support_web']['continuous_flange_junction_is_free_edge']
    assert not r['support_web']['free_edge_blocks_applicable']
    assert not any('column_flange' in x['id'] or ('support_web' in x['id'] and 'block' in x['id']) for x in r['checks'])


def test_support_bearing_uses_tw_not_tf_or_two_times_tw():
    a=evaluate(BASE);b=evaluate(replace(BASE,support=replace(BASE.support,tw=1.5),V=200000.))
    key='support_web_total_Vpos_bearing_group'
    assert row(b,key)['design_capacity_N']/row(a,key)['design_capacity_N']==pytest.approx(1.5/7.2)
    assert b['summary']['equivalent_total_V_capacity_N']==pytest.approx(182400.)
    assert any(x['status']=='FAIL' and 'support_web' in x['id'] for x in b['checks'])
    assert row(b,'bolt_support_negative')['design_capacity_N']==row(a,'bolt_support_negative')['design_capacity_N']
    assert row(b,key)['physical_web_count']==1


def test_support_terminal_bearing_cap_not_fictitious_root_edge():
    a=evaluate(BASE);b=evaluate(replace(BASE,V=-BASE.V))
    assert row(a,'support_web_negative_Vpos_bearing_hole4')['clear_distance_mm'] is None
    assert row(a,'support_web_negative_Vpos_bearing_hole1')['clear_distance_mm']==38.
    assert row(b,'support_web_negative_Vneg_bearing_hole1')['clear_distance_mm'] is None
    assert row(b,'support_web_negative_Vneg_bearing_hole4')['clear_distance_mm']==38.


def test_girder_equilibrium_and_torque_are_physical_not_equal_global_spans():
    e=support_boundary_actions(200000.,300000.,100000.,-100.,2000000.,[-50.,50.])
    assert e['equilibrium_closes'] and e['V_between_columns_N']==200000.
    assert [x['introduced_force_N'] for x in e['columns']]==[100000.,100000.]
    assert [x['M_Nmm'] for x in e['columns']]==[17000000.,37000000.]
    assert e['capacity_checks_performed'] is False
    assert not support_boundary_actions(200000.,100000.,100000.,-100.,0.,[-50.,50.])['equilibrium_closes']
    a=evaluate(BASE);b=evaluate(replace(BASE,support_eccentricity=25.))
    assert a['load_model']['girder_delivered_torsion_Nmm']==0.
    assert b['load_model']['girder_delivered_torsion_Nmm']==2500000.
    assert not b['local_pass'] and b['load_model']['global_span_reactions'] is None
    assert all('column_delivered' not in k for k in b['load_model'])


def test_source_domain_is_continuous_not_arbitrary_170_limit():
    a=cope_model(400.,8.,80.,800.,10.,345.)
    assert a['geometry_within_domain'] and a['stability_N'] is not None
    assert not cope_model(400.,8.,80.00001,800.,10.,345.)['geometry_within_domain']
    assert not cope_model(400.,8.,80.,800.00001,10.,345.)['geometry_within_domain']
    c=qualified(replace(BASE,c_top=200.,c_bottom=200.));r=evaluate(c)
    assert r['local_pass'] and r['status']=='COMPLETE_LOCAL_CHECKS_PASS_WITH_PRESET_DEVIATION'
    assert r['cope']['geometry_within_domain'] and r['cope']['e_mm']==210.


def test_instability_governed_probe_and_design_factor():
    a=cope_model(400.,8.,40.,130.,10.,345.)
    b=cope_model(400.,3.,40.,300.,10.,345.)
    assert a['W1_mm3']==pytest.approx(136533.33333333334)
    assert a['first_yield_N']==pytest.approx(305870.12987012987)
    assert a['stability_N']==pytest.approx(1446578.1684981687)
    assert b['stability_N']==pytest.approx(14928.774193548386)
    assert b['stability_N']<45000.<b['first_yield_N']
    assert b['coefficient_MPa']==350600.
    assert a['stability_N']==pytest.approx(a['Fbc_design_MPa']*a['W1_mm3']/140.)


def test_setback_in_moment_arm_not_stress_coefficient():
    a=evaluate(BASE);b=evaluate(replace(BASE,gap=20.))
    assert b['cope']['e_mm']==150.
    assert b['cope']['Fbc_design_MPa']==a['cope']['Fbc_design_MPa']
    assert b['cope']['first_yield_N']==pytest.approx(218353.63636363635)
    assert b['cope']['actual_cope_moment_Nmm']==15000000.


def test_unequal_or_out_of_model_does_not_fabricate_instability_capacity():
    for c in [replace(BASE,c_bottom=140.),replace(BASE,dc_bottom=31.),replace(BASE,c_top=800.,c_bottom=800.)]:
        r=evaluate(qualified(c,both=True))
        assert r['geometry']['valid'] and r['checks'] and not r['local_pass']
        assert r['status'] in ('ENGINEERING_MODEL_PENDING','VERIFIED_SUBCHECK_FAIL')
        assert any(i['severity']=='engineering_pending' for i in r['issues'])
        assert r['cope']['stability_N'] is None
        assert not any(x['id']=='cope_complementary_stability' for x in r['checks'])


def test_rounded_corner_is_actual_boundary_not_linear_or_angle_edge():
    assert cope_boundary(BASE,100.)==30.
    assert cope_boundary(BASE,125.)==30.
    assert cope_boundary(BASE,132.5)==pytest.approx(15.+math.sqrt(225.-7.5**2))
    assert cope_boundary(BASE,140.)==15.
    assert cope_boundary(BASE,140.001) is None
    assert cope_boundary(BASE,132.5,'bottom')==pytest.approx(BASE.beam.d-cope_boundary(BASE,132.5))
    assert cope_edge_distance(BASE,45.,87.5)==57.5
    assert BASE.r_top==BASE.r_bottom==15.


@pytest.mark.parametrize('change',[dict(N=1.),dict(M=1.),dict(torsion=1.),dict(kind='column_flange'),dict(cope='single_top'),
    dict(support_intact=False),dict(angle_count=1),dict(symmetric=False),dict(web_columns=2),dict(support_columns=2),
    dict(static=False),dict(normal_combination=False),dict(no_slip_required=True),dict(db=18.),dict(hole_type='slot'),dict(web_rows=1)])
def test_unsupported_load_topology_and_conditions_never_approve(change):
    r=evaluate(replace(BASE,**change))
    assert not r['local_pass'] and not r['global_pass']
    assert r['status']=='OUTSIDE_R017_SCOPE' and not r['checks']


@pytest.mark.parametrize('change',[dict(c_top=20.,c_bottom=20.),dict(dc_top=200.,dc_bottom=200.),dict(r_top=40.),
    dict(angle_top=0.),dict(length=1000.),dict(beam_gauge=20.),dict(support_gauge=75.)])
def test_physical_collisions_do_not_return_capacities(change):
    r=evaluate(replace(BASE,**change))
    assert r['status']=='INVALID_GEOMETRY' and not r['checks'] and not r['local_pass']


@pytest.mark.parametrize('change',[dict(beam_leg=90.),dict(support_gauge=50.),dict(gap=0.),dict(support_back_access=False),dict(angle_top=50.)])
def test_documentary_and_access_gaps_are_not_physical_impossibility(change):
    r=evaluate(replace(qualified(),**change))
    assert r['geometry']['valid'] and r['checks'] and not r['local_pass']
    assert r['status']=='ENGINEERING_MODEL_PENDING'


def test_resistance_and_detail_fail_remain_distinct_from_model_pending():
    a=evaluate(replace(BASE,V=500000.));b=evaluate(replace(qualified(),web_end_top=25.))
    assert a['status']=='VERIFIED_SUBCHECK_FAIL' and a['summary']['failed_check_ids']
    assert b['status']=='DETAIL_FAIL' and not b['local_pass'] and b['checks']


@pytest.mark.parametrize('field,value',[('V',float('nan')),('r_top',float('inf')),('length',0.),('support_intact',1),('web_rows',True),
    ('restraint_top_x',float('inf')),('beam_level',False),('restraint_top_ref',True)])
def test_invalid_inputs_never_approve_or_emit_nonfinite_json(field,value):
    c=replace(BASE,**{field:value});r=evaluate(c)
    assert r['status']=='INVALID_INPUT' and not r['checks']
    json.dumps(r,allow_nan=False)
    with pytest.raises(ValueError):c.to_dict()


def test_native_json_strict_roundtrip_preserves_true_topology():
    c=qualified(replace(BASE,V=-12345.678901,notes='R17 real.',beam_level=1.234),both=True)
    raw=c.to_dict();assert raw['connection_type']==CONNECTION_TYPE and raw['component_version']==COMPONENT_VERSION
    assert CopedDoubleAngle.from_dict(json.loads(json.dumps(raw)))==c
    assert not {'support_edge_top','support_edge_bottom'} & raw['connection'].keys()
    for key,value in [('connection_type','double_angle_r016_bolted_shear'),('schema_version',True),('units',{}),('fixed_assumptions',{})]:
        bad=dict(raw);bad[key]=value
        with pytest.raises(ValueError):CopedDoubleAngle.from_dict(bad)
    bad=json.loads(json.dumps(raw));bad['connection']['unexpected']=1
    with pytest.raises(ValueError):CopedDoubleAngle.from_dict(bad)


def test_assembly_margin_is_not_reclassified_as_physical_flange_collision():
    c=replace(BASE,c_top=73.,c_bottom=73.);r=evaluate(c)
    assert r['geometry']['valid'] and r['checks']
    assert r['status']=='ENGINEERING_MODEL_PENDING' and not r['local_pass']
    real=next(x for x in r['geometry']['checks'] if x['id']=='cope_top_flange_clearance')
    margin=next(x for x in r['geometry']['checks'] if x['id']=='cope_top_assembly_flange_clearance')
    assert real['passed'] and real['actual']==pytest.approx(9.038262143)
    assert not margin['passed'] and margin['category']=='access'


def test_frozen_independent_source_oracles_are_reproducible_in_package():
    import subprocess, sys
    from pathlib import Path
    path=Path(__file__).parent/'fixtures/compare_r017_implementation.py'
    completed=subprocess.run([sys.executable,str(path)],capture_output=True,text=True,timeout=30)
    assert completed.returncode==0,completed.stdout+completed.stderr
    assert '7645 assertions; 0 failures' in completed.stdout


def test_hole_geometry_and_girder_action_coordinate_frames_are_unambiguous():
    r=evaluate(BASE);g=r['geometry'];lm=r['load_model']
    assert 'support_hole_z_mm' not in g
    assert 'DOWN' in g['support_hole_coordinate_frame']['y']
    assert 'meia altura' in lm['girder_action_origin']
    y_down=sum(g['support_hole_y_mm'])/len(g['support_hole_y_mm'])
    assert lm['girder_application_point_mm'][1]==pytest.approx(BASE.support.d/2-y_down)
    assert all(p['z']==0. for p in g['support_hole_coordinates_mm'])
