"""UI: campos ocultos, sinais, navegação, JSON e invalidação de memória."""
from dataclasses import replace
from pathlib import Path
import json
import pytest
from streamlit.testing.v1 import AppTest
from lro.models import KGF
from lro.base_plate import BasePlate,evaluate,presets

APP=Path(__file__).resolve().parents[1]/'app.py'
FAMILY='Placa de base · Tipo 1'

def button(at,label):return next(x for x in at.button if x.label==label)

def open_lug():
    at=AppTest.from_file(str(APP),default_timeout=60).run()
    at.selectbox(key='connection_family').set_value(FAMILY).run()
    at.selectbox(key='bp_example').set_value('Chave retangular · cortante puro').run()
    button(at,'Usar exemplo de placa de base').click().run()
    assert not at.exception
    return at


def test_lug_default_signed_actions_and_report_export():
    at=open_lug()
    assert at.selectbox(key='bp_lug_t_label').value=='2"'
    assert at.selectbox(key='bp_lug_steel').value=='ASTM A36'
    assert any('dispositivo completo permanece pendente' in x.value for x in at.warning)
    assert any('ATENDE ÀS VERIFICAÇÕES REALIZADAS' in x.value for x in at.success)
    for v in (-100000.,100000.):
        at.number_input(key='bp_V_kgf').set_value(v/KGF).run()
        assert not at.exception
        c=BasePlate.from_dict(at.session_state['_base_plate_project'])
        assert evaluate(c).geometry['delta_M']==v*120.8
    button(at,'Gerar memória da placa de base').click().run()
    assert not at.exception and at.session_state['bp_report'][2][:2]==b'PK'
    at.number_input(key='bp_lug_bv').set_value(120.).run()
    assert 'bp_report' not in at.session_state


def test_lug_hidden_custom_geometry_and_external_descriptor_survive_switches():
    at=open_lug()
    at.selectbox(key='bp_lug_t_label').set_value('Personalizada').run()
    at.number_input(key='bp_lug_t').set_value(42.).run()
    at.number_input(key='bp_lug_bh').set_value(110.).run()
    at.selectbox(key='bp_shear_mechanism').set_value('device').run()
    at.selectbox(key='bp_device_model').set_value('external').run()
    at.selectbox(key='bp_external_shape').set_value('cruciform').run()
    at.text_input(key='bp_external_shear_ref').set_value('MC CR01: geometria e esforços completos').run()
    at.number_input(key='bp_external_shear_kgf').set_value(16000.).run()
    at.selectbox(key='bp_shear_mechanism').set_value('friction').run()
    at.number_input(key='bp_N_kgf').set_value(5000.).run()
    at.selectbox(key='bp_shear_mechanism').set_value('device').run()
    at.selectbox(key='bp_device_model').set_value('plate').run()
    assert not at.exception
    assert at.selectbox(key='bp_lug_t_label').value=='Personalizada'
    assert at.number_input(key='bp_lug_t').value==42.
    assert at.number_input(key='bp_lug_bh').value==110.
    at.selectbox(key='connection_family').set_value('Single plate').run()
    at.selectbox(key='connection_family').set_value(FAMILY).run()
    assert not at.exception and at.number_input(key='bp_lug_t').value==42.
    at.selectbox(key='bp_shear_mechanism').set_value('device').run()
    at.selectbox(key='bp_device_model').set_value('external').run()
    assert at.selectbox(key='bp_external_shape').value=='cruciform'
    assert at.number_input(key='bp_external_shear_kgf').value==16000.
    assert at.text_input(key='bp_external_shear_ref').value.startswith('MC CR01')


def test_lug_import_repeated_keeps_raw_moment_no_double_count():
    at=open_lug()
    c=replace(presets()['Chave retangular · cortante puro'],M=4e6,V=-100000.)
    for _ in range(2):
        data=json.dumps(c.to_dict()).encode()
        at.get('file_uploader')[0].upload('chave.json',data,'application/json').run()
        button(at,'Abrir placa de base JSON').click().run()
        assert not at.exception
        c=BasePlate.from_dict(at.session_state['_base_plate_project'])
        assert c.M==pytest.approx(4e6,abs=1e-8) and c.V==pytest.approx(-100000.,abs=1e-8)
        assert evaluate(c).geometry['M_effective']==pytest.approx(-8080000.,abs=1e-8)
    at.number_input(key='bp_lug_bv').set_value(40.).run()
    assert any('DADOS OU GEOMETRIA INVÁLIDOS' in x.value for x in at.error)
    assert button(at,'Gerar memória da placa de base').disabled
    at.selectbox(key='connection_family').set_value('Single plate').run()
    at.selectbox(key='connection_family').set_value(FAMILY).run()
    assert at.number_input(key='bp_lug_bv').value==40.
    assert button(at,'Gerar memória da placa de base').disabled
