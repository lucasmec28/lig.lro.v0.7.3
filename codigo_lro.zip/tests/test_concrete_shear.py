"""Independent numeric fixtures generated without production imports."""
import json
import math
from pathlib import Path
import pytest
from lro.concrete_shear import (shear_breakout_row,evaluate_shear,evaluate_pryout,aci_steel,interaction)

IN=25.4;LB=4.4482216152605;PSI=.006894757293168361
FIX=json.loads((Path(__file__).parents[1]/'docs/concrete_completion/shear_benchmarks.json').read_text())

@pytest.mark.parametrize('fixture',FIX['shear_rows'],ids=lambda f:f['id'])
def test_independent_shear_rows(fixture):
    i=fixture['inputs'];n=i.get('n',2);s=i['s']
    p=[0.,s*IN] if n==2 else [0.]
    force=[1.,1.] if n==2 else [1.]
    if i.get('e'):
        # positions0,4in; resultant3in => eccentricity1in.
        force=[1.,3.]
    r=shear_breakout_row(ca1=i['c']*IN,positions=p,edge_min=-i['left']*IN,
        edge_max=(s+i['right'])*IN,member_depth=i['ha']*IN,hef=i['hef']*IN,
        diameter=i['da']*IN,fc=i['fc']*PSI,forces=force,ids=[f'A{k}' for k in range(n)],
        parallel=i.get('parallel',False))
    c=r['checks'][0];e=fixture['expected']
    assert c['ca1_calc']==pytest.approx(e['ca1_calc']*IN,rel=1e-12)
    assert c['area']==pytest.approx(e['AVc']*IN**2,rel=1e-12)
    assert c['area0']==pytest.approx(e['AVco']*IN**2,rel=1e-12)
    for key,ref in [('vb1','Vb1'),('vb2','Vb2'),('vb','Vb')]:
        assert c[key]==pytest.approx(e[ref]*LB,rel=1e-12)
    for key in ('psi_ec','psi_ed','psi_h','parallel_factor'):
        assert c[key]==pytest.approx(e[key],rel=1e-12)
    assert c['resistance']==pytest.approx(e['design_N'],rel=1e-12)


def rods(spacingx=4,spacingy=4):
    return [dict(id=f'A{i+1}',x=x*IN,y=y*IN,tension=1000*(i+1))
            for i,(x,y) in enumerate(((-spacingx/2,-spacingy/2),(-spacingx/2,spacingy/2),
                                     (spacingx/2,-spacingy/2),(spacingx/2,spacingy/2)))]

def dist(mode='equal_four',**kw):
    return dict(mode=mode,qualified=True,reference='Explicit verified synthetic fixture detail',
                parallel_model='virtual_perpendicular',**kw)


def test_source_case3_and_no_simultaneous_load_duplication():
    r=evaluate_shear(rods(),(-40*IN,-30*IN,14*IN,30*IN),10*IN,4000*PSI,24*IN,.75*IN,10000*LB,dist())
    assert r['status']=='calculated'
    front=[c for c in r['breakout']['checks'] if c['edge']=='right']
    assert {c['case'] for c in front}=={'case3'}
    assert front[0]['demand']==10000*LB
    assert [a['shear'] for a in r['rods']]==[2500*LB]*4
    assert sum(a['shear'] for a in r['rods'])==10000*LB
    assert all(c['basis']=='source_row_method' for c in r['breakout']['checks'])


def test_source_case1_2_physical_spacing_threshold():
    r=evaluate_shear(rods(spacingx=6),(-40*IN,-30*IN,7*IN,30*IN),10*IN,4000*PSI,30*IN,.75*IN,10000*LB,dist())
    front=[c for c in r['breakout']['checks'] if c['edge']=='right']
    assert [(c['case'],c['demand']/LB) for c in front]==[('case1',5000),('case2',10000)]
    assert [c['ca1_physical']/IN for c in front]==[4,10]


def test_reverse_force_selects_opposite_actual_edge():
    a=rods();bounds=(-8*IN,-20*IN,14*IN,20*IN)
    p=evaluate_shear(a,bounds,8*IN,4000*PSI,20*IN,IN,1000,dist())
    n=evaluate_shear(a,bounds,8*IN,4000*PSI,20*IN,IN,-1000,dist())
    assert any(c['edge']=='right' for c in p['breakout']['checks'])
    assert not any(c['edge']=='left' for c in p['breakout']['checks'])
    assert any(c['edge']=='left' for c in n['breakout']['checks'])
    assert min(c['ca1_physical'] for c in n['breakout']['checks'] if c['edge']=='left')==6*IN


def test_parallel_model_must_be_explicit_but_perpendicular_kept():
    d=dist();d.pop('parallel_model')
    r=evaluate_shear(rods(),(-20*IN,-20*IN,20*IN,20*IN),10*IN,4000*PSI,24*IN,IN,1000,d)
    assert r['status']=='pending' and r['breakout']['checks']
    assert r['pryout']['status']=='calculated'
    assert {c['edge'] for c in r['breakout']['checks']}=={'right'}


def test_parallel_virtual_construction_is_source_case_primary():
    r=evaluate_shear(rods(),(-20*IN,-6*IN,20*IN,6*IN),8*IN,4000*PSI,20*IN,IN,1000,dist())
    sides=[c for c in r['breakout']['checks'] if c['edge'] in ('top','bottom')]
    assert sides and all(c['parallel_factor']==2 and c['psi_ed']==1 for c in sides)
    assert {c['case'] for c in sides}=={'case1','case2'} # spacing4==near4
    assert all(c['virtual_perpendicular'] for c in sides)


def test_optional_envelope_is_separate_and_not_default():
    b=(-40*IN,-30*IN,7*IN,30*IN)
    base=evaluate_shear(rods(6),b,10*IN,4000*PSI,30*IN,IN,1000,dist())
    extra=evaluate_shear(rods(6),b,10*IN,4000*PSI,30*IN,IN,1000,dist(optional_envelope=True))
    assert not any(c['basis']=='optional_conservative_envelope' for c in base['breakout']['checks'])
    assert any(c['basis']=='optional_conservative_envelope' for c in extra['breakout']['checks'])
    source=[c for c in extra['breakout']['checks'] if c['basis']=='source_row_method']
    assert source==base['breakout']['checks']


def test_distribution_not_inferred_and_invalid_documented_forces_fail():
    a=rods();b=(-20*IN,-20*IN,20*IN,20*IN)
    for d in ({},dict(mode='equal_four',qualified=True),dist('documented',forces={'A1':1000}),
              dist('documented',forces={'A1':400,'A2':100,'A3':250,'A4':250})):
        assert evaluate_shear(a,b,10*IN,4000*PSI,24*IN,IN,1000,d)['status']=='pending'
    valid=dist('documented',forces={'A1':100,'A2':100,'A3':400,'A4':400})
    assert evaluate_shear(a,b,10*IN,4000*PSI,24*IN,IN,1000,valid)['status']=='calculated'


def test_near_pair_actual_distribution_preserved():
    r=evaluate_shear(rods(),(-20*IN,-20*IN,20*IN,20*IN),10*IN,4000*PSI,24*IN,IN,1000,dist('near_row'))
    assert [a['shear'] for a in r['rods']]==[0,0,500,500]
    assert r['pryout']['checks'][0]['ids']==['A3','A4']


def test_disconnected_row_never_pools_capacities():
    r=shear_breakout_row(ca1=2*IN,positions=[0,7*IN],edge_min=-10*IN,edge_max=17*IN,
                        member_depth=10*IN,hef=4*IN,diameter=.5*IN,fc=4000*PSI,
                        forces=[1000,9000],ids=['A','B'])
    assert r['disconnected'] and len(r['checks'])==2
    assert [c['demand'] for c in r['checks']]==[1000,9000]
    assert r['checks'][1]['ratio']==pytest.approx(9*r['checks'][0]['ratio'])


def test_pryout_uses_shear_active_group_even_without_tension():
    a=[dict(z,tension=0,shear=1000) for z in rods()]
    r=evaluate_pryout(a,(-40*IN,-40*IN,40*IN,40*IN),10*IN,4000*PSI)
    e=FIX['pryout'][0]
    assert r['status']=='calculated';c=r['checks'][0]
    assert c['resistance']==pytest.approx(e['design_lbf']*LB,rel=1e-12)
    assert c['demand']==4000 and len(c['ids'])==4


def test_pryout_kcp_physical_not_fictitious_depth():
    a=[dict(z,shear=1000) for z in rods()]
    r=evaluate_pryout(a,(-5*IN,-5*IN,5*IN,5*IN),10*IN,4000*PSI)
    c=r['checks'][0];e=FIX['pryout'][1]
    assert c['hcalc']==pytest.approx(2*IN) and c['kcp']==2
    assert c['resistance']==pytest.approx(e['design_lbf']*LB,rel=1e-12)

@pytest.mark.parametrize('fixture',FIX['aci_steel'],ids=lambda f:f['id'])
def test_aci_steel_independent_effective_area_and_phi(fixture):
    f=fixture;duct='ductile_' in f['id'] and 'brittle' not in f['id'];grout=f['grout_factor']==.8
    r=aci_steel(tension=1000,shear=500,area_tension=f['Ase_N_in2']*IN**2,
                area_shear=f['Ase_V_in2']*IN**2,fy=250,fu=400,
                ductile=duct,grout=grout,ductility_ref='Synthetic certificate' if duct else '')
    assert r['checks'][0]['resistance']==pytest.approx(f['tension_design_lbf']*LB,rel=1e-12)
    assert r['checks'][1]['resistance']==pytest.approx(f['shear_design_lbf']*LB,rel=1e-12)

@pytest.mark.parametrize('f',FIX['interaction'])
def test_interaction_independent_branches(f):
    n=[dict(demand=f['beta_N']*1000,resistance=1000)]
    v=[dict(demand=f['beta_V']*1000,resistance=1000)]
    r=interaction(n,v,complete=True)
    assert r['passes']==f['passes']
    assert r['interaction_required']==f['interaction_required']
    assert r['ratio']==pytest.approx(f['utilization'])
    assert interaction(n,v,complete=False)['passes'] is None

@pytest.mark.parametrize('bad',[True,float('nan'),float('inf'),-1,0])
def test_invalid_number_rejected(bad):
    with pytest.raises(ValueError):
        shear_breakout_row(ca1=bad,positions=[0],edge_min=-100,edge_max=100,member_depth=300,
                           hef=100,diameter=20,fc=30,forces=[1000],ids=['A'])


def test_ductility_requires_proof_and_zero_shear_no_fake_demand():
    with pytest.raises(ValueError):
        aci_steel(tension=1,shear=1,area_tension=100,area_shear=100,fy=250,fu=400,ductile=True)
    r=evaluate_shear(rods(),(-1000,-1000,1000,1000),200,30,500,20,0,{})
    assert r['status']=='not_demanded' and not r['checks']


def test_malformed_anchor_and_irregular_pryout_return_pending():
    assert evaluate_pryout([None],(-100,-100,100,100),50,30)['status']=='pending'
    bad=[dict(id='A',x=-10,y=-10,shear=100),dict(id='B',x=10,y=10,shear=100)]
    assert evaluate_pryout(bad,(-100,-100,100,100),50,30)['status']=='pending'
    assert evaluate_shear([None],(-100,-100,100,100),50,30,100,20,10,dist())['status']=='pending'
