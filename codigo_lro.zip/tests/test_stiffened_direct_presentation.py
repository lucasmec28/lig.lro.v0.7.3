from copy import deepcopy
from io import BytesIO
from pathlib import Path
import json
from docx import Document
from streamlit.testing.v1 import AppTest
from stiffened_base_app_candidate_20261017.direct_controller import direct_example,calculate,document
from stiffened_base_app_candidate_20261017.direct_docx_report import export_user_docx

ROOT=Path(__file__).resolve().parents[1]


def app():
    return AppTest.from_string(f'''import sys
sys.path.insert(0,{str(ROOT)!r})
from stiffened_base_app_candidate_20261017.direct_ui import render
render()
''',default_timeout=60).run()


def text_doc(raw):
    d=Document(BytesIO(raw))
    return '\n'.join([p.text for p in d.paragraphs]+[c.text for t in d.tables for r in t.rows for c in r.cells])


def test_stiffened_direct_ui_example_preserves_physical_v_and_stales_on_change():
    at=app();assert not at.exception,[x.message for x in at.exception]
    assert at.text_input(key='sbv.loads.V_N').value==''
    at.button(key='sbv.example').click().run();assert not at.exception,[x.message for x in at.exception]
    assert float(at.text_input(key='sbv.loads.V_N').value)==40000.
    at.button(key='sbv.calculate').click().run();assert not at.exception,[x.message for x in at.exception]
    r=at.session_state['sbv.result']
    assert r['physical_inputs']['loads']['V_N']==40000.
    assert r['projection']['loads_NM']['V_N']==0.
    assert not r['assembly_approval'] and r['coverage_qualified'] and r['selected_route_resistance_pass']
    assert any('Escopo nominal delimitado' in x.value for x in at.success)
    assert len(at.dataframe[0].value)>100
    at.text_input(key='sbv.direct_shear.hole_diameter').set_value('28.575').run()
    assert not at.exception
    assert any('Recalcule' in x.value for x in at.warning)
    at.button(key='sbv.reset').click().run();assert not at.exception
    assert at.text_input(key='sbv.loads.V_N').value==''


def test_stiffened_direct_import_atomic_and_independent_nm_state():
    at=app()
    x=direct_example(-1)
    at.text_area(key='sbv.import_text').set_value(document(x))
    at.button(key='sbv.import').click().run()
    assert not at.exception,[w.message for w in at.exception]
    assert float(at.text_input(key='sbv.loads.M_Nmm').value)==x['loads']['M_Nmm']
    at.text_area(key='sbv.import_text').set_value('{}')
    at.button(key='sbv.import').click().run()
    assert at.error and not at.exception
    assert float(at.text_input(key='sbv.loads.V_N').value)==40000.
    assert 'sb.result' not in at.session_state


def test_stiffened_direct_word_preserves_original_actions_and_scopes():
    x=direct_example();r=calculate(x)
    raw=export_user_docx(x,r)
    text=text_doc(raw)
    assert 'ESCOPO NOMINAL DELIMITADO N + M + V ATENDE' in text
    assert 'Envelope OPCIONAL' in text and 'Não é exigência normativa geral' in text
    assert 'd0+2 mm' in text and 'Critérios governantes por família' in text
    assert '40000' in text
    assert 'Projeção normal N/M' in text and '0 somente nos componentes normais' in text
    assert 'γM2=1,25' in text and 'γa2=1,35' in text
    assert 'O programa não calcula δtotal' in text
    assert 'in-plane' not in text and 'fabricação' in text
    assert 'Memória normal detalhada indisponível' not in text
    assert 'EXEMPLO SINTÉTICO' in text


def test_stiffened_direct_word_rejects_stale_result():
    x=direct_example();r=calculate(x);edited=deepcopy(x);edited['loads']['V_N']+=10.
    try:export_user_docx(edited,r)
    except ValueError as e:assert 'desatualizado' in str(e)
    else:raise AssertionError('Stale physical load field was exported')


def test_separate_route_is_exposed_without_changing_original_default():
    text=(ROOT/'app.py').read_text()
    assert "STIFFENED_DIRECT='Base nervurada · N + M + V · direta · revisão'" in text
    assert '[STIFFENED_REVIEW,STIFFENED_DIRECT,' in text


def test_stiffened_failed_or_outside_envelope_word_does_not_show_approval():
    for field,value in [('V_N',200000.),('plate_thickness_mm',35.)]:
        p=direct_example();p['loads' if field=='V_N' else 'geometry'][field]=value
        r=calculate(p);text=text_doc(export_user_docx(p,r))
        assert not r['selected_route_resistance_pass']
        assert 'ESCOPO NOMINAL N + M + V NÃO APROVADO' in text
        assert 'ESCOPO NOMINAL DELIMITADO N + M + V ATENDE' not in text
        assert 'Envelope OPCIONAL' in text


def test_nominal_word_scopes_and_line_units_are_contextual():
    x=direct_example();r=calculate(x);data=export_user_docx(x,r)
    from docx import Document
    from io import BytesIO
    d=Document(BytesIO(data));text='\n'.join([p.text for p in d.paragraphs]+[c.text for t in d.tables for row in t.rows for c in row.cells])
    assert 'Introdução de V pela alma e receptor' in text
    assert 'A projeção normal preserva o benefício das nervuras em N/M' in text
    assert 'A36 equivalence selecionados' not in text
    assert 'N/1 mm' in text
    assert all(c['unit']=='N/1 mm' for c in r['checks_flat'] if '.adjacent_base_metal.checks[' in c['component'])
