from dataclasses import replace
from pathlib import Path
import json,math
import pytest
from lro.base_plate import BasePlate,evaluate,presets
from lro.concrete_anchorage import breakout_group,rectangle_union_area,connected_components,INCH,LBF,PSI,anchor_tensions
from lro.base_plate_details import fillet_dimensions,grout_geometry

FIXTURE=json.loads((Path(__file__).parent/'fixtures/concrete_cone_benchmarks.json').read_text())

@pytest.mark.parametrize('row',FIXTURE['fixtures'][:7],ids=lambda x:x['id'])
def test_independent_source_fixtures(row):
    anchors=[dict(id=f'A{i}',x=x*INCH,y=y*INCH,tension=t*LBF) for i,((x,y),t) in enumerate(zip(row['anchors_xy_in'],row['tensions_lbf'])) if t>0]
    x0,x1,y0,y1=row['block_bounds_in']
    g=breakout_group(anchors,tuple(v*INCH for v in (x0,y0,x1,y1)),row['physical_hef_in']*INCH,4000*PSI)
    expected=row['expected']
    for key,fixture,factor in [('hcalc','hcalc_in',INCH),('area','A_Nc_in2',INCH**2),('area0','A_Nco_in2',INCH**2),('nb','Nb_lbf',LBF),('resistance','phi_Ncb_lbf',LBF),('psi_ed','psi_ed_N',1),('psi_ec','psi_ec_N',1),('ex','e_x_in',INCH),('ey','e_y_in',INCH)]:
        assert g[key]==pytest.approx(expected[fixture]*factor,rel=1e-10,abs=1e-8)
    assert g['hef']==row['physical_hef_in']*INCH


def test_l_shaped_union_and_disconnected_no_pooling():
    assert rectangle_union_area([(-15,-15,15,15),(-7,-15,23,15),(-15,-9,15,21)])==1320
    rods=[dict(id=str(i),x=x*INCH,y=y*INCH,tension=t*LBF) for i,(x,y,t) in enumerate([(-20,-20,34000),(-20,20,1000),(20,-20,1000),(20,20,1000)])]
    g=breakout_group(rods,(-100*INCH,)*2+(100*INCH,)*2,10*INCH,4000*PSI)
    assert g['area']==pytest.approx(3600*INCH**2)
    assert len(g['components'])==4 and not g['connected']
    assert g['resistance'] is None and g['ratio'] is None
    single=breakout_group(rods[:1],(-100*INCH,)*2+(100*INCH,)*2,10*INCH,4000*PSI)
    assert single['ratio']>1


def native(**kw):
    c=replace(presets()['T2 · tração e pequeno momento'],cone_model='aci318_19',anchor_type='buried_plate_nut',anchor_detail_ref='Detalhe AN-01',anchor_detail_confirmed=True)
    return replace(c,**kw)


def test_cone_integrates_current_signed_tension_and_preserves_loads():
    c=native(M=-5e6,V=-1000)
    r=evaluate(c);cone=r.geometry['concrete_cone']
    assert cone['status']=='calculated' and len(cone['groups'])==1
    assert cone['combination']['M_top']==-5e6
    assert sum(x['tension'] for x in cone['rods'])==pytest.approx(r.geometry['T_total'])
    assert len(cone['primary_groups'])==1
    assert any(x.id.startswith('bp_cone') for x in r.checks)
    assert r.status!='ATENDE ÀS VERIFICAÇÕES REALIZADAS'
    assert any('Ancoragem no concreto (completa)' in i.text for i in r.issues)
    mirror=evaluate(replace(c,M=5e6))
    assert mirror.geometry['concrete_cone']['governing']['ratio']==pytest.approx(cone['governing']['ratio'])

@pytest.mark.parametrize('kw',[{'anchor_type':'straight'},{'anchor_type':'hook_j'},{'anchor_detail_confirmed':False},{'anchor_detail_ref':''},{'hef':0},{'block_h':100},{'anchor_head_hole':5},{'anchor_head_width':10000}])
def test_incomplete_native_cone_never_passes_or_blocks_independent_core(kw):
    r=evaluate(native(**kw))
    assert r.geometry and r.geometry['concrete_cone']['status']=='pending'
    assert not any(x.id.startswith('bp_cone') for x in r.checks)
    assert any(x.id=='bp_anchor_steel' for x in r.checks)
    assert any(x.origin=='anchorage_data' for x in r.issues)


def test_no_tension_is_not_a_cone_pass():
    r=evaluate(native(N=150000.,M=0.,V=0.))
    assert r.geometry['concrete_cone']['status']=='not_demanded'
    assert not any(x.id.startswith('bp_cone') for x in r.checks)


def test_classification_and_stiffeners_do_not_manufacture_strength():
    c=native()
    r=evaluate(c)
    changed=evaluate(replace(c,base_fixity='pinned',stiffener_detail='web_pair'))
    assert changed.geometry==r.geometry
    assert [(x.id,x.demand,x.resistance) for x in changed.checks]==[(x.id,x.demand,x.resistance) for x in r.checks]
    assert any('preservado integralmente' in i.text for i in changed.issues)
    assert any('referência' in i.text and 'SEM enrijecedores' in i.text for i in changed.issues)


def test_weld_conversion_and_grout_are_geometric_only():
    assert fillet_dimensions(6,'leg')['throat']==pytest.approx(6/math.sqrt(2))
    assert fillet_dimensions(6,'throat')['leg']==pytest.approx(6*math.sqrt(2))
    c=native();g=grout_geometry(c)
    assert g['bottom_L']==c.L+2*c.grout_t and g['bottom_B']==c.B+2*c.grout_t
    changed=replace(c,weld_web_type='cjp',weld_flange_type='fillet',weld_flange_measure='throat',weld_flange_size=4.)
    assert evaluate(changed).geometry==evaluate(c).geometry
    assert BasePlate.from_dict(changed.to_dict())==changed


def test_legacy_json_does_not_enable_concrete_or_detail_strength():
    data=presets()['T1 · tração centrada'].to_dict()
    from lro.base_plate_details import DETAIL_DEFAULTS
    for key in DETAIL_DEFAULTS:data['connection'].pop(key)
    c=BasePlate.from_dict(data)
    assert c.cone_model=='off' and c.anchor_type=='unspecified'
    assert evaluate(c).geometry['concrete_cone']['status']=='off'


def test_optional_subset_envelope_is_separate_and_off_by_default():
    c=native()
    normal=evaluate(c).geometry['concrete_cone']
    extra=evaluate(replace(c,cone_subset_envelope=True)).geometry['concrete_cone']
    assert len(normal['groups'])==1 and len(extra['groups'])==15
    assert extra['primary_groups']==normal['primary_groups']
    assert sum(g['basis']=='supplemental' for g in extra['groups'])==14
