"""Finite conventional audit regressions, source-defined member width and integrity."""
from copy import deepcopy
from dataclasses import asdict, replace
from io import BytesIO
import json
import math
from docx import Document
import pytest
from lro.models import profiles
from lro.w_splice_conventional import WConventional, evaluate, effective_width
from lro.w_splice_conventional_report import create_report, local_pass_is_complete
from lro.w_splice_conventional_drawing import drawing_svg

BASE=WConventional(profiles()['W 310 x 97,0 (H)'],minimum_action_policy='actual_actions_engineer_choice',minimum_reference='Finite regression RT decision')

def slender():
    p=replace(BASE.profile,name='Custom W audit geometry 308x305x9.9x8',tf=8.,clear=258.,area=7770.8,mass=61.00078,source='Declared custom rolled-W geometry; not catalogue')
    return replace(BASE,profile=p,N=-1e6,M=0.,V=0.,flange_rows=8,member_steel='ASTM A36')

def text(blob):
    d=Document(BytesIO(blob))
    return '\n'.join(p.text for p in d.paragraphs)+'\n'+'\n'.join(c.text for t in d.tables for row in t.rows for c in row.cells)

def test_primary_source_member_half_total_width_witness():
    c=slender();r=evaluate(c)
    assert r['status']=='VERIFIED_SUBCHECK_FAIL' and len(r['checks'])==993
    for pos in ('top','bottom'):
        row=next(x for x in r['checks'] if x['id']==f'actual:member_flange_{pos}_compression_local_effective')
        assert row['demand']==500000 and row['status']=='FAIL'
        assert row['capacity']==pytest.approx(499558.22607919644,abs=1e-8)
        assert row['utilization']==pytest.approx(1.000884329188753,abs=1e-14)
        assert row['details']['Aeff_mm2']==pytest.approx(2198.0561947484643)
        assert row['details']['local_element']['b_mm']==152.5
        assert row['details']['global_member_stability'] is False
        assert '5.1.2.2.4(a)' in row['reference']
    assert r['compression_strips']['outer']['local_elements'][0]['kind']=='AA'
    assert r['compression_strips']['outer']['local_elements'][0]['b_mm']==c.inner_clear_band+c.flange_inner_width
    assert len(r['web_block_paths'])==84

@pytest.mark.parametrize('offset',[-1e-8,0,1e-8])
def test_source_width_boundary_stocky_and_slender(offset):
    fy=250.;limit=.56*math.sqrt(200000/fy);b=BASE.profile.bf/2
    tf=b/(limit+offset)
    p=replace(BASE.profile,tf=tf,area=2*BASE.profile.bf*tf+(BASE.profile.d-2*tf)*BASE.profile.tw,clear=BASE.profile.d-2*tf-34)
    r=evaluate(replace(BASE,profile=p,member_steel='ASTM A36'))
    row=next(x for x in r['checks'] if x['id']=='actual:member_flange_top_compression_local_effective')
    z=1.49*limit/(b/tf)
    expected=b if b/tf<=limit else min(b,b*(1-.22*z)*z)
    assert row['details']['Aeff_mm2']==pytest.approx(2*expected*tf,rel=1e-13)
    assert row['capacity']<=p.bf*tf*fy/1.1*(1+1e-12)

@pytest.mark.parametrize('changes',[{}, {'M':0.,'V':0.}, {'N':0.,'V':0.}, {'N':-1000.,'V':2000.,'minimum_action_policy':'provided_envelope','minimum_N':3000.,'minimum_V':-4000.,'minimum_M':-2e6}, {'web_pitch':90.,'web_member_end':20.,'gap':0.}])
def test_mechanism_envelopes_are_complete_unchanged_primitive_rows(changes):
    r=evaluate(replace(BASE,**changes));rows={x['id']:x for x in r['checks']}
    ids=[]
    for env in r['mechanism_envelopes']:
        ids.extend(env['member_check_ids'])
        selected=env['governing_check'];assert selected==rows[selected['id']]
        assert selected['utilization']==max(rows[i]['utilization'] for i in env['member_check_ids'])
        assert env['governing_case_id']==selected['id'].split(':')[0]
        assert env['status']==('NOT_APPLICABLE' if all(rows[i]['demand']==0 for i in env['member_check_ids']) else selected['status'])
    assert len(ids)==len(set(ids))==len(rows) and set(ids)==set(rows)
    assert max(x['governing_check']['utilization'] for x in r['mechanism_envelopes'])==r['summary']['governing_utilization']
    for case in r['load_cases']:
        for side in ('negative','positive'):
            assert sum(x['id'].startswith(case['case_id']+':web_cover_'+side+'_block_') for x in rows.values())==84
    assert len(r['physical_covers'])==8

@pytest.mark.parametrize('attack',['stale','copied_input','one_row','zero_rows','contradictory_PASS'])
def test_direct_exports_reevaluate_all_forged_snapshots(attack):
    c=replace(BASE,N=0.,M=0.,V=175000.,project='CURRENT FAILURE')
    r=evaluate(BASE)
    if attack!='stale':r['inputs']=asdict(c)
    if attack=='one_row':r['checks']=r['checks'][:1];r['summary']['check_count']=1
    if attack=='zero_rows':r['checks']=[];r['summary']['check_count']=0
    if attack=='contradictory_PASS':r['checks'][0].update(demand=2*r['checks'][0]['capacity'],utilization=2,status='PASS')
    before=deepcopy(r)
    assert not local_pass_is_complete(c,r)
    svg=drawing_svg(c,r);doc=text(create_report(c,r))
    assert 'VERIFIED_SUBCHECK_FAIL' in svg and 'VERIFIED_SUBCHECK_FAIL' in doc
    assert 'LOCAL_CHECKS_PASS_WITHIN_SCOPE' not in svg and 'Estado exato do motor: LOCAL_CHECKS_PASS_WITHIN_SCOPE' not in doc
    assert 'Não há aprovação completa' in doc and 'CURRENT FAILURE' in svg
    assert r==before


def test_corrected_width_exports_and_numerical_categories():
    c=slender();r=evaluate(c);doc=text(create_report(c,r));svg=drawing_svg(c,r)
    assert r['status'] in svg and r['status'] in doc and '499.558,226079' in doc
    assert 'b=bf/2; Aef=2 beff tf' in doc
    overflow=evaluate(replace(BASE,M=1e308))
    assert overflow['status']=='NUMERICAL_FAILURE'
    assert any(i['category']=='NUMERICAL_FAILURE' for i in overflow['issues'])
    json.dumps(overflow,allow_nan=False)
    assert evaluate(replace(BASE,M=float('nan')))['status']=='INVALID_INPUT'
    assert evaluate(replace(BASE,N=0.,M=0.,V=0.))['status']=='NOT_EVALUATED'
    pending=evaluate(replace(BASE,V=500000.,integrity_included=False))
    assert pending['status']=='VERIFIED_SUBCHECK_FAIL' and pending['summary']['failed_check_ids']
    assert any(i['category']=='LOCAL_PREREQUISITE' for i in pending['issues'])


def test_detached_drawing_identifies_tiny_entered_torsion():
    c=replace(BASE,project='Detached diagnostic project 17',torsion=5e-324)
    svg=drawing_svg(c,evaluate(BASE))
    assert 'Detached diagnostic project 17' in svg
    assert 'T informado = +4.9406564584124654e-324 N·mm' in svg
    assert 'OUTSIDE_CONVENTIONAL_SCOPE' in svg
