"""Casos de aceitação independentes: NBR 6.7.2.4 e transformação estática."""
from dataclasses import replace
import json,math
import pytest
from lro.models import Profile
from lro.base_plate import BasePlate,evaluate,reactions,shear_plate_actions

P=Profile('I 300 × 150','Soldado',40.,300.,150.,8.,12.,276.,7008.)
BASE=BasePlate(P,tp=50.8,N=0.,M=0.,V=100000.,fck=20.,grout_t=40.,
               shear_path='plate',lug_bh=100.,lug_bv=100.,lug_t=50.8)


def check(r,key):return next(x for x in r.checks if x.id=='bp_lug_'+key)


def test_acceptance_1_local_pass_retains_pending_device():
    r=evaluate(BASE);a=r.geometry['lug']
    for key,value in {'sigma_rd':24.28571428571429,'contact_area':6000.,
        'bearing_rd':145714.2857142857,'t_required':35.09985754956849,
        'bending_rd':209467.53246753244,'yield_rd':692727.2727272727,
        'rupture_rd':903111.1111111111,'weld_V':145714.2857142857,'weld_M':10200000.}.items():
        assert a[key]==pytest.approx(value,rel=1e-10)
    assert all(x.passed for x in r.checks if x.id.startswith('bp_lug_'))
    assert r.component_status=='ATENDE ÀS VERIFICAÇÕES REALIZADAS'
    assert 'A COMPLEMENTAR' in r.status
    assert any(i.severity=='pending' and 'metal-base' in i.text for i in r.issues)
    assert any(i.severity=='pending' and 'bloco adequadamente armado' in i.text for i in r.issues)
    assert not any('weld' in x.id or 'solda' in x.name.lower() for x in r.checks)
    assert 'shear_rd' not in r.geometry
    assert not any(x.id in ('bp_shear','bp_shear_external') for x in r.checks)
    assert BASE.sigma_rd==pytest.approx(a['sigma_rd']/2)


def test_acceptance_2_bearing_fail_without_friction_rescue():
    r=evaluate(replace(BASE,V=150000.,N=150000.))
    assert not check(r,'contact').passed
    assert check(r,'bending').passed
    assert r.geometry['friction_rd']>0
    assert check(r,'contact').resistance==pytest.approx(145714.2857142857)
    assert 'NÃO ATENDE' in r.component_status


def test_acceptance_3_thickness_failures_are_not_corrected():
    c=replace(BASE,lug_t=31.75);r=evaluate(c)
    assert not check(r,'bending').passed
    assert c.lug_t==31.75
    c=replace(BASE,tp=38.1);r=evaluate(c)
    assert not check(r,'thickness').passed
    assert c.tp==38.1 and c.lug_t==50.8


def test_acceptance_4_weld_demands_at_concrete_capacity_not_applied_shear():
    c=replace(BASE,lug_bh=200.,lug_bv=150.,lug_t=31.75,tp=38.1,fck=30.)
    r=evaluate(c);a=r.geometry['lug']
    assert check(r,'bending').passed
    assert a['weld_V']==pytest.approx(801428.5714285715)
    assert a['weld_M']==pytest.approx(76135714.2857143)
    assert a['weld_V']>a['bending_rd']>abs(c.V)
    assert shear_plate_actions(replace(c,V=0.))['weld_M']==a['weld_M']


def test_acceptance_5_signed_pure_shear_and_json_roundtrip():
    pos=evaluate(BASE).geometry;neg=evaluate(replace(BASE,V=-BASE.V)).geometry
    assert pos['eV']==120.8 and pos['delta_M']==12080000.
    assert pos['M_input']==0 and pos['M_effective']==12080000.
    for key in ('lc','C','Ft_max','t_required'):
        assert pos[key]==pytest.approx(neg[key])
    assert pos['C_x']==-neg['C_x'] and pos['T_max_x']==-neg['T_max_x']
    assert abs(pos['residual_M'])<1e-7 and abs(neg['residual_M'])<1e-7
    c=replace(BASE,V=-BASE.V,M=4e6)
    for _ in range(3):
        c=BasePlate.from_dict(json.loads(json.dumps(c.to_dict())))
        a=evaluate(c).geometry
        assert c.M==4e6 and c.V==-100000.
        assert a['M_effective']==-8080000.
        assert 'M_effective' not in c.to_dict()['connection']


def test_signed_moment_cancellation_and_reinforcement():
    cancel=evaluate(replace(BASE,M=-12080000.)).geometry
    assert cancel['case']=='SEM N/M' and cancel['M_effective']==0.
    assert cancel['C']==cancel['T_total']==0.
    both=evaluate(replace(BASE,M=12080000.)).geometry
    assert both['M_effective']==24160000.
    signflip=evaluate(replace(BASE,M=-12e6)).geometry
    assert signflip['M_effective']==80000. and signflip['moment_sign']==1

@pytest.mark.parametrize('grout',[20.,40.,60.])
def test_actual_grout_not_anchor_table_value(grout):
    c=replace(BASE,grout_t=grout);a=evaluate(c).geometry
    assert a['eV']==c.tp+(c.lug_bv+grout)/2
    assert a['lug']['contact_area']==100*(100-grout)
    assert a['lug']['weld_M']==pytest.approx(a['lug']['bearing_rd']*(100+grout)/2)

@pytest.mark.parametrize('kwargs',[{'lug_bv':40.},{'lug_bv':20.},{'lug_bh':300.},
    {'lug_t':500.},{'lug_t':0.},{'lug_bv':math.nan},{'lug_bh':math.inf},
    {'lug_t':True},{'V':math.inf},{'lug_steel':'ASTM A992'},
    {'lug_bv':1e308},{'V':1e308},{'grout_t':math.nan}])
def test_invalid_key_never_produces_favorable_checks(kwargs):
    c=replace(BASE,**kwargs);r=evaluate(c)
    assert not r.geometry and not r.checks
    assert r.status=='DADOS OU GEOMETRIA INVÁLIDOS'
    with pytest.raises(ValueError):BasePlate.from_dict(c.to_dict())

@pytest.mark.parametrize('path',['friction','external'])
def test_legacy_json_and_paths_preserve_existing_nm_behavior(path):
    c=replace(BASE,shear_path=path,N=150000.,M=-6e6,
              external_shear_rd=200000.,external_shear_ref='MC dispositivo 1')
    data=c.to_dict()
    for k in ('lug_bh','lug_bv','lug_t','lug_steel','external_shape'):del data['connection'][k]
    old=BasePlate.from_dict(data);a=evaluate(old).geometry
    assert old.lug_steel=='ASTM A36' and old.lug_t==19.05
    assert a['delta_M']==0 and a['M_effective']==-6e6
    assert 'lug' not in a
    assert not any(x.id.startswith('bp_lug_') for x in evaluate(old).checks)
    assert reactions(old)['T_max_x']==reactions(c)['T_max_x']

@pytest.mark.parametrize('shape',['cruciform','w_major','w_minor'])
def test_other_shapes_use_documented_external_route_only(shape):
    c=replace(BASE,shear_path='external',external_shape=shape,
              external_shear_rd=130000.,external_shear_ref='MC externo revisão 1')
    loaded=BasePlate.from_dict(c.to_dict());r=evaluate(loaded)
    assert loaded.external_shape==shape and 'lug' not in r.geometry
    assert any(x.id=='bp_shear_external' for x in r.checks)
    assert not any(x.id.startswith('bp_lug_') for x in r.checks)


def test_extreme_finite_moment_does_not_approve_equilibrium():
    r=evaluate(replace(BASE,M=1e308))
    assert not r.geometry and r.component_status=='EQUILÍBRIO NÃO DEMONSTRADO'
