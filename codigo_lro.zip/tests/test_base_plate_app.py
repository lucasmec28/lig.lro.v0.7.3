import json
from pathlib import Path
import pytest
from streamlit.testing.v1 import AppTest
from lro.base_plate import presets
from lro.models import KGF

APP=Path(__file__).resolve().parents[1]/'app.py'
FAMILY='Placa de base · Tipo 1'

def open_app():
    at=AppTest.from_file(str(APP),default_timeout=60).run()
    at.selectbox(key='connection_family').set_value(FAMILY).run()
    assert not at.exception
    return at

def button(at,label):return next(x for x in at.button if x.label==label)

def test_default_scoped_status_and_word_invalidation():
    at=open_app()
    assert at.selectbox(key='bp_shear_mechanism').value=='anchors'
    assert any('DADOS PENDENTES' in x.value for x in at.warning)
    assert any('ancoragem no concreto' in x.value for x in at.warning)
    button(at,'Gerar memória da placa de base').click().run()
    assert not at.exception and at.session_state['bp_report'][2][:2]==b'PK'
    button(at,'Gerar memória da placa de base').click().run()
    assert not at.exception
    at.number_input(key='bp_N_kgf').set_value(20000.).run()
    assert 'bp_report' not in at.session_state
    assert not any(getattr(x,'label','')=='Baixar memória da placa de base .docx' for x in at.get('download_button'))


def test_all_examples_repeat_and_negative_moment():
    at=open_app()
    for name in presets():
        at.selectbox(key='bp_example').set_value(name).run()
        button(at,'Usar exemplo de placa de base').click().run()
        assert not at.exception
        assert at.session_state['_base_plate_project']['connection']['project']==presets()[name].project
    at.number_input(key='bp_M_kgfm').set_value(-3000.).run()
    assert not at.exception
    assert at.session_state['_base_plate_project']['connection']['M']<0


def test_family_switch_preserves_valid_and_invalid_draft():
    at=open_app()
    at.number_input(key='bp_N_kgf').set_value(-12000.).run()
    at.selectbox(key='connection_family').set_value('Single plate').run()
    at.selectbox(key='connection_family').set_value(FAMILY).run()
    assert not at.exception and at.number_input(key='bp_N_kgf').value==-12000.
    at.number_input(key='bp_a1').set_value(.1).run()
    assert any('DADOS OU GEOMETRIA INVÁLIDOS' in x.value for x in at.error)
    at.selectbox(key='connection_family').set_value('Single plate').run()
    at.selectbox(key='connection_family').set_value(FAMILY).run()
    assert not at.exception and at.number_input(key='bp_a1').value==.1
    assert button(at,'Gerar memória da placa de base').disabled


def test_external_shear_hidden_fields_survive():
    at=open_app()
    at.selectbox(key='bp_shear_mechanism').set_value('device').run()
    at.selectbox(key='bp_device_model').set_value('external').run()
    at.number_input(key='bp_external_shear_kgf').set_value(18000.).run()
    at.text_input(key='bp_external_shear_ref').set_value('MC chave 01').run()
    at.selectbox(key='bp_shear_mechanism').set_value('friction').run()
    at.number_input(key='bp_N_kgf').set_value(17000.).run()
    at.selectbox(key='bp_shear_mechanism').set_value('device').run()
    at.selectbox(key='bp_device_model').set_value('external').run()
    assert not at.exception
    assert at.number_input(key='bp_external_shear_kgf').value==18000.
    assert at.text_input(key='bp_external_shear_ref').value=='MC chave 01'


def test_custom_plate_switch_and_import_roundtrip():
    at=open_app()
    at.selectbox(key='bp_tp_label').set_value('Personalizada').run()
    at.number_input(key='bp_tp').set_value(24.).run()
    at.selectbox(key='connection_family').set_value('Single plate').run()
    at.selectbox(key='connection_family').set_value(FAMILY).run()
    assert not at.exception and at.number_input(key='bp_tp').value==24.
    c=list(presets().values())[4]
    at.get('file_uploader')[0].upload('base.json',json.dumps(c.to_dict()).encode(),'application/json').run()
    button(at,'Abrir placa de base JSON').click().run()
    assert not at.exception and at.number_input(key='bp_N_kgf').value==c.N/KGF
    assert at.selectbox(key='bp_tp_label').value=='1"'
    at.get('file_uploader')[0].upload('erro.json',b'{','application/json').run()
    button(at,'Abrir placa de base JSON').click().run()
    assert not at.exception and any('Não foi possível abrir' in x.value for x in at.error)
    assert at.number_input(key='bp_N_kgf').value==c.N/KGF
