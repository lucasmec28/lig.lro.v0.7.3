from copy import deepcopy
from dataclasses import replace
import math
import pytest
from lro.direct_plate_transfer import type2_plate_component
from lro.base_plate import evaluate
from lro.pinned_base_plate import PinnedBasePlate
from lro.column_base_weld import ColumnBaseWeld
from lro.base_weld_qualified import qualification_signature
from lro.concrete_components import bearing_signature
from test_direct_anchor_integration import fixture,P,config


def states(V,pitch):
    sign=1 if V>=0 else -1
    rods=[dict(id='A'+str(i+1),x=x,y=y,tension=0.) for i,(x,y) in enumerate(
        ( (x,y) for x in (-pitch/2,pitch/2) for y in (-pitch/2,pitch/2) ))]
    return [dict(id=name,rods=[dict(a,shear=abs(V)/4 if side==0 else abs(V)/2 if a['x']*side*sign>0 else 0.) for a in rods])
            for name,side in [('normal_hole_equal',0),('leading_row',1),('opposite_row_envelope',-1)]]


def oracle(**kw):
    p=dict(hp=260.,tp=20.,pitch=100.,tw=8.,d0=24.,B=180.,fy=250.,fu=400.,V=600000.)
    p.update(kw);p['states']=states(p['V'],p['pitch']);return type2_plate_component(**p)


def qualified_type2(**kw):
    b=fixture()
    c=PinnedBasePlate(replace(P,area=5808.,mass=45.5928),db=24.,a1=70.,a2=120.,tp=50.,N=200000.,V=40000.,
        shear_path='anchors',anchor_shear_model='direct_plate_bearing',direct_shear=config(),
        anchor_washer_side=70.,anchor_washer_t=10.,anchor_type=b.anchor_type,anchor_detail_confirmed=True,
        anchor_detail_ref=b.anchor_detail_ref,cone_model=b.cone_model,concrete_components=b.concrete_components,
        weld_web_type='fillet',weld_flange_type='fillet',weld_web_size=8.,weld_flange_size=8.,
        column_weld=ColumnBaseWeld(model='two_flange_normal_web_shear',column_steel='ASTM A36',
            process='smaw_e7018_single_pass',web_length=276.,web_effective_length=276.,flange_length=150.,
            flange_effective_length=150.,qualification_method='one_way',transfer_ref='Synthetic documented conventional allocation'))
    c=replace(c,**kw)
    c=replace(c,column_weld=replace(c.column_weld,qualification_signature=qualification_signature(c)))
    return replace(c,concrete_components=replace(c.concrete_components,bearing_confirmation=bearing_signature(c)))


def test_independent_p358_oracle_and_critical_short_prefix():
    r=oracle();assert r['complete'] and not r['passes']
    assert r['resistances_N']['gross']==pytest.approx(1181976.929050)
    assert r['resistances_N']['net']==pytest.approx(1566697.690473)
    assert r['resistances_N']['block_full']==pytest.approx(1189784.387633)
    lead=r['states'][1];opp=r['states'][2]
    assert lead['passes'] and not opp['passes']
    short=[c for c in opp['prefixes'] if c['m']==1]
    assert all(c['demand']==300000 and c['resistance']==pytest.approx(285899.091524) for c in short)
    assert all(c['status']=='sufficient_bound_exceeded' for c in short)
    assert all(c['Anv_mm2']==1360 for c in short)
    assert all(c['Anv_mm2']==2880 for c in opp['prefixes'] if c['m']==2)


def test_reversal_real_loaded_edge_and_holes():
    a=oracle(V=100000);b=oracle(V=-100000)
    assert a['passes'] and b['passes']
    assert a['resistances_N']==b['resistances_N']
    assert a['states'][2]['prefixes'][0]['ids']!=b['states'][2]['prefixes'][0]['ids']
    assert all(x['loaded_edge']=='x-' for x in a['states'][2]['prefixes'])
    assert all(x['loaded_edge']=='x+' for x in b['states'][2]['prefixes'])


@pytest.mark.parametrize('hp,bending',[(407.999,True),(408.,False),(408.001,False)])
def test_inplane_threshold(hp,bending):
    r=oracle(hp=hp,pitch=300.,B=400.,d0=24.,V=100000.)
    assert r['complete'] and r['inplane_bending_required'] is bending
    assert ('inplane_bending' in r['resistances_N']) is bending
    assert r['full_block_tension_coefficient']==(.5 if bending else 1)


@pytest.mark.parametrize('kw',[dict(hp=157.),dict(B=157.),dict(pitch=50.),dict(fy=500.,fu=400.),dict(tp=True)])
def test_outside_is_not_a_fictitious_plate_failure(kw):
    r=oracle(**kw);assert not r['complete'] and r['passes'] is None
    assert r['status']=='outside_p358_type2_domain' and not r['checks']


def test_inactive_hole_still_deducted():
    r=oracle(V=100000.)
    long=r['states'][1]['prefixes'][1]
    assert len(long['ids'])==2 and 0. in long['forces_N'].values()
    assert long['m']==2 and long['Anv_mm2']==2880.


def test_unsymmetric_or_unbalanced_state_not_repaired():
    p=dict(hp=260.,tp=20.,pitch=100.,tw=8.,d0=24.,B=180.,fy=250.,fu=400.,V=100000.,states=states(100000.,100.))
    p['states'][0]['rods'][0]['shear']+=1.
    assert not type2_plate_component(**p)['complete']


def test_actual_type2_composition_can_close_selected_direct_scope():
    c=qualified_type2();r=evaluate(c);d=r.geometry['direct_anchor_shear']
    assert d['local_transfer_scope']['complete'] and d['local_transfer_scope']['passes']
    assert d['direct_route_resistance_pass']
    assert d['plate_transfer_scope']['independently_calculated']
    assert not c.direct_shear.plate_transfer_complete  # documentary checkbox did not certify it
    assert d['local_transfer_scope']['panel']['geometry']['hp_mm']==276.
    assert d['local_transfer_scope']['introduction']['complete']
    assert not d['foundation_scope']['complete']


def test_plate_length_does_not_increase_source_or_capacity():
    a=evaluate(qualified_type2());b=evaluate(qualified_type2(a1=100.))
    pa=a.geometry['direct_anchor_shear']['local_transfer_scope']['panel']
    pb=b.geometry['direct_anchor_shear']['local_transfer_scope']['panel']
    assert pa['geometry']['hp_mm']==pb['geometry']['hp_mm']==276.
    assert pa['resistances_N']['gross']==pb['resistances_N']['gross']
    assert pa['resistances_N']['net']==pb['resistances_N']['net']
    # This family ties B to a1 too: its actual longer transverse ligament may
    # legitimately improve block capacity, but never the web source hp.
    assert pb['geometry']['B_mm']>pa['geometry']['B_mm']


def test_source_qualification_and_axial_washer_remain_real_obligations():
    c=qualified_type2();stale=replace(c,V=20000.)
    assert not evaluate(stale).geometry['direct_anchor_shear']['direct_route_resistance_pass']
    r=evaluate(qualified_type2(N=-40000.,V=10000.));d=r.geometry['direct_anchor_shear']
    assert d['local_transfer_scope']['complete']
    assert not d['direct_route_resistance_pass'] and not d['normal_and_axial_scope']['axial_washer_complete']
    assert any(i.origin=='direct_anchor_axial' for i in r.issues)
    assert r.component_outcome=='pending' and 'AXIAL' in r.component_status


def test_large_V_failure_is_preserved_and_exportable():
    r=evaluate(qualified_type2(V=600000.));d=r.geometry['direct_anchor_shear']
    assert not d['direct_route_resistance_pass'] and any(not c.passed for c in r.checks)
    import json
    json.dumps(d,allow_nan=False)


def test_passing_and_axial_pending_word_scopes():
    from lro.base_plate_report import create_report
    from test_direct_anchor_presentation import all_text
    c=qualified_type2();text=all_text(create_report(c,evaluate(c),True))
    assert 'ATENDE ao escopo resistente da rota direta' in text
    assert 'SCI P358 Check9' in text and '276' in text
    assert 'Prefixos de bloco' in text and 'γM2,placa=1,25' in text
    assert 'Blocos reais' in text and 'x-' in text
    assert '353,00 mm²' in text and '0,00 mm²; fonte pendente' not in text
    assert 'Construção perpendicular virtual ACI do método direto' in text
    assert 'Base completa e metal-base local da placa continuam a complementar' not in text
    assert 'Permanecem a verificar o metal-base da placa junto à fusão' not in text
    c=qualified_type2(N=-40000.,V=10000.);text=all_text(create_report(c,evaluate(c),True))
    assert 'ROTA DIRETA NÃO APROVADA' in text
    assert 'transferência axial local da arruela/porca superior não calculada' in text


def test_type2_ui_calculated_plate_and_no_stale_approval():
    from test_direct_anchor_presentation import app
    at=app(qualified_type2());assert not at.exception
    assert any('rota resistente atende' in x.value for x in at.markdown)
    at.number_input(key='pp_ds_hole_diameter').set_value(33.).run()
    assert not at.exception
    assert not any('rota resistente atende' in x.value for x in at.markdown)


def test_source_failure_does_not_hide_simultaneous_process_pending():
    c=qualified_type2(weld_web_size=1.)
    c=replace(c,column_weld=replace(c.column_weld,process='unspecified'))
    c=replace(c,column_weld=replace(c.column_weld,qualification_signature=qualification_signature(c)))
    r=evaluate(c);d=r.geometry['direct_anchor_shear']
    assert r.local_column_weld['status']=='fail'
    assert not d['local_transfer_scope']['introduction']['complete']
    assert not d['calculation_coverage_complete'] and not d['direct_route_resistance_pass']
    assert any(not check.passed for check in r.checks)


def test_real_local_failure_not_mislabeled_as_p358_bound():
    c=qualified_type2(tp=8.)
    c=replace(c,column_weld=replace(c.column_weld,flange_length=50.,flange_effective_length=50.))
    c=replace(c,column_weld=replace(c.column_weld,qualification_signature=qualification_signature(c)))
    r=evaluate(c);local=r.geometry['direct_anchor_shear']['local_transfer_scope']
    assert local['introduction']['status']=='fail' and local['panel']['status']=='pass'
    assert local['status']=='fail'


def test_type2_three_alternatives_cannot_be_omitted_or_forged():
    kw=dict(hp=260.,tp=20.,pitch=100.,tw=8.,d0=24.,B=180.,fy=250.,fu=400.,V=600000.)
    st=states(kw['V'],kw['pitch'])
    assert not type2_plate_component(**kw,states=st[:1])['complete']
    forged=deepcopy(st)
    for r in forged[2]['rods']:r['shear']=150000.
    assert not type2_plate_component(**kw,states=forged)['complete']


def test_type2_impossible_washer_width_does_not_qualify():
    r=evaluate(qualified_type2(anchor_washer_side=10.));d=r.geometry['direct_anchor_shear']
    assert not d['direct_route_resistance_pass'] and not d['calculation_coverage_complete']
