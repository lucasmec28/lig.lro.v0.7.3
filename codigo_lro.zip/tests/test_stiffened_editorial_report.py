from copy import deepcopy
from io import BytesIO
from docx import Document
import pytest
from stiffened_base_app_candidate_20261017.direct_controller import direct_example,calculate
from stiffened_base_app_candidate_20261017.direct_docx_report import export_user_docx
from stiffened_base_app_candidate_20261017.direct_report_view import display_checks,governing_groups


def contents(raw):
 d=Document(BytesIO(raw));return '\n'.join([p.text for p in d.paragraphs]+[c.text for t in d.tables for row in t.rows for c in row.cells])


def test_editorial_export_is_pure_and_all_rows_are_mapped(monkeypatch):
 p=direct_example();r=calculate(p);before=deepcopy(r);ibefore=deepcopy(p)
 def forbidden(*a,**k):raise AssertionError('Report attempted recalculation')
 monkeypatch.setattr('stiffened_base_app_candidate_20261017.direct_controller.calculate',forbidden)
 text=contents(export_user_docx(p,r))
 assert r==before and p==ibefore
 rows=display_checks(r);groups=governing_groups(r)
 assert {c['id'] for c in rows}=={m for g in groups for m in g['members']}
 assert len(rows)==sum(g['count'] for g in groups)==405
 assert 'EXEMPLO ILUSTRATIVO DE TESTE' in text
 for banned in ('demand and','physical_corner_tie','in-plane','plate_inplane_transfer_verified','físico corner','matching chi curve','candidate_only','production_credit'):
  assert banned not in text
 assert all(g['reference'] for g in groups)


def test_editorial_governants_recover_stored_measures_and_real_families():
 p=direct_example();r=calculate(p);rows={c['id']:c for c in display_checks(r)}
 assert rows['C0001']['display_ratio']==1.0 and rows['C0002']['unit']=='MPa'
 assert rows['C0058']['ratio']==r['nm_components']['sides'][1]['selected_resistance']['utilization_M']
 assert rows['C0058']['resistance']==r['nm_components']['sides'][1]['selected_resistance']['capacity']['M_design_Nmm']
 assert rows['C0005']['unit']=='N/mm' and rows['C0005']['demand'] is not None
 assert rows['C0059']['unit']=='N/1 mm'
 assert 'geométricas' in rows['C0137']['family']
 assert 'Cone' in rows['C0323']['family']
 assert 'placa' in rows['C0042']['family'] and 'placa' in rows['C0007']['family']
 assert rows['C0026']['criterion']=='Metal de solda'


@pytest.mark.parametrize('state,ratio',[('não atende',.001),('pendente',None),('fora do domínio',None)])
def test_editorial_never_hides_nonpassing_lower_index(state,ratio):
 p=direct_example();r=calculate(p)
 # Deliberate editorial adversarial: a lower ratio must not hide a bad state.
 r['checks_flat'][58].update(state=state,ratio=ratio)
 r['selected_route_resistance_pass']=False
 if state!='não atende':r['calculation_coverage_complete']=False
 r['missing'].append('Pendência editorial adversarial rastreável')
 text=contents(export_user_docx(p,r))
 assert 'C0059' in text and state in text
 assert 'Pendência editorial adversarial rastreável' in text
 assert 'ESCOPO NOMINAL DELIMITADO N + M + V ATENDE' not in text
 assert 'ESCOPO NOMINAL N + M + V NÃO APROVADO' in text
 group=next(g for g in governing_groups(r) if 'C0059' in g['members'])
 assert any(c['id']=='C0059' for c in group['nonpassing'])


@pytest.mark.parametrize('case',['pass','fail','pending'])
def test_export_real_pass_failure_pending_states(case):
 p=direct_example()
 if case=='fail':p['loads']['V_N']=200000.
 if case=='pending':p['anchorage']['headed_detail']['mechanical_ref']=''
 r=calculate(p);before=deepcopy(r);text=contents(export_user_docx(p,r))
 assert r==before
 if case=='pass':assert 'ESCOPO NOMINAL DELIMITADO N + M + V ATENDE' in text
 else:
  assert not r['selected_route_resistance_pass']
  assert 'ESCOPO NOMINAL N + M + V NÃO APROVADO' in text
  for c in display_checks(r):
   if c.get('state')!='atende':assert c['id'] in text
  for missing in r['missing']:assert missing.replace('in-plane','no plano da placa') in text
