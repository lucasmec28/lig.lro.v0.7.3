"""Cortante pelos chumbadores: comparação externa vinculada aos dados atuais."""
from dataclasses import replace
from pathlib import Path
from io import BytesIO
import json,zipfile
import pytest
from streamlit.testing.v1 import AppTest
from lro.base_plate import BasePlate,evaluate,presets
from lro.base_plate_report import create_report

BASE=replace(presets()['Chumbadores · resistência externa'],V=10000.,
             anchor_shear_rd=15000.,anchor_shear_ref='MC CH01: grupo instalado e combinação N-M-V')


def confirmed(c=BASE):return replace(c,anchor_shear_confirmation=c.anchor_shear_signature)


def test_missing_documented_data_or_applicability_is_pending_without_blocking_nm():
    for c in (BASE,replace(BASE,anchor_shear_rd=0.),replace(BASE,anchor_shear_ref='')):
        r=evaluate(c)
        assert r.geometry and r.geometry['case']=='C1'
        assert r.component_status=='VERIFICAÇÃO DO CORTANTE COM DADOS PENDENTES'
        assert not any(x.id=='bp_shear_anchors_external' for x in r.checks)
        assert any(x.id=='bp_plate_contact' for x in r.checks)


def test_anchor_capacity_is_total_documented_not_additive_or_steel_derived():
    c=confirmed();r=evaluate(c)
    row=next(x for x in r.checks if x.id=='bp_shear_anchors_external')
    assert row.demand==10000. and row.resistance==15000.
    assert r.geometry['delta_M']==0 and r.geometry['M_effective']==c.M
    assert r.geometry['shear_rd']==15000. and r.geometry['friction_rd']>0
    assert not any(x.id in ('bp_shear','bp_shear_external') for x in r.checks)
    assert any(i.severity=='pending' and 'tração–cisalhamento' in i.text for i in r.issues)
    assert 'A COMPLEMENTAR' in r.status
    c=confirmed(replace(BASE,anchor_shear_rd=5000.));r=evaluate(c)
    assert not next(x for x in r.checks if x.id=='bp_shear_anchors_external').passed

@pytest.mark.parametrize('changes',[{'N':149000.},{'M':1e6},{'V':-10000.},{'tp':25.4},
    {'a1':45.},{'a2':90.},{'db':25.4},{'fck':25.},{'grout_t':50.},
    {'grout_fck':80.},{'plate_steel':'ASTM A572 Gr.50'},
    {'anchor_shear_rd':18000.},{'anchor_shear_ref':'MC revisão 2'},
    {'column':replace(BASE.column,tf=6.)}])
def test_material_data_changes_invalidate_confirmation(changes):
    c=replace(confirmed(),**changes)
    assert not c.anchor_capacity_confirmed
    r=evaluate(c)
    assert any(i.severity=='pending' and i.origin=='data' for i in r.issues)
    assert not any(x.id=='bp_shear_anchors_external' for x in r.checks)


def test_json_preserves_current_confirmation_not_cosmetics_or_float_noise():
    c=confirmed()
    c=BasePlate.from_dict(json.loads(json.dumps(c.to_dict())))
    assert c.anchor_capacity_confirmed
    assert replace(c,project='Novo título',notes='Nota editorial').anchor_capacity_confirmed
    assert replace(c,N=c.N+1e-10).anchor_capacity_confirmed
    assert not replace(c,V=-c.V).anchor_capacity_confirmed


def test_anchor_and_device_capacity_never_leak_between_mechanisms():
    c=confirmed(replace(BASE,external_shear_rd=900000.,external_shear_ref='MC CHAVE'))
    assert evaluate(c).geometry['shear_rd']==15000.
    assert evaluate(replace(c,shear_path='external')).geometry['shear_rd']==900000.
    old=BASE.to_dict();old['connection'].pop('shear_path')
    assert BasePlate.from_dict(old).shear_path=='friction'


def test_anchor_word_scope_and_confirmation_status():
    for c in (BASE,confirmed()):
        data=create_report(c,evaluate(c))
        with zipfile.ZipFile(BytesIO(data)) as z:xml=z.read('word/document.xml').decode()
        assert 'Cortante pelos próprios chumbadores' in xml
        assert 'interação tração–cisalhamento' in xml
        assert 'não são calculados neste módulo' in xml
        assert ('confirmada pelo usuário' if c.anchor_capacity_confirmed else 'PENDENTE') in xml


def test_three_paths_default_anchors_and_ui_applicability_invalidation():
    app=Path(__file__).resolve().parents[1]/'app.py'
    at=AppTest.from_file(str(app),default_timeout=60).run()
    at.selectbox(key='connection_family').set_value('Placa de base · Tipo 1').run()
    assert not at.exception and at.selectbox(key='bp_shear_mechanism').value=='anchors'
    assert len(at.selectbox(key='bp_shear_mechanism').options)==3
    at.number_input(key='bp_anchor_shear_kgf').set_value(16000.).run()
    at.text_input(key='bp_anchor_shear_ref').set_value('MC CH01 grupo e combinação atual').run()
    cb=lambda:next(x for x in at.checkbox if x.key.startswith('bp_anchor_confirm_'))
    assert not cb().value
    cb().check().run()
    assert not at.exception
    assert BasePlate.from_dict(at.session_state['_base_plate_project']).anchor_capacity_confirmed
    at.text_input(key='bp_project').set_value('Título sem mudança estrutural').run()
    assert cb().value
    at.number_input(key='bp_V_kgf').set_value(900.).run()
    assert not cb().value
    assert any('DADOS PENDENTES' in x.value for x in at.warning)
    cb().check().run()
    at.selectbox(key='bp_shear_mechanism').set_value('device').run()
    assert at.selectbox(key='bp_device_model').value=='plate'
    at.selectbox(key='bp_device_model').set_value('external').run()
    assert at.number_input(key='bp_external_shear_kgf').value==0.
    at.number_input(key='bp_external_shear_kgf').set_value(5000.).run()
    at.text_input(key='bp_external_shear_ref').set_value('MC CHAVE').run()
    at.selectbox(key='bp_shear_mechanism').set_value('anchors').run()
    assert at.number_input(key='bp_anchor_shear_kgf').value==16000.
    assert at.text_input(key='bp_anchor_shear_ref').value=='MC CH01 grupo e combinação atual'
    assert cb().value
    next(x for x in at.button if x.label=='Gerar memória da placa de base').click().run()
    assert at.session_state['bp_report'][2][:2]==b'PK'
    at.number_input(key='bp_fck').set_value(25.).run()
    assert not cb().value and 'bp_report' not in at.session_state


def test_import_pending_same_signature_clears_previously_checked_applicability():
    app=Path(__file__).resolve().parents[1]/'app.py'
    at=AppTest.from_file(str(app),default_timeout=60).run()
    at.selectbox(key='connection_family').set_value('Placa de base · Tipo 1').run()
    at.number_input(key='bp_anchor_shear_kgf').set_value(10000.).run()
    at.text_input(key='bp_anchor_shear_ref').set_value('MC CH01').run()
    next(x for x in at.checkbox if x.key.startswith('bp_anchor_confirm_')).check().run()
    c=BasePlate.from_dict(at.session_state['_base_plate_project'])
    assert c.anchor_capacity_confirmed
    pending=replace(c,anchor_shear_confirmation='')
    at.get('file_uploader')[0].upload('pendente.json',json.dumps(pending.to_dict()).encode(),'application/json').run()
    next(x for x in at.button if x.label=='Abrir placa de base JSON').click().run()
    assert not at.exception
    assert not next(x for x in at.checkbox if x.key.startswith('bp_anchor_confirm_')).value
    assert not BasePlate.from_dict(at.session_state['_base_plate_project']).anchor_capacity_confirmed
    assert any('DADOS PENDENTES' in x.value for x in at.warning)
