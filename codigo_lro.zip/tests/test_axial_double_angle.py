"""Independent finite 2L fixtures; no other production engine is an oracle.

Numeric targets established in next_connection_scope before this implementation.
"""
from copy import deepcopy
from dataclasses import fields, replace
import json
import math
from pathlib import Path

import pytest

from lro.axial_double_angle import (
    AxialDoubleAngle, BOLTS, CONNECTION_TYPE, HOLES, bearing_resistance,
    block_resistance, bolt_shear_resistance, evaluate, input_errors, presets,
    terminal_resultants,
)


def fixture(**changes):
    return replace(AxialDoubleAngle(), **changes)


def row(result, primitive, case='actual'):
    return next(r for r in result['checks'] if r['id'] == primitive + '__' + case)


def finite_tree(value):
    if isinstance(value, dict):
        for child in value.values():
            finite_tree(child)
    elif isinstance(value, (list, tuple)):
        for child in value:
            finite_tree(child)
    elif isinstance(value, (float, int)):
        assert math.isfinite(value)


def test_current_independent_complete_fixture():
    r = evaluate(fixture())
    assert r['global_pass']
    assert r['status'] == 'COMPLETE_CHECKS_PASS_WITHIN_SCOPE'
    assert r['summary']['complete_checks']
    assert len(r['checks']) == 39
    assert not r['issues']
    s = r['sections']['angle_pair']
    assert s['Ag'] == 1858
    assert s['An'] == pytest.approx(1629.4)
    assert s['Ct'] == pytest.approx(.787)
    assert s['Ae'] == pytest.approx(1282.3378)
    assert row(r, 'angle_gross_yield')['resistance'] == pytest.approx(422272.727273)
    assert row(r, 'angle_effective_net_fracture')['resistance'] == pytest.approx(379951.940741)
    assert r['sections']['plate']['Ag'] == 1250
    assert r['sections']['plate']['An'] == 1025
    assert row(r, 'plate_gross_yield')['resistance'] == pytest.approx(284090.909091)
    assert row(r, 'plate_net_fracture')['resistance'] == pytest.approx(303703.703704)
    assert r['summary']['governing_capacity_N'] == pytest.approx(284090.909091)
    assert r['summary']['utilization'] == pytest.approx(.704)
    assert r['summary']['governing_id'] == 'plate_gross_yield__actual'
    assert r['summary']['governing_ties'] == ['plate_gross_yield__actual', 'plate_terminal_yield__actual']
    assert r['bolts']['compatible_uniform_group_capacity_N'] == pytest.approx(333762.803517)
    finite_tree(r)
    json.dumps(r, allow_nan=False)


def test_bolt_bearing_oracle_file_and_opposite_loaded_free_ends():
    oracle = json.loads((Path(__file__).resolve().parents[3] / 'next_connection_scope/bolt_bearing_oracle.json').read_text())
    r = evaluate(fixture())
    assert r['geometry']['bolt_x'] == [35, 85, 135]
    assert r['geometry']['angle_end_x'] == 170
    assert r['geometry']['terminal_x'] == 200
    assert r['geometry']['angle_heel_y'] == 15
    assert r['geometry']['angle_toe_y'] == 91
    assert r['geometry']['grip'] == pytest.approx(25.2)
    for witness in oracle['row_results']:
        i = witness['bolt']
        for plane in [1, 2]:
            b = row(r, f'bolt_{i}_plane_{plane}')
            assert b['demand'] == pytest.approx(witness['each_plane_demand_N'])
            assert b['resistance'] == pytest.approx(oracle['each_threaded_plane_Rd_N'])
        for angle in [1, 2]:
            a = row(r, f'angle_{angle}_bearing_{i}')
            assert a['demand'] == pytest.approx(witness['each_angle_bearing_demand_N'])
            assert a['resistance'] == pytest.approx(witness['each_angle_bearing_Rd_N'])
            assert a['clear_distance'] == pytest.approx(witness['angle_lc_mm'])
            assert a['loaded_direction'] == '+x'
        p = row(r, f'plate_bearing_{i}')
        assert p['demand'] == pytest.approx(witness['plate_bearing_demand_N'])
        assert p['resistance'] == pytest.approx(witness['plate_bearing_Rd_N'])
        assert p['clear_distance'] == pytest.approx(witness['plate_lc_mm'])
        assert p['thickness'] == 12.5
        assert p['loaded_direction'] == '-x'
    assert row(r, 'plate_bearing_1')['path'] == 'loaded_free_end'
    assert row(r, 'angle_1_bearing_3')['path'] == 'loaded_free_end'


def test_all_partial_angle_blocks_match_independent_areas_and_subsets():
    r = evaluate(fixture())
    witnesses = [(222.25, 165.1, 84901.85185185185),
                 (539.75, 368.3, 120179.62962962962),
                 (857.25, 571.5, 155457.4074074074)]
    for side in [1, 2]:
        for k, (Agv, Anv, resistance) in enumerate(witnesses, 1):
            b = row(r, f'angle_{side}_block_toe_k{k}')
            assert b['areas'] == pytest.approx({'Agv': Agv, 'Anv': Anv, 'Ant': 203.2})
            assert b['resistance'] == pytest.approx(resistance)
            assert b['demand'] == pytest.approx(k * 200000 / 6)
            assert b['bolt_indices'] == list(range(4 - k, 4))
            assert b['loaded_direction'] == '+x'
            assert b['Cts'] == 1
            assert b['physical_shear_surfaces'] == 1
            assert not b['heel_is_free_edge']
            assert b['shear_yield_branch_N'] < b['shear_fracture_branch_N']
            far = row(r, f'angle_{side}_block_far_toe_unfolded_k{k}')
            assert far['gross_tension_width'] == pytest.approx(35 + 76 - 6.35)
            assert far['net_tension_width'] == pytest.approx(95.65)
            assert far['resistance'] > b['resistance']
            assert far['bolt_indices'] == b['bolt_indices']
    assert row(r, 'angle_1_block_toe_k3')['equivalent_capacity_N'] == pytest.approx(310914.8148148148)


def test_plate_blocks_each_side_full_force_not_added_or_halved():
    r = evaluate(fixture())
    witnesses = [(437.5, 325, 200462.96296296296),
                 (1062.5, 725, 269907.4074074074),
                 (1687.5, 1125, 339351.85185185185)]
    for side in ['lower_side', 'upper_side']:
        for k, (Agv, Anv, capacity) in enumerate(witnesses, 1):
            b = row(r, f'plate_block_{side}_k{k}')
            assert b['areas'] == pytest.approx({'Agv': Agv, 'Anv': Anv, 'Ant': 512.5})
            assert b['resistance'] == pytest.approx(capacity)
            assert b['demand'] == pytest.approx(k * 200000 / 3)
            assert b['bolt_indices'] == list(range(1, k + 1))
            assert b['loaded_direction'] == '-x'
            assert b['physical_shear_surfaces'] == 1
            assert b['demand_basis'] == 'full_enclosed_bolt_force_alternative_side_paths'
    blocks = [x for x in r['checks'] if x['component'] == 'plate' and x['mechanism'] == 'block_tearout']
    assert len(blocks) == 6


def test_actual_force_balance_and_terminal_transport_sign():
    c = fixture()
    r = evaluate(c)
    m = r['load_model']
    assert m['angle_1_bolt_force_sum_x'] + m['angle_2_bolt_force_sum_x'] == -m['plate_bolt_force_sum_x'] == 200000
    assert m['terminal_actual']['N'] + m['plate_bolt_force_sum_x'] == 0
    assert m['terminal_actual']['M'] == 0
    t = terminal_resultants(c, reference_x=0, reference_y=20)
    assert t['N'] == 200000 and t['V'] == 0
    assert t['M'] == -6000000
    assert terminal_resultants(c, reference_y=80)['M'] == 6000000
    assert terminal_resultants(c, reference_x=-100)['M'] == 0
    assert t['x'] == 200 and t['y'] == 50
    assert t['valid_for_input']


def test_gauge_shift_changes_geometry_not_nominal_axis_or_direct_bolt_forces():
    a, b = evaluate(fixture()), evaluate(fixture(gauge=45))
    assert a['geometry']['physical_CG_offset_from_bolt_axis'] == pytest.approx(-13.7)
    assert b['geometry']['physical_CG_offset_from_bolt_axis'] == pytest.approx(-23.7)
    assert a['load_model']['terminal_actual'] == b['load_model']['terminal_actual']
    assert a['sections']['angle_pair']['Ct'] == b['sections']['angle_pair']['Ct']
    assert row(a, 'bolt_1_plane_1')['demand'] == row(b, 'bolt_1_plane_1')['demand']
    assert row(b, 'angle_1_block_toe_k3')['resistance'] < row(a, 'angle_1_block_toe_k3')['resistance']


def test_current_Ct_floor_and_no_old_point_nine_cap():
    short = evaluate(fixture(n=2, pitch=30))
    s = short['sections']['angle_pair']
    assert s['Ct_raw'] == pytest.approx(.29)
    assert s['Ac'] == 929 and s['Ct_floor'] == .5 and s['Ct'] == .5
    long = evaluate(fixture(n=21, pitch=50))
    assert long['global_pass']  # no imported splice-specific 950 mm veto
    assert long['geometry']['lc'] == 1000
    assert long['sections']['angle_pair']['Ct'] == pytest.approx(.9787)
    assert row(long, 'bolt_1_plane_1')['demand'] == pytest.approx(200000 / 42)


def test_real_plate_no_splice_cap_no_whitmore_or_width_normalization():
    r = evaluate(fixture(plate_width=200))
    assert r['sections']['plate']['real_width'] == 200
    assert r['sections']['plate']['An'] == (200 - 18) * 12.5
    assert r['sections']['plate']['Ae'] > .85 * r['sections']['plate']['Ag']
    assert not r['sections']['plate']['splice_cap_applied']
    assert not any('whitmore' in c['id'].lower() for c in r['checks'])


def test_drilling_deduction_changes_sections_and_blocks_not_physical_bearing():
    drilled, punched = evaluate(fixture()), evaluate(fixture(drilled=False))
    assert punched['geometry']['hole_diameter'] == 18
    assert punched['geometry']['net_hole_diameter'] == 20
    assert punched['sections']['angle_pair']['An'] == pytest.approx(1604)
    assert punched['sections']['plate']['An'] == 1000
    assert row(punched, 'angle_1_block_toe_k3')['resistance'] < row(drilled, 'angle_1_block_toe_k3')['resistance']
    assert row(punched, 'plate_bearing_1')['resistance'] == row(drilled, 'plate_bearing_1')['resistance']


def test_mixed_threads_never_average_equal_plane_demands():
    r = evaluate(fixture(threads_excluded_1=True, N=340000))
    p1, p2 = row(r, 'bolt_1_plane_1'), row(r, 'bolt_1_plane_2')
    assert p1['coefficient'] == .56 and p2['coefficient'] == .45
    assert p1['resistance'] == pytest.approx(69224.87776656763)
    assert p2['resistance'] == pytest.approx(55627.13391956326)
    assert p1['demand'] == p2['demand'] == pytest.approx(340000 / 6)
    assert p1['status'] == 'PASS' and p2['status'] == 'FAIL'
    assert r['bolts']['sum_group_capacity_N'] > 340000
    assert r['bolts']['compatible_uniform_group_capacity_N'] == pytest.approx(333762.803517)


def test_grip_factor_and_high_strength_pretension_exemption():
    c = fixture(plate_t=90)
    r, exempt = evaluate(c), evaluate(replace(c, pretensioned=True))
    factor = 1 - .01 * (102.7 - 80) / 1.5
    assert r['geometry']['grip_factor'] == pytest.approx(factor)
    assert row(r, 'bolt_1_plane_1')['resistance'] == pytest.approx(55627.13391956326 * factor)
    assert exempt['geometry']['grip_factor'] == 1
    assert exempt['geometry']['grip_pretension_exemption']
    assert row(exempt, 'bolt_1_plane_1')['resistance'] == pytest.approx(55627.13391956326)
    exhausted = evaluate(fixture(plate_t=250))
    assert not exhausted['global_pass']
    assert row(exhausted, 'bolt_1_plane_1')['status'] == 'FAIL'
    assert row(exhausted, 'bolt_1_plane_1')['resistance'] == 0


def test_common_bolt_threads_exclusion_and_pretension_never_raise_coefficient():
    c = fixture(bolt='ASTM A307', db=15.875, plate_t=90, threads_excluded_1=True, pretensioned=True)
    r = evaluate(c)
    assert not r['global_pass']
    assert row(r, 'bolt_1_plane_1')['coefficient'] == .45
    assert row(r, 'bolt_1_plane_2')['coefficient'] == .45
    assert not r['geometry']['grip_pretension_exemption']
    assert r['geometry']['grip_factor'] < 1
    assert bolt_shear_resistance(16, 415, True, common=True) == bolt_shear_resistance(16, 415, False, common=True)


def test_zero_actual_kept_with_separate_minimum_not_added():
    r = evaluate(fixture(N=0))
    assert r['global_pass']
    assert [(c['id'], c['N']) for c in r['cases']] == [('actual', 0), ('minimum_45kN', 45000)]
    assert len(r['checks']) == 78
    assert row(r, 'plate_gross_yield')['demand'] == row(r, 'plate_gross_yield')['utilization'] == 0
    assert row(r, 'plate_gross_yield', 'minimum_45kN')['demand'] == 45000
    assert r['load_model']['N_actual'] == 0 and r['load_model']['N_design'] == 45000
    assert r['load_model']['terminal_actual']['N'] == 0


def test_recommendation_keeps_three_separate_candidate_cases_and_source():
    r = evaluate(fixture(N=10000, recommend_half_capacity=True))
    assert [c['id'] for c in r['cases']] == ['actual', 'minimum_45kN', 'recommended_half']
    assert [c['N'] for c in r['cases']] == pytest.approx([10000, 45000, 189975.97037037035])
    assert r['cases'][2]['member_governing'] == 'angle_effective_net_fracture'
    assert r['load_model']['N_actual'] == 10000
    assert r['load_model']['N_design'] == pytest.approx(189975.97037037035)
    assert len(r['checks']) == 117


def test_applicable_minimum_cannot_be_disabled_without_modeled_exemption():
    r = evaluate(fixture(N=0, minimum_force=False))
    assert r['status'] == 'OUTSIDE_SCOPE'
    assert not r['global_pass']
    assert r['cases'] == [{'id': 'actual', 'label': 'N real informado', 'N': 0}]
    assert row(r, 'plate_gross_yield')['demand'] == 0
    assert not any(i['severity'] == 'numerical_failure' for i in r['issues'])
    assert evaluate(fixture(N=45000, minimum_force=False))['global_pass']


@pytest.mark.parametrize('changes,mechanism', [
    ({'plate_t': 4, 'N': 100000}, 'plate_gross_yield'),
    ({'n': 2, 'N': 230000}, 'bolt_1_plane_1'),
    ({'gauge': 53, 'N': 250000}, 'angle_1_block_toe_k3'),
    ({'n': 2, 'plate_end': 41, 'plate_t': 8, 'N': 179000}, 'plate_block_lower_side_k2'),
    ({'plate_end': 22, 'N': 180000}, 'plate_bearing_1'),
    ({'angle_end': 22, 'N': 180000}, 'angle_1_bearing_3'),
    ({'plate_width': 44, 'plate_t': 30, 'N': 240000}, 'plate_net_fracture'),
])
def test_independently_governing_resistance_modes(changes, mechanism):
    r = evaluate(fixture(**changes))
    assert r['summary']['complete_checks']
    assert r['summary']['governing_id'] == mechanism + '__actual'
    assert row(r, mechanism)['status'] == 'FAIL'
    assert not r['global_pass']
    assert not any(i['severity'] == 'numerical_failure' for i in r['issues'])


def test_detail_only_failure_does_not_hide_complete_capacity_checks():
    r = evaluate(fixture(tool_radius=24))
    assert r['status'] == 'DETAILING_FAIL'
    assert r['summary']['complete_checks']
    assert all(c['status'] == 'PASS' for c in r['checks'])
    assert any(i['id'] == 'root_tool_access' for i in r['issues'])
    assert r['summary']['governing_capacity_N'] == pytest.approx(284090.909091)


def test_geometry_and_outside_flags_do_not_hide_resistance_overload():
    r = evaluate(fixture(gauge=20, N=900000, static=False))
    assert not r['global_pass']
    assert any(i['severity'] == 'invalid_geometry' for i in r['issues'])
    assert any(i['severity'] == 'outside_scope' for i in r['issues'])
    assert row(r, 'plate_gross_yield')['status'] == 'FAIL'
    assert len(r['checks']) == 39


@pytest.mark.parametrize('changes', [
    {'N': -1}, {'V': 1}, {'M': 1}, {'torsion': 1}, {'static': False},
    {'normal_combination': False}, {'symmetric': False}, {'angle_count': 1},
    {'angle_count': 3}, {'n': 1}, {'exposure': 'underwater'},
    {'plate_steel': 'ASTM A992'}, {'angle_steel': 'USI-CIVIL 350'},
])
def test_outside_domain_actions_remain_explicit(changes):
    r = evaluate(fixture(**changes))
    assert r['status'] == 'OUTSIDE_SCOPE'
    assert not r['global_pass']
    assert not r['summary']['complete_checks']
    assert any(i['severity'] == 'outside_scope' for i in r['issues'])
    assert not any(i['severity'] == 'numerical_failure' for i in r['issues'])
    if 'N' in changes:
        assert r['load_model']['N_actual'] == -1
    if any(k in changes for k in ['V', 'M', 'torsion']):
        assert not r['load_model']['terminal_actions_valid_for_actual_input']
        for k, v in changes.items():
            assert r['load_model']['actual_actions'][k] == v
    finite_tree(r)


@pytest.mark.parametrize('changes', [
    {'N': math.nan}, {'N': math.inf}, {'N': True}, {'N': '200000'},
    {'pitch': 0}, {'terminal_extension': 0}, {'terminal_extension': -100},
    {'n': True}, {'n': 3.0}, {'n': 0}, {'n': 101}, {'angle_count': False},
    {'drilled': 1}, {'pretensioned': 'false'}, {'t': []}, {'notes': {}},
    {'db': None}, {'Ag': 10 ** 1000},
])
def test_invalid_input_types_and_nonfinite_are_clean_diagnostics(changes):
    c = fixture(**changes)
    assert input_errors(c)
    r = evaluate(c)
    assert r['status'] == 'INVALID_INPUT' and not r['global_pass']
    assert r['checks'] == []
    finite_tree(r)
    json.dumps(r, allow_nan=False)
    with pytest.raises(ValueError):
        c.to_dict()


def test_unknown_discrete_diameter_and_material_never_receive_defaults():
    for changes in [{'db': 16.01}, {'bolt': 'unknown'}, {'plate_steel': 'unknown'}]:
        r = evaluate(fixture(**changes))
        assert not r['global_pass'] and r['status'] == 'OUTSIDE_SCOPE'
        assert r['checks'] == []
    assert fixture(db=15.875).hole_diameter == 17.4625
    assert fixture(db=16).hole_diameter == 18


@pytest.mark.parametrize('changes', [
    {'leg': 1e308}, {'pitch': 1e308}, {'plate_width': 1e308},
    {'Ag': 1e308}, {'t': 1e200}, {'plate_t': 1e308}, {'N': 1e308},
    {'leg': 5e-324}, {'plate_t': 5e-324}, {'Ag': 5e-324},
])
def test_finite_extremes_never_crash_or_approve(changes):
    r = evaluate(fixture(**changes))
    assert not r['global_pass']
    assert r['issues'] or any(x['status'] == 'FAIL' for x in r['checks'])
    finite_tree(r)
    json.dumps(r, allow_nan=False)


def test_nonpositive_net_areas_are_visible_not_zero_clamped():
    r = evaluate(fixture(plate_width=17))
    assert r['status'] == 'NUMERICAL_FAILURE'
    p = row(r, 'plate_net_fracture')
    assert p['areas']['An'] == -12.5
    assert p['resistance'] < 0 and p['utilization'] is None
    assert not p['numerical_valid'] and p['status'] == 'FAIL'
    assert row(r, 'plate_gross_yield')['status'] == 'FAIL'
    assert r['summary']['numerical_failures_visible']


def test_custom_properties_preserved_and_checked_not_replaced_by_geometry():
    c = fixture(profile_name='Custom sourced equal leg', profile_source='Independent survey', Ag=1860, ec=22)
    r = evaluate(c)
    assert r['global_pass']
    assert r['sections']['angle_pair']['Ag'] == 1860
    assert r['sections']['angle_pair']['ec'] == 22
    assert r['sections']['angle_pair']['profile_source'] == 'Independent survey'
    assert r['geometry']['profile_sharp_corner_comparator'] != 1860
    assert not evaluate(fixture(Ag=900))['global_pass']
    assert not evaluate(fixture(ec=60))['global_pass']
    assert not evaluate(fixture(ec=0))['global_pass']


def test_native_exact_roundtrip_and_no_stale_computed_state_import():
    c = fixture(N=34567, gauge=40, notes='Round-trip', recommend_half_capacity=True)
    data = json.loads(json.dumps(c.to_dict(), allow_nan=False))
    assert AxialDoubleAngle.from_dict(data) == c
    assert set(data['connection']) == {f.name for f in fields(AxialDoubleAngle)}
    assert data['connection_type'] == CONNECTION_TYPE
    for mutate in [
        lambda d: d.update(result={'global_pass': True}),
        lambda d: d['connection'].update(unknown=1),
        lambda d: d['connection'].pop('N'),
        lambda d: d.update(schema_version=True),
        lambda d: d.update(component_version='old'),
        lambda d: d.update(connection_type='double_angle_r016_bolted_shear'),
        lambda d: d['units'].update(force='kN'),
        lambda d: d['fixed_assumptions'].update(shear_planes=1),
        lambda d: d['fixed_assumptions'].update(shared_bolts=1),
        lambda d: d['connection'].update(N=math.inf),
        lambda d: d['connection'].update(n=3.0),
        lambda d: d['connection'].update(drilled=1),
    ]:
        bad = deepcopy(data)
        mutate(bad)
        with pytest.raises(ValueError):
            AxialDoubleAngle.from_dict(bad)
    assert c.N == 34567 and c.gauge == 40


def test_numerical_primitive_equations_independently():
    assert block_resistance(222.25, 165.1, 203.2, 250, 400) == pytest.approx(84901.85185185185)
    assert bearing_resistance(16, 26, 6.35, 400) == pytest.approx(58702.22222222222)
    assert bolt_shear_resistance(16, 830) == pytest.approx(.45 * math.pi * 16 ** 2 / 4 * 830 / 1.35)
    assert all(isinstance(c, AxialDoubleAngle) for c in presets().values())
