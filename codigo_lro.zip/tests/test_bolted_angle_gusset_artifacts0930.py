"""Physical drawings and editable records for the complete one-row bolted route."""
from copy import deepcopy
from dataclasses import replace
from io import BytesIO
from xml.etree import ElementTree as ET
import math
import matplotlib.pyplot as plt
import numpy as np
import pytest
from docx import Document
from lro.bolted_angle_gusset import BoltedAngleGusset, evaluate, presets
from lro.bolted_angle_gusset_drawing import figure, drawing_svg, image_bytes, input_fingerprint
from lro.bolted_angle_gusset_presentation import physical_envelopes
from lro.bolted_angle_gusset_report import create_report


def fixture(**changes):return replace(next(iter(presets().values())),**changes)


def artists(fig):
    return ({x.get_gid():x for ax in fig.axes for x in ax.patches if x.get_gid()},
            {x.get_gid():x for ax in fig.axes for x in ax.lines if x.get_gid()})


def document(blob):
    doc=Document(BytesIO(blob))
    return doc,'\n'.join(p.text for p in doc.paragraphs)+'\n'+'\n'.join(cell.text for table in doc.tables for row in table.rows for cell in row.cells)


@pytest.mark.parametrize('arrangement,count',[('1L',1),('2L-T',2)])
def test_real_holes_shared_bolts_planes_and_common_double_root(arrangement,count):
    c=fixture(arrangement=arrangement);r=evaluate(c);fig=figure(c)
    try:
        patches,lines=artists(fig)
        assert fig._bolted_angle_gusset_result==r
        holes={k:v for k,v in patches.items() if k.startswith('physical_hole_')}
        bolts={k:v for k,v in patches.items() if k.startswith('physical_bolt_')}
        assert len(holes)==len(bolts)==c.n
        for i,point in enumerate(r['geometry']['bolt_centers']):
            assert holes[f'physical_hole_{i+1}'].center==pytest.approx(point)
            assert holes[f'physical_hole_{i+1}'].radius==c.hole_diameter/2
            assert bolts[f'physical_bolt_{i+1}'].radius==c.db/2
        assert len([k for k in lines if k.startswith('shear_plane_')])==count
        assert len([k for k in patches if k.startswith('root_fillet_')])==2
        assert ('angle_outer_free_leg_face_negative' in lines)==(count==2)
        assert all(ax.get_aspect()==1 for ax in fig.axes)
        assert patches['root_single_gusset'].get_width()==c.plate_t
    finally:plt.close(fig)


def test_T_section_heels_aligned_same_direction_and_nominal_unknown_corners():
    c=fixture();fig=figure(c)
    try:
        patches,lines=artists(fig)
        a,b=(lines['angle_outer_free_leg_face_'+face] for face in ('positive','negative'))
        assert a.get_xdata()==pytest.approx(b.get_xdata())
        assert a.get_ydata()==pytest.approx(-b.get_ydata())
        assert a.get_xdata()[0]==-c.gauge
        assert 'nominal_free_inner_face_positive' in lines and 'nominal_free_inner_face_negative' in lines
        assert not any(k.startswith('angle_section_face_') for k in patches)
        svg=drawing_svg(c)
        assert 'raios não publicados' in svg and '12,35 mm' in svg
        assert 'unpublished_heel_face_positive' in svg
    finally:plt.close(fig)


@pytest.mark.parametrize('theta,member',[(80.,'beam'),(90.,'column'),(100.,'beam'),(100.,'column')])
def test_signed_variable_angle_and_root_action_line(theta,member):
    c=fixture(theta_deg=theta,support_member=member);r=evaluate(c);fig=figure(c)
    try:
        patches,lines=artists(fig)
        arc=patches['brace_angle_arc'];line=lines['nominal_force_line']
        assert arc.theta1==0 and arc.theta2==theta
        p=r['geometry']['force_point'];u=r['geometry']['direction']
        offset=p[0]-p[1]*u[0]/u[1]
        assert line.get_xdata()[0]==pytest.approx(offset)
        assert r['root']['M']==pytest.approx(r['root']['N']*offset,abs=1e-6)
        svg=drawing_svg(c)
        assert ('PILAR W' if member=='column' else 'VIGA W') in svg
        if theta!=90:assert 'root_signed_moment' in svg and 'root_signed_shear' in svg
    finally:plt.close(fig)


def test_exports_recalculate_and_retire_forged_pass():
    c=fixture(N=200000.,project='Entrada atual falha na raiz');forged=evaluate(fixture());forged['status']='FORGED_PASS'
    svg=drawing_svg(c,forged);doc,text=document(create_report(c,forged))
    assert 'FORGED_PASS' not in svg+text
    assert input_fingerprint(c) in svg and input_fingerprint(c) in text
    assert evaluate(c)['status'] in text and 'sem conclusão favorável completa' in text
    assert len(doc.inline_shapes)==1 and doc.element.xpath('.//m:oMath') and doc.element.xpath('.//m:rad')
    assert image_bytes(c).startswith(b'\x89PNG')


@pytest.mark.parametrize('changes',[dict(plate_width=-1.),dict(arrangement='opposed_vertices'),dict(support_face='web')])
def test_unqualified_geometry_does_not_substitute_accepted_drawing(changes):
    svg=drawing_svg(fixture(**changes),evaluate(fixture()))
    assert 'diagnostic_only' in svg and 'physical_hole_1' not in svg


def test_zero_real_load_and_separate_minimum_are_preserved():
    c=fixture(N=0.);r=evaluate(c);svg=drawing_svg(c)
    assert r['cases'][0]['N']==0
    assert 'N total=0 kN' in svg and 'actual_force_arrow' not in svg and 'gusset_hole_force_' not in svg
    env=physical_envelopes(r)
    assert all(e['actual_utilization']==0 for e in env)
    assert any(e['utilization']>0 for e in env)


def test_envelopes_keep_every_check_and_exact_ties_without_mutating():
    r=evaluate(fixture());before=deepcopy(r);env=physical_envelopes(r)
    assert sorted(x['id'] for e in env for x in e['members'])==sorted(x['id'] for x in r['checks'])
    for e in env:
        assert e['utilization']==max(x['utilization'] for x in e['members'])
        assert set(e['governing_ids'])=={x['id'] for x in e['members'] if x['utilization']==e['utilization']}
    env[0]['members'][0]['id']='mutated';assert r==before


def test_word_distinguishes_actual_physical_model_and_supplemental_screen():
    doc,text=document(create_report(fixture()))
    for term in ('N/2 por L','N/(2n)','N/n','45 kN aplica-se uma vez','seção líquida','rotação rígida',
                 'cinco registros'.capitalize(),'triagem nominal','NÃO solução exata','Whitmore','Cts=0,5',
                 'qpico/(2tf)','6M/B','Mcentroide=Mraiz','não é raio','dois filetes','opostos (><)'):
        assert term.casefold() in text.casefold(),term
    assert 'An = Ag − dn t' in ''.join(doc.element.xpath('.//m:t/text()'))
    _,single=document(create_report(fixture(arrangement='1L')))
    assert '1L: N na cantoneira' in single and 'não se alega cancelamento' in single


def test_detailed_word_preserves_all_check_and_case_records():
    c=fixture(minimum_force=False);r=evaluate(c);_,text=document(create_report(c,detailed=True))
    for row in r['checks']:assert row['id'] in text
    for case in r['cases']:
        assert case['id'] in text
        for key in case:assert key in text
    assert 'Testemunhos integrais dos casos' in text
