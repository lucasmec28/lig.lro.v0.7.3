"""Native R017 UI and persistence regression: geometry and restraint evidence."""
import json
from dataclasses import fields, replace
from pathlib import Path

import pytest
from streamlit.testing.v1 import AppTest
from lro.coped_double_angle import CopedDoubleAngle, FAMILY, HOLES, presets
from lro.models import KGF

APP = Path(__file__).resolve().parents[1] / 'app.py'
HARNESS = """
import streamlit as st
from lro.coped_double_angle import FAMILY
from lro.double_angle import FAMILY as R016
from lro.welded_double_angle import FAMILY as R015
family = st.sidebar.selectbox('Tipo de ligação', [FAMILY, R016, R015, 'Single plate'], key='connection_family')
if family == FAMILY:
    from lro.coped_double_angle_ui import render
    render()
elif family == R016:
    from lro.double_angle_ui import render
    render()
elif family == R015:
    from lro.welded_double_angle_ui import render
    render()
else:
    st.write('Outra família')
"""


def base(**changes):
    return replace(next(iter(presets().values())), **changes)


def open_app():
    at = AppTest.from_string(HARNESS, default_timeout=60).run()
    assert not at.exception
    return at


def button(at, label):
    return next(item for item in at.button if item.label == label)


def upload(at, c):
    data = c.to_dict() if hasattr(c, 'to_dict') else c
    at.get('file_uploader')[0].upload('R017.json', json.dumps(data).encode(), 'application/json').run()
    button(at, 'Carregar R017').click().run()
    assert not at.exception
    return at


def qualify(at, side):
    at.text_input(key='ca_restraint_' + side + '_system').set_value('Travamento independente de ensaio').run()
    at.text_input(key='ca_restraint_' + side + '_ref').set_value('MC-TESTE-EXTERNO: resistência e rigidez verificadas').run()
    c = at.session_state['_coped_double_angle_project']['connection']
    at.number_input(key='ca_restraint_' + side + '_x').set_value(c['gap'] + c['c_' + side]).run()
    assert not at.exception
    return at


def test_native_schema_all_fields_and_structured_evidence():
    at = open_app(); c = base(); r = at.session_state['_coped_double_angle_result']
    assert at.session_state['_coped_double_angle_project'] == c.to_dict()
    assert r['checks'] and r['geometry']['valid']
    assert r['status'] == 'ENGINEERING_MODEL_PENDING' and not r['local_pass'] and not r['global_pass']
    assert not at.success
    keys = {item.key for collection in (at.number_input, at.selectbox, at.checkbox, at.text_input, at.text_area) for item in collection}
    for f in fields(CopedDoubleAngle):
        if f.name not in ('beam', 'support', 'V', 'N', 'M', 'torsion', 'angle_root_source', 'angle_root_confirmed'):
            assert 'ca_' + f.name in keys
    assert not any(key and (key.startswith('ca_weld') or key.startswith('ca_support_edge')) for key in keys)
    assert not any(item.key and 'restraint' in item.key for item in at.checkbox)
    assert at.number_input(key='ca_r_top').value == 15.
    assert at.number_input(key='ca_r_bottom').value == 15.
    assert at.selectbox(key='ca_cope').value == 'equal_double'
    assert any('EXTERNA' in item.value for item in at.caption)
    assert not button(at, 'Gerar memória R017').disabled


def test_restraint_switches_with_load_and_never_approves_global_members():
    at = qualify(open_app(), 'top')
    r = at.session_state['_coped_double_angle_result']
    assert r['local_pass'] is True and r['global_pass'] is False
    assert len(at.success) == 1 and 'LOCAL' in at.success[0].value
    at.number_input(key='ca_V_kgf').set_value(-10000.).run()
    r = at.session_state['_coped_double_angle_result']
    assert r['load_model']['Vsd_N'] == -10000. * KGF
    assert not r['local_pass'] and not at.success
    at = qualify(at, 'bottom')
    assert at.session_state['_coped_double_angle_result']['local_pass'] is True
    at.number_input(key='ca_V_kgf').set_value(0.).run()
    assert at.session_state['_coped_double_angle_result']['local_pass'] is True
    at.text_input(key='ca_restraint_top_ref').set_value('').run()
    assert not at.session_state['_coped_double_angle_result']['local_pass']
    assert not at.success


def test_actual_geometry_change_invalidates_matching_restraint_and_report():
    at = qualify(open_app(), 'top')
    button(at, 'Gerar memória R017').click().run()
    assert at.session_state['ca_report'][2].startswith(b'PK')
    at.number_input(key='ca_c_top').set_value(131.).run()
    assert not at.exception and 'ca_report' not in at.session_state
    assert not at.session_state['_coped_double_angle_result']['local_pass']
    at.number_input(key='ca_c_bottom').set_value(131.).run()
    assert not at.exception and not at.success
    assert at.session_state['_coped_double_angle_project']['connection']['restraint_top_x'] == 140.


@pytest.mark.parametrize('key,field,unit', [('ca_N_kgf', 'N', KGF), ('ca_M_kgfm', 'M', KGF*1000), ('ca_torsion_kgfm', 'torsion', KGF*1000)])
def test_unsupported_actions_are_preserved(key, field, unit):
    at = open_app(); at.number_input(key=key).set_value(-1.).run()
    assert not at.exception
    assert at.session_state['_coped_double_angle_project']['connection'][field] == -unit
    assert at.session_state['_coped_double_angle_result']['status'] == 'OUTSIDE_R017_SCOPE'
    assert not at.success and button(at, 'Gerar memória R017').disabled


def test_exact_import_roundtrip_and_independent_custom_profiles():
    c = base(project='Projeto importado', V=-12345.6789, N=123.456, M=-34567.891,
             beam=replace(base().beam, tw=7.25, source='Levantamento viga'),
             support=replace(base().support, tw=8.2, source='Levantamento apoio'),
             c_top=131.25, c_bottom=131.25, beam_level=-1.25, notes='Ações preservadas.',
             restraint_bottom_system='Sistema externo real', restraint_bottom_ref='MC-XYZ', restraint_bottom_x=141.25)
    at = upload(open_app(), c)
    assert at.session_state['_coped_double_angle_project'] == c.to_dict()
    assert at.text_input(key='ca_beam_source').value == 'Levantamento viga'
    assert at.text_input(key='ca_support_source').value == 'Levantamento apoio'
    at.selectbox(key='connection_family').set_value('Single plate').run()
    at.selectbox(key='connection_family').set_value(FAMILY).run()
    assert not at.exception and at.session_state['_coped_double_angle_project'] == c.to_dict()


def test_family_switch_keeps_R015_R016_R017_independent():
    from lro.double_angle import FAMILY as R016
    from lro.welded_double_angle import FAMILY as R015
    at = open_app(); at.number_input(key='ca_c_top').set_value(135.).run()
    native = at.session_state['_coped_double_angle_project']
    at.selectbox(key='connection_family').set_value(R016).run()
    at.number_input(key='da_web_pitch').set_value(58.).run()
    older = at.session_state['_double_angle_project']
    at.selectbox(key='connection_family').set_value(R015).run()
    at.number_input(key='wa_weld_start').set_value(22.).run()
    welded = at.session_state['_welded_double_angle_project']
    at.selectbox(key='connection_family').set_value(FAMILY).run()
    assert not at.exception
    assert at.session_state['_coped_double_angle_project'] == native
    assert at.session_state['_double_angle_project'] == older
    assert at.session_state['_welded_double_angle_project'] == welded


def test_custom_profile_widgets_survive_hidden_catalog_choice():
    at = open_app(); at.selectbox(key='ca_support_name').set_value('W personalizado').run()
    at.number_input(key='ca_support_tw').set_value(8.25).run()
    at.text_input(key='ca_support_source').set_value('Perfil verificado').run()
    at.selectbox(key='ca_support_name').set_value(base().support.name).run()
    at.selectbox(key='connection_family').set_value('Single plate').run()
    at.selectbox(key='connection_family').set_value(FAMILY).run()
    at.selectbox(key='ca_support_name').set_value('W personalizado').run()
    assert not at.exception
    assert at.number_input(key='ca_support_tw').value == 8.25
    assert at.text_input(key='ca_support_source').value == 'Perfil verificado'
    assert at.session_state['_coped_double_angle_project']['connection']['beam'] == base().to_dict()['connection']['beam']


@pytest.mark.parametrize('db', [24., 19.05])
def test_diameter_system_and_hole_callback_are_exact(db):
    at = open_app(); at.selectbox(key='ca_db').set_value(db).run()
    assert not at.exception
    assert at.number_input(key='ca_hole_diameter').value == HOLES[db]
    at.number_input(key='ca_hole_diameter').set_value(HOLES[db]-.25).run()
    assert at.session_state['_coped_double_angle_project']['connection']['hole_diameter'] == HOLES[db]-.25


@pytest.mark.parametrize('field,value', [('kind', 'unsupported'), ('cope', 'unequal_double'), ('hole_type', 'unknown'), ('db', 18.6), ('bolt', 'unknown')])
def test_unsupported_imported_enums_stay_visible_and_unapproved(field, value):
    c = base(**{field: value}); at = upload(open_app(), c)
    assert at.selectbox(key='ca_' + field).value == value
    assert at.session_state['_coped_double_angle_project'] == c.to_dict()
    assert not at.success and not at.session_state['_coped_double_angle_result']['local_pass']


def test_invalid_import_leaves_project_intact():
    at = open_app(); native = at.session_state['_coped_double_angle_project']; broken = dict(native)
    broken['connection_type'] = 'double_angle_r016_bolted_shear'
    upload(at, broken)
    assert at.session_state['_coped_double_angle_project'] == native
    assert 'Não foi possível abrir' in at.session_state['ca_import_error']


def test_partial_result_does_not_crash_or_approve(monkeypatch):
    import lro.coped_double_angle_ui as ui
    monkeypatch.setattr(ui, 'evaluate', lambda c: {'status': 'ENGINEERING_MODEL_PENDING', 'local_pass': False,
        'geometry': {}, 'summary': {'governing_label': 'Modelo incompleto'}, 'checks': [{'id': 'partial', 'formula': {'a': 2}}],
        'cope': {'a': 1}, 'support_web': {'local_only': True}, 'restraints': {}, 'issues': []})
    at = open_app()
    assert not at.exception and not at.success
    assert button(at, 'Gerar memória R017').disabled


def test_report_invalidation_includes_changed_engine_result(monkeypatch):
    import lro.coped_double_angle_ui as ui
    at = open_app(); button(at, 'Gerar memória R017').click().run()
    assert 'ca_report' in at.session_state
    original = ui.evaluate
    def changed(c):
        r = original(c); r['issues'].append({'severity': 'engineering_pending', 'text': 'Nova condição externa.'}); return r
    monkeypatch.setattr(ui, 'evaluate', changed)
    at.run()
    assert not at.exception and 'ca_report' not in at.session_state


@pytest.mark.parametrize('change', [{'local_pass': False}, {'local_pass': 1}, {'summary': {}}, {'inputs': None},
    {'checks': []}, {'checks': [{'status': 'FAIL'}]}, {'geometry': {'valid': False}},
    {'issues': [{'severity': 'engineering_pending'}]}])
def test_complete_result_requires_consistent_local_flags(change):
    from lro.coped_double_angle_ui import _approval_complete
    result = {'status': 'COMPLETE_LOCAL_CHECKS_PASS_WITHIN_SCOPE', 'local_pass': True, 'global_pass': False,
              'inputs': {}, 'summary': {'complete_checks': True}, 'geometry': {'valid': True},
              'checks': [{'status': 'PASS'}], 'issues': []}
    assert _approval_complete(result)
    result.update(change); assert not _approval_complete(result)


def test_main_application_routes_new_family_and_guard_version():
    at = AppTest.from_file(str(APP), default_timeout=60).run()
    assert not at.exception
    at.selectbox(key='connection_family').set_value(FAMILY).run()
    assert not at.exception and at.session_state['_coped_double_angle_project'] == base().to_dict()
    from lro.models import VERSION
    from lro.coped_double_angle import COMPONENT_VERSION
    assert any(VERSION in item.value for item in at.caption)
    assert COMPONENT_VERSION == '0.9.3-angle-dev'  # Existing component identity is preserved.
