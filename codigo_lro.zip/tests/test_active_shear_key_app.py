"""AppTest: chapas ativas, repartição, contato físico e estado independente."""
from dataclasses import replace
import json
from pathlib import Path

import pytest
from streamlit.testing.v1 import AppTest

from lro.base_plate import BasePlate, evaluate, presets
from lro.models import KGF

APP = Path(__file__).resolve().parents[1] / 'app.py'
FAMILY = 'Placa de base · engastada'


def button(at, label):
    return next(widget for widget in at.button if widget.label == label)


def open_key(example='W · envelope de repartição'):
    at = AppTest.from_file(str(APP), default_timeout=60).run()
    at.selectbox(key='connection_family').set_value(FAMILY).run()
    at.selectbox(key='bp_example').set_value(example).run()
    button(at, 'Usar exemplo de placa de base').click().run()
    assert not at.exception
    return at


def connection(at, valid=True):
    return BasePlate.from_dict(at.session_state['_base_plate_project'], validate_values=valid)


def test_three_routes_active_defaults_and_explicit_confirmations():
    at = AppTest.from_file(str(APP), default_timeout=60).run()
    at.selectbox(key='connection_family').set_value(FAMILY).run()
    assert len(at.selectbox(key='bp_shear_mechanism').options) == 3
    at.selectbox(key='bp_shear_mechanism').set_value('device').run()
    assert len(at.selectbox(key='bp_device_model').options) == 4
    at.selectbox(key='bp_device_model').set_value('w_flange_plates').run()
    assert not at.exception
    assert at.selectbox(key='bp_ak_sharing').value == 'unknown_envelope'
    assert not at.checkbox(key='bp_ak_continuous').value
    assert not at.checkbox(key='bp_ak_concrete_filled').value
    assert any('DADOS OU GEOMETRIA INVÁLIDOS' in item.value for item in at.error)
    assert any('casos alternativos (V,0) e (0,V)' in item.value for item in at.warning)


def test_w_sharing_signs_and_single_global_eccentricity():
    at = open_key()
    c = connection(at)
    a = evaluate(c).geometry['active_key']
    assert not a['local_pass']
    assert a['allocation_cases'] == [[160000., 0.], [0., 160000.]]
    assert a['delta_M'] == pytest.approx(19328000.)
    at.selectbox(key='bp_ak_sharing').set_value('equal').run()
    assert not at.exception
    assert evaluate(connection(at)).geometry['active_key']['local_pass']
    assert any('não demonstram reações iguais' in item.value for item in at.warning)
    at.selectbox(key='bp_ak_sharing').set_value('verified_range').run()
    at.number_input(key='bp_ak_alpha_min').set_value(.4).run()
    at.number_input(key='bp_ak_alpha_max').set_value(.4).run()
    at.text_input(key='bp_ak_share_ref').set_value('MC ensaio 04: α=0,4, ambas as direções').run()
    a = evaluate(connection(at)).geometry['active_key']
    assert not a['local_pass']
    assert [p['b_contact'] for p in a['plates']] == [200., 170.]
    at.number_input(key='bp_V_kgf').set_value(-160000. / KGF).run()
    assert not at.exception
    a = evaluate(connection(at)).geometry['active_key']
    assert a['local_pass']
    assert [p['b_contact'] for p in a['plates']] == [170., 200.]
    assert [p['force'] for p in a['plates']] == pytest.approx([-64000., -96000.])
    assert a['delta_M'] == pytest.approx(-19328000.)
    at.selectbox(key='bp_ak_share_signs').set_value('positive').run()
    assert not at.exception
    assert any('não cobre o sinal atual' in item.value for item in at.error)


def test_active_geometry_survives_paths_family_and_independent_column():
    at = open_key('Cruz · chapa perpendicular ativa')
    at.number_input(key='bp_ak_b').set_value(230.).run()
    at.number_input(key='bp_ak_t').set_value(42.).run()
    at.number_input(key='bp_ak_cross_exclusion_positive').set_value(26.).run()
    at.number_input(key='bp_ak_cross_exclusion_negative').set_value(30.).run()
    expected = connection(at).active_key.to_dict('cross_active_plate')
    assert expected['product'] == 'fabricated'
    for route in ['friction', 'anchors', 'device']:
        at.selectbox(key='bp_shear_mechanism').set_value(route).run()
        assert not at.exception
    at.selectbox(key='bp_device_model').set_value('plate').run()
    at.number_input(key='bp_lug_bh').set_value(97.).run()
    at.selectbox(key='bp_device_model').set_value('external').run()
    at.text_input(key='bp_external_shear_ref').set_value('Memória externa independente').run()
    at.selectbox(key='bp_device_model').set_value('cross_active_plate').run()
    assert connection(at).active_key.to_dict('cross_active_plate') == expected
    at.selectbox(key='connection_family').set_value('Single plate').run()
    at.selectbox(key='connection_family').set_value(FAMILY).run()
    assert not at.exception
    assert at.number_input(key='bp_ak_b').value == 230.
    assert at.number_input(key='bp_ak_t').value == 42.
    assert at.number_input(key='bp_ak_cross_exclusion_negative').value == 30.
    at.selectbox(key='bp_column_name').set_value('Seção I personalizada').run()
    at.number_input(key='bp_column_d').set_value(300.).run()
    assert connection(at).active_key.to_dict('cross_active_plate') == expected


def test_import_contact_intervals_retained_until_exclusion_edit_and_repeat():
    at = open_key('Cruz · chapa perpendicular ativa')
    base = presets()['Cruz · chapa perpendicular ativa']
    contacts = {'P': {'positive': [[-110., -12.], [12., 110.]],
                      'negative': [[-105., -15.], [15., 105.]]}}
    welds = {'P': {'positive': [[-100., -20.], [20., 100.]], 'negative': [[-90., -20.], [20., 90.]]}}
    c = replace(base, M=4e6, V=-180000., active_key=replace(base.active_key, contact_intervals=contacts, weld_geometry=welds))
    for _ in range(2):
        at.get('file_uploader')[0].upload('chapas.json', json.dumps(c.to_dict()).encode(), 'application/json').run()
        button(at, 'Abrir placa de base JSON').click().run()
        assert not at.exception
        actual = connection(at)
        assert actual.M == pytest.approx(4e6)
        assert actual.active_key.contact_intervals == contacts
        assert actual.active_key.weld_geometry == welds
        assert evaluate(actual).geometry['delta_M'] == pytest.approx(-21744000.)
    at.number_input(key='bp_ak_secondary_length').set_value(220.).run()
    assert connection(at).active_key.contact_intervals == contacts
    at.number_input(key='bp_ak_cross_exclusion_positive').set_value(28.).run()
    actual = connection(at)
    assert actual.active_key.to_dict('cross_active_plate')['contact_intervals']['P']['positive'] == [[-120., -14.], [14., 120.]]
    assert actual.active_key.weld_geometry == welds
    at.selectbox(key='connection_family').set_value('Single plate').run()
    at.selectbox(key='connection_family').set_value(FAMILY).run()
    assert not at.exception
    assert connection(at).active_key == actual.active_key


def test_rolled_a992_fabricated_plate_options_and_actual_grout():
    at = open_key()
    assert 'ASTM A992' in at.selectbox(key='bp_ak_steel').options
    at.selectbox(key='bp_ak_steel').set_value('ASTM A992').run()
    assert not at.exception
    assert not any('não aplicável ao produto' in item.value for item in at.error)
    at.selectbox(key='bp_ak_product').set_value('fabricated').run()
    assert not at.exception
    assert any('não aplicável ao produto de chapa' in item.value for item in at.error)
    assert any('fora do escopo' in label for label in at.selectbox(key='bp_ak_steel').options)
    at.selectbox(key='bp_ak_steel').set_value('ASTM A36').run()
    at.number_input(key='bp_grout_t').set_value(47.).run()
    button(at, 'Adotar a₁/a₂ da Tabela 18').click().run()
    assert not at.exception
    assert at.number_input(key='bp_grout_t').value == 47.
    assert connection(at, valid=False).grout_t == 47.


def test_invalid_geometry_json_and_report_invalidation_are_safe():
    at = open_key('W · repartição igual idealizada')
    button(at, 'Gerar memória da placa de base').click().run()
    assert not at.exception and at.session_state['bp_report'][2][:2] == b'PK'
    at.number_input(key='bp_ak_H').set_value(120.).run()
    assert 'bp_report' not in at.session_state
    at.number_input(key='bp_ak_H').set_value(40.).run()
    assert not at.exception
    assert any('H deve superar' in item.value for item in at.error)
    assert button(at, 'Gerar memória da placa de base').disabled
    at.selectbox(key='connection_family').set_value('Single plate').run()
    at.selectbox(key='connection_family').set_value(FAMILY).run()
    assert not at.exception and at.number_input(key='bp_ak_H').value == 40.
    at.number_input(key='bp_ak_H').set_value(100.).run()
    at.text_area(key='bp_ak_weld_json').set_value('{').run()
    assert not at.exception
    assert any('Geometria de solda não salva' in item.value for item in at.error)
    assert button(at, 'Gerar memória da placa de base').disabled
    at.selectbox(key='connection_family').set_value('Single plate').run()
    at.selectbox(key='connection_family').set_value(FAMILY).run()
    assert not at.exception and at.text_area(key='bp_ak_weld_json').value == '{'
    at.text_area(key='bp_ak_weld_json').set_value('{}').run()
    assert not at.exception and not button(at, 'Gerar memória da placa de base').disabled
    at.selectbox(key='bp_ak_orientation').set_value('rotated_90').run()
    assert not at.exception
    assert any('Orientação fora do modelo' in item.value for item in at.error)


def test_zero_shear_retains_both_faces_and_weld_actions():
    at = open_key('W · repartição igual idealizada')
    at.number_input(key='bp_V_kgf').set_value(0.).run()
    assert not at.exception
    c = connection(at)
    a = evaluate(c).geometry['active_key']
    assert a['M_effective'] == c.M
    assert a['eV'] == pytest.approx(120.8)
    assert all(p['force'] == 0. for p in a['plates'])
    tables = [item.value for item in at.dataframe]
    faces = next(table for table in tables if 'Faixas expostas y (mm)' in table.columns)
    assert len(faces) == 4
    assert set(faces['Sinal de V']) == {'+', '−'}
    assert any('Ligação e dispositivo completo PENDENTES' in item.value for item in at.warning)


def test_nonfinite_edit_and_invalid_json_import_do_not_crash_or_replace_project():
    at = open_key('Cruz · chapa perpendicular ativa')
    before = connection(at).to_dict()
    invalid = json.loads(json.dumps(before))
    invalid['connection']['active_key']['H'] = float('nan')
    at.get('file_uploader')[0].upload('nao_finito.json', json.dumps(invalid).encode(), 'application/json').run()
    button(at, 'Abrir placa de base JSON').click().run()
    assert not at.exception
    assert any('Não foi possível abrir' in item.value for item in at.error)
    assert connection(at).active_key.H == 100.
    at.number_input(key='bp_ak_H').set_value(float('nan')).run()
    assert not at.exception
    assert button(at, 'Gerar memória da placa de base').disabled
    assert any('valor positivo e finito' in item.value for item in at.error)


def test_failed_global_equilibrium_does_not_crash_active_drawing():
    at = open_key('W · repartição igual idealizada')
    at.number_input(key='bp_N_kgf').set_value(1.e12).run()
    assert not at.exception
    assert any('EQUILÍBRIO NÃO DEMONSTRADO' in item.value for item in at.warning)
    assert button(at, 'Gerar memória da placa de base').disabled
    assert not any(item.label == 'Baixar desenho da base SVG' for item in at.get('download_button'))
