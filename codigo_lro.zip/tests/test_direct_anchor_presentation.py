"""Presentation regressions: actual data, independent scopes and hidden-state persistence."""
from dataclasses import replace
from io import BytesIO
from pathlib import Path
import json
import pytest
from docx import Document
from streamlit.testing.v1 import AppTest
from test_direct_anchor_integration import fixture,config,P
from lro.models import Profile
from lro.base_plate import evaluate,BasePlate,ANCHORS
from lro.pinned_base_plate import PinnedBasePlate
from lro.channel_base_plate import ChannelBasePlate
from lro.base_plate_report import create_report as fixed_report
from lro.channel_base_plate_report import create_report as channel_report
from lro.direct_anchor_shear import unc_thread_area

ROOT=Path(__file__).resolve().parents[1]


def cases():
    p=Profile('U synthetic','U',20.,200.,75.,7.,10.,180.,3000.)
    return [fixture(),PinnedBasePlate(P,db=24.,a1=70.,a2=120.,tp=50.,N=-40000.,V=10000.,
        shear_path='anchors',anchor_shear_model='direct_plate_bearing',direct_shear=config()),
        *[ChannelBasePlate(p,L_plate=350.,B_plate=350.,anchor_x=45.,anchor_y=130.,db=24.,
            anchor_washer_side=50.,anchor_washer_t=10.,base_hole=26.,anchor_layout=layout,
            centroid_back=20.,straight_web_length=175.,clear_geometry_confirmed=True,flange_min_thickness=8.,
            N=-20000.,V=10000.,tp=30.,shear_path='anchors',anchor_shear_model='direct_plate_bearing',direct_shear=config())
          for layout in ('four','two_symmetry')]]


def all_text(raw):
    doc=Document(BytesIO(raw))
    return '\n'.join([p.text for p in doc.paragraphs]+[cell.text for t in doc.tables for row in t.rows for cell in row.cells])


@pytest.mark.parametrize('c',cases(),ids=['fixed','pinned','u4','u2'])
def test_direct_word_scopes_and_real_hole(c):
    r=evaluate(c)
    raw=(channel_report if isinstance(c,ChannelBasePlate) else fixed_report)(c,r,True)
    text=all_text(raw)
    assert 'Contato direto placa–chumbador' in text
    assert 'γM2=1,25' in text and 'γa2=1,35' in text
    assert 'não calcula δtotal' in text
    assert 'ROTA DIRETA NÃO APROVADA' in text
    assert 'Estados alternativos' in text
    assert 'Referência de detalhamento da Tabela 18 corrigida' not in text
    assert 'VRd externo do grupo instalado' not in text
    assert 'EN ISO 898-1:1999' in text
    assert 'Sem crédito de atrito' in text


@pytest.mark.parametrize('mode',['no_slip','numeric_total_limit'])
def test_failed_or_pending_service_exportable(mode):
    c=fixture(direct_shear=replace(config(),service_slip_requirement=mode,service_total_limit=2.))
    text=all_text(fixed_report(c,evaluate(c)))
    assert 'ROTA DIRETA NÃO APROVADA' in text and mode in text


def app(c):
    channel=isinstance(c,ChannelBasePlate)
    pinned=isinstance(c,PinnedBasePlate)
    module='channel_base_plate_ui' if channel else 'pinned_base_plate_ui' if pinned else 'base_plate_ui'
    klass='ChannelBasePlate' if channel else 'PinnedBasePlate' if pinned else 'BasePlate'
    model_module='channel_base_plate' if channel else 'pinned_base_plate' if pinned else 'base_plate'
    project='_channel_base_plate_project' if channel else '_pinned_base_plate_project' if pinned else '_base_plate_project'
    code=f'''import sys,json
sys.path.insert(0,{str(ROOT)!r})
import streamlit as st
from lro.{module} import seed,render
from lro.{model_module} import {klass}
if {project!r} not in st.session_state:
    seed({klass}.from_dict(json.loads({json.dumps(c.to_dict())!r})))
render()
'''
    return AppTest.from_string(code,default_timeout=45).run()


@pytest.mark.parametrize('c',cases(),ids=['fixed','pinned','u4','u2'])
def test_ui_direct_seed_render_no_manual_vector(c):
    at=app(c)
    assert not at.exception,[x.message for x in at.exception]
    keys={w.key for w in at.number_input}
    prefix='cp' if isinstance(c,ChannelBasePlate) else 'pp' if isinstance(c,PinnedBasePlate) else 'bp'
    assert prefix+'_ds_hole_diameter' in keys
    assert not any(k and k.startswith(prefix+'_cc_force_a') for k in keys)
    assert not any(w.key and 'distribution_confirm' in w.key for w in at.checkbox)
    assert at.number_input(key=prefix+'_ds_hole_diameter').value==26.


def test_ui_hole_edit_invalidates_saved_report_and_keeps_exact_data():
    at=app(fixture())
    assert not at.exception
    # Seed a cached output then mutate only an actual direct input.
    at.session_state['bp_report']=('obsolete',False,b'old')
    at.number_input(key='bp_ds_hole_diameter').set_value(29.175).run()
    assert not at.exception,[x.message for x in at.exception]
    saved=at.session_state['_base_plate_project']['connection']
    assert saved['direct_shear']['hole_diameter']==29.175
    assert saved['db']==24. and saved['direct_shear']['material_name']=='Classe 4.6'
    assert 'bp_report' not in at.session_state


def test_ui_astm_acceptance_roundtrip_and_no_diameter_conversion():
    u=replace(config(),material_name='ASTM A36',material_basis='ASTM_supplementary',material_specification='ASTM A36/A36M-19',fy=250.,
        material_protocol='astm_a36_supplementary_v1',ductility_reference='Synthetic final-product elongation',
        certification_reference='Synthetic ASTM product certificate',supplementary_application_accepted=False,
        thread_standard='UNC_2A',thread_tpi=8.,thread_area=unc_thread_area(25.4,8.),thread_area_source='calculated_asme',
        thread_compliance='unverified_cut',hole_basis='supplementary_unc_bounded',hole_diameter=28.575)
    at=app(fixture(db=25.4,direct_shear=u))
    assert not at.exception,[x.message for x in at.exception]
    assert at.checkbox(key='bp_ds_supplementary_application_accepted').value is False
    at.checkbox(key='bp_ds_supplementary_application_accepted').check().run()
    assert not at.exception
    data=at.session_state['_base_plate_project']
    c=BasePlate.from_dict(json.loads(json.dumps(data)))
    assert c.db==25.4 and c.direct_shear.hole_diameter==28.575
    assert c.direct_shear.supplementary_application_accepted is True
    assert not evaluate(c).geometry['direct_anchor_shear']['domain']['eligible']  # 3.175 mm clearance is excessive.


@pytest.mark.parametrize('c',cases(),ids=['fixed','pinned','u4','u2'])
def test_svg_explains_actual_hole_no_lateral_washer(c):
    from lro.base_plate_drawing import image_bytes as fixed_image
    from lro.channel_base_plate_drawing import image_bytes as channel_image
    raw=(channel_image if isinstance(c,ChannelBasePlate) else fixed_image)(c,evaluate(c),'svg').decode()
    assert 'CONTATO DIRETO' in raw
    assert '26' in raw and ('sem crédito lateral' in raw or 'sem resistência lateral' in raw)

@pytest.mark.parametrize('c',cases(),ids=['fixed','pinned','u4','u2'])
def test_switch_native_and_back_preserves_direct_draft(c):
    at=app(c)
    prefix='cp' if isinstance(c,ChannelBasePlate) else 'pp' if isinstance(c,PinnedBasePlate) else 'bp'
    project='_channel_base_plate_project' if prefix=='cp' else '_pinned_base_plate_project' if prefix=='pp' else '_base_plate_project'
    at.selectbox(key=prefix+'_anchor_shear_model').select('welded_washer').run()
    assert not at.exception,[x.message for x in at.exception]
    assert at.session_state[project]['connection']['db']==24.
    at.selectbox(key=prefix+'_anchor_shear_model').select('direct_plate_bearing').run()
    assert not at.exception,[x.message for x in at.exception]
    data=at.session_state[project]['connection']['direct_shear']
    assert data==c.to_dict()['connection']['direct_shear']


def test_choose_direct_from_legacy_does_not_change_material_hole_or_diameter():
    from lro.base_plate import presets
    c=presets()['Chumbadores · arruelas soldadas']
    at=app(c)
    assert not at.exception
    at.selectbox(key='bp_anchor_shear_model').select('direct_plate_bearing').run()
    assert not at.exception,[x.message for x in at.exception]
    data=at.session_state['_base_plate_project']['connection']
    assert data['db']==c.db
    assert data['direct_shear']['hole_diameter']==0.
    assert data['direct_shear']['material_name']==''
    assert data['direct_shear']['fy']==0.
    assert data['direct_shear']['model']=='conventional_grouted_ec3'
    assert any('M24' in x for x in at.selectbox(key='bp_db_label').options)


def test_nonstandard_imported_diameter_stays_exact_diagnostic():
    c=fixture(db=19.1,direct_shear=replace(config(),hole_diameter=21.1,thread_area=215.))
    at=app(c)
    assert not at.exception,[x.message for x in at.exception]
    data=at.session_state['_base_plate_project']['connection']
    assert data['db']==19.1 and data['direct_shear']['hole_diameter']==21.1
    assert not evaluate(BasePlate.from_dict(at.session_state['_base_plate_project'])).geometry['direct_anchor_shear']['domain']['eligible']


def test_axial_washer_edit_is_preserved_and_has_no_lateral_credit():
    at=app(fixture())
    at.number_input(key='bp_anchor_washer_t').set_value(12.3).run()
    assert not at.exception
    original=at.session_state['_base_plate_project']['connection']['direct_shear']
    assert at.session_state['_base_plate_project']['connection']['anchor_washer_t']==12.3
    at.selectbox(key='bp_anchor_shear_model').select('welded_washer').run()
    assert not at.exception
    at.selectbox(key='bp_anchor_shear_model').select('direct_plate_bearing').run()
    assert not at.exception
    data=at.session_state['_base_plate_project']['connection']
    assert data['anchor_washer_t']==12.3 and data['direct_shear']==original


def test_word_uses_actual_direct_equations_not_external_device_fallback():
    from zipfile import ZipFile
    from xml.etree import ElementTree as ET
    c=fixture(N=-40000.,M=0.);r=evaluate(c)
    raw=fixed_report(c,r,True)
    with ZipFile(BytesIO(raw)) as z:root=ET.fromstring(z.read('word/document.xml'))
    text=''.join(root.itertext())
    assert 'Rd,dispositivo' not in text
    assert 'min(0,75Ag; As real)' in text
    assert 'não dimensionado automaticamente; As real=' in text
    for row in r.checks:
        if row.id.startswith('bp_direct_'):assert row.equation in text
