"""Actual native 2L UI/import/exports; no browser or whole-catalog mock claims."""
from copy import deepcopy
from dataclasses import replace
import json
from pathlib import Path

import pytest
from streamlit.runtime.memory_media_file_storage import MemoryMediaFileStorage
from streamlit.testing.v1 import AppTest

from lro.axial_double_angle import AxialDoubleAngle, FAMILY, evaluate
from lro.axial_double_angle_ui import decode_project, import_ui_values, checks_complete

APP = Path(__file__).resolve().parents[1] / 'app.py'
PROJECT = '_axial_double_angle_project'
RESULT = '_axial_double_angle_result'
DRAFT = '_axial_double_angle_ui_draft'


@pytest.fixture
def media(monkeypatch):
    files = {}
    original = MemoryMediaFileStorage.load_and_get_id
    def tap(storage, *args, **kwargs):
        file_id = original(storage, *args, **kwargs)
        files[file_id] = storage._files_by_id[file_id].content
        return file_id
    monkeypatch.setattr(MemoryMediaFileStorage, 'load_and_get_id', tap)
    return files


def fresh():
    at = AppTest.from_file(str(APP), default_timeout=90)
    at.session_state['connection_family'] = FAMILY
    at.run()
    assert not at.exception
    return at


def button(at, label):
    return next(item for item in at.button if item.label == label)


def download(at, media, label):
    item = next(item for item in at.get('download_button') if item.label == label)
    return media[Path(item.proto.url).name.rsplit('.', 1)[0]]


def text(at):
    return '\n'.join(str(item.value) for kind in ('caption', 'info', 'warning', 'error', 'success', 'markdown')
                     for item in getattr(at, kind))


def upload(at, payload):
    if not isinstance(payload, bytes):
        payload = json.dumps(payload, allow_nan=True).encode()
    at.get('file_uploader')[0].upload('axial-native.json', payload, 'application/json').run()
    button(at, 'Carregar 2L axial').click().run()
    assert not at.exception


def test_native_initial_fixture_compact_inputs_source_properties_and_current_result(media):
    at = fresh()
    c = AxialDoubleAngle.from_dict(at.session_state[PROJECT])
    assert c.Ag == 1858 and c.ec == 21.3 and c.gauge == 35
    assert c.root_radius == 6 and c.tool_radius == 18 and c.fabrication_clearance == 2
    assert c.N == 200000
    assert at.session_state[RESULT] == evaluate(c)
    assert checks_complete(at.session_state[RESULT])
    assert json.loads(download(at, media, 'Salvar projeto 2L axial .json')) == c.to_dict()
    assert download(at, media, 'Baixar desenho 2L axial .png').startswith(b'\x89PNG')
    assert b'<svg' in download(at, media, 'Baixar desenho 2L axial .svg')
    assert all(word in text(at) for word in ('6.1.8.2', 'M=0', 'PDF 162', 'não se recalculam', 'não são verificados'))
    assert {'ad_N_kN', 'ad_n', 'ad_gauge', 'ad_angle_end', 'ad_plate_end'} <= {item.key for item in at.number_input}
    assert not {'ad_bolt_x', 'ad_terminal_x', 'ad_hole_diameter', 'ad_grip'} & {item.key for item in at.number_input}
    assert any(item.label == 'Todas as verificações primitivas e caminhos físicos' for item in at.expander)


def test_zero_actual_and_separate_policy_cases_then_native_roundtrip(media):
    at = fresh()
    c = replace(AxialDoubleAngle(), project='Zero real e duas políticas', N=0., recommend_half_capacity=True,
                Ag=1901.75, ec=22.125, profile_source='Propriedades fornecidas para este ensaio')
    upload(at, c.to_dict())
    assert 'ad_import_error' not in at.session_state
    assert at.session_state[PROJECT] == c.to_dict()
    cases = at.session_state[RESULT]['cases']
    assert len(cases) == 3
    assert sorted(case['N'] for case in cases)[0] == 0
    assert sum(case['N'] == 45000 for case in cases) == 1
    assert at.number_input(key='ad_N_kN').value == 0
    assert at.number_input(key='ad_Ag').value == c.Ag
    assert at.number_input(key='ad_ec').value == c.ec
    payload = download(at, media, 'Salvar projeto 2L axial .json')
    assert decode_project(payload) == c
    at.run()
    assert download(at, media, 'Salvar projeto 2L axial .json') == payload


@pytest.mark.parametrize('corrupt', ['unknown', 'missing', 'boolean_numeric', 'nonfinite', 'duplicate', 'wrong_family'])
def test_import_rejection_is_atomic_and_preserves_valid_report(media, corrupt):
    at = fresh()
    at.text_input(key='ad_project').set_value('Projeto protegido').run()
    button(at, 'Gerar memória 2L axial').click().run()
    assert not at.exception
    original = deepcopy(at.session_state[PROJECT])
    draft = deepcopy(at.session_state[DRAFT])
    report = at.session_state.ad_report
    bad = deepcopy(original)
    if corrupt == 'unknown':
        bad['unrecognized'] = 1
    elif corrupt == 'missing':
        bad['connection'].pop('ec')
    elif corrupt == 'boolean_numeric':
        bad['connection']['Ag'] = True
    elif corrupt == 'nonfinite':
        bad['connection']['N'] = float('nan')
    elif corrupt == 'duplicate':
        bad = json.dumps(bad).replace('"connection": {', '"connection": {"N": 1,').encode()
    else:
        bad['connection_type'] = 'double_angle'
    upload(at, bad)
    assert 'Não foi possível abrir' in text(at)
    assert at.session_state[PROJECT] == original
    assert at.session_state[DRAFT] == draft
    assert at.session_state.ad_report == report
    assert json.loads(download(at, media, 'Salvar projeto 2L axial .json')) == original


def test_custom_properties_threads_and_draft_survive_family_and_guide_changes(media):
    at = fresh()
    at.number_input(key='ad_leg').set_value(80.)
    at.number_input(key='ad_Ag').set_value(1987.25)
    at.number_input(key='ad_ec').set_value(22.75)
    at.number_input(key='ad_root_radius').set_value(7.)
    at.checkbox(key='ad_threads_excluded_1').check()
    at.text_input(key='ad_profile_source').set_value('Tabela específica aprovada no projeto').run()
    assert not at.exception
    original = deepcopy(at.session_state[PROJECT])
    at.selectbox(key='nav_guide_interface').set_value('w_splice').run()
    at.selectbox(key='nav_guide_model').set_value('axial_tension').run()
    assert at.session_state[PROJECT] == original
    at.selectbox(key='connection_family').set_value('Single plate').run()
    at.selectbox(key='connection_family').set_value(FAMILY).run()
    assert not at.exception and at.session_state[PROJECT] == original
    assert at.number_input(key='ad_Ag').value == 1987.25
    assert at.checkbox(key='ad_threads_excluded_1').value is True
    assert at.checkbox(key='ad_threads_excluded_2').value is False
    assert json.loads(download(at, media, 'Salvar projeto 2L axial .json')) == original


def test_report_invalidation_and_invalid_geometry_draft_recovery(media):
    at = fresh()
    button(at, 'Gerar memória 2L axial').click().run()
    assert at.session_state.ad_report[2].startswith(b'PK')
    at.number_input(key='ad_N_kN').set_value(900.).run()
    assert not at.exception
    assert 'ad_report' not in at.session_state
    assert not any(item.label == 'Baixar memória 2L axial .docx' for item in at.get('download_button'))
    assert at.session_state[RESULT]['global_pass'] is False
    assert at.session_state[RESULT]['checks']
    # Real resistance failure remains visible and reportable for coherent geometry.
    assert not button(at, 'Gerar memória 2L axial').disabled
    at.number_input(key='ad_pitch').set_value(0.).run()
    assert not at.exception
    assert button(at, 'Gerar memória 2L axial').disabled
    draft = deepcopy(at.session_state[DRAFT])
    at.selectbox(key='connection_family').set_value('Single plate').run()
    at.selectbox(key='connection_family').set_value(FAMILY).run()
    assert not at.exception
    assert at.number_input(key='ad_pitch').value == 0.
    assert at.session_state[DRAFT] == draft
    assert button(at, 'Gerar memória 2L axial').disabled


def test_import_preserves_unedited_native_force_bits_and_rejects_unit_underflow():
    c = replace(AxialDoubleAngle(), N=123456.78901234567)
    values = import_ui_values(c)
    assert values['ad_N'] == c.N
    assert values['ad_N_kN'] == c.N / 1000.
    with pytest.raises(ValueError, match='conversão de unidade'):
        import_ui_values(replace(c, N=5e-324))


def test_new_family_is_append_only_and_required_files_guarded():
    from lro.guided_selection import FAMILIES, search_families
    # This family was appended at index 11 in 0.9.20; subsequent releases
    # append other families without moving or relabeling this existing route.
    assert len(FAMILIES) >= 12
    assert FAMILIES[11].route_select_value == FAMILY
    assert sum(len(family.interface_tags) for family in FAMILIES[:12]) == 13
    assert search_families('axial_double_angle_gusset', 'axial_tension') == (FAMILIES[11],)
    source = APP.read_text()
    for name in ('axial_double_angle', 'axial_double_angle_ui', 'axial_double_angle_presentation',
                 'axial_double_angle_drawing', 'axial_double_angle_report'):
        assert repr(name) in source


def test_low_actual_cannot_disable_required_minimum_but_import_stays_recoverable():
    at = fresh()
    c = replace(AxialDoubleAngle(), N=0., minimum_force=False)
    upload(at, c.to_dict())
    assert at.session_state[PROJECT] == c.to_dict()
    assert at.checkbox(key='ad_minimum_force').value is False
    assert at.session_state[RESULT]['status'].startswith('OUTSIDE')
    assert at.session_state[RESULT]['global_pass'] is False
    assert not at.success
    assert button(at, 'Gerar memória 2L axial').disabled
    assert 'mínimo obrigatório' in at.checkbox(key='ad_minimum_force').label
    at.checkbox(key='ad_minimum_force').check().run()
    assert not at.exception
    assert at.session_state[PROJECT]['connection']['N'] == 0
    assert any(case['N'] == 45000 for case in at.session_state[RESULT]['cases'])
    assert not button(at, 'Gerar memória 2L axial').disabled
