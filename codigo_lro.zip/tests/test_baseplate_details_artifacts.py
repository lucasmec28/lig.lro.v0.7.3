from dataclasses import replace
from io import BytesIO
import zipfile
import pytest
from lro.base_plate import BasePlate,evaluate,presets
from lro.base_plate_drawing import image_bytes
from lro.base_plate_detail_drawing import detail_image_bytes
from lro.base_plate_report import create_report
from lro.base_plate_details import DETAIL_DEFAULTS


def sample(**kw):
    return replace(presets()['T2 · tração e pequeno momento'],cone_model='aci318_19',
        anchor_type='buried_plate_nut',anchor_detail_ref='AN01',anchor_detail_confirmed=True,
        weld_web_type='cjp',weld_flange_type='fillet',weld_flange_measure='throat',weld_flange_size=4.,**kw)


def capture(monkeypatch,callback,c):
    import matplotlib.pyplot as plt
    found=[];close=plt.close
    def remember(fig):
        if hasattr(fig,'axes'):found.append(fig)
        close(fig)
    monkeypatch.setattr(plt,'close',remember)
    svg=callback(c,evaluate(c),'svg').decode()
    return found[-1],svg


@pytest.mark.parametrize('path,model',[('friction','external'),('external','external'),('plate','external'),('anchors','welded_washer')])
def test_every_grout_path_has_actual_45_degree_footprint(monkeypatch,path,model):
    c=sample(shear_path=path,anchor_shear_model=model,grout_t=37.)
    fig,svg=capture(monkeypatch,image_bytes,c)
    shapes={p.get_gid():p for ax in fig.axes for p in ax.patches if p.get_gid()}
    footprint=shapes['grout_45_footprint']
    assert footprint.get_width()==c.L+74 and footprint.get_height()==c.B+74
    grout=shapes.get('actual_grout',shapes.get('anchor_actual_grout')).get_xy()
    assert tuple(grout[0])==(-c.L/2,0)
    assert tuple(grout[2])==(c.L/2+37,-37)
    assert tuple(grout[3])==(-c.L/2-37,-37)
    a=evaluate(c).geometry
    assert a['sigma_rd']==c.sigma_rd
    assert a['grout']['footprint']!=a['grout']['plate_area']


def test_rotated_stiffener_plan_and_distinct_buried_head_nut_washers(monkeypatch):
    c=sample(stiffener_detail='web_pair',shear_path='anchors',anchor_shear_model='welded_washer',
             anchor_head_length=95.,anchor_head_width=90.,anchor_bearing_t=14.,anchor_nut_t=18.,anchor_head_t=40.)
    fig,svg=capture(monkeypatch,detail_image_bytes,c)
    shapes={p.get_gid():p for ax in fig.axes for p in ax.patches if p.get_gid()}
    above=shapes['stiffener_above_plan'];below=shapes['stiffener_below_plan']
    assert above.get_x()==-c.stiffener_t/2 and above.get_y()==c.column.d/2
    assert below.get_y()==-c.column.d/2-c.stiffener_length
    head=shapes['buried_bearing_head_1'];washer=shapes['upper_welded_washer_1'];nut=shapes['buried_retaining_nut_1']
    assert head.get_y()+head.get_height()==-c.grout_t-c.hef
    assert head.get_height()==14 and nut.get_height()==18
    assert nut.get_y()+nut.get_height()==head.get_y()
    assert washer.get_y()==c.tp and washer.get_width()==c.anchor_washer_side
    assert head.get_width()==95 and head.get_width()!=washer.get_width()
    assert 'Alma: Solda de chanfro' in svg and 'a=4.000' in svg
    assert 'Sem crédito resistente' in svg


def test_word_has_correct_cone_equation_detail_and_independent_welds():
    c=sample();data=create_report(c,evaluate(c),True)
    with zipfile.ZipFile(BytesIO(data)) as z:xml=z.read('word/document.xml').decode()
    for term in ('Cone de concreto','ACI 318-19','4.3.2.2','Condição B','AN01','Solda da alma','Soldas das mesas','CJP','4.000','hef físico','ANCORAGEM COMPLETA A COMPLEMENTAR'):
        assert term in xml
    assert '<m:sSubSup>' in xml and 'calc,pol' in xml
    assert 'Grupo tracionado conectado' in xml
    assert 'Envelope suplementar conservador de subconjuntos desligado' in xml


def test_invalid_optional_detail_can_still_export_without_invented_geometry():
    c=sample(block_h=-10.,block_xmin=100.,block_xmax=0.)
    r=evaluate(c)
    assert r.geometry['concrete_cone']['status']=='pending'
    svg=detail_image_bytes(c,r,'svg').decode()
    assert 'actual_block_section' not in svg and 'contorno do bloco omitido' in svg
    assert create_report(c,r)[:2]==b'PK'


def test_new_fields_finite_bool_and_defaults_contract():
    c=sample()
    for key,val in DETAIL_DEFAULTS.items():
        # New projects have an explicit fixed family; legacy missing intent is
        # preserved separately by BasePlate.from_dict as unspecified.
        assert getattr(BasePlate(c.column),key)==('fixed' if key=='base_fixity' else val)
        if type(val) is float:
            assert any(i.severity=='error' for i in evaluate(replace(c,**{key:float('nan')})).issues)
            assert any(i.severity=='error' for i in evaluate(replace(c,**{key:True})).issues)
