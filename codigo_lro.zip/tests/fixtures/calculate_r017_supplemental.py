"""Additional independent NBR shear/grip/detail probes; no application imports."""
import json,math
from pathlib import Path
folder=Path(__file__).resolve().parent
source=json.loads((folder/'r017_independent_fixtures.json').read_text())
member={}
for name,f in source['fixtures'].items():
 i=f['inputs'];d=i['d_mm'];tw=i['tw_mm'];h=308. if d==355 else 352.;fy=i['fy_MPa']
 lam=h/tw;lp=1.10*math.sqrt(5.34*200000/fy);lr=1.37*math.sqrt(5.34*200000/fy)
 cv=1. if lam<=lp else lp/lam if lam<=lr else 1.24*(lp/lam)**2
 member[name]=dict(clear_mm=h,lambda_web=lam,lambda_p=lp,lambda_r=lr,Cv=cv,Rd_N=.6*fy*d*tw*cv/1.1)
bolt=.45*math.pi*20**2/4*830/1.35
long_grip=[]
for beam_t,support_t in [(110.,7.2),(7.2,110.),(110.,110.)]:
 wb=beam_t+12.8;sup=support_t+6.4
 wf=1-.01*max(0.,wb-100.)/1.5;sf=1-.01*max(0.,sup-100.)/1.5
 long_grip.append(dict(beam_tw_mm=beam_t,support_tw_mm=support_t,web_grip_mm=wb,support_grip_mm=sup,web_factor=wf,support_factor=sf,web_plane_Rd_N=bolt*wf,support_plane_Rd_N=bolt*sf))
record=dict(sources=['NBR5.4.3.1 intact I-web only','NBR6.3.7 printedp91/PDF113 visually verified, standard non-pretension-credit route'],uncut_member=member,long_grip=long_grip,
    warning='Long-grip profiles are deliberately synthetic component probes; no claim of real rolled-section availability. Uncut I-web and coped strip remain distinct.')
(folder/'r017_supplemental_fixtures.json').write_text(json.dumps(record,indent=2)+'\n')
