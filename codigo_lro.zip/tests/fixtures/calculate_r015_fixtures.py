"""Independent R015 elastic line-group and component fixtures. No app imports.
Units: N, mm, MPa. Geometry is explicit engineering input, not inferred
uniform-size weld length from an undimensioned historical drawing.
"""
import json, math
from pathlib import Path
G1=1.1; G2=1.35

def solve(V=200000.0,a=20.0,b=76.0,h=260.0,w=4.0,fw=490.0,ta=6.4,tweb=5.8,fya=250.0,fua=400.0,fyweb=345.0,fuweb=450.0,xload=0.0,yload=None):
    # y downward. Positive V is downward force, all coordinates measured from support face.
    if yload is None:yload=h/2
    segs=[('top',a,0,b,0),('toe',b,0,b,h),('bottom',b,h,a,h)]
    props=[]
    for name,x1,y1,x2,y2 in segs:
        L=math.hypot(x2-x1,y2-y1); xm=(x1+x2)/2; ym=(y1+y2)/2
        props.append((name,x1,y1,x2,y2,L,xm,ym))
    L=sum(s[5] for s in props)
    xb=sum(s[5]*s[6] for s in props)/L; yb=sum(s[5]*s[7] for s in props)/L
    J=sum(s[5]*((s[6]-xb)**2+(s[7]-yb)**2)+s[5]**3/12 for s in props)
    F=V/2; M=(xload-xb)*F
    def flow(x,y):return -M*(y-yb)/J,F/L+M*(x-xb)/J
    endpoints=[]
    for name,x1,y1,x2,y2,*_ in props:
        for label,x,y in [('start',x1,y1),('end',x2,y2)]:
            qx,qy=flow(x,y)
            endpoints.append(dict(segment=name,end=label,x=x,y=y,qx=qx,qy=qy,q=math.hypot(qx,qy)))
    worst=max(endpoints,key=lambda p:p['q']); qmax=worst['q']
    # Independent composite Simpson quadrature on the physical line proves equilibrium
    # and line integrals. This method uses no analytic centroid/J integration.
    numerical={'L':0,'Sx':0,'Sy':0,'J':0,'Fx':0,'Fy':0,'M_origin':0,'M_centroid':0}
    nn=2000
    for name,x1,y1,x2,y2,ll,*_ in props:
        for i in range(nn+1):
            k=1 if i in (0,nn) else 4 if i%2 else 2
            dl=k*ll/(3*nn); f=i/nn; x=x1+f*(x2-x1); y=y1+f*(y2-y1)
            qx,qy=flow(x,y)
            for key,value in [('L',1),('Sx',x),('Sy',y),('J',(x-xb)**2+(y-yb)**2),('Fx',qx),('Fy',qy),('M_origin',x*qy-y*qx),('M_centroid',(x-xb)*qy-(y-yb)*qx)]:numerical[key]+=value*dl
    assert math.isclose(numerical['L'],L,rel_tol=1e-12)
    assert math.isclose(numerical['J'],J,rel_tol=1e-12)
    assert abs(numerical['Fx'])<1e-7
    assert math.isclose(numerical['Fy'],F,rel_tol=1e-12)
    assert abs(numerical['M_origin']-xload*F)<1e-6
    assert math.isclose(numerical['M_centroid'],M,rel_tol=1e-12,abs_tol=1e-8)
    throat=w/math.sqrt(2)
    capacities={
        'weld_metal_line':0.6*fw*throat/G2,
        'angle_base_rupture_line':0.6*fua*ta/G2,
        'beam_shared_base_rupture_line_per_angle':0.6*fuweb*(tweb/2)/G2,
        'angle_base_elastic_vm_bound_line':fya*ta/(math.sqrt(3)*G1),
        'beam_shared_base_elastic_vm_bound_line_per_angle':fyweb*(tweb/2)/(math.sqrt(3)*G1)}
    derived={k:dict(q_Rd=v,utilization=qmax/v,pair_equivalent_V_Rd=abs(V)*v/qmax) for k,v in capacities.items()}
    return dict(inputs=dict(V_total=V,V_angle=F,x_start=a,x_toe=b,length=h,leg=w,fw=fw,t_angle=ta,t_web=tweb,fy_angle=fya,fu_angle=fua,fy_web=fyweb,fu_web=fuweb,x_load=xload,y_load=yload),
        line_group=dict(segments=[dict(name=s[0],start=[s[1],s[2]],end=[s[3],s[4]],length=s[5]) for s in props],total_length=L,xbar=xb,ybar=yb,J_line=J,throat=throat,Aw=throat*L,Jw=throat*J,M_angle= M,e=xb-xload,critical=worst,endpoints=endpoints),checks=derived,equilibrium_quadrature=numerical)

def angle_cut_resultants(result):
    """Elastic membrane-strip supplement; independent integration of actual weld field."""
    inp=result['inputs'];grp=result['line_group']
    F=inp['V_angle'];s=inp['x_start'];b=inp['x_toe'];H=inp['length'];t=inp['t_angle']
    Mw=grp['M_angle'];J=grp['J_line'];L=grp['total_length'];xc=grp['xbar']
    qa=F/L+Mw*(s-xc)/J;k=Mw/J;c=Mw*H*H/(2*J)
    def cut(x):
        u=max(0,x-s)
        return F-2*qa*u-k*u*u, F*x-qa*u*u-k*u**3/3+c*u
    xs=[0,s,b]
    # dM/du=F+c-2*qa*u-k*u^2; dV/du=-2*qa-2*k*u
    D=4*qa*qa+4*k*(F+c)
    if k and D>=0:
        for u in [(-2*qa+math.sqrt(D))/(2*k),(-2*qa-math.sqrt(D))/(2*k)]:
            if 0<=u<=b-s:xs.append(s+u)
    elif qa and 0<=(F+c)/(2*qa)<=b-s:xs.append(s+(F+c)/(2*qa))
    if k and 0<=-qa/k<=b-s:xs.append(s-qa/k)
    checks=[]
    for x in sorted(set(xs)):
        V,M=cut(x)
        # Simpson quadrature of loaded portions of top and bottom branches.
        # Support reaction is -F at x=0, and weld actions are those already solved.
        Fn=-F;Mn=F*x;nn=500;u=max(0,x-s)
        for y in [0,H]:
            for i in range(nn+1):
                xx=s+u*i/nn;wt=(1 if i in (0,nn) else 4 if i%2 else 2)*u/(3*nn)
                qx=-Mw*(y-H/2)/J;qy=F/L+Mw*(xx-xc)/J
                Fn+=qy*wt;Mn+=((xx-x)*qy-(y-H/2)*qx)*wt
        assert math.isclose(V,-Fn,rel_tol=1e-12,abs_tol=1e-8)
        assert math.isclose(M,Mn,rel_tol=1e-12,abs_tol=1e-8)
        checks.append(dict(x=x,V=V,M=M,V_quadrature=-Fn,M_quadrature=Mn))
    Vmax=max(abs(p['V']) for p in checks);critical=max(checks,key=lambda p:abs(p['M']));Mmax=abs(critical['M'])
    sigma=6*Mmax/(t*H*H);tau=1.5*Vmax/(t*H);vm=math.sqrt(sigma*sigma+3*tau*tau)
    return dict(Vmax=Vmax,Mmax=Mmax,x_Mmax=critical['x'],sigma_envelope=sigma,tau_envelope=tau,VM_envelope=vm,fy_design=inp['fy_angle']/G1,utilization=vm/(inp['fy_angle']/G1),cut_points=checks,note='Conservative noncoincident maxima, rectangular shear maximum1.5V/A, full-height unholed beam angle leg. Analytic equilibrium supplement, not a Gerdau equation.')

def support_components(V=200000,e_top=40,e_bottom=40,n=4,p=60,L=260,db=20,dh=22,dn=24,ta=6.4,tf=12,b_angle=76,g=45,tw=5.8,bf=250,col_top=500,col_bottom=500,fub=825):
    # One line of support bolts per angle; no beam-side bolt. Existing R016 equations
    # independently transcribed, rather than importing either verification or app engine.
    up=V<0;F=abs(V);gamma=1.35
    angleE=e_bottom if up else e_top;colE=col_top if up else col_bottom
    bolt=.45*(math.pi*db*db/4)*fub/gamma
    def rb(t,fu,lc):return min(1.2*lc,2.4*db)*t*fu/gamma
    ab=[rb(ta,400,p-dh)]*(n-1)+[rb(ta,400,angleE-dh/2)]
    cb=[rb(tf,450,p-dh)]*(n-1)+[rb(tf,450,colE-dh/2)]
    def blocks(t,fy,fu,E,width):
        result=[]
        for k in range(1,n+1):
            Agv=(E+(k-1)*p)*t;Anv=Agv-(k-.5)*dn*t;Ant=(width-.5*dn)*t
            rd=min(.6*fu*Anv+fu*Ant,.6*fy*Agv+fu*Ant)/gamma
            demand=F*k/(2*n)
            result.append(dict(k=k,Agv=Agv,Anv=Anv,Ant=Ant,Rd_each=rd,demand_each=demand,utilization=demand/rd))
        return result
    return dict(inputs=dict(V=V,n_per_angle=n,angle_edge_loaded=angleE,column_edge_loaded=colE,db=db,dh=dh,d_net=dn),bolt_one_plane=bolt,bolt_pair=2*n*bolt,angle_bearing_each=ab,column_bearing_each=cb,angle_bearing_sum_pair=2*sum(ab),column_bearing_sum_pair=2*sum(cb),angle_support_gross_shear_pair=.6*250*2*L*ta/G1,angle_support_net_shear_pair=.6*400*2*(L-n*dn)*ta/G2,angle_beam_unholed_shear_pair=.6*400*2*L*ta/G2,angle_support_blocks_each=blocks(ta,250,400,angleE,b_angle-g),column_outboard_blocks_each=blocks(tf,345,450,colE,bf/2-(tw/2+g)))

if __name__=='__main__':
    fixtures={
        'R015_U260_56_w4_V200_down':solve(),
        'R015_U260_56_w4_E70_485_V200_down':solve(fw=485),
        'R015_U260_56_w4_V200_up':solve(V=-200000),
        'R015_U230_66_w5_historical_geometry_only':solve(h=230,a=10,w=5,tweb=6.5),
        'R015_U260_40_w4_shorter_branches':solve(a=36),
        'R015_U260_56_concentric_control':solve(xload=(76*260+(76*76-20*20))/(260+2*56)),
        'R015_U260_56_V450_minimum_design':solve(V=45000),
        'R015_U260_56_thin_web_3':solve(tweb=3)}
    for result in fixtures.values():
        if result['inputs']['x_load']==0:result['angle_cut_supplement']=angle_cut_resultants(result)
    pos=fixtures['R015_U260_56_w4_V200_down'];neg=fixtures['R015_U260_56_w4_V200_up']
    assert pos['line_group']['critical']['q']==neg['line_group']['critical']['q']
    for p,n in zip(pos['line_group']['endpoints'],neg['line_group']['endpoints']):assert p['qx']==-n['qx'] and p['qy']==-n['qy']
    out=dict(status='Independent component/model fixtures, not published full-connection numerical validation',units='N, mm, MPa',methods='Exact line integrals and separately quadrature-verified equilibrium. Isotropic weld Table9 strength; no directional enhancement or ICR coefficients. Base-metal line checks conservative comparison. No app imports.',fixtures=fixtures,support_fixtures={'symmetric_down':support_components(),'asymmetric_down':support_components(e_top=30,e_bottom=50),'asymmetric_up':support_components(e_top=30,e_bottom=50,V=-200000),'thin_near_end_column':support_components(tf=3,bf=150,col_bottom=30)})
    path=Path(__file__).with_name('r015_independent_fixtures.json');path.write_text(json.dumps(out,indent=2))
    for name,result in fixtures.items():
        p=result['line_group'];print(name,{k:p[k] for k in ('total_length','xbar','ybar','J_line','M_angle')},'qmax',p['critical']['q'])
        for k,c in result['checks'].items():print(' ',k,c)
    print('Saved',path)
