"""Independent source equations for R017. No production imports or datasets.
Units are N, mm, MPa. Inputs deliberately frozen before production evaluation.
The local fixture assumes externally qualified compression-face lateral restraint;
its synthetic qualification is not a design of a real brace or supporting girder.
"""
from __future__ import annotations
import json, math, hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent
G1,G2=1.10,1.35

def boundary(x,c,dc,r,gap=10.):
    """Depth of top removed material, x measured from supporting web contact face."""
    u=x-gap
    if u < 0: return None
    if u <= c-r: return dc
    if u <= c: return dc-r+math.sqrt(max(0.,r*r-(u-(c-r))**2))
    return 0.

def cope_clearance(x,y,c,dc,r,gap=10.):
    """Euclidean point clearance to actual top cope boundary (not hole radius).
    Independent finite-segment/quarter-circle minimization, x from support face.
    """
    cx,cy=gap+c-r,dc-r
    qx=min(max(x,gap),cx)
    horizontal=math.hypot(x-qx,y-dc)
    qy=min(max(y,0.),cy)
    vertical=math.hypot(x-(gap+c),y-qy)
    theta=min(max(math.atan2(y-cy,x-cx),0.),math.pi/2)
    arc=math.hypot(x-(cx+r*math.cos(theta)),y-(cy+r*math.sin(theta)))
    return min(horizontal,vertical,arc)

def model(d,tw,dc,c,gap,fy=345.):
    h=d-2*dc;S=tw*h*h/6;e=c+gap;fd=3.5-7.5*dc/d
    F=350600.*tw*tw/(c*h)*fd
    return dict(h0_mm=h,W1_mm3=S,e_mm=e,fd=fd,Fbc_design_MPa=F,
        first_yield_N=fy*S/(G1*e),stability_N=F*S/e,
        model_domain=dict(equal_top_bottom=True,c_le_2d=c<=2*d,dc_le_0p2d=dc<=.2*d))

def fixture(*,V=100000.,angle_top=47.5,web_end=40.,support_end=40.,gap=10.,c=130.,dc=30.,d=355.,tw=7.2,support_tw=7.2,n=4,L=260.,pitch=60.,db=20.,dh=22.,dn=24.,t=6.4,g=45.,b=76.,r=15.,fub=830.,threads_excluded=False):
    fy,fu,fya,fua=345.,450.,250.,400.
    adopted=max(abs(V),45000.);directions=[1,-1] if V==0 else [1 if V>0 else -1]
    y=[angle_top+web_end+i*pitch for i in range(n)]
    sy=[angle_top+support_end+i*pitch for i in range(n)]
    bottom=L-web_end-(n-1)*pitch;sbottom=L-support_end-(n-1)*pitch
    bolt=(.56 if threads_excluded else .45)*math.pi*db*db/4*fub/G2
    h0=d-2*dc;S=tw*h0*h0/6
    values={}
    def check(identifier,capacity,fraction,**data):
        values[identifier]=dict(capacity_N=capacity,fraction=fraction,demand_N=adopted*fraction,actual_demand_N=abs(V)*fraction,
            utilization=adopted*fraction/capacity,equivalent_full_V_capacity_N=capacity/fraction,**data)
    def bear(k,t,fu,n,pitch,E,direction,fraction):
        caps=[]
        for i in range(n):
            terminal=i==(0 if direction=='up' else n-1)
            lc=None if terminal and E is None else E-dh/2 if terminal else pitch-dh
            R=(2.4*db if lc is None else min(1.2*lc,2.4*db))*t*fu/G2
            caps.append(R);check(k+f'.hole{i+1}',R,fraction/n,clear_mm=lc,direction=direction,terminal=terminal,thickness_mm=t)
        check(k+'.sum',sum(caps),fraction,per_hole_N=caps)
    def blocks(k,t,fy,fu,E,width,fraction,Cts=1.):
        for j in range(1,n+1):
            Ag=(E+(j-1)*pitch)*t;An=Ag-(j-.5)*dn*t;Ant=(width-dn/2)*t
            R=(min(.6*fu*An,.6*fy*Ag)+Cts*fu*Ant)/G2
            check(k+f'.prefix{j}',R,fraction*j/n,k=j,Agv_mm2=Ag,Anv_mm2=An,Ant_mm2=Ant,Cts=Cts)
    # Two serial interfaces. Beam bolts each have two planes; support bolts one.
    check('beam_bolts',2*n*bolt,1.,planes_per_bolt=2,physical_count=n)
    check('support_bolts',2*n*bolt,1.,planes_per_bolt=1,physical_count=2*n)
    for side in ['negative','positive']:
        for leg in ['beam','support']:
            check(f'angle.{side}.{leg}.gross',.6*fya*L*t/G1,.5,Ag_mm2=L*t)
            check(f'angle.{side}.{leg}.net',.6*fua*(L-n*dn)*t/G2,.5,An_mm2=(L-n*dn)*t)
    check('beam_web.gross',.6*fy*h0*tw/G1,1.,Ag_mm2=h0*tw)
    check('beam_web.net',.6*fu*(h0-n*dn)*tw/G2,1.,An_mm2=(h0-n*dn)*tw)
    m=model(d,tw,dc,c,gap,fy)
    check('cope.first_yield',m['first_yield_N'],1.)
    check('cope.stability',m['stability_N'],1.)
    for sign in directions:
        s='positive' if sign>0 else 'negative'
        beam_dir='down' if sign>0 else 'up';support_dir='up' if sign>0 else 'down'
        for side in ['negative','positive']:
            bear(f'angle.{side}.beam.{s}',t,fua,n,pitch,bottom if sign>0 else web_end,beam_dir,.5)
            bear(f'angle.{side}.support.{s}',t,fua,n,pitch,support_end if sign>0 else sbottom,support_dir,.5)
            blocks(f'angle.{side}.beam.{s}',t,fya,fua,bottom if sign>0 else web_end,b-g,.5)
            blocks(f'angle.{side}.support.{s}',t,fya,fua,support_end if sign>0 else sbottom,b-g,.5)
            bear(f'support_web.{side}.{s}',support_tw,fu,n,pitch,None,beam_dir,.5)
        # Straight-cope fixture; do not silently generalize block geometry to fillets.
        E=y[0]-dc if sign>0 else d-dc-y[-1]
        bear(f'beam_web.{s}',tw,fu,n,pitch,E,support_dir,1.)
        blocks(f'beam_web.{s}',tw,fy,fu,E,g-gap,1.)
    governing=min(values,key=lambda k:values[k]['equivalent_full_V_capacity_N'])
    return dict(inputs=dict(V_N=V,Vd_magnitude_N=adopted,d_mm=d,tw_mm=tw,support_tw_mm=support_tw,fy_MPa=fy,fu_MPa=fu,angle_fy_MPa=fya,angle_fu_MPa=fua,fub_MPa=fub,n=n,angle_length_mm=L,angle_top_mm=angle_top,web_end_top_mm=web_end,support_end_top_mm=support_end,pitch_mm=pitch,db_mm=db,dh_mm=dh,dn_mm=dn,angle_t_mm=t,angle_leg_mm=b,gauge_mm=g,c_mm=c,dc_mm=dc,gap_mm=gap,r_mm=r,threads_excluded=threads_excluded),
        geometry=dict(beam_holes_y_mm=y,support_holes_y_mm=sy,beam_bolt_x_mm=g,beam_bolt_to_end_mm=g-gap,
            support_column_x_mm=[-tw/2-g,tw/2+g],angle_web_end_bottom_mm=bottom,angle_support_end_bottom_mm=sbottom,
            web_top_edge_mm=y[0]-dc,web_bottom_edge_mm=d-dc-y[-1],beam_grip_mm=tw+2*t,support_grip_mm=support_tw+t,
            bolt_count=n+2*n,physical_support_webs=1),
        cope=m,bolt_one_plane_N=bolt,checks=values,governing=governing,capacity_N=values[governing]['equivalent_full_V_capacity_N'],
        real_girder_reaction_N=V,adopted_connection_force_N=adopted,
        qualification='Synthetic externally-qualified boundary condition for numerical testing only, not a real brace design.',
        scope='Conventional local connection; support member global/perforated member-section strength and external brace qualification remain separate.')

if __name__=='__main__':
    cases={
        'baseline_W355_equal30_c130':fixture(),
        'baseline_reversed':fixture(V=-100000.),
        'asymmetric_group_down':fixture(angle_top=37.5,web_end=35.,support_end=35.),
        'asymmetric_group_up':fixture(V=-100000.,angle_top=37.5,web_end=35.,support_end=35.),
        'minimum45_zero_both_directions':fixture(V=0.,angle_top=37.5,web_end=35.,support_end=35.),
        'setback20_real_lever':fixture(gap=20.),
        'thin_support1p5_bearing_governs':fixture(support_tw=1.5,V=200000.),
        'threads_excluded':fixture(threads_excluded=True),
        'deep_equal_cope20percent':fixture(dc=71.),
        'thin_supported_web_long_cope':fixture(d=400.,tw=3.,dc=40.,c=300.,angle_top=70.),
        'thick_web_source_probe':fixture(d=400.,tw=8.,dc=40.,c=130.,angle_top=70.),
        'historical_geometry_formula_only':fixture(n=3,L=230.,pitch=75.,angle_top=35.,dc=30.,c=130.,V=202000.)}
    points=[]
    for x in [10.,115.,125.,130.,139.,140.,141.]:
        points.append(dict(x_mm=x,top_mm=boundary(x,130.,30.,15.),bottom_mm=355.-boundary(x,130.,30.,15.),
            distance_to_top_from_y60_mm=cope_clearance(x,60.,130.,30.,15.)))
    cm=model(40.,.8,4.,13.,1.,34.5)
    # Direct printed equation in kN/cm, independently evaluated.
    hcm=40.-8.;Scm=.8*hcm*hcm/6
    fcm=35060.*.8**2/(13.*hcm)*(3.5-7.5*4./40.)
    vcm=fcm*Scm/14.
    assert math.isclose(vcm*1000.,cases['thick_web_source_probe']['cope']['stability_N'],rel_tol=1e-13)
    assert math.isclose(cases['baseline_W355_equal30_c130']['capacity_N'],cases['baseline_reversed']['capacity_N'],rel_tol=1e-13)
    assert cases['asymmetric_group_down']['checks']['beam_web.positive.prefix1']['capacity_N'] != cases['asymmetric_group_up']['checks']['beam_web.negative.prefix1']['capacity_N']
    assert cases['thin_supported_web_long_cope']['cope']['stability_N']<45000.
    assert cases['thin_support1p5_bearing_governs']['governing'].startswith('support_web.')
    record=dict(status='FROZEN_INDEPENDENT_R017_NUMERICAL_FIXTURES',oracle_implementation='Python stdlib only; no production imports or production outputs.',
        sources=['NBR8800:2024 corrected2025 clauses6.3.3.2/6.3.3.3/6.5.5/6.5.6 and Figure16(b)','Gerdau2018 pp20,23–25','Dowswell & Whyte2014 pp43–45, Eq1–4 and Fig1'],
        limitations=['Synthetic fixtures do not certify actual external bracing or supply supporting-girder global forces.','Rows deliberately outside fabrication/detail limits remain numerical/component fixtures, not passing production presets.','No optional supporting-girder member-section model is invented.'],
        units=dict(force='N',length='mm',stress='MPa'),gamma_a1=G1,gamma_a2=G2,
        historical_discrepancy=dict(table_V_kN=266.,formula_V_kN=cases['historical_geometry_formula_only']['cope']['first_yield_N']/1000.,status='UNRESOLVED_NOT_AN_EXACT_CAPACITY_ORACLE_NO_CALIBRATION'),
        dimensional_equivalence=dict(printed_kN_per_cm_coefficient=35060.,MPa_coefficient=350600.,V_printed_kN=vcm,coefficient_from_phi_0p9=.9*.62*math.pi*200000.),
        rounded_boundary_points=points,fixtures=cases)
    (ROOT/'r017_independent_fixtures.json').write_text(json.dumps(record,indent=2)+'\n')
    for name,f in cases.items(): print(name,'capacity_kN',f['capacity_N']/1000,'governing',f['governing'],'yield_kN',f['cope']['first_yield_N']/1000,'stability_kN',f['cope']['stability_N']/1000)
    print('Independent source/units/reversal/thin-support assertions: PASS')
