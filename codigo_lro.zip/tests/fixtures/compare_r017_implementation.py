"""Read production outputs and compare them with separately frozen source oracles.
The imported engine is only the subject under test, never the oracle.
"""
from __future__ import annotations
import json, math, sys, hashlib
from pathlib import Path
from dataclasses import replace
FOLDER=Path(__file__).resolve().parent
ROOT=FOLDER.parents[1]  # package source root: tests/fixtures -> source
sys.path.insert(0,str(ROOT))
from lro.coped_double_angle import CopedDoubleAngle,presets,evaluate,cope_model,cope_boundary,cope_edge_distance,support_boundary_actions
oracle=json.loads((FOLDER/'r017_independent_fixtures.json').read_text())
records=[];failures=[];case_status={}
def near(label,actual,expected):
    ok=isinstance(actual,(int,float)) and math.isclose(actual,expected,rel_tol=3e-12,abs_tol=2e-7)
    r=dict(assertion=label,actual=actual,expected=expected,passed=ok);records.append(r)
    if not ok:failures.append(r)
def expect(label,value,**details):
    r=dict(assertion=label,passed=bool(value),**details);records.append(r)
    if not value:failures.append(r)
def qualified(c):
    return replace(c,restraint_top_system='Synthetic independently checked lateral brace at top cope face',restraint_top_ref='R017 verification fixture: external boundary assumption only; not a physical brace design',restraint_top_x=c.gap+c.c_top,
        restraint_bottom_system='Synthetic independently checked lateral brace at bottom cope face',restraint_bottom_ref='R017 verification fixture: external boundary assumption only; not a physical brace design',restraint_bottom_x=c.gap+c.c_bottom)
base=next(iter(presets().values()))
# Map only fixture inputs, without querying preset output or reverse-fitting constants.
def from_oracle(f):
    i=f['inputs'];synthetic=i['d_mm']!=355.
    beam=replace(base.beam,d=i['d_mm'],tw=i['tw_mm'],tf=12. if synthetic else 11.6,clear=352. if synthetic else 308.)
    if synthetic:beam=replace(beam,name='Synthetic supported W-shaped geometry',source='Independent geometric test input; not a catalog product')
    support=replace(base.support,tw=i['support_tw_mm'],d=i['d_mm'] if synthetic else 355.,tf=12. if synthetic else 11.6,clear=352. if synthetic else 308.)
    if synthetic or i['support_tw_mm']!=7.2:support=replace(support,name='Synthetic supporting W-shaped geometry',source='Independent geometric test input; not a catalog product')
    return qualified(replace(base,beam=beam,support=support,V=i['V_N'],angle_top=i['angle_top_mm'],web_end_top=i['web_end_top_mm'],support_end_top=i['support_end_top_mm'],
        gap=i['gap_mm'],c_top=i['c_mm'],c_bottom=i['c_mm'],dc_top=i['dc_mm'],dc_bottom=i['dc_mm'],r_top=i['r_mm'],r_bottom=i['r_mm'],
        web_rows=i['n'],support_rows=i['n'],length=i['angle_length_mm'],web_pitch=i['pitch_mm'],support_pitch=i['pitch_mm'],
        web_threads_excluded=i['threads_excluded'],support_threads_excluded=i['threads_excluded']))
def production_key(k):
    if k=='beam_bolts':return 'bolt_shared_web'
    if k=='support_bolts':return None
    if k=='cope.first_yield':return 'cope_first_yield'
    if k=='cope.stability':return 'cope_complementary_stability'
    p=k.split('.')
    if p[0]=='angle':
        root=f'angle_{p[1]}_{p[2]}'
        if len(p)==4:return root+'_shear_'+p[3]
        sign,tail=p[3:]
    elif p[0]=='beam_web':
        root='beam_web'
        if len(p)==2:return root+'_shear_'+p[1]
        sign,tail=p[1:]
    else:root=f'support_web_{p[1]}';sign,tail=p[2:]
    root += '_Vpos' if sign=='positive' else '_Vneg'
    return root+('_bearing_group' if tail=='sum' else '_bearing_'+tail if tail.startswith('hole') else '_block_k'+tail.removeprefix('prefix'))
outputs={}
for name,f in oracle['fixtures'].items():
    i=f['inputs'];model=cope_model(i['d_mm'],i['tw_mm'],i['dc_mm'],i['c_mm'],i['gap_mm'],i['fy_MPa'])
    for k in ['h0_mm','W1_mm3','e_mm','fd','Fbc_design_MPa','first_yield_N','stability_N']:near(name+'.model.'+k,model[k],f['cope'][k])
    if name=='deep_equal_cope20percent':continue # The baseline angle cannot fit this deep cut; formula domain probe only.
    c=from_oracle(f);out=evaluate(c);outputs[name]=out;case_status[name]={'status':out['status'],'local_pass':out['local_pass'],'check_count':len(out['checks'])}
    actual={x['id']:x for x in out['checks']}
    expect(name+'.numeric_checks_available',bool(actual),status=out['status'])
    if not actual:continue
    for k,e in f['checks'].items():
        key=production_key(k)
        if key is None:
            near(name+'.support_bolts.combined',actual['bolt_support_negative']['design_capacity_N']+actual['bolt_support_positive']['design_capacity_N'],e['capacity_N']);continue
        expect(name+'.check_exists.'+key,key in actual)
        if key not in actual:continue
        a=actual[key]
        for ak,ek in [('design_capacity_N','capacity_N'),('demand_fraction_of_total_V','fraction'),('demand_N','demand_N'),('actual_demand_N','actual_demand_N'),('utilization','utilization'),('equivalent_total_V_capacity_N','equivalent_full_V_capacity_N')]:near(name+'.'+key+'.'+ak,a[ak],e[ek])
        for ek in ['Agv_mm2','Anv_mm2','Ant_mm2','Ag_mm2','An_mm2','Cts']:
            if ek in e:near(name+'.'+key+'.'+ek,a[ek],e[ek])
        if 'clear_mm' in e:
            if e['clear_mm'] is None:expect(name+'.'+key+'.no_free_terminal_edge',a['clear_distance_mm'] is None)
            else:near(name+'.'+key+'.clear_distance_mm',a['clear_distance_mm'],e['clear_mm'])
            expect(name+'.'+key+'.direction',a['loaded_direction']==e['direction'])
    near(name+'.total_capacity',out['summary']['equivalent_total_V_capacity_N'],f['capacity_N'])
    near(name+'.actual_reaction',out['load_model']['girder_delivered_vertical_force_N'],i['V_N'])
    near(name+'.adopted_magnitude',abs(out['load_model']['Vd_N']),i['Vd_magnitude_N'])
    expect(name+'.global_never_claimed',not out['global_pass'] and out['member_global_status']=='EXTERNAL_NOT_EVALUATED')
    expect(name+'.one_support_web',out['support_web']['physical_web_count']==1 and out['components']['support_web']['web_thickness_count']==1)
    expect(name+'.support_real_hole_count',out['support_web']['hole_count']==2*i['n'])
    expect(name+'.no_fictitious_support_blocks',not any('support_web' in x and 'block' in x for x in actual))
    expect(name+'.intact_I_coefficient_not_applied_to_cope','beam_web_shear_buckling' not in actual and 'beam_uncut_web_shear' in actual)
    for j,x in enumerate(f['geometry']['support_column_x_mm']):near(name+f'.support_column{j}',out['geometry']['support_hole_x_mm'][j],x)
    for sign in ([1,-1]if i['V_N']==0 else[1 if i['V_N']>0 else-1]):
        suffix='_Vpos'if sign>0 else'_Vneg'
        expected=sum(f['checks'][f'support_web.{side}.{"positive" if sign>0 else "negative"}.sum']['capacity_N']for side in ['negative','positive'])
        near(name+'.support_single_web_hole_sum'+suffix,actual['support_web_total'+suffix+'_bearing_group']['design_capacity_N'],expected)
# Default must stay numerically useful but cannot qualify the missing face brace.
default=evaluate(base)
expect('default.pending_not_local_pass',default['status']=='ENGINEERING_MODEL_PENDING' and not default['local_pass'])
expect('default.strength_result_preserved',default['summary']['strength_status']=='PASS' and len(default['checks'])>=70)
expect('qualified_baseline.local_pass',outputs['baseline_W355_equal30_c130']['local_pass'])
expect('qualified_reversal.bottom_required',outputs['baseline_reversed']['restraints']['required_compression_faces']==['bottom'])
expect('zero.requires_both_braces',outputs['minimum45_zero_both_directions']['restraints']['required_compression_faces']==['top','bottom'])
expect('thin_coped_web.instability_governs',outputs['thin_supported_web_long_cope']['summary']['governing_check_id']=='cope_complementary_stability')
expect('thin_support.failure_preserved',not outputs['thin_support1p5_bearing_governs']['local_pass'] and outputs['thin_support1p5_bearing_governs']['summary']['governing_check_id'].startswith('support_web'))
# Boundary geometry: absent free edge past cope face is intentionally None.
for p in oracle['rounded_boundary_points']:
    x=p['x_mm']
    for side in ['top','bottom']:
        v=cope_boundary(base,x,side)
        if x>base.gap+base.c_top:expect(f'boundary.{side}.{x}.no_fictitious_extension',v is None)
        else:near(f'boundary.{side}.{x}',v,p[side+'_mm'])
    near(f'boundary.shortest_clearance.{x}',cope_edge_distance(base,x,60.,'top'),p['distance_to_top_from_y60_mm'])
    near(f'boundary.mirrored_clearance.{x}',cope_edge_distance(base,x,base.beam.d-60.,'bottom'),p['distance_to_top_from_y60_mm'])
# Real geometric/model limits, no fabricated 170 mm rule.
q=qualified(base)
for name,c in {
 'missing_top':replace(q,restraint_top_ref=''), 'wrong_top_location':replace(q,restraint_top_x=130.),
 'only_top_brace_under_reversal':replace(q,V=-100000.,restraint_bottom_ref=''), 'only_top_brace_at_zero':replace(q,V=0.,restraint_bottom_ref=''),
 'unequal_lengths':replace(q,c_bottom=131.),'unequal_depths':replace(q,dc_bottom=31.),
 'deep_copes_outside_old_model':replace(q,dc_top=71.001,dc_bottom=71.001),
 'cope_length_outside_old_model':qualified(replace(q,c_top=711.,c_bottom=711.)),
 'N_unsupported':replace(q,N=1.),'M_unsupported':replace(q,M=1.),'torsion_unsupported':replace(q,torsion=1.),
 'single_angle':replace(q,angle_count=1),'asymmetry':replace(q,symmetric=False),'multi_column':replace(q,web_columns=2),
 'support_flange_wrong_family':replace(q,kind='column_flange'),'single_cope':replace(q,cope='top'),
 'fatigue':replace(q,static=False),'slip':replace(q,no_slip_required=True),'support_opening':replace(q,support_intact=False),
 'back_access_unresolved':replace(q,support_back_access=False),'zero_gap':qualified(replace(q,gap=0.)),
 'extended_gauge':replace(q,beam_gauge=50.),'support_eccentricity':replace(q,support_eccentricity=25.),
 'flange_collision':qualified(replace(q,c_top=60.,c_bottom=60.)), 'excess_angle_height':replace(q,length=320.),
 'radius_exceeds_depth':replace(q,r_top=31.),'hole_crosses_cope':replace(q,angle_top=0.,web_end_top=31.),
 'overstrength':replace(q,V=500000.),'infinite_V':replace(q,V=float('inf')),'nan_cope':replace(q,c_top=float('nan')),
 'large_number':replace(q,c_top=1e308,c_bottom=1e308),
 }.items():
    r=evaluate(c);expect('failclosed.'+name,not r['local_pass'],status=r['status'])
long=evaluate(qualified(replace(q,c_top=200.,c_bottom=200.)))
expect('continuous_domain.c200_approved',long['local_pass'] and long['cope']['geometry_within_domain'])
for d,dc,c,within in [(400.,40.,800.,True),(400.,40.,800.001,False),(400.,80.,300.,True),(400.,80.001,300.,False)]:
    m=cope_model(d,3.,dc,c,10.,345.);expect(f'model_domain.d{d}.dc{dc}.c{c}',m['geometry_within_domain']==within)
    expect(f'model_domain.no_outside_stability.dc{dc}.c{c}',(m['stability_N']is not None)==within)
# Optional equilibrium helper never supplies capacities or invents a span split.
s=json.loads((FOLDER/'support_equilibrium_independent.json').read_text());i=s['input'];e=s['expected']
a=support_boundary_actions(i['V_N'],i['V_left_N'],i['V_right_N'],i['x_left_mm'],i['M_left_Nmm'],i['columns_x_mm'])
near('support_equilibrium.middle_shear',a['V_between_columns_N'],e['V_between_N']);near('support_equilibrium.residual',a['shear_jump_residual_N'],0.)
for j,M in enumerate(e['M_at_columns_Nmm']):near(f'support_equilibrium.column{j}.M',a['columns'][j]['M_Nmm'],M)
expect('support_equilibrium.only',a['equilibrium_only'] and not a['capacity_checks_performed'])
bad=support_boundary_actions(200000.,300000.,0.,-100.,2000000.,[-48.6,48.6]);expect('support_equilibrium.reject_bad_jump',not bad['equilibrium_closes'])
for t in s['torque_examples']:
    a=evaluate(qualified(replace(base,V=t['V_N'],support_eccentricity=t['eccentricity_z_mm'])))
    near('support_torque.'+str(t),a['load_model']['girder_delivered_torsion_Nmm'],t['Tx_Nmm'])
    if t['eccentricity_z_mm']:expect('support_torque.local_incomplete',not a['local_pass'])
expect('roundtrip.qualified',CopedDoubleAngle.from_dict(q.to_dict())==q)
for kind in ['topology','gamma_a1','cope_model']:
    data=q.to_dict();data['fixed_assumptions'][kind]='tampered'
    try:CopedDoubleAngle.from_dict(data)
    except ValueError:expect('roundtrip.reject_'+kind,True)
    else:expect('roundtrip.reject_'+kind,False)
supp=json.loads((FOLDER/'r017_supplemental_fixtures.json').read_text())
for name,out in outputs.items():
    actual={r['id']:r for r in out['checks']}; e=supp['uncut_member'][name]
    row=actual['beam_uncut_web_shear']
    near(name+'.uncut_member.resistance',row['design_capacity_N'],e['Rd_N'])
    for key in ['lambda_web','lambda_p','lambda_r','Cv']:near(name+'.uncut_member.'+key,row[key],e[key])
for j,e in enumerate(supp['long_grip']):
    c=replace(q,beam=replace(q.beam,tw=e['beam_tw_mm']),support=replace(q.support,tw=e['support_tw_mm']))
    out=evaluate(c);groups={r['id']:r for r in out['bolts']['groups']}
    for name,kind in [('shared_web','web'),('support_negative','support'),('support_positive','support')]:
        near(f'long_grip.{j}.{name}.grip',groups[name]['grip_mm'],e[kind+'_grip_mm'])
        near(f'long_grip.{j}.{name}.factor',groups[name]['grip_factor'],e[kind+'_factor'])
        near(f'long_grip.{j}.{name}.plane_capacity',groups[name]['resistance_per_plane_N'],e[kind+'_plane_Rd_N'])
source=ROOT/'lro/coped_double_angle.py'
report=dict(status='FAIL'if failures else'PASS',assertion_count=len(records),failure_count=len(failures),
    production_file=str(source.relative_to(ROOT)),production_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
    oracle_sha256=hashlib.sha256((FOLDER/'r017_independent_fixtures.json').read_bytes()).hexdigest(),
    case_status=case_status,failures=failures,results=records)
(FOLDER/'r017_implementation_comparison.json').write_text(json.dumps(report,indent=2)+'\n')
print(report['status'],len(records),'assertions;',len(failures),'failures')
for fail in failures:print(fail)
if failures:sys.exit(1)
