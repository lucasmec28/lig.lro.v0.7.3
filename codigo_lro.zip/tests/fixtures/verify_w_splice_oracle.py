#!/usr/bin/env python3
"""Independent numerical oracle: balanced M004 actual W splice in pure tension.

No application imports. Fractions preserve the decimal dimension/strength inputs;
only the circular bolt area uses floating point pi. This validates the stated
conventional code model, not fabrication or the whole building.
"""
from fractions import Fraction as Q
from pathlib import Path
import argparse
import json
import math


def f(x):
    return Q(str(x))


BASE = dict(
    profile="W 310 x 97,0 (H)", d=308, bf=305, tf=15.4, tw=9.9,
    A=12360, clear_web=245, member_fy=345, member_fu=450,
    outer_width=240, inner_width=120, inner_gap=50, flange_cover_t=16,
    web_cover_h=200, web_cover_t=10, cover_fy=250, cover_fu=400,
    bolt_d=20, physical_hole=22, net_hole=24, bolt_fub=800,
    flange_rows=4, web_rows=2, web_columns=3,
    flange_pitch=60, web_pitch_x=60, web_pitch_y=60,
    member_end_flange=40, cover_end_flange=40,
    member_end_web=40, cover_end_web=40, butt_gap=10,
    root_envelope_z=22, root_envelope_y=122.5, fabrication_clearance=3,
    tool_radius=25, tension_design_governs=True, adopt_recommendation=True,
)


def evaluate(identifier, N, **overrides):
    inp = BASE | overrides
    x = {k: f(v) for k, v in inp.items() if type(v) in (float, int)}
    ga1, ga2 = f(1.1), f(1.35)
    A, tf, tw, d, bf = (x[k] for k in ("A", "tf", "tw", "d", "bf"))
    fy, fu = x["member_fy"], x["member_fu"]
    py, pu = x["cover_fy"], x["cover_fu"]
    dn, dh, db = x["net_hole"], x["physical_hole"], x["bolt_d"]
    Aw = (d-2*tf)*tw
    Af = (A-Aw)/2
    aw, af = Aw/A, Af/A
    Nfloor = A*fy/ga1/2 if inp["adopt_recommendation"] else f(0)
    Nd = max(f(N), f(45000), Nfloor)
    checks = []

    def check(name, frac, R, **data):
        D = Nd*frac
        checks.append(dict(id=name, demand_N=float(D), capacity_N=float(R),
                           utilization=float(D/R), fraction_of_N=float(frac),
                           equivalent_N_capacity_N=float(R/frac),
                           status="PASS" if D <= R else "FAIL", **data))

    def tension(name, Ag, An, frac, fy0, fu0, cover):
        Ae = min(An, f(.85)*Ag) if cover else An
        check(name+"_gross", frac, Ag*fy0/ga1, Ag_mm2=float(Ag))
        check(name+"_net", frac, Ae*fu0/ga2, An_mm2=float(An), Ae_mm2=float(Ae))

    def bearing(name, frac, t, fu0, n, m, e, p):
        # Member force points toward butt; cover force points toward its remote
        # free end. The identical e/p values represent both physical mirrors.
        Re = min(f(1.2)*(e-dh/2)*t*fu0, f(2.4)*db*t*fu0)/ga2
        Ri = min(f(1.2)*(p-dh)*t*fu0, f(2.4)*db*t*fu0)/ga2
        check(name+"_bearing_end", frac/(n*m), Re, clear_mm=float(e-dh/2))
        check(name+"_bearing_internal", frac/(n*m), Ri, clear_mm=float(p-dh))
        check(name+"_bearing_group", frac, m*(Re+(n-1)*Ri))

    def block(name, frac, t, fy0, fu0, L, k, legs, Ant, Cts):
        Agv=legs*L*t
        Anv=legs*(L-(f(k)-f(.5))*dn)*t
        R=(min(f(.6)*fu0*Anv, f(.6)*fy0*Agv)+Cts*fu0*Ant)/ga2
        assert min(Agv, Anv, Ant)>0
        check(name, frac, R, Agv_mm2=float(Agv), Anv_mm2=float(Anv),
              Ant_mm2=float(Ant), Cts=float(Cts))

    Anwhole=A-4*dn*tf-3*dn*tw
    tension("whole_W", A, Anwhole, f(1), fy, fu, False)
    # Fillet area enters the flange demand, but no fillet resistance is credited
    # in the deliberately conservative local rectangular-flange checks.
    tension("each_W_flange", bf*tf, (bf-2*dn)*tf, af, fy, fu, False)
    tension("W_web", Aw, Aw-3*dn*tw, aw, fy, fu, False)
    bo, bi, c, tc = (x[k] for k in ("outer_width","inner_width","inner_gap","flange_cover_t"))
    h, tcw = x["web_cover_h"], x["web_cover_t"]
    g=bi+c
    tension("each_outer_flange_cover", bo*tc, (bo-2*dn)*tc, af/2, py, pu, True)
    tension("each_inner_flange_strip", bi*tc, (bi-dn)*tc, af/4, py, pu, True)
    tension("each_web_cover", h*tcw, (h-3*dn)*tcw, aw/2, py, pu, True)
    nf, nw = int(x["flange_rows"]), int(x["web_rows"])
    pf, pw = x["flange_pitch"], x["web_pitch_x"]
    bolt_plane_R = .45*math.pi*float(db)**2/4*float(x["bolt_fub"])/float(ga2)
    check("each_flange_bolt_plane", af/(4*nf), bolt_plane_R)
    check("each_web_bolt_plane", aw/(2*nw*3), bolt_plane_R)
    for name, frac, t, fu0, n, m, e, p in (
        ("W_flange",af,tf,fu,nf,2,x["member_end_flange"],pf),
        ("outer_cover",af/2,tc,pu,nf,2,x["cover_end_flange"],pf),
        ("inner_strip",af/4,tc,pu,nf,1,x["cover_end_flange"],pf),
        ("W_web",aw,tw,fu,nw,3,x["member_end_web"],pw),
        ("web_cover",aw/2,tcw,pu,nw,3,x["cover_end_web"],pw)):
        bearing(name,frac,t,fu0,n,m,e,p)

    # Main-flange L1 exits at real outside flange edge. Its mirrored pair is
    # the source Fig.A13 mechanism. No fictitious isolated central-flange U.
    for k in range(1,nf+1):
        Lm=x["member_end_flange"]+(k-1)*pf
        Lc=x["cover_end_flange"]+(k-1)*pf
        for side in ("left","right"):
            block(f"W_flange_L1_{side}_k{k}",af*f(k)/(2*nf),tf,fy,fu,Lm,k,1,
                  ((bf-g)/2-dn/2)*tf,f(1))
            block(f"outer_L1_{side}_k{k}",af/2*f(k)/(2*nf),tc,py,pu,Lc,k,1,
                  ((bo-g)/2-dn/2)*tc,f(1))
            block(f"outer_L2_{side}_k{k}",af/2*f(k)/nf,tc,py,pu,Lc,k,1,
                  ((bo+g)/2-f(1.5)*dn)*tc,f(.5))
            block(f"inner_L_{side}_k{k}",af/4*f(k)/nf,tc,py,pu,Lc,k,1,
                  (bi/2-dn/2)*tc,f(1))
        block(f"outer_U_k{k}",af/2*f(k)/nf,tc,py,pu,Lc,k,2,(g-dn)*tc,f(1))

    for name, frac, t, fy0, fu0, end, free_sides in (
        ("W_web",aw,tw,fy,fu,x["member_end_web"],False),
        ("web_cover",aw/2,tcw,py,pu,x["cover_end_web"],True)):
        for k in range(1,nw+1):
            L=end+(k-1)*pw
            for m, labels in ((2,("lower_pair","upper_pair")), (3,("all_three",))):
                for label in labels:
                    block(f"{name}_U_{label}_k{k}",frac*f(k*m)/(nw*3),t,fy0,fu0,
                          L,k,2,(m-1)*(x["web_pitch_y"]-dn)*t,f(1))
            if free_sides:
                ey=(h-2*x["web_pitch_y"])/2
                for m in (1,2,3):
                    Ant=(ey+(m-1)*x["web_pitch_y"]-(f(m)-f(.5))*dn)*t
                    for side in ("top","bottom"):
                        block(f"{name}_L{m}_{side}_k{k}",frac*f(k*m)/(nw*3),t,fy0,fu0,
                              L,k,1,Ant,f(1) if m==1 else f(.5))

    detail=[]
    def geom(name, val, lower=None, upper=None):
        ok=(lower is None or val>=lower) and (upper is None or val<=upper)
        detail.append(dict(id=name,value=float(val),minimum=None if lower is None else float(lower),
                           maximum=None if upper is None else float(upper),pass_check=ok))
    geom("balance_bo_equals_2bi",bo-2*bi,0,0)
    geom("outer_within_flange",bo,0,bf)
    geom("inner_pair_within_flange",c+2*bi,0,bf)
    geom("inner_web_cover_clearance_each",(c-tw-2*tcw)/2,0)
    geom("web_cover_inner_flange_cover_clearance",(d-2*tf-2*tc-h)/2,0)
    geom("inner_root_clearance",c/2-x["root_envelope_z"],x["fabrication_clearance"])
    geom("web_cover_root_clearance",x["root_envelope_y"]-h/2,x["fabrication_clearance"])
    geom("flange_bolt_to_web_cover_tool_clearance",g/2-tw/2-tcw,x["tool_radius"]+x["fabrication_clearance"])
    geom("web_bolt_to_inner_flange_tool_clearance",d/2-tf-tc-x["web_pitch_y"],x["tool_radius"]+x["fabrication_clearance"])
    minspace=max(f(2.7)*db,dh+db)
    for label,val,tmin in (("flange_pitch",pf,min(tf,tc)),("flange_gauge",g,min(tf,tc)),
                           ("web_pitch_x",pw,min(tw,tcw)),("web_pitch_y",x["web_pitch_y"],min(tw,tcw))):
        geom(label,val,minspace,min(24*tmin,f(300)))
    for name,edge,t in (("outer_edge",(bo-g)/2,tc),("inner_edge",bi/2,tc),
                        ("member_flange_edge",(bf-g)/2,tf),
                        ("web_cover_edge",(h-2*x["web_pitch_y"])/2,tcw),
                        ("member_flange_end",x["member_end_flange"],tf),
                        ("cover_flange_end",x["cover_end_flange"],tc),
                        ("member_web_end",x["member_end_web"],tw),
                        ("cover_web_end",x["cover_end_web"],tcw)):
        geom(name,edge,26,min(12*t,f(150)))
    geom("flange_grip",tf+2*tc,0,5*db)
    geom("web_grip",tw+2*tcw,0,5*db)
    geom("flange_total_extreme_bolt_span",x["butt_gap"]+2*(x["member_end_flange"]+(nf-1)*pf),0,950)
    geom("web_total_extreme_bolt_span",x["butt_gap"]+2*(x["member_end_web"]+(nw-1)*pw),0,950)
    for label,end in (("flange",x["member_end_flange"]),("web",x["member_end_web"])):
        geom(label+"_cover_butt_spacing",2*end+x["butt_gap"],minspace)
    critical=min(checks,key=lambda z:z["equivalent_N_capacity_N"])
    return dict(id=identifier,input=inp|{"N_requested_N":N,"M_Nmm":0,"V_N":0},
                N_design_N=float(Nd),N_minimum_recommendation_N=float(Nfloor),
                allocation=dict(Aw_mm2=float(Aw),Af_allocated_each_mm2=float(Af),
                                rectangular_Af_each_mm2=float(bf*tf),
                                roots_not_in_rectangles_mm2=float(A-Aw-2*bf*tf),
                                N_web_N=float(Nd*aw),N_each_flange_N=float(Nd*af)),
                gross_W_mm2=float(A),net_W_envelope_mm2=float(Anwhole),
                actual_flange_station_min_net_mm2=float(A-4*dn*tf),
                checks=checks,detailing=detail,
                M004_preset_deviations=["M20 outer lateral edge 35 mm < drawing 40 mm; NBR table minimum 26 mm passes. Explicit dimensioned specialization required."],
                governing_check=critical["id"],equivalent_N_capacity_N=critical["equivalent_N_capacity_N"],
                resistance_pass=all(q["status"]=="PASS" for q in checks),
                geometry_pass=all(q["pass_check"] for q in detail))


def fixture():
    cases=[evaluate("catalog_W_floor_PASS",1_000_000),
           evaluate("catalog_W_2p2MN_PASS",2_200_000),
           evaluate("catalog_W_2p25MN_web_U_FAIL",2_250_000),
           evaluate("catalog_W_3p5MN_multiple_FAIL",3_500_000)]
    assert cases[0]["resistance_pass"] and cases[1]["resistance_pass"]
    assert not cases[2]["resistance_pass"]
    assert all(c["geometry_pass"] for c in cases)
    assert cases[0]["governing_check"]=="W_web_U_all_three_k2"
    assert all(q["status"]=="PASS" for q in cases[2]["checks"] if q["id"]!="W_web_U_all_three_k2")
    return dict(schema_version=1,scope="Balanced actual W M004 topology, pure concentric static tension only; conventional ULS resistance and explicit geometry. Not whole-building or fabrication approval.",
                sources=dict(NBR="User-supplied ABNT NBR8800:2024/Er1:2025 §§5.2,6.1.5,6.3,6.5",profile="https://gsn.gerdau.com/sites/gsn_gerdau/files/downloadable_files/Folder%20Perfis%20Estruturais%20Gerdau%20-%20Segmento%20Industrial.pdf p.3",paths="https://www.steelconstruction.info/images/f/f0/SBE_SS5.pdf Appendix A Figs.A9,A13,A14; geometry only"),
                bolt_material_note="fub=800 MPa is a declared conservative numerical test input. It is not an automatic ASTM grade mapping or material certificate.",
                construction_note="Root envelope and 25 mm tool radius are explicit fixture design inputs; confirm actual rolling tolerance, bolt/washer/tool and installation on a project.",
                hole_policy_regression=dict(bolt_d_mm=24,physical_drawing_hole_mm=26,
                    table14_maximum_hole_mm=27,ordinary_net_deduction_mm=29,
                    drilled_net_deduction_mm=27,wrong_actual_plus2_mm=28,
                    correct_W_net_envelope_mm2=9712.3,wrong_W_net_envelope_mm2=9803.6,
                    note="Keep physical bearing/clearance diameter separate from the Table14 maximum used by5.2.4.1(a). This is a hole-policy regression, not a geometrically qualified M24 assembly."),
                representative_multiplicity="Main flanges: four member-end transfer regions; outer covers: two physical covers, two series sides each; inner: four physical strips, two sides each; web: two member ends and two physical covers with two sides each. Symmetric duplicates have equal utilization and are not added as capacities.",
                cases=cases)


if __name__=="__main__":
    ap=argparse.ArgumentParser();ap.add_argument("--check",action="store_true");args=ap.parse_args()
    data=fixture();path=Path(__file__).with_name("axial_tension_completion_fixtures.json")
    if args.check:
        assert json.loads(path.read_text())==data
    else:
        path.write_text(json.dumps(data,indent=2,ensure_ascii=False)+"\n")
    for c in data["cases"]:
        print(c["id"],"Nd=",c["N_design_N"],"capacity=",c["equivalent_N_capacity_N"],
              c["governing_check"],"PASS" if c["resistance_pass"] else "FAIL")
