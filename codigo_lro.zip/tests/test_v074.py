"""Ressalvas devem permitir estudar o detalhe sem produzir aprovação indevida."""
from dataclasses import replace
from io import BytesIO
from pathlib import Path
import json, math
import pytest
from docx import Document
from streamlit.testing.v1 import AppTest
from lro.end_plate import EndPlate, evaluate, presets
from lro.end_plate_report import create_report
from lro.models import Result, Issue, Check, profiles

ROOT=Path(__file__).resolve().parents[1]
W200=EndPlate.from_dict(json.loads((ROOT/'examples/Caso_usuario_W200_v074.json').read_text()))
W410=replace(W200,beam=profiles()['W 410 x 46,1'])
MOM=list(presets().values())[2]
PIN=list(presets().values())[0]

def test_w200_input_is_preserved_and_all_checks_are_computed():
    before=W200.to_dict();r=evaluate(W200)
    assert len(r.checks)==17 and all(math.isfinite(x.ratio) for x in r.checks)
    assert r.status=='CÁLCULO COM RESSALVAS · EXTRAPOLAÇÃO DO MODELO'
    assert len([i for i in r.issues if i.severity=='extrapolation'])==2
    assert W200.to_dict()==before and r.geometry['actual_actions']['M']==2941995
    assert max(x.ratio for x in r.checks)==pytest.approx(.8275395954)

def test_w410_spacing_is_a_nonblocking_noncompliance():
    r=evaluate(W410)
    assert r.checks and r.status=='NÃO ATENDE AO DETALHAMENTO'
    assert any(i.severity=='noncompliance' and '290.6' in i.text and '244.8' in i.text for i in r.issues)
    assert create_report(W410,r)[:2]==b'PK'

@pytest.mark.parametrize('layout,sign',[('both',1),('both',-1),('top',1)])
def test_intermediate_rows_correct_spacing_without_increasing_capacity(layout,sign):
    c=replace(W410,layout=layout,M=sign*W410.M)
    a=evaluate(c);b=evaluate(replace(c,intermediate_n=1))
    assert b.checks and not any(i.severity=='noncompliance' for i in b.issues)
    assert b.geometry['intermediate_rows']==pytest.approx([W410.beam.d/2])
    assert b.geometry['nb']==a.geometry['nb']+2
    assert b.geometry['calculation_nb']==a.geometry['calculation_nb']
    for key in ('bolt_tension','bolt_shear','Yp','Yc'):
        assert b.geometry['actions'][key]==pytest.approx(a.geometry['actions'][key])
    ac={r.id:r for r in a.checks};bc={r.id:r for r in b.checks}
    # All added holes participate in bearing / block paths without capacity credit.
    assert bc['ep_block_plate'].resistance<=ac['ep_block_plate'].resistance
    assert bc['ep_bearing_plate'].resistance<=ac['ep_bearing_plate'].resistance
    assert b.status=='CÁLCULO COM RESSALVAS · EXTRAPOLAÇÃO DO MODELO'

@pytest.mark.parametrize('changes',[{'gauge':85.},{'plate_steel':'USI-CIVIL 350'},{'overhang':15.},{'n':2}])
def test_pinned_recipe_limits_are_warnings(changes):
    r=evaluate(replace(PIN,**changes))
    assert r.checks and any(i.severity=='extrapolation' for i in r.issues)
    assert r.status!='ATENDE ÀS VERIFICAÇÕES REALIZADAS'

@pytest.mark.parametrize('changes',[{'pfi':210.},{'intermediate_n':True},{'intermediate_n':-1},{'intermediate_n':30},{'intermediate_n':10}])
def test_crossed_or_overcrowded_rows_and_invalid_extra_count_still_block(changes):
    r=evaluate(replace(W200,**changes))
    assert r.status=='GEOMETRIA INVÁLIDA' and not r.checks

def test_failure_is_not_hidden_by_extrapolation():
    r=evaluate(replace(W200,M=100000000))
    assert r.status=='NÃO ATENDE' and any(not x.passed for x in r.checks)
    assert 'extrapolação' in r.calculation_note

def test_wider_plate_uses_limited_effective_width():
    r=evaluate(replace(MOM,bp=200.))
    assert r.checks and r.geometry['actions']['effective_bp']==pytest.approx(MOM.beam.bf+25.4)
    reference=evaluate(replace(MOM,bp=MOM.beam.bf+25.4))
    assert r.geometry['actions']['Yp']==pytest.approx(reference.geometry['actions']['Yp'])

def test_word_has_qualifier_at_start_and_final_premises():
    for c in (W200,W410,replace(W410,intermediate_n=1)):
        d=Document(BytesIO(create_report(c,evaluate(c))));p=[p.text for p in d.paragraphs]
        assert any('Cálculo disponível' in x or 'Resultados calculados com extrapolação' in x for x in p[:8])
        final='\n'.join(p[p.index('Premissas adotadas'):])
        assert ('fora do intervalo' in final or 'requisito de detalhamento não atendido' in final or 'sem crédito resistente' in final)

def test_ui_load_old_w200_json_then_add_w410_bolts_and_export():
    at=AppTest.from_file(str(ROOT/'app.py'),default_timeout=60).run()
    at.selectbox(key='connection_family').set_value('End plate · engastada').run()
    at.get('file_uploader')[0].upload('W200.json',(ROOT/'examples/Caso_usuario_W200_v074.json').read_bytes(),'application/json').run()
    next(x for x in at.button if x.label=='Abrir projeto de end plate').click().run()
    assert not at.exception and not at.error and at.warning
    assert at.number_input(key='ep_intermediate_n').value==0
    at.selectbox(key='ep_beam_name').set_value('W 410 x 46,1').run()
    assert any('NÃO ATENDE AO DETALHAMENTO' in x.value for x in at.error)
    assert not next(x for x in at.button if x.label=='Gerar memória Word').disabled
    at.number_input(key='ep_intermediate_n').set_value(1).run()
    assert not at.exception and not at.error and at.warning
    next(x for x in at.button if x.label=='Gerar memória Word').click().run()
    assert not at.exception and at.session_state['ep_report'][2][:2]==b'PK'
    data=at.session_state['ep_model']
    assert data['intermediate_n']==1 and data['V']==pytest.approx(W200.V)
    at.number_input(key='ep_intermediate_n').set_value(2).run()
    assert not any(getattr(x,'label','')=='Baixar memória Word' for x in at.get('download_button'))

@pytest.mark.parametrize('kind',['beam_web','column_flange'])
@pytest.mark.parametrize('limit',['pitch','edge'])
def test_single_plate_maximum_detail_limits_allow_calculation(kind,limit):
    from lro.engine import evaluate as calc
    from lro.examples import presets as examples
    c=next(c for c in examples().values() if c.kind==kind)
    c=replace(c,beam=profiles()['W 610 x 101,0'],n=2,plate_top=80,cope_top=0,cope_bottom=0)
    c=replace(c,pitch=301.) if limit=='pitch' else replace(c,edge_h=151.)
    r=calc(c)
    assert r.checks and any(i.severity=='noncompliance' for i in r.issues)
    assert r.status in ('NÃO ATENDE','NÃO ATENDE AO DETALHAMENTO')

@pytest.mark.parametrize('limit',['pitch','edge'])
def test_double_cover_maximum_detail_limits_allow_calculation(limit):
    from lro.double_cover import evaluate as calc,presets as examples
    c=replace(next(iter(examples().values())),beam=profiles()['W 610 x 101,0'],n=2)
    c=replace(c,pitch=301.) if limit=='pitch' else replace(c,edge_x=151.)
    r=calc(c)
    assert r.checks and any(i.severity=='noncompliance' for i in r.issues)
    assert r.status in ('NÃO ATENDE','NÃO ATENDE AO DETALHAMENTO')
