"""Finite R017 AppTest/uploader/download acceptance; no browser or new mechanics.

R017_UI_EVIDENCE records the bytes offered by the real app's download buttons,
plus exact tables/results. Only the media store is observed, never substituted.
"""
from collections import Counter
from copy import deepcopy
from dataclasses import replace
from io import BytesIO
import json
import os
import re
from pathlib import Path
import xml.etree.ElementTree as ET
from zipfile import ZipFile

import pytest
from streamlit.runtime.memory_media_file_storage import MemoryMediaFileStorage
from streamlit.testing.v1 import AppTest

from lro import coped_double_angle_ui as ui
from lro.coped_double_angle import FAMILY, presets, HOLES
from lro.double_angle import FAMILY as R016
from lro.welded_double_angle import FAMILY as R015
from lro.coped_double_angle_presentation import physical_envelopes, governing_description, state_label
from lro.models import KGF

APP = Path(__file__).resolve().parents[1] / 'app.py'
BASE = next(iter(presets().values()))
JSON_LABEL = 'Salvar projeto R017 .json'
SVG_LABEL = 'Baixar desenho R017 .svg'
WORD_LABEL = 'Baixar memória R017 .docx'


@pytest.fixture
def media(monkeypatch):
    files = {}
    original = MemoryMediaFileStorage.load_and_get_id
    def tap(storage, *args, **kwargs):
        identifier = original(storage, *args, **kwargs)
        files[identifier] = storage._files_by_id[identifier].content
        return identifier
    monkeypatch.setattr(MemoryMediaFileStorage, 'load_and_get_id', tap)
    return files


def clean(at):
    assert not at.exception, [x.message for x in at.exception]


def fresh():
    at = AppTest.from_file(str(APP), default_timeout=120)
    at.session_state['connection_family'] = FAMILY
    at.run(); clean(at)
    return at


def button(at, label='Gerar memória R017'):
    return next(x for x in at.button if x.label == label)


def labels(at):
    return [x.label for x in at.get('download_button')]


def download(at, media, label=JSON_LABEL):
    control = next(x for x in at.get('download_button') if x.label == label)
    return media[Path(control.proto.url).name.rsplit('.', 1)[0]]


def raw(at):
    return deepcopy(at.session_state['_coped_double_angle_project'])


def result(at):
    return deepcopy(at.session_state['_coped_double_angle_result'])


def upload(at, data):
    payload = data if isinstance(data, bytes) else json.dumps(data, ensure_ascii=False).encode()
    at.get('file_uploader')[0].upload('R017.json', payload, 'application/json').run(); clean(at)
    button(at, 'Carregar R017').click().run(); clean(at)
    return at


def report(at):
    button(at).click().run(); clean(at)
    return at.session_state['ca_report']


def word_text(data):
    with ZipFile(BytesIO(data)) as archive:
        return '\n'.join(ET.fromstring(archive.read('word/document.xml')).itertext())


def qualified(c, side):
    return replace(c, **{'restraint_' + side + '_system': 'Travamento independente EXEMPLO',
        'restraint_' + side + '_ref': 'MC-EXEMPLO: resistência e rigidez verificadas',
        'restraint_' + side + '_x': c.gap + getattr(c, 'c_' + side)})


def evidence(name, data, payloads=None):
    folder = os.environ.get('R017_UI_EVIDENCE')
    if folder:
        path = Path(folder); path.mkdir(parents=True, exist_ok=True)
        (path / (name + '.json')).write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False))
        for extension, payload in (payloads or {}).items():
            (path / (name + '.' + extension)).write_bytes(payload)


@pytest.mark.parametrize('field', ['beam.mass', 'c_top', 'V'])
def test_nonrepresentable_import_staging_is_field_specific_and_atomic(monkeypatch, field):
    state = {'ca_project': 'Prior', 'ca_report': ('digest', 'prior.docx', b'prior'),
             '_coped_double_angle_project': {'prior': True},
             '_coped_double_angle_result': {'status': 'prior'},
             '_coped_double_angle_ui_draft': {'prior': True}}
    before = deepcopy(state); monkeypatch.setattr(ui.st, 'session_state', state)
    c = (replace(BASE, beam=replace(BASE.beam, mass=9007199254740993)) if field == 'beam.mass'
         else replace(BASE, **{field: 9007199254740993}))
    with pytest.raises(ValueError, match=field + ': valor 9007199254740993 não representável'):
        ui.seed(c)
    assert state == before


@pytest.mark.parametrize('name,shear,sides,count', [
    ('baseline', 100000., (), 72), ('qualified_positive', 100000., ('top',), 72),
    ('qualified_negative', -100000., ('bottom',), 72),
    ('zero', 0., ('top', 'bottom'), 128), ('high_load', 500000., ('top',), 72)])
def test_actual_downloads_and_22_lossless_portuguese_envelopes(media, name, shear, sides, count):
    c = replace(BASE, project='R017 actual download ' + name, V=shear)
    for side in sides: c = qualified(c, side)
    at = upload(fresh(), c.to_dict()); r = result(at)
    table = at.dataframe[0].value; envelopes = physical_envelopes(r)
    assert len(table) == len(envelopes) == 22 and len(r['checks']) == count
    assert table['Componente físico'].tolist() == [e['component_label'] for e in envelopes]
    assert not any(word in ' '.join(table['Componente físico']) for word in ['negative', 'positive', 'beam_', 'support_', 'soldada'])
    assert set(table['Resultado adotado']) <= {state_label('PASS'), state_label('FAIL')}
    assert Counter(i for e in envelopes for i in e['member_ids']) == Counter(ch['id'] for ch in r['checks'])
    for (_, row), env in zip(table.iterrows(), envelopes):
        actual, adopted = env['actual_governing'], env['adopted_governing']
        assert row['Índice real'] == max(ch['actual_utilization'] for ch in env['members'])
        assert row['Índice adotado'] == max(ch['utilization'] for ch in env['members'])
        assert row['Solicitação real (kgf)'] == actual['actual_demand_N'] / KGF
        assert row['Resistência · ramo real (kgf)'] == actual['design_capacity_N'] / KGF
        assert row['Solicitação adotada (kgf)'] == adopted['demand_N'] / KGF
        assert row['Resistência · ramo adotado (kgf)'] == adopted['design_capacity_N'] / KGF
        assert row['Caso / sentido / ramo real'] == governing_description(actual)
        assert row['Caso / sentido / ramo adotado'] == governing_description(adopted)
        assert row['Falhas reais'] == sum(ch['actual_status'] == 'FAIL' for ch in env['members'])
        assert row['Falhas adotadas'] == sum(ch['status'] == 'FAIL' for ch in env['members'])
        assert row['Condição de contenção'] == env['restraint_condition']
    governors = next(e for e in at.expander if e.label.startswith('Governantes completos'))
    assert json.loads(governors.json[0].value) == json.loads(json.dumps(envelopes))
    detail = next(e for e in at.expander if e.label.startswith('Todas as verificações primitivas'))
    detail_table = detail.dataframe[0].value
    assert detail_table['ID'].tolist() == [ch['id'] for ch in r['checks']]
    assert detail_table['Fórmula'].tolist() == [ch['formula'] for ch in r['checks']]
    assert detail_table['Resultado adotado'].tolist() == [state_label(ch['status']) for ch in r['checks']]
    assert detail_table['Resistência (kgf)'].tolist() == [ch['design_capacity_N'] / KGF for ch in r['checks']]
    assert json.loads(detail.json[-1].value) == json.loads(json.dumps(r['checks']))
    report(at)
    payloads = {'native.json': download(at, media), 'svg': download(at, media, SVG_LABEL),
                'docx': download(at, media, WORD_LABEL)}
    assert json.loads(payloads['native.json']) == c.to_dict() == raw(at)
    svg, word = payloads['svg'].decode(), word_text(payloads['docx'])
    assert c.project in svg and c.project in word
    assert all(ch['id'] in word and ch['formula'] in word for ch in r['checks'])
    assert 'aba soldada junto à viga' not in word
    assert not r['global_pass'] and any('EXTERNA' in item.value for item in at.caption)
    ids = [element.attrib['id'] for element in ET.fromstring(svg).iter() if 'id' in element.attrib]
    assert sum(bool(re.match(r'angle_A[12]_L_plan$', identifier)) for identifier in ids) == 2
    assert sum(identifier.startswith('web_hole_elevation_') for identifier in ids) == 4
    assert sum(bool(re.match(r'support_hole_A[12]_', identifier)) for identifier in ids) == 8
    assert sum(identifier.startswith('web_shear_plane_') for identifier in ids) == 2
    assert sum(identifier.startswith('support_shear_plane_') for identifier in ids) == 2
    assert not any(token in ' '.join(table[column]) for column in ('Caso / sentido / ramo real', 'Caso / sentido / ramo adotado')
                   for token in ('negative', 'positive', 'direction_independent'))
    if shear == 0:
        assert r['load_model']['Vsd_N'] == 0 and r['load_model']['Vd_N'] == 45000.
        assert r['summary']['actual_governing_utilization'] == 0
        assert r['local_pass'] and len(at.success) == 1
        assert any(len(e['actual_governing_ties']) > 1 for e in envelopes)
    elif shear == 500000.:
        assert r['status'] == 'VERIFIED_SUBCHECK_FAIL' and not at.success
        assert int(table['Falhas adotadas'].sum()) == 33
        assert 'SEM APROVAÇÃO LOCAL' in svg and 'Não há aprovação local da ligação' in word
    elif sides:
        assert r['local_pass'] and len(at.success) == 1
    else:
        assert r['status'] == 'ENGINEERING_MODEL_PENDING' and not at.success
    evidence(name, {'result': r, 'table': table.to_dict(orient='records'),
        'details': detail_table.to_dict(orient='records'), 'all_primitive_ids_formulas_in_word': True,
        'downloads_are_actual_registered_bytes': True}, payloads)


def test_real_uploader_rejects_atomically_preserving_active_download_bytes(media):
    at = fresh(); report(at)
    before = (raw(at), result(at), at.session_state['ca_report'])
    downloads = {label: download(at, media, label) for label in (JSON_LABEL, WORD_LABEL)}
    wrong_units = deepcopy(BASE.to_dict()); wrong_units['units']['force'] = 'kN'
    precision = replace(BASE, beam=replace(BASE.beam, name='Precision witness', mass=9007199254740993)).to_dict()
    cases = [(wrong_units, 'units'), (b'{"connection":', 'Não foi possível abrir'),
             (b' ' * 200001, '200 kB'), (precision, 'beam.mass: valor 9007199254740993')]
    for value in (float('nan'), float('inf'), True):
        invalid = deepcopy(BASE.to_dict()); invalid['connection']['V'] = value
        cases.append((invalid, 'V: número finito obrigatório'))
    seen = []
    for data, reason in cases:
        upload(at, data)
        assert reason in at.session_state['ca_import_error']
        assert (raw(at), result(at), at.session_state['ca_report']) == before
        assert {label: download(at, media, label) for label in (JSON_LABEL, WORD_LABEL)} == downloads
        seen.append({'import_error': at.session_state['ca_import_error'], 'state_and_download_bytes_unchanged': True})
    evidence('atomic_rejections', seen)


def test_finite_display_overflow_retires_old_eligibility_and_recovers(media):
    c = qualified(BASE, 'top'); at = upload(fresh(), c.to_dict()); report(at)
    at.number_input(key='ca_V_kgf').set_value(1e308).run(); clean(at)
    r = result(at)
    assert r['status'] == 'NUMERICAL_FAILURE' and not r['local_pass'] and not r['global_pass'] and not r['checks']
    assert r['issues'][0]['severity'] == 'numerical_failure'
    assert not at.success and any('FALHA NUMÉRICA' in e.value for e in at.error)
    assert '_coped_double_angle_project' not in at.session_state
    assert 'ca_report' not in at.session_state and not labels(at) and button(at).disabled
    assert at.session_state['_coped_double_angle_ui_draft']['ca_V_kgf'] == 1e308
    failure = {'result': r, 'active_project_absent': True, 'old_report_absent': True,
               'downloads': labels(at), 'exceptions': [], 'protocol_probe_only': True}
    at.number_input(key='ca_V_kgf').set_value(100000. / KGF).run(); clean(at)
    assert result(at)['local_pass'] and not result(at)['global_pass']
    assert raw(at) == c.to_dict() == json.loads(download(at, media))
    assert 'ca_report' not in at.session_state and WORD_LABEL not in labels(at)
    report(at); assert download(at, media, WORD_LABEL).startswith(b'PK')
    evidence('conversion_overflow_recovery', {'failure': failure, 'recovery_status': result(at)['status'],
        'current_native_exact': True, 'fresh_report_available': True})


def test_finite_native_overflow_keeps_current_native_json_only(media):
    c = replace(BASE, project='R017 finite native overflow', V=1e308)
    at = fresh(); report(at); upload(at, c.to_dict())
    assert result(at)['status'] == 'NUMERICAL_FAILURE'
    assert raw(at) == c.to_dict() == json.loads(download(at, media))
    assert labels(at) == [JSON_LABEL] and not at.success and button(at).disabled
    assert 'ca_report' not in at.session_state
    evidence('finite_native_overflow', {'result': result(at), 'downloads': labels(at),
        'native_exact': True, 'old_report_absent': True}, {'native.json': download(at, media)})


def test_ordinary_high_load_then_signed_zero_and_missing_restraint_controls(media):
    at = fresh()
    for side in ('top', 'bottom'):
        at.text_input(key='ca_restraint_' + side + '_system').set_value('Travamento independente EXEMPLO').run(); clean(at)
        at.text_input(key='ca_restraint_' + side + '_ref').set_value('MC-EXEMPLO: resistência e rigidez').run(); clean(at)
        at.number_input(key='ca_restraint_' + side + '_x').set_value(140.).run(); clean(at)
    assert result(at)['local_pass']; old = report(at)
    at.number_input(key='ca_V_kgf').set_value(500000. / KGF).run(); clean(at)
    assert result(at)['status'] == 'VERIFIED_SUBCHECK_FAIL' and not at.success
    assert 'ca_report' not in at.session_state and WORD_LABEL not in labels(at)
    assert sum(x['status'] == 'FAIL' for x in result(at)['checks']) == 33
    assert report(at)[0] != old[0]
    for shear in (-100000., 0.):
        at.number_input(key='ca_V_kgf').set_value(shear / KGF).run(); clean(at)
        assert result(at)['local_pass'] and not result(at)['global_pass']
        report(at)
    at.text_input(key='ca_restraint_top_ref').set_value('').run(); clean(at)
    assert result(at)['status'] == 'ENGINEERING_MODEL_PENDING' and not at.success
    assert 'ca_report' not in at.session_state
    at.number_input(key='ca_V_kgf').set_value(100000. / KGF).run(); clean(at)
    at.number_input(key='ca_c_top').set_value(131.).run(); clean(at)
    at.number_input(key='ca_c_bottom').set_value(131.).run(); clean(at)
    assert raw(at)['connection']['restraint_top_x'] == 140. and not result(at)['local_pass']
    evidence('ordinary_edit_restraint_controls', {'high_load_failures': 33,
        'both_signed_and_zero_qualified': True, 'zero_missing_top_unapproved': True,
        'cope_edit_does_not_move_restraint': True, 'global_verification_external': True})


def test_custom_profiles_navigation_and_hole_callbacks_remain_exact(media):
    c = qualified(qualified(replace(BASE, project='R017 measured profiles', V=-12345.6789,
        beam=replace(BASE.beam, name='Measured B17', tw=7.25, source='Survey B17'),
        support=replace(BASE.support, name='Measured S04', tw=8.2, source='Survey S04'),
        c_top=131.25, c_bottom=131.25, beam_level=-1.25), 'top'), 'bottom')
    at = upload(fresh(), c.to_dict()); assert json.loads(download(at, media)) == c.to_dict()
    for role in ('beam', 'support'):
        at.selectbox(key='ca_' + role + '_name').set_value(getattr(BASE, role).name).run(); clean(at)
    at.number_input(key='ca_beam_level').set_value(2.75).run(); clean(at)
    at.selectbox(key='connection_family').set_value(R016).run(); clean(at)
    at.number_input(key='da_web_pitch').set_value(58.).run(); clean(at)
    r016 = deepcopy(at.session_state['_double_angle_project'])
    at.selectbox(key='connection_family').set_value(R015).run(); clean(at)
    at.number_input(key='wa_weld_start').set_value(22.).run(); clean(at)
    r015 = deepcopy(at.session_state['_welded_double_angle_project'])
    at.selectbox(key='connection_family').set_value(FAMILY).run(); clean(at)
    for role in ('support', 'beam'):
        at.selectbox(key='ca_' + role + '_name').set_value(ui.CUSTOM).run(); clean(at)
    assert raw(at) == replace(c, beam_level=2.75).to_dict() == json.loads(download(at, media))
    assert at.session_state['_double_angle_project'] == r016 and at.session_state['_welded_double_angle_project'] == r015
    upload(at, BASE.to_dict())
    for diameter in [19.05, 24., 20.]:
        at.selectbox(key='ca_db').set_value(diameter).run(); clean(at)
        assert at.number_input(key='ca_hole_diameter').value == HOLES[diameter]
    at.number_input(key='ca_hole_diameter').set_value(21.5).run(); at.run(); clean(at)
    assert raw(at)['connection']['hole_diameter'] == 21.5
    evidence('navigation_profiles_callbacks', {'native_exact': True, 'profiles_independent': True,
        'R015_R016_R017_independent': True, 'imperial_metric_callbacks_exact': True, 'manual_hole_preserved': True})


def test_signed_actions_tiny_values_and_unknown_enums_remain_lossless(media):
    at = fresh()
    signed = replace(BASE, project='R017 CURRENT SIGNED ACTIONS', V=-23456.789012345,
        N=1234.56789012, M=-345678.9012345, torsion=456789.0123456)
    upload(at, signed.to_dict())
    assert raw(at) == signed.to_dict() == json.loads(download(at, media))
    assert result(at)['status'] == 'OUTSIDE_R017_SCOPE' and not at.success and button(at).disabled
    svg = download(at, media, SVG_LABEL).decode(); assert signed.project in svg
    for label, value, unit in [('V', signed.V, 'N'), ('N', signed.N, 'N'), ('M', signed.M, 'N mm'), ('T', signed.torsion, 'N mm')]:
        assert f'{label}={value:+.12g} {unit}' in svg
    evidence('signed_actions', {'result': result(at), 'native_exact': True},
        {'native.json': download(at, media), 'svg': download(at, media, SVG_LABEL)})
    tiny = replace(BASE, N=1e-323, M=-1e-320, torsion=1e-320, r_top=.005)
    upload(at, tiny.to_dict())
    assert raw(at) == tiny.to_dict() == json.loads(download(at, media))
    assert at.number_input(key='ca_r_top').value == .005
    unknown = replace(BASE, kind='imported_topology', cope='unequal_double', hole_type='imported_slot',
        exposure='imported_exposure', beam_steel='imported_steel', bolt='imported_bolt', db=18.6)
    upload(at, unknown.to_dict())
    assert raw(at) == unknown.to_dict() == json.loads(download(at, media))
    assert not at.success and button(at).disabled
    assert all(at.selectbox(key='ca_' + key).value == getattr(unknown, key)
        for key in ('kind', 'cope', 'hole_type', 'exposure', 'beam_steel', 'bolt', 'db'))
    evidence('tiny_and_unknown_imports', {'subnormal_actions_exact': True, 'dimension_0005_exact': True,
        'unknown_enums_preserved_visible_and_unapproved': True})


@pytest.mark.parametrize('shear,passes', [(100000., True), (-100000., True), (500000., False), (-500000., False)])
def test_table16_short_beam_end_is_explicitly_qualified_without_clamping(media, shear, passes):
    c = replace(BASE, gap=20., V=shear)
    c = qualified(c, 'top' if shear > 0 else 'bottom')
    at = upload(fresh(), c.to_dict()); r = result(at)
    assert raw(at) == c.to_dict() == json.loads(download(at, media))
    box = next(e for e in at.expander if e.label.startswith('Nota da Tabela 16'))
    notes = '\n'.join(item.value for item in box.markdown)
    assert '25,000 mm' in notes and '26,000 mm' in notes
    assert ('EXCEÇÃO DA NOTA DA TABELA 16 VERIFICADA' if passes
            else 'EXCEÇÃO DA NOTA DA TABELA 16 NÃO VERIFICADA') in notes
    exception = r['geometry']['table16_exceptions']['beam_end_min']
    assert exception['qualified'] is passes and exception['actual_edge_mm'] == 25.
    assert all(key in notes for key in ['Contato / rasgamento', 'Bloco L', 'Sd=', 'Rd='])
    assert r['local_pass'] is passes and not r['global_pass']
    assert bool(at.success) is passes
    evidence('table16_' + str(int(shear)), {'status': r['status'], 'exception': exception,
        'qualification_text_explicit': True, 'native_exact_no_clamping': True})


def test_old_eligibility_is_retired_before_load_conversion(monkeypatch, media):
    at = fresh(); report(at)
    original = ui._force
    observed = []
    def checked_force(key):
        assert 'ca_report' not in ui.st.session_state
        assert '_coped_double_angle_project' not in ui.st.session_state
        assert '_coped_double_angle_result' not in ui.st.session_state
        observed.append(key)
        return original(key)
    monkeypatch.setattr(ui, '_force', checked_force)
    at.number_input(key='ca_V_kgf').set_value(1e308).run(); clean(at)
    assert observed == ['V'] and result(at)['status'] == 'NUMERICAL_FAILURE'
    assert not labels(at) and button(at).disabled
