"""Independent geometry and canonical artifact boundaries for axial 2L."""
from copy import deepcopy
from dataclasses import fields, replace
from io import BytesIO
import xml.etree.ElementTree as ET
import zipfile

import matplotlib.pyplot as plt
import pytest

from lro.axial_double_angle import AxialDoubleAngle, evaluate
from lro.axial_double_angle_drawing import drawing, image_bytes
from lro.axial_double_angle_presentation import physical_envelopes
from lro.axial_double_angle_report import create_report


def fixture(**changes):
    return replace(AxialDoubleAngle(), **changes)


def doc_text(c,result=None):
    blob=create_report(c,result)
    with zipfile.ZipFile(BytesIO(blob)) as z:
        xml=ET.fromstring(z.read('word/document.xml'))
        return '\n'.join(xml.itertext()),z.read('word/styles.xml'),z.namelist()


def artists(c):
    fig=drawing(c)
    patches={p.get_gid():p for ax in fig.axes for p in ax.patches if p.get_gid()}
    lines={p.get_gid():p for ax in fig.axes for p in ax.lines if p.get_gid()}
    return fig,patches,lines


def test_default_draws_two_real_mirrored_Ls_one_plate_and_actual_terminal():
    c=fixture();fig,p,l=artists(c)
    try:
        for code,sign in [('A1',-1),('A2',1)]:
            v=p['angle_'+code+'_L_section'].get_path().vertices
            assert min(sign*v[:,0])==pytest.approx(6.25)
            assert max(sign*v[:,0])==pytest.approx(82.25)
            assert min(v[:,1])==pytest.approx(15.)
            assert max(v[:,1])==pytest.approx(91.)
            assert p['angle_'+code+'_L_section'].get_path().codes[-1]==79
        assert p['single_plate_section'].get_width()==12.5
        assert p['single_plate_section'].get_height()==100.
        assert p['plate_elevation'].get_x()==0
        assert p['plate_elevation'].get_width()==200.
        assert p['plate_elevation'].get_height()==100.
        holes=[p['shared_hole_'+str(i)] for i in range(1,4)]
        assert [v.center for v in holes]==[(35.,50.),(85.,50.),(135.,50.)]
        assert [v.radius for v in holes]==[9.]*3
        assert list(l['terminal_cut_elevation'].get_xdata())==[200.,200.]
        assert len([name for name in l if name.startswith('through_bolt_')])==3
        assert len([name for name in l if name.startswith('bolt_') and '_plane_' in name])==6
    finally:plt.close(fig)


def test_changed_input_changes_geometry_without_width_or_property_normalization():
    c=fixture(n=4,pitch=60.,plate_width=120.,plate_t=16.,gauge=40.,angle_end=40.,plate_end=45.,terminal_extension=45.)
    fig,p,l=artists(c)
    try:
        assert p['plate_elevation'].get_width()==310.
        assert p['plate_elevation'].get_height()==120.
        assert p['single_plate_section'].get_width()==16.
        assert p['angle_A1_elevation'].get_y()==20.
        assert p['angle_A1_elevation'].get_height()==76.
        assert [p[f'shared_hole_{i}'].center for i in range(1,5)]==[(45.,60.),(105.,60.),(165.,60.),(225.,60.)]
        assert list(l['terminal_cut_elevation'].get_xdata())==[310.,310.]
    finally:plt.close(fig)


def test_force_arrows_follow_signed_actual_N_and_zero_has_no_fake_actual_arrow():
    for N,direction in [(200000.,1),(-200000.,-1),(0.,0)]:
        fig=drawing(fixture(N=N))
        try:
            annotations={a.get_gid():a for ax in fig.axes for a in ax.texts if a.get_gid()}
            if not direction:
                assert 'actual_plate_force' not in annotations
                assert 'force_on_angles_positive_x' not in annotations
            else:
                a=annotations['actual_plate_force']
                assert (a.xy[0]-a.get_position()[0])*direction>0
                a=annotations['actual_angle_force']
                assert (a.xy[0]-a.get_position()[0])*direction<0
        finally:plt.close(fig)


def test_canonical_svg_ignores_forged_stale_results_for_all_boundary_states():
    forged=evaluate(fixture())
    forged['geometry']['terminal_x']=99999
    for c in [fixture(N=600000.),fixture(V=3500.,M=250000.),fixture(n=1),fixture(N=0.,minimum_force=False)]:
        svg=image_bytes(c,forged,fmt='svg').decode()
        assert 'SEM APROVAÇÃO GLOBAL' in svg
        assert 'ATENDIMENTO LOCAL NO DOMÍNIO DECLARADO' not in svg
        assert '99999' not in svg
        assert evaluate(c)['status'] in svg


@pytest.mark.parametrize('changes',[{'pitch':0.},{'N':float('nan')},{'n':True},{'angle_count':1},{'symmetric':False},{'db':17.}])
def test_invalid_or_unrepresentable_svg_is_a_diagnostic_not_an_approved_fixture(changes):
    c=fixture(**changes)
    svg=image_bytes(c,evaluate(fixture()),fmt='svg').decode()
    assert 'SEM APROVAÇÃO GLOBAL' in svg
    assert 'ATENDIMENTO LOCAL NO DOMÍNIO DECLARADO' not in svg


def test_envelopes_are_lossless_physical_and_retain_ties_and_cases():
    result=evaluate(fixture(N=0.,recommend_half_capacity=True))
    envelopes=physical_envelopes(result)
    recovered=[row for env in envelopes for row in env['members']]
    assert sorted(row['id'] for row in recovered)==sorted(row['id'] for row in result['checks'])
    assert {row['case_id'] for row in recovered}=={'actual','minimum_45kN','recommended_half'}
    assert len(envelopes)==len({(row['component'],row['mechanism']) for row in result['checks']})
    assert all(env['actual_utilization']==0 for env in envelopes)
    for env in envelopes:
        assert env['governing']
        assert env['utilization']==max(row['utilization'] for row in env['members'])
        for row in env['members']:
            assert row==next(source for source in result['checks'] if source['id']==row['id'])
    plates=[env for env in envelopes if env['component']=='plate' and env['mechanism']=='gross_yield'][0]
    assert len(plates['governing'])==2
    envelopes[0]['members'][0]['areas']['Ag']=-1
    assert result['checks'][0]['areas']['Ag']==1858.


def test_unresolved_numerical_witness_survives_finite_passing_member():
    result={'cases':[{'id':'actual'}],'checks':[
        {'id':'a','component':'plate','mechanism':'bearing','case_id':'actual','utilization':.2,'status':'PASS'},
        {'id':'b','component':'plate','mechanism':'bearing','case_id':'actual','utilization':None,'status':'FAIL'}]}
    env=physical_envelopes(result)[0]
    assert env['status']=='FAIL'
    assert 'b' in env['governing_ids']
    assert len(env['members'])==2


def test_word_records_all_input_fields_primitives_and_actual_physical_witnesses():
    c=fixture();result=evaluate(c)
    text,styles,names=doc_text(c,{'status':'fake'})
    for field in fields(c):assert field.name in text
    for row in result['checks']:assert row['id'] in text
    for token in ['Agv','Anv','Ant','bolt_indices','shear_plane','threads_excluded','grip_factor',
                  'loaded_direction','far_toe_unfolded','terminal_unperforated_cut','real_full_width_one_hole']:
        assert token in text
    for token in ['6.1.8.2','PDF 162','1858','21,3','Caminho físico','SEM APROVAÇÃO GLOBAL'][:-1]:assert token in text
    assert 'SEM APROVAÇÃO GLOBAL' not in text
    assert 'ATENDIMENTO LOCAL NO DOMÍNIO DECLARADO' in text
    assert any(name.startswith('word/media/') for name in names)
    root=ET.fromstring(styles);ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
    title=root.find('w:style[@w:styleId="Title"]',ns)
    assert title.find('.//w:pBdr',ns) is None


def test_word_preserves_zero_and_candidate_cases_and_outside_actual_actions():
    zero=fixture(N=0.,recommend_half_capacity=True)
    text,_,_=doc_text(zero)
    for row in evaluate(zero)['checks']:assert row['id'] in text
    assert 'minimum_45kN' in text and 'recommended_half' in text
    assert 'N=0 permanece um caso real' in text
    outside=fixture(V=3500.,M=250000.)
    text,_,_=doc_text(outside,evaluate(fixture()))
    assert 'SEM APROVAÇÃO GLOBAL' in text and 'OUTSIDE_SCOPE' in text
    assert '3500' in text and '250000' in text
    assert 'não são uma solução das ações combinadas reais' in text


def test_malformed_word_retains_diagnostic_and_no_stale_pass():
    text,_,_=doc_text(fixture(N=float('nan'),bolt=['invalid']),evaluate(fixture()))
    assert 'SEM APROVAÇÃO GLOBAL' in text and 'INVALID_INPUT' in text
    assert 'ATENDIMENTO LOCAL NO DOMÍNIO DECLARADO' not in text


def test_huge_json_integer_exports_diagnostic_without_float_conversion_overflow():
    value=10**400
    c=fixture(N=value)
    assert evaluate(c)['status']=='INVALID_INPUT'
    svg=image_bytes(c,evaluate(fixture()),fmt='svg').decode()
    assert 'SEM APROVAÇÃO GLOBAL' in svg and 'INVALID_INPUT' in svg
    assert 'inteiro fora da faixa numérica' in svg
    text,_,_=doc_text(c,evaluate(fixture()))
    assert 'SEM APROVAÇÃO GLOBAL' in text and 'INVALID_INPUT' in text
    assert str(value) in text
    assert 'ATENDIMENTO LOCAL NO DOMÍNIO DECLARADO' not in text
