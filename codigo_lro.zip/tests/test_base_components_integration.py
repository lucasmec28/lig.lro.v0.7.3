from dataclasses import replace
import copy
from io import BytesIO
import pytest
from docx import Document
from lro.base_plate import BasePlate,presets,evaluate,reactions
from lro.pinned_base_plate import PinnedBasePlate,presets as pinned_presets,evaluate as pinned_evaluate
from lro.concrete_components import ConcreteComponents,bearing_signature,distribution_signature
from lro.column_base_weld import ColumnBaseWeld,MODEL
from lro.base_plate_report import create_report
from test_base_plate_catalog import app,FIXED,PINNED

def confirm(c):
    return replace(c,concrete_components=replace(c.concrete_components,bearing_confirmation=bearing_signature(c),distribution_confirmation=distribution_signature(c)))

def qualified(family=1):
    base=presets()['Chumbadores · arruelas soldadas'] if family==1 else pinned_presets()['Chumbadores · arruelas soldadas']
    c=replace(base,N=-100000.,V=20000.,cone_model='aci318_19',anchor_type='headed',anchor_detail_ref='HD1',anchor_detail_confirmed=True)
    u=ConcreteComponents(model='aci318_19',bearing_area=250.,bearing_area_ref='HD1 net area',mechanical_resistance=90000.,mechanical_ref='HD1 head proof',
        force_a1=5000.,force_a2=5000.,force_a3=5000.,force_a4=5000.,distribution_ref='Force field verified for HD1',parallel_model='virtual_perpendicular',
        area_tension=200.,area_shear=190.,steel_area_ref='Thread effective areas')
    return confirm(replace(c,concrete_components=u))

def test_selected_missing_data_are_pending():
    c=replace(presets()['Chumbadores · arruelas soldadas'],concrete_components=ConcreteComponents(model='aci318_19'))
    r=evaluate(c)
    assert r.geometry and r.concrete_components['complete'] is False
    assert 'PENDENTES' in r.component_status
    modes=r.concrete_components['modes']
    assert all(modes[k]['status']=='pending' for k in ('breakout','pryout','aci_steel','interaction'))
    assert all(modes[k]['status']=='not_demanded' for k in ('pullout','sideface','head_mechanical'))

@pytest.mark.parametrize('family',[1,2])
def test_actual_geometry_and_roundtrip(family):
    c=qualified(family);r=evaluate(c)
    assert r.concrete_components['modes']['pullout']['status']=='calculated'
    assert r.concrete_components['modes']['aci_steel']['status']=='calculated'
    assert r.concrete_components['modes']['interaction']['passes'] is True
    assert len(r.concrete_components['native_nbr_distribution'])==4
    assert (BasePlate if family==1 else PinnedBasePlate).from_dict(c.to_dict())==c
    if family==2:
        assert evaluate(c).geometry==pinned_evaluate(c).geometry
        with pytest.raises(ValueError):reactions(c)

@pytest.mark.parametrize('kind',['headed','buried_nut','buried_plate_nut'])
def test_impossible_bearing_area_no_capacity(kind):
    c=qualified();c=confirm(replace(c,anchor_type=kind,concrete_components=replace(c.concrete_components,bearing_area=1e6)))
    r=evaluate(c)
    assert r.concrete_components['modes']['pullout']['status']=='pending'
    assert not r.concrete_components['modes']['pullout']['checks']
    assert any('Área efetiva' in i.text for i in r.issues)

def test_nut_area_and_overlapping_buried_pieces():
    c=confirm(replace(qualified(),anchor_type='buried_nut',anchor_nut_bearing_area=100.))
    assert evaluate(c).concrete_components['modes']['pullout']['status']=='pending'
    c=confirm(replace(qualified(),anchor_head_width=200.));r=evaluate(c)
    assert r.geometry['concrete_cone']['status']=='pending'
    assert any('sobrepõem' in text for text in r.concrete_components['modes']['pullout']['reasons'])

@pytest.mark.parametrize('field,value',[('anchor_washer_t',10.),('anchor_washer_side',80.),('weld_web_size',8.),('anchor_head_hole',30.),('stiffener_height',140.)])
def test_physical_shear_changes_invalidate(field,value):
    c=qualified();edited=replace(c,**{field:value})
    assert distribution_signature(edited)!=c.concrete_components.distribution_confirmation
    assert evaluate(edited).concrete_components['modes']['breakout']['status']=='pending'

def test_nested_washer_change_invalidates():
    c=qualified();edited=replace(c,upper_washer=replace(c.upper_washer,leg=8.))
    assert distribution_signature(edited)!=c.concrete_components.distribution_confirmation

@pytest.mark.parametrize('an,av',[(1e5,1e5),(100.,120.)])
def test_aci_area_bounds(an,av):
    c=qualified();c=replace(c,concrete_components=replace(c.concrete_components,area_tension=an,area_shear=av))
    steel=evaluate(c).concrete_components['modes']['aci_steel']
    assert steel['status']=='pending' and not steel['checks']

def test_missing_ductility_is_pending_not_crash():
    c=qualified();c=replace(c,concrete_components=replace(c.concrete_components,ductile=True,ductility_ref=''))
    assert evaluate(c).concrete_components['modes']['aci_steel']['status']=='pending'

def test_near_row_meets_each_native_capacity():
    c=replace(qualified(),N=150000.)
    native=evaluate(replace(c,concrete_components=ConcreteComponents())).geometry['anchor_shear']
    v=.75*native['group_rd'];c=replace(c,V=v,concrete_components=replace(c.concrete_components,force_a1=0.,force_a2=0.,force_a3=v/2,force_a4=v/2))
    r=evaluate(confirm(c));checks=[ck for ck in r.checks if ck.id.startswith('bp_cc_nbr_actual')]
    assert len(checks)==4 and checks[2].ratio==pytest.approx(1.5)
    assert not checks[2].passed and not checks[3].passed
    assert next(ck for ck in r.checks if ck.id=='bp_anchor_shear_native').passed

def test_pure_uplift_column_components():
    c=pinned_presets()['Chumbadores · arruelas soldadas']
    w=ColumnBaseWeld(model=MODEL,column_steel='ASTM A36',process='smaw_e7018_single_pass',web_length=220.,procedure_ref='W1',detail_confirmed=True)
    c=replace(c,N=-50000.,V=0.,weld_web_type='fillet',weld_web_size=4.,column_weld=w);r=pinned_evaluate(c)
    assert r.local_column_weld['status']=='pass' and r.local_column_weld['complete'] is False
    assert r.local_column_weld['b_eff_mm']==pytest.approx(c.a2-c.column.tw)
    assert any(ck.id.startswith('bp_cw_') for ck in r.checks)
    assert any(i.origin=='column_weld_scope' for i in r.issues)
    assert pinned_evaluate(replace(c,V=1.)).local_column_weld['status']=='pending'

def test_word_records_modes():
    c=qualified();xml=Document(BytesIO(create_report(c,evaluate(c),False)))._element.xml
    assert 'Ancoragem ACI por modos de ruptura' in xml
    assert 'Área efetiva de apoio Abrg' in xml
    assert 'Interação ACI dos estados enumerados' in xml

def test_component_ui_independent():
    at=app(FIXED);at.number_input(key='bp_N_kgf').set_value(-10000.).run();at.selectbox(key='bp_cc_model').set_value('aci318_19').run()
    at.number_input(key='bp_cc_bearing_area').set_value(250.).run()
    fixed=copy.deepcopy(at.session_state['_base_plate_project']);assert not at.exception
    at.selectbox(key='connection_family').set_value(PINNED).run();assert at.selectbox(key='pp_cc_model').value=='off'
    at.selectbox(key='pp_cw_model').set_value(MODEL).run();assert not at.exception
    pinned=copy.deepcopy(at.session_state['_pinned_base_plate_project'])
    at.selectbox(key='connection_family').set_value(FIXED).run();assert at.session_state['_base_plate_project']==fixed
    at.selectbox(key='connection_family').set_value(PINNED).run();assert at.session_state['_pinned_base_plate_project']==pinned


def test_redistribution_state_exposes_failure_hidden_by_actual_vector():
    c=qualified();c=confirm(replace(c,N=-10000.,V=60000.,concrete_components=replace(c.concrete_components,
        force_a1=15000.,force_a2=15000.,force_a3=15000.,force_a4=15000.,area_tension=200.,area_shear=200.)))
    r=evaluate(c);states=r.concrete_components['force_states']
    assert len(states)==2
    assert states[0]['interaction']['ratio']<1
    assert states[1]['interaction']['beta_V']==pytest.approx(1.3020833333333333)
    assert r.concrete_components['modes']['interaction']['passes'] is False
    assert states[1]['forces']=={'A1':0.,'A2':0.,'A3':30000.,'A4':30000.}
    assert all(state['basis']!='virtual_perpendicular' for state in states)
    assert any(not ck.passed for ck in r.checks if ck.id.startswith('bp_cc_state_1_nbr'))


def test_mirrored_and_single_row_states():
    c=qualified();negative=confirm(replace(c,V=-c.V))
    states=evaluate(negative).concrete_components['force_states']
    assert states[1]['forces']=={'A1':10000.,'A2':10000.,'A3':0.,'A4':0.}
    near=confirm(replace(c,concrete_components=replace(c.concrete_components,force_a1=0.,force_a2=0.,force_a3=10000.,force_a4=10000.)))
    assert len(evaluate(near).concrete_components['force_states'])==1
    far_case=confirm(replace(c,block_xmax=c.a+120.))
    state=evaluate(far_case).concrete_components['force_states'][1]
    assert 'case2' in state['label'] and state['forces']['A1']==10000.


@pytest.mark.parametrize('missing',['cone','mechanical','distribution','parallel'])
def test_interaction_missing_prerequisites_still_pending(missing):
    c=qualified();u=c.concrete_components
    if missing=='cone':c=replace(c,cone_model='off')
    elif missing=='mechanical':c=confirm(replace(c,concrete_components=replace(u,mechanical_resistance=0.,mechanical_ref='')))
    elif missing=='distribution':c=replace(c,concrete_components=replace(u,distribution_confirmation=''))
    else:c=confirm(replace(c,concrete_components=replace(u,parallel_model='pending')))
    assert evaluate(c).concrete_components['modes']['interaction']['passes'] is None
