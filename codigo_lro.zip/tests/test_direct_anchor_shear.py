"""Independent arithmetic controls and fail-closed contract tests.

The expected capacities below are calculated from rational/Decimal expressions,
not by invoking private helpers or reproducing the production implementation.
"""
from copy import deepcopy
from dataclasses import fields, replace
from decimal import Decimal
import json
import math
import random

import pytest

from lro.direct_anchor_shear import DirectAnchorShear, evaluate_direct_anchor_shear, MODEL


def config(**changes):
    base = DirectAnchorShear(
        model=MODEL,material_name='Classe 4.6',material_basis='EN_bolt',
        material_specification='EN ISO 898-1:1999',material_reference='Certificado C001: fy=240; fu=400',
        material_quality_reference='Certificado C001: alongamento e qualidade de fabricação',
        fy=240.,fu=400.,thread_area=353.,thread_manufacture='cut',
        thread_compliance='en1090_verified',thread_reference='M24; As=353 mm²; EN1090, lote R1',
        hole_diameter=26.,hole_kind='normal_round',normal_hole_tolerance_verified=True,
        execution_reference='Plano D01: gabarito, tolerâncias normais e inspeção dos furos',
        grout_complete=True,grout_cured=True,no_free_standoff=True,grout_reference='G01: preenchido e curado',
        service_slip_requirement='ordinary_bearing',plate_transfer_complete=True,
        plate_transfer_reference='P01: placa, seções líquidas/bloco, soldas e rigidez verificadas',static_loading=True)
    return replace(base, **changes)


def inputs(**changes):
    data = dict(rods=[dict(id='L-',x=-100.,y=-70.,tension=10000.),
                      dict(id='L+',x=-100.,y=70.,tension=10000.),
                      dict(id='R-',x=100.,y=-70.,tension=0.),
                      dict(id='R+',x=100.,y=70.,tension=0.)],
                L=400.,B=300.,tp=20.,plate_fu=450.,db=24.,V=40000.,grout_t=25.,grout_fck=40.,fck=30.)
    data.update(changes)
    return data


def run(u=None, **changes):
    return evaluate_direct_anchor_shear(config() if u is None else u, **inputs(**changes))


def state(out, sid):
    return next(s for s in out['states'] if s['id']==sid)


def assert_finite_json(out):
    json.dumps(out,allow_nan=False)
    assert out['valid'] is False
    assert out['direct_route_resistance_pass'] is False
    assert out['complete'] is False


def test_published_m24_control_and_separate_foundation_scope():
    out=run()
    assert out['valid'] and out['domain']['eligible'] and out['steel_plate_uls']['passes']
    r=out['resistances']
    assert r['alpha_bc']==pytest.approx(.368)
    assert r['F1_N']==pytest.approx(56480.)
    assert r['F2_N']==pytest.approx(41569.28)
    assert r['tension_Rd_N']==pytest.approx(101664.)
    assert r['shear_Rd_N']==pytest.approx(41569.28)
    assert r['beta_Lf']==1 and r['shear_governing']=='F2'
    assert all(b['bearing_Rd_N']==pytest.approx(384000.) for b in out['bearings'].values())
    assert out['foundation_scope']['complete'] is False
    assert out['aci_components']['complete'] is False
    assert out['complete'] is False and out['direct_route_resistance_pass'] is False
    json.dumps(out,allow_nan=False)


def test_three_alternative_states_not_summed_and_real_tension_retained():
    out=run()
    assert len(out['states'])==3
    assert list(s['id'] for s in out['states'])==['normal_hole_equal','leading_row','opposite_row_envelope']
    for s in out['states']:
        assert sum(s['forces'].values())==40000.
        assert s['sum_shear_N']==40000. and s['residual_force_N']==0. and s['residual_torsion_Nmm']==0.
        assert s['equilibrium_pass']
        assert {a['id']:a['tension'] for a in s['rods']}=={'L-':10000.,'L+':10000.,'R-':0.,'R+':0.}
        assert s['rod_moment_calculated'] is False
        assert all('Mrod' not in a and 'moment' not in a for a in s['rods'])
        assert all(isinstance(c['demand'],(int,float)) and isinstance(c['resistance'],(int,float)) for c in s['checks'])
        assert all(c['ratio'] is None or math.isfinite(c['ratio']) for c in s['checks'])
    assert set(state(out,'normal_hole_equal')['forces'].values())=={10000.}
    assert state(out,'leading_row')['forces']=={'L-':0.,'L+':0.,'R-':20000.,'R+':20000.}
    assert state(out,'opposite_row_envelope')['forces']=={'L-':20000.,'L+':20000.,'R-':0.,'R+':0.}


def test_sign_reversal_changes_plate_reaction_and_front_row_not_tensions():
    a=run();b=run(V=-40000.)
    assert state(a,'leading_row')['forces']==state(b,'opposite_row_envelope')['forces']
    assert state(a,'opposite_row_envelope')['forces']==state(b,'leading_row')['forces']
    for sid in ('normal_hole_equal','leading_row','opposite_row_envelope'):
        assert [r['tension'] for r in state(a,sid)['rods']]==[r['tension'] for r in state(b,sid)['rods']]
        assert all(r['signed_shear']<=0 for r in state(b,sid)['rods'])
    assert a['bearings']['L-']['reaction_edge']=='x-'
    assert b['bearings']['L-']['reaction_edge']=='x+'
    assert a['bearings']['L-']['longitudinal_kind']=='end'
    assert b['bearings']['L-']['longitudinal_kind']=='interior'


def test_cut_unverified_reduction_only_f1_and_tension_not_f2():
    a=run();b=run(config(thread_compliance='unverified_cut'))
    for key in ('F1_N','tension_Rd_N'):
        assert b['resistances'][key]==pytest.approx(.85*a['resistances'][key])
    assert b['resistances']['F2_N']==a['resistances']['F2_N']
    assert b['resistances']['F2_extra_thread_reduction'] is False
    assert b['valid']


def test_long_joint_reduction_bounded_and_f2_not_reduced():
    short=run(config(thread_compliance='unverified_cut'))
    for length,beta in [(360.,1.),(600.,.95),(1560.,.75),(2000.,.75)]:
        rods=inputs()['rods']
        for r in rods:r['x']=math.copysign(length/2,r['x'])
        out=run(config(thread_compliance='unverified_cut'),rods=rods,L=length+200.)
        assert out['resistances']['beta_Lf']==pytest.approx(beta)
        assert out['resistances']['F1_N']==pytest.approx(48008.*beta)
        assert out['resistances']['F2_N']==short['resistances']['F2_N']
        assert out['resistances']['Lj_mm']==length
    assert out['resistances']['shear_governing']=='F1'


def test_every_hole_affects_plate_bearing_even_zero_shear_holes():
    out=run(L=280.,tp=2.,V=50000.)
    leading=state(out,'leading_row');opposite=state(out,'opposite_row_envelope')
    # Decimal independent control: edge distance 40 mm / (3*26 mm).
    edge=Decimal('2.5')*(Decimal(40)/Decimal(78))*Decimal(450)*Decimal(24)*Decimal(2)/Decimal('1.25')
    assert out['bearings']['L-']['bearing_Rd_N']==pytest.approx(float(edge))
    assert out['bearings']['R-']['bearing_Rd_N']==pytest.approx(38400.)
    assert out['bearings']['R-']['p1_mm']==200.
    assert out['bearings']['R-']['clear_ligament_mm']==174.
    assert out['bearings']['R-']['longitudinal_kind']=='interior'
    assert leading['forces']['L-']==0 and leading['passes']
    assert not opposite['passes'] and not out['valid']
    assert out['steel_plate_uls']['status']=='fail'


def test_independent_tension_and_interaction_even_no_shear_on_tension_row():
    data=inputs()
    for r in data['rods']:
        r['tension']=102000. if r['x']<0 else 0.
    out=evaluate_direct_anchor_shear(config(),**data)
    leading=state(out,'leading_row')
    check=next(c for c in leading['checks'] if c['id']=='leading_row_tension_L-')
    assert check['demand']==102000. and check['resistance']==101664.
    assert not check['passes'] and not leading['passes'] and not out['valid']


def test_interaction_with_reduced_f2_not_unreduced_f1():
    out=run()
    c=next(c for c in state(out,'opposite_row_envelope')['checks'] if c['id'].endswith('interaction_L-'))
    expected=Decimal(20000)/Decimal('41569.28')+Decimal(10000)/(Decimal('1.4')*Decimal(101664))
    assert c['demand']==pytest.approx(float(expected)) and c['resistance']==1.
    assert c['ratio']==c['demand']


def test_row_resistance_is_n_times_minimum_with_interaction():
    out=run()
    s=state(out,'opposite_row_envelope')
    row=s['row_capacities'][0]
    expected=2*41569.28*(1-10000/(1.4*101664.))
    assert row['n']==2 and row['resistance_N']==pytest.approx(expected)
    assert row['demand_N']==40000.


def test_line_1x2_uses_two_not_four_and_one_state():
    rods=[dict(id='A',x=0.,y=-70.,tension=12000.),dict(id='B',x=0.,y=70.,tension=12000.)]
    out=run(rods=rods)
    assert out['valid'] and out['geometry']['layout']=='line_1x2'
    assert len(out['states'])==1 and out['states'][0]['forces']=={'A':20000.,'B':20000.}
    assert out['resistances']['Lj_mm']==0 and out['resistances']['beta_Lf']==1.
    assert all(b['longitudinal_kind']=='end' for b in out['bearings'].values())


def test_zero_shear_still_checks_all_tension_and_keeps_state_identity():
    out=run(V=0.)
    assert out['valid'] and len(out['states'])==3
    assert all(s['sum_shear_N']==0. for s in out['states'])
    assert all(len(s['rods'])==4 for s in out['states'])
    assert all(any(c['demand']==10000. for c in s['checks'] if '_tension_' in c['id']) for s in out['states'])


@pytest.mark.parametrize('mode', ['no_slip','numeric_total_limit','wrong',''])
def test_els_never_approved_by_clearance_alone(mode):
    out=run(config(service_slip_requirement=mode,service_total_limit=1e5))
    assert out['steel_plate_uls']['passes']
    assert not out['service_scope']['passes'] and not out['valid']
    assert out['service_scope']['diametral_clearance_mm']==2.
    assert not out['service_scope']['total_displacement_calculated']


def test_ordinary_bearing_does_not_invent_contact_solver_obligation():
    out=run()
    assert out['service_scope']['passes']
    assert out['service_scope']['reasons']==[]
    assert out['pending_reasons']==[]


@pytest.mark.parametrize('change', [
    {'plate_transfer_complete':False}, {'plate_transfer_reference':''},
])
def test_full_plate_transfer_required_without_erasing_partial_capacities(change):
    out=run(config(**change))
    assert out['steel_plate_uls']['passes'] and out['domain']['eligible']
    assert out['plate_transfer_scope']['status']=='pending' and not out['valid']


@pytest.mark.parametrize('u', [
    config(material_name='ASTM A36',material_basis='ASTM_supplementary',material_specification='ASTM A36',fy=250.),
    config(material_name='ASTM A36',material_basis='EN_structural',material_specification='EN 10025-2',fy=250.),
    config(material_name='A36',material_basis='EN_rebar',material_specification='EN 10080',fy=250.),
    config(material_basis='equivalent',material_name='S235JR',material_specification='EN 10025-2',fy=250.),
    config(material_name='S235JR',material_basis='EN_structural',material_specification='EN 10025-2',fy=235.,fu=360.),
])
def test_astm_not_approved_by_boolean_equivalence_or_numerical_interval(u):
    out=run(u)
    assert not out['domain']['eligible'] and not out['valid']
    assert out['pending_reasons']


@pytest.mark.parametrize('basis,name,spec,fy,fu', [
    ('EN_structural','S355J2','EN 10025-2:2004',355.,470.),
    ('EN_bolt','Classe 8.8','EN ISO 898-1',640.,800.),
    ('EN_rebar','B500B','EN 10080:2005',500.,550.),
])
def test_documented_en_identities_in_conservative_property_range(basis,name,spec,fy,fu):
    out=run(config(material_basis=basis,material_name=name,material_specification=spec,fy=fy,fu=fu))
    assert out['valid'] and out['material']['en_3_3_identity_eligible']


@pytest.mark.parametrize('field', ['material_reference','material_quality_reference','thread_reference',
                                 'execution_reference','grout_reference'])
def test_missing_evidence_does_not_approve(field):
    out=run(config(**{field:'   '}))
    assert not out['domain']['eligible'] and not out['valid']


@pytest.mark.parametrize('change', [
    {'model':'off'}, {'static_loading':False}, {'torsion_z':1e-20},
    {'fy':234.9}, {'fy':640.1}, {'fu':399.9}, {'fu':800.1}, {'fy':500.,'fu':400.},
    {'thread_manufacture':'unknown'}, {'thread_compliance':'unknown'},
    {'thread_manufacture':'rolled','thread_compliance':'unverified_cut'},
    {'hole_kind':'oversized'}, {'hole_kind':'slot'}, {'hole_kind':'countersunk'},
    {'normal_hole_tolerance_verified':False}, {'hole_diameter':30.},
    {'grout_complete':False}, {'grout_cured':False}, {'no_free_standoff':False},
])
def test_domain_gates_fail_closed(change):
    out=run(config(**change))
    assert_finite_json(out)
    assert not out['domain']['eligible']


@pytest.mark.parametrize('change', [
    {'grout_t':40.001}, {'grout_t':0}, {'grout_t':-1.}, {'grout_fck':29.9},
    {'grout_fck':35.,'fck':40.}, {'db':25.4}, {'db':24.0000001},
    {'L':250.}, {'B':190.},
])
def test_physical_domain_limits(change):
    out=run(**change)
    assert_finite_json(out)
    assert not out['domain']['eligible']


def test_grout_domain_boundary_and_no_capacity_gain_with_thickness():
    a=run(grout_t=1e-9);b=run(grout_t=40.);c=run(grout_t=41.)
    assert a['valid'] and b['valid'] and not c['valid']
    assert a['resistances']==b['resistances']==c['resistances']
    assert a['bearings']==b['bearings']==c['bearings']


@pytest.mark.parametrize('db,d0,area', [(16.,18.,157.),(18.,20.,192.),(20.,22.,245.),(22.,24.,303.),
                                       (24.,26.,353.),(27.,30.,459.),(30.,33.,561.),(33.,36.,694.),(36.,39.,817.)])
def test_supported_metric_nominal_holes(db,d0,area):
    out=run(config(hole_diameter=d0,thread_area=area),db=db)
    assert out['domain']['eligible']
    assert out['geometry']['nominal_normal_hole_mm']==d0


def test_actual_smaller_normal_hole_used_not_nominal():
    out=run(config(hole_diameter=25.5),L=280.,tp=2.)
    expected=2.5*(40/(3*25.5))*450*24*2/1.25
    assert out['bearings']['L-']['bearing_Rd_N']==pytest.approx(expected)
    assert out['service_scope']['diametral_clearance_mm']==1.5


@pytest.mark.parametrize('mutate', [
    lambda r: r.pop(),
    lambda r: r.append(dict(id='fifth',x=0.,y=0.,tension=0.)),
    lambda r: r[0].update(id='L+'),
    lambda r: r[0].update(id=''),
    lambda r: r[0].update(y=-69.),
    lambda r: r[0].update(x=-99.),
    lambda r: r[0].update(tension=10001.),
    lambda r: r[0].update(tension=-1.),
    lambda r: r[0].update(x=190.),
    lambda r: r[0].update(x=100.,y=-70.),
    lambda r: r[0].pop('tension'),
    lambda r: r.__setitem__(0,None),
])
def test_invalid_group_never_auto_corrected(mutate):
    r=inputs()['rods'];mutate(r)
    out=run(rods=r)
    assert_finite_json(out)
    assert not out['domain']['eligible']


def test_one_line_off_centre_rejected():
    r=[dict(id='a',x=1.,y=-70.,tension=0.),dict(id='b',x=1.,y=70.,tension=0.)]
    assert not run(rods=r)['domain']['eligible']


@pytest.mark.parametrize('field', ['fy','fu','thread_area','hole_diameter','service_total_limit','torsion_z'])
@pytest.mark.parametrize('bad', [None,True,False,float('nan'),float('inf'),-float('inf'),'1',[],{},complex(1,2),10**400])
def test_every_config_numeric_malformed_is_closed_without_crash(field,bad):
    out=run(config(**{field:bad}))
    assert_finite_json(out)
    assert out['states']==[]


@pytest.mark.parametrize('field', list(inputs().keys()-{'rods'}))
@pytest.mark.parametrize('bad', [None,True,float('nan'),float('inf'),'1',[],{},10**400])
def test_every_external_numeric_malformed_is_closed_without_crash(field,bad):
    out=run(**{field:bad})
    assert_finite_json(out)
    assert out['states']==[]


@pytest.mark.parametrize('field', ['x','y','tension'])
@pytest.mark.parametrize('bad', [None,True,float('nan'),float('inf'),'1',[],{},10**400])
def test_every_rod_numeric_malformed_is_closed_without_crash(field,bad):
    r=inputs()['rods'];r[0][field]=bad
    out=run(rods=r)
    assert_finite_json(out)
    assert out['states']==[]


TEXT_FIELDS=[f.name for f in fields(DirectAnchorShear) if isinstance(f.default,str)]
BOOL_FIELDS=[f.name for f in fields(DirectAnchorShear) if type(f.default) is bool]


@pytest.mark.parametrize('field',TEXT_FIELDS)
@pytest.mark.parametrize('bad',[None,[],{},True,1.])
def test_every_text_field_malformed_is_closed_without_crash(field,bad):
    out=run(config(**{field:bad}))
    assert_finite_json(out)


@pytest.mark.parametrize('field',BOOL_FIELDS)
@pytest.mark.parametrize('bad',[None,0,1,'true',[],{}])
def test_boolean_flags_require_boolean(field,bad):
    out=run(config(**{field:bad}))
    assert_finite_json(out)


@pytest.mark.parametrize('bad',[None,True,{},'',[],12.,[None,None], [dict(id=[],x=0,y=0,tension=0)]*2])
def test_malformed_rods_container_and_ids(bad):
    assert_finite_json(run(rods=bad))


@pytest.mark.parametrize('bad',[None,True,{},'config',[],12.])
def test_malformed_config(bad):
    out=evaluate_direct_anchor_shear(bad,**inputs())
    assert_finite_json(out)


@pytest.mark.parametrize('field', ['fy','fu','thread_area','hole_diameter','service_total_limit','torsion_z'])
@pytest.mark.parametrize('bad', [1e300,-1e300])
def test_extreme_but_finite_config_values(field,bad):
    assert_finite_json(run(config(**{field:bad})))


@pytest.mark.parametrize('field',list(inputs().keys()-{'rods'}))
@pytest.mark.parametrize('bad',[1e300,-1e300])
def test_extreme_but_finite_external_values(field,bad):
    assert_finite_json(run(**{field:bad}))


def test_huge_tension_cannot_create_nonfinite_ratios_or_pass():
    r=inputs()['rods']
    for a in r:a['tension']=1e15
    out=run(rods=r,V=1e15)
    assert_finite_json(out)
    assert not out['steel_plate_uls']['passes']


def test_minimum_positive_but_unusable_bearing_stays_finite():
    # Physically disjoint small holes/plate can be outside code minimum.
    r=[dict(id='a',x=0.,y=-16.1,tension=0.),dict(id='b',x=0.,y=16.1,tension=0.)]
    out=run(config(hole_diameter=18.,thread_area=157.),rods=r,L=40.,B=50.4,db=16.)
    assert_finite_json(out)
    assert out['steel_plate_uls']['status']=='fail'


def test_no_input_mutation_and_permutation_invariance():
    u=config();data=inputs();saved=deepcopy(data);first=evaluate_direct_anchor_shear(u,**data)
    assert data==saved
    random.Random(42).shuffle(data['rods'])
    second=evaluate_direct_anchor_shear(u,**data)
    assert first==second


def test_unused_washer_fields_cannot_add_strength_or_restraint():
    a=config();b=config()
    a.washer_thickness=1.;b.washer_thickness=5000.
    a.washer_stiffness=0.;b.washer_stiffness=1e20
    assert run(a)==run(b)


def test_from_dict_roundtrip_does_not_convert_strings_or_boolean_equivalence():
    u=config();saved={f.name:getattr(u,f.name) for f in fields(u)}
    assert DirectAnchorShear.from_dict(saved)==u
    saved['fy']='240'
    assert not run(DirectAnchorShear.from_dict(saved))['valid']
    with pytest.raises(ValueError):DirectAnchorShear.from_dict([])


def test_randomized_finite_geometry_and_loads_close_without_exceptions():
    rng=random.Random(20261017)
    for _ in range(150):
        x=rng.uniform(.1,1000.);y=rng.uniform(.1,1000.)
        a=rng.uniform(0.,2e5);b=rng.uniform(0.,2e5)
        r=[dict(id=str(i),x=xx,y=yy,tension=t) for i,(xx,yy,t) in enumerate(
            [(-x,-y,a),(-x,y,a),(x,-y,b),(x,y,b)])]
        out=run(rods=r,L=rng.uniform(.1,2400.),B=rng.uniform(.1,2400.),
                tp=rng.uniform(.1,150.),V=rng.uniform(-1e6,1e6))
        json.dumps(out,allow_nan=False)
        if out['valid']:
            assert out['domain']['eligible'] and all(s['passes'] for s in out['states'])
        for s in out['states']:
            assert s['equilibrium_pass']


def supplemental_config(db=25.4,tpi=8.,**changes):
    from lro.direct_anchor_shear import unc_thread_area
    u=config(material_name='ASTM A36/A36M',material_basis='ASTM_supplementary',
             material_specification='ASTM A36/A36M-19',fy=250.,fu=400.,
             material_protocol='astm_a36_supplementary_v1',
             material_reference='C002: produto final ASTM A36/A36M-19, rastreável por lote',
             material_quality_reference='Q002: usinagem e processo final sem alteração/fragilização das propriedades',
             ductility_reference='D002: alongamento do produto final atende A36/A6, base de medida documentada',
             certification_reference='C002: certificado do produto final e fabricação',
             supplementary_application_accepted=True,thread_standard='UNC_2A',thread_tpi=tpi,
             thread_area=unc_thread_area(db,tpi),thread_area_source='calculated_asme',
             thread_manufacture='cut',thread_compliance='unverified_cut',
             thread_reference='R002: ASME B1.1, UNC Class 2A; perfil/diâmetro/passo do produto documentados',
             hole_basis='supplementary_unc_bounded',hole_diameter=db+(2. if db<=24 else 3.))
    return replace(u,**changes)


@pytest.mark.parametrize('db,tpi,area,f2',[
    (19.05,10.,215.7801664,25203.12343),
    (22.225,9.,297.8918287,34793.76559),
    (25.4,8.,390.8017891,45645.64897),
])
def test_independent_unc_decimal_controls(db,tpi,area,f2):
    from lro.direct_anchor_shear import unc_thread_area
    assert unc_thread_area(db,tpi)==pytest.approx(area,rel=1e-9)
    out=run(supplemental_config(db,tpi),db=db)
    assert out['valid']
    assert out['resistances']['F2_N']==pytest.approx(f2,rel=1e-9)
    assert out['domain']['status']=='supplemental_qualified'
    assert out['material']['qualification_status']=='astm_a36_supplemental'
    assert out['material']['en_3_3_identity_eligible'] is False
    assert out['material']['area_source']=='calculated_asme'
    assert out['material']['unc_design_area_mm2']==unc_thread_area(db,tpi)
    assert out['geometry']['nominal_normal_hole_mm'] is None
    assert out['geometry']['hole_basis']=='supplementary_unc_bounded'
    assert out['resistances']['kthread']==.85


@pytest.mark.parametrize('db,tpi',[(28.575,7.),(31.75,7.)])
def test_larger_initial_unc_pairs_supported_without_metric_rounding(db,tpi):
    out=run(supplemental_config(db,tpi),db=db)
    assert out['domain']['eligible'] and out['valid']
    assert out['geometry']['actual_hole_mm']==db+3.
    assert out['material']['thread_tpi']==tpi


@pytest.mark.parametrize('change',[
    {'material_protocol':''}, {'material_protocol':'approved'},
    {'supplementary_application_accepted':False},
    {'ductility_reference':''}, {'certification_reference':''},
    {'material_reference':''}, {'material_quality_reference':''},
    {'thread_reference':''}, {'material_specification':'ASTM A36'},
    {'material_specification':'ASTM A36/A36M'}, {'material_name':'ASTM F1554'},
    {'fy':330.,'fu':400.}, {'thread_manufacture':'rolled'},
    {'thread_tpi':7.}, {'thread_area_source':'unknown'}, {'thread_area':400.},
    {'hole_basis':'en_normal_nominal'}, {'hole_diameter':28.575},
    {'thread_compliance':'en1090_verified'},
])
def test_astm_protocol_missing_or_conflicting_evidence_never_approves(change):
    out=run(supplemental_config(**change),db=25.4)
    assert_finite_json(out)
    assert not out['domain']['eligible']
    assert out['material']['qualification_status']=='study_unqualified'


def test_astm_acceptance_is_not_en_equivalence_even_when_documented():
    good=run(supplemental_config(),db=25.4)
    bad=run(replace(supplemental_config(),material_basis='EN_structural'),db=25.4)
    assert good['valid'] and not bad['valid']
    assert good['material']['en_3_3_identity_eligible'] is False
    assert bad['material']['en_3_3_identity_eligible'] is False


def test_astm_cut_factor_never_disappears_if_en1090_flag_set():
    out=run(supplemental_config(thread_compliance='en1090_verified'),db=25.4)
    assert not out['valid'] and out['resistances']['kthread']==.85


def test_unc_documented_smaller_area_not_misrepresented_as_calculated():
    out=run(supplemental_config(thread_area=390.,thread_area_source='documented'),db=25.4)
    assert out['valid']
    assert out['material']['As_mm2']==390.
    assert out['material']['area_source']=='documented'
    bad=run(supplemental_config(thread_area=390.,thread_area_source='calculated_asme'),db=25.4)
    assert not bad['valid']


@pytest.mark.parametrize('db,tpi',[(38.1,6.),(44.45,5.),(50.8,4.5),(25.4,7.),(24.,8.),(True,8.),(25.4,True)])
def test_unc_helper_rejects_unknown_or_inconsistent_series(db,tpi):
    from lro.direct_anchor_shear import unc_thread_area
    with pytest.raises(ValueError):unc_thread_area(db,tpi)


@pytest.mark.parametrize('bad',[None,True,False,float('nan'),float('inf'),-float('inf'),'1',[],{},10**400,1e300,-1e300])
def test_thread_tpi_malformed_and_extreme_is_closed(bad):
    assert_finite_json(run(supplemental_config(thread_tpi=bad),db=25.4))


def test_from_dict_unknown_field_does_not_silently_change_scope():
    with pytest.raises(ValueError):
        DirectAnchorShear.from_dict({'model':MODEL,'material_eligibile':True})


def test_unc_not_accepted_only_from_generic_material_boolean():
    # Unknown fields rejected, legacy material defaults do not migrate.
    with pytest.raises(ValueError):
        DirectAnchorShear.from_dict({'material_basis':'ASTM_supplementary','en_eligible':True})
    u=DirectAnchorShear.from_dict({'model':MODEL,'material_name':'ASTM A36','fy':250.,'fu':400.})
    assert not run(u)['valid']


def test_auditor_independent_interaction_and_bearing_controls():
    rods=[dict(id=str(i),x=x,y=y,tension=30000.) for i,(x,y) in enumerate(
        [(-50.,-50.),(-50.,50.),(50.,-50.),(50.,50.)])]
    out=run(rods=rods,L=200.,B=200.,plate_fu=400.)
    reduced=run(config(thread_compliance='unverified_cut'),rods=rods,L=200.,B=200.,plate_fu=400.)
    c=next(c for c in state(out,'leading_row')['checks'] if c['id'].endswith('interaction_2'))
    cr=next(c for c in state(reduced,'leading_row')['checks'] if c['id'].endswith('interaction_2'))
    assert c['ratio']==pytest.approx(.6919028851,rel=1e-9)
    assert cr['ratio']==pytest.approx(.7290990666,rel=1e-9)
    assert out['bearings']['0']['bearing_Rd_N']==pytest.approx(246153.8462,rel=1e-9)


@pytest.mark.parametrize('name',['Classe 10.9','10.9','Classe 4.6 or 8.8','Unknown 4.6'])
def test_bolt_class_identity_not_overridden_by_fake_lower_strengths(name):
    out=run(config(material_name=name,fy=240.,fu=400.))
    assert not out['domain']['eligible'] and not out['valid']


@pytest.mark.parametrize('area',[1e-320,1e-300,1e-30])
def test_subnormal_or_tiny_area_does_not_overflow_ratios(area):
    out=run(config(thread_area=area))
    assert_finite_json(out)
    assert out['states']==[]


def test_minimum_geometry_coefficients_independent_control():
    d0=26.;e=1.2*d0;p2=2.4*d0
    rods=[dict(id=str(i),x=x,y=y,tension=0.) for i,(x,y) in enumerate(
        [(-40.,-p2/2),(-40.,p2/2),(40.,-p2/2),(40.,p2/2)])]
    out=run(rods=rods,L=80.+2*e,B=p2+2*e)
    assert out['domain']['eligible']
    b=out['bearings']['0']
    assert b['k1']==pytest.approx(1.66)
    assert b['alpha_b']==pytest.approx(.4)
    assert b['bearing_Rd_N']==pytest.approx(114739.2)
    assert out['bearings']['2']['alpha_d']==pytest.approx(80/78-.25)


@pytest.mark.parametrize('edge,pitch',[(31.2,200.),(100.,62.4)])
def test_each_transverse_coefficient_can_govern_independently(edge,pitch):
    rods=inputs()['rods']
    for a in rods:a['y']=math.copysign(pitch/2,a['y'])
    out=run(rods=rods,B=pitch+2*edge)
    assert out['domain']['eligible']
    assert out['bearings']['L-']['k1']==pytest.approx(1.66)
    assert out['bearings']['L-']['bearing_Rd_N']==pytest.approx(254976.)


@pytest.mark.parametrize('db',[-1.,0.,1e-6,1e6])
def test_finite_extreme_diameter_never_creates_a_valid_new_series(db):
    out=run(db=db)
    assert_finite_json(out)


def test_unspecified_els_numeric_limit_zero_never_passes():
    out=run(config(service_slip_requirement='numeric_total_limit',service_total_limit=0.))
    assert not out['valid'] and out['service_scope']['status']=='pending'
    assert len(out['service_scope']['reasons'])==2


def test_plate_strength_ratio_uses_rod_fu_not_rod_fy():
    out=run(plate_fu=800.)
    # Geometry factors are capped at k1=2.5, alpha_d>=1. Thus alpha_b=fu_rod/fu_plate=.5.
    assert out['bearings']['L-']['alpha_b']==.5
    assert out['bearings']['L-']['bearing_Rd_N']==384000.


def test_bearing_oversize_scope_failure_still_does_not_rewrite_hole():
    out=run(config(hole_diameter=30.))
    assert not out['valid'] and out['geometry']['actual_hole_mm']==30.
    assert out['service_scope']['diametral_clearance_mm']==6.
    assert out['material']['As_mm2']==353.


@pytest.mark.parametrize('grade,fy,fu',[
    ('4.6',240.,400.),('4.8',320.,400.),('5.6',300.,500.),
    ('5.8',400.,500.),('6.8',480.,600.),('8.8',640.,800.)])
def test_en_bolt_nominal_class_properties_consistent(grade,fy,fu):
    assert run(config(material_name=grade,fy=fy,fu=fu))['valid']


@pytest.mark.parametrize('change',[
    {'material_name':'4.6','fy':640.,'fu':800.},
    {'material_name':'8.8','fy':240.,'fu':400.},
    {'material_name':'4.6','material_specification':'EN 14399-3'},
])
def test_en_bolt_strength_or_specification_cannot_be_falsely_relabelled(change):
    out=run(config(**change))
    assert not out['domain']['eligible'] and not out['valid']
