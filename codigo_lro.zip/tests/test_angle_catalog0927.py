"""Exact producer row identities and intentionally incomplete catalog properties."""
import hashlib
import json
from pathlib import Path
import pytest
from lro.angle_catalog import catalog, get_angle, label, provenance, LEGACY_ARCELOR_ID

DATA=Path(__file__).parents[1]/'data/gerdau_equal_angles.json'


def test_authoritative_extraction_preserved_byte_for_byte():
    assert hashlib.sha256(DATA.read_bytes()).hexdigest()=='b412b9af03a073110627dfb055cde103cd86f9d2c699db122a45e1a2605c1a60'
    assert provenance()['sha256']=='3c7024ae143f4f57c010812eda8abd796e5b4a6cb599fe6616e644847ee72bc4'
    assert provenance()['physical_pdf_page']==3


def test_all52_rows_exact_printed_metrics_no_inch_reconstruction():
    rows=json.loads(DATA.read_text())['rows']; records=catalog(include_incomplete=True)
    assert len(records)==52
    assert list(records)==[r['id'] for r in rows]
    for row in rows:
        s=records[row['id']];d=row['normalized_decimal']
        assert s['leg']==float(d['leg_mm'])
        assert s['t']==float(d['thickness_mm'])
        for dest,source in [('Ag','Ag_mm2'),('centroid','centroid_x_mm')]:
            assert s[dest]==(float(d[source]) if d[source] is not None else None)
        assert s['normalized_decimal']==d
        assert s['source_raw']==row['source_raw']
        assert s['manufacturer']=='Gerdau'
        assert all(s[k] is None for k in ('root_radius','toe_radius','toe_flat'))
        assert 'fy' not in s and 'fu' not in s
    assert records['GERDAU_EQUAL_ANGLE_P03_R03']['t']==3.18
    assert records['GERDAU_EQUAL_ANGLE_P03_R06']['leg']==22.2


def test_missing_properties_are_never_reconstructed():
    rows=catalog(include_incomplete=True)
    assert len(catalog())==50
    assert sum(s['Ag'] is not None and s['centroid'] is not None for s in rows.values())==50
    for i in (1,2):
        s=rows[f'GERDAU_EQUAL_ANGLE_P03_R{i:02d}']
        assert s['Ag'] is None and s['centroid'] is None
        assert not s['section_properties_published']
        assert get_angle(s['id']) is None
        assert s['id'] not in catalog()


def test_exact_gerdau4inch_half_is_not_arcelor100x12():
    a=get_angle(LEGACY_ARCELOR_ID)
    g=next(s for s in catalog().values() if s['leg']==101.6 and s['t']==12.7)
    assert (g['Ag'],g['centroid'])==(2419.,30.)
    assert (a['leg'],a['t'],a['Ag'],a['centroid'])==(100.,12.,2270.,29.)
    assert g['id']!=a['id'] and a['manufacturer']=='ArcelorMittal'
    assert len(catalog(include_legacy=True))==51
    assert get_angle('L101.6x101.6x12.7') is None


def test_mutation_does_not_poison_catalog_or_provenance():
    rows=catalog();rows['GERDAU_EQUAL_ANGLE_P03_R03']['leg']=999
    assert get_angle('GERDAU_EQUAL_ANGLE_P03_R03')['leg']==12.7
    a=get_angle(LEGACY_ARCELOR_ID);a['t']=999
    assert get_angle(LEGACY_ARCELOR_ID)['t']==12.
    p=provenance();p['physical_pdf_page']=999
    assert provenance()['physical_pdf_page']==3


def test_resolved_mass_area_choice_preserves_source_without_warning():
    s=get_angle('GERDAU_EQUAL_ANGLE_P03_R46')
    assert (s['mass'],s['Ag'])==(23.52,2696.)
    assert not s['review_flags']
    assert s['property_selection_criterion']
    source=next(r for r in json.loads(DATA.read_text())['rows'] if r['id']==s['id'])
    assert source['review_flags']
