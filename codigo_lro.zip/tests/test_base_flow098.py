"""Applicability and presentation regressions for 0.9.8; no new resistance model."""
from dataclasses import replace
from io import BytesIO
import math
import pytest
from docx import Document
from lro.base_plate import evaluate,BasePlateResult
from lro.concrete_components import ConcreteComponents,anchor_shear_demand
from lro.single_key_weld import SingleKeyWeld
from lro.single_key_concrete import SingleKeyConcrete
from lro.models import Issue,Check
from lro.base_plate_report import create_report
from test_base_components_integration import qualified
from test_base_weld_qualified import config,bind,evaluate as weld_evaluate


@pytest.mark.parametrize('family',[1,2])
@pytest.mark.parametrize('route',['friction','plate'])
def test_zero_anchor_shear_without_tension_needs_no_anchor_capacity_inputs(family,route):
    c=replace(qualified(family),N=150000.,V=20000.,shear_path=route,
              anchor_type='unspecified',anchor_detail_confirmed=False,
              concrete_components=ConcreteComponents(model='aci318_19'),
              single_key_concrete=SingleKeyConcrete(rod_restraint='unwelded'))
    if family==1:c=replace(c,M=0.)
    r=evaluate(c);out=r.concrete_components
    assert out['component_demands']['V_column']==20000.
    assert out['component_demands']['V_anchor']==0.
    for name in ('pullout','sideface','head_mechanical','aci_steel','interaction'):
        assert out['modes'][name]['status']=='not_demanded'
        assert not out['modes'][name]['checks'] and not out['modes'][name]['reasons']
    for name in ('breakout','pryout'):
        assert out['modes'][name]['status']=='not_applicable'
        assert not out['modes'][name]['checks']
    assert not any(x.origin=='concrete_components' and x.severity=='pending' for x in r.issues)


@pytest.mark.parametrize('family',[1,2])
@pytest.mark.parametrize('route',['friction','plate'])
def test_tension_only_aci_uses_no_shear_area_or_capacity(family,route):
    c=qualified(family)
    c=replace(c,shear_path=route,V=2000.,single_key_concrete=SingleKeyConcrete(rod_restraint='unwelded'),
              concrete_components=replace(c.concrete_components,area_shear=0.))
    r=evaluate(c);out=r.concrete_components
    assert out['modes']['aci_steel']['status']=='calculated'
    checks=out['modes']['aci_steel']['checks']
    assert checks and all(x['id'].startswith('aci_tension_') for x in checks)
    assert out['modes']['interaction']['beta_V']==0.
    assert out['force_states'] and all(q==0. for state in out['force_states'] for q in state['forces'].values())
    assert not any(x.id.startswith('bp_cc_breakout') or x.id.startswith('bp_cc_pryout') for x in r.checks)


@pytest.mark.parametrize('restraint',['unknown','welded'])
def test_key_restraint_unknown_or_welded_never_invents_rod_shear(restraint):
    c=replace(qualified(),shear_path='plate',single_key_concrete=SingleKeyConcrete(rod_restraint=restraint))
    out=evaluate(c).concrete_components
    assert out['component_demands']['V_anchor'] is None
    assert out['modes']['breakout']['status']=='pending'
    assert out['modes']['pryout']['status']=='pending'
    assert not out['force_states']
    assert out['modes']['interaction']['passes'] is None


def test_hidden_key_restraint_does_not_override_declared_friction_route():
    c=replace(qualified(),shear_path='friction',single_key_concrete=SingleKeyConcrete(rod_restraint='welded',restraint_ref='Old key-only detail'))
    assert anchor_shear_demand(c)['V_anchor']==0.
    assert anchor_shear_demand(c)['V_friction']==c.V
    assert evaluate(c).concrete_components['modes']['breakout']['status']=='not_applicable'


@pytest.mark.parametrize('value',[True,float('inf'),float('nan'),'bad'])
def test_inactive_weld_keeps_strict_type_and_finite_validation(value):
    c=replace(qualified(),shear_path='friction',single_key_weld=SingleKeyWeld(size=value))
    assert any(i.severity=='error' for i in evaluate(c).issues)


def test_final_group_is_single_governing_row_and_individual_states_remain():
    c=qualified();r=evaluate(c)
    ids={x.id for x in r.checks}
    assert 'bp_anchor_shear_native' in ids
    assert not {'bp_anchor_shear_special','bp_anchor_shear_interaction'}&ids
    assert all('bp_cc_nbr_actual_A'+str(i) in ids for i in range(1,5))
    ash=r.geometry['anchor_shear']
    assert ash['group_rd']==sum(min(x['steel_rd'],x['combined_rd'],ash['concrete_cap']) for x in ash['rods'])
    assert ash['special_group_rd']>=ash['group_rd']
    assert ash['combined_group_rd']>=ash['group_rd']


def test_finite_failure_priority_over_other_pending_or_unsupported_modes():
    r=BasePlateResult(issues=[Issue('model','Unsupplied equilibrium','test'),Issue('pending','Some data','test')],
                      checks=[Check('test','Known local failure',2.,1.,'N','test','','','')])
    assert r.component_outcome=='fail' and r.component_status=='NÃO ATENDE ÀS VERIFICAÇÕES REALIZADAS'


def test_one_transfer_record_replaces_redundant_essays_without_execution_claim():
    c=config();c=bind(replace(c,column_weld=replace(c.column_weld,allocation_basis='',effective_length_basis='',
                                                  execution_ref='',procedure_ref='',inspection_ref='')))
    out,r=weld_evaluate(c)
    assert out['status']=='pass' and out['qualification_status']=='qualified'
    assert out['execution_status']=='specified_not_verified'
    assert out['connection_status']=='pending' and not out['complete']
    assert out['calculation_basis'] and out['design_specification']
    original,_=weld_evaluate(config())
    for name in ('F_left_N','F_right_N','web_shear_N','residual_N_N','residual_M_Nmm','residual_V_N'):
        assert out[name]==original[name]
    assert out['flange']==original['flange'] and out['web']==original['web']


def test_unbound_real_external_transfer_remains_pending_without_erasing_calculated_weld():
    c=config();c=replace(c,column_weld=replace(c.column_weld,qualification_signature='',transfer_ref=''))
    out,r=weld_evaluate(c)
    assert out['numerical_status']=='pass' and out['status']=='pending'
    assert out['qualification_status']=='missing'


def test_zero_anchor_shear_report_does_not_ask_for_shear_area_or_distribution():
    c=qualified();c=replace(c,shear_path='friction',concrete_components=replace(c.concrete_components,area_shear=0.))
    doc=Document(BytesIO(create_report(c,evaluate(c))))
    text='\n'.join(p.text for p in doc.paragraphs)+'\n'+'\n'.join(cell.text for t in doc.tables for row in t.rows for cell in row.cells)
    assert 'Cortante nos chumbadores' in text and 'Não aplicável no domínio verificado' in text
    assert 'Área efetiva de aço Ase,V' not in text
    assert 'Qualificação da distribuição' not in text


def test_optional_records_preserve_custom_binding_but_stale_results_cannot_export():
    from lro.base_weld_qualified import qualification_signature,qualification_binding_kind
    from lro.column_base_weld_drawing import require_current_result
    c=config();r=evaluate(c)
    changed=replace(c,column_weld=replace(c.column_weld,procedure_ref='WPS revision metadata',allocation_basis='Extra note'))
    assert qualification_signature(changed)==qualification_signature(c)
    assert qualification_binding_kind(changed)=='current'
    with pytest.raises(ValueError,match='desatualizado'):require_current_result(changed,r)
    assert weld_evaluate(changed)[0]['qualification_status']=='qualified'


def test_exact_legacy_binding_is_recognized_but_changed_force_is_not():
    from lro.base_weld_qualified import qualification_signature,qualification_binding_kind
    c=config();old=qualification_signature(c,legacy=True)
    c=replace(c,column_weld=replace(c.column_weld,qualification_signature=old))
    assert qualification_binding_kind(c)=='legacy_current'
    assert weld_evaluate(c)[0]['qualification_status']=='qualified'
    assert qualification_binding_kind(replace(c,V=c.V+1))=='stale'


@pytest.mark.parametrize('family',[1,2])
@pytest.mark.parametrize('component',['upper_washer','column_weld','concrete_components','key_dimensions','washer_dimensions'])
def test_inactive_physical_ranges_preserved_without_blocking_active_route(family,component):
    from lro.upper_washer import UpperWasher
    from lro.column_base_weld import ColumnBaseWeld
    c=replace(qualified(family),shear_path='friction',concrete_components=ConcreteComponents())
    changes={
        'upper_washer':dict(upper_washer=UpperWasher(model='four_edge_elastic',leg=-1.)),
        'column_weld':dict(column_weld=ColumnBaseWeld(web_length=-1.)),
        'concrete_components':dict(concrete_components=ConcreteComponents(area_shear=-1.,bearing_area=-1.)),
        'key_dimensions':dict(lug_bh=-1.,lug_bv=-1.,lug_t=-1.),
        'washer_dimensions':dict(anchor_washer_t=-1.,anchor_washer_side=-1.),
    }[component]
    c=replace(c,**changes)
    r=evaluate(c)
    assert r.geometry and not any(i.severity=='error' for i in r.issues)
    if component in ('upper_washer','washer_dimensions'):active=replace(c,shear_path='anchors')
    elif component=='key_dimensions':active=replace(c,shear_path='plate')
    elif component=='column_weld':active=replace(c,column_weld=replace(c.column_weld,model='two_flange_normal_web_shear'))
    else:active=replace(c,concrete_components=replace(c.concrete_components,model='aci318_19'))
    assert any(i.severity=='error' for i in evaluate(active).issues)


def test_key_only_tension_report_includes_actual_area_and_provided_source():
    from test_single_key_concrete_artifacts import fixture
    from lro.single_key_concrete_artifacts import append_report
    c=fixture(N=-30000.,V=1000.,concrete_components=ConcreteComponents(area_tension=200.,steel_area_ref='Thread area test source'))
    doc=Document();append_report(doc,c,evaluate(c))
    text='\n'.join(p.text for p in doc.paragraphs)+'\n'+'\n'.join(cell.text for t in doc.tables for row in t.rows for cell in row.cells)
    assert 'Área efetiva rosqueada Ase,N' in text and '200.000000 mm²' in text
    assert 'Thread area test source' in text and 'Não realizada; referência fornecida' in text
    assert c.concrete_components.model=='off'
