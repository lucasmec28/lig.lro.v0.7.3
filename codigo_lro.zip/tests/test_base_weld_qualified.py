"""Independent source and signed-field regression for the finite component."""
from dataclasses import replace
from decimal import Decimal, localcontext
import json
import math
from pathlib import Path

import pytest

from lro.models import Profile, Result, Check
from lro.base_plate import BasePlate, evaluate as evaluate_base
from lro.pinned_base_plate import PinnedBasePlate
from lro.column_base_weld import ColumnBaseWeld, MODEL_QUALIFIED, add_column_weld_checks
from lro.base_weld_qualified import qualification_signature, signed_flange_forces, web_design_length

FIX=json.loads((Path(__file__).parent/'fixtures/base_weld_practical_independent.json').read_text())
KIP=4448.2216152605
INCH=25.4


def config(kind_flange='fillet',kind_web='fillet',**changes):
    profile=Profile('I independent','Soldado',50,400.,220.,10.,16.,368.,10720.)
    u=ColumnBaseWeld(model=MODEL_QUALIFIED,column_steel='ASTM A572 Gr.50',
        process='smaw_e7018_mixed',web_length=300.,web_effective_length=280.,
        flange_length=220.,flange_effective_length=200.,procedure_ref='WPS test 1',
        cjp_detail='backing_removed',inspection_ref='ITP test 1',qualification_method='one_way',
        transfer_ref='Transfer record test 1',allocation_basis='Entire N/M via flange lines; V via web.',
        effective_length_basis='Centered effective segments from documented one-way plate transfer.',
        execution_ref='Continuous straight centered segments; intact section; access and interference checked.')
    c=BasePlate(profile,tp=40.,a1=60.,a2=260.,N=100000.,M=40000000.,V=20000.,
                weld_flange_type=kind_flange,weld_web_type=kind_web,
                weld_flange_size=8.,weld_web_size=6.,column_weld=u)
    return bind(replace(c,**changes))


def bind(c):
    return replace(c,column_weld=replace(c.column_weld,qualification_signature=qualification_signature(c)))


def evaluate(c):
    r=Result()
    def add(key,name,sd,rd,unit,ref,eq,sub,var):
        r.checks.append(Check('bp_'+key,name,sd,rd,unit,ref,eq,sub,var))
    out=add_column_weld_checks(c,r,add)
    return out,r


def test_dg1_source_force_and_nbr_fail_not_aisc_bonus():
    p=Profile('W18x76','W',76.,18.2*INCH,11*INCH,.425*INCH,.680*INCH,16*INCH,22.3*INCH**2)
    c=config(column=p,N=0.,M=1200*KIP*INCH,V=0.,tp=1.5*INCH,a1=2.45*INCH,a2=7.1*INCH,
             weld_flange_size=.25*INCH)
    c=bind(replace(c,column_weld=replace(c.column_weld,flange_length=11*INCH,
        flange_effective_length=11*INCH,web_length=10*INCH,web_effective_length=10*INCH)))
    out,r=evaluate(c); target=FIX['source_example']['NBR_same_geometry']
    assert out['F_right_N']==pytest.approx(float(target['F_flange_N']),rel=1e-13)
    assert out['flange']['resistance_N']==pytest.approx(float(target['R_fillet_N']),rel=1e-13)
    assert out['flange']['utilization']==pytest.approx(float(target['utilization']),rel=1e-13)
    assert out['status']=='fail' and out['flange']['utilization']>1
    assert out['complete'] is False


@pytest.mark.parametrize('kind,source',[('fillet','conditional_NMV'),('cjp','CJP_transfer_planes')])
def test_source_signed_extension_and_actual_planes(kind,source):
    p=Profile('W18x76','W',76.,18.2*INCH,11*INCH,.425*INCH,.680*INCH,16*INCH,22.3*INCH**2)
    c=config(kind_flange=kind,column=p,N=40*KIP,M=1200*KIP*INCH,V=25*KIP,
             tp=1.5*INCH,a1=2.45*INCH,a2=7.1*INCH,weld_flange_size=8.)
    c=bind(replace(c,column_weld=replace(c.column_weld,flange_length=11*INCH,
        flange_effective_length=11*INCH,web_length=10*INCH,web_effective_length=10*INCH)))
    out,_=evaluate(c); expected=FIX[source]
    assert out['F_left_N']/KIP==pytest.approx(float(expected['F_left']),rel=1e-13)
    assert out['F_right_N']/KIP==pytest.approx(float(expected['F_right']),rel=1e-13)
    assert out['h_mm']/INCH==pytest.approx(float(expected['h']),rel=1e-13)
    assert out['web']['q_per_face_N_per_mm']/(KIP/INCH)==pytest.approx(1.25)
    assert out['residual_N_N']==pytest.approx(0,abs=1e-8)
    assert out['residual_M_Nmm']==pytest.approx(0,abs=1e-7)
    assert out['residual_V_N']==pytest.approx(0,abs=1e-8)


@pytest.mark.parametrize('N',[-300000.,-100000.,0.,100000.,300000.])
@pytest.mark.parametrize('M',[-90e6,0.,90e6])
@pytest.mark.parametrize('V',[-75000.,0.,75000.])
def test_signed_equilibrium_all_regimes(N,M,V):
    c=config(N=N,M=M,V=V); out,_=evaluate(c)
    h=Decimal('400'); nd=Decimal(str(N)); md=Decimal(str(M))
    left=-nd/2-md/h;right=-nd/2+md/h
    assert out['F_left_N']==pytest.approx(float(left))
    assert out['F_right_N']==pytest.approx(float(right))
    f=out['flange'];w=out['web']
    n=(f['q_left_N_per_mm']+f['q_right_N_per_mm'])*f['effective_length_mm']
    m=(-h/2*Decimal(str(f['q_left_N_per_mm']))+h/2*Decimal(str(f['q_right_N_per_mm'])))*Decimal(str(f['effective_length_mm']))
    assert n==pytest.approx(-N)
    assert float(m)==pytest.approx(M,abs=1e-7)
    assert w['q_per_face_N_per_mm']*2*w['effective_length_mm']==pytest.approx(V)


def test_general_mixed_planes_have_no_symmetric_shortcut():
    out=signed_flange_forces(40,1200,-9.1,8.76)
    exp=FIX['mixed_transfer_planes']
    assert out['F_left_N']==pytest.approx(float(exp['F_left']))
    assert out['F_right_N']==pytest.approx(float(exp['F_right']))
    assert out['F_left_N']!=-40/2-1200/(9.1+8.76)


@pytest.mark.parametrize('fk,wk',[('fillet','fillet'),('fillet','cjp'),('cjp','fillet'),('cjp','cjp')])
def test_independent_joint_choices_and_one_cjp_section(fk,wk):
    out,r=evaluate(config(fk,wk))
    assert out['status']=='pass'
    assert out['h_mm']==400 if fk=='fillet' else out['h_mm']==384
    if wk=='cjp':
        assert out['web']['resistance_N']==pytest.approx(.6*280*10*250/1.1)
        assert out['web']['q_per_face_N_per_mm']==pytest.approx(20000/280)
    if fk=='cjp':
        assert out['flange']['resistance_N']==pytest.approx(200*16*250/1.1)
    assert out['connection_status']=='pending' and not out['complete']
    assert any(i.origin=='column_weld_scope' for i in r.issues)


def test_compression_not_deleted_and_reversal_swaps():
    a,_=evaluate(config(N=300000.,M=10e6)); b,_=evaluate(config(N=300000.,M=-10e6))
    assert a['F_left_N']<0 and a['F_right_N']<0
    assert a['F_left_N']==b['F_right_N']
    assert a['F_right_N']==b['F_left_N']
    assert a['flange']['utilization']>0


def test_unqualified_still_calculates_components_and_known_failure():
    c=config(); c=replace(c,column_weld=replace(c.column_weld,qualification_signature='',transfer_ref=''))
    out,r=evaluate(c)
    assert out['status']=='pending' and out['numerical_status']=='pass' and r.checks
    c=replace(c,N=1e7)
    out,r=evaluate(c)
    assert out['status']=='fail' and out['numerical_status']=='fail'
    assert out['qualification_status']=='missing'


@pytest.mark.parametrize('changes',[dict(N=100001.),dict(M=-40e6),dict(V=-20000.),dict(a2=280.),dict(tp=41.),
    dict(weld_flange_type='cjp'),dict(weld_web_size=7.),dict(plate_steel='ASTM A572 Gr.50')])
def test_changes_invalidate_evidence(changes):
    c=config(); changed=replace(c,**changes)
    out,r=evaluate(changed)
    assert out['qualification_status']=='stale'
    assert out['numerical_status'] in ('pass','fail')
    assert out['status']!='pass'


def test_project_notes_do_not_invalidate_and_lower_moment_not_used():
    c=config(); assert qualification_signature(replace(c,notes='Name only',project='Renamed'))==qualification_signature(c)
    keyed=replace(c,shear_path='plate',lug_bv=150.)
    a,_=evaluate(c);b,_=evaluate(keyed)
    assert keyed.effective_moment!=c.M
    assert a['F_left_N']==b['F_left_N'] and b['M_input_Nmm']==c.M


@pytest.mark.parametrize('field,value',[('flange_length',221.),('flange_effective_length',221.),
    ('web_length',369.),('web_effective_length',301.)])
def test_effective_length_must_exist(field,value):
    c=config();c=bind(replace(c,column_weld=replace(c.column_weld,**{field:value})))
    out,r=evaluate(c)
    assert out['status']=='fail' and not r.checks


@pytest.mark.parametrize('field,value',[('flange_length',True),('web_effective_length',float('nan')),
    ('bearing_area',float('inf')),('execution_ref',1),('qualification_signature',[])])
def test_malformed_nested_data_errors(field,value):
    c=config();c=replace(c,column_weld=replace(c.column_weld,**{field:value}))
    out,r=evaluate(c)
    assert out['status']=='pending' and not r.checks
    assert any(i.severity=='error' for i in r.issues)


def test_plate_width_does_not_create_nonexistent_flange_weld():
    c=config(a1=20.,a2=120.) # B=160 < physical Lf220
    out,r=evaluate(c)
    assert out['status']=='fail' and not r.checks


def test_leg_and_throat_equivalence():
    c=config(); a,_=evaluate(c)
    b,_=evaluate(bind(replace(c,weld_web_measure='throat',weld_web_size=6/math.sqrt(2),
                          weld_flange_measure='throat',weld_flange_size=8/math.sqrt(2))))
    for part in ('web','flange'):
        assert a[part]['resistance_N']==pytest.approx(b[part]['resistance_N'])


def test_short_effective_length_is_fail_not_increased_capacity():
    c=config();c=bind(replace(c,column_weld=replace(c.column_weld,flange_effective_length=30.)))
    out,r=evaluate(c)
    assert out['statuses']['flange_length_min']=='fail'
    assert out['flange']['design_length_mm']==30


@pytest.mark.parametrize('ratio,expected',[(100,1.),(150,.9),(300,.6),(301,180/301)])
def test_longitudinal_cap_boundary_keeps_transfer_geometry(ratio,expected):
    leg=6.; length=ratio*leg
    actual,beta=web_design_length(length,length,leg)
    assert actual/length==pytest.approx(expected)


def test_long_web_traction_integrates_on_transfer_length_not_resistance_length():
    c=config(column=replace(config().column,d=1400.,clear=1368.),V=-100000.)
    c=bind(replace(c,column_weld=replace(c.column_weld,web_length=1300.,web_effective_length=1250.)))
    out,_=evaluate(c);w=out['web']
    assert w['design_length_mm']<w['effective_length_mm']
    assert w['q_per_face_N_per_mm']*2*1250==pytest.approx(-100000)
    assert w['q_design_per_face_N_per_mm']>abs(w['q_per_face_N_per_mm'])
    assert w['area_column_mm2']==12500
    assert out['residual_V_N']==pytest.approx(0)


def test_prepared_bearing_native_capacity_and_equilibrium():
    c=config(N=300000.,M=0.)
    c=bind(replace(c,column_weld=replace(c.column_weld,normal_transfer='fit_bearing',
          bearing_area=5000.,bearing_ref='Machined contact record',bearing_basis='Verified contact area and surface preparation.')))
    out,r=evaluate(c)
    assert out['status']=='pass' and out['normal_transfer_applied']=='fit_bearing'
    assert out['F_left_N']==out['F_right_N']==0
    assert out['bearing_force_N']==-300000
    assert out['bearing_resistance_N']==pytest.approx(1.8*5000*250/1.35)
    assert out['residual_N_N']==0 and out['residual_M_Nmm']==0
    assert out['statuses']['flange_leg_min']=='pass'


@pytest.mark.parametrize('changes',[dict(M=1.),dict(N=-100000.)])
def test_bearing_never_relaxes_combined_or_tension(changes):
    c=config(**changes);c=bind(replace(c,column_weld=replace(c.column_weld,normal_transfer='fit_bearing',
        bearing_area=5000.,bearing_ref='Contact',bearing_basis='Prepared contact')))
    out,_=evaluate(c)
    assert out['normal_transfer_applied']=='welded' and out['bearing_force_N']==0
    assert out['F_left_N']+out['F_right_N']==pytest.approx(-c.N)


@pytest.mark.parametrize('area,qualify',[ (1.,True),(1e6,True),(5000.,False)])
def test_inadequate_nonphysical_or_unqualified_bearing_retains_compression(area,qualify):
    c=config(N=300000.,M=0.);c=replace(c,column_weld=replace(c.column_weld,normal_transfer='fit_bearing',
        bearing_area=area,bearing_ref='Contact',bearing_basis='Prepared contact'))
    if qualify:c=bind(c)
    out,_=evaluate(c)
    assert out['F_left_N']==out['F_right_N']==-150000
    assert out['bearing_force_N']==0 and out['normal_transfer_applied']=='welded'
    assert out['status']!='pass'


def test_cjp_missing_execution_still_conditional_numeric():
    c=config('cjp','fillet');c=bind(replace(c,column_weld=replace(c.column_weld,cjp_detail='unspecified',inspection_ref='')))
    out,r=evaluate(c)
    assert out['status']=='pending' and out['numerical_status']=='pass'
    assert 'flange' in out and r.checks


@pytest.mark.parametrize('family',[1,2])
def test_both_families_roundtrip_and_integrated_component(family):
    c=config(N=100000.,M=0.,V=10000.)
    if family==2:
        from lro.pinned_base_plate import presets
        p=presets()['Chumbadores · arruelas soldadas']
        c=replace(p,N=100000.,V=10000.,weld_web_type='fillet',weld_flange_type='cjp',
                  weld_web_size=4.,column_weld=replace(c.column_weld,web_length=220.,
                  web_effective_length=200.,flange_length=101.,flange_effective_length=100.))
        c=bind(c)
    cls=BasePlate if family==1 else PinnedBasePlate
    assert cls.from_dict(c.to_dict())==c
    out=evaluate_base(c).local_column_weld
    assert out.get('M_input_Nmm')==0
    assert out.get('numerical_status') in ('pass','fail')
    assert not out['complete']

@pytest.mark.parametrize('part',['web','flange'])
def test_huge_finite_weld_size_fails_cleanly(part):
    c=config(**{'weld_'+part+'_size':1e8})
    out,r=evaluate(c)
    assert out['status']=='fail'
    assert any('fora do domínio' in x.text for x in r.issues)


def test_tiny_thin_plate_controls_cjp_and_signed_failure():
    c=config('cjp','cjp',tp=4.,N=400000.,M=0.)
    out,r=evaluate(c)
    assert out['flange']['resistance_N']==pytest.approx(200*4*250/1.1)
    assert out['web']['resistance_N']==pytest.approx(.6*280*4*250/1.1)
    assert out['F_left_N']==out['F_right_N']==-200000
    assert out['status']=='fail'


def test_signature_numeric_int_float_and_signed_zero_equivalence():
    c=config(N=100000,M=0,V=20000)
    d=replace(c,N=100000.,M=-0.,V=20000.,column=replace(c.column,d=400,tf=16),
              column_weld=replace(c.column_weld,web_length=300,web_effective_length=280))
    assert qualification_signature(c)==qualification_signature(d)


@pytest.mark.parametrize('which',['web_length','flange_length','tw','tp'])
def test_tiny_positive_cjp_dimension_never_crashes(which):
    c=config('cjp','cjp')
    if which=='tp':c=replace(c,tp=1e-9)
    elif which=='tw':c=replace(c,column=replace(c.column,tw=1e-9))
    else:c=replace(c,column_weld=replace(c.column_weld,**{which:1e-9,which.replace('length','effective_length'):1e-9}))
    out,r=evaluate(c)
    assert out['status']=='fail'


def test_fakury_double_fillet_size_rule_is_not_a_scalar_nbr_capacity_exemption():
    # A different physical topology, retained solely as an independent guard
    # against replacing explicit NBR resistance with the book's size shortcut.
    with localcontext() as ctx:
        ctx.prec=40
        rd=Decimal(2)*Decimal(100)*Decimal('.6')*Decimal(485)*Decimal(5)/Decimal(2).sqrt()/Decimal('1.35')
        member=Decimal(7)*Decimal(100)*Decimal(350)/Decimal('1.10')
    assert float(rd)==pytest.approx(152420.79505576688)
    assert float(rd)<200000<float(member)
    from lro.column_base_weld import fillet_line_resistance
    assert 2*100*fillet_line_resistance(5)==pytest.approx(float(rd))


def test_signature_uses_physical_fillet_leg_not_leg_throat_representation():
    c=config()
    d=replace(c,weld_web_measure='throat',weld_web_size=6/math.sqrt(2),
              weld_flange_measure='throat',weld_flange_size=8/math.sqrt(2))
    assert qualification_signature(c)==qualification_signature(d)
    assert evaluate(d)[0]['qualification_status']=='qualified'
    assert qualification_signature(replace(d,weld_web_size=d.weld_web_size+.00001))!=qualification_signature(c)


def test_signature_ignores_inactive_cjp_fillet_sizes_and_inactive_drafts():
    c=config('cjp','cjp')
    d=replace(c,weld_web_size=111.,weld_flange_size=222.,weld_web_measure='throat',
              lug_bh=777.,lug_bv=888.,stiffener_height=999.,
              column_weld=replace(c.column_weld,bearing_area=333.,bearing_ref='inactive',bearing_basis='inactive'))
    assert qualification_signature(c)==qualification_signature(d)
    assert evaluate(d)[0]['qualification_status']=='qualified'
    assert qualification_signature(replace(d,weld_web_type='fillet'))!=qualification_signature(c)


def test_signature_ignores_inactive_cjp_records_but_keeps_active_contact_and_washers():
    c=config()
    d=replace(c,column_weld=replace(c.column_weld,inspection_ref='inactive',cjp_detail='backing_retained',
                                   cjp_charpy_confirmed=True,base_charpy_confirmed=True))
    assert qualification_signature(c)==qualification_signature(d)
    assert qualification_signature(replace(c,anchor_washer_side=c.anchor_washer_side+1))!=qualification_signature(c)
    bearing=bind(replace(c,column_weld=replace(c.column_weld,normal_transfer='fit_bearing')))
    assert qualification_signature(replace(bearing,column_weld=replace(bearing.column_weld,bearing_area=1)))!=qualification_signature(bearing)


def test_signature_keeps_active_key_dimensions_and_discards_inactive_key_draft():
    c=config()
    d=replace(c,active_key=replace(c.active_key,H=c.active_key.H+10))
    assert qualification_signature(c)==qualification_signature(d)
    keyed=replace(c,shear_path='plate')
    assert qualification_signature(keyed)!=qualification_signature(replace(keyed,lug_bv=keyed.lug_bv+1))
    for path in ('cross_active_plate','w_flange_plates'):
        keyed=replace(c,shear_path=path)
        assert qualification_signature(keyed)!=qualification_signature(replace(keyed,active_key=d.active_key))


@pytest.mark.parametrize('value,measure',[(1e308,'throat'),(-1.,'leg'),(0.,'leg'),(6.,'invalid')])
def test_canonical_signature_invalid_fillet_draft_still_fails_cleanly(value,measure):
    c=config(weld_web_size=value,weld_web_measure=measure)
    out,r=evaluate(c)
    assert out['status']=='fail'
