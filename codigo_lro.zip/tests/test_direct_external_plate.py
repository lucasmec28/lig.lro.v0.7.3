import math
from copy import deepcopy
import pytest
from lro.direct_external_plate import external_plate_components
from stiffened_base_app_candidate_20261017.direct_controller import direct_example,calculate


def case(**changes):
    p=direct_example();r=calculate(p);g=p['geometry'];m=p['materials']
    kw=dict(L=g['plate_length_mm'],B=g['plate_width_mm'],t=g['plate_thickness_mm'],d=g['column_depth_mm'],
        bf=g['column_flange_width_mm'],tw=g['column_web_thickness_mm'],a=g['column_depth_mm']/2+g['bolt_s_mm'],
        gauge=g['gauge_mm'],d0=p['direct_shear']['hole_diameter'],fy=m['plate_fy_MPa'],fu=m['plate_fu_MPa'],
        V=p['loads']['V_N'],states=r['direct_anchor_shear']['states'],washer_width=p['washer']['washer_width_mm'],source_half_width=g['column_web_thickness_mm']/2+p['connections']['column_base_leg_mm'])
    kw.update(changes);return external_plate_components(**kw)


def test_real_target_band_prefix_and_normal_cuts():
    r=case();assert r['checks'] and r['passes']
    # Method qualification is deliberately not yet claimed by this arithmetic test.
    assert not r['complete']
    st=r['states'][2];band=st['bands'][0];short=st['prefixes'][0]
    assert band['Agv_mm2']==pytest.approx(672.8*45)
    assert band['Anv_mm2']==pytest.approx((672.8-2*(28.4+2))*45)
    assert short['lv_mm']==pytest.approx(80.)
    assert short['Anv_mm2']==pytest.approx(45*(80-14.2))
    assert short['Ant_mm2']==pytest.approx(45*(39.8-14.2))
    expected=.5*400*45*(39.8-14.2)/1.25+250*45*(80-14.2)/math.sqrt(3)
    assert short['resistance']==pytest.approx(expected) and short['demand']==20000
    assert r['states'][1]['normal_cut']['demand_N']==0
    assert r['states'][2]['normal_cut']['demand_N']==40000
    assert st['normal_cut']['An_mm2']==pytest.approx((219.6-56.8)*45)
    assert st['double_block']['Anv_mm2']==pytest.approx(2*45*(80-14.2))
    assert st['double_block']['Ant_mm2']==pytest.approx(45*(140-28.4))


def test_reversal_does_not_reverse_normal_tensions():
    p=direct_example();p['loads']['V_N']=-40000.;n=calculate(p)['direct_anchor_shear']['states']
    a=case();b=case(V=-40000.,states=n)
    assert a['passes']==b['passes']
    assert a['states'][2]['normal_cut']['ids']!=b['states'][2]['normal_cut']['ids']
    assert b['states'][2]['normal_cut']['loaded_edge']=='x+'
    assert [c['resistance'] for c in a['checks']]==pytest.approx([c['resistance'] for c in b['checks']])


@pytest.mark.parametrize('changes',[dict(gauge=191.),dict(a=150.),dict(plate_monolithic=False),dict(t=True),dict(fy=500.)])
def test_nonmatching_or_invalid_domain_not_repaired(changes):
    r=case(**changes);assert not r['complete'] and not r['checks']


def test_inactive_holes_remain_and_source_width_is_real():
    r=case();long=r['states'][1]['prefixes'][1]
    assert len(long['ids'])==2 and 0. in long['forces_N'].values()
    assert long['Anv_mm2']==pytest.approx(45*(592.8-1.5*28.4))
    assert not case(source_half_width=70.)['checks']


def test_optional_application_envelope_published_tstub_oracle():
    r=case(flange_weld_leg=8.,rod_fu=400.,rod_As=390.8017890934302)
    e=r['application_envelope']
    assert r['complete'] and e['qualifies']
    assert e['mx_mm']==pytest.approx(100.)
    assert list(e['noncircular_leff_mm'].values())==pytest.approx([109.8,500.,289.8,320.])
    assert list(e['circular_leff_mm'].values())==pytest.approx([628.318530718,393.759265359])
    assert e['basal_plate_capacity_N']==pytest.approx(277931.25)
    assert e['reference_rod_pair_N']==pytest.approx(225101.8305178)
    assert e['scope_ratio']==pytest.approx(.809919109556)
    assert e['normative_requirement'] is False and e['inference_T_capacity_implies_V_capacity'] is False
    assert e['changes_actual_Ti'] is False and e['rib_normal_benefit_removed'] is False


def test_optional_envelope_exceeded_is_not_a_resistance_failure():
    r=case(t=20.,flange_weld_leg=8.,rod_fu=400.,rod_As=390.8017890934302)
    assert not r['complete'] and r['passes']
    assert r['status']=='outside_optional_app_scope'
    assert r['application_envelope']['scope_ratio']>1
    assert all(c['passes'] for c in r['checks'])


def test_longitudinal_projection_limited_without_silent_repair():
    p=direct_example();state=deepcopy(calculate(p)['direct_anchor_shear']['states'])
    for s in state:
        for r in s['rods']:r['x']=math.copysign(1000.,r['x'])
    r=case(a=1000.,L=2160.,states=state,flange_weld_leg=8.,rod_fu=400.,rod_As=390.8017890934302)
    assert not r['complete'] and r['application_envelope']['scope_ratio']>1
    assert r['physical_inputs']['a']==1000. and r['checks']


def test_scope_boundary_and_no_fictitious_cjp_fillet():
    params=dict(flange_weld_leg=8.,rod_fu=400.,rod_As=390.8017890934302)
    e=case(**params)['application_envelope'];threshold=45*math.sqrt(e['scope_ratio'])
    assert case(t=threshold,**params)['complete']
    assert not case(t=threshold-1e-5,**params)['complete']
    cjp=case(**dict(params,flange_weld_leg=0.))['application_envelope']
    assert cjp['mx_mm']==pytest.approx(106.4)
    assert cjp['basal_plate_capacity_N']<e['basal_plate_capacity_N']


def qualified_external(**kw):
    from dataclasses import replace
    from test_direct_plate_transfer import qualified_type2
    from test_direct_anchor_integration import fixture
    from lro.base_weld_qualified import qualification_signature
    from lro.concrete_components import bearing_signature
    q=qualified_type2();c=fixture(column=q.column,a2=120.,column_weld=q.column_weld,
        weld_web_type=q.weld_web_type,weld_flange_type=q.weld_flange_type,
        weld_web_size=q.weld_web_size,weld_flange_size=q.weld_flange_size)
    c=replace(c,**kw);c=replace(c,column_weld=replace(c.column_weld,qualification_signature=qualification_signature(c)))
    return replace(c,concrete_components=replace(c.concrete_components,bearing_confirmation=bearing_signature(c)))


def test_simple_external_closes_its_calculated_domain():
    from lro.base_plate import evaluate
    c=qualified_external();r=evaluate(c);d=r.geometry['direct_anchor_shear']
    assert d['local_transfer_scope']['complete'] and d['local_transfer_scope']['passes']
    assert d['direct_route_resistance_pass'] and d['calculation_coverage_complete']
    assert d['local_transfer_scope']['panel']['application_envelope']['qualifies']
    assert 'externa/P398' in r.calculation_note
    assert not d['foundation_scope']['complete']


def test_simple_external_axial_washer_not_silently_closed():
    from lro.base_plate import evaluate
    r=evaluate(qualified_external(N=-40000.,M=0.,V=10000.));d=r.geometry['direct_anchor_shear']
    assert d['local_transfer_scope']['complete']
    assert not d['direct_route_resistance_pass'] and not d['calculation_coverage_complete']
    assert not d['normal_and_axial_scope']['axial_washer_complete']
    assert 'AXIAL' in r.component_status


def test_simple_external_word_and_ui_use_actual_method():
    from lro.base_plate import evaluate
    from lro.base_plate_report import create_report
    from test_direct_anchor_presentation import all_text,app
    c=qualified_external();text=all_text(create_report(c,evaluate(c),True))
    assert 'ATENDE ao escopo resistente da rota direta' in text
    assert 'Envelope OPCIONAL' in text and 'd0+2 mm' in text
    assert 'Tipo2 interno: SCI P358' not in text
    at=app(c);assert not at.exception
    assert any('rota resistente atende' in x.value for x in at.markdown)
    assert any('P398 externo' in x.value for x in at.caption)


def test_actual_hole_and_washer_contours_block_false_external_approval():
    from lro.base_plate import evaluate
    c=qualified_external(a1=35.,a2=120.,M=0.,weld_flange_size=25.)
    r=evaluate(c);d=r.geometry['direct_anchor_shear']
    assert not d['direct_route_resistance_pass'] and not d['calculation_coverage_complete']
    assert any('Contorno real do furo' in x for x in d['local_transfer_scope']['reasons'])
    c=qualified_external(a1=45.,a2=120.,M=0.,weld_flange_size=20.)
    r=evaluate(c);d=r.geometry['direct_anchor_shear']
    assert 45.-20.-c.direct_shear.hole_diameter/2>0  # hole clears, washer does not
    assert not d['direct_route_resistance_pass']
    assert any('Arruela superior intercepta' in x for x in d['local_transfer_scope']['reasons'])


@pytest.mark.parametrize('family',['U','L','RHS','unknown'])
def test_no_non_i_h_profile_approval_by_signature(family):
    from dataclasses import replace
    from lro.base_plate import evaluate
    q=qualified_external();c=qualified_external(column=replace(q.column,family=family))
    r=evaluate(c);d=r.geometry['direct_anchor_shear']
    assert not d['direct_route_resistance_pass'] and not d['calculation_coverage_complete']
    assert not d['local_transfer_scope']['complete']


def test_all_three_states_and_their_distributions_required():
    p=direct_example();p['loads']['V_N']=1300000.;states=calculate(p)['direct_anchor_shear']['states']
    kw=dict(V=1300000.,flange_weld_leg=8.,rod_fu=400.,rod_As=390.8017890934302)
    assert not case(states=states[:1],**kw)['complete']
    repeated=deepcopy(states);repeated[2]['id']=repeated[1]['id']
    assert not case(states=repeated,**kw)['complete']
    forged=deepcopy(states)
    for r in forged[2]['rods']:r['shear']=1300000./4
    assert not case(states=forged,**kw)['complete']
    assert case(states=states,**kw)['complete'] and not case(states=states,**kw)['passes']


def test_washer_must_physically_cover_actual_hole():
    from lro.base_plate import evaluate
    for width in (10.,26.):
        r=evaluate(qualified_external(anchor_washer_side=width));d=r.geometry['direct_anchor_shear']
        assert not d['direct_route_resistance_pass'] and not d['calculation_coverage_complete']
        assert any('exceder o furo real' in x for x in d['local_transfer_scope']['reasons'])
