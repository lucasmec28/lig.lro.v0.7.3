"""Integração da família de base com os projetos existentes."""
from pathlib import Path
import copy,json
import pytest
from streamlit.testing.v1 import AppTest
ROOT=Path(__file__).resolve().parents[1]


def open_base():
    at=AppTest.from_file(str(ROOT/'app.py'),default_timeout=60).run()
    at.selectbox(key='connection_family').set_value('Placa de base · Tipo 1').run()
    assert not at.exception
    return at

def test_base_and_moment_drafts_survive_family_switch_and_word_invalidates():
    at=open_base()
    at.text_input(key='bp_project').set_value('Base preservada na integração').run()
    at.number_input(key='bp_M_kgfm').set_value(-600.).run()
    at.text_area(key='bp_notes').set_value('Nota da base com sinal de M negativo.').run()
    base=copy.deepcopy(at.session_state['_base_plate_project'])
    at.selectbox(key='connection_family').set_value('End plate · engastada').run()
    at.text_input(key='ep_project').set_value('End plate independente').run()
    at.number_input(key='ep_M_kgfm').set_value(4200.).run()
    moment=copy.deepcopy(at.session_state['ep_model'])
    at.selectbox(key='connection_family').set_value('Placa de base · Tipo 1').run()
    assert not at.exception and at.session_state['_base_plate_project']==base
    next(x for x in at.button if x.label=='Gerar memória da placa de base').click().run()
    assert not at.exception and at.session_state['bp_report'][2][:2]==b'PK'
    at.number_input(key='bp_N_kgf').set_value(14000.).run()
    assert not any(getattr(x,'label','')=='Baixar memória da placa de base .docx' for x in at.get('download_button'))
    at.selectbox(key='connection_family').set_value('End plate · engastada').run()
    assert not at.exception and at.session_state['ep_model']==moment


def test_base_json_import_and_hidden_external_shear_values_are_preserved():
    at=open_base()
    at.selectbox(key='bp_shear_mechanism').set_value('device').run()
    at.selectbox(key='bp_device_model').set_value('external').run()
    at.number_input(key='bp_external_shear_kgf').set_value(2000.).run()
    at.text_input(key='bp_external_shear_ref').set_value('Memória externa de teste').run()
    at.number_input(key='bp_V_kgf').set_value(1500.).run()
    saved=copy.deepcopy(at.session_state['_base_plate_project'])
    at.selectbox(key='bp_shear_mechanism').set_value('friction').run()
    at.selectbox(key='connection_family').set_value('Single plate').run()
    at.selectbox(key='connection_family').set_value('Placa de base · Tipo 1').run()
    at.selectbox(key='bp_shear_mechanism').set_value('device').run()
    at.selectbox(key='bp_device_model').set_value('external').run()
    assert not at.exception
    assert at.number_input(key='bp_external_shear_kgf').value==pytest.approx(2000.)
    assert at.text_input(key='bp_external_shear_ref').value=='Memória externa de teste'
    assert at.session_state['_base_plate_project']==saved
    at.get('file_uploader')[0].upload('base.json',json.dumps(saved).encode(),'application/json').run()
    next(x for x in at.button if x.label=='Abrir placa de base JSON').click().run()
    assert not at.exception and at.session_state['_base_plate_project']==saved
    bad=copy.deepcopy(saved);bad['connection']['fck']=55.
    at.get('file_uploader')[0].upload('base_invalida.json',json.dumps(bad).encode(),'application/json').run()
    next(x for x in at.button if x.label=='Abrir placa de base JSON').click().run()
    assert not at.exception and at.error
    assert at.session_state['_base_plate_project']==saved
