"""Physical geometry, signed audit, qualification and editable Word regressions."""
from copy import deepcopy
from dataclasses import replace
from io import BytesIO

from docx import Document
import pytest

from lro.base_plate import presets, evaluate
from lro.pinned_base_plate import presets as pinned_presets
from lro.base_plate_report import create_report
from lro.base_plate_detail_drawing import detail_image_bytes
from lro.column_base_weld import ColumnBaseWeld, MODEL as UPLIFT_MODEL
from lro.base_weld_qualified import MODEL, qualification_signature
from lro.column_base_weld_drawing import image_bytes
from lro.column_base_weld_report import append_qualified_weld_report


def qualified(family=1, flange='fillet', web='fillet', **changes):
    c=(presets() if family==1 else pinned_presets())['Chumbadores · arruelas soldadas']
    w=ColumnBaseWeld(model=MODEL,column_steel='ASTM A36',process='smaw_e7018_mixed',
        flange_length=min(95.,c.column.bf),flange_effective_length=80.,
        web_length=200.,web_effective_length=160.,procedure_ref='EPS QW-01',
        qualification_method='one_way',transfer_ref='TR-01: geometria e combinação atuais',
        allocation_basis='Transferência externa compatível: duas mesas para N/M e alma para todo V.',
        effective_length_basis='TR-01 justifica trechos retos e centrados: mesa 80 mm e alma 160 mm.',
        execution_ref='EX-01: seção íntegra, trechos centrados, acesso e ausência de interferências.',
        cjp_detail='backing_removed',inspection_ref='INS QW-01')
    values=dict(N=50000.,M=2e6 if family==1 else 0.,V=-10000.,weld_flange_type=flange,
                weld_web_type=web,weld_flange_size=6.,weld_web_size=6.,column_weld=w)
    values.update(changes)
    if family==2:values.pop('M',None)
    c=replace(c,**values)
    return bind(c)


def bind(c):
    return replace(c,column_weld=replace(c.column_weld,qualification_signature=qualification_signature(c)))


def figure(monkeypatch,c):
    import matplotlib.pyplot as plt
    figures=[];close=plt.close
    def remember(fig):
        if hasattr(fig,'axes'):figures.append(fig)
        close(fig)
    monkeypatch.setattr(plt,'close',remember)
    svg=image_bytes(c,evaluate(c),'svg').decode()
    return figures[-1],svg


def artists(fig):
    return {a.get_gid():a for ax in fig.axes for a in list(ax.lines)+list(ax.patches) if a.get_gid()}


@pytest.mark.parametrize('family',[1,2])
def test_both_families_have_same_explicit_component_and_own_rod_geometry(monkeypatch,family):
    c=qualified(family);r=evaluate(c);fig,svg=figure(monkeypatch,c)
    assert r.local_column_weld['status']=='pass'
    assert 'ATENDE CONDICIONAL' in svg and 'Base completa e rigidez: A COMPLEMENTAR' in svg
    found=artists(fig)
    for i,(x,y) in enumerate(((x,y) for x in (-c.a,c.a) for y in (-c.a2/2,c.a2/2)),1):
        assert found['cw_anchor_A'+str(i)].center==pytest.approx((y,x))
    assert 'Registro: TR-01' in svg and 'Assinatura: ATUAL' in svg


def test_fillet_lengths_are_physical_and_effective_centered_not_gauge_or_width(monkeypatch):
    c=qualified();fig,svg=figure(monkeypatch,c);a=artists(fig)
    for side,sign in [('left',-1),('right',1)]:
        assert list(a['cw_flange_'+side+'_physical'].get_xdata())==[-47.5,47.5]
        assert list(a['cw_flange_'+side+'_effective'].get_xdata())==[-40.,40.]
        assert list(a['cw_flange_'+side+'_physical'].get_ydata())==[sign*c.column.d/2]*2
    for name,sign in [('negative_y',-1),('positive_y',1)]:
        assert list(a['cw_web_'+name+'_physical'].get_xdata())==[sign*c.column.tw/2]*2
        assert list(a['cw_web_'+name+'_physical'].get_ydata())==[-100.,100.]
        assert list(a['cw_web_'+name+'_effective'].get_ydata())==[-80.,80.]
    assert 'cw_web_single_cjp' not in svg
    assert 'cw_web_negative_y_fillet_yz' in svg and 'cw_web_positive_y_fillet_yz' in svg
    assert 'cw_web_shear_negative_cross_' in svg


@pytest.mark.parametrize('flange,web',[('cjp','cjp'),('cjp','fillet'),('fillet','cjp')])
def test_independent_joints_preserve_one_cjp_section_and_correct_flange_planes(monkeypatch,flange,web):
    c=qualified(flange=flange,web=web);fig,svg=figure(monkeypatch,c);a=artists(fig)
    h=c.column.d-c.column.tf if flange=='cjp' else c.column.d
    assert list(a['cw_flange_left_effective'].get_ydata())==[-h/2]*2
    assert list(a['cw_flange_right_effective'].get_ydata())==[h/2]*2
    if flange=='cjp':
        assert 'cw_left_single_cjp_xz' in a and 'cw_right_single_cjp_xz' in a
        assert not any('exterior_fillet_xz' in name for name in a)
    if web=='cjp':
        assert list(a['cw_web_single_cjp_effective'].get_xdata())==[0.,0.]
        assert 'cw_web_single_cjp_yz' in a
        assert not any('web_negative_y' in name or 'web_positive_y' in name for name in a)


def test_report_independent_numeric_and_qualification_status_and_native_equations():
    c=qualified();r=evaluate(c)
    xml=Document(BytesIO(create_report(c,r,True)))._element.xml
    for phrase in ('Solda pilar–placa: duas mesas N/M e alma V','ATENDE ao componente condicional qualificado',
                   'Base completa / rigidez rotacional','L físico mm','L efetivo mm','L cálculo mm',
                   'Assinatura registrada:','Assinatura atual:','TR-01','EX-01','Resíduo normal ΣF+N',
                   'Resíduo de momento ΣxF−M','Resíduo de cortante ΣV−V','sem aumento direcional AISC',
                   'metal-base da placa junto à fusão'):
        assert phrase in xml
    assert '<m:oMath' in xml
    assert 'Solda pilar placa por faixas de tração pura' not in xml
    assert 'Detalhe íntegro / inspeção' not in xml  # Legacy checkbox is not this route's gate.


@pytest.mark.parametrize('mode',['missing','stale'])
def test_unqualified_keeps_numeric_failure_and_exports_evidence(mode):
    c=qualified(N=-300000.)
    w=replace(c.column_weld,transfer_ref='' if mode=='missing' else c.column_weld.transfer_ref,
              qualification_signature='' if mode=='missing' else 'prior-state')
    c=replace(c,column_weld=w);r=evaluate(c)
    assert r.local_column_weld['status']=='fail'
    xml=Document(BytesIO(create_report(c,r)))._element.xml
    assert 'NÃO ATENDE a uma ou mais verificações numéricas' in xml
    assert ('registro incompleto' if mode=='missing' else 'INVALIDADA após alteração de dados') in xml
    assert 'ATENDE ao componente condicional qualificado' not in xml
    assert 'NÃO ATENDE' in image_bytes(c,r,'svg').decode()


@pytest.mark.parametrize('producer',[image_bytes,detail_image_bytes,create_report])
def test_prior_numeric_result_cannot_be_exported_with_edited_inputs(producer):
    c=qualified();r=evaluate(c)
    edited=replace(c,V=-c.V)
    with pytest.raises(ValueError,match='desatualizado'):
        producer(edited,r)


def test_report_signed_actions_remain_top_face_while_lower_key_adds_moment():
    c=qualified(shear_path='plate');r=evaluate(c)
    assert r.geometry['M_effective']!=c.M
    assert r.local_column_weld['M_input_Nmm']==c.M
    doc=Document();append_qualified_weld_report(doc,c,r)
    text=' '.join(p.text for p in doc.paragraphs)+' '.join(cell.text for t in doc.tables for row in t.rows for cell in row.cells)
    assert '2,000000 kN·m' in text
    assert 'M não recebe o incremento V·e' in text
    assert 'Forças negativas permanecem' in text


def test_fit_bearing_reports_native_area_capacity_and_signed_force():
    c=qualified(M=0.)
    c=bind(replace(c,column_weld=replace(c.column_weld,normal_transfer='fit_bearing',bearing_area=1500.,
               bearing_ref='CB-01',bearing_basis='Superfície usinada plana, íntegra e em contato completo.')))
    r=evaluate(c);assert r.local_column_weld['normal_transfer_applied']=='fit_bearing'
    assert r.local_column_weld['bearing_force_N']==-c.N
    xml=Document(BytesIO(create_report(c,r)))._element.xml
    assert 'Área efetiva de contato preparada' in xml and 'Resistência nativa de contato' in xml
    assert 'CB-01' in xml and '1.500,000 mm²' in xml
    assert 'cw_bearing_force' in image_bytes(c,r,'svg').decode()


def test_physical_main_detail_overlays_component_paths():
    c=qualified();svg=detail_image_bytes(c,evaluate(c),'svg').decode()
    for gid in ('detail_cw_flange_left_effective','detail_cw_flange_right_effective',
                'detail_cw_web_negative_y_effective','detail_cw_web_positive_y_effective'):
        assert gid in svg
    assert 'componente condicional duas mesas N/M e alma V' in svg
    assert 'sem resistência geral N/M/V verificada' not in svg


def test_legacy_type2_uplift_report_is_preserved():
    c=pinned_presets()['Chumbadores · arruelas soldadas']
    w=ColumnBaseWeld(model=UPLIFT_MODEL,column_steel='ASTM A36',process='smaw_e7018_single_pass',
                    web_length=220.,procedure_ref='W1',detail_confirmed=True)
    c=replace(c,N=-50000.,V=0.,weld_web_type='fillet',weld_web_size=4.,column_weld=w)
    r=evaluate(c);assert r.local_column_weld['status']=='pass'
    xml=Document(BytesIO(create_report(c,r)))._element.xml
    assert 'Solda pilar placa por faixas de tração pura' in xml
    assert 'Componente condicional two_flange_normal_web_shear' not in xml


def test_missing_lengths_export_pending_without_invented_numeric_results():
    c=qualified();c=replace(c,column_weld=replace(c.column_weld,web_effective_length=0.))
    r=evaluate(c)
    assert r.local_column_weld['numerical_status']=='not_calculated'
    assert 'PENDENTE' in image_bytes(c,r,'svg').decode()
    xml=Document(BytesIO(create_report(c,r)))._element.xml
    assert 'PENDENTE: sem resultado numérico' in xml
    assert 'Não calculado' in xml


def test_qualified_equation_dispatch_does_not_fall_back_to_external_shear_device():
    c=qualified();r=evaluate(c)
    xml=Document(BytesIO(create_report(c,r,True)))._element.xml
    for row in r.checks:
        if row.id.startswith('bp_cwq_'):
            assert row.equation in xml


def test_longitudinal_resistance_design_traction_never_replaces_signed_physical_traction():
    c=qualified()
    c=replace(c,column=replace(c.column,d=2000.,bf=400.,tw=8.,tf=12.,clear=1976.),weld_web_size=5.,
              column_weld=replace(c.column_weld,web_length=1900.,web_effective_length=1700.))
    c=bind(c);r=evaluate(c);out=r.local_column_weld
    assert out['web']['design_length_mm']==900.
    assert out['web']['q_per_face_N_per_mm']==pytest.approx(-10000/(2*1700))
    assert out['web']['q_design_per_face_N_per_mm']==pytest.approx(10000/(2*900))
    doc=Document();append_qualified_weld_report(doc,c,r)
    text=' '.join(cell.text for t in doc.tables for row in t.rows for cell in row.cells)
    assert '-2,941176 N/mm' in text and '5,555556 N/mm' in text
    assert 'qV por caminho físico=V/(n Leff)' in text


def test_reversed_moment_and_shear_are_preserved_in_sheet_and_word():
    c=qualified();positive=bind(replace(c,V=10000.));negative=bind(replace(c,M=-c.M))
    a=evaluate(c).local_column_weld;b=evaluate(negative).local_column_weld
    assert a['F_left_N']==pytest.approx(b['F_right_N'])
    assert a['F_right_N']==pytest.approx(b['F_left_N'])
    assert 'cw_web_shear_positive_dot' in image_bytes(positive,evaluate(positive),'svg').decode()
    doc=Document();append_qualified_weld_report(doc,negative,evaluate(negative))
    text=' '.join(cell.text for t in doc.tables for row in t.rows for cell in row.cells)
    assert '-2,000000 kN·m' in text and '-10,000000 kN' in text


def test_report_describes_selected_cjp_topology_without_claiming_fillet_faces():
    c=qualified(flange='cjp',web='cjp');doc=Document()
    append_qualified_weld_report(doc,c,evaluate(c))
    text=' '.join(p.text for p in doc.paragraphs)
    assert 'Uma seção CJP por mesa' in text and 'uma seção CJP recebe V integral' in text
    assert 'Uma linha exterior de filete por mesa.' not in text


@pytest.mark.parametrize('size',[1e7,1e100,1e308])
@pytest.mark.parametrize('producer',[image_bytes,detail_image_bytes])
def test_unsupported_huge_fillet_sizes_never_allocate_extreme_plot_geometry(size,producer):
    c=qualified(weld_flange_size=size);r=evaluate(c)
    assert r.local_column_weld['status']=='fail'
    with pytest.raises(ValueError,match='desenho'):
        producer(c,r)


@pytest.mark.parametrize('effective',[1e-7,100.])
def test_tiny_or_noncontained_cjp_length_cannot_be_drawn_as_effective_section(effective):
    c=qualified(flange='cjp',web='cjp')
    c=bind(replace(c,column_weld=replace(c.column_weld,flange_effective_length=effective)))
    with pytest.raises(ValueError,match='desenho'):
        image_bytes(c,evaluate(c))


def test_rejected_main_detail_never_allocates_or_leaks_a_figure():
    import matplotlib.pyplot as plt
    c=qualified();c=bind(replace(c,weld_flange_size=1e100));r=evaluate(c)
    before=set(plt.get_fignums())
    for _ in range(3):
        with pytest.raises(ValueError):detail_image_bytes(c,r)
    assert set(plt.get_fignums())==before


def test_drawing_rejects_flange_segment_outside_actual_plate():
    c=qualified();c=bind(replace(c,a1=10.,a2=60.))
    with pytest.raises(ValueError):image_bytes(c,evaluate(c))
