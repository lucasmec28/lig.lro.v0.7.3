import copy
import json
import math
import pytest

from stiffened_base_app_candidate_20261017.positive_fixture import positive_fixture
from stiffened_base_kernels_candidate_20261017.full_composer import compose_complete_selected_domain
from stiffened_base_kernels_candidate_20261017.stiffened_direct_web_transfer import compose_direct_web_transfer
from stiffened_base_kernels_candidate_20261017.report_adapter import collect_check_states


def build(V=40000., sign=1, model='uniform', mutate=None):
    p=positive_fixture(sign)
    if mutate: mutate(p)
    nm=compose_complete_selected_domain(**p)
    out=compose_direct_web_transfer(nm_result=nm,V_N=V,geometry=p['geometry'],
        materials=p['materials'],connections=p['connections'],web_shear_flow_model=model)
    return p,nm,out


def test_reference_arithmetic_and_serialization():
    p,nm,out=build()
    assert out['domain'] and out['web_transfer_calculated']
    assert out['web_foot']['shear_flow_peak_per_face_actual_N_mm']==pytest.approx(40000/(2*276))
    g=p['geometry'];bf=g['column_flange_width_mm'];tf=g['column_flange_thickness_mm'];d=g['column_depth_mm'];tw=g['column_web_thickness_mm']
    expected_I=2*(bf*tf**3/12+bf*tf*((d-tf)/2)**2)+tw*(d-2*tf)**3/12
    expected_Q=bf*tf*(d-tf)/2
    assert out['internal_transfer']['I_column_rectangular_mm4']==pytest.approx(expected_I)
    assert out['internal_transfer']['global_longitudinal_flow_bound_N_mm']==pytest.approx(40000*expected_Q/expected_I)
    assert out['receiver']['panel']['samples'][0]['V_panel_N']==40000
    assert out['receiver']['panel']['samples'][-1]['V_panel_N']==40000
    assert not any(s['state']=='component_bound_not_satisfied' for s in collect_check_states(out))
    json.dumps(out,allow_nan=False)


def test_v_is_not_relieved_by_direct_compression_bearing():
    _,_,out=build()
    assert out['web_foot']['concurrent_normal_flow_peak_per_face_N_mm']==0
    assert out['web_foot']['recovered_shear_N']==40000
    assert out['web_foot']['shear_flow_peak_per_face_actual_N_mm']>0
    assert out['rib_lateral_credit_N']==0
    assert not out['plate_inplane_transfer_verified']
    assert not out['assembly_approval']


def test_global_flow_is_added_to_root_flow_without_cancellation():
    _,_,out=build()
    for i in out['internal_transfer']['interfaces']:
        assert i['combined_parallel_line_bound_N_mm']==pytest.approx(i['NM_parallel_line_bound_N_mm']+i['global_parallel_line_bound_N_mm'])
        assert i['global_parallel_line_bound_N_mm']>0


def test_zero_v_recovers_current_panel_and_internal_flow():
    _,nm,out=build(0.)
    assert out['receiver']['panel']==nm['receiver']['panel']
    assert out['internal_transfer']['global_longitudinal_flow_bound_N_mm']==0
    for i in out['internal_transfer']['interfaces']:
        assert i['combined_parallel_line_bound_N_mm']==i['NM_parallel_line_bound_N_mm']


def test_signed_v_preserved_and_strength_bounds_sign_invariant():
    _,_,a=build(40000);_,_,b=build(-40000)
    assert a['web_foot']['recovered_shear_N']==-b['web_foot']['recovered_shear_N']
    assert a['web_foot']['shear_flow_peak_per_face_actual_N_mm']==b['web_foot']['shear_flow_peak_per_face_actual_N_mm']
    assert a['internal_transfer']['global_longitudinal_flow_bound_N_mm']==b['internal_transfer']['global_longitudinal_flow_bound_N_mm']
    assert a['receiver']['panel']['samples'][0]['V_panel_N']==-b['receiver']['panel']['samples'][0]['V_panel_N']


def test_unpublished_plate_field_flow_is_rejected():
    with pytest.raises(ValueError,match='Unknown physical'):
        build(model='parabolic_zero_end')


def test_resistance_failure_does_not_hide_results():
    _,_,out=build(3e6)
    assert out['domain']
    assert out['web_transfer_calculated']
    assert any(s['state']=='component_bound_not_satisfied' for s in collect_check_states(out))
    assert out['web_foot']['recovered_shear_N']==3e6


def test_unchanged_old_guard_and_no_mutation():
    p,nm,_=build();before=copy.deepcopy(nm)
    compose_direct_web_transfer(nm_result=nm,V_N=80000,geometry=p['geometry'],materials=p['materials'],connections=p['connections'])
    assert nm==before
    p['loads']['V_N']=1.
    with pytest.raises(ValueError,match='V external = 0'):compose_complete_selected_domain(**p)


def test_stale_physical_inputs_are_rejected():
    p,nm,_=build();g=copy.deepcopy(p['geometry']);g['plate_thickness_mm']+=1
    with pytest.raises(ValueError,match='different actual geometry'):
        compose_direct_web_transfer(nm_result=nm,V_N=40000,geometry=g,materials=p['materials'],connections=p['connections'])


@pytest.mark.parametrize('value',[True,float('nan'),float('inf'),'40000'])
def test_invalid_v_is_rejected(value):
    with pytest.raises(ValueError):build(value)


def test_missing_internal_weld_continuity_blocks_component():
    _,_,out=build(mutate=lambda p:p['connections'].update(internal_continuous_two_faces=False))
    assert not out['domain']
    assert not out['web_transfer_calculated']
    assert 'Two real continuous internal fillets required' in out['reasons']


def test_unknown_flow_model_is_rejected():
    with pytest.raises(ValueError,match='Unknown physical'):build(model='arbitrary_redistribution')
