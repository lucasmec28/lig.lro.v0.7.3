"""New family only: independent frozen fixture and physical-parameter regression."""
from dataclasses import replace, fields
from pathlib import Path
import copy
import json
import math
import pytest
from lro.corner_gusset import CornerGusset, analyze, geometry, input_errors, receiving_union, COMPONENT_VERSION

ROOT=Path(__file__).resolve().parents[1]
ORACLE=json.loads((ROOT/'docs/qualification_corner0932/ORACLE.json').read_text())


def checks(result):return {r['id']:r for r in result['checks']}


def test_complete_frozen_fixture_all_86_rows_and_all_equilibria():
    r=analyze(CornerGusset());got=checks(r)
    assert r['status']=='PASS'
    assert len(ORACLE['checks'])==86
    for old in ORACLE['checks']:
        for key in ('demand','resistance','utilization'):
            assert got[old['id']][key]==pytest.approx(old[key],rel=1e-10,abs=1e-7),(old['id'],key)
    for residual in r['equilibrium_residuals'].values():assert max(map(abs,residual))<1e-7
    assert r['joint_distribution']['Ftop']<0<r['joint_distribution']['Fbottom']
    assert r['utilization']==pytest.approx(.5665793424032987)
    assert r['governing']['id']=='continuity_bottom_concurrent_column_receiver_bound'


def test_native_roundtrip_strict_and_json_compatible():
    c=CornerGusset();raw=c.to_dict()
    assert raw['component_version']==COMPONENT_VERSION
    assert CornerGusset.from_dict(json.loads(json.dumps(raw)))==c
    assert analyze(CornerGusset.from_dict(raw))['forces']==analyze(c)['forces']
    for key in ('schema_version','connection_type','component_version','units','fixed_assumptions','connection'):
        bad=copy.deepcopy(raw);bad.pop(key)
        with pytest.raises(ValueError):CornerGusset.from_dict(bad)
    for value in (True,'12',None,float('nan'),float('inf'),[] ,{}):
        bad=copy.deepcopy(raw);bad['connection']['plate_t']=value
        with pytest.raises(ValueError):CornerGusset.from_dict(bad)
    for value in (0,1,'true',None):
        bad=copy.deepcopy(raw);bad['connection']['symmetric']=value
        with pytest.raises(ValueError):CornerGusset.from_dict(bad)
    bad=copy.deepcopy(raw);bad['fixed_assumptions']['angle_count']=True
    with pytest.raises(ValueError):CornerGusset.from_dict(bad)
    bad=copy.deepcopy(raw);bad['connection']['unknown']=0
    with pytest.raises(ValueError):CornerGusset.from_dict(bad)


@pytest.mark.parametrize('key',['beam_profile','column_profile','angle_profile','beam_steel','column_steel'])
def test_wrong_nested_catalog_types_rejected_without_exception(key):
    c=replace(CornerGusset(),**{key:[]})
    assert input_errors(c)
    assert analyze(c)['status']=='INVALID'


@pytest.mark.parametrize('phi,expected',[(40.,13.615816164418774),(50.,13.131260324064993)])
def test_changed_angles_integrate_actual_retained_support_and_close(phi,expected):
    r=analyze(replace(CornerGusset(),phi_deg=phi))
    assert r['status']=='PASS'
    assert r['gusset_body']['governing']['VM']==pytest.approx(expected,rel=1e-10)
    assert r['gusset_paths']['rejected_supported']
    assert len(r['gusset_paths']['admissible'])>8
    assert all(not p['support_overlap'] for p in r['gusset_paths']['admissible'])
    for res in r['equilibrium_residuals'].values():assert max(map(abs,res))<1e-7


@pytest.mark.parametrize('phi',[30.,60.,80.])
def test_geometry_exclusion_is_actual_containment_not_angle_lock(phi):
    r=analyze(replace(CornerGusset(),phi_deg=phi))
    assert r['status']=='INVALID'
    assert any(q['id']=='brace_footprint_containment' for q in r['issues'])
    if phi==80:assert any(q['id']=='UNVERIFIED_COMPRESSION_COMPONENT' for q in r['issues'])


@pytest.mark.parametrize('phi',[40.,50.])
def test_moved_brace_true_small_body_compression_not_waived(phi):
    r=analyze(replace(CornerGusset(),phi_deg=phi,brace_weld_start=700.))
    assert r['status']=='UNVERIFIED'
    assert r['gusset_body']['minimum_normal']<0
    assert any(q['id']=='UNVERIFIED_COMPRESSION_COMPONENT' for q in r['issues'])


def test_nonzero_wp_moment_never_reuses_concentric_approval():
    r=analyze(replace(CornerGusset(),workpoint_offset=100.))
    assert r['status']!='PASS'
    assert r['forces']['brace_line_moment']==1e7
    assert any(q['id']=='UNVERIFIED_ECCENTRIC_DISTRIBUTION' for q in r['issues'])
    assert r['equilibrium_residuals']['gusset'][2]==pytest.approx(1e7)


def test_missing_load_is_not_zero_and_complete_lower_cut_can_be_compared():
    assert analyze(replace(CornerGusset(),beam_cut_Fy=None))['status']=='INVALID'
    r=analyze(replace(CornerGusset(),other_loads_excluded=False))
    assert r['status']=='UNVERIFIED' and any(q['id']=='missing_other_loads' for q in r['issues'])
    assert analyze(replace(CornerGusset(),compare_lower_cut=True))['status']=='PASS'
    assert analyze(replace(CornerGusset(),compare_lower_cut=True,lower_column_check_M=0.))['status']=='INVALID'


def test_cut_reference_transport_and_no_double_count():
    c=CornerGusset();r=analyze(c)
    moved=replace(c,upper_column_cut_x=100.,upper_column_cut_M=c.upper_column_cut_M-100*c.upper_column_cut_Fy,
                  beam_cut_y=75.,beam_cut_M=c.beam_cut_M+75*c.beam_cut_Fx)
    rr=analyze(moved)
    assert rr['status']=='PASS'
    assert rr['joint_beam_to_column']==pytest.approx(r['joint_beam_to_column'])
    assert rr['panel']==pytest.approx(r['panel'])
    for key in ('beam_local_NM_yield_screen','column_local_NM_yield_screen','continuity_bottom_concurrent_column_receiver_bound'):
        assert checks(rr)[key]['demand']==pytest.approx(checks(r)[key]['demand'])
    assert math.hypot(*r['forces']['double_count_residual_at_J'][:2])>30000


def test_column_steel_is_independent():
    a=checks(analyze(CornerGusset()));b=checks(analyze(replace(CornerGusset(),column_steel='ASTM A36')))
    for key in ('angle_each_gross','gusset_actual_body_chord_gross','joint_bottom_beam_flange_gross','continuity_bottom_plate_equilibrated_NVM'):
        assert a[key]['resistance']==b[key]['resistance']
    assert b['column_panel_zone']['resistance']/a['column_panel_zone']['resistance']==pytest.approx(250/345)


@pytest.mark.parametrize('field,changed,unchanged',[('fw_brace','brace_heel_weld_each_face','beam_root_weld'),('fw_root','beam_root_weld','joint_web_two_fillets'),('fw_joint','joint_web_two_fillets','continuity_bottom_web_weld'),('fw_continuity','continuity_bottom_web_weld','brace_heel_weld_each_face')])
def test_electrodes_independent(field,changed,unchanged):
    a=checks(analyze(CornerGusset()));b=checks(analyze(replace(CornerGusset(),**{field:400.})))
    assert b[changed]['resistance']/a[changed]['resistance']==pytest.approx(400/485)
    assert b[unchanged]['resistance']==a[unchanged]['resistance']


@pytest.mark.parametrize('width,clip,e,L,vm',[(130.,20.,75.,227.2,39.3735353868),(120.,30.,75.,207.2,49.1237086140)])
def test_continuity_general_geometry_is_rederived(width,clip,e,L,vm):
    r=analyze(replace(CornerGusset(),continuity_width=width,continuity_clip=clip));cp=r['geometry']['continuity']
    assert cp['e']==pytest.approx(e);assert cp['web_length']==pytest.approx(L)
    row=checks(r)['continuity_bottom_plate_equilibrated_NVM']
    assert row['demand']==pytest.approx(vm,rel=1e-10)
    assert r['continuity_per_plate_traction'][1]['M_poly']!=[7.5,28.75,0.,-21.25]


def test_root_clip_crossing_or_actual_flange_overhang_not_approved():
    assert analyze(replace(CornerGusset(),continuity_clip=145.))['status']=='INVALID'
    assert analyze(replace(CornerGusset(),continuity_width=160.))['status']=='INVALID'
    assert analyze(replace(CornerGusset(),continuity_clip=0.))['status']=='INVALID'


def test_overlapping_union_capacity_once_and_panel_axial_reduction():
    groups=receiving_union([(0,100,500000),(110,210,500000)],15.4,345,9.9)
    assert len(groups)==1
    assert groups[0]['resistance']==pytest.approx(980248.5)
    assert groups[0]['utilization']>1
    c=CornerGusset();r=analyze(replace(c,upper_column_cut_Fy=-.8*12360*345))
    assert r['panel']['factor']==pytest.approx(.6)
    assert r['panel']['VRd']==pytest.approx(573804.)
    assert r['panel']['Qmax']==pytest.approx(analyze(c)['panel']['Qmax'])


def test_receiving_end_branch_is_actual_geometry():
    r=analyze(replace(CornerGusset(),column_end_top=760.,upper_column_cut_y=760.))
    row=checks(r)['column_receiving_web_local_yield']
    assert row['spread_multiplier']==2.5
    assert row['resistance']==pytest.approx((550+2.5*15.4)*345*9.9)


def test_zero_brace_does_not_erase_concurrent_frame_actions():
    r=analyze(replace(CornerGusset(),P=0.))
    assert r['forces']['H']==0 and r['forces']['V']==0
    assert r['joint_beam_to_column']['M']!=0
    assert r['joint_beam_to_column']['Fy']==-50000


def test_explicit_extra_actions_equilibrate_and_native_nested_validation():
    load={'label':'beam point load','member':'beam','point':[900.,0.],'Fx':1234.,'Fy':-5000.,'M':500000.}
    c=replace(CornerGusset(),other_loads_excluded=False,other_loads=(load,))
    r=analyze(c)
    assert CornerGusset.from_dict(json.loads(json.dumps(c.to_dict())))==c
    for res in r['equilibrium_residuals'].values():assert max(map(abs,res))<1e-7
    raw=c.to_dict();raw['connection']['other_loads'][0]['Fx']=True
    with pytest.raises(ValueError):CornerGusset.from_dict(raw)
    raw=c.to_dict();raw['connection']['other_loads'][0]['unexpected']=0
    with pytest.raises(ValueError):CornerGusset.from_dict(raw)


def test_numeric_extremes_and_zero_panel_resistance_are_strict_json_safe():
    r=analyze(replace(CornerGusset(),P=1e200))
    assert r['status']=='INVALID'
    assert any(i['id']=='numeric_domain' for i in r['issues'])
    json.dumps(r,allow_nan=False)
    r=analyze(replace(CornerGusset(),upper_column_cut_Fy=-1.4*12360*345))
    assert r['status']=='FAIL'
    assert checks(r)['column_panel_zone']['resistance']==0
    assert checks(r)['column_panel_zone']['utilization'] is None
    assert r['utilization_unbounded']
    json.dumps(r,allow_nan=False)


@pytest.mark.parametrize('member,point',[('beam',[1500.,0.]),('column',[0.,-1500.])])
def test_other_actions_must_be_inside_complete_cuts(member,point):
    action={'label':'outside','member':member,'point':point,'Fx':5000.,'Fy':-30000.,'M':400000.}
    r=analyze(replace(CornerGusset(),other_loads_excluded=False,other_loads=(action,)))
    assert r['status']=='INVALID'
    assert any(i['id']=='other_load_outside_cuts' for i in r['issues'])


def test_component_summaries_keep_physical_paths_separate():
    r=analyze(CornerGusset());summary={v['component']:v for v in r['component_summary']}
    assert {'angles','brace_welds','beam_root','column_root','column_receiver','continuity_receiver','beam_joint','continuity_plates','continuity_welds'}<=set(summary)
    assert summary['local_member_material']['status']=='DIAGNOSTIC_ONLY'
    assert summary['local_member_material']['diagnostic_only']


@pytest.mark.parametrize('fw',[415.,450.])
def test_CJP_consumable_must_match_actual_steel_group_not_just_fu(fw):
    r=analyze(replace(CornerGusset(),fw_joint=fw))
    assert r['status']=='FAIL'
    assert checks(r)['joint_CJP_electrode_compatibility']['status']=='FAIL'
    assert checks(r)['joint_CJP_electrode_compatibility']['demand']==485.


def test_built_up_catalog_members_are_explicitly_unverified():
    r=analyze(replace(CornerGusset(),column_profile='CS 600 x 281'))
    assert r['status']!='PASS'
    assert any(i['id']=='column_member_family' and i['severity']=='unverified' for i in r['issues'])


def test_a913_electrode_group_not_inferred_from_fy_alone():
    r=analyze(replace(CornerGusset(),beam_steel='ASTM A913 Gr.50'))
    assert checks(r)['joint_CJP_electrode_compatibility']['demand']==550.
    assert r['status']=='FAIL'


def test_failed_strength_with_unverified_method_is_not_complete():
    r=analyze(replace(CornerGusset(),workpoint_offset=100.,continuity_web_weld_leg=1.))
    assert r['status']!='PASS' and not r['complete']
    assert any(i['severity']=='unverified' for i in r['issues'])


def test_coincident_brace_faces_cap_shared_thin_gusset_depth_once():
    c=replace(CornerGusset(),plate_t=6.,root_weld_leg=4.)
    r=analyze(c);row=checks(r)['brace_heel_gusset_face_substrate_each_face']
    expected=min(.6*250*(220*3)/1.1,.6*400*(220*3)/1.35)
    assert row['resistance']==pytest.approx(expected)


def test_long_weld_is_unverified_method_branch_not_forbidden_detail():
    r=analyze(replace(CornerGusset(),plate_width=700.))
    row=checks(r)['beam_root_long_weld_limit']
    assert row['status']=='UNVERIFIED' and row['method_domain']
    assert any(i['id']=='beam_root_long_weld_branch' for i in r['issues'])
    assert not r['complete'] and r['status']!='PASS'


def test_CJP_base_resistance_uses_lower_joined_fy_and_thickness():
    r=analyze(replace(CornerGusset(),column_steel='ASTM A36'))
    for level in ('top','bottom'):
        row=checks(r)['joint_'+level+'_CJP_and_beam_flange']
        assert row['resistance']==pytest.approx(167*13.2*250/1.1)
        assert row['effective_fy']==250.
        assert row['effective_thickness']==13.2
    assert checks(r)['joint_bottom_beam_flange_gross']['resistance']==pytest.approx(167*13.2*345/1.1)


def test_receiving_yield_exact_member_depth_is_end_branch_at_all_three_paths():
    c=CornerGusset()
    r=analyze(replace(c,column_end_top=781.5,upper_column_cut_y=780.))
    row=checks(r)['column_receiving_web_local_yield']
    assert row['end_distance']==308.
    assert row['spread_multiplier']==2.5
    assert row['resistance']==pytest.approx((550+2.5*15.4)*345*9.9)
    r=analyze(replace(c,column_end_bottom=-459.9,lower_column_cut_y=-450.))
    assert checks(r)['column_bottom_web_local_yield']['resistance']==pytest.approx((13.2+2.5*15.4)*345*9.9)
    r=analyze(replace(c,plate_height=580.,column_end_top=744.9,upper_column_cut_y=740.))
    group=next(g for g in r['receiver_unions'] if len(g['forces'])>1)
    assert group['spread_multiplier']==2.5
    assert group['resistance']==pytest.approx((group['span']+2.5*15.4)*345*9.9)


def test_supported_contact_cannot_extend_beyond_physical_member_end():
    r=analyze(replace(CornerGusset(),column_end_top=750.,upper_column_cut_y=750.))
    assert r['status']=='INVALID'
    assert any(i['id']=='physical_supported_contact_end' for i in r['issues'])


@pytest.mark.parametrize('edits',[{'beam_cut_x':750.},{'upper_column_cut_y':750.},{'lower_column_cut_y':-152.}])
def test_complete_cuts_enclose_full_physical_contacts_not_only_weld_centroids(edits):
    r=analyze(replace(CornerGusset(),**edits))
    assert r['status']=='INVALID'
    assert any(i['id']=='complete_cut_positions' for i in r['issues'])
