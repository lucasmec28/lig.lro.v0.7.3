"""Independent Decimal benchmarks and domain/qualification regression gates."""
from dataclasses import replace
import json
import math
from pathlib import Path
from types import SimpleNamespace

import pytest

from lro.models import Profile, Result, Check
from lro.column_base_weld import (
    ColumnBaseWeld, MODEL, LIMITS, add_column_weld_checks,
    validate_column_weld, column_weld_assumptions, fillet_line_resistance,
    cjp_resistance, type2_uplift_values,
)

FIX = {f['id']: f for f in json.loads(
    (Path(__file__).parent / 'fixtures/column_weld_independent.json').read_text())['fixtures']}


def config(**changes):
    c = SimpleNamespace(
        model_type=2, N=-300000., M=0., V=0., effective_moment=0.,
        column=Profile('I teste', 'Soldado', 50., 300., 180., 8., 12., 276., 6528.),
        a2=120., B=220., tp=35., plate_steel='ASTM A36', stiffener_detail='none',
        weld_web_type='fillet', weld_web_measure='leg', weld_web_size=6.,
        column_weld=ColumnBaseWeld(
            model=MODEL, column_steel='ASTM A572 Gr.50',
            process='smaw_e7018_single_pass', web_length=250.,
            procedure_ref='EPS de ensaio', detail_confirmed=True),
    )
    for name, value in changes.items():
        setattr(c, name, value)
    return c


def evaluate(c):
    r = Result()
    def add(i, name, sd, rd, unit, ref, eq, sub, var):
        r.checks.append(Check('bp_' + i, name, sd, rd, unit, ref, eq, sub, var))
    d = add_column_weld_checks(c, r, add)
    return d, r


@pytest.mark.parametrize('name', ['cjp_flange_normal', 'cjp_web_shear_failure', 'cjp_thinner_plate_controls'])
def test_independent_cjp_benchmarks(name):
    row = FIX[name]
    i = row['inputs']
    actual = cjp_resistance(i['L_mm'], i['t_column_mm'], i['t_plate_mm'],
                            i['fy_column_MPa'], i['fy_plate_MPa'])
    for key in ('A_MB_mm2', 'R_normal_N', 'R_shear_N'):
        if key in row['expected']:
            assert actual[key] == pytest.approx(row['expected'][key], rel=2e-14)
    if 'V_N' in i:
        assert i['V_N'] / actual['R_shear_N'] == pytest.approx(row['expected']['utilization'])
    else:
        assert i['F_normal_N'] / actual['R_normal_N'] == pytest.approx(row['expected']['utilization'])


def test_independent_pure_uplift_strip_benchmark():
    expected = FIX['type2_uplift_45deg_fillets']['expected']
    d, r = evaluate(config())
    for key in expected:
        if key == 'intervals_mm':
            assert d[key] == expected[key]
        else:
            assert d[key] == pytest.approx(expected[key], rel=3e-14), key
    assert d['status'] == 'pass'
    assert d['complete'] is False
    assert d['connection_status'] == 'pending'
    assert any(i.severity == 'pending' and i.text == LIMITS for i in r.issues)
    assert all(x.passed for x in r.checks)


def test_independent_combined_kernel_is_not_native_demand_generator():
    expected = FIX['type2_uplift_plus_shear_fillet_kernel']['expected']
    qz, qx = 75000 / 112, 100000 / (2 * 250)
    assert math.hypot(qz, qx) == pytest.approx(expected['q_resultant_N_per_mm'])
    assert math.hypot(qz, qx) / fillet_line_resistance(6) == pytest.approx(expected['weld_utilization'])
    d, r = evaluate(config(V=100000.))
    assert d['status'] == 'pending' and not r.checks


def test_independent_dg1_moment_demand_nbr_strength_convention():
    e = FIX['dg1_pure_moment_recomputed_with_nbr']['expected']
    kip, inch = 4448.2216152605, 25.4
    force = (1200 * kip * inch) / (18.2 * inch)
    resistance = fillet_line_resistance(.25 * inch, 70 * kip / inch**2) * 11 * inch
    assert force == pytest.approx(e['flange_force_N'], rel=2e-14)
    assert resistance == pytest.approx(e['R_fillet_N_NBR'], rel=2e-14)
    assert force / resistance == pytest.approx(e['utilization_NBR'])
    assert force / resistance > 1  # No borrowed AISC directional 1.5 factor.


def test_independent_prepared_bearing_shear_kernel():
    e = FIX['prepared_bearing_double_web_shear']['expected']
    resistance = 2 * 250 * fillet_line_resistance(5)
    assert resistance == pytest.approx(e['V_Rd_N'], rel=2e-14)
    assert 100000 / resistance == pytest.approx(e['utilization'])


def test_exact_signed_force_and_moment_integrals():
    d, _ = evaluate(config())
    q = d['q_normal_one_face_N_per_mm']
    force = 2 * sum(q * (end - start) for start, end in d['intervals_mm'])
    moment = 2 * sum(q * (end**2 - start**2) / 2 for start, end in d['intervals_mm'])
    assert force == pytest.approx(300000)
    assert moment == pytest.approx(0, abs=1e-9)
    assert d['normal_resultant_N'] == pytest.approx(force)
    assert d['span_mm'] == 232


@pytest.mark.parametrize('changes', [dict(model_type=1), dict(N=0), dict(N=400000),
    dict(M=1), dict(M=-1), dict(V=1), dict(V=-1), dict(stiffener_detail='web_pair')])
def test_unsupported_force_or_family_is_pending(changes):
    d, r = evaluate(config(**changes))
    assert d['status'] == 'pending'
    assert not r.checks
    assert not d['complete']


def test_never_imports_foundation_effective_moment_into_column_weld():
    # Deliberately inconsistent lower-path diagnostic value cannot alter the
    # top-action checks; parent owns validation of its foundation equilibrium.
    a, _ = evaluate(config(effective_moment=0))
    b, _ = evaluate(config(effective_moment=8e8))
    assert a == b


@pytest.mark.parametrize('field,value', [('column_steel', 'unspecified'), ('process', 'unspecified'),
    ('web_length', 0), ('procedure_ref', '  '), ('detail_confirmed', False), ('model', 'unknown')])
def test_missing_qualification_is_pending(field, value):
    c = config()
    c.column_weld = replace(c.column_weld, **{field: value})
    d, r = evaluate(c)
    assert d['status'] == 'pending' and not r.checks


@pytest.mark.parametrize('field,value', [('web_length', True), ('web_length', float('nan')),
    ('web_length', float('inf')), ('web_length', 10**400), ('web_length', -1),
    ('detail_confirmed', 'yes'), ('cjp_charpy_confirmed', 1), ('base_charpy_confirmed', None),
    ('model', {}), ('column_steel', []), ('procedure_ref', 4)])
def test_malformed_nested_data_never_reaches_arithmetic(field, value):
    c = config()
    c.column_weld = replace(c.column_weld, **{field: value})
    assert any(i.severity == 'error' for i in validate_column_weld(c))
    d, r = evaluate(c)
    assert d['status'] == 'pending' and not r.checks


@pytest.mark.parametrize('length', [231.99, 277])
def test_full_strip_containment_and_real_clear_length(length):
    c = config()
    c.column_weld = replace(c.column_weld, web_length=length)
    d, r = evaluate(c)
    assert d['status'] == 'fail' and not r.checks
    assert any(i.severity == 'noncompliance' for i in r.issues)


def test_exact_containment_boundary_and_no_strip_clipping():
    c = config()
    c.column_weld = replace(c.column_weld, web_length=232)
    d, _ = evaluate(c)
    assert d['status'] == 'pass'
    assert d['intervals_mm'] == [[-116, -4], [4, 116]]


@pytest.mark.parametrize('thickness,minimum', [(6.3, 3), (6.300001, 5),
    (12.5, 5), (12.500001, 6), (19, 6), (19.000001, 8)])
def test_table11_minimum_leg_thresholds(thickness, minimum):
    c = config(weld_web_size=minimum - .01)
    c.column = replace(c.column, tw=thickness)
    d, r = evaluate(c)
    check = next(x for x in r.checks if x.id == 'bp_cw_leg_min')
    assert check.demand == minimum and not check.passed
    assert d['status'] == 'fail'


def test_leg_and_throat_inputs_are_equivalent():
    a, _ = evaluate(config())
    b, _ = evaluate(config(weld_web_measure='throat', weld_web_size=6 / math.sqrt(2)))
    assert a['q_weld_Rd_N_per_mm'] == pytest.approx(b['q_weld_Rd_N_per_mm'])
    assert a['weld_utilization'] == pytest.approx(b['weld_utilization'])


def test_no_invented_t_joint_free_edge_leg_cap():
    d, r = evaluate(config(weld_web_size=8))
    assert d['status'] == 'pass'
    assert not any(x.id == 'bp_cw_leg_max' for x in r.checks)


def test_pure_transverse_uplift_has_no_automatic_longitudinal_reduction():
    c = config()
    c.column = replace(c.column, d=1400, clear=1376)
    c.column_weld = replace(c.column_weld, web_length=1300)
    d, _ = evaluate(c)
    assert d['status'] == 'pass'
    assert d['q_weld_Rd_N_per_mm'] == pytest.approx(fillet_line_resistance(6))


def cjp_config(**changes):
    c = config(weld_web_type='cjp')
    options = dict(process='smaw_e7018', cjp_detail='backing_removed',
                   inspection_ref='Plano de inspeção de ensaio')
    options.update(changes)
    c.column_weld = replace(c.column_weld, **options)
    return c


def test_cjp_is_one_section_with_smaller_fy_not_double_face_capacity():
    d, r = evaluate(cjp_config())
    cj = next(x for x in r.checks if x.id == 'bp_cw_web_cjp')
    assert cj.demand == pytest.approx(2 * 75000 / 112)
    assert cj.resistance == pytest.approx(8 * 250 / 1.1)
    assert d['cjp_A_MB_per_length_mm'] == 8
    assert d['complete'] is False and d['connection_status'] == 'pending'
    assert any(i.origin == 'column_weld_scope' for i in r.issues)


def test_cjp_retained_backing_charpy_gate():
    d, r = evaluate(cjp_config(cjp_detail='backing_retained'))
    assert d['status'] == 'pending' and not r.checks
    assert any('27 J' in i.text for i in r.issues)
    d, _ = evaluate(cjp_config(cjp_detail='backing_retained', cjp_charpy_confirmed=True))
    assert d['status'] == 'pass'


@pytest.mark.parametrize('field,value', [('cjp_detail', 'unspecified'), ('inspection_ref', ' ')])
def test_cjp_label_alone_never_certifies_interface(field, value):
    c = cjp_config()
    c.column_weld = replace(c.column_weld, **{field: value})
    d, r = evaluate(c)
    assert d['status'] == 'pending' and not r.checks


def test_cjp_thick_tensile_section_material_charpy_gate():
    c = cjp_config()
    c.column = replace(c.column, tf=51., clear=198.)
    c.a2 = 90.
    c.column_weld = replace(c.column_weld, web_length=180.)
    d, r = evaluate(c)
    assert d['status'] == 'pending' and not r.checks
    assert any('tenacidade do metal-base' in i.text for i in r.issues)
    c.column_weld = replace(c.column_weld, base_charpy_confirmed=True)
    d,r=evaluate(c)
    assert d['status']=='pending' and not r.checks
    assert any('metal de solda' in i.text for i in r.issues)
    c.column_weld=replace(c.column_weld,cjp_charpy_confirmed=True)
    d, _ = evaluate(c)
    assert d['statuses'].get('demand_field') == 'established'


def test_native_plate_pass_does_not_waive_narrower_strip_thickness():
    d, r = evaluate(config(tp=20.))
    assert d['statuses']['strip_bending'] == 'fail'
    assert d['status'] == 'fail'
    assert d['b_eff_mm'] == 112
    assert d['t_plate_plastic_req_mm'] == pytest.approx(25.69046515733026)


def test_material_compatibility_and_product_domains():
    c = config()
    c.column_weld = replace(c.column_weld, column_steel='ASTM A992')
    d, r = evaluate(c)  # A992 cannot be assumed to be welded plate stock.
    assert d['status'] == 'fail' and not r.checks
    c.column = replace(c.column, family='W')
    assert evaluate(c)[0]['status'] == 'pass'
    c.column_weld = replace(c.column_weld, column_steel='USI-CIVIL 350')
    assert evaluate(c)[0]['status'] == 'pending'


def test_nested_roundtrip_and_disabled_model():
    u = config().column_weld
    assert ColumnBaseWeld.from_dict(vars(u)) == u
    with pytest.raises(ValueError):
        ColumnBaseWeld.from_dict({'unexpected': True})
    with pytest.raises(ValueError):
        ColumnBaseWeld.from_dict([])
    c = config(column_weld=ColumnBaseWeld())
    assert evaluate(c)[0] == {}
    assert column_weld_assumptions(c) == []
    assert LIMITS in column_weld_assumptions(config())


@pytest.mark.parametrize('bad', [True, float('nan'), float('inf'), 10**400, 0, -1])
def test_standalone_resistance_kernel_rejects_bad_scales(bad):
    with pytest.raises(ValueError):
        fillet_line_resistance(bad)
    with pytest.raises(ValueError):
        cjp_resistance(bad, 8, 35, 345, 250)


def test_failed_weld_and_web_components_do_not_get_lost_in_scope_pending():
    d, r = evaluate(config(N=-1000000.))
    assert d['status'] == 'fail'
    assert d['statuses']['web_weld'] == 'fail'
    assert d['statuses']['web_yield'] == 'fail'
    assert any(not x.passed for x in r.checks)
    assert d['connection_status'] == 'pending'


def test_heavy_cjp_backing_removed_requires_both_charpy_qualifications():
    c=cjp_config(base_charpy_confirmed=True)
    c.column=replace(c.column,tf=51.,tw=8.,clear=198.)
    c.a2=90.;c.N=-100000.
    c.column_weld=replace(c.column_weld,web_length=180.)
    out,result=evaluate(c)
    assert out['status']=='pending' and not result.checks
    assert any('6.2.4.2(b)' in i.text for i in result.issues)
    c.column_weld=replace(c.column_weld,cjp_charpy_confirmed=True)
    assert evaluate(c)[0]['status']=='pass'
