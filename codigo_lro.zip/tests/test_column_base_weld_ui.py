"""Streamlit qualification, hidden-state and source-datum regression tests."""
from dataclasses import replace
import json
from pathlib import Path

import pytest
from streamlit.testing.v1 import AppTest

from lro.base_plate import BasePlate
from lro.pinned_base_plate import PinnedBasePlate
from lro.models import Profile
from lro.column_base_weld import ColumnBaseWeld, MODEL, MODEL_QUALIFIED
from lro.base_weld_qualified import qualification_signature

APP = Path(__file__).resolve().parents[1] / 'app.py'
FAMILIES = {'bp': 'Placa de base · engastada', 'pp': 'Placa de base · rotulada'}
PROJECT_KEYS = {'bp': '_base_plate_project', 'pp': '_pinned_base_plate_project'}


def config(prefix='bp', **weld_changes):
    u = ColumnBaseWeld(model=MODEL_QUALIFIED, column_steel='ASTM A36',
                       process='smaw_e7018_single_pass', procedure_ref='EPS-01, revisão 2',
                       flange_length=180., flange_effective_length=150.,
                       web_length=250., web_effective_length=220.,
                       qualification_method='one_way', transfer_ref='MC-01, combinação C1',
                       allocation_basis='N/M integralmente nas mesas; V na alma; modelo de faixas verifica transferência à placa e ancoragem.',
                       effective_length_basis='Comprimentos de 150 mm e 220 mm sustentados pela memória MC-01 para a configuração atual.',
                       execution_ref='Detalhe EX-01: trechos retos contínuos centrados; acesso e material íntegro, sem interferências.')
    u = replace(u, **weld_changes)
    p = Profile('I teste de interface', 'Soldado', 6528. * .00785, 300., 180., 8., 12., 276., 6528.)
    cls = BasePlate if prefix == 'bp' else PinnedBasePlate
    values = dict(N=40000., V=20000., tp=35., a1=50., a2=120.,
                  weld_web_type='fillet', weld_flange_type='fillet', column_weld=u)
    if prefix == 'bp':
        values['M'] = 1e6
    return cls(p, **values)


def current(at, prefix='bp'):
    cls = BasePlate if prefix == 'bp' else PinnedBasePlate
    return cls.from_dict(at.session_state[PROJECT_KEYS[prefix]])


def open_app(prefix='bp', c=None):
    at = AppTest.from_file(str(APP), default_timeout=60).run()
    at.selectbox(key='connection_family').set_value(FAMILIES[prefix]).run()
    if c is not None:
        at.get('file_uploader')[0].upload('weld.json', json.dumps(c.to_dict()).encode(), 'application/json').run()
        next(x for x in at.button if x.label == 'Abrir placa de base JSON').click().run()
    assert not at.exception
    return at


def bind(at, prefix='bp'):
    at.button(key=prefix + '_cw_bind_qualification').click().run()
    assert not at.exception
    c = current(at, prefix)
    assert c.column_weld.qualification_signature == qualification_signature(c)
    return c


@pytest.mark.parametrize('prefix', ['bp', 'pp'])
def test_model_available_to_both_base_families_without_prequalification(prefix):
    at = open_app(prefix)
    at.selectbox(key=prefix + '_cw_model').set_value(MODEL_QUALIFIED).run()
    assert not at.exception
    assert at.button(key=prefix + '_cw_bind_qualification').disabled
    assert current(at, prefix).column_weld.qualification_signature == ''
    assert not any(x.key == prefix + '_cw_detail_confirmed' for x in at.checkbox)


@pytest.mark.parametrize('field', ['transfer_ref'])
def test_each_missing_substantive_record_disables_binding(field):
    at = open_app(c=config(**{field: '   '}))
    assert at.button(key='bp_cw_bind_qualification').disabled
    assert current(at).column_weld.qualification_signature == ''


def test_qualified_binding_is_an_explicit_action_and_can_be_removed():
    at = open_app(c=config())
    assert not at.button(key='bp_cw_bind_qualification').disabled
    assert current(at).column_weld.qualification_signature == ''
    bind(at)
    at.button(key='bp_cw_clear_qualification').click().run()
    assert current(at).column_weld.qualification_signature == ''
    assert current(at).column_weld.transfer_ref == config().column_weld.transfer_ref
    assert not at.exception


@pytest.mark.parametrize('kind,key,value', [
    ('number_input', 'bp_N_kgf', 5000.),
    ('number_input', 'bp_M_kgfm', -500.),
    ('number_input', 'bp_V_kgf', 3000.),
    ('number_input', 'bp_a1', 55.),
    ('number_input', 'bp_weld_flange_size', 7.),
    ('number_input', 'bp_cw_flange_effective_length', 140.),
    ('selectbox', 'bp_weld_flange_type', 'cjp'),
    ('text_input', 'bp_cw_transfer_ref', 'Revisão do modelo de transferência.'),
])
def test_edit_invalidates_binding_and_reverting_does_not_restore(kind, key, value):
    at = open_app(c=config())
    bind(at)
    element = getattr(at, kind)(key=key)
    original = element.value
    element.set_value(value).run()
    assert not at.exception
    assert current(at).column_weld.qualification_signature == ''
    assert any('invalidada' in message.value for message in at.warning)
    getattr(at, kind)(key=key).set_value(original).run()
    assert not at.exception
    assert current(at).column_weld.qualification_signature == ''


def test_off_on_and_family_roundtrip_preserve_records_but_do_not_revalidate():
    at = open_app(c=config())
    before = bind(at).column_weld
    at.selectbox(key='bp_cw_model').set_value('off').run()
    assert current(at).column_weld.qualification_signature == ''
    at.selectbox(key='connection_family').set_value(FAMILIES['pp']).run()
    at.selectbox(key='pp_cw_model').set_value(MODEL_QUALIFIED).run()
    at.text_input(key='pp_cw_transfer_ref').set_value('Memória independente Tipo 2').run()
    at.selectbox(key='connection_family').set_value('Single plate').run()
    at.selectbox(key='connection_family').set_value(FAMILIES['bp']).run()
    at.selectbox(key='bp_cw_model').set_value(MODEL_QUALIFIED).run()
    after = current(at).column_weld
    assert after.transfer_ref == before.transfer_ref
    assert after.allocation_basis == before.allocation_basis
    assert after.flange_effective_length == before.flange_effective_length
    assert after.qualification_signature == ''
    at.selectbox(key='connection_family').set_value(FAMILIES['pp']).run()
    assert current(at, 'pp').column_weld.transfer_ref == 'Memória independente Tipo 2'
    assert not at.exception


def test_either_cjp_part_reveals_existing_inspection_fields_and_mixed_process():
    at = open_app(c=config())
    at.selectbox(key='bp_weld_flange_type').set_value('cjp').run()
    at.selectbox(key='bp_cw_process').set_value('smaw_e7018_mixed').run()
    assert at.selectbox(key='bp_cw_cjp_detail')
    at.text_input(key='bp_cw_inspection_ref').set_value('IT-01').run()
    at.selectbox(key='bp_weld_flange_type').set_value('fillet').run()
    at.selectbox(key='bp_weld_web_type').set_value('cjp').run()
    assert current(at).column_weld.inspection_ref == 'IT-01'
    assert current(at).column_weld.process == 'smaw_e7018_mixed'
    assert not at.exception


def test_fit_bearing_uses_area_not_external_capacity_and_needs_its_records():
    at = open_app(c=config())
    at.selectbox(key='bp_cw_normal_transfer').set_value('fit_bearing').run()
    assert at.button(key='bp_cw_bind_qualification').disabled
    at.number_input(key='bp_cw_bearing_area').set_value(5000.).run()
    at.text_input(key='bp_cw_bearing_ref').set_value('Apoio AP-01').run()
    at.text_area(key='bp_cw_bearing_basis').set_value('Contato preparado e área real de 5000 mm² demonstrados em AP-01.').run()
    assert not any(x.key == 'bp_cw_bearing_rd' for x in at.number_input)
    assert not at.button(key='bp_cw_bind_qualification').disabled
    at.selectbox(key='bp_cw_normal_transfer').set_value('welded').run()
    at.selectbox(key='bp_cw_normal_transfer').set_value('fit_bearing').run()
    assert current(at).column_weld.bearing_area == 5000.
    assert not at.exception


def test_legacy_type2_model_still_has_its_own_detail_confirmation():
    at = open_app('pp', config('pp'))
    at.selectbox(key='pp_cw_model').set_value(MODEL).run()
    assert at.checkbox(key='pp_cw_detail_confirmed')
    assert not any(x.key == 'pp_cw_bind_qualification' for x in at.button)
    assert not at.exception


def test_repeated_json_import_preserves_current_bound_record_and_edit_invalidates():
    c = config()
    c = replace(c, column_weld=replace(c.column_weld, qualification_signature=qualification_signature(c)))
    at = open_app(c=c)
    for _ in range(2):
        assert current(at).column_weld.qualification_signature == qualification_signature(current(at))
        at.get('file_uploader')[0].upload('weld.json', json.dumps(c.to_dict()).encode(), 'application/json').run()
        next(x for x in at.button if x.label == 'Abrir placa de base JSON').click().run()
        assert not at.exception
    at.text_input(key='bp_cw_transfer_ref').set_value('MC-01, revisão alterada').run()
    assert current(at).column_weld.qualification_signature == ''


def test_conditional_results_keep_signed_audit_and_native_drawing_downloads():
    at = open_app(c=config())
    assert current(at).column_weld.qualification_signature == ''
    assert any('Componentes numéricos atendem condicionalmente' in x.value for x in at.warning)
    assert not any('no escopo da qualificação documental vinculada' in x.value for x in at.success)
    assert not any(x.value == 'Base completa: ancoragem no concreto, bloco armado e soldas do pilar a complementar.' for x in at.warning)
    assert any('Resíduos de equilíbrio' in x.value for x in at.caption)
    assert any('Resultantes integradas' in x.value for x in at.markdown)
    labels = [x.label for x in at.get('download_button')]
    assert 'Baixar detalhe da solda pilar–placa PNG' in labels
    assert 'Baixar detalhe da solda pilar–placa SVG' in labels
    assert not at.exception


def test_project_title_and_notes_do_not_invalidate_bound_engineering_data():
    at = open_app(c=config())
    before = bind(at).column_weld.qualification_signature
    at.text_input(key='bp_project').set_value('Identificação revisada da mesma base').run()
    at.text_area(key='bp_notes').set_value('Observação administrativa sem alteração do detalhe.').run()
    assert current(at).column_weld.qualification_signature == before
    assert not at.exception


def test_bound_integer_json_dimensions_roundtrip_without_false_invalidation():
    c = config()
    p = replace(c.column, d=300, bf=180, tw=8, tf=12, clear=276, area=6528)
    u = replace(c.column_weld, flange_length=180, flange_effective_length=150,
                web_length=250, web_effective_length=220)
    c = replace(c, column=p, column_weld=u, N=40000, M=1000000, V=20000, a1=50, a2=120, tp=35)
    sig = qualification_signature(c)
    c = replace(c, column_weld=replace(u, qualification_signature=sig))
    at = open_app(c=c)
    assert current(at).column_weld.qualification_signature == sig
    assert qualification_signature(current(at)) == sig
    assert not at.exception


def test_qualified_component_report_generation_and_invalidation():
    at = open_app(c=config())
    bind(at)
    next(x for x in at.button if x.label == 'Gerar memória da placa de base').click().run()
    assert not at.exception
    assert at.session_state['bp_report'][2][:2] == b'PK'
    at.number_input(key='bp_cw_web_effective_length').set_value(210.).run()
    assert current(at).column_weld.qualification_signature == ''
    assert 'bp_report' not in at.session_state
    assert not at.exception


def test_current_transfer_record_with_missing_cjp_inspection_keeps_design_result():
    c = replace(config(process='smaw_e7018', cjp_detail='backing_removed', inspection_ref=''),
                weld_flange_type='cjp', weld_web_type='cjp')
    at = open_app(c=c)
    bind(at)
    assert any('Cálculo das soldas e seções locais: ATENDE' in x.value for x in at.success)
    assert any('o app não verifica sua realização' in x.value for x in at.caption)
    assert not any('a qualificação documental de transferência permanece pendente' in x.value for x in at.warning)
    assert any('Os componentes locais calculados atendem no escopo' in x.value for x in at.success)
    assert not at.exception


@pytest.mark.parametrize('prefix', ['bp', 'pp'])
@pytest.mark.parametrize('key,value', [('weld_flange_size', 100000.),
                                       ('cw_flange_effective_length', 181.)])
def test_invalid_weld_geometry_withholds_detail_and_report_without_crashing(prefix, key, value):
    at = open_app(prefix, config(prefix))
    bind(at, prefix)
    report_button = lambda: next(x for x in at.button if x.label == 'Gerar memória da placa de base')
    report_button().click().run()
    assert not at.exception
    assert at.session_state[prefix + '_report'][2][:2] == b'PK'
    original = at.number_input(key=prefix + '_' + key).value
    at.number_input(key=prefix + '_' + key).set_value(value).run()
    assert not at.exception
    preblocked = prefix == 'pp' and key == 'weld_flange_size'
    if preblocked:
        # The original Type2 physical-interference gate correctly runs first.
        assert any('Arruelas internas interferem' in x.value for x in at.error)
        assert report_button().disabled
    else:
        assert any('Detalhe da ancoragem e soldas indisponível' in x.value for x in at.warning)
        assert any('Há componente local calculado que não atende' in x.value for x in at.error)
    if key == 'cw_flange_effective_length':
        assert any('Comprimento efetivo deve caber' in x.value for x in at.error)
    assert at.session_state[PROJECT_KEYS[prefix]]['connection']['column_weld']['qualification_signature'] == ''
    assert prefix + '_report' not in at.session_state
    labels = [x.label for x in at.get('download_button')]
    assert 'Baixar detalhe da ancoragem e soldas SVG' not in labels
    assert 'Baixar detalhe da solda pilar–placa PNG' not in labels
    assert 'Baixar detalhe da solda pilar–placa SVG' not in labels
    assert 'Baixar memória da placa de base .docx' not in labels
    if not preblocked:
        report_button().click().run()
        assert not at.exception
        assert any('Memória da placa de base indisponível' in x.value for x in at.warning)
    assert prefix + '_report' not in at.session_state
    assert not any(x.label == 'Baixar memória da placa de base .docx' for x in at.get('download_button'))
    at.number_input(key=prefix + '_' + key).set_value(original).run()
    assert not at.exception
    assert current(at, prefix).column_weld.qualification_signature == ''
    assert not any('Detalhe da ancoragem e soldas indisponível' in x.value for x in at.warning)
    assert any(x.label == 'Baixar detalhe da ancoragem e soldas SVG' for x in at.get('download_button'))
    assert any(x.label == 'Baixar detalhe da solda pilar–placa SVG' for x in at.get('download_button'))
    report_button().click().run()
    assert not at.exception
    assert at.session_state[prefix + '_report'][2][:2] == b'PK'


def test_equivalent_leg_throat_toggles_preserve_bound_qualification():
    at = open_app(c=config())
    signature = bind(at).column_weld.qualification_signature
    for part in ('flange', 'web'):
        at.selectbox(key='bp_weld_' + part + '_measure').set_value('throat').run()
        assert current(at).column_weld.qualification_signature == signature
        assert qualification_signature(current(at)) == signature
        at.selectbox(key='bp_weld_' + part + '_measure').set_value('leg').run()
        assert current(at).column_weld.qualification_signature == signature
    assert not at.exception


def test_real_throat_change_invalidates_even_after_equivalent_measure_switch():
    at = open_app(c=config())
    bind(at)
    at.selectbox(key='bp_weld_flange_measure').set_value('throat').run()
    assert current(at).column_weld.qualification_signature
    old = at.number_input(key='bp_weld_flange_size').value
    at.number_input(key='bp_weld_flange_size').set_value(old * 1.1).run()
    assert current(at).column_weld.qualification_signature == ''
    at.number_input(key='bp_weld_flange_size').set_value(old).run()
    assert current(at).column_weld.qualification_signature == ''
    assert not at.exception


def test_imported_inactive_fillet_drafts_do_not_invalidate_active_cjp_record():
    c = replace(config(process='smaw_e7018', cjp_detail='backing_removed', inspection_ref='IT-01'),
                weld_flange_type='cjp', weld_web_type='cjp')
    at = open_app(c=c)
    c = bind(at)
    signature = c.column_weld.qualification_signature
    changed = replace(c, weld_flange_size=9., weld_flange_measure='throat',
                      weld_web_size=11., weld_web_measure='throat')
    assert qualification_signature(changed) == signature
    at.get('file_uploader')[0].upload('cjp.json', json.dumps(changed.to_dict()).encode(), 'application/json').run()
    next(x for x in at.button if x.label == 'Abrir placa de base JSON').click().run()
    assert current(at).column_weld.qualification_signature == signature
    assert current(at).weld_flange_size == 9.
    assert current(at).weld_web_size == 11.
    assert current(at).weld_flange_measure == current(at).weld_web_measure == 'throat'
    assert not at.exception
