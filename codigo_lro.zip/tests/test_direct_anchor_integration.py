from dataclasses import replace,asdict
import json,math
import pytest
from lro.models import Profile
from lro.base_plate import BasePlate,evaluate
from lro.pinned_base_plate import PinnedBasePlate
from lro.channel_base_plate import ChannelBasePlate
from lro.concrete_components import ConcreteComponents,bearing_signature
from lro.direct_anchor_shear import DirectAnchorShear,MODEL,unc_thread_area

P=Profile('I 300 x 150','Soldado',40.,300.,150.,8.,12.,276.,7008.)

def config():
    return DirectAnchorShear(model=MODEL,material_name='Classe 4.6',material_basis='EN_bolt',
        material_specification='EN ISO 898-1:1999',material_reference='Synthetic benchmark certificate',
        material_quality_reference='Synthetic quality/elongation certificate',fy=240.,fu=400.,thread_area=353.,
        thread_manufacture='cut',thread_compliance='en1090_verified',thread_reference='M24 As353 specimen',
        hole_diameter=26.,hole_kind='normal_round',normal_hole_tolerance_verified=True,execution_reference='Synthetic normal-hole jig',
        grout_complete=True,grout_cured=True,no_free_standoff=True,grout_reference='Synthetic full grouting',static_loading=True)

def fixture(**kw):
    c=BasePlate(P,project='Synthetic direct-bearing integration benchmark',db=24.,a1=70.,a2=200.,tp=50.,N=200000.,M=10e6,V=40000.,
        shear_path='anchors',anchor_shear_model='direct_plate_bearing',direct_shear=config(),
        anchor_washer_side=70.,anchor_washer_t=10.,anchor_type='headed',anchor_detail_confirmed=True,
        anchor_detail_ref='Synthetic cast-in head',cone_model='aci318_19',
        concrete_components=ConcreteComponents(model='aci318_19',bearing_area=1000.,bearing_area_ref='Synthetic net head area',
            mechanical_resistance=200000.,mechanical_ref='Synthetic head capacity'))
    c=replace(c,**kw)
    return replace(c,concrete_components=replace(c.concrete_components,bearing_confirmation=bearing_signature(c)))


def test_three_states_pass_component_keep_global_pending():
    c=fixture();r=evaluate(c);d=r.geometry['direct_anchor_shear']
    assert d['domain']['eligible'] and d['steel_plate_uls']['passes']
    assert r.concrete_components['passes'] is True
    assert len(r.concrete_components['states'])==3
    assert not d['direct_route_resistance_pass']
    assert not d['foundation_scope']['complete']
    assert not c.native_anchor_shear and c.direct_anchor_shear
    assert r.geometry['friction_credited']==r.geometry['washer_lateral_credited']==0


def test_material_real_in_every_aci_alternative():
    u=replace(config(),material_name='Classe 8.8',fy=640.,fu=800.)
    c=fixture(direct_shear=u,N=-80000.,M=6e6,V=20000.)
    r=evaluate(c)
    expected=.60*.6*353.*min(800.,1.9*640.,125000*.006894757293168361)*.8
    seen=0
    for state in r.concrete_components['states']:
        assert state['material']['fy']==640. and state['material']['fu']==800.
        for sub in state['force_states']:
            for ck in sub['steel']:
                if ck['id'].startswith('aci_shear_'):
                    seen+=1;assert ck['resistance']==pytest.approx(expected)
    assert seen>=12


@pytest.mark.parametrize('N,M',[(200000.,10e6),(-80000.,6e6),(-80000.,-6e6),(0.,5e6)])
def test_reversal_keeps_tensions_and_changes_credited_rows(N,M):
    c=fixture(N=N,M=M,V=10000.)
    a=evaluate(c).geometry['direct_anchor_shear'];b=evaluate(replace(c,V=-c.V)).geometry['direct_anchor_shear']
    assert {r['id']:r['tension'] for r in a['states'][0]['rods']}=={r['id']:r['tension'] for r in b['states'][0]['rods']}
    for r1,r2 in zip(a['states'][1]['rods'],b['states'][1]['rods']):
        assert r1['credited_to_shear'] != r2['credited_to_shear']
    assert a['bearings']['A1']['reaction_edge']=='x-'
    assert b['bearings']['A1']['reaction_edge']=='x+'


def test_upper_washer_has_no_lateral_credit_or_steel_effect():
    c=fixture();r=evaluate(c);changed=evaluate(replace(c,anchor_washer_t=15.,anchor_washer_side=75.))
    da=r.geometry['direct_anchor_shear'];db=changed.geometry['direct_anchor_shear']
    for field in ('resistances','bearings','states'):
        assert da[field]==db[field]
    assert not r.local_upper_washer and not changed.local_upper_washer


@pytest.mark.parametrize('field,value',[("hole_diameter",33.),('grout_complete',False),('grout_cured',False),('no_free_standoff',False),('static_loading',False)])
def test_domain_gates_preserve_other_results_and_export(field,value):
    c=fixture(direct_shear=replace(config(),**{field:value}));r=evaluate(c)
    assert not r.geometry['direct_anchor_shear']['domain']['eligible']
    assert r.checks and r.geometry
    assert BasePlate.from_dict(json.loads(json.dumps(c.to_dict())))==c
    assert not r.geometry['direct_anchor_shear']['direct_route_resistance_pass']


@pytest.mark.parametrize('mode', ['no_slip','numeric_total_limit'])
def test_service_never_approves_from_clearance(mode):
    r=evaluate(fixture(direct_shear=replace(config(),service_slip_requirement=mode,service_total_limit=500.)))
    d=r.geometry['direct_anchor_shear']
    assert not d['service_scope']['passes']
    assert not d['service_scope']['total_displacement_calculated']


@pytest.mark.parametrize('field,value',[('fy','240'),('fu',None),('thread_area',True),('grout_complete',1),('hole_diameter',float('nan'))])
def test_bad_nested_values_fail_closed(field,value):
    c=fixture(direct_shear=replace(config(),**{field:value}));r=evaluate(c)
    assert any(i.severity=='error' for i in r.issues)
    assert not r.geometry


def test_aci_area_cannot_override_actual_thread():
    c=fixture(concrete_components=ConcreteComponents(model='aci318_19',area_tension=400.,area_shear=400.,steel_area_ref='Wrong larger area'))
    r=evaluate(c)
    assert not r.concrete_components['complete'] and r.concrete_components['passes'] is None


def test_astm_legacy_no_inferred_qualification():
    c=fixture(direct_shear=replace(config(),material_name='ASTM A36',material_basis='ASTM_supplementary',material_specification='ASTM A36',fy=250.))
    r=evaluate(c);d=r.geometry['direct_anchor_shear']
    assert not d['domain']['eligible'] and not d['material']['en_3_3_identity_eligible']


def test_qualified_unc_astm_no_material_conversion():
    u=replace(config(),material_name='ASTM A36',material_basis='ASTM_supplementary',material_specification='ASTM A36/A36M-19',fy=250.,
        material_protocol='astm_a36_supplementary_v1',ductility_reference='Synthetic final-product elongation',
        certification_reference='Synthetic ASTM product certificate',supplementary_application_accepted=True,
        thread_standard='UNC_2A',thread_tpi=8.,thread_area=unc_thread_area(25.4,8.),thread_area_source='calculated_asme',
        thread_compliance='unverified_cut',hole_basis='supplementary_unc_bounded',hole_diameter=28.4)
    c=fixture(db=25.4,direct_shear=u);r=evaluate(c);d=r.geometry['direct_anchor_shear']
    assert d['domain']['eligible'] and not d['material']['en_3_3_identity_eligible']
    assert d['material']['name']=='ASTM A36' and c.db==25.4
    assert BasePlate.from_dict(c.to_dict())==c


def test_type2_independent_family_no_applied_M():
    c=PinnedBasePlate(P,db=24.,a1=70.,a2=120.,tp=50.,N=-40000.,V=10000.,
        shear_path='anchors',anchor_shear_model='direct_plate_bearing',direct_shear=config())
    r=evaluate(c)
    assert r.geometry and c.M==0 and not c.native_anchor_shear
    assert len(r.geometry['direct_anchor_shear']['states'])==3
    assert PinnedBasePlate.from_dict(c.to_dict())==c


@pytest.mark.parametrize('layout,nstates',[('four',3),('two_symmetry',1)])
def test_channel_uses_actual_layout_and_prying(layout,nstates):
    p=Profile('U synthetic','U',20.,200.,75.,7.,10.,180.,3000.)
    c=ChannelBasePlate(p,L_plate=350.,B_plate=350.,anchor_x=45.,anchor_y=130.,
        db=24.,anchor_washer_side=50.,anchor_washer_t=10.,base_hole=26.,anchor_layout=layout,
        centroid_back=20.,straight_web_length=175.,clear_geometry_confirmed=True,flange_min_thickness=8.,
        N=-20000.,V=10000.,tp=30.,shear_path='anchors',anchor_shear_model='direct_plate_bearing',direct_shear=config())
    r=evaluate(c)
    assert r.geometry,[(x.severity,x.text) for x in r.issues]
    direct=r.geometry['direct_anchor_shear']
    assert len(direct['states'])==nstates
    assert all(a['tension']==pytest.approx(1.4*abs(c.N)/c.anchor_count) for a in direct['states'][0]['rods'])
    assert sum(direct['states'][0]['forces'].values())==abs(c.V)
    assert ChannelBasePlate.from_dict(c.to_dict())==c
