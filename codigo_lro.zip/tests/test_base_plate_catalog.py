from dataclasses import replace
from io import BytesIO
from pathlib import Path
import copy,json
import pytest
from docx import Document
from streamlit.testing.v1 import AppTest
from lro.base_plate import BasePlate,presets,evaluate
from lro.pinned_base_plate import PinnedBasePlate,presets as pinned_presets,evaluate as pinned_evaluate
from lro.base_plate_catalog import FIXED,PINNED,load_project,catalog_family
from lro.base_plate_report import create_report
from lro.base_plate_drawing import image_bytes

APP=Path(__file__).resolve().parents[1]/'app.py'
def button(at,label):return next(x for x in at.button if x.label==label)
def app(family=FIXED):
    at=AppTest.from_file(str(APP),default_timeout=90).run()
    at.selectbox(key='connection_family').set_value(family).run()
    assert not at.exception
    return at

def test_legacy_pinned_intent_never_changes_geometry_or_drops_moment():
    c=replace(presets()['T2 · tração e pequeno momento'],base_fixity='pinned',M=-5e6)
    raw=c.to_dict();raw['schema_version']=1;raw['connection_type']='base_plate'
    loaded=load_project(raw)
    assert type(loaded) is BasePlate
    assert loaded==c and loaded.a==c.L/2-c.a1
    assert loaded.M==-5e6
    saved=loaded.to_dict()
    assert saved['connection_type']=='base_plate_type1_legacy'
    assert saved['schema_version']==2 and catalog_family(loaded)==FIXED
    assert BasePlate.from_dict(saved)==c
    assert 'não foi convertido' in loaded.migration_message
    assert any('legado' in x.text for x in evaluate(loaded).issues)
    with pytest.raises(ValueError):PinnedBasePlate.from_dict(raw)
    tampered=copy.deepcopy(saved);tampered['connection_type']='base_plate_fixed'
    with pytest.raises(ValueError):BasePlate.from_dict(tampered)

def test_new_pinned_project_is_separately_typed_and_has_no_applied_m():
    c=pinned_presets()['Chumbadores · arruelas soldadas']
    assert c.a==c.a2/2 and c.a<c.column.d/2-c.column.tf
    assert c.to_dict()['connection_type']=='base_plate_pinned'
    assert 'M' not in c.to_dict()['connection']
    assert 'base_fixity' not in c.to_dict()['connection']
    assert type(load_project(c.to_dict())) is PinnedBasePlate
    assert catalog_family(c)==PINNED
    with pytest.raises(ValueError):BasePlate.from_dict(c.to_dict())
    for M in (0.,25e6):
        raw=c.to_dict();raw['connection']['M']=M
        with pytest.raises(ValueError):PinnedBasePlate.from_dict(raw)

def test_catalog_no_fixity_selector_independent_loads_and_hidden_washer_drafts():
    at=app()
    assert FIXED in at.selectbox(key='connection_family').options and PINNED in at.selectbox(key='connection_family').options
    assert not any(x.key=='bp_base_fixity' for x in at.selectbox)
    at.number_input(key='bp_M_kgfm').set_value(3100.).run()
    at.selectbox(key='bp_uw_model').set_value('four_edge_elastic').run()
    at.number_input(key='bp_uw_leg').set_value(7.).run()
    fixed=copy.deepcopy(at.session_state['_base_plate_project'])
    at.selectbox(key='connection_family').set_value(PINNED).run()
    assert not at.exception
    assert not any('Momento M' in x.label for x in at.number_input)
    assert not any(x.key=='pp_M_kgfm' for x in at.number_input)
    assert at.selectbox(key='pp_uw_model').value=='off'
    at.selectbox(key='pp_uw_model').set_value('four_edge_elastic').run()
    at.number_input(key='pp_uw_leg').set_value(4.).run()
    at.number_input(key='pp_N_kgf').set_value(-5432.).run()
    pinned=copy.deepcopy(at.session_state['_pinned_base_plate_project'])
    at.selectbox(key='connection_family').set_value(FIXED).run()
    assert not at.exception and at.session_state['_base_plate_project']==fixed
    assert at.number_input(key='bp_uw_leg').value==7.
    at.selectbox(key='connection_family').set_value(PINNED).run()
    assert not at.exception and at.session_state['_pinned_base_plate_project']==pinned
    assert at.number_input(key='pp_uw_leg').value==4.
    assert 'M' not in pinned['connection']

def test_legacy_import_explains_migration_and_pinned_rejects_it():
    c=replace(presets()['T2 · tração e pequeno momento'],base_fixity='pinned',M=-5e6)
    raw=c.to_dict();raw['connection_type']='base_plate';raw['schema_version']=1
    at=app()
    at.get('file_uploader')[0].upload('legacy.json',json.dumps(raw).encode(),'application/json').run()
    button(at,'Abrir placa de base JSON').click().run()
    assert not at.exception and BasePlate.from_dict(at.session_state['_base_plate_project'])==c
    assert any('não foi convertido' in x.value for x in at.warning)
    at.selectbox(key='connection_family').set_value(PINNED).run()
    before=copy.deepcopy(at.session_state['_pinned_base_plate_project'])
    at.get('file_uploader')[0].upload('legacy.json',json.dumps(raw).encode(),'application/json').run()
    button(at,'Abrir placa de base JSON').click().run()
    assert not at.exception and at.session_state['_pinned_base_plate_project']==before
    assert 'pp_import_error' in at.session_state

def test_pinned_drawing_and_word_have_correct_geometry_equation_and_load_labels():
    c=pinned_presets()['Chumbadores · arruelas soldadas'];r=pinned_evaluate(c)
    drawing=image_bytes(c,r,'svg').decode()
    assert 'pinned_anchor_A4' in drawing and 'QUATRO CHUMBADORES EXTERNOS' not in drawing
    uplift=replace(c,N=-50000.,V=0.)
    assert '2×1274.6 kgf' in image_bytes(uplift,pinned_evaluate(uplift),'svg').decode()
    doc=Document(BytesIO(create_report(c,r,True)));xml=doc._element.xml
    assert 'chumbadores internos' in xml and 'Momento aplicado: zero' in xml
    assert 'a2−tw' in xml and 'l0' in xml
    headings=[p.text for p in doc.paragraphs if p.style.name=='Title']
    assert 'rotulada' in headings[0]
