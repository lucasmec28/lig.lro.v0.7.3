"""Guarda numérica e preservação dos projetos ao alternar as telas."""
from dataclasses import replace
from pathlib import Path
import math
import pytest
from streamlit.testing.v1 import AppTest
from lro.models import Check

ROOT=Path(__file__).resolve().parents[1]

@pytest.mark.parametrize('demand,resistance',[(1,math.inf),(1,math.nan),(math.nan,100),(math.inf,100),(1,0),(0,0),(1,-1)])
def test_nonfinite_or_invalid_numeric_check_is_not_approval(demand,resistance):
    c=Check('test','Test',demand,resistance,'N','','','','')
    assert not c.passed and math.isinf(c.ratio)

def test_finite_zero_demand_and_negative_load_still_work():
    assert Check('test','Test',0,100,'N','','','','').passed
    assert Check('test','Test',-50,100,'N','','','','').ratio==.5


def app():return AppTest.from_file(str(ROOT/'app.py'),default_timeout=60).run()
def family(at,name):
    at.selectbox(key='connection_family').set_value(name).run()
    assert not at.exception

def test_end_plate_values_survive_other_families_and_each_kind():
    at=app();family(at,'End plate · engastada')
    at.text_input(key='ep_project').set_value('Projeto engastado preservado').run()
    at.number_input(key='ep_M_kgfm').set_value(-4300.).run()
    at.number_input(key='ep_intermediate_n').set_value(1).run()
    at.text_area(key='ep_notes').set_value('Nota da engastada; manter a ressalva.').run()
    original=dict(at.session_state['ep_model'])
    family(at,'Single plate');family(at,'End plate · engastada')
    assert at.session_state['ep_model']==original
    family(at,'End plate · rotulada')
    at.text_input(key='ep_project').set_value('Projeto rotulado preservado').run()
    at.number_input(key='ep_V_kgf').set_value(2400.).run()
    pinned=dict(at.session_state['ep_model'])
    family(at,'End plate · engastada')
    assert at.session_state['ep_model']==original
    assert at.warning
    family(at,'End plate · rotulada')
    assert at.session_state['ep_model']==pinned
    family(at,'End plate · engastada')
    next(x for x in at.button if x.label=='Gerar memória Word').click().run()
    assert not at.exception and at.session_state['ep_report'][2][:2]==b'PK'
    at.number_input(key='ep_M_kgfm').set_value(-4400.).run()
    assert not any(getattr(x,'label','')=='Baixar memória Word' for x in at.get('download_button'))


def test_single_and_double_cover_values_survive_navigation():
    at=app()
    at.text_input(key='project').set_value('Single plate preservada').run()
    at.number_input(key='V_kgf').set_value(876.).run()
    at.text_area(key='notes').set_value('Nota single plate').run()
    single=dict(at.session_state['_single_plate_project'])
    family(at,'Alma de coluna · duas talas')
    at.text_input(key='dc_project').set_value('Duas talas preservadas').run()
    at.number_input(key='dc_V_kgf').set_value(-876.).run()
    at.text_area(key='dc_notes').set_value('Nota duas talas').run()
    double=dict(at.session_state['_double_cover_project'])
    for _ in range(2):
        family(at,'Single plate')
        assert at.session_state['_single_plate_project']==single
        family(at,'Alma de coluna · duas talas')
        assert at.session_state['_double_cover_project']==double


def test_explicit_end_plate_example_replaces_only_its_own_draft():
    at=app();family(at,'End plate · engastada')
    at.text_input(key='ep_project').set_value('Meu projeto moment').run()
    original=dict(at.session_state['ep_model'])
    family(at,'End plate · rotulada')
    at.selectbox(key='ep_example').set_value('Rotulada · V e compressão').run()
    next(x for x in at.button if x.label=='Carregar exemplo').click().run()
    assert at.session_state['ep_model']['N']<0
    family(at,'End plate · engastada')
    assert at.session_state['ep_model']==original


@pytest.mark.parametrize('name,upload_key,button,model_key',[
    ('Single plate','project_upload','Abrir arquivo','_single_plate_project'),
    ('Alma de coluna · duas talas','dc_upload','Abrir projeto de duas talas','_double_cover_project'),
    ('End plate · engastada','ep_upload','Abrir projeto de end plate','_end_plate_projects'),
])
def test_bad_import_does_not_replace_current_draft(name,upload_key,button,model_key):
    import copy,json
    at=app();family(at,name)
    before=copy.deepcopy(at.session_state[model_key])
    payload=copy.deepcopy(before['moment'] if name.startswith('End plate') else before)
    payload['connection']['db']=None
    at.get('file_uploader')[0].upload('bad.json',json.dumps(payload).encode(),'application/json').run()
    next(x for x in at.button if x.label==button).click().run()
    assert not at.exception and at.error
    assert at.session_state[model_key]==before
