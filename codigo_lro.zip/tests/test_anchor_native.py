"""Arruelas soldadas: cálculos independentes, domínio e conservação do escopo."""
from dataclasses import replace
from pathlib import Path
import json
import math
import pytest
from lro.base_plate import BasePlate, evaluate, reactions, anchor_shear_actions, presets
from lro.models import Profile

P=Profile('I 300 × 150','Soldado',40.,300.,150.,8.,12.,276.,7008.)
BASE=BasePlate(P,a1=50.,a2=100.,db=25.4,tp=25.4,N=400000.,V=50000.,
               shear_path='anchors',anchor_shear_model='welded_washer',
               anchor_washer_t=9.525,anchor_washer_side=75.)


def test_native_model_and_old_json_are_distinct_and_backward_compatible():
    c=presets()['Chumbadores · arruelas soldadas']
    loaded=BasePlate.from_dict(json.loads(json.dumps(c.to_dict())))
    assert loaded==c and loaded.native_anchor_shear
    old=c.to_dict()
    for key in ('anchor_shear_model','anchor_washer_t','anchor_washer_side'):
        old['connection'].pop(key)
    assert BasePlate.from_dict(old).anchor_shear_model=='external'
    old['connection'].pop('shear_path')
    assert BasePlate.from_dict(old).shear_path=='friction'


def test_native_actions_do_not_depend_on_external_capacity_or_add_friction():
    c=replace(BASE,external_shear_rd=1e9,anchor_shear_rd=1e9,anchor_shear_ref='irrelevante')
    r=evaluate(c);a=r.geometry
    assert a['shear_rd']==a['anchor_shear']['group_rd']<1e9
    assert a['friction_rd']>0
    assert not any(x.id in ('bp_shear','bp_shear_anchors_external','bp_shear_external') for x in r.checks)
    assert a['M_effective']==c.M and a['delta_M']==0.
    assert all('shear' not in rod and 'V' not in rod for rod in a['anchor_shear']['rods'])


@pytest.mark.parametrize('N,M',[(-100000.,0.),(-100000.,10e6),(400000.,120e6),(-100000.,40e6)])
def test_each_physical_rod_uses_its_concurrent_tension_and_signed_position(N,M):
    c=replace(BASE,N=N,M=M);r=evaluate(c);a=r.geometry;ash=a['anchor_shear']
    assert len(ash['rods'])==4
    for rod in ash['rods']:
        assert rod['tension']==(a['Ft_max'] if rod['x']==a['T_max_x'] else a['Ft_min'])
        assert rod['rd']==min(rod['steel_rd'],rod['combined_rd'],ash['concrete_cap'])
    assert ash['subtractive_tension']==a['Ft_max']
    assert ash['group_rd']==sum(rod['rd'] for rod in ash['rods'])
    mirrored=evaluate(replace(c,M=-M,V=-c.V)).geometry['anchor_shear']
    assert mirrored['group_rd']==pytest.approx(ash['group_rd'])
    bypos={(rod['x'],rod['y']):rod for rod in mirrored['rods']}
    for rod in ash['rods']:
        assert rod['tension']==bypos[(-rod['x'],rod['y'])]['tension']
    assert ash['weld_force_per_washer']==ash['shear_unreduced_rd']
    assert ash['weld_force_per_washer']>max(rod['rd'] for rod in ash['rods'])


def test_index_ambiguity_is_conservatively_bounded_and_disclosed():
    c=replace(BASE,N=-100000.,M=10e6)
    r=evaluate(c);ash=r.geometry['anchor_shear'];alpha=ash['alpha'];fv=ash['shear_unreduced_rd']
    assert any(i.severity=='warning' and 'índice' in i.text for i in r.issues)
    for rod in ash['rods']:
        q=.533*rod['tension']
        per_i=(math.sqrt((1+alpha*alpha)*fv*fv-q*q)-alpha*q)/(1+alpha*alpha)
        assert rod['steel_rd']<=per_i+1e-8
    assert ash['rods'][2]['steel_rd']<per_i
    equal=evaluate(replace(c,M=0.))
    assert not any(i.severity=='warning' and 'índice' in i.text for i in equal.issues)


def test_tension_limit_zeroes_general_interaction_without_rewriting_special_equation():
    ft=BASE.anchor_steel_rd
    c=replace(BASE,N=-4*ft,M=0.,V=1.)
    r=evaluate(c);ash=r.geometry['anchor_shear']
    assert ash['domain_ok']
    assert all(rod['steel_rd']>0 for rod in ash['rods'])
    assert all(rod['combined_rd']==0. for rod in ash['rods'])
    assert ash['group_rd']==0
    checks={row.id:row for row in r.checks}
    assert checks['bp_anchor_steel'].passed
    assert not checks['bp_anchor_shear_interaction'].passed
    assert not checks['bp_anchor_shear_native'].passed
    assert checks['bp_anchor_shear_special'].passed
    assert 'NÃO ATENDE' in r.status


@pytest.mark.parametrize('ratio',[1.001,10.])
def test_tension_exceedance_never_gets_a_valid_group_capacity(ratio):
    c=replace(BASE,N=-4*BASE.anchor_steel_rd*ratio,M=0.,V=1.)
    r=evaluate(c);ash=r.geometry['anchor_shear']
    assert not ash['domain_ok'] and ash['group_rd']==0
    assert not any(rod['domain_ok'] for rod in ash['rods'])
    assert not next(row for row in r.checks if row.id=='bp_anchor_steel').passed
    assert 'NÃO ATENDE' in r.status


def test_zero_loads_still_expose_partial_scope_and_zero_tension_limit_is_not_zero_over_zero():
    c=replace(BASE,N=0.,M=0.,V=0.)
    r=evaluate(c)
    assert r.geometry['anchor_shear']['group_rd']>0
    assert any('solda' in i.text for i in r.issues if i.severity=='pending')
    assert any('pryout' in i.text for i in r.issues if i.severity=='pending')
    at_limit=evaluate(replace(c,N=-4*c.anchor_steel_rd))
    assert at_limit.geometry['anchor_shear']['group_rd']==0.
    assert not any(row.id=='bp_anchor_shear_native' for row in at_limit.checks)


@pytest.mark.parametrize('key,value',[('anchor_washer_t',float('nan')),('anchor_washer_side',float('inf')),
                                    ('anchor_washer_t',True),('anchor_washer_t',0.),
                                    ('anchor_washer_side',-1.),('anchor_shear_model','unknown'),
                                    ('anchor_washer_t',1e308)])
def test_invalid_native_inputs_do_not_calculate(key,value):
    r=evaluate(replace(BASE,**{key:value}))
    assert not r.geometry and not r.checks
    assert r.component_status=='DADOS OU GEOMETRIA INVÁLIDOS'


@pytest.mark.parametrize('changes,check',[({'anchor_washer_t':6.35},'bp_anchor_washer_thickness'),
                                        ({'anchor_washer_side':50.},'bp_anchor_washer_side'),
                                        ({'anchor_washer_side':100.},'bp_anchor_washer_fit'),
                                        ({'anchor_washer_side':110.},'bp_anchor_washer_fit')])
def test_nonconforming_details_remain_calculable_but_cannot_pass(changes,check):
    r=evaluate(replace(BASE,**changes))
    assert r.geometry and r.geometry['anchor_shear']
    assert not next(row for row in r.checks if row.id==check).passed
    assert 'NÃO ATENDE' in r.status


def test_actual_plate_and_washer_thicknesses_reduce_capacity_but_not_weld_target():
    base=evaluate(BASE).geometry['anchor_shear']
    for c in (replace(BASE,tp=38.1),replace(BASE,anchor_washer_t=19.05)):
        ash=evaluate(c).geometry['anchor_shear']
        assert ash['alpha']>base['alpha']
        assert ash['group_rd']<base['group_rd']
        assert ash['weld_force_per_washer']==base['weld_force_per_washer']
    assert evaluate(replace(BASE,grout_t=60.)).geometry['anchor_shear']==base


def test_negative_fictitious_rod_tension_is_rejected_by_kernel():
    a=reactions(BASE);a['Ft_min']=-1
    ash=anchor_shear_actions(BASE,a)
    assert not ash['domain_ok'] and ash['group_rd']==0

FIXTURES=json.loads((Path(__file__).parent/'fixtures'/'anchor_native_benchmarks.json').read_text())

@pytest.mark.parametrize('row',[r for r in FIXTURES['fixtures'] if 'inputs' in r],ids=lambda row:row['id'])
def test_independent_55_digit_decimal_fixtures(row):
    p=row['inputs']
    c=replace(BASE,tp=p['tp'],db=p['db'],anchor_washer_t=p['ta'],fck=p['fck'],**row['loads'])
    r=evaluate(c);ash=r.geometry['anchor_shear']
    assert ash['alpha']==pytest.approx(row['alpha'],rel=1e-12)
    assert ash['shear_unreduced_rd']==pytest.approx(row['Fv_Rd'],rel=1e-12)
    assert ash['tension_rd']==pytest.approx(row['Ft_Rd'],rel=1e-12)
    assert ash['concrete_cap']==pytest.approx(row['Vcap_per_rod'],rel=1e-12)
    assert ash['group_rd']==pytest.approx(row['V_Rd_allowed'],abs=1e-7,rel=1e-12)
    assert ash['subtractive_tension']==pytest.approx(row['final_term_tension'],abs=1e-7)
    for got,expected in zip(ash['rods'],row['rods']):
        assert got['tension']==pytest.approx(expected['Ft'],abs=1e-7)
        assert got['steel_rd']==pytest.approx(expected['conservative_final_term_Ft_max'],abs=1e-7,rel=1e-12)
        assert got['combined_rd']==pytest.approx(expected['direct_interaction_cap'],abs=1e-7,rel=1e-12)
        assert got['rd']==pytest.approx(expected['allowed'],abs=1e-7,rel=1e-12)
    assert ash['weld_force_per_washer']==pytest.approx(row['weld_required_per_rod'],rel=1e-12)
