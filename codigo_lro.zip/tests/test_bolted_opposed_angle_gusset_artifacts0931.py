"""Current-input opposed topology, editable report and lossless envelopes."""
from copy import deepcopy
from dataclasses import replace
from io import BytesIO
import math
import matplotlib.pyplot as plt
import pytest
from docx import Document
from lro.bolted_opposed_angle_gusset import BoltedOpposedAngleGusset, evaluate, presets
from lro.bolted_opposed_angle_gusset_drawing import figure, drawing_svg, image_bytes, input_fingerprint
from lro.bolted_opposed_angle_gusset_presentation import physical_envelopes, concise_memory
from lro.bolted_opposed_angle_gusset_report import create_report


def fixture(**changes):return replace(next(iter(presets().values())),**changes)


def artists(fig):
    return ({x.get_gid():x for ax in fig.axes for x in ax.patches if x.get_gid()},
            {x.get_gid():x for ax in fig.axes for x in ax.lines if x.get_gid()})


def document(blob):
    doc=Document(BytesIO(blob))
    return doc,'\n'.join(p.text for p in doc.paragraphs)+'\n'+'\n'.join(cell.text for table in doc.tables for row in table.rows for cell in row.cells)


@pytest.mark.parametrize('n',[2,3,5])
def test_physical_two_row_bolts_one_plane_each_and_one_double_root(n):
    c=fixture(n=n,plate_height=450.,center_n=210.,plate_width=380.) if n==5 else fixture(n=n)
    r=evaluate(c);fig=figure(c)
    try:
        patches,lines=artists(fig)
        assert r['geometry']['valid']
        holes={k:v for k,v in patches.items() if k.startswith('physical_hole_')}
        bolts={k:v for k,v in patches.items() if k.startswith('physical_bolt_')}
        assert len(holes)==len(bolts)==2*c.n
        for i,point in enumerate(r['geometry']['bolt_centers']):
            assert holes[f'physical_hole_{i+1}'].center==pytest.approx(point)
            assert holes[f'physical_hole_{i+1}'].radius==c.hole_diameter/2
            assert bolts[f'physical_bolt_{i+1}'].radius==c.db/2
        for row,sign in enumerate((-1,1)):
            shaft=patches[f'single_shear_bolt_shaft_row_{row}']
            assert shaft.get_x()+shaft.get_width()/2==pytest.approx(sign*(c.plate_t/2+c.gauge))
            assert shaft.get_height()==pytest.approx(c.plate_t+r['geometry']['angle_section']['t']+c.washer_stack+10)
            plane=lines[f'shear_plane_row_{row}']
            assert all(z==sign*c.plate_t/2 for z in plane.get_ydata())
        assert len([k for k in lines if k.startswith('shear_plane_row_')])==2
        assert 'through_bolt_shaft' not in patches
        assert len([k for k in patches if k.startswith('root_fillet_')])==2
        assert patches['root_single_gusset'].get_width()==c.plate_t
        assert all(ax.get_aspect()==1 for ax in fig.axes)
    finally:plt.close(fig)


def test_opposed_contours_have_opposite_heel_and_leg_coordinates():
    c=fixture();fig=figure(c)
    try:
        patches,lines=artists(fig)
        p=lines['angle_outer_free_leg_face_positive'];n=lines['angle_outer_free_leg_face_negative']
        assert p.get_xdata()==pytest.approx(-n.get_xdata())
        assert p.get_ydata()==pytest.approx(-n.get_ydata())
        assert p.get_xdata()[0]==c.plate_t/2
        assert 'nominal_connected_inner_face_positive_0' in lines
        assert 'nominal_connected_inner_face_negative_0' in lines
        assert not any(k.startswith('angle_section_face_') for k in patches)
        svg=drawing_svg(c)
        assert 'unpublished_heel_face_positive' in svg
        assert '6 parafusos físicos' in svg and '1 plano por parafuso' in svg
        assert 'Raios não publicados' in svg and '12,35 mm' in svg
    finally:plt.close(fig)


@pytest.mark.parametrize('theta,member',[(80.,'beam'),(90.,'column'),(100.,'beam')])
def test_variable_angle_signed_common_root(theta,member):
    c=fixture(theta_deg=theta,support_member=member);r=evaluate(c);fig=figure(c)
    try:
        patches,lines=artists(fig)
        assert patches['brace_angle_arc'].theta2==theta
        root_x=c.center_s-c.center_n/math.tan(math.radians(theta))
        assert lines['nominal_force_line'].get_xdata()[0]==pytest.approx(root_x)
        assert r['root']['M']==pytest.approx(r['root']['N']*root_x,abs=1e-6)
        svg=drawing_svg(c)
        assert ('PILAR W' if member=='column' else 'VIGA W') in svg
    finally:plt.close(fig)


def test_report_recalculates_and_describes_revised_method_and_diagnostics():
    c=fixture(plate_width=300.,N=100000.);r=evaluate(c)
    assert r['global_pass']
    forged=deepcopy(r);forged['status']='FORGED_PASS'
    doc,text=document(create_report(c,forged))
    assert 'FORGED_PASS' not in text
    assert input_fingerprint(c) in text
    assert len(doc.inline_shapes)==1 and doc.element.xpath('.//m:oMath') and doc.element.xpath('.//m:rad')
    for term in ('2n parafusos distintos','um único plano','N/(2n)','tg+tL','N/2 por L','45 kN aplica-se uma vez',
                 'diagnóstico informativo','ligamento íntegro','tg/2','n²','3q','Ant = 0','Cinco registros',
                 'não é raio','Mcentroide=Mraiz','B300 H300','não prova cancelamento'):
        searchable=text+'\n'+''.join(doc.element.xpath('.//m:t/text()'))
        assert term.casefold() in searchable.casefold(),term
    assert 'Fora desta família: par de vértices opostos' not in text
    assert 'Esta triagem deve permanecer tracionada' not in text
    assert image_bytes(c).startswith(b'\x89PNG')


def test_detail_preserves_all_check_ids_and_case_record_keys():
    c=fixture(minimum_force=False);r=evaluate(c);_,text=document(create_report(c,detailed=True))
    for row in r['checks']:assert row['id'] in text
    for case in r['cases']:
        for key in case:assert key in text,key
    assert 'Testemunhos integrais dos casos' in text


def test_compact_memory_and_envelopes_remain_current_and_lossless():
    c=fixture(N=0.);r=evaluate(c);before=deepcopy(r);env=physical_envelopes(r)
    assert sorted(x['id'] for e in env for x in e['members'])==sorted(x['id'] for x in r['checks'])
    assert all(e['actual_utilization']==0 for e in env)
    assert any(e['utilization']>0 for e in env)
    for e in env:
        assert e['utilization']==max(x['utilization'] for x in e['members'])
        assert set(e['governing_ids'])=={x['id'] for x in e['members'] if x['utilization']==e['utilization']}
    env[0]['members'][0]['id']='mutated';assert r==before
    mc=concise_memory(c)
    assert 'N total=0 kN' in mc and '6 parafusos físicos' in mc and 'SHA-256' in mc
    assert 'diagnóstico informativo' in mc
    svg=drawing_svg(c)
    assert 'actual_force_arrow' not in svg and 'gusset_hole_force_' not in svg


def test_current_invalid_geometry_does_not_export_previous_physical_view():
    c=fixture(plate_width=-1.)
    svg=drawing_svg(c,evaluate(fixture()))
    assert 'diagnostic_only' in svg and 'physical_hole_1' not in svg


def test_physical_force_basis_does_not_merge_allocated_plate_with_aggregate():
    env=physical_envelopes(evaluate(fixture()))
    contact=[e for e in env if e['mechanism']=='bearing']
    assert len(contact)==4
    assert all(e['load_basis']=='per_physical_bolt' and 'N/(2n)' in e['force_scope'] for e in contact)
    whit=[e for e in env if e['mechanism'] in ('Whitmore_yield','Whitmore_net')]
    assert len(whit)==6
    assert len([e for e in whit if e['load_basis']=='total'])==2
    allocated=[e for e in whit if e['load_basis']=='per_row_half_thickness']
    assert len(allocated)==4 and {e['row'] for e in allocated}=={0,1}
    assert all('tg/2' in e['force_scope'] and 'N/2' in e['force_scope'] for e in allocated)
    blocks=[e for e in env if e['component']=='gusset' and e['mechanism']=='block_tearout']
    assert blocks and all(e['load_basis']=='captured_group' for e in blocks)


@pytest.mark.parametrize('n',[2,3,5])
@pytest.mark.parametrize('theta',[80.,90.,100.])
def test_axis_reference_label_never_hides_physical_bolts(n,theta):
    c=fixture(n=n,theta_deg=theta,**({'plate_height':450.,'center_n':210.,'plate_width':380.} if n==5 else {}))
    fig=figure(c)
    try:
        fig.canvas.draw();ax=fig.axes[0];renderer=fig.canvas.get_renderer()
        label=next(x for x in ax.texts if x.get_gid()=='reference_axis_label')
        bbox=label.get_window_extent(renderer)
        for patch in ax.patches:
            if (patch.get_gid() or '').startswith('physical_bolt_'):
                assert not bbox.overlaps(patch.get_window_extent(renderer)),patch.get_gid()
    finally:plt.close(fig)


def test_expanded_audit_table_uses_same_physical_force_scopes():
    from lro.bolted_angle_gusset_ui import _checks_table
    r=evaluate(fixture());frame=_checks_table(r['checks'],opposed=True)
    basis={item['id']:e['force_scope'] for e in physical_envelopes(r) for item in e['members']}
    assert frame['Base da força'].tolist()==[basis[x['id']] for x in r['checks']]
    assert all(isinstance(x,str) for x in frame['Face / plano'])
