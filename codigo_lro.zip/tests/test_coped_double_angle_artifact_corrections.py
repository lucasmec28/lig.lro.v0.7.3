"""Bounded R017 correction contract: canonical artifacts and lossless envelopes."""
from copy import deepcopy
from dataclasses import replace
from io import BytesIO
from zipfile import ZipFile
import xml.etree.ElementTree as ET

import pytest

from lro.coped_double_angle import evaluate, presets
from lro.coped_double_angle_drawing import drawing_svg, image_bytes, validated_result
from lro.coped_double_angle_report import create_report
from lro.coped_double_angle_presentation import physical_envelopes, component_label, governing_description


def fixture(**changes):
    c = next(iter(presets().values()))
    c = replace(c, restraint_top_system='Travamento superior externo', restraint_top_ref='MC-TOP',
                restraint_top_x=c.gap+c.c_top, restraint_bottom_system='Travamento inferior externo',
                restraint_bottom_ref='MC-BOTTOM', restraint_bottom_x=c.gap+c.c_bottom)
    return replace(c, **changes)


def word_text(data):
    with ZipFile(BytesIO(data)) as archive:
        return '\n'.join(ET.fromstring(archive.read('word/document.xml')).itertext())


def supplied_result(c, kind):
    if kind == 'absent':
        return None
    if kind == 'incomplete':
        return {'local_pass': True, 'status': 'COMPLETE_LOCAL_CHECKS_PASS_WITHIN_SCOPE'}
    if kind == 'stale':
        return evaluate(fixture(V=100000., project='Outro projeto'))
    r = evaluate(c)
    if kind == 'tampered':
        r['local_pass'] = True; r['status'] = 'COMPLETE_LOCAL_CHECKS_PASS_WITHIN_SCOPE'; r['issues'] = []
        r['summary']['complete_checks'] = True
        for row in r['checks']:
            row['status'] = row['actual_status'] = 'PASS'
    return r


@pytest.mark.parametrize('kind', ['absent', 'stale', 'incomplete', 'tampered', 'canonical'])
def test_exports_recalculate_ordinary_500kn_failure(kind, monkeypatch):
    c = fixture(V=500000.)
    supplied = supplied_result(c, kind); before = deepcopy(supplied)
    canonical = evaluate(c)
    assert validated_result(c, supplied) == canonical
    svg = drawing_svg(c, supplied)
    assert 'HÁ VERIFICAÇÃO NÃO ATENDIDA' in svg and 'SEM APROVAÇÃO LOCAL' in svg
    assert 'VERIFICAÇÕES LOCAIS ATENDIDAS NO DOMÍNIO R017' not in svg
    text = word_text(create_report(c, supplied))
    assert 'Há verificação resistente não atendida' in text and 'sim, no domínio' not in text
    assert 'Não há aprovação local da ligação' in text
    assert 'Verificação global dos membros: EXTERNA' in text
    for row in canonical['checks']:
        assert row['id'] in text and row['formula'] in text and row['reference'] in text
    assert supplied == before
    # PNG has the same canonical figure path, not caller-supplied status.
    import lro.coped_double_angle_drawing as drawing
    figures = []; old_close = drawing.plt.close
    def capture(fig):
        if hasattr(fig, 'texts'):
            figures.append(fig)
        old_close(fig)
    monkeypatch.setattr(drawing.plt, 'close', capture)
    assert image_bytes(c, supplied).startswith(b'\x89PNG')
    labels = [x.get_text() for x in figures[-1].texts]
    assert 'HÁ VERIFICAÇÃO NÃO ATENDIDA' in labels


@pytest.mark.parametrize('V', [100000., -100000., 0., 1000., -1000., 500000., -500000.])
def test_22_envelopes_preserve_every_id_maximum_tie_failure_and_units(V):
    r = evaluate(fixture(V=V)); before = deepcopy(r)
    envelopes = physical_envelopes(r)
    assert len(envelopes) == 22
    ids = [row['id'] for row in r['checks']]
    members = [identifier for group in envelopes for identifier in group['member_ids']]
    assert len(members) == len(set(members)) == len(ids) and set(members) == set(ids)
    for group in envelopes:
        assert group['units'] == 'N'
        assert group['members'] == [row for row in r['checks'] if row['id'] in group['member_ids']]
        for case, utilization, state in [('actual', 'actual_utilization', 'actual_status'), ('adopted', 'utilization', 'status')]:
            maximum = max(row[utilization] for row in group['members'])
            assert group[case+'_utilization'] == maximum
            assert [row['id'] for row in group[case+'_governing_ties']] == [row['id'] for row in group['members'] if row[utilization] == maximum]
            failures = [row['id'] for row in group['members'] if row[state] == 'FAIL']
            assert group[case+'_failure_ids'] == failures
            assert group[case+'_failure_count'] == len(failures)
            witness = group[case+'_governing']
            assert not any(token in governing_description(witness) for token in ('negative', 'positive', 'PASS', 'FAIL', 'direction_independent'))
            for key, value in next(row for row in r['checks'] if row['id'] == witness['id']).items():
                assert witness[key] == value
        assert 'soldada' not in group['component_label']
    assert max(group['actual_utilization'] for group in envelopes) == max(row['actual_utilization'] for row in r['checks'])
    assert max(group['adopted_utilization'] for group in envelopes) == max(row['utilization'] for row in r['checks'])
    assert r == before


def test_support_web_both_columns_sum_and_zero_branches_remain_distinct():
    r = evaluate(fixture(V=0.)); envelopes = physical_envelopes(r)
    support = next(group for group in envelopes if group['component'] == 'support_web')
    assert len(support['members']) == 22
    assert any('support_web_negative' in row['id'] for row in support['members'])
    assert any('support_web_positive' in row['id'] for row in support['members'])
    for sign, value in [('pos', 1), ('neg', -1)]:
        row = next(row for row in support['actual_governing_ties'] if row['id'] == 'support_web_total_V'+sign+'_bearing_group')
        assert row['case']['branch_direction_sign'] == value
        assert row['case']['signed_total_action_cases_N'] == [0.]
        assert 'sem força real' in governing_description(row)
    bolt = next(group for group in envelopes if group['id'] == 'bolt_shared_web')
    assert bolt['adopted_governing']['case']['signed_total_action_cases_N'] == [45000., -45000.]
    assert bolt['actual_governing']['case']['signed_total_action_cases_N'] == [0.]


def test_domain_omission_and_restraint_condition_never_invent_approval():
    r = evaluate(fixture(c_bottom=150.))
    ids = {group['id'] for group in physical_envelopes(r)}
    assert 'cope_complementary_stability' not in ids and not r['local_pass']
    r = evaluate(fixture(restraint_top_ref=''))
    stability = next(group for group in physical_envelopes(r) if group['id'] == 'cope_complementary_stability')
    assert stability['conditional_on_external_restraints']
    assert stability['external_restraints_qualified'] is False
    assert 'comprovação externa pendente' in stability['restraint_condition']
    assert 'superior' in stability['restraint_condition']


def test_word_has_own_bolted_labels_full_checks_and_22_envelopes():
    c = fixture(); r = evaluate(c); text = word_text(create_report(c))
    assert '22 envelopes' in text
    for side in ['negative', 'positive']:
        for leg in ['beam', 'support']:
            assert component_label(f'angle_{side}_{leg}') in text
    assert 'aba soldada' not in text and 'grupo de solda' not in text
    assert 'Parafusos comuns da viga · corte duplo' in text
    assert 'Alma única de apoio · duas colunas físicas' in text
    assert 'não contém tabela métrica de e/s' in text
    for row in r['checks']:
        assert row['id'] in text and row['formula'] in text and row['reference'] in text


def test_svg_identity_and_signed_actions_are_separate_from_hypothesis():
    c = fixture(project='PROJETO R017 AÇÕES ASSINADAS', V=-23456.789012345,
                N=1234.56789012, M=-345678.9012345, torsion=456789.0123456)
    svg = drawing_svg(c)
    text = '\n'.join(ET.fromstring(svg).itertext())
    assert c.project in text and 'Ações reais informadas' in text
    for name, value, unit in [('V', c.V, 'N'), ('N', c.N, 'N'), ('M', c.M, 'N mm'), ('T', c.torsion, 'N mm')]:
        assert f'{name}={value:+.12g} {unit}' in text
    assert 'Hipótese do modelo local: somente V estático; N=M=T=0' in text
    assert 'FORA DO DOMÍNIO R017' in text and 'SEM APROVAÇÃO LOCAL' in text


def test_derived_numeric_failure_can_be_exported_without_approval():
    c = fixture(V=1e308); r = evaluate(c)
    assert r['status'] == 'NUMERICAL_FAILURE'
    assert physical_envelopes(r) == []
    assert 'FALHA NUMÉRICA' in drawing_svg(c)
    text = word_text(create_report(c))
    assert 'Falha numérica' in text and 'Nenhum envelope resistente disponível' in text
    assert 'sim, no domínio' not in text


def test_table16_word_marks_qualified_exception_without_changing_25mm():
    c = fixture(gap=20., restraint_top_x=150.)
    r = evaluate(c)
    check = next(x for x in r['geometry']['checks'] if x['id'] == 'beam_end_min')
    assert check['actual'] == 25. and check['limit'] == 26.
    assert check['qualification'] == 'TABLE16_EXCEPTION_VERIFIED'
    text = word_text(create_report(c))
    assert 'Atende por exceção verificada da nota da Tabela 16' in text
    assert 'table16_exceptions.beam_end_min' in text
    for key in ('beam_web_Vpos_bearing_hole1', 'beam_web_Vpos_block_k4'):
        assert key in text
