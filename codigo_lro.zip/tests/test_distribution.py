"""Regressão dos erros recebidos no deploy, sem alterar critérios de cálculo."""
import hashlib
import json
from pathlib import Path

from streamlit.testing.v1 import AppTest
from verificar_pacote import verify

ROOT = Path(__file__).resolve().parents[1]


def test_pending_notice_and_word_use_origin_label():
    at = AppTest.from_file(str(ROOT / 'app.py'), default_timeout=45).run()
    at.checkbox(key='norm_minimum').uncheck().run()
    assert not at.exception
    assert any('Configuração:' in item.value for item in at.warning)
    next(item for item in at.button if item.label == 'Gerar memória Word').click().run()
    assert not at.exception
    assert at.session_state['report'][2][:2] == b'PK'


def test_incomplete_upload_shows_recovery_before_import(tmp_path):
    (tmp_path / 'app.py').write_bytes((ROOT / 'app.py').read_bytes())
    at = AppTest.from_file(str(tmp_path / 'app.py'), default_timeout=30).run()
    assert not at.exception
    assert any('Instalação incompleta' in item.value for item in at.error)
    assert any('lro/double_cover_ui.py' in item.value and
               'lro/end_plate_ui.py' in item.value for item in at.code)
    assert not at.selectbox
    assert any('lro/corner_compression.py' in item.value for item in at.code)


def test_manifest_detects_missing_and_mixed_files_but_accepts_crlf(tmp_path):
    data = b'original\n'
    (tmp_path / 'docs').mkdir()
    (tmp_path / 'docs/release_manifest.json').write_text(json.dumps({'files': [
        {'path': name, 'sha256': hashlib.sha256(data).hexdigest(),
         'sha256_lf': hashlib.sha256(data).hexdigest()}
        for name in ('app.py', 'missing.py', 'different.py')]}))
    (tmp_path / 'app.py').write_bytes(b'original\r\n')
    (tmp_path / 'different.py').write_bytes(b'old version\n')
    assert verify(tmp_path) == ['Ausente: missing.py', 'Diferente do pacote: different.py']


def test_missing_manifest_is_reported(tmp_path):
    assert verify(tmp_path)[0].startswith('Manifesto indisponível ou inválido:')

def test_new_upper_washer_modules_are_guarded_before_import(tmp_path):
    (tmp_path / 'app.py').write_bytes((ROOT / 'app.py').read_bytes())
    at=AppTest.from_file(str(tmp_path/'app.py'),default_timeout=30).run()
    assert not at.exception
    for name in ('upper_washer','upper_washer_ui','upper_washer_artifacts'):
        assert any('lro/'+name+'.py' in item.value for item in at.code)
