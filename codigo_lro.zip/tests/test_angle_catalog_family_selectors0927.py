"""Exact catalog loading, manual provenance, compatibility, and UI persistence."""
from copy import deepcopy
from dataclasses import asdict, replace
import importlib
from pathlib import Path

import pytest
from streamlit.testing.v1 import AppTest

from lro.angle_catalog import catalog
from lro.angle_catalog_selection import METADATA_FIELDS, missing_data_errors, provenance_text
from lro import angle_catalog_ui

CONFIGS = [
    ('axial_single_angle', 'AxialSingleAngle', 'as_', 1),
    ('axial_double_angle', 'AxialDoubleAngle', 'ad_', 2),
    ('double_angle', 'DoubleAngle', 'da_', 0),
    ('coped_double_angle', 'CopedDoubleAngle', 'ca_', 0),
    ('welded_double_angle', 'WeldedDoubleAngle', 'wa_', 0),
]
RECORDS = list(catalog().values())


def base(module):
    return next(iter(importlib.import_module('lro.' + module).presets().values()))


def select_state(monkeypatch, config, record):
    module, _, prefix, factor = config
    initial = base(module)
    state = {prefix + k: v for k, v in asdict(initial).items()}
    monkeypatch.setattr(angle_catalog_ui.st, 'session_state', state)
    state[prefix + 'angle_catalog_id'] = record['id']
    angle_catalog_ui.changed(prefix, factor or 1, bool(factor))
    values = {field: state[prefix + field] for field in asdict(initial)}
    # Beam/support objects never belong to catalog angle updates.
    for field in ('beam', 'support'):
        if hasattr(initial, field):
            values[field] = getattr(initial, field)
    return initial, type(initial)(**values), state


@pytest.mark.parametrize('config', CONFIGS, ids=[row[0] for row in CONFIGS])
@pytest.mark.parametrize('record', RECORDS, ids=[row['id'] for row in RECORDS])
def test_all_50_entries_load_exact_geometry_without_material_or_radius_borrowing(monkeypatch, config, record):
    initial, chosen, state = select_state(monkeypatch, config, record)
    _, _, prefix, factor = config
    assert chosen.angle_steel == initial.angle_steel
    assert chosen.t == record['t']
    assert chosen.root_radius == 0
    assert chosen.angle_root_source == '' and not chosen.angle_root_confirmed
    if factor:
        assert chosen.leg == record['leg']
        assert chosen.Ag == (factor * record['Ag'] if record['Ag'] is not None else 0)
        assert chosen.ec == (record['centroid'] if record['centroid'] is not None else 0)
        assert chosen.profile_source == record['source']
    else:
        assert chosen.beam_leg == chosen.support_leg == record['leg']
    result = importlib.import_module('lro.' + config[0]).evaluate(chosen)
    assert not result['global_pass'] and not result['checks']
    assert result['status'] == 'INVALID_INPUT'
    state[prefix + 'angle_catalog_id'] = ''
    angle_catalog_ui.changed(prefix, factor or 1, bool(factor))
    for field in angle_catalog_ui._geometry_fields(bool(factor)):
        assert state[prefix + field] == getattr(initial, field)
    assert state[prefix + 'angle_steel'] == initial.angle_steel


@pytest.mark.parametrize('config', CONFIGS, ids=[row[0] for row in CONFIGS])
def test_native_legacy_and_catalog_roundtrip_and_forged_identity(monkeypatch, config):
    module, _, _, factor = config
    initial, chosen, _ = select_state(monkeypatch, config, RECORDS[20])
    native = initial.to_dict()
    legacy = deepcopy(native)
    for key in METADATA_FIELDS:
        legacy['connection'].pop(key, None)
    restored = type(initial).from_dict(legacy)
    for key, value in legacy['connection'].items():
        assert restored.to_dict()['connection'][key] == value
    assert restored == initial
    partial = deepcopy(native)
    partial['connection'].pop('angle_root_source')
    with pytest.raises(ValueError):
        type(initial).from_dict(partial)
    chosen = replace(chosen, root_radius=5.5, angle_root_source='Desenho do perfil adquirido P-123', angle_root_confirmed=True)
    assert not missing_data_errors(chosen)
    assert type(chosen).from_dict(chosen.to_dict()) == chosen
    assert chosen.angle_catalog_id in provenance_text(chosen) or 'Gerdau' in provenance_text(chosen)
    with pytest.raises(ValueError, match='catálogo Gerdau'):
        replace(chosen, t=chosen.t + .01).to_dict()
    if factor:
        with pytest.raises(ValueError, match='catálogo Gerdau'):
            replace(chosen, Ag=chosen.Ag + 1).to_dict()
    else:
        with pytest.raises(ValueError, match='catálogo Gerdau'):
            replace(chosen, support_leg=chosen.support_leg + .01).to_dict()


@pytest.mark.parametrize('config', CONFIGS, ids=[row[0] for row in CONFIGS])
def test_excluded_missing_property_rows_never_become_an_operational_identity(config):
    initial = base(config[0])
    for identity in ('GERDAU_EQUAL_ANGLE_P03_R01', 'GERDAU_EQUAL_ANGLE_P03_R02'):
        assert identity not in catalog()
        with pytest.raises(ValueError, match='não reconhecido'):
            replace(initial, angle_catalog_id=identity).to_dict()


RUNNER = """
import importlib
import streamlit as st
families = ['axial_single_angle', 'axial_double_angle', 'double_angle', 'coped_double_angle', 'welded_double_angle', 'Other']
family = st.selectbox('Família', families, key='connection_family')
if family != 'Other':
    importlib.import_module('lro.' + family + '_ui').render()
"""


def app(config):
    at = AppTest.from_string(RUNNER, default_timeout=60)
    at.session_state['connection_family'] = config[0]
    return at.run()


@pytest.mark.parametrize('config', CONFIGS, ids=[row[0] for row in CONFIGS])
def test_streamlit_selector_navigation_manual_restore_and_qualified_declarations(config):
    module, _, prefix, factor = config
    at = app(config)
    assert not at.exception
    initial = base(module)
    leg = 'leg' if factor else 'beam_leg'
    at.number_input(key=prefix + leg).set_value(82.125).run()
    if factor:
        at.number_input(key=prefix + 'Ag').set_value(999.75 * factor).run()
    record = next(row for row in RECORDS if row['leg'] >= 63.5)
    selector = at.selectbox(key=prefix + 'angle_catalog_id')
    assert len(selector.options) == 1 + sum(row['leg'] >= 63.5 for row in RECORDS)
    selector.set_value(record['id']).run()
    assert not at.exception
    assert at.number_input(key=prefix + leg).value == record['leg']
    assert at.number_input(key=prefix + 't').value == record['t']
    assert at.number_input(key=prefix + 'root_radius').value == 0
    assert not at.success
    assert at.session_state[prefix + 'angle_steel'] == initial.angle_steel
    at.number_input(key=prefix + 'root_radius').set_value(5.5)
    at.text_input(key=prefix + 'angle_root_source').set_value('Medição documentada P-123')
    at.checkbox(key=prefix + 'angle_root_confirmed').check().run()
    assert not at.exception
    saved = deepcopy(at.session_state['_' + module + '_project'])
    assert saved['connection']['angle_catalog_id'] == record['id']
    at.selectbox(key='connection_family').set_value('Other').run()
    at.selectbox(key='connection_family').set_value(module).run()
    assert not at.exception
    assert at.session_state['_' + module + '_project'] == saved
    assert at.selectbox(key=prefix + 'angle_catalog_id').value == record['id']
    at.selectbox(key=prefix + 'angle_catalog_id').set_value('').run()
    assert not at.exception
    assert at.number_input(key=prefix + leg).value == 82.125
    if factor:
        assert at.number_input(key=prefix + 'Ag').value == 999.75 * factor
    assert at.number_input(key=prefix + 'root_radius').value == initial.root_radius
    assert at.session_state[prefix + 'angle_steel'] == initial.angle_steel


def test_streamlit_rare_sizes_filter_and_selected_small_profile_survive():
    config = CONFIGS[0]
    at = app(config)
    assert not at.checkbox(key='as_angle_show_small').value
    at.checkbox(key='as_angle_show_small').check().run()
    assert len(at.selectbox(key='as_angle_catalog_id').options) == 51
    record = RECORDS[0]
    at.selectbox(key='as_angle_catalog_id').set_value(record['id']).run()
    at.checkbox(key='as_angle_show_small').uncheck().run()
    assert not at.exception
    assert at.selectbox(key='as_angle_catalog_id').value == record['id']
    assert at.number_input(key='as_leg').value == record['leg']
    assert at.number_input(key='as_Ag').value == record['Ag']
    assert at.number_input(key='as_ec').value == record['centroid']
    assert len(at.selectbox(key='as_angle_catalog_id').options) == 2 + sum(row['leg'] >= 63.5 for row in RECORDS)

@pytest.mark.parametrize('config', CONFIGS, ids=[row[0] for row in CONFIGS])
def test_selected_small_native_import_is_visible_without_filter_or_geometry_rewrite(monkeypatch, config):
    # Build through the pure selection callback, then restore real Streamlit
    # before opening AppTest so this also exercises the production import path.
    with monkeypatch.context() as patch:
        _, chosen, _ = select_state(patch, config, RECORDS[0])
    chosen = replace(chosen, root_radius=1., angle_root_source='Medição independente registrada', angle_root_confirmed=True)
    native = chosen.to_dict()
    at = app(config)
    import json
    at.get('file_uploader')[0].upload('catalogo.json', json.dumps(native).encode(), 'application/json').run()
    next(widget for widget in at.button if widget.label.startswith('Carregar ')).click().run()
    assert not at.exception
    assert at.session_state['_' + config[0] + '_project'] == native
    assert at.selectbox(key=config[2] + 'angle_catalog_id').value == RECORDS[0]['id']
    assert at.checkbox(key=config[2] + 'angle_show_small').value is False
    assert len(at.selectbox(key=config[2] + 'angle_catalog_id').options) == 2 + sum(row['leg'] >= 63.5 for row in RECORDS)


def test_zero_radius_cannot_be_mislabeled_as_confirmed_physical_geometry(monkeypatch):
    _, chosen, _ = select_state(monkeypatch, CONFIGS[0], RECORDS[20])
    chosen = replace(chosen, angle_root_source='Referência declarada', angle_root_confirmed=True)
    assert missing_data_errors(chosen)
    assert importlib.import_module('lro.axial_single_angle').evaluate(chosen)['status'] == 'INVALID_INPUT'


def test_resolved_row46_uses_published_area_without_anomaly_banner(monkeypatch):
    row = catalog()['GERDAU_EQUAL_ANGLE_P03_R46']
    assert row['Ag'] == 2696. and not row['review_flags']
    for config in CONFIGS[:2]:
        _, chosen, _ = select_state(monkeypatch, config, row)
        assert chosen.Ag == row['Ag'] * config[3]
        assert chosen.N == base(config[0]).N
        assert '2696' in str(chosen.Ag) or config[3] == 2
        assert 'peso próprio' in provenance_text(chosen)

@pytest.mark.parametrize('config', CONFIGS[:2], ids=[row[0] for row in CONFIGS[:2]])
def test_imported_catalog_to_manual_clears_producer_claims_without_changing_numbers(monkeypatch, config):
    with monkeypatch.context() as patch:
        _, chosen, _ = select_state(patch, config, RECORDS[20])
    prefix = config[2]
    state = {prefix + key: value for key, value in asdict(chosen).items()}
    monkeypatch.setattr(angle_catalog_ui.st, 'session_state', state)
    angle_catalog_ui.reset(prefix)
    state[prefix + 'angle_catalog_id'] = ''
    angle_catalog_ui.changed(prefix, config[3], True)
    for field in ('leg', 't', 'Ag', 'ec', 'root_radius'):
        assert state[prefix + field] == getattr(chosen, field)
    assert 'manual' in state[prefix + 'profile_name'].lower()
    assert 'Gerdau' not in state[prefix + 'profile_source']
    assert 'Gerdau' not in state[prefix + 'profile_name']
    assert not state[prefix + 'angle_root_confirmed']


@pytest.mark.parametrize('module', ('double_angle', 'coped_double_angle', 'welded_double_angle', 'axial_single_angle', 'axial_double_angle'))
def test_catalog_drawing_footer_is_complete_visible_and_rejects_false_identity(module):
    import matplotlib.pyplot as plt
    drawing = importlib.import_module('lro.' + module + '_drawing')
    row = next(record for record in RECORDS if record['leg'] == 76.2 and record['t'] == 6.35)
    initial = base(module)
    shape = ({'leg': row['leg'], 'Ag': row['Ag'] * (2 if module == 'axial_double_angle' else 1),
              'ec': row['centroid']} if module.startswith('axial_')
             else {'beam_leg': row['leg'], 'support_leg': row['leg']})
    c = replace(initial, **shape, t=row['t'], root_radius=6.,
                angle_catalog_id=row['id'], angle_root_source='Desenho técnico independente P-123', angle_root_confirmed=True)
    fig = drawing._figure(c)
    try:
        fig.canvas.draw()
        renderer = fig.canvas.get_renderer()
        footer = next(text for text in fig.texts if text.get_gid() == 'angle_catalog_provenance')
        bounds = footer.get_window_extent(renderer)
        assert bounds.x0 >= 0 and bounds.y0 >= 0
        assert bounds.x1 <= fig.bbox.width and bounds.y1 <= fig.bbox.height
        for text in fig.texts:
            if text is not footer:
                assert text.get_window_extent(renderer).y0 > bounds.y1
        assert row['id'] in footer.get_text()
        assert 'página física 3' in footer.get_text()
        assert 'não publicado pela Gerdau' in footer.get_text()
        assert c.angle_root_source in footer.get_text()
    finally:
        plt.close(fig)
    with pytest.raises(ValueError, match='catálogo Gerdau'):
        drawing.drawing_svg(replace(c, t=c.t + .1))
    plt.close('all')
