"""Actual Streamlit reruns and atomic native imports across three bolted branches."""
from copy import deepcopy
from dataclasses import replace
import json
from pathlib import Path
import pytest
from streamlit.runtime.memory_media_file_storage import MemoryMediaFileStorage
from streamlit.testing.v1 import AppTest
from lro.bolted_angle_gusset import BoltedAngleGusset, presets as old_presets
from lro.bolted_opposed_angle_gusset import BoltedOpposedAngleGusset, evaluate, presets
from lro.bolted_angle_gusset_ui import PROJECT,RESULT,DRAFT,REPORT,TEMPLATE,ACCEPTED,decode_project,checks_complete

RUNNER='from lro.bolted_angle_gusset_ui import render\nrender()'


@pytest.fixture
def media(monkeypatch):
    files={};original=MemoryMediaFileStorage.load_and_get_id
    def tap(storage,*args,**kwargs):
        identity=original(storage,*args,**kwargs);files[identity]=storage._files_by_id[identity].content;return identity
    monkeypatch.setattr(MemoryMediaFileStorage,'load_and_get_id',tap);return files


def fixture(**changes):return replace(next(iter(presets().values())),**changes)


def fresh(c=None):
    at=AppTest.from_string(RUNNER,default_timeout=180);at.session_state[PROJECT]=(c or fixture()).to_dict();at.run()
    assert not at.exception;return at


def button(at,text):return next(x for x in at.button if x.label==text)


def download(at,media,text):
    item=next(x for x in at.get('download_button') if x.label==text)
    return media[Path(item.proto.url).name.rsplit('.',1)[0]]


def upload(at,payload):
    if not isinstance(payload,bytes):payload=json.dumps(payload,ensure_ascii=False).encode()
    at.get('file_uploader')[0].upload('native.json',payload,'application/json').run()
    button(at,'Carregar projeto completo parafusado').click().run();assert not at.exception


def test_opposed_native_current_downloads_summary_and_word(media):
    c=fixture();at=fresh(c)
    assert at.session_state[PROJECT]==c.to_dict() and at.session_state[RESULT]==evaluate(c)
    assert checks_complete(at.session_state[RESULT]) and at.session_state[RESULT]['global_pass']
    assert decode_project(download(at,media,'Salvar projeto completo parafusado .json'))==c
    assert '2n' in at.number_input(key='bag_n').label
    result=json.loads(download(at,media,'Baixar resultados completos parafusados .json'))
    assert result=={'input':c.to_dict(),'result':at.session_state[RESULT]}
    assert download(at,media,'Baixar desenho completo parafusado .png').startswith(b'\x89PNG')
    svg=download(at,media,'Baixar desenho completo parafusado .svg')
    assert b'physical_hole_6' in svg and b'single_shear_bolt_shaft_row_1' in svg
    mc=next(x for x in at.code if '2L opostas >< parafusadas' in x.value)
    assert '6 parafusos físicos' in mc.value and 'diagnóstico informativo' in mc.value
    button(at,'Gerar memória completa parafusada').click().run()
    assert download(at,media,'Baixar memória completa parafusada .docx').startswith(b'PK')


def test_three_way_arrangement_switch_and_old_native_payloads():
    at=fresh();before=deepcopy(at.session_state[PROJECT])
    for arrangement in ('1L','2L-T','2L-opposed'):
        at.selectbox(key='bag_arrangement').set_value(arrangement).run();assert not at.exception
        native=at.session_state[PROJECT]
        assert native['connection']['arrangement']==arrangement
        assert native['connection_type']==('bolted_opposed_angle_gusset' if arrangement=='2L-opposed' else 'bolted_angle_gusset')
        assert decode_project(json.dumps(native))== (BoltedOpposedAngleGusset if arrangement=='2L-opposed' else BoltedAngleGusset).from_dict(native)
    assert at.session_state[PROJECT]==before
    for c in (next(iter(old_presets().values())),replace(next(iter(old_presets().values())),arrangement='1L')):
        upload(at,c.to_dict());assert at.session_state[PROJECT]==c.to_dict()
    upload(at,before);assert at.session_state[PROJECT]==before


@pytest.mark.parametrize('corrupt',['identity','assumption','unknown','missing','nan','duplicate'])
def test_rejected_opposed_import_is_atomic(corrupt):
    at=fresh();button(at,'Gerar memória completa parafusada').click().run()
    saved={key:deepcopy(at.session_state[key]) for key in (PROJECT,RESULT,DRAFT,REPORT,TEMPLATE,ACCEPTED)}
    bad=deepcopy(saved[PROJECT])
    if corrupt=='identity':bad['connection_type']='bolted_angle_gusset'
    elif corrupt=='assumption':bad['fixed_assumptions']['physical_shear_planes']=2
    elif corrupt=='unknown':bad['connection']['filler']=1
    elif corrupt=='missing':bad['connection'].pop('heel_extent')
    elif corrupt=='nan':bad['connection']['theta_deg']=float('nan')
    else:bad=json.dumps(bad).replace('"connection": {','"connection": {"N": 1,').encode()
    upload(at,bad)
    assert any('Não foi possível abrir' in x.value for x in at.error)
    for key,value in saved.items():assert at.session_state[key]==value,key


def test_actual_heel_pending_material_separation_and_stale_report_retirement():
    at=fresh(BoltedOpposedAngleGusset())
    assert not at.session_state[RESULT]['global_pass']
    assert at.number_input(key='bag_heel_extent').value is None
    assert not any('heel' in str(x.key) for x in at.checkbox)
    at.number_input(key='bag_heel_extent').set_value(12.35).run()
    at.text_input(key='bag_heel_extent_source').set_value('Dimensão medida na peça').run()
    assert at.session_state[RESULT]['global_pass']
    button(at,'Gerar memória completa parafusada').click().run();assert REPORT in at.session_state
    old=deepcopy(at.session_state[PROJECT]['connection'])
    at.selectbox(key='bag_gusset_steel').set_value('ASTM A572 Gr.50').run()
    assert REPORT not in at.session_state
    now=at.session_state[PROJECT]['connection']
    for k in ('angle_steel','support_steel','bolt','root_electrode'):assert now[k]==old[k]
    at.number_input(key='bag_theta_deg').set_value(50.).run()
    assert not at.session_state[RESULT]['global_pass']
    at.number_input(key='bag_theta_deg').set_value(80.).run()
    assert at.session_state[RESULT]['global_pass']
