"""Actual isolated 1L UI, native artifacts, atomic imports and 1L/2L state isolation."""
from copy import deepcopy
from dataclasses import replace
import json
from pathlib import Path

import pytest
from streamlit.runtime.memory_media_file_storage import MemoryMediaFileStorage
from streamlit.testing.v1 import AppTest

from lro.axial_single_angle import AxialSingleAngle, FAMILY, evaluate
from lro.axial_double_angle import AxialDoubleAngle, FAMILY as DOUBLE_FAMILY
from lro.axial_single_angle_ui import checks_complete, decode_project, import_ui_values

PROJECT = '_axial_single_angle_project'
RESULT = '_axial_single_angle_result'
DRAFT = '_axial_single_angle_ui_draft'
DOUBLE_PROJECT = '_axial_double_angle_project'
DOUBLE_RESULT = '_axial_double_angle_result'
# Exercise the production renderers without coupling tests to the catalog ordering.
RUNNER = '''
import streamlit as st
from lro.axial_single_angle import FAMILY as SINGLE_FAMILY
from lro.axial_double_angle import FAMILY as DOUBLE_FAMILY
from lro.axial_single_angle_ui import render as render_single
from lro.axial_double_angle_ui import render as render_double
family = st.selectbox('Família de ensaio', [SINGLE_FAMILY, DOUBLE_FAMILY], key='test_family')
if family == SINGLE_FAMILY:
    render_single()
else:
    render_double()
'''


@pytest.fixture
def media(monkeypatch):
    files = {}
    original = MemoryMediaFileStorage.load_and_get_id
    def tap(storage, *args, **kwargs):
        file_id = original(storage, *args, **kwargs)
        files[file_id] = storage._files_by_id[file_id].content
        return file_id
    monkeypatch.setattr(MemoryMediaFileStorage, 'load_and_get_id', tap)
    return files


def fresh():
    at = AppTest.from_string(RUNNER, default_timeout=90).run()
    assert not at.exception
    return at


def button(at, label):
    return next(item for item in at.button if item.label == label)


def download(at, media, label):
    item = next(item for item in at.get('download_button') if item.label == label)
    return media[Path(item.proto.url).name.rsplit('.', 1)[0]]


def text(at):
    return '\n'.join(str(item.value) for kind in ('caption', 'info', 'warning', 'error', 'success', 'markdown')
                     for item in getattr(at, kind))


def upload(at, payload):
    if not isinstance(payload, bytes):
        payload = json.dumps(payload, allow_nan=True).encode()
    at.get('file_uploader')[0].upload('axial-1L-native.json', payload, 'application/json').run()
    button(at, 'Carregar 1L axial').click().run()
    assert not at.exception


def test_default_is_one_angle_one_plane_full_force_with_explicit_provenance(media):
    at = fresh()
    c = AxialSingleAngle.from_dict(at.session_state[PROJECT])
    r = at.session_state[RESULT]
    assert (c.angle_count, c.Ag, c.ec, c.N) == (1, 929., 21.3, 100000.)
    assert (c.root_radius, c.tool_radius, c.fabrication_clearance) == (6., 18., 2.)
    assert c.threads_excluded is False
    assert r == evaluate(c) and checks_complete(r) and r['global_pass'] is True
    assert r['summary']['utilization'] == pytest.approx(.6432630913120067)
    assert set(r['sections']) >= {'angle', 'plate'}
    assert 'angle_pair' not in r['sections']
    checkbox_keys = {item.key for item in at.checkbox}
    assert {key for key in checkbox_keys if 'threads' in key} == {'as_threads_excluded'}
    assert not {'as_symmetric', 'as_threads_excluded_1', 'as_threads_excluded_2'} & checkbox_keys
    numeric_keys = {item.key for item in at.number_input}
    assert {'as_N_kN', 'as_n', 'as_gauge', 'as_angle_end', 'as_plate_end'} <= numeric_keys
    assert not {'as_bolt_x', 'as_terminal_x', 'as_hole_diameter', 'as_grip'} & numeric_keys
    shown = text(at)
    for words in ('6.1.8.2', '6.5.2', 'M=0', 'PDF 162', 'PDF 160', '929', '6,35', '6,3',
                  'não se recalculam', 'não são verificados', 'não se cancela', '-13.700', '27.550',
                  '21.300', 'permanece ativo no Ct', '9.425', 'exatamente um plano', 'N integral'):
        assert words in shown
    assert json.loads(download(at, media, 'Salvar projeto 1L axial .json')) == c.to_dict()
    assert download(at, media, 'Baixar desenho 1L axial .png').startswith(b'\x89PNG')
    assert b'<svg' in download(at, media, 'Baixar desenho 1L axial .svg')
    assert any(item.label == 'Todas as verificações primitivas e caminhos físicos' for item in at.expander)


def test_same_geometry_at_200_kn_visibly_fails_and_invalidates_report(media):
    at = fresh()
    button(at, 'Gerar memória 1L axial').click().run()
    assert at.session_state.as_report[2].startswith(b'PK')
    before = deepcopy(at.session_state[PROJECT]['connection'])
    at.number_input(key='as_N_kN').set_value(200.).run()
    assert not at.exception
    after = at.session_state[PROJECT]['connection']
    assert after == dict(before, N=200000.)
    r = at.session_state[RESULT]
    assert not r['global_pass'] and checks_complete(r)
    assert r['summary']['utilization'] == pytest.approx(1.2865261826240134)
    assert not at.success and 'NÃO ATENDE ÀS VERIFICAÇÕES REALIZADAS' in text(at)
    failed = [row for row in r['checks'] if row['status'] == 'FAIL' and row['case_id'] == 'actual']
    assert any(row['component'] == 'angle' for row in failed)
    assert any(row['mechanism'] == 'bolt_shear' for row in failed)
    assert 'as_report' not in at.session_state
    assert not any(item.label == 'Baixar memória 1L axial .docx' for item in at.get('download_button'))
    # Coherent geometry with real resistance failures is reportable, never green.
    assert not button(at, 'Gerar memória 1L axial').disabled
    button(at, 'Gerar memória 1L axial').click().run()
    assert download(at, media, 'Baixar memória 1L axial .docx').startswith(b'PK')


def test_zero_actual_separate_policies_and_native_roundtrip(media):
    at = fresh()
    c = replace(AxialSingleAngle(), project='1L · zero real e políticas', N=0., recommend_half_capacity=True,
                Ag=951.75, ec=22.125, profile_source='Propriedades fornecidas para este ensaio')
    upload(at, c.to_dict())
    assert 'as_import_error' not in at.session_state
    assert at.session_state[PROJECT] == c.to_dict()
    cases = at.session_state[RESULT]['cases']
    assert len(cases) == 3
    assert next(case['N'] for case in cases if case['id'] == 'actual') == 0
    assert sum(case['N'] == 45000 for case in cases) == 1
    assert at.number_input(key='as_N_kN').value == 0
    assert at.number_input(key='as_Ag').value == c.Ag
    assert at.number_input(key='as_ec').value == c.ec
    payload = download(at, media, 'Salvar projeto 1L axial .json')
    assert decode_project(payload) == c
    at.run()
    assert download(at, media, 'Salvar projeto 1L axial .json') == payload


@pytest.mark.parametrize('corrupt', ['unknown', 'missing', 'boolean_numeric', 'nonfinite', 'duplicate',
                                     'wrong_family', 'actual_cg', 'mixed_planes', 'second_thread_plane'])
def test_rejected_import_is_atomic_and_preserves_current_report(media, corrupt):
    at = fresh()
    at.text_input(key='as_project').set_value('1L protegida').run()
    button(at, 'Gerar memória 1L axial').click().run()
    assert not at.exception
    original = deepcopy(at.session_state[PROJECT])
    draft = deepcopy(at.session_state[DRAFT])
    report = at.session_state.as_report
    bad = deepcopy(original)
    if corrupt == 'unknown':
        bad['unrecognized'] = 1
    elif corrupt == 'missing':
        bad['connection'].pop('ec')
    elif corrupt == 'boolean_numeric':
        bad['connection']['Ag'] = True
    elif corrupt == 'nonfinite':
        bad['connection']['N'] = float('nan')
    elif corrupt == 'duplicate':
        bad = json.dumps(bad).replace('"connection": {', '"connection": {"N": 1,').encode()
    elif corrupt == 'wrong_family':
        bad = AxialDoubleAngle().to_dict()
    elif corrupt == 'actual_cg':
        bad['fixed_assumptions']['load_model'] = 'actual_physical_CG'
    elif corrupt == 'mixed_planes':
        bad['fixed_assumptions']['shear_planes'] = 2
    else:
        bad['connection']['threads_excluded_2'] = True
    upload(at, bad)
    assert 'Não foi possível abrir' in text(at)
    assert at.session_state[PROJECT] == original
    assert at.session_state[DRAFT] == draft
    assert at.session_state.as_report == report
    assert json.loads(download(at, media, 'Salvar projeto 1L axial .json')) == original


def test_single_and_double_angle_edits_threads_reports_and_drafts_are_isolated(media):
    at = fresh()
    at.number_input(key='as_Ag').set_value(955.25)
    at.number_input(key='as_ec').set_value(22.75)
    at.checkbox(key='as_threads_excluded').check()
    at.text_input(key='as_profile_source').set_value('Fonte específica 1L').run()
    button(at, 'Gerar memória 1L axial').click().run()
    single = deepcopy(at.session_state[PROJECT])
    single_report = at.session_state.as_report
    at.selectbox(key='test_family').set_value(DOUBLE_FAMILY).run()
    assert not at.exception
    assert at.session_state[DOUBLE_PROJECT] == AxialDoubleAngle().to_dict()
    assert at.checkbox(key='ad_threads_excluded_1').value is False
    assert at.checkbox(key='ad_threads_excluded_2').value is False
    at.number_input(key='ad_Ag').set_value(1901.75)
    at.checkbox(key='ad_threads_excluded_2').check()
    at.text_input(key='ad_profile_source').set_value('Fonte específica 2L').run()
    button(at, 'Gerar memória 2L axial').click().run()
    double = deepcopy(at.session_state[DOUBLE_PROJECT])
    double_result = deepcopy(at.session_state[DOUBLE_RESULT])
    double_report = at.session_state.ad_report
    at.selectbox(key='test_family').set_value(FAMILY).run()
    assert not at.exception and at.session_state[PROJECT] == single
    assert at.session_state.as_report == single_report
    assert at.checkbox(key='as_threads_excluded').value is True
    assert at.number_input(key='as_Ag').value == 955.25
    assert json.loads(download(at, media, 'Salvar projeto 1L axial .json')) == single
    at.number_input(key='as_pitch').set_value(0.).run()
    assert not at.exception and button(at, 'Gerar memória 1L axial').disabled
    draft = deepcopy(at.session_state[DRAFT])
    at.selectbox(key='test_family').set_value(DOUBLE_FAMILY).run()
    assert at.session_state[DOUBLE_PROJECT] == double
    assert at.session_state[DOUBLE_RESULT] == double_result
    assert at.session_state.ad_report == double_report
    assert at.checkbox(key='ad_threads_excluded_1').value is False
    assert at.checkbox(key='ad_threads_excluded_2').value is True
    assert json.loads(download(at, media, 'Salvar projeto 2L axial .json')) == double
    at.selectbox(key='test_family').set_value(FAMILY).run()
    assert not at.exception and at.number_input(key='as_pitch').value == 0.
    assert at.session_state[DRAFT] == draft
    assert button(at, 'Gerar memória 1L axial').disabled
    assert 'as_report' not in at.session_state


def test_numeric_overflow_clears_prior_outputs_and_recovers_current_input(media):
    at = fresh()
    button(at, 'Gerar memória 1L axial').click().run()
    assert at.session_state.as_report[2].startswith(b'PK')
    at.number_input(key='as_N_kN').set_value(1e308).run()
    assert not at.exception
    assert at.session_state[RESULT]['status'] == 'NUMERICAL_FAILURE'
    assert not at.session_state[RESULT]['checks']
    assert PROJECT not in at.session_state and 'as_report' not in at.session_state
    assert not at.get('download_button')
    assert button(at, 'Gerar memória 1L axial').disabled
    assert 'Nenhum resultado ou arquivo anterior é válido' in text(at)
    at.number_input(key='as_N_kN').set_value(100.).run()
    assert not at.exception and at.session_state[RESULT]['global_pass'] is True
    assert at.session_state[PROJECT]['connection']['N'] == 100000.
    assert not button(at, 'Gerar memória 1L axial').disabled
    assert 'as_report' not in at.session_state


def test_import_force_precision_and_unit_underflow_rejection():
    c = replace(AxialSingleAngle(), N=123456.78901234567)
    values = import_ui_values(c)
    assert values['as_N'] == c.N
    assert values['as_N_kN'] == c.N / 1000.
    with pytest.raises(ValueError, match='conversão de unidade'):
        import_ui_values(replace(c, N=5e-324))


def test_zero_actual_cannot_disable_minimum_but_input_remains_recoverable():
    at = fresh()
    c = replace(AxialSingleAngle(), N=0., minimum_force=False)
    upload(at, c.to_dict())
    assert at.session_state[PROJECT] == c.to_dict()
    assert at.session_state[RESULT]['status'].startswith('OUTSIDE')
    assert at.session_state[RESULT]['global_pass'] is False and not at.success
    assert button(at, 'Gerar memória 1L axial').disabled
    at.checkbox(key='as_minimum_force').check().run()
    assert not at.exception and at.session_state[PROJECT]['connection']['N'] == 0
    assert any(case['N'] == 45000 for case in at.session_state[RESULT]['cases'])
    assert not button(at, 'Gerar memória 1L axial').disabled



def test_live_single_plane_and_physical_offsets_follow_current_edits():
    at = fresh()
    initial = deepcopy(at.session_state[RESULT])
    at.checkbox(key='as_threads_excluded').check().run()
    threaded = [row for row in initial['checks'] if row['mechanism'] == 'bolt_shear']
    unthreaded = [row for row in at.session_state[RESULT]['checks'] if row['mechanism'] == 'bolt_shear']
    assert len(threaded) == len(unthreaded) == 3
    for before, after in zip(threaded, unthreaded):
        assert after['resistance'] == pytest.approx(before['resistance'] * .56 / .45)
        assert after['demand'] == before['demand']
        assert after['id'].split('__')[0].endswith('_plane_1')
    at.number_input(key='as_plate_t').set_value(20.).run()
    assert not at.exception
    c = AxialSingleAngle.from_dict(at.session_state[PROJECT])
    assert c.Ag == 929. and c.N == 100000. and c.plate_t == 20.
    assert '31.300 mm' in text(at) and '-13.700 mm' in text(at)
    assert '13.175 mm' in text(at)
    at.number_input(key='as_gauge').set_value(36.).run()
    assert not at.exception and '-14.700 mm' in text(at)
