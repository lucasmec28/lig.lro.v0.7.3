"""Independent R017 drawing geometry and conservative artifact-status checks."""
from copy import deepcopy
from dataclasses import asdict, replace
import xml.etree.ElementTree as ET

import matplotlib.pyplot as plt
from matplotlib.path import Path
import numpy as np
import pytest

from lro.coped_double_angle import presets
from lro.coped_double_angle_drawing import drawing_svg, image_bytes, validated_result


def fixture(**changes):
    return replace(next(iter(presets().values())), **changes)


def capture(monkeypatch, c, r=None):
    import lro.coped_double_angle_drawing as drawing
    figures = []
    close = drawing.plt.close
    def remember(fig):
        if hasattr(fig, 'axes'):
            figures.append(fig)
        close(fig)
    monkeypatch.setattr(drawing.plt, 'close', remember)
    svg = drawing_svg(c, r)
    fig = figures[-1]
    patches = {p.get_gid(): p for ax in fig.axes for p in ax.patches if p.get_gid()}
    lines = {p.get_gid(): p for ax in fig.axes for p in ax.lines if p.get_gid()}
    return svg, fig, patches, lines


def diagnostic_pass(c):
    return dict(inputs=asdict(c), status='COMPLETE_LOCAL_CHECKS_PASS_WITHIN_SCOPE',
        local_pass=True, global_pass=False, member_global_status='EXTERNAL_NOT_EVALUATED',
        checks=[{'status': 'PASS'}], geometry={'valid': True}, summary={'complete_checks': True}, issues=[])


def test_three_views_two_physical_Ls_and_one_actual_support_web(monkeypatch):
    c = fixture()
    svg, fig, patches, lines = capture(monkeypatch, c)
    assert len(fig.axes) == 3
    for code, sign in (('A1', -1), ('A2', 1)):
        p = patches[f'angle_{code}_L_plan'].get_path()
        assert min(p.vertices[:, 0]) == 0
        assert max(p.vertices[:, 0]) == c.beam_leg
        assert min(sign*p.vertices[:, 1]) == c.beam.tw/2
        assert max(sign*p.vertices[:, 1]) == c.beam.tw/2+c.support_leg
        assert p.codes[-1] == Path.CLOSEPOLY
        assert sum(p.codes == Path.CURVE4) >= 3
    support = patches['support_web_plan']
    assert support.get_x() == -c.support.tw
    assert support.get_width() == c.support.tw
    assert patches['beam_web_plan'].get_x() == c.gap
    assert patches['beam_web_plan'].get_height() == c.beam.tw
    assert len([k for k in lines if k.startswith('web_shear_plane_')]) == 2
    assert len([k for k in lines if k.startswith('support_shear_plane_')]) == 2
    assert not any('column' in k or 'rear_flange_plan' in k or 'front_flange_plan' in k for k in patches)
    assert 'alma da viga de apoio' in svg and 'mesa do pilar' not in svg


def test_copecuts_have_actual_lengths_depths_and_tangent_R15_arcs(monkeypatch):
    c = fixture(gap=13., c_top=137., c_bottom=152., dc_top=36., dc_bottom=41., r_top=15., r_bottom=18.)
    svg, fig, p, lines = capture(monkeypatch, c)
    top = c.beam.d/2
    bottom = -top
    upper = p['cope_top_radius_elevation'].get_path()
    lower = p['cope_bottom_radius_elevation'].get_path()
    np.testing.assert_allclose(upper.vertices[0], (13+137-15, top-36), atol=1e-10)
    np.testing.assert_allclose(upper.vertices[-1], (13+137, top-36+15), atol=1e-10)
    np.testing.assert_allclose(lower.vertices[0], (13+152, bottom+41-18), atol=1e-10)
    np.testing.assert_allclose(lower.vertices[-1], (13+152-18, bottom+41), atol=1e-10)
    assert all(code == Path.CURVE4 for code in upper.codes[1:])
    assert all(code == Path.CURVE4 for code in lower.codes[1:])
    # Tangents are genuinely horizontal/vertical, rather than diagonal chamfers.
    assert upper.vertices[0, 1] == pytest.approx(upper.vertices[1, 1])
    assert upper.vertices[-1, 0] == pytest.approx(upper.vertices[-2, 0])
    assert lower.vertices[0, 0] == pytest.approx(lower.vertices[1, 0])
    assert lower.vertices[-1, 1] == pytest.approx(lower.vertices[-2, 1])
    assert p['beam_top_flange_elevation'].get_x() == 150.
    assert p['beam_bottom_flange_elevation'].get_x() == 165.
    assert p['beam_coped_end_front'].get_y() == bottom+41
    assert p['beam_coped_end_front'].get_height() == c.beam.d-36-41
    assert 'c sup = 137' in svg and 'c inf = 152' in svg and 'R15' in svg and 'R18' in svg


def test_support_is_perpendicular_girder_with_horizontal_continuous_flanges(monkeypatch):
    c = fixture(beam_level=27.)
    svg, fig, p, lines = capture(monkeypatch, c)
    top = c.beam.d/2+c.beam_level
    assert p['support_top_flange_elevation'].get_y() == top-c.support.tf
    assert p['support_bottom_flange_elevation'].get_y() == top-c.support.d
    assert p['support_web_elevation'].get_width() == c.support.tw
    for side in ('top', 'bottom'):
        f = p[f'support_{side}_flange_front']
        assert f.get_height() == c.support.tf
        assert f.get_width() > c.support.bf
        for edge in ('inner', 'outer'):
            line = lines[f'support_{side}_flange_{edge}_continuous']
            assert len(set(line.get_ydata())) == 1
    assert {'support_span_crop_left', 'support_span_crop_right'}.issubset(lines)
    assert 'support_front_real_edges' not in p
    assert 'Mesas contínuas; comprimento do apoio interrompido.' in svg
    assert 'support_edge_top' not in svg and 'support_edge_bottom' not in svg
    assert 'nível = 27' in svg
    mid = top-c.support.d/2
    assert list(lines['support_root_envelope_top'].get_ydata()) == [mid+c.support.clear/2]*2
    assert list(lines['support_root_envelope_bottom'].get_ydata()) == [mid-c.support.clear/2]*2
    assert lines['support_root_envelope_top'].get_linestyle() == ':'


def test_plan_ghosts_only_actual_flange_footprints_after_each_cope(monkeypatch):
    c = fixture(c_top=121., c_bottom=175.)
    svg, fig, p, lines = capture(monkeypatch, c)
    footprint = p['support_flange_footprint_plan']
    assert footprint.get_x() == -(c.support.bf+c.support.tw)/2
    assert footprint.get_width() == c.support.bf
    assert footprint.get_alpha() < .5
    for suffix in ('top', 'bottom'):
        flange = p[f'beam_{suffix}_flange_footprint_plan']
        assert flange.get_x() == c.gap+getattr(c, 'c_'+suffix)
        assert flange.get_height() == c.beam.bf
        assert flange.get_linestyle() == '--'
    assert 'Mesas da viga após os recortes' in svg


def test_independent_hole_patterns_and_shared_double_shear_stack(monkeypatch):
    c = fixture(web_rows=3, support_rows=4, web_pitch=68., support_pitch=57.,
        web_end_top=44., support_end_top=39., beam_gauge=49., support_gauge=51.)
    svg, fig, p, lines = capture(monkeypatch, c)
    y0 = c.beam.d/2-c.angle_top
    web = [v for k, v in p.items() if k.startswith('web_hole_elevation_')]
    assert len(web) == 3
    assert {h.center[0] for h in web} == {49.}
    assert sorted(h.center[1] for h in web) == sorted(y0-44-i*68 for i in range(3))
    for code, sign in (('A1', -1), ('A2', 1)):
        holes = [v for k, v in p.items() if k.startswith('support_hole_'+code+'_')]
        assert len(holes) == 4
        assert {h.center[0] for h in holes} == {sign*(c.beam.tw/2+51)}
        assert sorted(h.center[1] for h in holes) == sorted(y0-39-i*57 for i in range(4))
        assert {h.radius for h in holes} == {c.hole_diameter/2}
        bolt = lines[f'support_bolt_{code}_plan']
        assert list(bolt.get_xdata()) == [-c.support.tw-8, c.t+8]
        assert bolt.get_linestyle() == '--'
    assert list(lines['shared_web_bolt_plan'].get_xdata()) == [49., 49.]
    assert 'projetados de outra cota' in svg
    assert '3 parafusos comuns, 2 planos de corte.' in svg
    assert '2 × 4 parafusos, 1 plano por parafuso.' in svg


@pytest.mark.parametrize('V, gid', [(100000., 'load_V_positive_down'), (-100000., 'load_V_negative_up')])
def test_force_sign_reverses_arrow(monkeypatch, V, gid):
    svg, fig, p, lines = capture(monkeypatch, fixture(V=V))
    arrows = [a for ax in fig.axes for a in ax.texts if a.get_gid() == gid]
    assert len(arrows) == 1
    assert (arrows[0].xy[1] < arrows[0].xyann[1]) == (V > 0)


def test_zero_force_does_not_invent_arrow(monkeypatch):
    svg, fig, p, lines = capture(monkeypatch, fixture(V=0.))
    assert not [a for ax in fig.axes for a in ax.texts if str(a.get_gid()).startswith('load_V_')]


@pytest.mark.parametrize('changes', [{'angle_count': 1}, {'angle_count': 3}, {'symmetric': False},
    {'kind': 'column_flange'}, {'web_columns': 2}, {'support_columns': 2},
    {'support_intact': False}, {'cope': 'single_top'}])
def test_unsupported_topology_is_diagnostic_not_invented_pair(monkeypatch, changes):
    c = fixture(**changes)
    svg, fig, p, lines = capture(monkeypatch, c)
    assert 'TOPOLOGIA NÃO REPRESENTADA' in svg
    assert not fig.axes and not p and not lines
    assert f'{c.angle_count} cantoneira(s)' in svg


@pytest.mark.parametrize('changes', [{'r_top': 70.}, {'dc_top': 400.}, {'root_radius': 100.}])
def test_impossible_geometry_is_not_silently_clamped(monkeypatch, changes):
    svg, fig, p, lines = capture(monkeypatch, fixture(**changes))
    assert 'GEOMETRIA NÃO REPRESENTADA' in svg
    assert not p and not lines


@pytest.mark.parametrize('changes', [{'gap': float('nan')}, {'c_top': 0.}, {'web_rows': 3.5},
    {'V': True}, {'V': float('inf')}, {'beam_level': float('nan')}, {'support_rows': False}])
def test_unsafe_dimensions_are_rejected(changes):
    with pytest.raises(ValueError):
        image_bytes(fixture(**changes))


def test_result_geometry_never_overwrites_drawing_input(monkeypatch):
    c = fixture(c_top=149., support_gauge=53.)
    r = {'status': 'INVALID_GEOMETRY', 'geometry': {'c_top': 999., 'support_gauge': 2.}}
    svg, fig, p, lines = capture(monkeypatch, c, r)
    assert p['beam_top_flange_elevation'].get_x() == c.gap+149.
    assert p['support_hole_A2_0'].center[0] == c.beam.tw/2+53.
    assert 'SEM APROVAÇÃO LOCAL' in svg


@pytest.mark.parametrize('change', [{'V': -50000.}, {'c_top': 150.}, {'notes': 'revision'}, {'symmetric': 1}])
def test_stale_input_binding_recalculated(change):
    c = fixture()
    r = diagnostic_pass(c)
    from lro.coped_double_angle import evaluate
    current = replace(c, **change)
    svg = drawing_svg(current, r)
    assert 'engine_status_' + evaluate(current)['status'] in svg
    assert 'SEM APROVAÇÃO LOCAL' in svg


def test_local_acceptance_never_claims_global_member_approval():
    c = fixture(restraint_top_system='Travamento externo', restraint_top_ref='MC-TOP', restraint_top_x=140.)
    svg = drawing_svg(c, diagnostic_pass(c))
    assert 'ATENDIMENTO LOCAL R017' in svg
    assert 'VERIFICAÇÕES LOCAIS ATENDIDAS NO DOMÍNIO R017' in svg
    assert 'VERIFICAÇÃO GLOBAL DOS MEMBROS EXTERNA À LIGAÇÃO' in svg
    assert 'SEM APROVAÇÃO LOCAL' not in svg


@pytest.mark.parametrize('corruption', ['unbound', 'empty_checks', 'pending_issue', 'false_local', 'invalid_geometry', 'wrong_status'])
def test_incomplete_or_unbound_result_cannot_approve(corruption):
    c = fixture()
    r = diagnostic_pass(c)
    if corruption == 'unbound':
        r.pop('inputs')
    elif corruption == 'empty_checks':
        r['checks'] = []
    elif corruption == 'pending_issue':
        r['issues'] = [{'severity': 'engineering_pending'}]
    elif corruption == 'false_local':
        r['local_pass'] = False
    elif corruption == 'invalid_geometry':
        r['geometry']['valid'] = False
    elif corruption == 'wrong_status':
        r['status'] = 'ENGINEERING_MODEL_PENDING'
    r['global_pass'] = True
    before = deepcopy(r)
    svg = drawing_svg(c, r)
    assert 'SEM APROVAÇÃO LOCAL' in svg
    assert 'VERIFICAÇÕES LOCAIS ATENDIDAS NO DOMÍNIO R017' not in svg
    assert r == before


def test_validation_accepts_bound_nonfinite_diagnostic_without_drawing_it():
    c = fixture(c_top=float('nan'))
    snapshot = asdict(c)
    snapshot['c_top'] = 'nan'
    r = {'inputs': snapshot, 'status': 'INVALID_INPUT'}
    actual = validated_result(c, r)
    assert actual['status'] == 'INVALID_INPUT' and actual['inputs'] == snapshot
    assert actual is not r


def test_png_svg_formats_and_no_figure_leak():
    c = fixture()
    initial = set(plt.get_fignums())
    assert image_bytes(c).startswith(b'\x89PNG\r\n\x1a\n')
    assert ET.fromstring(drawing_svg(c)).tag.endswith('svg')
    assert set(plt.get_fignums()) == initial


def test_real_engine_result_binding_and_local_status_are_compatible():
    from lro.coped_double_angle import evaluate
    c = fixture()
    assert 'SEM APROVAÇÃO LOCAL' in drawing_svg(c, evaluate(c))
    c = replace(c, restraint_top_system='Contenção externa qualificada',
        restraint_top_ref='TEST-REST-TOP', restraint_top_x=c.gap+c.c_top,
        restraint_bottom_system='Contenção externa qualificada',
        restraint_bottom_ref='TEST-REST-BOTTOM', restraint_bottom_x=c.gap+c.c_bottom)
    r = evaluate(c)
    assert r['local_pass'] is True and r['global_pass'] is False
    assert 'VERIFICAÇÕES LOCAIS ATENDIDAS NO DOMÍNIO R017' in drawing_svg(c, r)
