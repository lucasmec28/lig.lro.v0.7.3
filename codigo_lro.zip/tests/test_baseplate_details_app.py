from dataclasses import replace
from pathlib import Path
import json,math
import pytest
from streamlit.testing.v1 import AppTest
from lro.base_plate import BasePlate,presets,evaluate

APP=Path(__file__).resolve().parents[1]/'app.py'
FAMILY='Placa de base · engastada'
def button(at,label):return next(x for x in at.button if x.label==label)
def open_app():
    at=AppTest.from_file(str(APP),default_timeout=60).run()
    at.selectbox(key='connection_family').set_value(FAMILY).run()
    assert not at.exception
    return at

def current(at):return BasePlate.from_dict(at.session_state['_base_plate_project'])


def test_independent_welds_conversion_switching_hidden_state_and_family():
    at=open_app()
    at.selectbox(key='bp_weld_web_type').set_value('fillet').run()
    at.number_input(key='bp_weld_web_size').set_value(8.).run()
    at.selectbox(key='bp_weld_web_measure').set_value('throat').run()
    assert current(at).weld_web_size==pytest.approx(8/math.sqrt(2))
    at.selectbox(key='bp_weld_flange_type').set_value('cjp').run()
    at.selectbox(key='bp_weld_web_type').set_value('cjp').run()
    at.selectbox(key='connection_family').set_value('Single plate').run()
    at.selectbox(key='connection_family').set_value(FAMILY).run()
    at.selectbox(key='bp_weld_web_type').set_value('fillet').run()
    assert current(at).weld_web_size==pytest.approx(8/math.sqrt(2))
    assert current(at).weld_web_measure=='throat' and current(at).weld_flange_type=='cjp'
    at.selectbox(key='bp_weld_web_measure').set_value('leg').run()
    assert current(at).weld_web_size==pytest.approx(8.)
    assert not at.exception


def test_cone_roundtrip_and_changed_data_clear_report():
    at=open_app()
    c=replace(presets()['T2 · tração e pequeno momento'],base_fixity='pinned',M=-5e6,
              cone_model='aci318_19',anchor_type='buried_plate_nut',anchor_detail_confirmed=True,
              anchor_detail_ref='AN01',weld_web_type='fillet',weld_web_measure='throat',weld_web_size=4.,
              weld_flange_type='cjp',stiffener_detail='web_pair')
    raw=json.dumps(c.to_dict()).encode()
    for _ in range(2):
        at.get('file_uploader')[0].upload('new.json',raw,'application/json').run()
        button(at,'Abrir placa de base JSON').click().run()
        assert not at.exception
        loaded=current(at)
        assert loaded==c
        assert type(loaded.anchor_detail_confirmed) is bool
        assert evaluate(loaded).geometry['concrete_cone']['status']=='calculated'
    button(at,'Gerar memória da placa de base').click().run()
    assert not at.exception and at.session_state['bp_report'][2][:2]==b'PK'
    at.number_input(key='bp_hef').set_value(280.).run()
    assert 'bp_report' not in at.session_state
    at.selectbox(key='bp_cone_model').set_value('off').run()
    at.selectbox(key='bp_anchor_type').set_value('unspecified').run()
    at.selectbox(key='connection_family').set_value('Single plate').run()
    at.selectbox(key='connection_family').set_value(FAMILY).run()
    at.selectbox(key='bp_anchor_type').set_value('buried_plate_nut').run()
    assert current(at).hef==280 and current(at).M==c.M
    assert current(at).anchor_detail_confirmed is True
    assert not at.exception


def test_cone_pending_does_not_block_word_or_legacy_steel():
    at=open_app()
    at.selectbox(key='bp_cone_model').set_value('aci318_19').run()
    c=current(at);r=evaluate(c)
    assert r.geometry['concrete_cone']['status']=='pending'
    assert any('DADOS PENDENTES' in x.value for x in at.warning)
    button(at,'Gerar memória da placa de base').click().run()
    assert not at.exception and at.session_state['bp_report'][2][:2]==b'PK'
