"""Artefatos nativos das quatro arruelas, sem perder a rota externa legada."""
from dataclasses import replace
from io import BytesIO
import json
import zipfile
import xml.etree.ElementTree as ET

import pytest

from lro.models import Profile
from lro.base_plate import BasePlate, evaluate, detail_reference
from lro.base_plate_drawing import image_bytes
from lro.base_plate_report import create_report


P = Profile('I 300 × 150', 'Soldado', 40., 300., 150., 8., 12., 276., 7008.)


def fixture(**kwargs):
    c = BasePlate(P, a1=50., a2=140., db=19.05, tp=31.75,
                  N=-40000., M=4e6, V=10000., fck=30., grout_t=35.,
                  shear_path='anchors', anchor_shear_model='welded_washer',
                  anchor_washer_t=9.525, anchor_washer_side=65.)
    return replace(c, **kwargs)


def doc_root(c, detailed=True):
    data = create_report(c, evaluate(c), detailed)
    with zipfile.ZipFile(BytesIO(data)) as archive:
        return ET.fromstring(archive.read('word/document.xml'))


def document_text(root):
    return ''.join(root.itertext())


def capture_figure(monkeypatch, c):
    import lro.base_plate_drawing as drawing
    captured = []
    close = drawing.plt.close

    def remember(fig):
        if hasattr(fig, 'axes'):
            captured.append(fig)
        close(fig)

    monkeypatch.setattr(drawing.plt, 'close', remember)
    svg = image_bytes(c, evaluate(c), 'svg').decode()
    return captured[-1], svg


def test_actual_washer_dimensions_and_all_four_positions(monkeypatch):
    c = fixture()
    ref = detail_reference(c)
    assert c.anchor_washer_t != ref['washer_t']
    assert c.anchor_washer_side != ref['washer_side']
    fig, svg = capture_figure(monkeypatch, c)
    patches = {p.get_gid(): p for ax in fig.axes for p in ax.patches if p.get_gid()}
    for rod in evaluate(c).geometry['anchor_shear']['rods']:
        washer = patches['washer_plan_' + rod['id']]
        assert washer.get_width() == c.anchor_washer_side
        assert washer.get_height() == c.anchor_washer_side
        assert washer.get_x() + washer.get_width() / 2 == rod['x']
        assert washer.get_y() + washer.get_height() / 2 == rod['y']
        assert patches['washer_hole_' + rod['id']].get_radius() == c.anchor_washer_hole / 2
        assert patches['anchor_' + rod['id']].center == (rod['x'], rod['y'])
        assert rod['id'] + ': (x,y)=' in svg
    assert patches['washer_section_1'].get_height() == c.anchor_washer_t
    assert patches['washer_section_2'].get_width() == c.anchor_washer_side
    grout=patches['anchor_actual_grout'].get_xy()
    assert list(grout[:,1])==[0.,0.,-c.grout_t,-c.grout_t,0.]
    assert grout[2,0]-grout[3,0]==c.L+2*c.grout_t
    assert '65 × 65 × 9.525 mm' in svg and 'furo Ø20.55 mm' in svg


@pytest.mark.parametrize('vsign', [1, -1])
@pytest.mark.parametrize('msign', [1, -1])
def test_signed_shear_arrows_and_tension_sides(monkeypatch, vsign, msign):
    c = fixture(V=vsign * 10000., M=msign * 4e6)
    c = BasePlate.from_dict(json.loads(json.dumps(c.to_dict())))
    result = evaluate(c)
    fig, svg = capture_figure(monkeypatch, c)
    patches = {p.get_gid(): p for ax in fig.axes for p in ax.patches if p.get_gid()}
    for key in ('anchor_plan_shear', 'anchor_applied_shear'):
        start, end = patches[key]._posA_posB
        assert (end[0] - start[0]) * vsign > 0
    assert patches['anchor_applied_shear']._posA_posB[0][1] == c.tp
    assert patches['anchor_native_tension_max']._posA_posB[0][0] == -msign * c.a
    assert result.geometry['M_effective'] == c.M
    assert result.geometry['delta_M'] == 0.
    assert f'V = {c.V / 1000:+.2f} kN (grupo)' in svg
    assert 'M mantido na face superior' in svg
    assert 'sem transporte automático de V' in svg
    text = document_text(doc_root(c))
    assert 'sem transporte automático do cortante' in text
    assert 'A1 e A2 estão em x=−a' in text
    assert 'A3 e A4, em x=+a' in text


def test_native_word_contains_actual_dimensions_capacities_and_pending_scope():
    c = fixture()
    result = evaluate(c)
    root = doc_root(c)
    text = document_text(root)
    assert '65,00 × 65,00 × 9,525 mm' in text
    assert 'furo Ø20,550 mm' in text
    assert 'Vaço,Rd,i' in text and 'Vint,Rd,i' in text
    for rod in result.geometry['anchor_shear']['rods']:
        assert rod['id'] in text
    assert 'fy,b=250 MPa e fub=400 MPa' in text
    assert 'Ft,máx no termo subtrativo conservador' in text
    assert 'maior tração simultânea Ft,máx' in text
    assert 'sem impor uma distribuição' in text
    assert 'σc,Rd=0,85fck/γc, com A2/A1=1' in text
    assert 'Fv,Rd sem redução' in text
    assert 'resistência ou utilização da solda' in text
    assert 'pressão de contato e rasgamento em furos conforme 6.3.3.3' in text
    assert 'cone de concreto' in text and 'efeitos de grupo e borda' in text
    assert 'não aprova a base completa' in text
    assert 'VRd externo do grupo instalado' not in text
    assert 'Aplicabilidade documentada para estes dados' not in text


def test_native_formula_has_editable_radical_fraction_and_exact_coefficient():
    root = doc_root(fixture())
    ns = {'m': 'http://schemas.openxmlformats.org/officeDocument/2006/math'}
    equations = root.findall('.//m:oMath', ns)
    special = next(node for node in equations if ''.join(node.itertext()).startswith('VaçoRd,i') or
                   ''.join(node.itertext()).startswith('Vaço,Rd,i'))
    value = ''.join(special.itertext())
    assert value.count('0,533') == 2
    assert special.findall('.//m:rad', ns)
    assert special.findall('.//m:f', ns)
    assert len(special.findall('.//m:sSup', ns)) >= 3
    math_strings = [''.join(node.itertext()) for node in equations]
    assert any('α = 1,45' in value and 'tp' in value and 'ta' in value for value in math_strings)
    assert any('Vint,Rd,i' in value and 'Ft,Rd' in value for value in math_strings)
    assert any('VRd,1' in value and 'VRd,4' in value for value in math_strings)
    assert all('V/4' not in value for value in math_strings)
    for row in evaluate(fixture()).checks:
        if row.id.startswith('bp_anchor_washer_'):
            assert row.equation in math_strings
    assert any('VRd,i = min(Vaço,Rd,i; Vint,Rd,i; 5db2σc,Rd)' in value for value in math_strings)
    assert any('|VSd| ≤ VRd,grupo = Σ VRd,i' in value for value in math_strings)
    assert not any('|VSd| ≤ Σ Vint,Rd,i' in value for value in math_strings)
    # Detailed per-rod capacities remain auditable after removing the two
    # redundant group inequalities, including the exact exported table values.
    from lro.report import number
    c=fixture();result=evaluate(c);shear=result.geometry['anchor_shear']
    wns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
    rows=[[''.join(cell.itertext()) for cell in row.findall('w:tc',wns)]
          for row in root.findall('.//w:tr',wns)]
    for rod in shear['rods']:
        row=next(row for row in rows if row[0]==rod['id'])
        assert row[3:6]==[number(rod[key]/1000,4) for key in ('steel_rd','combined_rd','rd')]
    assert shear['group_rd']==pytest.approx(sum(min(rod['steel_rd'],rod['combined_rd'],shear['concrete_cap']) for rod in shear['rods']))
    clone=BasePlate.from_dict(json.loads(json.dumps(c.to_dict())))
    assert evaluate(clone).geometry['anchor_shear']==shear
    assert special.findall('.//m:sSub/m:sub/m:r/m:t', ns)[-1].text == 't,máx'
    assert root.findall('.//m:rPr/m:nor', ns)


def test_weld_action_uses_unreduced_bar_capacity():
    c = fixture()
    shear = evaluate(c).geometry['anchor_shear']
    assert shear['weld_force_per_washer'] == shear['shear_unreduced_rd']
    assert shear['weld_force_per_washer'] > max(rod['rd'] for rod in shear['rods'])
    text = document_text(doc_root(c))
    from lro.report import number
    assert 'Fv,Rd sem redução = ' + number(shear['weld_force_per_washer'] / 1000, 6) + ' kN' in text
    assert 'não é limitada pela capacidade reduzida VRd,i nem pelo cortante aplicado' in text


def test_out_of_domain_is_visible_without_false_capacity_claim():
    c = fixture(N=-4 * fixture().anchor_steel_rd * 1.05, M=0.)
    result = evaluate(c)
    assert result.geometry and not result.geometry['anchor_shear']['domain_ok']
    text = document_text(doc_root(c))
    assert 'Inválido' in text and 'Sem crédito' in text
    svg = image_bytes(c, result, 'svg').decode()
    assert 'fora do domínio' in svg


def test_external_anchor_mode_keeps_documentary_scope_and_original_drawing():
    c = fixture(anchor_shear_model='external', anchor_shear_rd=15000., anchor_shear_ref='MC legado')
    c = replace(c, anchor_shear_confirmation=c.anchor_shear_signature)
    text = document_text(doc_root(c))
    assert 'VRd externo do grupo instalado' in text
    assert 'confirmada pelo usuário' in text
    assert 'Cortante nativo com arruelas soldadas' not in text
    svg = image_bytes(c, evaluate(c), 'svg').decode()
    assert 'CORTE NO PLANO DA ALMA E REAÇÕES' in svg
    assert 'washer_plan_A1' not in svg


@pytest.mark.parametrize('path', ['friction', 'external', 'plate'])
def test_other_shear_paths_do_not_acquire_native_anchor_artifacts(path):
    c = fixture(shear_path=path, N=150000., M=0., V=1000.,
                external_shear_rd=2000., external_shear_ref='MC dispositivo')
    text = document_text(doc_root(c))
    assert 'Cortante nativo com arruelas soldadas' not in text
    svg = image_bytes(c, evaluate(c), 'svg').decode()
    assert 'washer_plan_A1' not in svg
