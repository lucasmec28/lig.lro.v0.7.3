"""Finite R017 correction contract; no new resistance model."""
from dataclasses import replace
import json
import pytest
from lro.coped_double_angle import evaluate, presets, ADOPTED_PRESET_SOURCE


def qualified(V=100000., **changes):
    c = replace(next(iter(presets().values())), gap=20., V=V, **changes)
    return replace(c, restraint_top_system='Synthetic test boundary', restraint_top_ref='Fixture only',
                   restraint_top_x=c.gap+c.c_top, restraint_bottom_system='Synthetic test boundary',
                   restraint_bottom_ref='Fixture only', restraint_bottom_x=c.gap+c.c_bottom)


@pytest.mark.parametrize('V,qualifies', [(100000., True), (-100000., True), (500000., False), (-500000., False)])
def test_table16_four_point_acceptance_uses_real_existing_paths(V, qualifies):
    c = qualified(V)
    r = evaluate(c)
    q = r['geometry']['table16_exceptions']['beam_end_min']
    assert q['qualified'] is qualifies
    assert q['actual_edge_mm'] == q['horizontal_beam_end_distance_mm'] == 25.
    assert q['table16_minimum_mm'] == 26.
    assert q['horizontal_net_tension_length_mm'] == 13.
    path = q['paths'][0]
    assert path['direction'] == ('up' if V > 0 else 'down')
    assert len(path['bearing_checks']) == 5 and len(path['block_checks']) == 4
    holes = [x for x in path['bearing_checks'] if 'hole_index' in x]
    assert sorted(x['clear_distance_mm'] for x in holes) == [38., 38., 38., 46.5]
    assert path['bearing_checks'][-1]['design_capacity_N'] == pytest.approx(443520.)
    assert all(x['Ant_mm2'] == pytest.approx(93.6) for x in path['block_checks'])
    assert path['block_governing']['design_capacity_N'] == pytest.approx(252240.)
    assert q['governing'] == path['block_governing']
    assert q['governing_check_ids'] == [path['block_governing']['id']]
    detail = next(x for x in r['geometry']['checks'] if x['id'] == 'beam_end_min')
    assert detail['nominal_passed'] is False and detail['passed'] is qualifies
    assert detail['actual'] == 25. and detail['limit'] == 26.
    assert c.gap == 20. and c.beam_gauge == 45.
    assert r['global_pass'] is False
    assert r['local_pass'] is qualifies
    assert r['status'] == ('COMPLETE_LOCAL_CHECKS_PASS_WITHIN_SCOPE' if qualifies else 'VERIFIED_SUBCHECK_FAIL')
    assert bool(q['failed_check_ids']) is not qualifies
    assert bool([x for x in r['issues'] if x.get('field') == 'beam_end_min' and x['severity'] == 'detail_fail']) is not qualifies
    json.dumps(r, allow_nan=False)


def test_zero_requires_existing_paths_in_both_sizing_directions():
    r = evaluate(qualified(0.))
    q = r['geometry']['table16_exceptions']['beam_end_min']
    assert q['qualified'] and len(q['paths']) == 2
    assert {x['direction'] for x in q['paths']} == {'up', 'down'}
    assert r['load_model']['Vsd_N'] == r['load_model']['girder_delivered_vertical_force_N'] == 0.
    assert len(q['governing_check_ids']) == 2


@pytest.mark.parametrize('sign', [1, -1])
def test_bearing_failure_alone_cannot_qualify_exception(sign):
    r = evaluate(qualified(sign*60000., web_pitch=24.))
    q = r['geometry']['table16_exceptions']['beam_end_min']
    assert q['failed_check_ids'] and all('_bearing_' in key for key in q['failed_check_ids'])
    assert all(x['status'] == 'PASS' for x in q['paths'][0]['block_checks'])
    assert not q['qualified'] and r['status'] == 'VERIFIED_SUBCHECK_FAIL'


@pytest.mark.parametrize('sign', [1, -1])
def test_block_failure_alone_cannot_qualify_exception(sign):
    r = evaluate(qualified(sign*300000.))
    q = r['geometry']['table16_exceptions']['beam_end_min']
    assert q['failed_check_ids'] and all('_block_' in key for key in q['failed_check_ids'])
    assert all(x['status'] == 'PASS' for x in q['paths'][0]['bearing_checks'])
    assert not q['qualified'] and r['status'] == 'VERIFIED_SUBCHECK_FAIL'


@pytest.mark.parametrize('sign', [1, -1])
def test_missing_straight_path_retains_detail_boundary(sign):
    c = qualified(sign*100000., c_top=35., c_bottom=35.)
    c = replace(c, support=replace(c.support, bf=80.))
    r = evaluate(c)
    q = r['geometry']['table16_exceptions']['beam_end_min']
    assert r['geometry']['valid'] and not r['geometry']['bolt_column_within_straight_cope']
    assert not q['qualified'] and len(q['missing_check_ids']) == 9
    assert 'não implementado' in q['reason']
    assert r['status'] == 'DETAIL_FAIL' and not r['local_pass']


def test_unimplemented_other_edge_is_not_waived_by_beam_end_exception():
    r = evaluate(qualified(beam_leg=70.))
    q = r['geometry']['table16_exceptions']
    assert q['beam_end_min']['qualified']
    assert not q['angle_web_toe_min']['qualified']
    assert 'não implementada' in q['angle_web_toe_min']['reason']
    assert r['status'] == 'DETAIL_FAIL' and not r['local_pass']


@pytest.mark.parametrize('sign', [1, -1])
def test_missing_external_restraint_stays_pending_with_valid_edge_exception(sign):
    c = qualified(sign*100000.)
    c = replace(c, **{'restraint_top_ref' if sign > 0 else 'restraint_bottom_ref': ''})
    r = evaluate(c)
    assert r['geometry']['table16_exceptions']['beam_end_min']['qualified']
    assert r['status'] == 'ENGINEERING_MODEL_PENDING' and not r['local_pass']


def test_hole_crossing_real_end_stays_physically_invalid():
    r = evaluate(replace(qualified(), gap=34.))
    assert r['status'] == 'INVALID_GEOMETRY' and not r['checks'] and not r['local_pass']
    assert not r['geometry']['table16_exceptions']['beam_end_min']['qualified']


@pytest.mark.parametrize('changes', [{'N': 1.}, {'M': 1.}, {'torsion': 1.}, {'support_intact': False}])
def test_exception_does_not_expand_scope(changes):
    r = evaluate(replace(qualified(), **changes))
    assert r['status'] == 'OUTSIDE_R017_SCOPE' and not r['local_pass']
    assert not r['geometry']['table16_exceptions']['beam_end_min']['qualified']


def test_finite_overflow_is_distinct_from_invalid_and_finite_strength_failure():
    numerical = evaluate(qualified(1e308))
    invalid = evaluate(qualified(float('nan')))
    failed = evaluate(qualified(500000.))
    assert numerical['status'] == 'NUMERICAL_FAILURE'
    assert numerical['issues'][0]['severity'] == 'numerical_failure'
    assert invalid['status'] == 'INVALID_INPUT'
    assert failed['status'] == 'VERIFIED_SUBCHECK_FAIL' and failed['checks']
    for r in (numerical, invalid, failed):
        assert not r['local_pass'] and not r['global_pass']
        json.dumps(r, allow_nan=False)


def test_adopted_preset_attribution_is_explicit_without_changing_dimensions():
    c = qualified(web_pitch=59.)
    r = evaluate(c)
    issue = next(x for x in r['issues'] if x.get('reference') == ADOPTED_PRESET_SOURCE)
    assert 'R016' in issue['text']
    assert 'R017 p.20 não contém essa tabela' in issue['reference']
    assert r['inputs']['web_pitch'] == 59.
