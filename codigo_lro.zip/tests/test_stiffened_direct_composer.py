from copy import deepcopy
import json,math
import pytest
from stiffened_base_app_candidate_20261017.direct_controller import direct_example,calculate,document,validate_document,fingerprint
from stiffened_base_kernels_candidate_20261017.direct_composer import PLATE_GAP
from stiffened_base_kernels_candidate_20261017.full_composer import compose_complete_selected_domain


def test_composition_all_consumers_and_qualified_nominal_plate():
    p=direct_example();before=deepcopy(p);r=calculate(p)
    assert 'input_domain_error' not in r
    assert p==before and r['physical_inputs']==p
    assert r['projection']['loads_NM']['V_N']==0
    assert r['projection']['original_loads']['V_N']==40000
    assert r['direct_anchor_shear']['domain']['eligible']
    assert r['aci_components']['passes'] is True and len(r['aci_components']['states'])==3
    assert r['web_transfer']['web_foot']['recovered_shear_N']==40000
    assert r['web_transfer']['domain'] is True
    assert r['coverage_qualified'] and r['calculation_coverage_complete'] and r['selected_route_resistance_pass']
    assert not r['assembly_approval'] and not r['foundation_complete']
    assert not r['web_transfer']['plate_inplane_transfer_verified']  # web consumer alone still does not approve the plate
    assert r['plate_transfer_scope']['complete'] and PLATE_GAP not in r['missing']
    assert r['nominal_composition']['normal_rib_benefit_retained']
    assert r['credited_friction_N']==r['credited_washer_shear_N']==r['credited_rib_shear_N']==0
    assert len(r['checks_flat'])>200 and all(c['state']=='atende' for c in r['checks_flat'])
    assert not {'anchorage','receiver','internal_transfer','check_states'} & set(r['nm_components'])
    json.dumps(r,allow_nan=False)


@pytest.mark.parametrize('sign',[1,-1])
def test_reverse_v(sign):
    p=direct_example(sign);a=calculate(p);p['loads']['V_N']=-40000;b=calculate(p)
    assert a['actual_rods']==b['actual_rods']
    assert b['web_transfer']['web_foot']['recovered_shear_N']==-40000
    assert a['direct_anchor_shear']['states'][1]['forces']!=b['direct_anchor_shear']['states'][1]['forces']
    assert all(sum(s['forces'].values())==40000 for s in b['aci_components']['states'])


def test_preserve_original_v0_guard():
    p=direct_example()
    for k in ('direct_shear','direct_detail'):p.pop(k)
    with pytest.raises(ValueError,match='V external = 0'):compose_complete_selected_domain(**p)


@pytest.mark.parametrize('where,key,value,reason',[
    ('washer','base_hole_mm',47.625,'furo'),('washer','center_offset_x_mm',1.,'excentricidade'),
    ('direct_shear','fu',410.,'fu'),('direct_shear','thread_area',350.,'As'),
    ('direct_shear','thread_standard','metric','UNC'),
    ('direct_detail','actions_reference_plate_top_confirmed',False,'face superior')])
def test_contract_mismatch(where,key,value,reason):
    p=direct_example();p[where][key]=value;before=deepcopy(p);r=calculate(p)
    assert p==before and r['physical_inputs']==p and not r['coverage_qualified']
    assert any(reason in x for x in r['missing'])


@pytest.mark.parametrize('key,value',[
    ('grout_cured',False),('no_free_standoff',False),('hole_kind','oversized'),
    ('supplementary_application_accepted',False),('service_slip_requirement','no_slip'),('torsion_z',5000.)])
def test_exclusions_exportable(key,value):
    p=direct_example();p['direct_shear'][key]=value;r=calculate(p)
    assert not r['coverage_qualified'] and not r['assembly_approval'] and len(r['missing'])>=1
    json.dumps(r,allow_nan=False)


def test_washer_no_shear_credit():
    p=direct_example();a=calculate(p);p['washer']['washer_thickness_mm']*=4;b=calculate(p)
    for k in ('direct_anchor_shear','aci_components','web_transfer'):assert a[k]==b[k]


def test_real_fu_aci_alternatives_nbr():
    p=direct_example();p['direct_shear']['fu']=p['anchorage']['rod_fu_MPa']=500.;r=calculate(p)
    assert 'input_domain_error' not in r
    As=p['direct_shear']['thread_area'];expected=.6*.6*As*min(500.,1.9*250.,125000*.006894757293168361)*.8
    checks=[c for s in r['aci_components']['states'] for sub in s['force_states'] for c in sub['steel'] if c['id'].startswith('aci_shear_')]
    assert len(checks)>=12 and all(c['resistance']==pytest.approx(expected) for c in checks)
    assert all(c['resistance']==pytest.approx(min(.75*math.pi*25.4**2/4,As)*500/1.35) for c in r['nbr_rod_tension'])


def test_failures_retained():
    p=direct_example();p['loads']['V_N']=2e6;r=calculate(p)
    assert any(c['state']=='não atende' for c in r['checks_flat'])
    assert r['aci_components']['passes'] is False and 'não atendidos' in r['conclusion_label']
    assert not r['assembly_approval']


def test_schema_roundtrip():
    p=direct_example();assert fingerprint(validate_document(json.loads(document(p))))==fingerprint(p)
    doc=json.loads(document(p));doc['schema']='lro.stiffened-base.nm.v1'
    with pytest.raises(ValueError):validate_document(doc)
    doc=json.loads(document(p));doc['inputs']['direct_shear']['surprise']=True
    with pytest.raises(ValueError):validate_document(doc)


def test_aci_exclusions():
    p=direct_example();p['anchorage']['physical_detail']['intact_prism']=False;r=calculate(p)
    assert not r['aci_components']['complete'] and r['aci_components']['passes'] is None
    p=direct_example();p['anchorage']['concrete_fck_MPa']=100.;r=calculate(p)
    assert not r['aci_components']['complete']


def test_no_false_service_displacement():
    r=calculate(direct_example());s=r['direct_anchor_shear']['service_scope']
    assert s['total_displacement_calculated'] is False


def test_normal_and_washer_failures_not_hidden_by_generic_check_collector():
    p=direct_example();p['washer']['washer_thickness_mm']=1.;r=calculate(p)
    assert any(c['component'].endswith('prescription_satisfied') and c['state']=='não atende' for c in r['checks_flat'])
    p=direct_example();p['geometry']['plate_thickness_mm']=10.;r=calculate(p)
    assert any(c['component'].endswith('normal_pass') and c['state']=='não atende' for c in r['checks_flat'])


def test_pending_aci_interaction_is_not_reported_as_pass():
    p=direct_example();p['anchorage']['headed_detail']['effective_area_qualified']=False;r=calculate(p)
    assert r['aci_components']['passes'] is None
    rows=[c for c in r['checks_flat'] if c['component'].startswith('aci_components.') and c['component'].endswith('interaction')]
    assert rows and all(c['state']=='pendente' for c in rows)


def test_aci_ductility_bad_reference_preserves_other_components():
    p=direct_example();p['anchorage'].update(ductile=True,ductility_reference='')
    r=calculate(p)
    assert not r['coverage_qualified'] and r['nm_components'] and r['direct_anchor_shear']['states']
    assert r['web_transfer']['web_transfer_calculated'] and r['aci_components']['passes'] is None


@pytest.mark.parametrize('key,value',[('detail_confirmed',False),('family','unknown'),('intact_concrete',False),('cracked',False),('seismic',True)])
def test_zero_tension_does_not_waive_physical_head_qualification(key,value):
    p=direct_example();p['loads'].update(N_N=200000.,M_Nmm=0.)
    p['anchorage']['headed_detail'][key]=value;r=calculate(p)
    assert not r['aci_components']['complete'] and r['aci_components']['passes'] is None
    assert r['aci_components']['reasons']


def test_pending_aci_summaries_are_not_promoted_to_pass():
    p=direct_example();p['anchorage']['headed_detail']['effective_area_qualified']=False;r=calculate(p)
    rows=[c for c in r['checks_flat'] if 'states_summary' in c['component']]
    assert not rows  # summaries are not extra physical checks


def test_zero_tension_does_not_manufacture_head_area_demand():
    p=direct_example();p['loads'].update(N_N=200000.,M_Nmm=0.)
    p['anchorage']['headed_detail']['effective_area_qualified']=False
    r=calculate(p)
    assert r['aci_components']['headed']['pullout']['status']=='not_demanded'
    assert r['aci_components']['passes'] is True


def test_pryout_cone_auxiliary_geometry_not_reported_as_separate_failure():
    p=direct_example();p['loads']['V_N']=200000.;r=calculate(p)
    assert not any('cone_geometry' in c['component'] for c in r['checks_flat'])
    assert any('pryout' in c['component'] for c in r['checks_flat'])


def test_pryout_auxiliary_no_false_failure_counterexample():
    p=direct_example();p['loads']['V_N']=60000.;p['anchorage']['embedment_mm']=100.
    p['anchorage']['block_bounds_mm']=(-1000.,-1000.,1000.,1000.);r=calculate(p)
    assert r['direct_anchor_shear']['steel_plate_uls']['passes'] and r['aci_components']['passes']
    assert not any(c['state']=='não atende' for c in r['checks_flat'])


def test_optional_plate_scope_is_not_normative_or_actual_tension():
    p=direct_example();r=calculate(p);e=r['plate_transfer_scope']['application_envelope']
    assert e['scope_ratio']==pytest.approx(.809919109556)
    assert e['normative_requirement'] is False and e['inference_T_capacity_implies_V_capacity'] is False
    assert max(a['tension'] for a in r['actual_rods'])<1000.
    assert e['reference_rod_pair_N']>200000.
    assert e['kthread_reference']==1. and r['direct_anchor_shear']['resistances']['kthread']==.85


def test_thinner_basal_plate_is_domain_pending_without_erasing_ribs():
    p=direct_example();p['geometry']['plate_thickness_mm']=35.;r=calculate(p)
    assert not r['calculation_coverage_complete'] and not r['selected_route_resistance_pass']
    assert not r['plate_transfer_scope']['application_envelope']['qualifies']
    assert r['nm_components']['sides'] and r['actual_rods']
    assert r['plate_transfer_scope']['application_envelope']['rib_normal_benefit_removed'] is False
    assert PLATE_GAP in r['missing']


def test_known_resistance_failure_keeps_nominal_coverage():
    p=direct_example();p['loads']['V_N']=200000.;r=calculate(p)
    assert r['calculation_coverage_complete'] and not r['selected_route_resistance_pass']
    assert any(c['state']=='não atende' for c in r['checks_flat'])
    assert r['plate_transfer_scope']['application_envelope']['qualifies']
    assert not r['missing']
