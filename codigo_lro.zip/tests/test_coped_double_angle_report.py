"""Editable Word contract, exact findings and conservative local scope."""
from copy import deepcopy
from dataclasses import fields, replace
from io import BytesIO
from zipfile import ZipFile
import xml.etree.ElementTree as ET

import pytest
from lro.coped_double_angle import presets, evaluate
from lro.coped_double_angle_report import create_report, _approved
from lro.report import number
from lro.models import KGF


def fixture(**changes):
    return replace(next(iter(presets().values())), **changes)


def document(c, r=None):
    with ZipFile(BytesIO(create_report(c, evaluate(c) if r is None else r))) as archive:
        root = ET.fromstring(archive.read('word/document.xml'))
        text = '\n'.join(root.itertext()); files = archive.namelist()
    return root, text, files


def qualified(**changes):
    c = fixture()
    return replace(c, restraint_top_system='Travamento independente EXEMPLO', restraint_top_ref='MC-TESTE: resistência e rigidez', restraint_top_x=c.gap+c.c_top, **changes)


def test_complete_inputs_results_formulas_and_source_distinctions():
    c = fixture(); r = evaluate(c); root, text, files = document(c, r)
    assert 'Não há aprovação local da ligação' in text
    assert 'Verificação global dos membros: EXTERNA' in text
    for f in fields(c):
        if f.name not in ('beam', 'support'):
            assert f.name in text
    for key in c.fixed_assumptions:
        assert key in text
    for check in r['checks']:
        for key in ('id', 'formula', 'reference'):
            assert check[key] in text
        assert number(check['utilization'], 6) in text
    ns = {'m': 'http://schemas.openxmlformats.org/officeDocument/2006/math'}
    equations = [''.join(node.itertext()) for node in root.findall('.//m:oMath', ns)]
    assert set(check['formula'] for check in r['checks']).issubset(equations)
    assert 'R15' in text and 'aproximadamente 12 mm' in text
    assert '350600' in text and 'e = c + folga' in text
    assert 'página impressa 20' in text and 'Dowswell e Whyte' in text
    assert 'tw=' + number(c.support.tw, 3) in text
    assert 'sem fabricar uma borda livre' in text
    assert any(name.startswith('word/media/') for name in files)
    assert 'Soldas em U' not in text and 'R015' not in text and 'gabarito adotado da tabela industrial R016' in text


def test_qualified_local_success_explicitly_excludes_member_approval():
    c = qualified(); r = evaluate(c)
    assert r['local_pass'] and not r['global_pass'] and _approved(r)
    _, text, _ = document(c, r)
    assert 'sim, no domínio' in text and 'Atendimento local condicionado' in text
    assert 'VERIFICAÇÃO GLOBAL DOS MEMBROS: EXTERNA, NÃO AVALIADA' in text
    assert c.restraint_top_system in text and c.restraint_top_ref in text
    assert 'O módulo não dimensiona essas contenções' in text


def test_real_vs_minimum_signed_forces_and_no_result_mutation():
    c = fixture(V=-12345.67890123); r = evaluate(c); before = deepcopy(r)
    _, text, _ = document(c, r)
    assert number(c.V/KGF, 2) in text
    assert number(r['load_model']['Vd_N']/KGF, 2) in text
    assert 'sem arredondamento intermediário' in text
    assert r == before


def test_partial_report_ignores_injected_blocker_and_preserves_canonical_checks():
    c = fixture(); r = evaluate(c)
    r['issues'].append({'severity': 'engineering_pending', 'text': 'Falta referência específica do travamento X.', 'reference': 'REF-X'})
    _, text, _ = document(c, r)
    assert 'Falta referência específica do travamento X.' not in text and 'REF-X' not in text
    assert 'ENGINEERING_MODEL_PENDING' in text
    for check in r['checks']:
        assert check['id'] in text


@pytest.mark.parametrize('checks', [[], None])
def test_unbound_partial_result_cannot_approve_even_with_local_pass(checks):
    c = fixture(); r = {'status': 'COMPLETE_LOCAL_CHECKS_PASS_WITHIN_SCOPE', 'local_pass': True,
                       'global_pass': False, 'geometry': {'valid': True}, 'summary': {'complete_checks': True}, 'checks': checks}
    _, text, _ = document(c, r)
    assert 'ENGINEERING_MODEL_PENDING' in text
    assert 'Resultado sem vínculo de entrada' not in text
    assert 'Não há aprovação local' in text and 'sim, no domínio' not in text


@pytest.mark.parametrize('change', [{'V': 120000.}, {'c_top': 145.}, {'r_top': 16.}, {'restraint_top_ref': 'another'}, {'support_eccentricity': 3.}])
def test_stale_results_are_recalculated(change):
    c = fixture(); r = evaluate(c)
    current = replace(c, **change)
    text = document(current, r)[1]
    assert evaluate(current)['status'] in text
    assert 'Não há aprovação local' in text


def test_fail_and_unsupported_reports_are_diagnostic():
    c = fixture(V=500000.); r = evaluate(c)
    assert any(check['status'] == 'FAIL' for check in r['checks'])
    assert 'Falha' in document(c, r)[1]
    c = fixture(angle_count=1)
    assert 'Não há aprovação local' in document(c)[1]


def test_invalid_nan_dimension_records_matching_sanitized_input():
    c = fixture(c_top=float('nan'))
    _, text, _ = document(c)
    assert 'Desenho não gerado' in text and 'Não há aprovação local' in text


def test_embedded_drawing_fits_landscape_printable_height():
    root, _, _ = document(fixture())
    ns = {'wp': 'http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing'}
    extents = root.findall('.//wp:extent', ns)
    assert len(extents) == 1
    # 8.27 in page minus 2 x 0.48 in margins, with room for its paragraph.
    assert int(extents[0].get('cy')) < int(7.12 * 914400)
    assert int(extents[0].get('cx')) <= int(9.15 * 914400)
