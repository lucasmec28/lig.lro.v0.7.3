"""New 0930 complete-route acceptance; source-derived oracle is not legacy output."""
from dataclasses import replace
import copy
import json
import math
from pathlib import Path
import pytest
from lro.bolted_angle_gusset import (BoltedAngleGusset, evaluate, presets, HOLES, catalog,
    GAMMA_A1, GAMMA_A2, COMPONENT_VERSION, CONNECTION_TYPE)
from lro.bolted_gusset_geometry import (point, ray_exit, transverse_chord, root_contact_length,
    subtract_intervals, section_properties, horizontal_sections)

DATA = json.loads((Path(__file__).parents[1]/'examples'/'bolted_complete_reference0930.json').read_text())
BASE = next(iter(presets().values()))


def fixture_input(f):
    i = f['inputs']; m = i['materials']
    return replace(BASE, arrangement=i['topology'], N=i['N'], theta_deg=i['theta'],
        plate_width=i['plate'][0], plate_height=i['plate'][1], plate_t=i['plate'][2],
        drilled=i['drilled'], gusset_steel='ASTM A572 Gr.50' if m['gusset'][0] == 345 else 'ASTM A36')


@pytest.mark.parametrize('fixture', DATA['fixtures'], ids=lambda f:f['id'])
def test_all_seven_source_derived_complete_routes(fixture):
    r = evaluate(fixture_input(fixture)); expected = fixture['utilizations']
    assert r['local_pass'] == fixture['full_method_pass_given_declared_detail']
    assert len(r['cases']) == 1
    for key, value in expected.items():
        if key == 'plate_block':
            assert r['reference_center_path_utilizations'][key] == pytest.approx(value, rel=2e-8)
            assert r['utilizations'][key] >= value  # Conservative nonlinear variable-cap extension.
        else:
            assert r['utilizations'][key] == pytest.approx(value, rel=2e-8, abs=1e-10), key
    for key in ('N', 'V', 'M', 'q_peak', 'q_design', 'W_centroid_M'):
        assert r['root'][key] == pytest.approx(fixture['root'][key], rel=1e-9, abs=1e-7)
    for actual, expected in zip(r['geometry']['bolt_centers'], fixture['inputs']['bolt_centers']):
        assert actual == pytest.approx(expected)
    for side in ('angle', 'gusset'):
        for a, e in zip(r['bearing'][side], fixture['bearing'][side]):
            for key in ('lc', 'R', 'demand'):
                assert a[key] == pytest.approx(e[key])
    for p in fixture['angle_blocks']+fixture['gusset_blocks']:
        actual = next(x for x in r['paths'] if x['id'] == p['id'])
        for key in ('Agv', 'Anv', 'Ant', 'R', 'demand'):
            assert actual[key] == pytest.approx(p[key])
    for a,e in zip(r['force_normal_cuts'], fixture['force_normal_cuts']):
        for key in ('net_area','net_centroid_v','I','moment_about_net_centroid'):
            assert a[key] == pytest.approx(e[key], rel=1e-9, abs=1e-7)
    assert r['cases'][0]['normal_tension_domain'] == fixture['normal_tension_domain']
    assert r['global_member_verified'] is False
    assert r['member_actions']['existing_member_actions'] is None


@pytest.mark.parametrize('failure', DATA['same_geometry_failure_cases'], ids=lambda f:f['id'])
def test_every_concurrent_scaled_failure(failure):
    r = evaluate(replace(BASE, N=failure['N']))
    assert not r['local_pass']
    original = r['reference_center_path_utilizations'] if failure['target']=='plate_block' else r['utilizations']
    assert original[failure['target']] == pytest.approx(1.01, rel=2e-8)
    for key,value in failure['all_utilizations'].items():
        if key == 'plate_block':
            assert r['reference_center_path_utilizations'][key] == pytest.approx(value, rel=2e-8)
            assert r['utilizations'][key] == pytest.approx(.21226870552466506*failure['scale'],rel=2e-8)
        else:
            assert r['utilizations'][key] == pytest.approx(value, rel=2e-8)
    assert r['root']['N'] == pytest.approx(failure['N']*math.sin(math.radians(BASE.theta_deg)))


@pytest.mark.parametrize('fixture', DATA['adversarial_geometry'], ids=lambda f:f['id'])
def test_source_negative_geometry(fixture):
    r = evaluate(fixture_input(fixture))
    assert not r['local_pass']
    if fixture['inputs']['theta'] == 75:
        assert r['status'] == 'OUTSIDE_SCOPE'
        assert any('compressed_section' in x['id'] for x in r['issues'])
    else:
        assert r['status'] == 'DETAILING_FAIL'
        assert any('maximum_edge' in x['id'] for x in r['issues'])


def test_distinct_native_schema_no_silent_upgrades():
    assert BASE.to_dict()['connection_type'] == CONNECTION_TYPE
    assert BASE.to_dict()['component_version'] == COMPONENT_VERSION
    assert BoltedAngleGusset.from_dict(json.loads(json.dumps(BASE.to_dict()))) == BASE
    for key,value in [('connection_type','axial_double_angle'),('component_version','0.9.29-load-conventions-dev'),('schema_version',True)]:
        d=BASE.to_dict();d[key]=value
        with pytest.raises(ValueError):BoltedAngleGusset.from_dict(d)
    for key,value in [('filler_t',2.),('angle_count',2),('second_angle_steel','ASTM A36'),('arrangement','2L-opposed')]:
        d=BASE.to_dict();d['connection'][key]=value
        with pytest.raises(ValueError):BoltedAngleGusset.from_dict(d)
    for mutation in ['missing','unknown','premise','unit','bool']:
        d=BASE.to_dict()
        if mutation=='missing':del d['connection']['drilled']
        elif mutation=='unknown':d['results']={'global_pass':True}
        elif mutation=='premise':d['fixed_assumptions']['physical_shear_planes']=1
        elif mutation=='unit':d['units']['force']='kN'
        else:d['connection']['drilled']=1
        with pytest.raises(ValueError):BoltedAngleGusset.from_dict(d)


@pytest.mark.parametrize('kwargs', [dict(n=True),dict(n=3.0),dict(n=1),dict(n=51),dict(N=float('nan')),
    dict(center_s=float('inf')),dict(heel_extent=True),dict(threads_excluded_1=1)])
def test_strict_input_types(kwargs):
    r=evaluate(replace(BASE,**kwargs));assert r['status']=='INVALID_INPUT'
    json.dumps(r,allow_nan=False)


@pytest.mark.parametrize('kwargs', [dict(arrangement='2L-opposed'),dict(arrangement='2L-asymmetric'),dict(support_face='web'),
    dict(theta_deg=0.),dict(theta_deg=180.),dict(N=-1.),dict(V=1.),dict(M=1.),dict(torsion=1.),
    dict(fatigue=True),dict(seismic=True),dict(static=False),dict(normal_combination=False),
    dict(support_profile='built-up I'),dict(angle_profile='L76x6.35'),dict(db=16.1),dict(exposure='unknown'),
    dict(bolt='ASTM A307',pretensioned=True),dict(arrangement='1L',threads_excluded_2=True)])
def test_unqualified_domains_rejected(kwargs):
    assert not evaluate(replace(BASE,**kwargs))['local_pass']


def test_real_zero_minimum_once_recommendation_pair_and_individual():
    r=evaluate(replace(BASE,N=0.,recommend_half_capacity=True))
    assert [x['id'] for x in r['cases']]==['actual','minimum_45kN','recommended_half']
    real,minimum,half=r['cases']
    assert real['N']==0 and real['root']['N']==0 and real['root']['M']==0
    assert minimum['N']==45000 and minimum['force_split']['each_angle']==22500
    assert minimum['force_split']['each_plane']==7500
    single=evaluate(replace(BASE,arrangement='1L',N=0.,recommend_half_capacity=True))
    assert half['N']==pytest.approx(2*single['cases'][2]['N'])
    assert not evaluate(replace(BASE,N=0.,minimum_force=False))['local_pass']


def test_single_pair_force_conservation_and_root_never_doubled():
    pair=evaluate(BASE);single=evaluate(replace(BASE,arrangement='1L'))
    assert pair['root']==single['root']
    assert pair['member_actions']==single['member_actions']
    assert len(pair['cases'][0]['bolt_planes'])==6 and len(single['cases'][0]['bolt_planes'])==3
    assert pair['utilizations']['angle_net']*2==pytest.approx(single['utilizations']['angle_net'])
    assert pair['utilizations']['bolt_shear']*2==pytest.approx(single['utilizations']['bolt_shear'])
    assert pair['utilizations']['plate_bearing']==single['utilizations']['plate_bearing']
    assert pair['cases'][0]['angle_Ct']==single['cases'][0]['angle_Ct']<1.
    assert single['fixed_assumptions']['out_of_plane']=='static_end_idealization_not_physical_cancellation'


def test_plane_specific_threads_no_averaging_and_grip_reduction():
    base=evaluate(BASE);one=evaluate(replace(BASE,threads_excluded_1=True))
    p=one['cases'][0]['bolt_planes']
    assert p[0]['coefficient']==.56 and p[1]['coefficient']==.45
    assert one['utilizations']['bolt_shear']==base['utilizations']['bolt_shear']
    two=evaluate(replace(BASE,threads_excluded_1=True,threads_excluded_2=True))
    assert two['utilizations']['bolt_shear']==pytest.approx(base['utilizations']['bolt_shear']*.45/.56)
    long=evaluate(replace(BASE,washer_stack=80.));pretension=evaluate(replace(BASE,washer_stack=80.,pretensioned=True))
    assert long['geometry']['grip_factor']<1
    assert long['utilizations']['bolt_shear']>base['utilizations']['bolt_shear']
    assert pretension['geometry']['grip_factor']==1


def test_reference_translation_rigid_rotation_and_mirror():
    base=evaluate(BASE);alpha=37.;theta=math.radians(BASE.theta_deg)
    translated=evaluate(replace(BASE,center_s=BASE.center_s+alpha*math.cos(theta),
        center_n=BASE.center_n+alpha*math.sin(theta),row_offset=BASE.row_offset-alpha))
    for key in ('N','V','M'):assert translated['root'][key]==pytest.approx(base['root'][key])
    for key,value in base['utilizations'].items():assert translated['utilizations'][key]==pytest.approx(value,rel=1e-8)
    column=evaluate(replace(BASE,support_member='column'))
    assert column['root']==base['root'] and column['utilizations']==base['utilizations']
    mirror=evaluate(replace(BASE,theta_deg=100.))
    assert mirror['root']['V']==pytest.approx(-base['root']['V'])
    assert mirror['root']['M']==pytest.approx(-base['root']['M'])
    for key,value in base['utilizations'].items():assert mirror['utilizations'][key]==pytest.approx(value,rel=1e-8)
    vertical=evaluate(replace(BASE,theta_deg=90.));assert abs(vertical['root']['M'])<1e-7


def test_independent_materials_and_electrode():
    base=evaluate(BASE)
    plate=evaluate(replace(BASE,gusset_steel='ASTM A572 Gr.50'))
    assert plate['utilizations']['plate_bearing']<base['utilizations']['plate_bearing']
    for key in ('angle_yield','angle_net','bolt_shear','root_weld','W_web_normal'):assert plate['utilizations'][key]==base['utilizations'][key]
    angle=evaluate(replace(BASE,angle_steel='ASTM A572 Gr.50'))
    assert angle['utilizations']['angle_yield']<base['utilizations']['angle_yield']
    assert angle['utilizations']['plate_bearing']==base['utilizations']['plate_bearing']
    support=evaluate(replace(BASE,support_steel='ASTM A36'))
    assert support['utilizations']['W_web_normal']>base['utilizations']['W_web_normal']
    assert support['utilizations']['angle_yield']==base['utilizations']['angle_yield']
    bolt=evaluate(replace(BASE,bolt='ASTM F3125 A490'))
    assert bolt['utilizations']['bolt_shear']<base['utilizations']['bolt_shear']
    assert bolt['utilizations']['root_weld']==base['utilizations']['root_weld']
    weld=evaluate(replace(BASE,root_electrode='E70'))
    assert weld['utilizations']['root_weld']<base['utilizations']['root_weld']
    assert weld['utilizations']['root_gusset_contact']==base['utilizations']['root_gusset_contact']


def test_physical_vs_net_hole_and_no_inch_metric_alias():
    a=evaluate(BASE);b=evaluate(replace(BASE,drilled=False))
    assert a['geometry']['hole_diameter']==b['geometry']['hole_diameter']==18
    assert a['geometry']['net_hole_diameter']==18 and b['geometry']['net_hole_diameter']==20
    assert a['utilizations']['plate_bearing']==b['utilizations']['plate_bearing']
    assert b['utilizations']['angle_net']>a['utilizations']['angle_net']
    assert HOLES[15.875]!=HOLES[16.]


def test_tool_actual_heel_required_not_catalog_radius():
    missing=evaluate(BoltedAngleGusset())
    assert missing['status']=='DETAILING_PENDING' and missing['summary']['mechanics_pass']
    assert not missing['local_pass'] and missing['geometry']['angle_section']['root_radius'] is None
    assert evaluate(replace(BASE,heel_extent=20.))['local_pass']
    assert not evaluate(replace(BASE,heel_extent=20.0001))['local_pass']
    assert evaluate(replace(BASE,heel_extent_source=''))['status']=='DETAILING_PENDING'


@pytest.mark.parametrize('kwargs', [dict(pitch=40.),dict(pitch=200.),dict(angle_end=20.),dict(gauge=60.),
    dict(center_n=55.),dict(plate_width=60.),dict(root_weld_leg=2.),dict(root_weld_leg=12.),
    dict(support_end_left=100.),dict(tool_radius=8.),dict(plate_t=0.),dict(heel_extent=1.)])
def test_holes_tool_root_ligament_and_detail_collisions(kwargs):
    assert not evaluate(replace(BASE,**kwargs))['local_pass']


def test_nearest_fastener_to_every_free_edge_not_farthest():
    r=evaluate(BASE);checks=r['geometry']['detail_checks']
    left=next(x for x in checks if x['id']=='gusset_left_maximum_edge')
    assert left['actual']==pytest.approx(min(x+120 for x,y in r['geometry']['bolt_centers']))
    wide=evaluate(replace(BASE,plate_width=400.))
    assert wide['summary']['mechanics_pass'] and wide['status']=='DETAILING_FAIL'


def test_clipped_whitmore_real_polygon_not_infinite_strip():
    r=evaluate(replace(BASE,plate_width=100.,theta_deg=90.,N=45000.))
    assert r['local_pass'] and r['Whitmore']['clipped']
    assert r['Whitmore']['width']==100 and r['Whitmore']['nominal_width']>100
    assert r['Whitmore']['net_area']==(100-18)*BASE.plate_t


def test_root_touching_block_inactive_not_free_edge():
    r=evaluate(replace(BASE,theta_deg=45.,center_n=90.,plate_width=400.,plate_height=180.,plate_t=20.,n=2))
    inactive=r['geometry']['inactive_path_families']
    assert inactive and any(x['root_contact_length']>0 for x in inactive)
    ids={x['id'] for x in inactive}
    assert not ids.intersection(x['id'] for x in r['paths'])
    assert all(p.get('free_transverse_exit')!='root' for p in r['paths'])


def test_side_top_corner_exits_and_corner_events():
    a=replace(BASE,theta_deg=45.,plate_width=200.,plate_height=250.,center_n=150.)
    corner=ray_exit(a,[0.,150.],[2**-.5,2**-.5])
    assert corner['point']==pytest.approx([100.,250.])
    assert set(corner['edges'])=={'top','right'}
    side=ray_exit(replace(a,plate_width=180.),[0.,150.],[2**-.5,2**-.5])
    top=ray_exit(replace(a,plate_width=220.),[0.,150.],[2**-.5,2**-.5])
    assert side['edge']=='right' and top['edge']=='top'
    # The algorithm retains both sides and actual event stations, never a doubled one-row U block.
    r=evaluate(BASE)
    assert all(p.get('no_duplicate_U_path') for p in r['paths'] if p['component']=='gusset')
    assert any(p.get('event')=='hole_edge' for p in r['paths'])


def test_support_end_reduction_and_flange_bending_not_omitted():
    base=evaluate(BASE);near=evaluate(replace(BASE,support_end_left=200.))
    assert near['root']['closest_W_end']==80.
    assert near['root']['W_web_local_yield_R']<base['root']['W_web_local_yield_R']
    thick=evaluate(replace(BASE,plate_t=16.,root_weld_leg=6.))
    assert not thick['root']['flange_bending_exempt']
    assert 'W_flange_bending' in thick['utilizations']


def test_nominal_screen_full_intervals_jumps_and_net_centroid():
    r=evaluate(BASE);s=r['sections']
    assert 'not exact' in s['model'] and 'not an interval certificate' in s['extrema_method']
    assert len(s['bounds'])==11
    crossing=[x for x in s['intervals'] if x['crossing_bolts']]
    assert {x['inclusion'] for x in crossing}=={'excluding_crossing_holes','including_crossing_holes'}
    assert r['force_normal_cuts'][0]['net_centroid_v']!=0
    assert r['force_normal_cuts'][0]['moment_about_net_centroid']!=0
    assert r['sections']['utilization_yield']>0


def test_interval_union_and_force_limits_with_multiple_hole_crossings():
    assert subtract_intervals(-5,5,[[-2,1],[0,3]])==[[-5,-2],[3,5]]
    A,cg,I=section_properties([[-5,-2],[3,5]],1.)
    assert A==5 and cg==pytest.approx(-.5) and I>0
    # Horizontal projections can overlap at small theta. Only two count extremes
    # are needed because all forces are collinear, no exponential subset shortcut.
    c=replace(BASE,theta_deg=5.,plate_width=400.,plate_height=300.)
    C,S=math.cos(math.radians(5)),math.sin(math.radians(5))
    holes=[point(c,u) for u in [-50.,0.,50.]]
    g={'bolt_centers':holes,'net_hole_diameter':18.,'direction':[C,S]}
    r=horizontal_sections(c,g,100000.,250.,400.)
    assert any(len(x['crossing_bolts'])>1 for x in r['intervals'])
    assert len(r['intervals'])<=2*(len(r['bounds'])-1)


def test_all_fifty_gerdau_identities_remain_independent():
    sections=catalog();assert len(sections)==50
    for identity,section in sections.items():
        r=evaluate(replace(BASE,angle_profile=identity,heel_extent=None))
        assert r['geometry']['angle_section']['id']==identity
        assert r['geometry']['angle_section']['Ag']==section['Ag']
        assert r['geometry']['angle_section']['centroid']==section['centroid']
        assert r['geometry']['angle_section']['root_radius'] is None
        assert r['materials']['angle']['name']=='ASTM A36'
    assert not any(s['t']==2.5 for s in sections.values())


def test_recompute_on_export_not_stored_pass():
    d=BASE.to_dict();changed=copy.deepcopy(d);changed['connection']['N']=200000.
    r=evaluate(BoltedAngleGusset.from_dict(changed))
    assert r['status']=='COMPLETE_CHECKS_FAIL' and not r['local_pass']
    assert r['utilizations']['root_weld']>1
    assert len({c['id'] for c in r['checks']})==len(r['checks'])
    json.dumps(r,allow_nan=False)


def test_angle_far_path_reaches_real_other_toe_in_three_dimensions():
    r=evaluate(BASE)
    far=[p for p in r['paths'] if 'opposite_toe' in p['id']]
    assert len(far)==3
    for p in far:
        assert not p['heel_is_free_edge']
        assert p['free_exit']['name']=='opposite_real_toe'
        assert p['free_exit']['nominal_point_3d'][2]==pytest.approx(BASE.plate_t/2+76.2)
        a,b=p['nominal_path_3d_each_angle']
        assert a[-1][2]==-b[-1][2]
        assert not p['free_exit']['radius_contour_reconstructed']
        assert p['Ant']==pytest.approx(929-(76.2-40)*6.35-18*6.35/2)


def test_actual_block_corner_transition_and_side_exit():
    r=evaluate(replace(BASE,theta_deg=50.))
    assert r['geometry']['forward_exit']['edge']=='right'
    transitions=[p for p in r['paths'] if p.get('event')=='polygon_corner']
    assert len(transitions)==4
    assert any(p['root_contact_length']==0 for p in transitions)
    for p in transitions:
        for x,y in p['coordinates']:
            assert -120-1e-8<=x<=120+1e-8 and -1e-8<=y<=300+1e-8


def test_minimum_pitch_and_maximum_free_edge_exact_boundaries():
    assert evaluate(replace(BASE,pitch=2.7*16))['local_pass']
    assert not evaluate(replace(BASE,pitch=2.7*16-.001))['local_pass']
    width=2*(150+50*math.cos(math.radians(80)))
    assert evaluate(replace(BASE,plate_width=width))['local_pass']
    assert not evaluate(replace(BASE,plate_width=width+.001))['local_pass']


def test_published_source_replay_stays_aisc_not_nbr_oracle():
    p=DATA['published_source_replay']
    bolt=.75*54*(math.pi*.875**2/4)*2
    end_gusset=.75*1.2*(1.5-.9375/2)*.5*58
    end_angles=.75*1.2*(1.5-.9375/2)*.375*2*58
    assert p['bolt_double_shear_kip']==pytest.approx(bolt)
    assert p['effective_group_kip']==pytest.approx(end_gusset+bolt+end_angles)
    assert p['gusset_block_R_kip']==pytest.approx(.75*min(.6*58*2.50+58*2.25,.6*36*3.75+58*2.25))
    N,V,M,t,B=50.5,86.3,123.,.625,22.
    sn=N/(t*B);sm=4*M/(t*B**2);tau=V/(t*B)
    peak=math.hypot(sn+sm,tau);average=(peak+math.hypot(sn-sm,tau))/2
    assert p['root_design_ksi']==pytest.approx(max(peak,1.25*average))
    assert p['root_web_Nequiv_plastic_kip']==pytest.approx(N+4*M/B)
    assert 'AISC360-10' in p['factors'] and 'not' in p['warning'].lower()


def test_review_hole_intersecting_cap_interior_minimum_and_first_lower_half():
    c=replace(BASE,n=5,pitch=43.2,plate_height=270.,N=45000.)
    r=evaluate(c);assert r['local_pass']
    # Independent analytic geometry of the reviewer's second-hole LEFT cap.
    radius=9.;theta=math.radians(80.);a=math.cos(theta)/math.sin(theta)
    u=-43.2-radius*a/math.sqrt(1+a*a)
    cap=next(p for p in r['paths'] if p['component']=='gusset' and p['id'].startswith('G-event-left-')
        and p['event']=='hole_cap_rupture_critical_left' and abs(p['u']-u)<1e-8)
    assert cap['u']==pytest.approx(-44.76283359900238)
    assert cap['R']==pytest.approx(421400.8527115912,rel=1e-11)
    centered=next(p for p in r['paths'] if p['id']=='G-L--1-4')
    assert centered['R']==pytest.approx(421657.96291048854,rel=1e-10)
    assert cap['R']<centered['R']
    first=next(p for p in r['paths'] if p['component']=='gusset' and p['id'].startswith('G-event-left-')
        and p['event']=='hole_cap_rupture_critical_left' and p['u']<-86.4)
    assert first['u']==pytest.approx(-87.96283359900238)
    assert first['demand']==45000 and first['demand_limits']['excluding_crossing']==36000
    assert first['R']==pytest.approx(463294.69425491407,rel=1e-11)
    assert r['utilizations']['plate_block']==pytest.approx(.0971304022213561,rel=1e-10)


def test_extended_main_hole_cap_aggregate_disclosed_and_center_oracle_preserved():
    r=evaluate(BASE)
    assert r['reference_center_path_utilizations']['plate_block']==pytest.approx(.21112690538752169)
    assert r['utilizations']['plate_block']==pytest.approx(.21226870552466506)
    assert r['block_path_envelope']['original_center_witnesses_preserved']
    cap=max((p for p in r['paths'] if p['component']=='gusset'),key=lambda p:p['utilization'])
    assert cap['event']=='hole_cap_yield_critical_left'
    assert cap['u']==pytest.approx(-45.5215473637932)
    assert cap['demand_limits']==dict(excluding_crossing=200000/3,including_crossing=100000.)
    # Both analytical branch critical points are included; positive upper-half
    # demand is the explicit conservative pre/post bound, not a hidden pressure law.
    assert any('hole_cap_rupture_critical' in p.get('event','') for p in r['paths'])
    assert r['summary']['governing_id']=='actual__root_weld'


def test_exhausted_grip_reduction_rejected_as_geometry_not_numerics():
    r=evaluate(replace(BASE,washer_stack=10000.))
    assert r['status']=='INVALID_GEOMETRY'
    check=next(x for x in r['geometry']['detail_checks'] if x['id']=='grip_factor_positive')
    assert check['actual']==0 and check['status']=='FAIL'
    assert not any(x['severity']=='numerical_failure' for x in r['issues'])
