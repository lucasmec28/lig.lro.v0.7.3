"""Corner native UI and user-visible artifacts; no imports from a fixture oracle."""
from copy import deepcopy
from dataclasses import replace
from io import BytesIO
import json
import xml.etree.ElementTree as ET

import pytest
from docx import Document
from streamlit.testing.v1 import AppTest

from lro.corner_gusset import CornerGusset, analyze, geometry
from lro.corner_gusset_ui import (PROJECT,DRAFT,RESULT,REPORT,ACCEPTED,TEMPLATE,decode_project,
    import_ui_values,_key,OTHER,checks_complete)
from lro.corner_gusset_drawing import image_bytes,effort_convention_svg,effort_convention_png
from lro.corner_gusset_presentation import physical_envelopes,memory_text,input_fingerprint,approved,utilization_text
from lro.corner_gusset_report import create_report

RUNNER='''
import streamlit as st
from lro.corner_gusset_ui import render
page=st.selectbox('Página de teste',['Canto','Outra'],key='test_page')
if page=='Canto':render()
else:st.text_input('Outro projeto',key='other_project')
'''


def fresh(c=None):
    at=AppTest.from_string(RUNNER,default_timeout=120)
    at.session_state[PROJECT]=(c or CornerGusset()).to_dict()
    at.run();assert not at.exception
    return at


def button(at,label):return next(x for x in at.button if x.label==label)


def upload(at,payload):
    if not isinstance(payload,bytes):payload=json.dumps(payload,ensure_ascii=False).encode()
    at.get('file_uploader')[0].upload('native_corner.json',payload,'application/json').run()
    button(at,'Carregar projeto de canto').click().run()
    assert not at.exception


def texts(docbytes):
    doc=Document(BytesIO(docbytes))
    return '\n'.join([p.text for p in doc.paragraphs]+[c.text for t in doc.tables for r in t.rows for c in r.cells])


def test_native_exact_roundtrip_and_no_legacy_coercion():
    c=replace(CornerGusset(),P=123456.78901234567,beam_cut_M=62300000.01234567)
    assert decode_project(json.dumps(c.to_dict()))==c
    values=import_ui_values(c)
    assert values[ACCEPTED]['P']['raw']==c.P
    from lro.welded_double_angle_gusset import WeldedDoubleAngleGusset
    with pytest.raises((ValueError,TypeError)):decode_project(json.dumps(WeldedDoubleAngleGusset().to_dict()))


@pytest.mark.parametrize('bad',['unknown','missing','boolean','nan','duplicate','family','units','assumptions'])
def test_strict_native_decoder(bad):
    payload=CornerGusset().to_dict()
    if bad=='unknown':payload['unexpected']=1
    elif bad=='missing':payload['connection'].pop('upper_column_cut_Fy')
    elif bad=='boolean':payload['connection']['P']=True
    elif bad=='nan':payload['connection']['P']=float('nan')
    elif bad=='family':payload['connection_type']='welded_double_angle_gusset'
    elif bad=='units':payload['units']['force']='kN'
    elif bad=='assumptions':payload['fixed_assumptions']['angle_count']=1
    else:
        data=json.dumps(payload).replace('"connection": {','"connection": {"P": 1,')
        with pytest.raises(ValueError):decode_project(data)
        return
    with pytest.raises((ValueError,TypeError)):decode_project(json.dumps(payload))


def test_default_ui_native_groups_and_current_result():
    at=fresh();c=CornerGusset()
    assert at.session_state[PROJECT]==c.to_dict()
    assert at.session_state[RESULT]==analyze(c)
    assert checks_complete(at.session_state[RESULT])
    assert len(at.expander)>=6
    assert not any(x.key and 'N0' in x.key for x in at.number_input)
    assert at.checkbox(key=_key('other_loads_excluded')).value is True
    assert at.selectbox(key=_key('load_convention')).value=='COMPLETE_CUTS'


def test_atomic_rejected_import_preserves_report_and_draft():
    at=fresh();button(at,'Gerar memória de canto').click().run()
    snapshot={k:deepcopy(at.session_state[k]) for k in (PROJECT,RESULT,DRAFT,REPORT,ACCEPTED,TEMPLATE)}
    bad=deepcopy(snapshot[PROJECT]);bad['connection'].pop('case_id')
    upload(at,bad)
    assert any('Não foi possível abrir' in x.value for x in at.error)
    for key,value in snapshot.items():assert at.session_state[key]==value,key


def test_report_invalidated_by_load_change_and_navigation_preserves_draft():
    at=fresh();button(at,'Gerar memória de canto').click().run()
    assert REPORT in at.session_state
    at.number_input(key=_key('P')).set_value(200.).run()
    assert REPORT not in at.session_state
    assert at.session_state['cg_mc_current']==memory_text(CornerGusset.from_dict(at.session_state[PROJECT]))
    current=deepcopy(at.session_state[PROJECT])
    at.selectbox(key='test_page').set_value('Outra').run()
    at.text_input(key='other_project').set_value('Outra família não modificada').run()
    at.selectbox(key='test_page').set_value('Canto').run()
    assert not at.exception and at.session_state[PROJECT]==current
    at.checkbox(key=_key('other_loads_excluded')).uncheck().run()
    assert at.session_state[RESULT]['status']!='PASS'
    assert button(at,'Gerar memória de canto').disabled


def test_steel_and_weld_controls_independent_with_exact_load():
    c=replace(CornerGusset(),P=100000.123456789)
    at=fresh(c)
    at.selectbox(key=_key('column_steel')).set_value('ASTM A36').run()
    data=at.session_state[PROJECT]['connection']
    assert data['P']==c.P
    for key in ('angle_steel','gusset_steel','beam_steel','continuity_steel'):assert data[key]==getattr(c,key)
    at.number_input(key=_key('fw_continuity')).set_value(490.).run()
    data=at.session_state[PROJECT]['connection']
    for key in ('fw_brace','fw_root','fw_joint'):assert data[key]==getattr(c,key)


def test_drawing_physical_ids_and_deterministic_exports():
    c=CornerGusset();svg=image_bytes(c,fmt='svg');root=ET.fromstring(svg)
    ids={x.get('id') for x in root.iter()}
    for side in ('positive','negative'):
        for place in ('heel','toe'):assert 'T-'+side+'-'+place+'-fillet' in ids
        assert 'continuity-'+side+'-clipped-plate' in ids
        for edge in ('loaded','opposite'):assert 'continuity-'+side+'-'+edge+'-double-fillet' in ids
        assert 'continuity-'+side+'-web-double-fillet' in ids
    for key in ('beam_cut-named-cut','upper_column_cut-named-cut','lower_column_cut-named-cut','beam-upper-CJP','beam-lower-CJP','gusset-clipped-polygon'):assert key in ids
    assert image_bytes(c,fmt='svg')==svg
    png=image_bytes(c,fmt='png');assert png.startswith(b'\x89PNG') and png==image_bytes(c,fmt='png')


def test_value_free_convention_is_independent_of_loads_and_status():
    c=CornerGusset();svg=effort_convention_svg(c)
    assert svg==effort_convention_svg(replace(c,P=-999999.,beam_cut_M=88888888.,upper_column_cut_Fy=333333.))
    for word in ('+Fx','+Fy','+M','anti-horário','derivado','sem valores'):assert word in svg
    assert '100000' not in svg and 'PASS' not in svg
    assert effort_convention_png(c).startswith(b'\x89PNG')


def test_exports_recompute_instead_of_trusting_stale_result():
    c=replace(CornerGusset(),workpoint_offset=100.)
    stale=analyze(CornerGusset())
    actual=analyze(c);assert actual['status']!='PASS'
    svg=image_bytes(c,stale,fmt='svg').decode()
    assert 'Linha excêntrica real' in svg
    text=texts(create_report(c,stale))
    assert actual['status'] in text and input_fingerprint(c) in text
    assert 'não tem conclusão local favorável completa' in text


def test_word_compact_and_detailed_are_component_led_and_source_bound():
    c=CornerGusset();r=analyze(c)
    compact=create_report(c);detailed=create_report(c,detailed=True)
    assert compact.startswith(b'PK') and detailed.startswith(b'PK')
    a,b=texts(compact),texts(detailed)
    for term in ('COMPLETE_CUTS','D · viga completo','U · pilar superior completo','quatro chapas','CJP','compressão','continuidade'):
        assert term in a
    assert len(physical_envelopes(r))<len(r['checks'])
    assert 'Auditoria detalhada' not in a and 'Auditoria detalhada' in b
    assert all(str(x['id']) in b for x in r['checks'])
    assert 'MEMÓRIA LOCAL' in memory_text(c) and 'LINHAGEM' in memory_text(c)


def test_unbounded_failed_capacity_and_optional_diagnostics_are_distinct():
    unbounded={'id':'column_panel_zone','component':'panel','demand':100.,'resistance':0.,
               'utilization':None,'utilization_unbounded':True,'status':'FAIL'}
    result={'status':'FAIL','complete':True,'checks':[unbounded]}
    assert checks_complete(result)
    group=physical_envelopes(result)[0]
    assert group['status']=='FAIL' and utilization_text(group)=='sem capacidade'
    diagnostic={'id':'beam_local_NM_yield_screen','component':'local_member_material','demand':2.,
                'resistance':1.,'utilization':2.,'status':'FAIL','diagnostic_only':True}
    required={'id':'required','component':'beam_joint','demand':1.,'resistance':2.,'utilization':.5,'status':'PASS'}
    result={'status':'PASS','complete':True,'checks':[required,diagnostic]}
    assert approved(result)
    assert physical_envelopes(result)[1]['status']=='DIAGNOSTIC_ONLY'


@pytest.mark.parametrize('change',[{'workpoint_offset':100.,'P':1000000.},{'matching_cjp':False,'P':1000000.}])
def test_mixed_failed_and_unqualified_case_blocks_resistant_word(change):
    c=replace(CornerGusset(),**change);r=analyze(c)
    assert r['status']=='FAIL' and r['complete'] is False
    assert not checks_complete(r) and not approved(r)
    at=fresh(c)
    assert button(at,'Gerar memória de canto').disabled
    assert REPORT not in at.session_state
    assert any('VERIFICAÇÃO INCOMPLETA' in x.value for x in at.error)
    assert 'VERIFICAÇÃO INCOMPLETA' in texts(create_report(c))
    pure=analyze(replace(CornerGusset(),P=800000.))
    assert pure['status']=='FAIL' and checks_complete(pure)
