"""Focused Streamlit acceptance tests for the native R016 family."""
import json
from dataclasses import replace
from pathlib import Path

import pytest
from streamlit.testing.v1 import AppTest

from lro.double_angle import FAMILY, presets
from lro.models import KGF
from lro.w_splice import FAMILY as W_FAMILY, COMPONENT_VERSION as W_COMPONENT_VERSION

APP = Path(__file__).resolve().parents[1] / 'app.py'


def open_app():
    at = AppTest.from_file(str(APP), default_timeout=60).run()
    assert not at.exception
    at.selectbox(key='connection_family').set_value(FAMILY).run()
    assert not at.exception
    return at


def button(at, label):
    return next(item for item in at.button if item.label == label)


def upload(at, connection):
    data = connection.to_dict() if hasattr(connection, 'to_dict') else connection
    at.get('file_uploader')[0].upload('R016.json', json.dumps(data).encode(), 'application/json').run()
    button(at, 'Carregar R016').click().run()
    assert not at.exception
    return at


def test_native_family_distinct_members_interfaces_and_W_scope_unchanged():
    at = open_app()
    raw = at.session_state['_double_angle_project']
    result = at.session_state['_double_angle_result']
    assert raw['connection_type'] == 'double_angle_r016_bolted_shear'
    assert raw['component_version'] == '0.9.1-angle-dev'
    assert raw['connection']['beam'] != raw['connection']['support']
    assert raw['connection']['angle_count'] == 2
    for key in ('beam_leg', 'support_leg', 'beam_gauge', 'support_gauge', 'web_rows',
                'support_rows', 'web_pitch', 'support_pitch', 'web_end_top', 'support_end_top'):
        assert at.number_input(key='da_' + key)
    assert result['checks'] and result['geometry']['valid']
    assert len(at.metric) == 2
    assert W_FAMILY == 'Emenda W · M004 · tração axial'
    assert W_COMPONENT_VERSION == '0.9.0-w-dev'
    assert W_FAMILY in at.selectbox(key='connection_family').options
    at.selectbox(key='connection_family').set_value(W_FAMILY).run()
    assert not at.exception
    assert at.session_state['_w_splice_project']['component_version'] == W_COMPONENT_VERSION


def test_signed_V_and_independent_interface_values_survive_family_switch():
    at = open_app()
    at.number_input(key='da_V_kgf').set_value(-10000.).run()
    assert at.session_state['_double_angle_result']['load_model']['Vsd_N'] == -10000. * KGF
    at.number_input(key='da_beam_leg').set_value(80.).run()
    at.number_input(key='da_support_pitch').set_value(55.).run()
    native = at.session_state['_double_angle_project']
    assert native['connection']['V'] == -10000. * KGF
    assert native['connection']['beam_leg'] == 80.
    assert native['connection']['support_leg'] == 76.
    assert native['connection']['web_pitch'] == 60.
    assert native['connection']['support_pitch'] == 55.
    at.selectbox(key='connection_family').set_value('Single plate').run()
    at.selectbox(key='connection_family').set_value(FAMILY).run()
    assert not at.exception
    assert at.number_input(key='da_V_kgf').value == -10000.
    assert at.session_state['_double_angle_project'] == native


@pytest.mark.parametrize('key,field,unit', [('da_N_kgf', 'N', KGF),
                                           ('da_M_kgfm', 'M', KGF * 1000),
                                           ('da_torsion_kgfm', 'torsion', KGF * 1000)])
def test_separate_unsupported_actions_block_approval(key, field, unit):
    at = open_app()
    at.number_input(key=key).set_value(-1.).run()
    assert not at.exception
    assert at.session_state['_double_angle_project']['connection'][field] == -unit
    assert at.session_state['_double_angle_result']['status'] == 'OUTSIDE_R016_SCOPE'
    assert not at.success
    assert button(at, 'Gerar memória R016').disabled


def test_import_exact_roundtrip_unsupported_loads_and_hidden_fields():
    base = next(iter(presets().values()))
    c = replace(base, project='Importação sem normalização', V=-12345.6789, N=123.456789,
                M=-234567.891234, torsion=345678.912345, notes='Preservar todas as ações.',
                web_threads_excluded=True, support_threads_excluded=False,
                support_edge_top=321.25, support_edge_bottom=654.75,
                beam=replace(base.beam, name='Viga real independente', source='Medição viga'),
                support=replace(base.support, name='Pilar real independente', source='Medição apoio'))
    at = upload(open_app(), c)
    assert at.session_state['_double_angle_project'] == c.to_dict()
    assert at.session_state['_double_angle_result']['status'] == 'OUTSIDE_R016_SCOPE'
    assert at.text_input(key='da_beam_source').value == 'Medição viga'
    assert at.text_input(key='da_support_source').value == 'Medição apoio'
    at.selectbox(key='connection_family').set_value(W_FAMILY).run()
    at.selectbox(key='connection_family').set_value(FAMILY).run()
    assert not at.exception
    assert at.session_state['_double_angle_project'] == c.to_dict()


def test_import_unrecognized_options_remains_explicit_and_unapproved():
    base = next(iter(presets().values()))
    c = replace(base, kind='imported_other_support', hole_type='imported_slot',
                exposure='imported_exposure', cope='imported_cope', db=18.6)
    at = upload(open_app(), c)
    assert at.session_state['_double_angle_project'] == c.to_dict()
    for field in ('kind', 'hole_type', 'exposure', 'cope', 'db'):
        assert at.selectbox(key='da_' + field).value == getattr(c, field)
    assert not at.success
    assert not at.session_state['_double_angle_result']['global_pass']
    assert button(at, 'Gerar memória R016').disabled


def test_custom_profile_geometry_survives_hidden_widgets_and_family_switch():
    at = open_app()
    at.selectbox(key='da_beam_name').set_value('W personalizado').run()
    at.number_input(key='da_beam_tw').set_value(9.25).run()
    at.text_input(key='da_beam_source').set_value('Perfil verificado em campo').run()
    catalog_name = next(iter(presets().values())).beam.name
    at.selectbox(key='da_beam_name').set_value(catalog_name).run()
    at.selectbox(key='connection_family').set_value('Single plate').run()
    at.selectbox(key='connection_family').set_value(FAMILY).run()
    at.selectbox(key='da_beam_name').set_value('W personalizado').run()
    assert not at.exception
    assert at.number_input(key='da_beam_tw').value == 9.25
    assert at.text_input(key='da_beam_source').value == 'Perfil verificado em campo'
    assert at.session_state['_double_angle_project']['connection']['support'] == next(iter(presets().values())).to_dict()['connection']['support']


def test_report_invalidation_on_geometry_and_unsupported_action_changes():
    at = open_app()
    button(at, 'Gerar memória R016').click().run()
    assert not at.exception
    assert at.session_state['da_report'][2].startswith(b'PK')
    old_digest = at.session_state['da_report'][0]
    at.number_input(key='da_support_edge_top').set_value(501.).run()
    assert not at.exception and 'da_report' not in at.session_state
    button(at, 'Gerar memória R016').click().run()
    assert not at.exception
    assert at.session_state['da_report'][0] != old_digest
    at.number_input(key='da_M_kgfm').set_value(1.).run()
    assert not at.exception and 'da_report' not in at.session_state
    assert button(at, 'Gerar memória R016').disabled
    assert not at.success


def test_invalid_geometry_is_blocked_and_recovers():
    at = open_app()
    at.number_input(key='da_length').set_value(1000.).run()
    assert not at.exception
    assert at.session_state['_double_angle_result']['status'] == 'INVALID_GEOMETRY'
    assert not at.success
    assert button(at, 'Gerar memória R016').disabled
    at.number_input(key='da_length').set_value(next(iter(presets().values())).length).run()
    assert not at.exception
    assert at.session_state['_double_angle_result']['geometry']['valid']
    assert at.session_state['_double_angle_result']['checks']


def test_bolt_preset_then_explicit_hole_is_not_overwritten():
    at = open_app()
    at.selectbox(key='da_db').set_value(24.).run()
    assert not at.exception
    assert at.number_input(key='da_hole_diameter').value == 26.
    at.number_input(key='da_hole_diameter').set_value(27.).run()
    assert not at.exception
    assert at.session_state['_double_angle_project']['connection']['hole_diameter'] == 27.


def test_invalid_import_leaves_current_project_intact():
    at = open_app()
    original = at.session_state['_double_angle_project']
    broken = dict(original)
    broken['connection_type'] = 'wrong_family'
    upload(at, broken)
    assert 'Não foi possível abrir:' in at.session_state['da_import_error']
    assert at.session_state['_double_angle_project'] == original


def test_partial_result_and_expanded_formula_do_not_crash_or_approve(monkeypatch):
    import lro.double_angle_ui as ui
    monkeypatch.setattr(ui, 'evaluate', lambda c: {
        'status': 'ENGINEERING_MODEL_PENDING', 'global_pass': False,
        'geometry': {}, 'summary': {'governing_label': 'Modelo incompleto'},
        'checks': [{'id': 'partial', 'formula': {'equation': 'V/2', 'terms': ['V', 2]}}],
        'load_model': {'additional_interface_data': {'note': 'Dados de investigação'}}, 'issues': [],
    })
    at = open_app()
    assert not at.exception
    assert not at.success
    assert button(at, 'Gerar memória R016').disabled
    assert len(at.metric) == 2


def test_zero_real_shear_keeps_adopted_minimum_separate():
    at = open_app()
    at.number_input(key='da_V_kgf').set_value(0.).run()
    assert not at.exception
    native = at.session_state['_double_angle_project']
    result = at.session_state['_double_angle_result']
    assert native['connection']['V'] == 0.
    assert result['load_model']['Vsd_N'] == 0.
    assert result['load_model']['Vd_N'] == 45000.
    assert result['summary']['actual_governing_utilization'] == 0.
    assert result['summary']['governing_utilization'] > 0.


def test_zero_end_clearance_import_preserves_local_checks_but_no_green_result():
    c=replace(next(iter(presets().values())),gap=0.)
    at=upload(open_app(),c)
    r=at.session_state['_double_angle_result']
    assert at.number_input(key='da_gap').value==0.
    assert at.session_state['_double_angle_project']==c.to_dict()
    assert r['geometry']['valid'] and r['checks']
    assert r['status']=='ENGINEERING_MODEL_PENDING' and not r['global_pass']
    assert not at.success
    assert not button(at,'Gerar memória R016').disabled
