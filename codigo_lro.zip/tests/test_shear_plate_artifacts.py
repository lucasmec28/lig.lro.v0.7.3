"""Geometria da chave, sinais e memória Word sem aprovação do dispositivo."""
from dataclasses import replace
from io import BytesIO
import json
import zipfile
import xml.etree.ElementTree as ET

import pytest

from lro.models import Profile
from lro.base_plate import BasePlate, evaluate
from lro.base_plate_drawing import image_bytes
from lro.base_plate_report import create_report


P = Profile('I 300 × 150', 'Soldado', 40., 300., 150., 8., 12., 276., 7008.)


def fixture(**kwargs):
    c = BasePlate(P, a1=50., a2=100., db=19.05, tp=50.8,
                  N=0., M=0., V=100000., fck=20., grout_t=40.,
                  shear_path='plate', lug_bh=100., lug_bv=100.,
                  lug_t=50.8, lug_steel='ASTM A36')
    return replace(c, **kwargs)


def doc_xml(c, detailed=True):
    data = create_report(c, evaluate(c), detailed)
    with zipfile.ZipFile(BytesIO(data)) as archive:
        return archive.read('word/document.xml').decode()


def test_drawing_dimensions_use_actual_plate_and_grout(monkeypatch):
    import lro.base_plate_drawing as drawing
    c = fixture(grout_t=30., lug_bh=120., lug_bv=130., lug_t=45.)
    captured = []
    close = drawing.plt.close

    def remember(fig):
        if hasattr(fig, 'axes'):
            captured.append(fig)
        close(fig)

    monkeypatch.setattr(drawing.plt, 'close', remember)
    svg = image_bytes(c, evaluate(c), 'svg').decode()
    fig = captured[-1]
    patches = {p.get_gid(): p for ax in fig.axes for p in ax.patches if p.get_gid()}
    plan = patches['lug_plan']
    assert (plan.get_x(), plan.get_y(), plan.get_width(), plan.get_height()) == (-22.5, -60., 45., 120.)
    sec = patches['lug_section']
    assert (sec.get_x(), sec.get_y(), sec.get_width(), sec.get_height()) == (-22.5, -130., 45., 130.)
    grout = patches['actual_grout']
    assert grout.get_y() == -30. and grout.get_height() == 30.
    assert patches['lug_applied_shear']._posA_posB[0][1] == c.tp
    assert patches['lug_bearing_reaction']._posA_posB[0][1] == -(130. + 30.) / 2
    assert 'eV = 130.8' in svg and 'en = 30' in svg
    assert 'bh paralelo a y; tpv paralelo a x.' in svg


@pytest.mark.parametrize('sign', [1, -1])
def test_pure_shear_roundtrip_drawing_and_word(sign):
    c = fixture(V=sign * 100000.)
    c = BasePlate.from_dict(json.loads(json.dumps(c.to_dict())))
    r = evaluate(c)
    assert r.geometry['M_effective'] == pytest.approx(sign * 12.08e6)
    svg = image_bytes(c, r, 'svg').decode()
    assert f'ΔM = V · eV = {sign * 12.08:+.3f} kN·m' in svg
    assert 'M positivo horário' in svg
    assert 'dispositivo completo pendente' in svg
    xml = doc_xml(c)
    assert ('12,080000' if sign > 0 else '-12,080000') in xml
    assert 'M informado com sinal' in xml and 'Mef = M informado + ΔM' in xml
    assert 'Vw igual à resistência de contato' in xml
    assert '145,714286' in xml and '10,200000' in xml
    assert 'metal de solda' in xml and 'metal-base' in xml
    assert 'flexão local da placa' in xml and 'efeitos de borda do concreto' in xml
    assert 'não aprova o dispositivo completo' in xml


def test_signed_moments_are_not_added_as_magnitudes():
    c = fixture(M=-12.08e6)
    r = evaluate(c)
    assert r.geometry['M_effective'] == pytest.approx(0.)
    svg = image_bytes(c, r, 'svg').decode()
    assert 'Mef = M + ΔM = -12.080 + (+12.080) = +0.000 kN·m' in svg
    xml = doc_xml(c)
    assert '-12,080000' in xml
    assert 'somente depois se toma o módulo' in xml


def test_each_lug_equation_is_native_editable_math():
    c = fixture()
    result = evaluate(c)
    root = ET.fromstring(doc_xml(c))
    ns = {'m': 'http://schemas.openxmlformats.org/officeDocument/2006/math'}
    math_strings = [''.join(node.itertext()) for node in root.findall('.//m:oMath', ns)]
    rows = [row for row in result.checks if row.id.startswith('bp_lug_')]
    assert rows
    for row in rows:
        assert row.equation in math_strings
    assert any('Mef' in value or 'Mef' in value.replace(' ', '') for value in math_strings)
    assert '<m:f>' in doc_xml(c)


def test_weld_actions_are_not_capped_by_steel_or_applied_shear():
    c = fixture(a2=180., lug_bh=200., lug_bv=150., lug_t=31.75, tp=38.1, fck=30.)
    xml = doc_xml(c)
    assert '801,428571' in xml and '76,135714' in xml
    assert 'Não se limita Vw pela menor resistência da chapa' in xml
    assert 'Não se calcula resistência de solda' in xml
    assert 'qSd' not in xml and 'qRd' not in xml


def test_non_plate_routes_keep_their_drawing_and_report_scope():
    for path in ('friction', 'external'):
        c = fixture(shear_path=path, N=400000., V=1000.,
                    external_shear_rd=2000., external_shear_ref='MC-01')
        svg = image_bytes(c, evaluate(c), 'svg').decode()
        assert 'CORTE NO PLANO DA ALMA E REAÇÕES' in svg
        assert 'lug_plan' not in svg
        xml = doc_xml(c)
        assert 'Ações obrigatórias para dimensionar as soldas' not in xml
        assert 'Mef = M informado + ΔM' not in xml
