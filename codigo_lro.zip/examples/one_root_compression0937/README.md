# SRC1 geometria original com sinal invertido

O exemplo é o caso200kN anterior com somente o sinal invertido. Nenhuma dimensão, material ou força foi ajustada para obter aprovação. Permanece falha físicaη1,079466667 e vínculos reais desconhecidos. A resistência da faixa556,476924kN é condicional, não conclusão favorável do detalhe. Nenhum vão lateral ou travamento é fornecido por este exemplo. Os demais cenários sintéticos constam apenas de testes e da revisão independente.
