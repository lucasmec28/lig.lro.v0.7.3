# Exemplos de2L opostas parafusadas ·0.9.31

Abra a rota “Ligação1L /2L-T /2L opostas–gusset–mesaW · parafusada completa” e carregue um dos projetos JSON. A identidade nativa seleciona a disposição2L opostas; não converte projetos anteriores. Valores são exemplos de cálculo, sem liberação de fabricação.

01 é o exemplo prático principal300×300×12,5mm/θ80°/N100kN, com seis parafusos de corte simples e memória resumida/detalhada.02 usa pilar W com o mesmo sistema local;03 espelha a inclinação;04 é perpendicular.05 conserva a aceitação refinada em150kN;06 falha por resistência;07 falha no domínio real tracionado.08 preserva força real nula e mínimo separado;09 deixa talão pendente;10 distingue furo físico/dedução nominal;11 modifica somente o aço da chapa.

O envelope manual de talão12,35mm é hipótese demonstrativa explícita. Não é raio Gerdau nem comprovação de peça real. Confira a dimensão de montagem real antes de concluir o detalhamento.

No caso01, valores independentes de referência são: bloco da L0,421153774; solda de raiz0,387391955; parcial refinado0,196108418. Os diagnósticos nominais negativos no trecho de introdução permanecem visíveis; o ligamento não perfurado/raiz está tracionado.

PNG/SVG e Word são produzidos pelos módulos atuais com recalculo vinculado à entrada. Consulte EXAMPLE_INDEX.json para estados reais produzidos. Limites: tração estática, contato direto e raiz única na mesa exterior W; sem qualificação global/compressão/fadiga/canto com duas bordas apoiadas.
