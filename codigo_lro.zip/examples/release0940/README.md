# Current 0.9.40 native inputs and full results

These 42 JSONs were freshly generated on the final held corrected 0.9.40 source. The exact path/size/hash map and selection provenance are in docs/qualification_combined0940/current_examples. Their original component identities are retained; they are not old rendered outputs relabeled as current.

The set covers ten cap fixtures, two Lig18 extensions, W inner-on/outer-only and seven corrected 4E witnesses. Adverse and pending states are intentional. Four selected compact/detailed 4E Word reports and all prior84 current artifacts are in the separate selected examples delivery; other generated reports remain review-only and reproducible. No example certifies fabrication or a real project's full structural system.
