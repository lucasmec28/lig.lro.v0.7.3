# Exemplos delimitados da end plate rotulada

Todos mantêm a qualificação local completa em aberto. Componentes_com_escopo_incompleto e Compressao_sinais_preservados têm componentes numericamente atendidos com escopo incompleto; Passo_51_nao_conforme preserva p=51 mm e acusa mínimo 51,435 mm; Condicao_metodo_nao_satisfeita isola espessura construtiva; Falha_resistente preserva a falha finita real. São projetos de demonstração/regressão, não aprovação para obra. Abrir reavalia os dados e ignora resultados salvos. Método: ../../docs/PINNED_END_PLATE_AUDIT0911_METHOD.md.
