"""From source root: python examples/mre12_0941/reproduce_examples.py [--artifacts]."""
from pathlib import Path
import sys,json
from dataclasses import replace
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from lro.end_plate import presets,evaluate
BASE=next(c for c in presets().values() if c.is_mre12)
CASES={'MRE12_positive':BASE,'MRE12_negative_MV':replace(BASE,M=-BASE.M,V=-BASE.V),
       'MRE12_minimum':replace(BASE,M=-60e6,N=-2000.,V=-11000.),
       'MRE12_pfi_saturated':replace(BASE,pfi=110.),
       'MRE12_nominal_plate_fail':replace(BASE,tp=18.)}
for name,c in CASES.items():
    out=Path(__file__).parent;data=c.to_dict();(out/(name+'.json')).write_text(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    if '--artifacts' in sys.argv:
        from lro.end_plate_drawing import image_bytes
        from lro.end_plate_report import create_report
        for fmt in ('png','svg'):(out/(name+'.'+fmt)).write_bytes(image_bytes(c,fmt))
        for detailed in (False,True):(out/(name+('_detailed' if detailed else '_compact')+'.docx')).write_bytes(create_report(c,evaluate(c),detailed))
    print(name,data['verification']['status'])
