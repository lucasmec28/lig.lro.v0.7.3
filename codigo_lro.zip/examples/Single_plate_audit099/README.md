# Exemplos históricos da revisão 0.9.9

Os arquivos desta pasta são snapshots históricos de regressão da versão 0.9.9. As memórias Word podem conservar a explicação antiga de que o P901 ainda não havia sido conferido. Esse texto não descreve o estado atual da versão 0.9.10: o PDF original foi recuperado e os exemplos pertinentes foram verificados.

As novas memórias geradas pelo aplicativo 0.9.10 usam a qualificação vigente: a pendência de fonte remanescente é o domínio integral da dispensa automática da Tabela 10-9 do Manual. Consulte `../../docs/SINGLE_PLATE_AUDIT099_METHOD.md`.

A mesma ressalva se aplica à memória histórica `../Teste_usuario_enrijecedor_oposto.docx`.

Estes casos não foram regenerados nem ajustados para aprovação. Abra os projetos JSON no aplicativo atual e gere uma nova memória para obter os cálculos e a conclusão vigentes.
