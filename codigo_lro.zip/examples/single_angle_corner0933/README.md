# Exemplos de canto com uma cantoneira

Projetos nativos 0.9.33; abrir na família existente de canto (19ª rota). São 14 entradas, incluindo as duas faces, geometrias40/50°, duas regiões comprimidas efetivas, outro catálogo, materiais independentes, continuidade120, mudança equivalente do corte da viga, falha por carga, compressão da diagonal, afastamento100 e ações zero.

C1_positive e C1_negative contêm exatamente uma L76,2×7,94 com dois filetes5×220 e100kN. Chapa12, duas raízes duplas e nó completo preservados. A força integral pertence à única L; não usar N/2. O afastamento físico28,1mm e momento bruto2,81kNm são desprezados pela idealização estática nominal de extremidade NBR6.1.8.2, nunca cancelados ou qualificados em3D.

Resultados e MC são recalculados das entradas; as imagens correspondem aos casos nomeados. Word compacto/detalhado do C1positivo, compacto da face negativa e compacto50° mostram o alcance efetivo. Os JSON históricos de2L permanecem na pasta corner_gusset0932 e abrem sem conversão silenciosa de topologia. Resultados de método ausente são diagnósticos e não têm Word de aprovação emitido pelo aplicativo.
