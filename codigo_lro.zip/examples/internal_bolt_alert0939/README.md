# Lig18 internal bolt examples

The original preset is used with extension=0 mm and extension=10 mm. Both retain the explicit internal perforated-fin qualification/access pendency rather than asserting blanket solid-on-solid overlap. Result payloads preserve all current checks and warnings. The portable independent geometry replay reconstructs these inputs and verifies the unqualified status. No fin design method or fabrication approval is introduced.
