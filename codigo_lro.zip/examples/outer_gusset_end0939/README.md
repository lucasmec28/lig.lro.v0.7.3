# Current outer-cut examples

Ten native projects and full-precision current result payloads cover welded 1L at 45/90/135 degrees, welded 2L-T, one-root bolted 1L/2L-T, and all four corner adapters. INDEX.json identifies their actual statuses. An example marked outside scope remains outside scope; the new cap is not permission to ignore mixed compression or other failures.

The payloads correspond to the independent reviewed active-cut figures. Subsequent caption placement changes affect only no-trim drawings, and the exact-one-leg boundary correction does not change these margins. Final artifact parity verifies that connection.

Use the route-specific strict native reader and current evaluator. The real figure/export APIs reevaluate current inputs rather than trusting these saved results. PNG/Word/PDF review renderings are selected separately outside APP; all required geometry and numerical inputs remain here.
