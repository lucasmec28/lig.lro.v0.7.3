# Exemplos nativos da ligação de canto 2L-T

C1 é o caso estático completo qualificado: um par de cantoneiras, chapa única recortada com duas raízes, ligação direta CJP nas mesas e filetes na alma, e dois pares horizontais de continuidade. O Word resumido e detalhado, os desenhos e o texto MC são recalculados das entradas nativas. Não são certificados de fabricação ou de estabilidade global.

- C1.json: caso base, localmente atendido.
- phi50.json: mesma família com inclinação de 50 graus, recalculada; não é outro preset silenciosamente convertido.
- offset100_unverified.json: linha real afastada 100 mm; redistribuição excêntrica não qualificada.
- compressed_gusset_unverified.json: phi80, altura1600, início u1300, margem final da raiz no pilar1010; corte U em y1900mm com M19kN·m, transportado do corte original para conservar a mesma ação completa. A pegada das soldas cabe na chapa; há raiz comprimida não qualificada e faixa de Whitmore não inteiramente contida. Não representa uma seção de gusset inteiramente qualificada.
- load_fail.json: força de diagonal800kN, mantendo as ações completas explícitas dos cortes; falha local.
- missing_loads_unverified.json: ausência de outras cargas não declarada, sem ações substitutas; caso incompleto, sem atribuir zero a dados desconhecidos.

EXPECTED_STATES.json registra os estados efetivamente produzidos na geração. As figuras C1 e phi50 contêm o caso real; effort_convention mostra apenas a convenção positiva sem valores. Não usar estas figuras como desenho executivo.

- zero_brace_frame_retained.json: N da diagonal explicitamente zero; as seis ações D/U permanecem e continuam solicitando a ligação.
- all_actions_zero.json: N e as seis ações D/U explicitamente nulos, sem substituir a força por um mínimo artificial. Os detalhes e materiais ainda precisam atender.
