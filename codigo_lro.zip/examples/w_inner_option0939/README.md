# Conventional W inner-flange-plate option examples

inner_on.json uses the balanced conventional topology with inner and outer flange plates. outer_only.json omits the four inner flange plates, retaining the separately entered flange gauge and the actual outer-only force path.

These native inputs and full-precision result payloads were freshly regenerated on 0.9.39 hold v3 and match the independently held W-module previews exactly. Their generation identity and final-runtime bridge are in docs/qualification_combined0939/current_examples. They do not supply actual-project restraint or fabrication evidence. The on case remains pending; the outer-only mandatory witness retains a flange-plane failure at utilization 1.021251536153864. That failure is intentional evidence, not an example adjusted to pass.

Current rendering can be reproduced with lro.w_splice_conventional_drawing.image_bytes/drawing_svg and lro.w_splice_conventional_report.create_report after strict WConventional.from_dict import. Selected PNG/Word deliverables remain outside APP; this directory contains everything required to reconstruct their numerical model.
