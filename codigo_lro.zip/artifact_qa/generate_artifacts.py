#!/usr/bin/env python3
"""Replay the isolated 2L artifacts against an explicitly supplied source tree.

Usage: PYTHONPATH=<installed dependencies> python generate_artifacts.py \
       --source /absolute/current/source --output-dir /absolute/output
No source files are changed. Native project and result records are separate.
"""
from argparse import ArgumentParser
from dataclasses import replace
from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path
import sys


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--default-only', action='store_true')
    args = parser.parse_args()
    source = args.source.expanduser().resolve(strict=True)
    target = args.output_dir.expanduser().resolve()
    required = [source / 'lro' / ('welded_support_double_angle' + tail + '.py')
                for tail in ('', '_ui', '_drawing', '_report')]
    if not all(path.is_file() for path in required):
        parser.error('Source must contain all four current welded-support double-angle modules.')
    target.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault('MPLCONFIGDIR', str(target / '.cache' / 'matplotlib'))
    os.environ.setdefault('XDG_CACHE_HOME', str(target / '.cache'))
    sys.path.insert(0, str(source))
    from lro.welded_support_double_angle import presets, evaluate, CONNECTION_TYPE
    from lro.welded_support_double_angle_drawing import drawing_svg, image_bytes
    from lro.welded_support_double_angle_report import create_report
    import lro.welded_support_double_angle as engine
    if Path(engine.__file__).resolve().parent.parent != source:
        raise RuntimeError('Resolved engine is not the explicitly supplied source tree.')
    base = next(iter(presets().values()))
    cases = {'default': base}
    if not args.default_only:
        cases.update({
            'high_load': replace(base, V=500000., project='2L · resistência não atendida'),
            'reverse_load': replace(base, V=-100000., project='2L · V ascendente fora do domínio'),
            'field_weld_access_pending': replace(base, weld_tool_radius=100., project='2L · envelope de soldagem pendente'),
            'zero_radius_pending': replace(base, root_radius=0., project='2L · raio interno pendente'),
            'wrong_assembly': replace(base, assembly='both_shop_welded', project='2L · montagem fora do domínio'),
        })
    target.mkdir(parents=True, exist_ok=True)
    records = []
    for name, c in cases.items():
        before = c.to_dict()
        r = evaluate(c)
        payloads = {
            name + '.json': json.dumps(before, ensure_ascii=False, indent=2, allow_nan=False).encode(),
            name + '.result.json': json.dumps(r, ensure_ascii=False, indent=2, allow_nan=False).encode(),
            name + '.svg': drawing_svg(c, r).encode(),
            name + '.png': image_bytes(c, r),
            name + '.docx': create_report(c, r),
        }
        assert c.to_dict() == before
        for filename, payload in payloads.items():
            (target / filename).write_bytes(payload)
        records.append(dict(case=name, status=r['status'], local_pass=r['global_pass'],
                            files={filename: sha256(payload).hexdigest() for filename, payload in payloads.items()}))
    receipt = dict(created_utc=datetime.now(timezone.utc).isoformat(), source=str(source),
                   connection_type=CONNECTION_TYPE, default_only=args.default_only,
                   source_sha256={str(path.relative_to(source)): sha256(path.read_bytes()).hexdigest() for path in required},
                   artifacts=records, scope='Current-input final-state local artifacts only; no temporary-stage or global certification.',
                   render_qa='DOCX files still require canonical render and pixel inspection in the consuming environment.')
    (target / 'generation_receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(dict(source=str(source), output=str(target), cases=len(records),
                          receipt=str(target / 'generation_receipt.json')), ensure_ascii=False))


if __name__ == '__main__':
    main()
