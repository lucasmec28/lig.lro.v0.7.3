import json
import hashlib
import math
from dataclasses import replace
from pathlib import Path
import streamlit as st

st.set_page_config(page_title='LRO Ligações',page_icon='🔩',layout='wide')

# Diagnóstico antes dos imports: a distribuição precisa acompanhar app.py.
_root = Path(__file__).resolve().parent
_required = ['data/profiles.json', 'data/gerdau_equal_angles.json'] + ['lro/' + name + '.py' for name in (
    '__init__', 'angle_catalog', 'angle_catalog_ui', 'angle_catalog_selection', 'models', 'engine', 'examples', 'drawing', 'report', 'benchmarks',
    'guided_selection', 'load_conventions', 'display_precision',
    'corner_gusset', 'corner_compression', 'bolted_corner', 'bolted_corner_compression', 'corner_gusset_ui', 'corner_gusset_drawing', 'corner_gusset_report', 'corner_gusset_presentation',
    'welded_opposed_angle_gusset', 'welded_opposed_angle_gusset_ui', 'welded_opposed_angle_gusset_drawing',
    'welded_opposed_angle_gusset_report', 'welded_opposed_angle_gusset_presentation',
    'bolted_opposed_angle_gusset', 'bolted_opposed_gusset_geometry',
    'bolted_opposed_angle_gusset_drawing', 'bolted_opposed_angle_gusset_report', 'bolted_opposed_angle_gusset_presentation',
    'bolted_gusset_geometry', 'bolted_angle_gusset', 'bolted_angle_gusset_ui', 'bolted_angle_gusset_drawing',
    'bolted_angle_gusset_report', 'bolted_angle_gusset_presentation',
    'welded_angle_gusset', 'welded_angle_gusset_ui', 'welded_angle_gusset_drawing',
    'welded_angle_gusset_report', 'welded_angle_gusset_presentation',
    'welded_double_angle_gusset', 'welded_double_angle_gusset_ui', 'welded_double_angle_gusset_drawing',
    'welded_double_angle_gusset_report', 'welded_double_angle_gusset_presentation',
    'one_root_compression', 'one_root_compression_report',
    'gusset_outer_end', 'gusset_outer_sections', 'gusset_outer_end_ui', 'gusset_outer_end_drawing',
    'welded_w_splice', 'welded_w_splice_ui', 'welded_w_splice_drawing', 'welded_w_splice_report', 'welded_w_splice_presentation',
    'axial_single_angle', 'axial_single_angle_ui', 'axial_single_angle_presentation',
    'axial_single_angle_drawing', 'axial_single_angle_report',
    'axial_double_angle', 'axial_double_angle_ui', 'axial_double_angle_presentation',
    'axial_double_angle_drawing', 'axial_double_angle_report',
    'additional_checks', 'column_checks', 'detailing', 'local_checks', 'support_checks',
    'double_cover', 'double_cover_ui', 'double_cover_drawing', 'double_cover_report',
    'end_plate', 'end_plate_ui', 'end_plate_drawing', 'end_plate_report',
    'base_plate', 'base_plate_ui', 'base_plate_drawing', 'base_plate_report',
    'base_plate_details', 'base_plate_detail_drawing', 'concrete_anchorage',
    'active_shear_key', 'active_shear_key_ui', 'active_shear_key_drawing',
    'upper_washer', 'upper_washer_ui', 'upper_washer_artifacts',
    'single_key_weld', 'single_key_weld_ui', 'single_key_weld_artifacts',
    'base_plate_catalog', 'pinned_base_plate', 'pinned_base_plate_ui', 'pinned_base_plate_drawing',
    'concrete_components', 'concrete_force_states', 'base_component_ui', 'concrete_headed', 'concrete_shear',
    'column_base_weld', 'column_base_weld_ui', 'base_component_report', 'base_block_ui',
    'base_weld_qualified', 'column_base_weld_drawing', 'column_base_weld_report',
    'w_splice', 'w_splice_ui', 'w_splice_drawing', 'w_splice_report', 'w_splice_equilibrium',
    'w_splice_conventional', 'w_splice_conventional_ui', 'w_splice_conventional_drawing', 'w_splice_conventional_report',
    'double_angle', 'double_angle_ui', 'double_angle_drawing', 'double_angle_report',
    'coped_double_angle', 'coped_double_angle_ui', 'coped_double_angle_drawing', 'coped_double_angle_report',
    'welded_double_angle', 'welded_double_angle_ui', 'welded_double_angle_drawing', 'welded_double_angle_report',
)]
_missing = [name for name in _required if not (_root / name).is_file()]
if _missing:
    st.error('Instalação incompleta. Envie as pastas lro/ e data/ completas, '
             'ao lado de app.py, a partir do mesmo ZIP da versão 0.9.41-mre12-end-plate-dev.')
    st.code('\n'.join(_missing), language=None)
    st.info('Depois de atualizar os arquivos, reinicie o app no Streamlit Cloud.')
    st.stop()

from lro.display_precision import calculated_text
from lro.display_precision import display_format, display_frame, display_value, number_input
import pandas as pd
from lro.models import Connection,Profile,profiles,STEELS,BOLTS,DIAMETERS,THICKNESSES,KGF,VERSION,Issue
if VERSION != '0.9.41-mre12-end-plate-dev' or not hasattr(Issue, 'origin_label'):
    st.error('Arquivos de versões diferentes ou módulos antigos ainda carregados. '
             'Atualize app.py e toda a pasta lro/ com o mesmo pacote 0.9.41-mre12-end-plate-dev e reinicie o app.')
    st.stop()
from lro.load_conventions import render as render_load_convention
from lro.engine import evaluate
from lro.examples import presets
from lro.drawing import image_bytes
from lro.report import create_report,display,number,BRAND,LINK
from lro.benchmarks import benchmarks

st.markdown('''<style>
 .block-container {padding-top:2rem;max-width:1500px}
 [data-testid="stMetricValue"] {font-size:1.65rem}
 h1 {letter-spacing:-.045em!important;font-weight:750!important}
 .eyebrow {font-size:.78rem;letter-spacing:.16em;color:#397895;font-weight:700}
 .muted {color:#65798a;font-size:.95rem;line-height:1.5}
 [data-testid="stSidebar"] {background:#f3f6f8}
 div[data-testid="stVerticalBlockBorderWrapper"] {border-radius:12px}
 </style>''',unsafe_allow_html=True)

# Preserva os detalhes quando seus campos ficam ocultos ou muda a família.
for key in ('root_width','corner_clip','flange_weld','opposite_stiffener',
            'stiffener_t','stiffener_width','stiffener_clip','stiffener_weld','stiffener_steel',
            'gauge','cope_length','cope_top','cope_bottom','beam_level','real_t','support_edge_distance'):
    if key in st.session_state:st.session_state[key]=st.session_state[key]
for prefix in ('beam','support'):
    for suffix in ('manual_name','d','bf','tw','tf','clear','family','area','mass','source'):
        key=prefix+'_'+suffix
        if key in st.session_state:st.session_state[key]=st.session_state[key]
from lro.base_plate_catalog import FIXED as BASE_FIXED, PINNED as BASE_PINNED
# Existing live sessions preserve the external geometry under its explicit family.
if st.session_state.get('connection_family')=='Placa de base · Tipo 1':
    st.session_state['connection_family']=BASE_FIXED
from lro.w_splice_conventional import FAMILY as W_CONVENTIONAL_FAMILY
from lro.coped_double_angle import FAMILY as COPED_DOUBLE_ANGLE_FAMILY
from lro.double_angle import FAMILY as DOUBLE_ANGLE_FAMILY
from lro.welded_double_angle import FAMILY as WELDED_DOUBLE_ANGLE_FAMILY
from lro.axial_double_angle import FAMILY as AXIAL_DOUBLE_ANGLE_FAMILY
from lro.axial_single_angle import FAMILY as AXIAL_SINGLE_ANGLE_FAMILY
from lro.welded_w_splice import FAMILY as WELDED_W_SPLICE_FAMILY
from lro.welded_angle_gusset import FAMILY as WELDED_ANGLE_GUSSET_FAMILY
from lro.welded_double_angle_gusset import FAMILY as WELDED_DOUBLE_ANGLE_GUSSET_FAMILY
from lro.welded_opposed_angle_gusset import FAMILY as WELDED_OPPOSED_ANGLE_GUSSET_FAMILY
from lro.bolted_angle_gusset import FAMILY as BOLTED_ANGLE_GUSSET_FAMILY
from lro.corner_gusset import FAMILY as CORNER_GUSSET_FAMILY
from lro.guided_selection import route_label
family=st.sidebar.selectbox('Tipo de ligação',['Single plate','Alma de coluna · duas talas','End plate · rotulada','End plate · engastada',BASE_FIXED,BASE_PINNED,'Emenda W · M004 · tração axial',W_CONVENTIONAL_FAMILY,DOUBLE_ANGLE_FAMILY,WELDED_DOUBLE_ANGLE_FAMILY,COPED_DOUBLE_ANGLE_FAMILY,AXIAL_DOUBLE_ANGLE_FAMILY,AXIAL_SINGLE_ANGLE_FAMILY,WELDED_W_SPLICE_FAMILY,WELDED_ANGLE_GUSSET_FAMILY,WELDED_DOUBLE_ANGLE_GUSSET_FAMILY,WELDED_OPPOSED_ANGLE_GUSSET_FAMILY,BOLTED_ANGLE_GUSSET_FAMILY,CORNER_GUSSET_FAMILY],key='connection_family',format_func=route_label)
from lro.guided_selection import render as render_guided_selection
render_guided_selection()
if family==CORNER_GUSSET_FAMILY:
    from lro.corner_gusset_ui import render
    render()
    st.stop()

if family==WELDED_OPPOSED_ANGLE_GUSSET_FAMILY:
    from lro.welded_opposed_angle_gusset_ui import render
    render()
    st.stop()

if family==BOLTED_ANGLE_GUSSET_FAMILY:
    from lro.bolted_angle_gusset_ui import render
    render()
    st.stop()

if family==WELDED_DOUBLE_ANGLE_GUSSET_FAMILY:
    from lro.welded_double_angle_gusset_ui import render
    render()
    st.stop()

if family==WELDED_ANGLE_GUSSET_FAMILY:
    from lro.welded_angle_gusset_ui import render
    render()
    st.stop()

if family==WELDED_W_SPLICE_FAMILY:
    from lro.welded_w_splice_ui import render
    render()
    st.stop()

if family==AXIAL_SINGLE_ANGLE_FAMILY:
    from lro.axial_single_angle_ui import render
    render()
    st.stop()

if family==AXIAL_DOUBLE_ANGLE_FAMILY:
    from lro.axial_double_angle_ui import render
    render()
    st.stop()

if family==W_CONVENTIONAL_FAMILY:
    from lro.w_splice_conventional_ui import render
    render()
    st.stop()

if family==COPED_DOUBLE_ANGLE_FAMILY:
    from lro.coped_double_angle_ui import render
    render()
    st.stop()

if family==WELDED_DOUBLE_ANGLE_FAMILY:
    from lro.welded_double_angle_ui import render
    render()
    st.stop()

if family==DOUBLE_ANGLE_FAMILY:
    from lro.double_angle_ui import render
    render()
    st.stop()

if family=='Emenda W · M004 · tração axial':
    from lro.w_splice_ui import render
    render()
    st.stop()

if family==BASE_PINNED:
    from lro.pinned_base_plate_ui import render
    render()
    st.stop()

if family==BASE_FIXED:
    from lro.base_plate_ui import render
    render()
    st.stop()

if family=='Alma de coluna · duas talas':
    from lro.double_cover_ui import render
    render()
    st.stop()

if family.startswith('End plate'):
    from lro.end_plate_ui import render
    render('pinned' if family.endswith('rotulada') else 'moment')
    st.stop()

P=profiles();PRESETS=presets()


# Estes limites são os mesmos dos controles. O importador os verifica antes
# de alterar o projeto; valores inativos também precisam sobreviver ao reabrir.
_UI_RANGES = {
    'pitch': (1.,400.), 'edge_v': (1.,200.), 'edge_h': (1.,200.),
    'a': (10.,1000.), 'gap': (0.,900.), 'weld': (1.,25.),
    'plate_top': (-5000.,5000.), 'beam_level': (-1500.,1500.),
    'cope_length': (1.,1000.), 'cope_top': (1.,1000.), 'cope_bottom': (1.,1000.),
    'clearance': (0.,50.), 'tool_radius': (0.,1000.), 'tp': (1.,200.),
    'root_width': (1.,1000.), 'corner_clip': (0.,200.), 'flange_weld': (1.,25.),
    'stiffener_width': (1.,1000.), 'stiffener_clip': (0.,200.),
    'stiffener_weld': (1.,25.), 'gauge': (1.,400.),
    'support_edge_distance': (0.,100000.),
}
_DRAFT_KEYS = ('gauge','cope_length','cope_top','cope_bottom','beam_level',
               'real_t','custom_t','tp_label','center_plate','support_edge_distance')


def import_ui_values(c):
    """Build the complete widget state without mutating the current project."""
    def numeric(field,value,limits=None):
        try:finite=not isinstance(value,bool) and isinstance(value,(int,float)) and math.isfinite(value)
        except OverflowError:finite=False
        if not finite:
            raise ValueError(f'{display_value(field)} = {value!r}: o controle exige um número finito representável.')
        if float(value)!=value:
            raise ValueError(f'{display_value(field)} = {value!r}: não representável sem perda no controle numérico.')
        if limits and not limits[0]<=value<=limits[1]:
            raise ValueError(f"{display_value(field)} = {value!r}: fora do intervalo do controle [{display_format(limits[0], 'g')}, {display_format(limits[1], 'g')}].")
    for key,(lower,upper) in _UI_RANGES.items():numeric(key,getattr(c,key),(lower,upper))
    for key in ('fw','stiffener_t','support_joint_weld','db'):numeric(key,getattr(c,key))
    for key in ('n','bolt_columns'):
        if type(getattr(c,key)) is not int:raise ValueError(f'{display_value(key)} = {getattr(c, key)!r}: deve ser um inteiro.')
    for key in ('project','notes'):
        if not isinstance(getattr(c,key),str):raise ValueError(f'{display_value(key)}: deve ser texto.')
    plate_materials=[s.name for s in STEELS.values() if s.plate_allowed]
    for key in ('plate_steel','stiffener_steel'):
        if getattr(c,key) not in plate_materials:raise ValueError(f'{display_value(key)} = {getattr(c, key)!r}: material não disponível para chapa no controle.')
    values={k:v for k,v in c.__dict__.items() if k not in ('beam','support','V','N')}
    raw_loads={}
    for key in ('V','N'):
        value=getattr(c,key);numeric(key,value,(-1.e7*KGF,1.e7*KGF))
        kgf=value/KGF
        if value!=0 and kgf==0:raise ValueError(f'{display_value(key)} = {value!r}: não representável em kgf sem perda.')
        values[key+'_kgf']=kgf;raw_loads[key]=(kgf,value)
    # Do not round a nearly centered position or nearly nominal dimension.
    values['center_plate']=c.plate_top==(c.beam.d-c.hp)/2
    values['db_label']=next((k for k,v in DIAMETERS.items() if c.db==v),None)
    if values['db_label'] is None:raise ValueError(f'db = {c.db!r}: diâmetro não é exatamente um valor do catálogo.')
    values['tp_label']=next((k for k,v in THICKNESSES.items() if c.tp==v),'5/16"')
    values['custom_t']=c.tp not in THICKNESSES.values();values['real_t']=c.tp
    for prefix,profile in [('beam',c.beam),('support',c.support)]:
        for key in ('name','family','source'):
            if not isinstance(getattr(profile,key),str):raise ValueError(f'{display_value(prefix)}.{display_value(key)}: deve ser texto.')
        values[prefix+'_name']=profile.name if P.get(profile.name)==profile else 'Seção I personalizada'
        for key in ('d','bf','tw','tf','clear','area','mass'):
            val=getattr(profile,key);numeric(prefix+'.'+key,val,(.1,3000.) if key in ('d','bf','tw','tf','clear') else None)
            values[prefix+'_'+key]=float(val)
        for key in ('name','family','source'):
            values[prefix+('_manual_name' if key=='name' else '_'+key)]=getattr(profile,key)
    values['_single_plate_raw_loads']=raw_loads
    return values


def seed(c,values=None,drafts=None):
    values=import_ui_values(c) if values is None else values
    if drafts:values.update(drafts)
    st.session_state.update(values)
    st.session_state.pop('report',None)


def load_newtons(key,kgf):
    """Unedited imported loads retain the exact N value, including float bits."""
    snapshot=st.session_state.get('_single_plate_raw_loads',{}).get(key)
    return snapshot[1] if snapshot is not None and snapshot[0]==kgf else kgf*KGF


def load_example():seed(PRESETS[st.session_state['example']])


def import_file():
    # O callback executa antes da criação dos widgets, evitando alterar suas
    # chaves depois de instanciados no mesmo ciclo do Streamlit.
    try:
        uploaded=st.session_state.project_upload
        if uploaded is None:raise ValueError('Selecione um arquivo de projeto.')
        if len(uploaded.getvalue())>200_000:raise ValueError('Arquivo maior que o limite de projeto.')
        imported=Connection.from_dict(json.loads(uploaded.getvalue()))
        values=import_ui_values(imported)
        ir=evaluate(imported)
        if any(x.severity=='error' for x in ir.issues):raise ValueError('; '.join(x.text for x in ir.issues if x.severity=='error'))
        seed(imported,values=values)
        st.session_state.pop('import_error',None)
    except (ValueError,TypeError,KeyError,OverflowError) as exc:
        st.session_state['import_error']='Não foi possível abrir: '+str(exc)


if 'beam_name' not in st.session_state:
    saved=st.session_state.get('_single_plate_project')
    seed(Connection.from_dict(saved) if saved else next(iter(PRESETS.values())),
         drafts=st.session_state.get('_single_plate_drafts') if saved else None)


def profile_changed(prefix):
    name=st.session_state[prefix+'_name']
    if name in P:
        p=P[name]
        st.session_state[prefix+'_steel']='ASTM A36' if p.family in ('CS','CVS','VS') else 'ASTM A572 Gr.50'


def support_kind_changed():
    if st.session_state.kind=='column_flange':
        st.session_state.plate_shape='rectangular'
        st.session_state.opposite_stiffener=False


def profile_widget(prefix,label):
    name=st.selectbox(label,['Seção I personalizada']+list(P),key=prefix+'_name',on_change=profile_changed,args=(prefix,))
    if name in P:return P[name]
    with st.expander('Dimensões da seção personalizada',expanded=True):
        name=st.text_input('Designação',key=prefix+'_manual_name')
        cols=st.columns(2)
        vals={}
        for i,(key,text) in enumerate([('d','Altura d'),('bf','Largura bf'),('tw','Alma tw'),('tf','Mesa tf'),('clear','Altura livre sem concordâncias')]):
            with cols[i%2]:vals[key]=number_input(text+' (mm)',min_value=.1,max_value=3000.,key=prefix+'_'+key)
        family=st.text_input('Família / produto',key=prefix+'_family')
        area=number_input('Área informada (mm²)',key=prefix+'_area',format='%.2f')
        mass=number_input('Massa informada (kg/m)',key=prefix+'_mass',format='%.2f')
        source=st.text_input('Fonte da seção',key=prefix+'_source')
        return Profile(name,family,mass,area=area,source=source,**vals)


with st.sidebar:
    st.markdown('<div class="eyebrow">LRO · ENGENHARIA</div>',unsafe_allow_html=True)
    st.title('Ligações')
    st.caption(f'Versão {display_value(VERSION)} · single plate')
    st.text_input('Projeto ou identificação',key='project')
    st.selectbox('Carregar exemplo',list(PRESETS),key='example')
    st.button('Usar este exemplo',on_click=load_example,width='stretch')
    with st.expander('Abrir projeto salvo'):
        uploaded=st.file_uploader('Arquivo JSON do LRO Ligações',type=['json'],key='project_upload')
        st.button('Abrir arquivo',disabled=uploaded is None,on_click=import_file)
        if 'import_error' in st.session_state:st.error(st.session_state.import_error)
    st.divider()
    st.caption('Nesta versão')
    st.markdown('**Single plate**\n\nViga–viga e viga–mesa de pilar. Um caso de esforços já majorados.')
    with st.expander('Próximas ligações'):
        st.write('A ligação à alma de coluna com duas talas está no seletor acima, com seu escopo próprio. Cantoneiras duplas R016 também estão no seletor, no domínio de cortante. Cantoneira simples permanece prevista.')
    st.link_button('LinkedIn · Lucas Oliveira',LINK,width='stretch')

st.markdown('<div class="eyebrow">LIGAÇÕES DE AÇO</div>',unsafe_allow_html=True)
st.title('Single plate')
st.caption('Viga–viga ou viga–mesa de pilar; complemento e enrijecedor oposto disponíveis em viga–viga.')
st.markdown('<p class="muted">Escolha os perfis, ajuste o detalhe e acompanhe as verificações. A memória usa os mesmos dados e o mesmo desenho.</p>',unsafe_allow_html=True)

left,right=st.columns([1,1.65],gap='large')
with left:
    with st.container(border=True):
        st.subheader('1 · Ligação e esforços')
        st.selectbox('Tipo de apoio',['beam_web','column_flange'],format_func=lambda x:'Alma de viga — viga a 90°' if x=='beam_web' else 'Mesa de pilar — alinhada à alma',key='kind',on_change=support_kind_changed)
        beam=profile_widget('beam','Viga apoiada')
        support=profile_widget('support','Perfil de apoio')
        loads=st.columns(2)
        with loads[0]:vk=number_input('Cortante Vd (kgf)',min_value=-1.e7,max_value=1.e7,key='V_kgf',format='%.2f')
        with loads[1]:nk=number_input('Força axial Nd (kgf; + tração)',min_value=-1.e7,max_value=1.e7,key='N_kgf',format='%.2f')
        load_convention_slot = st.empty()
        st.caption(f"{display_format(load_newtons('V', vk) / 1000, '.3f')} kN de cortante · {display_format(load_newtons('N', nk) / 1000, '.3f')} kN axial (tração positiva). Entrada já majorada.")
        st.caption('Modelo no plano: cortante vertical, tração axial e momento local em torno da maior inércia. Viga apoiada com contenção eficaz por hipótese fixa.')
    with st.container(border=True):
        st.subheader('2 · Detalhamento')
        st.selectbox('Formato da single plate',['rectangular','between_flanges'] if st.session_state.kind=='beam_web' else ['rectangular'],
                     format_func=lambda x:'Retangular' if x=='rectangular' else 'Com complemento até as mesas do apoio',key='plate_shape')
        if st.session_state.plate_shape=='between_flanges':
            with st.expander('Complemento até as mesas',expanded=True):
                number_input('Largura do complemento bᵣ (mm)',1.,1000.,key='root_width')
                number_input('Alívio de canto c (mm)',0.,200.,key='corner_clip')
                number_input('Solda do complemento às mesas: filete (mm)',1.,25.,key='flange_weld')
                st.caption(f"Altura entre as faces internas das mesas: {display_format(support.d - 2 * support.tf, 'g')} mm. Complemento de mesma espessura da chapa; dimensões e soldas adicionais apenas para detalhamento.")
        if st.session_state.kind=='beam_web':
            st.checkbox('Enrijecedor no lado oposto da single plate',key='opposite_stiffener',
                        help='Coplanar à chapa, no outro lado da alma do apoio, entre as mesas. Disponível com chapa retangular ou com complemento.')
            if st.session_state.opposite_stiffener:
                with st.expander('Enrijecedor oposto',expanded=True):
                    thicknesses=list(THICKNESSES.values())
                    if st.session_state.stiffener_t not in thicknesses:thicknesses.append(st.session_state.stiffener_t)
                    def stiffener_thickness_label(t):
                        inch=next((k for k,v in THICKNESSES.items() if v==t),None)
                        return (inch+' · ' if inch else '')+f"{display_format(t, 'g')} mm"
                    st.selectbox('Espessura do enrijecedor tₑ (pol.)',thicknesses,key='stiffener_t',format_func=stiffener_thickness_label)
                    number_input('Largura do enrijecedor bₑ (mm)',1.,1000.,key='stiffener_width')
                    number_input('Alívio do enrijecedor cₑ (mm)',0.,200.,key='stiffener_clip')
                    number_input('Enrijecedor → alma e mesas: filete wₑ (mm)',1.,25.,key='stiffener_weld')
                    st.selectbox('Aço do enrijecedor',[s.name for s in STEELS.values() if s.plate_allowed],key='stiffener_steel')
                    st.caption(f"Altura Hₑ = {display_format(support.d - 2 * support.tf, 'g')} mm; projeção das mesas = {display_format((support.bf - support.tw) / 2, 'g')} mm. Dois filetes nas ligações à alma e às mesas, interrompidos nos alívios.")
                    st.caption('Opção de detalhamento: não aumenta as resistências calculadas, inclusive a punção. Premissas no final da página e do Word.')
        st.selectbox('Colunas de parafusos',[1,2],key='bolt_columns',help='Calcula o grupo bidimensional de parafusos e os caminhos de ruptura da chapa retangular.')
        if st.session_state.bolt_columns==2:number_input('Passo horizontal s (mm)',1.,400.,key='gauge')
        cols=st.columns(2)
        with cols[0]:
            st.selectbox('Parafuso Ø (pol.)',list(DIAMETERS),key='db_label')
            number_input('Número de linhas de parafusos',2,12,key='n',step=1)
            number_input('Passo p (mm)',min_value=1.,max_value=400.,key='pitch')
            number_input('Borda vertical eᵥ (mm)',min_value=1.,max_value=200.,key='edge_v')
            number_input('Face → parafusos a (mm)',min_value=10.,max_value=1000.,key='a')
        with cols[1]:
            st.selectbox('Chapa tₚ (pol.)',list(THICKNESSES),key='tp_label')
            number_input('Solda chapa → apoio: filete w (mm)',min_value=1.,max_value=25.,key='weld')
            number_input('Borda livre eₕ (mm)',min_value=1.,max_value=200.,key='edge_h')
            number_input('Folga face do apoio → ponta da viga g (mm)',min_value=0.,max_value=900.,key='gap',help='Sugestão usual: 10 mm. A borda do primeiro parafuso na viga é a − g. Em viga–viga, confira também a projeção das mesas e os recortes.')
            st.caption(f"Borda na viga: a − g = {display_format(st.session_state.a - st.session_state.gap, '.2f')} mm. Para g = 10 mm, o limite máximo desta borda permite a ≤ {display_format(10 + min(12 * beam.tw, 150), '.2f')} mm.")
        centered=st.checkbox('Centralizar chapa na altura da viga',key='center_plate')
        if centered:
            st.session_state.plate_top=(beam.d-(2*st.session_state.edge_v+(st.session_state.n-1)*st.session_state.pitch))/2
        position_label='Topo da mesa superior → topo da aba parafusada z (mm)' if st.session_state.plate_shape=='between_flanges' else 'Topo da mesa superior → topo da chapa z (mm)'
        number_input(position_label,-5000.,5000.,key='plate_top',disabled=centered,
                        help='Medida vertical a partir da face superior da mesa da viga apoiada, antes de qualquer recorte. Valor negativo é inválido e bloqueia o cálculo.')
        st.caption('Para subir a chapa, desmarque a centralização e reduza z. A geometria e a excentricidade de N são recalculadas automaticamente.')
        with st.expander('Recortes e desnível entre vigas'):
            if st.session_state.kind=='beam_web':number_input('Topo da viga apoiada abaixo do apoio (mm)',-1500.,1500.,key='beam_level')
            st.selectbox('Recorte',['none','top','both'],format_func=lambda x:{'none':'Sem recorte','top':'Mesa superior','both':'Mesas superior e inferior'}[x],key='cope')
            if st.session_state.cope!='none':
                st.caption('Calcula flexão, estabilidade, ruptura e bloco na região recortada. A contenção lateral na raiz do recorte deve existir no detalhe real.')
                number_input('Comprimento do recorte (mm)',1.,1000.,key='cope_length')
                number_input('Profundidade superior (mm)',1.,1000.,key='cope_top')
                if st.session_state.cope=='both':number_input('Profundidade inferior (mm)',1.,1000.,key='cope_bottom')
        with st.expander('Montagem e hipóteses'):
            number_input('Folga mínima entre peças (mm)',0.,50.,key='clearance')
            number_input('Raio do envelope de montagem (mm)',0.,1000.,key='tool_radius',help='Envelope de porca, arruela e ferramenta. Valor inicial ilustrativo, ajustável ao sistema de montagem.')
            st.checkbox('Furos executados com broca',key='drilled',help='Retira o acréscimo de 2 mm no desconto da seção líquida, conforme 5.2.4.')
            st.checkbox('Borda da solda da chapa com execução reforçada especificada',key='reinforced_weld')
            st.checkbox('Verificar mínimo normativo de 45 kN',key='norm_minimum')
            st.checkbox('Informar espessura real da chapa',key='custom_t')
            if st.session_state.custom_t:number_input('Espessura real tₚ (mm)',1.,200.,key='real_t',format='%.2f')
    centered_n=abs(beam.d/2-(st.session_state.plate_top+(2*st.session_state.edge_v+(st.session_state.n-1)*st.session_state.pitch)/2))<1e-8
    if st.session_state.kind=='beam_web' and nk>0 and vk==0 and centered_n:
        with st.expander('Alma do apoio sob tração',expanded=True):
            number_input('Menor distância livre longitudinal na alma (mm)',0.,100000.,key='support_edge_distance',help='Do eixo da chapa até a extremidade, abertura ou outra região carregada mais próxima, medida ao longo da viga de apoio. O mesmo valor conservador vale para os dois sentidos. Zero = não informado.')
            st.caption('A plastificação usa a orientação real da chapa: sua altura atravessa a alma e sua espessura fica na direção longitudinal do apoio. Modelo aplicável à tração direta centrada, sem cortante.')
    with st.expander('Materiais e especificações'):
        def material_options(profile,key):
            welded=profile.family in ('CS','CVS','VS','Soldado')
            return [s.name for s in STEELS.values() if s.rolled_allowed or welded or s.name==st.session_state[key]]
        st.selectbox('Aço da viga',material_options(beam,'beam_steel'),key='beam_steel')
        st.selectbox('Aço do apoio',material_options(support,'support_steel'),key='support_steel')
        st.selectbox('Aço da chapa',[s.name for s in STEELS.values() if s.plate_allowed],key='plate_steel')
        if any(st.session_state[k].startswith('USI-CIVIL') for k in ('beam_steel','support_steel','plate_steel')):
            st.caption('USI-CIVIL: chapas grossas de 6 a 75 mm e perfis soldados dessas chapas. fy/fu mínimos: 300/400 MPa ou 350/500 MPa. Fonte: Usiminas, catálogo de chapas grossas, p.29.')
        st.selectbox('Especificação dos parafusos',list(BOLTS),key='bolt')
        st.checkbox('Rosca no plano de corte',key='threads')
        number_input('Resistência do eletrodo fw (MPa)',key='fw',format='%.2f')
        st.text_area('Observações do detalhe',key='notes')
    with st.expander('Premissas fixas do modelo'):
        st.write('Viga apoiada com contenção eficaz. Sem cortante horizontal nem momento no eixo de menor inércia; tração axial mantida. Perfis soldados com juntas internas de penetração total e metal de adição compatível. No pilar, admite-se impedido o deslocamento lateral relativo entre suas mesas na região da ligação; é uma premissa do projeto, não uma consequência da penetração total. A análise global dos membros é externa.')

state=st.session_state
hp=2*state.edge_v+(state.n-1)*state.pitch
top=(beam.d-hp)/2 if state.center_plate else state.plate_top
base=next(iter(PRESETS.values()))
kwargs={k:state[k] for k in base.__dict__ if k in state and k not in ('beam','support','V','N','db','tp','plate_top')}
c=Connection(beam=beam,support=support,V=load_newtons('V',vk),N=load_newtons('N',nk),db=DIAMETERS[state.db_label],tp=state.real_t if state.custom_t else THICKNESSES[state.tp_label],plate_top=top,**kwargs)
with load_convention_slot.container():
    render_load_convention(st, 'single_plate', c.N)
state['_single_plate_project']=c.to_dict()
state['_single_plate_drafts']={key:state[key] for key in _DRAFT_KEYS if key in state}
r=evaluate(c)
payload=json.dumps(c.to_dict(),ensure_ascii=False,indent=2,allow_nan=False)
digest=hashlib.sha256(payload.encode()).hexdigest()

@st.cache_data(show_spinner=False,max_entries=25)
def drawing_cached(raw,fmt):return image_bytes(Connection.from_dict(json.loads(raw)),fmt)

with right:
    with st.container(border=True):
        st.subheader('3 · Geometria e resultado')
        if r.geometry:
            st.image(drawing_cached(payload,'png'),width='stretch')
        if any(i.severity=='error' for i in r.issues) or r.status.startswith('FALHA NUMÉRICA'):st.error(r.status)
        elif r.status in ('NÃO ATENDE','NÃO ATENDE AO DETALHAMENTO'):st.error(r.status+' · conferir índices e requisitos de detalhamento')
        elif r.method_failures or r.local_scope_issues or any(i.severity in ('pending','interference','extrapolation','outside_method') for i in r.issues):st.warning(r.status)
        else:st.success(r.status)
        if r.coverage_note:st.caption(r.coverage_note)
        if r.calculation_note:st.caption(r.calculation_note)
        ms=st.columns(3)
        ms[0].metric('Aba parafusada (mm)' if c.full_depth else 'Chapa (mm)',f"{display_format(c.width, 'g')} × {display_format(c.hp, 'g')}",f"t = {display_format(c.tp, '.3f')} mm",delta_color='off')
        ms[1].metric('Momento local de entrada',f"{display_format((abs(c.V) * c.bolt_centroid_x + abs(c.N * c.eccentric_n)) / (KGF * 1000), '.2f')}",'kgf·m',delta_color='off')
        ms[2].metric('Maior índice resistente válido' if r.numeric_failures else 'Maior índice resistente',number(r.governing.ratio,3) if r.governing else '—')
        st.caption(f"Furo padrão Ø {display_format(c.dh, '.4f')} mm · {display_value(c.beam_steel)} / {display_value(c.support_steel)} / chapa {display_value(c.plate_steel)}")
        if r.governing:st.caption(('Determina entre os resultados válidos: ' if r.numeric_failures else 'Determina: ')+r.governing.name+' · '+r.governing.case)
        if any(x.id=='support_punch' and not x.passed for x in r.checks):
            st.info('O requisito de hierarquia contra punção é uma condição do método: compara a espessura da chapa com um limite, não esforço com resistência. Seu descumprimento exige revisar o detalhe ou fazer uma verificação específica do apoio.')
        st.caption(r.method_provenance_note)
        for issue in r.issues:
            if issue.severity=='excluded':continue
            f=st.error if issue.severity in ('error','noncompliance') else st.warning if issue.severity in ('pending','interference','extrapolation','outside_method') else st.info
            f((issue.origin_label+': ' if issue.severity=='pending' else '')+calculated_text(issue.text, assignments_only=True)+'  ['+issue.reference+']')
        if any(i.severity=='interference' for i in r.issues):
            st.caption('Cálculo e exportação liberados para as dimensões informadas. Confira os avisos de montagem antes de definir o detalhe de fabricação.')
        if r.checks:
            st.caption('Todos os índices exibidos abaixo incluem o mínimo normativo quando aplicável. Os índices se referem somente às verificações realizadas.')
    with st.container(border=True):
        st.subheader('4 · Salvar e exportar')
        detailed=st.checkbox('Memória detalhada',value=False,help='A compacta desenvolve os itens determinantes e preserva as capacidades da chapa; o resumo consolida somente verificações redundantes.')
        can_detail=bool(r.geometry) and not any(i.severity=='error' for i in r.issues)
        if can_detail and not r.checks:st.caption('O Word será um pré-detalhamento com pendências, sem conclusão de resistência.')
        if st.button('Gerar memória Word',type='primary',disabled=not can_detail,width='stretch'):
            with st.spinner('Preparando imagem, equações e memória...'):
                state['report']=(digest,detailed,create_report(c,r,detailed))
        if 'report' in state and state.report[:2]==(digest,detailed):
            st.download_button('Baixar memória .docx',state.report[2],file_name='Memoria_LRO_single_plate.docx',mime='application/vnd.openxmlformats-officedocument.wordprocessingml.document',width='stretch')
        files=st.columns(2)
        files[0].download_button('Salvar projeto',payload,file_name='Projeto_LRO_ligacao.json',mime='application/json',width='stretch')
        if r.geometry:files[1].download_button('Desenho vetorial SVG',drawing_cached(payload,'svg'),file_name='Ligacao_LRO.svg',mime='image/svg+xml',width='stretch')

tabs=st.tabs(['Verificações','Equações e referências','Validação','Escopo da versão'])
with tabs[0]:
    if r.checks:
        table_rows=[]
        for x in r.summary_checks:
            sd,u=display(x.demand,x.unit);rd,_=display(x.resistance,x.unit)
            table_rows.append({'Verificação':x.name,'Tipo':x.category,'Sd / valor':sd if x.numerically_valid and x.applicable else '—','Rd / limite':rd if x.numerically_valid else '—','Unidade':u,'Relação':x.ratio if x.numerically_valid and x.applicable else None,'Resultado':x.outcome})
        st.caption('Resistência: relação esforço/capacidade ou interação. Condição do método: relação valor/limite de hierarquia, sem representar utilização resistente. N/A: sem solicitação axial nesse caminho. As capacidades escalares da chapa ficam na memória completa de equações.')
        st.dataframe(display_frame(pd.DataFrame(table_rows)),hide_index=True,width='stretch')
    else:st.info('Não há resistências calculadas. Consulte os avisos de geometria e de cobertura do modelo.')
with tabs[1]:
    for x in r.checks:
        with st.expander(x.name):
            if not x.numerically_valid:st.warning(x.outcome+'; capacidade ou relação inválida.')
            if not x.applicable:st.caption(x.outcome+'; capacidade preservada para consulta.')
            if not x.summary_visible:st.caption('Capacidade intermediária incluída nas envoltórias da chapa; sem aprovação redundante no resumo.')
            st.write(x.equation);st.write(calculated_text(x.substitution));st.write(calculated_text(x.variables, assignments_only=True));st.caption(x.reference)
    st.caption('O Word contém equações editáveis. Os procedimentos complementares AISC/SCI são identificados; as tabelas LRFD não são convertidas em bloco para NBR.')
with tabs[2]:
    vals=benchmarks();st.metric('Conferências pontuais contra exemplos',f"{display_value(sum((v['atende'] for v in vals)))} / {display_value(len(vals))}")
    st.dataframe(display_frame(pd.DataFrame(vals)),hide_index=True,width='stretch')
    st.info('Estas conferências validam componentes identificados, não a reprodução integral de todos os exemplos. No app usa-se a distância completa da face ao centro do grupo: e=a na coluna única; e=a+s/2 em duas colunas, inclusive em corte puro. O material didático original usa e=a/2 no grupo convencional; a comparação acima preserva essa hipótese apenas no teste. A NBR atual adota 0,45 e fub=830 MPa para A325; o exemplo antigo usa 0,40 e 825 MPa.')
with tabs[3]:
    st.markdown('''**Cálculo implementado:** single plate retangular, uma ou duas colunas de 2–12 linhas de parafusos, cortante e tração, parafusos por contato, furos padrão e dois filetes de oficina. Inclui desenho proporcional, importação e exportação de projeto e memória Word.

**Complemento até as mesas:** disponível na single plate viga–viga, apenas para detalhamento, sem novas verificações ou ganho de resistência. O cálculo mantém a chapa retangular nominal e sua solda à alma; as premissas constam no final da página.

**Interferências:** os avisos de concordância, contato e acesso de montagem permitem calcular e exportar as dimensões nominais. Entradas inválidas, perda de ligamento resistente e demais impedimentos do modelo continuam bloqueando o cálculo.

**Cobertura atual:** recortes dentro do domínio, ductilidade, solda chapa–apoio e metal-base das juntas de penetração total do perfil de pilar são calculados. No pilar, o momento é transportado à alma e suas zonas de tração/compressão são verificadas. A alma sob tração direta centrada, sem cortante, recebe cálculo por linhas de plastificação e punção, dentro de seu domínio. A interação fora do plano sob N+V ou N excêntrico é excluída do cálculo e indicada nas premissas ao final da página. A contenção eficaz da viga apoiada é hipótese fixa. Não se aplicam cortante horizontal nem momento no eixo de menor inércia. O apoio conserva suas próprias verificações locais; a estabilidade global permanece no projeto estrutural e o impedimento de deslocamento relativo das mesas do pilar é uma premissa registrada na memória.

**Outras famílias:** duas talas e end plates estão disponíveis no seletor lateral, com domínio e premissas próprios. A revisão das single plates acompanha o pacote em docs/REVISAO_TECNICA.md.

O P902-23W contém tabelas complementares; suas tabelas 10-A/10-B são para paredes de perfis tubulares e não são aplicadas às almas dos perfis I desta versão.''')
st.divider()
st.subheader('Premissas adotadas')
st.write('Modelo plano; viga com contenção eficaz; juntas internas mesa–alma dos perfis soldados com penetração total e metal de adição compatível. A análise global dos membros e do contraventamento pertence ao projeto da estrutura. Não se incluem atrito, fadiga, vibração ou ações cíclicas.')
for issue in r.issues:
    if issue.severity in ('excluded','extrapolation','noncompliance'):st.write(calculated_text(issue.text, assignments_only=True)+' ['+issue.reference+']')
st.caption(BRAND)
st.link_button('Contato no LinkedIn',LINK)
