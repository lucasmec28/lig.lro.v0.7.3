"""Lossless presentation envelopes for the existing R016 primitive checks.

This module does not calculate or combine resistances. It groups only branches
of the same physical component and mechanism, retaining complete witnesses.
"""
from .display_precision import display_value
from collections import OrderedDict
from copy import deepcopy


COMPONENT_LABELS = {
    'bolt_shared_web': 'Parafusos comuns · alma / duas cantoneiras',
    'bolt_support_negative': 'Parafusos do apoio · lado z−',
    'bolt_support_positive': 'Parafusos do apoio · lado z+',
    'angle_negative_beam': 'Cantoneira z− · aba da viga',
    'angle_negative_support': 'Cantoneira z− · aba do apoio',
    'angle_positive_beam': 'Cantoneira z+ · aba da viga',
    'angle_positive_support': 'Cantoneira z+ · aba do apoio',
    'beam_web': 'Alma da viga',
    'column_flange_negative': 'Mesa do pilar · lado z−',
    'column_flange_positive': 'Mesa do pilar · lado z+',
}
MECHANISM_LABELS = {
    'bolt_shear': 'Corte dos parafusos',
    'section_shear': 'Cisalhamento da seção',
    'bearing': 'Contato / rasgamento',
    'block': 'Cisalhamento em bloco L',
}


def _witness(check, result, actual):
    record = deepcopy(check)
    load = result.get('load_model') or {}
    component = check.get('component', '')
    branch_sign = 1 if component.endswith('_Vpos') else -1 if component.endswith('_Vneg') else None
    directions = [branch_sign] if branch_sign is not None else list(load.get('directions_evaluated') or [])
    total = load.get('Vsd_N' if actual else 'Vd_N')
    signed_cases = ([total] if actual else [abs(total) * direction for direction in directions]) if total is not None else []
    record['case'] = {
        'kind': 'actual' if actual else 'adopted',
        'total_action_N': signed_cases[0] if len(signed_cases) == 1 else None,
        'stored_total_action_reference_N': total,
        'total_action_magnitude_N': abs(total) if total is not None else None,
        'signed_total_action_cases_N': signed_cases,
        'directions_evaluated': directions,
        'branch_direction_sign': branch_sign,
        'loaded_direction': check.get('loaded_direction', 'direction_independent'),
    }
    return record


def governing_description(record):
    """Human-readable case, force direction and exact governing branch."""
    case = record['case']
    if case['kind'] == 'actual' and case['total_action_N'] == 0:
        case_label = 'V real = 0; sem força real'
    else:
        case_label = ' / '.join('V > 0' if x > 0 else 'V < 0' for x in case['directions_evaluated'])
    direction = {'down': 'força ↓', 'up': 'força ↑',
                 'direction_independent': 'independente do sentido'}.get(case['loaded_direction'], case['loaded_direction'])
    return f"{display_value(case_label)}; {display_value(direction)}; {display_value(record['id'])}"


def physical_envelopes(result):
    """Return lossless physical-mechanism groups, including all exact ties.

    Maxima are selected separately for actual and adopted actions. Every member
    occurs exactly once, including the normative bearing sum and each uniform
    per-hole compatibility check. Equal maxima are retained without tolerance.
    """
    groups = OrderedDict()
    for check in result.get('checks') or []:
        component = check['component'].removesuffix('_Vpos').removesuffix('_Vneg')
        identifier = check['id']
        mechanism = ('bearing' if '_bearing_' in identifier else 'block' if '_block_' in identifier
                     else 'bolt_shear' if identifier.startswith('bolt_') else 'section_shear')
        groups.setdefault((component, mechanism), []).append(check)
    envelopes = []
    for (component, mechanism), members in groups.items():
        actual_max = max(row['actual_utilization'] for row in members)
        adopted_max = max(row['utilization'] for row in members)
        actual_ties = [_witness(row, result, True) for row in members if row['actual_utilization'] == actual_max]
        adopted_ties = [_witness(row, result, False) for row in members if row['utilization'] == adopted_max]
        envelopes.append({
            'id': component + '__' + mechanism,
            'component': component,
            'component_label': COMPONENT_LABELS.get(component, component),
            'mechanism': mechanism,
            'mechanism_label': MECHANISM_LABELS[mechanism],
            'actual_governing_id': actual_ties[0]['id'],
            'adopted_governing_id': adopted_ties[0]['id'],
            'actual_utilization': actual_max,
            'adopted_utilization': adopted_max,
            'actual_governing': actual_ties[0],
            'adopted_governing': adopted_ties[0],
            'actual_governing_ties': actual_ties,
            'adopted_governing_ties': adopted_ties,
            'actual_status': 'FAIL' if any(row['actual_status'] == 'FAIL' for row in members) else 'PASS',
            'status': 'FAIL' if any(row['status'] == 'FAIL' for row in members) else 'PASS',
            'member_ids': [row['id'] for row in members],
            'members': deepcopy(members),
        })
    return envelopes
