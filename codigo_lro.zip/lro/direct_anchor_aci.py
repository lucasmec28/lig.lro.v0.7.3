"""ACI component assembly for actual direct-bearing states, N/mm/MPa.

Independent of BasePlate geometry. Reuses the retained ACI mechanisms and
real-edge-state evaluator. EN resistances never enter any ACI denominator.
"""
from types import SimpleNamespace
import math
from .concrete_anchorage import breakout_group
from .concrete_headed import evaluate_headed
from .concrete_shear import evaluate_shear,aci_steel
from .concrete_force_states import evaluate_force_states


def evaluate_direct_aci(*,direct,rods,bounds,hef,fc,block_h,db,fy,fu,As,
        bearing_area,headed_detail,physical_detail,ductile=False,ductility_reference=''):
    prerequisites=[]
    required=('cast_in','normalweight','cracked','static','intact_prism','no_sleeves_or_voids','splitting_detail_satisfied')
    prerequisites.extend('Condição física obrigatória: '+k for k in required if physical_detail.get(k) is not True)
    if not all(type(v) in (int,float) and math.isfinite(v) and v>0 for v in (hef,fc,block_h,db,fy,fu,As)):
        return dict(domain=False,complete=False,status='pending',passes=None,reasons=['Grandezas ACI reais positivas obrigatórias.'],states=[])
    if hef>=block_h:prerequisites.append('hef deve caber na altura real do bloco.')
    if fc>10000*.006894757293168361:prerequisites.append('Concreto acima do domínio ACI retido para ancoragem moldada.')
    if type(ductile) is not bool:prerequisites.append('Elegibilidade dúctil ACI deve ser booleana explícita.')
    if ductile and (not isinstance(ductility_reference,str) or not ductility_reference.strip()):
        prerequisites.append('Ductilidade ACI exige referência documental própria; nenhum fator dúctil foi presumido.')
    if As>math.pi*db*db/4 or fy>fu:prerequisites.append('Área/material real de haste inconsistente.')
    if prerequisites:
        return dict(domain=False,complete=False,status='pending',passes=None,reasons=prerequisites,states=[])
    active=[r for r in rods if r['tension']>0]
    groups=[]
    def calculate_group(rr):
        group=breakout_group(rr,bounds,hef,fc)
        if group['connected']:groups.append(group)
        else:
            for indices in group['components']:calculate_group([rr[i] for i in indices])
    if active:calculate_group(active)
    headed=evaluate_headed(rods,bounds,hef,fc,bearing_area,headed_detail)
    # Physical cast-in/headed qualification is required even when external T=0.
    # Zero pullout demand cannot qualify an unknown family or unconfirmed head.
    hp=headed.get('prerequisites',{})
    if hp.get('detail',{}).get('status')!='verified':
        prerequisites.extend(hp.get('reasons',[]))
        prerequisites.extend(hp.get('detail',{}).get('reasons',[]))
        if not prerequisites:prerequisites.append('Detalhe físico da ancoragem moldada ainda não qualificado.')
    tensionchecks=[dict(g,id='cone_'+str(i),method='ACI 318-19 17.6.2') for i,g in enumerate(groups)]
    if active:
        for mode in ('pullout','sideface'):
            result=headed.get(mode,{})
            tensionchecks.extend(x for x in result.get('checks',[]) if not x.get('diagnostic_only'))
            if result.get('status') not in ('calculated','not_demanded','not_applicable'):
                prerequisites.extend(result.get('reasons',[]) or [mode+' pendente'])
        mechanical=headed.get('prerequisites',{}).get('mechanical',{})
        tensionchecks.extend(mechanical.get('checks',[]))
        if headed.get('prerequisites',{}).get('status') not in ('verified','failed'):
            prerequisites.append('Peça enterrada/área de apoio sem qualificação mecânica completa.')
    records=[];checks=[]
    def add(key,name,sd,rd,unit,reference,equation,substitution,variables):
        checks.append(dict(id=key,label=name,demand=sd,resistance=rd,ratio=sd/rd if rd>0 else None,
            passes=sd<=rd,unit=unit,method=reference,equation=equation,substitution=substitution,variables=variables))
    for state in direct.get('states',[]):
        forces=state['forces'];V=state['V_signed_N']
        shear=evaluate_shear(rods,bounds,hef,fc,block_h,db,V,
            dict(mode='documented',qualified=True,reference=state['basis'],forces=forces,
                parallel_model='virtual_perpendicular',optional_envelope=False,
                **({'layout':'line_1x2'} if len(rods)==2 else {})))
        shear['V_anchor']=V
        steel=[]
        for rod in rods:
            steel.extend(aci_steel(tension=rod['tension'],shear=forces[rod['id']],area_tension=As,area_shear=As,
                fy=fy,fu=fu,ductile=ductile,grout=True,ductility_ref=ductility_reference,id=rod['id'])['checks'])
        ts=tensionchecks+[x for x in steel if x['id'].startswith('aci_tension_')]
        u=SimpleNamespace(distribution_ref=state['basis'],parallel_model='virtual_perpendicular',optional_envelope=False,
            area_tension=As,area_shear=As,ductile=ductile,ductility_ref=ductility_reference)
        c=SimpleNamespace(concrete_components=u,block_xmin=bounds[0],block_ymin=bounds[1],block_xmax=bounds[2],block_ymax=bounds[3],
            hef=hef,fck=fc,block_h=block_h,db=db,V=V,anchor_fy=fy,anchor_fu=fu,native_anchor_shear=False)
        r=SimpleNamespace(geometry={},local_upper_washer={})
        local=[]
        def state_add(key,*args):
            add(state['id']+'_'+key,*args)
            local.append(checks[-1])
        result=evaluate_force_states(c,r,rods,ts,shear,steel,True,prerequisites,state_add)
        for check in ts+steel+[ck for mode in ('breakout','pryout') for ck in shear.get(mode,{}).get('checks',[]) if not ck.get('diagnostic_only')]:
            if check not in local:local.append(check)
        records.append(dict(id=state['id'],forces=forces,steel=steel,shear=shear,
            force_states=result['states'],interaction=result['interaction'],checks=local))
    complete=bool(records) and all(x['interaction'].get('passes') is not None for x in records)
    passes=all(x['interaction']['passes'] for x in records) if complete else None
    return dict(domain=not prerequisites,complete=complete,status='pass' if passes is True else 'fail' if passes is False else 'pending',
        passes=passes,states=records,cone=dict(status='calculated' if active else 'not_demanded',groups=groups),headed=headed,
        reasons=list(dict.fromkeys(prerequisites+[reason for state in records for reason in state['interaction'].get('reasons',[])])),
        material=dict(fy=fy,fu=fu,As=As),grout_factor=.8,phi_N=.75 if ductile else .65,phi_V=.65 if ductile else .60,
        concrete_phi=.70,source='ACI 318-19/DG1, verificações paralelas completas com fatores próprios; não conformidade integral EN',
        foundation_complete=False)
