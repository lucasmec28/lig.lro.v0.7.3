"""One physical bolt row in the actual two-root corner polygon.

Qualified conventional NBR/DG29 limit states, parameterized geometry and nominal
body screens. No oracle/runtime import or fixture-coordinate specialization.
The full-joint and receiver kernels remain in corner_gusset.
"""
from __future__ import annotations
import math
from .models import BOLTS
from .bolted_angle_gusset import HOLES, EDGES


def _core():
    from . import corner_gusset
    return corner_gusset


def adapt_geometry(c,g):
    core=_core();a=g['angle'];co=g['angle_basis']['cos'];si=g['angle_basis']['sin']
    xy=lambda u,v:[u*co-v*si,u*si+v*co]
    count=1 if core.is_single(c) else 2;v=-c.workpoint_offset
    us=[c.bolt_start+j*c.bolt_pitch for j in range(c.bolt_count)]
    dh=HOLES[c.bolt_diameter];dn=dh if c.bolt_drilled else dh+2.
    tool=c.bolt_tool_radius+c.bolt_fabrication_clearance
    vh=v-c.bolt_gauge;vt=vh+a['leg'];uend=us[0]-c.bolt_angle_end
    footprint=[xy(u,z) for u in (uend,us[-1]+tool) for z in (vh,vt)]
    faces=[1 if c.single_angle_face=='positive' else -1] if count==1 else [-1,1]
    grip=count*a['t']+c.plate_t+c.bolt_washer_stack
    exempt=c.bolt_pretensioned and c.bolt in ('ASTM F3125 A325','ASTM F3125 A490')
    kg=1. if exempt else max(0.,1.-.01*max(0.,grip-5*c.bolt_diameter)/1.5)
    Lc=us[-1]-us[0];nominal=2*Lc*math.tan(math.pi/6)
    ch=core._line_intersections(g['poly_uv'],0,us[0])
    vl=max(v-nominal/2,ch[0]) if ch else v;vr=min(v+nominal/2,ch[1]) if ch else v
    zcent=[sign*(c.plate_t/2+a['centroid']) for sign in faces]
    vcent=v+a['centroid']-c.bolt_gauge
    ideal={'source':'NBR8800:2024 6.1.8.2',
           'scope':'ordinary static tensile equal-angle end, one straight row, standard bearing bolts and firm direct contact',
           'nominal_force_axis_v_z':[v,0.], 'physical_angle_centroid_v':vcent,
           'physical_angle_centroid_z':zcent,'ordinary_inplane_end_offset':a['centroid']-c.bolt_gauge,
           'raw_inplane_Mz_Nmm':-c.P*(a['centroid']-c.bolt_gauge),
           'raw_Mout_each_Nmm':[abs(c.P/count*z) for z in zcent],
           'raw_spatial_moments_each_Nmm':[{'Mx':-z*c.P/count*si,'My':z*c.P/count*co} for z in zcent],
           'assumed_spatial_cancellation':count==2, 'inplane_centroid_offset_cancels':False,
           'exact_3D_equilibrium_claimed':False,'raw_moment_resistance_verified':False,
           'real_workpoint_offset_retained':c.workpoint_offset,
           'Ct_uses_actual_catalog_ec':a['centroid'],
           'connection_axis_basis':'Nominal bolt-row axis at gusset midplane, engineering implementation of ordinary static end-axis exception; real centroids do not coincide.'}
    g.update(brace_lines=[],brace_weld_lines=[],brace_weld_count=0,brace_angle_count=count,
             brace_footprint=footprint,brace_free_end=[xy(uend,z) for z in (vh,vt)],
             brace_u_range=[us[0],us[-1]],brace_v_range=[vh,vt],
             brace_footprint_contained=all(core._inside(p,g['polygon']) for p in footprint),
             brace_connected_surface_z=[sign*c.plate_t/2 for sign in faces],
             brace_centroid_z=zcent[0] if count==1 else zcent,
             brace_centroid_v=vcent,nominal_connection_axis_z=0.,spatial_idealization=ideal,
             bolt_stations=us,bolt_centers=[xy(u,v) for u in us],bolt_row_v=v,
             physical_bolt_count=c.bolt_count,physical_shear_planes=count,physical_gusset_count=1,
             hole_diameter=dh,net_hole_diameter=dn,bolt_grip=grip,bolt_grip_factor=kg,
             bolt_grip_pretension_exemption=exempt,tool_required=tool,Lc=Lc,
             angle_free_end_u=uend,heel_extent=c.bolt_heel_extent,
             heel_extent_source=c.bolt_heel_extent_source,
             whitmore={'u':us[0],'v_range':[vl,vr],'width':max(0.,vr-vl),'nominal_width':nominal,
                       'centroid_v':(vl+vr)/2,'ends':[xy(us[0],vl),xy(us[0],vr)],
                       'contained':bool(ch and vl<=v-nominal/2+1e-8 and vr>=v+nominal/2-1e-8)})
    # Any welded intermediate 1L section is replaced by the actual connected leg.
    if count==1:
        z=faces[0]*c.plate_t/2;sign=faces[0]
        outline=[(vh,0),(vt,0),(vt,a['t']),(vh+a['t'],a['t']),(vh+a['t'],a['leg']),(vh,a['leg'])]
        g['brace_angle_section_vz']=[[vv,z+sign*zz] for vv,zz in outline]
    return g


def edge_id(g,u,v):
    co=g['angle_basis']['cos'];si=g['angle_basis']['sin'];p=[co*u-si*v,si*u+co*v]
    hits=[]
    for i,(a,b) in enumerate(zip(g['polygon'],g['polygon'][1:]+g['polygon'][:1])):
        cross=(p[0]-a[0])*(b[1]-a[1])-(p[1]-a[1])*(b[0]-a[0])
        if abs(cross)<1e-5 and min(a[0],b[0])-1e-7<=p[0]<=max(a[0],b[0])+1e-7 and min(a[1],b[1])-1e-7<=p[1]<=max(a[1],b[1])+1e-7:
            hits.append(('beam_support','right_free','top_free','column_support','clip_free')[i])
    # A point shared with a genuine free boundary is the free-side limit.
    # Interior supported endpoints and positive retained contact remain inactive.
    return next((edge for edge in hits if edge.endswith('_free')),hits[0] if hits else 'unknown')


def _distance(p,a,b):
    dx,dy=b[0]-a[0],b[1]-a[1];den=dx*dx+dy*dy
    q=max(0.,min(1.,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/den)) if den else 0.
    return math.hypot(p[0]-a[0]-q*dx,p[1]-a[1]-q*dy)


def detailing(c,g,out):
    core=_core();a=g['angle'];dh=g['hole_diameter'];dn=g['net_hole_diameter'];tool=g['tool_required'];edges=list(zip(g['polygon'],g['polygon'][1:]+g['polygon'][:1]));records=[]
    def limit(name,x,y,op='>=',severity='detail_fail',source='NBR8800:2024 6.3; Tabelas14/16'):
        ok=x>=y-1e-8 if op=='>=' else x<=y+1e-8
        records.append(dict(id=name,value=x,bound=y,operator=op,pass_=ok,source=source))
        core._check(out,name,y if op=='>=' else x,x if op=='>=' else y,source,component='detailing',value=x,bound=y,operator=op)
        if not ok:
            core._issue(out,name,severity,'Limite físico/detalhamento não atendido: '+name,value=x,bound=y,operator=op)
            if severity in ('unverified','detail_pending'):
                out['checks'][-1].update(status='UNVERIFIED',pass_=False,method_domain=True)
    for j,p in enumerate(g['bolt_centers']):
        for i,(aa,bb) in enumerate(edges):
            d=_distance(p,aa,bb)
            limit(f'bolt{j+1}_edge{i}_net_ligament',d,dn/2+1e-7,severity='invalid_geometry')
            limit(f'bolt{j+1}_edge{i}_minimum',d,EDGES[c.bolt_diameter])
            limit(f'bolt{j+1}_edge{i}_tool',d,tool+(c.root_weld_leg if i in (0,3) else 0.),severity='invalid_geometry',source='Envelope real informado ferramenta/hardware e raiz')
    for i in (1,2,4):
        limit(f'gusset_free_edge{i}_maximum_interpretation',min(_distance(p,*edges[i]) for p in g['bolt_centers']),min(12*c.plate_t,150.),'<=','unverified',
              'NBR6.3.12: diagnóstico conservador de toda borda livre; excedência exige interpretação de aplicabilidade da borda real')
    limit('bolt_pitch_minimum',c.bolt_pitch,max(2.7*c.bolt_diameter,dh+c.bolt_diameter))
    limit('bolt_pitch_net_ligament',c.bolt_pitch,dn+1e-7,severity='invalid_geometry')
    thin=min(a['t'],c.plate_t)
    limit('bolt_pitch_maximum',c.bolt_pitch,min(14*thin,180.) if c.bolt_exposure=='weathering' else min(24*thin,300.),'<=')
    limit('bolt_tool_covers_hole',c.bolt_tool_radius,dh/2,severity='invalid_geometry')
    limit('bolt_adjacent_tool_clearance',c.bolt_pitch,2*c.bolt_tool_radius+c.bolt_fabrication_clearance)
    for label,d in [('angle_end',c.bolt_angle_end),('angle_toe',a['leg']-c.bolt_gauge)]:
        limit(label+'_minimum',d,EDGES[c.bolt_diameter]);limit(label+'_maximum',d,min(12*a['t'],150.),'<=')
        limit(label+'_net_ligament',d,dn/2+1e-7,severity='invalid_geometry');limit(label+'_tool',d,tool,severity='invalid_geometry')
    limit('known_heel_thickness_hole',c.bolt_gauge-a['t'],dh/2,severity='invalid_geometry')
    if c.bolt_heel_extent<=0:
        core._issue(out,'bolt_heel_extent_missing','detail_pending','Informar envelope interno real do talão e sua origem. O catálogo Gerdau não publica raio; mecânica não certifica montagem.')
    else:
        limit('heel_extent_at_least_thickness',c.bolt_heel_extent,a['t'],severity='invalid_geometry')
        limit('heel_hole_clearance',c.bolt_gauge-c.bolt_heel_extent,dh/2,severity='invalid_geometry')
        limit('heel_tool_clearance',c.bolt_gauge-c.bolt_heel_extent,tool,severity='invalid_geometry')
        if not c.bolt_heel_extent_source.strip() or c.bolt_heel_extent_source=='Não informado':
            core._issue(out,'bolt_heel_source_missing','detail_pending','Identificar a origem do envelope real do talão informado.')
    if min(c.bolt_fabrication_clearance,c.bolt_washer_stack,c.bolt_heel_extent)<0:
        core._issue(out,'bolt_negative_clearances','invalid_geometry','Folgas, envelope e espessura de arruelas não podem ser negativos.')
    limit('bolt_lap_overlap',g['Lc']+c.bolt_angle_end,max(5*thin,25.))
    if g['bolt_grip_factor']<=0:core._issue(out,'bolt_grip_no_capacity','invalid_geometry','Pega excede o ramo de resistência positiva da NBR6.3.7.')
    if g['Lc']>950.:
        core._issue(out,'bolt_long_joint_distribution','unverified','Distância entre primeiro e último parafuso >950 mm: NBR6.3.8 prevê majoração1,20 de corte/contato nas emendas tracionadas. Adota-se conservadoramente esse limite para a extremidade em transpasse; distribuição longa e caminhos parciais não qualificados. Resultados abaixo são diagnósticos, sem proibir fisicamente a ligação longa.',Lc=g['Lc'])
    out['bolt_detailing']=records


def _section_area(vl,vh,hole_v,h,t):
    """Circular cut deduction clipped against an actual section interval."""
    lo=max(vl,hole_v-h);hi=min(vh,hole_v+h);d=max(0.,hi-lo)
    A=t*(vh-vl-d)
    if A<=1e-9:return None
    first=t*((vh*vh-vl*vl)-(hi*hi-lo*lo if d else 0.))/2
    vc=first/A
    I=t*((vh**3-vl**3)-(hi**3-lo**3 if d else 0.))/3-A*vc*vc
    return (A,vc,I,d) if I>1e-9 else None


def block_events(c,g):
    core=_core();poly=g['poly_uv'];us=g['bolt_stations'];r=g['net_hole_diameter']/2;v=g['bolt_row_v'];lo=us[0]-r;hi=us[-1]+r
    events={lo,hi}|{u+d for u in us for d in (-r,0.,r)}|{p[0] for p in poly if lo<=p[0]<=hi}
    for a,b in g['support_edges_uv'].values():
        events.update(p[0] for p in (a,b) if lo<=p[0]<=hi)
        for boundary in (v-r,v,v+r):
            if (a[1]-boundary)*(b[1]-boundary)<0:
                u=a[0]+(boundary-a[1])*(b[0]-a[0])/(b[1]-a[1])
                if lo<=u<=hi:events.add(u)
    base=sorted(events);mat=core.MATERIALS[c.gusset_steel]
    for a,b in zip(base,base[1:]):
        mid=(a+b)/2;j=next((j for j,u in enumerate(us) if abs(mid-u)<r),None)
        if j is None or b-a<1e-8:continue
        c1=core._line_intersections(poly,0,a);c2=core._line_intersections(poly,0,b)
        if not c1 or not c2:continue
        for side in (0,1):
            slope=(abs(c2[side]-v)-abs(c1[side]-v))/(b-a)
            for K in (-slope,1.2*mat['fy']/mat['fu']-slope):
                z=us[j]+r*K/math.hypot(1.,K)
                if a<z<b:events.add(z)
        for K in (1.2*mat['fy']/mat['fu'],1.2):
            z=us[j]+r*K/math.hypot(1.,K)
            if a<z<b:events.add(z)
    return sorted(events)


def support_hits(edges,planes):
    """Half-plane clip with one consistent snapped distance convention.

    A point contact at a support/free vertex has zero retained length. It is
    never promoted to a whole support by inconsistent tolerance/sign tests.
    """
    hits=[]
    for name,(a,b) in edges.items():
        lo,hi=0.,1.
        for n,k in planes:
            da=n[0]*a[0]+n[1]*a[1]-k;db=n[0]*b[0]+n[1]*b[1]-k
            da=0. if abs(da)<1e-9 else da;db=0. if abs(db)<1e-9 else db
            if da<0 and db<0:hi=-1.;break
            if (da>=0)!=(db>=0):
                f=da/(da-db)
                if da<0:lo=max(lo,f)
                else:hi=min(hi,f)
        length=max(0.,hi-lo)*math.dist(a,b)
        if length>1e-7:hits.append({'support':name,'length':length})
    return hits


def block_state(c,g,u,side):
    core=_core();poly=g['poly_uv'];us=g['bolt_stations'];v=g['bolt_row_v'];r=g['net_hole_diameter']/2;t=c.plate_t
    ch=core._line_intersections(poly,0,u);ray=core._line_intersections(poly,1,v)
    if not ch or not ray:return None
    vl,vh=ch;exit0=ray[1]
    captured=[j+1 for j,z in enumerate(us) if z+r>=u-1e-8];excluded=[j+1 for j,z in enumerate(us) if z-r>u+1e-8]
    if not captured:return None
    h=max([math.sqrt(max(0.,r*r-(u-z)**2)) for z in us if abs(u-z)<=r]+[0.])
    deduction=sum(max(0.,min(exit0,z+r)-max(u,z-r)) for z in us)
    if side in ('negative','positive'):
        vb=vl if side=='negative' else vh
        plane=((0.,-1.),-v) if side=='negative' else ((0.,1.),v)
        planes=[((1.,0.),u),plane]
        path=[[exit0,v],[u,v],[u,vb]];Agv=(exit0-u)*t;Anv=(exit0-u-deduction)*t;Ant=(abs(vb-v)-h)*t
    else:
        if not vl<=v-r or not v+r<=vh:return None
        left=core._line_intersections(poly,1,v-r);right=core._line_intersections(poly,1,v+r)
        if not left or not right:return None
        x0=left[1];x1=right[1];planes=[((1.,0.),u),((0.,1.),v-r),((0.,-1.),-(v+r))]
        path=[[x0,v-r],[u,v-r],[u,v+r],[x1,v+r]];Agv=(x0+x1-2*u)*t;Anv=Agv;Ant=(2*r-2*h)*t;vb=None
    hits=support_hits(g['support_edges_uv'],planes)
    base={'id':f'G_{side}_{u:.10f}','u':u,'side':side,'path_uv':path}
    if hits:return dict(base,active=False,reason='retains_supported_contact',support_hits=hits)
    if vb is not None and edge_id(g,u,vb).endswith('support'):
        return dict(base,active=False,reason='transverse_end_on_supported_edge')
    if min(Agv,Anv)<1e-8 or Ant< -1e-6:return dict(base,active=False,reason='nonpositive_net_path')
    Ant=max(0.,Ant);mat=core.MATERIALS[c.gusset_steel]
    Ry=(.6*mat['fy']*Agv+.5*mat['fu']*Ant)/c.gamma_a2;Rr=(.6*mat['fu']*Anv+.5*mat['fu']*Ant)/c.gamma_a2;Rd=min(Ry,Rr);D=abs(c.P)*len(captured)/c.bolt_count
    co=g['angle_basis']['cos'];si=g['angle_basis']['sin']
    return dict(base,active=True,Agv=Agv,Anv=Anv,Ant=Ant,Ryield=Ry,Rrupture=Rr,resistance=Rd,demand=D,utilization=D/Rd,
                path_xy=[[co*x-si*y,si*x+co*y] for x,y in path],captured_bolts_including_crossing=captured,
                captured_bolts_excluding_crossing=excluded,demand_limits=[abs(c.P)*len(excluded)/c.bolt_count,D],
                free_exit=[edge_id(g,*path[0]),edge_id(g,*path[-1])],
                force_model='included/excluded crossing-hole conservative envelope; no assumed contact-pressure distribution')


def section(c,g,forces,u,include=True,net=True):
    core=_core();ch=core._line_intersections(g['poly_uv'],0,u)
    if not ch or ch[1]-ch[0]<1e-8:return None
    vl,vh=ch;r=g['net_hole_diameter']/2;us=g['bolt_stations'];v=g['bolt_row_v']
    h=max([math.sqrt(max(0.,r*r-(u-z)**2)) for z in us if abs(u-z)<=r]+[0.]) if net else 0.
    area=_section_area(vl,vh,v,h,c.plate_t)
    if area is None:return None
    A,vc,I,ded=area;N=V=M=0.;retained=[];co=g['angle_basis']['cos'];si=g['angle_basis']['sin']
    for j,z in enumerate(us):
        yes=(z+r>=u-1e-8) if include and abs(z-u)<=r+1e-8 else (z-r>u+1e-8) if abs(z-u)<=r+1e-8 else z>u
        if yes:N+=c.P/c.bolt_count;M+=(vc-v)*c.P/c.bolt_count;retained.append('bolt'+str(j+1))
    for label,Fx,Fy in [('beam',-forces['Hb'],-forces['Vb']),('column',-forces['Hc'],-forces['Vc'])]:
        ends=sorted([[co*x+si*y,-si*x+co*y] for x,y in g[label+'_seam']]);pa,pb=ends;u0,u1=pa[0],pb[0]
        if u>=u1:continue
        if u1-u0<1e-10:continue
        fraction=1. if u<=u0 else (u1-u)/(u1-u0)
        q0=pa if u<=u0 else [u,pa[1]+(u-u0)*(pb[1]-pa[1])/(u1-u0)]
        uc=(q0[0]+pb[0])/2;vv=(q0[1]+pb[1])/2;nn=fraction*(co*Fx+si*Fy);tt=fraction*(-si*Fx+co*Fy)
        N+=nn;V+=tt;M+=(uc-u)*tt-(vv-vc)*nn;retained.append(label+'_root')
    N=0. if abs(N)<1e-8 else N;V=0. if abs(V)<1e-8 else V;M=0. if abs(M)<1e-6 else M
    sig=[N/A-M*(z-vc)/I for z in (vl,vh)];vm=max(math.hypot(z,math.sqrt(3)*1.5*V/A) for z in sig)
    return dict(u=u,include_cut_hole=include,net=net,chord_v=[vl,vh],A=A,centroid_v=vc,I=I,hole_half_chord=h,
                actual_deduction=ded,N=N,V=V,M=M,sigma_edges=sig,nominal_VM=vm,retained_sources=retained)


def _maximum(fun,lo,hi):
    q=(math.sqrt(5)-1)/2;a=hi-q*(hi-lo);b=lo+q*(hi-lo);fa=fun(a);fb=fun(b)
    for _ in range(70):
        if fa>fb:hi,b,fb=b,a,fa;a=hi-q*(hi-lo);fa=fun(a)
        else:lo,a,fa=a,b,fb;b=lo+q*(hi-lo);fb=fun(b)
    return (lo+hi)/2


def body_sections(c,g,forces,out,events):
    core=_core();co=g['angle_basis']['cos'];si=g['angle_basis']['sin'];end=g['bolt_stations'][-1]+g['net_hole_diameter']/2
    stations=sorted(set(events)|{p[0] for p in g['poly_uv'] if p[0]<=end}|{co*x+si*y for label in ('beam','column') for x,y in g[label+'_seam'] if co*x+si*y<=end})
    rows=[];exact=[];peaks=[]
    for inc in (False,True):
        for net in (False,True):
            def at(u):return section(c,g,forces,u,inc,net)
            exact.extend(z for u in stations if (z:=at(u)))
            for lo,hi in zip(stations,stations[1:]):
                if hi-lo<1e-8:continue
                grid=[lo+(hi-lo)*j/32 for j in range(33)];values=[at(u) for u in grid]
                rows.extend(z for z in values if z)
                for kind in (('normal','VM','negative','tension') if c.P<0 and c.topology=='symmetric_2L_T_bolted' else ('normal','VM','negative')):
                    def value(z):return -math.inf if z is None else z['nominal_VM'] if kind=='VM' else -min(z['sigma_edges']) if kind=='negative' else max(z['sigma_edges']) if kind=='tension' else max(map(abs,z['sigma_edges']))
                    vals=[value(z) for z in values]
                    for j in range(1,32):
                        if vals[j]>0 and vals[j]>=vals[j-1] and vals[j]>=vals[j+1] and (vals[j]>vals[j-1]+1e-11 or vals[j]>vals[j+1]+1e-11):
                            peak=at(_maximum(lambda u:value(at(u)),grid[j-1],grid[j+1]))
                            if peak:peaks.append(peak)
    allrows=rows+exact+peaks
    if not allrows:
        core._issue(out,'bolted_body_sections','unverified','Não foi possível formar seções físicas positivas.');return
    normal=max(allrows,key=lambda z:max(map(abs,z['sigma_edges'])));vm=max(allrows,key=lambda z:z['nominal_VM']);minimum=min(allrows,key=lambda z:min(z['sigma_edges']));mat=core.MATERIALS[c.gusset_steel]
    compression=c.P<0 and c.topology=='symmetric_2L_T_bolted'
    tension=max(allrows,key=lambda z:max(z['sigma_edges']))
    if not compression or max(tension['sigma_edges'])>1e-7:
        witness=tension if compression else normal
        core._check(out,'gusset_actual_net_body_rupture',max(witness['sigma_edges']) if compression else max(map(abs,witness['sigma_edges'])),mat['fu']/c.gamma_a2,('Seção líquida circular real; apenas tração positiva real na compressão; triagem nominal complementar N/M' if compression else 'Seção líquida circular real; triagem nominal complementar N/M'),component='gusset_sections',witness=witness,nominal_screen=True)
    core._check(out,'gusset_actual_net_body_yield',vm['nominal_VM'],mat['fy']/c.gamma_a1,'Seção real e forças de parafusos/raízes retidas; triagem nominal VM, não campo elástico de furos',component='gusset_sections',witness=vm,nominal_screen=True)
    # Negative hole-introduction nominal stress alone is not continuum buckling.
    gross_regions=[z for z in allrows if not z['net'] and all(abs(z['u']-u)>g['net_hole_diameter']/2+1e-7 for u in g['bolt_stations'])]
    grossmin=min((min(z['sigma_edges']) for z in gross_regions),default=0.)
    required=[]
    for z in allrows:
        if z['net']:continue
        N,M=z['N'],z['M'];vl,vh=z['chord_v']
        vr=z['centroid_v']-M/N if abs(N)>1e-6 else None
        if N< -1e-6 or (abs(N)<=1e-6 and abs(M)>1e-5) or (N>1e-6 and not vl-1e-7<=vr<=vh+1e-7):
            required.append(dict(u=z['u'],N=N,M=M,resultant_v=vr,chord_v=[vl,vh]))
    if required and not compression:core._issue(out,'UNVERIFIED_GROSS_GUSSET_COMPRESSION','unverified','Resultante da seção requer compressão normal: N negativo, binário sem N ou linha resultante fora da seção física. Caminho de compressão não qualificado.',witness=required[0])
    elif not compression and min(minimum['sigma_edges'])< -1e-6:
        core._issue(out,'nominal_section_negative_stress','note','Tensão linear nominal negativa retida como diagnóstico; resultante cabe no trecho físico e não prova compressão/instabilidade do contínuo.',minimum_normal=min(minimum['sigma_edges']))
    out['gusset_body']={'stations':stations,'station_oracles':exact,'governing':vm,'peak_normal_witness':normal,
                        'minimum_normal':min(minimum['sigma_edges']),'minimum_normal_witness':minimum,
                        'gross_unperforated_minimum_normal':grossmin,
                        'search':{'method':'hole/polygon/support events; 32 subdivisions per smooth interval and bounded refinement of observed extrema',
                                  'interval_certification':False,'pointwise_hole_stress_claimed':False},
                        'peak_normal':max(map(abs,normal['sigma_edges']))}


def calculate(c,g,forces,out):
    core=_core();check=core._check;issue=core._issue;a=g['angle'];ma=core.MATERIALS[c.angle_steel];mg=core.MATERIALS[c.gusset_steel]
    if c.topology=='symmetric_2L_T_bolted' and c.P<0:
        from .bolted_corner_compression import calculate as compression_calculate
        return compression_calculate(c,g,forces,out)
    if c.bolt_friction_type:
        from .bolted_corner_compression import friction
        friction(c,g,out)
    count=g['brace_angle_count'];P=abs(c.P);us=g['bolt_stations'];n=c.bolt_count;dh=g['hole_diameter'];dn=g['net_hole_diameter'];r=dn/2;t=c.plate_t
    Ct=max(.5,1-a['centroid']/g['Lc']);An=a['Ag']-dn*a['t'];prefix='1L' if count==1 else '2L-T'
    if An<=0:issue(out,'angle_nonpositive_net','invalid_geometry','Área líquida real da cantoneira não positiva.');return
    check(out,prefix+'_angle_gross_each',P/count,a['Ag']*ma['fy']/c.gamma_a1,'NBR5.2.2',component='angles')
    check(out,prefix+'_angle_net_effective_each',P/count,Ct*An*ma['fu']/c.gamma_a2,'NBR5.2.2/5.2.4/5.2.5',component='angles',Ct=Ct,An=An,Lc=g['Lc'])
    ray=core._line_intersections(g['poly_uv'],1,g['bolt_row_v'])
    if not ray:issue(out,'bolt_row_outside_polygon','invalid_geometry','A linha real não intercepta a chapa.');return
    exit0=ray[1];planes=[];bearings=[];paths=[]
    for j,u in enumerate(us):
        for plane in range(1,count+1):
            excluded=getattr(c,'bolt_threads_excluded_'+str(plane));coef=.56 if excluded and c.bolt!='ASTM A307' else .45
            R=coef*math.pi*c.bolt_diameter**2/4*BOLTS[c.bolt]/c.gamma_a2*g['bolt_grip_factor']
            z=check(out,f'{prefix}_bolt{j+1}_plane{plane}',P/(count*n),R,'NBR6.3.3.2/6.3.7 plano físico individual',component='bolts',bolt_index=j+1,plane=plane,threads_excluded=excluded,coefficient=coef,grip=g['bolt_grip'],grip_factor=g['bolt_grip_factor']);planes.append(z)
        for part,lc,th,mat,D in [('angle',c.bolt_angle_end-dh/2 if j==0 else c.bolt_pitch-dh,a['t'],ma,P/(count*n)),('gusset',c.bolt_pitch-dh if j<n-1 else exit0-u-dh/2,t,mg,P/n)]:
            R=max(0.,min(1.2*lc*th*mat['fu'],2.4*c.bolt_diameter*th*mat['fu'])/c.gamma_a2)
            z=check(out,(prefix+'_' if part=='angle' else 'common_')+part+f'_bearing{j+1}',D,R,'NBR6.3.3.3(a), deformação considerada; contato por furo, sem soma favorável',component=part+'_bearing',lc=lc,hole=j+1,force_direction='-u' if part=='angle' else '+u',physical_hole_diameter=dh);bearings.append(z)
    for k in range(1,n+1):
        Lv=c.bolt_angle_end+us[k-1]-us[0];Agv=Lv*a['t'];Anv=(Lv-(k-.5)*dn)*a['t']
        for side,Ant in [('connected_real_toe',(a['leg']-c.bolt_gauge-dn/2)*a['t']),('opposite_real_toe_catalog_complement',a['Ag']-(a['leg']-c.bolt_gauge)*a['t']-dn*a['t']/2)]:
            Ry=(.6*ma['fy']*Agv+.5*ma['fu']*Ant)/c.gamma_a2;Rr=(.6*ma['fu']*Anv+.5*ma['fu']*Ant)/c.gamma_a2
            z=check(out,f'{prefix}_angle_block_{side}_{k}',P*k/(count*n),max(0.,min(Ry,Rr)),'NBR6.5.6 ambos ramos; caminho para ponta livre real, talão não é borda livre',component='angle_block',Agv=Agv,Anv=Anv,Ant=Ant,Ryield=Ry,Rrupture=Rr,captured_bolts=list(range(1,k+1)),heel_is_free=False);paths.append(z)
    w=g['whitmore'];vl,vh=w['v_range'];v=g['bolt_row_v'];b=w['width']
    if b<=dn:issue(out,'whitmore_nonpositive_net','invalid_geometry','Whitmore real sem área líquida positiva.');return
    ends=[edge_id(g,w['u'],z) for z in (vl,vh)]
    if not w['contained'] and any(z.endswith('support') for z in ends):
        issue(out,'UNVERIFIED_WHITMORE_CROSS_INTERFACE','unverified','Whitmore alcança interface apoiada; contribuição do membro e resultante da faixa truncada precisam qualificação própria. Material além da chapa não é contado.',ends=ends)
    gross=_section_area(vl,vh,v,0.,t);net=_section_area(vl,vh,v,r,t)
    for name,prop,strength in [('gross',gross,mg['fy']/c.gamma_a1),('net_supplement',net,mg['fu']/c.gamma_a2)]:
        if prop is None:continue
        A,vc,I,ded=prop;M=-c.P*(v-vc);sig=max(abs(c.P/A-M*(z-vc)/I) for z in (vl,vh))
        # Express capacity in force units, retaining actual resultant eccentricity.
        factor=1/A+max(abs((v-vc)*(z-vc)/I) for z in (vl,vh));R=strength/factor
        check(out,'gusset_whitmore_'+name,P,R,'DG29 Ex5.1 faixa30° recortada real; centroide/resultante preservados; NBR6.5.3',component='gusset_whitmore',width=b,net_width=b-ded,A=A,centroid_v=vc,I=I,M=M,peak_stress=sig,clipped=not w['contained'])
        if min(c.P/A-M*(z-vc)/I for z in (vl,vh))< -1e-6:issue(out,'whitmore_compression','unverified','Faixa Whitmore possui borda nominal comprimida; método específico necessário.')
    events=block_events(c,g);allpaths=[z for u in events for side in ('negative','positive','tangent_U') if (z:=block_state(c,g,u,side))]
    for side in ('negative','positive','tangent_U'):
        active=[z for z in allpaths if z['side']==side and z['active']]
        if not active:issue(out,'gusset_block_'+side+'_unclosed','unverified','Família de bloco '+side+' sem candidato destacado admissível.');continue
        worst=max(active,key=lambda z:z['utilization']);check(out,'gusset_block_'+side,worst['demand'],worst['resistance'],'NBR6.5.6 dois ramos; polígono real, contato apoiado excluído e mínimos interiores dos furos',component='gusset_block',witness=worst)
    out['gusset_paths']={'admissible':[z for z in allpaths if z['active']],'rejected_supported':[z for z in allpaths if not z['active']],'events':events,'basis':'actual_two_support_polygon_L_and_tangent_U'}
    body_sections(c,g,forces,out,events)
    co=g['angle_basis']['cos'];si=g['angle_basis']['sin'];boltR=[sum(c.P/n*co for _ in us),sum(c.P/n*si for _ in us),sum(x*c.P/n*si-y*c.P/n*co for x,y in g['bolt_centers'])]
    expected=[forces['H'],forces['V'],c.P*c.workpoint_offset]
    if any(abs(x-y)>1e-6*max(1.,abs(y)) for x,y in zip(boltR,expected)):issue(out,'bolt_resultant_mismatch','invalid_input','Resultante dos parafusos não fecha a força nominal uma vez.')
    out['brace']={'Ct':Ct,'An':An,'Lc':g['Lc'],'angle_count':count,'weld_count':0,'physical_bolt_count':n,'shear_planes_per_bolt':count,'per_angle_force':c.P/count,'per_plane_force':c.P/(count*n),'force_per_gusset_hole':c.P/n,'physical_bolt_resultant':boltR,'nominal_connection_axis_z':0.,'face':c.single_angle_face if count==1 else 'both','angle_block_paths':paths}
