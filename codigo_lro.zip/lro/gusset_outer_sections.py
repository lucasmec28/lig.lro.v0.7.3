"""Exact rational normal extrema for the bounded cropped welded gusset.

Horizontal chord endpoints and centroid are affine between polygon/source
vertices. The VM value retains the pre-existing conservative separated-maxima
meaning; it is not relabeled as an exact continuum stress solution.
"""
import math
from numpy.polynomial import Polynomial as Poly
from .gusset_outer_end import line_chord


def roots(poly):
    return [float(z.real) for z in poly.roots() if abs(z.imag)<1e-8 and -1.+1e-10<z.real<1.-1e-10] if poly.degree()>0 else []


def welded_horizontal_sections(c,g,N):
    t=c.plate_t;C,S=g['direction'];L=c.weld_length;poly=g['polygon']
    bounds=sorted(set([p[1] for p in poly]+[p[1] for line in g['weld_lines'] for p in (line['start'],line['end'])]))
    cuts=[];intervals=[]
    for a,b in zip(bounds,bounds[1:]):
        if b-a<=1e-10:continue
        mid=(a+b)/2;half=(b-a)/2;Y=Poly([mid,half])
        ca,cb=line_chord(poly,1,a),line_chord(poly,1,b)
        if not ca or not cb:raise ValueError('Intervalo carregado sem seção no polígono atual.')
        XL=Poly([(ca[0]+cb[0])/2,(cb[0]-ca[0])/2]);XR=Poly([(ca[1]+cb[1])/2,(cb[1]-ca[1])/2])
        W=XR-XL;CG=(XR+XL)/2;Nr=Poly([0.]);Vr=Poly([0.]);Mo=Poly([0.])
        for line in g['weld_lines']:
            F=N*line['force_fraction'];start,end=line['start'][1],line['end'][1]
            if mid<=start:force=Poly([F])
            elif mid>=end:force=Poly([0.])
            else:force=F*(end-Y)/(L*S)
            k=line['centroid'][0]*S-line['centroid'][1]*C
            Nr+=S*force;Vr+=C*force;Mo+=force*(k+Y*C)
        Mc=Mo-CG*Nr
        values=[];tau_values=[];empty_tip=[]
        def row(z,sign,kind):
            width=float(W(z));y=float(Y(z));nr=float(Nr(z));vr=float(Vr(z));m=float(Mc(z))
            if width<=1e-9:
                # Source containment leaves the terminal zero-measure vertex
                # unloaded. A loaded zero-width section is never discarded.
                if any(p.coef.any() for p in (Nr,Vr,Mc)):
                    raise ValueError('Seção de largura nula mantém força ou momento; contorno incompatível.')
                empty_tip.append(y);return None
            cg=float(CG(z));area=t*width;inertia=t*width**3/12
            sigma=nr/area+sign*6*m/(t*width**2)
            return dict(y=y,edge='+s' if sign>0 else '-s',sigma_MPa=sigma,kind=kind,
                N=nr,V=vr,M=m,A=area,centroid_s=cg,I=inertia,width=width,
                endpoints=[float(XL(z)),float(XR(z))])
        for sign in (1.,-1.):
            numerator=Nr*W+sign*6*Mc
            stationary=roots(numerator.deriv()*W-2*numerator*W.deriv())
            for z in [-1.,1.]+stationary:
                item=row(z,sign,'stationary_rational' if z in stationary else 'boundary')
                if item is not None:cuts.append(item);values.append(item['sigma_MPa'])
        for z in (-1.,1.):
            width=float(W(z))
            if width>1e-9:tau_values.append(1.5*abs(float(Vr(z)))/(t*width))
            elif not Vr.coef.any():tau_values.append(0.)
            else:raise ValueError('Cisalhamento em seção degenerada.')
        sigma_abs=max(map(abs,values),default=0.);tau=max(tau_values,default=0.)
        intervals.append(dict(y_start=a,y_end=b,sigma_abs_max=sigma_abs,tau_abs_max=tau,
            von_mises_envelope=math.hypot(sigma_abs,math.sqrt(3)*tau),
            extrema_method='rational normal derivative roots; affine-ratio shear endpoints; separated conservative VM envelope',
            coordinate=dict(y_mid=mid,y_half_span=half,parameter_range=[-1.,1.]),
            normalized_width_coeff=W.coef.tolist(),normalized_centroid_coeff=CG.coef.tolist(),
            normalized_N_coeff=Nr.coef.tolist(),normalized_V_coeff=Vr.coef.tolist(),
            normalized_M_origin_coeff=Mo.coef.tolist(),normalized_M_centroid_coeff=Mc.coef.tolist(),
            unloaded_zero_measure_endpoints=sorted(set(empty_tip))))
    width=c.introduction_width;Ai=width*t;Si=width*width*t/6;angle=g['angle_section']
    mi=(angle['centroid']-angle['leg']/2)*N;s1=N/Ai+mi/Si;s2=N/Ai-mi/Si
    Ct=1/(1+(width/L)**2/3)*(1-width/(2*L)*t/width)
    local=dict(id='local_introduction',width=width,thickness=t,endpoints=g['introduction_endpoints'],
        A=Ai,S=Si,N=N,M=mi,sigma_min=min(s1,s2),sigma_max=max(s1,s2),Ct=Ct,
        spread_angle_deg=math.degrees(math.atan((width-angle['leg'])/(2*L))),
        Ct_basis='Adaptação conservadora de5.2.5(d) à faixa efetiva; chapa integral Ct1 por5.2.5(a).')
    if not cuts or not intervals:raise ValueError('Nenhuma seção física horizontal fechada.')
    return dict(cuts=cuts,intervals=intervals,local=local,bounds=bounds,
        min_normal=min([r['sigma_MPa'] for r in cuts]+[local['sigma_min']]),
        max_vm=max([r['von_mises_envelope'] for r in intervals]+[max(abs(s1),abs(s2))]))
