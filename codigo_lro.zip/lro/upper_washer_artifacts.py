"""Separate readable local detail; same result dictionary as the engine."""
from .display_precision import display_format
from io import BytesIO
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Circle
from docx.shared import Inches
from .upper_washer import LIMITS

def image_bytes(c,result,fmt='png'):
    u=c.upper_washer; d=result.local_upper_washer; s=c.anchor_washer_side; ta=c.anchor_washer_t
    with plt.rc_context({'font.family':'DejaVu Sans','font.size':9,'svg.fonttype':'none'}):
        fig,(ax,notes)=plt.subplots(1,2,figsize=(11,4.6),gridspec_kw={'width_ratios':[1,1.5]},layout='constrained')
        ax.set_aspect('equal');ax.axis('off');notes.axis('off')
        ax.add_patch(Rectangle((-s/2,-s/2),s,s,fc='#ccdce7',ec='#20354a'))
        ax.add_patch(Circle((0,0),(c.db+1.5)/2,fc='white',ec='#20354a'))
        if u.base_hole>0:ax.add_patch(Circle((0,0),u.base_hole/2,fill=False,ec='#777777',ls='--'))
        if u.layout=='four_edges':
            for i,((x0,y0),(x1,y1)) in enumerate([((-s/2,-s/2),(s/2,-s/2)),((s/2,-s/2),(s/2,s/2)),((s/2,s/2),(-s/2,s/2)),((-s/2,s/2),(-s/2,-s/2))]):
                line,=ax.plot([x0,x1],[y0,y1],color='#c66329',lw=3);line.set_gid('upper_washer_root_'+str(i))
        ax.annotate('',xy=(s*1.05,0),xytext=(s*.6,0),arrowprops={'arrowstyle':'->'})
        ax.text(s*.6,s*.08,'F = Fv,Rd',ha='left',va='bottom')
        ax.text(0,-s*.7,f"{display_format(s, 'g')} × {display_format(s, 'g')} × {display_format(ta, 'g')} mm\nFuro da arruela Ø{display_format(c.db + 1.5, 'g')} mm",ha='center')
        ax.set_xlim(-s*.8,s*1.6);ax.set_ylim(-s, s*.8);ax.set_title('ARRUELA SUPERIOR · PLANTA')
        values=[f"4 filetes contínuos, perna w={display_format(u.leg, 'g')} mm" if u.layout=='four_edges' else 'Arranjo fora do modelo de quatro filetes',
                f"Furo real da placa df={display_format(u.base_hole, 'g')} mm (tracejado)",u.steel+'; '+('SMAW / E7018 / passe único' if u.process=='smaw_e7018_single_pass' else u.process),
                'Contorno = linhas de raiz; sem comprimento extra nos cantos.']
        if 'F_N' in d:values += [f"F = {display_format(d['F_N'] / 1000, '.3f')} kN por arruela (não V/4)",f"Mapoio = {display_format(d['M_bearing_Nmm'] / 1000000.0, '.4f')} kN·m",f"|Mbarra,DG1| = {display_format(d['M_rod_DG1_Nmm'] / 1000000.0, '.4f')} kN·m",f"Mw = {display_format(d['M_envelope_Nmm'] / 1000000.0, '.4f')} kN·m (envelope aditivo)"]
        values += ['Momento fora do plano: M = F(tp/2 + 3ta/4).','Escolha conservadora do app; não altera o M global.','Flexão local, metal-base e conjunto completo pendentes.']
        for i,line in enumerate(values):notes.text(0,1-i*.084,line,va='top',fontsize=9,transform=notes.transAxes)
        out=BytesIO();fig.savefig(out,format=fmt,dpi=150);plt.close(fig);return out.getvalue()

def append_report(doc,c,result):
    if not c.native_anchor_shear or c.upper_washer.model=='off':return
    doc.add_paragraph('Arruela superior — verificações locais selecionadas',style='Heading 1').paragraph_format.page_break_before=True
    doc.add_picture(BytesIO(image_bytes(c,result)),width=Inches(6.95))
    d=result.local_upper_washer
    doc.add_paragraph('Aço: '+c.upper_washer.steel+'; processo/execução: '+c.upper_washer.process+f"; perna w={display_format(c.upper_washer.leg, 'g')} mm; furo real df={display_format(c.upper_washer.base_hole, 'g')} mm; concentricidade: "+('confirmada.' if c.upper_washer.centered else 'não confirmada.'))
    labels={'pass':'ATENDE no modelo local','fail':'NÃO ATENDE no modelo local','pending':'PENDENTE'}
    doc.add_paragraph('Modelo elástico de quatro filetes externos contínuos. Resultado: '+labels.get(d.get('status'),'PENDENTE')+'.')
    for key,value in d.get('statuses',{}).items():doc.add_paragraph({'weld_metal':'Metal das soldas','hole':'Furo, pressão e rasgamento','weld_detail':'Detalhamento dos filetes e implantação'}[key]+': '+labels[value])
    for reason in d.get('reasons',[]):doc.add_paragraph(reason)
    doc.add_paragraph('F=0,45(πdb²/4)fub/γa2, sem redução pela tração ou pelo cortante aplicado, inclusive V=0. M_apoio=Fta/2; |M_barra,DG1|=F(tp+ta/2)/2; Mw=F(tp/2+3ta/4). Este envelope aditivo é hipótese conservadora do app, não fórmula NBR nem prescrição DG1 de solda. Não modifica o equilíbrio global.')
    doc.add_paragraph('L=4b; Iy,linha=2b³/3; a=w/√2; qmax=√[(F/L)²+(Mw b/(2Iy,linha))²]; qRd=0,6fw a/1,35, fw=485 MPa. Furo: Rd=min(1,2lc ta fu;2,4db ta fu)/1,35, fu=450 MPa, lc=(b−db−1,5)/2. Envelope de capacidade no furo é opção conservadora do app; falha não demonstra reprovação para todo V aplicado menor.')
    doc.add_paragraph(LIMITS)
