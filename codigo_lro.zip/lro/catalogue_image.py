"""Clickable native catalogue images, independent from physical project state.

The local component sends only family ID and an event sequence. Its on_change
callback runs before the normal Streamlit rerun (and the native route selector).
No URL navigation, query-parameter routing, preset load or project serialization.
"""
from base64 import b64encode
from functools import lru_cache, partial
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


@lru_cache(maxsize=26)
def image_source(family_id):
    from .catalogue_ui import catalogue_assets
    asset = catalogue_assets()[family_id]
    data = (ROOT / 'data/catalogue_native' / asset['file']).read_bytes()
    return 'data:image/png;base64,' + b64encode(data).decode('ascii')


def image_clicked(state, family_id):
    """Validate the exact rendered family, monotonic event and current filters."""
    from .catalogue_ui import open_catalogue_card
    key = 'nav_guide_image_' + family_id
    event = state.get(key)
    if not isinstance(event, dict) or set(event) != {'family_id', 'sequence'}:
        return False
    sequence = event.get('sequence')
    if event.get('family_id') != family_id or type(sequence) is not int or not 0 < sequence <= 2147483647:
        return False
    seen_key = 'nav_guide_image_seen_' + family_id
    seen = state.get(seen_key, 0)
    if type(seen) is not int or sequence <= seen:
        return False
    # Consume even an obsolete filtered event; it must not replay after clearing.
    state[seen_key] = sequence
    return open_catalogue_card(state, family_id)


def render_image(st, state, family, asset):
    from streamlit.components.v1 import declare_component
    component = declare_component('lro_catalogue_image', path=str(ROOT / 'data/catalogue_image_component'))
    component(image_src=image_source(family.id), family_id=family.id,
              title=asset['title'], sequence=state.get('nav_guide_image_seen_' + family.id, 0),
              key='nav_guide_image_' + family.id, default=None,
              on_change=partial(image_clicked, state, family.id), tab_index=0)
