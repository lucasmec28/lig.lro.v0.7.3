"""Current-input four-view drawing of the 1L welded-column-flange family.

x follows the beam, y is vertical, and z crosses its single web. The
column face is x=0. Geometry is read only from the input. Caller-supplied
results are never a source of geometry, approval, capacities, or status.
"""
from io import BytesIO

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.path import Path
from matplotlib.patches import Circle, PathPatch, Polygon, Rectangle

from .angle_catalog_selection import add_drawing_provenance
from .display_precision import display_format
from .drawing_annotations import dimension, rendered_wrap
from .models import finite_real

INK = '#263746'
MUTED = '#60717e'
MEMBER = '#e0e6eb'
ANGLE = '#81b5c2'
WELD = '#b0382c'
RETURN = '#aa6517'
RED = '#a32835'

STATUS = {
    'INVALID_INPUT': 'DADOS INVÁLIDOS',
    'NUMERICAL_FAILURE': 'FALHA NUMÉRICA',
    'INVALID_GEOMETRY': 'GEOMETRIA INVÁLIDA',
    'OUTSIDE_SUPPORTED_SCOPE': 'FORA DO DOMÍNIO SUPORTADO',
    'DETAIL_FAIL': 'DETALHAMENTO NÃO ATENDIDO',
    'VERIFIED_SUBCHECK_FAIL': 'HÁ VERIFICAÇÃO NÃO ATENDIDA',
    'ENGINEERING_MODEL_PENDING': 'VERIFICAÇÃO COMPLEMENTAR PENDENTE',
    'COMPLETE_CHECKS_PASS_WITHIN_SCOPE': 'VERIFICAÇÕES LOCAIS ATENDIDAS NO DOMÍNIO',
}


def validated_result(c, result=None):
    """Recalculate current input even if the supplied result looks authentic."""
    from .welded_support_single_angle import evaluate
    try:
        return evaluate(c)
    except (AttributeError, TypeError, ValueError, ArithmeticError) as exc:
        return dict(status='INVALID_INPUT', global_pass=False, checks=[],
                    geometry={}, summary={}, issues=[dict(
                        severity='invalid_input', text=str(exc))])


def _approved(result):
    return (result.get('global_pass') is True
            and result.get('status') == 'COMPLETE_CHECKS_PASS_WITHIN_SCOPE'
            and result.get('geometry', {}).get('valid') is True
            and result.get('summary', {}).get('complete_checks') is True
            and bool(result.get('checks'))
            and all(row.get('status') == 'PASS' for row in result['checks'])
            and not any(row.get('severity') in {
                'invalid_input', 'invalid_geometry', 'unsupported_scope',
                'numerical_failure', 'detail_fail', 'access_pending',
                'engineering_pending', 'error', 'pending'}
                for row in result.get('issues', [])))


def _num(value, signed=False):
    if finite_real(value):
        return display_format(value, '+g' if signed else 'g')
    if isinstance(value, int) and not isinstance(value, bool):
        return 'inteiro fora da faixa numérica'
    return str(value)


def _label(value, limit=240):
    text = str(value)
    return text if len(text) <= limit else text[:limit] + ' […]'


def _drawable(c):
    """Only guard renderability; engine validity is independently displayed.

    Small invalid clearances/edge distances stay visible. Degenerate solids,
    nonfinite numbers, impossible root arcs, and unusable scales do not.
    """
    positive = ('beam_leg', 'support_leg', 't', 'length', 'beam_gauge',
                'web_pitch', 'web_end_top', 'db', 'hole_diameter', 'weld_leg')
    nonnegative = ('root_radius', 'angle_top', 'gap', 'top_return')
    vals = []
    for key in positive + nonnegative:
        value = getattr(c, key, None)
        if not finite_real(value) or value < 0 or (key in positive and value == 0):
            return False
        vals.append(value)
    for key in ('beam', 'support'):
        profile = getattr(c, key, None)
        for field in ('d', 'bf', 'tw', 'tf'):
            value = getattr(profile, field, None)
            if not finite_real(value) or value <= 0:
                return False
            vals.append(value)
        if profile.d <= 2*profile.tf or profile.bf <= profile.tw:
            return False
    if type(getattr(c, 'web_rows', None)) is not int or not 1 <= c.web_rows <= 20:
        return False
    if any(not finite_real(getattr(c, key, None)) for key in ('V', 'N', 'M', 'torsion')):
        return False
    solids = [v for v in vals if v > 0]
    if max(solids) > 1e6 or min(solids) < 1e-5 or max(solids)/min(solids) > 1e6:
        return False
    if c.t + c.root_radius >= min(c.beam_leg, c.support_leg):
        return False
    if c.top_return > c.support_leg or c.gap >= max(c.beam_leg, c.beam.d):
        return False
    return True


def _provenance(fig, c):
    try:
        return add_drawing_provenance(fig, c, area_factor=1)
    except (AttributeError, TypeError, ValueError, ArithmeticError):
        # A bad catalog identity is an engine blocker, not a reason to replace
        # the current input with a drawing of some approved preset.
        fig.text(.035, .849, 'Identidade do catálogo inconsistente; proveniência não validada.',
                 fontsize=8, color=RED, parse_math=False).set_gid('invalid_catalog_provenance')
        return fig


def _figure(c, result=None):
    result = validated_result(c, result)
    fig = plt.figure(figsize=(16, 12), facecolor='white')
    def text(x, y, value, gid=None, **kwargs):
        artist = fig.text(x, y, value, color=kwargs.pop('color', INK),
                          parse_math=False, **kwargs)
        artist.set_gid(gid)
        return artist
    text(.035, .967, '1L  |  CANTONEIRA SOLDADA À MESA DO PILAR',
         'drawing_family_welded_support_single_angle', fontsize=17, fontweight='bold')
    text(.035, .941, 'Projeto: ' + _label(getattr(c, 'project', '')),
         'current_project', fontsize=9)
    beam = getattr(c, 'beam', None)
    support = getattr(c, 'support', None)
    text(.035, .919, 'Viga: ' + _label(getattr(beam, 'name', '?'), 80)
         + '  |  Pilar: ' + _label(getattr(support, 'name', '?'), 80),
         'current_profiles', fontsize=9)
    status = result.get('status', 'INVALID_INPUT')
    text(.035, .895, STATUS.get(status, str(status)), 'engine_status_' + str(status),
         fontsize=10.2, fontweight='bold', color=INK if _approved(result) else RED)
    text(.965, .895, 'ATENDIMENTO LOCAL' if _approved(result) else 'SEM APROVAÇÃO GLOBAL',
         'approval_status', ha='right', fontsize=9, color=INK if _approved(result) else RED)
    actions = '; '.join(label + '=' + _num(getattr(c, key, None), True) + unit
                       for key, label, unit in [('V', 'V', ' N'), ('N', 'N', ' N'),
                                               ('M', 'M', ' N mm'), ('torsion', 'T', ' N mm')])
    text(.035, .872, 'Ações reais: ' + actions, 'actual_signed_actions', fontsize=9)
    topology = (getattr(c, 'kind', None) == 'column_flange'
                and getattr(c, 'side', None) in ('positive_z', 'negative_z')
                and getattr(c, 'web_columns', None) == 1
                and getattr(c, 'weld_layout', None) == 'toe_bottom_short_top')
    if not _drawable(c) or not topology:
        text(.06, .77, 'ENTRADA SEM REPRESENTAÇÃO FÍSICA SEGURA', 'diagnostic_only',
             fontsize=17, fontweight='bold', color=RED)
        rows = ['As dimensões ou a topologia exigem um detalhe próprio; nenhum exemplo substituiu a entrada.',
                'Apoio: ' + _label(getattr(c, 'kind', None))
                + '; lado: ' + _label(getattr(c, 'side', None))
                + '; colunas de parafusos: ' + _label(getattr(c, 'web_columns', None)) + '.',
                'Solda solicitada: ' + _label(getattr(c, 'weld_layout', None)) + '.',
                'Abas viga/apoio = ' + _num(getattr(c, 'beam_leg', None)) + ' / '
                + _num(getattr(c, 'support_leg', None)) + '; t = ' + _num(getattr(c, 't', None))
                + '; H = ' + _num(getattr(c, 'length', None)) + ' mm.']
        rows += [_label(row.get('text', row.get('message', '')), 350)
                 for row in result.get('issues', [])[:12]]
        if len(result.get('issues', [])) > 12:
            rows.append('Demais impedimentos constam da avaliação atual.')
        text(.06, .715, rendered_wrap('\n'.join(rows), 960, 10), 'input_diagnostic',
             fontsize=10, va='top', linespacing=1.6)
        text(.035, .04, 'Esquema não emitido. Sem aprovação global ou liberação de fabricação.',
             fontsize=10, color=RED)
        return _provenance(fig, c)

    # Separate physical-view and annotation lanes. Physical scales are equal
    # within each view; the enlarged grip is deliberately an independent scale.
    elev = fig.add_axes((.035, .492, .535, .321))
    front = fig.add_axes((.625, .488, .34, .325))
    plan = fig.add_axes((.035, .190, .535, .250))
    grip = fig.add_axes((.652, .209, .295, .196))
    for ax, name in ((elev, 'elevation_xy'), (front, 'support_face_zy'),
                     (plan, 'plan_xz'), (grip, 'grip_section_zy')):
        ax.set_aspect('equal')
        ax.axis('off')
        ax.set_gid('view_' + name)
    def title(ax, label):
        ax.set_title(label, loc='left', fontsize=10, fontweight='bold', color=INK, pad=14)
    def rect(ax, x, y, w, h, fill, gid, **kwargs):
        p = Rectangle((x, y), w, h, facecolor=fill, edgecolor=INK, lw=.8, **kwargs)
        p.set_gid(gid); ax.add_patch(p); return p
    def line(ax, xs, ys, gid=None, **kwargs):
        p, = ax.plot(xs, ys, color=kwargs.pop('color', INK), lw=kwargs.pop('lw', .8), **kwargs)
        p.set_gid(gid); return p
    def dim(ax, p1, p2, label, gid, side=1, fontsize=8):
        pair = dimension(ax, p1, p2, label, fontsize=fontsize, color=INK,
                         rotation=90 if p1[0] == p2[0] else 0, short_side=side)
        pair[0].set_gid('dimension_' + gid); pair[1].set_gid('dimension_label_' + gid)
        return pair
    def leader(ax, label, xy, xytext, gid=None, **kwargs):
        p = ax.annotate(label, xy=xy, xytext=xytext, ha=kwargs.pop('ha', 'left'),
                        va='center', fontsize=8, color=kwargs.pop('color', INK),
                        arrowprops={'arrowstyle':'-', 'lw':.6, 'color':MUTED},
                        bbox={'facecolor':'white', 'edgecolor':'none', 'pad':1},
                        parse_math=False, **kwargs)
        p.set_gid(gid); return p
    def cut(ax, left, right, y, gid):
        span=right-left
        line(ax, [left, left+.4*span, left+.45*span, left+.5*span, right],
             [y, y, y+6, y, y], gid, lw=1)
    yt = c.beam.d/2-c.angle_top
    yb = yt-c.length
    ys = [yt-c.web_end_top-i*c.web_pitch for i in range(c.web_rows)]
    end = c.length-c.web_end_top-(c.web_rows-1)*c.web_pitch
    sign = 1 if c.side == 'positive_z' else -1
    z0 = c.beam.tw/2
    heel = sign*z0
    toe = sign*(z0+c.support_leg)
    stub = max(c.beam_leg+160, c.beam.d*.72, c.beam_gauge+90)
    top = max(c.beam.d/2, yt, max(ys))+35
    bottom = min(-c.beam.d/2, yb, min(ys))-35
    row_span=max(top-bottom,c.beam.d)
    dl=row_span*.055

    title(elev, 'A  ELEVAÇÃO x–y  |  uma linha de furos na alma')
    rect(elev, -c.support.d, bottom, c.support.d, top-bottom, MEMBER, 'column_elevation_crop', alpha=.48)
    rect(elev, -c.support.tf, bottom, c.support.tf, top-bottom, MEMBER, 'column_front_flange_elevation')
    rect(elev, -c.support.d, bottom, c.support.tf, top-bottom, MEMBER, 'column_rear_flange_elevation')
    cut(elev, -c.support.d, 0, top, 'column_top_crop_elevation')
    cut(elev, -c.support.d, 0, bottom, 'column_bottom_crop_elevation')
    rect(elev, c.gap, -c.beam.d/2, stub-c.gap, c.beam.d, '#f0f3f5', 'beam_web_elevation')
    rect(elev, c.gap, -c.beam.d/2, stub-c.gap, c.beam.tf, MEMBER, 'beam_bottom_flange_elevation')
    rect(elev, c.gap, c.beam.d/2-c.beam.tf, stub-c.gap, c.beam.tf, MEMBER, 'beam_top_flange_elevation')
    rect(elev, 0, yb, c.beam_leg, c.length, ANGLE, 'single_angle_beam_leg_elevation', alpha=.88)
    # This red projection is x=0 on the COLUMN FACE, never at the beam-leg toe.
    line(elev, [0,0], [yb,yt], 'column_weld_toe_projection_elevation', color=WELD, lw=2.5)
    for index, y in enumerate(ys, 1):
        p=Circle((c.beam_gauge,y), c.hole_diameter/2, facecolor='white', edgecolor=INK, lw=.9)
        p.set_gid('beam_web_hole_elevation_'+str(index)); elev.add_patch(p)
        q=c.hole_diameter*.23
        line(elev,[c.beam_gauge-q,c.beam_gauge+q],[y,y], 'hole_center_x_'+str(index), lw=.5)
        line(elev,[c.beam_gauge,c.beam_gauge],[y-q,y+q], 'hole_center_y_'+str(index), lw=.5)
    # Length and pitch chains lie immediately outside the angle, away from V.
    lane=c.beam_leg+dl
    dim(elev,(lane,yb),(lane,yt),'H = '+_num(c.length),'angle_length')
    chain=lane+2*dl
    dim(elev,(chain,ys[0]),(chain,yt),'e₁='+_num(c.web_end_top),'web_end_top',-1)
    if len(ys)>1:
        dim(elev,(chain,ys[-1]),(chain,ys[0]),str(c.web_rows-1)+' × p='+_num(c.web_pitch),'web_pitch',-1)
    dim(elev,(chain,yb),(chain,ys[-1]),'e₂='+_num(end),'web_end_bottom',-1)
    dim(elev,(0,bottom-dl),(c.beam_leg,bottom-dl),'b viga='+_num(c.beam_leg),'beam_leg',-1)
    dim(elev,(0,top+dl),(c.beam_gauge,top+dl),'e='+_num(c.beam_gauge),'beam_gauge')
    leader(elev,'folga='+_num(c.gap),(c.gap/2,-c.beam.d/2),(-c.support.d*.60,bottom-2*dl),'beam_end_gap')
    leader(elev,'solda na mesa\n(ver B)',(0,(yt+yb)/2),(-c.support.d*.7,(yt+yb)/2),'column_weld_location',color=WELD)
    leader(elev,'a₀='+_num(c.angle_top),(c.beam_leg,yt),(stub-20,top+dl),'angle_top_offset',ha='right')
    ax=stub-22; ym=(yt+yb)/2
    if c.V:
        direction=-1 if c.V>0 else 1
        p=elev.annotate('',xy=(ax,ym+direction*45),xytext=(ax,ym-direction*30),
                        arrowprops={'arrowstyle':'-|>','color':RED,'lw':1.7,'mutation_scale':14})
        p.set_gid('load_V_positive_down' if c.V>0 else 'load_V_negative_up')
        p.arrow_patch.set_gid(p.get_gid())
    elev.text(ax-9,ym,'V='+_num(c.V/1000)+'\nkN',fontsize=9,ha='right',va='center',color=RED).set_gid('actual_load_V')
    elev.text(-c.support.d,top+dl,'Pilar contínuo\n(trecho interrompido)',fontsize=7.5,color=MUTED,va='center')
    elev.set_xlim(-c.support.d-12,stub+10)
    elev.set_ylim(bottom-3*dl,top+2.6*dl)

    title(front, 'B  FACE DO APOIO z–y  |  solda L na mesa')
    rect(front,-c.support.bf/2,bottom,c.support.bf,top-bottom,MEMBER,'column_flange_support_face',alpha=.75)
    for z in (-c.support.tw/2,c.support.tw/2):
        line(front,[z,z],[bottom,top],color=MUTED,ls='--',lw=.6)
    cut(front,-c.support.bf/2,c.support.bf/2,top,'column_top_crop_front')
    cut(front,-c.support.bf/2,c.support.bf/2,bottom,'column_bottom_crop_front')
    rect(front,min(heel,toe),yb,c.support_leg,c.length,ANGLE,'single_angle_support_leg_front')
    # Exactly two effective segments plus one physical, uncredited short return.
    line(front,[toe,toe],[yb,yt],'weld_vertical_toe_front',color=WELD,lw=3,solid_capstyle='butt')
    line(front,[toe,heel],[yb,yb],'weld_bottom_full_front',color=WELD,lw=3,solid_capstyle='butt')
    line(front,[toe,toe-sign*c.top_return],[yt,yt],'weld_short_top_return_uncredited_front',
         color=RETURN,lw=3,solid_capstyle='butt')
    # Beam end is a projection, without holes through the support flange.
    rect(front,-z0,-c.beam.d/2+c.beam.tf,c.beam.tw,c.beam.d-2*c.beam.tf,'none','beam_web_front_projection',linestyle='--')
    for label,y in [('top',c.beam.d/2-c.beam.tf),('bottom',-c.beam.d/2)]:
        rect(front,-c.beam.bf/2,y,c.beam.bf,c.beam.tf,'none','beam_'+label+'_front_projection',linestyle='--')
    for index,y in enumerate(ys,1):
        line(front,[min(-z0,heel+sign*c.t)-4,max(z0,heel+sign*c.t)+4],[y,y],
             'web_bolt_front_projection_'+str(index),lw=1.5)
    dim(front,(-c.support.bf/2,bottom-dl),(c.support.bf/2,bottom-dl),
        'bf pilar='+_num(c.support.bf),'column_flange_width',-1)
    dim(front,(min(heel,toe),top+dl),(max(heel,toe),top+dl),
        'b apoio='+_num(c.support_leg),'support_leg')
    # Mirrored labels occupy the free side of the beam and flange.
    lx=-sign*(c.support.bf/2+18)
    ha='right' if sign>0 else 'left'
    leader(front,'retorno '+_num(c.top_return)+'\nsem crédito',(toe-sign*c.top_return/2,yt),(lx,yt+24),
           'annotation_uncredited_return',ha=ha,color=RETURN)
    leader(front,'talão livre\nsem solda',(heel,yt-c.length*.22),(lx,yt-c.length*.30),
           'annotation_unwelded_heel',ha=ha)
    leader(front,'filete w='+_num(c.weld_leg),(toe,yb+c.length*.15),(sign*(c.support.bf/2+18),yb-12),
           'annotation_weld_leg',ha='left' if sign>0 else 'right',color=WELD)
    front.set_xlim(-c.support.bf/2-112,c.support.bf/2+112)
    front.set_ylim(bottom-2.2*dl,top+2.6*dl)

    title(plan,'C  PLANTA x–z  |  uma cantoneira, uma alma')
    rect(plan,-c.support.d,-c.support.bf/2,c.support.tf,c.support.bf,MEMBER,'column_rear_flange_plan')
    rect(plan,-c.support.tf,-c.support.bf/2,c.support.tf,c.support.bf,MEMBER,'column_front_flange_plan')
    rect(plan,-c.support.d+c.support.tf,-c.support.tw/2,c.support.d-2*c.support.tf,c.support.tw,
         MEMBER,'column_web_plan')
    rect(plan,c.gap,-z0,stub-c.gap,c.beam.tw,MEMBER,'single_beam_web_plan')
    for z in (-c.beam.bf/2,c.beam.bf/2):
        line(plan,[c.gap,stub],[z,z],ls='--',lw=.6,color=MUTED)
    b,s,t,rr=c.beam_leg,c.support_leg,c.t,c.root_radius
    k=.5522847498307936
    vertices=[(0,z0),(b,z0),(b,z0+t),(t+rr,z0+t)]
    codes=[Path.MOVETO,Path.LINETO,Path.LINETO,Path.LINETO]
    if rr:
        vertices.extend([(t+rr-k*rr,z0+t),(t,z0+t+rr-k*rr),(t,z0+t+rr)])
        codes.extend([Path.CURVE4]*3)
    else:
        vertices.append((t,z0+t)); codes.append(Path.LINETO)
    vertices.extend([(t,z0+s),(0,z0+s),(0,z0)])
    codes.extend([Path.LINETO,Path.LINETO,Path.CLOSEPOLY])
    p=PathPatch(Path([(x,sign*z) for x,z in vertices],codes),facecolor=ANGLE,edgecolor=INK,lw=1)
    p.set_gid('single_angle_L_plan_'+c.side); plan.add_patch(p)
    # Vertical toe fillet, cut horizontally: against x=0 column flange,
    # outward of the support-leg toe. No weld contacts the beam web.
    p=Polygon([(0,toe),(c.weld_leg,toe),(0,toe+sign*c.weld_leg)],
              facecolor=WELD,edgecolor=WELD,lw=.6)
    p.set_gid('column_weld_toe_section_plan'); plan.add_patch(p)
    low=min(-z0,heel+sign*t); high=max(z0,heel+sign*t)
    rect(plan,c.beam_gauge-c.hole_diameter/2,low,c.hole_diameter,high-low,'white','web_hole_cut_plan')
    rect(plan,c.beam_gauge-c.db/2,low-7,c.db,high-low+14,'#697c88','web_bolt_shank_plan')
    rect(plan,c.beam_gauge-c.db*.70,low-10,c.db*1.4,5,INK,'web_bolt_head_plan')
    rect(plan,c.beam_gauge-c.db*.65,high+5,c.db*1.3,5,INK,'web_bolt_nut_plan')
    line(plan,[c.beam_gauge-c.db*.75,c.beam_gauge+c.db*.75],[heel,heel],
         'single_shear_plane_plan',color=RED,lw=1.5,ls='--')
    leader(plan,'1L  '+('lado +z' if sign>0 else 'lado −z'),(b*.7,sign*(z0+t/2)),
           (b+40,sign*(c.support.bf/2+8)),'single_angle_side')
    leader(plan,'1 linha na alma',(c.beam_gauge,high+10),(b+50,-sign*(c.support.bf*.36)),
           'annotation_web_bolt_line')
    dim(plan,(0,-c.support.bf/2-30),(c.beam_leg,-c.support.bf/2-30),
        'b viga='+_num(c.beam_leg),'beam_leg_plan',-1)
    leader(plan,'mesa tf='+_num(c.support.tf),(-c.support.tf/2,c.support.bf*.3),
           (-c.support.d*.6,c.support.bf/2+28),'column_thickness')
    leader(plan,'filete na mesa',(c.weld_leg/3,toe+sign*c.weld_leg/3),
           (-c.support.d*.66,sign*(c.support.bf*.32)),'annotation_toe_weld_plan',color=WELD)
    plan.set_xlim(-c.support.d-15,stub+10)
    plan.set_ylim(-c.support.bf/2-60,c.support.bf/2+60)

    title(grip,'D  CORTE NO PARAFUSO  |  pega real, ampliada')
    # The plate widths in this section are their real thicknesses; the
    # enlarged independent scale never introduces a second angle/web.
    h=max(3*c.db,3*(c.beam.tw+c.t))
    rect(grip,-z0,-h/2,c.beam.tw,h,MEMBER,'single_beam_web_grip')
    rect(grip,min(heel,heel+sign*t),-h/2,t,h,ANGLE,'single_angle_beam_leg_grip')
    rect(grip,low,-c.hole_diameter/2,high-low,c.hole_diameter,'white','actual_hole_grip')
    extra=max(c.db*.4,4)
    rect(grip,low-extra,-c.db/2,high-low+2*extra,c.db,'#697c88','web_bolt_shank_grip')
    rect(grip,low-extra-4,-c.db*.70,4,c.db*1.4,INK,'web_bolt_head_grip')
    rect(grip,high+extra,-c.db*.65,4,c.db*1.3,INK,'web_bolt_nut_grip')
    line(grip,[heel,heel],[-h*.58,h*.58],'single_shear_plane_grip',color=RED,lw=1.5,ls='--')
    dim(grip,(low,-h*.80),(high,-h*.80),
        'pega = tw+t = '+_num(c.beam.tw+c.t),'single_shear_grip',-1,7.8)
    leader(grip,'1 plano de corte',(heel,h*.45),(high+18,h*.68),'annotation_one_shear_plane',ha='right',color=RED)
    leader(grip,'alma tw='+_num(c.beam.tw),(0,-h*.3),(low-17,-h*.35),'web_thickness',ha='right')
    leader(grip,'L: t='+_num(t),(heel+sign*t/2,h*.3),(high+17,h*.3),'angle_thickness')
    grip.set_xlim(low-70,high+80)
    grip.set_ylim(-h*1.07,h*.9)

    summary=[
        '1 peça L '+_num(c.beam_leg)+' × '+_num(c.support_leg)+' × '+_num(c.t)
        + '; raio interno r='+_num(c.root_radius)+' mm. Aço L: '+_label(c.angle_steel,80)+'.',
        str(c.web_rows)+' parafusos '+_label(c.bolt,80)+' Ø'+_num(c.db)
        + '; furos físicos Ø'+_num(c.hole_diameter)+'; 1 alma; corte simples; pega tw+t='+_num(c.beam.tw+c.t)+' mm.',
        'Solda na mesa: toe vertical H='+_num(c.length)+' + borda inferior b='+_num(c.support_leg)
        + ' mm; retorno superior '+_num(c.top_return)+' mm físico, sem crédito resistente.',
        'Filete w='+_num(c.weld_leg)+' mm; garganta a=w/√2; soldas resistentes em vermelho; retorno em ocre. Talão sem solda.',
        'Montagem: soldar 1L ao pilar em oficina; parafusar a viga em campo. Sem parafusos no apoio e sem solda na alma da viga.',
    ]
    if getattr(c, 'reinforced_weld_edge', False) is True:
        summary.append('Borda reforçada declarada: confirmar execução para w≤t (NBR 6.2.6.2.2(b)); nenhum acréscimo de resistência creditado.')
    text(.035,.153,'DETALHE FÍSICO E MONTAGEM',fontsize=10,fontweight='bold')
    text(.035,.133,'\n'.join(summary),'physical_topology_notes',fontsize=8.8,va='top',linespacing=1.48)
    text(.035,.034,'Cotas em mm. Domínio inicial: V descendente estático; N=M=T=0; pilar W contínuo; viga sem recorte.',
         'scope_note',fontsize=8.5)
    text(.035,.019,'Esquema dimensionado; não libera fabricação ou estabilidade global. Referência do detalhe: AISC P901 II.A-29; resistências locais NBR 8800.',
         'fabrication_disclaimer',fontsize=8.3)
    return _provenance(fig,c)


def drawing(c, result=None):
    """Return the standard matplotlib Figure; callers own closing it."""
    with plt.rc_context({'font.family':'DejaVu Sans', 'font.size':10,
                         'svg.fonttype':'none', 'text.parse_math':False}):
        return _figure(c, result)


def image_bytes(c, result=None, fmt='png'):
    """Raster/vector export from current input, never from supplied results."""
    with plt.rc_context({'font.family':'DejaVu Sans', 'font.size':10,
                         'svg.fonttype':'none', 'text.parse_math':False}):
        fig=_figure(c,result)
        try:
            out=BytesIO()
            fig.savefig(out,format=fmt,dpi=170,facecolor='white',
                        metadata={'Creator':'LRO 1L welded to column flange'})
            return out.getvalue()
        finally:
            plt.close(fig)


def drawing_svg(c, result=None):
    return image_bytes(c,result,'svg').decode('utf-8')
