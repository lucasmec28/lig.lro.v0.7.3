"""Proportional actual-detail sheet, distinct from the NBR force model drawing."""
from io import BytesIO
import math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Circle,Polygon
from .base_plate_drawing import INK,PLATE,COLUMN
from .base_plate_details import ANCHOR_TYPES,FIXITIES,weld_description
from .concrete_anchorage import SUPPORTED
from .drawing_annotations import dimension


def detail_image_bytes(c,r,fmt='png'):
    p=c.column;L,B=c.L,c.B;en=c.grout_t
    qualified_weld=getattr(c.column_weld,'model','off')=='two_flange_normal_web_shear'
    if qualified_weld:
        from .column_base_weld_drawing import require_current_result,_require_drawable_geometry
        require_current_result(c,r)
        _require_drawable_geometry(c)
    valid=(c.block_xmin<c.block_xmax and c.block_ymin<c.block_ymax and c.block_h>0 and
           c.hef>0 and min(c.anchor_head_length,c.anchor_head_width,c.anchor_head_t)>0 and
           max(abs(v) for v in (c.block_xmin,c.block_xmax,c.block_ymin,c.block_ymax,c.block_h,c.hef,
                                c.anchor_head_length,c.anchor_head_width,c.anchor_head_t,c.anchor_bearing_t,c.anchor_nut_t))<1e7)
    has_head=c.anchor_type in SUPPORTED
    show_block=valid and c.anchor_type!='unspecified'
    with plt.rc_context({'font.family':'DejaVu Sans','font.size':9,'svg.fonttype':'none'}):
        fig=plt.figure(figsize=(13,8.4),layout='constrained')
        grid=fig.add_gridspec(2,2,height_ratios=(3.7,1.5))
        plan=fig.add_subplot(grid[0,0]);sec=fig.add_subplot(grid[0,1]);notes=fig.add_subplot(grid[1,:])
        for ax in (plan,sec):ax.set_aspect('equal');ax.axis('off')
        notes.axis('off')
        def rect(ax,x,y,w,h,color,gid=None,**kw):
            patch=Rectangle((x,y),w,h,facecolor=color,edgecolor=INK,lw=.8,**kw)
            if gid:patch.set_gid(gid)
            ax.add_patch(patch);return patch
        def poly(ax,coords,color,gid,**kw):
            patch=Polygon(coords,closed=True,facecolor=color,edgecolor=INK,lw=.8,**kw)
            patch.set_gid(gid);ax.add_patch(patch)
        def text(ax,x,y,label,**kw):return ax.text(x,y,label,fontsize=8,color=INK,**kw)
        def dim(ax,x1,y1,x2,y2,label):
            side=(-1 if x1>0 else 1) if x1==x2 else (1 if y1>0 else -1)
            return dimension(ax,(x1,y1),(x2,y2),label,fontsize=8,
                             rotation=90 if x1==x2 else 0,color=INK,pad=1.2,lw=.65,short_side=side)
        # Rotated display: +x (column web and L) up, +y (B) to the right.
        plan.set_title('PLANTA DO DETALHE · ALMA VERTICAL',loc='left',fontsize=11,fontweight='bold',color=INK)
        if show_block:
            rect(plan,c.block_ymin,c.block_xmin,c.block_ymax-c.block_ymin,c.block_xmax-c.block_xmin,
                 '#f2f0ed','actual_concrete_block_plan')
            cone=r.geometry.get('concrete_cone',{})
            if cone.get('status')=='calculated':
                for i,box in enumerate(cone['governing']['projected_rectangles']):
                    x0,y0,x1,y1=box
                    rect(plan,y0,x0,y1-y0,x1-x0,'#cce3d3','cone_projection_'+str(i),alpha=.3)
        rect(plan,-B/2-en,-L/2-en,B+2*en,L+2*en,'#f3e7d3','grout_actual_footprint',alpha=.8,linestyle='--')
        rect(plan,-B/2,-L/2,B,L,PLATE,'baseplate_detail_plan',alpha=.65)
        rect(plan,-p.bf/2,-p.d/2,p.bf,p.tf,COLUMN)
        rect(plan,-p.bf/2,p.d/2-p.tf,p.bf,p.tf,COLUMN)
        rect(plan,-p.tw/2,-p.d/2+p.tf,p.tw,p.d-2*p.tf,COLUMN)
        for i,(x,y) in enumerate(((x,y) for x in (-c.a,c.a) for y in (-c.a2/2,c.a2/2)),1):
            if has_head and show_block:
                rect(plan,y-c.anchor_head_width/2,x-c.anchor_head_length/2,c.anchor_head_width,c.anchor_head_length,
                     'none','buried_head_plan_A'+str(i),linestyle='--')
            if c.native_anchor_shear:
                side=c.anchor_washer_side
                rect(plan,y-side/2,x-side/2,side,side,'#f0cb89','top_washer_plan_A'+str(i),alpha=.9)
            circle=Circle((y,x),c.db/2,facecolor='white',edgecolor=INK,lw=.8)
            circle.set_gid('detail_rod_A'+str(i));plan.add_patch(circle)
            # Keep the entire ID outside the rotated plate/grout, washer and
            # buried head. Near-edge alignment accounts for its rendered width.
            half_width=max(c.db/2,c.anchor_washer_side/2 if c.native_anchor_shear else 0,
                           c.anchor_head_width/2 if has_head and show_block else 0)
            sign=1 if y>0 else -1
            outer=max(B/2+en,abs(y)+half_width)
            plan.annotate('A'+str(i),xy=(sign*outer,x),xytext=(sign*5,0),
                          textcoords='offset points',fontsize=8,color=INK,
                          ha='left' if y>0 else 'right',va='center')
        if qualified_weld:
            from .column_base_weld_drawing import draw_plan_welds
            draw_plan_welds(plan,c,prefix='detail_cw_',linewidth=1.3)
        if c.stiffener_detail=='web_pair':
            rect(plan,-c.stiffener_t/2,p.d/2,c.stiffener_t,c.stiffener_length,'#cf9b8a','stiffener_above_plan')
            rect(plan,-c.stiffener_t/2,-p.d/2-c.stiffener_length,c.stiffener_t,c.stiffener_length,'#cf9b8a','stiffener_below_plan')
        extent_x=max(L/2+en,abs(c.block_xmin) if show_block else 0,abs(c.block_xmax) if show_block else 0)
        extent_y=max(B/2+en,abs(c.block_ymin) if show_block else 0,abs(c.block_ymax) if show_block else 0)
        m=max(35,extent_x*.11,extent_y*.11)
        dim(plan,-B/2,-extent_x-m,B/2,-extent_x-m,f'B={B:g}')
        dim(plan,-extent_y-m,-L/2,-extent_y-m,L/2,f'L={L:g}')
        plan.annotate('',(extent_y*.72,extent_x*.80),(extent_y*.72,extent_x*.58),arrowprops={'arrowstyle':'->','color':INK})
        plan.annotate('',(extent_y*.72,extent_x*.58),(extent_y*.4,extent_x*.58),arrowprops={'arrowstyle':'->','color':INK})
        text(plan,extent_y*.72,extent_x*.84,'+x (L)',ha='center')
        text(plan,extent_y*.46,extent_x*.62,'+y (B)',ha='center')
        plan.set_xlim(-extent_y-m*2,extent_y+m*1.1);plan.set_ylim(-extent_x-m*1.7,extent_x+m*.7)

        sec.set_title('CORTE x–z · PEÇA ENTERRADA ≠ ARRUELA SUPERIOR',loc='left',fontsize=10,fontweight='bold',color=INK)
        col_h=max(150.,c.stiffener_height*1.15 if c.stiffener_detail=='web_pair' else 150.)
        bottom=-en-c.block_h if show_block else -en-max(c.hef+50,200)
        if show_block:rect(sec,c.block_xmin,bottom,c.block_xmax-c.block_xmin,c.block_h,'#ece9e4','actual_block_section',hatch='..')
        poly(sec,[(-L/2,0),(L/2,0),(L/2+en,-en),(-L/2-en,-en)],'#f3e7d3','grout_45_section')
        rect(sec,-L/2,0,L,c.tp,PLATE)
        rect(sec,-p.d/2,c.tp,p.d,col_h,'#f2f3f4')
        rect(sec,-p.d/2,c.tp,p.tf,col_h,COLUMN);rect(sec,p.d/2-p.tf,c.tp,p.tf,col_h,COLUMN)
        for i,x in enumerate((-c.a,c.a),1):
            zhead=-en-c.hef if valid else -en-100
            rod_end=zhead-c.anchor_head_t if has_head and valid else max(bottom+30,-en-200)
            sec.plot([x,x],[rod_end,c.tp+c.anchor_washer_t+c.db],color=INK,lw=2,gid='actual_embedded_rod_'+str(i))
            if has_head and valid:
                rect(sec,x-c.anchor_head_length/2,zhead-c.anchor_bearing_t,c.anchor_head_length,c.anchor_bearing_t,
                     '#b2cbb6','buried_bearing_head_'+str(i))
                if c.anchor_type=='buried_plate_nut':
                    rect(sec,x-c.db*.75,zhead-c.anchor_bearing_t-c.anchor_nut_t,c.db*1.5,c.anchor_nut_t,'#637b8d','buried_retaining_nut_'+str(i))
                sec.plot([x-c.anchor_head_length/2,x+c.anchor_head_length/2],[zhead,zhead],color='#447c58',lw=2,gid='upper_buried_bearing_face_'+str(i))
            if c.native_anchor_shear:
                rect(sec,x-c.anchor_washer_side/2,c.tp,c.anchor_washer_side,c.anchor_washer_t,'#f0cb89','upper_welded_washer_'+str(i))
            rect(sec,x-c.db*.65,c.tp+(c.anchor_washer_t if c.native_anchor_shear else 0),c.db*1.3,c.db*.7,'#637b8d')
        if c.stiffener_detail=='web_pair':
            for sign in (-1,1):
                edge=sign*p.d/2
                poly(sec,[(edge,c.tp),(edge+sign*c.stiffener_length,c.tp),(edge,c.tp+c.stiffener_height)],'#cf9b8a','stiffener_triangle_'+str(sign),alpha=.9)
        sx=max(L/2+en,abs(c.block_xmin) if show_block else 0,abs(c.block_xmax) if show_block else 0)
        sm=max(35,sx*.12)
        sec.annotate(f'Graute e={en:g}; 45°', xy=(L/2+en/2,-en/2),
                     xytext=(L/2+sm*.8,c.tp+col_h*.62), fontsize=8, color=INK,
                     ha='left', va='center', arrowprops={'arrowstyle':'->','lw':.65,'color':INK},
                     bbox={'facecolor':'white','edgecolor':'none','pad':1.2})
        if has_head and valid:
            dim(sec,-sx-sm*.5,-en-c.hef,-sx-sm*.5,-en,f'hef físico={c.hef:g}')
            if show_block:
                dim(sec,sx+sm*.5,bottom,sx+sm*.5,-en,f'h={c.block_h:g}')
                text(sec,0,bottom+sm*.5,f'Cobrimento geométrico inferior = {c.block_h-c.hef-c.anchor_head_t:g} mm',ha='center',bbox={'facecolor':'white','edgecolor':'none','pad':1.2})
            text(sec,0,-en-c.hef-sm*.65,'Face SUPERIOR de apoio enterrada',ha='center',bbox={'facecolor':'white','edgecolor':'none','pad':1.2})
        else:text(sec,0,-en-65,'Mecanismo enterrado não definido neste desenho',ha='center',bbox={'facecolor':'white','edgecolor':'none','pad':1.2})
        text(sec,0,c.tp+col_h+sm*.55,'M na face superior preservado; vínculo não comprova rigidez.',ha='center')
        sec.set_xlim(-sx-sm*1.5,sx+sm*1.5);sec.set_ylim(bottom-sm*.35,c.tp+col_h+sm*1.2)
        # Fixed-size note area prevents callouts colliding with scaled detail geometry.
        lines=[
            'Ancoragem: '+ANCHOR_TYPES[c.anchor_type]+'. Família: '+c.catalog_label+'.',
            'Alma: '+weld_description(c,'web')+'. Mesas: '+weld_description(c,'flange')+'.',
            ('Solda pilar–placa: componente condicional duas mesas N/M e alma V em folha própria; base completa a complementar.' if qualified_weld else
             'Soldas especificadas, sem resistência geral N/M/V verificada. Filete de pernas iguais a 90°: a=z/√2. CJP exige preparação/inspeção.'),
            f'Graute a 45°: base inferior L+2e={L+2*en:g}; B+2e={B+2*en:g} mm. Contato de cálculo permanece B×lc, sem ganho por essa projeção.',
        ]
        if qualified_weld:
            lines.append('Soldas em planta: cinza=físico; laranja=mesa efetiva; azul=alma efetiva. Trechos retos centrados, sem crédito automático à largura total.')
        if c.stiffener_detail=='web_pair':
            lines.append(f'Interpretação inicial: 2 triângulos no plano da alma, além das mesas; projeção {c.stiffener_length:g}, altura {c.stiffener_height:g}, t={c.stiffener_t:g} mm. Sem crédito resistente.')
        if has_head:
            lines.append(f'Peça enterrada: envelope x×y={c.anchor_head_length:g}×{c.anchor_head_width:g}; peça t={c.anchor_bearing_t:g}; extensão total={c.anchor_head_t:g} mm. Apoio/rigidez não verificados.')
        lines.append('Cone isolado, quando calculado, não verifica pullout, ruptura lateral, fendilhamento, cortante/interação, peça enterrada ou bloco armado.')
        if not valid:lines.append('Geometria do detalhe incompleta ou inválida: contorno do bloco omitido. Corrija as dimensões para desenhar o bloco real.')
        for i,line in enumerate(lines):notes.text(.01,.98-i*.135,line,transform=notes.transAxes,color=INK,fontsize=8,va='top')
        output=BytesIO();fig.savefig(output,format=fmt,dpi=160,facecolor='white');plt.close(fig);return output.getvalue()
