"""Current-input, proportional axial single-angle/plate drawings and safe diagnostics."""
from .display_precision import display_format, display_value
from io import BytesIO

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.path import Path
from matplotlib.patches import Circle, PathPatch, Rectangle

from .angle_catalog_selection import add_drawing_provenance
from .drawing_annotations import dimension, rendered_wrap
from .models import finite_real

INK = '#263746'
MUTED = '#607080'
PLATE = '#e1e7ed'
ANGLE = '#82b7c4'
RED = '#a52934'


def validated_result(c, result=None):
    """A supplied result is compatibility-only, never an export authority."""
    from .axial_single_angle import evaluate
    try:
        return evaluate(c)
    except (TypeError, ValueError, OverflowError, ArithmeticError) as exc:
        return {'status': 'NUMERICAL_FAILURE', 'global_pass': False,
                'issues': [{'id': 'export_evaluation', 'severity': 'numerical_failure',
                            'message': str(exc)}], 'geometry': {'valid': False},
                'summary': {'complete_checks': False}, 'checks': [], 'cases': []}


def approved(result):
    return (result.get('global_pass') is True
            and result.get('geometry', {}).get('valid') is True
            and result.get('summary', {}).get('complete_checks') is True
            and bool(result.get('checks'))
            and all(row.get('status') == 'PASS' for row in result['checks'])
            and not any(row.get('severity') in {
                'invalid_input', 'invalid_geometry', 'unsupported_scope', 'outside_scope', 'numerical_failure',
                'detail_fail', 'engineering_pending', 'error', 'pending'}
                        for row in result.get('issues', [])))


def _num(value):
    if not finite_real(value):
        if isinstance(value,int) and not isinstance(value,bool):
            return 'inteiro fora da faixa numérica'
        return str(value)
    return f"{display_format(value, 'g')}"


def _drawable(c):
    for key in ('leg', 't', 'plate_width', 'plate_t', 'db', 'pitch', 'gauge',
                'angle_end', 'plate_end', 'terminal_extension'):
        value = getattr(c, key, None)
        if not finite_real(value) or value <= 0:
            return False
    for key in ('Ag', 'ec', 'tool_radius', 'fabrication_clearance', 'N', 'V', 'M', 'torsion'):
        value = getattr(c, key, None)
        if not finite_real(value):
            return False
    return (type(getattr(c, 'n', None)) is int and 1 <= c.n <= 100
            and finite_real(getattr(c, 'root_radius', None)) and c.root_radius >= 0
            and c.angle_count == 1)


def _text(fig, x, y, text, gid=None, **kwargs):
    artist = fig.text(x, y, text, color=kwargs.pop('color', INK), **kwargs)
    if gid:
        artist.set_gid(gid)
    return artist


def _figure(c, result=None):
    result = validated_result(c, result)
    fig = plt.figure(figsize=(14, 10.8), facecolor='white')
    _text(fig, .035, .962, 'LIGAÇÃO AXIAL 1L A CHAPA RETANGULAR PARAFUSADA', fontsize=16, fontweight='bold')
    _text(fig, .035, .937, rendered_wrap('Projeto: ' + str(getattr(c, 'project', '')), 905, 9),
          'current_project', fontsize=9, va='top')
    _text(fig, .035, .901, 'ATENDIMENTO LOCAL NO DOMÍNIO DECLARADO' if approved(result)
          else 'SEM APROVAÇÃO GLOBAL', 'approval_status', fontsize=10, fontweight='bold',
          color=INK if approved(result) else RED)
    _text(fig, .965, .901, str(result.get('status', 'NOT_EVALUATED')), 'engine_status', fontsize=8, ha='right',
          color=INK if approved(result) else RED)
    actions = '; '.join(key + '=' + _num(getattr(c, key, None)) + unit
                        for key, unit in (('N', ' N'), ('V', ' N'), ('M', ' N mm'), ('torsion', ' N mm')))
    _text(fig, .035, .875, 'Ações reais: ' + actions, 'actual_actions', fontsize=9)
    _text(fig, .035, .85, 'Modelo nominal estático NBR 6.1.8.2 e 6.5.2: N no eixo y=b/2, z=0; corte terminal centrado M=0.',
          'nominal_force_model', fontsize=9)
    if result.get('status') in {'INVALID_INPUT', 'NUMERICAL_FAILURE'} or not _drawable(c):
        _text(fig, .06, .74, 'ENTRADA NÃO REPRESENTÁVEL COM SEGURANÇA', 'diagnostic_only',
              fontsize=17, fontweight='bold', color=RED)
        lines = ['A geometria não foi substituída por um exemplo aprovado.',
                 'Quantidade de cantoneiras: ' + str(getattr(c, 'angle_count', None)),
                 'Quantidade de parafusos: ' + str(getattr(c, 'n', None))]
        lines += [str(row.get('id', '')) + ': ' + str(row.get('message', ''))
                  for row in result.get('issues', [])]
        _text(fig, .06, .68, rendered_wrap('\n'.join(lines), 820, 11), fontsize=11,
              va='top', linespacing=1.55)
        _text(fig, .035, .05, 'Sem aprovação da raiz, de soldas, do apoio ou de um nó completo.', fontsize=10, color=RED)
        return add_drawing_provenance(fig, c, area_factor=1)

    xs = [c.plate_end + i*c.pitch for i in range(c.n)]
    end = xs[-1] + c.angle_end
    terminal = end + c.terminal_extension
    by = c.plate_width/2
    heel = by - c.gauge
    toe = heel + c.leg
    start = -max(.26*terminal, .65*c.leg)
    dh = getattr(c, 'hole_diameter', 0)
    if not finite_real(dh) or dh <= 0:
        _text(fig, .06, .65, 'Diâmetro de furo indisponível. Desenho resistente não gerado.', fontsize=14, color=RED)
        return add_drawing_provenance(fig, c, area_factor=1)

    elev = fig.add_axes((.035, .485, .585, .315))
    section = fig.add_axes((.675, .49, .29, .31))
    plan = fig.add_axes((.035, .175, .585, .245))
    for ax in (elev, section, plan):
        ax.set_aspect('equal')
        ax.axis('off')
    def title(ax, text):
        ax.set_title(text, loc='left', fontsize=10, fontweight='bold', color=INK, pad=14)
    def rect(ax, x, y, w, h, fill, gid, **kwargs):
        p = Rectangle((x, y), w, h, facecolor=fill, edgecolor=INK, lw=.9, **kwargs)
        p.set_gid(gid); ax.add_patch(p); return p
    def line(ax, x, y, gid, **kwargs):
        artist, = ax.plot(x, y, color=kwargs.pop('color', INK), **kwargs)
        artist.set_gid(gid); return artist
    def dim(ax, p1, p2, text, side=1):
        return dimension(ax, p1, p2, text, fontsize=8, color=INK,
                         rotation=90 if p1[0] == p2[0] else 0, short_side=side)
    def arrow(ax, tail, head, gid, color=RED):
        artist = ax.annotate('', xy=head, xytext=tail,
                             arrowprops={'arrowstyle': '-|>', 'color': color, 'lw':1.4,
                                         'mutation_scale':11})
        artist.set_gid(gid); return artist

    title(elev, 'A  ELEVAÇÃO x y  Uma chapa real e uma linha de furos')
    rect(elev, 0, 0, terminal, c.plate_width, PLATE, 'plate_elevation')
    rect(elev, start, heel, end-start, c.leg, ANGLE, 'angle_elevation', alpha=.45)
    line(elev, [start, end], [heel+c.t, heel+c.t], 'angle_heel_elevation', lw=.8)
    line(elev, [start-15, terminal+25], [by, by], 'nominal_axis_elevation', ls='-.', lw=.6, color=MUTED)
    cg_y=heel+c.ec
    line(elev,[start,end],[cg_y,cg_y],'physical_angle_CG_geometry',ls=':',lw=.65,color=MUTED)
    elev.text(start-3,cg_y-4,'CG geométrico',ha='right',fontsize=7,color=MUTED)
    for index, x in enumerate(xs):
        p = Circle((x, by), dh/2, facecolor='white', edgecolor=INK, lw=.85)
        p.set_gid('hole_'+str(index+1)); elev.add_patch(p)
        line(elev, [x-dh*.25, x+dh*.25], [by, by], 'bolt_center_'+str(index+1), lw=.5)
        elev.text(x, by+dh/2+4, str(index+1), ha='center', fontsize=7, color=INK)
    line(elev, [terminal, terminal], [-5, c.plate_width+5], 'terminal_cut_elevation', color=RED, lw=1.6, ls='--')
    elev.text(terminal, c.plate_width+10, 'corte terminal', ha='center', fontsize=8, color=RED)
    elev.text(start, heel+c.leg*.72, '1L contínuo', fontsize=8, color=INK)
    elev.text(0, c.plate_width+10, 'borda livre x=0', fontsize=8)
    low = min(0, heel)-18
    dim(elev, (0, low), (xs[0], low), f"e chapa={display_format(c.plate_end, 'g')}", -1)
    dim(elev, (xs[0], low), (xs[-1], low), f"{display_value(c.n - 1)} × p={display_format(c.pitch, 'g')}", -1)
    dim(elev, (xs[-1], low), (end, low), f"e L={display_format(c.angle_end, 'g')}", -1)
    dim(elev, (end, low-25), (terminal, low-25), f"ext={display_format(c.terminal_extension, 'g')}", -1)
    dim(elev, (terminal+45, 0), (terminal+45, c.plate_width), f"b chapa={display_format(c.plate_width, 'g')}")
    if finite_real(c.N) and c.N != 0:
        direction = 1 if c.N > 0 else -1
        arrow(elev, (start-8, by), (start-8-direction*27, by), 'actual_angle_force')
        arrow(elev, (terminal+5, by), (terminal+5+direction*27, by), 'actual_plate_force')
    elev.text(start-3, by+22, f'N real={display_value(_num(c.N / 1000))} kN', ha='right', fontsize=8, color=RED)
    elev.set_xlim(start-68, terminal+70)
    elev.set_ylim(low-45, max(c.plate_width, toe)+28)

    title(section, 'B  SEÇÃO z y  Recobrimento simples')
    half = c.plate_t/2
    rect(section, -half, 0, c.plate_t, c.plate_width, PLATE, 'single_plate_section')
    kappa = .5522847498307936
    # Exactly one L on the positive plate face; actual rounded inside root.
    rr = c.root_radius
    vertices = [(0,0), (c.leg,0), (c.leg,c.t), (c.t+rr,c.t)]
    codes = [Path.MOVETO, Path.LINETO, Path.LINETO, Path.LINETO]
    if rr:
        vertices.extend([(c.t+rr-kappa*rr,c.t), (c.t,c.t+rr-kappa*rr), (c.t,c.t+rr)])
        codes.extend([Path.CURVE4]*3)
    vertices.extend([(c.t,c.leg), (0,c.leg), (0,0)])
    codes.extend([Path.LINETO, Path.LINETO, Path.CLOSEPOLY])
    patch = PathPatch(Path([(half+u, heel+v) for u,v in vertices], codes),
                      facecolor=ANGLE, edgecolor=INK, lw=.95)
    patch.set_gid('angle_L_section'); section.add_patch(patch)
    rect(section, -half-8, by-c.db/2, c.plate_t+c.t+16, c.db,
         '#bcc6cf', 'single_lap_bolt_section', alpha=.7)
    line(section, [half, half], [by-c.db*.7, by+c.db*.7],
         'shear_plane_1', lw=2.2, color=RED)
    line(section, [-half-12, half+c.t+12], [by, by], 'bolt_axis_section', lw=.6, ls='-.')
    cg_z=half+c.ec
    line(section, [0], [by], 'nominal_axis_section', marker='+', ms=9, mew=1.3, color=RED)
    line(section, [cg_z], [cg_y], 'physical_angle_CG_section', marker='o', ms=4, color=MUTED)
    section.annotate('CG físico', xy=(cg_z,cg_y), xytext=(cg_z+20,cg_y+24),
                     fontsize=7, color=MUTED, arrowprops={'arrowstyle':'-','color':MUTED,'lw':.6})
    section.annotate('eixo nominal\nz=0; y=b/2', xy=(0,by), xytext=(-22,by+52),
                     fontsize=7, color=RED, ha='center',
                     arrowprops={'arrowstyle':'-','color':RED,'lw':.6})
    # Tool footprint is in the x-y contact plane, shown by its y projection.
    required = c.tool_radius+c.fabrication_clearance
    line(section,[half+c.t]*2,[by-required,by+required],
         'declared_tool_envelope',color=MUTED,ls=':',lw=1.5)
    dim(section, (half+c.leg+12, heel), (half+c.leg+12, by), f"g={display_format(c.gauge, 'g')}")
    dim(section, (-half-23, heel), (-half-23, toe), f"L={display_format(c.leg, 'g')}")
    dim(section, (-half, min(0,heel)-18), (half+c.t, min(0,heel)-18),
        f"grip={display_format(c.t + c.plate_t, 'g')}", -1)
    section.text(half+c.leg*.62, heel+2, 'L único', fontsize=7, ha='center')
    section.text(half+c.leg*.4, max(c.plate_width,toe)+12,
                 f"chapa t={display_format(c.plate_t, 'g')}; L t={display_format(c.t, 'g')}; r={display_format(c.root_radius, 'g')} mm", fontsize=7, ha='center')
    section.set_xlim(-half-44, half+c.leg+32)
    section.set_ylim(min(0,heel)-40, max(c.plate_width,toe)+25)

    title(plan, 'C  CORTE LONGITUDINAL x z  Um parafuso atravessa chapa e L')
    rect(plan, 0, -half, terminal, c.plate_t, PLATE, 'single_plate_longitudinal')
    rect(plan, start, half, end-start, c.t, ANGLE, 'angle_longitudinal')
    plan.text(start+5, half+c.t+4, 'L único  N integral', fontsize=8, color=INK)
    line(plan,[start,terminal],[0,0],'nominal_axis_longitudinal',ls='-.',lw=.6,color=RED)
    line(plan,[start,end],[cg_z,cg_z],'physical_angle_CG_longitudinal',ls=':',lw=.65,color=MUTED)
    plan.text(start+5,cg_z+4,f"zCG={display_format(cg_z, 'g')} mm; omitido, não cancelado",fontsize=7,color=MUTED)
    for index,x in enumerate(xs):
        line(plan, [x,x], [-half-7, half+c.t+7], 'through_bolt_'+str(index+1), lw=2)
        line(plan, [x-c.db*.35,x+c.db*.35], [half]*2,
             f'bolt_{display_value(index + 1)}_plane_1', color=RED, lw=1.8)
    line(plan, [terminal,terminal], [-half-15,half+15], 'terminal_cut_longitudinal', color=RED, lw=1.4, ls='--')
    if finite_real(c.N) and c.N != 0:
        direction = 1 if c.N>0 else -1
        xmid = (xs[0]+xs[-1])/2
        arrow(plan, (xmid-15*direction, cg_z+21), (xmid+15*direction,cg_z+21), 'force_on_angle_positive_x')
        arrow(plan, (xmid+15*direction,-half-25), (xmid-15*direction,-half-25), 'force_on_plate_negative_x')
    plan.text(end+10, cg_z+20, 'no L: '+('+x' if c.N>0 else '−x' if c.N<0 else '0'), fontsize=8, color=RED)
    plan.text(end+10, -half-28, 'na chapa: '+('−x' if c.N>0 else '+x' if c.N<0 else '0'), fontsize=8, color=RED)
    dim(plan,(0,-half-47),(terminal,-half-47),f"x terminal={display_format(terminal, 'g')} mm",-1)
    plan.set_xlim(start-15,terminal+45)
    plan.set_ylim(-half-65,max(cg_z+45,half+c.t+45))

    notes = [
        f"{display_value(c.n)} parafusos {display_value(c.bolt)}; Ø{display_format(c.db, 'g')} / furo Ø{display_format(dh, 'g')} mm",
        f"1 plano físico; rosca excluída: {display_value('sim' if c.threads_excluded else 'não')}; grip=t+tp={display_format(c.t + c.plate_t, 'g')} mm",
        'Cantoneira e chapa: N integral; parafuso e plano: N/n',
        f"Ag de um L={display_format(c.Ag, 'g')} mm²; ec ativo em Ct={display_format(c.ec, 'g')} mm; lc={display_format((c.n - 1) * c.pitch, 'g')} mm",
        f"CG físico y={display_format(cg_y, 'g')}, z={display_format(cg_z, 'g')} mm; eixo nominal y={display_format(by, 'g')}, z=0",
        f"Afastamentos omitidos: y={display_format(c.ec - c.gauge, 'g')}; z={display_format(cg_z, 'g')} mm. Não há cancelamento.",
        f"Planos médios aba/chapa separados {display_format((c.plate_t + c.t) / 2, 'g')} mm",
        f"Ferramenta declarada r={display_format(c.tool_radius, 'g')} + folga={display_format(c.fabrication_clearance, 'g')} mm",
        'Terminal local: N real; M=0 apenas no eixo nominal',
        '45 kN e recomendação 50%: casos separados; N real preservado',
    ]
    case_labels={'actual':'real','minimum_45kN':'mínimo','recommended_half':'recomendado'}
    case_text='; '.join(case_labels.get(v.get('id'),str(v.get('id')))+' '+_num(v['N']/1000)+' kN'
                        for v in result.get('cases',[]) if finite_real(v.get('N')))
    if case_text:notes.append('Casos: '+case_text)
    _text(fig, .665, .411, 'DADOS E LIMITES LOCAIS', fontsize=10, fontweight='bold')
    _text(fig, .665, .387, rendered_wrap('\n'.join(notes), 296, 7.4), fontsize=7.4,
          va='top', linespacing=1.45)
    _text(fig, .035, .104, rendered_wrap('Perfil informado: '+str(c.profile_name)+'; fonte Ag/ec: '+str(c.profile_source), 900, 8),
          'profile_provenance', fontsize=8, va='top')
    _text(fig, .035, .052, 'Cotas em mm. Fronteira local no corte terminal; raiz, soldas, apoio e nó completo não verificados.',
          'local_scope_boundary', fontsize=9, color=RED)
    _text(fig, .035, .031, 'Chapa de largura real constante, sem Whitmore. Carga no CG real e ações secundárias não são resolvidas por este modelo nominal.',
          fontsize=8, color=MUTED)
    return add_drawing_provenance(fig, c, area_factor=1)


def drawing(c, result=None):
    return _figure(c, result)


def image_bytes(c, result=None, fmt='png', **kwargs):
    if fmt not in {'png', 'svg'}:
        raise ValueError('Formato suportado: png ou svg.')
    fig = _figure(c, result)
    buffer = BytesIO()
    try:
        with matplotlib.rc_context({'svg.fonttype': 'none'}):
            fig.savefig(buffer, format=fmt, dpi=kwargs.get('dpi', 160), facecolor='white')
        return buffer.getvalue()
    finally:
        plt.close(fig)


def drawing_svg(c, result=None):
    return image_bytes(c, result, fmt='svg').decode('utf-8')
