"""Bounded ordinary welded two-root corner compression, DG29 C / NBR 5.3.

No fixture/oracle data is used. Declarations describe real boundary details, not
an approval result. Their geometry digest is recomputed on every evaluation.
"""
import hashlib
import json
import math
from dataclasses import replace

RESTRAINT_FIELDS = ('compression_beam_restraint', 'compression_column_restraint',
                    'compression_brace_restraint', 'compression_detail_source',
                    'compression_geometry_stamp')
STATUSES = ('unknown', 'confirmed', 'absent')
MODEL = 'DG29_C_noncompact_K1_full_centered_stripe_max_NBR5_3'

def candidate(c):
    return getattr(c, 'topology', None) == 'symmetric_2L_T_welded' and getattr(c, 'P', 0) < 0


def geometry_identity(c):
    """Only physical restraint geometry/topology, never actions or materials.

The receiver-only lateral_restraint exception, case labels, grades, E, gamma,
bolt controls and unused single-angle face cannot invalidate this declaration.
"""
    from .corner_gusset import geometry
    g = geometry(c)
    identity = {'model': MODEL, 'topology': c.topology, 'symmetric': c.symmetric,
                'matching_cjp': c.matching_cjp,
                'polygon': g['polygon'], 'plate_t': c.plate_t,
                'beam_seam': g['beam_seam'], 'column_seam': g['column_seam'],
                'root_weld_leg': c.root_weld_leg, 'brace_u_range': g['brace_u_range'],
                'brace_v_range': g['brace_v_range'], 'brace_free_end': g['brace_free_end'],
                'brace_weld_leg': c.brace_weld_leg, 'brace_footprint': g['brace_footprint'],
                'phi_deg': c.phi_deg, 'workpoint_offset': c.workpoint_offset,
                'angle': {k: g['angle'][k] for k in ('leg', 't', 'Ag', 'centroid')},
                'continuity': g['continuity'],
                'joint_web_length': c.beam_web_weld_length, 'joint_web_leg': c.beam_web_weld_leg,
                'beam_access_radius': c.beam_access_radius,
                'continuity_flange_weld_leg': c.continuity_flange_weld_leg,
                'continuity_web_weld_leg': c.continuity_web_weld_leg,
                'column_ends': [c.column_end_bottom, c.column_end_top]}
    for key in ('beam', 'column'):
        identity[key] = {k: g[key][k] for k in ('d', 'bf', 'tf', 'tw', 'clear', 'family')}
    def normalize(v):
        if isinstance(v, bool): return v
        if isinstance(v, (int, float)): return float(v)
        if isinstance(v, dict): return {k: normalize(x) for k, x in v.items()}
        if isinstance(v, (list, tuple)): return [normalize(x) for x in v]
        return v
    return normalize(identity)


def geometry_stamp(c):
    return hashlib.sha256(json.dumps(geometry_identity(c), sort_keys=True,
                                    separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def declare_current_detail(c, source):
    """Explicit declaration helper; callers must supply the actual detail source.

This does not verify physical restraint, approve the project or bypass checks.
"""
    if not isinstance(source, str) or not source.strip() or source.strip() == 'Não informado':
        raise ValueError('Identifique a fonte/detalhe físico ordinário das três contenções.')
    proposal = replace(c, compression_beam_restraint='confirmed',
                       compression_column_restraint='confirmed', compression_brace_restraint='confirmed',
                       compression_detail_source=source.strip())
    return replace(proposal, compression_geometry_stamp=geometry_stamp(proposal))


def reduction(E, fy, area, thickness, length, gamma):
    """NBR 5.3 curve for every Le; no <=25 shortcut or Q-factor substitution."""
    r = thickness / math.sqrt(12)
    slenderness = length / r
    lambda0 = slenderness / math.pi * math.sqrt(fy / E)
    chi = 1. if lambda0 == 0 else .658 ** (lambda0 ** 2) if lambda0 <= 1.5 else .877 / lambda0 ** 2
    gross = area * fy / gamma
    return {'r': r, 'Le_over_r': slenderness, 'lambda0': lambda0,
            'Ne': math.pi ** 2 * E * area / slenderness ** 2 if slenderness else None,
            'chi': chi, 'A': area, 'Aef': area, 'gross_resistance': gross,
            'resistance': min(gross, chi * gross)}


def evaluate(c, g, forces, out):
    from .corner_gusset import _issue, _check, _inside, MATERIALS
    co = g['angle_basis']['cos']; si = g['angle_basis']['sin']
    raw = g['whitmore']['v_range']; h = min(-raw[0], raw[1]); u0 = g['brace_u_range'][0]
    source = c.compression_detail_source
    current_stamp = geometry_stamp(c)
    data = {'model': MODEL, 'K': 1., 'u0': u0, 'v0': 0., 'raw_v_range': list(raw),
            'selected_v_range': [-h, h], 'detail_source': source,
            'geometry_stamp': current_stamp, 'declared_geometry_stamp': c.compression_geometry_stamp,
            'declaration_matches_geometry': c.compression_geometry_stamp == current_stamp,
            'restraints': {root: getattr(c, 'compression_' + root + '_restraint') for root in ('beam', 'column', 'brace')},
            'local_scope': 'Local gusset and attached angle ends only; global brace/member/frame stability excluded.',
            'length_basis': 'K=1 x exact full-stripe maximum; conservative enlargement of DG29 C noncompact three-line average.',
            'free_clip': 'Inner relief is free, not support; nominal-face projection is the declared ordinary-corner idealization.',
            'inactive_mechanisms': ['Ct tension net rupture', 'support-side angle tension end block', 'outward gusset tension tear paths']}
    out['compression'] = data
    blockers = []
    def pending(id, message, **detail):
        blockers.append(id); _issue(out, id, 'unverified', message, **detail)
    for root, label in [('beam', 'viga'), ('column', 'pilar'), ('brace', 'extremidade/traspasse simétrico da diagonal')]:
        if data['restraints'][root] != 'confirmed':
            pending('compression_' + root + '_restraint', 'Contenção fora do plano na ' + label + ' não confirmada no detalhe físico atual.', declared=data['restraints'][root])
    if not source.strip() or source.strip() == 'Não informado':
        pending('compression_detail_source', 'Identifique a fonte/detalhe ordinário de contenção, incluindo recorte real e raízes efetivas; uma marcação não cria apoio.')
    if not data['declaration_matches_geometry']:
        pending('compression_geometry_declaration', 'A declaração do detalhe de compressão está ausente ou corresponde a outra geometria; confirme o recorte, raízes e traspasse atuais.')
    direct = all(forces[k] / c.P >= -1e-10 for k in ('Hb', 'Vb', 'Hc', 'Vc'))
    data['direct_load_flow'] = direct
    if not direct: pending('compression_direct_load_flow', 'Campo de raízes de sinais mistos exige qualificação específica; não pertence ao fluxo axial direto deste modelo.', component_over_P={k: forces[k] / c.P for k in ('Hb', 'Vb', 'Hc', 'Vc')})
    if not c.symmetric or abs(c.workpoint_offset) > 1e-9:
        pending('compression_axial_domain', 'O modelo de compressão exige 2L simétricas sem afastamento real ou binário independente na chapa.')
    if h <= 0 or co <= 1e-10 or si <= 1e-10:
        pending('compression_stripe_geometry', 'Não há faixa Whitmore centrada positiva no domínio angular ordinário.'); data['qualification_issues'] = blockers; data['qualified'] = False; return data
    def xy(v): return [u0 * co - v * si, u0 * si + v * co]
    ends = [xy(-h), xy(h)]
    contained = all(_inside(p, g['polygon']) for p in ends)
    data.update(width=2*h, selected_ends=ends, stripe_contained=contained)
    if not contained: pending('compression_stripe_containment', 'A faixa Whitmore centrada atravessa o contorno real; não se conta continuação no receptor.')
    if not g['brace_footprint_contained']: pending('compression_brace_footprint', 'A pegada real das cantoneiras/soldas precisa estar integralmente contida na chapa.')
    projections = {}
    for root, axis in [('beam', 0), ('column', 1)]:
        lo, hi = sorted(p[axis] for p in g[root + '_seam'])
        values = sorted(p[axis] for p in ends)
        valid = lo - 1e-8 <= values[0] and values[1] <= hi + 1e-8
        # The convex actual polygon contains each entire orthogonal segment
        # iff its stripe and seam endpoints are contained. No clip support.
        feet = [[p[0], g['eb']] if root == 'beam' else [g['ec'], p[1]] for p in ends]
        uninterrupted = all(_inside(p, g['polygon']) for p in feet)
        projections[root] = {'stripe_projection': values, 'effective_seam': [lo, hi],
                             'contained_in_effective_seam': valid, 'uninterrupted_plate_path': uninterrupted, 'feet': feet}
        if not valid or not uninterrupted:
            pending('compression_' + root + '_projection', 'Projeção perpendicular da faixa na raiz ' + root + ' sai da solda efetiva ou é interrompida pelo recorte; o apoio não pode ser presumido.', **projections[root])
    data['root_projections'] = projections
    def length(v):
        ub = (g['eb'] - v*co) / si; uc = (g['ec'] + v*si) / co
        return max(0., u0 - max(ub, uc))
    switch = g['eb'] * co - g['ec'] * si
    candidates = [-h, h] + ([switch] if -h <= switch <= h else [])
    stations = [{'v': v, 'length': length(v)} for v in candidates]
    governing = max(stations, key=lambda s: s['length'])
    lengths = [length(0.), length(-h), length(h)]
    result = reduction(c.E, MATERIALS[c.gusset_steel]['fy'], 2*h*c.plate_t, c.plate_t, governing['length'], c.gamma_a1)
    data.update(l1=lengths[0], l2=lengths[1], l3=lengths[2], three_line_average=sum(lengths)/3,
                full_strip_stations=stations, face_switch_v=switch, maximum_length_station=governing,
                Lmax=governing['length'], Le=governing['length'], **result)
    if result['Le_over_r'] > 200 + 1e-9:
        pending('compression_slenderness_service', 'Le/r excede a recomendação 200 da NBR5.3.7: resistência calculada mantida, mas a qualificação de comportamento em serviço pelo responsável está pendente; não é proibição absoluta.', Le_over_r=result['Le_over_r'], recommendation=200.)
    _check(out, 'gusset_centered_whitmore_compression_buckling', -c.P, result['resistance'],
           'DG29 Apêndice C: coluna equivalente não compacta K=1, Lmáx de toda faixa centrada; NBR8800:2024/Errata1:2025 5.3/6.5.4, sem atalho Le/r25', component='gusset_compression', **{k: v for k, v in data.items() if k not in ('resistance',)})
    data['qualification_issues'] = blockers
    data['qualified'] = not blockers
    return data
