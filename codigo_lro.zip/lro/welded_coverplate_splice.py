"""Isolated candidate: bounded welded coverplate FR splice, N/mm/MPa.

NBR 8800:2024 + Er1:2025 strength; AISC Manual15 Part12 FR force model.
Not registered in application until independent complete qualification.
"""
from __future__ import annotations
from dataclasses import asdict, dataclass, fields, replace
import hashlib
import json
import math

NBR = 'ABNT NBR 8800:2024, Errata 1:2025'
MODEL = 'AISC15_Part12_FR_flange_NM_web_V_eccentricity_waiver'
CONNECTION_TYPE = 'welded_coverplate_splice'
FAMILY = 'Emenda W · talas soldadas · N/M/V'
METHOD_REVISION = 'FR-coverplate-schema1'
SCOPE = ('Dois W/I laminados iguais, coaxiais e íntegros; talas externas iguais nas mesas e duas talas simétricas na alma. '
         'N/M pelas mesas, V/2 por tala de alma; resistências locais NBR, forças FR AISC15 Parte12. '
         'Le efetivos locais fornecidos pelo projetista para cada tala comprimida; dimensionamento global externo.')
SCHEMA = 1
E, G = 200000., 77000.
GA1, GA2, GW2 = 1.10, 1.35, 1.35
UNITS = dict(force='N', moment='N mm', length='mm', stress='MPa')
ASSUMPTIONS = dict(model=MODEL, strengths=NBR, flange_centroids='y=+/- (d+t_flange_cover)/2',
    axial_web_force=0., web_moment=0., common_receiver_web_count=1,
    global_member_design='external_prerequisite_not_numerically_checked',
    weld_pattern='two_longitudinal_edges_plus_outboard_transverse_per_overlap',
    throat='leg/sqrt(2)', directional_weld_enhancement=False,
    compression='designer_Le_each_flange_each_axis; exact_J; zero_warping_torsion_bound',
    gamma_a1=GA1, gamma_a2=GA2, gamma_w2=GW2)
DECLARATIONS = ('geometry_verified', 'materials_verified', 'weld_access_verified',
    'procedure_qualified', 'inspection_defined', 'all_welds_complete',
    'global_member_design_verified', 'integrity_actions_included')

@dataclass(frozen=True)
class LoadCase:
    id: str = 'ULS1'
    N: float = 0.
    M: float = 30e6
    V: float = 60e3
    torsion: float = 0.
    weak_M: float = 0.
    transverse_V: float = 0.

@dataclass(frozen=True)
class Restraint:
    Le_normal_mm: float = 0.
    Le_in_plane_mm: float = 0.
    reference: str = ''
    support_description: str = ''
    restraint_and_receiver_verified: bool = False
    detail_signature: str = ''

@dataclass(frozen=True)
class CoverplateSplice:
    project: str = 'Emenda com talas soldadas · candidato isolado'
    profile_name: str = 'W310x97'
    profile_kind: str = 'rolled_equal_coaxial_W'
    d: float = 308.
    bf: float = 305.
    tf: float = 15.4
    tw: float = 9.9
    root_radius: float = 16.1
    flange_width: float = 200.
    flange_t: float = 12.
    flange_overlap: float = 240.
    flange_leg: float = 6.
    web_height: float = 180.
    web_t: float = 10.
    web_overlap: float = 220.
    web_leg: float = 5.
    gap: float = 10.
    flange_setback: float = 8.
    web_setback: float = 8.
    member_fy: float = 345.
    member_fu: float = 450.
    cover_fy: float = 250.
    cover_fu: float = 400.
    electrode_fw: float = 485.
    procedure_id: str = ''
    top_restraint: Restraint = Restraint()
    bottom_restraint: Restraint = Restraint()
    cases: tuple[LoadCase, ...] = (LoadCase(),)
    geometry_verified: bool = False
    materials_verified: bool = False
    weld_access_verified: bool = False
    procedure_qualified: bool = False
    inspection_defined: bool = False
    all_welds_complete: bool = False
    global_member_design_verified: bool = False
    integrity_actions_included: bool = False
    static: bool = True
    normal_combination: bool = True
    fatigue: bool = False
    seismic: bool = False
    fire: bool = False
    erection: bool = False
    holes_or_notches: bool = False
    fillers_or_offsets: bool = False
    end_bearing: bool = False
    minimum_force: bool = True

    def to_dict(self):
        errors = input_errors(self)
        if errors:
            raise ValueError('; '.join(errors))
        value = asdict(self)
        value['cases'] = [asdict(x) for x in self.cases]
        return dict(schema_version=SCHEMA, connection_type=CONNECTION_TYPE,
                    units=dict(UNITS), assumptions=dict(ASSUMPTIONS), connection=value)

    @classmethod
    def from_dict(cls, data):
        if type(data) is not dict or set(data) != {'schema_version','connection_type','units','assumptions','connection'}:
            raise ValueError('Projeto nativo incompleto ou com campos desconhecidos.')
        if type(data['schema_version']) is not int or data['schema_version'] != SCHEMA or data['connection_type'] != CONNECTION_TYPE:
            raise ValueError('Família/versão incompatível.')
        def exact(a,b):
            return type(a) is type(b) and (set(a)==set(b) and all(exact(a[k],b[k]) for k in b) if isinstance(b,dict) else a==b)
        if not exact(data['units'],UNITS) or not exact(data['assumptions'],ASSUMPTIONS):
            raise ValueError('Unidades/premissas incompatíveis.')
        def construct(kind, raw):
            if type(raw) is not dict or set(raw) != {f.name for f in fields(kind)}:
                raise ValueError(kind.__name__+': campos completos explícitos obrigatórios.')
            return kind(**raw)
        raw = dict(data['connection']) if type(data['connection']) is dict else {}
        if set(raw) != {f.name for f in fields(cls)}:
            raise ValueError('Campos completos obrigatórios; sem defaults silenciosos.')
        raw['top_restraint'] = construct(Restraint,raw['top_restraint'])
        raw['bottom_restraint'] = construct(Restraint,raw['bottom_restraint'])
        if type(raw['cases']) is not list:
            raise ValueError('cases deve ser lista.')
        raw['cases'] = tuple(construct(LoadCase,x) for x in raw['cases'])
        c = cls(**raw)
        c.to_dict()
        return c


def finite(v):
    try:
        return type(v) in (int,float) and math.isfinite(v)
    except (ValueError,OverflowError):
        return False


def input_errors(c):
    if not isinstance(c,CoverplateSplice):
        return ['Entrada deve ser CoverplateSplice.']
    errors=[]
    def scalars(obj):
        for f in fields(obj):
            v=getattr(obj,f.name)
            if f.type in ('str',str):
                if type(v) is not str: errors.append(f.name+': texto obrigatório.')
                elif any(not (ord(ch) in (9,10,13) or 0x20<=ord(ch)<=0xD7FF or 0xE000<=ord(ch)<=0xFFFD or 0x10000<=ord(ch)<=0x10FFFF) for ch in v):
                    errors.append(f.name+': caractere de controle/surrogate inválido para texto e documentos.')
            elif f.type in ('bool',bool):
                if type(v) is not bool: errors.append(f.name+': booleano explícito obrigatório.')
            elif f.type in ('float',float) and not finite(v):
                errors.append(f.name+': número real finito obrigatório.')
    scalars(c)
    for k in ('top_restraint','bottom_restraint'):
        r=getattr(c,k)
        if not isinstance(r,Restraint):errors.append(k+': registro de travamento obrigatório.')
        else:scalars(r)
    if type(c.cases) is not tuple or not 1<=len(c.cases)<=100:
        errors.append('Uma a 100 combinações explícitas obrigatórias.')
    else:
        used=set()
        for case in c.cases:
            if not isinstance(case,LoadCase):errors.append('Combinação inválida.');continue
            scalars(case)
            if type(case.id) is not str or not case.id.strip() or case.id in used or case.id.endswith(':minimum'):
                errors.append('Identificador de combinação vazio/duplicado/reservado.')
            if type(case.id) is str:used.add(case.id)
    return errors


def detail_signature(c):
    """A record must be deliberately rebound after geometry/material/sign changes."""
    keys=('profile_kind','d','bf','tf','tw','root_radius','flange_width','flange_t','flange_overlap',
          'flange_leg','web_height','web_t','web_overlap','web_leg','gap','flange_setback','web_setback',
          'member_fy','member_fu','cover_fy','cover_fu','electrode_fw','procedure_id')
    raw={k:getattr(c,k) for k in keys}
    def sign(x):return 0 if x==0 else 1 if x>0 else -1
    raw['directions']=[]
    for case in all_cases(c):
        direction={k:sign(case[k]) for k in ('N','M','V')}
        direction.update(top_flange=sign(case['N']/2+case['M']/(c.d+c.flange_t)),
                         bottom_flange=sign(case['N']/2-case['M']/(c.d+c.flange_t)))
        raw['directions'].append(direction)
    return hashlib.sha256(json.dumps(raw,sort_keys=True,allow_nan=False).encode()).hexdigest()


def restraint_signature(c,record,element):
    """Bind actual engineering input and its element, not only geometry."""
    if element not in ('top','bottom') or not isinstance(record,Restraint):
        raise ValueError('Identificação da tala e registro de vínculos obrigatórios.')
    data=asdict(record);data.pop('detail_signature')
    raw=dict(detail=detail_signature(c),element=element,restraint=data)
    return hashlib.sha256(json.dumps(raw,sort_keys=True,allow_nan=False).encode()).hexdigest()


def rectangle_J(b,t):
    wide,thin=max(b,t),min(b,t)
    if not all(finite(x) and x>0 for x in (wide,thin)):raise ValueError('Retângulo inválido.')
    series=math.fsum(math.tanh(n*math.pi*wide/(2*thin))/n**5 for n in range(1,1000,2))
    return wide*thin**3/3*(1-192*thin*series/(math.pi**5*wide))


def compression_rectangle(b,t,Le_normal,Le_in_plane,fy):
    """Independent axes, zero-warping torsion bound, actual AA overlap width.

    The bridge is a solid rectangle, not two fictitious flange outstands.
    The AA reduction concerns the overlap between its real edge weld lines.
    """
    if not all(finite(x) and x>0 for x in (b,t,Le_normal,Le_in_plane,fy)):
        raise ValueError('Compressão: dimensões/Le/fy positivos obrigatórios.')
    A=b*t;In=b*t**3/12;Ip=t*b**3/12;J=rectangle_J(b,t)
    rn=t/math.sqrt(12);rp=b/math.sqrt(12)
    Ne_n=math.pi**2*E*In/Le_normal**2
    Ne_p=math.pi**2*E*Ip/Le_in_plane**2
    Ne_t=G*J/((In+Ip)/A)
    Ne=min(Ne_n,Ne_p,Ne_t);lambda2=A*fy/Ne
    chi=.658**lambda2 if lambda2<=2.25 else .877/lambda2
    local_limit=1.4*math.sqrt(E/fy)
    local_ratio=b/t
    stocky=max(Le_normal/rn,Le_in_plane/rp)<=25 and Ne_t>=A*fy and local_ratio<=local_limit
    used_chi=1. if stocky else chi
    # NBR5.3.4 AA element, reduced stress chi*fy; no central support line.
    sigma_el=(1.31*local_limit/local_ratio)**2*fy
    s=math.sqrt(sigma_el/(used_chi*fy))
    be=b if local_ratio<=local_limit/math.sqrt(used_chi) else min(b,max(0.,b*(1-.18*s)*s))
    return dict(A_mm2=A,Aeff_mm2=be*t,J_mm4=J,Ne_normal_N=Ne_n,Ne_in_plane_N=Ne_p,
        Ne_torsion_lower_N=Ne_t,Ne_min_N=Ne,lambda0=math.sqrt(lambda2),chi=used_chi,
        chi_member_curve=chi,Le_normal_mm=Le_normal,Le_in_plane_mm=Le_in_plane,
        slenderness_normal=Le_normal/rn,slenderness_in_plane=Le_in_plane/rp,
        normal_direction='y; flexão z',in_plane_direction='z; flexão y',length_kind='effective_Le_no_second_K',
        local_element='AA entre as duas soldas longitudinais reais',local_width_mm=b,beff_mm=be,
        branch='6.5.4a_stocky' if stocky else '6.5.4b_5.3',
        capacity_N=used_chi*be*t*fy/GA1, torsion_model='Saint-Venant exact rectangle; Cw term omitted conservatively')


def elastic_line_group(segments,Fx,Fy,C=0.):
    """Exact finite segments; C is moment ABOUT GROUP CENTROID, not origin."""
    parts=[]
    for p,q in segments:
        L=math.hypot(q[0]-p[0],q[1]-p[1])
        if L<=0:raise ValueError('Segmento de solda degenerado.')
        parts.append((p,q,L,((p[0]+q[0])/2,(p[1]+q[1])/2)))
    L=math.fsum(x[2] for x in parts)
    xc=math.fsum(x[2]*x[3][0] for x in parts)/L
    yc=math.fsum(x[2]*x[3][1] for x in parts)/L
    J=math.fsum(l*((m[0]-xc)**2+(m[1]-yc)**2+l*l/12) for p,q,l,m in parts)
    points=[];integrals=[]
    for i,(p,q,l,m) in enumerate(parts):
        for point in (p,q):
            x,y=point;qx=Fx/L-C*(y-yc)/J;qy=Fy/L+C*(x-xc)/J
            points.append(dict(segment=i,x=x,y=y,qx=qx,qy=qy,q=math.hypot(qx,qy)))
        qx=Fx/L-C*(m[1]-yc)/J;qy=Fy/L+C*(m[0]-xc)/J
        moment=l*((m[0]-xc)*qy-(m[1]-yc)*qx)+C/J*l**3/12
        integrals.append(dict(Fx=qx*l,Fy=qy*l,C=moment))
    return dict(L_mm=L,centroid_mm=[xc,yc],Jline_mm3=J,points=points,qmax_N_mm=max(x['q'] for x in points),
        Fx=Fx,Fy=Fy,C=C,integrated_Fx=math.fsum(x['Fx'] for x in integrals),
        integrated_Fy=math.fsum(x['Fy'] for x in integrals),integrated_C=math.fsum(x['C'] for x in integrals))


def geometry(c):
    hw=c.d-2*c.tf;clear=hw-2*c.root_radius
    if min(c.d,c.bf,c.tf,c.tw,c.flange_width,c.flange_t,c.flange_overlap,c.flange_leg,
           c.web_height,c.web_t,c.web_overlap,c.web_leg,c.gap,c.flange_setback,c.web_setback)<=0 or c.root_radius<0:
        raise ValueError('Dimensões positivas obrigatórias; raio não negativo.')
    if min(clear,c.bf-c.tw)<=0:raise ValueError('Geometria do perfil inválida.')
    groups={}
    for name,width,overlap,setback in [('flange',c.flange_width,c.flange_overlap,c.flange_setback),('web',c.web_height,c.web_overlap,c.web_setback)]:
        for side,s in [('left',-1),('right',1)]:
            inner=s*(c.gap/2+setback);outer=s*(c.gap/2+overlap)
            groups[name+'_'+side]=[((inner,-width/2),(outer,-width/2)),
                                  ((inner,width/2),(outer,width/2)),((outer,-width/2),(outer,width/2))]
    A=2*c.bf*c.tf+c.tw*hw
    I=(c.bf*c.d**3-(c.bf-c.tw)*hw**3)/12
    return dict(web_clear_mm=clear,web_height_mm=hw,dm_mm=c.d+c.flange_t,
        top_y_mm=(c.d+c.flange_t)/2,bottom_y_mm=-(c.d+c.flange_t)/2,
        flange_cover_length_mm=c.gap+2*c.flange_overlap,web_cover_length_mm=c.gap+2*c.web_overlap,
        flange_weld_length_mm=c.flange_overlap-c.flange_setback,web_weld_length_mm=c.web_overlap-c.web_setback,
        A_member_mm2=A,I_member_mm4=I,groups=groups,axes='x longitudinal; y vertical; z transversal às mesas')


def all_cases(c):
    result=[]
    for case in c.cases:
        q=asdict(case);q['kind']='actual';result.append(q)
        resultant=math.hypot(case.N,case.V)
        if c.minimum_force and 0<resultant<45000.:
            f=45000./resultant
            q=dict(q,id=case.id+':minimum',N=case.N*f,V=case.V*f,kind='minimum_45kN',source_case=case.id)
            result.append(q)
    return result


def _check(out,case,component,mode,demand,capacity,unit='N',reference='',**detail):
    if not finite(demand) or demand<0 or not finite(capacity) or capacity<=0:
        raise ArithmeticError(component+': ação/resistência inválida.')
    ratio=demand/capacity
    if not finite(ratio):raise ArithmeticError('Índice não finito.')
    out['checks'].append(dict(id=case['id']+':'+component+':'+mode,case_id=case['id'],component=component,
        mode=mode,demand=demand,capacity=capacity,unit=unit,utilization=ratio,
        status='NOT_APPLICABLE' if demand==0 else 'PASS' if ratio<=1 else 'FAIL',
        reference=reference or NBR,details=detail))


def _tension(out,case,component,force,width,t,fy,fu,Ct=1.):
    A=width*t
    _check(out,case,component,'gross_tension',max(force,0),fy*A/GA1,reference=NBR+' 6.5.3',Ag_mm2=A)
    _check(out,case,component,'effective_tension',max(force,0),fu*A*Ct/GA2,reference=NBR+' 6.5.3 / 5.2.5',Ag_mm2=A,An_mm2=A,Ae_mm2=A*Ct,Ct=Ct,no_bolted_085_cap=True)


def _shear(out,case,component,V,width,t,fy,fu):
    A=width*t
    _check(out,case,component,'shear_yield',abs(V),.6*fy*A/GA1,reference=NBR+' 6.5.5',Agv_mm2=A)
    _check(out,case,component,'shear_rupture',abs(V),.6*fu*A/GA2,reference=NBR+' 6.5.5',Anv_mm2=A)


def evaluate(c):
    out=dict(status='INVALID_INPUT',local_pass=False,checks=[],issues=[],geometry={},cases=[],force_paths=[],
             restraints={},scope=dict(model=MODEL,strengths=NBR,global_member_design='EXTERNAL_PREREQUISITE_NOT_CALCULATED'),
             qualification='ISOLATED_CANDIDATE_NOT_REGISTERED')
    errors=input_errors(c)
    if errors:out['issues']=errors;return out
    try:
        return _evaluate(c,out)
    except (ValueError,OverflowError,ZeroDivisionError,ArithmeticError) as exc:
        out.update(status='INVALID_INPUT',local_pass=False)
        out['checks']=[]
        out['issues'].append(str(exc))
        return out


def _evaluate(c,out):
    excluded = c.profile_kind!='rolled_equal_coaxial_W' or not c.static or not c.normal_combination or any((c.fatigue,c.seismic,c.fire,c.erection,c.holes_or_notches,c.fillers_or_offsets,c.end_bearing))
    if excluded or any(any(getattr(q,k)!=0 for k in ('torsion','weak_M','transverse_V')) for q in c.cases):
        out.update(status='OUTSIDE_QUALIFIED_SCOPE');out['issues'].append('Somente dois W/I laminados iguais, coaxiais, íntegros; N/M forte/V estáticos; sem ações/exclusões adicionais.');return out
    if not all(0<fy<fu and fy<=1000 and fu<=1500 for fy,fu in ((c.member_fy,c.member_fu),(c.cover_fy,c.cover_fu))) or not 0<c.electrode_fw<=1500:
        raise ValueError('Materiais: 0<fy<fu; dados em MPa dentro do domínio de aço estrutural.')
    g=geometry(c);out['geometry']=g;cases=all_cases(c);out['cases']=cases
    details=[]
    if c.flange_width+2*c.flange_leg>c.bf:details.append('Tala de mesa e pés das soldas devem caber na mesa receptora.')
    if c.web_height+2*c.web_leg>g['web_clear_mm']:details.append('Talas/soldas de alma colidem com filetes de raiz.')
    for name,t,receiver,leg,overlap,setback,width in [('flange',c.flange_t,c.tf,c.flange_leg,c.flange_overlap,c.flange_setback,c.flange_width),('web',c.web_t,c.tw,c.web_leg,c.web_overlap,c.web_setback,c.web_height)]:
        thin=min(t,receiver);minleg=3. if thin<=6.3 else 5. if thin<=12.5 else 6. if thin<=19 else 8.
        maxleg=t if t<6.3 else t-1.5
        if leg<minleg or leg>maxleg:details.append(name+': perna fora dos limites NBR6.2.6.2.1–2 (sem borda reforçada).')
        if setback<leg:details.append(name+': interrupção junto à borda deve ser >=perna.')
        L=overlap-setback
        if min(L,width)<max(4*leg,40):details.append(name+': cada trecho efetivo >=max(4s,40 mm).')
        if overlap<max(5*thin,25):details.append(name+': cobrimento >=max(5t_menor,25 mm).')
        if max(L,width)>100*leg:details.append(name+': domínio inicial L de cada trecho <=100s; sem redução de solda longa.')
    if not c.minimum_force:details.append('Mínimo de 45 kN não pode ser desativado nesta rota.')
    if details:out.update(status='DETAIL_FAIL',issues=details);return out
    compressed={side:any(q['N']/2+(1 if side=='top' else -1)*q['M']/g['dm_mm']<0 for q in cases) for side in ('top','bottom')}
    for side,needed in compressed.items():
        record=getattr(c,side+'_restraint')
        if needed:
            if min(record.Le_normal_mm,record.Le_in_plane_mm)<=0 or not record.reference.strip() or not record.support_description.strip() or not record.restraint_and_receiver_verified or record.detail_signature!=restraint_signature(c,record,side):
                out['issues'].append(side+': Le normal y/flexão z e Le no plano z/flexão y, fonte, vínculos e confirmação vinculada à revisão atual são obrigatórios.')
            else:
                out['restraints'][side]=dict(record=asdict(record),capacity=compression_rectangle(c.flange_width,c.flange_t,record.Le_normal_mm,record.Le_in_plane_mm,c.cover_fy))
        else:out['restraints'][side]=dict(status='NOT_APPLICABLE_NO_COMPRESSION')
    if out['issues']:out['status']='INVALID_RESTRAINT_INPUT';return out
    for side,data in out['restraints'].items():
        cap=data.get('capacity')
        if cap and max(cap['slenderness_normal'],cap['slenderness_in_plane'])>200:
            out.update(status='OUTSIDE_QUALIFIED_SCOPE',issues=[side+': Le/r > 200. Domínio inicial conforme recomendação NBR5.3.7.1; limite alternativo do projetista (5.3.7.2) não incluído nesta rota.'])
            return out
    # Receiving member local classification only; remote column/FLT is external.
    if any(compressed.values()):
        limits=dict(flange=(c.bf-c.tw)/(2*c.tf)/(.56*math.sqrt(E/c.member_fy)),web=g['web_height_mm']/c.tw/(1.49*math.sqrt(E/c.member_fy)))
        if max(limits.values())>1:
            out.update(status='OUTSIDE_QUALIFIED_SCOPE',issues=['Receptor comprimido localmente esbelto; rota inicial exige elementos não esbeltos da Tabela 4.']);return out
        out['receiver_local_classification']=limits
    for case in cases:
        N,M,V=case['N'],case['M'],case['V'];ft=N/2+M/g['dm_mm'];fb=N/2-M/g['dm_mm']
        out['force_paths'].append(dict(case_id=case['id'],top_N=ft,bottom_N=fb,each_web_V=V/2,web_N=0.,web_M=0.,
            axial_residual_N=ft+fb-N,moment_residual_Nmm=g['top_y_mm']*ft+g['bottom_y_mm']*fb-M,
            source='AISC15 Part12 p12-11; Fig12-7(b); web eccentricity waived, not general weld-group rule'))
        for side,F in [('top',ft),('bottom',fb)]:
            comp=side+'_flange_cover'
            _tension(out,case,comp,F,c.flange_width,c.flange_t,c.cover_fy,c.cover_fu)
            if compressed[side]:
                cap=out['restraints'][side]['capacity']
                _check(out,case,comp,'compression',max(-F,0),cap['capacity_N'],reference=NBR+' 6.5.4 / 5.3',**cap)
            for member in ('left','right'):
                _transfer(out,c,g,case,comp+'_'+member,F,0.,'flange',member,c.flange_t,c.tf)
                rec=side+'_receiver_'+member
                _tension(out,case,rec,F,c.flange_width,c.tf,c.member_fy,c.member_fu)
                _check(out,case,rec,'compression_local_yield',max(-F,0),c.member_fy*c.flange_width*c.tf/GA1,reference=NBR+' 6.5.4; flange local não esbelta; estabilidade global externa',width_mm=c.flange_width)
        for face in ('front','back'):
            _shear(out,case,face+'_web_cover',V/2,c.web_height,c.web_t,c.cover_fy,c.cover_fu)
            for member in ('left','right'):
                _transfer(out,c,g,case,face+'_web_cover_'+member,0.,V/2,'web',member,c.web_t,c.tw/2)
        for member in ('left','right'):
            _shear(out,case,'receiver_web_'+member,V,c.web_height,c.tw,c.member_fy,c.member_fu)
            _receiver_envelope(out,c,g,case,member)
    missing=[x for x in DECLARATIONS if not getattr(c,x)]
    if not c.procedure_id.strip():missing.append('procedure_id')
    failed=any(x['status']=='FAIL' for x in out['checks'])
    out['issues']+=['Confirmação técnica pendente: '+x for x in missing]
    out['local_pass']=not failed and not missing
    out['status']='LOCAL_CHECKS_FAIL' if failed else 'NOT_VERIFIED' if missing else 'LOCAL_CHECKS_PASS'
    out['summary']=dict(max_utilization=max(x['utilization'] for x in out['checks']),check_count=len(out['checks']),
        controlling=max(out['checks'],key=lambda x:x['utilization'])['id'],complete_local_schedule=True)
    return out


def _transfer(out,c,g,case,component,Fx,Fy,kind,member,t,receiver_allocated_t):
    """Real U segments. Paired web faces get tw/2, never tw each."""
    leg=c.flange_leg if kind=='flange' else c.web_leg
    group=elastic_line_group(g['groups'][kind+'_'+member],Fx,Fy,0.)
    q=group['qmax_N_mm'];L=group['L_mm'];demand=math.hypot(Fx,Fy)
    _check(out,case,component,'weld_metal',q,.6*c.electrode_fw*leg/math.sqrt(2)/GW2,'N/mm',NBR+' 6.2.5 Tabela9',group=group)
    for label,thickness,fy,fu in [('cover',t,c.cover_fy,c.cover_fu),('receiver',receiver_allocated_t,c.member_fy,c.member_fu)]:
        _check(out,case,component,label+'_weld_adjacent_rupture',q,.6*fu*thickness/GA2,'N/mm',NBR+' 6.5; AISC15 Part9 p9-5',
               thickness_allocated_mm=thickness,common_web_plane_not_doubled=kind=='web',line_length_mm=L)
        _check(out,case,component,label+'_weld_adjacent_yield',q,.6*fy*thickness/GA1,'N/mm',NBR+' 6.5; conservative all-direction shear screen',thickness_allocated_mm=thickness)
    # Physical fracture paths are defined explicitly below, never bolt formulas.
    _fracture_paths(out,c,g,case,component,Fx,Fy,kind,t,receiver_allocated_t)


def _fracture_paths(out,c,g,case,component,Fx,Fy,kind,t,receiver_allocated_t):
    """Physical receiver paths from actual free boundaries, independent review.

    Unperforated free-edge U-welded covers have no analogous receiver block:
    their complete transverse section and every weld-adjacent transfer line
    are checked separately. There is no phantom floating vertical U block.
    Coordinates here use local x=0 at member butt, u across flange / web.
    """
    if kind=='flange':
        b=c.flange_width;L=c.flange_overlap
        paths=[dict(name='receiver_axial_U',Lv=2*L,Lt=b,D=abs(Fx),
            points=[[0.,-b/2],[L,-b/2],[L,b/2],[0.,b/2]],
            boundary='Fechamento livre na borda de topo x=0; duas pernas longitudinais e seção transversal externa.'),
            dict(name='receiver_half_flange_L',Lv=L,Lt=c.bf/2,D=abs(Fx)/2,
            points=[[0.,0.],[L,0.],[L,c.bf/2]],
            boundary='Metade simétrica: bordas livres de topo x=0 e lateral u=bf/2; outra metade espelhada.')]
    else:
        out.setdefault('applicability',{})['web_block']=dict(status='NOT_APPLICABLE',
            reason='Alma íntegra sem furos/recortes: única borda livre local x=0 perpendicular a V. As linhas y=+/-h_tala/2 não são bordas livres; não há bloco aberto U/L no contorno local.',
            checked_instead=['Cisalhamento bruto/líquido da tala','Cisalhamento comum h_tala*tw do receptor',
                             'Transferência de cada linha soldada com tw/2 por face','Envelope elástico local da seção íntegra N/M/V'],
            intact_member_required=True)
        return
    for path in paths:
        thickness=receiver_allocated_t;Lv=path['Lv'];Lt=path['Lt']
        R=(min(.6*c.member_fu*Lv*thickness,.6*c.member_fy*Lv*thickness)+.5*c.member_fu*Lt*thickness)/GA2
        _check(out,case,component,path['name'],path['D'],R,reference=NBR+' 6.5.6',
               Agv_mm2=Lv*thickness,Anv_mm2=Lv*thickness,Ant_mm2=Lt*thickness,Cts=.5,
               path_shear_length_mm=Lv,path_tension_length_mm=Lt,physical_path=path['name'],
               path_coordinates_local_mm=path['points'],free_boundary=path['boundary'],
               thickness_allocated_mm=thickness,common_web_plane_not_doubled=kind=='web',
               cover_block_omission='Chapa sem furos com soldas nas bordas livres; seção transversal e linhas adjacentes verificadas.')


def _receiver_envelope(out,c,g,case,member):
    """Local intact member bound, not full global beam/column verification."""
    extent=c.gap/2+max(c.flange_overlap,c.web_overlap)
    sign=-1 if member=='left' else 1
    stations=[sign*c.gap/2,sign*extent]
    moments=[case['M']-case['V']*x for x in stations]
    mb=max(abs(x) for x in moments);A=g['A_member_mm2'];I=g['I_member_mm4']
    sigma=abs(case['N'])/A+mb*c.d/(2*I)
    tau=1.5*abs(case['V'])/(g['web_height_mm']*c.tw)
    stress=math.hypot(sigma,math.sqrt(3)*tau)
    _check(out,case,'receiver_'+member,'local_elastic_NMV_envelope',stress,c.member_fy/GA1,'MPa',
        NBR+' 6.1.1.3 / 6.5; additional conservative elastic stress envelope',stations_mm=stations,
        signed_M_Nmm=moments,normal_stress_MPa=sigma,shear_stress_MPa=tau,
        envelope_not_new_force_distribution=True,global_stability_not_checked=True)
    # Original member is attached for axial transfer only through flanges.
    half_web=c.tw*g['web_height_mm']/2
    Af=c.bf*c.tf;At=Af+half_web
    e=(Af*c.tf/2+half_web*(c.tf+g['web_height_mm']/4))/At
    Ct=max(Af/At,1-e/g['flange_weld_length_mm'])
    _check(out,case,'receiver_'+member,'whole_member_partial_axial_rupture',max(case['N'],0),Ct*A*c.member_fu/GA2,
        reference=NBR+' 5.2.5(c); two symmetric fictitious T sections',Ct=Ct,e_mm=e,lc_mm=g['flange_weld_length_mm'],
        web_shear_weld_not_axial_attachment=True,Ae_mm2=Ct*A)
