"""Deterministic physical full-joint drawings, separate from value-free signs.

All dimensions are read from the current native connection. Drawings never
trust a caller's result/status, and a nonzero work-point offset is drawn rather
than silently snapping the brace line back to O.
"""
from io import BytesIO
from math import cos, sin, radians
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon, Rectangle, Arc, Circle
from .corner_gusset_presentation import (STATUS, input_fingerprint, validated_result,
                                         approved, number, finite, result_label, is_single, is_bolted)

INK = '#23384d'
MUTED = '#617487'
WELD = '#bd403b'
PLATE = '#dce5ef'
ANGLE = '#5b9fab'
CONT = '#dab875'


def _line(ax, a, b, gid, **kwargs):
    line, = ax.plot([a[0], b[0]], [a[1], b[1]], **kwargs)
    line.set_gid(gid)
    return line


def _poly(ax, pts, gid, **kwargs):
    p = Polygon(pts, closed=True, **kwargs)
    p.set_gid(gid); ax.add_patch(p)
    return p


def _rect(ax, x, y, w, h, gid, **kwargs):
    p = Rectangle((x, y), w, h, **kwargs)
    p.set_gid(gid); ax.add_patch(p)
    return p


def _arrow(ax, a, b, text=None, color=INK, gid=None):
    p = ax.annotate('', xy=b, xytext=a, arrowprops=dict(arrowstyle='-|>', lw=1.4, color=color))
    if gid:
        p.set_gid(gid)
        if p.arrow_patch is not None:p.arrow_patch.set_gid(gid+'-arrow-path')
    if text: ax.text(*b, text, fontsize=8, color=color, va='bottom')
    return p


def _axes(ax, title):
    ax.set_aspect('equal'); ax.axis('off'); ax.set_title(title, loc='left', fontsize=11, weight='bold', color=INK, pad=10)


def _geom(c):
    # Geometry remains drawable even when resistance has an explicit unsupported
    # component. Only non-finite/invalid dimensions prevent the physical view.
    from types import SimpleNamespace
    from .corner_gusset import geometry
    g=geometry(c)
    return (SimpleNamespace(**g['beam']), SimpleNamespace(**g['column']), g['angle'],
            g['ec'], g['eb'], g['polygon'], g['beam_seam'], g['column_seam'])


def _physical(c, r):
    b, col, a, ec, eb, polygon, bs, cs = _geom(c)
    single=is_single(c);bolted=is_bolted(c);faces=((1,'positive'),) if single and c.single_angle_face=='positive' else ((-1,'negative'),) if single else ((1,'positive'),(-1,'negative'))
    fig = plt.figure(figsize=(15.8, 10.2), facecolor='white')
    fig.text(.035, .965, ('Canto viga–pilar · '+('1L' if single else '2L-T')+' '+('parafusada' if bolted else 'soldada')+' · eixos fortes'), fontsize=18, weight='bold', color=INK)
    fig.text(.035, .937, str(c.project), fontsize=10, color=MUTED)
    state = result_label(r)
    fig.text(.035, .912, state + ' · caso ' + str(c.case_id), fontsize=10, color='#326647' if approved(r) else '#a33333', weight='bold')
    ax = fig.add_axes([.035, .22, .565, .655]); _axes(ax, 'A · Vista no plano das almas (x, y) · dimensões em mm')
    xmin = min(-col.d/2.-120, c.upper_column_cut_x-180, c.lower_column_cut_x-180)
    xmax = max(c.beam_cut_x+180, ec+c.plate_width+120)
    ymin = min(c.lower_column_cut_y-110, -eb-120)
    ymax = max(c.upper_column_cut_y+130, eb+c.plate_height+180)
    # Actual member outlines, interrupted at the named free-body cuts.
    cymin, cymax = c.lower_column_cut_y, c.upper_column_cut_y
    _rect(ax,-col.d/2.,cymin,col.d,cymax-cymin,'column-web-plane',facecolor='#f1f4f7',edgecolor=INK,lw=1)
    for x, name in ((-col.d/2., 'back'), (col.d/2.-col.tf, 'loaded')):
        _rect(ax,x,cymin,col.tf,cymax-cymin,'column-'+name+'-flange',facecolor='#c9d3df',edgecolor=INK,lw=.8)
    _rect(ax,ec,-eb,c.beam_cut_x-ec,b.d,'beam-web-plane',facecolor='#f1f4f7',edgecolor=INK,lw=1)
    for y, name in ((-eb,'bottom'), (eb-b.tf,'top')):
        _rect(ax,ec,y,c.beam_cut_x-ec,b.tf,'beam-'+name+'-flange',facecolor='#c9d3df',edgecolor=INK,lw=.8)
    _poly(ax,polygon,'gusset-clipped-polygon',facecolor=PLATE,edgecolor=INK,lw=1.4,zorder=3)
    _line(ax,*bs,'beam-root-double-fillet',color=WELD,lw=3,zorder=5)
    _line(ax,*cs,'column-root-double-fillet',color=WELD,lw=3,zorder=5)
    if bolted:
        ax.annotate('Raiz viga · 2 filetes '+number(c.root_weld_leg)+'\nL='+number(bs[1][0]-bs[0][0]),xy=((bs[0][0]+bs[1][0])/2,eb),xytext=(ec+c.plate_width+100,eb+90),fontsize=7.5,color=WELD,ha='left',bbox=dict(facecolor='white',edgecolor='none',pad=1),arrowprops=dict(arrowstyle='-',color=WELD,lw=.7))
    else:
        ax.text((bs[0][0]+bs[1][0])/2,eb-45,'Raiz viga · 2 filetes '+number(c.root_weld_leg)+' · L='+number(bs[1][0]-bs[0][0]),ha='center',fontsize=7.5,color=WELD)
    ax.annotate('Raiz pilar · 2 filetes '+number(c.root_weld_leg)+'\nL='+number(cs[1][1]-cs[0][1]),xy=(ec,(cs[0][1]+cs[1][1])/2),xytext=(-col.d/2.-35,500),fontsize=7.5,color=WELD,ha='right',arrowprops=dict(arrowstyle='-',color=WELD,lw=.7))
    ax.annotate('Recorte '+number(c.corner_clip)+' × '+number(c.corner_clip),xy=(ec+c.corner_clip/2,eb+c.corner_clip/2),xytext=(-col.d/2-35,eb+140) if bolted else (ec+120,eb+125),ha='right' if bolted else 'left',fontsize=7.5,color=INK,bbox=dict(facecolor='white',edgecolor='none',pad=1) if bolted else None,arrowprops=dict(arrowstyle='-',lw=.7))
    th = radians(c.phi_deg); u = (cos(th),sin(th)); v=(-sin(th),cos(th))
    # Positive offset is the right-hand normal: (sin phi,-cos phi).
    origin=(c.workpoint_offset*sin(th),-c.workpoint_offset*cos(th))
    def xy(U,V): return (origin[0]+U*u[0]+V*v[0], origin[1]+U*u[1]+V*v[1])
    start,end=(c.bolt_start,c.bolt_start+(c.bolt_count-1)*c.bolt_pitch) if bolted else (c.brace_weld_start,c.brace_weld_start+c.brace_weld_length)
    heel,toe=(-c.bolt_gauge,a['leg']-c.bolt_gauge) if bolted else (-a['centroid'],a['leg']-a['centroid'])
    extension=c.bolt_angle_end if bolted else c.brace_free_end_extension
    _poly(ax,[xy(start-extension,heel),xy(end+125,heel),xy(end+125,toe),xy(start-extension,toe)],('brace-single-projection' if single else 'brace-pair-projection'),facecolor=ANGLE,alpha=.46,edgecolor=ANGLE,lw=1,zorder=4)
    # Four physical welds have two coincident projections. Individual GIDs and
    # the T section make the two faces explicit; no fake transverse separation.
    if bolted:
        from .bolted_angle_gusset import HOLES
        for j in range(c.bolt_count):
            center=xy(start+j*c.bolt_pitch,0)
            hole=Circle(center,HOLES[c.bolt_diameter]/2,facecolor='white',edgecolor=INK,lw=.8,zorder=7);hole.set_gid('corner-hole-'+str(j+1));ax.add_patch(hole)
            bolt=Circle(center,c.bolt_diameter/2,facecolor=INK,edgecolor=INK,lw=.5,zorder=8);bolt.set_gid('corner-bolt-'+str(j+1));ax.add_patch(bolt)
        ax.text(*xy(start+20,toe+35),str(c.bolt_count)+' parafusos db'+number(c.bolt_diameter)+'; p='+number(c.bolt_pitch),rotation=c.phi_deg,fontsize=7.5,color=INK)
    else:
        for _,face in faces:
            for side,V in (('heel',heel),('toe',toe)):
                _line(ax,xy(start,V),xy(end,V),'brace-'+face+'-'+side+'-fillet',color=WELD,lw=2.2,zorder=6,ls='-' if face=='positive' else (0,(4,3)))
    _line(ax,xy(-75,0),xy(end+205,0),'actual-brace-force-line',color=ANGLE,lw=.8,ls='--',zorder=5)
    direction=1 if c.P>=0 else -1
    if c.P<0:
        _arrow(ax,xy(end+205,0),xy(end+70,0),None,ANGLE,'brace-actual-force')
        ax.text(*xy(end+215,15),'N='+number(c.P,1000)+' kN · compressão',fontsize=8,color=ANGLE,va='bottom',ha='left')
    elif c.P:_arrow(ax,xy(end+30,0),xy(end+30+direction*135,0),'N='+number(c.P,1000)+' kN',ANGLE,'brace-actual-force')
    cp_compression=r.get('compression') or {}
    if cp_compression.get('selected_ends'):
        _line(ax,*cp_compression['selected_ends'],'compression-centered-whitmore-stripe',color='#a33333',lw=1.5,ls='--',zorder=8)
    zero_path=cp_compression.get('inward_zero_cap') or {}
    if bolted and zero_path.get('path_xy'):
        for idx,(aa,bb) in enumerate(zip(zero_path['path_xy'],zero_path['path_xy'][1:])):
            _line(ax,aa,bb,'compression-inward-U-zero-cap-'+str(idx),color='#ad6a00',lw=1.4,ls=':',zorder=9)
    if not bolted:ax.text(*xy(start+35,toe+25),('2 × ' if single else '4 × ')+number(c.brace_weld_leg)+'; L='+number(c.brace_weld_length),rotation=c.phi_deg,fontsize=7.5,color=WELD)
    ax.plot(0,0,'o',ms=3,color=INK); ax.text(-95,-50,'O=(0; 0)',fontsize=7.5)
    ax.plot(ec,0,'o',ms=3,color='#783f81',zorder=9)
    ax.text(ec+30,35,'J=('+number(ec)+'; 0)',fontsize=7.5,color='#783f81')
    ax.text(ec+20,-eb-55,'Viga '+c.beam_profile,fontsize=8,color=INK)
    ax.text(-col.d/2.-20,-470,'Pilar '+c.column_profile,rotation=90,fontsize=8,color=INK,ha='right')
    h0=b.d-b.tf
    for y,name in ((h0/2,'upper'),(-h0/2,'lower')):
        _rect(ax,-col.d/2.+col.tf,y-c.continuity_t/2,col.d-2*col.tf,c.continuity_t,'continuity-'+name+'-pair-projection',facecolor=CONT,edgecolor=INK,lw=.8,zorder=7)
        _line(ax,(ec,y-b.tf/2),(ec,y+b.tf/2),'beam-'+name+'-CJP',color='#783f81',lw=4,zorder=8)
    _line(ax,(ec,-c.beam_web_weld_length/2),(ec,c.beam_web_weld_length/2),'beam-web-two-fillets',color=WELD,lw=2.8,zorder=7)
    for sign in (-1,1):
        # End access holes: actual nominal radius, in the remaining web end.
        hole=Arc((ec,sign*(eb-b.tf)),2*c.beam_access_radius,2*c.beam_access_radius,theta1=270 if sign>0 else 0,theta2=360 if sign>0 else 90,color=INK,lw=.9)
        hole.set_gid('beam-access-'+str(sign));ax.add_patch(hole)
    ax.annotate('2 mesas CJP; alma 2 filetes '+number(c.beam_web_weld_leg)+'\nPares de continuidade nos níveis ±'+number(h0/2),xy=(ec,0),xytext=(ec+160,-410),fontsize=7.5,color=INK,arrowprops=dict(arrowstyle='-',lw=.7))
    for prefix,label,point,vertical in [('beam_cut','D · corte viga',(c.beam_cut_x,c.beam_cut_y),True),('upper_column_cut','U · corte superior',(c.upper_column_cut_x,c.upper_column_cut_y),False),('lower_column_cut','L · corte inferior derivado',(c.lower_column_cut_x,c.lower_column_cut_y),False)]:
        x,y=point
        _line(ax,(x,y-190) if vertical else (x-col.d/2.-25,y),(x,y+190) if vertical else (x+col.d/2.+25,y),prefix+'-named-cut',color='#74668c',lw=1.2,ls='--',zorder=8)
        ax.text(x+25 if vertical else x+220,y+200 if vertical else y+75,label,fontsize=8,color='#635179',ha='left')
        action=(r.get('forces') or {}).get(prefix)
        if action:
            fx,fy,m=(action.get(k,0.) for k in ('Fx','Fy','M'))
            # Separate actual signed action arrows. Their fixed drawn lengths
            # indicate direction; printed values provide actual magnitudes.
            if fx:_arrow(ax,(x,y),(x+(95 if fx>0 else -95),y),color='#176c89',gid=prefix+'-actual-Fx')
            if fy:_arrow(ax,(x,y),(x,y+(95 if fy>0 else -95)),color='#176c89',gid=prefix+'-actual-Fy')
            if m:
                radius=62; angles=(15,300) if m>0 else (300,15)
                import numpy as np
                tt=np.linspace(radians(angles[0]),radians(angles[1]),40)
                xs=[x+radius*cos(t) for t in tt];ys=[y+radius*sin(t) for t in tt]
                line,=ax.plot(xs,ys,color='#176c89',lw=.8);line.set_gid(prefix+'-actual-M')
                _arrow(ax,(xs[-3],ys[-3]),(xs[-1],ys[-1]),color='#176c89')
            # Values are positioned away from the member outline and arrows.
            tx,ty=(x-65,y-520) if vertical else (x+220,y-10)
            if prefix=='upper_column_cut' and y-(eb+c.plate_height)<240:
                tx=max(tx,ec+c.plate_width+60)
            ax.text(tx,ty,'Fx='+number(fx,1000)+' kN\nFy='+number(fy,1000)+' kN\nM='+number(m,1e6)+' kN m',fontsize=7,color='#176c89',va='top',ha='center' if vertical else 'left',bbox=dict(facecolor='white',edgecolor='none',pad=2),zorder=10)
    if c.workpoint_offset:
        ax.annotate('Linha excêntrica real\ne='+number(c.workpoint_offset)+' mm\nRedistribuição não verificada',xy=xy(300,0),xytext=(ec+c.plate_width+130,eb+c.plate_height*.5),fontsize=8,color='#a33333',va='center',bbox=dict(facecolor='white',edgecolor='none',pad=2),arrowprops=dict(arrowstyle='->',color='#a33333'))
    _arrow(ax,(xmin+40,ymin+70),(xmin+150,ymin+70),'+x',MUTED)
    _arrow(ax,(xmin+40,ymin+70),(xmin+40,ymin+180),'+y',MUTED)
    ax.set_xlim(xmin,xmax);ax.set_ylim(ymin,ymax)

    # True T cross section: one angle at each face, same-direction connected
    # legs and outward free legs. Sharp nominal legs disclose unknown radii.
    ax2=fig.add_axes([.64,.59,.325,.275]);_axes(ax2,('B · Corte '+('1L' if single else 'T')+': '+('parafuso em corte '+('simples' if single else 'duplo') if bolted else 'uma face, dois filetes' if single else 'duas L, uma chapa, quatro filetes')))
    tg,leg,t=c.plate_t,a['leg'],a['t']
    _rect(ax2,heel-20,-tg/2,toe-heel+40,tg,'T-central-gusset',facecolor=PLATE,edgecolor=INK,lw=1)
    for sign,face in faces:
        z=sign*tg/2
        points=[(heel,z),(toe,z),(toe,z+sign*t),(heel+t,z+sign*t),(heel+t,z+sign*leg),(heel,z+sign*leg)]
        _poly(ax2,points,'T-'+face+'-L',facecolor=ANGLE,edgecolor=INK,lw=1)
        for side,V,dirn in (() if bolted else (('heel',heel,-1),('toe',toe,1))):
            s=c.brace_weld_leg
            _poly(ax2,[(V,z),(V+dirn*s,z),(V,z+sign*s)],'T-'+face+'-'+side+'-fillet',facecolor=WELD,edgecolor=WELD,lw=.6)
        ax2.text(toe+25 if bolted else heel+leg*.6,z+sign*(t+(38 if single else 14)),('N integral · face ' if single else 'N/2 · face ')+('+' if sign>0 else '−')+'z',fontsize=8,ha='left' if bolted else 'center',va='center')
    if bolted:
        dh=HOLES[c.bolt_diameter];zs=[sign*(tg/2+t) for sign,_ in faces];zlo=min([-tg/2]+zs);zhi=max([tg/2]+zs)
        _rect(ax2,-dh/2,zlo,dh,zhi-zlo,'T-physical-hole',facecolor='white',edgecolor='none',zorder=7)
        _rect(ax2,-c.bolt_diameter/2,zlo-6,c.bolt_diameter,zhi-zlo+12,'T-shared-through-bolt' if not single else 'T-single-shear-bolt',facecolor=INK,edgecolor=INK,lw=.7,zorder=8)
        if c.bolt_friction_type and c.bolt_hardened_washer_count>0 and c.bolt_washer_stack>0:
            wt=c.bolt_washer_stack/c.bolt_hardened_washer_count;wd=c.bolt_washer_diameter
            if c.bolt_washer_location in ('rotating','both'):
                _rect(ax2,-wd/2,zhi,wd,wt,'T-hardened-washer-rotating',facecolor=CONT,edgecolor=INK,lw=.6,zorder=9)
            if c.bolt_washer_location=='both':
                _rect(ax2,-wd/2,zlo-wt,wd,wt,'T-hardened-washer-nonrotating',facecolor=CONT,edgecolor=INK,lw=.6,zorder=9)
        for sign,face in faces:
            _line(ax2,(-c.bolt_diameter,sign*tg/2),(c.bolt_diameter,sign*tg/2),'T-shear-plane-'+face,color='#bd403b',lw=1.2,ls='--',zorder=9)
        ax2.annotate('db'+number(c.bolt_diameter)+'; '+str(len(faces))+' plano(s)',xy=(0,0),xytext=(toe+25,-faces[0][0]*25 if single else 0),fontsize=7,color=INK,va='center',arrowprops=dict(arrowstyle='-',color=INK,lw=.5))
    if single:
        z=faces[0][0]*(tg/2+a['centroid'])
        ax2.plot(a['centroid']-c.bolt_gauge if bolted else 0,z,'o',color=INK,ms=3)
        if bolted:ax2.annotate('CG z='+number(z)+' mm',xy=(a['centroid']-c.bolt_gauge,z),xytext=(toe+25,z),fontsize=7,color=INK,va='center',arrowprops=dict(arrowstyle='-',color=INK,lw=.5))
        else:ax2.text(6,z,'CG z='+number(z)+' mm',fontsize=7,color=INK)
        _line(ax2,(heel-18,0),(toe+18,0),'nominal-midplane-axis-z0',color=MUTED,lw=.7,ls='--')
        if bolted:ax2.annotate('Eixo terminal nominal z=0',xy=(heel-10,0),xytext=(toe+25,-faces[0][0]*65),fontsize=7,color=MUTED,va='center',arrowprops=dict(arrowstyle='-',color=MUTED,lw=.5))
        else:ax2.text(heel-18,10 if faces[0][0]<0 else -17,'Eixo terminal nominal z=0',fontsize=7,color=MUTED)
    if bolted and not single:
        _line(ax2,(heel-18,0),(toe+18,0),'nominal-midplane-axis-z0',color=MUTED,lw=.7,ls='--')
        ax2.annotate('Eixo terminal nominal z=0',xy=(heel-10,0),xytext=(toe+25,leg+12),fontsize=7,color=MUTED,arrowprops=dict(arrowstyle='-',color=MUTED,lw=.5))
        for sign,face in faces:
            zz=sign*(tg/2+a['centroid']);vv=a['centroid']-c.bolt_gauge
            ax2.plot(vv,zz,'o',color=INK,ms=3)
            ax2.annotate('CG v='+number(vv)+'; z='+number(zz),xy=(vv,zz),xytext=(toe+25,sign*(tg/2+a['centroid']+25)),fontsize=7,color=INK,va='center',arrowprops=dict(arrowstyle='-',color=INK,lw=.5))
    ax2.text(heel-20,-leg-30,'b='+number(leg)+'; tL='+number(t)+'; tg='+number(tg)+' mm',fontsize=8,color=INK)
    ax2.text(heel-20,-leg-45,'Raios não publicados: contorno nominal, sem crédito.',fontsize=7.5,color=MUTED)
    ax2.set_xlim(heel-30,toe+190) if bolted else ax2.set_xlim(heel-25,toe+35)
    ax2.set_ylim(-leg-55,leg+30)

    ax3=fig.add_axes([.64,.225,.325,.25]);_axes(ax3,'C · Continuidade: 2 níveis, 4 chapas no total')
    xr=col.d/2-col.tf; zw=col.tw/2; w=c.continuity_width; clip=c.continuity_clip
    _rect(ax3,-xr-col.tf,-col.bf/2,col.tf,col.bf,'continuity-back-column-flange',facecolor='#c9d3df',edgecolor=INK,lw=.8)
    _rect(ax3,xr,-col.bf/2,col.tf,col.bf,'continuity-loaded-column-flange',facecolor='#c9d3df',edgecolor=INK,lw=.8)
    _rect(ax3,-xr,-zw,2*xr,2*zw,'continuity-common-column-web',facecolor='#c9d3df',edgecolor=INK,lw=.8)
    for sign,face in ((1,'positive'),(-1,'negative')):
        pts=[(-xr,sign*(zw+clip)),(-xr+clip,sign*zw),(xr-clip,sign*zw),(xr,sign*(zw+clip)),(xr,sign*(zw+w)),(-xr,sign*(zw+w))]
        _poly(ax3,pts,'continuity-'+face+'-clipped-plate',facecolor=CONT,edgecolor=INK,lw=1)
        wx=xr-clip-c.continuity_web_end_margin
        _line(ax3,(-wx,sign*zw),(wx,sign*zw),'continuity-'+face+'-web-double-fillet',color=WELD,lw=2.3)
        z0=zw+clip+c.continuity_flange_start_margin; z1=zw+w-c.continuity_flange_end_margin
        for side,xx in (('loaded',xr),('opposite',-xr)):
            _line(ax3,(xx,sign*z0),(xx,sign*z1),'continuity-'+face+'-'+side+'-double-fillet',color=WELD,lw=2.3)
    ax3.text(0,col.bf/2+22,'x entre mesas; z transversal · espessura '+number(c.continuity_t)+' mm',fontsize=7.8,ha='center')
    ax3.text(0,-col.bf/2-26,'Recortes '+number(clip)+'; largura por chapa '+number(w)+' mm',fontsize=7.8,ha='center')
    ax3.text(0,-col.bf/2-46,'2 filetes em cada borda soldada; sem contato ajustado.',fontsize=7.5,ha='center',color=MUTED)
    ax3.set_xlim(-xr-col.tf-30,xr+col.tf+30);ax3.set_ylim(-col.bf/2-58,col.bf/2+48)
    fig.text(.64,.205,'Mesas carregada/oposta: 2 × '+number(c.continuity_flange_weld_leg)+' mm; Lef='+number(w-clip-c.continuity_flange_start_margin-c.continuity_flange_end_margin)+' mm por chapa.',fontsize=7.8,color=WELD)
    fig.text(.64,.186,'Alma: 2 × '+number(c.continuity_web_weld_leg)+' mm; Lef='+number(2*(xr-clip-c.continuity_web_end_margin))+' mm por chapa.',fontsize=7.8,color=WELD)
    joint=(r.get('forces') or {}).get('joint') or {}
    if joint:
        fig.text(.64,.563,'J derivado · viga → pilar, no mesmo caso completo',fontsize=9,weight='bold',color='#783f81')
        fig.text(.64,.542,'Fx='+number(joint.get('Fx'),1000)+' kN; Fy='+number(joint.get('Fy'),1000)+' kN; M='+number(joint.get('M'),1e6)+' kN m',fontsize=8.5,color='#783f81')
    fig.text(.035,.163,'Caminho: cada L → chapa única → duas raízes. Momento direto da viga → binário das mesas CJP → pares de continuidade.',fontsize=9,color=INK)
    fig.text(.035,.139,'N='+number(c.P,1000)+' kN; φ='+number(c.phi_deg)+'°. As ações D/U são completas e concorrentes; L é derivado por equilíbrio.',fontsize=9,color=INK)
    fig.text(.035,.114,('Compressão local: faixa centrada bw='+number(cp_compression.get('width'))+' mm; K=1; Le='+number(cp_compression.get('Le'))+' mm; Le/r='+number(cp_compression.get('Le_over_r'))+'. Contenções declaradas: '+('geometria atual.' if cp_compression.get('declaration_matches_geometry') and all(cp_compression.get('restraints',{}).get(k)=='confirmed' for k in ('beam','column','brace')) else 'geometria vinculada; contenções PENDENTES.' if cp_compression.get('declaration_matches_geometry') else 'PENDENTES.') if cp_compression else 'Tração da diagonal não elimina compressão local. Mesas opostas da continuidade não recebem crédito extra de resistência.'),fontsize=8.5,color=MUTED)
    if not r.get('service_slip'):fig.text(.035,.09,'Desenho de verificação local. Preparação CJP, remoção de backing/runoff, WPS, acesso e inspeção devem constar do detalhamento executivo.',fontsize=8.5,color=MUTED)
    if single and not r.get('service_slip'):
        z=faces[0][0]*(tg/2+a['centroid'])
        fig.text(.035,.067,'1L: afastamento físico z='+number(z)+' mm; |N·z| bruto='+number(abs(c.P*z),1e6)+' kN m. Não há cancelamento por outra L.',fontsize=8.2,color=MUTED)
        fig.text(.035,.050,'NBR 6.1.8.2: excentricidade ordinária desprezada no eixo terminal nominal z=0. Equilíbrio apenas no plano idealizado, não exato 3D.',fontsize=8.2,color=MUTED)
    elif bolted and not r.get('service_slip'):
        fig.text(.035,.065,'Linha nominal no plano médio; afastamento físico no plano ec−g='+number(a['centroid']-c.bolt_gauge)+' mm não se cancela no par. NBR6.1.8.2.',fontsize=8.2,color=MUTED)
    elif cp_compression and not bolted:
        fig.text(.035,.065,'Nc,Rd='+number(cp_compression.get('resistance'),1000)+' kN. Receptor/continuidade/painel permanecem ativos; sem verificação global da diagonal ou do pórtico.',fontsize=8.2,color=MUTED)
    elif not r.get('service_slip'):
        fig.text(.035,.065,'Linha de força, recortes, soldas efetivas e cortes pertencem à entrada atual; nenhuma figura antiga é reutilizada.',fontsize=8.2,color=MUTED)
    if bolted:
        fig.text(.64,.165,str(c.bolt_count)+' parafusos físicos; '+str(len(faces))+' plano(s) cada; furo'+number(HOLES[c.bolt_diameter])+' mm.',fontsize=7.8,color=INK)
        fig.text(.64,.147,'Talão='+number(c.bolt_heel_extent)+'; ferramenta='+number(c.bolt_tool_radius)+'; folga='+number(c.bolt_fabrication_clearance)+' mm.',fontsize=7.8,color=MUTED)
    if r.get('service_slip'):
        slip=r['service_slip']; hw=slip.get('hardware') or {}
        fig.text(.035,.091,'Atrito Classe '+str(slip.get('surface_class'))+'; FTb='+number(slip.get('minimum_pretension'),1000)+' kN; '+str(c.bolt_hardened_washer_count)+' arruela(s) endurecida(s), '+{'rotating':'sob elemento girante','both':'sob ambos','none':'posição pendente'}[c.bolt_washer_location]+', t total='+number(c.bolt_washer_stack)+' mm; Ø='+number(c.bolt_washer_diameter)+' mm; pega='+number(hw.get('grip'))+' mm.',fontsize=8.2,color=MUTED)
        fig.text(.035,.073,('Deslizamento ELS: ' if slip.get('qualified') else 'Deslizamento ELS diagnóstico · detalhe NÃO VERIFICADO: ')+number(slip.get('per_bolt_demand'),1000)+' / '+number(slip.get('per_bolt_resistance'),1000)+' kN por parafuso; 0,70 apenas ELU normal; sem somar ao corte/contato ELU.',fontsize=8.2,color=MUTED)
        if cp_compression:
            fig.text(.035,.055,'U interno, cap de tração zero: Rd='+number(zero_path.get('zero_cap_resistance'),1000)+' kN. Contato: chapa −u / L +u; continuação livre L='+number(c.bolt_angle_continuation)+' mm.',fontsize=8.2,color=MUTED)
        elif single:
            z=faces[0][0]*(tg/2+a['centroid'])
            fig.text(.035,.055,'1L: z físico='+number(z)+' mm; |N·z| bruto='+number(abs(c.P*z),1e6)+' kN m. Não há cancelamento por outra L; detalhe por atrito 1L não qualificado.',fontsize=8.2,color=MUTED)
        else:fig.text(.035,.055,'Detalhe por atrito mantido no caso '+('tracionado' if c.P>0 else 'sem axial')+'; eixo nominal z=0, afastamento ec−g='+number(a['centroid']-c.bolt_gauge)+' mm não se cancela no par.',fontsize=8.2,color=MUTED)
        fig.text(.035,.037,('NBR6.1.8.2: eixo nominal z=0, sem equilíbrio exato 3D. Compressão 1L, estabilidade global e execução não qualificadas.' if single else 'Somente ligação e trechos ligados sob contenção física de translação/torção documentada; sem estabilidade global, costuras intermediárias ou certificação de execução.'),fontsize=8.2,color=MUTED)
    fig.text(.035,.019 if r.get('service_slip') else .027 if single else .039,'Entradas SHA-256: '+input_fingerprint(c),fontsize=7,color=MUTED)
    return fig


def _export(fig,fmt):
    out=BytesIO()
    if fmt not in ('svg','png'):raise ValueError('Formato deve ser svg ou png.')
    metadata={'Date':None,'Creator':'LRO corner gusset'} if fmt=='svg' else {'Software':'LRO corner gusset'}
    with matplotlib.rc_context({'svg.hashsalt':'lro-corner-gusset-0932','svg.fonttype':'none','font.family':'DejaVu Sans'}):
        fig.savefig(out,format=fmt,dpi=170,metadata=metadata,facecolor='white')
    plt.close(fig)
    return out.getvalue()


def image_bytes(c,result=None,fmt='png'):
    r=validated_result(c)
    try:
        fig=_physical(c,r)
    except (ArithmeticError,ValueError,TypeError,KeyError) as exc:
        fig=plt.figure(figsize=(10,3),facecolor='white')
        fig.text(.05,.76,'Geometria atual não desenhável',fontsize=16,color='#a33333')
        fig.text(.05,.51,str(exc)[:160],fontsize=9)
        fig.text(.05,.25,'Nenhum desenho favorável anterior foi reutilizado.',fontsize=10)
    return _export(fig,fmt)


def drawing_svg(c,result=None):return image_bytes(c,result,'svg').decode()


def effort_convention_svg(c=None):
    """Value-free reference; cut signs are fixed, independent of actual actions."""
    from .corner_gusset import CornerGusset
    c=c or CornerGusset()
    angle=c.phi_deg
    # Deliberately no numeric loads, moment values, result/status or dimensions.
    th=radians(angle); dx,dy=75*cos(th),-75*sin(th)
    scope_note='<text x="18" y="310" font-size="11">1L: eixo terminal nominal z=0; excentricidade ordinária desprezada, sem cancelamento espacial.</text>' if is_single(c) else ''
    return f'''<svg xmlns="http://www.w3.org/2000/svg" width="740" height="350" viewBox="0 0 740 350" role="img" aria-label="Convenção positiva COMPLETE_CUTS, sem valores">
<title>Convenção positiva dos esforços: cortes completos</title><desc>Fx para a direita, Fy para cima e M anti-horário em todos os cortes, como ações externas sobre a ligação isolada. N positivo traciona a diagonal. Corte inferior L derivado. Não representa o caso digitado.</desc>
<defs><marker id="cg-arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto"><path d="M0 0 L10 5 L0 10Z" fill="#176c89"/></marker></defs>
<rect x="1" y="1" width="738" height="348" rx="12" fill="#f7fafc" stroke="#cbd9e2"/>
<g font-family="DejaVu Sans,Arial,sans-serif" fill="#23384d" font-size="13"><text x="18" y="26" font-size="17" font-weight="bold">Convenção positiva · ações externas sobre a ligação isolada</text>
<path d="M170 74V275 M170 195H380" stroke="#b6c6d5" stroke-width="18" fill="none"/>
<path d="M178 187H295L178 85Z" fill="#dce5ef" stroke="#657c8d"/><path d="M200 171L{200+dx:.3f} {171+dy:.3f}" stroke="#176c89" stroke-width="2" marker-end="url(#cg-arrow)"/><text x="250" y="102">+N · tração</text>
<g stroke="#74668c" stroke-dasharray="4 3"><path d="M145 76H195M145 275H195M378 173V218"/></g>
<g stroke="#176c89" stroke-width="1.8" marker-end="url(#cg-arrow)" fill="none"><path d="M175 65H221M175 65V39"/><path d="M175 287H221M175 287V253"/><path d="M392 195H438M392 195V149"/><path d="M424 229A26 26 0 1 0 401 243"/></g>
<text x="224" y="68">+Fx</text><text x="185" y="49">+Fy</text><text x="113" y="65">U</text><text x="224" y="290">+Fx</text><text x="184" y="263">+Fy</text><text x="45" y="300">L · derivado</text><text x="442" y="200">+Fx</text><text x="399" y="146">+Fy</text><text x="378" y="265">+M anti-horário</text><text x="354" y="228">D</text>
<text x="500" y="86">+x → direita</text><text x="500" y="112">+y ↑ cima</text><text x="500" y="138">+M ↺ anti-horário</text><text x="500" y="179">D: corte da viga</text><text x="500" y="205">U: corte superior</text><text x="500" y="231">L: corte inferior</text>{scope_note}<text x="18" y="330" font-size="12">Sem valores. A mesma convenção +Fx/+Fy/+M vale em D, U e L; não confundir com esforços internos do software.</text></g></svg>'''


def effort_convention_png(c=None):
    # Avoid a second SVG renderer dependency: the reference is available as SVG
    # for UI; this matching plot is used only where raster embedding is required.
    from .corner_gusset import CornerGusset
    c=c or CornerGusset();fig,ax=plt.subplots(figsize=(9,3.5));ax.set_xlim(0,10);ax.set_ylim(0,4);ax.axis('off')
    _line(ax,(2,.8),(2,3.2),'reference-column',color='#b6c6d5',lw=13)
    _line(ax,(2,2),(5.5,2),'reference-beam',color='#b6c6d5',lw=13)
    for name,x,y in [('U',2,3.2),('D',5.5,2),('L derivado',2,.8)]:
        _arrow(ax,(x,y),(x+.7,y),'+Fx','#176c89');_arrow(ax,(x,y),(x,y+.55),'+Fy','#176c89')
        ax.text(x-.8,y-.2,name,fontsize=10)
    import numpy as np
    tt=np.linspace(radians(15),radians(300),45)
    xs=[5.5+.36*cos(t) for t in tt];ys=[1.2+.36*sin(t) for t in tt]
    ax.plot(xs,ys,color='#176c89',lw=1.2)
    _arrow(ax,(xs[-3],ys[-3]),(xs[-1],ys[-1]),color='#176c89',gid='reference-positive-M-CCW')
    ax.text(6.,1.05,'+M',fontsize=10,color='#176c89')
    _arrow(ax,(3,2.5),(3+.8*cos(radians(c.phi_deg)),2.5+.8*sin(radians(c.phi_deg))),'+N','#176c89')
    ax.text(6.8,3.1,'+M anti-horário\nAções externas em D/U/L\n+N: diagonal tracionada',fontsize=10,linespacing=1.8)
    if is_single(c):
        ax.text(.4,.36,'1L: eixo terminal nominal z=0; afastamento ordinário desprezado, sem cancelamento espacial.',fontsize=8)
    ax.text(.4,.08,'Convenção positiva, sem valores; não representa o caso digitado.',fontsize=9)
    return _export(fig,'png')
