"""Dimensioned M004 W splice with all eight continuous physical cover plates.

Coordinates are x along the member, y in the web plane and z across its
flanges. Drawings use the input dimensions, never altered geometry from a
result. This is a component illustration, not a fabrication release.
"""
from .display_precision import display_format, display_value
from io import BytesIO
from math import isfinite

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, PathPatch, Rectangle
from matplotlib.path import Path
from .drawing_annotations import dimension, rendered_wrap
from .w_splice import evaluate

INK = '#263746'
MEMBER = '#dce1e5'
WEB = '#b9d6dd'
OUTER = '#bbd4c6'
INNER = '#e6ccaa'
MUTED = '#65727b'

# Stable physical identifiers shared by the three views and the report.
COVERS = (
    ('W1', 'Tala da alma lado −z'), ('W2', 'Tala da alma lado +z'),
    ('F1', 'Mesa superior externa'), ('F2', 'Mesa superior interna −z'),
    ('F3', 'Mesa superior interna +z'), ('F4', 'Mesa inferior externa'),
    ('F5', 'Mesa inferior interna −z'), ('F6', 'Mesa inferior interna +z'),
)


def _header(fig, rows, top=.983):
    """Keep complete free text inside a measured header above the views."""
    renderer = fig.canvas.get_renderer()
    width_points = fig.get_figwidth() * 72 * .93
    y = top
    for text, size, weight in rows:
        artist = fig.text(.035, y, rendered_wrap(text, width_points, size, weight),
                          fontsize=size, fontweight=weight, color=INK, va='top',
                          linespacing=1.25)
        y -= (artist.get_window_extent(renderer).height / fig.bbox.height
              + 3 / (fig.get_figheight() * 72))
    # Titles have their own point-sized band; only the two upper views need
    # extra header space. Equal aspect and all data coordinates are unchanged.
    view_top = min(.81, y - 24 / (fig.get_figheight() * 72))
    for ax, bottom, width, left in ((fig.axes[0], .275, .39, .025),
                                   (fig.axes[1], .485, .505, .46)):
        ax.set_position((left, bottom, width, view_top-bottom))


def _points_per_data(ax):
    """Equal-aspect scale inside the allocated viewport, in physical points."""
    box = ax.get_position(original=True)
    fig = ax.figure
    return min(box.width * fig.get_figwidth() * 72 / abs(ax.get_xlim()[1]-ax.get_xlim()[0]),
               box.height * fig.get_figheight() * 72 / abs(ax.get_ylim()[1]-ax.get_ylim()[0]))


def _profile_header_rows(fig, name, suffix, size):
    """Keep actions/scope together when a free profile name needs another row."""
    combined = str(name) + suffix
    if '\n' not in rendered_wrap(combined, fig.get_figwidth()*72*.93, size):
        return [(combined, size, 'normal')]
    return [(str(name), size, 'normal'), (suffix.lstrip(' |•'), size, 'normal')]


def _dimensions(c):
    """Reject impossible rendering input without masking geometric clashes."""
    p = c.profile
    inner=getattr(c,'include_inner_flange_plates',True)
    active=(c.flange_inner_width,c.inner_clear_band) if inner else (c.flange_bolt_gauge,)
    values = (*active,p.d, p.bf, p.tw, p.tf, c.flange_outer_width, c.flange_t, c.web_height, c.web_t,
              c.flange_pitch, c.flange_member_end, c.flange_cover_end,
              c.web_pitch, c.web_gauge, c.web_member_end, c.web_cover_end,
              c.hole_diameter, c.db)
    if any(isinstance(v, bool) or not isinstance(v, (int, float)) or not isfinite(v) or v <= 0 for v in values):
        raise ValueError('Desenho W exige dimensões positivas e finitas.')
    if not isinstance(c.gap, (int, float)) or not isfinite(c.gap) or c.gap < 0:
        raise ValueError('Desenho W exige folga finita não negativa.')
    for count in (c.flange_rows, c.web_rows, c.web_levels):
        if type(count) is not int or not 1 <= count <= 20:
            raise ValueError('Desenho W exige contagens inteiras entre 1 e 20.')
    lf = c.gap + 2 * (c.flange_member_end + (c.flange_rows - 1) * c.flange_pitch + c.flange_cover_end)
    lw = c.gap + 2 * (c.web_member_end + (c.web_rows - 1) * c.web_pitch + c.web_cover_end)
    if not all(isfinite(v) for v in (lf,lw)):
        raise ValueError('Desenho W: comprimento calculado fora da faixa numérica finita.')
    return lf, lw


def _figure(c, result=None):
    lf, lw = _dimensions(c)
    p = c.profile
    tc, wc = c.flange_t, c.web_t
    inner=getattr(c,'include_inner_flange_plates',True)
    bo=c.flange_outer_width
    bi,band=(c.flange_inner_width,c.inner_clear_band) if inner else (0.,0.)
    gauge=band+bi if inner else c.flange_bolt_gauge
    z_bolts=(-gauge/2,gauge/2)
    xf = [s * (c.gap / 2 + c.flange_member_end + j * c.flange_pitch)
          for s in (-1, 1) for j in range(c.flange_rows)]
    xw = [s * (c.gap / 2 + c.web_member_end + j * c.web_pitch)
          for s in (-1, 1) for j in range(c.web_rows)]
    yw = [(j - (c.web_levels - 1) / 2) * c.web_gauge for j in range(c.web_levels)]
    span = max(lf, lw) / 2 + max(35., .13 * max(lf, lw))
    fig = plt.figure(figsize=(14, 9.3), facecolor='white')
    sec = fig.add_axes((.025, .275, .39, .535))
    elev = fig.add_axes((.46, .485, .505, .325))
    plan = fig.add_axes((.46, .085, .505, .325))
    for ax in (sec, elev, plan):
        ax.set_aspect('equal')
        ax.axis('off')

    def rect(ax, x, y, w, h, color, gid=None, **kwargs):
        patch = Rectangle((x, y), w, h, facecolor=color, edgecolor=INK,
                          linewidth=.8, **kwargs)
        patch.set_gid(gid)
        ax.add_patch(patch)
        return patch

    def line(ax, xs, ys, **kwargs):
        return ax.plot(xs, ys, color=kwargs.pop('color', INK),
                       linewidth=kwargs.pop('lw', .7), **kwargs)

    def hole(ax, x, y, gid):
        patch = Circle((x, y), c.hole_diameter / 2, facecolor='white',
                       edgecolor=INK, linewidth=.85)
        patch.set_gid(gid)
        ax.add_patch(patch)
        a = c.hole_diameter * .18
        line(ax, [x - a, x + a], [y, y], lw=.55)
        line(ax, [x, x], [y - a, y + a], lw=.55)

    def dim(ax, x1, y1, x2, y2, label, offset=0):
        vertical = abs(x1 - x2) < 1e-12
        return dimension(ax, (x1, y1), (x2, y2), label, fontsize=8.5,
                         rotation=90 if vertical else 0, color=INK,
                         offset=(offset, 0) if vertical else (0, offset),
                         pad=1.0, lw=.6,
                         short_side=-1 if vertical or y1 < 0 else 1)

    def leader(ax, label, xy, xytext, ha='left'):
        ax.annotate(label, xy=xy, xytext=xytext, ha=ha, va='center',
                    fontsize=9.5, color=INK,
                    arrowprops={'arrowstyle': '-', 'lw': .7, 'color': INK,
                                'connectionstyle': 'angle,angleA=0,angleB=90,rad=0'},
                    bbox={'facecolor': 'white', 'edgecolor': 'none', 'pad': .4})

    def title(ax, label):
        ax.set_title(label, loc='left', color=INK, fontsize=11, fontweight='bold', pad=14)

    # The real section shows eight separate pieces. Member root fillets are
    # shown only when their input is valid; no fillet area is inferred here.
    title(sec, 'A  CORTE TRANSVERSAL NO TRECHO PARAFUSADO')
    rect(sec, -p.bf / 2, p.d / 2 - p.tf, p.bf, p.tf, MEMBER, 'member_top_flange_section')
    rect(sec, -p.bf / 2, -p.d / 2, p.bf, p.tf, MEMBER, 'member_bottom_flange_section')
    rect(sec, -p.tw / 2, -p.d / 2 + p.tf, p.tw, p.d - 2 * p.tf, MEMBER, 'member_web_section')
    r = getattr(c, 'root_radius', 0.)
    if isinstance(r, (int, float)) and isfinite(r) and 0 < r < min((p.bf-p.tw)/2, (p.d-2*p.tf)/2):
        # Circular root approximated by a cubic quarter arc, reflected in z/y.
        k = .5522847498307936
        for sz in (-1, 1):
            for sy in (-1, 1):
                a, b = p.tw / 2, p.d / 2 - p.tf
                pts = [(a,b),(a+r,b),(a+r-k*r,b),(a,b-r+k*r),(a,b-r),(a,b)]
                path = Path([(sz*x,sy*y) for x,y in pts],
                            [Path.MOVETO,Path.LINETO,Path.CURVE4,Path.CURVE4,Path.CURVE4,Path.CLOSEPOLY])
                patch = PathPatch(path, facecolor=MEMBER, edgecolor=INK, lw=.65)
                patch.set_gid(f'member_root_{display_value(sz)}_{display_value(sy)}')
                sec.add_patch(patch)
    rect(sec, -p.tw/2-wc, -c.web_height/2, wc, c.web_height, WEB, 'cover_W1_section')
    rect(sec, p.tw/2, -c.web_height/2, wc, c.web_height, WEB, 'cover_W2_section')
    for sy, outer_id, inside_ids in ((1,'F1',('F2','F3')),(-1,'F4',('F5','F6'))):
        oy = p.d/2 if sy == 1 else -p.d/2-tc
        iy = p.d/2-p.tf-tc if sy == 1 else -p.d/2+p.tf
        rect(sec, -bo/2, oy, bo, tc, OUTER, f'cover_{display_value(outer_id)}_section')
        if inner:
            rect(sec, -band/2-bi, iy, bi, tc, INNER, f'cover_{display_value(inside_ids[0])}_section')
            rect(sec, band/2, iy, bi, tc, INNER, f'cover_{display_value(inside_ids[1])}_section')
        for z in z_bolts:
            lo, hi = sorted((oy+tc/2,iy+tc/2)) if inner else (p.d/2-p.tf+tc/2,p.d/2+tc/2) if sy>0 else (-p.d/2-tc/2,-p.d/2+p.tf-tc/2)
            line(sec,[z,z],[lo-8,hi+8],lw=1.3)
    for y in yw:
        line(sec,[-p.tw/2-wc-7,p.tw/2+wc+7],[y,y],lw=1.2)
    reach = max(p.bf, band+2*bi, bo) / 2 + 20
    top = p.d/2+tc
    leader(sec,'F1 externa superior',(0,top),(0,top+35),ha='center')
    leader(sec,'F4 externa inferior',(0,-top),(0,-top-35),ha='center')
    for label,z,y,text_y in (
        ('F2 interna',z_bolts[0],p.d/2-p.tf-tc/2,p.d*.31),
        ('F3 interna',z_bolts[1],p.d/2-p.tf-tc/2,p.d*.31),
        ('F5 interna',z_bolts[0],-p.d/2+p.tf+tc/2,-p.d*.31),
        ('F6 interna',z_bolts[1],-p.d/2+p.tf+tc/2,-p.d*.31)):
        if inner:leader(sec,label,(z,y),((-reach if z<0 else reach),text_y),ha='right' if z<0 else 'left')
    leader(sec,'W1 alma',(-p.tw/2-wc/2,0),(-reach,0),ha='right')
    leader(sec,'W2 alma',(p.tw/2+wc/2,0),(reach,0))
    dim(sec,-bo/2,top+63,bo/2,top+63,f"b externa = {display_format(bo, 'g')}")
    if inner:dim(sec,-band/2,-top-66,band/2,-top-66,f"c = {display_format(band, 'g')}")
    else:dim(sec,-gauge/2,-top-66,gauge/2,-top-66,f"g mesas = {display_format(gauge, 'g')}")
    side = reach + max(85.,.2*p.bf)
    sec.set_xlim(-side,side)
    sec.set_ylim(-top-86,top+88)
    sec.set_ylim(-top-max(86, 66+24/_points_per_data(sec)), top+88)
    sec.text(.5,-.01,'8 talas físicas  •  2 planos de corte por parafuso' if inner else '4 talas físicas  •  mesas: 1 plano; alma: 2 planos',
             transform=sec.transAxes,ha='center',va='top',fontsize=10,color=INK)

    # Web elevation: a single visible cover represents W1; W2 is coincident
    # in projection, explicitly identified as the opposite physical plate.
    title(elev,'B  ELEVAÇÃO DA ALMA  |  W1 E W2')
    for sign in (-1,1):
        x0,x1 = (-span,-c.gap/2) if sign<0 else (c.gap/2,span)
        rect(elev,x0,-p.d/2,x1-x0,p.d,MEMBER, f'member_{display_value(sign)}_elevation',alpha=.55)
        for y in (-p.d/2,p.d/2-p.tf):
            rect(elev,x0,y,x1-x0,p.tf,MEMBER)
    rect(elev,-lw/2,-c.web_height/2,lw,c.web_height,WEB,'cover_W1_elevation',alpha=.85)
    rect(elev,-lw/2,-c.web_height/2,lw,c.web_height,'none','cover_W2_elevation',linestyle='--')
    for i,x in enumerate(xw):
        for j,y in enumerate(yw):
            hole(elev,x,y,f'web_hole_{display_value(i)}_{display_value(j)}')
    for x in (-c.gap/2,c.gap/2):
        line(elev,[x,x],[-p.d/2-8,p.d/2+8],ls=(0,(5,3)),color=MUTED)
    for sy in (-1,1):
        oy = p.d/2 if sy>0 else -p.d/2-tc
        iy = p.d/2-p.tf-tc if sy>0 else -p.d/2+p.tf
        rect(elev,-lf/2,oy,lf,tc,OUTER, f'flange_outer_{display_value(sy)}_elevation',alpha=.85)
        if inner:rect(elev,-lf/2,iy,lf,tc,INNER, f'flange_inner_{display_value(sy)}_elevation',alpha=.7)
    dim(elev,-lw/2,-p.d/2-33,lw/2,-p.d/2-33,f"L alma = {display_format(lw, 'g')}")
    dim(elev,span+18,-c.web_height/2,span+18,c.web_height/2,f"h alma = {display_format(c.web_height, 'g')}")
    # Annotation lanes stay separate even for the shorter two-row specimen.
    leader(elev,f"g = {display_format(c.gap, 'g')} mm", (0,p.d/2+tc+3),(span-12,p.d/2+tc+59),ha='right')
    elev.annotate(f'{display_value(c.web_rows)} × {display_value(c.web_levels)} parafusos / lado',
                  xy=(-span,-p.d/2-33), xytext=(0,-27), textcoords='offset points',
                  fontsize=9,va='top',color=INK)
    elev.set_xlim(-span-8,span+45)
    elev.set_ylim(-p.d/2-85,p.d/2+tc+80)
    elev.set_ylim(-p.d/2-max(85, 33+45/_points_per_data(elev)), p.d/2+tc+80)

    # Plan of the upper flange. The lower flange has its own six/other
    # bolts and its own three plates, never an added parallel splice side.
    title(plan,'C  PLANTA DA MESA SUPERIOR  |  INFERIOR IDÊNTICA')
    for sign in (-1,1):
        x0,x1 = (-span,-c.gap/2) if sign<0 else (c.gap/2,span)
        rect(plan,x0,-p.bf/2,x1-x0,p.bf,MEMBER,f'member_{display_value(sign)}_plan',alpha=.6)
    if inner:
        rect(plan,-lf/2,-band/2-bi,lf,bi,INNER,'cover_F2_plan',alpha=.9)
        rect(plan,-lf/2,band/2,lf,bi,INNER,'cover_F3_plan',alpha=.9)
    rect(plan,-lf/2,-bo/2,lf,bo,OUTER,'cover_F1_plan',alpha=.42)
    for z in ((-band/2,band/2) if inner else ()):
        line(plan,[-lf/2,lf/2],[z,z],ls='--',color='#896947')
    for i,x in enumerate(xf):
        for j,z in enumerate(z_bolts):
            hole(plan,x,z,f'flange_hole_{display_value(i)}_{display_value(j)}')
    for x in (-c.gap/2,c.gap/2):
        line(plan,[x,x],[-p.bf/2-6,p.bf/2+6],ls=(0,(5,3)),color=MUTED)
    dim(plan,-lf/2,-p.bf/2-31,lf/2,-p.bf/2-31,f"L mesas = {display_format(lf, 'g')}")
    dim(plan,span+18,z_bolts[0],span+18,z_bolts[1],f"g mesas = {display_format(gauge, 'g')}")
    caption = plan.annotate(f'{display_value(c.flange_rows)} × 2 parafusos / lado / mesa\n'+('F1 sobre F2 + F3' if inner else 'F1 externa; F4 na mesa inferior'),
                            xy=(-span,p.bf/2), xytext=(0,10), textcoords='offset points',
                            fontsize=9,linespacing=1.5,va='bottom',color=INK)
    plan.set_xlim(-span-8,span+45)
    plan.set_ylim(-p.bf/2-55,p.bf/2+83)
    caption_height = caption.get_window_extent(fig.canvas.get_renderer()).height * 72/fig.dpi
    plan.set_ylim(-p.bf/2-55,
                  p.bf/2+max(83, (caption_height+18)/_points_per_data(plan)))

    # Dimension schedule avoids unreadable chains on crowded bolt grids.
    labels = [
        f"W1 + W2   2 × {display_format(lw, 'g')} × {display_format(c.web_height, 'g')} × {display_format(wc, 'g')} mm",
        f"F1 + F4     2 × {display_format(lf, 'g')} × {display_format(bo, 'g')} × {display_format(tc, 'g')} mm",
        f"F2 F3 F5 F6   4 × {display_format(lf, 'g')} × {display_format(bi, 'g')} × {display_format(tc, 'g')} mm",
        f"Alma: p = {display_format(c.web_pitch, 'g')}; passo vertical = {display_format(c.web_gauge, 'g')}; e membro / tala = {display_format(c.web_member_end, 'g')} / {display_format(c.web_cover_end, 'g')}",
        f"Mesas: p = {display_format(c.flange_pitch, 'g')}; e membro / tala = {display_format(c.flange_member_end, 'g')} / {display_format(c.flange_cover_end, 'g')}",
        f"Parafuso Ø{display_format(c.db, 'g')}; furo Ø{display_format(c.hole_diameter, 'g')}; cotas em mm",
    ]
    if not inner:labels.pop(2)
    fig.text(.035,.22,'RELAÇÃO DE TALAS CONTÍNUAS E PARAFUSOS',fontsize=10.5,fontweight='bold',color=INK)
    fig.text(.035,.204,'\n'.join(labels),fontsize=9.2,linespacing=1.5,va='top',color=INK)
    status = str((result or {}).get('status','ESCOPO LIMITADO')) if isinstance(result,(dict,type(None))) else 'ESCOPO LIMITADO'
    _header(fig, [
        ('EMENDA W M004  |  TRAÇÃO AXIAL', 17, 'bold'),
        ('Projeto: '+str(c.project), 10.5, 'normal'),
        *_profile_header_rows(fig, p.name, '  •  duas extremidades coaxiais  •  Escopo do método: N > 0; M = V = T = 0', 10),
        (f"Ações de entrada (com sinal): N = {display_format(c.N, '+.12g')} N; M = {display_format(c.M, '+.12g')} N mm; V = {display_format(c.V, '+.12g')} N; T = {display_format(c.torsion, '+.12g')} N mm", 9.5, 'normal'),
        ('Resultado atual: '+status, 9.5, 'normal'),
    ])
    fig.text(.035,.031,'As 8 talas atravessam a junta sem interrupção. Grupos esquerdo e direito em série; capacidades não se somam.',fontsize=9.5,color=INK)
    fig.text(.035,.011,'Esquema dimensionado do modelo; não libera fabricação. Cinza: perfil; azul: alma; verde: externas; ocre: internas.',fontsize=9.5,color=INK)
    return fig


def image_bytes(c, result=None, fmt='png'):
    """Return an input-bound PNG/SVG; caller-provided results are not authority.

    A fresh evaluation binds the conclusion to the same immutable input used
    for geometry, even when a caller passes stale, partial or forged results.
    """
    result=evaluate(c)
    with plt.rc_context({'font.family':'DejaVu Sans','font.size':10,'svg.fonttype':'none'}):
        fig = _figure(c, result)
        try:
            out = BytesIO()
            metadata={'Creator':'LRO M004 W splice'}
            if result.get('input_digest'):metadata['Description']='input_digest='+str(result['input_digest'])
            fig.savefig(out, format=fmt, dpi=170, facecolor='white',metadata=metadata)
            return out.getvalue()
        finally:
            plt.close(fig)


def drawing_svg(c, result=None):
    """Return a searchable vector drawing with stable component identifiers."""
    return image_bytes(c,result,'svg').decode('utf-8')
