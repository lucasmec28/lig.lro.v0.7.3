"""Native, input-bound UI for the finite static axial 2L–plate connection."""
from .display_precision import display_format, display_frame, display_tree, display_value, number_input
from dataclasses import fields
import hashlib
import json
import math

import pandas as pd
import streamlit as st
from .load_conventions import render as render_load_convention

from .axial_double_angle import AxialDoubleAngle, FAMILY, presets, evaluate
from .axial_double_angle_presentation import physical_envelopes
from .angle_catalog_ui import (render_selector as render_angle_catalog,
    draft_keys as angle_catalog_draft_keys, reset as reset_angle_catalog)
from .models import STEELS, BOLTS, VERSION
from .package_identity import PACKAGE_ID as VERSION  # display only; native serializers remain frozen
from .report import BRAND, LINK

PRESETS = presets()
PREFIX = 'ad_'
PROJECT = '_axial_double_angle_project'
DRAFT = '_axial_double_angle_ui_draft'
RESULT = '_axial_double_angle_result'
UNITS = {'N': 1000., 'V': 1000., 'M': 1000000., 'torsion': 1000000.}
DISPLAY = {'N': 'N_kN', 'V': 'V_kN', 'M': 'M_kNm', 'torsion': 'torsion_kNm'}
SCOPE_TEXT = ('Modelo nominal estático NBR 8800:2024, 6.1.8.2: N atua no eixo dos parafusos e da chapa. '
              'A excentricidade física do centroide das cantoneiras é omitida apenas neste modelo nominal. '
              'No corte terminal perpendicular e centrado: N, M=0 e V=0. '
              'A raiz da chapa, suas soldas e o apoio a jusante não são verificados.')
STATUS = {
    'INVALID_INPUT': 'DADOS INVÁLIDOS',
    'NUMERICAL_FAILURE': 'FALHA NUMÉRICA · CÁLCULO NÃO CONCLUÍDO',
    'INVALID_GEOMETRY': 'GEOMETRIA FISICAMENTE INVÁLIDA',
    'OUTSIDE_SCOPE': 'FORA DO DOMÍNIO · TRAÇÃO AXIAL ESTÁTICA',
    'OUTSIDE_AXIAL_SCOPE': 'FORA DO DOMÍNIO · TRAÇÃO AXIAL ESTÁTICA',
    'DETAIL_FAIL': 'NÃO ATENDE AO DETALHAMENTO',
    'DETAILING_FAIL': 'NÃO ATENDE AO DETALHAMENTO',
    'COMPLETE_CHECKS_FAIL': 'NÃO ATENDE ÀS VERIFICAÇÕES REALIZADAS',
    'COMPLETE_CHECKS_PASS_WITHIN_SCOPE': 'ATENDE ÀS VERIFICAÇÕES LOCAIS NO DOMÍNIO',
    'INCOMPLETE_CHECKS': 'VERIFICAÇÕES INCOMPLETAS',
    'VERIFIED_SUBCHECK_FAIL': 'NÃO ATENDE ÀS VERIFICAÇÕES REALIZADAS',
    'COMPLETE_LOCAL_CHECKS_PASS_WITHIN_SCOPE': 'ATENDE ÀS VERIFICAÇÕES LOCAIS NO DOMÍNIO',
}


def _finite(value):
    try:
        return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)
    except (OverflowError, ValueError):
        return False


def _number(value, field):
    if not _finite(value) or float(value) != value:
        raise ValueError(f'{display_value(field)}: número finito, representável sem perda, obrigatório.')
    return float(value)


def draft_keys():
    return angle_catalog_draft_keys(PREFIX) + [PREFIX + f.name for f in fields(AxialDoubleAngle)] + [PREFIX + key for key in DISPLAY.values()]


def import_ui_values(c):
    """Stage the complete candidate before writing any widget or accepted state."""
    c.to_dict()
    proposed = {}
    for field in fields(c):
        value = getattr(c, field.name)
        if field.type in (float, 'float'):
            value = _number(value, field.name)
        proposed[PREFIX + field.name] = value
    for key, unit in UNITS.items():
        value = getattr(c, key)
        displayed = _number(value / unit, key)
        if value != 0 and displayed == 0:
            raise ValueError(f'{display_value(key)}: conversão de unidade não representável sem perda.')
        proposed[PREFIX + DISPLAY[key]] = displayed
    return proposed


def seed(c):
    proposed = import_ui_values(c)
    st.session_state.update(proposed)
    reset_angle_catalog(PREFIX)
    st.session_state.pop('ad_report', None)
    st.session_state.pop(DRAFT, None)


def use_example():
    seed(PRESETS[st.session_state.ad_example])


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f'Chave JSON duplicada: {display_value(key)}.')
        result[key] = value
    return result


def decode_project(payload):
    if len(payload) > 200000:
        raise ValueError('Arquivo maior que 200 kB.')
    def reject_constant(value):
        raise ValueError('Número JSON inválido: ' + value)
    native = json.loads(payload, object_pairs_hook=_unique_object, parse_constant=reject_constant)
    c = AxialDoubleAngle.from_dict(native)
    import_ui_values(c)
    return c


def load_project():
    try:
        upload = st.session_state.ad_upload
        if upload is None:
            raise ValueError('Selecione um arquivo JSON.')
        seed(decode_project(upload.getvalue()))
        st.session_state.pop('ad_import_error', None)
    except (ValueError, TypeError, KeyError, OverflowError, UnicodeError) as exc:
        st.session_state.ad_import_error = 'Não foi possível abrir: ' + str(exc)


def _force(key):
    raw = st.session_state[PREFIX + key]
    shown = st.session_state[PREFIX + DISPLAY[key]]
    _number(raw, key)
    _number(shown, key)
    if shown == raw / UNITS[key]:
        return raw
    converted = shown * UNITS[key]
    if not _finite(converted):
        raise ArithmeticError(f'{display_value(key)}: conversão excede a faixa numérica finita.')
    return converted


def _select(label, options, key, labels=None):
    options = list(options)
    selected = st.session_state.get(PREFIX + key)
    if selected not in options:
        options.append(selected)
    return st.selectbox(label, options, key=PREFIX + key,
                        format_func=(lambda value: labels.get(value, str(value) + ' · importado')) if labels else str)


def _dimension(key, label):
    # No clipping or silent normalization of imported/draft geometry.
    return number_input(label + ' (mm)', key=PREFIX + key, format='%.2f')


def _display(value):
    return f"{display_format(value, '.3f')}" if _finite(value) else '—'


def checks_complete(result):
    checks = result.get('checks') or []
    required = {'id', 'label', 'component', 'mechanism', 'case_id', 'demand', 'resistance', 'utilization', 'status'}
    return bool(checks) and result.get('summary', {}).get('complete_checks') is True and all(
        isinstance(row, dict) and required <= row.keys()
        and all(_finite(row[key]) for key in ('demand', 'resistance', 'utilization'))
        and row['status'] in ('PASS', 'FAIL') for row in checks)


def _checks_table(checks):
    return pd.DataFrame([{
        'ID': row['id'], 'Caso': row['case_id'], 'Componente': row['component'],
        'Mecanismo': row['mechanism'], 'Verificação': row['label'],
        'Solicitação (kN)': row['demand'] / 1000., 'Resistência (kN)': row['resistance'] / 1000.,
        'Índice': row['utilization'], 'Resultado': row['status'],
        'Sentido carregado': row.get('loaded_direction', ''),
        'Parafusos do caminho': str(row.get('bolt_indices', '')),
    } for row in checks])


def _envelopes_table(envelopes):
    rows = []
    for envelope in envelopes:
        governing = envelope.get('governing', [])
        if isinstance(governing, dict):
            governing = [governing]
        rows.append({
            'Componente físico': envelope.get('component_label', envelope.get('component', '')),
            'Mecanismo': envelope.get('mechanism_label', envelope.get('mechanism', '')),
            'Índice com N real': envelope.get('actual_utilization'),
            'Resultado real': envelope.get('actual_status'),
            'Índice governante': envelope.get('utilization'), 'Resultado': envelope.get('status'),
            'Governantes e empates': '; '.join(row['id'] for row in governing),
            'Ramos preservados': len(envelope.get('members', [])),
        })
    return pd.DataFrame(rows)


def _fail(exc):
    s = st.session_state
    s.pop('ad_report', None)
    s.pop(PROJECT, None)
    s[DRAFT] = {key: s[key] for key in draft_keys() if key in s}
    status = 'NUMERICAL_FAILURE' if isinstance(exc, ArithmeticError) else 'INVALID_INPUT'
    s[RESULT] = {'status': status, 'global_pass': False, 'checks': [],
                 'geometry': {'valid': False}, 'summary': {'complete_checks': False},
                 'issues': [{'id': 'ui_input', 'severity': 'error', 'message': str(exc)}]}
    st.error(STATUS[status])
    st.error(str(exc))
    st.caption('Nenhum resultado ou arquivo anterior é válido para a edição atual. Corrija os dados para recalcular.')
    st.button('Gerar memória 2L axial', disabled=True)


def render():
    try:
        _render()
    except (ArithmeticError, ValueError, TypeError, KeyError) as exc:
        _fail(exc)


def _render():
    from .axial_double_angle_drawing import image_bytes
    from .axial_double_angle_report import create_report

    s = st.session_state
    saved, draft = s.get(PROJECT), s.get(DRAFT)
    prior_report = s.pop('ad_report', None)
    s.pop(PROJECT, None)
    s.pop(RESULT, None)
    if 'ad_project' not in s:
        seed(AxialDoubleAngle.from_dict(saved) if saved else next(iter(PRESETS.values())))
        if draft:
            s.update(draft)
    for key in draft_keys():
        if key in s:
            s[key] = s[key]
    with st.sidebar:
        st.caption('Versão ' + VERSION + ' · ligação axial 2L')
        st.selectbox('Exemplo 2L axial', list(PRESETS), key='ad_example')
        st.button('Usar exemplo 2L axial', on_click=use_example)
        st.file_uploader('Abrir projeto 2L axial', type=['json'], key='ad_upload')
        st.button('Carregar 2L axial', on_click=load_project)
        if 'ad_import_error' in s:
            st.error(s.ad_import_error)
        st.caption(BRAND)
        st.link_button('LinkedIn · Lucas Oliveira', LINK)
    st.title(FAMILY)
    st.info(SCOPE_TEXT)
    st.caption('Duas cantoneiras iguais em contato direto nas faces de uma chapa retangular de largura real constante. '
               'Uma linha de parafusos passantes, dois planos de corte. Sem calços, atrito creditado, solda participante ou espalhamento Whitmore.')
    st.text_input('Identificação do projeto 2L axial', key='ad_project')
    left, right = st.columns([.9, 1.5], gap='large')
    with left:
        st.subheader('Dados principais')
        render_angle_catalog(PREFIX, area_factor=2, axial=True)
        st.text_input('Perfil 2L · designação declarada', key='ad_profile_name')
        st.caption('Seção atual: 2L ' + _display(s.ad_leg) + ' × ' + _display(s.ad_t) +
                   ' mm; Ag do par=' + _display(s.ad_Ag) + ' mm²; ec=' + _display(s.ad_ec) + ' mm.')
        if not s.ad_angle_catalog_id and (s.ad_leg, s.ad_t, s.ad_Ag, s.ad_ec) != (76., 6.35, 1858., 21.3):
            st.caption('Geometria/propriedades personalizadas fornecidas. A designação não substitui os valores; '
                       'confira compatibilidade e proveniência no painel avançado.')
        _select('Aço das duas cantoneiras', [key for key, steel in STEELS.items() if steel.rolled_allowed], 'angle_steel')
        number_input('Tração Nsd real, já majorada (kN)', key='ad_N_kN', format='%.2f')
        load_convention_slot = st.empty()
        a, b = st.columns(2)
        with a:
            _dimension('plate_width', 'Largura real da chapa')
        with b:
            _dimension('plate_t', 'Espessura da chapa')
        _select('Aço da chapa', [key for key, steel in STEELS.items() if steel.plate_allowed], 'plate_steel')
        _select('Classe dos parafusos', BOLTS, 'bolt')
        _dimension('db', 'Diâmetro nominal do parafuso')
        number_input('Parafusos na única linha longitudinal', step=1, key='ad_n')
        _dimension('pitch', 'Passo longitudinal')
        _dimension('gauge', 'Gabarito desde o talão da cantoneira')
        _dimension('angle_end', 'Último parafuso até a ponta livre das cantoneiras')
        _dimension('plate_end', 'Ponta livre da chapa até o primeiro parafuso')
        st.caption('As pontas livres carregadas são opostas. A chapa recebe N; cada cantoneira recebe N/2. '
                   'Coordenadas, furo padrão e pega são derivados, sem entradas redundantes.')
        with st.expander('Avançado · perfil, montagem e proveniência'):
            st.text_input('Fonte das dimensões e propriedades do perfil', key='ad_profile_source')
            _dimension('leg', 'Aba igual das cantoneiras')
            _dimension('t', 'Espessura de cada cantoneira')
            number_input('Área bruta Ag do par (mm²)', key='ad_Ag', format='%.2f')
            _dimension('ec', 'ec de cada cantoneira · centroide ao plano de ligação')
            if not s.ad_angle_catalog_id:
                st.caption('Referência do exemplo inicial: Souza, tabela de cantoneiras duplas, PDF 162: 2L76×6,35; Ag do par 1858 mm²; ec 21,3 mm. '
                           'Propriedades fornecidas são preservadas; não se recalculam por uma seção sintética de cantos vivos. '
                           'Uma edição de geometria exige propriedades compatíveis e fonte atualizada pelo responsável.')
            if not s.ad_angle_catalog_id:
                _dimension('root_radius', 'Raio interno real')
            _dimension('tool_radius', 'Raio combinado ferragens/ferramenta')
            _dimension('fabrication_clearance', 'Folga adicional de fabricação')
            st.caption('No exemplo manual, raio interno 6 mm e envelope 18 mm + folga 2 mm são entradas declaradas; '
                       'não são dimensões ASTM de fabricante nem valores fornecidos pelo exemplo Souza. Confirmar para fabricação.')
            _dimension('terminal_extension', 'Extensão contínua da chapa além da ponta das cantoneiras')
            st.checkbox('Furos de broca documentados · sem acréscimo de 2 mm na dedução', key='ad_drilled')
            st.checkbox('Rosca excluída e documentada · plano 1', key='ad_threads_excluded_1')
            st.checkbox('Rosca excluída e documentada · plano 2', key='ad_threads_excluded_2')
            st.checkbox('Protensão documentada · dispensa aplicável de redução por pega', key='ad_pretensioned')
            _select('Exposição', ['painted', 'weathering'], 'exposure',
                    {'painted': 'Pintado / protegido', 'weathering': 'Patinável exposto'})
        with st.expander('Avançado · ações, políticas e domínio'):
            st.checkbox('Aplicar mínimo obrigatório de 45 kN · caso separado, 6.1.5.2', key='ad_minimum_force')
            st.checkbox('Adotar recomendação separada de 50% de Nt,Rd · 6.1.5.3', key='ad_recommend_half_capacity')
            st.caption('Nesta ligação comum de extremidade 2L não há exceção codificada ao mínimo de 45 kN. '
                       'Se N real for menor, desativar o mínimo deixa o projeto fora do domínio. '
                       'N real permanece inalterado, inclusive N=0. Casos mínimo e recomendado não são somados. '
                       'A recomendação usa a capacidade axial de tração explicitada; não fornece capacidade global de compressão '
                       'nem aplica automaticamente a exceção de barras governadas por esbeltez.')
            st.checkbox('Ações estáticas · sem fadiga ou reversão cíclica', key='ad_static')
            st.checkbox('Combinações últimas normais', key='ad_normal_combination')
            st.checkbox('Duas cantoneiras iguais e simétricas', key='ad_symmetric')
            number_input('Quantidade física de cantoneiras', key='ad_angle_count', step=1)
            number_input('V adicional · fora do domínio (kN)', key='ad_V_kN')
            number_input('M adicional · fora do domínio (kN·m)', key='ad_M_kNm')
            number_input('Torção adicional · fora do domínio (kN·m)', key='ad_torsion_kNm')
        st.text_area('Observações do responsável técnico', key='ad_notes')

    values = {f.name: s[PREFIX + f.name] for f in fields(AxialDoubleAngle) if f.name not in UNITS}
    c = AxialDoubleAngle(**values, **{key: _force(key) for key in UNITS})
    native = c.to_dict()
    encoded = json.dumps(native, ensure_ascii=False, indent=2, allow_nan=False)
    s[DRAFT] = {key: s[key] for key in draft_keys() if key in s}
    with load_convention_slot.container():
        render_load_convention(st, 'axial_double_angle_bolted', c.N)
    r = evaluate(c)
    digest = hashlib.sha256((encoded + json.dumps(r, ensure_ascii=False, sort_keys=True, allow_nan=False)).encode()).hexdigest()
    s[PROJECT], s[RESULT] = native, r
    complete = checks_complete(r)
    geometry_valid = r.get('geometry', {}).get('valid') is True
    status = r.get('status', 'INVALID_INPUT')
    ready = complete and geometry_valid and not status.startswith(('INVALID', 'NUMERICAL', 'OUTSIDE'))
    if ready and prior_report and prior_report[0] == digest:
        s.ad_report = prior_report
    png = image_bytes(c) if geometry_valid else None
    with right:
        label = STATUS.get(status, status)
        if r.get('global_pass') is True and complete and geometry_valid:
            st.success(label + ' · LIGAÇÃO LOCAL')
        else:
            st.error(label)
        st.caption('Resultado limitado ao componente entre as pontas reais e o corte terminal. '
                   'Não aprova raiz, soldas, nó completo, coluna ou estabilidade global da barra.')
        a, b = st.columns(2)
        a.metric('N real (kN)', _display(c.N / 1000.))
        b.metric('Índice governante', _display(r.get('summary', {}).get('utilization')))
        cases = r.get('cases') or []
        if cases:
            st.subheader('Ações independentes')
            st.dataframe(display_frame(pd.DataFrame([{'Caso': case['label'], 'ID': case['id'], 'N (kN)': case['N'] / 1000.} for case in cases])), hide_index=True, width='stretch')
        for issue in r.get('issues') or []:
            message = issue.get('message', issue.get('text', str(issue)))
            if issue.get('severity') in ('warning', 'info', 'note'):
                st.warning(message) if issue.get('severity') == 'warning' else st.caption(message)
            else:
                st.error(message)
        geometry = r.get('geometry') or {}
        if geometry_valid:
            st.image(png, width='stretch')
        with st.expander('Geometria derivada · coordenadas em mm'):
            st.json(display_tree(geometry), expanded=False)
        with st.expander('Seções, áreas e Ct atuais'):
            st.json(display_tree(r.get('sections') or {}), expanded=False)
        with st.expander('Eixo nominal e ações no corte terminal'):
            st.caption(SCOPE_TEXT)
            st.json(display_tree(r.get('load_model') or {}), expanded=False)
    checks = r.get('checks') or []
    if complete:
        envelopes = physical_envelopes(r)
        st.subheader('Envelopes por componente físico e mecanismo')
        st.caption(f'{display_value(len(envelopes))} envelopes preservam {display_value(len(checks))} verificações primitivas. Casos real, mínimo e recomendado são alternativas, nunca capacidades somadas. Todos os empates ficam registrados.')
        st.dataframe(display_frame(_envelopes_table(envelopes)), hide_index=True, width='stretch')
        with st.expander('Governantes, empates e membros de cada envelope'):
            st.json(display_tree(envelopes), expanded=False)
        with st.expander('Todas as verificações primitivas e caminhos físicos'):
            st.dataframe(display_frame(_checks_table(checks)), hide_index=True, width='stretch')
            st.caption('Testemunhas: caminho, áreas, furos incluídos e direção carregada. '
                       'Talão é uma dobra; não é uma borda livre fictícia. Caminhos de lados opostos da chapa são alternativas.')
            st.json(display_tree(checks), expanded=False)
    elif checks:
        st.warning('Registros incompletos: emissão da memória e conclusão resistente bloqueadas.')
        st.json(display_tree(checks), expanded=False)
    a, b, d = st.columns(3)
    a.download_button('Salvar projeto 2L axial .json', encoded, 'ligacao_2L_axial.json', 'application/json')
    if geometry_valid:
        b.download_button('Baixar desenho 2L axial .png', png, 'ligacao_2L_axial.png', 'image/png')
        b.download_button('Baixar desenho 2L axial .svg', image_bytes(c, fmt='svg'), 'ligacao_2L_axial.svg', 'image/svg+xml')
    if ready and not r.get('global_pass'):
        st.caption('A memória registra as falhas atuais. Emiti-la não constitui aprovação da ligação.')
    if d.button('Gerar memória 2L axial', disabled=not ready):
        s.ad_report = (digest, 'memoria_2L_axial.docx', create_report(c))
    if 'ad_report' in s:
        _, filename, payload = s.ad_report
        st.download_button('Baixar memória 2L axial .docx', payload, filename,
                           'application/vnd.openxmlformats-officedocument.wordprocessingml.document')
