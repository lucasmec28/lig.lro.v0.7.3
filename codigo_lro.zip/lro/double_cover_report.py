"""Memória da ligação com talas: quadro completo e contas governantes."""
from .display_precision import calculated_text
from .display_precision import display_format, display_value
from io import BytesIO
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.oxml import OxmlElement
from .models import STEELS,KGF
from .package_identity import PACKAGE_ID
from .double_cover import NBR,ASSEMBLY_NOTE,COMPRESSION_NOTE,evaluate,weld_interfaces,internal_fin_bearing
from .double_cover_drawing import image_bytes
from .report import table,number,display,decimal_text,hyperlink,BRAND,LINK,_math,group,sub,frac,power,radical

REFERENCES=[
    NBR+' — itens 5.3, 6.1.5, 6.2, 6.3 e 6.5: materiais, parafusos, soldas e elementos de ligação.',
    'AISC 360-22, F11: resistência à flexão de barras chatas. A resistência nominal complementar é dividida por γa1; não se utiliza conversão global de tabelas LRFD.',
    'Fortney e Thornton (2016), Analysis and Design of Stabilizer Plates in Single-Plate Shear Connections, Engineering Journal 53(1), 1–28. DOI: 10.62913/engj.v53i1.1095. Fundamenta a atenção ao momento local e à estabilização; não valida esta geometria com talas.',
    'Sapkota et al. (2024), Behavior of Extended Single-Plate Shear Connections Subjected to Combined Shear and Compression Forces Using FEA, Engineering Journal 61(4), 193–216. DOI: 10.62913/engj.v61i4.1332. Referência de comportamento sob compressão, sem transposição direta de capacidades.'
]

WELD_EDGE_LABELS={'web':'Alma da coluna','top':'Horizontal superior','bottom':'Horizontal inferior'}
INTERNAL_WELD_HYPOTHESIS=(
    'Modelo elástico do grupo de soldas em três bordas: nervura rígida no plano, '
    'apoios receptores idealizados rígidos e compatibilidade de deslocamentos dos filetes. '
    'Cada borda tem dois filetes contínuos, com garganta a=w/√2 e comprimento útil após os alívios. '
    'A rigidez é ponderada pelas gargantas reais; não há aumento direcional da resistência. '
    'O atendimento do metal de solda é local e condicionado a essas hipóteses. '
    'A transferência em membrana pelos ligamentos e pontes da nervura perfurada, sua estabilidade, '
    'a ruptura e os demais modos do metal-base, e a capacidade/rigidez dos receptores permanecem pendentes.')


def weld_geometry_rows(weld_group):
    """One physical row per double-fillet edge, shared by the UI and Word."""
    return [(WELD_EDGE_LABELS[s['id']],
             '; '.join(number(v) for v in s['start_mm']),
             '; '.join(number(v) for v in s['end_mm']),
             number(s['length_mm']),number(s['leg_mm']),number(s['throat_mm']),number(s['area_mm2']))
            for s in weld_group['segments']]


def weld_reaction_rows(weld_group):
    """Signed transmitted actions, including the exact moment of distributed load."""
    return [(WELD_EDGE_LABELS[s['id']],number(s['integrated_Fx_N']/KGF),
             number(s['integrated_Fy_N']/KGF),number(s['integrated_M_about_origin_Nmm']/(KGF*1000)))
            for s in weld_group['segments']]


def weld_stress_rows(weld_group):
    return [(WELD_EDGE_LABELS[s['id']],number(p['x_mm'])+'; '+number(p['y_mm']),
             number(p['sx_MPa']),number(p['sy_MPa']),number(p['resultant_MPa']),
             number(p['resultant_MPa']/weld_group['stress_resistance_MPa'],3))
            for s in weld_group['segments'] for p in s['endpoint_stresses']]


def internal_weld_equations(doc):
    start=len(doc.paragraphs)
    aw=sub('A','w');xc=sub('x','c');yc=sub('y','c');mc=sub('M','c')
    _math(doc,group(aw,' = Σ 2',sub('a','i'),sub('L','i'),';   ',
                    xc,' = ',frac('Σ Ai xi',aw),';   ',yc,' = ',frac('Σ Ai yi',aw)))
    _math(doc,group('J = ∫ [',power(group('(x − ',xc,')')),' + ',
                    power(group('(y − ',yc,')')),'] dA'))
    _math(doc,group(mc,' = ',sub('M','o'),' − (',xc,'V − ',yc,'N)'))
    _math(doc,group(sub('τ','x'),' = ',frac('N',aw),' − ',frac(group(mc,'(y − ',yc,')'),'J'),
                    ';   ',sub('τ','y'),' = ',frac('V',aw),' + ',frac(group(mc,'(x − ',xc,')'),'J')))
    _math(doc,group(sub('q','x'),' = 2',sub('a','i'),sub('τ','x'),';   ',
                    sub('q','y'),' = 2',sub('a','i'),sub('τ','y')))
    _math(doc,group(sub('F','x,i'),' = ∫',sub('q','x'),' ds;   ',
                    sub('F','y,i'),' = ∫',sub('q','y'),' ds;   ',
                    sub('M','o,i'),' = ∫(x',sub('q','y'),' − y',sub('q','x'),') ds'))
    for paragraph in doc.paragraphs[start:-1]:paragraph.paragraph_format.keep_with_next=True

def equation(doc,row):
    i=row.id;g1=sub('γ','a1');g2=sub('γ','a2');fy=sub('f','y');fu=sub('f','u');Ag=sub('A','g');An=sub('A','n')
    if i.startswith('dc_bolt_'):
        expr=group(sub('F','Rd'),' = ',frac(group('2',sub('k','pega'),sub('k','calço'),'α',sub('A','b'),sub('f','ub')),g2))
    elif i=='dc_bearing_local_fin':
        expr=group(sub('F','Rd'),' = ',frac(group(sub('k','calço'),' min(1,2',sub('l','f'),'t',fu,'; 2,4',sub('d','b'),'t',fu,')'),g2))
    elif i.startswith('dc_bearing_'):
        expr=group(sub('F','Rd'),' = ',frac(group(sub('k','calço'),sub('n','t'),' min(1,2',sub('l','c'),'t',fu,'; 2,4',sub('d','b'),'t',fu,')'),g2))
    elif i.startswith('dc_block_'):
        expr=group('η = ',frac('Σ|Fx,i|',sub('R','N,bloco')),' + ',frac('Σ|Fy,i|',sub('R','V,bloco')),' ≤ 1')
    elif i.startswith('dc_yield_'):
        expr=group(sub('σ','eq'),' = ',radical(group(power(group('(',frac('|N|',Ag),' + ',frac('|M|',sub('W','g')),')')),' + 3',power(group('(',frac('1,5|V|',Ag),')')))),' ≤ ',frac(fy,g1))
    elif i.startswith('dc_net_'):
        expr=group('η = ',frac(group('max(0; ',frac('N',sub('A','e')),' + ',frac('|M|',sub('W','n')),')'),frac(fu,g2)),' + ',frac('|V|',frac(group('0,6',fu,An),g2)),' ≤ 1')
    elif i.startswith('dc_stability_'):
        expr=group('η = ',frac('|N|',sub('N','Rd')),' + ',frac('|M|',sub('M','Rd')),' + ',frac('|V|',sub('V','Rd')),' ≤ 1')
    elif i=='dc_stiffener':
        expr=group('η = ',frac('|H|s/4',sub('M','Rd')),' + ',frac('|H|/2',sub('V','Rd')),' ≤ 1')
    elif i.startswith('dc_weld_internal_'):
        # The internal three-edge group uses pointwise elastic stress, not a
        # uniform force divided by the length of an isolated weld.
        expr=group(sub('τ','max'),' = max ',radical(group(power(sub('τ','x')),' + ',power(sub('τ','y')))),
                   ' ≤ ',sub('f','w,Rd'),' = ',frac(group('0,6',sub('f','w')),sub('γ','w2')))
    elif i.startswith('dc_weld_'):
        expr=group(sub('F','Rd'),' = ',frac(group('2',frac('w',radical('2')),'L·0,6',sub('f','w')),sub('γ','w2')))
    elif i.startswith('dc_base_internal_'):
        expr=group(sub('σ','eq'),' = ',radical(group(
            power(group('(',frac(sub('q','n'),sub('t','nervura')),')')),' + 3',
            power(group('(',frac(sub('q','∥'),sub('t','nervura')),')')))),
            ' ≤ ',frac(fy,g1))
    elif i.startswith('dc_base_'):
        expr=group(sub('F','Rd'),' = L min(',frac(group('0,6',fy,'t'),g1),'; ',frac(group('0,6',fu,'t'),g2),')')
    else:
        expr=group(sub('V','Rd'),' = 2H',sub('t','w'),' min(',frac(group('0,6',fy),g1),'; ',frac(group('0,6',fu),g2),')')
    _math(doc,expr)
    if i.startswith('dc_block_'):
        _math(doc,group('R = ',frac(group(sub('n','t'),' min(0,6',fu,sub('A','nv'),' + 0,5',fu,sub('A','nt'),'; 0,6',fy,sub('A','gv'),' + 0,5',fu,sub('A','nt'),')'),g2)))

def create_report(c,r,detailed=False):
    # Recalculate from the canonical input: supplied results cannot mix snapshots.
    r=evaluate(c)
    if not r.checks or r.numeric_failures or any(x.severity=='error' for x in r.issues):raise ValueError('A geometria deve ser válida, possuir ações e cálculo numericamente válido para gerar a memória.')
    doc=Document();sec=doc.sections[0]
    sec.page_width=Inches(8.27);sec.page_height=Inches(11.69)
    sec.top_margin=sec.bottom_margin=Inches(.6);sec.left_margin=sec.right_margin=Inches(.65)
    for name in ('Normal','Title','Subtitle','Heading 1','Heading 2'):
        style=doc.styles[name];style.font.name='Arial';style.font.color.rgb=RGBColor(0,0,0)
    for style in doc.styles:
        for border in style.element.xpath('.//w:pBdr'):border.getparent().remove(border)
    normal=doc.styles['Normal'];normal.font.size=Pt(9.5);normal.paragraph_format.space_after=Pt(5)
    doc.styles['Title'].font.size=Pt(20);doc.styles['Heading 1'].font.size=Pt(12);doc.styles['Heading 2'].font.size=Pt(10)
    doc.core_properties.title='Ligação de viga à alma de coluna com duas talas'
    doc.core_properties.author='LRO Soluções de engenharia LTDA.'
    doc.add_paragraph('Ligação de viga à alma de coluna',style='Title')
    doc.add_paragraph('Duas talas parafusadas e nervura soldada',style='Subtitle')
    doc.add_paragraph(c.project)
    doc.add_paragraph(c.beam.name+' → '+c.support.name)
    p=doc.add_paragraph();p.add_run(r.status).bold=True
    p.add_run(' | Maior índice calculado: '+number(r.governing.ratio,3))
    doc.add_paragraph(r.coverage_note)
    if r.calculation_note:doc.add_paragraph(r.calculation_note)
    doc.add_picture(BytesIO(image_bytes(c)),width=Inches(6.95))
    doc.add_paragraph('As talas são independentes do conjunto soldado: cada grupo de parafusos transmite V e N integrais; cada tala recebe metade. A viga não encosta na coluna ou na nervura. Encontro ortogonal, com as peças centradas na altura da viga.')
    doc.add_paragraph('O desenho acompanha a geometria informada. É ilustrativo e não substitui o detalhamento de fabricação, a definição dos comprimentos dos parafusos ou a especificação de montagem.')
    doc.add_page_break()
    doc.add_paragraph('Dimensões e materiais',style='Heading 1')
    rows=[
        ('Viga apoiada',f"d={display_format(c.beam.d, 'g')}; bf={display_format(c.beam.bf, 'g')}; tw={display_format(c.beam.tw, 'g')}; tf={display_format(c.beam.tf, 'g')}",c.beam_steel),
        ('Coluna',f"d={display_format(c.support.d, 'g')}; bf={display_format(c.support.bf, 'g')}; tw={display_format(c.support.tw, 'g')}; tf={display_format(c.support.tf, 'g')}",c.support_steel),
        ('Nervura vertical',f"H={display_format(c.root_height, 'g')}; h={display_format(c.hp, 'g')}; L={display_value(number(c.fin_length))}; t={display_value(number(c.fin_t, 4))}",c.fin_steel),
        ('Duas talas iguais',f'{display_value(number(c.cover_length))} × {display_value(number(c.hp))} × {display_value(number(c.cover_t, 4))}',c.cover_steel),
        ('Quatro horizontais',f"b={display_value(number(c.projection))}; s={display_value(number(c.stiffener_span))}; t={display_value(number(c.stiffener_t, 4))}; c={display_format(c.corner_clip, 'g')}",c.stiffener_steel),
        ('Parafusos',f'2 grupos × {display_value(c.n)} unidades; Ø={display_value(number(c.db, 3))}; 2 planos de corte',c.bolt),
        ('Furos padrão',f'Ø={display_value(number(c.dh, 4))}; dedução líquida={display_value(number(c.dh_net, 4))}','Broca' if c.drilled else 'Acréscimo de 2 mm'),
        ('Afastamento viga–face da coluna (u + g)',display_format(c.beam_column_gap, 'g'),'mm'),
        ('Posições',f"g={display_format(c.gap, 'g')}; u={display_format(c.extension, 'g')}; p={display_format(c.pitch, 'g')}; e={display_format(c.edge_x, 'g')}; eᵥ={display_format(c.edge_v, 'g')}",'mm'),
        ('Soldas duplas',f"w nervura/alma={display_format(c.weld_web, 'g')}; nervura/horizontal={display_format(c.weld_fin_stiffener, 'g')}; horizontal/coluna={display_format(c.weld_stiffener_column, 'g')}",f"fw={display_format(c.fw, 'g')} MPa"),
        ('Calços simétricos',f'2 × {display_value(number(c.shim_each, 3))} no lado da {display_value(c.shim_side)}' if c.shim_each else f'Ajuste de montagem; diferença={display_value(number(c.thickness_difference, 3))}','Sem crédito resistente'),
    ]
    rows=[(a,decimal_text(b),d) for a,b,d in rows]
    table(doc,['Componente','Dimensões em mm','Material / critério'],rows,[1.25,3.55,2.15])
    steels=list(dict.fromkeys([c.beam_steel,c.support_steel,c.fin_steel,c.cover_steel,c.stiffener_steel]))
    doc.add_paragraph('Filetes por interface física',style='Heading 2')
    weld_rows=[]
    for j in weld_interfaces(c):
        ok=j['minimum']<=j['w']<=j['maximum'] and j['length']>=max(4*j['w'],40)
        weld_rows.append((j['name'],number(j['t_edge'])+' / '+number(j['t_other']),number(j['w'],4),number(j['minimum'])+' / '+number(j['maximum']),number(j['length']), 'Atende' if ok else 'Não atende ao detalhamento'))
    table(doc,['Junta','Espessuras mm','w mm','Mín. / máx. mm','L útil mm','Detalhamento'],weld_rows,[2.0,.85,.65,.9,.7,1.3])
    doc.add_paragraph('O mesmo filete horizontal/coluna é conferido separadamente na mesa e na alma, com suas espessuras e comprimentos reais. NBR 6.2.6.2 / Tabela 11. A insuficiência do tamanho mínimo é uma não conformidade de detalhamento; os índices de resistência são calculados independentemente.')
    doc.add_paragraph('Resistências características: '+'; '.join(f"{display_value(s)}: fy={display_format(STEELS[s].fy, 'g')} MPa, fu={display_format(STEELS[s].fu, 'g')} MPa" for s in steels)+'. E=200.000 MPa; γa1=1,10; γa2=γw2=1,35.')
    doc.add_paragraph('Ações e equilíbrio',style='Heading 1')
    if c.internal_fin_perforation:doc.add_paragraph('Equilíbrio do grupo elástico de soldas em três bordas, com gargantas ponderadas. As ações transmitidas são obtidas por integração do campo de tensões; o cálculo local das soldas é independente da transferência em membrana e da estabilidade da nervura perfurada, ainda pendentes, e não demonstra a capacidade dos receptores.')
    rows=[]
    for key,label in [('actual_actions','Entrada'),('actions','Conferência governante')]:
        a=r.geometry[key]
        rows.append((label,number(a['V']/KGF),number(a['N']/KGF),number(a['M']/(KGF*1000)),number(a['top']/KGF),number(a['bottom']/KGF)))
    table(doc,['Caso','V kgf','N kgf','M local kgf·m','Fx superior kgf' if c.internal_fin_perforation else 'H superior kgf','Fx inferior kgf' if c.internal_fin_perforation else 'H inferior kgf'],rows,[1.45,.9,.9,1.3,1.2,1.2])
    doc.add_paragraph('N positivo indica tração; negativo, compressão. Entradas já majoradas. A conferência de resistência mínima de 45 kN preserva a direção N/V, com fator '+number(r.minimum_factor,3)+'. O momento local deriva da excentricidade; não há momento externo de entrada.')
    _math(doc,group(sub('e','g'),' = e + g/2;   ',sub('M','g'),' = V',sub('e','g'),';   ',sub('M','col'),' = V(b + u + g/2)'))
    if c.internal_fin_perforation:
        doc.add_paragraph('Origem O na face da alma, a meia altura da nervura; x positivo para fora da coluna e y positivo para cima. V positivo atua em +y e o momento positivo é anti-horário. Os valores são ações transmitidas da nervura aos receptores; as reações dos apoios sobre a nervura têm sinais opostos. A borda superior está em y=+H/2. Fx superior e inferior são integrais das respectivas soldas, sem impor um binário isolado entre horizontais.')
        doc.add_paragraph('b é a projeção da mesa a partir da face da alma; H é a distância livre entre horizontais; e é a borda horizontal; g é a folga nervura–viga. O momento M local é referido a O. O momento global no eixo da coluna inclui também a distância da face ao eixo da alma e deve ser compatibilizado com o modelo da estrutura.')
        doc.add_paragraph('Grupo elástico de soldas em três bordas',style='Heading 1')
        doc.add_paragraph(INTERNAL_WELD_HYPOTHESIS)
        wg=r.geometry['actions']['weld_group']
        table(doc,['Borda','Início x; y mm','Fim x; y mm','L útil mm','w mm','a mm','Aw mm²'],weld_geometry_rows(wg),[1.45,1.2,1.2,.75,.65,.65,1.05])
        doc.add_paragraph('Aw já inclui os dois filetes de cada borda. Área total Aw='+number(wg['area_mm2'])+' mm²; centroide C=('+number(wg['centroid_x_mm'])+'; '+number(wg['centroid_y_mm'])+') mm; J='+number(wg['J_mm4'])+' mm⁴. A geometria do grupo é a mesma para a entrada e para a conferência mínima.')
        reaction_rows=[]
        for key,label in [('actual_actions','Entrada'),('actions','Conferência governante')]:
            group_data=r.geometry[key]['weld_group']
            reaction_rows.extend((label,*row) for row in weld_reaction_rows(group_data))
        table(doc,['Caso','Borda','Fx kgf','Fy kgf','Mo kgf·m'],reaction_rows,[1.5,1.8,1.15,1.15,1.35])
        doc.add_paragraph('Integrais por borda: ΣFx=N; ΣFy=V; ΣMo=M local. Mo inclui a variação das forças ao longo do cordão e é referido à origem O, não somente ao centroide de cada segmento. As forças de alma e horizontais não são somadas a uma segunda distribuição legada.')
        critical=wg['critical_point']
        doc.add_paragraph('Caso governante: Mc='+number(wg['moment_about_centroid_Nmm']/(KGF*1000))+' kgf·m, referido ao centroide C. Ponto crítico na borda '+WELD_EDGE_LABELS[critical['segment']].lower()+', em ('+number(critical['x_mm'])+'; '+number(critical['y_mm'])+') mm: τmáx='+number(critical['resultant_MPa'])+' MPa; fw,Rd='+number(wg['stress_resistance_MPa'])+' MPa; η='+number(wg['max_utilization'],3)+'. O resultado local não aprova o conjunto.')
        table(doc,['Borda','Ponto x; y mm','τx MPa','τy MPa','τresult. MPa','η'],weld_stress_rows(wg),[1.7,1.5,.9,.9,1.1,.55])
        doc.add_paragraph('τx e τy são componentes assinadas do campo vetorial equivalente do grupo soldado, não uma decomposição normal/cisalhante do tensor real da garganta. A resultante é comparada a 0,6fw/γw2 (Tabela 9). O campo é linear; a maior norma em cada cordão reto ocorre em um de seus extremos. O escoamento local da nervura adota tensão paralela à borda nula: é um critério suplementar condicionado, não um limite conservador demonstrado. Não qualifica ruptura, propagação pelos ligamentos ou os receptores.')
    else:
        _math(doc,group(sub('H','sup'),' = N/2 + ',frac(sub('M','col'),'H'),';   ',sub('H','inf'),' = N/2 − ',frac(sub('M','col'),'H')))
        doc.add_paragraph('b é a projeção da mesa medida da face da alma da coluna; H é a distância livre entre horizontais adotada como braço do binário; e é a borda horizontal; g é a folga nervura–viga. O momento global no eixo da coluna inclui também a distância da face ao eixo da alma. Esses efeitos devem ser compatibilizados com o modelo da estrutura.')
    doc.add_page_break()
    doc.add_paragraph('Quadro de verificações dos componentes',style='Heading 1')
    doc.add_paragraph('Índice η = solicitação/resistência, ou valor da interação. Limite: 1,00. Um resultado por seção física reúne os limites elástico, líquido e de estabilidade; os dois grupos de parafusos aparecem pela envoltória. Todos esses ramos e os dois lados são desenvolvidos abaixo, mesmo na memória compacta. “Atende” é exclusivamente o resultado local da linha; a quantidade de linhas não qualifica o nó.')
    rows=[]
    for row in r.summary_checks:
        sd,un=display(row.demand,row.unit);rd,_=display(row.resistance,row.unit)
        rows.append((row.name,sd,rd,un,number(row.ratio,3),row.outcome))
    table(doc,['Verificação','Solicitação','Resistência','Unid.','η','Resultado'],rows,[2.55,.9,.9,.5,.5,1.6] if c.internal_fin_perforation else [3.25,.85,.85,.6,.65,.75])
    if c.internal_fin_perforation:
        doc.add_paragraph('Contato/rasgamento direcional da nervura',style='Heading 2')
        a=r.geometry['actions'];local=internal_fin_bearing(c,a['V'],a['N'])
        hole_rows=[]
        for h in local['holes']:
            path=('Sem força' if h['demand']==0 else 'Teto de contato; transferência à solda pendente' if h['transfer_pending'] else h['contact_label'])
            hole_rows.append((str(h['hole']),number(h['fx']/KGF),number(h['fy']/KGF),number(h['lf_directional'],3) if h['lf_directional'] is not None else '—',path,number(h['resistance']/KGF),number(h['ratio'],3)))
        table(doc,['Furo','Fx kgf','Fy kgf','lf geom. mm','Primeiro encontro / critério','FRd kgf','η'],hole_rows,[.4,.8,.8,.8,2.45,.95,.75])
        doc.add_paragraph('Valores do caso governante, incluindo momento assinado. lf geom. é medido somente paralelamente à força, entre contornos reais; não é a menor distância em todas as direções. Para encontro com trecho soldado, lf geom. não é usado como borda livre: FRd fica limitado ao teto necessário. O quadro é local e não qualifica a nervura integral. Abaixo do teto necessário, exceder o critério direcional adotado exige revisão local, sem declarar por isso falha física demonstrada.')
    doc.add_paragraph('Caso governante: '+r.governing.case+'. As verificações da entrada original também são executadas. Como o modelo é homogêneo nas ações, a conferência mínima governa quando seu fator supera 1.')
    doc.add_page_break()
    doc.add_paragraph('Equações e substituições',style='Heading 1')
    doc.add_paragraph('Unidades nas substituições: N, mm e MPa. A tabela anterior converte forças para kgf. '+('Todas as verificações são desenvolvidas.' if detailed else 'Ambos os grupos de parafusos e todos os ramos de cada seção são desenvolvidos. Para contato, bloco, solda e metal-base mostra-se o item governante de cada grupo.'))
    if c.internal_fin_perforation:
        doc.add_paragraph('Campo elástico e integração do grupo soldado',style='Heading 2')
        internal_weld_equations(doc)
    cuts=[('Talas / faixa conectada da viga',c.group_e)]
    if not c.internal_fin_perforation:cuts.extend([('Nervura — aba livre',c.extension+c.gap/2),('Nervura — trecho interno',c.pin_x)])
    table(doc,['Corte físico','Braço real de V (mm)','Momento local'],[(label,number(arm,4),'|V| × braço') for label,arm in cuts],[3.5,1.5,1.95])
    if c.internal_fin_perforation:doc.add_paragraph('O contato/rasgamento da nervura é examinado por furo e pela direção de sua força. O ligamento é a menor distância paralela à força entre os contornos físicos, sem penalização pelo menor ligamento em todas as direções. Quando o primeiro contato é uma borda soldada, somente o teto necessário de esmagamento é conferido; a transferência nessa direção permanece pendente. O quadro de contato não inclui seções/blocos internos ou estabilidade. O cálculo independente do grupo de soldas e do escoamento local na linha da junta não elimina a pendência de transferência pela chapa até essas bordas nem qualifica os receptores.')
    doc.add_paragraph(('As envoltórias resistentes das faixas de talas e alma da viga limitam mecanismos separadamente; o grupo de soldas em três bordas tem um campo elástico compatível próprio. A transferência na nervura perfurada e a capacidade dos receptores permanecem pendentes.' if c.internal_fin_perforation else 'As envoltórias resistentes locais limitam mecanismos separadamente; não representam uma distribuição física simultânea única de todas as forças. O equilíbrio assinado da coluna está indicado na seção anterior. A solda horizontal/alma é uma envoltória adicional com H integral, sem redistribuir ou reduzir as demais demandas.'))
    selected=[]
    for prefix in ['dc_bolt_','dc_bearing_','dc_block_','dc_yield_','dc_net_','dc_stability_','dc_stiffener','dc_weld_','dc_base_']:
        family=[x for x in r.checks if x.id.startswith(prefix)]
        if family:
            selected.extend(family if detailed or prefix in ('dc_bolt_','dc_yield_','dc_net_','dc_stability_') else [max(family,key=lambda x:x.ratio)])
            if prefix=='dc_bearing_' and c.internal_fin_perforation:
                local_fin=next(x for x in family if x.id=='dc_bearing_local_fin')
                if local_fin not in selected:selected.append(local_fin)
    for row in selected:
        start=len(doc.paragraphs)
        doc.add_paragraph(row.name+' · η='+number(row.ratio,3),style='Heading 2')
        equation(doc,row)
        doc.add_paragraph(decimal_text(calculated_text(row.substitution)))
        doc.add_paragraph(calculated_text(row.variables, assignments_only=True))
        p=doc.add_paragraph(row.reference);p.paragraph_format.space_after=Pt(8)
        for run in p.runs:run.font.size=Pt(8)
        for p in doc.paragraphs[start:-1]:p.paragraph_format.keep_with_next=True
    doc.add_paragraph('Definição das variáveis e hipóteses',style='Heading 1')
    doc.add_paragraph('Ag, An e Ae: áreas bruta, líquida e efetiva; Wg e Wn: módulos elásticos bruto e líquido; Ab: área nominal do parafuso; fy, fu e fub: resistências do aço e do parafuso; db: diâmetro; lc: ligamento livre; nt: quantidade de chapas; α=0,45 com rosca e 0,56 sem rosca; kpega e kcalço: reduções por pega e enchimento; w: perna; L: comprimento útil da solda; χ: fator de instabilidade; K: fator de comprimento; NRd, MRd e VRd: resistências de cálculo.')
    doc.add_paragraph('O grupo elástico de parafusos usa Fx,i=N/n−Mg·yi/Σyi² e Fy,i=V/n. Para o bloco U axial: Agv=2et; Anv=2(e−dn/2)t; Ant=(n−1)(p−dn)t. Para o bloco L vertical: lv=ev+(n−1)p; Agv=lv·t; Anv=[lv−(n−0,5)dn]t; Ant=(e−dn/2)t. As áreas gv/nv/nt são, respectivamente, bruta ao corte, líquida ao corte e líquida à tração; dn é o diâmetro de dedução líquida. A soma de duas peças iguais é feita por nt=2.')
    doc.add_paragraph('Seções: Ag=nt·h·t; An=nt·(h−n·dn)t; Wg=nt·t·h²/6. Nas talas Ae=min(An;0,85Ag). Wn=nt·[t·h³/12−Σt(dn³/12+dn·yi²)]/(h/2). Nos trechos sem furos, n=0. As interações lineares e as faixas resistentes são hipóteses deste modelo, não uma equação normativa única para o nó completo.')
    doc.add_paragraph(COMPRESSION_NOTE)
    doc.add_paragraph('Compressão: Ne=π²EI/(KL)²; λ0=√(Agfy/Ne); χ=0,658^(λ0²) se λ0≤1,5 e 0,877/λ0² nos demais casos. Adota-se a curva inclusive para barras curtas. As chapas são idealizadas como barras chatas isoladas, Q=1, sem ganho por solidarização das talas. K=1 entre grupos das talas; '+('K=2 na faixa da alma da viga.' if c.internal_fin_perforation else 'K=2 nas faixas da nervura e da alma da viga.')+' Esses comprimentos pertencem à idealização isolada declarada; não demonstram o modo acoplado ou a contenção efetiva do conjunto.')
    doc.add_paragraph('Na flexão, o complemento AISC F11 usa λ=Lh/t² e Cb=1: Mn=Mp até 0,08E/fy; no trecho intermediário, Mn=min[Mp;(1,52−0,274λfy/E)My]; acima de 1,9E/fy, Mn=min[Mp;1,9E·Wg/λ]. MrD=Mn/γa1.'+(' A faixa horizontal é biapoiada entre mesas, com carga no centro e largura útil b−2c. Não se atribui ganho resistente ao par de horizontais oposto.' if not c.internal_fin_perforation else ' Aplicado somente às faixas locais retidas das talas e da alma da viga.'))
    for issue in r.issues:
        if issue.severity in ('pending','error','extrapolation','noncompliance'):doc.add_paragraph('Pendência: '+calculated_text(issue.text, assignments_only=True))
    doc.add_paragraph('Premissas: viga com contenção eficaz; juntas internas mesa–alma dos perfis soldados com penetração total e metal de adição compatível; ligação por contato, soldagem em oficina. '+('A resistência local das soldas em três bordas e o escoamento local na linha da junta são condicionados ao modelo elástico de nervura e apoios rígidos. A transferência na chapa perfurada, sua estabilidade, a ruptura do metal-base e a capacidade/rigidez dos horizontais e demais receptores não estão qualificadas.' if c.internal_fin_perforation else 'A resistência/rigidez de estabilização dos horizontais e suas soldas para forças fora do plano não está abrangida pela verificação de H no plano.')+' Análise global da coluna, atrito, fadiga, vibração e carregamento cíclico fora do escopo.')
    if c.notes:doc.add_paragraph('Observações do projeto: '+c.notes)
    doc.add_paragraph('Referências',style='Heading 1')
    for ref in REFERENCES:doc.add_paragraph(ref)
    doc.add_paragraph('Premissas adotadas',style='Heading 1')
    doc.add_paragraph('Modelo plano; contenção eficaz da viga; juntas internas dos perfis soldados de penetração total; ausência de ações fora do plano e de efeitos de fadiga, vibração ou carregamento cíclico.')
    doc.add_paragraph(ASSEMBLY_NOTE+' A análise global dos membros é responsabilidade separada do projeto da estrutura e não encerra as qualificações locais acima.')
    for issue in r.issues:
        if issue.severity=='interference':doc.add_paragraph('Aviso de montagem: '+calculated_text(issue.text, assignments_only=True))
        elif issue.severity in ('excluded','extrapolation','noncompliance') and issue.text!=ASSEMBLY_NOTE:doc.add_paragraph(calculated_text(issue.text, assignments_only=True)+' ['+issue.reference+']')
    doc.add_paragraph(BRAND)
    p=doc.add_paragraph('LRO Ligações '+PACKAGE_ID+' · ');hyperlink(p,'LinkedIn — Lucas Oliveira',LINK)
    out=BytesIO();doc.save(out);return out.getvalue()
