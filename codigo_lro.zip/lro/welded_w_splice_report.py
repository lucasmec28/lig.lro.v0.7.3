"""Engineer-facing Portuguese record of the current full-CJP W splice input.

Concise mode retains every case and component envelope, including exact ties.
Detailed mode additionally records every primitive check and its full witness.
Both entry points re-evaluate the input, never trust a caller-supplied result.
"""
from .display_precision import display_format
from dataclasses import asdict, fields
from io import BytesIO
from math import isfinite

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor
import matplotlib.pyplot as plt
from matplotlib.transforms import Bbox

from .welded_w_splice import COMPONENT_VERSION, DECLARATIONS, EXCLUSIONS, SCOPE
from .welded_w_splice_drawing import STATUS, figure, input_fingerprint, validated_result
from .welded_w_splice_presentation import component_label, governing_description, physical_envelopes
from .models import STEELS
from .report import BRAND, _math, frac, group, power, radical, table

LABELS = {
    'project': 'Projeto', 'orientation': 'Orientação de apresentação',
    'profile_name': 'Perfil A', 'profile_b_name': 'Perfil B',
    'profile_source': 'Fonte das dimensões', 'profile_kind': 'Tipo de perfil',
    'd': 'Altura total d em mm', 'bf': 'Largura da mesa bf em mm',
    'tf': 'Espessura da mesa tf em mm', 'tw': 'Espessura da alma tw em mm',
    'root_radius': 'Raio de raiz em mm', 'clear_web_height': 'Altura livre real entre raízes em mm',
    'steel_a': 'Aço do membro A', 'steel_b': 'Aço do membro B',
    'offset_y': 'Desalinhamento y em mm', 'offset_z': 'Desalinhamento z em mm',
    'rotation': 'Rotação relativa informada', 'depth_mismatch': 'Diferença de altura em mm',
    'flange_mismatch': 'Diferença de mesa em mm', 'web_mismatch': 'Diferença de alma em mm',
    'weld_type': 'Tipo de solda', 'flange_weld_length': 'Comprimento CJP de cada mesa em mm',
    'flange_weld_throat': 'Garganta CJP nas mesas em mm',
    'web_weld_length': 'Comprimento CJP na alma em mm',
    'web_weld_throat': 'Garganta CJP na alma em mm',
    'access_detail': 'Família de curva de acesso', 'access_h0': 'Altura da abertura no plano da junta em mm',
    'access_hmax_a': 'Altura máxima da abertura A em mm',
    'access_hmax_b': 'Altura máxima da abertura B em mm',
    'access_length_a': 'Comprimento da abertura A em mm',
    'access_length_b': 'Comprimento da abertura B em mm',
    'access_radius_a': 'Raio da abertura A em mm',
    'access_radius_b': 'Raio da abertura B em mm',
    'root_clearance': 'Folga de acesso até a raiz em mm',
    'process': 'Processo de soldagem', 'consumable': 'Consumível exato',
    'procedure_id': 'Identificação do procedimento WPS',
    'material_certified': 'Material certificado',
    'compatibility_declared': 'Compatibilidade de material e consumível declarada',
    'procedure_qualified': 'Procedimento qualificado',
    'inspection_plan_declared': 'Plano de inspeção declarado',
    'actual_geometry_verified': 'Geometria real verificada',
    'cut_quality_verified': 'Qualidade e acabamento do corte verificados',
    'root_access_verified': 'Acesso à raiz verificado',
    'alignment_verified': 'Alinhamento e tolerâncias verificados',
    'integrity_included': 'Ações de integridade contempladas',
    'minimum_force': 'Critério de força mínima de 45 kN habilitado',
    'static': 'Ações estáticas', 'normal_combination': 'Combinação última normal',
    'fatigue': 'Fadiga exigida', 'seismic': 'Qualificação sísmica exigida',
    'impact': 'Impacto exigido', 'notes': 'Observações do projeto',
}


def _value(value):
    if isinstance(value, bool): return 'sim' if value else 'não'
    if value is None: return 'não disponível'
    if isinstance(value, float):
        return display_format(value, '.15g').replace('.', ',') if isfinite(value) else str(value)
    if isinstance(value, dict):
        return '; '.join(str(k) + '=' + _value(v) for k, v in value.items())
    if isinstance(value, (list, tuple)):
        return '; '.join(_value(v) for v in value) or 'nenhum'
    return str(value) if str(value) else 'não informado'


def _n(value, decimals=4, divisor=1):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not isfinite(value):
        return 'não disponível'
    return display_format(value / divisor, '.' + str(decimals) + 'f').replace('.', ',')


def _flatten(value, prefix=''):
    if isinstance(value, dict):
        for key, child in value.items():
            yield from _flatten(child, prefix + '.' + str(key) if prefix else str(key))
    elif isinstance(value, (list, tuple)):
        if not value: yield prefix, 'nenhum'
        for i, child in enumerate(value):
            yield from _flatten(child, prefix + '[' + str(i) + ']')
    else:
        yield prefix, _value(value)


def _tab(doc, headers, rows, widths=None, size=8):
    widths = widths or [6.97 / len(headers)] * len(headers)
    out = table(doc, headers, rows, widths)
    for row in out.rows:
        for j, cell in enumerate(row.cells):
            for p in cell.paragraphs:
                if j == 0: p.alignment = WD_ALIGN_PARAGRAPH.LEFT
                for run in p.runs: run.font.size = Pt(size)
    return out


def _heading(doc, title, level=1):
    return doc.add_paragraph(title, style='Heading ' + str(level))


def _issues(doc, r):
    _heading(doc, 'Pendências e condições de uso')
    issues = r.get('issues') or []
    if not issues:
        doc.add_paragraph('Não há ocorrências registradas nesta avaliação. A conclusão continua limitada ao domínio local declarado.')
    for item in issues:
        if isinstance(item, dict):
            p = doc.add_paragraph()
            p.add_run({'pending': 'Pendente', 'unsupported_scope': 'Fora do domínio', 'error': 'Erro', 'detail': 'Detalhe'}.get(item.get('severity'), str(item.get('severity', 'Ocorrência'))) + ': ').bold = True
            message = str(item.get('message', item.get('text', item.get('id', ''))))
            prefix, colon, suffix = message.partition(':')
            if colon and prefix in LABELS:
                message = LABELS[prefix] + colon + suffix
            p.add_run(message)
            if item.get('reference'): p.add_run(' Referência: ' + str(item['reference']) + '.')
        else:
            doc.add_paragraph(str(item))


def _inputs(doc, c):
    _heading(doc, 'Dimensões materiais e declarações')
    doc.add_paragraph('Unidades canônicas: N, mm e MPa; momentos em N mm. Os campos abaixo preservam os valores informados. Nenhum arredondamento de exibição realimenta o motor.')
    declaration_names = set(DECLARATIONS) | {'integrity_included'}
    dimensions, declarations = [], []
    for field in fields(c):
        key = field.name
        if key in ('N', 'M', 'V', 'torsion', 'weak_M', 'transverse_V', 'load_cases'):
            continue
        row = (LABELS.get(key, key), _value(getattr(c, key)))
        (declarations if key in declaration_names else dimensions).append(row)
    _tab(doc, ['Dado informado', 'Valor'], dimensions, [3.65, 3.32])
    _heading(doc, 'Declarações do responsável', 2)
    _tab(doc, ['Condição declarada', 'Confirmada'], declarations, [5.47, 1.5])
    doc.add_paragraph('Uma declaração registra a entrada do responsável e não certifica execução, inspeção ou conformidade real. WPS, compatibilidade, acesso e alinhamento pendentes bloqueiam a conclusão favorável mesmo com baixas utilizações.')
    materials = []
    for name in dict.fromkeys((c.steel_a, c.steel_b)):
        steel = STEELS.get(name)
        materials.append((name, _n(steel.fy, 1) if steel else 'não cadastrado',
                          _n(steel.fu, 1) if steel else 'não cadastrado'))
    _tab(doc, ['Aço de base', 'fy MPa', 'fu MPa'], materials, [3.97, 1.5, 1.5])
    doc.add_paragraph('γa1 = 1,10; γa2 = 1,35. Governa o menor valor aplicável entre os dois materiais conectados. Não se usa resistência de filete 0,6 fuw como resistência de uma CJP compatível.')
    _heading(doc, 'Premissas fixas', 2)
    _tab(doc, ['Premissa nativa', 'Valor'], list(_flatten(c.fixed_assumptions)), [4.27, 2.7])


def _loads(doc, c, r):
    _heading(doc, 'Todos os casos de carga')
    doc.add_paragraph('As ações já são de cálculo. N positivo traciona; M positivo traciona y positivo; Na face +x do membro A, V positivo atua em −y; o transporte é M(x)=M(0)−Vx. A orientação viga ou pilar não modifica as equações nem zera ações. Casos reais e suplementares são preservados separadamente; não se cria um momento mínimo independente.')
    cases = r.get('cases') or []
    _tab(doc, ['Caso e origem', 'Descrição', 'N kN', 'M kN m', 'V kN'],
         [(str(x.get('id')) + '\n' + str(x.get('kind')), str(x.get('label', '')),
           _n(x.get('N'), 3, 1000), _n(x.get('M'), 3, 1e6), _n(x.get('V'), 3, 1000))
          for x in cases], [1.8, 2.05, 1.04, 1.04, 1.04])
    unsupported = [(str(x.get('id')), key, _value(x.get(key)))
                   for x in cases for key in ('torsion', 'weak_M', 'transverse_V')
                   if x.get(key) not in (None, 0, 0.0)]
    if unsupported:
        _tab(doc, ['Caso', 'Ação fora do domínio', 'Valor canônico'], unsupported, [2.2, 2.57, 2.2])
    if not cases:
        doc.add_paragraph('Nenhum caso resistente foi gerado. Ações da entrada: N=' + _value(c.N) +
                          ' N; M=' + _value(c.M) + ' N mm; V=' + _value(c.V) + ' N.')
    doc.add_paragraph('O critério de 45 kN e a consideração de integridade seguem a política explicitamente registrada no motor. Os casos suplementares não substituem a combinação real nem comprovam ações globais ausentes.')


def _method(doc, r):
    _heading(doc, 'Método e seções efetivas')
    doc.add_paragraph('O grupo CJP usa os retângulos efetivamente soldados das duas mesas e da alma remanescente. As aberturas de acesso, filetes de raiz, backing e peças provisórias não recebem crédito de área ou inércia. As inércias próprias das mesas são mantidas.')
    _math(doc, group('σ(y) = ', frac('N', 'Aew'), ' + ', frac('M y', 'Ix'),
                     ';   τgrupo = ', frac('|V|', 'Aew')))
    _math(doc, group('|σ| ≤ ', frac('fy', 'γa1'), ';   |τ| ≤ ', frac('0,60 fy', 'γa1'),
                     ';   σeq = ', radical(group(power('σ'), ' + 3 ', power('τ'))),
                     ' ≤ ', frac('fy', 'γa1')))
    doc.add_paragraph('O último critério é a Eq. 10.27 de Fakury, Castro e Silva e Caldas, aplicada com normal e cisalhamento coincidentes no mesmo ponto. Não é uma equação atribuída à Tabela 9 da NBR. As tensões são nominais do grupo elástico; não representam picos físicos no contorno dos furos.')
    _math(doc, group('VRd,alma = min(', frac('0,60 fy Agv', 'γa1'), '; ',
                     frac('0,60 fu Anv', 'γa2'), ') ≥ |Vintegral|'))
    doc.add_paragraph('A alma receptora resiste ao V integral. A fração de cortante atribuída à solda da alma pelo grupo elástico não reduz essa demanda. Os membros A e B são caminhos em série: resistências não são somadas. Nas seções afastadas da junta, o momento é transportado com o sinal de V e a posição do corte.')
    doc.add_paragraph('A verificação receptora usa a área e a inércia mínimas reais no domínio longitudinal das aberturas e o envelope de momento nesse domínio. Esse limite nominal conservador não equivale a uma solução de concentração de tensões junto ao furo, nem substitui a verificação dos membros e do sistema.')
    geometry = r.get('geometry') or {}
    if geometry.get('weld_mismatches'):
        _heading(doc, 'Incompatibilidade da solda declarada', 2)
        doc.add_paragraph('Comprimentos ou gargantas declarados não correspondem à CJP completa da geometria real. Não há cálculo de resistência nessa condição; as propriedades do grupo exigido são apenas referência geométrica e não capacidade desta entrada.')
        _tab(doc, ['Campo', 'Declarado', 'Exigido', 'Unidade'],
             [(LABELS.get(x.get('field'), x.get('field')), _value(x.get('declared')),
               _value(x.get('required')), str(x.get('unit', ''))) for x in geometry['weld_mismatches']],
             [3.47, 1.25, 1.25, 1.0])
    keys = ('d', 'bf', 'tf', 'tw', 'h_clear', 'H0', 'Aew', 'Ix', 'Iy', 'Aw')
    names = {'h_clear': 'Altura livre nominal em mm', 'H0': 'Altura da abertura na junta em mm',
             'Aew': 'Área efetiva CJP em mm²', 'Ix': 'Inércia Ix do grupo em mm⁴',
             'Iy': 'Inércia Iy do grupo em mm⁴', 'Aw': 'Área da alma na junta em mm²'}
    rows = [(names.get(k, k + ' em mm'), _value(geometry[k])) for k in keys if k in geometry]
    if rows: _tab(doc, ['Propriedade calculada', 'Valor'], rows, [4.1, 2.87])
    patches = geometry.get('patches') or []
    if patches:
        _tab(doc, ['Parcela efetiva', 'Área mm²', 'y mínimo mm', 'y máximo mm', 'Ix mm⁴'],
             [(component_label(x.get('name')), _n(x.get('area'), 3), _n(x.get('y_min'), 3),
               _n(x.get('y_max'), 3), _n(x.get('Ix'), 3)) for x in patches],
             [1.67, 1.22, 1.22, 1.22, 1.64])
    for key, label in (('receiver_a', 'Membro receptor A'), ('receiver_b', 'Membro receptor B')):
        if geometry.get(key):
            _heading(doc, label, 2)
            _tab(doc, ['Propriedade do corte reduzido', 'Valor'],
                 list(_flatten({k: v for k, v in geometry[key].items()
                                if k not in ('opening_outline', 'patches', 'curve', 'envelope')})), [3.6, 3.37])
            curve = geometry[key].get('curve') or {}
            doc.add_paragraph('Curva exata: círculo de centro ' + _value(curve.get('center')) +
                              '; tangência superior ' + _value(curve.get('upper_tangent')) +
                              '; tangência inferior ' + _value(curve.get('lower_tangent')) +
                              '; inclinações ' + _value(curve.get('upper_slope')) + ' e ' +
                              _value(curve.get('lower_slope')) + '. Os pontos do arco são amostras de representação dessa curva analítica.')
    if geometry.get('checks'):
        _heading(doc, 'Critérios geométricos', 2)
        _tab(doc, ['Critério', 'Testemunho'], [(str(x.get('id', '')), _value(x))
                                             for x in geometry['checks']], [1.7, 5.27])


def _envelopes(doc, r):
    _heading(doc, 'Envelopes por componente e mecanismo')
    envelopes = physical_envelopes(r)
    if not envelopes:
        doc.add_paragraph('Sem verificações resistentes disponíveis. Nenhuma capacidade favorável foi presumida.')
        return
    doc.add_paragraph('Cada linha reúne somente o mesmo componente físico e mecanismo. η real considera os casos reais; η total inclui suplementares. Todos os governantes empatados estão registrados após a tabela. Os valores parciais não removem pendências materiais ou de detalhamento.')
    _tab(doc, ['Componente e mecanismo', 'η real', 'η total', 'Sd / Rd governante', 'Estado numérico'],
         [(x['component_label'] + '\n' + x['mechanism_label'], _n(x['actual_utilization']),
           _n(x['utilization']),
           _n(x['governing'][0].get('demand'), 3) + ' / ' + _n(x['governing'][0].get('resistance'), 3) + '\n' + str(x['governing'][0].get('unit', '')),
           x['status']) for x in envelopes], [3.04, .67, .67, 1.52, 1.07])
    _heading(doc, 'Governantes e empates preservados', 2)
    for envelope in envelopes:
        p = doc.add_paragraph()
        p.add_run(envelope['component_label'] + ' · ' + envelope['mechanism_label'] + '. ').bold = True
        actual_ids = set(x.get('id') for x in envelope['actual_governing'])
        total_ids = set(x.get('id') for x in envelope['governing'])
        if actual_ids == total_ids:
            p.add_run('Real e total: ' + ' | '.join(governing_description(x) for x in envelope['governing']))
        else:
            p.add_run('Real: ' + (' | '.join(governing_description(x) for x in envelope['actual_governing']) or 'não avaliado') +
                      '. Total: ' + ' | '.join(governing_description(x) for x in envelope['governing']))
        for run in p.runs: run.font.size = Pt(8)


def _audit(doc, r):
    _heading(doc, 'Domínio local das seções')
    eligibility = r.get('local_section_eligibility') or {}
    if eligibility:
        _tab(doc, ['Condição de elegibilidade', 'Valor'], list(_flatten(eligibility)), [3.6, 3.37])
    doc.add_paragraph('A verificação da Tabela 4 é aplicada somente quando há N de compressão. O domínio inicial de compressão é limitado à seção não esbelta; isso não é uma classificação de flexão compacta. Na flexão pura, as verificações de classificação e estabilidade do membro permanecem externas. O limite curto de abertura L ≤ max(45 mm; 1,5 tw + 5 mm; 2 R + 5 mm) delimita esta primeira implementação e não é um máximo prescrito pela NBR.')
    _heading(doc, 'Equilíbrio e material receptor')
    rows = []
    for case in r.get('group_cases') or []:
        equilibrium = case.get('equilibrium') or {}
        integrated = equilibrium.get('integrated') or {}
        residual = equilibrium.get('residual') or {}
        rows.append((case.get('case_id'), _n(integrated.get('N'), 3, 1000),
                     _n(integrated.get('M'), 3, 1e6), _n(integrated.get('V'), 3, 1000),
                     _value(residual), 'sim' if equilibrium.get('verified') else 'não'))
    if rows:
        _tab(doc, ['Caso', 'N int kN', 'M int kN m', 'V int kN', 'Resíduos N e N mm', 'Equilíbrio'],
             rows, [1.25, .9, .95, .9, 2.12, .85])
    doc.add_paragraph('As integrações recuperam as ações assinadas na junta; resíduos e tolerâncias são registros do motor. O limite nominal receptor é um envelope conservador, não um segundo campo de equilíbrio nem uma tensão física de pico na abertura.')
    receiver_rows = []
    for case in r.get('receiver_cases') or []:
        values = case.get('signed_M_endpoints') or []
        dominance = case.get('rupture_dominance') or {}
        receiver_rows.append((str(case.get('case_id')) + ' / ' + str(case.get('side')),
                              '; '.join(_n(x, 3, 1e6) for x in values),
                              _n(case.get('M_bound'), 3, 1e6),
                              _n(case.get('full_web_shear_utilization')),
                              'sim' if dominance.get('yield_dominates') else 'não'))
    if receiver_rows:
        _tab(doc, ['Caso e membro', 'M assinado nas extremidades kN m', '|M| limite kN m', 'η alma V integral', 'Escoamento domina ruptura'],
             receiver_rows, [1.3, 1.85, 1.22, 1.25, 1.35])
    doc.add_paragraph('A dominância usa as mesmas áreas reais Ag, An e Ae: compara fy/γa1 com fu/γa2 e as resistências de cisalhamento. Não se importa o limite 0,85 Ag de uma família parafusada. Se a ruptura não for limitada pelo escoamento, a condição correspondente permanece explícita no motor.')


def _details(doc, r):
    from collections import OrderedDict
    _heading(doc, 'Verificações completas e testemunhos')
    doc.add_paragraph('Cada verificação primitiva é preservada. Testemunhos idênticos de um mesmo componente e caso são registrados uma vez e valem para todas as linhas da tabela imediatamente anterior. Não há união entre casos ou componentes distintos.')
    groups = OrderedDict()
    for row in r.get('checks') or []:
        groups.setdefault((row.get('case_id'), row.get('component')), []).append(row)
    standard = {'id', 'label', 'component', 'mechanism', 'case_id', 'demand',
                'resistance', 'utilization', 'status', 'unit', 'reference'}
    for (case_id, component), members in groups.items():
        _heading(doc, component_label(component.removesuffix('_min').removesuffix('_max')) + ' caso ' + str(case_id), 2)
        _tab(doc, ['Verificação e ID', 'Sd', 'Rd', 'Unidade', 'η', 'Estado'],
             [(str(row.get('label')) + '\n' + str(row.get('id')), _n(row.get('demand'), 8),
               _n(row.get('resistance'), 8), str(row.get('unit', '')),
               _n(row.get('utilization'), 8), str(row.get('status', ''))) for row in members],
             [2.4, 1.2, 1.2, .57, 1.0, .6], 7.5)
        references = list(dict.fromkeys(str(row.get('reference', 'não informada')) for row in members))
        doc.add_paragraph('Referência: ' + '; '.join(references))
        witnesses = [{k: v for k, v in row.items() if k not in standard} for row in members]
        shared = all(x == witnesses[0] for x in witnesses)
        for index, witness in enumerate(witnesses[:1] if shared else witnesses):
            if not shared: doc.add_paragraph('Testemunho de ' + str(members[index].get('id')))
            _tab(doc, ['Testemunho físico e numérico', 'Valor'], list(_flatten(witness)), [3.6, 3.37], 7.7)
    _heading(doc, 'Campos assinados e resultantes por região', 2)
    for case in r.get('group_cases') or []:
        doc.add_paragraph('Caso ' + str(case.get('case_id')))
        _tab(doc, ['Ponto', 'y mm', 'σ MPa', 'τ MPa', 'σeq MPa', 'η'],
             [(x.get('point'), _value(x.get('y')), _n(x.get('sigma'), 6), _n(x.get('tau'), 6),
               _n(x.get('equivalent'), 6), _n(x.get('utilization'), 6)) for x in case.get('stresses') or []],
             [2.0, .77, 1.1, 1.1, 1.1, .9], 7.5)
        _tab(doc, ['Região', 'N em N', 'M em N mm', 'V em N'],
             [(x.get('patch'), _value(x.get('N')), _value(x.get('M')), _value(x.get('V')))
              for x in case.get('patch_resultants') or []], [1.27, 1.9, 1.9, 1.9], 7.5)
        _tab(doc, ['Equilíbrio e tolerância', 'Valor'], list(_flatten(case.get('equilibrium') or {})), [3.6, 3.37], 7.7)
    _heading(doc, 'Testemunhos receptores completos', 2)
    for case in r.get('receiver_cases') or []:
        doc.add_paragraph('Caso ' + str(case.get('case_id')) + '; membro ' + str(case.get('side')))
        _tab(doc, ['Grandeza nominal ou dominância', 'Valor'], list(_flatten(case)), [3.6, 3.37], 7.7)
    other = {k: r[k] for k in ('load_model', 'minimum_action_basis', 'adjacent_web', 'materials', 'local_section_eligibility') if k in r}
    if other:
        _heading(doc, 'Rastreabilidade adicional do motor', 2)
        _tab(doc, ['Campo', 'Valor'], list(_flatten(other)), [3.6, 3.37], 7.7)


def _drawing(doc, c):
    doc.add_page_break()
    _heading(doc, 'Geometria proporcional da entrada atual')
    # Crop only annotation/case repetition for this Word figure; the complete
    # signed cases and declarations already have their own readable tables.
    fig = figure(c)
    try:
        height = fig.get_figheight()
        out = BytesIO()
        fig.savefig(out, format='png', dpi=170, facecolor='white',
                    bbox_inches=Bbox([[0, height - fig._welded_splice_drawing_height], [14, height]]))
        p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.add_run().add_picture(BytesIO(out.getvalue()), width=Inches(6.97))
    finally:
        plt.close(fig)
    doc.add_paragraph('A vista longitudinal muda apenas a orientação de apresentação. As quatro aberturas são espelhamentos das curvas reais de A e B. O vermelho identifica os comprimentos e gargantas declarados. Se forem incompatíveis com a CJP completa, a divergência permanece visível e não há cálculo de resistência. Dimensões e declarações completas constam nas tabelas deste documento.')


def create_report(c, result=None, detailed=False):
    r = validated_result(c, result)
    doc = Document()
    sec = doc.sections[0]
    sec.page_width = Inches(8.27); sec.page_height = Inches(11.69)
    sec.top_margin = sec.bottom_margin = Inches(.55)
    sec.left_margin = sec.right_margin = Inches(.65)
    normal = doc.styles['Normal']; normal.font.name = 'Calibri'; normal.font.size = Pt(9.5)
    normal.paragraph_format.space_after = Pt(5)
    for name, size in (('Title', 21), ('Subtitle', 11), ('Heading 1', 13), ('Heading 2', 10.5)):
        style = doc.styles[name]; style.font.name = 'Calibri'; style.font.size = Pt(size)
        style.font.color.rgb = RGBColor(0, 0, 0); style.font.underline = False
        style.paragraph_format.space_before = Pt(10 if name == 'Heading 1' else 5)
        style.paragraph_format.space_after = Pt(4)
        for border in list(style.element.iter(qn('w:pBdr'))): border.getparent().remove(border)
    doc.add_paragraph('Emenda soldada CJP de perfis W', style='Title')
    doc.add_paragraph('Memória de cálculo local ' + ('detalhada' if detailed else 'resumida'), style='Subtitle')
    p = doc.add_paragraph(); p.add_run(STATUS.get(r.get('status'), str(r.get('status')))).bold = True
    doc.add_paragraph('Projeto: ' + c.project)
    doc.add_paragraph(SCOPE)
    doc.add_paragraph('Esta avaliação não libera fabricação nem aprova o membro ou sistema estrutural completo. Falhas e pendências continuam vinculadas à entrada atual, mesmo quando uma verificação numérica isolada atende.')
    doc.add_paragraph('Versão: ' + COMPONENT_VERSION + '. Entradas SHA-256: ' + input_fingerprint(c))
    summary = r.get('summary') or {}
    rows = [('Estado do motor', str(r.get('status'))),
            ('Atendimento local declarado pelo motor', 'sim' if r.get('global_pass') is True else 'não'),
            ('Número de casos preservados', str(len(r.get('cases') or []))),
            ('Número de verificações primitivas', str(len(r.get('checks') or [])))]
    rows.extend(({'complete_checks': 'Verificações numéricas completas', 'utilization': 'Maior utilização total', 'actual_utilization': 'Maior utilização real'}.get(k, k), _value(v))
                for k, v in summary.items() if k in ('complete_checks', 'utilization', 'actual_utilization'))
    _tab(doc, ['Resumo', 'Resultado'], rows, [3.65, 3.32])
    _issues(doc, r)
    _loads(doc, c, r)
    _envelopes(doc, r)
    _drawing(doc, c)
    _inputs(doc, c)
    _method(doc, r)
    _audit(doc, r)
    if detailed:
        _details(doc, r)
        _heading(doc, 'Resumo completo do motor', 2)
        _tab(doc, ['Campo', 'Valor'], list(_flatten(summary)), [3.6, 3.37])
    _heading(doc, 'Referências e limites')
    doc.add_paragraph('ABNT NBR 8800:2024 com Errata 1:2025: 6.1.1 a 6.1.5, equilíbrio e ações; 6.1.13 e 12.2.1.2 com Figura 25, aberturas de acesso; 6.2.2.1, área e garganta CJP; 6.2.4 e Tabela 8, compatibilidade; Tabela 9, metal base de CJP; 6.5.3 a 6.5.6, material conectado. Os critérios vigentes de materiais e detalhe prevalecem sobre exemplos históricos.')
    doc.add_paragraph('Fakury, Castro e Silva e Caldas, Dimensionamento de elementos estruturais de aço e mistos de aço e concreto, parte 4, páginas 275 a 277, equações 10.19 a 10.27: campo elástico nominal de grupo CJP e interação suplementar. A raiz quadrada da Eq. 10.27 é preservada.')
    doc.add_paragraph('AISC Design Guide 21, Miller, 2006, seções 3.3.3, 3.9.2 e 3.12.1: contexto técnico de CJP e acesso. Manual Gerdau de ligações, páginas 189 a 194: precedente de emendas soldadas; não é fonte de capacidade N/M/V desta família. Nenhum coeficiente resistente histórico foi importado.')
    for text in EXCLUSIONS: doc.add_paragraph(text, style='List Bullet')
    _heading(doc, 'Conclusão')
    doc.add_paragraph(('As verificações locais implementadas atendem no domínio declarado pelo motor.'
                       if r.get('global_pass') is True else
                       'A entrada atual permanece sem conclusão favorável completa. Resolver as falhas e pendências registradas antes de usar o resultado como verificação local.'))
    doc.add_paragraph('Confirmar ações de projeto, geometria real, WPS e inspeção. A conclusão não inclui picos físicos nas aberturas, estabilidade global, montagem ou qualificação de um detalhe não padronizado.')
    doc.add_paragraph(BRAND)
    doc.core_properties.title = 'Emenda soldada CJP de perfis W'
    doc.core_properties.subject = 'Memória local ' + COMPONENT_VERSION
    out = BytesIO(); doc.save(out)
    return out.getvalue()
