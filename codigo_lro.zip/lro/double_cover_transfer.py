"""Concomitant alternative transfer models; never a rib/receiver approval."""
import math
from .double_cover_beam import evaluate_preset_beam
from .receiver_weld_group import receiver_weld_group
from .local_checks import elastic_group
from .models import STEELS

LABELS={'three_edge':'Grupo rígido de três bordas','beam_eb':'Barra bi-engastada — Euler–Bernoulli','beam_timoshenko':'Barra bi-engastada — sensibilidade ao cisalhamento'}
ASSUMPTIONS=('Envoltória da maior utilização por solda entre campos completos: grupo rígido de três bordas e barra vertical bi-engastada, com e sem deformação de cisalhamento. '
 'Na barra, os horizontais impedem as translações e a rotação no plano; a solda vertical não recebe reação primária no plano. '
 'O modelo Timoshenko usa seção bruta uniforme, ν=0,30 e κ=5/6 como sensibilidade. A rigidez real das peças permanece uma hipótese. '
 'Não se somam capacidades, não se escolhe o caminho mais favorável e não se combinam máximos independentes de Fx, Fy e M. '
 'A contenção lateral da borda junto à alma não é convertida em trava torcional nem dispensa FLT.')
LIMITATIONS=[
 'Nervura perfurada: N/Q/M e propriedades líquidas são informativos; interação líquida, ligamentos, blocos e estabilidade/FLT ainda não qualificados.',
 'Horizontais: a força Fy é normal ao plano e Mz também solicita torção da faixa entre mesas; resistência da chapa, metal-base e rigidez de engaste permanecem pendentes.',
 'Receptores da coluna: as forças e momentos por borda são rastreados; capacidade da alma/mesas e estabilidade local não são demonstradas pelo grupo de soldas.',
 'A envoltória destas hipóteses não é prova de que todas as distribuições reais possíveis estejam cobertas.']

def transfer_envelope(c,V,N,three_group,case=''):
    if c.extension != 0:
        return dict(status='outside_domain',assumptions=ASSUMPTIONS,limitations=['A barra retangular requer nervura sem extensão; geometria escalonada não é extrapolada.'],models=[],receiver_groups={},weld_envelopes=[])
    forces=elastic_group(c.n,c.pitch,1,0,V,N,V*c.group_e)
    beams={id:evaluate_preset_beam(c,forces,shear_flexible=flex) for id,flex in [('beam_eb',False),('beam_timoshenko',True)]}
    edge={s['id']:s for s in three_group['segments']}
    models=[dict(id='three_edge',label=LABELS['three_edge'],beam=None)]+[dict(id=k,label=LABELS[k],beam=v) for k,v in beams.items()]
    actions={'three_edge':{level:dict(Fx=edge[level]['integrated_Fx_N'],Fy=edge[level]['integrated_Fy_N'],Mz=edge[level]['local_couple_Nmm']) for level in ('top','bottom')}}
    welds={'three_edge':{level:edge[level] for level in ('top','bottom')}}
    for key,beam in beams.items():
        actions[key]={};welds[key]={}
        for w in beam['end_weld_groups']:
            level=w['id'];actions[key][level]=w['receiver_action'];welds[key][level]=w['throat']['segments'][0]
        for item in beam['sections']:
            sec=item['section'];a=item['actions'];a['nominal_normal_stress_MPa']=[a['N']/sec['A']+a['M_net_centroid']*(x-sec['xc'])/sec['I'] for x in (sec['xmin'],sec['xmax'])]
    receivers={key:{level:receiver_weld_group(c,a['Fx'],a['Fy'],a['Mz'],level=level,case=case,model=key) for level,a in levels.items()} for key,levels in actions.items()}
    rd=.6*c.fw/1.35; fy=STEELS[c.fin_steel].fy/1.1;envelopes=[]
    for level in ('top','bottom'):
        label='superior' if level=='top' else 'inferior'
        alt=[];base_alt=[]
        for key in LABELS:
            s=welds[key][level];a=actions[key][level]
            alt.append(dict(model=key,label=LABELS[key],utilization=s['max_stress_MPa']/rd,stress_MPa=s['max_stress_MPa'],segment=s,**{k:a[k] for k in ('Fx','Fy','Mz')}))
            pts=[dict(endpoint=p['endpoint'],sigma_normal_MPa=(-1 if level=='top' else 1)*p['qy_N_per_mm']/c.fin_t,tau_xy_MPa=(-1 if level=='top' else 1)*p['qx_N_per_mm']/c.fin_t,
                      equivalent_MPa=math.hypot(p['qy_N_per_mm'],math.sqrt(3)*p['qx_N_per_mm'])/c.fin_t) for p in s['endpoint_stresses']]
            worst=max(pts,key=lambda p:p['equivalent_MPa'])
            base_alt.append(dict(model=key,label=LABELS[key],utilization=worst['equivalent_MPa']/fy,stress_MPa=worst['equivalent_MPa'],critical_point=worst,**{k:a[k] for k in ('Fx','Fy','Mz')}))
        for prefix,name,variants,resistance in [('dc_weld_internal_','Nervura–horizontal '+label+' — solda',alt,rd),('dc_base_internal_','Nervura–horizontal '+label+' — escoamento local suplementar',base_alt,fy)]:
            winner=max(variants,key=lambda a:a['utilization'])
            envelopes.append(dict(id=prefix+level,label=name,governing_model=winner['model'],utilization=winner['utilization'],demand=winner['stress_MPa'],resistance=resistance,alternatives=variants))
        for segid,seglabel in [('web','alma'),('flange_negative_z','mesa z−'),('flange_positive_z','mesa z+')]:
            alt=[]
            for key in LABELS:
                g=receivers[key][level];s=next(s for s in g['segments'] if s['id']==segid);a=actions[key][level]
                alt.append(dict(model=key,label=LABELS[key],utilization=s['utilization'],stress_MPa=s['max_stress_MPa'],segment=s,**{k:a[k] for k in ('Fx','Fy','Mz')}))
            winner=max(alt,key=lambda a:a['utilization'])
            envelopes.append(dict(id='dc_weld_receiver_'+level+'_'+segid,label='Horizontal '+label+'–'+seglabel+' da coluna — solda',governing_model=winner['model'],utilization=winner['utilization'],demand=winner['stress_MPa'],resistance=rd,alternatives=alt))
    return dict(status='calculated_conditional',assumptions=ASSUMPTIONS,models=models,receiver_actions=actions,receiver_groups=receivers,weld_envelopes=envelopes,limitations=LIMITATIONS,
                long_joint_edges=sorted({level+':'+s for gs in receivers.values() for level,g in gs.items() for s in g['long_joint_edges']}))
