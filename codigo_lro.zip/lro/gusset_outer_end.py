"""Bounded first outer end cut, perpendicular to the physical brace axis.

The base envelope and every complete support remain explicit. This is not an
arbitrary polygon editor or a stability method. All values are unrounded mm.
"""
from __future__ import annotations
import math

CUT_EDGE = 'outer_normal_cut_free'
WELDED_FIELDS = ('gusset_end_shape', 'gusset_weld_end_distance')
BOLTED_FIELDS = ('gusset_end_shape', 'gusset_bolt_end_distance')
SHAPES = ('original', 'normal_cut')


def enabled(c):
    return getattr(c, 'gusset_end_shape', 'original') == 'normal_cut'


def dot(a,b): return a[0]*b[0]+a[1]*b[1]


def tolerance(poly):
    return 1e-9 + 1e-12*max([abs(v) for p in poly for v in p]+[1.])


def inside(p,poly,tol=None):
    tol = tolerance(poly) if tol is None else tol
    return bool(poly) and all((b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0]) >= -tol*max(1.,math.dist(a,b)) for a,b in zip(poly,poly[1:]+poly[:1]))


def segment_distance(p,a,b):
    d=[b[i]-a[i] for i in (0,1)];den=dot(d,d)
    f=max(0.,min(1.,dot([p[i]-a[i] for i in (0,1)],d)/den)) if den else 0.
    q=[a[i]+f*d[i] for i in (0,1)]
    return math.dist(p,q)


def properties(poly):
    terms=[a[0]*b[1]-b[0]*a[1] for a,b in zip(poly,poly[1:]+poly[:1])]
    area=sum(terms)/2
    if area<=0: raise ValueError('Contorno retido sem área positiva e orientação anti-horária.')
    centroid=[sum((a[j]+b[j])*z for a,b,z in zip(poly,poly[1:]+poly[:1],terms))/(6*area) for j in (0,1)]
    return area,centroid


def clip(poly,axis,limit):
    tol=tolerance(poly);out=[]
    for a,b in zip(poly,poly[1:]+poly[:1]):
        da=dot(a,axis)-limit;db=dot(b,axis)-limit
        da=0. if abs(da)<=tol else da;db=0. if abs(db)<=tol else db
        if da<=0: out.append(list(a))
        if (da<=0)!=(db<=0):
            f=da/(da-db);out.append([a[j]+f*(b[j]-a[j]) for j in (0,1)])
    clean=[]
    for p in out:
        if not clean or math.dist(p,clean[-1])>tol:clean.append(p)
    if len(clean)>1 and math.dist(clean[0],clean[-1])<=tol:clean.pop()
    return clean


def tagged_edges(poly,original,ids,axis=None,limit=None):
    tol=8*tolerance(original);edges=[]
    originals=list(zip(original,original[1:]+original[:1],ids))
    for a,b in zip(poly,poly[1:]+poly[:1]):
        matches=[name for p,q,name in originals if segment_distance(a,p,q)<=tol and segment_distance(b,p,q)<=tol]
        name=matches[0] if matches else CUT_EDGE if axis is not None and abs(dot(a,axis)-limit)<=tol and abs(dot(b,axis)-limit)<=tol else None
        if name is None:raise ValueError('Aresta sem identidade física no contorno retido.')
        edges.append({'id':name,'start':list(a),'end':list(b),'supported':name in ('root','beam_support','column_support'),'length':math.dist(a,b)})
    return edges


def build(original,axis,references,distance,shape,ids,supports,root_footprints=()):
    """Clip exactly once and retain bounded dimension/support witnesses."""
    poly=[list(p) for p in original];area0,_=properties(poly)
    result={'polygon':poly,'edges':tagged_edges(poly,poly,ids),'problems':[]}
    info={'shape':shape,'trimmed':False,'state':'original','axis':list(axis),'reference_kind':None,
          'distance_mm':distance,'dimension':None,'cut_segment':None,'base_polygon':[list(p) for p in original]}
    result['outer_end_cut']=info
    if shape=='original':return result
    if shape!='normal_cut':
        result['problems'].append(('outer_end_shape','Forma externa não reconhecida.'));return result
    if not isinstance(distance,(int,float)) or isinstance(distance,bool) or not math.isfinite(distance) or distance<=0:
        info['state']='invalid_distance';result['problems'].append(('outer_end_distance','Informe distância externa positiva, em mm, após a última fixação física.'));return result
    norm=math.hypot(*axis)
    if not math.isfinite(norm) or abs(norm-1)>1e-10:raise ValueError('Eixo físico do corte deve ser unitário.')
    tol=tolerance(poly);uref=max(dot(p,axis) for p in references);limit=uref+distance
    refs=[list(p) for p in references if abs(dot(p,axis)-uref)<=tol]
    info.update(reference_u=uref,cut_u=limit,reference_points=refs)
    if max(dot(p,axis) for p in poly)<=limit+tol:
        info['state']='no_trim';info['note']='Plano além do contorno ou coincidente: nenhuma nova borda fabricada; distância nominal não é cota de uma face de corte.'
        return result
    clipped=clip(poly,axis,limit)
    if len(clipped)<3:
        info['state']='invalid_contour';result['problems'].append(('outer_end_area','Corte elimina o contorno positivo da chapa.'));return result
    area,cg=properties(clipped)
    if area<=tol*tol:raise ValueError('Área retida numericamente degenerada.')
    edges=tagged_edges(clipped,original,ids,axis,limit)
    cap=next((e for e in edges if e['id']==CUT_EDGE),None)
    if cap is None:raise ValueError('Recorte ativo sem segmento externo identificado.')
    info.update(trimmed=True,state='trimmed',cut_segment=[cap['start'],cap['end']],base_area_mm2=area0,retained_area_mm2=area,removed_area_mm2=area0-area)
    result.update(polygon=clipped,edges=edges,plate_area_mm2=area,plate_centroid=cg)
    for name,points in list(supports.items())+list(root_footprints):
        if any(dot(p,axis)>limit+tol for p in points):
            result['problems'].append(('outer_end_preserve_'+name,'Corte cruza '+name+': esta família preserva integralmente contatos e pegadas das raízes; redefinir a raiz exige outro modelo.'))
    dimensions=[]
    for p in refs:
        foot=[p[j]+distance*axis[j] for j in (0,1)]
        actual=ray_exit(edges,p,axis) if inside(p,clipped) else None
        on_cap=actual is not None and segment_distance(foot,cap['start'],cap['end'])<=8*tol and CUT_EDGE in actual['edges'] and abs(actual['distance']-distance)<=8*tol
        dimensions.append({'reference':p,'foot':foot,'actual_first_exit':actual,'actual_gauge':on_cap})
    info['reference_clearances']=dimensions
    if not all(d['actual_gauge'] for d in dimensions):
        result['problems'].append(('outer_end_reference_exit','Outra borda real é atingida antes da face de corte; a distância informada não é uma cota física até o chanfro.'))
    else:info['dimension']=[dimensions[-1]['reference'],dimensions[-1]['foot']]
    return result


def ray_exit(edges,start,direction):
    candidates=[]
    scale=[p for e in edges for p in (e['start'],e['end'])];tol=tolerance(scale)
    cross=lambda a,b:a[0]*b[1]-a[1]*b[0]
    for edge in edges:
        a,b=edge['start'],edge['end'];v=[b[j]-a[j] for j in (0,1)];w=[a[j]-start[j] for j in (0,1)]
        den=cross(direction,v)
        if abs(den)<=1e-13*max(1.,math.hypot(*v)):continue
        t=cross(w,v)/den;f=cross(w,direction)/den
        if t>=-tol and -tol/max(1.,edge['length'])<=f<=1+tol/max(1.,edge['length']):
            candidates.append({'distance':max(0.,t),'point':[start[j]+t*direction[j] for j in (0,1)],'edge':edge['id'],'supported':edge['supported']})
    if not candidates:raise ValueError('Raio não encontra uma aresta real limitada do polígono.')
    t=min(x['distance'] for x in candidates);ties=[x for x in candidates if abs(x['distance']-t)<=8*tol]
    chosen=next((x for x in ties if not x['supported']),ties[0]);out=dict(chosen)
    out['edges']=[x['edge'] for x in ties]
    return out


def line_chord(poly,axis,value):
    tol=tolerance(poly);hits=[]
    for a,b in zip(poly,poly[1:]+poly[:1]):
        if min(a[axis],b[axis])-tol<=value<=max(a[axis],b[axis])+tol:
            if abs(b[axis]-a[axis])<=tol:hits.extend([a[1-axis],b[1-axis]])
            else:hits.append(a[1-axis]+(value-a[axis])*(b[1-axis]-a[1-axis])/(b[axis]-a[axis]))
    return [min(hits),max(hits)] if hits else None


def one_root(c):
    B,H=c.plate_width,c.plate_height;C,S=math.cos(math.radians(c.theta_deg)),math.sin(math.radians(c.theta_deg))
    point=lambda u,v=0.:[c.center_s+u*C+v*S,c.center_n+u*S-v*C]
    bolted=hasattr(c,'n');u=(c.row_offset+(c.n-1)*c.pitch/2) if bolted else c.weld_length/2
    if bolted:refs=[point(u)];distance=getattr(c,'gusset_bolt_end_distance',0.)
    else:
        from .angle_catalog import get_angle
        angle=get_angle(c.angle_profile);b=angle['leg']
        refs=[point(u,-b/2),point(u,b/2)];distance=getattr(c,'gusset_weld_end_distance',0.)
    base=[[-B/2,0.],[B/2,0.],[B/2,H],[-B/2,H]]
    roots={'root_support':[[-B/2,0.],[B/2,0.]]}
    footprint=[[-B/2,0.],[B/2,0.],[B/2,c.root_weld_leg],[-B/2,c.root_weld_leg]]
    result=build(base,[C,S],refs,distance,getattr(c,'gusset_end_shape','original'),('root','right','top','left'),roots,[('root_weld_footprint',footprint)])
    result['outer_end_cut']['reference_kind']='last_physical_bolt_center' if bolted else 'physical_weld_end'
    return result


def attach(g,contour):
    if contour['outer_end_cut']['shape']!='original':
        g.update(polygon=contour['polygon'],boundary_edges=contour['edges'],outer_end_cut=contour['outer_end_cut'])
        if 'plate_area_mm2' in contour:g.update(plate_area_mm2=contour['plate_area_mm2'],plate_centroid=contour['plate_centroid'])
    return g


def description(g,fmt):
    data=g.get('outer_end_cut')
    if not data:return 'Contorno original, sem corte externo.'
    if not data.get('trimmed'):return 'Corte externo sem remoção de material: não há nova face para cotar.' if data.get('state')=='no_trim' else 'Corte externo: distância/geometria ainda inválida.'
    if data.get('dimension') is None:
        return ('Plano de corte informado com distância axial '+fmt(data['distance_mm'])+' mm; configuração inválida: a distância não corresponde à primeira borda física limitada. Não há cota física de corte válida. Conferir também a preservação integral dos contatos e pegadas das raízes nos problemas de geometria.')
    origin='centro do último parafuso físico' if data['reference_kind']=='last_physical_bolt_center' else 'término físico das soldas longitudinais'
    return ('Corte externo perpendicular ao eixo da diagonal, '+fmt(data['distance_mm'])+' mm após o '+origin+'. Exige contatos e pegadas das raízes integralmente preservados; conferir os problemas de geometria. Envelope original B/H. Área retida '+fmt(data['retained_area_mm2'])+' mm². Mesma geometria no cálculo, croqui e arquivo nativo.')
