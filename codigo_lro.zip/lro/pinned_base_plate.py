"""Base rotulada, quatro chumbadores INTERNOS: NBR 8800 Tipo 2.

Ações de entrada N/V, sem momento aplicado. A excentricidade de uma chave
gera momento local explicitamente. Não extrapola Tipo 2 a C3/T3/M0.
Dados periféricos são compartilhados; geometria, equilíbrio e flexão por
tração são independentes do modelo de chumbadores externos.
"""
from dataclasses import dataclass, field, asdict, fields
import math
from .models import Profile, Issue, VERSION, profiles
from . import base_plate as common
from .base_plate_details import fillet_dimensions
from .active_shear_key import ActiveShearKey, active_key_assumptions
from .column_base_weld import ColumnBaseWeld,column_weld_assumptions
from .concrete_components import ConcreteComponents,components_assumptions
from .upper_washer import UpperWasher, upper_washer_assumptions
from .single_key_weld import SingleKeyWeld, single_key_weld_assumptions
from .single_key_concrete import SingleKeyConcrete, single_key_concrete_assumptions


@dataclass(frozen=True)
class PinnedBasePlate(common.BasePlate):
    project: str = 'Placa de base rotulada'
    tp: float = 25.4
    db: float = 25.4
    a1: float = 50.
    a2: float = 100.
    anchor_shear_model: str = 'welded_washer'
    anchor_washer_t: float = 8.
    anchor_washer_side: float = 75.
    M: float = field(default=0., init=False, repr=False)
    base_fixity: str = field(default='pinned', init=False)

    @property
    def model_type(self): return 2
    @property
    def catalog_label(self): return 'Placa de base rotulada'
    @property
    def migration_message(self): return ''
    @property
    def a(self): return self.a2/2
    @property
    def l0(self): return min(self.column.d, self.a2+1.75*(self.a2-self.column.tw))
    @property
    def effective_moment(self): return self.V*self.shear_eccentricity
    @property
    def anchor_edge_distance(self): return min(self.L/2-self.a, self.a1)
    @property
    def detail_washer_side(self):
        return self.anchor_washer_side if self.native_anchor_shear else common.detail_reference(self)['washer_side']
    @property
    def washer_clearance(self):
        s=self.detail_washer_side
        web_leg=(fillet_dimensions(self.weld_web_size,self.weld_web_measure)['leg']
                 if self.weld_web_type=='fillet' else 0.)
        flange_leg=(fillet_dimensions(self.weld_flange_size,self.weld_flange_measure)['leg']
                    if self.weld_flange_type=='fillet' else 0.)
        return min(self.anchor_edge_distance-s/2, (self.a2-s)/2,
                   self.a2/2-self.column.tw/2-s/2-web_leg,
                   self.column.d/2-self.column.tf-self.a-s/2-flange_leg)
    @property
    def washer_clearance_expression(self):
        return 'g = min(borda−s/2; (a2−s)/2; (a2−tw−s)/2−z_alma; (d−2tf−a2−s)/2−z_mesa)'
    @property
    def assumptions(self):
        items=[
            'Família rotulada distinta: placa retangular sem enrijecedores, perfil I/H centrado e quatro chumbadores internos em (±a2/2, ±a2/2), NBR Tipo 2. L=d+4a1, B=a2+2a1 e a=a2/2. Referência geométrica industrial B-003; B-001 tem chumbadores externos.',
            'Entradas estáticas de cálculo N e V na face superior da placa; N>0 comprime e N<0 traciona. Não existe momento aplicado nesta família. A seleção rotulada é hipótese do modelo global, sem certificação de rigidez rotacional ou capacidade de rotação.',
            'NBR 6.7.1.4: Tipo 2 limitado a C1/C2/T1/T2. Excentricidade local de chave é preservada por Mlocal=V eV. Estados que exigem C3, T3 ou momento puro precisam de outro modelo verificado; não se usa a fórmula externa de Tipo 1.',
            'Flexão da placa sob tração: tmin=√[4 Ft,máx(a2−tw)/(l0 fy/γa1)], com l0=min[d; a2+1,75(a2−tw)]. Flexão sob contato C1/C2 usa as expressões comuns da NBR. Não se adota a linha de plastificação dos chumbadores externos.',
            'Chumbadores ASTM A36, fy=250 MPa e fu=400 MPa, barras redondas rosqueadas e porcas hexagonais pesadas. γa1=1,10, γa2=1,35 e γc=1,40 para combinações usuais; ações já majoradas.',
            'Concreto de densidade normal, 20≤fck≤50 MPa; pressão σRd=0,85fck/γc, A2/A1=1. Argamassa expansiva com resistência característica ≥2fck. A geometria da saia do graute não amplia a área resistente da placa.',
            'Cortante: atrito do contato, quatro chumbadores com arruelas soldadas, ou chave/dispositivo definido. O dispositivo escolhido resiste a V integral; resistências de mecanismos não se somam.',
            'Na rota nativa de arruelas soldadas, a flexão local das barras está na expressão NBR 6.7.2.5 por α, com tp+ta/2. Não se acrescenta outro Vtp a esse modelo de referência superior. Atrito segue a idealização de contato NBR. Outro ponto de aplicação ou caminho excêntrico exige modelo explícito.',
            'Cone de tração opcional ACI 318-19/DG1: coordenadas reais INTERNAS e trações simultâneas por barra, concreto fissurado íntegro, φ=0,70 Condição B. Não reaplicar γc aos valores ACI. Ancoragem completa exige pullout, ruptura lateral, fendilhamento, cortante/pryout/interação e componentes enterrados.',
            (('O componente condicional de soldas/seções locais do pilar é discriminado separadamente; metal-base local, transferência e flexão acoplada da placa, ancoragem completa e bloco armado permanecem a complementar. ' if self.column_weld.model=='two_flange_normal_web_shear' else
              'Soldas do pilar, transferência das forças locais à alma/mesas, flexão acoplada da placa, ancoragem completa e bloco armado permanecem a complementar. ')+'Sem crédito a enrijecedores, tubulares, ganchos J, ancoragens químicas/pós-instaladas, fadiga, sismo, incêndio ou montagem antes da cura.'),
        ]
        if self.shear_path=='plate':
            items += ['Chave retangular: eV=tp+(bv+en)/2; Mlocal=V eV, com seu sinal, entra uma única vez no equilíbrio. Cisalhamento paralelo a L, sem ação biaxial/torção. Ações de solda Vw=Vbearing,Rd e Mw=Vbearing,Rd(bv+en)/2. Contato local, flexão/corte da chave e t-chave≤t-placa não aprovam soldas, flexão local da placa, ruptura do concreto ou bloco armado.']
        if self.native_anchor_shear:
            items += ['Quatro arruelas especiais superiores idênticas com furos-padrão db+1,5 mm, soldadas e capazes de mobilizar todas as barras. VRd=ΣVRd,i usando cada tração concorrente. No termo subtrativo de índice ambíguo da NBR, usa-se Ft,máx como envelope conservador, mais interação geral tração–corte. A solda de cada arruela é solicitada por Fv,Rd não reduzido, nunca por V/4.']
        if self.shear_path in ('external','anchors') and not self.native_anchor_shear:
            items += ['Rota documentada: a memória externa deve cobrir a combinação N/V, excentricidades, grupo real, aço, concreto, soldas e caminho completo; a comparação de capacidade não calcula essas verificações.']
        return items+active_key_assumptions(self)+single_key_weld_assumptions(self)+single_key_concrete_assumptions(self)+upper_washer_assumptions(self)+components_assumptions(self)+column_weld_assumptions(self)

    def to_dict(self):
        data=asdict(self)
        data.pop('M');data.pop('base_fixity')
        data['active_key']=self.active_key.to_dict(self.shear_path)
        return dict(schema_version=2,app_version=VERSION,connection_type='base_plate_pinned',
                    connection=data,fixed_assumptions=self.assumptions)

    @staticmethod
    def from_dict(data,validate_values=True):
        if (not isinstance(data,dict) or data.get('connection_type')!='base_plate_pinned'
            or type(data.get('schema_version')) is not int or data['schema_version']!=2):
            raise ValueError('Selecione um projeto da família placa de base rotulada desta versão.')
        if not isinstance(data.get('connection'),dict):raise ValueError('Dados da placa de base rotulada ausentes.')
        payload=dict(data['connection'])
        names={f.name for f in fields(PinnedBasePlate) if f.init}
        unknown=set(payload)-names
        if unknown:raise ValueError('Campos não aceitos pela base rotulada: '+', '.join(sorted(unknown)))
        if not isinstance(payload.get('column'),dict):raise ValueError('Seção do pilar ausente ou inválida.')
        try:
            payload['column']=Profile(**payload['column'])
            if 'active_key' in payload:payload['active_key']=ActiveShearKey.from_dict(payload['active_key'])
            if 'upper_washer' in payload:payload['upper_washer']=UpperWasher.from_dict(payload['upper_washer'])
            if 'single_key_weld' in payload:payload['single_key_weld']=SingleKeyWeld.from_dict(payload['single_key_weld'])
            if 'single_key_concrete' in payload:payload['single_key_concrete']=SingleKeyConcrete.from_dict(payload['single_key_concrete'])
            if 'concrete_components' in payload:payload['concrete_components']=ConcreteComponents.from_dict(payload['concrete_components'])
            if 'column_weld' in payload:payload['column_weld']=ColumnBaseWeld.from_dict(payload['column_weld'])
            c=PinnedBasePlate(**payload)
        except (TypeError,KeyError) as exc:raise ValueError('Dados incompatíveis com a base rotulada.') from exc
        issues=validate(c) if validate_values else []
        if any(i.severity=='error' for i in issues):raise ValueError('; '.join(i.text for i in issues if i.severity=='error'))
        return c


def validate(c):
    issues=common.validate(c)
    if any(i.severity=='error' for i in issues):return issues
    ref=common.detail_reference(c)
    if c.shear_path=='external' or (c.shear_path=='anchors' and not c.native_anchor_shear):
        issues.append(Issue('error','Base rotulada: capacidade externa escalar não define a posição da reação nem o momento local. Use atrito, arruelas soldadas nativas ou chave com geometria explícita; outro caminho requer modelo específico.', 'Caminho e referência do cortante'))
    if c.a2<=c.column.tw:
        issues.append(Issue('error','Os quatro chumbadores internos devem ficar em ambos os lados da alma: a2>tw.',common.NBR+', Figura 21 corrigida'))
    if c.a>=c.column.d/2-c.column.tf:
        issues.append(Issue('error','As linhas internas de chumbadores devem caber entre as faces internas das mesas.',common.NBR+', Figura 21 corrigida'))
    if c.washer_clearance<0:
        issues.append(Issue('error','Arruelas internas interferem com alma/mesas, soldas especificadas, outra arruela ou borda da placa. Reveja a2, placa, seção e o detalhe real.',common.NBR+', Figura 21 e tabela 18'))
    if not math.isclose(c.a1,ref['a1']):
        issues.append(Issue('pending',f'Este modelo usa um único a1 nas duas direções. A Tabela 18 corrigida permite reduzir a1 entre 10 e {ref["a1"]:g} mm somente na direção L; a redução transversal não é automaticamente coberta. O a1 informado difere do pacote tabulado e requer detalhamento específico, sem correção automática.',common.NBR+', tabela 18 nota f'))
    if c.stiffener_detail!='none':
        issues.append(Issue('error','Enrijecedores não integram esta família Tipo 2; geometria e distribuição de forças exigem outro modelo verificado.',common.NBR+', 6.7.1.1'))
    return issues


def reactions(c):
    """C1/C2/T1/T2 independent equilibrium, with Type2 uplift yield line."""
    N=c.N;local=c.effective_moment;M=abs(local);P=max(N,0.);U=max(-N,0.)
    B,L,a=c.B,c.L,c.a;sign=1 if local>=0 else -1
    out=dict(case='SEM N',e=None,ecrit=None,lc=0.,sigma=0.,C=0.,T_total=0.,Ft_max=0.,Ft_min=0.,
             X=0.,lambda_=0.,D=None,t_contact=0.,t_tension=0.,t_required=0.,db_required=0.,lmax=0.,
             m=c.m,n=c.n,n0=c.n0,l0=c.l0,moment_sign=sign,M_input=0.,delta_M=local,M_effective=local,
             eV=c.shear_eccentricity,L=L,B=B,a=a,sigma_rd=c.sigma_rd,tau_rd=c.tau_rd,C_x=0.,
             T_max_x=-sign*a,T_min_x=sign*a,residual_N=0.,residual_M=0.)
    out['lambda']=out.pop('lambda_')
    if N==0 and M==0:return out
    if N==0:
        raise ValueError('Momento local V·eV sem força axial exige contato e tração simultâneos; não é caso C1/C2/T1/T2 do Tipo 2. Rever o caminho do cortante ou verificar outro modelo.')
    if P>c.sigma_rd*L*B:
        raise ValueError('Compressão N>σRd L B: a área da placa é insuficiente.')
    X=4*c.column.d*c.column.bf/(c.column.d+c.column.bf)**2*P/(L*B*c.sigma_rd)
    if X>1:raise ValueError('X>1 fora do domínio corrigido NBR; não se extrapola √(1−X).')
    lam=min(1.,2*math.sqrt(X)/(1+math.sqrt(1-X)))
    out.update(X=X);out['lambda']=lam
    e=M/(P or U);out['e']=e
    if P:
        critical=.5*(L-P/(c.sigma_rd*B));out['ecrit']=critical
        if e>critical and not math.isclose(e,critical,rel_tol=1e-12,abs_tol=1e-10):
            raise ValueError('O momento local do cortante exige C3 (compressão e chumbadores tracionados). NBR 6.7.1.4 não inclui C3 para Tipo 2; não se transfere a fórmula de Tipo 1.')
        lc=L-2*e
        if lc<=0:raise ValueError('Faixa de contato não positiva para o Tipo 2.')
        sigma=P/(B*lc)
        lmax=max(c.m,c.n,lam*c.n0) if lc>=c.m else max(math.sqrt(lc*(2*c.m-lc)),c.n)
        tc=lmax*math.sqrt(2*sigma/(c.fy/common.G1))
        out.update(case='C1' if M==0 else 'C2',lc=lc,C=P,sigma=sigma,lmax=lmax,t_contact=tc,t_required=tc,
                   C_x=sign*(L/2-lc/2))
    else:
        if e>a and not math.isclose(e,a,rel_tol=1e-12,abs_tol=1e-10):
            raise ValueError('O momento local do cortante exige T3 (tração e contato comprimido). NBR 6.7.1.4 não inclui T3 para Tipo 2; não se transfere a fórmula de Tipo 1.')
        Ft=U/4+M/(4*a);Fmin=U/4-M/(4*a)
        if Fmin<0 and math.isclose(Fmin,0.,abs_tol=1e-7):Fmin=0.
        if c.l0<=0 or c.a2<=c.column.tw:raise ValueError('Linha de plastificação interna inválida.')
        tt=math.sqrt(4*Ft*(c.a2-c.column.tw)/(c.l0*(c.fy/common.G1)))
        out.update(case='T1' if M==0 else 'T2',T_total=2*(Ft+Fmin),Ft_max=Ft,Ft_min=Fmin,
                   t_tension=tt,t_required=tt,db_required=math.sqrt(4*Ft/(.75*math.pi*(400/common.G2))))
    out['residual_N']=out['C']-out['T_total']-N
    out['residual_M']=(out['C']*out['C_x']-2*out['Ft_max']*out['T_max_x']
                       -2*out['Ft_min']*out['T_min_x']-local)
    return out


def evaluate(c):
    return common.evaluate_components(c,validate,reactions)


def presets():
    from dataclasses import replace
    catalog=profiles()
    p=next((v for k,v in catalog.items() if k.startswith('W 310') or k.startswith('W310')),next(iter(catalog.values())))
    c=PinnedBasePlate(p,a2=max(100.,p.bf+25-100),project='Base rotulada — compressão e atrito')
    return {
        'Rotulada · compressão e atrito':c,
        'Chumbadores · arruelas soldadas':replace(c,N=-100000.,V=20000.,shear_path='anchors',anchor_shear_model='welded_washer',project='Base rotulada — tração e cortante'),
        'Rotulada · compressão e chave':replace(c,N=400000.,V=50000.,shear_path='plate',lug_bh=100.,lug_bv=100.,project='Base rotulada — chave de chapa'),
    }
