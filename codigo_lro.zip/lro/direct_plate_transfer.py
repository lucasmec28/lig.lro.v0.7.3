"""Bounded published plate components for the direct-bearing route.

P358 Check 9 is mapped ONLY to the internal, symmetric Type 2 geometry.
hp is the common physical web attachment, never the whole baseplate length.
EN section factors are independent of EN anchor, NBR and ACI factors.
"""
import math
from .models import STEELS, finite_real

REF = 'SCI P358 Check 9 p.23; EN 1993-1-8 3.10.2/6.1.1; EN 1993-1-1 γM0=1,00, γM2,placa=1,25'
LOCAL_REF = 'NBR 8800:2024 corrigida 2025, 6.5.1/6.5.5; metal-base real junto à linha de fusão'
G0, G2 = 1., 1.25


def _check(key, label, demand, resistance, reference=REF, sufficient=False, **extra):
    ratio = demand/resistance if resistance > 0 else None
    passed = ratio is not None and ratio <= 1+1e-10
    return dict(id=key,label=label,demand=demand,resistance=resistance,unit='N',ratio=ratio,
                passes=passed,status='pass' if passed else 'sufficient_bound_exceeded' if sufficient else 'fail',
                reference=reference,sufficient_bound=sufficient,**extra)


def three_state_contract(states,V):
    """Every required contact alternative, not only the favorable uniform case."""
    names={'normal_hole_equal':0,'leading_row':1,'opposite_row_envelope':-1}
    if not isinstance(states,list) or len(states)!=3 or any(not isinstance(s,dict) for s in states):return False
    if any(not isinstance(s.get('id'),str) for s in states) or {s.get('id') for s in states}!=set(names):return False
    sign=1 if V>=0 else -1
    for state in states:
        rods=state.get('rods',[]);side=names[state['id']]
        if len(rods)!=4 or any(not isinstance(r,dict) or not isinstance(r.get('id'),str) or not finite_real(r.get('x')) or not finite_real(r.get('y')) or not finite_real(r.get('shear')) for r in rods):return False
        for r in rods:
            expected=abs(V)/4 if side==0 else abs(V)/2 if side*sign*r['x']>0 else 0.
            if not math.isclose(r['shear'],expected,rel_tol=1e-9,abs_tol=1e-8):return False
    return True


def type2_plate_component(*,hp,B,tp,pitch,tw,d0,fy,fu,V,states):
    """Pure P358 plate oracle. The adapter establishes the real welded source."""
    out=dict(method='p358_type2_real_web_v1',complete=False,passes=None,status='outside_p358_type2_domain',
             reasons=[],checks=[],states=[],reference=REF,
             factors=dict(gamma_M0_section=G0,gamma_M2_section=G2,p358_uk_gamma_M2_not_used=1.1),
             assumptions=['Subplaca contida no trecho físico contínuo comum da alma; prolongamentos ignorados.',
                          'Prefixos com fator de tração 0,5: limite suficiente conservador, não exigência universal de excentricidade.',
                          'Composição nominal com N/M da família; não é uma nova interação membrana/flexão.'])
    vals=(hp,B,tp,pitch,tw,d0,fy,fu)
    if any(not finite_real(x) or not 0<x<=1e7 for x in vals) or not finite_real(V) or abs(V)>1e15 or fy>fu:
        out['reasons'].append('Dimensões, propriedades ou ação fora do domínio numérico.');return out
    e1=(hp-pitch)/2;e2=(B-pitch)/2
    out['geometry']=dict(hp_mm=hp,B_mm=B,tp_mm=tp,p1_mm=pitch,p3_mm=pitch,tw_mm=tw,d0_mm=d0,e1_mm=e1,e2_mm=e2,n1=2)
    if e1<1.2*d0-1e-9 or e2<1.2*d0-1e-9 or pitch<2.4*d0-1e-9 or pitch<=tw or hp<=2*d0:
        out['reasons'].append('Subplaca Tipo2: e1/e2≥1,2d0, p1≥2,2d0, p3≥2,4d0, p3>tw e áreas líquidas positivas. Fora deste limite suficiente não significa ruptura da placa real.');return out
    expected={(x,y) for x in (-pitch/2,pitch/2) for y in (-pitch/2,pitch/2)}
    if not three_state_contract(states,V):
        out['reasons'].append('Exigem-se os três estados únicos e suas distribuições reais: uniforme, linha dianteira e envelope oposto.');return out
    for state in states:
        rods=state.get('rods',[])
        if len(rods)!=4 or {(a.get('x'),a.get('y')) for a in rods}!=expected or len({a.get('id') for a in rods})!=4:
            out['reasons'].append('Quatro furos internos reais simétricos exigidos; não reconstruir coordenadas.');return out
        if any(not finite_real(a.get('shear')) or a['shear']<0 for a in rods):
            out['reasons'].append('Qi reais finitos não negativos exigidos.');return out
        if not math.isclose(sum(a['shear'] for a in rods),abs(V),rel_tol=1e-9,abs_tol=1e-8):
            out['reasons'].append('Estado não equilibra o V integral.');return out
        for y in (-pitch/2,pitch/2):
            if not math.isclose(sum(a['shear'] for a in rods if a['y']==y),abs(V)/2,rel_tol=1e-9,abs_tol=1e-8):
                out['reasons'].append('A simetria de V/2 por meia-placa não está satisfeita.');return out
    Ant=tp*(e2-d0/2);Anv=tp*(hp-e1-1.5*d0)
    bending=100*hp<136*pitch  # exact decimal threshold, avoids 1.36 binary drift
    c_full=.5 if bending else 1.
    resistances=dict(gross=2*hp*tp*fy/(1.27*math.sqrt(3)*G0),
        net=2*tp*(hp-2*d0)*fu/(math.sqrt(3)*G2),
        block_full=2*(c_full*fu*Ant/G2+fy*Anv/(math.sqrt(3)*G0)))
    if bending:resistances['inplane_bending']=2*tp*hp*hp*fy/(3*(pitch-tw)*G0)
    out.update(resistances_N=resistances,areas_mm2=dict(Ant=Ant,Anv_full=Anv,Av_net=tp*(hp-2*d0)),
               inplane_bending_required=bending,full_block_tension_coefficient=c_full)
    sign=1 if V>=0 else -1
    labels=dict(gross='P358 chapa — seção bruta com redução 1,27',net='P358 chapa — seção líquida',
                block_full='P358 chapa — bloco completo',inplane_bending='P358 chapa — flexão no plano')
    for state in states:
        sid=state['id'];checks=[_check(sid+'_'+key,label,abs(V),resistances[key],sufficient=True)
                               for key,label in labels.items() if key in resistances]
        prefixes=[]
        for y in (-pitch/2,pitch/2):
            rods=sorted((a for a in state['rods'] if a['y']==y),key=lambda a:-sign*a['x'],reverse=True)
            for n in (1,2):
                selected=rods[:n];last=selected[-1];lv=hp/2+sign*last['x']
                anv=tp*(lv-(n-.5)*d0);agv=tp*lv
                demand=sum(a['shear'] for a in selected)
                rd=.5*fu*Ant/G2+fy*anv/(math.sqrt(3)*G0)
                rec=dict(ids=[a['id'] for a in selected],m=n,side_y_mm=y,loaded_edge='x-' if sign>0 else 'x+',
                         lv_mm=lv,Agv_mm2=agv,Anv_mm2=anv,Ant_mm2=Ant,tension_coefficient=.5,
                         inactive_holes_retained=True,forces_N={a['id']:a['shear'] for a in selected})
                ck=_check(sid+'_prefix_'+str(y)+'_'+str(n),'P358/EN bloco lateral — '+','.join(rec['ids']),demand,rd,sufficient=True,**rec)
                checks.append(ck);prefixes.append(ck)
        out['states'].append(dict(id=sid,checks=checks,prefixes=prefixes,passes=all(c['passes'] for c in checks)))
        out['checks'].extend(checks)
    passed=all(c['passes'] for c in out['checks'])
    out.update(complete=True,passes=passed,status='pass' if passed else 'sufficient_bound_exceeded')
    return out


def introduction_component(c,r):
    """Actual weld line to baseplate. Two fillets never create two plates."""
    out=dict(complete=False,passes=None,status='pending',checks=[],reasons=[],reference=LOCAL_REF)
    ps=STEELS[c.plate_steel];w=r.local_column_weld
    if w.get('model')=='channel_elastic_lines':
        t=min(c.column.tw,c.effective_flange_min_thickness,c.tp)
        if t<=0:
            out['reasons'].append('Espessura real mínima do U indisponível para metal-base.');return out
        cs=STEELS[c.column_steel];q=w['qmax']
        # Same conservative resultant traction used by the existing rupture
        # check, now with yield as an independent resistance as well.
        for key,strength,gamma in [('yield',min(cs.fy,ps.fy),1.1),('rupture',min(cs.fu,ps.fu),1.35)]:
            ck=_check('u_introduction_'+key,'Metal-base U/placa — '+key,q,.6*strength*t/gamma,LOCAL_REF)
            ck['unit']='N/mm';out['checks'].append(ck)
        out['actual_weld_centroid']=w['centroid'];out['actual_Mz_Nmm']=w['Mz']
    elif w.get('model')=='two_flange_normal_web_shear' and all(k in w for k in ('flange','web','F_left_N','F_right_N')):
        if (w.get('qualification_status')!='qualified' or w.get('status')=='pending'
                or 'pending' in w.get('statuses',{}).values()
                or any(i.origin=='column_weld' and i.severity=='pending' for i in r.issues)):
            out['reasons'].append('Introdução na placa exige fonte soldada qualificada e vinculada aos dados atuais.');return out
        for part,demand in [('flange_left',abs(w['F_left_N'])),('flange_right',abs(w['F_right_N'])),('web',abs(c.V))]:
            source=w['web' if part=='web' else 'flange']
            length=source['design_length_mm'];area=length*c.tp
            for mode,strength,gamma in [('yield',ps.fy,1.1),('rupture',ps.fu,1.35)]:
                out['checks'].append(_check('plate_introduction_'+part+'_'+mode,
                    'Placa junto à fusão — '+part+' '+mode,demand,.6*strength*area/gamma,LOCAL_REF,
                    physical_length_mm=source['physical_length_mm'],design_length_mm=length,one_plate_area_mm2=area))
    else:
        out['reasons'].append('Fonte soldada I/H qualificada duas mesas N/M e alma V não calculada; não inferir metal-base pela resistência da solda.');return out
    out.update(complete=True,passes=all(x['passes'] for x in out['checks']))
    out['status']='pass' if out['passes'] else 'fail'
    return out


def evaluate_family_plate(c,r):
    out=dict(method='family_plate_transfer_v2',complete=False,passes=None,status='pending',checks=[],reasons=[])
    if not finite_real(c.anchor_washer_side) or c.anchor_washer_side<=c.direct_shear.hole_diameter:
        out['reasons'].append('Largura física da arruela superior deve exceder o furo real da placa; sem qualificação axial automática.');return out
    local=introduction_component(c,r);out['introduction']=local;out['checks'].extend(local['checks'])
    if c.model_type==2 and c.stiffener_detail in ('none','web_pair_visual'):
        w=r.local_column_weld
        if not local['complete'] or w.get('model')!='two_flange_normal_web_shear':
            out['reasons'].extend(local['reasons']);return out
        hp=w['web']['physical_length_mm'];ps=STEELS[c.plate_steel]
        panel=type2_plate_component(hp=hp,B=c.B,tp=c.tp,pitch=c.a2,tw=c.column.tw,d0=c.direct_shear.hole_diameter,
                                   fy=ps.fy,fu=ps.fu,V=c.V,states=r.geometry['direct_anchor_shear'].get('states',[]))
        out['panel']=panel;out['checks'].extend(panel['checks']);out['reasons'].extend(panel['reasons'])
        out['complete']=local['complete'] and panel['complete']
        if out['complete']:
            out['passes']=local['passes'] and panel['passes']
            out['status']='pass' if out['passes'] else 'fail' if not local['passes'] else 'sufficient_bound_exceeded'
        else:out['status']='outside_p358_type2_domain'
    elif c.model_type==1 and c.stiffener_detail in ('none','web_pair_visual'):
        if not local['complete']:
            out['reasons'].extend(local['reasons']);return out
        from .direct_external_plate import external_plate_components
        from .base_plate_details import fillet_dimensions
        ps=STEELS[c.plate_steel]
        web_leg=(fillet_dimensions(c.weld_web_size,c.weld_web_measure)['leg'] if c.weld_web_type=='fillet' else 0.)
        flange_leg=(fillet_dimensions(c.weld_flange_size,c.weld_flange_measure)['leg'] if c.weld_flange_type=='fillet' else 0.)
        panel=external_plate_components(L=c.L,B=c.B,t=c.tp,d=c.column.d,bf=c.column.bf,tw=c.column.tw,
            a=c.a,gauge=c.a2,d0=c.direct_shear.hole_diameter,fy=ps.fy,fu=ps.fu,V=c.V,
            states=r.geometry['direct_anchor_shear'].get('states',[]),source_half_width=c.column.tw/2+web_leg,
            flange_weld_leg=flange_leg,rod_fu=c.direct_shear.fu,rod_As=c.direct_shear.thread_area,washer_width=c.anchor_washer_side)
        out['panel']=panel;out['checks'].extend(panel['checks']);out['reasons'].extend(panel['reasons'])
        out['complete']=panel['complete']
        if out['complete']:
            out['passes']=local['passes'] and panel['passes']
            out['status']='pass' if out['passes'] else 'fail' if not local['passes'] else panel['status']
        else:out['status']=panel['status']
    else:
        out['reasons'].append('Transferência entre fonte soldada real e furos assimétricos ainda não qualificada para este domínio geométrico. Não é exigência universal de solver nem de interação própria N/M.')
        out['reasons'].extend(local['reasons'])
    return out
