"""Independent channel-base editor, native project state and local result scope."""
from dataclasses import fields, replace, asdict
import hashlib
import json
import pandas as pd
import streamlit as st
from .models import Profile, STEELS, KGF
from .channel_base_plate import ChannelBasePlate, channel_profiles, evaluate, presets, FAMILY, VERSION
from .channel_base_plate import CHANNEL_ANCHORS, catalog_properties
from .upper_washer import UpperWasher
from .channel_catalog import nominal_flange_tip, FLANGE_TAPER_ASSUMPTION
from .base_plate_details import ANCHOR_TYPES
from .base_input_summary_ui import concrete_summary, projection_widget, mc_excerpt_widget
from .base_block_ui import seed_block_editor, block_geometry_widgets
from .concrete_components import bearing_signature, distribution_signature
from .display_precision import number_input, calculated_text
from .report import BRAND, number
from .channel_base_plate_drawing import image_bytes
from .channel_base_plate_report import HEADERS, checks_rows, create_report, create_mc_excerpt

from .direct_anchor_shear_ui import (seed_direct_shear,restore_direct_shear,direct_shear_widgets,
    direct_shear_from_state,direct_shear_results,anchor_choices,anchor_label,direct_selected,MODEL_LABELS)
from .direct_anchor_shear_ui import METRIC_ANCHORS,UNC_ANCHORS

PROJECT='_channel_base_plate_project'
RESULT='_channel_base_plate_result'
PREFIX='cp_'
MANUAL='Seção U personalizada'
P=channel_profiles()
PRESETS=presets()
_NESTED={'column','active_key','upper_washer','single_key_weld','single_key_concrete','concrete_components','column_weld','direct_shear'}
_LOADS={'N','V'}
_CC_LOADS={'mechanical_resistance','force_a1','force_a2','force_a3','force_a4'}


def _canonical(value,previous,factor):
    return previous if value==previous/factor else value*factor


def _state(c,overwrite=False):
    s=st.session_state
    def put(key,value):
        # Reassign existing values too: otherwise Streamlit can restore an old
        # seed when a conditional widget is cleaned up on family navigation.
        s[key]=value if overwrite or key not in s else s[key]
    for f in fields(c):
        if not f.init or f.name in _NESTED:continue
        value=getattr(c,f.name)
        if f.name in _LOADS:put(PREFIX+f.name+'_kgf',value/KGF)
        else:put(PREFIX+f.name,float(value) if type(value) in (float,int) else value)
    put('cp_column_name',c.column.name if P.get(c.column.name)==c.column else MANUAL)
    manual=s.get('_cp_manual_draft',asdict(c.column))
    def put_manual(key,value):
        if s.get('_cp_profile_mode')!=MANUAL or overwrite:s[key]=value
        else:put(key,value)
    put_manual('cp_manual_name',manual['name'])
    put_manual('cp_manual_source',manual['source'])
    for name in ('d','bf','tw','tf','clear','area','mass'):put_manual('cp_column_'+name,float(manual[name]))
    for name,value in asdict(c.upper_washer).items():put('cp_uw_'+name,value)
    if overwrite:seed_direct_shear(c.direct_shear,'cp')
    else:restore_direct_shear({'direct_shear':asdict(c.direct_shear)},'cp')
    for name,value in asdict(c.concrete_components).items():
        put('cp_cc_'+name,value/KGF if name in _CC_LOADS else value)


def seed(c):
    st.session_state.pop('_cp_manual_draft',None)
    st.session_state.pop('_cp_manual_geometry',None)
    st.session_state.pop('_cp_profile_mode',None)
    for key in ('_cp_washer_mode_four','_cp_washer_mode_two_symmetry'):st.session_state.pop(key,None)
    _state(c,overwrite=True)
    seed_block_editor(c,'cp')
    st.session_state[PROJECT]=c.to_dict()
    st.session_state.pop('cp_report',None)
    st.session_state.pop('cp_mc_excerpt',None)
    for key in list(st.session_state):
        if key.startswith(('cp_bearing_confirm_','cp_distribution_confirm_')):del st.session_state[key]


def load_example():
    seed(PRESETS[st.session_state.cp_example])
    st.session_state.pop('cp_import_error',None)


def decode_project(raw):
    if len(raw)>200000:raise ValueError('Projeto maior que o limite de 200 kB.')
    return ChannelBasePlate.from_dict(json.loads(raw))


def load_json():
    try:
        upload=st.session_state.cp_upload
        if upload is None:raise ValueError('Selecione um arquivo JSON.')
        c=decode_project(upload.getvalue())
    except (ValueError,TypeError,KeyError,OverflowError,UnicodeError) as exc:
        st.session_state.cp_import_error='Não foi possível abrir: '+str(exc)
    else:
        seed(c);st.session_state.pop('cp_import_error',None)


def _select(label,choices,name,labels=None,on_change=None):
    options=list(choices);value=st.session_state.get('cp_'+name)
    if value is not None and value not in options:options.append(value)
    return st.selectbox(label,options,key='cp_'+name,
        format_func=lambda v:str((labels or {}).get(v,v)),on_change=on_change)


def _layout_changed():
    s=st.session_state
    previous=ChannelBasePlate.from_dict(s[PROJECT],validate_values=False)
    s['_cp_washer_mode_'+previous.anchor_layout]=s.cp_uw_model
    if s.cp_anchor_layout=='four' and s.cp_uw_model=='fitted_direct':
        s.cp_uw_model=s.get('_cp_washer_mode_four','off')
    elif s.cp_anchor_layout=='two_symmetry' and '_cp_washer_mode_two_symmetry' in s:
        s.cp_uw_model=s['_cp_washer_mode_two_symmetry']
    if s.cp_anchor_layout=='two_symmetry' and s.cp_base_hole==0 and not direct_selected('cp'):
        from . import base_plate as common
        for label,db in common.ANCHORS.items():
            if s.cp_db==db:
                s.cp_base_hole=float(common.DETAIL[label]['df'])
                break


def profile_widget(previous):
    name=st.selectbox('Pilar U',[MANUAL]+list(P),key='cp_column_name')
    old_mode=st.session_state.get('_cp_profile_mode')
    if old_mode==MANUAL:
        st.session_state['_cp_manual_geometry']={k:getattr(previous,k) for k in
            ('centroid_back','straight_web_length','flange_min_thickness','clear_geometry_confirmed')}
    if name==MANUAL and old_mode!=MANUAL:
        for key,value in st.session_state.get('_cp_manual_geometry',{}).items():
            st.session_state['cp_'+key]=value
    st.session_state['_cp_profile_mode']=name
    if name in P:
        p=P[name]
        if p != previous.column:
            st.session_state.cp_centroid_from_catalog=True
            st.session_state.cp_centroid_back=catalog_properties(p)['ec_mm']
            st.session_state.cp_straight_web_length=0.
            st.session_state.cp_flange_min_thickness=0.
            st.session_state.cp_flange_thickness_from_model=True
            st.session_state.cp_clear_geometry_confirmed=False
        st.caption(p.source)
        st.caption('d='+number(p.d)+'; bf='+number(p.bf)+'; tw='+number(p.tw)+'; tf='+number(p.tf)+' mm. Área='+number(p.area)+' mm².')
        return p
    with st.expander('Geometria manual do U',expanded=True):
        st.text_input('Designação do pilar U',key='cp_manual_name')
        for key,label in [('d','Altura d'),('bf','Largura da mesa bf'),('tw','Espessura da alma tw'),('tf','Espessura da mesa tf'),('clear','Altura livre sem concordâncias')]:
            number_input(label+' (mm)',min_value=.01,key='cp_column_'+key)
        number_input('Área publicada ou verificada do U (mm²)',min_value=.01,key='cp_column_area')
        number_input('Massa linear publicada (kg/m)',min_value=.01,key='cp_column_mass')
        st.text_input('Fonte das propriedades do U',key='cp_manual_source')
        st.caption('Informe propriedades reais. O editor não substitui o U por uma seção I nem recalcula o centroide como bf/2.')
    s=st.session_state
    family=s.get('_cp_manual_draft',{}).get('family',previous.column.family)
    profile=Profile(s.cp_manual_name,family,s.cp_column_mass,
        **{name:s['cp_column_'+name] for name in ('d','bf','tw','tf','clear','area')},source=s.cp_manual_source)
    s['_cp_manual_draft']=asdict(profile)
    return profile


def _anchor_widgets():
    concrete_summary('cp')
    projection_widget('cp')
    with st.expander('Concreto junto aos chumbadores · dados da civil'):
        _select('Tipo da ancoragem',ANCHOR_TYPES,'anchor_type',ANCHOR_TYPES)
        _select('Cone de tração',['off','aci318_19'],'cone_model',
                {'off':'Não selecionado','aci318_19':'ACI 318-19 · concreto fissurado'})
        st.caption('A civil dimensiona o bloco e a fundação. Aqui entram somente a geometria real e os dados necessários às rupturas locais dos chumbadores/concreto: cone, bordas, pullout, pryout e interação. Não há cálculo de armadura ou solo.')
        if st.session_state.cp_cone_model=='off' and st.session_state.cp_cc_model=='off':
            st.caption('Selecione o cone ou os modos complementares ACI para abrir os dados necessários. As entradas já salvas são conservadas; ausência de verificação permanece pendente quando há ação nos chumbadores.')
            return
        if st.session_state.cp_cone_model!='off':
            with st.popover('Avançado · envelope adicional do cone'):
                st.checkbox('Envelope suplementar de subconjuntos tracionados',key='cp_cone_subset_envelope')
        number_input('Embutimento efetivo hef (mm)',min_value=.1,key='cp_hef')
        block_geometry_widgets('cp')
        number_input('Altura real do bloco h (mm)',min_value=.1,key='cp_block_h')
        if st.session_state.cp_anchor_type in ('headed','buried_nut','buried_plate_nut'):
            with st.popover('Avançado · geometria do apoio enterrado'):
                for name,label in [('anchor_head_length','Apoio enterrado · extensão x'),('anchor_head_width','Apoio enterrado · extensão y'),
                                   ('anchor_bearing_t','Espessura da peça de apoio'),('anchor_head_t','Extensão abaixo do apoio'),
                                   ('anchor_bottom_cover','Cobrimento inferior livre')]:
                    number_input(label+' (mm)',min_value=0.,key='cp_'+name)
                if st.session_state.cp_anchor_type=='buried_plate_nut':
                    number_input('Espessura da porca inferior (mm)',min_value=0.,key='cp_anchor_nut_t')
                    number_input('Diâmetro do furo da chapa enterrada (mm)',min_value=0.,key='cp_anchor_head_hole')
                if st.session_state.cp_anchor_type=='buried_nut':
                    number_input('Área líquida de apoio da porca (mm²)',min_value=0.,key='cp_anchor_nut_bearing_area')
        else:
            st.caption('Geometria de cabeça/porca/chapa oculta para este tipo de ancoragem; valores anteriores preservados. O mecanismo resistente da ancoragem continua a verificar.')
        st.text_input('Referência do detalhe de ancoragem',key='cp_anchor_detail_ref')
        st.checkbox('Ancoragem moldada no local, apoio mecânico definido e concreto íntegro, sem bainha livre na transferência.',key='cp_anchor_detail_confirmed')
        st.caption('hef começa no topo do concreto. O bloco real não é substituído por dimensões mínimas de tabela. Gancho e barra sem cabeça não recebem resistência nativa presumida.')


def _washer(c):
    """Expose the existing local washer component without fabricating capacity."""
    s=st.session_state
    if c.direct_anchor_shear:
        st.caption('Arruela superior axial apenas: dimensões preservadas, sem crédito lateral ou solda da arruela na rota direta.')
        return c
    if c.shear_path=='anchors' or (c.anchor_count==2 and c.N<0):
        with st.expander('Arruelas superiores · soldas e furo'):
            _select('Verificações locais da arruela superior',(['fitted_direct','off','four_edge_elastic'] if c.anchor_count==2 else ['off','four_edge_elastic']),'uw_model',
                {'off':'Não selecionadas · pendentes','fitted_direct':'Furo ajustado · apoio direto · porca pesada normalizada','four_edge_elastic':'Modelo legado · quatro filetes e furo; alcance parcial'})
            if s.cp_uw_model!='off':
                _select('Contorno de solda de cada arruela',['unspecified','four_edges'],'uw_layout',
                    {'unspecified':'Não confirmado','four_edges':'Quatro bordas externas contínuas · filetes iguais'})
                number_input('Perna w dos filetes da arruela (mm)',min_value=0.,key='cp_uw_leg')
                _select('Aço da arruela',['unspecified','ASTM A572 Gr.50'],'uw_steel',
                    {'unspecified':'Não informado','ASTM A572 Gr.50':'ASTM A572 Gr.50 · fy=345 MPa · fu=450 MPa'})
                _select('Processo de soldagem da arruela',['unspecified','smaw_e7018_single_pass'],'uw_process',
                    {'unspecified':'Não informado','smaw_e7018_single_pass':'SMAW E7018 · passe único'})
                if c.base_hole>0:
                    s.cp_uw_base_hole=c.base_hole
                    st.caption('Furo da placa sob a arruela: Dbase='+number(c.base_hole)+' mm, informado acima. Furo da própria arruela: dh=db+1,5='+number(c.anchor_washer_hole)+' mm. São aberturas distintas; não há segunda entrada de Dbase.')
                else:
                    number_input('Furo circular real sob a arruela (mm)',min_value=0.,key='cp_uw_base_hole')
                    st.caption('A referência de tabela não confirma o furo executado. Informe o diâmetro real, igual ao usado na geometria da placa.')
                if s.cp_uw_model=='fitted_direct':
                    _select('Alinhamento dos furos da arruela e da placa',['unspecified','joint_drilled','specified_tolerance'],'washer_alignment',
                        {'unspecified':'Não especificado','joint_drilled':'Furação conjunta após solda · coincidência efetiva','specified_tolerance':'Tolerância máxima entre centros especificada'})
                    if s.cp_washer_alignment=='specified_tolerance':
                        number_input('Desvio máximo δ entre centros dos furos (mm)',min_value=0.,key='cp_washer_offset_tolerance')
                    _select('Porca superior normalizada',['unspecified','a563_a_heavy_hex_unc'],'washer_nut_type',
                        {'unspecified':'Não especificada','a563_a_heavy_hex_unc':'ASTM A563 Grade A · pesada heavy hex · UNC'})
                    st.checkbox('Detalhe especificado: assentamento direto contínuo, sem vazio/calço, rosca e acabamento compatíveis e engate integral da porca.',key='cp_washer_detail_confirmed')
                    st.caption('Condição: Dbase+2δ≤dh. Esta rota não reduz furos importados. Furo ajustado tem menor tolerância de montagem; furação conjunta deve constar do detalhe de fabricação. A folga da barra dentro do furo entra automaticamente na área conservadora de contato.')
                    st.caption('Solda/corte para Fv,Rd não reduzido. Apoio axial direto com porca normalizada; sem inventar modelo de ponte sobre furo alargado. Quatro filetes são as bordas de cada arruela, não o número de chumbadores.')
                else:
                    st.checkbox('Arruela, barra e furo circular da placa concêntricos, sem calço ou afastamento.',key='cp_uw_centered')
                    st.caption('Lado e espessura são os informados acima. O modelo legado conserva seu envelope e alcance parcial.')
    u=UpperWasher(**{name:s.get('cp_uw_'+name,old) for name,old in asdict(c.upper_washer).items()})
    return replace(c,upper_washer=u,**{name:s.get('cp_'+name,getattr(c,name)) for name in ('washer_alignment','washer_offset_tolerance','washer_nut_type','washer_detail_confirmed')})


def _fill_symmetric_shear():
    """Explicit geometry-based helper; does not qualify the physical load path."""
    s=st.session_state
    if s.cp_anchor_layout!='two_symmetry' or s.cp_offset_y!=0 or s.cp_shear_path!='anchors':
        return
    value=abs(s.cp_V_kgf)/2.
    s.cp_cc_force_a1=value
    s.cp_cc_force_a2=value
    # A3/A4 and source/confirmation fields remain untouched. The qualification
    # signature is recomputed by _components and invalidates stale confirmations.


def _components(c):
    s=st.session_state;u=c.concrete_components
    with st.expander('Ancoragem ACI · modos complementares'):
        mode=st.selectbox('Verificações complementares da ancoragem',['off','aci318_19'],key='cp_cc_model',
                          format_func=lambda v:'Não selecionadas' if v=='off' else 'ACI 318-19 · dados explícitos')
        if mode!='off':
            st.caption('Dados da ancoragem real. Área de apoio e resistência mecânica da cabeça não são adotadas automaticamente. Os estados de corte da rota direta são gerados pelo método, não por qualificação manual.' if c.direct_anchor_shear else 'Dados da ancoragem real. Nenhum V/4, área de apoio ou resistência de cabeça é adotado automaticamente.')
            if c.N<0:
                number_input('Área efetiva de apoio enterrado Abrg (mm²)',min_value=0.,key='cp_cc_bearing_area')
                st.text_input('Fonte da área de apoio',key='cp_cc_bearing_area_ref')
                number_input('Resistência mecânica do apoio por barra (kgf)',min_value=0.,key='cp_cc_mechanical_resistance')
                st.text_input('Memória mecânica do apoio enterrado',key='cp_cc_mechanical_ref')
            if c.N<0 or (c.V!=0 and c.shear_path=='anchors'):
                number_input('Área efetiva rosqueada Ase,N (mm²)',min_value=0.,key='cp_cc_area_tension')
                if c.V!=0 and c.shear_path=='anchors':
                    number_input('Área efetiva no corte Ase,V (mm²)',min_value=0.,key='cp_cc_area_shear')
                st.text_input('Fonte das áreas efetivas da barra',key='cp_cc_steel_area_ref')
                st.checkbox('Ductilidade ACI comprovada',key='cp_cc_ductile')
                if s.cp_cc_ductile:st.text_input('Referência da ductilidade',key='cp_cc_ductility_ref')
            if c.V!=0 and c.shear_path=='anchors' and not c.direct_anchor_shear:
                if c.anchor_count==2:
                    st.caption('Duas barras idênticas em x=0 e ey=0: o equilíbrio sem torção exige V1=V2=|V|/2. Informe e qualifique esse vetor; A3/A4 ficam inativos e seus dados são conservados para o arranjo de quatro.')
                    if c.offset_y==0:
                        st.button('Preencher cortante simétrico V/2',on_click=_fill_symmetric_shear,key='cp_fill_symmetric_shear')
                        st.caption('Preenchimento por equilíbrio do arranjo simétrico. A confirmação do caminho físico e dos modos da ancoragem continua necessária; as referências não são preenchidas automaticamente.')
                for i in range(1,c.anchor_count+1):number_input(f'Cortante documentado A{i} (kgf)',min_value=0.,key=f'cp_cc_force_a{i}')
                st.text_input('Memória da distribuição física do cortante',key='cp_cc_distribution_ref')
                st.selectbox('Bordas paralelas ao cortante',['pending','virtual_perpendicular'],key='cp_cc_parallel_model',
                    format_func=lambda v:'Pendente' if v=='pending' else 'Construção perpendicular virtual ACI')
                st.checkbox('Envelope suplementar de linhas',key='cp_cc_optional_envelope')
            elif c.V!=0 and c.direct_anchor_shear:
                st.caption('Estados automáticos e alternativos: uniforme, linha dianteira e linha oposta para quatro barras; V/2 para duas barras transversais. Não são forças simultâneas.')
                st.caption('Mecanismos perpendiculares virtuais ACI incluídos automaticamente nas bordas paralelas, sem girar V nem criar torção.')
    values={}
    for name,old in asdict(u).items():
        value=s.get('cp_cc_'+name,old/KGF if name in _CC_LOADS else old)
        values[name]=_canonical(value,old,KGF) if name in _CC_LOADS else value
    u=replace(u,**values);c=replace(c,concrete_components=u)
    if u.model!='off':
        with st.expander('Confirmações do detalhe e da combinação'):
            if c.N<0:
                sig=bearing_signature(c)
                yes=st.checkbox('A área e a memória mecânica correspondem ao detalhe enterrado atual.',
                    value=bool(u.bearing_confirmation) and u.bearing_confirmation==sig,key='cp_bearing_confirm_'+sig[:20])
                u=replace(u,bearing_confirmation=sig if yes else '')
            if c.V!=0 and c.shear_path=='anchors' and not c.direct_anchor_shear:
                sig=distribution_signature(replace(c,concrete_components=u))
                yes=st.checkbox('A memória citada verifica estas forças por barra e o caminho físico desta combinação.',
                    value=bool(u.distribution_confirmation) and u.distribution_confirmation==sig,key='cp_distribution_confirm_'+sig[:20])
                u=replace(u,distribution_confirmation=sig if yes else '')
            st.caption('A confirmação registra aplicabilidade da memória externa; não verifica seu conteúdo.')
    for name in ('bearing_confirmation','distribution_confirmation'):s['cp_cc_'+name]=getattr(u,name)
    return replace(c,concrete_components=u)


def _current(previous,column):
    s=st.session_state;values={'column':column}
    for f in fields(previous):
        if not f.init or f.name in _NESTED:continue
        old=getattr(previous,f.name)
        if f.name in _LOADS:values[f.name]=_canonical(s['cp_'+f.name+'_kgf'],old,KGF)
        else:values[f.name]=s.get('cp_'+f.name,old)
    values['direct_shear']=direct_shear_from_state(prefix='cp')
    return replace(previous,**values)


def render():
    s=st.session_state
    previous=ChannelBasePlate.from_dict(s[PROJECT],validate_values=False) if PROJECT in s else next(iter(PRESETS.values()))
    if PROJECT not in s:seed(previous)
    else:_state(previous,overwrite='cp_column_name' not in s)
    with st.sidebar:
        st.caption('LRO Ligações · '+VERSION)
        st.selectbox('Exemplos de base U',list(PRESETS),key='cp_example')
        st.button('Usar exemplo de base U',on_click=load_example,use_container_width=True)
        st.file_uploader('Abrir projeto de base U',type=['json'],key='cp_upload')
        st.button('Abrir base U JSON',on_click=load_json,use_container_width=True)
        if 'cp_import_error' in s:st.error(s.cp_import_error)
        st.caption('Exemplos são testes didáticos com ações explícitas; não representam um projeto executado.')
    st.title(FAMILY)
    st.caption('Perfil U assimétrico · dois ou quatro chumbadores · sem momento aplicado · modelo local com hipóteses explícitas')
    st.text_input('Identificação da base U',key='cp_project')
    left,right=st.columns([.95,1.4],gap='large')
    with left:
        column=profile_widget(previous)
        _select('Aço do pilar U',STEELS,'column_steel')
        info=catalog_properties(column)
        if info is not None:
            st.checkbox('Centroide automático do catálogo Gerdau',key='cp_centroid_from_catalog')
            if s.cp_centroid_from_catalog:
                s.cp_centroid_back=info['ec_mm']
                st.caption('ec = '+number(info['ec_mm'])+' mm, automático (x publicado × 10, medido do dorso da alma).')
            else:
                number_input('Centroide ec a partir do dorso da alma (mm)',min_value=.01,key='cp_centroid_back')
                st.caption('Substituição manual do centroide publicado; conferir a fonte da seção real.')
        else:
            s.cp_flange_thickness_from_model=False
            s.cp_centroid_from_catalog=False
            number_input('Centroide ec a partir do dorso da alma (mm)',min_value=.01,key='cp_centroid_back')
        number_input('Comprimento reto verificado T entre raízes (mm)',min_value=0.,key='cp_straight_web_length')
        st.caption('Zero = não informado. Gerdau não publica T: d−2tf é apenas envelope provisório, não comprimento livre real. Para seção manual, clear informado continua disponível.')
        st.checkbox('Comprimento livre entre raízes das mesas e acesso das arruelas/soldas conferidos no detalhe real.',key='cp_clear_geometry_confirmed')
        if info is not None:
            st.checkbox('Espessura nominal automática da ponta · hipótese 16,14%',key='cp_flange_thickness_from_model')
        if s.cp_flange_thickness_from_model:
            st.caption('tmin,nom = '+number(nominal_flange_tip(column))+' mm. '+FLANGE_TAPER_ASSUMPTION)
        else:
            number_input('Espessura mínima real da mesa junto à solda (mm)',min_value=0.,key='cp_flange_min_thickness')
            st.caption('Entrada manual/legada preservada. Zero = pendente. Ative a hipótese nominal explicitamente para substituir o valor usado; a entrada manual é conservada ao alternar o modo.')
        st.subheader('Ações de cálculo')
        number_input('Axial N (kgf)',key='cp_N_kgf')
        number_input('Cortante V paralelo à alma (kgf)',key='cp_V_kgf')
        st.caption('N positivo = compressão; N negativo = tração. N/V já majorados na face superior da placa. M aplicado=0.')
        st.subheader('Placa e grupo de chumbadores')
        _select('Arranjo dos chumbadores',['four','two_symmetry'],'anchor_layout',
                {'four':'Quatro · (±ax, ±ay)','two_symmetry':'Dois · atrás da alma e à frente da abertura · eixo x=0'},on_change=_layout_changed)
        for name,label in [('L_plate','Comprimento L'),('B_plate','Largura B'),('tp','Espessura tp')]:
            number_input(label+' (mm)',min_value=.1,key='cp_'+name)
        if s.cp_anchor_layout=='four':number_input('Semiespaçamento ax (mm)',min_value=.1,key='cp_anchor_x')
        number_input('Semiespaçamento ay (mm)',min_value=.1,key='cp_anchor_y')
        if s.cp_anchor_layout=='four' and '_cp_washer_mode_two_symmetry' in s:
            st.caption('O modelo ajustado novo pertence à configuração de duas barras; ao voltar a quatro, usa-se a escolha legada guardada ou não selecionada. Os demais dados são conservados.')
        if s.cp_anchor_layout=='two_symmetry':
            st.caption('Duas barras em (0,−ay) e (0,+ay), no eixo de simetria do U: uma atrás da alma e outra à frente da abertura. ax é conservado para voltar ao arranjo de quatro, sem efeito neste modo. U/2 é adaptação mecânica: a Tabela 18 NBR trata disposições com 4–8 barras.')
        number_input('Deslocamento ey do centroide do U (mm)',key='cp_offset_y')
        st.caption('Placa centrada no centroide real quando ey=0. ey≠0 gera N·ey; contato parcial e V nas barras com torção ficam fora do domínio. O centroide publicado é conservado, sem substituição por bf/2.')
        _select('Aço da placa',[name for name,steel in STEELS.items() if steel.plate_allowed],'plate_steel')
        choices=dict(CHANNEL_ANCHORS)
        if direct_selected('cp'):choices.update(METRIC_ANCHORS);choices.update(UNC_ANCHORS)
        _select('Diâmetro real da haste' if direct_selected('cp') else 'Chumbador ASTM A36 · diâmetro',list(dict.fromkeys(choices.values())),'db',
                {value:label+' · '+number(value,3)+' mm' for label,value in choices.items()})
        if not direct_selected('cp'):
            number_input('Furo circular real da placa (mm; zero = referência tabelada, quando disponível)',min_value=0.,key='cp_base_hole')
        else:st.caption('Contato direto: o furo real d0 é informado na seção própria. O furo legado fica preservado, sem redução ou conversão automática.')
        if s.cp_anchor_layout=='two_symmetry':st.caption('Furo explícito neste arranjo. Ao selecionar duas barras, um valor tabelado pode ser sugerido como geometria editável; a origem do valor não valida a configuração U/2 pela Tabela 18.')
        st.caption('3/8, 1/2 e 5/8 pol. exigem furo real explícito e detalhe específico. Não há linha de referência implementada na Tabela 18 para esses diâmetros; as verificações resistentes continuam ativas.')
        number_input('Lado da arruela superior (mm)',min_value=.1,key='cp_anchor_washer_side')
        number_input('Espessura da arruela superior (mm)',min_value=.1,key='cp_anchor_washer_t')
        _select('Caminho resistente do cortante',['friction','anchors'],'shear_path',
                {'friction':'Atrito no graute','anchors':'Chumbadores retos · V integral, sem atrito'})
        if s.cp_shear_path=='anchors':
            _select('Modelo dos chumbadores',['welded_washer','direct_plate_bearing'],'anchor_shear_model',MODEL_LABELS)
            if s.cp_anchor_shear_model=='direct_plate_bearing':direct_shear_widgets('cp')
            else:st.caption('Arruelas superiores soldadas: interação tração–corte, limite local do concreto e ancoragem separados. Sem crédito de atrito.')
        st.caption('Barra reta descreve o fuste; defina a cabeça, porca/placa enterrada ou mecanismo real. Reto sem cabeça não recebe aderência ou arrancamento presumidos.')
        st.subheader('Concreto, graute e solda U–placa')
        number_input('Perna z do filete contínuo E7018 (mm)',min_value=.1,key='cp_weld_size')
        with st.expander('Concreto e assentamento',expanded=False):
            for name,label in [('fck','fck do concreto (MPa)'),('grout_fck','fck do graute (MPa)'),('grout_t','Espessura do graute (mm)')]:
                number_input(label,min_value=.1,key='cp_'+name)
            st.caption('Valores adotados para esta verificação. O app não substitui o concreto existente por um valor que apenas faça o cálculo passar; confirme as premissas com a disciplina civil.')
        st.caption('Solda própria do U: duas linhas úteis de alma e faces exteriores das mesas; excentricidade do centroide preservada. Sem crédito a quinas ou retornos. Na mesa, mínimo suficiente conservador Tabela 11(tp), não mínimo normativo exato universal; junta T sem teto de borda t ou t−1,5. Conferir acesso e geometria real.')
        _anchor_widgets()
        st.text_area('Notas do projeto',key='cp_notes')
        c=_current(previous,column)
        c=_washer(c)
        c=_components(c)
    result=evaluate(c)
    s[PROJECT]=c.to_dict();s[RESULT]=result
    raw=json.dumps(c.to_dict(),ensure_ascii=False,allow_nan=False,sort_keys=True).encode('utf-8')
    digest=hashlib.sha256(raw).hexdigest()
    if s.get('cp_report') and s.cp_report[0]!=digest:s.pop('cp_report',None)
    valid=bool(result.geometry) and not any(i.severity=='error' for i in result.issues)
    with right:
        status=result.component_outcome
        (st.error if status in ('invalid','fail') else st.warning if status=='pending' else st.success)(result.status)
        st.caption(result.calculation_note)
        direct_shear_results(c,result)
        if valid:
            st.image(image_bytes(c,result),use_container_width=True)
            g=result.geometry
            if c.N>0:st.caption('Painel U: '+g['panel_method'])
            a,b=st.columns(2)
            a.metric('Espessura requerida local',number(g['t_required'])+' mm')
            b.metric('Tração de projeto máxima por barra',number(g['Ft_max']/KGF)+' kgf')
            st.caption('qmin='+number(g['qmin'])+'; qmax='+number(g['sigma'])+' MPa. Momento local N·ey='+number(g['local_moment_x']/(KGF*1000))+' kgf·m.')
            with st.expander('Reações individuais e equilíbrio'):
                nominal={v['id']:v for v in g.get('nominal_rods',g['rods'])}
                st.dataframe(pd.DataFrame([{'Barra':v['id'],'x (mm)':number(v['x']),'y (mm)':number(v['y']),
                    'Tração nominal (kgf)':number(nominal[v['id']]['tension']/KGF),
                    'Tração de projeto (kgf)':number(v['tension']/KGF)} for v in g['rods']]),hide_index=True,width='stretch')
                if g.get('prying_factor',1.)!=1.:
                    st.caption('Tração de projeto inclui fator de alavanca '+number(g['prying_factor'])+'. O equilíbrio usa reações nominais; o acréscimo é envelope de dimensionamento.')
                st.caption('Resíduos: N='+number(g['residual_N'])+' N; Mx='+number(g['residual_Mx'])+'; My='+number(g['residual_My'])+' N·mm.')
        for issue in result.issues:
            (st.error if issue.severity=='error' else st.info if issue.severity=='info' else st.warning)(issue.text if issue.origin=='channel_flange_model' else calculated_text(issue.text))
    if result.checks:
        st.subheader('Verificações realizadas')
        st.dataframe(pd.DataFrame(checks_rows(result),columns=HEADERS),hide_index=True,width='stretch')
        st.download_button('Baixar verificações da base U CSV',pd.DataFrame(checks_rows(result),columns=HEADERS).to_csv(index=False).encode('utf-8-sig'),'Verificacoes_base_U_LRO.csv','text/csv')
        with st.expander('Equações, substituições e referências'):
            for row in result.checks:
                st.write(row.name+' · '+row.equation)
                st.caption(calculated_text(row.substitution))
                st.caption(row.reference)
    if valid:
        with st.expander('Interface com a disciplina civil · ações e limites'):
            st.write('Entregar N/V de cálculo da ligação, pressão de contato, posições e trações por chumbador. As reações nominais equilibram as ações externas; o envelope 1,4Ti de alavanca é identificado separadamente, sem somá-lo novamente às ações.')
            st.caption('N='+number(c.N/KGF)+' kgf; V='+number(c.V/KGF)+' kgf; C='+number(result.geometry['C']/KGF)+' kgf; qmin/qmax='+number(result.geometry['qmin'])+' / '+number(result.geometry['sigma'])+' MPa. Coordenadas e forças por barra estão em “Reações individuais e equilíbrio”.')
            st.caption('Bloco armado, estabilidade da fundação, solo, fendilhamento/detalhamento e compatibilização com a civil permanecem fora desta memória local. Dados fictícios ou ausentes não validam a ancoragem da obra.')
    st.subheader('Projeto e memória')
    a,b=st.columns(2)
    a.download_button('Salvar projeto de base U JSON',raw,'Base_U_rotulada_LRO.json','application/json',use_container_width=True)
    if valid:b.download_button('Baixar desenho da base U SVG',image_bytes(c,result,'svg'),'Base_U_rotulada_LRO.svg','image/svg+xml',use_container_width=True)
    mc_excerpt_widget(c,result,'cp',digest,valid,create_mc_excerpt)
    detailed=st.checkbox('Memória detalhada da base U',key='cp_detailed')
    if st.button('Gerar memória da base U',disabled=not valid):
        try:s.cp_report=(digest,detailed,create_report(c,result,detailed))
        except ValueError as exc:st.warning(str(exc));s.pop('cp_report',None)
    saved=s.get('cp_report')
    if saved and saved[0]==digest and saved[1]==detailed:
        st.download_button('Baixar memória da base U .docx',saved[2],'Memoria_base_U_rotulada_LRO.docx','application/vnd.openxmlformats-officedocument.wordprocessingml.document')
    with st.expander('Premissas, fontes e alcance do modelo'):
        for text in c.assumptions:st.write(text)
    st.caption(BRAND)
