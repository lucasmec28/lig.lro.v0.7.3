"""Bounded cast-in headed-anchor pullout and side-face blowout.

Pure dict API: forces N, dimensions mm, areas mm2, concrete strength MPa.
ACI 318-19 complement to the NBR model, static cracked normalweight concrete.
The application must confirm intact concrete and actual assembly fit. No head,
nut or plate mechanical strength is manufactured from concrete bearing area.
See docs/HEADED_ANCHORS_V086.md and the independent research fixtures.
"""
import math

INCH = 25.4
LBF = 4.4482216152605
PSI = LBF / INCH**2
PHI = 0.70
SOURCE = ('ACI 318-19, 17.6.3/17.6.4; AISC DG1 3ª ed., pp.29–33; '
          'base complementar N/mm/MPa, concreto normal fissurado, estático, φ=0,70')
_FAMILIES = ('headed', 'buried_nut', 'buried_plate_nut')
_EDGES = ('left', 'right', 'bottom', 'top')
_EDGE_LABEL = {'left': 'esquerda', 'right': 'direita', 'bottom': 'inferior em planta', 'top': 'superior em planta'}


def _finite(value):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return False
    try:
        return math.isfinite(value)
    except (OverflowError, ValueError):
        return False


def _roundoff_equal(a, b, geometry_scale):
    # 32 binary64 rounding units, tied to the coordinates that were subtracted.
    # This is numerical boundary handling, not a physical spacing allowance.
    tolerance = (32*2.220446049250313e-16)*max(1.0, abs(a), abs(b), geometry_scale)
    return abs(a-b) <= tolerance


def _susceptible(hef, c, geometry_scale):
    boundary = 2.5*c
    return hef > boundary and not _roundoff_equal(hef, boundary, geometry_scale)


def _text(value):
    return isinstance(value, str) and bool(value.strip())


def _mode(status, reasons=None, checks=None, **extra):
    return dict(status=status, checks=checks or [], reasons=reasons or [], **extra)


def _check(cid, label, rods, resistance, nominal, method, **extra):
    demand = sum(r['tension'] for r in rods)
    if not all(_finite(v) for v in (demand, resistance, nominal)) or resistance <= 0 or nominal <= 0:
        raise ValueError('Escala numérica fora do domínio do cálculo de ancoragem.')
    ratio = demand / resistance
    if not _finite(ratio):
        raise ValueError('Relação solicitação/resistência não finita.')
    return dict(id=cid, label=label, ids=[r['id'] for r in rods], demand=demand,
                resistance=resistance, ratio=ratio, nominal=nominal, phi=PHI,
                method=method, **extra)


def _distances(rod, bounds):
    xmin, ymin, xmax, ymax = bounds
    return dict(left=rod['x']-xmin, right=xmax-rod['x'], bottom=rod['y']-ymin, top=ymax-rod['y'])


def _side_basic(c, area, fc):
    # Coefficient160 is strictly inch/psi/lbf; do not insert it into an SI expression.
    return 160*(c/INCH)*math.sqrt(area/INCH**2)*math.sqrt(fc/PSI)*LBF


def _single(rod, bounds, area, fc, basis='source', screened_edges=None):
    distances = _distances(rod, bounds)
    edge = min(_EDGES, key=lambda e: distances[e])
    c1 = distances[edge]
    perpendicular = ('bottom', 'top') if edge in ('left', 'right') else ('left', 'right')
    c2 = min(distances[e] for e in perpendicular)
    corner = min(1.0, (1.0+c2/c1)/4.0)
    nominal = _side_basic(c1, area, fc)*corner
    label = 'Ruptura lateral do concreto · barra '+rod['id']
    if basis != 'source':
        label += ' · envoltória conservadora de barra isolada'
    return _check('headed_sideface_single_'+rod['id']+('' if basis == 'source' else '_envelope'),
                  label, [rod], PHI*nominal, nominal, 'ACI 17.6.4.1/17.6.4.1.1',
                  edge=edge, ca1=c1, ca2=c2, bearing_area=area,
                  factors=dict(alpha_corner=corner, lambda_a=1.0), basis=basis,
                  screened_edges=screened_edges or [edge])


def _invalid(reason):
    return dict(pullout=_mode('invalid', [reason]), sideface=_mode('invalid', [reason]),
                prerequisites=dict(status='invalid', reasons=[reason]), source=SOURCE)


def evaluate_headed(anchors, bounds, hef, fc, bearing_area, detail):
    """Evaluate independent concrete components without implying full anchorage.

    anchors: one to four actual rods {id:str,x,y,tension}, concurrent forces only.
    bounds: (xmin,ymin,xmax,ymax), actual intact concrete prism in plan.
    detail: family, bearing_area_ref, effective_area_qualified(bool),
      detail_confirmed(bool), detail_ref; optional mechanical_resistance(N),
      mechanical_ref, isolated_envelope(bool, defaultFalse). Optional
      actual_available_bearing_area is the caller's validated geometric cap.
    For a plate, area qualification and a documented adequate mechanical design
    resistance are mandatory. Optional qualified_bearing_area binds that proof
    to the current area; the outer application owns assembly-change invalidation
    and computes the geometric cap from the actual head/nut/plate dimensions.

    Mode statuses: calculated, pending, not_applicable, not_demanded, invalid.
    'calculated' is not a strength pass: inspect every check.ratio and prerequisites.
    Side-face uses one susceptible normal-distance row per face (max two rods).
    Unsupported faces keep other computed faces visible and the mode pending.
    """
    if not isinstance(detail, dict):
        return _invalid('O detalhe de ancoragem deve ser um dicionário explícito.')
    if not isinstance(bounds, (tuple, list)) or len(bounds) != 4:
        return _invalid('Informe os quatro limites reais do bloco (xmin,ymin,xmax,ymax).')
    if not all(_finite(v) for v in (*bounds, hef, fc, bearing_area)):
        return _invalid('Geometria, embutimento, concreto e área devem ser números finitos; booleanos não são dimensões.')
    if hef <= 0 or fc <= 0 or bearing_area <= 0:
        return _invalid('Embutimento, resistência do concreto e área líquida devem ser positivos.')
    xmin, ymin, xmax, ymax = bounds
    if xmin >= xmax or ymin >= ymax:
        return _invalid('Limites reais do bloco inconsistentes.')
    if not isinstance(anchors, (list, tuple)) or not 1 <= len(anchors) <= 4:
        return _invalid('O submodelo aceita de uma a quatro barras identificadas.')
    ids = []
    rods = []
    for rod in anchors:
        if not isinstance(rod, dict) or not _text(rod.get('id')):
            return _invalid('Cada barra requer uma identificação textual não vazia.')
        if any(not _finite(rod.get(k)) for k in ('x', 'y', 'tension')) or rod['tension'] < 0:
            return _invalid('Coordenadas e trações devem ser finitas; tração negativa não é convertida em positiva.')
        if not xmin < rod['x'] < xmax or not ymin < rod['y'] < ymax:
            return _invalid('O centro de cada barra deve estar dentro dos limites reais do concreto.')
        if not all(_finite(v) for v in _distances(rod, bounds).values()):
            return _invalid('Distâncias às bordas excedem o domínio numérico.')
        ids.append(rod['id'])
        rods.append({k: rod[k] for k in ('id', 'x', 'y', 'tension')})
    if len(ids) != len(set(ids)) or len({(r['x'], r['y']) for r in rods}) != len(rods):
        return _invalid('Identificações e centros de barras não podem estar repetidos.')
    for key in ('effective_area_qualified', 'detail_confirmed', 'isolated_envelope', 'intact_concrete', 'normalweight', 'cracked', 'seismic'):
        if key in detail and not isinstance(detail[key], bool):
            return _invalid('O campo '+key+' deve ser booleano explícito.')
    for key in ('mechanical_resistance', 'qualified_bearing_area', 'actual_available_bearing_area'):
        if detail.get(key) is not None and (not _finite(detail[key]) or detail[key] <= 0):
            return _invalid('O campo '+key+' deve ser positivo e finito quando informado.')
    geometry_scale = max(abs(v) for v in (*bounds, hef, *(r[k] for r in rods for k in ('x', 'y'))))
    rods.sort(key=lambda r: r['id'])
    active = [r for r in rods if r['tension'] > 0]

    physical_reasons = []
    if detail.get('family') not in _FAMILIES:
        physical_reasons.append('Família sem cabeça/porca mecânica moldada no local dentro do domínio suportado.')
    if detail.get('detail_confirmed') is not True or not _text(detail.get('detail_ref')):
        physical_reasons.append('Confirme e referencie concreto íntegro, contato mecânico real e implantação/altura da montagem enterrada.')
    if detail.get('intact_concrete') is False:
        physical_reasons.append('Bolsão vazio, espuma, bainha livre ou concreto não íntegro está fora deste modelo.')
    if detail.get('normalweight') is False or detail.get('cracked') is False or detail.get('seismic') is True:
        physical_reasons.append('Este submodelo é limitado a concreto normal fissurado e carregamento estático não sísmico.')
    if fc > 10000*PSI:
        physical_reasons.append('f\u2032c ultrapassa o limite de cálculo ACI de10000psi para chumbadores moldados no local; não houve truncamento automático.')

    area_reasons = []
    if not _text(detail.get('bearing_area_ref')) or detail.get('effective_area_qualified') is not True:
        area_reasons.append('A área líquida efetiva exige referência dimensional e qualificação vinculada ao detalhe atual.')
    qualified_area = detail.get('qualified_bearing_area')
    if qualified_area is not None and not math.isclose(qualified_area, bearing_area, rel_tol=1e-10, abs_tol=1e-8):
        area_reasons.append('A área qualificada na verificação não corresponde à área de apoio atual.')

    available_area = detail.get('actual_available_bearing_area')
    if available_area is not None and bearing_area > available_area and not math.isclose(bearing_area, available_area, rel_tol=1e-10, abs_tol=1e-8):
        area_reasons.append('A área de apoio creditada excede a área líquida geometricamente disponível do detalhe real.')

    mechanical_capacity = detail.get('mechanical_resistance')
    mechanical_ref = detail.get('mechanical_ref')
    mechanical_ready = mechanical_capacity is not None and _text(mechanical_ref)
    mechanical_checks = []
    mechanical_reasons = []
    if mechanical_ready:
        for rod in active:
            ratio = rod['tension']/mechanical_capacity
            if not _finite(ratio):
                return _invalid('Relação de resistência mecânica não finita.')
            mechanical_checks.append(dict(id='headed_mechanical_'+rod['id'], ids=[rod['id']],
                label='Cabeça/porca/chapa enterrada · resistência mecânica documentada',
                demand=rod['tension'], resistance=mechanical_capacity, ratio=ratio,
                nominal=None, phi=None, method='resistência de cálculo externa documentada', reference=mechanical_ref))
        mechanical_status = 'failed' if any(c['ratio'] > 1 for c in mechanical_checks) else 'verified'
    else:
        mechanical_status = 'pending'
        mechanical_reasons.append('Resistência da cabeça/porca/rosca e, quando presente, da chapa enterrada permanece sem verificação mecânica documentada.')
    if detail.get('family') == 'buried_plate_nut':
        if not mechanical_ready:
            area_reasons.append('Chapa enterrada não recebe área efetiva sem referência e resistência mecânica da montagem, incluindo flexão e retenção por porca/rosca.')
        elif mechanical_status == 'failed':
            area_reasons.append('A solicitação excede a resistência mecânica documentada da chapa; a área qualificada não é creditada além de sua capacidade.')

    prerequisites = dict(
        status='failed' if mechanical_status == 'failed' else ('pending' if physical_reasons or area_reasons or not mechanical_ready else 'verified'),
        detail=dict(status='pending' if physical_reasons else 'verified', reasons=physical_reasons, reference=detail.get('detail_ref')),
        bearing_area=dict(status='pending' if area_reasons else 'verified', reasons=area_reasons,
                          area=bearing_area, reference=detail.get('bearing_area_ref'), qualified_bearing_area=qualified_area,
                          actual_available_bearing_area=available_area),
        mechanical=dict(status=mechanical_status, checks=mechanical_checks, reasons=mechanical_reasons,
                        resistance=mechanical_capacity, reference=mechanical_ref),
        remaining_modes=['cone de tração', 'fendilhamento/cobrimentos/detalhamento', 'aço da barra',
                         'ruptura de concreto por cortante/pryout/interação', 'dimensionamento do bloco'],
        assembly_fit_basis='confirmação e referência do detalhe fornecidas pelo aplicativo')
    result = dict(pullout=_mode('pending'), sideface=_mode('pending'), prerequisites=prerequisites,
                  source=SOURCE, rods=rods, hef=hef, bearing_area=bearing_area,
                  assumptions=dict(cracked=True, normalweight=True, static=True, supplementary_reinforcement_credit=False))
    if not active:
        result['pullout'] = _mode('not_demanded')
        result['sideface'] = _mode('not_demanded')
        return result
    blockers = physical_reasons+area_reasons
    if blockers:
        result['pullout'] = _mode('pending', list(blockers))
        result['sideface'] = _mode('pending', list(blockers))
        return result

    try:
        nominal = 8*bearing_area*fc  # N/mm2/MPa is exactly coherent for this expression.
        checks = [_check('headed_pullout_'+r['id'], 'Arrancamento local do concreto · barra '+r['id'],
                         [r], PHI*nominal, nominal, 'ACI 17.6.3.1/17.6.3.2.2(a)',
                         bearing_area=bearing_area, factors=dict(psi_cP=1.0), basis='source') for r in active]
        result['pullout'] = _mode('calculated', checks=checks)
    except (ValueError, OverflowError, ZeroDivisionError) as exc:
        result['pullout'] = _mode('invalid', [str(exc)])

    susceptible = {e: [r for r in active if _susceptible(hef, _distances(r, bounds)[e], geometry_scale)] for e in _EDGES}
    edge_results = {e: dict(ids=[r['id'] for r in susceptible[e]],
                           distances=[_distances(r, bounds)[e] for r in susceptible[e]],
                           status='not_applicable') for e in _EDGES}
    if not any(susceptible.values()):
        result['sideface'] = _mode('not_applicable', edges=edge_results)
        return result
    # One/two aligned coordinate levels describe the bounded regular rectangular layout.
    if any(len({r[k] for r in rods}) > 2 for k in ('x', 'y')):
        result['sideface'] = _mode('pending', ['Arranjo não retangular de até duas linhas/colunas; requer avaliação específica.'], edges=edge_results)
        return result

    checks = []
    reasons = []
    opposed_ids = {}
    for rod in active:
        distances = _distances(rod, bounds)
        pairs = [(a, b) for a, b in (('left', 'right'), ('bottom', 'top'))
                 if _susceptible(hef, distances[a], geometry_scale) and _susceptible(hef, distances[b], geometry_scale)]
        if pairs:
            opposed_ids[rod['id']] = pairs
            reasons.append('Barra '+rod['id']+': suscetível em duas faces opostas; geometria estreita fora do ramo lateral limitado, exige avaliação específica (limite de escopo do aplicativo).')
    singleton_requests = {}
    try:
        for edge in _EDGES:
            row = susceptible[edge]
            if not row:
                continue
            distances = [_distances(r, bounds)[edge] for r in row]
            if len(set(distances)) != 1 or len(row) > 2:
                edge_results[edge]['status'] = 'pending'
                reasons.append('Borda '+_EDGE_LABEL[edge]+': mais de uma profundidade/linha suscetível à ruptura lateral; interação não verificada neste submodelo.')
                continue
            c = distances[0]
            edge_results[edge]['status'] = 'calculated'
            if len(row) == 1:
                singleton_requests.setdefault(row[0]['id'], []).append(edge)
                continue
            tangent = 'y' if edge in ('left', 'right') else 'x'
            spacing = abs(row[1][tangent]-row[0][tangent])
            if spacing < 6*c and not _roundoff_equal(spacing, 6*c, geometry_scale):
                factor = 1+spacing/(6*c)
                nominal = factor*_side_basic(c, bearing_area, fc)
                checks.append(_check('headed_sideface_'+edge, 'Ruptura lateral do concreto · grupo na borda '+_EDGE_LABEL[edge],
                                     row, PHI*nominal, nominal, 'ACI 17.6.4.2', edge=edge,
                                     ca1=c, spacing=spacing, bearing_area=bearing_area, basis='source',
                                     factors=dict(alpha_group=factor, lambda_a=1.0, perpendicular_edge_modifier_applied=False)))
            else:
                edge_results[edge]['branch'] = 'independent_single_anchors'
                for rod in row:
                    singleton_requests.setdefault(rod['id'], []).append(edge)
        for rod in active:
            if rod['id'] in singleton_requests:
                candidate = _single(rod, bounds, bearing_area, fc, screened_edges=singleton_requests[rod['id']])
                # If the triggering face is not the nearest one, make the conservative
                # reorientation explicit rather than silently clamping ca2/ca1 to1.
                if candidate['edge'] not in singleton_requests[rod['id']]:
                    candidate['basis'] = 'conservative_nearest_face_reorientation'
                    candidate['label'] += ' · envoltória conservadora pela borda mais próxima'
                checks.append(candidate)
        if detail.get('isolated_envelope', False):
            checked = set(singleton_requests)
            for rod in active:
                if rod['id'] not in checked and _susceptible(hef, min(_distances(rod, bounds).values()), geometry_scale):
                    checks.append(_single(rod, bounds, bearing_area, fc, basis='supplemental_isolated_envelope'))
        if opposed_ids:
            for rod_id, pairs in opposed_ids.items():
                for pair in pairs:
                    for edge in pair:
                        edge_results[edge]['status'] = 'pending'
                        edge_results[edge]['geometry_review'] = 'opposing_faces_susceptible'
            for check in checks:
                if any(rod_id in opposed_ids for rod_id in check['ids']):
                    check['diagnostic_only'] = True
                    check['geometry_review'] = 'opposing_faces_susceptible'
        result['sideface'] = _mode('pending' if reasons else 'calculated', reasons, checks,
                                  edges=edge_results, isolated_envelope=detail.get('isolated_envelope', False),
                                  opposing_faces=opposed_ids)
    except (ValueError, OverflowError, ZeroDivisionError) as exc:
        result['sideface'] = _mode('invalid', reasons+[str(exc)], checks, edges=edge_results)
    return result
