"""Independent R015 UI, native persistence and conservative result presentation."""
from dataclasses import fields
import hashlib
import json
import math

import pandas as pd
import streamlit as st
from .load_conventions import render as render_load_convention

from .angle_catalog_ui import (render_selector as render_angle_catalog,
    draft_keys as angle_catalog_draft_keys, reset as reset_angle_catalog)
from .models import Profile, profiles, STEELS, BOLTS, KGF, VERSION
from .welded_double_angle import WeldedDoubleAngle, FAMILY, SCOPE, presets, evaluate
from .welded_double_angle_presentation import physical_envelopes, governing_description, component_label
from .report import BRAND, LINK, number

P = {name: p for name, p in profiles().items() if p.family == 'W'}
PRESETS = presets()
CUSTOM = 'W personalizado'
PROFILE_VALUES = ('d', 'bf', 'tw', 'tf', 'clear', 'area', 'mass')
LOAD_UNITS = {'V': KGF, 'N': KGF, 'M': KGF * 1000, 'torsion': KGF * 1000}
LOAD_KEYS = {'V': 'V_kgf', 'N': 'N_kgf', 'M': 'M_kgfm', 'torsion': 'torsion_kgfm'}
STATUS = {
    'INVALID_INPUT': 'DADOS INVÁLIDOS',
    'NUMERICAL_FAILURE': 'FALHA NUMÉRICA · CÁLCULO NÃO CONCLUÍDO',
    'INVALID_GEOMETRY': 'GEOMETRIA FISICAMENTE INVÁLIDA',
    'OUTSIDE_R015_SCOPE': 'FORA DO DOMÍNIO R015 · CORTANTE',
    'DETAIL_FAIL': 'NÃO ATENDE AO DETALHAMENTO',
    'VERIFIED_SUBCHECK_FAIL': 'NÃO ATENDE ÀS VERIFICAÇÕES REALIZADAS',
    'ENGINEERING_MODEL_PENDING': 'VERIFICAÇÃO COMPLEMENTAR PENDENTE',
    'COMPLETE_CHECKS_PASS_WITHIN_SCOPE': 'ATENDE ÀS VERIFICAÇÕES NO DOMÍNIO R015',
    'COMPLETE_CHECKS_PASS_WITH_PRESET_DEVIATION': 'ATENDE NO DOMÍNIO · DETALHE DIFERE DO PRESET R015',
}


def _draft_keys():
    keys = ['wa_' + f.name for f in fields(WeldedDoubleAngle) if f.name not in ('beam', 'support')]
    keys += ['wa_' + key for key in LOAD_KEYS.values()]
    for role in ('beam', 'support'):
        keys += ['wa_' + role + '_' + key for key in ('name', 'manual_name', 'family', 'source') + PROFILE_VALUES]
    return keys + angle_catalog_draft_keys('wa_')


def seed(c):
    # Stage all widget conversions before touching the accepted session. The
    # finite native integer 9007199254740993, for example, cannot be represented
    # by a binary64 profile control without losing a unit of metadata.
    c.to_dict()
    proposed = {}
    for f in fields(c):
        if f.name not in ('beam', 'support'):
            proposed['wa_' + f.name] = getattr(c, f.name)
    for key, unit in LOAD_UNITS.items():
        proposed['wa_' + LOAD_KEYS[key]] = getattr(c, key) / unit
    for role in ('beam', 'support'):
        p = getattr(c, role)
        prefix = 'wa_' + role + '_'
        proposed[prefix + 'name'] = p.name if p.name in P and p == P[p.name] else CUSTOM
        proposed[prefix + 'manual_name'] = p.name
        proposed[prefix + 'family'] = p.family
        proposed[prefix + 'source'] = p.source
        for key in PROFILE_VALUES:
            value = getattr(p, key)
            converted = float(value)
            if not math.isfinite(converted) or converted != value:
                raise ValueError(f'{role}.{key}: valor {value!r} não representável sem alteração '
                                 'no controle numérico de precisão binária de 64 bits.')
            proposed[prefix + key] = converted
    s = st.session_state
    for key, value in proposed.items():
        s[key] = value
    reset_angle_catalog('wa_')
    s.pop('wa_report', None)
    s.pop('_welded_double_angle_ui_draft', None)


def use_example():
    seed(PRESETS[st.session_state.wa_example])


def load_project():
    try:
        upload = st.session_state.wa_upload
        if upload is None:
            raise ValueError('Selecione um arquivo JSON.')
        if len(upload.getvalue()) > 200000:
            raise ValueError('Arquivo maior que 200 kB.')
        seed(WeldedDoubleAngle.from_dict(json.loads(upload.getvalue())))
        st.session_state.pop('wa_import_error', None)
    except (ValueError, TypeError, KeyError, OverflowError) as exc:
        st.session_state.wa_import_error = 'Não foi possível abrir: ' + str(exc)


def bolt_changed():
    hole = {16.: 18., 20.: 22., 24.: 26., 30.: 33.}.get(st.session_state.wa_db)
    if hole is not None:
        st.session_state.wa_hole_diameter = hole


def _select(label, options, key, labels=None, **kwargs):
    """Keep unsupported imported enum values visible, never silently normalize."""
    options = list(options)
    current = st.session_state.get(key)
    if current is not None and current not in options:
        options.append(current)
    if labels:
        kwargs['format_func'] = lambda value: labels.get(value, str(value) + ' · valor importado')
    return st.selectbox(label, options, key=key, **kwargs)


def _minimum(key, minimum):
    """Preserve legitimate imported dimensions below the normal display bound."""
    value = st.session_state.get(key)
    return min(minimum, float(value)) if _finite(value) else minimum


def _dimension(key, label, minimum=.01):
    return st.number_input(label + ' (mm)', min_value=_minimum('wa_' + key, minimum), key='wa_' + key)


def _profile(role, label):
    prefix = 'wa_' + role + '_'
    name = st.selectbox(label, [CUSTOM] + list(P), key=prefix + 'name')
    if name in P:
        p = P[name]
    else:
        with st.expander('Geometria personalizada · ' + label, expanded=True):
            designation = st.text_input('Designação · ' + label, key=prefix + 'manual_name')
            family = st.text_input('Família declarada · ' + label, key=prefix + 'family')
            values = {}
            for key, text in [('d', 'Altura d (mm)'), ('bf', 'Largura bf (mm)'),
                              ('tw', 'Alma tw (mm)'), ('tf', 'Mesa tf (mm)'),
                              ('clear', 'Altura livre das raízes (mm)'), ('area', 'Área A (mm²)'),
                              ('mass', 'Massa linear (kg/m)')]:
                values[key] = st.number_input(text + ' · ' + label, min_value=_minimum(prefix + key, .01), key=prefix + key)
            source = st.text_input('Fonte das dimensões/área · ' + label, key=prefix + 'source')
            p = Profile(designation, family, source=source, **values)
    st.caption(f'{label}: d={p.d:g}; bf={p.bf:g}; tw={p.tw:g}; tf={p.tf:g} mm; A={p.area:g} mm².')
    return p


def _force(key):
    """Preserve original JSON loads exactly until their display value is edited."""
    raw = st.session_state['wa_' + key]
    displayed = st.session_state['wa_' + LOAD_KEYS[key]]
    unit = LOAD_UNITS[key]
    if not _finite(raw) or not _finite(displayed):
        raise ValueError(f'{key}: número finito obrigatório.')
    if displayed == raw / unit:
        return raw
    converted = displayed * unit
    if not _finite(converted):
        raise ArithmeticError(f'{key}: a conversão da ação finita informada excedeu a faixa '
                              'numérica de cálculo em N ou N·mm.')
    return converted


def _finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def _kgf(value):
    return value / KGF if _finite(value) else None


def _display(value):
    return number(value, 3) if _finite(value) else '—'


def _checks_table(checks):
    rows = []
    for check in checks:
        rows.append({
            'ID': check.get('id', ''), 'Componente': component_label(check.get('component', '')),
            'Verificação': check.get('label', check.get('id', '')),
            'Solicitação real (kgf)': _kgf(check.get('actual_demand_N')),
            'Solicitação adotada (kgf)': _kgf(check.get('demand_N')),
            'Resistência (kgf)': _kgf(check.get('design_capacity_N')),
            'Índice real': check.get('actual_utilization'), 'Índice adotado': check.get('utilization'),
            'Resultado real': _check_status(check.get('actual_status')),
            'Resultado adotado': _check_status(check.get('status')),
            'Fórmula': check.get('formula', ''), 'Referência': check.get('reference', ''),
        })
    return pd.DataFrame(rows)


def _check_status(status):
    return {'PASS': 'ATENDE', 'FAIL': 'NÃO ATENDE'}.get(status, str(status or 'NÃO AVALIADO'))


def _envelopes_table(envelopes):
    rows = []
    for envelope in envelopes:
        actual, adopted = envelope['actual_governing'], envelope['adopted_governing']
        rows.append({
            'Componente físico': envelope['component_label'], 'Mecanismo': envelope['mechanism_label'],
            'Solicitação real (kgf)': _kgf(actual['actual_demand_N']),
            'Resistência · ramo real (kgf)': _kgf(actual['design_capacity_N']),
            'Índice real': envelope['actual_utilization'],
            'Caso / sentido / ramo real': governing_description(actual),
            'Solicitação adotada (kgf)': _kgf(adopted['demand_N']),
            'Resistência · ramo adotado (kgf)': _kgf(adopted['design_capacity_N']),
            'Índice adotado': envelope['adopted_utilization'],
            'Caso / sentido / ramo adotado': governing_description(adopted),
            'Resultado real': _check_status(envelope['actual_status']),
            'Resultado adotado': _check_status(envelope['status']),
            'Ramos preservados': len(envelope['members']),
        })
    return pd.DataFrame(rows)


def _complete_checks(checks):
    required = {'id', 'component', 'actual_demand_N', 'demand_N', 'design_capacity_N',
                'actual_utilization', 'utilization', 'actual_status', 'status'}
    numeric = required - {'id', 'component', 'actual_status', 'status'}
    return bool(checks) and all(
        isinstance(row, dict) and required <= row.keys() and
        all(_finite(row[key]) for key in numeric) and
        row['actual_status'] in ('PASS', 'FAIL') and row['status'] in ('PASS', 'FAIL')
        for row in checks)


def _input_failure(s, status, exc):
    """Keep the failed current edit distinct from the preceding valid project."""
    s['_welded_double_angle_result'] = {
        'status': status, 'global_pass': False, 'checks': [], 'summary': {},
        'geometry': {'valid': False},
        'issues': [{'severity': 'numerical_failure' if status == 'NUMERICAL_FAILURE' else 'invalid_input',
                    'text': str(exc)}],
    }
    st.error(STATUS[status])
    st.error(str(exc))
    st.caption('Nenhum resultado ou arquivo do cálculo anterior é válido para esta entrada. Corrija os dados para recalcular.')


def _approval_complete(result):
    """Never promote a partial or contradictory engine result to approval."""
    summary = result.get('summary') or {}
    checks = result.get('checks') or []
    blocking = {'invalid_input', 'numerical_failure', 'invalid_geometry', 'unsupported_scope', 'detail_fail',
                'engineering_pending', 'access_pending', 'error', 'pending', 'not_evaluated'}
    return (result.get('status') in ('COMPLETE_CHECKS_PASS_WITHIN_SCOPE',
                                     'COMPLETE_CHECKS_PASS_WITH_PRESET_DEVIATION')
            and result.get('global_pass') is True
            and summary.get('complete_checks') is True
            and (result.get('geometry') or {}).get('valid') is True
            and bool(checks)
            and all(isinstance(check, dict) and check.get('status') == 'PASS' for check in checks)
            and not any(isinstance(issue, dict) and issue.get('severity') in blocking
                        for issue in result.get('issues') or []))


def render():
    from .welded_double_angle_drawing import image_bytes, drawing_svg
    from .welded_double_angle_report import create_report

    s = st.session_state
    if 'wa_project' not in s:
        saved = s.get('_welded_double_angle_project')
        draft = s.get('_welded_double_angle_ui_draft')
        seed(WeldedDoubleAngle.from_dict(saved) if saved else next(iter(PRESETS.values())))
        if draft:
            for key, value in draft.items():
                s[key] = value
    # Hidden custom geometry and independent interface inputs survive reruns.
    for key in _draft_keys():
        if key in s:
            s[key] = s[key]

    with st.sidebar:
        st.caption('Versão ' + VERSION + ' · cantoneiras duplas R015')
        st.selectbox('Exemplo de cantoneiras duplas', list(PRESETS), key='wa_example')
        st.button('Usar exemplo R015', on_click=use_example, use_container_width=True)
        st.file_uploader('Abrir projeto R015', type=['json'], key='wa_upload')
        st.button('Carregar R015', on_click=load_project, use_container_width=True)
        if 'wa_import_error' in s:
            st.error(s.wa_import_error)
        st.divider()
        st.caption(BRAND)
        st.link_button('LinkedIn · Lucas Oliveira', LINK)

    st.title('Cantoneiras duplas · R015')
    st.caption('Duas cantoneiras reais · alma de viga W à mesa de pilar W · solda em U na alma, parafusos somente no apoio')
    st.info('Primeiro domínio: cortante vertical estático, com sinal. N, M e torção não nulos, cantoneira única, recortes e arranjos não convencionais exigem modelo próprio.')
    st.text_input('Identificação do projeto R015', key='wa_project')
    left, right = st.columns([.85, 1.5], gap='large')
    with left:
        beam = _profile('beam', 'Viga apoiada W')
        support = _profile('support', 'Pilar de apoio W')
        st.number_input('Cortante Vsd já majorado, com sinal (kgf)', key='wa_V_kgf', format='%.2f')
        st.caption('O sinal de V define a borda carregada. A força real e a ação adotada de conferência permanecem distintas.')
        load_convention_slot = st.empty()
        with st.expander('N, M e torção · ações fora do domínio R015'):
            st.number_input('Força axial N (kgf)', key='wa_N_kgf', format='%.2f')
            st.number_input('Momento M (kgf·m)', key='wa_M_kgfm', format='%.2f')
            st.number_input('Torção T (kgf·m)', key='wa_torsion_kgfm', format='%.2f')
            st.caption('Valores não nulos são preservados e impedem aprovação pelo modelo V-only.')
        with st.expander('Geometria das duas cantoneiras', expanded=True):
            render_angle_catalog('wa_')
            for key, label in [('beam_leg', 'Aba junto à alma da viga'), ('support_leg', 'Aba junto à mesa do apoio'),
                               ('t', 'Espessura da cantoneira'), ('length', 'Comprimento vertical da cantoneira')]:
                _dimension(key, label)
            if not s.wa_angle_catalog_id:
                _dimension('root_radius', 'Raio interno da cantoneira', 0.)
            _dimension('angle_top', 'Topo da cantoneira abaixo do topo da viga', 0.)
            st.caption('As duas cantoneiras do par são iguais. A aba soldada junto à alma e a aba parafusada junto ao apoio são peças contínuas de cada cantoneira.')
        with st.expander('Interface 1 · solda em U de cada cantoneira à alma', expanded=True):
            _select('Traçado da solda', ['U_three_edges'], 'wa_weld_layout',
                    {'U_three_edges': 'U em três bordas da aba junto à alma'})
            _dimension('weld_leg', 'Perna do filete de pernas iguais')
            _dimension('weld_start', 'Início dos ramos horizontais desde a face do apoio', 0.)
            _select('Processo e consumível de soldagem', ['SMAW_E7018'], 'wa_weld_process',
                    {'SMAW_E7018': 'SMAW E7018 em passe único'})
            st.number_input('Resistência do metal de solda fuw (MPa)',
                            min_value=_minimum('wa_electrode_fuw', .01), key='wa_electrode_fuw')
            st.checkbox('Borda com reforço de solda expressamente especificado', key='wa_reinforced_weld_edge')
            st.caption('Cada cantoneira tem três ramos conectados na aba junto à alma: superior, vertical externo e inferior. '
                       'O U fica aberto junto ao apoio, sem solda na aba de apoio ou fechamento no talão. '
                       'Não há furos nem parafusos na alma. A garganta é perna/√2.')
            st.caption('A geometria efetiva, os limites de perna, a excentricidade do grupo e o metal-base '
                       'são verificados pelo motor. Informar reforço de borda não aprova automaticamente o detalhe.')
            st.caption('Esta rota exige filetes em passe único conforme a Tabela 11 e procedimento de execução '
                       'qualificado. O processo SMAW E7018 e essa premissa de execução são obrigatórios; '
                       'outros processos ou arranjos importados permanecem fora do domínio.')
        with st.expander('Interface 2 · parafusos de cada cantoneira à mesa do apoio', expanded=True):
            st.number_input('Parafusos verticais por cantoneira no apoio', min_value=1, max_value=20, key='wa_support_rows')
            st.number_input('Colunas de parafusos por aba de apoio', min_value=1, max_value=20, key='wa_support_columns')
            for key, label in [('support_gauge', 'Gabarito da aba do apoio'), ('support_pitch', 'Passo vertical no apoio'),
                               ('support_end_top', 'Borda superior da cantoneira ao primeiro parafuso do apoio'),
                               ('support_edge_top', 'Primeiro parafuso até a borda livre superior real do apoio'),
                               ('support_edge_bottom', 'Último parafuso até a borda livre inferior real do apoio')]:
                _dimension(key, label)
            st.caption('Um plano de corte por parafuso de apoio; cada cantoneira transmite V/2 no modelo simétrico.')
        with st.expander('Furação somente no apoio, montagem e acesso'):
            _select('Diâmetro métrico do parafuso (mm)', [16., 20., 24., 30.], 'wa_db', on_change=bolt_changed)
            _select('Classe dos parafusos', list(BOLTS), 'wa_bolt')
            _dimension('hole_diameter', 'Diâmetro efetivo do furo no apoio')
            _select('Tipo de furo', ['standard_round', 'oversized_round', 'short_slot', 'long_slot'], 'wa_hole_type',
                    {'standard_round': 'Circular padrão', 'oversized_round': 'Circular alargado',
                     'short_slot': 'Alongado curto', 'long_slot': 'Alongado longo'})
            st.checkbox('Furo de broca documentado: sem acréscimo de 2 mm na dedução', key='wa_drilled')
            st.checkbox('Rosca excluída e documentada no plano do apoio', key='wa_support_threads_excluded')
            for key, label in [('gap', 'Folga da ponta da viga à mesa do apoio'),
                               ('fabrication_clearance', 'Folga adicional de fabricação')]:
                _dimension(key, label, 0.)
            _dimension('tool_radius', 'Raio livre requerido para a ferramenta')
            st.caption('R015: soldar as cantoneiras à alma na oficina e despachar o conjunto com a viga. N×s da folha industrial conta intervalos; os campos acima contam parafusos. Z não é o comprimento automático da cantoneira.')
        with st.expander('Materiais, topologia e premissas'):
            for key, label in [('beam_steel', 'Aço da viga'), ('support_steel', 'Aço do apoio')]:
                _select(label, [name for name, steel in STEELS.items() if steel.rolled_allowed], 'wa_' + key)
            _select('Aço das cantoneiras', [name for name, steel in STEELS.items() if steel.rolled_allowed], 'wa_angle_steel')
            _select('Exposição', ['painted', 'weathering'], 'wa_exposure',
                    {'painted': 'Pintado / protegido', 'weathering': 'Aço patinável exposto'})
            _select('Interface física de apoio', ['column_flange', 'column_web', 'beam_web'], 'wa_kind',
                    {'column_flange': 'Mesa de pilar W · R015', 'column_web': 'Alma de pilar · fora deste domínio',
                     'beam_web': 'Alma de viga · R017, fora deste domínio'})
            st.number_input('Quantidade real de cantoneiras', min_value=1, max_value=20, key='wa_angle_count')
            st.checkbox('Par de cantoneiras iguais, simétricas em relação à alma', key='wa_symmetric')
            _select('Recortes da viga', ['none', 'top', 'bottom', 'both'], 'wa_cope',
                    {'none': 'Sem recortes', 'top': 'Recorte superior', 'bottom': 'Recorte inferior', 'both': 'Superior e inferior'})
            st.checkbox('Ações estáticas, sem impacto ou fadiga', key='wa_static')
            st.checkbox('Combinações últimas normais', key='wa_normal_combination')
            st.checkbox('Projeto exige resistência ao deslizamento', key='wa_no_slip_required')
        st.text_area('Observações e decisão do responsável técnico', key='wa_notes')

    # Retire the previous evaluation before construction/conversion can fail.
    # A harmless rerun or rejected import may regain its report only after the
    # current inputs and canonical result reproduce the entire binding digest.
    prior_report = s.pop('wa_report', None)
    s.pop('_welded_double_angle_result', None)
    s.pop('_welded_double_angle_project', None)
    s['_welded_double_angle_ui_draft'] = {key: s[key] for key in _draft_keys() if key in s}
    try:
        values = {f.name: s['wa_' + f.name] for f in fields(WeldedDoubleAngle)
                  if f.name not in ('beam', 'support', *LOAD_UNITS)}
        c = WeldedDoubleAngle(beam=beam, support=support, **{key: _force(key) for key in LOAD_UNITS}, **values)
        native = c.to_dict()
        encoded = json.dumps(native, ensure_ascii=False, indent=2, allow_nan=False)
        with load_convention_slot.container():
            render_load_convention(st, 'welded_double_angle_r015', c.N)
        r = evaluate(c)
    except (ArithmeticError, ValueError, TypeError, KeyError) as exc:
        failure = 'NUMERICAL_FAILURE' if isinstance(exc, ArithmeticError) else 'INVALID_INPUT'
        with right:
            _input_failure(s, failure, exc)
        st.button('Gerar memória R015', disabled=True, use_container_width=True)
        return
    s['_welded_double_angle_project'] = native
    # Bind a generated report to the inputs AND the current evaluated result.
    # A changed engine result must not leave an old approval downloadable.
    digest = hashlib.sha256((encoded + json.dumps(r, ensure_ascii=False, sort_keys=True)).encode()).hexdigest()
    if prior_report and prior_report[0] == digest:
        s['wa_report'] = prior_report
    s['_welded_double_angle_result'] = r
    checks = r.get('checks') or []
    complete_checks = _complete_checks(checks)
    status = r.get('status', 'ENGINEERING_MODEL_PENDING')
    geometry_valid = bool((r.get('geometry') or {}).get('valid')) and status not in ('INVALID_INPUT', 'NUMERICAL_FAILURE')
    with right:
        text = STATUS.get(status, status)
        if status in ('INVALID_INPUT', 'NUMERICAL_FAILURE', 'INVALID_GEOMETRY', 'DETAIL_FAIL', 'VERIFIED_SUBCHECK_FAIL'):
            st.error(text)
        elif status == 'COMPLETE_CHECKS_PASS_WITHIN_SCOPE' and _approval_complete(r):
            st.success(text)
        else:
            if status in ('COMPLETE_CHECKS_PASS_WITHIN_SCOPE', 'COMPLETE_CHECKS_PASS_WITH_PRESET_DEVIATION') and not _approval_complete(r):
                text = STATUS['ENGINEERING_MODEL_PENDING'] + ' · completude não confirmada'
            st.warning(text)
        summary = r.get('summary') or {}
        load = r.get('load_model') or {}
        if summary:
            a, b = st.columns(2)
            a.metric('Índice com V real', _display(summary.get('actual_governing_utilization')))
            b.metric('Índice com ação adotada', _display(summary.get('governing_utilization')))
            st.caption('Vsd=' + _display(_kgf(load.get('Vsd_N', c.V))) + ' kgf; Vd adotado=' +
                       _display(_kgf(load.get('Vd_N'))) + ' kgf. Governa: ' + str(summary.get('governing_label', 'não determinado')))
        if geometry_valid:
            st.image(image_bytes(c, r), width='stretch')
        for issue in r.get('issues') or []:
            text = issue.get('text', str(issue)) if isinstance(issue, dict) else str(issue)
            severity = issue.get('severity', '') if isinstance(issue, dict) else ''
            if severity in ('invalid_input', 'numerical_failure', 'invalid_geometry', 'detail_fail', 'error'):
                st.error(text)
            elif severity in ('unsupported_scope', 'engineering_pending', 'access_pending', 'preset_deviation', 'warning'):
                st.warning(text)
            else:
                st.caption(text)
            if isinstance(issue, dict) and issue.get('reference'):
                st.caption(str(issue['reference']))
        if load:
            with st.expander('Partilha, interfaces e excentricidades'):
                for key, label in [('each_weld_group_force_N', 'Ação adotada em cada grupo de soldas'),
                                   ('each_angle_force_N', 'Ação adotada em cada cantoneira'),
                                   ('each_support_group_force_N', 'Ação adotada em cada grupo do apoio')]:
                    if _finite(load.get(key)):
                        st.write(label + ': ' + _display(_kgf(load[key])) + ' kgf.')
                for key in ('minimum_note', 'serial_interfaces', 'eccentricity_model'):
                    if load.get(key):
                        st.caption(str(load[key]))
                delivered = load.get('column_delivered_vertical_force_N')
                moment = load.get('column_delivered_transport_moment_about_centroid_Nmm')
                if _finite(delivered) and _finite(moment):
                    st.write('Ações reais entregues ao dimensionamento global do pilar: V=' +
                             _display(delivered / KGF) + ' kgf; momento de transporte=' +
                             _display(moment / (KGF * 1000)) + ' kgf·m.')
                if load.get('column_transport_note'):
                    st.caption(str(load['column_transport_note']))
                st.caption('As interfaces transmitem a ação em série; não se somam suas resistências. N=M=T externos nulos não anulam excentricidades geométricas.')
                st.json(load, expanded=False)
        welds = r.get('welds') or {}
        if welds:
            with st.expander('Soldas em U · geometria efetiva e grupo excêntrico'):
                group = welds.get('per_angle') or {}
                st.write('Garganta efetiva: ' + _display(welds.get('throat_mm')) + ' mm; '
                         'comprimento efetivo por cantoneira: ' + _display(group.get('total_length_mm')) + ' mm.')
                st.write('Centroide x̄: ' + _display(group.get('centroid_x_mm')) + ' mm; '
                         'inércia polar de linha J: ' + _display(group.get('J_line_mm3')) + ' mm³.')
                st.write('Força linear máxima adotada: ' + _display(group.get('max_resultant_N_per_mm')) +
                         ' N/mm; resistência do metal de solda: ' +
                         _display(welds.get('weld_line_resistance_N_per_mm')) + ' N/mm.')
                st.caption('Cada grupo recebe Vd/2. A excentricidade em relação ao centroide produz momento '
                           'e componentes locais de força; N=M=T externos nulos não eliminam esse efeito. '
                           'Os dois grupos atuam na mesma alma física da viga.')
                st.json(welds, expanded=False)
        st.caption(SCOPE)
        for exclusion in r.get('exclusions') or []:
            st.caption(exclusion)
    if checks and complete_checks:
        envelopes = physical_envelopes(r)
        st.subheader('Envelopes por componente físico e mecanismo')
        st.caption(f'{len(envelopes)} envelopes conservam os {len(checks)} ramos originais, sem somar resistências em série. '
                   'Máximos real e adotado são selecionados separadamente; empates e todos os casos constam no detalhamento.')
        st.dataframe(_envelopes_table(envelopes), hide_index=True, width='stretch')
        with st.expander('Governantes completos · casos reais, adotados e empates'):
            st.caption('Cada envelope conserva as testemunhas integrais dos governantes, seus empates e todos os ramos membros.')
            st.json(envelopes, expanded=False)
        with st.expander('Todas as verificações primitivas · IDs, fórmulas e referências'):
            st.caption('Inclui cada furo, soma normativa, prefixo de bloco e sentido, sem redistribuição plástica implícita.')
            st.dataframe(_checks_table(checks), hide_index=True, width='stretch')
            for check in checks:
                st.write(str(check.get('id', '')) + ' · ' + str(check.get('label', 'Verificação')))
                formula = check.get('formula')
                if isinstance(formula, (dict, list)):
                    st.json(formula, expanded=False)
                elif formula is not None:
                    st.write(str(formula))
                st.caption(str(check.get('reference', '')))
            st.json(checks, expanded=False)
    elif checks:
        st.warning('Registros incompletos: não é possível formar envelopes ou emitir conclusão resistente.')
        with st.expander('Registros diagnósticos disponíveis'):
            st.json(checks, expanded=False)
    a, b, d = st.columns(3)
    a.download_button('Salvar projeto R015 .json', encoded, 'cantoneiras_duplas_R015.json', 'application/json')
    if geometry_valid:
        b.download_button('Baixar desenho R015 .svg', drawing_svg(c, r), 'cantoneiras_duplas_R015.svg', 'image/svg+xml')
    ready = complete_checks and geometry_valid and status not in ('INVALID_INPUT', 'NUMERICAL_FAILURE', 'INVALID_GEOMETRY', 'OUTSIDE_R015_SCOPE')
    if ready and not _approval_complete(r):
        st.caption('A memória registra as verificações disponíveis e todas as falhas ou pendências; sua emissão não representa aprovação da ligação.')
    if d.button('Gerar memória R015', disabled=not ready, use_container_width=True):
        s.wa_report = (digest, 'memoria_cantoneiras_duplas_R015.docx', create_report(c, r))
    if 'wa_report' in s:
        _, filename, payload = s.wa_report
        st.download_button('Baixar memória R015 .docx', payload, filename,
                           'application/vnd.openxmlformats-officedocument.wordprocessingml.document')
