"""Complete 1L / symmetric 2L-T bolted rectangular gusset to exterior W flange.

N, mm, MPa. NBR 8800:2024/Errata 1:2025 normal static tension; method-qualified
conventional limit states plus separately identified supplemental nominal screens.
The actual angle end eccentricity is idealized under 6.1.8.2, not erased physically.
One central gusset and one double root receive TOTAL N in both arrangements.
No old axial or welded connection result is used as a complete-route shortcut.
"""
from __future__ import annotations
from dataclasses import asdict, dataclass, fields, replace
import math
from .models import BOLTS, finite_real
from .angle_catalog import get_angle, catalog
from .welded_angle_gusset import MATERIALS, ELECTRODES, SUPPORT_CATALOG, minimum_fillet
from .bolted_gusset_geometry import (point, ray_exit, transverse_chord, root_contact_length,
    horizontal_sections, force_normal_sections, golden_extreme)

FAMILY = 'Ligação 1L / 2L-T–gusset–mesa W · parafusada completa'
CONNECTION_TYPE = 'bolted_angle_gusset'
PRE_CAP_COMPONENT_VERSION = '0.9.30-gusset-variants-dev'
COMPONENT_VERSION = '0.9.39-bolted-outer-end-dev'
from . import gusset_outer_end as outer
UNITS = {'force': 'N', 'length': 'mm', 'stress': 'MPa', 'moment': 'N mm'}
GAMMA_A1, GAMMA_A2, GAMMA_W2 = 1.10, 1.35, 1.35
ARRANGEMENTS = ('1L', '2L-T')
HOLES = {12.7: 14.2875, 15.875: 17.4625, 19.05: 20.6375, 22.225: 23.8125,
         25.4: 28.575, 28.575: 31.75, 31.75: 34.925, 36.: 39.,
         16.: 18., 20.: 22., 22.: 24., 24.: 27., 27.: 30., 30.: 33.}
EDGES = {12.7: 19., 15.875: 22., 19.05: 25., 22.225: 28., 25.4: 32.,
         28.575: 38., 31.75: 41., 36.: 45., 16.: 22., 20.: 26.,
         22.: 28., 24.: 30., 27.: 34., 30.: 38.}
SCOPE = ('Uma L ou duas L idênticas em T simétrico, uma por face, abas conectadas no mesmo sentido, '
    'uma linha reta de parafusos passantes padrão em contato direto com um gusset retangular. '
    'Uma raiz longitudinal de dois filetes iguais contínuos, centrada na alma de W laminado, mesa exterior. '
    'Tração estática, combinações normais; theta variável sujeito à geometria, detalhamento e domínio tracionado. '
    'NBR8800:2024/Errata1:2025 6.1.8.2 idealiza a excentricidade estática de extremidade da L; ec real permanece em Ct. '
    '2L-T tem dois planos de corte e simetria através da chapa; 1L tem um plano e não tem cancelamento físico fora do plano. '
    'Seções perfuradas são triagens nominais complementares aos estados-limite convencionais, não solução de contato/contínuo.')
EXCLUSIONS = [
    'Par de vértices opostos requer duas linhas distintas de corte simples e modelo perfurado próprio; não disponível nesta família.',
    'Compressão, fadiga, sismo, reversão, ações espaciais V/M/T impostas, enchimentos e afastamentos fora do contato direto.',
    'Ângulos desiguais ou assimétricos, linhas múltiplas/escalonadas, furos alongados, contornos arbitrários, afunilamento lateral ou redução de raízes e crédito por atrito.',
    'Raiz transversal, descontínua ou deslocada da alma, alma W direta, I soldado, enrijecedores e segunda interface de apoio.',
    'Triagem nominal perfurada reprovada limita este método; não prova fissura, flambagem ou compressão pontual do contínuo.',
    'Resultado local não aprova fabricação, montagem real sem detalhe informado, WPS, inspeção ou estabilidade global da barra/apoio/estrutura.',
    'Combinar as ações exportadas com as ações concorrentes reais do W; apoio descarregado nunca presumido.',
]
SOURCES = {'NBR': 'ABNT NBR8800:2024/Errata1:2025 §§5.2,5.7,6.1.5,6.1.8.2,6.2,6.3,6.5; Tabelas14/16',
           'DG29': 'AISC DG29(2014) Ex5.4 PDF106–116/impresso98–108; método adaptado, não oráculo NBR',
           'qualification': 'Independent conventional method qualification 2026-10-11; new source-derived complete-route fixtures'}


@dataclass(frozen=True)
class BoltedAngleGusset:
    project: str = '2L-T Gerdau L76,2×6,35 → gusset240×300×12,5 → mesa W · 80° · N100kN'
    arrangement: str = '2L-T'
    support_member: str = 'beam'
    support_face: str = 'flange'
    angle_profile: str = 'GERDAU_EQUAL_ANGLE_P03_R29'
    support_profile: str = 'W310x165x52'
    angle_steel: str = 'ASTM A36'
    gusset_steel: str = 'ASTM A36'
    support_steel: str = 'ASTM A572 Gr.50'
    plate_width: float = 240.
    plate_height: float = 300.
    plate_t: float = 12.5
    gusset_end_shape: str = 'original'
    gusset_bolt_end_distance: float = 0.
    theta_deg: float = 80.
    center_s: float = 0.
    center_n: float = 150.
    row_offset: float = 0.
    bolt: str = 'ASTM F3125 A325'
    db: float = 16.
    n: int = 3
    pitch: float = 50.
    gauge: float = 40.
    angle_end: float = 35.
    drilled: bool = True
    threads_excluded_1: bool = False
    threads_excluded_2: bool = False
    pretensioned: bool = False
    exposure: str = 'painted'
    tool_radius: float = 18.
    fabrication_clearance: float = 2.
    heel_extent: float | None = None
    heel_extent_source: str = ''
    washer_stack: float = 0.
    root_weld_leg: float = 5.
    root_electrode: str = 'E60'
    support_end_left: float = 1000.
    support_end_right: float = 1000.
    N: float = 100000.
    V: float = 0.
    M: float = 0.
    torsion: float = 0.
    static: bool = True
    normal_combination: bool = True
    fatigue: bool = False
    seismic: bool = False
    minimum_force: bool = True
    recommend_half_capacity: bool = False
    notes: str = ''

    @property
    def angle_count(self):
        return 1 if self.arrangement == '1L' else 2

    @property
    def hole_diameter(self):
        return HOLES.get(self.db) if finite_real(self.db) else None

    @property
    def fixed_assumptions(self):
        return dict(topology='one_angle_one_face' if self.arrangement == '1L' else 'symmetric_identical_T_pair_shared_through_bolts',
            arrangement=self.arrangement, angle_count=self.angle_count, physical_bolt_rows=1,
            physical_shear_planes=self.angle_count, common_gusset_count=1, double_root_count=1,
            contact='firm_direct_no_fillers', load_model='NBR6.1.8.2_static_nominal_bolt_line',
            out_of_plane='static_end_idealization_not_physical_cancellation' if self.arrangement == '1L' else 'identical_symmetric_T_pair',
            angle_shear_lag='actual_catalog_ec_Lc_first_to_last_Ct_floor0.5',
            total_N='split_only_at_angles_and_shear_planes_full_N_to_gusset_root_W',
            bearing='uniform_per_bolt_deformation_limited_opposite_part_directions',
            net_hole_policy='Table14_plus2mm_unless_drilled', slip_resistance_credit=False,
            block='actual_clipped_L_paths_Cts0.5_alternatives_not_summed_root_contact_inactive',
            horizontal_sections='supplemental_nominal_net_section_jump_envelope_not_continuum',
            root='two_full_equal_fillets_longitudinal_web_centered_exterior_rolled_W_flange',
            root_weld_DG29='max_peak_1.25_endpoint_average_elastic6M_over_B',
            gamma_a1=GAMMA_A1, gamma_a2=GAMMA_A2, gamma_w2=GAMMA_W2,
            support_member_global_pass=False)

    def to_dict(self):
        errors = input_errors(self)
        if errors:
            raise ValueError('; '.join(errors))
        if self.arrangement not in ARRANGEMENTS:
            raise ValueError('Arranjo nativo deve ser 1L ou 2L-T; par oposto não é este modelo.')
        return dict(schema_version=1, connection_type=CONNECTION_TYPE, component_version=COMPONENT_VERSION,
            connection=asdict(self), units=dict(UNITS), fixed_assumptions=self.fixed_assumptions)

    @classmethod
    def from_dict(cls, data):
        required = {'schema_version', 'connection_type', 'component_version', 'connection', 'units', 'fixed_assumptions'}
        if not isinstance(data, dict) or set(data) != required:
            raise ValueError('Ligação parafusada completa: campos nativos ausentes ou desconhecidos.')
        if type(data['schema_version']) is not int or data['schema_version'] != 1 or data['connection_type'] != CONNECTION_TYPE or data['component_version'] not in (COMPONENT_VERSION, PRE_CAP_COMPONENT_VERSION):
            raise ValueError('Família/versão incompatível; componentes axiais ou soldados não são migrados silenciosamente.')
        raw = data['connection']
        if data['component_version']==PRE_CAP_COMPONENT_VERSION:
            if not isinstance(raw,dict) or set(raw)!={f.name for f in fields(cls)}-set(outer.BOLTED_FIELDS):raise ValueError('Campos legados incompletos ou híbridos; corte externo não é presumido.')
            raw=dict(raw,gusset_end_shape='original',gusset_bolt_end_distance=0.)
        if not isinstance(raw, dict) or set(raw) != {f.name for f in fields(cls)}:
            raise ValueError('Campos da ligação parafusada incompletos ou desconhecidos.')
        candidate = cls(**raw)
        canonical = candidate.to_dict()
        if not _exact(data['units'], canonical['units']) or not _exact(data['fixed_assumptions'], canonical['fixed_assumptions']):
            raise ValueError('Unidades ou premissas incompatíveis; nenhuma conversão silenciosa.')
        return candidate


def _exact(a, b):
    if type(a) is not type(b):
        return False
    if isinstance(b, dict):
        return set(a) == set(b) and all(_exact(a[k], b[k]) for k in b)
    if isinstance(b, list):
        return len(a) == len(b) and all(_exact(x, y) for x, y in zip(a, b))
    return a == b


def input_errors(c):
    if not isinstance(c, BoltedAngleGusset):
        return ['Entrada deve ser BoltedAngleGusset.']
    errors = []
    for f in fields(c):
        value = getattr(c, f.name)
        if f.type in ('str', str):
            if not isinstance(value, str):
                errors.append(f.name+': texto obrigatório.')
        elif f.type in ('bool', bool):
            if type(value) is not bool:
                errors.append(f.name+': booleano explícito obrigatório.')
        elif f.name == 'n':
            if type(value) is not int or not 2 <= value <= 50:
                errors.append('n: inteiro de 2 a 50 obrigatório; Lc deve ser positivo.')
        elif f.name == 'heel_extent' and value is None:
            pass
        elif not finite_real(value):
            errors.append(f.name+': número real finito obrigatório.')
    if isinstance(c.gusset_end_shape,str) and c.gusset_end_shape not in outer.SHAPES:errors.append('gusset_end_shape: escolher original ou normal_cut.')
    return errors


def presets():
    base = replace(BoltedAngleGusset(), heel_extent=12.35,
        heel_extent_source='Hipótese dimensional explícita do fixture: k_heel=12,35 mm (t+6 mm); raio NÃO publicado pela Gerdau; verificar peça real.')
    return {'2L-T · 80° · N100kN · detalhe assumido': base,
        '1L · 80° · N100kN · detalhe assumido': replace(base, arrangement='1L', project='1L Gerdau R29 · 80° · N100kN'),
        '2L-T · 90° · N100kN': replace(base, theta_deg=90., project='2L-T · 90° · N100kN'),
        '2L-T · 100° · espelho no plano': replace(base, theta_deg=100., project='2L-T · 100° · espelho'),
        '2L-T · N200kN · falha da raiz': replace(base, N=200000., project='2L-T · N200kN · raiz reprovada'),
        '2L-T · N real zero / mínimo45kN': replace(base, N=0., project='2L-T · N real zero'),
        '2L-T · 75° · fora do domínio tracionado': replace(base, theta_deg=75., project='2L-T · 75° · compressão nominal'),
        '2L-T · B400 · borda máxima reprovada': replace(base, plate_width=400., project='2L-T · B400 · borda máxima'),
        '2L-T · dado real de talão pendente': BoltedAngleGusset()}


def _safe(value):
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return value if finite_real(value) else None
    if isinstance(value, dict):
        return {str(k): _safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_safe(v) for v in value]
    return value if value is None or isinstance(value, (str, bool)) else repr(value)


def _issue(out, id, severity, message, **detail):
    out['issues'].append(dict(id=id, severity=severity, message=message, **detail))


def _row(out, id, label, component, mechanism, case, demand, resistance, unit='N', reference='', **details):
    if not all(finite_real(v) for v in (demand, resistance)) or demand < 0 or resistance <= 0:
        raise ArithmeticError('Nonpositive/nonfinite demand or capacity: '+id)
    utilization = demand/resistance
    out['checks'].append(dict(id=case+'__'+id, label=label, component=component,
        mechanism=mechanism, case_id=case, demand=demand, resistance=resistance, unit=unit,
        utilization=utilization, status='PASS' if utilization <= 1. else 'FAIL',
        reference=reference, details=details))


def _geometry(c, out):
    A, W = get_angle(c.angle_profile), SUPPORT_CATALOG.get(c.support_profile)
    if A is None or W is None:
        return None
    if A['Ag'] is None or A['centroid'] is None:
        _issue(out, 'missing_catalog_properties', 'outside_scope', 'Ag/ec não publicados; não são inferidos.')
        return None
    positive = ('plate_width', 'plate_height', 'plate_t', 'pitch', 'gauge', 'angle_end', 'db',
        'tool_radius', 'root_weld_leg', 'support_end_left', 'support_end_right')
    if any(getattr(c, key) <= 0 for key in positive) or c.fabrication_clearance < 0 or c.washer_stack < 0:
        _issue(out, 'positive_geometry', 'invalid_geometry', 'Dimensões positivas e folgas/arruelas não negativas obrigatórias.')
        return None
    if c.heel_extent is not None and c.heel_extent < A['t']:
        _issue(out, 'heel_extent_geometry', 'invalid_geometry', 'Envelope interno do talão deve alcançar ao menos a espessura da aba.')
    if not 0 < c.theta_deg < 180:
        _issue(out, 'theta_domain', 'outside_scope', 'Exige 0<theta<180 graus, direção de tração afastando da raiz.')
        return None
    if c.hole_diameter is None:
        _issue(out, 'diameter_system', 'outside_scope', 'Diâmetro/sistema sem furo padrão identificado nas Tabelas14/16.')
        return None
    B, H, dh = c.plate_width, c.plate_height, c.hole_diameter
    contour=outer.one_root(c) if outer.enabled(c) else None
    dn = dh if c.drilled else dh+2.
    C, S = math.cos(math.radians(c.theta_deg)), math.sin(math.radians(c.theta_deg))
    stations = [c.row_offset+(j-(c.n-1)/2)*c.pitch for j in range(c.n)]
    holes = [point(c, u) for u in stations]
    tool = c.tool_radius+c.fabrication_clearance
    vs = [-c.gauge, A['leg']-c.gauge]
    end_u = stations[0]-c.angle_end
    footprint = [point(c, u, v) for u in (end_u, stations[-1]+tool) for v in vs]
    ends = [point(c, end_u, v) for v in vs]
    grip = c.angle_count*A['t']+c.plate_t+c.washer_stack
    exempt = c.pretensioned and c.bolt in ('ASTM F3125 A325', 'ASTM F3125 A490')
    grip_raw = 1.-.01*max(0., grip-5*c.db)/1.5
    factor = 1. if exempt else max(0., grip_raw)
    g = dict(valid=False, polygon=[[-B/2, 0.], [B/2, 0.], [B/2, H], [-B/2, H]],
        direction=[C, S], center=[c.center_s, c.center_n], force_point=point(c, c.row_offset),
        bolt_stations=stations, bolt_centers=holes, hole_diameter=dh, net_hole_diameter=dn,
        angle_section=dict(A), support_catalog=dict(W), angle_count=c.angle_count,
        shear_planes=c.angle_count, physical_bolt_count=c.n, physical_gusset_count=1,
        root_endpoints=[[-B/2, 0.], [B/2, 0.]], root_centroid=[0., 0.], root_length=B,
        plate_width=B, plate_height=H, plate_t=c.plate_t, theta_deg=c.theta_deg,
        root_weld_leg=c.root_weld_leg, footprint_corners=footprint, angle_free_end=ends,
        angle_free_end_u=end_u, connected_leg_v=vs, grip=grip, grip_factor=factor,
        grip_factor_raw=grip_raw, grip_pretension_exemption=exempt, washer_stack=c.washer_stack,
        support_end_clearances=[c.support_end_left-B/2, c.support_end_right-B/2],
        tool_required=tool, Lc=(c.n-1)*c.pitch,
        heel_extent=c.heel_extent, heel_extent_source=c.heel_extent_source,
        heel_extent_catalog_verified=False, fabrication_notes=[], inactive_path_families=[])
    if contour:
        outer.attach(g,contour)
        for code,message in contour['problems']:_issue(out,code,'invalid_geometry',message)
    def limit(id, actual, bound, operator='>=', severity='detail_fail', message=None, reference='NBR6.3/Tabelas14/16'):
        ok = (actual >= bound-1e-9 if operator == '>=' else actual <= bound+1e-9 if operator == '<=' else actual > bound)
        g.setdefault('detail_checks', []).append(dict(id=id, actual=actual, bound=bound, operator=operator,
            status='PASS' if ok else 'FAIL', reference=reference))
        if not ok:
            _issue(out, id, severity, message or id+': limite dimensional não atendido.', actual=actual, bound=bound)
    for j, (x, y) in enumerate(holes):
        clearances = ({edge['id']:outer.segment_distance([x,y],edge['start'],edge['end']) for edge in contour['edges']} if contour and contour['outer_end_cut']['trimmed'] else dict(left=x+B/2, right=B/2-x, root=y, top=H-y))
        if contour and not outer.inside([x,y],g['polygon']):_issue(out,f'hole{j+1}_outside_contour','invalid_geometry','Centro físico do furo fora do contorno retido.')
        for edge, gap in clearances.items():
            limit(f'hole{j+1}_{edge}_net_ligament', gap, dn/2+1e-8, severity='invalid_geometry')
            limit(f'hole{j+1}_{edge}_tool', gap, tool+(c.root_weld_leg if edge == 'root' else 0.),
                severity='invalid_geometry', reference='Envelope real informado de ferramenta/hardware e raiz')
            if edge != 'root':
                limit(f'hole{j+1}_{edge}_minimum', gap, EDGES[c.db])
    def inside(p):
        return (outer.inside(p,g['polygon']) and p[1]>=c.root_weld_leg+1e-9) if contour else -B/2-1e-9 <= p[0] <= B/2+1e-9 and c.root_weld_leg+1e-9 <= p[1] <= H+1e-9
    if not all(inside(p) for p in footprint):
        _issue(out, 'angle_footprint_containment', 'invalid_geometry', 'Sobreposição física da aba/endereço livre ou envelope da última fixação cruza borda/raiz.')
    if min(g['support_end_clearances']) < 0:
        _issue(out, 'root_beyond_support', 'invalid_geometry', 'Raiz ultrapassa extremidade real do W.')
    free_distances=([(e['id'],min(outer.segment_distance(p,e['start'],e['end']) for p in holes)) for e in contour['edges'] if not e['supported']] if contour and contour['outer_end_cut']['trimmed'] else [('left',min(x+B/2 for x,_ in holes)),('right',min(B/2-x for x,_ in holes)),('top',min(H-y for _,y in holes))])
    for edge,distance in free_distances:
        limit('gusset_'+edge+'_maximum_edge', distance, min(12*c.plate_t, 150.), '<=',
            reference='NBR6.3.12: distância ao parafuso mais próximo de CADA borda livre; raiz não é borda livre')
    limit('pitch_min', c.pitch, max(2.7*c.db, dh+c.db))
    limit('pitch_net_ligament', c.pitch-dn, 1e-8, severity='invalid_geometry')
    thin = min(A['t'], c.plate_t)
    limit('pitch_max', c.pitch, min(14*thin, 180.) if c.exposure == 'weathering' else min(24*thin, 300.), '<=')
    limit('tool_covers_hole', c.tool_radius, dh/2, severity='invalid_geometry')
    limit('adjacent_tool_clearance', c.pitch, 2*c.tool_radius+c.fabrication_clearance)
    for key, distance in [('angle_end', c.angle_end), ('angle_toe', A['leg']-c.gauge)]:
        limit(key+'_net_ligament', distance, dn/2+1e-8, severity='invalid_geometry')
        limit(key+'_minimum', distance, EDGES[c.db])
        limit(key+'_maximum', distance, min(12*A['t'], 150.), '<=')
        limit(key+'_tool', distance, tool, severity='invalid_geometry')
    limit('known_heel_thickness_hole_clearance', c.gauge-A['t'], dh/2, severity='invalid_geometry')
    limit('known_heel_thickness_tool_clearance', c.gauge-A['t'], tool, severity='invalid_geometry')
    if c.heel_extent is None:
        _issue(out, 'heel_extent_missing', 'detail_pending', 'Informar envelope interno real do talão e sua origem; catálogo Gerdau não publica raio. Mecânica não certifica montagem.')
    else:
        limit('heel_hole_clearance', c.gauge-c.heel_extent, dh/2, severity='invalid_geometry')
        limit('heel_tool_clearance', c.gauge-c.heel_extent, tool, severity='invalid_geometry')
        if not c.heel_extent_source.strip():
            _issue(out, 'heel_extent_source_missing', 'detail_pending', 'Identificar origem do envelope real/hipótese dimensional do talão.')
        g['fabrication_notes'].append('Envelope de talão informado: '+str(c.heel_extent)+' mm; '+c.heel_extent_source)
    if c.pitch < 3*c.db:
        _issue(out, 'pitch_preferred', 'warning', 'Passo atende mínimo se verificado; preferência3d não alcançada.')
    limit('grip_factor_positive', factor, 0., '>', severity='invalid_geometry', reference='NBR6.3.7: redução por pega, arruelas incluídas conservadoramente')
    limit('lap_overlap', g['Lc']+c.angle_end, max(5*thin, 25.))
    limit('root_fillet_min', c.root_weld_leg, minimum_fillet(min(c.plate_t, W['tf'])), reference='NBR6.2.6.2: peça menos espessa')
    limit('root_fillet_max', c.root_weld_leg, c.plate_t if c.plate_t < 6.3 else c.plate_t-1.5, '<=', reference='NBR6.2.6.2: borda ordinária do gusset')
    limit('root_effective_length', B, max(4*c.root_weld_leg, 40.), reference='NBR6.2.2.2')
    limit('root_weld_long_limit', B/c.root_weld_leg, 100., '<=', severity='outside_scope', reference='L/s>100: redução de comprimento não coberta')
    limit('flange_footprint', c.plate_t+2*c.root_weld_leg, W['bf'], '<=', severity='invalid_geometry')
    if any(i['severity'] in ('invalid_geometry', 'outside_scope') for i in out['issues']):
        return g
    forward = ray_exit(c, holes[0], [C, S])
    g['forward_exit'] = dict(forward, u=stations[0]+forward['distance'])
    g['force_line_root_s'] = c.center_s-c.center_n*C/S
    g['transverse_stations'] = [dict(u=u, chord=transverse_chord(c, u)) for u in stations]
    if forward['edge'] == 'root':
        _issue(out, 'forward_root', 'invalid_geometry', 'Saída longitudinal carregada não pode ser a raiz apoiada.')
    width = 2*g['Lc']*math.tan(math.pi/6)
    chord = transverse_chord(c, stations[0])
    vlo, vhi = max(-width/2, -chord['left']['distance']), min(width/2, chord['right']['distance'])
    if (vlo > -width/2+1e-9 and chord['left']['edge'] == 'root') or (vhi < width/2-1e-9 and chord['right']['edge'] == 'root'):
        _issue(out, 'whitmore_root_contact', 'outside_scope', 'Whitmore alcança a raiz apoiada; não se conta material imaginário além da interface.')
    g['Whitmore'] = dict(nominal_width=width, width=vhi-vlo, clipped=vhi-vlo < width-1e-9,
        v_limits=[vlo, vhi], endpoints=[point(c, stations[0], vlo), point(c, stations[0], vhi)],
        actual_deduction=min(vhi, dn/2)-max(vlo, -dn/2))
    if vhi-vlo <= dn:
        _issue(out, 'whitmore_nonpositive_net', 'invalid_geometry', 'Whitmore recortado sem ligamento líquido positivo.')
    g['valid'] = not any(i['severity'] in ('invalid_geometry', 'outside_scope') for i in out['issues'])
    return g


def _block(id, component, Agv, Anv, Ant, force, material, coordinates, **details):
    if min(Agv, Anv, Ant) <= 0:
        raise ValueError('Ligamento líquido não positivo no caminho '+id)
    yield_branch = (.6*material.fy*Agv+.5*material.fu*Ant)/GAMMA_A2
    rupture_branch = (.6*material.fu*Anv+.5*material.fu*Ant)/GAMMA_A2
    resistance = min(yield_branch, rupture_branch)
    return dict(id=id, name=id, component=component, Agv=Agv, Anv=Anv, Ant=Ant, Cts=.5,
        R_yield=yield_branch, R_rupture=rupture_branch, R=resistance, resistance=resistance,
        demand=force, utilization=force/resistance, coordinates=coordinates, path=coordinates,
        active=True, reference='NBR6.5.6: ambas parcelas/gamma_a2; Cts0.5 conservador', **details)


def rupture_paths(c, g, N, angle, gusset):
    A, t, dn = g['angle_section'], c.plate_t, g['net_hole_diameter']
    stations = g['bolt_stations']; paths = []; inactive = []
    for k in range(1, c.n+1):
        length = c.angle_end+(k-1)*c.pitch
        demand = N*k/(c.angle_count*c.n)
        for side, area in [('connected_toe', (A['leg']-c.gauge-dn/2)*A['t']),
            ('opposite_toe_area_complement', A['Ag']-(A['leg']-c.gauge)*A['t']-dn*A['t']/2)]:
            u = stations[k-1]
            coords = [point(c, g['angle_free_end_u']), point(c, u),
                point(c, u, A['leg']-c.gauge if side == 'connected_toe' else -c.gauge)]
            p = _block('A-'+side+'-'+str(k), 'angle', length*A['t'],
                (length-(k-.5)*dn)*A['t'], area, demand, angle, coords,
                k=k, copies=c.angle_count, Lv=length, captured_bolts=list(range(1, k+1)),
                shear_hole_deduction_count=k-.5, tension_hole_deduction_count=.5,
                heel_is_free_edge=False, force_direction='-u', alternative_path=True,
                geometric_note=('Connected real toe' if side == 'connected_toe' else
                    'Nominal catalog-area complement continues through heel to opposite real toe; projected last point is heel transition, not a free exit'),
                unfolded_transverse_length=(A['leg']-c.gauge if side == 'connected_toe' else None),
                area_complement_nominal=side != 'connected_toe')
            # Separate nominal 3-D witness: the far path continues through the
            # heel to the other REAL toe, not to an invented planar free heel.
            # Published b/t set the straight nominal leg endpoints; the missing
            # heel radius is not reconstructed. Areas still use catalog Ag.
            zmid = c.plate_t/2+A['t']/2
            first = point(c, g['angle_free_end_u']); at_hole = point(c, u)
            if side == 'connected_toe':
                last = point(c, u, A['leg']-c.gauge)
                path3 = [[*first, zmid], [*at_hole, zmid], [*last, zmid]]
            else:
                heel = point(c, u, -c.gauge+A['t']/2)
                path3 = [[*first, zmid], [*at_hole, zmid], [*heel, zmid],
                         [*heel, c.plate_t/2+A['leg']]]
            p['nominal_path_3d_each_angle'] = [path3] if c.angle_count == 1 else [path3, [[x, y, -z] for x, y, z in path3]]
            p['free_exit'] = dict(name='connected_real_toe' if side == 'connected_toe' else 'opposite_real_toe',
                nominal_point_3d=path3[-1], radius_contour_reconstructed=False)
            paths.append(p)
    C, S = g['direction']; end_u = g['forward_exit']['u']
    # Standard centered L paths remain explicit witnesses. Generalized caps also
    # include EVERY hole edge, corner and the interior minimum of each block
    # branch. Inside a hole, net shear length is constant but the tensile cap
    # deducts sqrt(r^2-(u-uj)^2); it is NOT affine. On one fixed polygon edge,
    # transverse gross length has slope a. With x=u-uj the stationary points are
    # x/r=K/sqrt(1+K^2), K=-a (net-shear rupture) or K=1.2fy/fu-a
    # (gross-shear yield). Both branches are convex on that geometric interval;
    # their minima and interval ends contain the minimum of their lower envelope.
    radius = dn/2
    lower, upper = stations[0]-radius, stations[-1]+radius
    events = [(u, 'bolt_center', j) for j, u in enumerate(stations)]
    for j, u in enumerate(stations):
        events.extend((u+delta, 'hole_edge', j) for delta in (-radius, radius))
    for x, y in g['polygon']:
        u = (x-c.center_s)*C+(y-c.center_n)*S
        if lower <= u <= upper:
            events.append((u, 'polygon_corner', -1))
    cuts = sorted(set(u for u, _, _ in events))
    for low, high in zip(cuts, cuts[1:]):
        mid = (low+high)/2
        intersected = [j for j, uj in enumerate(stations) if abs(mid-uj) < radius]
        if not intersected:
            continue
        j = intersected[0]  # Minimum pitch/net-ligament gates ensure disjoint holes along u.
        chord = transverse_chord(c, mid)
        for side, sign in [('left', -1), ('right', 1)]:
            edge = chord[side]['edge']
            if g.get('outer_end_cut',{}).get('trimmed'):
                ca,cb=transverse_chord(c,low)[side],transverse_chord(c,high)[side]
                slope=(cb['distance']-ca['distance'])/(high-low)
            else:slope = -C/(sign*S) if edge in ('left', 'right') else S/(sign*C)
            for branch, K in [('rupture', -slope), ('yield', 1.2*gusset.fy/gusset.fu-slope)]:
                u = stations[j]+radius*K/math.hypot(1., K)
                if low < u < high:
                    events.append((u, 'hole_cap_'+branch+'_critical_'+side, j))
    unique = {}
    for u, event, j in events:
        key = round(u, 11)
        if key not in unique or event == 'bolt_center':
            unique[key] = (u, event, j)
    for u, event, index in sorted(unique.values()):
        # A hole-crossing cap has no assumed bearing-pressure distribution.
        # Preserve the pre/post limits explicitly; the included-hole force is
        # the conservative governing limit, including its one-sided tangent.
        captured = [j for j, station in enumerate(stations) if station+radius >= u-1e-8]
        excluded = [j for j, station in enumerate(stations) if station-radius > u+1e-8]
        crossing = [j for j in captured if j not in excluded]
        if not captured:
            continue
        k = len(captured)
        chord = transverse_chord(c, u)
        length = end_u-u
        deduction = sum(max(0., min(end_u, uj+dn/2)-max(u, uj-dn/2)) for uj in stations)
        transverse_deduction = max([math.sqrt(max(0., (dn/2)**2-(u-uj)**2))
            for uj in stations if abs(u-uj) <= dn/2]+[0.])
        for side, sign in [('left', -1), ('right', 1)]:
            exit_ = chord[side]
            contact = root_contact_length(c, u, side)
            pathid = (f'G-L-{sign:+d}-{k}' if event == 'bolt_center' else f'G-event-{side}-{event}-{u:.10g}')
            coords = [g['forward_exit']['point'], point(c, u), exit_['point']]
            if exit_['edge'] == 'root' or contact > 1e-8:
                inactive.append(dict(id=pathid, component='gusset', active=False, u=u, event=event,
                    root_contact_length=contact, coordinates=coords,
                    reason='Positive supported-root segment or transverse root hit: does not detach a free block'))
                continue
            paths.append(_block(pathid, 'gusset', length*t, (length-deduction)*t,
                (exit_['distance']-transverse_deduction)*t, N*k/c.n, gusset, coords,
                k=k, u=u, event=event, Lv=length, transverse_length=exit_['distance'],
                captured_bolts=[j+1 for j in captured],
                crossing_bolts=[j+1 for j in crossing],
                captured_bolt_limits=dict(excluding_crossing=[j+1 for j in excluded], including_crossing=[j+1 for j in captured]),
                demand_limits=dict(excluding_crossing=N*len(excluded)/c.n, including_crossing=N*k/c.n),
                captured_force_model='Conservative included/excluded crossing-hole one-sided envelope; no contact-pressure distribution assumed',
                shear_hole_deduction_length=deduction,
                shear_hole_deduction_count=deduction/dn, tension_hole_deduction_length=transverse_deduction,
                free_longitudinal_exit=g['forward_exit']['edge'], free_transverse_exit=exit_['edge'],
                root_contact_length=contact, force_direction='+u', alternative_path=True,
                no_duplicate_U_path=True, purpose=('conventional_centered_L_path' if event == 'bolt_center' else 'conservative_variable_cap_envelope')))
    return paths, inactive


def root_checks(c, g, N, case, out, gusset, support):
    """Qualified one-root/W equations recalculated from this discrete bolt row."""
    C, S = g['direction']; B = c.plate_width; W = g['support_catalog']
    nr, vr = N*S, N*C
    # Discrete physical forces, never angle centroid followed by discarded moment.
    mr = sum(N/c.n*(x*S-y*C) for x, y in g['bolt_centers'])
    qn = [nr/B-6*mr/B**2, nr/B+6*mr/B**2]; qs = vr/B
    endpoints = [math.hypot(q, qs) for q in qn]
    peak, average = max(endpoints), sum(endpoints)/2
    design = max(peak, 1.25*average)
    root = dict(N=nr, V=vr, M=mr, B=B, t=c.plate_t, area=B*c.plate_t,
        q_n_ends_N_per_mm=qn, q_s_N_per_mm=qs, q_normal=qn, q_parallel=qs,
        q_peak=peak, q_average=average, q_design=design, weld_leg=c.root_weld_leg,
        weld_stress=design/(math.sqrt(2)*c.root_weld_leg),
        elastic_peak_equivalent_normal_N=B*max(map(abs, qn)))
    _row(out, 'root_weld', 'Solda dupla da raiz · N/V/M total', 'root_weld', 'weld', case,
        root['weld_stress'], .6*ELECTRODES[c.root_electrode]/GAMMA_W2, 'MPa',
        'NBR6.2.5 + suplemento DG29 max(qpico,1.25qmédio), 6M/B elástico', **root)
    root['weld_utilization'] = out['checks'][-1]['utilization']
    for id, component, material, depth in [('root_gusset_contact', 'gusset_root', gusset, min(c.plate_t, 2*c.root_weld_leg)),
        ('root_W_contact', 'support_contact', support, 2*c.root_weld_leg)]:
        sigma, tau = max(map(abs, qn))/depth, abs(qs)/depth
        candidates = [dict(name='yield', demand=math.hypot(sigma, math.sqrt(3)*tau), resistance=material.fy/GAMMA_A1),
            dict(name='normal_rupture', demand=sigma, resistance=material.fu/GAMMA_A2),
            dict(name='shear_rupture', demand=tau, resistance=.6*material.fu/GAMMA_A2)]
        controlling = max(candidates, key=lambda z: z['demand']/z['resistance'])
        _row(out, id, 'Metal-base da raiz · '+component, component, 'root_substrate', case,
            controlling['demand'], controlling['resistance'], 'MPa', 'NBR6.5.3/6.5.5: normal+cisalhamento',
            depth=depth, sigma=sigma, tau=tau, candidates=candidates)
        root['gusset_contact' if component == 'gusset_root' else 'W_contact'] = dict(depth=depth, sigma=sigma, tau=tau,
            **{z['name']+'_u': z['demand']/z['resistance'] for z in candidates})
    end_distance = min(g['support_end_clearances'])
    end_factor = 2.5 if end_distance <= W['d'] else 5.
    neq = root['elastic_peak_equivalent_normal_N']
    rnormal = 1.10*(end_factor*W['k']+B)*support.fy*W['tw']/GAMMA_A1
    _row(out, 'W_web_normal', 'W · escoamento local da alma em tração', 'support_web', 'local_normal_yield', case,
        neq, rnormal, reference='NBR5.7.3; Neq=|N|+6|M|/B; ambos extremos reais', end_factor=end_factor, end_distance=end_distance)
    shear_strength = min(.6*support.fy/GAMMA_A1, .6*support.fu/GAMMA_A2)
    _row(out, 'W_longitudinal_shear', 'W · cisalhamento longitudinal', 'support_web', 'longitudinal_shear', case,
        abs(vr), B*W['tw']*shear_strength, reference='NBR6.5.5/DG29, Agv=Btw, V paralelo')
    web_normal, web_tau = neq/(B*W['tw']), 1.5*abs(vr)/(B*W['tw'])
    _row(out, 'W_web_VM', 'W · triagem combinada local da alma', 'support_web', 'combined_yield', case,
        math.hypot(web_normal, math.sqrt(3)*web_tau), support.fy/GAMMA_A1, 'MPa', 'Triagem elástica local conservadora derivada')
    _row(out, 'W_flange_shear', 'W · cisalhamento/punção da mesa', 'support_flange', 'punching', case,
        peak/(2*W['tf']), shear_strength, 'MPa', 'NBR6.5.5: duas faces longitudinais, qpeak sem fator1.25 da solda')
    footprint = c.plate_t+2*c.root_weld_leg
    exempt = footprint < .15*W['bf']
    if not exempt:
        resistance = 6.25*support.fy*W['tf']**2/GAMMA_A1
        if end_distance < 10*W['tf']:
            resistance /= 2
        _row(out, 'W_flange_bending', 'W · flexão local da mesa', 'support_flange', 'local_bending', case,
            neq, resistance, reference='NBR5.7.2; metade junto à extremidade', footprint=footprint, end_distance=end_distance)
    root.update(flange_bending_exempt=exempt, flange_footprint=footprint, closest_W_end=end_distance,
        W_web_Neq_elastic=neq, W_web_local_yield_R=rnormal, W_centroid_M=mr-W['d']*vr/2,
        transverse_member_shear_jump=nr, compression_only_checks='inactive: tension-only route; a compressed screen leaves scope')
    member = dict(reference='Centroide da raiz na face exterior da mesa', point_local=[0., 0.],
        applied_to_support=dict(N_normal=nr, V_parallel=vr, M_root=mr),
        equal_opposite_on_gusset=dict(N_normal=-nr, V_parallel=-vr, M_root=-mr),
        introduced_member_shear_jump=nr, introduced_member_axial_jump=vr,
        root_to_member_centroid_normal_offset=W['d']/2,
        introduced_moment_about_member_centroid=mr-W['d']*vr/2,
        existing_member_actions=None, global_member_verified=False,
        note='Somar às ações concorrentes reais do W; Nnormal é salto de cortante do membro, Vparalelo é ação axial.')
    return root, member


def _calculate_case(c, g, N, case, label, out, materials):
    angle, gusset, support = materials
    A = g['angle_section']; dn = g['net_hole_diameter']; dh = g['hole_diameter']
    count = c.angle_count; Ct = max(1.-A['centroid']/g['Lc'], .5)
    An = A['Ag']-dn*A['t']
    if An <= 0:
        raise ValueError('Seção líquida da L não positiva.')
    _row(out, 'angle_yield', 'L · escoamento bruto total', 'angle', 'tension_yield', case,
        N, count*A['Ag']*angle.fy/GAMMA_A1, reference='NBR5.2.2(a); Ag real de catálogo por L', count=count, Ag_one=A['Ag'])
    _row(out, 'angle_net', 'L · ruptura líquida efetiva total', 'angle', 'tension_rupture', case,
        N, count*Ct*An*angle.fu/GAMMA_A2, reference='NBR5.2.2/5.2.4/5.2.5; uma dedução por L; ec real/Lc',
        count=count, An_one=An, Ct=Ct, ec=A['centroid'], Lc=g['Lc'], net_hole_diameter=dn)
    planes = []
    for j, position in enumerate(g['bolt_centers']):
        for plane in range(1, count+1):
            excluded = getattr(c, 'threads_excluded_'+str(plane))
            coefficient = .56 if excluded and c.bolt != 'ASTM A307' else .45
            resistance = coefficient*math.pi*c.db**2/4*BOLTS[c.bolt]/GAMMA_A2*g['grip_factor']
            demand = N/(count*c.n)
            _row(out, f'bolt_{j+1}_plane_{plane}', f'Parafuso{j+1} · plano{plane}', 'bolt', 'bolt_shear', case,
                demand, resistance, reference='NBR6.3.3.2/6.3.7: plano físico individual; sem crédito por atrito',
                bolt_index=j+1, plane=plane, threads_excluded=excluded, coefficient=coefficient,
                fub=BOLTS[c.bolt], grip=g['grip'], grip_factor=g['grip_factor'], position=position)
            planes.append(dict(bolt=j+1, plane=plane, demand=demand, resistance=resistance,
                utilization=demand/resistance, coefficient=coefficient, threads_excluded=excluded))
    bearing = dict(angle=[], gusset=[])
    for j, u in enumerate(g['bolt_stations']):
        angle_lc = c.angle_end-dh/2 if j == 0 else c.pitch-dh
        plate_lc = c.pitch-dh if j < c.n-1 else g['forward_exit']['u']-u-dh/2
        for component, lc, thickness, material, demand in [('angle', angle_lc, A['t'], angle, N/(count*c.n)),
            ('gusset', plate_lc, c.plate_t, gusset, N/c.n)]:
            if lc <= 0:
                raise ValueError('Ligamento de contato não positivo em '+component)
            resistance = min(1.2*lc*thickness*material.fu, 2.4*c.db*thickness*material.fu)/GAMMA_A2
            record = dict(hole=j+1, lc=lc, tearout_R=1.2*lc*thickness*material.fu/GAMMA_A2,
                bearing_cap_R=2.4*c.db*thickness*material.fu/GAMMA_A2, R=resistance, demand=demand,
                utilization=demand/resistance, force_direction='-u' if component == 'angle' else '+u',
                physical_hole_diameter=dh, copies=count if component == 'angle' else 1)
            bearing[component].append(record)
            _row(out, f'{component}_bearing_{j+1}', component+f' · contato individual{j+1}', component, 'bearing', case,
                demand, resistance, reference='NBR6.3.3.3(a): min(1.2lc t fu,2.4db t fu)/gamma_a2; direções opostas', bearing=record)
    paths, inactive = rupture_paths(c, g, N, angle, gusset)
    for p in paths:
        p['case_id'] = case
        _row(out, p['id'], p['name'], p['component'], 'block_tearout', case,
            p['demand'], p['resistance'], reference=p['reference'], path=p)
    whit = dict(g['Whitmore'])
    whit.update(gross_area=whit['width']*c.plate_t, net_area=(whit['width']-whit['actual_deduction'])*c.plate_t)
    whit['R_yield'] = whit['gross_area']*gusset.fy/GAMMA_A1
    whit['R_net'] = whit['net_area']*gusset.fu/GAMMA_A2
    whit['yield_utilization'] = N/whit['R_yield']; whit['net_utilization'] = N/whit['R_net']
    _row(out, 'Whitmore_yield', 'Gusset · Whitmore bruto recortado', 'gusset', 'Whitmore_yield', case,
        N, whit['R_yield'], reference='DG29 Ex5.4/espalhamento30°; NBR5.2/6.5.3; extensão real contida', **whit)
    _row(out, 'Whitmore_net', 'Gusset · triagem líquida Whitmore', 'gusset', 'Whitmore_net', case,
        N, whit['R_net'], reference='Triagem líquida conservadora complementar; sem limite0.85Ag de chapa de emenda', **whit)
    normal = force_normal_sections(c, g, N, gusset.fy, gusset.fu)
    for key, strength in [('yield', gusset.fy/GAMMA_A1), ('rupture', gusset.fu/GAMMA_A2)]:
        witness = max(normal, key=lambda z: z[key+'_utilization'])
        _row(out, 'normal_net_'+key, 'Gusset · seção líquida normal real · '+key, 'gusset', 'normal_net_'+key, case,
            max(map(abs, witness['sigma_edges'])), strength, 'MPa',
            'NBR6.5.3: geometria líquida recortada + triagem nominal N/M no centroide líquido próprio', witness=witness)
    horizontal = horizontal_sections(c, g, N, gusset.fy, gusset.fu)
    _row(out, 'nominal_perforated_yield', 'Gusset · triagem nominal perfurada N/V/M', 'gusset', 'nominal_perforated_yield', case,
        horizontal['max_VM'], gusset.fy/GAMMA_A1, 'MPa',
        'Complementar: sigma=N/A+M(s-sbar)/I, tau1.5V/A; não solução exata de furos', extrema_method=horizontal['extrema_method'])
    _row(out, 'nominal_perforated_rupture', 'Gusset · envelope nominal tração/cisalhamento', 'gusset', 'nominal_perforated_rupture', case,
        horizontal['utilization_rupture'], 1., 'ratio',
        'Complementar NBR6.5.3/6.5.5; ruptura normal e cisalhamento separados')
    minimum = min(horizontal['min_sigma'], min(min(z['sigma_edges']) for z in normal))
    tolerance = 1e-10*max(1., abs(N)/(c.plate_width*c.plate_t))
    if minimum < -tolerance:
        _issue(out, case+'_compressed_section', 'outside_scope',
            'Triagem nominal apresenta seção comprimida: entrada fora do domínio tracionado deste método; não é prova pontual de contínuo.',
            minimum_normal_MPa=minimum)
    root, member = root_checks(c, g, N, case, out, gusset, support)
    utilization = dict(angle_yield=N/(count*A['Ag']*angle.fy/GAMMA_A1), angle_net=N/(count*Ct*An*angle.fu/GAMMA_A2),
        bolt_shear=max(p['utilization'] for p in planes), angle_bearing=max(p['utilization'] for p in bearing['angle']),
        plate_bearing=max(p['utilization'] for p in bearing['gusset']),
        angle_block=max(p['utilization'] for p in paths if p['component'] == 'angle'),
        plate_block=max([p['utilization'] for p in paths if p['component'] == 'gusset']+[0.]))
    for key in ('Whitmore_yield', 'Whitmore_net', 'normal_net_yield', 'normal_net_rupture',
        'nominal_perforated_yield', 'nominal_perforated_rupture', 'root_weld', 'root_gusset_contact',
        'root_W_contact', 'W_flange_shear', 'W_web_normal', 'W_longitudinal_shear', 'W_web_VM', 'W_flange_bending'):
        rows = [r for r in out['checks'] if r['id'] == case+'__'+key]
        if rows:
            utilization[key] = rows[0]['utilization']
    center_utilizations = dict(plate_block=max([p['utilization'] for p in paths
        if p['component'] == 'gusset' and p.get('event') == 'bolt_center']+[0.]))
    block_envelope = dict(method='Conventional centered L paths plus conservative variable-cap envelope',
        extrema='All hole edges/centers/polygon corners and analytical interior minima of BOTH NBR6.5.6 branches',
        hole_caps='Circular half-chord deduction is nonlinear; within a hole Anv is constant while Agv and gross cap length vary linearly',
        force_limits='Explicit crossing-hole included/excluded one-sided bounds; larger included force governs without assumed contact pressure',
        original_center_witnesses_preserved=True, reference_center_path_utilizations=center_utilizations)
    record = dict(id=case, label=label, N=N, root=root, member_actions=member, paths=paths,
        block_path_envelope=block_envelope, reference_center_path_utilizations=center_utilizations,
        inactive_path_families=inactive, angle_Ct=Ct, angle_Ae=Ct*An, angle_An=An,
        bolt_planes=planes, bearing=bearing, Whitmore=whit, force_normal_cuts=normal,
        horizontal_sections=horizontal, plate_sections=horizontal, utilizations=utilization,
        normal_tension_domain=minimum >= -tolerance,
        force_split=dict(total=N, each_angle=N/count, each_bolt=N/c.n, each_plane=N/(count*c.n), each_gusset_hole=N/c.n),
        angle=dict(Ct=Ct, An_one=An, yield_R_total=count*A['Ag']*angle.fy/GAMMA_A1,
            net_R_total=count*Ct*An*angle.fu/GAMMA_A2))
    out['cases'].append(record)
    if case == 'actual':
        out.update(root=root, sections=horizontal, paths=paths, member_actions=member,
            bearing=bearing, Whitmore=whit, force_normal_cuts=normal, utilizations=utilization,
            block_path_envelope=block_envelope, reference_center_path_utilizations=center_utilizations)
        out['geometry']['inactive_path_families'] = inactive


def _finalize(out):
    severities = {x['severity'] for x in out['issues']}
    complete = bool(out['checks']) and not severities.intersection({'invalid_input', 'numerical_failure', 'invalid_geometry', 'outside_scope'})
    failures = [x['id'] for x in out['checks'] if x['status'] == 'FAIL']
    detail_ok = not severities.intersection({'detail_fail', 'detail_pending'})
    passed = complete and not failures and detail_ok
    status = next((name for severity, name in [('invalid_input', 'INVALID_INPUT'), ('numerical_failure', 'NUMERICAL_FAILURE'),
        ('invalid_geometry', 'INVALID_GEOMETRY'), ('outside_scope', 'OUTSIDE_SCOPE'),
        ('detail_fail', 'DETAILING_FAIL'), ('detail_pending', 'DETAILING_PENDING')] if severity in severities),
        'COMPLETE_CHECKS_FAIL' if failures else 'COMPLETE_LOCAL_CHECKS_PASS_WITHIN_SCOPE' if complete else 'INCOMPLETE_CHECKS')
    governing = max(out['checks'], key=lambda r: r['utilization']) if out['checks'] else None
    out.update(status=status, global_pass=passed, local_pass=passed, global_member_verified=False,
        summary=dict(complete_checks=complete, utilization=governing['utilization'] if governing else None,
            governing_id=governing['id'] if governing else None, failed_check_ids=failures,
            check_count=len(out['checks']), case_count=len(out['cases']), detailing_pass=detail_ok,
            mechanics_pass=complete and not failures, global_member_verified=False))
    return _safe(out)


def evaluate(c):
    out = dict(status='INVALID_INPUT', global_pass=False, local_pass=False, issues=[], checks=[], cases=[], geometry={},
        root={}, sections={}, paths=[], materials={}, member_actions={}, summary={},
        inputs=_safe(asdict(c)) if isinstance(c, BoltedAngleGusset) else _safe(c), family=FAMILY,
        connection_type=CONNECTION_TYPE, component_version=COMPONENT_VERSION, units=dict(UNITS),
        scope=SCOPE, exclusions=list(EXCLUSIONS), sources=dict(SOURCES))
    errors = input_errors(c)
    if errors:
        for j, error in enumerate(errors):
            _issue(out, 'input_'+str(j), 'invalid_input', error)
        return _finalize(out)
    out['fixed_assumptions'] = c.fixed_assumptions
    conditions = [
        (c.arrangement not in ARRANGEMENTS, 'arrangement', 'Arranjos permitidos:1L ou2L-T simétrico; oposto/asimétrico exige outro modelo de duas linhas.'),
        (c.support_member not in ('beam', 'column'), 'support_member', 'Apoio deve ser viga ou pilar W.'),
        (c.support_face != 'flange', 'support_face', 'Somente mesa exterior W, raiz longitudinal centrada na alma.'),
        (get_angle(c.angle_profile) is None, 'angle_catalog', 'Identidade exata de catálogo não reconhecida.'),
        (c.support_profile not in SUPPORT_CATALOG, 'support_catalog', 'W laminado com identidade exata não reconhecido.'),
        (c.bolt not in BOLTS, 'bolt_class', 'Classe de parafuso não reconhecida.'),
        (c.root_electrode not in ELECTRODES, 'root_electrode', 'Eletrodo de raiz não reconhecido.'),
        (c.exposure not in ('painted', 'weathering'), 'exposure', 'Exposição deve ser painted ou weathering.'),
        (c.bolt == 'ASTM A307' and c.pretensioned, 'pretension_grade', 'A307 não recebe dispensa de pega por protensão.'),
        (c.arrangement == '1L' and c.threads_excluded_2, 'inactive_plane', '1L não tem segundo plano; não declarar condição de rosca nesse plano inexistente.'),
        (c.N < 0, 'compression', 'N negativo é compressão, não convertido em módulo.'),
        (any(x != 0 for x in (c.V, c.M, c.torsion)), 'external_actions', 'V/M/T externos preservados, fora desta rota axial; momento geométrico calculado.'),
        (not c.static or c.fatigue or c.seismic, 'nonstatic', 'Somente tração estática sem fadiga/sismo, NBR6.1.8.2.'),
        (not c.normal_combination, 'combination', 'Fatores limitados a combinações normais.'),
        (not c.minimum_force and 0 <= c.N < 45000., 'minimum_force', 'Mínimo45kN desativado sem exceção qualificada para N<45kN.')]
    for test, id, message in conditions:
        if test:
            _issue(out, id, 'outside_scope', message)
    A = get_angle(c.angle_profile); W = SUPPORT_CATALOG.get(c.support_profile)
    materials = []
    for role, name, thicknesses in [('angle', c.angle_steel, [A['t']] if A else []),
        ('gusset', c.gusset_steel, [c.plate_t]), ('support', c.support_steel, [W['tf'], W['tw']] if W else [])]:
        material = MATERIALS.get(name)
        if material is None:
            _issue(out, role+'_material', 'outside_scope', role+': aço fora do catálogo.'); continue
        allowed = all(material.plate_allowed and material.plate_min <= t <= material.plate_max if role == 'gusset'
            else material.rolled_allowed and material.profile_min <= t <= material.profile_max for t in thicknesses)
        if not allowed:
            _issue(out, role+'_material_product', 'outside_scope', role+': produto/espessura fora do aço selecionado.')
        materials.append(material)
        out['materials'][role] = dict(name=name, fy=material.fy, fu=material.fu, thicknesses=thicknesses, source=material.source)
    if c.bolt in BOLTS:
        out['materials']['bolt'] = dict(name=c.bolt, fub=BOLTS[c.bolt])
    if c.root_electrode in ELECTRODES:
        out['materials']['root_weld'] = dict(name=c.root_electrode, fw=ELECTRODES[c.root_electrode])
    try:
        # Invalid topology must not reach arithmetic that presumes the arrangement.
        if any(i['severity'] == 'outside_scope' for i in out['issues']):
            return _finalize(out)
        g = _geometry(c, out)
        if g is not None:
            out['geometry'] = g
        # End-loaded uniform distribution is qualified only through 950 mm.
        # NBR6.3.8 states the long-group boundary for bearing-type tension
        # splices; conservatively adopt it for this end lap. Keep every local
        # diagnostic calculation, but do not approve an unqualified long group.
        if g and g['Lc'] > 950.:
            _issue(out, 'long_bolt_group', 'outside_scope',
                'Lc>950 mm: distribuição uniforme do grupo longo não qualificada nesta rota. '
                'Limite de NBR6.3.8 para emendas tracionadas adotado conservadoramente na sobreposição de extremidade; '
                'resultados locais mantidos como diagnóstico, sem correção automática1,20 ou aprovação do modelo longo.',
                actual=g['Lc'], qualified_limit=950., reference='NBR8800:2024/Errata1:2025 §6.3.8')
        if g and g['valid'] and len(materials) == 3:
            loads = [('actual', 'Tração total real informada', c.N)]
            if c.minimum_force and c.N < 45000.:
                loads.append(('minimum_45kN', 'Mínimo45kN da ligação inteira, repartido depois', 45000.))
            if c.recommend_half_capacity:
                angle = materials[0]; Ct = max(1.-A['centroid']/g['Lc'], .5)
                half = .5*c.angle_count*min(A['Ag']*angle.fy/GAMMA_A1, Ct*(A['Ag']-g['net_hole_diameter']*A['t'])*angle.fu/GAMMA_A2)
                loads.append(('recommended_half', 'Recomendação50% da resistência do conjunto de L', half))
            for id, label, force in loads:
                _calculate_case(c, g, force, id, label, out, materials)
        def finite(value):
            if isinstance(value, dict):
                return all(finite(x) for x in value.values())
            if isinstance(value, (list, tuple)):
                return all(finite(x) for x in value)
            return finite_real(value) if isinstance(value, (int, float)) and not isinstance(value, bool) else True
        if not finite(out):
            raise ArithmeticError('Resultado intermediário não finito.')
    except (ArithmeticError, ValueError, TypeError, OverflowError) as error:
        _issue(out, 'numerical_failure', 'numerical_failure', 'Cálculo não concluído: '+str(error))
    return _finalize(out)
