"""Native isolated UI for the full strong-axis corner joint, family 19.

Grouped physical inputs, a single COMPLETE_CUTS case, exact scalar import,
atomic rejection and current-input-bound artifact exports. No legacy migration.
"""
from copy import deepcopy
from dataclasses import replace
import hashlib
import json
import math
import pandas as pd
import streamlit as st
from .corner_gusset_presentation import (STATUS, SCOPE_TEXT, CUT_CONVENTION,
    physical_envelopes, compact_envelopes, memory_text, finite, number, input_fingerprint, utilization_text, applicability_notes, result_label, detail_note, is_single, is_bolted, scope_text, idealization_text, compression_notes)

PREFIX='cg_'
PROJECT='_corner_gusset_project'
DRAFT='_corner_gusset_ui_draft'
RESULT='_corner_gusset_result'
ACCEPTED='_corner_gusset_accepted_values'
TEMPLATE='_corner_gusset_native_template'
REPORT='cg_report'
OTHER='cg_other_loads_json'
LABELS={
 'project':'Identificação do projeto', 'beam_profile':'Perfil W da viga', 'column_profile':'Perfil W do pilar',
 'angle_profile':'Uma cantoneira do par 2L-T', 'angle_steel':'Aço das duas cantoneiras', 'gusset_steel':'Aço da chapa de nó',
 'beam_steel':'Aço da viga', 'column_steel':'Aço do pilar', 'continuity_steel':'Aço das chapas de continuidade',
 'fw_brace':'fw · quatro soldas L–chapa (MPa)', 'fw_root':'fw · raízes chapa–viga/pilar (MPa)',
 'fw_joint':'fw · ligação direta viga–pilar (MPa)', 'fw_continuity':'fw · continuidade (MPa)',
 'plate_width':'Largura externa da chapa, a partir da mesa do pilar (mm)',
 'plate_height':'Altura externa da chapa, a partir da mesa da viga (mm)', 'plate_t':'Espessura da chapa de nó (mm)',
 'corner_clip':'Recorte interior de canto · pernas iguais (mm)', 'root_weld_leg':'Perna dos filetes nas duas raízes (mm)',
 'phi_deg':'Inclinação φ a partir de +x horizontal (graus)', 'P':'N total da diagonal · tração positiva (kN)',
 'workpoint_offset':'Afastamento da linha de força · normal direita (mm)',
 'brace_weld_start':'Início das quatro soldas · coordenada u (mm)', 'brace_weld_length':'Comprimento efetivo das quatro soldas (mm)',
 'brace_free_end_extension':'Extensão da extremidade livre antes das soldas (mm)', 'brace_weld_leg':'Perna das quatro soldas 2L–chapa (mm)',
 'beam_seam_start_margin':'Raiz viga · margem após o recorte (mm)', 'beam_seam_end_margin':'Raiz viga · margem antes da borda externa (mm)',
 'column_seam_start_margin':'Raiz pilar · margem após o recorte (mm)', 'column_seam_end_margin':'Raiz pilar · margem antes da borda externa (mm)',
 'beam_web_weld_length':'Comprimento efetivo dos dois filetes da alma (mm)', 'beam_web_weld_leg':'Perna dos dois filetes da alma (mm)',
 'beam_access_radius':'Raio dos recortes de acesso da alma (mm)', 'matching_cjp':'CJP compatível nas duas mesas, garganta completa e WPS qualificada',
 'continuity_width':'Largura de cada chapa de continuidade (mm)', 'continuity_t':'Espessura da continuidade (mm)',
 'continuity_clip':'Recorte de raiz em cada chapa de continuidade (mm)',
 'continuity_flange_start_margin':'Continuidade · margem de solda após o recorte (mm)',
 'continuity_flange_end_margin':'Continuidade · margem até a borda livre (mm)',
 'continuity_web_end_margin':'Continuidade · margem da solda de alma até o recorte (mm)',
 'continuity_flange_weld_leg':'Continuidade · filetes nas mesas (mm)', 'continuity_web_weld_leg':'Continuidade · filetes na alma (mm)',
 'column_end_top':'Extremidade física superior do pilar · y (mm)', 'column_end_bottom':'Extremidade física inferior do pilar · y (mm)',
 'symmetric':'Duas L idênticas, simétricas e igualmente carregadas',
 'lateral_restraint':'Deslocamento lateral relativo das mesas impedido pelos pares de continuidade',
 'case_id':'Identificação da combinação concorrente', 'cuts_source':'Origem dos esforços e identificação dos cortes',
 'other_loads_excluded':'Declaro que não há outras cargas ou membros entre os cortes nomeados',
 'compare_lower_cut':'Comparar L derivado com o corte inferior correspondente do Robot',
 'E':'Módulo de elasticidade E (MPa)', 'gamma_a1':'γa1', 'gamma_a2':'γa2', 'gamma_w2':'γw2',
 'single_angle_face':'Face da cantoneira única',
 'topology':'Adaptador físico', 'load_convention':'Convenção de entrada',
}
LABELS.update({'compression_beam_restraint':'Raiz na viga · contenção fora do plano', 'compression_column_restraint':'Raiz no pilar · contenção fora do plano', 'compression_brace_restraint':'Extremidade/traspasse 2L · contenção fora do plano', 'compression_detail_source':'Fonte e descrição do detalhe ordinário · recorte, raízes e traspasse atuais'})
LABELS.update({'bolt':'Classe do parafuso','bolt_diameter':'Diâmetro do parafuso db (mm)','bolt_count':'Número de parafusos físicos na linha','bolt_start':'Primeiro parafuso · coordenada u (mm)','bolt_pitch':'Passo longitudinal dos parafusos (mm)','bolt_gauge':'Gramil da linha a partir do talão (mm)','bolt_angle_end':'Primeiro parafuso até a extremidade da L (mm)','bolt_drilled':'Furos broqueados ou com dedução sem acréscimo de 2 mm','bolt_threads_excluded_1':'Rosca fora do plano de corte 1','bolt_threads_excluded_2':'Rosca fora do plano de corte 2','bolt_pretensioned':'Parafusos de alta resistência protendidos','bolt_exposure':'Proteção das peças em contato','bolt_tool_radius':'Raio real do envelope de ferramenta ou hardware (mm)','bolt_fabrication_clearance':'Folga adicional de montagem (mm)','bolt_heel_extent':'Envelope interno real do talão (mm) · zero indica pendente','bolt_heel_extent_source':'Origem do envelope de talão','bolt_washer_stack':'Espessura total adicional das arruelas na pega (mm)'})
LABELS.update({'bolt_friction_type':'Extremidade por atrito · duas interfaces iguais',
 'bolt_surface_class':'Classe das duas superfícies de contato',
 'bolt_installation_source':'Detalhe de preparo, aperto, inspeção e hardware',
 'bolt_hardened_washer_count':'Arruelas endurecidas por parafuso',
 'bolt_washer_location':'Posição das arruelas endurecidas',
 'bolt_washer_diameter':'Diâmetro externo real da arruela (mm)',
 'bolt_angle_continuation':'Comprimento livre após o último furo no sentido +u (mm)',
 'bolt_continuation_source':'Próximo furo/borda ou continuação íntegra verificada',
 'combination_type':'Classificação do caso ELU para deslizamento'})
for _prefix,_label in [('beam_cut','D · viga'),('upper_column_cut','U · pilar superior'),('lower_column_cut','L · pilar inferior')]:
    for _keyname,_unit in [('x','mm'),('y','mm'),('Fx','kN'),('Fy','kN'),('M','kN·m')]:
        LABELS[_prefix+'_'+_keyname]=_label+' · '+_keyname+' ('+_unit+')'
for _component in ('Fx','Fy','M'):
    LABELS['lower_column_check_'+_component]='Robot · L · '+_component+(' (kN·m)' if _component=='M' else ' (kN)')


def _factor(name):
    if name=='P' or name.endswith(('_Fx','_Fy')):return 1000.
    if name.endswith('_M'):return 1e6
    return 1.


def _key(name):
    if isinstance(name,tuple):name='_'.join(map(str,name))
    return PREFIX+name+('_kN' if _factor(name)==1000 else '_kNm' if _factor(name)==1e6 else '')


def _unique_object(pairs):
    out={}
    for key,value in pairs:
        if key in out:raise ValueError('Chave JSON duplicada: '+key)
        out[key]=value
    return out


def _json_load(payload):
    if len(payload)>250000:raise ValueError('Arquivo maior que 250 kB.')
    def invalid(value):raise ValueError('Número JSON inválido: '+value)
    return json.loads(payload,object_pairs_hook=_unique_object,parse_constant=invalid)


def import_ui_values(c):
    native=c.to_dict();out={};accepted={}
    for name,raw in native['connection'].items():
        if name=='other_loads':
            display=json.dumps(raw,ensure_ascii=False,indent=2,allow_nan=False);key=OTHER
        elif type(raw) in (int,float):
            if not finite(raw) or float(raw)!=raw:raise ValueError(name+': número não representável sem perda.')
            display=raw if name in ('bolt_count','bolt_hardened_washer_count') else float(raw)/_factor(name);key=_key(name)
            if raw!=0 and display==0:raise ValueError(name+': conversão não representável.')
        else:display=raw;key=_key(name)
        out[key]=display;accepted[name]={'raw':deepcopy(raw),'display':display}
    out[ACCEPTED]=accepted;out[TEMPLATE]=deepcopy(native)
    return out


def decode_project(payload):
    from .corner_gusset import CornerGusset
    c=CornerGusset.from_dict(_json_load(payload));import_ui_values(c);return c


def seed(c):
    # Stage and validate the complete proposal before mutating accepted state.
    proposed=import_ui_values(c)
    st.session_state.update(proposed)
    st.session_state.pop(REPORT,None);st.session_state.pop(DRAFT,None)


def _current_native():
    s=st.session_state;native=deepcopy(s[TEMPLATE])
    for name,original in native['connection'].items():
        value=s[OTHER if name=='other_loads' else _key(name)];accepted=s[ACCEPTED][name]
        if value==accepted['display'] and type(value) is type(accepted['display']):raw=deepcopy(accepted['raw'])
        elif name=='other_loads':
            raw=_json_load(value)
            if not isinstance(raw,list):raise ValueError('Outras cargas devem ser uma lista JSON.')
        elif type(original) in (int,float):
            if not finite(value):raise ValueError(name+': número real finito obrigatório.')
            raw=int(value) if name in ('bolt_count','bolt_hardened_washer_count') and float(value).is_integer() else value*_factor(name)
            if not finite(raw):raise ArithmeticError(name+': conversão de unidade não finita.')
        else:raw=value
        native['connection'][name]=raw
    return native


def _save_draft():
    s=st.session_state;keys=[OTHER if n=='other_loads' else _key(n) for n in s[TEMPLATE]['connection']]
    keys += [ACCEPTED,TEMPLATE,'cg_report_detailed','cg_include_small_angles']
    s[DRAFT]={k:deepcopy(s[k]) for k in keys if k in s}


def use_example():
    from .corner_gusset import presets
    seed(presets()[st.session_state.cg_example])


def load_project():
    try:
        file=st.session_state.cg_upload
        if file is None:raise ValueError('Selecione um JSON nativo de canto.')
        c=decode_project(file.getvalue());seed(c);st.session_state.pop('cg_import_error',None)
    except (ValueError,TypeError,KeyError,ArithmeticError,UnicodeError) as exc:
        st.session_state.cg_import_error='Não foi possível abrir: '+str(exc)


def _scalar(name,options=None,labels=None):
    key=_key(name);value=st.session_state[key];label=LABELS.get(name,name)
    if st.session_state.get(_key('topology')) in ('single_1L_welded','single_1L_bolted'):
        label={'angle_profile':'Cantoneira única 1L','angle_steel':'Aço da cantoneira única',
               'fw_brace':'fw · duas soldas L–chapa (MPa)',
               'brace_weld_start':'Início das duas soldas · coordenada u (mm)',
               'brace_weld_length':'Comprimento efetivo das duas soldas (mm)',
               'brace_weld_leg':'Perna das duas soldas L–chapa (mm)'}.get(name,label)
    if options is not None:
        options=list(options)
        if value not in options:options.append(value)
        return st.selectbox(label,options,key=key,format_func=(lambda v:labels.get(v,str(v))) if labels else str)
    if type(value) is bool:return st.checkbox(label,key=key)
    if name=='bolt_hardened_washer_count':return st.number_input(label,min_value=0,max_value=2,step=1,key=key)
    if name=='bolt_count':return st.number_input(label,min_value=2,max_value=50,step=1,key=key)
    if type(value) in (int,float):return st.number_input(label,key=key,format='%.8f',**({'on_change':change_force_mode} if name=='P' else {}))
    return st.text_input(label,key=key)



def change_force_mode():
    from .corner_gusset import CornerGusset
    raw=_current_native()['connection']
    raw['other_loads']=tuple(raw['other_loads'])
    seed(CornerGusset(**raw))


def change_adapter():
    """Keep common inputs and restore each branch's last explicit controls."""
    from .corner_gusset import CornerGusset,BOLTED_FIELDS,WELDED_BRACE_FIELDS,BOLTED_COMPRESSION_FIELDS
    state=st.session_state;raw=_current_native()['connection'];target=state[_key('topology')]
    prior=state[TEMPLATE]['connection']['topology'];raw['topology']=prior
    branch='bolted' if prior.endswith('_bolted') else 'welded'
    saved=deepcopy(state.get('_corner_adapter_details',{}))
    names=BOLTED_FIELDS+BOLTED_COMPRESSION_FIELDS if branch=='bolted' else WELDED_BRACE_FIELDS
    saved[branch]={k:deepcopy(raw[k]) for k in names if k in raw}
    for k in BOLTED_FIELDS+BOLTED_COMPRESSION_FIELDS+WELDED_BRACE_FIELDS:raw.pop(k,None)
    branch='bolted' if target.endswith('_bolted') else 'welded'
    raw.update(saved.get(branch,{}));raw['topology']=target
    raw['symmetric']=target in ('symmetric_2L_T_welded','symmetric_2L_T_bolted')
    raw['single_angle_face']=state.get(_key('single_angle_face'),'positive') if target in ('single_1L_welded','single_1L_bolted') else 'positive'
    raw['other_loads']=tuple(raw['other_loads'])
    candidate=CornerGusset(**raw);candidate.to_dict()
    seed(candidate);state['_corner_adapter_details']=saved


def confirm_compression_detail():
    from .corner_gusset import CornerGusset
    from .corner_compression import geometry_stamp
    try:
        c=CornerGusset.from_dict(_current_native())
        if any(getattr(c,'compression_'+root+'_restraint')!='confirmed' for root in ('beam','column','brace')):
            raise ValueError('Confirme cada contenção física existente; condição desconhecida ou ausente não pode ser registrada como confirmada.')
        if c.compression_detail_source.strip() in ('','Não informado'):
            raise ValueError('Identifique a fonte e o detalhe físico ordinário do recorte, raízes e traspasse atuais.')
        seed(replace(c,compression_geometry_stamp=geometry_stamp(c)))
        st.session_state.pop('cg_compression_declaration_error',None)
    except (ValueError,TypeError,KeyError,ArithmeticError) as exc:
        st.session_state.cg_compression_declaration_error=str(exc)


def checks_complete(r):
    return r.get('complete') is True and r.get('status') in ('PASS','FAIL') and bool(r.get('checks')) and all(
        x.get('status') in ('PASS','FAIL','NOT_APPLICABLE') and
        (x.get('status')=='NOT_APPLICABLE' or (all(finite(x.get(k)) for k in ('demand','resistance')) and
         (finite(x.get('utilization')) or (x.get('utilization_unbounded') is True and x.get('status')=='FAIL'))))
        for x in r['checks'])


def _rows(rows):
    return pd.DataFrame([{'ID':x.get('id'),'Solicitação':x.get('demand'),'Resistência':x.get('resistance'),
        'η':utilization_text(x),'Estado':x.get('status'),'Fonte':x.get('source','')} for x in rows])


def _fail(exc):
    s=st.session_state;s.pop(REPORT,None);s.pop(PROJECT,None)
    if TEMPLATE in s:_save_draft()
    s[RESULT]={'status':'INVALID','checks':[],'issues':[{'id':'ui_input','severity':'error','message':str(exc)}]}
    st.error('DADOS INVÁLIDOS · '+str(exc))
    st.caption('Resultado e arquivos anteriores invalidados. Corrija a edição atual para recalcular.')
    st.button('Gerar memória de canto',disabled=True)


def render():
    try:_render()
    except (ValueError,TypeError,KeyError,ArithmeticError) as exc:_fail(exc)


def _render():
    from .corner_gusset import CornerGusset,FAMILY,COMPONENT_VERSION,MATERIALS,MEMBER_CATALOG,analyze,presets
    from .angle_catalog import catalog,label as angle_label
    from .corner_gusset_drawing import image_bytes,effort_convention_svg
    from .corner_gusset_report import create_report
    s=st.session_state;saved=s.get(PROJECT);draft=s.get(DRAFT);old_report=s.pop(REPORT,None)
    s.pop(PROJECT,None);s.pop(RESULT,None)
    if _key('project') not in s:
        seed(CornerGusset.from_dict(saved) if saved else CornerGusset())
        if draft:s.update(draft)
    # Preserve family widgets across navigation; accepted source precision is
    # retained until a particular control is explicitly edited.
    for n in s[TEMPLATE]['connection']:
        key=OTHER if n=='other_loads' else _key(n)
        if key in s:s[key]=s[key]
    with st.sidebar:
        st.caption(COMPONENT_VERSION+' · projeto nativo de canto')
        st.selectbox('Exemplo de canto',list(presets()),key='cg_example')
        st.button('Usar exemplo de canto',on_click=use_example)
        st.file_uploader('Abrir projeto de canto',type=['json'],key='cg_upload')
        st.button('Carregar projeto de canto',on_click=load_project)
        if 'cg_import_error' in s:st.error(s.cg_import_error)
    single=s[_key('topology')] in ('single_1L_welded','single_1L_bolted')
    bolted=s[_key('topology')] in ('single_1L_bolted','symmetric_2L_T_bolted')
    st.title('Ligação de canto '+('1L' if single else '2L-T')+'–gusset–viga/pilar · '+('parafusada' if bolted else 'soldada'))
    st.selectbox('Disposição da diagonal',('symmetric_2L_T_welded','single_1L_welded','symmetric_2L_T_bolted','single_1L_bolted'),key=_key('topology'),
                 format_func=lambda v:{'symmetric_2L_T_welded':'2L-T · duas faces simétricas','single_1L_welded':'1L · uma face, dois filetes','symmetric_2L_T_bolted':'2L-T · parafusos passantes, corte duplo','single_1L_bolted':'1L · parafusos, corte simples'}[v],on_change=change_adapter)
    st.info(scope_text(CornerGusset(topology=s[_key('topology')],symmetric=not single,P=s[_key('P')]*1000)))
    _scalar('project')
    left,right=st.columns([1,1.35],gap='large');rendered={'project','other_loads','topology'}
    from .corner_compression import RESTRAINT_FIELDS, STATUSES
    from .bolted_corner_compression import DETAIL_FIELDS
    rendered.update(RESTRAINT_FIELDS+DETAIL_FIELDS)
    def scalar(name,options=None,labels=None):
        if name in s[TEMPLATE]['connection']:
            _scalar(name,options,labels);rendered.add(name)
    with left:
        with st.expander('1 · Geometria e perfis de catálogo',expanded=True):
            scalar('beam_profile',MEMBER_CATALOG);scalar('column_profile',MEMBER_CATALOG)
            angles=catalog();include=st.checkbox('Incluir cantoneiras menores que 2½ pol.',key='cg_include_small_angles')
            scalar('angle_profile',[k for k,v in angles.items() if include or v['leg']>=63.5],{k:angle_label(k) for k in angles})
            selected=angles.get(s[_key('angle_profile')])
            if selected:st.caption('Uma L: b='+number(selected['leg'])+' mm; t='+number(selected['t'])+' mm; Ag='+number(selected['Ag'])+' mm²; ec='+number(selected['centroid'])+' mm. Raios não publicados não são inventados.')
            for n in ('plate_width','plate_height','plate_t','corner_clip'):scalar(n)
            st.caption('As duas raízes, seus comprimentos e centroides são derivados da chapa recortada, dos perfis e das margens. As bordas de contato continuam apoiadas além das extremidades efetivas das soldas.')
        with st.expander('2 · Força axial da diagonal e '+('parafusos' if bolted else 'duas soldas' if single else 'quatro soldas'),expanded=True):
            if single:scalar('single_angle_face',('positive','negative'),{'positive':'Face +z','negative':'Face −z'})
            for n in ('P','phi_deg'):scalar(n)
            if bolted:
                from .models import BOLTS
                from .bolted_angle_gusset import HOLES
                scalar('bolt',BOLTS);scalar('bolt_diameter',HOLES)
                for n in ('bolt_count','bolt_start','bolt_pitch','bolt_gauge','bolt_angle_end','bolt_drilled','bolt_threads_excluded_1'):scalar(n)
                if not single:scalar('bolt_threads_excluded_2')
                else:rendered.add('bolt_threads_excluded_2')
                for n in ('bolt_tool_radius','bolt_fabrication_clearance','bolt_heel_extent','bolt_heel_extent_source'):scalar(n)
                st.caption(str(s[_key('bolt_count')])+' parafusos físicos em uma linha; '+('1 plano por parafuso; N integral na L.' if single else '2 planos por parafuso passante; N/2 por L.')+' Cada furo da chapa única recebe N/n. Talão e ferramenta são dimensões reais de montagem; não são raios inventados de catálogo.')
                rendered.update(('brace_weld_start','brace_weld_length','brace_free_end_extension','brace_weld_leg','fw_brace'))
            else:
                for n in ('brace_weld_start','brace_weld_length','brace_free_end_extension','brace_weld_leg'):scalar(n)
            st.caption(('Uma L recebe N integral; chapa única e conjunto do nó recebem esse N uma só vez. ' if single else 'N é o total: N/2 por L; chapa única e conjunto do nó recebem N integral. ')+('φ parte de +x horizontal. N<0 ativa compressão local, com detalhe de contenção no grupo avançado; não é dimensionamento global da diagonal.' if not single else 'φ parte de +x horizontal. Compressão da diagonal permanece não qualificada neste adaptador.'))
        with st.expander('3 · Um caso completo de ações concorrentes',expanded=True):
            scalar('case_id');scalar('cuts_source');st.caption(CUT_CONVENTION)
            for prefix in ('beam_cut','upper_column_cut'):
                st.markdown('Corte '+('D · viga' if prefix=='beam_cut' else 'U · pilar superior'))
                for n in ('x','y','Fx','Fy','M'):scalar(prefix+'_'+n)
            for n in ('lower_column_cut_x','lower_column_cut_y'):scalar(n)
            scalar('other_loads_excluded')
            st.caption('Se existem outras cargas, desmarque a declaração e informe todas na lista abaixo. Sem declaração e sem dados, o caso fica incompleto. Não há entrada redundante N0/V0/M0.')
            st.text_area('Outras ações reais entre cortes · JSON em N, mm e N mm',key=OTHER,height=100)
            st.caption('Cada item: label, member (beam/column), point [x,y], Fx, Fy, M. Não inserir comandos ou registros de resultados.')
            scalar('compare_lower_cut')
            for n in ('lower_column_check_Fx','lower_column_check_Fy','lower_column_check_M'):scalar(n)
            st.caption('A comparação Robot só é usada quando ativada, para o mesmo corte, combinação e orientação de corpo livre. L não é uma terceira ação independente.')
        with st.expander('4 · Aços e consumíveis independentes'):
            for n in ('angle_steel','gusset_steel','beam_steel','column_steel','continuity_steel'):
                scalar(n,MATERIALS)
                material=MATERIALS[s[_key(n)]];st.caption('fy='+number(material['fy'])+' MPa; fu='+number(material['fu'])+' MPa')
            for n in (('fw_root','fw_joint','fw_continuity') if bolted else ('fw_brace','fw_root','fw_joint','fw_continuity')):scalar(n)
            st.caption('Alterar o aço do pilar não troca os demais aços. Consumíveis e compatibilidade/WPS pertencem às respectivas interfaces.')
        with st.expander('5 · Continuidade, CJP e detalhamento'):
            for n in ('matching_cjp','beam_web_weld_length','beam_web_weld_leg','beam_access_radius','continuity_width','continuity_t','continuity_clip','continuity_flange_weld_leg','continuity_web_weld_leg','root_weld_leg','lateral_restraint'):scalar(n)
            if not single:scalar('symmetric')
            else:rendered.add('symmetric')
            st.caption('Um par horizontal de chapas em cada nível das mesas. Cada chapa preserva sua excentricidade até a alma; não basta cancelar a excentricidade do par. Sem crédito de contato ajustado nem soma de resistência paralela da alma.')
        with st.expander('6 · Avançado: margens, domínio e coeficientes'):
            for n in ('beam_seam_start_margin','beam_seam_end_margin','column_seam_start_margin','column_seam_end_margin','continuity_flange_start_margin','continuity_flange_end_margin','continuity_web_end_margin','column_end_top','column_end_bottom','workpoint_offset','E','gamma_a1','gamma_a2','gamma_w2'):scalar(n)
            if bolted:
                scalar('bolt_pretensioned');scalar('bolt_exposure',('painted','weathering'),{'painted':'Pintado ou protegido','weathering':'Aço patinável exposto'});scalar('bolt_washer_stack')
            scalar('load_convention',('COMPLETE_CUTS',))
            st.caption('Afastamento positivo segue (senφ, −cosφ). Um afastamento não nulo é desenhado e permanece não verificado até qualificar sua redistribuição. Geometria inválida, falha resistente e método não qualificado são estados distintos.')
            for n in s[TEMPLATE]['connection']:
                if n not in rendered:scalar(n)
        if bolted and any(name in s[TEMPLATE]['connection'] for name in DETAIL_FIELDS):
            with st.expander('Extremidade por atrito · serviço e detalhe real',expanded=True):
                st.caption('Rota inicial 2L-T comprimida: extremidade por atrito é restrição explícita sob NBR5.3.6.2; não classifica todo par 2L nem verifica o membro global. Corte e contato ELU continuam separados. Protensão e espessura total de arruelas usam os campos existentes no grupo 6.')
                scalar('bolt_friction_type')
                scalar('bolt_surface_class',('unknown','A','B'),{'unknown':'Desconhecida','A':'Classe A · μ=0,30','B':'Classe B · μ=0,50'})
                scalar('bolt_installation_source')
                scalar('bolt_hardened_washer_count')
                scalar('bolt_washer_location',('none','rotating','both'),{'none':'Não documentada','rotating':'Sob o elemento girante','both':'Sob os dois elementos'})
                scalar('bolt_washer_diameter')
                scalar('combination_type',('unknown','normal_ultimate','special_ultimate','exceptional_ultimate'),{'unknown':'ELU não identificado','normal_ultimate':'ELU normal explicitamente identificado','special_ultimate':'ELU especial','exceptional_ultimate':'ELU excepcional'})
                st.caption('Somente ELU normal permite 0,70N no deslizamento local; não converte os cortes D/U em análise de serviço. Pré-tensão mínima vem da linha métrica ou imperial real da Tabela19; execução e conformidade das arruelas não são certificadas pelo cálculo.')
                if not single and s[_key('P')]<0:
                    scalar('bolt_angle_continuation');scalar('bolt_continuation_source')
                    st.caption('A parede carregada da L olha +u, para o membro contínuo. A ponta junto à raiz está descarregada; não pode fornecer o comprimento livre do último furo. p/r mínimo≤25 é limite local escolhido, não regra universal de passo.')
        if not single and s[_key('P')]<0:
            with st.expander('7 · Avançado: detalhe físico de contenção em compressão',expanded=True):
                st.caption('Informe as três condições reais do modelo ordinário. A contenção lateral do receptor, no grupo 5, não substitui estas condições. O recorte não é apoio; projeções geométricas são necessárias, mas não criam contenção.')
                labels={'unknown':'Desconhecida / não documentada','confirmed':'Confirmada no detalhe físico','absent':'Ausente / não atende ao modelo'}
                for name in RESTRAINT_FIELDS[:3]:scalar(name,STATUSES,labels)
                scalar('compression_detail_source')
                st.button('Registrar contenções na geometria atual',on_click=confirm_compression_detail)
                if 'cg_compression_declaration_error' in s:st.warning(s.cg_compression_declaration_error)
                if bolted:st.caption('O detalhe deve justificar contenção de translação relativa e torção das L em cada estação de parafuso, além da contenção fora do plano do traspasse. Pareamento, protensão ou uma marcação isolada não criam contenção. Parafusos, furos, contato, arruelas, ferramenta e fontes do detalhe fazem parte da identidade.')
                st.caption('Confirme novamente após mudar recorte, raízes, sobreposição ou detalhe físico relevante. Alterar N, cortes, aço ou coeficientes não muda esta declaração de geometria.')
    native=_current_native();c=CornerGusset.from_dict(native);_save_draft();r=analyze(c)
    encoded=json.dumps(native,ensure_ascii=False,indent=2,allow_nan=False)
    s[PROJECT]=native;s[RESULT]=r
    digest=input_fingerprint(c)
    with right:
        status=r.get('status');label=result_label(r)
        if status=='PASS' and checks_complete(r):st.success(label)
        elif status=='UNVERIFIED':st.warning(label)
        else:st.error(label)
        if r.get('design_cases'):st.info('N real='+number(c.P,1000)+' kN preservado. O resumo também verifica o mínimo45 kN em caso sintético separado: D/U como fundo, duas raízes e nó recalculados; corte inferior sintético não é Robot.')
        st.caption('Conclusão local da entrada atual. Não libera fabricação, estabilidade global nem qualificação sísmica/fadiga.')
        c1,c2,c3=st.columns(3);c1.metric('N total (kN)',number(c.P,1000));c2.metric('N por L (kN)',number(c.P,1000 if single else 2000));c3.metric('η governante',utilization_text(r))
        for item in r.get('issues',[]):
            msg=str(item.get('id',''))+' · '+str(item.get('message',item))
            if item.get('severity') in ('info','note'):st.caption(msg)
            elif item.get('severity') in ('warning','unverified'):st.warning(msg)
            else:st.error(msg)
        if single or bolted:st.caption(idealization_text(c))
        if r.get('compression'):
            with st.expander('Compressão local · faixa, comprimento e contenções',expanded=True):
                for note in compression_notes(c,r):st.caption(note)
                st.json(r['compression'],expanded=False)
        if r.get('service_slip'):
            with st.expander('Deslizamento de serviço · separado do ELU',expanded=True):
                from .corner_gusset_presentation import friction_notes
                for note in friction_notes(c,r):st.caption(note)
                st.json(r['service_slip'],expanded=False)
        png=image_bytes(c,fmt='png');st.image(png,width='stretch')
        with st.expander('Convenção positiva dos esforços · sem valores'):
            st.image(effort_convention_svg(c),width='stretch');st.caption(CUT_CONVENTION)
        g=r.get('geometry') or {}
        with st.expander('Derivados: costuras, centroides e propriedades'):
            st.json({k:g[k] for k in ('beam','column','angle','polygon','beam_seam','column_seam','alpha','beta','beam_seam_length','column_seam_length','brace_lines','continuity','whitmore','brace_angle_count','brace_weld_count','brace_connected_surface_z','brace_centroid_z','brace_angle_z_bounds','spatial_idealization','bolt_centers','physical_bolt_count','physical_shear_planes','hole_diameter','net_hole_diameter','bolt_grip','bolt_grip_factor') if k in g},expanded=False)
        st.subheader('Cortes, raízes e interface · mesmo caso')
        st.json(r.get('forces') or {},expanded=False)
        st.caption('A interface direta é recuperada do corte completo da viga com as ações da chapa. Somar novamente o caminho da diagonal duplica a carga. Compressão real no receptor ativa seus próprios estados limites.')
        with st.expander('Aplicabilidade dos modos · forças com seus sinais'):
            for note in applicability_notes(r):st.caption(note)
            for key,note in (r.get('details') or {}).items():st.caption(detail_note(key,note))
    envelopes=compact_envelopes(r)
    st.subheader('Governante por componente físico')
    if envelopes:
        st.dataframe(pd.DataFrame([{'Componente':x['component_label'],'η':utilization_text(x),'Estado':x['status'],'Governantes':'; '.join(x['governing_labels'])} for x in envelopes]),hide_index=True,width='stretch')
        for x in envelopes:
            with st.expander(x['component_label']+' · verificações e fontes'):
                st.dataframe(_rows(x['members']),hide_index=True,width='stretch');st.json(x['members'],expanded=False)
    else:st.warning('Nenhuma conclusão resistente disponível para estes dados.')
    with st.expander('Memória de cálculo em texto · selecionar e copiar'):
        s['cg_mc_current']=memory_text(c)
        st.text_area('MC da entrada atual',height=320,key='cg_mc_current',disabled=True)
    detailed=st.checkbox('Word detalhado · acrescentar primitivas, testemunhos e fontes',key='cg_report_detailed')
    ready=checks_complete(r)
    a,b,d=st.columns(3)
    artifact=('1L' if single else '2L_T')+('_parafusada' if bolted else '')
    a.download_button('Salvar projeto de canto .json',encoded,'ligacao_canto_'+artifact+'.json','application/json')
    result_export=json.dumps({'input':native,'result':r},ensure_ascii=False,indent=2,allow_nan=False)
    a.download_button('Baixar resultados completos de canto .json',result_export,'resultados_canto_'+artifact+'.json','application/json')
    b.download_button('Baixar desenho de canto .png',png,'ligacao_canto_'+artifact+'.png','image/png')
    b.download_button('Baixar desenho de canto .svg',image_bytes(c,fmt='svg'),'ligacao_canto_'+artifact+'.svg','image/svg+xml')
    report_key=digest+('detailed' if detailed else 'compact')
    if old_report and old_report[0]==report_key and ready:s[REPORT]=old_report
    if d.button('Gerar memória de canto',disabled=not ready):
        filename='memoria_canto_'+artifact+'_'+('detalhada' if detailed else 'resumida')+'.docx'
        s[REPORT]=(report_key,filename,create_report(c,detailed=detailed))
    if REPORT in s:
        d.download_button('Baixar memória de canto .docx',s[REPORT][2],s[REPORT][1],'application/vnd.openxmlformats-officedocument.wordprocessingml.document')
    if not ready:st.caption('Emissão da memória resistente bloqueada: resolver os dados ou o componente não verificado. O projeto e o desenho diagnóstico atuais continuam disponíveis.')
