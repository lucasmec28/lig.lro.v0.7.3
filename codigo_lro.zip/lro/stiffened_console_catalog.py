"""Bounded, audited receiver catalogue; factual dimensions, not resistance tables.
Gerdau Segmento Industrial p.3 explicitly publishes each US designation.
Fit envelopes intentionally smaller than source root/detailing clearances.
Materials must be confirmed for the actual member, never inferred from its name.
"""
GERDAU_SOURCE='https://gsn.gerdau.com/sites/gsn_gerdau/files/downloadable_files/Folder%20Perfis%20Estruturais%20Gerdau%20-%20Segmento%20Industrial.pdf'
MATERIALS={'ASTM A36':(36.,58.),'ASTM A572 Gr.50':(50.,65.),'ASTM A992':(50.,65.)}
# d, bf, tw, tf, flat web d′, conservative fit envelope, explicit US designation.
_ROWS={
'Gerdau W310×97':(308,305,9.9,15.4,245,228.6,'W12×65'),
'Gerdau W310×107':(311,306,10.9,17.0,245,228.6,'W12×72'),
'Gerdau W310×117':(314,307,11.9,18.7,245,228.6,'W12×79'),
'Gerdau W360×64':(347,203,7.7,13.5,288,254.,'W14×43'),
'Gerdau W360×72':(350,204,8.6,15.1,288,254.,'W14×48'),
'Gerdau W360×79':(354,205,9.4,16.8,288,254.,'W14×53'),
'Gerdau W360×91':(353,254,9.5,16.4,288,254.,'W14×61'),
'Gerdau W360×101':(357,255,10.5,18.3,286,254.,'W14×68'),
'Gerdau W360×110':(360,256,11.4,19.9,288,254.,'W14×74'),
'Gerdau W360×122':(363,257,13.0,21.7,288,254.,'W14×82'),
}
COLUMNS={name:dict(zip(('d','bf','tw','tf','flat_web','fit_clear','us_designation'),row),source=GERDAU_SOURCE,source_page=3,manufacturer='Gerdau') for name,row in _ROWS.items()}
for name,d,bf,tw,tf,clear,page in [('W14×90',14.,14.5,.440,.710,10.,'1-24'),('W14×43',13.7,8.,.305,.530,10.,'1-24'),('W12×65',12.1,12.,.390,.605,9.,'1-26')]:
    COLUMNS['AISC '+name]={'d':d*25.4,'bf':bf*25.4,'tw':tw*25.4,'tf':tf*25.4,'flat_web':None,'fit_clear':clear*25.4,'us_designation':name,'source':'AISC Manual 15, Table 1-1','source_page':page,'manufacturer':'AISC nominal'}
