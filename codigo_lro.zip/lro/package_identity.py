"""Full review package identity, separate from frozen component schemas."""
PACKAGE_ID = "0.9.72-candidatos-r016-dev.1"
SOURCE_BASE = "0.9.44-beam-on-beam-partial-dev"
REVIEW_ONLY = True
