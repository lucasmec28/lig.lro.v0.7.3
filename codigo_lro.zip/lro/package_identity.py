"""Application package identity; native component schemas stay frozen."""
PACKAGE_ID = "0.9.73"
SOURCE_BASE = "0.9.44-beam-on-beam-partial-dev"
REVIEW_ONLY = False
