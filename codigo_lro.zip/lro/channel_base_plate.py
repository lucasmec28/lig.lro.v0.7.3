"""Pinned channel base, bounded two-/four-anchor configurations (N, mm, MPa).

Ranzi & Kneen (2002) §4.3.4/A.2 compression, §5.2.2 generic tensile
cantilevers. Explicit NBR resistance adaptation; no AS phi multiplied by gamma.
This is not the I/H Type 2 formula or the channel 1/2-bolt yield-line model.
"""
from dataclasses import dataclass, field, fields, asdict, replace
import math
from .models import Profile, Check, Issue, STEELS, finite_real
from . import base_plate as common
from .concrete_components import ConcreteComponents, validate_components, add_component_checks
from .concrete_anchorage import anchor_tensions
from .upper_washer import UpperWasher

VERSION='0.9.53-channel-two-anchor-dev.1'
FAMILY='Placa de base · U rotulada'
REF='Ranzi e Kneen (2002), §4.3.4, Tabela 3, Apêndice A.2; §5.2.2, Fig.19'
NBR=common.NBR
CHANNEL_ANCHORS={'3/8"':9.525,'1/2"':12.7,'5/8"':15.875,**common.ANCHORS}


from .channel_catalog import channel_profiles, catalog_properties, nominal_flange_tip, FLANGE_TAPER_ASSUMPTION


@dataclass(frozen=True)
class ChannelBasePlate(common.BasePlate):
    project: str='Base U rotulada — dados de teste'
    L_plate: float=320.
    B_plate: float=240.
    anchor_x: float=30.
    anchor_y: float=70.
    anchor_layout: str='four'
    washer_alignment: str='unspecified'
    washer_offset_tolerance: float=0.
    washer_nut_type: str='unspecified'
    washer_detail_confirmed: bool=False
    centroid_back: float=13.
    centroid_from_catalog: bool=False
    straight_web_length: float=0.
    offset_y: float=0.
    column_steel: str='ASTM A36'
    weld_size: float=5.
    clear_geometry_confirmed: bool=False
    flange_min_thickness: float=0.
    flange_thickness_from_model: bool=False
    @property
    def effective_flange_min_thickness(self):
        return nominal_flange_tip(self.column) if self.flange_thickness_from_model else self.flange_min_thickness
    @property
    def flange_thickness_basis(self):
        return FLANGE_TAPER_ASSUMPTION if self.flange_thickness_from_model else 'Entrada manual/legada preservada; zero indica dado pendente. Modelo nominal opcional não foi aplicado.'
    tp: float=19.05
    N: float=30000.
    V: float=0.
    anchor_shear_model: str='welded_washer'
    anchor_washer_side: float=50.
    anchor_washer_t: float=6.35
    base_hole: float=0.
    M: float=field(default=0.,init=False,repr=False)
    base_fixity: str=field(default='pinned',init=False)
    @property
    def effective_clear(self):
        # Unverified nominal envelope is allowed only for provisional results;
        # validate() keeps the result pending until actual straight length exists.
        return self.straight_web_length if self.straight_web_length>0 else self.column.clear
    @property
    def model_type(self):return 3
    @property
    def catalog_label(self):return FAMILY
    @property
    def L(self):return self.L_plate
    @property
    def B(self):return self.B_plate
    @property
    def a(self):return self.anchor_x
    @property
    def effective_moment(self):return 0.
    @property
    def shear_eccentricity(self):return 0.
    @property
    def web_back(self):return self.offset_y-self.centroid_back
    @property
    def anchor_count(self):return 2 if self.anchor_layout=='two_symmetry' else 4
    @property
    def anchor_coordinates(self):
        if self.anchor_layout=='two_symmetry':return ((0.,-self.anchor_y),(0.,self.anchor_y))
        return tuple((x,y) for x in (-self.anchor_x,self.anchor_x) for y in (-self.anchor_y,self.anchor_y))
    @property
    def min_anchor_spacing(self):
        return 2*self.anchor_y if self.anchor_layout=='two_symmetry' else 2*min(self.anchor_x,self.anchor_y)
    @property
    def anchor_edge_distance(self):
        return min(self.L/2-(0. if self.anchor_layout=='two_symmetry' else self.anchor_x),self.B/2-self.anchor_y)
    @property
    def has_tabulated_anchor_detail(self):
        return any(math.isclose(self.db,x,abs_tol=1e-8) for x in common.ANCHORS.values())
    @property
    def actual_base_hole(self):
        if self.direct_anchor_shear:return self.direct_shear.hole_diameter
        if self.base_hole>0:return self.base_hole
        return common.detail_reference(self)['df'] if self.has_tabulated_anchor_detail else 0.
    @property
    def washer_clearance_components(self):
        """Signed, axis-separating margins for square washers, in mm.

        U/2 uses local obstacles, not the solid bounding box of the open U.
        Flanges conservatively occupy the entire projected width up to the
        deepest nominal root / verified straight-web limit. Expanding each
        obstacle by weld_size in BOTH axes is conservative at its corners.
        Unknown root geometry remains pending in validate().
        """
        s = self.anchor_washer_side / 2
        p = self.column
        root_t = p.tf
        if self.flange_thickness_from_model and catalog_properties(p) is not None:
            root_t = 2*p.tf - nominal_flange_tip(p)
        inner_x = min(self.effective_clear/2, p.d/2-root_t)
        z = self.weld_size
        gaps = {'plate_edge': self.anchor_edge_distance-s,
                'washer_pair': 2*self.anchor_y-2*s,
                'rear_web_weld': self.web_back+self.anchor_y-s-z,
                'front_web_weld': self.anchor_y-s-self.web_back-p.tw-z}
        # At x=0, both flanges have the same square-to-obstacle x gap.
        x_gap = inner_x-s
        for label, y in (('rear_flange_weld',-self.anchor_y),
                         ('front_flange_weld',self.anchor_y)):
            y_gap = max(self.web_back-(y+s), y-s-(self.web_back+p.bf))
            gaps[label] = max(x_gap,y_gap)-z
        return gaps

    @property
    def washer_clearance(self):
        s=self.anchor_washer_side/2
        if self.anchor_layout=='two_symmetry':
            return min(self.washer_clearance_components.values())
        # Preserve the legacy four-anchor domain in this focused U/2 fix.
        return min(self.anchor_edge_distance-s,self.anchor_x-s,self.anchor_y-s,
            self.web_back+self.anchor_y-s-self.weld_size,
            self.anchor_y-(self.web_back+self.column.bf)-s-self.weld_size)
    @property
    def washer_clearance_expression(self):
        return ('g = menor margem conservadora: borda, outra arruela, alma/solda e mesas/solda locais'
                if self.anchor_layout=='two_symmetry' else
                'g = menor folga real da arruela à alma, mesas, bordas e outra arruela')
    @property
    def assumptions(self):
        notes=[
        self.flange_thickness_basis,
        'Configuração local: um U laminado, placa retangular sem enrijecedores, quatro barras em (±ax,±ay) nos dois lados da alma e entre as mesas. N>0 comprime, N<0 traciona; V paralelo à alma. Sem momento externo aplicado, torção ou chave.',
        'Origem no centro da placa/grupo de barras. Dorso da alma y=ey−ec; centroide real do U em y=ey. ec é distância publicada do dorso ao centroide, não bf/2. O offset gera momento local N·ey, nunca apagado.',
        'Compressão limitada a contato integral: q(y)=N/(LB)[1+12ey·y/B²], qmin≥0. Envelope qmax cobre a pressão real. Balanços medidos às linhas efetivas 0,95d × 0,80bf na posição real do U; λ=1, sem redução para cargas leves. Região interna de três bordas apoiadas do U: a4=√(2d·bf)/3 para 1,25≤d/bf≤4 (Eq.130/132); fora desse intervalo, a4=bf√(2α²), α²=(√(4+9η²)−2)/24, η=d/bf (Eq.129/131), com bf<d conforme Fig.73/A.2.1. A correção de projeções assimétricas/envelope é adaptação mecânica declarada, não validação experimental do artigo.',
        'Tração: equilíbrio elástico de grupo rígido Ti=U/4[1+ey·yi/ay²], somente Ti≥0, sem contato simultâneo. §5.2.2: balanço de cada barra até a face real da alma, bt>0; be=min(2bt+dh; 2ax; clear−2ax). Faixas centradas nas barras, contidas na alma livre, sem sobreposição. Mesas e ação bidirecional sem crédito. Não usa os mecanismos específicos de 1/2 barras das Figs.47–52.',
        'Alavanca (prying): §5.4.2 do artigo, fator 1,4 sobre a tração de dimensionamento das barras (equivalente a φp=1/1,4). Ações nominais equilibradas são guardadas separadamente. ACI e interação usam o mesmo envelope 1,4Ti; solda usa a ação externa. A placa recebe adicionalmente o envelope conservador max(1,4Ti bt;0,4Ti eout), não equação literal da fonte; verifica raiz e faixa externa sob o mesmo allowance Q=0,4Ti. Não é solução de deformação/pressão de contato local nem limite universal para qualquer detalhe.',
        'Resistência da placa adaptada explicitamente: fy/γa1 (γa1=1,10) substitui o 0,9fy do artigo; nenhum produto φAS/γNBR. Contato NBR: 0,85fck/1,40, sem confinamento. ACI complementar mantém seus próprios φ, sem γ adicional.',
        'Solda contínua E7018 nas duas faces úteis da alma e duas faces EXTERNAS úteis das mesas, modelo elástico de linhas com garganta z/√2. Raios, pontas e trechos de retorno não recebem crédito; N/V completos, com excentricidade real centroide–grupo de soldas. Junta T nas faces planas: alma usa Tabela 11(min(tw,tp)); mesa usa o mínimo suficiente conservador Tabela 11(tp), envelope para espessura variável, não mínimo normativo exato. O teto de borda da NBR 6.2.6.2.2 não se aplica a estas linhas retas. Sem crédito a quinas/retornos; metal-base local verificado por envelope de tração/corte. AISC DG1 3ª ed. §4.5.2, p.54.',
        'Cortante por atrito ou quatro arruelas soldadas. Para barras, ey=0 quando V≠0; vetor Vi documentado e rotina ACI existente. Sem soma de atrito com barras. Soldas/peças das arruelas e ancoragem têm seus próprios escopos.',
        'Rigidez rotacional, estabilidade global, bloco armado e fundação não são dimensionados. A palavra rotulada descreve a hipótese global, não certifica rotação. Exemplos contêm apenas dados de teste.',
        ]
        if self.anchor_layout=='two_symmetry':
            if self.upper_washer.model=='fitted_direct':notes.append('Arruela superior com apoio direto: Dbase+2δ≤dh; furação conjunta após solda ou tolerância especificada, sem vazio ou calço. Porca pesada ASTM A563A UNC com engate integral. Área de contato conservadora ASME desconta tolerâncias da face/rebaixo, folga total da barra e borda da arruela. q=Td/A≤min(fy,arruela;fy,placa)/1,10 é critério elástico próprio; Td já inclui 1,4 uma vez. Corte e solda conforme caminho DG1 Ex4.7-6, reforçado por Fv,Rd não reduzido NBR. Curvatura reversa verificada na barra; sem binário artificial adicional na solda da arruela. Não se aplica este contato direto a arruela em ponte sobre furo alargado.')
            notes.append('O arranjo U/2 não pertence às disposições literais de base I/H de 4–8 chumbadores da NBR 8800, 6.7/Tabela 18. Empregam-se modelos mecânicos e resistências de componentes com fatores NBR declarados, além das verificações ACI próprias; os resultados não certificam conformidade literal da configuração com a Tabela 18.')
            notes[1]='Configuração local: um U laminado, placa retangular sem enrijecedores, duas barras em (0,−ay) e (0,+ay), alinhadas no eixo de simetria da seção em planta: uma atrás do dorso da alma, outra à frente da abertura. ax legado é conservado, mas não entra na geometria nem no cálculo deste arranjo. N>0 comprime, N<0 traciona; V paralelo à alma. Sem momento externo aplicado, torção ou chave.'
            notes[4]='Tração: equilíbrio elástico de grupo rígido Ti=U/2[1+ey·yi/ay²], somente Ti≥0, sem contato simultâneo. §5.2.2: balanço de cada barra até a face real da alma, bt>0; be=min(2bt+dh; T). Uma faixa por lado, centrada em x=0 e contida no trecho reto verificado da alma. Mesas e ação bidirecional sem crédito. É adaptação explícita do balanço genérico; não usa os mecanismos internos de 1/2 barras das Figs.47–52.'
            notes[8]='Cortante por atrito ou duas arruelas soldadas. Para barras, ey=0 quando V≠0; vetor Vi documentado, individual e equilibrado, sem soma de atrito com barras. O adaptador ACI usa a linha real 1×2, sem barras fictícias. Soldas/peças das arruelas e ancoragem têm seus próprios escopos.'
        return notes
    def to_dict(self):
        data=asdict(self);data.pop('M');data.pop('base_fixity')
        return dict(schema_version=1,app_version=VERSION,connection_type='base_plate_channel_pinned',connection=data,fixed_assumptions=self.assumptions)
    @staticmethod
    def from_dict(data,validate_values=True):
        if not isinstance(data,dict) or data.get('connection_type')!='base_plate_channel_pinned' or type(data.get('schema_version')) is not int or data['schema_version']!=1:
            raise ValueError('Arquivo não pertence à base U rotulada, esquema 1.')
        p=data.get('connection')
        if not isinstance(p,dict):raise ValueError('Dados da base U ausentes.')
        p=dict(p);unknown=set(p)-{f.name for f in fields(ChannelBasePlate) if f.init}
        if unknown:raise ValueError('Campos não aceitos: '+', '.join(sorted(unknown)))
        try:
            p['column']=Profile(**p['column'])
            from .active_shear_key import ActiveShearKey
            from .single_key_weld import SingleKeyWeld
            from .single_key_concrete import SingleKeyConcrete
            from .column_base_weld import ColumnBaseWeld
            for key,cls in [('active_key',ActiveShearKey),('upper_washer',UpperWasher),('single_key_weld',SingleKeyWeld),('single_key_concrete',SingleKeyConcrete),('concrete_components',ConcreteComponents),('column_weld',ColumnBaseWeld),('direct_shear',common.DirectAnchorShear)]:
                if key in p:p[key]=cls.from_dict(p[key])
            c=ChannelBasePlate(**p)
        except (TypeError,KeyError) as e:raise ValueError('Dados incompatíveis com base U.') from e
        if validate_values:
            errors=[i.text for i in validate(c) if i.severity=='error']
            if errors:raise ValueError('; '.join(errors))
        return c


def validate(c):
    issues=[]
    def err(t):issues.append(Issue('error',t,REF))
    if not isinstance(c.column,Profile):err('Seção U inválida.');return issues
    for f in fields(c):
        v=getattr(c,f.name)
        if type(f.default) in (int,float) and (not finite_real(v) or abs(v)>1e12):err(f.name+': número finito e magnitude ≤10¹² obrigatórios.')
    for k in ('d','bf','tw','tf','clear','area'):
        if not finite_real(getattr(c.column,k)) or not 1e-6<=getattr(c.column,k)<=1e12:err('Seção: '+k+' deve ser finito e estar entre 10⁻⁶ e 10¹².')
    for k in ('L_plate','B_plate','anchor_y','centroid_back','tp','db','fck','grout_fck','grout_t','weld_size','anchor_washer_side','anchor_washer_t'):
        if not finite_real(getattr(c,k)) or not 1e-6<=getattr(c,k)<=1e12:err(k+': valor finito entre 10⁻⁶ e 10¹² obrigatório.')
    if issues:return issues
    p=c.column
    if any(not isinstance(getattr(c,k),str) for k in ('washer_alignment','washer_nut_type')):err('Identificação do detalhe ajustado deve ser texto.');return issues
    if type(c.washer_detail_confirmed) is not bool:err('Confirmação do detalhe ajustado deve ser booleana.');return issues
    if c.washer_offset_tolerance<0:err('Tolerância de alinhamento dos furos não pode ser negativa.');return issues
    if c.anchor_layout not in ('four','two_symmetry'):err('Arranjo de chumbadores deve ser quatro ou dois no eixo de simetria.');return issues
    if c.anchor_layout=='four' and not 1e-6<=c.anchor_x<=1e12:err('anchor_x: valor positivo obrigatório para quatro barras.')
    if any(not isinstance(getattr(p,k),str) for k in ("name","family","source")):err("Identificação e origem da seção devem ser texto.");return issues
    if not p.family.upper().startswith('U'):err('Família do perfil deve ser U; não converter I/H ou cantoneira.')
    if p.d<=2*p.tf or p.bf<=p.tw or p.clear>p.d-2*p.tf+1e-7:err('Dimensões do U inconsistentes.')
    if not p.tw/2<c.centroid_back<p.bf:err('Centroide deve estar dentro do U, medido a partir do dorso.')
    if c.N>0 and p.bf>=p.d:err('Compressão U: mecanismo Fig.73/A.2.1 requer bf<d; outro mecanismo não implementado.')
    for k in ('plate_steel','column_steel'):
        if getattr(c,k) not in STEELS:err(k+': aço não reconhecido.')
    if c.plate_steel in STEELS:
        steel=STEELS[c.plate_steel]
        if not steel.plate_allowed:err("Aço não aplicável a chapas.")
        elif not steel.plate_min<=c.tp<=steel.plate_max:
            issues.append(Issue("noncompliance","Espessura fora da faixa do produto de aço da placa.",steel.source))
    if not 20<=c.fck<=50:err('Concreto normal: 20≤fck≤50 MPa.')
    if not c.direct_anchor_shear and not any(math.isclose(c.db,x,abs_tol=1e-8) for x in CHANNEL_ANCHORS.values()):err('Diâmetro de chumbador fora da série implementada.')
    if c.base_hole<0:err('Furo real da placa não pode ser negativo.')
    if not c.direct_anchor_shear and c.anchor_layout=='two_symmetry' and c.base_hole<=0:err('Duas barras: informe o furo real/adotado da placa; a Tabela 18 não qualifica este arranjo.')
    if c.anchor_washer_side<=c.anchor_washer_hole:err('Furo padrão db+1,5 mm deve caber estritamente na arruela superior.')
    if not c.direct_anchor_shear and not c.has_tabulated_anchor_detail:
        if c.base_hole<=0:err('Chumbadores de 3/8, 1/2 e 5/8 pol. exigem informar o furo circular real da placa; não há linha na Tabela 18 implementada.')
        issues.append(Issue('info' if c.anchor_layout=='two_symmetry' and c.upper_washer.model=='fitted_direct' else 'pending','Chumbador abaixo de 3/4 pol.: sem detalhamento de referência na Tabela 18 implementada. Furo, arruela, porcas, embutimento e ancoragem exigem detalhe específico documentado; selecionar o diâmetro não aprova o detalhe.',NBR,origin='channel_anchor_detail'))
    hole=c.actual_base_hole
    if hole and (hole<=c.db or hole>=min(c.anchor_washer_side,2*c.anchor_edge_distance,c.min_anchor_spacing)):
        err('Furo real deve conter a barra com folga, caber sob a arruela, permanecer inteiro na placa e separado dos demais furos.')
    if isinstance(c.upper_washer,UpperWasher) and c.upper_washer.model=='fitted_direct' and c.anchor_layout!='two_symmetry':err('O detalhe ajustado de arruela desta revisão exige exatamente duas barras no eixo de simetria.')
    if c.shear_path not in ('friction','anchors'):err('Base U deste incremento: atrito ou chumbadores com arruelas soldadas.')
    if c.shear_path=='anchors' and c.anchor_shear_model not in ('welded_washer','direct_plate_bearing'):err('Cortante por barras requer arruelas soldadas nativas.')
    if c.shear_path=='anchors' and c.V!=0 and c.offset_y!=0:err('V por barras com ey≠0 exige torção do grupo não implementada.')
    if c.stiffener_detail!='none':err('Base U sem enrijecedores neste domínio.')
    if c.column_weld.model!='off':err('Não aplicar o modelo de solda I/H à base U; esta família tem grupo de solda próprio.')
    if c.L/2<=p.d/2+c.weld_size or min(c.B/2+c.web_back,c.B/2-c.web_back-p.bf)<=c.weld_size:err('U e solda não cabem integralmente na placa.')
    if c.washer_clearance<=0:err('Arruelas interferem com alma, mesas, outra arruela ou borda; ajustar ax/ay/placa.')
    if c.effective_clear<=2*c.weld_size or p.bf<=p.tw+2*c.weld_size:err("Trechos retos positivos de solda não cabem na seção.")
    if c.anchor_layout=='four' and 2*c.anchor_x>=c.effective_clear:err('Barras precisam estar entre as mesas e dentro da extensão livre da alma.')
    if c.N>0 and abs(c.offset_y)>c.B/6+1e-10:err('Contato parcial: fora do núcleo central B/6; esta família não resolve contato+tração simultâneos.')
    if c.N<0 and abs(c.offset_y)>c.anchor_y+1e-10:err('Tração com contato simultâneo: centroide fora do grupo de barras.')
    info=catalog_properties(p)
    if type(c.centroid_from_catalog) is not bool:err('Modo automático do centroide deve ser booleano.')
    if c.centroid_from_catalog and (info is None or not math.isclose(c.centroid_back,info['ec_mm'],abs_tol=1e-8)):
        err('Centroide automático incompatível com o perfil Gerdau selecionado.')
    if c.straight_web_length<0 or c.straight_web_length>p.d-2*p.tf:
        err('Comprimento reto medido deve ser positivo e não exceder o envelope d−2tf.')
    if info is not None and c.straight_web_length<=0:
        issues.append(Issue('pending','Catálogo Gerdau não publica T reto entre raízes: informar comprimento verificado. d−2tf é somente envelope nominal, sem aprovação.',REF,origin='channel_geometry'))
    if type(c.clear_geometry_confirmed) is not bool:err("Confirmação da geometria livre deve ser booleana.")
    if c.flange_min_thickness<0 or c.flange_min_thickness>p.tf:err("Espessura mínima real da mesa deve estar entre zero (não informada) e tf médio.")
    if type(c.flange_thickness_from_model) is not bool:err('Modo da espessura nominal deve ser booleano.')
    if c.flange_thickness_from_model and info is None:err('Espessura nominal automática exige perfil exato do catálogo Gerdau.')
    if c.flange_thickness_from_model and info is not None:
        if nominal_flange_tip(p)<=0:err('Hipótese de espessura nominal produz ponta não positiva.')
        issues.append(Issue('info',FLANGE_TAPER_ASSUMPTION,'Hipótese geométrica de projeto',origin='channel_flange_model'))
    if not c.flange_thickness_from_model and c.flange_min_thickness==0:
        issues.append(Issue("pending","Informar espessura mínima real da mesa na faixa soldada; tf médio de catálogo não é espessura mínima.",NBR,origin="channel_geometry"))
    if not c.clear_geometry_confirmed:
        issues.append(Issue("pending","Confirmar comprimento realmente livre entre raízes das mesas e acesso das arruelas/soldas. tf médio do U laminado não define essa dimensão; clear de catálogo é apenas envelope nominal.",REF,origin="channel_geometry"))
    from .base_plate_details import validate_details
    issues+=validate_details(c)
    from .upper_washer import validate_upper_washer
    issues+=validate_upper_washer(c)
    if not c.direct_anchor_shear and isinstance(c.upper_washer,UpperWasher) and c.upper_washer.model!='off' and c.upper_washer.base_hole>0 and not math.isclose(c.upper_washer.base_hole,c.actual_base_hole,abs_tol=1e-8):
        err('Furo do modelo local da arruela deve coincidir com o furo real da placa U.')
    if not c.direct_anchor_shear and c.upper_washer.model!="off" and c.upper_washer.base_hole>=c.min_anchor_spacing:err("Furos das arruelas devem permanecer separados no passo real U.")
    if c.weld_web_type!="unspecified" or c.weld_flange_type!="unspecified":err("Base U: use weld_size do grupo próprio; campos de solda I/H devem permanecer não especificados.")
    issues+=validate_components(c)
    from .direct_anchor_adapter import validate_direct_data
    issues+=validate_direct_data(c)
    return issues


def reactions(c):
    p=c.column;N=c.N;U=max(-N,0);P=max(N,0)
    rods=[dict(id=f'A{i}',x=x,y=y,tension=U/c.anchor_count*(1+c.offset_y*y/c.anchor_y**2))
        for i,(x,y) in enumerate(c.anchor_coordinates,1)]
    q=P/(c.L*c.B);qmax=q*(1+6*abs(c.offset_y)/c.B);qmin=q*(1-6*abs(c.offset_y)/c.B)
    a1=(c.L-.95*p.d)/2
    a2=c.B/2-.4*p.bf+abs(c.web_back+p.bf/2)
    eta=p.d/p.bf
    # Eq.130 is the conservative approximation only on 1.25<=eta<=4.
    # Outside it, Eq.129+131 gives the general Fig.73 panel solution for eta>1.
    # alpha²=(s-2)/24 is algebraically identical to published Eq.129.
    approximate=1.25<=eta<=4
    alpha2=(math.sqrt(4+9*eta*eta)-2)/24
    a4=math.sqrt(2*p.d*p.bf)/3 if approximate else p.bf*math.sqrt(2*alpha2)
    panel_method='Eq.130/132 · aproximação conservadora' if approximate else 'Eq.129/131 · expressão geral (bf<d)'
    lmax=max(a1,a2,a4);tc=lmax*math.sqrt(2*qmax/(c.fy/common.G1))
    strips=[]
    for rod in rods:
        bt=c.web_back-rod['y'] if rod['y']<c.web_back else rod['y']-(c.web_back+p.tw)
        be=(min(2*bt+c.actual_base_hole,c.effective_clear) if c.anchor_layout=='two_symmetry' else
            min(2*bt+c.actual_base_hole,2*c.anchor_x,c.effective_clear-2*c.anchor_x))
        eout=c.B/2-abs(rod['y'])
        moment=max(1.4*rod['tension']*bt,.4*rod['tension']*eout)
        tt=math.sqrt(4*moment/(be*c.fy/common.G1)) if rod['tension'] else 0.
        strips.append(dict(id=rod['id'],bt=bt,be=be,eout=eout,t_required=tt,moment=moment))
    tt=max(s['t_required'] for s in strips)
    design_rods=[dict(rod,tension=1.4*rod['tension']) for rod in rods]
    return dict(case='UC' if P else 'UT' if U else 'U0',C=P,T_total=U,Ft_max=max(r['tension'] for r in design_rods),Ft_min=min(r['tension'] for r in design_rods),
        rods=design_rods,nominal_rods=rods,prying_factor=1.4,anchor_design_tension=1.4*U,strips=strips,sigma=qmax,qmin=qmin,qmean=q,lc=c.L,C_x=0.,C_y=c.offset_y if P else 0.,T_max_x=0. if c.anchor_layout=='two_symmetry' else -c.a,T_min_x=0. if c.anchor_layout=='two_symmetry' else c.a,
        t_contact=tc,t_tension=tt,t_required=max(tc,tt),a1=a1,a2=a2,a4=a4,panel_method=panel_method,panel_alpha2=alpha2,lmax=lmax,lambda_=1.,L=c.L,B=c.B,
        column_centroid=(0.,c.offset_y),web_back=c.web_back,local_moment_x=N*c.offset_y,
        residual_N=P-sum(r['tension'] for r in rods)-N,
        residual_Mx=P*(c.offset_y if P else 0)-sum(r['tension']*r['y'] for r in rods)-N*c.offset_y,
        residual_My=-sum(r['tension']*r['x'] for r in rods),M_input=0.,M_effective=0.)


class ChannelResult(common.BasePlateResult):
    @property
    def component_status(self):
        base=super().component_status
        if base=="ATENDE ÀS VERIFICAÇÕES REALIZADAS" and any(i.severity=="pending" for i in self.issues):
            return "VERIFICAÇÕES LOCAIS COM CONDIÇÕES PENDENTES"
        return base
    @property
    def calculation_note(self):
        washer=(' Arruela ajustada, porca normalizada e transferência local verificadas no domínio declarado.'
                if self.local_upper_washer.get('model')=='fitted_direct' and self.local_upper_washer.get('status')=='pass' else '')
        return ('Escopo local: equilíbrio, placa U, contato, solda e aço das barras; ancoragem ACI quando selecionada.'+
                washer+' Bloco armado, fundação e estabilidade global pertencem à disciplina civil.')


def evaluate(c):
    r=ChannelResult(issues=validate(c))
    if any(i.severity=='error' for i in r.issues):return r
    g=reactions(c);r.geometry=g
    def add(i,n,sd,rd,u,ref,eq,sub='',var=''):
        r.checks.append(Check('u_'+i,n,sd,rd,u,ref,eq,sub or f'Sd={sd:.8g}; Rd={rd:.8g}',var))
    add('grout','Graute — resistência característica',2*c.fck,c.grout_fck,'MPa',NBR,'fck,graute≥2fck')
    if g['C']:
        add('contact','Concreto — pressão máxima de contato',g['sigma'],c.sigma_rd,'MPa',NBR,'qmax≤0,85fck/γc')
        add('plate_compression','Placa U — flexão sob compressão',g['t_contact'],c.tp,'mm',REF,'t=max(a1,a2,a4)√(2qmax/(fy/γa1)); λ=1',var='Projeções assimétricas; envelope de contato integral; adaptação explicitada nas premissas.')
    if g['T_total']:
        for s,rod in zip(g['strips'],g['nominal_rods']):
            add('plate_'+s['id'],'Placa U — balanço da barra '+s['id'],s['t_required'],c.tp,'mm',REF+' §5.2.2','t=√(4 max(1,4Ti bt;0,4Ti eout)/(be fy/γa1))',f'Ti={rod["tension"]:.8g}; bt={s["bt"]:.8g}; be={s["be"]:.8g}; t={s["t_required"]:.8g}')
        add('anchor_tension','Chumbador '+c.anchor_material_name+' — ruptura à tração',g['Ft_max'],c.anchor_steel_rd,'N',NBR,'1,4Ti≤Ft,Rd=0,75Ag fu/γa2',var='Ranzi–Kneen §5.4.2: φp=1/1,4 aplicado uma vez às barras; ações nominais e envelope de dimensionamento separados.')
    weld_checks(c,r,add)
    if c.shear_path=='friction':
        rd=min(common.MU*g['C']/common.G2,c.tau_rd*c.L*c.B);g['shear_rd']=rd
        if c.V!=0:
            add('friction','Cortante — atrito no graute',abs(c.V),rd,'N',NBR,'VRd=min(0,45C/γa2; τRd LB)')
    elif c.direct_anchor_shear:
        from .direct_anchor_adapter import add_direct_checks
        add_direct_checks(c,r,add)
    else:
        def add_native(*args):
            if c.anchor_layout=='two_symmetry':
                args=list(v.replace('quatro','duas').replace('Quatro parcelas','Duas parcelas') if isinstance(v,str) else v for v in args)
                args[5]+=' · adaptação mecânica U/2; configuração fora da Tabela 18 (4–8 barras)'
            add(*args)
        common._add_native_anchor_shear_checks(c,r,add_native,table_detail=c.has_tabulated_anchor_detail and c.anchor_count==4)
        if c.anchor_layout=='two_symmetry' and c.V!=0:
            for rod in g['anchor_shear']['rods']:
                add('anchor_shear_two_'+rod['id'],'Chumbador '+rod['id']+' — cortante individual simétrico',abs(c.V)/2,rod['rd'],'N',
                    NBR+' 6.7.2.5 e 6.3.3.4 como adaptação mecânica; equilíbrio plano do grupo 1×2',
                    '|V|/2 ≤ VRd,i condicionado à tração concorrente',
                    f'Vi={abs(c.V)/2:.8g}; VRd,i={rod["rd"]:.8g}; Ti={rod["tension"]:.8g}',
                    'Hipótese explícita: duas barras idênticas mobilizadas pelas arruelas soldadas, ey=0 e torção nula. A distribuição física e o concreto exigem qualificação separada.')
        if c.upper_washer.model not in ('off','fitted_direct'):
            from .upper_washer import add_upper_washer_checks
            r.local_upper_washer=add_upper_washer_checks(c,r,add)
        if c.V!=0 and c.upper_washer.model=='off':r.issues.append(Issue('pending','Cortante pelas barras: soldas e metal-base das arruelas requerem detalhe e verificação local.','NBR 6.7.2.5',origin='data'))
    if not c.direct_anchor_shear and c.anchor_layout=='two_symmetry' and c.upper_washer.model=='fitted_direct':
        from .channel_upper_washer import evaluate as evaluate_fitted_washer
        r.local_upper_washer=evaluate_fitted_washer(c,r,add)
    elif c.anchor_layout=='two_symmetry' and g['T_total']:
        r.issues.append(Issue('pending','Tração em duas barras: o modelo de arruela legado não verifica apoio axial sobre furo. Selecionar detalhe ajustado aplicável ou fornecer modelo específico de transferência axial.',REF,origin='channel_washer'))
    common._add_concrete_cone(c,r,add)
    r.concrete_components=add_component_checks(c,r,add)
    if (g['T_total'] or (c.V and c.shear_path=='anchors')) and c.concrete_components.model=='off':
        r.issues.append(Issue('pending','Há ações nos chumbadores: selecionar e completar os modos de ancoragem ACI aplicáveis.','ACI 318-19 capítulo 17',origin='concrete_components'))
    if c.direct_anchor_shear:
        from .direct_anchor_adapter import finalize_direct_route
        finalize_direct_route(c,r,add)
    for issue in r.issues:
        if issue.origin=="concrete_components_scope" or issue.text.startswith(("Cone de tração ACI 318-19/DG1:","O limite local 5db²σc,Rd")):
            issue.severity="info"
        if c.anchor_layout=='two_symmetry' and r.local_upper_washer.get('status')=='pass':
            if issue.text.startswith('O limite local 5db²σc,Rd'):
                issue.text=('O limite local 5db²σc,Rd utiliza σc,Rd=0,85fck/γc sem ganho por confinamento. '
                    'Cone, arrancamento, pryout, bordas, grupo e interação são verificações independentes, com resultados e eventuais pendências apresentados separadamente. '
                    'A transferência local pela arruela ajustada e porca normalizada está verificada no domínio declarado. '
                    'O dimensionamento do bloco armado e da fundação pertence à disciplina civil.')
            elif issue.origin=='concrete_components_scope':
                issue.text=('Resultados ACI limitados aos modos aplicáveis e estados enumerados; consultar as verificações e eventuais pendências de cada modo. '
                    'A peça de ancoragem enterrada e seu detalhamento devem corresponder aos dados qualificados. '
                    'A transferência local pela arruela superior ajustada está verificada no domínio declarado. '
                    'Fendilhamento, detalhamento do bloco e fundação permanecem no projeto civil.')
    r.actual=list(r.checks)
    return r


def weld_checks(c,r,add):
    p=c.column;b=c.web_back;z=c.weld_size;a=z/math.sqrt(2)
    # Effective straight runs exclude end deductions and the rolled root zone.
    clear=max(0.,c.effective_clear-2*z);flange=max(0.,p.bf-p.tw-2*z)
    seg=[((-clear/2,b),(clear/2,b)),((-clear/2,b+p.tw),(clear/2,b+p.tw))]
    for x in (-p.d/2,p.d/2):seg.append(((x,b+p.tw+z),(x,b+p.bf-z)))
    length=sum(math.dist(u,v) for u,v in seg)
    cx=sum(math.dist(u,v)*(u[0]+v[0])/2 for u,v in seg)/length
    cy=sum(math.dist(u,v)*(u[1]+v[1])/2 for u,v in seg)/length
    ix=sum(math.dist(u,v)*((u[1]-cy)**2+(u[1]-cy)*(v[1]-cy)+(v[1]-cy)**2)/3 for u,v in seg)
    iy=sum(math.dist(u,v)*((u[0]-cx)**2+(u[0]-cx)*(v[0]-cx)+(v[0]-cx)**2)/3 for u,v in seg)
    mx=c.N*(c.offset_y-cy);mz=-c.V*(c.offset_y-cy);J=ix+iy
    demand=max(math.sqrt((c.N/length+mx*(v[1]-cy)/ix)**2+(c.V/length-mz*(v[1]-cy)/J)**2+(mz*(v[0]-cx)/J)**2) for s in seg for v in s)
    rd=.6*485*a/1.35
    add('weld','Solda U–placa — resultante elástica',demand,rd,'N/mm',NBR+' 6.2','qmax≤0,6fw·a/γw2',var='N integral pela solda, sem desconto por contato; excentricidade centroide–solda preservada.')
    add('weld_length_web','Solda da alma — extensão contínua mínima',max(40.,4*z),c.effective_clear,'mm',NBR,'Lreal≥max(40;4z)')
    add('weld_length_flange','Solda externa da mesa — extensão contínua mínima',max(40.,4*z),p.bf,'mm',NBR,'Lreal≥max(40;4z)',var='Execução contínua na face externa inteira; só trecho reto descontado recebe crédito resistente.')
    # Straight column-end/base-top runs form T-joints, not exposed lap edges.
    # Flange thickness varies; Table 11(tp) bounds Table 11(min(t_local,tp))
    # without inventing a root radius or using the minimum tip as a maximum.
    for part,thin in [('alma',min(p.tw,c.tp)),('mesa',c.tp)]:
        minimum=3 if thin<=6.3 else 5 if thin<=12.5 else 6 if thin<=19 else 8
        label='Filete mesa — mínimo suficiente conservador' if part=='mesa' else 'Filete alma — perna mínima'
        note=('Envelope de simplificação: Tabela 11(tp) ≥ Tabela 11(min(tlocal,tp)) para toda espessura local; não é o mínimo normativo exato universal. Inclui possível espessamento da raiz sem estimar raio.' if part=='mesa' else 'Espessura uniforme conhecida da alma; peça menos espessa governa.')
        add('weld_min_'+part,label,minimum,z,'mm',NBR+' 6.2.6.2.1 / Tabela 11; AISC DG1 3ª ed. §4.5.2','z≥Tabela11(tp)' if part=='mesa' else 'z≥Tabela11(min(tw,tp))',var=note)
    # NBR 6.2.6.2.2 exposed-edge cap is not applied to these straight T runs.
    if c.effective_flange_min_thickness>0:
        minsteel=min(p.tw,c.effective_flange_min_thickness)
        base=min(STEELS[c.column_steel].fu*minsteel,STEELS[c.plate_steel].fu*c.tp)*.6/1.35
        add('weld_basemetal','Metal-base junto à solda — envelope local'+(' nominal 16,14%' if c.flange_thickness_from_model else ''),demand,base,'N/mm',NBR+' 6.5','qmax≤0,6fu·tmin/γa2',var='Envelope de ruptura local; não é análise global do membro.')
    r.local_column_weld=dict(model='channel_elastic_lines',status='pass' if all(x.passed for x in r.checks if x.id.startswith('u_weld')) else 'fail',segments=seg,length=length,centroid=(cx,cy),Ix=ix,Iy=iy,Mx=mx,Mz=mz,qmax=demand)
    r.geometry['weld']=r.local_column_weld
    r.geometry['flange_thickness']=dict(mode='nominal_taper' if c.flange_thickness_from_model else 'manual',effective_mm=c.effective_flange_min_thickness,manual_mm=c.flange_min_thickness,basis=c.flange_thickness_basis)


def presets():
    p=channel_profiles()['U 152 × 12,2'];c=ChannelBasePlate(p,centroid_from_catalog=True,flange_thickness_from_model=True,weld_size=8.)
    return {'U · compressão — teste':c,
            'U · dois chumbadores · compressão — teste':replace(c,anchor_layout='two_symmetry',base_hole=33.,project='Base U dois chumbadores — teste de compressão'),
            'U · dois chumbadores · tração e corte — teste':replace(c,anchor_layout='two_symmetry',base_hole=20.55,N=-10000.,V=1000.,shear_path='anchors',B_plate=260.,anchor_y=80.,anchor_washer_t=8.,washer_alignment='joint_drilled',washer_nut_type='a563_a_heavy_hex_unc',washer_detail_confirmed=True,upper_washer=UpperWasher('fitted_direct','four_edges',5.,'ASTM A572 Gr.50','smaw_e7018_single_pass',20.55,True),project='Base U dois chumbadores — teste de tração e corte; detalhe fictício de furação conjunta'),
            'U · tração — teste':replace(c,N=-20000.,project='Base U — teste de tração'),
            'U · compressão e atrito — teste':replace(c,N=30000.,V=3000.,project='Base U — teste de atrito')}
