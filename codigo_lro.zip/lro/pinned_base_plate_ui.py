"""Interface da base rotulada Tipo 2; estado e persistência independentes."""
from .display_precision import calculated_text
from .display_precision import display_format, display_frame, display_value, number_input
from dataclasses import fields,replace
import hashlib
import json
import pandas as pd
import streamlit as st
from .load_conventions import render as render_load_convention
from .models import Profile,STEELS,KGF,VERSION,profiles
from .package_identity import PACKAGE_ID as VERSION  # display only; native serializers remain frozen
from .pinned_base_plate import PinnedBasePlate as BasePlate,presets,evaluate
from .base_plate import STOCK,ANCHORS,DETAIL,detail_reference,EXTERNAL_SHAPES
from .base_plate_drawing import image_bytes
from .base_plate_details import DETAIL_DEFAULTS,ANCHOR_TYPES,FIXITIES,WELD_TYPES,MEASURES,fillet_dimensions,weld_description
from .base_plate_detail_drawing import detail_image_bytes
from .report import BRAND,LINK,number,display
from .active_shear_key_ui import (ACTIVE_PATHS,DEVICE_MODELS,seed_active_key,restore_active_key,
                                  active_key_widgets,active_key_from_state,active_key_results)

from .base_block_ui import seed_block_editor,block_geometry_widgets
from .base_input_summary_ui import concrete_summary, projection_widget, mc_excerpt_widget
from .column_base_weld import MODEL_QUALIFIED
from .column_base_weld_ui import (seed_column_weld,restore_column_weld,column_weld_widgets,column_weld_from_state,column_weld_results,column_weld_qualification)
from .base_component_ui import (seed_component_details,restore_component_details,component_detail_widgets,
    components_from_state,component_qualifications,component_results,shared_key_tension_widgets,base_scope_summary)
from .upper_washer_ui import (seed_upper_washer,restore_upper_washer,upper_washer_widgets,
                              upper_washer_from_state,upper_washer_results)
from .single_key_weld_ui import (seed_single_key_weld,restore_single_key_weld,single_key_weld_widgets,
    single_key_weld_from_state,single_key_weld_qualification,single_key_weld_results)

DEVICE_MODELS={key:value for key,value in DEVICE_MODELS.items() if key!='external'}
from .single_key_concrete_ui import (seed_single_key_concrete,restore_single_key_concrete,single_key_concrete_widgets,
    single_key_concrete_from_state,single_key_concrete_qualification,single_key_concrete_results)

from .direct_anchor_shear_ui import (seed_direct_shear,restore_direct_shear,direct_shear_widgets,
    direct_shear_from_state,direct_shear_results,anchor_choices,anchor_label,direct_selected,MODEL_LABELS)

P=profiles();PRESETS=presets()


def _canonical(value,previous,factor):
    """Unedited unit displays retain the exact saved canonical value."""
    return previous if previous is not None and value==previous/factor else value*factor


def seed(c,preserve_active_draft=False):
    st.session_state['_baseplate_ui_prefix']='pp'
    s=st.session_state
    # Uma importação substitui também a declaração técnica, mesmo para dados iguais.
    for key in list(s):
        if key.startswith('pp_anchor_confirm_'):del s[key]
    for f in fields(c):
        if f.name not in ('column','N','M','V','external_shear_rd','anchor_shear_rd','active_key','upper_washer','single_key_weld','single_key_concrete','concrete_components','column_weld','direct_shear'):
            v=getattr(c,f.name);s['pp_'+f.name]=float(v) if type(v) in (float,int) else v
    s['pp_N_kgf']=c.N/KGF;s['pp_V_kgf']=c.V/KGF
    s['pp_external_shear_kgf']=c.external_shear_rd/KGF
    s['pp_anchor_shear_kgf']=c.anchor_shear_rd/KGF
    s['pp_shear_mechanism']='device' if c.shear_path in DEVICE_MODELS else c.shear_path
    s['pp_device_model']=c.shear_path if c.shear_path in DEVICE_MODELS else 'plate'
    s['pp_db_label']=anchor_label(c.db,ANCHORS)
    s['pp_anchor_washer_t_label']=next((k for k,v in STOCK.items() if abs(c.anchor_washer_t-v)<1e-7),'Personalizada')
    s['pp_lug_t_label']=next((k for k,v in STOCK.items() if abs(c.lug_t-v)<1e-7),'Personalizada')
    s['pp_tp_label']=next((k for k,v in STOCK.items() if abs(c.tp-v)<1e-7),'Personalizada')
    p=c.column;s['pp_column_name']=p.name if p.name in P else 'Seção I personalizada'
    s['pp_column_manual_name']=p.name
    for k in ('d','bf','tw','tf','clear'):s['pp_column_'+k]=float(getattr(p,k))
    for part in ('web','flange'):s['_pp_'+part+'_measure_previous']=getattr(c,'weld_'+part+'_measure')
    pending_weld_json=s.get('_pp_active_weld_json') if preserve_active_draft else None
    seed_active_key(c.active_key,c.shear_path)
    seed_upper_washer(c.upper_washer)
    seed_direct_shear(c.direct_shear)
    seed_single_key_weld(c.single_key_weld,c.lug_bh)
    seed_single_key_concrete(c.single_key_concrete,preserve_qualification=preserve_active_draft)
    seed_component_details(c)
    seed_column_weld(c)
    seed_block_editor(c,'pp')
    if pending_weld_json is not None:
        s['pp_ak_weld_json']=pending_weld_json
        s['_pp_active_weld_json']=pending_weld_json
    s['_pinned_base_plate_project']=c.to_dict()
    s.pop('pp_report',None)
    s.pop('pp_mc_excerpt',None)


def load_example():
    seed(PRESETS[st.session_state.pp_example])
    st.session_state.pop('pp_import_error',None)


def load_json():
    try:
        up=st.session_state.pp_upload
        if up is None:raise ValueError('Selecione um arquivo JSON.')
        raw=up.getvalue()
        if len(raw)>200000:raise ValueError('Projeto maior que o limite de 200 kB.')
        c=BasePlate.from_dict(json.loads(raw))
        seed(c);st.session_state.pop('pp_import_error',None)
    except (ValueError,TypeError,KeyError,OverflowError,UnicodeError) as exc:
        st.session_state.pp_import_error='Não foi possível abrir: '+str(exc)


def stock_changed():
    if st.session_state.pp_tp_label in STOCK:
        st.session_state.pp_tp=STOCK[st.session_state.pp_tp_label]


def lug_stock_changed():
    if st.session_state.pp_lug_t_label in STOCK:
        st.session_state.pp_lug_t=STOCK[st.session_state.pp_lug_t_label]


def use_anchor_washers():
    ref=DETAIL[st.session_state.pp_db_label]
    label=next((k for k,v in STOCK.items() if v>=ref['washer_t']),'Personalizada')
    st.session_state.pp_anchor_washer_t_label=label
    st.session_state.pp_anchor_washer_t=STOCK.get(label,float(ref['washer_t']))
    st.session_state.pp_anchor_washer_side=float(ref['washer_side'])


def anchor_washer_stock_changed():
    if st.session_state.pp_anchor_washer_t_label in STOCK:
        st.session_state.pp_anchor_washer_t=STOCK[st.session_state.pp_anchor_washer_t_label]


def use_table_spacing():
    ref=DETAIL[st.session_state.pp_db_label]
    st.session_state.pp_a1=float(ref['a1'])


def use_table_grout():
    ref=DETAIL[st.session_state.pp_db_label]
    st.session_state.pp_grout_t=float(ref['en'])


def weld_measure_changed(part):
    s=st.session_state;key='pp_weld_'+part+'_measure';size='pp_weld_'+part+'_size'
    previous=s.get('_pp_'+part+'_measure_previous','leg')
    if previous!=s[key]:
        dims=fillet_dimensions(s[size],previous)
        s[size]=dims[s[key]]
    s['_pp_'+part+'_measure_previous']=s[key]


def detail_widgets():
    with st.expander('Enrijecedores · especificação'):
        st.caption('Família rotulada Tipo 2: quatro chumbadores internos. A rigidez rotacional requer verificação específica.')
        st.caption('Sem enrijecedores no modelo Tipo 2 suportado.')
        if st.session_state.pp_stiffener_detail=='web_pair':
            for key,label in [('stiffener_length','Projeção além de cada mesa'),('stiffener_height','Altura dos enrijecedores'),('stiffener_t','Espessura dos enrijecedores')]:
                number_input(label+' (mm)',min_value=.1,key='pp_'+key)
            st.warning('Interpretação inicial: uma chapa triangular vertical além de cada mesa, ambas no plano da alma, ligadas à mesa e à placa de base. Na planta do detalhe, a alma fica vertical. Sem ganho de resistência; a base enrijecida ainda exige modelo específico.')
    concrete_summary('pp')
    projection_widget('pp')
    with st.expander('Bloco real e ancoragem enterrada',expanded=False):
        st.selectbox('Tipo da ancoragem no concreto',list(ANCHOR_TYPES),key='pp_anchor_type',format_func=ANCHOR_TYPES.get)
        st.selectbox('Verificação do cone de tração',['off','aci318_19'],key='pp_cone_model',
                     format_func=lambda x:'Não selecionada · permanece a verificar' if x=='off' else 'ACI 318-19 / DG1 · moldado no local, fissurado, φ=0,70')
        if st.session_state.pp_cone_model!='off':
            with st.popover('Avançado · envelope adicional do cone'):
                st.checkbox('Adicionar envelope conservador de subconjuntos tracionados · opcional',key='pp_cone_subset_envelope')
                st.caption('Padrão: grupos tracionados conectados do método ACI. A opção suplementar avalia subconjuntos sem criar ganho de capacidade; não é exigência literal da ACI.')
        if st.session_state.pp_anchor_type!='unspecified' or st.session_state.pp_cone_model!='off':
            number_input('Embutimento efetivo hef até a face superior de apoio enterrada (mm)',min_value=.1,key='pp_hef')
            st.caption('hef começa no topo do concreto, abaixo do graute; não é o comprimento total da barra. A arruela superior soldada à base é outra peça.')
            block_geometry_widgets('pp')
            number_input('Altura real do bloco h (mm)',min_value=.1,key='pp_block_h')
            st.caption('Origem no centro da placa; x paralelo a L/alma, y paralelo a B. São bordas reais livres. Bloco fora do centro é permitido; não use os mínimos tabulados como dimensões existentes.')
            if st.session_state.pp_anchor_type in ('headed','buried_nut','buried_plate_nut'):
                with st.popover('Avançado · geometria do apoio enterrado'):
                    for key,label in [('anchor_head_length','Extensão enterrada na direção x'),('anchor_head_width','Extensão enterrada na direção y'),('anchor_bearing_t','Espessura da cabeça, porca ou chapa de apoio'),('anchor_head_t','Extensão enterrada abaixo da face de apoio'),('anchor_bottom_cover','Cobrimento inferior livre adotado no detalhe')]:
                        number_input(label+' (mm)',min_value=0. if key=='anchor_bottom_cover' else .1,key='pp_'+key)
                    if st.session_state.pp_anchor_type=='buried_plate_nut':
                        number_input('Espessura da porca sob a chapa enterrada (mm)',min_value=.1,key='pp_anchor_nut_t')
                        number_input('Furo da chapa enterrada (mm)',min_value=.1,key='pp_anchor_head_hole')
                    if st.session_state.pp_anchor_type=='buried_nut':
                        number_input('Área líquida de apoio documentada da porca (mm²)',min_value=.1,key='pp_anchor_nut_bearing_area')
            else:
                st.caption('Geometria de cabeça/porca/chapa oculta para este tipo de ancoragem; valores anteriores preservados. O mecanismo resistente da ancoragem continua a verificar.')
            st.text_input('Referência do detalhe de ancoragem',key='pp_anchor_detail_ref')
            st.checkbox('Declaro ancoragem moldada no local, apoio mecânico definido e concreto íntegro, sem bolsões vazios/espuma ou bainha livre na transferência.',key='pp_anchor_detail_confirmed')
            st.caption('Cabeça/porca/chapa deve ser mecanicamente ligada à barra. Geometria documentada não verifica por si rigidez local, arrancamento, ruptura lateral, fendilhamento ou cobrimentos normativos. A extensão abaixo do apoio inclui toda a peça enterrada e porca inferior, quando houver.')
        elif st.session_state.get('pp_shear_path')=='plate' and st.session_state.get('pp_skc_model','off')!='off':
            # The key's real block is independent of selecting an anchor-head model.
            block_geometry_widgets('pp')
            number_input('Altura real do bloco h (mm)',min_value=.1,key='pp_block_h')
            st.caption('Bloco real usado pelo concreto da chave; são os mesmos limites e offsets do projeto. Não é necessário selecionar um tipo de cabeça ou cone para informar o bloco. Todas as bordas informadas são livres.')
        st.caption('Cone calculado somente para cabeça forjada, porca ou chapa com porca moldadas no local. Reto sem cabeça e gancho J são detalhes registrados, sem capacidade nativa. Químicos/pós-instalados exigem outro modelo.')
        st.caption('Base ACI complementar à NBR: concreto normal fissurado, φ=0,70 Condição B, sem armadura suplementar creditada; usa fck numérico como fc informado, sem γc adicional. Não demonstra a ancoragem completa nem interação com cortante.')


def profile_widget():
    name=st.selectbox('Pilar I ou H',['Seção I personalizada']+list(P),key='pp_column_name')
    if name in P:return P[name]
    with st.expander('Dimensões do pilar',expanded=True):
        name=st.text_input('Designação do pilar',key='pp_column_manual_name')
        vals={}
        for k,label in [('d','Altura d'),('bf','Largura bf'),('tw','Alma tw'),('tf','Mesa tf'),('clear','Altura livre sem concordâncias')]:
            vals[k]=number_input(label+' (mm)',min_value=.1,key='pp_column_'+k)
        area=2*vals['bf']*vals['tf']+(vals['d']-2*vals['tf'])*vals['tw']
        return Profile(name,'Soldado',max(area,1)*.00785,area=max(area,1),**vals)


def render():
    st.session_state['_baseplate_ui_prefix']='pp'
    from .base_plate_report import create_report, create_mc_excerpt
    if 'pp_column_name' not in st.session_state:
        saved=st.session_state.get('_pinned_base_plate_project')
        seed(BasePlate.from_dict(saved,validate_values=False) if saved else PRESETS['Chumbadores · arruelas soldadas'],preserve_active_draft=bool(saved))
    # Restaurar campos que podem ter sido destruídos ao ficarem ocultos.
    draft=st.session_state.get('_pinned_base_plate_project',{}).get('connection',{})
    restore_active_key(draft)
    restore_upper_washer(draft)
    restore_direct_shear(draft)
    restore_single_key_weld(draft)
    restore_single_key_concrete(draft)
    restore_component_details(draft)
    restore_column_weld(draft)
    hidden={'pp_shear_mechanism':'device' if draft.get('shear_path') in DEVICE_MODELS else draft.get('shear_path','device'),
            'pp_device_model':draft.get('shear_path') if draft.get('shear_path') in DEVICE_MODELS else 'plate',
            'pp_anchor_shear_kgf':draft.get('anchor_shear_rd',0.)/KGF,
            'pp_anchor_shear_ref':draft.get('anchor_shear_ref',''),
            'pp_anchor_shear_model':draft.get('anchor_shear_model','external'),
            'pp_anchor_washer_t':draft.get('anchor_washer_t',6.35),
            'pp_anchor_washer_side':draft.get('anchor_washer_side',50.),
            'pp_anchor_washer_t_label':next((k for k,v in STOCK.items() if abs(draft.get('anchor_washer_t',6.35)-v)<1e-7),'Personalizada'),
            'pp_external_shear_kgf':draft.get('external_shear_rd',0.)/KGF,
            'pp_external_shear_ref':draft.get('external_shear_ref',''),
            'pp_tp':draft.get('tp',19.05),
            'pp_external_shape':draft.get('external_shape','other'),
            'pp_lug_bh':draft.get('lug_bh',100.),'pp_lug_bv':draft.get('lug_bv',100.),
            'pp_lug_t':draft.get('lug_t',19.05),'pp_lug_steel':draft.get('lug_steel','ASTM A36'),
            'pp_lug_t_label':next((k for k,v in STOCK.items() if abs(draft.get('lug_t',19.05)-v)<1e-7),'Personalizada')}
    hidden.update({'pp_'+key:draft.get(key,value) for key,value in DETAIL_DEFAULTS.items()})
    for part in ('web','flange'):
        st.session_state.setdefault('_pp_'+part+'_measure_previous',draft.get('weld_'+part+'_measure','leg'))
    for key,value in hidden.items():
        st.session_state[key]=st.session_state.get(key,value)
    with st.sidebar:
        st.markdown('### LRO Ligações')
        st.caption('Versão '+VERSION+' · placa de base rotulada / Tipo 2')
        st.selectbox('Exemplos de placa de base',list(PRESETS),key='pp_example')
        st.button('Usar exemplo de placa de base',on_click=load_example,use_container_width=True)
        st.file_uploader('Abrir projeto de placa de base',type=['json'],key='pp_upload')
        st.button('Abrir placa de base JSON',on_click=load_json,use_container_width=True)
        if 'pp_import_error' in st.session_state:st.error(st.session_state.pp_import_error)
        st.caption('Os exemplos são didáticos, com ações identificadas. Não representam um projeto executado.')
        st.divider();st.caption(BRAND);st.link_button('LinkedIn · Lucas Oliveira',LINK)
    st.markdown('<div class="eyebrow">BASE ROTULADA · QUATRO CHUMBADORES INTERNOS</div>',unsafe_allow_html=True)
    st.title('Placa de base · rotulada')
    st.caption('NBR 8800:2024 corrigida em 2025 · perfil I/H · chapa sem enrijecedores · flexão no eixo de maior inércia')
    st.text_input('Identificação da base',key='pp_project')
    left,right=st.columns([.9,1.55],gap='large')
    with left:
        column=profile_widget()
        st.subheader('Ações de cálculo')
        N=number_input('Axial N (kgf)',key='pp_N_kgf',format='%.2f')*KGF
        V=number_input('Cortante V (kgf)',key='pp_V_kgf',format='%.2f')*KGF
        load_convention_slot = st.empty()
        st.caption('Apenas N e V já majorados, na face superior da placa. N positivo = compressão; N negativo = tração. V está no plano da alma. Não há momento aplicado; excentricidade local da chave, quando existente, é calculada uma única vez.')
        st.subheader('Placa e chumbadores')
        choices=anchor_choices(ANCHORS)
        label=st.selectbox('Diâmetro real do chumbador' if direct_selected() else 'Chumbador ASTM A36 Ø (pol.)',list(choices),key='pp_db_label')
        db=choices[label];st.caption(number(db,3)+' mm · 4 barras rosqueadas; material identificado na rota selecionada')
        a,b=st.columns(2)
        with a:number_input('Projeção e borda a₁ (mm)',min_value=.1,key='pp_a1',format='%.2f')
        with b:number_input('Malha quadrada de chumbadores a₂ (mm)',min_value=.1,key='pp_a2',format='%.2f')
        st.button('Adotar a₁ da Tabela 18',on_click=use_table_spacing,use_container_width=True,disabled=direct_selected() or st.session_state.pp_db_label not in DETAIL)
        st.caption('Este botão altera somente a₁; preserva a malha interna a₂, o graute real, as peças enterradas e o bloco.')
        st.caption('Tipo 2: chumbadores em (±a₂/2, ±a₂/2), dentro das mesas e ao lado da alma. L=d+4a₁; B=a₂+2a₁. O encaixe real de furo, arruela e soldas é verificado separadamente.')
        tp_label=st.selectbox('Espessura da placa (pol.)',list(STOCK)+['Personalizada'],key='pp_tp_label',on_change=stock_changed)
        if tp_label=='Personalizada':
            tp=number_input('Espessura da placa tₚ (mm)',min_value=.1,key='pp_tp',format='%.2f')
        else:
            tp=STOCK[tp_label];st.caption(number(tp,4)+' mm')
        st.selectbox('Aço da placa',[k for k,v in STEELS.items() if v.plate_allowed],key='pp_plate_steel')
        with st.expander('Concreto e assentamento',expanded=False):
            number_input('Concreto fck (MPa)',min_value=20.,max_value=50.,key='pp_fck')
            number_input('Argamassa expansiva fck (MPa)',min_value=1.,key='pp_grout_fck')
            number_input('Espessura de graute e (mm)',min_value=.1,key='pp_grout_t')
            st.button('Adotar graute de referência da Tabela 18',on_click=use_table_grout,disabled=direct_selected() or st.session_state.pp_db_label not in DETAIL)
            st.caption('Adoção explícita: altera somente a espessura do graute. Esse valor muda a excentricidade da chave e precisa representar o assentamento real.')
            st.caption('Graute ≥ 2fck. Concreto de densidade normal; resistência aos 28 dias. A2/A1=1, sem aumento presumido por confinamento. γa1=1,10; γa2=1,35; γc=1,40.')
        with st.expander('Caminho resistente do cortante',expanded=True):
            mechanism=st.selectbox('Transferência de V',['anchors','device','friction'],key='pp_shear_mechanism',format_func=lambda x:{'anchors':'Chumbadores · arruelas soldadas','device':'Barra ou chave de cisalhamento','friction':'Atrito placa/graute expansivo'}[x])
            if mechanism=='device':
                path=st.selectbox('Modelo da barra ou chave',list(DEVICE_MODELS),key='pp_device_model',format_func=DEVICE_MODELS.get)
            else:path=mechanism
            st.session_state.pp_shear_path=path
            if path=='anchors':
                models={k:v for k,v in MODEL_LABELS.items() if k!='external'}
                imported=st.session_state.get('pp_anchor_shear_model','welded_washer')
                if imported not in models:models[imported]='Dado importado: '+imported
                model=st.selectbox('Modelo dos chumbadores',list(models),key='pp_anchor_shear_model',format_func=models.get)
                if model=='welded_washer':
                    wt=st.selectbox('Espessura das arruelas ta (pol.)',list(STOCK)+['Personalizada'],
                        key='pp_anchor_washer_t_label',on_change=anchor_washer_stock_changed)
                    if wt=='Personalizada':
                        number_input('Espessura das arruelas ta (mm)',min_value=.1,key='pp_anchor_washer_t',format='%.2f')
                    else:st.caption(number(STOCK[wt],4)+' mm')
                    number_input('Lado das arruelas especiais (mm)',min_value=.1,key='pp_anchor_washer_side',format='%.2f')
                    st.button('Usar arruelas da Tabela 18 e espessura comercial',on_click=use_anchor_washers,use_container_width=True,disabled=direct_selected() or st.session_state.pp_db_label not in DETAIL)
                    st.caption(f'Detalhe adotado: 4 arruelas quadradas idênticas, aço fy=345 MPa, soldadas à face superior; furo-padrão Ø{display_value(number(db + 1.5, 3))} mm. As quatro barras devem estar efetivamente mobilizadas. Rosca no plano de corte. O simples furo alargado da placa não demonstra esse engajamento.')
                    st.caption('O índice publicado na parcela subtrativa é ambíguo (1/i); o app adota a maior tração simultânea nessa parcela como limite conservador explícito. O app calcula a resistência de cada barra com sua tração simultânea, limita também pela interação geral de 6.3.3.4 e soma as quatro conforme NBR 6.7.2.5. Não presume V/4; não soma atrito ou chave.')
                    st.caption('N/V e efeitos locais na face superior da placa; M aplicado é zero. O braço local tp+ta/2 entra em α. Não há transporte global automático V·tp/V·graute; outro ponto de aplicação ou detalhe exige modelo específico ou memória externa.')
                    upper_washer_widgets()
                elif model=='direct_plate_bearing':
                    direct_shear_widgets()
                    st.caption('Bitolas métricas e UNC ficam disponíveis no seletor de diâmetro ao ativar esta rota; o diâmetro anterior é preservado.')
                else:
                    number_input('VRd do grupo instalado para a combinação atual (kgf)',min_value=0.,key='pp_anchor_shear_kgf')
                    st.text_input('Referência da memória de cortante dos chumbadores',key='pp_anchor_shear_ref')
                    st.warning('Esta rota só compara a resistência documentada do conjunto. Resistência ao corte, interação tração–cisalhamento, efeitos locais e transferência ao concreto não são calculados no app. A memória deve cobrir o grupo efetivamente mobilizado, furos/arruelas/soldas, tração–corte–flexão do aço, ruptura/pryout/bordas/grupo no concreto, os esforços combinados e a excentricidade da reação. Não se admite 4 × resistência isolada sem verificação do grupo. Esta rota preserva momento local calculado, sem transporte automático V·e; a memória externa deve fornecer as ações resultantes adequadas para a base. Não se soma atrito nem chave.')
            elif path in ACTIVE_PATHS:
                active_key_widgets(path,st.session_state.pp_grout_t)
            elif path=='external':
                st.selectbox('Geometria do dispositivo externo',list(EXTERNAL_SHAPES),key='pp_external_shape',format_func=EXTERNAL_SHAPES.get)
                number_input('Resistência de cálculo do dispositivo (kgf)',min_value=0.,key='pp_external_shear_kgf')
                st.text_input('Referência da memória do dispositivo',key='pp_external_shear_ref')
                st.caption('Informe a resistência do caminho completo, incluindo dispositivo, soldas e transferência ao bloco. O app só compara; não calcula esse dispositivo. Para cruciforme e perfil W, a orientação e todas as dimensões constam da memória externa. Ela deve incluir a excentricidade da reação e os esforços correspondentes na base. Esta rota preserva momento local calculado, sem transformação automática. Não se soma atrito.')
            elif path=='plate':
                number_input('Largura da chave bh (mm)',min_value=.1,key='pp_lug_bh',format='%.2f')
                number_input('Projeção abaixo da placa bv (mm)',min_value=.1,key='pp_lug_bv',format='%.2f')
                lug_label=st.selectbox('Espessura da chave (pol.)',list(STOCK)+['Personalizada'],key='pp_lug_t_label',on_change=lug_stock_changed)
                if lug_label=='Personalizada':
                    number_input('Espessura da chave tpv (mm)',min_value=.1,key='pp_lug_t',format='%.2f')
                else:st.caption(number(STOCK[lug_label],4)+' mm')
                st.selectbox('Aço da chave',[k for k,v in STEELS.items() if v.plate_allowed],key='pp_lug_steel')
                st.caption('Uma chapa vertical maciça, centrada sob a base: bh paralelo a B; V perpendicular à face. bv inclui o graute real en e deve ser maior que en. Sem soma de atrito.')
                single_key_weld_widgets()
                single_key_concrete_widgets()
                st.warning('V na face superior da placa. O app calcula somente Mlocal=V·[tp+(bv+en)/2], uma única vez; não há M aplicado. C3/T3 e momento puro estão fora do domínio Tipo 2 e bloqueiam a solução.')
            else:
                st.caption('μ=0,45 conforme NBR, com limitação pelo graute/concreto. Sem compressão de contato, o atrito é nulo; não se atribui cortante automaticamente às barras.')
        detail_widgets()
        component_panel=st.container()
        weld_panel=column_weld_widgets(weld_measure_changed)
        with st.expander('Observações da base'):st.text_area('Observações',key='pp_notes')
    s=st.session_state
    details={key:s.get('pp_'+key,value) for key,value in DETAIL_DEFAULTS.items() if key!='base_fixity'}
    active_key,active_input_errors=active_key_from_state(s.pp_shear_path)
    N=_canonical(s.pp_N_kgf,draft.get('N'),KGF)
    V=_canonical(s.pp_V_kgf,draft.get('V'),KGF)
    c=BasePlate(column,**details,project=s.pp_project,plate_steel=s.pp_plate_steel,tp=tp,db=db,a1=s.pp_a1,a2=s.pp_a2,
        fck=s.pp_fck,grout_fck=s.pp_grout_fck,grout_t=s.pp_grout_t,N=N,V=V,shear_path=s.pp_shear_path,
        external_shear_rd=_canonical(s.get('pp_external_shear_kgf',0.),draft.get('external_shear_rd'),KGF),
        external_shear_ref=s.get('pp_external_shear_ref',''),notes=s.pp_notes,
        external_shape=s.get('pp_external_shape','other'),lug_bh=s.get('pp_lug_bh',100.),
        lug_bv=s.get('pp_lug_bv',100.),lug_t=STOCK.get(s.get('pp_lug_t_label'),s.get('pp_lug_t',19.05)),
        lug_steel=s.get('pp_lug_steel','ASTM A36'),active_key=active_key,upper_washer=upper_washer_from_state(),single_key_weld=single_key_weld_from_state(),single_key_concrete=single_key_concrete_from_state(),concrete_components=components_from_state(),column_weld=column_weld_from_state(),direct_shear=direct_shear_from_state(),
        anchor_shear_model=s.get('pp_anchor_shear_model','external'),
        anchor_washer_t=(s.get('pp_anchor_washer_t',6.35) if direct_selected() else STOCK.get(s.get('pp_anchor_washer_t_label'),s.get('pp_anchor_washer_t',6.35))),
        anchor_washer_side=s.get('pp_anchor_washer_side',50.),
        anchor_shear_rd=_canonical(s.get('pp_anchor_shear_kgf',0.),draft.get('anchor_shear_rd'),KGF),
        anchor_shear_ref=s.get('pp_anchor_shear_ref',''),
        anchor_shear_confirmation=s.get('pp_anchor_shear_confirmation',draft.get('anchor_shear_confirmation','')))
    with left:
        with component_panel:
            component_detail_widgets(c)
            c=replace(c,concrete_components=components_from_state())
            c=shared_key_tension_widgets(c)
            c=component_qualifications(c)
        with weld_panel:
            c=column_weld_qualification(c,embedded=True)
        c=single_key_weld_qualification(c)
        c=single_key_concrete_qualification(c)
    if c.shear_path=='anchors' and not c.native_anchor_shear and not c.direct_anchor_shear:
        with left:
            confirmed=st.checkbox('Confirmo que a memória documentada verifica este grupo instalado para a combinação atual N–M–V, seu detalhamento e a excentricidade da reação.',
                value=c.anchor_capacity_confirmed,key='pp_anchor_confirm_'+c.anchor_shear_signature[:20])
            st.caption('Declaração técnica de aplicabilidade da memória externa, sem certificar a base pelo app. A confirmação perde efeito se mudar ação, geometria, material, capacidade ou referência.')
        c=replace(c,anchor_shear_confirmation=c.anchor_shear_signature if confirmed else '')
        s.pp_anchor_shear_confirmation=c.anchor_shear_confirmation
    # Chaves não-widget sobrevivem à troca de família e a widgets ocultos.
    # Os campos externos ocultos também são reconstituídos do rascunho salvo.
    previous=s.get('_pinned_base_plate_project',{}).get('connection',{})
    if c.shear_path=='friction':
        c=replace(c,external_shear_rd=_canonical(s.get('pp_external_shear_kgf',previous.get('external_shear_rd',0.)/KGF),previous.get('external_shear_rd'),KGF),
                  external_shear_ref=s.get('pp_external_shear_ref',previous.get('external_shear_ref','')))
    s['_pinned_base_plate_project']=c.to_dict()
    try:
        encoded=json.dumps(c.to_dict(),ensure_ascii=False,indent=2,allow_nan=False)
    except (ValueError,TypeError,OverflowError):
        encoded=''
        active_input_errors.append('Projeto não exportável: corrija valores numéricos não finitos ou dados incompatíveis.')
    digest=hashlib.sha256(encoded.encode()).hexdigest()
    if s.get('pp_report',('',False,b''))[0]!=digest:s.pop('pp_report',None)
    with load_convention_slot.container():
        render_load_convention(st, 'base_plate_pinned', c.N)
    r=evaluate(c);a=r.geometry
    can_draw=not any(i.severity=='error' for i in r.issues)
    if c.shear_path in ACTIVE_PATHS:
        can_draw=can_draw and bool(a.get('active_key'))
    can_export=not active_input_errors
    detail_png=detail_svg=None
    detail_error=''
    if can_draw and any((c.cone_model!='off',c.anchor_type!='unspecified',c.base_fixity!='unspecified',c.stiffener_detail!='none',c.weld_web_type!='unspecified',c.weld_flange_type!='unspecified')):
        try:
            detail_png=detail_image_bytes(c,r)
            detail_svg=detail_image_bytes(c,r,'svg')
        except ValueError as exc:
            detail_png=detail_svg=None
            detail_error=str(exc)
    with right:
        st.subheader('Resultados desta base')
        for error in active_input_errors:st.error(error)
        writer={'pass':st.success,'pending':st.warning,'fail':st.error,'invalid':st.error,'neutral':st.caption}[r.component_outcome]
        writer(r.component_status)
        st.caption('Conclusão das verificações calculadas no método selecionado. Dados faltantes, caminhos locais ainda não calculados e responsabilidades externas são discriminados abaixo.')
        base_scope_summary(c,r)
        x,y,z=st.columns(3)
        x.metric('Placa L × B',f'{display_value(number(c.L, 1))} × {display_value(number(c.B, 1))} mm')
        y.metric('Regime N–Mlocal',a.get('case','Sem solução'))
        z.metric('tₚ requerido',number(a['t_required'],2)+' mm' if a else '—')
        if can_draw:
            st.image(image_bytes(c,r),width='stretch')
            if detail_png is not None:
                st.image(detail_png,width='stretch')
            elif detail_error:
                st.warning('Detalhe da ancoragem e soldas indisponível: '+detail_error)
        for i in r.issues:
            if i.severity=='pending' and i.origin not in ('data','anchorage_data'):continue
            if i.severity in ('error','model','noncompliance'):st.error(calculated_text(i.text, assignments_only=True))
            elif i.severity in ('pending','interference','warning'):st.warning(calculated_text(i.text, assignments_only=True))
            else:st.caption(calculated_text(i.text, assignments_only=True))
        direct_shear_results(c,r)
        if not c.direct_anchor_shear:upper_washer_results(c,r)
        single_key_weld_results(c,r)
        single_key_concrete_results(c,r)
        component_results(c,r)
        column_weld_results(c,r)
        if a:
            cone=a.get('concrete_cone',{})
            if cone.get('status')=='calculated':
                with st.expander('Cone de tração · ACI complementar',expanded=True):
                    g=cone['governing']
                    st.write(f"Grupo governante: {display_value(', '.join(g['ids']))}; tração={display_value(number(g['demand'] / KGF, 3))} kgf; φNcb={display_value(number(g['resistance'] / KGF, 3))} kgf; índice={display_value(number(g['ratio'], 3))}.")
                    st.write(f"hef físico={display_value(number(g['hef'], 3))} mm; hcalc={display_value(number(g['hcalc'], 3))} mm; ANc={display_value(number(g['area'], 1))} mm²; ψec={display_value(number(g['psi_ec'], 4))}; ψed={display_value(number(g['psi_ed'], 4))}.")
                    st.caption(('Envelope suplementar opcional ativado. ' if c.cone_subset_envelope else 'Método ACI: grupos tracionados conectados. ')+'Área por união de projeções recortada nas bordas reais. Barras sem tração não ampliam a área. Cones desconectados são verificados separadamente. Não é somatório de capacidades de grupos independentes.')
                    st.caption('O ajuste de bloco estreito altera apenas hcalc no cálculo; não altera o hef físico desenhado. Usada expressão básica Nb=24√fc,psi hcalc,in^1,5, sem ganho opcional para grandes embutimentos.')
                    st.caption('Este resultado é somente o cone de tração. Os demais modos aplicáveis são discriminados na ancoragem; não há cortante/pryout exigido em barras sem cortante.')
            if c.native_anchor_shear and 'anchor_shear' in a:
                ash=a['anchor_shear']
                with st.expander('Cortante com tração simultânea por chumbador',expanded=True):
                    st.write(f"α={display_value(number(ash['alpha'], 6))}; Fv,Rd não reduzido={display_value(number(ash['shear_unreduced_rd'] / KGF, 3))} kgf/barra; limite local 5db²σc,Rd={display_value(number(ash['concrete_cap'] / KGF, 3))} kgf/barra.")
                    st.dataframe(display_frame(pd.DataFrame([{'Barra':rod['id'],'x (mm)':rod['x'],'y (mm)':rod['y'],
                        'Ft,Sd (kgf)':rod['tension']/KGF,'VRd,i conservador (kgf)':rod['steel_rd']/KGF,
                        'Limite interação (kgf)':rod['combined_rd']/KGF,
                        'VRd,i limitado (kgf)':rod['rd']/KGF,'Domínio':'Válido' if rod['domain_ok'] else 'Não admissível'}
                        for rod in ash['rods']])),hide_index=True,width='stretch')
                    st.write(f"VRd do grupo para esta combinação=ΣVRd,i={display_value(number(ash['group_rd'] / KGF, 3))} kgf. Cortante aplicado |V|={display_value(number(abs(c.V) / KGF, 3))} kgf.")
                    st.caption('Valores por barra são resistências condicionadas à tração, sem atribuir V/4 às barras. Se qualquer expressão sair do domínio, não se concede capacidade ao grupo.')
                    st.write(f"Ação para dimensionar a solda de CADA arruela: Fv,Rd={display_value(number(ash['weld_force_per_washer'] / KGF, 3))} kgf, sem reduzir por tração.")
                    if c.upper_washer.model=='off':
                        st.caption('Resistência da solda e transferência pela arruela/placa não calculadas. O limite local do concreto não demonstra cone, arrancamento, pryout, bordas, grupo ou interação da ancoragem.')
                    else:
                        st.caption('As verificações locais selecionadas da arruela superior são apresentadas separadamente; transferência completa arruela–placa permanece pendente. O limite local do concreto não demonstra cone, arrancamento, pryout, bordas, grupo ou interação da ancoragem.')
            if c.shear_path in ACTIVE_PATHS:
                active_key_results(c,r)
            if c.shear_path=='plate':
                st.write(f"M aplicado fixo={display_value(number(c.M / (KGF * 1000), 3))} kgf·m; eV={display_value(number(a['eV'], 3))} mm; ΔM={display_value(number(a['delta_M'] / (KGF * 1000), 3))} kgf·m; Mef={display_value(number(a['M_effective'] / (KGF * 1000), 3))} kgf·m.")
                lug=a['lug']
                with st.expander('Ações prescritas para dimensionar as soldas da chave',expanded=True):
                    st.write(('Magnitudes prescritas (sinais no componente acima): ' if c.single_key_weld.model!='off' else '') + f"Vw=Vbearing,Rd={display_value(number(lug['weld_V'] / KGF, 3))} kgf; Mw=Vbearing,Rd·(bv+en)/2={display_value(number(lug['weld_M'] / (KGF * 1000), 3))} kgf·m.")
                    st.caption('NBR 6.7.2.4: usar a resistência de contato do concreto, mesmo se maior que |V| ou que a resistência do aço da chave. ' + ('Componente dos dois filetes apresentado separadamente; metal-base e transferência local à placa permanecem pendentes.' if c.single_key_weld.model!='off' else 'Resistência/detalhamento das soldas e transferência ao metal-base não calculados nesta rota.'))
            x,y=st.columns(2)
            x.metric('Tração máxima por barra',number(a['Ft_max']/KGF)+' kgf')
            y.metric('Compressão de contato C',number(a['C']/KGF)+' kgf')
            with st.expander('Equilíbrio e distribuição das reações'):
                st.write(f"Bloco equivalente de compressão: lc={display_value(number(a['lc'], 3))} mm; σSd={display_value(number(a['sigma'], 4))} MPa; σRd={display_value(number(c.sigma_rd, 4))} MPa.")
                st.write(f"Cada linha contém dois chumbadores. Tração individual: linha mais solicitada={display_value(number(a['Ft_max'] / KGF))} kgf; outra linha={display_value(number(a['Ft_min'] / KGF))} kgf.")
                st.write(f"Tração total={display_value(number(a['T_total'] / KGF))} kgf. Espessura por contato={display_value(number(a['t_contact'], 3))} mm; por tração={display_value(number(a['t_tension'], 3))} mm.")
                st.caption(f"Checagem estática: C−ΣT=N; resíduos N={display_format(a['residual_N'], '.3e')} N e M={display_format(a['residual_M'], '.3e')} N·mm. Não é cálculo de deslocamento, abertura ou rigidez rotacional.")
    if r.checks:
        st.subheader('Verificações realizadas')
        rows=[]
        for row in r.checks:
            sd,unit=display(row.demand,row.unit);rd,_=display(row.resistance,row.unit)
            rows.append({'Componente / verificação':row.name,'Solicitação':sd,'Resistência / limite':rd,
                         'Unidade':unit,'Índice':row.ratio,'Resultado':'Atende' if row.passed else 'Não atende'})
        st.dataframe(display_frame(pd.DataFrame(rows)),hide_index=True,width='stretch')
        with st.expander('Equações, substituições e referências'):
            for row in r.checks:
                st.markdown('**'+row.name+'**');st.code(row.equation,language=None)
                st.caption(calculated_text(row.substitution)+' | '+calculated_text(row.variables, assignments_only=True));st.caption(row.reference)
    if can_draw and not c.direct_anchor_shear:
        ref=detail_reference(c)
        with st.expander('Detalhamento de referência da Tabela 18 corrigida'):
            st.write('Referência construtiva para '+ref['label']+'. Não é verificação da ancoragem ou do bloco do projeto.')
            st.write(f"Furo da placa: {display_value(number(ref['df']))} mm. Arruela especial: {display_value(number(ref['washer_side']))} × {display_value(number(ref['washer_side']))} × {display_value(number(ref['washer_t']))} mm, aço fy=345 MPa; furo {display_value(number(ref['washer_hole'], 3))} mm.")
            st.write(f"Ancoragem tabulada: h1={display_value(ref['h1'])} mm; h2={display_value(ref['h2'])} mm; r1={display_value(ref['r1'])} mm; r2={display_value(ref['r2'])} mm. Conferir posições na Tabela 18.")
            st.write(f"Bloco de referência Nb×Bb×Ab: {display_value(number(ref['Nb']))} × {display_value(number(ref['Bb']))} × {display_value(number(ref['Ab']))} mm. Armadura mínima tabulada: Ø{display_value(number(ref['rebar_diameter']))} a cada {display_value(number(ref['S']))} mm; da≤{display_value(number(ref['da_max']))} mm.")
            st.caption('Tipo 2: mbloco=a3,tab−a1,tab; Nb=max(Nb,min; L+2en; L+2mbloco); Bb=max(B+2en; B+2mbloco); Ab=max(h1+100; Nb). Valores corrigidos em 2025. A armadura deve ser dimensionada conforme NBR 6118; os mínimos tabulados não aprovam o bloco.')
    if c.direct_anchor_shear:
        st.caption('Contato direto: bitola e furo efetivos não são valores tabulados da Tabela 18. Conferir fabricação, arruela axial, ancoragem e bloco reais.')
    st.subheader('Salvar projeto e memória')
    x,y,z=st.columns(3)
    x.download_button('Baixar placa de base JSON',encoded,'Placa_de_base_rotulada_LRO.json','application/json',use_container_width=True,disabled=not can_export)
    if can_draw:y.download_button('Baixar desenho da base SVG',image_bytes(c,r,'svg'),'Placa_de_base_rotulada_LRO.svg','image/svg+xml',use_container_width=True,disabled=not can_export)
    if detail_svg is not None:
        st.download_button('Baixar detalhe da ancoragem e soldas SVG',detail_svg,'Detalhe_ancoragem_LRO.svg','image/svg+xml')
    mc_excerpt_widget(c,r,'pp',digest,can_export and can_draw,create_mc_excerpt)
    detailed=st.checkbox('Memória detalhada da placa de base',key='pp_detailed')
    if z.button('Gerar memória da placa de base',disabled=not bool(a) or not can_export,use_container_width=True):
        try:
            report_bytes=create_report(c,r,detailed)
        except ValueError as exc:
            s.pop('pp_report',None)
            st.warning('Memória da placa de base indisponível: '+str(exc))
        else:
            s.pp_report=(digest,detailed,report_bytes)
    saved=s.get('pp_report')
    if saved and saved[0]==digest and saved[1]==detailed and can_export:
        st.download_button('Baixar memória da placa de base .docx',saved[2],'Memoria_placa_de_base_rotulada_LRO.docx','application/vnd.openxmlformats-officedocument.wordprocessingml.document')
    st.divider();st.subheader('Alcance deste modelo')
    st.write('Geometria normativa Tipo 2, sem enrijecedores, com quatro chumbadores internos. C1/C2 e T1/T2 são selecionados pelos esforços; C3/T3 e momento puro não são admitidos. Chapa em tração usa a faixa efetiva l₀=min[d; a₂+1,75(a₂−tw)]. Não há campo de momento aplicado. Outro arranjo exige modelo próprio.')
    with st.expander('Premissas adotadas e verificações complementares'):
        for text in c.assumptions:st.write(text)
    st.caption(BRAND)
