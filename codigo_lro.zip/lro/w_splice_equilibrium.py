"""Research-only signed N/M/V statics. No resistance or approval interface.

Coordinate/sign contract is w_splice_scope/spec.md. This is deliberately not
selected by the public axial-tension evaluation when M or V is nonzero.
"""
from __future__ import annotations
import math


def equilibrium(*,d,tf,tw,area,I,N,M,V,left_x,right_x,web_x,web_y):
    values=(d,tf,tw,area,I,N,M,V,left_x,right_x,*web_x,*web_y)
    if not all(type(v) in (float,int) and math.isfinite(v) for v in values):raise ValueError('Finite numeric inputs required.')
    h=d-2*tf;h0=d-tf;aw=tw*h;iw=tw*h**3/12
    if not (h>0 and h0>0 and 0<aw<area and 0<iw<I and left_x<0<right_x):raise ValueError('Invalid partition/centers.')
    if (len(web_x)<2 or len(web_y)<2 or len(set(web_x))!=len(web_x) or len(set(web_y))!=len(web_y)):
        raise ValueError('Two distinct, nonoverlapping bolt axes are required; each axis needs at least two unique coordinates.')
    grid=[(x,y) for x in web_x for y in web_y];n=len(grid)
    if abs(sum(x for x,y in grid))>1e-9 or abs(sum(y for x,y in grid))>1e-9:raise ValueError('Local grid must be centered.')
    J=sum(x*x+y*y for x,y in grid)
    if not math.isfinite(J) or J<=0:raise ValueError('Bolt-group polar sum J must be positive and finite.')
    nw=aw/area*N;mw=iw/I*M;f0=(N-nw)/2;fm=(M-mw)/h0
    groups=[]
    for side,center,Fx,Fy,C in [('left',left_x,-nw,-V,-mw+left_x*V),('right',right_x,nw,V,mw-right_x*V)]:
        bolts=[dict(x=x,y=y,qx=Fx/n-C*y/J,qy=Fy/n+C*x/J) for x,y in grid]
        for bolt in bolts:bolt['resultant']=math.hypot(bolt['qx'],bolt['qy'])
        groups.append(dict(side=side,center_x=center,Fx=Fx,Fy=Fy,C=C,J=J,bolts=bolts,
                           residual_Fx=sum(b['qx'] for b in bolts)-Fx,residual_Fy=sum(b['qy'] for b in bolts)-Fy,
                           residual_C=sum(b['x']*b['qy']-b['y']*b['qx'] for b in bolts)-C))
    return dict(status='RESEARCH_STATICS_ONLY_NO_RESISTANCE_APPROVAL',Nw=nw,Mw0=mw,Vw=V,Ftop=f0-fm,Fbottom=f0+fm,
                Ftop_full_M_envelope=f0-M/h0,Fbottom_full_M_envelope=f0+M/h0,
                member_residual_N=(f0-fm)+(f0+fm)+nw-N,member_residual_M=2*fm*h0/2+mw-M,
                cover_residual_Fx=sum(g['Fx'] for g in groups),cover_residual_Fy=sum(g['Fy'] for g in groups),
                cover_residual_M=sum(g['C']+g['center_x']*g['Fy'] for g in groups),groups=groups)
