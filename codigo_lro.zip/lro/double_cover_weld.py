"""Exact weighted elastic weld-line integrals for the internal double-cover rib.

Units: N, mm, MPa. The welded parts/supports are idealized as rigid in plane;
all fillets have the same isotropic elastic stiffness per unit throat area.
This load-allocation model does not establish the stiffness, membrane strength
or stability of the perforated rib, nor the capacity of its receivers.
"""
import math

from .models import finite_real


def elastic_throat_group(segments, force_x, force_y, load_x, load_y, applied_moment=0.):
    """Return affine throat stresses and exact force/moment integrals.

    A segment is a mapping with id, start_mm/end_mm (two coordinates),
    leg_mm and fillet_count. Coincident fillets in elevation have combined
    line weight count*leg/sqrt(2). Stress is per throat, whereas q and all
    integrated edge actions include every fillet on that edge.

    Coordinates are right handed: positive moment is counterclockwise.
    applied_moment is a FREE couple at the load point, not an already
    translated origin moment. The returned edge actions are transmitted
    forces in the same sense as the applied load, not opposing reactions.
    """
    if not all(finite_real(v) for v in (force_x,force_y,load_x,load_y,applied_moment)):
        raise ValueError('Ações/coordenadas finitas obrigatórias para o grupo de solda.')
    lines=[];ids=set()
    for s in segments:
        ident=s['id'];start=list(s['start_mm']);end=list(s['end_mm'])
        leg=s['leg_mm'];count=s.get('fillet_count',2)
        if (not isinstance(ident,str) or not ident or ident in ids
            or len(start)!=2 or len(end)!=2
            or not all(finite_real(v) for v in (*start,*end,leg))
            or leg<=0 or type(count) is not int or count<1):
            raise ValueError('Segmentos de solda inválidos.')
        ids.add(ident)
        dx,dy=end[0]-start[0],end[1]-start[1]
        length=math.hypot(dx,dy);throat=leg/math.sqrt(2)
        weight=count*throat;area=weight*length
        if not all(math.isfinite(v) and v>0 for v in (length,throat,weight,area)):
            raise ValueError('Comprimento/área de garganta não positivo ou não finito.')
        lines.append(dict(id=ident,start_mm=start,end_mm=end,length_mm=length,
            leg_mm=leg,throat_mm=throat,fillet_count=count,line_weight_mm=weight,
            area_mm2=area,midpoint_mm=[start[0]+dx/2,start[1]+dy/2],
            tangent_unit=[dx/length,dy/length]))
    if not lines:raise ValueError('Grupo de solda vazio.')
    area=math.fsum(s['area_mm2'] for s in lines)
    if not math.isfinite(area) or area<=0:raise ArithmeticError('Área de garganta não finita/positiva.')
    xc=math.fsum(s['area_mm2']*s['midpoint_mm'][0] for s in lines)/area
    yc=math.fsum(s['area_mm2']*s['midpoint_mm'][1] for s in lines)/area
    for s in lines:
        xm,ym=s['midpoint_mm'];length=s['length_mm']
        s['J_about_centroid_mm4']=s['area_mm2']*((xm-xc)**2+(ym-yc)**2+length**2/12)
    J=math.fsum(s['J_about_centroid_mm4'] for s in lines)
    if not math.isfinite(J) or J<=0:raise ArithmeticError('Inércia polar não positiva/finita.')
    moment=applied_moment+(load_x-xc)*force_y-(load_y-yc)*force_x
    moment_origin=applied_moment+load_x*force_y-load_y*force_x
    if not all(math.isfinite(v) for v in (xc,yc,moment,moment_origin)):
        raise ArithmeticError('Centroide/momento do grupo não finito.')
    points=[]
    for s in lines:
        weight=s['line_weight_mm'];tx,ty=s['tangent_unit'];endpoints=[]
        for label,(x,y) in zip(('start','end'),(s['start_mm'],s['end_mm'])):
            sx=force_x/area-moment*(y-yc)/J
            sy=force_y/area+moment*(x-xc)/J
            qx,qy=weight*sx,weight*sy
            p=dict(segment=s['id'],endpoint=label,x_mm=x,y_mm=y,
                sx_MPa=sx,sy_MPa=sy,resultant_MPa=math.hypot(sx,sy),
                qx_N_per_mm=qx,qy_N_per_mm=qy,
                qparallel_N_per_mm=qx*tx+qy*ty,
                qnormal_left_N_per_mm=-qx*ty+qy*tx)
            if not all(math.isfinite(v) for k,v in p.items() if k not in ('segment','endpoint')):
                raise ArithmeticError('Tensão/fluxo de solda não finito.')
            endpoints.append(p);points.append(p)
        xm,ym=s['midpoint_mm'];a=s['area_mm2'];length=s['length_mm']
        fx=a*(force_x/area-moment*(ym-yc)/J)
        fy=a*(force_y/area+moment*(xm-xc)/J)
        # The affine traction has a nonzero local couple about the edge's
        # midpoint. Replacing the edge by its resultant alone loses it.
        couple=moment/J*a*length**2/12
        mg=(xm-xc)*fy-(ym-yc)*fx+couple
        mo=xm*fy-ym*fx+couple
        if not all(math.isfinite(v) for v in (fx,fy,couple,mg,mo)):
            raise ArithmeticError('Integral de forças/momentos não finita.')
        critical=max(endpoints,key=lambda p:p['resultant_MPa'])
        s.update(endpoint_stresses=endpoints,critical_point=critical,
            max_stress_MPa=critical['resultant_MPa'],integrated_Fx_N=fx,
            integrated_Fy_N=fy,local_couple_Nmm=couple,
            integrated_M_about_centroid_Nmm=mg,integrated_M_about_origin_Nmm=mo)
    fx=math.fsum(s['integrated_Fx_N'] for s in lines)
    fy=math.fsum(s['integrated_Fy_N'] for s in lines)
    mg=math.fsum(s['integrated_M_about_centroid_Nmm'] for s in lines)
    mo=math.fsum(s['integrated_M_about_origin_Nmm'] for s in lines)
    critical=max(points,key=lambda p:p['resultant_MPa'])
    return dict(area_mm2=area,centroid_x_mm=xc,centroid_y_mm=yc,J_mm4=J,
        force_x_N=force_x,force_y_N=force_y,load_point_mm=[load_x,load_y],
        applied_free_moment_Nmm=applied_moment,moment_about_centroid_Nmm=moment,
        moment_about_origin_Nmm=moment_origin,segments=lines,
        critical_point=critical,max_stress_MPa=critical['resultant_MPa'],
        equilibrium=dict(integrated_Fx_N=fx,integrated_Fy_N=fy,
            integrated_M_about_centroid_Nmm=mg,integrated_M_about_origin_Nmm=mo,
            Fx_residual_N=fx-force_x,Fy_residual_N=fy-force_y,
            M_centroid_residual_Nmm=mg-moment,M_origin_residual_Nmm=mo-moment_origin))
