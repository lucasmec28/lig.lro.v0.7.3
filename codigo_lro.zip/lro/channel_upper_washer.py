"""Bounded direct-bearing washer detail for the two-anchor U base.

AISC DG1 (3rd ed.) §4.5.3 and Example 4.7-6 separate anchor-rod bending
from washer shear/weld checks. The fitted-hole axial contact screen here
is an explicit elastic engineering adaptation, not a plate-bridging formula.
"""
import math
from .models import Issue,STEELS
from . import base_plate as common

MODEL='fitted_direct'
REF='AISC DG1 3ª ed., §4.5.3 e Ex.4.7-6, pp.95–96; NBR 8800:2024 corrigida 2025, §§6.2,6.3.3.3,6.5.5 · adaptação U/2'
NUT_REF='ASME B18.2.2-2010, §§3.3.2,3.4,3.6,3.8.1 e dimensões heavy hex; ASTM A563 Grade A, rosca UNC compatível'
NUT_URL='https://www.aftfasteners.com/heavy-hex-nuts-dimensions-technical-information/'
ASME_URL='https://www.zzsteels.com/knowledge/asme-b18.2.2-2010.pdf'
# Nominal diameter: Fmin, Fmax, Hmax in inches. Original commercial table,
# checked against ASME dimensional requirements; no geometric extrapolation.
NUTS={.375:(.669,.688,.377),.5:(.850,.875,.504),.625:(1.031,1.062,.631),
      .75:(1.212,1.250,.758),.875:(1.394,1.438,.885),1.:(1.575,1.625,1.012),
      1.25:(1.938,2.000,1.251),1.5:(2.300,2.375,1.505),1.75:(2.662,2.750,1.759),2.:(3.025,3.125,2.013)}


def nut_geometry(db,dh,side=None):
    key=next((d for d in NUTS if math.isclose(db,d*25.4,abs_tol=1e-8)),None)
    if key is None:raise ValueError('Diâmetro sem porca heavy hex normalizada na série implementada.')
    fmin,fmax,hmax=(v*25.4 for v in NUTS[key])
    k=.04 if key<=1.5 else .06
    face=.95*fmin-k*fmax
    recess=db+.762 if key==.375 else 1.08*db
    # The rod can touch either side of the washer hole. Subtract a concentric
    # envelope covering that actual hole for every permitted rod position.
    ebar=(dh-db)/2
    excluded=max(recess,dh+2*ebar)
    useful=min(face,side-2*ebar) if side is not None else face
    area=math.pi/4*(useful*useful-excluded*excluded)
    return dict(Fmin=fmin,Fmax=fmax,height=hmax,bearing_face=face,recess=recess,
                positional_ratio=k,rod_offset=ebar,excluded_diameter=excluded,
                useful_diameter=useful,area=area,corners_max=2*fmax/math.sqrt(3),source=NUT_REF,url=NUT_URL,asme_url=ASME_URL)


def evaluate(c,r,add):
    u=c.upper_washer;out=dict(model=MODEL,status='pending',checks=[],reasons=[])
    def pending(text):
        out['reasons'].append(text);r.issues.append(Issue('pending',text,REF,origin='channel_washer'))
    if c.anchor_layout!='two_symmetry':pending('O detalhe ajustado pertence somente à rota U/2 deste incremento.');return out
    shear=c.shear_path=='anchors'
    tension=r.geometry['Ft_max']
    if not shear and tension==0:return dict(out,status='not_demanded')
    if u.steel!='ASTM A572 Gr.50':pending('Selecionar aço ASTM A572 Gr.50 da arruela superior.')
    if c.anchor_washer_t>100.:pending('ASTM A572 Gr.50: arruela acima de 100 mm está fora do domínio material adotado; nenhuma capacidade é creditada.')
    if c.washer_nut_type!='a563_a_heavy_hex_unc':pending('Selecionar porca superior pesada ASTM A563 Grade A, UNC, compatível com a barra.')
    if c.washer_alignment not in ('joint_drilled','specified_tolerance'):
        pending('Especificar furação conjunta após solda ou tolerância máxima de alinhamento dos dois furos.')
    if c.washer_alignment=='specified_tolerance' and c.washer_offset_tolerance<=0:
        pending('Informar tolerância positiva entre os centros; coincidência efetiva exige a opção de furação conjunta.')
    if not c.washer_detail_confirmed:
        pending('Confirmar detalhe ajustado especificado: assentamento direto contínuo, sem vazio/calço, rosca compatível e engate integral da porca normalizada.')
    if shear:
        if u.layout!='four_edges':pending('Cortante: especificar quatro filetes externos iguais e contínuos por arruela.')
        if u.process!='smaw_e7018_single_pass':pending('Cortante: especificar SMAW E7018 em passe único.')
        if u.leg<=0:pending('Cortante: informar perna positiva dos filetes da arruela.')
    if out['reasons']:return out
    s=c.anchor_washer_side;ta=c.anchor_washer_t;tp=c.tp;dh=c.anchor_washer_hole
    delta=0. if c.washer_alignment=='joint_drilled' else c.washer_offset_tolerance
    geometry_ok=c.actual_base_hole+2*delta<=dh+1e-10
    check_start=len(r.checks)
    def ck(id,name,demand,resistance,unit,equation,sub='',variables='',reference=REF):
        add('uw2_'+id,name,demand,resistance,unit,reference,equation,sub,variables)
    ck('fit','Arruela ajustada — suporte integral fora do furo',c.actual_base_hole+2*delta,dh,'mm',
       'Dbase + 2δ ≤ dh',f'Dbase={c.actual_base_hole:.8g}; δ={delta:.8g}; dh={dh:.8g}',
       'Abertura da placa inteiramente contida na abertura da arruela. Furação conjunta é especificação explícita, não tolerância nula presumida. Furos alargados importados não são reduzidos.')
    if not geometry_ok:
        out.update(status='fail',support_complete=False)
        r.issues.append(Issue('noncompliance','Furo da placa ultrapassa o furo da arruela no envelope de alinhamento. Há ponte sem apoio; o modelo de contato direto não se aplica.',REF,origin='channel_washer'))
        return out
    nut=nut_geometry(c.db,dh,s);out['nut']=nut
    if nut['area']<=0:pending('A área anular conservadora sob a porca não é positiva.');return out
    # Nut must remain on the washer for every allowed bar position.
    ck('nut_fit','Porca superior — área de apoio contida na arruela',nut['corners_max']+2*nut['rod_offset'],s,'mm',
       '2Fmax/√3 + 2ebarra ≤ lado da arruela',reference=NUT_REF)
    ck('nut_grade','Porca pesada A563A UNC — compatibilidade normalizada',400.,75000*.006894757293168361,'MPa',
       'proof stress mínimo da porca ≥ fu,min da barra',
       'A563A heavy hex UNC: mínimo 75 ksi galvanizada; 100 ksi sem revestimento. Engate integral e acabamento compatível especificados.',
       'Adequação do conjunto normalizado, não resistência NBR inventada para a porca. Aplicação ao A36/3⁄8 é adaptação expressa; nenhuma carga de prova é chamada de Rd.',
       'ASTM A563A; compatibilidade por prova, princípio ASTM F1554§6.7.2 adaptado ao A36; https://www.portlandbolt.com/technical/faqs/hex-vs-heavy-hex-dimensions/')
    if tension>0:
        q=tension/nut['area'];limit=min(345.,c.fy)/common.G1
        ck('contact','Porca–arruela–placa — contato axial elástico',q,limit,'MPa',
           'q=Td/Acont ≤ min(fy,arruela;fy,placa)/γa1',
           f'Td={tension:.8g}; Dútil={nut["useful_diameter"]:.8g}; dexcl={nut["excluded_diameter"]:.8g}; Acont={nut["area"]:.8g}; q={q:.8g}',
           'Critério elástico próprio, explicitamente conservador; Td já contém 1,4 uma única vez. Diâmetro excluído cobre rebaixo da porca e folga máxima da barra no furo. Não usa fórmula de flexão de arruela sobre vazio.',NUT_REF+'; adaptação mecânica elástica')
        out.update(T_design=tension,contact_pressure=q,contact_limit=limit)
    if shear:
        F=.45*math.pi*c.db**2/4*400/common.G2
        L=4*s;q=F/L;w=u.leg;a=w/math.sqrt(2)
        ck('weld','Arruela superior — solda em corte direto',q,.6*485*a/1.35,'N/mm',
           'q=Fv,Rd/(4s) ≤ 0,6fw·a/γw2',f'Fv,Rd={F:.8g}; L={L:.8g}; a={a:.8g}; q={q:.8g}',
           'Solda dimensionada para capacidade Fv,Rd não reduzida, adaptação conservadora NBR. A curvatura reversa permanece na verificação da barra, sem adicionar binário artificial à arruela.')
        lc=(s-dh)/2
        rd=min(1.2*lc*ta*450,2.4*c.db*ta*450)/common.G2
        ck('hole','Arruela superior — pressão e rasgamento do furo',F,rd,'N',
           'Fv,Rd ≤ min(1,2lc ta fu;2,4db ta fu)/γa2',f'lc={lc:.8g}; ta={ta:.8g}; fu=450; F={F:.8g}',
           'Envelope de capacidade da barra. Não usa V/4 nem soma atrito.')
        base=STEELS[c.plate_steel]
        limits=[.6*345*ta/common.G1,.6*450*ta/common.G2,.6*base.fy*tp/common.G1,.6*base.fu*tp/common.G2]
        ck('base_metal','Arruela e placa — metal-base junto às raízes',q,min(limits),'N/mm',
           'q ≤ min(0,6fy ta/γa1;0,6fu ta/γa2;0,6fy,b tp/γa1;0,6fu,b tp/γa2)',
           'Lef=4s='+format(L,'.8g')+'; áreas locais Lef×ta e Lef×tp; limites='+','.join(format(x,'.8g') for x in limits),
           'Quatro caminhos contínuos junto às raízes, sem interseção com furo; envelope local de escoamento/ruptura em cisalhamento. Não é dimensionamento global da placa.')
        thin=min(ta,tp);wmin=3 if thin<=6.3 else 5 if thin<=12.5 else 6 if thin<=19 else 8
        ck('weld_min','Arruela superior — perna mínima',wmin,w,'mm','w ≥ Tabela 11(min(ta,tp))')
        ck('weld_max','Arruela superior — perna máxima',w,ta if ta<6.3 else ta-1.5,'mm','w ≤ ta ou ta−1,5')
        ck('length','Arruela superior — bordas contínuas',max(40.,4*w),s,'mm','s ≥ max(40;4w)')
        ck('overlap','Arruela superior — sobreposição',max(25.,5*thin),s,'mm','s ≥ max(25;5tmin)')
        ck('shelf','Arruela superior — apoio do filete',w,c.washer_clearance,'mm','w ≤ folga real disponível')
        ck('edge','Arruela superior — distância máxima à borda',s/2,min(12*ta,150.),'mm','e ≤ min(12ta;150)')
        if s>100*w:pending('Borda da arruela excede 100w; comprimento efetivo da solda deve ser tratado em outro domínio.')
        out.update(F_N=F,L_mm=L,q_resultant_Npmm=q,q_weld_Rd_Npmm=.6*485*a/1.35,
                   hole_Rd_N=rd,local_base_metal_limits=limits)
    out['checks']=[x.id for x in r.checks[check_start:]]
    out['support_complete']=True
    out['status']='fail' if any(not x.passed for x in r.checks[check_start:]) else 'pending' if out['reasons'] else 'pass'
    return out
