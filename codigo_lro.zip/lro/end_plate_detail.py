"""Optional drawing data, deliberately independent of every resistance engine."""
import math
from .display_precision import display_format

DETAIL_FIELDS={'detail_ribs','detail_rib_auto_t','detail_rib_t','detail_rib_length'}
DETAIL_SCOPE=('Nervuras de detalhamento, sem crédito resistente no cálculo base; '
              'nervuras, suas soldas e a compatibilidade do detalhe não são verificadas neste modelo.')


def next_stock_thickness(web):
    from .end_plate import STOCK
    return next((t for t in sorted(set(STOCK.values())) if t>web), None)


def validate_detail_inputs(c):
    for name in ('detail_ribs','detail_rib_auto_t'):
        if type(getattr(c,name)) is not bool:raise ValueError(name+': informar sim ou não.')
    for name,minimum,maximum in [('detail_rib_t',.1,100.),('detail_rib_length',20.,10000.)]:
        v=getattr(c,name)
        if type(v) not in (int,float) or not math.isfinite(v) or not minimum<=v<=maximum:
            raise ValueError(name+': dimensão de detalhamento inválida.')
    if c.has_detail_ribs and c.detail_rib_auto_t and next_stock_thickness(c.beam.tw) is None:
        raise ValueError('Sem espessura comercial acima da alma no catálogo; informe a espessura manual da nervura.')


def rib_ends(c):
    return (False,True) if c.layout=='both' else (False,)


def rib_polygon(c,lower=False):
    """Web-aligned external plate with 20 mm ends and a real corner clip.

    At short plate extensions, terminate within the available extent rather
    than drawing material outside the end plate. This is not a design check.
    """
    h=c.ext_bottom if lower else c.ext_top;L=c.detail_rib_length
    end=min(20.,h/2,L/2);clip=min(20.,h/2,L/2)
    points=[(0,clip),(0,h),(end,h),(L,end),(L,0),(clip,0)]
    sign=1 if lower else -1;base=c.beam.d if lower else 0.
    return [(c.tp+x,base+sign*y) for x,y in points]


def detail_description(c):
    return (f"{len(rib_ends(c))} nervuras alinhadas à alma: t={display_format(c.detail_rib_thickness, 'g')} mm; "
            f"L={display_format(c.detail_rib_length, 'g')} mm; aço {c.plate_steel}; altura acompanha a extensão da chapa; "
            'terminações e recorte de 20 mm, limitados à metade da extensão quando necessário.')
