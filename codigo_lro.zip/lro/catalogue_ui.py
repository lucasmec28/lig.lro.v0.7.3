"""Optional visual catalogue. Presentation state is confined to nav_guide_*.

No projects, widgets of physical inputs, drafts, results or imports are inspected.
Only an explicit validated open action delegates to the existing native router.
The native form always renders, even with the catalogue open, preserving Streamlit
widget lifecycle and existing per-family state/import/export safeguards.
"""
from functools import lru_cache
from hashlib import sha256
import json
from pathlib import Path
import unicodedata

from .guided_selection import (
    FAMILIES, INTERFACES, MODELS, PERMANENT_NOTE, OUTSIDE_NOTE, EMPTY_NOTE,
    STATIC_NOTES, available_models, search_families, interface_changed,
    model_changed, clear_filters, open_family, route_label,
)

ROOT = Path(__file__).resolve().parent.parent
GROUPS = (('all', 'Todas as famílias'), ('shear', 'Cortante / flexíveis'),
          ('moment', 'Momento'), ('bases', 'Placas de base'),
          ('splices', 'Emendas W'), ('bracing', 'Diagonais / chapas de nó'),
          ('seats', 'Apoios / assentos'))
EXAMPLE_NOTE = ('As miniaturas são exemplos ilustrativos dos desenhos nativos da versão 0.9.69. '
                'Dimensões, valores, estados e verificações impressos nelas pertencem apenas ao preset identificado; '
                'não representam o projeto atual nem sua aprovação. Abra o formulário para ver o projeto real.')


@lru_cache(maxsize=1)
def catalogue_assets():
    """Validate the complete packaged asset map once; return no mutable globals."""
    payload = json.loads((ROOT / 'data/catalogue_native.json').read_text(encoding='utf-8'))
    if payload.get('schema') != 1 or not isinstance(payload.get('views'), list):
        raise ValueError('Manifesto de miniaturas inválido.')
    records = payload['views']
    if len(records) != len(FAMILIES) or {r.get('id') for r in records} != {f.id for f in FAMILIES}:
        raise ValueError('As miniaturas não correspondem às 26 famílias do catálogo.')
    result = {}
    for record in records:
        family_id = record['id']
        filename = record.get('file')
        if filename != family_id + '.png' or record.get('group') not in dict(GROUPS) or record['group'] == 'all':
            raise ValueError('Caminho ou grupo inválido de miniatura: ' + family_id)
        for field in ('title', 'preset', 'renderer', 'alt'):
            if not isinstance(record.get(field), str) or not record[field]:
                raise ValueError('Descrição ausente de miniatura: ' + family_id)
        data = (ROOT / 'data/catalogue_native' / filename).read_bytes()
        if not data.startswith(b'\x89PNG\r\n\x1a\n') or sha256(data).hexdigest() != record.get('sha256'):
            raise ValueError('Miniatura ausente ou diferente do pacote: ' + family_id)
        result[family_id] = dict(record)
    return result


def validate_installation():
    catalogue_assets()


def _normalized(value):
    return ''.join(c for c in unicodedata.normalize('NFKD', str(value)).casefold()
                   if not unicodedata.combining(c))


def search_catalogue(interface='all', model='all', group='all', query=''):
    """Pure metadata AND filtering in the unchanged native route order."""
    assets = catalogue_assets()
    if group not in dict(GROUPS):
        return ()
    words = _normalized(query).split()
    return tuple(family for family in search_families(interface, model)
                 if (group == 'all' or assets[family.id]['group'] == group)
                 and all(word in _normalized(' '.join((family.id, route_label(family.route_select_value),
                     assets[family.id]['title'], family.scope_caption))) for word in words))


def _results(state):
    return search_catalogue(state.get('nav_guide_interface', 'all'), state.get('nav_guide_model', 'all'),
                            state.get('nav_guide_group', 'all'), state.get('nav_guide_query', ''))


def presentation_filter_changed(state):
    state['nav_guide_candidate'] = 'none'


def clear_catalogue_filters(state):
    clear_filters(state)
    state['nav_guide_group'] = 'all'
    state['nav_guide_query'] = ''


def choose_candidate(state, family_id):
    """Cards select metadata only, never load a preset or open a native route."""
    state['nav_guide_candidate'] = family_id if family_id in {f.id for f in _results(state)} else 'none'


def catalogue_open(state):
    candidate = state.get('nav_guide_candidate', 'none')
    if candidate not in {family.id for family in _results(state)}:
        return False
    changed = open_family(state)
    if changed:
        state['nav_guide_catalog_expanded'] = False
    return changed


def show_catalogue(state):
    state['nav_guide_catalog_enabled'] = True
    state['nav_guide_catalog_expanded'] = True


def _filters_and_cards(st, state, show_cards=True):
    assets = catalogue_assets()
    st.caption(PERMANENT_NOTE)
    st.info(EXAMPLE_NOTE)
    groups = dict(GROUPS)
    interfaces, models = dict(INTERFACES), dict(MODELS)
    interface, model = state['nav_guide_interface'], state['nav_guide_model']
    valid_interface = interface in ('all', *interfaces)
    valid_model = model in ('all', *available_models(interface))
    valid_group = state['nav_guide_group'] in groups
    row = st.columns([1, 2])
    if valid_group:
        row[0].selectbox('Grupo do catálogo', list(groups), format_func=groups.__getitem__,
                         key='nav_guide_group', on_change=presentation_filter_changed, args=(state,))
    row[1].text_input('Buscar família ou detalhe', key='nav_guide_query',
                       placeholder='Ex.: single plate, emenda W, cantoneira…',
                       on_change=presentation_filter_changed, args=(state,))
    filters = st.columns(2)
    if valid_interface:
        filters[0].selectbox('1 · Onde é a ligação?', ['all', *interfaces],
                             format_func=lambda v: 'Todos' if v == 'all' else interfaces[v],
                             key='nav_guide_interface', on_change=interface_changed, args=(state,))
    if valid_interface and valid_model:
        filters[1].selectbox('2 · Modelo de ligação', ['all', *available_models(interface)],
                             format_func=lambda v: 'Todos os modelos' if v == 'all' else models[v],
                             key='nav_guide_model', on_change=model_changed, args=(state,))
    if state.get('nav_guide_model_cleared', False):
        st.caption('O filtro de modelo foi limpo para “Todos os modelos”, pois a nova interface não contém a categoria anterior.')
    results = _results(state)
    if state.get('connection_family') not in {f.route_select_value for f in results}:
        st.info(OUTSIDE_NOTE)
    by_id = {f.id: f for f in results}
    selected = None
    if results and valid_interface and valid_model and valid_group:
        if state['nav_guide_candidate'] not in ('none', *by_id):
            state['nav_guide_candidate'] = 'none'
        st.selectbox('3 · Família disponível', ['none', *by_id],
                     format_func=lambda v: 'Selecione uma família' if v == 'none' else route_label(by_id[v].route_select_value),
                     key='nav_guide_candidate')
        selected = by_id.get(state['nav_guide_candidate'])
        if selected:
            st.markdown('**' + route_label(selected.route_select_value) + '**')
            st.caption(selected.scope_caption)
            if selected.id in STATIC_NOTES:
                st.caption(STATIC_NOTES[selected.id])
            st.caption(assets[selected.id]['preset'])
            if selected.id == 'column_web_double_cover':
                st.caption('Módulo existente disponível. A evolução técnica de duas talas está pausada; o acesso permanece ativo.')
    else:
        st.warning(EMPTY_NOTE)
    already_open = selected is not None and selected.route_select_value == state.get('connection_family')
    actions = st.columns([1, 1, 2])
    actions[0].button('Família já aberta' if already_open else 'Abrir família', key='nav_guide_open',
                       disabled=selected is None or already_open, type='primary',
                       on_click=catalogue_open, args=(state,))
    actions[1].button('Limpar filtros', key='nav_guide_clear', on_click=clear_catalogue_filters, args=(state,))
    actions[2].caption(str(len(results)) + ' famílias · selecionar uma miniatura apenas exibe seu escopo.')
    if not show_cards:
        return
    for start in range(0, len(results), 3):
        columns = st.columns(3)
        for col, family in zip(columns, results[start:start + 3]):
            asset = assets[family.id]
            with col.container(border=True):
                st.markdown('**' + asset['title'] + '**')
                st.caption(groups[asset['group']] + ' · exemplo ilustrativo')
                st.image(str(ROOT / 'data/catalogue_native' / asset['file']), width='stretch')
                st.caption('Preset de exemplo; não é o projeto atual.')
                st.button('Conferir escopo', key='nav_guide_card_' + family.id,
                          on_click=choose_candidate, args=(state, family.id), width='stretch')


def render():
    import streamlit as st
    from .visual_identity import render_header, render_project_heading
    from .guided_selection import render as render_sidebar_guide

    state = st.session_state
    defaults = {'nav_guide_catalog_enabled': True, 'nav_guide_catalog_expanded': True,
                'nav_guide_navy': True, 'nav_guide_group': 'all', 'nav_guide_query': '',
                'nav_guide_interface': 'all', 'nav_guide_model': 'all',
                'nav_guide_candidate': 'none', 'nav_guide_model_cleared': False}
    for key, value in defaults.items():
        state.setdefault(key, value)
    # Preserve presentation-only widgets while the optional catalogue is hidden.
    for key in defaults:
        state[key] = state[key]
    st.sidebar.toggle('Catálogo visual', key='nav_guide_catalog_enabled')
    st.sidebar.toggle('Identidade LRO · marinho', key='nav_guide_navy')
    st.sidebar.button('Voltar ao catálogo', key='nav_guide_back_catalogue',
                      on_click=show_catalogue, args=(state,))
    if state['nav_guide_navy']:
        render_header(st)
    if state['nav_guide_catalog_enabled']:
        with st.expander('Catálogo de ligações · encontrar e abrir uma família',
                         expanded=True, key='nav_guide_catalog_expanded', on_change='rerun') as catalogue:
            # Only illustration cards are lazy. Search widgets and the native form
            # still render to preserve their existing Streamlit state lifecycle.
            _filters_and_cards(st, state, show_cards=catalogue.open)
    else:
        render_sidebar_guide()
    if state['nav_guide_navy']:
        render_project_heading(st, route_label(state.get('connection_family', '')))
