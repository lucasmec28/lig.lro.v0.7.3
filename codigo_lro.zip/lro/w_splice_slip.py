"""NBR 8800:2024 ELS slip for the existing conventional W splice.

Standard round holes only. Strength/contact checks remain in their original
engine. No sum of the serial member ends; no inference from paint exposure.
"""
import math

REFERENCE='ABNT NBR 8800:2024 corrigida 2025, 6.3.4.1–6.3.4.4 e 6.8.4.1 / Tabela 19'
# Minimum pretension, NBR Table 19, printed p111/PDF133. These are prescribed
# engineering inputs, not a capacity table or an approximate area derivation.
PRETENSION_N={
    'ASTM F3125 A325':{16.:91000.,20.:142000.,24.:205000.,30.:326000.},
    'ASTM F3125 A490':{16.:114000.,20.:178000.,24.:257000.,30.:408000.},
}
SURFACES={
    'A':(.30,'Classe A: laminadas, limpas, sem óleo/graxa e sem pintura na região de contato'),
    'B':(.50,'Classe B: jateadas e sem pintura na região de contato'),
    'C':(.30,'Classe C: galvanizadas a quente, rugosidade aumentada MANUALMENTE com escova de aço, sem máquina'),
    'galvanized':(.20,'Galvanizadas a quente, sem aumento manual de rugosidade'),
}
BASIS={'pending':'Selecionar a combinação de serviço',
       'rare_service':'N/M/V da combinação rara de serviço',
       'normal_uls_70':'70% de N/M/V do caso ELU normal informado (NBR 6.3.4.4)'}


def evaluate_slip(c,g,mechanics):
    out={'status':'PENDING','checks':[],'reasons':[],'reference':REFERENCE,
         'basis':c.slip_action_basis,'surface_class':c.slip_surface_class,
         'limit_state':'ELS_DESLIZAMENTO','strength_checks_replaced':False,
         'serial_ends_added':False,'synthetic_minimum_cases_used':False}
    if c.slip_action_basis not in ('rare_service','normal_uls_70'):
        out['reasons'].append('Selecionar ações raras de serviço ou a alternativa normativa de 70% do caso ELU normal.');return out
    if c.slip_surface_class not in SURFACES:
        out['reasons'].append('Especificar a classe real das superfícies de contato; pintura/proteção externa não define o coeficiente de atrito.');return out
    if not c.normal_combination:
        out['reasons'].append('Esta emenda mantém seu domínio de ELU normal. A alternativa de 70% não se aplica a combinações excepcionais; nenhum fator é convertido.');return out
    ftb=PRETENSION_N.get(c.bolt,{}).get(c.db)
    if ftb is None:
        out['reasons'].append('Protensão mínima não definida para o parafuso informado neste domínio.');return out
    if c.slip_action_basis=='rare_service':
        N,M,V=c.slip_service_N,c.slip_service_M,c.slip_service_V
    else:N,M,V=.70*c.N,.70*c.M,.70*c.V
    if not all(math.isfinite(v) for v in (N,M,V)):raise ArithmeticError('Ações de serviço fora da faixa numérica.')
    out['actions']={'N_N':N,'M_Nmm':M,'V_N':V,'factor':.70 if c.slip_action_basis=='normal_uls_70' else 1.,'description':BASIS[c.slip_action_basis]}
    if N==M==V==0.:
        out['status']='NOT_EVALUATED';out['reasons'].append('Combinação de serviço nula: capacidades informativas não aprovam uma solicitação de deslizamento. Informe a combinação rara aplicável.');return out
    mu,description=SURFACES[c.slip_surface_class]
    load=mechanics(c,g,N,M,V)
    out.update(mu=mu,Ce=1.,minimum_pretension_N=ftb,bolt_axial_tension_service_N=0.,
        flange_slip_planes=2 if c.include_inner_flange_plates else 1,web_slip_planes=2,
        surface_description=description,load_model=load,
        equation='Ff,Rk = 0,80 μ Ce FTb ns [1 − Ft,Sk/(0,80 FTb)]',
        bolt_tension_basis='Ft,Sk=0 no modelo nominal de forças no plano, com detalhe convencional completo e restrito. N/M geram corte longitudinal nos parafusos, não tração em seu eixo. Não representa abertura, alavanca ou ação fora do plano.',
        execution_requirements=[
            'Conjuntos novos e conformes, contato firme aço–aço; sem sujeira, rebarba ou carepa solta. Extremidade do parafuso nivelada ou além da face externa da porca.',
            'Arruela endurecida sob o elemento girado; também sob o elemento não girado para A490 contra aço com fy<280 MPa. NBR 6.8.',
            'Instalação por rotação da porca, chave calibrada ou indicador direto de tração, e inspeção conforme 6.8.5. Não usar tabela genérica de torque. A seleção de projeto não certifica execução.',
            'Especificar e executar a protensão mínima por parafuso conforme NBR 6.8.4 / Tabela 19, com procedimento de instalação e inspeção aplicáveis. Valor de projeto não comprova aperto executado.',
            'Mesma classe de superfície em todos os planos de contato de mesas e alma. Manter a região de atrito conforme 6.3.4.3/Figura 13. Revestimento com atrito dependente de ensaio RCSC não pertence a estas opções.',
            'Sem chapas de enchimento: Ce=1. Talas estruturais não são calços. Um plano nas mesas sem internas; dois nas mesas com internas e na alma; lados da emenda em série.',
            'Furos circulares padrão e ações estáticas no domínio atual. A verificação ELS não substitui corte/contato e demais verificações ELU de 6.3.3.',
            'Força de tração externa ao longo do eixo do parafuso, abertura, levantamento ou efeito alavanca fora do detalhe convencional não são admitidos. A idealização sem tração axial segue o caminho no plano já qualificado; não é certificado de rigidez ou aperto.'
        ])
    def add(identifier,group,demand,planes,**details):
        capacity=.80*mu*ftb*planes
        ratio=demand/capacity
        if not all(math.isfinite(x) for x in (capacity,demand,ratio)) or capacity<=0:raise ArithmeticError('Deslizamento fora da faixa numérica.')
        out['checks'].append(dict(id=identifier,group=group,demand_N=demand,capacity_N=capacity,
            utilization=ratio,status='NOT_APPLICABLE' if demand==0 else 'PASS' if demand<=capacity else 'FAIL',
            slip_planes=planes,limit_state='ELS_DESLIZAMENTO',reference=REFERENCE,**details))
    for pos,F in [('top',load['top_force_N']),('bottom',load['bottom_force_N'])]:
        for side in ('left','right'):
            for i in range(2*c.flange_rows):
                add(f'flange_{pos}_{side}_{i}','Mesa '+('superior' if pos=='top' else 'inferior')+' · '+('esquerda' if side=='left' else 'direita'),
                    abs(F)/(2*c.flange_rows),out['flange_slip_planes'],signed_group_force_N=F)
    for group in load['web_groups']:
        for i,b in enumerate(group['bolts']):
            add(f'web_{group["side"]}_{i}','Alma · '+('esquerda' if group['side']=='left' else 'direita'),b['resultant_N'],2,
                qx_N=b['qx_N'],qy_N=b['qy_N'],x_mm=b['x_mm'],y_mm=b['y_mm'])
    governing=max(out['checks'],key=lambda r:r['utilization'])
    out.update(status='FAIL' if any(r['status']=='FAIL' for r in out['checks']) else 'PASS',
               governing_check=governing,failed_check_ids=[r['id'] for r in out['checks'] if r['status']=='FAIL'])
    return out


def bolt_label(identifier):
    parts=identifier.split('_')
    if parts[0]=='flange':
        return 'Mesa '+('sup.' if parts[1]=='top' else 'inf.')+' '+('esq.' if parts[2]=='left' else 'dir.')+' · P'+str(int(parts[3])+1)
    return 'Alma '+('esq.' if parts[1]=='left' else 'dir.')+' · P'+str(int(parts[2])+1)
