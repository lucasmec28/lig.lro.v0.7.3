"""Independent optional component inputs, with family-scoped drafts and bound qualifications."""
from .display_precision import display_value, number_input
from dataclasses import asdict,fields,replace
import streamlit as st
from .models import KGF
from .report import number
from .concrete_components import ConcreteComponents,bearing_signature,distribution_signature,anchor_shear_demand


def _prefix():return st.session_state.get('_baseplate_ui_prefix','bp')
def _key(name):return _prefix()+'_cc_'+name
def _draft():return '_'+_prefix()+'_concrete_components_draft'
def _canonical(value,previous,factor):return previous if previous is not None and value==previous/factor else value*factor
_LOADS=('mechanical_resistance','force_a1','force_a2','force_a3','force_a4')


def seed_component_details(c):
    data=asdict(c.concrete_components);s=st.session_state
    for name,value in data.items():
        s[_key(name)]=value/KGF if name in _LOADS else float(value) if type(value) in (float,int) else value
    s[_draft()]=data


def restore_component_details(connection):
    s=st.session_state;data=s.get(_draft(),connection.get('concrete_components',{}))
    for name,default in asdict(ConcreteComponents()).items():
        value=data.get(name,default)
        s[_key(name)]=s.get(_key(name),value/KGF if name in _LOADS else float(value) if type(value) in (float,int) else value)


def component_detail_widgets(c=None):
    need_tension=True
    if c is not None:
        from .base_plate import reactions as fixed_reactions
        from .pinned_base_plate import reactions as pinned_reactions
        try:
            need_tension=(fixed_reactions if c.model_type==1 else pinned_reactions)(c).get('Ft_max',0)>0 or key_tension_required(c)
        except (ValueError,TypeError,OverflowError,ZeroDivisionError):
            need_tension=True
    demand=anchor_shear_demand(c) if c is not None else None
    need_shear=(demand['V_anchor'] not in (None,0.)) if demand else st.session_state.get(_prefix()+'_shear_path')=='anchors' and st.session_state.get(_prefix()+'_V_kgf',0.)!=0

    with st.expander('Ancoragem ACI · pullout, ruptura lateral, cortante e interação'):
        mode=st.selectbox('Verificações complementares da ancoragem',['off','aci318_19'],key=_key('model'),
            format_func=lambda v:'Não selecionadas' if v=='off' else 'ACI 318-19 · modos separados, com dados explícitos')
        if mode=='off':return
        st.caption('Usa o detalhe enterrado, hef e bloco real informados acima. O cone de tração continua sendo selecionado no campo próprio. Os resultados locais não aprovam o bloco nem a base completa.')
        if not need_tension and not need_shear:
            st.caption('Sem tração ou cortante demandado nos chumbadores nesta combinação; áreas de aço e apoio enterrado não são solicitadas.' if demand and demand['V_anchor']==0 else 'Defina a restrição real das barras no detalhe do dispositivo para estabelecer os modos aplicáveis.')
            return
        if need_tension:
            number_input('Área líquida efetiva de apoio enterrado Abrg (mm²)',min_value=0.,key=_key('bearing_area'),format='%.2f')
            st.text_input('Fonte e verificação da área efetiva de apoio',key=_key('bearing_area_ref'))
            st.caption('Área efetivamente sustentada pela cabeça/porca/chapa: não se presume rigidez de toda a projeção. Para chapa enterrada, é necessária comprovação mecânica da montagem antes de creditar área.')
            number_input('Resistência mecânica documentada do apoio enterrado por barra (kgf)',min_value=0.,key=_key('mechanical_resistance'),format='%.2f')
            st.text_input('Memória mecânica da cabeça, porca ou chapa enterrada',key=_key('mechanical_ref'))
            st.caption('Zero ou fonte ausente = pendente. A área e a comprovação devem corresponder às dimensões atuais do detalhe; a confirmação aparece abaixo das entradas.')
        st.markdown('**Aço da barra · resistência ACI complementar**')
        number_input('Área efetiva rosqueada Ase,N (mm²)',min_value=0.,key=_key('area_tension'),format='%.2f')
        if need_shear:
            number_input('Área efetiva no corte Ase,V (mm²)',min_value=0.,key=_key('area_shear'),format='%.2f')
        st.text_input('Fonte das áreas efetivas da barra',key=_key('steel_area_ref'))
        st.checkbox('Ductilidade conforme critério ACI comprovada',key=_key('ductile'))
        if st.session_state[_key('ductile')]:st.text_input('Referência da comprovação de ductilidade ACI',key=_key('ductility_ref'))
        st.caption('Sem comprovação de ductilidade: φN=0,65 e φV=0,60; ASTM A36 por nome não comprova esse requisito. Considera redução ACI de 0,8 no cortante para base sobre graute. Não combina capacidades NBR com φACI.')
        if not need_shear:
            st.caption('Dados de distribuição do cortante aparecem quando há V pelos chumbadores. O detalhamento informado permanece salvo.')
            return
        st.markdown('**Distribuição física do cortante nos chumbadores**')
        st.caption('Preencha magnitudes por barra, no sentido de V, somente se esta rota transfere V pelos chumbadores. Não há V/4 automático. A1/A2 estão em x negativo; A3/A4 em x positivo. Os pares devem coincidir e a soma deve ser |V|.')
        cols=st.columns(2)
        for i in range(1,5):
            with cols[(i-1)%2]:number_input(f'Cortante documentado A{display_value(i)} (kgf)',min_value=0.,key=_key(f'force_a{display_value(i)}'),format='%.2f')
        st.text_input('Memória da distribuição e do caminho físico do cortante',key=_key('distribution_ref'))
        st.selectbox('Bordas paralelas ao cortante',['pending','virtual_perpendicular'],key=_key('parallel_model'),
            format_func=lambda v:'Pendente · não atribuir resultado completo' if v=='pending' else 'Construção perpendicular virtual · ACI 17.7.2.1(c)')
        st.caption('A construção virtual avalia mecanismos alternativos nas bordas laterais, com as mesmas forças qualificadas. Não são forças simultâneas adicionadas ao grupo. A sua aplicabilidade deve constar da memória da distribuição.')
        st.checkbox('Adicionar envelope conservador suplementar de linhas',key=_key('optional_envelope'))


def key_tension_required(c):
    """Use the existing two declared force models only to choose input visibility."""
    if c.shear_path!='plate' or c.single_key_concrete.model=='off':return False
    from .single_key_concrete import key_geometry,type1_force_state,type2_force_state,PHI
    from .base_plate import reactions as fixed_reactions
    from .pinned_base_plate import reactions as pinned_reactions
    try:
        native=(fixed_reactions if c.model_type==1 else pinned_reactions)(c)
        if native.get('Ft_max',0)>0:return True
    except (ValueError,TypeError,OverflowError,ZeroDivisionError):
        pass
    try:
        geo=key_geometry(b=c.lug_bh,H=c.lug_bv,g=c.grout_t,t=c.lug_t,
                         bounds=(c.block_xmin,c.block_ymin,c.block_xmax,c.block_ymax),ha=c.block_h)
        solver=type1_force_state if c.model_type==1 else type2_force_state
        state=solver(N=c.N,Mbase=c.M+c.V*(c.tp+c.grout_t+geo['d']/2),L=c.L,B=c.B,
                     a=c.a,row_y=c.a2/2,pressure_limit=PHI*.85*c.fck)
        return any(rod['tension']>0 for rod in state['rods'])
    except (ValueError,TypeError,OverflowError,ZeroDivisionError):
        # Uplift definitely needs the shared area; an unsolved compression state
        # remains pending, without inventing a tension demand for visibility.
        return c.N<0


def shared_key_tension_widgets(c):
    if c.concrete_components.model!='off' or not key_tension_required(c):return c
    with st.expander('Chumbadores tracionados · área compartilhada com a chave',expanded=True):
        st.caption('Há tração em barras de pelo menos um estado da chave. Informe a mesma área efetiva usada pelo aço ACI; isso não seleciona outros modos nem qualifica a ancoragem.')
        number_input('Área efetiva rosqueada Ase,N (mm²)',min_value=0.,key=_key('area_tension'),format='%.2f')
        st.text_input('Fonte das áreas efetivas da barra',key=_key('steel_area_ref'))
    return replace(c,concrete_components=components_from_state())


def components_from_state():
    s=st.session_state;prior=s.get(_draft(),{});data={}
    for name,default in asdict(ConcreteComponents()).items():
        value=s.get(_key(name),prior.get(name,default)/KGF if name in _LOADS else prior.get(name,default))
        data[name]=_canonical(value,prior.get(name),KGF) if name in _LOADS else value
    result=ConcreteComponents(**data);s[_draft()]=asdict(result);return result


def component_qualifications(c):
    u=c.concrete_components
    if u.model=='off':return c
    with st.expander('Confirmações vinculadas ao detalhe e à combinação atuais'):
        from .concrete_anchorage import anchor_tensions
        from .base_plate import reactions as fixed_reactions
        from .pinned_base_plate import reactions as pinned_reactions
        try:
            needs_bearing=(fixed_reactions if c.model_type==1 else pinned_reactions)(c).get('Ft_max',0)>0 or key_tension_required(c)
        except (ValueError,TypeError,OverflowError,ZeroDivisionError):
            needs_bearing=True
        if needs_bearing:
            sig=bearing_signature(c)
            ready=st.checkbox('A área efetiva e a memória mecânica correspondem a esta geometria enterrada e à montagem real.',
                value=bool(u.bearing_confirmation) and u.bearing_confirmation==sig,key=_key('bearing_confirm_'+sig[:20]))
            u=replace(u,bearing_confirmation=sig if ready else '')
        if c.shear_path=='anchors' and c.V!=0:
            sig=distribution_signature(replace(c,concrete_components=u))
            ready=st.checkbox('A memória citada verifica estas forças individuais, seu caminho físico e as hipóteses de borda para esta combinação e geometria.',
                value=bool(u.distribution_confirmation) and u.distribution_confirmation==sig,key=_key('distribution_confirm_'+sig[:20]))
            u=replace(u,distribution_confirmation=sig if ready else '')
        st.caption('Alterações relevantes invalidam as confirmações. Marcar não transforma área, distribuição ou referência ausente em dados verificados pelo app.')
    st.session_state[_draft()]=asdict(u)
    st.session_state[_key('bearing_confirmation')]=u.bearing_confirmation
    st.session_state[_key('distribution_confirmation')]=u.distribution_confirmation
    return replace(c,concrete_components=u)


LABELS={'head_mechanical':'Apoio enterrado · comparação mecânica documental','pullout':'Pullout','sideface':'Ruptura lateral',
        'breakout':'Ruptura ao cortante','pryout':'Pryout','aci_steel':'Aço · ACI','interaction':'Interação ACI · estados enumerados'}


def component_results(c,r):
    if c.concrete_components.model=='off':return
    result=r.concrete_components
    with st.expander('Ancoragem ACI · resultados por modo',expanded=True):
        demands=result.get('component_demands',{})
        if demands:
            value=demands.get('V_anchor')
            st.caption('Cortante na face superior: '+number(demands['V_column']/KGF,3)+' kgf; nos chumbadores: '+('pendente de modelo físico' if value is None else number(value/KGF,3)+' kgf')+'. Caminho selecionado: '+str(demands['route'])+'.')
        for name,mode in result.get('modes',{}).items():
            label=LABELS.get(name,name);status=mode.get('status')
            failed=any(check.get('ratio',0)>1+1e-10 and not check.get('diagnostic_only') for check in mode.get('checks',[])) or mode.get('numerical_screen_passes') is False
            if failed:st.error(label+': NÃO ATENDE aos modos calculados.')
            elif status in ('calculated','verified'):st.success(label+': ATENDE aos modos calculados.')
            elif status=='not_demanded':st.caption(label+': sem solicitação nesta combinação.')
            elif status=='not_applicable':st.caption(label+': não aplicável no domínio verificado.')
            else:st.warning(label+': PENDENTE.')
            if mode.get('applicability_note'):st.caption(mode['applicability_note'])
            for reason in mode.get('reasons',[]):st.caption(str(reason))
            for check in mode.get('checks',[]):
                st.write(('Diagnóstico sem conclusão · ' if check.get('diagnostic_only') else '')+check.get('label',label)+f": Sd={display_value(number(check['demand'] / KGF, 3))} kgf; Rd={display_value(number(check['resistance'] / KGF, 3))} kgf; índice={display_value(number(check['ratio'], 3))}.")
            if name=='interaction' and 'beta_N' in mode:
                st.write(f"βN={display_value(number(mode['beta_N'], 4))}; βV={display_value(number(mode['beta_V'], 4))}; índice parcial={display_value(number(mode['ratio'], 4))}.")
                st.caption('Numeradores e capacidades preservam o grupo/barra e o mesmo estado de forças. '+('Interação dos modos e estados enumerados calculada; a ancoragem completa permanece a complementar.' if mode.get('passes') is not None else 'Triagem parcial; resultado favorável não aprova modos ausentes.'))
                for state in mode.get('states_summary',[]):st.write(state['label']+': índice='+number(state['ratio'],4)+'; forças em N='+str(state['forces']))
        if result.get('attachment_demands'):
            st.caption('Demandas máximas de transferência por barra entre os estados, sem somá-los: '+', '.join(x['id']+'='+number(x['required']/KGF,3)+' kgf' for x in result['attachment_demands']))
        st.caption('N/A e sem solicitação não são aprovações numéricas. A conclusão da ancoragem limita-se aos modos e estados explicitados; consulte o resumo de escopo local.')


def base_scope_summary(c,r):
    """One summary of actual local gaps; external project duties are separate."""
    local=[]
    if c.column_weld.model=='off':local.append('Soldas pilar–placa: componente resistente ainda não selecionado.')
    else:local.append('Pilar–placa: resultados locais abaixo; transferência pela placa até contato/chumbadores e compatibilidade do detalhe permanecem no escopo específico.')
    if c.shear_path=='plate':
        local.append('Chave única: metal-base junto à fusão e flexão/transferência da placa receptora ainda não calculados; solda e concreto têm seus próprios resultados abaixo.')
    elif c.native_anchor_shear:
        local.append('Arruela–placa: flexão local e transferência do binário/contato ainda não calculadas; metal da solda e furo são componentes separados.')
    elif c.shear_path not in ('friction','anchors'):
        local.append('Dispositivo: confira o campo de forças, sua ligação e o mecanismo de concreto no modelo ou memória selecionados.')
    if c.cone_model=='off' and c.concrete_components.model=='off':
        local.append('Ancoragem no concreto: não calculada neste projeto; necessária quando houver tração/cortante nos chumbadores.')
    with st.expander('Escopo local e responsabilidades do projeto'):
        for item in local:st.write(item)
        st.caption('Responsabilidades separadas: bloco e armaduras NBR 6118, fundação/solo, membro e rigidez global, montagem e conformidade de execução/inspeção. Não foram verificados por este aplicativo. Se um modelo selecionado depende desses dados, seu requisito específico continua obrigatório.')
