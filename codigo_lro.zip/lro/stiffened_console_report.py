"""Original numerical reporting; does not reproduce Manual artwork/tables."""
from io import BytesIO,StringIO
import csv
from .stiffened_console import evaluate,project

def csv_bytes(c):
    r=evaluate(c);s=StringIO();w=csv.writer(s,delimiter=';')
    w.writerow(['Verificação','Solicitação ou mínimo','Resistência ou disponível','Unidade','Utilização','Resultado','Referência'])
    def fmt(v):return f'{v:.2f}'.replace('.',',')
    for x in r['checks']:
        scale=1000 if x['unit']=='N' else 1
        w.writerow([x['name'],fmt(x['demand']/scale),fmt(x['capacity']/scale),'kN' if scale==1000 else x['unit'],fmt(x['ratio']),'OK' if x['ok'] else 'NÃO ATENDE',x['reference']])
    return ('\ufeff'+s.getvalue()).encode('utf-8')

def word_bytes(c,sketch=None):
    from docx import Document
    from docx.shared import Inches,Pt,RGBColor
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    d=Document();sec=d.sections[0];sec.page_width=Inches(8.5);sec.page_height=Inches(11)
    sec.top_margin=sec.bottom_margin=Inches(.65)
    sec.left_margin=sec.right_margin=Inches(.65)
    for name in ['Normal','Title','Heading 1','Heading 2']:
        st=d.styles[name];st.font.name='Calibri';st.font.color.rgb=RGBColor(0,0,0)
    d.styles['Normal'].font.size=Pt(10)
    d.styles['Title'].font.size=Pt(24)
    for el in list(d.styles.element.iter()):
        if el.tag==qn('w:pBdr'):el.getparent().remove(el)
    r=evaluate(c)
    d.add_paragraph('Memória de verificação do console recortado','Title')
    d.add_paragraph(r['status']+'. Verificações locais do apoio inferior conforme AISC 360-16 LRFD e Manual 15. O resultado depende das condições de contato, centralização, parafusos e contenção descritas. Não autoriza fabricação sem revisão do responsável técnico.')
    d.add_heading('Domínio e dados',1)
    d.add_paragraph(f'Pilar {c.column_profile}, {c.column_material}, apoio em apenas um lado da alma. Viga I/W simétrica com propriedades e resistência declaradas. Chapas A36 e eletrodo E70. Nervura central alinhada à alma da viga e ajustada para contato sob o assento. Patamares do recorte de 20 mm.')
    labels={'column_profile':'Pilar','column_material':'Material do pilar','beam_d':'d da viga','beam_bf':'bf da viga','beam_tw':'tw da viga','beam_tf':'tf da viga','beam_k1':'k1 da viga','beam_k':'k da viga','beam_fy':'Fy da viga','projection':'Projeção W','reaction':'Reação V','length':'Altura l','weld':'Perna da solda','rib_thickness':'Espessura da nervura','seat_thickness':'Espessura do assento','seat_width':'Largura do assento','rib_seat_weld':'Solda nervura ao assento','rib_seat_length':'Comprimento por lado'}
    d.add_paragraph('Comprimentos em mm, tensões em MPa e força em N.')
    items=list(project(c)['connection'].items())
    for i in range(0,len(items),2):d.add_paragraph(' | '.join(f'{labels[k]}: {v if isinstance(v,str) else format(v,".6g")}' for k,v in items[i:i+2]))
    col=r.get('fixed',{}).get('column_catalogue',{})
    if col:d.add_paragraph(f"Receptor: {col['us_designation']}; tw={col['tw']:g} mm; envelope de montagem={col['fit_clear']:g} mm. Fonte: {col['source']}, p. {col['source_page']}. O envelope é conservador e não iguala d′ a T.")
    d.add_heading('Método e referências',1)
    d.add_paragraph('Soldas em T: comprimento total 2,4l, módulo resistente à tração 0,6l² e excentricidade 0,8W. Resistência LRFD por método elástico com φ=0,75 e tensão nominal 0,6FEXX. Alma da viga conforme J10.2 e J10.3; detalhamento de soldas J2.2 e Tabela J2.4. Espessuras e alma receptora conforme Manual 15, pp. 10-78 a 10-81 e Eq. 9-2. Benchmark Companion II.A-15.')
    d.add_page_break();d.add_heading('Resultados locais',1)
    t=d.add_table(rows=1,cols=4);t.style='Table Grid'
    for cell,label in zip(t.rows[0].cells,['Verificação','Solicitação / mínimo','Disponível','Utilização']):cell.text=label
    for x in r['checks']:
        cells=t.add_row().cells;scale=1000 if x['unit']=='N' else 1;unit='kN' if scale==1000 else x['unit']
        for cell,value in zip(cells,[x['name'],f"{x['demand']/scale:.2f} {unit}",f"{x['capacity']/scale:.2f} {unit}",f"{x['ratio']:.2f} · {'OK' if x['ok'] else 'FALHA'}"]):cell.text=value
    for border in t._tbl.xpath('.//w:tblBorders/*'):
        border.set(qn('w:color'),'D9D9D9')
    for row in t.rows:
        for cell in row.cells:
            for p in cell.paragraphs:
                for run in p.runs:run.font.size=Pt(9)
    borders=OxmlElement('w:tblBorders')
    for side in ['top','left','bottom','right','insideH','insideV']:
        el=OxmlElement('w:'+side);el.set(qn('w:val'),'single');el.set(qn('w:sz'),'4');el.set(qn('w:color'),'D9D9D9');borders.append(el)
    t._tbl.tblPr.append(borders)
    hdr=OxmlElement('w:tblHeader');t.rows[0]._tr.get_or_add_trPr().append(hdr)
    for e in r['errors']:d.add_paragraph(e)
    d.add_page_break();d.add_heading('Detalhe e condições de aplicação',1)
    if sketch:d.add_picture(str(sketch),width=Inches(7.1))
    for note in r.get('warnings',[]):d.add_paragraph(note)
    d.add_paragraph('A solda transversal ao pilar fica sob o assento. Não acrescentar solda superior formando contorno fechado sem análise própria. Os desenhos são originais e esquemáticos; não substituem o detalhamento de fabricação.')
    b=BytesIO();d.save(b);return b.getvalue()
