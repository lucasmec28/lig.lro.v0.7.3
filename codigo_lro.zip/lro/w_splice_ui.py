"""Independent UI/persistence for the real eight-cover M004 W splice."""
from dataclasses import asdict, fields
import hashlib
import json
import math
import pandas as pd
import streamlit as st
from .load_conventions import render as render_load_convention
from .models import Profile,profiles,STEELS,KGF,VERSION
from .w_splice import WSplice,FAMILY,SCOPE,presets,evaluate
from .report import BRAND,LINK,number

P={k:v for k,v in profiles().items() if v.family=='W'}
PRESETS=presets()
STATUS={'INVALID_INPUT':'DADOS INVÁLIDOS','INVALID_GEOMETRY':'GEOMETRIA FISICAMENTE INVÁLIDA',
        'NUMERICAL_FAILURE':'CÁLCULO NÃO CONCLUÍDO · LIMITE NUMÉRICO',
        'OUTSIDE_BALANCED_M004_SCOPE':'FORA DO DOMÍNIO M004 BALANCEADO EM TRAÇÃO',
        'NOT_EVALUATED':'SEM TRAÇÃO AVALIÁVEL','DETAIL_FAIL':'NÃO ATENDE AO DETALHAMENTO',
        'VERIFIED_SUBCHECK_FAIL':'NÃO ATENDE ÀS VERIFICAÇÕES REALIZADAS',
        'ENGINEERING_MODEL_PENDING':'VERIFICAÇÃO COMPLEMENTAR PENDENTE',
        'COMPLETE_CHECKS_PASS_WITH_PRESET_DEVIATION':'ATENDE NO DOMÍNIO · DETALHE DIFERE DO PRESET M004',
        'COMPLETE_CHECKS_PASS_WITHIN_SCOPE':'ATENDE ÀS VERIFICAÇÕES NO DOMÍNIO DE TRAÇÃO'}


PROFILE_SCALARS=('d','bf','tw','tf','clear','area','mass')
POSITIVE_WIDGETS=('flange_outer_width','flange_inner_width','inner_clear_band','flange_t',
                  'flange_pitch','flange_member_end','flange_cover_end','web_height','web_t',
                  'web_pitch','web_gauge','web_member_end','web_cover_end','hole_diameter','tool_radius')


def validate_widget_representation(c):
    """Validate the entire import before touching any live project/widget state.

    Domain-invalid geometry may be a diagnostic draft. Controls must never
    replace an unsupported enum, clamp a dimension or rewrite hidden topology.
    """
    errors=[]
    def reject(field,value,reason):errors.append(f'{field}={value!r}: {reason}')
    options={'profile.family':('W',),'db':(16.,20.,24.,30.),
             'bolt':('ASTM F3125 A325','ASTM F3125 A490'),
             'member_steel':tuple(k for k,s in STEELS.items() if s.rolled_allowed),
             'flange_steel':tuple(k for k,s in STEELS.items() if s.plate_allowed),
             'web_steel':tuple(k for k,s in STEELS.items() if s.plate_allowed),
             'exposure':('painted','weathering'),
             'minimum_action_policy':('tension_strength','slenderness','engineer_waived')}
    for field,allowed in options.items():
        value=c.profile.family if field=='profile.family' else getattr(c,field)
        if value not in allowed:reject(field,value,'valor não representável no seletor; opções: '+', '.join(map(str,allowed)))
    if not 2<=c.flange_rows<=6:reject('flange_rows',c.flange_rows,'o controle admite inteiro de 2 a 6, sem substituição')
    for field,value in (('web_rows',2),('web_levels',3)):
        if getattr(c,field)!=value:reject(field,getattr(c,field),f'malha fixa desta interface exige {value}; não será sobrescrita')
    for field in POSITIVE_WIDGETS:
        value=getattr(c,field)
        if value<.1:reject(field,value,'mínimo representável no controle: 0.1 mm')
    for field in PROFILE_SCALARS:
        value=getattr(c.profile,field)
        if value<.01:reject('profile.'+field,value,'mínimo representável no controle: 0.01')
    # Browser number controls use doubles. Do not silently round large integer
    # dimensions; floating-point unit conversion roundoff is allowed.
    for field,value in asdict(c).items():
        values=value.items() if field=='profile' else ((field,value),)
        for key,v in values:
            name='profile.'+key if field=='profile' else key
            if type(v) is int and float(v)!=v:reject(name,v,'inteiro não representável exatamente em precisão dupla')
    for field,scale in (('N',KGF),('M',KGF*1000),('V',KGF),('torsion',KGF*1000),('compression_resistance',KGF)):
        value=getattr(c,field);display=value/scale
        restored=display*KGF
        if field in ('M','torsion'):restored*=1000
        if not math.isfinite(display) or not math.isfinite(restored) or (value!=0 and (display==0 or restored==0)):
            reject(field,value,'conversão de unidade não representável pelo controle')
    if errors:raise ValueError('; '.join(errors))


def _restore_custom_draft(draft):
    s=st.session_state;p=draft['profile']
    s['ws_manual_name']=p['name'];s['ws_profile_source']=p['source']
    for key in PROFILE_SCALARS:s['ws_profile_'+key]=float(p[key])
    s['ws_root_radius']=draft['root_radius']


def seed(c):
    validate_widget_representation(c)
    s=st.session_state
    for f in fields(c):
        if f.name!='profile':s['ws_'+f.name]=getattr(c,f.name)
    s['ws_N_kgf']=c.N/KGF;s['ws_M_kgfm']=c.M/(KGF*1000);s['ws_V_kgf']=c.V/KGF;s['ws_torsion_kgfm']=c.torsion/(KGF*1000)
    s['ws_compression_kgf']=c.compression_resistance/KGF
    s['ws_profile_name']=c.profile.name if c.profile.name in P and c.profile==P[c.profile.name] else 'W personalizado'
    if s['ws_profile_name']=='W personalizado' or '_w_splice_custom_draft' not in s:
        s['_w_splice_custom_draft']={'profile':asdict(c.profile),'root_radius':c.root_radius}
    # The active catalogue project and the last manual draft are independent.
    # Reentry into this family must not replace the hidden custom profile.
    active_root=c.root_radius
    _restore_custom_draft(s['_w_splice_custom_draft'])
    s['ws_root_radius']=active_root
    s.pop('ws_root_suggestion',None)
    s.pop('ws_report',None)


def use_example():seed(PRESETS[st.session_state.ws_example])

def load_project():
    try:
        upload=st.session_state.ws_upload
        if upload is None:raise ValueError('Selecione um arquivo JSON.')
        if len(upload.getvalue())>200000:raise ValueError('Arquivo maior que 200 kB.')
        c=WSplice.from_dict(json.loads(upload.getvalue()))
        seed(c);st.session_state.pop('ws_import_error',None)
    except (ValueError,TypeError,KeyError,OverflowError) as exc:st.session_state.ws_import_error='Não foi possível abrir: '+str(exc)


def bolt_changed():
    st.session_state['ws_hole_diameter']={16.:18.,20.:22.,24.:26.,30.:33.}[st.session_state.ws_db]


def profile_changed():
    p=P.get(st.session_state.ws_profile_name)
    if p:
        value=max(0.,(p.d-2*p.tf-p.clear)/2)
        st.session_state['ws_root_radius']=value
        st.session_state['ws_root_suggestion']=f'Perfil de catálogo selecionado: envelope de raiz sugerido = {value:g} mm. Confirme com o fornecimento real.'
    elif '_w_splice_custom_draft' in st.session_state:
        _restore_custom_draft(st.session_state['_w_splice_custom_draft'])
        st.session_state.pop('ws_root_suggestion',None)


def render():
    from .w_splice_drawing import image_bytes,drawing_svg
    from .w_splice_report import create_report,GROUP_LABELS,MECHANISMS
    if 'ws_project' not in st.session_state:
        saved=st.session_state.get('_w_splice_project')
        seed(WSplice.from_dict(saved) if saved else next(iter(PRESETS.values())))
    # Preserve conditionally hidden scalar widgets, never uploader/button state.
    preserve=['ws_'+f.name for f in fields(WSplice) if f.name!='profile']+['ws_compression_kgf','ws_manual_name','ws_profile_source']+['ws_profile_'+k for k in ('d','bf','tw','tf','clear','area','mass')]
    for key in preserve:
        if key in st.session_state:st.session_state[key]=st.session_state[key]
    with st.sidebar:
        st.caption('Versão '+VERSION+' · emenda W M004')
        st.selectbox('Exemplo de emenda W',list(PRESETS),key='ws_example')
        st.button('Usar exemplo de emenda W',on_click=use_example,use_container_width=True)
        st.file_uploader('Abrir projeto de emenda W',type=['json'],key='ws_upload')
        st.button('Carregar emenda W',on_click=load_project,use_container_width=True)
        if 'ws_import_error' in st.session_state:st.error(st.session_state.ws_import_error)
        st.divider();st.caption(BRAND);st.link_button('LinkedIn · Lucas Oliveira',LINK)
    st.title('Emenda de perfil W')
    st.caption('M004 balanceado · 8 talas · primeiro domínio: tração axial concêntrica')
    st.info('M, V, torção e compressão ainda não são avaliados nesta família. O modelo geral N/M/V permanece separado, sem aprovação por este cálculo.')
    st.text_input('Identificação do projeto',key='ws_project')
    left,right=st.columns([.85,1.5],gap='large')
    with left:
        name=st.selectbox('Mesmo perfil W nos dois lados',['W personalizado']+list(P),key='ws_profile_name',on_change=profile_changed)
        if name in P:p=P[name]
        else:
            with st.expander('Geometria do W personalizado',expanded=True):
                label=st.text_input('Designação do perfil',key='ws_manual_name')
                vals={}
                for key,text in [('d','Altura d (mm)'),('bf','Largura bf (mm)'),('tw','Alma tw (mm)'),('tf','Mesa tf (mm)'),('clear','Altura livre de raízes (mm)'),('area','Área do perfil A (mm²)'),('mass','Massa linear (kg/m)')]:
                    vals[key]=st.number_input(text,min_value=.01,key='ws_profile_'+key)
                source=st.text_input('Fonte das dimensões/área',key='ws_profile_source')
                p=Profile(label,'W',source=source,**vals)
        st.caption(f'd={p.d:g}; bf={p.bf:g}; tw={p.tw:g}; tf={p.tf:g} mm; A={p.area:g} mm². Dois membros idênticos.')
        st.number_input('Tração Nsd já majorada (kgf)',key='ws_N_kgf',format='%.2f')
        load_convention_slot = st.empty()
        with st.expander('Ações adicionais: fora do primeiro domínio'):
            st.number_input('Momento M (kgf·m)',key='ws_M_kgfm',format='%.2f')
            st.number_input('Cortante V (kgf)',key='ws_V_kgf',format='%.2f')
            st.number_input('Torção T (kgf·m)',key='ws_torsion_kgfm',format='%.2f')
            st.caption('Qualquer valor não nulo bloqueia o cálculo de tração. Nunca é descartado silenciosamente.')
        with st.expander('Talas e parafusos das mesas',expanded=True):
            for key,text in [('flange_outer_width','Largura da tala externa bo'),('flange_inner_width','Largura de cada tira interna bi'),('inner_clear_band','Faixa central livre c'),('flange_t','Espessura única das 6 talas de mesa')]:
                st.number_input(text+' (mm)',min_value=.1,key='ws_'+key)
            st.caption('Balanceamento obrigatório: bo=2bi. Mesma espessura, aço e comprimento. Duas colunas por mesa; cada tira interna contém uma coluna.')
            st.number_input('Linhas longitudinais por lado da mesa',min_value=2,max_value=6,key='ws_flange_rows')
            for key,text in [('flange_pitch','Passo longitudinal da mesa'),('flange_member_end','Borda no perfil à primeira linha'),('flange_cover_end','Borda da tala à última linha')]:
                st.number_input(text+' (mm)',min_value=.1,key='ws_'+key)
        with st.expander('Duas talas e parafusos da alma'):
            for key,text in [('web_height','Altura de cada tala da alma'),('web_t','Espessura de cada tala da alma'),('web_pitch','Passo longitudinal da alma'),('web_gauge','Passo vertical da alma'),('web_member_end','Borda na alma do perfil'),('web_cover_end','Borda longitudinal da tala da alma')]:
                st.number_input(text+' (mm)',min_value=.1,key='ws_'+key)
            st.caption('Malha inicial fixa: 2 linhas longitudinais × 3 níveis verticais em cada lado, 12 parafusos na alma.')
        with st.expander('Furação, montagem e folgas'):
            st.selectbox('Diâmetro métrico do parafuso (mm)',[16.,20.,24.,30.],key='ws_db',on_change=bolt_changed)
            st.selectbox('Classe do parafuso',['ASTM F3125 A325','ASTM F3125 A490'],key='ws_bolt')
            st.number_input('Diâmetro efetivo do furo circular (mm)',min_value=.1,key='ws_hole_diameter')
            st.checkbox('Furo de broca documentado: sem acréscimo de 2 mm na dedução',key='ws_drilled')
            st.checkbox('Rosca excluída dos dois planos de corte e documentada',key='ws_threads_excluded_verified')
            for key,text in [('gap','Folga entre os dois perfis'),('root_radius','Envelope radial adotado para a raiz do perfil'),('fabrication_clearance','Folga adicional de fabricação'),('tool_radius','Raio livre requerido da ferramenta')]:
                st.number_input(text+' (mm)',min_value=0. if key!='tool_radius' else .1,key='ws_'+key)
            if 'ws_root_suggestion' in st.session_state:st.caption(st.session_state.ws_root_suggestion)
            st.caption('Dedução líquida: diâmetro máximo da Tabela 14, mais 2 mm quando aplicável; contato usa o furo físico informado.')
            st.caption('O envelope de raiz padrão é conservador, não um raio oficial de catálogo. Raiz e ferramenta devem corresponder ao fornecimento real. Folga de 10 mm do desenho industrial é preset; colisão física é bloqueio independente.')
        with st.expander('Materiais, ações mínimas e domínio'):
            st.selectbox('Aço do W',[k for k,s in STEELS.items() if s.rolled_allowed],key='ws_member_steel')
            for key,text in [('flange_steel','Aço das talas de mesa'),('web_steel','Aço das talas de alma')]:
                st.selectbox(text,[k for k,s in STEELS.items() if s.plate_allowed],key='ws_'+key)
            st.selectbox('Exposição',['painted','weathering'],format_func=lambda x:'Pintado / protegido' if x=='painted' else 'Aço patinável exposto',key='ws_exposure')
            policy=st.selectbox('Recomendação de resistência do membro · 6.1.5.3',['tension_strength','slenderness','engineer_waived'],
                format_func=lambda x:{'tension_strength':'Adotar · resistência à tração governa (50%)','slenderness':'Adotar · esbeltez governa (100% Nc,Rd externo)','engineer_waived':'Não adotar · decisão registrada do responsável técnico'}[x],key='ws_minimum_action_policy')
            if policy=='slenderness':
                st.number_input('Nc,Rd verificado do membro (kgf)',min_value=0.,key='ws_compression_kgf')
                st.text_input('Fonte/referência do Nc,Rd externo',key='ws_compression_reference')
            st.caption('O piso de 45 kN é aplicado ao conjunto. A recomendação de 50% fica a critério do responsável técnico; o N real permanece disponível. O alvo de tração usa 50% Ag fy/γa1 conservadoramente.')
            st.checkbox('Ações estáticas, sem fadiga ou inversão de tensões',key='ws_static')
            st.checkbox('Combinações últimas normais',key='ws_normal_combination')
            st.checkbox('Nsd inclui ações de integridade aplicáveis ao sistema',key='ws_integrity_included')
            st.checkbox('Membros coaxiais e força axial concêntrica',key='ws_concentric')
            st.checkbox('Projeto exige resistência ao deslizamento',key='ws_no_slip_required')
        st.text_area('Observações e decisão do responsável técnico',key='ws_notes')
    skip={'profile','N','M','V','torsion','compression_resistance'}
    values={f.name:st.session_state['ws_'+f.name] for f in fields(WSplice) if f.name not in skip}
    c=WSplice(p,N=st.session_state.ws_N_kgf*KGF,M=st.session_state.ws_M_kgfm*KGF*1000,V=st.session_state.ws_V_kgf*KGF,
              torsion=st.session_state.ws_torsion_kgfm*KGF*1000,compression_resistance=st.session_state.ws_compression_kgf*KGF,**values)
    encoded=json.dumps(c.to_dict(),ensure_ascii=False,indent=2);digest=hashlib.sha256(encoded.encode()).hexdigest()
    st.session_state['_w_splice_project']=c.to_dict()
    if name=='W personalizado':st.session_state['_w_splice_custom_draft']={'profile':asdict(p),'root_radius':c.root_radius}
    if st.session_state.get('ws_report',('','',b''))[0]!=digest:st.session_state.pop('ws_report',None)
    with load_convention_slot.container():
        render_load_convention(st, 'w_splice_m004', c.N)
    r=evaluate(c);st.session_state['_w_splice_result']=r
    with right:
        status=STATUS.get(r['status'],r['status'])
        if r['status'] in ('INVALID_INPUT','INVALID_GEOMETRY','NUMERICAL_FAILURE','VERIFIED_SUBCHECK_FAIL','DETAIL_FAIL'):st.error(status)
        elif r['status']=='COMPLETE_CHECKS_PASS_WITHIN_SCOPE':st.success(status)
        else:st.warning(status)
        if r.get('summary'):
            summary=r['summary'];load=r['load_model'];a,b=st.columns(2)
            a.metric('Índice com N real',number(summary['actual_governing_utilization'],3))
            b.metric('Índice com ação adotada',number(summary['governing_utilization'],3))
            st.caption(f'Nsd={number(c.N/KGF,1)} kgf; Nd adotado={number(load["Nd_N"]/KGF,1)} kgf. Governa: '+summary['governing_label'])
            sources={'actual_N':'ação real informada','mandatory_45kN_floor':'piso obrigatório de 45 kN',
                     'selected_member_recommendation':'recomendação do membro selecionada pelo responsável técnico'}
            source=load.get('adopted_action_source','')
            st.caption('Origem de Nd: '+sources.get(source,load['minimum_note']))
            if not load.get('adopted_action_complete',True):
                basis=('N real e piso obrigatório de 45 kN' if load.get('member_recommendation_N') is None
                       else 'a ação adotada indicada acima')
                st.warning('Índices calculados com '+basis+'. Há pendência na recomendação suplementar ou em sua justificativa/fonte; não há aprovação global.')
        if r.get('geometry',{}).get('valid'):
            st.image(image_bytes(c,r),width='stretch')
        for issue in r['issues']:
            text=issue['text']
            if issue['severity'] in ('invalid_input','invalid_geometry','numerical_failure','detail_fail'):st.error(text)
            elif issue['severity'] in ('unsupported_scope','engineering_pending','access_pending','preset_deviation','warning'):st.warning(text)
            else:st.caption(text)
        if r.get('load_model'):
            load=r['load_model']
            with st.expander('Partilha e equilíbrio do W'):
                st.write('N da alma = '+number(load['web_force_N']/KGF,1)+' kgf; N de cada mesa = '+number(load['each_flange_force_N']/KGF,1)+' kgf.')
                st.write('Cada tala externa: '+number(load['each_outer_force_N']/KGF,1)+' kgf; cada tira interna: '+number(load['each_inner_force_N']/KGF,1)+' kgf; cada tala de alma: '+number(load['each_web_cover_force_N']/KGF,1)+' kgf.')
                st.caption(load['allocation']);st.caption(load['minimum_note'])
        st.caption(SCOPE)
    if r['checks']:
        def row(x):
            return {'ID governante':x['id'],'Componente':x['component'],'Verificação':x['label'],
                    'Solicitação real (kgf)':x['actual_demand_N']/KGF,'Solicitação adotada (kgf)':x['demand_N']/KGF,
                    'Resistência (kgf)':x['design_capacity_N']/KGF,'Índice real':x['actual_utilization'],
                    'Índice adotado':x['utilization'],'Resultado':x['status']}
        st.subheader('Envoltórias por componente e mecanismo')
        groups=r.get('check_groups',[])
        if groups:
            rows=[]
            for g in groups:
                x=g['governing']
                rows.append({'Componente / mecanismo':GROUP_LABELS[g['component_class']]+' · '+MECHANISMS[g['mechanism']],
                             **{k:v for k,v in row(x).items() if k not in ('Componente','Verificação')}})
            st.dataframe(pd.DataFrame(rows),hide_index=True,width='stretch')
            st.caption('Cada linha preserva a verificação primitiva governante do grupo; resistências de peças em série não são somadas.')
        with st.expander(f'Todas as verificações detalhadas · {len(r["checks"])} linhas'):
            st.dataframe(pd.DataFrame([row(x) for x in r['checks']]),hide_index=True,width='stretch')
            st.json({'fixed_assumptions':c.fixed_assumptions,
                     **{key:r[key] for key in ('geometry','physical_regions','physical_covers','bolts','whole_member') if key in r}},expanded=False)
            st.json(groups,expanded=False)
            st.json(r['checks'],expanded=False)
    a,b,d=st.columns(3)
    a.download_button('Salvar projeto de emenda W .json',encoded,'emenda_W_M004.json','application/json')
    if r.get('geometry',{}).get('valid'):
        b.download_button('Baixar desenho da emenda W .svg',drawing_svg(c,r),'emenda_W_M004.svg','image/svg+xml')
    if not r['checks']:st.caption('Memória diagnóstica disponível: registra entradas e impedimentos, sem aprovação global da emenda.')
    if d.button('Gerar memória de emenda W',use_container_width=True):
        st.session_state.ws_report=(digest,'memoria_emenda_W_M004.docx',create_report(c,r))
    if 'ws_report' in st.session_state:
        _,fname,payload=st.session_state.ws_report
        st.download_button('Baixar memória de emenda W .docx',payload,fname,'application/vnd.openxmlformats-officedocument.wordprocessingml.document')
