"""Producer-identified equal-leg angles; geometric data never imply steel grade.

The authoritative extraction retains printed decimals and explicit missing data.
Runtime floats are converted from those exact strings only, not inch labels.
"""
from copy import deepcopy
from functools import lru_cache
import json
from pathlib import Path

LEGACY_ARCELOR_ID = 'L100x100x12'

@lru_cache(maxsize=1)
def _source():
    return json.loads((Path(__file__).resolve().parent.parent / 'data' /
                       'gerdau_equal_angles.json').read_text(encoding='utf-8'))


def provenance():
    return deepcopy(_source()['source'])


def catalog(include_legacy=False, include_incomplete=False):
    """Return fresh mappings keyed by permanent producer/page/row identity."""
    result = {}
    for row in _source()['rows']:
        if not include_incomplete and not row['section_properties_published']:
            continue
        raw = row['normalized_decimal']
        def number(field):
            return None if raw[field] is None else float(raw[field])
        result[row['id']] = dict(
            id=row['id'], name=row['designation_mm'], manufacturer='Gerdau',
            leg=number('leg_mm'), t=number('thickness_mm'), Ag=number('Ag_mm2'),
            centroid=number('centroid_x_mm'), root_radius=None, toe_radius=None,
            toe_flat=None, mass=number('mass_kg_m'),
            source='Gerdau · Barras-e-Perfis-Tabela-de-bolso-Gerdau.pdf · página física 3 · linha '+str(row['source_row']),
            source_row=row['source_row'], source_page=row['source_page'],
            source_sha256=_source()['source']['sha256'],
            source_filename=_source()['source']['filename'],
            source_raw=deepcopy(row['source_raw']), normalized_decimal=deepcopy(raw),
            section_properties_published=row['section_properties_published'],
            review_flags=([] if row['source_row'] == 46 else deepcopy(row['review_flags'])),
            property_selection_criterion=('Ag resistente = 26,96 cm² publicada, menor que a área inferida da massa; massa publicada 23,52 kg/m mantida separada, sem geração automática de peso próprio.' if row['source_row'] == 46 else ''),
            missing_fields=([key for key in ('Ag','centroid') if number({'Ag':'Ag_mm2','centroid':'centroid_x_mm'}[key]) is None]
                            + ['root_radius','toe_radius','toe_flat']))
    if include_legacy:
        result[LEGACY_ARCELOR_ID] = dict(
            id=LEGACY_ARCELOR_ID, name='L100x100x12', manufacturer='ArcelorMittal',
            leg=100., t=12., Ag=2270., centroid=29., root_radius=12.,
            toe_radius=6., toe_flat=6.,
            source='https://orangebook.arcelormittal.com/node/220',
            section_properties_published=True, missing_fields=[], review_flags=[])
    return result


def get_angle(identity):
    """Return the exact identity or None. Never substitute a nearest section."""
    return catalog(include_legacy=True).get(identity)


def label(identity):
    section = get_angle(identity)
    if section is None:
        return str(identity)+' · não reconhecido'
    suffix = ' · Ag/ec não publicados' if not section['section_properties_published'] else ''
    if section['manufacturer'] == 'ArcelorMittal': suffix += ' · legado'
    return section['manufacturer']+' · '+section['name'].replace('x','×')+suffix
