"""Conventional four/eight-cover W splice, all N/M in flanges and V/Ve in web.

Separate serialized force model: never changes the established axial M004 model.
N, mm, MPa internally. Signed load cases, two serial ends, individual pieces.
Basis: Fakury pp.310–320 plus current NBR 8800:2024, corrected 2025.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict, fields, replace
from copy import deepcopy
import hashlib
import json
import math
from .models import Profile, profiles, STEELS, BOLTS, finite_real
from .w_splice import WSplice, geometry, block_paths, _safe, NBR, GAMMA_A1, GAMMA_A2, TOL

FAMILY = 'Emenda W · convencional · N/M/V'
CONNECTION_TYPE = 'w_splice_conventional_nmv'
LEGACY_COMPONENT_VERSION = '0.9.5-w-conventional-dev'
PREVIOUS_COMPONENT_VERSION = '0.9.6-w-inner-option-dev'
COMPONENT_VERSION = '0.9.7-w-slip-service-dev'
SLIP_FIELDS = {'slip_action_basis','slip_surface_class','slip_service_N','slip_service_M','slip_service_V'}
LEGACY_QUALIFICATION_VERSION = 'regular_2x3_symmetric_eight_cover_parametric_v1'
QUALIFICATION_VERSION = 'regular_2x3_optional_inner_flange_covers_v2'
E, G = 200000., 77000.
SCOPE = ('Emenda de W idênticos e coaxiais, 4 ou 8 talas separadas e malha regular 2×3 na alma; '
         'N e M integralmente nas mesas, V e excentricidade real nas duas talas de alma. '
         'Ações últimas estáticas com sinais; sem crédito de contato entre pontas.')
DETAIL_CONDITIONS = [
    'Dois membros completos, alinhados e apoiados; nenhuma fase de montagem isolada é verificada.',
    'Talas planas em contato firme nos trechos sobrepostos, sem calços, frestas de apoio ou peças ausentes.',
    'Todos os parafusos estruturais, porcas e arruelas instalados; as linhas completas mantêm apoio lateral e à torção das talas.',
    'Contenções laterais e torsionais dos membros especificadas no projeto estrutural; não fornecidas pelo simples desenho da emenda.',
    'Talas independentes: K=1 e vão máximo entre linhas portantes; nenhuma seção-caixão composta entre talas.',
]
EXCLUSIONS = [
    'Sem torção, flexão no eixo menor, fadiga, impacto, qualificação sísmica ou crédito de contato entre pontas.',
    'Estabilidade global dos membros e análise do sistema são externas; capacidades fornecidas são identificadas e vinculadas aos dados.',
    'Contato em ELU não certifica deslizamento, rigidez, continuidade de pórtico, deformação de serviço ou estabilidade de montagem.',
    'Sem recortes, rasgos, furos escalonados, talas desiguais ou parcela independente de N/M na alma.',
]

OUTER_ONLY_METHOD = (
    'Idealização convencional de resistência estática: W completos e coaxiais, mesas e alma intactas, '
    'talas externas simétricas nas duas mesas e duas talas de alma, pares simétricos de parafusos em '
    'pelo menos duas estações de cada lado, contato firme e todos os parafusos instalados. A restrição '
    'mesa–alma do membro limita a flexão secundária da emenda. O deslocamento real e=(tf+t)/2 é registrado; '
    'o braço nominal h0=d−tf não prova equilíbrio de chapas externas livres. Sem calços/frestas, '
    'peças destacadas, parafusos ausentes, montagem incompleta, torção, eixo menor ou fadiga.'
)
OUTER_ONLY_SOURCE = ('Fakury §10.14.7, pp.311–320; Kulak/Fisher/Struik, Guide to Design Criteria '
                     'for Bolted and Riveted Joints, 2nd ed., §§8.1–8.3.1 pp.171–175, §16.3 p.261; '
                     'https://www.boltcouncil.org/files/2ndEditionGuide.pdf; resistências NBR atuais')


@dataclass(frozen=True)
class WConventional(WSplice):
    slip_action_basis: str = 'pending'
    slip_surface_class: str = 'pending'
    slip_service_N: float = 0.
    slip_service_M: float = 0.
    slip_service_V: float = 0.
    project: str = 'Emenda W convencional · N/M/V'
    include_inner_flange_plates: bool = True
    flange_bolt_gauge: float | None = None
    N: float = -600000.
    M: float = 120000000.
    V: float = 100000.
    minimum_action_policy: str = 'pending'
    minimum_N: float = 0.
    minimum_M: float = 0.
    minimum_V: float = 0.
    minimum_reference: str = ''
    assembly_detail: str = 'complete_row_supported_detail_v1'
    member_capacity_reference: str = ''
    member_Nc_Rd: float = 0.
    member_Nt_Rd: float = 0.
    member_M_Rd: float = 0.
    member_V_Rd: float = 0.
    member_capacity_binding: str = ''

    @property
    def legacy_fixed_assumptions(self):
        return {'force_model': CONNECTION_TYPE, 'qualification': LEGACY_QUALIFICATION_VERSION,
                'topology':'two_outer_four_inner_two_web_covers',
                'N_M_allocation':'Ftop=N/2−M/(d−tf); Fbottom=N/2+M/(d−tf); Nw=Mw0=0',
                'web_allocation':'V/2 per cover, complete bolt vectors include actual Ve',
                'web_grid':[2,3], 'flange_fraction_outer':.5, 'flange_fraction_each_inner':.25,
                'ends':'series_never_add', 'no_end_bearing_credit':True,
                'shear_planes_per_bolt':2, 'compression_K':1.,
                'restraint_detail_conditions':DETAIL_CONDITIONS.copy(),
                'gamma_a1':GAMMA_A1, 'gamma_a2':GAMMA_A2,
                'hole_deduction':'Table14 maximum +2 mm unless drilled documented',
                'web_block':'84 real-edge L/U prefixes; Cts=.5; full |V|/2 each',
                'cover_net_additional_screen':'|Vcover|/VRd+|Menv|/MRd,net≤1, additional conservative screen',
                'minimum_actions':'separate signed resultant45kN floor cases; discretionary member recommendation policy; never change actual N/M/V',
                'whole_member_Ct':'not asserted; all normal force local flange path'}

    @property
    def fixed_assumptions(self):
        assumptions=self.legacy_fixed_assumptions
        assumptions.update(qualification=QUALIFICATION_VERSION,
                           flange_shear_planes_per_bolt=2 if self.include_inner_flange_plates else 1,
                           web_shear_planes_per_bolt=2,
                           topology_method='optional_inner_flange_covers_v2',
                           nominal_force_arm='d−tf; nominal conventional allocation, not free-cover centroid equilibrium')
        if not self.include_inner_flange_plates:
            assumptions.pop('shear_planes_per_bolt')
            assumptions.pop('flange_fraction_each_inner')
            assumptions.update(topology='two_outer_two_web_covers',flange_fraction_outer=1.,
                               secondary_bending_idealization=OUTER_ONLY_METHOD,
                               secondary_bending_source=OUTER_ONLY_SOURCE)
        return assumptions

    def to_dict(self):
        errors=input_errors(self)
        if errors:raise ValueError('; '.join(errors))
        return {'schema_version':3,'connection_type':CONNECTION_TYPE,'component_version':COMPONENT_VERSION,
                'connection':active_engineering_payload(self),'units':{'force':'N','length':'mm','stress':'MPa','moment':'N mm'},
                'fixed_assumptions':self.fixed_assumptions}

    @classmethod
    def from_dict(cls,data):
        keys={'schema_version','connection_type','component_version','connection','units','fixed_assumptions'}
        if not isinstance(data,dict) or set(data)!=keys:raise ValueError('Projeto convencional: campos ausentes ou desconhecidos.')
        if data['connection_type']!=CONNECTION_TYPE or type(data['schema_version']) is not int:
            raise ValueError('Família ou modelo de forças convencional incompatível; sem conversão entre famílias.')
        legacy=data['schema_version']==1 and data['component_version']==LEGACY_COMPONENT_VERSION
        previous=data['schema_version']==2 and data['component_version']==PREVIOUS_COMPONENT_VERSION
        if not legacy and not previous and not (data['schema_version']==3 and data['component_version']==COMPONENT_VERSION):
            raise ValueError('Versão convencional incompatível; apenas migração explícita do esquema legado conhecido.')
        raw=data['connection']
        if not isinstance(raw,dict):raise ValueError('Dados convencionais incompletos ou desconhecidos.')
        known={f.name for f in fields(cls)}
        if legacy or previous:known-=SLIP_FIELDS
        elif raw.get('no_slip_required') is False:known-=SLIP_FIELDS
        if legacy:
            expected=known-{'include_inner_flange_plates','flange_bolt_gauge'}
        else:
            if type(raw.get('include_inner_flange_plates')) is not bool:raise ValueError('include_inner_flange_plates: booleano explícito obrigatório.')
            expected=known-({'flange_bolt_gauge'} if raw['include_inner_flange_plates'] else {'flange_inner_width','inner_clear_band'})
        if set(raw)!=expected:raise ValueError('Dados convencionais ativos incompletos ou desconhecidos.')
        raw=dict(raw);p=raw['profile']
        if not isinstance(p,dict) or set(p)!={f.name for f in fields(Profile)}:raise ValueError('Perfil incompleto.')
        raw['profile']=Profile(**p)
        c=cls(**raw)
        errors=input_errors(c)
        if errors:raise ValueError('; '.join(errors))
        if data['units']!={'force':'N','length':'mm','stress':'MPa','moment':'N mm'}:
            raise ValueError('units: unidade incompatível.')
        if not _same_contract(data['fixed_assumptions'],c.legacy_fixed_assumptions if legacy else c.fixed_assumptions):
            raise ValueError('fixed_assumptions: premissa incompatível.')
        # Validate the complete old schema before supplying any new field.
        # Preserve old binding bytes; never silently rebind an external basis.
        if legacy:c=replace(c,include_inner_flange_plates=True,flange_bolt_gauge=c.flange_inner_width+c.inner_clear_band)
        return c


def _same_contract(actual,expected):
    """Assumptions are a typed schema: bool, int and float are not substitutes."""
    if type(actual) is not type(expected):return False
    if isinstance(expected,dict):
        return actual.keys()==expected.keys() and all(_same_contract(actual[k],v) for k,v in expected.items())
    if isinstance(expected,list):
        return len(actual)==len(expected) and all(_same_contract(a,b) for a,b in zip(actual,expected))
    return actual==expected


def active_engineering_payload(c):
    """The single calculation/artifact/binding payload; dormant UI drafts do not enter it."""
    data=asdict(c)
    if not c.no_slip_required:
        for name in SLIP_FIELDS:data.pop(name)
    if c.include_inner_flange_plates:
        data.pop('flange_bolt_gauge')
    else:
        data.pop('flange_inner_width');data.pop('inner_clear_band')
    return data


def input_digest(c):
    data=active_engineering_payload(c) if isinstance(c,WConventional) else c
    return hashlib.sha256(json.dumps(_safe(data),sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def _binding(data):
    for key in ('project','notes','member_capacity_binding'):data.pop(key,None)
    return hashlib.sha256(json.dumps(data,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def capacity_binding(c):
    return _binding(active_engineering_payload(c))


def legacy_capacity_binding(c):
    """Exact schema-1 balanced input compatibility, unavailable in outer-only mode."""
    if c.include_inner_flange_plates is not True:return None
    data=asdict(c)
    data.pop('include_inner_flange_plates');data.pop('flange_bolt_gauge')
    for name in SLIP_FIELDS:data.pop(name)
    return _binding(data)


def input_errors(c):
    if not isinstance(c,WConventional):return ['A entrada deve ser WConventional; modelo axial antigo não é convertido.']
    strings={'project','member_steel','flange_steel','web_steel','bolt','exposure','notes','minimum_action_policy',
             'compression_reference','minimum_reference','assembly_detail','member_capacity_reference','member_capacity_binding','slip_action_basis','slip_surface_class'}
    bools={'include_inner_flange_plates','drilled','threads_excluded_verified','static','normal_combination','concentric','no_slip_required','integrity_included'}
    ints={'flange_rows','web_rows','web_levels'}
    signed={'N','M','V','torsion','minimum_N','minimum_M','minimum_V','slip_service_N','slip_service_M','slip_service_V'}
    nonnegative={'gap','root_radius','fabrication_clearance','compression_resistance','member_Nc_Rd','member_Nt_Rd','member_M_Rd','member_V_Rd'}
    errors=[]
    for f in fields(c):
        v=getattr(c,f.name);k=f.name
        if k=='profile':continue
        if not c.no_slip_required and k in SLIP_FIELDS:continue
        if c.include_inner_flange_plates is True and k=='flange_bolt_gauge':continue
        if c.include_inner_flange_plates is False and k in ('flange_inner_width','inner_clear_band'):continue
        if k in strings:
            if not isinstance(v,str):errors.append(k+': texto obrigatório.')
        elif k in bools:
            if type(v) is not bool:errors.append(k+': booleano explícito obrigatório.')
        elif k in ints:
            if type(v) is not int or not 1<=v<=20:errors.append(k+': inteiro entre 1 e 20 obrigatório.')
        elif not finite_real(v):errors.append(k+': número finito obrigatório.')
        elif k not in signed and (v<0 if k in nonnegative else v<=0):errors.append(k+': dimensão/resistência inválida.')
    p=c.profile
    if not isinstance(p,Profile):errors.append('Perfil documentado obrigatório.')
    else:
        for k in ('d','bf','tw','tf','clear','area','mass'):
            if not finite_real(getattr(p,k)) or getattr(p,k)<=0:errors.append('profile.'+k+': positivo finito obrigatório.')
        for k in ('name','family','source'):
            if not isinstance(getattr(p,k),str):errors.append('profile.'+k+': texto obrigatório.')
    if c.no_slip_required:
        if c.slip_action_basis not in ('pending','rare_service','normal_uls_70'):errors.append('Base de ações de deslizamento desconhecida.')
        if c.slip_surface_class not in ('pending','A','B','C','galvanized'):errors.append('Classe de superfície de atrito desconhecida.')
    if c.minimum_action_policy not in ('pending','provided_envelope','actual_actions_engineer_choice'):errors.append('Política mínima convencional desconhecida.')
    if c.assembly_detail not in ('complete_row_supported_detail_v1','unsupported_detail'):errors.append('Detalhe de apoio convencional desconhecido.')
    if c.compression_resistance!=0 or c.compression_reference:errors.append('Campos axiais legados não são capacidades globais convencionais; usar member_Nc_Rd e referência própria.')
    return errors


def presets():
    c=WConventional(profiles()['W 310 x 97,0 (H)'])
    return {'W 310 × 97 · compressão/M/V':c,
            'W 310 × 97 · momento puro':replace(c,project='Momento puro convencional',N=0.,M=120e6,V=0.),
            'W 310 × 97 · compressão pura':replace(c,project='Compressão pura convencional',N=-600e3,M=0.,V=0.),
            'W 310 × 97 · falha resistente':replace(c,project='Falha de bloco convencional',N=0.,M=0.,V=175e3)}


def issue(out,severity,text,reference='',**details):
    categories={'invalid_input':'INVALID_INPUT','invalid_geometry':'PHYSICAL_GEOMETRY',
                'numerical_failure':'NUMERICAL_FAILURE','detail_fail':'DETAILING_FAILURE',
                'unsupported_scope':'METHOD_DOMAIN','engineering_pending':'LOCAL_PREREQUISITE',
                'access_pending':'LOCAL_PREREQUISITE','service_pending':'SERVICE_GAP','service_failure':'SERVICE_FAILURE',
                'external_pending':'GLOBAL_EXTERNAL_GAP','external_scope':'GLOBAL_EXCLUDED',
                'not_evaluated':'NOT_APPLICABLE'}
    out['issues'].append(dict(severity=severity,category=categories.get(severity,'INFORMATION'),text=text,reference=reference,**details))


def check(out,identifier,label,component,demand,capacity,units,formula,reference,**details):
    if not finite_real(demand) or demand<0 or not finite_real(capacity) or capacity<=0:
        raise ArithmeticError(identifier+': ação não negativa e resistência positiva finitas obrigatórias.')
    ratio=demand/capacity
    if not finite_real(ratio):raise ArithmeticError(identifier+': índice fora da faixa numérica finita.')
    row=dict(id=identifier,label=label,component=component,demand=demand,capacity=capacity,units=units,
             utilization=ratio,status='NOT_APPLICABLE' if demand==0 else 'PASS' if demand<=capacity*(1+TOL) else 'FAIL',
             category='INACTIVE' if demand==0 else 'FINITE_RESISTANCE',
             formula=formula,reference=reference,details=details)
    if units=='N':row.update(demand_N=demand,design_capacity_N=capacity)
    if units=='N mm':row.update(demand_Nmm=demand,design_capacity_Nmm=capacity)
    out['checks'].append(row)
    return row


def net_rectangle(height,thickness,dn,levels):
    """Integrate actual retained intervals, including the central-axis hole."""
    last=-height/2;intervals=[]
    for y in sorted(levels):
        if y-dn/2<last-TOL or y+dn/2>height/2+TOL:raise ArithmeticError('Furos líquidos fora da seção ou sobrepostos.')
        intervals.append([last,y-dn/2]);last=y+dn/2
    intervals.append([last,height/2])
    A=sum(thickness*(b-a) for a,b in intervals)
    I=sum(thickness*(b**3-a**3)/3 for a,b in intervals)
    Z=sum(thickness*(b*abs(b)-a*abs(a))/2 for a,b in intervals)
    return dict(Ag_mm2=height*thickness,An_mm2=A,Ig_mm4=thickness*height**3/12,In_mm4=I,
                Zg_mm3=thickness*height**2/4,Znet_mm3=Z,Wg_mm3=thickness*height**2/6,
                Wnet_mm3=I/(height/2),retained_intervals_mm=intervals)


def effective_width(b,t,fy,chi,kind):
    limit=(1.4 if kind=='AA' else .56)*math.sqrt(E/fy)
    c1,c2=(.18,1.31) if kind=='AA' else (.22,1.49)
    ratio=b/t
    sigma=(c2*limit/ratio)**2*fy if b else 0.
    be=b if ratio<=limit/math.sqrt(chi) else b*(1-c1*math.sqrt(sigma/(chi*fy)))*math.sqrt(sigma/(chi*fy))
    return dict(kind=kind,b_mm=b,t_mm=t,ratio=ratio,limit=limit,effective_limit=limit/math.sqrt(chi),
                beff_mm=min(b,max(0.,be)),sigma_el_MPa=sigma,c1=c1,c2=c2)


def compression_strip(b,t,Le,fy,local_widths=None):
    """Independent rectangular bar axes/torsion; no composite-cover inertia."""
    A=b*t;Iw=b*t**3/12;Is=t*b**3/12;r0sq=(b*b+t*t)/12
    # Full Saint-Venant rectangle series, negative correction. Both dimensions
    # can vary without using the thin-strip approximation for compression.
    wide,thin=max(b,t),min(b,t)
    odds=sum(math.tanh(n*math.pi*wide/(2*thin))/n**5 for n in range(1,1000,2))
    J=wide*thin**3/3*(1-192*thin/(math.pi**5*wide)*odds)
    Ne_w=math.pi**2*E*Iw/Le**2;Ne_s=math.pi**2*E*Is/Le**2;Ne_z=G*J/r0sq
    Ne=min(Ne_w,Ne_s,Ne_z);lam=math.sqrt(A*fy/Ne);chi=.658**(lam*lam) if lam<=1.5 else .877/(lam*lam)
    slender=Le/(min(b,t)/math.sqrt(12))
    # Corrected 6.5.4 branches. Local reductions remain explicit in either
    # branch; stocky bar uses chi=1 only when its torsion bound exceeds squash.
    widths=[effective_width(w,t,fy,chi,kind) for kind,w in (local_widths or [('AL',b/2),('AL',b/2)])]
    stocky=slender<=25 and Ne_z>=A*fy and all(v['ratio']<=v['limit'] for v in widths)
    applied_chi=1. if stocky else chi
    Aeff=t*sum(v['beff_mm'] for v in widths)
    R=applied_chi*Aeff*fy/GAMMA_A1
    return dict(b_mm=b,t_mm=t,Le_mm=Le,K=1.,A_mm2=A,Aeff_mm2=Aeff,Le_over_r=slender,J_mm4=J,
                Ne_weak_N=Ne_w,Ne_strong_N=Ne_s,Ne_torsion_lower_N=Ne_z,Ne_min_N=Ne,
                lambda0=lam,chi=applied_chi,chi_5_3=chi,R_N=R,local_elements=widths,
                branch='6.5.4a_stocky' if stocky else '6.5.4b_and_5.3',torsion_above_squash=Ne_z>=A*fy,
                local_basis='Overlap widths only; bridge is separate finite row-supported rectangular bar, not backed AA plate.')


def web_ltb(h,t,Lb,fy):
    A=h*t;J=h*t**3/3;ry=t/math.sqrt(12);Z=t*h*h/4;W=t*h*h/6
    lam=Lb/ry;mp=fy*Z;mr=fy*W;lp=.13*E*math.sqrt(J*A)/mp;lr=2*E*math.sqrt(J*A)/mr
    if lam<=lp:R=mp/GAMMA_A1;branch='plastic'
    elif lam<=lr:R=(mp-(mp-mr)*(lam-lp)/(lr-lp))/GAMMA_A1;branch='inelastic_LTB'
    else:R=2*E*math.sqrt(J*A)/lam/GAMMA_A1;branch='elastic_LTB'
    return dict(lambda_=lam,lambda_p=lp,lambda_r=lr,MRd_Nmm=R,branch=branch,Cb=1.,Lb_mm=Lb,J_mm4=J,
                formula_basis='Annex D Table D.1 solid rectangular; J=ht³/3 source convention')


def mechanics(c,g,N,M,V):
    h0=c.profile.d-c.profile.tf;ft=N/2-M/h0;fb=N/2+M/h0
    a=c.web_pitch/2;b=c.gap/2+c.web_member_end;e=b+a;J=6*a*a+4*c.web_gauge**2
    groups=[];points=[]
    for side,s in [('left',-1),('right',1)]:
        C=-e*V;bolts=[]
        physical_x=sorted(s*x for x in g['web_x_mm'])
        for xi,xlocal in enumerate((-a,a)):
            for yi,y in enumerate(g['web_y_mm']):
                qx=-C*y/J;qy=s*V/6+C*xlocal/J;x=physical_x[xi]
                bolt=dict(column_index=xi+(0 if s<0 else 2),level_index=yi,x_local_mm=xlocal,x_mm=x,y_mm=y,qx_N=qx,qy_N=qy,resultant_N=math.hypot(qx,qy),
                          each_plane_qx_N=qx/2,each_plane_qy_N=qy/2,each_plane_resultant_N=math.hypot(qx,qy)/2)
                bolts.append(bolt);points.append((x,y,qx/2,qy/2))
        groups.append(dict(side=side,center_x_mm=s*e,Fx_N=0.,Fy_N=s*V,C_Nmm=C,J_mm2=J,bolts=bolts,
                           residual_Fx_N=sum(v['qx_N'] for v in bolts),residual_Fy_N=sum(v['qy_N'] for v in bolts)-s*V,
                           residual_C_Nmm=sum(v['x_local_mm']*v['qy_N']-v['y_mm']*v['qx_N'] for v in bolts)-C))
    cuts=[];stations=sorted({-g['web_length_mm']/2,g['web_length_mm']/2,0.,*[v[0] for v in points]})
    for x in stations:
        for inclusive in (False,True):
            ps=[v for v in points if v[0]<x or inclusive and v[0]==x]
            cuts.append(dict(x_mm=x,inclusive=inclusive,N_N=-sum(v[2] for v in ps),V_N=-sum(v[3] for v in ps),
                             M_Nmm=-sum((v[0]-x)*v[3]-v[1]*v[2] for v in ps)))
    xlast=max(g['flange_x_mm']+g['web_x_mm'])
    member_stations=sorted({-xlast,xlast,0.,*[-v for v in g['flange_x_mm']],*g['flange_x_mm'],*[-v for v in g['web_x_mm']],*g['web_x_mm']})
    load=dict(N_N=N,M_Nmm=M,V_N=V,h0_mm=h0,top_force_N=ft,bottom_force_N=fb,Nw_N=0.,Mw_splice_Nmm=0.,
                top_outer_force_N=ft/2,top_each_inner_force_N=ft/4,bottom_outer_force_N=fb/2,bottom_each_inner_force_N=fb/4,
                top_outer_centroid_y_mm=c.profile.d/2+c.flange_t/2,
                top_inner_centroid_y_mm=c.profile.d/2-c.profile.tf-c.flange_t/2,
                combined_top_flange_cover_centroid_y_mm=h0/2,
                balanced_cover_first_moment_residual_mm=(c.profile.d/2+c.flange_t/2)/2+(c.profile.d/2-c.profile.tf-c.flange_t/2)/2-h0/2,
                web_groups=groups,web_cut_records=cuts,web_group_moment_per_cover_Nmm=abs(V)*e/2,
                web_max_cut_moment_per_cover_Nmm=max(abs(v['M_Nmm']) for v in cuts),
                web_design_moment_envelope_per_cover_Nmm=max(abs(V)*e/2,max(abs(v['M_Nmm']) for v in cuts)),web_eccentricity_mm=e,
                web_max_complete_bolt_N=max(v['resultant_N'] for gr in groups for v in gr['bolts']),
                member_moment_envelope_Nmm=max(abs(M-V*x) for x in member_stations),
                member_stations=[dict(x_mm=x,M_Nmm=M-V*x,Ftop_N=N/2-(M-V*x)/h0,Fbottom_N=N/2+(M-V*x)/h0) for x in member_stations],
                member_envelope_basis='M(x)=M(0)−Vx through outermost flange/web row; conservatively assigned in full to member local checks.',
                residual_N_N=ft+fb-N,residual_M_Nmm=(fb-ft)*h0/2-M,
                cover_residual_Fx_N=sum(v[2] for v in points),cover_residual_Fy_N=sum(v[3] for v in points),
                cover_residual_M_Nmm=sum(v[0]*v[3]-v[1]*v[2] for v in points))
    if not c.include_inner_flange_plates:
        for key in ('top_each_inner_force_N','bottom_each_inner_force_N','top_inner_centroid_y_mm','balanced_cover_first_moment_residual_mm'):
            load.pop(key)
        offset=(c.profile.tf+c.flange_t)/2
        load.update(top_outer_force_N=ft,bottom_outer_force_N=fb,
                    combined_top_flange_cover_centroid_y_mm=c.profile.d/2+c.flange_t/2,
                    top_cover_centroid_offset_mm=offset,bottom_cover_centroid_offset_mm=-offset,
                    nominal_centroid_couple_discrepancy_Nmm=M*(c.profile.tf+c.flange_t)/h0,
                    equilibrium_residual_basis='Nominal conventional allocation at h0; not exact free outer-cover centroid equilibrium',
                    secondary_bending_idealization=OUTER_ONLY_METHOD,secondary_bending_source=OUTER_ONLY_SOURCE)
    return load


def web_paths(c,g,load):
    """All 84 complete-cover physical L/U source-family paths, not cut at x=0."""
    xs=sorted([-x for x in g['web_x_mm']]+g['web_x_mm']);dn=g['dn'];t=c.web_t;h=c.web_height
    bolts=[b for gr in load['web_groups'] for b in gr['bolts']];rows=[]
    for sy in (-1,1):
        for k in (1,2,3):
            levels=sorted(g['web_y_mm'],reverse=sy>0)[:k];ycut=levels[-1];yfree=sy*h/2
            Lv=abs(yfree-ycut);Ln=Lv-(k-.5)*dn;candidates=[]
            for i in range(4):
                for j in range(i+2,5):
                    cols=xs[i:j];candidates.append(('U',cols,2,cols[-1]-cols[0]-(len(cols)-1)*dn,None))
            for free in (-g['web_length_mm']/2,g['web_length_mm']/2):
                ordered=sorted(xs,reverse=free>0)
                for m in (1,2,3,4):
                    cols=ordered[:m];candidates.append(('L',cols,1,abs(cols[-1]-free)-(m-.5)*dn,free))
            for n,(family,cols,legs,Tnet,free) in enumerate(candidates):
                column_ids=[xs.index(x) for x in cols];level_ids=[g['web_y_mm'].index(y) for y in levels]
                selected=[v for v in bolts if v['column_index'] in column_ids and v['level_index'] in level_ids]
                if len(selected)!=len(cols)*k:raise ArithmeticError('Caminho de bloco não selecionou todos os parafusos físicos esperados.')
                Fx=sum(v['qx_N']/2 for v in selected);Fy=sum(v['qy_N']/2 for v in selected)
                C=sum(v['x_mm']*v['qy_N']/2-v['y_mm']*v['qx_N']/2 for v in selected)
                sx=[min(cols),max(cols)] if family=='U' else [cols[-1]]
                tx=[min(cols),max(cols)] if family=='U' else [cols[-1],free]
                rows.append(dict(id=f'{"top" if sy>0 else "bottom"}_k{k}_{family}{n}',family=family,k=k,columns_mm=cols,
                                 number_shear_legs=legs,column_ids=column_ids,level_ids=level_ids,subset_bolt_count=len(selected),Agv_mm2=legs*Lv*t,Anv_mm2=legs*Ln*t,Ant_mm2=Tnet*t,Cts=.5,
                                 shear_legs_mm=[[[x,yfree],[x,ycut]] for x in sx],tension_segment_mm=[[x,ycut] for x in tx],
                                 subset_Fx_N=Fx,subset_Fy_N=Fy,subset_C_origin_Nmm=C,subset_resultant_N=math.hypot(Fx,Fy),
                                 demand_fraction_total_V=.5,actual_subset_couple_retained=True))
    if len(rows)!=84:raise ArithmeticError('Enumeração de blocos convencional incompleta.')
    if any(min(x['Agv_mm2'],x['Anv_mm2'],x['Ant_mm2'])<=0 for x in rows):raise ArithmeticError('Caminho real de bloco com ligamento líquido não positivo.')
    return rows


def directional_clearance(point,force,holes,bounds,dh):
    """Distance in the actual load direction to real edge or hole perimeter.

    Bounds may be None for uncut member continuations. No web/flange interface
    is treated as a free edge. The resulting bearing stress is capped normally.
    """
    fx,fy=force;q=math.hypot(fx,fy)
    if q==0:return None
    ux,uy=fx/q,fy/q;px,py=point;limits=[]
    for coordinate,unit,low,high in ((px,ux,bounds[0],bounds[1]),(py,uy,bounds[2],bounds[3])):
        end=high if unit>0 else low
        if abs(unit)>1e-14 and end is not None:
            distance=(end-coordinate)/unit-dh/2
            if distance>=-TOL:limits.append(distance)
    for hx,hy in holes:
        dx,dy=hx-px,hy-py
        if abs(dx)+abs(dy)<1e-10:continue
        along=dx*ux+dy*uy;cross=dx*uy-dy*ux
        if along>0 and abs(cross)<=dh/2:
            limits.append(along-math.sqrt(max(0.,(dh/2)**2-cross**2))-dh/2)
    return min(limits) if limits else None


def bearing_rows(c,out,case_id,component,holes,forces,bounds,t,fu):
    """Every loaded physical hole, resultant plus conservative x/y screen."""
    for j,(pt,f) in enumerate(zip(holes,forces)):
        q=math.hypot(*f);lc=directional_clearance(pt,f,holes,bounds,c.hole_diameter)
        cap=2.4*c.db*t*fu/GAMMA_A2
        if lc is not None:
            if lc<=0:raise ArithmeticError(component+': ligamento de contato não positivo.')
            cap=min(cap,1.2*lc*t*fu/GAMMA_A2)
        det=dict(x_mm=pt[0],transverse_mm=pt[1],force_x_N=f[0],force_y_N=f[1],clear_distance_mm=lc,
                 physical_bounds_mm=bounds,thickness_mm=t,fu_MPa=fu)
        check(out,f'{case_id}:{component}_bearing_b{j}',f'Contato/rasgamento no vetor real · furo {j+1}',component,q,cap,'N',
              'min(1,2 lc t fu;2,4 db t fu)/γa2; lc no sentido real',NBR+', 6.3.3.3(a)',**det)
        ratios=[];caps=[]
        for k,comp in enumerate(f):
            vec=(comp,0.) if k==0 else (0.,comp)
            cl=directional_clearance(pt,vec,holes,bounds,c.hole_diameter)
            cp=2.4*c.db*t*fu/GAMMA_A2
            if cl is not None:cp=min(cp,1.2*cl*t*fu/GAMMA_A2)
            ratios.append(abs(comp)/cp);caps.append(cp)
        check(out,f'{case_id}:{component}_bearing_xy_b{j}',f'Tela conservadora de contato x/y · furo {j+1}',component,sum(ratios),1.,'ratio',
              '|qx|/Rx + |qy|/Ry ≤1; tela adicional conservadora, não interação normativa',NBR+', 6.3.3.3; restrição adicional de projeto',
              **det,axis_capacities_N=caps,additional_design_screen=True)


def tension_checks(c,out,case_id,identifier,width,t,end,pitch,nrows,cols,steel,demand,cover,member=False):
    dn=out['geometry']['dn'];Ag=width*t;An=Ag-len(cols)*dn*t;Ae=min(An,.85*Ag) if cover else An
    if min(Ag,An,Ae)<=0:raise ArithmeticError(identifier+': seção líquida não positiva.')
    check(out,f'{case_id}:{identifier}_gross_tension','Tração · escoamento bruto',identifier,demand,steel.fy*Ag/GAMMA_A1,'N','fy Ag/γa1',NBR+', 5.2.2',Ag_mm2=Ag)
    check(out,f'{case_id}:{identifier}_net_tension','Tração · ruptura líquida local',identifier,demand,steel.fu*Ae/GAMMA_A2,'N',
          'fu min(An;0,85Ag)/γa2' if cover else 'fu An/γa2; caminho local direto da mesa',NBR+', 5.2.3–5.2.5; 6.5.3',
          Ag_mm2=Ag,An_mm2=An,Ae_mm2=Ae,whole_member_Ct_claim=False)
    paths=block_paths(identifier=identifier,width=width,thickness=t,end=end,pitch=pitch,nrows=nrows,columns=cols,
                      dn=dn,fy=steel.fy,fu=steel.fu,fraction=1.,N=max(demand,1.),free_sides=True)
    if member:paths=[p for p in paths if p['path_family']=='L' and p['m']==1]
    for path in paths:
        fraction=path['demand_fraction_of_component']
        check(out,case_id+':'+path['id'],path['label'],identifier,demand*fraction,path['design_capacity_N'],'N',
              path['formula'],path['reference'],**{k:v for k,v in path.items() if k not in ('id','label','component','formula','reference','status','utilization','demand_N','design_capacity_N')})
    return dict(Ag_mm2=Ag,An_mm2=An,Ae_mm2=Ae,block_count=len(paths))


def _blank(c):
    return dict(status='INVALID_INPUT',issues=[],checks=[],geometry={},components={},physical_covers=[],bolts={},
                capacity_calculation_permitted=False,scope=dict(supported=False,statement=SCOPE,exclusions=EXCLUSIONS.copy(),
                detail_conditions=DETAIL_CONDITIONS.copy()),inputs=_safe(active_engineering_payload(c)) if isinstance(c,WConventional) else _safe(c),
                units={'force':'N','length':'mm','stress':'MPa','moment':'N mm'},force_model=CONNECTION_TYPE,qualification=QUALIFICATION_VERSION)


def _evaluate(c,out=None):
    out=_blank(c) if out is None else out
    errors=input_errors(c)
    if errors:
        for text in errors:issue(out,'invalid_input',text)
        return out
    p=c.profile
    unsupported=[(p.family!='W','Somente perfis W laminados idênticos e coaxiais.'),
        (c.torsion!=0,'Torção não é descartada; está fora do modelo N/M/V.'),
        (not c.concentric,'Membros não coaxiais fora do domínio.'),(not c.static,'Fadiga, impacto e ações dinâmicas fora do domínio; sinais estáticos podem reverter.'),
        (not c.normal_combination,'Apenas combinações últimas normais.'),
        (c.include_inner_flange_plates and not math.isclose(c.flange_outer_width,2*c.flange_inner_width,rel_tol=TOL,abs_tol=1e-8),'O domínio atual de partilha igual exige bo=2bi com mesma espessura e aço; não é exigência universal da NBR.'),
        (c.flange_rows<2,'Mesas: pelo menos duas linhas longitudinais completas por lado.'),
        (c.web_rows!=2 or c.web_levels!=3,'A alma exige malha regular completa 2×3 por lado.'),
        (c.exposure not in ('painted','weathering'),'Exposição sem regra de detalhamento.'),
        (c.db not in (16.,20.,24.,30.),'Parafusos métricos M16/M20/M24/M30.'),
        (c.bolt not in ('ASTM F3125 A325','ASTM F3125 A490'),'Classe de parafuso não implementada.')]
    hole_max={16.:18.,20.:22.,24.:27.,30.:33.}.get(c.db)
    if hole_max is not None and not c.db<c.hole_diameter<=hole_max:unsupported.append((True,'Furo não circular padrão ou fora da Tabela 14.'))
    for bad,text in unsupported:
        if bad:issue(out,'unsupported_scope',text,'Domínio convencional paramétrico')
    materials={}
    for key,name,ts,plate in [('member',c.member_steel,[p.tf,p.tw],False),('flange',c.flange_steel,[c.flange_t],True),('web',c.web_steel,[c.web_t],True)]:
        s=STEELS.get(name)
        if s is None or not (s.plate_allowed if plate else s.rolled_allowed) or any(not ((s.plate_min if plate else s.profile_min)<=t<=(s.plate_max if plate else s.profile_max)) for t in ts):
            issue(out,'unsupported_scope',key+': aço/produto/espessura fora do cadastro.')
        else:materials[key]=s
    before_geometry=len(out['issues'])
    g=geometry(c,out)
    for item in out['issues'][before_geometry:]:
        if item['severity']=='unsupported_scope':
            item['severity']='engineering_pending'
            item['code']='BOLT_GRIP_OR_LONG_JOINT_REDUCTION_PENDING'
    if p.area<(2*p.bf*p.tf+(p.d-2*p.tf)*p.tw)*.995:issue(out,'invalid_geometry','Área do perfil menor que mesas+alma retangulares, além da tolerância de0,5%.')
    fit_only={'outer_width_fit','inner_assembly_fit','inner_web_clear','web_flange_clear','inner_root_fit','web_root_fit','root_clear_height','root_radius_vertical'}
    # A collision blocks approval but does not erase useful component results.
    # Nonpositive physical/net ligaments cannot support these calculations.
    if any(key not in fit_only for key in g['errors']):out['status']='INVALID_GEOMETRY';return out
    if any(i['severity']=='unsupported_scope' for i in out['issues']):out['status']='OUTSIDE_CONVENTIONAL_SCOPE';return out
    out['materials']={k:asdict(v) for k,v in materials.items()};steel,fsteel,wsteel=(materials[k] for k in ('member','flange','web'))
    if c.assembly_detail!='complete_row_supported_detail_v1':issue(out,'engineering_pending','Detalhe de apoio às linhas não fornecido: resistências das talas são condicionais ao detalhe físico listado.','Fakury pp.313–317; K=1 conservador')
    if c.minimum_action_policy=='pending' or not c.minimum_reference.strip():
        issue(out,'engineering_pending','Declarar a política da 6.1.5.3: envelope recomendado ou decisão registrada do responsável de usar as ações de projeto. A recomendação de resistência do membro não é obrigatória. O piso obrigatório da 6.1.5.2 é tratado separadamente, com direção e sentido preservados.',NBR+', 6.1.5')
    if not c.integrity_included:issue(out,'engineering_pending','Ações de integridade aplicáveis ainda não incluídas na entrada.',NBR+', 4.13; 6.1.5')
    cases=[('actual',c.N,c.M,c.V)]
    if c.minimum_action_policy=='provided_envelope':cases.append(('minimum',c.minimum_N,c.minimum_M,c.minimum_V))
    if c.minimum_action_policy=='actual_actions_engineer_choice' and c.minimum_reference.strip():
        issue(out,'warning','Decisão registrada do responsável técnico: usar ações de projeto, sem adotar a recomendação discricionária de 50% da resistência do membro ou sua alternativa de 100% quando a esbeltez governa. '+c.minimum_reference,NBR+', 6.1.5.3')
    floor_cases=[]
    for label,Nc,Mc,Vc in cases:
        resultant=math.hypot(Nc,Vc)
        if 0<resultant<45000.:
            factor=45000./resultant
            floor_cases.append((label+'_force_floor',Nc*factor,Mc,Vc*factor))
            issue(out,'info',f'Caso separado {label}_force_floor: piso de 45 kN com N/V na direção e sentido da resultante original; M independente mantido. O caso {label} permanece inalterado.',NBR+', 6.1.5.2',
                  code='SIGNED_RESULTANT_45KN_SUPPLEMENT',source_case=label,resultant_N=resultant,scale=factor,
                  interpretation='Convenção declarada: força resultante no plano hypot(N,V); escala uniforme de N,V, sem escalar o binário independente M.')
    cases.extend(floor_cases)
    LeF=max(c.gap+2*c.flange_member_end,c.flange_pitch);LbW=max(c.gap+2*c.web_member_end,c.web_pitch)
    gf=g['flange_gauge_mm'];cols=[-gf/2,gf/2]
    strips={'outer':compression_strip(c.flange_outer_width,c.flange_t,LeF,fsteel.fy,[('AA',gf),('AL',(c.flange_outer_width-gf)/2),('AL',(c.flange_outer_width-gf)/2)]),
            }
    if c.include_inner_flange_plates:
        strips['inner']=compression_strip(c.flange_inner_width,c.flange_t,LeF,fsteel.fy,[('AL',c.flange_inner_width/2),('AL',c.flange_inner_width/2)])
    out['compression_strips']=strips
    section=net_rectangle(c.web_height,c.web_t,g['dn'],g['web_y_mm']);ltb=web_ltb(c.web_height,c.web_t,LbW,wsteel.fy)
    out['net_web_section']=section;out['web_ltb']=ltb
    a=c.web_pitch/2;e=c.gap/2+c.web_member_end+a;J=6*a*a+4*c.web_gauge**2
    normalized=mechanics(c,g,0.,0.,1.);normalized_paths=web_paths(c,g,normalized)
    directional=e*a/J<=1/6+TOL;bound=max(x['subset_resultant_N'] for x in normalized_paths)
    actual_cut=normalized['web_max_cut_moment_per_cover_Nmm'];envelope=normalized['web_group_moment_per_cover_Nmm']
    domain=dict(e_mm=e,a_mm=a,J_mm2=J,e_a_over_J=e*a/J,no_shear_direction_reversal=directional,
                subset_resultant_max_per_unit_V=bound,subset_bound_limit=.5,all_84_path_resultants_bounded=bound<=.5+TOL,
                cut_moment_envelope_bounded=actual_cut<=envelope+TOL,web_path_count_per_cover=84)
    domain['active_web_shear']=any(v!=0 for _,_,_,v in cases)
    domain['governing_subset']=max(normalized_paths,key=lambda x:x['subset_resultant_N'])
    out['qualification_checks']=domain
    if domain['active_web_shear'] and not all((directional,domain['all_84_path_resultants_bounded'])):
        issue(out,'engineering_pending','Geometria excede a admissão finita do modelo escalar V/Ve: conferir e·a/J≤1/6 e resultantes de todos os 84 subgrupos≤|V|/2. Cálculos locais preservados como condicionais.','Qualificação convencional paramétrica',code='WEB_SCALAR_BLOCK_ECCENTRICITY_MAPPING_PENDING',**domain)
    if c.flange_t>=(c.flange_inner_width if c.include_inner_flange_plates else c.flange_outer_width) or c.web_t>=c.web_height:
        issue(out,'engineering_pending','Proporção barra/chapa fora do detalhe convencional retangular de talas; resistência calculada não qualifica a montagem.')
    Ab=math.pi*c.db**2/4;alpha=.56 if c.threads_excluded_verified else .45;rplane=alpha*Ab*BOLTS[c.bolt]/GAMMA_A2
    out['bolts']=dict(Ab_mm2=Ab,coefficient=alpha,resistance_per_plane_N=rplane,shear_planes=2,
                      total_bolts=8*c.flange_rows+12,physical_groups=[])
    flange_planes=2 if c.include_inner_flange_plates else 1
    out['bolts'].update(flange_shear_planes=flange_planes,web_shear_planes=2)
    if not c.include_inner_flange_plates:out['bolts'].pop('shear_planes')
    out['load_cases']=[]
    out['minimum_action_basis']=dict(policy=c.minimum_action_policy,reference=c.minimum_reference,
                                     actual_actions_unchanged=True,supplemental_signed_actions={'N_N':c.minimum_N,'M_Nmm':c.minimum_M,'V_N':c.minimum_V},
                                     mandatory_force_floor_N=45000.,force_floor_case_ids=[v[0] for v in floor_cases],
                                     force_floor_convention='Para resultante0<R<45kN: (N,V)×45kN/R, mesmo sentido; M independente mantido. R=0 não cria direção ou força axial fictícia.',
                                     discretionary_recommendation='6.1.5.3:50% ou100% por esbeltez são recomendações a critério do responsável técnico, não capacidades externas obrigatórias.',
                                     limitation='O critério de recomendação é declarado pelo responsável; a referência não é verificada independentemente pelo aplicativo.')
    for case_id,N,M,V in cases:
        load=mechanics(c,g,N,M,V);load['case_id']=case_id;out['load_cases'].append(load)
        if case_id=='actual':out['load_model']=load
        paths=web_paths(c,g,load)
        if case_id=='actual':out['web_block_paths']=paths
        # Separate flange plates and connected member flanges. Covers use
        # splice forces; member local envelopes retain the full M−Vx gradient.
        for pos,F in [('top',load['top_force_N']),('bottom',load['bottom_force_N'])]:
            pieces=[('outer_'+pos,c.flange_outer_width,.5 if c.include_inner_flange_plates else 1.,cols,'outer')]
            if c.include_inner_flange_plates:pieces += [(f'inner_{pos}_{s}',c.flange_inner_width,.25,[0.],'inner') for s in ('negative','positive')]
            for identifier,width,fraction,pcols,kind in pieces:
                force=F*fraction;result=tension_checks(c,out,case_id,identifier,width,c.flange_t,c.flange_cover_end,c.flange_pitch,c.flange_rows,pcols,fsteel,max(0.,force),True)
                check(out,f'{case_id}:{identifier}_compression','Compressão da tala independente',identifier,max(0.,-force),strips[kind]['R_N'],'N',
                      '6.5.4 corrigido; χ Aef fy/γa1; K=1; Ne=min(Nex,Ney,Nez)',NBR+', 6.5.4; 5.3; tabelas4–5',**strips[kind])
                holes=[];forces=[]
                for sign in (-1,1):
                    for x in g['flange_x_mm']:
                        for z in pcols:holes.append((sign*x,z));forces.append((sign*force/(c.flange_rows*len(pcols)),0.))
                bearing_rows(c,out,case_id,identifier,holes,forces,(-g['flange_length_mm']/2,g['flange_length_mm']/2,-width/2,width/2),c.flange_t,fsteel.fu)
                if case_id=='actual':
                    out['components'][identifier]=dict(id=identifier,cover=True,force_N=force,width_mm=width,thickness_mm=c.flange_t,length_mm=g['flange_length_mm'],role=kind,position=pos,**result)
                    out['physical_covers'].append(identifier)
            identifier='member_flange_'+pos;field='Ftop_N' if pos=='top' else 'Fbottom_N'
            Ft=max(0.,*(v[field] for v in load['member_stations']));Fc=max(0.,*(-v[field] for v in load['member_stations']))
            result=tension_checks(c,out,case_id,identifier,p.bf,p.tf,c.flange_member_end,c.flange_pitch,c.flange_rows,cols,steel,Ft,False,True)
            check(out,f'{case_id}:{identifier}_compression_local','Mesa do membro · compressão local bruta',identifier,Fc,p.bf*p.tf*steel.fy/GAMMA_A1,'N',
                  'fy bf tf/γa1; limite local, estabilidade global externa',NBR+', 5.3; caminho normal integral pelas mesas',global_member_stability=False)
            # NBR 5.1.2.2.4(a): member flange b is HALF TOTAL width.
            # The two effective halves already include the central web strip.
            member_local=effective_width(p.bf/2,p.tf,steel.fy,1.,'AL')
            Aeff=2*p.tf*member_local['beff_mm']
            check(out,f'{case_id}:{identifier}_compression_local_effective','Mesa do membro · seção efetiva local',identifier,Fc,Aeff*steel.fy/GAMMA_A1,'N',
                  'b=bf/2; Aef=2 beff tf; Aef fy/γa1; χ=1 para tela local, não Nc,Rd global',NBR+', 5.1.2.2.4(a); 5.3.4; tabela4',Aeff_mm2=Aeff,local_element=member_local,global_member_stability=False)
            for side,sign in [('left',-1),('right',1)]:
                holes=[(sign*x,z) for x in g['flange_x_mm'] for z in cols]
                forces=[(-sign*F/(2*c.flange_rows),0.) for _ in holes]
                bounds=(-c.gap/2 if sign<0 else c.gap/2,None,-p.bf/2,p.bf/2) if sign>0 else (None,-c.gap/2,-p.bf/2,p.bf/2)
                bearing_rows(c,out,case_id,identifier+'_'+side,holes,forces,bounds,p.tf,steel.fu)
                for j,pt in enumerate(holes):
                    for plane in range(1,flange_planes+1):
                        check(out,f'{case_id}:bolt_flange_{pos}_{side}_{j}_plane{plane}','Corte do parafuso · plano individual',f'bolt_flange_{pos}_{side}',abs(F)/(flange_planes*2*c.flange_rows),rplane,'N',
                              '|Fmesa|/(2n); α Ab fub/γa2' if c.include_inner_flange_plates else '|Fmesa|/n; α Ab fub/γa2; n=2nf',NBR+', 6.3.3.2',x_mm=pt[0],transverse_mm=pt[1],plane=plane,complete_bolt_force_N=abs(F)/(2*c.flange_rows))
            if case_id=='actual':
                out['components'][identifier]=dict(id=identifier,cover=False,force_N=F,tension_envelope_N=Ft,compression_envelope_N=Fc,**result)
                for side in ('left','right'):
                    out['bolts']['physical_groups'].append(dict(id='flange_'+pos+'_'+side,bolt_count=2*c.flange_rows,group_signed_force_N=F,
                        each_bolt_force_N=abs(F)/(2*c.flange_rows),each_plane_force_N=abs(F)/(flange_planes*2*c.flange_rows),shear_planes=flange_planes))
        # All actual web holes and both physical shear planes.
        allholes=[(b['x_mm'],b['y_mm']) for gr in load['web_groups'] for b in gr['bolts']]
        coverforces=[(b['qx_N']/2,b['qy_N']/2) for gr in load['web_groups'] for b in gr['bolts']]
        vc=abs(V)/2;mv=load['web_design_moment_envelope_per_cover_Nmm']
        for side in ('negative','positive'):
            identifier='web_cover_'+side
            if case_id=='actual':out['physical_covers'].append(identifier);out['components'][identifier]=dict(id=identifier,cover=True,role='web_cover',force_N=0.,shear_N=V/2,moment_envelope_Nmm=mv,width_mm=c.web_height,thickness_mm=c.web_t,length_mm=g['web_length_mm'],**section)
            bearing_rows(c,out,case_id,identifier,allholes,coverforces,(-g['web_length_mm']/2,g['web_length_mm']/2,-c.web_height/2,c.web_height/2),c.web_t,wsteel.fu)
            RvG=.6*wsteel.fy*section['Ag_mm2']/GAMMA_A1;RvN=.6*wsteel.fu*section['An_mm2']/GAMMA_A2;RmN=wsteel.fu*section['Znet_mm3']/GAMMA_A2
            check(out,f'{case_id}:{identifier}_shear_gross','Corte · escoamento bruto',identifier,vc,RvG,'N','.6fy Ag/γa1',NBR+', 6.5.5',Ag_mm2=section['Ag_mm2'])
            check(out,f'{case_id}:{identifier}_shear_net','Corte · ruptura líquida',identifier,vc,RvN,'N','.6fu An/γa2',NBR+', 6.5.5',An_mm2=section['An_mm2'])
            check(out,f'{case_id}:{identifier}_LTB','Flexão e flambagem lateral-torcional',identifier,mv,ltb['MRd_Nmm'],'N mm','AnnexD/TableD.1 rectangular; Cb=1',NBR+', anexoD/tabelaD.1',**ltb)
            check(out,f'{case_id}:{identifier}_net_bending','Flexão · ruptura da seção líquida integrada',identifier,mv,RmN,'N mm','fu Znet/γa2; integral exata das partes remanescentes','Fakury p.317; método do elemento de ligação',**section)
            sigma=mv/section['Wg_mm3'];tau=1.5*vc/section['Ag_mm2'];vm=math.sqrt(sigma*sigma+3*tau*tau)
            check(out,f'{case_id}:{identifier}_gross_combined','Interação elástica bruta M/V',identifier,vm,wsteel.fy/GAMMA_A1,'MPa','√[(Menv/Wg)²+3(1,5V/Ag)²] ≤ fy/γa1','Fakury p.317; envelope elástico conservador',sigma_MPa=sigma,tau_MPa=tau)
            check(out,f'{case_id}:{identifier}_net_additional_screen','Tela líquida adicional V/M',identifier,vc/min(RvG,RvN)+mv/RmN,1.,'ratio',
                  '|Vcover|/VRd+|Menv|/MRd,net≤1','Restrição adicional conservadora de projeto; não equação normativa de fratura mista',additional_design_screen=True)
            for path in paths:
                R=(min(.6*wsteel.fy*path['Agv_mm2'],.6*wsteel.fu*path['Anv_mm2'])+.5*wsteel.fu*path['Ant_mm2'])/GAMMA_A2
                check(out,f'{case_id}:{identifier}_block_{path["id"]}','Bloco real '+path['family']+' · '+path['id'],identifier,vc,R,'N',
                      '[min(.6fy Agv,.6fu Anv)+.5fu Ant]/γa2; demanda integral|V|/2',NBR+', 6.5.6; Fakury pp.315–318',**path)
        for gr in load['web_groups']:
            side=gr['side'];sign=-1 if side=='left' else 1
            holes=[(b['x_mm'],b['y_mm']) for b in gr['bolts']];forces=[(-b['qx_N'],-b['qy_N']) for b in gr['bolts']]
            bounds=(None,-c.gap/2,None,None) if sign<0 else (c.gap/2,None,None,None)
            bearing_rows(c,out,case_id,'member_web_'+side,holes,forces,bounds,p.tw,steel.fu)
            for j,b in enumerate(gr['bolts']):
                for plane in (1,2):check(out,f'{case_id}:bolt_web_{side}_{j}_plane{plane}','Corte vetorial · plano individual','bolt_web_'+side,b['resultant_N']/2,rplane,'N',
                                         '√(qx²+qy²)/2 ≤ α Ab fub/γa2',NBR+', 6.3.3.2',plane=plane,**b)
            if case_id=='actual':out['bolts']['physical_groups'].append(dict(id='web_'+side,bolt_count=6,bolts=gr['bolts']))
        aw=(p.d-2*p.tf)*p.tw;anw=aw-3*g['dn']*p.tw
        check(out,case_id+':member_web_shear_gross','Alma contínua · corte bruto','member_web',abs(V),.6*steel.fy*aw/GAMMA_A1,'N','.6fy Aw/γa1',NBR+', 6.5.5',Ag_mm2=aw)
        check(out,case_id+':member_web_shear_net','Alma contínua · ruptura líquida','member_web',abs(V),.6*steel.fu*anw/GAMMA_A2,'N','.6fu (Aw−3dn tw)/γa2',NBR+', 6.5.5',An_mm2=anw,flange_interfaces_are_not_free_edges=True)
        shear_lambda=p.clear/p.tw;lp=1.1*math.sqrt(5.34*E/steel.fy);lr=1.37*math.sqrt(5.34*E/steel.fy)
        Cv=1. if shear_lambda<=lp else lp/shear_lambda if shear_lambda<=lr else 1.24*(lp/shear_lambda)**2
        check(out,case_id+':member_web_shear_buckling','Alma do membro · instabilidade por cisalhamento','member_web',abs(V),Cv*.6*steel.fy*aw/GAMMA_A1,'N',
              'Cv .6fy Aw/γa1; kv=5,34; painel sem crédito de enrijecedores',NBR+', 5.4.3',Cv=Cv,lambda_=shear_lambda,lambda_p=lp,lambda_r=lr)
        # Actual tension-flange hole flexure cap, separate from cover net bend.
        Afg=p.bf*p.tf;Afn=(p.bf-2*g['dn'])*p.tf;Yt=1. if steel.fy/steel.fu<=.8 else 1.1
        Ix=2*(p.bf*p.tf**3/12+p.bf*p.tf*((p.d-p.tf)/2)**2)+p.tw*(p.d-2*p.tf)**3/12
        W=Ix/(p.d/2);gate=steel.fu*Afn>=Yt*steel.fy*Afg
        holecap=steel.fu*Afn/Afg*W/GAMMA_A1
        out['member_hole_flexure']=dict(Afg_mm2=Afg,Afn_mm2=Afn,Yt=Yt,gate_satisfied=gate,Wt_mm3=W,
                                       hole_cap_Nmm=holecap,cap_active=not gate,
                                       basis='Gross W from actual rectangular flange/web dimensions; no fillet credit; γa1, not γa2.')
        if not gate:check(out,case_id+':member_flange_hole_flexure','Membro · limite de flexão nos furos','member',load['member_moment_envelope_Nmm'],holecap,'N mm',
                          '(fu Afn/Afg) Wt/γa1 when fu Afn<Yt fy Afg',NBR+', 5.4.2.6',**out['member_hole_flexure'])
        if case_id=='actual':out['components']['member_web']=dict(id='member_web',cover=False,force_N=0.,shear_N=V,Ag_mm2=aw,An_mm2=anw)
    if c.no_slip_required:
        from .w_splice_slip import evaluate_slip
        out['slip']=evaluate_slip(c,g,mechanics)
        if out['slip']['status'] in ('PENDING','NOT_EVALUATED'):
            for text in out['slip']['reasons']:issue(out,'service_pending',text,NBR+', 6.3.4.4')
        elif out['slip']['status']=='FAIL':issue(out,'service_failure','Não atende à verificação de deslizamento em serviço; as verificações ELU continuam independentes.',NBR+', 6.3.4.4')
    # External global member inputs are never inferred from a cover capacity.
    supplied=any(getattr(c,k)>0 for k in ('member_Nc_Rd','member_Nt_Rd','member_M_Rd','member_V_Rd')) or bool(c.member_capacity_reference)
    bound=c.member_capacity_binding in (capacity_binding(c),legacy_capacity_binding(c))
    allcaps=all(getattr(c,k)>0 for k in ('member_Nc_Rd','member_Nt_Rd','member_M_Rd','member_V_Rd'))
    status='EXTERNAL_SUPPLIED_CHECKED' if supplied and allcaps and c.member_capacity_reference.strip() and bound else 'EXTERNAL_INPUT_STALE' if supplied else 'EXTERNAL_NOT_SUPPLIED'
    out['member_external']=dict(status=status,reference=c.member_capacity_reference,expected_binding=capacity_binding(c),supplied_binding=c.member_capacity_binding,
                                capacities=dict(Nc_Rd_N=c.member_Nc_Rd,Nt_Rd_N=c.member_Nt_Rd,M_Rd_Nmm=c.member_M_Rd,V_Rd_N=c.member_V_Rd),
                                verification='User-supplied global resistance basis; connection evaluator does not establish member lengths/restraints/analysis.')
    if bound and c.member_capacity_binding!=capacity_binding(c):
        out['member_external']['binding_compatibility']='Exact legacy schema-1 balanced active inputs; original binding preserved, not rebound'
    if status=='EXTERNAL_SUPPLIED_CHECKED':
        for load in out['load_cases']:
            N=load['N_N'];M=load['member_moment_envelope_Nmm'];Vr=abs(load['V_N']);Nr=c.member_Nt_Rd if N>=0 else c.member_Nc_Rd
            Mr=c.member_M_Rd if out['member_hole_flexure']['gate_satisfied'] else min(c.member_M_Rd,out['member_hole_flexure']['hole_cap_Nmm'])
            n=abs(N)/Nr;m=M/Mr;ratio=n+8*m/9 if n>=.2 else n/2+m
            check(out,load['case_id']+':external_member_NM','Membro global · interação com capacidades fornecidas','external_member',ratio,1.,'ratio',
                  'N/NRd≥.2: N/NRd+(8/9)M/MRd; abaixo:.5N/NRd+M/MRd',NBR+', 5.5.1',capacity_reference=c.member_capacity_reference,external_basis=True,N_ratio=n,M_ratio=m)
            check(out,load['case_id']+':external_member_V','Membro global · cortante com resistência fornecida','external_member',Vr,c.member_V_Rd,'N','|V|≤VRd externo verificado',NBR+', 5.4.3',external_basis=True)
    elif supplied:issue(out,'external_pending','Capacidades globais fornecidas incompletas ou vínculo desatualizado: não há conclusão global do membro.')
    else:issue(out,'external_scope','Estabilidade global do membro e análise do sistema não incluídas. Fornecer capacidades verificadas e referência para a conferência opcional de interação.')
    out['physical_regions']={identifier+'_'+side:dict(component=identifier,side=side,serial_sides_do_not_add=True)
                             for identifier in out['components'] for side in ('left','right')}
    out['capacity_calculation_permitted']=True
    severities={i['severity'] for i in out['issues']};pending=bool(severities&{'engineering_pending','access_pending','service_pending','invalid_geometry'})
    failed=[r['id'] for r in out['checks'] if r['status']=='FAIL'];govern=max(out['checks'],key=lambda r:r['utilization'])
    out['scope']['supported']=not pending
    for row in out['checks']:
        row['evaluation_basis_status']='CONDITIONAL_DOMAIN' if pending or 'detail_fail' in severities else 'WITHIN_DECLARED_LOCAL_DOMAIN'
    out['summary']=dict(governing_check_id=govern['id'],governing_label=govern['label'],governing_component=govern['component'],
                        governing_utilization=govern['utilization'],strength_status='FAIL' if failed else 'PASS',failed_check_ids=failed,
                        complete_local_checks=not pending and 'detail_fail' not in severities,check_count=len(out['checks']),physical_cover_count=len(out['physical_covers']),
                        global_member_status=status,load_case_count=len(cases),no_equivalent_axial_capacity=True)
    unloaded=all(N==0 and M==0 and V==0 for _,N,M,V in cases)
    if unloaded:
        issue(out,'not_evaluated','Todos os casos são nulos; as resistências são informativas e não constituem aprovação de um caso carregado.')
        out['summary']['complete_local_checks']=False;out['scope']['supported']=False
    out['status']='INVALID_GEOMETRY' if 'invalid_geometry' in severities else 'NOT_EVALUATED' if unloaded else 'VERIFIED_SUBCHECK_FAIL' if failed else 'DETAIL_FAIL' if 'detail_fail' in severities else 'LOCAL_CHECKS_PENDING' if pending else 'LOCAL_CHECKS_PASS_WITHIN_SCOPE'
    if c.no_slip_required and 'slip' in out:
        out['summary']['service_slip_status']=out['slip']['status']
        if out['slip']['status']=='FAIL' and out['status'] in ('LOCAL_CHECKS_PASS_WITHIN_SCOPE','LOCAL_CHECKS_PENDING'):
            out['status']='SERVICE_SLIP_FAILURE'
    return out


def evaluate(c):
    out=_blank(c)
    try:
        out=_evaluate(c,out)
        out['input_digest']=input_digest(c)
        def finite(x):
            if isinstance(x,float):return math.isfinite(x)
            if isinstance(x,dict):return all(finite(v) for v in x.values())
            if isinstance(x,(tuple,list)):return all(finite(v) for v in x)
            return True
        if not finite(out):raise ArithmeticError('Resultado excede a faixa numérica finita.')
        return presentation(out)
    except (ArithmeticError,OverflowError,ZeroDivisionError) as exc:
        issue(out,'numerical_failure',str(exc),'Faixa numérica finita do cálculo')
        out['status']='NUMERICAL_FAILURE';out['scope']['supported']=False
        out['capacity_calculation_permitted']=bool(out['checks'])
        if out['checks']:
            failed=[r['id'] for r in out['checks'] if r['status']=='FAIL']
            govern=max(out['checks'],key=lambda r:r['utilization'])
            out['summary']=dict(governing_check_id=govern['id'],governing_label=govern['label'],governing_utilization=govern['utilization'],
                                strength_status='FAIL' if failed else 'PARTIAL',failed_check_ids=failed,complete_local_checks=False,check_count=len(out['checks']))
        return presentation(_safe(out))


# Display envelopes never enter the strength calculation. Every primitive is
# assigned exactly once; max utilization selects the ENTIRE row and load case.
# No summed, minimized, or independently enveloped resistance is manufactured.
def mechanism_envelopes(rows):
    groups={}
    cover_codes={'outer_top':'F1','inner_top_negative':'F2','inner_top_positive':'F3',
                 'outer_bottom':'F4','inner_bottom_negative':'F5','inner_bottom_positive':'F6',
                 'web_cover_negative':'W1','web_cover_positive':'W2'}
    component_names={'outer':'Talas externas de mesa F1/F4','inner':'Tiras internas F2/F3/F5/F6',
                     'member_flange':'Mesas dos membros','web_cover':'Talas de alma W1/W2',
                     'member_web':'Almas dos membros','bolt_flange':'Parafusos de mesa',
                     'bolt_web':'Parafusos de alma','member':'Membro local',
                     'external_member':'Membro · base global fornecida'}
    names={'bolt_shear':'Corte por plano físico de parafuso',
           'bearing_vector':'Contato/rasgamento · vetor real',
           'bearing_xy':'Contato x/y · tela conservadora',
           'block':'Bloco · envelope de todos os caminhos físicos',
           'tension_gross':'Tração · escoamento bruto','tension_net':'Tração · ruptura líquida',
           'compression':'Compressão · estabilidade da peça independente',
           'local_compression':'Compressão local do membro · bruto/efetivo χ=1',
           'web_net':'Seção líquida V/M · tela conservadora e ramos escalares',
           'gross_combined':'Interação elástica bruta M/V', 'LTB':'Flexão e flambagem lateral-torcional',
           'member_shear':'Corte do membro · bruto/líquido/instabilidade',
           'hole_flexure':'Flexão do membro nos furos','external_NM':'Interação N/M · base externa',
           'external_V':'Corte · base externa'}
    for row in rows:
        comp=row['component'];id=row['id']
        kind=next((k for k in ('external_member','member_flange','member_web','web_cover','bolt_flange','bolt_web','outer','inner') if comp.startswith(k)),'member')
        if kind.startswith('bolt_'): mech='bolt_shear'
        elif '_bearing_xy_' in id:mech='bearing_xy'
        elif '_bearing_b' in id:mech='bearing_vector'
        elif '_block_' in id:mech='block'
        elif id.endswith('_gross_tension'):mech='tension_gross'
        elif id.endswith('_net_tension'):mech='tension_net'
        elif '_compression_local' in id:mech='local_compression'
        elif id.endswith('_compression'):mech='compression'
        elif kind=='web_cover' and any(id.endswith(x) for x in ('_shear_gross','_shear_net','_net_bending','_net_additional_screen')):mech='web_net'
        elif kind=='member_web' and '_shear_' in id:mech='member_shear'
        elif id.endswith('_gross_combined'):mech='gross_combined'
        elif id.endswith('_LTB'):mech='LTB'
        elif id.endswith('_hole_flexure'):mech='hole_flexure'
        elif id.endswith('_NM'):mech='external_NM'
        elif id.endswith('_V'):mech='external_V'
        else:mech=id.split(':',1)[-1]  # Unknown mechanisms stay separate.
        groups.setdefault((kind,mech),[]).append(row)
    result=[]
    for (kind,mech),members in groups.items():
        governing=max(members,key=lambda row:row['utilization'])
        components=list(dict.fromkeys(row['component'] for row in members))
        result.append(dict(id=kind+':'+mech,component_group=component_names[kind],
                           mechanism=names.get(mech,governing['label']),
                           governing_check=deepcopy(governing),governing_case_id=governing['id'].split(':',1)[0],
                           member_check_ids=[row['id'] for row in members],
                           physical_component_ids=components,
                           physical_cover_ids=[cover_codes[k] for k in components if k in cover_codes],
                           primitive_count=len(members),
                           status='NOT_APPLICABLE' if all(row['demand']==0 for row in members) else governing['status'],
                           basis='Maximum utilization; complete governing primitive row and case retained. No added capacity.'))
    return result


def presentation(out):
    inherited_categories={'invalid_input':'INVALID_INPUT','invalid_geometry':'PHYSICAL_GEOMETRY',
                          'detail_fail':'DETAILING_FAILURE','unsupported_scope':'METHOD_DOMAIN',
                          'engineering_pending':'LOCAL_PREREQUISITE','access_pending':'LOCAL_PREREQUISITE'}
    for item in out.get('issues',[]):
        item.setdefault('category',inherited_categories.get(item['severity'],'INFORMATION'))
    out['mechanism_envelopes']=mechanism_envelopes(out.get('checks',[]))
    if out.get('summary') is not None:
        out['summary']['mechanism_envelope_count']=len(out['mechanism_envelopes'])
        out['summary']['inactive_check_count']=sum(row['status']=='NOT_APPLICABLE' for row in out['checks'])
    out['evaluation_basis']='fresh_canonical_input'
    out['method_revision']='conventional_optional_inner_flange_v2'
    out['source_basis']={'member_flange_width':'NBR 8800:2024 + Er1:2025, 5.1.2.2.4(a): b=bf/2; Aeff=2 beff tf',
                         'force_and_cover_model':'Fakury et al., part 4, §10.14.7, printed pp.310–320; current NBR coefficients control',
                         'equal_share_domain':'Inner covers installed: bo=2bi, same thickness/material; outer-only: full flange force in outer cover',
                         'outer_only_secondary_bending':OUTER_ONLY_SOURCE}
    if out.get('inputs',{}).get('include_inner_flange_plates') is False:
        out['scope']['detail_conditions'].append(OUTER_ONLY_METHOD)
    out['blocking_conditions']=[deepcopy(i) for i in out.get('issues',[]) if i['severity'] in
        ('invalid_input','invalid_geometry','numerical_failure','detail_fail','unsupported_scope','engineering_pending','access_pending','service_pending','not_evaluated')]
    return out
