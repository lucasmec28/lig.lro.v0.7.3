"""Finite static-tension 1L end connection to one real rectangular plate.

Units: N, mm, MPa. NBR 8800:2024/Er1:2025, nominal bolt-axis model
6.1.8.2/6.5.2. Both physical CG offsets are omitted, never cancelled.
These are local end checks, not actual-CG equilibrium or downstream support checks.
Independent qualification: next_single_angle_bolted_scope/QUALIFICATION_CONTRACT.md.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, fields, replace
import math

from .angle_catalog_selection import (native_connection, valid_native_fields, identity_errors,
    missing_data_errors, STRING_FIELDS as CATALOG_STRINGS, BOOL_FIELDS as CATALOG_BOOLS)
from .models import BOLTS, STEELS, finite_real

FAMILY = 'Ligação axial 1L–chapa retangular · parafusada'
COMPONENT_VERSION = '0.9.21-axial-single-angle-dev'
CONNECTION_TYPE = 'axial_single_angle_bolted'
LOAD_MODEL = 'NBR6.1.8.2+6.5.2_static_nominal_bolt_axis'
NBR = 'ABNT NBR 8800:2024 / Errata 1:2025'
GAMMA_A1, GAMMA_A2 = 1.10, 1.35
TOL = 1e-10
UNITS = {'force': 'N', 'length': 'mm', 'stress': 'MPa', 'moment': 'N mm'}
SCOPE = ('Uma cantoneira laminada de abas iguais ligada por uma aba à face positiva de uma '
         'chapa retangular real de largura constante; uma linha longitudinal centrada '
         'de parafusos, um plano físico de corte, furos padrão e contato firme direto sem '
         'enchimento. Tração estática e combinações normais. Modelo nominal local, '
         'NBR 6.1.8.2/6.5.2: as excentricidades físicas no plano e através da espessura '
         'são explicitamente omitidas, não canceladas. O ec continua ativo no Ct. '
         'N de entrada e saída usam y=b_chapa/2, z=0; My=Mz=0 nesse eixo nominal '
         'do corte terminal. Não representa equilíbrio de carregamento no CG físico.')
EXCLUSIONS = [
    'Não verifica raiz da chapa, soldas, apoio, estabilidade global da barra ou da chapa de nó.',
    'Compressão, fadiga, sismo, reversão cíclica, N+V+M, torção, abertura, enchimentos e duas cantoneiras estão fora do domínio.',
    'Carregamento ou terminal no CG físico exige outro método acoplado de contato e ações secundárias; não é aprovado como N-only.',
    'Não inclui chapas poligonais, alargamento de largura, múltiplas linhas, furos alongados ou crédito de atrito.',
    'A recomendação de 50% usa resistência local da barra tracionada; não fornece resistência global à compressão nem resolve a exceção por esbeltez.',
]
# Exact Table 14/16 systems; metric M16 is not an imperial 5/8 inch bolt.
HOLES = {12.7: 14.2875, 15.875: 17.4625, 19.05: 20.6375, 22.225: 23.8125,
         25.4: 28.575, 28.575: 31.75, 31.75: 34.925, 36.: 39.,
         16.: 18., 20.: 22., 22.: 24., 24.: 27., 27.: 30., 30.: 33.}
EDGES = {12.7: 19., 15.875: 22., 19.05: 25., 22.225: 28., 25.4: 32.,
         28.575: 38., 31.75: 41., 36.: 45., 16.: 22., 20.: 26.,
         22.: 28., 24.: 30., 27.: 34., 30.: 38.}
METRIC_DIAMETERS = {16., 20., 22., 24., 27., 30., 36.}


@dataclass(frozen=True)
class AxialSingleAngle:
    project: str = '1L76 × 6,35 / CH100 × 12,5 · N=100 kN'
    profile_name: str = 'L 76 × 6,35'
    profile_source: str = 'Souza PDF162: Ag=18,58/2=9,29 cm², t=6,35 mm, ec=2,13 cm; PDF160 confirma Ag/ec e arredonda t=6,3 mm'
    leg: float = 76.0
    t: float = 6.35
    Ag: float = 929.0
    ec: float = 21.3
    root_radius: float = 6.0
    angle_steel: str = 'ASTM A36'
    plate_steel: str = 'ASTM A36'
    plate_width: float = 100.0
    plate_t: float = 12.5
    bolt: str = 'ASTM F3125 A325'
    db: float = 16.0
    n: int = 3
    pitch: float = 50.0
    gauge: float = 35.0
    angle_end: float = 35.0
    plate_end: float = 35.0
    terminal_extension: float = 30.0
    drilled: bool = True
    threads_excluded: bool = False
    pretensioned: bool = False
    exposure: str = 'painted'
    tool_radius: float = 18.0
    fabrication_clearance: float = 2.0
    N: float = 100000.0
    V: float = 0.0
    M: float = 0.0
    torsion: float = 0.0
    static: bool = True
    normal_combination: bool = True
    angle_count: int = 1
    minimum_force: bool = True
    recommend_half_capacity: bool = False
    notes: str = ''
    angle_catalog_id: str = ''
    angle_root_source: str = ''
    angle_root_confirmed: bool = False


    @property
    def hole_diameter(self):
        """Physical standard-hole diameter; unknown systems never get a guessed size."""
        return HOLES.get(self.db) if finite_real(self.db) else None

    @property
    def fixed_assumptions(self):
        return {'topology': 'single_equal_leg_angle_rectangular_plate_one_centered_row',
                'load_model': LOAD_MODEL,
                'physical_CG_eccentricity': 'both_y_and_z_disclosed_omitted_by_6.1.8.2_and_6.5.2_not_cancelled',
                'actual_CG_export_permitted': False,
                'terminal': 'N_on_bolt_and_plate_axis_M0_at_centered_orthogonal_cut',
                'nominal_axis': 'y_plate_width_over_2_z0',
                'angle_face': 'positive_z_outstanding_leg_positive_z',
                'contact': 'firm_direct_contact_no_fillers',
                'angle_count': 1, 'shear_planes': 1, 'slip_resistance_credit': False,
                'plate_section': 'actual_constant_width_Ct1_not_a_splice_plate',
                'bearing_deformation_is_design_limitation': True,
                'net_hole_policy': 'Table14_plus_2mm_unless_drilled',
                'connected_area': 'half_single_angle_catalog_Ag_by_equal_leg_bisector_including_shared_root',
                'shear_lag_ec': 'physical_centroid_to_connected_face_retained_in_Ct',
                'angle_far_toe': 'unfolded_gauge_plus_leg_minus_thickness',
                'plate_side_blocks': 'alternative_paths_each_full_enclosed_bolt_force',
                'normal_ultimate_combinations_only': True,
                'gamma_a1': GAMMA_A1, 'gamma_a2': GAMMA_A2}

    def to_dict(self):
        errors = input_errors(self)
        if not errors and self.angle_count != 1:
            errors.append('angle_count: a família nativa exige exatamente uma cantoneira.')
        if errors:
            raise ValueError('; '.join(errors))
        return {'schema_version': 1, 'connection_type': CONNECTION_TYPE,
                'component_version': COMPONENT_VERSION, 'connection': native_connection(self),
                'units': dict(UNITS), 'fixed_assumptions': self.fixed_assumptions}

    @classmethod
    def from_dict(cls, data):
        required = {'schema_version', 'connection_type', 'component_version',
                    'connection', 'units', 'fixed_assumptions'}
        if not isinstance(data, dict) or set(data) != required:
            raise ValueError('Projeto axial 1L: campos ausentes ou desconhecidos.')
        if (type(data['schema_version']) is not int or data['schema_version'] != 1 or
                data['connection_type'] != CONNECTION_TYPE or data['component_version'] != COMPONENT_VERSION):
            raise ValueError('Família ou versão axial 1L incompatível.')
        raw = data['connection']
        if not valid_native_fields(raw, cls):
            raise ValueError('Dados axial 1L incompletos ou desconhecidos.')
        candidate = cls(**raw)
        canonical = candidate.to_dict()
        # Compare types as well as values: True is not the canonical numeric 1.
        if not _exact(data['units'], canonical['units']) or not _exact(data['fixed_assumptions'], canonical['fixed_assumptions']):
            raise ValueError('Unidades ou premissas incompatíveis; nenhuma conversão silenciosa.')
        return candidate


def _exact(a, b):
    if type(a) is not type(b):
        return False
    if isinstance(b, dict):
        return set(a) == set(b) and all(_exact(a[k], b[k]) for k in b)
    return a == b


def presets():
    base = AxialSingleAngle()
    return {'1L76 × 6,35 · CH100 × 12,5 · M16 · N=100 kN': base,
            '1L · carga nula real e candidato mínimo 45 kN': replace(base, project='1L · N real=0', N=0.),
            '1L · mesma geometria / N=200 kN / falha resistente': replace(base, project='1L · N=200 kN', N=200000.)}


def input_errors(c):
    if not isinstance(c, AxialSingleAngle):
        return ['A entrada deve ser AxialSingleAngle.']
    strings = {'project', 'profile_name', 'profile_source', 'angle_steel', 'plate_steel', 'bolt', 'exposure', 'notes'}
    bools = {'drilled', 'threads_excluded', 'pretensioned', 'static',
             'normal_combination', 'minimum_force', 'recommend_half_capacity'}
    errors = []
    for field in fields(c):
        key, value = field.name, getattr(c, field.name)
        if key in strings | CATALOG_STRINGS:
            if not isinstance(value, str):
                errors.append(key + ': texto obrigatório.')
        elif key in bools | CATALOG_BOOLS:
            if type(value) is not bool:
                errors.append(key + ': booleano explícito obrigatório.')
        elif key in {'n', 'angle_count'}:
            if type(value) is not int or not 1 <= value <= 100:
                errors.append(key + ': inteiro entre 1 e 100 obrigatório (limite computacional).')
        elif not finite_real(value):
            errors.append(key + ': número real finito obrigatório.')
        elif key in {'N', 'V', 'M', 'torsion', 'terminal_extension'}:
            pass  # Preserve signed actions and invalid terminal geometry for visible checks.
        elif key in {'root_radius', 'fabrication_clearance', 'ec'}:
            if value < 0:
                errors.append(key + ': número não negativo obrigatório.')
        elif value <= 0:
            errors.append(key + ': dimensão/área positiva obrigatória.')
    return errors + (identity_errors(c, 1) if not errors else [])


def _safe(value):
    """JSON-safe diagnostic payload; non-finite numbers become null, never strings."""
    if isinstance(value, (float, int)) and not isinstance(value, bool):
        return value if finite_real(value) else None
    if isinstance(value, dict):
        return {str(k): _safe(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [_safe(v) for v in value]
    return value if value is None or isinstance(value, (str, bool)) else repr(value)


def _issue(out, identifier, severity, message, **metadata):
    out['issues'].append(dict(id=identifier, severity=severity, message=message, **metadata))


def _checked(value, description):
    if not finite_real(value):
        raise ArithmeticError(description + ': resultado não finito/overflow.')
    return value


def _positive(value, description):
    _checked(value, description)
    if value <= 0:
        raise ArithmeticError(description + ': área/resistência não positiva.')
    return value


def bolt_shear_resistance(db, fub, threads_excluded=False, grip_factor=1., common=False):
    coefficient = .56 if threads_excluded and not common else .45
    return coefficient * (math.pi * db * db / 4) * fub / GAMMA_A2 * grip_factor


def bearing_resistance(db, clear_distance, thickness, fu):
    return min(1.2 * clear_distance, 2.4 * db) * thickness * fu / GAMMA_A2


def block_resistance(Agv, Anv, Ant, fy, fu, Cts=1.):
    return (min(.6 * fu * Anv, .6 * fy * Agv) + Cts * fu * Ant) / GAMMA_A2


def terminal_resultants(c, reference_x=None, reference_y=None, N=None, reference_z=None):
    """Transport the NOMINAL +N x resultant with r×N, never the physical CG.

    N defaults to unchanged actual action; candidate cases can supply their N.
    The reference defaults to the centered orthogonal terminal section (z=0).
    My=(0-reference_z)N; Mz=-(plate_width/2-reference_y)N. M aliases Mz.
    ``N`` retains its historical fourth positional slot; reference_z is optional.
    """
    errors = input_errors(c)
    if errors:
        raise ValueError('; '.join(errors))
    action = c.N if N is None else N
    axis_y = _checked(c.plate_width / 2, 'Eixo terminal')
    axis_x = _checked(c.plate_end + (c.n - 1) * c.pitch + c.angle_end + c.terminal_extension, 'Coordenada terminal')
    refx = axis_x if reference_x is None else reference_x
    refy = axis_y if reference_y is None else reference_y
    refz = 0. if reference_z is None else reference_z
    for key, value in [('N', action), ('reference_x', refx), ('reference_y', refy), ('reference_z', refz)]:
        if not finite_real(value):
            raise ValueError(key + ': número finito obrigatório.')
    my = _checked(-refz * action, 'My nominal transportado')
    mz = _checked(-(axis_y - refy) * action, 'Mz nominal transportado')
    return dict(x=axis_x, y=axis_y, z=0., reference_x=refx, reference_y=refy, reference_z=refz,
                N=action, V=0., M=mz, torsion=0., Fx=action, Fy=0., Fz=0.,
                Mx=0., My=my, Mz=mz, actual_CG_export_permitted=False,
                model=LOAD_MODEL, moment_units='N mm',
                valid_for_input=(action >= 0 and c.N >= 0 and c.V == c.M == c.torsion == 0 and c.static and
                                 c.normal_combination and c.angle_count == 1 and c.n >= 2 and
                                 c.terminal_extension > 0))


def _geometry(c, out):
    dh = c.hole_diameter
    if dh is None:
        _issue(out, 'bolt_diameter', 'outside_scope', 'Diâmetro/sistema fora das tabelas 14 e 16 implementadas.')
        return None
    dn = dh + (0. if c.drilled else 2.)
    xs = [_checked(c.plate_end + i * c.pitch, 'Coordenada de parafuso') for i in range(c.n)]
    end = _checked(xs[-1] + c.angle_end, 'Extremidade da cantoneira')
    terminal = _checked(end + c.terminal_extension, 'Corte terminal')
    y = c.plate_width / 2
    grip = _checked(c.t + c.plate_t, 'Pega')
    raw_grip = _checked(1 - .01 * max(0., grip - 5 * c.db) / 1.5, 'Fator de pega')
    exempt = c.pretensioned and c.bolt in {'ASTM F3125 A325', 'ASTM F3125 A490'}
    factor = 1. if exempt else max(0., raw_grip)
    g = dict(valid=False, bolt_x=xs, bolt_y=y, angle_end_x=end, terminal_x=terminal,
             bolt_interface_z=c.plate_t / 2, nominal_axis_y=y, nominal_axis_z=0.,
             plate_free_end_x=0., plate_y_min=0., plate_y_max=c.plate_width,
             plate_z_min=-c.plate_t / 2, plate_z_max=c.plate_t / 2,
             angle_heel_y=y - c.gauge, angle_toe_y=y - c.gauge + c.leg,
             angle_physical_centroid_y=y - c.gauge + c.ec,
             angle_physical_centroid_z=c.plate_t / 2 + c.ec,
             physical_CG_offset_from_bolt_axis=c.ec - c.gauge,
             physical_CG_offset_y_omitted=c.ec - c.gauge,
             physical_CG_offset_z_omitted=c.plate_t / 2 + c.ec,
             physical_CG_offsets_cancelled=False, ec_shear_lag=c.ec,
             connected_leg_to_plate_midplanes=(c.plate_t + c.t) / 2,
             hole_diameter=dh, net_hole_diameter=dn, grip=grip, lc=(c.n - 1) * c.pitch,
             grip_factor=factor, grip_factor_raw=raw_grip, grip_pretension_exemption=exempt,
             angle_toe_edge=c.leg - c.gauge, angle_far_toe_unfolded=c.gauge + c.leg - c.t,
             tool_required=c.tool_radius + c.fabrication_clearance,
             root_hole_clear=c.gauge - c.t - c.root_radius - dh / 2,
             root_tool_clear=c.gauge - c.t - c.root_radius,
             physical_shear_planes=1, physical_angle_count=1, checks=[], errors=[])
    out['geometry'] = g

    def scalar(key, actual, limit, relation, label, category='detail', reference='NBR 6.3.9–6.3.12'):
        _checked(actual, key)
        _checked(limit, key + ': limite')
        passed = (actual > limit if relation == '>' else
                  actual >= limit - TOL * max(1., abs(limit)) if relation == '>=' else
                  actual <= limit + TOL * max(1., abs(limit)))
        g['checks'].append(dict(id=key, label=label, actual=actual, limit=limit, relation=relation,
                                status='PASS' if passed else 'FAIL', category=category,
                                units='mm²' if key.startswith('profile_area') else 'mm', reference=reference))
        if not passed:
            if category == 'geometry':
                g['errors'].append(key)
            _issue(out, key, 'invalid_geometry' if category == 'geometry' else 'detail_fail',
                   f'{label}: {actual:g}; requerido {relation} {limit:g}.', reference=reference)

    scalar('leg_thickness', c.leg, c.t, '>', 'Aba maior que espessura', 'geometry')
    scalar('root_envelope', c.t + c.root_radius, c.leg, '<=', 'Raiz dentro da aba', 'geometry')
    scalar('effective_connection_length', g['lc'], 0., '>', 'Comprimento efetivo entre primeiro e último parafuso', 'geometry', 'NBR 5.2.5(c)')
    scalar('plate_physical_net', c.plate_width - dh, 0., '>', 'Furo contido na largura real da chapa', 'geometry')
    scalar('angle_toe_net', c.leg - c.gauge - dn / 2, 0., '>', 'Ligamento líquido até a ponta livre da aba', 'geometry')
    scalar('root_hole_clear', g['root_hole_clear'], 0., '>=', 'Furo livre da raiz', 'geometry')
    scalar('physical_pitch_clear', c.pitch - dh, 0., '>', 'Furos distintos', 'geometry')
    scalar('terminal_beyond_angle', terminal - end, 0., '>', 'Corte terminal além da ponta da cantoneira', 'geometry')
    scalar('terminal_beyond_bolts', terminal - xs[-1] - dh / 2, 0., '>', 'Corte terminal em material contínuo além dos furos', 'geometry')
    scalar('ec_lower', c.ec, c.t / 2, '>=', 'CG dentro do envelope material', 'geometry')
    scalar('ec_upper', c.ec, c.leg / 2, '<=', 'CG compatível com cantoneira de abas iguais', 'geometry')
    # Broad physical consistency bounds, not a replacement for catalog properties.
    # Rectangular two-leg union +/- bounding squares for two rounded toes/root.
    sharp = _checked(2 * c.leg * c.t - c.t * c.t, 'Área sintética de comparação')
    low = max(0., sharp - 2 * c.t * c.t)
    high = sharp + c.root_radius * c.root_radius
    g.update(profile_sharp_corner_comparator=sharp, profile_area_lower_bound=low, profile_area_upper_bound=high)
    scalar('profile_area_lower', c.Ag, low, '>=', 'Área fornecida: limite geométrico inferior', 'geometry', 'Consistência física, sem substituir Ag de catálogo')
    scalar('profile_area_upper', c.Ag, high, '<=', 'Área fornecida: limite geométrico superior', 'geometry', 'Consistência física, sem substituir Ag de catálogo')
    scalar('pitch_min', c.pitch, max(2.7 * c.db, dh + c.db), '>=', 'Passo mínimo')
    thin = min(c.t, c.plate_t)
    pmax = min(14 * thin, 180.) if c.exposure == 'weathering' else min(24 * thin, 300.)
    scalar('pitch_max', c.pitch, pmax, '<=', 'Passo máximo para exposição')
    if c.pitch < 3 * c.db:
        _issue(out, 'pitch_preferred', 'warning', 'Passo menor que a preferência 3db; o mínimo obrigatório é verificado separadamente.')
    emin = EDGES[c.db]
    for key, edge, t in [('angle_end', c.angle_end, c.t), ('plate_end', c.plate_end, c.plate_t),
                         ('angle_toe', c.leg - c.gauge, c.t), ('plate_lower_side', y, c.plate_t),
                         ('plate_upper_side', c.plate_width - y, c.plate_t)]:
        scalar(key + '_ligament', edge - dn / 2, 0., '>', key + ': ligamento líquido real', 'geometry')
        scalar(key + '_min', edge, emin, '>=', key + ': limite conservador de borda desta rota', reference='NBR tabela16 admite redução com6.3.3.3; exceção não invocada nesta rota')
        scalar(key + '_max', edge, min(12 * t, 150.), '<=', key + ': borda máxima')
        scalar(key + '_hardware', edge, g['tool_required'], '>=', key + ': envelope de montagem', reference='Envelope informado de ferramenta/cabeça/porca/arruela')
    scalar('root_tool_access', g['root_tool_clear'], g['tool_required'], '>=', 'Acesso de ferramenta junto à raiz', reference='Envelope informado; raio interno deve corresponder ao perfil adquirido')
    scalar('tool_covers_hole', c.tool_radius, dh / 2, '>=', 'Envelope físico ao menos igual ao raio do furo', reference='Consistência de montagem')
    scalar('adjacent_tool_clearance', c.pitch, 2 * c.tool_radius + c.fabrication_clearance, '>=', 'Envelope entre parafusos', reference='Envelope combinado informado')
    for k in range(1, c.n + 1):
        for component, loaded_end in [('angle', c.angle_end), ('plate', c.plate_end)]:
            scalar(f'{component}_block_net_k{k}', loaded_end + (k - 1) * c.pitch - (k - .5) * dn,
                   0., '>', component + f': ligamento líquido do bloco com {k} furos', 'geometry')
    g['valid'] = not g['errors']
    return g


def _row(out, identifier, label, component, mechanism, case, resistance, fraction,
         reference, area_values=(), method_applicable=True, **metadata):
    """Every primitive survives, including undefined/nonpositive numerical resistance."""
    demand = case['N'] * fraction
    valid = (finite_real(resistance) and resistance > 0 and finite_real(demand) and
             finite_real(fraction) and fraction > 0 and all(finite_real(x) and x > 0 for x in area_values))
    applicable = finite_real(demand) and demand >= 0
    utilization = demand / resistance if valid and applicable else None
    equivalent = resistance / fraction if valid else None
    if valid and ((applicable and not finite_real(utilization)) or not finite_real(equivalent)):
        valid = False
        utilization = equivalent = None
    if not valid and method_applicable:
        _issue(out, identifier + '__' + case['id'] + '_numeric', 'numerical_failure',
               label + ': solicitação, área, resistência ou razão inválida; resultado sem aprovação.')
    row = dict(id=identifier + '__' + case['id'], primitive_id=identifier, label=label,
               component=component, mechanism=mechanism, case_id=case['id'],
               demand=demand, resistance=resistance, utilization=utilization,
               status='PASS' if valid and applicable and utilization <= 1 + TOL else 'FAIL',
               equivalent_capacity_N=equivalent, demand_fraction=fraction,
               reference=reference, numerical_valid=valid, action_applicable=applicable, method_applicable=method_applicable, **metadata)
    out['checks'].append(row)
    return row


def _calculate(c, out, g, angle, plate, fub):
    dn = g['net_hole_diameter']
    An = c.Ag - dn * c.t
    Ac = c.Ag / 2  # Equal-leg bisector allocation, including the shared rounded root.
    raw_ct = 1 - c.ec / g['lc'] if g['lc'] > 0 else None
    Ct = max(Ac / c.Ag, raw_ct) if raw_ct is not None else None
    Ae = Ct * An if Ct is not None else None
    pag, pan = c.plate_width * c.plate_t, (c.plate_width - dn) * c.plate_t
    ary = c.Ag * angle.fy / GAMMA_A1
    arf = Ae * angle.fu / GAMMA_A2 if Ae is not None else None
    pry, prf = pag * plate.fy / GAMMA_A1, pan * plate.fu / GAMMA_A2
    out['sections'] = dict(
        angle=dict(Ag=c.Ag, An=An, Ac=Ac, Ct_raw=raw_ct, Ct_floor=Ac / c.Ag, Ct=Ct, Ae=Ae,
                        ec=c.ec, lc=g['lc'], fy=angle.fy, fu=angle.fu,
                        connected_area_basis='Ag/2: bissetriz das abas iguais, incluindo raiz compartilhada',
                        property_basis='provided_catalog_or_custom_never_replaced_by_sharp_corner_formula',
                        profile_name=c.profile_name, profile_source=c.profile_source,
                        yield_capacity_N=ary, fracture_capacity_N=arf),
        plate=dict(Ag=pag, An=pan, Ct=1., Ae=pan, fy=plate.fy, fu=plate.fu,
                   real_width=c.plate_width, thickness=c.plate_t, yield_capacity_N=pry,
                   fracture_capacity_N=prf, splice_cap_applied=False,
                   basis='Largura retangular real; NBR5.2.5(a), errata2025 e6.5.3'),
        terminal=dict(Ag=pag, An=pag, Ct=1., Ae=pag, x=g['terminal_x'], y=g['bolt_y'], z=0.,
                      hole_count=0, section_orientation='orthogonal_to_x',
                      physical_continuity=(g['terminal_x'] > g['angle_end_x'] and
                                           g['terminal_x'] > g['bolt_x'][-1] + g['hole_diameter'] / 2)))
    cases = [dict(id='actual', label='N real informado', N=c.N)]
    if c.minimum_force and c.N >= 0 and c.N < 45000:
        cases.append(dict(id='minimum_45kN', label='Candidato mínimo 45 kN · NBR6.1.5.2', N=45000.))
    if c.recommend_half_capacity:
        if arf is not None and finite_real(ary) and finite_real(arf) and min(ary, arf) > 0:
            member = min(ary, arf)
            cases.append(dict(id='recommended_half', label='Recomendação opcional 50% Nt,Rd · NBR6.1.5.3',
                              N=.5 * member, member_capacity_N=member,
                              member_governing='angle_gross_yield' if ary <= arf else 'angle_effective_net_fracture',
                              applicability='barra tracionada; esbeltez máxima/compressão não inferidas'))
        else:
            _issue(out, 'recommendation_undefined', 'outside_scope' if raw_ct is None else 'numerical_failure', 'Candidato de 50% não calculável sem resistência positiva da barra.')
    out['cases'] = cases
    N_design = max(x['N'] for x in cases)
    actions = [dict(case_id=case['id'], **terminal_resultants(c, N=case['N'])) for case in cases]
    out['load_model'] = dict(model=LOAD_MODEL, description=SCOPE,
                            N_actual=c.N, N_design=N_design, axis_y=g['bolt_y'], axis_z=0.,
                            physical_CG_y=g['angle_physical_centroid_y'],
                            physical_CG_z=g['angle_physical_centroid_z'],
                            physical_CG_offset_omitted=g['physical_CG_offset_from_bolt_axis'],
                            physical_CG_offset_y_omitted=g['physical_CG_offset_y_omitted'],
                            physical_CG_offset_z_omitted=g['physical_CG_offset_z_omitted'],
                            physical_CG_offsets_cancelled=False,
                            ec_shear_lag=c.ec,
                            connected_leg_to_plate_midplanes=g['connected_leg_to_plate_midplanes'],
                            actual_CG_export_permitted=False,
                            actual_actions=dict(N=c.N, V=c.V, M=c.M, torsion=c.torsion),
                            terminal_actions=actions, terminal_actual=actions[0],
                            terminal_actions_valid_for_actual_input=actions[0]['valid_for_input'],
                            terminal_description=('resultantes do modelo nominal' if actions[0]['valid_for_input'] else
                                                  'candidato nominal; resultantes reais fora do domínio não avaliadas'),
                            angle_bolt_direction='+x', plate_bolt_direction='-x',
                            each_angle_fraction=1., each_bolt_fraction=1 / c.n,
                            each_plane_fraction=1 / c.n, physical_shear_planes=1,
                            bolt_tension=0., plate_bolt_force_sum_x=-c.N,
                            angle_bolt_force_sum_x=c.N,
                            connection_force_residual_x=0., terminal_force_residual_x=0.,
                            moment_reference='centered orthogonal terminal; r×N for another reference',
                            omitted_eccentricity_basis='6.1.8.2/6.5.2; ambos os afastamentos omitidos, não cancelados; não é equilíbrio no CG físico')
    diagnostic_my = c.N * g['physical_CG_offset_z_omitted']
    diagnostic_mz = -c.N * g['physical_CG_offset_y_omitted']
    out['load_model']['diagnostic_only_actual_CG_moments'] = dict(
        My=diagnostic_my, Mz=diagnostic_mz, units='N mm', used_in_resistance_checks=False,
        actual_CG_export_permitted=False,
        description='Consequências geométricas de OUTRO modelo; não combinar com verificações nominais N-only.',
        numerical_valid=finite_real(diagnostic_my) and finite_real(diagnostic_mz))
    if not finite_real(diagnostic_my) or not finite_real(diagnostic_mz):
        _issue(out, 'physical_CG_diagnostic_overflow', 'numerical_failure',
               'Momento geométrico diagnóstico não finito; não constitui uma ação do modelo nominal.')
    for case in cases:
        _row(out, 'angle_gross_yield', 'Cantoneira única · escoamento bruto', 'angle', 'gross_yield', case,
             ary, 1., 'NBR5.2.2(a)', (c.Ag,), areas={'Ag': c.Ag}, path='whole_angle_section')
        _row(out, 'angle_effective_net_fracture', 'Cantoneira única · ruptura líquida efetiva', 'angle', 'net_fracture', case,
             arf, 1., 'NBR5.2.2(b),5.2.3–5.2.5(c)', (An, Ae), areas={'Ag': c.Ag, 'An': An, 'Ae': Ae}, Ct=Ct,
             method_applicable=Ct is not None, path='whole_angle_one_hole', bolt_indices=list(range(1, c.n + 1)))
        _row(out, 'plate_gross_yield', 'Chapa real · escoamento bruto', 'plate', 'gross_yield', case,
             pry, 1., 'NBR6.5.3(a)', (pag,), areas={'Ag': pag}, path='real_full_width_section')
        _row(out, 'plate_net_fracture', 'Chapa real · ruptura líquida', 'plate', 'net_fracture', case,
             prf, 1., 'NBR6.5.3(b),5.2.5(a)/Er1:2025', (pan,), areas={'An': pan, 'Ae': pan}, Ct=1.,
             path='real_full_width_one_hole', splice_cap_applied=False)
        _row(out, 'plate_terminal_yield', 'Corte terminal contínuo · escoamento bruto', 'plate', 'gross_yield', case,
             pry, 1., 'NBR6.5.3(a); corte nominal N-only', (pag,), areas={'Ag': pag},
             path='terminal_unperforated_cut', section_x=g['terminal_x'], section_y=g['bolt_y'], section_z=0.,
             nominal_M=0., nominal_My=0., nominal_Mz=0., nominal_V=0.)
        _row(out, 'plate_terminal_fracture', 'Corte terminal contínuo · ruptura', 'plate', 'net_fracture', case,
             pag * plate.fu / GAMMA_A2, 1., 'NBR6.5.3(b); An=Ag sem furos', (pag,), areas={'An': pag, 'Ae': pag},
             path='terminal_unperforated_cut', section_x=g['terminal_x'], Ct=1.)
        for i, x in enumerate(g['bolt_x'], 1):
            for plane, excluded in [(1, c.threads_excluded)]:
                coefficient = .56 if excluded and c.bolt != 'ASTM A307' else .45
                rb = bolt_shear_resistance(c.db, fub, excluded, g['grip_factor'], common=c.bolt == 'ASTM A307')
                _row(out, f'bolt_{i}_plane_{plane}', f'Parafuso {i} · plano de corte {plane}', 'bolts', 'bolt_shear',
                     case, rb, 1 / c.n, 'NBR6.3.3.2,6.3.7',
                     shear_plane=plane, threads_excluded=excluded, coefficient=coefficient, fub=fub,
                     grip_factor=g['grip_factor'], bolt_indices=[i], x=x, y=g['bolt_y'],
                     path='angle_plate_interface')
            for component, thickness, fu, direction, clear, fraction in [
                ('angle', c.t, angle.fu, '+x', c.angle_end - g['hole_diameter'] / 2 if i == c.n else c.pitch - g['hole_diameter'], 1 / c.n),
                ('plate', c.plate_t, plate.fu, '-x', c.plate_end - g['hole_diameter'] / 2 if i == 1 else c.pitch - g['hole_diameter'], 1 / c.n)]:
                rb = bearing_resistance(c.db, clear, thickness, fu)
                _row(out, f'{component}_bearing_{i}', f'{component} · contato/rasgamento no furo {i}', component,
                     'bearing', case, rb, fraction, 'NBR6.3.3.3(a)', (clear,), clear_distance=clear,
                     thickness=thickness, fu=fu, bolt_indices=[i], loaded_direction=direction,
                     path='loaded_free_end' if (direction == '+x' and i == c.n) or (direction == '-x' and i == 1) else 'next_hole_in_force_direction')
        for component, t, fy, fu, direction, end, share, paths in [
            ('angle', c.t, angle.fy, angle.fu, '+x', c.angle_end, 1.,
             [('toe', c.leg - c.gauge), ('far_toe_unfolded', c.gauge + c.leg - c.t)]),
            ('plate', c.plate_t, plate.fy, plate.fu, '-x', c.plate_end, 1.,
             [('lower_side', g['bolt_y']), ('upper_side', c.plate_width - g['bolt_y'])])]:
            for path, width in paths:
                for k in range(1, c.n + 1):
                    indices = list(range(c.n - k + 1, c.n + 1)) if direction == '+x' else list(range(1, k + 1))
                    Lv = end + (k - 1) * c.pitch
                    Agv, Anv, Ant = Lv * t, (Lv - (k - .5) * dn) * t, (width - dn / 2) * t
                    rd = block_resistance(Agv, Anv, Ant, fy, fu)
                    _row(out, f'{component}_block_{path}_k{k}', f'{component} · bloco {path} · {k}/{c.n} furos',
                         component, 'block_tearout', case, rd, share * k / c.n, 'NBR6.5.6/Fig16(b)',
                         (Agv, Anv, Ant), areas={'Agv': Agv, 'Anv': Anv, 'Ant': Ant}, Cts=1.,
                         path=path, k=k, bolt_indices=indices, loaded_direction=direction,
                         gross_shear_length=Lv, net_shear_length=Lv - (k - .5) * dn,
                         gross_tension_width=width, net_tension_width=width - dn / 2,
                         thickness=t, physical_shear_surfaces=1, free_end_x=g['angle_end_x'] if direction == '+x' else 0.,
                         shear_yield_branch_N=(.6 * fy * Agv + fu * Ant) / GAMMA_A2,
                         shear_fracture_branch_N=(.6 * fu * Anv + fu * Ant) / GAMMA_A2,
                         demand_basis='full_enclosed_bolt_force_alternative_side_paths' if component == 'plate' else 'enclosed_bolts_in_one_angle',
                         heel_is_free_edge=False, alternative_path=True)
    # A single physical plane per bolt; no pair or mixed-thread bookkeeping.
    rb = bolt_shear_resistance(c.db, fub, c.threads_excluded, g['grip_factor'], c.bolt == 'ASTM A307')
    out['bolts'] = dict(plane_capacities_N=[rb], single_plane_capacity_N=rb,
                        physical_shear_planes=1, sum_group_capacity_N=c.n * rb,
                        compatible_uniform_group_capacity_N=c.n * rb,
                        note='Um plano físico por parafuso; N/n no plano e em cada material, sem divisão por dois.')


def _finalize(out):
    numerical = any(i['severity'] == 'numerical_failure' for i in out['issues'])
    invalid = any(i['severity'] == 'invalid_input' for i in out['issues'])
    geometry = any(i['severity'] == 'invalid_geometry' for i in out['issues'])
    outside = any(i['severity'] == 'outside_scope' for i in out['issues'])
    detail = any(i['severity'] == 'detail_fail' for i in out['issues'])
    complete = bool(out['checks']) and not (invalid or geometry or outside or numerical)
    failed = [r['id'] for r in out['checks'] if r['status'] == 'FAIL']
    eligible = [r for r in out['checks'] if r.get('numerical_valid') and r.get('utilization') is not None]
    governing = max(eligible, key=lambda row: row['utilization']) if eligible else None
    ties = [r['id'] for r in eligible if governing and math.isclose(r['utilization'], governing['utilization'], rel_tol=1e-10, abs_tol=1e-12)]
    capacities = [r for r in eligible if r.get('equivalent_capacity_N') is not None]
    cap_row = min(capacities, key=lambda row: row['equivalent_capacity_N']) if capacities else None
    out['global_pass'] = complete and not failed and not detail
    out['status'] = ('INVALID_INPUT' if invalid else 'NUMERICAL_FAILURE' if numerical else
                     'OUTSIDE_SCOPE' if outside else 'INVALID_GEOMETRY' if geometry else
                     'COMPLETE_CHECKS_FAIL' if failed else 'DETAILING_FAIL' if detail else
                     'COMPLETE_CHECKS_PASS_WITHIN_SCOPE' if complete else 'INCOMPLETE_CHECKS')
    out['summary'] = dict(complete_checks=complete, governing_id=governing['id'] if governing else None,
                          governing_capacity_N=cap_row['equivalent_capacity_N'] if cap_row else None,
                          capacity_governing_id=cap_row['id'] if cap_row else None,
                          utilization=governing['utilization'] if governing else None,
                          governing_ties=ties, failed_check_ids=failed, check_count=len(out['checks']),
                          numerical_failures_visible=numerical, detailing_pass=not detail)
    return _safe(out)


def evaluate(c):
    """Recompute only from the native connection; no supplied result is trusted."""
    out = dict(status='INVALID_INPUT', global_pass=False, issues=[], geometry={'valid': False},
               checks=[], cases=[], sections={}, load_model={}, summary={}, scope=SCOPE,
               exclusions=list(EXCLUSIONS), units=dict(UNITS), family=FAMILY,
               component_version=COMPONENT_VERSION, connection_type=CONNECTION_TYPE,
               inputs=_safe(asdict(c)) if isinstance(c, AxialSingleAngle) else _safe(c))
    errors = input_errors(c)
    if not errors:
        errors = missing_data_errors(c)
    if errors:
        for i, message in enumerate(errors):
            _issue(out, f'input_{i + 1}', 'invalid_input', message)
        return _finalize(out)
    out['fixed_assumptions'] = c.fixed_assumptions
    for bad, identifier, message in [
        (c.angle_count != 1, 'angle_count', 'Exige exatamente uma cantoneira, uma chapa e um plano de corte; topologia de duas faces fora do domínio.'),
        (not c.minimum_force and 0 <= c.N < 45000, 'minimum_force_disabled', 'Sem exceção de6.1.5.2 declarada nesta família, desativar o candidato obrigatório45kN impede aprovação para N<45kN.'),
        (c.N < 0, 'compression', 'N negativo é compressão, fora do modelo de tração; o valor real não é convertido em módulo.'),
        (any(x != 0 for x in (c.V, c.M, c.torsion)), 'outside_actions', 'V, M ou torção não nulos: ação informada preservada; verificações N-only não aprovam ações combinadas.'),
        (not c.static, 'nonstatic', 'A omissão de excentricidade de 6.1.8.2 exige solicitação estática sem fadiga.'),
        (not c.normal_combination, 'combination', 'Fatores desta rota são exclusivos de combinações normais.'),
        (c.exposure not in {'painted', 'weathering'}, 'exposure', 'Exposição deve ser painted ou weathering.'),
        (c.bolt == 'ASTM A307' and c.pretensioned, 'pretension_grade', 'A307 não recebe dispensa de pega por protensão de parafuso de alta resistência.'),
        (c.bolt == 'ASTM A307' and c.db in METRIC_DIAMETERS, 'bolt_grade_diameter', 'ASTM A307: a faixa implementada da tabelaA.3 usa diâmetros imperiais.')]:
        if bad:
            _issue(out, identifier, 'outside_scope', message)
    if c.n == 1:
        _issue(out, 'single_bolt_Ct', 'outside_scope', 'Um parafuso não define lc>0 para5.2.5(c); nenhum Ct aprovado por substituição.')
    for role, name, thickness in [('angle', c.angle_steel, c.t), ('plate', c.plate_steel, c.plate_t)]:
        material = STEELS.get(name)
        if material is None:
            _issue(out, role + '_material', 'outside_scope', role + ': aço não reconhecido.')
            continue
        supported = (material.rolled_allowed and material.profile_min <= thickness <= material.profile_max if role == 'angle'
                     else material.plate_allowed and material.plate_min <= thickness <= material.plate_max)
        if not supported:
            _issue(out, role + '_material_product', 'outside_scope', role + ': produto/espessura fora da faixa do aço selecionado.')
    if c.bolt not in BOLTS:
        _issue(out, 'bolt_material', 'outside_scope', 'Classe de parafuso não reconhecida.')
    try:
        g = _geometry(c, out)
        if g is not None and c.angle_steel in STEELS and c.plate_steel in STEELS and c.bolt in BOLTS:
            _calculate(c, out, g, STEELS[c.angle_steel], STEELS[c.plate_steel], BOLTS[c.bolt])
        else:
            out['cases'] = [dict(id='actual', label='N real informado', N=c.N)]
            out['load_model'] = dict(N_actual=c.N, actual_actions=dict(N=c.N, V=c.V, M=c.M, torsion=c.torsion))
    except (ArithmeticError, ValueError, TypeError) as error:
        _issue(out, 'calculation_failure', 'numerical_failure', str(error))
    return _finalize(out)
