"""Lossless physical envelopes for the complete bolted angle/gusset route.

This module never recalculates resistance. Public drawing and report exports
obtain their own current canonical evaluation before building these envelopes.
"""
from .display_precision import display_format
from collections import OrderedDict
from copy import deepcopy
from math import isfinite

COMPONENT_LABELS = {
    'bolts': 'Parafusos físicos', 'bolt': 'Parafuso / plano de corte',
    'angle_bearing': 'Contato do furo na cantoneira', 'gusset_bearing': 'Contato do furo na chapa',
    'angle': 'Cantoneira por face', 'angle_pair': 'Par 2L-T', 'gusset': 'Chapa de nó',
    'angle_weld': 'Soldas cantoneira–chapa', 'angle_welds': 'Soldas cantoneira–chapa',
    'root_weld': 'Soldas da raiz chapa–mesa', 'root_welds': 'Soldas da raiz chapa–mesa',
    'angle_substrate': 'Metal base da cantoneira junto à solda',
    'gusset_substrate': 'Metal base da chapa junto às soldas',
    'support': 'Apoio W receptor local', 'support_flange': 'Mesa W receptora local',
    'support_web': 'Alma W receptora local', 'w_flange': 'Mesa W receptora local',
    'w_web': 'Alma W receptora local',
    'gusset_root': 'Chapa na raiz', 'support_contact': 'Mesa W no contato dos filetes',
}
MECHANISM_LABELS = {
    'tension_yield':'Escoamento bruto · total',
    'Whitmore_yield':'Whitmore · escoamento', 'Whitmore_net':'Whitmore líquido · triagem conservadora',
    'normal_net_yield':'Seção normal líquida · escoamento', 'normal_net_rupture':'Seção normal líquida · ruptura',
    'nominal_perforated_yield':'Seção perfurada · escoamento nominal suplementar',
    'nominal_perforated_rupture':'Seção perfurada · ruptura nominal suplementar',
    'bolt_shear': 'Cisalhamento por plano físico', 'bearing': 'Contato e rasgamento por furo',
    'whitmore_yield': 'Whitmore · escoamento', 'whitmore_net': 'Whitmore líquido · triagem conservadora',
    'nominal_perforated_screen': 'Seção perfurada · triagem nominal suplementar',
    'tension': 'Tração bruta / efetiva', 'longitudinal_substrate': 'Metal base nas soldas longitudinais',
    'root_substrate': 'Metal base na raiz', 'weld_heel': 'Solda do calcanhar',
    'weld_toe': 'Solda da ponta', 'local_normal_yield': 'Escoamento normal local',
    'longitudinal_shear': 'Cisalhamento longitudinal', 'combined_yield': 'Escoamento combinado local',
    'local_bending': 'Flexão local da mesa',
    'gross_yield': 'Escoamento da seção bruta', 'gross_yielding': 'Escoamento da seção bruta',
    'tension_rupture': 'Ruptura da seção efetiva', 'effective_rupture': 'Ruptura da seção efetiva',
    'net_rupture': 'Ruptura da seção efetiva', 'net_fracture': 'Ruptura da seção efetiva',
    'block': 'Bloco / rasgamento e limite conservador',
    'block_shear': 'Bloco / rasgamento e limite conservador',
    'block_tearout': 'Bloco / rasgamento e limite conservador',
    'yield': 'Envelope de escoamento', 'yielding': 'Envelope de escoamento',
    'rupture': 'Envelope de ruptura', 'weld': 'Metal de solda',
    'weld_metal': 'Metal de solda', 'fillet_weld': 'Metal de solda',
    'substrate': 'Cisalhamento local do metal base',
    'shear': 'Cisalhamento do metal base', 'shear_yield': 'Escoamento por cisalhamento',
    'shear_rupture': 'Ruptura por cisalhamento', 'local_yield': 'Escoamento local',
    'local_yielding': 'Escoamento local', 'punching': 'Cisalhamento por puncionamento',
    'plane_stress': 'Interação local no plano', 'interaction': 'Interação local no plano',
    'normal_yield': 'Escoamento normal local',
}


def _finite(value):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return False
    try:
        return isfinite(value)
    except (OverflowError, ValueError):
        return False



def selected_angle(c, result=None):
    """Resolve identity for presentation without ever substituting a section.

    Evaluated geometry is authoritative. Catalog data are also available on a
    diagnostic export whose calculation could not build valid geometry.
    """
    from .angle_catalog import get_angle
    section = ((result or {}).get('geometry') or {}).get('angle_section')
    if section and section.get('id', section.get('name')) == c.angle_profile:
        return deepcopy(section)
    return get_angle(c.angle_profile)


def angle_transfer(section):
    """Catalog-centroid split; no default section or fabricated centroid."""
    if not section or not all(_finite(section.get(k)) for k in ('leg', 'centroid')) or section['leg'] <= 0:
        return None
    toe = section['centroid'] / section['leg']
    return {'heel': 1. - toe, 'toe': toe, 'projected_centroid': section['centroid'] - section['leg'] / 2.}


def angle_identity(section, fallback='não reconhecida'):
    if not section:
        return str(fallback)
    return str(section.get('manufacturer', 'Fabricante não informado')) + ' · ' + str(section.get('name', fallback)).replace('x', '×').replace('.', ',')


def angle_detail_disclosure(section):
    """Describe only supplied radii/flat, preserving unpublished-data gaps."""
    if not section:
        return 'Seção não reconhecida; propriedades e contorno não presumidos.'
    names = [('root_radius', 'Raio interno'), ('toe_radius', 'Raio da ponta'), ('toe_flat', 'Face plana da ponta')]
    parts = []
    for key, name in names:
        value = section.get(key)
        parts.append(name + (': ' + display_format(value, '.6g').replace('.', ',') + ' mm' if _finite(value) else ': não publicado'))
    if any(not _finite(section.get(key)) for key, _ in names):
        parts.append('Contorno nominal esquemático; cantos sem geometria presumida.')
    return '; '.join(parts)


def component_label(component):
    return COMPONENT_LABELS.get(str(component), str(component).replace('_', ' '))


def _governors(rows):
    finite = [row for row in rows if _finite(row.get('utilization'))]
    maximum = max((row['utilization'] for row in finite), default=None)
    # Unknown demand or capacity is an unresolved witness, never a hidden pass.
    unresolved = [row for row in rows if not _finite(row.get('utilization'))]
    tied = unresolved + [row for row in finite if row['utilization'] == maximum]
    return maximum, deepcopy(tied)


def _status(rows):
    if not rows:
        return 'NOT_EVALUATED'
    if any(row.get('status') == 'FAIL' or row.get('passed') is False for row in rows):
        return 'FAIL'
    if all(row.get('status') == 'PASS' or row.get('passed') is True for row in rows):
        return 'PASS'
    return 'NOT_VERIFIED'


def physical_envelopes(result):
    """Lossless envelopes, keeping total/member/plane force bases explicit."""
    groups=OrderedDict()
    count=(result.get('geometry') or {}).get('angle_count',1)
    for row in result.get('checks') or []:
        if not isinstance(row,dict):continue
        component=str(row.get('component','unidentified'))
        mechanism=str(row.get('mechanism','unidentified'))
        plane=(row.get('details') or {}).get('plane') if component=='bolt' else None
        basis=('total' if component!='angle' or mechanism in ('tension_yield','tension_rupture') else 'per_angle')
        if component=='bolt':basis='per_shear_plane'
        groups.setdefault((component,mechanism,plane,basis),[]).append(row)
    out=[]
    for (component,mechanism,plane,basis),rows in groups.items():
        actual=[r for r in rows if r.get('case_id')=='actual' or r.get('case_kind')=='actual']
        maximum,governing=_governors(rows);actual_max,actual_governing=_governors(actual)
        label=component_label(component)
        if component=='angle':label='Cantoneira(s) · total do membro' if basis=='total' else 'Cantoneira · por L'
        if plane is not None:label+=' · plano '+str(plane)
        scope={'total':'N total da ligação','per_angle':'N/2 por L' if count==2 else 'N por L',
               'per_shear_plane':'N/(2n) por plano' if count==2 else 'N/n por plano'}[basis]
        out.append(dict(id=component+'__'+mechanism+('__plane_'+str(plane) if plane is not None else ''),
            component=component,component_label=label,mechanism=mechanism,
            mechanism_label=MECHANISM_LABELS.get(mechanism,mechanism.replace('_',' ')),
            plane=plane,face=None,load_basis=basis,force_scope=scope,
            units=rows[0].get('unit',''),utilization=maximum,adopted_utilization=maximum,
            actual_utilization=actual_max,status=_status(rows),actual_status=_status(actual),
            governing=governing,governing_ties=deepcopy(governing),adopted_governing_ties=deepcopy(governing),
            actual_governing=actual_governing,actual_governing_ties=deepcopy(actual_governing),
            governing_ids=[x.get('id') for x in governing],member_ids=[x.get('id') for x in rows],members=deepcopy(rows)))
    return out


def governing_description(row):
    """Unambiguous short physical witness, including every available location."""
    parts = [str(row.get('id', 'sem identificação'))]
    # The stable primitive ID already contains the case and physical point.
    for key in ('face', 'side', 'cut_id', 'section_id', 'point', 'location', 'x_mm', 'y_mm'):
        if row.get(key) is not None:
            parts.append(key + '=' + str(row[key]))
    metadata = row.get('metadata') or {}
    for key in ('y', 'x', 'x_interval', 'M_bound', 'sigma', 'tau', 'side'):
        if key in metadata:
            parts.append(key + '=' + str(metadata[key]))
    return '; '.join(parts)
