"""Single solid rectangular key: two opposed fillet weld-metal component.

NBR 8800:2024 corrected 2025 prescribes full concrete-capacity actions and
scalar weld resistance. DG1 3e Ex4.7-5 supplies the two-centroid force couple.
No receiving-plate, connected-base-metal or complete key/base approval.
"""
from dataclasses import dataclass, asdict, fields
import hashlib
import json
import math
from .models import Issue, STEELS, finite_real
from .base_plate_details import fillet_dimensions

MODEL = 'two_opposed_fillets'
REF = ('NBR 8800:2024 corrigida 2025, 6.7.2.4, 6.2.2.2, 6.2.5.1/tabela 9, '
       '6.2.6.2/tabelas 8 e 11; AISC DG1 3ª ed., Ex.4.7-5, pp.88–89')
LIMITS = ('Metal dos dois filetes e requisitos numéricos de detalhamento são um componente separado. '
          'Metal-base junto à fusão na chave e na placa, transferência local e flexão da placa até '
          'chumbadores/contato, concreto da chave e bloco armado permanecem a complementar. '
          'Não aprova a ligação, o dispositivo ou a base completa.')
SUPPORTED_STEELS = frozenset(('ASTM A36','ASTM A572 Gr.42','ASTM A572 Gr.50','ASTM A572 Gr.55'))
FW, GW = 485.0, 1.35

@dataclass
class SingleKeyWeld:
    model: str = 'off'
    weld_type: str = 'fillet'
    layout: str = 'two_equal_continuous'
    measure: str = 'leg'
    size: float = 8.0
    real_length: float = 100.0
    effective_length: float = 100.0
    process: str = 'smaw_e7018'
    single_pass_confirmed: bool = False
    execution_ref: str = ''
    detail_confirmed: bool = False
    qualification_signature: str = ''

    @classmethod
    def from_dict(cls, data):
        if not isinstance(data,dict):
            raise ValueError('Dados da solda da chave devem ser um objeto.')
        extra=set(data)-{f.name for f in fields(cls)}
        if extra:raise ValueError('Campos não reconhecidos na solda da chave: '+', '.join(sorted(extra)))
        return cls(**data)


def validate_single_key_weld(c):
    u=getattr(c,'single_key_weld',None)
    if not isinstance(u,SingleKeyWeld):return [Issue('error','Dados inválidos da solda da chave.',REF,origin='single_key_weld')]
    issues=[]
    active=c.shear_path=='plate' and u.model!='off'
    for name in ('model','weld_type','layout','measure','process','execution_ref','qualification_signature'):
        if not isinstance(getattr(u,name),str):
            issues.append(Issue('error','Texto inválido da solda da chave: '+name,REF,origin='single_key_weld'))
    for name in ('size','real_length','effective_length'):
        value=getattr(u,name)
        if not finite_real(value) or (active and value<0):
            issues.append(Issue('error','Dimensão da solda da chave deve ser real finita e não negativa: '+name,REF,origin='single_key_weld'))
    for name in ('single_pass_confirmed','detail_confirmed'):
        if type(getattr(u,name)) is not bool:
            issues.append(Issue('error','Confirmação da solda da chave deve ser booleana: '+name,REF,origin='single_key_weld'))
    return issues


def qualification_signature(c):
    """Execution currency only, never verification of an engineering record.

    Bind physical leg, not interchangeable leg/throat input representation.
    """
    u=c.single_key_weld
    data={key:getattr(c,key) for key in ('N','M','V','shear_path','plate_steel','tp','lug_steel','lug_t',
          'lug_bh','lug_bv','grout_t','fck','db','a1','a2','stiffener_detail')}
    if data['stiffener_detail']=='web_pair_visual':data['stiffener_detail']='none'
    data.update(model_type=c.model_type,L=c.L,B=c.B,a=c.a)
    data['weld']=asdict(u)
    for key in ('detail_confirmed','qualification_signature','size','measure'):
        data['weld'].pop(key,None)
    try:
        leg=fillet_dimensions(u.size,u.measure)['leg']
        if not finite_real(leg):raise ValueError
        data['weld']['physical_leg_mm']=leg
    except (ValueError,OverflowError):
        data['weld']['invalid_size']=[u.size,u.measure]
    def stable(value):
        if isinstance(value,dict):return {k:stable(v) for k,v in value.items()}
        if isinstance(value,list):return [stable(v) for v in value]
        if type(value) in (int,float):return format(value,'.12g')
        return value
    return hashlib.sha256(json.dumps(stable(data),sort_keys=True,ensure_ascii=False,allow_nan=False).encode()).hexdigest()


def result_signature(c):
    """Bind displayed results to all persisted inputs, including qualification state."""
    return hashlib.sha256(json.dumps(asdict(c),sort_keys=True,ensure_ascii=False,
                                    allow_nan=False).encode()).hexdigest()


def result_is_current(c, result):
    data=getattr(result,'local_single_key_weld',result)
    try:return bool(data) and data.get('input_signature')==result_signature(c)
    except (ValueError,TypeError,OverflowError):return False


def detail_is_current(c):
    u=c.single_key_weld
    return bool(u.detail_confirmed and u.execution_ref.strip() and u.qualification_signature
                and u.qualification_signature==qualification_signature(c))


def single_key_weld_assumptions(c):
    if c.shear_path!='plate' or c.single_key_weld.model=='off':return []
    return [
        'Solda da chave: dois filetes iguais, retos e contínuos, um em cada face x=±tchave/2; '
        'raízes físicas em y=−bh/2 a +bh/2, sob a placa, sem retornos ou contorno fictício. '
        'Lreal=Leff=bh deve ser integralmente de tamanho pleno. A execução, integridade e acesso são documentados.',
        'Ações prescritas integrais NBR: Vw=(1,7fck/1,40)bh(H−g); Mw=Vw(H+g)/2, '
        'sem reduzir por Vreal, aço, atrito ou chumbadores. Reversão de V troca os sinais; '
        'em Vreal=0 conserva-se o envelope positivo de desenvolvimento de capacidade.',
        'Binário DG1 Ex.4.7-5: braço a=tchave+2z/3; qx=Vw/(2Leff), '
        'qz,±=±Mw/(aLeff), q=√(qx²+qz²). Compressão entra no vetor. '
        'NBR: qRd=0,6×485×(z/√2)/1,35, sem aumento direcional AISC. '
        'O braço dos centroides é local e não altera Mlocal=Mtopo+Vreal[tp+(H+g)/2].',
        LIMITS]


def component_values(Vw, Mw, length, thickness, leg):
    """Analytical two-line field for signed prescribed N and N·mm actions.

    This kernel permits independent source-action verification. Production
    adapter below always supplies the existing full native NBR actions.
    """
    for value in (Vw,Mw,length,thickness,leg):
        if not finite_real(value):raise ValueError('Campo de solda exige números reais finitos.')
    if min(length,thickness,leg)<=0:raise ValueError('Geometria do campo de solda deve ser positiva.')
    try:
        arm=thickness+2*leg/3
        throat=leg/math.sqrt(2)
        shear_denominator=2*length
        moment_denominator=arm*length
        if not all(math.isfinite(v) and v>0 for v in (arm,throat,shear_denominator,moment_denominator)):
            raise OverflowError
        qx=Vw/shear_denominator
        qz=Mw/moment_denominator
        q=math.hypot(qx,qz)
        rd=.6*FW*throat/GW
        values=dict(leg_mm=leg,throat_mm=throat,Leff_mm=length,arm_mm=arm,
            fw_MPa=FW,gamma_w2=GW,Vw_N=Vw,Mw_Nmm=Mw,qx_Npmm=qx,
            qz_plus_Npmm=qz,qz_minus_Npmm=-qz,q_resultant_Npmm=q,q_Rd_Npmm=rd,
            utilization=q/rd,residual_V_N=2*qx*length-Vw,residual_normal_N=0.,
            residual_M_Nmm=2*(arm/2)*qz*length-Mw)
        if not all(math.isfinite(v) for v in values.values()):raise OverflowError
    except (OverflowError,ZeroDivisionError):
        raise ValueError('Escala numérica do campo de solda excede a precisão finita; conferir unidades.') from None
    return values


def _rectangle_circle_intersects(box,x,y,radius):
    # Equality is contact at a hole/free edge, not intact fillet support.
    nearx=max(box[0],min(x,box[1]));neary=max(box[2],min(y,box[3]))
    return math.hypot(x-nearx,y-neary)<=radius


def add_single_key_weld_checks(c,r,add,lug):
    u=c.single_key_weld
    if c.shear_path!='plate' or u.model=='off':return {}
    out=dict(status='pending',weld_component_status='pending',attachment_complete=False,
             device_complete=False,complete=False,reasons=[],statuses={},model=u.model,
             reference=REF,scope=LIMITS,physical_segments=[],input_signature=result_signature(c))
    reasons=out['reasons'];fails=[];pending=[]
    def wait(text):
        reasons.append(text);pending.append(text)
        r.issues.append(Issue('pending',text,REF,origin='single_key_weld'))
    def fail(text):
        reasons.append(text);fails.append(text)
        r.issues.append(Issue('noncompliance',text,REF,origin='single_key_weld'))
    def check(key,name,sd,rd,unit,equation,variables):
        add('skw_'+key,'Solda da chave — '+name,sd,rd,unit,REF,equation,
            f'Sd={sd:.12g}; Rd={rd:.12g}',variables)
        passed=r.checks[-1].passed
        if not passed:fails.append(name)
        return passed
    def finish():
        out['status']=out['weld_component_status']='fail' if fails else 'pending' if pending else 'pass'
        r.issues.append(Issue('pending',LIMITS,REF,origin='single_key_weld_scope'))
        return out

    # Unknown physical topology cannot inherit any two-fillet strength.
    topology=(u.model==MODEL and u.weld_type=='fillet' and u.layout=='two_equal_continuous')
    if not topology:
        wait('Modelo limitado a dois filetes iguais contínuos de uma chave retangular maciça; '
             'CJP, filetes desiguais/interrompidos e outras topologias exigem modelo próprio.')
        return finish()
    if u.measure not in ('leg','throat'):
        wait('Informar perna ou garganta equivalente dos filetes.');return finish()
    if min(u.size,u.real_length,u.effective_length)<=0:
        wait('Informar tamanho, comprimento físico pleno e comprimento efetivo positivos de cada filete.');return finish()
    try:
        dimensions=fillet_dimensions(u.size,u.measure);z=dimensions['leg']
        if not finite_real(z):raise ValueError('Tamanho físico excede a precisão finita.')
        sign=-1 if c.V<0 else 1
        values=component_values(sign*lug['weld_V'],sign*lug['weld_M'],u.effective_length,c.lug_t,z)
    except (ValueError,OverflowError) as exc:
        fail(str(exc));return finish()
    out.update(values)
    out.update(Lreal_mm=u.real_length,Vactual_N=c.V,Mactual_top_Nmm=c.M,
        global_Mlocal_Nmm=c.effective_moment,zero_V_envelope=(c.V==0),
        applied_body='Ações da chave sobre a placa na interface inferior; reação na chave tem sinais opostos.',
        axis_convention='x acompanha V, y acompanha bh, z para baixo; momento escalar positivo conforme a aplicação.',
        L_origin='Duas raízes retas centradas; tamanho pleno real e efetivo em toda a largura bh, sem retornos.',
        key_steel=c.lug_steel,plate_steel=c.plate_steel,process=u.process)
    # Length mismatch is a truthful domain pending, not a silent reduction of b.
    full_length=math.isclose(u.real_length,c.lug_bh,rel_tol=1e-12,abs_tol=1e-9) and math.isclose(u.effective_length,u.real_length,rel_tol=1e-12,abs_tol=1e-9)
    if not full_length:wait('Domínio atual exige Lreal=Leff=bh, com tamanho pleno até ambas as extremidades; '
                            'um trecho menor exige um novo detalhe físico, sem reduzir a largura de contato da chave.')
    if u.effective_length>u.real_length+1e-9 or u.real_length>c.lug_bh+1e-9:
        fail('Comprimento efetivo não pode exceder o físico e a raiz física não pode exceder bh.')
    for identity,sgn in (('minus',-1),('plus',1)):
        out['physical_segments'].append(dict(id=identity,root_x_mm=sgn*c.lug_t/2,
            y_start_mm=-u.real_length/2,y_end_mm=u.real_length/2,toe_x_mm=sgn*(c.lug_t/2+z),
            centroid_x_mm=sgn*out['arm_mm']/2,Lreal_mm=u.real_length,Leff_mm=u.effective_length,
            qx_Npmm=out['qx_Npmm'],qz_Npmm=sgn*out['qz_plus_Npmm']))
    contact_domain=z<=c.grout_t*(1+1e-10)
    if not contact_domain:
        wait('O filete avança abaixo do graute e ocupa parte da face retangular plana adotada para contato com o concreto. '
             'Esse contato/tração modificados exigem detalhe próprio; z≤g é fronteira geométrica deste modelo, não limite universal NBR.')
    tmin=min(c.lug_t,c.tp)
    zmin=3. if tmin<=6.3 else 5. if tmin<=12.5 else 6. if tmin<=19 else 8.
    out['leg_min_mm']=zmin
    details=[]
    details.append(check('leg_min','perna mínima',zmin,z,'mm','z ≥ zmin(tmenor)',
                         'Tabela 11 pela parte mais fina; requisito de execução em passe único é registrado separadamente.'))
    details.append(check('length_min','comprimento efetivo mínimo por filete',max(40.,4*z),u.effective_length,'mm',
                         'Leff ≥ max(40 mm; 4z)','Comprimento real pleno é independente da largura de contato no concreto.'))
    # Finite first-release domain is not asserted to be a transverse-weld code maximum.
    length_domain=u.real_length<=100*z
    if not length_domain:
        wait('Domínio desta implementação: Lreal≤100z. Comprimento maior requer tratamento aplicável de comprimento '
             'efetivo e direção dos esforços; isto não é uma proibição geral NBR de solda transversal longa.')
    shelf=(c.L-c.lug_t)/2
    out['shelf_mm']=shelf
    details.append(check('shelf','pé dos filetes apoiado na placa',z,shelf,'mm','z ≤ (L−tchave)/2',
                         'Raízes e pés sob a placa íntegra. Não se aplica t−1,5 ao encontro T como se fosse uma borda livre.'))
    details.append(check('key_face','perna vertical apoiada na chave',z,c.lug_bv,'mm','z ≤ H',
                         'A perna vertical deve caber na face real da chapa abaixo da placa; não se credita filete sem apoio.'))
    # Native centered key and full weld roots must fit between physical plate boundaries.
    if c.lug_bh>c.B:fail('A largura física da chave e dos filetes ultrapassa a placa.');details.append(False)
    from .base_plate import detail_reference
    hole=detail_reference(c)['df']
    out['base_hole_diameter_mm']=hole
    # Native four holes remain physical obstacles even though V follows the key.
    boxes=[(-c.lug_t/2,c.lug_t/2,-c.lug_bh/2,c.lug_bh/2)]
    boxes += [(min(s['root_x_mm'],s['toe_x_mm']),max(s['root_x_mm'],s['toe_x_mm']),
               s['y_start_mm'],s['y_end_mm']) for s in out['physical_segments']]
    holes=[(x,y) for x in (-c.a,c.a) for y in (-c.a2/2,c.a2/2)]
    out['hole_centers_mm']=[list(p) for p in holes]
    if any(_rectangle_circle_intersects(box,x,y,hole/2) for box in boxes for x,y in holes):
        fail('Chave ou prateleira dos filetes intercepta um furo físico da placa; não há apoio íntegro na raiz/pé.');details.append(False)
    out['statuses']['weld_detail']='pass' if all(details) else 'fail'
    if not u.single_pass_confirmed:wait('Registrar o requisito de execução em passe único associado à perna mínima da Tabela 11.')
    if not u.execution_ref.strip():wait('Informar detalhe/procedimento de execução: tamanho pleno até os extremos, integridade, acesso e ausência de interferências inferiores.')
    if not detail_is_current(c):wait('Confirmar o detalhe de execução vinculado à geometria, materiais e ações atuais; registro ausente ou desatualizado.')
    key_domain=c.lug_t<=c.tp*(1+1e-10)
    if not key_domain:
        fail('A relação tchave≤tplaca exigida por NBR 6.7.2.4 não atende na verificação existente da chave; não se qualifica a ação prescrita fora desse domínio.')
    materials=True;material_failure=False
    for name,thickness,label in ((c.lug_steel,c.lug_t,'chave'),(c.plate_steel,c.tp,'placa')):
        steel=STEELS.get(name)
        if name not in SUPPORTED_STEELS:
            materials=False;wait('Compatibilidade SMAW/E7018 não qualificada nesta rota para o aço real da '+label+': '+name+'.')
        if steel is None or not steel.plate_allowed or not steel.plate_min<=thickness<=steel.plate_max:
            materials=False;material_failure=True;fail('Produto/espessura do aço real da '+label+' fora do domínio especificado.')
    if u.process!='smaw_e7018':wait('Processo/eletrodo não coberto: selecionar a rota documentada SMAW/E7018.');materials=False
    out['statuses']['materials']='fail' if material_failure else 'pass' if materials else 'pending'
    out['statuses']['domain']='fail' if not key_domain else 'pass' if full_length and length_domain and contact_domain else 'pending'
    out['resistance_basis_valid']=materials and full_length and length_domain and key_domain and contact_domain
    if out['resistance_basis_valid']:
        passed=check('metal','metal dos dois filetes',out['q_resultant_Npmm'],out['q_Rd_Npmm'],'N/mm',
            'q=√[(Vw/(2Leff))²+(Mw/(aLeff))²] ≤ qRd=0,6 fw (z/√2)/γw2; a=tchave+2z/3',
            'Vw/Mw prescritos integrais NBR; 485 MPa e γw2=1,35. Binário nos centroides DG1; sem fator direcional 1,5. Metal-base separado.')
        out['statuses']['weld_metal']='pass' if passed else 'fail'
    else:out['statuses']['weld_metal']='pending'
    out['statuses']['execution']='pass' if detail_is_current(c) and u.single_pass_confirmed else 'pending'
    return finish()
