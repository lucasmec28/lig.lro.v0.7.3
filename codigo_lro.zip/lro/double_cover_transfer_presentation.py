"""Presentation-only views of the rib transfer study and weld envelope.

No load allocation, resistance, favorable model selection or plate check is
performed here. These tables consume the canonical vectors from the kernel.
"""
from .models import KGF
from .report import number

EDGE_LABELS={'web':'Alma da coluna','top':'Horizontal superior','bottom':'Horizontal inferior'}
TRANSFER_ENVELOPE_NOTE=(
    'São comparadas as hipóteses de grupo elástico de três bordas e barra vertical '
    'bi-engastada. Cada hipótese conserva seus vetores concomitantes de forças e '
    'momentos; o dimensionamento de cada solda usa a maior utilização entre elas. '
    'Não há seleção da hipótese mais favorável nem combinação de máximos isolados '
    'de componentes pertencentes a hipóteses diferentes.'
)
RIB_DIAGNOSTIC_NOTE=(
    'Propriedades líquidas e solicitações N, Q e M são informações do modelo de '
    'barra. Não constituem verificação resistente da nervura perfurada, de sua '
    'interação N–Q–M, da transferência pelos ligamentos ou da flambagem lateral '
    'com torção. Não se atribui uma resistência a partir da substituição de área '
    'em uma expressão de cisalhamento de retângulo íntegro.'
)


def beam_support_rows(study):
    """Signed reactions ON the rib, not the opposite receiver actions."""
    return [(EDGE_LABELS[s['id']],number(s['x']),number(s['y']),
             number(s['Fx']/KGF),number(s['Fy']/KGF),number(s['Mz']/(KGF*1000)))
            for s in study['supports']]


def beam_load_rows(study):
    return [(str(i),number(p['x']),number(p['y']),number(p['Fx']/KGF),
             number(p['Fy']/KGF),number(p['M_centroid']/(KGF*1000)))
            for i,p in enumerate(study['loads'],1)]


def beam_section_geometry_rows(study):
    """Physical net-section properties only; never a capacity/result column."""
    rows=[]
    for i,record in enumerate(study['sections'],1):
        s=record['section'];a=record['actions']
        intervals=' + '.join('['+number(lo)+'; '+number(hi)+']' for lo,hi in s['intervals'])
        rows.append((str(i),number(a['y']),{'below':'Abaixo','above':'Acima'}.get(a['side'],a['side']),intervals,
                     number(s['A']),number(s['xc']),number(s['I'])))
    return rows


def beam_section_action_rows(study):
    return [(str(i),number(s['actions']['N']/KGF),number(s['actions']['Q']/KGF),
             number(s['actions']['M']/(KGF*1000)),
             number(s['actions']['M_net_centroid']/(KGF*1000)))
            for i,s in enumerate(study['sections'],1)]


LEVEL_LABELS={'top':'Superior','bottom':'Inferior'}
MODEL_SHORT={'three_edge':'Três bordas','beam_eb':'Barra EB','beam_timoshenko':'Barra Timo'}
RECEIVER_EDGES={'web':'Alma','flange_negative_z':'Mesa z−','flange_positive_z':'Mesa z+'}
RECEIVER_NOTE=(
    'Soldas horizontal–coluna: grupo espacial em U na horizontal frontal, ligado '
    'à alma e às duas mesas, sem solda na borda frontal livre. x aponta para fora '
    'da coluna, y para cima e z entre as mesas; momentos seguem a regra da mão '
    'direita. Cada vetor completo chega à face da nervura em (b/2; ±H/2; 0) e é '
    'transportado uma única vez ao grupo no plano médio da horizontal, '
    'y=±(H+tₕ)/2. Dois filetes por borda são projetados nesse plano; não se dobra '
    'a espessura das chapas nem se atribui capacidade ao afastamento dos filetes.'
)


def active_transfer(actions):
    value=actions.get('beam_transfer_envelope',{})
    return value if value.get('status')=='calculated_conditional' else None


def _vector(values,factor=1.):
    return '; '.join(number(v/factor) for v in values)


def transfer_action_rows(envelope):
    rows=[]
    for model in envelope['models']:
        key=model['id']
        for level in ('top','bottom'):
            a=envelope['receiver_actions'][key][level]
            rows.append((MODEL_SHORT.get(key,model['label']),LEVEL_LABELS[level],
                         number(a['Fx']/KGF),number(a['Fy']/KGF),number(a['Mz']/(KGF*1000))))
    return rows


def transfer_envelope_headers(envelope):
    return ['Junta / critério']+[MODEL_SHORT.get(m['id'],m['label'])+' η' for m in envelope['models']]+['Governa','Sd MPa','Rd MPa']


def transfer_envelope_rows(envelope):
    rows=[]
    for e in envelope['weld_envelopes']:
        alternatives={a['model']:a for a in e['alternatives']}
        rows.append((e['label'],*[number(alternatives[m['id']]['utilization']) for m in envelope['models']],
                     MODEL_SHORT.get(e['governing_model'],e['governing_model']),number(e['demand']),number(e['resistance'])))
    return rows



def rib_weld_stress_rows(envelope,detailed=False):
    """Critical points of each complete rib-to-horizontal weld field."""
    rows=[]
    for model in envelope['models']:
        for level in ('top','bottom'):
            entry=next(e for e in envelope['weld_envelopes'] if e['id']=='dc_weld_internal_'+level)
            alternative=next(a for a in entry['alternatives'] if a['model']==model['id'])
            segment=alternative['segment']
            for p in (segment['endpoint_stresses'] if detailed else [segment['critical_point']]):
                rows.append((MODEL_SHORT.get(model['id'],model['label']),LEVEL_LABELS[level],
                             _vector([p['x_mm'],p['y_mm']]),number(p['sx_MPa']),number(p['sy_MPa']),
                             number(p['resultant_MPa']),number(p['resultant_MPa']/entry['resistance'])))
    return rows


def receiver_geometry_rows(envelope):
    groups=envelope['receiver_groups'][envelope['models'][0]['id']]
    return [(LEVEL_LABELS[level]+' / '+RECEIVER_EDGES[s['id']],_vector(s['start_mm']),_vector(s['end_mm']),
             number(s['length_mm']),number(s['leg_mm']),number(s['throat_mm']),number(s['area_mm2']))
            for level in ('top','bottom') for s in groups[level]['segments']]


def receiver_action_rows(envelope):
    rows=[]
    for model in envelope['models']:
        key=model['id']
        for level in ('top','bottom'):
            for s in envelope['receiver_groups'][key][level]['segments']:
                rows.append((MODEL_SHORT.get(key,model['label']),LEVEL_LABELS[level],RECEIVER_EDGES[s['id']],
                             _vector(s['integrated_force_N'],KGF),
                             _vector(s['integrated_moment_about_origin_Nmm'],KGF*1000)))
    return rows


def receiver_stress_rows(envelope,detailed=False):
    rows=[]
    for model in envelope['models']:
        key=model['id']
        for level in ('top','bottom'):
            g=envelope['receiver_groups'][key][level]
            for s in g['segments']:
                for p in (s['endpoint_stresses'] if detailed else [s['critical_point']]):
                    rows.append((MODEL_SHORT.get(key,model['label']),LEVEL_LABELS[level],RECEIVER_EDGES[s['id']],
                                 _vector(p['point_mm']),_vector(p['stress_MPa']),number(p['resultant_MPa']),
                                 number(p['resultant_MPa']/s['stress_resistance_MPa'])))
    return rows


def receiver_property_text(envelope):
    groups=envelope['receiver_groups'][envelope['models'][0]['id']]
    return [LEVEL_LABELS[level]+': Aw='+number(groups[level]['area_mm2'])+' mm²; G=('+_vector(groups[level]['centroid_mm'])+') mm; '
            'tensor Iw em mm⁴=['+' / '.join(_vector(row) for row in groups[level]['inertia_tensor_mm4'])+'].'
            for level in ('top','bottom')]


def receiver_equilibrium_rows(envelope):
    return [(MODEL_SHORT.get(m['id'],m['label']),LEVEL_LABELS[level],
             _vector(envelope['receiver_groups'][m['id']][level]['equilibrium']['force_residual_N']),
             _vector(envelope['receiver_groups'][m['id']][level]['equilibrium']['moment_origin_residual_Nmm']))
            for m in envelope['models'] for level in ('top','bottom')]


def beam_nominal_rows(study):
    rows=[]
    for i,s in enumerate(study['sections'],1):
        a=s['actions'];stress=a['nominal_normal_stress_MPa']
        rows.append((str(i),number(a['N']/KGF),number(a['Q']/KGF),number(a['M']/(KGF*1000)),
                     number(a['M_net_centroid']/(KGF*1000)),number(stress[0]),number(stress[1])))
    return rows


def transfer_equations(doc):
    from .report import _math,group,sub,frac,power,radical
    _math(doc,group(sub('M','G'),' = ',sub('M','livre'),' + (',sub('r','P'),' − ',sub('r','G'),') × F ;   ',sub('I','w'),' Ω = ',sub('M','G')))
    _math(doc,group('τ(r) = ',frac('F',sub('A','w')),' + Ω × (r − ',sub('r','G'),') ;   ',
                    sub('τ','res'),' = ',radical(group(power(sub('τ','x')),' + ',power(sub('τ','y')),' + ',power(sub('τ','z'))))))
    _math(doc,group(sub('η','envoltória'),' = ',sub('max','hipóteses'),frac(sub('τ','res,max'),sub('f','w,Rd')),' ;   ',sub('f','w,Rd'),' = ',frac(group('0,6',sub('f','w')),sub('γ','w2'))))


def append_transfer_report(doc,actual,design,detailed=False):
    """Append the .67-only chapters; unchanged callers keep the .65 branch."""
    from .report import table,_math,group,sub,frac
    from docx.shared import Pt
    title=doc.add_paragraph('Transferência aos horizontais e envoltória das soldas',style='Heading 1')
    title.paragraph_format.page_break_before=True
    title.paragraph_format.space_before=Pt(0)
    doc.add_paragraph(design['assumptions'])
    doc.add_paragraph('Hipóteses avaliadas: '+'; '.join(m['label'] for m in design['models'])+'.')
    doc.add_paragraph('Ações transmitidas à face de cada horizontal',style='Heading 2')
    doc.add_paragraph('Fx e Fy são forças resultantes; Mz é o binário livre na face da nervura, em (b/2; ±H/2; 0). Esses três valores pertencem à mesma hipótese. O momento em relação à origem inclui também o braço da força. Reações sobre a nervura têm sinais opostos.')
    rows=[]
    for label,envelope in [('Entrada',actual),('Conferência governante',design)]:
        rows.extend((label,*row) for row in transfer_action_rows(envelope))
    table(doc,['Caso','Hipótese','Horizontal','Fx kgf','Fy kgf','Mz livre kgf·m'],rows,[1.15,.95,1.3,.8,.8,1.05])
    doc.add_paragraph('Envoltória por junta e por critério',style='Heading 2')
    doc.add_paragraph('Compara-se a utilização de cada campo completo. A coluna Governa identifica o campo mantido integralmente nessa verificação; campos governantes distintos não são somados em um vetor artificial. “Escoamento local suplementar” é um critério idealizado na linha da nervura, não a interação N–Q–M de sua seção perfurada.')
    table(doc,transfer_envelope_headers(design),transfer_envelope_rows(design),[2.15]+[.65]*len(design['models'])+[.95,.65,.65])
    doc.add_paragraph('Pontos críticos das soldas nervura aos horizontais',style='Heading 2')
    doc.add_paragraph('Campos de cada hipótese na conferência governante. As pernas, gargantas e comprimentos úteis são os mesmos da geometria das bordas superior e inferior já apresentada. τx e τy são componentes do vetor equivalente; a capacidade é local à solda.')
    table(doc,['Hipótese','Horizontal','Ponto x; y mm','τx MPa','τy MPa','τres MPa','η'],rib_weld_stress_rows(design,detailed),[.9,.8,1.3,.8,.8,.9,.75])
    doc.add_paragraph('Qualificações ainda necessárias',style='Heading 2')
    for note in design['limitations']:doc.add_paragraph(note)
    doc.add_paragraph('Grupo espacial de soldas das horizontais à coluna',style='Heading 1')
    doc.add_paragraph(RECEIVER_NOTE)
    doc.add_paragraph('A hipótese é de peças rígidas e rigidez isotrópica uniforme por área de garganta. Fy é normal ao plano da horizontal; não é tratado como cisalhamento no plano de seu metal-base. O vetor equivalente τ não é a decomposição normal/cisalhante real da garganta. A Tabela 9 fornece o limite resistente, sem aumento direcional, mas não demonstra a rigidez das peças.')
    table(doc,['Junta','Início x; y; z mm','Fim x; y; z mm','L mm','w mm','a mm','Aw mm²'],receiver_geometry_rows(design),[1.8,1.3,1.3,.65,.55,.55,.8])
    for line in receiver_property_text(design):doc.add_paragraph(line)
    transfer_equations(doc)
    doc.add_paragraph('Vetores integrados por borda na conferência governante',style='Heading 2')
    table(doc,['Hipótese','Horizontal','Borda','F (x; y; z) kgf','Mo (x; y; z) kgf·m'],receiver_action_rows(design),[.95,1.1,.85,1.9,2.05])
    doc.add_paragraph('Mo é referido à origem global O e inclui o binário local distribuído. Não se substitui cada borda apenas por sua força concentrada. As resultantes abaixo não demonstram capacidade das chapas receptoras.')
    table(doc,['Hipótese','Horizontal','Resíduo F (x; y; z) N','Resíduo Mo (x; y; z) N·mm'],receiver_equilibrium_rows(design),[1.,1.2,2.1,2.55])
    doc.add_paragraph('Tensões '+('nas extremidades' if detailed else 'críticas por borda')+' na conferência governante',style='Heading 2')
    table(doc,['Hipótese','Horizontal','Borda','Ponto x; y; z mm','τ (x; y; z) MPa','τres MPa','η'],receiver_stress_rows(design,detailed),[.8,.95,.8,1.25,1.45,.8,.75])
    resistance=design['receiver_groups'][design['models'][0]['id']]['top']['stress_resistance_MPa']
    doc.add_paragraph('Limite comum fw,Rd='+number(resistance)+' MPa. O campo é afim: a maior norma em cada cordão reto ocorre em uma de suas extremidades. Os índices acima são próprios de cada hipótese; a envoltória por junta permanece a do quadro anterior.')
    beams=[m for m in design['models'] if m['beam'] is not None]
    if beams:
        title=doc.add_paragraph('Informações nominais da nervura como barra',style='Heading 1')
        title.paragraph_format.page_break_before=True
        title.paragraph_format.space_before=Pt(0)
        doc.add_paragraph(RIB_DIAGNOSTIC_NOTE)
        doc.add_paragraph('Na barra vertical, N é axial ao longo de y e Q é transversal em x; não são automaticamente as componentes N e V da entrada. N, Q e M de uma linha são concomitantes e atuam na face +y do corpo inferior retido. Abaixo/Acima indica o lado do corte em uma força concentrada. Furos alteram as propriedades da seção, mas a rigidez global da hipótese continua bruta e uniforme.')
        doc.add_paragraph('Geometria das seções comum às hipóteses de barra',style='Heading 2')
        table(doc,['Corte','y mm','Lado','Intervalos x mm','An mm²','xn mm','In mm⁴'],beam_section_geometry_rows(beams[0]['beam']),[.45,.7,.7,1.65,.85,.75,1.45])
        _math(doc,group(sub('M','n'),' = ',sub('M','g'),' + (',sub('x','g'),' − ',sub('x','n'),')N ;   ',sub('σ','nom'),' = ',frac('N',sub('A','n')),' + ',frac(group(sub('M','n'),'(x − ',sub('x','n'),')'),sub('I','n'))))
        doc.add_paragraph('Sem índice de utilização ou conclusão resistente para estes cortes. Mg usa o centroide bruto; Mn usa o centroide líquido. As tensões nominais normais não incluem concentração junto aos furos nem um campo de cisalhamento qualificado dos ligamentos.')
        for m in beams:
            b=m['beam']
            doc.add_paragraph(m['label'],style='Heading 2')
            doc.add_paragraph('Reações dos apoios sobre a nervura; sinais opostos às ações transmitidas aos horizontais.')
            table(doc,['Apoio','x mm','y mm','Rx kgf','Ry kgf','Mz kgf·m'],beam_support_rows(b),[1.35,.9,.9,1.,1.,1.1])
            table(doc,['Corte','N kgf','Q kgf','Mg kgf·m','Mn kgf·m','σnom xmin MPa','σnom xmax MPa'],beam_nominal_rows(b),[.45,.9,.9,.95,.95,1.,1.])


def render_transfer_ui(st,actual,design):
    """Read-only tables, without a favorable-hypothesis selector."""
    import pandas as pd
    def frame(headers,rows):
        st.dataframe(pd.DataFrame(rows,columns=headers),hide_index=True,width='stretch')
    with st.expander('Envoltória de transferência · horizontais'):
        st.caption(design['assumptions'])
        st.write('Hipóteses: '+'; '.join(m['label'] for m in design['models'])+'.')
        st.caption('Ações transmitidas na face da nervura em (b/2; ±H/2; 0). Mz é o binário livre, sem o braço da força; reações sobre a nervura têm sinais opostos.')
        rows=[]
        for label,envelope in [('Entrada',actual),('Conferência governante',design)]:
            rows.extend((label,*row) for row in transfer_action_rows(envelope))
        frame(['Caso','Hipótese','Horizontal','Fx kgf','Fy kgf','Mz livre kgf·m'],rows)
        frame(transfer_envelope_headers(design),transfer_envelope_rows(design))
        st.caption('Pontos críticos das soldas nervura–horizontal em cada hipótese. Pernas, gargantas e comprimentos úteis são os da geometria das bordas superior e inferior.')
        frame(['Hipótese','Horizontal','Ponto x; y mm','τx MPa','τy MPa','τres MPa','η'],rib_weld_stress_rows(design))
        st.caption('A maior utilização governa cada junta com seu vetor completo. Campos governantes de juntas distintas não são somados. O escoamento local suplementar é um critério idealizado junto à solda, sem qualificar a seção perfurada ou sua interação N–Q–M.')
    with st.expander('Soldas horizontais–coluna · grupos espaciais'):
        st.caption(RECEIVER_NOTE)
        st.caption('Peças rígidas e rigidez isotrópica por área de garganta são hipóteses. Fy é normal ao plano da horizontal; o vetor equivalente τ não é a decomposição normal/cisalhante real da garganta. Limite da Tabela 9 sem aumento direcional.')
        frame(['Junta','Início x; y; z mm','Fim x; y; z mm','L mm','w mm','a mm','Aw mm²'],receiver_geometry_rows(design))
        for line in receiver_property_text(design):st.write(line)
        frame(['Hipótese','Horizontal','Borda','F (x; y; z) kgf','Mo (x; y; z) kgf·m'],receiver_action_rows(design))
        st.caption('Mo é referido à origem global e inclui o binário local distribuído. Integrais de força e momento não demonstram capacidade das chapas receptoras.')
        frame(['Hipótese','Horizontal','Resíduo F (x; y; z) N','Resíduo Mo (x; y; z) N·mm'],receiver_equilibrium_rows(design))
        frame(['Hipótese','Horizontal','Borda','Ponto x; y; z mm','τ (x; y; z) MPa','τres MPa','η'],receiver_stress_rows(design))
        resistance=design['receiver_groups'][design['models'][0]['id']]['top']['stress_resistance_MPa']
        st.caption('Limite comum fw,Rd='+number(resistance)+' MPa. Pontas críticas por borda na conferência governante; a envoltória final permanece no quadro anterior.')
    beams=[m for m in design['models'] if m['beam'] is not None]
    if beams:
        with st.expander('Nervura como barra · informações nominais'):
            st.caption(RIB_DIAGNOSTIC_NOTE)
            st.caption('N é axial em y e Q transversal em x. N, Q e M são concomitantes na face +y do corpo inferior retido. Abaixo/Acima indica o lado do corte; a rigidez global permanece bruta e uniforme.')
            frame(['Corte','y mm','Lado','Intervalos x mm','An mm²','xn mm','In mm⁴'],beam_section_geometry_rows(beams[0]['beam']))
            for m in beams:
                st.write(m['label'])
                st.caption('Reações sobre a nervura, opostas às ações nos horizontais.')
                frame(['Apoio','x mm','y mm','Rx kgf','Ry kgf','Mz kgf·m'],beam_support_rows(m['beam']))
                frame(['Corte','N kgf','Q kgf','Mg kgf·m','Mn kgf·m','σnom xmin MPa','σnom xmax MPa'],beam_nominal_rows(m['beam']))
            st.caption('Mg usa o centroide bruto; Mn usa o centroide líquido. σnom=N/An+Mn(x−xn)/In é apenas tensão normal nominal, sem concentração nos furos, cisalhamento qualificado dos ligamentos ou conclusão resistente.')
            for note in design['limitations']:st.caption(note)
