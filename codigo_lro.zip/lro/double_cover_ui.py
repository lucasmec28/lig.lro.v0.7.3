"""Interface independente para a emenda com duas talas."""
from .display_precision import calculated_text
from .display_precision import display_format, display_frame, display_value, number_input
from dataclasses import fields
import hashlib
import json
import math
import pandas as pd
import streamlit as st
from .load_conventions import render as render_load_convention
from .models import profiles,Profile,STEELS,BOLTS,DIAMETERS,KGF
from .package_identity import PACKAGE_ID
from .double_cover import DoubleCoverConnection,presets,evaluate,PLATE_STOCK,ASSEMBLY_NOTE,COMPRESSION_NOTE,INITIAL_PRESET
from .double_cover_drawing import image_bytes
from .report import BRAND,LINK,number,display

P=profiles();PRESETS=presets()

# Import limits mirror the controls, including currently hidden inputs. A
# candidate is fully checked before any live widget or export state is replaced.
_UI_RANGES = {
    'pitch': (1., None), 'edge_v': (1., None), 'edge_x': (1., None),
    'gap': (.1, None), 'extension': (0., None), 'root_height': (1., None),
    'fin_t': (.1, 100.), 'cover_t': (.1, 100.), 'stiffener_t': (.1, 100.),
    'corner_clip': (0., None), 'clearance': (0., None),
    'tool_radius': (.1, None), 'fit_tolerance': (0., 1.),
    'weld_web': (.1, None), 'weld_fin_stiffener': (.1, None),
    'weld_stiffener_column': (.1, None), 'fw': (1., None),
}
_PROFILE_FIELDS = ('manual_name','d','bf','tw','tf','clear','family','area','mass','source')
_THICKNESS_KEYS = ('fin_t','cover_t','stiffener_t')
_DRAFT_KEYS = (
    'dc_fit_tolerance',
    *(f'dc_{display_value(key)}_{display_value(suffix)}' for key in ('beam','support') for suffix in ('name',)+_PROFILE_FIELDS),
    *(f'_dc_{display_value(key)}_custom_steel' for key in ('beam','support')),
    *(name for key in _THICKNESS_KEYS for name in ('dc_'+key, 'dc_'+key+'_label', '_dc_'+key+'_custom')),
)


def import_ui_values(c):
    """Build a lossless candidate widget state; never mutate the live project."""
    def numeric(field, value, limits=None):
        try:
            finite=type(value) in (int,float) and math.isfinite(value)
        except OverflowError:
            finite=False
        if not finite:
            raise ValueError(f'{display_value(field)} = {value!r}: o controle exige um número finito representável.')
        if float(value)!=value:
            raise ValueError(f'{display_value(field)} = {value!r}: não representável sem perda no controle numérico.')
        if limits:
            lower,upper=limits
            if value<lower or (upper is not None and value>upper):
                interval=f"[{display_format(lower, 'g')}, {display_format(upper, 'g')}]" if upper is not None else f"≥ {display_format(lower, 'g')}"
                raise ValueError(f'{display_value(field)} = {value!r}: fora do intervalo do controle {display_value(interval)}.')
    for key,limits in _UI_RANGES.items():numeric(key,getattr(c,key),limits)
    if type(c.n) is not int or not 2<=c.n<=12:
        raise ValueError(f'n = {c.n!r}: o controle exige um inteiro de 2 a 12.')
    for key in ('threads','drilled','norm_minimum'):
        if type(getattr(c,key)) is not bool:raise ValueError(f'{display_value(key)}: deve ser verdadeiro ou falso.')
    for key in ('project','notes'):
        if not isinstance(getattr(c,key),str):raise ValueError(f'{display_value(key)}: deve ser texto.')
    if c.shim_mode not in ('automatic','fit'):raise ValueError('shim_mode: modo de montagem não disponível no controle.')
    if c.bolt not in BOLTS or c.bolt=='ASTM A307':raise ValueError('bolt: classe de parafuso não disponível no controle.')
    for key in ('beam_steel','support_steel','fin_steel','cover_steel','stiffener_steel'):
        if getattr(c,key) not in STEELS:raise ValueError(f'{display_value(key)}: aço não disponível no controle.')
    numeric('db',c.db)
    db_label=next((key for key,value in DIAMETERS.items() if c.db==value),None)
    if db_label is None:raise ValueError(f'db = {c.db!r}: diâmetro não é exatamente um valor do catálogo.')
    values={'dc_'+f.name:getattr(c,f.name) for f in fields(c) if f.name not in ('beam','support','V','N')}
    values['dc_db_label']=db_label
    raw_loads={}
    for key in ('V','N'):
        value=getattr(c,key);numeric(key,value)
        kgf=value/KGF
        if value!=0 and kgf==0:raise ValueError(f'{display_value(key)} = {value!r}: não representável em kgf sem perda.')
        values['dc_'+key+'_kgf']=kgf;raw_loads[key]=(kgf,value)
    values['_double_cover_raw_loads']=raw_loads
    for key in _THICKNESS_KEYS:
        value=getattr(c,key)
        values['dc_'+key+'_label']=next((label for label,stock in PLATE_STOCK.items() if value==stock),'Personalizada')
        values['_dc_'+key+'_custom']=float(value)
    for key in ('beam','support'):
        profile=getattr(c,key)
        for field in ('name','family','source'):
            if not isinstance(getattr(profile,field),str):raise ValueError(f'{display_value(key)}.{display_value(field)}: deve ser texto.')
        # Equal names alone never authorize replacing imported geometry/product.
        values['dc_'+key+'_name']=profile.name if P.get(profile.name)==profile else 'Seção I personalizada'
        for field in ('d','bf','tw','tf','clear','area','mass'):
            value=getattr(profile,field)
            numeric(key+'.'+field,value,(.1,3000.) if field in ('d','bf','tw','tf','clear') else None)
            values['dc_'+key+'_'+field]=float(value)
        for field in ('name','family','source'):
            values['dc_'+key+('_manual_name' if field=='name' else '_'+field)]=getattr(profile,field)
        values['_dc_'+key+'_custom_steel']=getattr(c,key+'_steel')
    return values


def seed(c,values=None,drafts=None):
    values=import_ui_values(c) if values is None else values
    if drafts:values.update(drafts)
    st.session_state.update(values)
    st.session_state.pop('dc_report',None)


def load_newtons(key,kgf):
    """Keep unedited imported N values exact across kgf display/reruns."""
    snapshot=st.session_state.get('_double_cover_raw_loads',{}).get(key)
    return snapshot[1] if snapshot is not None and snapshot[0]==kgf else kgf*KGF


def load_example():
    seed(PRESETS[st.session_state.dc_example])
    st.session_state.pop('dc_import_error',None)


def load_json():
    try:
        up=st.session_state.dc_upload
        if up is None:raise ValueError('Selecione um arquivo JSON.')
        if len(up.getvalue())>200000:raise ValueError('Projeto maior que o limite de 200 kB.')
        c=DoubleCoverConnection.from_dict(json.loads(up.getvalue()))
        values=import_ui_values(c)
        r=evaluate(c)
        if r.numeric_failures or any(x.origin=='numeric' for x in r.issues):
            raise ValueError('Resultado numérico não finito para os dados informados. Revise a magnitude das ações e dimensões; o projeto atual foi mantido.')
        if any(x.severity=='error' for x in r.issues):raise ValueError('; '.join(x.text for x in r.issues if x.severity=='error'))
        seed(c,values=values);st.session_state.pop('dc_import_error',None)
    except (ValueError,TypeError,KeyError,OverflowError) as exc:st.session_state.dc_import_error='Não foi possível abrir: '+str(exc)


def profile_changed(key):
    p=P.get(st.session_state['dc_'+key+'_name'])
    if p:st.session_state['dc_'+key+'_steel']='ASTM A36' if p.family in ('CS','CVS','VS','Soldado') else 'ASTM A572 Gr.50'
    else:st.session_state['dc_'+key+'_steel']=st.session_state['_dc_'+key+'_custom_steel']


def profile_widget(key,label):
    name=st.selectbox(label,['Seção I personalizada']+list(P),key='dc_'+key+'_name',on_change=profile_changed,args=(key,))
    if name in P:return P[name]
    with st.expander('Dimensões de '+label.lower(),expanded=True):
        name=st.text_input('Designação',key='dc_'+key+'_manual_name')
        vals={}
        for field,text in [('d','Altura d'),('bf','Largura bf'),('tw','Alma tw'),('tf','Mesa tf'),('clear','Altura livre sem concordâncias')]:
            vals[field]=number_input(text+' (mm)',min_value=.1,max_value=3000.,key='dc_'+key+'_'+field)
        family=st.text_input('Família / produto',key='dc_'+key+'_family')
        area=number_input('Área informada (mm²)',key='dc_'+key+'_area',format='%.2f')
        mass=number_input('Massa informada (kg/m)',key='dc_'+key+'_mass',format='%.2f')
        source=st.text_input('Fonte da seção',key='dc_'+key+'_source')
        return Profile(name,family,mass,area=area,source=source,**vals)


def stock_changed(key):
    label=st.session_state['dc_'+key+'_label']
    st.session_state['dc_'+key]=PLATE_STOCK[label] if label in PLATE_STOCK else st.session_state['_dc_'+key+'_custom']


def thickness(key,label):
    lab=st.selectbox(label,list(PLATE_STOCK)+['Personalizada'],key='dc_'+key+'_label',on_change=stock_changed,args=(key,))
    if lab=='Personalizada':
        value=number_input(label+' (mm)',min_value=.1,max_value=100.,key='dc_'+key,format='%.2f')
        st.session_state['_dc_'+key+'_custom']=value
        return value
    st.caption(number(PLATE_STOCK[lab],4)+' mm')
    return PLATE_STOCK[lab]

def render():
    from .double_cover_report import (create_report, INTERNAL_WELD_HYPOTHESIS,
                                     WELD_EDGE_LABELS, weld_geometry_rows,
                                     weld_reaction_rows, weld_stress_rows)
    if 'dc_beam_name' not in st.session_state:
        saved=st.session_state.get('_double_cover_project')
        seed(DoubleCoverConnection.from_dict(saved) if saved else PRESETS[INITIAL_PRESET],
             drafts=st.session_state.get('_double_cover_drafts') if saved else None)
    # Detach conditional widgets from Streamlit's hidden-widget cleanup. The
    # separate snapshot below also survives navigation into another family.
    for key in _DRAFT_KEYS:
        if key in st.session_state:st.session_state[key]=st.session_state[key]
    with st.sidebar:
        st.markdown('### LRO Ligações')
        st.caption('Versão '+PACKAGE_ID+' · modelo por componentes')
        st.selectbox('Exemplos',[INITIAL_PRESET]+[name for name in PRESETS if name!=INITIAL_PRESET],key='dc_example')
        st.button('Usar exemplo de duas talas',on_click=load_example,use_container_width=True)
        st.file_uploader('Abrir projeto desta ligação',type=['json'],key='dc_upload')
        st.button('Abrir projeto de duas talas',on_click=load_json,use_container_width=True)
        if 'dc_import_error' in st.session_state:st.error(st.session_state.dc_import_error)
        st.divider();st.caption(BRAND);st.link_button('LinkedIn · Lucas Oliveira',LINK)
    st.markdown('<div class="eyebrow">DUAS TALAS · PERFIS I · MODELO LOCAL</div>',unsafe_allow_html=True)
    st.title('Viga na alma de coluna')
    st.caption('Duas talas parafusadas · nervura soldada · quatro enrijecedores horizontais')
    st.text_input('Identificação do projeto',key='dc_project')
    left,right=st.columns([.95,1.55],gap='large')
    with left:
        beam=profile_widget('beam','Viga apoiada');support=profile_widget('support','Coluna')
        a,b=st.columns(2)
        with a:V=load_newtons('V',number_input('Cortante vertical V (kgf)',key='dc_V_kgf',format='%.2f'))
        with b:N=load_newtons('N',number_input('Axial N (kgf)',key='dc_N_kgf',format='%.2f'))
        load_convention_slot = st.empty()
        st.caption('Esforços já majorados. N positivo: tração; N negativo: compressão. Sem momento externo aplicado.')
        a,b=st.columns(2)
        with a:
            st.selectbox('Parafuso Ø (pol.)',list(DIAMETERS),key='dc_db_label')
            number_input('Linhas por grupo',min_value=2,max_value=12,key='dc_n')
            number_input('Passo vertical p (mm)',min_value=1.,key='dc_pitch')
        with b:
            st.selectbox('Classe do parafuso',[x for x in BOLTS if x!='ASTM A307'],key='dc_bolt')
            number_input('Borda vertical eᵥ (mm)',min_value=1.,key='dc_edge_v')
            number_input('Borda horizontal e (mm)',min_value=1.,key='dc_edge_x')
        st.caption('u = 0,00 representa nervura rente à borda das mesas. Parafusos no vão entre mesas são uma posição prevista; colisão material, acesso e qualificação resistente são verificações separadas.')
        st.caption('Uma coluna de parafusos em cada grupo, mesma quantidade e passo. Duas talas iguais, centradas na altura da viga.')
        a,b=st.columns(2)
        with a:tn=thickness('fin_t','Espessura da nervura')
        with b:tt=thickness('cover_t','Espessura das talas')
        nearest=min(PLATE_STOCK,key=lambda k:abs(PLATE_STOCK[k]-beam.tw))
        st.caption(f'Alma da viga: {display_value(number(beam.tw, 3))} mm. Chapa de estoque mais próxima: {display_value(nearest)}; conferir também a compatibilidade dos filetes.')
        with st.expander('Geometria e montagem'):
            number_input('Folga g entre nervura e viga (mm)',min_value=.1,key='dc_gap')
            number_input('Projeção u além da mesa da coluna (mm)',min_value=0.,key='dc_extension')
            st.caption('Afastamento da ponta da viga à face frontal da coluna: u + g = '+number(st.session_state.dc_extension+st.session_state.dc_gap,2)+' mm.')
            number_input('Distância livre H entre horizontais (mm)',min_value=1.,key='dc_root_height')
            th=thickness('stiffener_t','Espessura dos quatro horizontais')
            number_input('Alívio de canto dos horizontais c (mm)',min_value=0.,key='dc_corner_clip')
            st.selectbox('Ajuste de espessuras',['automatic','fit'],key='dc_shim_mode',format_func=lambda x:'Calços simétricos na peça mais fina' if x=='automatic' else 'Pequena diferença admitida na montagem')
            if st.session_state.dc_shim_mode=='fit':number_input('Tolerância adotada de espessura (mm)',min_value=0.,max_value=1.,key='dc_fit_tolerance')
            number_input('Folga de montagem (mm)',min_value=0.,key='dc_clearance')
            number_input('Raio livre para porca/ferramenta (mm)',min_value=.1,key='dc_tool_radius')
        with st.expander('Soldas de oficina'):
            st.caption('Filetes duplos no conjunto soldado. As talas e a viga não recebem soldas de ligação.')
            number_input('Nervura → alma da coluna, w (mm)',min_value=.1,key='dc_weld_web')
            number_input('Nervura → horizontais, w (mm)',min_value=.1,key='dc_weld_fin_stiffener')
            number_input('Horizontais → coluna, w (mm)',min_value=.1,key='dc_weld_stiffener_column')
            number_input('Resistência do eletrodo fw (MPa)',min_value=1.,key='dc_fw')
        with st.expander('Materiais e critérios'):
            for key,label,p in [('beam_steel','Aço da viga',beam),('support_steel','Aço da coluna',support),('fin_steel','Aço da nervura',None),('cover_steel','Aço das talas',None),('stiffener_steel','Aço dos horizontais',None)]:
                plate=p is None or p.family in ('VS','CVS','CS','Soldado')
                options=[name for name,steel in STEELS.items() if (steel.plate_allowed if plate else steel.rolled_allowed) or name==st.session_state['dc_'+key]]
                st.selectbox(label,options,key='dc_'+key)
            st.checkbox('Rosca incluída nos planos de corte',key='dc_threads')
            st.checkbox('Furos executados com broca, sem acréscimo de 2 mm na dedução líquida',key='dc_drilled')
            st.checkbox('Conferir mínimo resistente de 45 kN',key='dc_norm_minimum')
            st.caption('Contenção eficaz da viga e penetração total das juntas internas dos perfis soldados são premissas fixas. Sem atrito, fadiga ou ações cíclicas.')
        with st.expander('Observações do projeto'):st.text_area('Observações',key='dc_notes')
    values={f.name:st.session_state['dc_'+f.name] for f in fields(DoubleCoverConnection) if f.name not in ('beam','support','V','N','db','fin_t','cover_t','stiffener_t')}
    c=DoubleCoverConnection(beam,support,V=V,N=N,db=DIAMETERS[st.session_state.dc_db_label],fin_t=tn,cover_t=tt,stiffener_t=th,**values)
    st.session_state['_double_cover_project']=c.to_dict()
    for key in ('beam','support'):
        if st.session_state['dc_'+key+'_name']=='Seção I personalizada':
            st.session_state['_dc_'+key+'_custom_steel']=st.session_state['dc_'+key+'_steel']
    st.session_state['_double_cover_drafts']={key:st.session_state[key] for key in _DRAFT_KEYS if key in st.session_state}
    with load_convention_slot.container():
        render_load_convention(st, 'column_web_double_cover', c.N)
    r=evaluate(c);encoded=json.dumps(c.to_dict(),ensure_ascii=False,indent=2);digest=hashlib.sha256(encoded.encode()).hexdigest()
    if st.session_state.get('dc_report',('','',b''))[0]!=digest:st.session_state.pop('dc_report',None)
    with right:
        if r.status in ('GEOMETRIA INVÁLIDA','NÃO ATENDE','NÃO ATENDE AO DETALHAMENTO','FALHA NUMÉRICA · REVISAR ENTRADA','DADOS NECESSÁRIOS AUSENTES'):st.error(r.status)
        elif r.local_scope_issues or any(i.severity in ('pending','interference','extrapolation') for i in r.issues):st.warning(r.status)
        else:st.success(r.status)
        st.caption(r.coverage_note)
        if r.calculation_note:st.caption(r.calculation_note)
        if r.governing:
            a,b=st.columns(2)
            a.metric('Maior índice calculado',number(r.governing.ratio,3))
            b.metric('Caso governante',r.governing.case)
            st.caption(r.governing.name+' · '+r.governing.case)
        can_draw=bool(r.geometry) and not r.numeric_failures and not any(i.origin=='numeric' or i.severity=='error' for i in r.issues)
        can_report=bool(r.checks) and not r.numeric_failures and not any(i.severity=='error' for i in r.issues)
        if can_draw:
            st.image(image_bytes(c),width='stretch')
        elif any(i.severity=='error' for i in r.issues):
            st.warning('Desenho e exportação SVG indisponíveis enquanto houver erros de entrada ou geometria. Corrija os erros indicados abaixo.')
        for issue in r.issues:
            if issue.severity=='excluded':continue
            if issue.severity in ('error','noncompliance'):st.error(calculated_text(issue.text, assignments_only=True))
            elif issue.severity in ('pending','interference','extrapolation'):st.warning(calculated_text(issue.text, assignments_only=True))
            else:st.caption(calculated_text(issue.text, assignments_only=True))
        if r.geometry.get('weld_interfaces'):
            with st.expander('Filetes e interfaces físicas'):
                st.caption('A mesma perna dos horizontais atende separadamente à mesa e à alma. Critérios avaliados sem arredondar; mínimo insuficiente é não conformidade de detalhamento.')
                joints=[]
                for j in r.geometry['weld_interfaces']:
                    ok=j['minimum']<=j['w']<=j['maximum'] and j['length']>=max(4*j['w'],40)
                    joints.append({'Junta':j['name'],'Espessuras (mm)':f"{display_format(j['t_edge'], '.12g')} / {display_format(j['t_other'], '.12g')}",'Filete (mm)':display_format(j['w'],'.12g'),'Mínimo (mm)':j['minimum'],'Máximo (mm)':j['maximum'],'L útil (mm)':j['length'],'Detalhamento':'Atende' if ok else 'Não atende'})
                st.dataframe(display_frame(pd.DataFrame(joints)),hide_index=True,width='stretch')
        if r.minimum_factor>1:
            st.info('Além da entrada, o app confere a resultante mínima resistente de 45 kN, mantendo a direção N/V. Fator da conferência mínima: '+number(r.minimum_factor,3)+'. Não é nova majoração das ações.')
        if r.checks and 'actual_actions' in r.geometry:
            a=r.geometry['actual_actions']
            with st.expander('Equilíbrio e ações transmitidas à coluna'):
                if c.internal_fin_perforation:st.caption('Equilíbrio do grupo elástico em três bordas. O cálculo local das soldas é independente da transferência em membrana e da estabilidade da nervura perfurada, ainda pendentes, e não demonstra a capacidade dos receptores.')
                st.write('Rótula nominal no meio da folga. A excentricidade gera momento local no conjunto soldado, mesmo sem momento externo informado.')
                st.write(f"e até a face da alma = {display_value(number(c.pin_x))} mm; M local = {display_value(number(a['M'] / (KGF * 1000)))} kgf·m.")
                if c.internal_fin_perforation:
                    st.write(f"Fx integrado na borda superior = {display_value(number(a['top'] / KGF))} kgf; Fx integrado na borda inferior = {display_value(number(a['bottom'] / KGF))} kgf.")
                    st.caption('Origem O na face da alma, a meia altura da nervura; x para fora da coluna, y para cima, V positivo em +y e momento positivo anti-horário. Ações transmitidas da nervura aos receptores; as reações sobre a nervura têm sinais opostos. Superior: y=+H/2. Momentos por borda incluem a distribuição ao longo do cordão e são referidos a O.')
                    st.dataframe(pd.DataFrame(weld_reaction_rows(a['weld_group']),columns=['Borda','Fx kgf','Fy kgf','Mo kgf·m']),hide_index=True,width='stretch')
                else:st.write(f"H superior = {display_value(number(a['top'] / KGF))} kgf; H inferior = {display_value(number(a['bottom'] / KGF))} kgf.")
                st.caption('Valores acima correspondem às ações de entrada. O dimensionamento também inclui a conferência mínima, se ativa. A verificação global da coluna pertence ao modelo da estrutura.')
            if c.internal_fin_perforation:
                with st.expander('Soldas em três bordas · verificação local'):
                    st.caption(INTERNAL_WELD_HYPOTHESIS)
                    wg=r.geometry['actions']['weld_group'];critical=wg['critical_point']
                    st.dataframe(pd.DataFrame(weld_geometry_rows(wg),columns=['Borda','Início x; y mm','Fim x; y mm','L útil mm','w mm','a mm','Aw mm²']),hide_index=True,width='stretch')
                    st.write('Aw total = '+number(wg['area_mm2'])+' mm²; centroide C = ('+number(wg['centroid_x_mm'])+'; '+number(wg['centroid_y_mm'])+') mm; J = '+number(wg['J_mm4'])+' mm⁴.')
                    st.caption('Aw inclui os dois filetes de cada borda. As gargantas reais ponderam a área, o centroide e J. Valores abaixo: conferência governante, incluindo o mínimo resistente quando ativo.')
                    st.dataframe(pd.DataFrame(weld_reaction_rows(wg),columns=['Borda','Fx kgf','Fy kgf','Mo kgf·m']),hide_index=True,width='stretch')
                    st.write('Mc = '+number(wg['moment_about_centroid_Nmm']/(KGF*1000))+' kgf·m; τmáx = '+number(critical['resultant_MPa'])+' MPa; fw,Rd = '+number(wg['stress_resistance_MPa'])+' MPa; η = '+number(wg['max_utilization'],3)+'.')
                    st.caption('Ponto crítico: '+WELD_EDGE_LABELS[critical['segment']]+', x = '+number(critical['x_mm'])+' mm, y = '+number(critical['y_mm'])+' mm. O atendimento é condicionado à hipótese elástica; não aprova o conjunto.')
                    st.dataframe(pd.DataFrame(weld_stress_rows(wg),columns=['Borda','Ponto x; y mm','τx MPa','τy MPa','τresult. MPa','η']),hide_index=True,width='stretch')
                    st.caption('τx e τy são componentes assinadas do campo vetorial equivalente do grupo soldado, não uma decomposição normal/cisalhante do tensor real da garganta. A resultante é comparada ao limite da Tabela 9; sua maior norma ocorre em um dos extremos de cada cordão reto. O escoamento local da nervura adota tensão paralela à borda nula: é um critério suplementar condicionado, não um limite conservador demonstrado. Não demonstra ruptura, transferência pelos ligamentos ou capacidade dos receptores.')
    if r.checks:
        st.subheader('Resultados dos componentes')
        st.caption('Uma envoltória por seção física e pelos dois grupos de parafusos; todos os ramos permanecem nas contas abaixo. Atendimento de componentes não qualifica o conjunto.')
        data=[]
        for row in r.summary_checks:
            sd,unit=display(row.demand,row.unit);rd,_=display(row.resistance,row.unit)
            data.append({'Verificação':row.name,'Solicitação':sd,'Resistência / limite':rd,'Unidade':unit,'Índice':row.ratio,'Resultado':row.outcome,'Caso':row.case})
        st.dataframe(display_frame(pd.DataFrame(data)),hide_index=True,width='stretch')
        with st.expander('Equações, substituições e referências'):
            st.caption(COMPRESSION_NOTE)
            if c.internal_fin_perforation:st.caption('Talas e alma da viga conservam as faixas locais existentes. O grupo elástico das três bordas soldadas e o escoamento local do metal-base na linha da junta têm verificações próprias. A transferência em membrana e a estabilidade da nervura perfurada, os demais modos do metal-base e os receptores permanecem pendentes.')
            else:st.caption('Cortes e braços de V: talas/alma = '+number(c.group_e,4)+' mm; aba livre da nervura = '+number(c.extension+c.gap/2,4)+' mm; trecho interno = '+number(c.pin_x,4)+' mm. Envoltórias locais não representam uma distribuição física simultânea única.')
            for row in r.checks:
                st.markdown('**'+row.name+'**');st.code(row.equation,language=None);st.caption(calculated_text(row.substitution)+' | '+calculated_text(row.variables, assignments_only=True));st.caption(row.reference)
    st.subheader('Salvar projeto e memória')
    a,b,cx=st.columns(3)
    a.download_button('Baixar projeto JSON',encoded,'Ligacao_duas_talas_LRO.json','application/json',use_container_width=True)
    if can_draw:b.download_button('Baixar desenho SVG',image_bytes(c,'svg'),'Ligacao_duas_talas_LRO.svg','image/svg+xml',use_container_width=True)
    detailed=st.checkbox('Memória detalhada: todas as substituições',key='dc_detailed')
    if cx.button('Gerar memória de duas talas',disabled=not can_report,use_container_width=True):
        st.session_state.dc_report=(digest,detailed,create_report(c,r,detailed))
    saved=st.session_state.get('dc_report')
    if saved and saved[0]==digest and saved[1]==detailed:
        st.download_button('Baixar memória de duas talas .docx',saved[2],'Memoria_duas_talas_LRO.docx','application/vnd.openxmlformats-officedocument.wordprocessingml.document')
    st.divider()
    st.subheader('Premissas adotadas')
    st.write('Modelo plano, contenção eficaz da viga e juntas internas dos perfis soldados com penetração total. Análise global dos membros, fadiga, atrito e ações cíclicas permanecem fora do modelo local.')
    st.write(ASSEMBLY_NOTE)
    for issue in r.issues:
        if issue.severity=='excluded' and issue.text!=ASSEMBLY_NOTE:st.write(calculated_text(issue.text, assignments_only=True))
    st.caption(BRAND)
