"""Same aligned rolled-W static CJP splice. Units N, mm, MPa.

Fakury Eqs 10.19--10.27 are a nominal elastic weld-group idealization;
NBR 8800:2024 / Errata 1:2025 controls materials and detailing.
"""
from __future__ import annotations
from dataclasses import asdict, dataclass, fields, replace
import math
from .models import finite_real

FAMILY = 'Emenda W · soldada · N/M/V'
CONNECTION_TYPE = 'welded_w_splice'
COMPONENT_VERSION = '0.9.23-welded-w-splice-dev'
LOAD_MODEL = 'Fakury_nominal_elastic_CJP_group_N_Mmajor_Vweb'
GAMMA_A1, GAMMA_A2 = 1.10, 1.35
UNITS = {'force': 'N', 'length': 'mm', 'stress': 'MPa', 'moment': 'N mm'}
DECLARATIONS = ('material_certified', 'compatibility_declared', 'procedure_qualified',
                'inspection_plan_declared', 'actual_geometry_verified', 'cut_quality_verified',
                'root_access_verified', 'alignment_verified', 'integrity_included')
SCOPE = ('Dois W laminados iguais e alinhados; CJP nas duas mesas e na alma remanescente. '
         'N positivo em tração, M positivo traciona y positivo, V positivo no plano da alma. '
         'Tensões nominais de grupo elástico de soldas, não picos físicos nas aberturas. '
         'V integral verificado separadamente na alma receptora. Ambos os membros são caminhos em série.')
EXCLUSIONS = ['Flambagem global, estabilidade lateral e análise de segunda ordem pertencem ao projeto dos membros/sistema.',
              'Sem PJP, crédito de contato de topo, cobrejunta, backing, cantoneira ou parafuso de montagem.',
              'Sem torção, flexão no eixo fraco, cortante transversal, fadiga, impacto ou qualificação sísmica.',
              'Detalhes não padronizados, mesas recortadas e perfis pesados com tf>50 mm estão fora do detalhe qualificado.',
              'Classificação e estabilidade flexional do membro íntegro permanecem no projeto do membro; este módulo não certifica compacidade à flexão.']

@dataclass(frozen=True)
class LoadCase:
    id: str = 'real_2'
    label: str = 'Combinação adicional'
    N: float = 0.0
    M: float = 0.0
    V: float = 0.0
    torsion: float = 0.0
    weak_M: float = 0.0
    transverse_V: float = 0.0

@dataclass(frozen=True)
class WeldedWSplice:
    project: str = 'Emenda W310 × 97 · CJP · exemplo de cálculo'
    orientation: str = 'beam'
    profile_name: str = 'W 310 × 97,0 (H)'
    profile_b_name: str = 'W 310 × 97,0 (H)'
    profile_source: str = 'Dimensões nominais declaradas; retângulos sem crédito dos filetes de raiz'
    profile_kind: str = 'rolled_W'
    d: float = 308.0
    bf: float = 305.0
    tf: float = 15.4
    tw: float = 9.9
    root_radius: float = 16.1
    clear_web_height: float = 245.0
    steel_a: str = 'ASTM A572 Gr.50'
    steel_b: str = 'ASTM A572 Gr.50'
    offset_y: float = 0.0
    offset_z: float = 0.0
    rotation: float = 0.0
    depth_mismatch: float = 0.0
    flange_mismatch: float = 0.0
    web_mismatch: float = 0.0
    weld_type: str = 'CJP'
    flange_weld_length: float = 305.0
    flange_weld_throat: float = 15.4
    web_weld_length: float = 227.2
    web_weld_throat: float = 9.9
    access_detail: str = 'NBR_Fig25_alt1_2_tangent_circle'
    access_h0: float = 25.0
    access_hmax_a: float = 25.0
    access_hmax_b: float = 25.0
    access_length_a: float = 45.0
    access_length_b: float = 45.0
    access_radius_a: float = 10.0
    access_radius_b: float = 10.0
    root_clearance: float = 2.0
    process: str = 'SMAW'
    consumable: str = 'E7018'
    procedure_id: str = ''
    material_certified: bool = False
    compatibility_declared: bool = False
    procedure_qualified: bool = False
    inspection_plan_declared: bool = False
    actual_geometry_verified: bool = False
    cut_quality_verified: bool = False
    root_access_verified: bool = False
    alignment_verified: bool = False
    N: float = -600000.0
    M: float = 120000000.0
    V: float = 100000.0
    torsion: float = 0.0
    weak_M: float = 0.0
    transverse_V: float = 0.0
    load_cases: tuple[LoadCase, ...] = ()
    minimum_force: bool = True
    integrity_included: bool = False
    static: bool = True
    normal_combination: bool = True
    fatigue: bool = False
    seismic: bool = False
    impact: bool = False
    notes: str = ''

    @property
    def fixed_assumptions(self):
        return {'load_model': LOAD_MODEL, 'serial_members': True, 'root_fillet_credit': False,
                'end_bearing_credit': False, 'backing_credit': False, 'erection_credit': False,
                'receiver_web_full_V': True, 'normal_sign': 'positive_tension',
                'moment_sign': 'positive_tension_at_positive_y',
                'receiver_model': 'bounded_nominal_sections_with_signed_moment_transport',
                'short_access_domain': 'L<=max(45mm,1.5tw+5mm,2R+5mm); initial_implementation_not_NBR_maximum',
                'axial_compression_domain': 'N<0_requires_Table4_nonslender_intact_rolled_W; not_flexural_compactness',
                'physical_hole_peak_claim': False, 'gamma_a1': GAMMA_A1, 'gamma_a2': GAMMA_A2}

    def to_dict(self):
        errors = input_errors(self)
        if errors:
            raise ValueError('; '.join(errors))
        raw = asdict(self)
        raw['load_cases'] = [asdict(case) for case in self.load_cases]
        return dict(schema_version=1, connection_type=CONNECTION_TYPE, component_version=COMPONENT_VERSION,
                    connection=raw, units=dict(UNITS), fixed_assumptions=self.fixed_assumptions)

    @classmethod
    def from_dict(cls, data):
        required = {'schema_version', 'connection_type', 'component_version', 'connection', 'units', 'fixed_assumptions'}
        if not isinstance(data, dict) or set(data) != required:
            raise ValueError('Emenda W soldada: campos nativos ausentes ou desconhecidos.')
        if type(data['schema_version']) is not int or data['schema_version'] != 1 or data['connection_type'] != CONNECTION_TYPE or data['component_version'] != COMPONENT_VERSION:
            raise ValueError('Família ou versão da emenda W soldada incompatível.')
        raw = data['connection']
        if not isinstance(raw, dict) or set(raw) != {f.name for f in fields(cls)}:
            raise ValueError('Dados completos da emenda W soldada obrigatórios; sem preenchimento silencioso.')
        raw = dict(raw)
        if not isinstance(raw['load_cases'], list):
            raise ValueError('load_cases deve ser uma lista nativa explícita.')
        cases = []
        for item in raw['load_cases']:
            if not isinstance(item, dict) or set(item) != {f.name for f in fields(LoadCase)}:
                raise ValueError('Caso de carga incompleto ou com campos desconhecidos.')
            cases.append(LoadCase(**item))
        raw['load_cases'] = tuple(cases)
        c = cls(**raw)
        canonical = c.to_dict()
        if not _exact(data['units'], canonical['units']) or not _exact(data['fixed_assumptions'], canonical['fixed_assumptions']):
            raise ValueError('Unidades ou premissas incompatíveis; sem conversão silenciosa.')
        return c


def _exact(a, b):
    return type(a) is type(b) and (set(a) == set(b) and all(_exact(a[k], b[k]) for k in b) if isinstance(b, dict) else a == b)


def presets():
    c = WeldedWSplice()
    return {'W310 × 97 · N/M/V · declarações pendentes': c,
            'W310 × 97 · pilar · reversão': replace(c, orientation='column', N=600000., M=-120000000., V=-100000.),
            'W310 × 97 · grupo passa / alma falha': replace(c, N=0., M=0., V=500000.),
            'W310 × 97 · ações reais nulas': replace(c, N=0., M=0., V=0.)}


def input_errors(c):
    if not isinstance(c, WeldedWSplice):
        return ['Entrada deve ser WeldedWSplice.']
    errors = []
    for f in fields(c):
        value = getattr(c, f.name)
        if f.name == 'load_cases':
            if not isinstance(value, tuple) or len(value) > 100:
                errors.append('load_cases: tupla de até 100 casos explícitos obrigatória.')
            continue
        if f.type in (str, 'str'):
            if not isinstance(value, str): errors.append(f.name+': texto obrigatório.')
        elif f.type in (bool, 'bool'):
            if type(value) is not bool: errors.append(f.name+': booleano explícito obrigatório.')
        elif not finite_real(value):
            errors.append(f.name+': número real finito obrigatório.')
    if isinstance(c.load_cases, tuple):
        used = {'actual', 'minimum_N_positive', 'minimum_N_negative', 'minimum_V_positive', 'minimum_V_negative'}
        for case in c.load_cases:
            if not isinstance(case, LoadCase):
                errors.append('Caso adicional deve ser LoadCase.'); continue
            if not isinstance(case.id, str) or not case.id or case.id in used or case.id.endswith('_force_floor'):
                errors.append('Identificador de caso vazio, reservado ou duplicado.')
            if isinstance(case.id, str): used.add(case.id)
            if not isinstance(case.label, str) or not case.label:
                errors.append('Rótulo do caso obrigatório.')
            for key in ('N','M','V','torsion','weak_M','transverse_V'):
                if not finite_real(getattr(case,key)): errors.append(case.id+'.'+key+': número finito obrigatório.')
    return errors

# evaluate(c), geometry(c), access_outline(c, side), and all_cases(c) follow.

def _finite(value, label):
    if not finite_real(value):
        raise ArithmeticError(label+': resultado não finito.')
    return value


def _positive(value, label):
    _finite(value,label)
    if value <= 0:
        raise ValueError(label+': valor positivo obrigatório.')
    return value


def _tangent(point, center, radius, upper):
    dx, dy = point[0]-center[0], point[1]-center[1]
    dd = _positive(dx*dx+dy*dy,'Distância ao centro do arco')
    if dd <= radius*radius:
        raise ValueError('Boca dentro do círculo: transição tangente inexistente.')
    a = radius*radius/dd
    b = radius*math.sqrt(dd-radius*radius)/dd
    candidates = [(center[0]+a*dx-sign*b*dy, center[1]+a*dy+sign*b*dx) for sign in (-1,1)]
    return min(candidates,key=lambda p:p[1]) if upper else max(candidates,key=lambda p:p[1])


def access_curve(c, side='a'):
    """Exact line / circular-bulb geometry, depths from the flange inner face.

    The right circular arc and its two tangents form the chosen Fig25
    alternative1/2-compatible branch. Hmax encloses *all* actual removed material.
    """
    if side not in ('a','b'):
        raise ValueError('Lado deve ser a ou b.')
    h, hm = c.access_h0, getattr(c,'access_hmax_'+side)
    length, radius = getattr(c,'access_length_'+side), getattr(c,'access_radius_'+side)
    for name,value in [('H0',h),('Hmax',hm),('L',length),('R',radius)]:
        _positive(value,name)
    if not (hm >= h and length >= 2*radius and hm > 2*radius):
        raise ValueError('Ramo tangente exige Hmax≥H0, L≥2R e Hmax>2R.')
    center=(length-radius,hm-radius)
    upper=_tangent((0.,0.),center,radius,True)
    lower=_tangent((0.,h),center,radius,False)
    if not (0<upper[0]<=length and 0<lower[0]<=length and upper[1]>0 and 0<=lower[1]<=hm):
        raise ValueError('Transições tangentes fora do envelope ou sem inclinação superior positiva.')
    au=math.atan2(upper[1]-center[1],upper[0]-center[0])
    al=math.atan2(lower[1]-center[1],lower[0]-center[0])
    if au >= 0 or al <= 0 or al-au >= 2*math.pi:
        raise ValueError('Arco direito ou transições incompatíveis.')
    # Exact arc extrema, rather than trusting sampled drawing points.
    extrema=[upper,lower,(length,center[1])]
    if au<=-math.pi/2<=al:extrema.append((center[0],hm-2*radius))
    if au<=math.pi/2<=al:extrema.append((center[0],hm))
    if any(not(-1e-9<=p[0]<=length+1e-9 and -1e-9<=p[1]<=hm+1e-9) for p in extrema):
        raise ValueError('Curva ultrapassa a remoção máxima declarada.')
    return dict(H0=h,Hmax=hm,L=length,R=radius,center=center,upper_tangent=upper,
                lower_tangent=lower,angle_start=au,angle_end=al,extrema=extrema,
                upper_slope=upper[1]/upper[0],lower_slope=(lower[1]-h)/lower[0],
                model='two_tangents_right_circular_arc')


def access_outline(c, side='a'):
    curve=access_curve(c,side)
    cx,cy=curve['center'];r=curve['R'];a,b=curve['angle_start'],curve['angle_end']
    # Points include extrema explicitly so SVG/PNG bounding boxes reproduce Hmax/L.
    angles=sorted({a,b,0.,*[a+(b-a)*i/64 for i in range(65)],
                   *([math.pi/2] if a<=math.pi/2<=b else []),
                   *([-math.pi/2] if a<=-math.pi/2<=b else [])})
    return [(0.,0.),*[(cx+r*math.cos(t),cy+r*math.sin(t)) for t in angles],(0.,curve['H0']),(0.,0.)]


def section_properties(c, removed_height):
    """Symmetric finite rectangular patches; root/fillet/backing never credited."""
    height=_positive(c.d-2*c.tf-2*removed_height,'Altura remanescente da alma')
    patches=[]
    for name,width,y0,y1 in [('top_flange',c.bf,-c.d/2,-c.d/2+c.tf),
                              ('web',c.tw,-height/2,height/2),
                              ('bottom_flange',c.bf,c.d/2-c.tf,c.d/2)]:
        hh=_positive(y1-y0,'Altura da região');area=_positive(width*hh,'Área da região')
        yc=(y0+y1)/2
        patches.append(dict(name=name,width=width,height=hh,area=area,centroid_y=yc,
                            y_min=y0,y_max=y1,Ix=_finite(width*hh**3/12+area*yc**2,'Ix'),
                            Ix_intrinsic=width*hh**3/12,Iy=_finite(hh*width**3/12,'Iy')))
    return dict(A=_positive(sum(p['area'] for p in patches),'A'),
                Ix=_positive(sum(p['Ix'] for p in patches),'Ix'),
                Iy=_positive(sum(p['Iy'] for p in patches),'Iy'),
                Aw=_positive(height*c.tw,'Área da alma'),web_height=height,patches=patches,centroid_y=0.)


def geometry(c):
    errors=input_errors(c)
    if errors:raise ValueError('; '.join(errors))
    for name in ('d','bf','tf','tw','clear_web_height','access_h0','flange_weld_length','flange_weld_throat','web_weld_length','web_weld_throat'):
        _positive(getattr(c,name),name)
    if not (c.tf<c.d/2 and c.tw<c.bf and c.root_radius>=0 and c.root_clearance>=0):
        raise ValueError('Dimensões do W ou folga/raio fisicamente incompatíveis.')
    core=section_properties(c,c.access_h0)
    g=dict(valid=True,d=c.d,bf=c.bf,tf=c.tf,tw=c.tw,h_clear=c.d-2*c.tf,H0=c.access_h0,
           Aew=core['A'],Ix=core['Ix'],Iy=core['Iy'],Aw=core['Aw'],
           patches=core['patches'],web_weld_length=core['web_height'],centroid_y=0.,
           critical_section_model='symmetric_rectangles_no_root_credit',root_fillet_credit=False)
    for side in ('a','b'):
        curve=access_curve(c,side)
        sec=section_properties(c,curve['Hmax'])
        g['receiver_'+side]=dict(Hmax=curve['Hmax'],L=curve['L'],R=curve['R'],Amin=sec['A'],
            Imin=sec['Ix'],Iymin=sec['Iy'],Aw_min=sec['Aw'],web_height_min=sec['web_height'],
            patches=sec['patches'],x_interval=[-curve['L'],0.] if side=='a' else [0.,curve['L']],
            curve=curve,opening_outline=access_outline(c,side),
            envelope='Conservador nominal: A(x)≥Amin; I(x)≥Imin; |M(x)|≤|M0|+|V|L. Não é pico físico da abertura.')
    return g


def all_cases(c):
    cases=[dict(id='actual',label='Ações reais principais',kind='actual',
                **{key:getattr(c,key) for key in ('N','M','V','torsion','weak_M','transverse_V')})]
    cases += [dict(**asdict(case),kind='actual') for case in c.load_cases]
    if c.minimum_force:
        for case in list(cases):
            resultant=_finite(math.hypot(case['N'],case['V']),'Resultante N/V')
            if 0<resultant<45000.:
                # Divide before multiplication to avoid overflow for subnormal inputs.
                n=case['N']/resultant*45000.;v=case['V']/resultant*45000.
                cases.append(dict(case, id=case['id']+'_force_floor',label='Mínimo 45 kN · '+case['label'],
                                  kind='minimum',N=n,V=v,source_case=case['id'],
                                  reference='NBR 6.1.5.2; convenção resultante hypot(N,V), direção e sentido preservados, M independente mantido'))
    return cases


def _safe(value):
    if isinstance(value,(float,int)) and not isinstance(value,bool):return value if finite_real(value) else None
    if isinstance(value,dict):return {str(k):_safe(v) for k,v in value.items()}
    if isinstance(value,(tuple,list)):return [_safe(v) for v in value]
    return value if value is None or isinstance(value,(str,bool)) else repr(value)


def _issue(out,identifier,severity,message,reference=''):
    out['issues'].append(dict(id=identifier,severity=severity,message=message,reference=reference))


def _check(out,case,component,mechanism,label,demand,resistance,unit,reference,**metadata):
    _finite(demand,label);_positive(resistance,label+' resistência')
    utilization=_finite(abs(demand)/resistance,label+' índice')
    row=dict(id=case['id']+'::'+component+'::'+mechanism,label=label,component=component,
             mechanism=mechanism,case_id=case['id'],kind=case['kind'],demand=abs(demand),
             resistance=resistance,utilization=utilization,status='PASS' if utilization<=1.+1e-10 else 'FAIL',
             unit=unit,reference=reference,metadata=metadata)
    out['checks'].append(row)
    return row


def _stress_checks(out,case,component,sigma,tau,fy,reference,**metadata):
    nr=fy/GAMMA_A1;sr=.6*nr
    _check(out,case,component,'normal','Tensão normal nominal',abs(sigma),nr,'MPa',reference,**metadata)
    _check(out,case,component,'shear','Cisalhamento nominal',abs(tau),sr,'MPa',reference,**metadata)
    eq=_finite(math.hypot(sigma,math.sqrt(3)*tau),'Tensão equivalente nominal')
    if sigma != 0 and tau != 0:
        _check(out,case,component,'interaction','Interação nominal no mesmo ponto/envelope',eq,nr,'MPa',
               'Fakury Eq.10.27 (critério suplementar), não equação da Tabela9 NBR',**metadata)
    return dict(sigma=sigma,tau=tau,equivalent=eq,normal_utilization=abs(sigma)/nr,
                shear_utilization=abs(tau)/sr,interaction_applicable=sigma!=0 and tau!=0,
                utilization=max(abs(sigma)/nr,abs(tau)/sr,eq/nr if sigma!=0 and tau!=0 else 0.))


def _group_case(c,g,case,out,fy):
    n,m,v=case['N'],case['M'],case['V'];a,i=g['Aew'],g['Ix'];tau=v/a
    stresses=[];forces=[]
    for patch in g['patches']:
        for end,y in [('min',patch['y_min']),('max',patch['y_max'])]:
            sigma=_finite(n/a+m*y/i,'Tensão no grupo CJP')
            component='weld_'+patch['name']+'_'+end
            stresses.append(dict(point=component,y=y,**_stress_checks(out,case,component,sigma,tau,fy,
                'NBR Tabela9; Fakury Eqs10.19–10.27',y=y,model=LOAD_MODEL)))
        # Exact polynomial integration includes intrinsic flange inertia.
        force=n*patch['area']/a+m*patch['area']*patch['centroid_y']/i
        moment=n*patch['area']*patch['centroid_y']/a+m*patch['Ix']/i
        forces.append(dict(patch=patch['name'],N=force,M=moment,V=tau*patch['area']))
    recovered={key:sum(row[key] for row in forces) for key in ('N','M','V')}
    residual={key:_finite(recovered[key]-case[key],'Resíduo de equilíbrio') for key in recovered}
    scales={key:max(1.,abs(case[key]),sum(abs(q[key]) for q in forces)) for key in residual}
    eqok=all(abs(residual[key])<=1e-9*scales[key] for key in residual)
    if not eqok:_issue(out,'equilibrium_'+case['id'],'numerical_failure','Integração do campo não recupera as ações.')
    return dict(case_id=case['id'],stresses=stresses,patch_resultants=forces,
                group_utilization=max(row['utilization'] for row in stresses),
                equilibrium=dict(integrated=recovered,residual=residual,verified=eqok,
                                 tolerance='1e-9×max(1,|ação|,soma|resultantes das regiões|)',scales=scales,minor_moment=0.,torsion=0.),
                model=LOAD_MODEL,physical_hole_peak_claim=False)


def _receiver_case(c,g,case,out,side,fy,fu):
    sec=g['receiver_'+side];a,i,aw=sec['Amin'],sec['Imin'],sec['Aw_min'];n,m,v=case['N'],case['M'],case['V']
    # x signed away from splice: M(x)=M0−V*x; max absolute is bounded.
    actual_end_moments=[_finite(m-v*x,'Momento no corte local') for x in sec['x_interval']]
    mb=_finite(abs(m)+abs(v)*sec['L'],'Envelope de momento')
    sf=_finite(abs(n)/a+mb*(c.d/2)/i,'Envelope normal da mesa')
    sw=_finite(abs(n)/a+mb*(c.d/2-c.tf)/i,'Envelope normal da alma')
    common=dict(side=side,Amin=a,Imin=i,Aw_min=aw,M_bound=mb,x_interval=sec['x_interval'],
                signed_M_endpoints=actual_end_moments,nominal_envelope=True,physical_hole_peak_claim=False)
    flange=_stress_checks(out,case,'receiver_'+side+'_section',sf,abs(v)/a,fy,
                         'NBR 6.5.3/6.5.4; envelope nominal conservador',**common)
    web=_stress_checks(out,case,'receiver_'+side+'_web_nominal',sw,abs(v)/aw,fy,
                       'NBR 6.5.5; interação nominal suplementar; V integral',**common)
    yrd=.6*fy*aw/GAMMA_A1;urd=.6*fu*aw/GAMMA_A2
    web_shear=_check(out,case,'receiver_'+side+'_web','full_shear','Alma receptora · V integral',
                    abs(v),min(yrd,urd),'N','NBR 6.5.5',yield_Rd=yrd,rupture_Rd=urd,Agv=aw,Anv=aw,
                    serial_members=True,group_shear_fraction_not_used=True,**common)
    # Both matching presets use equal Ag=An=Ae and yield stress below rupture stress.
    dominance=dict(Ae=a,An=a,Ag=a,normal_yield=fy/GAMMA_A1,normal_rupture=fu/GAMMA_A2,
                   shear_yield=yrd,shear_rupture=urd,yield_dominates=fy/GAMMA_A1<=fu/GAMMA_A2,
                   no_bolted_085_cap=True,reference='NBR6.5.3/6.5.5; mesmas áreas reais/equivalentes')
    if not dominance['yield_dominates']:
        _check(out,case,'receiver_'+side+'_section','net_tension','Ruptura na seção líquida real',sf,fu/GAMMA_A2,
               'MPa','NBR6.5.3; limite conservador',**common)
    return dict(side=side,section=flange,web_nominal=web,full_web_shear_utilization=web_shear['utilization'],
                M_bound=mb,signed_M_endpoints=actual_end_moments,rupture_dominance=dominance,
                envelope_not_second_equilibrium_field=True)


def evaluate(c):
    out=dict(family=FAMILY,component_version=COMPONENT_VERSION,status='INVALID_INPUT',global_pass=False,
             geometry={'valid':False},checks=[],cases=[],issues=[],group_cases=[],receiver_cases=[],
             summary={'complete_checks':False},scope=SCOPE,exclusions=list(EXCLUSIONS),load_model=LOAD_MODEL)
    errors=input_errors(c)
    if errors:
        for e in errors:_issue(out,'input','invalid_input',e)
        return _safe(out)
    try:
        return _safe(_evaluate(c,out))
    except ValueError as exc:
        _issue(out,'geometry','invalid_geometry',str(exc));out['status']='INVALID_GEOMETRY'
    except (OverflowError,ZeroDivisionError,ArithmeticError) as exc:
        _issue(out,'numeric','numerical_failure',str(exc));out['status']='NUMERICAL_FAILURE'
    out['global_pass']=False;out['summary']['complete_checks']=False
    return _safe(out)


def _evaluate(c,out):
    g=geometry(c);out['geometry']=g;cases=all_cases(c);out['cases']=cases
    for key in DECLARATIONS:
        if not getattr(c,key):_issue(out,key,'pending',key+': declaração explícita ainda pendente.')
    if not c.procedure_id.strip():_issue(out,'procedure_id','pending','Identificar o procedimento de soldagem aplicável; os valores do exemplo não aprovam WPS.')
    unsupported=[]
    if c.orientation not in ('beam','column'):unsupported.append('Orientação deve ser viga ou pilar.')
    if c.profile_kind!='rolled_W' or c.profile_name!=c.profile_b_name:unsupported.append('São exigidos dois perfis W laminados idênticos.')
    if any(getattr(c,k)!=0 for k in ('offset_y','offset_z','rotation','depth_mismatch','flange_mismatch','web_mismatch')):unsupported.append('Desalinhamento ou diferença medida exige outro detalhe; não é ignorado por nome igual.')
    if not c.static or not c.normal_combination or c.fatigue or c.seismic or c.impact:unsupported.append('Somente combinações últimas normais estáticas, sem fadiga/impacto/sismo.')
    if any(any(case[k]!=0 for k in ('torsion','weak_M','transverse_V')) for case in cases):unsupported.append('Ações fora do domínio preservadas: torção, M no eixo fraco ou V transversal não são descartados.')
    if c.weld_type!='CJP':unsupported.append('A família exige penetração total nas duas mesas e na alma; PJP não implementada.')
    if (c.process,c.consumable)!=('SMAW','E7018'):unsupported.append('Processo/consumível fora da compatibilidade inicial implementada SMAW/E7018.')
    if c.access_detail!='NBR_Fig25_alt1_2_tangent_circle':unsupported.append('Somente o ramo geométrico tangente/circular das alternativas1/2 está qualificado; alternativa3 não vale para W laminado.')
    if c.tf>50.:unsupported.append('Perfil pesado: tf>50 mm exige regras adicionais de tenacidade/preparo; fora do detalhe qualificado inicial (NBR6.1.12/6.2.4.2/12.2.1.2.5–.6).')
    materials={name:(345.,450.) for name in ('ASTM A572 Gr.50','ASTM A992')}
    if c.steel_a not in materials or c.steel_b not in materials:unsupported.append('Aço fora dos presets compatíveis A572Gr50/A992 com E7018 e espessura qualificada.')
    # Explicit finite-method domain, NOT a normative maximum opening length.
    for side in ('a','b'):
        sec=g['receiver_'+side]
        limit=max(45.,1.5*c.tw+5.,2*sec['R']+5.)
        sec['short_detail_length_limit']=limit
        sec['short_detail_within_domain']=sec['L']<=limit
        if sec['L']>limit:
            unsupported.append('Lado '+side+': abertura longa fora do ramo inicial curto L≤max(45;1,5tw+5;2R+5) mm. Este limite de implementação não é um máximo normativo NBR.')
    compression_active=any(q['N']<0 for q in cases)
    # Table4 is an ordinary axial-compression section eligibility condition;
    # never apply it merely because orientation is column or an M edge compresses.
    flange_lambda=c.bf/(2*c.tf);web_lambda=c.clear_web_height/c.tw
    flange_limit=.56*math.sqrt(200000./345.);web_limit=1.49*math.sqrt(200000./345.)
    eligible=flange_lambda<=flange_limit and web_lambda<=web_limit
    out['local_section_eligibility']=dict(compression_active=compression_active,
        flange_lambda=flange_lambda,flange_limit=flange_limit,web_lambda=web_lambda,web_limit=web_limit,
        applied=bool(compression_active),eligible=(eligible if compression_active else None),
        reference='NBR5.3.4.1/Tabela4, grupos4 e2; dimensões5.1.2.2.3/.4',
        interpretation='Restrição inicial de seção íntegra não esbelta somente quando N<0; não é falha resistente, compacidade à flexão ou prova de estabilidade de rasgos arbitrários.',
        compression_connection_element='Detalhe padrão curto sem novo elemento de ligação isolado; não são criadas colunas fictícias de mesa/alma.',
        flexural_member_classification_external=True,global_member_buckling_external=True)
    if compression_active and not eligible:
        unsupported.append('N<0 com seção fora do ramo inicial não esbelto da Tabela4; requer outra qualificação de compressão. Não é uma declaração de falha nem um limite universal para vigas.')
    for msg in unsupported:_issue(out,'scope','outside_scope',msg)
    if unsupported:
        out['status']='OUTSIDE_SCOPE';return out
    fy=min(materials[c.steel_a][0],materials[c.steel_b][0]);fu=min(materials[c.steel_a][1],materials[c.steel_b][1])
    out['materials']=dict(member_a=c.steel_a,member_b=c.steel_b,fy=fy,fu=fu,process=c.process,consumable=c.consumable,
                          gamma_a1=GAMMA_A1,gamma_a2=GAMMA_A2,compatibility='NBR Tabela8, confirmação da WPS separada')
    detail=[]
    if not math.isclose(c.clear_web_height,c.d-2*c.tf-2*c.root_radius,rel_tol=1e-10,abs_tol=1e-8):detail.append('Altura plana da alma incompatível com d,tf e os dois raios reais de raiz.')
    if c.access_h0<c.root_radius+c.root_clearance:detail.append('A abertura no corte não libera o raio/k declarado e a folga exigida.')
    if c.access_h0<20. or c.access_h0<=c.tw:detail.append('Altura de acesso exige H0≥20 mm e H0>tw (NBR6.1.13).')
    for side in ('a','b'):
        sec=g['receiver_'+side]
        if sec['L']<40. or sec['L']<=1.5*c.tw:detail.append('Lado '+side+': L≥40 mm e L>1,5tw obrigatórios.')
        if sec['R']<10.:detail.append('Lado '+side+': R≥10 mm obrigatório.')
        if sec['Hmax']>50.:detail.append('Lado '+side+': altura máxima>50 mm fora do detalhe padrão inicial, exige qualificação específica.')
    pairs=[('flange_weld_length',c.bf),('flange_weld_throat',c.tf),('web_weld_length',g['web_weld_length']),('web_weld_throat',c.tw)]
    weld_mismatches=[]
    for name,target in pairs:
        if not math.isclose(getattr(c,name),target,rel_tol=1e-12,abs_tol=1e-9):
            detail.append(name+': CJP deve cobrir a largura/espessura real integral; garganta ou comprimento divergente.')
            weld_mismatches.append(dict(field=name,declared=getattr(c,name),required=target,unit='mm'))
    if not c.minimum_force and any(0<math.hypot(q['N'],q['V'])<45000. for q in cases):detail.append('Piso obrigatório45kN desativado com força atuante abaixo dele.')
    for msg in detail:_issue(out,'detail','detail_fail',msg,'NBR6.1.13/6.2.2.1/12.2.1.2/Fig25')
    if weld_mismatches:
        # A partial run is not the prescribed full-CJP load path. Never publish
        # hypothetical full-section strengths alongside a shorter/thinner weld.
        g['strength_model_valid']=False
        g['weld_mismatches']=weld_mismatches
        g['required_full_cjp_reference']={key:g[key] for key in ('Aew','Ix','Iy','Aw','patches')}
        for key in ('Aew','Ix','Iy','Aw'):g[key]=None
        g['patches']=[]
        out['status']='DETAIL_FAIL'
        out['summary']['complete_checks']=False
        return out
    g['strength_model_valid']=True
    if all(q['N']==q['M']==q['V']==0 for q in cases):
        _issue(out,'zero_actions','info','Todos os esforços reais são nulos; não se inventa direção para45kN. Conferir o conjunto de ações/integridade declarado.')
    out['minimum_action_basis']=dict(force_floor_N=45000.,enabled=c.minimum_force,
        convention='Para0<hypot(N,V)<45kN: N,V escalados na mesma direção/sentido; M independente mantido. R=0 não inventa direção nem força.',
        actual_cases_unchanged=True,no_invented_minimum_moment=True,
        discretionary_recommendation='6.1.5.3: recomendação proporcional à resistência do membro a critério do responsável; sem imposição automática.',
        integrity_included=c.integrity_included)
    lam=c.clear_web_height/c.tw;lp=1.10*math.sqrt(5.34*200000./fy);lr=1.37*math.sqrt(5.34*200000./fy)
    factor=1. if lam<=lp else lp/lam if lam<=lr else 1.24*(lp/lam)**2
    adjacent_rd=_positive(.6*fy*(c.d*c.tw)*factor/GAMMA_A1,'Cortante da alma adjacente')
    out['adjacent_web']=dict(lambda_=lam,lambda_p=lp,lambda_r=lr,kv=5.34,E=200000.,Aw=c.d*c.tw,
                             factor=factor,branch='yielding' if lam<=lp else 'inelastic' if lam<=lr else 'elastic',
                             VRd=adjacent_rd,reference='NBR5.4.3.1.1–.2; alma adjacente sem enrijecedores')
    for case in cases:
        out['group_cases'].append(_group_case(c,g,case,out,fy))
        for side in ('a','b'):out['receiver_cases'].append(dict(case_id=case['id'],**_receiver_case(c,g,case,out,side,fy,fu)))
        _check(out,case,'adjacent_web','shear_stability','Cortante na alma adjacente · estabilidade',abs(case['V']),adjacent_rd,
               'N','NBR5.4.3.1.1–.2',**{k:v for k,v in out['adjacent_web'].items() if k!='reference'})
    complete=bool(out['checks']) and not any(i['severity']=='numerical_failure' for i in out['issues'])
    maximum=max(row['utilization'] for row in out['checks']) if out['checks'] else None
    governing=[row['id'] for row in out['checks'] if math.isclose(row['utilization'],maximum,rel_tol=1e-10,abs_tol=1e-12)] if maximum is not None else []
    out['summary']=dict(complete_checks=complete,utilization=maximum,governing=governing,
                        actual_utilization=max((row['utilization'] for row in out['checks'] if row['kind']=='actual'),default=None),
                        case_count=len(cases),check_count=len(out['checks']))
    if any(i['severity']=='numerical_failure' for i in out['issues']):out['status']='NUMERICAL_FAILURE'
    elif detail:out['status']='DETAIL_FAIL'
    elif any(row['status']=='FAIL' for row in out['checks']):out['status']='LOCAL_CHECKS_FAIL'
    elif any(i['severity']=='pending' for i in out['issues']):out['status']='NOT_VERIFIED'
    else:out['status']='LOCAL_CHECKS_PASS_WITHIN_SCOPE';out['global_pass']=complete
    return out
