"""Actual M-004 balanced W splice, bounded to concentric axial tension.

N, mm, MPa throughout. Both member ends act in series. General N/M/V is a
separate conventional family and never falls through to an axial pass.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict, fields, replace
import math
import hashlib
import json
from copy import deepcopy
from .models import Profile, profiles, STEELS, BOLTS, finite_real

FAMILY = 'Emenda W · M004 · tração axial'
CONNECTION_TYPE = 'w_splice_m004_balanced_axial_tension'
COMPONENT_VERSION = '0.9.0-w-dev'
NBR = 'ABNT NBR 8800:2024, versão corrigida 2025'
GAMMA_A1, GAMMA_A2 = 1.10, 1.35
TOL = 1e-10
SCOPE = ('Emenda de dois perfis W idênticos e coaxiais, oito talas contínuas: duas na alma, '
         'duas externas às mesas e quatro tiras internas. Tração axial estática; M=V=T=0. '
         'Talas balanceadas, furos circulares alinhados, duas seções de corte por parafuso.')
MODEL_GATES = []  # Bounded N-only basis: docs/W_SPLICE_M004_TENSION_SCOPE.md; independent rational oracle.
EXCLUSIONS = [
    'Momento, cortante, torção, compressão, fadiga, impacto e inversão de tensões fora deste primeiro domínio.',
    'Não qualifica rigidez de pórtico, resistência ao deslizamento ou continuidade de ligação rígida.',
    'Não dimensiona a estabilidade global dos membros nem a sequência de montagem.',
    'Outras topologias, perfis diferentes, calços, rasgos, recortes, furos escalonados e soldas participantes não são admitidos.',
]

@dataclass(frozen=True)
class WSplice:
    profile: Profile
    project: str = 'Emenda W M004 · tração axial'
    N: float = 500000.0
    M: float = 0.0
    V: float = 0.0
    torsion: float = 0.0
    flange_outer_width: float = 240.0
    flange_inner_width: float = 120.0
    inner_clear_band: float = 50.0
    flange_t: float = 16.0
    web_height: float = 200.0
    web_t: float = 10.0
    flange_rows: int = 4
    flange_pitch: float = 60.0
    flange_member_end: float = 40.0
    flange_cover_end: float = 40.0
    web_rows: int = 2
    web_levels: int = 3
    web_pitch: float = 60.0
    web_gauge: float = 60.0
    web_member_end: float = 40.0
    web_cover_end: float = 40.0
    gap: float = 10.0
    root_radius: float = 17.05
    fabrication_clearance: float = 3.0
    tool_radius: float = 25.0
    member_steel: str = 'ASTM A572 Gr.50'
    flange_steel: str = 'ASTM A36'
    web_steel: str = 'ASTM A36'
    bolt: str = 'ASTM F3125 A325'
    db: float = 20.0
    hole_diameter: float = 22.0
    drilled: bool = False
    threads_excluded_verified: bool = False
    exposure: str = 'painted'
    static: bool = True
    normal_combination: bool = True
    concentric: bool = True
    no_slip_required: bool = False
    minimum_action_policy: str = 'tension_strength'
    compression_resistance: float = 0.0
    compression_reference: str = ''
    integrity_included: bool = True
    notes: str = ''

    @property
    def fixed_assumptions(self):
        return {'topology': 'M004_eight_covers_balanced', 'members': 'identical_coaxial_W',
                'shear_planes_per_bolt': 2, 'splice_sides': 'series_do_not_add',
                'web_bolt_grid': [2, 3], 'flange_columns': 2,
                'outside_flange_force_fraction': .5, 'each_inner_strip_force_fraction': .25,
                'web_cover_force_fraction': .5, 'gamma_a1': GAMMA_A1, 'gamma_a2': GAMMA_A2,
                'minimum_assembly_action_N': 45000., 'uniform_axial_bolt_forces': True,
                'whole_section_Ct': 1., 'cover_Ae': 'min(An,0.85Ag)',
                'partition': 'Aw=tw*(d-2tf); Af_allocated=(A-Aw)/2',
                'bearing_deformation_is_design_limitation': True,
                'normal_ultimate_combinations_only': True, 'net_cut': 'all_holes_conservative_aligned_envelope',
                'supported_actions': 'N>0, M=V=T=0', 'standard_round_holes_only': True, 'net_hole_policy': 'Table14_maximum_plus_2mm_unless_documented_drilled',
                'integrity_actions': 'Provided N must include applicable system integrity actions; no global system check'}

    def to_dict(self):
        errors = input_errors(self)
        if errors: raise ValueError('; '.join(errors))
        return {'schema_version': 1, 'connection_type': CONNECTION_TYPE, 'component_version': COMPONENT_VERSION,
                'connection': asdict(self), 'units': {'force':'N','length':'mm','stress':'MPa','moment':'N mm'},
                'fixed_assumptions': self.fixed_assumptions}

    @classmethod
    def from_dict(cls, data):
        allowed={'schema_version','connection_type','component_version','connection','units','fixed_assumptions'}
        if not isinstance(data,dict) or set(data)!=allowed: raise ValueError('Projeto W: campos ausentes ou desconhecidos.')
        if type(data['schema_version']) is not int or data['schema_version']!=1 or data['connection_type']!=CONNECTION_TYPE or data['component_version']!=COMPONENT_VERSION:
            raise ValueError('Família ou versão de emenda W incompatível.')
        raw=data['connection']
        if not isinstance(raw,dict) or set(raw)!={f.name for f in fields(cls)}: raise ValueError('Dados da emenda W incompletos ou desconhecidos.')
        raw=dict(raw); pr=raw['profile']
        if not isinstance(pr,dict) or set(pr)!={f.name for f in fields(Profile)}: raise ValueError('Perfil W inválido ou incompleto.')
        raw['profile']=Profile(**pr); c=cls(**raw)
        canonical=c.to_dict()
        for key in ('units','fixed_assumptions'):
            if data[key]!=canonical[key]: raise ValueError(f'{key}: premissas/unidades incompatíveis, sem conversão silenciosa.')
        return c


def presets():
    base=WSplice(profiles()['W 310 x 97,0 (H)'])
    return {'W 310 × 97 · 500 kN':base,
            'W 310 × 97 · solicitação elevada':replace(base,project='Emenda W · solicitação elevada',N=2200000.),
            'W estreito · fora do ajuste balanceado':replace(base,profile=profiles()['W 200 x 26,6'],project='Emenda W · verificar encaixe')}


def input_errors(c):
    if not isinstance(c,WSplice): return ['A entrada deve ser WSplice.']
    errors=[]
    names={'project','member_steel','flange_steel','web_steel','bolt','exposure','notes','minimum_action_policy','compression_reference'}
    bools={'drilled','threads_excluded_verified','static','normal_combination','concentric','no_slip_required','integrity_included'}
    ints={'flange_rows','web_rows','web_levels'}
    for f in fields(c):
        name=f.name; v=getattr(c,name)
        if name=='profile': continue
        if name in names:
            if not isinstance(v,str): errors.append(f'{name}: texto obrigatório.')
        elif name in bools:
            if type(v) is not bool: errors.append(f'{name}: booleano explícito obrigatório.')
        elif name in ints:
            if type(v) is not int or not 1<=v<=20: errors.append(f'{name}: inteiro entre 1 e 20 obrigatório.')
        elif not finite_real(v): errors.append(f'{name}: número finito obrigatório.')
        elif name not in ('N','M','V','torsion','gap','root_radius','fabrication_clearance','compression_resistance') and v<=0:
            errors.append(f'{name}: dimensão positiva obrigatória.')
        elif name in ('gap','root_radius','fabrication_clearance') and v<0: errors.append(f'{name}: valor não negativo obrigatório.')
    if not isinstance(c.profile,Profile): errors.append('profile: perfil documentado obrigatório.')
    else:
        for key in ('d','bf','tw','tf','clear','area','mass'):
            if not finite_real(getattr(c.profile,key)) or getattr(c.profile,key)<=0: errors.append(f'profile.{key}: positivo finito obrigatório.')
        for key in ('name','family','source'):
            if not isinstance(getattr(c.profile,key),str): errors.append(f'profile.{key}: texto obrigatório.')
    if c.minimum_action_policy not in ('tension_strength','slenderness','engineer_waived'): errors.append('Critério mínimo do membro desconhecido.')
    if finite_real(c.compression_resistance) and c.compression_resistance<0: errors.append('compression_resistance: não negativa obrigatória.')
    return errors


def _safe(x):
    if isinstance(x,float) and not math.isfinite(x): return str(x)
    if isinstance(x,dict): return {str(k):_safe(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)): return [_safe(v) for v in x]
    return x if x is None or isinstance(x,(str,int,float,bool)) else repr(x)


def _issue(out,severity,text,ref='',**extra):
    out['issues'].append(dict(severity=severity,text=text,reference=ref,**extra))


def _check(identifier,label,component,N,capacity,fraction,formula,reference,**details):
    if not all(finite_real(v) and v>0 for v in (N,capacity,fraction)): raise ArithmeticError(identifier+': resistência, ação ou fração não positiva/finita.')
    demand=N*fraction
    return dict(id=identifier,label=label,component=component,demand_N=demand,design_capacity_N=capacity,
                utilization=demand/capacity,status='PASS' if demand/capacity<=1+TOL else 'FAIL',
                demand_fraction_of_total_N=fraction,equivalent_total_N_capacity_N=capacity/fraction,
                formula=formula,reference=reference,**details)


def block_paths(*,identifier,width,thickness,end,pitch,nrows,columns,dn,fy,fu,fraction,N,free_sides):
    """Concentric rectilinear U/L paths, every prefix and physical mirror.

    columns are real positions within a plate. No artificial duplicate column
    and no free side boundary at a member web/flange interface.
    """
    checks=[]; mtotal=len(columns)
    for k in range(1,nrows+1):
        L=end+(k-1)*pitch; Ln=L-(k-.5)*dn
        candidates=[]
        for m in range(2,mtotal+1):
            for start in range(mtotal-m+1):
                span=columns[start+m-1]-columns[start]
                candidates.append(('U',f'columns{start+1}to{start+m}',m,2,(span-(m-1)*dn)*thickness,1.))
        if free_sides:
            for side in ('negative','positive'):
                for m in range(1,mtotal+1):
                    stop=columns[m-1] if side=='negative' else columns[-m]
                    transverse=width/2+stop if side=='negative' else width/2-stop
                    candidates.append(('L',f'{side}_m{m}',m,1,(transverse-(m-.5)*dn)*thickness,1. if m==1 else .5))
        for family,mirror,m,legs,Ant,Cts in candidates:
            Agv=legs*L*thickness; Anv=legs*Ln*thickness
            if min(Agv,Anv,Ant)<=0: raise ArithmeticError(identifier+': caminho de bloco com área não positiva.')
            rs=.6*fu*Anv; ys=.6*fy*Agv; rt=Cts*fu*Ant
            checks.append(_check(f'{identifier}_block_{family}_{mirror}_k{k}',f'Bloco {family} · {mirror} · k={k}',identifier,N,
                (min(rs,ys)+rt)/GAMMA_A2,fraction*k*m/(nrows*mtotal),
                '[min(0,60fu Anv;0,60fy Agv)+Cts fu Ant]/γa2',NBR+', 6.5.6; figura 16',
                path_family=family,mirror=mirror,k=k,m=m,Agv_mm2=Agv,Anv_mm2=Anv,Ant_mm2=Ant,Cts=Cts,
                number_shear_legs=legs,gross_axial_length_mm=L,net_axial_length_per_leg_mm=Ln,
                demand_fraction_of_component=k*m/(nrows*mtotal),
                nominal_shear_rupture_N=rs,nominal_shear_yield_N=ys,nominal_tension_N=rt))
    return checks


def geometry(c,out):
    p=c.profile; dh=c.hole_diameter
    table_hole={16.:18.,20.:22.,24.:27.,30.:33.}.get(c.db,dh)
    dn=table_hole+(0. if c.drilled else 2.)
    inner=getattr(c,'include_inner_flange_plates',True)
    gf=c.inner_clear_band+c.flange_inner_width if inner else c.flange_bolt_gauge
    wf=c.flange_member_end+(c.flange_rows-1)*c.flange_pitch
    ww=c.web_member_end+(c.web_rows-1)*c.web_pitch
    root=p.tw/2+c.root_radius
    g=dict(dh=dh,dn=dn,physical_hole_diameter_mm=dh,table14_max_hole_mm=table_hole,net_deduction_diameter_mm=dn,flange_gauge_mm=gf,flange_length_mm=c.gap+2*(wf+c.flange_cover_end),
           web_length_mm=c.gap+2*(ww+c.web_cover_end),flange_x_mm=[c.gap/2+c.flange_member_end+j*c.flange_pitch for j in range(c.flange_rows)],
           web_x_mm=[c.gap/2+c.web_member_end+j*c.web_pitch for j in range(c.web_rows)],
           web_y_mm=[(j-(c.web_levels-1)/2)*c.web_gauge for j in range(c.web_levels)],
           flange_outer_edge_mm=(c.flange_outer_width-gf)/2,
           root_envelope_half_width_mm=root,checks=[],errors=[],detailing_checks=[])
    if inner:
        g.update(inner_strip_edge_mm=c.flange_inner_width/2,
                 inner_to_web_cover_clearance_mm=(c.inner_clear_band-p.tw-2*c.web_t)/2,
                 web_to_inner_cover_clearance_mm=(p.d-2*p.tf-2*c.flange_t-c.web_height)/2)
    else:g['web_to_member_flange_clearance_mm']=(p.d-2*p.tf-c.web_height)/2
    out['geometry']=g
    def scalar(key,value,limit,relation,category,text,ref=None):
        if ref is None:ref='Geometria física M004' if inner else 'Geometria convencional sem talas internas'
        passed=value>limit if relation=='>' else value>=limit*(1-TOL) if relation=='>=' else value<=limit*(1+TOL)
        row=dict(id=key,actual=value,limit=limit,relation=relation,category=category,passed=passed,units='mm',reference=ref)
        g['checks'].append(row)
        if category=='detail':g['detailing_checks'].append(row)
        if not passed:
            if category=='geometry':g['errors'].append(key)
            _issue(out,{'geometry':'invalid_geometry','detail':'detail_fail','preset':'preset_deviation','access':'access_pending'}[category],f'{text}: {value:g} mm; requerido {relation} {limit:g} mm.',ref,field=key)
    scalar('member_clear_height',p.d-2*p.tf,0.,'>','geometry','Altura de alma entre mesas')
    scalar('root_clear_height',p.clear,p.d-2*p.tf,'<=','geometry','Altura livre de concordâncias')
    scalar('root_radius_vertical',p.d-2*p.tf-2*c.root_radius,0.,'>','geometry','Altura livre do envelope de raiz')
    scalar('outer_width_fit',c.flange_outer_width,p.bf,'<=','geometry','Tala externa cabe na mesa')
    if inner:
        scalar('inner_assembly_fit',c.inner_clear_band+2*c.flange_inner_width,p.bf,'<=','geometry','Duas tiras internas e faixa central cabem na mesa')
        scalar('inner_web_clear',g['inner_to_web_cover_clearance_mm'],0.,'>','geometry','Separação tira interna/tala da alma')
        scalar('web_flange_clear',g['web_to_inner_cover_clearance_mm'],0.,'>','geometry','Separação tala da alma/tira interna')
        scalar('inner_root_fit',c.inner_clear_band/2-root,0.,'>=','geometry','Tira interna fora da raiz do perfil')
        scalar('inner_root_fabrication',c.inner_clear_band/2-root,c.fabrication_clearance,'>=','access','Folga de fabricação junto à raiz')
    else:scalar('web_flange_clear',g['web_to_member_flange_clearance_mm'],0.,'>','geometry','Separação tala da alma/mesa do membro','Geometria convencional sem talas internas')
    scalar('web_root_fit',(min(p.clear,p.d-2*p.tf-2*c.root_radius)-c.web_height)/2,0.,'>=','geometry','Tala da alma fora das concordâncias')
    scalar('web_root_fabrication',(min(p.clear,p.d-2*p.tf-2*c.root_radius)-c.web_height)/2,c.fabrication_clearance,'>=','access','Folga de fabricação da tala da alma')
    scalar('flange_tool_root',gf/2-root,c.tool_radius+c.fabrication_clearance,'>=','access','Acesso de ferramenta na mesa junto à raiz')
    scalar('flange_tool_web',gf/2-(p.tw/2+c.web_t),c.tool_radius+c.fabrication_clearance,'>=','access','Acesso de ferramenta na mesa junto à tala da alma')
    scalar('web_tool_flange',(p.d-2*p.tf)/2-(c.flange_t if inner else 0.)-(c.web_levels-1)*c.web_gauge/2,c.tool_radius+c.fabrication_clearance,'>=','access','Acesso de ferramenta no parafuso extremo da alma')
    scalar('web_tool_root',min(p.clear,p.d-2*p.tf-2*c.root_radius)/2-(c.web_levels-1)*c.web_gauge/2,c.tool_radius+c.fabrication_clearance,'>=','access','Acesso da alma fora do envelope de raiz')
    for key,text in ([('inner_to_web_cover_clearance_mm','Folga tira interna/tala de alma do padrão M004'),('web_to_inner_cover_clearance_mm','Folga tala de alma/tira interna do padrão M004')] if inner else []):
        scalar(key+'_preset',g[key],10.,'>=','preset',text,'M004 p.72: preset de oficina, não mínimo universal NBR')
    edges={16.:22.,20.:26.,24.:30.,30.:38.}; emin=edges.get(c.db,0.)
    pmin=max(2.7*c.db,dh+c.db)
    for family,t,n,pitch,gauge,endm,endc,width in (
        ('flange',min(p.tf,c.flange_t),c.flange_rows,c.flange_pitch,gf,c.flange_member_end,c.flange_cover_end,c.flange_outer_width),
        ('web',min(p.tw,c.web_t),c.web_rows,c.web_pitch,c.web_gauge,c.web_member_end,c.web_cover_end,c.web_height)):
        pmax=min(14*t,180.) if c.exposure=='weathering' else min(24*t,300.)
        for name,value in [('pitch',pitch),('gauge',gauge),('across_gap',2*endm+c.gap)]:
            scalar(f'{family}_{name}_hole_ligament',value-dh,0.,'>','geometry',f'{family} {name}: ligamento entre furos')
            scalar(f'{family}_{name}_spacing',value,pmin,'>=','detail',f'{family} {name}: espaçamento mínimo',NBR+', 6.3.9')
            if name!='across_gap':scalar(f'{family}_{name}_spacing_max',value,pmax,'<=','detail',f'{family} {name}: espaçamento máximo',NBR+', 6.3.10')
            if value<3*c.db:_issue(out,'warning',f'{family} {name}={value:g} mm inferior à preferência 3db={3*c.db:g} mm.',NBR+', 6.3.9')
        side_edges=[('outer',g['flange_outer_edge_mm'],c.flange_t),*([('inner',c.flange_inner_width/2,c.flange_t)] if inner else []),('member',(p.bf-gf)/2,p.tf)] if family=='flange' else [('cover',(c.web_height-(c.web_levels-1)*c.web_gauge)/2,c.web_t)]
        for name,value,thickness in [('member_end',endm,p.tf if family=='flange' else p.tw),('cover_end',endc,c.flange_t if family=='flange' else c.web_t),*side_edges]:
            scalar(f'{family}_{name}_physical',value-dh/2,0.,'>','geometry',f'{family} {name}: furo dentro da peça')
            scalar(f'{family}_{name}_net',value-dn/2,0.,'>','geometry',f'{family} {name}: ligamento líquido positivo')
            if inner and c.db in (16.,20.,24.,30.):
                scalar(f'{family}_{name}_drawing_edge',value,{16.:35.,20.:40.,24.:50.,30.:60.}[c.db],'>=','preset',f'{family} {name}: borda do preset M004','M004 p.72; variação dimensionada admissível após detalhamento')
            scalar(f'{family}_{name}_emin',value,emin,'>=','detail',f'{family} {name}: borda mínima tabelada',NBR+', tabela 16; exceções não automatizadas')
            scalar(f'{family}_{name}_emax',value,min(12*thickness,150.),'<=','detail',f'{family} {name}: borda máxima',NBR+', 6.3.12')
        for k in range(1,n+1):
            for typ,end in [('member',endm),('cover',endc)]:
                scalar(f'{family}_{typ}_net_prefix{k}',end+(k-1)*pitch-(k-.5)*dn,0.,'>','geometry',f'{family} {typ}: prefixo líquido k={k}')
        scalar(f'{family}_transverse_net',gauge-dn,0.,'>','geometry',f'{family}: ligamento transversal líquido')
        grip=(p.tf+(2 if inner else 1)*c.flange_t) if family=='flange' else (p.tw+2*c.web_t)
        g[family+'_grip_mm']=grip
        if grip>5*c.db:_issue(out,'unsupported_scope',f'{family}: pega {grip:g} mm >5db; redução de pega longa não implementada.',NBR+', 6.3.7')
        extreme=2*(endm+(n-1)*pitch)+c.gap
        g[family+'_extreme_bolt_span_mm']=extreme
        if extreme>950.:_issue(out,'unsupported_scope',f'{family}: vão conservador entre parafusos extremos {extreme:g} mm >950; ligação longa fora do domínio.',NBR+', 6.3.8')
    if inner and c.gap!=10.:_issue(out,'preset_deviation',f'Folga {c.gap:g} mm difere do preset M004 de 10 mm; mostrar dimensão específica no detalhe.','M004 p.72')
    if c.tool_radius<c.db/2:_issue(out,'access_pending','Raio de ferramenta informado menor que o raio do próprio parafuso. Conferir ferramenta, porca e arruela reais.','Acesso de montagem')
    if not inner:g['topology_basis']='Conventional outer-only covers; Fakury §10.14.7 pp.311–318; no M004 inner-strip preset'
    g['valid']=not g['errors']
    return g


def component_checks(c,out,*,identifier,width,thickness,end,pitch,nrows,columns,steel,fraction,N,cover,free_sides,member_flange=False,Ag_override=None):
    g=out['geometry']; dn=g['dn']; dh=g['dh']; m=len(columns)
    Ag=width*thickness if Ag_override is None else Ag_override
    An=Ag-m*dn*thickness; Ae=min(An,.85*Ag) if cover else An
    if min(Ag,An,Ae)<=0:raise ArithmeticError(identifier+': área líquida não positiva.')
    rows=[_check(identifier+'_gross','Escoamento bruto',identifier,N,steel.fy*Ag/GAMMA_A1,fraction,'fy Ag/γa1',NBR+', 5.2.2',Ag_mm2=Ag),
          _check(identifier+'_net','Ruptura líquida',identifier,N,steel.fu*Ae/GAMMA_A2,fraction,'fu min(An;0,85Ag)/γa2' if cover else 'fu An/γa2; Ct=1',NBR+', 5.2.3–5.2.5 corrigido; 6.5.3',Ag_mm2=Ag,An_mm2=An,Ae_mm2=Ae,Ct=1.)]
    capacities={}
    for kind,lc,count in [('end',end-dh/2,m),('internal',pitch-dh,m*(nrows-1))]:
        if count==0:continue
        capacity=min(1.2*lc*thickness*steel.fu,2.4*c.db*thickness*steel.fu)/GAMMA_A2
        capacities[kind]=capacity
        rows.append(_check(identifier+'_bearing_'+kind,'Contato/rasgamento por furo · '+kind,identifier,N,capacity,fraction/(nrows*m),
            'min(1,2 lc t fu;2,4 db t fu)/γa2',NBR+', 6.3.3.3(a)',clear_distance_mm=lc,multiplicity=count,
            basis='Partilha igual por parafuso, critério adicional conservador além da soma normativa.'))
    rows.append(_check(identifier+'_bearing_group','Contato/rasgamento do grupo',identifier,N,m*(capacities['end']+(nrows-1)*capacities.get('internal',0.)),fraction,
        'm [Rb,end+(n−1)Rb,internal]',NBR+', 6.3.3.3(a)'))
    blocks=block_paths(identifier=identifier,width=width,thickness=thickness,end=end,pitch=pitch,nrows=nrows,columns=columns,
                       dn=dn,fy=steel.fy,fu=steel.fu,fraction=fraction,N=N,free_sides=free_sides)
    if member_flange:
        # The attached web is not a free edge or a severed central U block.
        blocks=[x for x in blocks if x['path_family']=='L' and x['m']==1]
    rows.extend(blocks)
    out['checks'].extend(rows)
    return dict(id=identifier,width_mm=width,thickness_mm=thickness,Ag_mm2=Ag,An_mm2=An,Ae_mm2=Ae,force_N=N*fraction,
                total_force_fraction=fraction,columns_mm=columns,rows_per_side=nrows,bolts_per_side=m*nrows,
                material=asdict(steel),cover=cover,check_ids=[x['id'] for x in rows],
                physical_count=1,block_path_count=len(blocks))


def _evaluate(c):
    out={'status':'INVALID_INPUT','issues':[],'checks':[],'geometry':{},'components':{},'physical_covers':[],
         'capacity_calculation_permitted':False,'scope':{'supported':False,'statement':SCOPE,'exclusions':EXCLUSIONS.copy()},
         'inputs':_safe(asdict(c)) if isinstance(c,WSplice) else _safe(c),
         'units':{'force':'N','length':'mm','area':'mm²','stress':'MPa','moment':'N mm'}}
    errors=input_errors(c)
    if errors:
        for text in errors:_issue(out,'invalid_input',text)
        return out
    p=c.profile
    unsupported=[(p.family!='W','Somente perfil W laminado neste domínio; não assumir comportamento da raiz de outras famílias.'),
        (c.N<0,'Compressão não é convertida em tração; estabilidade fora deste domínio.'),
        (any(v!=0 for v in (c.M,c.V,c.torsion)),'M, V ou T não nulo: fora desta família axial. A família convencional N/M/V é separada e não é aprovada por este cálculo.'),
        (not c.concentric,'Emenda excêntrica fora do domínio.'),(not c.static,'Fadiga, impacto ou inversão fora do domínio.'),
        (not c.normal_combination,'Somente combinações últimas normais são implementadas.'),
        (c.no_slip_required,'Solicitada ligação sem deslizamento; verificação por contato não satisfaz essa exigência.'),
        (not math.isclose(c.flange_outer_width,2*c.flange_inner_width,rel_tol=TOL,abs_tol=1e-8),'Talas de mesa desbalanceadas: bo deve ser exatamente 2bi; não se aplica divisão F/2 indiscriminadamente.'),
        (not 2<=c.flange_rows<=6,'Limite inicial: 2 a 6 linhas longitudinais nas mesas.'),
        (c.web_rows!=2 or c.web_levels!=3,'Malha de alma inicial: 2 linhas longitudinais × 3 níveis transversais por lado.'),
        (c.exposure not in ('painted','weathering'),'Exposição sem critério máximo de espaçamento implementado.'),
        (c.db not in (16.,20.,24.,30.),'Diâmetro fora do conjunto métrico M16/M20/M24/M30 implementado.'),
        (c.bolt not in ('ASTM F3125 A325','ASTM F3125 A490'),'Parafuso fora das classes de alta resistência implementadas.')]
    hole_max={16.:18.,20.:22.,24.:27.,30.:33.}.get(c.db)
    if hole_max is not None:
        if not c.db<c.hole_diameter<=hole_max:unsupported.append((True,f'Furo Ø{c.hole_diameter:g} fora do furo circular padrão admissível Ødb<dh≤{hole_max:g}.'))
        if c.db==24. and c.hole_diameter==26.:_issue(out,'info','M24: furo adotado de 26 mm do desenho M004, abaixo do máximo 27 mm da Tabela 14; dedução líquida usa 27 mm da Tabela 14, acrescidos de 2 mm quando aplicável.',NBR+', tabela14; notas padrão')
    for bad,text in unsupported:
        if bad:_issue(out,'unsupported_scope',text,'Domínio M004 balanceado em tração axial')
    material_ok=True
    for component,name,ts,plate in [('member',c.member_steel,[p.tf,p.tw],False),('flange',c.flange_steel,[c.flange_t],True),('web',c.web_steel,[c.web_t],True)]:
        steel=STEELS.get(name)
        if steel is None:
            material_ok=False;_issue(out,'unsupported_scope',f'{component}: aço não cadastrado; nenhuma resistência substituta.')
        elif not (steel.plate_allowed if plate else steel.rolled_allowed) or any(not ((steel.plate_min if plate else steel.profile_min)<=t<=(steel.plate_max if plate else steel.profile_max)) for t in ts):
            material_ok=False;_issue(out,'unsupported_scope',f'{component}: material/produto/espessura fora da faixa cadastrada.',steel.source)
    aw=p.tw*(p.d-2*p.tf); rect_area=aw+2*p.bf*p.tf
    if p.area<rect_area*(1-.005):_issue(out,'invalid_geometry','Área de catálogo menor que área retangular das mesas+alma além da tolerância de arredondamento de0,5%. Verifique dimensões/unidades.')
    if not 0<aw<p.area:_issue(out,'invalid_geometry','Partilha de área exige 0 < Aw < A do perfil.')
    g=geometry(c,out)
    if any(i['severity']=='invalid_geometry' for i in out['issues']):out['status']='INVALID_GEOMETRY';return out
    if any(i['severity']=='unsupported_scope' for i in out['issues']) or not material_ok:out['status']='OUTSIDE_BALANCED_M004_SCOPE';return out
    if c.N==0:
        _issue(out,'not_evaluated','N=0: não há tração solicitante. O piso de 45 kN não transforma caso descarregado em aprovação.');out['status']='NOT_EVALUATED';return out
    steel=STEELS[c.member_steel]; fsteel=STEELS[c.flange_steel]; wsteel=STEELS[c.web_steel]
    if c.minimum_action_policy=='tension_strength':
        member_target=.5*p.area*steel.fy/GAMMA_A1
        minimum_note='Recomendação 6.1.5.3 adotada: resistência à tração governa; alvo conservador de 50% Ag fy/γa1 sem redução por furos.'
    elif c.minimum_action_policy=='slenderness':
        member_target=c.compression_resistance if c.compression_resistance>0 else None
        if member_target is None:
            _issue(out,'engineering_pending','Esbeltez governa: Nc,Rd externo verificado ausente. Calculadas somente a ação real e o piso obrigatório de 45 kN; a recomendação selecionada permanece pendente.',NBR+', 6.1.5.3',field='compression_resistance')
        if not c.compression_reference.strip():
            _issue(out,'engineering_pending','Informar fonte/referência da resistência externa Nc,Rd do membro.',NBR+', 6.1.5.3',field='compression_reference')
        minimum_note=('Recomendação 6.1.5.3 selecionada: esbeltez governa; 100% Nc,Rd externo. '
                      +('Nc,Rd ausente: Nd conhecido=max(N real;45 kN); não é o envelope suplementar completo.' if member_target is None else 'Valor fornecido pelo responsável técnico; sua fonte deve estar registrada.'))
    else:
        member_target=0.
        minimum_note='Responsável técnico optou por não adotar a recomendação 6.1.5.3. Piso obrigatório de 45 kN mantido.'
        if not c.notes.strip():
            _issue(out,'engineering_pending','Registrar nas observações a decisão do responsável técnico de dispensar a recomendação 6.1.5.3.',NBR+', 6.1.5.3')
        else:_issue(out,'warning',minimum_note,NBR+', 6.1.5.3')
    known_N=max(c.N,45000.)
    N=max(known_N,member_target) if member_target is not None else known_N
    supplementary_complete=not ((c.minimum_action_policy=='slenderness' and (member_target is None or not c.compression_reference.strip()))
                               or (c.minimum_action_policy=='engineer_waived' and not c.notes.strip()))
    governing_source=('selected_member_recommendation' if member_target is not None and member_target>known_N else 'mandatory_45kN_floor' if 45000.>c.N else 'actual_N')
    alpha=aw/p.area; ff=(1-alpha)/2; fw=alpha
    out['load_model']=dict(Nsd_N=c.N,Nd_N=N,assembly_minimum_N=45000.,member_recommendation_N=member_target,minimum_action_policy=c.minimum_action_policy,
        minimum_note=minimum_note,known_action_with_floor_N=known_N,adopted_action_source=governing_source,
        supplementary_complete=supplementary_complete,adopted_action_complete=supplementary_complete,
        recommendation_missing_fields=([name for name,missing in [('compression_resistance',member_target is None),('compression_reference',not c.compression_reference.strip())] if missing] if c.minimum_action_policy=='slenderness' else ['notes'] if c.minimum_action_policy=='engineer_waived' and not c.notes.strip() else []),
        monotone_envelope='N-only: D_i=f_i*N, f_i>0; R_i independente de N; Nd conhecido>=N real. Nenhuma capacidade é multiplicada por simetria.',
        Aw_mm2=aw,Af_allocated_mm2=(p.area-aw)/2,Af_local_rectangular_mm2=p.bf*p.tf,alpha_web=alpha,
        web_force_N=N*fw,each_flange_force_N=N*ff,each_outer_force_N=N*ff/2,each_inner_force_N=N*ff/4,each_web_cover_force_N=N*fw/2,
        equilibrium_residual_N=N-(2*N*ff+N*fw),allocation='Raízes incluídas na força alocada às mesas; sem crédito nas capacidades retangulares locais.',
        sides='Dois lados em série, nunca somados',actual_actions={'N':c.N,'M':c.M,'V':c.V,'torsion':c.torsion})
    out['scope']['supported']=True
    out['scope']['integrity_actions_included_in_N']=c.integrity_included
    if not c.integrity_included:_issue(out,'engineering_pending','N informado ainda não inclui as ações de integridade aplicáveis. O módulo não determina as ações globais da estrutura.',NBR+', 4.13; 6.1.5')
    else:_issue(out,'info','Premissa de entrada: Nsd inclui as ações de integridade aplicáveis ao sistema. A verificação global de integridade não é realizada pelo módulo.',NBR+', 4.13; 6.1.5')
    if member_target is not None and member_target>c.N:_issue(out,'info',f'Conferência adicional da recomendação de resistência do membro: Nd={N/1000:.3f}kN; N informado={c.N/1000:.3f}kN. '+minimum_note,NBR+', 6.1.5.3')
    if c.N<45000.:_issue(out,'info','Piso de 45 kN aplicado uma única vez ao conjunto antes da partilha entre mesas e alma.',NBR+', 6.1.5.2')
    gf=g['flange_gauge_mm']; fcols=[-gf/2,gf/2]; wcols=g['web_y_mm']
    def add(identifier,**kwargs):
        data=component_checks(c,out,identifier=identifier,N=N,**kwargs);out['components'][identifier]=data;return data
    common_f=dict(end=c.flange_member_end,pitch=c.flange_pitch,nrows=c.flange_rows,columns=fcols,steel=steel,fraction=ff,cover=False,free_sides=True,member_flange=True)
    add('member_flange_top',width=p.bf,thickness=p.tf,**common_f)
    add('member_flange_bottom',width=p.bf,thickness=p.tf,**common_f)
    add('member_web',width=p.d-2*p.tf,thickness=p.tw,end=c.web_member_end,pitch=c.web_pitch,nrows=c.web_rows,columns=wcols,steel=steel,fraction=fw,cover=False,free_sides=False)
    for pos in ('top','bottom'):
        data=add('outer_'+pos,width=c.flange_outer_width,thickness=c.flange_t,end=c.flange_cover_end,pitch=c.flange_pitch,nrows=c.flange_rows,columns=fcols,steel=fsteel,fraction=ff/2,cover=True,free_sides=True)
        data.update(role='outer_flange',position=pos,length_mm=g['flange_length_mm']);out['physical_covers'].append(data['id'])
        for side in ('negative','positive'):
            data=add('inner_'+pos+'_'+side,width=c.flange_inner_width,thickness=c.flange_t,end=c.flange_cover_end,pitch=c.flange_pitch,nrows=c.flange_rows,columns=[0.],steel=fsteel,fraction=ff/4,cover=True,free_sides=True)
            data.update(role='inner_flange_strip',position=pos,side=side,length_mm=g['flange_length_mm']);out['physical_covers'].append(data['id'])
    for side in ('negative','positive'):
        data=add('web_cover_'+side,width=c.web_height,thickness=c.web_t,end=c.web_cover_end,pitch=c.web_pitch,nrows=c.web_rows,columns=wcols,steel=wsteel,fraction=fw/2,cover=True,free_sides=True)
        data.update(role='web_cover',side=side,length_mm=g['web_length_mm']);out['physical_covers'].append(data['id'])
    dn=g['dn']; an=p.area-4*dn*p.tf-c.web_levels*dn*p.tw
    if an<=0:_issue(out,'invalid_geometry','Área líquida conservadora do W não positiva.');out['checks']=[];out['status']='INVALID_GEOMETRY';return out
    out['whole_member']=dict(Ag_mm2=p.area,An_envelope_mm2=an,Ae_mm2=an,Ct=1.,flange_holes=4,web_holes=c.web_levels,
        basis='Envelope conservador sem escalonamento: desconta todos os furos de mesas+alma na mesma seção, mesmo se estações diferirem. Todas partes transferem força diretamente.')
    out['checks'].extend([
        _check('whole_member_gross','W completo · escoamento bruto','whole_member',N,p.area*steel.fy/GAMMA_A1,1.,'Ag fy/γa1',NBR+', 5.2.2'),
        _check('whole_member_net','W completo · ruptura líquida conservadora','whole_member',N,an*steel.fu/GAMMA_A2,1.,'[A−4dn tf−3dn tw]fu/γa2; Ct=1',NBR+', 5.2.3–5.2.5(a) corrigido',An_mm2=an,Ct=1.)])
    ab=math.pi*c.db**2/4; coeff=.56 if c.threads_excluded_verified else .45; rplane=coeff*ab*BOLTS[c.bolt]/GAMMA_A2
    out['bolts']=dict(diameter_mm=c.db,Ab_mm2=ab,fub_MPa=BOLTS[c.bolt],coefficient=coeff,resistance_per_plane_N=rplane,shear_planes=2,
        flange_bolts_per_group=2*c.flange_rows,web_bolts_per_group=c.web_rows*c.web_levels,total_bolts=8*c.flange_rows+2*c.web_rows*c.web_levels,physical_groups=[])
    for family,fraction,n in [('flange_top',ff,2*c.flange_rows),('flange_bottom',ff,2*c.flange_rows),('web',fw,c.web_rows*c.web_levels)]:
        for side in ('left','right'):
            bid=family+'_'+side
            out['bolts']['physical_groups'].append(dict(id=bid,bolt_count=n,group_force_N=N*fraction,each_bolt_force_N=N*fraction/n,each_plane_force_N=N*fraction/(2*n)))
            out['checks'].append(_check('bolt_'+bid,'Corte duplo · '+bid,'bolt_'+bid,N,2*n*rplane,fraction,'2 n α Ab fub/γa2; lados em série',NBR+', 6.3.3.2',bolt_count=n,each_plane_capacity_N=rplane,each_plane_demand_N=N*fraction/(2*n)))
    # Physical transfer regions specify both serial sides for every piece.
    out['physical_regions']={}
    for identifier,data in out['components'].items():
        for side,sign in [('left',-1),('right',1)]:
            rid=identifier+'_'+side;cover=data['cover'];family='web' if identifier.startswith('web_') or identifier=='member_web' else 'flange'
            x=g[family+'_x_mm'];loaded_x=sign if cover else -sign
            out['physical_regions'][rid]=dict(id=rid,component=identifier,side=side,force_N=data['force_N'],prefix_from='outboard' if cover else 'butt',
                loaded_direction_x=loaded_x,bolt_x_mm=[sign*v for v in x],columns_mm=data['columns_mm'],check_ids=data['check_ids'])
    for gate in MODEL_GATES:_issue(out,'engineering_pending',gate,'Revisão técnica da implementação')
    if p.source.startswith('material didático'):_issue(out,'warning','Dimensões do catálogo didático: conferir catálogo de fornecimento, raiz e ferramenta efetivamente utilizados.',p.source)
    _issue(out,'info','Contagem física: 8 talas e '+str(out['bolts']['total_bolts'])+' parafusos. As verificações locais desprezam ajuda mesa–alma; as duas metades não somam capacidade.')
    for row in out['checks']:
        row['actual_demand_N']=c.N*row['demand_fraction_of_total_N']
        row['actual_utilization']=row['actual_demand_N']/row['design_capacity_N']
        row['actual_status']='PASS' if row['actual_utilization']<=1+TOL else 'FAIL'
    governing=min(out['checks'],key=lambda x:x['equivalent_total_N_capacity_N'])
    failures=[r['id'] for r in out['checks'] if r['status']=='FAIL']
    severities={i['severity'] for i in out['issues']}
    strength='FAIL' if failures else 'PASS'
    out['capacity_calculation_permitted']=True
    out['summary']=dict(governing_check_id=governing['id'],governing_label=governing['label'],governing_component=governing['component'],
        governing_utilization=governing['utilization'],actual_governing_utilization=governing['actual_utilization'],actual_strength_status='FAIL' if any(row['actual_status']=='FAIL' for row in out['checks']) else 'PASS',equivalent_total_N_capacity_N=governing['equivalent_total_N_capacity_N'],
        check_count=len(out['checks']),failed_check_ids=failures,strength_status=strength,
        supplementary_complete=supplementary_complete,adopted_action_complete=supplementary_complete,
        actual_failed_check_ids=[row['id'] for row in out['checks'] if row['actual_status']=='FAIL'],
        complete_checks=not any(s in severities for s in ('engineering_pending','access_pending')),
        component_count=len(out['components']),physical_cover_count=len(out['physical_covers']))
    out['status']=('VERIFIED_SUBCHECK_FAIL' if failures else 'DETAIL_FAIL' if 'detail_fail' in severities else
        'ENGINEERING_MODEL_PENDING' if 'engineering_pending' in severities or 'access_pending' in severities else
        'COMPLETE_CHECKS_PASS_WITH_PRESET_DEVIATION' if 'preset_deviation' in severities else 'COMPLETE_CHECKS_PASS_WITHIN_SCOPE')
    out['check_groups']=consolidate_checks(out)
    out['summary']['group_count']=len(out['check_groups'])
    return out


def consolidate_checks(result):
    """Presentation envelopes only; every primitive row/path remains unchanged.

    Identical copies and serial sides do not add capacity. The governing
    complete row supplies demand, capacity, fraction, source and path together.
    No equivalence between different mechanisms is asserted by an envelope.
    """
    grouped={}
    for row in result.get('checks',[]):
        component=row['component']
        if component.startswith('member_flange_'): family='member_flanges'
        elif component.startswith('outer_'): family='outer_covers'
        elif component.startswith('inner_'): family='inner_strips'
        elif component.startswith('web_cover_'): family='web_covers'
        elif component.startswith('bolt_flange_'): family='flange_bolt_planes'
        elif component.startswith('bolt_web_'): family='web_bolt_planes'
        else: family=component
        mechanism=('bolt_shear' if component.startswith('bolt_') else 'block' if 'path_family' in row
                   else 'bearing' if '_bearing_' in row['id'] else 'section')
        grouped.setdefault((family,mechanism),[]).append(row)
    envelopes=[]
    for (family,mechanism),rows in grouped.items():
        components=list(dict.fromkeys(row['component'] for row in rows))
        governing=max(rows,key=lambda row:row['utilization'])
        envelopes.append(dict(group_id=family+'_'+mechanism,component_class=family,mechanism=mechanism,
            physical_component_ids=components,physical_component_count=len(components),
            physical_region_ids=[key for key,value in result.get('physical_regions',{}).items() if value['component'] in components],
            primitive_ids=[row['id'] for row in rows],primitive_count=len(rows),
            governing=deepcopy(governing),serial_sides_do_not_add=True,
            basis='Envelope do maior índice; linha governante integral, sem soma de capacidades. Todos os caminhos primitivos permanecem no detalhe.'))
    return envelopes


def input_digest(c):
    """Diagnostic fingerprint, never an authorization to trust supplied results."""
    data=_safe(asdict(c)) if isinstance(c,WSplice) else _safe(c)
    return hashlib.sha256(json.dumps(data,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def evaluate(c):
    try:
        out=_evaluate(c)
        def finite(x):
            if isinstance(x,float):return math.isfinite(x)
            if isinstance(x,dict):return all(finite(v) for v in x.values())
            if isinstance(x,(list,tuple)):return all(finite(v) for v in x)
            return True
        if not finite(out):raise ArithmeticError('Faixa numérica finita excedida.')
        out['input_digest']=input_digest(c)
        out['evaluation_basis']='fresh_canonical_input'
        return out
    except (ArithmeticError,OverflowError) as exc:
        return {'status':'NUMERICAL_FAILURE','issues':[dict(severity='numerical_failure',text=str(exc),reference='Faixa numérica; não é uma falha resistente finita')],
                'input_digest':input_digest(c),'evaluation_basis':'fresh_canonical_input',
                'checks':[],'geometry':{},'components':{},'physical_covers':[],'capacity_calculation_permitted':False,
                'scope':{'supported':False,'statement':SCOPE,'exclusions':EXCLUSIONS.copy()},'inputs':_safe(asdict(c)) if isinstance(c,WSplice) else _safe(c)}
