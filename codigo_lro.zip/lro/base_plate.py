"""Base exposta Tipo 1 — ABNT NBR 8800:2024, corrigida em 2025.

Modelo local, estático, de quatro chumbadores externos, sem enrijecedores.
Unidades canônicas: N, mm, MPa; N positivo comprime a base. As ações já
são de cálculo. Não calcula a ancoragem no concreto ou o bloco armado.
"""
from dataclasses import dataclass, asdict, fields, field, replace
import math
import hashlib
import json
from .models import Profile, Check, Issue, Result, STEELS, VERSION, profiles, finite_real
from .base_plate_details import validate_details, detailing_issues, grout_geometry
from .column_base_weld import ColumnBaseWeld,validate_column_weld,column_weld_assumptions,add_column_weld_checks
from .concrete_components import ConcreteComponents,validate_components,components_assumptions,add_component_checks
from .upper_washer import (UpperWasher, validate_upper_washer, upper_washer_assumptions, add_upper_washer_checks)
from .single_key_weld import (SingleKeyWeld, validate_single_key_weld, single_key_weld_assumptions, add_single_key_weld_checks)
from .single_key_concrete import (SingleKeyConcrete, validate_single_key_concrete, single_key_concrete_assumptions, add_single_key_concrete_checks)
from .single_key_plate import add_single_key_plate_checks
from .active_shear_key import (ActiveShearKey, PATHS as ACTIVE_KEY_PATHS, validate_active_key,
                               active_key_assumptions, active_key_actions, add_active_key_checks)

G1 = 1.10
G2 = 1.35
GC = 1.40
MU = .45
NBR = 'ABNT NBR 8800:2024, versão corrigida 2025'
EXTERNAL_SHAPES = {'other':'Outro dispositivo documentado', 'cruciform':'Chave cruciforme de chapas',
                   'w_major':'Trecho de perfil W · alma paralela a V', 'w_minor':'Trecho de perfil W · alma perpendicular a V'}
STOCK = {'1/4"':6.35,'5/16"':7.9375,'3/8"':9.525,'1/2"':12.7,
         '5/8"':15.875,'3/4"':19.05,'7/8"':22.225,'1"':25.4,
         '1 1/4"':31.75,'1 1/2"':38.1,'1 3/4"':44.45,'2"':50.8}
ANCHORS = {'3/4"':19.05,'7/8"':22.225,'1"':25.4,'1 1/4"':31.75,
           '1 1/2"':38.1,'1 3/4"':44.45,'2"':50.8}

# Tabela 18 SUBSTITUÍDA pela errata 2025. Não usar os mínimos da edição
# original de 2024: Nb,min, S e as expressões do bloco foram corrigidos.
_DETAIL_ROWS = [
    (40,80,120,450,150,175,50,33,6.3,50,40,20,900,125,10),
    (45,90,140,465,200,225,50,40,6.3,65,50,20,900,100,10),
    (50,100,160,465,200,225,50,45,8,75,60,25,900,125,12.5),
    (65,130,190,525,225,250,60,50,9.5,75,60,25,1100,100,12.5),
    (80,160,230,610,250,275,70,60,9.5,90,70,25,1300,150,16),
    (90,180,270,700,300,325,70,70,12.5,100,80,25,1600,125,16),
    (100,200,300,850,350,375,100,80,16,125,90,30,1800,100,16),
]
_DETAIL_KEYS = ('a1','a2','a3','h1','h2','r1','r2','df','washer_t',
                'washer_side','en','fck_min','Nb_min','S','rebar_diameter')
DETAIL = {label:dict(zip(_DETAIL_KEYS,row)) for label,row in zip(ANCHORS,_DETAIL_ROWS)}


def detail_reference(c):
    """Referência construtiva corrigida, não aprovação da ancoragem/bloco."""
    label=next(k for k,v in ANCHORS.items() if math.isclose(c.db,v,abs_tol=1e-8))
    ref=dict(DETAIL[label]);ref['label']=label
    ref['washer_hole']=c.db+1.5
    margin=ref['a3']-(ref['a1'] if c.model_type==2 else c.a1)
    ref['block_edge_margin']=margin
    ref['Nb']=max(ref['Nb_min'],c.L+2*ref['en'],c.L+2*margin)
    ref['Bb']=max(c.B+2*ref['en'],c.B+2*margin)
    ref['Ab']=max(ref['h1']+100,ref['Nb'])
    ref['da_max']=.5*(ref['h1']-.5*(ref['r2']+c.db))
    ref['matches_spacing']=math.isclose(c.a1,ref['a1']) and math.isclose(c.a2,ref['a2'])
    return ref

@dataclass(frozen=True)
class BasePlate:
    column: Profile
    project: str = 'Placa de base Tipo 1'
    plate_steel: str = 'ASTM A36'
    tp: float = 19.05
    db: float = 19.05
    a1: float = 40.
    a2: float = 180.
    fck: float = 30.
    grout_fck: float = 60.
    grout_t: float = 40.
    N: float = 150000.
    M: float = 0.
    V: float = 0.
    shear_path: str = 'friction'
    external_shear_rd: float = 0.
    external_shear_ref: str = ''
    notes: str = ''
    lug_bh: float = 100.
    lug_bv: float = 100.
    lug_t: float = 19.05
    lug_steel: str = 'ASTM A36'
    external_shape: str = 'other'
    anchor_shear_rd: float = 0.
    anchor_shear_ref: str = ''
    anchor_shear_confirmation: str = ''
    anchor_shear_model: str = 'external'
    anchor_washer_t: float = 6.35
    anchor_washer_side: float = 50.
    base_fixity: str = 'fixed'
    anchor_type: str = 'unspecified'
    cone_model: str = 'off'
    cone_subset_envelope: bool = False
    hef: float = 250.
    anchor_projection_above_plate: float = 0.  # 0: explicit automatic detailing proposal
    block_xmin: float = -600.
    block_xmax: float = 600.
    block_ymin: float = -500.
    block_ymax: float = 500.
    block_h: float = 700.
    anchor_head_width: float = 65.
    anchor_head_length: float = 65.
    anchor_head_t: float = 30.
    anchor_bearing_t: float = 10.
    anchor_nut_t: float = 12.
    anchor_bottom_cover: float = 50.
    anchor_head_hole: float = 22.
    anchor_nut_bearing_area: float = 300.
    anchor_detail_ref: str = ''
    anchor_detail_confirmed: bool = False
    weld_web_type: str = 'unspecified'
    weld_flange_type: str = 'unspecified'
    weld_web_measure: str = 'leg'
    weld_flange_measure: str = 'leg'
    weld_web_size: float = 6.
    weld_flange_size: float = 6.
    stiffener_detail: str = 'none'
    stiffener_length: float = 60.
    stiffener_height: float = 120.
    stiffener_t: float = 8.
    active_key: ActiveShearKey = field(default_factory=ActiveShearKey)
    upper_washer: UpperWasher = field(default_factory=UpperWasher)
    single_key_weld: SingleKeyWeld = field(default_factory=SingleKeyWeld)
    single_key_concrete: SingleKeyConcrete = field(default_factory=SingleKeyConcrete)
    concrete_components: ConcreteComponents = field(default_factory=ConcreteComponents)
    column_weld: ColumnBaseWeld = field(default_factory=ColumnBaseWeld)

    @property
    def model_type(self): return 1
    @property
    def catalog_label(self):
        return 'Base externa Tipo 1 · legado' if self.base_fixity=='pinned' else 'Placa de base · engastada'
    @property
    def migration_message(self):
        if self.base_fixity=='pinned':
            return ('Projeto legado: a antiga indicação “rotulada” era apenas metadado de uma base Tipo 1 com quatro chumbadores externos. '
                    'Geometria, ações N/M/V e resultados desse modelo externo foram preservados. Este projeto não foi convertido para a nova base rotulada Tipo 2. '
                    'Para projetar uma base rotulada real, abra essa família no catálogo e defina seu próprio detalhe e esforços; nenhum momento é apagado automaticamente.')
        return ''
    @property
    def washer_clearance(self):
        return min(self.a1-self.anchor_washer_side/2,(self.a2-self.anchor_washer_side)/2)
    @property
    def washer_clearance_expression(self): return 'g = min(a1−ba/2; (a2−ba)/2)'
    @property
    def anchor_edge_distance(self): return self.a1

    @property
    def native_anchor_shear(self):
        return self.shear_path=='anchors' and self.anchor_shear_model=='welded_washer'
    @property
    def anchor_washer_hole(self): return self.db+1.5
    @property
    def L(self): return self.column.d + 4*self.a1
    @property
    def B(self): return self.a2 + 2*self.a1
    @property
    def a(self): return self.L/2-self.a1
    @property
    def count(self): return 4
    @property
    def m(self): return (self.L-.95*self.column.d)/2
    @property
    def n(self): return (self.B-.80*self.column.bf)/2
    @property
    def n0(self): return math.sqrt(self.column.d*self.column.bf)/4
    @property
    def fy(self): return STEELS[self.plate_steel].fy
    @property
    def sigma_rd(self): return .85*self.fck/GC  # A2/A1=1, sem confinamento presumido
    @property
    def tau_rd(self): return min(.2*self.fck/GC, 4.)
    @property
    def anchor_steel_rd(self): return .75*math.pi*self.db**2/4*400/G2
    @property
    def lug_fy(self): return STEELS[self.lug_steel].fy
    @property
    def lug_fu(self): return STEELS[self.lug_steel].fu
    @property
    def shear_eccentricity(self):
        if self.shear_path in ACTIVE_KEY_PATHS:return self.tp+(self.active_key.H+self.grout_t)/2
        return self.tp+(self.lug_bv+self.grout_t)/2 if self.shear_path=='plate' else 0.
    @property
    def effective_moment(self):
        # Apenas a chave de chapa tem geometria interna: preservar rotas legadas.
        return self.M+self.V*self.shear_eccentricity if self.shear_path in ('plate',)+ACTIVE_KEY_PATHS else self.M
    def _anchor_shear_signature(self,legacy_dormant=False):
        # Vínculo técnico à combinação/material/detalhe, não ao título/notas.
        keys=('plate_steel','tp','db','a1','a2','fck','grout_fck','grout_t',
              'N','M','V','anchor_shear_rd','anchor_shear_ref','anchor_type','hef',
              'block_xmin','block_xmax','block_ymin','block_ymax','block_h',
              'anchor_head_width','anchor_head_length','anchor_head_t','anchor_bearing_t','anchor_nut_t','anchor_head_hole','anchor_bottom_cover',
              'anchor_nut_bearing_area','anchor_detail_ref','anchor_detail_confirmed','stiffener_detail',
              'stiffener_length','stiffener_height','stiffener_t')
        data={k:getattr(self,k) for k in keys}
        if data['stiffener_detail']=='web_pair_visual':data['stiffener_detail']='none'
        if data['stiffener_detail']=='none' and not legacy_dormant:
            data.update(stiffener_length=60.,stiffener_height=120.,stiffener_t=8.)
        data['base_model_type']=self.model_type
        data['column']={k:getattr(self.column,k) for k in ('d','bf','tw','tf','clear','area')}
        def stable(value):
            if isinstance(value,dict):return {k:stable(v) for k,v in value.items()}
            if isinstance(value,(float,int)) and not isinstance(value,bool):return format(value,'.12g')
            return value
        return hashlib.sha256(json.dumps(stable(data),sort_keys=True,ensure_ascii=False).encode()).hexdigest()
    @property
    def anchor_shear_signature(self):
        return self._anchor_shear_signature()

    @property
    def anchor_capacity_confirmed(self):
        return bool(self.anchor_shear_confirmation) and self.anchor_shear_confirmation==self.anchor_shear_signature
    @property
    def assumptions(self):
        return [
            'Placa retangular sem enrijecedores, perfil I/H centrado e quatro chumbadores externos simétricos. Geometria Tipo 1: L=d+4a1 e B=a2+2a1; ambas as distâncias entre mesa, linha de chumbadores e borda valem a1.',
            'Ações estáticas já majoradas na face superior da placa de base: N positivo é compressão e N negativo é tração; M atua em torno do eixo de maior inércia. O sinal de M apenas troca o lado tracionado. Cortante no plano de M; sem torção nem flexão biaxial.',
            'Aço dos chumbadores ASTM A36, fy=250 MPa e fu=400 MPa, barras redondas rosqueadas e porcas hexagonais pesadas. Calcula-se a ruptura à tração do aço; na rota nativa de arruelas soldadas, também o cortante com a tração individual simultânea. Arruelas especiais em aço fy=345 MPa.',
            'γa1=1,10, γa2=1,35 e γc=1,40; combinações usuais de cálculo. Não se aplicam fatores adicionais às ações informadas.',
            'Concreto de densidade normal, com resistência característica aos 28 dias e 20≤fck≤50 MPa. Não se verifica transferência antes de atingir essa resistência.',
            'Pressão de contato conforme NBR 6.6.5 com A2/A1=1. Não se considera aumento por confinamento do concreto. Argamassa expansiva de assentamento com resistência característica de pelo menos 2fck.',
            ('Soldas pilar–placa: o componente duas mesas N/M e alma V, os requisitos de execução e a qualificação documental aparecem em seção própria. A análise não demonstra rigidez rotacional nem aprova a base completa.' if self.column_weld.model=='two_flange_normal_web_shear' else
             'A placa e o pilar são ligados por soldas a dimensionar. A análise não demonstra a rigidez rotacional nem classifica a base como rótula ou engaste.'),
            'Cone de tração pode ser calculado no submodelo ACI 318-19/DG1 explicitamente selecionado, para o detalhe moldado no local e concreto fissurado íntegro. Arrancamento, ruptura lateral, cortante/interação no concreto, comportamento local da cabeça/porca/chapa e bloco armado continuam a verificar separadamente. ACI é base complementar distinta dos coeficientes NBR.',
            'Sem crédito aos chumbadores para transmitir cortante no modo atrito. Um dispositivo externo, quando selecionado, resiste sozinho ao cortante total; sua resistência documentada não é somada ao atrito.',
            'Não se atribui resistência nativa a bases enrijecidas, tubulares, embutidas, chumbadores químicos/pós-instalados ou ganchos J, fadiga, sismo, ações cíclicas, incêndio ou transferência antes da cura do graute. O par de enrijecedores, quando especificado, é apenas um detalhe; resultados da chapa sem enrijecedores são uma referência, sem comprovar a distribuição real.',
            'O graute desce da face inferior da placa com saia a 45°: projeção inferior (L+2en)×(B+2en). Essa área geométrica não substitui B×lc do contato nem L×B do limite de atrito.',
        ] + ([
            'Chave de cisalhamento: uma chapa retangular vertical maciça, centrada, de largura bh paralela a B, espessura tpv paralela a L e projeção bv abaixo da placa. V perpendicular à face da chave; sem furos, enrijecedores, torção ou ação biaxial.',
            'V positivo aponta no sentido +x do corte; M positivo é horário, com compressão no lado +x. Com a chave de chapa, eV=tp+(bv+en)/2 e Mef=M+V eV. M e V informados são as ações na face superior, sem incluir previamente essa parcela. A soma algébrica ocorre uma única vez, antes de tomar |Mef|. Transformação estática derivada; a geometria do graute é a efetivamente informada.',
            'Contato local da chave conforme 6.7.2.4: A2/A1=4 e σlug,Rd=1,7fck/γc. Isso não altera A2/A1=1 no contato horizontal da placa de base. A chave resiste ao cortante total, sem soma de atrito.',
            ('Soldas da chave: ações prescritas Vw=Vbearing,Rd e Mw=Vbearing,Rd(bv+en)/2, sem limitar pela solicitação V ou pela resistência do aço da chave. '+('Metal dos dois filetes e detalhamento numérico são discriminados no componente selecionado; metal-base e flexão local da placa permanecem separados.' if self.single_key_weld.model!='off' else 'Resistência/detalhamento das soldas, metal-base e flexão local da placa na ligação da chave permanecem a complementar.')),
            'O atendimento local de contato, flexão e cisalhamento da chave não aprova o dispositivo completo. Ruptura/arrancamento do concreto, efeitos de borda, bloco adequadamente armado conforme NBR 6118 e transferência à fundação requerem memória específica.'
        ] if self.shear_path=='plate' else []) + ([
            'Cortante pelos chumbadores: somente comparação com resistência de cálculo externa documentada do grupo instalado para a combinação atual. Este módulo não calcula resistência ao corte dos chumbadores, interação tração–cisalhamento, efeito de alavanca, esmagamento/flexão local, folgas ou transferência ao concreto. A memória externa deve verificar as barras efetivamente mobilizadas, furos/arruelas/soldas, tração–corte–flexão do aço, concreto (interação, borda, ruptura e pryout), caminho completo sob os esforços combinados e sua excentricidade; não se admite somar automaticamente quatro resistências isoladas; sem soma de atrito ou de chave.'
        ] if self.shear_path=='anchors' and not self.native_anchor_shear else []) + ([
            'Cortante nativo pelos quatro chumbadores: quatro arruelas especiais quadradas idênticas, soldadas à face superior da placa e com furos-padrão db+1,5 mm, montadas com todas as barras efetivamente mobilizadas. Espessura e lado são os informados; aço da arruela fy=345 MPa. A seleção desta rota adota esse detalhe, e não o simples contato em furos alargados da placa.',
            'NBR 6.7.2.5: VRd=ΣVRd,i. A fonte imprime índice i na raiz e índice 1 no termo subtrativo; adota-se explicitamente Ft,máx simultâneo no termo subtrativo de todas as barras como limite conservador. Cada resistência condicionada à tração Ft,Sd,i do equilíbrio N–M da mesma combinação. Não se presume V/4 nem se apresenta uma distribuição elástica de cortante. Roscas atravessam o plano de corte: Fv,Rd=0,45 Ab fub/γa2 conforme 6.3.3.2. Mantêm-se a verificação independente da ruptura à tração e o limite adicional Fv,Rd√[1−(Ft,Sd,i/Ft,Rd)²] da interação geral de 6.3.3.4, além da expressão especial com coeficiente 0,533.',
            'As ações N/M/V desta rota são referidas à face superior da placa, onde as arruelas transmitem o cortante. M informado é preservado: não se adiciona automaticamente V·tp ou V·graute. O parâmetro α inclui o braço local tp+ta/2 da NBR 6.7.2.5. Aplicação global excêntrica, torção ou outro detalhe exigem modelo específico/rota documentada.',
            'Cada solda de arruela deve ser dimensionada para Fv,Rd não reduzido da respectiva barra, e não para VRd,i ou V/4. O submodelo local de solda e furo só é calculado quando explicitamente selecionado e com dados completos; flexão acoplada e transferência local à placa continuam a complementar. O limite local 5db²σc,Rd não verifica cone de concreto, arrancamento, pryout, bordas, interação ou grupo, nem substitui o bloco armado.',
            'O cortante total é resistido por esta rota, sem soma de atrito ou chave. O atendimento das verificações calculadas não aprova a ancoragem nem a base completa.'
        ] if self.native_anchor_shear else []) + active_key_assumptions(self) + single_key_weld_assumptions(self) + single_key_concrete_assumptions(self) + upper_washer_assumptions(self) + components_assumptions(self) + column_weld_assumptions(self)

    def to_dict(self):
        data=asdict(self)
        data['active_key']=self.active_key.to_dict(self.shear_path)
        return {'schema_version':2,'app_version':VERSION,'connection_type':('base_plate_type1_legacy' if self.base_fixity=='pinned' else 'base_plate_fixed'),
                'connection':data,'fixed_assumptions':self.assumptions}

    @staticmethod
    def from_dict(data,validate_values=True):
        if not isinstance(data,dict):
            raise ValueError('Selecione um projeto de placa de base engastada ou Tipo 1 legado.')
        kind=data.get('connection_type');version=data.get('schema_version')
        if type(version) is not int or not ((kind=='base_plate' and version==1) or
                (kind in ('base_plate_fixed','base_plate_type1_legacy') and version==2)):
            raise ValueError('Selecione um projeto de placa de base engastada ou Tipo 1 legado. A base rotulada Tipo 2 tem modelo e arquivo próprios.')
        if not isinstance(data.get('connection'),dict):
            raise ValueError('O arquivo não contém os dados da placa de base.')
        d=dict(data['connection'])
        if kind=='base_plate':d.setdefault('base_fixity','unspecified')
        if kind=='base_plate_fixed' and d.get('base_fixity')=='pinned':
            raise ValueError('Arquivo incoerente: intenção rotulada legada não pode ser rotulada como nova base engastada. Preserve o tipo legado explícito.')
        if kind=='base_plate_type1_legacy' and d.get('base_fixity')!='pinned':
            raise ValueError('Arquivo Tipo 1 legado sem a indicação rotulada original.')
        names={f.name for f in fields(BasePlate)}
        if set(d)-names: raise ValueError('O projeto contém campos não reconhecidos: '+', '.join(sorted(set(d)-names)))
        if not isinstance(d.get('column'),dict): raise ValueError('Seção do pilar ausente ou inválida.')
        try:
            d['column']=Profile(**d['column'])
            if 'active_key' in d:d['active_key']=ActiveShearKey.from_dict(d['active_key'])
            if 'upper_washer' in d:d['upper_washer']=UpperWasher.from_dict(d['upper_washer'])
            if 'single_key_weld' in d:d['single_key_weld']=SingleKeyWeld.from_dict(d['single_key_weld'])
            if 'single_key_concrete' in d:d['single_key_concrete']=SingleKeyConcrete.from_dict(d['single_key_concrete'])
            if 'concrete_components' in d:d['concrete_components']=ConcreteComponents.from_dict(d['concrete_components'])
            if 'column_weld' in d:d['column_weld']=ColumnBaseWeld.from_dict(d['column_weld'])
            c=BasePlate(**d)
        except (TypeError,KeyError) as exc:
            raise ValueError('Dados incompletos ou incompatíveis com a placa de base.') from exc
        # Preserve valid older records that bound dormant, nonstructural rib sizes.
        # Only exact matches to the old current-data digest migrate; stale records do not.
        if c.stiffener_detail=='none':
            if c.anchor_shear_confirmation and c.anchor_shear_confirmation==c._anchor_shear_signature(legacy_dormant=True):
                c=replace(c,anchor_shear_confirmation=c.anchor_shear_signature)
            from .concrete_components import distribution_signature
            u=c.concrete_components
            if u.distribution_confirmation and u.distribution_confirmation==distribution_signature(c,legacy_dormant=True):
                c=replace(c,concrete_components=replace(u,distribution_confirmation=distribution_signature(c)))
        issues=validate(c) if validate_values else []
        if any(i.severity=='error' for i in issues):
            raise ValueError('; '.join(i.text for i in issues if i.severity=='error'))
        return c

@dataclass
class BasePlateResult(Result):
    local_upper_washer: dict = field(default_factory=dict)
    local_single_key_weld: dict = field(default_factory=dict)
    local_single_key_concrete: dict = field(default_factory=dict)
    local_single_key_plate: dict = field(default_factory=dict)
    concrete_components: dict = field(default_factory=dict)
    local_column_weld: dict = field(default_factory=dict)

    @property
    def component_outcome(self):
        """Presentation category; uncalculated/unsupported does not mean failed."""
        if any(i.severity=='error' for i in self.issues): return 'invalid'
        if any(not x.passed for x in self.checks) or any(i.severity=='noncompliance' for i in self.issues): return 'fail'
        if any(out.get('status')=='fail' for out in (self.local_single_key_concrete,self.local_single_key_weld,self.local_column_weld,self.local_upper_washer)): return 'fail'
        if self.component_status=='ATENDE ÀS VERIFICAÇÕES REALIZADAS': return 'pass'
        if not self.checks and not any(i.severity in ('pending','model') for i in self.issues): return 'neutral'
        return 'pending'

    @property
    def component_status(self):
        if any(i.severity=='error' for i in self.issues): return 'DADOS OU GEOMETRIA INVÁLIDOS'
        if self.local_single_key_concrete.get('status')=='fail': return 'NÃO ATENDE ÀS VERIFICAÇÕES REALIZADAS'
        if any(not x.passed for x in self.checks): return 'NÃO ATENDE ÀS VERIFICAÇÕES REALIZADAS'
        if any(i.severity=='noncompliance' for i in self.issues): return 'NÃO ATENDE AO DETALHAMENTO'
        if any(i.severity=='model' for i in self.issues): return 'EQUILÍBRIO NÃO DEMONSTRADO'
        if any(i.severity=='pending' and i.origin=='anchorage_data' for i in self.issues): return 'VERIFICAÇÃO DO CONE COM DADOS PENDENTES'
        if any(i.severity=='pending' and i.origin=='data' for i in self.issues): return 'VERIFICAÇÃO DO CORTANTE COM DADOS PENDENTES'
        if self.local_single_key_concrete.get('status')=='pending': return 'CONCRETO DA CHAVE COM DADOS OU ESTADO PENDENTES'
        if self.local_single_key_weld.get('status')=='pending': return 'SOLDA DA CHAVE COM DADOS OU DETALHE PENDENTES'
        if self.local_column_weld.get('status')=='pending': return 'SOLDA PILAR–PLACA COM DADOS OU MODELO PENDENTES'
        if any(i.severity=='pending' and i.origin=='concrete_components' for i in self.issues): return 'COMPONENTES ACI COM DADOS OU HIPÓTESES PENDENTES'
        if self.local_upper_washer.get('status')=='pending': return 'VERIFICAÇÕES LOCAIS DA ARRUELA COM DADOS PENDENTES'
        if not self.checks: return 'SEM VERIFICAÇÕES'
        return 'ATENDE ÀS VERIFICAÇÕES REALIZADAS'

    @property
    def status(self):
        # Não converte um conjunto parcial de verificações em aprovação da base.
        if self.component_status!='ATENDE ÀS VERIFICAÇÕES REALIZADAS': return self.component_status
        return 'COMPONENTES CALCULADOS ATENDEM · ESCOPO LOCAL DECLARADO'

    @property
    def calculation_note(self):
        if self.local_column_weld.get('model')=='two_flange_normal_web_shear':
            return 'Resultados locais da placa, contato e aço dos chumbadores; soldas e seções locais do pilar discriminadas no componente condicional duas mesas N/M e alma V. Metal-base local e transferência na placa, ancoragem completa, bloco/fundação e rigidez permanecem a complementar.'
        return 'Resultado local da chapa, do contato e do aço dos chumbadores; cone de tração somente quando explicitamente selecionado e dentro do domínio ACI complementar. Ancoragem no concreto (completa), bloco armado e soldas do pilar permanecem a complementar.'


def validate(c):
    issues=validate_details(c)
    issues.extend(validate_upper_washer(c))
    issues.extend(validate_single_key_weld(c))
    issues.extend(validate_single_key_concrete(c))
    issues.extend(validate_components(c))
    issues.extend(validate_column_weld(c))
    if not isinstance(c.active_key,ActiveShearKey):
        issues.append(Issue('error','Dados inválidos de chapas ativas.','Dados da chave'))
        return issues
    def issue(severity,text,ref='Dados da placa de base'): issues.append(Issue(severity,text,ref))
    if not isinstance(c.column,Profile):
        issue('error','Selecione uma seção I/H válida.'); return issues
    positive=('tp','db','a1','a2','fck','grout_fck','grout_t')
    if c.shear_path=='plate':positive+=('lug_bh','lug_bv','lug_t')
    if c.native_anchor_shear:positive+=('anchor_washer_t','anchor_washer_side')
    numeric=('tp','db','a1','a2','fck','grout_fck','grout_t','lug_bh','lug_bv','lug_t','anchor_washer_t','anchor_washer_side','N','M','V','external_shear_rd','anchor_shear_rd')
    for key in numeric:
        value=getattr(c,key)
        if not finite_real(value):
            issue('error',f'{key}: informe um número real finito.')
        elif key in positive and value<=0:
            issue('error',f'{key}: o valor deve ser positivo.')
    for key in ('d','bf','tw','tf','clear','area'):
        value=getattr(c.column,key)
        if not finite_real(value) or value<=0:
            issue('error','Seção do pilar: '+key+' deve ser positivo e finito.')
    for key in ('project','plate_steel','shear_path','external_shear_ref','notes','lug_steel','external_shape','anchor_shear_ref','anchor_shear_confirmation','anchor_shear_model'):
        if not isinstance(getattr(c,key),str): issue('error',key+': texto inválido.')
    if issues: return issues
    issues.extend(validate_active_key(c))
    if any(i.severity=='error' for i in issues):return issues
    if not 20<=c.fck<=50:
        issue('error','O modelo NBR adotado abrange concreto de densidade normal com 20 ≤ fck ≤ 50 MPa. Outros concretos precisam de método específico.',NBR+', 4.6.3.1')
    if c.plate_steel not in STEELS or not STEELS[c.plate_steel].plate_allowed:
        issue('error','Aço da placa não reconhecido ou não aplicável a chapas.'); return issues
    if c.shear_path not in ('friction','external','plate','anchors')+ACTIVE_KEY_PATHS: issue('error','Selecione o caminho resistente do cortante.')
    if c.anchor_shear_model not in ('external','welded_washer'):
        issue('error','Selecione o modelo de cortante pelos chumbadores.')
    if c.lug_steel not in STEELS or not STEELS[c.lug_steel].plate_allowed:
        issue('error','Aço da chave não reconhecido ou não aplicável a chapas.')
    if c.external_shape not in EXTERNAL_SHAPES:
        issue('error','Descrição do dispositivo externo não reconhecida.')
    if c.shear_path=='plate':
        if c.lug_bv<=c.grout_t:
            issue('error','A projeção bv da chave deve superar a espessura real en do graute para haver contato com o concreto.',NBR+', 6.7.2.4')
        if c.lug_bh>c.B or c.lug_t>c.L:
            issue('error','A chave centrada deve caber sob a placa: bh ≤ B e tpv ≤ L.')
    if c.shear_path=='anchors' and not c.native_anchor_shear and c.anchor_shear_rd<0: issue('error','A resistência documentada dos chumbadores ao cortante não pode ser negativa.')
    if c.shear_path=='external' and c.external_shear_rd<0: issue('error','A resistência externa ao cortante não pode ser negativa.')
    if not any(math.isclose(c.db,v,abs_tol=1e-8) for v in ANCHORS.values()):
        issue('error','Diâmetro de chumbador fora da série imperial da Tabela 18. Selecione um diâmetro entre 3/4 e 2 polegadas.',NBR+', tabela 18')
    p=c.column
    if any(not isinstance(getattr(p,k),str) for k in ('name','family','source')):
        issue('error','Designação, família e referência do pilar devem ser textos.'); return issues
    try:
        scale_values=(c.L,c.B,c.a,c.L*c.B,c.a*c.a,p.d*p.bf,
                      (abs(c.effective_moment)+abs(c.N)*c.a)/(c.sigma_rd*c.B),
                      c.m*c.m,c.n*c.n)
        if c.shear_path=='plate' and not any(i.severity=='error' for i in issues):
            scale_values+=tuple(shear_plate_actions(c).values())
        if c.shear_path in ACTIVE_KEY_PATHS and not any(i.severity=='error' for i in issues):
            active_key_actions(c)
        if c.native_anchor_shear:
            scale_values+=(c.anchor_washer_t/c.db,((c.tp+c.anchor_washer_t/2)/c.db)**2,c.db*c.db,
                           c.anchor_washer_side*c.anchor_washer_side)
        if not all(math.isfinite(v) for v in scale_values): raise OverflowError
    except (OverflowError,ZeroDivisionError):
        issue('error','A escala numérica informada excede a precisão do cálculo. Confira unidades e ordens de grandeza; nenhum resultado resistente foi calculado.'); return issues
    if p.d<=2*p.tf or p.bf<=p.tw or p.clear>p.d-2*p.tf+1e-8:
        issue('error','Geometria da seção I/H inconsistente.')
    if c.B<p.bf+25-1e-8:
        issue('noncompliance',f'Largura B={c.B:g} mm menor que bf+25={p.bf+25:g} mm. Aumente o espaçamento a2.',NBR+', 6.7.2.1')
    steel=STEELS[c.plate_steel]
    if not steel.plate_min<=c.tp<=steel.plate_max:
        issue('noncompliance','Espessura da placa fora da faixa do produto de aço selecionado.',steel.source)
    if c.shear_path=='plate' and c.lug_steel in STEELS:
        lug_steel=STEELS[c.lug_steel]
        if not lug_steel.plate_min<=c.lug_t<=lug_steel.plate_max:
            issue('noncompliance','Espessura da chave fora da faixa do produto de aço selecionado.',lug_steel.source)
    if any(i.severity=='error' for i in issues): return issues
    ref=detail_reference(c)
    if c.anchor_edge_distance<=ref['df']/2 or c.a2<=ref['df']:
        issue('error','Os furos precisam estar inteiros na placa e separados entre si. Aumente a1/a2.',NBR+', tabela 18 e geometria')
    if c.model_type==1 and c.a1<ref['washer_side']/2:
        issue('interference','A arruela especial interfere com o perfil ou ultrapassa a placa; ajustar o detalhe sem reduzir o caminho resistente.',NBR+', tabela 18')
    if not ref['matches_spacing']:
        issue('info','Geometria distinta do detalhamento tabulado: a1/a2 diferem da Tabela 18. As forças e a placa são calculadas nas dimensões informadas; ancoragem e detalhamento exigem verificação específica.',NBR+', 6.7.1.1 e tabela 18 corrigida')
    if c.fck<ref['fck_min']:
        issue('noncompliance',f'fck={c.fck:g} MPa abaixo de fck,min={ref["fck_min"]:g} MPa da Tabela 18 para a porca de ancoragem.',NBR+', tabela 18 corrigida, nota b)')
    if c.grout_fck<2*c.fck:
        issue('noncompliance','Argamassa expansiva: fck,graute deve ser pelo menos 2fck do bloco. Atualize o material de assentamento.',NBR+', 6.7.1.5 d)')
    return issues


def _contact_length(H,q,term):
    """Raiz menor racionalizada: preserva precisão em pequenas excentricidades.

    D=H²−2term/q. Não recorta radicando negativo: a ligação precisa mudar.
    """
    D=H*H-2*term/q
    if D<0: raise ValueError('Radicando negativo na equação de contato. Aumente a base ou a resistência do concreto e recalcule.')
    return (2*term/q)/(H+math.sqrt(D)) if term else 0.,D


def reactions(c):
    """Equilíbrio N–M da NBR 6.7.2.2; não calcula ancoragem no concreto."""
    if c.model_type!=1:
        raise ValueError('Use o equilíbrio próprio da família Tipo 2; a fórmula externa Tipo 1 não pode ser reutilizada.')
    N=c.N;M=abs(c.effective_moment);P=max(N,0.);U=max(-N,0.);B=c.B;L=c.L;a=c.a
    q=c.sigma_rd*B;H=L/2+a
    out={'case':'SEM N/M','e':None,'ecrit':None,'lc':0.,'sigma':0.,'C':0.,
         'T_total':0.,'Ft_max':0.,'Ft_min':0.,'X':0.,'lambda':0.,'D':None,
         't_contact':0.,'t_tension':0.,'t_required':0.,'db_required':0.,
         'lmax':0.,'m':c.m,'n':c.n,'n0':c.n0,'moment_sign':1 if c.effective_moment>=0 else -1,
         'M_input':c.M,'delta_M':c.V*c.shear_eccentricity,'M_effective':c.effective_moment,'eV':c.shear_eccentricity,
         'L':L,'B':B,'a':a,'sigma_rd':c.sigma_rd,'tau_rd':c.tau_rd}
    out.update(C_x=0.,T_max_x=-out['moment_sign']*a,T_min_x=out['moment_sign']*a,residual_N=0.,residual_M=0.)
    if N==0 and M==0: return out
    if P>c.sigma_rd*L*B:
        raise ValueError('Compressão N > σRd L B: nem toda a área da placa sustenta a compressão informada. Aumente a base ou a resistência do concreto.')
    X=4*c.column.d*c.column.bf/(c.column.d+c.column.bf)**2*P/(L*B*c.sigma_rd)
    out['X']=X
    if X>1: raise ValueError('X > 1 no domínio corrigido da NBR 6.7.2.1. Aumente a base ou a resistência do concreto; não se calcula √(1−X).')
    lam=min(1.,2*math.sqrt(X)/(1+math.sqrt(1-X)))
    out['lambda']=lam
    if P:
        e=M/P;ecrit=.5*(L-P/q);out.update(e=e,ecrit=ecrit)
        if M==0:
            case='C1';lc=L;C=P;sigma=P/(B*lc);Ft=Fmin=0.
        elif e<=ecrit:
            case='C2';lc=L-2*e;C=P;sigma=P/(B*lc);Ft=Fmin=0.
        else:
            case='C3';lc,D=_contact_length(H,q,M+P*a);out['D']=D
            C=q*lc;sigma=c.sigma_rd;Ft=2*(C-P)/c.count;Fmin=0.
    elif U and M<=U*a:
        case='T1' if M==0 else 'T2';lc=0.;C=sigma=0.
        Ft=U/c.count+M/(a*c.count);Fmin=U/c.count-M/(a*c.count);out['e']=M/U
    else:
        case='T3' if U else 'M0';lc,D=_contact_length(H,q,M-U*a);out['D']=D
        C=q*lc;sigma=c.sigma_rd;Ft=2*(C+U)/c.count;Fmin=0.
        if U: out['e']=M/U
    if lc<0 or lc>L+1e-8 or Ft<-1e-7 or Fmin<-1e-7:
        raise ValueError('A solução não produz uma faixa de contato e trações fisicamente admissíveis. Reveja geometria e ações.')
    Ft=max(Ft,0.);Fmin=max(Fmin,0.)
    # Para C1/C2 a pressão real governa; C3/T3 usam a pressão resistente.
    lmax=0.;tcomp=0.
    if lc>0:
        if lc>=c.m:
            candidates=[c.m,c.n]
            if case in ('C1','C2','C3'): candidates.append(lam*c.n0)
            lmax=max(candidates)
        else:
            lmax=max(math.sqrt(lc*(2*c.m-lc)),c.n)
        tcomp=lmax*math.sqrt(2*sigma/(c.fy/G1))
    ttension=math.sqrt(2*c.count*Ft*(c.m-c.a1)/(B*(c.fy/G1))) if Ft else 0.
    dbmin=math.sqrt(4*Ft/(.75*math.pi*(400/G2))) if Ft else 0.
    Ttotal=2*(Ft+Fmin)
    out.update(case=case,lc=lc,C=C,sigma=sigma,T_total=Ttotal,Ft_max=Ft,Ft_min=Fmin,
               t_contact=tcomp,t_tension=ttension,t_required=max(tcomp,ttension),
               db_required=dbmin,lmax=lmax)
    # Forças/posições para um desenho orientado e para auditoria de equilíbrio.
    sign=out['moment_sign']
    out['C_x']=sign*(L/2-lc/2) if C else 0.
    out['T_max_x']=-sign*a
    out['T_min_x']=sign*a
    out['residual_N']=C-Ttotal-N
    out['residual_M']=C*out['C_x']-2*Ft*out['T_max_x']-2*Fmin*out['T_min_x']-c.effective_moment
    return out


def shear_plate_actions(c):
    """NBR 6.7.2.4: ações/resistências locais da chapa, não do dispositivo completo.

    N, mm e MPa. Somente geometria validada; bh paralelo a B e V paralelo a L.
    As ações das soldas são prescritas pela resistência de contato do concreto.
    """
    sigma=1.7*c.fck/GC
    area=c.lug_bh*(c.lug_bv-c.grout_t)
    bearing=sigma*area
    denom=c.lug_bh*(c.lug_fy/G1)
    return dict(sigma_rd=sigma,contact_area=area,bearing_rd=bearing,
                t_required=math.sqrt(2*abs(c.V)*(c.lug_bv+c.grout_t)/denom),
                bending_rd=denom*c.lug_t**2/(2*(c.lug_bv+c.grout_t)),
                yield_rd=.60*c.lug_fy*c.lug_bh*c.lug_t/G1,
                rupture_rd=.60*c.lug_fu*c.lug_bh*c.lug_t/G2,
                weld_V=bearing,weld_M=bearing*(c.lug_bv+c.grout_t)/2)


def _add_shear_plate_checks(c,r,add):
    lug=shear_plate_actions(c)
    add('lug_contact','Chave de chapa — contato local no concreto',abs(c.V),lug['bearing_rd'],'N',
        NBR+', 6.7.2.4 e 6.6.5','Vbearing,Rd = (1,7 fck/γc) bh (bv−en); A2/A1=4',
        f'σlug,Rd={lug["sigma_rd"]:.6f}; bh={c.lug_bh:g}; bv={c.lug_bv:g}; en={c.grout_t:g}; Vbearing,Rd={lug["bearing_rd"]:.5f}',
        'Cortante total |V|, sem somar atrito. Contato local não verifica ruptura do bloco nem efeitos de borda.')
    add('lug_bending','Chave de chapa — flexão local',lug['t_required'],c.lug_t,'mm',
        NBR+', 6.7.2.4','tpv,min = √[2 |VSd| (bv+en)/(bh (fy/γa1))]',
        f'|VSd|={abs(c.V):.5f}; bv+en={c.lug_bv+c.grout_t:g}; bh={c.lug_bh:g}; fy={c.lug_fy:g}; tpv,min={lug["t_required"]:.6f}; tpv={c.lug_t:g}',
        'Flexão da própria chave; não é a flexão local da placa de base na ligação da chave.')
    add('lug_thickness','Chave de chapa — relação com a placa de base',c.lug_t,c.tp,'mm',
        NBR+', 6.7.2.4','tpv ≤ tp',f'tpv={c.lug_t:g}; tp={c.tp:g}',
        'A espessura da chave não pode exceder a da placa de base neste modelo; as entradas não são corrigidas.')
    for tag,title,fy,g,rd in [('yield','escoamento por cisalhamento',c.lug_fy,G1,lug['yield_rd']),
                             ('rupture','ruptura por cisalhamento',c.lug_fu,G2,lug['rupture_rd'])]:
        add('lug_'+tag,'Chave de chapa — '+title,abs(c.V),rd,'N',NBR+', 6.5.5 a) e b)',
            'VRd = 0,60 fy Ag/γa1' if tag=='yield' else 'VRd = 0,60 fu Anv/γa2',
            f'f={fy:g}; Ag=Anv=bh tpv={c.lug_bh*c.lug_t:g}; γ={g:g}; VRd={rd:.5f}',
            'Chapa retangular maciça sem furos; não abrange a transferência de tensões ao metal-base na solda.')
    from .single_key_plate import eligible as key_plate_eligible
    plate_scope=('flexão da seção bruta da placa tratada em componente separado; transferência completa e metal-base a complementar' if key_plate_eligible(c) else 'metal-base e flexão local da placa na ligação da chave a complementar')
    r.issues.append(Issue('pending',('Chave de chapa: '+plate_scope+'; metal dos filetes discriminado no componente selecionado. ' if c.single_key_weld.model!='off' else 'Chave de chapa: soldas (resistência e detalhamento), '+plate_scope+'. ')+'Ações prescritas das soldas são calculadas à resistência de contato do concreto, mesmo quando maiores que o cortante aplicado.',NBR+', 6.7.2.4 e 6.2.5.1, tabela 9'))
    r.issues.append(Issue('pending','Chave de chapa: ruptura/arrancamento do concreto, efeitos de borda e bloco adequadamente armado a dimensionar conforme NBR 6118. Atendimento local não aprova o dispositivo completo.',NBR+', 6.7.2.4'))
    return lug


def anchor_shear_actions(c,a):
    """Resistências individuais do detalhe 6.7.2.5, sem supor V/4.

    As quatro arruelas soldadas, com furos-padrão, mobilizam o grupo.
    Cada parcela usa a tração simultânea da respectiva posição. A expressão
    especial é limitada separadamente pela interação geral 6.3.3.4 e pelo
    limite local do concreto. Não calcula solda/arruela/ancoragem completa.
    """
    area=math.pi*c.db**2/4
    fv=.45*area*400/G2
    ft=.75*area*400/G2
    alpha=1.45*((c.tp+.5*c.anchor_washer_t)/c.db)*(400/250)*(G1/G2)
    cap=5*c.db**2*c.sigma_rd
    subtractive=max(a['Ft_max'],a['Ft_min'])
    smax=.533*subtractive/fv
    rods=[]
    from .concrete_anchorage import anchor_tensions
    for i,rod in enumerate(anchor_tensions(c,a),1):
        x,y,tension=rod["x"],rod["y"],rod["tension"]
        s=.533*tension/fv
        radicand=1+alpha*alpha-s*s
        domain=(0<=tension<=ft*(1+1e-12) and radicand>=0 and s<=1)
        steel=combined=0.
        if domain:
            # A fonte imprime Ft,Sd,1 no termo subtrativo e Ft,Sd,i na
            # raiz. Adota-se o maior Ft concorrente no termo subtrativo:
            # limite conservador para ambas as leituras, não errata criada.
            steel=max(0.,fv*(math.sqrt(radicand)-alpha*smax)/(1+alpha*alpha))
            tr=tension/ft
            # Apenas ruído de ponto flutuante no limite Ft=Ft,Rd é tolerado.
            combined=fv*math.sqrt(max(0.,(1-tr)*(1+tr)))
        rods.append(dict(id=f'A{i}',x=x,y=y,tension=tension,steel_rd=steel,
                         combined_rd=combined,rd=min(steel,combined,cap),domain_ok=domain))
    valid=all(rod['domain_ok'] for rod in rods)
    return dict(alpha=alpha,subtractive_tension=subtractive,index_envelope=True,
                shear_unreduced_rd=fv,tension_rd=ft,sigma_rd=c.sigma_rd,
                concrete_cap=cap,group_rd=sum(rod['rd'] for rod in rods) if valid else 0.,
                special_group_rd=sum(min(rod['steel_rd'],cap) for rod in rods) if valid else 0.,
                combined_group_rd=sum(rod['combined_rd'] for rod in rods) if valid else 0.,
                rods=rods,weld_force_per_washer=fv,domain_ok=valid)


def _add_native_anchor_shear_checks(c,r,add,*,table_detail=True):
    # Channel-only smaller rods have no Table 18 row. All mechanical checks
    # below still run; their caller retains a separate detailing limitation.
    ref=detail_reference(c) if table_detail else None
    ash=anchor_shear_actions(c,r.geometry)
    r.geometry['anchor_shear']=ash
    r.geometry['shear_rd']=ash['group_rd']
    if ref is not None:add('anchor_washer_thickness','Arruelas especiais — espessura mínima de referência',ref['washer_t'],c.anchor_washer_t,'mm',
        NBR+', tabela 18 corrigida','ta ≥ ta,Tabela 18',
        f'ta,min={ref["washer_t"]:g}; ta={c.anchor_washer_t:g}',
        'Espessura real adotada em todas as quatro arruelas; integra o braço local tp+ta/2. Não verifica flexão/esmagamento da arruela.')
    if ref is not None:add('anchor_washer_side','Arruelas especiais — lado mínimo de referência',ref['washer_side'],c.anchor_washer_side,'mm',
        NBR+', tabela 18 corrigida','ba ≥ ba,Tabela 18',
        f'ba,min={ref["washer_side"]:g}; ba={c.anchor_washer_side:g}; furo=db+1,5={c.anchor_washer_hole:g}',
        'Arruela quadrada fy=345 MPa; furo-padrão fixo db+1,5 mm. Este mínimo tabulado não verifica pressão no furo, rasgamento ou flexão local; o submodelo de furo, quando selecionado, é separado.')
    gap=c.washer_clearance
    add('anchor_washer_fit','Arruelas especiais — espaço geométrico para a ligação',0.,gap,'mm',
        'Geometria do detalhe de quatro arruelas soldadas',c.washer_clearance_expression+' > 0',
        f'a1={c.a1:g}; a2={c.a2:g}; ba={c.anchor_washer_side:g}; g={gap:g}',
        'Folga positiva entre arruela/perfil/borda e entre arruelas. O tamanho e acesso efetivos da solda ainda precisam ser detalhados; g>0 não dimensiona a solda.')
    if not ash['domain_ok']:
        r.issues.append(Issue('noncompliance','Cortante nativo: ao menos um chumbador excede Ft,Rd ou a expressão sai do domínio. Não se atribui capacidade ao grupo; os demais resultados N–M permanecem disponíveis.',NBR+', 6.3.3.1, 6.3.3.4 e 6.7.2.5'))
    if not math.isclose(r.geometry['Ft_max'],r.geometry['Ft_min'],rel_tol=1e-10,abs_tol=1e-8):
        r.issues.append(Issue('warning','A expressão publicada em 6.7.2.5 mostra Ft,Sd,i na raiz e Ft,Sd,1 no termo subtrativo. Com trações diferentes, o app usa a maior tração simultânea nesse termo para todas as barras: limite conservador explícito, sem corrigir silenciosamente o índice da norma.',NBR+', 6.7.2.5 — ambiguidade do índice publicado'))
    # Zero cortante com todos os chumbadores no limite de tração não exige
    # reserva positiva de corte; não se usa a razão artificial 0/0 como passe.
    if abs(c.V)>0 or ash['group_rd']>0 or not ash['domain_ok']:
        add('anchor_shear_native','Chumbadores — cortante com tração simultânea',abs(c.V),ash['group_rd'],'N',
            NBR+', 6.7.2.5; 6.3.3.2 e 6.3.3.4',
            '|VSd| ≤ Σ min(V6.7.2.5,Rd,i; Fv,Rd √[1−(Ft,Sd,i/Ft,Rd)²]; 5 db² σc,Rd)',
            f'α={ash["alpha"]:.8f}; Fv,Rd={ash["shear_unreduced_rd"]:.6f}; Ft,Rd={ash["tension_rd"]:.6f}; limite concreto={ash["concrete_cap"]:.6f}; VRd,grupo={ash["group_rd"]:.6f}',
            'Quatro parcelas calculadas com Ft,Sd individual da mesma combinação. Não presume V/4; não soma atrito/chave. A interação geral é um limite adicional, sem alterar o coeficiente 0,533 da expressão especial.')
    else:
        r.issues.append(Issue('info','Cortante aplicado nulo e reserva ao corte nula nos chumbadores no limite da tração. Nenhuma resistência positiva de cortante é atribuída.',NBR+', 6.3.3.4'))
    r.issues.append(Issue('pending','O limite local 5db²σc,Rd utiliza σc,Rd=0,85fck/γc sem ganho por confinamento. Não verifica a ancoragem completa. O cone de concreto, com efeitos de grupo e borda, arrancamento, pryout e interação tração–corte exigem verificações independentes, calculadas somente quando selecionadas e no domínio declarado. O bloco armado e a transferência local completa continuam a complementar.',NBR+', 6.7.2.5 e 6.6.5; NBR 6118'))
    return ash


def _add_concrete_cone(c,r,add):
    from .concrete_anchorage import evaluate_cone,SOURCE
    cone=evaluate_cone(c,r.geometry);r.geometry['concrete_cone']=cone
    if cone['status']=='off':return
    if cone['status']=='pending':
        for reason in cone['reasons']:
            r.issues.append(Issue('pending',reason,SOURCE,origin='anchorage_data'))
    elif cone['status']=='not_demanded':
        r.issues.append(Issue('info','Cone de tração sem solicitação nesta combinação: nenhuma barra tracionada. Não é verificação do concreto ao cortante nem aprovação da ancoragem.',SOURCE))
    else:
        for g in cone['groups']:
            add('cone_'+g['id'],('Cone suplementar — ' if g.get('basis')=='supplemental' else 'Cone de concreto à tração — ')+', '.join(g['ids']),g['demand'],g['resistance'],'N',SOURCE,
                'φNcb = 0,70 (ANc/ANco) ψec,N ψed,N Nb; ANco=9 hcalc²; Nb=24√fc,psi hcalc,in^1,5 [lbf]',
                f'hef físico={g["hef"]:.6f}; hcalc={g["hcalc"]:.6f}; ANc={g["area"]:.6f}; ANco={g["area0"]:.6f}; ψec={g["psi_ec"]:.8f}; ψed={g["psi_ed"]:.8f}; Nb={g["nb"]:.6f} N; φNcb={g["resistance"]:.6f} N',
                'Trações simultâneas positivas das barras indicadas; união de projeções limitada às bordas reais. '+('Envelope suplementar conservador opcional da aplicação; não é exigência literal ACI. ' if g.get('basis')=='supplemental' else 'Grupo tracionado conectado do método ACI. ')+'Sem somar resistências de cones desconectados.')
    r.issues.append(Issue('pending','Cone de tração ACI 318-19/DG1: concreto fissurado normal e φ=0,70 Condição B. Pullout, ruptura lateral, aço e interação têm aplicabilidade própria; cortante/pryout só quando houver cortante nos chumbadores. Peça local, detalhamento e projeto do bloco permanecem em seus escopos. Sem reaplicar γc ou majorar novamente as ações.',SOURCE))


def evaluate(c):
    if c.model_type==3:
        from .channel_base_plate import evaluate as evaluate_channel
        return evaluate_channel(c)
    if c.model_type==2:
        from .pinned_base_plate import evaluate as evaluate_pinned
        return evaluate_pinned(c)
    return evaluate_components(c,validate,reactions)


def evaluate_components(c,validator,reaction_solver):
    """Shared component checks, with explicit family-specific domain and equilibrium."""
    r=BasePlateResult(issues=validator(c))
    if any(i.severity=='error' for i in r.issues): return r
    def add(i,name,sd,rd,unit,ref,eq,sub,var):
        r.checks.append(Check('bp_'+i,name,sd,rd,unit,ref,eq,sub,var))
    # As verificações de dados/condições permanecem visíveis, mesmo sem equilíbrio.
    add('grout','Argamassa expansiva — resistência mínima',2*c.fck,c.grout_fck,'MPa',
        NBR+', 6.7.1.5 d)','fck,graute ≥ 2fck',f'2 × {c.fck:g} = {2*c.fck:g} ≤ {c.grout_fck:g}',
        'Resistências características à compressão, em MPa.')
    add('width',f'Geometria Tipo {c.model_type} — largura mínima',c.column.bf+25,c.B,'mm',
        NBR+', 6.7.2.1','B = a2 + 2a1 ≥ bf + 25',f'B={c.B:g}; bf+25={c.column.bf+25:g}',
        'B: largura transversal; a2: passo entre chumbadores; a1: folga e borda.')
    lug=_add_shear_plate_checks(c,r,add) if c.shear_path=='plate' else None
    if lug is not None:r.local_single_key_weld=add_single_key_weld_checks(c,r,add,lug)
    active=add_active_key_checks(c,r,add) if c.shear_path in ACTIVE_KEY_PATHS else None
    if c.native_anchor_shear:
        r.local_upper_washer=add_upper_washer_checks(c,r,add)
    try:
        a=reaction_solver(c)
    except ValueError as exc:
        r.local_single_key_concrete=add_single_key_concrete_checks(c,r,add,native_reason=str(exc))
        r.local_single_key_plate=add_single_key_plate_checks(c,r,add)
        r.issues.append(Issue('model',str(exc),NBR+', 6.7.2.1 e 6.7.2.2'))
        r.issues.append(Issue('pending',r.calculation_note,NBR+', 6.7.1.3'))
        return r
    r.geometry=a
    r.local_single_key_concrete=add_single_key_concrete_checks(c,r,add,native_geometry=a)
    if r.local_single_key_concrete:a['single_key_concrete']=r.local_single_key_concrete
    r.local_single_key_plate=add_single_key_plate_checks(c,r,add,native_geometry=a)
    if r.local_single_key_plate:a['single_key_plate']=r.local_single_key_plate
    a['grout']=grout_geometry(c)
    r.issues.extend(detailing_issues(c))
    if lug is not None:a['lug']=lug
    if active is not None:a['active_key']=active
    if r.local_upper_washer:a['upper_washer']=r.local_upper_washer
    if r.local_single_key_weld:a['single_key_weld']=r.local_single_key_weld
    case=a['case'];a['friction_rd']=min(MU*a['C']/G2,c.tau_rd*c.L*c.B)
    if case=='M0':
        r.issues.append(Issue('info','Momento puro: limite de equilíbrio estático C3/T3 com N=0, sem usar e=M/N. A expressão é derivada e não é um caso separado enumerado pela NBR.',NBR+', 6.7.2.2; limite estático do modelo'))
    if a['C']:
        add('contact','Concreto — pressão de contato',a['sigma'],c.sigma_rd,'MPa',
            NBR+', 6.6.5 e 6.7.2.2',
            'σRd = 0,85 fck/γc; A2/A1 = 1; σSd = C/(B lc)',
            f'C={a["C"]:.4f}; B={c.B:g}; lc={a["lc"]:.5f}; σSd={a["sigma"]:.6f}; σRd={c.sigma_rd:.6f}',
            'C: resultante comprimida, N; lc: comprimento de contato, mm; sem ganho por confinamento.')
        add('plate_contact','Placa — flexão sob o contato',a['t_contact'],c.tp,'mm',
            NBR+', 6.7.2.1 e 6.7.2.2',
            'tmin,c = lmax √[2σSd/(fy/γa1)]',
            f'caso={case}; m={c.m:.5f}; n={c.n:.5f}; n0={c.n0:.5f}; X={a["X"]:.7f}; λ={a["lambda"]:.7f}; lmax={a["lmax"]:.5f}; tmin,c={a["t_contact"]:.5f}',
            'lmax conforme o caso e a extensão de contato; γa1=1,10. X≤1 sem extrapolar a raiz da equação corrigida.')
    if a['Ft_max']:
        add('plate_tension','Placa — flexão junto aos chumbadores',a['t_tension'],c.tp,'mm',
            NBR+', 6.7.2.2 c) a f)',
            ('tmin,t = √[nb Ft,Sd (a2−tw)/(l0 fy/γa1)]; l0=min[d; a2+1,75(a2−tw)]' if c.model_type==2 else 'tmin,t = √[2 nb Ft,Sd (m−a1)/(B fy/γa1)]'),
            (f'nb=4; Ft,Sd={a["Ft_max"]:.5f}; a2−tw={c.a2-c.column.tw:.5f}; l0={a["l0"]:.5f}; fy={c.fy:g}; tmin,t={a["t_tension"]:.5f}' if c.model_type==2 else f'nb=4; Ft,Sd={a["Ft_max"]:.5f}; m−a1={c.m-c.a1:.5f}; B={c.B:g}; fy={c.fy:g}; tmin,t={a["t_tension"]:.5f}'),
            'Ft,Sd é a maior tração por chumbador; nb=4. Em T2 a força da outra linha é menor.')
        add('anchor_steel','Chumbador ASTM A36 — ruptura do aço à tração',a['Ft_max'],c.anchor_steel_rd,'N',
            NBR+', 6.7.2.2 c) a f)',
            'Ft,Rd = 0,75 (π db²/4) fu/γa2',
            f'db={c.db:g}; fu=400; γa2={G2:g}; Ft,Rd={c.anchor_steel_rd:.5f}; db,min={a["db_required"]:.5f}',
            'Resistência do aço da barra rosqueada, não da ancoragem no concreto. Não se atribui resistência por nome comercial.')
    if c.shear_path=='friction':
        a['shear_rd']=a['friction_rd']
        if a['shear_rd']>0:
            add('shear','Deslizamento — atrito no graute',abs(c.V),a['shear_rd'],'N',
                NBR+', 6.7.2.2 e 6.7.2.3',
                'VRd = min(0,45 C/γa2; τRd L B); τRd = min(0,2 fck/γc; 4 MPa)',
                f'C={a["C"]:.5f}; 0,45C/γa2={MU*a["C"]/G2:.5f}; τRd={c.tau_rd:.6f}; VRd={a["shear_rd"]:.5f}',
                'Contato com argamassa expansiva; chumbadores sem crédito resistente ao corte.')
        elif abs(c.V)>0:
            r.issues.append(Issue('noncompliance','Há cortante e não há compressão de contato para mobilizar atrito. Selecione um dispositivo de cisalhamento com resistência documentada.',NBR+', 6.7.2.3'))
        if abs(c.V)>a['shear_rd']+1e-8 and a['shear_rd']>0:
            r.issues.append(Issue('noncompliance','O cortante supera o atrito resistente. Um dispositivo deve resistir ao cortante total, sem somar atrito.',NBR+', 6.7.2.3'))
    elif c.native_anchor_shear:
        _add_native_anchor_shear_checks(c,r,add)
    elif c.shear_path=='anchors':
        a['shear_rd']=c.anchor_shear_rd
        if c.anchor_shear_rd<=0 or not c.anchor_shear_ref.strip() or not c.anchor_capacity_confirmed:
            r.issues.append(Issue('pending','Cortante pelos chumbadores: informe VRd externo positivo do grupo instalado, referência da memória e confirme sua aplicação ao detalhe e à combinação atual N–M–V. Alterar esses dados invalida a confirmação, sem bloquear os demais cálculos.',NBR+', 6.7.1.3',origin='data'))
        else:
            add('shear_anchors_external','Chumbadores — comparação documental de cortante',abs(c.V),c.anchor_shear_rd,'N',
                'Resistência externa informada: '+c.anchor_shear_ref,'|VSd| ≤ VRd,conjunto documentado; sem soma de atrito/chave',
                f'|VSd|={abs(c.V):.5f}; VRd,conjunto={c.anchor_shear_rd:.5f}',
                'Somente comparação com memória externa; não calcula resistência ao corte dos chumbadores nem interação com a tração calculada.')
        r.issues.append(Issue('pending','Chumbadores ao cortante: resistência ao corte, interação tração–cisalhamento, flexão/esmagamento local, efeito de alavanca e transferência ao concreto não verificados pelo app. A memória externa deve cobrir o conjunto e a excentricidade da reação.',NBR+', 6.7.1.3'))
    elif c.shear_path=='external':
        a['shear_rd']=c.external_shear_rd
        if c.external_shear_rd<=0 or not c.external_shear_ref.strip():
            r.issues.append(Issue('pending','Dispositivo externo: informe resistência de cálculo positiva e referência da memória que verifica o dispositivo, suas soldas e a transferência ao bloco.',NBR+', 6.7.2.3',origin='data'))
        else:
            add('shear_external','Cortante — comparação com dispositivo externo',abs(c.V),c.external_shear_rd,'N',
                'Resistência informada: '+c.external_shear_ref,
                '|VSd| ≤ VRd,dispositivo; sem somar atrito',
                f'|VSd|={abs(c.V):.5f}; VRd,dispositivo={c.external_shear_rd:.5f}',
                'Comparação documental; '+EXTERNAL_SHAPES[c.external_shape]+'. O módulo não dimensiona nem valida a memória externa, inclusive a excentricidade da reação e seus efeitos na base.')
    _add_concrete_cone(c,r,add)
    r.concrete_components=add_component_checks(c,r,add)
    r.local_column_weld=add_column_weld_checks(c,r,add)
    r.issues.append(Issue('pending',r.calculation_note,NBR+', 6.7.1.3 e tabela 18'))
    r.actual=list(r.checks)
    return r


def presets():
    """Exemplos verificáveis; ações didáticas, não extraídas de um projeto real."""
    from dataclasses import replace
    catalog=profiles()
    p=next((v for k,v in catalog.items() if k.startswith('W 250') or k.startswith('W250')),next(iter(catalog.values())))
    c=BasePlate(p,a2=max(80.,p.bf+25-80),project='Exemplo didático C1 — compressão centrada')
    return {
        'Chumbadores · arruelas soldadas':replace(c,shear_path='anchors',anchor_shear_model='welded_washer',V=20000.,project='Nova base — chumbadores com arruelas soldadas'),
        'Chumbadores · resistência externa':replace(c,shear_path='anchors',project='Base — cortante documentado nos chumbadores'),
        'C1 · compressão centrada':c,
        'C2 · pequena excentricidade':replace(c,N=150000.,M=6e6,project='Exemplo didático C2 — contato sem tração'),
        'C3 · compressão e momento':replace(c,N=150000.,M=40e6,tp=31.75,project='Exemplo didático C3 — contato e tração'),
        'T1 · tração centrada':replace(c,N=-80000.,M=0.,tp=25.4,project='Exemplo didático T1 — tração centrada'),
        'T2 · tração e pequeno momento':replace(c,N=-80000.,M=5e6,tp=25.4,project='Exemplo didático T2 — duas linhas tracionadas'),
        'T3 · tração e grande momento':replace(c,N=-80000.,M=30e6,tp=38.1,project='Exemplo didático T3 — contato e tração'),
        'Chave retangular · cortante puro':replace(c,N=0.,M=0.,V=100000.,tp=50.8,fck=20.,
            shear_path='plate',lug_bh=100.,lug_bv=100.,lug_t=50.8,grout_t=40.,
            project='Exemplo didático — chave retangular com verificações locais'),
        'Cruz · chapa perpendicular ativa':replace(c,N=0.,M=-30e6,V=180000.,tp=50.8,a2=180.,fck=20.,grout_t=40.,
            shear_path='cross_active_plate',active_key=ActiveShearKey(continuous=True,concrete_filled=True,t=50.8,product='fabricated',
            geometry_ref='Geometria sintética: chapa secundária de 10 mm e filetes de junção de 5 mm; raiz não informada.'),
            project='Exemplo didático — cruz por chapa ativa'),
        'W · envelope de repartição':replace(c,N=0.,M=-20e6,V=160000.,tp=50.8,a2=180.,fck=20.,grout_t=40.,
            shear_path='w_flange_plates',active_key=ActiveShearKey(continuous=True,concrete_filled=True,radius=10.,
            geometry_ref='Geometria sintética de regressão, sem catálogo: d=bf=200; tw=10; tf=25; r=10 mm.'),
            project='Exemplo didático — W por mesas ativas, envelope'),
        'W · repartição igual idealizada':replace(c,N=0.,M=-20e6,V=160000.,tp=50.8,a2=180.,fck=20.,grout_t=40.,
            shear_path='w_flange_plates',active_key=ActiveShearKey(continuous=True,concrete_filled=True,radius=10.,sharing='equal',
            geometry_ref='Geometria sintética de regressão, sem catálogo: d=bf=200; tw=10; tf=25; r=10 mm.'),
            project='Exemplo didático — W por mesas ativas, repartição igual'),
    }


# Named public identity for the external-anchor family; BasePlate remains API-compatible.
FixedBasePlate = BasePlate
