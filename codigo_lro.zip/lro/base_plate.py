"""Base exposta Tipo 1 — ABNT NBR 8800:2024, corrigida em 2025.

Modelo local, estático, de quatro chumbadores externos, sem enrijecedores.
Unidades canônicas: N, mm, MPa; N positivo comprime a base. As ações já
são de cálculo. Não calcula a ancoragem no concreto ou o bloco armado.
"""
from dataclasses import dataclass, asdict, fields
import math
import hashlib
import json
from .models import Profile, Check, Issue, Result, STEELS, VERSION, profiles

G1 = 1.10
G2 = 1.35
GC = 1.40
MU = .45
NBR = 'ABNT NBR 8800:2024, versão corrigida 2025'
EXTERNAL_SHAPES = {'other':'Outro dispositivo documentado', 'cruciform':'Chave cruciforme de chapas',
                   'w_major':'Trecho de perfil W · alma paralela a V', 'w_minor':'Trecho de perfil W · alma perpendicular a V'}
STOCK = {'1/4"':6.35,'5/16"':7.9375,'3/8"':9.525,'1/2"':12.7,
         '5/8"':15.875,'3/4"':19.05,'7/8"':22.225,'1"':25.4,
         '1 1/4"':31.75,'1 1/2"':38.1,'1 3/4"':44.45,'2"':50.8}
ANCHORS = {'3/4"':19.05,'7/8"':22.225,'1"':25.4,'1 1/4"':31.75,
           '1 1/2"':38.1,'1 3/4"':44.45,'2"':50.8}

# Tabela 18 SUBSTITUÍDA pela errata 2025. Não usar os mínimos da edição
# original de 2024: Nb,min, S e as expressões do bloco foram corrigidos.
_DETAIL_ROWS = [
    (40,80,120,450,150,175,50,33,6.3,50,40,20,900,125,10),
    (45,90,140,465,200,225,50,40,6.3,65,50,20,900,100,10),
    (50,100,160,465,200,225,50,45,8,75,60,25,900,125,12.5),
    (65,130,190,525,225,250,60,50,9.5,75,60,25,1100,100,12.5),
    (80,160,230,610,250,275,70,60,9.5,90,70,25,1300,150,16),
    (90,180,270,700,300,325,70,70,12.5,100,80,25,1600,125,16),
    (100,200,300,850,350,375,100,80,16,125,90,30,1800,100,16),
]
_DETAIL_KEYS = ('a1','a2','a3','h1','h2','r1','r2','df','washer_t',
                'washer_side','en','fck_min','Nb_min','S','rebar_diameter')
DETAIL = {label:dict(zip(_DETAIL_KEYS,row)) for label,row in zip(ANCHORS,_DETAIL_ROWS)}


def detail_reference(c):
    """Referência construtiva corrigida, não aprovação da ancoragem/bloco."""
    label=next(k for k,v in ANCHORS.items() if math.isclose(c.db,v,abs_tol=1e-8))
    ref=dict(DETAIL[label]);ref['label']=label
    ref['washer_hole']=c.db+1.5
    ref['Nb']=max(ref['Nb_min'],c.L+2*ref['en'],c.L+2*(ref['a3']-c.a1))
    ref['Bb']=max(c.B+2*ref['en'],c.B+2*(ref['a3']-c.a1))
    ref['Ab']=max(ref['h1']+100,ref['Nb'])
    ref['da_max']=.5*(ref['h1']-.5*(ref['r2']+c.db))
    ref['matches_spacing']=math.isclose(c.a1,ref['a1']) and math.isclose(c.a2,ref['a2'])
    return ref

@dataclass(frozen=True)
class BasePlate:
    column: Profile
    project: str = 'Placa de base Tipo 1'
    plate_steel: str = 'ASTM A36'
    tp: float = 19.05
    db: float = 19.05
    a1: float = 40.
    a2: float = 180.
    fck: float = 30.
    grout_fck: float = 60.
    grout_t: float = 40.
    N: float = 150000.
    M: float = 0.
    V: float = 0.
    shear_path: str = 'friction'
    external_shear_rd: float = 0.
    external_shear_ref: str = ''
    notes: str = ''
    lug_bh: float = 100.
    lug_bv: float = 100.
    lug_t: float = 19.05
    lug_steel: str = 'ASTM A36'
    external_shape: str = 'other'
    anchor_shear_rd: float = 0.
    anchor_shear_ref: str = ''
    anchor_shear_confirmation: str = ''

    @property
    def L(self): return self.column.d + 4*self.a1
    @property
    def B(self): return self.a2 + 2*self.a1
    @property
    def a(self): return self.L/2-self.a1
    @property
    def count(self): return 4
    @property
    def m(self): return (self.L-.95*self.column.d)/2
    @property
    def n(self): return (self.B-.80*self.column.bf)/2
    @property
    def n0(self): return math.sqrt(self.column.d*self.column.bf)/4
    @property
    def fy(self): return STEELS[self.plate_steel].fy
    @property
    def sigma_rd(self): return .85*self.fck/GC  # A2/A1=1, sem confinamento presumido
    @property
    def tau_rd(self): return min(.2*self.fck/GC, 4.)
    @property
    def anchor_steel_rd(self): return .75*math.pi*self.db**2/4*400/G2
    @property
    def lug_fy(self): return STEELS[self.lug_steel].fy
    @property
    def lug_fu(self): return STEELS[self.lug_steel].fu
    @property
    def shear_eccentricity(self):
        return self.tp+(self.lug_bv+self.grout_t)/2 if self.shear_path=='plate' else 0.
    @property
    def effective_moment(self):
        # Apenas a chave de chapa tem geometria interna: preservar rotas legadas.
        return self.M+self.V*self.shear_eccentricity if self.shear_path=='plate' else self.M
    @property
    def anchor_shear_signature(self):
        # Vínculo técnico à combinação/material/detalhe, não ao título/notas.
        keys=('plate_steel','tp','db','a1','a2','fck','grout_fck','grout_t',
              'N','M','V','anchor_shear_rd','anchor_shear_ref')
        data={k:getattr(self,k) for k in keys}
        data['column']={k:getattr(self.column,k) for k in ('d','bf','tw','tf','clear','area')}
        def stable(value):
            if isinstance(value,dict):return {k:stable(v) for k,v in value.items()}
            if isinstance(value,(float,int)) and not isinstance(value,bool):return format(value,'.12g')
            return value
        return hashlib.sha256(json.dumps(stable(data),sort_keys=True,ensure_ascii=False).encode()).hexdigest()
    @property
    def anchor_capacity_confirmed(self):
        return bool(self.anchor_shear_confirmation) and self.anchor_shear_confirmation==self.anchor_shear_signature
    @property
    def assumptions(self):
        return [
            'Placa retangular sem enrijecedores, perfil I/H centrado e quatro chumbadores externos simétricos. Geometria Tipo 1: L=d+4a1 e B=a2+2a1; ambas as distâncias entre mesa, linha de chumbadores e borda valem a1.',
            'Ações estáticas já majoradas na face superior da placa de base: N positivo é compressão e N negativo é tração; M atua em torno do eixo de maior inércia. O sinal de M apenas troca o lado tracionado. Cortante no plano de M; sem torção nem flexão biaxial.',
            'Aço dos chumbadores ASTM A36, fy=250 MPa e fu=400 MPa, barras redondas rosqueadas e porcas hexagonais pesadas. A resistência calculada é exclusivamente a ruptura à tração do aço; arruelas especiais em aço fy=345 MPa.',
            'γa1=1,10, γa2=1,35 e γc=1,40; combinações usuais de cálculo. Não se aplicam fatores adicionais às ações informadas.',
            'Concreto de densidade normal, com resistência característica aos 28 dias e 20≤fck≤50 MPa. Não se verifica transferência antes de atingir essa resistência.',
            'Pressão de contato conforme NBR 6.6.5 com A2/A1=1. Não se considera aumento por confinamento do concreto. Argamassa expansiva de assentamento com resistência característica de pelo menos 2fck.',
            'A placa e o pilar são ligados por soldas a dimensionar. A análise não demonstra a rigidez rotacional nem classifica a base como rótula ou engaste.',
            'Dimensionamento da ancoragem no concreto, efeitos de grupo e borda, arrancamento, cone de concreto, armaduras do bloco, flexão/cisalhamento do bloco e sua ligação à fundação devem ser verificados separadamente.',
            'Sem crédito aos chumbadores para transmitir cortante no modo atrito. Um dispositivo externo, quando selecionado, resiste sozinho ao cortante total; sua resistência documentada não é somada ao atrito.',
            'Não se avaliam bases enrijecidas, tubulares, embutidas, chumbadores químicos ou pós-instalados, fadiga, sismo, ações cíclicas, incêndio ou transferência antes da cura do graute.',
        ] + ([
            'Chave de cisalhamento: uma chapa retangular vertical maciça, centrada, de largura bh paralela a B, espessura tpv paralela a L e projeção bv abaixo da placa. V perpendicular à face da chave; sem furos, enrijecedores, torção ou ação biaxial.',
            'V positivo aponta no sentido +x do corte; M positivo é horário, com compressão no lado +x. Com a chave de chapa, eV=tp+(bv+en)/2 e Mef=M+V eV. M e V informados são as ações na face superior, sem incluir previamente essa parcela. A soma algébrica ocorre uma única vez, antes de tomar |Mef|. Transformação estática derivada; a geometria do graute é a efetivamente informada.',
            'Contato local da chave conforme 6.7.2.4: A2/A1=4 e σlug,Rd=1,7fck/γc. Isso não altera A2/A1=1 no contato horizontal da placa de base. A chave resiste ao cortante total, sem soma de atrito.',
            'Soldas da chave: ações prescritas Vw=Vbearing,Rd e Mw=Vbearing,Rd(bv+en)/2, sem limitar pela solicitação V ou pela resistência do aço da chave. Resistência/detalhamento das soldas, metal-base e flexão local da placa na ligação da chave permanecem a complementar.',
            'O atendimento local de contato, flexão e cisalhamento da chave não aprova o dispositivo completo. Ruptura/arrancamento do concreto, efeitos de borda, bloco adequadamente armado conforme NBR 6118 e transferência à fundação requerem memória específica.'
        ] if self.shear_path=='plate' else []) + ([
            'Cortante pelos chumbadores: somente comparação com resistência de cálculo externa documentada do grupo instalado para a combinação atual. Este módulo não calcula resistência ao corte dos chumbadores, interação tração–cisalhamento, efeito de alavanca, esmagamento/flexão local, folgas ou transferência ao concreto. A memória externa deve verificar as barras efetivamente mobilizadas, furos/arruelas/soldas, tração–corte–flexão do aço, concreto (interação, borda, ruptura e pryout), caminho completo sob os esforços combinados e sua excentricidade; não se admite somar automaticamente quatro resistências isoladas; sem soma de atrito ou de chave.'
        ] if self.shear_path=='anchors' else [])

    def to_dict(self):
        return {'schema_version':1,'app_version':VERSION,'connection_type':'base_plate',
                'connection':asdict(self),'fixed_assumptions':self.assumptions}

    @staticmethod
    def from_dict(data,validate_values=True):
        if not isinstance(data,dict) or data.get('connection_type')!='base_plate' or (type(data.get('schema_version')) is not int or data.get('schema_version')!=1):
            raise ValueError('Selecione um projeto de placa de base Tipo 1 desta versão.')
        if not isinstance(data.get('connection'),dict):
            raise ValueError('O arquivo não contém os dados da placa de base.')
        d=dict(data['connection'])
        names={f.name for f in fields(BasePlate)}
        if set(d)-names: raise ValueError('O projeto contém campos não reconhecidos: '+', '.join(sorted(set(d)-names)))
        if not isinstance(d.get('column'),dict): raise ValueError('Seção do pilar ausente ou inválida.')
        try:
            d['column']=Profile(**d['column'])
            c=BasePlate(**d)
        except (TypeError,KeyError) as exc:
            raise ValueError('Dados incompletos ou incompatíveis com a placa de base.') from exc
        issues=validate(c) if validate_values else []
        if any(i.severity=='error' for i in issues):
            raise ValueError('; '.join(i.text for i in issues if i.severity=='error'))
        return c

@dataclass
class BasePlateResult(Result):
    @property
    def component_status(self):
        if any(i.severity=='error' for i in self.issues): return 'DADOS OU GEOMETRIA INVÁLIDOS'
        if any(i.severity=='model' for i in self.issues): return 'EQUILÍBRIO NÃO DEMONSTRADO'
        if any(not x.passed for x in self.checks): return 'NÃO ATENDE ÀS VERIFICAÇÕES REALIZADAS'
        if any(i.severity=='noncompliance' for i in self.issues): return 'NÃO ATENDE AO DETALHAMENTO'
        if any(i.severity=='pending' and i.origin=='data' for i in self.issues): return 'VERIFICAÇÃO DO CORTANTE COM DADOS PENDENTES'
        if not self.checks: return 'SEM VERIFICAÇÕES'
        return 'ATENDE ÀS VERIFICAÇÕES REALIZADAS'

    @property
    def status(self):
        # Não converte um conjunto parcial de verificações em aprovação da base.
        if self.component_status!='ATENDE ÀS VERIFICAÇÕES REALIZADAS': return self.component_status
        return 'COMPONENTES CALCULADOS ATENDEM · BASE COM VERIFICAÇÕES A COMPLEMENTAR'

    @property
    def calculation_note(self):
        return 'Resultado local da chapa, do contato e do aço dos chumbadores. Ancoragem no concreto, bloco armado e soldas do pilar não têm resistência calculada neste módulo.'


def validate(c):
    issues=[]
    def issue(severity,text,ref='Dados da placa de base'): issues.append(Issue(severity,text,ref))
    if not isinstance(c.column,Profile):
        issue('error','Selecione uma seção I/H válida.'); return issues
    positive=('tp','db','a1','a2','fck','grout_fck','grout_t','lug_bh','lug_bv','lug_t')
    numeric=positive+('N','M','V','external_shear_rd','anchor_shear_rd')
    for key in numeric:
        value=getattr(c,key)
        if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value):
            issue('error',f'{key}: informe um número real finito.')
        elif key in positive and value<=0:
            issue('error',f'{key}: o valor deve ser positivo.')
    for key in ('d','bf','tw','tf','clear','area'):
        value=getattr(c.column,key)
        if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or value<=0:
            issue('error','Seção do pilar: '+key+' deve ser positivo e finito.')
    for key in ('project','plate_steel','shear_path','external_shear_ref','notes','lug_steel','external_shape','anchor_shear_ref','anchor_shear_confirmation'):
        if not isinstance(getattr(c,key),str): issue('error',key+': texto inválido.')
    if issues: return issues
    if not 20<=c.fck<=50:
        issue('error','O modelo NBR adotado abrange concreto de densidade normal com 20 ≤ fck ≤ 50 MPa. Outros concretos precisam de método específico.',NBR+', 4.6.3.1')
    if c.plate_steel not in STEELS or not STEELS[c.plate_steel].plate_allowed:
        issue('error','Aço da placa não reconhecido ou não aplicável a chapas.'); return issues
    if c.shear_path not in ('friction','external','plate','anchors'): issue('error','Selecione o caminho resistente do cortante.')
    if c.lug_steel not in STEELS or not STEELS[c.lug_steel].plate_allowed:
        issue('error','Aço da chave não reconhecido ou não aplicável a chapas.')
    if c.external_shape not in EXTERNAL_SHAPES:
        issue('error','Descrição do dispositivo externo não reconhecida.')
    if c.shear_path=='plate':
        if c.lug_bv<=c.grout_t:
            issue('error','A projeção bv da chave deve superar a espessura real en do graute para haver contato com o concreto.',NBR+', 6.7.2.4')
        if c.lug_bh>c.B or c.lug_t>c.L:
            issue('error','A chave centrada deve caber sob a placa: bh ≤ B e tpv ≤ L.')
    if c.anchor_shear_rd<0: issue('error','A resistência documentada dos chumbadores ao cortante não pode ser negativa.')
    if c.external_shear_rd<0: issue('error','A resistência externa ao cortante não pode ser negativa.')
    if not any(math.isclose(c.db,v,abs_tol=1e-8) for v in ANCHORS.values()):
        issue('error','Diâmetro de chumbador fora da série imperial da Tabela 18. Selecione um diâmetro entre 3/4 e 2 polegadas.',NBR+', tabela 18')
    p=c.column
    if any(not isinstance(getattr(p,k),str) for k in ('name','family','source')):
        issue('error','Designação, família e referência do pilar devem ser textos.'); return issues
    try:
        scale_values=(c.L,c.B,c.a,c.L*c.B,c.a*c.a,p.d*p.bf,
                      (abs(c.effective_moment)+abs(c.N)*c.a)/(c.sigma_rd*c.B),
                      c.m*c.m,c.n*c.n)
        if c.shear_path=='plate' and not any(i.severity=='error' for i in issues):
            scale_values+=tuple(shear_plate_actions(c).values())
        if not all(math.isfinite(v) for v in scale_values): raise OverflowError
    except (OverflowError,ZeroDivisionError):
        issue('error','A escala numérica informada excede a precisão do cálculo. Confira unidades e ordens de grandeza; nenhum resultado resistente foi calculado.'); return issues
    if p.d<=2*p.tf or p.bf<=p.tw or p.clear>p.d-2*p.tf+1e-8:
        issue('error','Geometria da seção I/H inconsistente.')
    if c.B<p.bf+25-1e-8:
        issue('noncompliance',f'Largura B={c.B:g} mm menor que bf+25={p.bf+25:g} mm. Aumente o espaçamento a2.',NBR+', 6.7.2.1')
    steel=STEELS[c.plate_steel]
    if not steel.plate_min<=c.tp<=steel.plate_max:
        issue('noncompliance','Espessura da placa fora da faixa do produto de aço selecionado.',steel.source)
    if c.shear_path=='plate' and c.lug_steel in STEELS:
        lug_steel=STEELS[c.lug_steel]
        if not lug_steel.plate_min<=c.lug_t<=lug_steel.plate_max:
            issue('noncompliance','Espessura da chave fora da faixa do produto de aço selecionado.',lug_steel.source)
    if any(i.severity=='error' for i in issues): return issues
    ref=detail_reference(c)
    if c.a1<=ref['df']/2 or c.a2<=ref['df']:
        issue('error','Os furos precisam estar inteiros na placa e separados entre si. Aumente a1/a2.',NBR+', tabela 18 e geometria')
    if c.a1<ref['washer_side']/2:
        issue('interference','A arruela especial interfere com o perfil ou ultrapassa a placa; ajustar o detalhe sem reduzir o caminho resistente.',NBR+', tabela 18')
    if not ref['matches_spacing']:
        issue('info','Geometria distinta do detalhamento tabulado: a1/a2 diferem da Tabela 18. As forças e a placa são calculadas nas dimensões informadas; ancoragem e detalhamento exigem verificação específica.',NBR+', 6.7.1.1 e tabela 18 corrigida')
    if c.fck<ref['fck_min']:
        issue('noncompliance',f'fck={c.fck:g} MPa abaixo de fck,min={ref["fck_min"]:g} MPa da Tabela 18 para a porca de ancoragem.',NBR+', tabela 18 corrigida, nota b)')
    if c.grout_fck<2*c.fck:
        issue('noncompliance','Argamassa expansiva: fck,graute deve ser pelo menos 2fck do bloco. Atualize o material de assentamento.',NBR+', 6.7.1.5 d)')
    return issues


def _contact_length(H,q,term):
    """Raiz menor racionalizada: preserva precisão em pequenas excentricidades.

    D=H²−2term/q. Não recorta radicando negativo: a ligação precisa mudar.
    """
    D=H*H-2*term/q
    if D<0: raise ValueError('Radicando negativo na equação de contato. Aumente a base ou a resistência do concreto e recalcule.')
    return (2*term/q)/(H+math.sqrt(D)) if term else 0.,D


def reactions(c):
    """Equilíbrio N–M da NBR 6.7.2.2; não calcula ancoragem no concreto."""
    N=c.N;M=abs(c.effective_moment);P=max(N,0.);U=max(-N,0.);B=c.B;L=c.L;a=c.a
    q=c.sigma_rd*B;H=L/2+a
    out={'case':'SEM N/M','e':None,'ecrit':None,'lc':0.,'sigma':0.,'C':0.,
         'T_total':0.,'Ft_max':0.,'Ft_min':0.,'X':0.,'lambda':0.,'D':None,
         't_contact':0.,'t_tension':0.,'t_required':0.,'db_required':0.,
         'lmax':0.,'m':c.m,'n':c.n,'n0':c.n0,'moment_sign':1 if c.effective_moment>=0 else -1,
         'M_input':c.M,'delta_M':c.V*c.shear_eccentricity,'M_effective':c.effective_moment,'eV':c.shear_eccentricity,
         'L':L,'B':B,'a':a,'sigma_rd':c.sigma_rd,'tau_rd':c.tau_rd}
    out.update(C_x=0.,T_max_x=-out['moment_sign']*a,T_min_x=out['moment_sign']*a,residual_N=0.,residual_M=0.)
    if N==0 and M==0: return out
    if P>c.sigma_rd*L*B:
        raise ValueError('Compressão N > σRd L B: nem toda a área da placa sustenta a compressão informada. Aumente a base ou a resistência do concreto.')
    X=4*c.column.d*c.column.bf/(c.column.d+c.column.bf)**2*P/(L*B*c.sigma_rd)
    out['X']=X
    if X>1: raise ValueError('X > 1 no domínio corrigido da NBR 6.7.2.1. Aumente a base ou a resistência do concreto; não se calcula √(1−X).')
    lam=min(1.,2*math.sqrt(X)/(1+math.sqrt(1-X)))
    out['lambda']=lam
    if P:
        e=M/P;ecrit=.5*(L-P/q);out.update(e=e,ecrit=ecrit)
        if M==0:
            case='C1';lc=L;C=P;sigma=P/(B*lc);Ft=Fmin=0.
        elif e<=ecrit:
            case='C2';lc=L-2*e;C=P;sigma=P/(B*lc);Ft=Fmin=0.
        else:
            case='C3';lc,D=_contact_length(H,q,M+P*a);out['D']=D
            C=q*lc;sigma=c.sigma_rd;Ft=2*(C-P)/c.count;Fmin=0.
    elif U and M<=U*a:
        case='T1' if M==0 else 'T2';lc=0.;C=sigma=0.
        Ft=U/c.count+M/(a*c.count);Fmin=U/c.count-M/(a*c.count);out['e']=M/U
    else:
        case='T3' if U else 'M0';lc,D=_contact_length(H,q,M-U*a);out['D']=D
        C=q*lc;sigma=c.sigma_rd;Ft=2*(C+U)/c.count;Fmin=0.
        if U: out['e']=M/U
    if lc<0 or lc>L+1e-8 or Ft<-1e-7 or Fmin<-1e-7:
        raise ValueError('A solução não produz uma faixa de contato e trações fisicamente admissíveis. Reveja geometria e ações.')
    Ft=max(Ft,0.);Fmin=max(Fmin,0.)
    # Para C1/C2 a pressão real governa; C3/T3 usam a pressão resistente.
    lmax=0.;tcomp=0.
    if lc>0:
        if lc>=c.m:
            candidates=[c.m,c.n]
            if case in ('C1','C2','C3'): candidates.append(lam*c.n0)
            lmax=max(candidates)
        else:
            lmax=max(math.sqrt(lc*(2*c.m-lc)),c.n)
        tcomp=lmax*math.sqrt(2*sigma/(c.fy/G1))
    ttension=math.sqrt(2*c.count*Ft*(c.m-c.a1)/(B*(c.fy/G1))) if Ft else 0.
    dbmin=math.sqrt(4*Ft/(.75*math.pi*(400/G2))) if Ft else 0.
    Ttotal=2*(Ft+Fmin)
    out.update(case=case,lc=lc,C=C,sigma=sigma,T_total=Ttotal,Ft_max=Ft,Ft_min=Fmin,
               t_contact=tcomp,t_tension=ttension,t_required=max(tcomp,ttension),
               db_required=dbmin,lmax=lmax)
    # Forças/posições para um desenho orientado e para auditoria de equilíbrio.
    sign=out['moment_sign']
    out['C_x']=sign*(L/2-lc/2) if C else 0.
    out['T_max_x']=-sign*a
    out['T_min_x']=sign*a
    out['residual_N']=C-Ttotal-N
    out['residual_M']=C*out['C_x']-2*Ft*out['T_max_x']-2*Fmin*out['T_min_x']-c.effective_moment
    return out


def shear_plate_actions(c):
    """NBR 6.7.2.4: ações/resistências locais da chapa, não do dispositivo completo.

    N, mm e MPa. Somente geometria validada; bh paralelo a B e V paralelo a L.
    As ações das soldas são prescritas pela resistência de contato do concreto.
    """
    sigma=1.7*c.fck/GC
    area=c.lug_bh*(c.lug_bv-c.grout_t)
    bearing=sigma*area
    denom=c.lug_bh*(c.lug_fy/G1)
    return dict(sigma_rd=sigma,contact_area=area,bearing_rd=bearing,
                t_required=math.sqrt(2*abs(c.V)*(c.lug_bv+c.grout_t)/denom),
                bending_rd=denom*c.lug_t**2/(2*(c.lug_bv+c.grout_t)),
                yield_rd=.60*c.lug_fy*c.lug_bh*c.lug_t/G1,
                rupture_rd=.60*c.lug_fu*c.lug_bh*c.lug_t/G2,
                weld_V=bearing,weld_M=bearing*(c.lug_bv+c.grout_t)/2)


def _add_shear_plate_checks(c,r,add):
    lug=shear_plate_actions(c)
    add('lug_contact','Chave de chapa — contato local no concreto',abs(c.V),lug['bearing_rd'],'N',
        NBR+', 6.7.2.4 e 6.6.5','Vbearing,Rd = (1,7 fck/γc) bh (bv−en); A2/A1=4',
        f'σlug,Rd={lug["sigma_rd"]:.6f}; bh={c.lug_bh:g}; bv={c.lug_bv:g}; en={c.grout_t:g}; Vbearing,Rd={lug["bearing_rd"]:.5f}',
        'Cortante total |V|, sem somar atrito. Contato local não verifica ruptura do bloco nem efeitos de borda.')
    add('lug_bending','Chave de chapa — flexão local',lug['t_required'],c.lug_t,'mm',
        NBR+', 6.7.2.4','tpv,min = √[2 |VSd| (bv+en)/(bh (fy/γa1))]',
        f'|VSd|={abs(c.V):.5f}; bv+en={c.lug_bv+c.grout_t:g}; bh={c.lug_bh:g}; fy={c.lug_fy:g}; tpv,min={lug["t_required"]:.6f}; tpv={c.lug_t:g}',
        'Flexão da própria chave; não é a flexão local da placa de base na ligação da chave.')
    add('lug_thickness','Chave de chapa — relação com a placa de base',c.lug_t,c.tp,'mm',
        NBR+', 6.7.2.4','tpv ≤ tp',f'tpv={c.lug_t:g}; tp={c.tp:g}',
        'A espessura da chave não pode exceder a da placa de base neste modelo; as entradas não são corrigidas.')
    for tag,title,fy,g,rd in [('yield','escoamento por cisalhamento',c.lug_fy,G1,lug['yield_rd']),
                             ('rupture','ruptura por cisalhamento',c.lug_fu,G2,lug['rupture_rd'])]:
        add('lug_'+tag,'Chave de chapa — '+title,abs(c.V),rd,'N',NBR+', 6.5.5 a) e b)',
            'VRd = 0,60 fy Ag/γa1' if tag=='yield' else 'VRd = 0,60 fu Anv/γa2',
            f'f={fy:g}; Ag=Anv=bh tpv={c.lug_bh*c.lug_t:g}; γ={g:g}; VRd={rd:.5f}',
            'Chapa retangular maciça sem furos; não abrange a transferência de tensões ao metal-base na solda.')
    r.issues.append(Issue('pending','Chave de chapa: soldas (resistência e detalhamento), metal-base e flexão local da placa na ligação da chave a complementar. Ações prescritas das soldas são calculadas à resistência de contato do concreto, mesmo quando maiores que o cortante aplicado.',NBR+', 6.7.2.4 e 6.2.5.1, tabela 9'))
    r.issues.append(Issue('pending','Chave de chapa: ruptura/arrancamento do concreto, efeitos de borda e bloco adequadamente armado a dimensionar conforme NBR 6118. Atendimento local não aprova o dispositivo completo.',NBR+', 6.7.2.4'))
    return lug


def evaluate(c):
    r=BasePlateResult(issues=validate(c))
    if any(i.severity=='error' for i in r.issues): return r
    def add(i,name,sd,rd,unit,ref,eq,sub,var):
        r.checks.append(Check('bp_'+i,name,sd,rd,unit,ref,eq,sub,var))
    # As verificações de dados/condições permanecem visíveis, mesmo sem equilíbrio.
    add('grout','Argamassa expansiva — resistência mínima',2*c.fck,c.grout_fck,'MPa',
        NBR+', 6.7.1.5 d)','fck,graute ≥ 2fck',f'2 × {c.fck:g} = {2*c.fck:g} ≤ {c.grout_fck:g}',
        'Resistências características à compressão, em MPa.')
    add('width','Geometria Tipo 1 — largura mínima',c.column.bf+25,c.B,'mm',
        NBR+', 6.7.2.1','B = a2 + 2a1 ≥ bf + 25',f'B={c.B:g}; bf+25={c.column.bf+25:g}',
        'B: largura transversal; a2: passo entre chumbadores; a1: folga e borda.')
    lug=_add_shear_plate_checks(c,r,add) if c.shear_path=='plate' else None
    try:
        a=reactions(c)
    except ValueError as exc:
        r.issues.append(Issue('model',str(exc),NBR+', 6.7.2.1 e 6.7.2.2'))
        r.issues.append(Issue('pending',r.calculation_note,NBR+', 6.7.1.3'))
        return r
    r.geometry=a
    if lug is not None:a['lug']=lug
    case=a['case'];a['friction_rd']=min(MU*a['C']/G2,c.tau_rd*c.L*c.B)
    if case=='M0':
        r.issues.append(Issue('info','Momento puro: limite de equilíbrio estático C3/T3 com N=0, sem usar e=M/N. A expressão é derivada e não é um caso separado enumerado pela NBR.',NBR+', 6.7.2.2; limite estático do modelo'))
    if a['C']:
        add('contact','Concreto — pressão de contato',a['sigma'],c.sigma_rd,'MPa',
            NBR+', 6.6.5 e 6.7.2.2',
            'σRd = 0,85 fck/γc; A2/A1 = 1; σSd = C/(B lc)',
            f'C={a["C"]:.4f}; B={c.B:g}; lc={a["lc"]:.5f}; σSd={a["sigma"]:.6f}; σRd={c.sigma_rd:.6f}',
            'C: resultante comprimida, N; lc: comprimento de contato, mm; sem ganho por confinamento.')
        add('plate_contact','Placa — flexão sob o contato',a['t_contact'],c.tp,'mm',
            NBR+', 6.7.2.1 e 6.7.2.2',
            'tmin,c = lmax √[2σSd/(fy/γa1)]',
            f'caso={case}; m={c.m:.5f}; n={c.n:.5f}; n0={c.n0:.5f}; X={a["X"]:.7f}; λ={a["lambda"]:.7f}; lmax={a["lmax"]:.5f}; tmin,c={a["t_contact"]:.5f}',
            'lmax conforme o caso e a extensão de contato; γa1=1,10. X≤1 sem extrapolar a raiz da equação corrigida.')
    if a['Ft_max']:
        add('plate_tension','Placa — flexão junto aos chumbadores',a['t_tension'],c.tp,'mm',
            NBR+', 6.7.2.2 c) a f)',
            'tmin,t = √[2 nb Ft,Sd (m−a1)/(B fy/γa1)]',
            f'nb=4; Ft,Sd={a["Ft_max"]:.5f}; m−a1={c.m-c.a1:.5f}; B={c.B:g}; fy={c.fy:g}; tmin,t={a["t_tension"]:.5f}',
            'Ft,Sd é a maior tração por chumbador; nb=4. Em T2 a força da outra linha é menor.')
        add('anchor_steel','Chumbador ASTM A36 — ruptura do aço à tração',a['Ft_max'],c.anchor_steel_rd,'N',
            NBR+', 6.7.2.2 c) a f)',
            'Ft,Rd = 0,75 (π db²/4) fu/γa2',
            f'db={c.db:g}; fu=400; γa2={G2:g}; Ft,Rd={c.anchor_steel_rd:.5f}; db,min={a["db_required"]:.5f}',
            'Resistência do aço da barra rosqueada, não da ancoragem no concreto. Não se atribui resistência por nome comercial.')
    if c.shear_path=='friction':
        a['shear_rd']=a['friction_rd']
        if a['shear_rd']>0:
            add('shear','Deslizamento — atrito no graute',abs(c.V),a['shear_rd'],'N',
                NBR+', 6.7.2.2 e 6.7.2.3',
                'VRd = min(0,45 C/γa2; τRd L B); τRd = min(0,2 fck/γc; 4 MPa)',
                f'C={a["C"]:.5f}; 0,45C/γa2={MU*a["C"]/G2:.5f}; τRd={c.tau_rd:.6f}; VRd={a["shear_rd"]:.5f}',
                'Contato com argamassa expansiva; chumbadores sem crédito resistente ao corte.')
        elif abs(c.V)>0:
            r.issues.append(Issue('noncompliance','Há cortante e não há compressão de contato para mobilizar atrito. Selecione um dispositivo de cisalhamento com resistência documentada.',NBR+', 6.7.2.3'))
        if abs(c.V)>a['shear_rd']+1e-8 and a['shear_rd']>0:
            r.issues.append(Issue('noncompliance','O cortante supera o atrito resistente. Um dispositivo deve resistir ao cortante total, sem somar atrito.',NBR+', 6.7.2.3'))
    elif c.shear_path=='anchors':
        a['shear_rd']=c.anchor_shear_rd
        if c.anchor_shear_rd<=0 or not c.anchor_shear_ref.strip() or not c.anchor_capacity_confirmed:
            r.issues.append(Issue('pending','Cortante pelos chumbadores: informe VRd externo positivo do grupo instalado, referência da memória e confirme sua aplicação ao detalhe e à combinação atual N–M–V. Alterar esses dados invalida a confirmação, sem bloquear os demais cálculos.',NBR+', 6.7.1.3',origin='data'))
        else:
            add('shear_anchors_external','Chumbadores — comparação documental de cortante',abs(c.V),c.anchor_shear_rd,'N',
                'Resistência externa informada: '+c.anchor_shear_ref,'|VSd| ≤ VRd,conjunto documentado; sem soma de atrito/chave',
                f'|VSd|={abs(c.V):.5f}; VRd,conjunto={c.anchor_shear_rd:.5f}',
                'Somente comparação com memória externa; não calcula resistência ao corte dos chumbadores nem interação com a tração calculada.')
        r.issues.append(Issue('pending','Chumbadores ao cortante: resistência ao corte, interação tração–cisalhamento, flexão/esmagamento local, efeito de alavanca e transferência ao concreto não verificados pelo app. A memória externa deve cobrir o conjunto e a excentricidade da reação.',NBR+', 6.7.1.3'))
    elif c.shear_path=='external':
        a['shear_rd']=c.external_shear_rd
        if c.external_shear_rd<=0 or not c.external_shear_ref.strip():
            r.issues.append(Issue('pending','Dispositivo externo: informe resistência de cálculo positiva e referência da memória que verifica o dispositivo, suas soldas e a transferência ao bloco.',NBR+', 6.7.2.3',origin='data'))
        else:
            add('shear_external','Cortante — comparação com dispositivo externo',abs(c.V),c.external_shear_rd,'N',
                'Resistência informada: '+c.external_shear_ref,
                '|VSd| ≤ VRd,dispositivo; sem somar atrito',
                f'|VSd|={abs(c.V):.5f}; VRd,dispositivo={c.external_shear_rd:.5f}',
                'Comparação documental; '+EXTERNAL_SHAPES[c.external_shape]+'. O módulo não dimensiona nem valida a memória externa, inclusive a excentricidade da reação e seus efeitos na base.')
    r.issues.append(Issue('pending',r.calculation_note,NBR+', 6.7.1.3 e tabela 18'))
    r.actual=list(r.checks)
    return r


def presets():
    """Exemplos verificáveis; ações didáticas, não extraídas de um projeto real."""
    from dataclasses import replace
    catalog=profiles()
    p=next((v for k,v in catalog.items() if k.startswith('W 250') or k.startswith('W250')),next(iter(catalog.values())))
    c=BasePlate(p,a2=max(80.,p.bf+25-80),project='Exemplo didático C1 — compressão centrada')
    return {
        'Chumbadores · resistência externa':replace(c,shear_path='anchors',project='Nova base — cortante pelos chumbadores'),
        'C1 · compressão centrada':c,
        'C2 · pequena excentricidade':replace(c,N=150000.,M=6e6,project='Exemplo didático C2 — contato sem tração'),
        'C3 · compressão e momento':replace(c,N=150000.,M=40e6,tp=31.75,project='Exemplo didático C3 — contato e tração'),
        'T1 · tração centrada':replace(c,N=-80000.,M=0.,tp=25.4,project='Exemplo didático T1 — tração centrada'),
        'T2 · tração e pequeno momento':replace(c,N=-80000.,M=5e6,tp=25.4,project='Exemplo didático T2 — duas linhas tracionadas'),
        'T3 · tração e grande momento':replace(c,N=-80000.,M=30e6,tp=38.1,project='Exemplo didático T3 — contato e tração'),
        'Chave retangular · cortante puro':replace(c,N=0.,M=0.,V=100000.,tp=50.8,fck=20.,
            shear_path='plate',lug_bh=100.,lug_bv=100.,lug_t=50.8,grout_t=40.,
            project='Exemplo didático — chave retangular com verificações locais'),
    }
