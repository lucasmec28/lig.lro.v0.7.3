"""Native 1L, 2L-T and opposed 2L/gusset UI with distinct strict engines.

The accepted native payload is the source of truth. Unit controls retain the
exact imported scalar until the user edits that control. Rejected imports are
staged and never replace accepted widgets, drafts, results or report bytes.
"""
from .display_precision import display_format, display_frame, display_tree, display_value, number_input
from copy import deepcopy
import hashlib
import json
import math

import pandas as pd
import streamlit as st
from .load_conventions import render as render_load_convention

from .report import BRAND, LINK

PREFIX = 'bag_'
PROJECT = '_bolted_angle_gusset_project'
DRAFT = '_bolted_angle_gusset_ui_draft'
RESULT = '_bolted_angle_gusset_result'
ACCEPTED = '_bolted_angle_gusset_accepted_values'
TEMPLATE = '_bolted_angle_gusset_native_template'
REPORT = 'bag_report'
# Separate complete-route state; no legacy axial or welded keys are reused.


def _finite(value):
    try:
        return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)
    except (OverflowError, ValueError):
        return False


def _number(value, field):
    if not _finite(value) or float(value) != value:
        raise ValueError(f'{display_value(field)}: número finito, representável sem perda, obrigatório.')
    return float(value)


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f'Chave JSON duplicada: {display_value(key)}.')
        result[key] = value
    return result


def _json_load(payload):
    if len(payload) > 200000:
        raise ValueError('Arquivo maior que 200 kB.')
    def reject_constant(value):
        raise ValueError('Número JSON inválido: ' + value)
    return json.loads(payload, object_pairs_hook=_unique_object, parse_constant=reject_constant)


def _walk(value, path=()):
    if isinstance(value, dict):
        for key, item in value.items():
            yield from _walk(item, (*path, key))
    elif isinstance(value, (list, tuple)):
        for index, item in enumerate(value):
            yield from _walk(item, (*path, index))
    else:
        yield path, value


def _set_path(value, path, replacement):
    for part in path[:-1]:
        value = value[part]
    value[path[-1]] = replacement


def _factor(path):
    if path[-1] in ('N', 'V', 'V_out', 'out_of_plane_V', 'minor_V', 'weak_V', 'transverse_V'):
        return 1000.
    if path[-1] in ('M', 'M_applied', 'M_out', 'out_of_plane_M', 'torsion', 'T', 'minor_M', 'weak_M'):
        return 1000000.
    return 1.


def _key(path):
    suffix = '_kN' if _factor(path) == 1000. else '_kNm' if _factor(path) == 1000000. else ''
    return PREFIX + '_'.join(map(str, path)) + suffix


def import_ui_values(c):
    """Return all proposed widgets/accepted values before any state mutation."""
    native = c.to_dict()
    proposed, accepted = {}, {}
    for path, raw in _walk(native['connection']):
        display = raw
        if type(raw) in (int, float):
            display = _number(raw, '.'.join(map(str, path))) / _factor(path)
            if raw != 0 and display == 0:
                raise ValueError('.'.join(map(str, path)) + ': conversão de unidade não representável sem perda.')
        proposed[_key(path)] = display
        accepted[path] = {'raw': raw, 'display': display}
    proposed[ACCEPTED] = accepted
    proposed[TEMPLATE] = deepcopy(native)
    return proposed


def _connection_class(arrangement=None, connection_type=None):
    if arrangement == '2L-opposed' or connection_type == 'bolted_opposed_angle_gusset':
        from .bolted_opposed_angle_gusset import BoltedOpposedAngleGusset
        return BoltedOpposedAngleGusset
    from .bolted_angle_gusset import BoltedAngleGusset
    return BoltedAngleGusset


def _all_presets():
    from .bolted_angle_gusset import presets
    from .bolted_opposed_angle_gusset import presets as opposed_presets
    return {**presets(), **opposed_presets()}


def decode_project(payload):
    native = _json_load(payload)
    if not isinstance(native, dict):
        raise ValueError('Objeto JSON nativo obrigatório.')
    c = _connection_class(connection_type=native.get('connection_type')).from_dict(native)
    import_ui_values(c)
    return c


def seed(c):
    proposed = import_ui_values(c)
    st.session_state.update(proposed)
    st.session_state.pop('bag_arrangement_notice',None)
    st.session_state.pop('bag_arrangement_error',None)
    st.session_state.pop(REPORT, None)
    st.session_state.pop(DRAFT, None)


def _current_native(*, explicit_arrangement_change=False):
    """Rebuild every native field, keeping accepted force bits until edited."""
    s = st.session_state
    native = deepcopy(s[TEMPLATE])
    for path, original in _walk(native['connection']):
        shown = s[_key(path)]
        accepted = s[ACCEPTED][path]
        if shown == accepted['display'] and type(shown) is type(accepted['display']):
            raw = accepted['raw']
        elif path[-1] == 'heel_extent' and shown is None:
            raw = None
        elif type(original) in (int, float):
            _number(shown, '.'.join(map(str, path)))
            raw = shown * _factor(path)
            if not _finite(raw):
                raise ArithmeticError('.'.join(map(str, path)) + ': conversão excede a faixa numérica finita.')
            if type(original) is int and _factor(path) == 1:
                if int(raw) != raw:
                    raise ValueError('.'.join(map(str, path)) + ': inteiro obrigatório.')
                raw = int(raw)
        else:
            raw = shown
        _set_path(native['connection'], path, raw)
    cls = _connection_class(arrangement=native['connection'].get('arrangement'))
    if explicit_arrangement_change and native['connection'].get('arrangement')=='2L-opposed':
        # Only this deliberate UI transition drops controls absent from the
        # opposed model. Strict native imports never use this conversion.
        from .gusset_outer_end import BOLTED_FIELDS
        for key in BOLTED_FIELDS:native['connection'].pop(key,None)
    native['fixed_assumptions'] = cls(**native['connection']).fixed_assumptions
    return native


def _save_draft():
    s = st.session_state
    keys = [_key(path) for path, _ in _walk(s[TEMPLATE]['connection'])]
    keys += [ACCEPTED, TEMPLATE, 'bag_report_detailed', 'bag_include_small_angles']
    s[DRAFT] = {key: deepcopy(s[key]) for key in keys if key in s}


def change_arrangement():
    # Deliberate UI change creates the selected family's native identity.
    # Imports still require an exact identity and never use this conversion.
    s=st.session_state;previous=s[TEMPLATE]['connection']['arrangement']
    was_cut=s.get('bag_gusset_end_shape')=='normal_cut'
    try:
        native = _current_native(explicit_arrangement_change=True)
        cls = _connection_class(arrangement=native['connection']['arrangement'])
        # seed stages strict serialization/widget values before mutating state.
        seed(cls(**native['connection']))
    except (ValueError,TypeError,KeyError,ArithmeticError) as exc:
        s['bag_arrangement']=previous
        s.pop(REPORT,None)
        s.pop('bag_arrangement_notice',None)
        s['bag_arrangement_error']='Alteração de arranjo não aplicada; mantido o arranjo anterior, sem ajustar valores: '+str(exc)
        return
    if native['connection']['arrangement']=='2L-opposed' and was_cut:
        s['bag_arrangement_notice']='Arranjo 2L opostas selecionado: esta rota usa o contorno retangular original. O corte externo anterior foi desativado; resultados e memória são recalculados para o novo arranjo.'
    else:s.pop('bag_arrangement_notice',None)


def use_example():
    seed(_all_presets()[st.session_state.bag_example])


def load_project():
    try:
        upload = st.session_state.bag_upload
        if upload is None:
            raise ValueError('Selecione um arquivo JSON.')
        candidate = decode_project(upload.getvalue())
        seed(candidate)
        st.session_state.pop('bag_import_error', None)
    except (ValueError, TypeError, KeyError, OverflowError, UnicodeError) as exc:
        st.session_state.bag_import_error = 'Não foi possível abrir: ' + str(exc)


def _display(value):
    return f"{display_format(value, '.3f')}" if _finite(value) else '—'


def _select(label, options, path, labels=None):
    key = _key(path)
    options = list(options)
    current = st.session_state[key]
    if current not in options:
        options.append(current)
    return st.selectbox(label, options, key=key,
                        on_change=change_arrangement if path == ('arrangement',) else None,
                        format_func=(lambda value: labels.get(value, str(value) + ' · importado')) if labels else str)


def _scalar(path, label=None, options=None, labels=None):
    key = _key(path)
    value = st.session_state[key]
    label = label or str(path[-1])
    if options is not None:
        return _select(label, options, path, labels)
    if path[-1] == 'heel_extent':
        return number_input(label, key=key, value=None, format='%.2f', placeholder='Não informado: montagem pendente')
    if type(value) is bool:
        return st.checkbox(label, key=key)
    if type(value) in (int, float):
        return number_input(label, key=key, format='%.2f')
    return st.text_input(label, key=key)


def _fail(exc):
    s = st.session_state
    s.pop(REPORT, None)
    s.pop(PROJECT, None)
    if TEMPLATE in s:
        _save_draft()
    status = 'NUMERICAL_FAILURE' if isinstance(exc, ArithmeticError) else 'INVALID_INPUT'
    s[RESULT] = {'status': status, 'global_pass': False, 'checks': [],
                 'geometry': {'valid': False}, 'summary': {'complete_checks': False},
                 'issues': [{'id': 'ui_input', 'severity': 'error', 'message': str(exc)}]}
    st.error('FALHA NUMÉRICA · CÁLCULO NÃO CONCLUÍDO' if status == 'NUMERICAL_FAILURE' else 'DADOS INVÁLIDOS')
    st.error(str(exc))
    st.caption('Nenhum resultado ou arquivo anterior é válido para a edição atual. Corrija os dados para recalcular.')
    st.button('Gerar memória completa parafusada', disabled=True)


def render():
    try:
        _render()
    except (ArithmeticError, ValueError, TypeError, KeyError) as exc:
        _fail(exc)

STATUS = {
    'INVALID_INPUT': 'DADOS INVÁLIDOS', 'INVALID_GEOMETRY': 'GEOMETRIA FISICAMENTE INVÁLIDA',
    'NUMERICAL_FAILURE': 'FALHA NUMÉRICA · CÁLCULO NÃO CONCLUÍDO',
    'OUTSIDE_SCOPE': 'FORA DO DOMÍNIO DA LIGAÇÃO COMPLETA PARAFUSADA',
    'DETAILING_PENDING': 'MONTAGEM PENDENTE · GEOMETRIA REAL NECESSÁRIA', 'NOT_VERIFIED': 'NÃO VERIFICADO · MONTAGEM OU CONDIÇÕES PENDENTES',
    'DETAIL_FAIL': 'NÃO ATENDE AO DETALHAMENTO', 'DETAILING_FAIL': 'NÃO ATENDE AO DETALHAMENTO',
    'LOCAL_CHECKS_FAIL': 'NÃO ATENDE ÀS VERIFICAÇÕES LOCAIS',
    'COMPLETE_CHECKS_FAIL': 'NÃO ATENDE ÀS VERIFICAÇÕES LOCAIS',
    'VERIFIED_SUBCHECK_FAIL': 'NÃO ATENDE ÀS VERIFICAÇÕES LOCAIS',
    'LOCAL_CHECKS_PASS_WITHIN_SCOPE': 'ATENDE ÀS VERIFICAÇÕES LOCAIS NO DOMÍNIO',
    'COMPLETE_LOCAL_CHECKS_PASS_WITHIN_SCOPE': 'ATENDE ÀS VERIFICAÇÕES LOCAIS NO DOMÍNIO',
    'COMPLETE_CHECKS_PASS_WITHIN_SCOPE': 'ATENDE ÀS VERIFICAÇÕES LOCAIS NO DOMÍNIO',
    'INCOMPLETE_CHECKS': 'VERIFICAÇÕES INCOMPLETAS',
}
SCOPE_TEXT = ('Rota completa: cantoneira → furos e parafusos → chapa de nó única → dois filetes da raiz → mesa exterior de W. '
              '1L: uma cantoneira e um plano de corte por parafuso. 2L-T: duas L idênticas em faces opostas, talões alinhados e '
              'abas conectadas no mesmo sentido; cada parafuso atravessa L–chapa–L, com dois planos físicos de corte. '
              '2L opostas ><: duas linhas distintas, uma por L, 2n parafusos físicos e um plano por parafuso. '
              'N é a força total da ligação. Chapa, raiz e W recebem N integral nos três arranjos. Tração estática, '
              'furos normais e contato direto; raiz longitudinal centrada na alma do W.')
LABELS = {
    'project': 'Identificação do projeto', 'arrangement': 'Arranjo físico da ligação',
    'support_member': 'Membro de apoio', 'support_face': 'Face receptora',
    'angle_profile': 'Seção de uma cantoneira', 'support_profile': 'Perfil W receptor',
    'angle_steel': 'Aço da cantoneira / comum às duas L', 'gusset_steel': 'Aço da chapa de nó',
    'support_steel': 'Aço do W receptor', 'bolt': 'Classe do parafuso', 'db': 'Diâmetro nominal do parafuso (mm)',
    'n': 'Quantidade de parafusos físicos na linha', 'pitch': 'Passo longitudinal (mm)',
    'gauge': 'Graminho desde o talão externo (mm)', 'angle_end': 'Extremidade livre da L até o primeiro furo (mm)',
    'row_offset': 'Deslocamento da linha ao longo de u (mm)', 'drilled': 'Furos executados por broca · dedução líquida sem acréscimo de 2 mm',
    'threads_excluded_1': 'Plano 1 realmente fora da rosca', 'threads_excluded_2': 'Plano 2 realmente fora da rosca · só 2L-T',
    'pretensioned': 'Parafusos protendidos', 'exposure': 'Exposição ambiental',
    'tool_radius': 'Raio real do envelope da ferramenta / ferragem (mm)',
    'fabrication_clearance': 'Folga adicional de fabricação (mm)',
    'heel_extent': 'Extensão interna real do talão desde a face externa (mm)',
    'heel_extent_source': 'Origem da medida real do talão', 'washer_stack': 'Espessura adicional de arruelas na pega (mm)',
    'root_electrode': 'Eletrodo dos dois filetes da raiz',
    'plate_width': 'Largura da chapa / raiz B (mm)', 'plate_height': 'Projeção da chapa H (mm)',
    'plate_t': 'Espessura da chapa t (mm)', 'theta_deg': 'Ângulo com +s, eixo longitudinal do W · θ (graus)',
    'center_s': 'Referência da linha em s (mm)', 'center_n': 'Referência da linha em n (mm)',
    'root_weld_leg': 'Perna dos dois filetes da raiz (mm)',
    'support_end_left': 'Extremidade W esquerda · módulo (mm)', 'support_end_right': 'Extremidade W direita (mm)',
    'N': 'Força axial total N · tração positiva (kN)', 'V': 'Cortante adicional fora do modelo (kN)',
    'M': 'Momento adicional fora do modelo (kN·m)', 'torsion': 'Torção adicional fora do modelo (kN·m)',
    'static': 'Carregamento estático', 'normal_combination': 'Combinação última normal',
    'fatigue': 'Fadiga exigida', 'seismic': 'Qualificação sísmica exigida',
    'minimum_force': 'Mínimo de 45 kN em caso separado', 'recommend_half_capacity': 'Recomendação de 50% da resistência em caso separado',
    'notes': 'Observações do responsável técnico',
}


def checks_complete(result):
    rows = result.get('checks') or []
    required = {'id', 'label', 'component', 'mechanism', 'case_id', 'demand', 'resistance', 'utilization', 'status'}
    return bool(rows) and result.get('summary', {}).get('complete_checks') is True and all(
        isinstance(row, dict) and required <= row.keys()
        and all(_finite(row[key]) for key in ('demand', 'resistance', 'utilization'))
        and row['status'] in ('PASS', 'FAIL') for row in rows)


from .gusset_outer_end_ui import LABELS as OUTER_LABELS
LABELS.update(OUTER_LABELS)

def _checks_table(rows, opposed=False):
    frame = pd.DataFrame([{'Caso': x.get('case_id'), 'Verificação': x.get('label', x.get('id')),
                          'ID': x.get('id'), 'Componente': x.get('component'),
                          'Face / plano': x.get('face', x.get('plane', (x.get('details') or {}).get('plane', 'comum'))),
                          'Base da força': x.get('load_basis', x.get('force_scope',
                              'por plano físico' if x.get('component') == 'bolt' else
                              'por L' if x.get('component') == 'angle' and x.get('mechanism') not in ('tension_yield','tension_rupture') else 'N total da ligação')),
                          'Solicitação': x.get('demand'), 'Resistência': x.get('resistance'),
                          'Unidade': x.get('unit', 'N'), 'Índice': x.get('utilization'), 'Resultado': x.get('status')}
                         for x in rows])

    if opposed:
        frame['Face / plano'] = [str(x.get('face',(x.get('details') or {}).get('face', (x.get('details') or {}).get('plane','comum')))) for x in rows]
        from .bolted_opposed_angle_gusset_presentation import physical_envelopes
        basis = {item['id']:envelope['force_scope'] for envelope in physical_envelopes({'checks':rows}) for item in envelope['members']}
        frame['Base da força'] = [basis[x['id']] for x in rows]
    return frame


def _render():
    from .bolted_angle_gusset import BoltedAngleGusset, FAMILY, COMPONENT_VERSION, MATERIALS, ELECTRODES, SUPPORT_CATALOG, evaluate, presets
    from .bolted_angle_gusset_drawing import image_bytes
    from .bolted_angle_gusset_report import create_report
    from .bolted_angle_gusset_presentation import physical_envelopes, angle_identity, angle_detail_disclosure
    from .angle_catalog import catalog, label as angle_label
    from .models import BOLTS
    s = st.session_state
    saved, draft = s.get(PROJECT), s.get(DRAFT)
    prior_report = s.pop(REPORT, None)
    s.pop(PROJECT, None); s.pop(RESULT, None)
    if 'bag_project' not in s:
        seed(_connection_class(connection_type=saved.get('connection_type')).from_dict(saved) if saved else BoltedAngleGusset())
        if draft: s.update(draft)
    opposed = s.get('bag_arrangement') == '2L-opposed'
    if opposed:
        from .bolted_opposed_angle_gusset import BoltedOpposedAngleGusset as BoltedAngleGusset, FAMILY, COMPONENT_VERSION, evaluate
        from .bolted_opposed_angle_gusset_drawing import image_bytes
        from .bolted_opposed_angle_gusset_report import create_report
        from .bolted_opposed_angle_gusset_presentation import physical_envelopes
    for path, _ in _walk(s[TEMPLATE]['connection']):
        key = _key(path)
        if key in s: s[key] = s[key]
    if s.get('bag_arrangement_notice'):st.info(s['bag_arrangement_notice'])
    if s.get('bag_arrangement_error'):st.error(s['bag_arrangement_error'])
    with st.sidebar:
        st.caption('Versão ' + COMPONENT_VERSION + ' · rota completa parafusada')
        st.selectbox('Exemplo completo parafusado', list(_all_presets()), key='bag_example')
        st.button('Usar exemplo completo parafusado', on_click=use_example)
        st.file_uploader('Abrir projeto completo parafusado', type=['json'], key='bag_upload')
        st.button('Carregar projeto completo parafusado', on_click=load_project)
        if 'bag_import_error' in s: st.error(s.bag_import_error)
        st.caption(BRAND); st.link_button('LinkedIn · Lucas Oliveira', LINK)
    st.title(FAMILY)
    st.info(SCOPE_TEXT)
    st.caption('Família independente dos antigos componentes axiais: inclui chapa perfurada, raiz e W local. '
               'Projetos importados conservam a identidade nativa da família. 2L opostas >< usa motor, duas linhas e caminhos de chapa próprios.')
    _scalar(('project',), LABELS['project'])
    left, right = st.columns([.95, 1.5], gap='large')
    rendered = {'project'}
    def scalar(name, options=None, labels=None):
        if (name,) in s[ACCEPTED]:
            label = LABELS.get(name, name)
            if opposed:
                label = {'n':'Quantidade de parafusos por L / por linha (total físico = 2n)',
                         'threads_excluded_1':'Linha negativa · plano único realmente fora da rosca',
                         'threads_excluded_2':'Linha positiva · plano único realmente fora da rosca',
                         'center_s':'Eixo médio do par P0 em s (mm)',
                         'center_n':'Eixo médio do par P0 em n (mm)'}.get(name, label)
            _scalar((name,), label, options, labels); rendered.add(name)
    with left:
        st.subheader('Arranjo, ações e materiais independentes')
        scalar('arrangement', ('1L', '2L-T', '2L-opposed'), {'1L':'1L · um plano por parafuso', '2L-T':'2L-T simétrico · dois planos por parafuso passante', '2L-opposed':'2L opostas >< · duas linhas, 2n parafusos em corte simples'})
        scalar('support_member', ('beam', 'column'), {'beam':'Viga W', 'column':'Pilar W'})
        scalar('support_face', ('flange', 'web'), {'flange':'Mesa exterior centrada na alma', 'web':'Alma direta · fora do domínio'})
        scalar('N'); load_slot = st.empty()
        if opposed:
            st.caption('2L opostas ><: N/2 por L; N/(2n) por parafuso e por furo da chapa. h=t da chapa; linhas v=±(t/2+g), graminho desde cada talão. Pega=t da chapa+t de uma L+arruelas. Chapa, raiz e W recebem N uma vez. A idealização NBR 6.1.8.2 não demonstra cancelamento físico de efeitos locais fora do plano.')
        else:
            st.caption('2L-T: N/2 em cada L, N/(2n) por plano e N/n em cada furo da chapa. 1L: N na L e N/n por plano. '
                   'A chapa comum e os dois filetes da raiz conservam N total. A idealização estática da NBR 6.1.8.2 não elimina shear lag nem o momento da raiz.')
        with st.expander('Ações e condições fora do domínio'):
            for name in ('V','M','torsion','static','normal_combination','fatigue','seismic'): scalar(name)
        for name in ('angle_steel','gusset_steel','support_steel'): scalar(name, list(MATERIALS))
        scalar('bolt', list(BOLTS)); scalar('root_electrode', list(ELECTRODES))
        with st.expander('Cantoneira e geometria da linha', expanded=True):
            angles = catalog(include_legacy=True)
            include_small = st.checkbox('Incluir cantoneiras menores que 2½ pol.', key='bag_include_small_angles')
            visible = [identity for identity, section in angles.items() if include_small or section['leg'] >= 63.5]
            scalar('angle_profile', visible, {identity:angle_label(identity) for identity in angles})
            selected = angles.get(s.get('bag_angle_profile'))
            if selected:
                st.caption(angle_identity(selected) + '; b=' + _display(selected['leg']) + ' mm; t=' + _display(selected['t'])
                           + ' mm; Ag por L=' + _display(selected.get('Ag')) + ' mm²; ec por L=' + _display(selected.get('centroid')) + ' mm.')
                st.caption('Fonte: ' + selected['source']); st.caption(angle_detail_disclosure(selected))
                if not selected.get('section_properties_published'): st.warning('Ag/ec não publicados: nenhuma propriedade resistente é estimada.')
            for name in ('theta_deg','center_s','center_n','row_offset','gauge','angle_end'): scalar(name)
            st.caption('θ parte de +s, eixo longitudinal do apoio, até o eixo da cantoneira. A linha nominal dos parafusos conserva Nraiz=N senθ, '
                       'Vraiz=N cosθ e Mraiz=sP Nraiz−nP Vraiz, inclusive seus sinais. Nenhum momento arbitrário é acrescentado.')
        with st.expander('Parafusos, furos e acesso físico', expanded=True):
            for name in ('db','n','pitch','drilled','threads_excluded_1','threads_excluded_2','pretensioned'): scalar(name)
            scalar('exposure', ('painted','weathering'), {'painted':'Aço pintado / protegido', 'weathering':'Aço patinável exposto'})
            for name in ('washer_stack','tool_radius','fabrication_clearance','heel_extent','heel_extent_source'): scalar(name)
            st.caption('A extensão do talão é geometria real, não raio presumido de catálogo nem declaração de aprovação. Deixe vazia quando desconhecida: '
                       'a montagem fica pendente. A origem deve identificar medição, desenho ou limite verificado. O exemplo declara uma hipótese de 12,35 mm, sem certificá-la.')
            st.caption('Furo físico normal e diâmetro de dedução líquida são distintos. Cada plano de corte e cada contato de furo são verificados individualmente. '
                       'Protensão não concede resistência por atrito neste modelo.')
        with st.expander('Chapa única e dois filetes da raiz', expanded=True):
            for name in ('plate_width','plate_height','plate_t','root_weld_leg'): scalar(name)
            if not opposed:
                from .gusset_outer_end_ui import render as render_outer_end
                rendered.update(render_outer_end(st,'bag_','bolted','bag_db'))
        with st.expander('W receptor e extremidades'):
            scalar('support_profile', list(SUPPORT_CATALOG))
            scalar('support_end_left'); scalar('support_end_right')
            profile = SUPPORT_CATALOG.get(s.get('bag_support_profile'))
            if profile: st.caption('Fonte do W: ' + profile['source'])
        with st.expander('Casos suplementares independentes'):
            scalar('minimum_force'); scalar('recommend_half_capacity')
            st.caption('45 kN aplica-se uma vez à ligação, antes da divisão. A recomendação usa a resistência do membro, ou do par de duas L. '
                       'Nenhum caso é somado à força real, que permanece zero quando N=0.')
        other = [(path, value) for path,value in _walk(s[TEMPLATE]['connection']) if path[0] not in rendered and path[0] != 'notes']
        if other:
            with st.expander('Outras entradas nativas'):
                for path,_ in other: _scalar(path, '.'.join(map(str,path)))
        if ('notes',) in s[ACCEPTED]: st.text_area(LABELS['notes'], key='bag_notes')
    native = _current_native(); c = BoltedAngleGusset.from_dict(native)
    encoded = json.dumps(native, ensure_ascii=False, indent=2, allow_nan=False)
    with load_slot.container(): render_load_convention(st, 'bolted_opposed_angle_gusset' if opposed else 'bolted_angle_gusset', c.N, theta_deg=c.theta_deg)
    _save_draft(); r = evaluate(c)
    digest = hashlib.sha256((encoded + json.dumps(r, ensure_ascii=False, sort_keys=True, allow_nan=False)).encode()).hexdigest()
    s[PROJECT],s[RESULT] = native,r
    complete = checks_complete(r); geometry_valid = r.get('geometry',{}).get('valid') is True
    status = r.get('status','INVALID_INPUT')
    ready = complete and geometry_valid and not status.startswith(('INVALID','NUMERICAL','OUTSIDE'))
    png = image_bytes(c,fmt='png') if geometry_valid else None
    count = 1 if c.arrangement == '1L' else 2
    with right:
        label = STATUS.get(status,status)
        if r.get('global_pass') and complete and geometry_valid: st.success(label + ' · LIGAÇÃO LOCAL')
        elif status in ('DETAILING_PENDING','NOT_VERIFIED'): st.warning(label)
        else: st.error(label)
        st.caption('Atendimento local não aprova o membro carregado, a estrutura nem fabricação. Seções perfuradas são triagem nominal suplementar; '
                   'Whitmore, contato dos furos, seções líquidas e blocos de borda permanecem verificações independentes.')
        a,b,index = st.columns(3)
        a.metric('N real total (kN)',_display(c.N/1000)); b.metric('N real por L (kN)',_display(c.N/count/1000))
        index.metric('Índice governante',_display(r.get('summary',{}).get('utilization')))
        for issue in r.get('issues') or []:
            message = issue.get('message',str(issue)); severity = issue.get('severity')
            if severity in ('info','note'): st.caption(message)
            elif severity in ('warning','pending','engineering_pending'): st.warning(message)
            else: st.error(message)
        if opposed:
            st.caption('Sinal nominal na zona perfurada é diagnóstico informativo. Tensões negativas nesse campo hipotético não reprovam sozinhas a ligação; resistências e envelopes materiais continuam obrigatórios. Compressão real na raiz ou no ligamento não perfurado permanece fora deste domínio de tração.')
            with st.expander('Diagnóstico da introdução e ligamento íntegro da raiz'):
                for case in r.get('cases') or []:
                    st.json(display_tree({'case_id':case.get('id'), 'introduction_sign_diagnostic':case.get('introduction_sign_diagnostic'),
                             'solid_root_ligament':case.get('solid_root_ligament')}), expanded=False)
        if png: st.image(png,width='stretch')
        with st.expander('Geometria, equilíbrio e ações exportadas para o membro W'):
            for key in ('geometry','root','member_actions'): st.json(display_tree(r.get(key) or {}),expanded=False)
        if r.get('cases'):
            st.subheader('Casos independentes')
            st.dataframe(display_frame(pd.DataFrame([{'Caso':x.get('label',x.get('id')), 'ID':x.get('id'),
                                       'N total (kN)':x.get('N',0)/1000, 'N por L (kN)':x.get('N',0)/count/1000}
                                      for x in r['cases']])),hide_index=True,width='stretch')
    if complete:
        st.subheader('Resultados por componente e mecanismo físico')
        envelopes=physical_envelopes(r)
        st.dataframe(display_frame(pd.DataFrame([{'Componente':e['component_label'],'Mecanismo':e['mechanism_label'],
                                    'Índice real':e['actual_utilization'],'Índice adotado':e['utilization'],
                                    'Resultado':e['status'],'Governantes e empates':'; '.join(e['governing_ids'])}
                                   for e in envelopes])),hide_index=True,width='stretch')
        with st.expander('Todos os planos, contatos, caminhos e seções · evidência completa'):
            st.dataframe(display_frame(_checks_table(r['checks'],opposed=opposed)),hide_index=True,width='stretch')
            for key in ('checks','cases','materials'): st.json(display_tree(r.get(key) or []),expanded=False)
    if opposed:
        from .bolted_opposed_angle_gusset_presentation import concise_memory
        st.caption('MC resumida · copiar e colar')
        st.code(concise_memory(c), language=None, wrap_lines=True)
    if not complete and r.get('checks'):
        st.warning('Registros incompletos: conclusão resistente e emissão da memória bloqueadas.'); st.json(display_tree(r['checks']),expanded=False)
    a,b,d=st.columns(3)
    artifact_stem='ligacao_completa_parafusada_'+('2L_opostas_gusset' if opposed else 'gusset')
    a.download_button('Salvar projeto completo parafusado .json',encoded,artifact_stem+'.json','application/json')
    if opposed:
        a.download_button('Baixar resultados completos parafusados .json',
                          json.dumps({'input':native,'result':r},ensure_ascii=False,indent=2,allow_nan=False),
                          artifact_stem+'_resultados.json','application/json')
    if geometry_valid:
        b.download_button('Baixar desenho completo parafusado .png',png,artifact_stem+'.png','image/png')
        b.download_button('Baixar desenho completo parafusado .svg',image_bytes(c,fmt='svg'),artifact_stem+'.svg','image/svg+xml')
    detailed=d.checkbox('Memória detalhada · incluir testemunhos e caminhos',key='bag_report_detailed')
    report_digest=hashlib.sha256((digest+str(detailed)).encode()).hexdigest()
    if ready and prior_report and prior_report[0]==report_digest: s[REPORT]=prior_report
    if ready and not r.get('global_pass'): st.caption('A memória registra a falha ou pendência atual; emiti-la não aprova a ligação.')
    if d.button('Gerar memória completa parafusada',disabled=not ready):
        name='memoria_completa_parafusada_'+('2L_opostas_gusset' if opposed else 'gusset')+('_detalhada' if detailed else '')+'.docx'
        s[REPORT]=(report_digest,name,create_report(c,detailed=detailed))
    if REPORT in s:
        _,name,payload=s[REPORT]
        st.download_button('Baixar memória completa parafusada .docx',payload,name,'application/vnd.openxmlformats-officedocument.wordprocessingml.document')
