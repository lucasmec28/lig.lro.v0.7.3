"""Editable, independently scoped calculation record for welded-support 2L.

The public exporter always evaluates the current input. ``result`` is accepted
only for API compatibility, is never read, and is never serialized or embedded.
Presentation formatting must not feed back into the input or the calculation.
"""
from dataclasses import fields, is_dataclass
from io import BytesIO
from math import pi, sqrt

from docx import Document
from docx.enum.section import WD_ORIENT, WD_SECTION_START
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor

from .angle_catalog import get_angle
from .display_precision import calculated_text
from .models import BOLTS, STEELS, finite_real
from .report import BRAND, _math, frac, group, hyperlink, number, power, radical, slot, sub, table
from .welded_support_double_angle import (
    COMPONENT_VERSION, CONNECTION_TYPE, EXCLUSIONS, NBR, SCOPE,
    WeldedSupportDoubleAngle, evaluate, input_errors,
)


STATUS = {
    'INVALID_INPUT': 'Entrada inválida',
    'INVALID_GEOMETRY': 'Geometria inválida',
    'NUMERICAL_FAILURE': 'Falha numérica',
    'OUTSIDE_SUPPORTED_SCOPE': 'Fora do domínio implementado',
    'VERIFIED_SUBCHECK_FAIL': 'Verificação resistente não atendida',
    'DETAIL_FAIL': 'Requisito de detalhamento não atendido',
    'ENGINEERING_MODEL_PENDING': 'Verificação completa pendente',
    'COMPLETE_CHECKS_PASS_WITHIN_SCOPE': 'Verificações locais atendidas no domínio declarado',
}
LABELS = {
    'project': 'Projeto', 'kind': 'Interface receptora', 'angle_count': 'Número físico de cantoneiras', 'symmetric': 'Cantoneiras iguais e simétricas',
    'assembly': 'Sequência de montagem declarada', 'weld_tool_radius': 'Raio do envelope de soldagem em campo em mm',
    'beam_leg': 'Aba junto à alma b_viga em mm', 'support_leg': 'Aba na mesa b em mm',
    't': 'Espessura real da cantoneira t em mm', 'root_radius': 'Raio interno real em mm',
    'length': 'Altura da cantoneira H em mm', 'angle_top': 'Topo L abaixo do topo da viga em mm',
    'beam_gauge': 'Face do apoio até eixo dos parafusos e em mm',
    'web_rows': 'Número de parafusos na coluna', 'web_columns': 'Colunas de parafusos na alma',
    'web_pitch': 'Passo vertical p em mm', 'web_end_top': 'Borda superior L em mm',
    'gap': 'Folga ponta da viga até face do pilar em mm',
    'weld_leg': 'Perna do filete w em mm', 'top_return': 'Retorno superior físico em mm',
    'weld_layout': 'Arranjo de soldas', 'weld_process': 'Processo e eletrodo',
    'reinforced_weld_edge': 'Exceção de borda reforçada documentada pelo responsável',
    'electrode_fuw': 'Resistência fuw em MPa', 'beam_steel': 'Aço da viga',
    'support_steel': 'Aço do pilar', 'angle_steel': 'Aço das duas cantoneiras',
    'bolt': 'Classe dos parafusos', 'db': 'Diâmetro do parafuso db em mm',
    'hole_diameter': 'Diâmetro físico do furo dh em mm', 'hole_type': 'Tipo de furo',
    'drilled': 'Furação por broca documentada',
    'web_threads_excluded': 'Rosca excluída dos dois planos de corte',
    'V': 'V real com sinal em N', 'N': 'N externo real em N',
    'M': 'M externo real em N mm', 'torsion': 'T externo real em N mm',
    'cope': 'Recorte da viga', 'static': 'Ações estáticas',
    'normal_combination': 'Combinação última normal',
    'no_slip_required': 'Ausência de deslizamento exigida',
    'support_continuous': 'Mesa do pilar contínua na região',
    'tool_radius': 'Raio do envelope de cabeça, porca, arruela e ferramenta em mm',
    'fabrication_clearance': 'Folga adicional de fabricação em mm',
    'exposure': 'Exposição', 'notes': 'Observações',
    'angle_catalog_id': 'Identificador de catálogo da cantoneira',
    'angle_root_source': 'Fonte do raio de concordância',
    'angle_root_confirmed': 'Raio de concordância confirmado',
}
SEVERITY = {
    'warning': 'Advertência', 'invalid_input': 'Entrada inválida', 'invalid_geometry': 'Geometria inválida',
    'numerical_failure': 'Falha numérica', 'unsupported_scope': 'Fora do domínio',
    'detail_fail': 'Detalhamento não atendido', 'access_pending': 'Acesso pendente',
    'engineering_pending': 'Pendência técnica', 'info': 'Informação',
}


def _mapping(value):
    return value if isinstance(value, dict) else {}


def _value(value):
    if isinstance(value, bool):
        return 'sim' if value else 'não'
    if value is None:
        return 'não disponível'
    if isinstance(value, (int, float)):
        return number(value, 2) if finite_real(value) else str(value) + ' (inválido)'
    if isinstance(value, (tuple, list)):
        return '(' + '; '.join(_value(item) for item in value) + ')'
    if isinstance(value, dict):
        return '; '.join(str(key) + '=' + _value(item) for key, item in value.items())
    return str(value)


def _kn(value):
    return _value(value / 1000.) if finite_real(value) else 'não disponível'


def _flatten(value, path=''):
    if isinstance(value, dict):
        for key, child in value.items():
            yield from _flatten(child, path + '.' + str(key) if path else str(key))
    elif isinstance(value, (tuple, list)) and any(isinstance(x, (dict, tuple, list)) for x in value):
        for index, child in enumerate(value):
            yield from _flatten(child, path + '[' + str(index) + ']')
    else:
        yield path, _value(value)


def _approved(result):
    blockers = {'invalid_input', 'invalid_geometry', 'numerical_failure', 'unsupported_scope',
                'detail_fail', 'access_pending', 'engineering_pending', 'error', 'pending'}
    checks = result.get('checks') or []
    return (result.get('status') == 'COMPLETE_CHECKS_PASS_WITHIN_SCOPE'
            and result.get('global_pass') is True
            and _mapping(result.get('geometry')).get('valid') is True
            and _mapping(result.get('summary')).get('complete_checks') is True
            and bool(checks) and all(row.get('status') == 'PASS' for row in checks)
            and not any(row.get('severity') in blockers for row in result.get('issues', [])))


def _heading(doc, text, level=1):
    return doc.add_paragraph(text, style='Heading ' + str(level))


def _tab(doc, headers, rows, widths, size=8.2):
    result = table(doc, headers, rows, widths)
    for row in result.rows:
        for cell in row.cells:
            for margin in cell._tc.xpath('./w:tcPr/w:tcMar/w:top | ./w:tcPr/w:tcMar/w:bottom'):
                margin.set(qn('w:w'), '40')
            for paragraph in cell.paragraphs:
                paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT
                for run in paragraph.runs:
                    run.font.size = Pt(size)
    gap = doc.paragraphs[-1]
    gap.paragraph_format.space_before = gap.paragraph_format.space_after = Pt(0)
    gap.paragraph_format.line_spacing = Pt(2)
    return result


def _section(doc, landscape=False):
    section = doc.add_section(WD_SECTION_START.NEW_PAGE)
    section.orientation = WD_ORIENT.LANDSCAPE if landscape else WD_ORIENT.PORTRAIT
    section.page_width = Inches(11.69 if landscape else 8.27)
    section.page_height = Inches(8.27 if landscape else 11.69)
    section.top_margin = section.bottom_margin = Inches(.55)
    section.left_margin = section.right_margin = Inches(.60)
    return section


def _square_delimited(expression):
    delimiter = OxmlElement('m:d')
    props = OxmlElement('m:dPr')
    for tag, value in (('begChr', '('), ('endChr', ')')):
        node = OxmlElement('m:' + tag)
        node.set(qn('m:val'), value)
        props.append(node)
    delimiter.append(props)
    delimiter.append(slot('e', group(expression)))
    return power(delimiter)


def _equations(doc, *expressions):
    for expression in expressions:
        _math(doc, group(expression))


def _inputs(doc, c):
    _heading(doc, 'Dados de entrada completos')
    doc.add_paragraph('Unidades nativas: N, mm, MPa e N mm. As apresentações numéricas têm no máximo duas casas decimais; '
                      'valores muito pequenos usam notação científica. A entrada e os resultados permanecem sem arredondamento. '
                      'Designações, fontes e observações são conservadas como texto.')
    if not isinstance(c, WeldedSupportDoubleAngle):
        doc.add_paragraph('Objeto de entrada recebido: ' + repr(c))
        return
    _heading(doc, 'Perfis da viga e do pilar', 2)
    doc.add_paragraph('d, bf, tw, tf e clear em mm; area em mm²; mass em kg/m. A mesa receptora usa tf do pilar, '
                      'uma única espessura física; tw da viga pertence apenas à alma apoiada.')
    for key, label in (('beam', 'Viga apoiada'), ('support', 'Pilar receptor')):
        profile = getattr(c, key)
        rows = [(label + ' · ' + f.name, _value(getattr(profile, f.name))) for f in fields(profile)] if is_dataclass(profile) else [(label, _value(profile))]
        _tab(doc, ['Campo do perfil', 'Valor declarado'], rows, [3.15, 3.92])
    _heading(doc, 'Geometria ações fabricação e montagem', 2)
    rows = [(LABELS.get(f.name, f.name) + '\n' + f.name, _value(getattr(c, f.name)))
            for f in fields(c) if f.name not in ('beam', 'support')]
    _tab(doc, ['Grandeza e identificador de entrada', 'Valor declarado'], rows, [4.25, 2.82])
    if c.angle_catalog_id and not input_errors(c):
        record = get_angle(c.angle_catalog_id)
        if record:
            doc.add_paragraph('Fonte do catálogo: ' + record['source'] + '. Raio interno manual declarado: ' +
                              _value(c.root_radius) + ' mm. Fonte independente: ' + (c.angle_root_source or 'pendente') +
                              '. A seleção não certifica o aço ou a fabricação e não amplia o domínio do modelo.')
    _heading(doc, 'Materiais e coeficientes', 2)
    rows = []
    for role, key in (('Cada uma das duas cantoneiras', 'angle_steel'), ('Alma da viga', 'beam_steel'), ('Mesa do pilar', 'support_steel')):
        name = getattr(c, key)
        steel = STEELS.get(name) if isinstance(name, str) else None
        rows.append((role, _value(name), _value(getattr(steel, 'fy', None)), _value(getattr(steel, 'fu', None))))
    _tab(doc, ['Componente', 'Aço', 'fy MPa', 'fu MPa'], rows, [1.65, 3.02, 1.2, 1.2])
    fub = BOLTS.get(c.bolt) if isinstance(c.bolt, str) else None
    doc.add_paragraph('Parafusos: fub=' + _value(fub) + ' MPa. Metal de solda: fuw=' + _value(c.electrode_fuw) +
                      ' MPa. Coeficientes para combinações normais: γa1=1,10 e γa2=1,35. E=200.000 MPa na seleção geométrica e no cortante da alma.')
    doc.add_paragraph('A fonte de propriedades e o raio real devem corresponder ao produto adquirido. Um nome de perfil '
                      'não substitui a conferência das dimensões, do raio, do aço, da faixa de espessura e das ferragens.')
    _heading(doc, 'Premissas fixas', 2)
    _tab(doc, ['Premissa do modelo', 'Valor'], list(_flatten(c.fixed_assumptions)), [3.2, 3.87])



def _scope_gates(doc, result):
    """Keep resistance, geometry/access, method and external work distinct."""
    checks = result.get('checks') or []
    issues = result.get('issues') or []
    def failed(*categories):
        return any(row.get('severity') in categories for row in issues)
    resistance = ('Não avaliada' if not checks else 'Não atende' if any(row.get('status') != 'PASS' for row in checks)
                  else 'Verificações resistentes locais atendidas')
    geometry = ('Não avaliada' if not result.get('geometry') else
                'Bloqueada' if failed('invalid_geometry', 'detail_fail', 'access_pending') else
                'Condições geométricas e envelopes declarados atendidos')
    method = ('Não qualificado' if failed('invalid_input', 'unsupported_scope', 'engineering_pending', 'numerical_failure')
              else 'Dentro do domínio implementado' if checks else 'Não avaliado')
    _heading(doc, 'Quatro conclusões independentes', 2)
    _tab(doc, ['Aspecto', 'Resultado e limite'], [
        ('Resistência local', resistance),
        ('Geometria e acesso', geometry + '. O envelope declarado não certifica o acesso real no edifício.'),
        ('Domínio do método', method + '. Estado final, V descendente estático e N=M=T=0.'),
        ('Global e provisório', 'NÃO VERIFICADOS. Não verifica içamento, uma cantoneira/um parafuso, estabilidade provisória, '
         'escoramento ou estabilidade global. Não autoriza liberar o içamento.'),
    ], [1.60, 5.47])


def _loads_and_scope(doc, c, result):
    _heading(doc, 'Caminho das forças e domínio da ligação 2L')
    doc.add_paragraph('Duas cantoneiras físicas iguais e simétricas envolvem uma única alma de viga. '
        'Cada parafuso comum atravessa cantoneira, alma e cantoneira, com dois planos de corte. '
        'Cada aba de apoio transfere metade da força à mesa contínua do pilar por uma solda vertical externa. '
        'Não existem parafusos no apoio nem solda na viga. Não há solda inferior ou no talão.')
    doc.add_paragraph('O detalhe convencional 2L de AISC P901 v16, exemplo II.A-2A, orienta a topologia e '
        'a distribuição direta no domínio declarado. As resistências são verificadas pela ' + NBR + '. '
        'O grupo elástico de cada solda vertical considera a excentricidade no plano da mesa do pilar. '
        'A hipótese convencional de flexibilidade fora desse plano é restrita a esta configuração; '
        'não constitui dispensa geral de excentricidade ou prova de ductilidade rotacional.')
    doc.add_paragraph('V positivo é descendente. As ações já são de cálculo, sem majoração adicional. '
        'V nulo ou ascendente, qualquer N, M ou T externo diferente de zero, reversão, fadiga e impacto '
        'permanecem como informados e não são aprovados nesta rota.')
    lm = _mapping(result.get('load_model'))
    _tab(doc, ['Grandeza preservada ou adotada', 'Valor', 'Unidade'], [
        ('V real com sinal', _value(getattr(c, 'V', None)), 'N'),
        ('N externo real', _value(getattr(c, 'N', None)), 'N'),
        ('M externo real', _value(getattr(c, 'M', None)), 'N mm'),
        ('T externo real', _value(getattr(c, 'torsion', None)), 'N mm'),
        ('V real', _kn(getattr(c, 'V', None)), 'kN'),
        ('Vd adotado para a ligação completa', _kn(lm.get('Vd_N')), 'kN'),
        ('F adotada por cantoneira', _kn(lm.get('each_angle_force_N')), 'kN'),
        ('Força por parafuso comum', _kn(lm.get('web_bolt_force_N')), 'kN'),
    ], [4.07, 1.50, 1.50])
    _math(doc, group(sub('V', 'd'), ' = max(', sub('V', 'real'), '; 45 kN), somente se Vreal > 0'))
    _math(doc, group(sub('F', 'L'), ' = ', frac(sub('V', 'd'), '2'), ';  ', sub('F', 'parafuso'), ' = ', frac(sub('V', 'd'), 'n'), ';  ', sub('n', 'planos'), ' = 2'))
    doc.add_paragraph('O mínimo de 45 kN é aplicado uma única vez à ligação completa, conforme NBR 6.1.5.2. '
        'Só depois Vd é dividido entre as duas cantoneiras. Cada plano do parafuso recebe Vd/(2n); a alma única '
        'recebe Vd/n por furo. Não são duas almas, dois grupos físicos de parafusos ou dois mínimos de 45 kN.')
    if lm:
        _tab(doc, ['Modelo de ações e referências', 'Valor'], list(_flatten(lm)), [3.50, 3.57])
    else:
        doc.add_paragraph('O motor não produziu demandas resistentes para esta entrada. As equações documentam '
            'a rota implementada, mas não aprovam uma entrada bloqueada.')
    doc.add_paragraph('Transporte para o modelo global: X é normal à face do pilar, do centro até a face carregada; '
        'Y é vertical para cima e Z completa o sistema destro. A força real na face é (0; −Vreal; 0), '
        'r=(d_pilar/2; 0; 0) e r×F=(0; 0; −Vreal d_pilar/2). Incluir somente se ainda ausente do modelo global. '
        'O mínimo local de 45 kN não substitui a reação global. Esse transporte não cria um engaste convencional.')
    _heading(doc, 'Domínio geométrico e de montagem', 2)
    doc.add_paragraph('Uma coluna de 2 a 8 parafusos; e≤76,20 mm da face do apoio ao eixo dos parafusos; '
        'abas≥63,50 mm; espessura de 6,35 mm até o valor exato de 3/8 in; b_apoio/t≥8; comprimento H≥d_viga/2. '
        'Estes limites delimitam a qualificação inicial do método. Contato firme sem calços e folga positiva '
        'entre ponta da viga e face do apoio são exigidos. A viga não tem recorte.')
    _math(doc, group(frac('b', 't'), ' ≤ 0,45 ', radical(frac('E', sub('f', 'y'))), '  [triagem geométrica]'))
    doc.add_paragraph('A expressão inspirada na NBR Tabela 4, grupo AL3, é somente uma triagem conservadora '
        'de perfis usuais. Não demonstra estabilidade bidimensional da placa, rotação ou ductilidade. '
        'A exceção de borda reforçada permite w≤t apenas quando declarada e documentada; não cria reforço '
        'automaticamente e não aumenta a resistência calculada.')
    _heading(doc, 'Estado de montagem efetivamente verificado', 2)
    doc.add_paragraph('Uma cantoneira é pré-soldada em oficina. Após posicionar a viga, ainda sustentada pelo içamento, '
        'a cantoneira oposta é posicionada e soldada em campo; todos os parafusos são instalados e recebem aperto final. '
        'Este memorial verifica somente o estado final resultante. A sequência proposta exige procedimento específico '
        'de montagem, soldagem, inspeção e estabilidade provisória definido pelo responsável técnico.')
    doc.add_paragraph('NÃO VERIFICADO: fase de uma cantoneira/um parafuso, içamento, escoramento, sustentação temporária '
        'ou momento de liberação do equipamento. O resultado local final não autoriza liberar o içamento.')


def _geometry(doc, c, result):
    _heading(doc, 'Geometria derivada, detalhamento e acesso')
    g = _mapping(result.get('geometry'))
    doc.add_paragraph('O envelope declarado da ferramenta de soldagem em campo é separado do envelope de '
        'cabeça, porca, arruela e chave dos parafusos. O valor de soldagem informado é ' +
        _value(getattr(c, 'weld_tool_radius', None)) + ' mm de raio. O valor inicial da rota é 20,00 mm; '
        'deve ser conferido para a ferramenta e posição reais. Uma folga numérica favorável não certifica '
        'o acesso do soldador, a sequência de passes ou a execução no edifício.')
    _equations(doc, 'folga_superior = topo_L − (d_viga−h_livre)/2',
        'folga_inferior = d_viga − (d_viga−h_livre)/2 − topo_L − H',
        'folga_superior e folga_inferior ≥ raio_ferramenta_solda + folga_fabricação',
        'e−t−r ≥ raio_ferragem_ferramenta + folga_fabricação')
    if not g:
        doc.add_paragraph('Geometria derivada não produzida. Nenhuma condição é considerada atendida por omissão.')
        return
    doc.add_paragraph('Coordenadas da solda: (z global; y para cima desde a base da cantoneira), com o plano médio '
        'da alma em z=0. O desenho distingue segmentos físicos dos segmentos resistentes. Os y dos furos são '
        'medidos para baixo a partir do topo da viga. Comprimentos em mm e áreas quando identificadas em mm².')
    _tab(doc, ['Grandeza derivada', 'Valor'], list(_flatten({k: v for k, v in g.items() if k != 'checks'})), [3.65, 3.42])
    _heading(doc, 'Todas as condições geométricas e de acesso', 2)
    _tab(doc, ['Critério, categoria e referência', 'Medido', 'Exigência', 'Estado'], [
        (row.get('id', '') + '\n' + row.get('category', '') + '\n' + row.get('reference', ''),
         _value(row.get('actual')), row.get('relation', '') + ' ' + _value(row.get('limit')),
         'Atende' if row.get('passed') else 'Não atende') for row in g.get('checks', [])
    ], [3.60, .88, 1.15, 1.44], size=7.8)
    doc.add_paragraph('dh é o furo físico. dn é a dedução líquida da Tabela 14 acrescida de 2 mm quando a furação '
        'por broca não está documentada. Para V descendente, a borda carregada da cantoneira é a inferior. '
        'Na alma a reação aponta para cima; a alma continua acima do primeiro parafuso, sem borda livre fictícia. '
        'A distância e da face do apoio ao parafuso é distinta da folga da ponta da viga.')


def _weld(doc, result):
    _heading(doc, 'Duas soldas verticais independentes')
    doc.add_paragraph('Cada cantoneira tem uma única linha vertical resistente no toe externo, de comprimento H. '
        'Existe somente um retorno superior físico curto por cantoneira, entre 2w e min(4w; b/2), '
        'sem crédito de comprimento, centroide, inércia ou capacidade. Nenhuma solda inferior, no talão '
        'ou em toda a borda superior integra esta topologia.')
    doc.add_paragraph('Para o lado s=+1 ou −1: ztoe=s(tw/2+b), zL=s tw/2 e yc=H/2. A força de cada cantoneira '
        'é Fy=−Vd/2. O ponto de carga está no seu talão; o braço no plano da solda é b. '
        'Não se usa b+tw/2 como se cada cantoneira recebesse a carga na linha central da alma.')
    _math(doc, group('L = H;  ', sub('z', 'c'), ' = s(', frac(sub('t', 'w'), '2'), ' + b);  ', sub('y', 'c'), ' = ', frac('H', '2')))
    _math(doc, group('J = ', frac(power('H', '3'), '12'), ';  ', sub('e', 'z'), ' = −s b;  ', sub('m', 'zy'), ' = ', sub('F', 'y'), sub('e', 'z')))
    _math(doc, group(sub('q', 'z'), '(y) = −', frac(group(sub('m', 'zy'), '(y−', sub('y', 'c'), ')'), 'J'), ';  ', sub('q', 'y'), ' = ', frac(sub('F', 'y'), 'H')))
    _math(doc, group(sub('q', 'max'), ' = ', frac(group('|', sub('F', 'y'), '|'), 'H'), radical(group('1 + ', _square_delimited(frac('6b', 'H'))))))
    _math(doc, group('a = ', frac('w', radical('2')), ';  ', sub('q', 'Rd'), ' = ', frac(group('0,60 ', sub('f', 'uw'), ' a'), sub('γ', 'a2'))))
    _math(doc, group(sub('F', 'Rd,solda'), ' = ', frac(sub('q', 'Rd'), group(sub('q', 'max'), '(Fy=−1 N)')), ';  ', sub('V', 'Rd,eq'), ' = 2', sub('F', 'Rd,solda')))
    doc.add_paragraph('A distribuição elástica é afim e a norma máxima ocorre nas extremidades exatas. '
        'Não há incremento direcional de resistência nem ajuste a um coeficiente ICR. O kernel utiliza x como z '
        'e qx como qz; seu momento escalar mzy equivale a −Mx global. A garganta é uniforme w/√2.')
    weld = _mapping(result.get('welds'))
    unit = _mapping(weld.get('per_unit_force'))
    if not unit:
        doc.add_paragraph('Grupo resistente não calculado para esta entrada.')
        return
    _tab(doc, ['Grandeza por cantoneira', 'Valor'], [
        ('Perna w em mm', _value(weld.get('leg_mm'))),
        ('Garganta a em mm', _value(weld.get('throat_mm'))),
        ('qRd em N/mm', _value(weld.get('line_resistance_N_per_mm'))),
        ('Comprimento efetivo em mm', _value(unit.get('total_length_mm'))),
        ('Centroide (z; y) em mm, lado positivo', _value((unit.get('centroid_x_mm'), unit.get('centroid_y_mm')))),
        ('Inércia de linha J em mm³', _value(unit.get('J_line_mm3'))),
        ('Ponto de carga em mm, lado positivo', _value(unit.get('load_point_mm'))),
        ('Excentricidade zL−zc em mm, lado positivo', _value(unit.get('eccentricity_x_mm'))),
        ('qmax para Fy=−1 N em N/mm', _value(unit.get('max_resultant_N_per_mm'))),
        ('Retorno superior creditado', _value(weld.get('top_return_credited'))),
    ], [4.20, 2.87])
    rows = []
    for name, key in (('Real', 'actual_per_angle'), ('Adotada', 'adopted_per_angle')):
        for item in weld.get(key, []):
            current = _mapping(item.get('group'))
            rows.append((name + ' · s=' + str(item.get('side')), _kn(current.get('force_y_N')),
                _value(current.get('moment_about_centroid_Nmm')), _value(current.get('max_resultant_N_per_mm'))))
    _tab(doc, ['Ação e lado', 'Fy em kN', 'mzy em N mm', 'qmax em N/mm'], rows, [1.90, 1.40, 1.90, 1.87])
    rows = []
    for segment in unit.get('segments', []):
        for endpoint in segment.get('endpoint_forces', []):
            rows.append((segment.get('id', '') + '/' + endpoint.get('endpoint', ''),
                _value((endpoint.get('x_mm'), endpoint.get('y_mm'))), _value(endpoint.get('qx_N_per_mm')),
                _value(endpoint.get('qy_N_per_mm')), _value(endpoint.get('resultant_N_per_mm'))))
    _tab(doc, ['Extremo unitário +z', '(z; y) mm', 'qz N/mm', 'qy N/mm', 'q N/mm'], rows, [2.0, 1.47, 1.2, 1.2, 1.2])
    _heading(doc, 'Equilíbrio das soldas e cancelamento transversal', 2)
    _equations(doc, '∫qz dl=0;  ∫qy dl=Fy;  ∫[(z−zc)qy−(y−yc)qz] dl=mzy',
        '∫(z qy−y qz) dl=Fy zL;  Mx global=−∫(z qy−y qz) dl',
        'ΣFy=−Vreal;  ΣMx global=0 para o par simétrico')
    rows = []
    for item in weld.get('actual_per_angle', []):
        for key, value in _mapping(_mapping(item.get('group')).get('equilibrium')).items():
            rows.append(('s=' + str(item.get('side')) + ' · ' + key, _value(value)))
    rows += [('Par simétrico · ' + key, _value(value)) for key, value in _mapping(weld.get('paired_equilibrium')).items()]
    _tab(doc, ['Testemunho de equilíbrio para a ação real, N ou N mm', 'Valor'], rows, [4.90, 2.17])
    doc.add_paragraph('Os momentos globais Mx das duas cantoneiras cancelam por simetria; a excentricidade local '
        'b e as trações de cada solda continuam presentes. Esse cancelamento não elimina o transporte '
        'da reação real da face para o centro do pilar em torno de Z.')


def _section_envelope(doc, result):
    _heading(doc, 'Envelope elástico de cada aba soldada')
    doc.add_paragraph('A coordenada u vai do toe ao talão, 0≤u≤b. Cada seção vertical possui A=tH e W=tH²/6. '
        'O equilíbrio de uma única linha vertical fornece N=0, V=Fy e B=Fy(b−u). '
        'No talão, B(b)=0; o braço transversal de cada solda permanece b.')
    _equations(doc, 'N(u)=0;  V(u)=Fy;  B(u)=Fy(b−u);  B(b)=0')
    _math(doc, group(sub('σ', 'bound'), ' = ', frac(group('6|', sub('F', 'y'), '|b'), group('t', power('H'))), ';  ', sub('τ', 'bound'), ' = ', frac(group('1,50|', sub('F', 'y'), '|'), 'tH')))
    _math(doc, group(sub('σ', 'eq,bound'), ' = ', radical(group(power(sub('σ', 'bound')), ' + 3', power(sub('τ', 'bound')))), ';  ', sub('F', 'Rd,aba'), ' = ', frac(group(sub('f', 'y'), '/', sub('γ', 'a1')), group(sub('σ', 'eq,bound'), '(Fy=−1 N)'))))
    doc.add_paragraph('O máximo de flexão é tomado junto ao toe. A combinação de máximos separados é um envelope '
        'conservador de seção retangular no modelo elástico, não uma solução pontual de placa bidimensional. '
        'Não se reivindica ganho plástico, por contato ou por rotação. A demanda é Vd/2 por aba e a capacidade '
        'equivalente do conjunto é duas vezes a capacidade de uma aba simétrica.')
    section = _mapping(_mapping(result.get('welds')).get('support_leg_section'))
    if section:
        _tab(doc, ['Testemunho para Fy=−1 N em uma cantoneira', 'Valor'], list(_flatten(section)), [4.45, 2.62])
    else:
        doc.add_paragraph('Envelope não calculado para esta entrada.')


def _component_derivations(doc, c, result):
    _heading(doc, 'Demais componentes e fórmulas resistentes')
    _heading(doc, 'Metal base junto a cada solda', 2)
    _equations(doc, 'qRd,y=fy tbase/(√3 γa1);  qRd,u=0,60fu tbase/γa2',
        'FRd,base=qRd,base/qmax(Fy=−1 N);  VRd,eq=2FRd,base')
    doc.add_paragraph('A cantoneira usa tbase=t; a mesa do pilar usa sua única espessura física tf_pilar. '
        'Os limites locais lineares por solda não duplicam a espessura da mesa, não usam tw_pilar '
        'e não verificam a resistência e estabilidade global do pilar.')
    _heading(doc, 'Cisalhamento das abas e parafusos comuns', 2)
    _equations(doc, 'Ag=Ht;  An,viga=(H−n dn)t;  An,apoio=Ht',
        'FRd,y=0,60fy Ag/γa1;  FRd,u=0,60fu An/γa2;  Sd por cantoneira=Vd/2',
        'Ab=πdb²/4;  αv=0,45 com rosca ou 0,56 com rosca excluída',
        'gpega=tw,viga+2t;  kpega=max[0; 1−0,01 max(0; gpega−5db)/1,50]',
        'Rv,plano=αv Ab fub kpega/γa2;  VRd,grupo=2n Rv,plano')
    doc.add_paragraph('O parafuso é compartilhado por duas cantoneiras e uma alma. Há dois planos de corte, '
        'demanda Vd/n por parafuso e Vd/(2n) por plano. Não há dois parafusos na mesma posição. '
        'As abas de cada cantoneira são componentes em série, cujas capacidades não se somam.')
    bolts = _mapping(result.get('bolts'))
    if bolts:
        _tab(doc, ['Parafusos, planos e pega', 'Valor'], list(_flatten(bolts)), [4.30, 2.77])
    _heading(doc, 'Contato por furo e transferência em série', 2)
    _equations(doc, 'Rb=min(1,20lc; 2,40db)tbase fu/γa2',
        'lc,L=p−dh nos furos interiores;  lc,L,inferior=eb−dh/2',
        'lc,alma=p−dh abaixo do primeiro;  primeiro: Rb=2,40db tw,viga fu/γa2',
        'Sd,L,i=Vd/(2n);  Sd,alma,i=Vd/n',
        'Rb,L,grupo=ΣRb,L,i;  Rb,alma,grupo=ΣRb,alma,i',
        'Rtransferência=Σmin(2Rv,plano; 2Rb,L,i; Rb,alma,i)')
    doc.add_paragraph('A soma de transferência limita o componente mais fraco em série em cada furo. '
        'Os dois planos e as duas cantoneiras são duplicados somente nesse caminho em paralelo; '
        'a alma física é única e sua capacidade não é duplicada. As verificações individuais com distribuição '
        'direta também precisam atender, independentemente das somas normativas.')
    _heading(doc, 'Blocos de cisalhamento da cantoneira', 2)
    _equations(doc, 'eb=H−et−(n−1)p;  lkv=eb+(k−1)p;  k=1,…,n',
        'Agv=lkv t;  Anv=[lkv−(k−0,50)dn]t;  Ant=(b_viga−e−dn/2)t',
        'Rbloco=[min(0,60fu Anv; 0,60fy Agv)+fu Ant]/γa2',
        'Sd,bloco=k Vd/(2n);  VRd,equivalente=(2n/k)Rbloco')
    doc.add_paragraph('Cada bloco fecha k furos a partir da borda inferior carregada de uma cantoneira. '
        'Cts=1. Caminhos alternativos não se somam. A viga sem recorte e com mesas contínuas não recebe '
        'o bloco específico de uma alma recortada.')
    _heading(doc, 'Cortante da alma única da viga', 2)
    _equations(doc, 'λ=h_livre/tw;  λp=1,10√(5,34 E/fy);  λr=1,37√(5,34 E/fy)',
        'Cv=1 se λ≤λp;  Cv=λp/λ se λp<λ≤λr;  Cv=1,24(λp/λ)² se λ>λr',
        'VRd=0,60fy d tw Cv/γa1;  Sd=Vd')
    doc.add_paragraph('Utilizam-se kv=5,34, E=200.000 MPa e a área física d×tw. Este limite local '
        'não certifica flexão, interação ou estabilidade global da viga.')
    if _mapping(result.get('load_model')) and isinstance(c, WeldedSupportDoubleAngle):
        g = result['geometry']; steel = STEELS[c.beam_steel]
        _tab(doc, ['Substituição geométrica', 'Valor exibido'], [(label, _value(value)) for label, value in [
            ('Ag de cada aba, mm²', c.length*c.t),
            ('An de cada aba parafusada, mm²', (c.length-c.web_rows*g['dn'])*c.t),
            ('Ab de um parafuso, mm²', pi*c.db*c.db/4),
            ('αv', .56 if c.web_threads_excluded else .45),
            ('λ da alma', c.beam.clear/c.beam.tw),
            ('λp da alma', 1.1*sqrt(5.34*200000./steel.fy)),
            ('λr da alma', 1.37*sqrt(5.34*200000./steel.fy)),
            ('Área d tw da alma única, mm²', c.beam.d*c.beam.tw),
        ]], [4.50, 2.57])

def _checks(doc, result):
    checks = result.get('checks') or []
    if not checks:
        _heading(doc, 'Capacidades não avaliadas')
        doc.add_paragraph('Sem verificações resistentes para esta entrada. Capacidades de resultados anteriores não são reutilizadas.')
        return
    _section(doc, landscape=True)
    _heading(doc, 'Todas as capacidades e demandas locais')
    doc.add_paragraph('Todas as forças desta tabela estão em kN. Sd real conserva a reação real; Sd projeto usa Vd uma '
                      'vez. Rd é a resistência do mecanismo ou subconjunto identificado. VRd eq é a capacidade equivalente '
                      'para o V total da ligação, sem somar componentes em série. η usa valores não arredondados; o estado '
                      'do motor prevalece se a apresentação arredondar um índice próximo de 1.')
    _tab(doc, ['Verificação e identificador', 'Sd real', 'Sd projeto', 'Rd', 'VRd eq', 'η real', 'η projeto', 'Estado'], [
        (row['label'] + '\n' + row['id'], _kn(row.get('actual_demand_N')), _kn(row.get('demand_N')),
         _kn(row.get('design_capacity_N')), _kn(row.get('equivalent_total_V_capacity_N')),
         _value(row.get('actual_utilization')), _value(row.get('utilization')), row.get('status', ''))
        for row in checks
    ], [3.3, .97, 1.02, 1., 1., 1., 1.1, 1.1], size=8.1)
    _heading(doc, 'Fórmulas referências e testemunhos de cada verificação')
    doc.add_paragraph('As equações editáveis definem os termos. Áreas dos blocos em mm²; clear_distance_mm e '
                      'thickness_mm em mm; Cv adimensional. Ausência de clear_distance_mm no primeiro furo da alma '
                      'significa que não há borda livre vertical acima. per_hole_capacities_N está em N.')
    main = {'id', 'label', 'component', 'demand_N', 'actual_demand_N', 'design_capacity_N', 'utilization',
            'actual_utilization', 'status', 'equivalent_total_V_capacity_N', 'formula', 'reference'}
    formula_table = _tab(doc, ['Verificação e componente', 'Fórmula implementada e referência', 'Testemunhos adicionais'], [
        (row['id'] + '\n' + row.get('component', ''), '',
         '\n'.join(key + ' = ' + value for key, value in _flatten({k: v for k, v in row.items() if k not in main})) or 'Sem campo adicional')
        for row in checks
    ], [2.4, 5.35, 2.74], size=7.8)
    for table_row, check in zip(formula_table.rows[1:], checks):
        cell = table_row.cells[1]
        _math(cell, group(check.get('formula', '')))
        # Keep every primitive's exact expression editable, including repeated
        # mechanisms. The checked expression stays tied to its own ID/source.
        for math_run in cell._tc.xpath('.//m:r'):
            properties = OxmlElement('w:rPr')
            size = OxmlElement('w:sz')
            size.set(qn('w:val'), '16')
            properties.append(size)
            math_run.insert(0, properties)
        reference = cell.add_paragraph(check.get('reference', ''))
        reference.paragraph_format.space_after = Pt(0)
        for run in reference.runs:
            run.font.size = Pt(7.8)
        # The initially empty cell paragraph would otherwise inflate every row.
        empty = cell.paragraphs[0]
        empty._p.getparent().remove(empty._p)



def _closing(doc, result):
    _section(doc)
    _heading(doc, 'Conclusão, rastreabilidade e limites')
    status = result.get('status', 'NOT_EVALUATED')
    doc.add_paragraph(STATUS.get(status, status) + ' · ' + status)
    if _approved(result):
        doc.add_paragraph('Atendimento das verificações locais implementadas no estado final, condicionado às '
            'ações, dimensões, materiais e premissas registradas. O resultado não aprova a estrutura global, '
            'não libera fabricação ou montagem e não autoriza liberar o içamento.')
    else:
        doc.add_paragraph('SEM APROVAÇÃO LOCAL. Uma falha, pendência, entrada inválida ou domínio não coberto '
            'impede aprovação, mesmo quando componentes individuais tenham resultado PASS.')
    _scope_gates(doc, result)
    summary = _mapping(result.get('summary'))
    if summary:
        _tab(doc, ['Resumo recalculado da entrada atual', 'Valor'], list(_flatten(summary)), [3.65, 3.42])
    _heading(doc, 'Avisos e bloqueios', 2)
    issues = result.get('issues') or []
    if issues:
        _tab(doc, ['Classificação', 'Ocorrência e referência'], [
            (SEVERITY.get(row.get('severity'), str(row.get('severity'))),
             calculated_text(row.get('text', ''), assignments_only=True) +
             ('\n' + row['reference'] if row.get('reference') else '')) for row in issues
        ], [1.45, 5.62])
    else:
        doc.add_paragraph('Nenhuma ocorrência adicional retornada pelo motor.')
    for row in result.get('not_applicable', []):
        doc.add_paragraph(row.get('mechanism', '') + ': ' + row.get('reason', ''))
    _heading(doc, 'Verificações externas obrigatórias', 2)
    for exclusion in result.get('exclusions', EXCLUSIONS):
        doc.add_paragraph(exclusion, style='List Bullet')
    doc.add_paragraph('O projeto estrutural continua responsável por ações e combinações globais; '
        'resistência, interação e estabilidade da viga, pilar e pórtico; condições reais do receptor; '
        'rotação, soldabilidade e procedimento de soldagem; inspeção, corrosão e acesso no edifício. '
        'A condição provisória precisa de verificação específica. Nenhuma razão geométrica isolada '
        'certifica ductilidade, estabilidade provisória ou liberação de içamento.')
    _heading(doc, 'Referências e natureza da verificação', 2)
    doc.add_paragraph(NBR + ': 6.1.5.2, força mínima; seção 6.2 e Tabelas 9 e 11, soldas; '
        'seção 6.3 e Tabelas 14 e 16, parafusos, contato e detalhe; 6.5.5 e 6.5.6, cisalhamento e blocos; '
        '5.4.3.1, cortante da alma. Tabela 4, grupo AL3, somente como origem da triagem geométrica declarada. '
        'As referências específicas permanecem vinculadas a cada verificação.')
    doc.add_paragraph('AISC P901 v16, exemplo II.A-2A, pp. IIA-40 a IIA-49: topologia 2L soldada ao apoio '
        'e parafusada à alma. O exemplo publicado tem recorte inferior para montagem; esta rota utiliza '
        'a sequência de uma cantoneira pré-fixa e outra soldada após o posicionamento, sem atribuir crédito '
        'resistente a recorte inexistente. O método de solda desta implementação é elástico e sem crédito '
        'de contato; não reproduz nem calibra o ICR da edição 16.')
    for label, url in (
        ('AISC P901 v16: exemplos de projeto, II.A-2A', 'https://www.aisc.org/media/kybevlwy/first-semester-design-examples-v160.pdf'),
        ('AISC Detailing for Steel Construction: errata da segunda edição', 'https://www.aisc.org/media/a3mjwxyh/errata-to-detailing-for-steel-construction-2nd-ed.pdf'),
        ('AISC Steel Interchange, fevereiro de 2016: excentricidade convencional', 'https://www.aisc.org/globalassets/modern-steel/archives/2016/02/si.pdf'),
        ('AISC Modern Steel, janeiro de 2024: método das soldas B', 'https://www.aisc.org/globalassets/modern-steel/archives/2024/january2024.pdf'),
        ('AISC Steel Interchange, dezembro de 2023: formulação elástica com contato', 'https://www.aisc.org/globalassets/modern-steel/archives/2023/december2023.pdf'),
    ):
        hyperlink(doc.add_paragraph(), label, url)
    doc.add_paragraph('Formulação suplementar: equilíbrio de duas linhas verticais independentes e envelope '
        'elástico de seção de cada aba soldada. A hipótese convencional de flexibilidade fora do plano '
        'é explicitamente limitada. O memorial não é uma validação experimental ou um procedimento executivo.')


def create_report(c, result=None):
    """Return editable DOCX bytes, always re-evaluating c; never trust result."""
    # Supplied results may be stale, forged or belong to another family. Do not
    # read them, merge them, serialize them or use them for any display decision.
    current = evaluate(c)
    doc = Document()
    section = doc.sections[0]
    section.page_width = Inches(8.27)
    section.page_height = Inches(11.69)
    section.top_margin = section.bottom_margin = Inches(.55)
    section.left_margin = section.right_margin = Inches(.60)
    for name in ('Normal', 'Title', 'Heading 1', 'Heading 2', 'List Bullet'):
        style = doc.styles[name]
        style.font.name = 'Arial'
        style.font.color.rgb = RGBColor(0, 0, 0)
    for style in doc.styles:
        for border in style.element.xpath('.//w:pBdr'):
            border.getparent().remove(border)
    doc.styles['Normal'].font.size = Pt(9)
    doc.styles['Normal'].paragraph_format.space_after = Pt(5)
    doc.styles['Title'].font.size = Pt(20)
    doc.styles['Heading 1'].font.size = Pt(12)
    doc.styles['Heading 2'].font.size = Pt(10)
    for name in ('Heading 1', 'Heading 2'):
        doc.styles[name].paragraph_format.keep_with_next = True
    doc.core_properties.title = 'Memória de cálculo de duas cantoneiras soldadas à mesa do pilar'
    doc.core_properties.subject = 'Ligação 2L, alma única, dois planos de corte e estado final'
    doc.core_properties.author = 'LRO Soluções de engenharia LTDA.'
    doc.add_paragraph('Duas cantoneiras soldadas à mesa do pilar', style='Title')
    doc.add_paragraph('Memória de cálculo da ligação 2L para cortante descendente · estado final')
    doc.add_paragraph(_value(getattr(c, 'project', 'Entrada sem projeto')))
    status = current.get('status', 'NOT_EVALUATED')
    paragraph = doc.add_paragraph()
    paragraph.add_run(STATUS.get(status, status)).bold = True
    doc.add_paragraph(status)
    if _approved(current):
        summary = current['summary']
        doc.add_paragraph('Atendimento local no domínio declarado. Governa ' + summary.get('governing_label', '') +
            ', com η adotado=' + _value(summary.get('governing_utilization')) + ', η real=' +
            _value(summary.get('actual_governing_utilization')) + ' e capacidade equivalente de V=' +
            _kn(summary.get('equivalent_total_V_capacity_N')) + ' kN.')
    else:
        doc.add_paragraph('SEM APROVAÇÃO LOCAL. Revise os bloqueios e os resultados da entrada atual.')
    doc.add_paragraph(SCOPE)
    doc.add_paragraph('Duas cantoneiras físicas, uma alma de viga, parafusos comuns em dois planos de corte. '
        'Cada cantoneira recebe Vd/2. Cada apoio tem um filete vertical no toe e retorno superior curto '
        'não creditado. Sem solda inferior, solda no talão, solda na viga ou parafuso no apoio.')
    doc.add_paragraph('Somente o estado final após soldagem de campo e instalação/aperto de todos os parafusos '
        'é verificado. Não há aprovação da fase provisória nem autorização para liberar o içamento.')
    doc.add_paragraph('Tipo: ' + CONNECTION_TYPE + '. Versão: ' + COMPONENT_VERSION + '. '
        'Este arquivo reavalia a entrada atual; resultados fornecidos externamente são ignorados.')
    _scope_gates(doc, current)
    _section(doc)
    _inputs(doc, c)
    _loads_and_scope(doc, c, current)
    _geometry(doc, c, current)
    _weld(doc, current)
    _section_envelope(doc, current)
    _component_derivations(doc, c, current)
    _checks(doc, current)
    _closing(doc, current)
    drawable = isinstance(c, WeldedSupportDoubleAngle) and not input_errors(c)
    if drawable:
        from .welded_support_double_angle_drawing import image_bytes
        sheet = _section(doc, landscape=True)
        sheet.page_width = Inches(16.54)
        sheet.page_height = Inches(11.69)
        _heading(doc, 'Desenho da ligação em folha A3')
        paragraph = doc.add_paragraph()
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        paragraph.add_run().add_picture(BytesIO(image_bytes(c, current)), width=Inches(12.65))
        doc.add_paragraph('Esquema da entrada atual, estado final. Não substitui detalhamento executivo, '
            'verificação provisória ou procedimento de montagem; não autoriza liberar o içamento.')
    else:
        doc.add_paragraph('Entrada inválida sem esquema dimensionado. Os dados informados e erros '
            'permanecem registrados; nenhum desenho de uma configuração anterior é reutilizado.')
    footer = doc.sections[0].footer.paragraphs[0]
    footer.add_run(BRAND + '  |  Página ')
    field = OxmlElement('w:fldSimple')
    field.set(qn('w:instr'), 'PAGE')
    footer._p.append(field)
    for run in footer.runs:
        run.font.size = Pt(7)
    stream = BytesIO()
    doc.save(stream)
    return stream.getvalue()
