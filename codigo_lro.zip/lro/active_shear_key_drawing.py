"""True active-strip geometry and signed, alternative key load cases.

The ignored steel remains drawn. Contact bands represent exact persisted
intervals; their transverse display thickness is symbolic. No contact area or
force sharing is inferred by this presentation layer.
"""
from .display_precision import display_format, display_value
from io import BytesIO
from .drawing_annotations import dimension
import math

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Polygon, FancyArrowPatch

INK = '#20354a'
ACTIVE = '#d6a065'
INACTIVE = '#c7cdd2'
CONTACT = '#4f947a'
EXCLUDED = '#b65a51'
WELD = '#705995'
PATHS = ('cross_active_plate', 'w_flange_plates')


def _missing_intervals(width, intervals):
    """Complement in the physical face, without merging credited steel."""
    current = -width / 2
    missing = []
    for lo, hi in sorted(intervals):
        if lo > current:
            missing.append((current, lo))
        current = max(current, hi)
    if current < width / 2:
        missing.append((current, width / 2))
    return missing


def _weld_intervals(key, plate_id, sign):
    """Actual paired face runs, when explicitly provided, never a default."""
    geometry = getattr(key, 'weld_geometry', {}) or {}
    plate = geometry.get(plate_id, {})
    if not isinstance(plate, dict):
        return []
    value = plate.get(sign, [])
    if isinstance(value, dict):
        value = value.get('intervals', [])
    return value if isinstance(value, (tuple, list)) else []


def image_bytes(c, r=None, fmt='png'):
    """Render only a valid component result; never manufacture missing data."""
    if r is None:
        from .base_plate import evaluate
        r = evaluate(c)
    data = r.geometry.get('active_key', {})
    if c.shear_path not in PATHS or not data.get('plates'):
        raise ValueError('A chave por chapas ativas exige geometria e resultado local válidos.')
    with plt.rc_context({'font.family': 'DejaVu Sans', 'font.size': 9, 'svg.fonttype': 'none'}):
        fig = _figure(c, data)
        output = BytesIO()
        fig.savefig(output, format=fmt, dpi=170, facecolor='white')
        plt.close(fig)
        return output.getvalue()


def _figure(c, data):
    key = c.active_key
    plates = data['plates']
    is_w = c.shear_path == 'w_flange_plates'
    H, g, L, B = key.H, c.grout_t, c.L, c.B
    z_R = data['z_R']
    margin = max(42., L * .11, B * .13, g * .8)
    cases = data['allocation_cases']
    fig = plt.figure(figsize=(13.5, 10), layout='constrained')
    grid = fig.add_gridspec(3, 2, height_ratios=(3.7, 1.65, 1.45))
    plan = fig.add_subplot(grid[0, 0])
    section = fig.add_subplot(grid[0, 1])
    case_axes = [fig.add_subplot(grid[1, i]) for i in range(2)]
    notes = fig.add_subplot(grid[2, :])
    for ax in (plan, section):
        ax.set_aspect('equal')
        ax.axis('off')
    for ax in (*case_axes, notes):
        ax.axis('off')

    def rect(ax, x, y, w, h, color, gid, **kw):
        patch = Rectangle((x, y), w, h, facecolor=color, edgecolor=INK, lw=.8, **kw)
        patch.set_gid(gid)
        ax.add_patch(patch)
        return patch

    def text(ax, x, y, label, **kw):
        return ax.text(x, y, label, color=INK, fontsize=8, **kw)

    def arrow(ax, tail, head, gid, color=INK):
        patch = FancyArrowPatch(tail, head, arrowstyle='-|>', mutation_scale=11, lw=1.25, color=color)
        patch.set_gid(gid)
        ax.add_patch(patch)
        return patch

    def dim(ax, x1, y1, x2, y2, label):
        side=(-1 if x1>0 else 1) if x1==x2 else (1 if y1>0 else -1)
        return dimension(ax,(x1,y1),(x2,y2),label,fontsize=8,
                         rotation=90 if x1==x2 else 0,color=INK,pad=1,lw=.6,short_side=side)

    # Plan axes use true x/y dimensions, independent of column profile geometry.
    plan.set_title('PLANTA DA CHAVE · x / y', loc='left', fontsize=11, fontweight='bold', color=INK)
    rect(plan, -L/2, -B/2, L, B, '#e8eef2', 'active_baseplate_plan')
    if is_w:
        rect(plan, -key.d/2+key.tf, -key.tw/2, key.d-2*key.tf, key.tw,
             INACTIVE, 'inactive_web_plan', hatch='///')
        # Draw sourced rolled root radii as physical but inactive steel.
        # The concave quarter circle joins the flange and web tangencies.
        if key.product == 'rolled' and key.radius:
            radius = key.radius
            for sx in (-1, 1):
                for sy in (-1, 1):
                    xf, yw = key.d/2-key.tf, key.tw/2
                    arc = [(sx*(xf-radius+radius*math.cos(-math.pi*j/32)),
                            sy*(yw+radius+radius*math.sin(-math.pi*j/32))) for j in range(17)]
                    patch = Polygon([(sx*xf, sy*yw), *arc], closed=True,
                                    facecolor=INACTIVE, edgecolor=INK, lw=.65, hatch='///')
                    patch.set_gid(f'inactive_root_radius_{display_value(sx)}_{display_value(sy)}')
                    plan.add_patch(patch)
    else:
        rect(plan, -key.secondary_length/2, -key.secondary_t/2,
             key.secondary_length, key.secondary_t, INACTIVE, 'inactive_crossing_plan', hatch='///')
    band = max(2., min(5., L * .009))
    for plate in plates:
        pid, x, width, t = plate['id'], plate['x'], plate['b_steel'], plate['t']
        rect(plan, x-t/2, -width/2, t, width, ACTIVE, 'active_plate_plan_'+pid)
        text(plan, x, width/2+margin*.19, pid, ha='center', fontweight='bold')
        for sign, direction in (('positive', 1), ('negative', -1)):
            xface = x + direction*t/2
            xband = xface if direction > 0 else xface-band
            intervals = plate['contact_by_sign'][sign]
            for j, (lo, hi) in enumerate(intervals):
                rect(plan, xband, lo, band, hi-lo, CONTACT, f'contact_{display_value(pid)}_{display_value(sign)}_{display_value(j)}', alpha=.95)
            for j, (lo, hi) in enumerate(_missing_intervals(width, intervals)):
                rect(plan, xband, lo, band, hi-lo, EXCLUDED, f'excluded_{display_value(pid)}_{display_value(sign)}_{display_value(j)}', hatch='xx')
            for j, (lo, hi) in enumerate(_weld_intervals(key, pid, sign)):
                line, = plan.plot([xface, xface], [lo, hi], color=WELD, lw=2.8, ls='--')
                line.set_gid(f'root_weld_{display_value(pid)}_{display_value(sign)}_{display_value(j)}')
    dim(plan, -L/2, -B/2-margin*.50, L/2, -B/2-margin*.50, f"L = {display_format(L, 'g')}")
    dim(plan, -L/2-margin*.5, -B/2, -L/2-margin*.5, B/2, f"B = {display_format(B, 'g')}")
    physical_width = plates[0]['b_steel']
    dim(plan, L/2+margin*.48, -physical_width/2, L/2+margin*.48, physical_width/2,
        f"b aço = {display_format(physical_width, 'g')}")
    if is_w:
        dim(plan, -key.d/2, -B/2-margin, key.d/2, -B/2-margin, f"d = {display_format(key.d, 'g')}")
    else:
        dim(plan, -key.secondary_length/2, -B/2-margin, key.secondary_length/2,
            -B/2-margin, f"l secundária = {display_format(key.secondary_length, 'g')}")
    axis_y = B/2 + margin*.8
    arrow(plan, (-L*.28, axis_y), (-L*.28+margin*.7, axis_y), 'active_axis_x')
    text(plan, -L*.28+margin*.8, axis_y, '+x / V positivo', va='center')
    arrow(plan, (L*.30, axis_y-margin*.2), (L*.30, axis_y+margin*.5), 'active_axis_y')
    text(plan, L*.30+margin*.1, axis_y+margin*.4, '+y')
    text(plan, -L/2, -B/2-margin*1.48, 'Verde: contato exposto nas faces ±x; vermelho: faixa excluída.')
    text(plan, -L/2, -B/2-margin*1.85, 'Hachura cinza: aço inativo, sem resistência ou enrijecimento creditado.')
    plan.set_xlim(-L/2-margin*.9, L/2+margin*.9)
    plan.set_ylim(-B/2-margin*2.2, B/2+margin*1.5)

    # z is positive downward; this view is drawn in -z, with the physical root at 0.
    section.set_title('CORTE / PROJEÇÃO x z · COTAS REAIS', loc='left', fontsize=11, fontweight='bold', color=INK)
    bottom = -H-margin*.7
    rect(section, -L/2, bottom, L, -g-bottom, '#e6e4df', 'active_concrete', hatch='..')
    grout = Polygon([(-L/2, 0), (L/2, 0), (L/2+g, -g), (-L/2-g, -g)],
                    closed=True, facecolor='#f3e7d3', edgecolor=INK, lw=.8)
    grout.set_gid('active_actual_grout')
    section.add_patch(grout)
    rect(section, -L/2, 0, L, c.tp, '#8faec1', 'active_baseplate_section')
    inactive_length = key.d-2*key.tf if is_w else key.secondary_length
    rect(section, -inactive_length/2, -H, inactive_length, H, INACTIVE,
         'inactive_projection_section', hatch='///', alpha=.4, linestyle='--')
    for plate in plates:
        pid, x, t = plate['id'], plate['x'], plate['t']
        rect(section, x-t/2, -H, t, H, ACTIVE, 'active_plate_section_'+pid)
        text(section, x, -H-margin*.2, pid, ha='center', va='top')
        if c.V:
            direction = 1 if c.V > 0 else -1
            xface = x+direction*t/2
            qwidth = margin*.20
            # Pressure region is in the exposed strips, not the projected web plane.
            rect(section, xface if direction > 0 else xface-qwidth, -H, qwidth, H-g,
                 '#d7e6dd', 'active_pressure_extent_'+pid, alpha=.75)
    dim(section, L/2+margin*.40, 0, L/2+margin*.40, c.tp, f"tp = {display_format(c.tp, 'g')}")
    dim(section, -L/2-margin*.60, -g, -L/2-margin*.60, 0, f"g = {display_format(g, 'g')}")
    dim(section, -L/2-margin*.22, -H, -L/2-margin*.22, 0, f"H = {display_format(H, 'g')}")
    dim(section, L/2+margin*.45, -H, L/2+margin*.45, -g, f"H − g = {display_format(H - g, 'g')}")
    direction = 1 if c.V >= 0 else -1
    if c.V:
        arrow(section, (-direction*L*.17, c.tp), (direction*L*.17, c.tp), 'active_applied_shear')
        arrow(section, (direction*L*.32, -z_R), (-direction*L*.32, -z_R), 'active_total_reaction', CONTACT)
    text(section, 0, c.tp+margin*.24, f"V = {display_format(c.V / 1000, '+.3f')} kN · face superior", ha='center')
    text(section, 0, c.tp+margin*.65, f"M informado = {display_format(c.M / 1000000.0, '+.3f')} kN·m", ha='center')
    text(section, 0, -z_R-margin*.22, f"ΣR = −V; zR = {display_format(z_R, 'g')} mm", ha='center',
         bbox={'facecolor': 'white', 'edgecolor': 'none', 'pad': 1})
    text(section, -L/2, bottom-margin*.35, 'z positivo para baixo, a partir da face inferior (z = 0).')
    text(section, -L/2, bottom-margin*.72, 'Pressão somente nas faixas expostas, entre z = g e H.')
    text(section, -L/2, bottom-margin*1.09, 'Aço inativo em projeção; sem pressão creditada em sua faixa.')
    section.set_xlim(-L/2-margin*.9, L/2+margin*.9)
    section.set_ylim(bottom-margin*1.5, c.tp+margin*1.25)
    if getattr(c,'stiffener_detail','none')=='web_pair_visual':
        from .base_plate_drawing import _draw_visual_ribs
        p=c.column;column_height=c.stiffener_height*1.1
        rect(section,-p.d/2,c.tp,p.d,column_height,'#edf0f3','visual_column_web_section',zorder=.5)
        rect(section,-p.d/2,c.tp,p.tf,column_height,'#cbd3da','visual_column_flange_left',zorder=.5)
        rect(section,p.d/2-p.tf,c.tp,p.tf,column_height,'#cbd3da','visual_column_flange_right',zorder=.5)
        _draw_visual_ribs(plan,section,c)
        section.set_ylim(bottom-margin*1.5,c.tp+column_height+margin*1.25)


    # Every panel is a simultaneous allocation. The envelope is NEVER plotted
    # as two |V| flange forces in the same panel.
    for case_index, ax in enumerate(case_axes):
        if case_index >= len(cases):
            ax.text(0, .92, 'EQUILÍBRIO GLOBAL', fontsize=10, color=INK, fontweight='bold', transform=ax.transAxes)
            ax.text(0, .65, 'ΣFi = V; Σmi = V (H + g)/2', fontsize=10, color=INK, transform=ax.transAxes)
            ax.text(0, .40, 'Separação das mesas paralela a V: sem parcela d/2.' if is_w else
                    'Chapa primária passante: V total; secundária sem crédito.', fontsize=8, color=INK, transform=ax.transAxes)
            ax.text(0, .16, 'Reações do concreto em sentido oposto a Fi.', fontsize=8, color=INK, transform=ax.transAxes)
            continue
        forces = cases[case_index]
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        title = 'ALOCAÇÃO SIMULTÂNEA' if len(cases) == 1 else f'CASO ALTERNATIVO {display_value(case_index + 1)}'
        ax.text(0, .94, title, fontsize=10, fontweight='bold', color=INK)
        for i, (plate, force) in enumerate(zip(plates, forces)):
            y = .64-i*.27
            x = .05+i*.02
            if force:
                s = 1 if force > 0 else -1
                arrow(ax, (.26-s*.07, y), (.26+s*.07, y), f"active_case_{display_value(case_index)}_{display_value(plate['id'])}_force")
            ax.text(x, y, plate['id'], fontsize=9, color=INK, va='center', fontweight='bold')
            ax.text(.40, y, f"F = {display_format(force / 1000, '+.3f')} kN; m raiz = {display_format(force * z_R / 1000000.0, '+.3f')} kN·m",
                    fontsize=8, color=INK, va='center')
        ax.text(0, .07, f"ΣF = {display_format(sum(forces) / 1000, '+.3f')} kN = V; momentos com sinal.", fontsize=8, color=INK)

    # Keep engineering qualification in the exported picture as well as Word.
    lines = [
        data['scope_label'],
        'Partilha: '+data['sharing_label']+(' · casos alternativos, nunca 2V simultâneo.' if key.sharing == 'unknown_envelope' and is_w else ''),
        f"eV = tp + (H + g)/2 = {display_format(data['eV'], 'g')} mm; ΔM = V · eV = {display_format(data['delta_M'] / 1000000.0, '+.3f')} kN·m.",
        f"Mef = M + ΔM = {display_format(c.M / 1000000.0, '+.3f')} + ({display_format(data['delta_M'] / 1000000.0, '+.3f')}) = {display_format(data['M_effective'] / 1000000.0, '+.3f')} kN·m. Aplicado uma vez.",
        'Laranja: aço físico contínuo; só faixas verdes recebem crédito local. Larguras não se somam como capacidade do dispositivo.',
        ('Roxo tracejado: segmentos de solda de raiz informados; resistência não verificada.' if getattr(key, 'weld_geometry', {}) else 'Soldas de raiz: geometria não informada; sem continuidade ou resistência presumida.'),
        'Verificações locais: '+('ATENDEM' if data['local_pass'] else 'NÃO ATENDEM')+' ao modelo. Fixação e dispositivo completo pendentes. M positivo horário.',
    ]
    if is_w and key.product == 'rolled' and key.radius is None:
        lines.insert(-1, 'Raio/contorno real da junção não especificado: vermelho é exclusão de contato, não um raio zero presumido.')
    line_step = .14 if len(lines) <= 7 else .88/(len(lines)-1)
    for i, line in enumerate(lines):
        notes.text(0, .98-i*line_step, line, fontsize=8.4 if i else 9.3, color=INK, va='top',
                   fontweight='bold' if i == 0 else 'normal', transform=notes.transAxes)
    return fig
