"""Bounded DG6 B9 gravity seat: 2 x 2 M20 8.8N/S on a W column flange.

Equations: DG6 (2007) pp35–36; HB1 (2007) pp15–18, 26–27, 78.
Inputs specify engineering dimensions; they do not certify installed hardware.
"""
import math
from .beam_direct_seat import _row
from .models import STEELS


def angle_yield(thickness):
    return 320. if thickness<11. else 300. if thickness<=17. else 280.


def upper_limit(fy, length, thickness, radius):
    """Positive root x=Rf/(fy La ta) of 16x^4+x^2+(2-4ra/ta)x-2.

    Polynomial is strictly convex for x>=0, starts negative, tends to +infinity:
    exactly one positive root. Bisection returns its lower bracket, conservative.
    """
    a=2.-4.*radius/thickness
    def f(x):return 16.*x**4+x*x+a*x-2.
    lo,hi=0.,1.
    while f(hi)<0.:hi*=2.
    for _ in range(100):
        mid=(lo+hi)/2.
        if mid==lo or mid==hi:break
        if f(mid)>0.:hi=mid
        else:lo=mid
    rf=lo*fy*length*thickness
    return rf,.9*rf,lo,f(lo)


def add_checks(c,out,force,geom):
    p=out['parameters'];rows=out['checks']
    geom('bolted_beam_web_domain','Alma apoiada no domínio experimental B9',c.beam.tw,14.3,'<=')
    fy=angle_yield(c.angle_thickness)
    rf,vf,x,residual=upper_limit(fy,c.angle_length,c.angle_thickness,c.angle_root_radius)
    p.update(bolted_Rf_N=rf,bolted_Vf_N=vf,bolted_root_x=x,bolted_root_residual=residual)
    rows.append(_row('bolted_seat_upper_limit','Limite superior Vf da cantoneira parafusada',force,vf,
        reference='ASI DG6 B9, check 4, p.35',equation='Vf=0,9 Rf; 16x⁴+x²+(2−4ra/ta)x−2=0; x=Rf/(fy La ta)',
        notes='Raiz positiva única, extremo inferior da bisseção; limite adicional, não substitui alma, flexão ou fixação.'))
    out['bolted_model_complete']=False
    needed=('bolt_top','bolt_pitch','bolt_gauge','column_top_edge','column_bottom_edge','bolt_tool_radius','bolt_tool_length')
    labels={'bolt_top':'distância do topo à primeira fila','bolt_pitch':'passo vertical','bolt_gauge':'gabarito transversal','column_top_edge':'borda superior da coluna','column_bottom_edge':'borda inferior da coluna','bolt_tool_radius':'raio da ferramenta','bolt_tool_length':'comprimento da ferramenta'}
    absent=[labels[k] for k in needed if getattr(c,k)<=0.]
    if absent:
        out['bolted_missing']=['Informar dimensões da fixação B9: '+', '.join(absent)+'. Projetos antigos não recebem geometria presumida.']
        return
    db,dh,ac,fub=20.,22.,225.,830.
    t,tc=c.angle_thickness,c.support.tf
    top,pitch,gauge=c.bolt_top,c.bolt_pitch,c.bolt_gauge
    bottom=c.angle_vertical-top-pitch
    side=(c.angle_length-gauge)/2.
    colside=(c.support.bf-gauge)/2.
    min_t=min(t,tc)
    geom('bolt_column_covers_top','Mesa da coluna cobre o topo do assento',c.column_top_edge,top)
    geom('bolt_column_covers_bottom','Mesa da coluna cobre a extremidade inferior do assento',c.column_bottom_edge,bottom)
    # All free edges use the conservative sheared-edge value (1.75d), no
    # undocumented edge-quality relaxation. No oversize/slotted/packed connection.
    for key,name,val in (
        ('bolt_top_edge','Borda superior do grupo na cantoneira',top),
        ('bolt_bottom_edge','Borda inferior da cantoneira',bottom),
        ('bolt_side_edge','Bordas laterais da cantoneira',side),
        ('bolt_column_side_edge','Bordas laterais da mesa do pilar',colside),
        ('bolt_column_top_edge','Borda superior da coluna',c.column_top_edge),
        ('bolt_column_bottom_edge','Borda inferior da coluna',c.column_bottom_edge)):
        geom(key,name,val,1.75*db)
    for key,name,val in [('bolt_pitch','Passo vertical dos parafusos',pitch),('bolt_gauge','Gabarito transversal dos parafusos',gauge)]:
        geom(key+'_min',name+' mínimo',val,2.5*db)
        geom(key+'_max',name+' máximo',val,min(15*min_t,200.),'<=')
    geom('bolt_outer_pitch','Passo de linha externa na direção de V',pitch,min(4*min_t+100.,200.),'<=')
    geom('bolt_angle_edge_max','Maior distância à borda mais próxima da cantoneira',max(min(top,side),min(bottom,side)),min(12*min_t,150.),'<=')
    geom('bolt_column_edge_max','Maior distância à borda mais próxima da coluna',max(min(c.column_top_edge,colside),min(c.column_bottom_edge,colside)),min(12*min_t,150.),'<=')
    geom('bolt_no_packer','Sem calço neste caminho B9',c.packer_thickness,0.,'<=')
    # r=(d-2tf-clear)/2 is the occupied root envelope declared by the actual
    # W profile. Centre-lines must clear it AND the specified tool envelope.
    root=max(0.,(c.support.d-2*tc-c.support.clear)/2.)
    geom('bolt_tool_radius_min','Raio mínimo do envelope de montagem M20',c.bolt_tool_radius,24.15)
    geom('bolt_tool_length_min','Comprimento mínimo do envelope de montagem M20',c.bolt_tool_length,65.)
    geom('bolt_angle_root_access','Acesso junto à raiz da cantoneira',top-t-c.angle_root_radius,c.bolt_tool_radius)
    geom('bolt_column_root_access','Acesso atrás da mesa junto à raiz do pilar',gauge/2.-c.support.tw/2.-root,c.bolt_tool_radius)
    geom('bolt_tool_between_rows','Acesso entre parafusos de filas vizinhas',pitch,2*c.bolt_tool_radius)
    geom('bolt_tool_between_columns','Acesso entre colunas de parafusos',gauge,2*c.bolt_tool_radius)
    geom('bolt_rear_access','Acesso axial entre mesas do pilar',c.support.d-2*tc,c.bolt_tool_length)
    # In angle: bolts act upward, nearest conservative free end is top edge;
    # in column: force downward. Adjacent holes limit a_e for both plies.
    ae_angle=min(top-1.,pitch-dh/2.-1.)
    ae_column=min(c.column_bottom_edge-1.,pitch-dh/2.-1.)
    p.update(bolt_diameter_mm=db,bolt_hole_mm=dh,bolt_count=4,bolt_core_area_mm2=ac,
             bolt_fu_MPa=fub,bolt_phi=.8,bolt_kr=1.,bolt_angle_fu_MPa=440.,
             bolt_angle_ae_mm=ae_angle,bolt_column_ae_mm=ae_column,
             bolt_angle_bottom_mm=bottom,bolt_angle_side_mm=side,bolt_column_side_mm=colside,
             bolt_column_root_envelope_mm=root)
    if min(ae_angle,ae_column,bottom,side,colside)<=0.:
        out['bolted_missing']=['Geometria sem ligamento físico positivo; resistências dos furos indisponíveis.']
        return
    shear=.8*.62*fub*ac
    angle_bearing=.9*3.2*db*t*440.
    angle_tear=.9*ae_angle*t*440.
    column_bearing=.9*3.2*db*tc*STEELS[c.support_steel].fu
    column_tear=.9*ae_column*tc*STEELS[c.support_steel].fu
    for key,name,r,eq in (
        ('bolted_shear','Quatro M20: corte simples com rosca no plano',shear,'4 × 0,8 × 0,62 × 830 × 225; kr=1'),
        ('bolted_angle_bearing','Contato nos furos da cantoneira',angle_bearing,'4 × 0,9 × 3,2 db ta fu,a'),
        ('bolted_angle_tearout','Rasgamento entre furos / borda da cantoneira',angle_tear,'4 × 0,9 × ae,a ta fu,a'),
        ('bolted_column_bearing','Contato nos furos da mesa do pilar',column_bearing,'4 × 0,9 × 3,2 db tf,c fu,c'),
        ('bolted_column_tearout','Rasgamento entre furos / borda da mesa do pilar',column_tear,'4 × 0,9 × ae,c tf,c fu,c')):
        rows.append(_row(key,name,force,4*r,reference='DG6 B9 check 6 p.36; HB1 pp.15–18',equation=eq,
            notes='Quatro parafusos 2×2; força vertical centrada, V/4 na fixação à coluna. Não são parafusos de localização da viga.'))
    p['bolted_Vg_N']=4*min(shear,angle_bearing,angle_tear,column_bearing,column_tear)
    out['bolted_model_complete']=True
    out['bolted_execution_requirements']=[
        'B9: quatro M20 classe 8.8/S conforme AS/NZS 1252, rosca incluída em um plano de corte, fu=830 MPa, Ac=225 mm²; furos-padrão 22 mm, sem rasgos, calços, pré-tração creditada ou resistência ao deslizamento.',
        'Parafusos fixam somente o assento à mesa do pilar. Parafusos localizadores da mesa inferior da viga e cantoneira de contenção seguem DG6 B1–B4, permitem rotação e não recebem V/4.',
        'As distâncias de borda da coluna são medidas a partir da linha superior/inferior do grupo até as bordas reais; nenhum furo, abertura, emenda, apoio ou obstáculo adicional no trecho de transferência e montagem. Coluna contínua no detalhe, sem ação concorrente de outro assento nessa face.',
        'Cabeças no lado da cantoneira e porcas atrás da mesa do pilar; inserção antes de apoiar a viga. Envelope de ferramenta informado inclui cabeça, porca e arruelas; mínimos de referência para soquete manual M20: raio 24,15 mm e comprimento 65 mm (HB1 p.12). Confirmar ferramental real; a geometria verifica espaço, não certifica execução.',
        'Seção líquida da coluna sob N/M e estabilidade do membro são verificações externas. Blocos de grupos arbitrários, furos adicionais, entalhes e recortes não pertencem à topologia B9 especificada; rasgamento individual não prova todos esses caminhos.',
        'Modelo empírico DG6 B6/B9: fixação dimensionada ao corte vertical, tração adicional por excentricidade desprezada conforme DG6 B6 p.26; momento excêntrico entregue ao dimensionamento da coluna. Somente carregamento vertical estático, sem forças horizontais, tração normal, fadiga ou sismo.'
    ]
