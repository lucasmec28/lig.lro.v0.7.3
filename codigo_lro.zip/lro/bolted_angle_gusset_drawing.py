"""Current-input physical views of the complete one-row bolted gusset route.

Physical hole diameters, one versus two shear planes, the single gusset and
shared two-fillet root are shown. Unknown catalog corners stay interrupted.
"""
from .display_precision import display_format, display_value
from dataclasses import asdict
from io import BytesIO
import hashlib
import json
import math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Arc, Circle, Polygon, Rectangle
from .drawing_annotations import dimension, rendered_wrap
from .bolted_angle_gusset import COMPONENT_VERSION
from .bolted_angle_gusset_presentation import selected_angle, angle_identity, angle_detail_disclosure

INK='#243749'; MUTED='#667788'; PLATE='#dce5ec'; ANGLE='#80b4c0'; WELD='#b13b39'; BOLT='#454f60'
STATUS={'INVALID_INPUT':'Dados inválidos','INVALID_GEOMETRY':'Geometria inválida','NUMERICAL_FAILURE':'Falha numérica',
        'OUTSIDE_SCOPE':'Fora do domínio qualificado','DETAILING_PENDING': 'MONTAGEM PENDENTE · GEOMETRIA REAL NECESSÁRIA', 'NOT_VERIFIED':'Montagem ou condições pendentes',
        'DETAIL_FAIL':'Não atende ao detalhamento','DETAILING_FAIL':'Não atende ao detalhamento',
        'INCOMPLETE_CHECKS':'Verificações incompletas','COMPLETE_CHECKS_FAIL':'Não atende às verificações locais',
        'LOCAL_CHECKS_FAIL':'Não atende às verificações locais','VERIFIED_SUBCHECK_FAIL':'Não atende às verificações locais',
        'LOCAL_CHECKS_PASS_WITHIN_SCOPE':'Atende localmente no domínio',
        'COMPLETE_LOCAL_CHECKS_PASS_WITHIN_SCOPE':'Atende localmente no domínio',
        'COMPLETE_CHECKS_PASS_WITHIN_SCOPE':'Atende localmente no domínio'}


def input_fingerprint(c):
    try: native=c.to_dict()
    except (TypeError,ValueError,ArithmeticError): native=asdict(c)
    return hashlib.sha256(json.dumps(native,ensure_ascii=False,sort_keys=True,separators=(',',':'),default=str).encode()).hexdigest()


def validated_result(c,result=None):
    """Caller-supplied results never authorize geometry or a favorable label."""
    from .bolted_angle_gusset import evaluate
    try: return evaluate(c)
    except (TypeError,ValueError,ArithmeticError) as exc:
        return {'status':'NUMERICAL_FAILURE','global_pass':False,'geometry':{'valid':False},
                'summary':{'complete_checks':False},'checks':[],'cases':[],
                'issues':[{'severity':'error','message':str(exc)}]}


def approved(r):
    return (r.get('global_pass') is True and r.get('geometry',{}).get('valid') is True
            and r.get('summary',{}).get('complete_checks') is True and bool(r.get('checks'))
            and all(x.get('status')=='PASS' for x in r['checks']))


def _n(value,divisor=1):
    try: return display_format(value/divisor,'.6g').replace('.',',')
    except (TypeError,ValueError,OverflowError): return 'não disponível'


def _line(ax,a,b,gid,**style):
    line,=ax.plot([a[0],b[0]],[a[1],b[1]],**style); line.set_gid(gid); return line


def _patch(ax,points,gid,**style):
    obj=Polygon(points,closed=True,**style);obj.set_gid(gid);ax.add_patch(obj);return obj


def _arrow(ax,a,b,gid,color=INK,lw=1.5):
    obj=ax.annotate('',xy=b,xytext=a,arrowprops={'arrowstyle':'-|>','color':color,'lw':lw});obj.set_gid(gid);obj.arrow_patch.set_gid(gid);return obj


def _rect(ax,xy,w,h,gid,**style):
    obj=Rectangle(xy,w,h,**style);obj.set_gid(gid);ax.add_patch(obj);return obj


def _section_angle(ax,c,section,sign,dh):
    """Nominal leg surfaces with explicit breaks at unpublished corners."""
    b,t,g,tg=section['leg'],section['t'],c.gauge,c.plate_t
    face='positive' if sign==1 else 'negative'
    z=lambda value:sign*(tg/2+value)
    # Hole splits connected leg; its physical opening is dh, not net deduction.
    for i,(a,end) in enumerate(((-g,-dh/2),(dh/2,b-g))):
        _line(ax,(a,z(0)),(end,z(0)),f'angle_contact_face_{display_value(face)}_{display_value(i)}',color=ANGLE,lw=2.4)
    _line(ax,(-g,z(0)),(-g,z(b)),f'angle_outer_free_leg_face_{display_value(face)}',color=ANGLE,lw=2.4)
    # Missing corner radii are never silently drawn as a square/radius polygon.
    gap=max(t*.5,(b-t)*.16)
    _line(ax,(-g+t,z(t+gap)),(-g+t,z(b-gap)),f'nominal_free_inner_face_{display_value(face)}',color=ANGLE,lw=1.6,ls='--')
    for i,(a,end) in enumerate(((-g+t+gap,-dh/2),(dh/2,b-g-gap))):
        if end>a: _line(ax,(a,z(t)),(end,z(t)),f'nominal_connected_inner_face_{display_value(face)}_{display_value(i)}',color=ANGLE,lw=1.6,ls='--')
    ax.text(-g+t,z(t),'?',fontsize=10,ha='center',va='center',color=MUTED,gid=f'unpublished_heel_face_{display_value(face)}')
    ax.text(b-g,z(t/2),'?',fontsize=9,ha='center',va='center',color=MUTED)
    ax.text(-g+t/2,z(b),'?',fontsize=9,ha='center',va='center',color=MUTED)
    if c.heel_extent is not None:
        _line(ax,(-g+c.heel_extent,z(t)),(-g+c.heel_extent,z(t+20)),f'declared_heel_extent_face_{display_value(face)}',color=WELD,lw=1,ls=':')
    return z


def figure(c,result=None):
    r=validated_result(c,result);geometry=r.get('geometry') or {};angle=selected_angle(c,r)
    project=rendered_wrap('Projeto: '+str(c.project),980,8.5)
    extra=max(0,project.count('\n'))*.16
    height=11.5+extra
    fig=plt.figure(figsize=(14,height),facecolor='white')
    fig._bolted_angle_gusset_result=r;fig._bolted_angle_gusset_fingerprint=input_fingerprint(c)
    def text(x,y,value,gid=None,**kw):
        obj=fig.text(x,y/height,value,color=kw.pop('color',INK),**kw)
        if gid:obj.set_gid(gid)
        return obj
    count=2 if c.arrangement=='2L-T' else 1
    text(.035,11.12+extra,str(c.arrangement)+' PARAFUSADA · CHAPA ÚNICA · RAIZ DUPLA · MESA W',fontsize=15,fontweight='bold')
    text(.965,10.84+extra,'PILAR W' if c.support_member=='column' else 'VIGA W',fontsize=10,ha='right')
    text(.035,10.81+extra,project,fontsize=8.5,va='top')
    text(.035,10.41,STATUS.get(r.get('status'),str(r.get('status'))),'engine_status',fontsize=11,fontweight='bold',color=INK if approved(r) else WELD)
    text(.965,10.41,'Resultado local; não é liberação de fabricação',fontsize=8,ha='right')
    text(.035,10.13,'N total='+_n(c.N,1000)+' kN; N por L='+_n(c.N/count,1000)+' kN; '+str(c.n)+' parafusos físicos; '
         +str(count)+' plano(s) por parafuso. θ='+_n(c.theta_deg)+'° em relação a +s, eixo W.','actual_actions',fontsize=9)
    text(.035,9.89,angle_identity(angle,c.angle_profile)+'; Ag por L='+_n((angle or {}).get('Ag'))+' mm²; ec='+_n((angle or {}).get('centroid'))+' mm.',fontsize=8.5)
    safe=(geometry.get('valid') is True and angle is not None and c.arrangement in ('1L','2L-T') and c.support_face=='flange')
    if not safe:
        text(.055,9.15,'ENTRADA ATUAL SEM GEOMETRIA QUALIFICADA PARA ESTA VISTA','diagnostic_only',fontsize=14,fontweight='bold',color=WELD)
        lines=[angle_detail_disclosure(angle),'Nenhuma geometria anterior ou resultado fornecido pelo chamador foi reaproveitado.']
        lines += [str(x.get('message',x)) for x in r.get('issues') or []]
        text(.055,8.7,rendered_wrap('\n'.join(lines),980,10),fontsize=10,va='top')
        text(.035,.3,COMPONENT_VERSION+' · SHA-256: '+input_fingerprint(c),'input_fingerprint',fontsize=7)
        return fig
    B,H,tg=c.plate_width,c.plate_height,c.plate_t; b,t=angle['leg'],angle['t']
    theta=math.radians(c.theta_deg);co,si=math.cos(theta),math.sin(theta)
    point=lambda u,v:(c.center_s+u*co+v*si,c.center_n+u*si-v*co)
    stations=geometry.get('bolt_stations') or [c.row_offset+(i-(c.n-1)/2)*c.pitch for i in range(c.n)]
    centers=geometry.get('bolt_centers') or [point(u,0) for u in stations]
    # Standard physical diameter is exposed by the kernel, never inferred from dn.
    dh=geometry.get('hole_diameter',c.hole_diameter)
    if isinstance(dh,dict):dh=dh['diameter']
    free=stations[0]-c.angle_end
    end=max(stations[-1]+c.tool_radius+c.fabrication_clearance, (geometry.get('forward_exit') or {}).get('u',stations[-1]+50.)+25.)
    W=geometry['support_catalog']
    elev=fig.add_axes((.04,4.8/height,.56,4.65/height));section=fig.add_axes((.675,5.25/height,.285,3.95/height))
    support=fig.add_axes((.71,1.65/height,.24,3.25/height));longitudinal=fig.add_axes((.04,2.65/height,.56,1.2/height))
    for ax in (elev,section,support,longitudinal):ax.set_aspect('equal');ax.axis('off')
    elev.set_title('Plano da chapa · uma linha física de furos',loc='left',fontsize=10,pad=10)
    _patch(elev,geometry['polygon'],'gusset_polygon',facecolor=PLATE,edgecolor=INK)
    from .gusset_outer_end_drawing import draw as draw_outer_end
    draw_outer_end(elev,geometry,_n,label_offset=(-100,50))
    _rect(elev,(-B/2-30,-W['tf']),B+60,W['tf'],'exterior_W_flange',facecolor='#aab8c4',edgecolor=INK)
    _patch(elev,[point(free,-c.gauge),point(free,b-c.gauge),point(end,b-c.gauge),point(end,-c.gauge)],
           'connected_angle_leg_projection',facecolor=ANGLE,alpha=.65,edgecolor=INK)
    _line(elev,point(free,-c.gauge),point(free,b-c.gauge),'angle_free_end',color=INK,lw=2)
    elev.annotate('Continuação da diagonal',xy=point(end,b-c.gauge),xytext=(20,0),textcoords='offset points',fontsize=7.5,
                  arrowprops={'arrowstyle':'-','color':MUTED},color=MUTED)
    for i,center in enumerate(centers):
        circle=Circle(center,dh/2,facecolor='white',edgecolor=INK,lw=1.2,gid=f'physical_hole_{display_value(i + 1)}');elev.add_patch(circle)
        shaft=Circle(center,c.db/2,facecolor=BOLT,edgecolor=INK,lw=.6,gid=f'physical_bolt_{display_value(i + 1)}');elev.add_patch(shaft)
        elev.annotate(str(i+1),xy=center,xytext=(14,-3),textcoords='offset points',fontsize=8)
        if c.N:
            sign=1 if c.N>0 else -1
            _arrow(elev,point(stations[i]-21*sign,0),point(stations[i]+21*sign,0),f'gusset_hole_force_{display_value(i + 1)}',color=WELD,lw=1)
    _line(elev,(-B/2,0),(B/2,0),'root_weld_line',color=WELD,lw=4)
    p=geometry.get('force_point',(c.center_s,c.center_n));root_x=p[0]-p[1]*co/si
    _line(elev,(root_x,0),point(end+38,0),'nominal_force_line',color=INK,ls='--',lw=1)
    _line(elev,(0,0),(0,0),'root_weld_centroid',color=INK,marker='o',ms=3)
    if c.N:_arrow(elev,point(end-5,0),point(end+(35 if c.N>0 else -40),0),'actual_force_arrow')
    arc=Arc(p,55,55,theta1=0,theta2=c.theta_deg,color=INK,lw=1,gid='brace_angle_arc');elev.add_patch(arc)
    _arrow(elev,p,(p[0]+48,p[1]),'angle_reference_positive_s',color=MUTED,lw=.8)
    elev.text(p[0]+52,p[1]-5,'+s (W)',fontsize=8,color=MUTED)
    elev.text(p[0]+38*math.cos(theta/2),p[1]+38*math.sin(theta/2),'θ='+_n(c.theta_deg)+'°',fontsize=8,ha='center',bbox={'facecolor':'white','edgecolor':'none','pad':1})
    dimension(elev,(-B/2,-45),(B/2,-45),'B='+_n(B),fontsize=8)
    dimension(elev,(B/2+30,0),(B/2+30,H),('H_env=' if geometry.get('outer_end_cut',{}).get('trimmed') else 'H=')+_n(H),fontsize=8,rotation=90)
    elev.text(-B/2,max(H+28,point(end+40,b-c.gauge)[1]+32),'Ø físico='+_n(dh)+'; dn líquido='+_n(geometry.get('net_hole_diameter'))+'; d='+_n(c.db)+'; passo='+_n(c.pitch)+' mm',fontsize=8)
    elev.text(-B/2,-76,'Extremidade livre da L: '+_n(c.angle_end)+' mm antes do 1º furo.\nFuro na L recebe −u; furo na chapa recebe +u.',fontsize=8,va='top')
    elev.set_xlim(min(-B/2-45,root_x-20),B/2+95);elev.set_ylim(-105,max(H+48,point(end+40,b-c.gauge)[1]+52))
    section.set_title('Corte normal à linha dos parafusos · v / z',loc='left',fontsize=10,pad=14)
    xlo,xhi=-c.gauge-20,b-c.gauge+20
    for i,(lo,hi) in enumerate(((xlo,-dh/2),(dh/2,xhi))):
        _rect(section,(lo,-tg/2),hi-lo,tg,f'single_gusset_section_{display_value(i)}',facecolor=PLATE,edgecolor=INK)
    _section_angle(section,c,angle,1,dh)
    if count==2:_section_angle(section,c,angle,-1,dh)
    lower=-tg/2-(t if count==2 else 0);upper=tg/2+t
    washer=c.washer_stack/2
    _rect(section,(-c.db/2,lower-washer-5),c.db,upper-lower+2*washer+10,'through_bolt_shaft',facecolor=BOLT,edgecolor=INK)
    if washer:
        _rect(section,(-c.db,upper),2*c.db,washer,'washer_stack_positive_schematic',facecolor='#aab8c4',edgecolor=INK)
        _rect(section,(-c.db,lower-washer),2*c.db,washer,'washer_stack_negative_schematic',facecolor='#aab8c4',edgecolor=INK)
    _rect(section,(-c.db*.85,upper+washer),c.db*1.7,7,'bolt_head',facecolor=BOLT,edgecolor=INK)
    _rect(section,(-c.db*.8,lower-washer-7),c.db*1.6,7,'bolt_nut',facecolor=BOLT,edgecolor=INK)
    for plane,sign in ((1,1),(2,-1)):
        if plane>count:continue
        z=sign*tg/2
        _line(section,(-c.db*.9,z),(c.db*.9,z),f'shear_plane_{display_value(plane)}',color=WELD,lw=2,ls='--')
        section.annotate('Plano '+str(plane)+'\n'+_n(c.N/count/c.n,1000)+' kN',xy=(c.db/2,z),xytext=(35,sign*27),
                         textcoords='offset points',fontsize=8,ha='left',arrowprops={'arrowstyle':'-','color':WELD},color=WELD)
    dimension(section,(-c.gauge,-b-15),(0,-b-15),'g='+_n(c.gauge),fontsize=8)
    section.text(xlo,b+tg/2+19,('Talões alinhados; abas livres opostas ±z' if count==2 else 'Uma L na face +z; um plano de corte'),fontsize=8)
    section.text(xlo,-b-38,'Chapa única t='+_n(tg)+'; contato direto.\nContorno nominal: raios não publicados não são presumidos.'
                 +('\nArruelas: total '+_n(c.washer_stack)+' mm, repartição esquemática.' if washer else ''),fontsize=7.4,va='top')
    section.set_xlim(xlo-8,xhi+43);section.set_ylim(-b-65,b+tg/2+42)
    support.set_title('Raiz dupla na mesa exterior',fontsize=10,loc='left',pad=10)
    d,bf,tf,tw=W['d'],W['bf'],W['tf'],W['tw'];rw=c.root_weld_leg
    _patch(support,[(-bf/2,0),(bf/2,0),(bf/2,-tf),(tw/2,-tf),(tw/2,-d+tf),(bf/2,-d+tf),(bf/2,-d),
                    (-bf/2,-d),(-bf/2,-d+tf),(-tw/2,-d+tf),(-tw/2,-tf),(-bf/2,-tf)],'W_section',facecolor='#becbd5',edgecolor=INK)
    _rect(support,(-tg/2,0),tg,80,'root_single_gusset',facecolor=PLATE,edgecolor=INK)
    _patch(support,[(-tg/2,0),(-tg/2-rw,0),(-tg/2,rw)],'root_fillet_left',facecolor=WELD)
    _patch(support,[(tg/2,0),(tg/2+rw,0),(tg/2,rw)],'root_fillet_right',facecolor=WELD)
    _line(support,(0,95),(0,-d-10),'W_web_centerline',color=MUTED,ls='--',lw=.8)
    support.annotate('2 filetes de '+_n(rw)+' mm',xy=(tg/2+rw,0),xytext=(30,55),fontsize=8,arrowprops={'arrowstyle':'-'})
    support.text(-bf/2,-d-28,str(W.get('name',c.support_profile))+'\nMesa/alma reais do catálogo W',fontsize=8,va='top')
    support.set_xlim(-bf/2-30,bf/2+70);support.set_ylim(-d-64,110)
    lo,hi=-c.support_end_left,c.support_end_right
    _rect(longitudinal,(lo,-bf/2),hi-lo,bf,'support_longitudinal_flange',facecolor=PLATE,edgecolor=INK)
    _line(longitudinal,(lo,0),(hi,0),'support_longitudinal_axis',color=MUTED,ls='--',lw=.8)
    for sign in (-1,1):_line(longitudinal,(-B/2,sign*tg/2),(B/2,sign*tg/2),'root_weld_'+('negative' if sign<0 else 'positive'),color=WELD,lw=2)
    dimension(longitudinal,(lo,-bf/2-45),(-B/2,-bf/2-45),_n(c.support_end_left-B/2)+' livre',fontsize=8)
    dimension(longitudinal,(-B/2,-bf/2-45),(B/2,-bf/2-45),'B='+_n(B),fontsize=8)
    dimension(longitudinal,(B/2,-bf/2-45),(hi,-bf/2-45),_n(c.support_end_right-B/2)+' livre',fontsize=8)
    longitudinal.set_xlim(lo-30,hi+30);longitudinal.set_ylim(-bf/2-90,bf/2+20)
    root=r.get('root') or {};nr=root.get('N',c.N*si);vr=root.get('V',c.N*co);mr=root.get('M',c.center_s*nr-c.center_n*vr)
    if nr:_arrow(elev,(-B/2+25,-10),(-B/2+25,25 if nr>0 else -40),'root_normal_force',color=WELD)
    if vr:_arrow(elev,(0,-15),(40 if vr>0 else -40,-15),'root_signed_shear',color=WELD)
    if abs(mr)>1e-8*max(1.,abs(nr)):
        angles=[math.radians(-40+240*i/24) for i in range(25)]
        if mr<0:angles.reverse()
        coords=[(16*math.cos(a),20+16*math.sin(a)) for a in angles]
        moment,=elev.plot([p[0] for p in coords],[p[1] for p in coords],color=WELD,lw=1)
        moment.set_gid('root_moment_arc')
        _arrow(elev,coords[-2],coords[-1],'root_signed_moment',color=WELD,lw=1)
    text(.04,4.47,'Chapa e raiz recebem N total; a simetria 2L-T não elimina Mraiz no plano.',fontsize=8.5)
    text(.04,4.22,'Raiz: Nnormal='+_n(nr,1000)+' kN; Vparalelo='+_n(vr,1000)+' kN; M='+_n(mr,1e6)+' kN m.','signed_root_actions',fontsize=9)
    text(.04,2.24,'Extensão longitudinal real do W; dois filetes centrados na alma, de comprimento B.',fontsize=8)
    text(.035,1.9,'Linha nominal estática NBR 6.1.8.2: N atua na linha de parafusos; ec permanece no shear lag de cada L.',fontsize=8)
    text(.035,1.65,'1L não alega cancelamento físico dos efeitos fora do plano. 2L-T usa parafusos passantes compartilhados.',fontsize=8)
    text(.035,1.40,'Aços independentes: L '+str(c.angle_steel)+'; chapa '+str(c.gusset_steel)+'; W '+str(c.support_steel)+'.',fontsize=8)
    text(.035,1.15,'Parafuso '+str(c.bolt)+'; raiz '+str(c.root_electrode)+'. Não há solda entre cantoneira e chapa.',fontsize=8)
    heel='PENDENTE' if c.heel_extent is None else _n(c.heel_extent)+' mm; origem: '+str(c.heel_extent_source)
    text(.035,.9,rendered_wrap('Extensão real do talão: '+heel+'. Ferramenta R='+_n(c.tool_radius)+' mm; folga='+_n(c.fabrication_clearance)+' mm.',950,8),fontsize=8)
    text(.035,.53,'Seções perfuradas: triagem nominal suplementar, sem solução exata de tensão de contato. Dimensões em mm.',fontsize=7.5)
    text(.035,.3,COMPONENT_VERSION+' · SHA-256: '+input_fingerprint(c),'input_fingerprint',fontsize=7)
    text(.035,.08,'Fonte da cantoneira: '+str(angle.get('source','não disponível')),fontsize=6.5)
    return fig


def image_bytes(c,result=None,fmt='png'):
    if fmt not in ('png','svg'):raise ValueError('Formato de desenho não suportado.')
    fig=figure(c,result)
    try:
        out=BytesIO()
        with matplotlib.rc_context({'svg.fonttype':'none'}):
            fig.savefig(out,format=fmt,dpi=150,facecolor='white',metadata={'Creator':'LRO Soluções de engenharia'})
        return out.getvalue()
    finally:plt.close(fig)


def drawing_svg(c,result=None):return image_bytes(c,result,'svg').decode('utf-8')
connection_svg=drawing_svg
connection_png=image_bytes
