"""Editable evidence for the qualified two-flange normal / web shear component.

The section reports the kernel's signed actions and independent status gates;
no plate or whole-base approval is inferred from a weld resistance result.
"""
from io import BytesIO
from docx.shared import Inches

from .report import table, number, _math, group, sub, frac
from .column_base_weld_drawing import image_bytes, require_current_result

MODEL = 'two_flange_normal_web_shear'
NORMAL_MODES = {'welded':'Transferência soldada', 'fit_bearing':'Contato preparado'}
METHODS = {'guide_example': 'Exemplo de guia aplicável',
           'one_way': 'Cálculo documentado de transferência unidirecional',
           'plate_model': 'Modelo de placa verificado',
           'unspecified': 'Não especificado'}


def _value(out, key, scale=1., unit='', digits=6):
    value = out.get(key)
    if type(value) not in (int, float):
        return 'Não calculado'
    return number(value / scale, digits) + (' ' + unit if unit else '')


def _signature_state(c, out):
    entered = c.column_weld.qualification_signature
    current = out.get('current_signature', '')
    if out.get('qualification_binding_kind')=='legacy_current':
        return 'Vínculo legado conferido: mesma memória e dados físicos; registros opcionais preservados'
    if not entered:
        return 'PENDENTE: sem assinatura de vinculação'
    if not current or entered != current:
        return 'INVALIDADA: registro não vinculado aos dados atuais'
    return 'Vinculada aos dados atuais; validade técnica depende do registro'


def append_qualified_weld_report(doc, c, r, detailed=False):
    """Append only the explicitly selected finite component, in three parts."""
    w, out = c.column_weld, require_current_result(c, r)
    doc.add_page_break()
    doc.add_paragraph('Solda pilar–placa: duas mesas N/M e alma V', style='Heading 1')
    doc.add_paragraph('Componente condicional two_flange_normal_web_shear. Pilar W/I simétrico sem '
                      'enrijecedores; duas mesas do mesmo tipo de junta recebem a transferência normal '
                      'prescrita, e a alma recebe todo o cortante. Ações de cálculo na face superior da placa. '
                      'A escolha da família Tipo 1 ou Tipo 2 não qualifica automaticamente esse caminho.')
    numerical = {'pass': 'ATENDE às verificações numéricas disponíveis',
                 'fail': 'NÃO ATENDE a uma ou mais verificações numéricas',
                 'pending': 'PENDENTE: verificações numéricas incompletas'}.get(
                     out.get('numerical_status'), 'PENDENTE: sem resultado numérico')
    conditional = {'pass': 'ATENDE ao componente condicional qualificado',
                   'fail': 'NÃO ATENDE ao componente local',
                   'pending': 'PENDENTE: sem aprovação do componente'}.get(out.get('status'), 'PENDENTE')
    table(doc, ['Escopo do resultado', 'Situação'], [
        ('Verificações numéricas locais', numerical),
        ('Qualificação do caminho de transferência', {'qualified':'Registro vinculado aos dados atuais', 'missing':'PENDENTE: registro incompleto', 'stale':'INVALIDADA após alteração de dados'}.get(out.get('qualification_status'), 'PENDENTE')),
        ('Registro e dados atuais', _signature_state(c, out)),
        ('Componente condicional', conditional),
        ('Base completa / rigidez rotacional', 'A COMPLEMENTAR; não aprovadas por este componente'),
    ], [2.65, 4.3])
    doc.add_picture(BytesIO(image_bytes(c, r)), width=Inches(6.95))
    doc.add_paragraph('Traços cinza: comprimentos físicos retos e centrados. Traços coloridos: trechos '
                      'efetivos declarados. Espessuras gráficas das linhas são simbólicas. CJP representa '
                      'uma seção fundida por mesa e uma seção de alma; não são duas capacidades por face.')

    doc.add_paragraph('Ações, planos e auditoria de equilíbrio', style='Heading 1').paragraph_format.page_break_before = True
    table(doc, ['Ação na face superior', 'Valor com sinal'], [
        ('N positivo em compressão', _value(out, 'N_input_N', 1000, 'kN')),
        ('M de maior inércia', _value(out, 'M_input_Nmm', 1e6, 'kN·m')),
        ('V paralelo à alma', _value(out, 'V_input_N', 1000, 'kN')),
        ('Plano esquerdo xL / plano direito xR', _value(out, 'x_left_mm', unit='mm', digits=3) + ' / ' + _value(out, 'x_right_mm', unit='mm', digits=3)),
        ('Braço real h=xR−xL', _value(out, 'h_mm', unit='mm', digits=3)),
        ('Transferência normal solicitada / aplicada', NORMAL_MODES.get(out.get('normal_transfer_requested', w.normal_transfer), 'Não estabelecida') + ' / ' + NORMAL_MODES.get(out.get('normal_transfer_applied'), 'Não estabelecida')),
    ], [3.6, 3.35])
    doc.add_paragraph('Filetes exteriores das mesas: x=±d/2, h=d. CJP nas mesas: '
                      'x=±(d−tf)/2, h=d−tf. A alma tem resultante normal nula neste modelo. '
                      'M não recebe o incremento V·e da chave inferior: esse transporte pertence '
                      'ao equilíbrio da placa/ancoragem e é apresentado separadamente.')
    if out.get('normal_transfer_applied')=='fit_bearing':
        _math(doc, group(sub('F', 'L'), ' = ', sub('F', 'R'), ' = 0;   ', sub('F', 'contato'), ' = −N;   M = 0'))
    else:
        _math(doc, group('h = ', sub('x', 'R'), ' − ', sub('x', 'L'), ';   ',
                         sub('F', 'L'), ' = ', frac(group('−M − N ', sub('x', 'R')), 'h'), ';   ',
                         sub('F', 'R'), ' = ', frac(group('M + N ', sub('x', 'L')), 'h')))
    doc.add_paragraph('F positivo indica tração na transferência normal do pilar. Forças negativas '
                      'permanecem na auditoria e são verificadas em módulo quando a transferência é '
                      'soldada, sem alívio por contato. As expressões combinadas N/M são uma extensão '
                      'estática declarada do par M/d do DG1, e não uma equação publicada de aprovação '
                      'geral de placas flexíveis.')
    table(doc, ['Resultante do componente', 'Valor com sinal'], [
        ('Mesa esquerda FL', _value(out, 'F_left_N', 1000, 'kN')),
        ('Mesa direita FR', _value(out, 'F_right_N', 1000, 'kN')),
        ('Força transferida por contato preparado', _value(out, 'bearing_force_N', 1000, 'kN')),
        ('Cortante total na alma', _value(out, 'web_shear_N', 1000, 'kN')),
    ], [3.6, 3.35])
    _math(doc, group('ΣF = −N;   Σ(xF) = M;   ΣV = V'))
    table(doc, ['Integral / resíduo', 'Valor canônico'], [
        ('Resultante normal ΣF', _value(out, 'normal_resultant_N', unit='N')),
        ('Momento ΣxF', _value(out, 'moment_resultant_Nmm', unit='N·mm')),
        ('Cortante ΣV', _value(out, 'shear_resultant_N', unit='N')),
        ('Resíduo normal ΣF+N', _value(out, 'residual_N_N', unit='N', digits=9)),
        ('Resíduo de momento ΣxF−M', _value(out, 'residual_M_Nmm', unit='N·mm', digits=9)),
        ('Resíduo de cortante ΣV−V', _value(out, 'residual_V_N', unit='N', digits=9)),
    ], [3.6, 3.35])
    doc.add_paragraph('A auditoria inclui a parcela de contato quando efetivamente adotada. '
                      'Fechar as três integrais confirma a estática da alocação, não a capacidade '
                      'da placa de realizar o caminho selecionado.')

    doc.add_paragraph('Seções resistentes e registro de qualificação', style='Heading 1').paragraph_format.page_break_before = True
    rows = []
    for key, label, physical, effective in (
            ('flange', 'Cada mesa', w.flange_length, w.flange_effective_length),
            ('web', 'Alma', w.web_length, w.web_effective_length)):
        part = out.get(key, {})
        rows.append((label, {'fillet':'Filete','cjp':'CJP'}.get(part.get('kind', getattr(c, 'weld_' + key + '_type')), 'Pendente'),
                     number(physical, 3), number(effective, 3),
                     _value(part, 'design_length_mm', digits=3),
                     _value(part, 'resistance_N', 1000, digits=3),
                     _value(part, 'utilization', digits=6)))
    table(doc, ['Trecho', 'Junta', 'L físico mm', 'L efetivo mm', 'L cálculo mm', 'Rd kN', 'η'], rows,
          [.65, .6, 1., 1., 1., 1.2, 1.5])
    flange, web = out.get('flange', {}), out.get('web', {})
    table(doc, ['Força por comprimento', 'Valor com sinal / de dimensionamento'], [
        ('Mesa esquerda: qL=FL/Leff', _value(flange, 'q_left_N_per_mm', unit='N/mm')),
        ('Mesa direita: qR=FR/Leff', _value(flange, 'q_right_N_per_mm', unit='N/mm')),
        ('Alma: qV por caminho físico=V/(n Leff)', _value(web, 'q_per_face_N_per_mm', unit='N/mm')),
        ('Filete da alma: q de dimensionamento=|V|/(2 Ld)',
         _value(web, 'q_design_per_face_N_per_mm', unit='N/mm') if c.weld_web_type=='fillet' else 'CJP: seção única; sem redução longitudinal de filete'),
    ], [3.6, 3.35])
    doc.add_paragraph('Comprimentos físicos e efetivos são trechos retos, contínuos e centrados. '
                      'L de cálculo registra eventual redução normativa do comprimento; não altera '
                      'o trecho físico desenhado nem a tração uniforme qV usada na integral física. '
                      'O q de dimensionamento incorpora Ld para a resistência longitudinal. Rd da mesa é a resistência de uma mesa; Rd da alma '
                      'é a resistência do caminho total de cortante. Os índices de detalhamento e '
                      'metal-base são independentes e constam na tabela geral de verificações.')
    expressions=group(sub('q', 'i'), ' = ', frac(sub('F', 'i'), sub('L', 'ef,i')), ';   ',
                      sub('q', 'V,caminho'), ' = ', frac('V', group('2 ' if c.weld_web_type=='fillet' else '', sub('L', 'ef,w'))))
    if 'fillet' in (c.weld_flange_type,c.weld_web_type):
        expressions+=group(';   ',sub('q', 'Rd,filete'), ' = ', frac(group('0,6 ', sub('f', 'w'), ' a'), '1,35'))
    _math(doc,expressions)
    topology=('Uma linha exterior de filete por mesa. ' if c.weld_flange_type=='fillet' else
              'Uma seção CJP por mesa, centrada na espessura da mesa. ')
    topology+=('Na alma, dois filetes iguais recebem V/2 por face e nenhuma força normal. ' if c.weld_web_type=='fillet' else
               'Na alma, uma seção CJP recebe V integral e nenhuma força normal. ')
    topology+=('Filete NBR sem aumento direcional AISC; a=z/√2. ' if 'fillet' in (c.weld_flange_type,c.weld_web_type) else '')
    if 'cjp' in (c.weld_flange_type,c.weld_web_type):
        topology+='CJP usa uma seção fundida; materiais e preparação são especificados. Procedimento e inspeção são requisitos de execução, sem comprovação de sua realização pelo aplicativo.'
    doc.add_paragraph(topology)
    records = [
        ('Método de qualificação', METHODS.get(w.qualification_method, w.qualification_method)),
        ('Referência da transferência', w.transfer_ref or 'PENDENTE'),
        ('Alocação calculada N/M/V', out.get('calculation_basis','N/M nas duas mesas, V na alma; equilíbrio auditado acima')),
        ('Registro adicional de alocação', w.allocation_basis or 'Não informado · opcional'),
        ('Base dos comprimentos efetivos', w.effective_length_basis or 'Ver memória de transferência citada; registro adicional opcional'),
        ('Detalhe e execução aplicáveis', w.execution_ref or out.get('design_specification','Requisitos de execução do projeto; não verificados em obra')),
        ('Procedimento / processo', (w.procedure_ref or 'Registro de WPS não informado · execução não verificada') + ' / ' + w.process),
        ('Aço do pilar / da placa', w.column_steel + ' / ' + c.plate_steel),
        ('Inspeção da junta, quando exigida', w.inspection_ref or 'não informada'),
    ]
    if 'cjp' in (c.weld_flange_type,c.weld_web_type):
        records.extend([('CJP: apoio/cobre-junta', w.cjp_detail),
            ('Tenacidade metal de solda / metal-base', ('Confirmada' if w.cjp_charpy_confirmed else 'Não confirmada') + ' / ' + ('Confirmada' if w.base_charpy_confirmed else 'Não confirmada'))])
    table(doc, ['Registro de engenharia', 'Evidência informada'], records, [2.35, 4.6])
    doc.add_paragraph('Vinculação ao estado atual: ' + _signature_state(c, out) + '.')
    doc.add_paragraph('Assinatura registrada: ' + (w.qualification_signature or 'ausente') +
                      '. Assinatura atual: ' + (out.get('current_signature') or 'indisponível') + '.')
    doc.add_paragraph('A assinatura vincula o registro à combinação, geometria, materiais, detalhe e '
                      'comprimentos atuais. Não é certificação independente da memória externa. '
                      'Uma confirmação isolada, g<bf ou seleção de CJP não justifica comprimento integral.')
    if w.normal_transfer == 'fit_bearing':
        doc.add_paragraph('Contato preparado: qualificação específica', style='Heading 1').paragraph_format.page_break_before=True
        table(doc, ['Contato preparado: registro específico', 'Dado'], [
            ('Área efetiva de contato preparada', number(w.bearing_area, 3) + ' mm²'),
            ('Resistência nativa de contato', _value(out, 'bearing_resistance_N', 1000, 'kN')),
            ('Referência', w.bearing_ref or 'PENDENTE'),
            ('Condição de contato e base resistente', w.bearing_basis or 'PENDENTE'),
        ], [2.9, 4.05])
        doc.add_paragraph('Fit-to-bear só pode retirar a demanda normal das soldas em compressão '
                          'pura N>0 e M=0 com contato preparado e área efetiva documentados. '
                          'Cortante e requisitos mínimos de solda/detalhamento permanecem. '
                          'Não se apagam forças comprimidas de uma combinação com momento.')
    for reason in out.get('reasons', []):
        doc.add_paragraph(str(reason))
    if r.geometry.get('direct_anchor_shear',{}).get('local_transfer_scope',{}).get('complete'):
        doc.add_paragraph('Escopo deste componente: soldas e seções locais íntegras do pilar, com alocação e comprimentos vinculados. '
                          'A composição direta apresenta separadamente os consumidores calculados do metal-base receptor e da placa, '
                          'as ações normais preservadas, a ancoragem e eventuais pendências axiais. Não aprova fundação nem rigidez rotacional.')
    else:
        doc.add_paragraph('Escopo: soldas e seções locais íntegras do pilar, com alocação e comprimentos vinculados. '
                      'Permanecem a verificar o metal-base da placa junto à fusão, flexão/interação da placa, '
                      'transferência aos chumbadores/contato, ancoragem, bloco/fundação e rigidez rotacional. '
                      'Os resultados nativos da placa não são automaticamente requalificados.')
