"""Entradas em kgf, kgf·m e mm; motor independente da interface."""
from dataclasses import fields,asdict,replace
import json,hashlib,math
import pandas as pd
import streamlit as st
from .load_conventions import render as render_load_convention
from .models import profiles,STEELS,BOLTS,DIAMETERS,KGF,VERSION
from .end_plate import EndPlate,STOCK,presets,evaluate
from .end_plate_drawing import image_bytes
from .report import BRAND,LINK,number,display

P=profiles();EXAMPLES=presets()
# Full 8ES verification snapshots exceed the former 200 kB upload guard.
# Keep a finite bound that accepts the application's own readable JSON export.
MAX_PROJECT_BYTES=1_000_000

# Imports must fit their family's actual controls before session replacement.
# Inactive dimensions retain their stored values instead of being clamped.
_PINNED_UI_RANGES={
    'tp':(.1,100.),'bp':(1.,None),'gauge':(1.,None),'n':(2,10),
    'pitch':(1.,None),'overhang':(.1,None),'weld':(.1,None),
    'fw':(1.,None),'tool_radius':(1.,None),
}
_PINNED_M_ZERO=1e-9  # N·mm; same numerical-zero tolerance as the engine.
_MOMENT_UI_RANGES={
    'tp':(.1,100.),'bp':(1.,None),'gauge':(1.,None),
    'pfi':(1.,None),'pfo':(1.,None),'edge':(1.,None),
    'fw':(1.,None),'tool_radius':(1.,None),'intermediate_n':(0,10),
}
_STIFFENER_FIELDS=('stiffener_steel','stiffener_t','stiffener_length',
                   'stiffener_clip','stiffener_landing','stiffener_weld','stiffener_electrode','stiffener_compatible','stiffener_clearance')
_STIFFENER_UI_RANGES={'stiffener_t':(.1,100.),'stiffener_length':(.1,None),
                      'stiffener_clip':(0.,None),'stiffener_landing':(.1,None)}

def moment_import(c):
    """Reject malformed/unrepresentable inputs before touching the live draft.

    These are widget limits, not added engineering restrictions. In particular,
    inactive pinned fields and the both-end bottom overhang are not normalized.
    """
    if c.kind!='moment':return c
    def reject(key,value,reason):
        raise ValueError(f'{key}={value!r}: {reason} O projeto atual foi preservado.')
    for key in ('kind','layout','variant','project','beam_steel','support_steel','plate_steel','bolt','notes','stiffener_steel','stiffener_weld','stiffener_electrode'):
        value=getattr(c,key)
        if not isinstance(value,str):reject(key,value,'Este campo requer texto.')
    for key in ('reinforced_edge','threads','drilled','norm_minimum','stiffener_compatible','stiffener_clearance'):
        value=getattr(c,key)
        if type(value) is not bool:reject(key,value,'Este campo requer um valor booleano.')
    for key in ('n','intermediate_n'):
        value=getattr(c,key)
        if type(value) is not int:reject(key,value,'Este campo requer um número inteiro, sem valores booleanos.')
    for key in ('db','tp','bp','gauge','pitch','overhang','pfi','pfo','pb','edge','weld','fw','tool_radius','V','N','M','stiffener_t','stiffener_length','stiffener_clip','stiffener_landing'):
        value=getattr(c,key)
        if type(value) not in (int,float):reject(key,value,'Este campo requer um número, sem valores booleanos.')
        try:finite=math.isfinite(value)
        except OverflowError:finite=False
        if not finite:reject(key,value,'Este campo requer um número finito representável.')
    if c.variant not in ('4E','4ES','8ES'):reject('variant',c.variant,'Selecione 4E, 4ES ou 8ES.')
    ranges=dict(_MOMENT_UI_RANGES)
    if c.is_stiffened:
        ranges.update(_STIFFENER_UI_RANGES)
        if c.stiffener_weld!='CJP':reject('stiffener_weld',c.stiffener_weld,f'A variante inicial {c.variant} admite somente CJP.')
        if c.stiffener_electrode!='E7018':reject('stiffener_electrode',c.stiffener_electrode,f'A rota inicial {c.variant} admite somente E7018.')
        if c.stiffener_steel not in STEELS or not STEELS[c.stiffener_steel].plate_allowed:
            reject('stiffener_steel',c.stiffener_steel,'Selecione um aço de chapa do catálogo.')
    if c.is_8es:ranges['pb']=(1.,None)
    if c.layout=='top':ranges['overhang']=(0.,None)
    for key,(lo,hi) in ranges.items():
        value=getattr(c,key)
        if value<lo or (hi is not None and value>hi):
            bound=f'{lo:g} a {hi:g}' if hi is not None else f'no mínimo {lo:g}'
            reject(key,value,f'A interface aceita {bound}.')
    if c.db not in DIAMETERS.values():reject('db',c.db,'A interface aceita somente os diâmetros exatos do catálogo.')
    return c

def pinned_import(c):
    if c.kind!='pinned':return c
    for key,(lo,hi) in _PINNED_UI_RANGES.items():
        value=getattr(c,key)
        if isinstance(value,bool) or not isinstance(value,(int,float)):
            raise ValueError(f'{key}={value!r}: este campo requer um número representável pela interface.')
        if value<lo or (hi is not None and value>hi):
            bound=f'{lo:g} a {hi:g}' if hi is not None else f'no mínimo {lo:g}'
            raise ValueError(f'{key}={value!r}: a interface aceita {bound}. O projeto atual foi preservado.')
    if c.db not in DIAMETERS.values():
        raise ValueError(f'db={c.db!r}: a interface aceita somente os diâmetros exatos do catálogo. O projeto atual foi preservado.')
    # The pinned controls have no moment input. Make this normalization explicit,
    # rather than accepting a tiny M only to lose it during widget reconstruction.
    return replace(c,M=0.) if abs(c.M)<=_PINNED_M_ZERO else c

def seed(c,restore_draft=False):
    s=st.session_state
    projects=dict(s.get('_end_plate_projects',{}));projects[c.kind]=c.to_dict()
    s['_end_plate_projects']=projects
    s.ep_model=asdict(c);s.ep_screen_kind=c.kind
    if c.kind=='moment':
        drafts=dict(s.get('_ep_variant_drafts',{}));drafts[c.variant]=asdict(c)
        s['_ep_variant_drafts']=drafts
    for f in fields(c):
        if f.name not in ('beam','support','V','N','M'):s['ep_'+f.name]=getattr(c,f.name)
    for k in ('beam','support'):s['ep_'+k+'_name']=getattr(c,k).name
    s.ep_V_kgf=c.V/KGF;s.ep_N_kgf=c.N/KGF;s.ep_M_kgfm=c.M/(1000*KGF)
    s.ep_db_label=next(k for k,v in DIAMETERS.items() if v==c.db)
    s.ep_t_label=next((k for k,v in STOCK.items() if v==c.tp),'Personalizada')
    if c.kind=='moment':s['_ep_moment_overhang']=c.overhang
    if c.kind in ('pinned','moment'):
        custom_key=f'_ep_{c.kind}_custom_tp';label_key=f'_ep_{c.kind}_t_label'
        if not restore_draft or custom_key not in s:
            s[custom_key]=c.tp
            s[label_key]=s.ep_t_label
        else:
            s.ep_t_label=s.get(label_key,s.ep_t_label)
        if s.ep_t_label=='Personalizada':s.ep_tp=s[custom_key]
    s.pop('ep_report',None)

def preserve_variant_draft():
    """Save a complete moment draft separately from conditional widget keys."""
    s=st.session_state
    if s.ep_model['kind']!='moment':return
    variant=s.ep_model['variant']
    drafts=dict(s.get('_ep_variant_drafts',{}));drafts[variant]=dict(s.ep_model)
    s['_ep_variant_drafts']=drafts
    controls=dict(s.get('_ep_variant_controls',{}))
    controls[variant]={'custom_tp':s.get('_ep_moment_custom_tp',s.ep_model['tp']),
                       't_label':s.get('_ep_moment_t_label',s.ep_t_label),
                       'overhang':s.get('_ep_moment_overhang',s.ep_model['overhang'])}
    s['_ep_variant_controls']=controls

def load_example():
    c=EXAMPLES[st.session_state.ep_example];seed(c)
    st.session_state.connection_family='End plate · '+('rotulada' if c.kind=='pinned' else 'engastada')

def load_json():
    try:
        up=st.session_state.ep_upload
        if up is None:raise ValueError('Selecione um projeto JSON.')
        if len(up.getvalue())>MAX_PROJECT_BYTES:raise ValueError('Projeto maior que 1 MB.')
        c=EndPlate.from_dict(json.loads(up.getvalue()))
        if c.beam.name not in P or c.support.name not in P:raise ValueError('Esta interface utiliza seções do catálogo.')
        if c.beam!=P[c.beam.name] or c.support!=P[c.support.name]:raise ValueError('Dimensões dos perfis diferem do catálogo. O arquivo não será alterado silenciosamente.')
        c=moment_import(pinned_import(c))
        r=evaluate(c)
        if any(i.severity=='error' for i in r.issues):raise ValueError('; '.join(i.text for i in r.issues if i.severity=='error'))
        if getattr(r,'numeric_failures',[]):raise ValueError('Falha numérica: '+', '.join(row.name for row in r.numeric_failures)+'. O projeto atual foi preservado.')
        if any(i.origin=='numeric' for i in r.issues):raise ValueError('Falha numérica: '+ '; '.join(i.text for i in r.issues if i.origin=='numeric')+' O projeto atual foi preservado.')
        seed(c);st.session_state.connection_family='End plate · '+('rotulada' if c.kind=='pinned' else 'engastada');st.session_state.pop('ep_import_error',None)
    except (ValueError,TypeError,KeyError,OverflowError,AttributeError) as exc:st.session_state.ep_import_error=str(exc)

def stock_change():
    if st.session_state.ep_kind in ('pinned','moment'):
        kind=st.session_state.ep_kind
        st.session_state[f'_ep_{kind}_t_label']=st.session_state.ep_t_label
        if st.session_state.ep_t_label=='Personalizada':
            st.session_state.ep_tp=st.session_state[f'_ep_{kind}_custom_tp']
            return
    if st.session_state.ep_t_label in STOCK:st.session_state.ep_tp=STOCK[st.session_state.ep_t_label]

def custom_thickness_change():
    # This key is never attached to a widget, so Streamlit does not discard it
    # when stock thickness is selected or another connection family is shown.
    if st.session_state.ep_kind in ('pinned','moment'):
        st.session_state[f'_ep_{st.session_state.ep_kind}_custom_tp']=st.session_state.ep_tp

def bottom_overhang_change():
    st.session_state['_ep_moment_overhang']=st.session_state.ep_overhang

def preserve_option(options,key):
    """Show a dormant imported choice verbatim when a variant activates it.

    An unsupported choice must reach validation, never become the first item.
    """
    value=st.session_state[key]
    return options if value in options else options+[value]

def variant_change():
    # First activation inherits unchanged inputs. Revisiting a variant restores
    # its own complete draft, including custom values hidden by stock widgets.
    s=st.session_state
    target=s.ep_variant
    preserve_variant_draft()
    data=dict(s.get('_ep_variant_drafts',{}).get(target,s.ep_model))
    data['variant']=target
    controls=s.get('_ep_variant_controls',{}).get(target)
    if controls:
        s['_ep_moment_custom_tp']=controls['custom_tp']
        s['_ep_moment_t_label']=controls['t_label']
        s['_ep_moment_overhang']=controls['overhang']
    c=EndPlate.from_dict({'schema_version':1,'connection_type':'end_plate','connection':data})
    seed(c,restore_draft=True)

def profile_change(key):
    p=P[st.session_state['ep_'+key+'_name']]
    st.session_state['ep_'+key+'_steel']='ASTM A36' if p.family in ('CS','CVS','VS','Soldado') else 'ASTM A572 Gr.50'

def verification_table(checks,with_case=False):
    rows=[]
    for row in checks:
        valid=getattr(row,'applicable',True) and getattr(row,'numerically_valid',True)
        sd,u=display(row.demand,row.unit) if valid else ('—',row.unit)
        rd,_=display(row.resistance,row.unit) if valid else ('—',row.unit)
        entry={'Verificação':row.name,'Tipo':row.category,'Sd / valor':sd,'Rd / limite':rd,'Unidade':u,'Índice':row.ratio if valid else None,'Resultado':getattr(row,'outcome','Atende' if row.passed else 'Não atende')}
        if with_case:entry['Caso governante']=row.case
        rows.append(entry)
    st.dataframe(pd.DataFrame(rows),hide_index=True,width='stretch',column_config={'Índice':st.column_config.NumberColumn(format='%.3f')})

def render(kind):
    from .end_plate_report import create_report
    if st.session_state.get('ep_screen_kind')!=kind or 'ep_project' not in st.session_state:
        saved=st.session_state.get('_end_plate_projects',{}).get(kind)
        seed(EndPlate.from_dict(saved) if saved else next(c for c in EXAMPLES.values() if c.kind==kind),restore_draft=bool(saved))
    with st.sidebar:
        st.caption('LRO Ligações '+VERSION)
        st.selectbox('Exemplos de end plate',list(EXAMPLES),key='ep_example')
        st.button('Carregar exemplo',on_click=load_example,use_container_width=True)
        st.file_uploader('Projeto de end plate',type=['json'],key='ep_upload')
        st.button('Abrir projeto de end plate',on_click=load_json,use_container_width=True)
        if 'ep_import_error' in st.session_state:st.error(st.session_state.ep_import_error)
        st.divider();st.caption(BRAND);st.link_button('LinkedIn · Lucas Oliveira',LINK)
    # A loaded example can change the connection kind; the header tracks the object.
    k=st.session_state.ep_kind
    if k=='moment':
        for key in _STIFFENER_FIELDS+('pb',):
            if 'ep_'+key not in st.session_state:
                st.session_state['ep_'+key]=st.session_state.ep_model[key]
        # A conditional widget can leave a stale keyed value when it disappears.
        # Keep the inactive bottom dimension outside the widget lifecycle.
        st.session_state.ep_overhang=st.session_state.get('_ep_moment_overhang',st.session_state.ep_model['overhang'])
    st.title('End plate '+('rotulada' if k=='pinned' else 'engastada'))
    st.caption('Viga na mesa de coluna · perfis I · análise plana · uma combinação de cálculo')
    st.text_input('Identificação do projeto',key='ep_project')
    left,right=st.columns([.95,1.5],gap='large')
    with left:
        st.subheader('Perfis e esforços')
        st.selectbox('Viga',list(P),key='ep_beam_name',on_change=profile_change,args=('beam',))
        st.selectbox('Coluna',list(P),key='ep_support_name',on_change=profile_change,args=('support',))
        b=P[st.session_state.ep_beam_name];s=P[st.session_state.ep_support_name]
        x,y=st.columns(2)
        with x:V=st.number_input('V vertical (kgf)',key='ep_V_kgf',format='%.2f')*KGF
        with y:N=st.number_input('N axial (kgf)',key='ep_N_kgf',format='%.2f')*KGF
        M=st.number_input('M maior inércia (kgf·m)',key='ep_M_kgfm',format='%.2f')*1000*KGF if k=='moment' else 0.
        load_convention_slot = st.empty()
        st.caption('Esforços já majorados. N positivo: tração; N negativo: compressão.'+(' M positivo: tração na mesa superior; negativo: mesa inferior.' if k=='moment' else ' Sem momento externo.'))
        if k=='pinned':st.caption('Importação: |M| ≤ 1e-9 N·mm é normalizado explicitamente para zero numérico. Valores maiores são rejeitados. A conversão N ↔ kgf pode diferir apenas por arredondamento de ponto flutuante.')
        st.subheader('Chapa e parafusos')
        if k=='moment':
            st.selectbox('Variante de end plate',['4E','4ES','8ES'],key='ep_variant',on_change=variant_change,
                         format_func=lambda v:dict([('4E','4E · sem nervuras'),('4ES','4ES · duas nervuras externas'),('8ES','8ES · 16 parafusos e duas nervuras')])[v])
            if st.session_state.ep_variant=='4ES':
                st.caption('4ES inicial: extensão simétrica, oito parafusos, duas nervuras centradas e CJP compatível. A seleção preserva as entradas; use o exemplo 4ES para carregar suas dimensões e materiais.')
            elif st.session_state.ep_variant=='8ES':
                st.caption('8ES: 16 parafusos físicos, oito ativos em tração, quatro braços e duas nervuras CJP. Primeira seleção preserva as entradas; use o exemplo 8ES para carregar o detalhe de referência. Cada variante conserva seu próprio rascunho.')
        if k=='moment':st.selectbox('Extensão da chapa',['both','top'],key='ep_layout',format_func=lambda v:'Acima e abaixo' if v=='both' else 'Somente acima')
        x,y=st.columns(2)
        with x:
            st.selectbox('Espessura da chapa (pol.)',list(STOCK)+['Personalizada'],key='ep_t_label',on_change=stock_change)
            if st.session_state.ep_t_label=='Personalizada':
                tp=st.number_input('Espessura tp (mm)',min_value=.1,max_value=100.,key='ep_tp',on_change=custom_thickness_change)
                st.session_state[f'_ep_{k}_custom_tp']=tp
            else:tp=STOCK[st.session_state.ep_t_label];st.caption(number(tp,4)+' mm')
            st.number_input('Largura bp (mm)',min_value=1.,key='ep_bp')
        with y:
            st.selectbox('Parafusos Ø (pol.)',list(DIAMETERS),key='ep_db_label')
            st.number_input('Gabarito g (mm)',min_value=1.,key='ep_gauge')
        if k=='pinned':
            x,y=st.columns(2)
            with x:st.number_input('Linhas de parafusos',min_value=2,max_value=10,key='ep_n')
            with y:st.number_input('Passo p (mm)',min_value=1.,key='ep_pitch')
            st.number_input('Sobra acima e abaixo (mm)',min_value=.1,key='ep_overhang')
            st.caption('Grupo centrado, duas colunas de parafusos entre as mesas da viga.')
        else:
            x,y=st.columns(2)
            with x:st.number_input('Mesa → linha externa pfo (mm)',min_value=1.,key='ep_pfo')
            with y:st.number_input('Mesa → linha interna pfi (mm)',min_value=1.,key='ep_pfi')
            if st.session_state.ep_variant=='8ES':
                x,y=st.columns(2)
                with x:st.number_input('Passo adicional pb (mm)',min_value=min(1.,float(st.session_state.ep_pb)),key='ep_pb',help='Separação física igual entre as duas linhas externas e as duas internas de cada mesa. O detalhe simétrico tem oito linhas, todas resistentes.')
                with y:st.number_input('Linha externa → borda e (mm)',min_value=1.,key='ep_edge')
            else:st.number_input('Linha externa → borda e (mm)',min_value=1.,key='ep_edge')
            if st.session_state.ep_layout=='top':
                st.number_input('Sobra abaixo da mesa inferior (mm)',min_value=0.,key='ep_overhang',on_change=bottom_overhang_change,help='Distância da face inferior da viga até a borda inferior da chapa. Afeta a altura e as distâncias à borda no arranjo com extensão somente acima.')
            st.number_input('Linhas intermediárias entre as mesas',min_value=0,max_value=10,step=1,key='ep_intermediate_n',help='8ES exige zero linhas intermediárias. Nas variantes 4E/4ES, linhas adicionais não têm crédito resistente e sinalizam extrapolação.')
            st.caption(('8ES: oito parafusos com tração e cisalhamento e oito apenas com cisalhamento; oito linhas primárias, sem linhas adicionais.' if st.session_state.ep_variant=='8ES' else st.session_state.ep_variant+': quatro parafusos na região tracionada, mais os parafusos do lado comprimido.')+' A altura da chapa é calculada automaticamente.')
        if k=='moment' and st.session_state.ep_variant in ('4ES','8ES'):
            with st.expander('Nervuras '+st.session_state.ep_variant+' · acima e abaixo',expanded=True):
                st.selectbox('Aço das duas nervuras',preserve_option([name for name,steel in STEELS.items() if steel.plate_allowed],'ep_stiffener_steel'),key='ep_stiffener_steel')
                x,y=st.columns(2)
                with x:
                    st.number_input('Espessura ts (mm)',min_value=min(.1,float(st.session_state.ep_stiffener_t)),max_value=max(100.,float(st.session_state.ep_stiffener_t)),key='ep_stiffener_t')
                    st.number_input('Recorte em cada face (mm)',min_value=min(0.,float(st.session_state.ep_stiffener_clip)),key='ep_stiffener_clip')
                with y:
                    st.number_input('Comprimento Lst (mm)',min_value=min(.1,float(st.session_state.ep_stiffener_length)),key='ep_stiffener_length')
                    st.number_input('Patamares de terminação (mm)',min_value=min(.1,float(st.session_state.ep_stiffener_landing)),key='ep_stiffener_landing')
                eight=st.session_state.ep_variant=='8ES'
                hst=st.session_state.ep_pfo+st.session_state.ep_edge+(st.session_state.ep_pb if eight else 0.)
                st.caption(f'hst = pfo + '+('pb + ' if eight else '')+f'e = {hst:g} mm. Trechos conectados: chapa {hst-st.session_state.ep_stiffener_clip:g} mm; mesa {st.session_state.ep_stiffener_length-st.session_state.ep_stiffener_clip:g} mm. O recorte não recebe solda.')
                st.selectbox('Juntas nervura–chapa e nervura–mesa',preserve_option(['CJP'],'ep_stiffener_weld'),key='ep_stiffener_weld')
                st.selectbox('Consumível da rota CJP '+st.session_state.ep_variant,preserve_option(['E7018'],'ep_stiffener_electrode'),key='ep_stiffener_electrode')
                st.checkbox('CJP contínua, E7018 e procedimento compatíveis nas duas interfaces (NBR Tabela 8)',key='ep_stiffener_compatible')
                st.checkbox('Recorte libera a CJP da mesa e sua preparação; viga soldada antes das nervuras',key='ep_stiffener_clearance')
                st.caption('Aços independentes da viga, chapa e nervuras: A36/A572 Gr.42/Gr.50. Cada CJP usa o menor fy e a menor espessura conectada; ambas devem desenvolver a nervura. E7018, fw=485 MPa, baixo hidrogênio e preaquecimento pelo grupo de maior resistência (Tabela 8, nota a). A declaração inclui o procedimento qualificado. Soldar a viga à chapa antes das nervuras; sem reforço da coluna.')
        with st.expander('Soldas e montagem'):
            if k=='pinned':
                st.number_input('Filete contínuo w (mm)',min_value=.1,key='ep_weld')
                st.checkbox('Bordas com reforço de solda',key='ep_reinforced_edge')
            else:st.write('Mesas e alma da viga soldadas à chapa por juntas de penetração total, com metal de adição compatível.')
            st.number_input('Resistência do eletrodo fw (MPa)',min_value=1.,key='ep_fw')
            st.number_input('Raio de ferramenta/porca (mm)',min_value=1.,key='ep_tool_radius')
        with st.expander('Materiais e critérios'):
            st.caption('Cada componente conserva seu próprio aço. Mudar a chapa não altera a viga, a coluna ou as nervuras.')
            for key,label,p in [('beam_steel','Aço da viga',b),('support_steel','Aço da coluna',s),('plate_steel','Aço da chapa',None)]:
                welded=p is None or p.family in ('CS','CVS','VS','Soldado')
                options=[x for x,v in STEELS.items() if v.plate_allowed] if welded else [x for x,v in STEELS.items() if v.rolled_allowed]
                st.selectbox(label,options,key='ep_'+key)
            st.selectbox('Classe dos parafusos',[x for x in BOLTS if x!='ASTM A307'],key='ep_bolt')
            st.checkbox('Rosca no plano de corte',key='ep_threads')
            st.checkbox('Furos com broca, sem acréscimo de 2 mm na área líquida',key='ep_drilled')
            st.checkbox('Conferir resistência mínima de 45 kN',key='ep_norm_minimum')
        with st.expander('Observações'):st.text_area('Observações do projeto',key='ep_notes')
    if k=='moment':
        converted_actions=[('V','ep_V_kgf','kgf','N',V),('N','ep_N_kgf','kgf','N',N),('M','ep_M_kgfm','kgf·m','N·mm',M)]
        overflow=[(name,key,unit,target) for name,key,unit,target,value in converted_actions if not math.isfinite(value)]
        if overflow:
            st.error('FALHA NUMÉRICA · REVISAR ENTRADA')
            for name,key,unit,target in overflow:
                st.error(f'{name}={st.session_state[key]!r} {unit}: a conversão para {target} não é finita. Reduza o valor para um número representável.')
            st.caption('O último projeto e a memória válida foram preservados. As exportações ficam ocultas enquanto esta entrada numérica não for corrigida.')
            # Do not replace either canonical snapshot, invalidate a valid stored
            # report or offer downloads for the still-invalid visible controls.
            st.stop()
    excluded=('beam','support','V','N','M','db','tp')
    values={f.name:st.session_state.get('ep_'+f.name,st.session_state.ep_model[f.name]) for f in fields(EndPlate) if f.name not in excluded}
    c=EndPlate(b,s,V=V,N=N,M=M,db=DIAMETERS[st.session_state.ep_db_label],tp=tp,**values)
    st.session_state.ep_model=asdict(c)
    projects=dict(st.session_state.get('_end_plate_projects',{}));projects[c.kind]=c.to_dict()
    st.session_state['_end_plate_projects']=projects
    if k=='moment':preserve_variant_draft()
    with load_convention_slot.container():
        render_load_convention(st, 'end_plate_' + k, c.N)
    r=evaluate(c);encoded=json.dumps(c.to_dict(),ensure_ascii=False,indent=2,allow_nan=False);digest=hashlib.sha256(encoded.encode()).hexdigest()
    summary=getattr(r,'summary_checks',r.checks)
    with right:
        if r.status in ('GEOMETRIA INVÁLIDA','NÃO ATENDE','NÃO ATENDE AO DETALHAMENTO','FALHA NUMÉRICA · REVISAR ENTRADA','DADOS NECESSÁRIOS AUSENTES','DADOS NECESSÁRIOS AUSENTES OU INVÁLIDOS','CONDIÇÕES DO MÉTODO NÃO SATISFEITAS'):st.error(r.status)
        elif getattr(r,'coverage_note',''):st.warning(r.status)
        elif any(i.severity in ('pending','interference','extrapolation') for i in r.issues):st.warning(r.status)
        else:st.success(r.status)
        if getattr(r,'coverage_note',''):st.caption(r.coverage_note)
        if r.calculation_note:st.caption(r.calculation_note)
        st.image(image_bytes(c),width='stretch')
        if c.intermediate_n:
            st.caption(f'{c.count} parafusos no detalhe; {c.calculation_count} no grupo base usado no cálculo. Linhas intermediárias sem crédito resistente.')
        if k=='moment':
            gap=b.d-2*(b.tf+c.pfi+(c.pb if c.is_8es else 0.));limit=min(24*min(c.tp,s.tf),300.)
            from math import ceil
            suggested=max(0,ceil(gap/limit)-1) if math.isfinite(gap) else 0
            if c.is_8es and suggested:
                st.info(f'O vão central de {gap:g} mm supera {limit:g} mm. Revise as dimensões do detalhe 8ES; esta variante não admite linhas intermediárias adicionais.')
            elif suggested>c.intermediate_n:
                st.info(f'Para o vão entre linhas internas, são necessárias pelo menos {suggested} linhas intermediárias para não superar {limit:g} mm. Confira também espaçamentos mínimos, gabarito e o arranjo resistente.')
        for issue in r.issues:
            if issue.severity=='excluded':continue
            if issue.severity in ('error','noncompliance'):st.error(issue.text)
            elif issue.severity in ('pending','interference','extrapolation'):st.warning(issue.text)
        if r.checks:
            a=r.geometry['actions'];x,y,z=st.columns(3)
            ratio_rows=r.checks if k=='moment' else summary
            ratios=[row.ratio for row in ratio_rows if getattr(row,'applicable',True) and getattr(row,'numerically_valid',True) and math.isfinite(row.ratio)]
            x.metric('Maior índice finito',number(max(ratios),3) if ratios else 'Não disponível')
            y.metric('tp mínimo calculado',number(a['tp_required'],2)+' mm')
            z.metric('Parafusos',c.count)
            if k=='moment':st.caption('Espessura mínima pelo método de chapa espessa do DG39; o resultado também depende da mesa da coluna e das demais verificações.')
            else:st.caption('tp mínimo refere-se à tração sem alavanca; o limite máximo de espessura para a rótula é verificado separadamente.')
            if r.minimum_factor>1:st.info('Conferência adicional de força mínima: V e N multiplicados por '+number(r.minimum_factor,3)+'. O momento externo permanece igual à entrada; não há nova majoração da combinação.')
        st.subheader('Salvar e exportar')
        st.download_button('Salvar projeto JSON',encoded,'Projeto_LRO_end_plate.json','application/json',use_container_width=True)
        st.download_button('Desenho vetorial SVG',image_bytes(c,'svg'),'End_plate_LRO.svg','image/svg+xml',use_container_width=True)
        detailed=st.checkbox('Memória detalhada',key='ep_detailed')
        if st.button('Gerar memória Word',type='primary',disabled=not bool(r.checks),use_container_width=True):
            st.session_state.ep_report=(digest,detailed,create_report(c,r,detailed))
        saved=st.session_state.get('ep_report')
        if saved and saved[:2]==(digest,detailed):st.download_button('Baixar memória Word',saved[2],'Memoria_end_plate_LRO.docx','application/vnd.openxmlformats-officedocument.wordprocessingml.document',use_container_width=True)
    st.subheader('Verificações')
    if r.checks:
        if k=='moment':st.caption('Envoltória por mecanismo: cada linha conserva os esforços, a resistência e a fonte do caso indicado. Os casos calculados e as pendências permanecem disponíveis abaixo.')
        verification_table(summary,with_case=k=='moment')
        if k=='moment':
            with st.expander('Casos de cálculo · entrada e mínimo de força'):
                for record in r.case_records:
                    a=record['actions'];st.write(record['label'])
                    st.caption('N='+number(a['N']/KGF,3)+' kgf; V='+number(a['V']/KGF,3)+' kgf; M='+number(a['M']/(1000*KGF),3)+' kgf·m. Sinais conforme a entrada; M não é ampliado na conferência mínima.')
                    if record.get('reason'):st.warning(record['reason'])
                    checks=r.actual_summary if record['label']=='Entrada' else r.minimum_summary
                    if checks:verification_table(checks)
                if r.minimum_factor<=1:st.caption('Não há caso adicional de ampliação de N/V. Em momento puro, não se inventa uma direção de força mínima.')
        with st.expander('Equações e referências'):
            equation_rows=r.actual+r.minimum if k=='moment' else r.checks
            for row in equation_rows:
                st.markdown('**'+row.name+(' ['+row.case+']' if k=='moment' else '')+'**');st.write(row.equation);st.write(row.substitution);st.caption(row.variables+' '+row.reference)
                if k=='moment':st.caption(row.outcome)
    st.divider();st.subheader('Premissas adotadas')
    for note in c.assumptions:st.write(note)
    for issue in r.issues:
        if issue.severity in ('excluded','extrapolation','noncompliance'):st.write(issue.text+' ['+issue.reference+']')
    st.caption(BRAND);st.link_button('Contato no LinkedIn',LINK)
