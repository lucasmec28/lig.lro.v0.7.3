"""Memória editável: equações OMML, tabela única de verificações e desenho comum."""
from .display_precision import calculated_text
from .display_precision import display_format, display_value
from io import BytesIO
from copy import deepcopy
from datetime import datetime
import re
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from .column_checks import WELDED_FAMILIES,column_actions
from .models import KGF,VERSION,STEELS,BOLTS,SUPPORT_WEB_EXCLUSION
from .models import SinglePlateFullDepthWeldCheck,SinglePlateNominalReferenceCheck
from .package_identity import PACKAGE_ID
from .drawing import image_bytes
from .detailing import polygon_area,plate_outline

LINK='https://www.linkedin.com/in/lucas-oliveira-722723149/?isSelfProfile=true'
BRAND='Desenvolvido por LRO Soluções de engenharia LTDA.'


def number(x,places=2):
    return display_format(x, ',.' + str(min(2, places)) + 'f').replace(',','§').replace('.',',').replace('§','.')

def decimal_text(text):
    """Converte decimais nas substituições; preserva itens como 6.2.5."""
    return re.sub(r'(?<![\w.])(\d+)\.(\d+)(?![\w.])',r'\1,\2',text)


def display(v,unit):
    factor,label={'N':(KGF,'kgf'),'Nmm':(KGF*1000,'kgf·m'),'N/mm':(KGF,'kgf/mm')}.get(unit,(1,unit))
    return number(v/factor,3 if unit=='—' else 2),label


def hyperlink(p,label,url):
    rel=p.part.relate_to(url,'http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink',is_external=True)
    h=OxmlElement('w:hyperlink');h.set(qn('r:id'),rel)
    r=OxmlElement('w:r');rp=OxmlElement('w:rPr');color=OxmlElement('w:color');color.set(qn('w:val'),'225D86');rp.append(color);r.append(rp)
    t=OxmlElement('w:t');t.text=label;r.append(t);h.append(r);p._p.append(h)


def table(doc,headers,rows,widths):
    # Fit proportionally to the actual section, including portrait MC excerpts.
    if len(widths) != len(headers) or any(w <= 0 for w in widths):
        raise ValueError('Larguras da tabela incompatíveis com as colunas.')
    section = doc.sections[-1]
    available = (section.page_width-section.left_margin-section.right_margin)/914400
    scale = min(1., available/sum(widths))
    widths = [w*scale for w in widths]
    t=doc.add_table(rows=1,cols=len(headers));t.autofit=False
    for col,width in zip(t.columns,widths):col.width=Inches(width)
    props=t._tbl.tblPr
    borders=OxmlElement('w:tblBorders')
    for edge in ['top','bottom','left','right','insideH','insideV']:
        e=OxmlElement('w:'+edge);e.set(qn('w:val'),'single');e.set(qn('w:sz'),'4');e.set(qn('w:color'),'D9D9D9');borders.append(e)
    props.append(borders)
    for i,label in enumerate(headers):t.rows[0].cells[i].text=label
    rep=OxmlElement('w:tblHeader');t.rows[0]._tr.get_or_add_trPr().append(rep)
    for row in rows:
        for cell,value in zip(t.add_row().cells,row):cell.text=display_value(value)
    for ri,row in enumerate(t.rows):
        cant=OxmlElement('w:cantSplit');row._tr.get_or_add_trPr().append(cant)
        for j,cell in enumerate(row.cells):
            cell.width=Inches(widths[j]);cell.vertical_alignment=1
            pr=cell._tc.get_or_add_tcPr();sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'DCE8F0' if ri==0 else ('F5F7F9' if ri%2==0 else 'FFFFFF'));pr.append(sh)
            margins=OxmlElement('w:tcMar')
            for side in ['top','left','bottom','right']:
                el=OxmlElement('w:'+side);el.set(qn('w:w'),'65');el.set(qn('w:type'),'dxa');margins.append(el)
            pr.append(margins)
            for p in cell.paragraphs:
                p.paragraph_format.space_after=Pt(0);p.paragraph_format.space_before=Pt(0)
                p.paragraph_format.keep_with_next = (ri == 0)
                p.paragraph_format.widow_control = True
                if j>0:p.alignment=WD_ALIGN_PARAGRAPH.CENTER
                for r in p.runs:r.font.size=Pt(9);r.bold=(ri==0)
    doc.add_paragraph().paragraph_format.space_after=Pt(0)
    return t


# OMML nativo: frações, índices, expoentes e radicais estruturados.
def mr(text):
    r=OxmlElement('m:r');t=OxmlElement('m:t');t.text=str(text);r.append(t);return r
def group(*items):
    out=[]
    for item in items:
        if isinstance(item,list):out.extend(item)
        else:out.append(mr(item) if isinstance(item,str) else item)
    return out
def slot(tag,items):
    e=OxmlElement('m:'+tag)
    for item in group(items):e.append(deepcopy(item))
    return e
def sub(base,idx):
    e=OxmlElement('m:sSub');e.append(slot('e',group(base)));e.append(slot('sub',group(idx)));return e
def power(base,exp='2'):
    e=OxmlElement('m:sSup');e.append(slot('e',group(base)));e.append(slot('sup',group(exp)));return e
def frac(a,b):
    e=OxmlElement('m:f');e.append(slot('num',group(a)));e.append(slot('den',group(b)));return e
def radical(items):
    e=OxmlElement('m:rad');pr=OxmlElement('m:radPr');de=OxmlElement('m:degHide');de.set(qn('m:val'),'1');pr.append(de);e.append(pr);e.append(slot('deg',[]));e.append(slot('e',group(items)));return e


def native_equation(doc,check,c):
    def squared_ratio(numerator,denominator):
        # Explicit delimiters keep the whole-fraction exponent unambiguous
        # when the native equation is rendered in Word or LibreOffice.
        d=OxmlElement('m:d');pr=OxmlElement('m:dPr')
        for tag,value in [('begChr','('),('endChr',')')]:
            char=OxmlElement('m:'+tag);char.set(qn('m:val'),value);pr.append(char)
        d.append(pr);d.append(slot('e',group(frac(numerator,denominator))))
        return power(d)
    fy=sub('f','y');fu=sub('f','u');g1=sub('γ','a1');g2=sub('γ','a2');Ag=sub('A','g');An=sub('A','n')
    cid=check.id
    if cid=='bolts':
        alpha='0,45' if c.threads or c.bolt=='ASTM A307' else '0,56'
        expr=group(sub('F','Rd'),' = ',frac(group(sub('k','pega'),alpha,'π',power(sub('d','b')),sub('f','ub')),group('4',g2)))
    elif cid.startswith('bearing'):
        expr=group(sub('F','Rd'),' = ',frac(group('min(1,2',sub('l','c'),'t',fu,'; 2,4',sub('d','b'),'t',fu,')'),g2))
    elif cid in ['plate_vy','plate_vu','plate_ny','plate_nu']:
        rupture=cid.endswith('u');shear=cid.startswith('plate_v')
        expr=group(sub('V' if shear else 'N','Rd'),' = ',frac(group('0,60' if shear else '',fu if rupture else fy,An if rupture else Ag),g2 if rupture else g1))
    elif cid.startswith('interaction'):
        expr=group('η = ',power(group('[n/2 + m]')),' + ',power('v'),' ≤ 1   (n < 0,2)')
        expr2=group('η = ',power(group('[n + 8m/9]')),' + ',power('v'),' ≤ 1   (n ≥ 0,2)')
        _math(doc,expr);_math(doc,expr2);return
    elif cid.startswith('sp_weld_full_'):
        expr=group(sub('τ','max'),' = ',sub('max','pontas'),' ',radical(group(power(sub('τ','x')),' + ',power(sub('τ','y')))),
                   ' ≤ ',sub('f','w,Rd'),' = ',frac(group('0,60',sub('f','w')),sub('γ','w2')))
    elif cid=='weld':
        expr=group(sub('q','max'),' = ',radical(group(power(group('(',frac('N','2h'),' + ',frac('3M',power('h')),')')),' + ',power(group('(',frac('V','2h'),')')))))
        _math(doc,expr)
        expr=group(sub('q','Rd'),' = ',frac(group('0,60',sub('f','w'),'w'),group(radical('2'),sub('γ','w2'))))
    elif cid=='plate_mu':expr=group(sub('M','Rd'),' = ',frac(group(fu,sub('Z','n')),g2))
    elif cid=='plate_ltb':expr=group(sub('M','Rd'),' = ',frac(sub('M','n'),g1),' ; ',sub('M','n'),' = min(',sub('M','p'),'; ',sub('C','b'),'[1,52 − 0,274λ',frac(fy,'E'),']',fy,'W)')
    elif cid=='beam_vm':expr=group('η = ',frac('M',group(sub('M','BC,Rd'),' + ',sub('V','AB,Rd'),'ℓ')),' + ',frac('N',sub('N','web,Rd')),' ≤ 1')
    elif cid=='support_punch':
        expr=group(sub('t','p'),' ≤ max[',frac(group(sub('t','s'),sub('f','u,s')),group(sub('f','y,p'),g2)),'; ',frac(group(sub('t','s'),sub('t','p'),sub('f','u,s'),power(sub('h','p'))),group('6Ve',g2)),']')
        if c.N>0 or c.V==0:expr=group(sub('t','p'),' ≤ ',frac(group(sub('t','s'),sub('f','u,s')),group(sub('f','y,p'),g2)))
    elif cid=='support_shear':expr=group(sub('R','Rd'),' = min(',frac(group('1,2',fy,'h',sub('t','s')),g1),'; ',frac(group('1,2',fu,'h',sub('t','s')),g2),')')
    elif cid=='support_web_y':expr=group('max(T; C) ≤ ',frac(group('1,10(2,5k + ',sub('l','n'),')',fy,sub('t','w')),g1))
    elif cid=='support_crippling':expr=group('C ≤ ',frac(group('0,33',power(sub('t','w')),radical(group('E',fy,sub('t','f'),'/',sub('t','w')))),g1))
    elif cid=='support_joint_base':expr=group(sub('r','max'),' ≤ min(',frac(group('0,6',fy,sub('t','w')),g1),'; ',frac(group('0,6',fu,sub('t','w')),g2),')')
    elif cid=='support_flange':expr=group('T ≤ ',frac(group('0,5 × 6,25',power(sub('t','f')),fy),g1))
    elif cid.startswith('block'):
        if cid=='block_plate':
            _math(doc,group(sub('R','v'),' = ',frac(group('min(0,60',fu,sub('A','nv,V'),' + ',sub('C','ts,V'),fu,sub('A','nt,V'),'; 0,60',fy,sub('A','gv,V'),' + ',sub('C','ts,V'),fu,sub('A','nt,V'),')'),g2)))
            _math(doc,group(sub('R','n'),' = ',frac(group('min(0,60',fu,sub('A','nv,N'),' + ',fu,sub('A','nt,N'),'; 0,60',fy,sub('A','gv,N'),' + ',fu,sub('A','nt,N'),')'),g2)))
            _math(doc,group(sub('C','ts,V'),' = '+('0,5' if c.bolt_columns==2 else '1,0'),' ; ',sub('C','ts,N'),' = 1,0'))
            expr=group('η = ',squared_ratio('V',sub('R','v')),' + ',squared_ratio('N',sub('R','n')),' ≤ 1')
        else:expr=group(sub('R','Rd'),' = ',frac(group('min(0,60',fu,sub('A','nv'),' + ',fu,sub('A','nt'),'; 0,60',fy,sub('A','gv'),' + ',fu,sub('A','nt'),')'),g2))
    elif cid=='base_plate':expr=group(sub('q','Rd'),' = min(',frac(group('0,60',fy,sub('t','p')),g1),'; ',frac(group('0,60',fu,sub('t','p')),g2),')')
    elif cid=='beam_v':
        if c.cope=='none':
            _math(doc,group(sub('A','gv'),' = ',sub('h','livre'),sub('t','w'),' ; ',sub('A','nv'),' = (d − n',sub('d','n'),')',sub('t','w')))
            _math(doc,group(sub('V','y,Rd'),' = ',frac(group('0,60',fy,sub('A','gv')),g1),' ; ',sub('V','b,Rd'),' = ',sub('C','v'),sub('V','y,Rd')))
            _math(doc,group(sub('V','u,Rd'),' = ',frac(group('0,60',fu,sub('A','nv')),g2)))
            expr=group(sub('V','Rd'),' = min(',sub('V','y,Rd'),'; ',sub('V','b,Rd'),'; ',sub('V','u,Rd'),')')
        else:expr=group(sub('V','Rd'),' = ',frac(group('0,60',fy,sub('h','web'),sub('t','w')),g1))
    elif cid=='beam_n':expr=group(sub('N','Rd'),' = min(',frac(group(fy,Ag),g1),'; ',frac(group(fu,An),g2),')')
    elif cid=='ductility':expr=group(sub('t','p'),' ≤ ',frac(group('6',sub('R','n,par'),'C′'),group(fy,power(sub('h','p')))))
    elif cid=='weld_development':expr=group('w ≥ max(',frac(group('5',sub('t','p')),'8'),'; ',frac(group(radical('3'),sub('t','p'),fy),group('2',sub('f','w'))),')')
    elif cid=='cope_interaction':expr=group('η = ',frac('N',sub('N','Rd')),' + ',frac(sub('M','c'),sub('M','Rd')),' + ',frac('V',sub('V','Rd')),' ≤ 1')
    elif cid=='cope_rupture':expr=group('η = ',frac(sub('M','c'),group(fu,sub('Z','n'),'/',g2)),' + ',frac('N',group(fu,An,'/',g2)),' ≤ 1')
    elif cid=='cope_block':
        _math(doc,group(sub('R','v'),' = ',frac(group('min(0,60',fu,sub('A','nv,V'),' + ',sub('C','ts,V'),fu,sub('A','nt,V'),'; 0,60',fy,sub('A','gv,V'),' + ',sub('C','ts,V'),fu,sub('A','nt,V'),')'),g2)))
        _math(doc,group(sub('C','ts,V'),' = '+('0,5' if c.bolt_columns==2 else '1,0'),' ; ',sub('C','ts,N'),' = 1,0'))
        expr=group('η = ',squared_ratio('V',sub('R','v')),' + ',squared_ratio('N',sub('R','n')),' ≤ 1')
    elif cid=='beam_buckling':expr=group(sub('V','Rd'),' = ',frac(group('0,6',fy,'h',sub('t','w'),sub('C','v')),g1))
    elif cid=='support_web_n':
        expr=group(sub('N','Rd'),' = ',frac(group(fy,power(sub('t','w')),group('[4',radical('2wuv(u+v)'),' + L(u+v)]')),group('4',g1,'uv')))
    elif cid=='support_web_punch_n':
        expr=group(sub('N','Rd'),' = ',frac(group('0,6',fu,'·2(',sub('h','p'),' + ',sub('t','p'),')',sub('t','w')),g2))
    elif cid.startswith('full_weld_'):
        expr=group('τ = ',radical(group(power(group('(',frac('N',sub('A','w')),' − ',frac('My',sub('J','w')),')')),' + ',power(group('(',frac('V',sub('A','w')),' + ',frac('Mx',sub('J','w')),')')))),' ≤ ',frac(group('0,6',sub('f','w')),sub('γ','w2')))
    elif cid.startswith('full_base_'):
        expr=group(sub('q','Sd'),' ≤ min(',frac(group('0,6',sub('f','y,p'),sub('t','p')),g1),'; ',frac(group('0,6',sub('f','u,p'),sub('t','p')),g2),'; ',frac(group('0,6',sub('f','y,s'),sub('t','s')),g1),'; ',frac(group('0,6',sub('f','u,s'),sub('t','s')),g2),')')
    elif cid in ('full_compactness','opposite_compactness'):
        expr=group(frac(sub('b','r' if cid=='full_compactness' else 'e'),sub('t','p' if cid=='full_compactness' else 'e')),' ≤ ',frac('200',radical(fy)))
    else:
        # Novos estados limite nunca recebem uma equação de tração genérica.
        doc.add_paragraph(check.equation)
        return
    _math(doc,expr)


def _math(doc,expr):
    p=doc.add_paragraph();p.paragraph_format.space_after=Pt(4)
    m=OxmlElement('m:oMath')
    for item in expr:m.append(deepcopy(item))
    p._p.append(m)


def _input_number(value):
    """Displayed native-unit input; raw project/export remains lossless."""
    return display_value(value).replace('.',',')


SINGLE_PLATE_WELD_EDGES={'web':'Alma do apoio','top':'Mesa superior','bottom':'Mesa inferior'}


def single_plate_check_kind(check):
    if isinstance(check,SinglePlateFullDepthWeldCheck):return 'Solda · hipótese elástica'
    if isinstance(check,SinglePlateNominalReferenceCheck):return 'Referência retangular nominal'
    return check.category


def single_plate_weld_geometry_rows(wg):
    return [(SINGLE_PLATE_WELD_EDGES[s['id']],'; '.join(number(x) for x in s['start_mm']),
             '; '.join(number(x) for x in s['end_mm']),number(s['length_mm']),
             number(s['leg_mm']),number(s['throat_mm']),number(s['area_mm2'])) for s in wg['segments']]


def single_plate_weld_reaction_rows(wg):
    return [(SINGLE_PLATE_WELD_EDGES[s['id']],number(s['integrated_Fx_N']/KGF),
             number(s['integrated_Fy_N']/KGF),number(s['integrated_M_about_origin_Nmm']/(KGF*1000)),
             number(s['local_couple_Nmm']/(KGF*1000))) for s in wg['segments']]


def single_plate_weld_stress_rows(wg):
    return [(SINGLE_PLATE_WELD_EDGES[s['id']],number(p['x_mm'])+'; '+number(p['y_mm']),
             number(p['sx_MPa']),number(p['sy_MPa']),number(p['resultant_MPa']),
             number(p['resultant_MPa']/s['stress_resistance_MPa']))
            for s in wg['segments'] for p in s['endpoint_stresses']]


def single_plate_weld_group_caption(wg):
    return (f"Aw={number(wg['area_mm2'])} mm²; centroide G=({number(wg['centroid_x_mm'])}; "
            f"{number(wg['centroid_y_mm'])}) mm; Jw={number(wg['J_mm4'])} mm⁴. "
            f"M0={number(wg['moment_about_origin_Nmm']/(KGF*1000))} kgf·m; "
            f"MG={number(wg['moment_about_centroid_Nmm']/(KGF*1000))} kgf·m.")


def single_plate_weld_critical_caption(wg):
    p=wg['critical_point']
    return (f"Ponto crítico: {SINGLE_PLATE_WELD_EDGES[p['segment']]}, "
            f"({number(p['x_mm'])}; {number(p['y_mm'])}) mm. "
            f"τmáx={number(p['resultant_MPa'])} MPa; fw,Rd={number(wg['stress_resistance_MPa'])} MPa; "
            f"índice local={number(wg['max_utilization'])}. O estado de cada borda consta no resumo.")


def _single_plate_weld_report(doc,r):
    wg=r.full_depth_weld_group
    if not wg:return
    doc.add_paragraph('Soldas entre mesas · grupo elástico de três bordas',style='Heading 1').paragraph_format.page_break_before=True
    doc.add_paragraph(wg['sign_convention'])
    doc.add_paragraph(wg['component_envelope_note'])
    doc.add_paragraph('Dois filetes simétricos por borda; garganta a=w/√2. A rigidez é ponderada pela área de garganta, com alívios sem solda. τx e τy são componentes do vetor equivalente do grupo, não uma decomposição normal/cisalhante do tensor real da garganta. A resistência usa a resultante vetorial da Tabela 9, sem aumento direcional.')
    table(doc,['Borda','Início x; y mm','Fim x; y mm','L útil mm','w mm','a mm','Aw mm²'],single_plate_weld_geometry_rows(wg),[1.3,1.05,1.05,.75,.65,.65,1.05])
    _math(doc,group(sub('A','w'),' = Σ2aL ; ',sub('M','0'),' = ',sub('x','P'),sub('F','y'),' − ',sub('y','P'),sub('F','x'),' ; ',sub('M','G'),' = ',sub('M','0'),' − ',sub('x','G'),sub('F','y'),' + ',sub('y','G'),sub('F','x')))
    _math(doc,group(sub('τ','x'),' = ',frac(sub('F','x'),sub('A','w')),' − ',frac(group(sub('M','G'),'(', 'y − ',sub('y','G'),')'),sub('J','w')),' ; ',sub('τ','y'),' = ',frac(sub('F','y'),sub('A','w')),' + ',frac(group(sub('M','G'),'(', 'x − ',sub('x','G'),')'),sub('J','w'))))
    for label,g in [('Entrada',r.actual_full_depth_weld_group),('Conferência governante',wg)]:
        if g is None:continue
        doc.add_paragraph(label if label==g['case'] else label+' · '+g['case'],style='Heading 2')
        doc.add_paragraph(single_plate_weld_group_caption(g))
        px,py=g['load_point_mm']
        doc.add_paragraph(f"Aplicação P=({number(px)}; {number(py)}) mm; Fx={number(g['force_x_N']/KGF)} kgf; Fy={number(g['force_y_N']/KGF)} kgf. M0 e MG são assinados, sem envoltória nem acréscimo duplicado do momento do grupo de parafusos.")
        table(doc,['Borda','Fx kgf','Fy kgf','M0 kgf·m','Binário local kgf·m'],single_plate_weld_reaction_rows(g),[1.65,1.1,1.1,1.25,1.4])
        sums=[sum(s[key] for s in g['segments']) for key in ('integrated_Fx_N','integrated_Fy_N','integrated_M_about_origin_Nmm')]
        residual=[sums[0]-g['force_x_N'],sums[1]-g['force_y_N'],sums[2]-g['moment_about_origin_Nmm']]
        doc.add_paragraph(f"Equilíbrio: ΣFx={number(sums[0]/KGF)} kgf; ΣFy={number(sums[1]/KGF)} kgf; ΣM0={number(sums[2]/(KGF*1000))} kgf·m. Resíduos Fx/Fy/M0: {number(residual[0])} N; {number(residual[1])} N; {number(residual[2])} N·mm. O momento de cada borda inclui o binário local, além do momento da resultante.")
    doc.add_paragraph('Tensões nas extremidades · '+wg['case'],style='Heading 2')
    table(doc,['Borda','Ponto x; y mm','τx MPa','τy MPa','τresult. MPa','Índice'],single_plate_weld_stress_rows(wg),[1.4,1.25,1.,1.,1.15,.7])
    doc.add_paragraph(single_plate_weld_critical_caption(wg))
    doc.add_paragraph('Mudança do caminho de carga',style='Heading 2')
    doc.add_paragraph('Os antigos itens de linha única abaixo são substituídos ou ficam pendentes; não aparecem como aprovações dos receptores. As referências retangulares nominais permanecem identificadas separadamente no resumo.')
    labels={'weld':'Solda vertical isolada','base_plate':'Metal-base da chapa','support_shear':'Cisalhamento da alma do apoio','support_punch':'Hierarquia contra punção','support_web_n':'Plastificação da alma do apoio','support_web_punch_n':'Punção da alma sob N','weld_development':'Desenvolvimento da solda vertical'}
    table(doc,['Item anterior','Tratamento no modelo de três bordas'],[(labels.get(key,key),value) for key,value in wg['replaced_checks'].items()],[2.,4.6])


def _single_plate_conclusion(doc,r):
    """Coverage belongs beside the result; do not conflate its independent gates."""
    resistance=r.resistance_failures
    method=r.method_failures
    numeric=r.numeric_failures
    conditional=r.conditional_model_failures
    failures=resistance+method+numeric+conditional
    if numeric:
        doc.add_paragraph('Falha numérica: '+'; '.join(x.name for x in numeric)+'. Capacidade ou relação inválida; esses itens não demonstram atendimento nem falha resistente. Revisar os valores de entrada e o cálculo.')
    if resistance:
        worst=max(resistance,key=lambda x:x.ratio)
        doc.add_paragraph(f'A ligação não atende às verificações resistentes. Falha resistente governante: {display_value(worst.name)}; índice = {display_value(number(worst.ratio, 6))}. As demais condições abaixo não eliminam essa falha.')
    if method:
        doc.add_paragraph('Condições do método não atendidas: '+'; '.join(x.name for x in method)+'. São requisitos de aplicação/hierarquia, não índices resistentes sob a ação aplicada.')
    if conditional:
        doc.add_paragraph('Modelo local condicionado não atendido: '+'; '.join(x.name for x in conditional)+'. A hipótese elástica ou a referência retangular nominal é excedida; esse resultado não demonstra isoladamente falha física do conjunto de três bordas.')
    shown=set()
    for issue in r.issues:
        if issue.severity=='error':label={'numeric':'Falha numérica','material':'Material fora do domínio'}.get(issue.origin,'Geometria ou entrada inválida')
        elif issue.severity=='noncompliance':label='Detalhamento não atendido'
        elif issue.severity=='extrapolation':label='Fora do domínio verificado'
        elif issue.severity=='outside_method':label='Fora do método'
        elif issue.severity=='pending':label='Dado faltante' if issue.origin=='data' else 'Condição de aplicação pendente'
        elif issue.origin=='local_scope' or issue.text==SUPPORT_WEB_EXCLUSION:label='Mecanismo local não verificado'
        else:continue
        doc.add_paragraph(label+': '+calculated_text(issue.text, assignments_only=True)+' ['+issue.reference+']')
        shown.add(id(issue))
    if not failures and not shown:
        doc.add_paragraph('As verificações locais incluídas nesta versão atendem para a geometria e as hipóteses registradas.')
    doc.add_paragraph('Responsabilidade externa de projeto: análise global dos membros e da estrutura, sistema de contenção e integridade estrutural. Essas verificações não são concluídas por este resultado local.')
    return shown


def create_report(c,r,detailed=False):
    if (c.opposite_stiffener or c.full_depth) and c.kind!='beam_web':
        raise ValueError('Complemento e enrijecedor oposto disponíveis apenas em viga–viga.')
    if c.full_depth:
        from .engine import evaluate
        r=evaluate(c)
    doc=Document();s=doc.sections[0]
    s.page_width=Inches(8.5);s.page_height=Inches(11)
    s.top_margin=s.bottom_margin=Inches(.6);s.left_margin=s.right_margin=Inches(.7)
    for name in ['Normal','Title','Heading 1','Heading 2']:
        st=doc.styles[name];st.font.name='Arial';st.font.color.rgb=RGBColor(0,0,0)
    for style in doc.styles:
        for border in style.element.xpath('.//w:pBdr'):
            border.getparent().remove(border)
    normal=doc.styles['Normal'];normal.font.size=Pt(9.5);normal.paragraph_format.space_after=Pt(5)
    doc.styles['Title'].font.size=Pt(20)
    doc.styles['Heading 1'].font.size=Pt(12);doc.styles['Heading 2'].font.size=Pt(10)
    doc.core_properties.author='LRO Soluções de engenharia LTDA.'
    doc.core_properties.title='Memória de cálculo de ligação com chapa simples'
    doc.add_paragraph('Ligação com chapa simples' if r.checks else 'Pré-detalhamento de ligação',style='Title')
    doc.add_paragraph(c.project)
    doc.add_paragraph(f'{display_value(c.beam.name)} → {display_value(c.support.name)} | '+('Alma da viga de apoio' if c.kind=='beam_web' else 'Mesa do pilar alinhada à alma'))
    p=doc.add_paragraph();p.add_run(r.status).bold=True
    if r.governing:
        p.add_run((' · maior índice calculado (escopos separados)' if c.full_depth else ' · índice resistente máximo')+(' entre resultados válidos' if r.numeric_failures else '')+f' {display_value(number(r.governing.ratio, 3))} · {display_value(r.governing.name)}')
    conclusion_issues=_single_plate_conclusion(doc,r)
    if r.calculation_note:doc.add_paragraph(r.calculation_note)
    if not r.checks:doc.add_paragraph('Somente geometria e materiais: não há resistência calculada nem aprovação estrutural desta configuração.')
    interferences=[i for i in r.issues if i.severity=='interference']
    if interferences:doc.add_paragraph('Cálculo realizado com avisos de interferência. As dimensões nominais informadas foram mantidas; os avisos de montagem constam nas premissas finais.')
    doc.add_picture(BytesIO(image_bytes(c)),width=Inches(7.05))
    doc.add_paragraph('Dimensões e materiais adotados',style='Heading 1')
    geom=[('Chapa',f'{display_value(number(c.width))} × {display_value(number(c.hp))} × {display_value(number(c.tp, 4))} mm',c.plate_steel),('Parafusos',f'{display_value(c.n)} × Ø {display_value(number(c.db, 3))} mm',c.bolt),('Furos',f'Ø {display_value(number(c.dh, 4))} mm', 'Padrão; '+('broca' if c.drilled else 'desconto líquido +2 mm')),('Soldas',f'2 filetes de {display_value(number(c.weld))} mm; L = {display_value(number(c.hp))} mm',f'fw = {display_value(number(c.fw, 0))} MPa'),('Posições',f"z = {display_format(c.plate_top, 'g')}; a = {display_format(c.a, 'g')}; g = {display_format(c.gap, 'g')}; p = {display_format(c.pitch, 'g')}; eᵥ = eₕ = {display_format(c.edge_v, 'g')}" if c.edge_v==c.edge_h else f"z = {display_format(c.plate_top, 'g')}; a = {display_format(c.a, 'g')}; g = {display_format(c.gap, 'g')}; p = {display_format(c.pitch, 'g')}; eᵥ = {display_format(c.edge_v, 'g')}; eₕ = {display_format(c.edge_h, 'g')}", 'mm'),('Viga apoiada',f"d/bf/tw/tf = {display_format(c.beam.d, 'g')}/{display_format(c.beam.bf, 'g')}/{display_format(c.beam.tw, 'g')}/{display_format(c.beam.tf, 'g')}",c.beam_steel),('Apoio',f"d/bf/tw/tf = {display_format(c.support.d, 'g')}/{display_format(c.support.bf, 'g')}/{display_format(c.support.tw, 'g')}/{display_format(c.support.tf, 'g')}",c.support_steel)]
    geom[1]=('Parafusos',f'{display_value(c.n * c.bolt_columns)} × Ø {display_value(number(c.db, 3))} mm; {display_value(c.n)} linhas × {display_value(c.bolt_columns)} coluna(s)',c.bolt)
    geom[2]=('Furos',f'{display_value(c.n * c.bolt_columns)} furos; Ø {display_value(number(c.dh, 4))} mm; dn = {display_value(number(c.dh_net, 4))} mm', 'Padrão; '+('broca' if c.drilled else 'desconto líquido +2 mm'))
    if c.full_depth:
        geom[0]=('Chapa recortada',f'Aba: {display_value(number(c.width))} × {display_value(number(c.hp))} mm; t = {display_value(number(c.tp, 4))} mm',c.plate_steel)
        geom[3]=('Soldas',f'Dois filetes por borda; alma: w = {number(c.weld)} mm; mesas: w = {number(c.flange_weld)} mm',f'fw = {number(c.fw, 0)} MPa; comprimentos úteis e gargantas no grupo de três bordas')
        geom.append(('Entre mesas',f'H = {display_value(number(c.root_height))}; bᵣ = {display_value(number(c.root_width))}; c = {display_value(number(c.corner_clip))} mm','Alívios a 45°; chapa soldada à alma e mesas'))
    if c.opposite_stiffener:
        geom.append(('Enrijecedor oposto',f'Hₑ = {display_value(number(c.root_height))}; bₑ = {display_value(number(c.stiffener_width))}; tₑ = {display_value(number(c.stiffener_t, 4))}; cₑ = {display_value(number(c.stiffener_clip))} mm',c.stiffener_steel+'; coplanar à single plate; alívios a 45°'))
        geom.append(('Soldas do enrijecedor',f'2 filetes wₑ = {display_value(number(c.stiffener_weld))} mm na alma e em cada mesa; interrompidos nos alívios',f'fw = {display_value(number(c.fw, 0))} MPa; dimensões informadas, sem crédito no cálculo'))
    if c.bolt_columns>1:geom.append(('Passo horizontal',f's = {display_value(number(c.gauge))} mm','Grupo bidimensional; furos alinhados'))
    if not c.full_depth and c.kind=='beam_web' and c.N>0 and not c.support_web_combined_excluded:
        geom.append(('Alma do apoio',f'Distância longitudinal livre = {display_value(number(c.support_edge_distance))} mm' if c.support_edge_distance else 'Distância longitudinal livre não informada','Menor valor nos dois sentidos a partir do eixo da chapa'))
    if c.kind=='column_flange' and c.support.family in ('CS','CVS','VS','Soldado'):
        geom.append(('Fabricação do perfil','Juntas mesa–alma de penetração total','Metal de adição compatível; hipótese de projeto'))
    table(doc,['Componente','Dimensões','Material ou especificação'],[(a,decimal_text(b),cc) for a,b,cc in geom],[1.1,3.25,2.75])
    mats=[]
    material_list=[('Chapa',c.plate_steel),('Viga',c.beam_steel),('Apoio',c.support_steel)]
    if c.opposite_stiffener:material_list.append(('Enrijecedor',c.stiffener_steel))
    for label,name in material_list:
        st=STEELS[name];mats.append(f"{display_value(label)}: fy = {display_format(st.fy, 'g')} MPa; fu = {display_format(st.fu, 'g')} MPa")
    doc.add_paragraph('Ligação: viga parafusada à single plate; single plate soldada à '+('alma e às mesas da viga de apoio.' if c.full_depth else 'alma da viga de apoio.' if c.kind=='beam_web' else 'mesa do pilar. Não há solda direta entre viga e pilar.'))
    doc.add_paragraph('; '.join(mats)+'. E = 200 000 MPa; γa1 = 1,10; γa2 = γw2 = 1,35.')
    doc.add_paragraph('Esforços e hipóteses',style='Heading 1')
    doc.add_paragraph(f'Entrada já majorada: V = {display_value(number(c.V / KGF))} kgf ({display_value(number(c.V / 1000, 3))} kN); N = {display_value(number(c.N / KGF))} kgf ({display_value(number(c.N / 1000, 3))} kN), tração positiva. Não se aplicam novos coeficientes de ações.')
    doc.add_paragraph(f'Valores canônicos de entrada preservados: V = {display_value(_input_number(c.V))} N; N = {display_value(_input_number(c.N))} N. '+('No grupo de três bordas, Fx=N e Fy=−V; o momento físico é M0=xP·Fy−yP·Fx. A envoltória M=|V|e+|N·eN| é preservada apenas nos componentes e referências nominais que a utilizam.' if c.full_depth else 'Os sinais pertencem ao caso informado; os índices locais usam a envoltória dos dois sentidos, com M = |V|e + |N·eN|.')+' N negativo permanece fora do método de tração; zero não define direção.')
    if r.minimum_factor>1:
        doc.add_paragraph(f'Verificação adicional do mínimo de 45 kN conforme NBR 8800, 6.1.5.2, na direção da resultante informada: V = {display_value(number(c.V * r.minimum_factor / KGF))} kgf; N = {display_value(number(c.N * r.minimum_factor / KGF))} kgf. Os resultados governantes abaixo incluem essa verificação.')
        doc.add_paragraph(f'Caso adicional em unidades canônicas: V = {display_value(_input_number(c.V * r.minimum_factor))} N; N = {display_value(_input_number(c.N * r.minimum_factor))} N; fator = {display_value(_input_number(r.minimum_factor))}. A entrada não é substituída pelo caso mínimo.')
        actual_resistance=[x for x in r.actual_summary if x.applicable and x.category=='Resistência']
        if actual_resistance:
            actual_max=max(actual_resistance,key=lambda x:x.ratio)
            doc.add_paragraph(('Caso Entrada: maior índice calculado = ' if c.full_depth else 'Caso Entrada: índice resistente máximo = ')+f'{display_value(number(actual_max.ratio, 6))} ({display_value(actual_max.name)}). O quadro resumo usa o caso adicional de 45 kN; cada desenvolvimento identifica seu caso.')
    doc.add_paragraph(f'Encontro a 90°; {display_value(c.bolt_columns)} coluna(s) de parafusos; soldagem em oficina. Face do apoio ao centro do grupo: e = {display_value(number(c.bolt_centroid_x))} mm. Excentricidade vertical de N: eN = {display_value(number(c.eccentric_n))} mm. '+('Referência geométrica nominal, distinta do momento físico das soldas: ' if c.full_depth else 'Referência geométrica: ')+'M = |V|e + |N·eN|. Contenção longitudinal da viga apoiada: eficaz por hipótese fixa definida para esta versão. Não há cortante horizontal nem momento no eixo de menor inércia. N é força axial de tração, distinta de cortante horizontal.')
    cope_label={'none':'sem recorte','top':'mesa superior','both':'mesas superior e inferior'}[c.cope]
    doc.add_paragraph(f"Posição z = {display_value(number(c.plate_top))} mm: distância da face superior da mesa da viga apoiada ao topo do trecho parafusado, antes do recorte. Desnível entre vigas: {display_value(number(c.beam_level))} mm. Recorte: {display_value(cope_label)}; dimensões superior/inferior/comprimento = {display_format(c.coped_top, 'g')}/{display_format(c.coped_bottom, 'g')}/{display_format(c.cope_length if c.cope != 'none' else 0, 'g')} mm. Folga de montagem = {display_format(c.clearance, 'g')} mm; raio do envelope de montagem = {display_format(c.tool_radius, 'g')} mm. Borda da solda reforçada: "+('sim.' if c.reinforced_weld else 'não.'))
    if c.kind=='column_flange' and r.checks:
        m,p,_=column_actions(c,c.V*r.minimum_factor,c.N*r.minimum_factor)
        doc.add_paragraph(f'Transmissão ao pilar: Mma = |V|(e+tf)+|N·eN| = {display_value(number(m / (KGF * 1000)))} kgf·m; resultantes locais T = {display_value(number(p.tension / KGF))} kgf e C = {display_value(number(p.compression / KGF))} kgf. Integração da carga linear p(y)=N/hp+12Mma·y/hp³; T−C=N. Inclui o mínimo normativo quando aplicável.')
        doc.add_paragraph('Hipótese do apoio: deslocamento lateral relativo entre as mesas do pilar impedido na região da ligação (NBR 8800, 5.7.5.1). A análise global do pilar permanece no projeto estrutural. Essa contenção é premissa, não conclusão decorrente da solda de penetração total.')
    if c.notes:doc.add_paragraph(c.notes)
    doc.add_paragraph('Referências e limites de aplicação',style='Heading 1')
    doc.add_paragraph('ABNT NBR 8800:2024, errata 2025: 5.2.4; 5.4.3.1; 5.7; 6.1.5.2; 6.2; 6.3; 6.5 e Anexo A. Gerdau, Manual de Ligações, 7ª edição, 5.4.1, p.98 e nomenclatura p.374: definição da área líquida da alma sem recorte, com resistências NBR atuais. AISC Companion v16.0, Volume 1, P901-23W: exemplos II.A-6, II.A-7, II.A-17B, II.A-18 e II.A-19B. SCI P358 (2014), seção 5. Muir e Hewitt (2009), Engineering Journal 46(2), p.67–80. Dowswell (2018), Engineering Journal 55(4), p.231–242. Procedimentos complementares AISC/SCI identificados por verificação, com resistências e coeficientes explicitados.')
    doc.add_paragraph('Proveniência do método complementar: o P901-23W original foi recuperado e os exemplos II.A-17B (IIA-180–193), II.A-19A (IIA-205–212) e II.A-19B (IIA-213–229) foram conferidos. A fonte contém N+V, duas colunas, detalhes estendidos e contenção contra rotação de menor inércia. O bloco L completo da chapa sob V usa tensão não uniforme e Cts,V=0,5 nas duas colunas; os caminhos N e U mantêm 1,0. A qualificação remanescente refere-se ao domínio completo da dispensa automática da Tabela 10-9 do Manual; a hierarquia explícita dos exemplos foi confirmada. Permanecem declaradas as adaptações brasileiras, a excentricidade de N e a exclusão da interação fora do plano da alma da viga de apoio.')
    if any(name.startswith('USI-CIVIL') for label,name in material_list):
        doc.add_paragraph('USI-CIVIL: propriedades mínimas e espessuras de 6 a 75 mm conforme Usiminas, Catálogo de chapas grossas, jul. 2022, p.29. Aplicação em chapas e perfis soldados; não são especificações de perfis W laminados.')
        hyperlink(doc.add_paragraph(),'Catálogo Usiminas — fonte das propriedades','https://usiminas.com/wp-content/uploads/2024/04/CatalagoChapasGrossas.pdf')
    doc.add_paragraph(f'Versão {display_value(PACKAGE_ID)}, escopo delimitado: uma viga, tração axial e cortante no plano. O mínimo normativo é avaliado pela resultante. Premissas e limites do modelo no tópico final.')
    if not c.full_depth and c.kind=='beam_web' and c.N>0 and not c.support_web_combined_excluded:
        doc.add_paragraph('Plastificação da alma: AISC Manual 16, eq.9-45; P901 II.A-19B, IIA-228; Kapp, Engineering Journal 11(2), 1974, p.38–41. A expressão é aplicada somente à tração direta centrada, sem cortante, e exige a distância longitudinal livre indicada.')
    if c.full_depth:_single_plate_weld_report(doc,r)
    doc.add_paragraph('Resumo das verificações' if r.checks else 'Cobertura do pré-detalhamento',style='Heading 1')
    if r.checks:
        categories=('Resistência','Solda · hipótese elástica','Referência retangular nominal','Condição do método') if c.full_depth else ('Resistência','Condição do método')
        for category in categories:
            checkrows=[]
            for x in r.summary_checks:
                if single_plate_check_kind(x)!=category:continue
                sd,unit=display(x.demand,x.unit);rd,_=display(x.resistance,x.unit)
                checkrows.append((x.name,sd if x.numerically_valid else '—',rd if x.numerically_valid else '—',unit,number(x.ratio,3) if x.numerically_valid and x.applicable else '—',x.outcome))
            if checkrows:
                doc.add_paragraph({'Resistência':'Resistências locais','Condição do método':'Condições de aplicação e hierarquia'}.get(category,category),style='Heading 2')
                if category=='Condição do método':doc.add_paragraph(r.method_provenance_note)
                table(doc,['Verificação','Sd / valor','Rd / limite','Unid.','Índice','Estado'],checkrows,[2.7,.9,.9,.55,.65,1.4])
        doc.add_paragraph('N/A: caminho axial sem solicitação N; não constitui aprovação resistente. '+('As capacidades N/V/M, interações, blocos e ductilidade da chapa são referências retangulares nominais; não validam a transferência na chapa recortada. Soldas elásticas e resistências independentes de parafusos/alma da viga estão separadas acima. Não há aprovação escalar de metal-base ou dos receptores.' if c.full_depth else 'As seis capacidades isoladas de chapa N/V/M alimentam as duas interações e aparecem somente no desenvolvimento. Os caminhos físicos distintos de bloco, solda e metal-base são mantidos.'))
        doc.add_paragraph('Condições de método, incluindo compacidade, não são índices de utilização sob a carga aplicada. Índices de interação também não são multiplicadores lineares da carga. O atendimento usa valores sem arredondamento e abrange somente as verificações realizadas.')
        doc.add_paragraph('Memória de cálculo',style='Heading 1')
        doc.add_paragraph('As substituições usam N, mm e MPa; os resultados principais são apresentados em kgf e kgf·m. Conversão: 1 kgf = 9,80665 N. Variáveis geométricas seguem o desenho. Na versão compacta, desenvolvem-se os caminhos determinantes, as falhas e todas as capacidades intermediárias da chapa que alimentam as duas interações.')
    else:
        doc.add_paragraph('Conferidas as dimensões, o arranjo dos furos, os envelopes de montagem e os limites geométricos de solda implementados. Não foram verificadas resistências, redistribuição de esforços, estabilidade ou capacidade de rotação do conjunto. O mínimo normativo de força também não foi aplicado a resistências nesta variante.')
        doc.add_paragraph(f'Área geométrica da chapa, antes da dedução dos furos: {display_value(number(polygon_area(plate_outline(c))))} mm². Essa área serve apenas para detalhamento e não define uma área resistente equivalente.')
    if detailed:selected=r.checks
    else:
        groups=[['bolts'],['bearing_plate','bearing_beam'],['plate_ltb','plate_mu','interaction_y','interaction_u','block_plate','block_plate_u','block_plate_partial_u','partial_plate_l'],['beam_v','beam_n','block_beam_u','beam_vm','beam_buckling','cope_interaction','cope_rupture','cope_block','block_beam_partial_u','partial_beam_l'],['weld','base_plate'],['support_shear','support_punch','support_web_y','support_flange','support_joint_weld','support_joint_base'],['support_crippling'],['ductility','weld_development']]
        selected=[]
        groups.extend([['support_web_n'],['support_web_punch_n']])
        for groupids in groups:
            candidates=[x for x in r.checks if x.id in groupids and x.numerically_valid and x.applicable and x.summary_visible]
            if candidates:selected.append(max(candidates,key=lambda x:x.ratio))
        selected_ids={x.id for x in selected}
        selected=[x for x in r.checks if x.id in selected_ids or not x.summary_visible or x.id in ('interaction_y','interaction_u','beam_v') or x.id.startswith('sp_weld_full_') or (x.applicable and not x.passed)]
    for x in selected:
        start=len(doc.paragraphs)
        doc.add_paragraph(x.name,style='Heading 2')
        native_equation(doc,x,c)
        if x.id=='cope_interaction':doc.add_paragraph(x.equation.split('; ',1)[1])
        doc.add_paragraph('Caso: '+x.case+'. '+decimal_text(calculated_text(x.substitution)))
        sd,u=display(x.demand,x.unit);rd,_=display(x.resistance,x.unit)
        labels=('Valor','Limite') if x.category=='Condição do método' else ('Sd','Rd')
        if not x.numerically_valid:
            doc.add_paragraph('Falha numérica: capacidade ou relação inválida. Sem índice de utilização resistente nem conclusão deste item; a substituição acima permite rastrear o problema.')
        elif not x.applicable:
            doc.add_paragraph(f'N/A: N = 0; caminho axial sem solicitação. Capacidade calculada = {display_value(rd)} {display_value(u)}, sem conclusão de atendimento deste caminho.')
        elif not x.summary_visible:
            doc.add_paragraph(f'Capacidade intermediária da chapa: Rd = {display_value(rd)} {display_value(u)}; Sd = {display_value(sd)} {display_value(u)}. Integra a envoltória combinada de escoamento/estabilidade ou ruptura, sem aprovação isolada no resumo.')
        else:
            doc.add_paragraph(f'Resultado: {display_value(labels[0])} = {display_value(sd)} {display_value(u)}; {display_value(labels[1])} = {display_value(rd)} {display_value(u)}; índice = {display_value(number(x.ratio, 3))}. '+x.outcome+'.')
        variables=x.variables
        if x.id.startswith('sp_weld_full_') and r.full_depth_weld_group:
            variables=variables.replace(r.full_depth_weld_group['assumption']+' ','')
        doc.add_paragraph(calculated_text(variables, assignments_only=True)+' Referência: '+x.reference)
        for paragraph in doc.paragraphs[start:-1]:
            paragraph.paragraph_format.keep_with_next=True
    doc.add_paragraph('Premissas adotadas',style='Heading 1')
    doc.add_paragraph('Modelo plano, contenção eficaz da viga e juntas internas mesa–alma dos perfis soldados com penetração total e metal de adição compatível. Deslocamento lateral relativo entre as mesas da coluna impedido por hipótese. Não se incluem a análise global da estrutura, atrito, fadiga, vibração ou ações cíclicas.')
    for issue in r.issues:
        if issue.severity in ('excluded','extrapolation','noncompliance') and id(issue) not in conclusion_issues:doc.add_paragraph(calculated_text(issue.text, assignments_only=True)+' ['+issue.reference+']')
    if interferences:
        doc.add_paragraph('Avisos de montagem',style='Heading 2')
        for issue in interferences:doc.add_paragraph(calculated_text(issue.text, assignments_only=True))
    p=s.footer.paragraphs[0];p.paragraph_format.space_after=Pt(0)
    r0=p.add_run(BRAND+' ');r0.font.size=Pt(7)
    hyperlink(p,'LinkedIn de Lucas Oliveira',LINK)
    p=s.footer.add_paragraph(f'LRO Ligações {display_value(PACKAGE_ID)} · ');p.paragraph_format.space_after=Pt(0)
    fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');p._p.append(fld)
    for r0 in p.runs:r0.font.size=Pt(7)
    buf=BytesIO();doc.save(buf);return buf.getvalue()
