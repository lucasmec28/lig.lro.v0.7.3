"""Bounded local seat checks. Independent input schema; no complete-connection approval.
References: ASI DG6 (2007), A3 pp7-8 and B6/B8 pp26-32 / AS4100.
Private engineering review only; commercial use requires publisher permission.
"""
from dataclasses import dataclass, asdict, fields
import math
from .models import Profile, STEELS, profiles, finite_real
from .beam_direct_seat import _row, _same_json
FAMILY = 'Apoios de viga · concreto, coluna e cantoneira'
VERSION = '0.9.55-bolted-seat-dev.1'
LEGACY_VERSIONS = {'0.9.52-seated-local-dev.2', '0.9.54-seated-paths-dev.1'}
BOLTED_FIELDS = ('bolt_top', 'bolt_pitch', 'bolt_gauge', 'column_top_edge', 'column_bottom_edge', 'bolt_tool_radius', 'bolt_tool_length')
WELD_ELECTRODES = {'E41XX / W40X': 410.0, 'E48XX / W50X': 480.0}
WELD_CATEGORIES = {'SP': .80, 'GP': .60}
ANGLE_STEELS = {'AS/NZS 3679.1 Grade 300': 300.0}
LABELS = {'concrete_end':'A1(a)/A3 · apoio direto por gravidade, sem ancoragem', 'column_continuous':'A1(e) · viga contínua sobre coluna', 'angle_seat':'B1/B9 · cantoneira à mesa da coluna'}
@dataclass(frozen=True)
class SeatedVariant:
    variant: str
    beam: Profile
    support: Profile
    beam_steel: str = 'ASTM A572 Gr.50'
    support_steel: str = 'ASTM A572 Gr.50'
    V: float = 25595.3565
    shear_left: float = 12797.67825
    shear_right: float = 12797.67825
    bearing_length: float = 100.
    bearing_width: float = 140.
    packer_thickness: float = 0.
    angle_horizontal: float = 150.
    angle_vertical: float = 150.
    angle_thickness: float = 12.
    angle_length: float = 200.
    angle_gap: float = 14.
    angle_root_radius: float = 10.
    angle_steel: str = 'AS/NZS 3679.1 Grade 300'
    attachment: str = 'welded'
    weld_mode: str = 'automatic'
    weld_category: str = 'SP'
    weld_electrode: str = 'E48XX / W50X'
    weld_long_lap: bool = False
    weld_line_capacity: float = 0.
    weld_effective_length: float = 140.
    weld_leg: float = 6.
    weld_capacity_source: str = ""
    supported_stiffeners: bool = False
    receiving_stiffeners: bool = False
    bolt_top: float = 0.
    bolt_pitch: float = 0.
    bolt_gauge: float = 0.
    column_top_edge: float = 0.
    column_bottom_edge: float = 0.
    bolt_tool_radius: float = 0.
    bolt_tool_length: float = 0.
    project: str = 'Verificação local de apoio'
    notes: str = ''
    def to_dict(self):
        errors = input_errors(self)
        if errors: raise ValueError('; '.join(errors))
        return {'schema_version':1,'component_version':VERSION,'connection_type':'seated_variants_local','units':{'force':'N','length':'mm','stress':'MPa'},'connection':asdict(self)}
    @classmethod
    def from_dict(cls,data):
        if not isinstance(data,dict) or set(data)!={'schema_version','component_version','connection_type','units','connection'}: raise ValueError('Estrutura de projeto incompatível.')
        raw=data['connection']
        legacy=isinstance(data.get('component_version'),str) and data['component_version'] in LEGACY_VERSIONS
        if legacy and isinstance(raw,dict) and not (set(raw)&set(BOLTED_FIELDS)):
            raw=dict(raw, **{key:0. for key in BOLTED_FIELDS})
        if not isinstance(raw,dict) or set(raw)!={f.name for f in fields(cls)}: raise ValueError('Campos ausentes ou desconhecidos.')
        raw=dict(raw)
        for role in ('beam','support'):
            if not isinstance(raw[role],dict) or set(raw[role])!={f.name for f in fields(Profile)}: raise ValueError('Perfil incompleto.')
            raw[role]=Profile(**raw[role])
        c=cls(**raw)
        canonical=c.to_dict()
        if isinstance(data.get('component_version'),str) and data.get('component_version') in LEGACY_VERSIONS:
            canonical['component_version']=data['component_version']
            if not (set(data['connection'])&set(BOLTED_FIELDS)):
                for key in BOLTED_FIELDS:canonical['connection'].pop(key)
        if not _same_json(canonical,data): raise ValueError('Versão, unidades ou tipos incompatíveis.')
        return c

def positive_geometry_fields(c):
    """Strictly positive dimensions used by the selected topology.

    Hidden numeric fields remain finite, nonnegative and bounded for safe JSON
    round trips. Zero is allowed only while that dimension is inactive.
    """
    if c.variant == 'angle_seat':
        keys = {'angle_horizontal', 'angle_vertical', 'angle_thickness',
                'angle_length', 'angle_gap', 'angle_root_radius'}
        if c.attachment == 'welded':
            keys.update(('weld_effective_length', 'weld_leg'))
        return keys
    return {'bearing_length', 'bearing_width'}


def input_errors(c):
    errors=[]
    if not isinstance(c,SeatedVariant): return ['Entrada deve ser SeatedVariant.']
    if not isinstance(c.variant,str) or c.variant not in LABELS: errors.append('Tipo de apoio desconhecido.')
    if not isinstance(c.attachment,str) or c.attachment not in ('bolted','welded'): errors.append('Fixação desconhecida.')
    for key in ('supported_stiffeners','receiving_stiffeners','weld_long_lap'):
        if type(getattr(c,key)) is not bool: errors.append(key+': booleano obrigatório.')
    for f in fields(c):
        v=getattr(c,f.name)
        if f.name in ('beam','support'):
            if not isinstance(v,Profile): errors.append('Perfil obrigatório.'); continue
            if any(not isinstance(getattr(v,k),str) or not getattr(v,k).strip() for k in ('name','family','source')): errors.append('Perfil: textos de identificação e fonte obrigatórios.')
            if v.family!='W': errors.append('Somente perfil W laminado simétrico nesta revisão.')
            if any(not finite_real(getattr(v,k)) or getattr(v,k)<0.001 or getattr(v,k)>1e12 for k in ('d','bf','tw','tf','clear','area','mass')): errors.append('Dimensões de perfil inválidas.')
            elif v.d<=2*v.tf or v.bf<=v.tw or v.clear>v.d-2*v.tf: errors.append('Seção inconsistente.')
        elif f.name.endswith('_steel'):
            if not isinstance(v,str) or v not in (ANGLE_STEELS if f.name=='angle_steel' else STEELS): errors.append('Aço não cadastrado para este produto/modelo.')
        elif f.name in ('variant','attachment','project','notes','weld_capacity_source','weld_mode','weld_category','weld_electrode'):
            if not isinstance(v,str): errors.append('Texto obrigatório.')
        elif f.name not in ('supported_stiffeners','receiving_stiffeners','weld_long_lap'):
            if not finite_real(v) or v<0 or v>1e12 or (f.name in positive_geometry_fields(c) and v==0): errors.append(f.name+': valor finito e válido obrigatório.')
    for key,options in [('weld_mode',('automatic','manual')),('weld_category',WELD_CATEGORIES),('weld_electrode',WELD_ELECTRODES)]:
        if not isinstance(getattr(c,key),str) or getattr(c,key) not in options: errors.append(key+': opção não suportada.')
    if not errors:
        for role in ('beam','support'):
            p=getattr(c,role); steel=STEELS[getattr(c,role+'_steel')]
            if not steel.rolled_allowed or min(p.tw,p.tf)<steel.profile_min or max(p.tw,p.tf)>steel.profile_max: errors.append('Material/espessura fora do domínio do perfil laminado: '+role)
    return errors

def reduction(p,fy):
    d=p.d-2*p.tf
    ln=2.5*d/p.tw*math.sqrt(fy/250)
    aa=2100*(ln-13.5)/(ln*ln-15.3*ln+2050)
    lam=ln+.5*aa; eta=max(0,.00326*(lam-13.5)); x=(lam/90)**2
    xi=(x+1+eta)/(2*x)
    ac=xi*(1-math.sqrt(max(0,1-(90/(xi*lam))**2)))
    return ac,min(1,(82/((d/p.tw)*math.sqrt(fy/250)))**2)

def _evaluate(c):
    out={'status':'INVALID_INPUT','checks':[],'parameters':{},'missing_verifications':[], 'global_pass':False,'stiffener_strength_credit':False,'vertical_locating_bolt_shear_N':None,'reference':'ASI DG6 2007 / AS 4100; sem fatores NBR', 'publication':'Revisão privada. Obter permissão ASI antes de uso comercial/publicação.'}
    errors=input_errors(c)
    if errors: out['errors']=errors; return out
    rows=out['checks']; gaps=out['missing_verifications']; p=c.beam; fy=STEELS[c.beam_steel].fy
    ac,av=reduction(p,fy); va=.54*fy*p.d*p.tw; vb=av*va
    internal=c.variant=='column_continuous'; force=c.V; bs=c.bearing_length; tp=c.packer_thickness
    def geom(key,name,value,limit,relation='>='):
        passed=value>=limit if relation=='>=' else value<=limit
        rows.append(_row(key,name,category='GEOMETRY',status='PASS' if passed else 'FAIL',value=value,limit=limit,unit='mm',equation=relation))
    if c.variant=='angle_seat':
        # Reject extrapolation rather than implementing the contradictory p28 clamp.
        tp=0.; fa=ANGLE_STEELS[c.angle_steel]
        # HB1 Table 29 p78: >17 mm uses 280 MPa. Preserve existing conservative
        # 300 MPa below 11 mm in welded B1; its other results remain unchanged.
        if c.angle_thickness>17:fa=280.
        if c.attachment=='bolted':
            from .bolted_seat import angle_yield
            fa=angle_yield(c.angle_thickness)
            out['parameters']['bolted_angle_fy_MPa']=fa
        if c.angle_thickness>17 or c.attachment=='bolted':out['parameters']['angle_fy_MPa']=fa
        k1=.9*1.25*fy*p.tw; k2=.9*fa*c.angle_length*c.angle_thickness**2/4
        k3=c.angle_thickness+c.angle_root_radius-c.angle_gap; k4=2.5*p.tf
        k5=k1*(k4+2*k3); k6=2*k1*k2
        coupled=(k5+math.sqrt(k5*k5+4*k6))/2
        bs=coupled/k1-k4; ev=c.angle_gap+bs/2-c.angle_thickness-c.angle_root_radius
        out['parameters'].update(k1_N_per_mm=k1,k2_Nmm=k2,k3_mm=k3,k4_mm=k4,k5_N=k5,k6_N2=k6,coupled_capacity_N=coupled,ev_mm=ev)
        for args in [('angle_width','Comprimento transversal da cantoneira',c.angle_length,max(150,.9*p.bf)),('angle_vertical','Aba vertical',c.angle_vertical,150),('angle_horizontal','Aba horizontal',c.angle_horizontal,90),('angle_t_min','Espessura mínima',c.angle_thickness,9.5),('angle_t_max','Espessura máxima',c.angle_thickness,25,'<='),('angle_contact','Contato cabe na aba',c.angle_gap+bs,c.angle_horizontal,'<='),('angle_eccentricity','Excentricidade positiva',ev,1e-9),('angle_gap','Folga de cálculo (inclui tolerância)',c.angle_gap,14)]:geom(*args)
        force=max(c.V,min(40000,.15*vb))
        out['parameters']['minimum_design_reaction_N']=min(40000,.15*vb)
        out['parameters']['design_reaction_N']=force
        if ev>0:
            rows.append(_row('angle_bending','Flexão da aba horizontal',force,k2/ev,reference='DG6 B8, verificação 3',equation='0,9 fy La ta² / (4 ev)'))
        geom('seat_fits_flange','Cantoneira cabe na mesa receptora',c.angle_length+(2*c.weld_leg if c.attachment=='welded' else 0.),c.support.bf,'<=')
        ew=c.angle_gap+bs/2
        out['parameters']['column_eccentricity_mm']=max(100.,ew)
        out['parameters']['column_design_moment_Nmm']=force*(max(100.,ew)+c.support.d/2)
        # HB1 2007 pp58-60: equal-leg right-angle fillet, no added penetration.
        qrd=None
        if c.attachment=='welded' and not c.weld_long_lap:
            if c.weld_mode=='automatic':
                throat=c.weld_leg/math.sqrt(2.)
                phi=WELD_CATEGORIES[c.weld_category]
                fuw=WELD_ELECTRODES[c.weld_electrode]
                qrd=phi*.6*fuw*throat # kr=1 only in the bounded non-long-lap seat.
                out['parameters'].update(weld_throat_mm=throat,weld_phi=phi,weld_fuw_MPa=fuw,weld_kr=1.,weld_qRd_N_per_mm=qrd)
                rows.append(_row('weld_leg_domain','Filete de 6 ou 8 mm: domínio desta revisão',category='GEOMETRY',status='PASS' if c.weld_leg in (6.,8.) else 'FAIL',value=c.weld_leg,limit=None,unit='mm',equation='6 ou 8'))
                weld_note='qRd = φ × 0,6 fuw × (perna/√2) × kr; kr=1 no assento não longo; sem penetração adicional nem aumento direcional.'
            elif c.weld_line_capacity>0 and c.weld_capacity_source.strip():
                qrd=c.weld_line_capacity
                out['parameters']['weld_qRd_N_per_mm']=qrd
                weld_note='qRd excepcional informado pelo projetista: '+c.weld_capacity_source
            if qrd is not None:
                geom('weld_size','Margem geométrica conservadora do filete',c.weld_leg,min(c.angle_thickness,c.support.tf)-1.,'<=')
                geom('weld_length','Comprimento efetivo da solda dentro da aba vertical',c.weld_effective_length,c.angle_vertical,'<=')
                weld=2*c.weld_effective_length*qrd/math.sqrt(1+(6*ew/c.weld_effective_length)**2)
                rows.append(_row('angle_weld','Duas soldas verticais: grupo excêntrico',force,weld,reference='DG6 B8 p.32; Handbook 1 (2007), pp.58–60',equation='2 Lv qRd / sqrt(1 + (6 ew / Lv)²)',notes=weld_note))
                gaps.append('Execução: filetes contínuos, iguais, a 90°, sem crédito de penetração; comprimento efetivo de tamanho pleno. Qualificar procedimento, compatibilidade consumível/metal-base e categoria conforme AS 1554.1, citada no Handbook 1 p.54. A resistência calculada é do metal de solda; não certifica material ou execução.')
            else:
                gaps.append('Modo manual: informar qRd em N/mm e sua fonte coerente com AS 4100 histórico. O modo automático usa Handbook 1 (2007), pp.58–60.')
        elif c.attachment=='welded' and c.weld_long_lap:
            gaps.append('Emenda longa por sobreposição fora do escopo: Handbook 1 p.58 exclui long lap splices de kr=1 e não fornece aqui lei para kr. Não se calcula qRd nem crédito do grupo nesse caso.')
        else:
            from .bolted_seat import add_checks
            add_checks(c,out,force,geom)
        gaps += ['Montagem limitada à MESA de coluna W: verificação de cisalhamento local da alma do pilar dispensada nesse detalhe pelo DG6 B12.1, p.41. Assento na ALMA do pilar não implementado (B8, p.33).','Entregar ao cálculo da coluna o momento excêntrico Mc = V × (max(100 mm, c + bs/2) + dc/2), DG6 B10, p.38; não integra a resistência local do assento.','Cantoneira de contenção, parafusos de localização e compatibilidade de rotação/montagem: detalhes DG6 B1–B3, pp.20–22, não dimensionados.']
    elif c.variant=='concrete_end':
        geom('bearing_width','Largura de contato cobrindo a mesa',c.bearing_width,p.bf)
        gaps += ['DG6 A3, pp.7–8, cobre somente a viga de aço; não fornece resistência do concreto, fendilhamento, armaduras, ancoragens ou bordas. Requer norma de concreto e geometria real do apoio.','Chumbadores, contenção lateral, eventual placa/argamassa e rotação não dimensionados.']
    else:
        geom('bearing_width','Largura de contato cobrindo a mesa',c.bearing_width,p.bf)
        geom('steel_bearing_width','Contato transversal dentro da mesa da coluna',c.bearing_width,c.support.bf,'<=')
        geom('steel_bearing','Comprimento rígido não excede envelope da coluna',bs,c.support.d,'<=')
        gaps += ['DG6 A1(e), p.2, e A4, p.6: comprimento rígido bs depende de orientação, contato e chapa de topo. Esta tela não dimensiona chapa, soldas ou coluna; fornecer essas dimensões e método de verificação próprio.','Continuidade: informar cortantes de cada lado obtidos do modelo global; reação não substitui os cortantes de painel.']
    if c.supported_stiffeners: gaps.append('A2: enrijecedores da VIGA APOIADA registrados, sem crédito resistente; verificar integralmente A5, área efetiva, flambagem, ajuste e soldas antes de aumentar capacidade.')
    if c.receiving_stiffeners: gaps.append('A1(c): enrijecedores da VIGA RECEPTORA são outro detalhe; não pertencem às três variantes desta tela. Usar a família viga sobre viga, que preserva o par sem crédito resistente.')
    bbf=bs+(5 if internal else 2.5)*(p.tf+tp); bb=bbf+(1 if internal else .5)*(p.d-2*p.tf)
    if bs<=0 or bb<=0 or bbf<=0: out['status']='OUTSIDE_SCOPE'; return out
    out['parameters'].update(bearing_position='internal' if internal else 'end',bs_mm=bs,bbf_mm=bbf,bb_mm=bb,alpha_c=ac,alpha_v=av,Va_N=va,Vb_N=vb,Vc_N=.9*1.25*bbf*p.tw*fy,Vd_N=.9*ac*bb*p.tw*fy)
    for key,name,res,eq in [('bearing_yield','Escoamento local da alma',.9*1.25*bbf*p.tw*fy,'0,9 × 1,25 bbf tw fy'),('bearing_buckling','Flambagem local da alma',.9*ac*bb*p.tw*fy,'0,9 αc bb tw fy')]:
        rows.append(_row(key,name,force,res,reference='DG6 A3 / B8; AS 4100',equation=eq))
    panels=[('left','Cortante à esquerda',c.shear_left),('right','Cortante à direita',c.shear_right)] if internal else [('end','Cortante no extremo',force)]
    for key,name,demand in panels:
        rows.append(_row(key+'_shear_yield',name+' · escoamento',demand,va,reference='DG6 A3 / AS 4100',equation='0,54 fy d tw'))
        rows.append(_row(key+'_shear_buckling',name+' · flambagem',demand,vb,reference='DG6 A3 / AS 4100',equation='αv × 0,54 fy d tw'))
    gaps.append('Estabilidade global, torção, esforço axial, momentos e ações horizontais pertencem ao projeto externo; não impedem a leitura das verificações locais.')
    out['status']='LOCAL_GEOMETRY_FAILURE' if any(r['status']=='FAIL' and r['category']=='GEOMETRY' for r in rows) else 'LOCAL_RESISTANCE_FAILURE' if any(r['status']=='FAIL' for r in rows) else 'LOCAL_CHECKS_PASS'
    if c.variant=='angle_seat' and c.attachment=='welded' and c.weld_long_lap:
        out['status']='OUTSIDE_SCOPE'
        out['diagnosis']='Emenda longa fora do domínio: kr=1 não é aplicado e o grupo soldado não recebe capacidade.'
        return out
    if c.variant=='angle_seat' and c.attachment=='welded' and out['status']=='LOCAL_CHECKS_PASS' and qrd is None:
        out['status']='LOCAL_ATTACHMENT_PENDING'
        out['diagnosis']='Viga e cantoneira verificadas; falta informar resistência linear de cálculo da solda e sua fonte para concluir o grupo soldado local.'
        return out
    if c.variant=='angle_seat' and c.attachment=='bolted' and not out.get('bolted_model_complete'):
        if out['status']=='LOCAL_CHECKS_PASS':out['status']='BOLTED_MODEL_INCOMPLETE'
    if out['status']=='BOLTED_MODEL_INCOMPLETE':
        out['diagnosis']='B9: faltam dimensões da fixação parafusada; informar geometria, bordas da coluna e envelope de montagem.'
        return out
    out['diagnosis']='Verificações calculadas atendem; ligação completa NÃO verificada.' if out['status']=='LOCAL_CHECKS_PASS' else 'Há verificação local não atendida; consultar tabela e limites do modelo.'
    return out

def evaluate(c):
    try:
        return _qualify_scope(c, _evaluate(c))
    except (ArithmeticError,ValueError) as exc:
        return {'status':'INVALID_INPUT','checks':[], 'parameters':{},
                'missing_verifications':[], 'global_pass':False,
                'stiffener_strength_credit':False, 'vertical_locating_bolt_shear_N':None,
                'errors':['Modelo numericamente fora do domínio: '+str(exc)]}

def _qualify_scope(c, out):
    """Separate calculated metal path, execution specifications and external interfaces."""
    out.update(metal_scope_complete=False,metal_scope_pass=False,interfaces=[],execution_requirements=[])
    if out.get('errors') or not isinstance(c,SeatedVariant): return out
    req=out['execution_requirements']; interfaces=out['interfaces']; pending=[]
    req.append('Ações centradas exclusivamente verticais; viga horizontal sem esconsidade. A montagem deve fornecer contenção/posicionamento e liberdade de rotação compatíveis. Nenhuma resistência horizontal, axial, à torção ou ao arrancamento é declarada.')
    req.append('Superfícies e dimensões de contato especificadas devem ser executadas; comprimentos efetivos já descontam tolerâncias. A verificação dimensiona o projeto, não atesta uma peça executada.')
    interfaces.append({'title':'Modelo global','description':'Reações, cortantes de painel e estabilidade dos membros são dados/responsabilidades do modelo estrutural; não impedem nem substituem estes cálculos locais.'})
    if c.variant=='concrete_end':
        width=c.beam.bf
        area=c.bearing_length*width
        out['civil_interface']={'reaction_N':c.V,'contact_length_mm':c.bearing_length,'contact_width_mm':width,'contact_area_mm2':area,'mean_pressure_MPa':c.V/area,'anchors_present':False,'capacity_calculated':False}
        interfaces.append({'title':'Interface ao projeto civil','description':'Reação vertical, dimensão efetiva de contato e pressão média informativa. Não se dimensionam concreto, bloco, fundação ou armaduras. Não há chumbadores neste detalhe metálico selecionado.','values':out['civil_interface']})
        out['scope_summary']='Apoio direto por gravidade da viga de aço, sem chapa de distribuição e sem ancoragem: alma ao cortante e ao apoio conforme DG6 A3. A interface civil não é um estado limite metálico pendente.'
        if c.packer_thickness!=0:
            pending.append('Chapa/calço metálico diferente de zero não pertence ao apoio direto desta revisão; sua flexão e seu contato precisam de modelo próprio. O valor importado foi preservado, não zerado silenciosamente.')
            out['status']='OUTSIDE_SCOPE'
        else:out['metal_scope_complete']=True
    elif c.variant=='angle_seat':
        out['scope_summary']='Caminho vertical do assento soldado à mesa de coluna W: alma da viga, aba da cantoneira, geometria e duas soldas verticais excêntricas, DG6 B8 e Handbook 1 (2007).'
        interfaces.append({'title':'Ações entregues à coluna','description':'Reação do assento e momento excêntrico DG6 B10, p.38. Dimensionamento do membro coluna pertence ao modelo estrutural.','values':{'reaction_N':out.get('parameters',{}).get('design_reaction_N',c.V),'moment_Nmm':out.get('parameters',{}).get('column_design_moment_Nmm')}})
        req += ['Cantoneira laminada Grade 300, sem esconsidade ou inclinação; folga de cálculo inclui tolerância. Parafusos localizadores e contenção não recebem V/n, conforme DG6 B1, p.20.','Consumível, categoria e procedimento compatíveis com o metal-base conforme Handbook 1, p.54 / AS 1554.1. A resistência da solda não é certificado da execução.','DG6 B12.1, p.41, dispensa check 7 neste apoio na MESA da coluna: check 7 é cisalhamento da ALMA, não outro mecanismo obrigatório omitido.']
        if c.attachment=='bolted':
            out['scope_summary']='Caminho vertical B9: alma apoiada, aba da cantoneira, limite Vf, quatro M20 8.8N/S em corte simples e contato/rasgamento nas duas peças, fixados à MESA de coluna W contínua.'
            req=[x for x in req if 'Consumível' not in x]
            out['execution_requirements']=req
            req += out.get('bolted_execution_requirements',[])
            if out.get('bolted_model_complete'):out['metal_scope_complete']=True
            else:pending += out.get('bolted_missing',['Geometria da fixação B9 ainda não informada.'])
        elif c.attachment=='welded' and c.weld_long_lap:pending.append('Emenda longa exige kr próprio não estabelecido pelo modelo do assento; nenhum crédito da solda é atribuído.')
        elif c.weld_mode=='manual' and (c.weld_line_capacity<=0 or not c.weld_capacity_source.strip()):pending.append('No modo manual excepcional, informar resistência linear e fonte. O modo automático já dimensiona a solda.')
        else:out['metal_scope_complete']=True
    else:
        out['scope_summary']='Viga contínua sobre topo de coluna: as verificações da viga estão calculadas; o caminho local da chapa de topo e da introdução da reação no apoio ainda requer fechamento.'
        pending += ['Chapa de topo A1(e): definir apoios reais, faixa/equilíbrio de carga, flexão, cisalhamento e interação; bs editável não prova apoio rígido.','Introdução no topo da coluna e ligação chapa/coluna: justificar contato e ação do componente. Não é uma pendência de estabilidade global nem de concreto.']
        if out['status']=='LOCAL_CHECKS_PASS':out['status']='LOCAL_LOAD_PATH_PENDING'
    if c.supported_stiffeners:req.append('A2: enrijecedores da viga APOIADA apenas indicados; nenhuma parcela de resistência é somada. As verificações permanecem da alma original.')
    if c.receiving_stiffeners:req.append('A1(c): par da viga RECEPTORA pertence à família viga sobre viga, não à coluna; registro preservado sem converter ou atribuir crédito.')
    out['missing_verifications']=pending
    out['metal_scope_pass']=out['metal_scope_complete'] and out['status']=='LOCAL_CHECKS_PASS'
    if out['metal_scope_pass']:out['diagnosis']='ATENDE no caminho metálico por gravidade especificado. Interfaces externas e condições de execução estão declaradas separadamente.'
    elif pending and (c.variant!='angle_seat' or c.attachment!='bolted' or out['status'] not in ('LOCAL_RESISTANCE_FAILURE','LOCAL_GEOMETRY_FAILURE')):out['diagnosis']='Caminho metálico não concluído: '+pending[0]
    else:out['diagnosis']='NÃO ATENDE em uma ou mais verificações do caminho metálico especificado.'
    return out

def presets():
    p=profiles();return {k:SeatedVariant(k,p['W 360 x 39,0'],p['W 250 x 73,0 (H)']) for k in LABELS}
