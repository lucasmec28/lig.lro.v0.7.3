"""1L welded to a column flange, bolted to one supported beam web.

Independent conventional downward-shear route. This is not R015 inverted,
not half R016, and not the girder-web receiver. N/mm/MPa; no load factors.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict, fields, replace
import math
from .models import Profile, profiles, STEELS, BOLTS, finite_real
from .angle_catalog_selection import identity_errors, missing_data_errors
from .double_angle import (HOLES, EDGES, bolt_shear_resistance, bearing_resistance,
                           block_resistance, GAMMA_A1, GAMMA_A2)
from .welded_double_angle import elastic_line_group

FAMILY = 'Cantoneira simples · soldada ao pilar · cortante'
CONNECTION_TYPE = 'welded_support_single_angle_shear'
COMPONENT_VERSION = '0.9.43-1l-column-dev'
NBR = 'ABNT NBR 8800:2024, Errata 1:2025'
SCOPE = ('Uma cantoneira laminada, solda L na mesa contínua de pilar W, retorno superior curto, '
         'uma coluna de parafusos na alma de viga W sem recorte. V descendente estático; N=M=T=0. '
         'Modelo convencional flexível AISC, solda e aba de apoio elásticas, resistências NBR.')
EXCLUSIONS = [
    'V nulo/ascendente, reversão, fadiga e impacto não qualificados nesta primeira rota.',
    'N, M ou T externos, apoio na alma, segunda cantoneira, calços, atrito e recortes não cobertos.',
    'Solda no talão ou em toda a borda superior remove o detalhe flexível adotado.',
    'Resistência e estabilidade globais da viga, pilar e pórtico continuam fora do cálculo local.',
]

# Standard heavy-hex hardware only; these are physical plausibility floors,
# not a selected wrench/socket size. Metric and inch diameters stay distinct.
_METRIC_HARDWARE = {16.:(31.18,34.),20.:(39.26,42.),22.:(41.57,44.),
                    24.:(47.34,50.),27.:(53.12,56.),30.:(57.74,60.)}
_INCH_HARDWARE = {12.7:(1.010,1.063),15.875:(1.227,1.313),19.05:(1.443,1.469),
                  22.225:(1.660,1.750),25.4:(1.876,2.),28.575:(2.093,2.25),31.75:(2.309,2.5)}
_METRIC_HARDWARE_SOURCE = 'BAPP A325M structural bolt assembly, pp.2–3; heavy-hex head/A563M nut and F436M washer'
_INCH_HARDWARE_SOURCE = 'Portland Bolt structural bolts/heavy-hex nuts; Anchor Bolt Express F436 washer OD +0.0313in'


def hardware_envelope(db):
    """Bound the standard head/nut/washer, without inventing a tool allowance."""
    if db in _METRIC_HARDWARE:
        corners,washer=_METRIC_HARDWARE[db]
        source=_METRIC_HARDWARE_SOURCE
    else:
        corners,nominal=_INCH_HARDWARE[db]
        corners*=25.4
        washer=(nominal+.0313)*25.4
        source=_INCH_HARDWARE_SOURCE
    return dict(head_nut_max_corners_mm=corners,washer_max_outside_mm=washer,
                minimum_hardware_radius_mm=max(corners,washer)/2,source=source)


@dataclass(frozen=True)
class WeldedSupportSingleAngle:
    beam: Profile
    support: Profile
    project: str = '1L soldada ao apoio · V descendente'
    kind: str = 'column_flange'
    side: str = 'positive_z'
    beam_leg: float = 101.6
    support_leg: float = 101.6
    t: float = 9.52
    root_radius: float = 10.
    length: float = 240.
    angle_top: float = 80.
    beam_gauge: float = 65.
    web_rows: int = 4
    web_columns: int = 1
    web_pitch: float = 60.
    web_end_top: float = 30.
    gap: float = 10.
    weld_leg: float = 5.
    top_return: float = 10.
    weld_layout: str = 'toe_bottom_short_top'
    weld_process: str = 'SMAW_E7018'
    electrode_fuw: float = 485.
    reinforced_weld_edge: bool = False
    beam_steel: str = 'ASTM A572 Gr.50'
    support_steel: str = 'ASTM A572 Gr.50'
    angle_steel: str = 'ASTM A572 Gr.50'
    bolt: str = 'ASTM F3125 A325'
    db: float = 20.
    hole_diameter: float = 22.
    hole_type: str = 'standard_round'
    drilled: bool = False
    web_threads_excluded: bool = False
    V: float = 90000.
    N: float = 0.
    M: float = 0.
    torsion: float = 0.
    cope: str = 'none'
    static: bool = True
    normal_combination: bool = True
    no_slip_required: bool = False
    support_continuous: bool = True
    tool_radius: float = 22.
    fabrication_clearance: float = 3.
    exposure: str = 'painted'
    notes: str = ''
    angle_catalog_id: str = ''
    angle_root_source: str = ''
    angle_root_confirmed: bool = False

    @property
    def fixed_assumptions(self):
        return dict(physical_angles=1, physical_beam_webs=1, web_shear_planes=1,
            support_bolts=0, beam_welds=0, assembly='shop_weld_angle_then_field_bolt_beam',
            effective_weld='vertical_toe_plus_full_bottom; short_top_return_not_credited',
            weld_model='elastic_planar_uniform_throat_no_directional_enhancement',
            load_model='conventional_downward_flexible_single_angle',
            beam_bolt_eccentricity='omitted_only_one_column_e_from_support_face_le_76.2mm',
            support_receiver='continuous_rolled_W_column_flange_local_in_plane',
            contact='direct_contact_no_shims; positive_beam_end_gap',
            hardware='standard_heavy_hex_head_and_nut_with_F436_round_washer; declared_envelope_includes_actual_tool; alternate_S_heads_excluded',
            gamma_a1=GAMMA_A1, gamma_a2=GAMMA_A2)

    def to_dict(self):
        errors=input_errors(self)
        if errors: raise ValueError('; '.join(errors))
        return dict(schema_version=1, connection_type=CONNECTION_TYPE,
            component_version=COMPONENT_VERSION, connection=asdict(self),
            units=dict(force='N', length='mm', stress='MPa', moment='N mm'),
            fixed_assumptions=self.fixed_assumptions)

    @classmethod
    def from_dict(cls, data):
        if not isinstance(data,dict) or set(data)!={'schema_version','connection_type','component_version','connection','units','fixed_assumptions'}:
            raise ValueError('Projeto 1L: campos ausentes ou desconhecidos.')
        if type(data['schema_version']) is not int or data['schema_version']!=1 or data['connection_type']!=CONNECTION_TYPE or data['component_version']!=COMPONENT_VERSION:
            raise ValueError('Família/versão de projeto 1L incompatível.')
        raw=data['connection']
        if not isinstance(raw,dict) or set(raw)!={f.name for f in fields(cls)}:
            raise ValueError('Entrada 1L incompleta ou com campos desconhecidos.')
        raw=dict(raw)
        for key in ('beam','support'):
            if not isinstance(raw[key],dict) or set(raw[key])!={f.name for f in fields(Profile)}:
                raise ValueError('Perfil '+key+' incompleto.')
            raw[key]=Profile(**raw[key])
        c=cls(**raw); canonical=c.to_dict()
        if any(data[k]!=canonical[k] for k in ('units','fixed_assumptions')):
            raise ValueError('Unidades/premissas de projeto incompatíveis.')
        return c


def presets():
    p=profiles(); c=WeldedSupportSingleAngle(p['W 410 x 38,8'],p['W 310 x 97,0 (H)'])
    return {'1L · exemplo local · V=90 kN':c,
            '1L · solicitação elevada':replace(c,project='1L · adverso',V=250000.),
            '1L · V ascendente não coberto':replace(c,project='1L · limite de sinal',V=-90000.)}


def input_errors(c):
    if not isinstance(c,WeldedSupportSingleAngle): return ['Entrada deve ser WeldedSupportSingleAngle.']
    errors=[]
    strings={'project','kind','side','weld_layout','weld_process','beam_steel','support_steel','angle_steel','bolt','hole_type','cope','exposure','notes','angle_catalog_id','angle_root_source'}
    booleans={'drilled','web_threads_excluded','static','normal_combination','no_slip_required','support_continuous','angle_root_confirmed','reinforced_weld_edge'}
    signed={'V','N','M','torsion'}
    nonnegative={'root_radius','angle_top','gap','top_return','fabrication_clearance'}
    for f in fields(c):
        k=f.name; v=getattr(c,k)
        if k in ('beam','support'):
            if not isinstance(v,Profile): errors.append(k+': perfil obrigatório.'); continue
            for n in ('d','bf','tw','tf','clear','area','mass'):
                if not finite_real(getattr(v,n)) or getattr(v,n)<=0: errors.append(k+'.'+n+': positivo finito obrigatório.')
            for n in ('name','family','source'):
                if not isinstance(getattr(v,n),str): errors.append(k+'.'+n+': texto obrigatório.')
        elif k in strings:
            if not isinstance(v,str): errors.append(k+': texto obrigatório.')
        elif k in booleans:
            if type(v) is not bool: errors.append(k+': booleano obrigatório.')
        elif k in ('web_rows','web_columns'):
            if type(v) is not int or not 1<=v<=20: errors.append(k+': inteiro entre 1 e 20 obrigatório.')
        elif not finite_real(v): errors.append(k+': número finito obrigatório.')
        elif k not in signed and (v<0 if k in nonnegative else v<=0): errors.append(k+': dimensão inválida.')
    return errors+(identity_errors(c) if not errors else [])


def support_weld_segments(c):
    s=1. if c.side=='positive_z' else -1.
    toe=s*(c.beam.tw/2+c.support_leg);heel=s*c.beam.tw/2
    # Coordinates are (global z, local y upward from angle bottom).
    return [((toe,0.),(toe,c.length)),((toe,0.),(heel,0.))]


def support_leg_envelope(c, group):
    """Exact section resultants; conservative rectangular-section stress bound.

    u from toe to heel. The short top return is not credited. Independent
    integration verifies N(heel)=0, V(heel)=F, B(heel)=F*tw/2.
    Mirrored side uses the identical local positive-u field.
    """
    H,b,t=c.length,c.support_leg,c.t
    F=group['force_y_N']; xc=b*b/(2*(H+b));yc=H*H/(2*(H+b))
    J=group['J_line_mm3']; M=F*(b+c.beam.tw/2-xc); K=M/J; A=F/group['total_length_mm']-K*xc
    def N(u): return -K*H*(H/2-yc)+K*yc*u
    def V(u): return A*(H+u)+K*u*u/2
    def B(u): return K*H**3/12-u*H*A-A*u*u/2-K*u**3/6+K*H*yc*u/2
    nv=[0.,b]; vv=nv.copy(); bv=nv.copy()
    if K:
        root=-A/K
        if 0<root<b: vv.append(root)
        aa=-K/2;bb=-A;cc=-H*A+K*H*yc/2;disc=bb*bb-4*aa*cc
        if disc>=0:
            for u in ((-bb+math.sqrt(disc))/(2*aa),(-bb-math.sqrt(disc))/(2*aa)):
                if 0<u<b:bv.append(u)
    elif A:
        root=-H
        if 0<root<b:bv.append(root)
    maxima={name:max(((u,fn(u)) for u in points),key=lambda q:abs(q[1]))
            for name,fn,points in [('N',N,nv),('V',V,vv),('B',B,bv)]}
    sigma=abs(maxima['N'][1])/(t*H)+6*abs(maxima['B'][1])/(t*H*H)
    tau=1.5*abs(maxima['V'][1])/(t*H)
    return dict(maxima={k:dict(u_mm=v[0],resultant=v[1]) for k,v in maxima.items()},
        normal_stress_bound_MPa=sigma,shear_stress_bound_MPa=tau,
        equivalent_stress_bound_MPa=math.hypot(sigma,math.sqrt(3)*tau),
        heel=dict(N_N=N(b),V_N=V(b),B_Nmm=B(b)),
        equation='N=-KH(H/2-yc)+Kyc u; V=A(H+u)+Ku²/2; B=KH³/12-uHA-Au²/2-Ku³/6+KHyc u/2',
        stress_model='Conservative combination of separate section-resultant maxima; not exact pointwise plate elasticity.')


def _evaluate(c):
    out=dict(status='INVALID_INPUT',global_pass=False,scope=SCOPE,exclusions=EXCLUSIONS.copy(),
        issues=[],checks=[],geometry={},load_model={},summary={},welds={},bolts={},components={},
        inputs=_safe(asdict(c)) if isinstance(c,WeldedSupportSingleAngle) else repr(c))
    def issue(severity,text,reference=''):
        out['issues'].append(dict(severity=severity,text=text,reference=reference))
    errors=input_errors(c)
    if not errors: errors=missing_data_errors(c)
    if errors:
        for e in errors: issue('invalid_input',e)
        return out
    if c.root_radius == 0:
        issue('engineering_pending',
              'Raio interno zero preservado para correção: informar o raio real positivo da cantoneira laminada antes de aprovar folgas da raiz, furo e ferramenta.',
              'Geometria física da cantoneira laminada; raio não inferido do catálogo')
    for bad,msg in [
        (c.kind!='column_flange','Receptor deve ser mesa de pilar W.'),
        (c.beam.family!='W' or c.support.family!='W','Viga e pilar W laminados exigidos.'),
        (c.side not in ('negative_z','positive_z'),'Lado físico não reconhecido.'),
        (c.V<=0,'Somente V estritamente descendente. Zero e V ascendente preservados e não aprovados.'),
        (any(v!=0 for v in (c.N,c.M,c.torsion)),'N, M e T externos devem ser nulos; não são apagados.'),
        (c.web_columns!=1 or not 2<=c.web_rows<=4,'Primeiro domínio: uma coluna com 2 a 4 parafusos.'),
        (c.beam_gauge>76.2,'e é a distância real da face do apoio ao eixo dos parafusos e deve ser ≤76,2 mm.'),
        (c.beam.tw/2>6.35,'Meia alma acima de 6,35 mm fora do domínio convencional inicial.'),
        (c.cope!='none','Recortes exigem outro modelo.'),
        (not c.support_continuous,'Pilar com extremidade/descontinuidade local requer outro receptor.'),
        (not c.static or not c.normal_combination,'Somente ações estáticas e combinações últimas normais.'),
        (c.no_slip_required,'Deslizamento de serviço não verificado.'),
        (c.hole_type!='standard_round' or c.db not in HOLES,'Somente diâmetro cadastrado e furo circular padrão.'),
        (c.weld_layout!='toe_bottom_short_top','Somente borda vertical externa + inferior + retorno superior curto; sem solda no talão.'),
        (c.weld_process!='SMAW_E7018' or c.electrode_fuw!=485.,'Primeira rota: SMAW E7018, fuw=485 MPa.'),
        (c.bolt not in ('ASTM F3125 A325','ASTM F3125 A490'),'Parafuso fora do cadastro operacional.'),
        (c.exposure not in ('painted','weathering'),'Exposição não cadastrada.'),
        (min(c.beam_leg,c.support_leg)<63.5,'Primeiro domínio: abas de pelo menos 63,5 mm (L64).'),
        (not 6.35<=c.t<=9.525,'Primeiro domínio de espessura: 6,35 a 9,525 mm.'),
        (c.support_leg<8*c.t,'Aba curta/espessa fora da faixa convencional inicial b_apoio/t≥8.'),
    ]:
        if bad:issue('unsupported_scope',msg,'Domínio convencional 1L; P901 II.A-29 e ficha 0943')
    allowed={'ASTM A36','ASTM A572 Gr.42','ASTM A572 Gr.50','ASTM A572 Gr.55','ASTM A992'}
    for role,name,th in [('beam',c.beam_steel,[c.beam.tw,c.beam.tf]),('support',c.support_steel,[c.support.tw,c.support.tf]),('angle',c.angle_steel,[c.t])]:
        s=STEELS.get(name)
        if name not in allowed or s is None or not s.rolled_allowed or any(not s.profile_min<=v<=s.profile_max for v in th):
            issue('unsupported_scope',role+': aço/produto/espessura não qualificado.',NBR+' tabela A.2; compatibilidade E7018')
    if any(i['severity']=='unsupported_scope' for i in out['issues']):
        out['status']='OUTSIDE_SUPPORTED_SCOPE';return out
    sa,sb,ss=STEELS[c.angle_steel],STEELS[c.beam_steel],STEELS[c.support_steel]
    dh=c.hole_diameter;dn=HOLES[c.db]+(0. if c.drilled else 2.)
    end=c.length-c.web_end_top-(c.web_rows-1)*c.web_pitch
    beamroot=(c.beam.d-c.beam.clear)/2
    signed=1. if c.side=='positive_z' else -1.
    g=dict(valid=True,physical_angle_count=1,physical_beam_webs=1,bolt_count=c.web_rows,
        shear_planes=1,support_bolt_count=0,beam_weld_count=0,dh=dh,dn=dn,
        physical_hole_diameter_mm=dh,net_deduction_diameter_mm=dn,
        web_end_bottom_mm=end,web_grip_mm=c.beam.tw+c.t,
        web_hole_y_mm=[c.angle_top+c.web_end_top+i*c.web_pitch for i in range(c.web_rows)],
        beam_end_distance_mm=c.beam_gauge-c.gap,angle_toe_edge_mm=c.beam_leg-c.beam_gauge,
        beam_clear_top_mm=c.angle_top-beamroot,
        beam_clear_bottom_mm=c.beam.d-beamroot-c.angle_top-c.length,
        column_flange_toe_clear_mm=c.support.bf/2-c.beam.tw/2-c.support_leg,
        top_return_mm=c.top_return,top_return_credited=False,
        physical_weld_segments_mm=support_weld_segments(c)+[((signed*(c.beam.tw/2+c.support_leg),c.length),(signed*(c.beam.tw/2+c.support_leg-c.top_return),c.length))],
        effective_weld_segments_mm=support_weld_segments(c),
        weld_coordinates='(z_global, y_up_from_angle_bottom); supported_web_midplane_z=0',checks=[])
    out['geometry']=g
    def bound(key,value,limit,relation,category,text,reference='Geometria física 1L'):
        passed=value>=limit if relation=='>=' else value<=limit if relation=='<=' else value>limit
        g['checks'].append(dict(id=key,actual=value,limit=limit,relation=relation,passed=passed,category=category,reference=reference))
        if not passed:
            issue(category,text,reference)
            if category=='invalid_geometry':g['valid']=False
    for name,p in [('beam',c.beam),('support',c.support)]:
        bound(name+'_clear',p.clear,p.d-2*p.tf,'<=','invalid_geometry','Altura livre incompatível com mesas.')
        bound(name+'_width',p.bf,p.tw,'>','invalid_geometry','Mesa deve exceder a espessura da alma.')
    bound('standard_hole_min',dh,c.db,'>','invalid_geometry','Diâmetro do furo deve exceder o do parafuso.')
    bound('standard_hole_max',dh,HOLES[c.db],'<=','unsupported_scope','Furo acima da tabela14.',NBR+' tabela14')
    for key in ('beam_clear_top_mm','beam_clear_bottom_mm'):
        bound(key,g[key],c.fabrication_clearance,'>=','invalid_geometry','Cantoneira/retorno devem caber entre raízes da viga com folga.')
    bound('beam_end_restraint_height',c.length,c.beam.d/2,'>=','unsupported_scope','Primeiro domínio convencional: comprimento da cantoneira ≥metade da altura da viga.','NBR6.1.7; detalhe convencional, não verificação global de estabilidade')
    for key,value in [('top',g['web_hole_y_mm'][0]-beamroot),('bottom',c.beam.d-beamroot-g['web_hole_y_mm'][-1])]:
        bound('web_tool_'+key,value,c.tool_radius+c.fabrication_clearance,'>=','access_pending','Ferramenta junto à raiz da mesa da viga sem acesso: '+key)
    bound('flange_weld_fit',g['column_flange_toe_clear_mm'],c.weld_leg+c.fabrication_clearance,'>=','invalid_geometry','Filete e acesso devem caber na mesa do pilar.')
    bound('positive_gap',c.gap,0.,'>','unsupported_scope','Folga positiva obrigatória para não criar contato da ponta da viga.')
    bound('beam_leg_flat',c.beam_leg-c.t-c.root_radius,0.,'>','invalid_geometry','Aba junto à viga sem trecho reto.')
    bound('support_leg_flat',c.support_leg-c.t-c.root_radius,0.,'>','invalid_geometry','Aba junto ao apoio sem trecho reto.')
    bound('hole_root',c.beam_gauge-c.t-c.root_radius-dh/2,0.,'>','invalid_geometry','Furo invade a concordância da cantoneira.')
    bound('tool_root',c.beam_gauge-c.t-c.root_radius,c.tool_radius+c.fabrication_clearance,'>=','access_pending','Ferramenta/porca não cabem junto à raiz.')
    hardware=hardware_envelope(c.db)
    g['hardware_envelope']=dict(**hardware,declared_hardware_tool_radius_mm=c.tool_radius)
    bound('tool_physical',c.tool_radius,hardware['minimum_hardware_radius_mm'],'>=','access_pending',
          'Envelope informado menor que a cabeça/porca/arruela padrão; informar envelope físico completo da ferragem e ferramenta.',hardware['source'])
    bound('top_return_min',c.top_return,2*c.weld_leg,'>=','detail_fail','Retorno superior mínimo desta rota é 2w.')
    bound('top_return_max',c.top_return,min(4*c.weld_leg,c.support_leg/2),'<=','unsupported_scope','Retorno superior deve ser ≤4w e ≤metade da aba.',NBR+' 6.2.6.2.6(c); AISC detalhe convencional')
    bound('open_top_root',c.support_leg-c.top_return,c.t+c.root_radius,'>','unsupported_scope','Parte superior junto ao talão deve permanecer sem solda.')
    minimum=3. if min(c.t,c.support.tf)<=6.3 else 5. if min(c.t,c.support.tf)<=12.5 else 6. if min(c.t,c.support.tf)<=19 else 8.
    bound('weld_min',c.weld_leg,minimum,'>=','detail_fail','Filete inferior ao mínimo NBR.',NBR+' tabela11')
    bound('weld_max',c.weld_leg,c.t if c.reinforced_weld_edge else c.t-1.5,'<=','detail_fail','Filete excede a borda detalhada.',NBR+' 6.2.6.2.2')
    if c.reinforced_weld_edge:
        issue('warning','Borda especificada como reforçada durante a execução para garantir a garganta integral. Mostrar no desenho/procedimento; não é arredondamento do filete máximo.',NBR+' 6.2.6.2.2(b)')
    for key,L in [('vertical',c.length),('bottom',c.support_leg)]:
        bound('weld_'+key+'_length',L,max(4*c.weld_leg,40.),'>=','detail_fail','Comprimento efetivo insuficiente.',NBR+' 6.2.6.2.3')
        bound('weld_'+key+'_long',L,100*c.weld_leg,'<=','unsupported_scope','Trecho longo exige redução fora desta rota.',NBR+' 6.2.2.2')
    emin=EDGES[c.db]
    for key,e,t in [('top',c.web_end_top,c.t),('bottom',end,c.t),('toe',g['angle_toe_edge_mm'],c.t),('beam_end',g['beam_end_distance_mm'],c.beam.tw)]:
        bound('edge_'+key+'_net',e-dn/2,0.,'>','invalid_geometry','Ligamento líquido não positivo: '+key)
        bound('edge_'+key+'_min',e,emin,'>=','detail_fail','Distância de borda abaixo da tabela16: '+key,NBR+' tabela16')
        bound('edge_'+key+'_max',e,min(12*t,150.),'<=','detail_fail','Distância de borda excede o máximo: '+key,NBR+' 6.3.12')
    bound('pitch_min',c.web_pitch,max(2.7*c.db,dh+c.db),'>=','detail_fail','Passo inferior ao mínimo.',NBR+' 6.3.9')
    pmax=min(14*min(c.t,c.beam.tw),180.) if c.exposure=='weathering' else min(24*min(c.t,c.beam.tw),300.)
    bound('pitch_max',c.web_pitch,pmax,'<=','detail_fail','Passo superior ao máximo.',NBR+' 6.3.10')
    bound('net_shear',c.length-c.web_rows*dn,0.,'>','invalid_geometry','Área líquida ao cisalhamento não positiva.')
    for k in range(1,c.web_rows+1):
        bound('block_net_'+str(k),end+(k-1)*c.web_pitch-(k-.5)*dn,0.,'>','invalid_geometry','Bloco líquido não positivo.')
    # These slenderness bounds are a deliberately restricted initial domain;
    # qualification source and exclusions are recorded in the method contract.
    for role,b in [('beam',c.beam_leg),('support',c.support_leg)]:
        bound(role+'_stockiness',b/c.t,.45*math.sqrt(200000./sa.fy),'<=','unsupported_scope','Aba fora do filtro conservador de compacidade da implementação; não é prova normativa de ductilidade ou do modo de flambagem da placa.','Filtro inicial inspirado na NBR tabela4 AL3; aplicabilidade delimitada na ficha 0943')
    if not g['valid']:out['status']='INVALID_GEOMETRY';return out
    if any(i['severity']=='unsupported_scope' for i in out['issues']):out['status']='OUTSIDE_SUPPORTED_SCOPE';return out
    V=max(c.V,45000.)
    out['load_model']=dict(Vsd_N=c.V,Vd_N=V,assembly_minimum_N=45000.,minimum_applied_once=True,
        physical_angle_count=1,each_angle_force_N=V,web_shear_planes=1,web_bolt_force_N=V/c.web_rows,
        external_actions=dict(V=c.V,N=c.N,M=c.M,torsion=c.torsion),
        bolt_eccentricity_mm=c.beam_gauge,bolt_eccentricity_omitted=True,
        local_weld_model='in_plane_L_elastic; conventional_out_of_plane_flexibility',
        column_reference_transport=dict(F_N=[0.,-c.V,0.],r_mm=[c.support.d/2,0.,0.],
            moment_Nmm=[0.,0.,-c.V*c.support.d/2]),
        transport_note='Carga real à face; transporte face-centro do pilar somente se ausente no modelo global. Mínimo local não substitui reação real.')
    def check(identifier,label,component,capacity,fraction=1.,formula='',reference=NBR,**details):
        if not finite_real(capacity) or capacity<=0:raise ArithmeticError(identifier+': capacidade não positiva/finita.')
        ratio=V*fraction/capacity
        row=dict(id=identifier,label=label,component=component,demand_N=V*fraction,
            actual_demand_N=c.V*fraction,design_capacity_N=capacity,utilization=ratio,
            actual_utilization=c.V*fraction/capacity,status='PASS' if ratio<=1 else 'FAIL',
            equivalent_total_V_capacity_N=capacity/fraction,formula=formula,reference=reference,**details)
        out['checks'].append(row);return row
    unit=elastic_line_group(support_weld_segments(c),0.,-1.,0.,c.length/2)
    actual=elastic_line_group(support_weld_segments(c),0.,-c.V,0.,c.length/2)
    q=unit['max_resultant_N_per_mm'];throat=c.weld_leg/math.sqrt(2);qw=.6*c.electrode_fuw*throat/GAMMA_A2
    section=support_leg_envelope(c,unit)
    out['welds']=dict(per_unit_force=unit,actual=actual,leg_mm=c.weld_leg,throat_mm=throat,
        coordinates='(z_global, y_up_from_angle_bottom); group scalar moment is -Mx_global',
        actual_centroid_Mx_Nmm=-actual['moment_about_centroid_Nmm'],
        actual_origin_Mx_Nmm=-actual['equilibrium']['integrated_M_about_origin_Nmm'],
        line_resistance_N_per_mm=qw,top_return_credited=False,support_leg_section=section)
    check('weld_L','Solda L excêntrica · ruptura','weld',qw/q,formula='[0,60 fuw (w/√2)/γa2]/qmax(F=1)',reference=NBR+' tabela9; P901 II.A-27 método elástico')
    for name,t,steel in [('angle',c.t,sa),('column',c.support.tf,ss)]:
        for mode,line,formula in [('yield',steel.fy*t/(math.sqrt(3)*GAMMA_A1),'fy t/(√3 γa1 qmax)'),('rupture',.6*steel.fu*t/GAMMA_A2,'0,60 fu t/(γa2 qmax)')]:
            check(name+'_weld_base_'+mode,'Metal-base junto à solda · '+name+' · '+mode,name,line/q,formula=formula,reference=NBR+' tabela9/6.5; limite local por unidade de comprimento',thickness_mm=t)
    check('support_leg_elastic','Aba no apoio · envelope elástico N/V/M','angle_support',sa.fy/GAMMA_A1/section['equivalent_stress_bound_MPa'],formula='(fy/γa1)/σeq(F=1)',reference='Equilíbrio analítico da solda L; NBR6.1.1.3/6.5')
    for name,net in [('beam',c.length-c.web_rows*dn),('support',c.length)]:
        check('angle_'+name+'_gross','Cantoneira · escoamento ao corte · '+name,'angle_'+name,.6*sa.fy*c.length*c.t/GAMMA_A1,formula='0,60 fy Ht/γa1',reference=NBR+' 6.5.5')
        check('angle_'+name+'_net','Cantoneira · ruptura ao corte · '+name,'angle_'+name,.6*sa.fu*net*c.t/GAMMA_A2,formula='0,60 fu An/γa2',reference=NBR+' 6.5.5')
    grip=c.beam.tw+c.t;grip_factor=max(0.,1-.01*max(0.,grip-5*c.db)/1.5)
    bolt=bolt_shear_resistance(c.db,BOLTS[c.bolt],c.web_threads_excluded,grip_factor)
    out['bolts']=dict(bolt_count=c.web_rows,shear_planes=1,physical_beam_webs=1,grip_mm=grip,grip_factor=grip_factor,resistance_per_plane_N=bolt)
    check('bolts_single_shear','Parafusos · corte simples','bolts',c.web_rows*bolt,formula='n α Ab fub/γa2 × fator de pega',reference=NBR+' 6.3.3.2/6.3.7')
    transfer=[];angle_bearings=[];web_bearings=[]
    for i in range(c.web_rows):
        angle_lc=end-dh/2 if i==c.web_rows-1 else c.web_pitch-dh
        # Opposite interface action: angle is loaded downward, beam web upward.
        # The uncoped web has no free vertical edge above its top bolt.
        web_lc=None if i==0 else c.web_pitch-dh
        ra=bearing_resistance(c.db,angle_lc,c.t,sa.fu);rw=bearing_resistance(c.db,web_lc,c.beam.tw,sb.fu)
        check(f'angle_bearing_{i+1}',f'Cantoneira · contato furo {i+1}','angle_beam',ra,1/c.web_rows,'min(1,2lc;2,4db)t fu/γa2',NBR+' 6.3.3.3',clear_distance_mm=angle_lc,loaded_direction='down')
        check(f'web_bearing_{i+1}',f'Alma única · contato furo {i+1}','beam_web',rw,1/c.web_rows,'min(1,2lc;2,4db)tw fu/γa2; superior sem borda livre vertical',NBR+' 6.3.3.3',clear_distance_mm=web_lc,loaded_direction='up')
        transfer.append(min(bolt,ra,rw))
        angle_bearings.append(ra);web_bearings.append(rw)
    for component,caps in [('angle',angle_bearings),('web',web_bearings)]:
        check(component+'_bearing_sum','Contato/rasgamento · soma normativa · '+component,component,sum(caps),formula='ΣRb,i',reference=NBR+' 6.3.3.3',per_hole_capacities_N=caps)
    check('transfer_sum','Transferência em série nos furos · soma','bolts_web_angle',sum(transfer),formula='Σmin(Rv, Rb,L, Rb,alma)',reference='P901 II.A-29; componentes NBR6.3.3')
    for k in range(1,c.web_rows+1):
        l=end+(k-1)*c.web_pitch;ag=l*c.t;an=(l-(k-.5)*dn)*c.t;ant=(g['angle_toe_edge_mm']-dn/2)*c.t
        check('angle_block_'+str(k),f'Cantoneira · bloco de {k} furos pela borda inferior','angle_beam',block_resistance(ag,an,ant,sa.fy,sa.fu,1.),k/c.web_rows,
            '[min(0,60fu Anv;0,60fy Agv)+fu Ant]/γa2',NBR+' 6.5.6',Agv_mm2=ag,Anv_mm2=an,Ant_mm2=ant)
    lam=c.beam.clear/c.beam.tw;lp=1.1*math.sqrt(5.34*200000./sb.fy);lr=1.37*math.sqrt(5.34*200000./sb.fy)
    Cv=1. if lam<=lp else lp/lam if lam<=lr else 1.24*(lp/lam)**2
    check('beam_shear','Alma da viga · cortante com instabilidade','beam_web',.6*sb.fy*c.beam.d*c.beam.tw*Cv/GAMMA_A1,
        formula='0,60fy d tw Cv/γa1; kv=5,34',reference=NBR+' 5.4.3.1',Cv=Cv)
    out['not_applicable']=[dict(mechanism='Bloco/ruptura por recorte da alma',reason='Viga sem recorte, mesas contínuas; P901 II.A-29 IIA-291.'),
        dict(mechanism='Parafusos no apoio/soldas na alma apoiada',reason='Não existem nesta topologia.'),
        dict(mechanism='Momento externo/engaste',reason='Rota convencional flexível descendente; N=M=T externos nulos não anulam excentricidade no plano da solda.')]
    issue('info','Retorno superior real mostrado, sem crédito resistente. Grupo L recebe V inteiro e excentricidade transversal; não há divisão por dois.','Ficha 1L0943')
    issue('info','O raio informado deve abranger cabeça, porca, arruela e ferramenta reais. O piso tabelado da ferragem não certifica o acesso da chave; não se reduz o envelope informado. Cabeças modificadas S fora do domínio.','Montagem física; ficha 1L0943')
    issue('info','Aprovação local não certifica fabricação, estabilidade global ou a disponibilidade física de acesso no edifício.','Escopo local')
    failures=[r['id'] for r in out['checks'] if r['status']=='FAIL']
    blockers=any(i['severity'] in ('detail_fail','access_pending','engineering_pending') for i in out['issues'])
    governing=max(out['checks'],key=lambda r:r['utilization'])
    out['summary']=dict(complete_checks=not blockers,governing_check_id=governing['id'],governing_label=governing['label'],
        governing_utilization=governing['utilization'],actual_governing_utilization=governing['actual_utilization'],
        equivalent_total_V_capacity_N=governing['equivalent_total_V_capacity_N'],failed_check_ids=failures,
        check_count=len(out['checks']),physical_angle_count=1)
    out['status']='VERIFIED_SUBCHECK_FAIL' if failures else 'DETAIL_FAIL' if any(i['severity']=='detail_fail' for i in out['issues']) else 'ENGINEERING_MODEL_PENDING' if blockers else 'COMPLETE_CHECKS_PASS_WITHIN_SCOPE'
    out['global_pass']=out['status']=='COMPLETE_CHECKS_PASS_WITHIN_SCOPE'
    return out


def evaluate(c):
    try:
        r=_evaluate(c)
        def finite(x):
            return all(finite(v) for v in x.values()) if isinstance(x,dict) else all(finite(v) for v in x) if isinstance(x,(list,tuple)) else math.isfinite(x) if isinstance(x,float) else True
        if not finite(r):raise ArithmeticError('Resultado não finito.')
        return r
    except (ArithmeticError,OverflowError) as e:
        return dict(status='NUMERICAL_FAILURE',global_pass=False,scope=SCOPE,exclusions=EXCLUSIONS.copy(),
            issues=[dict(severity='numerical_failure',text=str(e),reference='Faixa numérica')],checks=[],geometry={},load_model={},summary={},welds={},bolts={},components={})


def _safe(value):
    if isinstance(value,float) and not math.isfinite(value):return str(value)
    if isinstance(value,dict):return {k:_safe(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)):return [_safe(v) for v in value]
    return value
