"""Current-only app, JSON, diagram and Word view of bounded plate flexure."""
from io import BytesIO
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle,Rectangle
from docx.shared import Inches
from .single_key_plate import LIMITS,REF,result_is_current
from .display_precision import display_format


LABELS={'pass':'ATENDE AO ESCOAMENTO POR FLEXÃO (CONDICIONAL)',
        'fail':'NÃO ATENDE AO ESCOAMENTO POR FLEXÃO','pending':'FLEXÃO NÃO DEMONSTRADA'}


def require_current_result(c,result):
    d=getattr(result,'local_single_key_plate',result)
    if not result_is_current(c,d):
        raise ValueError('Resultado da placa receptora ausente ou desatualizado: recalcule.')
    return d


def json_bytes(c,result):
    d=require_current_result(c,result)
    return json.dumps(dict(schema='lro.single_key_plate.result.v1',input=c.to_dict(),result=d,
                           units=dict(force='N',moment='N mm',length='mm',stress='MPa'),
                           complete=False),ensure_ascii=False,indent=2,allow_nan=False).encode('utf-8')


def image_bytes(c,result,fmt='png'):
    d=require_current_result(c,result)
    state=next((s for s in d['states'] if s.get('id')==d.get('governing_state_id')),None)
    fig,ax=plt.subplots(figsize=(7.4,3.6))
    ax.add_patch(Rectangle((-c.L/2,-c.B/2),c.L,c.B,facecolor='#eef1f4',edgecolor='#24384a',lw=1.4))
    if state:
        lc=state['lc_mm'];left=c.L/2-lc if state['moment_sign']>0 else -c.L/2
        ax.add_patch(Rectangle((left,-c.B/2),lc,c.B,facecolor='#f0d19a',edgecolor='#a57425',alpha=.85))
    ax.add_patch(Rectangle((-c.lug_t/2,-c.lug_bh/2),c.lug_t,c.lug_bh,
                           facecolor='#b9d2e1',edgecolor='#406881',alpha=.7))
    for hole in d['known_anchor_holes']:
        ax.add_patch(Circle((hole['x_mm'],hole['y_mm']),hole['radius_mm'],facecolor='white',edgecolor='#24384a'))
    section=d['section']
    ax.plot([0,0],[section['y_min_mm'],section['y_max_mm']],color='#be3d42',lw=3,gid='single_key_plate_critical_section')
    ax.annotate('Seção x=0 · b efetivo=bh',xy=(0,section['y_max_mm']),
                xytext=(0,c.B/2+24),ha='center',fontsize=9,arrowprops=dict(arrowstyle='->',color='#be3d42'))
    ax.set_title('Placa receptora: seção bruta ideal, sem rigidez do pilar',fontsize=11,pad=28)
    ax.set_xlim(-c.L/2-25,c.L/2+25);ax.set_ylim(-c.B/2-24,c.B/2+56)
    ax.set_aspect('equal');ax.set_xlabel('x (mm) · eixo do cortante');ax.set_ylabel('y (mm)')
    ax.grid(alpha=.15)
    caption='Furos auxiliares/respiros não posicionados; transferência completa pendente.'
    if state:caption+='\nEstado: '+state['id']+' · contato usa C integral, sem reduzir por bh/B.'
    fig.text(.5,.018,caption,ha='center',fontsize=8)
    fig.subplots_adjust(left=.12,right=.97,bottom=.24,top=.73)
    b=BytesIO();fig.savefig(b,format=fmt,dpi=150);plt.close(fig);return b.getvalue()


def _n(value,scale=1.):
    return display_format(value/scale,'.2f')


def render_results(c,result):
    if not getattr(result,'local_single_key_plate',{}):return
    import streamlit as st
    try:d=require_current_result(c,result)
    except ValueError as exc:st.warning(str(exc));return
    with st.expander('Placa receptora da chave · flexão da seção bruta',expanded=True):
        writer=st.error if d['flexure_status']=='fail' else st.warning
        writer(LABELS[d['flexure_status']])
        st.image(image_bytes(c,result),width='stretch')
        for state in d['states']:
            st.write(state['id'])
            if 'M_Sd_Nmm' in state:
                st.write('Tlinha='+_n(state['T_row_N'],1000)+' kN; C='+_n(state['C_N'],1000)+
                         ' kN; Mt='+_n(state['M_tension_Nmm'],1e6)+' kN·m; Mc='+_n(state['M_contact_Nmm'],1e6)+
                         ' kN·m; MSd='+_n(state['M_Sd_Nmm'],1e6)+' kN·m; MRd='+_n(state['M_Rd_Nmm'],1e6)+
                         ' kN·m; índice='+_n(state['utilization'])+'.')
            for reason in state['reasons']:st.warning(reason)
        st.caption('Mt e Mc são momentos de cada lado do corte. Usa-se o maior, sem nova parcela V·e. '
                   'Resistência ao escoamento por flexão da placa: (fy/1,10) bh tp²/4; não usa o fy da chave.')
        st.warning(LIMITS)
        st.caption(d['interface_gap'])
        st.download_button('Baixar resultado da flexão da placa (JSON)',data=json_bytes(c,result),
                           file_name='placa_receptora_chave_resultado.json',mime='application/json',
                           key='bp_single_key_plate_json')


def append_report(doc,c,result):
    if not getattr(result,'local_single_key_plate',{}):return
    from .report import table,_math,group,sub,frac,power
    d=require_current_result(c,result)
    title=doc.add_paragraph('Placa receptora da chave · flexão da seção bruta',style='Heading 1')
    title.paragraph_format.page_break_before=True
    doc.add_paragraph(LABELS[d['flexure_status']]+'. Transferência completa e metal-base das interfaces: PENDENTES.')
    doc.add_picture(BytesIO(image_bytes(c,result)),width=Inches(6.7))
    _math(doc,group(sub('M','Sd'),' = max[',sub('T','linha'),' a; C(L − ',sub('l','c'),')/2]'))
    _math(doc,group(sub('M','Rd'),' = ',frac(group(sub('f','y'),' ',sub('b','h'),' ',power(sub('t','p'))),'4 × 1,10')))
    doc.add_paragraph('Tlinha soma as duas barras tracionadas. C é a resultante integral de contato do mesmo estado. '
                      'Mt e Mc são valores dos dois lados do corte, não parcelas a somar como demanda. '
                      'Mbase já inclui o transporte V·e da face superior: nenhuma nova parcela é adicionada. '
                      'O aço e a espessura são os da placa receptora; a flexão da própria chave é outra verificação.')
    rows=[]
    for state in d['states']:
        if 'M_Sd_Nmm' in state:
            rows.append((state['id'],_n(state['M_tension_Nmm'],1e6),_n(state['M_contact_Nmm'],1e6),
                         _n(state['M_Rd_Nmm'],1e6),_n(state['utilization'])))
        else:doc.add_paragraph(state['id']+': '+'; '.join(state['reasons']))
    if rows:table(doc,['Estado','Mt (kN·m)','Mc (kN·m)','MRd (kN·m)','Índice'],rows,[2.75,1.,1.,1.,.9])
    if 't_required_mm' in d:
        doc.add_paragraph('Espessura requerida por este componente: '+_n(d['t_required_mm'])+' mm. A síntese geral conserva o maior valor dos modos calculados; mecanismos pendentes permanecem separados.')
    for reason in d['reasons']:doc.add_paragraph(reason)
    doc.add_paragraph(LIMITS)
    doc.add_paragraph(d['interface_gap'])
    doc.add_paragraph(REF)
