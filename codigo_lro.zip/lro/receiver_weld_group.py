"""Candidate only: elastic 3-D weld-line tractions, not receiver-plate approval.

Units N/mm/MPa. Equal isotropic line stiffness per effective throat area and
rigid connected parts are explicit assumptions. The weld resistance is the
NBR 8800:2024 6.2.5 / Table 9 vector criterion, without directional increase.
Table 9 supplies resistance, not proof of this load-distribution idealization.
"""
import math


def _finite(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)


def _vector(v, label):
    if len(v) != 3 or not all(_finite(x) for x in v):
        raise ValueError(label + ' must contain three finite coordinates.')
    return [float(x) for x in v]


def _add(a, b):
    return [x+y for x, y in zip(a, b)]


def _sub(a, b):
    return [x-y for x, y in zip(a, b)]


def _scale(k, v):
    return [k*x for x in v]


def _dot(a, b):
    return math.fsum(x*y for x, y in zip(a, b))


def _cross(a, b):
    return [a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]]


def _sumvec(vectors):
    return [math.fsum(v[i] for v in vectors) for i in range(3)]


def _solve3(matrix, rhs):
    scale = max(abs(v) for row in matrix for v in row)
    if not math.isfinite(scale) or scale <= 0:
        raise ValueError('Degenerate weld rotational inertia.')
    a = [[v/scale for v in row]+[rhs[i]/scale] for i, row in enumerate(matrix)]
    for col in range(3):
        pivot = max(range(col, 3), key=lambda i: abs(a[i][col]))
        if abs(a[pivot][col]) <= 1e-13:
            raise ValueError('Weld geometry cannot resist all three moment components.')
        a[col], a[pivot] = a[pivot], a[col]
        p = a[col][col]
        a[col] = [v/p for v in a[col]]
        for row in range(3):
            if row != col:
                factor = a[row][col]
                a[row] = [x-factor*y for x, y in zip(a[row], a[col])]
    result = [a[i][3] for i in range(3)]
    if not all(math.isfinite(x) for x in result):
        raise ArithmeticError('Nonfinite weld stress gradient.')
    return result


def elastic_weld_group_3d(segments, force_N, load_point_mm, free_moment_Nmm=(0., 0., 0.)):
    """Affine vector traction and exact per-edge force/couple integrals.

    segments: id, start_mm/end_mm (x,y,z), leg_mm, fillet_count (default 2).
    Coincident fillets are projected to the declared reference line. Their
    summed weight n*w/sqrt(2) multiplies line load and area, not plate thickness.
    Returned forces have the applied/transmitted sense, not reaction sense.
    free_moment_Nmm is a free couple at load_point_mm; no double translation.
    """
    force = _vector(force_N, 'Force'); point = _vector(load_point_mm, 'Load point')
    couple = _vector(free_moment_Nmm, 'Free moment'); lines = []; ids = set()
    for segment in segments:
        ident = segment['id']; p = _vector(segment['start_mm'], 'Segment start')
        q = _vector(segment['end_mm'], 'Segment end'); w = segment['leg_mm']
        n = segment.get('fillet_count', 2)
        if not isinstance(ident, str) or not ident or ident in ids or not _finite(w) or w <= 0 or type(n) is not int or n < 1:
            raise ValueError('Invalid weld segment id, leg or fillet count.')
        ids.add(ident); delta = _sub(q, p); L = math.sqrt(_dot(delta, delta))
        throat = w/math.sqrt(2); weight = n*throat; area = weight*L
        if not all(math.isfinite(v) and v > 0 for v in (L, throat, weight, area)):
            raise ValueError('Invalid weld segment length or throat area.')
        lines.append(dict(id=ident, start_mm=p, end_mm=q, midpoint_mm=_add(p, _scale(.5, delta)),
                          length_mm=L, leg_mm=w, throat_mm=throat, fillet_count=n,
                          line_weight_mm=weight, area_mm2=area, tangent_unit=_scale(1/L, delta)))
    if not lines:
        raise ValueError('Empty weld group.')
    area = math.fsum(s['area_mm2'] for s in lines)
    center = [math.fsum(s['area_mm2']*s['midpoint_mm'][i] for s in lines)/area for i in range(3)]
    tensor = [[0.]*3 for _ in range(3)]
    for s in lines:
        r = _sub(s['midpoint_mm'], center); tangent = s['tangent_unit']; h = s['length_mm']**2/12
        C = [[s['area_mm2']*(((_dot(r, r)+h) if i == j else 0.)-r[i]*r[j]-h*tangent[i]*tangent[j])
              for j in range(3)] for i in range(3)]
        s['rotational_inertia_tensor_mm4'] = C
        for i in range(3):
            for j in range(3):
                tensor[i][j] += C[i][j]
    mc = _add(couple, _cross(_sub(point, center), force))
    mo = _add(couple, _cross(point, force)); omega = _solve3(tensor, mc)
    direct = _scale(1/area, force); endpoints = []
    for s in lines:
        edge_points = []
        for label, p in [('start', s['start_mm']), ('end', s['end_mm'])]:
            stress = _add(direct, _cross(omega, _sub(p, center)))
            result = dict(segment=s['id'], endpoint=label, point_mm=p, stress_MPa=stress,
                          sx_MPa=stress[0], sy_MPa=stress[1], sz_MPa=stress[2],
                          resultant_MPa=math.sqrt(_dot(stress, stress)),
                          line_force_N_per_mm=_scale(s['line_weight_mm'], stress))
            edge_points.append(result); endpoints.append(result)
        r = _sub(s['midpoint_mm'], center); tangent = s['tangent_unit']
        fi = _scale(s['area_mm2'], _add(direct, _cross(omega, r)))
        li = _scale(s['area_mm2']*s['length_mm']**2/12,
                    _sub(omega, _scale(_dot(tangent, omega), tangent)))
        mci = _add(_cross(r, fi), li); moi = _add(_cross(s['midpoint_mm'], fi), li)
        critical = max(edge_points, key=lambda p: p['resultant_MPa'])
        s.update(endpoint_stresses=edge_points, critical_point=critical, max_stress_MPa=critical['resultant_MPa'],
                 integrated_force_N=fi, integrated_Fx_N=fi[0], integrated_Fy_N=fi[1], integrated_Fz_N=fi[2],
                 local_couple_Nmm=li, local_couple_z_Nmm=li[2],
                 integrated_moment_about_centroid_Nmm=mci, integrated_moment_about_origin_Nmm=moi)
    total_f = _sumvec([s['integrated_force_N'] for s in lines])
    total_mc = _sumvec([s['integrated_moment_about_centroid_Nmm'] for s in lines])
    total_mo = _sumvec([s['integrated_moment_about_origin_Nmm'] for s in lines])
    critical = max(endpoints, key=lambda p: p['resultant_MPa'])
    return dict(area_mm2=area, centroid_mm=center, inertia_tensor_mm4=tensor,
                force_N=force, load_point_mm=point, free_moment_Nmm=couple,
                moment_about_centroid_Nmm=mc, moment_about_origin_Nmm=mo,
                moment_gradient_MPa_per_mm=omega, segments=lines, critical_point=critical,
                max_stress_MPa=critical['resultant_MPa'],
                equilibrium=dict(integrated_force_N=total_f, integrated_moment_about_centroid_Nmm=total_mc,
                                 integrated_moment_about_origin_Nmm=total_mo,
                                 force_residual_N=_sub(total_f, force), moment_centroid_residual_Nmm=_sub(total_mc, mc),
                                 moment_origin_residual_Nmm=_sub(total_mo, mo)))


def horizontal_receiver_segments(c, level='top'):
    """Front horizontal octagon: web and both flange joints, no free-front weld.

    x is outward, y vertical, z across the column depth. Paired fillets above
    and below the horizontal are projected onto its mid-plane, not onto the
    rib contact face. This neglects their small separation as a stated line
    idealization; no moment capacity is credited solely to that separation.
    """
    if level not in ('top', 'bottom'):
        raise ValueError('level must be top or bottom.')
    b, s, clip, t, H, w = c.projection, c.stiffener_span, c.corner_clip, c.stiffener_t, c.root_height, c.weld_stiffener_column
    if not all(_finite(v) for v in (b, s, clip, t, H, w)) or min(b, s, t, H, w) <= 0 or clip < 0 or min(b-2*clip, s-2*clip) <= 0:
        raise ValueError('Horizontal weld geometry is invalid or erased by corner clips.')
    sign = 1 if level == 'top' else -1; y = sign*(H+t)/2
    return [dict(id='web', start_mm=[0., y, -s/2+clip], end_mm=[0., y, s/2-clip], leg_mm=w, fillet_count=2),
            dict(id='flange_negative_z', start_mm=[clip, y, -s/2], end_mm=[b-clip, y, -s/2], leg_mm=w, fillet_count=2),
            dict(id='flange_positive_z', start_mm=[clip, y, s/2], end_mm=[b-clip, y, s/2], leg_mm=w, fillet_count=2)]


def receiver_weld_group(c, Fx, Fy, Mz, *, level='top', case='', model=''):
    """Horizontal-to-column weld check for one complete concomitant action set.

    Fx,Fy,Mz are transmitted TO the front horizontal at (b/2, +/-H/2, 0).
    Beam model: negate its support reaction. Three-edge model: use that edge's
    integrated Fx,Fy and its local free couple, without adding V*e again.
    Never form this input by combining independent maxima from hypotheses.
    """
    segments = horizontal_receiver_segments(c, level)
    if not _finite(c.fw) or c.fw <= 0:
        raise ValueError('Positive finite weld metal strength is required.')
    y = (1 if level == 'top' else -1)*c.root_height/2
    result = elastic_weld_group_3d(segments, [Fx, Fy, 0.], [c.projection/2, y, 0.], [0., 0., Mz])
    resistance = .6*c.fw/1.35; long_edges = []
    for segment in result['segments']:
        segment['stress_resistance_MPa'] = resistance
        segment['utilization'] = segment['max_stress_MPa']/resistance
        segment['length_to_leg_ratio'] = segment['length_mm']/segment['leg_mm']
        if segment['length_to_leg_ratio'] > 100:
            long_edges.append(segment['id'])
        for p in segment['endpoint_stresses']:
            p['normal_to_horizontal_MPa'] = p['sy_MPa']
            p['in_plane_horizontal_MPa'] = math.hypot(p['sx_MPa'], p['sz_MPa'])
            p['utilization'] = p['resultant_MPa']/resistance
    result.update(level=level, case=case, load_model=model, model='elastic_horizontal_receiver_U_weld_group',
                  stress_resistance_MPa=resistance, utilization=result['max_stress_MPa']/resistance,
                  sign_convention='x outward, y up, z across column; right-hand moments; transmitted actions to receiver',
                  receiver_rigidity_assumed=True, horizontal_plate_strength_status='pending',
                  base_metal_status='pending', column_receiver_strength_status='pending',
                  in_plane_fixity_status='pending', assembly_approval_status='not_established',
                  source='NBR 8800:2024 6.2.2.2 and 6.2.5 / Table 9; analytic elastic 3-D line allocation',
                  directional_strength_increase=False, long_joint_edges=long_edges,
                  long_joint_status='pending_reduction_applicability' if long_edges else 'within_100_leg_scope',
                  detailing_status='existing_interface_leg_and_length_checks_required',
                  assumption='Rigid connected parts; uniform isotropic stiffness per effective throat area; paired fillets projected to horizontal mid-plane. Fy is normal traction on the horizontal, not its in-plane base-metal shear.',
                  paired_fillet_note='Two symmetric fillets give line weight 2w/sqrt(2). Integrated forces include both; horizontal and column plate thicknesses are never doubled.')
    return result
