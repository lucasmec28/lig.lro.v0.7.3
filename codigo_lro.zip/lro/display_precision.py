"""Presentation-only decimal policy.

Native inputs, engines, comparisons and machine-readable exports stay numeric
and unrounded. Helpers return new text/copies and must never feed calculations.
"""
from math import isfinite
from numbers import Integral, Real
import json
import re


def display_format(value, spec=''):
    """Format a displayed scalar with no more than two decimal places.

    Existing 0/1-decimal requests are retained. Integers remain integers unless
    the caller explicitly requested fixed decimals. Tiny nonzero quantities and
    very large values use scientific notation rather than a misleading zero.
    This is not a units conversion and deliberately never edits arbitrary text.
    """
    if isinstance(value, bool) or not isinstance(value, Real):
        return format(value, spec)
    try:
        finite = isfinite(value)
    except (OverflowError, ValueError):
        finite = False
    if not finite:
        return format(value, spec)
    if spec and not re.fullmatch(r'[+ -]?,?(?:\.\d+)?[fFgGeE%]?', spec):
        return format(value, spec)
    sign = '+' if '+' in spec else (' ' if spec.startswith(' ') else '')
    grouped = ',' if ',' in spec else ''
    fixed = re.search(r'\.(\d+)[fF%]$', spec)
    places = min(2, int(fixed.group(1))) if fixed else 2
    if isinstance(value, Integral) and not fixed and not spec.endswith(('%','e','E')):
        return format(value, sign + grouped + 'd')
    if spec.endswith('%'):
        return display_format(value * 100, sign + grouped + '.' + str(places) + 'f') + '%'
    if (value != 0 and abs(value) < 10 ** -places) or abs(value) >= 1e12 or spec.endswith(('e','E')):
        return format(value, sign + '.2e')
    rendered = format(value, sign + grouped + '.' + str(places) + 'f')
    return rendered.rstrip('0').rstrip('.') if spec.endswith(('g', 'G')) else rendered


def display_value(value):
    """Text scalar; stable identifiers, standards, names and prose stay exact."""
    if isinstance(value, Real) and not isinstance(value, (bool, Integral)):
        return display_format(value)
    return str(value)


def display_tree(value):
    """Non-mutating display copy for nested diagnostic tables and JSON views."""
    if isinstance(value, dict):
        return {key: calculated_text(item, assignments_only=(key == 'variables')) if key in ('substitution', 'variables') and isinstance(item, str) else display_tree(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [display_tree(item) for item in value]
    if isinstance(value, Real) and not isinstance(value, (bool, Integral)):
        return display_format(value)
    return value


def display_json(value, **kwargs):
    return json.dumps(display_tree(value), **kwargs)


def display_frame(value):
    """Independent cell text over raw numeric data: sorting remains numeric."""
    import pandas as pd
    frame = value.copy(deep=True) if isinstance(value, pd.DataFrame) else pd.DataFrame(value)
    return frame.style.format(lambda item: str(display_tree(item)) if isinstance(item, (dict, list, tuple)) else display_value(item))


def number_input(*args, **kwargs):
    """Use Streamlit's render format without rounding its value/session state.

    The existing widget remains the source of edits. Imported high-precision
    floats survive a render/rerun untouched; integer count widgets stay integer.
    """
    import streamlit as st
    current = st.session_state.get(kwargs.get('key')) if kwargs.get('key') is not None else None
    candidates = [current, kwargs.get('value'), kwargs.get('min_value'), kwargs.get('max_value'), kwargs.get('step')]
    candidates.extend(args[1:5])
    numeric = [v for v in candidates if isinstance(v, Real) and not isinstance(v, bool)]
    explicit_int = kwargs.get('format') in ('%d', '%i')
    integral = explicit_int or (bool(numeric) and all(isinstance(v, Integral) for v in numeric))
    tiny = isinstance(current, Real) and not isinstance(current, (bool, Integral)) and current != 0 and abs(current) < .01
    kwargs['format'] = '%d' if integral else ('%.2e' if tiny else '%.2f')
    return st.number_input(*args, **kwargs)


_CALCULATED_DECIMAL = re.compile(r'(?<![\w.,])[-+]?\d+[.,]\d{3,}(?:[eE][-+]?\d+)?(?:(?![\w,]|\.\d)|(?=(?:kN|MPa|N|mm|kgf)(?:\b|[·/²³])))')


def calculated_text(text, assignments_only=False):
    """Render an engine's numeric substitution string without mutating it.

    Use only for the explicit substitution field, or numeric assignments / explicitly unit-labelled quantities in its
    explanatory variables or issue field. Never use for equations, references, project
    labels, catalogue identities, native JSON or arbitrary document text.
    Standard clauses/multiple-dot versions are not scalar tokens. The exact
    kgf conversion constant is a definition and is retained verbatim.
    """
    text = str(text)
    def replace(match):
        token = match.group(0)
        if token.replace(',', '.') in ('9.80665', '+9.80665', '-9.80665'):
            return token
        if assignments_only:
            prefix = text[:match.start()].rstrip()
            suffix = text[match.end():].lstrip()
            measured = re.match(r'(?:kN|MPa|N|mm|kgf|graus|%)(?:\b|[·/²³])', suffix)
            if (not prefix or prefix[-1] not in '=(/×+−-') and not measured:
                return token
        value = float(token.replace(',', '.'))
        shown = display_format(value)
        return shown.replace('.', ',') if ',' in token else shown
    return _CALCULATED_DECIMAL.sub(replace, text)
