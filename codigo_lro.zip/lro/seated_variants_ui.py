"""Portuguese, local-only seat diagnostics; isolated, lossless project state."""
from dataclasses import fields, replace
import json
import math
from pathlib import Path

import pandas as pd
import streamlit as st

from . import seated_variants as core
from .beam_direct_seat_presentation import HEADERS, checks_rows, fmt
from .display_precision import number_input
from .models import KGF, Profile, STEELS, profiles

PREFIX = 'sv_'
CUSTOM = 'W personalizado (dados preservados)'
P = {n: p for n, p in profiles().items() if p.family == 'W'}
FORCES = ('V', 'shear_left', 'shear_right')
PROFILE_VALUES = ('d', 'bf', 'tw', 'tf', 'clear', 'area', 'mass')


def _widget_float(value, name):
    result = float(value)
    if not math.isfinite(result) or result != value:
        raise ValueError(name + ': valor não representável sem alteração no controle.')
    return result


def _proposed_ui_state(c):
    """Complete validation before any mutation, including custom profile metadata."""
    c.to_dict()
    proposed = {}
    for f in fields(c):
        if f.name in ('beam', 'support'):
            continue
        value = getattr(c, f.name)
        if isinstance(value, (float, int)) and not isinstance(value, bool):
            value = _widget_float(value, f.name)
        proposed[PREFIX + f.name] = value
    for key in FORCES:
        shown = getattr(c, key) / KGF
        if not math.isfinite(shown):
            raise ValueError(key + ': ação não representável em kgf.')
        proposed[PREFIX + key + '_kgf'] = shown
    for role in ('beam', 'support'):
        p = getattr(c, role)
        prefix = PREFIX + role + '_'
        proposed[prefix + 'name'] = p.name if p.name in P and p == P[p.name] else CUSTOM
        for key in ('name', 'family', 'source'):
            proposed[prefix + ('manual_name' if key == 'name' else key)] = getattr(p, key)
        for key in PROFILE_VALUES:
            proposed[prefix + key] = _widget_float(getattr(p, key), role + '.' + key)
    return proposed


def seed(c):
    proposed = _proposed_ui_state(c)
    st.session_state.update(proposed)
    st.session_state['_sv_draft'] = dict(proposed)
    st.session_state.pop('_seated_variants_result', None)


def _unique_object(pairs):
    data = {}
    for key, value in pairs:
        if key in data:
            raise ValueError('Campo JSON duplicado: ' + key)
        data[key] = value
    return data


def load_project():
    try:
        upload = st.session_state.get(PREFIX + 'upload')
        if upload is None:
            raise ValueError('Selecione um projeto JSON desta família.')
        payload = upload.getvalue()
        if len(payload) > 200000:
            raise ValueError('Arquivo maior que 200 kB.')
        data=json.loads(payload, object_pairs_hook=_unique_object)
        c = core.SeatedVariant.from_dict(data)
        seed(c)
        st.session_state[PREFIX+'import_notice']='Projeto anterior preservado; verificações e limites reaplicados pela revisão atual.' if data['component_version']!=core.VERSION else ''
        st.session_state.pop(PREFIX + 'import_error', None)
    except (ValueError, TypeError, KeyError, ArithmeticError, UnicodeError) as exc:
        st.session_state[PREFIX + 'import_error'] = 'Importação rejeitada; dados anteriores mantidos. ' + str(exc)


def _select(label, options, key):
    choices = list(options)
    current = st.session_state.get(key)
    if current is not None and current not in choices:
        choices.append(current)
    return st.selectbox(label, choices, key=key)


def _profile(role, title):
    prefix = PREFIX + role + '_'
    name = st.selectbox(title, [CUSTOM] + list(P), key=prefix + 'name')
    if name in P:
        return P[name]
    with st.expander('Seção W informada — ' + title, expanded=True):
        designation = st.text_input('Designação — ' + title, key=prefix + 'manual_name')
        family = st.text_input('Família — ' + title, key=prefix + 'family')
        values = {key: number_input(label + ' — ' + title, min_value=0., key=prefix + key)
                  for key, label in (('d', 'Altura d (mm)'), ('bf', 'Mesa bf (mm)'),
                                     ('tw', 'Alma tw (mm)'), ('tf', 'Mesa tf (mm)'),
                                     ('clear', 'Altura livre das raízes (mm)'),
                                     ('area', 'Área (mm²)'), ('mass', 'Massa (kg/m)'))}
        source = st.text_input('Fonte — ' + title, key=prefix + 'source')
    return Profile(designation, family, source=source, **values)


def _stored_profile(role):
    prefix = PREFIX + role + '_'
    name = st.session_state[prefix + 'name']
    if name in P:
        return P[name]
    return Profile(st.session_state[prefix + 'manual_name'], st.session_state[prefix + 'family'],
                   source=st.session_state[prefix + 'source'],
                   **{key: st.session_state[prefix + key] for key in PROFILE_VALUES})


def _force(key):
    raw = st.session_state[PREFIX + key]
    shown = st.session_state[PREFIX + key + '_kgf']
    if not math.isfinite(shown):
        raise ValueError('Ações devem ser finitas.')
    value = raw if shown == raw / KGF else shown * KGF
    if not math.isfinite(value):
        raise ValueError('Ação fora da faixa numérica.')
    return value


def connection_from_state():
    values = {f.name: st.session_state[PREFIX + f.name]
              for f in fields(core.SeatedVariant) if f.name not in ('beam', 'support')}
    values.update({role: _stored_profile(role) for role in ('beam', 'support')})
    values.update({key: _force(key) for key in FORCES})
    return core.SeatedVariant(**values)


def _remember_draft():
    # Streamlit removes hidden widget keys: retain all schema fields in a shadow.
    keys = st.session_state['_sv_draft'].keys()
    st.session_state['_sv_draft'] = {key: st.session_state.get(key, st.session_state['_sv_draft'][key])
                                   for key in keys}


def _dimension(key, label):
    return number_input(label + ' (mm)', min_value=0., key=PREFIX + key)


def render():
    if '_sv_draft' not in st.session_state:
        seed(core.presets()['concrete_end'])
    for key, value in st.session_state['_sv_draft'].items():
        # Detach widget-backed keys before Streamlit's hidden-widget cleanup.
        st.session_state[key] = st.session_state.get(key, value)
    st.subheader('Apoios de viga · verificações locais')
    st.info('Verificação do caminho metálico por gravidade. Interfaces com o projeto civil e com os membros da estrutura são informadas separadamente.')
    st.caption('ASI DG6 + Handbook 1 (2007), base AS 4100 histórica. Sem combinação com fatores NBR. Revisão privada; obter permissão do editor antes de uso comercial/publicação.')
    with st.expander('Projeto · importar e identificar'):
        st.file_uploader('Projeto JSON desta família', type=['json'], key=PREFIX + 'upload')
        st.button('Importar projeto', key=PREFIX + 'import', on_click=load_project)
        if st.session_state.get(PREFIX + 'import_error'):
            st.error(st.session_state[PREFIX + 'import_error'])
        if st.session_state.get(PREFIX+'import_notice'):st.caption(st.session_state[PREFIX+'import_notice'])
        st.text_input('Projeto', key=PREFIX + 'project')
        st.text_area('Notas e hipóteses externas', key=PREFIX + 'notes')
    variant = st.selectbox('Caso de apoio', list(core.LABELS), format_func=lambda k: core.LABELS[k], key=PREFIX + 'variant')
    if variant=='angle_seat':
        st.button('Carregar exemplo B9 · quatro M20', key=PREFIX+'example_b9', on_click=lambda: seed(replace(core.presets()['angle_seat'], attachment='bolted', bolt_top=60., bolt_pitch=50., bolt_gauge=120., column_top_edge=300., column_bottom_edge=300., bolt_tool_radius=25., bolt_tool_length=65.)))
    st.caption('Campos de outras variantes ficam preservados no projeto e não são usados como verificações deste caso.')
    _profile('beam', 'Viga apoiada · perfil W')
    _select('Aço da viga apoiada', STEELS, PREFIX + 'beam_steel')
    if variant != 'concrete_end':
        _profile('support', 'Coluna receptora · perfil W')
        _select('Aço da coluna', STEELS, PREFIX + 'support_steel')
    number_input('Reação vertical de cálculo V (kgf)', min_value=0., key=PREFIX + 'V_kgf')
    st.caption('Informe ações de cálculo já combinadas. A interface converte kgf para N; não aplica fatores de carga.')
    if variant == 'column_continuous':
        number_input('Cortante de cálculo à esquerda (módulo, kgf)', min_value=0., key=PREFIX + 'shear_left_kgf')
        number_input('Cortante de cálculo à direita (módulo, kgf)', min_value=0., key=PREFIX + 'shear_right_kgf')
        st.info('Os cortantes de cada painel são independentes da reação V e devem vir do modelo global. Não se assume V/2.')
    if variant == 'angle_seat':
        for key, label in (('angle_horizontal', 'Aba horizontal'), ('angle_vertical', 'Aba vertical'),
                           ('angle_thickness', 'Espessura da cantoneira'), ('angle_length', 'Comprimento transversal'),
                           ('angle_gap', 'Folga de cálculo, incluindo tolerância'), ('angle_root_radius', 'Raio interno')):
            _dimension(key, label)
        _select('Aço da cantoneira · domínio da fonte', getattr(core, 'ANGLE_STEELS', {}), PREFIX + 'angle_steel')
        st.caption('O modelo de cantoneira é limitado ao aço Grade 300 documentado na fonte; materiais fora do domínio não recebem aprovação local.')
        attachment = st.selectbox('Fixação da cantoneira à coluna', ['welded','bolted'],
                                  format_func=lambda k: 'Soldada' if k == 'welded' else 'Parafusada B9 · quatro M20 8.8N/S', key=PREFIX + 'attachment')
        if attachment == 'welded':
            _dimension('weld_leg', 'Perna do filete contínuo de pernas iguais a 90° (6 ou 8)')
            _dimension('weld_effective_length', 'Comprimento efetivo de tamanho pleno de cada solda vertical')
            mode=st.selectbox('Resistência da solda', ['automatic','manual'], format_func=lambda k: 'Automática · ASI Handbook 1 (2007)' if k=='automatic' else 'Manual · valor excepcional com fonte', key=PREFIX+'weld_mode')
            if mode=='automatic':
                st.selectbox('Categoria de execução da solda', list(core.WELD_CATEGORIES), key=PREFIX+'weld_category')
                st.selectbox('Consumível de soldagem', list(core.WELD_ELECTRODES), key=PREFIX+'weld_electrode')
                st.caption('qRd = φ × 0,6 fuw × (perna/√2), com kr=1 no assento não longo. φ=0,80 SP ou 0,60 GP. Sem penetração adicional ou aumento por direção. Handbook 1, pp.58–60; base histórica 2007.')
            else:
                number_input('Resistência linear de cálculo qRd verificada (N/mm)', min_value=0., key=PREFIX + 'weld_line_capacity')
                st.text_input('Fonte de qRd: norma, eletrodo, filete, categoria e metal-base', key=PREFIX + 'weld_capacity_source')
                st.caption('Zero ou fonte ausente mantém o modo manual pendente. Não misturar fatores de resistência NBR com este modelo AS.')
            st.checkbox('O detalhe exige tratamento de emenda LONGA por sobreposição (fora do escopo)', key=PREFIX+'weld_long_lap')
            st.caption('A categoria e o consumível são especificações de projeto; sua seleção não atesta a solda executada. Procedimento e compatibilidade com o metal-base devem ser qualificados.')
        else:
            st.caption('B9: quatro M20 8.8N/S em malha simétrica 2×2; furos-padrão 22 mm; um plano de corte com rosca. Sem calço. Dimensões nulas mantêm projeto legado pendente.')
            for key,label in (('bolt_top','Topo externo da cantoneira até a fila superior'),('bolt_pitch','Passo vertical entre as duas filas'),('bolt_gauge','Gabarito entre as duas colunas'),('column_top_edge','Fila superior até a borda superior real da coluna'),('column_bottom_edge','Fila inferior até a borda inferior real da coluna'),('bolt_tool_radius','Raio do envelope real de montagem'),('bolt_tool_length','Comprimento axial do envelope real de montagem')):
                _dimension(key,label)
            if st.session_state[PREFIX+'packer_thickness']!=0:_dimension('packer_thickness','Calço registrado (deve ser zero no B9)')
            st.caption('Grade300: fy=320 MPa para ta<11; 300 para 11≤ta≤17; 280 acima de 17 mm; fu=440 MPa. HB1 p.78. B1 mantém 300 conservador abaixo de 11 mm.')
        st.caption('Escopo B1/B9 desta revisão: cantoneira fixada à MESA de coluna W. A cantoneira e as soldas devem caber nessa face. Não é ligação à alma da coluna.')
        st.info('Parafusos de localização/contenção não recebem parcela V/4. A fixação do assento à coluna tem verificação própria; montagem e liberdade de rotação devem seguir os requisitos de execução indicados.')
    else:
        _dimension('bearing_length', 'Comprimento rígido efetivo do apoio')
        _dimension('bearing_width', 'Largura efetiva do contato')
        if variant!='concrete_end' or st.session_state[PREFIX+'packer_thickness']!=0:
            _dimension('packer_thickness', 'Chapa/calço existente (fora do modelo direto se maior que zero)')
        if variant=='concrete_end':
            st.caption('Apoio direto sem chapa de distribuição ou chumbadores. bs é o contato efetivo já descontadas as tolerâncias; o resultado civil não é tratado como pendência metálica.')
    st.checkbox('A2 · enrijecedores na VIGA APOIADA (sem crédito resistente)', key=PREFIX + 'supported_stiffeners')
    st.caption('A2: detalhe na alma da viga apoiada. Área efetiva, flambagem, ajuste e soldas não dimensionados; marcar não aumenta a resistência.')
    with st.expander('A1(c) · enrijecedores na viga receptora: outro detalhe'):
        st.info('A1(c) refere-se à VIGA RECEPTORA no apoio viga sobre viga. Não são enrijecedores da coluna. Use a família existente de apoio direto viga sobre viga para esse detalhe; também sem crédito resistente automático.')
        if st.session_state[PREFIX + 'receiving_stiffeners']:
            st.warning('Projeto importado registra A1(c). A informação é preservada no JSON, mas não é aplicável nem representada como reforço de coluna nesta tela.')
    _remember_draft()
    try:
        c = connection_from_state()
        result = core.evaluate(c)
    except (ValueError, TypeError, KeyError, ArithmeticError) as exc:
        st.session_state['_seated_variants_result'] = {'status': 'INVALID_INPUT', 'global_pass': False, 'errors': [str(exc)]}
        st.error('Não foi possível avaliar os dados: ' + str(exc))
        return
    st.session_state['_seated_variants_result'] = result
    if result.get('errors'):
        for error in result['errors']:
            st.error(error)
        return
    st.write(result.get('scope_summary',''))
    if result.get('metal_scope_pass'):
        st.success(result['diagnosis'])
    elif result['status']=='LOCAL_LOAD_PATH_PENDING':
        st.warning(result['diagnosis'])
    elif result['status'] == 'LOCAL_ATTACHMENT_PENDING':
        st.warning(result['diagnosis'])
    elif result['status'] == 'BOLTED_MODEL_INCOMPLETE':
        st.warning(result['diagnosis'])
    else:
        st.error(result.get('diagnosis', 'Caso fora do domínio: consulte os dados e limites.'))
    qrd=result.get('parameters',{}).get('weld_qRd_N_per_mm')
    if qrd is not None:
        st.caption('Resistência linear de cálculo da solda: '+f'{qrd:.2f}'.replace('.',',')+' N/mm. O grupo considera a excentricidade da reação.')
    st.dataframe(pd.DataFrame(checks_rows(result['checks']), columns=HEADERS), hide_index=True, use_container_width=True)
    if result.get('missing_verifications'):
        st.markdown('Pendências do caminho metálico')
        for gap in result['missing_verifications']:st.write('• '+gap)
    st.markdown('Interfaces entregues ao projeto')
    for item in result.get('interfaces',[]):
        st.write(item['title']+': '+item['description'])
        values=item.get('values',{})
        if 'mean_pressure_MPa' in values:
            st.caption('Reação '+fmt(values['reaction_N']/KGF)+' kgf; contato '+fmt(values['contact_length_mm'])+' × '+fmt(values['contact_width_mm'])+' mm; pressão média informativa '+fmt(values['mean_pressure_MPa'])+' MPa. Não é resistência do concreto.')
        elif 'moment_Nmm' in values and values['moment_Nmm'] is not None:
            st.caption('Reação '+fmt(values['reaction_N']/KGF)+' kgf; momento excêntrico '+fmt(values['moment_Nmm']/(KGF*1000))+' kgf·m.')
    with st.expander('Condições de execução e detalhamento'):
        for item in result.get('execution_requirements',[]):st.write('• '+item)
    from .seated_variants_drawing import create_svg
    from .seated_variants_report import create_report
    try:
        svg = create_svg(c)
        st.image(svg)
        st.download_button('Baixar desenho SVG', svg, 'apoio-local.svg', 'image/svg+xml', key=PREFIX + 'svg')
    except (ValueError, TypeError, ArithmeticError, OSError) as exc:
        st.error('Desenho indisponível: ' + str(exc))
    st.download_button('Exportar projeto JSON', json.dumps(c.to_dict(), ensure_ascii=False, indent=2),
                       'apoio-local.json', 'application/json', key=PREFIX + 'json')
    try:
        report = create_report(c)
        if isinstance(report, (str, Path)):
            report = Path(report).read_bytes()
        elif hasattr(report, 'getvalue'):
            report = report.getvalue()
        st.download_button('Baixar memorial DOCX', report, 'apoio-local.docx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', key=PREFIX + 'report')
    except (ValueError, TypeError, ArithmeticError, OSError) as exc:
        st.error('Memorial indisponível: ' + str(exc))
