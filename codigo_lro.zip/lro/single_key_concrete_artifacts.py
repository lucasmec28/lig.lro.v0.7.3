from .display_precision import display_json, display_tree
"""Current-result drawings, editable Word record and portable ACI key results.

Every number and physical polygon is supplied by the evaluated component; stale
results receive no drawing/strength credit and cannot be exported as Word/JSON.
"""
from .display_precision import display_format, display_value
from io import BytesIO
import json
import math
import textwrap

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon, Rectangle
from docx.shared import Inches, Pt, RGBColor

from .single_key_concrete import MODEL, LIMITS, REF, result_is_current

LABELS = {'pass': 'ATENDE no escopo local', 'fail': 'NÃO ATENDE no escopo local',
          'pending': 'PENDENTE', 'invalid': 'DADOS/ESTADO INVÁLIDOS', 'calculated': 'EQUILÍBRIO CALCULADO', 'not_demanded': 'NÃO SOLICITADO', 'off': 'NÃO SELECIONADO'}
STATUS_LABELS = {'geometry': 'Geometria física', 'domain': 'Domínio do modelo',
                 'qualification': 'Vínculo documental', 'detail': 'Detalhe de preenchimento/ventilação',
                 'restraint': 'Restrição real das barras', 'bearing': 'Contato da chave no concreto',
                 'edges': 'Ruptura de borda', 'equilibrium': 'Estados de equilíbrio',
                 'anchors': 'Ancoragem concorrente', 'anchorage': 'Ancoragem concorrente',
                 'force_model': 'Topologia de forças e contato', 'force_states': 'Estados de forças', 'grout': 'Graute', 'arithmetic': 'Domínio numérico'}


def _n(value, scale=1.):
    if type(value) not in (int, float):
        return '—'
    if math.isinf(value):
        return '+∞' if value > 0 else '−∞'
    return f"{display_format(value / scale, '.6f')}" if math.isfinite(value) else '—'


def _data(c, result):
    d = result if isinstance(result, dict) else getattr(result, 'local_single_key_concrete', {}) or {}
    try:
        current = bool(d) and result_is_current(c, d)
    except (ValueError, TypeError, OverflowError, ZeroDivisionError):
        current = False
    if not current:
        return {'status': 'pending', 'complete': False, 'stale': True, 'geometry': {}, 'states': [],
                'edges': {'status': 'pending', 'surfaces': []},
                'reasons': ['Resultado do concreto da chave ausente ou desatualizado: recalcule para as entradas atuais.']}
    return d


def require_current_result(c, result):
    d = _data(c, result)
    if d.get('stale'):
        raise ValueError('Resultado do concreto da chave desatualizado: recalcule para as entradas atuais.')
    return d


def _json_safe(value):
    """Strict JSON retains explicit nonfinite failure indices, never a false pass."""
    if isinstance(value, dict):
        return {str(k): _json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(v) for v in value]
    if isinstance(value, float) and not math.isfinite(value):
        return 'Infinity' if value > 0 else '-Infinity' if value < 0 else 'NaN'
    return value


def json_bytes(c, result):
    d = require_current_result(c, result)
    payload = {'schema': 'lro.single_key_concrete.result.v1', 'complete': False,
               'units': {'length': 'mm', 'area': 'mm2', 'force': 'N', 'moment': 'N mm', 'stress': 'MPa'},
               'nonfinite_encoding': 'Nonfinite numbers are explicit strings: Infinity, -Infinity, NaN.',
               'scope': LIMITS, 'references': REF, 'input': c.to_dict(), 'result': d}
    return json.dumps(_json_safe(payload), ensure_ascii=False, indent=2, allow_nan=False).encode('utf-8')


def _points(value, plane='yz'):
    """Accept explicit planar pairs or physical xyz vertices, without reconstruction."""
    if not isinstance(value, (list, tuple)) or len(value) < 3:
        return []
    out = []
    for p in value:
        if not isinstance(p, (list, tuple)) or len(p) not in (2, 3):
            return []
        if not all(type(x) in (float, int) and math.isfinite(x) for x in p):
            return []
        out.append(tuple(p) if len(p) == 2 else ((p[1], p[2]) if plane == 'yz' else (p[0], p[2])))
    return out


def _polygon(ax, points, gid, **kwargs):
    if not points:
        return
    patch = Polygon(points, closed=True, **kwargs)
    patch.set_gid(gid)
    ax.add_patch(patch)


def _finite(*values):
    return all(type(v) in (int, float) and math.isfinite(v) for v in values)


def _bounds(g):
    bounds = g.get('bounds', {})
    if isinstance(bounds, dict):
        return [bounds.get(name) for name in ('xmin', 'xmax', 'ymin', 'ymax')]
    if isinstance(bounds, (list, tuple)) and len(bounds) == 4:
        # Kernel serialization follows (xmin, ymin, xmax, ymax).
        return [bounds[0], bounds[2], bounds[1], bounds[3]]
    return [None]*4


def state_lines(state):
    """Identical concise state record for UI, figure and report."""
    contact, bearing = state.get('contact', {}), state.get('bearing', {})
    rods = state.get('rods', [])
    lines = [
        f"{display_value(state.get('id', '—'))} · {display_value(LABELS.get(state.get('status'), 'PENDENTE'))} · caso {display_value(state.get('case', '—'))}; modelo {display_value(state.get('model', '—'))}.",
        f"N={display_value(_n(state.get('N'), 1000))} kN; Mtop={display_value(_n(state.get('Mtop'), 1000000.0))} kN·m; Vtop={display_value(_n(state.get('Vtop'), 1000))} kN; e={display_value(_n(state.get('e')))} mm; Mbase={display_value(_n(state.get('Mbase'), 1000000.0))} kN·m.",
        f"Pressão limite={display_value(_n(state.get('pressure_limit')))} MPa; base de pressão: {display_value(state.get('pressure_basis', '—'))}.",
        f"Contato: C={display_value(_n(contact.get('C'), 1000))} kN; lc={display_value(_n(contact.get('lc')))} mm; xC={display_value(_n(contact.get('x')))} mm; área={display_value(_n(contact.get('area')))} mm²; intervalo x={display_value(contact.get('interval', '—'))}.",
        f"Resíduos: C−ΣTi−N={display_value(_n(state.get('residual_N')))} N; CxC−ΣTixi−Mbase={display_value(_n(state.get('residual_M')))} N·mm.",
        f"Contato ACI: ψbrg={display_value(_n(bearing.get('psi_brg')))}; φVbrg={display_value(_n(bearing.get('resistance'), 1000))} kN; demanda={display_value(_n(bearing.get('demand'), 1000))} kN; índice={display_value(_n(bearing.get('ratio')))}; Abp_used_upper_bound={display_value(_n(bearing.get('Abp_used_upper_bound')))} mm².",
    ]
    if bearing.get('compression_note'):
        lines.append(str(bearing['compression_note']) + '.')
    if rods:
        lines.append('Barras reais (x, y em mm; Ti em kN): ' + '; '.join(
            f"{display_value(r.get('id', '—'))} ({display_value(_n(r.get('x')))}, {display_value(_n(r.get('y')))}): {display_value(_n(r.get('tension'), 1000))}" for r in rods) + '.')
    return lines


def image_bytes(c, result, fmt='png'):
    d = _data(c, result)
    g = d.get('geometry', {})
    eligible = c.shear_path == 'plate' and c.single_key_concrete.model == MODEL and not d.get('stale')
    surfaces = d.get('edges', {}).get('surfaces', []) if eligible else []
    with plt.rc_context({'font.family': 'DejaVu Sans', 'font.size': 8, 'svg.fonttype': 'none'}):
        fig = plt.figure(figsize=(12.2, 10.8), layout='constrained')
        grid = fig.add_gridspec(3, 6, height_ratios=[1., 1., 1.25])
        plan, section = fig.add_subplot(grid[0, :3]), fig.add_subplot(grid[0, 3:])
        edge_axes = [fig.add_subplot(grid[1, i*2:(i+1)*2]) for i in range(3)]
        notes = fig.add_subplot(grid[2, :])
        notes.axis('off')
        fig.suptitle('CHAVE ÚNICA · CONCRETO ACI 318-19 CONSERVADOR', fontsize=13, fontweight='bold')
        xmin, xmax, ymin, ymax = _bounds(g)
        b, t, h, dep, ha = (g.get(k) for k in ('b', 't', 'h', 'd', 'ha'))
        geometry_ok = eligible and _finite(xmin, xmax, ymin, ymax, b, t, h, dep, ha) and xmin < xmax and ymin < ymax and min(b,t,h,dep,ha) > 0
        if geometry_ok:
            plan.add_patch(Rectangle((xmin,ymin), xmax-xmin, ymax-ymin, fc='#f2f1eb', ec='#727b80', lw=1.1))
            physical = Rectangle((-t/2,-b/2),t,b,fc='#b6cbd9',ec='#395c73')
            physical.set_gid('single_key_concrete_plan_key')
            plan.add_patch(physical)
            for i, state in enumerate(d.get('states', [])):
                contact_points = _points(state.get('contact', {}).get('polygon'), 'xy')
                _polygon(plan, contact_points, 'single_key_concrete_contact_'+str(state.get('id',i)),
                         fc='none', ec=('#326b99' if i == 0 else '#a56625'), lw=1.2, ls='--' if i == 0 else ':')
                for rod in state.get('rods', []):
                    if _finite(rod.get('x'), rod.get('y')):
                        plan.plot(rod['x'], rod['y'], marker='+' if i == 0 else 'x', ms=5,
                                  color='#a13a33' if rod.get('tension',0)>0 else '#576e7b')
            v = d.get('top_actions', {}).get('Vtop', d.get('top_actions', {}).get('V', c.V))
            sign = -1 if v < 0 else 1
            width = xmax-xmin
            if v != 0:
                plan.annotate('',xy=(sign*min(width*.18,abs(xmin)*.65,xmax*.65),0),xytext=(0,0),arrowprops={'arrowstyle':'->','lw':1.8,'color':'#b24e20'})
            load_label = 'V=0 · sem demanda; x+ só para desenho' if v == 0 else 'V real '+('−x' if sign<0 else '+x')+'; sem carga física Vy'
            plan.annotate(load_label,xy=(0,1),xycoords='axes fraction',xytext=(0,22),
                          textcoords='offset points',ha='left',va='bottom',fontsize=8)
            plan.set_xlim(xmin-width*.08,xmax+width*.08)
            plan.set_ylim(ymin-(ymax-ymin)*.08,ymax+(ymax-ymin)*.08)
            plan.set_title('PLANTA · BLOCO REAL E CHAVE CENTRADA',pad=47)
            plan.set_xlabel('x (mm)');plan.set_ylabel('y (mm)')
            section.add_patch(Rectangle((ymin,0),ymax-ymin,ha,fc='#f2f1eb',ec='#727b80',lw=.8))
            physical_poly = _points(g.get('physical_key_polygon'), 'yz')
            effective_poly = _points(g.get('effective_key_polygon'), 'yz')
            _polygon(section,physical_poly,'single_key_concrete_physical_key',fc='#d0dfe8',ec='#395c73',lw=1.2)
            _polygon(section,effective_poly,'single_key_concrete_effective_key',fc='#f3c499',ec='#aa5921',lw=1.3,hatch='///',alpha=.85)
            section.axhline(0,color='#444',lw=1)
            section.annotate(f"Superfície do concreto: z=0\nh={display_format(h, 'g')} mm físico; d={display_format(dep, 'g')} mm efetivo\nH={display_value(_n(g.get('H')))}; g={display_value(_n(g.get('g')))}; t={display_format(t, 'g')} mm",
                             xy=(0,1),xycoords='axes fraction',xytext=(0,8),
                             textcoords='offset points',ha='left',va='bottom',fontsize=8)
            section.set_xlim(ymin-(ymax-ymin)*.06,ymax+(ymax-ymin)*.06)
            section.set_ylim(ha*1.05,-max(5,h*.1))
            section.set_title('FACE y–z · d MEDIDO A PARTIR DO CONCRETO',pad=47)
            section.set_xlabel('y (mm)');section.set_ylabel('z para baixo (mm)')
        else:
            for ax in (plan, section):
                ax.axis('off')
                ax.text(.5,.5,'Geometria resistente indisponível\npara os dados e resultado atuais.',ha='center',va='center',transform=ax.transAxes)
        for ax, index in zip(edge_axes, range(3)):
            if index >= len(surfaces):
                ax.axis('off')
                ax.text(.5,.5,'Superfície não disponível',ha='center',va='center',transform=ax.transAxes)
                continue
            s = surfaces[index]
            sid = str(s.get('id',index))
            plane = str(s.get('plane','yz')).lower().replace('–','').replace('-','')
            gross = _points(s.get('gross_polygon'),plane)
            removed = _points(s.get('removed_polygon'),plane)
            _polygon(ax,gross,'single_key_concrete_gross_'+sid,fc='#f2ceca' if s.get('status')=='fail' else '#c9ded1',ec='#9e453e' if s.get('status')=='fail' else '#306e51',lw=1.4)
            _polygon(ax,removed,'single_key_concrete_removed_'+sid,fc='white',ec='#aa5921',hatch='///',lw=1.2)
            if gross:
                xx, zz = zip(*gross); pad=max(max(xx)-min(xx),max(zz)-min(zz),1)*.06
                ax.set_xlim(min(xx)-pad,max(xx)+pad);ax.set_ylim(max(zz)+pad,min(zz)-pad)
            ax.set_xlabel(('y' if plane=='yz' else 'x')+' (mm)');ax.set_ylabel('z (mm)')
            ax.set_title(f"{display_value(sid)} · face {display_value(s.get('face', '—'))}\nAVc={display_value(_n(s.get('AVc')))} mm²",fontsize=9)
            ax.text(.5,-.24,f"ca1={display_value(_n(s.get('ca1')))} mm; ψh={display_value(_n(s.get('psi_h_used')))}\nφVcb={display_value(_n(s.get('resistance'), 1000))} kN; η={display_value(_n(s.get('ratio')))}\nRecorte inferior: {display_value(s.get('clipped_bottom', False))}; lateral: {display_value(s.get('clipped_sides', False))}",ha='center',va='top',transform=ax.transAxes,fontsize=7.5)
        for ax in [plan,section]+edge_axes:
            ax.set_aspect('equal',adjustable='box')
            ax.tick_params(labelsize=7)
            ax.grid(alpha=.15)
        lines = [
            'Componente: '+LABELS.get(d.get('status'),'PENDENTE')+'. Chave, ligação, ancoragem e base completas: PENDENTES.',
            'Política: ca1 físico; ψh=1; sem aumento de membro fino/estreito. AVc não limitado a AVco.',
            'Bordas paralelas: construção virtual de chumbador único ACI 17.11.3.2 ×2, sem criar Vy ou V/4.',
            'Sob recorte, não se alega área sempre menor que chave finita; não se subtrai t×d na construção pontual.',
            'Área colorida: projeção bruta; hachura branca: retângulo efetivo removido. Área líquida = AVc.',
            'Planta: contato NBR tracejado azul; contato ACI pontilhado ocre; barras +/× por estado, sem somar estados.',
            'Compressão: '+str(c.single_key_concrete.compression_policy)+'. N aplicado preservado; nenhum uso de C como Pu.',
        ]
        for state in d.get('states',[]):
            lines += [state_lines(state)[i] for i in (0,1,2,4,5)]
        if d.get('stale') or not geometry_ok:
            lines += [str(reason) for reason in d.get('reasons',[])][:3]
        wrapped = [part for line in lines for part in textwrap.wrap(line,155)]
        step = min(.074,.98/max(len(wrapped),1))
        for i, line in enumerate(wrapped):
            notes.text(.005,.98-i*step,line,va='top',fontsize=8,transform=notes.transAxes)
        out = BytesIO()
        fig.savefig(out,format=fmt,dpi=150)
        plt.close(fig)
        return out.getvalue()


def append_report(doc, c, result):
    if c.shear_path != 'plate' or c.single_key_concrete.model == 'off':
        return
    from .report import table as base_table, _math, group, sub
    def table(doc, headers, rows, widths):
        # Keep these short (at most ten-row) numerical tables together.
        tab = base_table(doc, headers, rows, widths)
        for row in tab.rows[:-1]:
            for cell in row.cells:
                for para in cell.paragraphs:
                    para.paragraph_format.keep_with_next = True
        return tab
    d, u = require_current_result(c, result), c.single_key_concrete
    title=doc.add_paragraph('Concreto da chave única · ACI 318-19 conservador',style='Heading 1')
    title.paragraph_format.page_break_before=True
    doc.add_paragraph('Componente complementar: '+LABELS.get(d.get('status'),'PENDENTE')+'. Chave, ligação, ancoragem e base completas: PENDENTES.')
    doc.add_picture(BytesIO(image_bytes(c,result)),width=Inches(6.95))
    for name,status in d.get('statuses',{}).items():
        doc.add_paragraph(STATUS_LABELS.get(name,name.replace('_',' '))+': '+LABELS.get(status,'PENDENTE')+'.')
    for reason in d.get('reasons',[]): doc.add_paragraph(str(reason))
    doc.add_paragraph(f"Restrição real das barras: {display_value(u.rod_restraint)}; referência: {display_value(u.restraint_ref or 'NÃO INFORMADA')}. A solda perimetral da arruela não comprova que a barra é soldada ou rigidamente ligada. Barras soldadas exigem interação concorrente separada; não se atribui Vi=0 ou V/4.")
    doc.add_paragraph(f"Preenchimento/consolidação: {display_value(u.filled_detail_ref or 'NÃO INFORMADO')}; confirmado={display_value(u.filled_detail_confirmed)}. Ventilação: {display_value(u.vent_detail_ref or 'NÃO INFORMADA')}; confirmado={display_value(u.vents_confirmed)}. Exigência do modelo: pelo menos um furo de 25,4 mm junto a cada face longa, graute fluido não retrátil e detalhe integralmente preenchido; efeitos dos furos na placa/contato qualificados separadamente.")
    doc.add_paragraph(f"Topologia de forças/contato: {display_value(u.force_model_ref or 'NÃO INFORMADA')}; confirmado={display_value(u.force_model_confirmed)}. Política de compressão: {display_value(u.compression_policy)}. Vínculo: {display_value(u.qualification_signature or 'PENDENTE')}. Assinatura do resultado: {display_value(d.get('source_signature', '—'))}.")
    if any(rod.get('tension',0)>0 for state in d.get('states',[]) for rod in state.get('rods',[])):
        cc=c.concrete_components
        table(doc,['Dado compartilhado de barras tracionadas','Entrada atual'],[
            ('Área efetiva rosqueada Ase,N',_n(cc.area_tension)+' mm²'),
            ('Fonte informada da área efetiva',cc.steel_area_ref or 'NÃO INFORMADA'),
            ('Verificação da fonte pelo aplicativo','Não realizada; referência fornecida pelo responsável técnico'),
        ],[3.6,3.35])
    doc.add_paragraph('Geometria física e política resistente',style='Heading 2')
    g=d.get('geometry',{})
    table(doc,['Grandeza','Valor','Unidade'],[(name,_n(g.get(name)),'mm²' if name=='Aef' else 'mm') for name in ('b','H','g','h','d','t','Aef','ha')],[3.0,3.1,.85])
    doc.add_paragraph('Limites reais do bloco (xmin, xmax, ymin, ymax): '+str(display_tree(_bounds(g)))+' mm. Todas as bordas informadas são livres. Polígono físico da chave: '+display_json(g.get('physical_key_polygon',[]),ensure_ascii=False)+'; polígono efetivo: '+display_json(g.get('effective_key_polygon',[]),ensure_ascii=False)+'. Coordenadas em mm, z=0 na superfície do concreto.')
    doc.add_paragraph('h=H−g; d=min(h,2t); Aef=bd. O graute não entra na área ACI. Usa-se f′c=fck informado sem γc, concreto normal fissurado, λa=ψc,V=1 e φ=0,65. A altura física h é mantida para implantação e razão de ancoragem. Estado NBR e suas ações de desenvolvimento de solda permanecem inalterados.')
    _math(doc,group(sub('R','brg'),' = 0,65 × 1,7 ',sub('f′','c'),' b d ',sub('ψ','brg'),';   demanda = |V|'))
    doc.add_paragraph('Pu=N original, positivo em compressão. N=0: ψbrg=1. N<0: ψbrg=1+N/(n Nsa), com n igual ao número real de Ti>0 neste mesmo estado e Nsa=Ase,N min(futa;1,9fya;125000 psi), nominal, sem φ e sem γ NBR. ψbrg≤0 com cortante positivo falha. N>0: política no_gain usa ψbrg=1, sem crédito de aumento por compressão; política contact_upper_bound usa min[2;1+4N/(Abp f′c)] somente para a faixa de contato qualificada como limite superior da área real. Nenhuma política qualifica pressão/topologia incorreta.')
    doc.add_paragraph('Ruptura de borda · três superfícies candidatas',style='Heading 2')
    doc.add_paragraph('Face normal carregada: ca1 medido da face física da chave ao bordo em x no sentido do V real. Bordas paralelas: ca1 do centro da chave ao bordo em y, construção virtual pontual e fator 2; ambas recebem a demanda |V| como superfícies alternativas, sem nova carga Vy. AVco=4,5ca1²; Vb=9√f′c,psi ca1,in^1,5 lbf. φVcb=0,65(AVc/AVco)ψedψcψhVb, com fator 2 somente nas bordas paralelas.')
    doc.add_paragraph('A construção paralela é autorizada diretamente por ACI 17.11.3.2, 17.7.2.1(c) e 17.7.2.1.1, com analogia de chumbador único em R17.11.3.2; sua origem virtual é o centro da chave. Não é uma alegação de área sempre inferior à projeção líquida de uma chave finita. Sob recorte total, a construção pontual não sofre subtração de t×d. Alterar para uma chave finita na direção paralela exige outro contrato geométrico.')
    doc.add_paragraph('AVc não é limitado a AVco. Recortam-se as projeções nas bordas reais e no fundo. Usa-se ca1 físico e ψh_used=1; omitem-se os aumentos positivos de espessura e de membro estreito. A falha significa falha deste modelo conservador, sem impedir um projeto específico de armadura ou refinamento da superfície.')
    for s in d.get('edges',{}).get('surfaces',[]):
        doc.add_paragraph(f"Superfície {display_value(s.get('id', '—'))} · face {display_value(s.get('face', '—'))} · plano {display_value(s.get('plane', '—'))}",style='Heading 2')
        entries=[('ca1',s.get('ca1'),'mm'),('AVc',s.get('AVc'),'mm²'),('AVco',s.get('AVco'),'mm²'),('ψed',s.get('psi_ed'),'—'),('ψh_used',s.get('psi_h_used'),'—'),('Vb',s.get('Vb'),'N'),('Resistência φVcb',s.get('resistance'),'N'),('Demanda |V|',s.get('demand'),'N'),('Índice',s.get('ratio'),'—')]
        table(doc,['Grandeza','Valor','Unidade'],[(k,_n(v),unit) for k,v,unit in entries],[3.0,3.1,.85])
        doc.add_paragraph(f"Recorte inferior: {display_value(s.get('clipped_bottom', False))}; recortes laterais: {display_value(s.get('clipped_sides', False))}. Polígono bruto: "+display_json(s.get('gross_polygon',[]),ensure_ascii=False)+'; polígono removido: '+display_json(s.get('removed_polygon',[]),ensure_ascii=False)+'.')
    doc.add_paragraph('Superfície governante: '+display_json(_json_safe(d.get('edges',{}).get('governing')),ensure_ascii=False)+'.')
    doc.add_paragraph('Estados de forças independentes',style='Heading 2')
    doc.add_paragraph('Ações originais no topo: '+display_json(_json_safe(d.get('top_actions',{})),ensure_ascii=False)+'. Estado nativo preservado: '+display_json(_json_safe(d.get('native_actions',{})),ensure_ascii=False)+'.')
    _math(doc,group(sub('e','NBR'),' = ',sub('t','p'),' + g + h/2;   ',sub('e','ACI'),' = ',sub('t','p'),' + g + d/2;   ',sub('M','base'),' = ',sub('M','top'),' + V e'))
    doc.add_paragraph('São estados alternativos completos, nunca mistura de contato, tensões ou contagem de barras de estados diferentes. A solda pilar–placa conserva N/M/V do topo. Vw/Mw prescritos não entram no transporte nem substituem V real. Estado ACI: pressão 0,65×0,85f′c e A2/A1=1; nenhum confinamento A2/A1=4 é inferido.')
    for state in d.get('states',[]):
        doc.add_paragraph('Estado '+str(state.get('id','—')),style='Heading 2')
        for line in state_lines(state): doc.add_paragraph(line)
        for reason in state.get('reasons',[]): doc.add_paragraph(str(reason))
        for reason in state.get('bearing',{}).get('reasons',[]): doc.add_paragraph(str(reason))
        contact=state.get('contact',{})
        doc.add_paragraph('Polígono do contato físico (mm): '+display_json(contact.get('polygon',[]),ensure_ascii=False)+'.')
        rods=state.get('rods',[])
        if rods:
            table(doc,['Barra','x (mm)','y (mm)','Ti (kN)'],[(str(r.get('id','—')),_n(r.get('x')),_n(r.get('y')),_n(r.get('tension'),1000)) for r in rods],[1.,1.8,1.8,2.35])
        anchor=state.get('anchor_modes',{})
        doc.add_paragraph('Ancoragem concorrente: '+LABELS.get(anchor.get('status'),'PENDENTE')+'. Modos: '+display_json({name: mode.get('status','pending') for name,mode in anchor.get('modes',{}).items()},ensure_ascii=False)+'.')
        for reason in anchor.get('reasons',[]): doc.add_paragraph(str(reason))
        for check in anchor.get('checks',[]):
            doc.add_paragraph(str(check.get('label',check.get('id','Modo')))+': demanda='+_n(check.get('demand'))+'; resistência='+_n(check.get('resistance'))+'; índice='+_n(check.get('ratio'))+'; barras='+str(check.get('ids',[]))+'; método='+str(check.get('method','—'))+'.')
    doc.add_paragraph('Se qualquer barra real estiver em tração: hef≥2,5h e hef≥2,5csl; h é físico e csl é a distância até a fileira efetivamente tracionada ao longo de V. O componente da chave não cria pryout com diâmetro de chumbador. Tipo 1 usa somente sua topologia uniforme declarada; Tipo 2 mantém C1/C2/T1/T2 e seu l0, sem fallback de alto momento do Tipo 1. Uma pendência de equilíbrio suplementar não elimina resistências locais independentes disponíveis.')
    doc.add_paragraph(LIMITS)
    doc.add_paragraph('Referências: '+REF+'. Componente conservador ACI-based; não inclui todas as opções positivas da norma. Não é aprovação de chave, ligação, ancoragem, bloco armado NBR 6118, fundação/solo ou base completa.')


def docx_bytes(c, result):
    """Standalone local record, including when global equilibrium is unavailable."""
    from docx import Document
    require_current_result(c, result)
    doc = Document()
    section = doc.sections[0]
    section.page_width, section.page_height = Inches(8.27), Inches(11.69)
    section.top_margin = section.bottom_margin = Inches(.6)
    section.left_margin = section.right_margin = Inches(.65)
    for name in ('Normal', 'Heading 1', 'Heading 2'):
        style = doc.styles[name]
        style.font.name = 'Arial'
        style.font.color.rgb = RGBColor(0, 0, 0)
    doc.styles['Normal'].font.size = Pt(9.5)
    doc.styles['Normal'].paragraph_format.space_after = Pt(4)
    doc.styles['Heading 1'].font.size = Pt(12)
    doc.styles['Heading 2'].font.size = Pt(10)
    doc.core_properties.title = 'Concreto da chave única ACI 318-19 conservador'
    doc.core_properties.subject = 'Componente local; não aprova chave, ancoragem ou base completas'
    append_report(doc, c, result)
    stream = BytesIO()
    doc.save(stream)
    return stream.getvalue()
