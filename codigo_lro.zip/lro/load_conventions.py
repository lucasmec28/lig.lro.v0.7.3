"""Read-only load legends and reference schematics; never engineering inputs.

The family-specific signs mirror the existing kernels. The diagram deliberately
shows the POSITIVE reference, not the actual case, its minima or its reactions.
No domain, numerical tolerance, conversion, persistence or approval lives here.
"""
from .display_precision import display_format, display_value
from dataclasses import dataclass
from html import escape
import math


@dataclass(frozen=True)
class Convention:
    axial_domain: str
    positive_axial: str
    actions: tuple[str, ...]
    scheme: str
    member: str
    note: str


CONVENTIONS = {
    'single_plate': Convention('tension', 'tension', ('N', 'V'), 'beam', 'Single plate',
        'V para baixo é a referência ilustrada; o cálculo existente usa |V| e envelope. Sem momento externo aplicado.'),
    'column_web_double_cover': Convention('both', 'tension', ('N', 'V'), 'beam', 'Alma de coluna · duas talas',
        'V positivo para baixo. O momento local V·e é derivado, não uma entrada adicional.'),
    'end_plate_pinned': Convention('both', 'tension', ('N', 'V'), 'beam', 'End plate · rotulada',
        'V positivo para baixo na referência; resistências ao cortante usam seu módulo. Sem momento externo aplicado.'),
    'end_plate_moment': Convention('both', 'tension', ('N', 'V', 'M'), 'beam', 'End plate · engastada',
        'M positivo horário: tração na mesa superior. V para baixo na referência; cortante resistente em módulo. Permanecem as restrições de flexão dominante e da variante.'),
    'base_plate_fixed': Convention('both', 'compression', ('N', 'V', 'M'), 'base', 'Base engastada · face superior',
        'N positivo comprime o pilar; V positivo em +x, no plano da alma. M positivo horário comprime o lado +x.'),
    'base_plate_pinned': Convention('both', 'compression', ('N', 'V'), 'base', 'Base rotulada · face superior',
        'N positivo comprime o pilar; V positivo em +x, no plano da alma. Sem M aplicado; a excentricidade local da chave continua calculada.'),
    'w_splice_m004': Convention('tension', 'tension', ('N',), 'axial_w', 'Emenda W · M004',
        'Tração axial somente. M, V e torção adicionais continuam fora do domínio.'),
    'w_splice_conventional': Convention('both', 'tension', ('N', 'V', 'M'), 'splice', 'Emenda W convencional',
        'Face +x (direita): N positivo para a direita, V positivo para cima e M positivo anti-horário, com tração na mesa inferior.'),
    'double_angle_r016': Convention('none', 'tension', ('V',), 'beam', 'Duas cantoneiras · R016',
        'V positivo para baixo na viga apoiada. Apenas cortante externo; N, M e torção não nulos continuam fora do domínio.'),
    'welded_double_angle_r015': Convention('none', 'tension', ('V',), 'beam', 'Duas cantoneiras · R015',
        'V positivo para baixo na viga apoiada. O momento excêntrico das soldas é derivado; não é M aplicado.'),
    'coped_double_angle_r017': Convention('none', 'tension', ('V',), 'beam', 'Viga recortada · R017',
        'V positivo para baixo na viga apoiada. Eixos dos furos do apoio são distintos; N, M e torção externos não nulos continuam fora do domínio.'),
    'axial_double_angle_bolted': Convention('tension', 'tension', ('N',), 'axial_angle', 'Par 2L parafusado · N total',
        'N positivo é a tração total no eixo nominal dos parafusos. A partilha por L é interna; não há outra entrada de força.'),
    'axial_single_angle_bolted': Convention('tension', 'tension', ('N',), 'axial_angle', 'Uma L parafusada',
        'N positivo é tração no eixo nominal. As excentricidades físicas omitidas pelo modelo limitado não criam entradas M ou V.'),
    'welded_w_splice': Convention('both', 'tension', ('N', 'V', 'M'), 'splice', 'Emenda W soldada · face +x de A',
        'Face +x do membro A: N em +x, V em −y; M positivo traciona +y. Os eixos locais acompanham a orientação viga/pilar. Vale para todas as combinações.'),
    'welded_angle_gusset': Convention('tension', 'tension', ('N',), 'gusset', 'Uma L soldada · plano local',
        'N positivo acompanha a cantoneira em θ a partir de +s do W. +n é normal à mesa. V paralelo, N normal e M da raiz são derivados, não entradas adicionais.'),
    'welded_double_angle_gusset': Convention('conditional_compression', 'tension', ('N',), 'gusset', 'Par 2L-T soldado · N total',
        'N positivo total acompanha o par em θ a partir de +s do W. +n é normal à mesa. A partilha por L e as ações da raiz são derivadas, não entradas adicionais.'),
    'welded_opposed_angle_gusset': Convention('tension', 'tension', ('N',), 'gusset', 'Par 2L opostas soldado · N total',
        'N positivo total acompanha o par em θ a partir de +s do W. Quatro linhas distintas; partilha N/2 e ações reais da raiz derivadas. Idealização estática por L, sem declarar cancelamento dos binários locais.'),
    'bolted_angle_gusset': Convention('tension', 'tension', ('N',), 'gusset', '1L / 2L-T parafusada · ligação completa',
        'N positivo acompanha a linha nominal dos parafusos em θ a partir de +s do W. N total na chapa, raiz dupla e W. Partilha por L/plano depende da disposição; Nnormal, Vparalelo e M da raiz são derivados.'),
    'corner_gusset': Convention('conditional_compression', 'tension', ('N', 'Fx', 'Fy', 'M'), 'corner', 'Canto viga–pilar · 2L-T soldadas',
        'N positivo traciona o par de cantoneiras a partir da horizontal +x. Nos cortes D e U: Fx em +x, Fy em +y e M anti-horário; ações externas no corpo livre do nó. Corte L derivado. Ações completas já incluem a diagonal.'),
}

# Arrangement-specific legends do not add another top-level route.
VARIANT_CONVENTIONS = {
    'single_plate_full_depth': Convention('tension', 'tension', ('N', 'V'), 'beam', 'Single plate entre mesas',
        'V positivo para baixo. Nas soldas de três bordas: Fx=N, Fy=−V e M0=xP·Fy−yP·Fx, com sinais preservados. Apenas os componentes legados e as referências retangulares mantêm suas envoltórias locais. Sem momento externo aplicado.'),
    'bolted_opposed_angle_gusset': Convention('tension', 'tension', ('N',), 'gusset', 'Par 2L opostas parafusado · N total',
        'N positivo total acompanha o par em θ a partir de +s do W. Duas linhas separadas de parafusos em corte simples; N/2 por L e N integral na chapa única, raiz dupla e W. Ações da raiz derivadas; binários locais idealizados pelo modelo estático por L, sem afirmar cancelamento.'),
}


def _convention(family_id):
    return VARIANT_CONVENTIONS[family_id] if family_id in VARIANT_CONVENTIONS else CONVENTIONS[family_id]


REFERENCE_NOTE = ('As setas mostram a convenção positiva, sem valores; não representam o caso digitado. '
                  'Esta legenda não indica atendimento nem amplia o domínio da família.')


def _finite(value):
    try:
        return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)
    except (OverflowError, ValueError):
        return False


def axial_nature(family_id, value):
    """Exact sign only: no rounding, abs(), clamping or engineering epsilon."""
    c = _convention(family_id)
    if not _finite(value):
        return 'Entrada axial inválida'
    if value == 0:
        return 'Sem axial'
    tension = (value > 0) == (c.positive_axial == 'tension')
    label = 'Tração' if tension else 'Compressão'
    if c.axial_domain=='conditional_compression' and not tension:
        return label+' · domínio local condicionado ao adaptador e detalhe físico'
    if c.axial_domain == 'none' or (c.axial_domain == 'tension' and not tension):
        label += ' · fora do domínio desta família'
    return label


def sign_legend(family_id):
    c = _convention(family_id)
    if c.axial_domain == 'none':
        return 'Família de cortante: axial deve ser nulo. Valores axiais são preservados e continuam sujeitos ao bloqueio do modelo.'
    meanings = ('compressão', 'tração') if c.positive_axial == 'compression' else ('tração', 'compressão')
    text = 'N positivo: ' + meanings[0] + '. N negativo: ' + meanings[1] + '. N nulo: sem axial.'
    if c.axial_domain == 'tension':
        text += ' Compressão permanece fora do domínio.'
    elif c.axial_domain=='conditional_compression':
        text += ' Compressão local 2L-T depende do adaptador e das contenções físicas; 1L permanece não qualificada.'
    return text


def reference_description(family_id, *, orientation='beam'):
    c = _convention(family_id)
    column = c.scheme == 'splice' and family_id == 'welded_w_splice' and orientation == 'column'
    direction = ('N para cima, V para a esquerda, M anti-horário.' if column else
                 'N para a direita, V para cima, M anti-horário.' if c.scheme == 'splice' else
                 'N para baixo, V para a direita; M horário quando aplicável.' if c.scheme == 'base' else
                 'N acompanha o eixo da cantoneira; eixos locais s e n.' if c.scheme == 'gusset' else
                 'V para baixo na viga apoiada.' if c.axial_domain == 'none' else
                 'N para a direita; V para baixo quando aplicável; M horário quando aplicável.')
    if c.scheme == 'corner':
        direction = 'N no eixo da diagonal; Fx à direita, Fy para cima, M anti-horário em cada corte declarado.'
    return direction + ' Somente ' + ', '.join(c.actions) + ' aplicáveis. ' + c.note + ' ' + REFERENCE_NOTE


def convention_svg(family_id, *, orientation='beam', theta_deg=45.):
    """Value-free local reference. Input force signs never alter its arrows."""
    if family_id == 'corner_gusset':
        from dataclasses import replace
        from .corner_gusset import CornerGusset
        from .corner_gusset_drawing import effort_convention_svg
        return effort_convention_svg(replace(CornerGusset(), phi_deg=theta_deg))
    c = _convention(family_id)
    column = c.scheme == 'splice' and family_id == 'welded_w_splice' and orientation == 'column'
    title = 'Convenção positiva dos esforços · ' + c.member
    desc = reference_description(family_id, orientation=orientation)
    out = [f'<svg xmlns="http://www.w3.org/2000/svg" width="480" height="252" viewBox="0 0 480 252" role="img" aria-label="{escape(title + ". " + desc, quote=True)}">',
           '<title>' + escape(title) + '</title><desc>' + escape(desc) + '</desc>',
           '<defs><marker id="load-tip" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="#176c89"/></marker><marker id="axis-tip" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto"><path d="M 0 0 L 10 5 L 0 10 z" fill="#586878"/></marker></defs>',
           '<rect x="1" y="1" width="478" height="250" rx="12" fill="#f7fafc" stroke="#cbd9e2"/>',
           '<g font-family="DejaVu Sans, Arial, sans-serif" fill="#223b4c">']
    def text(x, y, value, size=16, anchor='start', color='#223b4c'):
        out.append(f'<text x="{x:g}" y="{y:g}" font-size="{size}" text-anchor="{anchor}" fill="{color}">{escape(value)}</text>')
    def line(x1, y1, x2, y2, *, kind='member', label=None):
        if kind == 'load':
            attrs = 'stroke="#176c89" stroke-width="3" marker-end="url(#load-tip)"'
        elif kind == 'axis':
            attrs = 'stroke="#586878" stroke-width="1.5" stroke-dasharray="4 3" marker-end="url(#axis-tip)"'
        elif kind == 'cut':
            attrs = 'stroke="#586878" stroke-width="1.5" stroke-dasharray="4 3"'
        else:
            attrs = 'stroke="#617c8e" stroke-width="4"'
        gid = f' id="reference_{display_value(label)}"' if label else ''
        out.append(f'<line{gid} x1="{x1:g}" y1="{y1:g}" x2="{x2:g}" y2="{y2:g}" {attrs}/>')
    def rect(x,y,w,h):
        out.append(f'<rect x="{x:g}" y="{y:g}" width="{w:g}" height="{h:g}" rx="2" fill="#e1eaf0" stroke="#617c8e" stroke-width="2"/>')
    def moment(x,y,clockwise):
        start = -135 if clockwise else -45
        finish = start + (270 if clockwise else -270)
        points = [(x+29*math.cos(math.radians(a)), y+29*math.sin(math.radians(a)))
                  for a in [start+(finish-start)*i/36 for i in range(37)]]
        points_text = ' '.join(f'{px:.3f},{py:.3f}' for px,py in points)
        out.append(f'<polyline id="reference_M" data-direction="{"clockwise" if clockwise else "counterclockwise"}" points="{points_text}" fill="none" stroke="#176c89" stroke-width="3" marker-end="url(#load-tip)"/>')
        text(x,y+6,'M+',17,'middle','#176c89')
    text(20,29,c.member,17)
    if c.scheme == 'base':
        rect(168,79,56,109); rect(113,188,167,12)
        line(92,213,303,213); line(117,214,106,229); line(156,214,145,229); line(195,214,184,229); line(234,214,223,229); line(273,214,262,229)
        line(196,46,196,109,kind='load',label='N'); text(211,67,'N+',18,color='#176c89')
        line(231,145,358,145,kind='load',label='V'); text(362,151,'V+',18,color='#176c89')
        line(318,214,420,214,kind='axis'); text(423,220,'+x',15)
        if 'M' in c.actions: moment(368,78,True)
        text(21,118,'Pilar',15)
    elif c.scheme == 'splice':
        if column:
            rect(198,132,44,84); line(188,132,252,132,kind='cut');
            line(220,121,220,53,kind='load',label='N'); text(236,62,'N+',18,color='#176c89')
            line(194,115,99,115,kind='load',label='V'); text(101,99,'V+',18,color='#176c89')
            line(289,210,289,161,kind='axis'); text(299,169,'+x',15)
            line(293,211,350,211,kind='axis'); text(355,218,'+y',15)
            moment(381,92,False); text(20,239,'Pilar · face +x do membro A',15)
        else:
            rect(69,117,169,36); line(238,90,238,177,kind='cut')
            line(266,135,384,135,kind='load',label='N'); text(390,142,'N+',18,color='#176c89')
            line(272,112,272,49,kind='load',label='V'); text(289,63,'V+',18,color='#176c89')
            if family_id == 'w_splice_conventional':
                line(72,218,163,218,kind='axis'); text(169,224,'+x',15)
                line(72,216,72,174,kind='axis'); text(83,184,'+y',15)
            else:
                line(72,192,163,192,kind='axis'); text(169,198,'+x',15)
                line(72,195,72,232,kind='axis'); text(83,233,'+y',15)
            moment(377,75,False); text(193,238,'Face +x · corte à direita',15)
    elif c.scheme == 'gusset':
        rect(163,114,179,84); rect(121,202,270,12)
        line(51,197,116,197,kind='axis'); text(112,182,'+s',16)
        line(51,197,51,120,kind='axis'); text(63,126,'+n',16)
        text(124,237,'Mesa W · eixo longitudinal +s',15)
        if _finite(theta_deg) and 0 <= theta_deg <= 180:
            ux,uy=math.cos(math.radians(theta_deg)),-math.sin(math.radians(theta_deg))
            x,y=259,162
            line(x-37*ux,y-37*uy,x+43*ux,y+43*uy)
            line(x+52*ux,y+52*uy,x+106*ux,y+106*uy,kind='load',label='N')
            tx,ty=x+109*ux+25*(-uy),y+109*uy+25*ux
            text(tx,ty,'N+',18,'end' if ux < -.85 else 'middle','#176c89')
        else:
            text(254,153,'Confira o ângulo θ',16,'middle')
    else:
        if c.scheme.startswith('axial'):
            rect(78,112,140,42); rect(178,119,137,28)
            if c.scheme == 'axial_w':
                line(78,110,216,110); line(78,156,216,156)
            else:
                for bx in (190,214,238): out.append(f'<circle cx="{bx}" cy="133" r="5" fill="#617c8e"/>')
            line(325,133,405,133,kind='load',label='N'); text(379,112,'N+',18,color='#176c89')
            text(84,211,'Eixo axial nominal da ligação',16)
        else:
            rect(62,63,29,124); rect(91,117,194,32); rect(95,101,13,64)
            if family_id == 'coped_double_angle_r017':
                out.append('<path d="M 111 117 H 143 V 108 H 285 M 111 149 H 143 V 158 H 285" fill="none" stroke="#617c8e" stroke-width="2"/>')
            if 'N' in c.actions:
                line(296,133,406,133,kind='load',label='N'); text(379,113,'N+',18,color='#176c89')
            if 'V' in c.actions:
                line(258,159,258,220,kind='load',label='V'); text(275,206,'V+',18,color='#176c89')
            if 'M' in c.actions: moment(358,72,True)
            text(109,84,'Viga apoiada',16); text(20,235,'Vista lateral · plano da alma',15)
    out.append('</g></svg>')
    return ''.join(out)


def render_axial_state(st, family_id, axial):
    st.markdown('**Entrada axial: ' + axial_nature(family_id, axial) + '**')
    st.caption(sign_legend(family_id))


def render(st, family_id, axial, *, orientation='beam', theta_deg=45.):
    """Called into an existing UI placeholder with the canonical model value."""
    render_axial_state(st, family_id, axial)
    with st.expander('Convenção positiva dos esforços', expanded=True):
        st.image(convention_svg(family_id, orientation=orientation, theta_deg=theta_deg), width='stretch',
                 alt=_convention(family_id).member + '. ' + reference_description(family_id, orientation=orientation))
        st.caption(_convention(family_id).note)
        st.caption(REFERENCE_NOTE)
