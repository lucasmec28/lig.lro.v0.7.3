"""Ligação à alma de coluna com nervura, quatro horizontais e duas talas.

Modelo local por componentes. O equilíbrio é explícito; a validação do nó
tridimensional e da capacidade de rotação permanece uma pendência identificada.
Unidades internas: N, mm, MPa. Nenhuma majoração adicional de ações.
"""
from dataclasses import dataclass, asdict, replace
import math
from .models import Profile, Check, Issue, Result, STEELS, BOLTS, DIAMETERS, profiles, INTERFERENCE_ASSUMPTION, finite_real
from .package_identity import PACKAGE_ID
from .engine import bolt_shear, plate_ltb
from .local_checks import elastic_group, grip_factor
from .double_cover_weld import elastic_throat_group

E=200000.;G1=1.1;G2=1.35
NBR='ABNT NBR 8800:2024, versão corrigida 2025'
INITIAL_PRESET='W360 → HP250 · grupo interno · folga de 10 mm'
ROTATION_NOTE='Qualificação local não demonstrada: rotação/flexibilidade da emenda com duas talas e do conjunto soldado, incluindo a aplicabilidade do limite db/2 + 1,6 mm e a rótula nominal no meio da folga.'
STABILITY_NOTE='Qualificação local não demonstrada: estabilidade acoplada e compatibilidade da distribuição de forças no conjunto nervura escalonada–horizontais frontais–coluna, incluindo a contenção lateral efetiva.'
ASSEMBLY_NOTE=ROTATION_NOTE+' '+STABILITY_NOTE
INTERNAL_FIN_NOTE='Qualificação local pendente: nervura interna perfurada. Falta verificar a transferência pelos ligamentos laterais e pontes dos furos até as três bordas soldadas, a resistência da membrana, a estabilidade local e os receptores. As faixas legadas de aba livre/trecho interno sem furos e suas verificações de transferência não se aplicam a esta geometria. Parafusos, talas e alma da viga continuam verificados; o critério local direcional de contato/rasgamento usa o contorno e os furos reais; direções que encontram solda conservam apenas o teto necessário de contato, com transferência pendente. As soldas nas três bordas e o critério suplementar de escoamento local da nervura são calculados separadamente sob a hipótese de chapa e apoios rígidos no plano, com rigidez elástica uniforme por área de garganta. Isso não demonstra a compatibilidade real nem qualifica a transferência integral pela nervura ou pelos receptores.'
INTERNAL_WELD_NOTE='Grupo elástico de gargantas: chapa e apoios rígidos no plano; mesma rigidez elástica isotrópica por área de garganta, dois filetes simétricos por borda e alívios sem solda. Ações transmitidas da nervura aos receptores; reações sobre a nervura têm sinal oposto. Sem crédito das chapas opostas nem de solda direta viga–coluna. Membrana e estabilidade da nervura, rotação e capacidade dos receptores permanecem pendentes.'

COMPRESSION_NOTE='A Errata 1:2025 corrige o item 6.5.4 para Le/r > 25. Esta implementação conserva, por escolha conservadora explícita, a curva χ em todos os comprimentos, inclusive nas barras curtas; não adota o patamar permitido para Le/r ≤ 25.'


class DoubleCoverCheck(Check):
    """Presentation policy confined to the two-cover family."""
    @property
    def numerically_valid(self):
        return (finite_real(self.demand) and finite_real(self.resistance)
                and self.resistance>0 and math.isfinite(self.ratio))

    @property
    def applicable(self):
        # Each row carries its own complete demand, including local moments.
        # A zero net-tension/shear interaction in pure compression is inactive;
        # the separate compression/stability branch remains active.
        return not (self.numerically_valid and self.demand==0)

    @property
    def outcome(self):
        if not self.numerically_valid:return 'Falha numérica · sem conclusão'
        if not self.applicable:return 'N/A · sem solicitação deste mecanismo'
        return 'Atende' if self.passed else 'Não atende'


@dataclass
class InternalFinBearingCheck(DoubleCoverCheck):
    """A directional-model failure below the ceiling requires local review."""
    necessary_resistance: float=0.
    necessary_demand: float=0.
    directional_pending: bool=False

    @property
    def numerically_valid(self):
        return (super().numerically_valid and finite_real(self.necessary_resistance)
                and self.necessary_resistance>0 and finite_real(self.necessary_demand))

    @property
    def proven_failure(self):
        return self.numerically_valid and self.necessary_demand/self.necessary_resistance>1+1e-10

    @property
    def model_only_failure(self):
        return self.numerically_valid and not self.passed and not self.proven_failure

    @property
    def outcome(self):
        if not self.numerically_valid:return 'Falha numérica · sem conclusão'
        if not self.applicable:return 'N/A · sem solicitação deste mecanismo'
        if self.proven_failure:return 'Não atende · teto necessário excedido'
        if self.model_only_failure:return 'Critério direcional local não atendido'
        if self.directional_pending:return 'Limites locais não excedidos · transferência pendente'
        return 'Atende ao critério direcional local'


class InternalElasticWeldCheck(DoubleCoverCheck):
    """Never describe the assumed rigid-part distribution as unconditional."""
    @property
    def outcome(self):
        if not self.numerically_valid:return 'Falha numérica · sem conclusão'
        if not self.applicable:return 'N/A · sem solicitação deste mecanismo'
        return 'Atende à hipótese elástica' if self.passed else 'Não atende à hipótese elástica'


def section_envelopes(rows):
    """Summary only: all original physical branch IDs/calculations stay in rows."""
    groups={'dc_bolt_':'Parafusos — envoltória dos dois grupos',
            'dc_weld_internal_':'Soldas da nervura — envoltória das hipóteses elásticas',
            'dc_weld_receiver_':'Soldas horizontais–coluna — envoltória das hipóteses elásticas',
            'dc_base_internal_':'Nervura junto às soldas — envoltória do critério local elástico'}
    for cut,label in [('cover','Duas talas'),('fin','Nervura — aba livre'),('root','Nervura — trecho interno'),('beam','Alma da viga — faixa conectada')]:
        groups[cut]=label+' — envoltória da seção'
    result=[];seen=set()
    for row in rows:
        key=next((prefix for prefix in ('dc_bolt_','dc_weld_internal_','dc_weld_receiver_','dc_base_internal_') if row.id.startswith(prefix)),None)
        if key is None:key=next((cut for cut in ('cover','fin','root','beam') if row.id in ('dc_yield_'+cut,'dc_net_'+cut,'dc_stability_'+cut)),None)
        if key is None:result.append(row);continue
        if key in seen:continue
        seen.add(key)
        branches=[x for x in rows if x.id.startswith(key)] if key.startswith('dc_') else [x for x in rows if x.id in ('dc_yield_'+key,'dc_net_'+key,'dc_stability_'+key)]
        winner=max(branches,key=lambda x:x.ratio)
        result.append(replace(winner,name=groups[key]+' (governa: '+winner.name+')',demand=winner.ratio,resistance=1.,unit='—',equation='η = max(η dos ramos retidos)',substitution='; '.join(x.id+': η='+format(x.ratio,'.9g') for x in branches),variables='Envoltória de apresentação. Cada ramo, capacidade e solicitação permanece desenvolvido separadamente.'))
    return result


class DoubleCoverResult(Result):
    @property
    def summary_checks(self):return section_envelopes(self.checks)
    @property
    def actual_summary(self):return section_envelopes(self.actual)
    @property
    def resistance_failures(self):return [x for x in self.checks if x.numerically_valid and x.applicable and not x.passed and not getattr(x,'model_only_failure',False) and not isinstance(x,InternalElasticWeldCheck)]
    @property
    def conditional_model_failures(self):return [x for x in self.checks if isinstance(x,InternalElasticWeldCheck) and x.numerically_valid and x.applicable and not x.passed]
    @property
    def conservative_model_failures(self):return [x for x in self.checks if getattr(x,'model_only_failure',False)]
    @property
    def numeric_failures(self):return [x for x in self.checks if not x.numerically_valid]
    @property
    def local_scope_issues(self):return [x for x in self.issues if x.origin=='local_scope']
    @property
    def coverage_note(self):
        notes=[]
        if self.resistance_failures:notes.append('Resistência local não atendida: '+', '.join(x.name for x in self.resistance_failures)+'.')
        if self.conditional_model_failures:notes.append('Hipótese elástica não atendida: '+', '.join(x.name for x in self.conditional_model_failures)+'. O índice calculado excede o limite sob as hipóteses de transferência declaradas; isso não comprova falha física do conjunto real nem resolve as pendências da nervura e dos receptores.')
        if self.conservative_model_failures:notes.append('Critério direcional local da nervura não atendido; sem exceder o teto necessário, o resultado requer revisão do modelo local e não comprova falha física.')
        if self.numeric_failures:notes.append('Falha numérica em '+', '.join(x.name for x in self.numeric_failures)+': sem conclusão para esses mecanismos; falhas resistentes finitas, se presentes, permanecem válidas.')
        notes.extend(x.text for x in self.issues if x.origin=='numeric')
        notes.extend(x.text for x in self.local_scope_issues)
        return ' '.join(notes)
    @property
    def status(self):
        # A proven finite resistance failure is not hidden by an independent gap.
        if self.resistance_failures:return 'NÃO ATENDE'
        if self.numeric_failures or any(x.origin=='numeric' for x in self.issues):return 'FALHA NUMÉRICA · REVISAR ENTRADA'
        if any(x.severity=='error' and x.origin=='data' for x in self.issues):return 'DADOS NECESSÁRIOS AUSENTES'
        if any(x.severity=='error' for x in self.issues):return 'GEOMETRIA INVÁLIDA'
        if self.conditional_model_failures:return 'HIPÓTESE ELÁSTICA NÃO ATENDIDA'
        if any(x.severity=='noncompliance' for x in self.issues):return 'NÃO ATENDE AO DETALHAMENTO'
        if any(x.severity=='extrapolation' for x in self.issues):return 'CÁLCULO COM RESSALVAS · EXTRAPOLAÇÃO DO MODELO'
        if any(x.severity=='pending' and x.origin=='data' for x in self.issues):return 'DADOS NECESSÁRIOS AUSENTES'
        if any(x.origin=='zero_actions' for x in self.issues):return 'SEM AÇÕES · DIREÇÃO DO MÍNIMO INDEFINIDA'
        if self.conservative_model_failures:return 'REVISAR CRITÉRIO DIRECIONAL LOCAL'
        if any(x.severity=='pending' for x in self.issues):return 'REVISAR CONDIÇÕES DE APLICAÇÃO'
        if not self.checks:return 'SEM VERIFICAÇÕES DE RESISTÊNCIA'
        # A geometric interference must not hide an unresolved local load path.
        if self.local_scope_issues:return 'VERIFICAÇÕES LOCAIS ATENDEM · ESCOPO INCOMPLETO'
        if any(x.severity=='interference' for x in self.issues):return 'CÁLCULO ATENDE · CONFERIR INTERFERÊNCIAS'
        return 'ATENDE ÀS VERIFICAÇÕES REALIZADAS'
    @property
    def governing(self):
        rows=[x for x in self.checks if x.numerically_valid and x.applicable]
        return max(rows,key=lambda x:x.ratio) if rows else None


def fillet_minimum(thinner):
    return 3. if thinner<=6.3 else 5. if thinner<=12.5 else 6. if thinner<=19 else 8.


def weld_interfaces(c):
    """Actual physical joints. t_edge is the edge receiving the fillet."""
    joints=[('web','nervura–alma da coluna',c.weld_web,c.fin_t,c.support.tw,c.root_height-2*c.corner_clip),
            ('fin_h','nervura–horizontal',c.weld_fin_stiffener,c.fin_t,c.stiffener_t,c.projection-2*c.corner_clip),
            ('h_flange','horizontal–mesa da coluna',c.weld_stiffener_column,c.stiffener_t,c.support.tf,c.projection-2*c.corner_clip),
            ('h_web','horizontal–alma da coluna',c.weld_stiffener_column,c.stiffener_t,c.support.tw,c.stiffener_span-2*c.corner_clip)]
    return [dict(id=id,name=name,w=w,t_edge=t,t_other=ts,length=length,minimum=fillet_minimum(min(t,ts)),maximum=t if t<6.3 else t-1.5) for id,name,w,t,ts,length in joints]

PLATE_STOCK={'3/16"':4.7625,'1/4"':6.35,'5/16"':7.9375,'3/8"':9.525,'1/2"':12.7,'5/8"':15.875,'3/4"':19.05,'1"':25.4}


@dataclass(frozen=True)
class DoubleCoverConnection:
    beam: Profile
    support: Profile
    project: str='Viga na alma de coluna — duas talas'
    beam_steel: str='ASTM A572 Gr.50'
    support_steel: str='ASTM A572 Gr.50'
    fin_steel: str='ASTM A36'
    cover_steel: str='ASTM A36'
    stiffener_steel: str='ASTM A36'
    bolt: str='ASTM F3125 A325'
    db: float=19.05
    threads: bool=True
    n: int=3
    pitch: float=70.
    edge_v: float=40.
    edge_x: float=40.
    gap: float=10.
    extension: float=100.
    fin_t: float=7.9375
    cover_t: float=7.9375
    stiffener_t: float=9.525
    root_height: float=353.
    corner_clip: float=18.
    weld_web: float=5.
    weld_fin_stiffener: float=5.
    weld_stiffener_column: float=6.
    fw: float=485.
    clearance: float=10.
    tool_radius: float=18.
    shim_mode: str='automatic'
    fit_tolerance: float=1.
    drilled: bool=False
    norm_minimum: bool=True
    V: float=11000.
    N: float=2000.
    notes: str=''

    @property
    def hp(self):return 2*self.edge_v+(self.n-1)*self.pitch
    @property
    def plate_top(self):return (self.beam.d-self.hp)/2
    @property
    def dh(self):return self.db+(1.5875 if self.db<25.4 else 3.175)
    @property
    def dh_net(self):return self.dh+(0 if self.drilled else 2.)
    @property
    def projection(self):return (self.support.bf-self.support.tw)/2
    @property
    def fin_length(self):return self.projection+self.extension
    @property
    def beam_column_gap(self):return self.extension+self.gap
    @property
    def pin_x(self):return self.fin_length+self.gap/2
    @property
    def group_e(self):return self.edge_x+self.gap/2
    @property
    def fin_group_x(self):return self.fin_length-self.edge_x
    @property
    def cover_start_x(self):return self.fin_length-2*self.edge_x
    @property
    def internal_fin_perforation(self):return self.fin_group_x-self.dh/2<self.projection
    @property
    def cover_length(self):return 4*self.edge_x+self.gap
    @property
    def thickness_difference(self):return abs(self.fin_t-self.beam.tw)
    @property
    def shim_each(self):return self.thickness_difference/2 if self.shim_mode=='automatic' else 0.
    @property
    def shim_side(self):return 'nervura' if self.fin_t<self.beam.tw else 'viga' if self.fin_t>self.beam.tw else 'nenhum'
    @property
    def stiffener_width(self):return self.projection
    @property
    def stiffener_span(self):return self.support.d-2*self.support.tf
    @property
    def fixed_assumptions(self):
        return {'rotation_reference':'mid_gap','symmetric_double_cover':True,'rows_equal_both_groups':True,
                'horizontal_stiffeners':4,'rear_stiffeners_strength_credit':False,'beam_effectively_restrained':True,
                'welded_profile_internal_joints':'complete_joint_penetration_matching_filler',
                'axial_sign':'positive_tension_negative_compression','external_moment_input':False,
                'support_load_path':(('concomitant_three_edge_and_vertical_beam_weld_envelope' if self.extension==0 else 'weighted_elastic_three_edge_weld_group_rigid_parts') if self.internal_fin_perforation else 'V_to_web_N_and_local_M_to_front_horizontal_pair'),
                'internal_weld_group_assumption':'rigid_fin_and_receivers_in_plane_uniform_isotropic_stiffness_per_throat_area',
                'internal_weld_action_sign':'transmitted_rib_to_receivers_x_outward_y_up_positive_M_counterclockwise',
                'internal_fin_local_yield_assumption':'plane_stress_from_boundary_traction_only_sigma_parallel_zero',
                'vertical_beam_assumption':('fixed_in_plane_end_translations_and_rotations_EB_and_Timoshenko_gross_stiffness' if self.internal_fin_perforation and self.extension==0 else 'not_applied'),
                'lateral_restraint':'column_web_edge_lateral_only_not_torsional_FLT_not_waived',
                'assembly_stability_and_rotation':'not_validated','column_global_check':'external'}
    def to_dict(self):return {'schema_version':1,'connection_type':'column_web_double_cover','app_version':PACKAGE_ID,'connection':asdict(self),'fixed_assumptions':self.fixed_assumptions}
    @staticmethod
    def from_dict(data):
        if not isinstance(data,dict) or data.get('connection_type')!='column_web_double_cover' or data.get('schema_version')!=1:
            raise ValueError('Selecione um projeto da ligação à alma de coluna com duas talas.')
        d=dict(data['connection']);d['beam']=Profile(**d['beam']);d['support']=Profile(**d['support'])
        return DoubleCoverConnection(**d)


def presets():
    ps=profiles()
    c=DoubleCoverConnection(beam=ps['W 360 x 39,0'],support=ps['HP 250 x 62,0 (H)'])
    from dataclasses import replace
    return {'W360 → HP250 · tração':c,'W360 → HP250 · compressão':replace(c,N=-2000,project='Duas talas — compressão de 2 kN'),
            INITIAL_PRESET:replace(c,extension=0.,gap=10.,project='Duas talas — grupo interno e viga a 10 mm da coluna'),
            'Geometria inicial da planilha · revisar':replace(c,beam=ps['W 150 x 13,0'],n=2,pitch=37.3333333333333,edge_v=37.3333333333333,edge_x=40,db=15.875,fin_t=4.3,root_height=148,stiffener_t=6.35,weld_web=3,weld_fin_stiffener=3,V=45000,N=70000,project='Planilha recebida — geometria inicial',notes='Perfis e esforços da planilha. Talas e soldas complementadas para representar a descrição; não é reprodução integral da planilha.')}


def compression_capacity(h,t,fy,length,k=1.):
    """Barra chata isolada, Q=1, sem ganho de seção composta: NBR 5.3/6.5.4."""
    if min(h,t,fy,length,k)<=0:raise ValueError('Dimensões de compressão inválidas.')
    area=h*t;r=t/math.sqrt(12);slender=k*length/r
    ne=math.pi**2*E*(h*t**3/12)/(k*length)**2
    lam0=math.sqrt(area*fy/ne)
    # Errata 1:2025: Le/r > 25. All-length χ is a retained conservative
    # choice for short bars, not a workaround for an unresolved source typo.
    chi=.658**(lam0**2) if lam0<=1.5 else .877/lam0**2
    return chi*area*fy/G1,dict(slender=slender,chi=chi,ne=ne,lambda0=lam0,k=k,length=length)


def shim_factor(total):
    if total<0 or total>19:raise ValueError('Calços fora do intervalo de 0 a 19 mm.')
    return 1. if total<=6.3 else 1-.0154*(total-6.3)


def support_actions(c,V,N):
    M=V*c.pin_x
    top=N/2+M/c.root_height;bottom=N/2-M/c.root_height
    return dict(V=V,N=N,M=M,top=top,bottom=bottom)


def internal_weld_segments(c):
    """Physical paired fillets projected into the rib plane, including clips."""
    H=c.root_height;b=c.projection;a=c.corner_clip
    if H-2*a<=0 or b-2*a<=0:
        raise ValueError('Alívios eliminam o comprimento útil de uma borda soldada da nervura.')
    return [dict(id='web',start_mm=[0.,-H/2+a],end_mm=[0.,H/2-a],leg_mm=c.weld_web,fillet_count=2),
            dict(id='top',start_mm=[a,H/2],end_mm=[b-a,H/2],leg_mm=c.weld_fin_stiffener,fillet_count=2),
            dict(id='bottom',start_mm=[a,-H/2],end_mm=[b-a,-H/2],leg_mm=c.weld_fin_stiffener,fillet_count=2)]


def internal_weld_group(c,V,N):
    """Full N,V applied once at the nominal mid-gap pin, without bolt moment.

    The bolt-group couple V*group_e already belongs to moving the load from
    that pin to the bolt centroid. Adding it here would double count it.
    """
    group=elastic_throat_group(internal_weld_segments(c),N,V,c.pin_x,0.)
    if not finite_real(c.fw) or c.fw<=0 or not finite_real(c.fin_t) or c.fin_t<=0:
        raise ValueError('Resistência de solda/espessura da nervura inválida.')
    rd=.6*c.fw/G2;fy=STEELS[c.fin_steel].fy/G1
    normals={'web':[-1.,0.],'top':[0.,1.],'bottom':[0.,-1.]}
    for s in group['segments']:
        nx,ny=normals[s['id']];tx,ty=s['tangent_unit'];base=[]
        for p in s['endpoint_stresses']:
            qx,qy=p['qx_N_per_mm'],p['qy_N_per_mm']
            # Receiver action is the negative of the traction on the rib.
            # One rib thickness carries the sum from both fillets.
            sigma=-(qx*nx+qy*ny)/c.fin_t
            tau=-(qx*tx+qy*ty)/c.fin_t
            eq=math.hypot(sigma,math.sqrt(3)*tau)
            base.append(dict(endpoint=p['endpoint'],x_mm=p['x_mm'],y_mm=p['y_mm'],
                sigma_normal_MPa=sigma,tau_tangent_MPa=tau,sigma_parallel_MPa=0.,
                equivalent_MPa=eq,utilization=eq/fy))
        governing=max(base,key=lambda p:p['equivalent_MPa'])
        s.update(stress_resistance_MPa=rd,utilization=s['max_stress_MPa']/rd,
            length_to_leg_ratio=s['length_mm']/s['leg_mm'],
            fin_base_endpoint_stresses=base,fin_base_critical_point=governing,
            fin_base_max_equivalent_MPa=governing['equivalent_MPa'],
            fin_base_yield_resistance_MPa=fy,fin_base_utilization=governing['utilization'])
    long_edges=[s['id'] for s in group['segments'] if s['length_to_leg_ratio']>100.]
    long_note=(' Domínio extrapolado: L/w > 100 em '+', '.join(long_edges)+'. A aplicabilidade/redução de soldas longitudinais longas da NBR 6.2.2.2(d) requer revisão; o grupo usa comprimentos físicos sem redução β. O limiar é limite adotado deste método, não proibição normativa universal.' if long_edges else '')
    group.update(stress_resistance_MPa=rd,max_utilization=group['max_stress_MPa']/rd,
        model='weighted_elastic_three_edge_weld_group',assumption=INTERNAL_WELD_NOTE,
        long_joint_status='pending_reduction_applicability' if long_edges else 'within_100_leg_scope',
        long_joint_edges=long_edges,long_joint_note=long_note,
        sign_convention='x para fora da alma; y para cima; N=Fx, V=Fy; M positivo anti-horário; ações transmitidas nervura→receptores',
        receiver_capacity_status='pending',rib_membrane_status='pending',
        rib_stability_status='pending',compatibility_status='assumed_rigid_parts',
        fin_base_criterion='supplemental_local_plane_stress_yield_sigma_parallel_zero')
    return group


def internal_weld_checks(c,V,N,case):
    group=internal_weld_group(c,V,N);rows=[]
    labels={'web':'Nervura–alma da coluna','top':'Nervura–horizontal superior','bottom':'Nervura–horizontal inferior'}
    for s in group['segments']:
        p=s['critical_point'];name=labels[s['id']]
        geometry=(f"Aw={group['area_mm2']:.6f}; xG={group['centroid_x_mm']:.6f}; yG={group['centroid_y_mm']:.6f}; Jw={group['J_mm4']:.6f}; "
                  f"N={N:.6f}; V={V:.6f}; xP={c.pin_x:.6f}; MG={group['moment_about_centroid_Nmm']:.6f}; "
                  f"L={s['length_mm']:.6f}; w={s['leg_mm']:.6f}; a=w/√2={s['throat_mm']:.6f}; dois filetes; ")
        endpoints='; '.join(f"{e['endpoint']}: x={e['x_mm']:.6f}; y={e['y_mm']:.6f}; τx={e['sx_MPa']:.6f}; τy={e['sy_MPa']:.6f}; τres={e['resultant_MPa']:.6f}" for e in s['endpoint_stresses'])
        rows.append(InternalElasticWeldCheck('dc_weld_internal_'+s['id'],name+' — solda sob hipótese elástica',
            s['max_stress_MPa'],s['stress_resistance_MPa'],'MPa',NBR+', 6.2.5 / Tabela 9, nota d',
            'τres,max = max_pontas √[(N/Aw − MG(y−yG)/Jw)² + (V/Aw + MG(x−xG)/Jw)²] ≤ 0,6fw/γw2',
            geometry+endpoints+f"; ponto crítico={p['endpoint']}; τRd={s['stress_resistance_MPa']:.6f}",
            INTERNAL_WELD_NOTE+' Aw=Σ2aL; centroide e Jw ponderados pela garganta de cada borda. MG=(xP−xG)V−(yP−yG)N, yP=0; não soma novamente V·e do grupo de parafusos. Máximo exato nas extremidades, sem aumento direcional e sem média da tensão ao longo da borda.'+group['long_joint_note'],case))
        base=s['fin_base_critical_point']
        rows.append(InternalElasticWeldCheck('dc_base_internal_'+s['id'],name+' — escoamento local suplementar da nervura',
            s['fin_base_max_equivalent_MPa'],s['fin_base_yield_resistance_MPa'],'MPa',
            'Critério suplementar elástico de von Mises; '+NBR+', 6.5 / 6.1.1.3',
            'σeq,max = max_pontas √[(qn/tfin)² + 3(qpar/tfin)²] ≤ fy/γa1; σpar = 0',
            f"tfin={c.fin_t:.6f}; σn={base['sigma_normal_MPa']:.6f}; τpar={base['tau_tangent_MPa']:.6f}; σeq={base['equivalent_MPa']:.6f}; fy/γa1={s['fin_base_yield_resistance_MPa']:.6f}; ponto={base['endpoint']}",
            'Fluxo q é a soma dos dois filetes, aplicada a uma única espessura física da nervura; qn e qpar são as componentes normal e tangente à borda. Estado plano local idealizado com tensão paralela à borda nula; essa tensão não é determinada pelo grupo e pode existir na chapa real. Critério suplementar sob a mesma hipótese rígida, sem qualificar a membrana perfurada, ruptura combinada, estabilidade ou receptores. Não trata a componente normal ao plano da alma/horizontal receptora como cisalhamento no seu metal-base.'+group['long_joint_note'],case))
    edges={s['id']:s for s in group['segments']}
    actions=dict(V=V,N=N,M=group['moment_about_origin_Nmm'],
        top=edges['top']['integrated_Fx_N'],bottom=edges['bottom']['integrated_Fx_N'],
        model=group['model'],sign_convention=group['sign_convention'],weld_group=group)
    from .double_cover_transfer import transfer_envelope, LABELS
    envelope=transfer_envelope(c,V,N,group,case)
    actions['beam_transfer_envelope']=envelope
    if envelope['status']=='calculated_conditional':
        replacements={}
        for e in envelope['weld_envelopes']:
            detail='; '.join(f"{a['label']}: Fx={a['Fx']:.6f}; Fy={a['Fy']:.6f}; Mz livre={a['Mz']:.6f}; η={a['utilization']:.9f}" for a in e['alternatives'])
            winner=next(a for a in e['alternatives'] if a['model']==e['governing_model'])
            point=winner.get('critical_point',winner.get('segment',{}).get('critical_point',{}))
            detail+='; ponto crítico='+str(point.get('endpoint',''))+'; hipótese governante='+LABELS[e['governing_model']]
            note=envelope['assumptions']+' Governa: '+LABELS[e['governing_model']]+'. '+group['long_joint_note']
            is_base=e['id'].startswith('dc_base_')
            if is_base:
                equation='η = max_hipóteses max_pontas √[(qy/tfin)² + 3(qx/tfin)²] / (fy/γa1); σpar = 0'
                note+='Critério local suplementar na borda da nervura; tensão paralela à borda assumida nula, mas não é determinada por este campo de tração de borda. Não qualifica membrana, ligamentos, metal-base receptor ou estabilidade.'
                reference='Critério suplementar elástico; '+NBR+', 6.5 / 6.1.1.3'
            else:
                equation='η = max_hipóteses max_pontas ||σvetorial da garganta|| / (0,6fw/γw2)'
                note+='Metal da solda somente, dois filetes sem aumento direcional. Peças rígidas e rigidez isotrópica por área de garganta; não qualifica resistência/rigidez das chapas receptoras.'
                reference=NBR+', 6.2.5 / Tabela 9, nota d; distribuição elástica vetorial'
            if e['id'].startswith('dc_weld_receiver_'):
                note+=' Grupo U tridimensional no plano médio da horizontal: Fy é normal à chapa. Transporte da face da nervura ao plano médio inclui excentricidade da metade da espessura da horizontal.'
            replacements[e['id']]=InternalElasticWeldCheck(e['id'],e['label']+' — envoltória condicional',e['demand'],e['resistance'],'MPa',reference,equation,detail,note,case)
        rows=[replacements.pop(row.id,row) for row in rows]+list(replacements.values())
    return rows,actions


def fin_outline(c):
    """Physical rib outline in elevation (mm), also used by the drawing.

    At u=0 the hp step has zero width and is not a physical boundary.
    Corner clips belong to the horizontal stiffeners, not this rib outline.
    """
    b,L,H,h=c.projection,c.fin_length,c.root_height,c.hp
    if c.extension==0:
        return [(0.,-H/2),(b,-H/2),(b,H/2),(0.,H/2)]
    return [(0.,-H/2),(b,-H/2),(b,-h/2),(L,-h/2),
            (L,h/2),(b,h/2),(b,H/2),(0.,H/2)]


def _segment_distance(p,a,b):
    dx,dy=b[0]-a[0],b[1]-a[1]
    length2=dx*dx+dy*dy
    t=max(0.,min(1.,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/length2)) if length2 else 0.
    return math.hypot(p[0]-a[0]-t*dx,p[1]-a[1]-t*dy)


def _fin_hole_geometry(c):
    outline=fin_outline(c)
    edges=list(zip(outline,outline[1:]+outline[:1]))
    centers=[(c.fin_group_x,(i-(c.n-1)/2)*c.pitch) for i in range(c.n)]
    radius=c.dh/2
    holes=[]
    tolerance=1e-10*max(1.,c.fin_length,c.root_height,c.hp,c.dh)
    for i,p in enumerate(centers):
        inside=False
        for a,b in edges:
            if (a[1]>p[1])!=(b[1]>p[1]):
                x=a[0]+(p[1]-a[1])*(b[0]-a[0])/(b[1]-a[1])
                if p[0]<x:inside=not inside
        candidates=[(_segment_distance(p,a,b)-radius,f'contorno {k+1}')
                    for k,(a,b) in enumerate(edges)]
        candidates.extend((math.dist(p,q)-2*radius,f'furo {j+1}')
                          for j,q in enumerate(centers) if j!=i)
        minimum,nearest=min(candidates)
        if not inside or minimum < -tolerance:
            raise ValueError(f'Furo {i+1} da nervura intercepta ou ultrapassa o contorno físico ou outro furo.')
        if minimum<=tolerance:
            # A touching circle (or a roundoff-sized gap) is not a qualified
            # positive ligament; do not silently grant a finite capacity.
            raise ValueError(f'Furo {i+1} da nervura sem ligamento positivo resolvível no contorno físico.')
        holes.append(dict(hole=i+1,x=p[0],y=p[1],lf_minimum=minimum,minimum_target=nearest))
    return outline,edges,centers,holes


def _swept_directional_contact(p,u,edges,centers,radius,skip):
    """First translation of a circular hole along u to a segment/other hole.

    Segment capsules (offset lines plus endpoint circles) and circle-circle
    summed radii find the minimum parallel clear gap, including oblique
    neighbors missed by a ray through the loaded hole's center.
    """
    hits=[]
    def circle_entry(q,r):
        delta=(q[0]-p[0],q[1]-p[1])
        along=delta[0]*u[0]+delta[1]*u[1]
        transverse=delta[0]*u[1]-delta[1]*u[0]
        if along<0 or abs(transverse)>r:return None
        value=along-math.sqrt(max(0.,r*r-transverse*transverse))
        return max(0.,value) if value>=-1e-10 else None
    for k,(a,b) in enumerate(edges):
        vx,vy=b[0]-a[0],b[1]-a[1];length=math.hypot(vx,vy)
        if length:
            tangent=(vx/length,vy/length);normal=(-tangent[1],tangent[0])
            distance=(p[0]-a[0])*normal[0]+(p[1]-a[1])*normal[1]
            speed=u[0]*normal[0]+u[1]*normal[1]
            if speed:
                for sign in (-1,1):
                    travel=(sign*radius-distance)/speed
                    if travel<0:continue
                    point=(p[0]+travel*u[0]-sign*radius*normal[0],p[1]+travel*u[1]-sign*radius*normal[1])
                    projection=(point[0]-a[0])*tangent[0]+(point[1]-a[1])*tangent[1]
                    if -1e-10<=projection<=length+1e-10:
                        hits.append(dict(lf=travel,target=f'contorno {k+1}',edge=k,point=point))
        for q in (a,b):
            travel=circle_entry(q,radius)
            if travel is not None:hits.append(dict(lf=travel,target=f'contorno {k+1}',edge=k,point=q))
    for j,q in enumerate(centers):
        if j==skip:continue
        travel=circle_entry(q,2*radius)
        if travel is not None:
            point=((p[0]+travel*u[0]+q[0])/2,(p[1]+travel*u[1]+q[1])/2)
            hits.append(dict(lf=travel,target=f'furo {j+1}',edge=None,point=point))
    if not hits:raise ValueError('Direção da força sem encontro com contorno físico ou outro furo.')
    return min(hits,key=lambda hit:hit['lf'])


def _fin_contact_is_welded(c,point):
    x,y=point;tol=1e-8
    return ((abs(x)<=tol and abs(y)<=c.root_height/2-c.corner_clip+tol)
            or (abs(abs(y)-c.root_height/2)<=tol
                and c.corner_clip-tol<=x<=c.projection-c.corner_clip+tol))


def internal_fin_bearing(c,V,N):
    """Directional local criterion, not qualification of the rib load path.

    lf is the first swept-circle contact in the signed force direction. This
    explicit geometric interpretation uses the actual stepped boundary and
    round holes, not the minimum gap in unrelated directions. A first contact
    on a real welded interval yields only the necessary bearing ceiling and
    a pending directional transfer, never a fictitious free-edge resistance.
    """
    outline,edges,centers,holes=_fin_hole_geometry(c)
    forces=elastic_group(c.n,c.pitch,1,0,V,N,V*c.group_e)
    radius=c.dh/2
    ks=shim_factor(c.thickness_difference) if c.shim_mode=='automatic' and c.fin_t<c.beam.tw else 1.
    ceiling=ks*2.4*c.db*c.fin_t*STEELS[c.fin_steel].fu/G2
    for i,(p,(fx,fy),hole) in enumerate(zip(centers,forces,holes)):
        demand=math.hypot(fx,fy);directional=None;target=None;point=None;pending=False
        if demand>0:
            contact=_swept_directional_contact(p,(fx/demand,fy/demand),edges,centers,radius,i)
            directional,target,point=contact['lf'],contact['target'],contact['point']
            pending=contact['edge'] is not None and _fin_contact_is_welded(c,point)
        resistance=ceiling if pending or directional is None else min(ceiling,ks*1.2*directional*c.fin_t*STEELS[c.fin_steel].fu/G2)
        hole.update(fx=fx,fy=fy,demand=demand,lf_directional=directional,
                    directional_target=target,contact_point=point,
                    contact_label=(('trecho soldado' if pending else 'borda livre')+' [segmento '+target.split()[-1]+']') if target and target.startswith('contorno') else target,
                    lf_adopted=None if pending else directional,transfer_pending=pending,
                    shim_factor=ks,resistance=resistance,necessary_resistance=ceiling,
                    ratio=demand/resistance)
    governing=max(holes,key=lambda h:h['ratio'])
    return dict(holes=holes,governing=governing,boundary=outline,
                transfer_pending=any(h['transfer_pending'] for h in holes))


def geometry(c):
    issues=[]
    def add(sev,text,ref='Geometria e modelo',origin='model'):issues.append(Issue(sev,text,ref,origin))
    fields=('db','pitch','edge_v','edge_x','gap','extension','fin_t','cover_t','stiffener_t','root_height','corner_clip','weld_web','weld_fin_stiffener','weld_stiffener_column','fw','clearance','tool_radius','fit_tolerance','V','N')
    if any(getattr(c,k) is None for k in fields):
        add('error','Há entradas numéricas necessárias ausentes.',origin='data');return issues,{}
    if not all(finite_real(getattr(c,k)) for k in fields):
        add('error','Todas as entradas numéricas devem ser finitas.',origin='numeric');return issues,{}
    if type(c.n) is not int or not 2<=c.n<=12 or any(type(getattr(c,k)) is not bool for k in ('threads','drilled','norm_minimum')):
        add('error','Número de linhas ou opções booleanas inválidos.');return issues,{}
    if c.shim_mode not in ('automatic','fit') or c.db not in DIAMETERS.values() or c.bolt not in BOLTS:
        add('error','Parafuso ou modo de montagem não reconhecido.');return issues,{}
    if min(getattr(c,k) for k in fields if k not in ('V','N','extension','corner_clip','clearance','fit_tolerance'))<=0 or min(c.extension,c.corner_clip,c.clearance,c.fit_tolerance)<0:
        add('error','Dimensões positivas são obrigatórias; u, alívios e tolerâncias não podem ser negativos.');return issues,{}
    if c.fit_tolerance>1.:add('extrapolation','Tolerância de montagem sem calços acima de 1 mm, fora do limite adotado nesta implementação; conferir contato e montagem, sem dispensa normativa.')
    for name,p,steel in [('Viga',c.beam,c.beam_steel),('Coluna',c.support,c.support_steel)]:
        vals=(p.d,p.bf,p.tw,p.tf,p.clear,p.area,p.mass)
        if not all(finite_real(v) for v in vals):
            add('error',name+': dimensões e propriedades devem ser finitas.',origin='numeric');return issues,{}
        if not all(v>0 for v in vals) or p.d<=2*p.tf or p.clear>p.d-2*p.tf or p.bf<=p.tw:
            add('error',name+': seção I inconsistente.');return issues,{}
    for name,steel,thick,plate in [('Viga',c.beam_steel,[c.beam.tw,c.beam.tf],c.beam.family in ('VS','CVS','CS','Soldado')),('Coluna',c.support_steel,[c.support.tw,c.support.tf],c.support.family in ('VS','CVS','CS','Soldado')),('Nervura',c.fin_steel,[c.fin_t],True),('Talas',c.cover_steel,[c.cover_t],True),('Enrijecedores',c.stiffener_steel,[c.stiffener_t],True)]:
        if steel not in STEELS:add('error',name+': aço desconhecido.');continue
        s=STEELS[steel];lo=s.plate_min if plate else s.profile_min;hi=s.plate_max if plate else s.profile_max
        if (plate and not s.plate_allowed) or (not plate and not s.rolled_allowed) or min(thick)<lo or max(thick)>hi:add('error',name+': aço/produto/espessura fora do intervalo cadastrado.',s.source)
    pmin=max(2.7*c.db,c.dh+c.db);pmax=min(24*min(c.fin_t,c.cover_t,c.beam.tw),300)
    if c.pitch<pmin:add('error',f'Passo p inferior a {pmin:.2f} mm.',NBR+', 6.3.9')
    if c.pitch>pmax:add('noncompliance',f'Passo p excede {pmax:.2f} mm; cálculo disponível com requisito de detalhamento não atendido.',NBR+', 6.3.10')
    emin={12.7:19,15.875:22,19.05:25,22.225:28,25.4:32,28.575:38,31.75:41}[c.db]
    for name,e,t in [('vertical das talas/nervura',c.edge_v,min(c.cover_t,c.fin_t)),('horizontal da emenda',c.edge_x,min(c.cover_t,c.fin_t,c.beam.tw))]:
        if e<max(emin,c.dh/2):add('error',f'Borda {name} inferior a {emin} mm.',NBR+', tabela 16')
        if e>min(12*t,150):add('noncompliance',f'Borda {name} excede min(12t;150 mm).',NBR+', 6.3.12')
    if c.hp>=c.beam.clear-2*c.clearance:add('interference','Talas invadem mesas/concordâncias da viga; reduza altura ou aumente o perfil.')
    if (c.beam.clear-(c.n-1)*c.pitch)/2<c.tool_radius:add('interference','Porca/ferramenta interfere na concordância da viga.')
    # The column outline is not solid steel. x=0 is the front web face;
    # flanges occupy |y| >= (d-2tf)/2, with x <= projection.
    start=c.cover_start_x;xg=c.fin_group_x
    pack_half=max(c.fin_t,c.beam.tw)/2+c.cover_t
    half_clear=c.stiffener_span/2
    inside_cover=start<c.projection
    if start<0:
        add('interference','Colisão material: as talas interceptam a alma da coluna (início x < 0).',origin='material_collision')
    elif inside_cover and start<c.weld_web:
        add('interference','Envelope do filete nervura–alma intercepta a região das talas; conferir a geometria real da solda.',origin='weld_envelope')
    if inside_cover and pack_half>half_clear:
        add('interference','Colisão material: talas/calços interceptam as mesas da coluna na planta.',origin='material_collision')
    elif inside_cover and half_clear-pack_half<c.clearance:
        add('interference','Folga lateral entre as talas e as mesas da coluna inferior à folga de montagem informada.',origin='assembly_clearance')
    if xg-c.db/2<0:
        add('interference','Colisão material: haste do grupo da nervura intercepta a alma da coluna.',origin='material_collision')
    if xg-c.dh/2<0:
        add('error','Um furo da nervura ultrapassa sua borda junto à alma da coluna; geometria do furo inválida.')
    near_column=c.internal_fin_perforation or xg-c.tool_radius<c.projection+c.weld_stiffener_column
    if near_column:
        # Radius is only a radial tool envelope in the fin plane. It is not
        # head/nut height, bolt protrusion, socket length or installation access.
        if xg-c.tool_radius<0:
            add('interference','Envelope radial da ferramenta intercepta a alma da coluna.',origin='tool_envelope')
        # Distance from an extreme bolt center to the conservative horizontal/
        # fillet rectangle. Mere overlap of x/z bounding boxes is not collision.
        dx=max(0.,-xg,xg-(c.projection+c.weld_stiffener_column))
        low=c.root_height/2-c.weld_fin_stiffener
        high=c.root_height/2+c.stiffener_t+c.weld_stiffener_column
        ys=[(i-(c.n-1)/2)*c.pitch for i in range(c.n)]
        distance=min(math.hypot(dx,max(0.,z0-y,y-z1))
                     for y in ys for z0,z1 in ((low,high),(-high,-low)))
        if distance<c.tool_radius:
            add('interference','Envelope radial da ferramenta intercepta o envelope conservador dos horizontais/filetes junto ao grupo da nervura.',origin='tool_envelope')
        add('pending','Acesso de montagem ainda não verificado: informar/conferir os envelopes reais da cabeça, porca, ponta do parafuso e ferramenta entre as mesas. O raio informado não define essas dimensões axiais.',origin='assembly_access')
    if c.internal_fin_perforation:
        try:_fin_hole_geometry(c)
        except ValueError as exc:add('error',str(exc))
        position=('Grupo da nervura no vão interno da coluna' if xg<c.projection else 'Perfuração da nervura na transição entre o vão interno e a aba externa')
        add('info',position+': posição prevista no detalhe; o contorno da coluna não representa colisão com aço.',origin='geometry_position')
        add('pending',INTERNAL_FIN_NOTE+(' A envoltória entre grupo de três bordas e barra vertical inclui as soldas horizontais–coluna; a capacidade/rigidez das chapas receptoras continua pendente. N/Q/M e seções líquidas da barra são informativos, sem aprovação da chapa ou dispensa de FLT.' if c.extension==0 else ''),'Domínio da nervura finita perfurada',origin='local_scope')
        if c.root_height-2*c.corner_clip<=0 or c.projection-2*c.corner_clip<=0:
            add('error','Alívios eliminam o comprimento útil de uma borda soldada da nervura.')
        long_edges=[name for name,L,w in [('alma',c.root_height-2*c.corner_clip,c.weld_web),('horizontais',c.projection-2*c.corner_clip,c.weld_fin_stiffener)] if L>100*w]
        if long_edges:
            add('extrapolation','Grupo de soldas fora do domínio L/w ≤ 100 adotado para '+', '.join(long_edges)+'. Revisar a aplicabilidade da redução de soldas longitudinais longas; o cálculo elástico exibido usa o comprimento físico sem redução β. Este limite de método não é uma proibição normativa universal.',NBR+', 6.2.2.2(d)',origin='local_scope')
    if c.root_height<c.hp+2*(c.clearance+c.weld_fin_stiffener):add('interference','Distância entre horizontais insuficiente para a tala e as soldas.')
    radius=(c.support.d-2*c.support.tf-c.support.clear)/2
    if c.corner_clip<radius:add('interference',f'Alívio de canto menor que a concordância estimada da coluna ({radius:.2f} mm).')
    if c.corner_clip>=min(c.projection,c.stiffener_span/2)/2:add('error','Alívio de canto elimina parcela excessiva do enrijecedor.')
    if (c.n-1)*c.pitch+c.dh_net>=c.beam.d:add('error','Um furo ultrapassa a seção da viga; ligamento resistente inválido.')
    if c.hp-c.n*c.dh_net<=0:add('error','Os furos eliminam a seção líquida das talas/nervura.')
    if c.shim_mode=='fit' and c.thickness_difference>c.fit_tolerance:add('error','Diferença de espessuras excede a tolerância de montagem adotada; utilize calços simétricos.')
    if c.shim_mode=='automatic' and c.thickness_difference>19:add('error','Soma dos calços excede 19 mm; revise espessuras ou use detalhamento específico.',NBR+', 6.5.7.2')
    if c.thickness_difference>0:
        if c.shim_mode=='automatic':add('info',f'Prever dois calços de {c.shim_each:.3f} mm no lado da {c.shim_side}, cobrindo a região parafusada. Não somar a espessura à resistência da peça central.',NBR+', 6.5.7.2')
        else:add('info',f'Diferença de {c.thickness_difference:.3f} mm dentro da tolerância de detalhamento adotada ({c.fit_tolerance:g} mm). Garantir contato firme e montagem simétrica; não é tolerância normativa.',NBR+', 6.3.1')
    for joint in weld_interfaces(c):
        name,w,length=joint['name'],joint['w'],joint['length']
        wmin,wmax=joint['minimum'],joint['maximum']
        if w<wmin or w>wmax:
            add('noncompliance',f'Filete {name}: informado {w:g} mm; mínimo {wmin:g} mm e máximo {wmax:g} mm. Espessuras reais da junta: {joint["t_edge"]:g} / {joint["t_other"]:g} mm. Requisito de detalhamento não atendido; não é sobrecarga resistente demonstrada.',NBR+', 6.2.6.2.1–.2 / Tabela 11')
        if length<max(4*w,40):add('noncompliance',f'Comprimento útil da solda {name} ({length:g} mm) inferior a max(4w;40 mm).',NBR+', 6.2.6.2.3')
    if c.bolt=='ASTM A307':add('error','Nesta ligação, utilizar A325 ou A490; parafusos comuns A307 não estão implementados.')
    if c.hp<.5*c.beam.d:add('extrapolation','Altura conectada menor que metade da viga: detalhamento fora do domínio adotado para a rótula.')
    if min(c.fin_t,c.beam.tw)>c.db/2+1.6 or c.cover_t>c.db/2+1.6:add('extrapolation','Espessuras fora do limite geométrico conservador de flexibilidade; avaliar rotação da emenda.','Complemento AISC, Parte 10; limite de implementação')
    if not c.norm_minimum:add('pending','Mínimo normativo de 45 kN desativado: modo de comparação.',NBR+', 6.1.5.2')
    if c.V==0 and c.N==0:add('pending','Informe esforços não nulos; a direção do mínimo de 45 kN não está definida.',origin='zero_actions')
    add('excluded',ASSEMBLY_NOTE,'NBR 6.1.1–6.1.3; abrangência do modelo local',origin='local_scope')
    add('info','Quatro horizontais: dois níveis, com uma chapa de cada lado da alma da coluna. A dupla oposta não aumenta automaticamente as resistências calculadas.','Modelo do detalhe')
    return issues,dict(hp=c.hp,cover_length=c.cover_length,fin_length=c.fin_length,pin_x=c.pin_x,group_e=c.group_e,shim_each=c.shim_each,weld_interfaces=weld_interfaces(c),fin_group_x=xg,cover_start_x=start,column_front_edge_x=c.projection,column_half_clear_y=half_clear,pack_half_width_y=pack_half,internal_fin_perforation=c.internal_fin_perforation,assembly_access='unverified' if near_column else 'legacy_external')


def strength(c,V,N,case):
    rows=[]
    def add(id,name,sd,rd,unit,ref,eq,sub,variables):rows.append(DoubleCoverCheck(id,name,sd,rd,unit,ref,eq,sub,variables,case))
    # Signed equilibrium agrees with the report. Section envelopes use abs(Ms).
    M=V*c.group_e
    forces=elastic_group(c.n,c.pitch,1,0,V,N,M)
    F=max(math.hypot(x,y) for x,y in forces);Dn=sum(abs(x) for x,y in forces);Dv=sum(abs(y) for x,y in forces)
    nominal=bolt_shear(c.db,BOLTS[c.bolt],c.threads or c.bolt=='ASTM A307')
    for side,central in [('fin',c.fin_t),('beam',c.beam.tw)]:
        shims=c.thickness_difference if c.shim_mode=='automatic' and central<max(c.fin_t,c.beam.tw) else 0.
        grip=central+2*c.cover_t+shims;kg=grip_factor(grip,c.db);ks=shim_factor(shims)
        add('dc_bolt_'+side,'Parafusos — '+('nervura' if side=='fin' else 'viga')+' / corte duplo',F,2*nominal*kg*ks,'N',NBR+', 6.3.3.2, 6.3.7, 6.5.7.2','FRd = 2·kpega·kcalço·α·Ab·fub/γa2',f'FSd={F:.3f}; Mgrupo={M:.3f}; pega={grip:.3f}; kpega={kg:.5f}; kcalço={ks:.5f}', 'Dois planos de corte por parafuso; os dois grupos transmitem o esforço integral. N axial provoca corte, não tração no eixo dos parafusos.')
    if c.internal_fin_perforation:
        local=internal_fin_bearing(c,V,N);governing=local['governing']
        details='; '.join(f"furo {h['hole']}: Fx={h['fx']:.6f}; Fy={h['fy']:.6f}; lf,direcional="
                         +(f"{h['lf_directional']:.6f}" if h['lf_directional'] is not None else 'indefinido (força zero)')
                         +f"; encontro={h['contact_label'] or 'sem força'}; transferência pendente={'sim' if h['transfer_pending'] else 'não'}; FRd={h['resistance']:.6f}; η={h['ratio']:.9g}"
                         for h in local['holes'])
        add('dc_bearing_local_fin','Nervura interna — critério direcional local de contato/rasgamento',governing['demand'],governing['resistance'],'N',NBR+', 6.3.3.3/6.5.7.2',
            'FRd = kcalço·min(1,2lf t fu;2,4db t fu)/γa2; direção à solda: somente Fteto = kcalço·2,4db t fu/γa2',
            f"Governa furo {governing['hole']}; t={c.fin_t:.4f}; db={c.db:.4f}; dh={c.dh:.4f}; kcalço={governing['shim_factor']:.5f}. "+details,
            'Interpretação geométrica direcional explícita: lf é a menor translação do furo circular na direção da força até outro furo ou contorno físico. Usa o contorno escalonado/H real, sem limitar por distâncias em outras direções. Se o primeiro encontro ocorre em trecho soldado real, mantém apenas o teto necessário e a transferência direcional pendente; não trata solda como borda livre. Este critério de contato não atribui crédito às soldas; seu cálculo local independente não demonstra a transferência na chapa. Não qualifica transferência, ruptura/blocos, estabilidade ou receptores. Uma nervura recebe a força inteira; duas talas não duplicam t.')
        rows[-1]=InternalFinBearingCheck(**asdict(rows[-1]),necessary_resistance=governing['necessary_resistance'],necessary_demand=F,directional_pending=local['transfer_pending'])
    lc=min(c.edge_x-c.dh/2,c.edge_v-c.dh/2,c.pitch-c.dh)
    pieces=[('beam','Alma da viga',c.beam.tw,c.beam_steel,1),('cover','Duas talas',c.cover_t,c.cover_steel,2)]
    if not c.internal_fin_perforation:pieces.insert(0,('fin','Nervura',c.fin_t,c.fin_steel,1))
    for id,label,t,steel,count in pieces:
        s=STEELS[steel]
        shimmed=c.shim_mode=='automatic' and (id=='cover' or (id=='fin' and c.fin_t<c.beam.tw) or (id=='beam' and c.beam.tw<c.fin_t))
        ks=shim_factor(c.thickness_difference) if shimmed else 1.
        cap=ks*count*min(1.2*lc*t*s.fu,2.4*c.db*t*s.fu)/G2
        add('dc_bearing_'+id,label+' — contato e rasgamento',F,cap,'N',NBR+', 6.3.3.3/6.5.7.2','FRd = kcalço·nt·min(1,2lc t fu;2,4db t fu)/γa2',f'lc={lc:.4f}; t={t:.4f}; nt={count}; kcalço={ks:.5f}; Fmax={F:.3f}', 'Ligamento livre mínimo em qualquer direção. Cada tala recebe metade da força; calços sem crédito resistente. Para as talas, governa o grupo com maior enchimento.')
        le=c.edge_x;lv=c.edge_v+(c.n-1)*c.pitch;dn=c.dh_net;ell=(c.n-1)*c.pitch
        def block(Agv,Anv,Ant):return count*min(.6*s.fu*Anv+.5*s.fu*Ant,.6*s.fy*Agv+.5*s.fu*Ant)/G2
        rn=block(2*le*t,2*(le-dn/2)*t,(ell-(c.n-1)*dn)*t)
        rv=block(lv*t,(lv-(c.n-.5)*dn)*t,(le-dn/2)*t)
        add('dc_block_'+id,label+' — bloco e esforços do grupo',Dn/rn+Dv/rv,1,'—',NBR+', 6.5.6; combinação linear conservadora','η = Σ|Fx,i|/RN,bloco + Σ|Fy,i|/RV,bloco ≤ 1',f'Σ|Fx|={Dn:.3f}; Σ|Fy|={Dv:.3f}; RN={rn:.3f}; RV={rv:.3f}', 'Caminho U para componente axial e L para vertical; Cts=0,5. Envoltória dos módulos das forças individuais inclui momento e reversão. As duas extremidades iguais das talas são abrangidas.')

    def section(id,label,h,t,steel,Ns,Vs,Ms,L,holes=0,pair=1,k=1,splice=False):
        s=STEELS[steel];A=pair*h*t;An=pair*(h-holes*c.dh_net)*t;Ae=min(An,.85*A) if splice else An
        W=pair*t*h*h/6
        # Momento de inércia líquido de furos retangulares centrados, conservador.
        I=t*h**3/12
        if holes:
            for i in range(holes):
                y=(i-(holes-1)/2)*c.pitch
                I-=t*(c.dh_net**3/12+c.dh_net*y*y)
        Wn=pair*I/(h/2)
        if min(An,Ae,Wn)<=0:raise ValueError('Seção líquida não positiva.')
        sigma=abs(Ns)/A+abs(Ms)/W;tau=1.5*abs(Vs)/A
        add('dc_yield_'+id,label+' — tensões combinadas',math.hypot(sigma,math.sqrt(3)*tau),s.fy/G1,'MPa',NBR+', 6.5; critério elástico de von Mises','σeq = √[(|N|/Ag+|M|/Wg)²+3(1,5|V|/Ag)²]',f'Ag={A:.3f}; Wg={W:.3f}; N={Ns:.3f}; V={Vs:.3f}; M={Ms:.3f}; σeq={math.hypot(sigma,math.sqrt(3)*tau):.5f}', f'Corte físico: {label}. Braço de V: '+format({'cover':c.group_e,'fin':c.extension+c.gap/2,'root':c.pin_x,'beam':c.group_e}[id],'.9g')+' mm. Limite elástico conservador, sem redistribuição plástica; h e t representam esta faixa local, não a seção global da viga.')
        tension=max(0,Ns/Ae+abs(Ms)/Wn)
        eta=tension/(s.fu/G2)+abs(Vs)/(.6*s.fu*An/G2)
        add('dc_net_'+id,label+' — seção líquida',eta,1,'—',NBR+', 6.5.3/6.5.5; envoltória linear','η = max(0;N/Ae+|M|/Wn)/(fu/γa2) + |V|/(0,6fu An/γa2)',f'An={An:.3f}; Ae={Ae:.3f}; Wn={Wn:.3f}; η={eta:.5f}', 'Ae=min(An;0,85Ag) nas talas de emenda; demais faixas Ae=An. Compressão não é transformada em tração. Furos deduzidos sem reutilizar área de calços.')
        nr,props=compression_capacity(h,t,s.fy,L,k);nr*=pair
        mr,_=plate_ltb(h,t,L,s.fy,Cb=1.);mr=pair*mr/G1
        vr=pair*min(.6*s.fy*h*t/G1,.6*s.fu*(h-holes*c.dh_net)*t/G2)
        # Barra chata isolada e LTB sem crédito de solidarização entre talas.
        nrd=nr if Ns<0 else min(s.fy*A/G1,s.fu*Ae/G2)
        eta=abs(Ns)/nrd+abs(Ms)/mr+abs(Vs)/vr
        add('dc_stability_'+id,label+' — estabilidade e interação',eta,1,'—',NBR+', 5.3/6.5.4; AISC F11; interação linear declarada','η = |N|/NRd + |M|/MRd + |V|/VRd ≤ 1',f'L={L:.3f}; K={k:g}; KL/r={props["slender"]:.3f}; χ={props["chi"]:.5f}; NRd={nrd:.3f}; MRd={mr:.3f}; VRd={vr:.3f}', 'Compressão: χAgfy/γa1; K e L explícitos. Flexão: barra chata AISC F11, Cb=1. Cada tala é isolada para instabilidade. Modelo de componente, não estabilidade acoplada do nó.')
    section('cover','Duas talas',c.hp,c.cover_t,c.cover_steel,N,V,M,2*c.group_e,c.n,2,1,True)
    if not c.internal_fin_perforation:
        section('fin','Nervura — aba livre',c.hp,c.fin_t,c.fin_steel,N,V,abs(V)*(c.extension+c.gap/2),c.extension+c.gap/2,c.n,1,2)
        section('root','Nervura — trecho interno',c.root_height,c.fin_t,c.fin_steel,N,V,abs(V)*c.pin_x,c.pin_x,0,1,2)
    section('beam','Alma da viga — faixa conectada',c.hp,c.beam.tw,c.beam_steel,N,V,M,c.group_e,c.n,1,2)
    if c.internal_fin_perforation:
        weld_rows,action=internal_weld_checks(c,V,N,case)
        return rows+weld_rows,action
    action=support_actions(c,V,N)
    H=max(abs(action['top']),abs(action['bottom']))
    sl=c.stiffener_span;b=c.stiffener_width-2*c.corner_clip;ts=c.stiffener_t;s=STEELS[c.stiffener_steel]
    # Faixa horizontal como viga simplesmente apoiada entre mesas, H central no plano.
    mh=H*sl/4;mr,_=plate_ltb(b,ts,sl,s.fy,Cb=1.);mr/=G1
    vr=min(.6*s.fy*b*ts/G1,.6*s.fu*b*ts/G2)
    eta=mh/mr+(H/2)/vr
    add('dc_stiffener','Horizontais frontais — flexão/corte',eta,1,'—','Modelo de faixa biapoiada; '+NBR+', 6.5; AISC F11','η = (|H|s/4)/MRd + (|H|/2)/VRd',f'Hsup={action["top"]:.3f}; Hinf={action["bottom"]:.3f}; Hmax={H:.3f}; b útil={b:.3f}; s={sl:.3f}; M={mh:.3f}; MRd={mr:.3f}; VRd={vr:.3f}', 'Carga H no plano da chapa horizontal; W=t·b²/6. Sem crédito da solda à alma na flexão da faixa. Duas chapas frontais calculadas pela maior força; par oposto sem soma automática. Não verifica sua função de contenção do nó.')
    def weld(id,label,force,w,length,base_t,base_steel,other_t,other_steel):
        capacity=2*(w/math.sqrt(2))*length*.6*c.fw/G2
        add('dc_weld_'+id,label+' — solda',force,capacity,'N',NBR+', 6.2.5','FRd = 2(w/√2)L·0,6fw/γw2',f'FSd={force:.3f}; w={w:.3f}; L útil={length:.3f}; fw={c.fw:g}', 'Dois filetes contínuos; sem aumento direcional. Solda chapa–apoio ou chapa–chapa; não há solda direta viga–coluna.')
        fy=STEELS[base_steel].fy;fu=STEELS[base_steel].fu;fy2=STEELS[other_steel].fy;fu2=STEELS[other_steel].fu
        cap=length*min(.6*fy*base_t/G1,.6*fu*base_t/G2,.6*fy2*other_t/G1,.6*fu2*other_t/G2)
        add('dc_base_'+id,label+' — metal-base',force,cap,'N',NBR+', 6.5.5','FRd = L·min(0,6fy t/γa1;0,6fu t/γa2), ambas as peças',f't1={base_t:.4f}; t2={other_t:.4f}; L={length:.3f}; FRd={cap:.3f}', 'Resultante limitada conservadoramente pela resistência ao corte do metal-base; não duplica a espessura da peça pela existência de dois filetes.')
    weld('web','Nervura–alma da coluna',abs(V),c.weld_web,c.root_height-2*c.corner_clip,c.fin_t,c.fin_steel,c.support.tw,c.support_steel)
    weld('fin_h','Nervura–horizontal',H,c.weld_fin_stiffener,b,c.fin_t,c.fin_steel,ts,c.stiffener_steel)
    weld('h_flange','Horizontal–mesa da coluna',H/2,c.weld_stiffener_column,b,ts,c.stiffener_steel,c.support.tf,c.support_steel)
    # Envoltória adicional: a solda à alma é conferida para H integral, sem ganho nas demais.
    weld('h_web','Horizontal–alma da coluna',H,c.weld_stiffener_column,sl-2*c.corner_clip,ts,c.stiffener_steel,c.support.tw,c.support_steel)
    return rows,action


def evaluate(c):
    try:
        issues,g=geometry(c)
        if not any(i.origin=='local_scope' for i in issues):
            issues.append(Issue('excluded',ASSEMBLY_NOTE,'NBR 6.1.1–6.1.3; abrangência do modelo local','local_scope'))
        if any(i.severity=='interference' for i in issues):issues.append(Issue('excluded',INTERFERENCE_ASSUMPTION))
        r=DoubleCoverResult(issues=issues,geometry=g)
        if any(x.severity=='error' for x in issues):return r
        if c.V==0 and c.N==0:return r
        r.actual,actual_actions=strength(c,c.V,c.N,'Entrada')
        r.minimum_factor=max(1,45000/math.hypot(c.V,c.N)) if c.norm_minimum else 1
        if r.minimum_factor>1:
            r.checks,actions=strength(c,c.V*r.minimum_factor,c.N*r.minimum_factor,'Mínimo de 45 kN')
        else:r.checks=list(r.actual);actions=actual_actions
        r.geometry.update(actions=actions,actual_actions=actual_actions)
        extra=actions.get('beam_transfer_envelope',{})
        if extra.get('long_joint_edges'):
            r.issues.append(Issue('extrapolation','Soldas horizontais–coluna com L/w > 100: revisar aplicabilidade da redução de juntas longas; o grupo usa comprimentos físicos. '+', '.join(extra['long_joint_edges']),NBR+', 6.2.2.2(d)','local_scope'))
        return r
    except (ArithmeticError,ValueError) as exc:
        r=locals().get('r',DoubleCoverResult(issues=[Issue('excluded',ASSEMBLY_NOTE,origin='local_scope')]))
        if not r.checks:r.checks=list(r.actual)
        r.issues.append(Issue('error','Falha numérica no cálculo dos componentes: '+str(exc),'Revisar magnitude e consistência das entradas','numeric'))
        return r
