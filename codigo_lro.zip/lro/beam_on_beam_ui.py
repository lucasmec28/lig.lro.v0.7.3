"""Independent beam-on-beam route; lossless native data and partial results."""
from dataclasses import fields
import hashlib
import json
import math

import pandas as pd
import streamlit as st

from .beam_on_beam import BeamOnBeam, COMPONENT_VERSION, FAMILY, SCOPE, OPTIONAL, presets
from .display_precision import calculated_text, display_format, display_frame, display_tree, number_input
from .models import Profile, profiles, STEELS, BOLTS, KGF

P = {name: p for name, p in profiles().items() if p.family == 'W'}
PRESETS = presets()
CUSTOM = 'W personalizado'
PREFIX = 'bob_'
STATE = '_beam_on_beam_'
UI_REVISION = '0.9.46-ui.2-beam-alignment-review-dev'
ALIGNMENT = STATE + 'alignment'
OFFSET_DRAFT = STATE + 'offset_draft'
ALIGNMENT_DRAFT = STATE + 'alignment_draft'
PROFILE_VALUES = ('d', 'bf', 'tw', 'tf', 'clear', 'area', 'mass')
LOAD_UNITS = {'V': KGF, 'N': KGF, 'applied_moment_y': KGF * 1000, 'torsion': KGF * 1000}
LOAD_KEYS = {'V': 'V_kgf', 'N': 'N_kgf', 'applied_moment_y': 'My_kgfm', 'torsion': 'torsion_kgfm'}
STATUS = {'INVALID_INPUT': 'DADOS INVÁLIDOS', 'NUMERICAL_FAILURE': 'FALHA NUMÉRICA',
          'INVALID_GEOMETRY': 'GEOMETRIA NÃO ATENDIDA', 'OUTSIDE_SUPPORTED_SCOPE': 'FORA DO DOMÍNIO',
          'VERIFIED_SUBCHECK_FAIL': 'HÁ VERIFICAÇÃO LOCAL NÃO ATENDIDA',
          'LOCAL_RESISTANCE_FAIL': 'HÁ RESISTÊNCIA LOCAL NÃO ATENDIDA',
          'LOCAL_RESISTANCE_FAIL_MODEL_PENDING': 'HÁ RESISTÊNCIA LOCAL NÃO ATENDIDA · MODELO PENDENTE',
          'GEOMETRY_FAIL_MODEL_PENDING': 'HÁ GEOMETRIA NÃO ATENDIDA · MODELO PENDENTE',
          'EXTERNAL_EQUILIBRIUM_FAIL': 'EQUILÍBRIO DOS DADOS EXTERNOS NÃO ATENDIDO',
          'DETAIL_FAIL': 'HÁ DETALHAMENTO NÃO ATENDIDO',
          'ENGINEERING_MODEL_PENDING': 'TRANSFERÊNCIA LOCAL FORA DO PLANO PENDENTE',
          'PARTIAL_CHECKS_PASS_MODEL_PENDING': 'VERIFICAÇÕES PARCIAIS · MODELO LOCAL PENDENTE'}
CATEGORIES = (('RESISTANCE', 'Resistência · verificações locais'),
              ('GEOMETRY', 'Geometria · detalhamento e acesso'),
              ('MODEL', 'Modelo · equilíbrio e limites'))
CHECK_STATUS = {'PASS': 'ATENDE NO ESCOPO', 'FAIL': 'NÃO ATENDE', 'PENDING': 'PENDENTE',
                'PENDING_DEMAND': 'DEMANDA PENDENTE', 'OUTSIDE_SCOPE': 'FORA DO ESCOPO',
                'NOT_APPLICABLE': 'INAPLICÁVEL'}


def _draft_keys():
    keys = [PREFIX + f.name for f in fields(BeamOnBeam) if f.name not in ('beam', 'support')]
    keys += [PREFIX + key for key in LOAD_KEYS.values()]
    for role in ('beam', 'support'):
        keys += [PREFIX + role + '_' + key for key in ('name', 'manual_name', 'family', 'source') + PROFILE_VALUES]
    return keys


def _finite(value):
    try:
        return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)
    except OverflowError:
        return False


def _widget_float(value, name):
    converted = float(value)
    if not math.isfinite(converted) or converted != value:
        raise ValueError(f'{name}: valor {value!r} não representável sem alteração no controle.')
    return converted


def _proposed_ui_state(c):
    """Validate all data before changing state; None remains unknown."""
    c.to_dict()
    proposed = {}
    for f in fields(c):
        if f.name in ('beam', 'support'):
            continue
        value = getattr(c, f.name)
        if isinstance(value, (int, float)) and not isinstance(value, bool) and f.name not in LOAD_UNITS:
            value = _widget_float(value, f.name)
        proposed[PREFIX + f.name] = value
    for key, unit in LOAD_UNITS.items():
        shown = getattr(c, key) / unit
        if not _finite(shown):
            raise ValueError(key + ': ação não representável em kgf / kgf·m.')
        proposed[PREFIX + LOAD_KEYS[key]] = shown
    for role in ('beam', 'support'):
        p = getattr(c, role); prefix = PREFIX + role + '_'
        proposed[prefix + 'name'] = p.name if p.name in P and p == P[p.name] else CUSTOM
        for key, value in [('manual_name', p.name), ('family', p.family), ('source', p.source)]:
            proposed[prefix + key] = value
        for key in PROFILE_VALUES:
            proposed[prefix + key] = _widget_float(getattr(p, key), role + '.' + key)
    return proposed


EXTERNAL_FIELDS = {'contact_resultant', 'contact_x', 'contact_y', 'bolt_tension_1', 'bolt_tension_2',
                   'bolt_tension_3', 'bolt_tension_4', 'external_same_case', 'tensions_include_prying',
                   'local_model_reference', 'project', 'notes'}


def _physical_signature(state):
    """Current physical widget basis, including unrounded displayed force values."""
    force_keys = {PREFIX + key for key in (*LOAD_UNITS, *LOAD_KEYS.values())}
    keys = set(_draft_keys()) - {PREFIX + key for key in EXTERNAL_FIELDS} - force_keys
    basis = {key: state.get(key) for key in sorted(keys)}
    for key, unit in LOAD_UNITS.items():
        raw, shown = state.get(PREFIX + key), state.get(PREFIX + LOAD_KEYS[key])
        try:
            basis['canonical_' + key] = raw if shown == raw / unit else shown * unit
        except (TypeError, ValueError, ArithmeticError):
            basis['canonical_' + key] = {'raw': raw, 'shown': shown}
    return json.dumps(basis, sort_keys=True, ensure_ascii=False)


def seed(c):
    proposed = _proposed_ui_state(c)
    st.session_state.update(proposed)
    st.session_state[STATE + 'declaration_basis'] = _physical_signature(proposed)
    st.session_state.pop(STATE + 'external_reconfirm', None)
    st.session_state.pop(PREFIX + 'report', None)
    st.session_state.pop(STATE + 'ui_draft', None)
    for key in (ALIGNMENT, OFFSET_DRAFT, ALIGNMENT_DRAFT):
        st.session_state.pop(key, None)


def use_example():
    seed(PRESETS[st.session_state[PREFIX + 'example']])
    st.session_state.pop(PREFIX + 'import_error', None)


def _unique_object(pairs):
    data = {}
    for key, value in pairs:
        if key in data:
            raise ValueError('Campo JSON duplicado: ' + str(key))
        data[key] = value
    return data


def load_project():
    try:
        upload = st.session_state[PREFIX + 'upload']
        if upload is None:
            raise ValueError('Selecione um arquivo JSON.')
        payload = upload.getvalue()
        if len(payload) > 200000:
            raise ValueError('Arquivo maior que 200 kB.')
        c = BeamOnBeam.from_dict(json.loads(payload, object_pairs_hook=_unique_object))
        seed(c)
        st.session_state.pop(PREFIX + 'import_error', None)
    except (ValueError, TypeError, KeyError, OverflowError) as exc:
        st.session_state[PREFIX + 'import_error'] = 'Não foi possível abrir: ' + str(exc)


def _select(label, options, key):
    options = list(options)
    current = st.session_state.get(key)
    if current is not None and current not in options:
        options.append(current)
    return st.selectbox(label, options, key=key)


def _dimension(key, label, signed=False):
    return number_input(label + ' (mm)', key=PREFIX + key, **({} if signed else {'min_value': 0.}))


def _optional(key, label, signed=False):
    return number_input(label + ' · em branco = desconhecido', value=None, key=PREFIX + key,
                        **({} if signed else {'min_value': 0.}))


def _alignment_changed():
    s = st.session_state
    current = s[PREFIX + 'reference_x']
    if current is not None and current != 0:
        s[OFFSET_DRAFT] = current
    choice = s[ALIGNMENT]
    s[PREFIX + 'reference_x'] = (0. if choice == 'Sim' else
                                s.get(OFFSET_DRAFT) if choice == 'Não' else None)


def _reference_input():
    s = st.session_state
    current = s[PREFIX + 'reference_x']
    if ALIGNMENT not in s:
        s[ALIGNMENT] = 'Não informado' if current is None else 'Sim' if current == 0 else 'Não'
    choice = st.radio('Nó alinhado ao eixo da viga de apoio?',
                      ['Sim', 'Não', 'Não informado'], key=ALIGNMENT,
                      on_change=_alignment_changed, horizontal=True)
    if choice == 'Não':
        s[OFFSET_DRAFT] = _optional('reference_x', 'Afastamento do nó em relação ao eixo da viga de apoio (mm)', signed=True)
        st.caption('Afastamento com sinal no eixo da viga superior. Em branco, a posição permanece desconhecida; zero representa alinhamento.')
    elif choice == 'Sim':
        st.caption('Alinhamento declarado: afastamento do nó igual a zero. Isso não valida o contato ou o detalhe da ligação.')
    else:
        st.caption('Posição do nó não informada: o afastamento e o momento total transportado permanecem desconhecidos.')


def _profile(role, title):
    prefix = PREFIX + role + '_'
    name = st.selectbox(title, [CUSTOM] + list(P), key=prefix + 'name')
    if name in P:
        p = P[name]
    else:
        with st.expander('Geometria personalizada · ' + title, expanded=True):
            designation = st.text_input('Designação · ' + title, key=prefix + 'manual_name')
            family = st.text_input('Família declarada · ' + title, key=prefix + 'family')
            values = {key: number_input(text + ' · ' + title, min_value=0., key=prefix + key)
                      for key, text in [('d', 'Altura d (mm)'), ('bf', 'Largura bf (mm)'),
                      ('tw', 'Alma tw (mm)'), ('tf', 'Mesa tf (mm)'), ('clear', 'Altura livre das raízes (mm)'),
                      ('area', 'Área A (mm²)'), ('mass', 'Massa linear (kg/m)')]}
            source = st.text_input('Fonte das dimensões/área · ' + title, key=prefix + 'source')
            p = Profile(designation, family, source=source, **values)
    st.caption(f"d={display_format(p.d)}; bf={display_format(p.bf)}; tw={display_format(p.tw)}; tf={display_format(p.tf)} mm.")
    return p


def _force(key):
    raw = st.session_state[PREFIX + key]
    shown = st.session_state[PREFIX + LOAD_KEYS[key]]
    if not _finite(raw) or not _finite(shown):
        raise ValueError(key + ': ação finita obrigatória.')
    if shown == raw / LOAD_UNITS[key]:
        return raw
    converted = shown * LOAD_UNITS[key]
    if not _finite(converted):
        raise ArithmeticError(key + ': transbordamento na conversão para N / N mm.')
    return converted


def _checks_table(checks):
    return pd.DataFrame([{'ID': row.get('id'), 'Verificação': row.get('name'),
        'Demanda': row.get('demand'), 'Resistência / limite': row.get('resistance'),
        'Unidade': row.get('unit'), 'Índice': row.get('eta'),
        'Resultado': CHECK_STATUS.get(row.get('status'), row.get('status')),
        'Equação': row.get('equation'), 'Referência': row.get('reference'),
        'Observações': calculated_text(row.get('notes', ''), assignments_only=True)} for row in checks])


def _input_failure(status, exc):
    s = st.session_state
    s.pop(PREFIX + 'report', None); s.pop(STATE + 'project', None)
    s[STATE + 'result'] = dict(status=status, global_pass=False, checks=[], summary={},
                             issues=[dict(severity='invalid_input', text=str(exc))])
    st.error(STATUS[status]); st.error(str(exc))
    st.caption('Corrija a entrada para recalcular. Nenhum arquivo do cálculo anterior permanece válido.')
    st.button('Gerar memória viga sobre viga', disabled=True)


def render():
    from .beam_on_beam import evaluate
    from .beam_on_beam_drawing import image_bytes, drawing_svg
    s = st.session_state
    if PREFIX + 'project' not in s:
        saved, draft = s.get(STATE + 'project'), s.get(STATE + 'ui_draft')
        alignment_draft = s.get(ALIGNMENT_DRAFT)
        seed(BeamOnBeam.from_dict(saved) if saved else next(iter(PRESETS.values())))
        if draft:
            s.update(draft)
        if alignment_draft:
            s.update(alignment_draft)
    current_basis = _physical_signature(s)
    prior_basis = s.get(STATE + 'declaration_basis')
    if prior_basis is not None and prior_basis != current_basis and s.get(PREFIX + 'external_same_case'):
        s[PREFIX + 'external_same_case'] = False
        s[STATE + 'external_reconfirm'] = True
    s[STATE + 'declaration_basis'] = current_basis
    for key in _draft_keys() + [ALIGNMENT, OFFSET_DRAFT]:
        if key in s:
            s[key] = s[key]
    with st.sidebar:
        st.caption('Componente '+COMPONENT_VERSION+' · identidade técnica preservada; versão do aplicativo na barra lateral')
        st.caption('Revisão da interface: ' + UI_REVISION)
        st.selectbox('Exemplo de viga sobre viga', list(PRESETS), key=PREFIX + 'example')
        st.button('Usar exemplo viga sobre viga', on_click=use_example, use_container_width=True)
        st.file_uploader('Abrir projeto viga sobre viga', type=['json'], key=PREFIX + 'upload')
        st.button('Carregar viga sobre viga', on_click=load_project, use_container_width=True)
        if PREFIX + 'import_error' in s:
            st.error(s[PREFIX + 'import_error'])
    st.title(FAMILY)
    st.caption(SCOPE)
    st.caption('A viga superior termina sobre o apoio; a coordenada física de sua terminação não foi informada. x_ref define somente a seção / nó das ações.')
    st.warning('Dimensões iniciais de tentativa, não dimensionadas nem aprovadas. Sem aprovação da ligação completa ou liberação de fabricação.')
    st.text_input('Identificação do projeto viga sobre viga', key=PREFIX + 'project')
    left, right = st.columns([.9, 1.5], gap='large')
    with left:
        beam = _profile('beam', 'Viga superior W')
        support = _profile('support', 'Viga inferior W')
        number_input('V descendente já majorado (kgf)', key=PREFIX + 'V_kgf')
        number_input('N no eixo da viga superior, com sinal (kgf)', key=PREFIX + 'N_kgf')
        st.caption('Ações simultâneas fornecidas, sem novo coeficiente: V segue por contato; N/4 é o corte horizontal por parafuso no grupo simétrico, sem torção.')
        with st.expander('Alinhamento do nó e transporte das ações', expanded=True):
            _reference_input()
            st.caption('x: eixo da viga superior; y: eixo da viga inferior; z: para cima. Origem na interseção das almas, no topo da mesa inferior. My = N×(d/2+tp) + V×x_ref + My aplicado.')
            st.caption('Sem posição declarada do nó, o termo N×(d/2+tp) permanece calculado; o transporte total continua desconhecido. Não presumir V centrado.')
        with st.expander('Entradas avançadas — momento My e torção Tz',
                         expanded=any(s[PREFIX + key] != 0 or s[PREFIX + LOAD_KEYS[key]] != 0
                                      for key in ('applied_moment_y', 'torsion'))):
            number_input('My aplicado na seção de referência (kgf·m)', key=PREFIX + 'My_kgfm')
            number_input('Tz — torção no plano dos parafusos (kgf·m)', key=PREFIX + 'torsion_kgfm')
            st.caption('Ações aplicadas, preservadas também quando a seção está recolhida. O alinhamento não zera My ou Tz nem elimina as pendências de escopo.')
        with st.expander('Chapa única contínua e quatro parafusos', expanded=True):
            for key, label in [('plate_length', 'Comprimento da chapa · eixo x'), ('plate_width', 'Largura da chapa · eixo y'),
                               ('tp', 'Espessura da chapa'), ('bolt_pitch', 'Passo dos parafusos · eixo x'),
                               ('bolt_gauge', 'Gabarito dos parafusos · eixo y')]:
                _dimension(key, label)
            _select('Diâmetro do parafuso (mm)', [16., 20., 24., 30.], PREFIX + 'db')
            _dimension('hole_diameter', 'Diâmetro físico do furo')
            _select('Classe dos parafusos', list(BOLTS), PREFIX + 'bolt')
            st.checkbox('Rosca excluída e documentada no plano de corte', key=PREFIX + 'threads_excluded')
            st.checkbox('Furo de broca documentado', key=PREFIX + 'drilled')
            st.caption('Um plano de corte por parafuso; chapa e mesa inferior são verificadas separadamente à pressão nos furos.')
        with st.expander('Solda da chapa à viga superior'):
            _dimension('weld_leg', 'Perna dos dois filetes longitudinais')
            _dimension('weld_length', 'Comprimento declarado de cada linha de solda')
            number_input('Resistência do eletrodo fuw (MPa)', min_value=0., key=PREFIX + 'electrode_fuw')
            st.caption('O cálculo horizontal não aprova a transferência normal/momento na solda. Comprimento útil e término real exigem conferência do detalhe.')
        with st.expander('Par de enrijecedores na viga inferior', expanded=True):
            st.checkbox('Dois enrijecedores, um de cada lado da alma inferior', key=PREFIX + 'stiffeners')
            for key, label in [('stiffener_t', 'Espessura de cada enrijecedor'), ('stiffener_width', 'Largura saliente de cada enrijecedor'),
                               ('stiffener_height', 'Altura de cada enrijecedor'), ('stiffener_clip', 'Recorte de concordância'),
                               ('stiffener_weld', 'Perna da solda dos enrijecedores')]:
                _dimension(key, label)
            _dimension('stiffener_y', 'Posição do par no eixo y inferior', signed=True)
            st.caption('Verificação dimensional apenas. O par não recebe resistência automática nem V/2 por placa.')
        with st.expander('Materiais, ferragens e acesso real'):
            for role, label in [('beam', 'Aço da viga superior'), ('support', 'Aço da viga inferior'),
                                ('plate', 'Aço da chapa'), ('stiffener', 'Aço dos enrijecedores')]:
                _select(label, list(STEELS), PREFIX + role + '_steel')
            _optional('support_end_negative', 'Cruzamento até extremidade da inferior em −y (mm)')
            _optional('support_end_positive', 'Cruzamento até extremidade da inferior em +y (mm)')
            _optional('support_root_radius', 'Raio real de concordância da viga inferior (mm)')
            _optional('tool_radius', 'Raio real de ferramenta / soquete (mm)')
            _dimension('fabrication_clearance', 'Folga adicional de fabricação')
            st.caption('Envelope mínimo de ferragem não é raio de ferramenta. Campo vazio conserva o acesso pendente; conferir também acesso axial e montagem.')
        with st.expander('Transferência local fora do plano · dados externos opcionais'):
            st.caption('O responsável técnico deve validar as demandas externas para as ações, geometria, materiais e detalhe dos enrijecedores ATUAIS. Valores ausentes ficam desconhecidos. C/T informados permitem checar equilíbrio, mas não certificam compatibilidade, contato/flexão ou alavanca.')
            if s.get(STATE + 'external_reconfirm') and not s[PREFIX + 'external_same_case']:
                st.info('Uma entrada física foi alterada. Revise os dados externos e confirme novamente sua aplicação à entrada atual. Os números externos foram preservados.')
            _optional('contact_resultant', 'Resultante de contato C (N)')
            _optional('contact_x', 'Centro de contato x_c (mm)', signed=True)
            _optional('contact_y', 'Centro de contato y_c (mm)', signed=True)
            for index, coord in enumerate((('−x', '−y'), ('+x', '−y'), ('−x', '+y'), ('+x', '+y')), 1):
                _optional('bolt_tension_' + str(index), f'Tração total T{index} em ({coord[0]}, {coord[1]}) (N)')
            st.checkbox('Confirmo dados externos para ações, geometria, materiais e enrijecedores atuais', key=PREFIX + 'external_same_case')
            st.checkbox('As quatro trações fornecidas incluem alavanca explicitamente', key=PREFIX + 'tensions_include_prying')
            st.text_input('Referência do modelo externo / caso simultâneo', key=PREFIX + 'local_model_reference')
        with st.expander('Hipóteses e escopo'):
            st.checkbox('Ações estáticas, sem impacto ou fadiga', key=PREFIX + 'static')
            st.checkbox('Combinação última normal', key=PREFIX + 'normal_combination')
            st.checkbox('Projeto exige ausência de deslizamento', key=PREFIX + 'no_slip_required')
        st.text_area('Observações / proveniência das ações', key=PREFIX + 'notes')
    s[STATE + 'ui_draft'] = {key: s[key] for key in _draft_keys() if key in s}
    s[ALIGNMENT_DRAFT] = {key: s[key] for key in (ALIGNMENT, OFFSET_DRAFT) if key in s}
    try:
        values = {f.name: s[PREFIX + f.name] for f in fields(BeamOnBeam)
                  if f.name not in ('beam', 'support', *LOAD_UNITS)}
        c = BeamOnBeam(beam=beam, support=support, **{key: _force(key) for key in LOAD_UNITS}, **values)
        native = c.to_dict()
        encoded = json.dumps(native, ensure_ascii=False, indent=2, allow_nan=False)
        r = evaluate(c)
    except ArithmeticError as exc:
        with right: _input_failure('NUMERICAL_FAILURE', exc)
        return
    except (ValueError, TypeError, KeyError) as exc:
        with right: _input_failure('INVALID_INPUT', exc)
        return
    digest = hashlib.sha256(encoded.encode()).hexdigest()
    s[STATE + 'project'] = native; s[STATE + 'result'] = r
    if s.get(PREFIX + 'report', ('', '', b''))[0] != digest:
        s.pop(PREFIX + 'report', None)
    status = r.get('status'); checks = r.get('checks') or []
    artifact_ok = status not in ('INVALID_INPUT', 'NUMERICAL_FAILURE')
    if not artifact_ok:
        s.pop(PREFIX + 'report', None)
    with right:
        st.warning('SEM APROVAÇÃO DA LIGAÇÃO COMPLETA')
        st.caption(STATUS.get(status, status))
        passed = sum(row.get('status') == 'PASS' for row in checks)
        failed = sum(row.get('status') == 'FAIL' for row in checks)
        st.write(f'Verificações locais: {passed} atendem no escopo; {failed} não atendem. Consulte as pendências de geometria e modelo separadamente.')
        moment_n = c.N * (c.beam.d / 2 + c.tp)
        a, b = st.columns(2)
        a.metric('Parcela My de N×h (kN·m)', display_format(moment_n / 1e6))
        b.metric('Corte horizontal nominal N/4 (kN)', display_format(c.N / 4000) if c.torsion == 0 else 'Fora do domínio')
        if c.reference_x is None:
            st.caption('My total: desconhecido, pois x_ref não foi informado.')
        if artifact_ok:
            st.image(image_bytes(c, r), width='stretch')
        for issue in r.get('issues') or []:
            severity = str(issue.get('severity', '')).lower()
            action = st.error if severity in ('invalid_input', 'numerical_failure', 'invalid_geometry', 'detail_fail', 'error') else st.caption if severity == 'info' else st.warning
            action(calculated_text(issue.get('text', ''), assignments_only=True))
        with st.expander('Caminho das ações e transporte ao apoio'):
            st.write('V descendente → contato entre mesa superior, chapa única e mesa inferior. N horizontal → soldas → chapa → quatro parafusos em corte simples → mesa inferior. A parcela N×h é mantida; não se presume tração nula nem alavanca nula.')
            st.json(display_tree(r.get('load_model') or {}), expanded=False)
        st.caption('Estabilidade global, contraventamento e dimensionamento global das vigas pertencem ao projeto estrutural; os resultados locais não liberam fabricação ou montagem.')
    for category, title in CATEGORIES:
        st.subheader(title)
        rows = [row for row in checks if row.get('category') == category]
        if rows:
            st.dataframe(display_frame(_checks_table(rows)), hide_index=True, width='stretch')
        else:
            st.caption('Sem verificação calculada nesta categoria.')
    with st.expander('Fórmulas, módulos e registros completos · apresentação em duas casas'):
        st.json(display_tree({key: r.get(key) for key in ('checks', 'geometry', 'load_model', 'summary', 'modules')}), expanded=False)
    a, b, d = st.columns(3)
    a.download_button('Salvar projeto viga sobre viga .json', encoded, 'viga_sobre_viga.json', 'application/json')
    if artifact_ok:
        b.download_button('Baixar croquis viga sobre viga .svg', drawing_svg(c, r), 'viga_sobre_viga.svg', 'image/svg+xml')
    if d.button('Gerar memória viga sobre viga', disabled=not artifact_ok, use_container_width=True):
        from .beam_on_beam_report import build_docx
        s[PREFIX + 'report'] = (digest, 'memoria_viga_sobre_viga.docx', build_docx(c))
    if PREFIX + 'report' in s:
        _, filename, payload = s[PREFIX + 'report']
        st.download_button('Baixar memória viga sobre viga .docx', payload, filename,
                           'application/vnd.openxmlformats-officedocument.wordprocessingml.document')
