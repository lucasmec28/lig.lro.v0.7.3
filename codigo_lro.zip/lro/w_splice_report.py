from .display_precision import calculated_text
"""Editable calculation record for the actual eight-cover M004 W splice.

No rounded display value is used to recalculate a result. Unsupported and
pending evaluations remain available as explicitly unapproved diagnostic
reports, rather than being converted into an aggregate pass.
"""
from .display_precision import display_format, display_value
from collections import OrderedDict
from io import BytesIO
from math import isfinite

from docx import Document
from docx.enum.section import WD_ORIENT, WD_SECTION_START
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Inches, Pt, RGBColor

from .models import KGF, STEELS, VERSION
from .report import BRAND, LINK, _math, display, group, hyperlink, number, table
from .w_splice import COMPONENT_VERSION, EXCLUSIONS, NBR, SCOPE, evaluate
from .w_splice_drawing import image_bytes

COMPONENTS = OrderedDict([
    ('web_cover_negative', ('W1', 'Tala de alma lado −z')),
    ('web_cover_positive', ('W2', 'Tala de alma lado +z')),
    ('outer_top', ('F1', 'Tala externa superior')),
    ('inner_top_negative', ('F2', 'Tira interna superior −z')),
    ('inner_top_positive', ('F3', 'Tira interna superior +z')),
    ('outer_bottom', ('F4', 'Tala externa inferior')),
    ('inner_bottom_negative', ('F5', 'Tira interna inferior −z')),
    ('inner_bottom_positive', ('F6', 'Tira interna inferior +z')),
    ('member_flange_top', ('MS', 'Mesa superior do membro')),
    ('member_flange_bottom', ('MI', 'Mesa inferior do membro')),
    ('member_web', ('AM', 'Alma do membro')),
    ('whole_member', ('W', 'Seção W completa')),
])
STATUS = {
    'INVALID_INPUT': 'Entrada inválida',
    'NUMERICAL_FAILURE': 'Falha de avaliação numérica',
    'INVALID_GEOMETRY': 'Geometria inválida',
    'OUTSIDE_BALANCED_M004_SCOPE': 'Fora do domínio M004 balanceado',
    'NOT_EVALUATED': 'Sem avaliação resistente',
    'ENGINEERING_MODEL_PENDING': 'Verificação completa pendente',
    'VERIFIED_SUBCHECK_FAIL': 'Há verificação resistente não atendida',
    'DETAIL_FAIL': 'Há requisito de detalhamento não atendido',
    'COMPLETE_CHECKS_PASS_WITH_PRESET_DEVIATION': 'Verificações atendidas no domínio com desvio do padrão de oficina',
    'COMPLETE_CHECKS_PASS_WITHIN_SCOPE': 'Verificações atendidas no domínio declarado',
}
SEVERITY = {
    'invalid_input':'Entrada inválida', 'invalid_geometry':'Geometria inválida',
    'numerical_failure':'Falha numérica, sem conclusão resistente',
    'unsupported_scope':'Fora do domínio', 'engineering_pending':'Pendência técnica',
    'access_pending':'Acesso pendente', 'detail_fail':'Detalhamento não atendido',
    'preset_deviation':'Desvio do padrão de oficina', 'warning':'Ressalva',
    'info':'Informação', 'not_evaluated':'Não avaliado',
}


def _num(value, places=3):
    if isinstance(value, bool) or not isinstance(value, (int,float)) or not isfinite(value):
        return 'não disponível'
    if abs(value)>=1e12 or (value!=0 and abs(value)<1e-8):
        return display_format(value,'.12g').replace('.',',')
    return number(value,places)


def _force(value):
    if isinstance(value, bool) or not isinstance(value, (int,float)) or not isfinite(value):
        return 'não disponível'
    return _num(value/KGF,2)


def _mapping(value):
    return value if isinstance(value,dict) else {}


def _name(key):
    if key in COMPONENTS:
        code,label=COMPONENTS[key]
        return code+'  '+label
    if key.startswith('bolt_'):
        return 'Parafusos '+key[5:].replace('_',' ')
    return str(key)


def _tab(doc, headers, rows, widths, size=8.3):
    """Use the existing report table style with readable, explicit widths."""
    out=table(doc,headers,rows,widths)
    for row in out.rows:
        for j,cell in enumerate(row.cells):
            for paragraph in cell.paragraphs:
                if j==0:
                    paragraph.alignment=WD_ALIGN_PARAGRAPH.LEFT
                for run in paragraph.runs:
                    run.font.size=Pt(size)
    return out


def _section(doc, landscape=False):
    section=doc.add_section(WD_SECTION_START.NEW_PAGE)
    section.orientation=WD_ORIENT.LANDSCAPE if landscape else WD_ORIENT.PORTRAIT
    section.page_width=Inches(11.69 if landscape else 8.27)
    section.page_height=Inches(8.27 if landscape else 11.69)
    section.top_margin=section.bottom_margin=Inches(.52)
    section.left_margin=section.right_margin=Inches(.6)
    return section


def _issues(doc, issues):
    doc.add_paragraph('Pendências e condições de uso',style='Heading 1')
    if not issues:
        doc.add_paragraph('Nenhuma ocorrência foi fornecida pelo motor nesta avaliação. Esse fato não amplia o domínio declarado.')
    for issue in issues:
        item=_mapping(issue)
        paragraph=doc.add_paragraph()
        paragraph.add_run(SEVERITY.get(item.get('severity'),str(item.get('severity','Ocorrência')))+': ').bold=True
        paragraph.add_run(calculated_text(item.get('text','Sem descrição.'), assignments_only=True))
        reference=item.get('reference')
        if reference:
            paragraph.add_run(' Referência: '+str(reference)+'.')


def _geometry(doc,c,r):
    p=c.profile;g=_mapping(r.get('geometry'))
    inner=getattr(c,'include_inner_flange_plates',True)
    d14=g.get('table14_max_hole_mm',{16.:18.,20.:22.,24.:27.,30.:33.}.get(c.db,c.hole_diameter))
    dn=g.get('dn',d14+(0 if c.drilled else 2))
    doc.add_paragraph('Dimensões materiais e montagem',style='Heading 1')
    lf=g.get('flange_length_mm',c.gap+2*(c.flange_member_end+(c.flange_rows-1)*c.flange_pitch+c.flange_cover_end))
    lw=g.get('web_length_mm',c.gap+2*(c.web_member_end+(c.web_rows-1)*c.web_pitch+c.web_cover_end))
    rows=[
        ('Dois membros idênticos',p.name,f'd={display_value(_num(p.d))}; bf={display_value(_num(p.bf))}; tw={display_value(_num(p.tw))}; tf={display_value(_num(p.tf))}',c.member_steel),
        ('W1 W2','2 talas contínuas',f'L={display_value(_num(lw))}; h={display_value(_num(c.web_height))}; t={display_value(_num(c.web_t))}',c.web_steel),
        ('F1 F4','2 talas externas',f'L={display_value(_num(lf))}; b={display_value(_num(c.flange_outer_width))}; t={display_value(_num(c.flange_t))}',c.flange_steel),
        *([('F2 F3 F5 F6','4 tiras internas',f'L={display_value(_num(lf))}; b={display_value(_num(c.flange_inner_width))}; t={display_value(_num(c.flange_t))}',c.flange_steel),
           ('Faixa central','Entre tiras internas',f'c={display_value(_num(c.inner_clear_band))}; g mesas={display_value(_num(c.inner_clear_band + c.flange_inner_width))}','Sem calço ou solda participante')] if inner else
          [('Gramil das mesas','Parafusos nas talas externas','g mesas='+_num(c.flange_bolt_gauge),'Sem calço ou solda participante')]),
        ('Folga entre membros','Junta em x=0',f'g={display_value(_num(c.gap))}','Talas contínuas através da junta'),
        ('Parafusos',c.bolt,f'db={display_value(_num(c.db))}; dh real={display_value(_num(c.hole_diameter))}; d14={display_value(_num(d14))}; dn={display_value(_num(dn))}','2 planos de corte' if inner else 'Mesas: 1 plano; alma: 2 planos'),
        ('Alma por lado',f'{display_value(c.web_rows)} × {display_value(c.web_levels)} parafusos',f'p={display_value(_num(c.web_pitch))}; g={display_value(_num(c.web_gauge))}; e membro={display_value(_num(c.web_member_end))}; e tala={display_value(_num(c.web_cover_end))}','Dois lados em série'),
        ('Cada mesa por lado',f'{display_value(c.flange_rows)} × 2 parafusos',f'p={display_value(_num(c.flange_pitch))}; e membro={display_value(_num(c.flange_member_end))}; e tala={display_value(_num(c.flange_cover_end))}','Mesas superior e inferior'),
        ('Raiz e fabricação','Envelope declarado',f'r={display_value(_num(c.root_radius))}; folga={display_value(_num(c.fabrication_clearance))}; raio ferramenta={display_value(_num(c.tool_radius))}','Confirmar fabricação e acesso'),
    ]
    _tab(doc,['Componente','Identificação','Dimensões em mm','Material ou condição'],rows,[1.15,1.65,2.55,1.72])
    doc.add_paragraph('Área bruta de catálogo A='+_num(p.area)+' mm²; altura livre declarada='+_num(p.clear)+' mm. Fonte da seção: '+str(p.source))
    materials=[]
    for name in dict.fromkeys((c.member_steel,c.flange_steel,c.web_steel)):
        steel=STEELS.get(name)
        if steel:
            materials.append(f'{display_value(name)}: fy={display_value(_num(steel.fy))} MPa; fu={display_value(_num(steel.fu))} MPa')
        else:
            materials.append(str(name)+': material não cadastrado')
    doc.add_paragraph('; '.join(materials)+'. γa1=1,10; γa2=1,35. Os limites de produto e espessura do cadastro permanecem aplicáveis.')
    doc.add_paragraph(('Rosca excluída dos dois planos de corte: ' if inner else 'Rosca excluída de todos os planos ativos (1 nas mesas; 2 na alma): ')+('verificada na entrada' if c.threads_excluded_verified else 'não; coeficiente de rosca incluída')+'. Furo físico adotado dh='+_num(c.hole_diameter)+' mm, usado no desenho e no contato. Base normativa da dedução: maior diâmetro circular d14='+_num(d14)+' mm da Tabela 14. Dedução líquida dn='+_num(dn)+' mm: '+('dn=d14, furação por broca declarada' if c.drilled else 'dn=d14+2 mm')+'. O furo físico e a base normativa são registrados separadamente.')
    doc.add_paragraph('Exposição: '+str(c.exposure)+'. Ações estáticas: '+('sim' if c.static else 'não')+'. Combinação última normal: '+('sim' if c.normal_combination else 'não')+('. Concentricidade: ' if inner else '. Membros coaxiais: ')+('sim' if c.concentric else 'não')+'. Exigência de ausência de deslizamento: '+('sim' if c.no_slip_required else 'não')+'.')
    dims=[('Folga interna até tala da alma','inner_to_web_cover_clearance_mm'),
          ('Folga tala de alma até tiras de mesa','web_to_inner_cover_clearance_mm'),
          ('Folga tala de alma até mesa do membro','web_to_member_flange_clearance_mm'),
          ('Borda lateral da tala externa','flange_outer_edge_mm'),
          ('Borda lateral da tira interna','inner_strip_edge_mm'),
          ('Pega nos parafusos da mesa','flange_grip_mm'),('Pega nos parafusos da alma','web_grip_mm')]
    rows=[(label,_num(g[key])) for label,key in dims if key in g]
    if rows:
        _tab(doc,['Geometria derivada','Valor em mm'],rows,[5.2,1.87])
    failures=[x for x in g.get('checks',[]) if isinstance(x,dict) and not x.get('passed',False)]
    if failures:
        doc.add_paragraph('Critérios geométricos não atendidos',style='Heading 2')
        _tab(doc,['Critério','Valor','Exigência','Categoria'],[(x.get('id',''),_num(x.get('actual')),str(x.get('relation',''))+' '+_num(x.get('limit')),x.get('category','')) for x in failures],[3.9,1.0,1.05,1.12])
    doc.add_paragraph(('O afastamento de 10 mm do desenho M004 é uma referência de oficina. ' if inner else 'Detalhe convencional somente com talas externas; a folga das talas de alma é medida até as mesas reais do W. ')+ 'Geometria, folgas de fabricação e acesso são verificações distintas. Desvios não são corrigidos ou ocultados no desenho.')


def _loads(doc,c,r):
    lm=_mapping(r.get('load_model'));p=c.profile
    doc.add_paragraph('Ações e partilha equilibrada',style='Heading 1')
    input_rows=[('Nsd informado',_force(c.N),'kgf'),('M informado',_num(c.M/(KGF*1000),2),'kgf·m'),
                ('V informado',_force(c.V),'kgf'),('T informado',_num(c.torsion/(KGF*1000),2),'kgf·m')]
    if getattr(c,'minimum_action_policy','')=='slenderness':
        input_rows.append(('Nc,Rd externo informado',_force(getattr(c,'compression_resistance',None)),'kgf'))
    if lm:
        input_rows.extend([('Nd adotado na conferência',_force(lm.get('Nd_N')),'kgf'),
                           ('Piso do conjunto',_force(lm.get('assembly_minimum_N',45000.)),'kgf'),
                           ('Alvo da recomendação adotada',_force(lm.get('member_recommendation_N')),'kgf')])
    _tab(doc,['Ação ou critério','Valor','Unidade'],input_rows,[4.2,1.65,1.22])
    doc.add_paragraph('As ações informadas já são de cálculo. O módulo não aplica fatores de carga. N positivo indica tração; somente N>0 e M=V=T=0 pertencem ao domínio resistente desta família.')
    integrity=getattr(c,'integrity_included',False)
    doc.add_paragraph('Ações de integridade incluídas no Nsd informado: '+('sim, premissa explicitamente declarada na entrada' if integrity else 'não; premissa pendente que impede aprovação global')+'. O módulo não calcula as ações de integridade nem verifica a integridade global da estrutura.')
    if getattr(c,'compression_reference',''):
        doc.add_paragraph('Referência externa de Nc,Rd: '+str(c.compression_reference))
    if not lm:
        doc.add_paragraph('Partilha resistente não executada nesta avaliação. Não se atribuem capacidades ou índices favoráveis às peças.')
        return
    doc.add_paragraph(str(lm.get('minimum_note','Política de resistência mínima não descrita pelo resultado.')))
    sources={'actual_N':'N real solicitado','mandatory_45kN_floor':'piso obrigatório de 45 kN','selected_member_recommendation':'recomendação selecionada do membro'}
    doc.add_paragraph('Origem de Nd: '+sources.get(lm.get('adopted_action_source'),'não disponível')+'. '+str(lm.get('monotone_envelope','')))
    if not lm.get('adopted_action_complete',False):
        doc.add_paragraph('Envelope suplementar incompleto. Pendências: '+', '.join(lm.get('recommendation_missing_fields',[]))+'. Os índices apresentados não encerram a recomendação selecionada.').runs[0].bold=True
    doc.add_paragraph('O piso de 45 kN é aplicado uma única vez ao conjunto, antes da partilha. A recomendação de resistência do membro é uma escolha explicitada da avaliação e não deve ser apresentada como uma exigência universal de 50%.')
    _math(doc,group('Aw = tw (d − 2tf);   Af,alocada = (A − Aw)/2;   αw = Aw/A'))
    _math(doc,group('Nw = αw Nd;   Fmesa = (1 − αw) Nd/2'))
    _math(doc,group('Fexterna = Fmesa/2;   Finterna = Fmesa/4;   Ftala,alma = Nw/2'))
    _tab(doc,['Propriedade de partilha','Valor'],[
        ('A de catálogo em mm²',_num(p.area,6)),('Aw retangular em mm²',_num(lm.get('Aw_mm2'),6)),
        ('Af alocada por mesa em mm²',_num(lm.get('Af_allocated_mm2'),6)),
        ('Af retangular local por mesa em mm²',_num(lm.get('Af_local_rectangular_mm2',p.bf*p.tf),6)),
        ('αw',_num(lm.get('alpha_web'),9)),('Resíduo Nd − Nw − 2Fmesa em N',_num(lm.get('equilibrium_residual_N'),9))],[4.6,2.47])
    doc.add_paragraph(str(lm.get('allocation','As áreas das raízes remanescentes da partilha são alocadas às mesas. A resistência local das mesas usa a área retangular, sem crédito adicional das raízes.')))
    doc.add_paragraph('As extremidades esquerda e direita trabalham em série. Cada extremidade transfere a mesma força; as capacidades dos dois lados não são somadas. As oito talas são peças contínuas e não dezesseis chapas interrompidas na junta.')
    data=_mapping(r.get('components'))
    rows=[]
    nd=lm.get('Nd_N');real=lm.get('Nsd_N',c.N)
    scale=real/nd if isinstance(nd,(int,float)) and nd>0 else None
    for key,(code,label) in COMPONENTS.items():
        if key=='whole_member' or key not in data:
            continue
        value=_mapping(data[key]);force=value.get('force_N')
        actual=force*scale if scale is not None and isinstance(force,(int,float)) else None
        rows.append((code+' '+label,_num(value.get('Ag_mm2')),_num(value.get('An_mm2')),
                     _num(value.get('Ae_mm2')),_force(actual),_force(force)))
    if rows:
        doc.add_paragraph('Forças em cada componente físico',style='Heading 2')
        _tab(doc,['Peça','Ag mm²','An mm²','Ae mm²','Nsd kgf','Nd kgf'],rows,[2.15,.97,.97,.97,1.,1.01])
    doc.add_paragraph('Nsd nas peças corresponde à entrada real. Nd nas peças corresponde à conferência governante com a política mínima adotada. As parcelas por furo e por bloco usam o subconjunto de parafusos definido em cada linha; não se aplica um piso separado por peça.')
    groups=_mapping(r.get('bolts')).get('physical_groups',[])
    if groups:
        doc.add_paragraph('Seis grupos físicos de parafusos',style='Heading 2')
        _tab(doc,['Grupo','Qtd.','Força grupo kgf','Por parafuso kgf','Por plano kgf'],
             [(x.get('id',''),x.get('bolt_count',''),_force(x.get('group_force_N')),_force(x.get('each_bolt_force_N')),_force(x.get('each_plane_force_N'))) for x in groups],
             [2.05,.70,1.44,1.44,1.44])
        doc.add_paragraph('Total físico: '+str(_mapping(r.get('bolts')).get('total_bolts','não disponível'))+' parafusos. O valor por plano se refere a uma das duas interfaces de corte do mesmo parafuso.')


GROUP_LABELS={
    'member_flanges':'Mesas do membro (2)', 'member_web':'Alma do membro',
    'outer_covers':'Talas externas (2)', 'inner_strips':'Tiras internas (4)',
    'web_covers':'Talas da alma (2)', 'whole_member':'W completo',
    'flange_bolt_planes':'Parafusos das mesas', 'web_bolt_planes':'Parafusos da alma',
}
MECHANISMS={'section':'Seção bruta/líquida','bearing':'Contato/rasgamento','block':'Blocos U/L','bolt_shear':'Planos de corte'}


def _envelopes(doc,r):
    groups=r.get('check_groups',[])
    if not groups:
        return
    doc.add_paragraph('Síntese por componente físico e mecanismo',style='Heading 1')
    doc.add_paragraph(f"{display_value(len(groups))} envelopes de apresentação; {display_value(len(r['checks']))} linhas primitivas preservadas no apêndice. Cada envelope usa integralmente a linha de maior índice, incluindo sua própria solicitação, resistência, fração e caminho. A quantidade de peças ou de lados em série nunca multiplica a resistência.")
    rows=[]
    for item in groups:
        row=item['governing']
        rows.append((GROUP_LABELS.get(item['component_class'],item['component_class'])+'\n'+MECHANISMS[item['mechanism']],
                     row['id'],_force(row['actual_demand_N'])+'\n'+_force(row['demand_N']),
                     _force(row['design_capacity_N']),_num(row['actual_utilization'],6)+'\n'+_num(row['utilization'],6),
                     'Falha' if row['status']=='FAIL' else 'Atende'))
    _tab(doc,['Componente / mecanismo','ID governante','N real / Nd kgf','Rd kgf','η real / Nd','Linha'],rows,[1.44,2.2,.93,.83,.96,.51],size=7.8)
    doc.add_paragraph('Seção, contato e bloco não são mecanismos intercambiáveis. A soma normativa de contato é dominada pelos furos com partilha igual somente neste modelo axial. Simetria de peças, equivalência de índices brutos W/alma e seções de talas balanceadas não eliminam os caminhos de bloco nem aumentam capacidades. Todas as equações e todos os IDs permanecem abaixo.')


def _checks(doc,c,r):
    checks=[x for x in r.get('checks',[]) if isinstance(x,dict)]
    doc.add_paragraph('Fórmulas e referências das verificações',style='Heading 1')
    if not checks:
        doc.add_paragraph('Não há verificações resistentes calculadas. As pendências e os dados de entrada definem os impedimentos desta avaliação.')
        return
    formulas=OrderedDict()
    for row in checks:
        key=(str(row.get('formula','Fórmula não fornecida')),str(row.get('reference','Referência não fornecida')))
        if key not in formulas:
            formulas[key]='E'+str(len(formulas)+1)
    for (formula,reference),code in formulas.items():
        p=doc.add_paragraph(code,style='Heading 2')
        p.paragraph_format.keep_with_next=True
        _math(doc,group(formula))
        doc.add_paragraph(reference)
    doc.add_paragraph('Ag, An e Ae são as áreas bruta, líquida e efetiva. Agv e Anv são as áreas bruta e líquida ao corte; Ant é a área líquida à tração do bloco. fy, fu e fub são as resistências características dos materiais; γa1 e γa2 são os coeficientes de resistência. db é o diâmetro do parafuso; dh é o furo real; dn é a dedução líquida; lc é o ligamento livre de contato; Ab é a área nominal do parafuso. Nas fórmulas de contato e blocos, n é a quantidade de linhas e m, a quantidade de colunas; na fórmula de corte duplo 2n, n é a quantidade total de parafusos do grupo. α é o coeficiente resistente do parafuso, distinto de αw, a fração de força da alma.')
    doc.add_paragraph('Blocos U e L usam cada prefixo e espelho fisicamente admitido. Nos caminhos, k é o número de linhas e m o número de colunas incluídas; a solicitação é a fração k·m/(n·m total) da força do componente. Cts corresponde à distribuição de tensão adotada. As interfaces alma–mesa do membro não são bordas livres. Talas contínuas usam a borda externa real, e não a folga da junta, como borda de arrancamento.')
    doc.add_paragraph('Apêndice · todas as verificações primitivas calculadas',style='Heading 1')
    doc.add_paragraph(f'Total de {display_value(len(checks))} linhas. Rd é a resistência de cálculo da própria linha; Nsd e Nd são as suas solicitações, após a fração de transferência correspondente. η=solicitação/Rd. O resultado da linha vem do motor com valores não arredondados; um índice exibido próximo de 1 não altera o seu estado. As fórmulas E1 em diante são referenciadas em cada linha.')
    lm=_mapping(r.get('load_model'));nd=lm.get('Nd_N');scale=c.N/nd if isinstance(nd,(int,float)) and nd>0 else None
    grouped=OrderedDict()
    for row in checks:
        grouped.setdefault(row.get('component','Sem componente'),[]).append(row)
    for component,items in grouped.items():
        doc.add_paragraph(_name(component),style='Heading 2')
        rows=[]
        for row in items:
            d=row.get('demand_N');eta=row.get('utilization')
            actual=row.get('actual_demand_N',d*scale if scale is not None and isinstance(d,(int,float)) else None)
            aet=row.get('actual_utilization',eta*scale if scale is not None and isinstance(eta,(int,float)) else None)
            fkey=(str(row.get('formula','Fórmula não fornecida')),str(row.get('reference','Referência não fornecida')))
            state={'PASS':'Atende','FAIL':'Falha'}.get(row.get('status'),str(row.get('status','Não avaliado')))
            rows.append((str(row.get('label',''))+'\n'+str(row.get('id','')), _force(actual),_force(d),
                         _force(row.get('design_capacity_N')),_num(aet,6)+'\n'+_num(eta,6),state,formulas[fkey]))
        _tab(doc,['Verificação e ID','Nsd kgf','Nd kgf','Rd kgf','η real\nη Nd','Linha','Eq'],rows,[2.52,.82,.82,.82,.96,.64,.49],size=7.8)
    # Explicit machine identifiers and all formulas remain in the DOCX XML;
    # no row, failure or pending issue is filtered out for presentation.
    governing_id=_mapping(r.get('summary')).get('governing_check_id')
    governing=next((x for x in checks if x.get('id')==governing_id),None)
    if governing:
        doc.add_paragraph('Detalhe da verificação governante',style='Heading 1')
        doc.add_paragraph(str(governing.get('id'))+' | '+str(governing.get('label','')))
        _math(doc,group(str(governing.get('formula',''))))
        rows=[('Solicitação da conferência em N',governing.get('demand_N')),
              ('Resistência de cálculo da linha em N',governing.get('design_capacity_N')),
              ('Índice sem conversão de unidades',governing.get('utilization')),
              ('Fração da força total na linha',governing.get('demand_fraction_of_total_N')),
              ('Capacidade equivalente referida a N total em N',governing.get('equivalent_total_N_capacity_N'))]
        for key in ('Ag_mm2','An_mm2','Ae_mm2','Agv_mm2','Anv_mm2','Ant_mm2','Cts','clear_distance_mm','each_plane_capacity_N','each_plane_demand_N'):
            if key in governing:
                rows.append((key,governing[key]))
        _tab(doc,['Grandeza','Valor com seis casas decimais'],[(label,_num(value,6)) for label,value in rows],[4.65,2.42])
        doc.add_paragraph('A capacidade equivalente é Rd dividido pela fração de solicitação desta linha. Serve à comparação das verificações calculadas e não elimina pendências, requisitos de detalhamento, condições de montagem ou exclusões.')


def create_report(c,r=None):
    """Reevaluate current immutable inputs; caller results cannot authorize output.

    The optional result argument is retained for API compatibility but ignored.
    A digest is diagnostic metadata only, never a substitute for recalculation.
    """
    r=evaluate(c)
    doc=Document();sec=doc.sections[0]
    sec.page_width=Inches(8.27);sec.page_height=Inches(11.69)
    sec.top_margin=sec.bottom_margin=Inches(.52)
    sec.left_margin=sec.right_margin=Inches(.6)
    for name in ('Normal','Title','Subtitle','Heading 1','Heading 2'):
        style=doc.styles[name]
        style.font.name='Arial';style.font.color.rgb=RGBColor(0,0,0)
    for style in doc.styles:
        for border in style.element.xpath('.//w:pBdr'):
            border.getparent().remove(border)
    doc.styles['Normal'].font.size=Pt(9)
    doc.styles['Normal'].paragraph_format.space_after=Pt(5)
    doc.styles['Title'].font.size=Pt(21)
    doc.styles['Subtitle'].font.size=Pt(11)
    doc.styles['Heading 1'].font.size=Pt(12)
    doc.styles['Heading 1'].paragraph_format.space_before=Pt(10)
    doc.styles['Heading 2'].font.size=Pt(10)
    doc.styles['Heading 2'].paragraph_format.space_before=Pt(7)
    doc.core_properties.title='Memória de cálculo da emenda W M004 em tração axial'
    doc.core_properties.author='LRO Soluções de engenharia LTDA.'
    doc.core_properties.subject='Oito talas contínuas com duas extremidades em série'
    doc.core_properties.identifier=r['input_digest']
    doc.add_paragraph('Memória de cálculo da emenda W M004',style='Title')
    doc.add_paragraph('Tração axial com oito talas contínuas',style='Subtitle')
    doc.add_paragraph(str(c.project))
    doc.add_paragraph(c.profile.name+' | Aplicativo '+VERSION+' | Esquema '+COMPONENT_VERSION)
    status=str(r.get('status','RESULTADO INCOMPLETO'));summary=_mapping(r.get('summary'));scope=_mapping(r.get('scope'))
    p=doc.add_paragraph()
    p.add_run(STATUS.get(status,status)).bold=True
    doc.add_paragraph('Estado do motor: '+status+'.')
    doc.add_paragraph('Entrada recalculada na geração. SHA256: '+r['input_digest'])
    doc.add_paragraph('Esta memória registra a geometria, a partilha das ações e todas as verificações calculadas de uma emenda real entre dois perfis W idênticos e coaxiais. O domínio é limitado a N>0, M=V=T=0, em tração axial estática. A avaliação não qualifica uma ligação rígida de pórtico nem resistência ao deslizamento.')
    issues=[x for x in r.get('issues',[]) if isinstance(x,dict)]
    blocked=any(x.get('severity') in ('engineering_pending','access_pending','invalid_input','invalid_geometry','unsupported_scope','detail_fail','numerical_failure') for x in issues)
    approved_status=(status in ('COMPLETE_CHECKS_PASS_WITHIN_SCOPE','COMPLETE_CHECKS_PASS_WITH_PRESET_DEVIATION')
                     and scope.get('supported') is True and summary.get('complete_checks') is True
                     and r.get('capacity_calculation_permitted') is True)
    if blocked or not approved_status:
        p=doc.add_paragraph('Não há aprovação global da emenda nesta avaliação. Linhas isoladas atendidas não eliminam pendências, falhas ou limites de escopo.')
        p.runs[0].bold=True
        doc.add_paragraph('REGISTRO DIAGNÓSTICO NÃO APROVADO. Não libera fabricação ou uso da ligação.').runs[0].bold=True
    else:
        doc.add_paragraph('O atendimento se limita às verificações e hipóteses declaradas. A compatibilização com o projeto, os materiais efetivos e a montagem permanece sob responsabilidade técnica.')
    if summary:
        _tab(doc,['Síntese calculada','Resultado'],[
            ('Nsd da entrada em kgf',_force(c.N)),
            ('Nd da conferência em kgf',_force(_mapping(r.get('load_model')).get('Nd_N'))),
            ('Verificação governante',str(summary.get('governing_check_id','não disponível'))),
            ('Índice governante com N real',_num(summary.get('actual_governing_utilization'),6)),
            ('Índice governante da conferência',_num(summary.get('governing_utilization'),6)),
            ('Cobertura suplementar selecionada', 'Completa' if summary.get('supplementary_complete') else 'Pendente; ação conhecida e piso calculados'),
            ('Capacidade equivalente das linhas calculadas em kgf',_force(summary.get('equivalent_total_N_capacity_N'))),
            ('Quantidade de verificações',str(summary.get('check_count',len(r.get('checks',[]))))),
            ('Talas físicas',str(summary.get('physical_cover_count',len(r.get('physical_covers',[]))))),
        ],[3.8,3.27])
    doc.add_paragraph('Unidades internas: N, mm e MPa; momentos em N·mm. O cálculo preserva a precisão numérica integral, sem arredondamento intermediário. A apresentação de forças usa kgf com 1 kgf = 9,80665 N. Arredondamentos das tabelas são somente visuais; decisões e índices são calculados antes da conversão.')
    _issues(doc,issues)
    _envelopes(doc,r)
    # A separate landscape sheet keeps every dimension and physical label
    # readable, rather than squeezing a three-view drawing into a text column.
    try:
        if r['status'] in ('INVALID_INPUT','NUMERICAL_FAILURE'):
            raise ValueError('Avaliação de entrada/numérica bloqueada; sem desenho de aprovação.')
        png=image_bytes(c,r)
    except (ValueError,TypeError,AttributeError,OverflowError) as exc:
        doc.add_paragraph('Desenho não gerado neste registro diagnóstico: '+str(exc))
    else:
        _section(doc,landscape=True)
        picture=doc.add_picture(BytesIO(png),width=Inches(10.45))
        picture._inline.docPr.set('descr','Emenda M004 com corte transversal, elevação da alma e planta da mesa; oito talas contínuas W1 W2 F1 F2 F3 F4 F5 F6 e grupos de parafusos em ambos os lados.')
        _section(doc,landscape=False)
    _geometry(doc,c,r)
    _loads(doc,c,r)
    _checks(doc,c,r)
    doc.add_paragraph('Domínio fontes e responsabilidade técnica',style='Heading 1')
    doc.add_paragraph(str(scope.get('statement',SCOPE)))
    for text in scope.get('exclusions',EXCLUSIONS):
        doc.add_paragraph(str(text),style='List Bullet')
    doc.add_paragraph('Fonte geométrica: PADRÃO DE LIGAÇÕES 5Model, detalhe M004, página impressa 72. O arranjo balanceado usa uma tala externa e duas tiras internas por mesa, além de duas talas de alma. O catálogo de oficina orienta a geometria e não certifica a capacidade resistente desta especialização.')
    doc.add_paragraph('Base normativa das expressões: '+NBR+'. As referências específicas acompanham cada fórmula. A divisão de forças, a enumeração de caminhos e o domínio implementado devem ser lidos em conjunto com as pendências desta avaliação.')
    doc.add_paragraph('As verificações de montagem, tolerâncias, comprimentos de parafusos, estabilidade global dos membros, ações fora do domínio e requisitos de serviço não são substituídas por este relatório.')
    if c.notes:
        doc.add_paragraph('Observações do projeto',style='Heading 2')
        doc.add_paragraph(str(c.notes))
    p=doc.add_paragraph();hyperlink(p,BRAND,LINK)
    p=doc.add_paragraph('Componente '+COMPONENT_VERSION+' | Memória gerada por avaliação canônica nova da entrada.')
    for run in p.runs:
        run.font.size=Pt(8)
    out=BytesIO();doc.save(out)
    return out.getvalue()
