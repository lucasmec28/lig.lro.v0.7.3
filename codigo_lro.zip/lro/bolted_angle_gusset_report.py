"""Editable, input-bound Word record of the complete bolted route.

Compact reports retain physical envelopes and actual inputs. Detailed reports
also preserve each check and full canonical case evidence. Both reevaluate.
"""
from dataclasses import asdict
from io import BytesIO
from math import isfinite
import json
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Inches, Pt, RGBColor
from docx.oxml.ns import qn
from .bolted_angle_gusset import COMPONENT_VERSION, FAMILY
from .bolted_angle_gusset_drawing import STATUS, image_bytes, input_fingerprint, validated_result
from .bolted_angle_gusset_presentation import physical_envelopes, selected_angle, angle_identity, angle_detail_disclosure
from .report import BRAND, _math, frac, group, power, radical, table


def _value(value):
    if value is None:return 'não informado'
    if isinstance(value,bool):return 'sim' if value else 'não'
    if isinstance(value,float):return format(value,'.15g').replace('.',',') if isfinite(value) else str(value)
    if isinstance(value,dict):return '; '.join(str(k)+'='+_value(v) for k,v in value.items())
    if isinstance(value,(list,tuple)):return '; '.join(_value(v) for v in value) or 'nenhum'
    return str(value) or 'não informado'


def _n(value,divisor=1):
    if isinstance(value,bool) or not isinstance(value,(int,float)) or not isfinite(value):return 'não disponível'
    return format(value/divisor,'.6g').replace('.',',')


def _flatten(value,prefix=''):
    if isinstance(value,dict):
        for key,item in value.items():yield from _flatten(item,prefix+'.'+str(key) if prefix else str(key))
    elif isinstance(value,(list,tuple)):
        if not value:yield prefix,'nenhum'
        for i,item in enumerate(value):yield from _flatten(item,prefix+'['+str(i)+']')
    else:yield prefix,_value(value)


def _tab(doc,headers,rows,widths=None,size=8):
    out=table(doc,headers,rows,widths or [6.97/len(headers)]*len(headers))
    for i,row in enumerate(out.rows):
        for j,cell in enumerate(row.cells):
            for p in cell.paragraphs:
                if j==0:p.alignment=WD_ALIGN_PARAGRAPH.LEFT
                if len(out.rows)<=6:p.paragraph_format.keep_with_next=i<len(out.rows)-1
                for run in p.runs:run.font.size=Pt(size)
    return out


def _head(doc,title,level=1):return doc.add_paragraph(title,style='Heading '+str(level))


def _inputs(doc,c,r):
    # Labels are presentation only; no UI widgets are invoked.
    from .bolted_angle_gusset_ui import LABELS
    _head(doc,'Entradas atuais e materiais independentes')
    doc.add_paragraph('Unidades nativas: N, mm e MPa; momentos em N mm. As forças da tabela abaixo estão em N, mesmo quando o controle da tela usa kN. Nenhum arredondamento da memória realimenta o cálculo.')
    labels=dict(LABELS)
    labels.update(N='Força axial total N (N)',V='Cortante adicional V (N)',M='Momento adicional M (N mm)',torsion='Torção adicional (N mm)')
    _tab(doc,['Dado nativo','Valor'],[(labels.get(k,k),_value(v)) for k,v in asdict(c).items()],[3.65,3.32])
    angle=selected_angle(c,r)
    _head(doc,'Identidade da cantoneira selecionada',2)
    doc.add_paragraph(angle_identity(angle,c.angle_profile)+' · '+c.angle_profile)
    if angle:
        _tab(doc,['b (mm)','t (mm)','Ag por L (mm²)','ec por L (mm)'],[[_value(angle.get(k)) for k in ('leg','t','Ag','centroid')]])
        doc.add_paragraph('Fonte: '+str(angle.get('source','não disponível'))+'. '+angle_detail_disclosure(angle))
        if angle.get('source_sha256'):doc.add_paragraph('SHA-256 da fonte: '+str(angle['source_sha256']))
    doc.add_paragraph('A extensão interna do talão informada é uma geometria de detalhe da peça real. Não é raio fabricado a partir do catálogo, não usa raio de giração e não é uma declaração de conformidade. Sua ausência deixa a montagem pendente. Uma hipótese do exemplo não certifica a peça real.')
    _head(doc,'Propriedades dos materiais adotados pelo motor',2)
    if r.get('materials'):_tab(doc,['Material / propriedade','Valor'],list(_flatten(r['materials'])),[3.65,3.32])
    else:doc.add_paragraph('Sem propriedades resistentes concluídas para esta entrada.')
    doc.add_paragraph('Cinco registros independentes: aço da L, aço da chapa, aço do W, classe do parafuso e eletrodo da raiz. Compartilhar um valor de fy/fu não une os registros. Dimensão de catálogo não certifica aço, ferragem, procedimento de soldagem ou inspeção.')
    W=(r.get('geometry') or {}).get('support_catalog')
    if W:
        _head(doc,'W receptor selecionado',2)
        _tab(doc,['Perfil','d','bf','tw','tf','r','k'],[[str(W.get('name',c.support_profile))]+[_value(W.get(k)) for k in ('d','bf','tw','tf','r','k')]], [1.87,.85,.85,.85,.85,.85,.85],7.5)
        doc.add_paragraph('Dimensões em mm. Fonte: '+str(W.get('source','não informada')))


def _envelopes(doc,r):
    _head(doc,'Envelopes por componente e mecanismo físico')
    env=physical_envelopes(r)
    if not env:doc.add_paragraph('Nenhum envelope resistente concluído.');return
    doc.add_paragraph('η real corresponde a N real; η adotado conserva os casos mínimos e recomendados separados. Capacidades de partes em série ou caminhos alternativos não são somadas. Todos os empates governantes são preservados.')
    _tab(doc,['Componente / mecanismo','η real','η adotado','Estado'],
         [(e['component_label']+'\n'+e['mechanism_label'],_n(e['actual_utilization']),_n(e['utilization']),e['status']) for e in env],[4.12,.85,.95,1.05])
    for e in env:
        p=doc.add_paragraph();p.add_run(e['component_label']+' / '+e['mechanism_label']+': ').bold=True
        p.add_run('; '.join(str(w.get('id'))+' ['+str(w.get('case_id'))+'] Sd='+_n(w.get('demand'))+', Rd='+_n(w.get('resistance'))+' '+str(w.get('unit','')) for w in e['governing']))
        for run in p.runs:run.font.size=Pt(7.5)


def _cases(doc,c,r):
    _head(doc,'Casos independentes, planos físicos e raiz comum')
    count=2 if c.arrangement=='2L-T' else 1
    doc.add_paragraph('N é a força total da ligação. '+('2L-T: N/2 por L, N/(2n) por plano de corte; cada parafuso passante e cada furo da chapa recebem N/n.' if count==2 else '1L: N na cantoneira; N/n no único plano de corte, em cada parafuso e furo da chapa.')+' A chapa única, os dois filetes da raiz e o W recebem N total.')
    doc.add_paragraph('O mínimo de 45 kN aplica-se uma vez à ligação, antes de repartir entre cantoneiras ou planos. A recomendação de 50% usa a resistência do membro ou do par em 2L-T. São casos separados; N real zero permanece zero.')
    cases=r.get('cases') or []
    if not cases:doc.add_paragraph('Nenhum caso resistente concluído.');return
    _tab(doc,['Caso','N total (kN)','N por L (kN)','N por plano (kN)'],
         [(str(x.get('id')),_n(x.get('N'),1000),_n(x.get('N',0)/count,1000),_n(x.get('N',0)/count/c.n,1000)) for x in cases],[2.2,1.4,1.4,1.97])
    for case in cases:
        _head(doc,'Raiz no caso '+str(case.get('id')),2)
        root=case.get('root') or (r.get('root') if case.get('id')=='actual' else {}) or {}
        _tab(doc,['Grandeza canônica','Valor'],list(_flatten(root)),[3.65,3.32])
    _head(doc,'Ações exportadas para o membro W',2)
    if r.get('member_actions'):_tab(doc,['Grandeza / referência','Valor'],list(_flatten(r['member_actions'])),[3.65,3.32])
    doc.add_paragraph('Nnormal é a variação de cortante transversal introduzida no membro; Vparalelo é o cisalhamento longitudinal da interface. No centroide do W, Mcentroide=Mraiz−dW Vparalelo/2. Combinar com as ações concorrentes reais do membro; nunca presumir apoio descarregado.')


def _method(doc,c):
    _head(doc,'Modelo e equações editáveis')
    doc.add_paragraph('A linha nominal de N coincide com a linha dos parafusos sob a idealização estática da NBR 8800, 6.1.8.2. O centroide físico de cada L não muda: ec continua no shear lag. Em 1L, não se alega cancelamento dos efeitos fora do plano; em 2L-T, há dois planos físicos simétricos. O par oposto pelos vértices não usa esta topologia.')
    _math(doc,group('An = Ag − dn t;   Ae = Ct An;   Ct = max[1 − ',frac('ec','Lc'),'; 0,5]'))
    doc.add_paragraph('Lc é a distância do primeiro ao último centro de furo, não n vezes o passo. Uma seção transversal desta linha cruza um furo por L. O diâmetro físico controla contato e montagem; dn é a dimensão máxima da Tabela 14 acrescida de 2 mm, exceto furo por broca. Não se mistura M16 com o sistema imperial de 5/8 pol.')
    _math(doc,group('Rplano = kpega α ',frac('π db² fub','4 γa2'),';   α = 0,45 ou 0,56'))
    doc.add_paragraph('Cada plano usa sua condição real de rosca e a redução de pega aplicável. Todos os furos devem resistir à parcela uniforme individual, sem redistribuição de capacidade para esconder contato sobrecarregado. Não se credita atrito por protensão.')
    _math(doc,group('Rcontato = ',frac('min(1,2 lc t fu; 2,4 db t fu)','γa2')))
    doc.add_paragraph('lc segue a força SOBRE CADA PEÇA: −u na L, +u na chapa. O extremo livre da L e a saída livre da chapa são opostos. A raiz apoiada não é borda livre. Mantêm-se folgas, passos, distâncias mínimas/máximas às bordas e envelopes reais de ferramenta e talão.')
    _math(doc,group('bWhitmore = 2 Lc tan 30°'))
    _math(doc,group('Rbloco = min[',frac('0,60 fu Anv + Cts fu Ant','γa2'),'; ',frac('0,60 fy Agv + Cts fu Ant','γa2'),']'))
    doc.add_paragraph('Whitmore é recortado à chapa real. Escoamento e triagem líquida conservadora são separados. Blocos L usam Cts=0,5, furos/frações e forças capturadas reais; ambos os ramos usam γa2=1,35. Prefixos capturados na L e sufixos na chapa não inventam um bloco U duplicando a mesma linha. Caminhos alternativos para cada lado não somam resistências. Contato positivo com a raiz apoiada torna o bloco inativo, com motivo registrado.')
    doc.add_paragraph('O caminho oposto da L continua através do talão até a ponta real da aba livre; o talão não é borda livre. Sem raios publicados, a área nominal conservadora usa Ag de catálogo menos a faixa da ponta conectada, sem reconstruir um contorno arredondado inexistente. Os testemunhos detalhados distinguem projeção no plano e percurso tridimensional por cantoneira.')
    _math(doc,group('Nraiz = N sen θ;   Vraiz = N cos θ;   Mraiz = sP Nraiz − nP Vraiz'))
    doc.add_paragraph('θ é medido desde +s, paralelo ao eixo longitudinal do W, até a linha da diagonal no plano da chapa. Os sinais são mantidos para ângulos agudos e obtusos. Mover P sobre a mesma linha não altera o momento. Viga ou pilar é uma rotação rígida local.')
    _math(doc,group('qn = ',frac('Nraiz','B'),' ± ',frac('6 Mraiz','B²'),';   qs = ',frac('Vraiz','B')))
    _math(doc,group('qprojeto = max(qpico; 1,25 qmédio dos extremos);   τw = ',frac('qprojeto','√2 sraiz')))
    doc.add_paragraph('A raiz tem dois filetes iguais de comprimento B e uma única chapa A=B·t. Usa-se o envelope elástico 6M/B, com o suplemento DG29 de 1,25 da média dos módulos extremos para solda; não se aplica aumento direcional. O mínimo do filete usa o material menos espesso, além de limite de borda, comprimento efetivo e compatibilidade.')
    _math(doc,group('δg = min(tg; 2 sraiz);   δW = 2 sraiz;   σeq = ',radical(group(power('σ'),' + 3 ',power('τ')))))
    doc.add_paragraph('Nos dois metais base da raiz, as componentes normal e tangencial permanecem separadas, com fy/fu próprios e verificações de escoamento/ruptura. O puncionamento da mesa usa qpico/(2tf), sem o fator exclusivo da solda. Mesa, alma, duas extremidades e interação local do W são verificados no domínio exterior centrado na alma.')
    _head(doc,'Triagem nominal suplementar da chapa perfurada',2)
    _math(doc,group('σnominal = ',frac('N','A'),' + ',frac('M(s − s̄)','I'),';   τtriagem = ',frac('1,5 |V|','A')))
    doc.add_paragraph('Cada seção horizontal subtrai cordas dos furos usando dn e conserva área, centroide líquido e inércia. Ações de parafusos interceptados são somadas com seus momentos; nos centros de furos mantêm-se limites antes/depois do salto de força. A expressão 1,5|V|/A é triagem herdada da seção retangular maciça, NÃO solução exata de cisalhamento de seção repartida por furos nem tensão de contato contínua.')
    doc.add_paragraph('Esta triagem deve permanecer tracionada e atender aos envelopes do material no domínio adotado. Ela é suplementar e não substitui Whitmore, contato individual, ruptura líquida/efetiva e blocos reais. Sua falha limita o método; não demonstra fissura física específica, flambagem ou exigência universal de elementos finitos. No ligamento não perfurado da raiz, vale a interpretação retangular usual.')


def _details(doc,r):
    _head(doc,'Detalhamento auditável de todas as verificações')
    for row in r.get('checks') or []:
        _head(doc,str(row.get('id')),2)
        p=doc.add_paragraph(_value(row))
        for run in p.runs:run.font.size=Pt(7.5)
    _head(doc,'Testemunhos integrais dos casos')
    def record(label,value):
        # One complete witness per paragraph. Coordinate arrays stay together;
        # long paragraphs can paginate normally, unlike cantSplit table rows.
        if isinstance(value,list) and value and all(isinstance(v,dict) for v in value):
            for i,item in enumerate(value):record(label+'['+str(i)+']',item)
        else:
            p=doc.add_paragraph();p.add_run(label+': ').bold=True;p.add_run(_value(value))
            p.paragraph_format.space_after=Pt(3)
            for run in p.runs:run.font.size=Pt(7.5)
    for case in r.get('cases') or []:
        _head(doc,'Caso '+str(case.get('id')),2)
        for key,value in case.items():record(key,value)


def create_report(c,result=None,detailed=False):
    r=validated_result(c,result);doc=Document()
    sec=doc.sections[0];sec.page_width=Inches(8.27);sec.page_height=Inches(11.69)
    sec.top_margin=sec.bottom_margin=Inches(.65);sec.left_margin=sec.right_margin=Inches(.65)
    normal=doc.styles['Normal'];normal.font.name='Calibri';normal.font.size=Pt(9)
    normal.paragraph_format.space_after=Pt(5)
    for style in doc.styles:
        for border in list(style.element.iter(qn('w:pBdr'))):border.getparent().remove(border)
    for name in ('Heading 1','Heading 2'):
        style=doc.styles[name];style.font.name='Calibri';style.font.color.rgb=RGBColor.from_string('243749')
        style.paragraph_format.keep_with_next=True
    doc.add_heading('Ligação completa parafusada '+str(c.arrangement),0)
    doc.add_paragraph(str(c.project))
    doc.add_paragraph(COMPONENT_VERSION+' · '+('Memória detalhada' if detailed else 'Memória compacta'))
    p=doc.add_paragraph();p.add_run(STATUS.get(r.get('status'),str(r.get('status')))).bold=True
    p.add_run(' · estado canônico: '+str(r.get('status')))
    doc.add_paragraph('Cantoneira → parafusos e chapa perfurada → dois filetes da raiz → mesa exterior W. Família independente dos componentes axiais antigos; nenhum resultado deles aprova esta ligação completa.')
    doc.add_paragraph('SHA-256 das entradas atuais: '+input_fingerprint(c))
    for issue in r.get('issues') or []:
        doc.add_paragraph(str(issue.get('severity','Ocorrência'))+': '+str(issue.get('message',issue)))
    doc.add_picture(BytesIO(image_bytes(c,fmt='png')),width=Inches(6.97))
    doc.add_paragraph('Figura proporcional das entradas atuais: furos físicos, seção 1L ou T, planos de corte, chapa única e raiz dupla. Cantos da cantoneira sem raio publicado ficam interrompidos; a extensão real do talão é informação separada de montagem.')
    doc.add_page_break();_envelopes(doc,r);_inputs(doc,c,r);_cases(doc,c,r);_method(doc,c)
    if detailed:_details(doc,r)
    _head(doc,'Referências e limites')
    doc.add_paragraph('ABNT NBR 8800:2024 / Errata 1:2025: 5.2.2–5.2.5, tração, seção líquida e shear lag; 5.7, mesa e alma receptoras; 6.1.5 e 6.1.8.2, força mínima e idealização estática de extremidade de cantoneira; 6.2, filetes; 6.3 e Tabelas 14/16, parafusos, contato, furos, pega e distâncias; 6.5.3, 6.5.5 e 6.5.6, elementos conectados e blocos.')
    doc.add_paragraph('AISC Design Guide 29 (2014), Exemplo 5.4, Fig. 5-10, pp. 98–108 (PDF 106–116): percurso 2L, parafusos compartilhados, gusset, raiz e W. Precedente metodológico; geometria retangular, fatores NBR, demanda uniforme por parafuso e envelope elástico da raiz são identificados separadamente. Não se transfere a redistribuição de resistência do exemplo AISC.')
    for item in r.get('exclusions') or []:doc.add_paragraph(str(item),style='List Bullet')
    doc.add_paragraph('Fora desta família: par de vértices opostos (><), duas linhas ou furos escalonados, enchimentos/afastamentos, compressão, reversão/fadiga, sismo, ações espaciais adicionais, alma W direta, raiz transversal ou deslocada, segundo apoio e chapa de canto. O arranjo oposto necessita duas linhas distintas em corte simples, não parafusos passantes compartilhados.')
    _head(doc,'Conclusão local')
    doc.add_paragraph('As verificações locais implementadas atendem no domínio declarado.' if r.get('global_pass') else 'A entrada atual permanece sem conclusão favorável completa. Resolver as falhas e pendências registradas antes de usar esta memória como verificação local.')
    doc.add_paragraph('Esta conclusão não aprova fabricação, montagem, estabilidade global da diagonal ou do sistema, travamentos do par, membro W carregado ou estrutura completa. '+BRAND)
    doc.core_properties.title=FAMILY;doc.core_properties.subject='Memória local '+COMPONENT_VERSION
    out=BytesIO();doc.save(out);return out.getvalue()

report_docx=create_report
