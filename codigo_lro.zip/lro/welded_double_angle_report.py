"""Editable, complete and scope-safe R015 calculation report."""
from .display_precision import display_value
from collections import OrderedDict
from dataclasses import fields, is_dataclass
from io import BytesIO
from math import isfinite

from docx import Document
from docx.enum.section import WD_ORIENT, WD_SECTION_START
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Inches, Pt, RGBColor

from .angle_catalog_selection import provenance_text, LABELS as CATALOG_LABELS
from .welded_double_angle import COMPONENT_VERSION, EXCLUSIONS, NBR, SCOPE
from .welded_double_angle_drawing import image_bytes, validated_result
from .welded_double_angle_presentation import physical_envelopes, governing_description, component_label
from .models import KGF, STEELS, BOLTS
from .report import BRAND, LINK, _math, group, hyperlink, number, table

STATUS={
    'INVALID_INPUT':'Entrada inválida',
    'NUMERICAL_FAILURE':'Falha numérica',
    'INVALID_GEOMETRY':'Geometria inválida',
    'OUTSIDE_R015_SCOPE':'Fora do domínio R015',
    'OUTSIDE_SUPPORTED_SCOPE':'Fora do domínio implementado',
    'ENGINEERING_MODEL_PENDING':'Verificação completa pendente',
    'NOT_EVALUATED':'Sem avaliação resistente',
    'VERIFIED_SUBCHECK_FAIL':'Há verificação resistente não atendida',
    'DETAIL_FAIL':'Há requisito de detalhamento não atendido',
    'COMPLETE_CHECKS_PASS_WITHIN_SCOPE':'Verificações atendidas no domínio declarado',
    'COMPLETE_CHECKS_PASS_WITH_PRESET_DEVIATION':'Verificações atendidas com desvio do padrão de oficina',
}
SEVERITY={
    'invalid_input':'Entrada inválida','invalid_geometry':'Geometria inválida','numerical_failure':'Falha numérica',
    'unsupported_scope':'Fora do domínio','engineering_pending':'Pendência técnica',
    'detail_fail':'Detalhamento não atendido','warning':'Ressalva','info':'Informação',
    'access_pending':'Montagem/acesso pendente','preset_deviation':'Desvio do padrão de oficina',
    'error':'Erro','pending':'Pendência','excluded':'Exclusão','not_evaluated':'Não avaliado',
}
LABELS={
    'project':'Projeto','kind':'Interface do apoio','angle_count':'Quantidade de cantoneiras',
    'symmetric':'Arranjo simétrico','beam_leg':'Aba junto à viga b_viga em mm',
    'support_leg':'Aba junto ao apoio b_apoio em mm','t':'Espessura da cantoneira em mm',
    'root_radius':'Raio interno da cantoneira em mm','length':'Comprimento da cantoneira em mm',
    'angle_top':'Topo da cantoneira abaixo do topo da viga em mm',
        'support_gauge':'Gabarito do apoio desde a face da alma em mm',
    'support_rows':'Parafusos por coluna em cada aba de apoio',
    'support_columns':'Colunas por aba de apoio',
    'support_pitch':'Passo vertical no apoio em mm',
    'support_end_top':'Borda superior na aba de apoio em mm',
    'gap':'Folga ponta da viga até face do pilar em mm',
    'weld_layout':'Arranjo dos filetes na aba da viga',
    'weld_process':'Processo e classificação do eletrodo',
    'weld_leg':'Perna do filete w em mm',
    'weld_start':'Início x0 dos ramos superior/inferior em mm',
    'electrode_fuw':'Resistência característica do metal de solda fuw em MPa',
    'reinforced_weld_edge':'Exceção de solda reforçada junto à borda documentada',
    'support_edge_top':'Primeiro furo até borda superior real do apoio em mm',
    'support_edge_bottom':'Último furo até borda inferior real do apoio em mm',
    'beam_steel':'Aço da viga','support_steel':'Aço do apoio','angle_steel':'Aço das cantoneiras',
    'bolt':'Classe dos parafusos','db':'Diâmetro dos parafusos em mm',
    'hole_diameter':'Diâmetro físico dos furos em mm','hole_type':'Tipo de furo',
    'drilled':'Furação por broca documentada',
    'support_threads_excluded':'Rosca excluída no plano de corte do apoio','exposure':'Exposição',
    'V':'Vsd informado em N','N':'N informado em N','M':'M informado em N mm','torsion':'T informado em N mm',
    'cope':'Recorte da viga','static':'Ações estáticas','normal_combination':'Combinação última normal',
    'no_slip_required':'Ausência de deslizamento exigida','tool_radius':'Raio de ferramenta em mm',
    'fabrication_clearance':'Folga de fabricação em mm','notes':'Observações do projeto',
}


def _mapping(value):return value if isinstance(value,dict) else {}

def _approved(r):
    blockers={'invalid_input','invalid_geometry','numerical_failure','unsupported_scope','engineering_pending','access_pending','detail_fail','error','pending'}
    return (isinstance(r.get('inputs'),dict) and r.get('global_pass') is True
            and r.get('status') in ('COMPLETE_CHECKS_PASS_WITHIN_SCOPE','COMPLETE_CHECKS_PASS_WITH_PRESET_DEVIATION')
            and _mapping(r.get('geometry')).get('valid') is True
            and _mapping(r.get('summary')).get('complete_checks') is True
            and bool(r.get('checks'))
            and all(isinstance(x,dict) and x.get('status')=='PASS' for x in (r.get('checks') or []))
            and not any(isinstance(x,dict) and x.get('severity') in blockers for x in (r.get('issues') or [])))

def _num(value,places=6):
    if isinstance(value,bool) or not isinstance(value,(int,float)) or not isfinite(value):return 'não disponível'
    return number(value,places)

def _force(value):
    if isinstance(value,bool) or not isinstance(value,(int,float)) or not isfinite(value):return 'não disponível'
    return number(value/KGF,2)

def _value(value):
    if isinstance(value,bool):return 'sim' if value else 'não'
    if isinstance(value,(int,float)):return _num(value,6) if isinstance(value,float) else str(value)
    if isinstance(value,(tuple,list)):return '; '.join(_value(x) for x in value)
    if isinstance(value,dict):return '; '.join(str(k)+'='+_value(v) for k,v in value.items())
    return str(value) if value is not None else 'não disponível'

def _tab(doc,headers,rows,widths,size=8.3):
    t=table(doc,headers,rows,widths)
    for row in t.rows:
        for i,cell in enumerate(row.cells):
            for paragraph in cell.paragraphs:
                if i==0:paragraph.alignment=WD_ALIGN_PARAGRAPH.LEFT
                for run in paragraph.runs:run.font.size=Pt(size)
    return t

def _section(doc,landscape=False):
    s=doc.add_section(WD_SECTION_START.NEW_PAGE)
    s.orientation=WD_ORIENT.LANDSCAPE if landscape else WD_ORIENT.PORTRAIT
    s.page_width=Inches(11.69 if landscape else 8.27);s.page_height=Inches(8.27 if landscape else 11.69)
    s.top_margin=s.bottom_margin=Inches(.48)
    s.left_margin=s.right_margin=Inches(.60)
    return s


def _inputs(doc,c,r):
    if c.angle_catalog_id:
        doc.add_paragraph(provenance_text(c))
    doc.add_paragraph('Dados completos da entrada',style='Heading 1')
    doc.add_paragraph('Todos os campos da entrada são registrados abaixo. A interface da alma é soldada, sem parafusos e sem furos. A furação pertence somente às abas de apoio e à mesa do pilar. Nenhuma espessura do apoio é substituída pela da viga.')
    doc.add_paragraph('Perfis: d, bf, tw, tf e clear em mm; area em mm²; mass em kg/m. A geometria derivada usa mm, áreas em mm² e contagens adimensionais, conforme o identificador de cada campo.')
    for key,label in (('beam','Viga apoiada'),('support','Pilar de apoio')):
        p=getattr(c,key,None)
        doc.add_paragraph(label,style='Heading 2')
        if is_dataclass(p):
            _tab(doc,['Campo do perfil','Valor'],[(f.name,_value(getattr(p,f.name))) for f in fields(p)],[2.1,4.97])
        else:doc.add_paragraph(str(p))
    rows=[]
    for f in fields(c):
        if f.name not in ('beam','support'):
            rows.append((CATALOG_LABELS.get(f.name, LABELS.get(f.name,f.name))+'\n'+f.name,_value(getattr(c,f.name))))
    _tab(doc,['Grandeza e campo de entrada','Valor informado'],rows,[4.3,2.77])
    doc.add_paragraph('Materiais e coeficientes',style='Heading 2')
    for name in dict.fromkeys((c.beam_steel,c.support_steel,c.angle_steel)):
        steel=STEELS.get(name)
        doc.add_paragraph(str(name)+': '+(f'fy={display_value(_num(steel.fy, 3))} MPa; fu={display_value(_num(steel.fu, 3))} MPa.' if steel else 'material não cadastrado; sem resistência presumida.'))
    bolt=BOLTS.get(c.bolt)
    if bolt is not None:
        fub=bolt if isinstance(bolt,(int,float)) else getattr(bolt,'fu',getattr(bolt,'fub',None))
        doc.add_paragraph('Parafuso '+str(c.bolt)+': fub='+_num(fub,3)+' MPa.')
    doc.add_paragraph('Processo da rota implementada: SMAW E7018 em passe único, com procedimento de execução qualificado. O mínimo da Tabela 11 é aplicado nessa premissa; outro regime de passes exige reavaliar a rota, não marcar uma opção de reforço de borda.')
    doc.add_paragraph('γa1=1,10; γa2=1,35. Limites do produto, faixas de espessura, corrosão, fabricação e montagem continuam aplicáveis.')
    doc.add_paragraph('Premissas fixas do modelo',style='Heading 2')
    doc.add_paragraph('Contato direto e firme entre as abas parafusadas e a mesa do pilar, sem calços. O contato entre cada aba soldada e a alma deve ser compatível com a preparação e o procedimento de soldagem. A folga da ponta da viga até a face do pilar é uma dimensão distinta. Parafusos, porcas e arruelas seguem a montagem da NBR 6.8, sem crédito resistente por atrito ou protensão.')
    doc.add_paragraph('Viga e pilar W laminados contínuos na região da ligação, sem recortes, aberturas adicionais ou descontinuidades soldadas locais. A tabela registra as premissas fixas que acompanham o arquivo nativo.')
    _tab(doc,['Premissa','Valor declarado'],[(str(k),_value(v)) for k,v in c.fixed_assumptions.items()],[3.6,3.47],size=8)
    doc.add_paragraph('O atendimento local R015 não representa verificação completa do edifício, da estabilidade ou do dimensionamento global da viga e do pilar. Contato, montagem, rotações e ações transportadas devem corresponder ao modelo estrutural.')
    g=_mapping(r.get('geometry'))
    doc.add_paragraph('Geometria derivada e diagnóstico',style='Heading 2')
    if g:
        rows=list(_flatten({k:v for k,v in g.items() if k not in ('checks','issues','detailing_checks')}))
        if rows:_tab(doc,['Grandeza retornada pelo motor','Valor'],rows,[3.4,3.67],size=8)
        gchecks=[x for x in g.get('checks',[]) if isinstance(x,dict)]
        if gchecks:
            _tab(doc,['Critério geométrico','Valor / exigência em mm','Estado'],
                 [(str(x.get('id',''))+'\n'+str(x.get('reference','')),
                   _num(x.get('actual'),3)+' / '+str(x.get('relation',''))+' '+_num(x.get('limit'),3),
                   'Atende' if x.get('passed') else 'Não atende') for x in gchecks],[3.65,2.35,1.07],size=7.8)
    else:doc.add_paragraph('O motor não forneceu geometria derivada nesta avaliação.')
    doc.add_paragraph('Somente na interface do apoio, o furo físico dh é usado no desenho e no contato. A dedução líquida dn segue a maior dimensão circular da Tabela 14 acrescida de 2 mm, salvo furação por broca explicitamente documentada. A opção de fabricação não é inferida do diâmetro digitado.')
    doc.add_paragraph('Bordas livres do apoio são medidas do primeiro e último furo até as extremidades reais do pilar; as laterais são as bordas reais da mesa. A junção mesa–alma não é borda livre. No desenho local da elevação, o fuste interrompido não cria uma extremidade resistente.')


def _flatten(value,path=''):
    """One short leaf per row: never create an unbreakable nested-data cell."""
    if isinstance(value,dict):
        for key,child in value.items():
            yield from _flatten(child,path+'.'+str(key) if path else str(key))
    elif isinstance(value,(tuple,list)):
        if not value:yield path,'nenhum'
        for index,child in enumerate(value):yield from _flatten(child,path+'['+str(index)+']')
    else:yield path,_value(value)


def _loads(doc,c,r):
    doc.add_paragraph('Ações e caminho das forças',style='Heading 1')
    lm=_mapping(r.get('load_model'))
    def moment(v):
        return _num(v/(KGF*1000),3) if isinstance(v,(int,float)) and not isinstance(v,bool) and isfinite(v) else 'não disponível'
    _tab(doc,['Ação','Valor','Unidade'],[
        ('Vsd com sinal da entrada',_force(c.V),'kgf'),
        ('Vd adotado na conferência',_force(lm.get('Vd_N')),'kgf'),
        ('N informado',_force(c.N),'kgf'),('M informado',moment(c.M),'kgf m'),
        ('T informado',moment(c.torsion),'kgf m')],[4.0,1.65,1.42])
    doc.add_paragraph('V positivo é representado para baixo na viga; V negativo, para cima. O sinal determina as bordas carregadas. As ações já são de cálculo; o módulo não aplica fatores de majoração. A resistência mínima eventualmente adotada incide uma vez no conjunto, antes da divisão entre cantoneiras. Valores reais e adotados são registrados separadamente.')
    if lm:_tab(doc,['Parâmetro do modelo de ações','Valor'],list(_flatten(lm)),[3.6,3.47],size=8)
    else:doc.add_paragraph('Modelo resistente não executado; nenhuma força ou capacidade favorável é atribuída a componente não avaliado.')
    _math(doc,group('Fy,ângulo = Vd/2;  Fparafuso,apoio = Vd/(2napoio);  nplanos,apoio = 1'))
    _math(doc,group('Mz,ângulo = (0 − x̄) Fy,ângulo = −x̄ Fy,ângulo'))
    doc.add_paragraph('Identificação física: A1 é a cantoneira do lado −z (angle_negative); A2 é a cantoneira do lado +z (angle_positive). Cada uma possui três segmentos próprios de solda e seu grupo de parafusos na mesa de apoio. Há uma única alma física da viga; os campos transferidos pelos dois grupos soldados devem ser superpostos sobre essa mesma alma.')
    g=_mapping(r.get('geometry'));groups=_mapping(r.get('bolts')).get('groups',[])
    doc.add_paragraph('Total físico de parafusos: '+str(g.get('total_bolt_count',2*c.support_rows*c.support_columns))+'. Todos estão na interface de apoio; nenhum atravessa a alma da viga.')
    if groups:
        _tab(doc,['Grupo físico','Quantidade','Planos por parafuso','Força por parafuso kgf','Força por plano kgf'],
            [(x.get('id',''),x.get('bolt_count',''),x.get('shear_planes',''),_force(x.get('each_bolt_force_N')),_force(x.get('each_plane_force_N'))) for x in groups],[2.3,.85,1.2,1.36,1.36],size=8)
    doc.add_paragraph('Caminho resistente: única alma da viga → dois grupos de soldas em U → duas cantoneiras → dois grupos de parafusos de apoio → mesa do pilar. Interfaces em série não têm capacidades somadas. A divisão V/2 exige par simétrico e não autoriza dimensionar uma cantoneira única pela metade do par.')
    doc.add_paragraph('A resultante de cada grupo é aplicada na face do apoio x=0; a excentricidade até o centroide da solda é mantida mesmo quando N, M e T externos são nulos. O modelo local de filetes não encerra por si só compatibilidade tridimensional, flexão das cantoneiras, concentração na alma ou resposta local do pilar. Pendências exatas constam no início desta memória.')


def _welds(doc,c,r):
    doc.add_paragraph('Grupo de soldas em U por cantoneira',style='Heading 1')
    doc.add_paragraph('Sistema local do motor: x é a distância desde a face do apoio; y local cresce desde o topo da cantoneira. Os dois ramos horizontais vão de x0=weld_start até b=beam_leg, nas cotas locais y=0 e y=L. O segmento vertical de ponta fica em x=b entre essas cotas. Na elevação da viga, a origem vertical do grupo está a angle_top abaixo do topo da viga. Não existe quarto segmento de fechamento.')
    equations=[
        'h = b − x0;  Lw = L + 2h;  a = w/√2',
        'x̄ = [bL + h(x0+b)]/Lw;  ȳ = L/2',
        'Jlinha = ∫U [(x−x̄)² + (y−ȳ)²] ds  [mm³]',
        'Mz = −x̄ Fy;  qx = −Mz (y−ȳ)/Jlinha;  qy = Fy/Lw + Mz (x−x̄)/Jlinha',
        'q = √(qx²+qy²)  [N/mm];  τw = q/a  [MPa]',
        '∫U qx ds = 0;  ∫U qy ds = Fy;  ∫U [(x−x̄)qy − (y−ȳ)qx] ds = Mz',
    ]
    for formula in equations:_math(doc,group(formula))
    doc.add_paragraph('A integração é analítica sobre cada segmento efetivo. Os extremos de todos os segmentos são avaliados: o quadrado da norma do campo linear é convexo sobre cada segmento, logo o máximo nesse segmento ocorre em um dos seus extremos. Usa-se o vetor resultante, sem somar escalarmente corte direto e momento e sem tratar o U como um contorno fechado.')
    doc.add_paragraph('w é a perna do filete em mm; a é sua garganta efetiva; fuw é a resistência característica do metal de solda em MPa. Não se credita penetração, reforço de garganta ou majoração direcional. A opção reinforced_weld_edge documenta somente a exceção geométrica indicada no resultado, quando aplicável; não aumenta a resistência nominal presumida.')
    records={key:r[key] for key in ('weld','welds','weld_group','weld_groups','shared_web','shared_web_transfer') if key in r}
    if records:
        for key,value in records.items():
            doc.add_paragraph(key.replace('_',' '),style='Heading 2')
            _tab(doc,['Grandeza / ponto / segmento','Valor e unidade do identificador'],list(_flatten(value)),[4.1,2.97],size=8)
    else:doc.add_paragraph('O motor não forneceu resultados numéricos do grupo soldado nesta avaliação. As equações acima descrevem o modelo, sem atribuir aprovação a verificações ausentes.')
    doc.add_paragraph('Os resultados numéricos por ponto, sentidos, centroides, comprimentos, momentos de linha e solicitações abaixo seguem o retorno do motor; nenhuma capacidade é reconstruída a partir do desenho. As verificações de solda, metal-base e alma compartilhada permanecem individualizadas nas tabelas de verificações.')


def _envelopes(doc,r):
    envelopes=physical_envelopes(r)
    if not envelopes:return
    doc.add_paragraph('Envelopes por componente e mecanismo',style='Heading 1')
    doc.add_paragraph(f"{display_value(len(envelopes))} envelopes de apresentação conservam todas as {display_value(len(r['checks']))} linhas primitivas no desenvolvimento. Os governantes real e adotado são selecionados separadamente; cada solicitação e resistência abaixo pertence à sua própria linha governante. Não há soma ou aumento de resistências. Contato inclui soma normativa e compatibilidade uniforme por furo, mantidas distintas no detalhe.")
    rows=[]
    for item in envelopes:
        actual=item['actual_governing'];adopted=item['adopted_governing']
        rows.append((item['component_label']+'\n'+item['mechanism_label'],
                     _force(actual['actual_demand_N'])+' / '+_force(actual['design_capacity_N']),
                     _force(adopted['demand_N'])+' / '+_force(adopted['design_capacity_N']),
                     _num(item['actual_utilization'])+'\n'+_num(item['adopted_utilization']),
                     'Falha' if item['status']=='FAIL' else 'Atende'))
    _tab(doc,['Componente e mecanismo','Sd real / Rd\nkgf','Sd conf. / Rd\nkgf','ηreal / ηd','Estado'],rows,[2.52,1.45,1.45,1.03,.62],size=8)
    doc.add_paragraph('Casos sentidos e ramos governantes',style='Heading 2')
    for item in envelopes:
        p=doc.add_paragraph();p.add_run(item['component_label']+' · '+item['mechanism_label']+'. ').bold=True
        for key,label in (('actual','Real'),('adopted','Adotado')):
            record=item[key+'_governing'];ties=item[key+'_governing_ties']
            p.add_run(label+': '+governing_description(record)+'. ')
            if len(ties)>1:p.add_run('Empates: '+', '.join(row['id'] for row in ties)+'. ')
            p.add_run('Caso: '+_value(record['case'])+'. ')
    doc.add_paragraph('Os registros completos de todos os ramos, inclusive cada governante e empate acima, seguem em Todas as verificações calculadas e Áreas trajetos e valores auxiliares; os identificadores fazem a ligação exata entre resumo e desenvolvimento.')


def _checks(doc,r):
    checks=[x for x in (r.get('checks') or []) if isinstance(x,dict)]
    doc.add_paragraph('Equações editáveis e referências',style='Heading 1')
    if not checks:
        doc.add_paragraph('Não há verificações resistentes calculadas. A ausência de linhas não significa atendimento. As pendências e o estado do motor impedem atribuir aprovação.')
        return
    formulas=OrderedDict()
    for row in checks:
        key=(str(row.get('formula','Fórmula não fornecida')),str(row.get('reference','Referência não fornecida')))
        formulas.setdefault(key,'E'+str(len(formulas)+1))
    for (formula,reference),code in formulas.items():
        doc.add_paragraph(code,style='Heading 2')
        _math(doc,group(formula))
        doc.paragraphs[-1].paragraph_format.keep_with_next=True
        doc.add_paragraph(reference)
    doc.add_paragraph('Ag e An: áreas bruta e líquida ao cisalhamento. Agv e Anv: áreas bruta e líquida ao corte no bloco; Ant: área líquida à tração; Cts: coeficiente de distribuição de tensão. fy, fu e fub: resistências características; db: diâmetro do parafuso; dh: furo físico; dn: dedução líquida; lc: ligamento livre; α: coeficiente por plano de corte; γa1 e γa2: coeficientes de resistência.')
    doc.add_paragraph('Blocos e contato usam os furos, bordas e a parcela de força da própria peça. Uma aba sem furo não recebe dedução da outra. A soma normativa das resistências de contato dos furos é distinta de multiplicar a capacidade do pior furo pelo número total de parafusos.')
    doc.add_paragraph('Todas as verificações calculadas',style='Heading 1')
    doc.add_paragraph(f'Total de {display_value(len(checks))} linhas. Sd e Rd correspondem à própria linha. ηreal usa a ação informada; ηd usa a ação adotada na conferência. A fórmula e a referência de cada linha são identificadas por E. Os estados são fornecidos pelo motor antes do arredondamento visual.')
    grouped=OrderedDict()
    for row in checks:grouped.setdefault(str(row.get('component','Sem componente')),[]).append(row)
    for component,items in grouped.items():
        doc.add_paragraph(component_label(component),style='Heading 2')
        rows=[]
        for row in items:
            fkey=(str(row.get('formula','Fórmula não fornecida')),str(row.get('reference','Referência não fornecida')))
            state={'PASS':'Atende','FAIL':'Falha','NOT_EVALUATED':'Não avaliado','PENDING':'Pendente'}.get(row.get('status'),str(row.get('status','Não avaliado')))
            rows.append((str(row.get('label',''))+'\n'+str(row.get('id','')),
                         _force(row.get('actual_demand_N')),_force(row.get('demand_N')),
                         _force(row.get('design_capacity_N')),_num(row.get('actual_utilization'))+'\n'+_num(row.get('utilization')),
                         state,formulas[fkey]))
        _tab(doc,['Verificação e ID','Sd real\nkgf','Sd conf.\nkgf','Rd\nkgf','ηreal\nηd','Linha','Eq'],rows,[2.50,.84,.84,.84,.96,.62,.47],size=7.8)
    # Preserve every optional computed detail supplied by the engine. These
    # are supporting numbers, not a second independently rounded calculation.
    standard={'id','label','component','demand_N','actual_demand_N','design_capacity_N','utilization','actual_utilization','status','formula','reference'}
    details=[(str(row.get('id','')),[(str(k),v) for k,v in row.items() if k not in standard]) for row in checks]
    details=[(cid,items) for cid,items in details if items]
    if details:
        doc.add_paragraph('Áreas trajetos e valores auxiliares',style='Heading 1')
        for cid,items in details:
            p=doc.add_paragraph();p.add_run(cid+': ').bold=True
            p.add_run('; '.join(path+' = '+value for k,v in items for path,value in _flatten(v,k))+'.')


def create_report(c,r=None):
    """Return DOCX bytes, including honest diagnostics for incomplete cases."""
    r=validated_result(c,r)
    doc=Document();s=doc.sections[0]
    s.page_width=Inches(8.27);s.page_height=Inches(11.69)
    s.top_margin=s.bottom_margin=Inches(.48);s.left_margin=s.right_margin=Inches(.60)
    for name in ('Normal','Title','Subtitle','Heading 1','Heading 2'):
        style=doc.styles[name];style.font.name='Arial';style.font.color.rgb=RGBColor(0,0,0)
    for style in doc.styles:
        for b in style.element.xpath('.//w:pBdr'):b.getparent().remove(b)
    doc.styles['Normal'].font.size=Pt(9);doc.styles['Normal'].paragraph_format.space_after=Pt(5)
    doc.styles['Title'].font.size=Pt(21);doc.styles['Subtitle'].font.size=Pt(11)
    doc.styles['Heading 1'].font.size=Pt(12);doc.styles['Heading 2'].font.size=Pt(10)
    doc.core_properties.title='Memória de cálculo da ligação R015 com duas cantoneiras'
    doc.core_properties.author='LRO Soluções de engenharia LTDA.'
    doc.core_properties.subject='Duas cantoneiras soldadas em U à alma e parafusadas à mesa de pilar'
    doc.add_paragraph('Memória de cálculo da ligação R015',style='Title')
    doc.add_paragraph('Duas cantoneiras soldadas em U e parafusadas sob cortante vertical',style='Subtitle')
    doc.add_paragraph(str(c.project))
    doc.add_paragraph(c.beam.name+' → '+c.support.name+' | Componente '+COMPONENT_VERSION)
    status=str(r.get('status','RESULTADO INCOMPLETO'))
    unbound=not isinstance(r.get('inputs'),dict)
    p=doc.add_paragraph();p.add_run('Resultado sem vínculo de entrada: aprovação não disponível' if unbound else STATUS.get(status,status)).bold=True
    doc.add_paragraph('Estado do motor: '+status+'.')
    if unbound:doc.add_paragraph('O resultado não contém a cópia integral das entradas usada no cálculo. A memória é diagnóstica e exige nova avaliação do projeto antes de qualquer aprovação.')
    doc.add_paragraph('Esta memória registra a entrada completa e todas as verificações calculadas da família R015, composta por duas cantoneiras L, cada uma soldada em U à alma da viga e parafusada à mesa do pilar. Entradas que alteram essa topologia permanecem identificadas e não recebem aprovação pelo modelo do par. O domínio é a ligação usual flexível R015 com par simétrico sob V estático e N=M=T=0, sem recortes na viga.')
    if not _approved(r):
        p=doc.add_paragraph('Não há aprovação global da ligação nesta avaliação. Linhas atendidas não eliminam falhas, verificações ausentes ou limites de escopo.');p.runs[0].bold=True
    else:
        doc.add_paragraph('O atendimento se limita às verificações e hipóteses declaradas. A compatibilização com os materiais efetivos, a estrutura, a rotação e a montagem permanece sob responsabilidade técnica.')
    summary=_mapping(r.get('summary'));lm=_mapping(r.get('load_model'))
    _tab(doc,['Síntese da avaliação','Resultado'],[
        ('Vsd da entrada em kgf',_force(c.V)),('Vd da conferência em kgf',_force(lm.get('Vd_N'))),
        ('Verificação governante',str(summary.get('governing_label',summary.get('governing_check_id','não disponível')))),
        ('Índice governante real',_num(summary.get('actual_governing_utilization'))),
        ('Índice governante da conferência',_num(summary.get('governing_utilization'))),
        ('Número de verificações calculadas',len((r.get('checks') or []))),
        ('Quantidade de cantoneiras informada',c.angle_count),
        ('Atendimento local R015 no domínio','sim, no domínio' if _approved(r) else 'não'),
    ],[3.7,3.37])
    doc.add_paragraph('Unidades internas: N, mm e MPa; momentos em N mm. A apresentação de forças usa kgf, com 1 kgf = 9,80665 N. O relatório conserva os valores do motor sem arredondamento intermediário; o arredondamento exibido não altera a decisão.')
    doc.add_paragraph('Pendências e condições de uso',style='Heading 1')
    issues=[x for x in (r.get('issues') or []) if isinstance(x,dict)]
    if not issues:doc.add_paragraph('Nenhuma ocorrência foi fornecida pelo motor. A ausência de ocorrências não amplia o domínio nem substitui verificações ausentes.')
    for issue in issues:
        p=doc.add_paragraph();p.add_run(SEVERITY.get(issue.get('severity'),str(issue.get('severity','Ocorrência')))+': ').bold=True
        p.add_run(str(issue.get('text','Sem descrição.')))
        if issue.get('reference'):p.add_run(' Referência: '+str(issue['reference'])+'.')
    try:png=image_bytes(c,r)
    except (ValueError,TypeError,AttributeError,OverflowError) as exc:
        doc.add_paragraph('Desenho não gerado por entrada sem representação segura: '+str(exc))
    else:
        _section(doc,True)
        p=doc.add_picture(BytesIO(png),width=Inches(9.85))
        p._inline.docPr.set('descr','R015: duas cantoneiras L independentes A1 e A2, espelhadas junto à única alma. Soldas em U em cada aba da viga, abertas no apoio, sem furos ou parafusos na alma. Dois grupos de apoio em corte simples e bordas livres reais. Quantidades e sinal de V seguem a entrada.')
        _section(doc,False)
    _envelopes(doc,r);_inputs(doc,c,r);_loads(doc,c,r);_welds(doc,c,r);_checks(doc,r)
    not_applicable=[x for x in (r.get('not_applicable') or []) if isinstance(x,dict)]
    if not_applicable:
        doc.add_paragraph('Mecanismos não aplicáveis ao domínio',style='Heading 1')
        for item in not_applicable:
            doc.add_paragraph(str(item.get('mechanism',''))+': '+str(item.get('reason',''))+' Referência: '+str(item.get('reference',''))+'.')
    doc.add_paragraph('Domínio fontes e responsabilidade técnica',style='Heading 1')
    scope=r.get('scope',SCOPE)
    doc.add_paragraph(str(scope.get('statement',SCOPE)) if isinstance(scope,dict) else str(scope))
    for exclusion in r.get('exclusions',EXCLUSIONS):doc.add_paragraph(str(exclusion),style='List Bullet')
    doc.add_paragraph('Fonte geométrica: PADRÃO DE LIGAÇÕES 2Model, R015, página impressa 18. Duas cantoneiras soldadas à alma da viga e parafusadas à mesa do pilar. A família parafusada nas duas interfaces constitui outro detalhe e não é usada como desenho desta ligação.')
    doc.add_paragraph('Base normativa: '+NBR+'. Resistência e detalhamento seguem as referências específicas de cada verificação. O relatório distingue resistência calculada, detalhamento e verificações de engenharia ainda não fechadas.')
    doc.add_paragraph('Gerdau, Ligações para Estruturas de Aço, 7ª edição, 2018, páginas 19 e 50, LCSP: identificação da topologia de cantoneiras soldadas/parafusadas. Valores históricos de tabelas não são usados como validação de resistência pela edição normativa atual. O elemento de apoio é componente próprio e não recebe aprovação por associação à tabela industrial.')
    doc.add_paragraph('Os ramos superior e inferior do U pertencem integralmente à aba junto à alma da viga. Eles não são retornos adicionais sobre a aba projetante de apoio. Não há solda ao longo do talão fechando o U, nem filete na aba parafusada ao pilar. Nenhuma resistência de solda de contorno fechado é presumida.')
    doc.add_paragraph('Comprimentos inferiores a max(4w, 40 mm) ficam pendentes nesta rota de perna integral. A NBR 6.2.6.2.3 oferece a alternativa de perna considerada limitada a 25% do comprimento, ainda não implementada. Não se altera a perna informada nem se libera essa alternativa sem qualificação coerente. O limite 100w também é fronteira do método implementado, sem proibição normativa universal.')
    doc.add_paragraph('P901-23W completo: II.A-2A, PDF580/IIA-40, inverte as interfaces (solda no apoio e parafusos na alma); II.A-5, PDF615/IIA-75, usa viga recortada e apoio na alma. Nenhum certifica numericamente esta R015 sem recortes à mesa de pilar.')
    doc.add_paragraph('Souza, exemplo 10.1, PDF134–138, figuras 10.4–10.7: método elástico alternativo para cantoneiras L64×6,3 e VS/CVS, com momentos de extremidade transmitidos aos parafusos. Não se somam suas ações ou coeficientes históricos à idealização LCSP/NBR adotada. A inspeção consta da auditoria R015 de 10/10/2026; não é oráculo integral da conexão corrente.')
    doc.add_paragraph('Rotação, estabilidade global dos membros, ações transportadas ao modelo da estrutura, integridade, requisitos de serviço, fadiga e montagem devem ser compatibilizados pelo responsável técnico. Uma ressalva não substitui uma verificação resistente aplicável.')
    p=doc.add_paragraph();hyperlink(p,BRAND,LINK)
    out=BytesIO();doc.save(out);return out.getvalue()
