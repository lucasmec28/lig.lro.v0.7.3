"""Current-input physical views of the opposed two-row bolted gusset route.

Physical hole diameters, 2n distinct single-shear bolts, the single gusset and
shared two-fillet root are shown. Unknown catalog corners stay interrupted.
"""
from .display_precision import display_format, display_value
from dataclasses import asdict
from io import BytesIO
import hashlib
import json
import math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Arc, Circle, Polygon, Rectangle
from .drawing_annotations import dimension, rendered_wrap
from .bolted_opposed_angle_gusset import COMPONENT_VERSION
from .bolted_opposed_angle_gusset_presentation import selected_angle, angle_identity, angle_detail_disclosure

INK='#243749'; MUTED='#667788'; PLATE='#dce5ec'; ANGLE='#80b4c0'; WELD='#b13b39'; BOLT='#454f60'
STATUS={'INVALID_INPUT':'Dados inválidos','INVALID_GEOMETRY':'Geometria inválida','NUMERICAL_FAILURE':'Falha numérica',
        'OUTSIDE_SCOPE':'Fora do domínio qualificado','DETAILING_PENDING': 'MONTAGEM PENDENTE · GEOMETRIA REAL NECESSÁRIA', 'NOT_VERIFIED':'Montagem ou condições pendentes',
        'DETAIL_FAIL':'Não atende ao detalhamento','DETAILING_FAIL':'Não atende ao detalhamento',
        'INCOMPLETE_CHECKS':'Verificações incompletas','COMPLETE_CHECKS_FAIL':'Não atende às verificações locais',
        'LOCAL_CHECKS_FAIL':'Não atende às verificações locais','VERIFIED_SUBCHECK_FAIL':'Não atende às verificações locais',
        'LOCAL_CHECKS_PASS_WITHIN_SCOPE':'Atende localmente no domínio',
        'COMPLETE_LOCAL_CHECKS_PASS_WITHIN_SCOPE':'Atende localmente no domínio',
        'COMPLETE_CHECKS_PASS_WITHIN_SCOPE':'Atende localmente no domínio'}


def input_fingerprint(c):
    try: native=c.to_dict()
    except (TypeError,ValueError,ArithmeticError): native=asdict(c)
    return hashlib.sha256(json.dumps(native,ensure_ascii=False,sort_keys=True,separators=(',',':'),default=str).encode()).hexdigest()


def validated_result(c,result=None):
    """Caller-supplied results never authorize geometry or a favorable label."""
    from .bolted_opposed_angle_gusset import evaluate
    try: return evaluate(c)
    except (TypeError,ValueError,ArithmeticError) as exc:
        return {'status':'NUMERICAL_FAILURE','global_pass':False,'geometry':{'valid':False},
                'summary':{'complete_checks':False},'checks':[],'cases':[],
                'issues':[{'severity':'error','message':str(exc)}]}


def approved(r):
    return (r.get('global_pass') is True and r.get('geometry',{}).get('valid') is True
            and r.get('summary',{}).get('complete_checks') is True and bool(r.get('checks'))
            and all(x.get('status')=='PASS' for x in r['checks']))


def _n(value,divisor=1):
    try: return display_format(value/divisor,'.6g').replace('.',',')
    except (TypeError,ValueError,OverflowError): return 'não disponível'


def _line(ax,a,b,gid,**style):
    line,=ax.plot([a[0],b[0]],[a[1],b[1]],**style); line.set_gid(gid); return line


def _patch(ax,points,gid,**style):
    obj=Polygon(points,closed=True,**style);obj.set_gid(gid);ax.add_patch(obj);return obj


def _arrow(ax,a,b,gid,color=INK,lw=1.5):
    obj=ax.annotate('',xy=b,xytext=a,arrowprops={'arrowstyle':'-|>','color':color,'lw':lw});obj.set_gid(gid);obj.arrow_patch.set_gid(gid);return obj


def _rect(ax,xy,w,h,gid,**style):
    obj=Rectangle(xy,w,h,**style);obj.set_gid(gid);ax.add_patch(obj);return obj


def _section_angle(ax,c,section,sign,dh):
    """Two opposed L contours: exact nominal b/t, no invented rolled radii."""
    b,t,g,tg=section['leg'],section['t'],c.gauge,c.plate_t
    face='positive' if sign==1 else 'negative'
    v=lambda value:sign*(tg/2+value)
    z=lambda value:sign*(tg/2+value)
    for i,(lo,hi) in enumerate(((0,g-dh/2),(g+dh/2,b))):
        _line(ax,(v(lo),z(0)),(v(hi),z(0)),f'angle_contact_face_{display_value(face)}_{display_value(i)}',color=ANGLE,lw=2.4)
    _line(ax,(v(0),z(0)),(v(0),z(b)),f'angle_outer_free_leg_face_{display_value(face)}',color=ANGLE,lw=2.4)
    gap=max(t*.5,(b-t)*.16)
    _line(ax,(v(t),z(t+gap)),(v(t),z(b-gap)),f'nominal_free_inner_face_{display_value(face)}',color=ANGLE,lw=1.6,ls='--')
    for i,(lo,hi) in enumerate(((t+gap,g-dh/2),(g+dh/2,b-gap))):
        if hi>lo:_line(ax,(v(lo),z(t)),(v(hi),z(t)),f'nominal_connected_inner_face_{display_value(face)}_{display_value(i)}',color=ANGLE,lw=1.6,ls='--')
    ax.text(v(t),z(t),'?',fontsize=10,ha='center',va='center',color=MUTED,gid=f'unpublished_heel_face_{display_value(face)}')
    ax.text(v(b),z(t/2),'?',fontsize=9,ha='center',va='center',color=MUTED)
    ax.text(v(t/2),z(b),'?',fontsize=9,ha='center',va='center',color=MUTED)
    if c.heel_extent is not None:
        _line(ax,(v(c.heel_extent),z(t)),(v(c.heel_extent),z(t+15)),f'declared_heel_extent_face_{display_value(face)}',color=WELD,lw=1,ls=':')
    return v,z


def figure(c,result=None):
    r=validated_result(c,result);geometry=r.get('geometry') or {};angle=selected_angle(c,r)
    project=rendered_wrap('Projeto: '+str(c.project),980,8.5)
    extra=max(0,project.count('\n'))*.16
    height=11.5+extra
    fig=plt.figure(figsize=(14,height),facecolor='white')
    fig._bolted_opposed_angle_gusset_result=r;fig._bolted_opposed_angle_gusset_fingerprint=input_fingerprint(c)
    def text(x,y,value,gid=None,**kw):
        obj=fig.text(x,y/height,value,color=kw.pop('color',INK),**kw)
        if gid:obj.set_gid(gid)
        return obj
    count=2
    text(.035,11.12+extra,'2L OPOSTAS >< PARAFUSADAS · CHAPA ÚNICA · RAIZ DUPLA · MESA W',fontsize=15,fontweight='bold')
    text(.965,10.84+extra,'PILAR W' if c.support_member=='column' else 'VIGA W',fontsize=10,ha='right')
    text(.035,10.81+extra,project,fontsize=8.5,va='top')
    text(.035,10.41,STATUS.get(r.get('status'),str(r.get('status'))),'engine_status',fontsize=11,fontweight='bold',color=INK if approved(r) else WELD)
    text(.965,10.41,'Resultado local; não é liberação de fabricação',fontsize=8,ha='right')
    text(.035,10.13,'N total='+_n(c.N,1000)+' kN; N por L='+_n(c.N/count,1000)+' kN; '+str(2*c.n)+' parafusos físicos; '
         +'1 plano por parafuso. θ='+_n(c.theta_deg)+'° em relação a +s, eixo W.','actual_actions',fontsize=9)
    text(.035,9.89,angle_identity(angle,c.angle_profile)+'; Ag por L='+_n((angle or {}).get('Ag'))+' mm²; ec='+_n((angle or {}).get('centroid'))+' mm.',fontsize=8.5)
    safe=(geometry.get('valid') is True and angle is not None and c.arrangement == '2L-opposed' and c.support_face=='flange')
    if not safe:
        text(.055,9.15,'ENTRADA ATUAL SEM GEOMETRIA QUALIFICADA PARA ESTA VISTA','diagnostic_only',fontsize=14,fontweight='bold',color=WELD)
        lines=[angle_detail_disclosure(angle),'Nenhuma geometria anterior ou resultado fornecido pelo chamador foi reaproveitado.']
        lines += [str(x.get('message',x)) for x in r.get('issues') or []]
        text(.055,8.7,rendered_wrap('\n'.join(lines),980,10),fontsize=10,va='top')
        text(.035,.3,COMPONENT_VERSION+' · SHA-256: '+input_fingerprint(c),'input_fingerprint',fontsize=7)
        return fig
    B,H,tg=c.plate_width,c.plate_height,c.plate_t; b,t=angle['leg'],angle['t']
    theta=math.radians(c.theta_deg);co,si=math.cos(theta),math.sin(theta)
    point=lambda u,v:(c.center_s+u*co+v*si,c.center_n+u*si-v*co)
    stations=geometry.get('bolt_stations') or [c.row_offset+(i-(c.n-1)/2)*c.pitch for i in range(c.n)]
    row_v=[-(tg/2+c.gauge),tg/2+c.gauge]
    centers=geometry.get('bolt_centers') or [point(u,v) for v in row_v for u in stations]
    # Standard physical diameter is exposed by the kernel, never inferred from dn.
    dh=geometry.get('hole_diameter',c.hole_diameter)
    if isinstance(dh,dict):dh=dh['diameter']
    free=stations[0]-c.angle_end
    ends=[max(stations[-1]+c.tool_radius+c.fabrication_clearance,(row.get('forward_exit') or {}).get('u',stations[-1]+50.)+25.) for row in geometry.get('bolt_rows',[]) ]
    end=max(ends or [stations[-1]+75.])
    W=geometry['support_catalog']
    elev=fig.add_axes((.04,4.8/height,.56,4.65/height));section=fig.add_axes((.675,5.25/height,.285,3.95/height))
    support=fig.add_axes((.71,1.65/height,.24,3.25/height));longitudinal=fig.add_axes((.04,2.65/height,.56,1.2/height))
    for ax in (elev,section,support,longitudinal):ax.set_aspect('equal');ax.axis('off')
    elev.set_title('Plano da chapa · duas linhas e 2n furos físicos',loc='left',fontsize=10,pad=10)
    _patch(elev,[(-B/2,0),(B/2,0),(B/2,H),(-B/2,H)],'gusset_polygon',facecolor=PLATE,edgecolor=INK)
    _rect(elev,(-B/2-30,-W['tf']),B+60,W['tf'],'exterior_W_flange',facecolor='#aab8c4',edgecolor=INK)
    for row,sign in enumerate((-1,1)):
        heel=sign*tg/2;toe=sign*(tg/2+b)
        _patch(elev,[point(free,heel),point(free,toe),point(end,toe),point(end,heel)],
               f'connected_angle_leg_projection_row_{display_value(row)}',facecolor=ANGLE,alpha=.52,edgecolor=INK,
               linestyle='--' if sign<0 else '-')
        _line(elev,point(free,heel),point(free,toe),f'angle_free_end_row_{display_value(row)}',color=INK,lw=2)
        _line(elev,point(free,row_v[row]),point(end,row_v[row]),f'nominal_row_force_line_{display_value(row)}',color=MUTED,ls=':',lw=.8)
    elev.annotate('Continuação das duas L',xy=point(end,tg/2+b),xytext=(12,0),textcoords='offset points',fontsize=7.5,
                  arrowprops={'arrowstyle':'-','color':MUTED},color=MUTED)
    for i,center in enumerate(centers):
        circle=Circle(center,dh/2,facecolor='white',edgecolor=INK,lw=1.2,gid=f'physical_hole_{display_value(i + 1)}');elev.add_patch(circle)
        shaft=Circle(center,c.db/2,facecolor=BOLT,edgecolor=INK,lw=.6,gid=f'physical_bolt_{display_value(i + 1)}');elev.add_patch(shaft)
        elev.annotate(str(i+1),xy=center,xytext=(14,-3),textcoords='offset points',fontsize=8)
        if c.N:
            sign=1 if c.N>0 else -1
            _arrow(elev,point(stations[i%c.n]-21*sign,row_v[i//c.n]),point(stations[i%c.n]+21*sign,row_v[i//c.n]),f'gusset_hole_force_{display_value(i + 1)}',color=WELD,lw=1)
    _line(elev,(-B/2,0),(B/2,0),'root_weld_line',color=WELD,lw=4)
    p=geometry.get('force_point',(c.center_s,c.center_n));root_x=p[0]-p[1]*co/si
    _line(elev,(root_x,0),point(end+38,0),'nominal_force_line',color=INK,ls='--',lw=1)
    _line(elev,(0,0),(0,0),'root_weld_centroid',color=INK,marker='o',ms=3)
    if c.N:_arrow(elev,point(end-5,0),point(end+(35 if c.N>0 else -40),0),'actual_force_arrow')
    arc=Arc(p,55,55,theta1=0,theta2=c.theta_deg,color=INK,lw=1,gid='brace_angle_arc');elev.add_patch(arc)
    _arrow(elev,p,(p[0]+30,p[1]),'angle_reference_positive_s',color=MUTED,lw=.8)
    elev.text(p[0],p[1]-35,'+s (W)',fontsize=7,ha='center',color=MUTED,gid='reference_axis_label')
    elev.text(p[0]+38*math.cos(theta/2),p[1]+38*math.sin(theta/2),'θ='+_n(c.theta_deg)+'°',fontsize=8,ha='center',bbox={'facecolor':'white','edgecolor':'none','pad':1})
    dimension(elev,(-B/2,-45),(B/2,-45),'B='+_n(B),fontsize=8)
    dimension(elev,(B/2+30,0),(B/2+30,H),'H='+_n(H),fontsize=8,rotation=90)
    elev.text(-B/2,max(H+28,point(end+40,tg/2+b)[1]+32),'Ø físico='+_n(dh)+'; dn líquido='+_n(geometry.get('net_hole_diameter'))+'; d='+_n(c.db)+'; passo='+_n(c.pitch)+' mm',fontsize=8)
    elev.text(-B/2,-76,'Extremidade livre da L: '+_n(c.angle_end)+' mm antes do 1º furo.\nFuro na L recebe −u; furo na chapa recebe +u.',fontsize=8,va='top')
    elev.set_xlim(min(-B/2-45,root_x-20),B/2+95);elev.set_ylim(-105,max(H+48,point(end+40,tg/2+b)[1]+52))
    section.set_title('Corte normal à diagonal · duas L opostas em v / z',loc='left',fontsize=9,pad=14)
    xlo,xhi=-tg/2-b-15,tg/2+b+15
    intervals=((xlo,row_v[0]-dh/2),(row_v[0]+dh/2,row_v[1]-dh/2),(row_v[1]+dh/2,xhi))
    for i,(lo,hi) in enumerate(intervals):
        _rect(section,(lo,-tg/2),hi-lo,tg,f'single_gusset_section_{display_value(i)}',facecolor=PLATE,edgecolor=INK)
    for row,sign in enumerate((-1,1)):
        _section_angle(section,c,angle,sign,dh)
        v=row_v[row]
        lower=-tg/2-(t if sign<0 else 0);upper=tg/2+(t if sign>0 else 0)
        washer=c.washer_stack/2
        _rect(section,(v-c.db/2,lower-washer-5),c.db,upper-lower+2*washer+10,
              f'single_shear_bolt_shaft_row_{display_value(row)}',facecolor=BOLT,edgecolor=INK)
        if washer:
            _rect(section,(v-c.db,upper),2*c.db,washer,f'washer_positive_row_{display_value(row)}',facecolor='#aab8c4',edgecolor=INK)
            _rect(section,(v-c.db,lower-washer),2*c.db,washer,f'washer_negative_row_{display_value(row)}',facecolor='#aab8c4',edgecolor=INK)
        _rect(section,(v-c.db*.85,upper+washer),c.db*1.7,7,f'bolt_head_row_{display_value(row)}',facecolor=BOLT,edgecolor=INK)
        _rect(section,(v-c.db*.8,lower-washer-7),c.db*1.6,7,f'bolt_nut_row_{display_value(row)}',facecolor=BOLT,edgecolor=INK)
        z=sign*tg/2
        _line(section,(v-c.db*.9,z),(v+c.db*.9,z),f'shear_plane_row_{display_value(row)}',color=WELD,lw=2,ls='--')
        section.annotate('1 plano\n'+_n(c.N/(2*c.n),1000)+' kN',xy=(v,z),xytext=(sign*22,sign*31),
                         textcoords='offset points',fontsize=7.5,ha='center',arrowprops={'arrowstyle':'-','color':WELD},color=WELD)
        # Gauge measured from its own outside heel toward its connected toe.
        level=sign*(b+tg/2+13)
        dimension(section,(sign*tg/2,level),(v,level),'g='+_n(c.gauge),fontsize=7)
    dimension(section,(row_v[0],-b-32),(row_v[1],-b-32),'linhas: tg+2g='+_n(tg+2*c.gauge),fontsize=7)
    section.text(xlo,b+tg/2+32,'h=tg='+_n(tg)+'; v=±(tg/2+g)',fontsize=8)
    section.text(xlo,-b-53,'2 parafusos distintos neste corte; '+str(2*c.n)+' no conjunto.\nPega=tg+tL+arruelas; corte simples em cada um.\nFerragem esquemática; confirmar dimensões reais.\nRaios não publicados não são presumidos.',fontsize=7.3,va='top')
    section.set_xlim(xlo-4,xhi+4);section.set_ylim(-b-90,b+tg/2+48)
    support.set_title('Raiz dupla na mesa exterior',fontsize=10,loc='left',pad=10)
    d,bf,tf,tw=W['d'],W['bf'],W['tf'],W['tw'];rw=c.root_weld_leg
    _patch(support,[(-bf/2,0),(bf/2,0),(bf/2,-tf),(tw/2,-tf),(tw/2,-d+tf),(bf/2,-d+tf),(bf/2,-d),
                    (-bf/2,-d),(-bf/2,-d+tf),(-tw/2,-d+tf),(-tw/2,-tf),(-bf/2,-tf)],'W_section',facecolor='#becbd5',edgecolor=INK)
    _rect(support,(-tg/2,0),tg,80,'root_single_gusset',facecolor=PLATE,edgecolor=INK)
    _patch(support,[(-tg/2,0),(-tg/2-rw,0),(-tg/2,rw)],'root_fillet_left',facecolor=WELD)
    _patch(support,[(tg/2,0),(tg/2+rw,0),(tg/2,rw)],'root_fillet_right',facecolor=WELD)
    _line(support,(0,95),(0,-d-10),'W_web_centerline',color=MUTED,ls='--',lw=.8)
    support.annotate('2 filetes de '+_n(rw)+' mm',xy=(tg/2+rw,0),xytext=(30,55),fontsize=8,arrowprops={'arrowstyle':'-'})
    support.text(-bf/2,-d-28,str(W.get('name',c.support_profile))+'\nMesa/alma reais do catálogo W',fontsize=8,va='top')
    support.set_xlim(-bf/2-30,bf/2+70);support.set_ylim(-d-64,110)
    lo,hi=-c.support_end_left,c.support_end_right
    _rect(longitudinal,(lo,-bf/2),hi-lo,bf,'support_longitudinal_flange',facecolor=PLATE,edgecolor=INK)
    _line(longitudinal,(lo,0),(hi,0),'support_longitudinal_axis',color=MUTED,ls='--',lw=.8)
    for sign in (-1,1):_line(longitudinal,(-B/2,sign*tg/2),(B/2,sign*tg/2),'root_weld_'+('negative' if sign<0 else 'positive'),color=WELD,lw=2)
    dimension(longitudinal,(lo,-bf/2-45),(-B/2,-bf/2-45),_n(c.support_end_left-B/2)+' livre',fontsize=8)
    dimension(longitudinal,(-B/2,-bf/2-45),(B/2,-bf/2-45),'B='+_n(B),fontsize=8)
    dimension(longitudinal,(B/2,-bf/2-45),(hi,-bf/2-45),_n(c.support_end_right-B/2)+' livre',fontsize=8)
    longitudinal.set_xlim(lo-30,hi+30);longitudinal.set_ylim(-bf/2-90,bf/2+20)
    root=r.get('root') or {};nr=root.get('N',c.N*si);vr=root.get('V',c.N*co);mr=root.get('M',c.center_s*nr-c.center_n*vr)
    if nr:_arrow(elev,(-B/2+25,-10),(-B/2+25,25 if nr>0 else -40),'root_normal_force',color=WELD)
    if vr:_arrow(elev,(0,-15),(40 if vr>0 else -40,-15),'root_signed_shear',color=WELD)
    if abs(mr)>1e-8*max(1.,abs(nr)):
        angles=[math.radians(-40+240*i/24) for i in range(25)]
        if mr<0:angles.reverse()
        coords=[(16*math.cos(a),20+16*math.sin(a)) for a in angles]
        moment,=elev.plot([p[0] for p in coords],[p[1] for p in coords],color=WELD,lw=1)
        moment.set_gid('root_moment_arc')
        _arrow(elev,coords[-2],coords[-1],'root_signed_moment',color=WELD,lw=1)
    text(.04,4.47,'Chapa e raiz recebem N total; cada L recebe N/2. Linhas distintas mantêm seus momentos parciais.',fontsize=8.5)
    text(.04,4.22,'Raiz: Nnormal='+_n(nr,1000)+' kN; Vparalelo='+_n(vr,1000)+' kN; M='+_n(mr,1e6)+' kN m.','signed_root_actions',fontsize=9)
    text(.04,2.24,'Extensão longitudinal real do W; dois filetes centrados na alma, de comprimento B.',fontsize=8)
    text(.035,1.9,'NBR 6.1.8.2 aplicada por L: N/2 em cada linha; ec de catálogo permanece no shear lag de cada L.',fontsize=8)
    text(.035,1.65,'2L opostas ><: 2n parafusos de corte simples. A idealização não prova cancelamento físico de momentos locais de face.',fontsize=8)
    text(.035,1.40,'Aços independentes: L '+str(c.angle_steel)+'; chapa '+str(c.gusset_steel)+'; W '+str(c.support_steel)+'.',fontsize=8)
    text(.035,1.15,'Parafuso '+str(c.bolt)+'; raiz '+str(c.root_electrode)+'. Não há solda entre cantoneira e chapa.',fontsize=8)
    heel='PENDENTE' if c.heel_extent is None else _n(c.heel_extent)+' mm; origem: '+str(c.heel_extent_source)
    text(.035,.9,rendered_wrap('Extensão real do talão: '+heel+'. Ferramenta R='+_n(c.tool_radius)+' mm; folga='+_n(c.fabrication_clearance)+' mm.',950,8),fontsize=8)
    text(.035,.53,'Sinal na introdução perfurada: diagnóstico, não veto. Raiz e ligamento íntegro devem permanecer tracionados. Dimensões em mm.',fontsize=7.5)
    text(.035,.3,COMPONENT_VERSION+' · SHA-256: '+input_fingerprint(c),'input_fingerprint',fontsize=7)
    text(.035,.08,'Fonte da cantoneira: '+str(angle.get('source','não disponível')),fontsize=6.5)
    return fig


def image_bytes(c,result=None,fmt='png'):
    if fmt not in ('png','svg'):raise ValueError('Formato de desenho não suportado.')
    fig=figure(c,result)
    try:
        out=BytesIO()
        with matplotlib.rc_context({'svg.fonttype':'none'}):
            fig.savefig(out,format=fmt,dpi=150,facecolor='white',metadata={'Creator':'LRO Soluções de engenharia'})
        return out.getvalue()
    finally:plt.close(fig)


def drawing_svg(c,result=None):return image_bytes(c,result,'svg').decode('utf-8')
connection_svg=drawing_svg
connection_png=image_bytes
