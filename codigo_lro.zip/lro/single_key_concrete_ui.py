"""Explicit, family-isolated qualification of the bounded ACI key component."""
from dataclasses import asdict, replace

import streamlit as st

from .single_key_concrete import (SingleKeyConcrete, MODEL, LIMITS,
                                  qualification_signature, detail_is_current)
from .single_key_concrete_artifacts import (
    LABELS, STATUS_LABELS, _data, _n, image_bytes, json_bytes, docx_bytes, state_lines)

MODELS = {'off': 'Não selecionado · concreto da chave a complementar',
          MODEL: 'ACI 318-19 conservador · uma chave retangular maciça'}
RESTRAINTS = {'unknown': 'Não comprovada',
              'unwelded': 'Barras não soldadas e sem ligação rígida à placa',
              'welded': 'Barras soldadas ou rigidamente ligadas à placa'}
COMPRESSION = {'no_gain': 'Não creditar aumento por compressão: ψbrg=1',
               'contact_upper_bound': 'Faixa de contato qualificada como limite superior de Abp'}


def _prefix(): return st.session_state.get('_baseplate_ui_prefix', 'bp')
def _key(name): return _prefix() + '_skc_' + name
def _draft(): return '_' + _prefix() + '_single_key_concrete_draft'


def seed_single_key_concrete(value, preserve_qualification=False):
    """Import records are retained, but imports never qualify themselves."""
    if not preserve_qualification:
        value = replace(value, qualification_signature='')
    data = asdict(value)
    for name, item in data.items():
        st.session_state[_key(name)] = item
    st.session_state[_draft()] = data
    st.session_state.pop(_key('report'), None)


def restore_single_key_concrete(connection):
    data = st.session_state.get(_draft(), connection.get('single_key_concrete', {}))
    for name, default in asdict(SingleKeyConcrete()).items():
        # Explicit assignment detaches restored values from a hidden widget's
        # cleanup lifecycle. setdefault alone lets Streamlit erase the draft.
        st.session_state[_key(name)] = st.session_state.get(_key(name), data.get(name, default))


def _select(label, name, choices):
    options = list(choices)
    value = st.session_state.get(_key(name))
    if value is not None and value not in options:
        options.append(value)
    return st.selectbox(label, options, key=_key(name),
                        format_func=lambda item: choices.get(item, str(item) + ' · fora do modelo'))


def single_key_concrete_widgets():
    with st.expander('Concreto da chave única · ACI complementar', expanded=True):
        _select('Restrição real das barras à placa', 'rod_restraint', RESTRAINTS)
        st.text_input('Referência do detalhe barra–placa', key=_key('restraint_ref'))
        st.warning('Solda no perímetro da arruela não comprova barra soldada. Barras efetivamente soldadas/rigidamente ligadas exigem modelo separado de interação simultânea; não se infere Vi=0 nem V/4.')
        model = _select('Modelo complementar do concreto da chave', 'model', MODELS)
        if model == 'off':
            st.caption('O contato NBR em toda a altura física e suas ações prescritas de solda permanecem inalterados.')
            return
        st.caption('Uma chave retangular maciça centrada; cortante total assinado em um eixo. Concreto normal fissurado; três superfícies de borda reais; construção virtual de chumbador único nas bordas paralelas (ACI 17.11.3.2). ψh=1, sem ganhos de membro fino/estreito ou armadura. f′c=fck informado, sem divisão por γc.')
        st.text_area('Referência de preenchimento e consolidação junto à chave', key=_key('filled_detail_ref'))
        st.checkbox('Detalhe compatível de concreto/graute fluido não retrátil, preenchido e consolidado, sem vazio ou junta não qualificada no caminho da força.', key=_key('filled_detail_confirmed'))
        st.text_input('Referência dos furos de inspeção e ventilação', key=_key('vent_detail_ref'))
        st.checkbox('Há pelo menos um furo de 25,4 mm junto a cada face longa da chave; os furos estão considerados no modelo aplicável de placa/contato.', key=_key('vents_confirmed'))
        st.text_area('Referência da qualificação da topologia de forças e contato', key=_key('force_model_ref'))
        st.checkbox('Qualifico a topologia de contato uniforme/faixas e barras reais para os estados nativo e complementar, incluindo furos/recortes e transferência pela placa.', key=_key('force_model_confirmed'))
        st.caption('Tipo 1: faixa retangular uniforme de largura B e quatro barras externas, sem efeito de alavanca. Tipo 2: somente suas regiões C1/C2/T1/T2 e faixas próprias; nunca usa a solução de alto momento do Tipo 1. A pressão complementar é 0,65×0,85f′c, A2/A1=1. Equilíbrio não comprova por si só a flexão ou a transferência local da placa.')
        axial = st.session_state.get(_prefix()+'_N_kgf', 0.)
        if axial > 0 or st.session_state.get(_key('compression_policy')) not in COMPRESSION:
            _select('Política de aumento da resistência por compressão', 'compression_policy', COMPRESSION)
        st.caption('Quando qualquer barra tiver Ti>0, inclusive com N positivo e momento, Ase,N e sua fonte aparecem no campo compartilhado de chumbadores tracionados; não é preciso ativar os demais modos ACI para informá-las. Sem tração de barras não se exige área de aço. Cada estado usa suas próprias Ti; a razão de ancoragem usa h físico e a fileira real, não d limitado.')
        st.warning(LIMITS)


def single_key_concrete_from_state():
    old = st.session_state.get(_draft(), {})
    value = SingleKeyConcrete(**{name: st.session_state.get(_key(name), old.get(name, default))
                                 for name, default in asdict(SingleKeyConcrete()).items()})
    st.session_state[_draft()] = asdict(value)
    return value


def single_key_concrete_qualification(c):
    value = c.single_key_concrete
    if c.shear_path != 'plate' or value.model != MODEL:
        # Hidden optional components retain their record. When reactivated,
        # relevant physical changes are compared before any credit is given.
        st.session_state[_draft()] = asdict(value)
        st.session_state[_key('qualification_signature')] = value.qualification_signature
        return c
    try:
        signature = qualification_signature(c)
    except (ValueError, TypeError, OverflowError, ZeroDivisionError):
        signature = ''
    ready = (bool(signature) and value.model == MODEL and c.shear_path == 'plate'
             and value.rod_restraint == 'unwelded' and bool(value.restraint_ref.strip())
             and value.filled_detail_confirmed and bool(value.filled_detail_ref.strip())
             and value.vents_confirmed and bool(value.vent_detail_ref.strip())
             and value.force_model_confirmed and bool(value.force_model_ref.strip())
             and value.compression_policy in COMPRESSION)
    stale = bool(value.qualification_signature) and (value.qualification_signature != signature or not ready)
    if stale:
        value = replace(value, qualification_signature='')
    if c.shear_path == 'plate' and value.model == MODEL:
        with st.expander('Vínculo do detalhe ACI da chave aos dados atuais', expanded=True):
            st.caption('O vínculo registra a declaração técnica para ações, dimensões, pressão, barras e referências atuais. Importar um projeto exige nova revisão e vínculo explícito. Não constitui aprovação da base.')
            bound = st.button('Vincular detalhe ACI da chave aos dados atuais', key=_key('bind_qualification'), disabled=not ready)
            if bound:
                value = replace(value, qualification_signature=signature)
            if st.button('Remover vínculo do detalhe ACI da chave', key=_key('clear_qualification'), disabled=not bool(value.qualification_signature)):
                value = replace(value, qualification_signature='')
            if detail_is_current(replace(c, single_key_concrete=value)):
                st.success('Detalhe ACI da chave vinculado aos dados atuais; validade limitada ao componente declarado.')
            elif stale and not bound:
                st.warning('Vínculo invalidado por alteração de dados. Restaurar valores antigos não restaura a qualificação; revise e vincule novamente.')
            else:
                st.warning('Qualificação ACI ainda pendente. Falhas numéricas e superfícies locais calculáveis permanecem visíveis.')
    st.session_state[_draft()] = asdict(value)
    st.session_state[_key('qualification_signature')] = value.qualification_signature
    return replace(c, single_key_concrete=value)


def _status(label, status):
    writer = st.success if status == 'pass' else st.error if status in ('fail', 'invalid') else st.caption if status in ('not_demanded', 'off', 'calculated') else st.warning
    writer(label + ': ' + LABELS.get(status, 'PENDENTE') + '.')


def single_key_concrete_results(c, result):
    if c.shear_path != 'plate' or c.single_key_concrete.model == 'off':
        return
    d = _data(c, result)
    with st.expander('Chave única · resultados do concreto ACI conservador', expanded=True):
        _status('Componente complementar do concreto da chave', d.get('status'))
        st.caption('Chave, ligação, ancoragem e base completas: PENDENTES. Os estados são alternativos; não se combinam forças de estados distintos.')
        for name, status in d.get('statuses', {}).items():
            _status(STATUS_LABELS.get(name, name.replace('_', ' ')), status)
        for reason in d.get('reasons', []):
            st.warning(str(reason))
        st.image(image_bytes(c, result), width='stretch')
        g = d.get('geometry', {})
        st.write(f'b={_n(g.get("b"))} mm; H={_n(g.get("H"))} mm; g={_n(g.get("g"))} mm; h=H−g={_n(g.get("h"))} mm; d=min(h,2t)={_n(g.get("d"))} mm; t={_n(g.get("t"))} mm; Aef=bd={_n(g.get("Aef"))} mm².')
        st.caption('d começa na superfície real do concreto. A altura física h e o estado NBR integral são preservados. As quatro bordas do bloco são livres; dimensões/offsets vêm do bloco real.')
        for surface in d.get('edges', {}).get('surfaces', []):
            st.write(f'Superfície {surface.get("id", "—")} · face {surface.get("face", "—")}: ca1={_n(surface.get("ca1"))} mm; AVc={_n(surface.get("AVc"))} mm²; AVco={_n(surface.get("AVco"))} mm²; ψed={_n(surface.get("psi_ed"))}; ψh usado={_n(surface.get("psi_h_used"))}; Vb={_n(surface.get("Vb"),1000)} kN; φVcb={_n(surface.get("resistance"),1000)} kN; |V|={_n(surface.get("demand"),1000)} kN; índice={_n(surface.get("ratio"))}.')
            st.caption(f'Recorte inferior: {surface.get("clipped_bottom", False)}; recorte lateral: {surface.get("clipped_sides", False)}. Projeção e remoção são mostradas no desenho e no JSON; AVc não é limitado a AVco.')
        for state in d.get('states', []):
            _status('Estado ' + str(state.get('id', '—')), state.get('status'))
            for line in state_lines(state):
                st.write(line)
            for reason in state.get('reasons', []):
                st.warning(str(reason))
            bearing = state.get('bearing', {})
            _status('Contato ACI no estado ' + str(state.get('id', '—')), bearing.get('status'))
            for reason in bearing.get('reasons', []):
                st.warning(str(reason))
            anchors = state.get('anchor_modes', {})
            if anchors:
                st.write('Modos de ancoragem concorrentes deste estado:')
                st.json(anchors)
        st.caption('Construção virtual paralela diretamente autorizada por ACI 17.11.3.2/17.7.2.1(c), com origem no centro da chave; não se presume que sua área seja sempre menor que uma projeção finita de chave. Sob recorte total não se subtrai um t×d inventado.')
        st.caption('ψh=1: aumento de espessura omitido; ca1 físico, sem aumento oculto de membro estreito. Bordas paralelas usam construção virtual pontual ×2, não uma carga Vy. Sem diâmetro fictício, pryout de chave ou divisão V/4.')
        st.warning(LIMITS)
        if not d.get('stale') and d.get('source_signature'):
            st.download_button('Baixar desenho do concreto da chave SVG', image_bytes(c, result, 'svg'),
                               'Concreto_chave_ACI_LRO.svg', 'image/svg+xml', key=_key('download_svg'))
            st.download_button('Baixar resultado do concreto da chave JSON', json_bytes(c, result),
                               'Concreto_chave_ACI_LRO.result.json', 'application/json', key=_key('download_json'))
            signature = d['source_signature']
            saved = st.session_state.get(_key('report'))
            if saved and saved[0] != signature:
                st.session_state.pop(_key('report'), None)
                saved = None
            if st.button('Gerar memória local do concreto da chave', key=_key('generate_report')):
                saved = (signature, docx_bytes(c, result))
                st.session_state[_key('report')] = saved
            if saved:
                st.download_button('Baixar memória local do concreto da chave .docx', saved[1],
                                   'Concreto_chave_ACI_LRO.docx',
                                   'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                                   key=_key('download_report'))

