"""Separate wc_ UI and persistence for the conventional signed N/M/V model."""
from dataclasses import asdict, fields, replace
import hashlib
import json
import math
import pandas as pd
import streamlit as st
from .load_conventions import render as render_load_convention
from .models import Profile, profiles, STEELS, KGF, VERSION
from .w_splice_conventional import WConventional, FAMILY, COMPONENT_VERSION, evaluate, capacity_binding
from .w_splice_conventional_report import STATUS, local_pass_is_complete
from .report import BRAND, LINK, number

P={k:v for k,v in profiles().items() if v.family=='W'}
BASE=WConventional(P['W 310 x 97,0 (H)'])
PRESETS={
    'W 310 × 97 · N −600 / M +120 / V +100':BASE,
    'W 310 × 97 · reversão de M':replace(BASE,project='Emenda convencional · reversão de M',M=-120e6),
    'W 310 × 97 · reversão de V':replace(BASE,project='Emenda convencional · reversão de V',V=-100000.),
    'W 310 × 97 · momento puro':replace(BASE,project='Emenda convencional · momento puro',N=0.,V=0.),
}
CONVERSIONS={
    'N':('N_kgf',KGF),'M':('M_kgfm',KGF*1000),'V':('V_kgf',KGF),
    'torsion':('torsion_kgfm',KGF*1000),
    'minimum_N':('minimum_N_kgf',KGF),'minimum_M':('minimum_M_kgfm',KGF*1000),'minimum_V':('minimum_V_kgf',KGF),
    'member_Nc_Rd':('member_Nc_kgf',KGF),'member_Nt_Rd':('member_Nt_kgf',KGF),
    'member_M_Rd':('member_M_kgfm',KGF*1000),'member_V_Rd':('member_V_kgf',KGF),
}
PROFILE_SCALARS=('d','bf','tw','tf','clear','area','mass')
POSITIVE_WIDGETS=('flange_outer_width','flange_inner_width','inner_clear_band','flange_t',
                  'flange_pitch','flange_member_end','flange_cover_end','web_height','web_t',
                  'web_pitch','web_gauge','web_member_end','web_cover_end','hole_diameter','tool_radius')
NONNEGATIVE_WIDGETS=('gap','root_radius','fabrication_clearance')
NUMERIC_WIDGETS=POSITIVE_WIDGETS+NONNEGATIVE_WIDGETS+('db',)


def validate_widget_representation(c):
    """Reject an unrepresentable import before changing any project/report state.

    This validates controls, not the engineering domain: one flange row,
    unsupported hidden web grids and invalid geometric drafts stay diagnostic.
    """
    c.to_dict()  # Preserve strict model/schema validation for programmatic seeds.
    errors=[]
    def reject(field,value,reason):errors.append(f'{field}={value!r}: {reason}')
    options={'profile.family':('W',),'db':(16.,20.,24.,30.),
             'bolt':('ASTM F3125 A325','ASTM F3125 A490'),
             'member_steel':tuple(k for k,s in STEELS.items() if s.rolled_allowed),
             'flange_steel':tuple(k for k,s in STEELS.items() if s.plate_allowed),
             'web_steel':tuple(k for k,s in STEELS.items() if s.plate_allowed)}
    for field,allowed in options.items():
        value=c.profile.family if field=='profile.family' else getattr(c,field)
        if value not in allowed:
            reject(field,value,'valor não representável no seletor; opções: '+', '.join(map(str,allowed)))
    for field in POSITIVE_WIDGETS:
        value=getattr(c,field)
        if value<.1:reject(field,value,'mínimo representável no controle: 0.1 mm')
    for field in PROFILE_SCALARS:
        value=getattr(c.profile,field)
        if value<.01:reject('profile.'+field,value,'mínimo representável no controle: 0.01')
    for field,value in asdict(c).items():
        values=value.items() if field=='profile' else ((field,value),)
        for key,v in values:
            name='profile.'+key if field=='profile' else key
            if type(v) is int and float(v)!=v:
                reject(name,v,'inteiro não representável exatamente em precisão dupla')
    for field,(_,factor) in CONVERSIONS.items():
        value=getattr(c,field);display=value/factor
        if not math.isfinite(display) or (value!=0 and display==0):
            reject(field,value,'conversão de unidade não representável pelo controle; ação não será zerada')
    if errors:raise ValueError('; '.join(errors))


def _custom_widget_state(draft):
    p=draft['profile']
    state={'wc_manual_name':p['name'],'wc_profile_source':p['source']}
    accepted={}
    for key in PROFILE_SCALARS:
        state['wc_profile_'+key]=float(p[key])
        accepted['profile.'+key]={'raw':p[key],'display':float(p[key])}
    return state,accepted


def _restore_custom_draft(draft):
    state,accepted=_custom_widget_state(draft)
    state['wc_root_radius']=float(draft['root_radius'])
    accepted['root_radius']={'raw':draft['root_radius'],'display':state['wc_root_radius']}
    st.session_state.update(state)
    st.session_state['_w_conventional_accepted_values'].update(accepted)


def _accepted_value(field,display,factor=1.):
    """Retain exact accepted values until this control actually changes.

    No engineering tolerance and no implicit external-capacity rebind. This
    also retains JSON integer identity, which is part of the exact binding.
    """
    accepted=st.session_state['_w_conventional_accepted_values']
    previous=accepted.get(field)
    if previous is not None and display==previous['display']:
        return previous['raw']
    raw=display*factor
    accepted[field]={'raw':raw,'display':display}
    return raw


def seed(c):
    validate_widget_representation(c)
    s=st.session_state
    # Prepare the whole proposed state before committing any of it.
    proposed={};accepted={}
    for field in fields(c):
        if field.name!='profile':
            proposed['wc_'+field.name]=getattr(c,field.name)
    for name in NUMERIC_WIDGETS:
        raw=getattr(c,name);display=float(raw)
        proposed['wc_'+name]=display
        accepted[name]={'raw':raw,'display':display}
    for name,(key,factor) in CONVERSIONS.items():
        raw=getattr(c,name);display=raw/factor
        proposed['wc_'+key]=display
        accepted[name]={'raw':raw,'display':display}
    name=c.profile.name if c.profile.name in P and c.profile==P[c.profile.name] else 'W personalizado'
    proposed['wc_profile_name']=name
    proposed['_w_conventional_catalog_profile']=asdict(c.profile)
    draft=s.get('_w_conventional_custom_draft')
    if name=='W personalizado' or draft is None:
        draft={'profile':asdict(c.profile),'root_radius':c.root_radius}
    custom_state,custom_accepted=_custom_widget_state(draft)
    proposed.update(custom_state);accepted.update(custom_accepted)
    proposed['_w_conventional_custom_draft']=draft
    proposed['_w_conventional_accepted_values']=accepted
    s.update(proposed)
    s.pop('wc_report',None)


def use_example():
    seed(PRESETS[st.session_state.wc_example])


def load_project():
    try:
        upload=st.session_state.wc_upload
        if upload is None:raise ValueError('Selecione um arquivo JSON.')
        if len(upload.getvalue())>200000:raise ValueError('Arquivo maior que 200 kB.')
        seed(WConventional.from_dict(json.loads(upload.getvalue())))
        st.session_state.pop('wc_import_error',None)
    except (ValueError,TypeError,KeyError,OverflowError) as exc:
        st.session_state.wc_import_error='Não foi possível abrir: '+str(exc)


def bolt_changed():
    st.session_state.wc_hole_diameter={16.:18.,20.:22.,24.:26.,30.:33.}[st.session_state.wc_db]


def profile_changed():
    p=P.get(st.session_state.wc_profile_name)
    if p:
        st.session_state['_w_conventional_catalog_profile']=asdict(p)
        radius=max(0.,(p.d-2*p.tf-p.clear)/2)
        st.session_state.wc_root_radius=radius
        st.session_state['_w_conventional_accepted_values']['root_radius']={'raw':radius,'display':radius}
    elif '_w_conventional_custom_draft' in st.session_state:
        _restore_custom_draft(st.session_state['_w_conventional_custom_draft'])


def bind_external():
    c=WConventional.from_dict(st.session_state['_w_conventional_project'])
    st.session_state.wc_member_capacity_binding=capacity_binding(c)
    st.session_state.pop('wc_report',None)


def _inputs(items,positive=True):
    for key,label in items:
        st.number_input(label+' (mm)',min_value=.1 if positive else 0.,key='wc_'+key)


def render():
    from .w_splice_conventional_drawing import image_bytes, drawing_svg
    from .w_splice_conventional_report import create_report
    if 'wc_project' not in st.session_state:
        saved=st.session_state.get('_w_conventional_project')
        seed(WConventional.from_dict(saved) if saved else BASE)
    preserve=['wc_'+f.name for f in fields(WConventional) if f.name!='profile']
    preserve+=['wc_'+key for key,_ in CONVERSIONS.values()]
    preserve+=['wc_manual_name','wc_profile_source']+['wc_profile_'+k for k in ('d','bf','tw','tf','clear','area','mass')]
    for key in preserve:
        if key in st.session_state:st.session_state[key]=st.session_state[key]
    with st.sidebar:
        st.caption('Aplicativo '+VERSION+' · componente '+COMPONENT_VERSION)
        st.selectbox('Exemplo convencional N/M/V',list(PRESETS),key='wc_example')
        st.button('Usar exemplo convencional',on_click=use_example,use_container_width=True)
        st.file_uploader('Abrir projeto W convencional',type=['json'],key='wc_upload')
        st.button('Carregar W convencional',on_click=load_project,use_container_width=True)
        if 'wc_import_error' in st.session_state:st.error(st.session_state.wc_import_error)
        st.divider();st.caption(BRAND);st.link_button('LinkedIn · Lucas Oliveira',LINK)
    st.title('Emenda W convencional · N/M/V')
    st.caption('8 talas separadas · N e M nas mesas · V e Ve na alma · sem crédito de contato de topo')
    st.info('Forças assinadas: tração positiva. Fsuperior=N/2−M/h0 e Finferior=N/2+M/h0; Nw=Mw(0)=0. Fonte: Fakury §10.14.7 e NBR 8800:2024 + Er1:2025. A família axial M004 permanece separada.')
    st.text_input('Identificação do projeto',key='wc_project')
    left,right=st.columns([.9,1.5],gap='large')
    with left:
        name=st.selectbox('Mesmo perfil W nos dois lados',['W personalizado']+list(P),key='wc_profile_name',on_change=profile_changed)
        if name in P:
            stored=st.session_state.get('_w_conventional_catalog_profile',{})
            p=Profile(**stored) if stored.get('name')==name else P[name]
        else:
            with st.expander('Geometria do W personalizado',expanded=True):
                label=st.text_input('Designação do perfil',key='wc_manual_name');values={}
                for key,text in [('d','Altura d'),('bf','Largura bf'),('tw','Alma tw'),('tf','Mesa tf'),('clear','Altura livre de raízes'),('area','Área A (mm²)'),('mass','Massa (kg/m)')]:
                    display=st.number_input(text,min_value=.01,key='wc_profile_'+key)
                    values[key]=_accepted_value('profile.'+key,display)
                source=st.text_input('Fonte das dimensões e área',key='wc_profile_source')
                p=Profile(label,'W',source=source,**values)
        st.caption(f'd={p.d:g}; bf={p.bf:g}; tf={p.tf:g}; tw={p.tw:g} mm. Membros idênticos e coaxiais.')
        st.number_input('Normal Nsd assinada (kgf)',key='wc_N_kgf',format='%.3f')
        st.number_input('Momento Msd assinado (kgf·m)',key='wc_M_kgfm',format='%.3f')
        st.number_input('Cortante Vsd assinado (kgf)',key='wc_V_kgf',format='%.3f')
        load_convention_slot = st.empty()
        with st.expander('Ação fora do domínio'):
            st.number_input('Torção T (kgf·m)',key='wc_torsion_kgfm',format='%.3f')
            st.caption('T não nulo é registrado e bloqueia o domínio; não é descartado.')
        with st.expander('Talas e parafusos das mesas',expanded=True):
            _inputs([('flange_outer_width','Largura externa bo'),('flange_inner_width','Largura de cada tira bi'),('inner_clear_band','Faixa central livre c'),('flange_t','Espessura das seis talas de mesa')])
            st.caption('Duas externas e quatro tiras internas independentes. bo=2bi é a especialização deste domínio de partilha igual: a externa recebe F/2 e cada interna F/4; não é requisito universal da NBR.')
            st.number_input('Linhas longitudinais por lado da mesa',min_value=1,max_value=20,key='wc_flange_rows')
            _inputs([('flange_pitch','Passo longitudinal da mesa'),('flange_member_end','Borda no perfil à primeira fila'),('flange_cover_end','Borda da tala à última fila')])
        with st.expander('Duas talas de alma e malha completa'):
            _inputs([('web_height','Altura da tala'),('web_t','Espessura de cada tala'),('web_pitch','Passo longitudinal'),('web_gauge','Passo vertical'),('web_member_end','Borda no membro'),('web_cover_end','Borda da tala')])
            st.caption('Malha completa 2 × 3 por extremidade, com bordas físicas reais. Critérios de admissão e geometria são conferidos pelo motor.')
        with st.expander('Furação, folgas e materiais'):
            st.selectbox('Diâmetro do parafuso (mm)',[16.,20.,24.,30.],key='wc_db',on_change=bolt_changed)
            st.selectbox('Classe do parafuso',['ASTM F3125 A325','ASTM F3125 A490'],key='wc_bolt')
            st.number_input('Furo circular físico (mm)',min_value=.1,key='wc_hole_diameter')
            st.checkbox('Furo de broca documentado: dispensa acréscimo de 2 mm',key='wc_drilled')
            st.checkbox('Rosca excluída e documentada nos dois planos',key='wc_threads_excluded_verified')
            _inputs([('gap','Folga entre membros'),('root_radius','Envelope de raiz'),('fabrication_clearance','Folga de fabricação')],positive=False)
            _inputs([('tool_radius','Raio livre da ferramenta')])
            st.selectbox('Aço do W',[k for k,s in STEELS.items() if s.rolled_allowed],key='wc_member_steel')
            for key,label in [('flange_steel','Aço das talas de mesa'),('web_steel','Aço das talas de alma')]:
                st.selectbox(label,[k for k,s in STEELS.items() if s.plate_allowed],key='wc_'+key)
            exposure_options=list(dict.fromkeys(['painted','weathering',st.session_state.wc_exposure]))
            st.selectbox('Exposição',exposure_options,format_func=lambda x:{'painted':'Pintado / protegido','weathering':'Patinável exposto'}.get(x,x+' · fora do domínio'),key='wc_exposure')
        with st.expander('Detalhe físico de montagem e apoio',expanded=True):
            st.selectbox('Detalhe efetivamente especificado',['complete_row_supported_detail_v1','unsupported_detail'],format_func=lambda x:{'complete_row_supported_detail_v1':'Detalhe completo: membros, contato e filas apoiadas','unsupported_detail':'Condições de apoio não atendidas / outro detalhe'}[x],key='wc_assembly_detail')
            st.caption('Exige os dois membros, filas completas, contato firme nas sobreposições e todos os parafusos estruturais, porcas e arruelas instalados; restrições laterais e à torção dos membros. Sem calços com folga, tiras soltas, filas ausentes ou apoio provisório de montagem.')
            st.caption('Le e Lb consideram a ponte entre as primeiras filas e os intervalos carregados. K=1. Nenhuma inércia composta entre talas e nenhum contato de topo são creditados.')
            st.checkbox('Ações estáticas; sem fadiga ou ação cíclica',key='wc_static')
            st.checkbox('Combinações últimas normais',key='wc_normal_combination')
            st.checkbox('Membros idênticos e coaxiais',key='wc_concentric')
            st.checkbox('Ações incluem integridade aplicável ao sistema',key='wc_integrity_included')
            st.checkbox('Projeto exige resistência ao deslizamento',key='wc_no_slip_required')
        with st.expander('Ações mínimas e recomendação do membro · 6.1.5',expanded=True):
            policy=st.selectbox('Política de envelope mínimo',['pending','provided_envelope','actual_actions_engineer_choice'],format_func=lambda x:{'pending':'Pendente: selecionar política e registrar sua base','provided_envelope':'Envelope adicional fornecido pelo responsável','actual_actions_engineer_choice':'Decisão do RT: ações declaradas sem recomendação 50%/100%'}[x],key='wc_minimum_action_policy')
            if policy=='provided_envelope':
                st.number_input('Envelope mínimo N (kgf)',key='wc_minimum_N_kgf',format='%.3f')
                st.number_input('Envelope mínimo M (kgf·m)',key='wc_minimum_M_kgfm',format='%.3f')
                st.number_input('Envelope mínimo V (kgf)',key='wc_minimum_V_kgf',format='%.3f')
                st.text_input('Referência e justificativa do envelope mínimo',key='wc_minimum_reference')
            elif policy=='actual_actions_engineer_choice':
                st.text_input('Decisão e justificativa do responsável técnico',key='wc_minimum_reference')
                st.warning('O RT opta por não adotar a recomendação de 50%/100% do membro em 6.1.5.3. Registrar a decisão não dispensa os mínimos obrigatórios nem outros requisitos do projeto.')
            st.caption('As ações reais mantêm seus sinais. O mínimo obrigatório de 6.1.5.2 e eventual envelope adicional são casos separados; não substituem N/M/V reais. A recomendação do membro em 6.1.5.3 tem decisão própria. Sem política documentada, a conclusão local permanece pendente.')
            st.caption('Convenção do piso independente de 45 kN: para 0 < hypot(N,V) < 45 kN, escalar N e V no mesmo sentido; manter M independente. Resultante nula, inclusive momento puro, não cria direção nem força axial fictícia.')
        with st.expander('Membro: base externa opcional'):
            st.caption('Sem base externa, a estabilidade global do membro fica excluída da conclusão local. Informar capacidades de 5.3/5.4 e sua referência não equivale à verificação independente pelo aplicativo.')
            for key,label in [('member_Nc_kgf','Nc,Rd do membro (kgf)'),('member_Nt_kgf','Nt,Rd do membro (kgf)'),('member_M_kgfm','M,Rd do membro (kgf·m)'),('member_V_kgf','V,Rd do membro (kgf)')]:
                st.number_input(label,min_value=0.,key='wc_'+key,format='%.3f')
            st.text_input('Fonte e referência da análise externa',key='wc_member_capacity_reference')
            st.button('Vincular base externa fornecida ao caso atual',key='wc_bind_external',on_click=bind_external)
            st.caption('O vínculo é explícito e perde validade quando os dados relevantes mudam. Não certifica a qualidade da análise externa nem converte capacidades das talas em capacidades do membro.')
        st.text_area('Observações do projeto',key='wc_notes')
    values={f.name:st.session_state['wc_'+f.name] for f in fields(WConventional) if f.name!='profile' and f.name not in CONVERSIONS}
    values.update({name:_accepted_value(name,st.session_state['wc_'+name]) for name in NUMERIC_WIDGETS})
    values.update({name:_accepted_value(name,st.session_state['wc_'+key],factor) for name,(key,factor) in CONVERSIONS.items()})
    c=WConventional(p,**values)
    encoded=json.dumps(c.to_dict(),ensure_ascii=False,indent=2)
    digest=hashlib.sha256(encoded.encode()).hexdigest()
    st.session_state['_w_conventional_project']=c.to_dict()
    if name=='W personalizado':
        st.session_state['_w_conventional_custom_draft']={'profile':asdict(p),'root_radius':c.root_radius}
    if st.session_state.get('wc_report',('','',b''))[0]!=digest:st.session_state.pop('wc_report',None)
    with load_convention_slot.container():
        render_load_convention(st, 'w_splice_conventional', c.N)
    r=evaluate(c);st.session_state['_w_conventional_result']=r
    with right:
        status=STATUS.get(r['status'],r['status'])
        if r['status'] in ('INVALID_INPUT','INVALID_GEOMETRY','NUMERICAL_FAILURE','VERIFIED_SUBCHECK_FAIL','DETAIL_FAIL'):st.error(status)
        elif local_pass_is_complete(c,r):st.success(status)
        else:st.warning(status)
        st.caption('Ações originais assinadas: N='+repr(c.N)+' N; M='+repr(c.M)+' N·mm; V='+repr(c.V)+' N; T='+repr(c.torsion)+' N·mm.')
        st.caption('Conclusão somente local no domínio; estabilidade global, rigidez de pórtico e deslizamento não certificados.')
        cases=r.get('load_cases',[])
        if cases:st.caption('Casos independentes avaliados: '+', '.join(load['case_id'] for load in cases)+'. As ações suplementares não substituem o caso actual.')
        blocking=[issue['text'] for issue in r.get('issues',[]) if issue.get('severity') not in ('info','warning','external_scope')]
        if blocking:st.caption('Condições que limitam ou bloqueiam a conclusão: '+' | '.join(blocking))
        summary=r.get('summary',{})
        if summary:
            st.metric('Índice governante das verificações calculadas',number(summary.get('governing_utilization',0.),3))
            st.caption('Governa: '+str(summary.get('governing_label','não informado'))+' · '+str(summary.get('governing_check_id','')))
            if summary.get('failed_check_ids'):
                st.caption('Falha resistente calculada: '+str(len(summary['failed_check_ids']))+' linhas primitivas FAIL; identidades e casos mantidos nos envelopes e no detalhamento.')
        if r.get('geometry',{}).get('valid'):st.image(image_bytes(c,r),width='stretch')
        for issue in r.get('issues',[]):
            text=issue['text']
            if issue.get('severity') in ('invalid_input','invalid_geometry','numerical_failure','detail_fail'):st.error(text)
            elif issue.get('severity')=='info':st.caption(text)
            else:st.warning(text)
        lm=r.get('load_model',{})
        if lm:
            with st.expander('Partilha assinada e equilíbrio',expanded=True):
                st.write('Mesa superior: '+number(lm['top_force_N']/KGF,2)+' kgf; inferior: '+number(lm['bottom_force_N']/KGF,2)+' kgf.')
                st.write('Alma: Nw=0; Mw no centro=0. Cada tala recebe V/2; o grupo transfere o momento Ve.')
                for key,label in [('web_group_moment_per_cover_Nmm','Momento de grupo Ve por tala'),('web_design_moment_envelope_per_cover_Nmm','Envelope de projeto por tala: máximo de Ve e cortes'),('web_max_cut_moment_per_cover_Nmm','Máximo momento real nos cortes por tala'),('member_moment_envelope_Nmm','Envelope do membro incluindo Vx')]:
                    if key in lm:st.caption(label+': '+number(lm[key]/(KGF*1000),3)+' kgf·m')
                st.caption('Extremidades em série. As capacidades dos lados não se somam. As chapas são peças separadas.')
            with st.expander('Grupos vetoriais e cortes exatos'):
                st.json({key:lm.get(key) for key in ('web_groups','web_cut_records')})
        if r.get('minimum_action_basis'):
            with st.expander('Casos mínimos e decisão registrada'):
                st.json(r['minimum_action_basis'])
        if r.get('member_external'):
            with st.expander('Estado da base externa do membro'):
                st.json(r['member_external'])
        st.caption('A conclusão é local e limitada ao domínio indicado. Não certifica estabilidade global, rigidez de pórtico nem ausência de deslizamento.')
    if r.get('checks'):
        st.subheader('Envelopes por componente e mecanismo')
        envelopes=r.get('mechanism_envelopes',[])
        if envelopes:
            compact=[]
            for envelope in envelopes:
                x=envelope['governing_check']
                compact.append({'ID':x['id'],'Grupo':envelope['component_group'],'Mecanismo':envelope['mechanism'],
                                'Caso governante':envelope['governing_case_id'],'Solicitação':x['demand'],
                                'Resistência':x['capacity'],'Unidade':x['units'],'Índice':x['utilization'],
                                'Resultado':envelope['status'],'Linhas detalhadas':envelope['primitive_count']})
            st.dataframe(pd.DataFrame(compact),hide_index=True,width='stretch')
            st.caption('Cada envelope conserva a linha e o caso governantes. Extremidades em série e peças separadas não têm capacidades somadas; todas as linhas primitivas permanecem disponíveis abaixo.')
            with st.expander('Registros governantes completos · fórmulas, fontes e caminhos'):
                st.json(envelopes)
        rows=[{'ID':x['id'],'Componente':x['component'],'Verificação':x['label'],'Solicitação':x['demand'],'Resistência':x['capacity'],'Unidade':x['units'],'Índice':x['utilization'],'Resultado':x['status']} for x in r['checks']]
        with st.expander('Todas as verificações primitivas · componentes físicos e unidades'):
            st.dataframe(pd.DataFrame(rows),hide_index=True,width='stretch')
    st.download_button('Salvar verificações convencionais .json',json.dumps(r,ensure_ascii=False,indent=2,default=str),'verificacoes_W_convencional_NMV.json','application/json')
    a,b,d=st.columns(3)
    a.download_button('Salvar W convencional .json',encoded,'emenda_W_convencional_NMV.json','application/json')
    if r.get('geometry',{}).get('valid'):
        b.download_button('Baixar desenho W convencional .svg',drawing_svg(c,r),'emenda_W_convencional_NMV.svg','image/svg+xml')
    if d.button('Gerar memória W convencional',key='wc_generate_report',use_container_width=True):
        st.session_state.wc_report=(digest,'memoria_W_convencional_NMV.docx',create_report(c,r))
    if 'wc_report' in st.session_state:
        _,filename,payload=st.session_state.wc_report
        st.download_button('Baixar memória W convencional .docx',payload,filename,'application/vnd.openxmlformats-officedocument.wordprocessingml.document')
