"""Editable, complete and scope-safe R016 calculation report."""
from .display_precision import display_value
from collections import OrderedDict
from dataclasses import fields, is_dataclass
from io import BytesIO
from math import isfinite

from docx import Document
from docx.enum.section import WD_ORIENT, WD_SECTION_START
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Inches, Pt, RGBColor

from .angle_catalog_selection import provenance_text, LABELS as CATALOG_LABELS
from .double_angle import COMPONENT_VERSION, EXCLUSIONS, NBR, SCOPE, evaluate
from .double_angle_drawing import image_bytes
from .double_angle_presentation import physical_envelopes, governing_description
from .models import KGF, STEELS, BOLTS
from .report import BRAND, LINK, _math, group, hyperlink, number, table

STATUS={
    'INVALID_INPUT':'Entrada inválida',
    'NUMERICAL_FAILURE':'Falha numérica de cálculo',
    'INVALID_GEOMETRY':'Geometria inválida',
    'OUTSIDE_R016_SCOPE':'Fora do domínio R016',
    'OUTSIDE_SUPPORTED_SCOPE':'Fora do domínio implementado',
    'ENGINEERING_MODEL_PENDING':'Verificação completa pendente',
    'NOT_EVALUATED':'Sem avaliação resistente',
    'VERIFIED_SUBCHECK_FAIL':'Há verificação resistente não atendida',
    'DETAIL_FAIL':'Há requisito de detalhamento não atendido',
    'COMPLETE_CHECKS_PASS_WITHIN_SCOPE':'Verificações atendidas no domínio declarado',
    'COMPLETE_CHECKS_PASS_WITH_PRESET_DEVIATION':'Verificações atendidas com desvio do padrão de oficina',
}
SEVERITY={
    'invalid_input':'Entrada inválida','invalid_geometry':'Geometria inválida',
    'numerical_failure':'Falha numérica de cálculo',
    'unsupported_scope':'Fora do domínio','engineering_pending':'Pendência técnica',
    'detail_fail':'Detalhamento não atendido','warning':'Ressalva','info':'Informação',
    'error':'Erro','pending':'Pendência','excluded':'Exclusão','not_evaluated':'Não avaliado',
}
LABELS={
    'project':'Projeto','kind':'Interface do apoio','angle_count':'Quantidade de cantoneiras',
    'symmetric':'Arranjo simétrico','beam_leg':'Aba junto à viga b_viga em mm',
    'support_leg':'Aba junto ao apoio b_apoio em mm','t':'Espessura da cantoneira em mm',
    'root_radius':'Raio interno da cantoneira em mm','length':'Comprimento da cantoneira em mm',
    'angle_top':'Topo da cantoneira abaixo do topo da viga em mm',
    'beam_gauge':'Gabarito da viga desde a face do apoio em mm',
    'support_gauge':'Gabarito do apoio desde a face da alma em mm',
    'web_rows':'Parafusos comuns na alma por coluna','support_rows':'Parafusos por coluna em cada aba de apoio',
    'web_columns':'Colunas de parafusos na alma','support_columns':'Colunas por aba de apoio',
    'web_pitch':'Passo vertical na alma em mm','support_pitch':'Passo vertical no apoio em mm',
    'web_end_top':'Borda superior na aba da viga em mm','support_end_top':'Borda superior na aba de apoio em mm',
    'gap':'Folga ponta da viga até face do pilar em mm',
    'support_edge_top':'Primeiro furo até borda superior real do apoio em mm',
    'support_edge_bottom':'Último furo até borda inferior real do apoio em mm',
    'beam_steel':'Aço da viga','support_steel':'Aço do apoio','angle_steel':'Aço das cantoneiras',
    'bolt':'Classe dos parafusos','db':'Diâmetro dos parafusos em mm',
    'hole_diameter':'Diâmetro físico dos furos em mm','hole_type':'Tipo de furo',
    'drilled':'Furação por broca documentada','web_threads_excluded':'Rosca excluída de ambos os planos da alma',
    'support_threads_excluded':'Rosca excluída no plano de corte do apoio','exposure':'Exposição',
    'V':'Vsd informado em N','N':'N informado em N','M':'M informado em N mm','torsion':'T informado em N mm',
    'cope':'Recorte da viga','static':'Ações estáticas','normal_combination':'Combinação última normal',
    'no_slip_required':'Ausência de deslizamento exigida','tool_radius':'Raio de ferramenta em mm',
    'fabrication_clearance':'Folga de fabricação em mm','notes':'Observações do projeto',
}


def _mapping(value):return value if isinstance(value,dict) else {}

def _approved(r):
    blockers={'numerical_failure','invalid_input','invalid_geometry','unsupported_scope','engineering_pending','access_pending','detail_fail','error','pending'}
    return (r.get('global_pass') is True
            and r.get('status') in ('COMPLETE_CHECKS_PASS_WITHIN_SCOPE','COMPLETE_CHECKS_PASS_WITH_PRESET_DEVIATION')
            and _mapping(r.get('geometry')).get('valid') is True
            and _mapping(r.get('summary')).get('complete_checks') is True
            and bool(r.get('checks'))
            and all(isinstance(x,dict) and x.get('status')=='PASS' for x in r.get('checks',[]))
            and not any(isinstance(x,dict) and x.get('severity') in blockers for x in r.get('issues',[])))

def _num(value,places=6):
    if isinstance(value,bool) or not isinstance(value,(int,float)) or not isfinite(value):return 'não disponível'
    return number(value,places)

def _force(value):
    if isinstance(value,bool) or not isinstance(value,(int,float)) or not isfinite(value):return 'não disponível'
    return number(value/KGF,2)

def _value(value):
    if isinstance(value,bool):return 'sim' if value else 'não'
    if isinstance(value,(int,float)):return _num(value,6) if isinstance(value,float) else str(value)
    if isinstance(value,(tuple,list)):return '; '.join(_value(x) for x in value)
    if isinstance(value,dict):return '; '.join(str(k)+'='+_value(v) for k,v in value.items())
    return str(value) if value is not None else 'não disponível'

def _tab(doc,headers,rows,widths,size=8.3):
    t=table(doc,headers,rows,widths)
    for row in t.rows:
        for i,cell in enumerate(row.cells):
            for paragraph in cell.paragraphs:
                if i==0:paragraph.alignment=WD_ALIGN_PARAGRAPH.LEFT
                for run in paragraph.runs:run.font.size=Pt(size)
    return t

def _section(doc,landscape=False):
    s=doc.add_section(WD_SECTION_START.NEW_PAGE)
    s.orientation=WD_ORIENT.LANDSCAPE if landscape else WD_ORIENT.PORTRAIT
    s.page_width=Inches(11.69 if landscape else 8.27);s.page_height=Inches(8.27 if landscape else 11.69)
    s.top_margin=s.bottom_margin=Inches(.48)
    s.left_margin=s.right_margin=Inches(.60)
    return s


def _inputs(doc,c,r):
    if c.angle_catalog_id:
        doc.add_paragraph(provenance_text(c))
    doc.add_paragraph('Dados completos da entrada',style='Heading 1')
    doc.add_paragraph('Todos os campos da entrada são registrados abaixo. Dimensões e furos de cada interface permanecem independentes; nenhuma dimensão do apoio é substituída pela da viga.')
    doc.add_paragraph('Perfis: d, bf, tw, tf e clear em mm; area em mm²; mass em kg/m. A geometria derivada usa mm, áreas em mm² e contagens adimensionais, conforme o identificador de cada campo.')
    for key,label in (('beam','Viga apoiada'),('support','Pilar de apoio')):
        p=getattr(c,key,None)
        doc.add_paragraph(label,style='Heading 2')
        if is_dataclass(p):
            _tab(doc,['Campo do perfil','Valor'],[(f.name,_value(getattr(p,f.name))) for f in fields(p)],[2.1,4.97])
        else:doc.add_paragraph(str(p))
    rows=[]
    for f in fields(c):
        if f.name not in ('beam','support'):
            rows.append((CATALOG_LABELS.get(f.name, LABELS.get(f.name,f.name))+'\n'+f.name,_value(getattr(c,f.name))))
    _tab(doc,['Grandeza e campo de entrada','Valor informado'],rows,[4.3,2.77])
    doc.add_paragraph('Materiais e coeficientes',style='Heading 2')
    for name in dict.fromkeys((c.beam_steel,c.support_steel,c.angle_steel)):
        steel=STEELS.get(name)
        doc.add_paragraph(str(name)+': '+(f'fy={display_value(_num(steel.fy, 3))} MPa; fu={display_value(_num(steel.fu, 3))} MPa.' if steel else 'material não cadastrado; sem resistência presumida.'))
    bolt=BOLTS.get(c.bolt)
    if bolt is not None:
        fub=bolt if isinstance(bolt,(int,float)) else getattr(bolt,'fu',getattr(bolt,'fub',None))
        doc.add_paragraph('Parafuso '+str(c.bolt)+': fub='+_num(fub,3)+' MPa.')
    doc.add_paragraph('γa1=1,10; γa2=1,35. Limites do produto, faixas de espessura, corrosão, fabricação e montagem continuam aplicáveis.')
    doc.add_paragraph('Premissas fixas do modelo',style='Heading 2')
    doc.add_paragraph('Contato direto e firme em todas as superfícies ligadas, sem calços e sem folgas nessas interfaces. A folga da ponta da viga até a face do pilar é uma dimensão distinta. Parafusos, porcas e arruelas seguem a montagem da NBR 6.8, sem crédito resistente por atrito ou protensão.')
    doc.add_paragraph('Viga e pilar W laminados contínuos na região da ligação, sem recortes, aberturas adicionais ou descontinuidades soldadas locais. A tabela registra as premissas fixas que acompanham o arquivo nativo.')
    _tab(doc,['Premissa','Valor declarado'],[(str(k),_value(v)) for k,v in c.fixed_assumptions.items()],[3.6,3.47],size=8)
    doc.add_paragraph('O atendimento local R016 não representa verificação completa do edifício, da estabilidade ou do dimensionamento global da viga e do pilar. Contato, montagem, rotações e ações transportadas devem corresponder ao modelo estrutural.')
    g=_mapping(r.get('geometry'))
    doc.add_paragraph('Geometria derivada e diagnóstico',style='Heading 2')
    if g:
        rows=[(str(k),_value(v)) for k,v in g.items() if k not in ('checks','issues','detailing_checks')]
        if rows:_tab(doc,['Grandeza retornada pelo motor','Valor'],rows,[3.4,3.67],size=8)
        gchecks=[x for x in g.get('checks',[]) if isinstance(x,dict)]
        if gchecks:
            _tab(doc,['Critério geométrico','Valor / exigência em mm','Estado'],
                 [(str(x.get('id',''))+'\n'+str(x.get('reference','')),
                   _num(x.get('actual'),3)+' / '+str(x.get('relation',''))+' '+_num(x.get('limit'),3),
                   'Atende' if x.get('passed') else 'Não atende') for x in gchecks],[3.65,2.35,1.07],size=7.8)
    else:doc.add_paragraph('O motor não forneceu geometria derivada nesta avaliação.')
    doc.add_paragraph('O furo físico dh é usado no desenho e no contato. A dedução líquida dn segue a maior dimensão circular da Tabela 14 acrescida de 2 mm, salvo furação por broca explicitamente documentada. A opção de fabricação não é inferida do diâmetro digitado.')
    doc.add_paragraph('Bordas livres do apoio são medidas do primeiro e último furo até as extremidades reais do pilar; as laterais são as bordas reais da mesa. A junção mesa–alma não é borda livre. No desenho local da elevação, o fuste interrompido não cria uma extremidade resistente.')


def _loads(doc,c,r):
    doc.add_paragraph('Ações e caminho das forças',style='Heading 1')
    lm=_mapping(r.get('load_model'))
    rows=[('Vsd com sinal da entrada',_force(c.V),'kgf'),
          ('Vd adotado na conferência',_force(lm.get('Vd_N')),'kgf'),
          ('N informado',_force(c.N),'kgf'),('M informado',_num(c.M/(KGF*1000),3),'kgf m'),
          ('T informado',_num(c.torsion/(KGF*1000),3),'kgf m')]
    _tab(doc,['Ação','Valor','Unidade'],rows,[4.0,1.65,1.42])
    doc.add_paragraph('V positivo é representado para baixo na viga; V negativo, para cima. O sinal determina a borda carregada em cada peça e deve ser preservado. As ações já são de cálculo; o módulo não aplica fatores de majoração.')
    if lm:
        _tab(doc,['Parâmetro do modelo de ações','Valor'],[(str(k),_value(v)) for k,v in lm.items()],[3.3,3.77],size=8)
    else:doc.add_paragraph('Modelo resistente não executado; não se atribuem forças ou capacidades favoráveis a componentes não avaliados.')
    _math(doc,group('Vângulo = Vd/2;   Vparafuso,alma = Vd/nalma;   Vplano,alma = Vd/(2nalma)'))
    _math(doc,group('Vparafuso,apoio = Vd/(2napoio);   nplanos,alma = 2;   nplanos,apoio = 1'))
    doc.add_paragraph('Identificação física: A1 é a cantoneira do lado −z (angle_negative); A2 é a cantoneira do lado +z (angle_positive).')
    g=_mapping(r.get('geometry'));groups=_mapping(r.get('bolts')).get('groups',[])
    if groups:
        doc.add_paragraph('Total físico de parafusos: '+str(g.get('total_bolt_count','não disponível'))+'.')
        _tab(doc,['Grupo físico','Quantidade','Planos por parafuso','Força por parafuso kgf','Força por plano kgf'],
             [(x.get('id',''),x.get('bolt_count',''),x.get('shear_planes',''),_force(x.get('each_bolt_force_N')),_force(x.get('each_plane_force_N'))) for x in groups],[2.3,.85,1.2,1.36,1.36],size=8)
    doc.add_paragraph('O mesmo parafuso atravessa cantoneira A1, alma da viga e cantoneira A2. Há dois planos de corte e uma única alma, cuja espessura não é duplicada. Cada aba de apoio tem um grupo próprio de parafusos em corte simples. A divisão V/2 somente vale no par simétrico do domínio declarado.')
    doc.add_paragraph('O caminho resistente é sucessivo: alma da viga, parafusos comuns, duas cantoneiras, parafusos do apoio e mesa do pilar. Capacidades de interfaces em série não são somadas. A ausência de N, M e T externos não elimina as excentricidades geométricas; as hipóteses do mecanismo flexível convencional e as ações transportadas ao apoio constam do resultado.')
    doc.add_paragraph('A resistência mínima eventualmente adotada incide uma vez no conjunto, antes da divisão entre cantoneiras. As tabelas distinguem a solicitação efetiva Vsd da solicitação da conferência Vd; nenhuma linha recebe aprovação por arredondamento do índice.')


def _envelopes(doc,r):
    envelopes=physical_envelopes(r)
    if not envelopes:return
    doc.add_paragraph('Envelopes por componente e mecanismo',style='Heading 1')
    doc.add_paragraph(f"{display_value(len(envelopes))} envelopes de apresentação conservam todas as {display_value(len(r['checks']))} linhas primitivas no desenvolvimento. Os governantes real e adotado são selecionados separadamente; cada solicitação e resistência abaixo pertence à sua própria linha governante. Não há soma ou aumento de resistências. Contato inclui soma normativa e compatibilidade uniforme por furo, mantidas distintas no detalhe.")
    rows=[]
    for item in envelopes:
        actual=item['actual_governing'];adopted=item['adopted_governing']
        rows.append((item['component_label']+'\n'+item['mechanism_label'],
                     _force(actual['actual_demand_N'])+' / '+_force(actual['design_capacity_N']),
                     _force(adopted['demand_N'])+' / '+_force(adopted['design_capacity_N']),
                     _num(item['actual_utilization'])+'\n'+_num(item['adopted_utilization']),
                     'Falha' if item['status']=='FAIL' else 'Atende'))
    _tab(doc,['Componente e mecanismo','Sd real / Rd\nkgf','Sd conf. / Rd\nkgf','ηreal / ηd','Estado'],rows,[2.52,1.45,1.45,1.03,.62],size=8)
    doc.add_paragraph('Casos sentidos e ramos governantes',style='Heading 2')
    for item in envelopes:
        p=doc.add_paragraph();p.add_run(item['component_label']+' · '+item['mechanism_label']+'. ').bold=True
        for key,label in (('actual','Real'),('adopted','Adotado')):
            record=item[key+'_governing'];ties=item[key+'_governing_ties']
            p.add_run(label+': '+governing_description(record)+'. ')
            if len(ties)>1:p.add_run('Empates: '+', '.join(row['id'] for row in ties)+'. ')
            p.add_run('Caso: '+_value(record['case'])+'. ')
    doc.add_paragraph('Os registros completos de todos os ramos, inclusive cada governante e empate acima, seguem em Todas as verificações calculadas e Áreas trajetos e valores auxiliares; os identificadores fazem a ligação exata entre resumo e desenvolvimento.')


def _checks(doc,r):
    checks=[x for x in r.get('checks',[]) if isinstance(x,dict)]
    doc.add_paragraph('Equações editáveis e referências',style='Heading 1')
    if not checks:
        doc.add_paragraph('Não há verificações resistentes calculadas. A ausência de linhas não significa atendimento. As pendências e o estado do motor impedem atribuir aprovação.')
        return
    formulas=OrderedDict()
    for row in checks:
        key=(str(row.get('formula','Fórmula não fornecida')),str(row.get('reference','Referência não fornecida')))
        formulas.setdefault(key,'E'+str(len(formulas)+1))
    for (formula,reference),code in formulas.items():
        doc.add_paragraph(code,style='Heading 2')
        _math(doc,group(formula))
        doc.paragraphs[-1].paragraph_format.keep_with_next=True
        doc.add_paragraph(reference)
    doc.add_paragraph('Ag e An: áreas bruta e líquida ao cisalhamento. Agv e Anv: áreas bruta e líquida ao corte no bloco; Ant: área líquida à tração; Cts: coeficiente de distribuição de tensão. fy, fu e fub: resistências características; db: diâmetro do parafuso; dh: furo físico; dn: dedução líquida; lc: ligamento livre; α: coeficiente por plano de corte; γa1 e γa2: coeficientes de resistência.')
    doc.add_paragraph('Blocos e contato usam os furos, bordas e a parcela de força da própria peça. Uma aba sem furo não recebe dedução da outra. A soma normativa das resistências de contato dos furos é distinta de multiplicar a capacidade do pior furo pelo número total de parafusos.')
    doc.add_paragraph('Todas as verificações calculadas',style='Heading 1')
    doc.add_paragraph(f'Total de {display_value(len(checks))} linhas. Sd e Rd correspondem à própria linha. ηreal usa a ação informada; ηd usa a ação adotada na conferência. A fórmula e a referência de cada linha são identificadas por E. Os estados são fornecidos pelo motor antes do arredondamento visual.')
    grouped=OrderedDict()
    for row in checks:grouped.setdefault(str(row.get('component','Sem componente')),[]).append(row)
    for component,items in grouped.items():
        doc.add_paragraph(component.replace('_',' '),style='Heading 2')
        rows=[]
        for row in items:
            fkey=(str(row.get('formula','Fórmula não fornecida')),str(row.get('reference','Referência não fornecida')))
            state={'PASS':'Atende','FAIL':'Falha','NOT_EVALUATED':'Não avaliado','PENDING':'Pendente'}.get(row.get('status'),str(row.get('status','Não avaliado')))
            rows.append((str(row.get('label',''))+'\n'+str(row.get('id','')),
                         _force(row.get('actual_demand_N')),_force(row.get('demand_N')),
                         _force(row.get('design_capacity_N')),_num(row.get('actual_utilization'))+'\n'+_num(row.get('utilization')),
                         state,formulas[fkey]))
        _tab(doc,['Verificação e ID','Sd real\nkgf','Sd conf.\nkgf','Rd\nkgf','ηreal\nηd','Linha','Eq'],rows,[2.50,.84,.84,.84,.96,.62,.47],size=7.8)
    # Preserve every optional computed detail supplied by the engine. These
    # are supporting numbers, not a second independently rounded calculation.
    standard={'id','label','component','demand_N','actual_demand_N','design_capacity_N','utilization','actual_utilization','status','formula','reference'}
    details=[(str(row.get('id','')),[(str(k),v) for k,v in row.items() if k not in standard]) for row in checks]
    details=[(cid,items) for cid,items in details if items]
    if details:
        doc.add_paragraph('Áreas trajetos e valores auxiliares',style='Heading 1')
        for cid,items in details:
            p=doc.add_paragraph();p.add_run(cid+': ').bold=True
            p.add_run('; '.join(k+' = '+_value(v) for k,v in items)+'.')


def create_report(c,r=None):
    """Re-evaluate current input; optional caller result never authorizes a report."""
    r=evaluate(c)
    doc=Document();s=doc.sections[0]
    s.page_width=Inches(8.27);s.page_height=Inches(11.69)
    s.top_margin=s.bottom_margin=Inches(.48);s.left_margin=s.right_margin=Inches(.60)
    for name in ('Normal','Title','Subtitle','Heading 1','Heading 2'):
        style=doc.styles[name];style.font.name='Arial';style.font.color.rgb=RGBColor(0,0,0)
    for style in doc.styles:
        for b in style.element.xpath('.//w:pBdr'):b.getparent().remove(b)
    doc.styles['Normal'].font.size=Pt(9);doc.styles['Normal'].paragraph_format.space_after=Pt(5)
    doc.styles['Title'].font.size=Pt(21);doc.styles['Subtitle'].font.size=Pt(11)
    doc.styles['Heading 1'].font.size=Pt(12);doc.styles['Heading 2'].font.size=Pt(10)
    doc.core_properties.title='Memória de cálculo da ligação R016 com duas cantoneiras'
    doc.core_properties.author='LRO Soluções de engenharia LTDA.'
    doc.core_properties.subject='Duas cantoneiras parafusadas entre alma de viga e mesa de pilar'
    doc.add_paragraph('Memória de cálculo da ligação R016',style='Title')
    doc.add_paragraph('Duas cantoneiras parafusadas sob cortante vertical',style='Subtitle')
    doc.add_paragraph(str(c.project))
    doc.add_paragraph(c.beam.name+' → '+c.support.name+' | Componente '+COMPONENT_VERSION)
    status=str(r.get('status','RESULTADO INCOMPLETO'))
    p=doc.add_paragraph();p.add_run(STATUS.get(status,status)).bold=True
    doc.add_paragraph('Estado do motor: '+status+'.')
    doc.add_paragraph('Esta memória registra a entrada completa e todas as verificações calculadas da família R016, composta por duas cantoneiras L entre a alma da viga e a mesa do pilar. Entradas que alteram essa topologia permanecem identificadas e não recebem aprovação pelo modelo do par. O domínio é a ligação usual flexível R016 com par simétrico sob V estático e N=M=T=0, sem recortes na viga.')
    if not _approved(r):
        p=doc.add_paragraph('Não há aprovação global da ligação nesta avaliação. Linhas atendidas não eliminam falhas, verificações ausentes ou limites de escopo.');p.runs[0].bold=True
    else:
        doc.add_paragraph('O atendimento se limita às verificações e hipóteses declaradas. A compatibilização com os materiais efetivos, a estrutura, a rotação e a montagem permanece sob responsabilidade técnica.')
    summary=_mapping(r.get('summary'));lm=_mapping(r.get('load_model'))
    _tab(doc,['Síntese da avaliação','Resultado'],[
        ('Vsd da entrada em kgf',_force(c.V)),('Vd da conferência em kgf',_force(lm.get('Vd_N'))),
        ('Verificação governante',str(summary.get('governing_label',summary.get('governing_check_id','não disponível')))),
        ('Índice governante real',_num(summary.get('actual_governing_utilization'))),
        ('Índice governante da conferência',_num(summary.get('governing_utilization'))),
        ('Número de verificações calculadas',len(r.get('checks',[]))),
        ('Quantidade de cantoneiras informada',c.angle_count),
        ('Atendimento local R016 no domínio','sim, no domínio' if _approved(r) else 'não'),
    ],[3.7,3.37])
    doc.add_paragraph('Unidades internas: N, mm e MPa; momentos em N mm. A apresentação de forças usa kgf, com 1 kgf = 9,80665 N. O relatório conserva os valores do motor sem arredondamento intermediário; o arredondamento exibido não altera a decisão.')
    doc.add_paragraph('Pendências e condições de uso',style='Heading 1')
    issues=[x for x in r.get('issues',[]) if isinstance(x,dict)]
    if not issues:doc.add_paragraph('Nenhuma ocorrência foi fornecida pelo motor. A ausência de ocorrências não amplia o domínio nem substitui verificações ausentes.')
    for issue in issues:
        p=doc.add_paragraph();p.add_run(SEVERITY.get(issue.get('severity'),str(issue.get('severity','Ocorrência')))+': ').bold=True
        p.add_run(str(issue.get('text','Sem descrição.')))
        if issue.get('reference'):p.add_run(' Referência: '+str(issue['reference'])+'.')
    try:png=image_bytes(c,r)
    except (ValueError,TypeError,AttributeError,OverflowError) as exc:
        doc.add_paragraph('Desenho não gerado por entrada sem representação segura: '+str(exc))
    else:
        _section(doc,True)
        p=doc.add_picture(BytesIO(png),width=Inches(9.85))
        p._inline.docPr.set('descr','R016 com elevação, frente do pilar com bordas livres reais e planta de duas cantoneiras L independentes A1 e A2. Parafusos comuns à alma em corte duplo e dois grupos de apoio em corte simples. Quantidades e sinal da força seguem a entrada.')
        _section(doc,False)
    _inputs(doc,c,r);_loads(doc,c,r);_envelopes(doc,r);_checks(doc,r)
    not_applicable=[x for x in r.get('not_applicable',[]) if isinstance(x,dict)]
    if not_applicable:
        doc.add_paragraph('Mecanismos não aplicáveis ao domínio',style='Heading 1')
        for item in not_applicable:
            doc.add_paragraph(str(item.get('mechanism',''))+': '+str(item.get('reason',''))+' Referência: '+str(item.get('reference',''))+'.')
    doc.add_paragraph('Domínio fontes e responsabilidade técnica',style='Heading 1')
    scope=r.get('scope',SCOPE)
    doc.add_paragraph(str(scope.get('statement',SCOPE)) if isinstance(scope,dict) else str(scope))
    for exclusion in r.get('exclusions',EXCLUSIONS):doc.add_paragraph(str(exclusion),style='List Bullet')
    doc.add_paragraph('Fonte geométrica: PADRÃO DE LIGAÇÕES 2Model, R016, página impressa 19. Duas cantoneiras com ambas as interfaces parafusadas à alma da viga e à mesa do pilar. A nota manda despachar as cantoneiras com a viga. Na tabela industrial, N conta intervalos: n de parafusos=N+1; Z é altura livre e não comprimento automático da cantoneira.')
    doc.add_paragraph('Base normativa: '+NBR+'. Resistência e detalhamento seguem as referências específicas de cada verificação, incluindo 6.1, 6.3 e 6.5.5 a 6.5.6.')
    doc.add_paragraph('Gerdau, Ligações para Estruturas de Aço, 7ª edição, 2018, páginas 19 a 27 e tabela LCPP na página 33: geometria e mecanismo convencional. Seus valores históricos usam NBR 8800:2008 e não são um resultado atual convertido por fator global. O manual informa na página 9 que suas tabelas não verificam o elemento de apoio; nesta avaliação o apoio é um componente separado.')
    doc.add_paragraph('AISC P901-23W v16.0 completo recuperado: exemplo II.A-1A, páginas impressas IIA-2 a IIA-13 (PDF 542 a 553), conferido na auditoria R016 como apoio à topologia, corte duplo/simples, contato por furo e tratamento do apoio. Não substitui os coeficientes NBR atuais nem a verificação conservadora da alma adotada com base no Gerdau.')
    doc.add_paragraph('A tese Higgins e o relatório Green/Sputo/Higgins são referências históricas não recuperadas nesta cópia; não se afirma leitura integral nem se usam esses documentos para fechar nova qualificação. Cantoneiras axiais ligadas a gusset e juntas soldadas pertencem a outras topologias, fora desta avaliação R016.')
    doc.add_paragraph('Rotação, estabilidade global dos membros, ações transportadas ao modelo da estrutura, integridade, requisitos de serviço, fadiga e montagem devem ser compatibilizados pelo responsável técnico. Uma ressalva não substitui uma verificação resistente aplicável.')
    p=doc.add_paragraph();hyperlink(p,BRAND,LINK)
    out=BytesIO();doc.save(out);return out.getvalue()
