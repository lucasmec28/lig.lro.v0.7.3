"""Two opposed fillets on a single rectangular key; separate execution record."""
from dataclasses import asdict, replace
import math

import streamlit as st

from .single_key_weld import SingleKeyWeld, LIMITS, qualification_signature, detail_is_current
from .report import number

MODELS = {'off': 'Não selecionado · soldas da chave pendentes',
          'two_opposed_fillets': 'Chapa única · dois filetes opostos contínuos'}
STATUS_LABELS = {'weld_metal': 'Metal dos dois filetes', 'weld_detail': 'Detalhamento numérico',
                 'geometry': 'Geometria e implantação', 'domain': 'Domínio geométrico', 'materials': 'Materiais e processo',
                 'execution': 'Execução e vínculo documental', 'qualification': 'Vínculo documental'}


def _prefix(): return st.session_state.get('_baseplate_ui_prefix', 'bp')
def _key(name): return _prefix() + '_skw_' + name
def _draft(): return '_' + _prefix() + '_single_key_weld_draft'


def seed_single_key_weld(weld, width=None):
    data = asdict(weld)
    for name, value in data.items():
        st.session_state[_key(name)] = float(value) if type(value) in (int, float) else value
    st.session_state[_draft()] = data
    st.session_state[_key('_previous_measure')] = weld.measure
    st.session_state.pop(_key('_physical_leg'), None)
    standard=(width is not None and weld.real_length==width and weld.effective_length==width
              and weld.weld_type=='fillet' and weld.layout=='two_equal_continuous')
    st.session_state[_key('_length_mode')]='full_width' if standard else 'manual'
    st.session_state[_key('_length_mode_draft')]=st.session_state[_key('_length_mode')]


def restore_single_key_weld(connection):
    s = st.session_state
    data = s.get(_draft(), connection.get('single_key_weld', {}))
    for name, default in asdict(SingleKeyWeld()).items():
        value = data.get(name, default)
        s[_key(name)] = s.get(_key(name), float(value) if type(value) in (int, float) else value)
    s.setdefault(_key('_previous_measure'), data.get('measure', 'leg'))
    s[_key('_length_mode')]=s.get(_key('_length_mode'),s.get(_key('_length_mode_draft'),'manual'))


def _select(label, name, options):
    choices = list(options)
    current = st.session_state.get(_key(name))
    if current is not None and current not in choices:
        choices.append(current)
    return st.selectbox(label, choices, key=_key(name),
                        format_func=lambda value: options.get(value, str(value) + ' · fora do modelo'))


def single_key_weld_measure_changed():
    """Change display representation without changing the physical equal-leg fillet."""
    s = st.session_state
    previous = s.get(_key('_previous_measure'), 'leg')
    selected = s[_key('measure')]
    size = s[_key('size')]
    if previous in ('leg', 'throat') and selected in ('leg', 'throat') and previous != selected:
        remembered = s.get(_key('_physical_leg'))
        expected = remembered if previous == 'leg' else remembered / math.sqrt(2) if remembered is not None else None
        leg = remembered if remembered is not None and size == expected else size * (math.sqrt(2) if previous == 'throat' else 1)
        s[_key('_physical_leg')] = leg
        s[_key('size')] = leg if selected == 'leg' else leg / math.sqrt(2)
    s[_key('_previous_measure')] = selected


def single_key_weld_widgets():
    with st.expander('Solda da chave de chapa única · dois filetes', expanded=True):
        model = _select('Componente resistente da solda da chave', 'model', MODELS)
        if model == 'off':
            st.caption('As ações prescritas Vw e Mw permanecem; resistência das soldas e transferência ao metal-base pendentes.')
            return
        _select('Tipo de solda da chave', 'weld_type', {'fillet': 'Filete de pernas iguais a 90°'})
        _select('Arranjo da solda da chave', 'layout',
                {'two_equal_continuous': 'Dois filetes iguais, opostos, retos e contínuos'})
        choices = {'leg': 'Perna z', 'throat': 'Garganta a = z/√2'}
        options = list(choices)
        current = st.session_state.get(_key('measure'))
        if current not in options:
            options.append(current)
        st.selectbox('Dimensão informada do filete da chave', options, key=_key('measure'),
                     format_func=lambda value: choices.get(value, str(value) + ' · fora do modelo'),
                     on_change=single_key_weld_measure_changed)
        st.number_input('Tamanho do filete da chave (mm)', key=_key('size'), format='%.6f')
        size = st.session_state[_key('size')]
        measure = st.session_state[_key('measure')]
        if measure in choices and math.isfinite(size):
            leg = size if measure == 'leg' else size * math.sqrt(2)
            st.caption(f'Perna física z={number(leg, 6)} mm; garganta a={number(leg / math.sqrt(2), 6)} mm. A troca de representação conserva o filete.')
        supported=(st.session_state[_key('weld_type')]=='fillet' and
                   st.session_state[_key('layout')]=='two_equal_continuous')
        length_mode=st.selectbox('Comprimento dos dois filetes da chave', ['full_width','manual'],
            key=_key('_length_mode'),format_func=lambda v:'Largura completa da chave · Lreal=Leff=bh' if v=='full_width' else 'Comprimentos informados · preservar detalhe importado')
        st.session_state[_key('_length_mode_draft')]=length_mode
        if length_mode=='full_width' and supported:
            width=st.session_state[_prefix()+'_lug_bh']
            st.session_state[_key('real_length')]=float(width)
            st.session_state[_key('effective_length')]=float(width)
            st.caption(f'Lreal = Leff = bh = {number(width,3)} mm por filete, derivados da largura física da chave.')
        else:
            st.number_input('Comprimento real de cada filete da chave Lreal (mm)', key=_key('real_length'), format='%.3f')
            st.number_input('Comprimento efetivo de cada filete da chave Leff (mm)', key=_key('effective_length'), format='%.3f')
            st.caption('Comprimentos importados preservados. O componente só atribui capacidade no detalhe completo Lreal=Leff=bh; valores diferentes permanecem fora desse domínio.')
        st.caption('Dois filetes opostos a tamanho completo, inclusive extremidades. Sem desconto automático de 2z, retornos ou contorno fictício. Cada raiz fica em x=±tpv/2; o braço analítico do binário é ac=tpv+2z/3.')
        _select('Processo da solda da chave', 'process', {'smaw_e7018': 'SMAW / E7018 · fw=485 MPa'})
        st.checkbox('Execução em passe único comprovada para o mínimo de filete adotado.', key=_key('single_pass_confirmed'))
        st.text_area('Referência do procedimento e registro de execução da chave', key=_key('execution_ref'))
        st.checkbox('Confirmo dois filetes iguais contínuos a tamanho completo, raízes e pés em placa íntegra, prateleira livre, acesso e ausência de interferências.', key=_key('detail_confirmed'))
        st.caption('Os aços reais da chave e da placa são informados separadamente nas entradas da base. E7018 não qualifica por si só a execução. Sem furos, recortes, torção, segundo eixo, carregamento cíclico ou transferência antes do graute. Este componente não se aplica à cruz ou ao perfil W.')
        st.warning('Ações integrais da NBR 6.7.2.4: Vw = resistência de contato do concreto e Mw = Vw(H+g)/2, inclusive envelope positivo com V=0. Não usar V aplicado nem reduzir pelas resistências do aço da chave. O transporte global continua somente com V aplicado.')


def single_key_weld_from_state():
    s = st.session_state
    previous = s.get(_draft(), {})
    data = {name: s.get(_key(name), previous.get(name, default))
            for name, default in asdict(SingleKeyWeld()).items()}
    weld = SingleKeyWeld(**data)
    s[_draft()] = asdict(weld)
    return weld


def single_key_weld_qualification(c):
    """A changed input clears the old binding; returning to old values cannot restore it."""
    u = c.single_key_weld
    try:
        signature = qualification_signature(c)
    except (ValueError, TypeError, OverflowError):
        signature = ''
    stale = bool(u.qualification_signature) and (u.qualification_signature != signature or
              u.model != 'two_opposed_fillets' or c.shear_path != 'plate' or not u.detail_confirmed)
    if stale:
        u = replace(u, qualification_signature='')
    if c.shear_path == 'plate' and u.model == 'two_opposed_fillets':
        with st.expander('Vínculo do registro de execução da chave', expanded=True):
            ready = bool(signature and u.single_pass_confirmed and u.detail_confirmed and u.execution_ref.strip())
            st.caption('O responsável técnico vincula o registro às ações, geometria, materiais, processo e detalhe atuais. O vínculo registra uma declaração; não verifica o conteúdo do procedimento nem aprova o conjunto completo.')
            bound_now = st.button('Vincular execução da chave aos dados atuais', key=_key('bind_qualification'), disabled=not ready)
            if bound_now:
                u = replace(u, qualification_signature=signature)
            if st.button('Remover vínculo da execução da chave', key=_key('clear_qualification'), disabled=not bool(u.qualification_signature)):
                u = replace(u, qualification_signature='')
            if detail_is_current(replace(c, single_key_weld=u)):
                st.success('Registro de execução da chave vinculado aos dados atuais.')
            elif stale and not bound_now:
                st.warning('Vínculo anterior invalidado por alteração de dados. Revise e vincule novamente; restaurar valores antigos não restaura o vínculo.')
            else:
                st.warning('Execução ainda não vinculada. Falhas numéricas continuam válidas e visíveis; um resultado numérico favorável permanece condicionado.')
    st.session_state[_draft()] = asdict(u)
    st.session_state[_key('qualification_signature')] = u.qualification_signature
    return replace(c, single_key_weld=u)


def _n(value, scale=1.):
    return number(value / scale, 6) if type(value) in (int, float) and math.isfinite(value) else '—'


def _status(label, value):
    if value == 'pass':
        st.success(label + ': ATENDE no escopo local indicado.')
    elif value == 'fail':
        st.error(label + ': NÃO ATENDE no escopo local indicado.')
    else:
        st.warning(label + ': PENDENTE.')


def single_key_weld_results(c, result):
    if c.shear_path != 'plate' or c.single_key_weld.model == 'off':
        return
    from .single_key_weld_artifacts import _data
    d = _data(c, result)
    with st.expander('Chave de chapa única · resultados dos dois filetes', expanded=True):
        from .single_key_weld_artifacts import image_bytes
        st.image(image_bytes(c, result), width='stretch')
        _status('Componente de metal de solda e detalhamento', d.get('weld_component_status', d.get('status')))
        if d.get('resistance_basis_valid') is False:
            st.warning('qRd e índice são valores nominais condicionais, sem crédito resistente: material ou domínio fora da base qualificada. Falhas numéricas permanecem visíveis.')
        for key, value in d.get('statuses', {}).items():
            _status(STATUS_LABELS.get(key, key.replace('_', ' ')), value)
        for reason in d.get('reasons', []):
            st.warning(str(reason))
        st.write(f'Ação aplicada V={_n(d.get("Vactual_N", c.V), 1000)} kN. Ações prescritas com sinal: Vw={_n(d.get("Vw_N"), 1000)} kN; Mw={_n(d.get("Mw_Nmm"), 1e6)} kN·m. V=0 conserva o envelope positivo.')
        st.caption('Ações de referência transmitidas pela chave à placa. Na chave isolada, ações de ligação opostas. V positivo produz Mw positivo pela convenção escalar do app. Vw e Mw não entram novamente no equilíbrio global nem na solda superior pilar–placa.')
        st.write(f'Perna z={_n(d.get("leg_mm"))} mm; garganta a={_n(d.get("throat_mm"))} mm; Lreal={_n(d.get("Lreal_mm"))} mm; Leff={_n(d.get("Leff_mm"))} mm por filete. Braço ac=tpv+2z/3={_n(d.get("arm_mm"))} mm.')
        st.write(f'qx=Vw/(2Leff)={_n(d.get("qx_Npmm"))} N/mm; qz,+ = +Mw/(ac Leff)={_n(d.get("qz_plus_Npmm"))} N/mm; qz,− = −Mw/(ac Leff)={_n(d.get("qz_minus_Npmm"))} N/mm.')
        st.write(f'q=√(qx²+qz²)={_n(d.get("q_resultant_Npmm"))} N/mm; qRd=0,6fw a/γw2={_n(d.get("q_Rd_Npmm"))} N/mm; índice={_n(d.get("utilization"))}. fw=485 MPa; γw2=1,35.')
        st.caption('Mesmo resultante em ambos os filetes, incluindo a componente normal comprimida. Sem aumento direcional de 1,5 e sem somar duas capacidades de momento. Raízes físicas em ±tpv/2; linhas analíticas do binário em ±ac/2. A junta T não recebe automaticamente o limite de borda livre t−1,5.')
        st.warning(LIMITS)
