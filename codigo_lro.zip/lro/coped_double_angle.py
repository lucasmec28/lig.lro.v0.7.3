"""R017: symmetric bolted angles, equal shallow double cope, girder WEB.

N/mm/MPa. NBR 8800:2024 components plus explicitly qualified Gerdau/AISC
complementary cope model. Member-wide/global design remains external.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict, fields, replace
import math
from .angle_catalog_selection import (native_connection, valid_native_fields, identity_errors,
    missing_data_errors, STRING_FIELDS as CATALOG_STRINGS, BOOL_FIELDS as CATALOG_BOOLS)
from .models import Profile, profiles, STEELS, BOLTS, finite_real
from .double_angle import (HOLES, EDGES, INDUSTRIAL, GAMMA_A1, GAMMA_A2, NBR,
    TOL, bolt_shear_resistance, bearing_resistance, block_resistance,
    shear_resistances, bearing_rows, l_blocks, _safe, _issue, _check)

FAMILY = 'Cantoneiras duplas · R017 · viga recortada'
CONNECTION_TYPE = 'coped_double_angle_r017_bolted_shear'
COMPONENT_VERSION = '0.9.3-angle-dev'
COPE_SOURCE = 'Gerdau2018 p.25; Dowswell & Whyte2014 pp.43–45,48, DOI10.62913/engj.v51i1.1055'
ADOPTED_PRESET_SOURCE = ('Tabela métrica de passos e bordas do detalhe industrial R016, p.19, '
                        'adotada como preset de montagem R017; a folha R017 p.20 não contém essa tabela')
SCOPE = ('R017: duas cantoneiras simétricas parafusadas à alma de viga W com recortes superior e inferior iguais '
         'e à alma íntegra interior de viga W perpendicular. V estático com sinal; N=M=T=0. '
         'Componentes NBR2024 + modelo complementar Gerdau/AISC de instabilidade do recorte, sob condições externas explícitas.')
EXCLUSIONS = [
    'Não dimensiona a viga de apoio completa: esforços globais, seções perfuradas, flexão, torção e estabilidade permanecem no modelo estrutural.',
    'Não dimensiona os travamentos: referências externas devem comprovar resistência e rigidez nos pontos exigidos.',
    'Recortes desiguais, profundos, simples, enrijecidos, outra topologia, fadiga, impacto, atrito de serviço e forças N/M/T exigem modelo próprio.',
    'Aberturas, entalhes, outra ligação sobreposta ou viga oposta no apoio exigem caminhos e demandas combinados próprios.',
]

@dataclass(frozen=True)
class CopedDoubleAngle:
    beam: Profile
    support: Profile
    project: str = 'R017 · duas cantoneiras e recorte duplo'
    kind: str = 'beam_web'
    angle_count: int = 2
    symmetric: bool = True
    beam_leg: float = 76.0
    support_leg: float = 76.0
    t: float = 6.4
    root_radius: float = 8.0
    length: float = 260.0
    angle_top: float = 47.5
    beam_gauge: float = 45.0
    support_gauge: float = 45.0
    web_rows: int = 4
    support_rows: int = 4
    web_columns: int = 1
    support_columns: int = 1
    web_pitch: float = 60.0
    support_pitch: float = 60.0
    web_end_top: float = 40.0
    support_end_top: float = 40.0
    gap: float = 10.0
    c_top: float = 130.0
    c_bottom: float = 130.0
    dc_top: float = 30.0
    dc_bottom: float = 30.0
    r_top: float = 15.0
    r_bottom: float = 15.0
    beam_level: float = 0.0
    support_eccentricity: float = 0.0
    support_intact: bool = True
    support_back_access: bool = True
    restraint_top_system: str = ''
    restraint_top_ref: str = ''
    restraint_top_x: float = 0.0
    restraint_bottom_system: str = ''
    restraint_bottom_ref: str = ''
    restraint_bottom_x: float = 0.0
    beam_steel: str = 'ASTM A572 Gr.50'
    support_steel: str = 'ASTM A572 Gr.50'
    angle_steel: str = 'ASTM A36'
    bolt: str = 'ASTM F3125 A325'
    db: float = 20.0
    hole_diameter: float = 22.0
    hole_type: str = 'standard_round'
    drilled: bool = False
    web_threads_excluded: bool = False
    support_threads_excluded: bool = False
    exposure: str = 'painted'
    V: float = 100000.0
    N: float = 0.0
    M: float = 0.0
    torsion: float = 0.0
    cope: str = 'equal_double'
    static: bool = True
    normal_combination: bool = True
    no_slip_required: bool = False
    tool_radius: float = 22.0
    fabrication_clearance: float = 3.0
    notes: str = ''
    angle_catalog_id: str = ''
    angle_root_source: str = ''
    angle_root_confirmed: bool = False


    @property
    def fixed_assumptions(self):
        return {'topology':'R017_two_equal_bolted_angles_coped_beam_to_perpendicular_girder_web',
            'web_bolts_shared':True,'web_shear_planes':2,'support_shear_planes':1,
            'support_web_count':1,'support_hole_columns':2,
            'contact':'firm_direct_contact_no_shims_no_participating_welds',
            'assembly':'F3125 bolts, nuts and washers to NBR6.8; no friction or pretension credit',
            'support_continuity':'one_supported_beam_on_intact_interior_rolled_W_web_and_continuous_flanges_no_nearby_openings_or_overlapping_connections',
            'normal_ultimate_combinations_only':True,'load_model':'conventional_flexible_LCPP_V_only',
            'bearing_deformation_is_design_limitation':True,
            'net_hole_policy':'Table14_maximum_plus_2mm_unless_documented_drilled',
            'cope_model':'Gerdau2018_p25_design_resistance_complementary_AISC_older_equal_shallow_model',
            'cope_domain':'equal_lengths_and_depths_c_le_2d_dc_le_0p2d',
            'cope_radius_industrial_mm':15.,
            'connection_lateral_restraint':'conventional_pair_with_vertically_separated_web_bolts; no brace_strength_or_stiffness_design',
            'cope_face_restraint':'external_verified_lateral_translation_restraint_at_compression_flange_face; NOT full_cross_section_twist_fixity',
            'support_force_idealization':'vertical_in_girder_web_plane',
            'support_global_checks':'external_not_covered_by_local_pass',
            'gamma_a1':GAMMA_A1,'gamma_a2':GAMMA_A2}

    def to_dict(self):
        errors=input_errors(self)
        if errors:raise ValueError('; '.join(errors))
        return {'schema_version':1,'connection_type':CONNECTION_TYPE,'component_version':COMPONENT_VERSION,
            'connection':native_connection(self),'units':{'force':'N','length':'mm','stress':'MPa','moment':'N mm'},
            'fixed_assumptions':self.fixed_assumptions}

    @classmethod
    def from_dict(cls,data):
        keys={'schema_version','connection_type','component_version','connection','units','fixed_assumptions'}
        if not isinstance(data,dict) or set(data)!=keys:raise ValueError('Projeto R017: campos ausentes ou desconhecidos.')
        if type(data['schema_version']) is not int or data['schema_version']!=1 or data['connection_type']!=CONNECTION_TYPE or data['component_version']!=COMPONENT_VERSION:
            raise ValueError('Família ou versão R017 incompatível.')
        raw=data['connection']
        if not valid_native_fields(raw, cls):raise ValueError('Dados R017 incompletos ou desconhecidos.')
        raw=dict(raw)
        for key in ('beam','support'):
            p=raw[key]
            if not isinstance(p,dict) or set(p)!={f.name for f in fields(Profile)}:raise ValueError(key+': perfil inválido ou incompleto.')
            raw[key]=Profile(**p)
        c=cls(**raw);canonical=c.to_dict()
        for key in ('units','fixed_assumptions'):
            if data[key]!=canonical[key]:raise ValueError(key+': premissas/unidades incompatíveis; sem conversão silenciosa.')
        return c


def presets():
    p=profiles();base=CopedDoubleAngle(p['W 360 x 51,0'],p['W 360 x 51,0'])
    return {'R017 · W360/W360 · M20 · conferir travamento':base,
        'R017 · cortante invertido · conferir travamento':replace(base,project='R017 · V invertido',V=-100000.),
        'R017 · solicitação elevada':replace(base,project='R017 · solicitação elevada',V=500000.),
        'R017 · alternativa c200 · conferir travamento':replace(base,project='R017 · recorte longo dentro do domínio geométrico',c_top=200.,c_bottom=200.)}


def input_errors(c):
    if not isinstance(c,CopedDoubleAngle):return ['A entrada deve ser CopedDoubleAngle.']
    errors=[]
    strings={'project','kind','beam_steel','support_steel','angle_steel','bolt','hole_type','exposure','cope','notes',
        'restraint_top_system','restraint_top_ref','restraint_bottom_system','restraint_bottom_ref'}
    bools={'symmetric','drilled','web_threads_excluded','support_threads_excluded','static','normal_combination','no_slip_required','support_intact','support_back_access'}
    ints={'angle_count','web_rows','support_rows','web_columns','support_columns'}
    nonnegative={'root_radius','angle_top','gap','fabrication_clearance','restraint_top_x','restraint_bottom_x'}
    signed={'V','N','M','torsion','beam_level','support_eccentricity'}
    for f in fields(c):
        name=f.name;v=getattr(c,name)
        if name in ('beam','support'):
            if not isinstance(v,Profile):errors.append(name+': perfil documentado obrigatório.');continue
            for key in ('d','bf','tw','tf','clear','area','mass'):
                if not finite_real(getattr(v,key)) or getattr(v,key)<=0:errors.append(f'{name}.{key}: positivo finito obrigatório.')
            for key in ('name','family','source'):
                if not isinstance(getattr(v,key),str):errors.append(f'{name}.{key}: texto obrigatório.')
        elif name in strings | CATALOG_STRINGS:
            if not isinstance(v,str):errors.append(name+': texto obrigatório.')
        elif name in bools | CATALOG_BOOLS:
            if type(v) is not bool:errors.append(name+': booleano explícito obrigatório.')
        elif name in ints:
            if type(v) is not int or not 1<=v<=20:errors.append(name+': inteiro entre1 e20 obrigatório.')
        elif not finite_real(v):errors.append(name+': número finito obrigatório.')
        elif name in nonnegative:
            if v<0:errors.append(name+': valor não negativo obrigatório.')
        elif name not in signed and v<=0:errors.append(name+': dimensão positiva obrigatória.')
    return errors + (identity_errors(c, 1) if not errors else [])


def cope_boundary(c,x,side='top'):
    """Actual free edge y from beam top at x from SUPPORT FACE; None beyond cope face.

    Top circle centre=(gap+c_top-r_top,dc_top-r_top); mirror for bottom.
    At the vertical end of the cope return its corner tangency, not an invented
    continuation of a free horizontal edge into the intact rolled member.
    """
    if side not in ('top','bottom'):raise ValueError('side must be top or bottom')
    length=getattr(c,'c_'+side);depth=getattr(c,'dc_'+side);r=getattr(c,'r_'+side)
    face=c.gap+length
    if x>face:return None
    y=depth if x<=face-r else depth-r+math.sqrt(max(0.,r*r-(x-(face-r))**2))
    return y if side=='top' else c.beam.d-y


def cope_edge_distance(c,x,y,side='top'):
    """Exact closest distance from point to horizontal, R arc and vertical cut.

    The hole-circle clearance equals this distance minus dh/2. Independent of
    directional bearing ligament, which is measured along the load direction.
    """
    if side not in ('top','bottom'):raise ValueError('side must be top or bottom')
    if side=='bottom':y=c.beam.d-y
    face=c.gap+getattr(c,'c_'+side);d=getattr(c,'dc_'+side);r=getattr(c,'r_'+side)
    cx,cy=face-r,d-r
    hx=min(max(x,c.gap),cx);horizontal=math.hypot(x-hx,y-d)
    vy=min(max(y,0.),cy);vertical=math.hypot(x-face,y-vy)
    theta=min(math.pi/2,max(0.,math.atan2(y-cy,x-cx)))
    arc=math.hypot(x-(cx+r*math.cos(theta)),y-(cy+r*math.sin(theta)))
    return min(horizontal,vertical,arc)


def cope_model(d,tw,dc,c,gap,fy):
    """Equal-cope source formula, with resistance convention and real domain.

    This is a component formula probe; no brace design or whole-joint approval.
    """
    if not all(finite_real(v) for v in (d,tw,dc,c,gap,fy)) or min(d,tw,dc,c,fy)<=0 or gap<0 or 2*dc>=d:
        raise ValueError('Geometria/material inválidos no modelo de recorte duplo.')
    h=d-2*dc;W=tw*h*h/6;e=c+gap;fd=3.5-7.5*dc/d
    domain={'c_le_2d':c<=2*d*(1+TOL),'dc_le_0p2d':dc<=.2*d*(1+TOL)}
    within=all(domain.values())
    Fbc=350600.*tw*tw/(c*h)*fd if within else None
    return dict(h0_mm=h,W1_mm3=W,e_mm=e,fd=fd,domain=domain,geometry_within_domain=within,
        Fbc_design_MPa=Fbc,first_yield_N=fy*W/(GAMMA_A1*e),stability_N=Fbc*W/e if within else None,
        coefficient_MPa=350600.,printed_coefficient_kN_cm2=35060.,
        resistance_convention='Fbc já é tensão de cálculo Gerdau: não dividir novamente por gamma; primeiro escoamento separado.',
        restraint_qualified=False,source=COPE_SOURCE)


def support_boundary_actions(V,V_left,V_right,x_left,M_left,x_columns):
    """Optional EQUILIBRIUM ONLY, not a supporting-member capacity check.

    Axes x along girder, downward reaction positive. Q jumps by -V/2 at each
    column, dM/dx=Q. Boundary forces are actual (never 45 kN sizing floor).
    """
    numbers=(V,V_left,V_right,x_left,M_left,*x_columns)
    if len(x_columns)!=2 or not all(finite_real(x) for x in numbers):raise ValueError('Ações/posições finitas e duas colunas requeridas.')
    x1,x2=sorted(x_columns)
    if x_left>x1:raise ValueError('Referência esquerda deve preceder ambas as colunas.')
    residual=V_left-V_right-V
    qmid=V_left-V/2
    return {'equilibrium_only':True,'capacity_checks_performed':False,'V_left_N':V_left,
        'V_between_columns_N':qmid,'V_right_N':V_right,'reaction_actual_N':V,
        'shear_jump_residual_N':residual,'equilibrium_closes':abs(residual)<=1e-8*max(1.,abs(V),abs(V_left),abs(V_right)),
        'columns':[{'x_mm':x1,'introduced_force_N':V/2,'M_Nmm':M_left+V_left*(x1-x_left)},
                   {'x_mm':x2,'introduced_force_N':V/2,'M_Nmm':M_left+V_left*(x1-x_left)+qmid*(x2-x1)}],
        'note':'Valores de contorno externos. A partilha local V/2 entre cantoneiras não define reações globais iguais.'}


def geometry(c,out):
    dh=c.hole_diameter;d14=HOLES.get(c.db,dh);dn=d14+(0. if c.drilled else 2.)
    web_bottom=c.length-c.web_end_top-(c.web_rows-1)*c.web_pitch
    sup_bottom=c.length-c.support_end_top-(c.support_rows-1)*c.support_pitch
    sx=c.beam.tw/2+c.support_gauge;root=(c.beam.d-c.beam.clear)/2;sroot=(c.support.d-c.support.clear)/2
    web_y=[c.angle_top+c.web_end_top+i*c.web_pitch for i in range(c.web_rows)]
    support_y=[c.beam_level+c.angle_top+c.support_end_top+i*c.support_pitch for i in range(c.support_rows)]
    top=cope_boundary(c,c.beam_gauge,'top');bottom=cope_boundary(c,c.beam_gauge,'bottom')
    straight=(c.beam_gauge+dh/2<=min(c.gap+c.c_top-c.r_top,c.gap+c.c_bottom-c.r_bottom)+TOL)
    g=dict(valid=False,dh=dh,dn=dn,table14_max_hole_mm=d14,physical_hole_diameter_mm=dh,net_deduction_diameter_mm=dn,
        web_end_bottom_mm=web_bottom,support_end_bottom_mm=sup_bottom,
        web_hole_y_mm=web_y,web_hole_x_mm=c.beam_gauge,support_hole_y_mm=support_y,
        support_hole_x_mm=[-sx,sx],
        support_hole_coordinate_frame={'x':'along girder span, zero at supported-beam web plane',
            'y':'positive DOWN from supporting-girder top surface',
            'z':'normal to girder web, zero at girder-web mid-plane',
            'note':'Hole geometry frame; convert y_up=d_support/2-y_down before using girder action coordinates.'},
        support_hole_coordinates_mm=[{'column':side,'x':x,'y':y,'z':0.} for side,x in [('negative',-sx),('positive',sx)] for y in support_y],
        web_free_toe_edge_mm=c.beam_leg-c.beam_gauge,support_free_toe_edge_mm=c.support_leg-c.support_gauge,
        beam_end_distance_mm=c.beam_gauge-c.gap,beam_root_envelope_mm=root,support_root_envelope_mm=sroot,
        supported_reduced_height_mm=c.beam.d-c.dc_top-c.dc_bottom,
        cope_top_boundary_at_bolts_mm=top,cope_bottom_boundary_at_bolts_mm=bottom,
        cope_top_loaded_edge_mm=None if top is None else web_y[0]-top,
        cope_bottom_loaded_edge_mm=None if bottom is None else bottom-web_y[-1],
        bolt_column_within_straight_cope=straight,cope_face_top_x_mm=c.gap+c.c_top,cope_face_bottom_x_mm=c.gap+c.c_bottom,
        top_corner_center_mm=[c.gap+c.c_top-c.r_top,c.dc_top-c.r_top],
        bottom_corner_center_mm=[c.gap+c.c_bottom-c.r_bottom,c.beam.d-c.dc_bottom+c.r_bottom],
        support_flange_projection_mm=(c.support.bf-c.support.tw)/2,
        angle_beam_clear_top_mm=c.angle_top-c.dc_top,angle_beam_clear_bottom_mm=c.beam.d-c.dc_bottom-c.angle_top-c.length,
        angle_support_clear_top_mm=c.beam_level+c.angle_top-sroot,
        angle_support_clear_bottom_mm=c.support.d-sroot-c.beam_level-c.angle_top-c.length,
        web_grip_mm=c.beam.tw+2*c.t,support_grip_mm=c.support.tw+c.t,
        physical_angle_count=c.angle_count,shared_web_bolt_count=c.web_rows*c.web_columns,
        each_support_leg_bolt_count=c.support_rows*c.support_columns,support_web_hole_count=2*c.support_rows,
        total_bolt_count=c.web_rows*c.web_columns+c.angle_count*c.support_rows*c.support_columns,
        industrial_N_intervals=c.web_rows-1,checks=[],errors=[],detailing_checks=[],table16_exceptions={})
    out['geometry']=g
    def scalar(key,value,limit,relation,category,text,reference='Geometria física R017'):
        passed=(value>limit if relation=='>' else value>=limit-TOL if relation=='>=' else value<=limit+TOL)
        row=dict(id=key,actual=value,limit=limit,relation=relation,category=category,passed=passed,units='mm',reference=reference)
        if category == 'detail' and 'tabela16' in reference and not passed:
            row['nominal_passed'] = False
            row['qualification'] = 'TABLE16_EXCEPTION_NOT_VERIFIED'
            g['table16_exceptions'][key] = {
                'qualified': False, 'actual_edge_mm': value, 'table16_minimum_mm': limit,
                'reason': ('Contato vertical e blocos à ponta real ainda não verificados.' if key == 'beam_end_min' else
                           'Qualificação da exceção para esta borda não implementada; permanece o requisito de detalhamento.'),
                'reference': NBR + ', nota da Tabela 16 e 6.3.3.3',
            }
        g['checks'].append(row)
        if category=='detail':g['detailing_checks'].append(row)
        if not passed:
            if category=='geometry':g['errors'].append(key)
            exception_note = (' ' + g['table16_exceptions'][key]['reason']
                              if key in g['table16_exceptions'] and key != 'beam_end_min' else '')
            _issue(out,{'geometry':'invalid_geometry','detail':'detail_fail','preset':'preset_deviation','access':'access_pending','model':'engineering_pending'}[category],
                f'{text}: {value:g} mm; requerido {relation} {limit:g} mm.' + exception_note,reference,field=key)
    for name,p in [('beam',c.beam),('support',c.support)]:
        scalar(name+'_web_height',p.d-2*p.tf,0.,'>','geometry',name+': alma entre mesas')
        scalar(name+'_root_clear',p.clear,p.d-2*p.tf,'<=','geometry',name+': altura livre de raízes')
        scalar(name+'_flange_width',p.bf,p.tw,'>','geometry',name+': mesa maior que espessura da alma')
    for side in ('top','bottom'):
        depth=getattr(c,'dc_'+side);radius=getattr(c,'r_'+side);length=getattr(c,'c_'+side)
        scalar('cope_'+side+'_depth',depth,root,'>=','model','Recorte deve remover a mesa e raiz para o trecho retangular de alma')
        scalar('cope_'+side+'_radius_depth',depth-radius,0.,'>=','geometry','Arco contido na profundidade do recorte')
        scalar('cope_'+side+'_radius_length',length-radius,0.,'>=','geometry','Arco contido no comprimento do recorte')
        scalar('cope_'+side+'_radius_min',radius,12.,'>=','detail','Raio mínimo aproximado recomendado','Gerdau2018 p.19')
        if not math.isclose(radius,15.):_issue(out,'preset_deviation',f'Raio {side}={radius:g} mm difere do R15 do detalhe industrial; dimensão real preservada.','R017 p.20, dois líderes R15')
    scalar('reduced_web_height',g['supported_reduced_height_mm'],0.,'>','geometry','Altura restante entre recortes')
    scalar('reduced_web_net',g['supported_reduced_height_mm']-c.web_rows*dn,0.,'>','geometry','Área líquida do trecho reto')
    for key in ('angle_beam_clear_top_mm','angle_beam_clear_bottom_mm','angle_support_clear_top_mm','angle_support_clear_bottom_mm'):
        scalar(key,g[key],0.,'>=','geometry','Cantoneira dentro da alma disponível')
        scalar(key+'_fabrication',g[key],c.fabrication_clearance,'>=','access','Folga de montagem da cantoneira')
    for side in ('top','bottom'):
        # Rectangular flange-root envelope is deliberately conservative; actual
        # interference with FLANGE is a physical failure, root fit a pending detail.
        x=g['support_flange_projection_mm']
        y=cope_boundary(c,x,side)
        boundary=(0. if side=='top' else c.beam.d) if y is None else y
        clearance=(c.beam_level+boundary-c.support.tf if side=='top' else c.support.d-c.support.tf-c.beam_level-boundary)
        scalar('cope_'+side+'_flange_clearance',clearance,0.,'>=','geometry','Recorte não invade a mesa real do apoio')
        # Assembly margin is not physical steel. Extending the envelope may
        # reach the intact flange even when the actual steel does not collide.
        assembly_y=cope_boundary(c,x+c.fabrication_clearance,side)
        assembly_boundary=(0. if side=='top' else c.beam.d) if assembly_y is None else assembly_y
        assembly_clearance=(c.beam_level+assembly_boundary-c.support.tf if side=='top' else c.support.d-c.support.tf-c.beam_level-assembly_boundary)
        scalar('cope_'+side+'_assembly_flange_clearance',assembly_clearance,c.fabrication_clearance,'>=','access','Folga de montagem no envelope ampliado da mesa do apoio')
        rootclear=assembly_clearance-(sroot-c.support.tf)
        scalar('cope_'+side+'_root_envelope_clearance',rootclear,c.fabrication_clearance,'>=','access','Recorte libera envelope conservador da raiz do apoio')
    scalar('conventional_connection_depth',c.length,c.beam.d/2,'>=','model','Altura convencional para restrição lateral distribuída na ligação','Gerdau2018 p.20; NBR6.1.7')
    scalar('conventional_upper_location',web_y[0],c.beam.d-web_y[-1],'<=','model','Grupo centralizado ou próximo ao topo no domínio convencional','Gerdau2018 p.20')
    for name,b in [('beam',c.beam_leg),('support',c.support_leg)]:
        scalar(name+'_angle_leg',b-c.t-c.root_radius,0.,'>','geometry',name+': aba reta')
    for name,gauge in [('web',c.beam_gauge),('support',c.support_gauge)]:
        scalar(name+'_hole_root',gauge-c.t-c.root_radius-dh/2,0.,'>=','geometry',name+': furo fora da raiz da cantoneira')
        scalar(name+'_tool_root',gauge-c.t-c.root_radius,c.tool_radius+c.fabrication_clearance,'>=','access',name+': acesso junto à raiz da cantoneira')
    for position,y in [('top',support_y[0]),('bottom',support_y[-1])]:
        clear=y-sroot if position=='top' else c.support.d-sroot-y
        scalar('support_'+position+'_hole_fit',clear-dh/2,0.,'>=','geometry','Furo na alma reta do apoio')
        scalar('support_'+position+'_back_tool',clear,c.tool_radius+c.fabrication_clearance,'>=','access','Ferramenta no verso da alma do apoio')
    for i,y in enumerate(web_y):
        for side in ('top','bottom'):
            dist=cope_edge_distance(c,c.beam_gauge,y,side)
            scalar(f'web_hole{i+1}_{side}_physical',dist-dh/2,0.,'>','geometry','Furo integral fora do recorte real, incluindo arco')
            scalar(f'web_hole{i+1}_{side}_net',dist-dn/2,0.,'>','geometry','Ligamento líquido ao recorte real')
        if top is not None:scalar(f'web_hole{i+1}_inside_top',y-top-dh/2,0.,'>','geometry','Furo abaixo do contorno superior')
        if bottom is not None:scalar(f'web_hole{i+1}_inside_bottom',bottom-y-dh/2,0.,'>','geometry','Furo acima do contorno inferior')
    if not straight:_issue(out,'engineering_pending','Linha de furos alcança a concordância ou ultrapassa a face do recorte. Contorno real e integridade dos furos são calculados; contato/blocos curvos não usam automaticamente o caminho reto. Falta qualificar o caminho resistente específico.',COPE_SOURCE,field='rounded_cope_bolt_path')
    emin=EDGES.get(c.db,0.);pmin=max(2.7*c.db,dh+c.db)
    for family,n,pitch,topedge,bottomedge,tmin in [('web',c.web_rows,c.web_pitch,c.web_end_top,web_bottom,min(c.t,c.beam.tw)),('support',c.support_rows,c.support_pitch,c.support_end_top,sup_bottom,min(c.t,c.support.tw))]:
        if n>1:
            scalar(family+'_pitch_physical',pitch-dh,0.,'>','geometry','Furos distintos')
            scalar(family+'_pitch_min',pitch,pmin,'>=','detail','Passo mínimo',NBR+', 6.3.9')
            scalar(family+'_pitch_max',pitch,min(14*tmin,180.) if c.exposure=='weathering' else min(24*tmin,300.),'<=','detail','Passo máximo',NBR+', 6.3.10')
            if pitch<3*c.db:_issue(out,'warning',family+': passo abaixo da preferência3db.',NBR+', 6.3.9')
        for end,e in [('top',topedge),('bottom',bottomedge)]:
            scalar(family+'_end_'+end,e-dn/2,0.,'>','geometry','Ligamento líquido da extremidade da cantoneira')
            scalar(family+'_edge_'+end+'_min',e,emin,'>=','detail','Borda mínima da cantoneira',NBR+', tabela16')
            scalar(family+'_edge_'+end+'_max',e,min(12*c.t,150.),'<=','detail','Borda máxima da cantoneira',NBR+', 6.3.12')
        scalar(family+'_net_shear_length',c.length-n*dn,0.,'>','geometry','Seção líquida da aba')
        for k in range(1,n+1):scalar(family+f'_net_prefix{k}',min(topedge,bottomedge)+(k-1)*pitch-(k-.5)*dn,0.,'>','geometry','Ligamento de bloco da cantoneira')
    edges=[('angle_web_toe',g['web_free_toe_edge_mm'],c.t),('angle_support_toe',g['support_free_toe_edge_mm'],c.t),('beam_end',g['beam_end_distance_mm'],c.beam.tw)]
    if straight:edges += [('beam_cope_top',g['cope_top_loaded_edge_mm'],c.beam.tw),('beam_cope_bottom',g['cope_bottom_loaded_edge_mm'],c.beam.tw)]
    for name,e,t in edges:
        scalar(name+'_net',e-dn/2,0.,'>','geometry','Ligamento líquido até borda livre real')
        scalar(name+'_min',e,emin,'>=','detail','Borda mínima real',NBR+', tabela16')
        scalar(name+'_max',e,min(12*t,150.),'<=','detail','Borda máxima real',NBR+', 6.3.12')
    if straight:
        for k in range(1,c.web_rows+1):scalar(f'beam_cope_net_prefix{k}',min(g['cope_top_loaded_edge_mm'],g['cope_bottom_loaded_edge_mm'])+(k-1)*c.web_pitch-(k-.5)*dn,0.,'>','geometry','Ligamento de bloco da alma recortada')
    scalar('support_columns_min',2*sx,pmin,'>=','detail','Passo entre colunas na única alma do apoio',NBR+', 6.3.9')
    if c.tool_radius<c.db/2:_issue(out,'access_pending','Raio da ferramenta menor que raio do parafuso; conferir cabeça, porca e arruela.','Montagem')
    if not c.support_back_access:_issue(out,'access_pending','Acesso ao verso da alma do apoio não confirmado; montagem dos parafusos não está resolvida.','R017: montagem')
    if c.db in INDUSTRIAL:
        e,p=INDUSTRIAL[c.db]
        if not all(math.isclose(a,b) for a,b in [(c.web_pitch,p),(c.support_pitch,p),(c.web_end_top,e),(web_bottom,e),(c.support_end_top,e),(sup_bottom,e)]):
            _issue(out,'preset_deviation','Passos/bordas diferem do preset métrico adotado de R016; a geometria real continua no cálculo.',ADOPTED_PRESET_SOURCE)
    else:_issue(out,'preset_deviation','Diâmetro fora do preset métrico adotado de R016; sistema e dimensão reais preservados.',ADOPTED_PRESET_SOURCE + '; NBR tabelas 14/16')
    if c.c_top>170 or c.c_bottom>170:_issue(out,'preset_deviation','Comprimento de recorte excede a cobertura de estudo/tabulação Gerdau170mm, não o domínio analítico. O critério analítico é c≤2d e dc≤0,2d, com travamento qualificado.',COPE_SOURCE)
    g['valid']=not g['errors'];return g


def _qualify_table16_beam_end(c, out, directions):
    """Qualify only the existing straight-cope beam-end path, without a new model.

    The short horizontal edge belongs to the real block tension leg. Bearing
    remains vertical along the force; it never uses that horizontal distance.
    Every existing per-hole, normative sum and loaded-prefix check must pass in
    each direction actually checked, including both floor cases when V is zero.
    Other edge exceptions are deliberately not generalized by this function.
    """
    g = out['geometry']
    record = g['table16_exceptions'].get('beam_end_min')
    if record is None:
        return
    rows = {row['id']: row for row in out['checks']}
    expected = []
    paths = []
    for sign in directions:
        prefix = 'beam_web_Vpos' if sign > 0 else 'beam_web_Vneg'
        bearing_ids = [prefix + f'_bearing_hole{i}' for i in range(1, c.web_rows + 1)]
        bearing_ids.append(prefix + '_bearing_group')
        block_ids = [prefix + f'_block_k{i}' for i in range(1, c.web_rows + 1)]
        expected.extend(bearing_ids + block_ids)
        paths.append({'direction': 'up' if sign > 0 else 'down',
                      'case': 'Vpos' if sign > 0 else 'Vneg',
                      'bearing_check_ids': bearing_ids, 'block_check_ids': block_ids})
    missing = [key for key in expected if key not in rows]
    prerequisites = g['valid'] and g['bolt_column_within_straight_cope'] and not missing
    existing = [rows[key] for key in expected if key in rows]
    failed = [row['id'] for row in existing if row['status'] != 'PASS']
    blocks = [row for row in existing if '_block_' in row['id']]
    actual_boundaries = all(row.get('free_boundary') in
                            ('actual_cope_top_and_beam_end', 'actual_cope_bottom_and_beam_end')
                            for row in blocks)
    qualified = bool(prerequisites and actual_boundaries and not failed)
    governing = max(existing, key=lambda row: row['utilization']) if existing else None
    for path in paths:
        for mechanism in ('bearing', 'block'):
            children = [rows[key] for key in path[mechanism + '_check_ids'] if key in rows]
            path[mechanism + '_checks'] = [dict(row) for row in children]
            path[mechanism + '_governing'] = (dict(max(children, key=lambda row: row['utilization']))
                                               if children else None)
    record.update({
        'qualified': qualified,
        'qualification': 'TABLE16_EXCEPTION_VERIFIED' if qualified else 'TABLE16_EXCEPTION_NOT_VERIFIED',
        'physical_hole_diameter_mm': g['dh'], 'net_hole_deduction_mm': g['dn'],
        'horizontal_beam_end_distance_mm': g['beam_end_distance_mm'],
        'horizontal_net_tension_length_mm': g['beam_end_distance_mm'] - g['dn'] / 2,
        'web_thickness_mm': c.beam.tw,
        'bearing_direction_basis': 'Ligamentos verticais no sentido da força; a borda horizontal não é lc de contato.',
        'block_path_basis': 'Blocos L existentes, do recorte carregado à ponta horizontal real da viga.',
        'paths': paths, 'missing_check_ids': missing, 'failed_check_ids': failed,
        'governing': dict(governing) if governing else None,
        'governing_check_ids': ([row['id'] for row in existing if row['utilization'] == governing['utilization']]
                                if governing else []),
        'reference': NBR + ', nota da Tabela 16, 6.3.3.3 e 6.5.6 / Figura 16(b)',
    })
    if qualified:
        record['reason'] = 'Exceção da nota da Tabela 16 verificada pelos contatos e blocos existentes, em todos os sentidos aplicáveis.'
        out['issues'] = [issue for issue in out['issues']
                         if not (issue.get('field') == 'beam_end_min' and issue['severity'] == 'detail_fail')]
        _issue(out, 'info',
               f'Ponta real da viga {g["beam_end_distance_mm"]:g} mm, abaixo dos {record["table16_minimum_mm"]:g} mm tabulados: '
               f'exceção da nota da Tabela 16 verificada. Governante dos pré-requisitos: {governing["id"]}, '
               f'Sd={governing["demand_N"]:g} N, Rd={governing["design_capacity_N"]:g} N. '
               'Contato usa ligamentos verticais e os blocos usam a borda horizontal real; dimensões preservadas.',
               record['reference'], field='beam_end_min')
    else:
        record['reason'] = ('Caminho de contato/bloco correspondente não implementado para esta geometria.'
                            if not prerequisites or not actual_boundaries else
                            'Contato ou bloco existente não atende; a exceção da Tabela 16 não se qualifica.')
        for issue in out['issues']:
            if issue.get('field') == 'beam_end_min' and issue['severity'] == 'detail_fail':
                issue['text'] += ' ' + record['reason']
    for row in g['checks']:
        if row['id'] == 'beam_end_min':
            row.update(passed=qualified, qualification=record['qualification'],
                       qualification_note=record['reason'], reference=record['reference'])


def _restraints(c,out,directions):
    required=['top' if s>0 else 'bottom' for s in directions]
    result={'connection':{'model':'conventional_two_angles_vertically_separated_bolts_to_intact_stable_girder_web',
        'reference':'NBR6.1.7; Gerdau2018 p.20; Dowswell & Whyte2014 Fig.1',
        'strength_stiffness_design_performed':False,
        'scope':'Restrição fora do plano distribuída na altura da ligação; não comprova travamento na face do recorte.'},
        'required_compression_faces':required,'faces':{},'all_required_qualified':True,
        'twist_fixity_assumed':False,'external_boundary_condition_only':True}
    for side in ('top','bottom'):
        system=getattr(c,'restraint_'+side+'_system').strip();ref=getattr(c,'restraint_'+side+'_ref').strip();x=getattr(c,'restraint_'+side+'_x')
        face=c.gap+getattr(c,'c_'+side);needed=side in required
        qualified=bool(system and ref and math.isclose(x,face,rel_tol=0.,abs_tol=1e-6))
        result['faces'][side]=dict(required=needed,system=system,independent_design_reference=ref,
            declared_x_from_support_face_mm=x,required_x_from_support_face_mm=face,
            qualified_external_boundary=qualified,
            meaning='Referência declara verificação externa de resistência e rigidez da restrição lateral da mesa comprimida na face do recorte; o app não dimensiona o travamento.')
        if needed and not qualified:
            result['all_required_qualified']=False
            _issue(out,'engineering_pending',f'Travamento lateral da mesa comprimida {side} na face x={face:g} mm não qualificado: informar sistema físico, referência independente de resistência/rigidez e localização exata. As cantoneiras não comprovam esse travamento. Valores do modelo do recorte são condicionais.',COPE_SOURCE,field='restraint_'+side)
    out['restraints']=result;return result


def _evaluate(c):
    out={'status':'INVALID_INPUT','local_pass':False,'global_pass':False,
        'member_global_status':'EXTERNAL_NOT_EVALUATED','issues':[],'checks':[],'geometry':{},'load_model':{},
        'summary':{},'components':{},'physical_angles':[],'cope':{},'support_web':{},'restraints':{},
        'scope':SCOPE,'exclusions':EXCLUSIONS.copy(),'not_applicable':[],
        'inputs':_safe(asdict(c)) if isinstance(c,CopedDoubleAngle) else _safe(c),
        'units':{'force':'N','length':'mm','area':'mm²','stress':'MPa','moment':'N mm'}}
    errors=input_errors(c)
    if not errors:
        errors = missing_data_errors(c)
    if errors:
        for text in errors:_issue(out,'invalid_input',text)
        return out
    for bad,text in [
        (c.beam.family!='W' or c.support.family!='W','Viga e apoio devem ser perfis W laminados no domínio convencional.'),
        (c.kind!='beam_web','R017 exige alma de viga perpendicular; mesa de pilar é R016.'),
        (c.angle_count!=2 or not c.symmetric,'Somente duas cantoneiras iguais e simétricas; não se dimensiona cantoneira única pela metade do par.'),
        (c.web_columns!=1 or c.support_columns!=1,'Múltiplas colunas por aba exigem outro modelo de grupos excêntricos.'),
        (any(x!=0 for x in (c.N,c.M,c.torsion)),'N, M ou torção não nulos: modelo V-only não se aplica e não descarta essas ações.'),
        (c.cope!='equal_double','Esta rota requer recortes superior e inferior; recorte simples tem outra equação.'),
        (not c.static,'Inversão estática de V não é verificação de fadiga, impacto ou carregamento cíclico.'),
        (not c.normal_combination,'Somente combinações últimas normais.'),
        (c.no_slip_required,'Exigência de deslizamento requer verificação por atrito própria.'),
        (c.hole_type!='standard_round','Apenas furos circulares padrão nesta rota.'),
        (c.db not in HOLES,'Diâmetro sem linha de furação/detalhamento implementada.'),
        (c.bolt not in ('ASTM F3125 A325','ASTM F3125 A490'),'Classe de parafuso não implementada.'),
        (c.exposure not in ('painted','weathering'),'Exposição sem critério de espaçamento implementado.'),
        (c.web_rows<2 or c.support_rows<2,'Pelo menos dois parafusos por interface no domínio convencional.'),
        (not c.support_intact,'Apoio com aberturas, entalhes, descontinuidades ou outra ligação sobreposta: falta modelo dos caminhos físicos e demandas combinadas.')]:
        if bad:_issue(out,'unsupported_scope',text,'Domínio R017 convencional')
    if c.db in HOLES and not c.db<c.hole_diameter<=HOLES[c.db]:_issue(out,'unsupported_scope',f'Furo físico deve satisfazer db<dh≤{HOLES[c.db]:g} mm.',NBR+', tabela14')
    for name,steel_name,thicknesses in [('beam',c.beam_steel,[c.beam.tw,c.beam.tf]),('support',c.support_steel,[c.support.tw,c.support.tf]),('angle',c.angle_steel,[c.t])]:
        steel=STEELS.get(steel_name)
        if steel is None or not steel.rolled_allowed or any(not steel.profile_min<=t<=steel.profile_max for t in thicknesses):
            _issue(out,'unsupported_scope',name+': aço/perfil/espessura fora do cadastro válido.',NBR+', tabelaA.2')
    standard=any(all(math.isclose(a,b,rel_tol=0,abs_tol=1e-8) for a,b in zip(
        (c.beam_leg,c.support_leg,c.t,c.beam_gauge,c.support_gauge),case)) for case in ((76.,76.,6.4,45.,45.),(102.,102.,8.,65.,65.)))
    if not standard:_issue(out,'engineering_pending','Gabarito alternativo: permanecem os componentes calculáveis, mas falta qualificação de flexão/compatibilidade das abas e grupos. Referências convencionais L76×76×6,4 g45 e L102×102×8 g65; não é uma impossibilidade física nem limite normativo universal.','Gerdau2018 pp.14,21,23–25; Higgins2005 cap.4')
    if c.gap==0.:_issue(out,'engineering_pending','Folga de ponta zero: possível contato com o apoio altera rotação e forças; esse contato não está modelado.',NBR+', 6.1.1.3 e6.1.3')
    if c.support_eccentricity!=0.:
        _issue(out,'engineering_pending','Excentricidade fora do plano da alma foi retida no transporte T=V ez; transferência local desse torque não está dimensionada pela rota no plano.',NBR+', 6.1.1.3 e5.5.2.3')
    g=geometry(c,out)
    if not g['valid']:
        out['status']='INVALID_GEOMETRY';return out
    if any(i['severity']=='unsupported_scope' for i in out['issues']):
        out['status']='OUTSIDE_R017_SCOPE';return out
    directions=[1,-1] if c.V==0 else [1 if c.V>0 else -1];Vabs=max(abs(c.V),45000.)
    out['load_model']={'Vsd_N':c.V,'Vd_N':(1 if c.V>=0 else -1)*Vabs,'assembly_minimum_N':45000.,
        'directions_evaluated':directions,'each_angle_force_N':Vabs/2,'web_group_force_N':Vabs,'each_support_group_force_N':Vabs/2,
        'external_actions':{'V':c.V,'N':c.N,'M':c.M,'torsion':c.torsion},
        'minimum_note':'Piso de45kN uma única vez no conjunto. A reação física enviada ao apoio continua Vsd, sem carga artificial adicional.',
        'geometric_beam_gauge_mm':c.beam_gauge,'geometric_support_gauge_mm':c.support_gauge,
        'eccentricity_model':'Modelo flexível LCPP convencional documentado; excentricidade não desaparece por N=M=T=0.',
        'serial_interfaces':'Alma recortada → duas cantoneiras → uma alma de apoio; resistências em série não se somam.',
        'girder_axes':'x longitudinal, y vertical para cima, z normal à alma; F=(0,-V,0)',
        'girder_action_origin':'x=0 no plano da alma da viga apoiada; y=0 à meia altura do apoio; z=0 no plano médio da alma do apoio',
        'girder_delivered_vertical_force_N':c.V,
        'girder_application_point_mm':[0.,c.support.d/2-(c.beam_level+c.angle_top+c.support_end_top+(c.support_rows-1)*c.support_pitch/2),c.support_eccentricity],
        'girder_delivered_torsion_Nmm':c.V*c.support_eccentricity,
        'girder_force_columns':[{'x_mm':x,'force_actual_N':c.V/2,'force_adopted_local_N':Vabs/2} for x in g['support_hole_x_mm']],
        'global_span_reactions':None,
        'transport_note':'Mx=V ez por r×F; ez=0 no modelo convencional na alma. Não usar d_apoio/2 como braço de torção. Colunas introduzem V/2, não impõem partilha global dos vãos.'}
    restraints=_restraints(c,out,directions)
    if abs(c.V)<45000.:_issue(out,'info','Conferência mínima de45kN; paraV=0 ambos os sentidos estáticos são verificados. O V real é preservado.',NBR+', 6.1.5.2')
    sa,sb,ss=STEELS[c.angle_steel],STEELS[c.beam_steel],STEELS[c.support_steel]
    ab=math.pi*c.db*c.db/4
    out['bolts']={'Ab_mm2':ab,'fub_MPa':BOLTS[c.bolt],'groups':[]}
    for group,n,planes,fraction,excluded,grip in [('shared_web',c.web_rows,2,1.,c.web_threads_excluded,g['web_grip_mm']),('support_negative',c.support_rows,1,.5,c.support_threads_excluded,g['support_grip_mm']),('support_positive',c.support_rows,1,.5,c.support_threads_excluded,g['support_grip_mm'])]:
        coefficient=.56 if excluded else .45;grip_factor=max(0.,1-.01*max(0.,grip-5*c.db)/1.5)
        rdplane=bolt_shear_resistance(c.db,BOLTS[c.bolt],excluded,grip_factor)
        out['bolts']['groups'].append(dict(id=group,bolt_count=n,shear_planes=planes,coefficient=coefficient,grip_mm=grip,grip_factor=grip_factor,resistance_per_plane_N=rdplane,each_bolt_force_N=Vabs*fraction/n,each_plane_force_N=Vabs*fraction/n/planes))
        _check(out,'bolt_'+group,'Corte dos parafusos · '+group,'bolt_'+group,n*planes*rdplane,fraction,
            'n · planos · α Ab fub/γa2 · redução de pega',NBR+', 6.3.3.2 e6.3.7',bolt_count=n,shear_planes=planes,coefficient=coefficient,Ab_mm2=ab,fub_MPa=BOLTS[c.bolt],grip_factor=grip_factor)
    for side in ('negative','positive'):
        out['physical_angles'].append(dict(id='angle_'+side,side=side,beam_leg_mm=c.beam_leg,support_leg_mm=c.support_leg,thickness_mm=c.t,length_mm=c.length,force_N=Vabs/2))
        for leg,n in [('beam',c.web_rows),('support',c.support_rows)]:
            identifier='angle_'+side+'_'+leg;Ag=c.length*c.t;An=(c.length-n*g['dn'])*c.t
            out['components'][identifier]=dict(material=asdict(sa),physical_angle='angle_'+side,leg=leg,Ag_mm2=Ag,An_mm2=An,thickness_mm=c.t,force_fraction=.5)
            _check(out,identifier+'_shear_gross','Cisalhamento · escoamento bruto',identifier,.6*sa.fy*Ag/GAMMA_A1,.5,'0,60fy Ag/γa1',NBR+', 6.5.5(a)',Ag_mm2=Ag)
            _check(out,identifier+'_shear_net','Cisalhamento · ruptura líquida',identifier,.6*sa.fu*An/GAMMA_A2,.5,'0,60fu An/γa2',NBR+', 6.5.5(b)',An_mm2=An,deducted_holes=n,net_hole_deduction_mm=g['dn'])
    h=g['supported_reduced_height_mm'];Ag=h*c.beam.tw;An=(h-c.web_rows*g['dn'])*c.beam.tw
    out['components']['beam_web']=dict(material=asdict(sb),Ag_mm2=Ag,An_mm2=An,thickness_mm=c.beam.tw,force_fraction=1.,web_thickness_count=1)
    # h0 is the conservative reduced straight section, never intact-I kv on cope.
    _check(out,'beam_web_shear_gross','Alma recortada · cisalhamento bruto','beam_web',.6*sb.fy*Ag/GAMMA_A1,1.,'0,60fy h0 tw/γa1',NBR+', 6.5.5(a)',Ag_mm2=Ag,h0_mm=h)
    _check(out,'beam_web_shear_net','Alma recortada · ruptura líquida','beam_web',.6*sb.fu*An/GAMMA_A2,1.,'0,60fu (h0−n dn)tw/γa2',NBR+', 6.5.5(b)',An_mm2=An,deducted_holes=c.web_rows)
    equal=math.isclose(c.c_top,c.c_bottom,rel_tol=0,abs_tol=1e-8) and math.isclose(c.dc_top,c.dc_bottom,rel_tol=0,abs_tol=1e-8)
    if equal:
        model=cope_model(c.beam.d,c.beam.tw,c.dc_top,c.c_top,c.gap,sb.fy)
        model['restraint_qualified']=restraints['all_required_qualified'];model['equal_copes']=True
        model['actual_cope_moment_Nmm']=c.V*model['e_mm'];model['adopted_cope_moment_Nmm']=out['load_model']['Vd_N']*model['e_mm']
        out['cope']=model
        _check(out,'cope_first_yield','Recorte duplo · primeiro escoamento por flexão','beam_cope',model['first_yield_N'],1.,'fy W1/[γa1(c+folga)]; W1=tw h0²/6',COPE_SOURCE,
            W1_mm3=model['W1_mm3'],e_mm=model['e_mm'],moment_demand_Nmm=abs(model['adopted_cope_moment_Nmm']))
        if model['geometry_within_domain']:
            _check(out,'cope_complementary_stability','Recorte duplo · instabilidade complementar Gerdau/AISC','beam_cope',model['stability_N'],1.,
                'Fbc,d=350600 tw²/(c h0)(3,5−7,5dc/d); VRd=Fbc,d W1/(c+folga)',COPE_SOURCE,
                Fbc_design_MPa=model['Fbc_design_MPa'],already_design_resistance=True,additional_gamma_applied=False,
                conditional_on_external_restraints=True,external_restraints_qualified=model['restraint_qualified'])
        else:_issue(out,'engineering_pending','Recorte igual fora do domínio analítico c≤2d e dc≤0,2d. Primeiro escoamento e componentes preservados; resistência de instabilidade não atribuída. Fonte2014 contém rota ampliada que requer qualificação separada.',COPE_SOURCE)
    else:
        out['cope']={'equal_copes':False,'geometry_within_domain':False,'restraint_qualified':restraints['all_required_qualified'],
            'stability_N':None,'first_yield_N':None,'source':COPE_SOURCE,'reason':'Recortes desiguais não recebem comprimento/profundidade médios.'}
        _issue(out,'engineering_pending','Recortes desiguais: modelo igual não aplicado nem ajustado por média; faltam as seções e estabilidade da rota ampliada2014. Componentes locais disponíveis permanecem explicitamente parciais.',COPE_SOURCE)
    # Uncut member shear is distinct from the doubly free-edged coped strip.
    lam=c.beam.clear/c.beam.tw;lp=1.1*math.sqrt(5.34*200000./sb.fy);lr=1.37*math.sqrt(5.34*200000./sb.fy)
    Cv=1. if lam<=lp else lp/lam if lam<=lr else 1.24*(lp/lam)**2
    _check(out,'beam_uncut_web_shear','Viga íntegra após recorte · cortante da seção W','beam_uncut',.6*sb.fy*c.beam.d*c.beam.tw*Cv/GAMMA_A1,1.,
        '0,60fy(d tw)Cv/γa1; kv=5,34 somente na alma W íntegra',NBR+', 5.4.3.1',Cv=Cv,lambda_web=lam,lambda_p=lp,lambda_r=lr,Aw_mm2=c.beam.d*c.beam.tw)
    out['support_web']={'physical_web_count':1,'thickness_mm':c.support.tw,'hole_count':2*c.support_rows,
        'material':asdict(ss),'hole_coordinates_mm':g['support_hole_coordinates_mm'],
        'load_direction':'vertical_in_web_plane','load_transfer':'directional_bolt_hole_bearing_and_tear_out',
        'continuous_flange_junction_is_free_edge':False,'free_edge_blocks_applicable':False,
        'member_section_demands_supplied':False,'member_global_status':'EXTERNAL_NOT_EVALUATED',
        'scope':'Uma alma física, interior íntegra, sem aberturas/entalhes/ligação sobreposta; junção com mesas contínuas não é borda livre.',
        'source':'NBR6.3.3.3; AISC Table Talk fev2024 pp.18–19 (texto primário indexado); Gerdau exclui o membro de apoio.'}
    out['components']['support_web']=dict(material=asdict(ss),thickness_mm=c.support.tw,web_thickness_count=1,force_fraction=1.,hole_count=2*c.support_rows)
    for sign in directions:
        suffix='_Vpos' if sign>0 else '_Vneg';beam_dir='down' if sign>0 else 'up';support_dir='up' if sign>0 else 'down';support_caps=[]
        for side in ('negative','positive'):
            for leg,n,pitch,end,edge,direction in [
                ('beam',c.web_rows,c.web_pitch,g['web_end_bottom_mm'] if sign>0 else c.web_end_top,g['web_free_toe_edge_mm'],beam_dir),
                ('support',c.support_rows,c.support_pitch,c.support_end_top if sign>0 else g['support_end_bottom_mm'],g['support_free_toe_edge_mm'],support_dir)]:
                identifier='angle_'+side+'_'+leg+suffix
                bearing_rows(out,c,identifier,n,pitch,c.t,sa.fu,.5,end,direction)
                l_blocks(out,identifier,n,pitch,end,edge,c.t,g['dn'],sa.fy,sa.fu,.5,1.,direction,NBR+', 6.5.6; Gerdau2018 p.25, bloco L da cantoneira')
            identifier='support_web_'+side+suffix
            b=bearing_rows(out,c,identifier,c.support_rows,c.support_pitch,c.support.tw,ss.fu,.5,0.,beam_dir,terminal_cap=True)
            support_caps.extend(b['per_hole_capacity_N'])
        _check(out,'support_web_total'+suffix+'_bearing_group','Alma única do apoio · soma dos2n furos físicos','support_web',sum(support_caps),1.,
            'Σ Rb,i sobre duas colunas distintas em uma alma de espessura tw',NBR+', 6.3.3.3(a)',physical_web_count=1,bolt_count=2*c.support_rows,thickness_mm=c.support.tw,per_hole_capacities_N=support_caps)
        if g['bolt_column_within_straight_cope']:
            end=g['cope_top_loaded_edge_mm'] if sign>0 else g['cope_bottom_loaded_edge_mm'];identifier='beam_web'+suffix
            bearing_rows(out,c,identifier,c.web_rows,c.web_pitch,c.beam.tw,sb.fu,1.,end,support_dir)
            ids=l_blocks(out,identifier,c.web_rows,c.web_pitch,end,g['beam_end_distance_mm'],c.beam.tw,g['dn'],sb.fy,sb.fu,1.,1.,support_dir,
                NBR+', 6.5.6 eFig.16(b); Gerdau2018 p.25, borda real do recorte e ponta da viga')
            for row in out['checks']:
                if row['id'] in ids:row['free_boundary']='actual_cope_'+('top' if sign>0 else 'bottom')+'_and_beam_end'
    _qualify_table16_beam_end(c, out, directions)
    out['not_applicable']=[
        {'mechanism':'Bloco de borda livre da alma de apoio','reason':'Apoio interior íntegro e mesas contínuas: não existe extremidade livre no fim da cantoneira ou na raiz. Nenhum bloco fictício de mesa de pilar reutilizado.','reference':NBR+', 6.5.6, Fig.16; topologia R017'},
        {'mechanism':'Forças localizadas normais à mesa, NBR5.7.2–5.7.7','reason':'V entra diretamente nos furos da alma; não é força normal aplicada à face externa de mesa. Requisito de restrição NBR6.1.7 permanece separado.','reference':NBR+', 5.7.1 e6.1.7'},
        {'mechanism':'Seções e estabilidade global da viga de apoio','reason':'Exigem ações reais de contorno, demais cargas e vínculos do membro; não são pré-requisito fictício de V/2 para contato local. Permanecem externos.','reference':NBR+', 5.4,5.5,6.5.5'},
        {'mechanism':'Flexão das cantoneiras estendidas e grupo rígido excêntrico','reason':'Rota flexível convencional somente nos gabaritos documentados. Alternativas mantêm pendência documental.','reference':'Gerdau2018 pp.23–25; Higgins2005 cap.4'}]
    _issue(out,'info','Contato inclui soma normativa e compatibilidade por furo na distribuição direta. Não se somam interfaces em série.',NBR+', 6.3.3.3 e6.1.1.3')
    _issue(out,'info','R15 do desenho industrial é distinto do mínimo aproximado de 12 mm Gerdau. Conferir recorte, acesso e montagem reais antes de fabricação.','R017 p.20; Gerdau2018 p.19')
    _issue(out,'info','Apoio recebe V real nas duas colunas físicas. Verificação global do apoio e efeito do recorte na estabilidade global da viga continuam externos.','Gerdau 2018, p. 9 e nota 4 das tabelas; NBR5.4/5.5')
    if c.beam.source.startswith('material didático') or c.support.source.startswith('material didático'):
        _issue(out,'warning','Perfil do cadastro didático: confirmar dimensões e raízes no catálogo de fornecimento antes da fabricação.','Cadastro de perfis')
    failures=[r['id'] for r in out['checks'] if r['status']=='FAIL'];governing=max(out['checks'],key=lambda r:r['utilization'])
    severities={i['severity'] for i in out['issues']};pending=bool(severities & {'engineering_pending','access_pending'})
    out['summary']=dict(governing_check_id=governing['id'],governing_label=governing['label'],governing_component=governing['component'],
        governing_utilization=governing['utilization'],actual_governing_utilization=governing['actual_utilization'],
        equivalent_total_V_capacity_N=governing['equivalent_total_V_capacity_N'],capacity_is_conditional= pending,
        failed_check_ids=failures,check_count=len(out['checks']),strength_status='FAIL' if failures else 'PASS',
        complete_checks=not pending,physical_angle_count=2,scope='local_connection_only',
        member_global_checks_complete=False,external_restraints_qualified=restraints['all_required_qualified'])
    out['status']=('VERIFIED_SUBCHECK_FAIL' if failures else 'DETAIL_FAIL' if 'detail_fail' in severities else 'ENGINEERING_MODEL_PENDING' if pending else
        'COMPLETE_LOCAL_CHECKS_PASS_WITH_PRESET_DEVIATION' if 'preset_deviation' in severities else 'COMPLETE_LOCAL_CHECKS_PASS_WITHIN_SCOPE')
    out['local_pass']=out['status'] in ('COMPLETE_LOCAL_CHECKS_PASS_WITH_PRESET_DEVIATION','COMPLETE_LOCAL_CHECKS_PASS_WITHIN_SCOPE')
    return out


def evaluate(c):
    try:
        out=_evaluate(c)
        def finite(value):
            if isinstance(value,float):return math.isfinite(value)
            if isinstance(value,dict):return all(finite(v) for v in value.values())
            if isinstance(value,(list,tuple)):return all(finite(v) for v in value)
            return True
        if not finite(out):raise ArithmeticError('Faixa numérica finita excedida.')
        return out
    except (ArithmeticError,OverflowError,ValueError) as exc:
        return {'status':'NUMERICAL_FAILURE','local_pass':False,'global_pass':False,'member_global_status':'EXTERNAL_NOT_EVALUATED',
            'issues':[dict(severity='numerical_failure',text=str(exc),reference='Faixa numérica do cálculo; entrada finita não garante resultados derivados representáveis')],
            'checks':[],'geometry':{},'load_model':{},'summary':{},'components':{},'physical_angles':[],'cope':{},'support_web':{},'restraints':{},
            'scope':SCOPE,'exclusions':EXCLUSIONS.copy(),'not_applicable':[],
            'inputs':_safe(asdict(c)) if isinstance(c,CopedDoubleAngle) else _safe(c)}
