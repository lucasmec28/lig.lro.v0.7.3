"""Lossless physical envelopes for the nominal axial 2L connection.

Grouping is presentation only. No branch resistance or demand is recomputed,
added, averaged, or discarded; complete primitive witnesses remain available.
"""
from collections import OrderedDict
from copy import deepcopy
from .models import finite_real


COMPONENT_LABELS = {
    'angle_pair': 'Par de cantoneiras', 'angle_1': 'Cantoneira A1',
    'angle_2': 'Cantoneira A2', 'angle_negative': 'Cantoneira A1',
    'angle_positive': 'Cantoneira A2', 'plate': 'Chapa central única',
    'terminal': 'Corte terminal da chapa', 'bolts': 'Parafusos compartilhados',
    'shared_bolts': 'Parafusos compartilhados',
}
MECHANISM_LABELS = {
    'gross_yield': 'Escoamento da seção bruta',
    'gross_yielding': 'Escoamento da seção bruta',
    'net_fracture': 'Ruptura da seção líquida efetiva',
    'net_rupture': 'Ruptura da seção líquida efetiva',
    'bolt_shear': 'Corte dos parafusos', 'bearing': 'Contato e rasgamento',
    'block': 'Cisalhamento em bloco', 'block_shear': 'Cisalhamento em bloco',
    'block_tearout': 'Cisalhamento em bloco',
}


def component_label(component):
    return COMPONENT_LABELS.get(component, str(component))


def _finite(value):
    return finite_real(value)


def _governors(members):
    finite = [row for row in members if _finite(row.get('utilization'))]
    maximum = max((row['utilization'] for row in finite), default=None)
    # An unresolved numerical witness is never hidden by a finite passing one.
    unresolved = [row for row in members if not _finite(row.get('utilization'))]
    ties = unresolved + [row for row in finite if row['utilization'] == maximum]
    return maximum, deepcopy(ties)


def physical_envelopes(result):
    """One envelope per physical component/mechanism, with all cases and ties.

    The caller owns result authenticity. Canonical drawing/Word entry points
    always evaluate the current input before calling this presentation helper.
    """
    groups = OrderedDict()
    for row in result.get('checks') or []:
        if not isinstance(row, dict):
            continue
        key = (str(row.get('component', 'unidentified')), str(row.get('mechanism', 'unidentified')))
        groups.setdefault(key, []).append(row)
    actual_ids = {case.get('id') for case in result.get('cases', [])
                  if case.get('id') == 'actual' or case.get('kind') == 'actual'}
    actual_ids.add('actual')
    envelopes = []
    for (component, mechanism), rows in groups.items():
        maximum, governing = _governors(rows)
        actual = [row for row in rows if row.get('case_id') in actual_ids]
        actual_maximum, actual_governing = _governors(actual)
        envelopes.append({
            'id': component + '__' + mechanism,
            'component': component, 'component_label': component_label(component),
            'mechanism': mechanism, 'mechanism_label': MECHANISM_LABELS.get(mechanism, mechanism),
            'units': 'N', 'utilization': maximum, 'governing': governing,
            'governing_ids': [row.get('id') for row in governing],
            'status': 'PASS' if rows and all(row.get('status') == 'PASS' for row in rows) else 'FAIL',
            'actual_utilization': actual_maximum, 'actual_governing': actual_governing,
            'actual_status': ('PASS' if all(row.get('status') == 'PASS' for row in actual) else 'FAIL') if actual else 'NOT_EVALUATED',
            'member_ids': [row.get('id') for row in rows], 'members': deepcopy(rows),
        })
    return envelopes


def governing_description(row):
    return '; '.join(str(row[key]) for key in ('id', 'case_id', 'path', 'loaded_direction')
                     if row.get(key) is not None)
