"""Independent 2L column-flange route, lossless native input and local results."""
from dataclasses import fields
import hashlib
import json
import math

import pandas as pd
import streamlit as st

from .angle_catalog import catalog, get_angle, label as catalog_label
from .angle_catalog_ui import changed as catalog_changed, draft_keys as catalog_draft_keys, reset as reset_catalog
from .display_precision import display_format, display_frame, display_tree, number_input
from .models import Profile, profiles, STEELS, BOLTS, KGF
from .report import BRAND, LINK
from .welded_support_double_angle import (WeldedSupportDoubleAngle, COMPONENT_VERSION,
                                         FAMILY, SCOPE, ASSEMBLY_NOTE, evaluate, presets)

P = {name: p for name, p in profiles().items() if p.family == 'W'}
PRESETS = presets()
CUSTOM = 'W personalizado'
PREFIX = 'wsda_'
STATE = '_welded_support_double_angle_'
PROFILE_VALUES = ('d', 'bf', 'tw', 'tf', 'clear', 'area', 'mass')
LOAD_UNITS = {'V': KGF, 'N': KGF, 'M': KGF * 1000, 'torsion': KGF * 1000}
LOAD_KEYS = {'V': 'V_kgf', 'N': 'N_kgf', 'M': 'M_kgfm', 'torsion': 'torsion_kgfm'}
STATUS = {
    'INVALID_INPUT': 'DADOS INVÁLIDOS',
    'NUMERICAL_FAILURE': 'FALHA NUMÉRICA · CÁLCULO NÃO CONCLUÍDO',
    'INVALID_GEOMETRY': 'GEOMETRIA FISICAMENTE INVÁLIDA',
    'OUTSIDE_SUPPORTED_SCOPE': 'FORA DO DOMÍNIO 2L DESCENDENTE',
    'DETAIL_FAIL': 'NÃO ATENDE AO DETALHAMENTO',
    'VERIFIED_SUBCHECK_FAIL': 'NÃO ATENDE ÀS VERIFICAÇÕES REALIZADAS',
    'ENGINEERING_MODEL_PENDING': 'VERIFICAÇÃO COMPLEMENTAR PENDENTE',
    'COMPLETE_CHECKS_PASS_WITHIN_SCOPE': 'ATENDE ÀS VERIFICAÇÕES LOCAIS NO DOMÍNIO 2L',
}


def _draft_keys():
    keys = [PREFIX + f.name for f in fields(WeldedSupportDoubleAngle) if f.name not in ('beam', 'support')]
    keys += [PREFIX + key for key in LOAD_KEYS.values()]
    for role in ('beam', 'support'):
        keys += [PREFIX + role + '_' + key for key in ('name', 'manual_name', 'family', 'source') + PROFILE_VALUES]
    return keys + catalog_draft_keys(PREFIX)


def _finite(value):
    try:
        return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)
    except OverflowError:
        return False


def _widget_float(value, name):
    converted = float(value)
    if not math.isfinite(converted) or converted != value or converted < 0:
        raise ValueError(f'{name}: valor {value!r} não representável sem alteração no controle.')
    return converted


def _proposed_ui_state(c):
    """All validation precedes any state change, including profile precision."""
    c.to_dict()
    proposed = {}
    for f in fields(c):
        if f.name in ('beam', 'support'):
            continue
        value = getattr(c, f.name)
        if isinstance(value, (int, float)) and not isinstance(value, bool) and f.name not in {*LOAD_UNITS, 'angle_count', 'web_rows', 'web_columns', 'db'}:
            value = _widget_float(value, f.name)
        proposed[PREFIX + f.name] = value
    for key, unit in LOAD_UNITS.items():
        shown = getattr(c, key) / unit
        if not _finite(shown):
            raise ValueError(key + ': ação não representável em kgf / kgf·m.')
        proposed[PREFIX + LOAD_KEYS[key]] = shown
    for role in ('beam', 'support'):
        p = getattr(c, role)
        prefix = PREFIX + role + '_'
        proposed[prefix + 'name'] = p.name if p.name in P and p == P[p.name] else CUSTOM
        for key, value in [('manual_name', p.name), ('family', p.family), ('source', p.source)]:
            proposed[prefix + key] = value
        for key in PROFILE_VALUES:
            proposed[prefix + key] = _widget_float(getattr(p, key), role + '.' + key)
    return proposed


def seed(c):
    proposed = _proposed_ui_state(c)
    st.session_state.update(proposed)
    reset_catalog(PREFIX)
    st.session_state.pop(PREFIX + 'report', None)
    st.session_state.pop(STATE + 'ui_draft', None)


def use_example():
    seed(PRESETS[st.session_state[PREFIX + 'example']])
    st.session_state.pop(PREFIX + 'import_error', None)


def _unique_object(pairs):
    data = {}
    for key, value in pairs:
        if key in data:
            raise ValueError('Campo JSON duplicado: ' + str(key))
        data[key] = value
    return data


def load_project():
    try:
        upload = st.session_state[PREFIX + 'upload']
        if upload is None:
            raise ValueError('Selecione um arquivo JSON.')
        payload = upload.getvalue()
        if len(payload) > 200000:
            raise ValueError('Arquivo maior que 200 kB.')
        c = WeldedSupportDoubleAngle.from_dict(json.loads(payload, object_pairs_hook=_unique_object))
        seed(c)
        st.session_state.pop(PREFIX + 'import_error', None)
    except (ValueError, TypeError, KeyError, OverflowError) as exc:
        st.session_state[PREFIX + 'import_error'] = 'Não foi possível abrir: ' + str(exc)


def _select(label, options, key, labels=None, **kwargs):
    options = list(options)
    current = st.session_state.get(key)
    if current is not None and current not in options:
        options.append(current)
    if labels:
        kwargs['format_func'] = lambda value: labels.get(value, str(value) + ' · valor importado')
    return st.selectbox(label, options, key=key, **kwargs)


def bolt_changed():
    hole = {16.: 18., 20.: 22., 24.: 26., 30.: 33.}.get(st.session_state[PREFIX + 'db'])
    if hole is not None:
        st.session_state[PREFIX + 'hole_diameter'] = hole


def _dimension(key, label):
    return number_input(label + ' (mm)', min_value=0., key=PREFIX + key)


def _profile(role, title):
    prefix = PREFIX + role + '_'
    name = st.selectbox(title, [CUSTOM] + list(P), key=prefix + 'name')
    if name in P:
        p = P[name]
    else:
        with st.expander('Geometria personalizada · ' + title, expanded=True):
            designation = st.text_input('Designação · ' + title, key=prefix + 'manual_name')
            family = st.text_input('Família declarada · ' + title, key=prefix + 'family')
            values = {key: number_input(text + ' · ' + title, min_value=0., key=prefix + key)
                      for key, text in [('d', 'Altura d (mm)'), ('bf', 'Largura bf (mm)'),
                      ('tw', 'Alma tw (mm)'), ('tf', 'Mesa tf (mm)'), ('clear', 'Altura livre das raízes (mm)'),
                      ('area', 'Área A (mm²)'), ('mass', 'Massa linear (kg/m)')]}
            source = st.text_input('Fonte das dimensões/área · ' + title, key=prefix + 'source')
            p = Profile(designation, family, source=source, **values)
    st.caption(f"d={display_format(p.d, 'g')}; bf={display_format(p.bf, 'g')}; tw={display_format(p.tw, 'g')}; tf={display_format(p.tf, 'g')} mm.")
    return p


def _angle_catalog():
    """Restricted chooser; an imported unsupported record stays visible."""
    s = st.session_state
    key = PREFIX + 'angle_catalog_id'
    ids = [''] + [i for i, r in catalog().items() if r['leg'] >= 63.5 or i == s.get(key)]
    if s.get(key, '') not in ids:
        ids.append(s[key])
    identity = st.selectbox('Perfil de cantoneira · catálogo Gerdau', ids, key=key,
        format_func=lambda i: catalog_label(i) if i else 'Manual / projeto importado',
        on_change=catalog_changed, args=(PREFIX,))
    if not identity:
        st.caption('Entrada manual. A seleção do catálogo altera somente geometria; o aço permanece independente.')
        return
    record = get_angle(identity)
    if record is None:
        st.error('Identidade de catálogo não reconhecida.')
        return
    st.caption(record['source'] + '. Catálogo geométrico; não amplia o domínio resistente 2L.')
    for flag in record.get('review_flags', []):
        st.warning('Observação da tabela Gerdau: ' + str(flag))
    if s[PREFIX + 'root_radius'] <= 0 or not s[PREFIX + 'angle_root_confirmed'] or not s[PREFIX + 'angle_root_source'].strip():
        st.warning('Raio interno não publicado pela Gerdau: informe o raio real, sua fonte independente e confirme a declaração. O valor inicial zero é uma pendência.')
    _dimension('root_radius', 'Raio interno real · declaração independente')
    st.text_input('Fonte independente do raio interno · documento/medição', key=PREFIX + 'angle_root_source')
    st.checkbox('Confirmo o raio interno e sua fonte independente', key=PREFIX + 'angle_root_confirmed')


def _force(key):
    raw = st.session_state[PREFIX + key]
    shown = st.session_state[PREFIX + LOAD_KEYS[key]]
    if not _finite(raw) or not _finite(shown):
        raise ValueError(key + ': ação finita obrigatória.')
    # Preserve native precision and signed subnormals until the displayed action changes.
    if shown == raw / LOAD_UNITS[key]:
        return raw
    converted = shown * LOAD_UNITS[key]
    if not _finite(converted):
        raise ArithmeticError(key + ': transbordamento na conversão de kgf / kgf·m para N / N mm.')
    return converted


def _complete_checks(checks):
    numeric = ('actual_demand_N', 'demand_N', 'design_capacity_N', 'actual_utilization', 'utilization')
    return bool(checks) and all(isinstance(row, dict) and all(_finite(row.get(k)) for k in numeric)
                               and row.get('status') in ('PASS', 'FAIL') for row in checks)


COMPONENT_LABELS = {
    'weld': 'Cada solda vertical na mesa do pilar', 'angle': 'Cantoneira',
    'column': 'Mesa do pilar', 'angle_support': 'Aba de apoio',
    'angle_beam': 'Aba da viga', 'bolts': 'Parafusos comuns em corte duplo',
    'beam_web': 'Alma única da viga', 'web': 'Alma única da viga', 'bolts_web_angle': 'Transferência entre parafuso, cantoneira e alma',
}


def _checks_table(checks):
    return pd.DataFrame([{'ID': r['id'], 'Componente': COMPONENT_LABELS.get(r['component'], r['component']), 'Verificação': r['label'],
        'Solicitação real (kgf)': r['actual_demand_N'] / KGF,
        'Solicitação adotada (kgf)': r['demand_N'] / KGF, 'Resistência (kgf)': r['design_capacity_N'] / KGF,
        'Índice real': r['actual_utilization'], 'Índice adotado': r['utilization'],
        'Resultado': 'ATENDE' if r['status'] == 'PASS' else 'NÃO ATENDE',
        'Fórmula': r['formula'], 'Referência': r['reference']} for r in checks])


def _input_failure(status, exc):
    s = st.session_state
    s.pop(PREFIX + 'report', None)
    s.pop(STATE + 'project', None)
    s[STATE + 'result'] = dict(status=status, global_pass=False, checks=[], summary={},
        issues=[dict(severity='numerical_failure' if status == 'NUMERICAL_FAILURE' else 'invalid_input', text=str(exc))])
    st.error(STATUS[status]); st.error(str(exc))
    st.caption('Corrija a entrada para recalcular. Nenhum arquivo do cálculo anterior permanece válido.')
    st.button('Gerar memória 2L', disabled=True)


def render():
    from .welded_support_double_angle_drawing import image_bytes, drawing_svg
    from .welded_support_double_angle_report import create_report
    s = st.session_state
    if PREFIX + 'project' not in s:
        saved, draft = s.get(STATE + 'project'), s.get(STATE + 'ui_draft')
        seed(WeldedSupportDoubleAngle.from_dict(saved) if saved else next(iter(PRESETS.values())))
        if draft:
            s.update(draft)
    for key in _draft_keys():
        if key in s:
            s[key] = s[key]
    with st.sidebar:
        st.caption(COMPONENT_VERSION + ' · duas cantoneiras soldadas ao pilar')
        st.selectbox('Exemplo de cantoneiras duplas', list(PRESETS), key=PREFIX + 'example')
        st.button('Usar exemplo 2L', on_click=use_example, use_container_width=True)
        st.file_uploader('Abrir projeto 2L', type=['json'], key=PREFIX + 'upload')
        st.button('Carregar 2L', on_click=load_project, use_container_width=True)
        if PREFIX + 'import_error' in s:
            st.error(s[PREFIX + 'import_error'])
        st.divider(); st.caption(BRAND); st.link_button('LinkedIn · Lucas Oliveira', LINK)
    st.title('Cantoneiras duplas soldadas ao pilar')
    st.caption('2L simétricas · uma alma · dois planos de corte · parafusos comuns na viga · dois filetes verticais no pilar')
    st.info('Estado final de duas cantoneiras simétricas, restrito a V descendente estático. Cada solda vertical externa recebe V/2, com retorno superior curto sem crédito. Sem solda inferior ou no talão.')
    st.warning(ASSEMBLY_NOTE)
    st.text_input('Identificação do projeto 2L', key=PREFIX + 'project')
    left, right = st.columns([.85, 1.5], gap='large')
    with left:
        beam = _profile('beam', 'Viga apoiada W')
        support = _profile('support', 'Pilar de apoio W')
        number_input('Cortante Vsd já majorado, com sinal (kgf)', key=PREFIX + 'V_kgf')
        st.caption('V positivo: para baixo. V nulo ou ascendente é preservado e fica fora do domínio. O mínimo de 45 kN incide uma vez na ligação.')
        with st.expander('N, M e torção externos'):
            for key, title in [('N', 'Força axial N (kgf)'), ('M', 'Momento M (kgf·m)'), ('torsion', 'Torção T (kgf·m)')]:
                number_input(title, key=PREFIX + LOAD_KEYS[key])
            st.caption('N, M e T não nulos permanecem registrados e impedem aprovação nesta rota.')
        with st.expander('Geometria das duas cantoneiras iguais', expanded=True):
            number_input('Quantidade física de cantoneiras', min_value=1, max_value=20, key=PREFIX + 'angle_count')
            st.checkbox('Cantoneiras iguais e simétricas em faces opostas da alma', key=PREFIX + 'symmetric')
            _angle_catalog()
            for key, label in [('beam_leg', 'Aba junto à alma da viga'), ('support_leg', 'Aba junto à mesa do pilar'),
                               ('t', 'Espessura da cantoneira'), ('length', 'Comprimento vertical')]:
                _dimension(key, label)
            if not s[PREFIX + 'angle_catalog_id']:
                _dimension('root_radius', 'Raio interno da cantoneira')
            _dimension('angle_top', 'Topo da cantoneira abaixo do topo da viga')
        with st.expander('Parafusos somente na alma da viga', expanded=True):
            number_input('Parafusos verticais na alma', min_value=1, max_value=20, key=PREFIX + 'web_rows')
            number_input('Colunas na aba da viga', min_value=1, max_value=20, key=PREFIX + 'web_columns')
            for key, label in [('beam_gauge', 'Face do pilar ao eixo dos parafusos e'), ('web_pitch', 'Passo vertical'),
                               ('web_end_top', 'Borda superior ao primeiro parafuso')]:
                _dimension(key, label)
            st.caption('Domínio inicial: uma coluna comum, 2 a 8 parafusos, e ≤ 76,20 mm. Pega = t + tw da viga + t; dois planos de corte. A alma física é única.')
        with st.expander('Solda somente na mesa do pilar', expanded=True):
            _dimension('weld_leg', 'Perna do filete w')
            st.checkbox('Borda de solda reforçada explicitamente documentada', key=PREFIX + 'reinforced_weld_edge')
            if s[PREFIX + 'reinforced_weld_edge']:
                st.warning('Exceção de borda reforçada NBR 6.2.6.2.2(b): execução deve ser documentada e conferida. Não aumenta a garganta nem a resistência calculada.')
            _dimension('top_return', 'Retorno superior real')
            _select('Arranjo da solda', ['toe_vertical_short_top'], PREFIX + 'weld_layout',
                    {'toe_vertical_short_top': 'Uma vertical externa por cantoneira + retorno superior curto'})
            _select('Processo / eletrodo', ['SMAW_E7018'], PREFIX + 'weld_process')
            number_input('Resistência do eletrodo fuw (MPa)', min_value=0., key=PREFIX + 'electrode_fuw')
            st.caption('Retorno usual 2w; limitado a 4w e à metade da aba. Somente a linha vertical externa de cada cantoneira recebe crédito. Borda inferior e talão livres; nenhuma solda na alma da viga.')
        with st.expander('Furação, materiais e montagem'):
            _select('Diâmetro do parafuso (mm)', [16., 20., 24., 30.], PREFIX + 'db', on_change=bolt_changed)
            _select('Classe dos parafusos', list(BOLTS), PREFIX + 'bolt')
            _dimension('hole_diameter', 'Diâmetro físico do furo')
            _select('Tipo de furo', ['standard_round'], PREFIX + 'hole_type', {'standard_round': 'Circular padrão'})
            st.checkbox('Furo de broca documentado: sem acréscimo de 2 mm na dedução', key=PREFIX + 'drilled')
            st.checkbox('Rosca excluída e documentada nos dois planos de corte', key=PREFIX + 'web_threads_excluded')
            for role, label in [('beam', 'Aço da viga'), ('support', 'Aço do pilar'), ('angle', 'Aço da cantoneira')]:
                _select(label, list(STEELS), PREFIX + role + '_steel')
            for key, label in [('gap', 'Folga da ponta da viga à mesa do pilar'),
                               ('fabrication_clearance', 'Folga adicional de fabricação'), ('tool_radius', 'Raio do envelope de cabeça, porca, arruela e ferramenta'),
                               ('weld_tool_radius', 'Raio do envelope físico de soldagem em campo')]:
                _dimension(key, label)
            _select('Exposição', ['painted', 'weathering'], PREFIX + 'exposure', {'painted': 'Protegida / pintada', 'weathering': 'Aço patinável exposto'})
            st.caption('Informe o envelope real de cabeça, porca, arruela e ferramenta. O piso geométrico da ferragem é apenas uma verificação mínima de plausibilidade; não é tamanho de chave nem comprovação de acesso.')
            _select('Montagem da ligação sem recorte', ['one_shop_angle_other_field_weld'], PREFIX + 'assembly',
                    {'one_shop_angle_other_field_weld': 'Uma cantoneira de oficina; outra soldada em campo com a viga içada'})
            st.caption('O envelope de soldagem em campo é uma declaração física de espaço para ferramenta e execução. As folgas geométricas não certificam o procedimento de soldagem nem a estabilidade temporária.')
            st.caption(ASSEMBLY_NOTE)
        with st.expander('Hipóteses e limites do modelo'):
            _select('Receptor', ['column_flange'], PREFIX + 'kind', {'column_flange': 'Mesa de pilar W'})
            _select('Recorte da viga', ['none'], PREFIX + 'cope', {'none': 'Sem recorte'})
            st.checkbox('Pilar contínuo na região da ligação', key=PREFIX + 'support_continuous')
            st.checkbox('Ações estáticas, sem impacto ou fadiga', key=PREFIX + 'static')
            st.checkbox('Combinação última normal', key=PREFIX + 'normal_combination')
            st.checkbox('Projeto exige ausência de deslizamento', key=PREFIX + 'no_slip_required')
            st.caption('Dimensões e robustez são restrições desta implementação inicial. Não constituem prova isolada de ductilidade rotacional ou de estabilidade global.')
        st.text_area('Observações do responsável técnico', key=PREFIX + 'notes')
    s[STATE + 'ui_draft'] = {key: s[key] for key in _draft_keys() if key in s}
    try:
        values = {f.name: s[PREFIX + f.name] for f in fields(WeldedSupportDoubleAngle)
                  if f.name not in ('beam', 'support', *LOAD_UNITS)}
        c = WeldedSupportDoubleAngle(beam=beam, support=support, **{key: _force(key) for key in LOAD_UNITS}, **values)
        native = c.to_dict()
        encoded = json.dumps(native, ensure_ascii=False, indent=2, allow_nan=False)
    except ArithmeticError as exc:
        with right: _input_failure('NUMERICAL_FAILURE', exc)
        return
    except (ValueError, TypeError, KeyError) as exc:
        with right: _input_failure('INVALID_INPUT', exc)
        return
    digest = hashlib.sha256(encoded.encode()).hexdigest()
    s[STATE + 'project'] = native
    if s.get(PREFIX + 'report', ('', '', b''))[0] != digest:
        s.pop(PREFIX + 'report', None)
    r = evaluate(c)
    s[STATE + 'result'] = r
    status = r['status']; checks = r.get('checks') or []
    complete = _complete_checks(checks)
    artifact_ok = status not in ('INVALID_INPUT', 'NUMERICAL_FAILURE')
    ready = complete and bool(r.get('geometry', {}).get('valid')) and status not in ('OUTSIDE_SUPPORTED_SCOPE', 'INVALID_GEOMETRY')
    if not ready:
        s.pop(PREFIX + 'report', None)
    with right:
        approved = (status == 'COMPLETE_CHECKS_PASS_WITHIN_SCOPE' and r.get('global_pass') is True
                    and ready and r.get('summary', {}).get('complete_checks') is True
                    and all(row['status'] == 'PASS' for row in checks))
        if approved: st.success(STATUS[status])
        elif status in ('INVALID_INPUT', 'NUMERICAL_FAILURE', 'INVALID_GEOMETRY', 'DETAIL_FAIL', 'VERIFIED_SUBCHECK_FAIL'):
            st.error(STATUS.get(status, status))
        else: st.warning(STATUS.get(status, status))
        st.caption('Conclusão local do estado final. Não certifica fabricação, estabilidade temporária ou dimensionamento global; não autoriza liberar o içamento.')
        summary = r.get('summary') or {}
        if summary:
            a, b = st.columns(2)
            a.metric('Índice com V real', display_format(summary['actual_governing_utilization']))
            b.metric('Índice com ação adotada', display_format(summary['governing_utilization']))
            st.caption('Governa: ' + summary['governing_label'] + '. Capacidade equivalente total V: ' +
                       display_format(summary['equivalent_total_V_capacity_N'] / KGF) + ' kgf.')
        if artifact_ok:
            st.image(image_bytes(c, r), width='stretch')
        for issue in r.get('issues') or []:
            severity = issue.get('severity', '')
            action = st.error if severity in ('invalid_input', 'numerical_failure', 'invalid_geometry', 'detail_fail') else st.caption if severity == 'info' else st.warning
            action(issue['text'])
        with st.expander('Caminho das forças e ações para o modelo global'):
            st.write('Alma única com V total → parafusos comuns em corte duplo → duas cantoneiras com V/2 cada → dois filetes verticais na mesa do pilar. A alma e o conjunto de parafusos recebem V total; a alma não é duplicada.')
            st.caption('A distribuição direta dos parafusos pertence ao detalhe convencional restrito. A excentricidade no plano de cada solda é calculada com V/2. N=M=T externos nulos não eliminam o transporte da reação real ao modelo global.')
            st.json(display_tree(r.get('load_model') or {}), expanded=False)
        st.caption(SCOPE)
        for exclusion in r.get('exclusions') or []: st.caption(exclusion)
    if complete:
        st.subheader('Todas as verificações locais')
        st.dataframe(display_frame(_checks_table(checks)), hide_index=True, width='stretch')
        with st.expander('Fórmulas, referências e registros completos'):
            st.json(display_tree(checks), expanded=False)
    with st.expander('Geometria, solda e aba de apoio'):
        for key in ('geometry', 'welds', 'bolts', 'not_applicable'):
            if r.get(key): st.write(key); st.json(display_tree(r[key]), expanded=False)
    a, b, d = st.columns(3)
    a.download_button('Salvar projeto 2L .json', encoded, 'cantoneiras_duplas_apoio_2L.json', 'application/json')
    if artifact_ok:
        b.download_button('Baixar desenho 2L .svg', drawing_svg(c, r), 'cantoneiras_duplas_apoio_2L.svg', 'image/svg+xml')
    if d.button('Gerar memória 2L', disabled=not ready, use_container_width=True):
        s[PREFIX + 'report'] = (digest, 'memoria_cantoneiras_duplas_apoio_2L.docx', create_report(c, r))
    if PREFIX + 'report' in s:
        _, filename, payload = s[PREFIX + 'report']
        st.download_button('Baixar memória 2L .docx', payload, filename,
                           'application/vnd.openxmlformats-officedocument.wordprocessingml.document')
