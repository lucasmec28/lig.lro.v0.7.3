"""Physical topology and signed audit of the qualified column/base weld paths.

Plan coordinates are (display horizontal y, display vertical x). The x-z
section and the independent y-z web detail preserve the same local frame.
Line thickness is graphical; every longitudinal endpoint is a real mm input.
"""
from io import BytesIO
from .drawing_annotations import dimension
import math
from textwrap import shorten
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Circle, Polygon, FancyArrowPatch
from .base_plate_drawing import INK, PLATE, COLUMN

MODEL = 'two_flange_normal_web_shear'
PHYSICAL = '#71808a'
FLANGE = '#ba4b19'
WEB = '#176d92'


def _positive(value):
    return type(value) in (int, float) and math.isfinite(value) and 0 < value <= 1e6


def _number(value, digits=3):
    return f'{value:.{digits}f}' if type(value) in (int, float) and math.isfinite(value) else 'pendente'


def _require_drawable_geometry(c):
    """Reject unsupported scales/containment before allocating plot artists."""
    p,u=c.column,c.column_weld
    def finite(value,zero=False):
        return type(value) in (int,float) and math.isfinite(value) and (0 if zero else 1e-6)<=value<=1e6
    if any(not finite(value) for value in (p.d,p.bf,p.tw,p.tf,p.clear,c.L,c.B,c.tp)):
        raise ValueError('Geometria fora do domínio numérico do desenho da solda.')
    for physical,effective,available in ((u.flange_length,u.flange_effective_length,min(p.bf,c.B)),
                                       (u.web_length,u.web_effective_length,p.clear)):
        if (not finite(physical,True) or not finite(effective,True) or
                (0<physical<1e-6) or (0<effective<1e-6) or
                effective>physical+1e-8 or physical>available+1e-8):
            raise ValueError('Comprimentos fora do domínio ou da seção física; desenho da solda indisponível.')
    from .base_plate_details import fillet_dimensions
    for part in ('flange','web'):
        if getattr(c,'weld_'+part+'_type')=='fillet':
            size=getattr(c,'weld_'+part+'_size')
            if not finite(size):
                raise ValueError('Filete fora do domínio numérico do desenho da solda.')
            leg=fillet_dimensions(size,getattr(c,'weld_'+part+'_measure'))['leg']
            if not finite(leg) or leg>max(p.d,p.bf,c.L,c.B,c.tp):
                raise ValueError('Filete fora da escala física suportada no desenho da solda.')


def draw_plan_welds(ax, c, prefix='cw_', linewidth=1.4):
    """Overlay only the declared physical/effective straight centered paths.

    CJP has one fused section; two web-face fillets are two separate lines.
    This helper never invents lengths from a flange width or rod gauge.
    """
    u, p = c.column_weld, c.column
    if u.model != MODEL:
        return
    _require_drawable_geometry(c)
    def segment(xs, ys, gid, color, width, style='-'):
        ax.plot(xs, ys, color=color, lw=width, ls=style, solid_capstyle='butt',
                gid=prefix+gid, zorder=8)
    flange_kind = c.weld_flange_type
    if flange_kind in ('fillet', 'cjp'):
        h = p.d if flange_kind == 'fillet' else p.d-p.tf
        for name, x in (('left', -h/2), ('right', h/2)):
            if _positive(u.flange_length):
                segment([-u.flange_length/2, u.flange_length/2], [x, x],
                        'flange_'+name+'_physical', PHYSICAL, linewidth+1.1)
                if flange_kind == 'cjp':
                    band=Rectangle((-u.flange_length/2, x-p.tf/2), u.flange_length, p.tf,
                                   facecolor='none', edgecolor=FLANGE, hatch='////', lw=.5, zorder=6)
                    band.set_gid(prefix+'flange_'+name+'_fused_section'); ax.add_patch(band)
            if _positive(u.flange_effective_length):
                segment([-u.flange_effective_length/2, u.flange_effective_length/2], [x, x],
                        'flange_'+name+'_effective', FLANGE, linewidth)
    if c.weld_web_type in ('fillet', 'cjp'):
        positions = (('negative_y', -p.tw/2), ('positive_y', p.tw/2)) if c.weld_web_type=='fillet' else (('single_cjp', 0.),)
        for name, y in positions:
            if _positive(u.web_length):
                segment([y, y], [-u.web_length/2, u.web_length/2],
                        'web_'+name+'_physical', PHYSICAL, linewidth+1.1)
            if _positive(u.web_effective_length):
                segment([y, y], [-u.web_effective_length/2, u.web_effective_length/2],
                        'web_'+name+'_effective', WEB, linewidth)
        if c.weld_web_type=='cjp' and _positive(u.web_length):
            band=Rectangle((-p.tw/2, -u.web_length/2), p.tw, u.web_length,
                           facecolor='none', edgecolor=WEB, hatch='////', lw=.5, zorder=6)
            band.set_gid(prefix+'web_single_fused_section'); ax.add_patch(band)


def require_current_result(c, r):
    """Never pair current-input geometry with a prior numeric force field."""
    from .base_weld_qualified import result_signature
    out=getattr(r,'local_column_weld',{})
    if out.get('input_signature') != result_signature(c):
        raise ValueError('Resultado de solda desatualizado: recalcule o componente para os dados atuais antes de exportar.')
    return out


def image_bytes(c, r, fmt='png'):
    if c.column_weld.model != MODEL:
        raise ValueError('Desenho reservado ao componente duas mesas N/M e alma V.')
    p, u = c.column, c.column_weld
    out = require_current_result(c, r)
    _require_drawable_geometry(c)
    L, B = c.L, c.B
    with plt.rc_context({'font.family':'DejaVu Sans', 'font.size':10, 'svg.fonttype':'none'}):
        fig=plt.figure(figsize=(12.8, 10.4), layout='constrained')
        grid=fig.add_gridspec(2, 2, height_ratios=(3.4, 2.0), width_ratios=(1.,1.1))
        plan=fig.add_subplot(grid[0,0]); section=fig.add_subplot(grid[0,1])
        web=fig.add_subplot(grid[1,0]); audit=fig.add_subplot(grid[1,1])
        for ax in (plan,section,web):
            ax.set_aspect('equal'); ax.axis('off')
        audit.axis('off')
        def rect(ax,x,y,w,h,color,gid,**kwargs):
            shape=Rectangle((x,y),w,h,facecolor=color,edgecolor=INK,lw=.7,**kwargs)
            shape.set_gid(gid); ax.add_patch(shape); return shape
        def poly(ax,coords,color,gid):
            shape=Polygon(coords,closed=True,facecolor=color,edgecolor=INK,lw=.65)
            shape.set_gid(gid); ax.add_patch(shape)
        def text(ax,x,y,label,**kwargs):
            return ax.text(x,y,label,color=INK,fontsize=10,**kwargs)
        def arrow(ax,start,end,gid,color=INK):
            shape=FancyArrowPatch(start,end,arrowstyle='-|>',mutation_scale=13,color=color,lw=1.5)
            shape.set_gid(gid); ax.add_patch(shape)
        def dim(ax,x0,y0,x1,y1,label,color=INK):
            side=(-1 if x0>0 else 1) if x0==x1 else (1 if y0>0 else -1)
            return dimension(ax,(x0,y0),(x1,y1),label,fontsize=9,
                             rotation=90 if x0==x1 else 0,color=color,pad=1.2,lw=.7,short_side=side)
        m=max(L*.1,B*.12,30.)
        plan.set_title('PLANTA y–x · TRECHOS RETOS CENTRADOS',loc='left',fontsize=11,fontweight='bold',color=INK)
        rect(plan,-B/2,-L/2,B,L,PLATE,'cw_plate_plan',alpha=.45)
        rect(plan,-p.bf/2,-p.d/2,p.bf,p.tf,COLUMN,'cw_column_left_flange')
        rect(plan,-p.bf/2,p.d/2-p.tf,p.bf,p.tf,COLUMN,'cw_column_right_flange')
        rect(plan,-p.tw/2,-p.d/2+p.tf,p.tw,p.d-2*p.tf,COLUMN,'cw_column_web')
        for i,(x,y) in enumerate(((x,y) for x in (-c.a,c.a) for y in (-c.a2/2,c.a2/2)),1):
            rod=Circle((y,x),c.db/2,facecolor='white',edgecolor=PHYSICAL,lw=.8)
            rod.set_gid('cw_anchor_A'+str(i));plan.add_patch(rod)
        draw_plan_welds(plan,c)
        plan.plot([0,0],[-L/2,L/2],color=INK,lw=.5,ls='-.',gid='cw_x_centerline')
        plan.plot([-B/2,B/2],[0,0],color=INK,lw=.5,ls='-.',gid='cw_y_centerline')
        if _positive(u.flange_length):
            dim(plan,-u.flange_length/2,L/2+m*.65,u.flange_length/2,L/2+m*.65,
                f'Lmesa físico={u.flange_length:g}')
        if _positive(u.flange_effective_length):
            dim(plan,-u.flange_effective_length/2,-L/2-m*.7,u.flange_effective_length/2,-L/2-m*.7,
                f'Lmesa efetivo={u.flange_effective_length:g}',FLANGE)
        if _positive(u.web_length):
            dim(plan,-B/2-m*.65,-u.web_length/2,-B/2-m*.65,u.web_length/2,
                f'Lalma físico={u.web_length:g}')
        if _positive(u.web_effective_length):
            dim(plan,B/2+m*.65,-u.web_effective_length/2,B/2+m*.65,u.web_effective_length/2,
                f'Lalma efetivo={u.web_effective_length:g}',WEB)
        origin=(-B/2, -L/2-m*1.35)
        arrow(plan,origin,(origin[0]+m*.7,origin[1]),'cw_plan_y_axis')
        arrow(plan,origin,(origin[0],origin[1]+m*.7),'cw_plan_x_axis')
        text(plan,origin[0]+m*.8,origin[1],'+y',va='center')
        text(plan,origin[0],origin[1]+m*.83,'+x',ha='center')
        plan.set_xlim(-B/2-m*1.35,B/2+m*1.35)
        plan.set_ylim(-L/2-m*1.85,L/2+m*1.15)

        section.set_title('CORTE x–z · PLANOS DE TRANSFERÊNCIA NORMAL',loc='left',fontsize=11,fontweight='bold',color=INK)
        hcol=max(p.d*.45,c.tp*5,100.)
        rect(section,-L/2,0,L,c.tp,PLATE,'cw_plate_xz')
        rect(section,-p.d/2,c.tp,p.d,hcol,'#eef1f2','cw_column_xz')
        rect(section,-p.d/2,c.tp,p.tf,hcol,COLUMN,'cw_left_flange_xz')
        rect(section,p.d/2-p.tf,c.tp,p.tf,hcol,COLUMN,'cw_right_flange_xz')
        hf=p.d if c.weld_flange_type=='fillet' else p.d-p.tf
        if c.weld_flange_type in ('fillet','cjp'):
            for name,sign in (('left',-1),('right',1)):
                x=sign*hf/2
                section.plot([x,x],[0,c.tp+hcol*.88],color=FLANGE,lw=.7,ls='--',gid='cw_'+name+'_transfer_plane')
                if c.weld_flange_type=='fillet':
                    from .base_plate_details import fillet_dimensions
                    leg=fillet_dimensions(c.weld_flange_size,c.weld_flange_measure)['leg']
                    poly(section,[(x,c.tp),(x+sign*leg,c.tp),(x,c.tp+leg)],FLANGE,'cw_'+name+'_exterior_fillet_xz')
                else:
                    rect(section,x-p.tf/2,c.tp-min(c.tp,p.tf)*.15,p.tf,min(c.tp,p.tf)*.3,
                         FLANGE,'cw_'+name+'_single_cjp_xz')
                force=out.get('F_'+name+'_N')
                if type(force) in (int,float) and math.isfinite(force):
                    low=c.tp+hcol*.20;high=c.tp+hcol*.63
                    if force>0:arrow(section,(x,high),(x,low),'cw_'+name+'_normal_force',FLANGE)
                    elif force<0:arrow(section,(x,low),(x,high),'cw_'+name+'_normal_force',FLANGE)
                    # The force arrow stays on its true transfer plane. Values
                    # sit inward from each flange, with a fixed display-space gap.
                    label_x=-p.d/2+p.tf if sign<0 else p.d/2-p.tf
                    section.annotate(('FL' if sign<0 else 'FR')+'='+_number(force/1000)+' kN',
                                     xy=(label_x,c.tp+hcol*.82),xytext=(-sign*5,0),
                                     textcoords='offset points',fontsize=10,color=INK,
                                     ha='left' if sign<0 else 'right',va='bottom')
            text(section,-hf/2,-m*.23,f'xL={-hf/2:g}',ha='center',va='top')
            text(section,hf/2,-m*.23,f'xR={hf/2:g}',ha='center',va='top')
            dim(section,-hf/2,-m*.65,hf/2,-m*.65,f'h={hf:g} mm; '+('h=d' if c.weld_flange_type=='fillet' else 'h=d−tf'),FLANGE)
        text(section,0,c.tp+hcol*1.13,'Forças na interface do pilar: F>0 tração; F<0 compressão',ha='center')
        text(section,0,-m*1.35,'z=tp: face superior. Sem M+V·e da chave inferior.',ha='center')
        if out.get('normal_transfer_applied')=='fit_bearing':
            arrow(section,(0,c.tp+hcol*.1),(0,c.tp+hcol*.65),'cw_bearing_force','#427547')
            text(section,0,c.tp+hcol*.72,'Contato='+_number(out.get('bearing_force_N',0)/1000)+' kN',ha='center')
        axis=(L/2-m*.3,c.tp+hcol*.45)
        arrow(section,axis,(axis[0]+m*.6,axis[1]),'cw_section_x_axis')
        arrow(section,axis,(axis[0],axis[1]+m*.6),'cw_section_z_axis')
        text(section,axis[0]+m*.7,axis[1],'+x',va='center')
        text(section,axis[0],axis[1]+m*.7,'+z',ha='center')
        section.set_xlim(-L/2-m*.55,L/2+m*.8)
        section.set_ylim(-m*1.7,c.tp+hcol*1.32)

        web.set_title('CORTE LOCAL y–z · JUNTA DA ALMA',loc='left',fontsize=11,fontweight='bold',color=INK)
        from .base_plate_details import fillet_dimensions
        leg=fillet_dimensions(c.weld_web_size,c.weld_web_measure)['leg'] if c.weld_web_type=='fillet' else p.tw
        span=max(p.tw*3,leg*5,25.);height=span*.75
        rect(web,-span/2,-span*.25,span,span*.25,PLATE,'cw_web_plate_yz')
        rect(web,-p.tw/2,0,p.tw,height,COLUMN,'cw_web_material_yz')
        if c.weld_web_type=='fillet':
            for sign,name in ((-1,'negative_y'),(1,'positive_y')):
                y=sign*p.tw/2
                poly(web,[(y,0),(y+sign*leg,0),(y,leg)],WEB,'cw_web_'+name+'_fillet_yz')
            label='Dois filetes: V/2 por face; N da alma=0'
        elif c.weld_web_type=='cjp':
            rect(web,-p.tw/2,-min(p.tw,c.tp)*.15,p.tw,min(p.tw,c.tp)*.3,WEB,'cw_web_single_cjp_yz')
            label='Uma seção CJP da alma: V integral; N da alma=0'
        else:label='Junta da alma não especificada; sem topologia presumida'
        text(web,0,-span*.43,label,ha='center')
        text(web,0,-span*.64,'Detalhe local ampliado; +y à direita e +z acima.',ha='center')
        value=out.get('V_input_N',getattr(c,'V',0.))
        if type(value) in (int,float) and math.isfinite(value) and value!=0:
            center=(span*.37,height*.65);rad=span*.06
            circle=Circle(center,rad,facecolor='white',edgecolor=WEB,lw=1.4);circle.set_gid('cw_web_shear_direction');web.add_patch(circle)
            if value>0:
                dot=Circle(center,rad*.22,facecolor=WEB,edgecolor=WEB);dot.set_gid('cw_web_shear_positive_dot');web.add_patch(dot)
            else:
                for k in (-1,1):web.plot([center[0]-rad*.6,center[0]+rad*.6],[center[1]-k*rad*.6,center[1]+k*rad*.6],color=WEB,lw=1.1,gid='cw_web_shear_negative_cross_'+str(k))
            text(web,center[0],center[1]+rad*1.7,'V +x sai' if value>0 else 'V −x entra',ha='center')
        web.set_xlim(-span*.9,span*.9);web.set_ylim(-span*.8,height*1.4)

        audit.set_title('AUDITORIA COM SINAIS · FACE SUPERIOR',loc='left',fontsize=11,fontweight='bold',color=INK)
        lines=[
            f'N={_number(out.get("N_input_N"),2)} N; M={_number(out.get("M_input_Nmm"),2)} N·mm; V={_number(out.get("V_input_N"),2)} N',
            'ΣF=−N: '+_number(out.get('normal_resultant_N'))+' N',
            'ΣxF=M: '+_number(out.get('moment_resultant_Nmm'))+' N·mm',
            'ΣV=V: '+_number(out.get('shear_resultant_N'))+' N',
            'Resíduos N/M/V: '+', '.join(_number(out.get(key),6) for key in ('residual_N_N','residual_M_Nmm','residual_V_N')),
            'Numérico: '+{'pass':'ATENDE','fail':'NÃO ATENDE'}.get(out.get('numerical_status'),'PENDENTE')+' | Qualificação: '+{'qualified':'registro vinculado','stale':'INVALIDADA','missing':'PENDENTE'}.get(out.get('qualification_status'),'PENDENTE'),
            'Componente: '+{'pass':'ATENDE CONDICIONAL','fail':'NÃO ATENDE'}.get(out.get('status'),'PENDENTE'),
            'Registro: '+shorten(u.transfer_ref or 'não informado',width=65,placeholder='…'),
            'Assinatura: '+('ATUAL' if out.get('qualification_binding_kind') in ('current','legacy_current') else 'AUSENTE OU INVALIDADA'),
            'Base completa e rigidez: A COMPLEMENTAR.',
            'Cinza: físico; laranja: mesa efetiva; azul: alma efetiva.',
            'Setas indicam sentido, sem escala de força. Linhas: espessura gráfica.',
            'Contato preparado só alivia N puro quando qualificado.',
        ]
        for i,line in enumerate(lines):
            audit.text(0.,.96-i*.073,line,transform=audit.transAxes,color=INK,fontsize=9,va='top')
        buffer=BytesIO();fig.savefig(buffer,format=fmt,dpi=180,facecolor='white');plt.close(fig)
        return buffer.getvalue()
