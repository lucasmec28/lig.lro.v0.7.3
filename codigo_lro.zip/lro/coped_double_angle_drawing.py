"""Native R017 views of a double-coped beam bolted to a girder web.

Drawing coordinates: x follows the supported beam, y is upward, z follows
its transverse direction (and the girder span). The near girder WEB face
is x=0 and the one physical support web occupies -tw_support <= x <= 0.
The separate calculation's reaction coordinate frame is not changed here.
All geometry comes from the input. No capacity result can move an edge.
"""
from .display_precision import display_format, display_value
from io import BytesIO
from math import isfinite, sqrt

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.path import Path
from matplotlib.patches import Circle, PathPatch, Rectangle
from matplotlib.transforms import Affine2D

from .angle_catalog_selection import add_drawing_provenance
from .coped_double_angle import evaluate
from .drawing_annotations import dimension

INK = '#263746'
MEMBER = '#dce2e7'
ANGLE1 = '#76aeba'
ANGLE2 = '#e5b978'
MUTED = '#677783'
RED = '#a52b32'

STATUS = {
    'SEM AVALIAÇÃO': 'SEM AVALIAÇÃO',
    'INVALID_INPUT': 'DADOS INVÁLIDOS',
    'NUMERICAL_FAILURE': 'FALHA NUMÉRICA NA AVALIAÇÃO',
    'INVALID_GEOMETRY': 'GEOMETRIA INVÁLIDA',
    'OUTSIDE_R017_SCOPE': 'FORA DO DOMÍNIO R017',
    'DETAIL_FAIL': 'DETALHAMENTO NÃO ATENDIDO',
    'VERIFIED_SUBCHECK_FAIL': 'HÁ VERIFICAÇÃO NÃO ATENDIDA',
    'ENGINEERING_MODEL_PENDING': 'VERIFICAÇÃO COMPLEMENTAR PENDENTE',
    'COMPLETE_LOCAL_CHECKS_PASS_WITHIN_SCOPE': 'VERIFICAÇÕES LOCAIS ATENDIDAS NO DOMÍNIO R017',
    'COMPLETE_LOCAL_CHECKS_PASS_WITH_PRESET_DEVIATION': 'ATENDIMENTO LOCAL COM DESVIO DO PADRÃO',
}


def _dimensions(c):
    positive = (c.beam.d, c.beam.bf, c.beam.tw, c.beam.tf, c.support.d,
        c.support.bf, c.support.tw, c.support.tf, c.support.clear, c.beam_leg, c.support_leg,
        c.t, c.length, c.beam_gauge, c.support_gauge, c.web_pitch,
        c.support_pitch, c.web_end_top, c.support_end_top, c.hole_diameter,
        c.db, c.c_top, c.c_bottom, c.dc_top, c.dc_bottom, c.r_top, c.r_bottom)
    if any(isinstance(v, bool) or not isinstance(v, (int, float)) or not isfinite(v) or v <= 0 for v in positive):
        raise ValueError('O desenho R017 exige dimensões positivas e finitas.')
    for value in (c.gap, c.angle_top, c.root_radius):
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not isfinite(value) or value < 0:
            raise ValueError('Folga, posição e raio da cantoneira devem ser finitos e não negativos.')
    for count in (c.angle_count, c.web_rows, c.support_rows, c.web_columns, c.support_columns):
        if type(count) is not int or not 1 <= count <= 20:
            raise ValueError('O desenho R017 exige contagens inteiras entre 1 e 20.')
    for value in (c.V, c.beam_level):
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not isfinite(value):
            raise ValueError('V e desnível devem ser finitos.')


def validated_result(c, r=None):
    """Evaluate current input; a supplied result is never export authority.

    The optional argument is retained for caller compatibility only. Even a
    matching input snapshot cannot authenticate supplied checks or conclusions.
    """
    return evaluate(c)


def _approved(r):
    """Local connection approval only; member-wide approval is always external."""
    checks = r.get('checks')
    issues = r.get('issues', [])
    return (isinstance(r.get('inputs'), dict) and r.get('local_pass') is True
        and r.get('status') in ('COMPLETE_LOCAL_CHECKS_PASS_WITHIN_SCOPE', 'COMPLETE_LOCAL_CHECKS_PASS_WITH_PRESET_DEVIATION')
        and isinstance(r.get('geometry'), dict) and r['geometry'].get('valid') is True
        and isinstance(r.get('summary'), dict) and r['summary'].get('complete_checks') is True
        and isinstance(checks, list) and bool(checks)
        and all(isinstance(x, dict) and x.get('status') == 'PASS' for x in checks)
        and isinstance(issues, list)
        and not any(not isinstance(x, dict) or x.get('severity') in {
            'engineering_pending', 'unsupported_scope', 'invalid_input', 'invalid_geometry', 'numerical_failure',
            'detail_fail', 'error', 'pending', 'access_pending', 'not_evaluated'} for x in issues))


def _arc(cx, cy, radius, start, end):
    return Affine2D().scale(radius).translate(cx, cy).transform_path(Path.arc(start, end))


def _cope_geometry(c):
    """Actual tangent quarter circles, with cope length to the rear cut face."""
    top, bottom = c.beam.d / 2, -c.beam.d / 2
    xt, xb = c.gap + c.c_top, c.gap + c.c_bottom
    yt, yb = top - c.dc_top, bottom + c.dc_bottom
    top_arc = _arc(xt-c.r_top, yt+c.r_top, c.r_top, 270, 360)
    bottom_arc = _arc(xb-c.r_bottom, yb-c.r_bottom, c.r_bottom, 0, 90)
    return top, bottom, xt, xb, yt, yb, top_arc, bottom_arc


def _beam_path(c, stub):
    top, bottom, xt, xb, yt, yb, top_arc, bottom_arc = _cope_geometry(c)
    vertices = [(c.gap, yt), tuple(top_arc.vertices[0])]
    codes = [Path.MOVETO, Path.LINETO]
    vertices.extend(top_arc.vertices[1:]); codes.extend(top_arc.codes[1:])
    vertices.extend([(xt, top), (stub, top), (stub, bottom), (xb, bottom), tuple(bottom_arc.vertices[0])])
    codes.extend([Path.LINETO] * 5)
    vertices.extend(bottom_arc.vertices[1:]); codes.extend(bottom_arc.codes[1:])
    vertices.extend([(c.gap, yb), (c.gap, yt)])
    codes.extend([Path.LINETO, Path.CLOSEPOLY])
    return Path(vertices, codes)


def _angle_path(c, sign):
    z0 = c.beam.tw / 2
    b, s, t, rr = c.beam_leg, c.support_leg, c.t, c.root_radius
    vertices = [(0, z0), (b, z0), (b, z0+t), (t+rr, z0+t)]
    codes = [Path.MOVETO, Path.LINETO, Path.LINETO, Path.LINETO]
    if rr:
        arc = _arc(t+rr, z0+t+rr, rr, 180, 270)
        # Reverse the arc to run from the horizontal beam leg to the support leg.
        vertices.extend(arc.vertices[-2::-1]); codes.extend([Path.CURVE4] * (len(arc.vertices)-1))
    else:
        vertices.append((t, z0+t)); codes.append(Path.LINETO)
    vertices.extend([(t, z0+s), (0, z0+s), (0, z0)])
    codes.extend([Path.LINETO, Path.LINETO, Path.CLOSEPOLY])
    return Path([(x, sign*z) for x, z in vertices], codes)


def _figure(c, r=None):
    _dimensions(c)
    r = validated_result(c, r)
    topology = (c.angle_count == 2 and c.symmetric is True and c.kind == 'beam_web'
        and c.web_columns == 1 and c.support_columns == 1
        and c.support_intact is True and c.cope == 'equal_double')
    impossible = (c.dc_top+c.dc_bottom >= c.beam.d
        or c.r_top > min(c.c_top, c.dc_top) or c.r_bottom > min(c.c_bottom, c.dc_bottom)
        or c.t+c.root_radius >= min(c.beam_leg, c.support_leg)
        or c.beam.d <= 2*c.beam.tf or c.support.d <= 2*c.support.tf)
    fig = plt.figure(figsize=(15, 11.5), facecolor='white')
    fig.text(.035, .977, 'LIGAÇÃO R017  |  VIGA COM RECORTES SUPERIOR E INFERIOR', fontsize=17, fontweight='bold', color=INK)
    fig.text(.035, .955, 'Projeto: ' + str(c.project), fontsize=9.5, color=INK)
    fig.text(.035, .935, f'Viga {display_value(c.beam.name)}  →  alma da viga de apoio {display_value(c.support.name)}', fontsize=10.5, color=INK)
    status = str(r.get('status', 'SEM AVALIAÇÃO'))
    accepted = _approved(r) and topology and not impossible
    status_text = STATUS.get(status, 'ESTADO NÃO RECONHECIDO')
    # A bare or inconsistent status string must not read as a verified result.
    if status.startswith('COMPLETE_') and not accepted:
        status_text = 'ATENDIMENTO LOCAL NÃO VALIDADO'
    label = fig.text(.965, .914, status_text, ha='right', fontsize=8.6, color=INK if accepted else RED)
    label.set_gid('engine_status_' + status)
    fig.text(.035, .914, 'ATENDIMENTO LOCAL R017' if accepted else 'SEM APROVAÇÃO LOCAL', fontsize=8.8, color=INK if accepted else RED)
    fig.text(.035, .897, 'VERIFICAÇÃO GLOBAL DOS MEMBROS EXTERNA À LIGAÇÃO', fontsize=8.8, color=MUTED)

    fig.text(.035, .076, f"Ações reais informadas: V={display_format(c.V, '+.12g')} N; N={display_format(c.N, '+.12g')} N; M={display_format(c.M, '+.12g')} N mm; T={display_format(c.torsion, '+.12g')} N mm.", fontsize=8.5, color=INK)
    fig.text(.035, .053, 'Hipótese do modelo local: somente V estático; N=M=T=0; recortes iguais. Contenção lateral exige comprovação externa.', fontsize=9.1, color=INK)

    if not topology or impossible:
        fig.text(.06, .77, 'TOPOLOGIA NÃO REPRESENTADA' if not topology else 'GEOMETRIA NÃO REPRESENTADA', fontsize=18, color=RED, fontweight='bold')
        fig.text(.06, .66, f"Entrada preservada: {display_value(c.angle_count)} cantoneira(s); simetria={display_value(c.symmetric)}; apoio={display_value(c.kind)}.\nColunas na alma={display_value(c.web_columns)}; colunas por aba de apoio={display_value(c.support_columns)}.\nAlma do apoio íntegra={display_value(c.support_intact)}; tipo de recorte={display_value(c.cope)}.\nRecortes superior/inferior: c={display_format(c.c_top, 'g')}/{display_format(c.c_bottom, 'g')}; dc={display_format(c.dc_top, 'g')}/{display_format(c.dc_bottom, 'g')}; R={display_format(c.r_top, 'g')}/{display_format(c.r_bottom, 'g')} mm.\nA representação exige dois L simétricos, uma coluna de parafusos por interface\nem apoio íntegro, com recortes circulares possíveis. Esta entrada exige detalhe próprio.",
            fontsize=12, color=INK, linespacing=1.8)
        fig.text(.06, .41, f"Abas viga/apoio={display_format(c.beam_leg, 'g')}/{display_format(c.support_leg, 'g')}; t={display_format(c.t, 'g')}; L={display_format(c.length, 'g')} mm.\nGabaritos viga/apoio={display_format(c.beam_gauge, 'g')}/{display_format(c.support_gauge, 'g')} mm; V={display_format(c.V / 1000, 'g')} kN.", fontsize=12, color=INK, linespacing=1.8)
        fig.text(.035, .030, 'Entrada não corrigida nem substituída por outra topologia. Não libera fabricação.', fontsize=10, color=RED)
        return add_drawing_provenance(fig, c)

    elev = fig.add_axes((.035, .480, .49, .375))
    front = fig.add_axes((.590, .470, .375, .385))
    plan = fig.add_axes((.035, .108, .53, .285))
    for ax in (elev, front, plan):
        ax.set_aspect('equal'); ax.axis('off')

    def rect(ax, x, y, w, h, color, gid=None, **kw):
        patch = Rectangle((x, y), w, h, facecolor=color,
            edgecolor=kw.pop('edgecolor', INK), lw=kw.pop('lw', .8), **kw)
        patch.set_gid(gid); ax.add_patch(patch); return patch

    def path(ax, shape, color, gid, **kw):
        patch = PathPatch(shape, facecolor=color, edgecolor=INK, lw=.85, **kw)
        patch.set_gid(gid); ax.add_patch(patch); return patch

    def line(ax, xs, ys, gid=None, **kw):
        item, = ax.plot(xs, ys, color=kw.pop('color', INK), lw=kw.pop('lw', .8), **kw)
        item.set_gid(gid); return item

    def hole(ax, x, y, gid):
        patch = Circle((x, y), c.hole_diameter/2, facecolor='white', edgecolor=INK, lw=.8)
        patch.set_gid(gid); ax.add_patch(patch)
        d = c.hole_diameter*.20
        line(ax, [x-d, x+d], [y, y], lw=.4)
        line(ax, [x, x], [y-d, y+d], lw=.4)

    def dim(ax, x1, y1, x2, y2, label, gid=None, short_side=None):
        arrow, text = dimension(ax, (x1,y1), (x2,y2), label, fontsize=8,
            rotation=90 if x1 == x2 else 0, color=INK, pad=1, lw=.65,
            short_side=(-1 if x1 == x2 else 1) if short_side is None else short_side)
        arrow.set_gid(gid)
        return arrow, text

    def leader(ax, label, xy, text, ha='left', color=INK, connectionstyle='arc3'):
        return ax.annotate(label, xy=xy, xytext=text, ha=ha, va='center', fontsize=8.2, color=color,
            arrowprops={'arrowstyle': '-', 'lw': .6, 'color': color, 'connectionstyle': connectionstyle},
            bbox={'facecolor': 'white', 'edgecolor': 'none', 'pad': 1})

    def title(ax, label):
        ax.set_title(label, loc='left', fontsize=10.6, fontweight='bold', color=INK, pad=12)

    def crop_vertical(ax, x, low, high, gid):
        mid = (low+high)/2
        line(ax, [x, x, x-4, x+4, x, x], [low, mid-11, mid-5, mid+5, mid+11, high], gid, color=MUTED, lw=.9)

    top, bottom, xt, xb, yt, yb, top_arc, bottom_arc = _cope_geometry(c)
    angle_top = top-c.angle_top
    angle_bottom = angle_top-c.length
    yw = [angle_top-c.web_end_top-i*c.web_pitch for i in range(c.web_rows)]
    ys = [angle_top-c.support_end_top-i*c.support_pitch for i in range(c.support_rows)]
    support_top = top+c.beam_level
    support_bottom = support_top-c.support.d
    flange_left = -(c.support.bf+c.support.tw)/2
    flange_right = (c.support.bf-c.support.tw)/2
    z0 = c.beam.tw/2
    zs = z0+c.support_gauge
    span = max(c.support.bf*.85, z0+c.support_leg+65, c.beam.bf*.6+35)
    stub = max(xt, xb, c.beam_leg)+max(110, c.beam.d*.27)
    upper = max(top, support_top, angle_top)
    lower = min(bottom, support_bottom, angle_bottom)

    title(elev, 'A  ELEVAÇÃO NA ALMA DA VIGA RECORTADA')
    rect(elev, -c.support.tw, support_bottom+c.support.tf, c.support.tw,
        c.support.d-2*c.support.tf, MEMBER, 'support_web_elevation')
    for suffix, y in (('top', support_top-c.support.tf), ('bottom', support_bottom)):
        rect(elev, flange_left, y, c.support.bf, c.support.tf, MEMBER, 'support_'+suffix+'_flange_elevation')
    path(elev, _beam_path(c, stub), '#eef1f4', 'beam_coped_web_elevation')
    for suffix, start, y in (('top', xt, top-c.beam.tf), ('bottom', xb, bottom)):
        rect(elev, start, y, stub-start, c.beam.tf, MEMBER, 'beam_'+suffix+'_flange_elevation')
    path(elev, top_arc, 'none', 'cope_top_radius_elevation')
    path(elev, bottom_arc, 'none', 'cope_bottom_radius_elevation')
    rect(elev, 0, angle_bottom, c.beam_leg, c.length, ANGLE1, 'angle_A1_elevation', alpha=.88)
    rect(elev, 0, angle_bottom, c.beam_leg, c.length, 'none', 'angle_A2_elevation', linestyle='--')
    for i, y in enumerate(yw):
        hole(elev, c.beam_gauge, y, f'web_hole_elevation_{display_value(i)}')
    for i, y in enumerate(ys):
        line(elev, [-c.support.tw-8, c.t+8], [y, y], f'support_bolt_elevation_{display_value(i)}', lw=2)
    dim(elev, c.gap, upper+29, xt, upper+29, f"c sup = {display_format(c.c_top, 'g')}", 'dimension_cope_top_length')
    dim(elev, c.gap, lower-30, xb, lower-30, f"c inf = {display_format(c.c_bottom, 'g')}", 'dimension_cope_bottom_length')
    dim(elev, xt+23, yt, xt+23, top, f"dc {display_format(c.dc_top, 'g')}", 'dimension_cope_top_depth')
    dim(elev, xb+23, bottom, xb+23, yb, f"dc {display_format(c.dc_bottom, 'g')}", 'dimension_cope_bottom_depth')
    dim(elev, stub+27, angle_bottom, stub+27, angle_top, f"L = {display_format(c.length, 'g')}", 'dimension_angle_length')
    if c.web_rows > 1:
        dim(elev, c.beam_leg+24, yw[1], c.beam_leg+24, yw[0], f"p = {display_format(c.web_pitch, 'g')}", 'dimension_web_pitch')
    offset_t = c.r_top/sqrt(2)
    offset_b = c.r_bottom/sqrt(2)
    leader(elev, f"R{display_format(c.r_top, 'g')}", (xt-c.r_top+offset_t, yt+c.r_top-offset_t), (xt+60, yt-30), connectionstyle='angle,angleA=180,angleB=-90,rad=0')
    leader(elev, f"R{display_format(c.r_bottom, 'g')}", (xb-c.r_bottom+offset_b, yb-c.r_bottom+offset_b), (xb+60, yb+30), connectionstyle='angle,angleA=180,angleB=90,rad=0')
    leader(elev, f"Folga = {display_format(c.gap, 'g')}", (c.gap/2, yb+15), (flange_left-5, lower-29), ha='right')
    leader(elev, 'Alma do apoio', (-c.support.tw/2, (ys[0]+ys[-1])/2), (flange_left-8, (ys[0]+ys[-1])/2+40), ha='right')
    elev.text(flange_left, upper+10, 'Seção da viga de apoio', fontsize=8, color=MUTED)
    arrow_x = stub-25
    ym = (angle_top+angle_bottom)/2
    if c.V:
        direction = -1 if c.V > 0 else 1
        arrow = elev.annotate('', (arrow_x, ym+direction*47), (arrow_x, ym-direction*27),
            arrowprops={'arrowstyle': '-|>', 'lw': 1.8, 'color': RED, 'mutation_scale': 14})
        arrow.set_gid('load_V_positive_down' if c.V > 0 else 'load_V_negative_up')
    elev.text(arrow_x-10, ym, f"V = {display_format(c.V / 1000, 'g')}\nkN", fontsize=9, color=RED, va='center', ha='right')
    elev.set_xlim(flange_left-115, stub+65)
    elev.set_ylim(lower-58, upper+57)

    title(front, 'B  ELEVAÇÃO NA ALMA DA VIGA DE APOIO')
    # The drawn girder span is cropped, not bounded by fictional free edges.
    rect(front, -span, support_bottom+c.support.tf, 2*span, c.support.d-2*c.support.tf,
        MEMBER, 'support_web_front', edgecolor='none', alpha=.52)
    for suffix, y in (('top', support_top-c.support.tf), ('bottom', support_bottom)):
        rect(front, -span, y, 2*span, c.support.tf, MEMBER,
            'support_'+suffix+'_flange_front', edgecolor='none')
        for edge, yy in (('outer', y), ('inner', y+c.support.tf)):
            line(front, [-span, span], [yy, yy], f'support_{display_value(suffix)}_flange_{display_value(edge)}_continuous')
    # Catalogued straight-web limits are root envelopes, never cut/free edges.
    support_mid = (support_top+support_bottom)/2
    for suffix, y in (('top', support_mid+c.support.clear/2), ('bottom', support_mid-c.support.clear/2)):
        line(front, [-span, span], [y, y], 'support_root_envelope_'+suffix, ls=':', color=MUTED, lw=.65)
    for side, x in (('left', -span), ('right', span)):
        crop_vertical(front, x, support_bottom, support_top, 'support_span_crop_'+side)
    for sign, code, color in ((-1, 'A1', ANGLE1), (1, 'A2', ANGLE2)):
        x = -z0-c.support_leg if sign < 0 else z0
        rect(front, x, angle_bottom, c.support_leg, c.length, color, f'angle_{display_value(code)}_support_front')
        for i, y in enumerate(ys):
            hole(front, sign*zs, y, f'support_hole_{display_value(code)}_{display_value(i)}')
    rect(front, -z0, yb, c.beam.tw, yt-yb, '#eef1f4', 'beam_coped_end_front')
    for i, y in enumerate(yw):
        line(front, [-z0-c.t-8, z0+c.t+8], [y, y], f'shared_web_bolt_front_{display_value(i)}', lw=1.8)
    dim(front, -zs, upper+30, zs, upper+30, f"2 linhas: {display_format(2 * zs, 'g')}", 'dimension_support_columns')
    if c.support_rows > 1:
        dim(front, z0+c.support_leg+25, ys[1], z0+c.support_leg+25, ys[0], f"p = {display_format(c.support_pitch, 'g')}", 'dimension_support_pitch')
    dim(front, -z0, lower-29, -zs, lower-29, f"g apoio = {display_format(c.support_gauge, 'g')}", 'dimension_support_gauge', short_side=-1)
    if c.beam_level:
        dim(front, span+28, top, span+28, support_top, f"nível = {display_format(c.beam_level, 'g')}", 'dimension_beam_level')
    front.text(0, lower-54, 'Mesas contínuas; comprimento do apoio interrompido.', fontsize=8.2, color=MUTED, ha='center')
    front.set_xlim(-span-35, span+65)
    front.text(0, lower-70, 'Pontilhado: limites da alma reta; não são cortes.', fontsize=8, color=MUTED, ha='center')
    front.set_ylim(lower-85, upper+57)

    title(plan, 'C  PLANTA NA REGIÃO DOS PARAFUSOS')
    # Girder flanges are outside the section. Show only their real footprint.
    rect(plan, flange_left, -span, c.support.bf, 2*span, MEMBER,
        'support_flange_footprint_plan', edgecolor='none', alpha=.17)
    for suffix, x in (('far', flange_left), ('near', flange_right)):
        line(plan, [x, x], [-span, span], 'support_flange_footprint_'+suffix, ls='--', color=MUTED)
    rect(plan, -c.support.tw, -span, c.support.tw, 2*span, MEMBER,
        'support_web_plan', edgecolor='none')
    for suffix, x in (('back', -c.support.tw), ('contact', 0)):
        line(plan, [x, x], [-span, span], 'support_web_'+suffix+'_plan', lw=1.)
    for side, z in (('low', -span), ('high', span)):
        line(plan, [-c.support.tw, -c.support.tw*.70, -c.support.tw*.50, -c.support.tw*.30, 0],
            [z, z, z+4, z, z], 'support_web_crop_'+side, color=MUTED)
    for suffix, start in (('top', xt), ('bottom', xb)):
        rect(plan, start, -c.beam.bf/2, stub-start, c.beam.bf, 'none',
            'beam_'+suffix+'_flange_footprint_plan', edgecolor=MUTED, linestyle='--', alpha=.6)
    rect(plan, c.gap, -z0, stub-c.gap, c.beam.tw, MEMBER, 'beam_web_plan')
    slice_y = yw[0]
    same_level = any(abs(y-slice_y) < 1e-8 for y in ys)
    for sign, code, color in ((-1, 'A1', ANGLE1), (1, 'A2', ANGLE2)):
        path(plan, _angle_path(c, sign), color, f'angle_{display_value(code)}_L_plan')
        style = '-' if same_level else '--'
        line(plan, [-c.support.tw-8, c.t+8], [sign*zs, sign*zs], f'support_bolt_{display_value(code)}_plan', lw=2, ls=style)
        rect(plan, -c.support.tw-8, sign*zs-c.db*.35, 5, c.db*.7, INK, f'support_head_{display_value(code)}_plan')
        line(plan, [0, 0], [sign*zs-c.db*.5, sign*zs+c.db*.5], f'support_shear_plane_{display_value(code)}', color=RED, lw=2)
        leader(plan, code, (c.beam_leg*.78, sign*(z0+c.t/2)), (c.beam_leg+35, sign*52))
    line(plan, [c.beam_gauge, c.beam_gauge], [-z0-c.t-8, z0+c.t+8], 'shared_web_bolt_plan', lw=2)
    for sign in (-1, 1):
        rect(plan, c.beam_gauge-c.db*.35, sign*(z0+c.t+5)-2, c.db*.7, 4, INK, f'web_bolt_head_{display_value(sign)}_plan')
        line(plan, [c.beam_gauge-9, c.beam_gauge+9], [sign*z0, sign*z0], f'web_shear_plane_{display_value(sign)}', color=RED, lw=2)
    dim(plan, 0, -span-24, c.beam_gauge, -span-24, f"g viga = {display_format(c.beam_gauge, 'g')}", 'dimension_beam_gauge', short_side=-1)
    # Parallel short labels need their own rails; measured x spans are unchanged.
    dim(plan, 0, -span-70, c.beam_leg, -span-70, f"b viga = {display_format(c.beam_leg, 'g')}", 'dimension_beam_leg', short_side=-1)
    dim(plan, stub+24, z0, stub+24, z0+c.support_leg, f"b apoio = {display_format(c.support_leg, 'g')}", 'dimension_support_leg')
    leader(plan, f"Alma do apoio tw = {display_format(c.support.tw, 'g')}", (-c.support.tw/2, span*.60), (flange_left-12, span+31))
    leader(plan, 'Mesas do apoio (projeção)', (flange_right, span*.83), (flange_right+18, span+31))
    leader(plan, 'Mesas da viga após os recortes', (max(xt, xb)+20, c.beam.bf/2), (max(xt, xb)+26, span-28))
    leader(plan, 'Parafuso comum: 2 planos', (c.beam_gauge, 0), (max(xt, xb)+30, -span+24),
        connectionstyle='angle,angleA=180,angleB=-90,rad=0')
    if not same_level:
        plan.text(0, -.035, 'Apoio tracejado: parafusos projetados de outra cota.',
            transform=plan.transAxes, fontsize=8, color=MUTED)
    plan.set_xlim(flange_left-30, stub+110)
    plan.set_ylim(-span-137, span+53)
    # Add annotation space without reducing the original plan display scale.
    plan.set_position((.035, .108, .53, .285*(2*span+190)/(2*span+136)))

    web_bottom = c.length-c.web_end_top-(c.web_rows-1)*c.web_pitch
    support_end_bottom = c.length-c.support_end_top-(c.support_rows-1)*c.support_pitch
    notes = [
        f"2 peças L {display_format(c.beam_leg, 'g')} × {display_format(c.support_leg, 'g')} × {display_format(c.t, 'g')}; L = {display_format(c.length, 'g')} mm.",
        f'Alma da viga: {display_value(c.web_rows)} parafusos comuns, 2 planos de corte.',
        f'Alma do apoio: 2 × {display_value(c.support_rows)} parafusos, 1 plano por parafuso.',
        f"Ø parafuso {display_format(c.db, 'g')}; Ø furo físico {display_format(c.hole_diameter, 'g')} mm.",
        f"Bordas da cantoneira, viga: {display_format(c.web_end_top, 'g')} / {display_format(web_bottom, 'g')} mm.",
        f"Bordas da cantoneira, apoio: {display_format(c.support_end_top, 'g')} / {display_format(support_end_bottom, 'g')} mm.",
        f"Topo da cantoneira a {display_format(c.angle_top, 'g')} mm do topo da viga.",
        f"Recorte superior: c={display_format(c.c_top, 'g')}; dc={display_format(c.dc_top, 'g')}; R{display_format(c.r_top, 'g')} mm.",
        f"Recorte inferior: c={display_format(c.c_bottom, 'g')}; dc={display_format(c.dc_bottom, 'g')}; R{display_format(c.r_bottom, 'g')} mm.",
        f"Alma remanescente h0 = {display_format(c.beam.d - c.dc_top - c.dc_bottom, 'g')} mm.",
        f"Braços desde a face: {display_format(c.gap + c.c_top, 'g')} / {display_format(c.gap + c.c_bottom, 'g')} mm.",
        f"Espessuras físicas: tw viga={display_format(c.beam.tw, 'g')}; tw apoio={display_format(c.support.tw, 'g')} mm.",
        'Cada cantoneira recebe V/2; não define os esforços globais do apoio.',
        'Mesas contínuas do apoio não são bordas livres da alma.',
        'Cotas em mm. A1 azul; A2 ocre. Vermelho: V e planos de corte.',
    ]
    fig.text(.595, .398, 'GEOMETRIA E INTERFACES FÍSICAS', fontsize=10.5, fontweight='bold', color=INK)
    fig.text(.595, .375, '\n'.join(notes), fontsize=8.8, linespacing=1.58, va='top', color=INK)
    fig.text(.035, .030, 'Esquema dimensionado; não libera fabricação nem aprova os membros globais. Detalhe industrial R017, p. 20: raios R15.', fontsize=9.1, color=INK)
    return add_drawing_provenance(fig, c)


def image_bytes(c, r=None, fmt='png'):
    with plt.rc_context({'font.family': 'DejaVu Sans', 'font.size': 10, 'svg.fonttype': 'none'}):
        fig = _figure(c, r)
        try:
            out = BytesIO()
            fig.savefig(out, format=fmt, dpi=170, facecolor='white', metadata={'Creator': 'LRO R017 coped double angle'})
            return out.getvalue()
        finally:
            plt.close(fig)


def drawing_svg(c, r=None):
    return image_bytes(c, r, 'svg').decode('utf-8')
