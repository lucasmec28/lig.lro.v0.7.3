"""Actual bounded-rectangle geometry and supplemental nominal net-section screens.

No fixture values, stored results, continuum/contact claims or legacy section model.
Numerical extrema below are reproducible scalar searches, not interval certificates.
"""
from __future__ import annotations
import math

TOL = 1e-9


def point(c, u, v=0.):
    C, S = math.cos(math.radians(c.theta_deg)), math.sin(math.radians(c.theta_deg))
    return [c.center_s + u*C + v*S, c.center_n + u*S - v*C]


def ray_exit(c, start, direction):
    candidates = []
    for axis, bounds in [(0, [(-c.plate_width/2, 'left'), (c.plate_width/2, 'right')]),
                         (1, [(0., 'root'), (c.plate_height, 'top')])]:
        if abs(direction[axis]) < 1e-14:
            continue
        for end, edge in bounds:
            distance = (end-start[axis])/direction[axis]
            p = [start[j]+distance*direction[j] for j in (0, 1)]
            if distance >= -TOL and -c.plate_width/2-TOL <= p[0] <= c.plate_width/2+TOL and -TOL <= p[1] <= c.plate_height+TOL:
                candidates.append(dict(distance=max(0., distance), point=p, edge=edge))
    if not candidates:
        raise ValueError('Ray does not intersect the actual rectangle in its forward direction.')
    nearest = min(x['distance'] for x in candidates)
    tied = [x for x in candidates if abs(x['distance']-nearest) <= TOL]
    # A corner can be approached on its free side. Positive supported-root contact
    # is checked independently and is never erased by this display tie-break.
    result = dict(next((x for x in tied if x['edge'] != 'root'), tied[0]))
    result['edges'] = [x['edge'] for x in tied]
    return result


def transverse_chord(c, u):
    C, S = math.cos(math.radians(c.theta_deg)), math.sin(math.radians(c.theta_deg))
    p = point(c, u)
    return dict(left=ray_exit(c, p, [-S, C]), right=ray_exit(c, p, [S, -C]))


def root_contact_length(c, u, side):
    """Length of n=0 retained by {local_u>=u, local_v<=0 or >=0}."""
    C, S = math.cos(math.radians(c.theta_deg)), math.sin(math.radians(c.theta_deg))
    lo, hi = -c.plate_width/2, c.plate_width/2
    rhs = u+c.center_s*C+c.center_n*S
    if C > 1e-14:
        lo = max(lo, rhs/C)
    elif C < -1e-14:
        hi = min(hi, rhs/C)
    elif rhs > TOL:
        return 0.
    vzero = c.center_s-c.center_n*C/S
    if side == 'left':
        hi = min(hi, vzero)
    else:
        lo = max(lo, vzero)
    return max(0., hi-lo)


def section_properties(intervals, thickness):
    """Area, centroid and inertia of actual remaining 1-D segment union."""
    length = sum(b-a for a, b in intervals)
    if length <= 0:
        raise ValueError('Nonpositive net section.')
    first = sum((b*b-a*a)/2 for a, b in intervals)
    centroid = first/length
    inertia = thickness*sum(((b-centroid)**3-(a-centroid)**3)/3 for a, b in intervals)
    if inertia <= 0:
        raise ValueError('Nonpositive net inertia.')
    return thickness*length, centroid, inertia


def subtract_intervals(lo, hi, removed):
    remaining = []
    cursor = lo
    for a, b in sorted(removed):
        a, b = max(lo, a), min(hi, b)
        if b <= cursor:
            continue
        if a > cursor:
            remaining.append([cursor, a])
        cursor = max(cursor, b)
    if cursor < hi:
        remaining.append([cursor, hi])
    return remaining


def golden_extreme(fn, lo, hi, maximize=True):
    """Bounded scalar search. Caller splits geometric intervals and keeps endpoints."""
    ratio = (math.sqrt(5)-1)/2
    x, y = hi-ratio*(hi-lo), lo+ratio*(hi-lo)
    sx = -1. if maximize else 1.
    fx, fy = sx*fn(x), sx*fn(y)
    for _ in range(55):
        if hi-lo <= 2e-10*max(1., abs(lo), abs(hi)):
            break
        if fx < fy:
            hi, y, fy = y, x, fx
            x = hi-ratio*(hi-lo); fx = sx*fn(x)
        else:
            lo, x, fx = x, y, fy
            y = lo+ratio*(hi-lo); fy = sx*fn(y)
    return (lo+hi)/2


def horizontal_sections(c, g, N, fy, fu):
    """Discrete-resultant audit with both crossing-hole force limits.

    The net section union and force/moment are geometric/equilibrium quantities.
    Sigma=N/A+M(x-xbar)/I and tau=1.5|V|/A are supplemental nominal screens.
    All row forces are collinear, so mixed crossing-hole inclusion patterns have
    the same action line and are bounded by the all-excluded/all-included limits.
    """
    holes = g['bolt_centers']; radius = g['net_hole_diameter']/2
    C, S = g['direction']; B, t = c.plate_width, c.plate_t
    bounds = sorted(set([0., c.plate_height]+[max(0., min(c.plate_height, y+a)) for _, y in holes for a in (-radius, 0., radius)]))
    records = []
    for low, high in zip(bounds, bounds[1:]):
        if high-low <= 1e-12:
            continue
        mid = (low+high)/2
        above = [j for j, (_, y) in enumerate(holes) if y-radius >= mid]
        crossing = [j for j, (_, y) in enumerate(holes) if y-radius < mid < y+radius]
        alternatives = [(above, 'excluding_crossing_holes')]
        if crossing:
            alternatives.append((above+crossing, 'including_crossing_holes'))
        for active, inclusion in alternatives:
            cache = {}
            def cut(y):
                if y in cache:
                    return cache[y]
                removed = []
                for xh, yh in holes:
                    if abs(y-yh) <= radius:
                        half = math.sqrt(max(0., radius*radius-(y-yh)**2))
                        removed.append([xh-half, xh+half])
                net = subtract_intervals(-B/2, B/2, removed)
                area, cg, inertia = section_properties(net, t)
                nr, vr = N*S*len(active)/c.n, N*C*len(active)/c.n
                moment = sum(N/c.n*((holes[j][0]-cg)*S-(holes[j][1]-y)*C) for j in active)
                sigma = [nr/area+moment*(x-cg)/inertia for x in (-B/2, B/2)]
                tau = 1.5*abs(vr)/area
                maximum = max(map(abs, sigma)); vm = math.hypot(maximum, math.sqrt(3)*tau)
                result = dict(y=y, A=area, centroid_s=cg, I=inertia, N=nr, V=vr, M=moment,
                    active_bolts=[j+1 for j in active], active=[int(j in active) for j in range(c.n)],
                    net_segments=net, sigma_edges=sigma, tau_envelope=tau, sigma_min=min(sigma),
                    sigma_max=maximum, VM=vm, utilization_yield=vm/(fy/1.10),
                    utilization_rupture=max(maximum/(fu/1.35), tau/(.6*fu/1.35)))
                cache[y] = result
                return result
            candidates = {low, high}
            grid = [low+(high-low)*j/8 for j in range(9)]
            candidates.update(grid)
            for key, maximize in [('sigma_min', False), ('VM', True), ('utilization_rupture', True)]:
                for a, b in zip(grid, grid[1:]):
                    candidates.add(golden_extreme(lambda y: cut(y)[key], a, b, maximize))
            values = [cut(y) for y in candidates]
            records.append(dict(interval=[low, high], active=[int(j in active) for j in range(c.n)],
                inclusion=inclusion, crossing_bolts=[j+1 for j in crossing],
                min_sigma=min(values, key=lambda z: z['sigma_min']),
                max_VM=max(values, key=lambda z: z['VM']),
                max_rupture=max(values, key=lambda z: z['utilization_rupture'])))
    return dict(model='Supplemental nominal perforated-section screen; not exact continuum/contact or hole-split shear solution',
        extrema_method='geometric intervals, endpoints and subdivided bounded scalar optimization; not an interval certificate',
        force_limit_proof='Collinear equal bolt forces: both extreme included-count limits bound every mixed crossing-hole subset',
        bounds=bounds, intervals=records, min_sigma=min(r['min_sigma']['sigma_min'] for r in records),
        max_VM=max(r['max_VM']['VM'] for r in records),
        utilization_yield=max(r['max_VM']['utilization_yield'] for r in records),
        utilization_rupture=max(r['max_rupture']['utilization_rupture'] for r in records))


def force_normal_sections(c, g, N, fy, fu):
    records = []
    dn, t = g['net_hole_diameter'], c.plate_t
    for j, u in enumerate(g['bolt_stations']):
        chord = transverse_chord(c, u)
        left, right = chord['left']['distance'], chord['right']['distance']
        remaining = subtract_intervals(-left, right, [[-dn/2, dn/2]])
        area, cg, inertia = section_properties(remaining, t)
        demand = N*(c.n-j)/c.n
        moment = -demand*cg
        sigma = [demand/area+moment*(v-cg)/inertia for v in (-left, right)]
        records.append(dict(u=u, width=left+right, net_area=area, net_centroid_v=cg, I=inertia,
            demand_envelope=demand, moment_about_net_centroid=moment, sigma_edges=sigma,
            endpoints=[chord['left']['point'], chord['right']['point']],
            endpoint_edges=[chord['left']['edge'], chord['right']['edge']], net_segments=remaining,
            yield_utilization=max(map(abs, sigma))/(fy/1.10),
            rupture_utilization=max(map(abs, sigma))/(fu/1.35),
            purpose='Actual clipped net geometry with conservative nominal eccentric stress screen'))
    return records
