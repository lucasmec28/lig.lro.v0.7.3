"""Independent R016 UI, native persistence and conservative result presentation."""
from .display_precision import display_format, display_frame, display_tree, display_value, number_input
from dataclasses import fields
import hashlib
import json
import math

import pandas as pd
import streamlit as st
from .load_conventions import render as render_load_convention

from .angle_catalog_ui import (render_selector as render_angle_catalog,
    draft_keys as angle_catalog_draft_keys, reset as reset_angle_catalog)
from .models import Profile, profiles, STEELS, BOLTS, KGF, VERSION
from .double_angle import DoubleAngle, FAMILY, SCOPE, presets, evaluate
from .double_angle_presentation import physical_envelopes, governing_description
from .report import BRAND, LINK, number

P = {name: p for name, p in profiles().items() if p.family == 'W'}
PRESETS = presets()
CUSTOM = 'W personalizado'
PROFILE_VALUES = ('d', 'bf', 'tw', 'tf', 'clear', 'area', 'mass')
LOAD_UNITS = {'V': KGF, 'N': KGF, 'M': KGF * 1000, 'torsion': KGF * 1000}
LOAD_KEYS = {'V': 'V_kgf', 'N': 'N_kgf', 'M': 'M_kgfm', 'torsion': 'torsion_kgfm'}
STATUS = {
    'INVALID_INPUT': 'DADOS INVÁLIDOS',
    'NUMERICAL_FAILURE': 'FALHA NUMÉRICA · CÁLCULO NÃO CONCLUÍDO',
    'INVALID_GEOMETRY': 'GEOMETRIA FISICAMENTE INVÁLIDA',
    'OUTSIDE_R016_SCOPE': 'FORA DO DOMÍNIO R016 · CORTANTE',
    'DETAIL_FAIL': 'NÃO ATENDE AO DETALHAMENTO',
    'VERIFIED_SUBCHECK_FAIL': 'NÃO ATENDE ÀS VERIFICAÇÕES REALIZADAS',
    'ENGINEERING_MODEL_PENDING': 'VERIFICAÇÃO COMPLEMENTAR PENDENTE',
    'COMPLETE_CHECKS_PASS_WITHIN_SCOPE': 'ATENDE ÀS VERIFICAÇÕES NO DOMÍNIO R016',
    'COMPLETE_CHECKS_PASS_WITH_PRESET_DEVIATION': 'ATENDE NO DOMÍNIO · DETALHE DIFERE DO PRESET R016',
}


def _draft_keys():
    keys = ['da_' + f.name for f in fields(DoubleAngle) if f.name not in ('beam', 'support')]
    keys += ['da_' + key for key in LOAD_KEYS.values()]
    for role in ('beam', 'support'):
        keys += ['da_' + role + '_' + key for key in ('name', 'manual_name', 'family', 'source') + PROFILE_VALUES]
    return keys + angle_catalog_draft_keys('da_')


def _widget_float(value, name, minimum=.01):
    """Reject clamp/precision loss before any proposed project is committed."""
    converted = float(value)
    if not math.isfinite(converted) or converted != value or converted < minimum:
        raise ValueError(f"{display_value(name)}: valor {value!r} não representável sem alteração no controle (mínimo {display_format(minimum, 'g')}; precisão binária de 64 bits).")
    return converted


def _proposed_ui_state(c):
    """Validate the complete native input and every widget-bound numeric value."""
    c.to_dict()
    proposed = {}
    integer_fields = {'angle_count', 'web_rows', 'support_rows', 'web_columns', 'support_columns'}
    nonnegative = {'root_radius', 'angle_top', 'gap', 'fabrication_clearance'}
    for f in fields(c):
        if f.name not in ('beam', 'support'):
            value = getattr(c, f.name)
            if (isinstance(value, (int, float)) and not isinstance(value, bool)
                    and f.name not in integer_fields | set(LOAD_UNITS) | {'db'}):
                value = _widget_float(value, f.name, 0. if f.name in nonnegative else .01)
            proposed['da_' + f.name] = value
    for key, unit in LOAD_UNITS.items():
        display = getattr(c, key) / unit
        if not math.isfinite(display):
            raise ValueError(f'{display_value(key)}: ação não representável em kgf / kgf·m.')
        # The original canonical load is retained above, including subnormals.
        proposed['da_' + LOAD_KEYS[key]] = display
    for role in ('beam', 'support'):
        p = getattr(c, role)
        prefix = 'da_' + role + '_'
        proposed[prefix + 'name'] = p.name if p.name in P and p == P[p.name] else CUSTOM
        proposed[prefix + 'manual_name'] = p.name
        proposed[prefix + 'family'] = p.family
        proposed[prefix + 'source'] = p.source
        for key in PROFILE_VALUES:
            proposed[prefix + key] = _widget_float(getattr(p, key), role + '.' + key)
    return proposed


def seed(proposed):
    """Commit only a fully validated proposal; rejected imports never reach here."""
    s = st.session_state
    s.update(proposed)
    reset_angle_catalog('da_')
    s.pop('da_report', None)
    s.pop('_double_angle_ui_draft', None)


def use_example():
    seed(_proposed_ui_state(PRESETS[st.session_state.da_example]))
    st.session_state.pop('da_import_error', None)


def load_project():
    try:
        upload = st.session_state.da_upload
        if upload is None:
            raise ValueError('Selecione um arquivo JSON.')
        if len(upload.getvalue()) > 200000:
            raise ValueError('Arquivo maior que 200 kB.')
        proposed = _proposed_ui_state(DoubleAngle.from_dict(json.loads(upload.getvalue())))
        seed(proposed)
        st.session_state.pop('da_import_error', None)
    except (ValueError, TypeError, KeyError, OverflowError) as exc:
        st.session_state.da_import_error = 'Não foi possível abrir: ' + str(exc)


def bolt_changed():
    hole = {16.: 18., 20.: 22., 24.: 26., 30.: 33.}.get(st.session_state.da_db)
    if hole is not None:
        st.session_state.da_hole_diameter = hole


def _select(label, options, key, labels=None, **kwargs):
    """Keep unsupported imported enum values visible, never silently normalize."""
    options = list(options)
    current = st.session_state.get(key)
    if current is not None and current not in options:
        options.append(current)
    if labels:
        kwargs['format_func'] = lambda value: labels.get(value, str(value) + ' · valor importado')
    return st.selectbox(label, options, key=key, **kwargs)


def _dimension(key, label, minimum=.01):
    return number_input(label + ' (mm)', min_value=minimum, key='da_' + key)


def _profile(role, label):
    prefix = 'da_' + role + '_'
    name = st.selectbox(label, [CUSTOM] + list(P), key=prefix + 'name')
    if name in P:
        p = P[name]
    else:
        with st.expander('Geometria personalizada · ' + label, expanded=True):
            designation = st.text_input('Designação · ' + label, key=prefix + 'manual_name')
            family = st.text_input('Família declarada · ' + label, key=prefix + 'family')
            values = {}
            for key, text in [('d', 'Altura d (mm)'), ('bf', 'Largura bf (mm)'),
                              ('tw', 'Alma tw (mm)'), ('tf', 'Mesa tf (mm)'),
                              ('clear', 'Altura livre das raízes (mm)'), ('area', 'Área A (mm²)'),
                              ('mass', 'Massa linear (kg/m)')]:
                values[key] = number_input(text + ' · ' + label, min_value=.01, key=prefix + key)
            source = st.text_input('Fonte das dimensões/área · ' + label, key=prefix + 'source')
            p = Profile(designation, family, source=source, **values)
    st.caption(f"{display_value(label)}: d={display_format(p.d, 'g')}; bf={display_format(p.bf, 'g')}; tw={display_format(p.tw, 'g')}; tf={display_format(p.tf, 'g')} mm; A={display_format(p.area, 'g')} mm².")
    return p


def _force(key):
    """Preserve original JSON loads exactly until their display value is edited."""
    raw = st.session_state['da_' + key]
    displayed = st.session_state['da_' + LOAD_KEYS[key]]
    unit = LOAD_UNITS[key]
    if not _finite(raw) or not _finite(displayed):
        raise ValueError(key + ': ação finita obrigatória.')
    if displayed == raw / unit:
        return raw
    converted = displayed * unit
    if not _finite(converted):
        raise ArithmeticError(key + ': transbordamento na conversão de kgf / kgf·m para N / N mm.')
    return converted


def _finite(value):
    try:
        return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)
    except OverflowError:
        return False


def _kgf(value):
    return value / KGF if _finite(value) else None


def _display(value):
    return number(value, 3) if _finite(value) else '—'


def _checks_table(checks):
    rows = []
    for check in checks:
        rows.append({
            'ID do ramo': check.get('id', ''), 'Componente': check.get('component', ''),
            'Verificação': check.get('label', check.get('id', '')),
            'Sentido da força': {'down': 'para baixo', 'up': 'para cima'}.get(check.get('loaded_direction'), 'independente'),
            'Solicitação real (kgf)': _kgf(check.get('actual_demand_N')),
            'Solicitação adotada (kgf)': _kgf(check.get('demand_N')),
            'Resistência (kgf)': _kgf(check.get('design_capacity_N')),
            'Índice real': check.get('actual_utilization'), 'Índice adotado': check.get('utilization'),
            'Resultado': check.get('status', ''), 'Referência': check.get('reference', ''),
        })
    return pd.DataFrame(rows)


def _envelopes_table(envelopes):
    rows = []
    for envelope in envelopes:
        actual, adopted = envelope['actual_governing'], envelope['adopted_governing']
        rows.append({
            'Componente físico': envelope['component_label'], 'Mecanismo': envelope['mechanism_label'],
            'Solicitação real (kgf)': _kgf(actual['actual_demand_N']),
            'Resistência · ramo real (kgf)': _kgf(actual['design_capacity_N']),
            'Índice real': actual['actual_utilization'],
            'Caso / sentido / ramo real': governing_description(actual),
            'Solicitação adotada (kgf)': _kgf(adopted['demand_N']),
            'Resistência · ramo adotado (kgf)': _kgf(adopted['design_capacity_N']),
            'Índice adotado': adopted['utilization'],
            'Caso / sentido / ramo adotado': governing_description(adopted),
            'Resultado real': 'NÃO ATENDE' if envelope['actual_status'] == 'FAIL' else 'ATENDE',
            'Resultado adotado': 'NÃO ATENDE' if envelope['status'] == 'FAIL' else 'ATENDE',
            'Ramos preservados': len(envelope['members']),
        })
    return pd.DataFrame(rows)


def _complete_checks(checks):
    required = {'id', 'component', 'actual_demand_N', 'demand_N', 'design_capacity_N',
                'actual_utilization', 'utilization', 'actual_status', 'status'}
    numeric = required - {'id', 'component', 'actual_status', 'status'}
    return bool(checks) and all(
        isinstance(row, dict) and required <= row.keys() and
        all(_finite(row[key]) for key in numeric) and
        row['actual_status'] in ('PASS', 'FAIL') and row['status'] in ('PASS', 'FAIL')
        for row in checks)


def _input_failure(s, status, exc):
    """A failed current construction cannot expose the preceding calculation."""
    s.pop('da_report', None)
    s.pop('_double_angle_project', None)
    s['_double_angle_result'] = {
        'status': status, 'global_pass': False, 'checks': [], 'summary': {},
        'issues': [{'severity': 'numerical_failure' if status == 'NUMERICAL_FAILURE' else 'invalid_input',
                    'text': str(exc)}],
    }
    st.error(STATUS[status])
    st.error(str(exc))
    st.caption('Nenhum resultado ou arquivo do cálculo anterior é válido para esta entrada. Corrija os dados para recalcular.')


def render():
    from .double_angle_drawing import image_bytes, drawing_svg
    from .double_angle_report import create_report

    s = st.session_state
    if 'da_project' not in s:
        saved = s.get('_double_angle_project')
        draft = s.get('_double_angle_ui_draft')
        seed(_proposed_ui_state(DoubleAngle.from_dict(saved) if saved else next(iter(PRESETS.values()))))
        if draft:
            for key, value in draft.items():
                s[key] = value
    # Hidden custom geometry and independent interface inputs survive reruns.
    for key in _draft_keys():
        if key in s:
            s[key] = s[key]

    with st.sidebar:
        st.caption('Versão ' + VERSION + ' · cantoneiras duplas R016')
        st.selectbox('Exemplo de cantoneiras duplas', list(PRESETS), key='da_example')
        st.button('Usar exemplo R016', on_click=use_example, use_container_width=True)
        st.file_uploader('Abrir projeto R016', type=['json'], key='da_upload')
        st.button('Carregar R016', on_click=load_project, use_container_width=True)
        if 'da_import_error' in s:
            st.error(s.da_import_error)
        st.divider()
        st.caption(BRAND)
        st.link_button('LinkedIn · Lucas Oliveira', LINK)

    st.title('Cantoneiras duplas · R016')
    st.caption('Duas cantoneiras reais · alma de viga W à mesa de pilar W · ambas as interfaces parafusadas')
    st.info('Primeiro domínio: cortante vertical estático, com sinal. N, M e torção não nulos, cantoneira única, recortes e arranjos não convencionais exigem modelo próprio.')
    st.text_input('Identificação do projeto R016', key='da_project')
    left, right = st.columns([.85, 1.5], gap='large')
    with left:
        beam = _profile('beam', 'Viga apoiada W')
        support = _profile('support', 'Pilar de apoio W')
        number_input('Cortante Vsd já majorado, com sinal (kgf)', key='da_V_kgf', format='%.2f')
        st.caption('O sinal de V define a borda carregada. A força real e a ação adotada de conferência permanecem distintas.')
        load_convention_slot = st.empty()
        with st.expander('N, M e torção · ações fora do domínio R016'):
            number_input('Força axial N (kgf)', key='da_N_kgf', format='%.2f')
            number_input('Momento M (kgf·m)', key='da_M_kgfm', format='%.2f')
            number_input('Torção T (kgf·m)', key='da_torsion_kgfm', format='%.2f')
            st.caption('Valores não nulos são preservados e impedem aprovação pelo modelo V-only.')
        with st.expander('Geometria das duas cantoneiras', expanded=True):
            render_angle_catalog('da_')
            for key, label in [('beam_leg', 'Aba junto à alma da viga'), ('support_leg', 'Aba junto à mesa do apoio'),
                               ('t', 'Espessura da cantoneira'), ('length', 'Comprimento vertical da cantoneira')]:
                _dimension(key, label)
            if not s.da_angle_catalog_id:
                _dimension('root_radius', 'Raio interno da cantoneira', 0.)
            _dimension('angle_top', 'Topo da cantoneira abaixo do topo da viga', 0.)
            st.caption('As duas cantoneiras do par são iguais. As abas e os grupos de cada interface são informados separadamente.')
        with st.expander('Interface 1 · parafusos comuns à alma e às duas cantoneiras', expanded=True):
            number_input('Parafusos verticais na alma', min_value=1, max_value=20, key='da_web_rows')
            number_input('Colunas de parafusos na aba da viga', min_value=1, max_value=20, key='da_web_columns')
            for key, label in [('beam_gauge', 'Gabarito da aba da viga'), ('web_pitch', 'Passo vertical na alma'),
                               ('web_end_top', 'Borda superior da cantoneira ao primeiro parafuso da alma')]:
                _dimension(key, label)
            st.caption('Dois planos de corte por parafuso comum; a alma real da viga é verificada separadamente.')
        with st.expander('Interface 2 · parafusos de cada cantoneira à mesa do apoio', expanded=True):
            number_input('Parafusos verticais por cantoneira no apoio', min_value=1, max_value=20, key='da_support_rows')
            number_input('Colunas de parafusos por aba de apoio', min_value=1, max_value=20, key='da_support_columns')
            for key, label in [('support_gauge', 'Gabarito da aba do apoio'), ('support_pitch', 'Passo vertical no apoio'),
                               ('support_end_top', 'Borda superior da cantoneira ao primeiro parafuso do apoio'),
                               ('support_edge_top', 'Primeiro parafuso até a borda livre superior real do apoio'),
                               ('support_edge_bottom', 'Último parafuso até a borda livre inferior real do apoio')]:
                _dimension(key, label)
            st.caption('Um plano de corte por parafuso de apoio; cada cantoneira transmite V/2 no modelo simétrico.')
        with st.expander('Furação, montagem e acesso'):
            _select('Diâmetro métrico do parafuso (mm)', [16., 20., 24., 30.], 'da_db', on_change=bolt_changed)
            _select('Classe dos parafusos', list(BOLTS), 'da_bolt')
            _dimension('hole_diameter', 'Diâmetro efetivo do furo')
            _select('Tipo de furo', ['standard_round', 'oversized_round', 'short_slot', 'long_slot'], 'da_hole_type',
                    {'standard_round': 'Circular padrão', 'oversized_round': 'Circular alargado',
                     'short_slot': 'Alongado curto', 'long_slot': 'Alongado longo'})
            st.checkbox('Furo de broca documentado: sem acréscimo de 2 mm na dedução', key='da_drilled')
            st.checkbox('Rosca excluída e documentada nos dois planos da alma', key='da_web_threads_excluded')
            st.checkbox('Rosca excluída e documentada no plano do apoio', key='da_support_threads_excluded')
            for key, label in [('gap', 'Folga da ponta da viga à mesa do apoio'),
                               ('fabrication_clearance', 'Folga adicional de fabricação')]:
                _dimension(key, label, 0.)
            _dimension('tool_radius', 'Raio livre requerido para a ferramenta')
            st.caption('R016: despachar as cantoneiras para montagem junto com a viga. N×s da folha industrial conta intervalos; os campos acima contam parafusos. Z não é o comprimento automático da cantoneira.')
        with st.expander('Materiais, topologia e premissas'):
            for key, label in [('beam_steel', 'Aço da viga'), ('support_steel', 'Aço do apoio')]:
                _select(label, [name for name, steel in STEELS.items() if steel.rolled_allowed], 'da_' + key)
            _select('Aço das cantoneiras', [name for name, steel in STEELS.items() if steel.rolled_allowed], 'da_angle_steel')
            _select('Exposição', ['painted', 'weathering'], 'da_exposure',
                    {'painted': 'Pintado / protegido', 'weathering': 'Aço patinável exposto'})
            _select('Interface física de apoio', ['column_flange', 'column_web', 'beam_web'], 'da_kind',
                    {'column_flange': 'Mesa de pilar W · R016', 'column_web': 'Alma de pilar · fora deste domínio',
                     'beam_web': 'Alma de viga · R017, fora deste domínio'})
            number_input('Quantidade real de cantoneiras', min_value=1, max_value=20, key='da_angle_count')
            st.checkbox('Par de cantoneiras iguais, simétricas em relação à alma', key='da_symmetric')
            _select('Recortes da viga', ['none', 'top', 'bottom', 'both'], 'da_cope',
                    {'none': 'Sem recortes', 'top': 'Recorte superior', 'bottom': 'Recorte inferior', 'both': 'Superior e inferior'})
            st.checkbox('Ações estáticas, sem impacto ou fadiga', key='da_static')
            st.checkbox('Combinações últimas normais', key='da_normal_combination')
            st.checkbox('Projeto exige resistência ao deslizamento', key='da_no_slip_required')
        st.text_area('Observações e decisão do responsável técnico', key='da_notes')

    s['_double_angle_ui_draft'] = {key: s[key] for key in _draft_keys() if key in s}
    try:
        values = {f.name: s['da_' + f.name] for f in fields(DoubleAngle)
                  if f.name not in ('beam', 'support', *LOAD_UNITS)}
        c = DoubleAngle(beam=beam, support=support, **{key: _force(key) for key in LOAD_UNITS}, **values)
        native = c.to_dict()
        encoded = json.dumps(native, ensure_ascii=False, indent=2, allow_nan=False)
    except ArithmeticError as exc:
        with right:
            _input_failure(s, 'NUMERICAL_FAILURE', exc)
        return
    except (ValueError, TypeError, KeyError) as exc:
        with right:
            _input_failure(s, 'INVALID_INPUT', exc)
        return
    digest = hashlib.sha256(encoded.encode()).hexdigest()
    s['_double_angle_project'] = native
    if s.get('da_report', ('', '', b''))[0] != digest:
        s.pop('da_report', None)
    try:
        with load_convention_slot.container():
            render_load_convention(st, 'double_angle_r016', c.N)
        r = evaluate(c)
    except ArithmeticError as exc:
        with right:
            _input_failure(s, 'NUMERICAL_FAILURE', exc)
        return
    s['_double_angle_result'] = r
    from .double_angle_candidates_ui import render as render_candidates
    with left:
        render_candidates(c, r)
    checks = r.get('checks') or []
    status = r.get('status', 'ENGINEERING_MODEL_PENDING')
    complete_checks = _complete_checks(checks)
    geometry_valid = bool((r.get('geometry') or {}).get('valid')) and status not in ('INVALID_INPUT', 'NUMERICAL_FAILURE')
    if status in ('INVALID_INPUT', 'NUMERICAL_FAILURE'):
        s.pop('da_report', None)
    with right:
        text = STATUS.get(status, status)
        if status in ('INVALID_INPUT', 'NUMERICAL_FAILURE', 'INVALID_GEOMETRY', 'DETAIL_FAIL', 'VERIFIED_SUBCHECK_FAIL'):
            st.error(text)
        elif status == 'COMPLETE_CHECKS_PASS_WITHIN_SCOPE' and r.get('global_pass') is True and complete_checks:
            st.success(text)
        else:
            st.warning(text)
        summary = r.get('summary') or {}
        load = r.get('load_model') or {}
        if summary:
            a, b = st.columns(2)
            a.metric('Índice com V real', _display(summary.get('actual_governing_utilization')))
            b.metric('Índice com ação adotada', _display(summary.get('governing_utilization')))
            st.caption('Vsd=' + _display(_kgf(load.get('Vsd_N', c.V))) + ' kgf; Vd adotado=' +
                       _display(_kgf(load.get('Vd_N'))) + ' kgf. Governa: ' + str(summary.get('governing_label', 'não determinado')))
        if geometry_valid:
            st.image(image_bytes(c, r), width='stretch')
        for issue in r.get('issues') or []:
            text = issue.get('text', str(issue)) if isinstance(issue, dict) else str(issue)
            severity = issue.get('severity', '') if isinstance(issue, dict) else ''
            if severity in ('invalid_input', 'numerical_failure', 'invalid_geometry', 'detail_fail', 'error'):
                st.error(text)
            elif severity in ('unsupported_scope', 'engineering_pending', 'access_pending', 'preset_deviation', 'warning'):
                st.warning(text)
            else:
                st.caption(text)
        if load:
            with st.expander('Partilha, interfaces e excentricidades'):
                for key, label in [('web_group_force_N', 'Ação adotada no grupo comum da alma'),
                                   ('each_angle_force_N', 'Ação adotada em cada cantoneira'),
                                   ('each_support_group_force_N', 'Ação adotada em cada grupo do apoio')]:
                    if _finite(load.get(key)):
                        st.write(label + ': ' + _display(_kgf(load[key])) + ' kgf.')
                for key in ('minimum_note', 'serial_interfaces', 'eccentricity_model'):
                    if load.get(key):
                        st.caption(str(load[key]))
                delivered = load.get('column_delivered_vertical_force_N')
                moment = load.get('column_delivered_transport_moment_about_centroid_Nmm')
                if _finite(delivered) and _finite(moment):
                    st.write('Ações reais entregues ao dimensionamento global do pilar: V=' +
                             _display(delivered / KGF) + ' kgf; momento de transporte=' +
                             _display(moment / (KGF * 1000)) + ' kgf·m.')
                if load.get('column_transport_note'):
                    st.caption(str(load['column_transport_note']))
                st.caption('As interfaces transmitem a ação em série; não se somam suas resistências. N=M=T externos nulos não anulam excentricidades geométricas.')
                st.json(display_tree(load), expanded=False)
        st.caption(SCOPE)
        for exclusion in r.get('exclusions') or []:
            st.caption(exclusion)
    if checks and complete_checks:
        envelopes = physical_envelopes(r)
        st.subheader('Envelopes por componente físico e mecanismo')
        st.caption(f'{display_value(len(envelopes))} envelopes conservam os {display_value(len(checks))} ramos originais, sem somar resistências em série. Máximos real e adotado são selecionados separadamente; empates e todos os casos constam no detalhamento.')
        st.dataframe(display_frame(_envelopes_table(envelopes)), hide_index=True, width='stretch')
        for envelope in envelopes:
            with st.expander(envelope['component_label'] + ' · ' + envelope['mechanism_label'] +
                             f" · {display_value(len(envelope['members']))} ramos"):
                st.write('Governante real: ' + governing_description(envelope['actual_governing']))
                st.write('Governante adotado: ' + governing_description(envelope['adopted_governing']))
                if envelope['mechanism'] == 'bearing':
                    st.caption('A soma normativa dos furos e a compatibilidade da distribuição uniforme por furo são ramos distintos preservados. Não há redistribuição plástica implícita.')
                st.dataframe(display_frame(_checks_table(envelope['members'])), hide_index=True, width='stretch')
                st.caption('Registro integral: todos os furos, prefixos, sentidos, solicitações, capacidades, índices, fórmulas, referências e governantes empatados.')
                st.json(display_tree(envelope), expanded=False)
    elif checks:
        st.warning('Registros incompletos: não é possível formar envelopes ou emitir conclusão resistente.')
        with st.expander('Registros diagnósticos e fórmulas disponíveis'):
            st.dataframe(display_frame(_checks_table(checks)), hide_index=True, width='stretch')
            st.json(display_tree(checks), expanded=False)
    a, b, d = st.columns(3)
    a.download_button('Salvar projeto R016 .json', encoded, 'cantoneiras_duplas_R016.json', 'application/json')
    if geometry_valid:
        b.download_button('Baixar desenho R016 .svg', drawing_svg(c, r), 'cantoneiras_duplas_R016.svg', 'image/svg+xml')
    ready = complete_checks and geometry_valid and status not in ('INVALID_INPUT', 'NUMERICAL_FAILURE', 'INVALID_GEOMETRY', 'OUTSIDE_R016_SCOPE')
    if d.button('Gerar memória R016', disabled=not ready, use_container_width=True):
        s.da_report = (digest, 'memoria_cantoneiras_duplas_R016.docx', create_report(c, r))
    if 'da_report' in s:
        _, filename, payload = s.da_report
        st.download_button('Baixar memória R016 .docx', payload, filename,
                           'application/vnd.openxmlformats-officedocument.wordprocessingml.document')
