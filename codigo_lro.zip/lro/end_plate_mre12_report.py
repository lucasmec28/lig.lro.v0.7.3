"""Current-input Word report for the distinct MRE1/2 load path."""
from io import BytesIO
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from .models import STEELS,VERSION
from .end_plate import evaluate,input_digest,method_revision,NBR,DG
from .end_plate_drawing import image_bytes
from .end_plate_report import compact_outcome,equation
from .report import table,number,display,hyperlink,BRAND,LINK
from .display_precision import calculated_text
from .end_plate_presentation import summary_lines,SCOPE_NOTICE


def create_mre12_report(c,detailed=False):
    from .end_plate_detail import DETAIL_SCOPE,detail_description
    r=evaluate(c)
    if not r.checks or any(i.severity=='error' and i.origin not in ('method','numeric') for i in r.issues):
        raise ValueError('MRE1/2 requer geometria e dados válidos para gerar memória.')
    doc=Document();sec=doc.sections[0];sec.page_width=Inches(8.27);sec.page_height=Inches(11.69)
    sec.top_margin=sec.bottom_margin=Inches(.6);sec.left_margin=sec.right_margin=Inches(.65)
    for name,size in [('Normal',9),('Title',20),('Subtitle',11),('Heading 1',12),('Heading 2',10)]:
        sty=doc.styles[name];sty.font.name='Arial';sty.font.size=Pt(size);sty.font.color.rgb=RGBColor(0,0,0)
    for sty in doc.styles:
        for border in sty.element.xpath('.//w:pBdr'):border.getparent().remove(border)
    for p in doc.styles:
        if hasattr(p,'paragraph_format'):p.paragraph_format.widow_control=True
    doc.styles['Normal'].paragraph_format.space_after=Pt(4)
    doc.core_properties.title='End plate MRE1/2 · 12 parafusos'+(' · nervuras de detalhamento' if c.has_detail_ribs else ' sem nervuras');doc.core_properties.author=BRAND
    def para(text,style=None):return doc.add_paragraph(text,style)
    def val(x):return number(x,2)
    def check_table(checks):
        table(doc,['Verificação / caso','Tipo','Sd','Rd','Unid.','Índice','Resultado'],[(q.name+' ['+q.case+']',q.category,display(q.demand,q.unit)[0],display(q.resistance,q.unit)[0],display(q.demand,q.unit)[1],val(q.ratio),compact_outcome(q)) for q in checks],[2.05,.8,.75,.75,.5,.75,1.15])
    para('End plate MRE1/2','Title');para(('12 parafusos · cálculo base sem nervuras' if c.has_detail_ribs else '12 parafusos sem nervuras')+' · coluna contínua A-4(a)','Subtitle');para(c.project)
    para(c.beam.name+' → '+c.support.name);p=para(r.status);p.runs[0].bold=True
    if r.coverage_note:para(r.coverage_note)
    for line in summary_lines(r):
        para(line).paragraph_format.space_after=Pt(2)
    para(SCOPE_NOTICE).paragraph_format.space_after=Pt(2)
    para('Memória '+('detalhada' if detailed else 'compacta')+' · casos completos e classificação nominal separada. Aprovação local não certifica fabricação ou estabilidade global.')
    identity=para('Entradas SHA-256: '+input_digest(c)+' · revisão '+method_revision(c))
    for run in identity.runs:run.font.size=Pt(7)
    doc.add_picture(BytesIO(image_bytes(c)),width=Inches(6.75))
    para('Chapa parafusada à coluna; viga soldada à chapa por CJP nas mesas e alma. Seis linhas reais, três ativas à tração conforme M e três do lado comprimido recebendo V/6. '+('Cálculo base sem crédito às nervuras de detalhe' if c.has_detail_ribs else 'Sem nervuras')+'; sem reforço da coluna.')
    doc.add_page_break();para('Entradas e materiais','Heading 1')
    table(doc,['Componente','Dimensões / valores','Material ou condição'],[
        ('Viga','d='+val(c.beam.d)+'; bf='+val(c.beam.bf)+'; tw='+val(c.beam.tw)+'; tf='+val(c.beam.tf),c.beam_steel),
        ('Coluna','d='+val(c.support.d)+'; bf='+val(c.support.bf)+'; tw='+val(c.support.tw)+'; tf='+val(c.support.tf),c.support_steel),
        ('Chapa','bp='+val(c.bp)+'; tp='+val(c.tp)+'; hp='+val(c.hp),c.plate_steel),
        ('Linhas físicas',', '.join(val(y) for y in c.rows),'y em mm desde a face superior da viga'),
        ('Passos','pfo='+val(c.pfo)+'; pfi='+val(c.pfi)+'; pb='+val(c.pb)+'; de='+val(c.edge),'pb somente entre as duas linhas internas de cada mesa'),
        ('Parafusos','12 físicos; 6 ativos em tração; db='+val(c.db)+'; g='+val(c.gauge),c.bolt),
        ('Furos','dh='+val(c.dh)+'; dn='+val(c.dn),'Rosca no corte: '+('sim' if c.threads else 'não')+'; '+('broca' if c.drilled else '+2 mm na dedução líquida')),
        ('CJP','fw='+val(c.fw)+' MPa; ferramenta='+val(c.tool_radius)+' mm',c.cjp_electrode+'; compatibilidade declarada: '+('sim' if c.cjp_compatible else 'não')),
        ('Entrada','N='+val(c.N)+' N; V='+val(c.V)+' N; M='+val(c.M)+' Nmm','N>0 tração; M>0 tração superior; V assinado'),
        ('Mínimo 45 kN','f='+val(r.minimum_factor),'N e V proporcionais; M preservado; momento puro sem direção inventada')],[1.1,3.65,2.])
    if c.has_detail_ribs:
        para(DETAIL_SCOPE);para(detail_description(c))
    para('Resistências características: '+'; '.join(k+': fy='+val(STEELS[k].fy)+' MPa, fu='+val(STEELS[k].fu)+' MPa' for k in dict.fromkeys((c.beam_steel,c.plate_steel,c.support_steel)))+'. γa1=1,10; γa2=1,35; E=200000 MPa.')
    para('Método e fonte','Heading 1')
    para(DG+', tabela 5-12 p.115, figura 5-12 p.153; tabela A-4(a) pp.267–268; tabela 5-9 p.112; §§3.4–3.7 e 5.1. '+NBR+' para as resistências. A errata futura/inacessível não foi declarada consultada.')
    para('Yp=(bp,ef/2)[h1/pfo+h2/pi+h3/sP−1/2]+(2/g)[h2(pi+3pb/4)+h3(sP+pb/4)]+g/2')
    para('Yc=(B/2)[(h1+h3)/sC]+(2/g)[h1(sC+3pb/4+3c/4)+h3(sC+pb/4+c/4)]+g/2')
    para('bp,ef=min(bp;bf,viga+max(tp;25,4)); B=min(bf,coluna;bf,viga+max(tp;25,4)); sP=√(bp,ef g)/2; sC=√(B g)/2; pi=min(pfi;sP). pfo sem saturação. c=pfo+tf+pfi=h1−h2; h1=d−tf/2+pfo; h2=d−1,5tf−pfi; h3=h2−pb; H=2(h1+h2+h3). Coordenadas, braços e caminhos mantêm pfi físico quando pfi>sP.')
    a=r.geometry['actual_actions']
    para('Parâmetros em mm: '+ '; '.join(label+'='+val(a[k]) for k,label in [('h1','h1'),('h2','h2'),('h3','h3'),('H','H'),('Yp','Yp'),('Yc','Yc'),('plate_s','sP'),('column_s','sC'),('column_c','c')])+'.')
    para('Domínio geométrico','Heading 2')
    table(doc,['Grandeza','Entrada','Fonte, mm','±10% adotado','Estado'],[(q['name'],val(q['value']),val(q['lower'])+'–'+val(q['upper']),val(q['adopted_lower'])+'–'+val(q['adopted_upper']),'dentro' if q['within'] else 'extrapolação') for q in a['source_ranges']],[1.6,.8,1.3,1.6,1.45])
    para('pb não tem faixa numérica própria na tabela. Topologia, ligamentos, acesso e espaçamentos governam; não exigir pb=3 pol. do exemplo. Fora da faixa é extrapolação, não resistência fictícia.')
    para('Diagnóstico nominal separado','Heading 1');nom=a['nominal']
    para('Demanda: chapa espessa / sem alavanca na demanda de cálculo exige ambas as espessuras requeridas, sem tolerância. Diagnóstico nominal não é um requisito adicional do procedimento por demanda.')
    para('Eq.3-18/19: Mpl=fyp tp²Yp e Mcf=fyc tfc²Yc, comparados separadamente a 1,10Mnp. Mnp=Pt H; Pt=Fnt Ab nominal, sem dividir novamente por γa2 ou φ. Fnt DG39='+val(nom['Fnt'])+' MPa (90 ksi Group120; 113 ksi Group150).')
    table(doc,['Referência nominal','Mnp, kN·m','Mpl/Mnp','Mcf/Mnp','Classificação'],[
        ('DG39 literal',val(nom['Mnp']/1e6),val(nom['plate_ratio']),val(nom['column_ratio']),('chapa atende' if nom['plate_no_prying'] else 'chapa não atende')+'; '+('coluna atende' if nom['column_no_prying'] else 'coluna não atende')),
        ('NBR derivada 0,75fubAb',val(nom['NBR_reference']['Mnp']/1e6),val(nom['NBR_reference']['plate_ratio']),val(nom['NBR_reference']['column_ratio']),'Referência distinta, preservada')],[1.8,1.,1.,1.,1.95])
    para('Mpl='+val(nom['Mpl']/1e6)+' kN·m; Mcf='+val(nom['Mcf']/1e6)+' kN·m. '+('Sem prying até Mnp: ambas as condições nominais atendem.' if nom['all_no_prying'] else 'Não classificada sem prying até Mnp. O resultado de demanda permanece independente.'))
    para('Envoltória de verificações','Heading 1');check_table(r.summary_checks)
    para('As redundâncias comprovadas ficam agrupadas no resumo; todos os ramos de cada caso seguem abaixo. Espessura/plastificação não gera alarme nominal adicional.')
    for record in r.case_records:
        para(record['label']+' · caso completo','Heading 1');ac=record['actions']
        para('N='+val(ac['N'])+' N; V='+val(ac['V'])+' N; M='+val(ac['M'])+' Nmm. Estado: '+record['status']+'.')
        if not record['checks']:para(record.get('reason','Caso não resolvido.'));continue
        a=r.geometry['actual_actions' if record['label']=='Entrada' else 'minimum_actions']
        para('Tração '+('superior' if ac['M']>0 else 'inferior')+', linhas '+', '.join(str(i+1) for i in a['active_indices'])+'; cisalhamento nas linhas '+', '.join(str(i+1) for i in a['shear_indices'])+'. Pivô y='+val(a['compression_pivot'])+' mm. Três braços físicos: '+', '.join(val(h) for h in a['active_arms'])+' mm.')
        para('Meq='+val(a['Meq'])+' Nmm; Tb='+val(a['bolt_tension'])+' N; T=6Tb='+val(a['T'])+' N; C='+val(a['C'])+' N. Ff='+val(a['flange_transfer_force'])+' N; Fc='+val(a['flange_compression_force'])+' N. Extensão Ff/3='+val(a['extension_transfer_force'])+' N; alma 2Ff/3='+val(a['local_transfer_force'])+' N; V/6='+val(a['bolt_shear'])+' N.')
        para('lwt='+val(a['web_tension_length'])+' mm; lws='+val(a['web_shear_weld_length'])+' mm; hw='+val(a['web_physical_height'])+' mm. Regiões disjuntas, sem dupla dedução de tração. tp,req='+val(a['tp_required'])+' mm; tfc,req='+val(a['column_tf_required'])+' mm. Demanda espessa: '+('ambas atendem.' if a['demand_no_prying'] else 'não atendida.'))
        check_table(record['checks'])
        if detailed:
            para('Parafusos físicos e sentidos de força','Heading 2')
            table(doc,['Linha','x, mm','y, mm','Tração, N','V coluna, N','V chapa, N','η'],[(q['row'],val(q['x']),val(q['y']),val(q['tension']),val(q['column_signed_shear']),val(q['plate_signed_shear']),val(q['interaction'])) for q in a['bolts']],[.5,.8,.9,1.2,1.2,1.2,.95])
            para('Contato por caminho carregado','Heading 2')
            table(doc,['Peça / linha','Sentido','lc, mm','Sd, N','Rd, N','η'],[(q['piece']+' / '+str(q['row']),q['force_direction'],'sem borda' if q['lc'] is None else val(q['lc']),val(q['demand']),val(q['resistance']),val(q['ratio'])) for q in a['bearing_paths']],[1.3,.7,1.1,1.2,1.45,1.])
            para('Blocos da chapa: todos os furos deduzidos, somente cargas atribuídas somadas','Heading 2')
            table(doc,['Borda / furos / cargas','Agv, mm²','Anv, mm²','Ant, mm²','Sd, N','Rd, N'],[(q['edge']+' / '+str(q['hole_rows'])+' / '+str(q['loaded_rows']),val(q['Agv']),val(q['Anv']),val(q['Ant']),val(q['demand']),val(q['resistance'])) for q in a['plate_blocks']],[1.6,1.,1.,1.,1.,1.15])
            for q in record['checks']:
                para(q.name+' ['+q.case+']','Heading 2');equation(doc,q)
                para(calculated_text(q.substitution)+'; η='+val(q.ratio)+'. '+calculated_text(q.variables)+' Fonte: '+q.reference+'.')
    para('Premissas e limites','Heading 1')
    for note in c.assumptions:
        if note!=DETAIL_SCOPE:para(note)
    for i in r.issues:para(calculated_text(i.text,assignments_only=True)+' ['+i.reference+']')
    if c.notes:para('Observações: '+c.notes)
    footer=sec.footer.paragraphs[0];footer.paragraph_format.space_after=Pt(0)
    footer.add_run(BRAND+' · LRO Ligações '+VERSION+' · ').font.size=Pt(7)
    hyperlink(footer,'LinkedIn de Lucas Oliveira',LINK)
    out=BytesIO();doc.save(out);return out.getvalue()
