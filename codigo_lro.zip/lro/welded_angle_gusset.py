"""Bounded welded 1L–rectangular gusset–web-centred exterior W flange.

N, mm, MPa. Parameterized same-topology static tensile section model.
Geometry, primitive paths and section extrema are recomputed, never scaled from
an oracle. The full local route does not certify the loaded support member.
"""
from __future__ import annotations
from dataclasses import asdict, dataclass, fields, replace
import math
from .models import STEELS, Steel, finite_real, profiles
from .angle_catalog import get_angle, catalog, LEGACY_ARCELOR_ID

FAMILY = 'Ligação 1L–gusset–mesa W · soldada'
COMPONENT_VERSION = '0.9.27-gerdau-angles-dev'
LEGACY_COMPONENT_VERSION = '0.9.26-welded-angle-gusset-dev'
CONNECTION_TYPE = 'welded_angle_gusset'
UNITS = {'force': 'N', 'length': 'mm', 'stress': 'MPa', 'moment': 'N mm'}
GAMMA_A1, GAMMA_A2, GAMMA_W2 = 1.10, 1.35, 1.35
MATERIALS = dict(STEELS, S275JR=Steel('S275JR', 275., 410., 16., 16.,
    source='EN10025-2 S275JR, propriedades mínimas adotadas para t≤16 mm; certificar produto especificado'))
ELECTRODES = {'E60': 415., 'E70': 485.}
ANGLE = get_angle(LEGACY_ARCELOR_ID)  # Exact legacy record, never a Gerdau substitute.
SUPPORT = dict(name='W310x165x52', d=317., bf=167., tw=7.6, tf=13.2, r=8., k=21.2,
               source='https://constructalia.arcelormittal.com/files/W--0487915bad55d18fbfc679cd87133c88.pdf')
# Keep each producer/source identity separate: clear is the straight web depth,
# so k=(d-clear)/2. Never mix the Arcelor radius with another catalog record.
SUPPORT_CATALOG = {SUPPORT['name']: dict(SUPPORT)}
for _profile in profiles().values():
    if _profile.family == 'W':
        _k = (_profile.d - _profile.clear) / 2
        if _k >= _profile.tf and _profile.clear > 0:
            SUPPORT_CATALOG[_profile.name] = dict(name=_profile.name, d=_profile.d, bf=_profile.bf,
                tw=_profile.tw, tf=_profile.tf, r=_k-_profile.tf, k=_k,
                source=_profile.source + ' k=(d−altura livre reta)/2; conferir catálogo de fornecimento.')
SCOPE = ('Uma cantoneira laminada de abas iguais, identificada por fabricante e seção, uma aba contra chapa retangular, dois filetes longitudinais iguais '
         'e raiz contínua dupla na mesa exterior de W laminado do catálogo identificado, longitudinal e centrada na alma. '
         'Tração estática, sem fadiga, NBR 8800:2024/Errata1:2025, combinações normais. '
         'Geometria parametrizada somente com contenção, topologia de caminhos e seções totalmente tracionadas. '
         'A excentricidade no plano permanece no equilíbrio; a idealização fora do plano usa 6.1.8.2. '
         'Campo elástico de seções e faixa local conservadora, não solução exata de tensões do contínuo.')
EXCLUSIONS = [
    'Compressão, fadiga, sismo, ação espacial e ligação direta à alma W exigem outra qualificação.',
    'Sem chapas poligonais, furos, enrijecedores, raiz descontínua/descentrada, retornos ou comprimentos de solda desiguais.',
    'Não verifica resistência ou estabilidade global da barra, viga, pilar ou pórtico; exporta ações concorrentes ao verificador do membro.',
    'O resultado local não constitui aprovação de fabricação, WPS ou inspeção.',
    'Falha de envelope conservador é falha da triagem do método, não demonstração de uma fissura física exata.',
]

@dataclass(frozen=True)
class WeldedAngleGusset:
    project: str = '1L100×100×12 → gusset400×300×10 → mesa W · exemplo excêntrico N100kN'
    support_member: str = 'beam'
    support_face: str = 'flange'
    angle_profile: str = 'L100x100x12'
    support_profile: str = 'W310x165x52'
    angle_steel: str = 'S275JR'
    gusset_steel: str = 'ASTM A36'
    support_steel: str = 'ASTM A572 Gr.50'
    angle_electrode: str = 'E60'
    root_electrode: str = 'E60'
    plate_width: float = 400.
    plate_height: float = 300.
    plate_t: float = 10.
    theta_deg: float = 75.
    center_s: float = 0.
    center_n: float = 150.
    weld_length: float = 200.
    end_margin: float = 20.
    angle_weld_leg: float = 5.
    angle_weld_edge_detail: str = 'ordinary'
    root_weld_leg: float = 5.
    introduction_width: float = 150.
    support_end_left: float = 1000.
    support_end_right: float = 1000.
    N: float = 100000.
    V: float = 0.
    M: float = 0.
    torsion: float = 0.
    static: bool = True
    normal_combination: bool = True
    fatigue: bool = False
    seismic: bool = False
    minimum_force: bool = True
    recommend_half_capacity: bool = False
    notes: str = ''

    @property
    def fixed_assumptions(self):
        return dict(topology='one_angle_one_face_equal_longitudinal_fillets_full_double_root_rolled_W_flange',
                    load_transfer='balanced_uniform_from_catalog_centroid_over_leg',
                    out_of_plane='NBR6.1.8.2_static_single_angle_exception',
                    in_plane='actual_centroid_and_root_moment_retained',
                    no_holes=True, no_returns=True, gamma_a1=GAMMA_A1, gamma_a2=GAMMA_A2,
                    gamma_w2=GAMMA_W2, support_member_global_pass=False,
                    plate_model='full_horizontal_elastic_sections_plus_physical_local_strip',
                    rupture_envelope='ordinary_parallel_shear_transverse_tension_Cts0.5',
                    root_weld_DG29='max_peak_1.25_endpoint_average')

    def to_dict(self):
        errors = input_errors(self)
        if errors: raise ValueError('; '.join(errors))
        return dict(schema_version=1, connection_type=CONNECTION_TYPE,
                    component_version=COMPONENT_VERSION, connection=asdict(self),
                    units=dict(UNITS), fixed_assumptions=self.fixed_assumptions)

    @classmethod
    def from_dict(cls, data):
        keys = {'schema_version', 'connection_type', 'component_version', 'connection', 'units', 'fixed_assumptions'}
        if not isinstance(data, dict) or set(data) != keys:
            raise ValueError('Ligação soldada 1L: campos nativos ausentes ou desconhecidos.')
        if type(data['schema_version']) is not int or data['schema_version'] != 1 or data['connection_type'] != CONNECTION_TYPE or data['component_version'] not in (COMPONENT_VERSION, LEGACY_COMPONENT_VERSION):
            raise ValueError('Família ou versão soldada 1L incompatível.')
        raw = data['connection']
        field_names = {f.name for f in fields(cls)}
        if data['component_version'] == LEGACY_COMPONENT_VERSION:
            if not isinstance(raw, dict) or set(raw) != field_names-{'angle_weld_edge_detail'}:
                raise ValueError('Campos legados 0.9.26 incompletos ou desconhecidos; não se aceita esquema híbrido.')
            raw = dict(raw, angle_weld_edge_detail='ordinary')
        if not isinstance(raw, dict) or set(raw) != field_names:
            raise ValueError('Campos da ligação incompletos ou desconhecidos.')
        candidate = cls(**raw)
        canonical = candidate.to_dict()
        assumptions = canonical['fixed_assumptions']
        if data['component_version'] == LEGACY_COMPONENT_VERSION:
            if candidate.angle_profile != LEGACY_ARCELOR_ID:
                raise ValueError('Arquivo legado somente identifica a seção ArcelorMittal original.')
            assumptions = dict(assumptions, load_transfer='balanced_uniform_heel_0.71_toe_0.29')
        if not _exact(data['units'], canonical['units']) or not _exact(data['fixed_assumptions'], assumptions):
            raise ValueError('Unidades ou premissas incompatíveis; nenhuma conversão silenciosa.')
        return candidate


def _exact(a, b):
    if type(a) is not type(b): return False
    if isinstance(b, dict): return set(a) == set(b) and all(_exact(a[k], b[k]) for k in b)
    return a == b


def input_errors(c):
    if not isinstance(c, WeldedAngleGusset): return ['Entrada deve ser WeldedAngleGusset.']
    errors = []
    for f in fields(c):
        v = getattr(c, f.name)
        if f.type in ('str', str):
            if not isinstance(v, str): errors.append(f.name + ': texto obrigatório.')
        elif f.type in ('bool', bool):
            if type(v) is not bool: errors.append(f.name + ': booleano explícito obrigatório.')
        elif not finite_real(v): errors.append(f.name + ': número real finito obrigatório.')
    return errors


def presets():
    base = WeldedAngleGusset()
    gerdau = replace(base, project='Gerdau L63,5×6,35 · gusset400×300×10 · N100kN · borda reforçada',
                     angle_profile='GERDAU_EQUAL_ANGLE_P03_R25', angle_steel='ASTM A36',
                     angle_weld_edge_detail='reinforced')
    return {'Gerdau · L63,5×6,35 · borda reforçada': gerdau,
            'Gerdau · L101,6×12,70 · N100kN': replace(base,
                project='Gerdau L101,6×12,70 · N100kN',angle_profile='GERDAU_EQUAL_ANGLE_P03_R40',angle_steel='ASTM A36'),
            'Gerdau · L203,2×19,05 · N150kN': replace(base,
                project='Gerdau L203,2×19,05 · N150kN',angle_profile='GERDAU_EQUAL_ANGLE_P03_R52',angle_steel='ASTM A36',
                theta_deg=90.,plate_width=600.,plate_height=350.,center_n=180.,weld_length=250.,
                angle_weld_leg=6.,root_weld_leg=6.,introduction_width=300.,N=150000.),
            'Gerdau · L50,8×4,76 · uso eventual · N45kN': replace(base,
                project='Gerdau L50,8×4,76 · chapa6 · N45kN',angle_profile='GERDAU_EQUAL_ANGLE_P03_R20',angle_steel='ASTM A36',
                theta_deg=90.,plate_width=300.,plate_height=180.,plate_t=6.,center_n=90.,weld_length=100.,
                angle_weld_leg=3.,root_weld_leg=3.,introduction_width=120.,N=45000.),
            '1L soldada · N100kN · exemplo excêntrico': base,
            '1L soldada · N200kN · falha resistente': replace(base, project='1L soldada · N200kN', N=200000.),
            '1L soldada · pilar W · N100kN': replace(base, project='1L soldada · pilar W', support_member='column'),
            '1L soldada · N real zero / candidato45kN': replace(base, project='1L soldada · N real zero', N=0.),
            '1L soldada · 45° compacto · N100kN excêntrico': replace(base,
                project='45° compacto · exemplo excêntrico N100kN', theta_deg=45.,
                plate_width=500.,plate_height=210.,center_s=55.,center_n=105.,
                weld_length=150.,end_margin=10.,introduction_width=140.),
            '1L soldada · 45° alinhado · N45kN / Mlocal0': replace(base,
                project='45° · linha de força alinhada ao centro da solda (Mlocal=0)',N=45000.,
                theta_deg=45.,plate_width=600.,plate_height=200.,center_s=110.198484809835,
                center_n=80.5,weld_length=65.,end_margin=20.,root_weld_leg=6.),
            '1L soldada · 135° alinhado · N45kN / Mlocal0': replace(base,
                project='135° · linha de força alinhada ao centro da solda (Mlocal=0)',N=45000.,
                theta_deg=135.,plate_width=600.,plate_height=200.,center_s=-50.801515190165006,
                center_n=80.5,weld_length=65.,end_margin=20.,root_weld_leg=6.)}


def minimum_fillet(thinner):
    return 3. if thinner <= 6.3 else 5. if thinner <= 12.5 else 6. if thinner <= 19 else 8.


def root_actions(N, theta_deg, point, M_applied=0.):
    theta = math.radians(theta_deg)
    nr, vr = N * math.sin(theta), N * math.cos(theta)
    return dict(N=nr, V=vr, M=M_applied + point[0] * nr - point[1] * vr)


def block_resistance(Agv, Anv, Ant, fy, fu, Cts=.5):
    return min(.6 * fu * Anv + Cts * fu * Ant, .6 * fy * Agv + Cts * fu * Ant) / GAMMA_A2


def _safe(v):
    if isinstance(v, (int, float)) and not isinstance(v, bool): return v if finite_real(v) else None
    if isinstance(v, dict): return {str(k): _safe(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)): return [_safe(x) for x in v]
    return v if v is None or isinstance(v, (str, bool)) else repr(v)


def _issue(out, id, severity, message, **detail):
    out['issues'].append(dict(id=id, severity=severity, message=message, **detail))


def _forward_exit(c, v):
    """First actual free-boundary intersection along +u, never the root."""
    C,S=math.cos(math.radians(c.theta_deg)),math.sin(math.radians(c.theta_deg))
    choices=[((c.plate_height-c.center_n+v*C)/S,'top')]
    if C>0:choices.append(((c.plate_width/2-c.center_s-v*S)/C,'right'))
    if C<0:choices.append(((-c.plate_width/2-c.center_s-v*S)/C,'left'))
    u,edge=min(choices,key=lambda x:x[0])
    return dict(u=u,edge=edge,edges=[e for uu,e in choices if math.isclose(uu,u,rel_tol=1e-12,abs_tol=1e-10)],
                point=[c.center_s+u*C+v*S,c.center_n+u*S-v*C])


def _transverse_chord(c,u):
    """Intersection of constant-u line with all four rectangle halfspaces.

    A supported-root hit is identified, never renamed a free boundary.
    Corner ties prefer the genuinely adjoining free side at the transition.
    """
    C,S=math.cos(math.radians(c.theta_deg)),math.sin(math.radians(c.theta_deg))
    lows=[((-c.plate_width/2-c.center_s-u*C)/S,'left')]
    highs=[((c.plate_width/2-c.center_s-u*C)/S,'right')]
    if C>0:
        lows.append(((c.center_n+u*S-c.plate_height)/C,'top'))
        highs.append(((c.center_n+u*S)/C,'root'))
    elif C<0:
        lows.append(((c.center_n+u*S)/C,'root'))
        highs.append(((c.center_n+u*S-c.plate_height)/C,'top'))
    lo=max(lows,key=lambda x:x[0]);hi=min(highs,key=lambda x:x[0])
    result={}
    for side,(v,edge),possibilities in [('left',lo,lows),('right',hi,highs)]:
        for vv,ee in possibilities:
            if ee in ('left','right') and math.isclose(v,vv,rel_tol=1e-12,abs_tol=1e-10):v,edge=vv,ee
        result[side]=dict(v=v,edge=edge,point=[c.center_s+u*C+v*S,c.center_n+u*S-v*C])
    return result


def _root_contact_length(c,u_cut,v_boundary,side):
    """Exact intersection of the candidate detached block with n=0."""
    C,S=math.cos(math.radians(c.theta_deg)),math.sin(math.radians(c.theta_deg))
    lo,hi=-c.plate_width/2,c.plate_width/2
    ku=-c.center_s*C-c.center_n*S
    if C>0:lo=max(lo,(u_cut-ku)/C)
    elif C<0:hi=min(hi,(u_cut-ku)/C)
    elif ku < u_cut:return 0.
    sv=c.center_s+(v_boundary-c.center_n*C)/S
    if side=='left':hi=min(hi,sv)
    else:lo=max(lo,sv)
    return max(0.,hi-lo)


def _geometry(c, out):
    A = get_angle(c.angle_profile)
    if A is None:
        return None
    b, ta, ec = A['leg'], A['t'], A['centroid']
    if A['Ag'] is None or ec is None:
        _issue(out, 'angle_missing_section_properties', 'outside_scope',
               'Catálogo Gerdau não publica Ag/ec desta linha; propriedades não são inventadas nem herdadas de outra seção.')
        return None
    vh, vt, vc = -b/2, b/2, ec-b/2
    fh, ft = 1-ec/b, ec/b
    A['resistance_model'] = ('catalog_radiused_legacy' if c.angle_profile == LEGACY_ARCELOR_ID
                             else 'nominal_equal_angle_NBR')
    A['projected_centroid_v'] = vc
    A['heel_force_fraction'], A['toe_force_fraction'] = fh, ft
    dimensions = ('plate_width', 'plate_height', 'plate_t', 'weld_length', 'angle_weld_leg',
                  'root_weld_leg', 'introduction_width', 'support_end_left', 'support_end_right')
    if any(getattr(c, key) <= 0 for key in dimensions) or c.end_margin < 0:
        _issue(out, 'positive_geometry', 'invalid_geometry', 'Dimensões positivas e margem de extremidade não negativa são obrigatórias.')
        return None
    if not 0 < c.theta_deg < 180:
        _issue(out, 'direction_topology', 'outside_scope', 'Topologia inicial exige 0 < θ < 180°; a direção de tração deve afastar-se da raiz.')
        return None
    B,H,L = c.plate_width,c.plate_height,c.weld_length
    W = SUPPORT_CATALOG.get(c.support_profile,SUPPORT)
    C,S = math.cos(math.radians(c.theta_deg)), math.sin(math.radians(c.theta_deg))
    def point(u,v): return [c.center_s+u*C+v*S,c.center_n+u*S-v*C]
    def inside(p, tol=1e-8): return -B/2-tol <= p[0] <= B/2+tol and -tol <= p[1] <= H+tol
    lines = [dict(id=name,v=v,force_fraction=f,start=point(-L/2,v),end=point(L/2,v),
                  centroid=point(0,v),length=L) for name,v,f in [('heel',vh,fh),('toe',vt,ft)]]
    footprint_vs = [vh-c.angle_weld_leg,vh,vt,vt+c.angle_weld_leg]
    corners = [point(u,v) for u in (-L/2,L/2) for v in footprint_vs]
    angle_end = [point(-L/2-c.end_margin,v) for v in (vh,vt)]
    top = {str(v): point((H-c.center_n+v*C)/S,v) for v in footprint_vs}
    exits = {str(v): _forward_exit(c,v) for v in footprint_vs}
    station_events = sorted(set([-L/2,L/2]+[
        (x-c.center_s)*C+(y-c.center_n)*S for x in (-B/2,B/2) for y in (0.,H)
        if -L/2 < (x-c.center_s)*C+(y-c.center_n)*S < L/2]))
    stations = [dict(u=u,chord=_transverse_chord(c,u)) for u in station_events]
    intro = [point(-L/2,v) for v in (-c.introduction_width/2,c.introduction_width/2)]
    left_corner_u = (-B/2-c.center_s)*C-c.center_n*S
    left_u = max(-L/2,left_corner_u)
    left_v = (-B/2-c.center_s-left_u*C)/S
    left_point = point(left_u,left_v)
    right_corner_u = (B/2-c.center_s)*C-c.center_n*S
    right_u = max(-L/2,right_corner_u)
    right_v = (B/2-c.center_s-right_u*C)/S
    right_point = point(right_u,right_v)
    fabrication_notes = []
    if c.angle_weld_edge_detail == 'reinforced':
        fabrication_notes.append('BORDA REFORÇADA DA CANTONEIRA: executar reforço na borda para obter garganta efetiva mínima a=s/√2='
            +format(c.angle_weld_leg/math.sqrt(2),'.6g')+' mm; filete inscrito s='+format(c.angle_weld_leg,'g')
            +' mm, conforme NBR 8800:2024, 6.2.6.2.2(b). Assegurar garganta por procedimento, execução e inspeção; não reduzir para a borda sem reforço.')
    g = dict(valid=False, polygon=[[-B/2,0],[B/2,0],[B/2,H],[-B/2,H]],
             direction=[C,S], weld_lines=lines, footprint_corners=corners,
             angle_free_end=angle_end, force_point=point(0,vc), root_centroid=[0.,0.],
             root_endpoints=[[-B/2,0],[B/2,0]], root_length=B,
             angle_section=dict(A), support_catalog=dict(W), fabrication_notes=fabrication_notes,
             introduction_endpoints=intro, footprint_vs=footprint_vs,
             top_intersections=top, forward_exits=exits, transverse_stations=stations,
             force_line_root_s=point(0,vc)[0]-point(0,vc)[1]*C/S,
             left_u=left_u,left_v=left_v, left_point=left_point,
             right_u=right_u,right_v=right_v,right_point=right_point,
             angle_free_end_u=-L/2-c.end_margin, weld_start_u=-L/2,weld_end_u=L/2,
             min_end_clearance=min(p[1] for p in angle_end)-c.root_weld_leg,
             support_end_clearances=[c.support_end_left-B/2,c.support_end_right-B/2],
             plate_width=B,plate_height=H,plate_t=c.plate_t,theta_deg=c.theta_deg,
             center=[c.center_s,c.center_n], angle_weld_leg=c.angle_weld_leg,root_weld_leg=c.root_weld_leg)
    if not all(inside(p) for p in corners+angle_end+intro):
        _issue(out, 'physical_containment', 'invalid_geometry', 'Solda, extremidade livre da cantoneira ou faixa local ultrapassa o contorno real da chapa.')
    if min(p[1] for p in corners+angle_end) <= c.root_weld_leg:
        _issue(out, 'root_interference', 'invalid_geometry', 'Cantoneira/filete longitudinal interfere no filete de raiz; exige afastamento físico positivo.')
    if any(e['u'] < L/2-1e-8 or not inside(e['point']) for e in exits.values()):
        _issue(out,'forward_path_exit','invalid_geometry','Caminho longitudinal alcança a borda antes do término físico da solda.')
    if min(g['support_end_clearances']) < 0:
        _issue(out, 'root_beyond_support', 'invalid_geometry', 'Raiz ultrapassa uma extremidade do membro W.')
    if c.introduction_width < b+2*c.angle_weld_leg or c.introduction_width > b+2*L*math.tan(math.pi/6):
        _issue(out, 'spread_domain', 'outside_scope', 'Faixa local deve conter as duas pegadas completas das soldas e espalhamento por lado entre0° e30° sobre o comprimento real.')
    if c.plate_t >= 2*L:
        _issue(out,'local_strip_Ct','outside_scope','Faixa local: a adaptação de Ct requer t<2L; Ct não positivo não é uma resistência qualificada.')
    # The exact legacy branch retains its published physical toe-flat gate.
    # Gerdau is a nominal NBR branch: s is an inscribed fillet leg, not a claim
    # that the full weld sits on an unpublished pre-weld flat toe face.
    for key,leg,thin in [('angle',c.angle_weld_leg,min(ta,c.plate_t)),('root',c.root_weld_leg,min(c.plate_t,W['tf']))]:
        if leg < minimum_fillet(thin):
            _issue(out, key+'_minimum_weld', 'detail_fail', f'Filete {key}: mínimo {minimum_fillet(thin):g}mm pela peça menos espessa ({thin:g}mm).')
        if key == 'angle' and A['toe_flat'] is not None and leg > A['toe_flat']:
            _issue(out, 'toe_flat_fit', 'invalid_geometry', f'Filete da ponta excede face plana declarada {A["toe_flat"]:g} mm de {A["name"]}.')
        edge_t = ta if key == 'angle' else c.plate_t
        maxleg = edge_t if edge_t < 6.3 else edge_t-1.5
        if key == 'angle' and c.angle_weld_edge_detail == 'reinforced' and A['manufacturer']=='Gerdau':
            maxleg = ta
        if leg > maxleg:
            _issue(out, key+'_maximum_weld', 'detail_fail', f'Filete ultrapassa máximo de {maxleg:g} mm no detalhe de borda selecionado.')
        length = L if key == 'angle' else B
        if length < max(4*leg,40.):
            _issue(out, key+'_effective_length', 'detail_fail', 'Comprimento efetivo deve alcançar4s e40mm neste detalhe.')
    if L > 100*c.angle_weld_leg or B > 100*c.root_weld_leg:
        _issue(out,'long_weld_reduction','outside_scope','L/s>100: a redução de comprimento de6.2.2.2(d) e sua distribuição não estão implementadas nesta rota; não há crédito de comprimento integral.')
    if c.plate_t+2*c.root_weld_leg > W['bf']:
        _issue(out,'flange_footprint_fit','invalid_geometry','Pegada da raiz tg+2s ultrapassa largura real da mesa W.')
    if L+c.end_margin < max(5*min(ta,c.plate_t),25.):
        _issue(out, 'lap_overlap', 'detail_fail', 'Sobreposição menor que max(5t da parte menos espessa,25mm).')
    if c.end_margin < c.angle_weld_leg:
        _issue(out, 'end_termination', 'detail_fail', 'Extremidade longitudinal deve conservar ao menos um lado do filete até a borda livre.')
    terminations=[]
    for v in footprint_vs:
        p=point(L/2,v)
        for edge in exits[str(v)]['edges']:
            gap={'top':H-p[1],'right':B/2-p[0],'left':p[0]+B/2}[edge]
            terminations.append(dict(v=v,point=p,edge=edge,normal_gap=gap,required=c.angle_weld_leg))
    g['forward_termination_clearances']=terminations
    for edge in ('top','left','right'):
        witnesses=[x for x in terminations if x['edge']==edge and x['normal_gap'] < c.angle_weld_leg]
        if witnesses:
            _issue(out, edge+'_termination', 'detail_fail',
                   'Extremidade física da solda requer afastamento normal de uma perna à borda livre real ('+edge+').',witnesses=witnesses)
    g['valid'] = not any(i['severity'] in ('invalid_geometry','outside_scope') for i in out['issues'])
    return g


def _path(id, name, component, Av, At, force, material, coords=None, conservative=False, **details):
    fy,fu = material.fy,material.fu
    rupture=(.6*fu*Av+.5*fu*At)/GAMMA_A2
    yielding=(.6*fy*Av+.5*fu*At)/GAMMA_A2
    R=min(rupture,yielding)
    if R <= 0: raise ArithmeticError('Caminho sem área/resistência positiva: '+id)
    return dict(id=id,name=name,component=component,Agv=Av,Anv=Av,Agt=At,Ant=At,Cts=.5,
                demand=force,resistance=R,rupture_branch_N=rupture,yield_branch_N=yielding,
                utilization=force/R,status='PASS' if force/R <= 1 else 'FAIL',
                path_xy_mm=coords or [],conservative=conservative,reference='NBR6.5.6; γa2 em ambos os ramos',**details)


def rupture_paths(c,g,N,angle,gusset):
    L,t=c.weld_length,c.plate_t
    A=g['angle_section']; b,ta,ec=A['leg'],A['t'],A['centroid']
    vh,vt=-b/2,b/2; fh,ft=1-ec/b,ec/b
    C,S=g['direction']; B,H=c.plate_width,c.plate_height
    def xy(u,v):return [c.center_s+u*C+v*S,c.center_n+u*S-v*C]
    def uexit(v):return _forward_exit(c,v)['u']
    length=L+c.end_margin
    if A['resistance_model'] == 'catalog_radiused_legacy':
        r1,r2,flat=A['root_radius'],A['toe_radius'],A['toe_flat']
        ah=(ta+r1)*ta+(b-ta)*ta+(r1*r1-math.pi*r1*r1/4)-(r2*r2-math.pi*r2*r2/4)
        at=r2*ta-(r2*r2-math.pi*r2*r2/4)
        paths=[_path('A-H','Cantoneira: L talão','angle',length*ta,ah,fh*N,angle),
               _path('A-T','Cantoneira: L ponta arredondada','angle',length*ta,at,ft*N,angle),
               _path('A-B','Cantoneira: L ambas as soldas','angle',length*ta,ah,N,angle),
               _path('A-T-limit','Cantoneira: limite da ponta, espessura '+format(flat,'g')+' mm',
                     'angle',length*flat,0,ft*N,angle,conservative=True),
               _path('A-all','Cantoneira: envelope conservador de caminhos parciais','angle',L*flat,0,N,angle,
                     conservative=True,note='Uma superfície de espessura plana publicada; descarta margem livre e ligamentos transversais; não é fissura exata.')]
    else:
        paths=[_path('A-nominal','Cantoneira: envelope nominal pela aba t×L','angle',ta*L,0,N,angle,
                     conservative=True,model='nominal_equal_angle_NBR',
                     note='Modelo nominal NBR: Agv=Anv=tL, Ant=0, demanda N integral; não é limite geométrico exato de uma ponta arredondada. Garganta efetiva do filete deve ser assegurada por execução e inspeção.')]
    lo,hi=vh-c.angle_weld_leg,vt+c.angle_weld_leg
    for id,va,vb,f in [('G-U-both',lo,hi,1.),('G-U-heel',lo,vh,fh),('G-U-toe',vt,hi,ft)]:
        Av=(uexit(va)+L/2+uexit(vb)+L/2)*t; At=(vb-va)*t
        coords=[xy(uexit(va),va),xy(-L/2,va),xy(-L/2,vb),xy(uexit(vb),vb)]
        paths.append(_path(id,'Gusset: '+id,'gusset',Av,At,f*N,gusset,coords))
    inactive=[]
    for id,side,v,f in [('G-L-left-heel','left',vh,fh),
                        ('G-L-left-both','left',hi,1.),
                        ('G-L-right-toe-partial','right',vt,ft),
                        ('G-L-right-both-partial','right',lo,1.)]:
        candidates=[];records=[]
        for station in g['transverse_stations']:
            u=station['u']; cap=station['chord'][side]; fraction=(L/2-u)/L
            contact=_root_contact_length(c,u,v,side)
            record=dict(u_cut=u,transverse_edge=cap['edge'],captured_force=f*N*max(0.,fraction),supported_root_contact_length=contact)
            if fraction <= 0:
                records.append(dict(record,status='no-positive-demand'));continue
            if cap['edge']=='root' or contact > 1e-10*max(1.,c.plate_width):
                records.append(dict(record,status='inadmissible-supported-root'));continue
            Av=(uexit(v)-u)*t;At=abs(cap['v']-v)*t
            if Av <= 0 or At < 0:continue
            candidate=_path(id,'Gusset: '+id,'gusset',Av,At,f*N*fraction,gusset,
                [xy(uexit(v),v),xy(u,v),cap['point']],partial_fraction=fraction,
                cut_u=u,transverse_free_edge=cap['edge'],forward_free_edge=_forward_exit(c,v)['edge'],
                supported_root_contact_length=contact,
                note='Interseções reais com bordas livres; solda atravessada sem crédito resistente.')
            candidates.append(candidate);records.append(dict(record,status='admissible-positive-demand' if N>0 else 'admissible-zero-actual-load'))
        if candidates:
            governing=max(candidates,key=lambda x:x['utilization'])
            path=dict(governing)
            path['station_candidates']=candidates
            path['station_records']=records
            paths.append(path)
        else:
            inactive.append(dict(id=id,station_records=records,reason='Nenhuma tampa transversal em borda livre captura força positiva; a raiz apoiada não é borda livre.'))
    g['inactive_path_families']=inactive
    paths.append(_path('G-all','Gusset: envelope conservador de caminhos parciais','gusset',L*t,0,N,gusset,
                       conservative=True,note='Uma superfície; descarta extensões à borda e ligamentos transversais.'))
    return paths


def plate_sections(c,g,N):
    """Exact remaining-resultant polynomials; all boundaries and normal extrema.

    The maximum of separate |normal| and |shear| on each interval gives a
    conservative VM envelope, avoiding an unverified sampling/peak claim.
    """
    B,t=c.plate_width,c.plate_t; A=B*t; Z=B*B*t/6
    C,S=g['direction']; L=c.weld_length
    bounds=sorted(set([0.,c.plate_height]+[p for line in g['weld_lines'] for p in (line['start'][1],line['end'][1])]))
    cuts=[]; intervals=[]
    for a,b in zip(bounds[:-1],bounds[1:]):
        mid=(a+b)/2; n0=n1=v0=v1=m0=m1=m2=0.
        for line in g['weld_lines']:
            F=N*line['force_fraction']; start,end=line['start'][1],line['end'][1]
            # Remaining scalar force = f0+f1*y. Its moment arm per force is
            # invariant along the line: k + y*cos(theta).
            if mid <= start: f0,f1=F,0.
            elif mid >= end:f0,f1=0.,0.
            else:f0,f1=F*end/(L*S),-F/(L*S)
            k=line['centroid'][0]*S-line['centroid'][1]*C
            n0+=S*f0;n1+=S*f1;v0+=C*f0;v1+=C*f1
            m0+=k*f0;m1+=k*f1+C*f0;m2+=C*f1
        values=[]
        for sign,edge in [(1.,'+s'),(-1.,'-s')]:
            p0=n0/A+sign*m0/Z;p1=n1/A+sign*m1/Z;p2=sign*m2/Z
            ys=[a,b]
            if p2 and a < -p1/(2*p2) < b:ys.append(-p1/(2*p2))
            for y in ys:
                sigma=(p2*y+p1)*y+p0
                # Remove roundoff only at zero-force ends, without clipping real compression.
                row=dict(y=y,edge=edge,sigma_MPa=sigma,kind='stationary' if y not in (a,b) else 'boundary',
                         N=n0+n1*y,V=v0+v1*y,M=(m2*y+m1)*y+m0)
                cuts.append(row);values.append(sigma)
        sigma_abs=max(abs(x) for x in values)
        tau=max(abs(v0+v1*a),abs(v0+v1*b))*1.5/A
        intervals.append(dict(y_start=a,y_end=b,N_coeff=[n0,n1],V_coeff=[v0,v1],M_coeff=[m0,m1,m2],
                              sigma_abs_max=sigma_abs,tau_abs_max=tau,
                              von_mises_envelope=math.hypot(sigma_abs,math.sqrt(3)*tau)))
    width=c.introduction_width; Ai=width*t; Si=width*width*t/6
    # Actual projected catalog centroid retained against local strip centre v=0.
    angle=g['angle_section']
    mi=(angle['centroid']-angle['leg']/2)*N; s1=N/Ai+mi/Si;s2=N/Ai-mi/Si
    # Explicit conservative adaptation of5.2.5(d), not literal full-gusset geometry.
    Ct=1/(1+(width/L)**2/3)*(1-width/(2*L)*t/width)
    local=dict(id='local_introduction',width=width,thickness=t,endpoints=g['introduction_endpoints'],
               A=Ai,S=Si,N=N,M=mi,sigma_min=min(s1,s2),sigma_max=max(s1,s2),Ct=Ct,
               spread_angle_deg=math.degrees(math.atan((width-angle['leg'])/(2*L))),
               Ct_basis='Adaptação conservadora de5.2.5(d) à faixa efetiva; chapa integral Ct1 por5.2.5(a).')
    return dict(cuts=cuts,intervals=intervals,local=local,
                min_normal=min([r['sigma_MPa'] for r in cuts]+[local['sigma_min']]),
                max_vm=max([r['von_mises_envelope'] for r in intervals]+[max(abs(s1),abs(s2))]))


def _row(out,id,label,component,mechanism,case,demand,resistance,unit='N',reference='',**detail):
    if not all(finite_real(v) for v in (demand,resistance)) or resistance <= 0 or demand < 0:
        raise ArithmeticError('Verificação não finita ou resistência não positiva: '+id)
    eta=demand/resistance
    if not finite_real(eta):raise ArithmeticError('Índice não finito: '+id)
    out['checks'].append(dict(id=case+'__'+id,label=label,component=component,mechanism=mechanism,
                             case_id=case,demand=demand,resistance=resistance,unit=unit,
                             utilization=eta,status='PASS' if eta <= 1 else 'FAIL',
                             reference=reference,details=detail))


def _envelope(out,id,label,component,mechanism,case,candidates,reference):
    governing=max(candidates,key=lambda x:x['demand']/x['resistance'])
    _row(out,id,label,component,mechanism,case,governing['demand'],governing['resistance'],
         governing.get('unit','N'),reference,governing=governing,candidates=candidates)


def _calculate_case(c,g,N,case,label,out,materials):
    angle,gusset,support=materials
    g=dict(g)  # Case-specific path applicability must not overwrite another case's witnesses.
    C,S=g['direction']; L=c.weld_length; B=c.plate_width;t=c.plate_t
    W=g['support_catalog']; A=g['angle_section']
    root=root_actions(N,c.theta_deg,g['force_point'])
    Nr,Vr,Mr=root['N'],root['V'],root['M']
    qends=[Nr/B-6*Mr/B**2,Nr/B+6*Mr/B**2]; qs=Vr/B
    qvec=[math.hypot(q,qs) for q in qends]
    qpeak=max(qvec);qavg=sum(qvec)/2;qd=max(qpeak,1.25*qavg)
    root.update(q_n_ends_N_per_mm=qends,q_s_N_per_mm=qs,q_peak=qpeak,q_average=qavg,q_design=qd,
                weld_stress=qd/(math.sqrt(2)*c.root_weld_leg),elastic_peak_equivalent_normal_N=B*max(abs(q) for q in qends))
    sections=plate_sections(c,g,N)
    tension_tol=1e-10*max(1.,abs(N)/(B*t))
    if sections['min_normal'] < -tension_tol:
        witness=min(sections['cuts'],key=lambda x:x['sigma_MPa'])
        if sections['local']['sigma_min'] < witness['sigma_MPa']:witness=sections['local']
        _issue(out,case+'_compressed_section','outside_scope','Seção modelada contém compressão: estabilidade desta geometria ainda não qualificada.',
               minimum_normal_MPa=sections['min_normal'],witness=witness)
    paths=rupture_paths(c,g,N,angle,gusset)
    for p in paths:p['case_id']=case
    Ct=max(1-A['centroid']/L,.5)
    if not 0 < Ct <= 1:raise ArithmeticError('Ct da cantoneira inválido.')
    _envelope(out,'angle_tension','Cantoneira · tração bruta/efetiva','angle','tension',case,
        [dict(name='Escoamento bruto',demand=N,resistance=A['Ag']*angle.fy/GAMMA_A1,Ag=A['Ag']),
         dict(name='Ruptura efetiva',demand=N,resistance=Ct*A['Ag']*angle.fu/GAMMA_A2,Ct=Ct,Ae=Ct*A['Ag'])],
        'NBR5.2.2/5.2.5(c), An=Ag sem furos; piso Ac/Ag=0,5 por bissetriz de abas iguais')
    for component,name in [('angle','Cantoneira'),('gusset','Gusset')]:
        selected=[p for p in paths if p['component']==component]
        reference = ('NBR6.5.6; envelope nominal de aba tL, Ant=0; não reconstrói a ponta arredondada'
                     if component=='angle' and A['resistance_model']=='nominal_equal_angle_NBR'
                     else 'NBR6.5.6; caminhos físicos + envelope conservador')
        _envelope(out,component+'_block',name+' · bloco/rasgamento',component,'block_tearout',case,selected,reference)
    for line in g['weld_lines']:
        F=N*line['force_fraction'];name=line['id']; leg=c.angle_weld_leg
        _row(out,'angle_weld_'+name,'Solda longitudinal · '+name,'angle_weld','weld_'+name,case,F,
             L*leg/math.sqrt(2)*.6*ELECTRODES[c.angle_electrode]/GAMMA_W2,reference='NBR6.2.2.2/6.2.5: filete inscrito, garganta efetiva=s/√2, sem ganho direcional; assegurar execução e inspeção',length=L,leg=leg,force_fraction=line['force_fraction'])
    for component,material in [('angle',angle),('gusset',gusset)]:
        # One surface-adjacent contact footprint per line. Merge into single substrate mode.
        candidates=[]
        for line in g['weld_lines']:
            F=N*line['force_fraction']
            angle_depth=A['toe_flat'] if A['resistance_model']=='catalog_radiused_legacy' else A['t']
            depth=min(c.angle_weld_leg,angle_depth if component=='angle' else c.plate_t)
            Ac=L*depth
            for mech,R in [('Escoamento',.6*material.fy*Ac/GAMMA_A1),('Ruptura',.6*material.fu*Ac/GAMMA_A2)]:
                candidates.append(dict(name=line['id']+' '+mech,demand=F,resistance=R,area=Ac,effective_depth=depth))
        _envelope(out,component+'_substrate',component+' · metal-base da solda longitudinal',component,'longitudinal_substrate',case,candidates,'NBR6.5.5; área min(s,t)L no modelo nominal; face plana publicada somente no modelo legado')
    local=sections['local']; horizontal=sections['intervals']
    _envelope(out,'gusset_yield','Gusset · escoamento N/V/M','gusset','yielding',case,
        [dict(name='Seções horizontais: envelope elástico',demand=max(x['von_mises_envelope'] for x in horizontal),resistance=gusset.fy/GAMMA_A1,unit='MPa'),
         dict(name='Faixa física local N+M',demand=max(abs(local['sigma_min']),abs(local['sigma_max'])),resistance=gusset.fy/GAMMA_A1,unit='MPa')],
         'NBR6.5.3/6.5.5; VM elástico conservador; DG29 espalhamento0–30°')
    normal_max=max(abs(x['sigma_MPa']) for x in sections['cuts']);tau_max=max(x['tau_abs_max'] for x in horizontal)
    _envelope(out,'gusset_rupture','Gusset · ruptura por tração/cisalhamento','gusset','rupture',case,
        [dict(name='Seções horizontais Ct1',demand=normal_max,resistance=gusset.fu/GAMMA_A2,unit='MPa'),
         dict(name='Seções horizontais: cisalhamento',demand=tau_max,resistance=.6*gusset.fu/GAMMA_A2,unit='MPa'),
         dict(name='Faixa local Ct conservador adaptado',demand=max(abs(local['sigma_min']),abs(local['sigma_max'])),resistance=local['Ct']*gusset.fu/GAMMA_A2,unit='MPa',Ct=local['Ct'])],
         'NBR6.5.3/6.5.5; adaptação explícita de5.2.5(d) somente à faixa local')
    _row(out,'root_weld','Solda dupla da raiz · N/V/M','root_weld','weld',case,root['weld_stress'],
         .6*ELECTRODES[c.root_electrode]/GAMMA_W2,'MPa','NBR6.2.5 + DG29 max(qpico,1.25qmédio)',**root)
    # Substrate in the root: one actual plate section, not two thicknesses.
    qn=max(abs(q) for q in qends)
    for component,material,depth in [('gusset_root',gusset,min(t,2*c.root_weld_leg)),('support_contact',support,2*c.root_weld_leg)]:
        sn=qn/depth;ts=abs(qs)/depth
        _envelope(out,component+'_substrate',component+' · metal-base da raiz',component,'root_substrate',case,
            [dict(name='Escoamento combinado',demand=math.hypot(sn,math.sqrt(3)*ts),resistance=material.fy/GAMMA_A1,unit='MPa'),
             dict(name='Ruptura normal',demand=sn,resistance=material.fu/GAMMA_A2,unit='MPa'),
             dict(name='Ruptura por cisalhamento',demand=ts,resistance=.6*material.fu/GAMMA_A2,unit='MPa')],
             'NBR6.5.3/6.5.5; base recebendo tração normal + cisalhamento',)
    # Actual web end proximity acts on every loaded point, not root centroid alone.
    end_distance=min(g['support_end_clearances']);kfactor=2.5 if end_distance <= W['d'] else 5.
    Rnormal=1.10*support.fy*W['tw']*(kfactor*W['k']+B)/GAMMA_A1
    Neq=root['elastic_peak_equivalent_normal_N']
    _row(out,'W_web_normal','W · escoamento local da alma por força normal','support_web','local_normal_yield',case,Neq,Rnormal,
         reference='NBR5.7.3; envelope elástico |N|+6|M|/L derivado',end_factor=kfactor,end_distance=end_distance)
    As=W['tw']*B
    _envelope(out,'W_web_shear','W · cisalhamento longitudinal da alma','support_web','longitudinal_shear',case,
        [dict(name='Escoamento',demand=abs(Vr),resistance=.6*support.fy*As/GAMMA_A1),
         dict(name='Ruptura',demand=abs(Vr),resistance=.6*support.fu*As/GAMMA_A2)],'DG29 p204; NBR6.5.5; Agv=twL, Vparalelo')
    # Conservative simultaneous local normal/shear web screen used in qualified oracle.
    web_normal=Neq/(W['tw']*B)
    web_shear=1.5*abs(Vr)/As
    _row(out,'W_web_combined','W · combinação local da alma','support_web','combined_yield',case,
         math.hypot(web_normal,math.sqrt(3)*web_shear),support.fy/GAMMA_A1,'MPa','Triagem elástica local conservadora derivada')
    flange_tau=qpeak/(2*W['tf'])
    _envelope(out,'W_flange_punch','W · cisalhamento/punção da mesa','support_flange','punching',case,
        [dict(name='Escoamento nas duas faces longitudinais',demand=flange_tau,resistance=.6*support.fy/GAMMA_A1,unit='MPa'),
         dict(name='Ruptura nas duas faces longitudinais',demand=flange_tau,resistance=.6*support.fu/GAMMA_A2,unit='MPa')],
        'NBR6.5.5; duas superfícies2tfL, sem crédito das bordas curtas')
    footprint=t+2*c.root_weld_leg
    exempt=footprint < .15*W['bf']
    if not exempt:
        Rbend=6.25*support.fy*W['tf']**2/GAMMA_A1
        if end_distance < 10*W['tf']:Rbend/=2
        _row(out,'W_flange_bending','W · flexão local da mesa','support_flange','local_bending',case,Neq,Rbend,
             reference='NBR5.7.2; largura carregada tg+2s; metade junto à extremidade',footprint=footprint)
    root['flange_bending_exempt']=exempt;root['flange_footprint']=footprint
    member=dict(reference='Centroide da raiz na face exterior da mesa',point_local=[0.,0.],
                applied_to_support=dict(N_normal=Nr,V_parallel=Vr,M_root=Mr),
                equal_opposite_on_gusset=dict(N_normal=-Nr,V_parallel=-Vr,M_root=-Mr),
                introduced_member_shear_jump=Nr,introduced_member_axial_jump=Vr,
                root_to_member_centroid_normal_offset=W['d']/2,
                introduced_moment_about_member_centroid=Mr-W['d']/2*Vr,
                existing_member_actions=None,global_member_verified=False,
                note='Somar às ações concorrentes reais do membro; não se presume apoio descarregado.')
    record=dict(id=case,label=label,N=N,root=root,plate_sections=sections,paths=paths,
                inactive_path_families=g.get('inactive_path_families',[]),member_actions=member,
                angle_Ct=Ct,angle_Ae=Ct*A['Ag'])
    out['cases'].append(record)
    if case=='actual':
        out.update(root=root,sections=sections,paths=paths,member_actions=member)
        out['geometry']['inactive_path_families']=g.get('inactive_path_families',[])


def _finalize(out):
    issues=out['issues'];bad=lambda s:any(x['severity']==s for x in issues)
    invalid=bad('invalid_input');num=bad('numerical_failure');geo=bad('invalid_geometry');outside=bad('outside_scope');detail=bad('detail_fail')
    complete=bool(out['checks']) and not(invalid or num or geo or outside)
    failed=[x['id'] for x in out['checks'] if x['status']=='FAIL']
    governing=max(out['checks'],key=lambda x:x['utilization']) if out['checks'] else None
    passed=complete and not failed and not detail
    out['global_pass']=passed # Historical API: means complete LOCAL checks only, never global member.
    out['local_pass']=passed;out['global_member_verified']=False
    out['status']=('INVALID_INPUT' if invalid else 'NUMERICAL_FAILURE' if num else 'INVALID_GEOMETRY' if geo else 'OUTSIDE_SCOPE' if outside else 'DETAILING_FAIL' if detail else 'COMPLETE_CHECKS_FAIL' if failed else 'COMPLETE_LOCAL_CHECKS_PASS_WITHIN_SCOPE' if complete else 'INCOMPLETE_CHECKS')
    out['summary']=dict(complete_checks=complete,utilization=governing['utilization'] if governing else None,
                        governing_id=governing['id'] if governing else None,failed_check_ids=failed,
                        check_count=len(out['checks']),case_count=len(out['cases']),detailing_pass=not detail,
                        global_member_verified=False)
    return _safe(out)


def evaluate(c):
    out=dict(status='INVALID_INPUT',global_pass=False,local_pass=False,issues=[],checks=[],cases=[],geometry={},
             root={},sections={},paths=[],materials={},member_actions={},summary={},inputs=_safe(asdict(c)) if isinstance(c,WeldedAngleGusset) else _safe(c),
             family=FAMILY,connection_type=CONNECTION_TYPE,component_version=COMPONENT_VERSION,units=dict(UNITS),scope=SCOPE,exclusions=list(EXCLUSIONS))
    errors=input_errors(c)
    if errors:
        for n,e in enumerate(errors):_issue(out,'input_'+str(n),'invalid_input',e)
        return _finalize(out)
    out['fixed_assumptions']=c.fixed_assumptions
    conditions=[(c.support_member not in ('beam','column'),'member','Membro de apoio deve ser viga ou pilar.'),
      (c.support_face!='flange','face','Ligação direta à alma W ainda não qualificada; esta rota usa mesa exterior centrada na alma.'),
      (get_angle(c.angle_profile) is None,'angle_catalog','Cantoneira não reconhecida; selecionar identidade exata de fabricante e linha do catálogo.'),
      (c.angle_weld_edge_detail not in ('ordinary','reinforced'),'angle_weld_edge_detail','Detalhe de borda deve ser ordinary ou reinforced.'),
      (c.angle_weld_edge_detail == 'reinforced' and c.angle_profile == LEGACY_ARCELOR_ID,'legacy_edge_detail','Seção ArcelorMittal legada conserva o detalhe original sem reforço de borda.'),
      (c.support_profile not in SUPPORT_CATALOG,'support_catalog','Perfil W laminado não reconhecido; selecionar identidade completa do catálogo.'),
      (c.N<0,'compression','N negativo é compressão; não é convertido em módulo nem aprovado pelo método de tração.'),
      (any(x!=0 for x in (c.V,c.M,c.torsion)),'external_actions','Ações V/M/T externas preservadas, mas fora desta rota axial; M geométrico da raiz é calculado normalmente.'),
      (not c.static or c.fatigue or c.seismic,'nonstatic','Exige solicitação estática sem fadiga/sismo para6.1.8.2.'),
      (not c.normal_combination,'combination','Fatores limitados a combinações últimas normais.'),
      (not c.minimum_force and 0<=c.N<45000,'minimum_force','Sem exceção declarada, desativar o candidato45kN impede aprovação para N<45kN.')]
    for test,id,msg in conditions:
        if test:_issue(out,id,'outside_scope',msg)
    A=get_angle(c.angle_profile)
    material_objs=[]
    for role,name,thickness in [('angle',c.angle_steel,A['t'] if A else 0.),('gusset',c.gusset_steel,c.plate_t),('support',c.support_steel,SUPPORT_CATALOG.get(c.support_profile,SUPPORT)['tf'])]:
        mat=MATERIALS.get(name)
        if not mat:
            _issue(out,role+'_material','outside_scope',role+': material fora do catálogo.');continue
        okay=(mat.plate_allowed and mat.plate_min<=thickness<=mat.plate_max if role=='gusset' else mat.rolled_allowed and mat.profile_min<=thickness<=mat.profile_max)
        if not okay:_issue(out,role+'_material_product','outside_scope',role+': produto/espessura fora do intervalo do aço selecionado.')
        material_objs.append(mat);out['materials'][role]=dict(name=name,fy=mat.fy,fu=mat.fu,thickness=thickness,source=mat.source)
    for interface,name in [('angle_weld',c.angle_electrode),('root_weld',c.root_electrode)]:
        if name not in ELECTRODES:_issue(out,interface+'_electrode','outside_scope','Consumível não reconhecido.')
        else:out['materials'][interface]=dict(name=name,fw=ELECTRODES[name])
    try:
        g=_geometry(c,out)
        if g is not None:out['geometry']=g
        # Never compute selected geometry using known fixture coefficients after a topology error.
        fatal=any(i['severity'] in ('outside_scope','invalid_geometry') for i in out['issues'])
        if g and not fatal and len(material_objs)==3:
            loads=[('actual','Tração real informada',c.N)]
            if c.minimum_force and c.N<45000:loads.append(('minimum_45kN','Mínimo45kN · NBR6.1.5.2',45000.))
            if c.recommend_half_capacity:
                a=material_objs[0];Ct=max(1-A['centroid']/c.weld_length,.5)
                half=.5*min(A['Ag']*a.fy/GAMMA_A1,Ct*A['Ag']*a.fu/GAMMA_A2)
                loads.append(('recommended_half','Recomendação50% · opção do RT · NBR6.1.5.3',half))
            for id,label,N in loads:_calculate_case(c,g,N,id,label,out,material_objs)
        # Check all serialized arithmetic, including geometry intermediates.
        def check(v):
            if isinstance(v,dict):return all(check(x) for x in v.values())
            if isinstance(v,(tuple,list)):return all(check(x) for x in v)
            return finite_real(v) if isinstance(v,(int,float)) and not isinstance(v,bool) else True
        if not check(out):raise ArithmeticError('Resultado intermediário não finito.')
    except (ArithmeticError,ValueError,TypeError,ZeroDivisionError) as e:
        _issue(out,'numerical_failure','numerical_failure','Cálculo não concluído: '+str(e))
    return _finalize(out)
