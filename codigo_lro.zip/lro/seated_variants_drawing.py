"""Original parameter-driven projections for the three seated connection families.

No source figures are embedded. Continuation lengths and unspecified supporting
hardware are schematic; entered member and seat dimensions are proportional.
"""
from io import BytesIO
import math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Polygon, Circle
from .drawing_annotations import dimension, rendered_wrap

TITLES = {'concrete_end': 'VIGA DE EXTREMIDADE SOBRE CONCRETO',
          'column_continuous': 'VIGA CONTÍNUA SOBRE PILAR',
          'angle_seat': 'VIGA DE EXTREMIDADE SOBRE CANTONEIRA'}
INK, BEAM, SUPPORT, STIFF = '#263c4c', '#82b9c1', '#cedbe4', '#edc17d'


def _n(v):
    return f'{v:g}'.replace('.', ',')


def _figure(c):
    fig = plt.figure(figsize=(11.2, 8.6), facecolor='white')
    def ft(y, s, size=10, **kw):
        return fig.text(.045, y, s, fontsize=size, color=INK, parse_math=False, **kw)
    ft(.95, TITLES.get(c.variant, 'VARIANTE NÃO RECONHECIDA'), 16, weight='bold')
    ft(.915, 'Croqui original dos dados atuais · dimensões em mm · sem liberação para fabricação', 10)
    try:
        from .seated_variants import input_errors
        if input_errors(c):
            raise ValueError('Entradas inválidas')
        values = [getattr(p, k) for p in (c.beam, c.support) for k in ('d', 'bf', 'tf', 'tw')]
        if c.variant == 'angle_seat':
            values += [c.angle_horizontal, c.angle_vertical, c.angle_thickness, c.angle_length]
        else:
            values += [c.bearing_length, c.bearing_width]
        if c.variant not in TITLES or any(not math.isfinite(v) or v <= 0 or v > 1e5 for v in values):
            raise ValueError('Dimensões inválidas')
        if any(p.d <= 2*p.tf or p.bf <= p.tw for p in (c.beam, c.support)):
            raise ValueError('Seção sem geometria física')
        if any(not math.isfinite(v) or v < 0 or v > 1e5 for v in (c.packer_thickness, c.angle_gap, c.angle_root_radius)):
            raise ValueError('Afastamento ou calço inválido')
    except (ValueError, TypeError, AttributeError):
        ft(.72, 'Geometria não representada: corrija as dimensões de entrada.', 13)
        ft(.65, 'Nenhuma geometria de exemplo substitui os dados atuais.')
        return fig
    u, p = c.beam, c.support
    def axis(bounds):
        ax = fig.add_axes(bounds); ax.set_aspect('equal'); ax.axis('off'); return ax
    a, b = axis([.045,.30,.57,.53]), axis([.665,.30,.29,.53])
    def rect(ax, x, z, w, h, color, gid, **kw):
        q = Rectangle((x,z),w,h,facecolor=color,edgecolor=INK,linewidth=.8,**kw)
        q.set_gid(gid); ax.add_patch(q)
    def line(ax,x,z,gid,**kw):
        q, = ax.plot(x,z,color=kw.pop('color',INK),linewidth=kw.pop('lw',1),**kw);q.set_gid(gid)
    def txt(ax,x,z,s,**kw):
        ax.text(x,z,s,fontsize=8,parse_math=False,color=INK,**kw)
    def dim(ax,p1,p2,s,gid,**kw):
        ar,lab=dimension(ax,p1,p2,s,fontsize=8,**kw);ar.set_gid(gid+'_span');lab.set_gid(gid)
    def cut(ax,x,z,h,gid):
        line(ax,[x]*2,[z,z+h],gid+'_mask',color='white',lw=4)
        line(ax,[x,x,x-7,x+7,x,x],[z,z+h*.42,z+h*.47,z+h*.53,z+h*.58,z+h],gid)
    L, W, pack = c.bearing_length, c.bearing_width, c.packer_thickness
    if c.variant == 'angle_seat':
        from .seated_variants import evaluate
        derived = evaluate(c).get('parameters', {}).get('bs_mm')
        if derived is None or not math.isfinite(derived) or derived <= 0:
            ft(.72, 'Contato da cantoneira não representado: cálculo fora do escopo.', 12)
            return fig
        L, W, pack = derived, min(c.angle_length, u.bf), 0.
    length=max(u.d*1.25,L*2,300)
    support_h=max(u.d*.6,150)
    if c.variant == 'angle_seat':
        x0,x1=c.angle_gap,c.angle_gap+length
        contact0, contact1=x0,x0+L
        H,T=c.angle_horizontal,c.angle_thickness
        zbase=pack
        rect(a,-p.d,-support_h,p.d,support_h+u.d*.8,SUPPORT,'column_side')
        rect(a,-p.tf,-support_h,p.tf,support_h+u.d*.8,'#aabdc9','column_face_flange')
        poly=Polygon([(0,-c.angle_vertical),(T,-c.angle_vertical),(T,-T),(H,-T),(H,0),(0,0)],closed=True,facecolor=STIFF,edgecolor=INK)
        poly.set_gid('unstiffened_angle');a.add_patch(poly)
        dim(a,(0,-c.angle_vertical-25),(H,-c.angle_vertical-25),'aba h = '+_n(H),'angle_horizontal')
        dim(a,(-p.d-25,-c.angle_vertical),(-p.d-25,0),'aba v = '+_n(c.angle_vertical),'angle_vertical',rotation=90)
        txt(a,5,-c.angle_vertical-55,'Fixação '+('B9: 4 M20 · furos 22' if c.attachment=='bolted' else 'soldada ao pilar: não detalhada'))
        if c.attachment=='bolted' and c.bolt_top>0 and c.bolt_pitch>0:
            for i in range(2):
                zz=-c.bolt_top-i*c.bolt_pitch
                line(a,[-p.tf-16,T+13],[zz,zz],'seat_bolt_side_'+str(i),lw=3)
        left,right=-p.d-70,x1+35
        bottom=-max(support_h,c.angle_vertical)-90
        cut(a,x1,zbase,u.d,'beam_right_continuation')
    else:
        contact0,contact1=-L/2,L/2
        x0,x1=-length,(L/2 if c.variant=='concrete_end' else length)
        zbase=pack
        if c.variant=='concrete_end':
            rect(a,-L/2,-support_h,L,support_h,'#e6e4df','concrete_pad',hatch='..')
            txt(a,0,-support_h*.60,'Concreto',ha='center')
        else:
            rect(a,-p.d/2,-support_h,p.d,support_h,SUPPORT,'column_elevation')
            for x in (-p.d/2,p.d/2-p.tf):
                rect(a,x,-support_h,p.tf,support_h,'#aabdc9','column_elevation_flange_'+str(x))
            line(a,[-p.d/2,p.d/2],[0,0],'column_top',lw=2)
            txt(a,0,-support_h*.60,'Topo do pilar',ha='center')
            cut(a,x1,zbase,u.d,'beam_right_continuation')
        cut(a,x0,zbase,u.d,'beam_left_continuation')
        left,right=x0-60,x1+65
        bottom=-support_h-80
    # Seat / packer dimensions belong to the actual entered contact footprint.
    if pack>0: rect(a,contact0,0,L,pack,'#ba9775','packer')
    rect(a,x0,zbase,x1-x0,u.tf,BEAM,'beam_bottom_flange')
    rect(a,x0,zbase+u.tf,x1-x0,u.d-2*u.tf,BEAM,'beam_web',alpha=.4)
    rect(a,x0,zbase+u.d-u.tf,x1-x0,u.tf,BEAM,'beam_top_flange')
    if c.supported_stiffeners:
        sx=(contact0+contact1)/2
        rect(a,sx-u.tw/2,zbase+u.tf,u.tw,u.d-2*u.tf,STIFF,'supported_stiffener_symbol')
    # Break symbols are drawn after member patches so the continuation is clear.
    if c.variant!='angle_seat': cut(a,x0,zbase,u.d,'left_continuation_visible')
    if c.variant!='concrete_end': cut(a,x1,zbase,u.d,'right_continuation_visible')
    line(a,[contact0,contact1],[zbase,zbase],'bearing_contact',color='#985031',lw=2.5)
    dim(a,(contact0,zbase+u.d+30),(contact1,zbase+u.d+30),('bs calculado = ' if c.variant=='angle_seat' else 'apoio = ')+_n(round(L,2)),'bearing_length')
    for x in (contact0,contact1): line(a,[x,x],[zbase,zbase+u.d+35],'contact_projection_'+str(x),linestyle=':',lw=.6)
    dim(a,(right-15,zbase),(right-15,zbase+u.d),'d = '+_n(u.d),'beam_depth',rotation=90)
    a.set_xlim(left,right);a.set_ylim(bottom,zbase+u.d+75)
    # Transverse projection: actual beam section and the transverse seat width.
    rect(b,-u.bf/2,zbase,u.bf,u.tf,BEAM,'section_bottom_flange')
    rect(b,-u.tw/2,zbase+u.tf,u.tw,u.d-2*u.tf,BEAM,'section_web')
    rect(b,-u.bf/2,zbase+u.d-u.tf,u.bf,u.tf,BEAM,'section_top_flange')
    if pack>0: rect(b,-W/2,0,W,pack,'#ba9775','section_packer')
    if c.variant=='concrete_end':
        rect(b,-W/2,-support_h,W,support_h,'#e6e4df','section_concrete',hatch='..')
    elif c.variant=='column_continuous':
        rect(b,-p.bf/2,-support_h,p.bf,support_h,SUPPORT,'column_front')
    else:
        rect(b,-p.bf/2,-c.angle_vertical-12,p.bf,c.angle_vertical+12,SUPPORT,'column_flange_behind_seat')
        rect(b,-c.angle_length/2,-c.angle_vertical,c.angle_length,c.angle_vertical,STIFF,'angle_front')
        if c.attachment=='welded':
            weld_z0=-c.angle_vertical/2-c.weld_effective_length/2
            for sign in (-1,1):
                wx=sign*(c.angle_length+c.weld_leg)/2
                line(b,[wx,wx],[weld_z0,weld_z0+c.weld_effective_length],'vertical_weld_'+str(sign),color='#a84a36',lw=max(1.,c.weld_leg/2))
        if c.attachment=='bolted' and min(c.bolt_top,c.bolt_pitch,c.bolt_gauge)>0:
            for i in range(2):
                for j in (-1,1):
                    hole=Circle((j*c.bolt_gauge/2,-c.bolt_top-i*c.bolt_pitch),11,facecolor='white',edgecolor=INK)
                    hole.set_gid('seat_bolt_hole_'+str(i)+'_'+str(j));b.add_patch(hole)
            dim(b,(-c.bolt_gauge/2,-c.angle_vertical-20),(c.bolt_gauge/2,-c.angle_vertical-20),'g = '+_n(c.bolt_gauge),'bolt_gauge')
            dim(b,(c.angle_length/2+18,-c.bolt_top),(c.angle_length/2+18,-c.bolt_top-c.bolt_pitch),'p = '+_n(c.bolt_pitch),'bolt_pitch',rotation=90)
        line(b,[-c.angle_length/2,c.angle_length/2],[-c.angle_thickness]*2,'angle_toe_edge')
    if c.supported_stiffeners:
        for sign in (-1,1):
            rect(b, u.tw/2 if sign>0 else -u.bf/2, zbase+u.tf, (u.bf-u.tw)/2, u.d-2*u.tf, STIFF, 'supported_stiffener_indication_'+str(sign), alpha=.35, linestyle='--')
    dim(b,(-u.bf/2,zbase+u.d+30),(u.bf/2,zbase+u.d+30),'bf = '+_n(u.bf),'beam_width')
    dim(b,(-W/2,bottom+25),(W/2,bottom+25),'larg. apoio = '+_n(W),'bearing_width')
    width=max(u.bf,W,p.bf if c.variant in ('column_continuous','angle_seat') else W)
    b.set_xlim(-width/2-40,width/2+40);b.set_ylim(bottom,zbase+u.d+75)
    ft(.855,'1 · ELEVAÇÃO LONGITUDINAL',11,weight='bold')
    fig.text(.665,.855,'2 · SEÇÃO NO APOIO',fontsize=11,color=INK,weight='bold')
    ft(.255,rendered_wrap('Viga: '+u.name+' · aço '+c.beam_steel+' · V = '+f'{c.V/1000:.2f}'.replace('.', ',')+' kN · calço = '+_n(pack)+' mm',880,10))
    ft(.220,('Pilar: '+p.name+' · aço '+c.support_steel) if c.variant!='concrete_end' else 'Sem ancoragem; reação e contato entregues ao civil. Concreto fora deste cálculo.')
    ft(.185,'Enrijecedores na viga apoiada: '+('indicados simbolicamente, sem crédito resistente.' if c.supported_stiffeners else 'não previstos.'))
    ft(.150,'Enrijecedores na viga receptora: '+('solicitados, mas não aplicáveis a esta família (apoio em concreto/pilar).' if c.receiving_stiffeners else 'não aplicáveis a esta família.'))
    if c.variant=='angle_seat' and c.attachment=='welded':
        ft(.115,'Duas soldas verticais: perna '+_n(c.weld_leg)+' mm · Le = '+_n(c.weld_effective_length)+' mm · '+(c.weld_category+' · '+c.weld_electrode if c.weld_mode=='automatic' else 'resistência manual com fonte'),9)
    elif c.variant=='angle_seat' and c.attachment=='bolted':
        ft(.115,'B9 · 4 M20 8.8N/S · furos 22 mm · cabeças na cantoneira / porcas atrás da mesa · sem calço',9)
    else:
        ft(.115,'Seções e contato proporcionais; trechos de continuidade e suporte são esquemáticos.',9)
    ft(.080,'Croqui sem liberação para fabricação; verificações locais e limites estão no memorial.',9)
    ft(.045,'Amarelo: cantoneira / indicação de enrijecedores. Nenhuma figura ou tabela editorial reproduzida.',9)
    return fig


def create_svg(c):
    with matplotlib.rc_context({'svg.fonttype':'none','font.family':'DejaVu Sans','text.usetex':False}):
        fig=_figure(c)
        try:
            out=BytesIO();fig.savefig(out,format='svg',metadata={'Date':None});return out.getvalue().decode('utf-8')
        finally: plt.close(fig)


def png_bytes(c):
    with matplotlib.rc_context({'font.family':'DejaVu Sans','text.usetex':False}):
        fig=_figure(c)
        try:
            out=BytesIO();fig.savefig(out,format='png',dpi=160);return out.getvalue()
        finally: plt.close(fig)
