"""R016: two physical beam-web angles bolted to a W-column flange.

Canonical units N, mm, MPa. The beam and support are distinct physical members.
Only the conventional symmetric V-only mechanism is a candidate for closure.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict, fields, replace
import math
from .angle_catalog_selection import (native_connection, valid_native_fields, identity_errors,
    missing_data_errors, STRING_FIELDS as CATALOG_STRINGS, BOOL_FIELDS as CATALOG_BOOLS)
from .models import Profile, profiles, STEELS, BOLTS, finite_real

FAMILY = 'Cantoneiras duplas · R016 · cortante'
CONNECTION_TYPE = 'double_angle_r016_bolted_shear'
COMPONENT_VERSION = '0.9.1-angle-dev'
NBR = 'ABNT NBR 8800:2024, versão corrigida 2025'
GAMMA_A1, GAMMA_A2 = 1.10, 1.35
SCOPE = ('R016: duas cantoneiras iguais e simétricas, parafusadas à alma de viga W sem recortes '
         'e à mesa de pilar W. Modelo convencional flexível sob V estático; N=M=T=0.')
EXCLUSIONS = [
    'Cantoneira única, abas estendidas, múltiplas colunas de parafusos e assimetria exigem outro modelo.',
    'R015 soldada, R017 em alma de apoio e vigas recortadas não são dimensionadas nesta rota.',
    'Não avalia fadiga, impacto, atrito de serviço, rigidez rotacional ou estabilidade global dos membros.',
    'O dimensionamento global do apoio deve receber a reação e o momento de transporte indicados.',
]

@dataclass(frozen=True)
class DoubleAngle:
    beam: Profile
    support: Profile
    project: str = 'R016 · duas cantoneiras parafusadas'
    kind: str = 'column_flange'
    angle_count: int = 2
    symmetric: bool = True
    beam_leg: float = 76.0
    support_leg: float = 76.0
    t: float = 6.4
    root_radius: float = 8.0
    length: float = 200.0
    angle_top: float = 77.5
    beam_gauge: float = 45.0
    support_gauge: float = 45.0
    web_rows: int = 3
    support_rows: int = 3
    web_columns: int = 1
    support_columns: int = 1
    web_pitch: float = 60.0
    support_pitch: float = 60.0
    web_end_top: float = 40.0
    support_end_top: float = 40.0
    gap: float = 10.0
    support_edge_top: float = 500.0
    support_edge_bottom: float = 500.0
    beam_steel: str = 'ASTM A572 Gr.50'
    support_steel: str = 'ASTM A572 Gr.50'
    angle_steel: str = 'ASTM A36'
    bolt: str = 'ASTM F3125 A325'
    db: float = 20.0
    hole_diameter: float = 22.0
    hole_type: str = 'standard_round'
    drilled: bool = False
    web_threads_excluded: bool = False
    support_threads_excluded: bool = False
    exposure: str = 'painted'
    V: float = 100000.0
    N: float = 0.0
    M: float = 0.0
    torsion: float = 0.0
    cope: str = 'none'
    static: bool = True
    normal_combination: bool = True
    no_slip_required: bool = False
    tool_radius: float = 22.0
    fabrication_clearance: float = 3.0
    notes: str = ''
    angle_catalog_id: str = ''
    angle_root_source: str = ''
    angle_root_confirmed: bool = False


    @property
    def fixed_assumptions(self):
        return {'topology':'R016_two_equal_angles_beam_web_to_column_flange',
                'web_bolts_shared':True, 'web_shear_planes':2, 'support_shear_planes':1,
                'contact':'firm_direct_contact_at_all_interfaces_no_shims_no_gaps',
                'assembly':'F3125 bolts, nuts and washers installed to NBR6.8; no credit for friction or pretension',
                'support_continuity':'rolled_W_column_no_local_notches_openings_or_welded_discontinuities',
                'beam_continuity':'rolled_W_without_copes_or_additional_openings',
                'normal_ultimate_combinations_only':True,
                'load_model':'conventional_flexible_LCPP_V_only',
                'serial_interfaces':'beam_web_then_two_angle_legs_then_column_flange',
                'geometric_eccentricity':'conventional_standard_gages_only_not_zero_by_NMT_zero',
                'bearing_deformation_is_design_limitation':True,
                'net_hole_policy':'Table14_maximum_plus_2mm_unless_documented_drilled',
                'gamma_a1':GAMMA_A1,'gamma_a2':GAMMA_A2}

    def to_dict(self):
        errors=input_errors(self)
        if errors: raise ValueError('; '.join(errors))
        return {'schema_version':1,'connection_type':CONNECTION_TYPE,'component_version':COMPONENT_VERSION,
                'connection':native_connection(self),'units':{'force':'N','length':'mm','stress':'MPa','moment':'N mm'},
                'fixed_assumptions':self.fixed_assumptions}

    @classmethod
    def from_dict(cls,data):
        allowed={'schema_version','connection_type','component_version','connection','units','fixed_assumptions'}
        if not isinstance(data,dict) or set(data)!=allowed:raise ValueError('Projeto R016: campos ausentes ou desconhecidos.')
        if type(data['schema_version']) is not int or data['schema_version']!=1 or data['connection_type']!=CONNECTION_TYPE or data['component_version']!=COMPONENT_VERSION:
            raise ValueError('Família ou versão R016 incompatível.')
        raw=data['connection']
        if not valid_native_fields(raw, cls):raise ValueError('Dados R016 incompletos ou desconhecidos.')
        raw=dict(raw)
        for key in ('beam','support'):
            p=raw[key]
            if not isinstance(p,dict) or set(p)!={f.name for f in fields(Profile)}:raise ValueError(f'{key}: perfil inválido ou incompleto.')
            raw[key]=Profile(**p)
        c=cls(**raw);canonical=c.to_dict()
        for key in ('units','fixed_assumptions'):
            if data[key]!=canonical[key]:raise ValueError(f'{key}: premissas/unidades incompatíveis, sem conversão silenciosa.')
        return c


def presets():
    p=profiles();base=DoubleAngle(p['W 360 x 51,0'],p['W 310 x 97,0 (H)'],length=260.,angle_top=47.5,web_rows=4,support_rows=4)
    return {'R016 · W360/W310 · M20 · V=100 kN':base,
            'R016 · cortante invertido':replace(base,project='R016 · V invertido',V=-100000.),
            'R016 · exemplo de solicitação elevada':replace(base,project='R016 · solicitação elevada',V=500000.)}


def input_errors(c):
    if not isinstance(c,DoubleAngle):return ['A entrada deve ser DoubleAngle.']
    errors=[]
    strings={'project','kind','beam_steel','support_steel','angle_steel','bolt','hole_type','exposure','cope','notes'}
    bools={'symmetric','drilled','web_threads_excluded','support_threads_excluded','static','normal_combination','no_slip_required'}
    ints={'angle_count','web_rows','support_rows','web_columns','support_columns'}
    nonnegative={'root_radius','angle_top','gap','fabrication_clearance'}
    for f in fields(c):
        name=f.name;v=getattr(c,name)
        if name in ('beam','support'):
            if not isinstance(v,Profile):errors.append(name+': perfil documentado obrigatório.');continue
            for key in ('d','bf','tw','tf','clear','area','mass'):
                if not finite_real(getattr(v,key)) or getattr(v,key)<=0:errors.append(f'{name}.{key}: positivo finito obrigatório.')
            for key in ('name','family','source'):
                if not isinstance(getattr(v,key),str):errors.append(f'{name}.{key}: texto obrigatório.')
        elif name in strings | CATALOG_STRINGS:
            if not isinstance(v,str):errors.append(name+': texto obrigatório.')
        elif name in bools | CATALOG_BOOLS:
            if type(v) is not bool:errors.append(name+': booleano explícito obrigatório.')
        elif name in ints:
            if type(v) is not int or not 1<=v<=20:errors.append(name+': inteiro entre 1 e 20 obrigatório.')
        elif not finite_real(v):errors.append(name+': número finito obrigatório.')
        elif name in nonnegative:
            if v<0:errors.append(name+': valor não negativo obrigatório.')
        elif name not in ('V','N','M','torsion') and v<=0:errors.append(name+': dimensão positiva obrigatória.')
    return errors + (identity_errors(c, 1) if not errors else [])


# Exact diameter systems remain distinct. Table 14 / Table 16, current NBR.
HOLES = {12.7:14.2875,15.875:17.4625,19.05:20.6375,22.225:23.8125,
         25.4:28.575,28.575:31.75,31.75:34.925,
         16.:18.,20.:22.,22.:24.,24.:27.,27.:30.,30.:33.}
EDGES = {12.7:19.,15.875:22.,19.05:25.,22.225:28.,25.4:32.,28.575:38.,31.75:41.,
         16.:22.,20.:26.,22.:28.,24.:30.,27.:34.,30.:38.}
INDUSTRIAL = {16.:(35.,50.),20.:(40.,60.),24.:(50.,75.),30.:(60.,90.)}
TOL=1e-10


def bolt_shear_resistance(db,fub,threads_excluded=False,grip_factor=1.):
    """One physical shear plane; NBR6.3.3.2 current coefficients."""
    return (.56 if threads_excluded else .45)*math.pi*db**2/4*fub/GAMMA_A2*grip_factor


def shear_resistances(Ag,An,fy,fu):
    return .6*fy*Ag/GAMMA_A1,.6*fu*An/GAMMA_A2


def block_resistance(Agv,Anv,Ant,fy,fu,Cts):
    return (min(.6*fu*Anv,.6*fy*Agv)+Cts*fu*Ant)/GAMMA_A2


def bearing_resistance(db,lc,t,fu):
    return (2.4*db if lc is None else min(1.2*lc,2.4*db))*t*fu/GAMMA_A2


def _safe(value):
    if isinstance(value,float) and not math.isfinite(value):return str(value)
    if isinstance(value,dict):return {str(k):_safe(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)):return [_safe(v) for v in value]
    return value if value is None or isinstance(value,(str,int,float,bool)) else repr(value)


def _issue(out,severity,text,reference='',**details):
    out['issues'].append(dict(severity=severity,text=text,reference=reference,**details))


def _check(out,identifier,label,component,capacity,fraction,formula,reference,**details):
    if not finite_real(capacity) or capacity<=0 or not finite_real(fraction) or fraction<=0:
        raise ArithmeticError(identifier+': resistência/fração não positiva ou não finita.')
    adopted=abs(out['load_model']['Vd_N']);actual=abs(out['load_model']['Vsd_N'])
    demand=adopted*fraction;real=actual*fraction
    row=dict(id=identifier,label=label,component=component,demand_N=demand,actual_demand_N=real,
        design_capacity_N=capacity,utilization=demand/capacity,actual_utilization=real/capacity,
        status='PASS' if demand/capacity<=1+TOL else 'FAIL',actual_status='PASS' if real/capacity<=1+TOL else 'FAIL',
        demand_fraction_of_total_V=fraction,equivalent_total_V_capacity_N=capacity/fraction,
        formula=formula,reference=reference,**details)
    out['checks'].append(row);return row


def geometry(c,out):
    dh=c.hole_diameter;d14=HOLES.get(c.db,dh);dn=d14+(0. if c.drilled else 2.)
    web_bottom=c.length-c.web_end_top-(c.web_rows-1)*c.web_pitch
    sup_bottom=c.length-c.support_end_top-(c.support_rows-1)*c.support_pitch
    support_z=c.beam.tw/2+c.support_gauge
    beam_root=(c.beam.d-c.beam.clear)/2
    support_r=max(0.,(c.support.d-2*c.support.tf-c.support.clear)/2)
    g=dict(valid=False,dh=dh,dn=dn,table14_max_hole_mm=d14,physical_hole_diameter_mm=dh,
        net_deduction_diameter_mm=dn,web_end_bottom_mm=web_bottom,support_end_bottom_mm=sup_bottom,
        web_hole_y_mm=[c.angle_top+c.web_end_top+i*c.web_pitch for i in range(c.web_rows)],
        support_hole_y_mm=[c.angle_top+c.support_end_top+i*c.support_pitch for i in range(c.support_rows)],
        web_hole_x_mm=c.beam_gauge,support_hole_z_mm=[-support_z,support_z],
        web_free_toe_edge_mm=c.beam_leg-c.beam_gauge,support_free_toe_edge_mm=c.support_leg-c.support_gauge,
        beam_end_distance_mm=c.beam_gauge-c.gap,column_flange_edge_mm=c.support.bf/2-support_z,
        angle_beam_clear_top_mm=c.angle_top-beam_root,
        angle_beam_clear_bottom_mm=c.beam.d-beam_root-c.angle_top-c.length,
        column_top_y_mm=c.angle_top+c.support_end_top-c.support_edge_top,
        column_bottom_y_mm=c.angle_top+c.support_end_top+(c.support_rows-1)*c.support_pitch+c.support_edge_bottom,
        column_root_radius_envelope_mm=support_r,web_grip_mm=c.beam.tw+2*c.t,support_grip_mm=c.support.tf+c.t,
        physical_angle_count=c.angle_count,shared_web_bolt_count=c.web_rows*c.web_columns,
        each_support_leg_bolt_count=c.support_rows*c.support_columns,
        total_bolt_count=c.web_rows*c.web_columns+c.angle_count*c.support_rows*c.support_columns,
        industrial_N_intervals=c.web_rows-1,industrial_Z_mm=c.beam.d-2*c.beam.tf,
        checks=[],errors=[],detailing_checks=[])
    out['geometry']=g
    def scalar(key,value,limit,relation,category,text,reference='Geometria física R016'):
        passed=(value>limit if relation=='>' else value>=limit*(1-TOL) if relation=='>=' else value<=limit*(1+TOL))
        row=dict(id=key,actual=value,limit=limit,relation=relation,category=category,passed=passed,units='mm',reference=reference)
        g['checks'].append(row)
        if category=='detail':g['detailing_checks'].append(row)
        if not passed:
            if category=='geometry':g['errors'].append(key)
            severity={'geometry':'invalid_geometry','detail':'detail_fail','preset':'preset_deviation','access':'access_pending','model':'engineering_pending'}[category]
            _issue(out,severity,f'{text}: {value:g} mm; requerido {relation} {limit:g} mm.',reference,field=key)
    for name,p in [('beam',c.beam),('support',c.support)]:
        scalar(name+'_web_height',p.d-2*p.tf,0.,'>','geometry',name+': alma entre mesas')
        scalar(name+'_root_clear',p.clear,p.d-2*p.tf,'<=','geometry',name+': altura livre de raízes')
        scalar(name+'_flange_width',p.bf,p.tw,'>','geometry',name+': mesa maior que espessura da alma')
    for name,b in [('beam',c.beam_leg),('support',c.support_leg)]:
        scalar(name+'_angle_leg',b-c.t-c.root_radius,0.,'>','geometry',name+': aba reta disponível')
    scalar('angle_clear_top',g['angle_beam_clear_top_mm'],0.,'>=','geometry','Cantoneiras não cruzam a raiz superior da viga')
    scalar('angle_clear_bottom',g['angle_beam_clear_bottom_mm'],0.,'>=','geometry','Cantoneiras não cruzam a raiz inferior da viga')
    scalar('angle_support_fit',c.beam.tw+2*c.support_leg,c.support.bf,'<=','geometry','Par de abas dentro da mesa do pilar')
    scalar('conventional_restraint_depth',c.length,c.beam.d/2,'>=','model','Comprimento convencional para impedimento do giro longitudinal','Gerdau2018 p.20; AISC Steel Interchange abr.2010; NBR6.1.7')
    scalar('conventional_upper_location',g['web_hole_y_mm'][0],c.beam.d-g['web_hole_y_mm'][-1],'<=','model','Posição do grupo junto ao topo ou centralizada, dentro da rota convencional','Gerdau2018 p.20')
    scalar('beam_end_hole',g['beam_end_distance_mm']-dh/2,0.,'>','geometry','Furo integral na alma da viga')
    scalar('angle_web_toe',g['web_free_toe_edge_mm']-dh/2,0.,'>','geometry','Furo integral na aba da viga')
    scalar('angle_support_toe',g['support_free_toe_edge_mm']-dh/2,0.,'>','geometry','Furo integral na aba de apoio')
    scalar('column_toe_hole',g['column_flange_edge_mm']-dh/2,0.,'>','geometry','Furo integral na mesa do pilar')
    for name,gauge in [('web',c.beam_gauge),('support',c.support_gauge)]:
        scalar(name+'_hole_root',gauge-c.t-c.root_radius-dh/2,0.,'>=','geometry',name+': furo fora da concordância da cantoneira')
        scalar(name+'_tool_root',gauge-c.t-c.root_radius,c.tool_radius+c.fabrication_clearance,'>=','access',name+': acesso da ferramenta junto à concordância')
    scalar('column_back_tool_root',support_z-c.support.tw/2-support_r,c.tool_radius+c.fabrication_clearance,'>=','access','Ferramenta/porca no verso da mesa do pilar, fora da raiz')
    for name,value in [('top',g['angle_beam_clear_top_mm']),('bottom',g['angle_beam_clear_bottom_mm'])]:
        scalar('angle_'+name+'_fabrication',value,c.fabrication_clearance,'>=','access','Folga de fabricação '+name)
        scalar('angle_'+name+'_industrial',c.angle_top-c.beam.tf if name=='top' else c.beam.d-c.beam.tf-c.angle_top-c.length,20.,'>=','preset','Folga R016 junto à mesa '+name,'R016 p.19: referência de oficina')
    emin=EDGES.get(c.db,0.);pmin=max(2.7*c.db,dh+c.db)
    for family,n,pitch,top,bottom,tmin in [('web',c.web_rows,c.web_pitch,c.web_end_top,web_bottom,min(c.t,c.beam.tw)),('support',c.support_rows,c.support_pitch,c.support_end_top,sup_bottom,min(c.t,c.support.tf))]:
        if n>1:
            scalar(family+'_pitch_physical',pitch-dh,0.,'>','geometry',family+': furos não se sobrepõem')
            scalar(family+'_pitch_min',pitch,pmin,'>=','detail',family+': espaçamento mínimo',NBR+', 6.3.9')
            scalar(family+'_pitch_max',pitch,min(14*tmin,180.) if c.exposure=='weathering' else min(24*tmin,300.),'<=','detail',family+': espaçamento máximo',NBR+', 6.3.10')
            if pitch<3*c.db:_issue(out,'warning',f'{family}: p={pitch:g} mm inferior à preferência 3db={3*c.db:g} mm.',NBR+', 6.3.9')
        for position,e in [('top',top),('bottom',bottom)]:
            scalar(family+'_end_'+position,e-dn/2,0.,'>','geometry',family+': ligamento líquido de extremidade '+position)
            scalar(family+'_edge_'+position+'_min',e,emin,'>=','detail',family+': borda mínima '+position,NBR+', tabela16; exceção por resistência não automatizada')
            scalar(family+'_edge_'+position+'_max',e,min(12*c.t,150.),'<=','detail',family+': borda máxima '+position,NBR+', 6.3.12')
        scalar(family+'_net_shear_length',c.length-n*dn,0.,'>','geometry',family+': comprimento líquido ao cisalhamento')
        for k in range(1,n+1):
            scalar(family+f'_net_prefix{k}',min(top,bottom)+(k-1)*pitch-(k-.5)*dn,0.,'>','geometry',family+f': área líquida do prefixo {k}')
    edges=[('angle_web_toe',g['web_free_toe_edge_mm'],c.t),('angle_support_toe',g['support_free_toe_edge_mm'],c.t),
           ('beam_end',g['beam_end_distance_mm'],c.beam.tw),('column_toe',g['column_flange_edge_mm'],c.support.tf)]
    for name,e,t in edges:
        scalar(name+'_net',e-dn/2,0.,'>','geometry',name+': ligamento líquido')
        scalar(name+'_min',e,emin,'>=','detail',name+': borda mínima',NBR+', tabela16; exceção por resistência não automatizada')
        scalar(name+'_max',e,min(12*t,150.),'<=','detail',name+': borda máxima da parte ligada',NBR+', 6.3.12')
    for name,e in [('top',c.support_edge_top),('bottom',c.support_edge_bottom)]:
        scalar('column_end_'+name,e-dn/2,0.,'>','geometry','Coluna: furo dentro da extremidade real '+name)
        scalar('column_end_'+name+'_min',e,emin,'>=','detail','Coluna: distância mínima à extremidade real '+name,NBR+', tabela16')
    scalar('beam_net_shear',c.beam.clear-c.web_rows*dn,0.,'>','geometry','Seção líquida da alma sem crédito das raízes')
    scalar('support_columns_min',2*support_z,pmin,'>=','detail','Distância entre furos das duas abas na mesa do pilar',NBR+', 6.3.9')
    if c.tool_radius<c.db/2:_issue(out,'access_pending','Raio de ferramenta menor que raio do próprio parafuso; conferir cabeça, porca e arruela.','Montagem')
    if c.db in INDUSTRIAL:
        e,p=INDUSTRIAL[c.db];N=c.web_rows-1;zmin=2*20+2*e+N*p;zmax=zmin+p
        g.update(industrial_end_mm=e,industrial_pitch_mm=p,industrial_Z_min_mm=zmin,industrial_Z_max_mm=zmax)
        if not (math.isclose(c.web_pitch,p) and math.isclose(c.support_pitch,p) and math.isclose(c.web_end_top,e) and math.isclose(web_bottom,e) and math.isclose(c.support_end_top,e) and math.isclose(sup_bottom,e)):
            _issue(out,'preset_deviation','Passos/bordas diferem da tabela R016. É variação de detalhamento; as dimensões reais permanecem no cálculo.','R016 p.19')
        if not zmin<=g['industrial_Z_mm']<zmax:
            _issue(out,'preset_deviation',f'Z={g["industrial_Z_mm"]:g} mm fora da faixa R016 {zmin:g}≤Z<{zmax:g} para N={N} intervalos ({c.web_rows} parafusos). Não é colisão geométrica por si só.','R016 p.19')
    else:_issue(out,'preset_deviation','Parafuso imperial ou diâmetro fora da tabela métrica R016; designação e medidas reais preservadas.','R016 p.19 / NBR tabelas14 e16')
    if c.gap!=10.:_issue(out,'preset_deviation','Folga da ponta difere dos 10 mm do exemplo convencional Gerdau; verificar o detalhe real sem correção automática.','Gerdau2018 p.21')
    g['valid']=not g['errors'];return g


def bearing_rows(out,c,identifier,n,pitch,thickness,fu,fraction,loaded_end,loaded_direction,terminal_cap=False):
    """Normative sum AND direct-force per-hole compatibility, without n*min alias."""
    values=[];caps=[]
    for i in range(n):
        terminal=(i==n-1 if loaded_direction=='down' else i==0)
        lc=None if terminal and terminal_cap else loaded_end-c.hole_diameter/2 if terminal else pitch-c.hole_diameter
        rd=bearing_resistance(c.db,lc,thickness,fu)
        caps.append(rd)
        row=_check(out,identifier+f'_bearing_hole{i+1}',f'Contato/rasgamento · furo {i+1}',identifier,rd,fraction/n,
            'min(1,2 lc;2,4 db) t fu/γa2' if lc is not None else '2,4 db t fu/γa2; sem borda livre vertical',NBR+', 6.3.3.3(a)',
            hole_index=i+1,clear_distance_mm=lc,loaded_direction=loaded_direction,terminal_hole=terminal,thickness_mm=thickness,
            basis='Força direta igual por parafuso; verificação adicional de compatibilidade da distribuição.')
        values.append(row['id'])
    total=_check(out,identifier+'_bearing_group','Contato/rasgamento · soma normativa dos furos',identifier,sum(caps),fraction,
        'Σ Rb,i; cada ligamento na direção efetiva da força',NBR+', 6.3.3.3(a), último parágrafo',
        per_hole_capacities_N=caps,loaded_direction=loaded_direction,bolt_count=n,thickness_mm=thickness)
    return {'per_hole_capacity_N':caps,'normative_sum_N':total['design_capacity_N'],'loaded_direction':loaded_direction,'check_ids':values+[total['id']]}


def l_blocks(out,identifier,n,pitch,end,edge,t,dn,fy,fu,fraction,Cts,direction,reference):
    ids=[]
    for k in range(1,n+1):
        L=end+(k-1)*pitch;Agv=L*t;Anv=(L-(k-.5)*dn)*t;Ant=(edge-.5*dn)*t
        if min(Agv,Anv,Ant)<=0:raise ArithmeticError(identifier+': bloco com área não positiva.')
        rd=block_resistance(Agv,Anv,Ant,fy,fu,Cts)
        row=_check(out,identifier+f'_block_k{k}',f'Bloco L · {k}/{n} furos desde a borda carregada',identifier,rd,fraction*k/n,
            '[min(0,60fu Anv;0,60fy Agv)+Cts fu Ant]/γa2',reference,
            path_family='L',k=k,Agv_mm2=Agv,Anv_mm2=Anv,Ant_mm2=Ant,Cts=Cts,
            gross_shear_length_mm=L,net_shear_length_mm=L-(k-.5)*dn,net_tension_length_mm=edge-.5*dn,
            loaded_direction=direction,force_fraction_of_component=k/n,free_boundary='outer_toe_and_loaded_end')
        ids.append(row['id'])
    return ids


def _evaluate(c):
    out={'status':'INVALID_INPUT','global_pass':False,'issues':[],'checks':[],'geometry':{},'load_model':{},'summary':{},'components':{},
         'physical_angles':[], 'scope':SCOPE,'exclusions':EXCLUSIONS.copy(),'not_applicable':[],
         'inputs':_safe(asdict(c)) if isinstance(c,DoubleAngle) else _safe(c),
         'units':{'force':'N','length':'mm','area':'mm²','stress':'MPa','moment':'N mm'}}
    errors=input_errors(c)
    if not errors:
        errors = missing_data_errors(c)
    if errors:
        for text in errors:_issue(out,'invalid_input',text)
        return out
    for bad,text in [
        (c.beam.family!='W' or c.support.family!='W','Viga e pilar devem ser perfis W laminados neste domínio.'),
        (c.kind!='column_flange','R016 exige mesa de pilar; R017 em alma de apoio tem modelo próprio.'),
        (c.angle_count!=2 or not c.symmetric,'Somente duas cantoneiras iguais e simétricas. Cantoneira única não recebe metade da resistência do par.'),
        (c.web_columns!=1 or c.support_columns!=1,'Múltiplas colunas de parafusos alteram o modelo excêntrico e não são avaliadas.'),
        (any(x!=0 for x in (c.N,c.M,c.torsion)),'N, M ou torção não nulos: modelo V-only não se aplica e não descarta essas ações.'),
        (c.cope!='none','Viga recortada exige verificação própria do trecho; R016 inicial sem recortes.'),
        (not c.static,'Fadiga, impacto, afrouxamento e carregamento cíclico não são resolvidos pela inversão estática de V.'),
        (not c.normal_combination,'Somente combinações últimas normais neste módulo.'),
        (c.no_slip_required,'Exigência de resistência ao deslizamento requer verificação por atrito; contato não substitui serviço.'),
        (c.hole_type!='standard_round','Apenas furos circulares padrão. Rasgos e furos alargados exigem rota própria.'),
        (c.db not in HOLES,'Diâmetro sem linha de furação/detalhamento implementada.'),
        (c.bolt not in ('ASTM F3125 A325','ASTM F3125 A490'),'Classe de parafuso fora das duas classes de alta resistência implementadas.'),
        (c.exposure not in ('painted','weathering'),'Exposição sem critério de espaçamento implementado.'),
        (c.web_rows<2 or c.support_rows<2,'São necessários ao menos dois parafusos por interface no domínio convencional.')]:
        if bad:_issue(out,'unsupported_scope',text,'Domínio convencional R016')
    if c.db in HOLES and not c.db<c.hole_diameter<=HOLES[c.db]:
        _issue(out,'unsupported_scope',f'Furo físico deve satisfazer db<dh≤{HOLES[c.db]:g} mm para este diâmetro.',NBR+', tabela14')
    for name,steel_name,thicknesses in [('beam',c.beam_steel,[c.beam.tw,c.beam.tf]),('support',c.support_steel,[c.support.tw,c.support.tf]),('angle',c.angle_steel,[c.t])]:
        s=STEELS.get(steel_name)
        if s is None or not s.rolled_allowed or any(not s.profile_min<=t<=s.profile_max for t in thicknesses):
            _issue(out,'unsupported_scope',name+': aço/perfil laminado/espessura fora do cadastro válido.',NBR+', tabelaA.2')
    # Standard-gage domain is a documented set, never a universal threshold.
    standard=any(all(math.isclose(a,b,rel_tol=0,abs_tol=1e-8) for a,b in zip(
        (c.beam_leg,c.support_leg,c.t,c.beam_gauge,c.support_gauge),case)) for case in ((76.,76.,6.4,45.,45.),(102.,102.,8.,65.,65.)))
    if not standard:
        _issue(out,'engineering_pending','Geometria alternativa ainda não validada por este modelo. Referências verificadas: L76×76×6,4 g45 e L102×102×8 g65. A pendência é de escopo documental, não um limite normativo nem demonstração de falha física; ampliar o domínio requer validação compatível da flexão das abas e dos grupos excêntricos.','Gerdau2018 p.14,p.21,p.23–25')
    if c.gap==0.:
        _issue(out,'engineering_pending','Folga de ponta igual a zero: a extremidade da viga pode entrar em contato com a mesa do pilar e alterar as forças e a rotação. O modelo flexível convencional não verifica esse contato; as resistências locais permanecem disponíveis, sem atendimento completo. Não se impõe 10 mm como mínimo universal.',NBR+', 6.1.1.3(c–e) e6.1.3; Gerdau2018 p.20')
    g=geometry(c,out)
    if not g['valid']:
        out['status']='INVALID_GEOMETRY';return out
    if any(x['severity']=='unsupported_scope' for x in out['issues']):
        out['status']='OUTSIDE_R016_SCOPE';return out
    # Both static directions are checked when V=0; this does not claim fatigue.
    directions=[1,-1] if c.V==0 else [1 if c.V>0 else -1]
    Vabs=max(abs(c.V),45000.)
    out['load_model']=dict(Vsd_N=c.V,Vd_N=(1 if c.V>=0 else -1)*Vabs,assembly_minimum_N=45000.,
        directions_evaluated=directions,minimum_note='Piso de 45 kN uma única vez no conjunto; 6.1.5.3 axial não impõe metade do cortante da viga.',
        each_angle_force_N=Vabs/2,web_group_force_N=Vabs,each_support_group_force_N=Vabs/2,
        geometric_beam_gauge_mm=c.beam_gauge,geometric_support_gauge_mm=c.support_gauge,
        geometric_transport_moment_reference_Nmm=Vabs*c.beam_gauge,
        eccentricity_model='Modelo convencional flexível LCPP dentro dos gabaritos documentados; excentricidade geométrica existe e não é eliminada por N=M=T=0.',
        external_actions={'V':c.V,'N':c.N,'M':c.M,'torsion':c.torsion},
        column_delivered_vertical_force_N=c.V,column_delivered_transport_moment_about_centroid_Nmm=c.V*c.support.d/2,
        column_transport_note='Reação na face da mesa transportada ao centro do pilar. Somar somente se o modelo global ainda não inclui essa excentricidade.',
        serial_interfaces='Alma da viga → duas cantoneiras → mesa do pilar; capacidades em série não se somam.')
    if c.V==0:_issue(out,'info','V=0: conferência mínima de 45 kN nos dois sentidos estáticos. Não é verificação de fadiga.',NBR+', 6.1.5.2')
    elif abs(c.V)<45000.:_issue(out,'info','Piso obrigatório de 45 kN aplicado uma vez ao conjunto; V real preservado.',NBR+', 6.1.5.2')
    sa=STEELS[c.angle_steel];sb=STEELS[c.beam_steel];ss=STEELS[c.support_steel]
    ab=math.pi*c.db*c.db/4
    out['bolts']={'Ab_mm2':ab,'fub_MPa':BOLTS[c.bolt],'groups':[]}
    for group,n,planes,fraction,excluded,grip in [('shared_web',c.web_rows,2,1.,c.web_threads_excluded,g['web_grip_mm']),('support_negative',c.support_rows,1,.5,c.support_threads_excluded,g['support_grip_mm']),('support_positive',c.support_rows,1,.5,c.support_threads_excluded,g['support_grip_mm'])]:
        coefficient=.56 if excluded else .45;grip_factor=max(0.,1-.01*max(0.,grip-5*c.db)/1.5)
        rdplane=bolt_shear_resistance(c.db,BOLTS[c.bolt],excluded,grip_factor)
        out['bolts']['groups'].append(dict(id=group,bolt_count=n,shear_planes=planes,coefficient=coefficient,grip_mm=grip,grip_factor=grip_factor,resistance_per_plane_N=rdplane,each_bolt_force_N=Vabs*fraction/n,each_plane_force_N=Vabs*fraction/n/planes))
        _check(out,'bolt_'+group,'Corte dos parafusos · '+group,'bolt_'+group,n*planes*rdplane,fraction,
            'n · planos · α Ab fub/γa2 · redução de pega',NBR+', 6.3.3.2 e6.3.7',bolt_count=n,shear_planes=planes,coefficient=coefficient,Ab_mm2=ab,fub_MPa=BOLTS[c.bolt],grip_factor=grip_factor)
    for side in ('negative','positive'):
        out['physical_angles'].append(dict(id='angle_'+side,side=side,beam_leg_mm=c.beam_leg,support_leg_mm=c.support_leg,thickness_mm=c.t,length_mm=c.length,force_N=Vabs/2))
        for leg,n in [('beam',c.web_rows),('support',c.support_rows)]:
            identifier='angle_'+side+'_'+leg;Ag=c.length*c.t;An=(c.length-n*g['dn'])*c.t
            out['components'][identifier]=dict(material=asdict(sa),physical_angle='angle_'+side,leg=leg,Ag_mm2=Ag,An_mm2=An,thickness_mm=c.t,force_fraction=.5)
            _check(out,identifier+'_shear_gross','Cisalhamento · escoamento bruto',identifier,.6*sa.fy*Ag/GAMMA_A1,.5,'0,60 fy Ag/γa1',NBR+', 6.5.5(a)',Ag_mm2=Ag)
            _check(out,identifier+'_shear_net','Cisalhamento · ruptura líquida',identifier,.6*sa.fu*An/GAMMA_A2,.5,'0,60 fu An/γa2',NBR+', 6.5.5(b)',An_mm2=An,deducted_holes=n,net_hole_deduction_mm=g['dn'])
    # Local beam-web section, conservative clear height, plus actual member Cv.
    h=c.beam.clear;Ag=h*c.beam.tw;An=(h-c.web_rows*g['dn'])*c.beam.tw
    out['components']['beam_web']=dict(material=asdict(sb),Ag_mm2=Ag,An_mm2=An,thickness_mm=c.beam.tw,force_fraction=1.)
    _check(out,'beam_web_shear_gross','Alma da viga · cisalhamento bruto local','beam_web',.6*sb.fy*Ag/GAMMA_A1,1.,'0,60 fy h_livre tw/γa1',NBR+', 6.5.5(a); seção conservadora sem raízes',Ag_mm2=Ag)
    _check(out,'beam_web_shear_net','Alma da viga · ruptura na linha de furos','beam_web',.6*sb.fu*An/GAMMA_A2,1.,'0,60 fu (h_livre−n dn)tw/γa2',NBR+', 6.5.5(b)',An_mm2=An,deducted_holes=c.web_rows)
    lam=h/c.beam.tw;lp=1.1*math.sqrt(5.34*200000./sb.fy);lr=1.37*math.sqrt(5.34*200000./sb.fy)
    Cv=1. if lam<=lp else lp/lam if lam<=lr else 1.24*(lp/lam)**2
    _check(out,'beam_web_shear_buckling','Alma da viga · resistência ao cortante com instabilidade','beam_web',.6*sb.fy*c.beam.d*c.beam.tw*Cv/GAMMA_A1,1.,'0,60 fy (d tw) Cv/γa1; kv=5,34',NBR+', 5.4.3.1',lambda_web=lam,lambda_p=lp,lambda_r=lr,Cv=Cv,Aw_mm2=c.beam.d*c.beam.tw)
    for side in ('negative','positive'):
        out['components']['column_flange_'+side]=dict(material=asdict(ss),thickness_mm=c.support.tf,force_fraction=.5,free_toe_distance_mm=g['column_flange_edge_mm'])
    for sign in directions:
        suffix='_Vpos' if sign>0 else '_Vneg'
        beam_dir='down' if sign>0 else 'up';support_dir='up' if sign>0 else 'down'
        for side in ('negative','positive'):
            for leg,n,pitch,end,edge,direction in [
                ('beam',c.web_rows,c.web_pitch,g['web_end_bottom_mm'] if sign>0 else c.web_end_top,g['web_free_toe_edge_mm'],beam_dir),
                ('support',c.support_rows,c.support_pitch,c.support_end_top if sign>0 else g['support_end_bottom_mm'],g['support_free_toe_edge_mm'],support_dir)]:
                identifier='angle_'+side+'_'+leg+suffix
                bearing_rows(out,c,identifier,n,pitch,c.t,sa.fu,.5,end,direction)
                l_blocks(out,identifier,n,pitch,end,edge,c.t,g['dn'],sa.fy,sa.fu,.5,1.,direction,NBR+', 6.5.6; Gerdau2018 p.25: caminho L da cantoneira')
            identifier='column_flange_'+side+suffix;end=c.support_edge_bottom if sign>0 else c.support_edge_top
            bearing_rows(out,c,identifier,c.support_rows,c.support_pitch,c.support.tf,ss.fu,.5,end,beam_dir)
            l_blocks(out,identifier,c.support_rows,c.support_pitch,end,g['column_flange_edge_mm'],c.support.tf,g['dn'],ss.fy,ss.fu,.5,.5,beam_dir,
                NBR+', 6.5.6; caminho físico suplementar até borda lateral e extremidade real do pilar, Cts=0,5 conservador')
        bearing_rows(out,c,'beam_web'+suffix,c.web_rows,c.web_pitch,c.beam.tw,sb.fu,1.,0.,support_dir,terminal_cap=True)
    out['not_applicable']=[
        {'mechanism':'Bloco L de viga recortada','reason':'Viga sem recortes, mesas contínuas. Não existe a borda livre horizontal fictícia do modelo coped.','reference':'Gerdau2018 p.25; NBR6.5.6'},
        {'mechanism':'Flexão transversal/punção/crippling por ação normal à mesa do pilar','reason':'V puro age no plano da mesa; força normal à mesa é zero no modelo convencional simétrico.','reference':'AISC P901-23W v16.0, exemplo II.A-1A, IIA-2–IIA-13; domínio N=M=T=0'},
        {'mechanism':'Flexão das cantoneiras estendidas e grupo excêntrico rígido','reason':'Dispensa restrita ao detalhe convencional de gabarito documentado. Fora dele a pendência é bloqueante.','reference':'Gerdau2018 p.23–25'}]
    _issue(out,'info','Verificações de contato incluem soma normativa e compatibilidade por furo na distribuição direta. Não se somam resistências das interfaces em série.',NBR+', 6.3.3.3')
    _issue(out,'info','Classificação usual flexível restrita aos gabaritos documentados, comprimento L≥H/2, grupo centralizado ou superior, dois ou mais parafusos e folgas verificadas. Condição fora dessa rota mantém pendência. Não calcula curva momento–rotação nem aprova estabilidade global.',NBR+', 6.1.2.3,6.1.3,6.1.7; Gerdau2018 p.20')
    _issue(out,'info','Despachar as duas cantoneiras junto com a viga. Furos, porcas, arruelas, raio e acesso devem coincidir com os componentes reais.','R016 p.19, nota2')
    _issue(out,'info','Domínio de montagem: contato firme direto em todas as interfaces, sem calços, folgas entre chapas ou soldas participantes; parafusos, porcas e arruelas conforme NBR6.8. Alterações desses detalhes exigem novo modelo, não ajuste silencioso de espessura.',NBR+', 6.8')
    if c.beam.source.startswith('material didático') or c.support.source.startswith('material didático'):
        _issue(out,'warning','Geometria de catálogo didático: confirmar dimensões e raios no catálogo de fornecimento antes da fabricação.','Cadastro dos perfis')
    failures=[r['id'] for r in out['checks'] if r['status']=='FAIL'];governing=max(out['checks'],key=lambda r:r['utilization'])
    severities={i['severity'] for i in out['issues']};pending=bool(severities & {'engineering_pending','access_pending'})
    out['summary']=dict(governing_check_id=governing['id'],governing_label=governing['label'],governing_component=governing['component'],
        governing_utilization=governing['utilization'],actual_governing_utilization=governing['actual_utilization'],
        equivalent_total_V_capacity_N=governing['equivalent_total_V_capacity_N'],failed_check_ids=failures,check_count=len(out['checks']),
        strength_status='FAIL' if failures else 'PASS',complete_checks=not pending,physical_angle_count=2)
    out['status']=('VERIFIED_SUBCHECK_FAIL' if failures else 'DETAIL_FAIL' if 'detail_fail' in severities else 'ENGINEERING_MODEL_PENDING' if pending else
        'COMPLETE_CHECKS_PASS_WITH_PRESET_DEVIATION' if 'preset_deviation' in severities else 'COMPLETE_CHECKS_PASS_WITHIN_SCOPE')
    out['global_pass']=out['status'] in ('COMPLETE_CHECKS_PASS_WITH_PRESET_DEVIATION','COMPLETE_CHECKS_PASS_WITHIN_SCOPE')
    return out


def evaluate(c):
    try:
        out=_evaluate(c)
        def finite(value):
            if isinstance(value,float):return math.isfinite(value)
            if isinstance(value,dict):return all(finite(v) for v in value.values())
            if isinstance(value,(list,tuple)):return all(finite(v) for v in value)
            return True
        if not finite(out):raise ArithmeticError('Faixa numérica finita excedida.')
        return out
    except (ArithmeticError,OverflowError) as exc:
        return {'status':'NUMERICAL_FAILURE','global_pass':False,'issues':[dict(severity='numerical_failure',text='Não foi possível concluir o cálculo na faixa numérica finita: '+str(exc),reference='Faixa numérica')],
                'checks':[],'geometry':{},'load_model':{},'summary':{},'components':{},'physical_angles':[],
                'scope':SCOPE,'exclusions':EXCLUSIONS.copy(),'inputs':_safe(asdict(c)) if isinstance(c,DoubleAngle) else _safe(c)}
