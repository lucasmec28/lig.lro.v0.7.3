"""Conditional one-root welded 2L-T compression, DG29 Example 5.4 / NBR.

Signed equilibrium is never converted to tension. Only resistance comparisons
use positive demand magnitudes. No fixture/oracle is imported by this module.
"""
from dataclasses import asdict, replace
from copy import deepcopy
import hashlib
import json
import math
from . import welded_angle_gusset as base
from .corner_compression import reduction

MODEL = 'DG29_Ex5_4_one_root_K1_2_centered_clipped_strip_max_length'
E = 200000.
STATUSES = ('unknown', 'confirmed', 'absent')
FIELDS = (
    'compression_root_rotation', 'compression_root_source', 'compression_root_stamp',
    'compression_brace_rotation', 'compression_brace_source', 'compression_brace_stamp',
    'compression_receiver_relative', 'compression_receiver_source', 'compression_receiver_stamp',
    'compression_unbraced_length', 'compression_flange_rotation',
    'compression_receiver_interaction', 'compression_interaction_source',
)
INACTIVE = [
    {'id':'angle_tension_Ct','reason':'Compressão: não se usa ruptura tracionada Ct·Ag·fu.'},
    {'id':'outward_tension_blocks','reason':'Saída comprimida: blocos tracionados à ponta livre inativos; limite de transferência por cisalhamento conservado.'},
    {'id':'normal_tension_rupture','reason':'Tensões normais não positivas: ruptura normal por tração inativa.'},
    {'id':'W_flange_bending_5_7_2','reason':'Raiz inteiramente comprimida: flexão local de mesa por tração NBR5.7.2 inativa.'},
    {'id':'W_opposite_pair_5_7_6','reason':'Caso local de uma mesa: não se inventa par oposto; confirmar ausência de ações locais interagentes.'},
]


def identified_source(value):
    return bool(value.strip()) and value.strip().casefold() not in ('não informado','nao informado','unknown','none','-')


def geometry_stamp(c, role):
    """Bind each independent declaration to the real physical assembly.

Loads, labels and grades do not change geometric restraint evidence. Receiver
span/rotation/interaction are included only in its own evidence digest.
"""
    names = ('support_member','support_face','angle_profile','support_profile',
             'plate_width','plate_height','plate_t','theta_deg','center_s','center_n',
             'weld_length','end_margin','angle_weld_leg','angle_weld_edge_detail',
             'root_weld_leg','support_end_left','support_end_right','topology',
             'interface','symmetric_load','accessible_both_faces')
    data = {k:getattr(c,k) for k in names}
    if base.outer.enabled(c):
        contour=base.outer.one_root(c)
        if contour['outer_end_cut']['trimmed']:data['actual_gusset_polygon']=contour['polygon']
    if role == 'receiver':
        data.update({k:getattr(c,k) for k in ('compression_receiver_relative',
            'compression_unbraced_length','compression_flange_rotation',
            'compression_receiver_interaction','compression_interaction_source')})
    data.update(model=MODEL, role=role)
    def norm(x):
        if type(x) in (int,float):return float(x)
        if isinstance(x,dict):return {k:norm(v) for k,v in x.items()}
        return x
    return hashlib.sha256(json.dumps(norm(data),sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def bind_current_evidence(c):
    """Record current geometry only for separately supplied physical evidence.

This does not set a restraint true, fill a span, or supply missing sources.
"""
    updates={}
    for role in ('root','brace','receiver'):
        if identified_source(getattr(c,'compression_'+role+'_source')):
            updates['compression_'+role+'_stamp']=geometry_stamp(c,role)
    return replace(c,**updates)


def boundaries(c, out):
    records={}
    def pending(id,message):base._issue(out,id,'unverified',message)
    for role,label in [('root','raiz e W: contenção real à rotação fora do plano/torção do receptor'),
                       ('brace','extremidade/continuação da diagonal: contenção real à rotação fora do plano')]:
        status=getattr(c,'compression_'+role+'_rotation')
        source=getattr(c,'compression_'+role+'_source')
        stamp=getattr(c,'compression_'+role+'_stamp')
        current=geometry_stamp(c,role)
        verified=status=='confirmed' and identified_source(source) and stamp==current
        records[role]={'declared':status,'source':source,'current_stamp':current,'declared_stamp':stamp,'qualified':verified}
        if not verified:pending('compression_'+role+'_boundary',label+' não comprovada para a geometria atual. Identifique o desenho/cálculo e vincule o registro; simetria e solda contínua não provam este vínculo.')
    role='receiver';current=geometry_stamp(c,role)
    source=c.compression_receiver_source
    bound=identified_source(source) and c.compression_receiver_stamp==current
    records[role]={'relative_flange_restraint':c.compression_receiver_relative,
        'flange_rotation':c.compression_flange_rotation,'unbraced_length':c.compression_unbraced_length or None,
        'interaction':c.compression_receiver_interaction,'interaction_source':c.compression_interaction_source,
        'source':source,'current_stamp':current,'declared_stamp':c.compression_receiver_stamp,'evidence_current':bound}
    if not bound:pending('compression_receiver_evidence','Identifique e vincule o detalhe real do W: contenção relativa entre mesas ou vão lateral real envolvendo ambas as mesas e condição de rotação da mesa carregada. Distâncias às extremidades não são vãos destravados.')
    if c.compression_receiver_relative!='confirmed':
        if c.compression_unbraced_length<=0:pending('compression_receiver_span','Informe ℓ real: maior comprimento lateralmente destravado envolvendo a força e ambas as mesas, para NBR5.7.5; nenhum vão é presumido.')
        if c.compression_flange_rotation=='unknown':pending('compression_receiver_rotation','Informe se a rotação da mesa carregada é impedida ou livre em NBR5.7.5. Isto não comprova o vínculo de rotação da raiz K1,2.')
    if c.compression_receiver_interaction!='isolated' or not identified_source(c.compression_interaction_source):
        pending('compression_receiver_interaction','Identifique ações locais próximas/opostas no receptor. Este ramo cobre uma força em uma mesa sem interação; par oposto ou painel interagente exige verificação correspondente, sem presumir ações existentes nulas.')
    out['compression']={'model':MODEL,'K':1.2,'boundaries':records,
        'inactive_mechanisms':deepcopy(INACTIVE),
        'note':'Resultados numéricos condicionais preservam falhas; declarações documentam o detalhe informado, não certificam sua execução ou a estrutura global.'}
    return records


def whitmore(c,g,fy):
    C,S=g['direction'];a=g['angle_section'];u=-c.weld_length/2;v0=a['centroid']-a['leg']/2
    raw=[-a['leg']/2-c.weld_length/math.sqrt(3),a['leg']/2+c.weld_length/math.sqrt(3)]
    constraints=[dict(id='Whitmore30',range=raw),
        dict(id='plate_x',range=[(-c.plate_width/2-c.center_s-u*C)/S,(c.plate_width/2-c.center_s-u*C)/S]),
        dict(id='actual_root',range=[(-c.plate_width/2-c.center_s)*S+c.center_n*C,(c.plate_width/2-c.center_s)*S+c.center_n*C])]
    if abs(C)>1e-14:
        constraints.append(dict(id='plate_y',range=sorted([(c.center_n+u*S)/C,(c.center_n+u*S-c.plate_height)/C])))
    elif not 0<c.center_n+u*S<=c.plate_height:raise ValueError('Seção Whitmore sem distância positiva à raiz real.')
    if g.get('outer_end_cut',{}).get('trimmed'):
        chord=base._transverse_chord(c,u)
        constraints.append(dict(id='actual_polygon',range=[chord['left']['v'],chord['right']['v']]))
    lo=max(q['range'][0] for q in constraints);hi=min(q['range'][1] for q in constraints)
    half=min(v0-lo,hi-v0)
    if half<=0:raise ValueError('Sem faixa Whitmore positiva, centrada na força, contida na chapa e projetada na raiz contínua real.')
    retained=[v0-half,v0+half]
    xy=lambda v:[c.center_s+u*C+v*S,c.center_n+u*S-v*C]
    ends=[xy(v) for v in retained]
    if not all(base.outer.inside(p,g['polygon']) for p in ends):raise ValueError('Faixa comprimida ultrapassa o polígono real.')
    lengths=[xy(v)[1]/S for v in (retained[0],v0,retained[1])]
    length_tolerance=1e-10*max(1.,c.plate_width,c.plate_height,c.weld_length)
    if min(lengths)<=length_tolerance:raise ValueError('Toda a faixa comprimida requer caminho de comprimento positivo até a raiz; nenhum trecho nulo/negativo é descartado.')
    roots=[p[0]-p[1]/S*C for p in ends]
    if any(abs(x)>c.plate_width/2+1e-8 for x in roots):raise ValueError('Projeção Whitmore fora da raiz efetiva real.')
    L=max(lengths);bw=2*half
    result=reduction(E,fy,bw*c.plate_t,c.plate_t,1.2*L,base.GAMMA_A1)
    return dict(model=MODEL,K=1.2,u0=u,v0=v0,raw_v=raw,clip_constraints=constraints,
        clipped_v=[lo,hi],retained_v=retained,width=bw,area=bw*c.plate_t,
        I=bw*c.plate_t**3/12,ends=ends,root_projections=roots,three_lengths=lengths,
        Lmax=L,Le=1.2*L,**result,
        basis='Faixa reduzida simétrica sobre a linha real recebe N integral; Lmáx de toda faixa. Bordas virtuais não são bordas livres. Curva NBR integral mesmo abaixo de25; Errata1 corrige6.5.4(b) para Le/r>25.')


def crippling(W,fy,B,end_distance):
    interior=end_distance>=W['d']/2
    ratio=B/W['d'];mult=3*ratio if interior or ratio<=.2 else 4*ratio-.2
    resistance=(.66 if interior else .33)*W['tw']**2*(1+mult*(W['tw']/W['tf'])**1.5)*math.sqrt(E*fy*W['tf']/W['tw'])/base.GAMMA_A1
    return dict(resistance=resistance,end_distance=end_distance,interior=interior,loaded_length_ratio=ratio,
        branch='interior' if interior else 'end_short' if ratio<=.2 else 'end_long')


def sidesway(W,length,rotation):
    if length<=0 or rotation not in ('restrained','free'):return {'status':'UNVERIFIED','resistance':None}
    h=W['d']-2*W['k'];ratio=(h/W['tw'])/(length/W['bf']);limit=2.3 if rotation=='restrained' else 1.7
    # Exclusion is strict. Equality belongs to the resistance formula.
    # Comparing length avoids roundoff turning exactly-threshold inputs exempt.
    excluded=length<(h/W['tw'])*W['bf']/limit
    R=None if excluded else 16*E*W['tw']**3*W['tf']/(base.GAMMA_A1*h*h)*((.94 if rotation=='restrained' else 0)+.37*ratio**3)
    return dict(status='NOT_APPLICABLE_RATIO' if excluded else 'CALCULATED',resistance=R,
        h=h,unbraced_length=length,rotation=rotation,ratio=ratio,threshold=limit,Cr=16*E,
        basis='NBR5.7.5.2/.3; Cr16E conservador, sem presumir estado de momento global; dispensa somente para razão estritamente superior ao limite.')


def calculate_case(c,g,N,case,label,out,materials):
    angle,gusset,support=materials;B=c.plate_width;t=c.plate_t;L=c.weld_length
    W=g['support_catalog'];A=g['angle_section'];demand=-N
    sections=base.plate_sections(c,g,N)
    sections['local']['Ct']=None
    sections['local']['Ct_basis']='INATIVO em compressão: redução de ruptura tracionada não usada em nenhuma resistência deste caso.'
    root=base.root_actions(N,c.theta_deg,g['force_point']);Nr,Vr,Mr=(root[k] for k in ('N','V','M'))
    qends=[Nr/B-6*Mr/B**2,Nr/B+6*Mr/B**2];qs=Vr/B
    qvec=[math.hypot(q,qs) for q in qends];qp=max(qvec);qa=sum(qvec)/2;qd=max(qp,1.25*qa)
    Neq=B*max(0.,*[-q for q in qends])
    root.update(q_n_ends_N_per_mm=qends,q_s_N_per_mm=qs,q_peak=qp,q_average=qa,q_design=qd,
        weld_stress=qd/(math.sqrt(2)*c.root_weld_leg),elastic_peak_equivalent_normal_N=Neq,
        compression_peak_equivalent_N=Neq,flange_bending_exempt=True,
        flange_bending_inactive_reason='NBR5.7.2 é mecanismo de tração; raiz inteiramente comprimida.',flange_footprint=t+2*c.root_weld_leg)
    tol=1e-10*max(1.,demand/(B*t));normal_max=max([q['sigma_MPa'] for q in sections['cuts']]+[sections['local']['sigma_max']])
    direct=normal_max<=tol and max(qends)<=tol*t
    member=dict(reference='Centroide da raiz na face exterior da mesa',point_local=[0.,0.],
        applied_to_support=dict(N_normal=Nr,V_parallel=Vr,M_root=Mr),
        equal_opposite_on_gusset=dict(N_normal=-Nr,V_parallel=-Vr,M_root=-Mr),
        introduced_member_shear_jump=Nr,introduced_member_axial_jump=Vr,
        root_to_member_centroid_normal_offset=W['d']/2,introduced_moment_about_member_centroid=Mr-W['d']/2*Vr,
        existing_member_actions=None,global_member_verified=False,
        note='Somar às ações concorrentes reais do membro; não se presume apoio descarregado.')
    record=dict(id=case,label=label,N=N,N_per_angle=N/2,angle_count=2,angle_gross_area=A['Ag'],pair_gross_area=2*A['Ag'],
        angle_area_basis='one_angle',angle_Ct=None,angle_Ae=None,pair_effective_area=None,
        angle_forces=[dict(face=f,N=N/2,heel_N=N/2*A['heel_force_fraction'],toe_N=N/2*A['toe_force_fraction']) for f in ('face_positive','face_negative')],
        root=root,plate_sections=sections,paths=[],inactive_path_families=deepcopy(INACTIVE),member_actions=member,
        compression_domain=dict(all_normal_nonpositive=direct,max_normal_MPa=normal_max,normal_tolerance_MPa=tol))
    out['cases'].append(record)
    if case=='actual':out.update(root=root,sections=sections,paths=[],member_actions=member);out['geometry']['inactive_path_families']=deepcopy(INACTIVE)
    if not direct:
        base._issue(out,case+'_compression_mixed_sign','outside_scope','Campo normal de sinais mistos na chapa/faixa local ou raiz: este primeiro modelo exige todas as normais comprimidas. Qualifique o mecanismo misto correspondente; não se substitui N por |N|.',**record['compression_domain'],root_tractions=qends)
        return
    def row(id,label,component,mechanism,D,R,unit='N',ref='',face=None,**detail):
        base._row(out,id,label,component,mechanism,case,D,R,unit,ref,**detail)
        out['checks'][-1]['load_basis']='per_angle' if face else 'total_pair'
        if face:out['checks'][-1]['face']=face
    def env(id,label,component,mechanism,items,ref,face=None):
        base._envelope(out,id,label,component,mechanism,case,items,ref)
        out['checks'][-1]['load_basis']='per_angle' if face else 'total_pair'
        if face:out['checks'][-1]['face']=face
    # Distinct face resistance, common gusset once. No tensile block reused.
    for face in ('face_positive','face_negative'):
        row('angle_compression_'+face,'Cantoneira · compressão bruta local · '+face,'angle','local_compression',demand/2,A['Ag']*angle.fy/base.GAMMA_A1,ref='NBR6.5.4; seção local da conexão, sem estabilidade global da diagonal',face=face)
        row('angle_compactness_'+face,'Cantoneira · esbeltez local conservadora da aba inteira · '+face,'angle','local_compactness',A['leg']/A['t'],.45*math.sqrt(E/angle.fy),'razão','NBR Tabela4 AL3; b inteiro conservador; elemento não esbelto requerido',face=face)
        depth=A['toe_flat'] if A['resistance_model']=='catalog_radiused_legacy' else A['t']
        row('angle_shear_transfer_'+face,'Cantoneira · limite de transferência por cisalhamento · '+face,'angle','shear_transfer',demand/2,min(.6*angle.fy,.6*angle.fu)*L*depth/base.GAMMA_A2,
            ref='Limite conservador de transferência uniforme: uma superfície L×espessura real, Ant0; não é bloco tracionado na ponta livre',face=face,area=L*depth)
        for line in g['weld_lines']:
            F=demand*line['force_fraction']/2;loc=line['id']
            row('angle_weld_'+loc+'_'+face,'Solda '+loc+' · '+face,'angle_weld','weld_'+loc,F,L*c.angle_weld_leg/math.sqrt(2)*.6*base.ELECTRODES[c.angle_electrode]/base.GAMMA_W2,
                ref='NBR6.2.2.2/6.2.5; quatro filetes físicos; sem ganho direcional',face=face,signed_force=N*line['force_fraction']/2)
        for component,mat,dep in [('angle',angle,min(c.angle_weld_leg,depth)),('gusset',gusset,min(c.angle_weld_leg,t))]:
            items=[]
            for line in g['weld_lines']:
                for mode,R in [('Escoamento',.6*mat.fy*L*dep/base.GAMMA_A1),('Ruptura',.6*mat.fu*L*dep/base.GAMMA_A2)]:
                    items.append(dict(name=line['id']+' '+mode,demand=demand*line['force_fraction']/2,resistance=R,area=L*dep))
            env(component+'_substrate_'+face,component+' · metal-base dos filetes · '+face,component,'longitudinal_substrate',items,'NBR6.5.5; contato físico por face',face)
    row('gusset_shear_transfer','Chapa única · limite de transferência por cisalhamento','gusset','shear_transfer',demand,min(.6*gusset.fy,.6*gusset.fu)*L*t/base.GAMMA_A2,
        ref='Limite conservador uniforme, uma superfície L×t, N total uma vez, Ant0',area=L*t)
    local=sections['local'];horizontal=sections['intervals']
    env('gusset_yield','Gusset · escoamento N/V/M','gusset','yielding',[
        dict(name='Seções horizontais: envelope elástico',demand=max(x['von_mises_envelope'] for x in horizontal),resistance=gusset.fy/base.GAMMA_A1,unit='MPa'),
        dict(name='Faixa física local N+M',demand=max(abs(local['sigma_min']),abs(local['sigma_max'])),resistance=gusset.fy/base.GAMMA_A1,unit='MPa')],
        'NBR6.5.3/6.5.5; mantém exatamente a seção local e a excentricidade real')
    row('gusset_shear_rupture','Gusset · ruptura por cisalhamento','gusset','shear_rupture',max(x['tau_abs_max'] for x in horizontal),.6*gusset.fu/base.GAMMA_A2,'MPa','NBR6.5.5; ruptura normal por tração inativa')
    try:
        data=whitmore(c,g,gusset.fy);record['compression']=data
        data['boundary_qualified']=all(out['compression']['boundaries'][role]['qualified'] for role in ('root','brace'))
        row('gusset_one_root_buckling','Gusset · instabilidade local condicionada aos vínculos','gusset','compression_buckling',demand,data['resistance'],ref='DG29 Ex5.4 K1,2; NBR5.3/6.5.4(b), Errata1 PDF1 Le/r>25',**{k:v for k,v in data.items() if k!='resistance'})
        if data['Le_over_r']>200:base._issue(out,case+'_compression_service','unverified','Le/r>200: resultado resistente preservado; comportamento em serviço fora do domínio automático conservador, a qualificar pelo responsável. Não é proibição absoluta NBR.',Le_over_r=data['Le_over_r'])
    except ValueError as exc:base._issue(out,case+'_compression_strip','unverified',str(exc))
    row('root_weld','Solda dupla da raiz · N/V/M','root_weld','weld',root['weld_stress'],.6*base.ELECTRODES[c.root_electrode]/base.GAMMA_W2,'MPa','NBR6.2.5 + DG29 max(qpico,1.25qmédio)',**root)
    qn=Neq/B
    for component,mat,dep in [('gusset_root',gusset,min(t,2*c.root_weld_leg)),('support_contact',support,2*c.root_weld_leg)]:
        env(component+'_substrate',component+' · metal-base da raiz comprimida',component,'root_substrate',[
            dict(name='Escoamento combinado',demand=math.hypot(qn/dep,math.sqrt(3)*qs/dep),resistance=mat.fy/base.GAMMA_A1,unit='MPa'),
            dict(name='Ruptura por cisalhamento',demand=abs(qs)/dep,resistance=.6*mat.fu/base.GAMMA_A2,unit='MPa')],
            'NBR6.5.3/6.5.5; normal comprimida, sem resistência fictícia de ruptura tracionada')
    end=min(g['support_end_clearances']);kf=2.5 if end<=W['d'] else 5.
    row('W_web_normal','W · escoamento local da alma','support_web','local_normal_yield',Neq,1.1*support.fy*W['tw']*(kf*W['k']+B)/base.GAMMA_A1,
        ref='NBR5.7.3; Neq=L max(-qn) envelope conservador de pressão, não força extra no equilíbrio',end_factor=kf,end_distance=end)
    cr=crippling(W,support.fy,B,end)
    row('W_web_crippling','W · enrugamento da alma','support_web','web_crippling',Neq,cr['resistance'],ref='NBR5.7.4; comprimento carregado B e extremidade real',**{k:v for k,v in cr.items() if k!='resistance'})
    As=W['tw']*B
    env('W_web_shear','W · cisalhamento longitudinal da alma','support_web','longitudinal_shear',[
        dict(name='Escoamento',demand=abs(Vr),resistance=.6*support.fy*As/base.GAMMA_A1),
        dict(name='Ruptura',demand=abs(Vr),resistance=.6*support.fu*As/base.GAMMA_A2)],'NBR6.5.5; V real paralelo')
    row('W_web_combined','W · combinação local da alma','support_web','combined_yield',math.hypot(Neq/As,math.sqrt(3)*1.5*Vr/As),support.fy/base.GAMMA_A1,'MPa','Triagem elástica local conservadora')
    env('W_flange_punch','W · cisalhamento nas duas superfícies longitudinais da mesa','support_flange','punching',[
        dict(name='Escoamento',demand=qp/(2*W['tf']),resistance=.6*support.fy/base.GAMMA_A1,unit='MPa'),
        dict(name='Ruptura',demand=qp/(2*W['tf']),resistance=.6*support.fu/base.GAMMA_A2,unit='MPa')],'NBR6.5.5; sem crédito de bordas curtas')
    recv=out['compression']['boundaries']['receiver']
    if c.compression_receiver_relative=='confirmed' and recv['evidence_current']:
        sw=dict(status='NOT_APPLICABLE_REAL_RELATIVE_RESTRAINT',resistance=None,source=c.compression_receiver_source)
    else:
        sw=sidesway(W,c.compression_unbraced_length,c.compression_flange_rotation)
        if sw['resistance'] is not None:row('W_web_sidesway','W · flambagem lateral da alma','support_web','web_sidesway',Neq,sw['resistance'],ref='NBR5.7.5; vão e rotação declarados separadamente do vínculo K1,2',**{k:v for k,v in sw.items() if k!='resistance'})
    record['receiver_sidesway']=sw
    if case=='actual':out['compression']['strip']=record.get('compression');out['compression']['receiver_sidesway']=sw


def finalize(out):
    result=base._finalize(out)
    if not result.get('compression'):return result
    pending=[x['id'] for x in result['issues'] if x['severity']=='unverified']
    result['summary']['unverified_ids']=pending
    result['summary']['diagnostic_checks']=bool(result['checks'])
    result['compression']['qualified']=not pending and result['summary']['complete_checks']
    if pending:
        result['global_pass']=result['local_pass']=False
        result['summary']['complete_checks']=False
        if result['status'] not in ('INVALID_INPUT','INVALID_GEOMETRY','NUMERICAL_FAILURE','OUTSIDE_SCOPE','DETAILING_FAIL'):
            result['status']='CHECKS_FAIL_AND_UNVERIFIED' if result['summary']['failed_check_ids'] else 'NOT_VERIFIED'
    return result
