"""Current-input Portuguese Word export for the direct-seat DG6 local model."""
from io import BytesIO
from docx import Document
from docx.shared import Cm, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from .beam_direct_seat import evaluate, COMPONENT_VERSION
from .beam_direct_seat_presentation import HEADERS, checks_rows, STATUS, SCOPE_NAMES, fmt
from .beam_direct_seat_drawing import png_bytes


def create_report(c):
    r=evaluate(c)
    d=Document()
    sec=d.sections[0];sec.page_width=Cm(21);sec.page_height=Cm(29.7)
    sec.top_margin=sec.bottom_margin=Cm(1.6)
    sec.left_margin=sec.right_margin=Cm(1.6)
    for name in ('Normal','Title','Heading 1','Heading 2'):
        style=d.styles[name];style.font.name='Arial';style.font.color.rgb=RGBColor(0,0,0)
    d.styles['Normal'].font.size=Pt(9)
    d.styles['Normal'].paragraph_format.space_after=Pt(5)
    d.styles['Title'].font.size=Pt(20)
    d.styles['Heading 1'].font.size=Pt(12)
    for element in d.styles.element.iter():
        for child in list(element):
            if child.tag == qn('w:pBdr'): element.remove(child)
    def table(rows):
        from .report import table as shared_table
        return shared_table(d, HEADERS, [tuple(row.values()) for row in checks_rows(rows)],
                            (3.1, .85, .85, .5, .65, 1.0))
    d.add_heading('Memória de apoio direto entre vigas',0)
    d.add_paragraph(c.project)
    d.add_paragraph(r.get('diagnosis','Entrada inválida'))
    d.add_paragraph('Modelo de cálculo '+COMPONENT_VERSION+'. Apresentação revisada 0.9.51.')
    d.add_picture(BytesIO(png_bytes(c)),width=Cm(17.7))
    d.add_paragraph('Planta e vista lateral dos dados atuais. Eixos ortogonais; trechos longitudinais interrompidos. Contato direto entre mesas, sem chapa intermediária. Quatro parafusos verticais; dois se sobrepõem em cada posição da vista lateral. Croqui de conferência, não desenho de fabricação.')
    d.add_page_break()
    d.add_heading('Dados e modelo de cálculo',1)
    d.add_paragraph(f'{c.beam.name} sobre {c.support.name}. Aços: {c.beam_steel} / {c.support_steel}. Reação ELU: {fmt(c.V/1000)} kN; N={fmt(c.N)} N; My={fmt(c.applied_moment_y)} N mm; Tz={fmt(c.torsion)} N mm; x={fmt(c.reference_x)} mm.')
    d.add_paragraph('ASI Design Guide 6, primeira edição: família A1(c), dispersão 1:1 Fig. A4 (p.6), modelo A3 (pp.7–8), AS 4100. Apoio superior de extremidade e carga interna na viga inferior. Sem crédito resistente do par construtivo e sem cortante vertical R/4 nos parafusos.')
    d.add_heading('Resistências locais ASI DG6',1)
    table([x for x in r.get('checks',[]) if x['category']=='RESISTANCE'])
    d.add_heading('Condições do método',1)
    d.add_paragraph('Preparo das faces de contato direto: '+('especificado' if c.direct_bearing_faces_prepared else 'não especificado')+'. O resultado local exige geometria compatível, resistências suficientes e esta especificação de contato. Ações já majoradas; nenhum fator adicional é aplicado à reação.')
    d.add_paragraph('A compatibilidade de rotação, os vínculos e a estabilidade global pertencem ao projeto estrutural externo e não são usados como bloqueio artificial do resultado resistente local. O cálculo local não atesta fabricação ou comportamento executado.')
    d.add_heading('Suplemento NBR independente',1)
    table([x for x in r.get('checks',[]) if x['category']=='NBR_SUPPLEMENT'])
    d.add_paragraph('NBR 8800:2024, Errata 1:2025, 5.7.3/5.7.4: limites inferiores conservadores de escoamento e enrugamento locais da alma, ramo de extremidade com comprimento de apoio tendendo a zero, k=tf. Demanda max(R,45 kN). Não são resistências adicionais: não se somam ao DG6, não se misturam seus fatores e não substituem o resultado ASI. Sem crédito resistente dos enrijecedores.')
    d.add_page_break()
    d.add_heading('Geometria do detalhe',1)
    d.add_paragraph('As relações entre colchetes indicam o critério geométrico. Valores em milímetros. Condições geométricas não dimensionam a resistência do par construtivo ou de suas soldas.')
    table([x for x in r.get('checks',[]) if x['category']=='GEOMETRY'])
    d.add_paragraph(f'Par construtivo: 2 chapas {fmt(c.stiff_thickness)} × {fmt(c.stiff_width)} × {fmt(c.stiff_height)} mm; recortes {fmt(c.stiff_clip)} mm; filete {fmt(c.stiff_weld)} mm; comprimento útil declarado {fmt(c.stiff_weld_length)} mm. Nenhuma resistência dessas chapas ou soldas é creditada.')
    d.add_heading('Equações e parâmetros',1).paragraph_format.page_break_before=True
    d.add_paragraph('Va=0,54 fy Aw; Vb=alpha_v Va; Vc=0,9 × 1,25 bbf tw fy; Vd=0,9 alpha_c bb tw fy. Aw=d tw; d1=d2=d−2tf; bs=tw da outra viga + 2tf da outra viga; bbf=bs+2,5tf (extremidade) ou bs+5tf (interno); bb=bbf+0,5d2 ou bbf+d2.')
    d.add_paragraph('alpha_v=min[1; (82/((d1/tw) sqrt(fy/250)))²]. lambda_n=(2,5d1/tw)sqrt(fy/250); alpha_a=2100(lambda_n−13,5)/(lambda_n²−15,3lambda_n+2050); lambda=lambda_n+0,5alpha_a; eta=max[0;0,00326(lambda−13,5)]; xi=((lambda/90)²+1+eta)/(2(lambda/90)²); alpha_c=xi[1−sqrt(1−(90/(xi lambda))²)].')

    for role,p in r.get('dg6_parameters',{}).items():
        d.add_heading('Viga superior' if role=='upper' else 'Viga inferior',2)
        labels={'d1_mm':'d1 (mm)','d2_mm':'d2 (mm)','bs_mm':'bs (mm)','bbf_mm':'bbf (mm)',
                'bb_mm':'bb (mm)','Aw_mm2':'Aw (mm²)','fy_MPa':'fy (MPa)', 'lambda_':'lambda',
                'local_capacity_N':'resistência local (N)'}
        d.add_paragraph('; '.join(f'{labels.get(k,k)}={fmt(v)}' for k,v in p.items() if isinstance(v,(float,int))))
    d.add_heading('Equações do suplemento NBR',1)
    d.add_paragraph('Escoamento local: 1,10 × 2,5tf × fy × tw / gamma_a1. Enrugamento local: 0,33tw² × sqrt(E fy tf/tw) / gamma_a1. E=200000 MPa; gamma_a1=1,10. Ramo conservador conforme escopo descrito; nenhuma área de contato uniforme é presumida.')
    d.add_heading('Verificações externas e execução',1)
    table([x for x in r.get('checks',[]) if x['category']=='EXTERNAL_CAPACITY'])
    d.add_paragraph('Va/Vb inferiores são capacidades de seção informativas. O cortante total do painel inferior não foi fornecido; a reação isolada não substitui essa demanda. Não representam falha da ligação local.')
    for x in r.get('scopes',[]):
        if x['id'] not in ('dg6_local','nbr_supplement'):
            d.add_paragraph(SCOPE_NAMES.get(x['id'],'Condição')+': '+x['notes'])
    d.add_paragraph('Registro externo: '+fmt(c.external_length_reported_mm)+' mm; '+c.external_support_node+'; '+c.external_bracing_record)
    d.add_paragraph('Observações: '+c.notes)
    b=BytesIO();d.save(b);return b.getvalue()


def create_mc_excerpt(c):
    from . import mc_report_layout as mc
    from .models import KGF
    r=evaluate(c)
    supplement=[x for x in r.get('checks',[]) if x['category']=='NBR_SUPPLEMENT']
    supplement_status=('NÃO ATENDE' if any(x.get('status')=='FAIL' for x in supplement) else
                       'ATENDE' if supplement and all(x.get('status')=='PASS' for x in supplement) else 'PENDENTE')
    status=r.get('diagnosis','Entrada inválida')+' Suplemento NBR independente: '+supplement_status+'.'
    doc=mc.document('Apoio direto entre vigas',c.project,status,png_bytes(c),
        'Planta e vista lateral do mesmo caso de entrada. Contato direto entre mesas, sem chapa intermediária. Croqui de conferência.')
    mc.data_table(doc,[('Viga apoiada / apoio',c.beam.name+' / '+c.support.name,'—'),
        ('Aços: apoiada / apoio',c.beam_steel+' / '+c.support_steel,'—'),
        ('Reação vertical ELU',fmt(c.V/KGF),'kgf'),('Axial no eixo da viga',fmt(c.N/KGF),'kgf'),
        ('Momento externo',fmt(c.applied_moment_y/(KGF*1000)),'kgf·m'),
        ('Torção externa',fmt(c.torsion/(KGF*1000)),'kgf·m'),('Parafusos: quantidade × diâmetro','4 × '+fmt(c.db),'mm')])
    for key,title in [('RESISTANCE','Resistências locais ASI DG6'),('NBR_SUPPLEMENT','Suplemento NBR independente'),('GEOMETRY','Geometria do detalhe'),('EXTERNAL_CAPACITY','Verificações externas')]:
        rows=[x for x in r.get('checks',[]) if x['category']==key]
        if key=='GEOMETRY':
            doc.add_heading(title,1)
            failures=[x for x in rows if x.get('status')!='PASS']
            doc.add_paragraph(f'{len(rows)-len(failures)} de {len(rows)} requisitos geométricos atendidos. A lista completa de valores e limites está na memória completa; todos os itens não atendidos ou pendentes são reproduzidos abaixo.')
            mc.result_table(doc,'Pendências geométricas',[tuple(x.values()) for x in checks_rows(failures)])
        else:
            mc.result_table(doc,title,[tuple(x.values()) for x in checks_rows(rows)])
    notes=['Ações já majoradas. Resultados ASI e NBR independentes: suas resistências e fatores não se somam.',
        'A geometria não atribui resistência ao par construtivo de enrijecedores ou às suas soldas. A estabilidade global é verificada no projeto estrutural.']
    notes += [SCOPE_NAMES.get(s['id'],'Condição')+': '+s['notes'] for s in r.get('scopes',[])]
    return mc.close(doc,notes+[c.notes],['ASI Design Guide 6, primeira edição, A1(c), Figura A4 e modelo A3; AS 4100.',
        'ABNT NBR 8800:2024, Errata 1:2025, 5.7.3 e 5.7.4.'])
