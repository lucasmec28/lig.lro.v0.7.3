"""Minimal opt-in control; only selected 3/4-inch bolts receive the user's gauge."""
from .display_precision import number_input

LABELS={'gusset_end_shape':'Contorno externo da chapa',
        'gusset_bolt_end_distance':'Centro do último parafuso até o corte externo (mm)',
        'gusset_weld_end_distance':'Término físico da solda até o corte externo (mm)'}


def render(st,prefix,kind,diameter_key=None):
    shape=prefix+'gusset_end_shape';field='gusset_bolt_end_distance' if kind=='bolted' else 'gusset_weld_end_distance';distance=prefix+field
    def selected():
        # A user action may seed the specifically approved practical gauge.
        # Imports and non-3/4 selections are not silently normalized.
        if kind=='bolted' and st.session_state[shape]=='normal_cut' and st.session_state[distance]==0. and st.session_state.get(diameter_key)==19.05:
            st.session_state[distance]=35.
    st.selectbox(LABELS['gusset_end_shape'],('original','normal_cut'),key=shape,
        format_func=lambda x:{'original':'Original · sem corte externo','normal_cut':'Corte perpendicular ao eixo · preservar raízes'}[x],on_change=selected)
    number_input(LABELS[field],key=distance,format='%.2f',disabled=st.session_state[shape]!='normal_cut')
    if st.session_state[shape]=='normal_cut':
        st.caption('Gabarito prático inicial de 35,00 mm somente para Ø3/4 selecionado; editável. O mínimo tabelado de 25,00 mm é a triagem conservadora para esse furo padrão, sem substituir resistência ou acesso real.' if kind=='bolted' else 'Informe a margem de projeto/fabricação após o fim físico do cordão. No transpasse tracionado aplicável, verificar ao menos uma perna; não há valor universal de 35,00 mm para solda.')
        st.caption('O corte altera o polígono resistente e o croqui. Mantém as raízes completas; afunilamento lateral e encurtamento de raízes não pertencem a esta opção. A margem da ponta da cantoneira é outra dimensão.')
    return {'gusset_end_shape',field}
