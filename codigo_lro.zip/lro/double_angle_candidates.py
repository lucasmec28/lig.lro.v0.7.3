"""Optional, bounded R016 proposals; the native evaluator remains authoritative.

``search(DoubleAngle)`` never mutates its input. It considers the original and
76 industrial metric patterns, retaining the CURRENT exact documented template
and every input except diameter, physical hole, equal row counts, pitches,
angle length/end distances and column edge distances. Column endpoints stay
fixed. Accepted proposals carry complete native projects and native evaluations;
rejections retain compact evidence. Ranking is length, total bolts, diameter,
then canonical project digest, within this finite set only (not mass or a global
optimum). ``validated_proposal(base, id)`` reruns the search before an explicit
apply action and returns a fresh native DoubleAngle; stale/unknown IDs raise.

Result keys: base_project, base_digest, base_evaluation, status, reasons, counts,
accepted, rejected, domain, ranking. Status is BLOCKED, CANDIDATES_FOUND or
NO_CANDIDATE. Counts describe unique candidates (an eligibility-only baseline
evaluation is excluded when BLOCKED). Fingerprints use sorted, finite JSON.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict, fields, replace
import hashlib
import json

from .double_angle import DoubleAngle, HOLES, INDUSTRIAL, evaluate


TEMPLATES = ((76.0, 76.0, 6.4, 45.0, 45.0),
             (102.0, 102.0, 8.0, 65.0, 65.0))
DIAMETERS = (16.0, 20.0, 24.0, 30.0)
ROW_COUNTS = tuple(range(2, 21))
TEMPLATE_FIELDS = ('beam_leg', 'support_leg', 't', 'beam_gauge', 'support_gauge')
VARIABLE_FIELDS = (
    'db', 'hole_diameter', 'web_rows', 'support_rows', 'web_pitch',
    'support_pitch', 'length', 'web_end_top', 'support_end_top',
    'support_edge_top', 'support_edge_bottom',
)
_PASS_STATUSES = frozenset((
    'COMPLETE_CHECKS_PASS_WITHIN_SCOPE',
    'COMPLETE_CHECKS_PASS_WITH_PRESET_DEVIATION',
))
_BASE_STATUSES = _PASS_STATUSES | {'VERIFIED_SUBCHECK_FAIL', 'DETAIL_FAIL'}
RANKING = (
    'Menor comprimento no mesmo gabarito atual; depois menor total de '
    'parafusos (alma + 2 × apoio), menor diâmetro e digest determinístico. '
    'Comparação limitada aos candidatos enumerados; sem estimativa de massa '
    'ou garantia de ótimo global.'
)


def _canonical(value):
    """Reject NaN/Infinity rather than silently creating unstable identities."""
    return json.dumps(value, sort_keys=True, ensure_ascii=False,
                      separators=(',', ':'), allow_nan=False)


def _digest(value):
    return hashlib.sha256(_canonical(value).encode('utf-8')).hexdigest()


def _connection(base):
    if isinstance(base, DoubleAngle):
        # Native export validates every field, including catalog identity.
        base.to_dict()
        return base
    if isinstance(base, dict):
        return DoubleAngle.from_dict(deepcopy(base))
    raise ValueError('A base deve ser DoubleAngle ou um projeto nativo R016.')


def project_digest(base):
    """Digest of the complete validated native project, including all inputs."""
    return _digest(_connection(base).to_dict())


def _forbidden_issue(issue, *, detail=False):
    severity = issue.get('severity', '')
    return (severity.endswith('_pending')
            or severity.startswith(('invalid', 'unsupported', 'numerical'))
            or (detail and severity == 'detail_fail'))


def _blocking_reasons(result, *, candidate=False):
    reasons = []
    statuses = _PASS_STATUSES if candidate else _BASE_STATUSES
    if result.get('status') not in statuses:
        reasons.append('Estado nativo não elegível: ' + str(result.get('status')) + '.')
    if result.get('geometry', {}).get('valid') is not True:
        reasons.append('Geometria nativa não validada.')
    if result.get('summary', {}).get('complete_checks') is not True:
        reasons.append('Verificações nativas incompletas; pendências não podem ser contornadas pela busca.')
    for issue in result.get('issues', []):
        if _forbidden_issue(issue, detail=candidate):
            reasons.append(str(issue.get('severity')) + ': ' + str(issue.get('text', '')))
    checks = result.get('checks', [])
    if not checks:
        reasons.append('Nenhuma verificação resistente nativa concluída.')
    if candidate:
        if result.get('global_pass') is not True:
            reasons.append('O motor nativo não aprovou globalmente este candidato.')
        failures = [str(row.get('id', '?')) for row in checks if row.get('status') != 'PASS']
        if failures:
            reasons.append(str(len(failures)) + ' verificação(ões) nativa(s) sem PASS.')
    return reasons


def _changes(base, candidate):
    # Inspect every native field, rather than hiding unexpected input changes.
    return [{'field': f.name, 'before': getattr(base, f.name),
             'after': getattr(candidate, f.name)}
            for f in fields(DoubleAngle)
            if getattr(base, f.name) != getattr(candidate, f.name)]


def _candidate_id(base_digest, project):
    return 'r016-' + _digest({'base_digest': base_digest, 'project': project})


def _rejection(c, project, base_digest, result, reasons, is_original):
    return {
        'id': _candidate_id(base_digest, project),
        'is_original': is_original,
        'status': result.get('status'),
        'reasons': reasons,
        'variables': {key: getattr(c, key) for key in VARIABLE_FIELDS},
        'failed_check_ids': [row.get('id') for row in result.get('checks', [])
                             if row.get('status') != 'PASS'],
        'issues': [{key: issue[key] for key in ('severity', 'text', 'field', 'reference')
                    if key in issue} for issue in result.get('issues', [])
                   if _forbidden_issue(issue, detail=True)],
        'geometry_errors': list(result.get('geometry', {}).get('errors', [])),
        'complete_checks': result.get('summary', {}).get('complete_checks') is True,
        'global_pass': result.get('global_pass') is True,
    }


def _patterns(base):
    """Generate only the explicitly permitted substitutions, with fixed ends."""
    top_y = base.angle_top + base.support_end_top - base.support_edge_top
    bottom_y = (base.angle_top + base.support_end_top
                + (base.support_rows - 1) * base.support_pitch
                + base.support_edge_bottom)
    yield base
    for db in DIAMETERS:
        end, pitch = INDUSTRIAL[db]
        for rows in ROW_COUNTS:
            first_y = base.angle_top + end
            last_y = first_y + (rows - 1) * pitch
            yield replace(
                base, db=db, hole_diameter=HOLES[db],
                web_rows=rows, support_rows=rows,
                web_pitch=pitch, support_pitch=pitch,
                web_end_top=end, support_end_top=end,
                length=2 * end + (rows - 1) * pitch,
                support_edge_top=first_y - top_y,
                support_edge_bottom=bottom_y - last_y,
            )


def search(c):
    """Enumerate safe native proposals, or explain why the original blocks it.

    Pure resistance/detail failures may enter; incomplete checks, pending issues,
    invalid inputs/geometry, numerical failure and undocumented templates may not.
    No candidate fixes those baseline gates by quietly changing another input.
    """
    result = evaluate(c)
    base_project = None
    base_digest = None
    export_reason = None
    try:
        base_project = _connection(c).to_dict()
        base_digest = _digest(base_project)
    except (ValueError, TypeError, OverflowError) as exc:
        export_reason = 'Projeto nativo inválido: ' + str(exc)
    report = {
        'base_project': base_project,
        'base_digest': base_digest,
        'base_evaluation': result,
        'status': 'BLOCKED',
        'reasons': _blocking_reasons(result),
        'counts': {'evaluated': 0, 'accepted': 0, 'rejected': 0, 'duplicates': 0},
        'accepted': [],
        'rejected': [],
        'domain': {
            'templates': [list(template) for template in TEMPLATES],
            'current_template_only': True,
            'diameters_mm': list(DIAMETERS),
            'rows': list(ROW_COUNTS),
            'include_original': True,
            'maximum_patterns_including_original': 1 + len(DIAMETERS) * len(ROW_COUNTS),
            'physical_hole_policy': 'HOLES[db]; alteração explícita de hole_diameter',
            'fixed_column_endpoints': True,
            'variable_fields': list(VARIABLE_FIELDS),
        },
        'ranking': RANKING,
    }
    if export_reason:
        report['reasons'].append(export_reason)
    template = tuple(getattr(c, name, None) for name in TEMPLATE_FIELDS)
    # Exact published domain: no rounding of Gerdau 76.2/101.6 dimensions.
    if template not in TEMPLATES:
        report['reasons'].append('Gabarito atual fora dos dois conjuntos exatos documentados; nenhuma dimensão será arredondada ou substituída.')
    if report['reasons']:
        return report

    seen = []
    for candidate in _patterns(c):
        # Retain a complete finite payload even for invalid attempted dimensions,
        # solely to identify and reject them; only native valid exports are accepted.
        project = deepcopy(base_project)
        project['connection'] = asdict(candidate)
        digest = _digest(project)
        # Native numeric equality also deduplicates 20 versus 20.0, without
        # rewriting either project's stored inputs or its canonical digest.
        if candidate in seen:
            report['counts']['duplicates'] += 1
            continue
        seen.append(candidate)
        is_original = digest == base_digest
        evaluated = result if is_original else evaluate(candidate)
        report['counts']['evaluated'] += 1
        reasons = _blocking_reasons(evaluated, candidate=True)
        if reasons:
            report['rejected'].append(_rejection(
                candidate, project, base_digest, evaluated, reasons, is_original))
            continue
        # Native round-trip is mandatory and no alternative project format is used.
        project = candidate.to_dict()
        native = DoubleAngle.from_dict(project)
        changes = _changes(c, native)
        if any(change['field'] not in VARIABLE_FIELDS for change in changes):
            raise ValueError('O candidato alterou uma entrada fora do escopo autorizado.')
        report['accepted'].append({
            'id': _candidate_id(base_digest, project),
            'project': project,
            'evaluation': evaluated,
            'score': [native.length, native.web_rows + 2 * native.support_rows,
                      native.db, digest],
            'changes': changes,
            'is_original': is_original,
        })
    report['accepted'].sort(key=lambda entry: entry['score'])
    report['counts']['accepted'] = len(report['accepted'])
    report['counts']['rejected'] = len(report['rejected'])
    report['status'] = 'CANDIDATES_FOUND' if report['accepted'] else 'NO_CANDIDATE'
    if not report['accepted']:
        report['reasons'].append('Nenhum candidato do conjunto limitado passou por todas as verificações nativas; isto não demonstra inexistência de outra solução.')
    return report


def validated_proposal(base, candidate_id):
    """Recompute a base-bound accepted ID; never trust a saved proposal payload."""
    if not isinstance(candidate_id, str) or not candidate_id:
        raise ValueError('Identificador de candidato R016 inválido.')
    current = _connection(base)
    report = search(current)
    for entry in report['accepted']:
        if entry['id'] == candidate_id:
            return DoubleAngle.from_dict(deepcopy(entry['project']))
    raise ValueError('Proposta R016 ausente, obsoleta ou não aprovada na busca atual. '
                     + ' '.join(report['reasons']))
