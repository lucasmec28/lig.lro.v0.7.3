"""Diagnostic fixed-fixed gross beam and end-weld demands; N, mm, MPa.

No capacity/approval, rupture interaction, stability exemption or receiver check.
Coordinates: x outward, y up, M positive counterclockwise. Internal resultants
act on the positive-y cut of the lower retained body (N positive tension).
"""
import math

LIMITATIONS = (
    'First-order constant gross EA/EI Euler–Bernoulli beam; both end translations and rotations fixed.',
    'No primary in-plane reaction credited to the vertical column-web weld.',
    'Hole deductions change section geometry only, not global stiffness; point-load cuts are one-sided idealizations.',
    'End welds reuse the .65-qualified rigid isotropic elastic throat allocation model, not an elastic receiver model.',
    'No global fin strength, N/Q/M rupture interaction, FLT exemption, horizontal plate or base-metal capacity, or structural approval.',
)


def _finite(*values):
    if not all(isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v) for v in values):
        raise ValueError('Finite real numeric inputs required.')


def _positive(*values):
    _finite(*values)
    if any(v <= 0 for v in values):
        raise ValueError('Positive dimensions/material values required.')


def solve_fixed_fixed(height, width, thickness, load_ys, forces, load_x, E=200000., shear_flexible=False):
    """Closed-form fixed-end compatibility; signed forces are (Fx,Fy) ON rib.

    The signed bolt Fx distribution already contains the bolt-group couple.
    Add only (load_x-width/2)*Fy at the gross centroid, never another bolt
    group or pin eccentricity moment. Returns serializable loads/supports/spans.
    E and gross A/I document the model; uniform stiffness magnitude cancels.
    """
    _positive(height, width, thickness, E); _finite(load_x)
    ys=list(load_ys); fs=list(forces)
    if len(ys) != len(fs):
        raise ValueError('One force pair required per ordinate.')
    if any(not isinstance(p, (tuple,list)) or len(p)!=2 for p in fs):
        raise ValueError('Each force must be an (Fx,Fy) pair.')
    for y,(p,q) in zip(ys,fs):
        _finite(y,p,q)
        if not -height/2 < y < height/2:
            raise ValueError('Loads must be strictly between end supports.')
    if ys != sorted(ys) or len(set(ys)) != len(ys):
        raise ValueError('Load ordinates must be unique and ascending.')
    H=height; xc=width/2; loads=[]; terms=[[],[]]
    for y,(p,q) in zip(ys,fs):
        a=y+H/2; b=H-a; m=(load_x-xc)*q
        loads.append(dict(y=y,x=load_x,Fx=p,Fy=q,M_centroid=m))
        terms[0].append((-p*b*b*(3*a+b)/H**3-6*m*a*b/H**3,
                         -q*b/H,p*a*b*b/H**2-m*b*(b-2*a)/H**2))
        terms[1].append((-p*a*a*(a+3*b)/H**3+6*m*a*b/H**3,
                         -q*a/H,-p*a*a*b/H**2-m*a*(a-2*b)/H**2))
    supports=[dict(id=name,x=xc,y=y,**{k:math.fsum(v[j] for v in terms[i]) for j,k in enumerate(('Fx','Fy','Mz'))})
              for i,(name,y) in enumerate((('bottom',-H/2),('top',H/2)))]
    if type(shear_flexible) is not bool:
        raise ValueError('shear_flexible must be boolean.')
    if shear_flexible:
        # Uniform Timoshenko compatibility: integral M=0 and
        # integral (H-z) M dz = EI/(kGA) * integral Q dz.
        # nu=.3, k=5/6 are fixed, explicit sensitivity assumptions.
        lam=(width**2/12)*2.6/(5/6)
        S1=math.fsum(p['Fx']*(H/2-p['y'])**2/2+p['M_centroid']*(H/2-p['y']) for p in loads)
        S2=math.fsum(p['Fx']*(H/2-p['y'])**3/6+p['M_centroid']*(H/2-p['y'])**2/2 for p in loads)
        SP=math.fsum(p['Fx']*(H/2-p['y']) for p in loads)
        RA=(S2-S1*H/2-lam*SP)/(H**3/12+lam*H)
        MA=-RA*H/2-S1/H
        RB=-math.fsum(p['Fx'] for p in loads)-RA
        MB=H*RB-MA-math.fsum(p['M_centroid']-(p['y']+H/2)*p['Fx'] for p in loads)
        supports[0].update(Fx=RA,Mz=MA); supports[1].update(Fx=RB,Mz=MB)
    result=dict(height=H,width=width,thickness=thickness,E=E,A=width*thickness,
                I=thickness*width**3/12,centroid_x=xc,loads=loads,supports=supports)
    result.update(beam_theory='Timoshenko' if shear_flexible else 'Euler–Bernoulli',
                  shear_correction=5/6 if shear_flexible else None,poisson_ratio=.3 if shear_flexible else None)
    nodes=[-H/2]+ys+[H/2]
    result['spans']=[dict(y0=a,y1=b,lower=cut_resultants(result,a,'above'),
                          upper=cut_resultants(result,b,'below')) for a,b in zip(nodes,nodes[1:])]
    result['equilibrium_residual']=[
        math.fsum([s['Fx'] for s in supports]+[p['Fx'] for p in loads]),
        math.fsum([s['Fy'] for s in supports]+[p['Fy'] for p in loads]),
        math.fsum([s['x']*s['Fy']-s['y']*s['Fx']+s['Mz'] for s in supports]+
                  [p['x']*p['Fy']-p['y']*p['Fx'] for p in loads])]
    _check_output(result)
    return result


def _check_output(obj):
    if isinstance(obj,dict):
        for v in obj.values(): _check_output(v)
    elif isinstance(obj,(tuple,list)):
        for v in obj: _check_output(v)
    elif isinstance(obj,(int,float)) and not math.isfinite(obj):
        raise ArithmeticError('Nonfinite computed output.')


def cut_resultants(model,y,side='below'):
    """Concomitant signed N,Q,M at gross centroid, including exact load jumps."""
    _finite(y)
    if side not in ('below','above') or not -model['height']/2 <= y <= model['height']/2:
        raise ValueError('Cut side/domain invalid.')
    lower=[p for p in model['loads'] if p['y']<y or (p['y']==y and side=='above')]
    s=model['supports'][0]
    out=dict(y=y,side=side,N=-s['Fy']-math.fsum(p['Fy'] for p in lower),
             Q=-s['Fx']-math.fsum(p['Fx'] for p in lower),
             M=-s['Mz']-(y-s['y'])*s['Fx']-math.fsum(p['M_centroid']+(y-p['y'])*p['Fx'] for p in lower))
    _check_output(out); return out


def section_properties(width, thickness, y, holes=()):
    """Exact rectangular rib horizontal cut minus union of circular-hole chords.

    holes: iterable of (x_center,y_center,net_diameter). Holes must fit the
    width; callers validate height. Overlapping deductions are unioned once.
    Z is the N=0 plastic section modulus, never a general N+M bound.
    """
    _positive(width,thickness); _finite(y); intervals=[(0.,width)]
    for x,h,d in holes:
        _finite(x,h); _positive(d); r=d/2
        if x-r<0 or x+r>width: raise ValueError('Hole exceeds rib width.')
        if abs(y-h)<r:
            chord=math.sqrt(max(0.,r*r-(y-h)**2)); a=x-chord; b=x+chord
            intervals=[(u,v) for lo,hi in intervals for u,v in ((lo,min(hi,a)),(max(lo,b),hi)) if v>u]
    length=math.fsum(b-a for a,b in intervals)
    if length<=0: raise ValueError('Hole deductions eliminate section.')
    xc=math.fsum((b-a)*(a+b)/2 for a,b in intervals)/length
    I=thickness*math.fsum((b-a)**3/12+(b-a)*((a+b)/2-xc)**2 for a,b in intervals)
    rem=length/2; xp=None
    for a,b in intervals:
        if rem<=b-a: xp=a+rem; break
        rem-=b-a
    F=lambda x: .5*(x-xp)*abs(x-xp)
    out=dict(intervals=intervals,A=length*thickness,xc=xc,I=I,
             Z=thickness*math.fsum(F(b)-F(a) for a,b in intervals),plastic_axis=xp,
             xmin=intervals[0][0],xmax=intervals[-1][1])
    _check_output(out); return out


def end_weld_groups(model,corner_clip,leg,throat_solver=None):
    """Two separate horizontal receiver joints, each with two fillets.

    Free M=-support Mz at (b/2,yend). Do NOT pass an origin moment as
    a free couple. Each returned group integrates the receiver wrench.
    """
    _finite(corner_clip); _positive(leg)
    b=model['width']
    if corner_clip<0 or 2*corner_clip>=b: raise ValueError('Invalid weld corner clip.')
    if throat_solver is None:
        from lro.double_cover_weld import elastic_throat_group
        throat_solver=elastic_throat_group
    groups=[]
    for s in model['supports']:
        seg=dict(id=s['id'],start_mm=[corner_clip,s['y']],end_mm=[b-corner_clip,s['y']],leg_mm=leg,fillet_count=2)
        group=throat_solver([seg],-s['Fx'],-s['Fy'],b/2,s['y'],-s['Mz'])
        groups.append(dict(id=s['id'],receiver_action=dict(Fx=-s['Fx'],Fy=-s['Fy'],Mz=-s['Mz'],point=[b/2,s['y']]),throat=group))
    return groups


def evaluate_preset_beam(c, signed_bolt_forces, E=200000., throat_solver=None, shear_flexible=False):
    """Adapter for real double_cover rectangular, internally perforated preset.

    Requires caller's signed bolt forces; deliberately does not call evaluate
    or change design actions. Importing this module performs no app imports.
    """
    _positive(c.root_height,c.projection,c.fin_t,c.pitch,c.dh_net)
    _finite(c.extension,c.fin_group_x)
    if c.extension != 0: raise ValueError('Gross rectangular beam requires zero fin extension.')
    if type(c.n) is not int or c.n<1: raise ValueError('Positive integer bolt count required.')
    forces=list(signed_bolt_forces)
    if len(forces)!=c.n: raise ValueError('Force count differs from preset bolt count.')
    ys=[(i-(c.n-1)/2)*c.pitch for i in range(c.n)]
    if max(abs(y) for y in ys)+c.dh_net/2>=c.root_height/2:
        raise ValueError('Net hole reaches an end support.')
    holes=[(c.fin_group_x,y,c.dh_net) for y in ys]
    # Validate full hole-width domain even if no sampled chord crosses a hole.
    section_properties(c.projection,c.fin_t,ys[0],holes)
    model=solve_fixed_fixed(c.root_height,c.projection,c.fin_t,ys,forces,c.fin_group_x,E,shear_flexible)
    model['end_weld_groups']=end_weld_groups(model,c.corner_clip,c.weld_fin_stiffener,throat_solver)
    sections=[]
    for y in sorted(set([-c.root_height/2,c.root_height/2]+ys+[v+d for v in ys for d in (-c.dh_net/2,c.dh_net/2)])):
        sec=section_properties(c.projection,c.fin_t,y,holes)
        for side in (('below','above') if y in ys else (('above',) if y==-c.root_height/2 else ('below',))):
            actions=cut_resultants(model,y,side)
            actions['M_net_centroid']=actions['M']+(model['centroid_x']-sec['xc'])*actions['N']
            sections.append(dict(section=sec,actions=actions))
    from lro.models import STEELS
    steel=STEELS[c.fin_steel]; _positive(steel.fy,steel.fu)
    notes=list(LIMITATIONS)
    if shear_flexible:
        notes[0]='First-order uniform gross Timoshenko beam; kappa=5/6, nu=.3; both end translations and rotations fixed. Sensitivity, not a conservative bound.'
    model.update(material=dict(name=c.fin_steel,fy=steel.fy,fu=steel.fu,E=E),holes=holes,
                 sections=sections,limitations=notes,status='diagnostic_only')
    _check_output(model); return model
