"""Lossless physical envelopes for the qualified welded angle/gusset route.

This module never recalculates resistance. Public drawing and report exports
obtain their own current canonical evaluation before building these envelopes.
"""
from .display_precision import display_format
from collections import OrderedDict
from copy import deepcopy
from math import isfinite

COMPONENT_LABELS = {
    'angle': 'Cantoneira por face', 'angle_pair': 'Par 2L opostas', 'gusset': 'Chapa de nó',
    'angle_weld': 'Soldas cantoneira–chapa', 'angle_welds': 'Soldas cantoneira–chapa',
    'root_weld': 'Soldas da raiz chapa–mesa', 'root_welds': 'Soldas da raiz chapa–mesa',
    'angle_substrate': 'Metal base da cantoneira junto à solda',
    'gusset_substrate': 'Metal base da chapa junto às soldas',
    'support': 'Apoio W receptor local', 'support_flange': 'Mesa W receptora local',
    'support_web': 'Alma W receptora local', 'w_flange': 'Mesa W receptora local',
    'w_web': 'Alma W receptora local',
    'gusset_root': 'Chapa na raiz', 'support_contact': 'Mesa W no contato dos filetes',
}
MECHANISM_LABELS = {
    'allocated_face_screen': 'Chapa única · triagem por face t/2', 'tension': 'Tração bruta / efetiva', 'longitudinal_substrate': 'Metal base nas soldas longitudinais',
    'root_substrate': 'Metal base na raiz', 'weld_heel': 'Solda do calcanhar',
    'weld_toe': 'Solda da ponta', 'local_normal_yield': 'Escoamento normal local',
    'longitudinal_shear': 'Cisalhamento longitudinal', 'combined_yield': 'Escoamento combinado local',
    'local_bending': 'Flexão local da mesa',
    'gross_yield': 'Escoamento da seção bruta', 'gross_yielding': 'Escoamento da seção bruta',
    'tension_rupture': 'Ruptura da seção efetiva', 'effective_rupture': 'Ruptura da seção efetiva',
    'net_rupture': 'Ruptura da seção efetiva', 'net_fracture': 'Ruptura da seção efetiva',
    'block': 'Bloco / rasgamento e limite conservador',
    'block_shear': 'Bloco / rasgamento e limite conservador',
    'block_tearout': 'Bloco / rasgamento e limite conservador',
    'yield': 'Envelope de escoamento', 'yielding': 'Envelope de escoamento',
    'rupture': 'Envelope de ruptura', 'weld': 'Metal de solda',
    'weld_metal': 'Metal de solda', 'fillet_weld': 'Metal de solda',
    'substrate': 'Cisalhamento local do metal base',
    'shear': 'Cisalhamento do metal base', 'shear_yield': 'Escoamento por cisalhamento',
    'shear_rupture': 'Ruptura por cisalhamento', 'local_yield': 'Escoamento local',
    'local_yielding': 'Escoamento local', 'punching': 'Cisalhamento por puncionamento',
    'plane_stress': 'Interação local no plano', 'interaction': 'Interação local no plano',
    'normal_yield': 'Escoamento normal local',
}


def _finite(value):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return False
    try:
        return isfinite(value)
    except (OverflowError, ValueError):
        return False



def selected_angle(c, result=None):
    """Resolve identity for presentation without ever substituting a section.

    Evaluated geometry is authoritative. Catalog data are also available on a
    diagnostic export whose calculation could not build valid geometry.
    """
    from .angle_catalog import get_angle
    section = ((result or {}).get('geometry') or {}).get('angle_section')
    if section and section.get('id', section.get('name')) == c.angle_profile:
        return deepcopy(section)
    return get_angle(c.angle_profile)


def angle_transfer(section):
    """Catalog-centroid split; no default section or fabricated centroid."""
    if not section or not all(_finite(section.get(k)) for k in ('leg', 'centroid')) or section['leg'] <= 0:
        return None
    toe = section['centroid'] / section['leg']
    return {'heel': 1. - toe, 'toe': toe, 'projected_centroid': 0.}


def angle_identity(section, fallback='não reconhecida'):
    if not section:
        return str(fallback)
    return str(section.get('manufacturer', 'Fabricante não informado')) + ' · ' + str(section.get('name', fallback)).replace('x', '×').replace('.', ',')


def angle_detail_disclosure(section):
    """Describe only supplied radii/flat, preserving unpublished-data gaps."""
    if not section:
        return 'Seção não reconhecida; propriedades e contorno não presumidos.'
    names = [('root_radius', 'Raio interno'), ('toe_radius', 'Raio da ponta'), ('toe_flat', 'Face plana da ponta')]
    parts = []
    for key, name in names:
        value = section.get(key)
        parts.append(name + (': ' + display_format(value, '.6g').replace('.', ',') + ' mm' if _finite(value) else ': não publicado'))
    if any(not _finite(section.get(key)) for key, _ in names):
        parts.append('Contorno nominal esquemático; cantos sem geometria presumida.')
    return '; '.join(parts)


def component_label(component):
    return COMPONENT_LABELS.get(str(component), str(component).replace('_', ' '))


def _governors(rows):
    finite = [row for row in rows if _finite(row.get('utilization'))]
    maximum = max((row['utilization'] for row in finite), default=None)
    # Unknown demand or capacity is an unresolved witness, never a hidden pass.
    unresolved = [row for row in rows if not _finite(row.get('utilization'))]
    tied = unresolved + [row for row in finite if row['utilization'] == maximum]
    return maximum, deepcopy(tied)


def _status(rows):
    if not rows:
        return 'NOT_EVALUATED'
    if any(row.get('status') == 'FAIL' or row.get('passed') is False for row in rows):
        return 'FAIL'
    if all(row.get('status') == 'PASS' or row.get('passed') is True for row in rows):
        return 'PASS'
    return 'NOT_VERIFIED'


def physical_envelopes(result):
    """Group only matching physical component/mechanism; retain every witness.

    Both actual and all-case envelopes retain exact ties, IDs, signs and source
    metadata. The serial load path is preserved; no capacities are ever added.
    """
    groups = OrderedDict()
    for row in result.get('checks') or []:
        if not isinstance(row, dict):
            continue
        component = str(row.get('envelope_component', row.get('component', 'unidentified')))
        face = str(row.get('face') or (row.get('details') or {}).get('face') or '')
        if face not in ('face_positive', 'face_negative'):
            face = next((f for f in ('face_positive', 'face_negative') if str(row.get('id', '')).endswith(f)), '')
        mechanism=str(row.get('envelope_mechanism', row.get('mechanism', 'unidentified')))
        if face and mechanism.endswith('_'+face):mechanism=mechanism[:-len(face)-1]
        key = (component, mechanism, face)
        groups.setdefault(key, []).append(row)
    cases = result.get('cases') or []
    if isinstance(cases, dict):
        cases = list(cases.values())
    actual_ids = {str(case.get('id', case.get('case_id'))) for case in cases
                  if isinstance(case, dict) and (case.get('id') == 'actual' or case.get('kind') in ('actual', 'design'))}
    actual_ids.add('actual')
    envelopes = []
    transfer = angle_transfer((result.get('geometry') or {}).get('angle_section'))
    for (component, mechanism, face), rows in groups.items():
        actual = [row for row in rows if str(row.get('case_id')) in actual_ids
                  or row.get('case_kind') in ('actual', 'design')]
        maximum, governing = _governors(rows)
        actual_maximum, actual_governing = _governors(actual)
        mechanism_label = MECHANISM_LABELS.get(mechanism, mechanism.replace('_', ' '))
        if transfer and mechanism in ('weld_heel', 'weld_toe'):
            fraction = transfer['heel' if mechanism == 'weld_heel' else 'toe']
            mechanism_label += ' · ' + display_format(100 * fraction, '.6g').replace('.', ',') + '% de N/2 (' + display_format(50 * fraction, '.6g').replace('.', ',') + '% de N total)'
        envelopes.append({
            'id': component + '__' + mechanism + ('__' + face if face else ''),
            'face': face or None,
            'force_scope': 'N/2 por cantoneira' if face or component=='angle' else 'N total do par',
            'component': component, 'component_label': component_label(component) + ({'face_positive': ' · face +z', 'face_negative': ' · face −z'}.get(face, '')),
            'mechanism': mechanism,
            'mechanism_label': mechanism_label,
            'units': rows[0].get('unit', rows[0].get('units', '')),
            'utilization': maximum, 'adopted_utilization': maximum,
            'actual_utilization': actual_maximum,
            'status': _status(rows), 'actual_status': _status(actual),
            'governing': governing, 'governing_ties': deepcopy(governing),
            'adopted_governing_ties': deepcopy(governing),
            'actual_governing': actual_governing,
            'actual_governing_ties': deepcopy(actual_governing),
            'governing_ids': [row.get('id') for row in governing],
            'member_ids': [row.get('id') for row in rows],
            'members': deepcopy(rows),
        })
    return envelopes


def governing_description(row):
    """Unambiguous short physical witness, including every available location."""
    parts = [str(row.get('id', 'sem identificação'))]
    # The stable primitive ID already contains the case and physical point.
    for key in ('face', 'side', 'cut_id', 'section_id', 'point', 'location', 'x_mm', 'y_mm'):
        if row.get(key) is not None:
            parts.append(key + '=' + str(row[key]))
    metadata = row.get('metadata') or {}
    for key in ('y', 'x', 'x_interval', 'M_bound', 'sigma', 'tau', 'side'):
        if key in metadata:
            parts.append(key + '=' + str(metadata[key]))
    return '; '.join(parts)
