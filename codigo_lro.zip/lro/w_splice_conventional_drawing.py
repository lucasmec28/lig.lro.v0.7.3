"""Four or eight physical covers, conventional signed N/M/V annotations only.

The axial module is read-only. Its geometric artist builder is reused, with
all figure-level force-model text removed before conventional labels are added.
"""
from .display_precision import display_format, display_value
from io import BytesIO
import matplotlib.pyplot as plt
from .w_splice_drawing import _figure as _geometry_figure, _header, _profile_header_rows, COVERS, INK
from .w_splice_conventional import evaluate, input_digest

SUPPORT_DETAIL = (
    'Apoio nas filas completas: dois membros, contato firme nas sobreposições, parafusos/porcas/arruelas instalados.',
    'Restrições laterais e à torção dos membros; sem folgas de calço, tiras soltas, filas ausentes ou apoio provisório.',
    'Le/Lb = maior intervalo entre filas completas; K = 1; peças separadas. Sem crédito de contato de topo.',
)


def _signed(value,scale,places=3):
    converted=value/scale
    if converted!=0 and (abs(converted)<.0005 or abs(converted)>=1e9):return f"{display_format(converted, '+.12g')}"
    return f"{display_format(converted, '+.'+str(places)+'f')}"


def _figure(c, result=None):
    result=evaluate(c)  # Never trust caller-supplied status, forces or copied inputs.
    fig = _geometry_figure(c, result)
    # Do not leave an old N>0-only label in a signed N/M/V artifact.
    for artist in list(fig.texts):
        artist.remove()
    precision=2 if c.no_slip_required else 3
    p = c.profile
    lf = c.gap + 2*(c.flange_member_end+(c.flange_rows-1)*c.flange_pitch+c.flange_cover_end)
    lw = c.gap + 2*(c.web_member_end+(c.web_rows-1)*c.web_pitch+c.web_cover_end)
    lm = result.get('load_model', {}) if isinstance(result, dict) else {}
    h0 = p.d-p.tf
    ft = lm.get('top_force_N', c.N/2-c.M/h0)
    fb = lm.get('bottom_force_N', c.N/2+c.M/h0)
    status = str(result.get('status','RESULTADO NÃO FORNECIDO')) if isinstance(result,dict) else 'RESULTADO NÃO FORNECIDO'
    if c.no_slip_required:
        states={'LOCAL_CHECKS_PASS_WITHIN_SCOPE':'VERIFICAÇÕES LOCAIS ATENDEM','SERVICE_SLIP_FAILURE':'NÃO ATENDE AO DESLIZAMENTO','VERIFIED_SUBCHECK_FAIL':'NÃO ATENDE AO ELU','LOCAL_CHECKS_PENDING':'DADOS/CONDIÇÕES PENDENTES'}
        status=states.get(status,status)
    _header(fig, [
        ('EMENDA W CONVENCIONAL | N / M / V', 15, 'bold'),
        ('Projeto: '+str(c.project), 9, 'normal'),
        *_profile_header_rows(fig, p.name, f' | N = {display_value(_signed(c.N, 1000, precision))} kN; M = {display_value(_signed(c.M, 1000000.0, precision))} kN·m; V = {display_value(_signed(c.V, 1000, precision))} kN', 10.5),
        (f'F superior = {display_value(_signed(ft, 1000, precision))} kN; F inferior = {display_value(_signed(fb, 1000, precision))} kN | tração + | Nw = Mw(0) = 0; alma transfere V e Ve', 10, 'normal'),
        (f"T informado = {display_format(c.torsion, '+.17g')} N·mm | Conclusão somente local; torção não nula fora do domínio.", 8.5, 'normal'),
    ])
    fig.text(.965,.979,status,fontsize=8,ha='right',color=INK)
    if c.no_slip_required:
        outcome={'PASS':'ATENDE','FAIL':'NÃO ATENDE','PENDING':'PENDENTE','NOT_EVALUATED':'NÃO AVALIADO'}.get(result.get('slip',{}).get('status'),'INDISPONÍVEL')
        fig.text(.965,.959,'Deslizamento ELS: '+outcome,fontsize=8,ha='right',color=INK)
    inner=c.include_inner_flange_plates
    labels = [
        f"W1 + W2   2 × {display_format(lw, 'g')} × {display_format(c.web_height, 'g')} × {display_format(c.web_t, 'g')} mm",
        f"F1 + F4     2 × {display_format(lf, 'g')} × {display_format(c.flange_outer_width, 'g')} × {display_format(c.flange_t, 'g')} mm",
        *([f"F2 F3 F5 F6   4 × {display_format(lf, 'g')} × {display_format(c.flange_inner_width, 'g')} × {display_format(c.flange_t, 'g')} mm"] if inner else []),
        f"Alma: p={display_format(c.web_pitch, 'g')}; g={display_format(c.web_gauge, 'g')}; bordas={display_format(c.web_member_end, 'g')}/{display_format(c.web_cover_end, 'g')}",
        f"Mesas: p={display_format(c.flange_pitch, 'g')}; bordas={display_format(c.flange_member_end, 'g')}/{display_format(c.flange_cover_end, 'g')}",
        f"Parafuso Ø{display_format(c.db, 'g')}; furo Ø{display_format(c.hole_diameter, 'g')}; cotas em mm",
    ]
    fig.text(.035,.225,('8' if inner else '4')+' TALAS CONTÍNUAS E SEPARADAS',fontsize=10.5,fontweight='bold',color=INK)
    fig.text(.035,.208,'\n'.join(labels),fontsize=9,linespacing=1.4,va='top',color=INK)
    if not inner:
        labels.append(f"Mesas: 1 plano; alma: 2 planos. e real = {display_format((p.tf+c.flange_t)/2, '.2f')} mm; W íntegro com restrição mesa–alma.")
        fig.texts[-1].set_text('\n'.join(labels))
    detail = getattr(c,'assembly_detail','unsupported_detail')
    if detail == 'complete_row_supported_detail_v1':
        le=max(c.gap+2*c.flange_member_end,c.flange_pitch)
        lb=max(c.gap+2*c.web_member_end,c.web_pitch)
        notes = SUPPORT_DETAIL[:2]+(f"Le mesas={display_format(le, 'g')} mm; Lb alma={display_format(lb, 'g')} mm; K=1; peças separadas. Sem contato de topo; não libera fabricação.",)
    else:
        notes = ('DETALHE DE APOIO NÃO ADMITIDO: capacidades de estabilidade não qualificadas.',
                 'Condições de montagem e apoio devem corresponder ao detalhe completo documentado.',
                 'Sem crédito de contato de topo. Esquema não libera fabricação.')
    for y,text in zip((.066,.047,.028),notes):
        fig.text(.035,y,text,fontsize=8.4,color=INK)
    fig.text(.035,.009,'Talas atravessam a junta. Extremidades em série; capacidades não se somam. Fonte: Fakury §10.14.7; NBR 8800:2024 + Er1:2025.',fontsize=8.4,color=INK)
    return fig


def image_bytes(c,result=None,fmt='png'):
    with plt.rc_context({'font.family':'DejaVu Sans','font.size':10,'svg.fonttype':'none'}):
        fig=_figure(c,result)
        try:
            stream=BytesIO()
            fig.savefig(stream,format=fmt,dpi=170,facecolor='white',metadata={'Creator':'LRO conventional W N/M/V','Description':'input_digest='+input_digest(c)})
            return stream.getvalue()
        finally:
            plt.close(fig)


def drawing_svg(c,result=None):
    return image_bytes(c,result,'svg').decode('utf-8')
