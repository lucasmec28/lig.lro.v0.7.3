"""Eight physical covers, conventional signed N/M/V annotations only.

The axial module is read-only. Its geometric artist builder is reused, with
all figure-level force-model text removed before conventional labels are added.
"""
from io import BytesIO
import matplotlib.pyplot as plt
from .w_splice_drawing import _figure as _geometry_figure, _header, _profile_header_rows, COVERS, INK
from .w_splice_conventional import evaluate

SUPPORT_DETAIL = (
    'Apoio nas filas completas: dois membros, contato firme nas sobreposições, parafusos/porcas/arruelas instalados.',
    'Restrições laterais e à torção dos membros; sem folgas de calço, tiras soltas, filas ausentes ou apoio provisório.',
    'Le/Lb = maior intervalo entre filas completas; K = 1; peças separadas. Sem crédito de contato de topo.',
)


def _signed(value,scale):
    converted=value/scale
    if converted!=0 and (abs(converted)<.0005 or abs(converted)>=1e9):return f'{converted:+.12g}'
    return f'{converted:+.3f}'


def _figure(c, result=None):
    result=evaluate(c)  # Never trust caller-supplied status, forces or copied inputs.
    fig = _geometry_figure(c, result)
    # Do not leave an old N>0-only label in a signed N/M/V artifact.
    for artist in list(fig.texts):
        artist.remove()
    p = c.profile
    lf = c.gap + 2*(c.flange_member_end+(c.flange_rows-1)*c.flange_pitch+c.flange_cover_end)
    lw = c.gap + 2*(c.web_member_end+(c.web_rows-1)*c.web_pitch+c.web_cover_end)
    lm = result.get('load_model', {}) if isinstance(result, dict) else {}
    h0 = p.d-p.tf
    ft = lm.get('top_force_N', c.N/2-c.M/h0)
    fb = lm.get('bottom_force_N', c.N/2+c.M/h0)
    status = str(result.get('status','RESULTADO NÃO FORNECIDO')) if isinstance(result,dict) else 'RESULTADO NÃO FORNECIDO'
    _header(fig, [
        ('EMENDA W CONVENCIONAL | N / M / V', 15, 'bold'),
        ('Projeto: '+str(c.project), 9, 'normal'),
        *_profile_header_rows(fig, p.name, f' | N = {_signed(c.N,1000)} kN; M = {_signed(c.M,1e6)} kN·m; V = {_signed(c.V,1000)} kN', 10.5),
        (f'F superior = {_signed(ft,1000)} kN; F inferior = {_signed(fb,1000)} kN | tração + | Nw = Mw(0) = 0; alma transfere V e Ve', 10, 'normal'),
        (f'T informado = {c.torsion:+.17g} N·mm | Conclusão somente local; torção não nula fora do domínio.', 8.5, 'normal'),
    ])
    fig.text(.965,.979,status,fontsize=8,ha='right',color=INK)
    labels = [
        f'W1 + W2   2 × {lw:g} × {c.web_height:g} × {c.web_t:g} mm',
        f'F1 + F4     2 × {lf:g} × {c.flange_outer_width:g} × {c.flange_t:g} mm',
        f'F2 F3 F5 F6   4 × {lf:g} × {c.flange_inner_width:g} × {c.flange_t:g} mm',
        f'Alma: p={c.web_pitch:g}; g={c.web_gauge:g}; bordas={c.web_member_end:g}/{c.web_cover_end:g}',
        f'Mesas: p={c.flange_pitch:g}; bordas={c.flange_member_end:g}/{c.flange_cover_end:g}',
        f'Parafuso Ø{c.db:g}; furo Ø{c.hole_diameter:g}; cotas em mm',
    ]
    fig.text(.035,.225,'8 TALAS CONTÍNUAS E SEPARADAS',fontsize=10.5,fontweight='bold',color=INK)
    fig.text(.035,.208,'\n'.join(labels),fontsize=9,linespacing=1.4,va='top',color=INK)
    detail = getattr(c,'assembly_detail','unsupported_detail')
    if detail == 'complete_row_supported_detail_v1':
        le=max(c.gap+2*c.flange_member_end,c.flange_pitch)
        lb=max(c.gap+2*c.web_member_end,c.web_pitch)
        notes = SUPPORT_DETAIL[:2]+(f'Le mesas={le:g} mm; Lb alma={lb:g} mm; K=1; peças separadas. Sem contato de topo; não libera fabricação.',)
    else:
        notes = ('DETALHE DE APOIO NÃO ADMITIDO: capacidades de estabilidade não qualificadas.',
                 'Condições de montagem e apoio devem corresponder ao detalhe completo documentado.',
                 'Sem crédito de contato de topo. Esquema não libera fabricação.')
    for y,text in zip((.066,.047,.028),notes):
        fig.text(.035,y,text,fontsize=8.4,color=INK)
    fig.text(.035,.009,'Talas atravessam a junta. Extremidades em série; capacidades não se somam. Fonte: Fakury §10.14.7; NBR 8800:2024 + Er1:2025.',fontsize=8.4,color=INK)
    return fig


def image_bytes(c,result=None,fmt='png'):
    with plt.rc_context({'font.family':'DejaVu Sans','font.size':10,'svg.fonttype':'none'}):
        fig=_figure(c,result)
        try:
            stream=BytesIO()
            fig.savefig(stream,format=fmt,dpi=170,facecolor='white',metadata={'Creator':'LRO conventional W N/M/V'})
            return stream.getvalue()
        finally:
            plt.close(fig)


def drawing_svg(c,result=None):
    return image_bytes(c,result,'svg').decode('utf-8')
