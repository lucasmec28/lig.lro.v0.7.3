"""Qualified two-flange normal/web-shear component, NBR resistance.

DG1 3e Ex4.7-9 motivates the exterior-flange M/d path; the signed N/M
extension is statics, not a claim that the guide solved every flexible base.
The effective transfer model is supplied and bound to current inputs.
"""
from dataclasses import asdict
import hashlib
import json
import math

from .models import Issue, STEELS, finite_real
from .base_plate_details import fillet_dimensions
from .active_shear_key import PATHS as ACTIVE_KEY_PATHS
from .column_base_weld import (G1, G2, FW, SUPPORTED_STEELS, WELDED_FAMILIES,
                               fillet_line_resistance, cjp_resistance)

MODEL = 'two_flange_normal_web_shear'
REF = 'NBR 8800:2024 corrigida 2025, 6.2/6.5/6.6.2; DG1 3ª ed., 4.3.2, 4.3.5–4.3.10, Ex.4.7-5 e 4.7-9'
SCOPE = ('Componente de solda e seções locais íntegras do pilar. A distribuição por duas mesas e os comprimentos '
         'efetivos dependem da memória de transferência vinculada. Ruptura/fusão local e flexão–cisalhamento '
         'do metal-base da placa, transmissão aos chumbadores/contato, ancoragem completa, bloco/fundação '
         'e rigidez rotacional não são aprovados por este componente.')
QUALIFICATION_METHODS = ('guide_example', 'one_way', 'plate_model')
RECORD_FIELDS = ('transfer_ref',)
CALCULATION_BASIS = ('N/M nas duas mesas, V na alma; FL+FR=−N, xL FL+xR FR=M. '
                     'Alocação e equilíbrio calculados pelo app; compatibilidade placa–chumbadores não inferida.')
DESIGN_SPECIFICATION = ('Trechos retos contínuos, centrados e a tamanho completo; seções íntegras, acesso e ausência de interferências. '
                        'Processo e detalhes indicados são requisitos de projeto; execução e inspeção em obra não verificadas pelo app.')


def qualification_signature(c, legacy=False):
    """Binds substantive records to current actions/geometry/material/execution.

    This is evidence currency, not verification of the supplied engineering
    argument. Project title and free project notes do not change mechanics.
    """
    keys = ('N','M','V','plate_steel','tp','a1','a2','db','stiffener_detail',
            'weld_web_type','weld_flange_type','anchor_washer_side','anchor_washer_t',
            'shear_path','grout_t','fck','grout_fck')
    data = {name: getattr(c,name,None) for name in keys}
    data['column'] = {name: getattr(c.column,name,None) for name in
                      ('family','d','bf','tw','tf','clear','area')}
    # Bind the physical weld, not its leg/throat representation. Twelve
    # significant digits remove only sqrt(2) round-trip floating point noise.
    for part in ('web','flange'):
        if getattr(c,'weld_'+part+'_type',None)=='fillet':
            size=getattr(c,'weld_'+part+'_size')
            measure=getattr(c,'weld_'+part+'_measure')
            try:
                leg=fillet_dimensions(size,measure)['leg']
                if not finite_real(leg):
                    raise ValueError('Dimensão física não finita.')
                data['weld_'+part+'_physical_leg']=float(f'{leg:.12g}')
            except (ValueError,OverflowError):
                # Invalid drafts still get a stable diagnostic identity; they
                # never gain a resistance or qualification from this digest.
                data['weld_'+part+'_invalid_dimension']={'size':size,'measure':measure}
    data['column_weld'] = asdict(c.column_weld)
    if not legacy:
        for key in ('allocation_basis','effective_length_basis','execution_ref','procedure_ref','inspection_ref'):
            data['column_weld'].pop(key,None)
    for key in ('qualification_signature','detail_confirmed'):
        data['column_weld'].pop(key, None)
    if c.column_weld.normal_transfer!='fit_bearing':
        for key in ('bearing_area','bearing_ref','bearing_basis'):
            data['column_weld'].pop(key,None)
    if 'cjp' not in (getattr(c,'weld_web_type',None),getattr(c,'weld_flange_type',None)):
        for key in ('cjp_detail','inspection_ref','cjp_charpy_confirmed','base_charpy_confirmed'):
            data['column_weld'].pop(key,None)
    if getattr(c,'stiffener_detail','none')!='none':
        data['stiffener']={name:getattr(c,name,None) for name in
                          ('stiffener_length','stiffener_height','stiffener_t')}
    path=getattr(c,'shear_path',None)
    if path=='plate':
        data['plate_key']={name:getattr(c,name,None) for name in
                          ('lug_bh','lug_bv','lug_t','lug_steel')}
    if path in ACTIVE_KEY_PATHS and hasattr(c,'active_key'):
        data['active_key'] = asdict(c.active_key)
    if path=='anchors':
        data['anchor_shear_model']=getattr(c,'anchor_shear_model',None)
        if getattr(c,'native_anchor_shear',False) and hasattr(c,'upper_washer'):
            if c.upper_washer.model!='off':
                data['upper_washer'] = asdict(c.upper_washer)
    data['model_type'] = getattr(c, 'model_type', None)
    data['physical_plate'] = {k: getattr(c, k, None) for k in ('L', 'B', 'a')}

    def normalize(value):
        if isinstance(value, dict):
            return {key: normalize(item) for key,item in value.items()}
        if isinstance(value, (list,tuple)):
            return [normalize(item) for item in value]
        if type(value) in (int,float):
            number=float(value)
            return 0.0 if number==0 else number
        return value
    return hashlib.sha256(json.dumps(normalize(data), sort_keys=True, separators=(',', ':'),
                                    ensure_ascii=False, allow_nan=False).encode()).hexdigest()


def qualification_binding_kind(c):
    """Recognize exact legacy evidence without reviving changed physical scopes."""
    entered=c.column_weld.qualification_signature
    if not entered:return 'missing'
    if entered==qualification_signature(c):return 'current'
    if entered==qualification_signature(c,legacy=True):return 'legacy_current'
    return 'stale'


def result_signature(c):
    """Full-input export freshness, distinct from custom engineering evidence."""
    return hashlib.sha256(json.dumps(asdict(c),sort_keys=True,ensure_ascii=False,
                                    allow_nan=False).encode()).hexdigest()


def qualification_missing(c):
    u = c.column_weld
    missing = []
    if u.qualification_method not in QUALIFICATION_METHODS:
        missing.append('método da memória de transferência')
    labels = dict(transfer_ref='referência específica da memória de compatibilidade placa–chumbadores e dos comprimentos efetivos',
                  allocation_basis='justificativa de N/M integral nas duas mesas e V na alma',
                  effective_length_basis='justificativa dos comprimentos efetivos na geometria atual',
                  execution_ref='detalhe de execução, integridade, acesso e interferências')
    for key in RECORD_FIELDS:
        if not isinstance(getattr(u, key, None), str) or not getattr(u, key).strip():
            missing.append(labels[key])
    return missing


def signed_flange_forces(N, M, x_left, x_right):
    """Forces positive in tension on column; N positive compression. N,mm."""
    if any(not finite_real(v) or abs(v) > 1e15 for v in (N, M, x_left, x_right)):
        raise ValueError('Ações e planos de transferência devem ser reais finitos.')
    h = x_right - x_left
    if h <= 0:
        raise ValueError('Os planos de transferência devem satisfazer xL<xR.')
    left = (-M - N*x_right)/h
    right = (M + N*x_left)/h
    return dict(x_left_mm=x_left, x_right_mm=x_right, h_mm=h,
                F_left_N=left, F_right_N=right,
                normal_resultant_N=left+right,
                moment_resultant_Nmm=x_left*left+x_right*right,
                residual_N_N=left+right+N,
                residual_M_Nmm=x_left*left+x_right*right-M)


def web_design_length(physical, effective, leg):
    """Conservative NBR long longitudinal weld limit; no directional gain.

    Supplied effective length is never increased. The cap addresses
    nonuniform end transfer conservatively even if a record permits more.
    """
    if any(not finite_real(v) or v <= 0 for v in (physical, effective, leg)):
        raise ValueError('Comprimentos e perna da alma devem ser positivos e finitos.')
    beta = min(1., max(.6, 1.2-.002*physical/leg))
    cap = beta*physical if physical <= 300*leg else 180*leg
    return min(effective, cap), beta


def assumptions(c):
    return [
        'Componente duas mesas normais/alma ao corte: I/H duplamente simétrico, sem enrijecedores; '
        'todas as ações de cálculo na face superior da placa. N positivo comprime. '
        'Toda N/M forte é alocada às duas mesas; V integral às duas faces de filete da alma ou a uma seção CJP.',
        'Forças positivas tracionam o pilar: FL+FR=−N; xL FL+xR FR=M informado. '
        'Filetes externos nas mesas: x=±d/2; CJP: x=±(d−tf)/2. Não usa M+V eV da chave inferior.',
        'Comprimentos físicos/efetivos retos, contínuos e centrados são explícitos; não há crédito automático '
        'por gabarito de chumbadores, espessura resistente da placa, filetes internos ou perímetro completo. '
        'Memória de distribuição/transferência pode usar cálculo unidirecional, exemplo aplicável ou modelo de placa; não se exige FEA.',
        'Filetes E7018: a=z/√2 e 0,6 fw a/1,35, sem aumento direcional AISC. CJP é uma única seção fundida. '
        'Compressão é verificada nas soldas, salvo contato preparado qualificado em compressão pura. '
        'A assinatura apenas vincula a documentação aos dados atuais; o aplicativo não valida seu conteúdo.',
        SCOPE,
    ]


def add_qualified_checks(c, r, add):
    u, p = c.column_weld, c.column
    out = dict(model=MODEL, status='pending', numerical_status='not_calculated',
               connection_status='pending', complete=False, statuses={}, reasons=[], scope=SCOPE,
               qualification_status='missing', qualification_signature=u.qualification_signature,
               normal_transfer_requested=u.normal_transfer, normal_transfer_applied='welded',
               calculation_basis=CALCULATION_BASIS,design_specification=DESIGN_SPECIFICATION,
               execution_status='specified_not_verified')
    try:
        out['current_signature']=qualification_signature(c)
        out['input_signature']=result_signature(c)
    except (ValueError,TypeError,OverflowError):
        out['current_signature']=''
    passed, required_pending = [], []
    def pending(text, key=None):
        out['reasons'].append(text); required_pending.append(text)
        if key: out['statuses'][key] = 'pending'
        r.issues.append(Issue('pending', text, REF, origin='column_weld'))
    def fail(text):
        out['reasons'].append(text); out['status']='fail'; out['numerical_status']='fail'
        r.issues.append(Issue('noncompliance', text, REF, origin='column_weld'))
    def check(key, name, sd, rd, unit, equation, variables):
        add('cwq_'+key, name, sd, rd, unit, REF, equation,
            f'Sd={sd:.10g}; Rd={rd:.10g}', variables)
        ok = finite_real(sd) and finite_real(rd) and rd > 0 and abs(sd) <= rd*(1+1e-10)
        out['statuses'][key] = 'pass' if ok else 'fail'; passed.append(ok)
        return ok
    if getattr(c, 'model_type', None) not in (1,2):
        pending('O componente foi definido somente para as bases I/H Tipo 1 e Tipo 2.'); return out
    if getattr(c, 'stiffener_detail', 'none') != 'none':
        pending('A alocação duas mesas/alma foi definida sem enrijecedores; o detalhe enrijecido requer outro campo.'); return out
    if any(not finite_real(getattr(c,k,None)) or abs(getattr(c,k))>1e15 for k in ('N','M','V')):
        pending('Ações inválidas na face superior da placa.'); return out
    if any(not finite_real(getattr(p,k,None)) or not 0<getattr(p,k)<=1e6 for k in ('d','bf','tw','tf','clear')):
        pending('Dimensões reais da seção I/H inválidas.'); return out
    if p.d<=2*p.tf or p.bf<=p.tw or p.clear>p.d-2*p.tf+1e-8:
        fail('Seção I/H incompatível com os trechos retos e simétricos informados.'); return out
    if not finite_real(c.tp) or not 0<c.tp<=1e6:
        pending('Espessura real da placa inválida.'); return out
    if u.column_steel not in SUPPORTED_STEELS or c.plate_steel not in SUPPORTED_STEELS:
        pending('Identifique independentemente os aços de pilar e placa compatíveis com E7018.'); return out
    cs, ps = STEELS[u.column_steel], STEELS[c.plate_steel]
    if not ps.plate_allowed or not ps.plate_min<=c.tp<=ps.plate_max:
        fail('Placa fora do produto/espessura admitido para o aço selecionado.'); return out
    if p.family in WELDED_FAMILIES:
        material_ok=cs.plate_allowed and all(cs.plate_min<=t<=cs.plate_max for t in (p.tw,p.tf))
    else:
        material_ok=cs.rolled_allowed and all(cs.profile_min<=t<=cs.profile_max for t in (p.tw,p.tf))
    if not material_ok:
        fail('Pilar fora do produto/espessura admitido para o aço selecionado.'); return out
    kinds={part:getattr(c,'weld_'+part+'_type','unspecified') for part in ('flange','web')}
    if any(kind not in ('fillet','cjp') for kind in kinds.values()):
        pending('Especifique independentemente filete externo ou CJP nas mesas e filete/CJP na alma.'); return out
    if not finite_real(getattr(c,'B',None)) or not finite_real(getattr(c,'L',None)) or c.B<=p.tw or c.L<p.d:
        fail('Placa sem superfície física suficiente para as juntas modeladas.'); return out
    lengths={'flange':(u.flange_length,u.flange_effective_length,min(p.bf,c.B)),
             'web':(u.web_length,u.web_effective_length,p.clear)}
    for part,(physical,effective,available) in lengths.items():
        if physical<=0 or effective<=0:
            pending('Informe comprimentos físico e efetivo positivos da '+('mesa' if part=='flange' else 'alma')+'.'); return out
        if effective>physical+1e-8 or physical>available+1e-8:
            fail('Comprimento efetivo deve caber no trecho físico, e este no trecho reto real da '+('mesa (bf).' if part=='flange' else 'alma (clear).')); return out
    current=qualification_signature(c); out['current_signature']=current
    binding=qualification_binding_kind(c);out['qualification_binding_kind']=binding
    missing=qualification_missing(c)
    if missing:
        pending('Qualificação da transferência pendente: '+ '; '.join(missing)+'.', 'transfer_qualification')
    elif binding not in ('current','legacy_current'):
        out['qualification_status']='stale' if u.qualification_signature else 'missing'
        pending('Memória de transferência não vinculada aos dados atuais; confirmar aplicabilidade após revisar ações, geometria, soldas e comprimentos.', 'transfer_qualification')
    else:
        out['qualification_status']='qualified'; out['statuses']['transfer_qualification']='documented_current'
    if 'fillet' in kinds.values() and u.process not in ('smaw_e7018_single_pass','smaw_e7018_mixed'):
        pending('Filetes: especificar SMAW/E7018 em passe único, ou execução mista com filetes em passe único.', 'fillet_execution')
    if 'cjp' in kinds.values():
        if u.process not in ('smaw_e7018','smaw_e7018_mixed'):
            pending('CJP: especificar procedimento SMAW/E7018 compatível.', 'cjp_process')
        if u.cjp_detail not in ('backing_removed','backing_retained'):
            pending('CJP: especifique a preparação de penetração total e a condição do cobre-junta; execução/inspeção permanecem requisitos do projeto.', 'cjp_detail')
        if u.cjp_detail=='backing_retained' and not u.cjp_charpy_confirmed:
            pending('CJP com cobre-junta mantido: comprovar Charpy 27 J a temperatura máxima de 4 °C.', 'cjp_charpy')
    h=p.d if kinds['flange']=='fillet' else p.d-p.tf
    forces=signed_flange_forces(c.N,c.M,-h/2,h/2)
    out.update(forces)
    out.update(N_input_N=c.N,M_input_Nmm=c.M,V_input_N=c.V,
               flange_length_mm=u.flange_length,flange_effective_length_mm=u.flange_effective_length,
               web_length_mm=u.web_length,web_effective_length_mm=u.web_effective_length,
               bearing_force_N=0.,bearing_area_mm2=u.bearing_area,
               web_shear_N=c.V,shear_resultant_N=c.V,residual_V_N=0.)
    tension=max(forces['F_left_N'],forces['F_right_N'])>0
    if kinds['flange']=='cjp' and tension and max(p.tw,p.tf)>50:
        if not u.base_charpy_confirmed: pending('CJP em seção espessa tracionada: comprovar tenacidade do metal-base de 12.2.1.5.', 'base_charpy')
        if not u.cjp_charpy_confirmed: pending('CJP em seção espessa tracionada: comprovar também tenacidade do metal de solda de 6.2.4.2(b).', 'cjp_charpy_thick')
    if u.normal_transfer=='fit_bearing':
        area_geom=2*p.bf*p.tf+(p.d-2*p.tf)*p.tw
        bearing_valid=(c.N>0 and c.M==0 and u.bearing_area>0 and u.bearing_area<=area_geom+1e-8
                       and u.bearing_ref.strip() and u.bearing_basis.strip()
                       and out['qualification_status']=='qualified')
        if not bearing_valid:
            pending('Contato preparado sem crédito: exige N>0, M=0, área real positiva contida na seção e referências de preparo/capacidade vinculadas. A compressão continua integralmente nas soldas.', 'bearing_path')
        else:
            rd=1.8*u.bearing_area*min(cs.fy,ps.fy)/G2
            out['bearing_resistance_N']=rd
            if check('bearing','Pilar–placa — contato preparado em compressão pura',c.N,rd,'N',
                     'N ≤ 1,8 Acont min(fy,pilar;fy,placa)/γa2',
                     'Área efetiva de contato preparada documentada; não usa a área da placa. NBR6.6.2 e 12.2.1.6/.8.'):
                out.update(F_left_N=0.,F_right_N=0.,bearing_force_N=-c.N,normal_transfer_applied='fit_bearing')
            else:
                pending('Contato preparado insuficiente; não se zera a compressão nas soldas nem se soma contato e solda.', 'bearing_path')
    out['normal_resultant_N']=out['F_left_N']+out['F_right_N']+out['bearing_force_N']
    out['moment_resultant_Nmm']=out['x_left_mm']*out['F_left_N']+out['x_right_mm']*out['F_right_N']
    out['residual_N_N']=out['normal_resultant_N']+c.N
    out['residual_M_Nmm']=out['moment_resultant_Nmm']-c.M
    out['statuses']['equilibrium']='balanced'
    for part in ('flange','web'):
        kind=kinds[part]; physical,effective,_=lengths[part]
        t=p.tf if part=='flange' else p.tw
        demand=max(abs(out['F_left_N']),abs(out['F_right_N'])) if part=='flange' else abs(c.V)
        row=dict(kind=kind,physical_length_mm=physical,effective_length_mm=effective,
                 design_length_mm=effective,area_column_mm2=effective*t)
        if kind=='fillet':
            try: dims=fillet_dimensions(getattr(c,'weld_'+part+'_size'),getattr(c,'weld_'+part+'_measure'))
            except (ValueError,OverflowError) as exc: fail(str(exc)); return out
            leg=dims['leg']; design=effective; beta=1.
            if part=='web': design,beta=web_design_length(physical,effective,leg)
            row.update(leg_mm=leg,throat_mm=dims['throat'],design_length_mm=design,longitudinal_beta=beta)
            faces=1 if part=='flange' else 2
            try:
                rd=faces*design*fillet_line_resistance(leg)
            except (ValueError,OverflowError) as exc:
                fail(str(exc)); return out
            row['q_per_face_N_per_mm']=(c.V if part=='web' else demand)/(faces*effective)
            row['q_design_per_face_N_per_mm']=demand/(faces*design)
            minimum=3 if min(t,c.tp)<=6.3 else 5 if min(t,c.tp)<=12.5 else 6 if min(t,c.tp)<=19 else 8
            check(part+'_leg_min','Pilar–placa — perna mínima '+('mesas' if part=='flange' else 'alma'),minimum,leg,'mm',
                  'z ≥ zmin', 'Tabela11, parte menos espessa, filete de pernas iguais em passe único.')
            check(part+'_length_min','Pilar–placa — trecho efetivo mínimo '+('mesas' if part=='flange' else 'alma'),max(40.,4*leg),effective,'mm',
                  'Leff ≥ max(40;4z)', 'Comprimento efetivo contínuo não inclui concordâncias ou retornos.')
            shelf=(c.L-p.d)/2 if part=='flange' else (min(p.bf,c.B)-p.tw)/2
            check(part+'_shelf','Pilar–placa — espaço físico para filete '+('externo da mesa' if part=='flange' else 'da alma'),leg,shelf,'mm',
                  'z ≤ prateleira disponível', 'Geometria nominal; acesso, furos/arruelas e terminações constam do detalhe vinculado.')
            equation=('|Fi| ≤ Leff·0,6 fw·a/γw2' if part=='flange' else '|V| ≤ 2 Ld·0,6 fw·a/γw2')
            variables=('Um filete externo por mesa; compressão atribuída também verificada.' if part=='flange' else
                       'Duas faces, V/2 cada; Ld=min(Leff;βLreal), β≤1 e cap180z para Lreal>300z. Redução longitudinal conservadora, sem ganho direcional.')
        else:
            try:
                cj=cjp_resistance(effective,t,c.tp,cs.fy,ps.fy)
            except (ValueError,OverflowError) as exc:
                fail(str(exc)); return out
            rd=cj['R_normal_N'] if part=='flange' else cj['R_shear_N']
            row.update(cjp_area_mm2=cj['A_MB_mm2'],q_per_face_N_per_mm=(c.V if part=='web' else demand)/effective)
            equation='|Fi| ≤ Leff min(tf;tp) min(fy)/γa1' if part=='flange' else '|V| ≤ 0,6 Leff min(tw;tp) min(fy)/γa1'
            variables='Uma seção fundida, sem duplicar faces; materiais, procedimento, preparação e inspeção permanecem explícitos.'
        row.update(resistance_N=rd,utilization=demand/rd)
        out[part]=row
        if part=='flange':
            row['q_left_N_per_mm']=out['F_left_N']/effective
            row['q_right_N_per_mm']=out['F_right_N']/effective
            for side in ('left','right'):
                force=out['F_'+side+'_N']
                check('flange_'+side+'_weld','Pilar–placa — '+('filete externo' if kind=='fillet' else 'CJP')+' da mesa '+('−x' if side=='left' else '+x'),abs(force),rd,'N',equation,variables+f' Fi={force:.10g} N, positivo traciona o pilar.')
                area=effective*t
                check('flange_'+side+'_yield','Pilar–placa — escoamento local da mesa '+('−x' if side=='left' else '+x'),abs(force),area*cs.fy/G1,'N',
                      '|Fi| ≤ Leff tf fy,pilar/γa1', 'Uma seção real íntegra do pilar; não duplica por faces de solda. Não verifica instabilidade do membro.')
                if force>0:
                    check('flange_'+side+'_rupture','Pilar–placa — ruptura local da mesa tracionada '+('−x' if side=='left' else '+x'),force,area*cs.fu/G2,'N',
                          'Fi ≤ Aef fu,pilar/γa2', 'Seção líquida íntegra no trecho efetivo; exclui furos/recortes, shear lag ou caminho adicional não qualificado.')
        else:
            check('web_weld','Pilar–placa — '+('dois filetes da alma' if kind=='fillet' else 'CJP única da alma')+' ao corte',demand,rd,'N',equation,variables)
            area=effective*p.tw
            check('web_yield','Pilar–placa — escoamento local da alma ao corte',demand,.6*area*cs.fy/G1,'N',
                  '|V| ≤ 0,6 Leff tw fy,pilar/γa1','Toda V em uma alma íntegra; nunca duas áreas por duas soldas.')
            check('web_rupture','Pilar–placa — ruptura local da alma ao corte',demand,.6*area*cs.fu/G2,'N',
                  '|V| ≤ 0,6 Leff tw fu,pilar/γa2','Área líquida efetiva real; integridade e trechos sem furos/recortes constam do detalhe.')
    out['normal_resultant_N']=out['flange']['q_left_N_per_mm']*u.flange_effective_length+out['flange']['q_right_N_per_mm']*u.flange_effective_length+out['bearing_force_N']
    out['moment_resultant_Nmm']=(out['x_left_mm']*out['flange']['q_left_N_per_mm']+out['x_right_mm']*out['flange']['q_right_N_per_mm'])*u.flange_effective_length
    out['shear_resultant_N']=out['web']['q_per_face_N_per_mm']*u.web_effective_length*(2 if kinds['web']=='fillet' else 1)
    out['residual_N_N']=out['normal_resultant_N']+c.N
    out['residual_M_Nmm']=out['moment_resultant_Nmm']-c.M
    out['residual_V_N']=out['shear_resultant_N']-c.V
    out['numerical_status']='pass' if all(passed) else 'fail'
    out['status']='fail' if not all(passed) else 'pending' if required_pending else 'pass'
    r.issues.append(Issue('pending',SCOPE,REF,origin='column_weld_scope'))
    return out
