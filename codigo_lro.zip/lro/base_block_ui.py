"""Actual block dimensions/offsets editor; unchanged imports retain exact canonical limits."""
import streamlit as st


def _limits(s,p):return tuple(s[p+'_'+name] for name in ('block_xmin','block_xmax','block_ymin','block_ymax'))
def _sync(s,p):
    limits=_limits(s,p)
    if s.get('_'+p+'_block_editor_limits')==limits and '_'+p+'_block_editor_values' in s:return
    xmin,xmax,ymin,ymax=limits
    # Canonical bounds own geometry. These shadows survive widget cleanup when
    # dimensions/offset controls are hidden by coordinates or navigation.
    s['_'+p+'_block_editor_values']=dict(block_length=xmax-xmin,block_width=ymax-ymin,
        block_offset_x=(xmin+xmax)/2,block_offset_y=(ymin+ymax)/2,
        block_centered=(xmin+xmax==0 and ymin+ymax==0))
    s['_'+p+'_block_editor_limits']=limits


def _dimensions_changed(p,field):
    s=st.session_state
    xmin,xmax,ymin,ymax=_limits(s,p)
    x=(xmin+xmax)/2;y=(ymin+ymax)/2;L=xmax-xmin;B=ymax-ymin
    value=s[p+'_'+field]
    # Use only the deliberately edited widget. Every unedited dimension/offset
    # comes from canonical bounds, never stale hidden widget defaults.
    if field=='block_length':L=value;xmin=x-L/2;xmax=x+L/2
    elif field=='block_width':B=value;ymin=y-B/2;ymax=y+B/2
    elif field=='block_offset_x':xmin=value-L/2;xmax=value+L/2
    elif field=='block_offset_y':ymin=value-B/2;ymax=value+B/2
    elif field=='block_centered' and value:xmin=-L/2;xmax=L/2;ymin=-B/2;ymax=B/2
    for name,value_bound in zip(('block_xmin','block_xmax','block_ymin','block_ymax'),(xmin,xmax,ymin,ymax)):
        s[p+'_'+name]=value_bound
    s['_'+p+'_block_editor_limits']=None
    _sync(s,p)
    if field=='block_centered':
        # Unchecking opens the offset controls even while both offsets are zero;
        # it is an editor choice, not a request to change the physical bounds.
        s['_'+p+'_block_editor_values']['block_centered']=bool(value)


def _mode_changed(p):st.session_state['_'+p+'_block_editor_mode']=st.session_state[p+'_block_editor_mode']


def seed_block_editor(c,p):
    s=st.session_state
    s['_'+p+'_block_editor_limits']=None
    for name in ('block_xmin','block_xmax','block_ymin','block_ymax'):s[p+'_'+name]=float(getattr(c,name))
    _sync(s,p)


def block_geometry_widgets(p):
    s=st.session_state;_sync(s,p)
    # Preserve editor UI choices independently of widget cleanup on navigation.
    modekey=p+'_block_editor_mode'
    s[modekey]=s.get(modekey,s.get('_'+p+'_block_editor_mode','dimensions'))
    mode=st.selectbox('Geometria real do bloco',['dimensions','coordinates'],key=modekey,
        format_func=lambda value:'Dimensões e posição' if value=='dimensions' else 'Limites x/y · coordenadas',on_change=_mode_changed,args=(p,))
    if mode=='coordinates':
        a,b=st.columns(2)
        with a:
            st.number_input('Bloco · x mínimo (mm)',key=p+'_block_xmin')
            st.number_input('Bloco · y mínimo (mm)',key=p+'_block_ymin')
        with b:
            st.number_input('Bloco · x máximo (mm)',key=p+'_block_xmax')
            st.number_input('Bloco · y máximo (mm)',key=p+'_block_ymax')
    else:
        # Rehydrate from the persistent canonical shadow, never from a hidden
        # widget's residual value. Callbacks already committed deliberate edits.
        for key,value in s['_'+p+'_block_editor_values'].items():s[p+'_'+key]=value
        a,b=st.columns(2)
        with a:st.number_input('Comprimento real do bloco Lb (mm)',key=p+'_block_length',on_change=_dimensions_changed,args=(p,'block_length'))
        with b:st.number_input('Largura real do bloco Bb (mm)',key=p+'_block_width',on_change=_dimensions_changed,args=(p,'block_width'))
        st.checkbox('Bloco centrado na placa',key=p+'_block_centered',on_change=_dimensions_changed,args=(p,'block_centered'))
        if not s[p+'_block_centered']:
            a,b=st.columns(2)
            with a:st.number_input('Deslocamento do centro do bloco ex (mm)',key=p+'_block_offset_x',on_change=_dimensions_changed,args=(p,'block_offset_x'))
            with b:st.number_input('Deslocamento do centro do bloco ey (mm)',key=p+'_block_offset_y',on_change=_dimensions_changed,args=(p,'block_offset_y'))
        st.caption('Dimensões reais do bloco; nenhuma dimensão mínima tabulada é adotada automaticamente. A troca de editor preserva os limites exatos do projeto.')
