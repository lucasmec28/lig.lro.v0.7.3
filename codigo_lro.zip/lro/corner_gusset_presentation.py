"""Lossless component envelopes and concise, copyable full-joint force lineage.

Presentation is not a second resistance model. Every public artifact reevaluates
its native inputs; supplied result dictionaries cannot authorize a stale pass.
"""
from collections import OrderedDict
from copy import deepcopy
import hashlib
import json
import math

STATUS = {'PASS': 'ATENDE LOCALMENTE NO DOMÍNIO', 'FAIL': 'NÃO ATENDE',
          'INVALID': 'DADOS OU GEOMETRIA INVÁLIDOS', 'UNVERIFIED': 'NÃO VERIFICADO',
          'NUMERICAL_FAILURE': 'FALHA NUMÉRICA'}
COMPONENT_LABELS = {
    'angle': 'Cantoneiras 2L-T', 'brace': 'Cantoneiras 2L-T',
    'brace_weld': 'Quatro soldas 2L–chapa', 'angle_weld': 'Quatro soldas 2L–chapa',
    'brace_welds': 'Quatro soldas 2L–chapa', 'gusset': 'Chapa de nó única',
    'beam_root': 'Raiz na viga', 'column_root': 'Raiz no pilar',
    'root_weld': 'Soldas das duas raízes', 'root_welds': 'Soldas das duas raízes',
    'beam_receiver': 'Viga receptora', 'column_receiver': 'Pilar receptor',
    'beam': 'Viga e ligação direta', 'column': 'Pilar receptor',
    'beam_joint': 'Ligação direta viga–pilar', 'joint': 'Ligação direta viga–pilar',
    'continuity': 'Chapas de continuidade', 'continuity_weld': 'Soldas das chapas de continuidade',
    'continuity_receiver': 'Receptor das chapas de continuidade', 'panel': 'Painel da alma do pilar',
    'detail': 'Detalhamento', 'detailing': 'Detalhamento', 'material': 'Materiais',
    'materials': 'Materiais', 'equilibrium': 'Equilíbrio do mesmo caso concorrente',
    'root_seams': 'Duas raízes chapa–viga/pilar',
    'receivers': 'Regiões receptoras da viga e do pilar',
    'beam_column_joint': 'Ligação direta viga–pilar',
    'member_web_shear': 'Almas receptoras sob cortante concorrente',
    'local_member_material': 'Triagens dos membros remotos (diagnóstico)',
    'continuity_welds': 'Soldas da continuidade',
    'angles': 'Cantoneiras 2L-T',
    'bolted_adapter':'Diagonal parafusada', 'common_gusset':'Chapa de nó única',
    'bolts':'Parafusos · planos físicos', 'angle_bearing':'Contato nos furos das L',
    'gusset_bearing':'Contato nos furos da chapa única','angle_block':'Blocos das cantoneiras',
    'gusset_block':'Blocos reais da chapa única','gusset_sections':'Seções reais da chapa · triagem',
    'gusset_whitmore':'Faixa Whitmore da chapa única',
    'gusset_compression':'Chapa de nó · estabilidade em compressão',
    'continuity_plates': 'Chapas de continuidade',
    'beam_web_shear': 'Alma da viga · cortante concorrente',
    'column_web_shear': 'Alma do pilar · cortante concorrente',
}
SCOPE_TEXT = ('2L-T simétricas soldadas à mesma chapa de canto recortada; duas raízes nas mesas da viga e do pilar. '
              'Ligação direta viga–pilar por CJP nas mesas e dois filetes na alma; pares horizontais de continuidade '
              'nos níveis das mesas. Tração estática da diagonal no plano das almas. A tração da diagonal não elimina '
              'compressão local real no receptor. Verificação local não libera fabricação nem certifica estabilidade global.')
CUT_CONVENTION = ('COMPLETE_CUTS: ações externas assinadas sobre a ligação isolada; +x para a direita, +y para cima, '
                  '+M anti-horário. D é o corte na viga; U o corte superior do pilar; L o corte inferior derivado. '
                  'Fx/Fy/M de D e U pertencem à mesma combinação. Não somar novamente a diagonal ao recuperar '
                  'a interface completa. Ausência de outras cargas exige declaração explícita.')



def is_single(c):
    return getattr(c, 'topology', None) in ('single_1L_welded','single_1L_bolted')

def is_bolted(c):
    return getattr(c,'topology',None) in ('single_1L_bolted','symmetric_2L_T_bolted')


def scope_text(c):
    if is_bolted(c):
        return ('Uma L em uma face, um plano de corte por parafuso. ' if is_single(c) else 'Duas L idênticas em T, uma por face, parafusos passantes comuns e dois planos de corte. ')+('Uma linha longitudinal em contato direto; chapa de canto única e suas duas raízes recebem N integral uma vez. Tração estática ordinária e eixo terminal nominal NBR6.1.8.2. Contato, seções líquidas, blocos reais e Whitmore separados; telas nominais de corpo perfurado não são solução de contato. Ligação direta CJP/alma e continuidade mantidas. Montagem depende do envelope real de talão e ferramenta. Sem compressão da diagonal, fadiga, sismo, afastamentos ou ações espaciais não qualificadas. Não libera fabricação ou estabilidade global.')
    if not is_single(c) and getattr(c,'P',0)<0:
        return ('Compressão axial estática local de 2L-T simétricas continuamente soldadas; chapa de canto ordinária com duas raízes nas mesas da viga e do pilar. DG29 Apêndice C, coluna equivalente K=1 e faixa Whitmore centrada; curva NBR5.3 sem crédito de sismo ou K=0,5. Depende das três contenções fora do plano e do detalhe físico da geometria atual. Mantém ligação direta, receptores, continuidade e painel do mesmo caso completo. Não certifica estabilidade global da diagonal, membros ou pórtico nem libera fabricação.')
    if not is_single(c):return SCOPE_TEXT
    return ('Uma cantoneira soldada por uma aba diretamente a uma face da chapa de canto; dois filetes longitudinais recebem N integral. '
            'Chapa única com duas raízes nas mesas da viga e do pilar; ligação direta CJP/alma e continuidade mantidas. '
            'Modelo nominal plano estático NBR 6.1.8.2, com eixo terminal adotado no plano médio da chapa. '
            'A excentricidade física fora do plano é desprezada por essa idealização, nunca cancelada. '
            'Não demonstra equilíbrio espacial exato. Não abrange fadiga, sismo, espaçador ou ações espaciais explícitas. '
            'A tração da diagonal não elimina compressão local real no receptor. Verificação local não libera fabricação nem certifica estabilidade global.')


def idealization_text(c):
    if is_bolted(c):
        from .corner_gusset import geometry
        g=geometry(c);a=g['angle'];v=a['centroid']-c.bolt_gauge
        return ('Eixo da linha nominal no plano médio z=0. Centroide físico de cada L: v relativo à linha='+number(v)+' mm; z='+compact_value(g['spatial_idealization']['physical_angle_centroid_z'])+' mm. Momento ordinário bruto no plano='+number(-c.P*v,1e6)+' kN m. NBR6.1.8.2 permite a idealização estática de extremidade; os centroides reais não coincidem. '+('Uma L não tem cancelamento espacial. ' if is_single(c) else 'O par cancela os afastamentos z, mas não o afastamento v no plano. ')+'Ct usa ec real e distância primeiro–último parafuso. Afastamento real do ponto de trabalho permanece separado e não qualificado. Não é verificação exata3D.')
    if not is_single(c):return ''
    from .angle_catalog import get_angle
    a=get_angle(c.angle_profile)
    sign=1 if c.single_angle_face=='positive' else -1
    face=sign*c.plate_t/2;z=sign*(c.plate_t/2+a['centroid'])
    return ('1L na face '+('+' if sign>0 else '−')+'z; face z='+number(face)+' mm, centroide físico z='+number(z)+
            ' mm. Momento espacial bruto |N·z|='+number(abs(c.P*z),1e6)+' kN m, com parcelas centroide–face '+
            number(abs(c.P*a['centroid']),1e6)+' e face–plano médio '+number(abs(c.P*face),1e6)+
            ' kN m. Esses momentos não se cancelam. NBR 6.1.8.2: eixo terminal nominal adotado em z=0; '
            'afastamento ordinário desprezado no modelo estático. Resíduos de equilíbrio referem-se somente ao plano idealizado, não ao equilíbrio exato 3D.')


def finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def number(value, divisor=1., digits=6):
    if not finite(value):
        return 'não disponível'
    return format(value / divisor, '.' + str(digits) + 'g').replace('.', ',')


def utilization_text(row):
    return 'sem capacidade' if row.get('utilization_unbounded') else number(row.get('utilization'))


def result_label(result):
    label=STATUS.get(result.get('status'),str(result.get('status')))
    if result.get('complete') is not True and result.get('status') in ('PASS','FAIL'):
        label+=' · VERIFICAÇÃO INCOMPLETA'
    return label


def input_fingerprint(c):
    return hashlib.sha256(json.dumps(c.to_dict(), ensure_ascii=False, sort_keys=True,
                                    separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def validated_result(c, result=None):
    from .corner_gusset import analyze
    # Caller-supplied result is intentionally never trusted.
    return analyze(c)


def approved(r):
    rows = [x for x in r.get('checks') or [] if not x.get('diagnostic_only')]
    return (r.get('status') == 'PASS' and r.get('complete') is True and bool(rows)
            and all(row.get('status') in ('PASS', 'NOT_APPLICABLE') for row in rows)
            and not any(i.get('severity') in ('error', 'unverified') for i in r.get('issues', [])))


def component_label(key, single=False):
    if single and key in ('angle','brace','angles'):return 'Cantoneira única 1L'
    if single and key in ('brace_weld','angle_weld','brace_welds'):return 'Duas soldas 1L–chapa'
    return COMPONENT_LABELS.get(key, str(key).replace('_', ' '))


CHECK_LABELS={
 'beam_receiving_compression_web_crippling':'Enrugamento da alma receptora da viga sob compressão',
 'column_receiving_compression_web_crippling':'Enrugamento da alma receptora do pilar sob compressão',
 'gusset_centered_whitmore_compression_buckling':'Instabilidade da faixa Whitmore centrada em compressão',
 'angle_each_local_gross_compression':'Compressão bruta local de cada L ligada',
 'angle_each_compression_local_slenderness':'Esbeltez local da aba de cada L · AL3',
 'angle_each_uniform_run_shear_envelope':'Envelope de cisalhamento do trecho soldado de cada L',
 'gusset_uniform_run_shear_envelope':'Envelope de cisalhamento da chapa única',
 'column_all_local_web_shear':'Cortante máximo da alma do pilar no trecho',
 'beam_gusset_supported_shear_rupture':'Ruptura por cisalhamento da chapa na raiz da viga',
 'column_gusset_supported_shear_rupture':'Ruptura por cisalhamento da chapa na raiz do pilar',
 'angle_single_gross':'Escoamento bruto da cantoneira única',
 'angle_single_effective_rupture':'Ruptura efetiva da cantoneira única',
 'angle_single_nominal_through_leg_block':'Bloco nominal através da aba da L',
 'angle_each_gross':'Escoamento bruto de cada cantoneira',
 'angle_each_effective_rupture':'Ruptura efetiva de cada cantoneira',
 'angle_each_nominal_through_leg_block':'Bloco nominal através da aba de cada L',
 'brace_heel_angle_substrate_each_face':'Metal base da L no talão, em cada face',
 'brace_heel_gusset_face_substrate_each_face':'Metal base da chapa no talão, em cada face',
 'gusset_ordinary_partial_path_envelope':'Envelope conservador dos caminhos parciais',
 'beam_root_weld':'Metal das soldas da raiz na viga',
 'column_root_weld':'Metal das soldas da raiz no pilar',
 'beam_receiving_web_local_yield':'Escoamento local da alma receptora da viga',
 'column_receiving_web_local_yield':'Escoamento local da alma receptora do pilar',
 'column_bottom_web_local_yield':'Escoamento local da alma no nível inferior',
 'column_top_web_local_yield':'Escoamento local da alma no nível superior',
 'column_top_compression_web_crippling':'Enrugamento da alma sob compressão superior',
 'column_bottom_flange_local_bending':'Flexão local da mesa sob tração inferior',
 'joint_top_CJP_and_beam_flange':'CJP e mesa superior da viga',
 'joint_bottom_CJP_and_beam_flange':'CJP e mesa inferior da viga',
 'joint_top_beam_flange_gross':'Escoamento da mesa superior da viga',
 'joint_bottom_beam_flange_gross':'Escoamento da mesa inferior da viga',
 'continuity_bottom_plate_equilibrated_NVM':'Chapa inferior sob N/V/M em equilíbrio',
 'continuity_top_plate_equilibrated_NVM':'Chapa superior sob N/V/M em equilíbrio',
 'continuity_bottom_web_base_shear':'Metal base junto à solda de alma inferior',
 'continuity_top_web_base_shear':'Metal base junto à solda de alma superior',
 'continuity_bottom_concurrent_column_receiver_bound':'Receptor inferior com tensões concorrentes',
 'continuity_top_concurrent_column_receiver_bound':'Receptor superior com tensões concorrentes',
 'beam_uniform_traction_local_web_shear':'Cortante da alma com tração distribuída da raiz',
 'column_lower_web_shear':'Cortante da alma do pilar abaixo do painel',
 'column_panel_zone':'Cisalhamento do painel com axial concorrente',
 'joint_CJP_electrode_compatibility':'Compatibilidade do consumível CJP',
 'column_top_flange_gusset_overlap_union':'União das faixas sobrepostas da mesa e do gusset',
}


for _face,_face_label in [('positive','positiva'),('negative','negativa')]:
    for _side,_side_label in [('heel','talão'),('toe','ponta')]:
        for _part,_part_label in [('weld','Solda'),('angle_substrate','Metal base da L'),('gusset_face_substrate','Metal base da chapa')]:
            CHECK_LABELS['brace_'+_side+'_'+_part+'_'+_face+'_face']=_part_label+' no '+_side_label+', face '+_face_label


def check_label(row):
    """Portuguese short mechanism name; machine IDs remain in audit details."""
    if isinstance(row,dict) and str(row.get('id','')).startswith('minimum45__'):
        return check_label(dict(row,id=row['id'].removeprefix('minimum45__')))+' · mínimo45kN'
    identity=str(row.get('id','')) if isinstance(row,dict) else str(row)
    if isinstance(row,dict) and row.get('component') in ('bolts','angle_bearing','gusset_bearing','angle_block','gusset_block','gusset_sections','gusset_whitmore'):
        component=row['component']
        if component=='bolts':return 'Cisalhamento por plano · '+('sem rosca' if row.get('threads_excluded') else 'com rosca')
        if component in ('angle_bearing','gusset_bearing'):return 'Pressão de contato e rasgamento por furo'
        if component=='angle_block':return 'Bloco para ponta livre real · '+str(len(row.get('captured_bolts',[])))+' parafusos capturados'
        if component=='gusset_block':return 'Bloco '+('U tangente' if identity.endswith('tangent_U') else 'L negativo' if identity.endswith('negative') else 'L positivo')
        if component=='gusset_sections':return 'Triagem nominal '+('VM de escoamento' if identity.endswith('yield') else 'de ruptura normal')
        if component=='gusset_whitmore':return 'Whitmore '+('bruto' if identity.endswith('gross') else 'líquido complementar')
    if identity.endswith('_angle_gross_each'):return 'Escoamento bruto de cada L'
    if identity.endswith('_angle_net_effective_each'):return 'Ruptura líquida efetiva de cada L'
    if identity in CHECK_LABELS:return CHECK_LABELS[identity]
    prefixes={'brace':'Diagonal','beam_root':'Raiz na viga','column_root':'Raiz no pilar',
              'joint_web':'Ligação da alma','continuity_flange':'Continuidade junto à mesa',
              'continuity_web':'Continuidade junto à alma','continuity_top':'Continuidade superior',
              'continuity_bottom':'Continuidade inferior','beam':'Viga','column':'Pilar',
              'joint':'Ligação direta','gusset':'Chapa de nó','angle_each':'Cada cantoneira'}
    suffixes={'minimum_fillet':'perna mínima do filete','maximum_fillet':'perna máxima do filete',
              'minimum_weld_length':'comprimento mínimo de solda','long_weld_limit':'limite de solda longa',
              'shear_lag_length':'comprimento para redução por ligação parcial',
              'loaded_flange_weld':'solda na mesa carregada','opposite_flange_weld':'solda na mesa oposta',
              'web_weld':'solda de transferência à alma','compression_buckling':'estabilidade sob compressão',
              'compression_net_yield':'escoamento da seção líquida comprimida',
              'gross_tension':'tração na área bruta','net_rupture':'ruptura na área líquida',
              'web_two_fillets':'dois filetes na alma','minimum_width':'largura mínima',
              'minimum_thickness':'espessura mínima','outstand_compactness':'compacidade da parte saliente'}
    for suffix,label in sorted(suffixes.items(),key=lambda x:-len(x[0])):
        if identity.endswith('_'+suffix):
            prefix=identity[:-len(suffix)-1]
            return prefixes.get(prefix,prefix.replace('_',' '))+': '+label
    words={'gusset':'chapa de nó','brace':'diagonal','beam':'viga','column':'pilar','joint':'ligação',
        'continuity':'continuidade','top':'superior','bottom':'inferior','upper':'superior','lower':'inferior',
        'heel':'talão','toe':'ponta','weld':'solda','welds':'soldas','base':'metal base','substrate':'metal base',
        'each':'cada','face':'face','flange':'mesa','web':'alma','root':'raiz','contact':'contato','receiver':'receptor',
        'receiving':'receptor','local':'local','yield':'escoamento','rupture':'ruptura','normal':'normal',
        'shear':'cisalhamento','combined':'combinado','tension':'tração','gross':'bruto','net':'líquido',
        'section':'seção','supported':'apoiada','interaction':'interação','actual':'real','body':'corpo',
        'chord':'corda','peak':'máximo','tear':'bloco','both':'ambas','footprints':'faixas','between':'entre',
        'roots':'raízes','negative':'negativa','positive':'positiva','loaded':'carregada','opposite':'oposta',
        'no':'sem','spread':'dispersão','all':'todos','uniform':'uniforme','plate':'chapa','bound':'limite',
        'member':'membro','material':'material','screen':'triagem','NM':'N/M','NVM':'N/V/M'}
    return ' '.join(words.get(w,w) for w in identity.split('_')).capitalize()


def physical_envelopes(result):
    """One governing row per physical component, preserving all ties and IDs.

    Primitive counts are audit instrumentation, not additive capacities. Unknown
    utilization/status is retained as an unresolved witness, never hidden by a
    lower finite governing row.
    """
    groups = OrderedDict()
    for row in result.get('checks') or []:
        if isinstance(row, dict):
            groups.setdefault(row.get('component', 'unidentified'), []).append(row)
    out = []
    for component, rows in groups.items():
        active = [x for x in rows if x.get('status') != 'NOT_APPLICABLE' and not x.get('diagnostic_only')]
        quantified = [x for x in active if finite(x.get('utilization'))]
        peak = max((x['utilization'] for x in quantified), default=None)
        unresolved = [x for x in active if not finite(x.get('utilization')) or x.get('status') not in ('PASS', 'FAIL')]
        governing = unresolved + [x for x in quantified if x['utilization'] == peak and x not in unresolved]
        diagnostic_only=bool(rows) and all(x.get('diagnostic_only') for x in rows)
        status = ('DIAGNOSTIC_ONLY' if diagnostic_only else 'FAIL' if any(x.get('status') == 'FAIL' for x in active) else
                  'UNVERIFIED' if unresolved else 'PASS' if active else 'NOT_APPLICABLE')
        out.append({'component': component, 'component_label': component_label(component, (result.get('assumptions') or {}).get('angle_count')==1),
                    'utilization': peak, 'status': status, 'governing_ids': [x.get('id') for x in governing],
                    'governing': deepcopy(governing), 'members': deepcopy(rows),
                    'governing_labels':list(dict.fromkeys(check_label(x) for x in governing)),
                    'member_ids': [x.get('id') for x in rows], 'diagnostic_only':diagnostic_only,
                    'utilization_unbounded':any(x.get('utilization_unbounded') for x in active)})
    return out


def compact_envelopes(result):
    """Readable physical-component governors; detailed rows remain unchanged."""
    if not str((result.get('assumptions') or {}).get('brace_adapter','')).endswith('_bolted'):
        return physical_envelopes(result)
    compact=deepcopy(result)
    for row in compact.get('checks',[]):
        component=row.get('component')
        row['compact_original_component']=component
        if component in ('angles','bolts','angle_bearing','angle_block'):row['component']='bolted_adapter'
        elif component in ('gusset','gusset_bearing','gusset_block','gusset_sections','gusset_whitmore'):row['component']='common_gusset'
    groups=physical_envelopes(compact)
    for group in groups:
        for row in group['members']+group['governing']:
            row['component']=row.pop('compact_original_component',row['component'])
        group['governing_labels']=list(dict.fromkeys(check_label(row) for row in group['governing']))
    return groups


def scalar_lineage(value, prefix=''):
    """Yield scalar paths for expandable audit, retaining signs and zeroes."""
    if isinstance(value, dict):
        for key, child in value.items():
            yield from scalar_lineage(child, prefix + '.' + str(key) if prefix else str(key))
    elif isinstance(value, (tuple, list)):
        if not value:
            yield prefix, 'nenhum'
        for index, child in enumerate(value):
            yield from scalar_lineage(child, prefix + '[' + str(index) + ']')
    else:
        yield prefix, value


def compact_value(value):
    if isinstance(value, dict):
        return '; '.join(str(k) + '=' + compact_value(v) for k, v in value.items())
    if isinstance(value, (list, tuple)):
        return '[' + ', '.join(compact_value(v) for v in value) + ']'
    if isinstance(value, bool):
        return 'sim' if value else 'não'
    if value is None:
        return 'não disponível'
    return number(value, digits=9) if finite(value) else str(value)


def applicability_notes(result):
    notes=[]
    for key,label in [('beam','Raiz na viga'),('column','Raiz no pilar')]:
        seam=(result.get('seams') or {}).get(key) or {}
        normal=seam.get('N')
        if finite(normal):
            if normal>0:notes.append(label+': normal '+number(normal,1000)+' kN em tração; modos de compressão dessa raiz não ativados.')
            elif normal<0:notes.append(label+': normal '+number(normal,1000)+(' kN em compressão; enrugamento e contenção do receptor permanecem ativos.' if result.get('compression') else ' kN em compressão; verificar o componente comprimido, mesmo com a diagonal tracionada.'))
            else:notes.append(label+': normal nula; não existe demanda normal por essa parcela.')
        if seam.get('flange_bending_exempt'):
            notes.append(label+': flexão local da mesa dispensada pela largura real '+number(seam.get('footprint'))+' mm ≤ 0,15bf='+number(seam.get('threshold'))+' mm; escoamento da alma continua verificado.')
    dist=(result.get('forces') or {}).get('joint_distribution') or {}
    for key,label in [('Ftop','Mesa superior'),('Fbottom','Mesa inferior')]:
        force=dist.get(key)
        if finite(force):notes.append(label+' da ligação direta: '+number(force,1000)+' kN, '+('compressão' if force<0 else 'tração' if force>0 else 'sem força')+'. Os modos desse receptor usam esse sinal real.')
    return notes


DETAIL_LABELS={'CJP':'CJP das mesas',
 'column5_7_5':'Instabilidade lateral da alma receptora (sidesway), NBR 5.7.5',
 'column5_7_6':'Par de compressões externas opostas, NBR 5.7.6',
 'builtup_flange_web_weld':'Solda de fabricação mesa–alma do perfil',
 'root_radius':'Raio de laminação no receptor',
 'continuity_opposite_flange':'Mesa oposta da continuidade',
 'angle_radii':'Raios das cantoneiras'}


def detail_note(key,value):
    return DETAIL_LABELS.get(key,str(key).replace('_',' '))+': '+str(value)


def compression_notes(c, result):
    cp=result.get('compression') or {}
    if not cp:return []
    status={'unknown':'desconhecida','confirmed':'confirmada no detalhe','absent':'ausente'}
    notes=['CONTENÇÕES E DOMÍNIO LOCAL',
        'Viga: '+status[c.compression_beam_restraint]+'; pilar: '+status[c.compression_column_restraint]+'; extremidade/traspasse 2L: '+status[c.compression_brace_restraint]+'.',
        'Fonte/detalhe físico: '+c.compression_detail_source,
        'Declaração vinculada à geometria atual: '+('sim' if cp.get('declaration_matches_geometry') else 'não; qualificação pendente')+'. O recorte interno é livre e não fornece apoio.',
        'FAIXA E COLUNA EQUIVALENTE',
        'N='+number(c.P,1000)+' kN; largura centrada bw='+number(cp.get('width'))+' mm; Aef=A='+number(cp.get('A'))+' mm²; a força total atua na faixa retida.',
        'l1/l2/l3='+number(cp.get('l1'))+' / '+number(cp.get('l2'))+' / '+number(cp.get('l3'))+' mm; média='+number(cp.get('three_line_average'))+' mm.',
        'K=1; Lmáx=Le='+number(cp.get('Le'))+' mm, máximo de toda a faixa incluindo a troca de face em v='+number(cp.get('face_switch_v'))+' mm. Não se usa apenas o máximo de três amostras.',
        'r='+number(cp.get('r'))+' mm; Le/r='+number(cp.get('Le_over_r'))+'; λ0='+number(cp.get('lambda0'))+'; χ='+number(cp.get('chi'))+'; Nc,Rd='+number(cp.get('resistance'),1000)+' kN.',
        'NBR5.3: χ=0,658^(λ0²) até λ0=1,5; acima, χ=0,877/λ0². A resistência é limitada ao escoamento bruto. Não há fator Q antigo, Ct de tração nem redução LRFD adicional.',
        'Le/r=200 é recomendação com qualificação de serviço pelo responsável acima dela, não proibição absoluta. Calcula-se χ para todo Le positivo; em Le=0, χ=1.',
        'MECANISMOS E LIMITES',
        'Cantoneiras: compressão bruta local e b/t AL3 conservador com largura nominal completa. Soldas e substratos usam vetores assinados e magnitudes; envelope do trecho uniforme conserva somente cisalhamento.',
        'Ct, ruptura líquida por tração e bloco de ponta tracionada estão inativos. Tração real causada por flexão, se presente, continua verificada. Raízes, enrugamento, continuidade, receptor compartilhado e painel permanecem no mesmo caso.',
        'O limite concorrente do receptor é uma soma conservadora superior de tensões. Sua falha exige resolver essa verificação; não demonstra por si só escoamento físico pontual.',
        'DG29 Apêndice C, pp. impressas 374–376: modelo não compacto K=1 e média de três linhas. Adota-se Lmáx de toda a faixa como ampliação conservadora. NBR8800:2024/Errata1:2025 5.3, 6.5.4 e Tabela4 fornecem curva e coeficientes.',
        'A NBR fornecida imprime Le/r≤25 nos dois itens de 6.5.4; não se corrige a citação nem se toma atalho favorável. Exemplo DG29 5.1 imprime Ag comprimida 20,9 in² versus 21,5 in² tracionada; a diferença não calibra a geometria.',
        'A verificação é apenas da ligação local. Estabilidade global da diagonal/membros/pórtico, fadiga, sismo e execução não são certificadas.']
    vectors=(result.get('brace') or {}).get('signed_weld_vectors',[])
    for location,label in [('heel','Talão'),('toe','Ponta')]:
        vector=next((v for v in vectors if v['id'].startswith(location+'_')),None)
        if vector:notes.append(label+' de cada L, uma solda por face: força axial assinada='+number(vector['force'],1000)+' kN; Fx='+number(vector['Fx'],1000)+' kN; Fy='+number(vector['Fy'],1000)+' kN; magnitude='+number(vector['magnitude'],1000)+' kN.')
    return notes


def memory_text(c, result=None):
    """Current plain-text calculation record, suitable for selecting/copying."""
    r = validated_result(c)
    lines = [('MEMÓRIA LOCAL · CANTO VIGA–PILAR / 1L' if is_single(c) else 'MEMÓRIA LOCAL · CANTO VIGA–PILAR / 2L-T'),
             'Projeto: ' + str(getattr(c, 'project', '')),
             'Estado: ' + result_label(r),
             'Entradas SHA-256: ' + input_fingerprint(c), '', scope_text(c), '', CUT_CONVENTION,
             '', 'RESUMO POR COMPONENTE']
    if is_single(c) or is_bolted(c):lines[7:7]=[idealization_text(c), '']
    for item in compact_envelopes(r):
        lines.append(item['component_label'] + ' | ' + item['status'] + ' | η=' + utilization_text(item)
                     + ' | ' + '; '.join(item['governing_labels']))
    if is_bolted(c):
        g=r.get('geometry') or {};br=r.get('brace') or {}
        lines.extend(['','ADAPTADOR PARAFUSADO',str(c.bolt_count)+' parafusos físicos; '+str(g.get('physical_shear_planes'))+' plano(s) por parafuso; uma chapa.', 'db='+number(c.bolt_diameter)+' mm; furo físico='+number(g.get('hole_diameter'))+' mm; dedução líquida='+number(g.get('net_hole_diameter'))+' mm; passo='+number(c.bolt_pitch)+' mm.', 'N por plano='+number(br.get('per_plane_force'),1000)+' kN; N por furo da chapa='+number(br.get('force_per_gusset_hole'),1000)+' kN; Ct='+number(br.get('Ct'))+'.', 'Talão: '+number(c.bolt_heel_extent)+' mm; fonte: '+c.bolt_heel_extent_source+'. Ferramenta='+number(c.bolt_tool_radius)+' mm; folga='+number(c.bolt_fabrication_clearance)+' mm.'])
    if r.get('compression'):lines.extend(['']+compression_notes(c,r))
    lines.extend(['', 'LINHAGEM DAS FORÇAS · N, mm, N mm'])
    for key, value in scalar_lineage(r.get('forces') or {}):
        lines.append(key + ': ' + compact_value(value))
    for case in r.get('design_cases',[]):
        lines.extend(['','CASO SINTÉTICO MÍNIMO45kN',case['origin'],case['background'],'N real='+number(c.P,1000)+' kN; N de dimensionamento='+number(case['design_P'],1000)+' kN. O resumo governa entre ambos.'])
        if case.get('zero_force_convention'):lines.append(case['zero_force_convention'])
        for key,value in scalar_lineage(case['result'].get('forces') or {}):lines.append(key+': '+compact_value(value))
    if r.get('issues'):
        lines.extend(['', 'PENDÊNCIAS / FALHAS'])
        for item in r['issues']:
            lines.append(str(item.get('id', '')) + ': ' + str(item.get('message', item)))
    lines.extend(['', 'Não somar capacidades de componentes em série. Não interpretar força desconhecida como zero.',
                  'Sem aprovação global, sísmica, de fadiga, espacial ou de execução/WPS.'])
    return '\n'.join(lines)


# Familiar public aliases for callers and tests.
component_summary = physical_envelopes
copyable_mc = memory_text
