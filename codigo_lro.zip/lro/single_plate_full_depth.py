"""Conditional three-edge fillet model for the full-depth single plate.

This module allocates actions to welds, not to a validated plate membrane or
receiver mechanism. Geometry uses x out of the support web and y upwards from
the supporting section's mid-depth. Input V is positive downwards.
"""
import math

from .double_cover_weld import elastic_throat_group
from .models import SinglePlateFullDepthWeldCheck


FULL_DEPTH_WELD_ASSUMPTION = (
    'Grupo elástico de três bordas: chapa e receptores rígidos no plano, '
    'rigidez elástica isotrópica uniforme por área de garganta, dois filetes '
    'simétricos por borda e alívios sem solda. O grupo distribui as ações às '
    'soldas; não demonstra a resistência, a estabilidade ou a redistribuição '
    'na chapa, a capacidade de rotação nem a capacidade e rigidez dos receptores. '
    'Sem crédito do enrijecedor oposto.'
)

# These rows all presume that the complete load reaches the web-only joint.
# They are not zero-demand or passing checks in the three-edge model.
FULL_DEPTH_REPLACED_CHECKS = {
    'weld': 'Substituída pelas três bordas do grupo elástico.',
    'base_plate': 'Metal-base na linha única não representa o campo na chapa de três bordas; pendente.',
    'support_shear': 'Resultante integral na alma não corresponde às ações dos três receptores; pendente.',
    'support_punch': 'Hierarquia da ligação só à alma não qualifica o mecanismo de três bordas; pendente.',
    'support_web_n': 'Plastificação da alma sob N integral não representa a distribuição de três bordas; pendente.',
    'support_web_punch_n': 'Punção sob N integral não representa a distribuição de três bordas; pendente.',
    'weld_development': 'Hierarquia de dois filetes verticais não estabelece o desenvolvimento nas três bordas; pendente.',
}

FULL_DEPTH_NOMINAL_IDS = frozenset({
    'plate_vy', 'plate_vu', 'plate_ny', 'plate_nu', 'plate_mu', 'plate_ltb',
    'interaction_y', 'interaction_u', 'block_plate', 'block_plate_u',
    'block_plate_partial_u', 'partial_plate_l', 'ductility',
})


def full_depth_weld_segments(c):
    """Physical intervals of plate_outline: only the web-side corners clip."""
    if not c.full_depth or c.kind != 'beam_web':
        raise ValueError('O grupo entre mesas exige single plate na alma da viga de apoio.')
    h = c.root_height
    a = c.corner_clip
    if not (h > 2*a >= 0 and c.root_width > a):
        raise ValueError('Alívios eliminam um comprimento útil de solda.')
    return [
        dict(id='web', start_mm=[0., -h/2+a], end_mm=[0., h/2-a], leg_mm=c.weld, fillet_count=2),
        dict(id='top', start_mm=[a, h/2], end_mm=[c.root_width, h/2], leg_mm=c.flange_weld, fillet_count=2),
        dict(id='bottom', start_mm=[a, -h/2], end_mm=[c.root_width, -h/2], leg_mm=c.flange_weld, fillet_count=2),
    ]


def full_depth_weld_group(c, V, N, case='Entrada'):
    """Signed actions, applied once; no bolt-group couple added a second time."""
    load_x = c.bolt_centroid_x
    load_y = c.support.d/2 - (c.beam_level+c.beam.d/2)
    group = elastic_throat_group(full_depth_weld_segments(c), N, -V, load_x, load_y)
    resistance = .6*c.fw/1.35
    if not math.isfinite(resistance) or resistance <= 0:
        raise ValueError('Resistência da solda não positiva/finita.')
    for s in group['segments']:
        s.update(stress_resistance_MPa=resistance,
                 utilization=s['max_stress_MPa']/resistance,
                 length_to_leg_ratio=s['length_mm']/s['leg_mm'])
    long_edges = [s['id'] for s in group['segments'] if s['length_to_leg_ratio'] > 100.]
    group.update(
        model='single_plate_weighted_elastic_three_edge_weld_group',
        case=case, input_V_N=V, input_N_N=N, assumption=FULL_DEPTH_WELD_ASSUMPTION,
        component_envelope_note='Parafusos, alma e referência retangular nominal mantêm envoltórias locais separadas M=|V|e+|N·eN|. Elas não formam com o grupo de soldas uma distribuição física simultânea única. O grupo usa N e V assinados uma única vez no ponto declarado.',
        sign_convention='Origem no meio da altura do apoio; x para fora da alma; y para cima; N=Fx; Fy=−V de entrada; M anti-horário positivo. Ações transmitidas chapa→receptores; reações na chapa têm sinais opostos.',
        stress_resistance_MPa=resistance,
        max_utilization=group['max_stress_MPa']/resistance,
        pending_components=['plate_membrane_and_redistribution', 'plate_stability', 'rotation', 'receiver_capacity_and_stiffness', 'base_metal_transfer'],
        receiver_capacity_status='pending', plate_membrane_status='pending',
        plate_stability_status='pending', rotation_status='pending',
        compatibility_status='assumed_rigid_parts',
        replaced_check_ids=list(FULL_DEPTH_REPLACED_CHECKS),
        replaced_checks=dict(FULL_DEPTH_REPLACED_CHECKS),
        nominal_reference_check_ids=sorted(FULL_DEPTH_NOMINAL_IDS),
        long_joint_status='pending_reduction_applicability' if long_edges else 'within_100_leg_scope',
        long_joint_edges=long_edges,
    )
    return group


def full_depth_weld_checks(c, V, N, case='Entrada'):
    group = full_depth_weld_group(c, V, N, case)
    rows = []
    names = {'web': 'alma', 'top': 'mesa superior', 'bottom': 'mesa inferior'}
    for s in group['segments']:
        p = s['critical_point']
        rows.append(SinglePlateFullDepthWeldCheck(
            'sp_weld_full_'+s['id'],
            'Entre mesas — solda à '+names[s['id']]+' / hipótese elástica',
            s['max_stress_MPa'], s['stress_resistance_MPa'], 'MPa',
            'NBR 8800:2024 corrigida 2025, 6.2.5/Tabela 9; grupo elástico AISC Manual 15, 8-12/8-13; ponderação analítica por gargantas',
            'τmax = max_pontas √[(Fx/Aw − MG(y−yG)/Jw)² + (Fy/Aw + MG(x−xG)/Jw)²] ≤ 0,6fw/γw2',
            f'Aw={group["area_mm2"]:.6f}; xG={group["centroid_x_mm"]:.6f}; yG={group["centroid_y_mm"]:.6f}; Jw={group["J_mm4"]:.6f}; Fx=N={N:.6f}; Fy=−V={-V:.6f}; xP={group["load_point_mm"][0]:.6f}; yP={group["load_point_mm"][1]:.6f}; M0={group["moment_about_origin_Nmm"]:.6f}; MG={group["moment_about_centroid_Nmm"]:.6f}; L={s["length_mm"]:.6f}; w={s["leg_mm"]:.6f}; τmax={s["max_stress_MPa"]:.6f}; ponto={p["endpoint"]}',
            FULL_DEPTH_WELD_ASSUMPTION+' Aw=Σ2aL, a=w/√2. M0=xP·Fy−yP·Fx; MG=M0−xG·Fy+yG·Fx. Sem envelope de sinais, dupla contagem de momento ou aumento direcional. O binário local de cada borda é conservado nas integrais. Não se verifica o metal-base por cisalhamento escalar da resultante.',
            case,
        ))
    return rows, group
