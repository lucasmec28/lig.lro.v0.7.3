"""Bounded MRE1/2: DG39 Tables 5-12/A-4(a), independent NBR resistances.

N, mm, MPa internally. Six physical rows, six tension-active bolts, six
compressed-side shear bolts. No thin-plate, general contact or seismic solver.
"""
from dataclasses import dataclass, replace
from decimal import Decimal
import math
from .models import Profile, STEELS, BOLTS, DIAMETERS, Issue, INTERFERENCE_ASSUMPTION
from .end_plate import (MomentEndPlateCheck, G1, G2, E, NBR, DG, CJP_STEELS,
                        minimum_bolt_spacing, moment_decimal_spacings, thick_required)
from .engine import bolt_shear
from .local_checks import grip_factor, web_shear
from .column_checks import crippling_point

FNT_DG39={'ASTM F3125 A325':90*6.8947572931683,'ASTM F3125 A490':113*6.8947572931683}

@dataclass
class MRE12Check(MomentEndPlateCheck):
    source_qualified: bool=True
    @property
    def passed(self):return self.numerically_valid and self.demand<=self.resistance
    @property
    def outcome(self):
        if self.numerically_valid and self.applicable and self.passed and not self.source_qualified:
            return 'Não qualificado · condições materiais/CJP MRE1/2 pendentes'
        return super().outcome


def required_inputs():
    return set('kind beam support variant layout pb pfi pfo edge gauge tp bp db bolt beam_steel support_steel plate_steel threads drilled norm_minimum tool_radius fw V N M intermediate_n cjp_electrode cjp_compatible'.split())


def yield_mre12(bp,g,h1,h2,h3,pfo,pfi,pb):
    """Table 5-12. Clamp pfi only here; h and every physical path stay real."""
    s=math.sqrt(bp*g)/2;pi=min(pfi,s)
    return bp/2*(h1/pfo+h2/pi+h3/s-.5)+2/g*(h2*(pi+3*pb/4)+h3*(s+pb/4))+g/2


def yield_column_mre12(B,g,h1,h3,c,pb):
    """A-4(a), continuous unreinforced column. Own effective width and sC."""
    s=math.sqrt(B*g)/2
    return B/2*((h1+h3)/s)+2/g*(h1*(s+3*pb/4+3*c/4)+h3*(s+pb/4+c/4))+g/2


def source_ranges(c):
    limits=[('pfi',c.pfi,25.4,127.),('pfo',c.pfo,25.4,127.),('extensão',c.ext_top,63.5,190.5),
            ('gabarito',c.gauge,69.85,177.8),('altura da viga',c.beam.d,400.05,1828.8),
            ('largura da chapa',c.bp,127.,260.35),('mesa da viga',c.beam.tf,9.525,25.4)]
    return [dict(name=n,value=v,lower=lo,upper=hi,adopted_lower=lo*.9,adopted_upper=hi*1.1,
                 within=Decimal(str(lo))*Decimal('.9')<=Decimal(str(v))<=Decimal(str(hi))*Decimal('1.1')) for n,v,lo,hi in limits]


def assumptions(c):
    return [
        'MRE1/2 sem nervuras: seis linhas físicas com dois parafusos por linha, 12 totais e seis ativos à tração em três linhas. V integral é atribuído somente aos seis parafusos do lado comprimido. Sinais de M e V escolhem os grupos e os sentidos físicos; não há crédito a linhas intermediárias arbitrárias.',
        'DG39 tabela 5-12 e coluna A-4(a) contínua não reforçada: sem chapa de topo, continuidade, doubler, viga oposta ou outra topologia de coluna. Serviço ordinário estático; sem pré-qualificação sísmica, fadiga ou curva momento–rotação. A classificação FR complementar depende do domínio fonte e da análise global.',
        'Chapa espessa / sem alavanca na demanda de cálculo: tp e tfc devem satisfazer √[1,10 Meq max(γa1;1/0,90)/(fy Y)]. Classificação nominal separada: Mpl e Mcf ≥ 1,10 Mnp, Mnp=Fnt Ab H. Somente ambas as condições nominais permitem afirmar sem prying até Mnp. Falha nominal isolada não bloqueia o procedimento por demanda.',
        'N positivo é tração; Meq=|M|+max(N;0)(d−tf)/2. Escopo adotado M≠0 e |N|(d−tf)≤|M|, sem solução geral de contato ou axial dominante. Tb=Meq/[2(h1+h2+h3)], T=6Tb e C=max(T−N;0). Ff=|M|/(d−tf)+max(N;0)/2 e Fc=|M|/(d−tf)+max(−N;0)/2 são forças de mesa distintas.',
        'Transferência local: extensão não enrijecida recebe Ff/3; alma recebe 2Ff/3. lwt=pfi+pb+152,4 mm e lws=min(d−2tf−lwt;(d−2tf)/2), em regiões disjuntas refletidas com M. Pisos CJP de 60% não recebem N adicional. Alma e mesas CJP compatíveis conectadas na largura total; sem furos de acesso alterando a seção.',
        'pfi efetivo=min(pfi;sP) somente em Yp; pfo não é limitado a sP. Coordenadas, braços, c, blocos e comprimentos CJP permanecem físicos. Esta interpretação combina a nota da tabela 5-12 com os braços físicos de 3.4; não é algoritmo trabalhado no exemplo.',
        'Aços da viga e chapa independentes A36/A572 Gr.42/Gr.50, coluna verificada separadamente. Rota CJP E7018 fw=485 MPa, procedimento/preparação compatíveis, baixo hidrogênio e preaquecimento do grupo mais resistente (NBR tabela 8). fw isolado não comprova compatibilidade. A declaração deve corresponder ao detalhe real.',
        'Parafusos A325/Group120 ou A490/Group150: nominal DG39 Fnt=90 ou 113 ksi respectivamente; não confundir com Pt,NBR=0,75fubAb. Capacidades de cálculo NBR usam γa2=1,35; não se aplica φ duas vezes. Catálogo da interface até 1,25 pol.; teto da fonte 1,5 pol.',
        'Alma da coluna: escoamento recebe max(Ff;Fc), enrugamento recebe Fc; contato recebe C. Painel de uma viga: |M|/(d−tf)+|N|/2, sem dedução favorável do cortante da coluna. Ncol,Sd≤0,4 Ag,col fyc e ausência de outros esforços locais são condições declaradas; análise global permanece externa.',
        'Domínio da tabela 5-9 com extensão ±10% explicitamente adotada; pf de 1 a 5 pol., sem faixa própria inventada para pb. Furos, ligamentos, acessos e ordem das seis linhas controlam pb. Fora da faixa é extrapolação, separada de falha resistente.',
    ]


def validate_mre12(c):
    issues=[]
    def add(sev,text,ref=NBR,origin='model'):issues.append(Issue(sev,text,ref,origin))
    def err(text,origin='data'):add('error',text,'Geometria e domínio MRE1/2',origin)
    numbers='db tp bp gauge pfi pfo pb edge fw tool_radius V N M'.split()
    if any(type(getattr(c,k)) not in (int,float) or not math.isfinite(getattr(c,k)) for k in numbers):
        err('Entradas numéricas MRE1/2 devem ser reais finitas, sem textos ou booleanos.');return issues
    if any(getattr(c,k)<=0 for k in numbers[:-3]):err('Dimensões e resistências MRE1/2 devem ser positivas.');return issues
    if c.db not in DIAMETERS.values() or c.db>38.1:err('Diâmetro MRE1/2 deve coincidir exatamente com o catálogo imperial disponível.');return issues
    if not isinstance(c.bolt,str) or c.bolt not in FNT_DG39:err('MRE1/2 admite A325/Group120 ou A490/Group150; sem A307 ou equivalência Group144.');return issues
    if any(type(getattr(c,k)) is not bool for k in ('threads','drilled','norm_minimum','cjp_compatible')):err('Declarações MRE1/2 devem ser booleanas.');return issues
    if type(c.intermediate_n) is not int or c.layout!='both' or c.intermediate_n!=0:
        err('MRE1/2 exige extensões simétricas, seis linhas e 12 parafusos, sem linhas intermediárias adicionais.','method');return issues
    for p,steel,label in ((c.beam,c.beam_steel,'viga'),(c.support,c.support_steel,'coluna')):
        if not isinstance(p,Profile) or any(type(getattr(p,k)) not in (int,float) or not math.isfinite(getattr(p,k)) or getattr(p,k)<=0 for k in ('d','bf','tf','tw','clear','area')):
            err('Seção nativa da '+label+' inválida.');continue
        if not isinstance(p.family,str) or p.family not in ('W','HP','CS','CVS','VS','Soldado'):
            err('MRE1/2 requer perfil I simétrico reconhecido na '+label+'.');continue
        if p.d<=2*p.tf or p.bf<=p.tw or p.clear>p.d-2*p.tf+1:err('Geometria da seção da '+label+' inválida.');continue
        if not isinstance(steel,str) or steel not in STEELS:err('Aço da '+label+' não reconhecido.');continue
        st=STEELS[steel];welded=p.family in ('CS','CVS','VS','Soldado')
        if not (st.plate_allowed if welded else st.rolled_allowed) or min(p.tf,p.tw)<st.profile_min or max(p.tf,p.tw)>st.profile_max:err('Material/produto/espessura incompatível da '+label+'.')
    if not isinstance(c.plate_steel,str) or c.plate_steel not in STEELS:err('Aço de chapa não reconhecido.')
    else:
        sp=STEELS[c.plate_steel]
        if not sp.plate_allowed or not sp.plate_min<=c.tp<=sp.plate_max:err('Material/produto/espessura incompatível da chapa.')
    if issues:return issues
    b,s=c.beam,c.support;sp=STEELS[c.plate_steel];sb=STEELS[c.beam_steel];sc=STEELS[c.support_steel]
    if c.beam_steel not in CJP_STEELS or c.plate_steel not in CJP_STEELS:
        add('pending','MRE1/2 requer viga e chapa selecionadas independentemente entre A36/A572 Gr.42/Gr.50.',NBR+', tabelas 8/9','method')
    if c.cjp_electrode!='E7018' or c.fw!=485. or not c.cjp_compatible:
        add('pending','CJP MRE1/2: confirmar E7018, fw=485 MPa, preparação/procedimento compatíveis e qualificados nas mesas e alma, baixo hidrogênio e preaquecimento aplicável. fw isolado não basta.',NBR+', tabela 8','method')
    if any(st.fu/G2<st.fy/G1 for st in (sb,sp)):
        add('pending','Ruptura sem furos fu/γa2≥fy/γa1 não satisfeita em metal-base da junta CJP.',NBR+', tabela 9','method')
    if sc.fy>380:add('extrapolation','Aço da coluna fora do limite adotado de 380 MPa.',DG+', 4.1.3')
    if c.bp<b.bf:add('pending','MRE1/2 requer largura total da mesa conectada, bp≥bf; junta parcial exige outro modelo.',DG+', 3.7.5','method')
    if c.bp>s.bf:err('Chapa ultrapassa a largura física da mesa da coluna.','model')
    ys=c.rows
    if any(y>=z for y,z in zip(ys,ys[1:])):err('Linhas MRE1/2 cruzadas ou coincidentes; a ordem física não é corrigida por ordenação.','model')
    if min(c.tension_arms)<=0:err('Três braços MRE1/2 devem ser positivos.','model')
    edge_min={12.7:19,15.875:22,19.05:25,22.225:28,25.4:32,28.575:38,31.75:41}[c.db]
    lat=(min(c.bp,s.bf)-c.gauge)/2
    for label,value in [('Borda lateral',lat),('Borda longitudinal da chapa',c.edge)]:
        if value<=c.dh/2:err(label+' sem ligamento físico positivo.','model')
        elif value<edge_min:add('noncompliance',f'{label}={value:g} mm inferior ao mínimo adotado {edge_min:g} mm; cálculo preservado.',NBR+', 6.3.11','data')
        elif value<c.tool_radius:add('interference',label+': envelope da ferramenta excede o material.')
    dec_hole=Decimal(str(c.db))+Decimal('1.5875' if c.db<25.4 else '3.175')
    for label,value in [('Gabarito',Decimal(str(c.gauge)))]+[(f'Passo {i+1}–{i+2}',v) for i,v in enumerate(moment_decimal_spacings(c))]:
        if value<=dec_hole:err(label+' produz furos sobrepostos ou ligamento livre não positivo.','model')
        elif value<Decimal(str(minimum_bolt_spacing(c.db))) or value-dec_hole<Decimal(str(c.db)):
            add('noncompliance',f'{label}={value} mm; requer 2,7db e ligamento livre≥db.',NBR+', 6.3.9','data')
    maximum=max([Decimal(str(c.gauge))]+moment_decimal_spacings(c));limit=min(Decimal('24')*min(Decimal(str(c.tp)),Decimal(str(s.tf))),Decimal('300'))
    if maximum>limit:add('noncompliance',f'Espaçamento máximo={maximum:g} mm excede {limit:g} mm. Rever geometria sem adicionar linhas arbitrárias.',NBR+', 6.3.10(a)','data')
    if max(lat,c.edge)>min(12*c.tp,150.):add('noncompliance','Borda da chapa excede min(12tp;150 mm).',NBR+', 6.3.12','data')
    if c.bp-2*c.dn<=0 or c.bp-c.gauge-c.dn<=0:err('Seção líquida ou faixa lateral de bloco não positiva.','model')
    for ordered,start in [(ys,-c.ext_top),([-y for y in reversed(ys)],-(b.d+c.ext_bottom))]:
        if any(y-start-(j-.5)*c.dn<=0 for j,y in enumerate(ordered,1)):err('Percurso líquido de bloco físico não positivo.','model');break
    root_b=(b.d-b.clear)/2;root_c=max((s.d-s.clear)/2-s.tf,0.)
    if c.gauge/2<=max(b.tw/2,s.tw/2+root_c)+c.tool_radius:add('interference','Envelope dos parafusos interfere com alma ou concordância.')
    if c.pfo<c.tool_radius or any(not root_b+c.tool_radius<=y<=b.d-root_b-c.tool_radius for y in ys[1:5]):add('interference','Linha de parafusos interfere com mesa, concordância ou ferramenta.')
    if c.gauge>b.bf:add('extrapolation','Gabarito fora da largura da mesa da viga no arranjo fonte.',DG+', 3.7.2')
    for q in source_ranges(c):
        if not q['within']:add('extrapolation',f"{q['name']}={q['value']:g} mm fora da faixa adotada {q['adopted_lower']:g}–{q['adopted_upper']:g} mm (±10%).",DG+', tabela 5-9')
    if c.M==0 or abs(c.N)*(b.d-b.tf)>abs(c.M):err('MRE1/2 requer M≠0 e |N|(d−tf)≤|M|; axial dominante/contacto migrante exige outro modelo.','method')
    hw=b.d-2*b.tf;lwt=c.web_tension_length
    if lwt>hw:add('pending',f'Região local lwt={lwt:g} mm excede a alma física hw={hw:g} mm; sem resistência atribuída ao trecho inexistente.',DG+', 3.7.5','method')
    if c.V!=0 and min(hw-lwt,hw/2)<=0:add('pending','Sem região CJP positiva disponível para o cortante V.',DG+', 3.7.5','method')
    if not c.norm_minimum:add('pending','Conferência normativa mínima desativada: modo de comparação.',NBR+', 6.1.5')
    if any(i.severity=='interference' for i in issues):add('excluded',INTERFERENCE_ASSUMPTION)
    return issues


def calculate_mre12(c,V,N,M,case):
    b,s=c.beam,c.support;sp,sb,sc=[STEELS[k] for k in (c.plate_steel,c.beam_steel,c.support_steel)]
    rows=[];a={};z=b.d-b.tf;arms=c.tension_arms;h1,h2,h3=arms;H=2*sum(arms)
    def add(key,name,D,R,unit,eq,variables='',ref=NBR):
        rows.append(MRE12Check('ep_'+key,name,D,R,unit,ref,eq,f'Sd={D:.12g}; Rd={R:.12g}',variables,case))
    Meq=abs(M)+max(N,0)*z/2;Tb=Meq/H;T=6*Tb;C=max(T-N,0);Ff=abs(M)/z+max(N,0)/2;Fc=abs(M)/z+max(-N,0)/2
    Yp=yield_mre12(c.effective_bp,c.gauge,*arms,c.pfo,c.pfi,c.pb)
    Yc=yield_column_mre12(c.effective_bfc,c.gauge,h1,h3,c.pfo+b.tf+c.pfi,c.pb)
    tr=thick_required(Meq,sp.fy,Yp);tcr=thick_required(Meq,sc.fy,Yc)
    add('plate_rigidity','Chapa — espessa / sem alavanca na demanda de cálculo',tr,c.tp,'mm','tp,req=√[1,10 Meq max(γa1;1/0,90)/(fyp Yp)]','Sem tolerância de aprovação. Classificação nominal separada.',DG+', tabela 5-12; 5.1.1')
    add('column_rigidity','Coluna — mesa espessa na demanda de cálculo',tcr,s.tf,'mm','tcf,req=√[1,10 Meq max(γa1;1/0,90)/(fyc Yc)]','Coluna contínua A-4(a), sem reforço.',DG+', tabela A-4(a); 5.1.1')
    add('plate_yield','Chapa — linhas de plastificação',Meq,sp.fy*c.tp*c.tp*Yp/G1,'Nmm','MRd=fyp tp² Yp/γa1','Ramo implicado pelo critério de chapa espessa, conservado no detalhamento.',DG+', tabela 5-12; '+NBR)
    Ab=math.pi*c.db*c.db/4;Ft=.75*BOLTS[c.bolt]*Ab/G2;Fv=bolt_shear(c.db,BOLTS[c.bolt],c.threads)*grip_factor(c.tp+s.tf,c.db);shear=abs(V)/6
    ti=[0,1,2] if M>0 else [5,4,3];vi=[3,4,5] if M>0 else [0,1,2];pivot=b.d-b.tf/2 if M>0 else b.tf/2
    bolts=[dict(row=i+1,row_index=i,x=x,y=y,active_tension=i in ti,shear_group=i in vi,tension=Tb if i in ti else 0.,shear=shear if i in vi else 0.,signed_shear=V/6 if i in vi else 0.,plate_signed_shear=-V/6 if i in vi else 0.,column_signed_shear=V/6 if i in vi else 0.,interaction=(Tb/Ft)**2 if i in ti else (shear/Fv)**2) for i,y in enumerate(c.rows) for x in (-c.gauge/2,c.gauge/2)]
    add('bolt_shear','Parafusos comprimidos — cisalhamento V/6',shear,Fv,'N','Fv,Rd=kpega α fub Ab/γa2','Seis parafusos junto à mesa comprimida; zero tração do modelo. Rosca e pega reais.')
    add('bolt_tension','Parafusos ativos — tração',Tb,Ft,'N','Tb=Meq/H; Ft,Rd=0,75 fub Ab/γa2','Seis parafusos tracionados, sem cisalhamento atribuído; exige ambas as espessuras de demanda.')
    add('bolt_interaction','Parafusos — envoltória da interação por parafuso',max(q['interaction'] for q in bolts),1.,'—','η=max_i[(Ti/Ft,Rd)²+(Vi/Fv,Rd)²]','Grupos disjuntos: seis em tração e seis em cisalhamento; não somar os máximos de parafusos diferentes.')
    bearing=[]
    for piece,t,fu,direction,label in [('plate',c.tp,sp.fu,-1 if V>=0 else 1,'Chapa'),('column',s.tf,sc.fu,1 if V>=0 else -1,'Coluna')]:
        candidates=[]
        for i in vi:
            nxt=i+direction
            lc=abs(c.rows[nxt]-c.rows[i])-c.dh if 0<=nxt<6 else ((c.rows[i]+c.ext_top if direction<0 else b.d+c.ext_bottom-c.rows[i])-c.dh/2 if piece=='plate' else math.inf)
            R=min(1.2*lc*t*fu,2.4*c.db*t*fu)/G2
            q=dict(piece=piece,row=i+1,row_index=i,force_direction=direction,lc=lc if math.isfinite(lc) else None,demand=shear,resistance=R,ratio=shear/R)
            bearing.append(q);candidates.append(q)
        q=max(candidates,key=lambda q:q['ratio'])
        add('bearing_'+piece,label+' — contato/rasgamento no furo carregado',q['demand'],q['resistance'],'N','R=min(1,2 lc t fu;2,4 db t fu)/γa2',f"Linha {q['row']}; direção={direction}; lc={q['lc']}. Reação na chapa e força transmitida à coluna opostas. Coluna contínua sem borda longitudinal fictícia.")
    blocks=[]
    for edge,ordered,start in [('top',list(enumerate(c.rows)),-c.ext_top),('bottom',[(i,-c.rows[i]) for i in range(5,-1,-1)],-(b.d+c.ext_bottom))]:
        included=[]
        for j,(i,y) in enumerate(ordered,1):
            included.append(i);loaded=len(set(included)&set(vi));lv=y-start;Agv=lv*c.tp;Anv=(lv-(j-.5)*c.dn)*c.tp;Ant=(c.bp-c.gauge-c.dn)/2*c.tp
            R=2*min(.6*sp.fu*Anv+.5*sp.fu*Ant,.6*sp.fy*Agv+.5*sp.fu*Ant)/G2;D=2*loaded*shear
            blocks.append(dict(edge=edge,hole_rows=j,loaded_rows=loaded,row_indices=list(included),lv=lv,Agv=Agv,Anv=Anv,Ant=Ant,demand=D,resistance=R,ratio=D/R))
    q=max(blocks,key=lambda q:q['ratio'])
    add('block_plate','Chapa — blocos físicos parcialmente carregados',q['demand'],q['resistance'],'N','R=2min(0,6fu Anv+0,5fu Ant;0,6fy Agv+0,5fu Ant)/γa2',f"Borda {q['edge']}; {q['hole_rows']} linhas deduzidas; {q['loaded_rows']} linhas carregadas. Demanda é a soma dos parafusos carregados contidos. Envoltória conservadora dos dois extremos, sem bloco longitudinal fictício da coluna.")
    extension=Ff/3;web=2*Ff/3;lwt=c.web_tension_length;hw=b.d-2*b.tf;lws=min(hw-lwt,hw/2);fyj=min(sb.fy,sp.fy);we=min(b.tw,c.tp);te=min(b.tf,c.tp);width=min(b.bf,c.bp)
    add('extension_shear_yield','Extensão da chapa — escoamento por cisalhamento de Ff/3',extension,.6*sp.fy*c.bp*c.tp/G1,'N','VSd=Ff/3; VRd=0,6 fyp bp tp/γa1','Largura física da extensão sem nervuras.',DG+', exemplo 5.3-3; '+NBR)
    add('extension_shear_rupture','Extensão da chapa — ruptura por cisalhamento de Ff/3',extension,.6*sp.fu*(c.bp-2*c.dn)*c.tp/G2,'N','VSd=Ff/3; VRd=0,6 fup (bp−2dn)tp/γa2','Dois furos e dedução NBR real.',DG+', exemplo 5.3-3; '+NBR)
    add('weld_cjp_flange_local','Junta CJP das mesas — transferência e desenvolvimento',max(Ff,Fc,.6*sb.fy*b.bf*b.tf),fyj*width*te/G1,'N','FSd=max(Ff;Fc;0,60 fyb bf tf); FRd=min(fyb;fyp)min(bf;bp)min(tf;tp)/γa1','N incluído apenas em Ff/Fc; não se soma ao piso.',DG+', 3.7.5; '+NBR+', tabela 9')
    if lwt<=hw:
        add('beam_web_local_tension','Alma da viga — tração local de 2Ff/3',web,sb.fy*b.tw*lwt/G1,'N','Tw=2Ff/3; R=fyb tw lwt/γa1','lwt=pfi+pb+152,4; região física ativa junto à mesa tracionada.',DG+', 3.7.5; '+NBR)
        add('weld_cjp_web_local','Junta CJP da alma — tração local e desenvolvimento',max(web,.6*sb.fy*b.tw*lwt),fyj*we*lwt/G1,'N','FSd=max(2Ff/3;0,60 fyb tw lwt); R=min(fyb;fyp)min(tw;tp)lwt/γa1','Região disjunta do cisalhamento, refletida com M.',DG+', 3.7.5; '+NBR+', tabela 9')
        if lws>0:add('weld_cjp_web_shear','Junta CJP da alma — cisalhamento disponível',abs(V),.6*fyj*we*lws/G1,'N','lws=min(hw−lwt;hw/2); R=0,60 min(fyb;fyp)min(tw;tp)lws/γa1','V integral; não se descontam duas regiões alternativas de tração.',DG+', 3.7.5; '+NBR+', tabela 9')
    A=2*b.bf*te+hw*we;I=2*(b.bf*te**3/12+b.bf*te*(b.d/2-b.tf/2)**2)+we*hw**3/12;W=I/(b.d/2)
    add('weld_cjp','Viga e juntas CJP — tensão equivalente global',math.hypot(abs(N)/A+abs(M)/W,math.sqrt(3)*abs(V)/(we*hw)),fyj/G1,'MPa','σeq=√[(|N|/A+|M|/W)²+3(V/Aw)²]','Seção bruta elástica; não substitui a transferência local.')
    Rv,cv=web_shear(b.clear,b.tw,sb.fy);Rp,cp=web_shear(s.clear,s.tw,sc.fy)
    add('beam_web','Viga — cisalhamento da alma',abs(V),Rv,'N','VRd=0,6 fyb h tw Cv/γa1',f'Cv={cv:.12g}; alma física sem furos.')
    add('column_web_yield','Coluna — escoamento local da alma',max(Ff,Fc),1.10*2.5*s.tf*sc.fy*s.tw/G1,'N','FSd=max(Ff;Fc); R=1,10(2,5tfc+ln)fyc twc/γa1','ln=0; condição de extremidade conservadora; Ff/Fc distintos de T/C.',NBR+', 5.7.3.2(b); '+DG+', 3.5/3.7.6')
    add('column_crippling','Coluna — enrugamento da alma',Fc,crippling_point(s.tw,s.tf,sc.fy),'N','FSd=Fc; R=0,33twc²√(E fyc tfc/twc)/γa1','Sem crédito a reforço ou comprimento carregado.',NBR+', 5.7.4.2(b)')
    add('contact','Chapa e coluna — compressão local de contato',C,min(sp.fy,sc.fy)*b.bf*b.tf/G1,'N','C=max(6Tb−N;0); R=min(fyp;fyc)bf tf/γa1','Contato sobre uma mesa; T não substitui força de mesa.')
    add('panel','Coluna — cisalhamento do painel',abs(M)/z+abs(N)/2,Rp,'N','Vp=|M|/(d−tf)+|N|/2; R=0,60fyc hc twc Cv/γa1',f'Cv={cp:.12g}; uma viga, Ncol≤0,4Agfyc; sem ganho de mesa/dedução favorável de cortante.')
    add('compact_flange','Viga — mesa compacta no nó',(b.bf-b.tw)/(2*b.tf),.38*math.sqrt(E/sb.fy),'—','(bf−tw)/(2tf)≤0,38√(E/fyb)','Condição local; análise global externa.')
    add('compact_web','Viga — alma compacta no nó',b.clear/b.tw,3.76*math.sqrt(E/sb.fy),'—','h/tw≤3,76√(E/fyb)','Condição local de flexão.')
    Mpl=sp.fy*c.tp*c.tp*Yp;Mcf=sc.fy*s.tf*s.tf*Yc;Pt=FNT_DG39[c.bolt]*Ab;Ptn=.75*BOLTS[c.bolt]*Ab;Mnp=Pt*H;Mnpn=Ptn*H
    nominal=dict(reference='DG39 eq.3-18/19/21, Fnt literal do grupo',Fnt=FNT_DG39[c.bolt],Pt=Pt,Mnp=Mnp,Mpl=Mpl,Mcf=Mcf,plate_ratio=Mpl/Mnp,column_ratio=Mcf/Mnp,plate_no_prying=Mpl>=1.10*Mnp,column_no_prying=Mcf>=1.10*Mnp,all_no_prying=Mpl>=1.10*Mnp and Mcf>=1.10*Mnp,NBR_reference=dict(Pt=Ptn,Mnp=Mnpn,plate_ratio=Mpl/Mnpn,column_ratio=Mcf/Mnpn,plate_no_prying=Mpl>=1.10*Mnpn,column_no_prying=Mcf>=1.10*Mnpn))
    source_ok=not any(i.severity in ('pending','error') and i.origin=='method' for i in validate_mre12(c))
    demand_ok=c.tp>=tr and s.tf>=tcr
    rows=[replace(q,no_prying_qualified=demand_ok,source_qualified=source_ok) if q.id in ('ep_bolt_tension','ep_bolt_interaction') else q for q in rows]
    a.update(V=V,N=N,M=M,Meq=Meq,z=z,variant='MRE12_U',h1=h1,h2=h2,h3=h3,arms=arms,H=H,Yp=Yp,Yc=Yc,tp_required=tr,column_tf_required=tcr,bolt_tension=Tb,bolt_shear=shear,T=T,C=C,flange_transfer_force=Ff,flange_compression_force=Fc,local_transfer_force=web,extension_transfer_force=extension,column_web_yield_force=max(Ff,Fc),column_crippling_force=Fc,calculation_nb=12,detail_nb=12,active_bolt_count=6,shear_bolt_count=6,active_indices=ti,shear_indices=vi,active_rows=[c.rows[i] for i in ti],shear_rows=[c.rows[i] for i in vi],active_arms=[abs(pivot-c.rows[i]) for i in ti],compression_pivot=pivot,bolts=bolts,bearing_paths=bearing,plate_blocks=blocks,nominal=nominal,demand_no_prying=demand_ok,plate_table='5-12',column_table='A-4(a)',effective_bp=c.effective_bp,effective_bfc=c.effective_bfc,plate_s=math.sqrt(c.effective_bp*c.gauge)/2,column_s=math.sqrt(c.effective_bfc*c.gauge)/2,column_c=c.pfo+b.tf+c.pfi,plate_pfi_effective=min(c.pfi,math.sqrt(c.effective_bp*c.gauge)/2),plate_pfo_effective=c.pfo,pb=c.pb,source_ranges=source_ranges(c),web_tension_length=lwt,web_shear_weld_length=lws,web_physical_height=hw,web_tension_region_fits=lwt<=hw,flange_cjp_width=width,extension_gross_shear_area=c.bp*c.tp,extension_net_shear_area=(c.bp-2*c.dn)*c.tp,tension_side='top' if M>0 else 'bottom')
    return rows,a
