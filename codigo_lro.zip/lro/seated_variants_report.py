"""Portuguese review report for seated variants, with explicit partial scope."""
from io import BytesIO
from dataclasses import fields, is_dataclass
from docx import Document
from docx.shared import Cm, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from .seated_variants_drawing import png_bytes, TITLES
from .beam_direct_seat_presentation import HEADERS, checks_rows, fmt

LABELS = {
    'bolt_top':'Topo até fila superior (mm)', 'bolt_pitch':'Passo vertical dos parafusos (mm)', 'bolt_gauge':'Gabarito transversal dos parafusos (mm)', 'column_top_edge':'Fila superior até borda superior da coluna (mm)', 'column_bottom_edge':'Fila inferior até borda inferior da coluna (mm)', 'bolt_tool_radius':'Raio do envelope de montagem (mm)', 'bolt_tool_length':'Comprimento axial do envelope de montagem (mm)',
    'variant':'Família', 'beam':'Viga apoiada', 'support':'Perfil do pilar',
    'beam_steel':'Aço da viga', 'support_steel':'Aço do pilar',
    'V':'Reação vertical de cálculo (N)', 'shear_left':'Cortante à esquerda (N)',
    'shear_right':'Cortante à direita (N)', 'bearing_length':'Comprimento de apoio (mm)',
    'bearing_width':'Largura de apoio (mm)', 'packer_thickness':'Espessura do calço (mm)',
    'angle_horizontal':'Aba horizontal da cantoneira (mm)', 'angle_vertical':'Aba vertical da cantoneira (mm)',
    'angle_thickness':'Espessura da cantoneira (mm)', 'angle_length':'Comprimento transversal da cantoneira (mm)',
    'angle_gap':'Folga viga / face do pilar (mm)', 'angle_root_radius':'Raio de raiz da cantoneira (mm)',
    'angle_steel':'Aço da cantoneira', 'attachment':'Fixação da cantoneira', 'weld_line_capacity':'Resistência linear de cálculo da solda (N/mm)', 'weld_mode':'Modo de resistência da solda', 'weld_category':'Categoria da solda', 'weld_electrode':'Consumível de soldagem', 'weld_long_lap':'Emenda longa por sobreposição', 'weld_leg':'Perna do filete (mm)', 'weld_capacity_source':'Fonte da resistência linear da solda', 'weld_effective_length':'Comprimento efetivo de cada solda vertical (mm)',
    'supported_stiffeners':'Enrijecedores na viga apoiada',
    'receiving_stiffeners':'Enrijecedores na viga receptora', 'project':'Projeto', 'notes':'Observações',
}


def create_report(c):
    from .seated_variants import evaluate, VERSION
    r=evaluate(c)
    d=Document();s=d.sections[0]
    s.page_width=Cm(21);s.page_height=Cm(29.7)
    s.top_margin=s.bottom_margin=Cm(1.5);s.left_margin=s.right_margin=Cm(1.6)
    for name in ('Normal','Title','Heading 1','Heading 2'):
        st=d.styles[name];st.font.name='Arial';st.font.color.rgb=RGBColor(0,0,0)
    for element in d.styles.element.iter():
        for child in list(element):
            if child.tag == qn('w:pBdr'): element.remove(child)
    d.styles['Normal'].font.size=Pt(9)
    d.styles['Normal'].paragraph_format.space_after=Pt(4)
    d.styles['Title'].font.size=Pt(19);d.styles['Heading 1'].font.size=Pt(13)
    d.core_properties.title='Memória de cálculo: '+TITLES.get(c.variant,c.variant)
    d.core_properties.subject='Verificações locais e pendências de projeto'
    d.core_properties.author=''
    def checks(rows):
        t=d.add_table(rows=1,cols=6);t.style='Table Grid';t.autofit=False
        widths=(7.3,2.2,2.2,1.2,1.5,3.4)
        for col,w in zip(t.columns,widths): col.width=Cm(w)
        t.rows[0]._tr.get_or_add_trPr().append(OxmlElement('w:tblHeader'))
        for cell,v,w in zip(t.rows[0].cells,HEADERS,widths):
            cell.text=v;cell.width=Cm(w)
            shade=OxmlElement('w:shd');shade.set(qn('w:fill'),'E8EDF2');cell._tc.get_or_add_tcPr().append(shade)
        for row in checks_rows(rows):
            cells=t.add_row().cells
            for cell,v,w in zip(cells,row.values(),widths): cell.text=str(v);cell.width=Cm(w)
            cells[0]._tc.getparent().get_or_add_trPr().append(OxmlElement('w:cantSplit'))
        for row in t.rows:
            for cell in row.cells:
                for p in cell.paragraphs:
                    p.paragraph_format.space_after=Pt(3)
                    for run in p.runs:run.font.size=Pt(8)
        return t
    d.add_heading('Memória de apoio assentado',0)
    d.add_paragraph(TITLES.get(c.variant,c.variant))
    if c.project:d.add_paragraph(c.project)
    d.add_paragraph('Modelo de cálculo: '+VERSION)
    d.add_paragraph('VERIFICAÇÃO DO CAMINHO METÁLICO POR GRAVIDADE · INTERFACES EXTERNAS IDENTIFICADAS')
    d.add_picture(BytesIO(png_bytes(c)),width=Cm(17.7))
    d.add_paragraph('Figura original gerada a partir das entradas. Contato e seções proporcionais; comprimentos de continuidade esquemáticos. As fixações e os elementos de transferência ao apoio não são detalhes de fabricação.')
    d.add_heading('Conclusão e alcance',1)
    status=r.get('status','PENDING')
    status_pt={'LOCAL_LOAD_PATH_PENDING':'Caminho local da chapa de topo não concluído', 'LOCAL_ATTACHMENT_PENDING':'Grupo soldado pendente: informar qRd e sua fonte', 'BOLTED_MODEL_INCOMPLETE':'Modelo parafusado incompleto; resistências calculadas não aprovam a fixação', 'LOCAL_CHECKS_PASS':'Verificações locais calculadas atendidas', 'LOCAL_GEOMETRY_FAILURE':'Geometria local não atendida', 'LOCAL_RESISTANCE_FAILURE':'Resistência local não atendida', 'OUTSIDE_SCOPE':'Entradas fora do escopo', 'PASS':'Verificações locais atendidas','FAIL':'Há verificação local não atendida',
               'PENDING':'Verificações pendentes','PARTIAL':'Verificação parcial',
               'INVALID':'Entrada inválida','INVALID_INPUT':'Entrada inválida',
               'PARTIAL_PASS':'Verificações implementadas atendidas; escopo incompleto'}.get(status,'Verificação parcial')
    d.add_paragraph(status_pt+'. '+r.get('scope_summary',''))
    if r.get('diagnosis'):d.add_paragraph(str(r['diagnosis']))
    d.add_page_break()
    d.add_heading('1. Entradas de projeto',1)
    keys=[f.name for f in fields(c)] if is_dataclass(c) else list(LABELS)
    for key in keys:
        if c.variant=='angle_seat' and key in ('bearing_length','bearing_width'):continue
        if key in ('bolt_top','bolt_pitch','bolt_gauge','column_top_edge','column_bottom_edge','bolt_tool_radius','bolt_tool_length') and (c.variant!='angle_seat' or c.attachment!='bolted'):continue
        if key.startswith('weld_') and c.variant=='angle_seat' and c.attachment=='bolted':continue
        if key in ('project','notes') or not hasattr(c,key): continue
        if c.variant!='angle_seat' and (key.startswith('angle_') or key.startswith('weld_') or key=='attachment'):continue
        if c.variant=='angle_seat' and c.weld_mode=='automatic' and key in ('weld_line_capacity','weld_capacity_source'):continue
        if c.variant=='angle_seat' and c.weld_mode=='manual' and key in ('weld_category','weld_electrode'):continue
        if c.variant=='concrete_end' and key in ('support','support_steel'):continue
        if c.variant!='column_continuous' and key in ('shear_left','shear_right'):continue
        value=getattr(c,key)
        if key=='variant': value=TITLES.get(value,value)
        elif key in ('beam','support'):
            value=f'{value.name}; d={fmt(value.d)}, bf={fmt(value.bf)}, tw={fmt(value.tw)}, tf={fmt(value.tf)} mm'
        elif isinstance(value,bool): value='Sim' if value else 'Não'
        elif isinstance(value,(float,int)):value=fmt(value)
        elif key=='weld_mode':value={'automatic':'Automático · Handbook 1 (2007)','manual':'Manual excepcional com fonte'}.get(value,value)
        elif key=='attachment':value={'bolted':'Parafusada','welded':'Soldada'}.get(value,value)
        d.add_paragraph(LABELS.get(key,key)+': '+str(value))
    d.add_heading('2. Hipóteses e limites',1)
    d.add_paragraph('As ações informadas são de cálculo. As verificações desta família empregam o modelo e os fatores AS 4100 identificados nas linhas de cálculo; não se somam resistências de normas distintas e não se atribui resistência a elementos não dimensionados.')
    if c.variant=='column_continuous':
        d.add_paragraph('A viga atravessa o topo do pilar, com continuidade longitudinal dos dois lados. Os cortantes de cada lado pertencem à viga contínua; a reação e a transferência ao pilar exigem compatibilidade com o modelo estrutural.')
    elif c.variant=='concrete_end':
        d.add_paragraph('A viga termina na região do apoio. O detalhe selecionado é apoio direto por gravidade, sem chapa de distribuição e sem chumbadores. Reação, contato e pressão média são entregues ao civil; não se dimensionam concreto, bloco ou fundação. Não são pendências do caminho metálico calculado. O perfil de pilar não é usado nesta família.')
    else:
        d.add_paragraph('Nos modelos B1/B9, bs é calculado pelo equilíbrio acoplado da alma e da cantoneira; o comprimento de apoio genérico não governa esse cálculo. O croqui usa bs calculado, contato transversal limitado à mesa/cantoneira e contato sem calço.')
        if c.attachment=='bolted':
            d.add_paragraph('A extremidade da viga assenta na aba horizontal da cantoneira laminada Grade 300, fixada à mesa do pilar por quatro M20 8.8N/S em malha simétrica 2×2. O caminho DG6 B9 combina Vc, Vd, o limite superior Vf e o grupo Vg: corte dos parafusos e contato/rasgamento das duas peças. A tração adicional por excentricidade é desprezada pelo modelo empírico publicado em DG6 B6 p.26; isso não qualifica forças normais, arrancamento, sismo ou outra topologia. Não há soma de fatores NBR.')
        else:
            d.add_paragraph('A extremidade da viga assenta na aba horizontal de uma cantoneira sem enrijecedor de apoio, fixada à face do pilar. Raio, folga, espessura e extensão efetiva de contato devem ser compatíveis. A fixação B9 usa quatro M20 8.8N/S em malha 2×2 na mesa da coluna, com Vf e resistência de parafusos/contato/rasgamento; exige as dimensões reais do grupo e da montagem. Para soldas, calcula-se o grupo de duas linhas. No modo automático, qRd = φ × 0,6 fuw × (perna/√2) × kr, conforme Handbook 1 (2007), pp.58–60; kr=1 somente no assento não longo. SP usa φ=0,80 e GP φ=0,60. A hipótese é filete de pernas iguais a 90°, sem crédito de penetração ou aumento por direção; execução e compatibilidade metal-base/consumível exigem qualificação.')
    d.add_paragraph('Enrijecedores da viga apoiada: '+('presença indicada, sem dimensionamento ou crédito resistente.' if c.supported_stiffeners else 'ausentes.'))
    d.add_paragraph('Enrijecedores de uma viga receptora não equivalem aos da viga apoiada. Estas três famílias usam concreto ou pilar como apoio; uma solicitação de enrijecedores de viga receptora não é transferida automaticamente para o pilar.')
    d.add_page_break()
    d.add_heading('3. Verificações locais',1)
    d.add_paragraph('Sd e Rd são demanda e resistência de cálculo. Nas linhas geométricas, são valor e limite. O índice é Sd/Rd quando definido. “Sim” vale exclusivamente para a linha correspondente; “Pendente” não constitui aprovação.')
    rows=r.get('checks',[])
    if rows:checks(rows)
    else:d.add_paragraph('Nenhuma verificação numérica disponível para as entradas atuais.')
    d.add_heading('4. Rastreabilidade das verificações',1)
    for row in rows:
        details=[str(row[k]) for k in ('reference','equation','notes') if row.get(k)]
        if details:
            d.add_paragraph(row.get('name',row.get('id','Verificação'))+': '+'; '.join(details))
    if r.get('parameters'):
        d.add_heading('5. Parâmetros derivados do modelo',1)
        for k,v in r['parameters'].items():
            parameter_labels={'angle_fy_MPa':'fy efetivo da cantoneira (MPa)', 'bolted_angle_fy_MPa':'fy efetivo da cantoneira B9 (MPa)', 'bolted_Rf_N':'Raiz nominal Rf (N)', 'bolted_Vf_N':'Limite de cálculo Vf (N)', 'bolted_root_x':'Raiz adimensional x', 'bolted_root_residual':'Resíduo da equação', 'bolt_diameter_mm':'Diâmetro do parafuso (mm)', 'bolt_hole_mm':'Diâmetro do furo (mm)', 'bolt_count':'Número de parafusos de fixação', 'bolt_core_area_mm2':'Área do núcleo roscado (mm²)', 'bolt_fu_MPa':'fu do parafuso (MPa)', 'bolt_phi':'Fator de resistência do parafuso', 'bolt_kr':'Fator de ligação parafusada kr', 'bolt_angle_fu_MPa':'fu da cantoneira (MPa)', 'bolt_angle_ae_mm':'Distância efetiva ae da cantoneira (mm)', 'bolt_column_ae_mm':'Distância efetiva ae da coluna (mm)', 'bolt_angle_bottom_mm':'Borda inferior da cantoneira (mm)', 'bolt_angle_side_mm':'Borda lateral da cantoneira (mm)', 'bolt_column_side_mm':'Borda lateral da mesa (mm)', 'bolt_column_root_envelope_mm':'Envelope da raiz do pilar (mm)', 'bolted_Vg_N':'Resistência do grupo de fixação Vg (N)', 'weld_throat_mm':'Garganta calculada do filete (mm)', 'weld_phi':'Fator de resistência da categoria φ', 'weld_fuw_MPa':'Resistência nominal do metal de solda (MPa)', 'weld_kr':'Fator de comprimento kr (somente assento não longo)', 'weld_qRd_N_per_mm':'Resistência linear de cálculo da solda qRd (N/mm)', 'k1_N_per_mm':'Coeficiente k1 (N/mm)', 'k2_Nmm':'Coeficiente k2 (N mm)', 'k3_mm':'Coeficiente k3 (mm)', 'k4_mm':'Coeficiente k4 (mm)', 'k5_N':'Coeficiente k5 (N)', 'k6_N2':'Coeficiente k6 (N²)', 'column_eccentricity_mm':'Excentricidade para dimensionamento da coluna (mm)', 'column_design_moment_Nmm':'Momento excêntrico a entregar ao cálculo da coluna (N mm)', 'bs_mm':'Comprimento efetivo bs (mm)', 'bbf_mm':'Largura efetiva de escoamento bbf (mm)', 'bb_mm':'Largura efetiva de flambagem bb (mm)', 'bearing_position':'Posição do apoio', 'coupled_capacity_N':'Resistência acoplada (N)', 'minimum_design_reaction_N':'Reação mínima de cálculo (N)', 'design_reaction_N':'Reação adotada (N)', 'ev_mm':'Excentricidade ev (mm)', 'alpha_c':'Fator de redução αc', 'alpha_v':'Fator de redução αv', 'Va_N':'Resistência ao escoamento por cortante Va (N)', 'Vb_N':'Resistência à flambagem por cortante Vb (N)', 'Vc_N':'Resistência local ao escoamento Vc (N)', 'Vd_N':'Resistência local à flambagem Vd (N)'}
            value=fmt(v) if isinstance(v,(int,float)) and not isinstance(v,bool) else {'internal':'Interior','end':'Extremidade'}.get(str(v),str(v))
            d.add_paragraph(parameter_labels.get(k,str(k))+': '+value)
    d.add_heading('6. Interfaces, condições e pendências específicas',1)
    for item in r.get('interfaces',[]):
        d.add_paragraph(item['title']+': '+item['description'])
        values=item.get('values',{})
        if 'mean_pressure_MPa' in values:
            d.add_paragraph('Reação: '+fmt(values['reaction_N'])+' N; contato efetivo: '+fmt(values['contact_length_mm'])+' × '+fmt(values['contact_width_mm'])+' mm; área: '+fmt(values['contact_area_mm2'])+' mm²; pressão média informativa: '+fmt(values['mean_pressure_MPa'])+' MPa. Sem resistência do concreto calculada.')
        elif values.get('moment_Nmm') is not None:
            d.add_paragraph('Reação: '+fmt(values['reaction_N'])+' N; momento excêntrico: '+fmt(values['moment_Nmm'])+' N mm.')
    for item in r.get('execution_requirements',[]):d.add_paragraph(str(item),style='List Bullet')
    if r.get('missing_verifications'):
        d.add_paragraph('Pendências reais do caminho metálico:')
        for item in r['missing_verifications']:d.add_paragraph(str(item),style='List Bullet')
    for err in r.get('errors',[]):d.add_paragraph(str(err),style='List Bullet')
    d.add_paragraph(r.get('diagnosis','Resultado inválido ou indisponível.'))
    d.add_heading('7. Referências e uso',1)
    d.add_paragraph('Revisão privada. Obter permissão do editor antes de uso comercial ou publicação do método.')
    d.add_paragraph('ASI, Design Guide 6 e Handbook 1, primeiras edições de 2007; AS 4100 na base histórica dessas fontes, conforme referências específicas das verificações. Confirmar edição normativa, condições de aplicação e documentação contratual do projeto. Texto, croqui e tabela de resultados são originais; figuras, tabelas e texto editorial do guia não são reproduzidos.')
    if c.notes:
        d.add_heading('Observações do projeto',1);d.add_paragraph(c.notes)
    out=BytesIO();d.save(out);return out.getvalue()
