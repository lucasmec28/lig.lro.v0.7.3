"""Bounded friction-type 2L-T bolted corner compression.

Parameter-driven local mechanics; no qualification fixture/oracle is loaded.
The selected inward U has zero tensile cap credit. Full-cap values are separate
kinematic diagnostics, never an alternative or additive strength resistance.
"""
import math
from dataclasses import fields
from .models import BOLTS

DETAIL_FIELDS = ('bolt_friction_type','bolt_surface_class','bolt_installation_source',
                 'bolt_hardened_washer_count','bolt_washer_location','bolt_washer_diameter',
                 'bolt_angle_continuation','bolt_continuation_source','combination_type')
# NBR8800:2024 Table19, supplied PDF133 / printed111. Metric and inch
# rows remain distinct. Values below are kN, converted only when returned.
PRETENSION_KN = {
    12.7:(53.,67.),15.875:(85.,106.),16.:(91.,114.),19.05:(125.,157.),
    20.:(142.,178.),22.:(176.,221.),22.225:(173.,217.),24.:(205.,257.),
    25.4:(227.,285.),27.:(267.,334.),28.575:(286.,358.),30.:(326.,408.),
    31.75:(363.,455.),36.:(475.,595.)}


def native_detail_required(c):
    if not getattr(c,'topology','').endswith('_bolted'): return False
    if c.topology=='symmetric_2L_T_bolted' and c.P<0: return True
    return any(getattr(c,f.name)!=f.default for f in fields(c) if f.name in DETAIL_FIELDS)


def restraint_identity(c,g):
    from .corner_gusset import BOLTED_FIELDS
    return dict(controls={k:getattr(c,k) for k in BOLTED_FIELDS+DETAIL_FIELDS if k!='combination_type'},
                physical_restraint_source=c.compression_detail_source,stations=g['bolt_stations'],centers=g['bolt_centers'],physical_hole=g['hole_diameter'],
                net_hole=g['net_hole_diameter'],grip=g['bolt_grip'],footprint=g['brace_footprint'],
                contact='firm_direct_L_gusset_L_no_fillers',planes=g['physical_shear_planes'],
                source='Actual clamp/contact/hardware and documented station translation/twist restraint required')


def pretension(c):
    values=PRETENSION_KN.get(c.bolt_diameter)
    if values is None or c.bolt not in ('ASTM F3125 A325','ASTM F3125 A490'): return None
    return values[0 if c.bolt=='ASTM F3125 A325' else 1]*1000.


def friction(c,g,out):
    """Separate service state, also active for positive force on this detail."""
    from .corner_gusset import _check,_issue,MATERIALS
    required=c.P<0 and c.topology=='symmetric_2L_T_bolted'
    if not required and not c.bolt_friction_type:return
    issues=[]
    def pending(id,text,**detail):
        issues.append(id);_issue(out,id,'unverified',text,**detail)
    if not c.bolt_friction_type:pending('compression_friction_end','A primeira rota 2L-T comprimida exige extremidade do tipo atrito, restrição explícita NBR5.3.6.2/6.1.11.2(c), sem certificar o membro global.')
    if c.topology!='symmetric_2L_T_bolted':pending('friction_topology','A rota inicial por atrito está qualificada somente para 2L-T simétricas, dois contatos iguais.')
    FT=pretension(c)
    if not c.bolt_pretensioned or FT is None:pending('friction_pretension','Exige parafuso de alta resistência protendido e linha dimensional publicada da Tabela19.')
    if not c.bolt_drilled:pending('friction_standard_drilled_holes','A primeira rota por atrito usa furos redondos padrão furados; outro processo exige qualificação própria.')
    mu={'A':.30,'B':.50}.get(c.bolt_surface_class)
    if mu is None:pending('friction_surface_class','Identifique superfícies de contato Classe A ou B iguais nas duas faces, preparação e execução reais.')
    if c.bolt_installation_source.strip() in ('','Não informado'):pending('friction_installation_source','Documente preparo das superfícies, método de aperto, inspeção de protensão e hardware endurecido; o programa não certifica execução.')
    minimum_washers=2 if c.bolt=='ASTM F3125 A490' and MATERIALS[c.angle_steel]['fy']<280 else 1
    hardware_ok=(c.bolt_hardened_washer_count>=minimum_washers and c.bolt_washer_location in (('both',) if minimum_washers==2 else ('rotating','both')) and ((c.bolt_washer_location=='both' and c.bolt_hardened_washer_count==2) or (c.bolt_washer_location=='rotating' and c.bolt_hardened_washer_count==1)) and c.bolt_washer_stack>0 and c.bolt_washer_diameter>g['hole_diameter'])
    if not hardware_ok:pending('friction_hardened_washers','Declare arruela(s) endurecida(s) sob o elemento girante; A490 sobre aço fy<280 MPa também exige sob o não girante. Quantidade, posições, espessura total e diâmetro devem corresponder ao hardware real.',minimum_count=minimum_washers)
    if c.bolt_washer_diameter/2>c.bolt_tool_radius+1e-9:pending('friction_washer_access','O raio da arruela excede o envelope de ferramenta/hardware informado; atualize o detalhe real.',washer_radius=c.bolt_washer_diameter/2,tool_radius=c.bolt_tool_radius)
    normal=c.combination_type=='normal_ultimate'
    if not normal:pending('friction_service_case','A conversão 0,70 só é admitida para ELU normal explicitamente identificado. ELU desconhecido/especial/excepcional precisa de demanda de serviço própria ainda não suportada nesta rota.',combination_type=c.combination_type)
    data=dict(required=True,qualified=not issues,issues=issues,limit_state='service_slip',surface_class=c.bolt_surface_class,mu=mu,Ce=1.,interfaces=g['physical_shear_planes'],minimum_pretension=FT,pretension_source='NBR8800:2024 Table19 metric/inch distinct rows, PDF133 printed111',external_bolt_tension=0.,external_tension_scope='No applied bolt tension or prying in this direct axial adapter',basis='0.70 normal ultimate local force only; no converted frame cuts' if normal else 'service demand unavailable',combination_type=c.combination_type,installation_source=c.bolt_installation_source,hardware=dict(hardened_count=c.bolt_hardened_washer_count,location=c.bolt_washer_location,total_thickness=c.bolt_washer_stack,outside_diameter=c.bolt_washer_diameter,grip=g['bolt_grip']),ultimate_friction_capacity_added=False,case_provenance='actual normal ultimate case' if normal else 'unverified service case')
    out['service_slip']=data
    if normal and mu is not None and FT is not None:
        D=.70*abs(c.P)/c.bolt_count;R=.80*mu*FT*g['physical_shear_planes']
        data.update(signed_local_service_force=.70*c.P,per_bolt_demand=D,per_bolt_resistance=R,per_interface_demand=D/g['physical_shear_planes'],per_interface_resistance=.80*mu*FT)
        for j in range(c.bolt_count):
            _check(out,f'bolt{j+1}_service_slip',D,R,'NBR6.3.4.4: 0,80 μ Ce FTb ns; 0,70 somente ELU normal explícito; ELS separado de corte/contato ELU',component='service_slip',bolt_index=j+1,mu=mu,Ce=1.,FTb=FT,ns=g['physical_shear_planes'],per_interface_demand=D/g['physical_shear_planes'],per_interface_resistance=.80*mu*FT)
    return data


def inward_events(c,g):
    from .corner_gusset import _line_intersections,MATERIALS
    us=g['bolt_stations'];r=g['net_hole_diameter']/2;v=g['bolt_row_v'];poly=g['poly_uv'];mat=MATERIALS[c.gusset_steel]
    lo,hi=us[0]-r,us[-1]+r
    events={z+k for z in us for k in (-r,0.,r)}|{p[0] for p in poly if lo<=p[0]<=hi}
    for p,q in g['support_edges_uv'].values():
        for vv in (v-r,v,v+r):
            if (p[1]-vv)*(q[1]-vv)<0:
                z=p[0]+(vv-p[1])*(q[0]-p[0])/(q[1]-p[1])
                if lo<=z<=hi:events.add(z)
    base=sorted(events)
    for a,b in zip(base,base[1:]):
        mid=(a+b)/2;j=next((j for j,z in enumerate(us) if abs(z-mid)<r),None)
        if j is None:continue
        ca=_line_intersections(poly,0,a);cb=_line_intersections(poly,0,b)
        if not ca or not cb:continue
        for side in (0,1):
            slope=(abs(cb[side]-v)-abs(ca[side]-v))/(b-a)
            for K in (-slope,-1.2*mat['fy']/mat['fu']-slope):
                z=us[j]+r*K/math.hypot(1.,K)
                if a<z<b:events.add(z)
        for K in (-1.2*mat['fy']/mat['fu'],-1.2):
            z=us[j]+r*K/math.hypot(1.,K)
            if a<z<b:events.add(z)
    return sorted(events)


def inward_path(c,g,u,side):
    from .corner_gusset import _line_intersections,MATERIALS
    from .bolted_corner import support_hits,edge_id
    poly=g['poly_uv'];us=g['bolt_stations'];v=g['bolt_row_v'];r=g['net_hole_diameter']/2;t=c.plate_t
    ch=_line_intersections(poly,0,u);ray=_line_intersections(poly,1,v)
    if not ch or not ray:return None
    captured=[j+1 for j,z in enumerate(us) if z-r<=u+1e-8];excluded=[j+1 for j,z in enumerate(us) if z+r<u-1e-8]
    if not captured:return None
    h=max([math.sqrt(max(0.,r*r-(u-z)**2)) for z in us if abs(u-z)<=r]+[0.]);ex=ray[0]
    if side in ('negative','positive'):
        vb=ch[0 if side=='negative' else 1];plane=((0.,-1.),-v) if side=='negative' else ((0.,1.),v)
        planes=[((-1.,0.),-u),plane];path=[[ex,v],[u,v],[u,vb]]
        ded=sum(max(0.,min(u,z+r)-max(ex,z-r)) for z in us)
        Agv=(u-ex)*t;Anv=(u-ex-ded)*t;Ant=(abs(vb-v)-h)*t
    else:
        if ch[0]>v-r or ch[1]<v+r:return None
        left=_line_intersections(poly,1,v-r);right=_line_intersections(poly,1,v+r)
        if not left or not right:return None
        ex0,ex1=left[0],right[0];planes=[((-1.,0.),-u),((0.,1.),v-r),((0.,-1.),-(v+r))]
        path=[[ex0,v-r],[u,v-r],[u,v+r],[ex1,v+r]];Agv=(2*u-ex0-ex1)*t;Anv=Agv;Ant=(2*r-2*h)*t;vb=None
    hits=support_hits(g['support_edges_uv'],planes)
    base=dict(id=f'GIN_{side}_{u:.10f}',u=u,side=side,path_uv=path,captured_bolts_including_crossing=captured,captured_bolts_excluding_crossing=excluded,support_hits=hits)
    if hits:return dict(base,active=False,reason='retains_supported_contact')
    if vb is not None and edge_id(g,u,vb).endswith('support'):return dict(base,active=False,reason='transverse_end_on_supported_edge')
    if min(Agv,Anv)<=1e-8 or Ant< -1e-6:return dict(base,active=False,reason='nonpositive_net_path')
    Ant=max(0.,Ant);mat=MATERIALS[c.gusset_steel];Ry=(.6*mat['fy']*Agv+.5*mat['fu']*Ant)/c.gamma_a2;Rr=(.6*mat['fu']*Anv+.5*mat['fu']*Ant)/c.gamma_a2
    R0=min(.6*mat['fy']*Agv,.6*mat['fu']*Anv)/c.gamma_a2;D=abs(c.P)*len(captured)/c.bolt_count;co=g['angle_basis']['cos'];si=g['angle_basis']['sin']
    return dict(base,active=True,Agv=Agv,Anv=Anv,Ant=Ant,zero_cap_resistance=R0,zero_cap_utilization=D/R0,demand=D,demand_limits=[abs(c.P)*len(excluded)/c.bolt_count,D],free_exit=[edge_id(g,*path[0]),edge_id(g,*path[-1])],path_xy=[[co*x-si*y,si*x+co*y] for x,y in path],full_cap_diagnostic=dict(model='diagnostic_only_full_cap_not_selected',Ryield=Ry,Rrupture=Rr,resistance=min(Ry,Rr),utilization=D/min(Ry,Rr)),force_model='conservative included crossing-hole force; no assumed contact pressure')


def calculate(c,g,forces,out):
    from .corner_gusset import _check as check,_issue as issue,_line_intersections,MATERIALS
    from .bolted_corner import body_sections
    a=g['angle'];ma=MATERIALS[c.angle_steel];mg=MATERIALS[c.gusset_steel];P=-c.P;n=c.bolt_count;us=g['bolt_stations'];dh=g['hole_diameter'];dn=g['net_hole_diameter'];t=c.plate_t
    start_issue=len(out['issues']);slip=friction(c,g,out)
    An=a['Ag']-dn*a['t']
    if An<=0:issue(out,'angle_nonpositive_net','invalid_geometry','Área líquida real da cantoneira não positiva.');return
    check(out,'each_angle_local_gross_compression',P/2,a['Ag']*ma['fy']/c.gamma_a1,'NBR5.3/6.5.4 compressão local; membro global excluído',component='angles')
    check(out,'each_angle_net_compression_yield_supplement',P/2,An*ma['fy']/c.gamma_a1,'Suplemento conservador de escoamento líquido em compressão, sem Ct/ruptura de tração',component='angles',An=An)
    limit=.45*math.sqrt(c.E/ma['fy']);row=check(out,'each_angle_compression_AL3',a['leg']/a['t'],limit,'NBR Tabela4 AL3, b nominal completo sem crédito de raio',component='angles')
    if a['leg']/a['t']>limit+1e-9:
        row.update(status='UNVERIFIED',pass_=False,method_domain=True);issue(out,'angle_compression_effective_area','unverified','Aba excede AL3; Aef da cantoneira esbelta exige qualificação própria.')
    # Exact published rz_min value, not a radius inferred from the rolled heel.
    rmin_raw=(a.get('normalized_decimal') or {}).get('rz_min_mm');rmin=float(rmin_raw) if rmin_raw is not None else None
    segment=dict(r_min=rmin,r_min_source=a['source'],K=1.,Le=c.bolt_pitch,domain_limit=25.,station_restraint_basis=c.compression_detail_source)
    if rmin is None or rmin<=0:issue(out,'angle_compression_rmin','unverified','r mínimo publicado ausente; não se infere a propriedade do talão.')
    else:
        slender=c.bolt_pitch/rmin;lam=slender/math.pi*math.sqrt(ma['fy']/c.E);chi=.658**(lam*lam) if lam<=1.5 else .877/lam**2;R=chi*a['Ag']*ma['fy']/c.gamma_a1
        segment.update(Le_over_r=slender,lambda0=lam,chi=chi,resistance=R,A=a['Ag'],Aef=a['Ag'])
        check(out,'each_angle_local_segment_compression',P/2,R,'Modelo local convencional de estações realmente contidas: K1, Le=p máximo, r mínimo publicado, curva NBR5.3 completa',component='angles',**{k:v for k,v in segment.items() if k!='resistance'})
        if slender>25+1e-9:issue(out,'angle_compression_short_interval','unverified','p/r mínimo excede 25, limite escolhido do primeiro domínio local; não é limite universal de passo da norma.',value=slender,bound=25.)
    if c.bolt_angle_continuation<2*c.bolt_diameter-1e-9:issue(out,'angle_compression_continuation','unverified','Verificar continuação íntegra no sentido +u após o último furo: esta rota exige comprimento livre >=2db; ponta livre junto à raiz não fornece esse contato.',clear=c.bolt_angle_continuation,required=2*c.bolt_diameter)
    if c.bolt_continuation_source.strip() in ('','Não informado'):issue(out,'angle_compression_continuation_source','unverified','Identifique o próximo furo/borda ou a continuação íntegra real no sentido carregado +u.')
    ray=_line_intersections(g['poly_uv'],1,g['bolt_row_v'])
    if not ray:issue(out,'bolt_row_outside_polygon','invalid_geometry','Linha de parafusos fora da chapa.');return
    for j,u in enumerate(us):
        for plane in (1,2):
            excluded=getattr(c,'bolt_threads_excluded_'+str(plane));coef=.56 if excluded and c.bolt!='ASTM A307' else .45
            R=coef*math.pi*c.bolt_diameter**2/4*BOLTS[c.bolt]/c.gamma_a2*g['bolt_grip_factor']
            check(out,f'2L-T_bolt{j+1}_plane{plane}',P/(2*n),R,'NBR6.3.3.2/6.3.7 corte ELU independente de deslizamento ELS',component='bolts',bolt_index=j+1,plane=plane,threads_excluded=excluded,coefficient=coef,grip=g['bolt_grip'],grip_factor=g['bolt_grip_factor'])
        for part,lc,th,mat,D in [('angle',us[j+1]-u-dh if j<n-1 else c.bolt_angle_continuation,a['t'],ma,P/(2*n)),('gusset',u-ray[0]-dh/2 if j==0 else u-us[j-1]-dh,t,mg,P/n)]:
            R=max(0.,min(1.2*lc*th*mat['fu'],2.4*c.bolt_diameter*th*mat['fu'])/c.gamma_a2)
            check(out,('2L-T_' if part=='angle' else 'common_')+part+f'_bearing{j+1}',D,R,'NBR6.3.3.3(a) parede física na direção real; sem soma entre furos',component=part+'_bearing',lc=lc,hole=j+1,force_direction='+u' if part=='angle' else '-u',physical_hole_diameter=dh)
    width=g['whitmore']['nominal_width']
    if width<=dn:issue(out,'whitmore_nonpositive_net','invalid_geometry','Faixa Whitmore sem ligamento líquido positivo.')
    else:check(out,'gusset_whitmore_net_compression_yield_supplement',P,(width-dn)*t*mg['fy']/c.gamma_a1,'Suplemento conservador de escoamento líquido em compressão, sem Ct',component='gusset_whitmore',net_width=width-dn)
    events=inward_events(c,g);paths=[z for u in events for side in ('negative','positive','tangent_U') if (z:=inward_path(c,g,u,side))]
    active_L=[z for z in paths if z['side']!='tangent_U' and z['active']]
    unsupported_reasons=[z for z in paths if z['side']!='tangent_U' and not z['active'] and z['reason'] not in ('retains_supported_contact','transverse_end_on_supported_edge')]
    if active_L or unsupported_reasons:issue(out,'compression_inward_L_topology','unverified','Um caminho L reverso fica ativo ou não é excluído por apoio real. Essa família precisa qualificação própria e não é descartada.',active_count=len(active_L),other_inactive_count=len(unsupported_reasons))
    active_U=[z for z in paths if z['side']=='tangent_U' and z['active']]
    wrong_U=[z for z in paths if z['side']=='tangent_U' and (not z['active'] or z.get('free_exit')!=['clip_free','clip_free'])]
    zero=None
    if not active_U or wrong_U:issue(out,'compression_inward_U_topology','unverified','As duas pernas U distintas devem alcançar o recorte interior livre real sem reter apoio; outra saída exige qualificação específica.',admissible=len(active_U),unqualified=len(wrong_U))
    if active_U:
        zero=max(active_U,key=lambda z:z['zero_cap_utilization']);diagnostic=max(active_U,key=lambda z:z['full_cap_diagnostic']['utilization'])
        check(out,'gusset_inward_tangent_U_zero_cap',zero['demand'],zero['zero_cap_resistance'],'NBR6.5.6 envelope conservador U interno: min(0,6fy Agv;0,6fu Anv)/γa2, crédito de tração no cap=0',component='gusset_block',model='selected_zero_tension_cap',witness=zero)
    else:diagnostic=None
    out['gusset_paths']=dict(admissible=[z for z in paths if z['active']],rejected_supported=[z for z in paths if not z['active']],events=events,basis='inward_tangent_U_zero_cap_only_L_support_inactive',selected_zero_cap=zero,full_cap_diagnostic=diagnostic)
    body_sections(c,g,forces,out,events)
    co=g['angle_basis']['cos'];si=g['angle_basis']['sin'];boltR=[sum(c.P/n*co for _ in us),sum(c.P/n*si for _ in us),sum(x*c.P/n*si-y*c.P/n*co for x,y in g['bolt_centers'])]
    expected=[forces['H'],forces['V'],c.P*c.workpoint_offset]
    if any(abs(x-y)>1e-6*max(1.,abs(y)) for x,y in zip(boltR,expected)):issue(out,'bolt_resultant_mismatch','invalid_input','Resultante dos parafusos não fecha a força nominal uma vez.')
    out['brace']=dict(An=An,Lc=g['Lc'],angle_count=2,weld_count=0,physical_bolt_count=n,shear_planes_per_bolt=2,per_angle_force=c.P/2,per_plane_force=c.P/(2*n),force_per_gusset_hole=c.P/n,physical_bolt_resultant=boltR,nominal_connection_axis_z=0.,face='both',angle_block_paths=[],force_mode='compression',global_member_stability='outside_scope',angle_segment=segment)
    cp=out.get('compression',{});cp.update(angle_segment=segment,inward_zero_cap=zero,friction_detail=slip)
    blockers=[i['id'] for i in out['issues'][start_issue:] if i['severity'] in ('unverified','outside_scope','invalid_geometry','invalid_input')]
    cp['qualification_issues']=cp.get('qualification_issues',[])+blockers;cp['qualified']=not cp['qualification_issues']
