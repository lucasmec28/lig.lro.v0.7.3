"""Proportional R015 drawings: two physical L angles, U welds, support bolts.

x follows the beam, y is vertical, z crosses the single beam web; the
support face is x=0. Dimensions come from the input, never result geometry.
"""
from io import BytesIO
from math import isfinite
from .angle_catalog_selection import add_drawing_provenance
from .drawing_annotations import dimension

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.path import Path
from matplotlib.patches import Circle, PathPatch, Polygon, Rectangle

INK='#263746'; MEMBER='#dce2e7'; ANGLE1='#76aeba'; ANGLE2='#e5b978'
MUTED='#677783'; RED='#a52b32'; WELD='#b84030'

STATUS={
    'SEM AVALIAÇÃO':'SEM AVALIAÇÃO',
    'INVALID_INPUT':'DADOS INVÁLIDOS',
    'NUMERICAL_FAILURE':'FALHA NUMÉRICA',
    'INVALID_GEOMETRY':'GEOMETRIA INVÁLIDA',
    'OUTSIDE_R015_SCOPE':'FORA DO DOMÍNIO R015',
    'DETAIL_FAIL':'DETALHAMENTO NÃO ATENDIDO',
    'VERIFIED_SUBCHECK_FAIL':'HÁ VERIFICAÇÃO NÃO ATENDIDA',
    'ENGINEERING_MODEL_PENDING':'VERIFICAÇÃO COMPLEMENTAR PENDENTE',
    'COMPLETE_CHECKS_PASS_WITHIN_SCOPE':'VERIFICAÇÕES ATENDIDAS NO DOMÍNIO R015',
    'COMPLETE_CHECKS_PASS_WITH_PRESET_DEVIATION':'ATENDE COM DESVIO DO PADRÃO DE OFICINA',
}


def _dimensions(c):
    positive=(c.beam.d,c.beam.bf,c.beam.tw,c.beam.tf,c.support.d,c.support.bf,
        c.support.tw,c.support.tf,c.beam_leg,c.support_leg,c.t,c.length,
        c.support_gauge,c.support_pitch,c.support_end_top,c.support_edge_top,
        c.support_edge_bottom,c.hole_diameter,c.db,c.weld_leg)
    if any(isinstance(v,bool) or not isinstance(v,(int,float)) or not isfinite(v) or v<=0 for v in positive):
        raise ValueError('O desenho R015 exige dimensões positivas e finitas.')
    for v in (c.gap,c.angle_top,c.root_radius,c.weld_start):
        if isinstance(v,bool) or not isinstance(v,(int,float)) or not isfinite(v) or v<0:
            raise ValueError('Folgas, posição, raio e início da solda devem ser finitos e não negativos.')
    for count in (c.angle_count,c.support_rows,c.support_columns):
        if type(count) is not int or not 1<=count<=20:
            raise ValueError('O desenho R015 exige contagens inteiras entre 1 e 20.')
    if isinstance(c.V,bool) or not isinstance(c.V,(int,float)) or not isfinite(c.V):
        raise ValueError('V deve ser finito para representar seu sentido.')


def validated_result(c,r):
    """Always evaluate current input; caller results are compatibility-only.

    An input snapshot or matching hash cannot authenticate numerical values,
    flags or issues supplied by a caller. No supplied result is trusted.
    """
    from .welded_double_angle import evaluate
    return evaluate(c)


def _approved(r):
    return (isinstance(r.get('inputs'),dict) and r.get('global_pass') is True and r.get('status') in ('COMPLETE_CHECKS_PASS_WITHIN_SCOPE','COMPLETE_CHECKS_PASS_WITH_PRESET_DEVIATION') and (r.get('geometry') or {}).get('valid') is True
        and (r.get('summary') or {}).get('complete_checks') is True and bool(r.get('checks'))
        and all(x.get('status')=='PASS' for x in r.get('checks',[]))
        and not any(x.get('severity') in {'engineering_pending','unsupported_scope','invalid_input',
            'invalid_geometry','numerical_failure','detail_fail','error','pending','access_pending'} for x in r.get('issues',[])))


def _figure(c,r=None):
    _dimensions(c);r=validated_result(c,r)
    fig=plt.figure(figsize=(14,10.1),facecolor='white')
    fig.text(.035,.968,'LIGAÇÃO R015  |  DUAS CANTONEIRAS SOLDADAS / PARAFUSADAS',fontsize=16,fontweight='bold',color=INK)
    fig.text(.035,.939,f'Viga {c.beam.name}  →  mesa do pilar {c.support.name}',fontsize=10.5,color=INK)
    fig.text(.035,.895,'Projeto: '+str(c.project),fontsize=8.5,color=INK).set_gid('current_project')
    actions=f'Ações reais: V={c.V:+g} N; N={c.N:+g} N; M={c.M:+g} N mm; T={c.torsion:+g} N mm'
    actions_text=fig.text(.035,.875,actions,fontsize=8.3,color=INK)
    actions_text.set_gid('actual_signed_actions')
    status=str(r.get('status','SEM AVALIAÇÃO'))
    status_text=fig.text(.965,.918,STATUS.get(status,'ESTADO NÃO RECONHECIDO'),ha='right',fontsize=8.5,color=INK if _approved(r) else RED)
    status_text.set_gid('engine_status_'+status)
    if not _approved(r):fig.text(.035,.918,'SEM APROVAÇÃO GLOBAL',fontsize=8.8,color=RED)
    topology=(c.angle_count==2 and c.symmetric is True and c.kind=='column_flange'
              and c.support_columns==1 and c.weld_layout=='U_three_edges')
    if not topology or c.weld_start>=c.beam_leg:
        fig.text(.06,.78,'TOPOLOGIA NÃO REPRESENTADA',fontsize=18,color=RED,fontweight='bold')
        fig.text(.06,.67,f'Entrada preservada: {c.angle_count} cantoneira(s); simetria={c.symmetric}; apoio={c.kind}.\n'
                 f'Colunas por aba de apoio={c.support_columns}; solda={c.weld_layout}.\n'
                 f'Início/fim dos ramos transversais: x={c.weld_start:g} / {c.beam_leg:g} mm.\n'
                 'A representação exige duas cantoneiras simétricas, uma coluna por aba de apoio\n'
                 'e três segmentos em U na aba junto à alma. Esta entrada exige detalhe próprio.',
                 fontsize=12,color=INK,linespacing=1.8)
        fig.text(.06,.42,f'Abas viga/apoio={c.beam_leg:g}/{c.support_leg:g}; t={c.t:g}; L={c.length:g} mm.\n'
                 f'Perna de solda={c.weld_leg:g} mm; V={c.V/1000:g} kN.',fontsize=12,color=INK,linespacing=1.8)
        fig.text(.035,.04,'Não foi inventado outro arranjo de cantoneiras ou de soldas para esta entrada.',fontsize=11,color=RED)
        return add_drawing_provenance(fig, c)
    elev=fig.add_axes((.035,.475,.49,.365));front=fig.add_axes((.61,.455,.335,.385));plan=fig.add_axes((.035,.092,.54,.285))
    for ax in (elev,front,plan):ax.set_aspect('equal');ax.axis('off')
    def rect(ax,x,y,w,h,color,gid=None,**kw):
        p=Rectangle((x,y),w,h,facecolor=color,edgecolor=INK,lw=.8,**kw);p.set_gid(gid);ax.add_patch(p);return p
    def line(ax,x,y,gid=None,**kw):
        p,=ax.plot(x,y,color=kw.pop('color',INK),lw=kw.pop('lw',.8),**kw);p.set_gid(gid);return p
    def hole(ax,x,y,gid):
        p=Circle((x,y),c.hole_diameter/2,facecolor='white',edgecolor=INK,lw=.8);p.set_gid(gid);ax.add_patch(p)
        d=c.hole_diameter*.2;line(ax,[x-d,x+d],[y,y],lw=.45);line(ax,[x,x],[y-d,y+d],lw=.45)
    def dim(ax,x1,y1,x2,y2,label,short_side=1):
        return dimension(ax,(x1,y1),(x2,y2),label,fontsize=8.2,
            rotation=90 if x1==x2 else 0,color=INK,pad=1,lw=.65,short_side=short_side)
    def leader(ax,label,xy,text,ha='left',color=INK,connectionstyle='arc3'):
        return ax.annotate(label,xy=xy,xytext=text,ha=ha,va='center',fontsize=8.3,color=color,
            arrowprops={'arrowstyle':'-','lw':.6,'color':color,'connectionstyle':connectionstyle},bbox={'facecolor':'white','edgecolor':'none','pad':1})
    def title(ax,label):ax.set_title(label,loc='left',fontsize=10.5,fontweight='bold',color=INK,pad=14)
    ytop=c.beam.d/2-c.angle_top;yb=ytop-c.length
    ys=[ytop-c.support_end_top-i*c.support_pitch for i in range(c.support_rows)]
    support_top=ys[0]+c.support_edge_top;support_bottom=ys[-1]-c.support_edge_bottom
    z0=c.beam.tw/2;zs=z0+c.support_gauge;stub=max(c.beam_leg+130,c.beam.d*.60)
    local_top=max(c.beam.d/2,ytop)+35;local_bottom=min(-c.beam.d/2,yb)-35
    title(elev,'A  ELEVAÇÃO: SOLDA EM U JUNTO À ALMA')
    rect(elev,-c.support.d,local_bottom,c.support.d,local_top-local_bottom,MEMBER,'support_elevation_crop',alpha=.42)
    rect(elev,-c.support.tf,local_bottom,c.support.tf,local_top-local_bottom,MEMBER,'support_front_flange_elevation')
    rect(elev,-c.support.d,local_bottom,c.support.tf,local_top-local_bottom,MEMBER,'support_rear_flange_elevation')
    for y in (local_bottom,local_top):line(elev,[-c.support.d,-c.support.d*.68,-c.support.d*.62,-c.support.d*.55,0],[y,y,y+6,y,y],lw=1.2)
    rect(elev,c.gap,-c.beam.d/2,stub-c.gap,c.beam.d,'#eef1f4','beam_web_elevation')
    for suffix,y in (('bottom',-c.beam.d/2),('top',c.beam.d/2-c.beam.tf)):
        rect(elev,c.gap,y,stub-c.gap,c.beam.tf,MEMBER,'beam_'+suffix+'_flange_elevation')
    rect(elev,0,yb,c.beam_leg,c.length,ANGLE1,'angle_A1_elevation',alpha=.87)
    rect(elev,0,yb,c.beam_leg,c.length,'none','angle_A2_elevation',linestyle='--')
    # No heel closure and no weld on the projecting support leg. Both
    # physical U groups have coincident projections in this elevation.
    for code in ('A2','A1'):
        style={'color':ANGLE2 if code=='A2' else WELD,'lw':4.3 if code=='A2' else 2.,'solid_capstyle':'butt'}
        line(elev,[c.weld_start,c.beam_leg],[ytop,ytop],f'weld_{code}_top_elevation',**style)
        line(elev,[c.beam_leg,c.beam_leg],[ytop,yb],f'weld_{code}_toe_elevation',**style)
        line(elev,[c.weld_start,c.beam_leg],[yb,yb],f'weld_{code}_bottom_elevation',**style)
    for i,y in enumerate(ys):line(elev,[-c.support.tf-7,c.t+7],[y,y],f'support_bolt_elevation_{i}',lw=2)
    dim(elev,0,local_bottom-27,c.beam_leg,local_bottom-27,f'b viga = {c.beam_leg:g}',short_side=-1)
    dim(elev,stub+23,yb,stub+23,ytop,f'L = {c.length:g}')
    dim(elev,c.weld_start,local_top+23,c.beam_leg,local_top+23,f'ramo = {c.beam_leg-c.weld_start:g}')
    leader(elev,f'início x = {c.weld_start:g}',(c.weld_start,ytop),(c.beam_leg+27,ytop+30),color=WELD)
    leader(elev,f'filete w = {c.weld_leg:g}',(c.beam_leg,yb+18),(c.beam_leg+33,yb-13),color=WELD)
    leader(elev,f'folga = {c.gap:g}',(c.gap/2,-c.beam.d/2),(c.beam_leg+24,local_bottom-26))
    elev.text(-c.support.d,local_top+23,'Fuste interrompido',fontsize=8.2,color=MUTED)
    arrow_x=stub-25;ym=(ytop+yb)/2;direction=-1 if c.V>=0 else 1
    if c.V!=0:
        a=elev.annotate('',(arrow_x,ym+direction*45),(arrow_x,ym-direction*27),arrowprops={'arrowstyle':'-|>','lw':1.8,'color':RED,'mutation_scale':14})
        a.set_gid('load_V_positive_down' if c.V>0 else 'load_V_negative_up')
    elev.text(arrow_x-12,ym,f'V = {c.V/1000:g}\nkN',fontsize=9,color=RED,va='center',ha='right')
    elev.set_xlim(-c.support.d-10,stub+75);elev.set_ylim(local_bottom-59,local_top+45)

    title(front,'B  FRENTE: PARAFUSOS NO APOIO')
    rect(front,-c.support.bf/2,support_bottom,c.support.bf,support_top-support_bottom,MEMBER,'support_front_real_edges',alpha=.7)
    for z in (-c.support.tw/2,c.support.tw/2):line(front,[z,z],[support_bottom,support_top],ls='--',color=MUTED,lw=.65)
    for sign,code,color in ((-1,'A1',ANGLE1),(1,'A2',ANGLE2)):
        z=-z0-c.support_leg if sign<0 else z0
        rect(front,z,yb,c.support_leg,c.length,color,f'angle_{code}_support_front')
        for i,y in enumerate(ys):hole(front,sign*zs,y,f'support_hole_{code}_{i}')
    rect(front,-z0,-c.beam.d/2+c.beam.tf,c.beam.tw,c.beam.d-2*c.beam.tf,'none','beam_web_front')
    for suffix,y in (('top',c.beam.d/2-c.beam.tf),('bottom',-c.beam.d/2)):
        rect(front,-c.beam.bf/2,y,c.beam.bf,c.beam.tf,'none','beam_'+suffix+'_front')
    dim(front,-c.support.bf/2,support_bottom-40,c.support.bf/2,support_bottom-40,f'bf apoio = {c.support.bf:g}',short_side=-1)
    dim(front,c.support.bf/2+40,ys[0],c.support.bf/2+40,support_top,f'e sup = {c.support_edge_top:g}',short_side=-1)
    dim(front,c.support.bf/2+40,support_bottom,c.support.bf/2+40,ys[-1],f'e inf = {c.support_edge_bottom:g}',short_side=-1)
    dim(front,-zs,support_top+40,zs,support_top+40,f'linhas = {2*zs:g}')
    leader(front,'Borda livre real',(-c.support.bf/2,ys[0]),(-c.support.bf/2-25,ys[0]+145),ha='right')
    front.set_xlim(-c.support.bf/2-200,c.support.bf/2+110);front.set_ylim(support_bottom-75,support_top+75)

    title(plan,'C  PLANTA: DOIS L E UMA ÚNICA ALMA')
    rect(plan,-c.support.d,-c.support.bf/2,c.support.tf,c.support.bf,MEMBER,'support_rear_flange_plan')
    rect(plan,-c.support.tf,-c.support.bf/2,c.support.tf,c.support.bf,MEMBER,'support_front_flange_plan')
    rect(plan,-c.support.d+c.support.tf,-c.support.tw/2,c.support.d-2*c.support.tf,c.support.tw,MEMBER,'support_web_plan')
    rect(plan,c.gap,-z0,stub-c.gap,c.beam.tw,MEMBER,'beam_web_plan')
    for z in (-c.beam.bf/2,c.beam.bf/2):line(plan,[c.gap,stub],[z,z],ls='--',color=MUTED)
    for sign,code,color in ((-1,'A1',ANGLE1),(1,'A2',ANGLE2)):
        b,s,t,rr=c.beam_leg,c.support_leg,c.t,c.root_radius;k=.5522847498307936
        verts=[(0,z0),(b,z0),(b,z0+t),(t+rr,z0+t)];codes=[Path.MOVETO,Path.LINETO,Path.LINETO,Path.LINETO]
        if rr>0:
            verts.extend([(t+rr-k*rr,z0+t),(t,z0+t+rr-k*rr),(t,z0+t+rr)]);codes.extend([Path.CURVE4]*3)
        else:verts.append((t,z0+t));codes.append(Path.LINETO)
        verts.extend([(t,z0+s),(0,z0+s),(0,z0)]);codes.extend([Path.LINETO,Path.LINETO,Path.CLOSEPOLY])
        p=PathPatch(Path([(x,sign*z) for x,z in verts],codes),facecolor=color,edgecolor=INK,lw=.95)
        p.set_gid(f'angle_{code}_L_plan');plan.add_patch(p)
        p=Polygon([(b,sign*z0),(b+c.weld_leg,sign*z0),(b,sign*(z0+c.weld_leg))],facecolor=WELD,edgecolor=WELD,lw=.65)
        p.set_gid(f'weld_{code}_toe_section');plan.add_patch(p)
        line(plan,[-c.support.tf-8,c.t+8],[sign*zs,sign*zs],f'support_bolt_{code}_plan',lw=2)
        rect(plan,-c.support.tf-8,sign*zs-c.db*.35,5,c.db*.7,INK,f'support_head_{code}_plan')
        line(plan,[0,0],[sign*zs-c.db*.5,sign*zs+c.db*.5],f'support_shear_plane_{code}',color=RED,lw=2)
        leader(plan,code,(c.beam_leg*.65,sign*(z0+c.t/2)),(c.beam_leg+50,sign*50))
    dim(plan,0,-c.support.bf/2-32,c.beam_leg,-c.support.bf/2-32,f'b viga = {c.beam_leg:g}',short_side=-1)
    dim(plan,stub+25,z0,stub+25,z0+c.support_leg,f'b apoio = {c.support_leg:g}',short_side=-1)
    leader(plan,f'g apoio = {c.support_gauge:g}',(c.t,zs),(35,c.support.bf/2+28))
    # One callout branches to the material of both existing weld triangles.
    # The elbow lane is left of the A1 label; it does not mask the component.
    joint=(c.beam_leg+22,0)
    leader(plan,'2 filetes, uma alma',joint,(c.beam_leg+48,-c.support.bf/2+3),color=WELD,
        connectionstyle='angle,angleA=180,angleB=-90,rad=0').set_gid('annotation_weld_pair')
    for sign,code in ((-1,'A1'),(1,'A2')):
        target=(c.beam_leg+c.weld_leg/3,sign*(z0+c.weld_leg/3))
        branch=plan.annotate('',xy=target,xytext=joint,arrowprops={
            'arrowstyle':'-','lw':.6,'color':WELD,'shrinkA':0,'shrinkB':0})
        branch.set_gid('annotation_weld_'+code)

    plan.set_xlim(-c.support.d-12,stub+108);plan.set_ylim(-c.support.bf/2-62,c.support.bf/2+60)
    end_bottom=c.length-c.support_end_top-(c.support_rows-1)*c.support_pitch
    h=c.beam_leg-c.weld_start;lw=c.length+2*h;xbar=(c.beam_leg*c.length+h*(c.weld_start+c.beam_leg))/lw
    notes=[
        f'2 peças L {c.beam_leg:g} × {c.support_leg:g} × {c.t:g}; raio {c.root_radius:g} mm',
        f'L = {c.length:g}; topo a {c.angle_top:g} mm do topo da viga',
        f'Cada U: vertical {c.length:g} + 2 ramos de {h:g} mm',
        f'Filete w = {c.weld_leg:g}; garganta a = w/√2; Lw = {lw:g} mm',
        f'SMAW E7018 em passe único; fuw = {c.electrode_fuw:g} MPa',
        f'U aberto no apoio; x̄ = {xbar:.2f} mm desde x = 0',
        'Fy = V/2 em x = 0; Mz = −x̄·Fy por cantoneira',
        f'Apoio: 2 × {c.support_rows} parafusos; passo {c.support_pitch:g} mm',
        f'Bordas do L: {c.support_end_top:g} / {end_bottom:g} mm',
        f'Ø parafuso {c.db:g}; Ø furo {c.hole_diameter:g} mm, só no apoio',
        f'Alma tw = {c.beam.tw:g}; mesa do apoio tf = {c.support.tf:g} mm',
        'Cada parafuso de apoio: um plano de corte. Cotas em mm.',
        'A1 azul; A2 ocre; soldas vermelhas. Não há parafusos na alma.',
        'Borda reforçada: sim; garantir garganta no procedimento.' if c.reinforced_weld_edge else 'Borda sem reforço especial; limites de filete permanecem aplicáveis.',
    ]
    fig.text(.605,.381,'GEOMETRIA E CAMINHO DAS FORÇAS',fontsize=10.2,fontweight='bold',color=INK)
    fig.text(.605,.359,'\n'.join(notes),fontsize=8.55,linespacing=1.55,va='top',color=INK)
    fig.text(.035,.049,'Domínio do método: par simétrico sob V estático; N = M = T = 0. Ramos do U na aba da viga; não há solda na aba de apoio.',fontsize=9,color=INK)
    fig.text(.035,.026,'Esquema dimensionado; não libera fabricação. Fonte geométrica: R015, p. 18; Gerdau LCSP, p. 19 e p. 50.',fontsize=9,color=INK)
    # Reserve actual rendered clearance rather than relying on baseline rows.
    fig.canvas.draw()
    renderer=fig.canvas.get_renderer()
    header_bottom=actions_text.get_window_extent(renderer).y0
    title_top=max(ax._left_title.get_window_extent(renderer).y1 for ax in (elev,front))
    shift=max(0.,(title_top+8*fig.dpi/72-header_bottom)/fig.bbox.height)
    for ax in (elev,front):
        pos=ax.get_position();ax.set_position((pos.x0,pos.y0-shift,pos.width,pos.height))
    return add_drawing_provenance(fig, c)


def image_bytes(c,r=None,fmt='png'):
    with plt.rc_context({'font.family':'DejaVu Sans','font.size':10,'svg.fonttype':'none'}):
        fig=_figure(c,r)
        try:
            out=BytesIO();fig.savefig(out,format=fmt,dpi=170,facecolor='white',metadata={'Creator':'LRO R015 welded double angle'});return out.getvalue()
        finally:plt.close(fig)


def drawing_svg(c,r=None):return image_bytes(c,r,'svg').decode('utf-8')
