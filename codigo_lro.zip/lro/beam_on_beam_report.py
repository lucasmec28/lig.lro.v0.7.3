"""Editable record of partial beam-on-beam checks, never a connection approval.

Every export reevaluates the current immutable input. The optional ``result``
argument is intentionally ignored. Display formatting is a one-way operation:
neither inputs nor calculated values are rounded or written back by this module.
"""
from dataclasses import fields, is_dataclass
from io import BytesIO

from docx import Document
from docx.enum.section import WD_ORIENT, WD_SECTION_START
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor

from .beam_on_beam import (
    BeamOnBeam, COMPONENT_VERSION, CONNECTION_TYPE, EXCLUSIONS, NBR, SCOPE,
    evaluate, input_errors,
)
from .display_precision import calculated_text
from .models import BOLTS, KGF, STEELS, finite_real
from .report import BRAND, _math, frac, group, hyperlink, number, power, sub, table


STATUS = {
    'INVALID_INPUT': 'Entrada inválida',
    'INVALID_GEOMETRY': 'Geometria inválida',
    'NUMERICAL_FAILURE': 'Falha numérica',
    'OUTSIDE_SUPPORTED_SCOPE': 'Fora do domínio implementado',
    'VERIFIED_SUBCHECK_FAIL': 'Verificação parcial não atendida',
    'DETAIL_FAIL': 'Requisito geométrico não atendido',
    'ENGINEERING_MODEL_PENDING': 'Transferência local fora do plano pendente',
    'PARTIAL_CHECKS_PASS': 'Verificações parciais atendidas no escopo',
    'PARTIAL_CHECKS_PASS_MODEL_PENDING': 'Verificações parciais atendidas com modelo local pendente',
    'LOCAL_RESISTANCE_FAIL_MODEL_PENDING': 'Resistência local não atendida com modelo pendente',
    'GEOMETRY_FAIL_MODEL_PENDING': 'Geometria não atendida com modelo local pendente',
    'EXTERNAL_EQUILIBRIUM_FAIL': 'Demandas externas sem equilíbrio válido',
}
CHECK_STATUS = {
    'PASS': 'ATENDE NO ESCOPO', 'FAIL': 'NÃO ATENDE',
    'PENDING': 'PENDENTE', 'OUTSIDE_SCOPE': 'FORA DO ESCOPO',
    'NOT_APPLICABLE': 'INAPLICÁVEL', 'NOT_EVALUATED': 'NÃO AVALIADO',
}
LABELS = {
    'project': 'Projeto', 'plate_length': 'Comprimento da chapa em x mm',
    'plate_width': 'Largura da chapa em y mm', 'tp': 'Espessura da chapa mm',
    'bolt_pitch': 'Passo dos parafusos em x mm', 'bolt_gauge': 'Gabarito dos parafusos em y mm',
    'db': 'Diâmetro do parafuso mm', 'hole_diameter': 'Diâmetro físico do furo mm',
    'bolt': 'Classe dos parafusos', 'threads_excluded': 'Rosca excluída do plano de corte',
    'drilled': 'Furação por broca documentada', 'beam_steel': 'Aço da viga superior',
    'support_steel': 'Aço da viga inferior', 'plate_steel': 'Aço da chapa',
    'stiffener_steel': 'Aço dos enrijecedores', 'weld_leg': 'Perna da solda da chapa mm',
    'weld_length': 'Comprimento declarado por linha de solda mm',
    'electrode_fuw': 'Resistência fuw do metal de solda MPa',
    'stiffeners': 'Par de enrijecedores na alma inferior',
    'stiffener_t': 'Espessura por enrijecedor mm',
    'stiffener_width': 'Largura saliente por enrijecedor mm',
    'stiffener_height': 'Altura por enrijecedor mm',
    'stiffener_clip': 'Recorte de concordância dos enrijecedores mm',
    'stiffener_weld': 'Perna da solda dos enrijecedores mm',
    'stiffener_y': 'Posição do par de enrijecedores ao longo da inferior mm',
    'V': 'V simultâneo descendente positivo N', 'N': 'N simultâneo no eixo superior N',
    'applied_moment_y': 'Momento externo declarado My N mm',
    'torsion': 'Torção aplicada no plano dos parafusos N mm',
    'reference_x': 'Abscissa do referencial das ações em x mm',
    'contact_resultant': 'Resultante externa de contato C N',
    'contact_x': 'Abscissa externa da resultante de contato xc mm',
    'contact_y': 'Ordenada externa da resultante de contato yc mm',
    'support_root_radius': 'Raio real de concordância da viga inferior mm',
    'support_end_negative': 'Extremidade negativa da viga inferior ao cruzamento mm',
    'support_end_positive': 'Extremidade positiva da viga inferior ao cruzamento mm',
    'bolt_tension_1': 'Tração total externa no parafuso 1 N',
    'bolt_tension_2': 'Tração total externa no parafuso 2 N',
    'bolt_tension_3': 'Tração total externa no parafuso 3 N',
    'bolt_tension_4': 'Tração total externa no parafuso 4 N',
    'tensions_include_prying': 'Trações externas incluem alavanca declarada',
    'external_same_case': 'Modelo externo pertence ao mesmo caso simultâneo',
    'local_model_reference': 'Identificação e origem do modelo local externo',
    'tool_radius': 'Raio declarado de ferragem e ferramenta mm',
    'fabrication_clearance': 'Folga adicional de fabricação mm',
    'static': 'Ações estáticas', 'normal_combination': 'Combinação última normal',
    'no_slip_required': 'Ausência de deslizamento exigida', 'notes': 'Observações',
}


def _value(value):
    if value is None:
        return 'PENDENTE'
    if isinstance(value, bool):
        return 'sim' if value else 'não'
    if isinstance(value, (int, float)):
        return number(value) if finite_real(value) else str(value) + ' (inválido)'
    if isinstance(value, (list, tuple)):
        return '; '.join(_value(v) for v in value)
    if isinstance(value, dict):
        return '; '.join(str(k) + '=' + _value(v) for k, v in value.items())
    return str(value) if value != '' else 'não informado'


def _mapping(value):
    return value if isinstance(value, dict) else {}


def _flatten(value, path=''):
    if isinstance(value, dict):
        for key, child in value.items():
            yield from _flatten(child, path + '.' + str(key) if path else str(key))
    elif isinstance(value, (list, tuple)) and any(isinstance(v, (dict, list, tuple)) for v in value):
        for index, child in enumerate(value):
            yield from _flatten(child, path + '[' + str(index) + ']')
    else:
        yield path, _value(value)


def _heading(doc, title, level=1):
    return doc.add_paragraph(title, style='Heading ' + str(level))


def _tab(doc, headers, rows, widths, size=9):
    t = table(doc, headers, rows, widths)
    for row in t.rows:
        for index, cell in enumerate(row.cells):
            for p in cell.paragraphs:
                p.alignment = WD_ALIGN_PARAGRAPH.LEFT if index == 0 else WD_ALIGN_PARAGRAPH.CENTER
                for run in p.runs:
                    run.font.size = Pt(size)
    return t


def _new_page(doc, landscape=False):
    s = doc.add_section(WD_SECTION_START.NEW_PAGE)
    s.orientation = WD_ORIENT.LANDSCAPE if landscape else WD_ORIENT.PORTRAIT
    s.page_width, s.page_height = Inches(11.69 if landscape else 8.27), Inches(8.27 if landscape else 11.69)
    s.top_margin = s.bottom_margin = Inches(.6)
    s.left_margin = s.right_margin = Inches(.6)
    return s


def _intro(doc, c, r):
    doc.add_paragraph('Viga sobre viga com chapa contínua de apoio', style='Title')
    doc.add_paragraph('Memória editável de verificações locais parciais')
    doc.add_paragraph(_value(getattr(c, 'project', 'Entrada sem projeto')))
    p = doc.add_paragraph()
    p.add_run('SEM APROVAÇÃO DA LIGAÇÃO COMPLETA').bold = True
    status = r.get('status', 'NOT_EVALUATED')
    doc.add_paragraph(STATUS.get(status, str(status)) + '  |  ' + str(status))
    doc.add_paragraph(SCOPE)
    doc.add_paragraph('Este memorial apresenta as ações simultâneas, as verificações resistentes que já têm demanda '
                      'definida, os requisitos geométricos e o estado do modelo de transferência. Um resultado local '
                      'ATENDE NO ESCOPO não comprova a transferência completa e não libera fabricação ou montagem.')
    counts = []
    for category, title in (('RESISTANCE', 'Resistência'), ('GEOMETRY', 'Geometria'), ('MODEL', 'Modelo')):
        checks = [x for x in r.get('checks', []) if x.get('category') == category]
        counts.append((title, str(sum(x.get('status') == 'PASS' for x in checks)),
                       str(sum(x.get('status') == 'FAIL' for x in checks)),
                       str(sum(x.get('status') not in ('PASS', 'FAIL') for x in checks))))
    _tab(doc, ['Grupo', 'Atendem', 'Não atendem', 'Pendentes ou outros'], counts, [2.0, 1.35, 1.5, 2.22])
    doc.add_paragraph('Uma chapa física contínua fica soldada sob a mesa inferior da viga superior. Quatro parafusos '
                      'atravessam essa chapa e a mesa superior da viga inferior, em um único plano de corte. O par '
                      'de enrijecedores fica na alma da viga inferior, um de cada lado. As duas vigas são ortogonais.')
    _heading(doc, 'Ocorrências da entrada atual', 2)
    issues = r.get('issues') or []
    for issue in issues:
        ref = issue.get('reference') or issue.get('ref') or ''
        doc.add_paragraph(str(issue.get('severity', 'info')) + ': ' +
                          calculated_text(issue.get('text', ''), assignments_only=True) +
                          (' Referência: ' + str(ref) + '.' if ref else ''), style='List Bullet')
    if not issues:
        doc.add_paragraph('Nenhuma ocorrência adicional retornada pelo motor. Mantém-se a limitação de escopo acima.')
    doc.add_paragraph('Identidade da família: ' + CONNECTION_TYPE + '. Componente: ' + COMPONENT_VERSION + '. '
                      'A exportação sempre recalcula a entrada atual; resultados externos ou salvos não são aceitos '
                      'como fonte de conclusão. Não há arredondamento nos dados nativos ou no motor.')


def _loads(doc, c, r):
    _new_page(doc)
    _heading(doc, 'Ações simultâneas e transporte')
    doc.add_paragraph('Convenção deste módulo: x acompanha a viga superior, y acompanha a viga inferior e z aponta '
                      'para cima a partir da face superior da mesa inferior. V positivo é descendente; N positivo '
                      'atua em +x. A origem O é a interseção das almas no plano de contato chapa e mesa inferior.')
    doc.add_paragraph('As ações fornecidas são utilizadas simultaneamente, sem nova majoração. No caso informado, '
                      'V provém da reação do modelo global e N de 1000 kgf é uma hipótese artificial de reserva; '
                      'não é apresentado como tração medida no Robot. As observações do caso atual constam integralmente '
                      'nos dados de entrada. Os coeficientes de resistência permanecem nas equações resistentes.')
    rows = []
    for key, label, unit in (('V', 'V descendente', 'N'), ('N', 'N no eixo superior', 'N'),
                           ('applied_moment_y', 'Momento externo em y', 'N mm'),
                           ('torsion', 'Torção aplicada no plano', 'N mm'),
                           ('reference_x', 'Referência longitudinal das ações', 'mm')):
        rows.append((label, _value(getattr(c, key, None)), unit))
    for key in ('V', 'N'):
        v = getattr(c, key, None)
        rows.append((key + ' em kgf', _value(v / KGF if finite_real(v) else None), 'kgf'))
    _tab(doc, ['Ação ou referência atual', 'Valor', 'Unidade'], rows, [4.27, 1.4, 1.4])
    doc.add_paragraph('A conversão exata é 1 kgf = 9,80665 N. Valores calculados aparecem com duas casas decimais '
                      'somente para leitura; a precisão integral é preservada no projeto nativo e no cálculo.')
    _math(doc, group('F = (N; 0; −V);  r = (', sub('x', 'ref'), '; 0; ', sub('d', 'sup'), '/2 + ', sub('t', 'p'), ')'))
    _math(doc, group(sub('M', 'y,O'), ' = ', sub('M', 'y,A'), ' + N(', frac(sub('d', 'sup'), '2'),
                     ' + ', sub('t', 'p'), ') + V', sub('x', 'ref')))
    doc.add_paragraph('O termo N(dsup/2+tp) é conhecido mesmo quando a posição longitudinal do referencial '
                      'das ações não foi declarada. reference_x ausente permanece desconhecido; o termo Vxref e o momento '
                      'total não recebem zero implícito. O transporte só deve ser acrescentado uma vez, sem duplicar '
                      'um braço já representado no modelo de origem. reference_x não define o término físico da viga; '
                      'essa cota executiva permanece não especificada.')
    lm = _mapping(r.get('load_model'))
    if lm:
        shown = {key: lm[key] for key in (
            'upper_axis_height_mm', 'moment_from_N_Nmm', 'moment_from_V_Nmm',
            'moment_at_contact_Nmm', 'horizontal_bolt_shear_N') if key in lm}
        _tab(doc, ['Grandeza do modelo de ações', 'Resultado atual'], list(_flatten(shown)), [3.45, 3.62])
        external = _mapping(lm.get('external_transfer'))
        doc.add_paragraph('Equilíbrio externo conferido: ' + _value(external.get('equilibrium_checked', False)) +
                          '; equilíbrio externo válido: ' + _value(external.get('equilibrium_valid', False)) +
                          '. As declarações e demandas externas estão no registro completo de entradas.')
        residuals = {key: value for key, value in external.items() if 'residual' in key or 'tolerance' in key}
        if residuals:
            _tab(doc, ['Residual ou tolerância externa', 'Valor'], list(_flatten(residuals)), [3.45, 3.62])
    _heading(doc, 'Distribuição no plano do grupo', 2)
    _math(doc, group(sub('S', 'i'), ' = ', frac('|N|', '4'), ';  ', sub('n', 'planos'), ' = 1'))
    doc.add_paragraph('A divisão horizontal N/4 vale somente para quatro parafusos simétricos, mesma rigidez e '
                      'ausência de torção aplicada no plano da chapa. V descendente segue por contato; V/4 não é '
                      'o cortante dos parafusos verticais. Alterar o sinal de N muda o sinal do momento e as bordas '
                      'carregadas; as forças de contato nos furos da chapa e da mesa têm sentidos opostos.')
    _heading(doc, 'Transferência local fora do plano', 2)
    _math(doc, group('C − Σ', sub('T', 'i'), ' = V'))
    _math(doc, group('C', sub('x', 'c'), ' − Σ(', sub('T', 'i'), sub('x', 'i'), ') = ', sub('M', 'y,O')))
    _math(doc, group('C', sub('y', 'c'), ' − Σ(', sub('T', 'i'), sub('y', 'i'), ') = 0'))
    doc.add_paragraph('C, xc e as quatro trações totais Ti são entradas externas opcionais. Ausência significa '
                      'PENDENTE, nunca zero. As trações devem corresponder ao mesmo caso simultâneo, incluir alavanca '
                      'explicitamente declarada e identificar a origem do modelo. Conferir equilíbrio não comprova '
                      'compatibilidade, distribuição de contato ou flexão das peças.')
    doc.add_paragraph('O fechamento ainda deve determinar contato e flexão da chapa e das mesas, tração e alavanca '
                      'nos parafusos, parcela normal e momento na solda, regiões locais das almas e forças em cada '
                      'enrijecedor. Não se presume Ti=M/g, C=V ou força V/2 por enrijecedor.')


def _methods(doc):
    _heading(doc, 'Equações resistentes e fronteiras de aplicação')
    _heading(doc, 'Parafusos e furos para a parcela horizontal', 2)
    _math(doc, group(sub('A', 'b'), ' = ', frac(group('π', power(sub('d', 'b'))), '4')))
    _math(doc, group(sub('F', 'v,Rd'), ' = ', frac(group('α', sub('A', 'b'), sub('f', 'ub')), sub('γ', 'a2')), ' × ', sub('k', 'pega')))
    doc.add_paragraph('α=0,45 quando a rosca intercepta o plano de corte, ou para parafuso comum; α=0,56 somente '
                      'na condição de alta resistência com rosca excluída. A redução de pega é aplicada quando '
                      'exigida. A resistência é por parafuso e por um plano, sem duplicar a espessura ou a quantidade '
                      'de interfaces. Referência: NBR 6.3.2 e 6.3.3.2.')
    _math(doc, group(sub('F', 'c,Rd'), ' = ', frac(group('min(1,2 ', sub('l', 'f'), '; 2,4 ', sub('d', 'b'), ') t ', sub('f', 'u')), sub('γ', 'a2'))))
    doc.add_paragraph('O contato nos furos usa o ramo de deformação em serviço limitada para furos padrão. lf é '
                      'o ligamento livre real no sentido da força da peça. Cada furo da chapa e da mesa inferior '
                      'tem espessura, aço e borda próprios. A resistência de contato do furo não verifica o contato '
                      'vertical entre chapa e mesa. Referência: NBR 6.3.3.3.')
    _math(doc, group(sub('F', 't,Rd'), ' = ', frac(group('0,75 ', sub('A', 'b'), sub('f', 'ub')), sub('γ', 'a2'))))
    _math(doc, group(power(group('(', frac(sub('T', 'i'), sub('F', 't,Rd')), ')')), ' + ', power(group('(', frac(sub('S', 'i'), sub('F', 'v,Rd')), ')')), ' ≤ 1'))
    doc.add_paragraph('A interação só recebe demanda quando a tração total externa é utilizável no caso em exame. '
                      'Ti ausente não gera utilização nula. Referência: NBR 6.3.3.1, 6.3.3.4 e 6.3.5.1.')
    _heading(doc, 'Solda e metais base para a parcela horizontal', 2)
    _math(doc, group(sub('q', 'N'), ' = ', frac('|N|', sub('L', 'ef,total')), ';  ', sub('a', 'w'), ' = ', frac('w', '√2')))
    _math(doc, group(sub('q', 'w,Rd'), ' = ', frac(group('0,60 ', sub('f', 'uw'), sub('a', 'w')), sub('γ', 'a2'))))
    _math(doc, group(sub('q', 'base,Rd'), ' = min(', frac(group('0,60 ', sub('f', 'y'), ' t'), sub('γ', 'a1')), '; ',
                     frac(group('0,60 ', sub('f', 'u'), ' t'), sub('γ', 'a2')), ')'))
    doc.add_paragraph('O grupo simétrico de duas linhas recebe aqui somente a parcela horizontal centrada N. '
                      'O metal-base é verificado separadamente na chapa e na mesa inferior da viga superior. '
                      'O resultado não aprova a solda completa: as forças normais e o momento fora do plano '
                      'continuam associados à transferência local pendente. V não é integralmente atribuído à '
                      'solda ao mesmo tempo em que se presume contato integral. Referência: NBR 6.2, Tabelas 9 e 11.')
    _heading(doc, 'Geometria e detalhe do par de enrijecedores', 2)
    doc.add_paragraph('São examinados furos, passo, bordas, pega, envelope de acesso, dimensões e soldas declaradas. '
                      'Mínimos e máximos geométricos não são capacidades resistentes. O acesso depende do conjunto '
                      'real de cabeça, porca, arruela e ferramenta e não fica comprovado apenas por um diâmetro.')
    _math(doc, group(sub('b', 's'), ' + ', frac(sub('t', 'w'), '2'), ' ≥ ', frac(sub('b', 'carregada'), '3')))
    _math(doc, group(sub('t', 's'), ' ≥ max(', frac(sub('t', 'carregada'), '2'), '; ', frac(sub('b', 's'), '16'), ')'))
    doc.add_paragraph('Os limites acima são de detalhamento da NBR 5.7.9.5. A presença do par não soma resistência '
                      'automaticamente; forças, extensão requerida, contato, soldas e eventuais estados locais '
                      'dependem do modelo de transferência. Não se adicionam duas vezes faixas efetivas da alma.')
    doc.add_paragraph('A resistência mínima da ligação da NBR 6.1.5.2 requer categoria do membro e interpretação '
                      'direcional declaradas. Este módulo conserva as ações fornecidas: não inventa 45 kN '
                      'independentes em N e V nem substitui silenciosamente os esforços do usuário.')


def _checks(doc, r):
    categories = [('RESISTANCE', 'Verificações resistentes parciais'),
                  ('GEOMETRY', 'Verificações de geometria e detalhamento'),
                  ('MODEL', 'Verificações do modelo local')]
    checks = r.get('checks') or []
    for category, title in categories:
        _heading(doc, title)
        doc.add_paragraph('Categoria ' + category + '. PASS indica atendimento apenas da parcela ou requisito '
                          'desta linha; FAIL indica não atendimento; PENDING indica pendência, nunca demanda zero.')
        selected = [x for x in checks if x.get('category') == category]
        if not selected:
            doc.add_paragraph('Nenhuma verificação desta categoria foi calculada para esta entrada.')
            continue
        refs, notes = {}, {}
        def key_for(store, text, prefix):
            if not text:
                return ''
            text = str(text)
            if text not in store:
                store[text] = prefix + str(len(store) + 1)
            return store[text]
        rows = []
        for check in selected:
            ref = key_for(refs, check.get('reference') or check.get('ref'), 'R')
            note = key_for(notes, check.get('notes') or check.get('variables'), 'N')
            equation = check.get('equation') or check.get('formula')
            tags = ' '.join(x for x in (ref, note) if x)
            label = str(check.get('id', '')) + '\n' + str(check.get('name', '')) + (' [' + tags + ']' if tags else '')
            unit = str(check.get('unit', ''))
            demand = '—' if check.get('demand') is None else _value(check['demand']) + ' ' + unit
            capacity = '—' if check.get('resistance') is None else _value(check['resistance']) + ' ' + unit
            eta = check.get('eta', check.get('utilization'))
            ratio = '—' if eta is None else _value(eta)
            status = str(check.get('status', 'NOT_EVALUATED'))
            if category == 'GEOMETRY':
                rows.append((label, demand, capacity, str(equation or '—'), ratio, status))
            elif category == 'MODEL':
                rows.append((label, status))
            else:
                rows.append((label, demand, capacity, ratio, status))
        if category == 'GEOMETRY':
            doc.add_paragraph('D/L é valor dividido pelo limite, não utilização resistente. A relação define o '
                              'atendimento: mínimos ≥ podem passar com D/L acima de 1. Essas razões não são índices '
                              'de utilização resistente. — significa dado ausente ou razão não aplicável; veja o estado.')
            _tab(doc, ['Requisito', 'Valor', 'Limite', 'Regra', 'D/L', 'Estado'], rows,
                 [3.45, .78, .78, .5, .5, 1.06], size=8.5)
        elif category == 'MODEL':
            _tab(doc, ['Parcela ou condição do modelo', 'Estado'], rows, [5.65, 1.42], size=9)
        else:
            doc.add_paragraph('Demanda e resistência são expressas na mesma unidade por linha. η é o índice '
                              'resistente; — significa PENDENTE ou não calculável, nunca zero.')
            _tab(doc, ['Componente e parcela', 'Demanda', 'Resistência', 'η', 'Estado'], rows,
                 [3.3, 1.02, 1.02, .5, 1.23], size=8.5)
            _heading(doc, 'Grandezas das verificações resistentes', 2)
            bolt = next((x for x in selected if x.get('id') == 'bolt_horizontal_shear'), {})
            weld = next((x for x in selected if x.get('id') == 'weld_horizontal'), {})
            doc.add_paragraph('Parafuso: Ab=' + _value(bolt.get('area_mm2')) + ' mm²; α=' +
                              _value(bolt.get('alpha')) + '; kpega=' + _value(bolt.get('grip_factor')) +
                              '. Solda: Lef,total=' + _value(weld.get('effective_total_length_mm')) +
                              ' mm; garganta=' + _value(weld.get('throat_mm')) + ' mm.')
            hole_groups = {}
            for check in selected:
                if check.get('id', '').startswith('hole_'):
                    values = tuple(check.get(k) for k in ('clear_distance_mm', 'load_direction_x', 'thickness_mm', 'fu_MPa'))
                    hole_groups.setdefault(values, []).append(check['id'])
            if hole_groups:
                _tab(doc, ['Furos com os mesmos parâmetros', 'lf mm', 'Sentido x', 't mm', 'fu MPa'], [
                    ('; '.join(ids), *(_value(v) for v in values)) for values, ids in hole_groups.items()
                ], [3.45, .85, 1.07, .85, .85], size=8.5)
                doc.add_paragraph('O sinal x indica a força nesta peça. lf é o ligamento livre usado no furo; '
                                  'valores iguais foram agrupados, preservando os quatro furos de cada peça.')
        # A legend is local to its category. Deduplicate exact notes and sources,
        # preserving every check association without repeating paragraphs per bolt.
        if refs:
            _heading(doc, 'Referências desta categoria', 2)
            for text, key in refs.items():
                p = doc.add_paragraph(key + '  ' + text)
                for run in p.runs:
                    run.font.size = Pt(9)
        if notes:
            _heading(doc, 'Hipóteses e limites desta categoria', 2)
            for text, key in notes.items():
                p = doc.add_paragraph(key + '  ' + calculated_text(text, assignments_only=True))
                for run in p.runs:
                    run.font.size = Pt(9)
        for check in selected:
            if check.get('substitution'):
                doc.add_paragraph(str(check['id']) + ': ' + calculated_text(check['substitution']))
    unknown = [x for x in checks if x.get('category') not in {a for a, _ in categories}]
    if unknown:
        _heading(doc, 'Resultados sem categoria reconhecida', 2)
        doc.add_paragraph('Resultados sem classificação não são tratados como aprovação.')
        _tab(doc, ['ID', 'Dados retornados'], [(str(x.get('id', '')), _value(x)) for x in unknown], [1.2, 5.87])


def _inputs(doc, c, r):
    _heading(doc, 'Registro completo dos dados de entrada')
    doc.add_paragraph('Unidades nativas: N, mm, MPa e N mm. Valores ausentes são identificados como PENDENTE. '
                      'As tabelas são editáveis e exibem duas casas decimais; nomes, referências e observações '
                      'permanecem textuais. O projeto nativo preserva todos os algarismos originais.')
    if not isinstance(c, BeamOnBeam):
        doc.add_paragraph('Objeto recebido: ' + repr(c))
        return
    _heading(doc, 'Perfis ortogonais', 2)
    if is_dataclass(c.beam) and is_dataclass(c.support):
        _tab(doc, ['Campo', 'Viga superior', 'Viga inferior'], [
            (f.name, _value(getattr(c.beam, f.name)), _value(getattr(c.support, f.name)))
            for f in fields(c.beam)
        ], [1.2, 2.935, 2.935])
    else:
        doc.add_paragraph('Superior: ' + _value(c.beam) + '; inferior: ' + _value(c.support))
    doc.add_paragraph('d, bf, tw, tf e clear em mm; area em mm² e mass em kg/m. As propriedades reais do produto, '
                      'as tolerâncias, o aço e as concordâncias devem corresponder ao material adquirido.')
    _heading(doc, 'Chapa parafusos soldas enrijecedores e ações', 2)
    _tab(doc, ['Identificador', 'Grandeza', 'Valor declarado'], [
        (f.name, LABELS.get(f.name, f.name), _value(getattr(c, f.name)))
        for f in fields(c) if f.name not in ('beam', 'support')
    ], [1.7, 3.07, 2.3], size=8.5)
    _heading(doc, 'Materiais', 2)
    materials = []
    for label, key in (('Viga superior', 'beam_steel'), ('Viga inferior', 'support_steel'),
                       ('Chapa', 'plate_steel'), ('Enrijecedores', 'stiffener_steel')):
        name = getattr(c, key)
        steel = STEELS.get(name) if isinstance(name, str) else None
        materials.append((label, _value(name), _value(getattr(steel, 'fy', None)), _value(getattr(steel, 'fu', None))))
    _tab(doc, ['Peça', 'Aço', 'fy MPa', 'fu MPa'], materials, [1.55, 3.12, 1.2, 1.2])
    fub = BOLTS.get(c.bolt) if isinstance(c.bolt, str) else None
    doc.add_paragraph('fub=' + _value(fub) + ' MPa; fuw=' + _value(c.electrode_fuw) +
                      ' MPa. γa1=1,10 e γa2=1,35 para combinação normal. As resistências e espessuras de cada '
                      'peça são independentes; escolher uma classe não certifica o componente comprado.')
    geometry = _mapping(r.get('geometry'))
    if geometry:
        _heading(doc, 'Coordenadas e montagem', 2)
        shown = {key: geometry[key] for key in ('bolt_coordinates_mm', 'grip_mm', 'hardware_envelope') if key in geometry}
        _tab(doc, ['Grandeza', 'Resultado atual'], list(_flatten(shown)), [3.3, 3.77], size=8.5)
    modules = _mapping(r.get('modules'))
    if modules:
        _heading(doc, 'Estado dos módulos', 2)
        _tab(doc, ['Módulo', 'Estado'], [(key, _value(value.get('status'))) for key, value in modules.items()], [3.3, 3.77], size=8.5)
    summary = _mapping(r.get('summary'))
    if summary:
        doc.add_paragraph('Maior índice entre as verificações resistentes calculadas: ' +
                          _value(summary.get('resistance_max_utilization')) +
                          '. Ligação completa verificada: NÃO. Geometria: ' +
                          str(summary.get('geometry_status', 'PENDING')) +
                          '. Modelo local: ' + str(summary.get('model_scope_status', 'PENDING')) + '.')


def _sources(doc):
    _heading(doc, 'Alcance e referências')
    for text in EXCLUSIONS:
        doc.add_paragraph(text, style='List Bullet')
    doc.add_paragraph('Norma principal: ' + NBR + '. Parafusos e contato nos furos: 6.3.2, 6.3.3 e 6.3.5; '
                      'furos e detalhe: 6.3.9 a 6.3.12, Tabelas 14 e 16; soldas: 6.2, Tabelas 9 e 11; '
                      'enrijecedores: 5.7.9; requisitos gerais e resistência mínima: 6.1.1.3 e 6.1.5.2. '
                      'A aplicação de cada expressão está limitada à demanda e ao escopo identificados neste memorial.')
    doc.add_paragraph('O exemplo J.7 do AISC Manual Companion v16 trata estados locais da viga inferior em apoio '
                      'de viga sobre viga. Não qualifica automaticamente esta chapa intermediária com N, nem a '
                      'tração/alavanca dos quatro parafusos ou a resistência do par de enrijecedores inferior. '
                      'É referência de contexto, sem substituir as verificações NBR aqui registradas.')
    for label, url in (
        ('AISC Manual Companion for the 16th Edition', 'https://www.aisc.org/aisc/publications/steel-construction-manual/manual-companion-for-16th-edition/'),
        ('Gerdau Perfis Estruturais Segmento Industrial', 'https://gsn.gerdau.com/sites/gsn_gerdau/files/downloadable_files/Folder%20Perfis%20Estruturais%20Gerdau%20-%20Segmento%20Industrial.pdf'),
    ):
        hyperlink(doc.add_paragraph(), label, url)
    doc.add_paragraph('O catálogo fornece dimensões nominais, sem substituir a verificação de tolerâncias, '
                      'concordâncias e certificados. Envelopes de ferragens e ferramentas devem corresponder ao '
                      'conjunto realmente escolhido; uma dimensão de outro sistema não qualifica sua resistência.')
    p = doc.add_paragraph()
    p.add_run('SEM APROVAÇÃO DA LIGAÇÃO COMPLETA E SEM LIBERAÇÃO DE FABRICAÇÃO.').bold = True


def _drawing(doc, c):
    if not isinstance(c, BeamOnBeam) or input_errors(c):
        return
    from .beam_on_beam_drawing import image_bytes
    sheet = _new_page(doc, landscape=True)
    sheet.page_width, sheet.page_height = Inches(16.54), Inches(11.69)
    _heading(doc, 'Esquema da geometria atual')
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    picture = p.add_run().add_picture(BytesIO(image_bytes(c)), width=Inches(13.2))
    picture._inline.docPr.set('descr', 'Planta e cortes de duas vigas ortogonais, chapa contínua, quatro parafusos e par de enrijecedores na viga inferior.')
    doc.add_paragraph('Esquema da entrada atual. Cotas e referências desconhecidas continuam assinaladas como '
                      'pendentes. A imagem não constitui detalhamento executivo nem altera a conclusão parcial.')


def build_docx(c, result=None):
    """Return an editable DOCX as bytes; never trust caller-supplied results."""
    current = evaluate(c)
    doc = Document()
    s = doc.sections[0]
    s.page_width, s.page_height = Inches(8.27), Inches(11.69)
    s.top_margin = s.bottom_margin = s.left_margin = s.right_margin = Inches(.6)
    for name in ('Normal', 'Title', 'Heading 1', 'Heading 2', 'List Bullet'):
        style = doc.styles[name]
        style.font.name = 'Arial'
        style.font.color.rgb = RGBColor(0, 0, 0)
    for style in doc.styles:
        for border in style.element.xpath('.//w:pBdr'):
            border.getparent().remove(border)
    doc.styles['Normal'].font.size = Pt(10)
    doc.styles['Normal'].paragraph_format.space_after = Pt(5)
    doc.styles['Title'].font.size = Pt(20)
    doc.styles['Heading 1'].font.size = Pt(14)
    doc.styles['Heading 2'].font.size = Pt(11)
    for name in ('Heading 1', 'Heading 2'):
        doc.styles[name].paragraph_format.keep_with_next = True
    doc.core_properties.title = 'Viga sobre viga com chapa contínua de apoio'
    doc.core_properties.subject = 'Verificações locais parciais com transferência fora do plano pendente'
    doc.core_properties.author = 'LRO Soluções de engenharia LTDA.'
    _intro(doc, c, current)
    _loads(doc, c, current)
    _methods(doc)
    _checks(doc, current)
    _inputs(doc, c, current)
    _sources(doc)
    _drawing(doc, c)
    footer = doc.sections[0].footer.paragraphs[0]
    footer.add_run(BRAND + '  |  Verificações parciais  |  Página ')
    field = OxmlElement('w:fldSimple')
    field.set(qn('w:instr'), 'PAGE')
    footer._p.append(field)
    for run in footer.runs:
        run.font.size = Pt(7)
    stream = BytesIO()
    doc.save(stream)
    return stream.getvalue()


# Match the older families without introducing a second export implementation.
create_report = build_docx
