"""Conventional direct-bearing adapter. EN, NBR and ACI factors stay separate.

No existing welded-washer predicate or capacity is reused. The three EN/DG1
states are alternative complete checks, not simultaneous external actions.
"""
from dataclasses import replace
import math
from .models import Issue, STEELS
from .direct_anchor_shear import evaluate_direct_anchor_shear

REF='EN 1993-1-8:2005 corrigida, 6.2.2 / Table 3.4; método complementar'


def add_direct_checks(c,r,add):
    from .concrete_anchorage import anchor_tensions
    rods=anchor_tensions(c,r.geometry)
    out=evaluate_direct_anchor_shear(c.direct_shear,rods=rods,L=c.L,B=c.B,tp=c.tp,
        plate_fu=STEELS[c.plate_steel].fu,db=c.db,V=c.V,grout_t=c.grout_t,
        grout_fck=c.grout_fck,fck=c.fck)
    r.geometry['direct_anchor_shear']=out
    r.geometry['friction_credited']=0.
    r.geometry['washer_lateral_credited']=0.
    # A lower component envelope, never a capacity of the whole foundation.
    capacities=[]
    for idx,ck in enumerate(out.get('checks',[])):
        add('direct_detail_'+str(idx),ck['label'],ck['demand'],ck['resistance'],ck.get('unit','mm'),
            ck.get('reference',REF),'Geometria real ≥ mínimo EN',f"Sd={ck['demand']:.9g}; Rd={ck['resistance']:.9g}",'Sem converter dimensões ou reduzir o furo automaticamente.')
    for state in out.get('states',[]):
        for idx,ck in enumerate(state.get('checks',[])):
            sd=ck.get('demand');rd=ck.get('resistance')
            if type(sd) not in (int,float) or type(rd) not in (int,float):continue
            if not math.isfinite(sd) or not math.isfinite(rd) or rd<0:continue
            cid=ck.get('id','')
            equation=('Ti ≤ TRd = kthread·0,9·fu·As/γM2' if '_tension_' in cid else
                'Qi ≤ VRd = min(F1,Rd; F2,Rd)' if '_shear_' in cid else
                'Qi ≤ Fb,Rd = k1·αb·fu,placa·d·t/γM2' if '_bearing_' in cid else
                'Qi/VRd + Ti/(1,4·TRd) ≤ 1' if '_interaction_' in cid else
                'ΣQi,linha ≤ n·min(Rd,i condicionada à Ti)' if '_row_' in cid else 'Sd ≤ Rd')
            add('direct_'+state['id']+'_'+str(idx),
                state['id']+' — '+ck.get('label',ck.get('id','Componente direto')),sd,rd,ck.get('unit','N'),
                ck.get('reference',REF),equation,
                f'Sd={sd:.9g}; Rd={rd:.9g}',
                'Estado alternativo; Ti real concomitante. γM2=1,25 somente EN. Atrito e contribuição lateral da arruela iguais a zero.')
        if state.get('row_capacities'):capacities.append(sum(row['resistance_N'] for row in state['row_capacities']))
    r.geometry['shear_rd']=min(capacities,default=0.)
    reasons=[]
    for key in ('domain','service_scope'):
        reasons.extend(out.get(key,{}).get('reasons',[]))
    reasons.extend(out.get('reasons',[]))
    for reason in dict.fromkeys(reasons):
        r.issues.append(Issue('pending',str(reason),REF,origin='direct_anchor_shear'))
    if c.stiffener_detail!='none':
        r.issues.append(Issue('pending','A rota convencional sem nervuras não qualifica o caminho in-plane de uma base nervurada. Use a composição específica N+M+V quando aplicável.',REF,origin='direct_anchor_shear'))
    return out


def add_direct_concrete_checks(c,r,add):
    """Each conventional state receives the entire original Ti vector and V.

    ACI's own real-edge alternatives are retained within each state. These
    comparisons do not create a new EN load state or change the EN sharing.
    """
    from .concrete_components import add_component_checks,distribution_signature
    direct=r.geometry.get('direct_anchor_shear',{})
    states=direct.get('states',[])
    if c.concrete_components.model=='off':
        reason='Contato direto: selecione e complete os modos ACI aplicáveis; a resistência EN da haste/chapa não aprova a ancoragem.'
        r.issues.append(Issue('pending',reason,REF,origin='direct_anchor_shear'))
        return dict(status='pending',complete=False,modes={},states=[],reasons=[reason])
    if not states:
        reason='Vetor convencional direto indisponível: domínio/entradas precisam ser corrigidos antes da ancoragem ACI.'
        r.issues.append(Issue('pending',reason,REF,origin='direct_anchor_shear'))
        return dict(status='pending',complete=False,modes={},states=[],reasons=[reason])
    records=[];allchecks=[];issues=[];invalid_areas=False
    for state in states:
        forces=state['forces']
        u=c.concrete_components
        # The EN supplied real thread area is also the actual threaded ACI
        # section unless an independently documented smaller section is given.
        area_n=u.area_tension if u.area_tension>0 else c.direct_shear.thread_area
        area_v=u.area_shear if u.area_shear>0 else c.direct_shear.thread_area
        if max(area_n,area_v)>c.direct_shear.thread_area+1e-8:
            invalid_areas=True
            reason='As efetiva ACI não pode superar a seção rosqueada real declarada no contato direto.'
            issues.append(Issue('pending',reason,REF,origin='direct_anchor_shear'))
        u=replace(u,distribution_ref=state['id']+'; EN 3.12 + DG1 e envelope conservador versionado',
            distribution_confirmation='',parallel_model='virtual_perpendicular',
            area_tension=area_n,area_shear=area_v,
            steel_area_ref=u.steel_area_ref or c.direct_shear.thread_reference,
            **{f'force_a{i}':forces.get(f'A{i}',0.) for i in range(1,5)})
        cs=replace(c,concrete_components=u)
        cs=replace(cs,concrete_components=replace(u,distribution_confirmation=distribution_signature(cs)))
        rs=type(r)(geometry=dict(r.geometry))
        def scoped_add(key,*args):
            add('direct_aci_'+state['id']+'_'+key,*args)
        record=add_component_checks(cs,rs,scoped_add,_direct_state=True)
        record['direct_state_id']=state['id'];record['forces']=dict(forces)
        record['material']=dict(name=c.anchor_material_name,fy=c.anchor_fy,fu=c.anchor_fu,
            area_tension=area_n,area_shear=area_v)
        records.append(record)
        issues.extend(rs.issues)
    # Keep the full record for each state; expose the governing existing shape
    # as a summary so legacy reports remain usable without dropping details.
    def ratio(record):return record.get('modes',{}).get('interaction',{}).get('ratio',0.)
    summary=dict(max(records,key=ratio))
    interactions=[x.get('modes',{}).get('interaction',{}) for x in records]
    complete=not invalid_areas and all(x.get('passes') is not None for x in interactions)
    passes=all(x.get('passes') is True for x in interactions) if complete else None
    summary.update(states=records,complete=complete,passes=passes,
        status='pass' if passes is True else 'fail' if passes is False else 'pending',
        source='ACI 318-19 separado, fatores próprios; todos os estados EN/DG1 alternativos')
    seen=set()
    for issue in issues:
        key=(issue.severity,issue.text,issue.origin)
        if key not in seen:r.issues.append(issue);seen.add(key)
    return summary


def finalize_direct_route(c,r,add):
    from .direct_plate_transfer import evaluate_family_plate
    from .direct_anchor_shear import PLATE_NOTE
    out=r.geometry.get('direct_anchor_shear',{})
    aci=r.concrete_components
    out['aci_components']=dict(status=aci.get('status','pending'),complete=aci.get('complete',False),
        passes=aci.get('passes'),states=aci.get('states',[]))
    local=evaluate_family_plate(c,r)
    for ck in local['checks']:
        add('direct_plate_'+ck['id'],ck['label'],ck['demand'],ck['resistance'],ck.get('unit','N'),ck['reference'],
            'Sd ≤ Rd do componente identificado',f"Sd={ck['demand']:.10g}; Rd={ck['resistance']:.10g}",
            'Limite suficiente conservador; exceder não prova isoladamente ruptura da placa real.' if ck.get('sufficient_bound') else 'Comprimentos e espessuras reais; dois filetes não duplicam a placa.')
    local_complete=local['complete']
    out['local_transfer_scope']=local
    if local_complete:
        # A calculated consumer supersedes the dormant documentary checkbox,
        # not the independent domain/service/material requirements.
        out['documentary_plate_record']=out.get('plate_transfer_scope',{})
        out['plate_transfer_scope']=dict(status=local['status'],complete=True,passes=local['passes'],
            independently_calculated=True,reference=local.get('panel',{}).get('reference',''),reasons=[])
        for key in ('reasons','pending_reasons'):
            out[key]=[s for s in out.get(key,[]) if s!=PLATE_NOTE]
        r.issues[:]=[i for i in r.issues if not (i.origin=='direct_anchor_shear' and i.text==PLATE_NOTE)]
        out['valid']=bool(out.get('domain',{}).get('eligible') and out.get('steel_plate_uls',{}).get('passes')
                          and out.get('service_scope',{}).get('passes') and local['passes'])
    for reason in out['local_transfer_scope']['reasons']:
        r.issues.append(Issue('pending',reason,REF,origin='direct_anchor_shear'))
    axial_pending=any(a.get('tension',0)>0 for s in out.get('states',[]) for a in s.get('rods',[])) and r.local_upper_washer.get('status')!='pass'
    if axial_pending:
        reason='Arruela/porca superior com tração: transferência axial local não calculada nesta composição simples. Sem crédito lateral; manter verificação axial independente.'
        r.issues.append(Issue('pending',reason,REF,origin='direct_anchor_axial'))
    out['normal_and_axial_scope']=dict(status='pending' if axial_pending else 'calculated_checks_retained',
        axial_washer_complete=not axial_pending,normal_checks_retained=True,
        reason='A solução N/M e as interações específicas da mesma combinação são mantidas; não se cria uma interação própria da chapa.')
    out['direct_route_resistance_pass']=bool(out.get('valid') and aci.get('passes') is True and local_complete
        and local.get('passes') and not axial_pending and all(x.passed for x in r.checks)
        and not any(i.severity in ('error','noncompliance') for i in r.issues))
    out['calculation_coverage_complete']=bool(out.get('domain',{}).get('eligible') and local_complete
        and aci.get('complete') and not axial_pending and out.get('service_scope',{}).get('passes'))
    if local_complete:
        for issue in r.issues:
            if issue.origin=='column_weld_scope':
                issue.severity='info'
                issue.text=('Soldas e seções locais do pilar conservadas; metal-base receptor da placa e componente de V '
                            'calculados separadamente na composição nominal delimitada. Memória vinculada é declaração de aplicabilidade, '
                            'não validação automática do seu conteúdo. Rigidez rotacional e fundação permanecem fora do escopo.')
            if aci.get('complete') and (issue.origin=='concrete_components_scope' or issue.text.startswith('Cone de tração ACI 318-19/DG1:')):
                issue.severity='info'
                issue.text=('Ancoragem ACI calculada por estados e modos aplicáveis na composição direta; consultar cada resultado. '
                            'Bloco armado, fendilhamento/detalhamento global e fundação não são dimensionados por este componente.')
    out['foundation_scope']=dict(status='not_designed',complete=False,
        reason='Bloco armado, fendilhamento/detalhamento global e fundação não são dimensionados por este componente.')
    return out


def validate_direct_data(c):
    """Reject malformed nested values before unrelated family arithmetic."""
    from dataclasses import fields
    from .direct_anchor_shear import DirectAnchorShear
    from .models import finite_real
    u=c.direct_shear
    if not isinstance(u,DirectAnchorShear):
        return [Issue('error','Dados do contato direto inválidos.',REF)]
    errors=[]
    for f in fields(u):
        default=getattr(DirectAnchorShear(),f.name);value=getattr(u,f.name)
        valid=(type(value) is bool if type(default) is bool else
               finite_real(value) if type(default) in (float,int) else isinstance(value,str))
        if not valid:errors.append(Issue('error','Contato direto: tipo inválido em '+f.name+'.',REF))
    return errors
