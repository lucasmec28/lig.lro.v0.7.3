"""Opposed two-row geometry, finite block families and nominal section envelopes.

No reference outputs are imported. Circular-cap stationary points are solved for
both block branches. Section searches split all hole/corner topology intervals,
enumerate every crossing-force mask, retain endpoints and subdivided extrema.
The searches are reproducible numerical envelopes, not interval certificates.
"""
from __future__ import annotations
import itertools
import math
from .bolted_gusset_geometry import (point, ray_exit, transverse_chord,
    section_properties, subtract_intervals, golden_extreme)


def _half_chord(u, center, radius):
    return math.sqrt(max(0., radius*radius-(u-center)**2)) if abs(u-center) <= radius else 0.


def _deduction(start, end, stations, radius):
    return sum(max(0., min(end, u+radius)-max(start, u-radius)) for u in stations)


def _holes(g):
    return [dict(index=ri*len(g['bolt_stations'])+j, id=f'{ri}:{j}', row=ri, u=u, v=v,
        xy=g['bolt_centers'][ri*len(g['bolt_stations'])+j])
        for ri, v in enumerate(g['row_v']) for j, u in enumerate(g['bolt_stations'])]


def _bounds(c, g):
    radius = g['net_hole_diameter']/2
    stations = g['bolt_stations']; C, S = g['direction']
    low, high = stations[0]-radius, stations[-1]+radius
    corners = [(x-c.center_s)*C+(y-c.center_n)*S for x, y in g['polygon']]
    return sorted(set([u+offset for u in stations for offset in (-radius, 0., radius)]+
        [u for u in corners if low < u < high]))


def _root_contact(c, g, u, vlo, vhi):
    """Actual retained root segment inside {U>=u, vlo<=V<=vhi}."""
    C, S = g['direction']; lo, hi = -c.plate_width/2, c.plate_width/2
    # Linear inequality C*s >= u+C*s0+S*n0.
    rhs = u+C*c.center_s+S*c.center_n
    if C > 1e-13:
        lo = max(lo, rhs/C)
    elif C < -1e-13:
        hi = min(hi, rhs/C)
    elif rhs > 1e-9:
        return 0.
    if math.isfinite(vlo):
        lo = max(lo, c.center_s+(vlo-C*c.center_n)/S)
    if math.isfinite(vhi):
        hi = min(hi, c.center_s+(vhi-C*c.center_n)/S)
    return max(0., hi-lo)


def _block(id, component, Agv, Anv, Ant, demand, material, coordinates, **detail):
    if Agv <= 0 or Anv <= 0 or Ant < -1e-7:
        raise ValueError('Nonpositive net ligament in opposed path '+id)
    Ant = max(0., Ant)
    ry = (.6*material.fy*Agv+.5*material.fu*Ant)/1.35
    rr = (.6*material.fu*Anv+.5*material.fu*Ant)/1.35
    return dict(id=id, name=id, component=component, Agv=Agv, Anv=Anv, Ant=Ant,
        Cts=.5, R_yield=ry, R_rupture=rr, R=min(ry, rr), resistance=min(ry, rr),
        demand=demand, utilization=demand/min(ry, rr), path=coordinates, coordinates=coordinates,
        active=True, reference='NBR6.5.6; ambas parcelas/gamma_a2; Cts0.5', **detail)


def rupture_paths(c, g, N, angle, gusset):
    """Outer/inward L, common U and each L's two genuine free-toe alternatives."""
    stations = g['bolt_stations']; r = g['net_hole_diameter']/2
    rows = g['row_v']; holes = _holes(g); F = N/(2*c.n); t = c.plate_t
    ends = [row['forward_exit']['u'] for row in g['bolt_rows']]
    bounds = _bounds(c, g); paths, inactive = [], []
    families = [dict(id=f'L{ri}_{sign}', kind='L', row=ri, sign=sign,
        lo=-math.inf if sign < 0 else rows[ri], hi=rows[ri] if sign < 0 else math.inf,
        inward=(ri == 0 and sign > 0) or (ri == 1 and sign < 0))
        for ri in (0, 1) for sign in (-1, 1)]
    families.append(dict(id='U_both', kind='U', lo=rows[0], hi=rows[1], inward=False))
    C, S = g['direction']

    def cap(u, fam, ids=None, event='finite_cap'):
        contact = _root_contact(c, g, u, fam['lo'], fam['hi'])
        if contact > 1e-8:
            return dict(active=False, id=f"{fam['id']}@{u:.12g}", family_id=fam['id'],
                component='gusset', u=u, root_contact_length=contact,
                reason='Positive supported-root segment remains attached; not a free block.')
        if fam['kind'] == 'L':
            ri, sign = fam['row'], fam['sign']; v = rows[ri]
            exit_ = ray_exit(c, point(c, u, v), [sign*S, -sign*C])
            vend = v+sign*exit_['distance']; low, high = sorted([v, vend])
            deduction = sum(max(0., min(high, h['v']+_half_chord(u, h['u'], r))-
                max(low, h['v']-_half_chord(u, h['u'], r))) for h in holes)
            av = (ends[ri]-u)*t
            anv = (ends[ri]-u-_deduction(u, ends[ri], stations, r))*t
            ant = (exit_['distance']-deduction)*t
            coords = [point(c, ends[ri], v), point(c, u, v), exit_['point']]
            free = [g['bolt_rows'][ri]['forward_exit']['edge'], exit_['edge']]
        else:
            deduction = sum(max(0., min(rows[1], h['v']+_half_chord(u, h['u'], r))-
                max(rows[0], h['v']-_half_chord(u, h['u'], r))) for h in holes)
            av = sum(end-u for end in ends)*t
            anv = sum(end-u-_deduction(u, end, stations, r) for end in ends)*t
            ant = (rows[1]-rows[0]-deduction)*t
            coords = [point(c, ends[0], rows[0]), point(c, u, rows[0]),
                point(c, u, rows[1]), point(c, ends[1], rows[1])]
            free = [row['forward_exit']['edge'] for row in g['bolt_rows']]
        included = [h['id'] for h in holes if fam['lo']-1e-9 <= h['v'] <= fam['hi']+1e-9 and h['u']+r >= u-1e-8]
        excluded = [h['id'] for h in holes if fam['lo']-1e-9 <= h['v'] <= fam['hi']+1e-9 and h['u']-r > u+1e-8]
        captured = included if ids is None else ids
        if not captured:
            return None
        return _block(f"G-{fam['id']}-{event}@{u:.12g}", 'gusset', av, anv, ant,
            len(captured)*F, gusset, coords, family_id=fam['id'], kind=fam['kind'],
            row=fam.get('row'), inward=fam['inward'], u=u, event=event,
            captured_ids=captured, captured_bolts=captured, including_crossing=included,
            excluding_crossing=excluded, crossing_bolts=[i for i in included if i not in excluded],
            captured_bolt_limits=dict(including_crossing=included, excluding_crossing=excluded),
            demand_limits=dict(including_crossing=len(included)*F, excluding_crossing=len(excluded)*F),
            root_contact_length=contact, free_exit_edges=free,
            tension_hole_deduction_length=deduction, shear_legs=2 if fam['kind'] == 'U' else 1,
            transverse_half_chord_multiplier=2 if fam['kind'] == 'U' else 3 if fam['inward'] else 1,
            force_direction='+u', load_basis='actual_captured_distinct_bolts', alternative_path=True)

    for fam in families:
        for u in stations:
            p = cap(u, fam, event='bolt_center')
            if p:
                (paths if p['active'] else inactive).append(p)
        for low, high in zip(bounds, bounds[1:]):
            mid = (low+high)/2
            ids = [h['id'] for h in holes if fam['lo']-1e-9 <= h['v'] <= fam['hi']+1e-9 and h['u']+r > mid]
            if not ids:
                continue
            candidates = [(low, 'interval_left'), (high, 'interval_right')]
            crossed = [u for u in stations if abs(mid-u) < r]
            if crossed:
                uc = crossed[0]
                if fam['kind'] == 'U':
                    slope, legs, mult = 0., 2, 2
                else:
                    sign, ri = fam['sign'], fam['row']
                    edge = ray_exit(c, point(c, mid, rows[ri]), [sign*S, -sign*C])['edge']
                    slope = -C/(sign*S) if edge in ('left', 'right') else S/(sign*C)
                    legs, mult = 1, 3 if fam['inward'] else 1
                for branch, k in [('rupture', -slope/mult), ('yield', (1.2*gusset.fy*legs/gusset.fu-slope)/mult)]:
                    u = uc+r*k/math.hypot(1., k)
                    if low < u < high:
                        candidates.append((u, 'stationary_'+branch))
            for u, event in candidates:
                p = cap(u, fam, ids, event)
                if p:
                    p['interval'] = [low, high]
                    (paths if p['active'] else inactive).append(p)

    A = g['angle_section']; ta = A['t']; end = g['angle_free_end_u']
    # Same dimensioned angle path on each opposed face; never a free heel edge.
    for side, gross in [('connected_toe', (A['leg']-c.gauge)*ta),
                        ('opposite_toe_area_complement', A['Ag']-(A['leg']-c.gauge)*ta)]:
        for low, high in zip(bounds, bounds[1:]):
            mid = (low+high)/2
            captured = [j for j, u in enumerate(stations) if u-r < mid]
            if not captured:
                continue
            candidates = [(low, 'interval_left'), (high, 'interval_right')]
            for uc in stations:
                if abs(mid-uc) < r:
                    k = -1.2*angle.fy/angle.fu
                    critical = uc+r*k/math.hypot(1., k)
                    if low < critical < high:
                        candidates.append((critical, 'stationary_yield'))
                    if low < uc < high:
                        candidates.append((uc, 'stationary_rupture'))
            for u, event in candidates:
                av = (u-end)*ta
                anv = (u-end-_deduction(end, u, stations, r))*ta
                ant = gross-sum(_half_chord(u, uc, r) for uc in stations)*ta
                path3 = []
                for ri, v in enumerate(rows):
                    sign = -1 if ri == 0 else 1; z = sign*(c.plate_t/2+ta/2)
                    path = [[*point(c, end, v), z], [*point(c, u, v), z]]
                    if side == 'connected_toe':
                        path.append([*point(c, u, v+sign*(A['leg']-c.gauge)), z])
                    else:
                        heel = point(c, u, v-sign*(c.gauge-ta/2))
                        path.extend([[*heel, z], [*heel, sign*(c.plate_t/2+A['leg'])]])
                    path3.append(path)
                p = _block(f'A-{side}-{event}@{u:.12g}', 'angle', av, anv, ant,
                    len(captured)*F, angle, [x[:2] for x in path3[1]],
                    family_id='A_'+side, side=side, u=u, k=len(captured), event=event,
                    interval=[low, high], copies=2, nominal_path_3d_each_angle=path3,
                    captured_bolts=[j+1 for j in captured], heel_is_free_edge=False,
                    area_complement_nominal=side != 'connected_toe', force_direction='-u',
                    load_basis='actual_prefix_on_each_angle_N_over_2', alternative_path=True)
                paths.append(p)
    return paths, inactive


def partial_bounds(c, g, N, material):
    """Correlated cap/remaining-hole/captured-load bound; zero joining credit."""
    r = g['net_hole_diameter']/2; C, S = g['direction']; stations = g['bolt_stations']
    result = []
    for ri, v in enumerate(g['row_v']):
        # A rectangle's forward exit is the minimum of affine edge functions.
        # It is concave in v, so its footprint minimum occurs at an endpoint.
        exits = [stations[0]+ray_exit(c, point(c, stations[0], vv), [C, S])['distance'] for vv in (v-r, v+r)]
        end = min(exits)
        for j, uj in enumerate(stations):
            start, k = uj+r, c.n-j
            length = end-start; deduction = _deduction(start, end, stations, r)
            result.append(_block(f'G-partial-row{ri}-suffix{j}', 'gusset', length*c.plate_t,
                (length-deduction)*c.plate_t, 0., k*N/(2*c.n), material,
                [point(c, start, v), point(c, end, v)], row=ri, start=start, u=start, k=k,
                end_min=end, Lmin=length, netmin=length-deduction, footprint_v=[v-r, v+r],
                remaining_hole_deduction=deduction, captured_ids=[f'{ri}:{jj}' for jj in range(j, c.n)],
                load_basis='actual_captured_suffix_N_k_over_2n',
                classification='supplemental_correlated_occupied_leg_bound',
                scope='straight_shear_legs_within_occupied_hole_footprint',
                failure_meaning='Failure of conservative method envelope, not proven physical block collapse'))
    return result


def zigzag_chains(c, g, N, fu):
    rows = g['row_v']; C, S = g['direction']; dn = g['net_hole_diameter']; results = []
    for il, ul in enumerate(g['bolt_stations']):
        for ir, ur in enumerate(g['bolt_stations']):
            left = ray_exit(c, point(c, ul, rows[0]), [-S, C])
            right = ray_exit(c, point(c, ur, rows[1]), [S, -C])
            gross = left['distance']+rows[1]-rows[0]+right['distance']
            credit = (ur-ul)**2/(4*(rows[1]-rows[0])); net = gross-2*dn+credit
            if net <= 0:
                raise ValueError('Nonpositive two-row zigzag net area.')
            ids = [f'{ri}:{j}' for ri, first in enumerate((il, ir)) for j in range(first, c.n)]
            demand, R = len(ids)*N/(2*c.n), net*c.plate_t*fu/1.35
            results.append(dict(id=f'G-zigzag-{il}-{ir}', u_left=ul, u_right=ur,
                gross_width=gross, hole_deduction=2*dn, stagger_credit=credit, net_width=net,
                An=net*c.plate_t, R=R, resistance=R, captured_ids=ids, D=demand,
                actual_captured_utilization=demand/R, conservative_full_N_utilization=N/R,
                path=[left['point'], point(c, ul, rows[0]), point(c, ur, rows[1]), right['point']],
                endpoint_edges=[left['edge'], right['edge']],
                classification='NBR5.2.4.1_two_row_zigzag_plus_conservative_full_N_screen'))
    return results


def _extrema(cut, low, high, metrics):
    # Separate short brackets prevent treating an entire multi-modal topology
    # interval as unimodal; endpoints are retained explicitly.
    cache = {}
    def at(x):
        if x not in cache:
            cache[x] = cut(x)
        return cache[x]
    grid = [low+(high-low)*j/8 for j in range(9)]
    candidates = set(grid)
    for key, maximize in metrics:
        for a, b in zip(grid, grid[1:]):
            candidates.add(golden_extreme(lambda x: at(x)[key], a, b, maximize))
    values = [at(x) for x in candidates]
    return {key: (max if maximize else min)(values, key=lambda z:z[key]) for key, maximize in metrics}


def horizontal_sections(c, g, N, fy, fu):
    holes = g['bolt_centers']; r = g['net_hole_diameter']/2
    C, S = g['direction']; B, t = c.plate_width, c.plate_t; F = N/len(holes)
    bounds = sorted(set([0., c.plate_height]+[max(0., min(c.plate_height, y+d)) for _, y in holes for d in (-r, 0., r)]))
    records = []
    for low, high in zip(bounds, bounds[1:]):
        if high-low <= 1e-12:
            continue
        mid = (low+high)/2
        fixed = [j for j, (_, y) in enumerate(holes) if y-r > mid]
        crossing = [j for j, (_, y) in enumerate(holes) if abs(y-mid) < r]
        for mask in itertools.product((0, 1), repeat=len(crossing)):
            active = fixed+[j for j, on in zip(crossing, mask) if on]
            def cut(y):
                removed = [[x-_half_chord(y, yh, r), x+_half_chord(y, yh, r)] for x, yh in holes if abs(y-yh) <= r]
                segments = subtract_intervals(-B/2, B/2, removed)
                area, cg, inertia = section_properties(segments, t)
                nr, vr = F*len(active)*S, F*len(active)*C
                moment = F*sum((holes[j][0]-cg)*S-(holes[j][1]-y)*C for j in active)
                sigma = [nr/area+moment*(x-cg)/inertia for x in (-B/2, B/2)]
                tau = 1.5*abs(vr)/area; maximum = max(map(abs, sigma))
                vm = math.hypot(maximum, math.sqrt(3)*tau)
                return dict(y=y, A=area, centroid_s=cg, I=inertia, N=nr, V=vr, M=moment,
                    active_bolts=[j+1 for j in active], active=[int(j in active) for j in range(len(holes))],
                    net_segments=segments, removed_chords=removed, sigma_edges=sigma,
                    tau_envelope=tau, sigma_min=min(sigma), sigma_max=maximum, VM=vm,
                    utilization_yield=vm/(fy/1.10), utilization_rupture=max(maximum/(fu/1.35), tau/(.6*fu/1.35)))
            witnesses = _extrema(cut, low, high, [('sigma_min', False), ('VM', True), ('utilization_rupture', True)])
            records.append(dict(interval=[low, high], crossing_bolts=[j+1 for j in crossing],
                active=[int(j in active) for j in range(len(holes))], force_mask=list(mask),
                min_sigma=witnesses['sigma_min'], max_VM=witnesses['VM'], max_rupture=witnesses['utilization_rupture']))
    return dict(model='Supplemental nominal all-mask beam-section envelope, not exact contact/continuum stresses',
        extrema_method='All hole events; endpoints; eight sub-brackets and bounded scalar extrema, not interval-certified',
        force_limit_proof='Every simultaneous crossing-hole subset is explicitly enumerated at its own row position',
        sign_classification='Informative in introduction zone; unperforated ligament tested separately',
        bounds=bounds, intervals=records, min_sigma=min(r['min_sigma']['sigma_min'] for r in records),
        max_VM=max(r['max_VM']['VM'] for r in records),
        utilization_yield=max(r['max_VM']['utilization_yield'] for r in records),
        utilization_rupture=max(r['max_rupture']['utilization_rupture'] for r in records))


def force_normal_sections(c, g, N, fy, fu):
    holes = _holes(g); r = g['net_hole_diameter']/2; F = N/len(holes); records = []
    bounds = _bounds(c, g)
    for low, high in zip(bounds, bounds[1:]):
        mid = (low+high)/2
        fixed = [h for h in holes if h['u']-r > mid]
        crossing = [h for h in holes if abs(h['u']-mid) < r]
        for mask in itertools.product((0, 1), repeat=len(crossing)):
            active = fixed+[h for h, on in zip(crossing, mask) if on]
            def cut(u):
                chord = transverse_chord(c, u)
                vl, vr = -chord['left']['distance'], chord['right']['distance']
                removed = [[h['v']-_half_chord(u, h['u'], r), h['v']+_half_chord(u, h['u'], r)] for h in holes if abs(u-h['u']) <= r]
                segments = subtract_intervals(vl, vr, removed)
                area, cg, inertia = section_properties(segments, c.plate_t)
                D, M = F*len(active), F*sum(h['v']-cg for h in active)
                sigma = [D/area+M*(v-cg)/inertia for v in (vl, vr)]
                maximum = max(map(abs, sigma))
                return dict(u=u, width=vr-vl, net_area=area, net_centroid_v=cg, I=inertia,
                    demand_envelope=D, moment_about_net_centroid=M, sigma_edges=sigma,
                    min_sigma=min(sigma), max_sigma=maximum, active_ids=[h['id'] for h in active],
                    endpoints=[chord['left']['point'], chord['right']['point']],
                    endpoint_edges=[chord['left']['edge'], chord['right']['edge']], net_segments=segments,
                    yield_utilization=maximum/(fy/1.10), rupture_utilization=maximum/(fu/1.35),
                    purpose='Supplemental nominal two-row net-section envelope; negative introduction sign is diagnostic')
            witnesses = _extrema(cut, low, high, [('min_sigma', False), ('max_sigma', True)])
            for metric, witness in witnesses.items():
                records.append(dict(witness, interval=[low, high], metric=metric,
                    crossing_ids=[h['id'] for h in crossing], force_mask=list(mask)))
    return records


def solid_ligament(c, g, N):
    """Physical hole boundary, not increased normative net deduction."""
    C, S = g['direction']; B, t = c.plate_width, c.plate_t
    end = min(y-g['hole_diameter']/2 for x, y in g['bolt_centers'])
    nr, vr = N*S, N*C
    mr = sum(N/len(g['bolt_centers'])*(x*S-y*C) for x, y in g['bolt_centers'])
    area, inertia = B*t, t*B**3/12
    cuts = []
    for y in (0., end):
        moment = mr+y*vr
        sigma = [nr/area+moment*x/inertia for x in (-B/2, B/2)]
        tau = 1.5*abs(vr)/area
        cuts.append(dict(y=y, N=nr, V=vr, M=moment, A=area, I=inertia,
            sigma=sigma, sigma_edges=sigma, min_sigma=min(sigma),
            VM=math.hypot(max(map(abs, sigma)), math.sqrt(3)*tau)))
    tolerance = 1e-10*max(1., abs(N)/(B*t))
    minimum = min(z['min_sigma'] for z in cuts)
    return dict(end=end, cuts=cuts, min_sigma=minimum, max_VM=max(z['VM'] for z in cuts),
        tensile=minimum >= -tolerance, physical_hole_diameter=g['hole_diameter'],
        proof='All bolt loads above physical hole boundary; edge stresses affine in y, bounded by endpoints',
        classification='mandatory_unperforated_ligament_and_root_tension_domain')
