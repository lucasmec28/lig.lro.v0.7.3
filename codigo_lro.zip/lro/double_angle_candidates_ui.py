"""Optional R016 proposals. Only explicit apply/restore changes native inputs.

Search and preview own da_suggest_* state. Apply validates the complete original
project AND the current native widget snapshot before calling the native seed.
No evaluator, drawing, export schema or catalog geometry is replaced here.
"""
from copy import deepcopy
import json

import streamlit as st

from .double_angle import DoubleAngle, FAMILY
from .double_angle_candidates import search, project_digest, validated_proposal
from .display_precision import display_format

PREFIX = 'da_suggest_'
FIELD_LABELS = {
    'db': 'Diâmetro do parafuso (mm)', 'hole_diameter': 'Diâmetro físico do furo (mm)',
    'web_rows': 'Parafusos verticais na alma', 'support_rows': 'Parafusos por cantoneira no apoio',
    'length': 'Comprimento da cantoneira (mm)', 'web_pitch': 'Passo na alma (mm)',
    'support_pitch': 'Passo no apoio (mm)', 'web_end_top': 'Borda superior na alma (mm)',
    'support_end_top': 'Borda superior no apoio (mm)',
    'support_edge_top': 'Primeiro furo até a extremidade superior real do pilar (mm)',
    'support_edge_bottom': 'Último furo até a extremidade inferior real do pilar (mm)',
}


def native_snapshot(state):
    from .double_angle_ui import _draft_keys
    return {key: deepcopy(state[key]) for key in _draft_keys() if key in state}


def _encoded(project):
    return json.dumps(project, ensure_ascii=False, indent=2, allow_nan=False)


def _clear_search(state):
    for name in ('result', 'snapshot', 'choice', 'selected_id'):
        state.pop(PREFIX + name, None)


def choice_changed():
    st.session_state[PREFIX + 'selected_id'] = st.session_state.get(PREFIX + 'choice')


def _current_base(state):
    if state.get('connection_family') != FAMILY:
        raise ValueError('Abra a família R016 antes de aplicar uma sugestão.')
    result = state.get(PREFIX + 'result')
    if not isinstance(result, dict) or result.get('status') != 'CANDIDATES_FOUND':
        raise ValueError('Faça uma nova busca a partir do projeto atual.')
    base = DoubleAngle.from_dict(result['base_project'])
    if (project_digest(base) != result['base_digest']
            or project_digest(state.get('_double_angle_project')) != result['base_digest']
            or native_snapshot(state) != state.get(PREFIX + 'snapshot')):
        raise ValueError('As entradas mudaram depois da busca. Busque novamente antes de aplicar.')
    return base


def apply_suggestion():
    state = st.session_state
    try:
        from .double_angle_ui import _proposed_ui_state, seed
        base = _current_base(state)
        proposal = validated_proposal(base, state.get(PREFIX + 'choice'))
        proposed = _proposed_ui_state(proposal)
        # Complete validation precedes every mutation of the native inputs.
        backup = {'project': base.to_dict(), 'encoded': _encoded(base.to_dict())}
        seed(proposed)
        state[PREFIX + 'backup'] = backup
        _clear_search(state)
        state[PREFIX + 'notice'] = ('Sugestão aplicada aos campos editáveis. O resultado, o desenho e os arquivos '
                                    'abaixo são recalculados pelo fluxo nativo. O projeto anterior foi preservado.')
        state.pop(PREFIX + 'error', None)
    except (ValueError, TypeError, KeyError, OverflowError) as exc:
        state[PREFIX + 'error'] = 'Sugestão não aplicada: ' + str(exc)


def restore_previous():
    state = st.session_state
    try:
        from .double_angle_ui import _proposed_ui_state, seed
        if state.get('connection_family') != FAMILY:
            raise ValueError('Abra a família R016 antes de restaurar.')
        backup = state.get(PREFIX + 'backup')
        if not isinstance(backup, dict):
            raise ValueError('Não há projeto anterior a uma aplicação de sugestão nesta sessão.')
        original = DoubleAngle.from_dict(backup['project'])
        proposed = _proposed_ui_state(original)
        seed(proposed)
        _clear_search(state)
        state[PREFIX + 'notice'] = 'Projeto anterior restaurado nos campos nativos. O cálculo e os arquivos são recalculados.'
        state.pop(PREFIX + 'error', None)
    except (ValueError, TypeError, KeyError, OverflowError) as exc:
        state[PREFIX + 'error'] = 'Projeto anterior não restaurado: ' + str(exc)


def _label(candidate):
    c = candidate['project']['connection']
    label = ('L=' + display_format(c['length'], 'g') + ' mm · '
             + str(c['web_rows']) + '/' + str(c['support_rows']) + ' linhas · db='
             + display_format(c['db'], 'g') + ' mm')
    return label + (' · projeto atual' if candidate['is_original'] else '')


def render(c, current_evaluation):
    """Called after the native project has been built and evaluated unchanged."""
    state = st.session_state
    with st.expander('Sugestões de detalhamento R016 · busca opcional', expanded=False):
        st.caption('Busca limitada ao gabarito atual: L76×76×6,4/g45 ou L102×102×8/g65. '
                   'Não troca perfil, aço, ações, sentido, raio, gabarito nem hipóteses de montagem. '
                   'As propostas permanecem separadas do projeto até você aplicar uma delas.')
        st.caption('Conjunto pesquisado: projeto atual e diâmetros métricos 16/20/24/30 mm; '
                   '2 a 20 linhas iguais nas duas interfaces; passos e bordas da tabela industrial já usada '
                   'pelo módulo; comprimento 2e+(n−1)p. Todo candidato passa pelo avaliador R016 vigente.')
        st.caption('Ordem: menor comprimento no mesmo gabarito, depois menor número total de parafusos '
                   'e menor diâmetro. É a melhor opção somente nesse conjunto finito; não é ótimo global '
                   'nem comparação de massa comercial. O primeiro item não é aplicado automaticamente.')
        if st.button('Buscar sugestões R016', key=PREFIX + 'search'):
            result = search(c)
            state[PREFIX + 'result'] = result
            state[PREFIX + 'snapshot'] = native_snapshot(state)
            accepted = result['accepted']
            state[PREFIX + 'choice'] = accepted[0]['id'] if accepted else 'none'
            state[PREFIX + 'selected_id'] = state[PREFIX + 'choice']
            state.pop(PREFIX + 'error', None)
            state.pop(PREFIX + 'notice', None)
        if state.get(PREFIX + 'notice'):
            st.info(state[PREFIX + 'notice'])
        if state.get(PREFIX + 'error'):
            st.warning(state[PREFIX + 'error'])
        result = state.get(PREFIX + 'result')
        if result:
            stale = (result.get('base_digest') != project_digest(c)
                     or state.get(PREFIX + 'snapshot') != native_snapshot(state))
            if stale:
                st.warning('Busca desatualizada: as entradas mudaram. Nenhuma proposta pode ser aplicada até buscar novamente.')
            counts = result['counts']
            st.caption(f"Candidatos avaliados: {counts['evaluated']}; com verificações completas atendidas: {counts['accepted']}; rejeitados: {counts['rejected']}.")
            if result['status'] == 'BLOCKED':
                st.warning('Busca bloqueada pelas condições atuais. Resolva as pendências no formulário; nenhuma hipótese será corrigida silenciosamente.')
                for reason in result['reasons']:
                    st.caption(reason)
            elif not result['accepted']:
                st.warning('Nenhum candidato integralmente verificado neste conjunto. O projeto e seu resultado atual permanecem inalterados.')
            else:
                accepted = {item['id']: item for item in result['accepted']}
                if state.get(PREFIX + 'choice') not in accepted:
                    previous = state.get(PREFIX + 'selected_id')
                    state[PREFIX + 'choice'] = previous if previous in accepted else next(iter(accepted))
                selected_id = st.selectbox('Prévia da sugestão · não altera o projeto', list(accepted),
                                            format_func=lambda value: _label(accepted[value]),
                                            key=PREFIX + 'choice', on_change=choice_changed)
                selected = accepted[selected_id]
                evaluation = selected['evaluation']
                from .double_angle_ui import STATUS
                st.caption('Resultado próprio da proposta: ' + STATUS.get(evaluation['status'], evaluation['status']) + '. '
                           'O resultado principal continua sendo o do formulário atual.')
                st.caption('Índice adotado da proposta: '
                           + display_format(evaluation['summary']['governing_utilization'], '.3f') + '.')
                st.caption('A posição do topo da cantoneira e as extremidades reais do pilar permanecem fixas. '
                           'As distâncias entre furos e bordas do pilar são recalculadas para esses mesmos limites físicos.')
                if selected['changes']:
                    st.table([{'Campo alterado': FIELD_LABELS.get(item['field'], item['field']),
                               'Atual': display_format(item['before'], 'g'),
                               'Proposta': display_format(item['after'], 'g')}
                              for item in selected['changes']])
                else:
                    st.caption('Esta proposta coincide com o projeto usado na busca.')
                for issue in evaluation['issues']:
                    if issue['severity'] in ('warning', 'preset_deviation'):
                        st.warning('Proposta: ' + issue['text'])
                st.caption('Diâmetro/furo propostos exigem conferir os componentes reais. Raio da ferramenta, '
                           'furo de broca e exclusão de rosca são as declarações atuais, não confirmação de fabricação. '
                           'Verificação completa neste domínio não aprova o projeto estrutural global.')
                st.download_button('Baixar sugestão R016 .json', _encoded(selected['project']),
                                   'sugestao_cantoneiras_R016.json', 'application/json', key=PREFIX + 'download')
                st.button('Aplicar sugestão', key=PREFIX + 'apply', type='primary', disabled=stale,
                          on_click=apply_suggestion)
            if result['rejected']:
                with st.expander('Candidatos rejeitados · rastreabilidade'):
                    st.json(result['rejected'], expanded=False)
        backup = state.get(PREFIX + 'backup')
        if backup:
            st.caption('A aplicação mais recente preservou o projeto anterior abaixo. Restaurar substitui '
                       'explicitamente os campos atuais; baixar o arquivo não altera nada.')
            st.download_button('Baixar projeto anterior às sugestões .json', backup['encoded'],
                               'R016_anterior_a_sugestao.json', 'application/json', key=PREFIX + 'backup_download')
            st.button('Restaurar projeto anterior', key=PREFIX + 'restore', on_click=restore_previous)
