"""Current-input croquis of one continuous plate between orthogonal W beams.

x follows the upper beam, y the lower beam, z is up from the lower top flange.
Unknown end coordinates and tool envelopes are never invented. Member display
lengths are schematic and un-dimensioned; the plate and connection are to scale.
"""
from io import BytesIO
import math

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Polygon, Rectangle

from .beam_on_beam import bolt_coordinates, input_errors
from .display_precision import display_format
from .drawing_annotations import dimension, rendered_wrap

INK = '#263746'
MUTED = '#627487'
LOWER = '#d9e2eb'
UPPER = '#80bec9'
PLATE = '#bab0db'
STIFFENER = '#e7b873'
WELD = '#ac394a'


def validated_result(c, result=None):
    """Cached outputs cannot approve a drawing or replace its current input."""
    from .beam_on_beam import evaluate
    try:
        return evaluate(c)
    except (TypeError, ValueError, ArithmeticError, AttributeError) as exc:
        return dict(status='INVALID_INPUT', global_pass=False, issues=[dict(severity='invalid_input', text=str(exc))])


def _num(value):
    if value is None:
        return 'desconhecido'
    try:
        return display_format(value, '.2f')
    except (ValueError, TypeError, OverflowError):
        return str(value)


def _force_kn(value):
    try:
        return _num(value / 1000) if isinstance(value, (int, float)) and not isinstance(value, bool) else 'inválido'
    except (ValueError, TypeError, OverflowError):
        return 'inválido'


def _drawable(c):
    try:
        if input_errors(c):
            return False
        values = [getattr(c, k) for k in ('plate_length', 'plate_width', 'tp', 'bolt_pitch', 'bolt_gauge', 'db',
                  'hole_diameter', 'weld_leg', 'weld_length', 'stiffener_t', 'stiffener_width', 'stiffener_height')]
        values += [getattr(p, k) for p in (c.beam, c.support) for k in ('d', 'bf', 'tw', 'tf')]
        if max(values) > 1e6 or min(values) < 1e-5 or max(values) / min(values) > 1e6:
            return False
        if any(p.d <= 2 * p.tf or p.bf <= p.tw for p in (c.beam, c.support)):
            return False
        return c.reference_x is None or abs(c.reference_x) < 1e6
    except (ValueError, TypeError, AttributeError, OverflowError):
        return False


def _figure(c, result=None):
    r = validated_result(c, result)
    fig = plt.figure(figsize=(17, 11), facecolor='white')

    def text(x, y, value, gid, **kwargs):
        artist = fig.text(x, y, value, color=kwargs.pop('color', INK), parse_math=False, **kwargs)
        artist.set_gid(gid)
        return artist

    text(.035, .962, 'VIGA SOBRE VIGA  |  CHAPA ÚNICA CONTÍNUA', 'drawing_family_beam_on_beam', fontsize=17, fontweight='bold')
    text(.035, .936, 'Projeto: ' + str(getattr(c, 'project', '')), 'current_project', fontsize=9)
    text(.035, .913, 'Superior de extremidade: ' + str(getattr(getattr(c, 'beam', None), 'name', '?')) +
         '  |  Inferior: ' + str(getattr(getattr(c, 'support', None), 'name', '?')),
         'current_profiles', fontsize=9)
    text(.035, .886, 'CROQUIS DE ENTRADA · DIMENSÕES DE TENTATIVA · SEM APROVAÇÃO DA LIGAÇÃO COMPLETA',
         'approval_status', fontsize=10, fontweight='bold', color=WELD)
    text(.035, .864, 'Resultado atual: ' + str(r.get('status')) + '  |  V=' + _force_kn(getattr(c, 'V', None)) + ' kN; N=' + _force_kn(getattr(c, 'N', None)) + ' kN',
         'engine_status', fontsize=9, color=MUTED)
    if not _drawable(c):
        text(.055, .745, 'ENTRADA SEM REPRESENTAÇÃO FÍSICA SEGURA', 'diagnostic_only', fontsize=17, fontweight='bold', color=WELD)
        text(.055, .690, 'Corrija as dimensões ou o perfil. Nenhuma geometria de exemplo substituiu a entrada atual.',
             'diagnostic_reason', fontsize=11)
        messages = '\n'.join(str(i.get('text', '')) for i in r.get('issues', [])[:10])
        text(.055, .630, rendered_wrap(messages, 1000, 10), 'diagnostic_issues', fontsize=10, va='top')
        return fig

    bx, by = c.plate_length / 2, c.plate_width / 2
    span_x = max(c.plate_length * 1.5, c.support.bf * 1.5, c.beam.d * .60)
    span_y = max(c.plate_width * .80, c.beam.bf * 1.3)
    span_x = max(span_x, abs(c.reference_x or 0.) * 1.1)
    end_x = span_x  # Display extent only; x_ref is not a physical beam end.

    def axis(bounds, title, gid):
        ax = fig.add_axes(bounds)
        ax.set_gid(gid); ax.set_title(title, loc='left', fontsize=11, fontweight='bold', pad=15, color=INK)
        ax.set_aspect('equal'); ax.axis('off')
        return ax

    def rect(ax, xy, width, height, color, gid, **kwargs):
        patch = Rectangle(xy, width, height, facecolor=color, edgecolor=INK, linewidth=.9, **kwargs)
        patch.set_gid(gid); ax.add_patch(patch)
        return patch

    def line(ax, xs, ys, gid, **kwargs):
        artist, = ax.plot(xs, ys, **kwargs); artist.set_gid(gid)
        return artist

    def label(ax, x, y, value, gid, **kwargs):
        artist = ax.text(x, y, value, fontsize=8, color=kwargs.pop('color', INK), parse_math=False, **kwargs)
        artist.set_gid(gid); return artist

    def dim(ax, p1, p2, value, gid, **kwargs):
        arrow, artist = dimension(ax, p1, p2, value, **kwargs)
        arrow.set_gid(gid + '_span'); artist.set_gid(gid)

    # The plan shows all four real holes and one physically continuous plate.
    plan = axis([.045, .265, .285, .56], '1 · PLANTA  |  z positivo para o observador', 'plan_xy')
    rect(plan, (-c.support.bf/2, -span_y), c.support.bf, 2*span_y, LOWER, 'plan_lower_top_flange')
    line(plan, [0, 0], [-span_y, span_y], 'plan_lower_web_axis', color=MUTED, linestyle='--', linewidth=.8)
    rect(plan, (-bx, -by), c.plate_length, c.plate_width, PLATE, 'plan_single_continuous_plate', alpha=.85)
    rect(plan, (-span_x, -c.beam.bf/2), end_x + span_x, c.beam.bf, UPPER, 'plan_upper_bottom_flange', alpha=.72)
    line(plan, [-span_x, end_x], [0, 0], 'plan_upper_web_axis', color=MUTED, linestyle='--', linewidth=.8)
    # An unknown physical end is intentionally absent, with schematic breaks.
    for side in (-1, 1):
        line(plan, [side*span_x]*2, [-c.beam.bf*.58, c.beam.bf*.58], 'plan_schematic_break_' + str(side), color='white', linewidth=5)
        line(plan, [side*span_x-5, side*span_x+5, side*span_x-5, side*span_x+5],
             [-c.beam.bf*.58, -c.beam.bf*.2, c.beam.bf*.2, c.beam.bf*.58],
             'plan_break_mark_' + str(side), color=INK, linewidth=.9)
    for index, (x, y) in enumerate(bolt_coordinates(c), 1):
        hole = Circle((x, y), c.hole_diameter/2, facecolor='white', edgecolor=INK, linewidth=1.2)
        hole.set_gid('plan_hole_' + str(index)); plan.add_patch(hole)
        label(plan, x + c.hole_diameter*.70, y, str(index), 'plan_bolt_label_' + str(index), va='center')
        if c.tool_radius is not None:
            tool = Circle((x, y), c.tool_radius, fill=False, edgecolor=WELD, linestyle=':', linewidth=.8)
            tool.set_gid('plan_declared_tool_' + str(index)); plan.add_patch(tool)
    for sign in (-1, 1):
        line(plan, [-c.weld_length/2, c.weld_length/2], [sign*c.beam.bf/2]*2,
             'plan_declared_weld_' + str(sign), color=WELD, linewidth=2.4)
    if c.stiffeners:
        for sign in (-1, 1):
            x0 = c.support.tw/2 if sign > 0 else -c.support.tw/2-c.stiffener_width
            rect(plan, (x0, c.stiffener_y-c.stiffener_t/2), c.stiffener_width, c.stiffener_t,
                 STIFFENER, 'plan_lower_stiffener_' + str(sign), alpha=.7)
    dim(plan, (-bx, by+28), (bx, by+28), 'Lp=' + _num(c.plate_length), 'dimension_plate_length', fontsize=8)
    dim(plan, (span_x+30, -by), (span_x+30, by), 'Bp=' + _num(c.plate_width), 'dimension_plate_width', rotation=90, fontsize=8)
    dim(plan, (-c.bolt_pitch/2, -by-30), (c.bolt_pitch/2, -by-30), 'px=' + _num(c.bolt_pitch), 'dimension_pitch', fontsize=8)
    dim(plan, (-span_x-30, -c.bolt_gauge/2), (-span_x-30, c.bolt_gauge/2), 'gy=' + _num(c.bolt_gauge), 'dimension_gauge', rotation=90, fontsize=8)
    plan.annotate('x · superior', xy=(span_x-20, -span_y-62), xytext=(-bx, -span_y-62), arrowprops=dict(arrowstyle='->', color=INK), fontsize=8, va='center')
    plan.annotate('y · inferior', xy=(-span_x-20, span_y+44), xytext=(-span_x-20, span_y-10), arrowprops=dict(arrowstyle='->', color=INK), fontsize=8)
    plan.set_xlim(-span_x-60, span_x+62); plan.set_ylim(-span_y-90, span_y+70)

    # xz: lower W cross-section, both lower stiffeners, upper longitudinal view.
    front = axis([.355, .225, .295, .60], '2 · VISTA x–z  |  seção da viga inferior', 'section_xz')
    p = c.support
    for z, suffix in [(-p.tf, 'top'), (-p.d, 'bottom')]:
        rect(front, (-p.bf/2, z), p.bf, p.tf, LOWER, 'xz_lower_flange_' + suffix)
    rect(front, (-p.tw/2, -p.d+p.tf), p.tw, p.d-2*p.tf, LOWER, 'xz_lower_web')
    if c.stiffeners:
        for sign in (-1, 1):
            inner, outer = sign*p.tw/2, sign*(p.tw/2+c.stiffener_width)
            top, bottom = -p.tf, -p.tf-c.stiffener_height
            clip = min(c.stiffener_clip, c.stiffener_width, c.stiffener_height/2)
            polygon = Polygon([(inner+sign*clip, top), (outer, top), (outer, bottom),
                               (inner+sign*clip, bottom), (inner, bottom+clip), (inner, top-clip)],
                              facecolor=STIFFENER, edgecolor=INK, linewidth=.9, alpha=.9)
            polygon.set_gid('xz_lower_paired_stiffener_' + str(sign)); front.add_patch(polygon)
    rect(front, (-bx, 0), c.plate_length, c.tp, PLATE, 'xz_single_plate')
    rect(front, (-span_x, c.tp), end_x+span_x, c.beam.d, UPPER, 'xz_upper_beam_longitudinal', alpha=.65)
    for z, suffix in [(c.tp, 'bottom'), (c.tp+c.beam.d-c.beam.tf, 'top')]:
        rect(front, (-span_x, z), end_x+span_x, c.beam.tf, UPPER, 'xz_upper_flange_' + suffix)
    for index, x in enumerate((-c.bolt_pitch/2, c.bolt_pitch/2), 1):
        rect(front, (x-c.db/2, -p.tf-12), c.db, c.tp+p.tf+24, INK, 'xz_projected_bolt_' + str(index), alpha=.85)
    dim(front, (span_x+30, 0), (span_x+30, -p.d), 'd inf.=' + _num(p.d), 'dimension_lower_depth', rotation=90, fontsize=8)
    dim(front, (-span_x-32, c.tp), (-span_x-32, c.tp+c.beam.d), 'd sup.=' + _num(c.beam.d), 'dimension_upper_depth', rotation=90, fontsize=8)
    label(front, -span_x, -p.d-47, 'Chapa tp=' + _num(c.tp) + ' mm  |  Par ts=' + _num(c.stiffener_t) + ' mm', 'xz_plate_stiffener_thickness')
    if c.reference_x is not None:
        zref = c.tp + c.beam.d / 2
        ref = c.reference_x
        v_start = zref + (c.beam.d*.30 if c.V >= 0 else -c.beam.d*.30)
        varrow = front.annotate('', xy=(ref, zref), xytext=(ref, v_start),
                                arrowprops=dict(arrowstyle='->', color=WELD))
        varrow.set_gid('vertical_force_at_reference')
        label(front, ref+12, v_start, 'V=' + _num(c.V/1000) + ' kN', 'vertical_force_label', color=WELD)
        n_end = ref + (span_x*.60 if c.N >= 0 else -span_x*.60)
        narrow = front.annotate('', xy=(n_end, zref), xytext=(ref, zref),
                                arrowprops=dict(arrowstyle='->', color=WELD))
        narrow.set_gid('horizontal_force_at_reference')
        label(front, (ref+n_end)/2, zref-24, 'N=' + _num(c.N/1000) + ' kN', 'horizontal_force_label', color=WELD, ha='center')
    for x in (-span_x, span_x):
        line(front, [x, x], [c.tp-1, c.tp+c.beam.d+1], 'xz_unknown_end_break_' + str(x), color='white', linewidth=4)
        line(front, [x, x], [c.tp-1, c.tp+c.beam.d+1], 'xz_unknown_end_symbol_' + str(x), color=INK, linestyle='--', linewidth=.8)
    if c.reference_x is not None:
        line(front, [c.reference_x, c.reference_x], [c.tp, c.tp+c.beam.d],
             'xz_action_reference_line', color=WELD, linestyle=':', linewidth=1.2)
        label(front, c.reference_x, c.tp+c.beam.d+24, 'Referência x=' + _num(c.reference_x), 'known_reference_x', ha='center', color=WELD)
        line(plan, [c.reference_x, c.reference_x], [-c.beam.bf/2, c.beam.bf/2],
             'plan_action_reference_line', color=WELD, linestyle=':', linewidth=1.2)
    front.set_xlim(-span_x-60, span_x+65); front.set_ylim(-p.d-65, c.tp+c.beam.d+68)

    # yz: upper W cross-section and lower longitudinal beam. The paired lower
    # stiffeners overlap in projection; the xz view above shows the two plates.
    side = axis([.685, .225, .275, .60], '3 · VISTA y–z  |  seção da viga superior', 'section_yz')
    rect(side, (-span_y, -p.d), 2*span_y, p.d, LOWER, 'yz_lower_beam_longitudinal', alpha=.65)
    for z, suffix in [(-p.tf, 'top'), (-p.d, 'bottom')]:
        rect(side, (-span_y, z), 2*span_y, p.tf, LOWER, 'yz_lower_flange_' + suffix)
    if c.stiffeners:
        rect(side, (c.stiffener_y-c.stiffener_t/2, -p.tf-c.stiffener_height), c.stiffener_t,
             c.stiffener_height, STIFFENER, 'yz_paired_stiffeners_projected')
    rect(side, (-by, 0), c.plate_width, c.tp, PLATE, 'yz_single_plate')
    u = c.beam
    for z, suffix in [(c.tp, 'bottom'), (c.tp+u.d-u.tf, 'top')]:
        rect(side, (-u.bf/2, z), u.bf, u.tf, UPPER, 'yz_upper_flange_' + suffix)
    rect(side, (-u.tw/2, c.tp+u.tf), u.tw, u.d-2*u.tf, UPPER, 'yz_upper_web')
    for index, y in enumerate((-c.bolt_gauge/2, c.bolt_gauge/2), 1):
        rect(side, (y-c.db/2, -p.tf-12), c.db, c.tp+p.tf+24, INK, 'yz_projected_bolt_' + str(index), alpha=.85)
    dim(side, (-u.bf/2, c.tp+u.d+30), (u.bf/2, c.tp+u.d+30), 'bf sup.=' + _num(u.bf), 'dimension_upper_bf', fontsize=8)
    label(side, -span_y, -p.d-47, 'Enrijecedores abaixo da mesa superior inferior', 'lower_stiffener_location')
    side.set_xlim(-span_y-35, span_y+35); side.set_ylim(-p.d-65, c.tp+u.d+68)

    text(.04, .197, 'LEGENDA  |  Azul: viga superior   Cinza: viga inferior   Lilás: uma chapa contínua   Ocre: par de enrijecedores inferiores   Vermelho: solda / ações',
         'drawing_legend', fontsize=9)
    notes = [
        'Dimensões em mm; quatro furos Ø' + _num(c.hole_diameter) + ' para parafusos Ø' + _num(c.db) + '. Espessuras e coordenadas refletem a entrada atual.',
        'x_ref da seção / nó de aplicação das ações: ' + _num(c.reference_x) + ' mm. A referência não define a extremidade física da viga.' + (' Posição das ações não desenhada.' if c.reference_x is None else ''),
        'A viga superior TERMINA sobre o apoio. Coordenada física da terminação não informada; traços interrompidos são esquemáticos, sem cota de acesso.',
        'Ferramenta real: raio ' + _num(c.tool_radius) + ' mm. ' + ('Nenhum envelope de ferramenta foi desenhado ou presumido.' if c.tool_radius is None else 'Círculos pontilhados: envelope declarado, sem prova de acesso axial.'),
        'V segue por contato; N é horizontal. My devido a N = ' + _num(c.N*(c.beam.d/2+c.tp)/1e6) + ' kN·m. Contato, flexão e tração/alavanca continuam sujeitos ao modelo local.',
        'Soldas desenhadas com comprimento declarado; término útil precisa ser conferido. Enrijecedores representam detalhamento, sem crédito automático de resistência.',
    ]
    text(.04, .17, rendered_wrap('\n'.join(notes), 1110, 8.5), 'current_drawing_notes', fontsize=8.5, va='top', linespacing=1.5)
    return fig


def image_bytes(c, result=None):
    fig = _figure(c, result)
    try:
        buffer = BytesIO(); fig.savefig(buffer, format='png', dpi=130, facecolor='white')
        return buffer.getvalue()
    finally:
        plt.close(fig)


def drawing_svg(c, result=None):
    fig = _figure(c, result)
    try:
        buffer = BytesIO()
        with matplotlib.rc_context({'svg.fonttype': 'none'}):
            fig.savefig(buffer, format='svg', facecolor='white')
        return buffer.getvalue().decode('utf-8')
    finally:
        plt.close(fig)
