"""Strong-axis corner gusset, welded/bolted local adapters, COMPLETE_CUTS.

N, mm, MPa, N mm. Independently parameterized physical component calculation.
No numerical fixture, oracle file or result from another connection is imported.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict, fields, replace
from copy import deepcopy
import math
import numpy as np
from numpy.polynomial import Polynomial as Poly
from .models import profiles, STEELS, finite_real
from .angle_catalog import get_angle, catalog

COMPONENT_VERSION = '0.9.36-bolted-corner-compression-dev'
WELDED_COMPRESSION_VERSION = '0.9.35-corner-compression-dev'
PREVIOUS_COMPONENT_VERSION = '0.9.34-bolted-corner-dev'
SINGLE_COMPONENT_VERSION = '0.9.33-single-angle-corner-dev'
from .corner_compression import RESTRAINT_FIELDS, STATUSES, candidate as compression_candidate
from .bolted_corner_compression import DETAIL_FIELDS as BOLTED_COMPRESSION_FIELDS, native_detail_required
BOLTED_TOPOLOGIES = ('single_1L_bolted', 'symmetric_2L_T_bolted')
WELDED_BRACE_FIELDS = ('fw_brace','brace_weld_start','brace_weld_length','brace_free_end_extension','brace_weld_leg')
BOLTED_FIELDS = ('bolt', 'bolt_diameter', 'bolt_count', 'bolt_start', 'bolt_pitch', 'bolt_gauge', 'bolt_angle_end', 'bolt_drilled', 'bolt_threads_excluded_1', 'bolt_threads_excluded_2', 'bolt_pretensioned', 'bolt_exposure', 'bolt_tool_radius', 'bolt_fabrication_clearance', 'bolt_heel_extent', 'bolt_heel_extent_source', 'bolt_washer_stack')

def is_bolted(c): return getattr(c,'topology',None) in BOLTED_TOPOLOGIES
def is_single(c): return getattr(c,'topology',None) in ('single_1L_welded','single_1L_bolted')
LEGACY_COMPONENT_VERSION = '0.9.32-corner-gusset-dev'
CONNECTION_TYPE = 'corner_gusset'
FAMILY = 'Ligação de canto 2L-T–gusset–viga/pilar · soldada'
UNITS = {'force':'N', 'length':'mm', 'stress':'MPa', 'moment':'N mm'}
MATERIALS = {name: {'fy':s.fy, 'fu':s.fu} for name,s in STEELS.items()}
MEMBER_CATALOG = profiles()
ANGLE_CATALOG = catalog()
# Published major-axis elastic moduli, Gerdau W tables, cm3 converted to mm3.
# Other selected W sections use a conservative sharp-rectangle derivation.
PUBLISHED_WX = {'W 310 x 52,0':751400., 'W 310 x 97,0 (H)':1447000.}
EXCLUSIONS = [
    'Estabilidade global dos membros e do pórtico, execução/WPS e inspeção não são certificados pelo módulo local.',
    'Sem sismo, fadiga, ações fora do plano, peças opostas desiguais ou soldas interrompidas.',
    'Compressão da diagonal/gusset e redistribuição para ponto de trabalho excêntrico requerem qualificação própria.'
]

@dataclass(frozen=True)
class CornerGusset:
    project: str = 'C1 · gusset de canto · 2L-T · ações completas'
    beam_profile: str = 'W 310 x 52,0'
    column_profile: str = 'W 310 x 97,0 (H)'
    angle_profile: str = 'GERDAU_EQUAL_ANGLE_P03_R30'
    angle_steel: str = 'ASTM A36'
    gusset_steel: str = 'ASTM A36'
    beam_steel: str = 'ASTM A572 Gr.50'
    column_steel: str = 'ASTM A572 Gr.50'
    continuity_steel: str = 'ASTM A36'
    fw_brace: float = 485.
    fw_root: float = 485.
    fw_joint: float = 485.
    fw_continuity: float = 485.
    E: float = 200000.
    gamma_a1: float = 1.10
    gamma_a2: float = 1.35
    gamma_w2: float = 1.35
    plate_width: float = 600.
    plate_height: float = 600.
    plate_t: float = 12.
    corner_clip: float = 30.
    beam_seam_start_margin: float = 10.
    beam_seam_end_margin: float = 10.
    column_seam_start_margin: float = 10.
    column_seam_end_margin: float = 10.
    root_weld_leg: float = 6.
    phi_deg: float = 45.
    workpoint_offset: float = 0.
    brace_weld_start: float = 650.
    brace_weld_length: float = 220.
    brace_free_end_extension: float = 20.
    brace_weld_leg: float = 5.
    beam_web_weld_length: float = 220.
    beam_web_weld_leg: float = 5.
    beam_access_radius: float = 25.
    matching_cjp: bool = True
    continuity_width: float = 140.
    continuity_t: float = 12.
    continuity_clip: float = 30.
    continuity_flange_start_margin: float = 5.
    continuity_flange_end_margin: float = 5.
    continuity_web_end_margin: float = 5.
    continuity_flange_weld_leg: float = 6.
    continuity_web_weld_leg: float = 6.
    column_end_top: float = 2000.
    column_end_bottom: float = -2000.
    symmetric: bool = True
    lateral_restraint: bool = True
    topology: str = 'symmetric_2L_T_welded'
    single_angle_face: str = 'positive'
    load_convention: str = 'COMPLETE_CUTS'
    case_id: str = 'C1_STATIC_COMPLETE'
    P: float = 100000.
    beam_cut_x: float = 1000.
    beam_cut_y: float = 0.
    beam_cut_Fx: float = -30710.67811865475
    beam_cut_Fy: float = -50000.
    beam_cut_M: float = 62300000.
    upper_column_cut_x: float = 0.
    upper_column_cut_y: float = 1000.
    upper_column_cut_Fx: float = 10000.
    upper_column_cut_Fy: float = -500000.
    upper_column_cut_M: float = 10000000.
    lower_column_cut_x: float = 0.
    lower_column_cut_y: float = -1000.
    cuts_source: str = 'Ações concorrentes completas sobre o corpo livre isolado; exemplo C1'
    other_loads_excluded: bool = True
    other_loads: tuple = ()
    compare_lower_cut: bool = False
    lower_column_check_Fx: float = -50000.
    lower_column_check_Fy: float = 479289.32188134524
    lower_column_check_M: float = 37700000.

    compression_beam_restraint: str = 'unknown'
    compression_column_restraint: str = 'unknown'
    compression_brace_restraint: str = 'unknown'
    compression_detail_source: str = 'Não informado'
    compression_geometry_stamp: str = 'undeclared'

    bolt: str = 'ASTM F3125 A325'
    bolt_diameter: float = 16.
    bolt_count: int = 4
    bolt_start: float = 370.
    bolt_pitch: float = 60.
    bolt_gauge: float = 40.
    bolt_angle_end: float = 35.
    bolt_drilled: bool = True
    bolt_threads_excluded_1: bool = False
    bolt_threads_excluded_2: bool = False
    bolt_pretensioned: bool = False
    bolt_exposure: str = 'painted'
    bolt_tool_radius: float = 18.
    bolt_fabrication_clearance: float = 2.
    bolt_heel_extent: float = 0.
    bolt_heel_extent_source: str = 'Não informado'
    bolt_washer_stack: float = 0.
    bolt_friction_type: bool = False
    bolt_surface_class: str = 'unknown'
    bolt_installation_source: str = 'Não informado'
    bolt_hardened_washer_count: int = 0
    bolt_washer_location: str = 'none'
    bolt_washer_diameter: float = 0.
    bolt_angle_continuation: float = 0.
    bolt_continuation_source: str = 'Não informado'
    combination_type: str = 'unknown'

    def to_dict(self):
        if self.topology not in ('single_1L_welded','symmetric_2L_T_welded')+BOLTED_TOPOLOGIES:
            raise ValueError('topology: adaptador nativo não reconhecido.')
        errors = input_errors(self)
        if errors:
            raise ValueError('; '.join(errors))
        raw = asdict(self)
        if not is_single(self):
            raw.pop('single_angle_face')
        for name in (WELDED_BRACE_FIELDS if is_bolted(self) else BOLTED_FIELDS): raw.pop(name)
        if not native_detail_required(self):
            for name in BOLTED_COMPRESSION_FIELDS: raw.pop(name)
        compression_defaults={f.name:f.default for f in fields(self) if f.name in RESTRAINT_FIELDS}
        if self.topology not in ('symmetric_2L_T_welded','symmetric_2L_T_bolted') or (self.P>=0 and all(getattr(self,k)==v for k,v in compression_defaults.items())):
            for name in RESTRAINT_FIELDS: raw.pop(name)
        raw['other_loads'] = deepcopy(list(self.other_loads))
        for action in raw['other_loads']: action['point'] = list(action['point'])
        return {'schema_version':1, 'connection_type':CONNECTION_TYPE,
                'component_version':COMPONENT_VERSION, 'connection':raw,
                'units':dict(UNITS), 'fixed_assumptions':fixed_assumptions(self.topology)}

    @classmethod
    def from_dict(cls, data):
        keys = {'schema_version','connection_type','component_version','connection','units','fixed_assumptions'}
        if not isinstance(data,dict) or set(data)!=keys:
            raise ValueError('Campos nativos ausentes ou desconhecidos.')
        if type(data['schema_version']) is not int or data['schema_version']!=1 or data['connection_type']!=CONNECTION_TYPE or data['component_version'] not in (COMPONENT_VERSION, WELDED_COMPRESSION_VERSION, PREVIOUS_COMPONENT_VERSION, SINGLE_COMPONENT_VERSION, LEGACY_COMPONENT_VERSION):
            raise ValueError('Família ou versão incompatível; não há migração silenciosa.')
        raw=data['connection']
        if not isinstance(raw,dict): raise ValueError('connection deve ser um objeto nativo.')
        if raw.get('topology') not in ('single_1L_welded','symmetric_2L_T_welded')+BOLTED_TOPOLOGIES:
            raise ValueError('topology: adaptador nativo não reconhecido.')
        bolted=raw.get('topology') in BOLTED_TOPOLOGIES
        required={f.name for f in fields(cls)}-{'single_angle_face'}-(set(WELDED_BRACE_FIELDS) if bolted else set(BOLTED_FIELDS))
        compression_native = data['component_version'] in (COMPONENT_VERSION, WELDED_COMPRESSION_VERSION) and raw['topology'] in (('symmetric_2L_T_welded','symmetric_2L_T_bolted') if data['component_version']==COMPONENT_VERSION else ('symmetric_2L_T_welded',)) and (any(k in raw for k in RESTRAINT_FIELDS) or (finite_real(raw.get('P')) and raw['P']<0))
        if not compression_native: required -= set(RESTRAINT_FIELDS)
        detail_native = data['component_version']==COMPONENT_VERSION and bolted and (any(k in raw for k in BOLTED_COMPRESSION_FIELDS) or (raw['topology']=='symmetric_2L_T_bolted' and finite_real(raw.get('P')) and raw['P']<0))
        if not detail_native: required -= set(BOLTED_COMPRESSION_FIELDS)
        if not isinstance(raw,dict) or not required <= set(raw) or set(raw)-required-{'single_angle_face'}:
            raise ValueError('Campos da ligação ausentes ou desconhecidos.')
        if raw['topology'] in ('single_1L_welded','single_1L_bolted') and 'single_angle_face' not in raw:
            raise ValueError('O arquivo 1L deve identificar explicitamente single_angle_face; não se infere a face física ausente.')
        if bolted and data['component_version'] not in (COMPONENT_VERSION, WELDED_COMPRESSION_VERSION, PREVIOUS_COMPONENT_VERSION):
            raise ValueError('A versão anterior não contém o adaptador parafusado de canto.')
        if data['component_version']==LEGACY_COMPONENT_VERSION and ('single_angle_face' in raw or raw['topology']=='single_1L_welded'):
            raise ValueError('A versão 0.9.32 não contém o adaptador 1L.')
        if not _exact(data['units'],UNITS) or not _exact(data['fixed_assumptions'],fixed_assumptions(raw['topology'])):
            raise ValueError('Unidades ou premissas incompatíveis.')
        raw=deepcopy(raw)
        raw.setdefault('single_angle_face','positive')
        if not isinstance(raw['other_loads'],list):
            raise ValueError('other_loads deve ser uma lista nativa.')
        raw['other_loads']=tuple(raw['other_loads'])
        result=cls(**raw)
        errors=input_errors(result)
        if errors: raise ValueError('; '.join(errors))
        return result


def _exact(a,b):
    if isinstance(b,dict):return isinstance(a,dict) and set(a)==set(b) and all(_exact(a[k],v) for k,v in b.items())
    if isinstance(b,list):return isinstance(a,list) and len(a)==len(b) and all(_exact(x,y) for x,y in zip(a,b))
    return type(a) is type(b) and a==b


def fixed_assumptions(topology='symmetric_2L_T_welded'):
    single=topology in ('single_1L_welded','single_1L_bolted')
    result={'brace_adapter':'single_1L_welded' if single else 'symmetric_2L_T_welded', 'angle_count':1 if single else 2, 'gusset_count':1,
            'load_convention':'COMPLETE_CUTS', 'moment_path':'all_beam_moment_to_flange_couple',
            'gusset_force_method':'DG29_Appendix_A_generalized_UFM',
            'continuity_path':'full_flange_force_to_web_each_plate_eccentricity_retained',
            'opposite_continuity_flange_transfer_credit':False, 'fitted_contact_credit':False}
    if topology in BOLTED_TOPOLOGIES:
        result.update(brace_adapter=topology, physical_bolt_rows=1, physical_shear_planes=1 if single else 2,
                      brace_weld_count=0, contact='firm_direct_no_fillers', slip_resistance_credit=False,
                      end_axis_idealization='NBR8800:2024 6.1.8.2 ordinary static angle end; nominal bolt row in gusset midplane',
                      nominal_connection_axis_z=0., assumed_spatial_cancellation=not single,
                      inplane_centroid_offset_cancels=False, exact_3D_equilibrium_claimed=False,
                      force_case='actual_COMPLETE_CUTS_and_separate_full_chain_minimum45_strength_case',
                      bearing='uniform_per_physical_hole_opposite_part_directions',
                      block='actual_polygon_L_and_tangent_U_alternatives_support_contact_inactive',
                      body_sections='supplemental_nominal_circular_net_sections_not_continuum')
    elif single:
        result.update(brace_weld_count=2, nominal_connection_axis_z=0.,
                      end_axis_idealization='NBR8800:2024 6.1.8.2 ordinary static direct single-angle end connection; nominal gusset midplane',
                      assumed_spatial_cancellation=False, exact_3D_equilibrium_claimed=False)
    return result


def input_errors(c):
    if not isinstance(c,CornerGusset):return ['Entrada deve ser CornerGusset.']
    errors=[]
    for f in fields(c):
        val=getattr(c,f.name)
        default=f.default
        if f.name=='other_loads' or (f.name in BOLTED_FIELDS+BOLTED_COMPRESSION_FIELDS and not is_bolted(c)) or (f.name in WELDED_BRACE_FIELDS and is_bolted(c)):continue
        if f.name=='bolt_hardened_washer_count':
            if type(val) is not int or not 0<=val<=2: errors.append('bolt_hardened_washer_count: inteiro nativo de 0 a 2 obrigatório.')
            continue
        if f.name=='bolt_count':
            if type(val) is not int or not 2<=val<=50: errors.append('bolt_count: inteiro nativo de 2 a 50 obrigatório.')
            continue
        if isinstance(default,bool):
            if type(val) is not bool:errors.append(f'{f.name}: booleano nativo obrigatório.')
        elif isinstance(default,str):
            declaration_unknown=f.name in ('compression_detail_source','compression_geometry_stamp')
            if not isinstance(val,str) or (not val.strip() and not declaration_unknown):errors.append(f'{f.name}: texto nativo obrigatório.' if declaration_unknown else f'{f.name}: texto não vazio obrigatório.')
        elif not finite_real(val):errors.append(f'{f.name}: número real finito obrigatório; ausência não é zero.')
    if not isinstance(c.other_loads,(tuple,list)):
        errors.append('other_loads: lista de ações explícitas obrigatória.')
    else:
        for i,a in enumerate(c.other_loads):
            keys={'label','member','point','Fx','Fy','M'}
            if not isinstance(a,dict) or set(a)!=keys:
                errors.append(f'other_loads[{i}]: campos label/member/point/Fx/Fy/M obrigatórios.');continue
            if not isinstance(a['label'],str) or not a['label'].strip() or a['member'] not in ('beam','column'):
                errors.append(f'other_loads[{i}]: identificação e membro beam/column obrigatórios.')
            if not isinstance(a['point'],(list,tuple)) or len(a['point'])!=2 or not all(finite_real(v) for v in a['point']):
                errors.append(f'other_loads[{i}].point: dois números finitos obrigatórios.')
            if not all(finite_real(a[k]) for k in ('Fx','Fy','M')):errors.append(f'other_loads[{i}]: ação numérica finita obrigatória.')
    for key in ('beam_profile','column_profile'):
        if not isinstance(getattr(c,key),str) or getattr(c,key) not in MEMBER_CATALOG:errors.append(f'{key}: perfil não reconhecido.')
    if not isinstance(c.angle_profile,str) or get_angle(c.angle_profile) is None:errors.append('angle_profile: cantoneira não reconhecida.')
    for key in ('angle_steel','gusset_steel','beam_steel','column_steel','continuity_steel'):
        if not isinstance(getattr(c,key),str) or getattr(c,key) not in MATERIALS:errors.append(f'{key}: aço não reconhecido.')
    if not isinstance(c.single_angle_face,str) or c.single_angle_face not in ('positive','negative'):
        errors.append('single_angle_face: escolher positive ou negative.')
    elif not is_single(c) and c.single_angle_face!='positive':
        errors.append('single_angle_face: a escolha de face negativa pertence somente ao adaptador 1L; 2L conserva o padrão positivo sem campo nativo de face.')
    for key in RESTRAINT_FIELDS[:3]:
        if getattr(c,key) not in STATUSES: errors.append(key+': escolher unknown, confirmed ou absent.')
    if is_bolted(c):
        from .models import BOLTS
        from .bolted_angle_gusset import HOLES
        if c.bolt not in BOLTS: errors.append('bolt: classe não reconhecida.')
        if c.bolt_diameter not in HOLES: errors.append('bolt_diameter: diâmetro sem furo-padrão qualificado.')
        if c.bolt_exposure not in ('painted','weathering'): errors.append('bolt_exposure: ambiente não reconhecido.')
        if c.bolt_surface_class not in ('unknown','A','B'): errors.append('bolt_surface_class: escolher unknown, A ou B.')
        if c.bolt_washer_location not in ('none','rotating','both'): errors.append('bolt_washer_location: escolher none, rotating ou both.')
        if c.combination_type not in ('unknown','normal_ultimate','special_ultimate','exceptional_ultimate'): errors.append('combination_type: tipo não reconhecido.')
        for name in ('bolt_washer_diameter','bolt_angle_continuation'):
            if finite_real(getattr(c,name)) and getattr(c,name)<0: errors.append(name+': dimensão não pode ser negativa.')
    return errors


def presets():
    c=CornerGusset()
    bc=replace(c,plate_width=300.,plate_height=300.,topology='symmetric_2L_T_bolted',project='BC1 · canto 2L-T parafusada · ações completas',case_id='BC1_2LT_COMPLETE',bolt_heel_extent=13.94,bolt_heel_extent_source='Hipótese dimensional do fixture t+6 mm; conferir o envelope real, raio não publicado pela Gerdau.')
    from .corner_compression import declare_current_detail
    cc1=declare_current_detail(replace(c,P=-100000.,project='CC1 · compressão −100 kN · falha no limite conservador do receptor',case_id='CC1_COMPRESSION'), 'Fixture CC1: canto ordinário 600×600×12, recorte livre 30 mm, duas raízes efetivas 550 mm; contenções fora do plano da viga, pilar e traspasse 2L contínuo declaradas para este testemunho, conferir no projeto real.')
    cc2=replace(cc1,P=-50000.,project='CC2 · compressão −50 kN · mesmos cortes D/U',case_id='CC2_COMPRESSION')
    cc3=declare_current_detail(replace(cc1,plate_t=6.,project='CC3 · compressão −100 kN · chapa 6 mm adversa',case_id='CC3_COMPRESSION'), 'Fixture CC3 adverso: mesma topologia ordinária de CC1, espessura 6 mm explicitamente declarada; recorte 30 mm e raízes 550 mm. Não é proposta de fabricação.')
    bcc1=declare_current_detail(replace(bc,P=-100000.,bolt_start=385.,bolt_pretensioned=True,bolt_washer_stack=4.,bolt_friction_type=True,bolt_surface_class='B',bolt_installation_source='Fixture hipotético BCC1: superfícies Classe B nas duas faces, A325 M16 pré-tensionado conforme Tabela19; aperto/inspeção e arruela endurecida sob porca girante devem ser comprovados no projeto real.',bolt_hardened_washer_count=1,bolt_washer_location='rotating',bolt_washer_diameter=32.,bolt_angle_continuation=60.,bolt_continuation_source='Fixture: continuação íntegra +u, 60 mm livres após a parede do último furo; conferir próximo furo/borda real.',combination_type='normal_ultimate',project='BCC1 · compressão parafusada −100 kN · receptor não atende',case_id='BCC1_2LT_PRETENSIONED_COMPRESSION'), 'Fixture hipotético BCC1: viga e pilar impedem translação/rotação fora do plano nas raízes; contato direto L–chapa–L, quatro A325 M16 protendidos e Classe B, arruela endurecida 4×32 mm sob porca girante; detalhe da diagonal contém translação relativa e torção das L nas estações u385/445/505/565. Sem certificação de detalhe construído.')
    return {'BC1 · canto 2L-T parafusada · detalhe assumido':bc,
            'BC1 · canto 1L parafusada · detalhe assumido':replace(bc,topology='single_1L_bolted',symmetric=False,project='BC1 · canto 1L parafusada · ações completas',case_id='BC1_1L_COMPLETE'),
            'BC1 · canto 1L parafusada · face negativa':replace(bc,topology='single_1L_bolted',symmetric=False,single_angle_face='negative',project='BC1 · 1L parafusada · face negativa',case_id='BC1_1L_NEGATIVE'),
            'C1 · canto 2L-T · ações completas':c,
            'Canto 2L-T · φ40° · recalcular':replace(c,phi_deg=40.),
            'Canto 2L-T · φ50° · recalcular':replace(c,phi_deg=50.),
            'Ponto de trabalho excêntrico · não verificado':replace(c,workpoint_offset=100.),
            'Compressão do gusset · não verificada':replace(c,phi_deg=80.),
            'C1 · canto 1L · face positiva':replace(c,project='C1 · gusset de canto · 1L · ações completas',topology='single_1L_welded',symmetric=False,case_id='C1_1L_STATIC_COMPLETE'),
            'C1 · canto 1L · face negativa':replace(c,project='C1 · gusset de canto · 1L · face negativa',topology='single_1L_welded',symmetric=False,single_angle_face='negative',case_id='C1_1L_NEGATIVE_COMPLETE'),
            'CC1 · 2L-T compressão · receptor não atende':cc1,
            'CC2 · 2L-T compressão · mesmos cortes':cc2,
            'CC3 · 2L-T compressão · chapa fina adversa':cc3,
            'BCC1 · 2L-T parafusada em compressão · receptor não atende':bcc1,
            'BCC2 · 2L-T parafusada −20 kN · mínimo separado':replace(bcc1,P=-20000.,project='BCC2 · real −20 kN e sintético −45 kN',case_id='BCC2_MINIMUM')}


def _member(name):
    p=MEMBER_CATALOG[name]
    r=asdict(p)
    r['Ag']=p.area
    h=p.d-2*p.tf
    Ix=p.tw*h**3/12+2*(p.bf*p.tf**3/12+p.bf*p.tf*((p.d-p.tf)/2)**2)
    r['Wx']=PUBLISHED_WX.get(name,2*Ix/p.d)
    r['Wx_basis']='Gerdau published elastic major-axis modulus' if name in PUBLISHED_WX else 'sharp rectangles; rolled root material uncredited'
    return r


def _inside(p,poly,tol=1e-8):
    return all((q[0]-a[0])*(p[1]-a[1])-(q[1]-a[1])*(p[0]-a[0])>=-tol for a,q in zip(poly,poly[1:]+poly[:1]))


def _clip(poly,n,k):
    out=[]
    for a,b in zip(poly,poly[1:]+poly[:1]):
        da=n[0]*a[0]+n[1]*a[1]-k;db=n[0]*b[0]+n[1]*b[1]-k
        ia=da>=-1e-9;ib=db>=-1e-9
        if ia:out.append(list(a))
        if ia!=ib:
            f=da/(da-db);out.append([a[i]+f*(b[i]-a[i]) for i in range(2)])
    return out


def _line_intersections(poly,axis,value):
    ans=[]
    for a,b in zip(poly,poly[1:]+poly[:1]):
        if min(a[axis],b[axis])-1e-8<=value<=max(a[axis],b[axis])+1e-8:
            if abs(a[axis]-b[axis])<1e-10:ans.extend([a[1-axis],b[1-axis]])
            else:ans.append(a[1-axis]+(value-a[axis])*(b[1-axis]-a[1-axis])/(b[axis]-a[axis]))
    return (min(ans),max(ans)) if ans else None


def _support_overlap(edges,planes):
    hits=[]
    for name,edge in edges.items():
        a,b=edge;lo,hi=0.,1.
        for n,k in planes:
            d0=n[0]*a[0]+n[1]*a[1]-k;d1=n[0]*b[0]+n[1]*b[1]-k
            if d0 < -1e-9 and d1 < -1e-9:hi=-1.;break
            if (d0>=-1e-9)!=(d1>=-1e-9):
                f=d0/(d0-d1)
                if d0<0:lo=max(lo,f)
                else:hi=min(hi,f)
        length=max(0.,hi-lo)*math.dist(a,b)
        if length>1e-7:hits.append({'support':name,'length':length})
    return hits


def _single_angle_idealization(c,a,co,si):
    """Record the real one-sided eccentricity, never fictitious cancellation.

    NBR 6.1.8.2 permits the ordinary static bar/end-axis simplification. The
    adopted gusset-midplane axis is an explicit engineering idealization of
    that direct end connection, not an exact spatial resistance calculation.
    """
    sign=1 if c.single_angle_face=='positive' else -1
    zface=sign*c.plate_t/2;za=sign*(c.plate_t/2+a['centroid'])
    return {'source':'NBR8800:2024 6.1.8.2',
            'scope':'ordinary axial equal-angle end connection, static, no fatigue, direct faying on gusset, no spacer or intentional joint-plane offset',
            'connection_axis_basis':'adopted nominal gusset midplane z=0; engineering implementation of the ordinary static end-axis exception',
            'physical_angle_axis_v_z':[-c.workpoint_offset,za],
            'physical_weld_root_v_z':[[-a['centroid']-c.workpoint_offset,zface],[a['leg']-a['centroid']-c.workpoint_offset,zface]],
            'nominal_force_axis_v_z':[-c.workpoint_offset,0.],
            'neglected_ordinary_end_axis_offset_mm':za,
            'neglected_offset_partition_mm':{'angle_centroid_to_faying':sign*a['centroid'],'faying_to_gusset_midplane':zface},
            'raw_Mout_Nmm':abs(c.P*za),'raw_spatial_moment_Nmm':{'Mx':-za*c.P*si,'My':za*c.P*co,'Mz':0.},
            'raw_moment_partition_Nmm':{'angle_centroid_to_faying':c.P*sign*a['centroid'],'faying_to_gusset_midplane':c.P*zface},
            'nominal_equilibrium_components':['Fx','Fy','Mz'],
            'assumed_spatial_cancellation':False,'exact_3D_equilibrium_claimed':False,
            'raw_moment_resistance_verified':False,
            'limitations':'No explicit spatial action, fatigue/seismic or stand-off transfer; in-plane offsets, shear lag, local substrates, compressed regions, roots, continuity and complete cuts remain active.'}


def geometry(c):
    errors=input_errors(c)
    if errors:raise ValueError('; '.join(errors))
    b=_member(c.beam_profile);col=_member(c.column_profile);a=get_angle(c.angle_profile)
    eb=b['d']/2;ec=col['d']/2
    cc=c.corner_clip;w=c.plate_width;h=c.plate_height
    poly=[[ec+cc,eb],[ec+w,eb],[ec+w,eb+h],[ec,eb+h],[ec,eb+cc]]
    beam=[[ec+cc+c.beam_seam_start_margin,eb],[ec+w-c.beam_seam_end_margin,eb]]
    column=[[ec,eb+cc+c.column_seam_start_margin],[ec,eb+h-c.column_seam_end_margin]]
    theta=math.radians(c.phi_deg);co=math.cos(theta);si=math.sin(theta);off=c.workpoint_offset
    # v=(-sin(phi),cos(phi)); positive right-normal offset therefore v=-offset.
    def uv(p):return [p[0]*co+p[1]*si,-p[0]*si+p[1]*co]
    def xy(u,v):return [u*co-v*si,u*si+v*co]
    vh=-a['centroid']-off;vt=a['leg']-a['centroid']-off;L=c.brace_weld_length;u0=c.brace_weld_start;u1=u0+L
    single=is_single(c)
    faces=(1 if c.single_angle_face=='positive' else -1,) if single else (-1,1)
    count=len(faces);lines=[]
    for sign in faces:
        for kind,v,f in [('heel',vh,1-a['centroid']/a['leg']),('toe',vt,a['centroid']/a['leg'])]:
            vlo,vhi=sorted([v,v+(-1 if kind=='heel' else 1)*c.brace_weld_leg])
            lines.append({'id':f'{kind}_{"positive" if sign>0 else "negative"}', 'location':kind,
                          'face':sign,'z':sign*c.plate_t/2,'v':v,'start':xy(u0,v),'end':xy(u1,v),
                          'length':L,'force_fraction':f/count,'force_fraction_of_angle':f,'footprint_v':[vlo,vhi]})
    brcorn=[xy(u,v) for u in (u0,u1) for v in (vh-c.brace_weld_leg,vt+c.brace_weld_leg)]
    foot=[xy(u0-c.brace_free_end_extension,v) for v in (vh,vt)]
    hc=col['d']-2*col['tf'];bs=c.continuity_width;clip=c.continuity_clip;zweb=col['tw']/2
    cpL=hc-2*(clip+c.continuity_web_end_margin)
    fl0=zweb+clip+c.continuity_flange_start_margin;fl1=zweb+bs-c.continuity_flange_end_margin
    zload=(fl0+fl1)/2;zbar=zweb+bs/2
    cp={'width':bs,'t':c.continuity_t,'clip':clip,'net_width':bs-clip,
        'depth':hc,'x_range':[-hc/2,hc/2],'web_x_range':[-cpL/2,cpL/2],
        'web_length':cpL,'flange_z_range':[fl0,fl1],'flange_length':fl1-fl0,
        'z_web':zweb,'z_load':zload,'z_bar':zbar,'e':zload-zweb,
        'd':zbar-zweb,'delta':zload-zbar,'levels_y':[(b['d']-b['tf'])/2,-(b['d']-b['tf'])/2],
        'count_per_level':2,'z_ranges':[[zweb,zweb+bs],[-zweb-bs,-zweb]],
        'outer_z':zweb+bs,'all_edges_two_sided':True,'fitted_contact_credit':False}
    spread=L*math.tan(math.pi/6);whit=[vh-spread,vt+spread]
    supports={'beam':[uv(poly[0]),uv(poly[1])],'column':[uv(poly[3]),uv(poly[4])]}
    result={'beam':b,'column':col,'angle':a,'eb':eb,'ec':ec,'polygon':poly,'poly_uv':[uv(p) for p in poly],
            'beam_seam':beam,'column_seam':column,'alpha':sum(p[0] for p in beam)/2-ec,
            'beta':sum(p[1] for p in column)/2-eb,'beam_seam_length':beam[1][0]-beam[0][0],
            'column_seam_length':column[1][1]-column[0][1],'brace_lines':lines,'brace_weld_lines':lines,
            'brace_footprint':brcorn,'brace_free_end':foot,'brace_u_range':[u0,u1],
            'brace_v_range':[vh,vt],'brace_force_point':xy(0.,-off),'support_edges_uv':supports,
            'brace_footprint_contained':all(_inside(p,poly) for p in brcorn+foot),
            'continuity':cp,'whitmore':{'u':u0,'v_range':whit,'width':whit[1]-whit[0],
                'centroid_v':sum(whit)/2,'ends':[xy(u0,v) for v in whit],
                'contained':all(_inside(xy(u0,v),poly) for v in whit)},
            'workpoint':[0.,0.], 'joint_point':[ec,0.], 'beam_web_weld':[ [ec,-c.beam_web_weld_length/2],[ec,c.beam_web_weld_length/2] ],
            'angle_basis':{'cos':co,'sin':si},'units':dict(UNITS)}
    if single:
        sign=faces[0];zface=sign*c.plate_t/2
        # Nominal L outline only: published rolled root/toe radii stay unknown.
        outline=[(vh,0.),(vt,0.),(vt,a['t']),(vh+a['t'],a['t']),
                 (vh+a['t'],a['leg']),(vh,a['leg'])]
        idealization=_single_angle_idealization(c,a,co,si)
        result.update(brace_angle_count=1,brace_weld_count=2,brace_connected_surface_z=[zface],
                      brace_centroid_z=sign*(c.plate_t/2+a['centroid']),
                      brace_angle_z_bounds=sorted([zface,zface+sign*a['leg']]),
                      brace_angle_section_vz=[[v,zface+sign*z] for v,z in outline],
                      brace_angle_section_basis='nominal leg outline; catalog area/centroid; no measured root/toe radii',
                      nominal_connection_axis_z=0.,spatial_idealization=idealization)
    if is_bolted(c):
        from .bolted_corner import adapt_geometry
        result=adapt_geometry(c,result)
    return result


def _action(point,Fx,Fy,M=0.,**more):
    return dict(point=list(point),Fx=Fx,Fy=Fy,M=M,**more)


def _resultant(actions,about=(0.,0.)):
    return [sum(a['Fx'] for a in actions),sum(a['Fy'] for a in actions),
            sum(a['M']+(a['point'][0]-about[0])*a['Fy']-(a['point'][1]-about[1])*a['Fx'] for a in actions)]


def _real_roots(poly,lo,hi):
    if poly.degree()<1:return []
    return sorted(float(v.real) for v in poly.roots() if abs(v.imag)<1e-7 and lo+1e-9<v.real<hi-1e-9)


def _check(out,id,D,R,source,component=None,**detail):
    D=abs(float(D));R=float(R)
    if not math.isfinite(D) or not math.isfinite(R):raise ArithmeticError('Resultado de componente fora do domínio numérico finito.')
    ratio=D/R if R>0 else (0. if D==0 and R==0 else None)
    passed=ratio is not None and ratio<=1+1e-9
    row={'id':id,'component':component or id.split('_')[0],'demand':D,'resistance':R,
         'utilization':ratio,'utilization_unbounded':ratio is None,'status':'PASS' if passed else 'FAIL','pass_':passed,
         'source':source,'detail':detail}
    row.update(detail)
    out['checks'].append(row)
    return row


def _issue(out,id,severity,message,**detail):
    out['issues'].append(dict(id=id,severity=severity,message=message,**detail))


def _weld_q(c,s,fw):return s/math.sqrt(2)*.6*fw/c.gamma_w2


def _block(c,Av,At,mat):
    return min(.6*mat['fu']*Av+.5*mat['fu']*At,.6*mat['fy']*Av+.5*mat['fu']*At)/c.gamma_a2


def receiving_union(zones,k,fy,tw,gamma=1.1,spread=5.):
    """One local-yield capacity for each connected set of spread footprints.
    zones are (actual_start, actual_end, signed_force); no favorable cancellation.
    """
    ordered=sorted((min(a,b),max(a,b),f) for a,b,f in zones)
    groups=[]
    for a,b,f in ordered:
        if groups and a-spread*k/2<=groups[-1]['end']+spread*k/2+1e-9:
            group=groups[-1];group['end']=max(group['end'],b);group['demand']+=abs(f);group['forces'].append(f)
        else:groups.append({'start':a,'end':b,'demand':abs(f),'forces':[f]})
    for group in groups:
        group['span']=group['end']-group['start'];group['resistance']=1.10*(group['span']+spread*k)*fy*tw/gamma
        group['utilization']=group['demand']/group['resistance']
    return groups


def _body_sections(c,g,forces,out):
    """Integrate physical line tractions on the retained +u side of every cut.
    Convex clipped rectangle gives affine chord edges between vertex stations.
    Exact rational-polynomial stationary equations close N/V/M section extrema.
    """
    co=g['angle_basis']['cos'];si=g['angle_basis']['sin'];poly=g['poly_uv']
    def uv(p):return [co*p[0]+si*p[1],-si*p[0]+co*p[1]]
    sources=[]
    for line in g['brace_lines']:
        sources.append({'ends':[uv(line['start']),uv(line['end'])],'Nu':c.P*line['force_fraction'],'Vv':0.,'id':line['id']})
    for label,Fx,Fy in [('beam',-forces['Hb'],-forces['Vb']),('column',-forces['Hc'],-forces['Vc'])]:
        sources.append({'ends':[uv(p) for p in g[label+'_seam']],'Nu':co*Fx+si*Fy,'Vv':-si*Fx+co*Fy,'id':label+'_support'})
    start=g['brace_u_range'][0];end=max(g['brace_u_range'][1],max(p[0] for s in sources for p in s['ends']))
    stations=sorted({start,end}|{p[0] for p in poly if start<p[0]<end}|{p[0] for s in sources for p in s['ends'] if start<p[0]<end})
    rows=[];minimum=math.inf;max_sigma=0.;max_tension=0.;max_vm=0.;governing=None
    for lo,hi in zip(stations,stations[1:]):
        if hi-lo<1e-8:continue
        mid=(lo+hi)/2;half=(hi-lo)/2;U=Poly([mid,half]);chlo=_line_intersections(poly,0,lo);chhi=_line_intersections(poly,0,hi)
        if not chlo or not chhi:continue
        VL=Poly([(chlo[0]+chhi[0])/2,(chhi[0]-chlo[0])/2]);VH=Poly([(chlo[1]+chhi[1])/2,(chhi[1]-chlo[1])/2]);W=VH-VL;VC=(VH+VL)/2
        N=Poly([0.]);V=Poly([0.]);M=Poly([0.]);retained=[]
        for s in sources:
            a,b=sorted(s['ends'],key=lambda p:p[0]);ua,ub=a[0],b[0]
            if mid>=ub-1e-10:continue
            if mid<=ua+1e-10:
                frac=Poly([1.]);uc=Poly([(ua+ub)/2]);vc=Poly([(a[1]+b[1])/2])
            elif ub-ua>1e-10:
                frac=(ub-U)/(ub-ua);uc=(ub+U)/2;vc=Poly([b[1]])+(U-ub)*(b[1]-a[1])/(2*(ub-ua))
            else:continue
            n=frac*s['Nu'];v=frac*s['Vv'];N=N+n;V=V+v;M=M+(uc-U)*v-(vc-VC)*n
            retained.append(s['id'])
        for edge in (-1,1):
            num=N*W+edge*6*M
            vmnum=num*num+3*(1.5*V*W)**2
            normal_st=[-1.,1.]+_real_roots(num.deriv()*W-2*num*W.deriv(),-1.,1.)
            vm_st=[-1.,1.]+_real_roots(vmnum.deriv()*W-4*vmnum*W.deriv(),-1.,1.)
            for t in normal_st:
                width=float(W(t))
                if width<=1e-7:continue
                sigma=float(num(t))/(c.plate_t*width**2);minimum=min(minimum,sigma);max_sigma=max(max_sigma,abs(sigma));max_tension=max(max_tension,sigma)
            for t in vm_st:
                width=float(W(t))
                if width<=1e-7:continue
                vm=math.sqrt(max(0.,float(vmnum(t))))/(c.plate_t*width**2)
                row={'u':float(U(t)),'edge':edge,'b':width,'centroid_v':float(VC(t)),
                     'N':float(N(t)),'V':float(V(t)),'M':float(M(t)),'VM':vm,'sources':retained}
                rows.append(row)
                if vm>max_vm:max_vm=vm;governing=row
    if not rows:
        _issue(out,'gusset_body_sections','unverified','Não foi possível fechar as seções físicas do corpo do gusset.');return
    if minimum < -1e-6 and not compression_candidate(c):
        _issue(out,'UNVERIFIED_COMPRESSION_COMPONENT','unverified','Seção física do gusset possui borda comprimida; resistência/estabilidade dessa região não qualificada.',minimum_stress=minimum)
    mg=MATERIALS[c.gusset_steel]
    _check(out,'gusset_actual_body_chord_gross',max_vm,mg['fy']/c.gamma_a1,
           'Seção real do polígono; todas as trações retidas +u; extremos racionais N/V/M exatos',component='gusset',governing=governing,minimum_normal=minimum,stations=stations)
    if not compression_candidate(c) or max_tension>1e-7:
        _check(out,'gusset_actual_body_chord_rupture',max_tension if compression_candidate(c) else max_sigma,mg['fu']/c.gamma_a2,
               'Seção transversal física sem furos; máxima tração real, sem Ct inventado para borda virtual' if compression_candidate(c) else 'Seção transversal física sem furos; tensão máxima, sem Ct inventado para borda virtual',component='gusset',governing=governing)
    out['gusset_body']={'stations':stations,'sources':sources,'candidates':rows,'governing':governing,'minimum_normal':minimum,'peak_normal':max_sigma}


def _tear_paths(c,g,out):
    """Ordinary straight U/L paths, clipped to actual free top/right boundaries.
    Supported contact is never treated as free. Endpoint envelopes apply between
    every polygon, load and support-admissibility transition of each candidate.
    """
    if compression_candidate(c):
        _check(out,'gusset_uniform_run_shear_envelope',-c.P,.6*MATERIALS[c.gusset_steel]['fy']*c.plate_t*c.brace_weld_length/c.gamma_a2,
               'Envelope conservador independente do sentido: ao menos um corte longitudinal tL por trecho uniforme capturado; zero crédito de tração transversal e chapa única',component='gusset')
        out['gusset_paths']={'admissible':[],'rejected_supported':[], 'basis':'compression_direction_independent_uniform_weld_run_shear_only',
                             'inactive':'Blocos antigos de tração para saídas externas inativos; contato retido não é bloco destacado nem pendência automática.'}
        return
    poly=g['poly_uv'];u0,u1=g['brace_u_range'];vh,vt=g['brace_v_range'];sw=c.brace_weld_leg
    fh=1-g['angle']['centroid']/g['angle']['leg'];ft=1-fh
    templates=[('U_both_footprints','U',(vh-sw,vt+sw),1.),('U_heel','U',(vh-sw,vh),fh),
               ('U_toe','U',(vt,vt+sw),ft),('U_between_roots','U',(vh,vt),1.),
               ('L_negative_heel','L',('negative',vh),fh),('L_negative_both','L',('negative',vt+sw),1.),
               ('L_positive_toe','L',('positive',vt),ft),('L_positive_both','L',('positive',vh-sw),1.)]
    rows=[];rejected=[]
    for name,kind,limits,f in templates:
        base=[((0.,1.),limits[0]),((0.,-1.),-limits[1])] if kind=='U' else [((0.,-1.),-limits[1])] if limits[0]=='negative' else [((0.,1.),limits[1])]
        stations={u0,u1}|{p[0] for p in poly if u0<p[0]<u1}
        # A support enters/leaves this lateral strip only at an actual edge or
        # its intersection with the candidate's longitudinal cut boundaries.
        for edge in g['support_edges_uv'].values():
            a,b=edge
            for p in edge:
                if u0<p[0]<u1:stations.add(p[0])
            for n,k in base:
                da=n[0]*a[0]+n[1]*a[1]-k;db=n[0]*b[0]+n[1]*b[1]-k
                if da*db<0:
                    t=da/(da-db);u=a[0]+t*(b[0]-a[0])
                    if u0<u<u1:stations.add(u)
        for u in sorted(stations):
            if u>=u1-1e-9:continue
            chord=_line_intersections(poly,0,u)
            if not chord:continue
            planes=[((1.,0.),u)]+base
            hits=_support_overlap(g['support_edges_uv'],planes)
            if hits:
                rejected.append({'id':name,'u':u,'reason':'retains_supported_contact','support_overlap':hits});continue
            if kind=='U':
                a,b=limits;exa=_line_intersections(poly,1,a);exb=_line_intersections(poly,1,b)
                if not exa or not exb or min(exa[1],exb[1])<u-1e-8 or a<chord[0]-1e-8 or b>chord[1]+1e-8:continue
                shear=exa[1]+exb[1]-2*u;tension=b-a
                path=[[exa[1],a],[u,a],[u,b],[exb[1],b]]
            else:
                side,v=limits;ex=_line_intersections(poly,1,v)
                if not ex or ex[1]<u-1e-8 or not chord[0]-1e-8<=v<=chord[1]+1e-8:continue
                bound=chord[0] if side=='negative' else chord[1]
                shear=ex[1]-u;tension=abs(bound-v);path=[[ex[1],v],[u,v],[u,bound]]
            polygon=poly[:]
            for n,k in planes:polygon=_clip(polygon,n,k)
            D=c.P*f*max(0.,min(1.,(u1-u)/c.brace_weld_length));Av=c.plate_t*shear;At=c.plate_t*tension
            mat=MATERIALS[c.gusset_steel];R=_block(c,Av,At,mat)
            row={'id':name,'u':u,'kind':kind,'path_uv':path,'block_uv':polygon,'Agv':Av,'Anv':Av,'Ant':At,'Cts':.5,
                 'demand':abs(D),'resistance':R,'utilization':abs(D)/R if R>0 else math.inf,'support_overlap':[]}
            rows.append(row)
        candidates=[r for r in rows if r['id']==name]
        if candidates:
            worst=max(candidates,key=lambda r:r['utilization'])
            _check(out,'gusset_tear_'+name,worst['demand'],worst['resistance'],'NBR6.5.6 dois ramos; caminho U/L que termina em bordas livres reais',component='gusset',path=worst)
    if not rows:
        _issue(out,'gusset_ordinary_tear_family','unverified','Nenhum bloco U/L destacado fechou sem contacto apoiado; família de ruptura precisa avaliação específica.')
    # For any admissible ordinary path capturing a uniform weld portion, at
    # least one longitudinal cut spans that portion. Drop all transverse
    # resistance and free-end extensions, using the TOTAL brace force once.
    _check(out,'gusset_ordinary_partial_path_envelope',abs(c.P),.6*MATERIALS[c.gusset_steel]['fy']*c.plate_t*c.brace_weld_length/c.gamma_a2,
           'Limite conservador de caminhos longitudinais/transversais ordinários; uma área de cisalhamento tL e zero crédito transversal',component='gusset')
    out['gusset_paths']={'admissible':rows,'rejected_supported':rejected,'basis':'actual_polygon_supported_contact_exclusion'}


def _continuity_sections(c,g,F,label,out):
    cp=g['continuity'];L=cp['web_length'];b=cp['width'];th=cp['t'];d=cp['d'];delta=cp['delta'];e=cp['e'];p=F/2
    N=p*Poly([.5,.5]);V=p*(1.5*e/L)*Poly([1.,0.,-1.]);M=p*Poly([delta/2,d/4+3*delta/4,0.,-e/4])
    A=b*th;Z=th*b*b/6;ta=1.5*V/A;candidates=[];normals=[]
    for sign in (-1,1):
        sig=N/A+sign*M/Z;vm2=sig*sig+3*ta*ta
        for t in [-1.,1.]+_real_roots(sig.deriv(),-1.,1.):normals.append(float(sig(t)))
        for t in [-1.,1.]+_real_roots(vm2.deriv(),-1.,1.):
            candidates.append({'t':t,'edge':sign,'VM':math.sqrt(max(0.,float(vm2(t)))),'N':float(N(t)),'V':float(V(t)),'M':float(M(t))})
    # Outside the web weld all N=p,V=0. In the loaded-side root clip,
    # the remaining width q decreases b to b-clip, shifting its centroid.
    # zbar(q)=zweb+b-q/2; M=p*(zload-zbar(q)). Rational extrema in q.
    bn=b-cp['clip'];K=cp['z_load']-cp['z_web']-b
    clips=[]
    for sign in (-1,1):
        # sigma = p/th * [(1+3sign)/q +6sign*K/q²]
        qa=1+3*sign;qb=6*sign*K;qs=[bn,b]
        if abs(qa)>1e-12:
            stationary=-2*qb/qa
            if bn<stationary<b:qs.append(stationary)
        for q in qs:
            stress=p/th*(qa/q+qb/q**2);normals.append(stress);clips.append({'width':q,'edge':sign,'sigma':stress})
    governing=max(candidates,key=lambda r:r['VM']);clippeak=max(abs(r['sigma']) for r in clips)
    _check(out,'continuity_'+label+'_plate_equilibrated_NVM',max(governing['VM'],clippeak),MATERIALS[c.continuity_steel]['fy']/c.gamma_a1,
           'Equilíbrio de cada placa; coeficientes derivados de zload/zweb/zbar; extremos exatos no trecho retangular e recortes terminais',component='continuity',governing=governing,terminal_clip_peak=clippeak,minimum_normal=min(normals),maximum_normal=max(normals))
    return {'name':label,'F_each':p,'webline_e':e,'M_web':p*e,'N_poly':N.coef.tolist(),'V_poly':V.coef.tolist(),'M_poly':M.coef.tolist(),
            'web_weld_demand_multiplier':math.sqrt(1+(6*e/L)**2),'governing':governing,'clip_candidates':clips,
            'minimum_normal':min(normals),'maximum_normal':max(normals),'end_resultants':[[float(a(t)) for a in (N,V,M)] for t in (-1.,1.)]}


def _column_fields(c,g,forces,ft,fb,nw,joint,upper,lower):
    ec=g['ec'];cp=g['continuity'];wl=c.beam_web_weld_length
    sources=[{'ends':g['column_seam'],'Fx':forces['Hc'],'Fy':forces['Vc'],'M':0.},
             {'ends':[[ec,-wl/2],[ec,wl/2]],'Fx':nw,'Fy':joint['Fy'],'M':0.}]
    points=[upper,_action([ec,cp['levels_y'][0]],ft,0.),_action([ec,cp['levels_y'][1]],fb,0.)]
    points.extend(a for a in c.other_loads if a['member']=='column')
    low=c.lower_column_cut_y;high=c.upper_column_cut_y
    stations=sorted({low,high}|{p[1] for s in sources for p in s['ends'] if low<p[1]<high}|{a['point'][1] for a in points if low<a['point'][1]<high})
    values=[]
    for lo,hi in zip(stations,stations[1:]):
        mid=(lo+hi)/2;half=(hi-lo)/2;Y=Poly([mid,half]);X=Poly([0.]);N=Poly([0.]);M=Poly([0.])
        for a in points:
            if a['point'][1]>mid:
                X+=a['Fx'];N+=a['Fy'];M+=a['M']+a['point'][0]*a['Fy']-(a['point'][1]-Y)*a['Fx']
        for s in sources:
            a,b=sorted(s['ends'],key=lambda p:p[1]);ya,yb=a[1],b[1]
            if mid>=yb:continue
            if mid<=ya:frac=Poly([1.]);yc=Poly([(ya+yb)/2])
            else:frac=(yb-Y)/(yb-ya);yc=(yb+Y)/2
            fx=frac*s['Fx'];fy=frac*s['Fy'];X+=fx;N+=fy;M+=ec*fy-(yc-Y)*fx
        ts={-1.,1.}|set(_real_roots(M.deriv(),-1.,1.))
        for t in sorted(ts):values.append({'y':float(Y(t)),'Q':-float(X(t)),'N':-float(N(t)),'M':-float(M(t))})
    compression=max([0.]+[v['N'] for v in values]);maxmoment=max([abs(upper['M']+upper['point'][0]*upper['Fy']),abs(lower['M']+lower['point'][0]*lower['Fy'])]+[abs(v['M']) for v in values])
    return {'stations':stations,'candidates':values,'maximum_compression':compression,'maximum_abs_moment':maxmoment}


def _finish(out):
    # Compact summaries retain the physical receiver/root identity, while
    # detailed checks keep their stable audit IDs.
    for row in out['checks']:
        component=row['component'];name=row['id']
        if component=='brace':row['component']='angles' if name.startswith('angle_') else 'brace_welds'
        elif component=='root_seams':row['component']='beam_root' if name.startswith('beam_') else 'column_root'
        elif component=='receivers':
            row['component']='continuity_receiver' if name.startswith('continuity_') or '_continuity_contact_' in name else 'beam_receiver' if name.startswith('beam_') else 'column_receiver'
        elif component=='beam_column_joint':row['component']='beam_joint'
        elif component=='continuity':row['component']='continuity_welds' if name.endswith('_weld') or name.endswith('_base_shear') else 'continuity_plates'
        elif component=='member_web_shear':row['component']='beam_web_shear' if name.startswith('beam_') else 'column_web_shear'
    summaries=[]
    for component in dict.fromkeys(r['component'] for r in out['checks']):
        rows=[r for r in out['checks'] if r['component']==component]
        required=[r for r in rows if not r.get('diagnostic_only')]
        governing=max(required or rows,key=lambda r:float('inf') if r['utilization'] is None else r['utilization'])
        summaries.append({'component':component,'governing_id':governing['id'],'check':governing['id'],
                          'utilization':governing['utilization'],'status':governing['status'] if required else 'DIAGNOSTIC_ONLY','demand':governing['demand'],'resistance':governing['resistance'],'diagnostic_only':all(r.get('diagnostic_only',False) for r in rows)})
    sev={i['severity'] for i in out['issues']}
    if 'invalid_geometry' in sev or 'invalid_input' in sev:status='INVALID'
    elif any(r['status']=='FAIL' and not r.get('diagnostic_only') for r in out['checks']) or 'detail_fail' in sev:status='FAIL'
    elif 'unverified' in sev or 'outside_scope' in sev or 'detail_pending' in sev:status='UNVERIFIED'
    else:status='PASS'
    strength_rows=[r for r in out['checks'] if r['component']!='detailing' and not r.get('diagnostic_only')]
    governing=max(strength_rows,key=lambda r:float('inf') if r['utilization'] is None else r['utilization'],default=None)
    out.update(status=status,utilization=governing['utilization'] if governing else 0.,utilization_unbounded=bool(governing and governing['utilization'] is None),
               component_summary=summaries,all_listed_checks_pass=all(r['status']=='PASS' for r in out['checks']),
               all_required_checks_pass=all(r['status']=='PASS' for r in out['checks'] if not r.get('diagnostic_only')),
               approved=status=='PASS',complete=status in ('PASS','FAIL') and not (sev & {'unverified','outside_scope','invalid_geometry','invalid_input','detail_pending'}),governing=governing)
    return out


def analyze(c):
    out={'family':FAMILY,'connection_type':CONNECTION_TYPE,'component_version':COMPONENT_VERSION,
         'checks':[],'issues':[],'geometry':{},'forces':{},'assumptions':fixed_assumptions(),'exclusions':list(EXCLUSIONS)}
    single=isinstance(c,CornerGusset) and is_single(c)
    bolted=is_bolted(c)
    compression=compression_candidate(c)
    if compression:
        out['exclusions'][-1]=('Compressão local apenas no canto ordinário 2L-T com extremidade parafusada por atrito, contato direto, intervalos curtos e contenções físicas documentadas. 1L/opostas, afastamento real, sismo/fadiga, estabilidade global e costuras intermediárias não qualificados.' if bolted else 'Compressão local apenas no canto ordinário 2L-T continuamente soldado, com contenções físicas declaradas. 1L/parafusada, afastamento real, sismo/fadiga e estabilidade global não qualificados.')
    if single:
        out['family']='Ligação de canto 1L–gusset–viga/pilar · soldada'
        out['assumptions']=fixed_assumptions(c.topology)
    if bolted:
        out['family']='Ligação de canto '+('1L' if single else '2L-T')+'–gusset–viga/pilar · parafusada'
        out['assumptions']=fixed_assumptions(c.topology)
    errors=input_errors(c)
    if errors:
        for e in errors:_issue(out,'input','invalid_input',e)
        return _finish(out)
    angle_count=1 if single else 2
    positive=('fw_brace','fw_root','fw_joint','fw_continuity','E','gamma_a1','gamma_a2','gamma_w2','plate_width','plate_height','plate_t',
              'root_weld_leg','brace_weld_start','brace_weld_length','brace_weld_leg','beam_web_weld_length','beam_web_weld_leg',
              'continuity_width','continuity_t','continuity_flange_weld_leg','continuity_web_weld_leg')
    if bolted:
        positive=tuple(k for k in positive if k not in ('fw_brace','brace_weld_start','brace_weld_length','brace_weld_leg'))+('bolt_start','bolt_pitch','bolt_diameter','bolt_gauge','bolt_angle_end','bolt_tool_radius')
    if any(getattr(c,k)<=0 for k in positive):
        _issue(out,'positive_dimensions','invalid_geometry','Dimensões, módulo, resistências e coeficientes devem ser positivos.');return _finish(out)
    nonnegative=('corner_clip','beam_seam_start_margin','beam_seam_end_margin','column_seam_start_margin','column_seam_end_margin','brace_free_end_extension',
                 'beam_access_radius','continuity_clip','continuity_flange_start_margin','continuity_flange_end_margin','continuity_web_end_margin')
    if any(getattr(c,k)<0 for k in nonnegative):
        _issue(out,'nonnegative_clearances','invalid_geometry','Recortes e margens devem ser não negativos.');return _finish(out)
    a=get_angle(c.angle_profile)
    if not a or a['Ag'] is None or a['centroid'] is None:
        _issue(out,'angle_catalog_properties','unverified','Catálogo não fornece Ag/centróide; não são estimados.');return _finish(out)
    g=geometry(c);out['geometry']=g;b=g['beam'];col=g['column'];a=g['angle'];cp=g['continuity']
    if single or bolted:out['spatial_idealization']=g['spatial_idealization']
    for label,member in [('beam',b),('column',col)]:
        if member['family']!='W':
            _issue(out,label+'_member_family','unverified','Ramo qualificado para perfil W laminado; perfil montado/outra família requer soldas de fabricação e verificações próprias.',profile=member['name'],family=member['family'])
    if min(g['beam_seam_length'],g['column_seam_length'],g['alpha'],g['beta'],cp['web_length'],cp['flange_length'],cp['net_width'])<=0:
        _issue(out,'effective_lengths','invalid_geometry','Comprimentos úteis e larguras líquidas devem ser positivos.');return _finish(out)
    if c.corner_clip>=min(c.plate_width,c.plate_height):
        _issue(out,'gusset_clip','invalid_geometry','Recorte interno elimina a aresta apoiada.');return _finish(out)
    if c.continuity_clip>cp['depth']/2:
        _issue(out,'continuity_clip_family','unverified','Recortes cruzam o trecho retangular central da placa de continuidade.');return _finish(out)
    if not 0<c.phi_deg<90:
        _issue(out,'brace_direction','outside_scope','Topologia de canto superior/direito exige a diagonal afastando-se do nó em ambos os eixos.')
    if single and c.symmetric:
        _issue(out,'brace_adapter','outside_scope','Uma cantoneira exige symmetric=False; não se credita simetria nem segunda face resistente.')
    elif not single and (not c.symmetric or c.topology not in ('symmetric_2L_T_welded','symmetric_2L_T_bolted')):
        _issue(out,'brace_adapter','outside_scope','Somente duas cantoneiras idênticas em T, uma por face, soldadas e simétricas são qualificadas.')
    if c.load_convention!='COMPLETE_CUTS':
        _issue(out,'load_convention','unverified','Informar ações completas concorrentes nos cortes nomeados; não se aceita N0/V0/M0 redundante.');return _finish(out)
    if not c.other_loads_excluded and not c.other_loads:
        _issue(out,'missing_other_loads','unverified','Outras ações entre cortes não foram fornecidas nem explicitamente excluídas; desconhecido não é zero.');return _finish(out)
    if c.other_loads_excluded and c.other_loads:
        _issue(out,'contradictory_loads','invalid_input','Lista de outras ações é incompatível com a declaração de nenhuma outra ação.');return _finish(out)
    if abs(c.workpoint_offset)>1e-9:
        _issue(out,'UNVERIFIED_ECCENTRIC_DISTRIBUTION','unverified','Linha de força excêntrica requer redistribuição DG29§4.2.2; esforços UFM concêntricos abaixo são somente diagnóstico.',additional_M=c.P*c.workpoint_offset)
    if c.P<0 and not compression:_issue(out,'UNVERIFIED_BRACE_COMPRESSION','unverified','Compressão da diagonal exige estabilidade e ligação próprias; não se usa resistência de tração como aprovação.')
    if not g['brace_footprint_contained']:_issue(out,'brace_footprint_containment','invalid_geometry','Pegada real de solda/cantoneira ultrapassa o contorno do gusset.')
    if not bolted and not compression and not g['whitmore']['contained']:_issue(out,'whitmore_containment','unverified','Faixa completa de Whitmore ultrapassa o contorno; precisa avaliar faixa reduzida e distribuição própria.')
    if not c.matching_cjp:_issue(out,'beam_flange_weld','unverified','Solda de mesa precisa CJP compatível, garganta total e WPS; outro grupo não foi dimensionado.')
    if not c.lateral_restraint:_issue(out,'column_web_sidesway','unverified','Sem contenção lateral relativa declarada, NBR5.7.5 não pode ser dispensada.')
    # Physical bounds, independently of numerical resistance.
    root_projection=max(0.,(col['d']-col['clear'])/2-col['tf'])
    if c.continuity_clip+1e-8<root_projection:
        _issue(out,'continuity_root_clip_clearance','invalid_geometry','Recorte da continuidade não libera a região de raiz delimitada pela altura livre publicada.',required_projection=root_projection)
    if c.corner_clip+1e-8<max(c.root_weld_leg,root_projection):
        _issue(out,'gusset_inner_corner_clearance','invalid_geometry','Recorte interno insuficiente para os filetes/região física da raiz.')
    if b['bf']>col['bf']+1e-8:_issue(out,'beam_flange_receiver_fit','invalid_geometry','Mesa da viga ultrapassa a largura receptora do pilar.')
    if c.plate_t+2*c.root_weld_leg>min(b['bf'],col['bf']):_issue(out,'gusset_root_face_fit','invalid_geometry','Chapa e contatos dos filetes não cabem na mesa receptora.')
    if not bolted and a.get('toe_flat') is not None and c.brace_weld_leg>a['toe_flat']:_issue(out,'brace_toe_flat','invalid_geometry','Filete excede a face de ponta publicada da cantoneira.')
    if cp['outer_z']>col['bf']/2+1e-8:_issue(out,'continuity_flange_fit','invalid_geometry','Placa de continuidade ultrapassa a mesa real do pilar.')
    if c.beam_web_weld_length/2+c.beam_access_radius>(b['d']/2-b['tf'])+1e-8:_issue(out,'beam_web_access','invalid_geometry','Solda de alma/alívio não cabe entre faces internas das mesas.')
    upper_contact=max(g['polygon'][3][1],b['d']/2,cp['levels_y'][0]+c.continuity_t/2+max(c.continuity_flange_weld_leg,c.continuity_web_weld_leg))
    lower_contact=min(-b['d']/2,cp['levels_y'][1]-c.continuity_t/2-max(c.continuity_flange_weld_leg,c.continuity_web_weld_leg))
    if c.beam_cut_x<g['polygon'][1][0] or c.upper_column_cut_y<upper_contact or c.lower_column_cut_y>lower_contact:
        _issue(out,'complete_cut_positions','invalid_geometry','Os cortes nomeados devem envolver os contatos apoiados físicos inteiros, inclusive além das extremidades efetivas das soldas.',beam_contact_end=g['polygon'][1][0],column_contact_limits=[lower_contact,upper_contact])
    if c.column_end_top<upper_contact or c.column_end_bottom>lower_contact:
        _issue(out,'physical_supported_contact_end','invalid_geometry','Contato apoiado declarado ultrapassa a extremidade física do pilar; não pode permanecer artificialmente apoiado nos caminhos de ruptura.',column_contact_limits=[lower_contact,upper_contact])
    for action in c.other_loads:
        x,y=action['point']
        valid=(g['ec']<=x<=c.beam_cut_x) if action['member']=='beam' else (c.lower_column_cut_y<=y<=c.upper_column_cut_y)
        if not valid:
            _issue(out,'other_load_outside_cuts','invalid_geometry','Ação adicional fora dos cortes completos declarados; ampliar os cortes ou corrigir a ação.',label=action['label'],point=list(action['point']))
    if c.column_end_top<c.upper_column_cut_y or c.column_end_bottom>c.lower_column_cut_y:
        _issue(out,'column_physical_ends','invalid_geometry','Extremidades físicas não abrangem os cortes nomeados.')
    for kind,key,th,rolled in [('angle','angle_steel',a['t'],True),('gusset','gusset_steel',c.plate_t,False),('beam','beam_steel',max(b['tf'],b['tw']),True),('column','column_steel',max(col['tf'],col['tw']),True),('continuity','continuity_steel',c.continuity_t,False)]:
        steel=STEELS[getattr(c,key)];allowed=steel.rolled_allowed if rolled else steel.plate_allowed
        mn=steel.profile_min if rolled else steel.plate_min;mx=steel.profile_max if rolled else steel.plate_max
        if not allowed or not all(mn<=value<=mx for value in ([b['tf'],b['tw']] if kind=='beam' else [col['tf'],col['tw']] if kind=='column' else [th])):_issue(out,kind+'_steel_product','invalid_input','Aço/produto/espessura fora dos limites publicados da seleção independente.')
    def detail(id,demand,resistance,source):return _check(out,id,demand,resistance,source,component='detailing')
    def minfillet(t):return 3. if t<=6.3 else 5. if t<=12.5 else 6. if t<=19 else 8.
    welds=[('brace',c.brace_weld_leg,a['t'],min(a['t'],c.plate_t),c.brace_weld_length),
           ('beam_root',c.root_weld_leg,c.plate_t,min(c.plate_t,b['tf']),g['beam_seam_length']),
           ('column_root',c.root_weld_leg,c.plate_t,min(c.plate_t,col['tf']),g['column_seam_length']),
           ('joint_web',c.beam_web_weld_leg,b['tw'],min(b['tw'],col['tf']),c.beam_web_weld_length),
           ('continuity_flange',c.continuity_flange_weld_leg,c.continuity_t,min(c.continuity_t,col['tf']),cp['flange_length']),
           ('continuity_web',c.continuity_web_weld_leg,c.continuity_t,min(c.continuity_t,col['tw']),cp['web_length'])]
    if bolted:welds=[w for w in welds if w[0]!='brace']
    for name,s,edge,thin,L in welds:
        detail(name+'_minimum_fillet',minfillet(thin),s,'NBR6.2.6 filete mínimo pela peça menos espessa')
        detail(name+'_maximum_fillet',s,edge if edge<6.3 else edge-1.5,'NBR6.2.6 borda nominal sem reforço')
        detail(name+'_minimum_weld_length',max(40.,4*s),L,'NBR6.2.6 comprimento efetivo mínimo')
        domain=detail(name+'_long_weld_limit',L,100*s,'Domínio implementado L/s<=100; solda longa não é proibida, redução/aplicabilidade requer ramo próprio')
        domain['method_domain']=True
        if L>100*s+1e-8:
            domain['status']='UNVERIFIED';domain['pass_']=False
            _issue(out,name+'_long_weld_branch','unverified','Solda longa fora do ramo avaliado: determinar redução/distribuição ou justificar não aplicabilidade à orientação da carga.',length=L,leg=s,length_over_leg=L/s)
    def cjp_minimum_electrode(steel,thickness):
        if steel=='ASTM A36':return 415. if thickness<=19. else 485.
        if steel in ('ASTM A572 Gr.42','ASTM A572 Gr.50','ASTM A572 Gr.55','ASTM A992'):return 485.
        if steel in ('ASTM A572 Gr.60','ASTM A572 Gr.65','ASTM A913 Gr.50','ASTM A913 Gr.60','ASTM A913 Gr.65'):return 550.
        return None
    electrode_requirements=[cjp_minimum_electrode(c.beam_steel,b['tf']),cjp_minimum_electrode(c.column_steel,col['tf'])]
    if any(v is None for v in electrode_requirements):
        _issue(out,'CJP_steel_electrode_compatibility','unverified','Compatibilidade CJP aço/consumível não qualificada para a combinação selecionada; não se infere de fu isolado.')
    else:
        detail('joint_CJP_electrode_compatibility',max(electrode_requirements),c.fw_joint,'NBR Tabela8 classes mínimas compatíveis; sem usar exceção de grupo inferior misto')
    if not bolted and not compression:detail('brace_shear_lag_length',a['leg'],c.brace_weld_length,'Comprimento longitudinal >= largura da perna conectada')
    elif bolted:
        from .bolted_corner import detailing
        detailing(c,g,out)
    detail('continuity_minimum_width',max(b['bf'],col['bf'])/3-col['tw']/2,c.continuity_width,'NBR5.7.9.5 largura incluindo mesa real do pilar')
    detail('continuity_minimum_thickness',max(col['tf']/2,b['tf']/2,c.continuity_width/16),c.continuity_t,'NBR5.7.9.5 espessura mínima')
    detail('continuity_outstand_compactness',c.continuity_width/c.continuity_t,.56*math.sqrt(c.E/MATERIALS[c.continuity_steel]['fy']),'NBR Tabela4 grupo AL4; inclui pequena borda comprimida por flexão')
    # Generalized force field at the ACTUAL effective seam centroids.
    co=g['angle_basis']['cos'];si=g['angle_basis']['sin'];H=c.P*co;V=c.P*si
    Hc=g['ec']*V/(g['eb']+g['beta']);Hb=H-Hc;Vb=g['eb']*Hb/g['alpha'];Vc=V-Vb
    forces=dict(H=H,V=V,Hb=Hb,Vb=Vb,Hc=Hc,Vc=Vc)
    if min(Vb,Hc)<-1e-8 and not compression:_issue(out,'UNVERIFIED_COMPRESSION_COMPONENT','unverified','Ação normal negativa em aresta do gusset ativa compressão/estabilidade ainda não qualificadas.',beam_normal=Vb,column_normal=Hc)
    if compression:
        from .corner_compression import evaluate as evaluate_compression
        evaluate_compression(c,g,forces,out)
    B=[g['ec']+g['alpha'],g['eb']];C=[g['ec'],g['eb']+g['beta']];J=g['joint_point']
    bc=_action([c.beam_cut_x,c.beam_cut_y],c.beam_cut_Fx,c.beam_cut_Fy,c.beam_cut_M)
    upper=_action([c.upper_column_cut_x,c.upper_column_cut_y],c.upper_column_cut_Fx,c.upper_column_cut_Fy,c.upper_column_cut_M)
    beam_other=[a for a in c.other_loads if a['member']=='beam'];column_other=[a for a in c.other_loads if a['member']=='column']
    beam_actions=[bc,_action(B,Hb,Vb)]+beam_other
    tj=_resultant(beam_actions,J);T=_action(J,*tj)
    colgus=_action(C,Hc,Vc);cr=_resultant([upper,T,colgus]+column_other,[c.lower_column_cut_x,c.lower_column_cut_y])
    lower=_action([c.lower_column_cut_x,c.lower_column_cut_y],*[-r for r in cr])
    brace=_action(g['brace_force_point'],H,V)
    residuals={'gusset':_resultant([brace,_action(B,-Hb,-Vb),_action(C,-Hc,-Vc)]),
               'beam':_resultant(beam_actions+[_action(J,-T['Fx'],-T['Fy'],-T['M'])]),
               'column':_resultant([upper,lower,T,colgus]+column_other),
               'assembly':_resultant([bc,upper,lower,brace]+list(c.other_loads))}
    if abs(c.workpoint_offset)<=1e-9 and any(max(abs(v) for v in r)>1e-5 for r in residuals.values()):
        _issue(out,'equilibrium','invalid_input','Resíduos de equilíbrio excedem a tolerância numérica; não aprovar o caso.')
    if c.compare_lower_cut:
        supplied=[c.lower_column_check_Fx,c.lower_column_check_Fy,c.lower_column_check_M]
        expected=[lower[k] for k in ('Fx','Fy','M')]
        if any(abs(x-y)>1e-6*max(1.,abs(y)) for x,y in zip(supplied,expected)):
            _issue(out,'lower_cut_mismatch','invalid_input','Corte inferior Robot não fecha o mesmo caso completo; verifique sinais/cortes/ações omitidas.',derived=expected,supplied=supplied)
    Af=b['bf']*b['tf'];Aw=(b['d']-2*b['tf'])*b['tw'];A0=2*Af+Aw;h0=b['d']-b['tf'];N=T['Fx'];M=T['M'];nw=N*Aw/A0;ft=N*Af/A0-M/h0;fb=N*Af/A0+M/h0
    distribution={'area_basis_rectangles':A0,'catalog_area_extra_uncredited':b['Ag']-A0,'Af':Af,'Aw':Aw,'Nweb':nw,'Ftop':ft,'Fbottom':fb,'h0':h0,
                  'force_residual':ft+fb+nw-N,'moment_residual':(fb-ft)*h0/2-M}
    forces.update(joint=T,beam_cut=bc,upper_column_cut=upper,lower_column_cut=lower,joint_distribution=distribution,
                  equilibrium_residuals=residuals,brace_line_moment=c.P*c.workpoint_offset,
                  double_count_residual_at_J=[Hc,-Vb,0.])
    out.update(forces=forces,force_model={k:forces[k] for k in ('H','V','Hb','Vb','Hc','Vc')},joint_beam_to_column=T,
               complete_cuts={'beam':bc,'column_upper':upper,'column_lower':lower},equilibrium_residuals=residuals,joint_distribution=distribution)
    ma=MATERIALS[c.angle_steel];mg=MATERIALS[c.gusset_steel];mb=MATERIALS[c.beam_steel];mc=MATERIALS[c.column_steel];ms=MATERIALS[c.continuity_steel]
    ga1=c.gamma_a1;ga2=c.gamma_a2;P=c.P;L=c.brace_weld_length;tg=c.plate_t;Pa=P/angle_count;Ct=max(.5,1-a['centroid']/L)
    check=lambda id,D,R,source,**kw:_check(out,id,D,R,source,**kw)
    if bolted:
        from .bolted_corner import calculate
        calculate(c,g,forces,out)
    else:
        angle_prefix='angle_single_' if single else 'angle_each_'
        if compression:
            check(angle_prefix+'local_gross_compression',Pa,a['Ag']*ma['fy']/ga1,'NBR5.3/6.5.4: extremidade local continuamente ligada; estabilidade global da diagonal excluída',component='brace')
            limit=.45*math.sqrt(c.E/ma['fy'])
            row=check(angle_prefix+'compression_local_slenderness',a['leg']/a['t'],limit,'NBR Tabela4 AL3 conservador: largura nominal completa, sem crédito de raio desconhecido',component='brace')
            if row['utilization']>1+1e-9:
                row['status']='UNVERIFIED';row['pass_']=False;row['method_domain']=True
                _issue(out,'angle_compression_effective_area','unverified','b/t excede o limite AL3 conservador; Aef local e contenção da perna esbelta precisam qualificação. A resistência bruta não aprova esse ramo.')
            check(angle_prefix+'uniform_run_shear_envelope',Pa,_block(c,a['t']*L,0.,ma),'Envelope de cisalhamento do trecho soldado uniforme em qualquer sentido; não é bloco de ponta tracionada',component='brace')
        else:
            check(angle_prefix+'gross',Pa,a['Ag']*ma['fy']/ga1,'NBR5.2.2',component='brace')
            check(angle_prefix+'effective_rupture',Pa,Ct*a['Ag']*ma['fu']/ga2,'NBR5.2.2/5.2.5',component='brace',Ct=Ct)
            check(angle_prefix+'nominal_through_leg_block',Pa,_block(c,a['t']*L,0.,ma),'NBR6.5.6 modelo nominal Gerdau; sem crédito de tração transversal',component='brace')
        face_suffix=c.single_angle_face+'_face' if single else 'each_face'
        for label,f in [('heel',1-a['centroid']/a['leg']),('toe',a['centroid']/a['leg'])]:
            check('brace_'+label+'_weld_'+face_suffix,Pa*f,_weld_q(c,c.brace_weld_leg,c.fw_brace)*L,
                  'NBR Tabela9 não direcional; uma ocorrência física na face selecionada' if single else 'NBR Tabela9 não direcional; duas ocorrências físicas',
                  component='brace',force_fraction_of_one_angle=f,physical_count=angle_count)
            for nm,th,mat in [('angle',a['t'],ma),('gusset_face',tg,mg)]:
                area=L*min(c.brace_weld_leg,th/2 if nm=='gusset_face' and not single else th)
                check('brace_'+label+'_'+nm+'_substrate_'+face_suffix,Pa*f,min(.6*mat['fy']*area/ga1,.6*mat['fu']*area/ga2),'NBR6.5.5 substrato nominal local',component='brace',physical_count=angle_count)
        if not compression:
            w=g['whitmore']['width'];ecc=g['whitmore']['centroid_v']+c.workpoint_offset
            sig=abs(P)/(tg*w)+6*abs(P*ecc)/(tg*w*w)
            check('gusset_whitmore_gross_peak_tension',sig,mg['fy']/ga1,'DG29 Whitmore30°; excentricidade retida; NBR6.5.3',component='gusset',b=w,e=ecc,A=tg*w,M=P*ecc)
            check('gusset_whitmore_net_rupture_peak',sig,mg['fu']/ga2,'Supplemental Whitmore gross-stress rupture screen; no Ct1 inferred merely from no holes',component='gusset')
            if P/(tg*w)-6*abs(P*ecc)/(tg*w*w)<-1e-7:_issue(out,'whitmore_compression','unverified','Borda da seção Whitmore comprimida exige verificação específica.')
        _body_sections(c,g,forces,out);_tear_paths(c,g,out)
    seams={}
    for label,Ls,normal,shear,mat,member,spread in [('beam',g['beam_seam_length'],Vb,Hb,mb,b,2.5),('column',g['column_seam_length'],Hc,Vc,mc,col,5.)]:
        enddist=min(c.column_end_top-(g['eb']+g['beta']),g['eb']+g['beta']-c.column_end_bottom) if label=='column' else 0.
        spread=5. if label=='column' and enddist>member['d'] else 2.5
        A=tg*Ls;qn=normal/Ls;qs=shear/Ls;q=math.hypot(qn,qs);s=c.root_weld_leg;ny=mg['fy']*A/ga1;sy=.6*mg['fy']*A/ga1
        check(label+'_root_weld',1.25*q,2*_weld_q(c,s,c.fw_root),'DG29 max(qpeak,1.25qavg); NBR Tabela9 não direcional',component='root_seams',q_raw=q)
        check(label+'_gusset_supported_section_interaction',(normal/ny)**2+(shear/sy)**2,1.,'Conservative N2+V2 inscribed interaction; exact DG29 N2+V4 reported separately',component='gusset',DG29_N2_V4=(normal/ny)**2+(shear/sy)**4)
        if normal>=0:check(label+'_gusset_supported_net_tension',normal,mg['fu']*A/ga2,'NBR6.5.3 seção apoiada sem furos',component='gusset')
        check(label+'_gusset_supported_shear_rupture',shear,.6*mg['fu']*A/ga2,'NBR6.5.5',component='gusset')
        for nm,depth,matr in [('gusset',min(tg,2*s),mg),('receiver',2*s,mat)]:
            sigma=qn/depth;tau=qs/depth
            check(label+'_'+nm+'_root_contact_yield',math.sqrt(sigma*sigma+3*tau*tau),matr['fy']/ga1,'NBR6.5 contato comum contado uma vez',component='root_seams')
            if not compression or sigma>0:check(label+'_'+nm+'_root_contact_normal_rupture',sigma,matr['fu']/ga2,'NBR6.5.3 tração real no contato' if compression else 'NBR6.5.3',component='root_seams')
            check(label+'_'+nm+'_root_contact_shear_rupture',tau,.6*matr['fu']/ga2,'NBR6.5.5',component='root_seams')
        check(label+'_receiving_web_local_yield',normal,1.10*(Ls+spread*member['tf'])*mat['fy']*member['tw']/ga1,'NBR5.7.3 k=tf conservador; viga extremidade/pilar interior',component='receivers',k_lower_bound=member['tf'],spread_multiplier=spread,end_distance=enddist)
        footprint=tg+2*s;exempt=footprint<.15*member['bf']
        if normal>0 and not exempt:check(label+'_receiving_flange_local_bending',normal,(.5 if label=='beam' or enddist<10*member['tf'] else 1.)*6.25*member['tf']**2*mat['fy']/ga1,'NBR5.7.2 flexão local; faixa não isenta',component='receivers')
        if normal<0:
            # Gusset compression remains unverified, but the receiver compression
            # branch is still evaluated with its own signed load and geometry.
            n=Ls;ratio=n/member['d'];interior=label=='column' and enddist>=member['d']/2
            mult=3*ratio if interior or ratio<=.2 else 4*ratio-.2
            term=mult*(member['tw']/member['tf'])**1.5
            coeff=.66 if interior else .33
            crip=coeff*member['tw']**2*(1+term)*math.sqrt(c.E*mat['fy']*member['tf']/member['tw'])/ga1
            check(label+'_receiving_compression_web_crippling',normal,crip,'NBR5.7.4 interior/exterior receiving compression branch',component='receivers')
        seams[label]={'L':Ls,'N':normal,'S':shear,'M':0.,'qn':qn,'qs':qs,'footprint':footprint,'threshold':.15*member['bf'],
                      'flange_bending_exempt':exempt,'compression_modes':'active' if normal<0 else 'not_active_normal_is_tension'}
    out['seams']=seams
    # Complete welded beam joint: sharp physical rectangles, no rolled-root
    # area inflation; all M to flange couple, all V to web.
    for label,F in [('top',ft),('bottom',fb)]:
        check('joint_'+label+'_CJP_and_beam_flange',F,b['bf']*min(b['tf'],col['tf'])*min(mb['fy'],mc['fy'])/ga1,'NBR6.2.5.1/Tabela9 CJP compatível; menor espessura e menor fy dos dois metais base',component='beam_column_joint',signed_force=F,contact_width=b['bf'],effective_thickness=min(b['tf'],col['tf']),effective_fy=min(mb['fy'],mc['fy']),beam_material=c.beam_steel,column_material=c.column_steel)
        check('joint_'+label+'_beam_flange_gross',F,Af*mb['fy']/ga1,'NBR6.5.3 seção bruta da mesa da viga, aço próprio independente',component='beam_column_joint',signed_force=F)
        if F>0:check('joint_'+label+'_beam_flange_net',F,Af*mb['fu']/ga2,'NBR6.5.3 mesa tracionada sem furos',component='beam_column_joint',signed_force=F)
    webL=c.beam_web_weld_length;sweb=c.beam_web_weld_leg
    check('joint_web_two_fillets',math.hypot(nw,T['Fy']),2*_weld_q(c,sweb,c.fw_joint)*webL,'NBR Tabela9 vetor normal/cisalhamento',component='beam_column_joint')
    check('joint_web_base_combined',math.hypot(nw/(webL*b['tw']),math.sqrt(3)*T['Fy']/(webL*b['tw'])),mb['fy']/ga1,'NBR6.5 escoamento elástico combinado',component='beam_column_joint')
    check('joint_web_base_shear_rupture',T['Fy'],.6*mb['fu']*webL*b['tw']/ga2,'NBR6.5.5',component='beam_column_joint')
    if not compression or nw>0:check('joint_web_base_normal_rupture',nw,mb['fu']*webL*b['tw']/ga2,'NBR6.5.3',component='beam_column_joint')
    contact=2*sweb
    check('joint_web_column_flange_contact_yield',math.hypot(nw/(webL*contact),math.sqrt(3)*T['Fy']/(webL*contact)),mc['fy']/ga1,'NBR6.5 substrato da mesa do pilar; dois contatos reais',component='receivers')
    if not compression or nw>0:check('joint_web_column_flange_contact_normal_rupture',nw,mc['fu']*webL*contact/ga2,'NBR6.5.3 material receptor independente',component='receivers')
    check('joint_web_column_flange_contact_shear_rupture',T['Fy'],.6*mc['fu']*webL*contact/ga2,'NBR6.5.5 material receptor independente',component='receivers')
    check('joint_web_receiver_local_yield_no_spread',nw,1.10*webL*col['tw']*mc['fy']/ga1,'DG29 sem repetição de5k; NBR5.7.3 dispersão zero conservadora',component='receivers')
    for label,F,level in [('top',ft,cp['levels_y'][0]),('bottom',fb,cp['levels_y'][1])]:
        enddist=min(c.column_end_top-level,level-c.column_end_bottom)
        localspread=5. if enddist>col['d'] else 2.5
        if F>0:
            factor=.5 if enddist<10*col['tf'] else 1.
            check('column_'+label+'_flange_local_bending',F,factor*6.25*col['tf']**2*mc['fy']/ga1,'NBR5.7.2 mesa receptora tracionada; distância à extremidade real',component='receivers')
        check('column_'+label+'_web_local_yield',F,1.10*(localspread*col['tf']+b['tf'])*mc['fy']*col['tw']/ga1,'NBR5.7.3 k=tf, comprimento de mesa real',component='receivers')
        if F<0:
            interior=enddist>=col['d']/2;nratio=b['tf']/col['d'];mult=3*nratio if interior or nratio<=.2 else 4*nratio-.2
            crip=(.66 if interior else .33)*col['tw']**2*(1+mult*(col['tw']/col['tf'])**1.5)*math.sqrt(c.E*mc['fy']*col['tf']/col['tw'])/ga1
            check('column_'+label+'_compression_web_crippling',F,crip,'NBR5.7.4 compressão real no receptor; ramo conforme extremidade',component='receivers',signed_force=F)
    # One capacity for connected overlapping receiving zones. Actual full
    # flange force follows continuity path; no parallel capacities are added.
    zones=[(cp['levels_y'][0]-b['tf']/2,cp['levels_y'][0]+b['tf']/2,ft),
           (cp['levels_y'][1]-b['tf']/2,cp['levels_y'][1]+b['tf']/2,fb),
           (g['column_seam'][0][1],g['column_seam'][1][1],Hc)]
    unions=receiving_union(zones,col['tf'],mc['fy'],col['tw'],ga1)
    for group in unions:
        center=(group['start']+group['end'])/2
        group['spread_multiplier']=5. if min(c.column_end_top-center,center-c.column_end_bottom)>col['d'] else 2.5
        group['resistance']=1.10*(group['span']+group['spread_multiplier']*col['tf'])*mc['fy']*col['tw']/ga1
        group['utilization']=group['demand']/group['resistance']
    out['receiver_unions']=unions
    for i,group in enumerate(unions):
        if len(group['forces'])>1:
            name='column_top_flange_gusset_overlap_union' if ft in group['forces'] and Hc in group['forces'] else 'column_receiving_overlap_union_'+str(i)
            check(name,group['demand'],group['resistance'],'NBR5.7.3 união das pegadas mesa-viga/gusset; uma dispersão5k, forças absolutas concorrentes',component='receivers',actual_union_span=group['span'],normal_demands=group['forces'])
    # CP and reciprocal receivers, all full flange force carried explicitly.
    ts=c.continuity_t;bs=cp['width'];bn=cp['net_width'];net=2*bn*ts;gross=2*bs*ts;Lw=cp['web_length'];Lf=cp['flange_length'];e=cp['e']
    webstrip=25*col['tw'];As=gross+webstrip*col['tw'];zweb=cp['z_web']
    Iy=2*ts*((zweb+bs)**3-zweb**3)/3+webstrip*col['tw']**3/12;Le=.75*cp['depth'];Ne=math.pi**2*c.E*Iy/Le**2
    fy_eff=min(ms['fy'],mc['fy']);lam=math.sqrt(As*fy_eff/Ne);chi=.658**(lam*lam) if lam<=1.5 else .877/(lam*lam)
    plate_results=[]
    for label,F in [('top',ft),('bottom',fb)]:
        if F<0:
            check('continuity_'+label+'_compression_buckling',F,chi*As*fy_eff/ga1,'NBR5.7.9.4 suplemento coluna composta,25tw,0.75h,fy mínimo conservador',component='continuity',A=As,I=Iy,Le=Le,lambda0=lam,chi=chi)
            check('continuity_'+label+'_compression_net_yield',F,net*ms['fy']/ga1,'NBR5.7.9 seção líquida com recortes',component='continuity',An=net)
        else:
            check('continuity_'+label+'_gross_tension',F,gross*ms['fy']/ga1,'NBR5.7.9.1',component='continuity')
            check('continuity_'+label+'_net_rupture',F,2*Lf*ts*ms['fu']/ga2,'NBR5.7.9.1 área efetivamente soldada, sem tiras não conectadas',component='continuity')
        factor=math.sqrt(1+(6*e/Lw)**2)
        for edge,eff,s in [('loaded_flange',Lf,c.continuity_flange_weld_leg),('web',Lw,c.continuity_web_weld_leg),('opposite_flange',Lf,c.continuity_flange_weld_leg)]:
            demand=F*(factor if edge=='web' else 1.) if edge!='opposite_flange' else 0.
            check('continuity_'+label+'_'+edge+'_weld',demand,4*_weld_q(c,s,c.fw_continuity)*eff,'NBR5.7.9; quatro filetes; web inclui binário excêntrico de cada placa',component='continuity',effective_length_each=eff,e=e)
            depth=2*min(ts,2*s)
            check('continuity_'+label+'_'+edge+'_base_shear',demand,min(.6*ms['fy']*depth*eff/ga1,.6*ms['fu']*depth*eff/ga2),'NBR6.5.5 contatos reais, espessura de cada placa no máximo uma vez',component='continuity')
        common_depth=min(col['tw'],4*c.continuity_web_weld_leg)
        check('continuity_'+label+'_column_web_receiver_shear',F,min(.6*mc['fy']*common_depth*Lw/ga1,.6*mc['fu']*common_depth*Lw/ga2),'NBR6.5.5 alma comum do pilar contada uma vez',component='receivers')
        depth=2*min(col['tf'],2*c.continuity_flange_weld_leg)
        check('continuity_'+label+'_column_flange_receiver_shear',F,min(.6*mc['fy']*depth*Lf/ga1,.6*mc['fu']*depth*Lf/ga2),'NBR6.5.5 duas zonas reais separadas; aço do pilar',component='receivers')
        sigz=3*abs(F)*abs(e)/(Lw*Lw*(2*c.continuity_web_weld_leg));taux=abs(F)/(Lw*common_depth)
        check('continuity_'+label+'_column_web_combined_receiver',math.hypot(sigz,math.sqrt(3)*taux),mc['fy']/ga1,'NBR6.5 tensões normais opostas nas faces e cisalhamento na única alma comum',component='receivers',sigma_z=sigz,tau_x=taux)
        check('continuity_'+label+'_column_web_normal_rupture',sigz,mc['fu']/ga2,'NBR6.5.3 tração normal recíproca',component='receivers')
        check('column_'+label+'_continuity_contact_net_yield',F,net*mc['fy']/ga1,'Contato normal mesa→par de continuidade na área líquida real',component='receivers')
        plate_results.append(_continuity_sections(c,g,F,label,out))
    out['continuity_per_plate_traction']=plate_results
    # Compact-web branch and actual same-case local web/panel actions.
    def VR(member,mat,label):
        slender=(member['d']-2*member['tf'])/member['tw'];lim=1.10*math.sqrt(5*c.E/mat['fy'])
        if slender>lim:_issue(out,label+'_web_shear_slender','unverified','Alma fora do ramo compacto não enrijecido kv5; flambagem por cisalhamento requer cálculo próprio.',slenderness=slender,limit=lim)
        return .6*mat['fy']*member['d']*member['tw']/ga1
    Vrb=VR(b,mb,'beam');Vrc=VR(col,mc,'column')
    # Extra point loads are included at their actual stations, not folded into
    # an unrelated member maximum. Baseline no-other-load case has two ends.
    beam_values=[abs(T['Fy']),abs(bc['Fy'])]
    for x in [g['beam_seam'][0][0],g['beam_seam'][1][0]]+[a['point'][0] for a in beam_other]:
        for side in (-1e-7,1e-7):
            xx=x+side;fraction=max(0.,min(1.,(g['beam_seam'][1][0]-xx)/g['beam_seam_length']))
            value=bc['Fy']+fraction*Vb+sum(a['Fy'] for a in beam_other if a['point'][0]>xx)
            beam_values.append(abs(value))
    column_fields=_column_fields(c,g,forces,ft,fb,nw,T,upper,lower);out['column_sections']=column_fields
    column_values=[abs(upper['Fx']),abs(upper['Fx']+Hc)]
    check('beam_uniform_traction_local_web_shear',max(beam_values),Vrb,'Tração normal uniforme integrada com corte completo; NBR5.4.3',component='member_web_shear',signed_endpoint_magnitudes=beam_values)
    check('column_upper_gusset_uniform_web_shear',max(column_values),Vrc,'Tração normal uniforme com corte superior concorrente; NBR5.4.3',component='member_web_shear',signed_endpoint_magnitudes=column_values)
    def panel_cut_Q(y):
        value=upper['Fx']
        lo,hi=g['column_seam'][0][1],g['column_seam'][1][1]
        value+=Hc*max(0.,min(1.,(hi-y)/(hi-lo)))
        value+=ft if cp['levels_y'][0]>y else 0.
        value+=fb if cp['levels_y'][1]>y else 0.
        value+=nw*max(0.,min(1.,(webL/2-y)/webL))
        value+=sum(a['Fx'] for a in column_other if a['point'][1]>y)
        return -value
    qtop=panel_cut_Q(cp['levels_y'][0]-1e-7);qbot=panel_cut_Q(cp['levels_y'][1]+1e-7)
    panel_candidates=[r for r in column_fields['candidates'] if cp['levels_y'][1]+1e-6<r['y']<cp['levels_y'][0]-1e-6]
    if column_other:
        # Actual field includes loads within panel and all upper loads.
        panel_Q=max([abs(qtop),abs(qbot)]+[abs(r['Q']) for r in panel_candidates])
    else:panel_Q=max(abs(qtop),abs(qbot))
    Nc=column_fields['maximum_compression'];Npl=col['Ag']*mc['fy'];fac=1. if Nc<=.4*Npl else max(0.,1.4-Nc/Npl)
    check('column_panel_zone',panel_Q,Vrc*fac,'NBR5.7.7 corte algébrico do mesmo caso; alma real sem área fictícia de continuidade',component='panel',Qtop=qtop,Qbottom=qbot,column_axial=Nc,Npl=Npl,axial_factor=fac)
    check('column_lower_web_shear',lower['Fx'],Vrc,'NBR5.4.3 corte inferior completo derivado',component='member_web_shear')
    check('column_all_local_web_shear',max([abs(r['Q']) for r in column_fields['candidates']]),Vrc,'NBR5.4.3 todos os extremos do campo local de cortes reais',component='member_web_shear')
    beam_base=abs(bc['Fx'])/b['Ag']+abs(bc['M']-bc['point'][1]*bc['Fx'])/b['Wx']
    Ncabs=max([abs(upper['Fy']),abs(lower['Fy'])]+[abs(r['N']) for r in column_fields['candidates']]);Mmax=column_fields['maximum_abs_moment']
    column_base=Ncabs/col['Ag']+Mmax/col['Wx']
    check('beam_local_NM_yield_screen',beam_base,mb['fy']/ga1,'Tela elástica local N/M; não certifica estabilidade global',component='local_member_material',diagnostic_only=True)
    check('column_local_NM_yield_screen',column_base,mc['fy']/ga1,'Envelope conservador de ações concorrentes integrado; não certifica estabilidade global',component='local_member_material',diagnostic_only=True)
    panel_tau=panel_Q/(col['d']*col['tw'])
    for label,F in [('top',ft),('bottom',fb)]:
        local_normal=3*abs(F)*abs(e)/(Lw*Lw*(2*c.continuity_web_weld_leg));local_shear=abs(F)/(Lw*min(col['tw'],4*c.continuity_web_weld_leg))
        bound=column_base+local_normal+math.sqrt(3)*(local_shear+panel_tau)
        check('continuity_'+label+'_concurrent_column_receiver_bound',bound,mc['fy']/ga1,'Limite triangular conservador vonMises; N/M,painel e tração local do mesmo caso, sem somar resistências',component='receivers',baseline_normal=column_base,panel_tau=panel_tau)
    out['panel']={'Qtop':qtop,'Qbottom':qbot,'Qmax':panel_Q,'VRd':Vrc,'Nc':Nc,'Npl':Npl,'factor':fac}
    forces['panel']=out['panel'];forces['continuity']=plate_results
    if not bolted:
        out['brace']={'fheel':1-a['centroid']/a['leg'],'ftoe':a['centroid']/a['leg']}
        if not compression:out['brace']['Ct']=Ct
        else:
            out['brace'].update(angle_count=2,per_angle_force=Pa,force_mode='compression',global_member_stability='outside_scope',
                signed_weld_vectors=[dict(id=line['id'],force=P*line['force_fraction'],Fx=P*line['force_fraction']*co,Fy=P*line['force_fraction']*si,magnitude=abs(P*line['force_fraction'])) for line in g['brace_lines']])
    if single and not bolted:
        out['brace'].update(angle_count=1,weld_count=2,face=c.single_angle_face,per_angle_force=Pa,
                            connected_surface_z=g['brace_connected_surface_z'][0],centroid_z=g['brace_centroid_z'],
                            nominal_connection_axis_z=0.)
    out['details']={'CJP':'Mesa inteira, garganta completa, bisel/WPS qualificado, remoção de backing/runoff; execução não certificada',
                    'column5_7_5':'Dispensada somente com contenção lateral relativa pelas continuidades completas' if c.lateral_restraint else 'Não verificada sem contenção',
                    'column5_7_6':'Não há par de forças externas opostas de compressão nas duas mesas do pilar neste caminho',
                    'builtup_flange_web_weld':'Não aplicável a perfis W laminados' if b['family']==col['family']=='W' else 'Não verificada para a família de perfil selecionada',
                    'root_radius':'k=tf conservador, sem estimar raio laminado não publicado',
                    'continuity_opposite_flange':'Solda presente, demanda zero no caminho selecionado integral para a alma',
                    'angle_radii':'Modelo nominal de perna Gerdau; filete inscrito, sem contorno microscópico inventado'}
    if bolted:
        out['details']['angle_radii']='Envelope real de talão/ferramenta declarado separadamente; raios de catálogo não inventados.'
        out['mechanics_complete']=not any(i['severity'] in ('invalid_input','invalid_geometry','unverified','outside_scope') for i in out['issues'])
        out['assembly_qualified']=not any(i['severity'] in ('detail_pending','detail_fail','invalid_geometry') for i in out['issues'])
    return _finish(out)


_analyze_impl=analyze

def analyze(c):
    """Public numerically guarded evaluator; invalid arithmetic is never PASS."""
    try:
        if isinstance(c,CornerGusset) and any(finite_real(getattr(c,f.name)) and abs(getattr(c,f.name))>1e100 for f in fields(c)):
            raise ArithmeticError('Magnitude excede o domínio seguro das operações polinomiais em ponto flutuante.')
        with np.errstate(over='raise',invalid='raise',divide='raise'):
            result=_analyze_impl(c)
            minimum_applicable = (0<=c.P<45000. or (compression_candidate(c) and -45000.<c.P<0)) if isinstance(c,CornerGusset) and finite_real(c.P) else False
            if minimum_applicable and result.get('geometry'):
                # Separate engineering design-strength case. D/U remain background
                # actions, never claimed to be a different actual Robot combination.
                design_force=-45000. if c.P<0 else 45000.
                design=replace(c,P=design_force,compare_lower_cut=False,case_id=c.case_id+' / MIN45_SYNTHETIC',
                               cuts_source='Caso sintético de dimensionamento: D/U e outras ações mantidos como fundo do caso '+c.case_id)
                minimum=_analyze_impl(design)
                if minimum.get('service_slip'):
                    minimum['service_slip']['case_provenance']='synthetic minimum design safeguard; not an actual rare-service combination or Robot cuts'
                if minimum.get('checks'):
                    actual_forces=deepcopy(result['forces'])
                    for row in result['checks']:row['case_id']='actual'
                    for row in minimum['checks']:
                        row['id']='minimum45__'+row['id'];row['case_id']='minimum_45kN'
                    result['checks'].extend(deepcopy(minimum['checks']))
                    result['issues'].extend(dict(i,id='minimum45__'+i['id'],case_id='minimum_45kN') for i in minimum['issues'])
                    result['force_cases']={'actual':actual_forces,'minimum_45kN':deepcopy(minimum['forces'])}
                    result['design_cases']=[{'id':'minimum_45kN','actual_P':c.P,'design_P':design_force,
                        'origin':'NBR8800:2024 6.1.5.2 mínimo da ligação uma vez; caso de resistência sintético, não combinação real prescrita pela norma',
                        'background':'D/U e outras ações do caso real mantidos explicitamente; L sintético derivado, não Robot',
                        'robot_lower_comparison':False,'result':minimum}]
                    if c.P==0:
                        result['design_cases'][0]['zero_force_convention']='N real zero preservado; +45 kN em +u adotado nominalmente em tração, não sentido prescrito pela norma.'
                    if is_bolted(c):
                        result['mechanics_complete']=result.get('mechanics_complete',False) and minimum.get('mechanics_complete',False)
                        result['assembly_qualified']=result.get('assembly_qualified',False) and minimum.get('assembly_qualified',False)
                    result=_finish(result)
        # Outputs are native JSON: do not hide infinities in deeply nested
        # geometry, extrema or forces. Zero-capacity ratios use explicit null.
        def finite_tree(value):
            if isinstance(value,float) and not math.isfinite(value):raise ArithmeticError('Resultado não finito.')
            if isinstance(value,dict):
                for v in value.values():finite_tree(v)
            elif isinstance(value,(list,tuple)):
                for v in value:finite_tree(v)
        finite_tree(result)
        return result
    except (ArithmeticError, np.linalg.LinAlgError, ValueError, TypeError) as exc:
        out={'family':FAMILY,'connection_type':CONNECTION_TYPE,'component_version':COMPONENT_VERSION,
             'checks':[],'issues':[],'geometry':{},'forces':{},'assumptions':fixed_assumptions(),'exclusions':list(EXCLUSIONS)}
        if isinstance(c,CornerGusset) and is_bolted(c):
            out['family']='Ligação de canto '+('1L' if is_single(c) else '2L-T')+'–gusset–viga/pilar · parafusada'
            out['assumptions']=fixed_assumptions(c.topology)
        elif isinstance(c,CornerGusset) and c.topology=='single_1L_welded':
            out['family']='Ligação de canto 1L–gusset–viga/pilar · soldada'
            out['assumptions']=fixed_assumptions(c.topology)
        _issue(out,'numeric_domain','invalid_input','Entradas fora do domínio numérico seguro; nenhum resultado de resistência pode ser aprovado.',reason=str(exc))
        return _finish(out)


evaluate=analyze
