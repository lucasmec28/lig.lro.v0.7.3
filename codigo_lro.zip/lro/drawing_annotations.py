"""Small display-space helpers for the finite drawing-layout corrections.

Only annotation artists are positioned here. Physical geometry and dimension
endpoints remain in their original data coordinates, including zero-length gaps.
"""
from math import hypot

from matplotlib.artist import Artist
from matplotlib.backends.backend_agg import RendererAgg
from matplotlib.font_manager import FontProperties


def rendered_wrap(text, max_width_points, fontsize, fontweight='normal'):
    """Wrap complete text using measured font widths, without truncation."""
    renderer = RendererAgg(1, 1, 72)
    prop = FontProperties(family='DejaVu Sans', size=fontsize, weight=fontweight)
    width = lambda value: renderer.get_text_width_height_descent(value, prop, False)[0]
    lines = []
    for paragraph in str(text).split('\n'):
        line = ''
        for word in paragraph.split(' '):
            candidate = (line + ' ' + word) if line else word
            if line and width(candidate) > max_width_points:
                lines.append(line)
                line = word
            else:
                line = candidate
            # A single uninterrupted designation still retains every character.
            while width(line) > max_width_points and len(line) > 1:
                split = len(line) - 1
                while split > 1 and width(line[:split]) > max_width_points:
                    split -= 1
                lines.append(line[:split])
                line = line[split:]
        lines.append(line)
    return '\n'.join(lines)


class _DimensionLayout(Artist):
    """Resolve just this dimension before its arrow/text artists are drawn."""
    def __init__(self, ax, p1, p2, arrow, text, external, ticks, offset,
                 short_side, color, lw):
        super().__init__()
        self.ax = ax
        self.p1, self.p2 = tuple(p1), tuple(p2)
        self.arrow, self.text = arrow, text
        self.external, self.ticks = external, ticks
        self.offset, self.short_side = tuple(offset), short_side
        self.color, self.lw = color, lw
        self.set_zorder(.1)
        self.set_in_layout(False)

    def draw(self, renderer):
        ax, text = self.ax, self.text
        p1, p2 = ax.transData.transform([self.p1, self.p2])
        dx, dy = p2 - p1
        span = hypot(dx, dy)
        ux, uy = (dx / span, dy / span) if span > 1e-9 else (1., 0.)
        nx, ny = -uy, ux
        mid_data = ((self.p1[0] + self.p2[0]) / 2,
                    (self.p1[1] + self.p2[1]) / 2)
        base = (mid_data[0] + self.offset[0], mid_data[1] + self.offset[1])
        text.set_position(base)
        text.update_bbox_position_size(renderer)
        bbox = text.get_bbox_patch().get_window_extent(renderer)
        projected = abs(ux) * bbox.width + abs(uy) * bbox.height
        points = renderer.points_to_pixels(1.)
        short = bool(span < projected + 14 * points)
        text._dimension_short = short
        text._dimension_span_pixels = float(span)
        text._dimension_label_pixels = float(projected)
        self.arrow._dimension_short = short
        for extra in self.external:
            extra.set_visible(short)
        for tick in self.ticks:
            tick.set_visible(short)
        self.arrow.arrow_patch.set_arrowstyle('-' if short else '<->')
        if short:
            mid = (p1 + p2) / 2
            base_px = ax.transData.transform(base)
            normal_offset = (base_px[0] - mid[0]) * nx + (base_px[1] - mid[1]) * ny
            side = (1 if normal_offset > 0 else -1) if abs(normal_offset) > points else self.short_side
            clearance = (abs(nx) * bbox.width + abs(ny) * bbox.height) / 2 + 5 * points
            # Preserve a larger intentional offset; otherwise move only text.
            normal_offset = side * max(abs(normal_offset), clearance)
            tangent_offset = (base_px[0] - mid[0]) * ux + (base_px[1] - mid[1]) * uy
            new_px = (mid[0] + tangent_offset * ux + normal_offset * nx,
                      mid[1] + tangent_offset * uy + normal_offset * ny)
            # Align the bounding-box center, not the text's baseline/anchor.
            anchor_px = ax.transData.transform(text.get_position())
            center_delta = ((bbox.x0 + bbox.x1) / 2 - anchor_px[0],
                            (bbox.y0 + bbox.y1) / 2 - anchor_px[1])
            text.set_position(ax.transData.inverted().transform(
                (new_px[0] - center_delta[0], new_px[1] - center_delta[1])))
            for index, (point, direction) in enumerate(((p1, -1), (p2, 1))):
                tail = (point[0] + direction * ux * 11 * points,
                        point[1] + direction * uy * 11 * points)
                self.external[index].xy = self.p1 if index == 0 else self.p2
                self.external[index].set_position(ax.transData.inverted().transform(tail))
                half_tick = 2.7 * points
                tick_data = ax.transData.inverted().transform([
                    (point[0] - nx * half_tick, point[1] - ny * half_tick),
                    (point[0] + nx * half_tick, point[1] + ny * half_tick)])
                self.ticks[index].set_data(tick_data[:, 0], tick_data[:, 1])
        self.stale = False


def dimension(ax, p1, p2, label, fontsize=8, rotation=0, color='#243749',
              offset=(0, 0), ha='center', va='center', pad=1.4, lw=.8,
              short_side=1):
    """Draw a physical span, using external arrows when its label won't fit.

    The optional short_side selects the display-space normal (+1/-1) only when
    the existing data-space offset does not already select a side. This is not
    a collision solver: each drawing owns its finite annotation lanes.
    """
    props = {'arrowstyle': '<->', 'color': color, 'lw': lw,
             'shrinkA': 0, 'shrinkB': 0}
    arrow = ax.annotate('', xy=p2, xytext=p1, arrowprops=props)
    arrow._dimension_endpoints = (tuple(p1), tuple(p2))
    mid = ((p1[0] + p2[0]) / 2 + offset[0],
           (p1[1] + p2[1]) / 2 + offset[1])
    text = ax.text(*mid, label, ha=ha, va=va, fontsize=fontsize,
                   rotation=rotation, color=color,
                   bbox={'facecolor': 'white', 'edgecolor': 'none', 'pad': pad})
    text._dimension_endpoints = (tuple(p1), tuple(p2))
    external = [ax.annotate('', xy=p, xytext=p, visible=False,
                           arrowprops={'arrowstyle': '->', 'color': color,
                                       'lw': lw, 'shrinkA': 0, 'shrinkB': 0})
                for p in (p1, p2)]
    ticks = [ax.plot([], [], color=color, lw=lw, visible=False)[0] for _ in (p1, p2)]
    for artist in external + ticks:
        artist.set_in_layout(False)
        artist._dimension_auxiliary = True
    ax.add_artist(_DimensionLayout(ax, p1, p2, arrow, text, external, ticks,
                                  offset, short_side, color, lw))
    return arrow, text
