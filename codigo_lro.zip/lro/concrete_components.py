"""Explicit adapter for complementary ACI anchorage modes, without assumed shear sharing."""
from dataclasses import dataclass,asdict,fields
import hashlib,json,math
from .models import Issue,finite_real

REF='ACI 318-19, capítulo 17 / AISC DG1 3ª ed. · base complementar'

@dataclass(frozen=True)
class ConcreteComponents:
    model: str = 'off'
    bearing_area: float = 0.
    bearing_area_ref: str = ''
    bearing_confirmation: str = ''
    mechanical_resistance: float = 0.
    mechanical_ref: str = ''
    distribution_ref: str = ''
    distribution_confirmation: str = ''
    force_a1: float = 0.
    force_a2: float = 0.
    force_a3: float = 0.
    force_a4: float = 0.
    parallel_model: str = 'pending'
    optional_envelope: bool = False
    area_tension: float = 0.
    area_shear: float = 0.
    steel_area_ref: str = ''
    ductile: bool = False
    ductility_ref: str = ''

    @staticmethod
    def from_dict(data):
        if not isinstance(data,dict):raise ValueError('Dados dos componentes de ancoragem devem ser um objeto.')
        unknown=set(data)-{f.name for f in fields(ConcreteComponents)}
        if unknown:raise ValueError('Campos de ancoragem não reconhecidos: '+', '.join(sorted(unknown)))
        return ConcreteComponents(**data)


def _digest(data):
    def stable(v):
        if isinstance(v,dict):return {k:stable(x) for k,x in v.items()}
        if isinstance(v,(list,tuple)):return [stable(x) for x in v]
        if type(v) in (float,int):return format(v,'.12g')
        return v
    return hashlib.sha256(json.dumps(stable(data),sort_keys=True,ensure_ascii=False,allow_nan=False).encode()).hexdigest()


def bearing_signature(c):
    u=c.concrete_components
    keys=('anchor_type','db','hef','anchor_head_width','anchor_head_length','anchor_head_t',
          'anchor_bearing_t','anchor_nut_t','anchor_head_hole','anchor_nut_bearing_area',
          'anchor_detail_ref','anchor_detail_confirmed')
    return _digest(dict(detail={k:getattr(c,k) for k in keys},area=u.bearing_area,area_ref=u.bearing_area_ref,
                        mechanical_resistance=u.mechanical_resistance,mechanical_ref=u.mechanical_ref))


def distribution_signature(c,legacy_dormant=False):
    u=c.concrete_components
    keys=('N','M','V','shear_path','anchor_shear_model','tp','grout_t','a1','a2','db','hef',
          'block_xmin','block_xmax','block_ymin','block_ymax','block_h','anchor_type','anchor_detail_ref','anchor_detail_confirmed',
          'anchor_washer_t','anchor_washer_side','anchor_head_width','anchor_head_length','anchor_head_t','anchor_bearing_t','anchor_nut_t',
          'anchor_head_hole','weld_web_type','weld_web_measure','weld_web_size','weld_flange_type','weld_flange_measure','weld_flange_size',
          'stiffener_detail','stiffener_length','stiffener_height','stiffener_t')
    detail={k:getattr(c,k) for k in keys}
    if detail['stiffener_detail']=='web_pair_visual':detail['stiffener_detail']='none'
    if c.model_type==1 and detail['stiffener_detail']=='none' and not legacy_dormant:
        detail.update(stiffener_length=60.,stiffener_height=120.,stiffener_t=8.)
    if getattr(c,"model_type",None)==3:
        detail.update({k:getattr(c,k) for k in ("L_plate","B_plate","anchor_x","anchor_y","centroid_back","offset_y","weld_size","clear_geometry_confirmed","flange_min_thickness","flange_thickness_from_model","straight_web_length","base_hole")})
        detail["channel_prying_factor"]=1.4
        if getattr(c,'anchor_layout','four')=='two_symmetry':
            detail['anchor_layout']='two_symmetry'
            detail.pop('anchor_x')
            detail.update({k:getattr(c,k) for k in ('washer_alignment','washer_offset_tolerance','washer_nut_type','washer_detail_confirmed')})
    return _digest(dict(model=c.model_type,detail=detail,column=asdict(c.column),
                        effective_moment=c.effective_moment,upper_washer=asdict(c.upper_washer),active_key=asdict(c.active_key),forces=[u.force_a1,u.force_a2,u.force_a3,u.force_a4],
                        reference=u.distribution_ref,parallel_model=u.parallel_model))


def validate_components(c):
    u=c.concrete_components;issues=[]
    if not isinstance(u,ConcreteComponents):return [Issue('error','Dados de componentes ACI inválidos.',REF)]
    for field in fields(u):
        value=getattr(u,field.name);default=getattr(ConcreteComponents(),field.name)
        physical_active=(u.model!='off' or (field.name=='area_tension' and c.shear_path=='plate' and getattr(c.single_key_concrete,'model','off')!='off'))
        if type(default) is float and (not finite_real(value) or (physical_active and value<0)):
            issues.append(Issue('error',field.name+': informe número finito não negativo.',REF))
        elif type(default) is str and not isinstance(value,str):issues.append(Issue('error',field.name+': texto inválido.',REF))
        elif type(default) is bool and type(value) is not bool:issues.append(Issue('error',field.name+': escolha booleana inválida.',REF))
    if u.model not in ('off','aci318_19'):issues.append(Issue('error','Modelo de componentes ACI não reconhecido.',REF))
    if u.parallel_model not in ('pending','virtual_perpendicular'):issues.append(Issue('error','Modelo de bordas paralelas não reconhecido.',REF))
    return issues


def components_assumptions(c):
    if c.concrete_components.model=='off':return []
    return [
        'Ancoragem ACI complementar: concreto normal fissurado, ações já de cálculo; fatores φ do método ACI não recebem γc ou γa adicionais. Modos explicitamente calculados permanecem separados das pendências da ancoragem e do bloco.',
        'Área líquida efetiva de apoio enterrado deve corresponder ao detalhe e à verificação citada. A confirmação é vinculada à geometria atual; mudar área, peça, referência ou comprovação mecânica invalida-a. Chapa enterrada com porca requer comprovação mecânica antes de creditar a área.',
        'Cortante no concreto utiliza vetor por chumbador expressamente documentado para a combinação atual. Não se presume V/4 a partir da soma das capacidades NBR; forças não negativas no sentido de V devem somar |V| e equilibrar torção. Mudança de combinação ou geometria invalida a qualificação.',
        'Bordas paralelas a V só são avaliadas quando selecionada explicitamente a transformação perpendicular virtual da ACI. Área projetada, profundidade física, grupos e forças reais governam cada modo. Não há soma automática de mecanismos.',
        'Interação aço/concreto ACI usa áreas efetivas documentadas e resistências ACI, sem combinar capacidades NBR com φACI. Sem comprovação de ductilidade aplicam-se os fatores explicitamente conservadores do ramo não dúctil. Interação parcial não aprova a ancoragem completa.',
    ]


def _pending(reason):return dict(status='pending',checks=[],reasons=[reason])


def anchor_shear_demand(c):
    """Selected-route component demand, never a split inferred from capacities.

    Friction declares no anchor shear. A single key additionally needs the
    explicit physical rod-restraint choice; a perimeter-welded washer is not it.
    Other devices have no supported rod-restraint contract in this increment.
    """
    out=dict(V_column=c.V,V_anchor=None,V_key=c.V if c.shear_path=='plate' else 0.,
             V_friction=c.V if c.shear_path=='friction' else 0.,
             route=c.shear_path,status='pending',reason='')
    if c.V==0:
        return dict(out,V_anchor=0.,status='not_demanded')
    if c.shear_path=='anchors':return dict(out,V_anchor=c.V,status='active')
    if c.shear_path=='friction':
        return dict(out,V_anchor=0.,status='not_applicable',
                    basis='Atrito como caminho exclusivo; sem crédito ou distribuição de cortante aos chumbadores.')
    if c.shear_path=='plate':
        restraint=c.single_key_concrete.rod_restraint
        if restraint=='unwelded':
            return dict(out,V_anchor=0.,status='not_applicable',
                        basis='Chave única com barras declaradas não soldadas e sem ligação rígida à placa; DG1/ACI 17.11.')
        reason=('Barras efetivamente soldadas ou rigidamente ligadas: interação simultânea com a chave requer modelo próprio; não se atribui Vi=0 nem V/4.'
                if restraint=='welded' else
                'Informe a restrição real das barras no detalhe da chave; sem essa definição não se atribui Vi=0 nem V/4.')
        return dict(out,reason=reason)
    return dict(out,reason='Esta rota de dispositivo não define a restrição e a demanda de corte das barras; exige um modelo físico próprio, sem atribuir Vi=0 ou V/4.')


def _no_demand(status='not_demanded', note=''):
    result=dict(status=status,checks=[],reasons=[])
    if note:result['applicability_note']=note
    return result


def add_component_checks(c,r,add):
    u=c.concrete_components
    if u.model=='off':return {}
    from .concrete_anchorage import anchor_tensions,detail_blockers
    from .concrete_headed import evaluate_headed
    from .concrete_shear import evaluate_shear,aci_steel,interaction
    rods=anchor_tensions(c,r.geometry)
    bounds=(c.block_xmin,c.block_ymin,c.block_xmax,c.block_ymax)
    detail_reasons=detail_blockers(c,rods)
    out=dict(status='pending',complete=False,modes={},reasons=[],rods=rods)
    modes=out['modes']
    # A declared physical force vector also constrains the native NBR steel path.
    two_channel=getattr(c,'model_type',None)==3 and getattr(c,'anchor_layout','four')=='two_symmetry'
    forces={f'A{i}':getattr(u,f'force_a{i}') for i in range(1,3 if two_channel else 5)}
    force_valid=(bool(u.distribution_confirmation) and u.distribution_confirmation==distribution_signature(c)
                 and bool(u.distribution_ref.strip()) and math.isclose(sum(forces.values()),abs(c.V),rel_tol=1e-10,abs_tol=1e-8)
                 and math.isclose(forces['A1'],forces['A2'],rel_tol=1e-10,abs_tol=1e-8)
                 and (two_channel or math.isclose(forces['A3'],forces['A4'],rel_tol=1e-10,abs_tol=1e-8)))
    if c.native_anchor_shear and force_valid:
        actual=[]
        for rod in r.geometry.get('anchor_shear',{}).get('rods',[]):
            q=forces[rod['id']];rd=rod['rd']
            add('cc_nbr_actual_'+rod['id'],'Chumbador '+rod['id']+' — cortante individual documentado / NBR',q,rd,'N',
                'NBR 8800:2024 corrigida 2025, 6.7.2.5 e 6.3.3.4','Vi,Sd documentado ≤ VRd,i condicionado à tração concorrente',
                f'Vi={q:.8g}; VRd,i={rd:.8g}; Ft,Sd,i={rod["tension"]:.8g}',
                'O vetor efetivo qualificado deve atender cada barra; soma de capacidades do grupo não substitui esta comparação.')
            actual.append(dict(id=rod['id'],demand=q,resistance=rd))
        out['native_nbr_distribution']=actual
    demand=anchor_shear_demand(c);out['component_demands']=demand
    Vanchor=demand['V_anchor']
    positive_tension=any(rod['tension']>0 for rod in rods)
    positive_shear=Vanchor is not None and Vanchor!=0
    if not positive_tension:
        headed={name:_no_demand() for name in ('pullout','sideface')}
        headed['prerequisites']=dict(status='not_demanded',mechanical=_no_demand())
    elif detail_reasons:
        headed={name:dict(status='pending',checks=[],reasons=list(detail_reasons)) for name in ('pullout','sideface')}
    else:
        detail=dict(family=c.anchor_type,bearing_area_ref=u.bearing_area_ref,
                    effective_area_qualified=bool(u.bearing_confirmation) and u.bearing_confirmation==bearing_signature(c),
                    qualified_bearing_area=u.bearing_area,detail_confirmed=c.anchor_detail_confirmed,detail_ref=c.anchor_detail_ref,
                    mechanical_resistance=u.mechanical_resistance if u.mechanical_resistance>0 else None,mechanical_ref=u.mechanical_ref)
        aperture=c.anchor_head_hole if c.anchor_type=='buried_plate_nut' else c.db
        area_limit=c.anchor_head_width*c.anchor_head_length-math.pi*aperture**2/4
        if c.anchor_type=='buried_nut':area_limit=min(area_limit,c.anchor_nut_bearing_area)
        if u.bearing_area<=0:
            headed={name:_pending('Informe a área líquida efetiva de apoio enterrado.') for name in ('pullout','sideface')}
        elif u.bearing_area>area_limit+1e-8:
            headed={name:_pending(f'Área efetiva {u.bearing_area:g} mm² supera o limite geométrico/documentado {area_limit:g} mm² da peça atual; nenhuma capacidade de apoio é creditada.') for name in ('pullout','sideface')}
            r.issues.append(Issue('noncompliance','Área efetiva de apoio enterrado maior que a projeção líquida/documentada disponível.',REF))
        else:
            detail['actual_available_bearing_area']=area_limit
            headed=evaluate_headed(rods,bounds,c.hef,c.fck,u.bearing_area,detail)
    for name in ('pullout','sideface'):
        modes[name]=headed.get(name,_pending('Resultado de '+name+' não disponível.'))
    out['headed_prerequisites']=headed.get('prerequisites',{})
    modes['head_mechanical']=headed.get('prerequisites',{}).get('mechanical',_pending('Comprovação mecânica do apoio enterrado indisponível.'))
    qualified=bool(u.distribution_confirmation) and u.distribution_confirmation==distribution_signature(c)
    if Vanchor==0:
        note=demand.get('basis','Cortante nulo nos chumbadores nesta combinação.')
        shear=dict(breakout=_no_demand(demand['status'],note),pryout=_no_demand(demand['status'],note),
                   rods=[dict(x,shear=0.) for x in rods])
    elif Vanchor is None:
        shear=dict(breakout=_pending(demand['reason']),pryout=_pending(demand['reason']),rods=[])
    elif detail_reasons:
        shear=dict(breakout=dict(status='pending',checks=[],reasons=list(detail_reasons)),
                   pryout=dict(status='pending',checks=[],reasons=list(detail_reasons)),rods=[])
    else:
        shear=evaluate_shear(rods,bounds,c.hef,c.fck,c.block_h,c.db,Vanchor,
                             dict(mode='documented',qualified=qualified,reference=u.distribution_ref,forces=forces,
                                  parallel_model=u.parallel_model,optional_envelope=u.optional_envelope,
                                  **({'layout':'line_1x2'} if two_channel else {})))
    shear['V_anchor']=Vanchor
    for name in ('breakout','pryout'):modes[name]=shear.get(name,_pending('Resultado de '+name+' indisponível.'))
    out['shear_details']=shear
    steelchecks=[];steelreasons=[]
    needs_steel=positive_tension or positive_shear
    if needs_steel:
        if u.area_tension<=0 or (positive_shear and u.area_shear<=0) or not u.steel_area_ref.strip():
            steelreasons.append('Informar área efetiva documentada Ase,N'+(' e Ase,V' if positive_shear else '')+' das barras rosqueadas; não usar automaticamente a área bruta NBR.')
        elif max(u.area_tension,u.area_shear if positive_shear else 0.)>math.pi*c.db**2/4+1e-8:
            steelreasons.append('Área efetiva não pode superar a seção bruta real πdb²/4; confira diâmetro e fonte das áreas.')
            r.issues.append(Issue('noncompliance','Área efetiva ACI superior à área bruta da barra; nenhuma capacidade de aço é creditada.',REF))
        elif positive_shear and u.area_shear>u.area_tension+1e-8:
            steelreasons.append('Esta rota tem a mesma seção rosqueada no corte: Ase,V não pode superar a área efetiva documentada Ase,N. Outra seção requer modelo específico.')
        elif positive_shear and not shear.get('rods'):
            steelreasons.append('Demandas individuais de cortante ainda não qualificadas.')
        else:
            shear_rods={x['id']:x for x in shear.get('rods',[])}
            for rod in rods:
                sr=shear_rods.get(rod['id'])
                if positive_shear and (not sr or 'shear' not in sr):
                    steelreasons.append('Força de corte ausente para '+rod['id']);continue
                try:
                    result=aci_steel(tension=rod['tension'],shear=sr.get('shear',0.) if sr else 0.,
                        area_tension=u.area_tension,area_shear=u.area_shear if positive_shear else None,
                        fy=250.,fu=400.,ductile=u.ductile,grout=True,ductility_ref=u.ductility_ref,id=rod['id'])
                    steelchecks.extend(result.get('checks',[]));steelreasons.extend(result.get('reasons',[]))
                except (ValueError,TypeError,OverflowError,ZeroDivisionError) as exc:steelreasons.append(str(exc))
    if Vanchor is None:steelreasons.append(demand['reason'])
    modes['aci_steel']=dict(status='pending' if steelreasons else 'calculated' if needs_steel else 'not_demanded',
                            checks=steelchecks,reasons=steelreasons)
    tensionchecks=[]
    for name in ('pullout','sideface'):
        tensionchecks.extend(ck for ck in modes[name].get('checks',[]) if not ck.get('diagnostic_only'))
    cone=r.geometry.get('concrete_cone',{})
    for g in cone.get('primary_groups',[]):
        tensionchecks.append(dict(id='cone_'+g['id'],label='Cone de tração ACI',ids=g['ids'],demand=g['demand'],resistance=g['resistance'],ratio=g['ratio'],nominal=g['resistance']/.70,phi=.70,method='ACI 318-19 17.6.2'))
    tensionchecks.extend(check for check in steelchecks if check['id'].startswith('aci_tension_'))
    prerequisite_reasons=[]
    if positive_tension:
        for name in ('pullout','sideface'):
            mode=modes[name]
            if mode.get('status') not in ('calculated','not_applicable','not_demanded'):
                prerequisite_reasons.append(name+' com domínio ou dados pendentes.')
            if any(ck.get('diagnostic_only') for ck in mode.get('checks',[])):
                prerequisite_reasons.append(name+' contém geometria de diagnóstico sem conclusão.')
        if cone.get('status')!='calculated':prerequisite_reasons.append('Cone de tração positivo deve ser selecionado e efetivamente calculado.')
        if out.get('headed_prerequisites',{}).get('status')!='verified':prerequisite_reasons.append('Apoio enterrado e área efetiva precisam de comprovação mecânica aplicável.')
    if not positive_tension and Vanchor==0:
        modes['interaction']=_no_demand()
        out['force_states']=[];out['attachment_demands']=[]
    else:
        from .concrete_force_states import evaluate_force_states
        state_results=evaluate_force_states(c,r,rods,tensionchecks,shear,steelchecks,not steelreasons,prerequisite_reasons,add)
        modes['interaction']=state_results['interaction']
        out['force_states']=state_results['states']
        out['attachment_demands']=state_results['attachment_demands']
    labels={'head_mechanical':'Apoio enterrado · comprovação mecânica documental','pullout':'Pullout / apoio enterrado','sideface':'Ruptura lateral do concreto','breakout':'Ruptura de concreto ao cortante',
            'pryout':'Pryout','aci_steel':'Aço dos chumbadores · ACI complementar','interaction':'Interação ACI · estados enumerados'}
    for mode,result in modes.items():
        for index,check in enumerate(result.get('checks',[])):
            if check.get('diagnostic_only'):continue
            demand=check.get('demand');resistance=check.get('resistance')
            if finite_real(demand) and finite_real(resistance):
                label=check.get('label',labels[mode])
                if two_channel:
                    details=[]
                    if check.get('edge'):
                        edge={'right':'+x','left':'−x','top':'+y','bottom':'−y'}.get(check['edge'],check['edge'])
                        details.append('borda '+edge+(' virtual' if check.get('virtual_perpendicular') else ''))
                        if check.get('case'):details.append({'single_row':'fila única','case1':'caso1','case2':'caso2','case3':'caso3','optional_envelope':'envelope'}.get(check['case'],check['case']))
                    if check.get('ids') and not all('barra '+anchor in label for anchor in check['ids']):
                        details.append(', '.join(check['ids']))
                    if details:label+=' · '+' · '.join(details)
                add('cc_'+mode+'_'+str(index),label,demand,resistance,'N',
                    check.get('method',REF),check.get('equation',f'{mode}: Sd ≤ φRn'),
                    f'Sd={demand:.8g}; φRn={resistance:.8g}; barras='+','.join(check.get('ids',[])),
                    'Verificação ACI complementar individual/grupal. '+('Triagem sem aprovação global.' if mode=='interaction' else 'Não substitui os demais modos ou o bloco armado.'))
        for reason in result.get('reasons',[]):
            r.issues.append(Issue('pending',labels[mode]+': '+str(reason),REF,origin='concrete_components'))
        if result.get('status')=='invalid':
            r.issues.append(Issue('noncompliance',labels[mode]+': dados ou hipótese incompatíveis.',REF))
    interaction_result=modes.get('interaction',{})
    if interaction_result.get('passes') is not None or interaction_result.get('numerical_screen_passes') is False:
        ready=interaction_result.get('passes') is not None
        add('cc_interaction' if ready else 'cc_interaction_fail',
            'Interação ACI — modos e estados de força enumerados' if ready else 'Interação ACI — falha já demonstrada na triagem parcial',
            interaction_result['ratio'],1.,'—',REF,'max_estados{βN; βV; (βN+βV)/1,2 quando ambos>0,2} ≤ 1',
            f'βN={interaction_result["beta_N"]:.8g}; βV={interaction_result["beta_V"]:.8g}; índice={interaction_result["ratio"]:.8g}',
            'Cada estado conserva Ti e seus próprios Vi, aço ACI e conjunto ativo de pryout. Não somar estados; o conjunto local, fendilhamento/detalhamento e bloco permanecem separados.')
    r.issues.append(Issue('pending','Resultados ACI limitados aos modos aplicáveis e estados enumerados. Peça de ancoragem, fendilhamento/detalhamento e caminho local devem corresponder ao método selecionado; bloco/fundação são responsabilidades separadas do projeto.',REF,origin='concrete_components_scope'))
    out['status']='partial'
    return out
