"""Compact view of adopted inputs; all advanced widgets still render and persist."""
import streamlit as st
from .display_precision import number_input
from .report import number


def concrete_summary(prefix):
    st.caption('PROJETAR: as referências construtivas são pontos de partida editáveis, não mínimos suficientes para aprovar a ancoragem. CONFERIR: informe fck, bordas e embutimento do detalhe real; valores de exemplo não comprovam essas condições. Cone, ruptura por borda e chumbadores continuam sujeitos às verificações e pendências do modelo.')
    s=st.session_state
    vals=[s.get(prefix+'_'+k) for k in ('fck','grout_fck','grout_t','hef')]
    if all(v is not None for v in vals):
        st.caption('Dados adotados · concreto '+number(vals[0])+' MPa; graute '+number(vals[1])+' MPa / '+number(vals[2])+' mm; hef '+number(vals[3])+' mm. Confira as hipóteses e os resultados da ancoragem; este resumo não representa aprovação.')


def projection_widget(prefix):
    key=prefix+'_anchor_projection_above_plate'
    st.session_state.setdefault(key,0.)
    with st.popover('Projeção superior do chumbador · detalhe'):
        number_input('Projeção acima da face superior da placa (mm; 0 = proposta automática)',min_value=0.,key=key)
        st.caption('Zero mantém uma proposta geométrica para arruela, porca e sobra de rosca, a confirmar na montagem. Um valor positivo é a projeção adotada pelo usuário. A projeção acima do concreto inclui também graute e placa; hef é medido para baixo a partir do topo do concreto. Não é o comprimento total da barra.')


def mc_excerpt_widget(c,r,prefix,digest,enabled,create_excerpt):
    """Compact editable Word output, cached only for the current canonical project."""
    key=prefix+'_mc_excerpt'
    saved=st.session_state.get(key)
    if saved and saved[0]!=digest:
        st.session_state.pop(key,None)
    st.caption('Trecho para MC: desenho, dados adotados, resultados e referências, com tabelas editáveis. Mantém as reprovações e pendências; a memória completa continua disponível.')
    if st.button('Gerar trecho para MC',key=prefix+'_generate_mc_excerpt',disabled=not enabled):
        try:
            st.session_state[key]=(digest,create_excerpt(c,r))
        except ValueError as exc:
            st.session_state.pop(key,None)
            st.warning(str(exc))
    saved=st.session_state.get(key)
    if enabled and saved and saved[0]==digest:
        st.download_button('Baixar trecho para MC .docx',saved[1],
            'Trecho_MC_'+{'cp':'base_U','bp':'base_engastada','pp':'base_rotulada'}[prefix]+'_LRO.docx',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',key=prefix+'_download_mc_excerpt')
