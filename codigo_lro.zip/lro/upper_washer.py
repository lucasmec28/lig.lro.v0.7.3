"""Limited upper-washer weld-metal and direct hole-bearing component models."""
from dataclasses import dataclass, fields
import math
from .models import Issue, finite_real

REF='ABNT NBR 8800:2024 corrigida 2025, 6.2, tabela 9, 6.3.3.3 e 6.7.2.5'
LIMITS=('Flexão local arruela–placa, contato combinado com o binário da barra, seção líquida, bloco de cisalhamento, '
        'transferência local e demais verificações do metal-base (§6.5), execução/acesso e ancoragem completa no concreto permanecem a complementar.')
@dataclass
class UpperWasher:
    model: str='off'
    layout: str='unspecified'
    leg: float=0.
    steel: str='unspecified'
    process: str='unspecified'
    base_hole: float=0.
    centered: bool=False
    @classmethod
    def from_dict(cls,data):
        if not isinstance(data,dict):raise ValueError('Dados da arruela superior devem ser um objeto.')
        return cls(**{k:v for k,v in data.items() if k in {f.name for f in fields(cls)}})

def validate_upper_washer(c):
    u=c.upper_washer
    if not isinstance(u,UpperWasher):return [Issue('error','Dados inválidos da arruela superior.',REF)]
    errors=[]
    active=c.native_anchor_shear and u.model!='off'
    for key in ('model','layout','steel','process'):
        if not isinstance(getattr(u,key),str):errors.append(Issue('error','Campo textual inválido da arruela superior: '+key,REF))
    if errors:return errors
    for k in ('leg','base_hole'):
        v=getattr(u,k)
        if not finite_real(v) or (active and (v<0 or v>1e5)):
            errors.append(Issue('error','Dimensão inválida da arruela superior: '+k,REF))
    if type(u.centered) is not bool:errors.append(Issue('error','Confirmação de concentricidade inválida.',REF))
    return errors

def upper_washer_assumptions(c):
    if not c.native_anchor_shear or c.upper_washer.model=='off':return []
    return ['Arruela superior: quatro filetes iguais externos contínuos; modelo elástico de linhas de raiz. F=Fv,Rd não reduzido por barra, mesmo com V=0. M=F(tp/2+3ta/4) é envelope conservador do app baseado na hipótese DG1 de curvatura reversa, não fórmula NBR ou prescrição DG1 da solda. Sem alterar equilíbrio global.',LIMITS]

def component_values(db,b,c,ta,tp,w):
    """Rectangular analytical kernel; first UI intentionally restricted to squares."""
    for v in (db,b,c,ta,tp,w):
        if not finite_real(v) or not 1e-6<=v<=1e6:raise ValueError('Dimensões fora do domínio numérico local: 10⁻⁶ a 10⁶ mm; sem resistência local creditada.')
    if min(b,c)<=db+1.5:raise ValueError('Furo não cabe na arruela.')
    F=.45*math.pi*db**2/4*400/1.35; L=2*(b+c); I=c*b*b/2+b**3/6; throat=w/math.sqrt(2)
    eb=ta/2; er=(tp+ta/2)/2; em=eb+er; mb=F*eb; mr=F*er; m=mb+mr
    qs=F/L; qb=mb*b/(2*I); qn=m*b/(2*I); q=math.hypot(qs,qn); qr=.6*485*throat/1.35
    lc=(b-db-1.5)/2; rt=1.2*lc*ta*450/1.35; rb=2.4*db*ta*450/1.35; rh=min(rt,rb)
    thin=min(ta,tp); wmin=3 if thin<=6.3 else 5 if thin<=12.5 else 6 if thin<=19 else 8
    return dict(F_N=F,L_mm=L,Iy_line_mm3=I,throat_mm=throat,Aw_mm2=throat*L,
        e_bearing_mm=eb,e_rod_DG1_mm=er,e_envelope_mm=em,M_bearing_Nmm=mb,M_rod_DG1_Nmm=mr,M_envelope_Nmm=m,
        q_shear_Npmm=qs,q_normal_bearing_only_Npmm=qb,q_normal_envelope_Npmm=qn,q_resultant_Npmm=q,
        q_bearing_only_resultant_Npmm=math.hypot(qs,qb),tau_resultant_MPa=q/throat,q_weld_Rd_Npmm=qr,weld_utilization=q/qr,
        lc_mm=lc,hole_tearout_Rd_N=rt,hole_bearing_cap_Rd_N=rb,hole_Rd_N=rh,hole_utilization=F/rh,
        weld_leg_min_mm=wmin,weld_leg_max_mm=ta if ta<6.3 else ta-1.5)

def add_upper_washer_checks(c,r,add):
    u=c.upper_washer
    if u.model=='off':return {}
    out={'status':'pending','statuses':{},'reasons':[]}
    reasons=out['reasons']
    for ok,text in [(u.model=='four_edge_elastic','Modelo local de solda não suportado.'),(u.layout=='four_edges','Informar quatro bordas externas contínuas.'),
        (u.steel=='ASTM A572 Gr.50','Identificar o aço da arruela como ASTM A572 Gr.50.'),
        (u.process=='smaw_e7018_single_pass','Informar SMAW/E7018 em passe único.'),(u.leg>0,'Informar perna positiva dos filetes.'),
        (u.base_hole>0,'Informar o furo circular real da placa.'),(u.centered,'Confirmar concentricidade, sem calço ou afastamento.'),(c.anchor_washer_t<=100,'ASTM A572 Gr.50: espessura acima do domínio de 100 mm.')]:
        if not ok:reasons.append(text)
    if reasons:
        for reason in reasons:r.issues.append(Issue('pending',reason,REF,origin='upper_washer'))
        return out
    s=c.anchor_washer_side; ta=c.anchor_washer_t; w=u.leg
    try:out.update(component_values(c.db,s,s,ta,c.tp,w))
    except ValueError as exc:
        reasons.append(str(exc));r.issues.append(Issue('noncompliance',str(exc),REF));out['status']='fail';return out
    def check(key,name,sd,rd,unit,equation,variables):
        add('uw_'+key,name,sd,rd,unit,REF,equation,f'Sd={sd:.9g}; Rd={rd:.9g}',variables)
        return r.checks[-1].passed
    weld=check('weld','Arruela superior — metal dos quatro filetes',out['q_resultant_Npmm'],out['q_weld_Rd_Npmm'],'N/mm',
        'qmax=√[(F/L)²+(Mw b/(2Iy,linha))²] ≤ 0,6 fw a/γw2', 'F=Fv,Rd não reduzido; Mw=F(tp/2+3ta/4), envelope conservador do app. Metal-base separado.')
    hole=check('hole','Arruela superior — furo, envelope de capacidade',out['F_N'],out['hole_Rd_N'],'N',
        'F ≤ min(1,2 lc ta fu; 2,4 db ta fu)/γa2','Furo padrão db+1,5 mm; fu=450 MPa. Envelope conservador, não distribuição V/4 nem reprovação de todo V menor.')
    gates=[]
    gates.append(check('leg_min','Arruela superior — perna mínima',out['weld_leg_min_mm'],w,'mm','w ≥ wmin','Tabela 11, parte mais fina; passe único.'))
    gates.append(check('leg_max','Arruela superior — perna máxima',w,out['weld_leg_max_mm'],'mm','w ≤ ta ou ta−1,5','Sem exceção de borda reforçada.'))
    gates.append(check('length_min','Arruela superior — comprimento mínimo de borda',max(4*w,40),s,'mm','b ≥ max(4w;40)','Quatro bordas contínuas de mesmo comprimento.'))
    length_domain=s<=100*w
    if not length_domain:
        text='Comprimento da arruela fora do modelo sem redução: b>100z exige tratamento de comprimento efetivo. Não é uma proibição geral NBR; capacidades nominais abaixo são condicionais.'
        reasons.append(text);r.issues.append(Issue('pending',text,REF,origin='upper_washer'))
    out['resistance_basis_valid']=length_domain

    gates.append(check('overlap','Arruela superior — dimensão de sobreposição',max(5*min(ta,c.tp),25),s,'mm','b ≥ max(5tmin;25)','Não verifica flexão da ponte sobre o furo.'))
    shelf=c.washer_clearance
    gates.append(check('shelf','Arruela superior — prateleira livre para filete',w,shelf,'mm','g ≥ w','Raiz e pé apoiados; acesso de execução permanece separado.'))
    # Explicit plan footprint of specified column fillets; only overlapping regions count.
    from .base_plate_details import fillet_dimensions
    obstacles=[]; p=c.column
    if c.weld_flange_type=='fillet':
        z=fillet_dimensions(c.weld_flange_size,c.weld_flange_measure)['leg']
        for sign in (-1,1):
            x=sign*(p.d/2-p.tf/2)
            obstacles.append((x-p.tf/2-z,x+p.tf/2+z,-p.bf/2-z,p.bf/2+z))
    if c.weld_web_type=='fillet':
        z=fillet_dimensions(c.weld_web_size,c.weld_web_measure)['leg']
        obstacles.append((-p.d/2+p.tf-z,p.d/2-p.tf+z,-p.tw/2-z,p.tw/2+z))
    if c.stiffener_detail=='web_pair':
        for sign in (-1,1):
            x=sign*(p.d/2+c.stiffener_length/2)
            obstacles.append((x-c.stiffener_length/2,x+c.stiffener_length/2,-c.stiffener_t/2,c.stiffener_t/2))
    collision=False
    for x in (-c.a,c.a):
        for y in (-c.a2/2,c.a2/2):
            box=(x-s/2-w,x+s/2+w,y-s/2-w,y+s/2+w)
            if any(min(box[1],o[1])-max(box[0],o[0])>1e-9 and min(box[3],o[3])-max(box[2],o[2])>1e-9 for o in obstacles):collision=True
    if collision:
        text='Implantação dos filetes da arruela interfere em planta com solda especificada da coluna ou enrijecedor. Rever dimensões e acesso.'
        r.issues.append(Issue('noncompliance',text,REF));reasons.append(text);gates.append(False)
    # Circular concentric hole must be contained strictly inside the four root lines.
    support=s-u.base_hole
    supported=(support>0 and u.base_hole>=c.db and u.base_hole/2<c.anchor_edge_distance and u.base_hole<c.a2)
    if not supported:
        r.issues.append(Issue('noncompliance','Furo real deve caber estritamente entre as raízes, conter a barra e permanecer inteiro e separado na placa.',REF));gates.append(False)
    # Maximum hole-edge distance; minimum alternative is explicitly covered by direct bearing check.
    gates.append(check('edge_max','Arruela superior — distância máxima à borda',s/2,min(12*ta,150),'mm','e ≤ min(12ta;150)','Distância mínima admite alternativa resistente de 6.3.3.3, Tabela 16; esta alternativa é verificada pelo envelope do furo.'))
    out['statuses']={'weld_metal':'pass' if weld else 'fail','hole':'pass' if hole else 'fail','weld_detail':'pass' if all(gates) else 'fail'}
    out['length_domain_status']='pass' if length_domain else 'pending'
    out['status']=('pass' if length_domain else 'pending') if weld and hole and all(gates) else 'fail'
    r.issues.append(Issue('pending',LIMITS,REF,origin='upper_washer_scope'))
    return out
