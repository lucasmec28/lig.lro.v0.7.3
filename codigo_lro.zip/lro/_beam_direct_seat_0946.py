"""Restricted direct-flange bearing seat with circular holes in both flanges.

DG6 A1(c) identifies the gravity family, as reviewed by the parent. NBR
resistances below remain conditional on the stated fabrication specification.
No intermediate plate, upper weld, contact solution, prying or bolt V/4 model.
"""
from dataclasses import asdict, dataclass, fields
import math

from .models import Profile, STEELS, finite_real, profiles

FAMILY = "Viga sobre viga — apoio direto entre mesas"
CONNECTION_TYPE = "beam_direct_seat_standard_holes"
COMPONENT_VERSION = "0.9.46-direct-seat-local-review-dev.2"
SCHEMA_VERSION = 3
NBR = "ABNT NBR 8800:2024, Errata 1:2025"
GAMMA_A1, GAMMA_A2, GAMMA_W2 = 1.10, 1.35, 1.35
E, FW, MINIMUM_VERTICAL = 200000.0, 485.0, 45000.0
UNITS = {"force": "N", "length": "mm", "stress": "MPa", "moment": "N mm"}
RADIUS_SOURCE = "Gerdau, Tabela de Bitolas, revisão 09/2017; R nominal inferido de (h-d')/2; conferir peça real."


@dataclass(frozen=True)
class BeamDirectSeat:
    beam: Profile
    support: Profile
    beam_steel: str = "ASTM A572 Gr.50"
    support_steel: str = "ASTM A572 Gr.50"
    stiffener_steel: str = "ASTM A36"
    V: float = 25595.3565
    N: float = 0.0
    applied_moment_y: float = 0.0
    torsion: float = 0.0
    reference_x: float = 0.0
    end: float = 70.0
    beam_radius: float = 12.0
    support_radius: float = 12.0
    radius_source: str = RADIUS_SOURCE
    db: float = 16.0
    upper_hole: float = 18.0
    support_hole: float = 18.0
    bolt_pitch: float = 70.0
    bolt_gauge: float = 80.0
    upper_washer_diameter: float = 33.0
    lower_washer_diameter: float = 33.0
    tool_radius: float = 17.0
    clearance: float = 2.0
    stiff_thickness: float = 8.0
    stiff_width: float = 60.0
    stiff_height: float = 381.4
    stiff_clip: float = 20.0
    stiff_weld: float = 5.0
    stiff_weld_length: float = 150.0
    stiff_y: float = 0.0
    fitted_required: bool = True
    direct_bearing_faces_prepared: bool = True
    web_attached: bool = True
    loaded_flange_attached: bool = True
    full_height_attached_both: bool = True
    rotational_detail_confirmed: bool = False
    external_length_reported_mm: float = 4000.0
    external_support_node: str = "interno central"
    external_bracing_record: str = "Contraventamentos e vigas informados; contencao longitudinal local nao comprovada neste registro."
    project: str = "W360x39 sobre W410x38,8 — apoio direto restrito"
    notes: str = "Especificação proposta; conferir ajuste, superfícies, ferramentas e montagem reais."

    @property
    def fixed_assumptions(self):
        return {
            "axes": "x: W360/superior; y: W410/apoio; z: vertical",
            "gravity_family": "ASI DG6 A1(c), familia conferida pelo revisor; verificacoes locais pela NBR",
            "local_calculated_scope": "5.7.3 e 5.7.4, almas originais, compressao local centrada",
            "intermediate_plate": False, "upper_weld": False, "bolt_count": 4,
            "upper_hole_type": "standard circular", "support_hole_type": "standard circular",
            "axial_release_verified": False,
            "gravity_path": "apoio direto entre mesas e verificacao local das almas originais",
            "pair_strength_credit": False, "pair_dimensioned": False,
            "stiffener_strength_credited": False,
            "stiffener_role": "par construtivo preservado; sem capacidade ou divisao de carga creditada",
            "fitted_required_as_construction_specification": self.fitted_required,
            "bearing_faces_prepared_as_specification": self.direct_bearing_faces_prepared,
            "web_attached_as_construction_specification": self.web_attached,
            "loaded_flange_attached_as_construction_specification": self.loaded_flange_attached,
            "full_height_both_flanges_as_construction_specification": self.full_height_attached_both,
            "actual_fit_or_preparation_attested": False,
            "actual_hardware_or_tool_attested": False,
            "actual_longitudinal_roll_restraint_attested": False,
            "stiffener_root_relief": "envelope quadrado c x c nas duas extremidades; c >= R nominal",
            "external_information": {
                "status": "PROVIDED",
                "length_reported_mm": self.external_length_reported_mm,
                "support_node": self.external_support_node,
                "bracing_record": self.external_bracing_record,
                "normative_lateral_length_attested": False,
                "span_inferred": False,
                "used_in_resistance_calculation": False,
                "global_stability_responsibility": "engenheiro responsavel pelo projeto externo",
            },
            "gamma_a1": GAMMA_A1, "gamma_a2": GAMMA_A2, "gamma_w2": GAMMA_W2,
            "no_additional_action_factor": True, "contact_or_prying_solved": False,
            "global_pass": False,
        }

    def to_dict(self):
        errors = input_errors(self)
        if errors:
            raise ValueError("; ".join(errors))
        return {"schema_version": SCHEMA_VERSION, "connection_type": CONNECTION_TYPE,
                "component_version": COMPONENT_VERSION, "connection": asdict(self),
                "units": dict(UNITS), "fixed_assumptions": self.fixed_assumptions}

    @classmethod
    def from_dict(cls, data):
        keys = {"schema_version", "connection_type", "component_version", "connection", "units", "fixed_assumptions"}
        if not isinstance(data, dict) or set(data) != keys:
            raise ValueError("Projeto de apoio direto: campos ausentes ou desconhecidos; resultados não são entradas.")
        if data["connection_type"] == "beam_direct_seat":
            raise ValueError("Rascunho anterior com oblongos: abrir a cópia anterior correspondente. Não é convertido para furos circulares.")
        if data["component_version"] == "0.9.46-direct-seat-circular-review-dev.1":
            raise ValueError("Projeto circular DEV1: abrir a copia anterior correspondente. O escopo resistente nao e convertido automaticamente para LOCAL DEV2.")
        if (type(data["schema_version"]) is not int or data["schema_version"] != SCHEMA_VERSION
                or data["connection_type"] != CONNECTION_TYPE
                or data["component_version"] != COMPONENT_VERSION):
            raise ValueError("Família ou versão incompatível; projetos legados não são convertidos automaticamente.")
        raw = data["connection"]
        if not isinstance(raw, dict) or set(raw) != {f.name for f in fields(cls)}:
            raise ValueError("Entradas incompletas ou desconhecidas.")
        raw = dict(raw)
        for role in ("beam", "support"):
            if not isinstance(raw[role], dict) or set(raw[role]) != {f.name for f in fields(Profile)}:
                raise ValueError("Perfil incompleto ou desconhecido: " + role)
            raw[role] = Profile(**raw[role])
        c = cls(**raw)
        canonical = c.to_dict()
        # Equality alone would let JSON true masquerade as the number 1.
        if not _same_json(data["units"], canonical["units"]) or not _same_json(data["fixed_assumptions"], canonical["fixed_assumptions"]):
            raise ValueError("Unidades ou premissas incompatíveis.")
        return c


def _same_json(a, b):
    if type(a) is not type(b):
        return False
    if isinstance(a, dict):
        return set(a) == set(b) and all(_same_json(a[k], b[k]) for k in a)
    if isinstance(a, list):
        return len(a) == len(b) and all(_same_json(x, y) for x, y in zip(a, b))
    return a == b


SIGNED = {"N", "applied_moment_y", "torsion", "reference_x", "stiff_y"}
NONNEGATIVE = {"V", "clearance", "stiff_clip"}
BOOLEANS = {"fitted_required", "direct_bearing_faces_prepared", "web_attached", "loaded_flange_attached", "full_height_attached_both", "rotational_detail_confirmed"}
TEXT = {"beam_steel", "support_steel", "stiffener_steel", "radius_source", "project", "notes", "external_support_node", "external_bracing_record"}


def input_errors(c):
    if not isinstance(c, BeamDirectSeat):
        return ["Entrada deve ser BeamDirectSeat."]
    errors = []
    for f in fields(c):
        key, value = f.name, getattr(c, f.name)
        if key in ("beam", "support"):
            if not isinstance(value, Profile):
                errors.append(key + ": Profile obrigatório.")
                continue
            for item in ("d", "bf", "tw", "tf", "clear", "area", "mass"):
                if not finite_real(getattr(value, item)) or getattr(value, item) <= 0:
                    errors.append(key + "." + item + ": positivo finito obrigatório; bool não é número.")
            for item in ("name", "family", "source"):
                if not isinstance(getattr(value, item), str) or not getattr(value, item).strip():
                    errors.append(key + "." + item + ": texto não vazio obrigatório.")
            if not any(e.startswith(key + ".") for e in errors):
                if value.d <= 2 * value.tf or value.bf <= value.tw or value.clear > value.d - 2 * value.tf:
                    errors.append(key + ": seção nominal inconsistente.")
        elif key in TEXT:
            if not isinstance(value, str) or (key != "notes" and not value.strip()):
                errors.append(key + ": texto obrigatório.")
        elif key in BOOLEANS:
            if type(value) is not bool:
                errors.append(key + ": booleano obrigatório.")
        elif not finite_real(value):
            errors.append(key + ": número finito obrigatório; bool não é número.")
        elif key not in SIGNED and (value < 0 if key in NONNEGATIVE else value <= 0):
            errors.append(key + ": dimensão/força inválida.")
    for key in ("beam_steel", "support_steel", "stiffener_steel"):
        value = getattr(c, key)
        if isinstance(value, str) and value not in STEELS:
            errors.append(key + ": aço fora do catálogo definido.")
    if errors:
        return errors
    for role in ("beam", "support"):
        steel, p = STEELS[getattr(c, role + "_steel")], getattr(c, role)
        if not steel.rolled_allowed or not (steel.profile_min <= min(p.tf, p.tw) and max(p.tf, p.tw) <= steel.profile_max):
            errors.append(role + ": material/espessura fora do domínio de produto laminado.")
    for role, thickness in (("stiffener", c.stiff_thickness),):
        steel = STEELS[getattr(c, role + "_steel")]
        if not steel.plate_allowed or not (steel.plate_min <= thickness <= steel.plate_max):
            errors.append(role + ": material/espessura fora do domínio de chapa.")
    return errors


def presets():
    p = profiles()
    return {"Caso informado — V=2610 kgf ELU, N=My=Tz=0 — apoio direto":
            BeamDirectSeat(p["W 360 x 39,0"], p["W 410 x 38,8"])}


def _finite(name, value, positive=False):
    if not finite_real(value) or (value <= 0 if positive else value < 0):
        raise ValueError("Falha numérica: " + name)
    return value


def _row(cid, name, demand=None, resistance=None, unit="N", reference="", equation="", notes="", category="RESISTANCE", status=None, **data):
    eta = None
    if demand is not None:
        _finite(cid + "/demanda", demand)
    if resistance is not None:
        _finite(cid + "/resistência", resistance, positive=True)
    if demand is not None and resistance is not None:
        eta = _finite(cid + "/índice", demand / resistance)
    if status is None:
        status = "PENDING" if eta is None else "PASS" if eta <= 1.0 else "FAIL"
    return dict(id=cid, name=name, demand=demand, resistance=resistance, eta=eta, unit=unit,
                reference=reference, equation=equation, notes=notes, category=category, status=status, **data)


def _geometry(c):
    rows = []
    def check(cid, name, value, limit, relation=">=", reference="", notes="", unit="mm"):
        _finite(cid + "/valor", abs(value))
        _finite(cid + "/limite", abs(limit))
        ok = value >= limit if relation == ">=" else value <= limit if relation == "<=" else value > limit if relation == ">" else value == limit
        rows.append(_row(cid, name, unit=unit, reference=reference, equation=relation, notes=notes,
                         category="GEOMETRY", status="PASS" if ok else "FAIL", value=value, limit=limit))
    x, y = c.bolt_pitch / 2, c.bolt_gauge / 2
    upper_toe = c.beam.tw / 2 + c.beam_radius
    lower_toe = c.support.tw / 2 + c.support_radius
    check("upper_hole", "Furo padrão M16 — mesa inferior da viga superior", c.upper_hole, 18.0, "==", NBR + " tabela 14")
    check("support_hole", "Furo padrão M16 — mesa superior da viga de apoio", c.support_hole, 18.0, "==", NBR + " tabela 14")
    check("upper_end_edge", "Borda longitudinal — mesa inferior da viga superior", c.end - x, 22.0, reference=NBR + " tabela 16")
    check("upper_side_edge", "Borda lateral — mesa inferior da viga superior", c.beam.bf / 2 - y, 22.0, reference=NBR + " tabela 16")
    check("lower_side_edge", "Borda lateral — mesa superior da viga de apoio", c.support.bf / 2 - x, 22.0, reference=NBR + " tabela 16")
    check("bolt_spacing_x", "Espaçamento mínimo entre centros x", c.bolt_pitch, 2.7 * c.db, reference=NBR + " 6.3.9", notes="3db é recomendação; mínimo verificado 2,7db.")
    check("bolt_spacing_y", "Espaçamento mínimo entre centros y", c.bolt_gauge, 2.7 * c.db, reference=NBR + " 6.3.9")
    check("bolt_clear_spacing_x", "Espaçamento livre entre bordas dos furos circulares x", c.bolt_pitch - max(c.upper_hole, c.support_hole), c.db, reference=NBR + " 6.3.9")
    check("bolt_clear_spacing_y", "Espaçamento livre entre bordas dos furos circulares y", c.bolt_gauge - max(c.upper_hole, c.support_hole), c.db, reference=NBR + " 6.3.9")
    max_spacing = min(14 * min(c.beam.tf, c.support.tf), 180.0)
    check("bolt_spacing_max_x", "Espaçamento máximo x — menor ramo", c.bolt_pitch, max_spacing, "<=", NBR + " 6.3.10", "Menor ramo 14t/180 adotado; não presume proteção/pintura ou ambiente do projeto.")
    check("bolt_spacing_max_y", "Espaçamento máximo y", c.bolt_gauge, max_spacing, "<=", NBR + " 6.3.10")
    check("upper_end_edge_max", "Borda longitudinal máxima — mesa inferior da viga superior", c.end - x, min(12 * c.beam.tf, 150.), "<=", NBR + " 6.3.12")
    check("upper_side_edge_max", "Borda lateral máxima — mesa inferior da viga superior", c.beam.bf / 2 - y, min(12 * c.beam.tf, 150.), "<=", NBR + " 6.3.12")
    check("lower_side_edge_max", "Borda lateral máxima — mesa superior da viga de apoio", c.support.bf / 2 - x, min(12 * c.support.tf, 150.), "<=", NBR + " 6.3.12")
    check("upper_end_overlap", "Fim superior cobre extremidade do enrijecedor positivo", c.end, c.support.tw / 2 + c.stiff_width)
    check("upper_end_no_overhang", "Fim superior sem projeção além da mesa inferior", c.end, c.support.bf / 2, "<=")
    check("upper_washer_end", "Arruela acima da mesa inferior da viga superior — fim", c.end - x, c.upper_washer_diameter / 2)
    check("upper_washer_edge", "Arruela acima da mesa inferior da viga superior — borda lateral", c.beam.bf / 2 - y, c.upper_washer_diameter / 2)
    check("upper_washer_root", "Arruela acima da mesa inferior da viga superior — concordância", y - upper_toe, c.upper_washer_diameter / 2)
    check("upper_washer_covers_hole", "Diâmetro externo da arruela superior cobre a abertura", c.upper_washer_diameter, c.upper_hole, ">",
          notes="Condição física necessária de anel externo positivo; furo interno, classe e capacidade da ferragem real permanecem a conferir.")
    check("lower_washer_root", "Arruela abaixo da mesa superior da viga de apoio — concordância", x - lower_toe, c.lower_washer_diameter / 2)
    check("lower_washer_edge", "Arruela abaixo da mesa superior da viga de apoio — borda", c.support.bf / 2 - x, c.lower_washer_diameter / 2)
    check("lower_washer_covers_hole", "Diâmetro externo da arruela inferior cobre a abertura", c.lower_washer_diameter, c.support_hole, ">",
          notes="Condição física necessária de anel externo positivo; furo interno, classe e capacidade da ferragem real permanecem a conferir.")
    check("tool_upper_root", "Ferramenta + folga — mesa inferior da viga superior", y - upper_toe, c.tool_radius + c.clearance)
    check("tool_lower_root", "Ferramenta + folga — mesa superior da viga de apoio", x - lower_toe, c.tool_radius + c.clearance)
    check("tool_hardware", "Envelope mínimo da haste; cabeça/porca reais a conferir", c.tool_radius, c.db / 2,
          notes="Somente condição geométrica necessária da haste. Soquete não precisa envolver a arruela; cabeça, porca e ferramenta reais permanecem a conferir.")
    check("lower_hole_stiffener", "Furo inferior não cruza enrijecedor", y - abs(c.stiff_y) - c.stiff_thickness / 2, c.support_hole / 2)
    check("lower_washer_stiffener", "Arruela inferior não cruza enrijecedor", y - abs(c.stiff_y) - c.stiff_thickness / 2, c.lower_washer_diameter / 2)
    check("tool_stiffener_weld", "Ferramenta fora do envelope enrijecedor/filete", y - abs(c.stiff_y) - c.stiff_thickness / 2 - c.stiff_weld, c.tool_radius + c.clearance)
    check("stiff_width_fit", "Enrijecedor cabe sob a mesa superior da viga de apoio", c.stiff_width, (c.support.bf - c.support.tw) / 2, "<=")
    check("stiff_width_min", "Largura do enrijecedor + meia alma", c.stiff_width + c.support.tw / 2, c.support.bf / 3, reference=NBR + " 5.7.9.5")
    check("stiff_thickness_min", "Espessura mínima do enrijecedor", c.stiff_thickness, max(c.support.tf / 2, c.stiff_width / 16), reference=NBR + " 5.7.9.5")
    check("stiff_clip_contact", "Contato líquido positivo após recorte", c.stiff_clip, c.stiff_width, "<=", notes="Igualdade não produz contato válido e é bloqueada separadamente.")
    check("stiff_clip_root_envelope", "Alívio quadrado proposto envolve a concordância inferior", c.stiff_clip, c.support_radius, reference="Geometria do alívio especificado",
          notes="Envelope conservador c×c em cada extremidade da raiz. c≥R é condição deste detalhe proposto; não é reprovação universal de outro contorno ajustado.")
    check("stiff_height", "Enrijecedor proposto entre faces internas das mesas", c.stiff_height, c.support.d - 2 * c.support.tf, "==", notes="Cota nominal; ajuste e recortes reais permanecem especificação.")
    check("stiff_alignment", "Plano do par de enrijecedores coincide com alma superior", abs(c.stiff_y), 0.0, "==")
    check("stiff_bearing_width", "Espessura do par cobre faixa da alma superior", c.stiff_thickness, c.beam.tw)
    check("stiff_weld_length", "Comprimento efetivo de solda cabe no enrijecedor", c.stiff_weld_length, c.stiff_height, "<=")
    check("stiff_weld_intact_body", "Linhas contínuas cabem no corpo após os dois alívios", c.stiff_weld_length, c.stiff_height - 2 * c.stiff_clip, "<=",
          notes="Duas linhas verticais contínuas no corpo intacto, fora dos envelopes quadrados das extremidades.")
    check("stiff_weld_length_min", "Comprimento efetivo mínimo do filete contínuo", c.stiff_weld_length, 4 * c.stiff_weld, reference=NBR + " 6.2.6.2.3",
          notes="Opção expressa de filete contínuo curto: perna de cálculo limitada a25% do comprimento. Não reutilizar para solda intermitente.")
    check("stiff_weld_length_max", "Linha de filete sem redução por comprimento", c.stiff_weld_length, 100 * c.stiff_weld, "<=", NBR + " 6.2.2.2")
    check("stiff_weld_max", "Perna do filete na borda do enrijecedor", c.stiff_weld, c.stiff_thickness if c.stiff_thickness < 6.3 else c.stiff_thickness - 1.5, "<=", NBR + " 6.2.6.2.2")
    thinner = min(c.stiff_thickness, c.support.tw, c.support.tf)
    wmin = 3.0 if thinner <= 6.3 else 5.0 if thinner <= 12.5 else 6.0 if thinner <= 19.0 else 8.0
    check("stiff_weld_min", "Perna mínima do filete do enrijecedor", c.stiff_weld, wmin, reference=NBR + " tabela 11", notes="Espessura da parte mais fina dentre as duas interfaces declaradas.")
    return rows, {
        "axes": "x superior, y inferior, z vertical", "physical_bolts": 4, "physical_stiffeners": 2,
        "bolt_coordinates_mm": [[-x, -y], [x, -y], [-x, y], [x, y]],
        "upper_end_x_mm": c.end, "load_reference_x_mm": c.reference_x,
        "upper_flange_y_bounds_mm": [-c.beam.bf / 2, c.beam.bf / 2],
        "lower_flange_x_bounds_mm": [-c.support.bf / 2, c.support.bf / 2],
        "upper_root_toe_mm": upper_toe, "lower_root_toe_mm": lower_toe,
        "radii_basis": c.radius_source, "radii_actual_measured": False,
        "upper_tool_available_radius_mm": y - upper_toe,
        "lower_tool_available_radius_mm": x - lower_toe,
        "upper_hole_diameter_mm": c.upper_hole,
        "support_hole_diameter_mm": c.support_hole,
        "upper_hole_type": "standard circular", "support_hole_type": "standard circular",
        "upper_washer_diameter_mm": c.upper_washer_diameter,
        "lower_washer_diameter_mm": c.lower_washer_diameter,
        "axial_release_verified": False,
        "stiff_tip_projection_mm": (c.support.bf - c.support.tw) / 2 - c.stiff_width,
        "clip_beyond_nominal_fillet_mm": max(0.0, c.stiff_clip - c.support_radius),
        "stiffener_root_relief_model": "envelope quadrado c×c em ambas as extremidades da raiz",
        "stiffener_intact_body_height_mm": c.stiff_height - 2 * c.stiff_clip,
        "clip_is_demonstrated_simple_span": False,
        "fit_is_fabrication_requirement_not_observed_fact": True,
        "intermediate_plate": False, "upper_weld": False,
    }


def _resistance_checks(c, force):
    rows = []
    for role, p, steel in (("upper", c.beam, STEELS[c.beam_steel]),
                           ("lower", c.support, STEELS[c.support_steel])):
        yield_bound = _finite(role + "/alma escoamento",
                             1.10 * 2.5 * p.tf * steel.fy * p.tw / GAMMA_A1, True)
        crippling = _finite(role + "/alma enrugamento",
                           .33 * p.tw ** 2 / GAMMA_A1 * math.sqrt(E * steel.fy * p.tf / p.tw), True)
        label = ("viga superior " if role == "upper" else "viga de apoio ") + p.name
        rows.extend([
            _row(role + "_web_yield", "Alma original da " + label + " - escoamento local",
                 force, yield_bound, reference=NBR + " 5.7.1/5.7.3",
                 equation="1,10 x 2,5tf x fy x tw / gamma_a1",
                 pair_strength_credit=False,
                 notes="Limite inferior do ramo de extremidade com ln tendendo a zero e k=tf. Nao representa footprint presumido; sem credito do par construtivo."),
            _row(role + "_web_crippling", "Alma original da " + label + " - enrugamento local",
                 force, crippling, reference=NBR + " 5.7.4",
                 equation="0,33tw^2 sqrt(E fy tf/tw) / gamma_a1",
                 pair_strength_credit=False,
                 notes="Menor ramo de extremidade com ln tendendo a zero. Nao usa pressao uniforme, raio ou capacidade de enrijecedor presumida."),
        ])
    return rows


def evaluate(c):
    out = {
        "connection_type": CONNECTION_TYPE, "component_version": COMPONENT_VERSION,
        "family": FAMILY, "global_pass": False, "engineering_approved": False,
        "local_connection_qualified": False,
        "local_strength_checks_satisfied": False, "local_geometry_checks_satisfied": False,
        "local_checks_satisfied": False, "gravity_checks_satisfied": False,
        "pair_strength_credit": False, "pair_dimensioned": False,
        "checks": [], "geometry": {}, "actions": {}, "scopes": [],
        "input_errors": [], "status": "INVALID_INPUT",
    }
    errors = input_errors(c)
    if errors:
        out["input_errors"] = errors
        out["diagnosis"] = "Entrada invalida; nenhuma resistencia calculada."
        return out
    out["external_information"] = dict(c.fixed_assumptions["external_information"])
    force = max(c.V, MINIMUM_VERTICAL)
    out["actions"] = {
        "V_ELU_N": c.V, "N_N": c.N, "applied_moment_y_Nmm": c.applied_moment_y,
        "torsion_Nmm": c.torsion, "reference_x_mm": c.reference_x,
        "action_factor": 1.0, "minimum_vertical_strength_case_N": MINIMUM_VERTICAL,
        "check_force_N": force, "minimum_is_action_multiplier": False,
        "contact_resultant_solved_N": None, "bolt_tensions_solved_N": None,
        "vertical_bolt_shear_from_V_N": None,
        "force_allocated_to_constructive_pair_N": None,
    }
    outside = []
    if c.beam.family != "W" or c.support.family != "W":
        outside.append("Somente dois perfis W laminados neste nucleo.")
    if c.V <= 0 or any(getattr(c, k) != 0 for k in ("N", "applied_moment_y", "torsion", "reference_x")):
        outside.append("Gravidade local restrita: V descendente positivo, N=My=Tz=0 e reacao centrada x=0; entradas preservadas.")
    if c.db != 16.0:
        outside.append("Detalhamento tabulado e ferragem nominal implementados somente para M16.")
    if outside:
        out["status"] = "OUTSIDE_SCOPE"
        out["scopes"] = [{"id": "local_gravity_domain", "status": "OUTSIDE_SCOPE", "notes": " ".join(outside)}]
        out["diagnosis"] = " ".join(outside)
        return out
    try:
        rows, geometry = _geometry(c)
        geometry.update(pair_strength_credit=False, pair_dimensioned=False,
                        stiffener_role="par construtivo sem capacidade resistente calculada")
        out["checks"], out["geometry"] = rows, geometry
        geometry_ok = not any(r["status"] == "FAIL" for r in rows)
        if c.stiff_clip >= c.stiff_width:
            geometry_ok = False
            out["checks"].append(_row("stiff_constructive_contact_positive", "Contato construtivo apos recorte",
                category="GEOMETRY", status="FAIL", notes="Recorte nao pode eliminar toda a largura proposta; nenhuma resistencia do par e creditada."))
        strengths = _resistance_checks(c, force)
        out["checks"].extend(strengths)
        strength_ok = all(r["status"] == "PASS" for r in strengths)
        model_ok = c.direct_bearing_faces_prepared
        out["local_strength_checks_satisfied"] = strength_ok
        out["local_geometry_checks_satisfied"] = geometry_ok
        out["local_checks_satisfied"] = strength_ok and geometry_ok and model_ok
        # Compatibility alias means calculated local checks only, never qualification.
        out["gravity_checks_satisfied"] = out["local_checks_satisfied"]
        out["local_necessary_construction_condition_satisfied"] = False
        lower_bound = min(r["resistance"] for r in strengths if r["id"].startswith("lower_"))
        out["constructive_pair"] = {
            "strength_credit": False, "dimensioned": False,
            "thickness_mm": c.stiff_thickness, "width_mm": c.stiff_width,
            "height_mm": c.stiff_height, "root_cut_mm": c.stiff_clip,
            "web_fillet_leg_mm": c.stiff_weld, "web_fillet_length_mm": c.stiff_weld_length,
            "strength_calculated": False, "force_share_assumed_N": None,
            "original_support_web_local_bound_N": lower_bound,
            "local_attachment_increment_N": max(0.0, force - lower_bound),
            "increment_reference": NBR + " 5.7.9.2",
            "notes": "Diferenca normativa local nao constitui dimensionamento do par ou das suas soldas. Zero nao dispensa o detalhe construtivo; nenhum C, V/2, V/4 ou prying e resolvido.",
        }
        out["scopes"] = [
            {"id": "local_calculated_web_modes", "status": "CONDITIONAL_PASS" if strength_ok else "FAIL",
             "notes": "Somente escoamento e enrugamento locais das duas almas originais, NBR5.7.3/5.7.4. Minimo45kN separado da acao ELU. Nenhuma resistencia do par e somada."},
            {"id": "local_gravity_model", "status": "CONDITIONAL" if model_ok else "PENDING",
             "notes": "Familia DG6 A1(c) conferida pelo revisor, apoio direto entre mesas e compressao local centrada. Superficies preparadas compatíveis sao especificacao a executar, nao fato observado. Nenhuma pressao uniforme ou C/T e resolvido."},
            {"id": "local_necessary_5_7_8", "status": "PENDING", "reference": NBR + " 5.7.8",
             "notes": "Condicao local necessaria na propria viga superior (W360 no caso informado): quando o apoio/extremidade nao tiver restricao a rotacao em torno do eixo longitudinal e a alma nao estiver ligada a outra viga/pilar, prever enrijecedores transversais de altura completa soldados as mesas e a alma. O engenheiro deve fornecer contencao local demonstrada ou o detalhe exigido, conforme aplicabilidade. Quatro parafusos entre mesas, par da viga de apoio e contraventamentos qualitativos nao comprovam essa contencao. Condicao desconhecida e pendencia, nao falha fisica demonstrada."},
            {"id": "external_stability_5_7_5", "status": "EXTERNAL_REQUIRED", "reference": NBR + " 5.7.5",
             "notes": "Estabilidade e contencoes sao responsabilidade do projeto externo. Os4m sao informacao fornecida; nao sao adotados como vao ou comprimento lateralmente destravado normativo. Conferir ambas as mesas, estado de compressao e os requisitos aplicaveis de5.7.5; nenhuma capacidade de estabilidade e calculada neste nucleo."},
            {"id": "constructive_pair", "status": "NO_STRENGTH_CREDIT",
             "notes": "Par conforme dimensoes de entrada preservado como detalhe construtivo; nominal do caso8x60, altura381,4, recortes20, filetes5/L150. Geometria nominal e conferida, mas par, fitted, barra composta e soldas resistentes nao sao dimensionados nem creditados."},
            {"id": "actual_fabrication", "status": "PENDING",
             "notes": "Ajuste, preparo das faces, raio, recortes, soldas, arruelas e ferramenta reais devem respeitar o detalhe. Flags de especificacao nao sao atestado de fabricacao."},
            {"id": "mounting_retention", "status": "PENDING",
             "notes": "Furos circulares padrao em ambas as mesas; montagem e aperto reais a conferir. Nao se verifica liberacao axial ou retencao sob outras acoes."},
            {"id": "rotation", "status": "DECLARED" if c.rotational_detail_confirmed else "PENDING",
             "notes": "Rotacao da extremidade declarada; nao e comprovacao da contencao longitudinal de5.7.8." if c.rotational_detail_confirmed else "Conferir rotacao da extremidade e montagem; condicao distinta da contencao longitudinal de5.7.8."},
            {"id": "global_connection", "status": "OUTSIDE_CALCULATED_SCOPE",
             "notes": "Este resultado nao aprova a ligacao completa, a estabilidade global, a barra recortada ou uso fora do escopo local calculado."},
        ]
        if not geometry_ok:
            out["status"] = "LOCAL_GEOMETRY_FAILURE"
        elif not strength_ok:
            out["status"] = "LOCAL_RESISTANCE_FAILURE"
        elif not model_ok:
            out["status"] = "LOCAL_MODEL_SPECIFICATION_PENDING"
        else:
            out["status"] = "LOCAL_CHECKS_SATISFIED_NECESSARY_CONDITION_PENDING"
        out["diagnosis"] = (
            "Verificacoes locais calculadas atendem sob o modelo proposto; condicao local de5.7.8, projeto externo e montagem devem ser atendidos. Par construtivo sem credito resistente."
            if out["local_checks_satisfied"] else
            "Verificacoes locais calculadas nao concluidas ou nao atendidas; consultar geometria, resistencias e especificacao do apoio direto."
        )
    except (ArithmeticError, ValueError) as exc:
        out.update(status="INVALID_NUMERIC", local_strength_checks_satisfied=False,
                   local_geometry_checks_satisfied=False, local_checks_satisfied=False,
                   gravity_checks_satisfied=False, checks=[], geometry={}, diagnosis=str(exc))
    return out
