"""DG1 3e Ex4.7-5 receiving-plate gross-section flexure, pure shear only.

This is deliberately not an attachment or connected-base-metal approval.
The native and selected complementary reactions are consumed, never solved
again or increased by another V*e. Canonical units: N, mm, MPa.
"""
import math
from .models import Issue, finite_real
from .single_key_weld import result_signature

MODEL = 'dg1_pure_shear_gross_section'
REF = ('AISC DG1 3ª ed., Ex.4.7-5, pp.89–90; resistência de faixa plástica '
       'retangular com fy/γa1 da NBR 8800:2024 corrigida 2025, 6.7.2.2')
LIMITS = ('Escoamento por flexão calculado na seção bruta ideal da placa receptora no eixo da chave, '
          'sem crédito à rigidez do pilar. Resultado favorável condicionado à seção íntegra. '
          'Posição dos respiros/outros furos, demais seções reduzidas, distribuição transversal, '
          'interação local, ruptura e metal-base de ambas as interfaces dos filetes permanecem pendentes; '
          'não aprova a transferência completa, a fixação da chave ou a base.')
INTERFACE_GAP = ('Tabela 9 remete o metal-base dos filetes à NBR 6.5. Faltam cortes físicos e '
                 'áreas efetivas/líquidas com as ações locais combinadas da mesma junta; '
                 'qRd da garganta e a seção fundida mínima de CJP não são resistências dessas interfaces.')
G1 = 1.10


def eligible(c):
    """No extension by tolerance: every nonzero applied N/M is outside contract."""
    return (c.model_type == 1 and c.shear_path == 'plate' and
            c.N == 0 and c.M == 0 and c.V != 0 and c.stiffener_detail in ('none','web_pair_visual'))


def local_bending_values(*, C, T_row, a, L, lc, bh, tp, fy, gamma=G1):
    """Arithmetic kernel for two one-sided gross-section moments.

    The caller owns equilibrium and model compatibility; this permits checking
    the rounded, published source numbers without silently modifying them.
    """
    vals=(C,T_row,a,L,lc,bh,tp,fy,gamma)
    if not all(finite_real(v) and v > 0 for v in vals):
        raise ValueError('Flexão da placa exige grandezas positivas, reais e finitas.')
    if not (a < L/2 and lc <= L/2):
        raise ValueError('Domínio: linha de tração dentro da placa e contato somente no seu semiplano (lc≤L/2).')
    try:
        mt=T_row*a;mc=C*(L-lc)/2;z=bh*tp**2/4;rd=fy*z/gamma
        sd=max(mt,mc);required=math.sqrt(4*sd*gamma/(fy*bh));ratio=sd/rd
        out=dict(T_row_N=T_row,C_N=C,a_mm=a,L_mm=L,lc_mm=lc,b_eff_mm=bh,
                 tp_mm=tp,fy_MPa=fy,gamma_a1=gamma,Z_mm3=z,M_tension_Nmm=mt,
                 M_contact_Nmm=mc,M_Sd_Nmm=sd,M_Rd_Nmm=rd,t_required_mm=required,
                 utilization=ratio,governing_side='contact' if mc>=mt else 'tension')
        if not all(finite_real(v) for v in out.values() if type(v) in (int,float)):
            raise OverflowError
        if min(rd,z,fy*bh)<=0:raise OverflowError
    except (OverflowError,ZeroDivisionError):
        raise ValueError('Escala numérica excede o domínio finito da flexão da placa.') from None
    return out


def result_is_current(c,result):
    d=getattr(result,'local_single_key_plate',result)
    try:return eligible(c) and bool(d) and d.get('input_signature')==result_signature(c)
    except (ValueError,TypeError,OverflowError,AttributeError):return False


def _native(c,a):
    if not a:return dict(id='native_nbr_full_depth',status='pending',reasons=['Equilíbrio nativo indisponível.'])
    sign=1 if c.effective_moment>=0 else -1
    return dict(id='native_nbr_full_depth',status='calculated',N=c.N,Mtop=c.M,Vtop=c.V,
                Mbase=c.effective_moment,e=c.shear_eccentricity,
                pressure_basis='NBR 0,85fck/1,40; A2/A1=1; estado nativo inalterado',
                contact=dict(C=a['C'],lc=a['lc'],x=a['C_x']),
                rods=[dict(x=x,y=y,tension=a['Ft_max'] if x==-sign*c.a else a['Ft_min'])
                      for x in (-c.a,c.a) for y in (-c.a2/2,c.a2/2)],
                residual_N=a['residual_N'],residual_M=a['residual_M'])


def _state_values(c,state):
    if state.get('status')!='calculated':
        raise ValueError('; '.join(state.get('reasons',[])) or 'Estado de forças não calculado.')
    contact=state['contact'];rods=state['rods'];M=state['Mbase'];C=contact['C'];lc=contact['lc'];xc=contact['x']
    numeric=[M,C,lc,xc,state['N'],state['residual_N'],state['residual_M'],state['e'],state['Vtop']]
    numeric.extend(v for rod in rods for v in (rod['x'],rod['y'],rod['tension']))
    if not all(finite_real(v) for v in numeric):raise ValueError('Estado de forças não finito.')
    if state['N']!=0 or M==0 or len(rods)!=4:
        raise ValueError('A rota exige cortante puro com quatro barras e momento local não nulo.')
    if any(rod['tension']<0 for rod in rods):raise ValueError('Tração negativa em barra do estado recebido.')
    active=[rod for rod in rods if rod['tension']>0]
    sign=1 if M>0 else -1
    if len(active)!=2 or any(not math.isclose(rod['x'],-sign*c.a,rel_tol=1e-12,abs_tol=1e-9) for rod in active):
        raise ValueError('Estado fora de uma linha tracionada oposta ao contato.')
    T=sum(rod['tension'] for rod in active)
    force_tol=1e-8*max(1.,C,T);moment_tol=1e-8*max(1.,abs(M),C*c.L)
    if (abs(C-T)>force_tol or abs(state['residual_N'])>force_tol or
        abs(state['residual_M'])>moment_tol or abs(C*xc-sum(r['tension']*r['x'] for r in rods)-M)>moment_tol):
        raise ValueError('Equilíbrio do estado recebido não demonstrado; não reconstruir reações.')
    if not math.isclose(xc,sign*(c.L-lc)/2,rel_tol=1e-10,abs_tol=1e-8):
        raise ValueError('Centroide de contato incompatível com o bloco uniforme do estado.')
    values=local_bending_values(C=C,T_row=T,a=c.a,L=c.L,lc=lc,bh=c.lug_bh,tp=c.tp,fy=c.fy)
    values.update(Mbase_Nmm=M,e_mm=state['e'],Vtop_N=state['Vtop'],moment_sign=sign,
                  contact_x_mm=xc,tension_row_x_mm=-sign*c.a,
                  residual_N_N=C-T,residual_M_Nmm=sign*(values['M_tension_Nmm']+values['M_contact_Nmm'])-M)
    return values


def evaluate_component(c,native_geometry=None,concrete_result=None):
    if not eligible(c):return {}
    out=dict(model=MODEL,limit_state='gross_section_flexural_yielding',status='pending',flexure_status='pending',transfer_status='pending',
             base_metal_status='pending',integrity_status='pending',complete=False,
             attachment_complete=False,device_complete=False,input_signature=result_signature(c),
             reference=REF,scope=LIMITS,interface_gap=INTERFACE_GAP,states=[],reasons=[],
             section=dict(x_mm=0.,y_min_mm=-c.lug_bh/2,y_max_mm=c.lug_bh/2,
                          width_mm=c.lug_bh,thickness_mm=c.tp,kind='gross_ideal'),
             full_contact_resultant=True,column_stiffness_credit=False)
    from .base_plate import detail_reference
    radius=detail_reference(c)['df']/2
    holes=[dict(x_mm=x,y_mm=y,radius_mm=radius) for x in (-c.a,c.a) for y in (-c.a2/2,c.a2/2)]
    out['known_anchor_holes']=holes
    for hole in holes:
        x,y,r=hole['x_mm'],hole['y_mm'],hole['radius_mm']
        dy=max(abs(y)-c.lug_bh/2,0.)
        if math.hypot(x,dy)<=r:
            out['reasons'].append('Furo conhecido toca/intercepta a seção no eixo da chave: a faixa bruta não é íntegra.')
            out['integrity_status']='outside_domain'
            return out
    try:states=[_native(c,native_geometry)]
    except (KeyError,TypeError,ValueError) as exc:
        states=[dict(id='native_nbr_full_depth',status='pending',reasons=['Estado nativo incompleto: '+str(exc)])]
    if c.single_key_concrete.model!='off':
        from .single_key_concrete import result_is_current as concrete_is_current
        current=bool(concrete_result) and concrete_is_current(c,concrete_result)
        supplemental=next((s for s in (concrete_result or {}).get('states',[])
                           if s.get('id')=='aci_limited_bearing_centroid'),None) if current else None
        states.append(supplemental or dict(id='aci_limited_bearing_centroid',status='pending',
                      reasons=['Componente ACI selecionado sem estado complementar atual calculado.']))
    out['expected_state_count']=len(states)
    for state in states:
        entry=dict(id=state['id'],status='pending',pressure_basis=state.get('pressure_basis',''),reasons=[])
        try:
            entry.update(_state_values(c,state))
            entry['status']='pass' if entry['utilization']<=1+1e-10 else 'fail'
        except (ValueError,KeyError,TypeError,OverflowError,ZeroDivisionError) as exc:
            entry['reasons'].append(str(exc));out['reasons'].append(state['id']+': '+str(exc))
        out['states'].append(entry)
    entries=out['states'];available=[s for s in entries if 'utilization' in s]
    out['flexure_status']='fail' if any(s['status']=='fail' for s in entries) else 'pending' if any(s['status']=='pending' for s in entries) else 'pass'
    # A calculated failure remains visible; favorable gross bending is not a qualified attachment pass.
    out['status']='fail' if out['flexure_status']=='fail' else 'pending'
    if available:
        governing=max(available,key=lambda s:s['utilization'])
        out.update(governing_state_id=governing['id'],utilization=governing['utilization'],
                   t_required_mm=max(s['t_required_mm'] for s in available))
    out['reasons'].append('Geometria de respiros/outros furos não parametrizada: verificar integridade da seção e demais cortes reais. Resultado de flexão bruta favorável é condicional.')
    return out


def add_single_key_plate_checks(c,r,add,native_geometry=None):
    out=evaluate_component(c,native_geometry,r.local_single_key_concrete)
    if not out:return out
    for state in out['states']:
        if 'M_Sd_Nmm' not in state:continue
        add('skp_bending_'+state['id'],'Placa receptora da chave — escoamento por flexão da seção bruta · '+state['id'],
            state['M_Sd_Nmm'],state['M_Rd_Nmm'],'N mm',REF,
            'MSd=max[Tlinha a; C(L−lc)/2] ≤ MRd=(fy/1,10) bh tp²/4',
            f'Tlinha={state["T_row_N"]:.12g}; C={state["C_N"]:.12g}; a={c.a:.12g}; lc={state["lc_mm"]:.12g}; '
            f'Mt={state["M_tension_Nmm"]:.12g}; Mc={state["M_contact_Nmm"]:.12g}; MRd={state["M_Rd_Nmm"]:.12g}',
            'Forças totais do mesmo estado; duas faces do corte, sem somar Mt+Mc como demanda. '
            'bh efetivo; sem reduzir C por bh/B, sem repetir V·e e sem substituir por Vw/Mw. '+LIMITS)
    for reason in out['reasons']:
        r.issues.append(Issue('pending',reason,REF,origin='single_key_plate'))
    r.issues.append(Issue('pending',LIMITS,REF,origin='single_key_plate_scope'))
    return out
