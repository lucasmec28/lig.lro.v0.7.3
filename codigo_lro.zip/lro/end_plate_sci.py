"""SCI P358 §4.7, full-depth end plate, one beam to column WEB, vertical load only.
Native UK Eurocode method. Never uses NBR factors or ASTM material equivalence.
"""
from dataclasses import dataclass,asdict,replace
import math,json
from .models import Profile,Check,Issue,Result,finite_real
SOURCE='SCI/BCSA P358 (2014), §4.7; BS EN 1993 e Anexos Nacionais UK'
SCHEMA='lro-endplate-sci-p358-shear-v1'
GROSS_FACTOR=1.; FRACTURE_FACTOR=1.1; JOINT_FACTOR=1.25
UK_BEAM=Profile('406×178×74 UKB','UKB',74,412.8,179.5,9.5,16.,360.4,9450.,'SCI P358 §4.8 exemplo 1; geometria UK')
# Only support t2 and its material thickness enter the resistance example;
# remaining dimensions define its displayed section, not additional capacity.
UK_COLUMN=Profile('305×305×137 UKC','UKC',137,320.5,309.2,13.8,21.7,246.7,17400.,'Seção UKC; conferir catálogo de fabricação')

@dataclass(frozen=True)
class SCIEndPlate:
 beam:Profile=UK_BEAM
 support:Profile=UK_COLUMN
 project:str='End plate de altura total — SCI/Eurocode'
 beam_grade:str='S275'
 support_grade:str='S275'
 plate_grade:str='S275'
 bolt_grade:str='8.8'
 diameter:float=20.
 plate_t:float=10.
 plate_width:float=150.
 gauge:float=90.
 rows:int=4
 pitch:float=70.
 first_row:float=90.
 weld_leg:float=6.
 support_top_edge:float=100.
 V:float=400000.
 N:float=0.
 M:float=0.
 materials_confirmed:bool=False
 support_kind:str='column_web'
 @property
 def ys(self):return [self.first_row+i*self.pitch for i in range(self.rows)]
 @property
 def hole(self):return self.diameter+2.
 @property
 def radius(self):return (self.beam.d-2*self.beam.tf-self.beam.clear)/2
 @property
 def assumptions(self):return [
  SOURCE+'. γM0=1,00; γM2 de fratura da seção=1,10; γM2 de parafusos/soldas=1,25.',
  'Somente cisalhamento vertical de cálculo, uma viga sem recortes ligada à alma de coluna I contínua; sem força axial ou momento aplicado.',
  'Placa S275 de 10 ou 12 mm; dois parafusos M20 classe 8.8 por linha; furos padrão 22 mm. Filetes contínuos nas duas faces da alma e nas mesas.',
  'O fator 0,80 reduz somente a resistência ao corte dos parafusos no método SCI e contempla a tração provocada pela rotação. Não é aplicado sobre resistência NBR.',
  'Detalhe interno protegido contra corrosão; os limites de espaçamento adotados não abrangem exposição corrosiva.',
  'Ações de amarração acidental (tying), N/V simultâneos, apoio em mesa de coluna e estabilidade global não fazem parte desta opção.',
  'ASTM A36, A572 e A325 não são substituídos por S275, S355 ou 8.8. Perfis Gerdau podem fornecer geometria, mas o material especificado precisa pertencer ao domínio desta opção.'
 ]
 def to_dict(self):return {'schema':SCHEMA,'inputs':asdict(self)}
 @classmethod
 def from_dict(cls,d):
  if not isinstance(d,dict) or set(d)!={'schema','inputs'} or d['schema']!=SCHEMA:raise ValueError('Projeto SCI incompatível; projeto atual preservado.')
  k=dict(d['inputs']);k['beam']=Profile(**k['beam']);k['support']=Profile(**k['support'])
  c=cls(**k)
  issues=validate(c)
  if any(x.severity=='error' for x in issues):raise ValueError('; '.join(x.text for x in issues if x.severity=='error'))
  return c

def steel(grade,t):
 if grade not in ('S275','S355') or not 0<t<=40:raise ValueError('Aço/espessura fora do domínio S275/S355 até 40 mm.')
 return ((275 if t<=16 else 265),410.) if grade=='S275' else ((355 if t<=16 else 345),470.)

def validate(c):
 out=[]
 def err(t):out.append(Issue('error',t,SOURCE,'data'))
 nums=('diameter','plate_t','plate_width','gauge','pitch','first_row','weld_leg','support_top_edge','V','N','M')
 for k in nums:
  v=getattr(c,k)
  if not finite_real(v):err(k+': número finito necessário.')
 if any(type(getattr(c,k)) is not str for k in ('project','beam_grade','support_grade','plate_grade','bolt_grade','support_kind')):err('Identificações e opções devem ser texto.')
 if type(c.rows) is not int or not 2<=c.rows<=10:err('Use 2 a 10 linhas inteiras.')
 if type(c.materials_confirmed) is not bool:err('Confirmação de materiais inválida.')
 for p in (c.beam,c.support):
  if not isinstance(p,Profile):err('Perfil inválido.');continue
  if any(type(getattr(p,k)) is not str for k in ('name','family','source')):err('Identificação de perfil deve ser texto.')
  if any(not finite_real(getattr(p,k)) or getattr(p,k)<=0 for k in ('d','bf','tf','tw','clear','area','mass')):err('Dimensões de perfil inválidas.');continue
  if p.d<=2*p.tf or p.bf<=p.tw or p.clear>p.d-2*p.tf or p.area<=2*p.bf*p.tf:err('Seção I incompatível.');continue
  if p.family not in ('W','UKB','UKC'):err('Somente seções I laminadas W/UKB/UKC neste domínio.')
  radius=(p.d-2*p.tf-p.clear)/2
  area_geom=2*p.bf*p.tf+(p.d-2*p.tf)*p.tw+(4-math.pi)*radius**2
  if abs(p.area-area_geom)>max(10.,.01*area_geom):err('Área do perfil inconsistente com dimensões e concordâncias; conferir catálogo.')
 if out:return out
 if any(getattr(c,k)<=0 for k in nums if k not in ('V','N','M')):err('Dimensões devem ser positivas.')
 if c.N!=0 or c.M!=0:err('Esta opção SCI aceita apenas V; N e M devem ser exatamente zero. Não são apagados ao importar.')
 if c.V<=0:err('Informe V positivo, vertical para baixo, já de cálculo.')
 if c.support_kind!='column_web':err('Esta versão é limitada à alma da coluna; apoio na mesa ainda não habilitado.')
 if c.plate_grade!='S275' or c.plate_t not in (10.,12.):err('Domínio de rotação: chapa S275 de 10 ou 12 mm.')
 if c.bolt_grade!='8.8' or c.diameter!=20.:err('Domínio implementado: parafusos M20 classe 8.8, As245 mm².')
 for grade,p in ((c.beam_grade,c.beam),(c.support_grade,c.support)):
  try:steel(grade,max(p.tf,p.tw))
  except ValueError as ex:err(str(ex))
 if not 90<=c.gauge<=140:err('Gabarito SCI deve estar entre 90 e 140 mm.')
 if out:return out
 # Standard-hole geometric bounds, EN 1993-1-8 Table3.3. Strict implementation
 # restricted to ordinary non-corrosive interior building joints.
 if c.pitch<2.2*c.hole or c.gauge<2.4*c.hole:err('Espaçamento inferior ao mínimo EN para furos padrão.')
 e2=(c.plate_width-c.gauge)/2
 if min(e2,c.ys[0],c.beam.d-c.ys[-1],c.support_top_edge)<1.2*c.hole:err('Distância de borda menor que 1,2d0.')
 if c.pitch>min(14*min(c.plate_t,c.support.tw),200):err('Passo excede o limite adotado EN para ligação interna protegida.')
 if c.plate_width>c.support.clear:err('Chapa não cabe entre as concordâncias da coluna.')
 if c.beam.bf>c.support.clear:err('Mesas da viga não cabem entre as concordâncias da coluna; recortes fora do domínio.')
 if c.gauge/2<=c.beam.tw/2+c.weld_leg+18:err('Parafuso/porca sem espaço lateral para montagem junto à alma.')
 if c.ys[0]<c.beam.tf+c.radius+c.weld_leg+18 or c.ys[-1]>c.beam.d-c.beam.tf-c.radius-c.weld_leg-18:err('Parafuso/porca interfere com mesa, concordância ou filete.')
 if c.weld_leg<3 or c.weld_leg/math.sqrt(2)>min(c.plate_t,c.beam.tw):err('Filete fora da faixa geométrica implementada.')
 fy,_=steel(c.beam_grade,max(c.beam.tf,c.beam.tw))
 if (c.beam.d-2*c.beam.tf)/c.beam.tw>72*math.sqrt(235/fy):err('Alma esbelta: necessário modelo de flambagem por cisalhamento EN 1993-1-5, fora desta opção.')
 if not c.materials_confirmed:out.append(Issue('pending','Confirme materiais EN especificados. ASTM/Gerdau não equivalem automaticamente a S275/S355/8.8.',SOURCE,'method'))
 return out

def evaluate(c):
 r=Result(issues=validate(c))
 if any(i.severity=='error' for i in r.issues):return r
 fy,fu=steel(c.beam_grade,max(c.beam.tf,c.beam.tw));fys,fus=steel(c.support_grade,max(c.support.tf,c.support.tw))
 b=c.beam;as_=245.;fv=.6*800*as_/JOINT_FACTOR
 def add(k,name,s,d,u,eq,sub):r.checks.append(Check('sci_'+k,name,s,d,u,SOURCE,eq,sub,'Método SCI/Eurocode UK; não é verificação NBR.','Entrada'))
 throat=c.weld_leg/math.sqrt(2);need=(.4 if c.beam_grade=='S275' else .48)*b.tw
 add('weld','Soldas contínuas — hierarquia da solda da alma',need,throat,'mm','a ≥ 0,40tw (S275) ou 0,48tw (S355)',f'a requerido={need:.2f}; disponível={throat:.2f}')
 av=max(b.area-2*b.bf*b.tf+(b.tw+2*c.radius)*b.tf,(b.d-2*b.tf)*b.tw)
 vr=av*fy/math.sqrt(3)/GROSS_FACTOR
 add('beam','Viga — cisalhamento da seção',c.V,vr,'N','Vc,Rd=Av fy/(√3γM0)',f'Av={av:.2f}; fy={fy:.2f}; Vc,Rd={vr:.2f}')
 # Conservative end-row branch retained for finite plate edges in addition to
 # the source's pitch expression (continuous support edge is separately real).
 alpha_p=min(c.pitch/(3*c.hole)-.25,min(c.ys[0],b.d-c.ys[-1])/(3*c.hole),800/410.,1.)
 alpha_s=min(c.pitch/(3*c.hole)-.25,c.support_top_edge/(3*c.hole),800/fus,1.)
 kp=min(2.8*((c.plate_width-c.gauge)/2)/c.hole-1.7,2.5)
 bp=kp*alpha_p*410*c.diameter*c.plate_t/JOINT_FACTOR
 bs=2.5*alpha_s*fus*c.diameter*c.support.tw/JOINT_FACTOR
 group=2*c.rows*min(.8*fv,bp,bs)
 add('bolts','Parafusos e furos — envoltória SCI',c.V,group,'N','FRd=n min(0,80Fv,Rd; Fb,Rd,chapa; Fb,Rd,apoio)',f'n={2*c.rows}; Fv={fv:.2f}; Fb,chapa={bp:.2f}; Fb,apoio={bs:.2f}; FRd={group:.2f}')
 et=min(c.support_top_edge,5*c.diameter);eb=min(c.gauge/2,5*c.diameter)
 avs=(et+(c.rows-1)*c.pitch+eb)*c.support.tw;ans=avs-c.rows*c.hole*c.support.tw
 gross=avs*fys/math.sqrt(3)/GROSS_FACTOR;net=ans*fus/math.sqrt(3)/FRACTURE_FACTOR
 add('support','Alma da coluna — cisalhamento local',c.V/2,min(gross,net),'N','V/2 ≤ min(Av fy/(√3γM0); Av,net fu/(√3γM2,seção))',f'Av={avs:.2f}; Av,net={ans:.2f}; Rbruta={gross:.2f}; Rlíquida={net:.2f}')
 r.actual=list(r.checks)
 r.geometry={'method':'SCI P358 §4.7 / Eurocode UK','bolt_rows':c.ys,'Av':av,'bolt_shear_N':fv,'plate_bearing_N':bp,'support_bearing_N':bs,'support_gross_N':gross,'support_net_N':net}
 return r
