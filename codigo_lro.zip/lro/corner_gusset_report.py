"""Compact and detailed current-input Word records for the full corner joint.

A report is a human-readable engineering record, not a JSON dump: component
conclusions first; one coherent load lineage; grouped physical inputs; sources
beside detail witnesses. Canonical reevaluation is mandatory on every call.
"""
from dataclasses import asdict
from io import BytesIO
import math
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches,Pt,RGBColor
from .corner_gusset_presentation import (STATUS,SCOPE_TEXT,CUT_CONVENTION,
    physical_envelopes,compact_envelopes,validated_result,input_fingerprint,number,compact_value,finite,utilization_text,applicability_notes,result_label,detail_note,is_single,is_bolted,scope_text,idealization_text)
from .corner_gusset_drawing import image_bytes,effort_convention_png


def _table(doc,headers,rows,widths=None,size=8):
    table=doc.add_table(rows=1,cols=len(headers));table.style='Light Shading Accent 1'
    table.autofit=False
    if widths:
        for column,width in zip(table.columns,widths):column.width=Inches(width)
    for i,h in enumerate(headers):table.rows[0].cells[i].text=str(h)
    prop=table.rows[0]._tr.get_or_add_trPr();repeat=OxmlElement('w:tblHeader');prop.append(repeat)
    for row in rows:
        cells=table.add_row().cells
        for i,value in enumerate(row):cells[i].text=str(value)
    for row in table.rows:
        pr=row._tr.get_or_add_trPr();cant=OxmlElement('w:cantSplit');pr.append(cant)
        for i,cell in enumerate(row.cells):
            if widths:cell.width=Inches(widths[i])
            for p in cell.paragraphs:
                p.paragraph_format.space_after=Pt(3);p.paragraph_format.space_before=Pt(2)
                for run in p.runs:run.font.size=Pt(size)
    gap=doc.add_paragraph();gap.paragraph_format.space_after=Pt(0);gap.paragraph_format.space_before=Pt(0);gap.paragraph_format.line_spacing=Pt(2)
    return table


def _heading(doc,title,level=1):return doc.add_paragraph(title,style='Heading '+str(level))


def _issue_text(doc,r):
    for item in r.get('issues',[]):
        p=doc.add_paragraph();p.add_run(str(item.get('id','Ocorrência'))+': ').bold=True
        p.add_run(str(item.get('message',item)))


def _scalar_details(row):
    detail=row.get('detail') or row.get('details') or {}
    if not isinstance(detail,dict):return compact_value(detail)
    # Keep physical witness/source facts, omitting recursive duplicated check
    # collections already tabulated. Coordinates and polynomial coefficients
    # remain explicit compact arrays rather than 1-cell-per-number raw dumps.
    return '; '.join(str(k)+'='+compact_value(v) for k,v in detail.items()
                    if k not in ('checks','members','governing','source','component'))


def _action_rows(c,r):
    rows=[]
    for name,prefix in [('D · viga completo','beam_cut'),('U · pilar superior completo','upper_column_cut')]:
        rows.append((name,'('+number(getattr(c,prefix+'_x'))+'; '+number(getattr(c,prefix+'_y'))+')',
                     number(getattr(c,prefix+'_Fx'),1000),number(getattr(c,prefix+'_Fy'),1000),number(getattr(c,prefix+'_M'),1e6)))
    f=r.get('forces') or {}
    lower=f.get('lower_column_cut') or f.get('lower_cut') or f.get('lower')
    if isinstance(lower,dict):
        rows.append(('L · pilar inferior DERIVADO','('+number(c.lower_column_cut_x)+'; '+number(c.lower_column_cut_y)+')',
                     number(lower.get('Fx'),1000),number(lower.get('Fy'),1000),number(lower.get('M'),1e6)))
    return rows


def _compact_forces(doc,c,r):
    _heading(doc,'Um caso concorrente: cortes completos e linha da diagonal')
    doc.add_paragraph(CUT_CONVENTION)
    doc.add_paragraph('Combinação: '+c.case_id+'. Origem: '+c.cuts_source)
    _table(doc,['Ação sobre o corpo livre','Ponto (mm)','Fx (kN)','Fy (kN)','M (kN m)'],_action_rows(c,r),[2.17,1.25,1.1,1.1,1.25])
    doc.add_paragraph('Diagonal: N total='+number(c.P,1000)+' kN; por L='+number(c.P,1000 if is_single(c) else 2000)+' kN; φ='+number(c.phi_deg)+' graus a partir de +x. Afastamento na normal direita='+number(c.workpoint_offset)+' mm.')
    if is_single(c) or is_bolted(c):doc.add_paragraph(idealization_text(c))
    doc.add_paragraph('Outras cargas entre os cortes: '+('ausência explicitamente declarada.' if c.other_loads_excluded else 'não excluídas; registros informados='+str(len(c.other_loads))+'.'))
    if c.other_loads:
        _table(doc,['Carga / membro','Ponto (mm)','Fx (kN)','Fy (kN)','M (kN m)'],[
            (a['label']+' / '+a['member'],compact_value(a['point']),number(a['Fx'],1000),number(a['Fy'],1000),number(a['M'],1e6)) for a in c.other_loads],[2.17,1.25,1.1,1.1,1.25])
    if c.compare_lower_cut:
        doc.add_paragraph('Robot, corte L correspondente: Fx='+number(c.lower_column_check_Fx,1000)+' kN; Fy='+number(c.lower_column_check_Fy,1000)+' kN; M='+number(c.lower_column_check_M,1e6)+' kN m. Comparação diagnóstica; não é outra ação independente.')
    f=r.get('forces') or {}
    root=[]
    for label,normal,shear in [('Raiz viga','Vb','Hb'),('Raiz pilar','Hc','Vc')]:
        root.append((label,number(f.get(normal),1000),number(f.get(shear),1000),'Centroides reais das costuras'))
    if any(finite(f.get(k)) for k in ('Hb','Vb','Hc','Vc')):
        _table(doc,['Interface','Normal assinada (kN)','Tangencial assinada (kN)','Referência'],root,[1.65,1.45,1.5,2.27])
    # Recover one complete joint interface, never reconstructing it from N alone.
    for key in ('joint','beam_joint','interface','joint_interface','beam_to_column','joint_at_J'):
        item=f.get(key)
        if isinstance(item,dict):
            point=item.get('point') or [g for g in ((r.get('geometry') or {}).get('ec'),0.)]
            doc.add_paragraph('Interface direta viga → pilar em J=('+number(point[0])+'; '+number(point[1])+') mm: '
                              'Fx='+number(item.get('Fx'),1000)+' kN; Fy='+number(item.get('Fy'),1000)+' kN; '
                              'M='+number(item.get('M'),1e6)+' kN m. Valores derivados do caso completo.');break
    doc.add_paragraph('Equilíbrio: L é o oposto da soma de D, U, diagonal e outras ações, com os momentos transportados ao corte L. A interface J é recuperada do corpo livre da viga incluindo a ação real da chapa uma única vez. Todo o momento de ligação direta vai ao binário das mesas, sem participação artificial da chapa de nó.')
    residuals=f.get('equilibrium_residuals') or {}
    witnesses=[v for v in residuals.values() if isinstance(v,(list,tuple)) and len(v)==3 and all(finite(x) for x in v)]
    if witnesses:
        doc.add_paragraph(('Fechamento nominal plano dos corpos livres chapa/viga/pilar/conjunto: maior resíduo de força=' if is_single(c) else 'Fechamento dos corpos livres chapa/viga/pilar/conjunto: maior resíduo de força=')+number(max(abs(x) for v in witnesses for x in v[:2]),digits=4)+' N; maior resíduo de momento='+number(max(abs(v[2]) for v in witnesses),digits=4)+' N mm.')


def _geometry_inputs(doc,c,r):
    if (r.get('geometry') or {}).get('outer_end_cut'):
        from .gusset_outer_end import description
        doc.add_paragraph(description(r['geometry'],number))
    from .corner_gusset import MATERIALS
    g=r.get('geometry') or {}
    _heading(doc,'Geometria física, materiais e costuras derivadas')
    rows=[('Viga',c.beam_profile),('Pilar',c.column_profile),(('Uma L na face '+('positiva (+z)' if c.single_angle_face=='positive' else 'negativa (−z)') if is_single(c) else 'Uma L repetida nas duas faces'),c.angle_profile),
          ('Chapa de nó',number(c.plate_width)+' × '+number(c.plate_height)+' × '+number(c.plate_t)+' mm; recorte '+number(c.corner_clip)+' mm'),
          (('Duas soldas da diagonal' if is_single(c) else 'Quatro soldas da diagonal'),'u='+number(c.brace_weld_start)+'…'+number(c.brace_weld_start+c.brace_weld_length)+' mm; perna '+number(c.brace_weld_leg)+' mm'),
          ('Duas raízes','Dois filetes por raiz, perna '+number(c.root_weld_leg)+' mm; início após recorte e margens informadas'),
          ('Ligação direta','CJP nas duas mesas; dois filetes '+number(c.beam_web_weld_leg)+' mm na alma, L='+number(c.beam_web_weld_length)+' mm; acesso R='+number(c.beam_access_radius)+' mm'),
          ('Continuidade','Dois pares horizontais (quatro chapas): largura '+number(c.continuity_width)+', espessura '+number(c.continuity_t)+', recorte '+number(c.continuity_clip)+' mm')]
    if is_bolted(c):
        rows[4]=('Parafusos da diagonal',str(c.bolt_count)+' físicos; '+str(g.get('physical_shear_planes'))+' plano(s) por parafuso; '+c.bolt+'; db='+number(c.bolt_diameter)+' mm; u='+number(c.bolt_start)+'…'+number(c.bolt_start+(c.bolt_count-1)*c.bolt_pitch)+' mm; passo='+number(c.bolt_pitch)+' mm')
        rows.insert(5,('Furos e montagem','Furo físico='+number(g.get('hole_diameter'))+'; dedução líquida='+number(g.get('net_hole_diameter'))+'; gramil='+number(c.bolt_gauge)+'; borda da L='+number(c.bolt_angle_end)+'; pega='+number(g.get('bolt_grip'))+' mm'))
    _table(doc,['Componente','Detalhe informado'],rows,[2.0,4.87])
    if is_bolted(c):doc.add_paragraph('Envelope interno real do talão='+number(c.bolt_heel_extent)+' mm; origem: '+c.bolt_heel_extent_source+'. Ferramenta='+number(c.bolt_tool_radius)+' mm; folga='+number(c.bolt_fabrication_clearance)+' mm. Mecânica e montagem têm qualificações separadas. '+('Deslizamento ELS separado de corte/contato ELU; sem somar resistência por atrito.' if r.get('service_slip') else 'Sem crédito por atrito.'))
    materials=[]
    for label,field in [(('1L' if is_single(c) else '2L'),'angle_steel'),('Chapa de nó','gusset_steel'),('Viga','beam_steel'),('Pilar','column_steel'),('Continuidade','continuity_steel')]:
        name=getattr(c,field);v=MATERIALS[name];materials.append((label,name,number(v['fy']),number(v['fu'])))
    _table(doc,['Metal base','Aço independente','fy (MPa)','fu (MPa)'],materials,[1.7,2.67,1.25,1.25])
    _table(doc,['Consumível / interface','fw (MPa)'],[(label,number(getattr(c,key))) for label,key in [(('Duas soldas 1L–chapa' if is_single(c) else 'Quatro soldas 2L–chapa'),'fw_brace'),('Duas raízes','fw_root'),('Ligação direta viga–pilar','fw_joint'),('Continuidade','fw_continuity')] if not (is_bolted(c) and key=='fw_brace')],[4.87,2.0])
    doc.add_paragraph('E='+number(c.E)+' MPa; γa1='+number(c.gamma_a1)+'; γa2='+number(c.gamma_a2)+'; γw2='+number(c.gamma_w2)+'. Materiais não são vinculados pelo nome de um único aço. Certificados, compatibilidade e procedimento de soldagem precisam ser confirmados no projeto real.')
    derived=[]
    for key,label in [('beam_seam','Costura efetiva na viga (mm)'),('column_seam','Costura efetiva no pilar (mm)'),('alpha','α derivado (mm)'),('beta','β derivado (mm)'),('beam_seam_length','Comprimento raiz viga (mm)'),('column_seam_length','Comprimento raiz pilar (mm)')]:
        if key in g:derived.append((label,compact_value(g[key])))
    cp=g.get('continuity') or {}
    for key,label in [('levels_y','Níveis das duas duplas y (mm)'),('web_x_range','Intervalo soldado na alma (mm)'),('flange_z_range','Intervalo soldado em cada mesa, +z (mm)'),('e','Excentricidade de CADA chapa (mm)'),('d','d = zbar − zweb (mm)'),('delta','δ = zload − zbar (mm)')]:
        if key in cp:derived.append((label,compact_value(cp[key])))
    if derived:_table(doc,['Derivado da geometria atual','Valor'],derived,[3.77,3.1])
    doc.add_paragraph('Raios de laminação das cantoneiras não publicados permanecem desconhecidos. k=tf é limite inferior de resistência do receptor, sem crédito de dispersão de raio de laminação. Comprimentos efetivos de solda não convertem trechos de contato apoiado em bordas livres.')


def _method(doc,c,r):
    _heading(doc,'Método e interpretação dos modos locais')
    points=[
      'Generalização UFM do DG29, apêndice A: Hc=ec V/(eb+β); Hb=H−Hc; Vb=eb Hb/α; Vc=V−Vb. Os centroides são os das costuras reais. Um afastamento do ponto de trabalho exige sua redistribuição própria; não recebe momentos nulos por herança.',
      ('Uma cantoneira recebe N integral, distribuído' if is_single(c) else 'Cada cantoneira recebe N/2, distribuído')+' entre talão e ponta pelo centroide de catálogo. A chapa é única. As seções de corpo inteiro, Whitmore, blocos U/L em bordas realmente livres e envelope conservador de caminhos parciais são mecanismos distintos; suas capacidades não se somam.',
      'Cortes completos D/U/L conservam sinais e momentos transportados. N da ligação direta é repartido pelas áreas retangulares físicas de mesas/alma; todo V vai à alma e todo M ao binário de mesas. A chapa de nó não recebe parcela do momento de pórtico.',
      'A compressão local de uma mesa receptora pode coexistir com diagonal tracionada. Escoamento, enrugamento e os ramos de receptor aplicáveis são ativados pelo sinal real. Faixas de carga que se sobrepõem recebem uma união com dispersão única, sem soma de capacidades ou cancelamento favorável.',
      'Toda força da mesa vai ao par de continuidade correspondente. A transferência de cada chapa até a alma preserva sua própria excentricidade; a resultante transversal do par não substitui o equilíbrio de cada chapa. O receptor de alma é comum, contado uma vez.',
      'Para o trecho retangular contínuo de cada chapa: t=2(x−xcentro)/L; Np=Fp(1+t)/2; Vz=Fp(1,5e/L)(1−t²); My=Fp[δ/2+(d/4+3δ/4)t−(d+δ)t³/4]. d, δ e e são derivados; transições/recortes externos são verificados separadamente. Essa expressão não autoriza recorte atravessando solda ou solda descontínua.',
      'O painel resulta do mesmo corpo livre do pilar, incluindo a ação horizontal do gusset e a distribuição axial real da alma da viga. A redução por compressão concorrente do pilar é mantida; chapas de continuidade não zeram o painel nem criam área de reforço.',
    ]
    if r.get('compression'):
        points[1]='Cada L recebe N/2 por talão/ponta, com vetores assinados. Compressão bruta e esbeltez local AL3 substituem Ct e blocos de ponta tracionada. Corpo real e envelope uniforme de cisalhamento permanecem distintos da estabilidade da faixa centrada; capacidades não se somam.'
    if is_bolted(c):
        points[1]='Uma linha de parafusos físicos: uma L recebe N e um plano de corte; duas L simétricas recebem N/2 cada e compartilham dois planos de corte por parafuso. Todo furo da chapa única recebe N/n. Ct=max(0,5;1−ec/Lc), com área líquida real Ag−dn·t. Contato de cada parede, blocos parciais para pontas livres reais, L/U da chapa perfurada e Whitmore são verificados separadamente; capacidades concorrentes não se somam.'
        points.append('Caminhos L e U tangente usam o polígono real, exclusão de todo contato apoiado e deduções circulares. Centros, tangências, transições de borda/apoio e mínimos interiores dos furos são reavaliados. A tela de corpo N/A−M(v−vbar)/I e 1,5V/A é nominal e suplementar, com refinamento numérico declarado, sem certificado de intervalo ou campo de pressão nos furos. Uma tensão linear negativa não é prova automática de instabilidade; resultante que exige compressão permanece não verificada.')
    if is_bolted(c) and r.get('compression'):
        points[1]='Duas L simétricas: N/2 por L, N/(2n) por plano e N/n por furo da chapa única. Compressão bruta/líquida, AL3 e estabilidade local com r mínimo publicado substituem Ct e ruptura/bloco da ponta tracionada. Contato inverte: chapa −u e L +u, com continuação real após o último furo.'
        points[-1]='Caminhos reversos L ficam inativos por contato apoiado real; a primeira rota admite U tangente até o recorte interno livre, com crédito de tração do cap igual a zero. O cálculo com cap completo é diagnóstico, não capacidade concorrente. Corpo bruto/líquido mantém raízes parciais, ambas as forças limite do furo cortado e apenas tração positiva real na ruptura; compressão não vira demanda de tração por valor absoluto.'
    for text in points:doc.add_paragraph(text,style='List Bullet')
    if r.get('compression'):
        from .corner_gusset_presentation import compression_notes
        _heading(doc,'Compressão local e contenções do detalhe atual',2)
        for text in compression_notes(c,r):
            paragraph=doc.add_paragraph(text)
            if text in ('CONTENÇÕES E DOMÍNIO LOCAL','FAIXA E COLUNA EQUIVALENTE','MECANISMOS E LIMITES'):
                paragraph.paragraph_format.keep_with_next=True
                paragraph.runs[0].bold=True
    if r.get('service_slip') and not r.get('compression'):
        from .corner_gusset_presentation import friction_notes
        for text in friction_notes(c,r):doc.add_paragraph(text)
    _heading(doc,'Modos aplicáveis aos sinais deste caso',2)
    for text in applicability_notes(r):doc.add_paragraph(text,style='List Bullet')
    for key in ('column5_7_5','column5_7_6','builtup_flange_web_weld','continuity_opposite_flange'):
        if key in (r.get('details') or {}):doc.add_paragraph(detail_note(key,r['details'][key]),style='List Bullet')
    _heading(doc,'Fontes e limites')
    for source in [
        'ABNT NBR 8800:2024 / Errata 1:2025: tração e redução de área efetiva (5.2); cisalhamento (5.4.3); receptores, painel e continuidade (5.7.2 a 5.7.9); ligação estática por uma aba (6.1.8.2); soldas e metal conectado (6.2 e 6.5).',
        'AISC Design Guide 29 (2014), apêndice A, pp. impressas 347–350; exemplo 5.1, pp. 52–59; exemplo 6.1a, pp. 303–317. Método generalizado de forças uniformes e distribuição no nó. Não são importados coeficientes AISC de resistência; os coeficientes adotados são os NBR declarados.',
        'Sabelli, Saxey, Li e Thornton (2021). Design for Local Web Shear at Brace Connections: An Adaptation of the Uniform Force Method. Engineering Journal 58(4), 223–266. Trações reais da conexão e cisalhamento local concorrente da alma. Fonte: https://ej.aisc.org/index.php/engj/article/view/1184 .',
        'Perfis W: cada linha preserva a procedência declarada no catálogo didático do aplicativo; a seleção não transforma todas as linhas em dados oficiais Gerdau. No caso C1, W310×52 e W310×97(H) e suas propriedades foram conferidos independentemente nas tabelas Gerdau. Cantoneiras: tabela Gerdau de barras e perfis, com identidade e fonte de cada linha preservadas. Catálogo não substitui certificado de aço.'
    ]:
        if (is_bolted(c) or r.get('compression')) and source.startswith('AISC Design Guide 29'):source=source.replace('exemplo 5.1, pp. 52–59','exemplo 5.1, pp. impressas 43–52 (PDF51–60)')
        if (is_bolted(c) or r.get('compression')) and source.startswith('ABNT NBR'):source=source.replace('soldas e metal conectado (6.2 e 6.5).','mínimo da ligação (6.1.5.2), soldas (6.2), parafusos e furos (6.3) e metal conectado/blocos (6.5).')
        doc.add_paragraph(source,style='List Bullet')
    for key in ('beam','column','angle'):
        sec=(r.get('geometry') or {}).get(key) or {}
        if sec.get('source'):doc.add_paragraph('Catálogo '+key+': '+str(sec['source']))
    for text in r.get('exclusions') or []:doc.add_paragraph(str(text),style='List Bullet')
    doc.add_paragraph('Não abrange estabilidade global do pórtico/diagonal, fadiga, sismo, ações espaciais, fabricação, tolerâncias, execução/WPS ou inspeção. Uma geometria fora do método é não verificada; não é automaticamente uma falha de resistência nem uma aprovação por ausência de dados.')


def _details(doc,c,r):
    if r.get('compression'):
        _heading(doc,'Auditoria detalhada por componente').paragraph_format.page_break_before=True
    else:
        doc.add_page_break();_heading(doc,'Auditoria detalhada por componente')
    doc.add_paragraph('As linhas abaixo são verificações primitivas do mesmo caso, com fontes e testemunhos físicos. São rastreabilidade do resumo, não componentes com capacidades aditivas. Valores nativos de força em N, momento em N mm, tensões em MPa e comprimento em mm, salvo unidade indicada no registro.')
    for group in physical_envelopes(r):
        _heading(doc,group['component_label'],2)
        _table(doc,['ID / mecanismo','Solicitação','Resistência','η','Estado'],[
            (str(row.get('id')),number(row.get('demand'),digits=8),number(row.get('resistance'),digits=8),utilization_text(row),row.get('status')) for row in group['members']],[2.67,1.2,1.2,.8,1.0],7.5)
        for row in group['members']:
            p=doc.add_paragraph();p.add_run(str(row.get('id'))+': ').bold=True
            p.add_run(str(row.get('source','Fonte não indicada')))
            detail=_scalar_details(row)
            if detail:p.add_run('. '+detail)
            for run in p.runs:run.font.size=Pt(8)
    _heading(doc,'Linhagem adicional do caso e fechamento de equilíbrio')
    forces=r.get('forces') or {}
    for key,value in forces.items():
        p=doc.add_paragraph();p.add_run(str(key)+': ').bold=True;p.add_run(compact_value(value))
        for run in p.runs:run.font.size=Pt(8)
    _heading(doc,'Registro integral dos parâmetros físicos e declarações')
    # Group native arrays on one row; do not expand each coordinate to a raw
    # dump. This section verifies import/export provenance without 86 inputs.
    _table(doc,['Parâmetro nativo','Valor'],[(k,compact_value(v)) for k,v in c.to_dict()['connection'].items()],[3.15,3.72],7.5)


def create_report(c,result=None,detailed=False):
    from .corner_gusset import FAMILY,COMPONENT_VERSION
    r=validated_result(c)
    doc=Document();sec=doc.sections[0]
    sec.page_width=Inches(8.27);sec.page_height=Inches(11.69)
    sec.left_margin=sec.right_margin=Inches(.7);sec.top_margin=sec.bottom_margin=Inches(.6)
    normal=doc.styles['Normal'];normal.font.name='Calibri';normal.font.size=Pt(9)
    normal.paragraph_format.space_after=Pt(5)
    for name,size in [('Title',21),('Subtitle',11),('Heading 1',13),('Heading 2',10.5)]:
        style=doc.styles[name];style.font.name='Calibri';style.font.size=Pt(size);style.font.color.rgb=RGBColor.from_string('000000' if is_bolted(c) else '23384D')
        style.paragraph_format.keep_with_next=True;style.paragraph_format.space_before=Pt(9);style.paragraph_format.space_after=Pt(5)
        for border in list(style.element.iter(qn('w:pBdr'))):border.getparent().remove(border)
    for border in list(doc.element.iter(qn('w:pBdr'))):border.getparent().remove(border)
    doc.add_paragraph('Canto viga pilar com '+('1L' if is_single(c) else '2L T')+' '+('parafusada' if is_bolted(c) else 'soldada'),style='Title')
    doc.add_paragraph('Memória local '+('detalhada' if detailed else 'resumida')+' · '+COMPONENT_VERSION,style='Subtitle')
    doc.add_paragraph('Projeto: '+c.project)
    p=doc.add_paragraph();p.add_run(result_label(r)).bold=True
    doc.add_paragraph('Estado canônico: '+str(r.get('status'))+'; η governante='+utilization_text(r)+'.')
    doc.add_paragraph(scope_text(c))
    _issue_text(doc,r)
    _heading(doc,'Resultado governante de cada componente')
    envelopes=compact_envelopes(r)
    _table(doc,['Componente físico','Governante','η','Estado'],[
        (e['component_label'],'; '.join(e['governing_labels']) or ('Triagem informativa; não governa a ligação' if e.get('diagnostic_only') else 'Não aplicável'),utilization_text(e),'DIAGNÓSTICO' if e['status']=='DIAGNOSTIC_ONLY' else e['status']) for e in envelopes],[1.65,3.45,.77,1.0],8)
    doc.add_paragraph('Componentes em série: capacidades não são somadas. Uma conclusão incompleta em qualquer caminho impede aprovação local completa. A tração da diagonal não remove os modos de compressão do receptor.')
    p=doc.add_paragraph('Entradas SHA-256: '+input_fingerprint(c));p.runs[0].font.size=Pt(7)
    doc.add_page_break();_heading(doc,'Desenho físico da entrada atual')
    doc.add_picture(BytesIO(image_bytes(c,fmt='png')),width=Inches(6.87))
    doc.add_paragraph(('O corte mostra '+str(c.bolt_count)+' parafusos na vista da chapa e '+str((r.get('geometry') or {}).get('physical_shear_planes'))+' plano(s) de corte por parafuso na seção; as duas raízes continuam soldadas. A planta' if is_bolted(c) else 'O corte 1L mostra uma cantoneira em uma face e dois filetes; as duas raízes mantêm dois filetes cada. A planta' if is_single(c) else 'A vista T torna explícitas as duas cantoneiras, a chapa central e as quatro soldas. A planta')+' da continuidade mostra duas chapas por nível, quatro no total, com recortes de raiz, soldas nas duas mesas e na alma. Contornos nominais não inventam raios de laminação.')
    _heading(doc,'Convenção de sinais separada do caso real',2)
    doc.add_picture(BytesIO(effort_convention_png(c)),width=Inches(6.5))
    doc.add_page_break();_compact_forces(doc,c,r);_geometry_inputs(doc,c,r);_method(doc,c,r)
    for case in r.get('design_cases',[]):
        _heading(doc,'Caso sintético de resistência mínima45kN')
        doc.add_paragraph(case['origin']+'. '+case['background']+'. A comparação Robot é exclusiva do caso real. O resumo considera a maior utilização entre os dois casos, sem somar capacidades.')
        if case.get('zero_force_convention'):doc.add_paragraph(case['zero_force_convention'])
        if case['result'].get('service_slip'):
            slip=case['result']['service_slip'];doc.add_paragraph('Deslizamento mínimo: salvaguarda sintética de dimensionamento, não combinação rara real; demanda por parafuso='+number(slip.get('per_bolt_demand'),1000)+' kN; resistência='+number(slip.get('per_bolt_resistance'),1000)+' kN. D/U reais não são escalados para serviço.')
        _table(doc,['Ação','Caso real','Caso sintético'],[('N da diagonal (kN)',number(c.P,1000),number(case['design_P'],1000))],[2.87,2.,2.])
        for label,key in [('J viga para pilar','joint'),('L sintético derivado','lower_column_cut')]:
            f=case['result']['forces'][key];doc.add_paragraph(label+': Fx='+number(f['Fx'],1000)+' kN; Fy='+number(f['Fy'],1000)+' kN; M='+number(f['M'],1e6)+' kN m.')
    if detailed:_details(doc,c,r)
    _heading(doc,'Conclusão')
    if r.get('status')=='PASS' and r.get('complete') is True:doc.add_paragraph('As verificações locais implementadas atendem no domínio da entrada atual. A conclusão depende das geometrias, ações completas, materiais e declarações desta memória.')
    else:doc.add_paragraph('A entrada atual não tem conclusão local favorável completa. Resolver os dados, falhas ou métodos não qualificados registrados antes de utilizá-la como verificação.')
    doc.add_paragraph('O resultado não constitui certificado de fabricação ou aprovação da estabilidade global da estrutura.')
    doc.core_properties.title=FAMILY;doc.core_properties.subject='Memória local de canto '+COMPONENT_VERSION
    doc.core_properties.author='LRO Ligações';doc.core_properties.keywords=('1L' if is_single(c) else '2L-T')+'; gusset; COMPLETE_CUTS; NBR 8800'
    out=BytesIO();doc.save(out);return out.getvalue()
