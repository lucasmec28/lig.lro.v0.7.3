"""Conventional grouted direct anchor bearing: bounded steel/plate kernel.

Units are N, mm and MPa. This is an explicitly identified supplementary
EN 1993-1-8:2005 (corrected) component check, not whole-base/EN conformity.
No washer lateral capacity, friction, pretension, artificial rotational
restraint, contact stiffness or individual rod moment is credited.
"""
from dataclasses import dataclass, fields
import math
import re

from .models import finite_real

MODEL = 'conventional_grouted_ec3'
REF = 'EN 1993-1-8:2005 corrigida, 3.3, 3.6.1/Table 3.4, 3.7, 3.8, 3.12 e 6.2.2'
GAMMA_M2 = 1.25
ALPHA_V = 0.5  # Declared conservative envelope, not a fictional bolt class.
MATERIAL_BASES = ('EN_structural', 'EN_bolt', 'EN_rebar', 'ASTM_supplementary')
SERVICE_MODES = ('ordinary_bearing', 'no_slip', 'numeric_total_limit')
THREAD_COMPLIANCES = ('en1090_verified', 'unverified_cut')
UNC_THREADS = {19.05:10.,22.225:9.,25.4:8.,28.575:7.,31.75:7.}
NORMAL_HOLES = {d: d + (2. if d <= 24 else 3.) for d in (16.,18.,20.,22.,24.,27.,30.,33.,36.)}
GROUT_NOTE = ('Flexão/efeito local do graute considerados implicitamente na resistência reduzida adotada; '
              'momento individual não calculado. A fase anterior à cura não é aprovada.')
FOUNDATION_NOTE = ('Este kernel não calcula ancoragem ACI, fundação, armadura ou fendilhamento. '
                   'O adaptador deve verificar todos os modos aplicáveis em cada estado, com o material real.')
PLATE_NOTE = ('Bearing local não verifica seção líquida, bloco, transferência às soldas, flexão fora do plano '
              'ou rigidez/resistência da placa inteira. Exige verificações próprias identificadas.')


@dataclass
class DirectAnchorShear:
    model: str = 'off'
    material_name: str = ''
    material_basis: str = 'unspecified'
    material_specification: str = ''
    material_reference: str = ''
    material_quality_reference: str = ''
    material_protocol: str = ''
    ductility_reference: str = ''
    certification_reference: str = ''
    supplementary_application_accepted: bool = False
    fy: float = 0.
    fu: float = 0.
    thread_area: float = 0.
    thread_standard: str = 'metric'
    thread_tpi: float = 0.
    thread_area_source: str = 'documented'
    thread_manufacture: str = 'unspecified'
    thread_compliance: str = 'unspecified'
    thread_reference: str = ''
    hole_diameter: float = 0.
    hole_kind: str = 'unspecified'
    hole_basis: str = 'en_normal_nominal'
    normal_hole_tolerance_verified: bool = False
    execution_reference: str = ''
    grout_complete: bool = False
    grout_cured: bool = False
    no_free_standoff: bool = False
    grout_reference: str = ''
    service_slip_requirement: str = 'ordinary_bearing'
    service_total_limit: float = 0.
    plate_transfer_complete: bool = False
    plate_transfer_reference: str = ''
    static_loading: bool = False
    torsion_z: float = 0.

    @classmethod
    def from_dict(cls, data):
        if not isinstance(data, dict):
            raise ValueError('Dados de contato direto devem ser um objeto.')
        keys = {f.name for f in fields(cls)}
        if any(k not in keys for k in data):
            raise ValueError('Campos desconhecidos no contato direto: ' + ', '.join(str(k) for k in data if k not in keys))
        return cls(**data)


def unc_thread_area(db, tpi):
    """DG1 eq.4-21/ASME B1.1 design area; not a product certificate."""
    if not finite_real(db) or not finite_real(tpi) or db not in UNC_THREADS or tpi != UNC_THREADS[db]:
        raise ValueError('Par diâmetro/passo UNC fora do domínio 3/4–10 a 1 1/4–7.')
    return math.pi/4*(db/25.4-.9743/tpi)**2*25.4**2


def _scope(status, *, eligible=None, passes=None, reasons=(), **extra):
    out = dict(status=status, reasons=list(reasons), **extra)
    if eligible is not None:
        out['eligible'] = eligible
    out['passes'] = passes
    return out


def _empty_result():
    return dict(model=MODEL, reference=REF, units='N, mm, MPa', valid=False,
                valid_scope='steel_plate_component_and_prescriptive_service_only',
                direct_route_resistance_pass=False, complete=False,
                domain=_scope('invalid', eligible=False),
                steel_plate_uls=_scope('pending'), service_scope=_scope('pending', eligible=False),
                plate_transfer_scope=_scope('pending', reasons=[PLATE_NOTE]),
                aci_components=_scope('not_calculated', reasons=[FOUNDATION_NOTE], complete=False),
                foundation_scope=_scope('outside_kernel', reasons=[FOUNDATION_NOTE], complete=False),
                states=[], checks=[], pending_reasons=[], reasons=[], assumptions=[
                    'Estados alternativos convencionais, nunca simultâneos ou somados; não são solver de contato.',
                    'Todo V transmitido pelas hastes. Atrito e contribuição lateral de arruela iguais a zero.',
                    'αv=0,5 é envelope conservador complementar; γM2=1,25 não é fator NBR/ACI.',
                    GROUT_NOTE, PLATE_NOTE])


def _check(key, label, demand, resistance, *, unit='N', ids=(), reference=REF):
    # Validated scales keep this operation finite; zero capacity at zero demand
    # is harmless only because independent tension checks are always retained.
    ratio = demand / resistance if resistance > 0 else (0. if demand == 0 else None)
    passes = ratio is not None and ratio <= 1. + 1e-10
    return dict(id=key, label=label, demand=demand, resistance=resistance, ratio=ratio,
                status='pass' if passes else 'fail', passes=passes, unit=unit,
                ids=list(ids), reference=reference)


def _near(a, b):
    return math.isclose(a, b, rel_tol=1e-10, abs_tol=1e-9)


def _text_present(value):
    return bool(value.strip())


def _material_identity(u):
    """A declared EN identity and documentary references, never a boolean alias.

    This checks the declared specification/grade's family. It does not claim to
    authenticate a certificate; reference/quality evidence remains auditable.
    ASTM identity is deliberately never reclassified as an EN grade.
    """
    spec = re.sub(r'\s+', ' ', u.material_specification.strip().upper())
    name = u.material_name.strip().upper()
    if u.material_basis == 'ASTM_supplementary':
        good_name = bool(re.fullmatch(r'ASTM A36(?:/A36M)?', name))
        good_spec = bool(re.fullmatch(r'ASTM A36/A36M(?:-|:)\d{2,4}(?:[A-Z])?', spec))
        good_protocol = (u.material_protocol == 'astm_a36_supplementary_v1' and
                         u.supplementary_application_accepted and
                         _text_present(u.ductility_reference) and _text_present(u.certification_reference) and
                         u.thread_manufacture == 'cut' and u.fy/u.fu <= .80)
        if good_name and good_spec and good_protocol:
            return True, ''
        return False, ('Aço ASTM: estudo não qualificado. Exigir protocolo astm_a36_supplementary_v1 aceito, '
                       'ASTM A36/A36M com edição, certificado do produto final, ductilidade, rosca cortada e fy/fu≤0,80. '
                       'Nunca é equivalência material EN 3.3.')
    if re.search(r'\bASTM\b|\bA\s*36\b|\bA\s*572\b|\bF\s*1554\b', name + ' ' + spec):
        return False, 'Identidade ASTM não pode ser convertida em material EN por seleção de categoria.'
    if u.material_basis == 'EN_structural':
        good_spec = bool(re.fullmatch(r'EN 10025-[1-6](?::\d{4})?', spec))
        good_grade = bool(re.fullmatch(r'S(?:235|275|355|420|450|460)(?:[A-Z0-9 +\-]*)', name))
    elif u.material_basis == 'EN_bolt':
        good_spec = bool(re.fullmatch(r'EN ISO 898-1(?::\d{4})?|EN 14399-[134](?::\d{4})?', spec))
        match = re.fullmatch(r'(?:(?:CLASSE|CLASS|PROPERTY CLASS) )?(4\.6|4\.8|5\.6|5\.8|6\.8|8\.8)', name)
        good_grade = bool(match)
        if match:
            grade = match.group(1)
            strengths = {'4.6':(240.,400.),'4.8':(320.,400.),'5.6':(300.,500.),
                         '5.8':(400.,500.),'6.8':(480.,600.),'8.8':(640.,800.)}
            fy_nom,fu_nom = strengths[grade]
            if not (_near(u.fy,fy_nom) and _near(u.fu,fu_nom)):
                return False, 'Ramo EN_bolt limitado aos valores nominais da classe declarada; não elevar resistência por propriedades incompatíveis com o grau.'
            if spec.startswith('EN 14399-') and grade!='8.8':
                return False, 'Especificação EN14399 incompatível com a classe informada neste domínio inicial.'
    elif u.material_basis == 'EN_rebar':
        good_spec = bool(re.fullmatch(r'EN 10080(?::\d{4})?', spec))
        good_grade = bool(re.fullmatch(r'B\d{3}[A-Z0-9 +\-]*', name))
    else:
        return False, 'Identificar a base do material: EN_structural, EN_bolt, EN_rebar ou ASTM_supplementary.'
    if not good_spec or not good_grade:
        return False, 'Identificar grau e especificação de material admissíveis em EN 3.3; sem equivalência automática.'
    return True, ''


def _validate_types(u, inputs, rods):
    errors = []
    if not isinstance(u, DirectAnchorShear):
        return ['Configuração de contato direto inválida: esperado DirectAnchorShear.']
    texts = ('model','material_name','material_basis','material_specification','material_reference',
             'material_quality_reference','material_protocol','ductility_reference','certification_reference',
             'thread_standard','thread_area_source','thread_manufacture','thread_compliance','thread_reference',
             'hole_kind','hole_basis','execution_reference','grout_reference','service_slip_requirement','plate_transfer_reference')
    for key in texts:
        if not isinstance(getattr(u, key), str):
            errors.append('Campo textual inválido: ' + key + '.')
    for key in ('normal_hole_tolerance_verified','grout_complete','grout_cured','no_free_standoff',
                'plate_transfer_complete','static_loading','supplementary_application_accepted'):
        if type(getattr(u, key)) is not bool:
            errors.append('Confirmação inválida: ' + key + '.')
    vals = dict(inputs)
    vals.update({k: getattr(u, k) for k in ('fy','fu','thread_area','thread_tpi','hole_diameter','service_total_limit','torsion_z')})
    for key, value in vals.items():
        if not finite_real(value):
            errors.append('Grandeza deve ser real e finita, não booleana: ' + key + '.')
    if not isinstance(rods, (list, tuple)) or len(rods) not in (2,4):
        errors.append('Fornecer duas ou quatro hastes reais em lista.')
    else:
        seen = set()
        for index, rod in enumerate(rods):
            if not isinstance(rod, dict):
                errors.append('Haste inválida no índice ' + str(index) + '.')
                continue
            rid = rod.get('id')
            if not isinstance(rid, str) or not rid.strip() or rid in seen:
                errors.append('Identificador de haste vazio, inválido ou duplicado.')
            else:
                seen.add(rid)
            for key in ('x','y','tension'):
                if not finite_real(rod.get(key)):
                    errors.append('Grandeza inválida na haste ' + str(index) + ': ' + key + '.')
    return errors


def _safe_failure(out, reasons, status='invalid'):
    out['domain'] = _scope(status, eligible=False, reasons=reasons)
    out['reasons'] = list(reasons)
    out['pending_reasons'] = list(reasons)
    return out


def evaluate_direct_anchor_shear(config, *, rods, L, B, tp, plate_fu, db, V, grout_t, grout_fck, fck):
    """Return a fail-closed, JSON-safe result without modifying any input.

    rods is [{id: str, x: mm, y: mm, tension: N}, ...]. Tensions are
    concomitant with signed V and never reversed or reconstructed here.
    A favourable result covers only this component; the caller must also
    complete the ACI/family/transfer checks. Extra rod keys are not used.
    """
    out = _empty_result()
    inputs = dict(L=L, B=B, tp=tp, plate_fu=plate_fu, db=db, V=V,
                  grout_t=grout_t, grout_fck=grout_fck, fck=fck)
    errors = _validate_types(config, inputs, rods)
    if errors:
        return _safe_failure(out, errors)
    u = config
    # Bounds are implementation/numerical limits, not claimed general EN limits.
    for key in ('L','B','tp','db'):
        if not 1e-6 <= inputs[key] <= 1e6:
            errors.append('Dimensão fora do domínio numérico positivo (até 10⁶ mm): ' + key + '.')
    for key in ('plate_fu','grout_fck','fck'):
        if not 1e-6 <= inputs[key] <= 1e5:
            errors.append('Resistência de material fora do domínio numérico positivo: ' + key + '.')
    if not 0 < u.fy <= 1e5 or not 0 < u.fu <= 1e5:
        errors.append('fy e fu reais positivos são obrigatórios.')
    if not 1e-6 <= u.thread_area <= 1e6 or not 0 < u.hole_diameter <= 1e6:
        errors.append('As real≥10⁻⁶ mm² e diâmetro real do furo positivo devem ter escala numérica válida.')
    if abs(V) > 1e15 or abs(u.torsion_z) > 1e18 or not 0 <= u.service_total_limit <= 1e6 or not 0 <= u.thread_tpi <= 1000:
        errors.append('Ação ou limite de serviço fora do domínio numérico.')
    if not 0 < grout_t <= 1e6:
        errors.append('Espessura real positiva do graute é obrigatória.')
    for rod in rods:
        if max(abs(rod['x']),abs(rod['y'])) > 1e6 or not 0 <= rod['tension'] <= 1e15:
            errors.append('Posição/tração de haste fora do domínio numérico; não admitir tração negativa.')
    if errors:
        return _safe_failure(out, errors)

    # Layout is checked before arithmetic and never silently recentred.
    rows = []
    for rod in sorted(rods, key=lambda a: (a['x'],a['y'],a['id'])):
        found = next((row for row in rows if _near(row[0]['x'],rod['x'])), None)
        if found is None:
            rows.append([rod])
        else:
            found.append(rod)
    layout_errors = []
    expected_rows = len(rods)//2
    if len(rows) != expected_rows or any(len(row) != 2 for row in rows):
        layout_errors.append('Domínio limitado a 2×2 ou linha transversal 1×2 com pares simétricos.')
    else:
        for row in rows:
            if row[0]['y'] >= 0 or row[1]['y'] <= 0 or not _near(row[0]['y'],-row[1]['y']):
                layout_errors.append('Par transversal deve ser simétrico em y e ter espaçamento positivo.')
            if not _near(row[0]['tension'], row[1]['tension']):
                layout_errors.append('Tração concomitante deve ser simétrica dentro de cada par y.')
        if expected_rows == 1 and not _near(rows[0][0]['x'],0.):
            layout_errors.append('Linha 1×2 deve estar em x=0; não recentrar automaticamente.')
        if expected_rows == 2:
            if not _near(rows[0][0]['x'],-rows[1][0]['x']) or rows[0][0]['x'] >= 0:
                layout_errors.append('Grupo 2×2 deve estar centrado em x com linhas distintas.')
            if not _near(rows[0][0]['y'],rows[1][0]['y']):
                layout_errors.append('Grupo 2×2 exige o mesmo par transversal em ambas as linhas.')
    if layout_errors:
        return _safe_failure(out, layout_errors, 'outside_domain')

    d0 = u.hole_diameter
    geometric_errors = []
    for rod in rods:
        if abs(rod['x']) + d0/2 >= L/2 or abs(rod['y']) + d0/2 >= B/2:
            geometric_errors.append('Furo deve estar inteiro e estritamente contido na placa: ' + rod['id'] + '.')
    for i,a in enumerate(rods):
        for b in rods[i+1:]:
            if math.hypot(a['x']-b['x'],a['y']-b['y']) <= d0:
                geometric_errors.append('Furos coincidentes, sobrepostos ou tangentes não são admitidos.')
    if d0 <= db or u.thread_area > math.pi*db*db/4:
        geometric_errors.append('Exigir d0>db e 0<As≤πdb²/4; As não é inferida do diâmetro.')
    if geometric_errors:
        return _safe_failure(out, geometric_errors, 'outside_domain')

    reasons = []
    if u.model != MODEL:
        reasons.append('Selecionar o método conventional_grouted_ec3; nenhuma outra rota é ativada automaticamente.')
    if not u.static_loading:
        reasons.append('Exige carregamento estático sem impacto, fadiga ou vibração significativa.')
    if u.torsion_z != 0:
        reasons.append('Qualquer torção externa não nula está fora do domínio unidirecional.')
    if not (235 <= u.fy <= 640 and 400 <= u.fu <= 800 and u.fy <= u.fu):
        reasons.append('Domínio conservador: 235≤fy≤640, 400≤fu≤800 MPa e fy≤fu.')
    material_eligible, material_reason = _material_identity(u)
    if not material_eligible:
        reasons.append(material_reason)
    for key, text in (
        ('material_name','Identificar o material real da haste.'),
        ('material_specification','Identificar a especificação real do material.'),
        ('material_reference','Referenciar a comprovação de identidade e propriedades reais do material.'),
        ('material_quality_reference','Referenciar alongamento/qualidade de fabricação do material.'),
        ('thread_reference','Referenciar a rosca real, área resistente e fabricação.')):
        if not _text_present(getattr(u,key)):
            reasons.append(text)
    thread_valid = u.thread_manufacture in ('cut','rolled') and u.thread_compliance in THREAD_COMPLIANCES
    if u.thread_compliance == 'unverified_cut' and u.thread_manufacture != 'cut':
        thread_valid = False
    if not thread_valid:
        reasons.append('Rosca: cut/rolled com en1090_verified, ou cut com unverified_cut e redução 0,85.')
    nominal_d0 = NORMAL_HOLES.get(db) if u.thread_standard == 'metric' else None
    allowed_d0 = None
    unc_area = None
    if u.thread_area_source not in ('documented','calculated_asme'):
        reasons.append('Identificar origem de As: documented ou calculated_asme (somente UNC).')
    if u.thread_standard == 'metric':
        allowed_d0 = nominal_d0
        if u.hole_basis != 'en_normal_nominal' or nominal_d0 is None or u.thread_area_source != 'documented':
            reasons.append('Ramo métrico: M16/M18/M20/M22/M24/M27/M30/M33/M36, As documentada e furo en_normal_nominal.')
    elif u.thread_standard == 'UNC_2A':
        if db not in UNC_THREADS or u.thread_tpi != UNC_THREADS.get(db):
            reasons.append('UNC Class 2A: pares 19,05/10; 22,225/9; 25,4/8; 28,575/7; 31,75/7 mm/fios por polegada.')
        else:
            unc_area = unc_thread_area(db,u.thread_tpi)
            allowed_d0 = db + (2. if db <= 24 else 3.)
            if u.thread_area > unc_area*(1.+1e-9):
                reasons.append('As excede a área de projeto do perfil UNC declarado (DG1/ASME).')
            if u.thread_area_source == 'calculated_asme' and not math.isclose(u.thread_area,unc_area,rel_tol=1e-9,abs_tol=1e-8):
                reasons.append('As marcada calculated_asme deve corresponder ao diâmetro e passo reais informados.')
        if u.hole_basis != 'supplementary_unc_bounded':
            reasons.append('UNC exige base supplementary_unc_bounded; teto dimensional não certifica classificação EN1090.')
        if u.thread_compliance != 'unverified_cut' or u.thread_manufacture != 'cut':
            reasons.append('Primeiro ramo UNC exige rosca cortada, kthread=0,85; não inferir conformidade EN1090.')
    else:
        reasons.append('Identificar perfil métrico ou UNC_2A, sem conversão automática de diâmetro.')
    if allowed_d0 is not None and d0 > allowed_d0 + 1e-10:
        reasons.append('Furo real excede o teto dimensional d+2/d+3 mm da base adotada; não reduzir automaticamente.')
    if u.hole_kind != 'normal_round':
        reasons.append('Somente furo circular normal; rasgo, alargado, escareado, bucha/resina excluídos.')
    if not u.normal_hole_tolerance_verified or not _text_present(u.execution_reference):
        reasons.append('Documentar locação/furação realizáveis e tolerâncias/inspeção que preservem o furo normal.')
    if grout_t > 40 or grout_fck < max(fck,30.):
        reasons.append('Graute: 0<tg≤40 mm e resistência especificada≥max(fck,30 MPa), limites deste ramo.')
    if not all((u.grout_complete,u.grout_cured,u.no_free_standoff)) or not _text_present(u.grout_reference):
        reasons.append('Documentar graute integral curado, sem vazios/bolsões livres, bainha livre ou afastamento livre.')

    e1_min = min(L/2-abs(a['x']) for a in rods)
    e2_min = min(B/2-abs(a['y']) for a in rods)
    p1 = rows[-1][0]['x']-rows[0][0]['x'] if len(rows)==2 else None
    p2 = rows[0][1]['y']-rows[0][0]['y']
    detail_checks = [
        _check('direct_edge_x','Borda longitudinal mínima',1.2*d0,e1_min,unit='mm'),
        _check('direct_edge_y','Borda transversal mínima',1.2*d0,e2_min,unit='mm'),
        _check('direct_pitch_y','Passo transversal mínimo',2.4*d0,p2,unit='mm')]
    if p1 is not None:
        detail_checks.append(_check('direct_pitch_x','Passo longitudinal mínimo',2.2*d0,p1,unit='mm'))
    if any(not c['passes'] for c in detail_checks):
        reasons.append('Distâncias mínimas EN: e1,e2≥1,2d0; p1≥2,2d0 e p2≥2,4d0 não atendidas.')
    out['checks'] = detail_checks
    out['geometry'] = dict(layout='grid_2x2' if len(rods)==4 else 'line_1x2',
                           nominal_normal_hole_mm=nominal_d0, actual_hole_mm=d0,allowed_hole_max_mm=allowed_d0,
                           hole_basis=u.hole_basis,thread_standard=u.thread_standard,
                           e1_min_mm=e1_min,e2_min_mm=e2_min,p1_mm=p1,p2_mm=p2,
                           all_holes_in_geometry=True)
    out['domain'] = _scope(('supplemental_qualified' if u.material_basis=='ASTM_supplementary' else 'eligible') if not reasons else 'outside_domain', eligible=not reasons, reasons=reasons)
    out['material'] = dict(name=u.material_name,basis=u.material_basis,specification=u.material_specification,
                           reference=u.material_reference,quality_reference=u.material_quality_reference,
                           en_3_3_identity_eligible=material_eligible and u.material_basis!='ASTM_supplementary',
                           qualification_status=('astm_a36_supplemental' if u.material_basis=='ASTM_supplementary' else 'en_eligible') if not reasons else 'study_unqualified',
                           protocol=u.material_protocol,ductility_reference=u.ductility_reference,
                           certification_reference=u.certification_reference,
                           supplementary_application_accepted=u.supplementary_application_accepted,fy_MPa=u.fy,fu_MPa=u.fu,As_mm2=u.thread_area,
                           thread_manufacture=u.thread_manufacture,thread_compliance=u.thread_compliance,
                           thread_reference=u.thread_reference,thread_standard=u.thread_standard,thread_tpi=u.thread_tpi,
                           area_source=u.thread_area_source,unc_design_area_mm2=unc_area)
    if u.material_basis=='ASTM_supplementary':
        out['assumptions'].append('ASTM A36: aplicação complementar explícita, não material EN 3.3/S235. αv/0,85 não são calibração ASTM e não substituem ductilidade do produto final.')
    out['assumptions'].append('Ti deve incluir prying quando aplicável, vindo do modelo axial qualificado da família; não se reconstrói tração bruta neste kernel.')

    service_reasons = []
    if u.service_slip_requirement == 'ordinary_bearing':
        service_status = 'pass'
    elif u.service_slip_requirement == 'no_slip':
        service_status = 'outside_domain'
        service_reasons.append('Contato por bearing permite acomodação; não atende requisito antideslizante.')
    elif u.service_slip_requirement == 'numeric_total_limit':
        service_status = 'pending'
        service_reasons.append('Limite de deslocamento total exige avaliação própria; folga geométrica não limita δtotal.')
        if u.service_total_limit <= 0:
            service_reasons.append('Informar limite total de deslocamento positivo.')
    else:
        service_status = 'invalid'
        service_reasons.append('Requisito de serviço desconhecido.')
    out['service_scope'] = _scope(service_status,eligible=service_status=='pass',passes=service_status=='pass',
        reasons=service_reasons,mode=u.service_slip_requirement,total_limit_mm=u.service_total_limit,
        diametral_clearance_mm=d0-db,total_displacement_calculated=False,
        note='Folga diametral é informação geométrica, não previsão/limite de deslocamento total. Sem promessa de δ=0.')
    transfer_ok = u.plate_transfer_complete and _text_present(u.plate_transfer_reference)
    out['plate_transfer_scope'] = _scope('documented' if transfer_ok else 'pending',passes=transfer_ok,
        reasons=[] if transfer_ok else [PLATE_NOTE],reference=u.plate_transfer_reference,
        independently_calculated=False)
    out['pending_reasons'] = list(reasons)+service_reasons+out['plate_transfer_scope']['reasons']
    out['reasons'] = list(out['pending_reasons'])

    # Unknown threads/properties do not get an invented numerical capacity.
    # Numerically bounded ASTM and other scope exclusions may be displayed as
    # diagnostic studies, but can never become a qualified kernel pass.
    arithmetic_ok = (thread_valid and 235 <= u.fy <= 640 and 400 <= u.fu <= 800 and u.fy <= u.fu)
    if not arithmetic_ok:
        out['steel_plate_uls'] = _scope('pending',reasons=['Propriedades/rosca fora do domínio das equações.'])
        return out
    kt = .85 if u.material_basis == 'ASTM_supplementary' else (1. if u.thread_compliance == 'en1090_verified' else .85)
    Lj = p1 or 0.
    beta = max(.75,min(1.,1.-(Lj-15.*db)/(200.*db)))
    alpha_bc = .44-.0003*u.fy
    F1_unreduced = kt*ALPHA_V*u.fu*u.thread_area/GAMMA_M2
    F1 = beta*F1_unreduced
    F2 = alpha_bc*u.fu*u.thread_area/GAMMA_M2
    VRd = min(F1,F2)
    TRd = kt*.9*u.fu*u.thread_area/GAMMA_M2
    out['resistances'] = dict(gamma_M2=GAMMA_M2,alpha_v=ALPHA_V,alpha_bc=alpha_bc,kthread=kt,
        beta_Lf=beta,Lj_mm=Lj,F1_before_long_joint_N=F1_unreduced,F1_N=F1,F2_N=F2,
        shear_Rd_N=VRd,tension_Rd_N=TRd,F2_extra_thread_reduction=False,
        shear_governing='F1' if F1<=F2 else 'F2',grout_bending_note=GROUT_NOTE)

    sign = 1. if V >= 0 else -1.
    reaction_sign = -sign
    bearings = {}
    for a in rods:
        # Every physical hole participates, including holes with Qi=0.
        ahead = [b for b in rods if _near(b['y'],a['y']) and reaction_sign*(b['x']-a['x'])>1e-9]
        e1 = L/2-reaction_sign*a['x']
        if ahead:
            pitch = min(abs(b['x']-a['x']) for b in ahead)
            alpha_d = pitch/(3*d0)-.25
            longitudinal_kind = 'interior'
            clear_ligament = pitch-d0
        else:
            pitch = None
            alpha_d = e1/(3*d0)
            longitudinal_kind = 'end'
            clear_ligament = e1-d0/2
        e2 = B/2-abs(a['y'])
        k1 = min(2.8*e2/d0-1.7,1.4*p2/d0-1.7,2.5)
        alpha_b = min(alpha_d,u.fu/plate_fu,1.)
        Fb = k1*alpha_b*plate_fu*db*tp/GAMMA_M2
        # Positive but nonconforming edge spacings may yield negative k1;
        # no negative capacity or divide-by-zero may reach scalar checks.
        Fb = max(0.,Fb)
        bearings[a['id']] = dict(id=a['id'],reaction_sign=reaction_sign,
            reaction_edge='x+' if reaction_sign>0 else 'x-',longitudinal_kind=longitudinal_kind,
            e1_mm=e1,e2_mm=e2,p1_mm=pitch,p2_mm=p2,clear_ligament_mm=clear_ligament,
            alpha_d=alpha_d,alpha_b=alpha_b,k1=k1,bearing_Rd_N=Fb)
    out['bearings'] = bearings

    ordered = [a for row in rows for a in row]
    variants = [('normal_hole_equal',ordered,'Distribuição convencional complementar: EN 3.12(3), DG1/SCI e equilíbrio; Ti concomitante')]
    if len(rows)==2:
        front = rows[1] if sign>0 else rows[0]
        back = rows[0] if sign>0 else rows[1]
        variants += [('leading_row',front,'AISC DG1, linha dianteira para tolerâncias'),
                     ('opposite_row_envelope',back,'Envelope adicional conservador do programa; não regra literal DG1')]
    for sid,active,basis in variants:
        ids = {a['id'] for a in active}
        forces = {a['id']:abs(V)/len(active) if a['id'] in ids else 0. for a in ordered}
        state_rods=[]; checks=[]
        for a in ordered:
            rid=a['id']; T=a['tension']; Q=forces[rid]; Fb=bearings[rid]['bearing_Rd_N']
            state_rods.append(dict(id=rid,x=a['x'],y=a['y'],tension=T,shear=Q,signed_shear=sign*Q,
                credited_to_shear=rid in ids,steel_shear_Rd_N=VRd,tension_Rd_N=TRd,bearing_Rd_N=Fb))
            checks.extend([
                _check(sid+'_tension_'+rid,'Tração da haste '+rid,T,TRd,ids=[rid]),
                _check(sid+'_shear_'+rid,'Corte reduzido da haste '+rid,Q,VRd,ids=[rid]),
                _check(sid+'_bearing_'+rid,'Bearing da placa no furo '+rid,Q,Fb,ids=[rid]),
                _check(sid+'_interaction_'+rid,'Interação corte–tração da haste '+rid,
                       Q/VRd+T/(1.4*TRd),1.,unit='adimensional',ids=[rid])])
        row_caps=[]
        for index,row in enumerate(rows):
            credited = [a for a in row if a['id'] in ids]
            if not credited:
                continue
            per_rod = [min(VRd,bearings[a['id']]['bearing_Rd_N'],
                           max(0.,VRd*(1.-a['tension']/(1.4*TRd)))) for a in credited]
            capacity = len(credited)*min(per_rod)
            demand = sum(forces[a['id']] for a in credited)
            row_ids = [a['id'] for a in credited]
            item = _check(sid+'_row_'+str(index),'Resistência conservadora da linha '+str(index+1),
                          demand,capacity,ids=row_ids)
            checks.append(item)
            row_caps.append(dict(x_mm=row[0]['x'],ids=row_ids,n=len(credited),
                                 minimum_individual_N=min(per_rod),resistance_N=capacity,demand_N=demand))
        residual = sum(forces.values())-abs(V)
        torque = sum(a['y']*forces[a['id']] for a in ordered)
        balanced = abs(residual)<=1e-8+1e-10*abs(V) and abs(torque)<=1e-8+1e-10*max(1.,abs(V)*max(abs(a['y']) for a in ordered))
        passed = balanced and all(c['passes'] for c in checks)
        ratios = [c['ratio'] for c in checks if c['ratio'] is not None]
        out['states'].append(dict(id=sid,label=sid,basis=basis,forces=forces,rods=state_rods,checks=checks,
            row_capacities=row_caps,group_resistance_N=sum(r['resistance_N'] for r in row_caps),V_signed_N=V,sum_shear_N=sum(forces.values()),
            residual_force_N=residual,residual_torsion_Nmm=torque,equilibrium_pass=balanced,
            status='pass' if passed else 'fail',passes=passed,ratio=max(ratios,default=0.),
            diagnostic_only=not out['domain']['eligible'],
            rod_moment_calculated=False,grout_bending_note=GROUT_NOTE))
    numerical_pass = bool(out['states']) and all(s['passes'] for s in out['states'])
    out['steel_plate_uls'] = _scope('pass' if numerical_pass else 'fail',passes=numerical_pass,
        ratio=max(s['ratio'] for s in out['states']),state_count=len(out['states']),
        qualified=out['domain']['eligible'],diagnostic_only=not out['domain']['eligible'],
        governing_state=max(out['states'],key=lambda s:s['ratio'])['id'])
    out['valid'] = out['domain']['eligible'] and numerical_pass and service_status=='pass' and bool(transfer_ok)
    # ACI is not part of this independent kernel. Never claim full route/base.
    out['direct_route_resistance_pass'] = False
    return out


# Short public alias for callers using the other component-kernel convention.
evaluate_component = evaluate_direct_anchor_shear
