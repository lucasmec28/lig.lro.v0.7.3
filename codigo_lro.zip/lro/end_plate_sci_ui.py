"""Separate SCI option inside full-height pinned end-plate family."""
import io,json,hashlib,csv,math
from dataclasses import asdict
import streamlit as st

def fmt(v):return format(v,'.2f').replace('.',',')
from .models import profiles,KGF
from .end_plate_sci import SCIEndPlate,evaluate,UK_BEAM,UK_COLUMN,SCHEMA

def picture(c):
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 from matplotlib.patches import Rectangle,Circle
 fig,axes=plt.subplots(1,2,figsize=(9,5))
 ax,side=axes;b=c.beam
 ax.add_patch(Rectangle((-c.plate_width/2,0),c.plate_width,b.d,facecolor='#d7dfe8',edgecolor='#29415c'))
 for y in (0,b.d-b.tf):ax.add_patch(Rectangle((-b.bf/2,y),b.bf,b.tf,facecolor='none',edgecolor='#333'))
 ax.add_patch(Rectangle((-b.tw/2,b.tf),b.tw,b.d-2*b.tf,facecolor='none',edgecolor='#333'))
 for y in c.ys:
  for x in (-c.gauge/2,c.gauge/2):ax.add_patch(Circle((x,y),c.hole/2,facecolor='white',edgecolor='#333'))
 ax.set_xlim(-b.bf/2-40,b.bf/2+40);ax.set_ylim(b.d+30,-30);ax.set_aspect('equal');ax.axis('off');ax.set_title('Vista frontal da chapa')
 side.add_patch(Rectangle((-c.support.tw, -30),c.support.tw,b.d+60,facecolor='#aaa',edgecolor='#333'))
 side.add_patch(Rectangle((0,0),c.plate_t,b.d,facecolor='#d7dfe8',edgecolor='#29415c'))
 length=180
 for y in (0,b.d-b.tf):side.add_patch(Rectangle((c.plate_t,y),length,b.tf,facecolor='#bbb',edgecolor='#333'))
 side.plot([c.plate_t+length/2]*2,[b.tf,b.d-b.tf],color='#888',lw=1)
 for y in c.ys:side.plot([-c.support.tw-15,c.plate_t+15],[y,y],color='#333',lw=2)
 side.annotate('V',(length,b.d*.75),(length,b.d*.45),arrowprops={'arrowstyle':'->','color':'#b33'},color='#b33')
 side.set_xlim(-50,length+40);side.set_ylim(b.d+30,-30);side.set_aspect('equal');side.axis('off');side.set_title('Vista lateral — apoio na alma')
 fig.suptitle(f'M{c.diameter:g} · {c.rows} linhas × 2 · p={fmt(c.pitch)} mm · g={fmt(c.gauge)} mm',fontsize=11)
 fig.text(.5,.015,'Croqui gerado pelo aplicativo. Materiais e método SCI/Eurocode; não equivalem a ASTM/NBR.',ha='center',fontsize=8)
 fig.tight_layout(rect=(0,.04,1,.94));f=io.BytesIO();fig.savefig(f,format='png',dpi=140);plt.close(fig);return f.getvalue()

def report(c,r):
 # Recompute from the supplied inputs; callers may hold a stale result.
 r=evaluate(c)
 if not r.checks:raise ValueError("Memória SCI indisponível: corrija os dados ou a geometria.")
 from docx import Document
 from docx.shared import Inches,Pt
 d=Document();d.add_heading(c.project,0);d.add_paragraph('Método: SCI P358 (2014), §4.7 / Eurocode com Anexos Nacionais UK. Não é resultado NBR 8800.')
 d.add_paragraph('Situação: '+r.status)
 d.add_paragraph('Referência: https://www.steelconstruction.info/images/a/a9/SCI_P358.pdf · §4.7, verificações 1, 2, 4, 8 e 10; Apêndice C.2.')
 d.add_paragraph(f'V={fmt(c.V/KGF)} kgf ({fmt(c.V/1000)} kN); N=0; M=0. Ações já de cálculo.')
 for text in c.assumptions:d.add_paragraph(text,style='List Bullet')
 d.add_heading('Dados do detalhe',1)
 rows=[('Viga',c.beam.name+' / '+c.beam_grade),('Coluna',c.support.name+' / '+c.support_grade),('Apoio','Alma da coluna; uma viga'),('Chapa',f'{fmt(c.plate_width)} × {fmt(c.beam.d)} × {fmt(c.plate_t)} mm / S275'),('Parafusos',f'{2*c.rows} M20 classe 8.8; furo 22 mm'),('Passo / gabarito',f'{fmt(c.pitch)} / {fmt(c.gauge)} mm'),('Primeira linha desde topo',f'{fmt(c.first_row)} mm'),('Filetes contínuos',f'Perna {fmt(c.weld_leg)} mm'),('Borda superior do apoio',f'{fmt(c.support_top_edge)} mm')]
 t=d.add_table(rows=1,cols=2);t.style='Table Grid';t.rows[0].cells[0].text='Parâmetro';t.rows[0].cells[1].text='Valor'
 for a,b in rows:
  cells=t.add_row().cells;cells[0].text=a;cells[1].text=b
 d.add_picture(io.BytesIO(picture(c)),width=Inches(6.1))
 d.add_heading('Resultados de resistência',1)
 t=d.add_table(rows=1,cols=5);t.style='Table Grid'
 for cell,value in zip(t.rows[0].cells,['Verificação','Solicitação','Resistência','Índice','Resultado']):cell.text=value
 for x in r.checks:
  factor=1000 if x.unit=='N' else 1;unit='kN' if x.unit=='N' else x.unit
  vals=[x.name,f'{fmt(x.demand/factor)} {unit}',f'{fmt(x.resistance/factor)} {unit}',fmt(x.ratio), 'Atende' if x.passed else 'Não atende']
  for cell,value in zip(t.add_row().cells,vals):cell.text=value
 d.add_heading('Geometria e condições de aplicação',1)
 if r.issues:
  for x in r.issues:d.add_paragraph(x.text)
 else:d.add_paragraph('Condições do domínio implementado satisfeitas para os dados declarados.')
 for x in r.checks:d.add_paragraph(x.equation+'; '+x.substitution)
 d.add_paragraph('Rotina de cisalhamento vertical. Amarração acidental e esforços axiais simultâneos não estão incluídos. Conferir materiais efetivamente fornecidos e detalhamento antes de fabricar.')
 for sec in d.sections:
  sec.footer.paragraphs[0].text='LRO Engenharia · SCI/Eurocode UK · Resultado condicionado aos dados declarados'
 d.styles['Normal'].font.size=Pt(9)
 f=io.BytesIO();d.save(f);return f.getvalue()

def load_project():
 try:
  f=st.session_state.get('sci_upload')
  if f is None:return
  if f.size>200000:raise ValueError('Arquivo excessivamente grande.')
  c=SCIEndPlate.from_dict(json.loads(f.getvalue()))
  for k,v in asdict(c).items():
   if k not in ('beam','support'):st.session_state['sci_'+k]=v
  st.session_state.sci_V_kgf=c.V/KGF
  st.session_state.sci_saved=c.to_dict();st.session_state.sci_draft=c;st.session_state.sci_beam_name=c.beam.name;st.session_state.sci_support_name=c.support.name
  st.session_state.pop('sci_import_error',None)
 except Exception as ex:st.session_state.sci_import_error=str(ex)

def render():
 st.subheader('End plate de altura total · SCI/Eurocode · cisalhamento')
 st.warning('Esta opção usa materiais EN e parafusos métricos 8.8. Não substitui a verificação NBR de ASTM A36/A572/A325. Apoio habilitado: alma da coluna.')
 base=st.session_state.get('sci_draft')
 if base is None:base=SCIEndPlate.from_dict(st.session_state.sci_saved) if 'sci_saved' in st.session_state else SCIEndPlate()
 catalog={p.name:p for p in (UK_BEAM,UK_COLUMN)};catalog.update({k:v for k,v in profiles().items() if v.family=='W'})
 beam_catalog=dict(catalog);beam_catalog[base.beam.name]=base.beam
 support_catalog=dict(catalog);support_catalog[base.support.name]=base.support
 def sel(label,opts,key,default):
  return st.selectbox(label,opts,index=opts.index(default) if default in opts else 0,key='sci_'+key)
 def num(label,key,default,step=1.):
  return st.number_input(label,value=float(default),step=step,format='%.2f',key='sci_'+key)
 cols=st.columns(2)
 with cols[0]:
  beam=beam_catalog[sel('Seção geométrica da viga',list(beam_catalog),'beam_name',base.beam.name)]
  bg=sel('Aço EN da viga',['S275','S355'],'beam_grade',base.beam_grade)
 with cols[1]:
  support=support_catalog[sel('Seção geométrica da coluna',list(support_catalog),'support_name',base.support.name)]
  sg=sel('Aço EN da coluna',['S275','S355'],'support_grade',base.support_grade)
 st.caption('Selecionar uma geometria Gerdau não certifica material EN. A confirmação abaixo depende da especificação real de fornecimento.')
 confirmed=st.checkbox('Confirmo S275/S355 nos perfis, chapa S275 e parafusos M20 classe 8.8 conforme especificação real.',value=base.materials_confirmed,key='sci_materials_confirmed')
 V=num('Cisalhamento vertical V (kgf), positivo para baixo','V_kgf',base.V/KGF,100.)*KGF
 a,b,c=st.columns(3)
 with a:
  width=num('Largura da chapa (mm)','plate_width',base.plate_width,5.)
  t=sel('Espessura da chapa S275 (mm)',[10.,12.],'plate_t',base.plate_t)
  n=st.number_input('Linhas de parafusos (2 por linha)',min_value=2,max_value=10,value=base.rows,step=1,key='sci_rows')
 with b:
  gauge=num('Gabarito horizontal (mm)','gauge',base.gauge,5.)
  pitch=num('Passo vertical (mm)','pitch',base.pitch,5.)
  first=num('Topo da viga até primeira linha (mm)','first_row',base.first_row,5.)
 with c:
  weld=num('Perna dos filetes contínuos (mm)','weld_leg',base.weld_leg,.5)
  top=num('Primeiro furo até topo da coluna (mm)','support_top_edge',base.support_top_edge,10.)
  st.caption('Coluna contínua: distâncias acima de 100 mm não aumentam a faixa superior resistente desta opção M20.')
 conn=SCIEndPlate(project=base.project,beam=beam,support=support,beam_grade=bg,support_grade=sg,plate_width=width,plate_t=t,rows=n,gauge=gauge,pitch=pitch,first_row=first,weld_leg=weld,support_top_edge=top,V=V,materials_confirmed=confirmed)
 if any(isinstance(v,(int,float)) and not isinstance(v,bool) and not math.isfinite(v) for v in asdict(conn).values()):
  st.error('FALHA NUMÉRICA · REVISAR ENTRADA')
  st.caption('Informe valores finitos. O último projeto foi preservado; as exportações ficam ocultas até corrigir a entrada.')
  st.stop()
 st.session_state.sci_draft=conn  # Preserve even invalid editable drafts across method switches.
 r=evaluate(conn)
 st.write(r.status)
 for i in r.issues: (st.error if i.severity=='error' else st.warning)(i.text)
 if r.checks:
  st.image(picture(conn))
  st.dataframe([{'Verificação':x.name,'Solicitação':f'{fmt(x.demand/(1000 if x.unit=="N" else 1))}', 'Resistência':f'{fmt(x.resistance/(1000 if x.unit=="N" else 1))}','Unidade':'kN' if x.unit=='N' else x.unit,'Índice':fmt(x.ratio),'Resultado':'Atende' if x.passed else 'Não atende'} for x in r.checks],hide_index=True,width='stretch')
 if r.checks:
  csv_file=io.StringIO(); writer=csv.writer(csv_file,delimiter=';')
  writer.writerow(['Verificação','Solicitação','Resistência','Unidade','Índice','Resultado'])
  for x in r.checks:
   factor=1000 if x.unit=='N' else 1
   writer.writerow([x.name,fmt(x.demand/factor),fmt(x.resistance/factor),'kN' if x.unit=='N' else x.unit,fmt(x.ratio),'Atende' if x.passed else 'Não atende'])
  st.download_button('Baixar resultados CSV SCI',csv_file.getvalue().encode('utf-8-sig'),'end_plate_sci_resultados.csv','text/csv')
 with st.expander('Premissas e limites'):
  for p in conn.assumptions:st.write(p)
 raw=json.dumps(conn.to_dict(),ensure_ascii=False,indent=2,allow_nan=False).encode();digest=hashlib.sha256(raw).hexdigest()
 st.download_button('Salvar projeto SCI',raw,'end_plate_sci.json','application/json')
 st.file_uploader('Abrir projeto SCI desta opção',type=['json'],key='sci_upload',on_change=load_project)
 if 'sci_import_error' in st.session_state:st.error(st.session_state.sci_import_error)
 if r.checks and st.button('Gerar Word SCI para MC'):
  st.session_state.sci_report=(digest,report(conn,r))
 saved=st.session_state.get('sci_report')
 if saved and saved[0]==digest:st.download_button('Baixar Word SCI',saved[1],'end_plate_sci_MC.docx','application/vnd.openxmlformats-officedocument.wordprocessingml.document')
 elif saved:st.caption('Entradas alteradas. Gere novamente o Word para evitar resultado desatualizado.')
