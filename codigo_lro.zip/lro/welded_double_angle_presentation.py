"""Lossless R015 presentation: no new resistance or load distribution.

Only branches of a physical component/mechanism are enveloped. Full source
checks, separate actual/adopted governors, exact ties and signed cases survive.
"""
from collections import OrderedDict
from copy import deepcopy
from .double_angle_presentation import _witness, governing_description


COMPONENT_LABELS = {
    'angle_negative_weld': 'A1 · grupo de solda U',
    'angle_positive_weld': 'A2 · grupo de solda U',
    'angle_negative_beam': 'A1 · aba soldada junto à viga',
    'angle_positive_beam': 'A2 · aba soldada junto à viga',
    'angle_negative_support': 'A1 · aba parafusada ao apoio',
    'angle_positive_support': 'A2 · aba parafusada ao apoio',
    'beam_web': 'Alma única da viga',
    'bolt_support_negative': 'Parafusos do apoio · A1',
    'bolt_support_positive': 'Parafusos do apoio · A2',
    'column_flange_negative': 'Mesa do pilar · lado A1',
    'column_flange_positive': 'Mesa do pilar · lado A2',
}
MECHANISM_LABELS = {
    'weld_rupture': 'Ruptura da solda U excêntrica',
    'weld_base': 'Metal-base junto à solda',
    'elastic_interaction': 'Flexão / corte elástico da aba',
    'section_shear': 'Cisalhamento da seção',
    'bolt_shear': 'Corte dos parafusos',
    'bearing': 'Contato / rasgamento',
    'block': 'Cisalhamento em bloco L',
}


def component_label(component):
    base = component.removesuffix('_Vpos').removesuffix('_Vneg')
    direction = ' · V > 0' if component.endswith('_Vpos') else ' · V < 0' if component.endswith('_Vneg') else ''
    return COMPONENT_LABELS.get(base, base) + direction


def _mechanism(identifier):
    if '_bearing_' in identifier:return 'bearing'
    if '_block_' in identifier:return 'block'
    if '_weld_base_' in identifier:return 'weld_base'
    if identifier.endswith('_weld_rupture'):return 'weld_rupture'
    if identifier.endswith('_beam_elastic_interaction'):return 'elastic_interaction'
    if '_shear_' in identifier:return 'section_shear'
    if identifier.startswith('bolt_support_'):return 'bolt_shear'
    raise ValueError('Verificação R015 sem grupo de apresentação: ' + identifier)


def physical_envelopes(result):
    groups = OrderedDict()
    for check in result.get('checks') or []:
        component = check['component'].removesuffix('_Vpos').removesuffix('_Vneg')
        groups.setdefault((component, _mechanism(check['id'])), []).append(check)
    envelopes = []
    for (component, mechanism), members in groups.items():
        actual_max = max(row['actual_utilization'] for row in members)
        adopted_max = max(row['utilization'] for row in members)
        actual_ties = [_witness(row, result, True) for row in members if row['actual_utilization'] == actual_max]
        adopted_ties = [_witness(row, result, False) for row in members if row['utilization'] == adopted_max]
        envelopes.append({
            'id': component + '__' + mechanism,
            'component': component, 'component_label': component_label(component),
            'mechanism': mechanism, 'mechanism_label': MECHANISM_LABELS[mechanism],
            'units': 'N',
            'actual_governing_id': actual_ties[0]['id'],
            'adopted_governing_id': adopted_ties[0]['id'],
            'actual_utilization': actual_max, 'adopted_utilization': adopted_max,
            'actual_governing': actual_ties[0], 'adopted_governing': adopted_ties[0],
            'actual_governing_ties': actual_ties, 'adopted_governing_ties': adopted_ties,
            'actual_status': 'FAIL' if any(row['actual_status'] == 'FAIL' for row in members) else 'PASS',
            'status': 'FAIL' if any(row['status'] == 'FAIL' for row in members) else 'PASS',
            'member_ids': [row['id'] for row in members], 'members': deepcopy(members),
        })
    return envelopes
