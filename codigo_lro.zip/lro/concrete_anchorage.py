"""ACI 318-19 tension concrete breakout, complementary to the NBR base model.

N, mm, MPa at API boundary. No NBR gamma is applied to ACI phi strength.
Only cast-in mechanical bearing anchors in intact cracked normalweight concrete.
Pure geometry/math functions are independent of the UI and steel shear engine.
Source specification: docs/CONE_CONCRETO_V083.md, DG1 3rd ed. §4.3.2.2.
"""
from itertools import combinations
import math

INCH=25.4
LBF=4.4482216152605
PSI=0.006894757293168361
PHI=0.70  # ACI 318-19 Condition B, no supplementary reinforcement credit
SOURCE='ACI 318-19, 17.6.2; AISC DG1 3ª ed., 4.3.2.2 · base complementar, φ=0,70 (Condição B)'
SUPPORTED=('headed','buried_nut','buried_plate_nut')


def rectangle_union_area(rectangles):
    """Exact axis-aligned union via x-sweep, including overlaps/disjoint regions."""
    rects=[r for r in rectangles if r[2]>r[0] and r[3]>r[1]]
    xs=sorted({x for r in rects for x in (r[0],r[2])})
    area=0.
    for x0,x1 in zip(xs,xs[1:]):
        ys=sorted((r[1],r[3]) for r in rects if r[0]<x1 and r[2]>x0)
        covered=0.;end=None
        for y0,y1 in ys:
            if end is None or y0>end:covered+=y1-y0;end=y1
            elif y1>end:covered+=y1-end;end=y1
        area+=(x1-x0)*covered
    return area


def connected_components(rectangles):
    remaining=set(range(len(rectangles)));components=[]
    def overlap(a,b):
        return min(a[2],b[2])>=max(a[0],b[0]) and min(a[3],b[3])>=max(a[1],b[1])
    while remaining:
        component=[remaining.pop()];queue=list(component)
        while queue:
            i=queue.pop()
            neighbors={j for j in remaining if overlap(rectangles[i],rectangles[j])}
            remaining-=neighbors;component.extend(sorted(neighbors));queue.extend(neighbors)
        components.append(sorted(component))
    return components


def _finite(value):
    return not isinstance(value,bool) and isinstance(value,(int,float)) and math.isfinite(value)


def breakout_group(anchors,bounds,hef,fc):
    """One tension-active set; returns nominal/design strength and geometry.

    anchors: dicts {id,x,y,tension}, all positive tensions from ONE combination.
    bounds: (xmin,ymin,xmax,ymax). All perimeter edges actual and free.
    Narrow-member correction uses *group envelope* clearances, not far rods.
    Basic 24sqrt(fc)h^1.5 policy retained at all depths; no optional deep gain.
    """
    if not anchors or any(not _finite(v) for v in (*bounds,hef,fc)) or hef<=0 or fc<=0:
        raise ValueError('Geometria/material inválidos para o cone.')
    xmin,ymin,xmax,ymax=bounds
    if xmin>=xmax or ymin>=ymax:raise ValueError('Limites do bloco inconsistentes.')
    for rod in anchors:
        if any(not _finite(rod.get(k)) for k in ('x','y','tension')) or rod['tension']<=0:
            raise ValueError('Cada barra do cone deve ter tração positiva e coordenadas finitas.')
        if not xmin<rod['x']<xmax or not ymin<rod['y']<ymax:
            raise ValueError('Barra fora do bloco.')
    xlo=min(r['x'] for r in anchors);xhi=max(r['x'] for r in anchors)
    ylo=min(r['y'] for r in anchors);yhi=max(r['y'] for r in anchors)
    clearances=(xlo-xmin,xmax-xhi,ylo-ymin,ymax-yhi)
    near=[c for c in clearances if c<1.5*hef]
    spacings=[]
    for key in ('x','y'):
        pos=sorted({r[key] for r in anchors});spacings.extend(b-a for a,b in zip(pos,pos[1:]))
    smax=max(spacings,default=0.)
    hcalc=min(hef,max(max(near)/1.5,smax/3)) if len(near)>=3 else hef
    reach=1.5*hcalc
    rects=[(max(xmin,r['x']-reach),max(ymin,r['y']-reach),
            min(xmax,r['x']+reach),min(ymax,r['y']+reach)) for r in anchors]
    components=connected_components(rects)
    anco=9*hcalc*hcalc
    anc=min(rectangle_union_area(rects),len(anchors)*anco)
    total=sum(r['tension'] for r in anchors)
    center_x=sum(r['x'] for r in anchors)/len(anchors)
    center_y=sum(r['y'] for r in anchors)/len(anchors)
    resultant_x=sum(r['x']*r['tension'] for r in anchors)/total
    resultant_y=sum(r['y']*r['tension'] for r in anchors)/total
    ex=abs(resultant_x-center_x);ey=abs(resultant_y-center_y)
    # Product for biaxial eccentricity, one axis for the app's symmetric 2×2.
    psi_ec_x=1/(1+ex/reach);psi_ec_y=1/(1+ey/reach)
    psi_ec=psi_ec_x*psi_ec_y
    cmin=min(clearances)
    psi_ed=min(1.,.7+.3*cmin/reach)
    nb=24*math.sqrt(fc/PSI)*(hcalc/INCH)**1.5*LBF
    nominal=(anc/anco)*psi_ec*psi_ed*nb
    values=(hcalc,anc,anco,nb,nominal,total)
    if not all(math.isfinite(v) for v in values) or min(values)<=0:
        raise ValueError('Escala do cálculo do cone excede o domínio numérico.')
    connected=len(components)==1
    return dict(connected=connected,components=components,ids=[r['id'] for r in anchors],demand=total,hef=hef,hcalc=hcalc,
                narrow=len(near)>=3,clearances=clearances,smax=smax,cmin=cmin,
                projected_rectangles=rects,area=anc,area0=anco,nb=nb,
                centroid=(center_x,center_y),resultant=(resultant_x,resultant_y),ex=ex,ey=ey,
                psi_ec_x=psi_ec_x,psi_ec_y=psi_ec_y,psi_ec=psi_ec,psi_ed=psi_ed,
                psi_c=1.,psi_cp=1.,phi=PHI,nominal=nominal if connected else None,resistance=PHI*nominal if connected else None,
                ratio=total/(PHI*nominal) if connected else None)


def anchor_tensions(c,a):
    """Actual rods; explicit channel coordinates precede the unchanged I/H path."""
    if getattr(c,"model_type",None)==3:
        return [dict(rod) for rod in a["rods"]]
    return [dict(id=f'A{i}',x=x,y=y,tension=a['Ft_max'] if math.isclose(x,a['T_max_x'],rel_tol=0,abs_tol=1e-8) else a['Ft_min'])
            for i,(x,y) in enumerate(((x,y) for x in (-c.a,c.a) for y in (-c.a2/2,c.a2/2)),1)]


def detail_blockers(c,rods):
    problems=[]
    if c.anchor_type not in SUPPORTED:
        problems.append('Cone nativo somente para cabeça forjada, porca enterrada ou chapa de apoio com porca, moldadas no concreto; reto sem cabeça/gancho/adesivo não têm resistência atribuída.')
    if not c.anchor_detail_confirmed or not c.anchor_detail_ref.strip():
        problems.append('Confirme e referencie o detalhe moldado no local, com concreto íntegro e transferência mecânica na cabeça/porca/chapa. Bolsões vazios, espuma, bainhas livres, concreto não fissurado ou ancoragem química não são presumidos.')
    if c.hef<=0 or c.block_h<=0 or c.block_xmin>=c.block_xmax or c.block_ymin>=c.block_ymax:
        problems.append('Informe embutimento efetivo positivo e limites/altura reais consistentes do bloco.')
    if min(c.anchor_head_width,c.anchor_head_length,c.anchor_head_t,c.anchor_bearing_t,c.anchor_nut_t)<=0 or c.anchor_bottom_cover<0:
        problems.append('Informe dimensões reais positivas do elemento enterrado e cobrimento inferior geométrico não negativo.')
    assembly_depth=c.anchor_bearing_t+(c.anchor_nut_t if c.anchor_type=='buried_plate_nut' else 0.)
    if c.anchor_head_t<assembly_depth:
        problems.append('A extensão inferior completa deve conter a espessura da peça de apoio e a porca inferior, quando houver.')
    if c.hef+c.anchor_head_t+c.anchor_bottom_cover>c.block_h:
        problems.append('O elemento enterrado e o cobrimento informado não cabem na altura do bloco: hef+extensão inferior completa+cobrimento ≤ h.')
    if c.anchor_type=='buried_plate_nut' and not c.db<c.anchor_head_hole<min(c.anchor_head_width,c.anchor_head_length):
        problems.append('A chapa enterrada requer furo maior que db e menor que suas dimensões em planta.')
    if c.anchor_type=='buried_nut' and c.anchor_nut_bearing_area<=0:
        problems.append('Informe a área líquida de apoio documentada da porca enterrada; a área não é calculada a partir do diâmetro da barra.')
    for rod in rods:
        if not (c.block_xmin<=rod['x']-c.anchor_head_length/2 and rod['x']+c.anchor_head_length/2<=c.block_xmax and
                c.block_ymin<=rod['y']-c.anchor_head_width/2 and rod['y']+c.anchor_head_width/2<=c.block_ymax):
            problems.append('Ao menos uma cabeça/porca/chapa enterrada não cabe nos limites reais do bloco.');break
    # The current detail represents individual equal-elevation bearing pieces.
    from itertools import combinations
    if any(abs(a['x']-b['x'])<c.anchor_head_length-1e-8 and abs(a['y']-b['y'])<c.anchor_head_width-1e-8
           for a,b in combinations(rods,2)):
        problems.append('Envelopes das peças enterradas individuais se sobrepõem na mesma cota. Peça compartilhada ou outro arranjo exige detalhe e modelo específicos; não se presume quatro apoios independentes.')
    # Support geometry, not an enlargement of bearing capacity.
    if (c.block_xmin>-(c.L/2+c.grout_t) or c.block_xmax<c.L/2+c.grout_t or
        c.block_ymin>-(c.B/2+c.grout_t) or c.block_ymax<c.B/2+c.grout_t):
        problems.append('O bloco deve conter a projeção real do graute a 45°; reveja as dimensões ou use detalhe/modelo específico.')
    if c.db>4*INCH:problems.append('Diâmetro além de 4 pol. fora do domínio ACI deste submodelo.')
    return problems


def evaluate_cone(c,a):
    """Application envelope; pending data do not suppress the unrelated NBR checks."""
    if c.cone_model=='off':return dict(status='off',groups=[],reasons=[])
    rods=anchor_tensions(c,a)
    reasons=detail_blockers(c,rods)
    if reasons:return dict(status='pending',groups=[],reasons=reasons,rods=rods)
    active=[r for r in rods if r['tension']>0.]
    if not active:return dict(status='not_demanded',groups=[],reasons=[],rods=rods)
    groups=[];primary=[]
    bounds=(c.block_xmin,c.block_ymin,c.block_xmax,c.block_ymax)
    def source_components(subset):
        group=breakout_group(subset,bounds,c.hef,c.fck)
        if group['connected']:
            group['id']='_'.join(group['ids']);group['basis']='source'
            primary.append(group)
        else:
            for indices in group['components']:source_components([subset[i] for i in indices])
    try:
        source_components(active)
        groups.extend(primary)
        if c.cone_subset_envelope:
            existing={g['id'] for g in groups}
            # Supplemental conservative envelope, explicitly user-selected.
            for n in range(1,len(active)+1):
                for subset in combinations(active,n):
                    group=breakout_group(subset,bounds,c.hef,c.fck)
                    group['id']='_'.join(group['ids']);group['basis']='supplemental'
                    if group['connected'] and group['id'] not in existing:groups.append(group)
    except (ValueError,OverflowError,ZeroDivisionError) as exc:
        return dict(status='pending',groups=[],reasons=[str(exc)],rods=rods)
    governing=max(groups,key=lambda g:g['ratio'])
    return dict(status='calculated',groups=groups,reasons=[],rods=rods,
                governing=governing,primary_groups=primary,phi=PHI,source=SOURCE,
                combination=dict(N=c.N,M_top=c.M,M_foundation=c.effective_moment,V=c.V))
