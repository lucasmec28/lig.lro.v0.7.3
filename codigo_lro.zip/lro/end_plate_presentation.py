"""Read-only end-plate result indices; never used for engineering decisions.

Resistance, method conditions and geometry/scope alerts are distinct. Finite
available comparisons remain visible when another required check is unresolved.
No value is rounded here and no approval is inferred from any maximum.
"""
from dataclasses import asdict
from math import isfinite
from .display_precision import display_format

CONTRACT_REVISION = 'endplate-result-indices-0942-v1'
SCOPE_NOTICE = ('Índices locais disponíveis; não aprovam a ligação completa, '
                'a fabricação ou a estabilidade global. Conferir condições e limites.')


def _valid(row):
    try:
        return (isfinite(row.demand) and isfinite(row.resistance) and
                row.resistance > 0 and isfinite(row.ratio) and
                getattr(row, 'numerically_valid', True))
    except (TypeError, ValueError, OverflowError):
        return False


def _identity(row):
    return {'id': row.id, 'name': row.name, 'case': row.case,
            'category': row.category, 'ratio': row.ratio,
            'outcome': row.outcome}


def result_indices(result):
    """An additive audit/presentation view over the original calculated rows.

    Use ungrouped envelope rows so a method condition never hides a resistant
    branch. Inspect every case for numerical failures: a finite envelope must
    not erase an unresolved required case. Missing indices are None, never 0.
    """
    rows = result.checks
    case_rows = getattr(result, 'all_case_checks', []) or result.actual or rows
    all_rows = list(rows)
    for row in case_rows:
        if not any(row is item for item in all_rows):
            all_rows.append(row)

    def maximum(category):
        candidates = [row for row in rows if row.category == category and
                      _valid(row) and getattr(row, 'applicable', True)]
        winner = max(candidates, key=lambda row: row.ratio) if candidates else None
        return {'max_ratio': winner.ratio if winner else None,
                'governing': _identity(winner) if winner else None,
                'available_checks': len(candidates)}

    def issues(predicate):
        return [asdict(issue) for issue in result.issues if predicate(issue)]

    invalid = []
    for row in all_rows:
        if not _valid(row) and (row.id, row.case) not in invalid:
            invalid.append((row.id, row.case))
    return {
        'contract_revision': CONTRACT_REVISION,
        'resistance': maximum('Resistência'),
        'method_conditions': maximum('Condição do método'),
        'geometry_and_detailing_issues': issues(lambda issue:
            issue.severity in ('noncompliance', 'interference') or
            (issue.severity == 'error' and issue.origin not in ('data', 'numeric', 'method'))),
        'method_issues': issues(lambda issue: issue.origin == 'method'),
        'pending_scope_issues': issues(lambda issue:
            issue.severity == 'pending' or issue.origin == 'local_scope'),
        'outside_scope_issues': issues(lambda issue: issue.severity in ('extrapolation', 'excluded')),
        'data_or_numeric_issues': issues(lambda issue:
            issue.severity == 'error' and issue.origin in ('data', 'numeric')),
        'invalid_checks': [{'id': identity, 'case': case} for identity, case in invalid],
        'unresolved_cases': [{'label': case['label'], 'status': case['status'],
                              'reason': case.get('reason', '')}
                             for case in getattr(result, 'case_records', [])
                             if case['status'] != 'calculated'],
        'legacy_max_ratio_basis': 'all_checks_including_method_conditions; not_resistance_utilization',
        'scope_notice': SCOPE_NOTICE,
    }


def ratio_text(value):
    return 'indisponível' if value is None else display_format(value, '.2f').replace('.', ',')


def summary_lines(result):
    """One wording contract for the UI, drawing and both Word report paths."""
    indices = result_indices(result)
    resistance = indices['resistance']
    method = indices['method_conditions']
    lines = ['Utilização resistente: ' + ratio_text(resistance['max_ratio'])]
    if resistance['governing']:
        row = resistance['governing']
        lines.append('Governante resistente: ' + row['name'] + ' [' + row['case'] +
                     '] · ' + row['outcome'])
    lines.append('Condições do método: índice máximo ' + ratio_text(method['max_ratio']) +
                 ' · não é utilização resistente')
    if method['governing']:
        row = method['governing']
        lines.append('Condicionante governante: ' + row['name'] + ' [' + row['case'] +
                     '] · ' + row['outcome'])
    geometry = len(indices['geometry_and_detailing_issues'])
    lines.append('Geometria e detalhamento: ' + (str(geometry) + ' alerta(s)' if geometry else
                 'sem alertas detectados nas verificações realizadas'))
    pending = len(indices['pending_scope_issues'])
    outside = len(indices['outside_scope_issues'])
    unresolved = len(indices['unresolved_cases'])
    if pending or outside or unresolved:
        lines.append('Escopo: ' + str(pending) + ' pendência(s); ' + str(outside) +
                     ' ressalva(s)/exclusão(ões); ' + str(unresolved) + ' caso(s) sem conclusão')
    if indices['invalid_checks'] or indices['data_or_numeric_issues']:
        lines.append('Dados/falhas numéricas: há resultados sem conclusão; o índice finito disponível não os substitui.')
    return lines
