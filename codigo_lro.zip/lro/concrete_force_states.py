"""Bounded ACI interaction across actual and real x-edge redistribution states.

Virtual perpendicular edge constructions are resistance comparisons only;
they never become physically rotated or torsional force states.
"""
import math
from .concrete_shear import evaluate_shear,aci_steel,interaction,SOURCE
from .models import Issue


def evaluate_force_states(c,r,rods,tension_checks,base_shear,base_steel,steel_ready,prerequisite_reasons,add):
    u=c.concrete_components;bounds=(c.block_xmin,c.block_ymin,c.block_xmax,c.block_ymax)
    states=[];seen=set();vectors=[]
    Vanchor=base_shear.get('V_anchor',c.V)
    actual={a['id']:a['shear'] for a in base_shear.get('rods',[]) if 'shear' in a}
    if set(actual)!={a['id'] for a in rods}:
        result=interaction(tension_checks,[],complete=False,pending_reasons=prerequisite_reasons+['Vetor físico de cortante ainda indisponível.'])
        return dict(interaction=result,states=[],attachment_demands=[])
    def append_vector(label,forces,basis):
        if set(forces)!={a['id'] for a in rods}:return
        values=tuple(forces[a['id']] for a in rods)
        key=tuple(format(v,'.12g') for v in values)
        if key in seen:return
        if any(not math.isfinite(v) or v<0 for v in values):return
        if not math.isclose(sum(values),abs(Vanchor),rel_tol=1e-10,abs_tol=1e-8):return
        moment=sum(a['y']*forces[a['id']] for a in rods)
        if abs(moment)>1e-8+1e-10*max(1.,abs(Vanchor)*max(abs(a['y']) for a in rods)):return
        seen.add(key);vectors.append((label,dict(forces),basis))
    append_vector('Vetor físico documentado' if Vanchor else 'Tração com cortante nulo nos chumbadores',actual,'actual')
    for mechanism in base_shear.get('breakout',{}).get('mechanisms',[]):
        if mechanism.get('virtual_perpendicular') or mechanism.get('case') not in ('case2','case3'):continue
        vector={a['id']:0. for a in rods}
        for rid,force in zip(mechanism['ids'],mechanism['forces']):vector[rid]=force
        append_vector('Estado alternativo '+mechanism['edge']+'/'+mechanism['case'],vector,'real_x_edge')
    native={a['id']:a for a in r.geometry.get('anchor_shear',{}).get('rods',[])}
    maxima={a['id']:0. for a in rods}
    for index,(label,forces,basis) in enumerate(vectors):
        if index==0:shear=base_shear;steel=base_steel
        else:
            shear=evaluate_shear(rods,bounds,c.hef,c.fck,c.block_h,c.db,Vanchor,
                dict(mode='documented',qualified=True,reference=u.distribution_ref+'; mecanismo alternativo real x conforme ACI/DG1',
                     forces=forces,parallel_model=u.parallel_model,optional_envelope=u.optional_envelope))
            steel=[]
            if steel_ready:
                for rod in rods:
                    part=aci_steel(tension=rod['tension'],shear=forces[rod['id']],area_tension=u.area_tension,area_shear=u.area_shear,
                                  fy=c.anchor_fy,fu=c.anchor_fu,ductile=u.ductile,grout=True,ductility_ref=u.ductility_ref,id=rod['id'])
                    steel.extend(part['checks'])
        reasons=list(prerequisite_reasons)
        if not steel_ready:reasons.append('Aço ACI ainda não qualificado/calculado.')
        shear_checks=[x for x in steel if x['id'].startswith('aci_shear_')]
        for mode in ('breakout','pryout'):
            result=shear.get(mode,{})
            if result.get('status') not in ('calculated','not_demanded','not_applicable'):
                reasons.extend(result.get('reasons',[]) or [mode+' pendente no estado '+label])
            shear_checks.extend(x for x in result.get('checks',[]) if not x.get('diagnostic_only'))
        if index>0:
            for j,check in enumerate(shear_checks):
                add(f'cc_state_{index}_{j}',label+' — '+check['label'],check['demand'],check['resistance'],'N',check.get('method',SOURCE),
                    'Vi/φVn do mesmo estado e grupo ≤ 1',f'Sd={check["demand"]:.8g}; Rd={check["resistance"]:.8g}; barras='+','.join(check['ids']),
                    'Estado alternativo de resistência, não simultâneo com os outros. Mesmas trações Ti; pryout usa somente o conjunto ativo deste estado.')
            if c.native_anchor_shear:
                for rid,q in forces.items():
                    if rid in native:
                        add(f'cc_state_{index}_nbr_{rid}',label+' — '+rid+' / capacidade NBR',q,native[rid]['rd'],'N',
                            'NBR 8800 6.7.2.5 e 6.3.3.4','Vi,Sd do estado ≤ VRd,i condicionado a Ti',f'Vi={q:.8g}; VRd,i={native[rid]["rd"]:.8g}',
                            'A resistência de aço, interação e limite local NBR são verificados por barra no estado redistribuído.')
        result=interaction(tension_checks,shear_checks,complete=not reasons,pending_reasons=reasons)
        result['method']='Interação ACI limitada aos estados de força enumerados'
        states.append(dict(label=label,basis=basis,forces=forces,shear=shear,steel=steel,interaction=result))
        for rid,q in forces.items():maxima[rid]=max(maxima[rid],q)
    if not states:
        result=interaction(tension_checks,[],complete=False,pending_reasons=prerequisite_reasons+['Não há estado plano admissível com ΣVi=|V| e torção nula.'])
        return dict(interaction=result,states=[],attachment_demands=[])
    governing=max(states,key=lambda state:state['interaction']['ratio'])
    result=dict(governing['interaction'])
    all_ready=all(state['interaction']['passes'] is not None for state in states)
    result.update(complete=all_ready,governing_state=governing['label'],state_count=len(states),
                  states_summary=[dict(label=x['label'],forces=x['forces'],ratio=x['interaction']['ratio'],status=x['interaction']['status']) for x in states])
    if not all_ready:
        result.update(status='pending',passes=None,reasons=list(dict.fromkeys(reason for state in states for reason in state['interaction']['reasons'])))
    attachments=[];local=r.local_upper_washer
    for rid,q in maxima.items():
        item=dict(id=rid,required=q,design_action=local.get('F_N'))
        attachments.append(item)
        if c.native_anchor_shear and local.get('F_N') is not None:
            add('cc_attachment_'+rid,'Arruela '+rid+' — cobertura da demanda máxima dos estados',q,local['F_N'],'N',
                'NBR 8800 6.7.2.5; envelope local de arruela selecionado','max(Vi,Sd dos estados) ≤ Fv,Rd adotado no cálculo local',
                f'Vi,max={q:.8g}; ação local={local["F_N"]:.8g}',
                'Compara demanda com a ação usada no dimensionamento local; não representa resistência adicional. As verificações locais de solda/furo mantêm seus próprios resultados.')
    return dict(interaction=result,states=states,attachment_demands=attachments)
