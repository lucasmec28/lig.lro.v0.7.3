"""Lossless display envelopes for the source-qualified elastic CJP family.

This module never recalculates resistance. Public drawing and report exports
obtain their own current canonical evaluation before building these envelopes.
"""
from collections import OrderedDict
from copy import deepcopy
from math import isfinite

COMPONENT_LABELS = {
    'top_flange': 'Mesa superior', 'bottom_flange': 'Mesa inferior',
    'web': 'Alma remanescente', 'weld_group': 'Grupo CJP completo',
    'flange_top': 'Mesa superior', 'flange_bottom': 'Mesa inferior',
    'receiver_web': 'Alma receptora com V integral',
    'receiver_section': 'Seção receptora reduzida',
    'weld_top_flange': 'CJP da mesa superior', 'weld_bottom_flange': 'CJP da mesa inferior',
    'weld_web': 'CJP da alma remanescente',
    'receiver_a_section': 'Membro A seção receptora', 'receiver_b_section': 'Membro B seção receptora',
    'receiver_a_web_nominal': 'Membro A alma sob normal e V integral',
    'receiver_b_web_nominal': 'Membro B alma sob normal e V integral',
    'receiver_a_web': 'Membro A alma com V integral',
    'receiver_b_web': 'Membro B alma com V integral',
    'adjacent_web': 'Alma adjacente',
}
MECHANISM_LABELS = {
    'normal': 'Tensão normal no metal base',
    'shear': 'Cisalhamento no metal base',
    'equivalent': 'Interação de Fakury Eq. 10.27',
    'interaction': 'Interação de Fakury Eq. 10.27',
    'normal_yield': 'Escoamento por tensão normal',
    'shear_yield': 'Escoamento por cisalhamento',
    'tension_rupture': 'Ruptura da seção tracionada',
    'net_tension': 'Ruptura da seção líquida tracionada',
    'web_shear_yield': 'Escoamento da alma sob V integral',
    'web_shear_rupture': 'Ruptura da alma sob V integral',
    'web_shear': 'Resistência da alma sob V integral',
    'elastic_interaction': 'Interação elástica no mesmo ponto',
    'local_compression': 'Compressão local',
    'full_shear': 'Resistência da alma sob V integral',
    'shear_stability': 'Cisalhamento e estabilidade da alma adjacente',
}


def _finite(value):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return False
    try:
        return isfinite(value)
    except (OverflowError, ValueError):
        return False


def component_label(component):
    return COMPONENT_LABELS.get(str(component), str(component).replace('_', ' '))


def _governors(rows):
    finite = [row for row in rows if _finite(row.get('utilization'))]
    maximum = max((row['utilization'] for row in finite), default=None)
    # Unknown demand or capacity is an unresolved witness, never a hidden pass.
    unresolved = [row for row in rows if not _finite(row.get('utilization'))]
    tied = unresolved + [row for row in finite if row['utilization'] == maximum]
    return maximum, deepcopy(tied)


def _status(rows):
    if not rows:
        return 'NOT_EVALUATED'
    if any(row.get('status') == 'FAIL' or row.get('passed') is False for row in rows):
        return 'FAIL'
    if all(row.get('status') == 'PASS' or row.get('passed') is True for row in rows):
        return 'PASS'
    return 'NOT_VERIFIED'


def physical_envelopes(result):
    """Group only matching physical component/mechanism; retain every witness.

    Both actual and all-case envelopes retain exact ties, IDs, signs and source
    metadata. Both members remain serial paths; no capacities are ever added.
    """
    groups = OrderedDict()
    for row in result.get('checks') or []:
        if not isinstance(row, dict):
            continue
        component = str(row.get('component', 'unidentified'))
        if component.startswith('weld_'):
            component = component.removesuffix('_min').removesuffix('_max')
        key = (component, str(row.get('mechanism', 'unidentified')))
        groups.setdefault(key, []).append(row)
    cases = result.get('cases') or []
    if isinstance(cases, dict):
        cases = list(cases.values())
    actual_ids = {str(case.get('id', case.get('case_id'))) for case in cases
                  if isinstance(case, dict) and case.get('kind', 'actual') in ('actual', 'design')}
    actual_ids.add('actual')
    envelopes = []
    for (component, mechanism), rows in groups.items():
        actual = [row for row in rows if str(row.get('case_id')) in actual_ids
                  or row.get('case_kind') in ('actual', 'design')]
        maximum, governing = _governors(rows)
        actual_maximum, actual_governing = _governors(actual)
        envelopes.append({
            'id': component + '__' + mechanism,
            'component': component, 'component_label': component_label(component),
            'mechanism': mechanism,
            'mechanism_label': MECHANISM_LABELS.get(mechanism, mechanism.replace('_', ' ')),
            'units': rows[0].get('unit', rows[0].get('units', '')),
            'utilization': maximum, 'adopted_utilization': maximum,
            'actual_utilization': actual_maximum,
            'status': _status(rows), 'actual_status': _status(actual),
            'governing': governing, 'governing_ties': deepcopy(governing),
            'adopted_governing_ties': deepcopy(governing),
            'actual_governing': actual_governing,
            'actual_governing_ties': deepcopy(actual_governing),
            'governing_ids': [row.get('id') for row in governing],
            'member_ids': [row.get('id') for row in rows],
            'members': deepcopy(rows),
        })
    return envelopes


def governing_description(row):
    """Unambiguous short physical witness, including every available location."""
    parts = [str(row.get('id', 'sem identificação'))]
    # The stable primitive ID already contains the case and physical point.
    for key in ('side', 'cut_id', 'section_id', 'point', 'location', 'x_mm', 'y_mm'):
        if row.get(key) is not None:
            parts.append(key + '=' + str(row[key]))
    metadata = row.get('metadata') or {}
    for key in ('y', 'x', 'x_interval', 'M_bound', 'sigma', 'tau', 'side'):
        if key in metadata:
            parts.append(key + '=' + str(metadata[key]))
    return '; '.join(parts)
