"""Input-bound Portuguese Word calculation record for the welded gusset route.

Compact output shows named physical envelopes. Detailed output also preserves
all case paths, section witnesses and consolidated check details. Every public
call recalculates the input and rejects caller-supplied approval by construction.
"""
from dataclasses import asdict
from io import BytesIO
from math import isfinite
import re
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor

from .welded_opposed_angle_gusset import COMPONENT_VERSION, FAMILY
from .welded_opposed_angle_gusset_drawing import STATUS, image_bytes, input_fingerprint, validated_result
from .welded_opposed_angle_gusset_presentation import (physical_envelopes, selected_angle, angle_transfer,
                                                angle_identity, angle_detail_disclosure)
from .report import BRAND, _math, frac, group, power, radical, table

def _value(value):
    if isinstance(value, bool): return 'sim' if value else 'não'
    if value is None: return 'não disponível'
    if isinstance(value, float):
        return format(value, '.15g').replace('.', ',') if isfinite(value) else str(value)
    if isinstance(value, dict):
        return '; '.join(str(k) + '=' + _value(v) for k, v in value.items())
    if isinstance(value, (list, tuple)):
        return '; '.join(_value(v) for v in value) or 'nenhum'
    return str(value) if str(value) else 'não informado'


def _n(value, decimals=4, divisor=1):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not isfinite(value):
        return 'não disponível'
    return format(value / divisor, '.' + str(decimals) + 'f').replace('.', ',')


def _flatten(value, prefix=''):
    if isinstance(value, dict):
        for key, child in value.items():
            yield from _flatten(child, prefix + '.' + str(key) if prefix else str(key))
    elif isinstance(value, (list, tuple)):
        if not value: yield prefix, 'nenhum'
        for i, child in enumerate(value):
            yield from _flatten(child, prefix + '[' + str(i) + ']')
    else:
        yield prefix, _value(value)


def _tab(doc, headers, rows, widths=None, size=8):
    widths = widths or [6.97 / len(headers)] * len(headers)
    out = table(doc, headers, rows, widths)
    # Keep short witness/branch tables together. Some LibreOffice builds can
    # clip the final cantSplit rows of a tiny table straddling a page boundary.
    # The explicit paragraph chain moves the whole small table to the next
    # page; large tables retain normal repeating-header pagination.
    short_table = len(out.rows) <= 6
    for index, row in enumerate(out.rows):
        for j, cell in enumerate(row.cells):
            for p in cell.paragraphs:
                if short_table:
                    p.paragraph_format.keep_with_next = index < len(out.rows) - 1
                if j == 0: p.alignment = WD_ALIGN_PARAGRAPH.LEFT
                for run in p.runs: run.font.size = Pt(size)
    return out


def _heading(doc, title, level=1):
    title = str(title).replace('N/2', 'N dividido por 2').replace('+z', 'z positiva').replace('−z', 'z negativa').replace('-z', 'z negativa')
    title = re.sub(r'[^\w\s]', ' ', title).replace('_', ' ')
    return doc.add_paragraph(' '.join(title.split()), style='Heading ' + str(level))



def _issues(doc, r):
    issues=r.get('issues') or []
    if not issues: return
    _heading(doc,'Ocorrências e limites da entrada atual')
    for issue in issues:
        p=doc.add_paragraph()
        p.add_run(str(issue.get('severity','Ocorrência'))+': ').bold=True
        p.add_run(str(issue.get('message',issue.get('text',issue))))
        if issue.get('reference'): p.add_run(' Referência: '+str(issue['reference']))


def _inputs(doc,c,r):
    # Import labels lazily, without invoking Streamlit or its session state.
    labels={
        'project':'Projeto', 'support_member':'Membro de apoio', 'support_face':'Face receptora',
        'angle_profile':'Cantoneira de catálogo', 'support_profile':'Perfil W receptor',
        'plate_width':'Largura / raiz B (mm)', 'plate_height':'Projeção H (mm)', 'plate_t':'Espessura da chapa (mm)',
        'theta_deg':'Ângulo da cantoneira com o eixo longitudinal +s do apoio W · θ (graus)', 'center_s':'Centro das soldas em s (mm)', 'center_n':'Centro das soldas em n (mm)',
        'weld_length':'Comprimento efetivo de cada uma das quatro soldas (mm)', 'end_margin':'Margem da extremidade livre (mm)',
        'angle_weld_leg':'Perna inscrita cantoneira–chapa (mm)',
        'angle_weld_edge_detail':'Detalhe da borda da cantoneira', 'root_weld_leg':'Perna chapa–mesa W (mm)',
        'introduction_width':'Largura da seção local (mm)', 'support_end_left':'Extremidade esquerda W, módulo s (mm)',
        'support_end_right':'Extremidade direita W, s (mm)', 'N':'Força axial total do par N (N)',
        'V':'Cortante adicional V (N)', 'M':'Momento adicional M (N mm)', 'torsion':'Torção T (N mm)',
        'static':'Carregamento estático', 'normal_combination':'Combinação última normal',
        'fatigue':'Fadiga exigida', 'seismic':'Qualificação sísmica exigida',
        'minimum_force':'Mínimo de 45 kN em caso separado', 'recommend_half_capacity':'Recomendação de meia capacidade em caso separado',
        'angle_steel':'Aço comum às duas cantoneiras', 'gusset_steel':'Aço da chapa', 'support_steel':'Aço do W',
        'angle_electrode':'Eletrodo 2L–chapa', 'root_electrode':'Eletrodo da raiz', 'notes':'Observações',
        'topology':'Topologia confirmada', 'interface':'Interface de transferência',
        'symmetric_load':'Carga simétrica nas duas L', 'accessible_both_faces':'Acesso físico às duas faces',
    }
    _heading(doc,'Entradas e materiais independentes')
    doc.add_paragraph('Unidades nativas: N, mm e MPa; momentos em N mm. Os valores informados abaixo não são arredondados para realimentar o cálculo. Viga ou pilar muda a apresentação, sem mudar os eixos e resistências locais.')
    _tab(doc,['Dado informado','Valor'],[(labels.get(k,k),_value(v)) for k,v in asdict(c).items()],[3.65,3.32])
    angle = selected_angle(c, r)
    _heading(doc,'Cantoneira selecionada: dimensões, propriedades e procedência',2)
    doc.add_paragraph(angle_identity(angle, c.angle_profile) + ' · identidade: ' + c.angle_profile)
    if angle:
        _tab(doc,['b por L (mm)','t por L (mm)','Ag por L (mm²)','ec por L (mm)'],
             [[_value(angle.get(key)) for key in ('leg','t','Ag','centroid')]], [1.74,1.74,1.75,1.74])
        doc.add_paragraph('Fonte da cantoneira selecionada: '+str(angle.get('source','não informada')))
        if angle.get('source_sha256'):
            doc.add_paragraph('SHA-256 da fonte da cantoneira: '+str(angle['source_sha256']))
        doc.add_paragraph(angle_detail_disclosure(angle))
        if angle.get('property_selection_criterion'):
            doc.add_paragraph('Critério de propriedade: '+str(angle['property_selection_criterion']))
        if not angle.get('section_properties_published'):
            doc.add_paragraph('Ag e ec ausentes na linha publicada. Sem estimativa de propriedades ou conclusão resistente para esta seção.')
    if angle and angle.get('Ag') is not None:
        doc.add_paragraph('Duas L idênticas: Ag do par = 2 Ag = '+_value(2*angle['Ag'])+' mm². Ct e Ae continuam definidos por cantoneira; Ae do par é a soma das duas áreas efetivas, sem nova multiplicação de área do par.')
    selected=(r.get('geometry') or {}).get('support_catalog')
    if selected:
        _heading(doc,'Geometria e fonte do W selecionado',2)
        _tab(doc,['Perfil','d (mm)','bf (mm)','tw (mm)','tf (mm)','r (mm)','k (mm)'],
             [(str(selected.get('name')), *[_n(selected.get(key),3) for key in ('d','bf','tw','tf','r','k')])],
             [1.75,.87,.87,.87,.87,.87,.87],7.5)
        doc.add_paragraph('Fonte da geometria selecionada: '+str(selected.get('source','não informada')))
    if r.get('materials'):
        _heading(doc,'Resistências dos três aços e dos dois consumíveis',2)
        _tab(doc,['Registro / propriedade','Valor'],list(_flatten(r['materials'])),[3.65,3.32])
    doc.add_paragraph('Cada metal base utiliza seu próprio fy/fu e espessura. Os dois consumíveis são independentes. Identificar os materiais e comprovar certificados, compatibilidade, procedimento de soldagem, execução e inspeção no projeto real. O exemplo numérico não certifica fabricação.')


def _cases(doc,r):
    _heading(doc,'Casos concorrentes preservados e equilíbrio da raiz')
    transfer = angle_transfer((r.get('geometry') or {}).get('angle_section'))
    transfer_text = ('O calcanhar recebe '+_n(100*transfer['heel'],6)+'% de N/2 e a ponta '+_n(100*transfer['toe'],6)+
                     '% de N/2 em cada face; cada parcela é uniforme ao longo de sua solda. O centroide projetado está em v='+
                     _n(transfer['projected_centroid'],6)+' mm, mantido na transformação. ' if transfer else
                     'As frações de força e o centroide projetado dependem de b e ec publicados; não são presumidos quando indisponíveis. ')
    doc.add_paragraph('N positivo indica tração. Eixo +s paralelo à raiz e ao eixo longitudinal da viga ou pilar W; θ vai de +s até o eixo da cantoneira, sem referência à horizontal global. Eixo n normal à mesa no plano da chapa. '+transfer_text+'Casos reais e mínimos/recomendados permanecem separados.')
    doc.add_paragraph('N é a força axial total do par; cada cantoneira recebe N/2. A única chapa, a raiz e o W recebem N total. Momento local derivado da excentricidade da força axial; não é momento aplicado à cantoneira. A referência de Mraiz é o centroide do grupo de soldas da raiz. O centro informado das soldas e o centroide do par v=0 definem essa linha, sem acrescentar excentricidade arbitrária.')
    cases=r.get('cases') or []
    if not cases:
        doc.add_paragraph('Nenhum caso resistente concluído para a entrada atual. Não há capacidade favorável presumida.')
        return
    doc.add_paragraph('A força real permanece intacta. O mínimo de 45 kN aplica-se uma vez à ligação completa e só depois é repartido em 22,5 kN por L. A recomendação opcional de 50% usa a resistência do par em outro caso, sem somar casos entre si.')
    _tab(doc,['Caso / origem','Descrição','N total (kN)','N/2 por L (kN)'],[(str(x.get('id'))+' / '+str(x.get('kind','actual' if x.get('id')=='actual' else 'suplementar')),
        str(x.get('label','')),_n(x.get('N'),6,1000),_n(x.get('N_per_angle'),6,1000)) for x in cases],[1.5,2.87,1.3,1.3])
    for case in cases:
        _heading(doc,'Forças e áreas por face no caso '+str(case.get('id')),2)
        _tab(doc,['Propriedade','Valor'], [(name,_value(case.get(name))) for name in ('N','N_per_angle','angle_Ct','angle_Ae','pair_gross_area','pair_effective_area')], [3.65,3.32])
        if case.get('angle_forces'):
            _tab(doc,['Força por face','Valor (N)'],list(_flatten(case['angle_forces'])),[3.65,3.32])
        _heading(doc,'Raiz comum no caso '+str(case.get('id')),2)
        root=case.get('root') or (r.get('root') if case.get('id')=='actual' else {}) or {}
        _tab(doc,['Ação, referência ou testemunho','Valor canônico'],list(_flatten(root)),[3.65,3.32])
        inactive=case.get('inactive_path_families') or []
        if inactive:
            doc.add_paragraph('Famílias de ruptura geometricamente inativas: a borda livre não captura força positiva ou o bloco continua ligado à raiz apoiada. A ausência física não é uma verificação omitida.')
            _tab(doc,['Família inativa','Motivo geométrico'],[(str(x.get('id')),str(x.get('reason'))) for x in inactive],[2.0,4.97])
    _heading(doc,'Ações exportadas para a verificação do membro W',2)
    if r.get('member_actions'):
        _tab(doc,['Ação / referência','Valor canônico'],list(_flatten(r['member_actions'])),[3.65,3.32])
    doc.add_paragraph('Nnormal é a variação de cortante transversal introduzida no membro. Vparalelo é o cisalhamento longitudinal da interface; são grandezas distintas. A mudança da face da mesa ao centroide do W acrescenta o momento do braço d/2 de Vparalelo. Verificar o membro com suas ações concorrentes reais; não presumir que elas sejam nulas.')


def _envelopes(doc,r):
    _heading(doc,'Envelopes por componente e mecanismo físico')
    envelopes=physical_envelopes(r)
    if not envelopes:
        doc.add_paragraph('Não há verificações locais completas nesta avaliação.')
        return
    doc.add_paragraph('Uma linha por componente, face física e mecanismo. As verificações de cada L usam N/2; os elementos comuns usam N total. As solicitações e resistências não são somadas entre partes em série. η real usa a combinação real; η adotado inclui os casos suplementares. Os caminhos e limites conservadores permanecem rastreáveis, sem multiplicar linhas de conclusão.')
    _tab(doc,['Componente / mecanismo','η real','η adotado','Estado'],
         [(e['component_label']+'\n'+e['mechanism_label'],_n(e['actual_utilization']),_n(e['utilization']),e['status'])
          for e in envelopes],[4.12,.85,.95,1.05])
    for e in envelopes:
        p=doc.add_paragraph()
        p.add_run(e['component_label']+' · '+e['mechanism_label']+': ').bold=True
        p.add_run('; '.join(str(x.get('id'))+' ['+str(x.get('case_id'))+']: Sd='+_n(x.get('demand'),6)+
                           ', Rd='+_n(x.get('resistance'),6)+' '+str(x.get('unit','')) for x in e['governing']))
        for run in p.runs: run.font.size=Pt(8)
    doc.add_paragraph('Falha em um limite inferior conservador é uma reprovação na triagem do método; não demonstra um caminho exato de fissura. Ausência de falha local não aprova a estrutura completa nem libera fabricação.')


def _method(doc,c,r):
    _heading(doc,'Modelo, equações e limites físicos')
    angle = selected_angle(c, r)
    transfer = angle_transfer(angle)
    if angle:
        doc.add_paragraph('Duas cantoneiras idênticas '+angle_identity(angle)+' formam a seção oposta pelos vértices (><). Cada aba conectada encosta diretamente em uma face da mesma chapa; os talões têm afastamento h=tg e as abas conectadas apontam para sentidos opostos. São quatro linhas projetadas distintas. As raízes dos filetes estão separadas pela aba b='+_value(angle['leg'])+' mm. Espessura nominal t='+_value(angle['t'])+' mm; Ag de catálogo por L='+_value(angle['Ag'])+' mm²; centroide ec='+_value(angle['centroid'])+' mm das faces externas. '+angle_detail_disclosure(angle))
    doc.add_paragraph('A ligação por uma aba usa a idealização estática da NBR 6.1.8.2, sem eliminar shear lag, a excentricidade no plano ou o momento da raiz. Dimensões geométricas não selecionam nem certificam o aço.')
    _math(doc,group('Ftalão,face = (1 − ',frac('ec','b'),') ',frac('N','2'),';   Fponta,face = ',frac('ec','b'),' ',frac('N','2'),';   vpar = 0;   vface = ±(tg/2 + ec)'))
    if transfer:
        doc.add_paragraph('Para a seção selecionada: Fcalcanhar='+_n(transfer['heel'],9)+' (N/2); Fponta='+_n(transfer['toe'],9)+' (N/2), em cada face; v='+_value(transfer['projected_centroid'])+' mm.')
    _math(doc,group('Ct = max[1 − ',frac('ec','L'),'; ',frac('Ac','Ag'),'];   ',frac('Ac','Ag'),' = 0,5'))
    _math(doc,group('NRd,y por L = ',frac('Ag fy','γa1'),';   NRd,u por L = ',frac('Ct An fu','γa2'),';   NRd,par = 2 NRd por L'))
    doc.add_paragraph('Ag e An pertencem a uma L, com An=Ag. O shear lag usa o ec catalogado de cada L, nunca ec=0 pela simetria do conjunto. Ct e Ae são calculados por L; o par tem Ag,par=2Ag e Ae,par=2CtAg. A NBR6.1.8.2/6.5.2 é aplicada individualmente a cada L: binários locais superfície–plano médio são idealizados fora do modelo, não declarados cancelados nem verificados como tensões tridimensionais. Mraiz permanece.')
    _math(doc,group('Nraiz = N sen θ;   Vraiz = N cos θ;   Mraiz = Ps Nraiz − Pn Vraiz'))
    doc.add_paragraph('A linha de força é a do centroide físico projetado da seção selecionada. Mover o ponto P ao longo dessa mesma linha não altera Mraiz. As solicitações N,V,M permanecem concorrentes; os valores atuais e suas referências constam dos casos desta memória.')
    _math(doc,group('a = ',frac('s',radical('2')),';   Rw = a L ',frac('0,60 fw','γw2')))
    _math(doc,group('qnormal(s) = ',frac('Nraiz','B'),' + ',frac('12 Mraiz s',power('B','3')),
                    ';   qparalelo = ',frac('Vraiz','B')))
    _math(doc,group('qprojeto = max(qpico; 1,25 qmédio dos extremos);   τw = ',
                    frac('qprojeto','2 a')))
    doc.add_paragraph('O critério de pico/média é a adaptação explícita do AISC DG29 ao grupo elástico da raiz, com os fatores NBR separados. Dois filetes não duplicam a área da chapa: A=B·t. Não se credita aumento direcional de resistência do filete.')
    _math(doc,group('σ = ',frac('N','A'),' ± ',frac('M','S'),';   σeq = ',
                    radical(group(power('σ'),' + 3 ',power('τ'))),' ≤ ',frac('fy','γa1')))
    doc.add_paragraph('O campo de seções horizontais usa transferência uniforme nas quatro linhas projetadas distintas, capturando suas forças e posições reais. As quatro soldas físicas são verificadas separadamente com suas frações de N total. São verificados limites dos intervalos e extremos estacionários internos; não se trata de uma solução exata de tensão contínua. A seção local de introdução usa a largura física informada, é centrada no par e participa do envelope de escoamento/ruptura. Acrescenta-se triagem conservadora por face: N/2 em largura local × t/2, Mface=(N/2)·[tg/2+ec], mantendo o menor Ct calculado com a espessura inteira. As duas espessuras alocadas somam uma chapa.')
    doc.add_paragraph('A triagem de ruptura da faixa local adapta a NBR 5.2.5(d); não afirma que as soldas reais estejam nas bordas dessa faixa. Ct=1 da chapa inteira se refere ao único elemento plano conectado, sem apagar a concentração local, o contato de solda e os caminhos de ruptura. A expansão local deve permanecer no domínio geométrico efetivamente aceito pelo motor.')
    _math(doc,group('Rbloco = min[',frac('0,60 fu Anv + Cts fu Ant','γa2'),'; ',
                    frac('0,60 fy Agv + Cts fu Ant','γa2'),'];   Cts = 0,5'))
    doc.add_paragraph('Sem furos: Agv=Anv e áreas brutas/líquidas transversais iguais. γa2=1,35 aplica-se aos dois ramos da expressão de bloco, inclusive ao ramo com escoamento por cisalhamento. γa1=1,10 e γw2=1,35 para combinação normal. Caminhos parciais de canto cruzam soldas ativas: a demanda é apenas a parcela transferida, e a resistência do metal de solda cruzado é omitida conservadoramente.')
    doc.add_paragraph('A quantidade de famílias de ruptura ativas depende das interseções reais com as bordas livres; famílias fisicamente inativas e suas estações são identificadas separadamente, sem inventar uma borda livre na raiz apoiada. Os limites inferiores conservadores não representam caminhos exatos de fissura. Verificações separadas da superfície de contato dos filetes cobrem o limite junto à fusão.')
    if angle and angle.get('toe_flat') is not None:
        doc.add_paragraph('No detalhe da cantoneira selecionada, a face plana da ponta e sua espessura limite são '+_value(angle['toe_flat'])+' mm. Cada cantoneira tem demanda N/2. O limite inferior por cantoneira usa uma única superfície de cisalhamento de comprimento L, sem contribuição transversal; os caminhos arredondados permanecem vinculados à geometria publicada.')
    elif angle:
        doc.add_paragraph('Para a cantoneira com raios e face plana não publicados, o contorno é apenas nominal esquemático. O envelope conservador da cantoneira usa Agv=Anv=t·L, Ant=0 e a força N/2 por L. Não se inventam caminhos arredondados ou espessura plana da ponta. O contato de fusão é limitado por min(s,t)·L, com a perna inscrita s da solda de filete; o limite usa apenas dimensões nominais publicadas.')
    doc.add_paragraph('O gusset é uma chapa única: cada polígono destacado captura todas as linhas reais contidas, inclusive em sobreposições de footprints. Enumeram-se subconjuntos U contíguos e caminhos L nas estações de solda e cantos; contato positivo com a raiz torna o bloco inativo. Não se somam capacidades de caminhos alternativos nem se transformam os dois filetes da raiz em quatro.')
    _math(doc,group('δg = min(tgusset; 2 sraiz);   δW = 2 sraiz;   σ = ',frac('qn,máx','δ'),';   τ = ',frac('|qs|','δ')))
    _math(doc,group('ηcontato = max[',frac(radical(group(power('σ'),' + 3 ',power('τ'))),'fy/γa1'),'; ',frac('σ','fu/γa2'),'; ',frac('τ','0,60 fu/γa2'),']'))
    doc.add_paragraph('No metal base da raiz, qn,máx e |qs| mantêm suas componentes normal e tangencial; qprojeto não é convertido em cisalhamento puro. No puncionamento da mesa W usa-se qpico/(2tf); o fator 1,25 da média dos módulos extremos pertence apenas à solda. O equivalente elástico N+6|M|/B não é o equivalente plástico N+4|M|/B.')
    doc.add_paragraph('No W, a raiz é longitudinal e centrada na alma, sobre a mesa exterior. A verificação inclui contato local, puncionamento da mesa, escoamento normal da alma, cisalhamento longitudinal da alma e interação local. A isenção de flexão local da mesa pela largura carregada menor que 0,15 bf só vale quando essa condição efetivamente atende. Tração normal em todo o domínio é condição do método; compressão, instabilidade local e alma diretamente carregada exigem outro modelo.')


def _station_witnesses(doc, family):
    records=family.get('station_records') or []
    if records:
        _tab(doc,['u do corte (mm)','Borda transversal','Força capturada (N)','Contato na raiz (mm)','Situação'],
             [(_n(x.get('u_cut'),6),str(x.get('transverse_edge')),_n(x.get('captured_force'),6),
               _n(x.get('supported_root_contact_length'),6),str(x.get('status'))) for x in records],
             [1.07,1.2,1.37,1.25,2.08],7.5)
    candidates=family.get('station_candidates') or []
    if candidates:
        _tab(doc,['u do corte (mm)','Agv=Anv (mm²)','Agt=Ant (mm²)','Sd (N)','Rd (N)','η'],
             [(_n(x.get('cut_u'),6),_n(x.get('Agv'),6),_n(x.get('Ant'),6),_n(x.get('demand'),6),
               _n(x.get('resistance'),6),_n(x.get('utilization'),7)) for x in candidates],
             [.92,1.25,1.25,1.3,1.3,.95],7.5)
        for x in candidates:
            p=doc.add_paragraph('u='+_value(x.get('cut_u'))+' mm: '+
                 'ramo ruptura='+_value(x.get('rupture_branch_N'))+' N; ramo escoamento='+_value(x.get('yield_branch_N'))+
                 ' N; fração capturada='+_value(x.get('partial_fraction'))+'; borda transversal='+str(x.get('transverse_free_edge'))+
                 '; borda à frente='+str(x.get('forward_free_edge'))+'; coordenadas (s;n) em mm: '+ '; '.join('('+_n(point[0],6)+'; '+_n(point[1],6)+')' for point in x.get('path_xy_mm',[]))+'.')
            for run in p.runs:run.font.size=Pt(7.5)


def _details(doc,r):
    _heading(doc,'Detalhamento dos caminhos e seções por caso')
    for case in r.get('cases') or []:
        case_id=str(case.get('id'))
        _heading(doc,'Primitivas de ruptura · '+case_id,2)
        paths=case.get('paths') or []
        doc.add_paragraph(str(len(paths))+' famílias de caminhos ativas preservadas neste caso, incluindo os limites inferiores conservadores. Valores em N e mm, áreas em mm². Cada caminho registra sua estação de contorno e forças efetivamente capturadas. Os limites inferiores conservadores não representam fissuras exatas.')
        _tab(doc,['Caminho e identificação','Demanda (N)','Resistência (N)','η'],
             [(str(x.get('name',x.get('label','')))+'\n'+str(x.get('id')),
               _n(x.get('demand'),6),_n(x.get('resistance'),6),_n(x.get('utilization'),7)) for x in paths],
             [3.15,1.25,1.42,1.15],7.5)
        for path in paths:
            p=doc.add_paragraph();p.add_run(str(path.get('id'))+': ').bold=True
            # Preserve every exact area, branch and physical boundary witness.
            witness={k:v for k,v in path.items() if k not in ('id','name','label','case_id','demand','resistance','utilization','status','station_candidates','station_records')}
            p.add_run(_value(witness))
            for run in p.runs:run.font.size=Pt(8)
            _station_witnesses(doc,path)
        inactive=case.get('inactive_path_families') or []
        if inactive:
            _heading(doc,'Famílias geometricamente inativas · '+case_id,2)
            for family in inactive:
                doc.add_paragraph(str(family.get('id'))+': '+str(family.get('reason')))
                _station_witnesses(doc,family)
        sections=case.get('plate_sections') or case.get('sections') or {}
        if sections:
            _heading(doc,'Seções e extremos estacionários · '+case_id,2)
            doc.add_paragraph('Cada linha preserva um corte de contorno ou extremo estacionário do motor. Cortes coincidentes de intervalos vizinhos são mantidos, sem apagar seus testemunhos.')
            _tab(doc,['n (mm)','Borda / tipo','σ (MPa)','N (kN)','V (kN)','M (kN m)'],
                 [(_n(x.get('y'),6),str(x.get('edge'))+' / '+str(x.get('kind')),_n(x.get('sigma_MPa'),7),
                   _n(x.get('N'),6,1000),_n(x.get('V'),6,1000),_n(x.get('M'),6,1e6)) for x in sections.get('cuts',[])],
                 [1.05,1.65,1.07,1.0,1.0,1.2],7.5)
            _tab(doc,['Intervalo n (mm)','|σ|max (MPa)','|τ|max (MPa)','σeq envelope (MPa)'],
                 [(_n(x.get('y_start'),6)+' a '+_n(x.get('y_end'),6),_n(x.get('sigma_abs_max'),7),
                   _n(x.get('tau_abs_max'),7),_n(x.get('von_mises_envelope'),7)) for x in sections.get('intervals',[])],
                 [2.27,1.5,1.5,1.7],7.5)
            for index,x in enumerate(sections.get('intervals',[])):
                p=doc.add_paragraph('Intervalo '+str(index+1)+': coeficientes em potências crescentes de n. '+
                                    '; '.join(key+'='+_value(x.get(key)) for key in ('N_coeff','V_coeff','M_coeff')))
                for run in p.runs:run.font.size=Pt(7.5)
            _tab(doc,['Seção local / limite do campo','Valor'],list(_flatten({k:v for k,v in sections.items() if k not in ('cuts','intervals')})),[3.65,3.32],7.5)
    _heading(doc,'Verificações consolidadas e testemunhos completos')
    for row in r.get('checks') or []:
        _heading(doc,str(row.get('label',row.get('id')))+' · '+str(row.get('case_id')),2)
        _tab(doc,['ID','Solicitação','Resistência','Unidade','η','Estado'],
             [(str(row.get('id')),_n(row.get('demand'),8),_n(row.get('resistance'),8),str(row.get('unit','')),
               _n(row.get('utilization'),8),str(row.get('status')))], [2.1,1.2,1.2,.6,1.0,.87],7.5)
        if row.get('formula'):doc.add_paragraph('Expressão: '+str(row['formula']))
        if row.get('reference'):doc.add_paragraph('Referência: '+str(row['reference']))
        details={k:v for k,v in row.items() if k not in ('id','label','component','mechanism','case_id','demand','resistance','unit','utilization','status','formula','reference')}
        if row.get('mechanism') == 'block_tearout':
            witness=row.get('details') or {}
            governed=witness.get('governing') or {}
            details={'governing_path_id':governed.get('id'),
                     'path_ids':[x.get('id') for x in witness.get('candidates',[])],
                     'full_witnesses':'Áreas, ramos resistentes e coordenadas integralmente registrados nas primitivas deste caso.'}
        elif isinstance(details.get('details'),dict) and 'candidates' in details['details']:
            witness=details['details'];candidates=witness['candidates']
            _tab(doc,['Ramo preservado','Sd','Rd','Unidade','η'],
                 [(str(x.get('name',x.get('id'))),_n(x.get('demand'),7),_n(x.get('resistance'),7),str(x.get('unit',row.get('unit',''))),
                   _n(x['demand']/x['resistance'],7)) for x in candidates],[2.8,1.12,1.12,.75,1.18],7.5)
            for x in candidates:
                extra={k:v for k,v in x.items() if k not in ('name','id','demand','resistance','unit')}
                if extra:
                    p=doc.add_paragraph(str(x.get('name',x.get('id')))+': '+_value(extra))
                    for run in p.runs:run.font.size=Pt(8)
            details={k:v for k,v in details.items() if k != 'details'}
            details['governing_branch']=witness.get('governing',{}).get('name')
            details.update({k:v for k,v in witness.items() if k not in ('candidates','governing')})
        # Paths already appear in full above. Avoid duplicating their complete
        # geometry once more within the consolidated envelope witness.
        def without_paths(value):
            if isinstance(value,dict):return {k: ('Registrados integralmente na seção de primitivas deste caso' if k in ('paths','all_paths') else without_paths(v)) for k,v in value.items()}
            if isinstance(value,list):return [without_paths(v) for v in value]
            return value
        _tab(doc,['Testemunho','Valor'],list(_flatten(without_paths(details))),[3.65,3.32],7.5)


def create_report(c,result=None,detailed=False):
    r=validated_result(c,result)
    angle=selected_angle(c,r)
    transfer=angle_transfer(angle)
    doc=Document();sec=doc.sections[0]
    sec.page_width=Inches(8.27);sec.page_height=Inches(11.69)
    sec.top_margin=sec.bottom_margin=Inches(.55);sec.left_margin=sec.right_margin=Inches(.65)
    normal=doc.styles['Normal'];normal.font.name='Calibri';normal.font.size=Pt(9.5)
    normal.paragraph_format.space_after=Pt(5)
    for name,size in (('Title',21),('Subtitle',11),('Heading 1',13),('Heading 2',10.5)):
        style=doc.styles[name];style.font.name='Calibri';style.font.size=Pt(size)
        style.font.color.rgb=RGBColor(0,0,0);style.font.underline=False
        style.paragraph_format.space_before=Pt(10 if name=='Heading 1' else 5)
        style.paragraph_format.space_after=Pt(4)
        style.paragraph_format.keep_with_next=True
        for border in list(style.element.iter(qn('w:pBdr'))):border.getparent().remove(border)
    doc.add_paragraph('Duas cantoneiras opostas soldadas ao gusset e à mesa W',style='Title')
    doc.add_paragraph('Memória de cálculo local '+('detalhada' if detailed else 'resumida'),style='Subtitle')
    doc.add_paragraph('Projeto: '+str(c.project))
    p=doc.add_paragraph();p.add_run(STATUS.get(r.get('status'),str(r.get('status')))).bold=True
    doc.add_paragraph('Estado canônico: '+str(r.get('status'))+'. Versão '+COMPONENT_VERSION+'.')
    doc.add_paragraph('Entradas SHA-256: '+input_fingerprint(c))
    doc.add_paragraph('Domínio: 2L opostas pelos vértices, duas cantoneiras idênticas '+angle_identity(angle,c.angle_profile)+', uma por face da mesma chapa retangular, h=tg derivado e abas conectadas em sentidos opostos. Quatro soldas longitudinais das L, dois filetes na única raiz sobre a mesa exterior de W laminado do catálogo identificado, longitudinal e centrada na alma. Tração estática no plano. A análise local preserva momento da raiz, materiais independentes e caminhos de ruptura.')
    doc.add_paragraph('Esta memória não aprova o membro ou sistema estrutural completo e não libera fabricação. O apoio deve ser verificado com suas ações concorrentes reais. Geometria, especificação de materiais, soldagem e inspeção devem ser confirmadas pelo responsável técnico.')
    _tab(doc,['Resumo','Resultado'],[
        ('Verificações locais completas','sim' if r.get('summary',{}).get('complete_checks') is True else 'não'),
        ('Atendimento local declarado pelo motor','sim' if r.get('global_pass') is True else 'não'),
        ('Maior utilização adotada',_n(r.get('summary',{}).get('utilization'),7)),
        ('Casos preservados',str(len(r.get('cases') or []))),
        ('Verificações físicas consolidadas',str(len(r.get('checks') or []))),
    ],[4.27,2.7])
    for fabrication_note in (r.get('geometry') or {}).get('fabrication_notes', []):
        note = str(fabrication_note)
        both_faces = 'Executar e inspecionar nas duas cantoneiras, faces +z e −z.'
        if 'Executar e inspecionar nas duas cantoneiras e nas duas faces.' in note:
            note = note.replace('Executar e inspecionar nas duas cantoneiras e nas duas faces.', both_faces)
        else:
            note += ' ' + both_faces
        doc.add_paragraph(note).runs[0].bold=True
    _issues(doc,r);_envelopes(doc,r)
    doc.add_page_break();_heading(doc,'Desenho proporcional da entrada atual')
    p=doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    p.add_run().add_picture(BytesIO(image_bytes(c,fmt='png')),width=Inches(6.97))
    doc.add_paragraph('Mesma entrada e mesmo ponto da linha de força usados no cálculo. A vista em planta mostra quatro linhas distintas em projeção; cada L recebe N/2, repartido por ec/b. O corte >< mostra duas L giradas180°, uma chapa central e quatro filetes longitudinais. O corte W mostra os dois filetes da raiz e o alinhamento longitudinal sobre a alma W. Raios publicados são representados quando disponíveis; cantos sem dados ficam interrompidos no esquema nominal, sem geometria presumida.')
    doc.add_page_break();_inputs(doc,c,r);_cases(doc,r);_method(doc,c,r)
    if detailed:_details(doc,r)
    _heading(doc,'Referências e limitações')
    doc.add_paragraph('ABNT NBR 8800:2024 / Errata 1:2025: 5.2.2 e 5.2.5, tração e shear lag; 5.7.2 e 5.7.3, mesa e alma receptoras; 6.1.5, ações mínimas; 6.1.8.2, ligação estática por uma aba; 6.2, soldas de filete e detalhamento; 6.5.3, 6.5.5 e 6.5.6, estados limites do metal conectado e cisalhamento em bloco.')
    doc.add_paragraph('AISC Design Guide 29 (2014), seção 4.2.4, pp. 32–33 e Figura 4-16; Exemplo 5.4, pp. 105–108: força axial P decomposta em H/V e momento local Mb devido à diferença entre a linha real e a ideal. Ligação de chapa à mesa, resultantes na interface e seções internas, pp. 54–59, 196–204. Critérios de seção e distribuição são idealizações identificadas; fatores NBR são aplicados separadamente. Souza, exemplo 9.6, transferência equilibrada em cantoneira soldada; não é aprovação isolada da chapa ou do apoio.')
    doc.add_paragraph('Catálogo da cantoneira selecionada: '+angle_identity(angle,c.angle_profile)+'; '+str((angle or {}).get('source','não disponível'))+'. Catálogo do W selecionado: '+str((r.get('geometry',{}).get('support_catalog') or {}).get('source','não disponível'))+'. As propriedades geométricas não substituem certificação de materiais.')
    exclusions=r.get('exclusions') or []
    if isinstance(exclusions,str):exclusions=[exclusions]
    for item in exclusions:doc.add_paragraph(_value(item),style='List Bullet')
    doc.add_paragraph('Fora desta rota: compressão da cantoneira/chapa, fadiga, qualificação sísmica, ações espaciais externas, apoio direto na alma W, raiz deslocada lateralmente, chapa arbitrária, interface parafusada ou mista, assimetria, enchimentos e afastadores. A disposição oposta parafusada tem qualificação separada e não pertence a este arquivo. Uma condição fora do domínio não implica automaticamente necessidade de análise por elementos finitos; exige um método correspondente ao caso real.')
    _heading(doc,'Conclusão')
    doc.add_paragraph('As verificações locais implementadas atendem no domínio declarado pelo motor.' if r.get('global_pass') is True else 'A entrada atual permanece sem conclusão favorável completa. Resolver as falhas ou condições fora do domínio registradas antes de utilizá-la como verificação local.')
    closing=doc.add_paragraph('A conclusão não abrange a resistência global do W carregado, estabilidade global da diagonal composta e do sistema, travamentos ou emendas intermediárias do par, montagem ou liberação de fabricação. ')
    closing.add_run(BRAND).font.size=Pt(7)
    doc.core_properties.title=FAMILY;doc.core_properties.subject='Memória local '+COMPONENT_VERSION
    out=BytesIO();doc.save(out);return out.getvalue()
