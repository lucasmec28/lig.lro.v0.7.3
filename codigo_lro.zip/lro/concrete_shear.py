"""Bounded complementary ACI 318-19 cast-in anchorage components.

Public units N/mm/MPa. Pure kernels; no UI and no complete-connection approval.
Source: DG1 3rd ed pp.34-37, 76-78, 101-102; ACI 17.7/17.8.
"""
import math
from .concrete_anchorage import breakout_group

INCH=25.4
LBF=4.4482216152605
PSI=0.006894757293168361
SOURCE='ACI 318-19, 17.7 e 17.8; AISC DG1 3ª ed. · base complementar'


def _number(value, name, positive=False, nonnegative=False):
    if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value):
        raise ValueError(f'{name}: informe número real finito.')
    if positive and value<=0 or nonnegative and value<0:
        raise ValueError(f'{name}: valor fora do domínio físico.')
    return float(value)


def _bounds(bounds):
    if not isinstance(bounds,(tuple,list)) or len(bounds)!=4:
        raise ValueError('Limites reais do concreto: xmin, ymin, xmax, ymax.')
    b=tuple(_number(x,'Borda') for x in bounds)
    if b[0]>=b[2] or b[1]>=b[3]:raise ValueError('Limites reais inconsistentes.')
    return b


def _anchors(anchors,bounds,field):
    if not isinstance(anchors,(list,tuple)) or not anchors:raise ValueError('Grupo de chumbadores vazio.')
    if len(anchors)>4:raise ValueError('Submodelo limitado a até quatro chumbadores.')
    b=_bounds(bounds); out=[];ids=set();coords=set()
    for a in anchors:
        if not isinstance(a,dict):raise ValueError('Cada barra deve conter identificador, coordenadas e força.')
        aid=a.get('id')
        if not isinstance(aid,str) or not aid.strip() or aid in ids:raise ValueError('Identificadores de barras únicos são obrigatórios.')
        x=_number(a.get('x'),'x');y=_number(a.get('y'),'y')
        q=_number(a.get(field),field,nonnegative=True)
        if not b[0]<x<b[2] or not b[1]<y<b[3]:raise ValueError('Centro de barra fora do concreto.')
        if (x,y) in coords:raise ValueError('Centros de barras coincidentes.')
        ids.add(aid);coords.add((x,y));out.append(dict(a,id=aid,x=x,y=y,**{field:q}))
    return out,b


def _check(id,label,ids,demand,resistance,nominal,phi,method,**extra):
    d=_number(demand,'Solicitação',nonnegative=True);r=_number(resistance,'Resistência',positive=True)
    if not math.isfinite(nominal) or nominal<=0:raise ValueError('Resistência nominal inválida.')
    return dict(id=id,label=label,ids=list(ids),demand=d,resistance=r,ratio=d/r,
                nominal=nominal,phi=phi,method=method,**extra)


def shear_breakout_row(*,ca1,positions,edge_min,edge_max,member_depth,hef,diameter,fc,
                       forces=None,ids=None,parallel=False):
    """One collinear edge row. Splits disconnected projections, no pooled capacity.

    ca1 and positions are physical mm coordinates in local normal/tangent axes.
    forces are explicit nonnegative simultaneous N loads for THIS mechanism.
    parallel is ACI's virtual-perpendicular edge construction, not zero demand.
    """
    ca1=_number(ca1,'ca1',positive=True);ha=_number(member_depth,'h',positive=True)
    h=_number(hef,'hef',positive=True);da=_number(diameter,'db',positive=True)
    fc=_number(fc,'fck',positive=True)
    if da>4*INCH or fc>10000*PSI:raise ValueError('Diâmetro/concreto fora do domínio ACI.')
    if h>=ha:raise ValueError('Embutimento deve ser menor que a espessura estrutural.')
    lo=_number(edge_min,'Limite transversal');hi=_number(edge_max,'Limite transversal')
    if lo>=hi:raise ValueError('Bordas transversais inconsistentes.')
    if not isinstance(parallel,bool):raise ValueError('Orientação paralela deve ser booleana.')
    if not isinstance(positions,(tuple,list)) or not 1<=len(positions)<=2:raise ValueError('Linha limitada a uma ou duas barras.')
    pos=[_number(v,'Posição') for v in positions]
    if len(set(pos))!=len(pos) or any(not lo<v<hi for v in pos):raise ValueError('Posições coincidentes ou externas.')
    capacity_only=forces is None
    if forces is None:forces=[1.]*len(pos) # capacity-only diagnostic, explicitly identified
    if len(forces)!=len(pos):raise ValueError('Forças não correspondem às barras.')
    force=[_number(v,'Cortante da barra',nonnegative=True) for v in forces]
    if ids is None:ids=[f'R{i+1}' for i in range(len(pos))]
    if len(ids)!=len(pos) or len(set(ids))!=len(ids):raise ValueError('IDs não correspondem à linha.')
    order=sorted(range(len(pos)),key=lambda i:pos[i]);pos=[pos[i] for i in order]
    force=[force[i] for i in order];ids=[ids[i] for i in order]
    if sum(force)==0:return dict(status='not_demanded',checks=[],reasons=[])
    active=[i for i,v in enumerate(force) if v>0]
    if len(active)<len(pos):
        return shear_breakout_row(ca1=ca1,positions=[pos[i] for i in active],edge_min=lo,edge_max=hi,
              member_depth=ha,hef=h,diameter=da,fc=fc,forces=[force[i] for i in active],
              ids=[ids[i] for i in active],parallel=parallel)
    left=pos[0]-lo;right=hi-pos[-1];spacing=pos[-1]-pos[0]
    narrow=left<1.5*ca1 and right<1.5*ca1 and ha<1.5*ca1
    c=min(ca1,max(left/1.5,right/1.5,ha/1.5,spacing/3)) if narrow else ca1
    if len(pos)==2 and spacing>3*c:
        checks=[]
        for i in range(2):
            result=shear_breakout_row(ca1=ca1,positions=[pos[i]],edge_min=lo,edge_max=hi,
                   member_depth=ha,hef=h,diameter=da,fc=fc,forces=[force[i]],ids=[ids[i]],parallel=parallel)
            checks.extend(result['checks'])
        return dict(status='calculated',checks=checks,reasons=[],disconnected=True,
                    capacity_only=capacity_only,source=SOURCE)
    reach=1.5*c;depth=min(reach,ha)
    width=min(reach,left)+spacing+min(reach,right)
    area=width*depth;area0=4.5*c*c
    le=min(h,8*da);ci=c/INCH;di=da/INCH;li=le/INCH;fi=fc/PSI
    vb1=7*(li/di)**.2*math.sqrt(di)*math.sqrt(fi)*ci**1.5*LBF
    vb2=9*math.sqrt(fi)*ci**1.5*LBF;vb=min(vb1,vb2)
    demand=sum(force);centroid=sum(pos)/len(pos);resultant=sum(p*q for p,q in zip(pos,force))/demand
    eccentricity=abs(resultant-centroid)
    pec=1/(1+eccentricity/reach) if len(pos)>1 else 1.
    ped=1. if parallel else min(1.,.7+.3*min(left,right)/reach)
    ph=max(1.,math.sqrt(reach/ha));parallel_factor=2. if parallel else 1.
    nominal=area/area0*pec*ped*ph*parallel_factor*vb
    ck=_check('shear_edge_'+'_'.join(ids),'Ruptura do concreto ao cortante',ids,demand,.7*nominal,
        nominal,.7,'ACI 17.7.2.1(c)' if parallel else 'ACI 17.7.2.1(a/b)',
        ca1_physical=ca1,ca1_calc=c,narrow=narrow,side_clearances=(left,right),spacing=spacing,
        projected_width=width,projected_depth=depth,area=area,area0=area0,le=le,
        vb1=vb1,vb2=vb2,vb=vb,psi_ec=pec,psi_ed=ped,psi_c=1.,psi_h=ph,
        parallel_factor=parallel_factor,eccentricity=eccentricity,forces=force)
    return dict(status='calculated',checks=[ck],reasons=[],disconnected=False,
                capacity_only=capacity_only,source=SOURCE)


def evaluate_pryout(anchors,bounds,hef,fc):
    """anchors contain explicit nonnegative `shear`; tension values are irrelevant."""
    try:
        rods,b=_anchors(anchors,bounds,'shear');h=_number(hef,'hef',positive=True);f=_number(fc,'fck',positive=True)
        if f>10000*PSI:raise ValueError('Concreto fora do domínio ACI cast-in.')
        xs={a['x'] for a in rods};ys={a['y'] for a in rods}
        if len(rods)>2 and not (len(rods)==4 and len(xs)==2 and len(ys)==2):
            raise ValueError('Pryout nativo limitado a linha ou grupo retangular 2×2.')
        if len(rods)==2 and len(xs)>1 and len(ys)>1:
            raise ValueError('Duas barras devem formar uma linha paralela às bordas.')
        active=[dict(id=a['id'],x=a['x'],y=a['y'],tension=a['shear']) for a in rods if a['shear']>0]
        if not active:return dict(status='not_demanded',checks=[],reasons=[],source=SOURCE)
        ax={a['x'] for a in active};ay={a['y'] for a in active}
        if len(active)==3 or len(active)==2 and len(ax)>1 and len(ay)>1:
            raise ValueError('Grupo ativo irregular de pryout fora da rota de uma linha ou 2×2.')
        checks=[];kcp=1. if h<2.5*INCH else 2.
        def component(group):
            g=breakout_group(group,b,h,f)
            if not g['connected']:
                for indices in g['components']:component([group[i] for i in indices])
                return
            nominal=kcp*g['nominal']
            checks.append(_check('pryout_'+'_'.join(g['ids']),'Pryout do concreto',g['ids'],g['demand'],
                .7*nominal,nominal,.7,'ACI 17.7.3',kcp=kcp,hef_physical=h,hcalc=g['hcalc'],
                area=g['area'],area0=g['area0'],nb=g['nb'],ncp=g['nominal'],psi_ec=g['psi_ec'],
                psi_ed=g['psi_ed'],cone_geometry=g))
        component(active)
        return dict(status='calculated',checks=checks,reasons=[],source=SOURCE)
    except (ValueError,TypeError,KeyError,OverflowError,ZeroDivisionError) as exc:
        return dict(status='pending',checks=[],reasons=[str(exc)],source=SOURCE)


def aci_steel(*,tension,shear,area_tension,area_shear,fy,fu,ductile=False,grout=True,
              ductility_ref='',id='anchor'):
    """One anchor. ACI factors kept separate from the existing NBR steel path."""
    t=_number(tension,'Tração',nonnegative=True);v=_number(shear,'Cortante',nonnegative=True)
    at=_number(area_tension,'Ase,N',positive=True)
    av=None if area_shear is None and v==0 else _number(area_shear,'Ase,V',positive=True)
    fy=_number(fy,'fy',positive=True);fu=_number(fu,'fu',positive=True)
    if fy>fu:raise ValueError('fy não pode superar fu.')
    if not isinstance(ductile,bool) or not isinstance(grout,bool):raise ValueError('Ductilidade e graute: valores booleanos.')
    if ductile and not isinstance(ductility_ref,str) or ductile and not ductility_ref.strip():
        raise ValueError('Ductilidade ACI exige referência; use fatores frágeis quando não comprovada.')
    eff=min(fu,1.9*fy,125000*PSI);phin=.75 if ductile else .65;phiv=.65 if ductile else .60
    nominaln=at*eff
    checks=[_check('aci_tension_'+id,'Aço em tração — ACI',[id],t,phin*nominaln,nominaln,phin,'ACI 17.6.1')]
    if av is not None:
        nominalv=.6*av*eff*(.8 if grout else 1.)
        checks.append(_check('aci_shear_'+id,'Aço em cortante — ACI',[id],v,phiv*nominalv,nominalv,phiv,'ACI 17.7.1'))
    return dict(status='calculated',checks=checks,reasons=[],futa=eff,ductile=ductile,
                grout_factor=.8 if grout else 1.,source=SOURCE)


def interaction(tension_checks,shear_checks,*,complete=False,pending_reasons=None):
    """Use matching individual/group ratios, never unrelated minimum capacities.

    complete must be true only after every applicable ACI mode and prerequisite
    is computed/not demanded/not applicable. A partial screen cannot pass.
    """
    if not isinstance(complete,bool):raise ValueError('Completude deve ser explícita.')
    def ratios(checks):
        result=[]
        for check in checks:
            d=_number(check.get('demand'),'Solicitação',nonnegative=True)
            r=_number(check.get('resistance'),'Resistência',positive=True)
            result.append(d/r)
        return result
    ns=ratios(tension_checks);vs=ratios(shear_checks);bn=max(ns,default=0.);bv=max(vs,default=0.)
    required=bn>.2 and bv>.2;value=max(bn,bv,(bn+bv)/1.2 if required else 0.)
    reasons=list(pending_reasons or [])
    if not complete:reasons.append('Interação ACI completa depende de todos os modos aplicáveis, aço e concreto, e da distribuição de cortante verificada.')
    return dict(status='calculated' if complete and not reasons else 'pending',beta_N=bn,beta_V=bv,
                interaction_required=required,sum=bn+bv,ratio=value,
                passes=value<=1. if complete and not reasons else None,
                numerical_screen_passes=value<=1.,reasons=reasons,source=SOURCE)


def _regular_four(rods):
    xs=sorted({a['x'] for a in rods});ys=sorted({a['y'] for a in rods})
    if len(rods)!=4 or len(xs)!=2 or len(ys)!=2 or {(a['x'],a['y']) for a in rods}!={(x,y) for x in xs for y in ys}:
        raise ValueError('Rota de cortante limitada ao grupo retangular regular 2×2.')
    return xs,ys


def evaluate_shear(anchors,bounds,hef,fc,member_depth,diameter,shear,distribution):
    """Assemble source front/back cases for a qualified 2x2 group.

    distribution: {mode:'equal_four'|'near_row'|'documented', qualified:bool,
    reference:str, forces:{id:nonnegativeN} for documented,
    parallel_model:'virtual_perpendicular'|'pending', optional_envelope:bool}.
    Default parallel model is pending, so virtual force construction is explicit.
    No inferred V/4. No external app model or saved confirmation is mutated.
    """
    empty=lambda reason:dict(status='pending',checks=[],reasons=[reason],source=SOURCE,
                            breakout=dict(status='pending',checks=[],reasons=[reason]),
                            pryout=dict(status='pending',checks=[],reasons=[reason]))
    try:
        v=_number(shear,'V');rods,b=_anchors(anchors,bounds,'tension');xs,ys=_regular_four(rods)
        ha=_number(member_depth,'h',positive=True);h=_number(hef,'hef',positive=True)
        if h>=ha:raise ValueError('hef deve caber na espessura real do concreto.')
        _number(fc,'fck',positive=True);_number(diameter,'db',positive=True)
        if not isinstance(distribution,dict):raise ValueError('Defina a distribuição de cortante.')
        if v==0:return dict(status='not_demanded',checks=[],reasons=[],rods=[dict(a,shear=0.) for a in rods],
                            breakout=dict(status='not_demanded',checks=[],reasons=[]),
                            pryout=dict(status='not_demanded',checks=[],reasons=[]),source=SOURCE)
        if distribution.get('qualified') is not True or not isinstance(distribution.get('reference'),str) or not distribution['reference'].strip():
            raise ValueError('Distribuição de cortante sem qualificação física e referência do detalhe.')
        mode=distribution.get('mode');total=abs(v);nearx=max(xs) if v>0 else min(xs)
        if mode=='equal_four':q={a['id']:total/4 for a in rods}
        elif mode=='near_row':q={a['id']:total/2 if a['x']==nearx else 0. for a in rods}
        elif mode=='documented':
            forces=distribution.get('forces',{})
            if set(forces)!={a['id'] for a in rods}:raise ValueError('Distribuição deve identificar exatamente as quatro barras.')
            q={k:_number(val,'Vi',nonnegative=True) for k,val in forces.items()}
            if not math.isclose(sum(q.values()),total,rel_tol=1e-10,abs_tol=1e-8):raise ValueError('ΣVi deve ser |V| da combinação atual.')
            for x in xs:
                pair=[a for a in rods if a['x']==x]
                if not math.isclose(q[pair[0]['id']],q[pair[1]['id']],rel_tol=1e-10,abs_tol=1e-8):
                    raise ValueError('Cortante excêntrico/torção fora da rota simétrica; forças do par devem coincidir.')
        else:raise ValueError('Modelo de distribuição de cortante não reconhecido.')
        active=[dict(a,shear=q[a['id']]) for a in rods if q[a['id']]>0]
        checks=[];mechanisms=[];reasons=[]
        parallel_model=distribution.get('parallel_model','pending')
        if parallel_model not in ('pending','virtual_perpendicular'):raise ValueError('Modelo de borda paralela não reconhecido.')
        optional=distribution.get('optional_envelope',False)
        if not isinstance(optional,bool):raise ValueError('Envelope opcional deve ser booleano.')
        edges=[('right','x',b[2],1,False)] if v>0 else [('left','x',b[0],-1,False)]
        if parallel_model=='virtual_perpendicular':edges += [('bottom','y',b[1],-1,True),('top','y',b[3],1,True)]
        else:reasons.append('Bordas paralelas ao cortante exigem selecionar e qualificar a construção virtual perpendicular ACI 17.7.2.1(c).')
        for edge,normal,edgecoord,sign,parallel in edges:
            tangent='y' if normal=='x' else 'x'
            emin,emax=(b[1],b[3]) if normal=='x' else (b[0],b[2])
            rows=sorted({a[normal] for a in active},reverse=sign>0)
            cfront=abs(edgecoord-rows[0]);states=[]
            if len(rows)==1:
                states=[('single_row',rows[0],False)]
            else:
                spacing=abs(rows[1]-rows[0])
                states=[('case1',rows[0],False),('case2',rows[1],True)] if spacing>=cfront else [('case3',rows[0],True)]
            if optional:
                states += [('optional_envelope',r,True) for r in rows]
            for casename,r,accumulate in states:
                group=[a for a in active if a[normal]==r]
                forces=[sum(z['shear'] for z in active if z[tangent]==a[tangent]) if accumulate else a['shear'] for a in group]
                result=shear_breakout_row(ca1=abs(edgecoord-r),positions=[a[tangent] for a in group],
                    edge_min=emin,edge_max=emax,member_depth=ha,hef=h,diameter=diameter,fc=fc,
                    forces=forces,ids=[a['id'] for a in group],parallel=parallel)
                for ck in result['checks']:
                    ck=dict(ck,id=f'{edge}_{casename}_'+ck['id'],edge=edge,case=casename,
                            basis='optional_conservative_envelope' if casename=='optional_envelope' else 'source_row_method',
                            virtual_perpendicular=parallel)
                    checks.append(ck)
                mechanisms.append(dict(edge=edge,case=casename,ids=[a['id'] for a in group],forces=forces,
                                       demand=sum(forces),virtual_perpendicular=parallel))
        pryout=evaluate_pryout([dict(a,shear=q[a['id']]) for a in rods],b,h,fc)
        breakout=dict(status='calculated' if not reasons else 'pending',checks=checks,reasons=reasons,mechanisms=mechanisms)
        return dict(status='calculated' if not reasons and pryout['status']=='calculated' else 'pending',
            checks=checks+pryout['checks'],reasons=reasons+pryout['reasons'],
            breakout=breakout,pryout=pryout,rods=[dict(a,shear=q[a['id']]) for a in rods],
            distribution=dict(distribution),source=SOURCE,
            scope_note='Componentes complementares; distribuição física, cabeça/porca, aço/arruelas/placa e bloco armado permanecem requisitos próprios. Casos de ruptura são comparações alternativas, não ações simultâneas somadas.')
    except (ValueError,TypeError,KeyError,OverflowError,ZeroDivisionError) as exc:
        return empty(str(exc))
