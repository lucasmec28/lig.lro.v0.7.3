"""Memória de end plate: figuras, dados, referências, contas e premissas finais."""
from .display_precision import calculated_text
from .display_precision import display_format, display_value
from io import BytesIO
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from .models import STEELS,KGF,VERSION
from .package_identity import PACKAGE_ID as VERSION  # display only; native serializers remain frozen
from .end_plate import NBR,DG,SCI,evaluate,input_digest,method_revision,MOMENT_GROUPS
from .end_plate_drawing import image_bytes
from .end_plate_presentation import summary_lines,SCOPE_NOTICE
from .report import table,number,display,decimal_text,hyperlink,BRAND,LINK,_math,group,sub,frac,power,radical

REFERENCES=[NBR+' — 6.1.2.3, 6.1.5.2, 6.2, 6.3, 6.5 e 5.7; coeficientes γa1=1,10 e γa2=γw2=1,35.',
            DG+' — 3.2, 3.5, 3.7.5 (eq.3-38 a 3-41 e figura 3-17), 3.7.6, 4.2.2 (eq.4-3), 5.1.1 e 5.3; tabelas 5-9 e 5-10; exemplo pp.125–126 e 129. Modelo 4E de chapa espessa, sem nervuras.',
            SCI+' — recomendações de detalhamento para end plate rotulada de altura total; complemento de geometria, sem conversão de capacidades das tabelas.']

DG_4ES_REFERENCE=(DG+' — 3.7.4 (eq.3-36), 3.7.5 (eq.3-38 a 3-41), 3.7.6; '
                  '4.2.5 (eq.4-4 e figura 4-3); 5.1 e 5.3.1; tabelas 5-9 e 5-11; '
                  'tabela A-2 para coluna contínua sem enrijecedores. Modelo 4ES de chapa espessa, '
                  'com duas nervuras externas e juntas CJP compatíveis. Exemplo 5.3-2 usado somente '
                  'para conferência dos componentes aplicáveis, sem crédito aos reforços de coluna do exemplo.')

DG_8ES_REFERENCE=(DG+' — edição 2023; tabela 5-16, p.119 (chapa 8ES); tabela A-5(a), '
                  'p.269 e figura A-5(a), p.270 (coluna contínua sem enrijecedores); '
                  'tabela 5-9, p.112 (domínio ensaiado); eq.3-36, p.43; CJP, p.45; '
                  'eq.4-3, p.51 e eq.4-4/figura 4-3, pp.52–53. Exemplo 5.3-7, '
                  'pp.180–188, usado apenas como referência de componentes: detalhe de 16 '
                  'parafusos p.181, CJP p.185 e transferência local da alma pp.186–187. '
                  'O exemplo não comprova uma ligação completa dentro do domínio: a largura '
                  'da chapa excede a faixa da tabela 5-9 e as verificações da coluna são remetidas a outros exemplos.')


def eight_es_case(doc,c,case,actions):
    """Describe one complete case without borrowing the other case's results."""
    ac=case['actions'];top=ac['M']>0
    end='superior' if top else 'inferior'
    pivot=c.beam.d-c.beam.tf/2 if top else c.beam.tf/2
    indices=(1,2,3,4) if top else (8,7,6,5)
    active=[c.rows[i-1] for i in indices]
    doc.add_paragraph('Estado do caso: '+('calculado' if case['status']=='calculated' else 'não resolvido')+
                      '; V='+number(ac['V'],3)+' N; N='+number(ac['N'],3)+' N; M='+number(ac['M'],3)+' Nmm. '
                      'Extremidade tracionada efetiva: '+end+'; oito parafusos ativos nas linhas '+
                      ', '.join(str(i) for i in indices)+'. Pivô de compressão em y='+number(pivot,3)+' mm.')
    doc.add_paragraph('Quatro braços físicos h1 a h4, na ordem da extremidade ativa para o centro: '+
                      '; '.join('h'+str(i)+'='+number(h,3)+' mm' for i,h in enumerate(c.tension_arms,1))+
                      '. Coordenadas y correspondentes: '+', '.join(number(y,3) for y in active)+' mm; dois parafusos por linha.')
    if not case['checks'] or not actions:return
    doc.add_paragraph('Distribuição deste caso: Ft=Meq/[2(h1+h2+h3+h4)]='+number(actions['bolt_tension'],3)+
                      ' N por parafuso ativo; T=8Ft='+number(actions['T'],3)+' N; C=max(T−N;0)='+
                      number(actions['C'],3)+' N. Fv=|V|/16='+number(actions['bolt_shear'],3)+
                      ' N em cada um dos 16 parafusos físicos. Os oito restantes recebem somente essa parcela de cisalhamento.')
    doc.add_paragraph('Transferência deste caso: Ff='+number(actions['flange_transfer_force'],3)+' N; Fc='+
                      number(actions['flange_compression_force'],3)+' N; Ff/2='+number(actions['local_transfer_force'],3)+
                      ' N. lwt=pfi+pb+152,4='+number(actions['web_tension_length'],3)+' mm; lws=min(hw−lwt;hw/2)='+
                      number(actions['web_shear_weld_length'],3)+' mm, com hw='+number(actions['web_physical_height'],3)+
                      ' mm. A faixa de tração começa na face interna da mesa '+end+
                      '; a faixa de cisalhamento é distinta, sem deduzir uma segunda faixa de tração inativa.')
    doc.add_paragraph('Espessuras requeridas deste caso: tp,req='+number(actions['tp_required'],6)+
                      ' mm; tfc,req='+number(actions['column_tf_required'],6)+
                      ' mm. A qualificação sem alavanca exige ambas as espessuras e todas as condições de fonte, domínio e nervuras CJP; os resultados abaixo conservam a qualificação própria deste caso.')


def equation_lines(doc,expressions):
    """Keep the deliberately split native equation together on one page."""
    for i,expression in enumerate(expressions):
        _math(doc,expression)
        doc.paragraphs[-1].paragraph_format.keep_with_next=i<len(expressions)-1

def compact_outcome(row):
    if not row.numerically_valid:return 'Falha numérica'
    if not row.applicable:return 'N/A'
    if row.passed and not getattr(row,'source_qualified',True):return 'Não qualificado'
    if row.category=='Condição do método':return 'Método: atende' if row.passed else 'Método: falha'
    if not row.passed:return 'Não atende'
    if not getattr(row,'no_prying_qualified',True):return 'Não qualificado'
    return 'Atende'


def equation(doc,row):
    i=row.id
    if i in ('ep_extension_shear_yield','ep_extension_shear_rupture','ep_beam_web_local_tension','ep_weld_cjp_flange_local','ep_weld_cjp_web_local','ep_weld_cjp_web_shear'):
        for part in row.equation.split('; '):_math(doc,group(part))
    elif i in ('ep_plate_rigidity','ep_column_rigidity'):
        _math(doc,group(sub('t','req'),' = ',radical(frac(group('1,10 ',sub('M','eq'),' max(',sub('γ','a1'),'; 1/0,90)'),group(sub('f','y'),' Y')))))
    elif i in ('ep_plate_prying','ep_column_prying'):
        _math(doc,group(sub('t','req'),' = ',radical(frac(group('4(b − ',sub('d','b'),'/2)',sub('F','t,0,Sd'),sub('γ','a1')),group('p ',sub('f','u'))))))
    elif i=='ep_bolt_interaction':
        _math(doc,group('η = ',power(group('(',frac(sub('F','t,Sd'),sub('F','t,Rd')),')')),' + ',power(group('(',frac(sub('F','v,Sd'),sub('F','v,Rd')),')')),' ≤ 1'))
    elif i=='ep_plate_yield':_math(doc,group(sub('M','Rd'),' = ',frac(group(sub('f','y'),power(sub('t','p')),sub('Y','p')),sub('γ','a1'))))
    else:_math(doc,group(row.equation))

def create_report(c,r,detailed=False):
    from .end_plate_detail import DETAIL_SCOPE,detail_description
    if c.is_mre12:
        from .end_plate_mre12_report import create_mre12_report
        return create_mre12_report(c,detailed)
    # Bind every exported report to current inputs, not a caller's stale result.
    r=evaluate(c)
    eight_es=c.kind=='moment' and getattr(c,'is_8es',False)
    stiffened=c.kind=='moment' and getattr(c,'variant','4E') in ('4ES','8ES')
    if not r.checks or any(x.severity=='error' and x.origin not in ('numeric','method') for x in r.issues):raise ValueError('O projeto deve ter geometria e domínio válidos para gerar a memória.')
    doc=Document();sec=doc.sections[0]
    sec.page_width=Inches(8.27);sec.page_height=Inches(11.69)
    sec.top_margin=sec.bottom_margin=Inches(.6);sec.left_margin=sec.right_margin=Inches(.65)
    for name in ('Normal','Title','Subtitle','Heading 1','Heading 2'):
        sty=doc.styles[name];sty.font.name='Arial';sty.font.color.rgb=RGBColor(0,0,0)
    for sty in doc.styles:
        for border in sty.element.xpath('.//w:pBdr'):border.getparent().remove(border)
    doc.styles['Normal'].font.size=Pt(9.5);doc.styles['Normal'].paragraph_format.space_after=Pt(5)
    doc.styles['Title'].font.size=Pt(20);doc.styles['Heading 1'].font.size=Pt(12);doc.styles['Heading 2'].font.size=Pt(10)
    kind='rotulada' if c.kind=='pinned' else ('engastada · '+c.variant if stiffened else 'engastada')
    doc.core_properties.title='End plate '+kind+' na mesa de coluna';doc.core_properties.author='LRO Soluções de engenharia LTDA.'
    doc.add_paragraph('End plate '+kind,style='Title')
    doc.add_paragraph('Viga na mesa de coluna',style='Subtitle')
    doc.add_paragraph(c.project+' | '+c.beam.name+' → '+c.support.name)
    summary=r.summary_checks
    p=doc.add_paragraph();p.add_run(r.status).bold=True
    # Keep qualifications immediately after the status, before numeric summaries.
    if r.coverage_note:doc.add_paragraph(r.coverage_note)
    if r.calculation_note:doc.add_paragraph(r.calculation_note)
    for line in summary_lines(r):
        doc.add_paragraph(line).paragraph_format.space_after=Pt(2)
    doc.add_paragraph(SCOPE_NOTICE).paragraph_format.space_after=Pt(2)
    for issue in r.issues:
        if issue.severity=='pending':doc.add_paragraph(calculated_text(issue.text, assignments_only=True))
    doc.add_picture(BytesIO(image_bytes(c)),width=Inches(6.65))
    doc.paragraphs[-1].paragraph_format.keep_with_next=True
    doc.add_paragraph('A viga é soldada à chapa de topo, que se liga à mesa da coluna somente por parafusos. O desenho acompanha as entradas; as cotas são ilustrativas e devem ser complementadas no detalhamento de fabricação.')
    if eight_es:
        doc.add_paragraph('8ES: 16 parafusos físicos em oito linhas primárias, dois por linha e oito ativos à tração por caso. '
                          'Extremidade tracionada na Entrada: '+('superior' if c.M>0 else 'inferior')+
                          '. Duas nervuras externas idênticas; coluna contínua sem reforço. Inversão do sinal de M representa casos estáticos separados, sem qualificação sísmica ou cíclica.')
    # A heading-owned break cannot leave an overflowing empty break paragraph.
    doc.add_paragraph('Dimensões e materiais adotados',style='Heading 1').paragraph_format.page_break_before=True
    # Keep the action/convention text with the data section, not on an orphan cover page.
    doc.add_paragraph('Ações no plano e já majoradas: V='+number(c.V/KGF)+' kgf; N='+number(c.N/KGF)+' kgf'+('; M='+number(c.M/(KGF*1000))+' kgf·m.' if c.kind=='moment' else '. Sem momento externo.'))
    doc.add_paragraph('N positivo indica tração; negativo, compressão. '+('M positivo traciona a mesa superior; negativo, a inferior.' if c.kind=='moment' else 'Os parafusos ficam entre as mesas, em grupo centrado.'))
    rows=[('Viga',f"d={display_format(c.beam.d, 'g')}; bf={display_format(c.beam.bf, 'g')}; tw={display_format(c.beam.tw, 'g')}; tf={display_format(c.beam.tf, 'g')}",c.beam_steel),
          ('Coluna',f"d={display_format(c.support.d, 'g')}; bf={display_format(c.support.bf, 'g')}; tw={display_format(c.support.tw, 'g')}; tf={display_format(c.support.tf, 'g')}",c.support_steel),
          ('Chapa',f"hp={display_format(c.hp, 'g')}; bp={display_format(c.bp, 'g')}; tp={display_format(c.tp, 'g')}",c.plate_steel),
          ('Parafusos',f"{display_value(c.count)} no detalhe; {display_value(c.calculation_count)} no cálculo; db={display_format(c.db, 'g')}; g={display_format(c.gauge, 'g')}",c.bolt),
          ('Furos',f"dh={display_format(c.dh, 'g')}; dedução líquida={display_format(c.dn, 'g')}",'Padrão; '+('broca' if c.drilled else 'dedução +2 mm')),
          ('Linhas',', '.join(number(y,2) for y in c.rows),'y desde a face superior da viga'),
          ('Extensões',f"acima={display_format(c.ext_top, 'g')}; abaixo={display_format(c.ext_bottom, 'g')}",'mm'),
          ('Soldas','CJP nas duas mesas e na alma' if c.kind=='moment' else f"Filetes contínuos w={display_format(c.weld, 'g')}",f"fw={display_format(c.fw, 'g')} MPa")]
    if eight_es:
        rows.extend([
            ('Passos 8ES',f"pfi={display_format(c.pfi, 'g')}; pfo={display_format(c.pfo, 'g')}; pb={display_format(c.pb, 'g')}; de={display_format(c.edge, 'g')}",'pb físico entre pares internos e externos de cada mesa'),
            ('Braços físicos','; '.join(f"h{display_value(i)}={display_format(h, 'g')}" for i,h in enumerate(c.tension_arms,1)),'Quatro linhas ativas; dois parafusos por linha')])
    if c.has_detail_ribs:
        doc.add_paragraph(DETAIL_SCOPE)
        rows.append(('Nervuras de detalhamento',detail_description(c),'Sem verificação das nervuras/soldas'))
    if stiffened:
        rows.extend([
            ('2 nervuras',f"ts={display_format(c.stiffener_t, 'g')}; hst={display_format(c.ext_top, 'g')}; Lst={display_format(c.stiffener_length, 'g')}",c.stiffener_steel),
            ('Recorte / patamares',f"recorte por face={display_format(c.stiffener_clip, 'g')}; patamares={display_format(c.stiffener_landing, 'g')}",'Simétricos; sem solda sobre o recorte'),
            ('CJP nervura–chapa',f"comprimento conectado={display_format(c.ext_top - c.stiffener_clip, 'g')}",c.stiffener_weld+' contínua'),
            ('CJP nervura–mesa',f"comprimento conectado={display_format(c.stiffener_length - c.stiffener_clip, 'g')}",c.stiffener_weld+' contínua'),
            ('Consumível '+c.variant,c.stiffener_electrode,f"fw={display_format(c.fw, 'g')} MPa"),
            ('Premissas CJP','Compatibilidade NBR Tabela 8: '+('sim' if c.stiffener_compatible else 'não'),
             'Recorte/sequência confirmados: '+('sim' if c.stiffener_clearance else 'não'))])
    table(doc,['Componente','Dimensões em mm','Material ou critério'],[(a,decimal_text(b),d) for a,b,d in rows],[1.15,3.5,2.3])
    mats=list(dict.fromkeys([c.beam_steel,c.support_steel,c.plate_steel]+([c.stiffener_steel] if stiffened else [])))
    doc.add_paragraph('Resistências características: '+'; '.join(f"{display_value(s)}: fy={display_format(STEELS[s].fy, 'g')} MPa; fu={display_format(STEELS[s].fu, 'g')} MPa" for s in mats)+'. E=200.000 MPa. 1 kgf=9,80665 N.')
    doc.add_paragraph('Referências de cálculo',style='Heading 1')
    for ref in REFERENCES:
        if (c.kind=='pinned' and ref.startswith(DG)) or (c.kind=='moment' and ref.startswith(SCI)):continue
        doc.add_paragraph((DG_8ES_REFERENCE if eight_es else DG_4ES_REFERENCE) if stiffened and ref.startswith(DG) else ref)
    if stiffened:
        doc.add_paragraph('Edição consultada: DG39 (2023). A errata de novembro de 2024 não foi consultada; limitação de controle de edição declarada.')
        doc.add_paragraph('As condições CJP e de acesso informadas são premissas do detalhe calculado; não constituem atestado de inspeção ou execução da solda.')
        doc.add_paragraph('Rota CJP finita: aços da viga, chapa e nervuras selecionados independentemente entre A36/A572 Gr.42/Gr.50. A coluna usa seu próprio material. Consumível E7018, classe 70, fw=485 MPa. A declaração de compatibilidade inclui procedimento, baixo hidrogênio e preaquecimento pelo grupo de maior resistência, conforme NBR Tabela 8, nota a; fw isolado não comprova essa compatibilidade. Soldar as mesas da viga à chapa antes de instalar as nervuras; o recorte deve liberar a junta e sua preparação.')
        doc.add_paragraph('A CJP compatível desenvolve a nervura através do metal-base conectado. As duas interfaces são verificadas separadamente, no mesmo nível de resistência de cálculo NBR: tração na chapa e cisalhamento na mesa. NBR 6.2.5.1: área baseada na menor espessura conectada e fy igual ao menor dos metais-base. Mesmo receptor mais espesso não compensa aço mais fraco na junta. fu/γa2≥fy/γa1 é conferido em cada material da viga, chapa e nervuras. Os patamares são detalhe de terminação recomendado no DG39, não um mínimo normativo NBR de 25,4 mm.')
    if eight_es:
        doc.add_paragraph('Escopo 8ES: uma viga I duplamente simétrica e centrada, perpendicular à mesa de uma coluna I contínua sem enrijecedores; ações estáticas no plano. '
                          'Excluídos: extremidade/emenda/abertura próxima da coluna, viga oposta ou carga concentrada concorrente, chapas de continuidade/doubler, laje participante, flexão no eixo fraco, cortante horizontal, fadiga, sismo e esforço axial dominante. '
                          'Mantêm-se as hipóteses declaradas de contenção da viga/coluna e força axial do painel. Uma falha da coluna sem reforço não autoriza acrescentar reforço nem aprovar a ligação.')
        doc.add_paragraph('Domínio da fonte: tabela 5-9 com ±10% nos limites ensaiados. Saída da faixa é extrapolação do método, sem qualificação; não é uma resistência NBR fictícia. '
                          'Não há faixa ensaiada independente de pb nem aplicação do gabarito go de quatro colunas. Os espaçamentos, bordas, ligamentos e acesso físico são verificados nas oito linhas reais.')
        table(doc,['Grandeza','Entrada em mm','Faixa da fonte em mm'],[
            (name,number(value,3),number(lo,4)+' a '+number(hi,4))
            for name,value,lo,hi in [('pfi',c.pfi,22.86,69.85),('pfo',c.pfo,22.86,69.85),
                ('hst = pfo + pb + de',c.ext_top,57.15,209.55),('g',c.gauge,62.865,195.58),
                ('d',c.beam.d,360.045,2011.68),('bp física',c.bp,114.3,286.385),
                ('tf da viga',c.beam.tf,8.5725,27.94)]],[2.35,1.7,2.9])
        doc.add_paragraph('Limites de fonte em SI arredondado: fy da chapa ≤345 MPa; fy da viga/coluna ≤380 MPa; parafusos A325/A490 e dimensões do catálogo qualificado. '
                          'A rota CJP restringe cada aço da viga, chapa e nervuras a A36/A572 Gr.42/Gr.50, permitindo escolhas diferentes com desenvolvimento verificado em ambas as interfaces. g≤bf preserva o caminho de forças. '
                          'Nas regiões protegidas em contato, o máximo de espaçamento adotado é min(24·min(tp;tfc);300 mm).')
        doc.add_paragraph('Execução CJP: soldar primeiro a alma da viga à chapa, depois as mesas e por último as nervuras; recorte sem solda e com acesso/preparação confirmados. '
                          'A eq.3-37 trata de ductilidade em alto sismo e não é um limite de esbeltez deste cálculo estático. '
                          'A fonte p.185 admite CJP nas duas interfaces. Não se adota um modelo genérico de nervura comprimida ou de gusset.')
    doc.add_paragraph('Esforços usados nas verificações',style='Heading 1')
    a=r.geometry['actions'];aa=r.geometry['actual_actions']
    action_cases=[(x['label']+(' · não resolvido' if x['status']!='calculated' else ''),x['actions']) for x in r.case_records] if c.kind=='moment' else [('Entrada',aa),('Conferência governante',a)]
    table(doc,['Caso','V em kgf','N em kgf','M em kgf·m'],[(lab,number(ac['V']/KGF),number(ac['N']/KGF),number(ac['M']/(1000*KGF))) for lab,ac in action_cases],[2.3,1.55,1.55,1.55])
    doc.add_paragraph('A conferência mínima de 45 kN mantém a direção e o sentido da resultante N/V. Fator aplicado somente às forças: '+number(r.minimum_factor,4)+'. O momento externo não é majorado novamente. A entrada original também é verificada.')
    if c.kind=='moment':
        doc.add_paragraph('Envoltória por mecanismo: cada linha conserva demanda, resistência, fonte e substituição do seu caso governante. Nenhum caso suplementar substitui a verificação da Entrada. Com N=V=0, não se inventa direção para a força mínima; o momento e os mínimos de desenvolvimento DG39 permanecem ativos.')
        doc.add_paragraph('Parâmetros de distribuição abaixo: '+('Mínimo de força.' if r.minimum else 'Entrada.'))
        doc.add_paragraph('Distribuição local: Meq=|M|+max(N;0)(d−tf)/2; Ft por parafuso=Meq/[2('+('h1+h2+h3+h4' if eight_es else 'h1+h2')+')]. A compressão axial não reduz a tração de cálculo dos parafusos. O envelope é conservador; não representa uma análise elástica de contato.')
        local_path=('A alma tracionada recebe Ff/2=' if stiffened else 'A alma tracionada e a extensão ativa da chapa recebem Ff/2=')
        doc.add_paragraph('Transferência local DG39: Ff=|M|/(d−tf)+max(N;0)/2='+number(a['flange_transfer_force'],3)+' N; Fc=|M|/(d−tf)+max(−N;0)/2='+number(a['flange_compression_force'],3)+' N. '+local_path+number(a['local_transfer_force'],3)+(' N.' if stiffened else ' N cada.')+' Essa força é distinta da resultante dos parafusos e do cortante V. lwt='+number(a['web_tension_length'],3)+' mm; lws='+number(a['web_shear_weld_length'],3)+' mm. As juntas CJP são verificadas localmente, com mínimo de desenvolvimento de 60%, além do critério elástico global.')
        if not stiffened:
            doc.add_paragraph('Coluna 4E sem reforço: escoamento local da alma sob max(Ff;Fc); enrugamento sob Fc. DG39 3.5 p.37 e 3.7.6 eq.3-48; exemplo 5.3-1 p.132. As resistências NBR 5.7.3.2(b)/5.7.4.2(b) conservam k=tf, ln=0 e condição de extremidade, sem crédito ao raio ou ao espalhamento. T=4Ft e C=max(T−N;0) são resultantes distintas, preservadas nas verificações de parafusos e contato.')
        if stiffened:
            doc.add_paragraph('Coluna sem reforço: escoamento local da alma sob max(Ff; Fc), crippling sob Fc. A resultante tracionada dos parafusos T='+('8' if eight_es else '4')+'Ft e o contato C=max(T−N;0) são grandezas distintas. As nervuras da end plate não dão crédito a chapas de continuidade ou doubler na coluna.')
            doc.add_paragraph('O cisalhamento da extensão livre da chapa, exclusivo das variantes sem nervuras, não é estado-limite '+c.variant+' (DG39 p.'+('184' if eight_es else '141')+'). Não se atribui Ff/2 como tensão direta fictícia na área ts·hst da nervura.')
        if eight_es:
            doc.add_paragraph('Cortante por parafuso: Fv=|V|/16 em todos os parafusos primários, com interação NBR nos oito ativos à tração. '
                              'A distribuição igual de tração é a da tabela 5-16, sem usar hi/Σhi². Transferência local da alma: (4/8)Ff=Ff/2; lwt=pfi+pb+152,4 mm, limitado pela existência física da alma. '
                              'Os casos completos adiante identificam os quatro braços e a extremidade tracionada efetiva.')
    if not stiffened:doc.add_page_break()
    doc.add_paragraph('Quadro de verificações',style='Heading 1')
    doc.add_paragraph('Índice η=solicitação/resistência, ou interação; limite 1,00. Os critérios de espessura, ductilidade e compacidade são condições do método. O resultado abrange as verificações abaixo, sob as premissas finais.')
    if c.kind=='moment':doc.add_paragraph('N/A: mecanismo sem solicitação, mantendo os mínimos DG39 onde aplicáveis. Método: requisito de aplicação, distinto de resistência. Não qualificado: índice sem alavanca condicionado às duas espessuras requeridas'+(' e às condições de suporte, geometria, material e CJP das nervuras '+c.variant+'.' if stiffened else '.'))
    vals=[]
    for row in summary:
        sd,unit=display(row.demand,row.unit);rd,_=display(row.resistance,row.unit)
        vals.append((row.name+(' ['+row.case+']' if c.kind=='moment' else ''),row.category,sd,rd,unit,number(row.ratio,3),compact_outcome(row) if c.kind=='moment' else row.outcome))
    table(doc,['Verificação','Tipo','Sd ou valor','Rd ou limite','Unid.','Índice','Resultado'],vals,[2.2,.8,.8,.8,.5,.75,1.1])
    doc.add_paragraph('Chapa: tp mínimo calculado='+number(a['tp_required'],3)+' mm; adotado='+number(c.tp,3)+' mm. Mesa da coluna: tf mínimo calculado='+number(a['column_tf_required'],3)+' mm; adotado='+number(c.support.tf,3)+' mm.')
    # Let the thickness note flow with the calculation, avoiding an orphan page.
    doc.add_paragraph('Memória de cálculo',style='Heading 1')
    doc.add_paragraph('Substituições em N, mm e MPa. '+('Desenvolvimento de todas as verificações.' if detailed else 'Desenvolvimento dos critérios principais e dos itens governantes por componente. Todas as verificações constam do quadro.'))
    selected=summary if detailed else []
    if not detailed:
        groups=[['ep_plate_rigidity','ep_plate_yield','ep_plate_prying'],['ep_column_rigidity','ep_column_prying'],['ep_rotation'],['ep_bolt_interaction'],['ep_bearing_plate','ep_bearing_column','ep_block_plate'],['ep_weld_fillet','ep_weld_cjp','ep_base_weld'],['ep_beam_web','ep_beam_nv'],['ep_column_web_yield','ep_column_crippling','ep_panel','ep_contact'],['ep_extension_shear_yield'],['ep_extension_shear_rupture'],['ep_beam_web_local_tension'],['ep_weld_cjp_flange_local'],['ep_weld_cjp_web_local'],['ep_weld_cjp_web_shear']]
        for ids in groups:
            candidates=[x for x in summary if x.id in ids]
            if candidates:selected.append(max(candidates,key=lambda x:x.ratio))
    if stiffened and not detailed:
        selected.extend(x for x in summary if ('stiffener' in x.id or '4es' in x.id or (eight_es and '8es' in x.id)) and x not in selected)
    for row in selected:
        start=len(doc.paragraphs);doc.add_paragraph(row.name+(' ['+row.case+']' if c.kind=='moment' else ''),style='Heading 2');equation(doc,row)
        doc.add_paragraph(decimal_text(calculated_text(row.substitution))+'; η='+number(row.ratio,3)+'.')
        doc.add_paragraph(calculated_text(row.variables, assignments_only=True)+' Referência: '+row.reference+'.')
        if c.kind=='pinned' and row.id=='ep_beam_nv':
            for branch in [x for x in r.checks if x.id in ('ep_beam_web','ep_beam_nv')]:
                doc.add_paragraph(branch.name+': '+branch.equation+'; '+decimal_text(calculated_text(branch.substitution))+'; η='+number(branch.ratio,6)+'. '+calculated_text(branch.variables, assignments_only=True)+' Referência: '+branch.reference+'.')
        for p in doc.paragraphs[start:-1]:p.paragraph_format.keep_with_next=True
    if c.kind=='moment':
        doc.add_paragraph('Casos independentes e ramos numéricos',style='Heading 1')
        doc.add_paragraph('Os três agrupamentos de exibição conservam todos os ramos: interação/escalas dos parafusos; espessura/plastificação da chapa; tração local da alma/junta CJP. Uma condição de espessura não atendida não equivale, por si só, a escoamento resistente.')
        for case in r.case_records:
            doc.add_paragraph(case['label'],style='Heading 2')
            if eight_es:
                case_actions=r.geometry.get('actual_actions' if case['label']=='Entrada' else 'minimum_actions')
                eight_es_case(doc,c,case,case_actions)
            if not case['checks']:
                doc.add_paragraph(case.get('reason','Caso sem conclusão.'));continue
            table(doc,['Ramo numérico','Sd','Rd','Unid.','η','Resultado'],[(x.name,display(x.demand,x.unit)[0],display(x.resistance,x.unit)[0],display(x.demand,x.unit)[1],number(x.ratio,6),compact_outcome(x)) for x in case['checks']],[3.05,.9,.9,.6,.7,.8])
            if detailed:
                for x in case['checks']:
                    doc.add_paragraph(x.name+' ['+x.case+']: '+x.equation+'; '+decimal_text(calculated_text(x.substitution))+'; η='+number(x.ratio,9)+'. '+calculated_text(x.variables, assignments_only=True)+' Fonte: '+x.reference+'.')
                if eight_es and case_actions and case_actions.get('plate_blocks'):
                    doc.add_paragraph('Blocos parciais e completos da chapa neste caso',style='Heading 2')
                    doc.add_paragraph('Cada percurso usa os furos das oito linhas físicas, a partir da borda indicada. '
                                      'Duas colunas de furos; solicitação de cisalhamento do bloco = 2·linhas carregadas·|V|/16. '
                                      'Áreas e resistências seguem a verificação NBR de cisalhamento em bloco, com as deduções reais de furos.')
                    table(doc,['Borda','Linhas de furos','Linhas carregadas','Sd em N','Rd em N','η'],[
                        ('superior' if block['edge']=='top' else 'inferior',block['hole_rows'],block['loaded_rows'],
                         number(block['demand'],3),number(block['resistance'],3),number(block['demand']/block['resistance'],6))
                        for block in case_actions['plate_blocks']],[.8,.8,.9,1.5,1.8,1.15])
        heading=doc.add_paragraph('Parâmetros das linhas de plastificação',style='Heading 2')
        heading.paragraph_format.page_break_before=False
        if eight_es:
            doc.add_paragraph('bp efetiva='+number(c.effective_bp,3)+' mm, limitada a min(bp;bf+max(tp;25,4 mm)). '
                              'sP=√(bp efetiva g)/2; po=min(pfo;sP); pi=min(pfi;sP). '
                              'h1=d−tf/2+pfo+pb; h2=d−tf/2+pfo; h3=d−1,5tf−pfi; h4=d−1,5tf−pfi−pb.')
            equation_lines(doc,[group(sub('Y','p'),' = (bp,ef/2)[h1/(2de) + h2/po + h3/pi + h4/sP] + (2/g)Qp + g'),
                                group('Qp = h1(de + 3pb/4) + h2(po + pb/4)'),
                                group('       + h3(pi + 3pb/4) + h4(sP + pb/4)')])
            doc.add_paragraph('Tabela 5-16, p.119: 0<de=e<sP estritamente; igualdade não pertence a este ramo. '
                              'Os limites po e pi são usados somente em Yp; coordenadas, quatro braços, c e pb permanecem físicos. '
                              'Qp apenas agrupa a soma da expressão da fonte. Eq.3-36: ts ≥ tw·Fyb/Fys. '
                              'Detalhe adotado da eq.4-4: Lst ≥ hst/tan(30°), com hst=pfo+pb+de.')
        else:
            doc.add_paragraph('bp efetiva='+number(c.effective_bp,3)+' mm, limitada a bf + max(25,4 mm; tp). s=√(bp efetiva g)/2; pi=min(pfi;s); '+('po=min(pfo;s); ' if stiffened else '')+'h1=d−tf/2+pfo; h2=d−1,5tf−pfi.')
        if stiffened and not eight_es:
            _math(doc,group(sub('Y','p'),' = (bp/2)[h1(1/po + 1/(2de)) + h2(1/pi + 1/s)] + (2/g)[h1(po + de) + h2(pi + s)]'))
            doc.add_paragraph('Tabela 5-11: de=e<s estritamente. Os limites po e pi são usados somente em Yp; coordenadas dos parafusos e braços h1/h2 conservam pfo/pfi físicos. Eq.3-36: ts ≥ tw·Fyb/Fys. Detalhe adotado da eq.4-4: Lst ≥ hst/tan(30°), hst=pfo+e.')
        elif not stiffened:
            _math(doc,group(sub('Y','p'),' = (bp/2)[h1/pfo + h2(1/pi + 1/s) − 1/2] + (2/g)h2(s + pi)'))
        doc.add_paragraph('Para a coluna: largura física bfc='+number(c.support.bf,3)+' mm; bfc efetiva=min(bfc;bf+max(tp;25,4))='+number(c.effective_bfc,3)+' mm; sc=√(bfc efetiva g)/2; c=pfo+tf+pfi. Em Yc usa-se a largura efetiva, conforme DG39 eq.4-3.')
        if eight_es:
            doc.add_paragraph('Tabela A-5(a), p.269: mecanismo da mesa da coluna contínua sem enrijecedores, '
                              'com quatro linhas e oito parafusos tracionados. sC=sc é independente de sP; c=h2−h3=pfo+tf+pfi. '
                              'Os coeficientes h2·c/4 e h3·c/2 são distintos na fonte. As nervuras externas não reforçam a coluna.')
            equation_lines(doc,[group(sub('Y','c'),' = (bfc,ef/2)(h1/sC + h4/sC) + (2/g)Qc + g/2'),
                                group('Qc = h1(pb + c/2 + sC) + h2(pb/2 + c/4)'),
                                group('       + h3(pb/2 + c/2) + h4 sC')])
            doc.add_paragraph('Valores: '+'; '.join('h'+str(i)+'='+number(h,3)+' mm' for i,h in enumerate(c.tension_arms,1))+
                              '; sP='+number((c.effective_bp*c.gauge)**.5/2,6)+' mm; sC='+number((c.effective_bfc*c.gauge)**.5/2,6)+
                              ' mm; Yp='+number(a['Yp'],6)+' mm; Yc='+number(a['Yc'],6)+' mm. '
                              'Todos os comprimentos do cálculo são em mm; fy·t²·Y resulta em Nmm. '
                              'A espessura requerida é calculada pela ação requerida do caso, sem substituir pelo momento resistente total dos parafusos. '
                              'Esse critério não fornece uma curva momento–rotação nem garante o modo último de ruptura.')
        else:
            if stiffened:doc.add_paragraph('A Tabela A-2 é o mecanismo da mesa da coluna contínua sem enrijecedores, aplicável a 4E/4ES; as nervuras desenhadas pertencem à end plate.')
            _math(doc,group(sub('Y','c'),' = (bfc/2)(h1+h2)/sc + (2/g)[h2(3c/4+sc)+h1(c/4+sc)+c²/2] + g/2'))
            doc.add_paragraph('Valores: h1='+number(a['h1'],3)+'; h2='+number(a['h2'],3)+'; Yp='+number(a['Yp'],3)+' mm; Yc='+number(a['Yc'],3)+' mm. A espessura mínima controla a hipótese de chapa espessa e alavanca desprezível; não é, isoladamente, uma medição de rigidez global.')
    doc.add_paragraph('Variáveis',style='Heading 2')
    doc.add_paragraph('d, bf, tw e tf: altura, largura de mesa, alma e mesa da viga; bp, hp e tp: largura, altura e espessura da chapa; g: gabarito horizontal; pfi e pfo: distâncias livres da mesa às linhas de parafusos; db e dh: diâmetros do parafuso e furo; Ab: área nominal do parafuso; fy, fu e fub: resistências características; Ft e Fv: forças de tração e cisalhamento por parafuso; lc: ligamento livre; Cv: fator de cisalhamento da alma; Sd e Rd: solicitação e resistência de cálculo. Índice c identifica a coluna; p identifica a chapa.')
    if stiffened:doc.add_paragraph('ts: espessura de cada nervura; hst: altura da extensão; Lst: comprimento junto à mesa; de=e: distância da linha externa à borda; po/pi: distâncias limitadas apenas na fórmula de Yp. O recorte diagonal tem pernas iguais, medidas em cada face conectada. Trechos CJP efetivos: hst−recorte e Lst−recorte, em cada nervura. Não há solda no recorte de canto.')
    if eight_es:doc.add_paragraph('pb: passo físico entre as duas linhas externas e entre as duas linhas internas de cada grupo de mesa; h1,h2,h3,h4: quatro braços positivos do grupo ativo, em ordem da extremidade para o centro. hst=pfo+pb+de e hp=d+2hst. Os oito furos por coluna vertical são primários; não há linhas intermediárias. sP e sC pertencem a mecanismos distintos.')
    if c.notes:doc.add_paragraph('Observações do projeto: '+c.notes)
    doc.add_paragraph('Vínculo das entradas (SHA-256): '+input_digest(c)+'. Revisão de cálculo: '+method_revision(c)+'.')
    premises_start=len(doc.paragraphs)
    heading=doc.add_paragraph('Premissas adotadas',style='Heading 1')
    if c.kind=='moment' and not detailed and not eight_es:heading.paragraph_format.page_break_before=True
    for note in c.assumptions:
        if note!=DETAIL_SCOPE:doc.add_paragraph(note)
    for issue in r.issues:doc.add_paragraph(calculated_text(issue.text, assignments_only=True)+' ['+issue.reference+']')
    hyperlink(doc.add_paragraph(BRAND+' LRO Ligações '+VERSION+' · '),'LinkedIn de Lucas Oliveira',LINK)
    for paragraph in doc.paragraphs[premises_start:]:paragraph.paragraph_format.space_after=Pt(3)
    if eight_es:
        for paragraph in doc.paragraphs:paragraph.paragraph_format.widow_control=True
    out=BytesIO();doc.save(out);return out.getvalue()
