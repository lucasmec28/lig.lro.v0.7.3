"""Editable report for the channel family, sharing the exact six UI columns."""
from io import BytesIO
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from .models import KGF, STEELS
from .report import BRAND, number, display, table, _math, group, sub, frac, power
from .display_precision import calculated_text
from .channel_base_plate_drawing import image_bytes, require_current_result

HEADERS=('Verificação','Sd ou valor','Rd ou limite','Unid.','Índice','Atende')


def checks_rows(r):
    rows=[]
    for row in r.checks:
        sd,unit=display(row.demand,row.unit)
        rd,_=display(row.resistance,row.unit)
        rows.append(dict(zip(HEADERS,(row.name,sd,rd,unit,number(row.ratio),'Sim' if row.passed else 'Não'))))
    return rows


def create_report(c,r=None,detailed=False):
    r=require_current_result(c,r)
    if not r.geometry or any(i.severity=='error' for i in r.issues):
        raise ValueError('Corrija os dados da base U antes de gerar a memória.')
    g=r.geometry;doc=Document();sec=doc.sections[0]
    sec.page_width=Inches(8.27);sec.page_height=Inches(11.69)
    sec.top_margin=sec.bottom_margin=Inches(.6)
    sec.left_margin=sec.right_margin=Inches(.65)
    for name in ('Normal','Title','Subtitle','Heading 1','Heading 2'):
        doc.styles[name].font.name='Arial'
        doc.styles[name].font.color.rgb=RGBColor(0,0,0)
    for style in doc.styles:
        for border in style.element.xpath('.//w:pBdr'):
            border.getparent().remove(border)
    doc.styles['Normal'].font.size=Pt(9)
    doc.styles['Normal'].paragraph_format.space_after=Pt(5)
    doc.styles['Title'].font.size=Pt(20)
    doc.styles['Heading 1'].font.size=Pt(12)
    doc.styles['Heading 2'].font.size=Pt(10)
    doc.core_properties.title='Placa de base U rotulada'
    doc.core_properties.author='LRO Soluções de engenharia LTDA.'
    doc.add_paragraph('Placa de base · U rotulada',style='Title')
    doc.add_paragraph('Perfil U assimétrico · '+str(c.anchor_count)+' chumbadores · N/V',style='Subtitle')
    doc.add_paragraph(c.project)
    doc.add_paragraph(r.status).runs[0].bold=True
    doc.add_paragraph(r.calculation_note)
    doc.add_picture(BytesIO(image_bytes(c,r)),width=Inches(6.95))
    doc.add_paragraph('Dimensões reais da seção U, placa, centroide e posições das barras ativas. '
                      'O trecho vertical e a parte enterrada são esquemáticos. Não é desenho de fabricação. '
                      'N positivo comprime; V positivo é paralelo a +x, na direção da alma. M aplicado=0.')
    doc.add_paragraph('Dados, materiais e ações de cálculo',style='Heading 1').paragraph_format.page_break_before=True
    rows=[('Pilar U',c.column.name),('Origem da seção',c.column.source),
          ('d / bf / tw / tf / clear nominal do registro (mm)',' / '.join(number(getattr(c.column,k)) for k in ('d','bf','tw','tf','clear'))),
          ('Área da seção (mm²)',number(c.column.area)),
          ('T reto informado / T usado no cálculo (mm)',number(c.straight_web_length)+' / '+number(c.effective_clear)),
          ('Centroide automático do catálogo','Sim' if c.centroid_from_catalog else 'Não; entrada manual/legada'),
          ('Aço do pilar / aço da placa',c.column_steel+' / '+c.plate_steel),
          ('fy do pilar / fy da placa (MPa)',number(STEELS[c.column_steel].fy)+' / '+number(c.fy)),
          ('Placa L × B × tp (mm)',' × '.join(number(v) for v in (c.L,c.B,c.tp))),
          ('Barras '+(c.anchor_material_name or 'material não identificado')+': quantidade / diâmetro',str(c.anchor_count)+' / '+number(c.db)+' mm'),
          ('Furo circular da placa U',number(c.actual_base_hole)+' mm · '+('informado para contato direto; não tabulado' if c.direct_anchor_shear else 'informado' if c.base_hole>0 else 'referência Tabela 18')),
          ('Posições (x,y) das barras (mm)','; '.join('('+number(x)+', '+number(y)+')' for x,y in c.anchor_coordinates)),
          ('ec: dorso → CG / ey: centro da placa → CG (mm)',number(c.centroid_back)+' / '+number(c.offset_y)),
          ('N de cálculo, positivo em compressão (kgf)',number(c.N/KGF)),
          ('V de cálculo, paralelo à alma (kgf)',number(c.V/KGF)),
          ('Momento externo aplicado (kgf·m)','0,00'),
          ('Momento local N·ey (kgf·m)',number(g['local_moment_x']/(KGF*1000))),
          ('fck concreto / graute (MPa)',number(c.fck)+' / '+number(c.grout_fck)),
          ('Espessura do graute (mm)',number(c.grout_t)),
          ('Perna do filete contínuo E7018 z (mm)',number(c.weld_size)),
          ('Cortante','Contato direto placa–haste: EN complementar e ACI independente; arruela somente axial' if c.direct_anchor_shear else {'friction':'Atrito','anchors':'Chumbadores retos: V integral, sem atrito; arruelas superiores soldadas'}.get(c.shear_path,c.shear_path))]
    if hasattr(c,'flange_min_thickness'):
        rows.append(('Espessura usada na mesa junto à solda (mm)',number(c.effective_flange_min_thickness) if c.effective_flange_min_thickness>0 else 'Pendente'))
        rows.append(('Origem da espessura da mesa',c.flange_thickness_basis))
        rows.append(('Entrada manual conservada (mm)',number(c.flange_min_thickness)))
    if c.upper_washer.model=='fitted_direct' and not c.direct_anchor_shear:
        rows.extend([('Arruela superior ajustada',number(c.anchor_washer_side)+' × '+number(c.anchor_washer_side)+' × '+number(c.anchor_washer_t)+' mm; '+c.upper_washer.steel),
            ('Furos e alinhamento','Dbase='+number(c.actual_base_hole)+' mm; dh='+number(c.anchor_washer_hole)+' mm; '+('furação conjunta após solda' if c.washer_alignment=='joint_drilled' else 'δ='+number(c.washer_offset_tolerance)+' mm')),
            ('Porca superior','ASTM A563 Grade A heavy hex UNC; engate integral e acabamento compatível' if c.washer_nut_type=='a563_a_heavy_hex_unc' else 'Não especificada'),
            ('Filetes da arruela','Quatro bordas contínuas; w='+number(c.upper_washer.leg)+' mm; SMAW E7018'),
            ('Detalhe ajustado especificado','Sim' if c.washer_detail_confirmed else 'Pendente')])
    table(doc,['Parâmetro','Dado'],rows,[3.35,3.6])
    doc.add_paragraph('Ações informadas já majoradas; nenhuma nova majoração. Geometria e materiais são '
                      'entradas independentes. O centroide do U não é bf/2. Os dados de teste não descrevem uma obra executada.')
    doc.add_paragraph('Equilíbrio e geometria resistente',style='Heading 1').paragraph_format.page_break_before=True
    _math(doc,group(sub('y','dorso'),' = ',sub('e','y'),' − ',sub('e','c'),';   ',sub('M','local'),' = N ',sub('e','y')))
    _math(doc,group('q(y) = ',frac('N','LB'),' [1 + ',frac(group('12 ',sub('e','y'),' y'),power('B')),'];   ',sub('q','min'),' ≥ 0'))
    _math(doc,group(sub('T','i'),' = ',frac('U',str(c.anchor_count)),' [1 + ',frac(group(sub('e','y'),' ',sub('y','i')),power(sub('a','y'))),'];   U = max(−N;0)'))
    if g.get('prying_factor',1.)!=1.:
        doc.add_paragraph('Ti acima é a reação nominal equilibrada. A tração de projeto inclui o fator de alavanca '+
                          number(g['prying_factor'])+'; o acréscimo é envelope de dimensionamento e não uma nova reação do equilíbrio nominal.')
    table(doc,['Resultado do equilíbrio','Valor'],[
        ('Regime',g['case']),('Compressão de contato C (kgf)',number(g['C']/KGF)),
        ('qmin / qmean / qmax (MPa)',' / '.join(number(g[k]) for k in ('qmin','qmean','sigma'))),
        ('Projeções a1 / a2 / a4 (mm)',' / '.join(number(g[k]) for k in ('a1','a2','a4'))),
        ('Espessura por contato / tração (mm)',number(g['t_contact'])+' / '+number(g['t_tension'])),
        ('Painel U sob compressão',g['panel_method']),
        ('Resíduo normal (N)',number(g['residual_N'])),
        ('Resíduos de momento Mx / My (N·mm)',number(g['residual_Mx'])+' / '+number(g['residual_My']))], [3.8,3.15])
    rod_rows=[]
    strips={item['id']:item for item in g['strips']}
    nominal={item['id']:item for item in g.get('nominal_rods',g['rods'])}
    for rod in g['rods']:
        s=strips[rod['id']]
        rod_rows.append((rod['id'],number(rod['x']),number(rod['y']),
                        number(nominal[rod['id']]['tension']/KGF)+' / '+number(rod['tension']/KGF),
                        number(s['bt']),number(s['be']),number(s['t_required'])))
    table(doc,['Barra','x mm','y mm','Tração nominal / projeto kgf','bt mm','be mm','t req. mm'],rod_rows,[.5,.65,.65,1.7,1.,1.,1.45])
    doc.add_paragraph('Compressão: contato integral e envelope qmax. Tração: '+str(c.anchor_count)+' faixas de balanço '
                      'até a face real da alma, sem crédito das mesas nem contato simultâneo. '
                      'Adaptação do balanço genérico §5.2.2. Os mecanismos internos de uma ou duas barras das Figs.47–52 não são usados nesta configuração.')
    doc.add_paragraph('Interface com a disciplina civil',style='Heading 1').paragraph_format.page_break_before=True
    doc.add_paragraph('O dimensionamento do bloco armado, fundação e solo pertence à disciplina civil. Esta memória fornece N/V de cálculo, pressão de contato, coordenadas e trações por barra, separando as reações nominais equilibradas do envelope de projeto 1,4Ti. O acréscimo não deve ser aplicado novamente. As verificações de concreto desta ligação limitam-se aos mecanismos relacionados aos chumbadores e dependem dos dados reais fornecidos.')
    doc.add_paragraph('Verificações realizadas',style='Heading 1')
    table(doc,HEADERS,[tuple(row[h] for h in HEADERS) for row in checks_rows(r)],[2.85,.85,.85,.5,.65,1.25])
    check_scope=('“Sim” indica atendimento da verificação local apresentada. O alcance da ligação e eventuais pendências estão descritos abaixo; '
                 'bloco armado, fundação e estabilidade global pertencem ao projeto civil.'
                 if c.anchor_layout=='two_symmetry' and r.local_upper_washer.get('status')=='pass' else
                 '“Sim” refere-se à linha calculada e não aprova a base completa.')
    doc.add_paragraph('Índices e valores exibidos com duas casas decimais; comparações usam valores internos '
                      'sem arredondamento. '+check_scope)
    from .direct_anchor_shear_report import append_direct_report
    append_direct_report(doc,c,r,detailed)
    doc.add_paragraph('Condições, pendências e alcance',style='Heading 1')
    for issue in r.issues:
        if issue.origin=='channel_flange_model':continue  # stated once in assumptions below
        doc.add_paragraph(issue.severity.upper()+': '+(issue.text if issue.origin=='channel_flange_model' else calculated_text(issue.text))+' Referência: '+issue.reference)
    for assumption in c.assumptions:
        doc.add_paragraph(assumption)
    if detailed:
        detail_start=len(doc.paragraphs)
        doc.add_paragraph('Equações, substituições e fontes',style='Heading 1').paragraph_format.page_break_before=True
        for row in r.checks:
            doc.add_paragraph(row.name,style='Heading 2')
            _math(doc,group(row.equation))
            doc.add_paragraph(calculated_text(row.substitution))
            if row.variables:doc.add_paragraph(calculated_text(row.variables,assignments_only=True))
            doc.add_paragraph('Referência: '+row.reference)
        for paragraph in doc.paragraphs[detail_start:]:
            paragraph.paragraph_format.space_after=Pt(2)
            if paragraph.style.name=='Heading 2':paragraph.paragraph_format.space_before=Pt(4)
    if c.notes:
        doc.add_paragraph('Notas do projeto',style='Heading 1');doc.add_paragraph(c.notes)
    footer=sec.footer.paragraphs[0];footer.text=BRAND
    for run in footer.runs:run.font.size=Pt(8)
    out=BytesIO();doc.save(out);return out.getvalue()


def create_mc_excerpt(c, r=None):
    """Fresh current-case, editable summary for insertion into a project MC."""
    from . import mc_report_layout as mc
    from .anchor_projection_detail import projection_geometry, projection_note
    projection=projection_geometry(c)
    r = require_current_result(c, r)
    if not r.geometry or any(i.severity == 'error' for i in r.issues):
        raise ValueError('Corrija os dados da base U antes de gerar o trecho para MC.')
    doc = mc.document('Placa de base U rotulada', c.project, r.status,
        image_bytes(c, r), 'Geometria e esforços do mesmo caso de entrada. N positivo em compressão; V paralelo à alma; momento externo aplicado nulo. Croqui de conferência.')
    mc.data_table(doc, [('Perfil', c.column.name, '—'), ('Aço do perfil / placa', c.column_steel+' / '+c.plate_steel, '—'),
        ('Placa L × B × tp', ' × '.join(number(v) for v in (c.L,c.B,c.tp)), 'mm'),
        ('Chumbadores: quantidade × diâmetro', str(c.anchor_count)+' × '+number(c.db), 'mm'),
        ('N de cálculo (compressão positiva)', number(c.N/KGF), 'kgf'),
        ('V de cálculo (paralelo à alma)', number(c.V/KGF), 'kgf'),
        ('Momento externo aplicado', '0,00', 'kgf·m'),
        ('Momento local N·ey', number(r.geometry['local_moment_x']/(KGF*1000)), 'kgf·m'),
        ('Concreto / graute: resistência informada', number(c.fck)+' / '+number(c.grout_fck), 'MPa')])
    anchor_table=table(doc, ('Ancoragem e projeção', 'Valor', 'Unid.'), [
        ('Embutimento efetivo hef: topo do concreto até face de apoio', number(c.hef), 'mm'),
        ('Projeção acima da face superior da placa', number(projection['above_plate']), 'mm'),
        ('Projeção acima do topo do concreto', number(projection['above_concrete']), 'mm')], (3.2,3.,.75))
    for row in anchor_table.rows[:-1]:
        for cell in row.cells:
            for paragraph in cell.paragraphs:
                paragraph.paragraph_format.keep_with_next=True
    doc.add_paragraph(projection_note(c)+' hef não é o comprimento total de fabricação do chumbador.')
    mc.object_checks(doc, r.checks)
    return mc.close(doc, [r.calculation_note]+[i.text if i.origin=='channel_flange_model' else calculated_text(i.text) for i in r.issues]+[
            'N/V simultâneos do caso informado; momento externo nulo. O momento local devido à excentricidade real do U permanece considerado.',
            'Tração, quando aplicável: hipóteses de alavanca, faixas resistentes e montagem conforme a memória completa. Rigidez rotacional e estabilidade global não são dimensionadas neste trecho.', c.notes],
        [check.reference for check in r.checks]+[i.reference for i in r.issues])
