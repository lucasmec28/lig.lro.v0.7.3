"""Interface da placa de base Tipo 1: estado isolado, importação e memória."""
from dataclasses import fields,replace
import hashlib
import json
import pandas as pd
import streamlit as st
from .models import Profile,STEELS,KGF,VERSION,profiles
from .base_plate import BasePlate,presets,evaluate,STOCK,ANCHORS,DETAIL,detail_reference,EXTERNAL_SHAPES
from .base_plate_drawing import image_bytes
from .report import BRAND,LINK,number,display

P=profiles();PRESETS=presets()


def seed(c):
    s=st.session_state
    # Uma importação substitui também a declaração técnica, mesmo para dados iguais.
    for key in list(s):
        if key.startswith('bp_anchor_confirm_'):del s[key]
    for f in fields(c):
        if f.name not in ('column','N','M','V','external_shear_rd','anchor_shear_rd'):
            v=getattr(c,f.name);s['bp_'+f.name]=float(v) if isinstance(v,(float,int)) else v
    s['bp_N_kgf']=c.N/KGF;s['bp_M_kgfm']=c.M/(KGF*1000);s['bp_V_kgf']=c.V/KGF
    s['bp_external_shear_kgf']=c.external_shear_rd/KGF
    s['bp_anchor_shear_kgf']=c.anchor_shear_rd/KGF
    s['bp_shear_mechanism']='device' if c.shear_path in ('plate','external') else c.shear_path
    s['bp_device_model']=c.shear_path if c.shear_path in ('plate','external') else 'plate'
    s['bp_db_label']=next(k for k,v in ANCHORS.items() if abs(c.db-v)<1e-7)
    s['bp_lug_t_label']=next((k for k,v in STOCK.items() if abs(c.lug_t-v)<1e-7),'Personalizada')
    s['bp_tp_label']=next((k for k,v in STOCK.items() if abs(c.tp-v)<1e-7),'Personalizada')
    p=c.column;s['bp_column_name']=p.name if p.name in P else 'Seção I personalizada'
    s['bp_column_manual_name']=p.name
    for k in ('d','bf','tw','tf','clear'):s['bp_column_'+k]=float(getattr(p,k))
    s['_base_plate_project']=c.to_dict()
    s.pop('bp_report',None)


def load_example():
    seed(PRESETS[st.session_state.bp_example])
    st.session_state.pop('bp_import_error',None)


def load_json():
    try:
        up=st.session_state.bp_upload
        if up is None:raise ValueError('Selecione um arquivo JSON.')
        raw=up.getvalue()
        if len(raw)>200000:raise ValueError('Projeto maior que o limite de 200 kB.')
        c=BasePlate.from_dict(json.loads(raw))
        seed(c);st.session_state.pop('bp_import_error',None)
    except (ValueError,TypeError,KeyError,OverflowError,UnicodeError) as exc:
        st.session_state.bp_import_error='Não foi possível abrir: '+str(exc)


def stock_changed():
    if st.session_state.bp_tp_label in STOCK:
        st.session_state.bp_tp=STOCK[st.session_state.bp_tp_label]


def lug_stock_changed():
    if st.session_state.bp_lug_t_label in STOCK:
        st.session_state.bp_lug_t=STOCK[st.session_state.bp_lug_t_label]


def use_table_spacing():
    ref=DETAIL[st.session_state.bp_db_label]
    st.session_state.bp_a1=float(ref['a1']);st.session_state.bp_a2=float(ref['a2'])
    st.session_state.bp_grout_t=float(ref['en'])


def profile_widget():
    name=st.selectbox('Pilar I ou H',['Seção I personalizada']+list(P),key='bp_column_name')
    if name in P:return P[name]
    with st.expander('Dimensões do pilar',expanded=True):
        name=st.text_input('Designação do pilar',key='bp_column_manual_name')
        vals={}
        for k,label in [('d','Altura d'),('bf','Largura bf'),('tw','Alma tw'),('tf','Mesa tf'),('clear','Altura livre sem concordâncias')]:
            vals[k]=st.number_input(label+' (mm)',min_value=.1,key='bp_column_'+k)
        area=2*vals['bf']*vals['tf']+(vals['d']-2*vals['tf'])*vals['tw']
        return Profile(name,'Soldado',max(area,1)*.00785,area=max(area,1),**vals)


def render():
    from .base_plate_report import create_report
    if 'bp_column_name' not in st.session_state:
        saved=st.session_state.get('_base_plate_project')
        seed(BasePlate.from_dict(saved,validate_values=False) if saved else PRESETS['Chumbadores · resistência externa'])
    # Restaurar campos que podem ter sido destruídos ao ficarem ocultos.
    draft=st.session_state.get('_base_plate_project',{}).get('connection',{})
    hidden={'bp_shear_mechanism':'device' if draft.get('shear_path') in ('plate','external') else draft.get('shear_path','device'),
            'bp_device_model':draft.get('shear_path') if draft.get('shear_path') in ('plate','external') else 'plate',
            'bp_anchor_shear_kgf':draft.get('anchor_shear_rd',0.)/KGF,
            'bp_anchor_shear_ref':draft.get('anchor_shear_ref',''),
            'bp_external_shear_kgf':draft.get('external_shear_rd',0.)/KGF,
            'bp_external_shear_ref':draft.get('external_shear_ref',''),
            'bp_tp':draft.get('tp',19.05),
            'bp_external_shape':draft.get('external_shape','other'),
            'bp_lug_bh':draft.get('lug_bh',100.),'bp_lug_bv':draft.get('lug_bv',100.),
            'bp_lug_t':draft.get('lug_t',19.05),'bp_lug_steel':draft.get('lug_steel','ASTM A36'),
            'bp_lug_t_label':next((k for k,v in STOCK.items() if abs(draft.get('lug_t',19.05)-v)<1e-7),'Personalizada')}
    for key,value in hidden.items():
        st.session_state[key]=st.session_state.get(key,value)
    with st.sidebar:
        st.markdown('### LRO Ligações')
        st.caption('Versão '+VERSION+' · placa de base Tipo 1')
        st.selectbox('Exemplos de placa de base',list(PRESETS),key='bp_example')
        st.button('Usar exemplo de placa de base',on_click=load_example,use_container_width=True)
        st.file_uploader('Abrir projeto de placa de base',type=['json'],key='bp_upload')
        st.button('Abrir placa de base JSON',on_click=load_json,use_container_width=True)
        if 'bp_import_error' in st.session_state:st.error(st.session_state.bp_import_error)
        st.caption('Os exemplos são didáticos, com ações identificadas. Não representam um projeto executado.')
        st.divider();st.caption(BRAND);st.link_button('LinkedIn · Lucas Oliveira',LINK)
    st.markdown('<div class="eyebrow">BASE DE PILAR · QUATRO CHUMBADORES EXTERNOS</div>',unsafe_allow_html=True)
    st.title('Placa de base Tipo 1')
    st.caption('NBR 8800:2024 corrigida em 2025 · perfil I/H · chapa sem enrijecedores · flexão no eixo de maior inércia')
    st.text_input('Identificação da base',key='bp_project')
    left,right=st.columns([.9,1.55],gap='large')
    with left:
        column=profile_widget()
        st.subheader('Ações de cálculo')
        N=st.number_input('Axial N (kgf)',key='bp_N_kgf',format='%.3f')*KGF
        M=st.number_input('Momento M (kgf·m)',key='bp_M_kgfm',format='%.3f')*KGF*1000
        V=st.number_input('Cortante V (kgf)',key='bp_V_kgf',format='%.3f')*KGF
        st.caption('Já majorados, na face superior da placa. N positivo = compressão; N negativo = tração. O sinal de M troca o lado tracionado. V está no plano da alma.')
        st.subheader('Placa e chumbadores')
        label=st.selectbox('Chumbador ASTM A36 Ø (pol.)',list(ANCHORS),key='bp_db_label')
        db=ANCHORS[label];st.caption(number(db,3)+' mm · 4 barras rosqueadas · porcas hexagonais pesadas')
        a,b=st.columns(2)
        with a:st.number_input('Folga e borda a₁ (mm)',min_value=.1,key='bp_a1',format='%.2f')
        with b:st.number_input('Passo transversal a₂ (mm)',min_value=.1,key='bp_a2',format='%.2f')
        st.button('Usar a₁/a₂ e graute da Tabela 18',on_click=use_table_spacing,use_container_width=True)
        st.caption('a₁: mesa → linha de chumbadores e linha → borda. a₂: passo entre chumbadores da mesma linha. Dimensões mostradas no desenho.')
        tp_label=st.selectbox('Espessura da placa (pol.)',list(STOCK)+['Personalizada'],key='bp_tp_label',on_change=stock_changed)
        if tp_label=='Personalizada':
            tp=st.number_input('Espessura da placa tₚ (mm)',min_value=.1,key='bp_tp',format='%.4f')
        else:
            tp=STOCK[tp_label];st.caption(number(tp,4)+' mm')
        st.selectbox('Aço da placa',[k for k,v in STEELS.items() if v.plate_allowed],key='bp_plate_steel')
        with st.expander('Concreto e assentamento',expanded=True):
            st.number_input('Concreto fck (MPa)',min_value=20.,max_value=50.,key='bp_fck')
            st.number_input('Argamassa expansiva fck (MPa)',min_value=1.,key='bp_grout_fck')
            st.number_input('Espessura de graute e (mm)',min_value=.1,key='bp_grout_t')
            st.caption('Graute ≥ 2fck. Concreto de densidade normal; resistência aos 28 dias. A2/A1=1, sem aumento presumido por confinamento. γa1=1,10; γa2=1,35; γc=1,40.')
        with st.expander('Caminho resistente do cortante',expanded=True):
            mechanism=st.selectbox('Transferência de V',['anchors','device','friction'],key='bp_shear_mechanism',format_func=lambda x:{'anchors':'Chumbadores · resistência documentada para esta combinação','device':'Barra ou chave de cisalhamento','friction':'Atrito placa/graute expansivo'}[x])
            if mechanism=='device':
                path=st.selectbox('Modelo da barra ou chave',['plate','external'],key='bp_device_model',format_func=lambda x:'Chapa retangular · verificações locais' if x=='plate' else 'Cruciforme, perfil W ou outro · memória externa')
            else:path=mechanism
            st.session_state.bp_shear_path=path
            if path=='anchors':
                st.number_input('VRd do grupo instalado para a combinação atual (kgf)',min_value=0.,key='bp_anchor_shear_kgf')
                st.text_input('Referência da memória de cortante dos chumbadores',key='bp_anchor_shear_ref')
                st.warning('Esta rota só compara a resistência documentada do conjunto. Resistência ao corte, interação tração–cisalhamento, efeitos locais e transferência ao concreto não são calculados no app. A memória deve cobrir o grupo efetivamente mobilizado, furos/arruelas/soldas, tração–corte–flexão do aço, ruptura/pryout/bordas/grupo no concreto, os esforços combinados e a excentricidade da reação. Não se admite 4 × resistência isolada sem verificação do grupo. Esta rota preserva M informado, sem transporte automático V·e; a memória externa deve fornecer as ações resultantes adequadas para a base. Não se soma atrito nem chave.')
            elif path=='external':
                st.selectbox('Geometria do dispositivo externo',list(EXTERNAL_SHAPES),key='bp_external_shape',format_func=EXTERNAL_SHAPES.get)
                st.number_input('Resistência de cálculo do dispositivo (kgf)',min_value=0.,key='bp_external_shear_kgf')
                st.text_input('Referência da memória do dispositivo',key='bp_external_shear_ref')
                st.caption('Informe a resistência do caminho completo, incluindo dispositivo, soldas e transferência ao bloco. O app só compara; não calcula esse dispositivo. Para cruciforme e perfil W, a orientação e todas as dimensões constam da memória externa. Ela deve incluir a excentricidade da reação e os esforços correspondentes na base. Esta rota preserva M informado, sem transformação automática. Não se soma atrito.')
            elif path=='plate':
                st.number_input('Largura da chave bh (mm)',min_value=.1,key='bp_lug_bh',format='%.2f')
                st.number_input('Projeção abaixo da placa bv (mm)',min_value=.1,key='bp_lug_bv',format='%.2f')
                lug_label=st.selectbox('Espessura da chave (pol.)',list(STOCK)+['Personalizada'],key='bp_lug_t_label',on_change=lug_stock_changed)
                if lug_label=='Personalizada':
                    st.number_input('Espessura da chave tpv (mm)',min_value=.1,key='bp_lug_t',format='%.4f')
                else:st.caption(number(STOCK[lug_label],4)+' mm')
                st.selectbox('Aço da chave',[k for k,v in STEELS.items() if v.plate_allowed],key='bp_lug_steel')
                st.caption('Uma chapa vertical maciça, centrada sob a base: bh paralelo a B; V perpendicular à face. bv inclui o graute real en e deve ser maior que en. Sem soma de atrito.')
                st.warning('M e V na face superior da placa, sem incluir previamente V·eV. O app soma Mef=M+V·[tp+(bv+en)/2] uma única vez. V positivo → +x; M positivo horário → compressão no lado +x do corte.')
            else:
                st.caption('μ=0,45 conforme NBR, com limitação pelo graute/concreto. Sem compressão de contato, o atrito é nulo; não se atribui cortante automaticamente às barras.')
        with st.expander('Observações da base'):st.text_area('Observações',key='bp_notes')
    s=st.session_state
    c=BasePlate(column,project=s.bp_project,plate_steel=s.bp_plate_steel,tp=tp,db=db,a1=s.bp_a1,a2=s.bp_a2,
        fck=s.bp_fck,grout_fck=s.bp_grout_fck,grout_t=s.bp_grout_t,N=N,M=M,V=V,shear_path=s.bp_shear_path,
        external_shear_rd=s.get('bp_external_shear_kgf',0.)*KGF,
        external_shear_ref=s.get('bp_external_shear_ref',''),notes=s.bp_notes,
        external_shape=s.get('bp_external_shape','other'),lug_bh=s.get('bp_lug_bh',100.),
        lug_bv=s.get('bp_lug_bv',100.),lug_t=STOCK.get(s.get('bp_lug_t_label'),s.get('bp_lug_t',19.05)),
        lug_steel=s.get('bp_lug_steel','ASTM A36'),
        anchor_shear_rd=s.get('bp_anchor_shear_kgf',0.)*KGF,
        anchor_shear_ref=s.get('bp_anchor_shear_ref',''),
        anchor_shear_confirmation=s.get('bp_anchor_shear_confirmation',draft.get('anchor_shear_confirmation','')))
    if c.shear_path=='anchors':
        with left:
            confirmed=st.checkbox('Confirmo que a memória documentada verifica este grupo instalado para a combinação atual N–M–V, seu detalhamento e a excentricidade da reação.',
                value=c.anchor_capacity_confirmed,key='bp_anchor_confirm_'+c.anchor_shear_signature[:20])
            st.caption('Declaração técnica de aplicabilidade da memória externa, sem certificar a base pelo app. A confirmação perde efeito se mudar ação, geometria, material, capacidade ou referência.')
        c=replace(c,anchor_shear_confirmation=c.anchor_shear_signature if confirmed else '')
        s.bp_anchor_shear_confirmation=c.anchor_shear_confirmation
    # Chaves não-widget sobrevivem à troca de família e a widgets ocultos.
    # Os campos externos ocultos também são reconstituídos do rascunho salvo.
    previous=s.get('_base_plate_project',{}).get('connection',{})
    if c.shear_path=='friction':
        c=replace(c,external_shear_rd=s.get('bp_external_shear_kgf',previous.get('external_shear_rd',0.)/KGF)*KGF,
                  external_shear_ref=s.get('bp_external_shear_ref',previous.get('external_shear_ref','')))
    s['_base_plate_project']=c.to_dict()
    encoded=json.dumps(c.to_dict(),ensure_ascii=False,indent=2,allow_nan=False)
    digest=hashlib.sha256(encoded.encode()).hexdigest()
    if s.get('bp_report',('',False,b''))[0]!=digest:s.pop('bp_report',None)
    r=evaluate(c);a=r.geometry
    can_draw=not any(i.severity=='error' for i in r.issues)
    with right:
        st.subheader('Resultados desta base')
        if r.component_status=='ATENDE ÀS VERIFICAÇÕES REALIZADAS':st.success(r.component_status+' · componentes abaixo')
        elif r.component_status.startswith('VERIFICAÇÃO'):st.warning(r.component_status)
        else:st.error(r.component_status)
        st.warning('Base completa: ancoragem no concreto, bloco armado e soldas do pilar a complementar.')
        st.caption('O resultado da chapa e do aço dos chumbadores não confirma a resistência da ancoragem, das soldas ou a rigidez da base.')
        if c.shear_path=='anchors':
            st.warning('Chumbadores ao cortante: comparação documental. Interação tração–cisalhamento e caminho até o concreto a verificar na memória externa.')
        if c.shear_path=='plate':
            st.warning('Chave de chapa: contato, flexão e cisalhamento locais calculados. Soldas, metal-base, flexão local da placa na ligação da chave, ruptura do concreto e bloco armado a complementar. O dispositivo completo permanece pendente.')
        x,y,z=st.columns(3)
        x.metric('Placa L × B',f'{number(c.L,1)} × {number(c.B,1)} mm')
        y.metric('Regime N–M',a.get('case','Sem solução'))
        z.metric('tₚ requerido',number(a['t_required'],2)+' mm' if a else '—')
        if can_draw:st.image(image_bytes(c,r),width='stretch')
        for i in r.issues:
            if i.severity=='pending' and i.origin!='data':continue
            if i.severity in ('error','model','noncompliance'):st.error(i.text)
            elif i.severity in ('pending','interference'):st.warning(i.text)
            else:st.caption(i.text)
        if a:
            if c.shear_path=='plate':
                st.write(f'M na face superior={number(c.M/(KGF*1000),3)} kgf·m; eV={number(a["eV"],3)} mm; ΔM={number(a["delta_M"]/(KGF*1000),3)} kgf·m; Mef={number(a["M_effective"]/(KGF*1000),3)} kgf·m.')
                lug=a['lug']
                with st.expander('Ações prescritas para dimensionar as soldas da chave',expanded=True):
                    st.write(f'Vw=Vbearing,Rd={number(lug["weld_V"]/KGF,3)} kgf; Mw=Vbearing,Rd·(bv+en)/2={number(lug["weld_M"]/(KGF*1000),3)} kgf·m.')
                    st.caption('NBR 6.7.2.4: usar a resistência de contato do concreto, mesmo se maior que |V| ou que a resistência do aço da chave. Resistência/detalhamento das soldas e transferência ao metal-base não calculados nesta versão.')
            x,y=st.columns(2)
            x.metric('Tração máxima por barra',number(a['Ft_max']/KGF)+' kgf')
            y.metric('Compressão de contato C',number(a['C']/KGF)+' kgf')
            with st.expander('Equilíbrio e distribuição das reações'):
                st.write(f'Bloco equivalente de compressão: lc={number(a["lc"],3)} mm; σSd={number(a["sigma"],4)} MPa; σRd={number(c.sigma_rd,4)} MPa.')
                st.write(f'Cada linha contém dois chumbadores. Tração individual: linha mais solicitada={number(a["Ft_max"]/KGF)} kgf; outra linha={number(a["Ft_min"]/KGF)} kgf.')
                st.write(f'Tração total={number(a["T_total"]/KGF)} kgf. Espessura por contato={number(a["t_contact"],3)} mm; por tração={number(a["t_tension"],3)} mm.')
                st.caption(f'Checagem estática: C−ΣT=N; resíduos N={a["residual_N"]:.3e} N e M={a["residual_M"]:.3e} N·mm. Não é cálculo de deslocamento, abertura ou rigidez rotacional.')
    if r.checks:
        st.subheader('Verificações realizadas')
        rows=[]
        for row in r.checks:
            sd,unit=display(row.demand,row.unit);rd,_=display(row.resistance,row.unit)
            rows.append({'Componente / verificação':row.name,'Solicitação':sd,'Resistência / limite':rd,
                         'Unidade':unit,'Índice':round(row.ratio,3),'Resultado':'Atende' if row.passed else 'Não atende'})
        st.dataframe(pd.DataFrame(rows),hide_index=True,width='stretch')
        with st.expander('Equações, substituições e referências'):
            for row in r.checks:
                st.markdown('**'+row.name+'**');st.code(row.equation,language=None)
                st.caption(row.substitution+' | '+row.variables);st.caption(row.reference)
    if can_draw:
        ref=detail_reference(c)
        with st.expander('Detalhamento de referência da Tabela 18 corrigida'):
            st.write('Referência construtiva para '+ref['label']+'. Não é verificação da ancoragem ou do bloco do projeto.')
            st.write(f'Furo da placa: {number(ref["df"])} mm. Arruela especial: {number(ref["washer_side"])} × {number(ref["washer_side"])} × {number(ref["washer_t"])} mm, aço fy=345 MPa; furo {number(ref["washer_hole"],3)} mm.')
            st.write(f'Ancoragem tabulada: h1={ref["h1"]} mm; h2={ref["h2"]} mm; r1={ref["r1"]} mm; r2={ref["r2"]} mm. Conferir posições na Tabela 18.')
            st.write(f'Bloco de referência Nb×Bb×Ab: {number(ref["Nb"])} × {number(ref["Bb"])} × {number(ref["Ab"])} mm. Armadura mínima tabulada: Ø{number(ref["rebar_diameter"])} a cada {number(ref["S"])} mm; da≤{number(ref["da_max"])} mm.')
            st.caption('Nb=max(Nb,min; L+2en; L+2(a3−a1)); Bb=max(B+2en; B+2(a3−a1)); Ab=max(h1+100; Nb). Valores corrigidos em 2025. A armadura deve ser dimensionada conforme NBR 6118; os mínimos tabulados não aprovam o bloco.')
    st.subheader('Salvar projeto e memória')
    x,y,z=st.columns(3)
    x.download_button('Baixar placa de base JSON',encoded,'Placa_de_base_LRO.json','application/json',use_container_width=True)
    if can_draw:y.download_button('Baixar desenho da base SVG',image_bytes(c,r,'svg'),'Placa_de_base_LRO.svg','image/svg+xml',use_container_width=True)
    detailed=st.checkbox('Memória detalhada da placa de base',key='bp_detailed')
    if z.button('Gerar memória da placa de base',disabled=not bool(a),use_container_width=True):
        s.bp_report=(digest,detailed,create_report(c,r,detailed))
    saved=s.get('bp_report')
    if saved and saved[0]==digest and saved[1]==detailed:
        st.download_button('Baixar memória da placa de base .docx',saved[2],'Memoria_placa_de_base_LRO.docx','application/vnd.openxmlformats-officedocument.wordprocessingml.document')
    st.divider();st.subheader('Alcance deste modelo')
    st.write('Geometria normativa Tipo 1, sem enrijecedores, com quatro chumbadores externos. C1/C2/C3 e T1/T2/T3 são selecionados automaticamente pelos esforços. Outro arranjo de placa, chumbadores ou enrijecedores pode ser viável e precisa de um modelo próprio.')
    with st.expander('Premissas adotadas e verificações complementares'):
        for text in c.assumptions:st.write(text)
    st.caption(BRAND)
