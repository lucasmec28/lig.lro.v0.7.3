"""Editable canonical calculation record for one axial 1L bolted connection.

Every public export re-evaluates its current input. Caller-provided evaluation
objects cannot approve a draft or substitute another connection's witnesses.
"""
from dataclasses import fields, is_dataclass
from collections import OrderedDict
from io import BytesIO

from docx import Document
from docx.enum.section import WD_ORIENT, WD_SECTION_START
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Inches, Pt, RGBColor
from docx.oxml.ns import qn

from .angle_catalog_selection import provenance_text, LABELS as CATALOG_LABELS
from .axial_single_angle_drawing import approved, image_bytes, validated_result
from .axial_single_angle_presentation import physical_envelopes
from .models import BOLTS, STEELS, finite_real
from .report import BRAND, _math, group, table


LABELS = {
    'project': 'Projeto', 'profile_name': 'Perfil declarado', 'profile_source': 'Fonte das propriedades',
    'leg': 'Aba L em mm', 't': 'Espessura L em mm', 'Ag': 'Área bruta da cantoneira única em mm²',
    'ec': 'ec catalogado da cantoneira em mm', 'root_radius': 'Raio interno declarado em mm',
    'angle_steel': 'Aço da cantoneira única', 'plate_steel': 'Aço da chapa única',
    'plate_width': 'Largura real da chapa em mm', 'plate_t': 'Espessura real da chapa em mm',
    'bolt': 'Classe dos parafusos', 'db': 'Diâmetro nominal em mm', 'n': 'Parafusos em corte simples',
    'pitch': 'Passo longitudinal em mm', 'gauge': 'Gabarito desde o talão em mm',
    'angle_end': 'Extremidade carregada L até último parafuso em mm',
    'plate_end': 'Extremidade carregada da chapa até primeiro parafuso em mm',
    'terminal_extension': 'Extensão além da ponta L até corte em mm',
    'drilled': 'Furação por broca documentada', 'threads_excluded': 'Rosca excluída do plano único', 'pretensioned': 'Protensão declarada',
    'exposure': 'Exposição', 'tool_radius': 'Raio do envelope ferramenta e ferragens em mm',
    'fabrication_clearance': 'Folga adicional de montagem em mm', 'N': 'N real em N',
    'V': 'V real em N', 'M': 'M real em N mm', 'torsion': 'Torção real em N mm',
    'static': 'Ações estáticas', 'normal_combination': 'Combinação normal',
    'angle_count': 'Quantidade de cantoneiras', 'minimum_force': 'Política de força mínima 45 kN',
    'recommend_half_capacity': 'Recomendação opcional 50 por cento', 'notes': 'Observações',
}
PATH_LABELS = {
    'whole_angle_section': 'seção bruta da cantoneira única',
    'whole_angle_one_hole': 'seção da cantoneira única com um furo deduzido',
    'real_full_width_section': 'seção de toda a largura real da chapa',
    'real_full_width_one_hole': 'largura real da chapa com um furo deduzido',
    'terminal_unperforated_cut': 'corte terminal em chapa contínua sem furos',
    'angle_plate_interface': 'interface entre a cantoneira única e a chapa',
    'loaded_free_end': 'borda livre real na direção da força',
    'next_hole_in_force_direction': 'ligamento até o próximo furo na direção da força',
    'toe': 'ponta livre da aba conectada',
    'far_toe_unfolded': 'outra ponta livre com rota desenvolvida ao redor do talão',
    'lower_side': 'borda lateral real y=0 da chapa',
    'upper_side': 'borda lateral real y=b da chapa',
}


def _label(value):
    text=str(value)
    for native,display in [('far_toe_unfolded','outra ponta desenvolvida'),
                           ('lower_side','borda lateral inferior'),
                           ('upper_side','borda lateral superior'),
                           ('angle','Cantoneira única'),('plate','Chapa'),('toe','ponta livre')]:
        text=text.replace(native,display)
    return text


def _value(value):
    if value is None:
        return 'não disponível'
    if isinstance(value, bool):
        return 'sim' if value else 'não'
    if isinstance(value, (int, float)):
        if not finite_real(value):
            return str(value) + ' (inválido)'
        return f'{value:.6f}'.rstrip('0').rstrip('.') if isinstance(value,float) else str(value)
    if isinstance(value, dict):
        return '; '.join(str(key)+'='+_value(child) for key,child in value.items())
    if isinstance(value, (list,tuple)):
        return '[' + ', '.join(_value(child) for child in value) + ']'
    return str(value)


def _kn(value):
    return _value(value/1000) if finite_real(value) else 'não disponível'


def _mapping(value):
    return value if isinstance(value,dict) else {}


def _flatten(value, path=''):
    if isinstance(value,dict):
        for key, child in value.items():
            yield from _flatten(child, path+'.'+str(key) if path else str(key))
    elif isinstance(value,(list,tuple)) and any(isinstance(child,(dict,list,tuple)) for child in value):
        for index,child in enumerate(value):
            yield from _flatten(child,path+'['+str(index)+']')
    else:
        yield path,_value(value)


def _tab(doc, headers, rows, widths, size=8.3):
    result = table(doc,headers,rows,widths)
    for row in result.rows:
        for cell in row.cells:
            for p in cell.paragraphs:
                p.alignment = WD_ALIGN_PARAGRAPH.LEFT
                for run in p.runs:
                    run.font.size=Pt(size)
    # The common helper adds a blank paragraph. Keep that separator compact.
    gap=doc.paragraphs[-1]
    gap.paragraph_format.space_before=gap.paragraph_format.space_after=Pt(0)
    gap.paragraph_format.line_spacing=Pt(2)
    for run in gap.runs:run.font.size=Pt(1)
    return result


def _heading(doc,text,level=1):
    return doc.add_paragraph(text,style='Heading '+str(level))


def _section(doc,landscape=False):
    s=doc.add_section(WD_SECTION_START.NEW_PAGE)
    s.orientation=WD_ORIENT.LANDSCAPE if landscape else WD_ORIENT.PORTRAIT
    s.page_width=Inches(16.54 if landscape else 8.27)
    s.page_height=Inches(11.69)
    s.top_margin=s.bottom_margin=Inches(.55)
    s.left_margin=s.right_margin=Inches(.60)
    return s


def _inputs(doc,c,result):
    _heading(doc,'Dados de entrada e materiais')
    doc.add_paragraph('As unidades nativas são N, mm e MPa. As tabelas resistentes identificam explicitamente kN. A carga informada não é substituída por uma carga mínima, nem pela recomendação opcional de projeto.')
    rows=[(CATALOG_LABELS.get(f.name, LABELS.get(f.name,f.name))+'\n'+f.name,_value(getattr(c,f.name))) for f in fields(c)] if is_dataclass(c) else [('Entrada',_value(c))]
    _tab(doc,['Grandeza e identificador nativo','Valor atual'],rows,[4.0,3.07])
    if c.angle_catalog_id:
        doc.add_paragraph(provenance_text(c))
    else:
        doc.add_paragraph('Referência do exemplo inicial, sem substituir a fonte do perfil atual: Souza, PDF 162, tabela de cantoneira dupla 3 × 1/4, fornece Ag do par 1858 mm². Para a cantoneira única L76 × 6,35, Ag=1858/2=929 mm² e ec=21,3 mm por simetria das abas iguais. A tabela de cantoneiras simples, PDF 160, confirma Ag=9,29 cm² e Xg=Yg=2,13 cm, mas arredonda t para 6,3 mm. Aqui se conserva a dimensão explícita 6,35 mm do PDF 162. As propriedades atuais acima prevalecem; o nome do perfil não substitui edições. Não se recalcula Ag por cantos vivos enquanto se conserva ec de catálogo; propriedades e geometria devem representar o mesmo produto.')
    doc.add_paragraph('No exemplo manual, o raio interno 6 mm e o envelope de ferramenta 18 mm com folga 2 mm são apenas valores declarados do exemplo moderno editável. Não são dimensões de fabricante extraídas de Souza nem ferragens ASTM inferidas de uma tabela ISO. Conferir o perfil e o conjunto de montagem efetivamente adquiridos.')
    rows=[]
    for label,key in (('Cantoneira única','angle_steel'),('Chapa','plate_steel')):
        name=getattr(c,key,None); steel=STEELS.get(name) if isinstance(name,str) else None
        rows.append((label,str(name),'fy='+_value(getattr(steel,'fy',None))+'; fu='+_value(getattr(steel,'fu',None))+' MPa'))
    bolt_name=getattr(c,'bolt',None)
    bolt=BOLTS.get(bolt_name) if isinstance(bolt_name,str) else None
    fub=bolt if isinstance(bolt,(int,float)) else getattr(bolt,'fu',getattr(bolt,'fub',None))
    rows.append(('Parafusos',str(getattr(c,'bolt',None)),'fub='+_value(fub)+' MPa'))
    _tab(doc,['Componente','Material','Resistências características'],rows,[1.3,2.6,3.17])
    doc.add_paragraph('Coeficientes de combinações normais: γa1=1,10 e γa2=1,35. Outro tipo de combinação está fora desta implementação. Não há crédito por atrito, solda ou enchimento. Há contato firme direto em uma face e exatamente um plano de corte por parafuso.')


def _loads(doc,c,result):
    _heading(doc,'Modelo nominal e ações preservadas')
    doc.add_paragraph('Adota-se exclusivamente a exceção estática nominal de extremidade de cantoneiras simples da NBR 8800:2024, 6.1.8.2, com remissão de 6.5.2. N atua no eixo da linha de parafusos, coincidente com o eixo da chapa. A excentricidade física entre o centroide da cantoneira e essa linha é mostrada como geometria omitida por essa idealização normativa; não se afirma que os centroides coincidem.')
    doc.add_paragraph('A cantoneira única fica na face positiva da chapa e transmite N integral. Cada parafuso e seu único plano de corte recebem N/n; ambas as verificações de contato recebem N/n nas espessuras reais. Na chapa, as forças dos parafusos apontam para −x e sua borda carregada está em x=0. Na cantoneira, apontam para +x e a borda carregada está além do último parafuso. O talão dobrado não é borda livre.')
    doc.add_paragraph('O eixo nominal está em y=b/2 e z=0, no plano médio da chapa. O centroide físico da cantoneira está em y=b/2−g+ec e z=tp/2+ec. Os afastamentos yCG−ynom=ec−g e zCG−znom=tp/2+ec são omitidos pelo modelo estático adotado, não cancelados. A separação entre os planos médios da aba conectada e da chapa é (tp+t)/2. No exemplo padrão: CG=(y36,3; z27,55) mm; eixo nominal=(y50; z0) mm; afastamentos −13,7 e +27,55 mm; separação 9,425 mm. O ec=21,3 mm permanece ativo no Ct de cisalhamento diferido. Esses números descrevem apenas o exemplo padrão; os valores da entrada atual constam nas tabelas.')
    doc.add_paragraph('Esta interpretação nominal de 6.1.8.2 e 6.5.2 não demonstra equilíbrio tridimensional de uma força aplicada no CG físico. Um modelo de carga no CG real, com ações secundárias de contato, flexão e torção, está fora deste componente. Não se introduzem momentos diagnósticos de outro modelo no cálculo nominal nem se afirma cancelamento por simetria.')
    _tab(doc,['Ação real preservada','Valor','Unidade'],[(key,_value(getattr(c,key,None)),unit) for key,unit in
        (('N','N'),('V','N'),('M','N mm'),('torsion','N mm'))],[3.8,1.5,1.77])
    cases=result.get('cases') or []
    _tab(doc,['Caso independente','Identificador','N em kN'],
         [(case.get('label',''),case.get('id',''),_kn(case.get('N'))) for case in cases], [3.7,1.8,1.57])
    doc.add_paragraph('N=0 permanece um caso real com demanda zero. Nesta ligação ordinária de extremidade, 6.1.5.2 exige o caso separado de 45 kN quando N real é menor; nenhuma exceção de treliçamento foi implementada. Desativar esse mínimo com N menor que 45 kN bloqueia a aprovação. A recomendação opcional de 50% de Nt,Rd de 6.1.5.3 é outro caso de projeto, com a resistência de tração e seu modo governante registrados. Esses casos não são somados entre si. O módulo não fornece capacidade global de compressão nem presume a exceção de barras com esbeltez governante.')
    doc.add_paragraph('O corte terminal é ortogonal, centrado e está além da zona dos parafusos e da ponta da cantoneira, em chapa contínua de largura e espessura reais. No modelo nominal puro N, esse corte transmite N e M=0 em seu centro. Uma referência transversal deslocada requer o momento r×N correspondente. Entradas com M, V, torção, compressão ou ações não estáticas não recebem aprovação por verificações de N puro.')
    lm=_mapping(result.get('load_model'))
    if lm:
        omit={'terminal_actions','terminal_actual','description','actual_actions'}
        _tab(doc,['Campo do modelo de ações','Valor retornado'],list(_flatten({k:v for k,v in lm.items() if k not in omit})),[3.4,3.67],size=8)
        actions=lm.get('terminal_actions') or []
        if actions:
            doc.add_paragraph('Resultantes do modelo nominal candidato no corte. Fora do domínio das ações, não são uma solução das ações combinadas reais.')
            _tab(doc,['Caso','Ponto e referência mm','Forças em N','Momentos em N mm'],
                 [(v.get('case_id',''),
                   'x='+_value(v.get('x'))+'; y='+_value(v.get('y'))+'; z='+_value(v.get('z'))+
                   '\nreference_x='+_value(v.get('reference_x'))+'; reference_y='+_value(v.get('reference_y'))+
                   '; reference_z='+_value(v.get('reference_z')),
                   'N='+_value(v.get('N'))+'; V='+_value(v.get('V'))+'\nFx='+_value(v.get('Fx'))+
                   '; Fy='+_value(v.get('Fy'))+'; Fz='+_value(v.get('Fz')),
                   'Mx='+_value(v.get('Mx'))+'; My='+_value(v.get('My'))+'; Mz='+_value(v.get('Mz'))+
                   '\nM='+_value(v.get('M'))+'; torção='+_value(v.get('torsion'))) for v in actions],
                 [1.1,2.7,1.57,1.7],size=7.8)

    else:
        doc.add_paragraph('Modelo de ações não executado para esta entrada. Nenhuma resultante terminal favorável é presumida.')


def _geometry(doc,result):
    _heading(doc,'Geometria real seções e detalhamento')
    doc.add_paragraph('A chapa tem uma única espessura e largura retangular constante, duas bordas laterais livres e uma borda carregada real. Sua área é b×tp e Ct=1 para o elemento diretamente conectado; não se aplica espalhamento Whitmore. O limite 0,85Ag de 6.5.3 para chapas de emenda parafusadas não é transportado automaticamente a esta chapa de nó.')
    for key,label in (('geometry','Geometria e verificações físicas'),('sections','Áreas e coeficientes de redução')):
        data=_mapping(result.get(key))
        if data:
            _heading(doc,label,2)
            _tab(doc,['Campo nativo','Valor e unidade indicada no campo'],list(_flatten({k:v for k,v in data.items() if k!='checks'})),[3.4,3.67],size=8)
            checks=data.get('checks') or []
            if checks:
                _tab(doc,['Verificação física e fonte','Medido','Limite','Estado'],
                     [(v.get('label','')+'\n'+v.get('id','')+'\n'+v.get('reference',''),
                       _value(v.get('actual'))+' '+v.get('units',''),str(v.get('relation',''))+' '+_value(v.get('limit')),
                       v.get('status','')) for v in checks],[4.05,1.0,1.15,.87],size=7.8)
    doc.add_paragraph('O diâmetro físico dh segue a Tabela 14. A dedução líquida dn inclui o acréscimo normativo de 2 mm quando a furação por broca não está documentada; a opção não altera o furo desenhado. A espessura de aperto é t+tp. A redução de 6.3.7 para grip além de 5db, quando aplicável ao tipo de protensão, e a condição de rosca são verificadas no único plano físico de corte.')
    _heading(doc,'Equações e caminhos físicos',2)
    for expression in (
        'An,L = Ag,L − dn t;  Ct = max(1 − ec/lc, Ac/Ag);  Ae = Ct An',
        'Nt,Rd,y = Ag fy / γa1;  Nt,Rd,u = Ae fu / γa2',
        'Ag,chapa = b tp;  An,chapa = (b − dn) tp;  Ct,chapa = 1',
        'Fv,Rd,plano = αv Ab fub / γa2 × fator de grip;  αv = 0,45 ou 0,56',
        'Fb,Rd = min(1,2 lc,livre t fu; 2,4 db t fu) / γa2',
        'Rbloco = min(0,6 fu Anv + Cts fu Ant; 0,6 fy Agv + Cts fu Ant) / γa2',
    ):
        _math(doc,group(expression))
    doc.add_paragraph('Cada caminho em bloco identifica o bordo livre real, a direção carregada, o subconjunto de parafusos encerrado e suas áreas Agv, Anv e Ant. A demanda do subconjunto é kN/n na cantoneira única e kN/n na chapa. Os caminhos para lados opostos da chapa são alternativas: cada um recebe conservadoramente toda a força dos parafusos encerrados; as capacidades não são somadas. A rota ao outro bordo livre da cantoneira é desenvolvida ao redor do talão, que não é inventado como corte livre.')


def _checks(doc,result):
    envelopes=physical_envelopes(result)
    _heading(doc,'Envelopes físicos e testemunhos completos')
    doc.add_paragraph('Cada envelope reúne apenas um componente físico e um mecanismo. Conserva todas as linhas primitivas, seus casos, caminhos e empates governantes. Não se somam resistências de elementos em série nem capacidades de caminhos alternativos. O máximo real é separado do máximo entre casos de projeto.')
    if not envelopes:
        doc.add_paragraph('Nenhuma verificação resistente foi produzida. Este documento não constitui aprovação.')
        return
    _tab(doc,['Componente e mecanismo','η real','η envelope','Estado','Governantes e empates'],
         [(item['component_label']+'\n'+item['mechanism_label'],_value(item['actual_utilization']),
           _value(item['utilization']),item['status'],'\n'.join(str(v) for v in item['governing_ids']))
          for item in envelopes],[2.1,.65,.75,.57,3.0],size=7.8)
    doc.add_paragraph('As próximas tabelas contêm todas as '+str(len(result.get('checks',[])))+' verificações primitivas. Sd e Rd estão em kN; equivalent_capacity_N, quando presente nos testemunhos, está em N. Áreas estão em mm², comprimentos em mm, coeficientes são adimensionais. Índices e planos identificam entidades físicas, não multiplicadores de espessura.')
    standard={'id','label','component','mechanism','case_id','demand','resistance','utilization','status','primitive_id'}
    for envelope in envelopes:
        _heading(doc,envelope['component_label']+' '+envelope['mechanism_label'],2)
        primitives=OrderedDict()
        for row in envelope['members']:
            primitives.setdefault(row.get('primitive_id',row.get('id')),[]).append(row)
        for primitive,members in primitives.items():
            first=members[0]
            # Shared witness printed once only when genuinely identical across cases.
            witnesses=[{k:v for k,v in row.items() if k not in standard} for row in members]
            shared=all(value==witnesses[0] for value in witnesses)
            label=_label(first.get('label',''))
            doc.add_paragraph(label+' | '+str(primitive),style='Heading 3')
            t=_tab(doc,['ID e caso preservados','Sd kN','Rd kN','η','Estado'],
                 [(str(row.get('id',''))+'\n'+str(row.get('case_id','')),_kn(row.get('demand')),
                   _kn(row.get('resistance')),_value(row.get('utilization')),str(row.get('status',''))) for row in members],
                 [3.5,1.0,1.0,.85,.72],size=7.8)
            for cell in t.rows[-1].cells:
                for p in cell.paragraphs:p.paragraph_format.keep_with_next=True
            doc.paragraphs[-1].paragraph_format.keep_with_next=True
            for index,witness in enumerate(witnesses[:1] if shared else witnesses):
                if not shared:doc.add_paragraph('Testemunho do caso '+str(members[index].get('case_id')))
                translated='Caminho físico: '+PATH_LABELS.get(witness.get('path'),str(witness.get('path','seção identificada')))+'. '
                p=doc.add_paragraph(translated+'; '.join(key+'='+value for key,value in _flatten(witness)))
                p.paragraph_format.space_after=Pt(8)
                p.paragraph_format.keep_together=True
                for run in p.runs:run.font.size=Pt(8)


def create_report(c, result=None):
    result=validated_result(c,result)
    doc=Document()
    section=doc.sections[0]
    section.page_width=Inches(8.27);section.page_height=Inches(11.69)
    section.top_margin=section.bottom_margin=Inches(.55)
    section.left_margin=section.right_margin=Inches(.6)
    normal=doc.styles['Normal'];normal.font.name='Calibri';normal.font.size=Pt(10)
    normal.paragraph_format.space_after=Pt(6)
    for name,size in (('Title',22),('Subtitle',11),('Heading 1',14),('Heading 2',11),('Heading 3',10)):
        style=doc.styles[name];style.font.name='Calibri';style.font.size=Pt(size);style.font.color.rgb=RGBColor.from_string('000000')
        style.font.underline=False
        style.paragraph_format.space_before=Pt(12 if name=='Heading 1' else 6)
        style.paragraph_format.space_after=Pt(4)
        for border in list(style.element.iter(qn('w:pBdr'))):border.getparent().remove(border)
    doc.add_paragraph('Ligação axial de cantoneira única à chapa retangular',style='Title')
    doc.add_paragraph('Memória de cálculo da ligação parafusada local',style='Subtitle')
    p=doc.add_paragraph();p.add_run('ATENDIMENTO LOCAL NO DOMÍNIO DECLARADO' if approved(result) else 'SEM APROVAÇÃO GLOBAL').bold=True
    doc.add_paragraph('Estado do motor: '+str(result.get('status','NOT_EVALUATED')))
    doc.add_paragraph('Projeto: '+str(getattr(c,'project','')))
    doc.add_paragraph('Esta memória verifica uma ligação de extremidade sob tração estática: uma cantoneira de abas iguais em uma face de uma chapa retangular única, uma linha longitudinal de parafusos e um corte terminal após a transferência de força. A raiz da chapa, suas soldas e o apoio seguinte não são verificados. O resultado se limita aos dados e ao domínio expressamente registrados aqui.')
    from .axial_single_angle import COMPONENT_VERSION
    doc.add_paragraph('Componente '+COMPONENT_VERSION+'. Referência resistente: ABNT NBR 8800:2024 com Errata 1 de 25 de fevereiro de 2025. Souza, Exemplo 9.1 e Figuras 9.3 e 9.4, PDF 118–119, documenta uma ligação de chapas em corte simples e apoia o modelo nominal de recobrimento; não é um exemplo resolvido de cantoneira única. O Exemplo 9.2, PDF 120–121, tem duas cantoneiras e não é relabelado como 1L. Seus coeficientes históricos não substituem os critérios normativos atuais.')
    for issue in result.get('issues') or []:
        doc.add_paragraph(str(issue.get('severity',''))+' | '+str(issue.get('id',''))+': '+str(issue.get('message','')))
    summary=_mapping(result.get('summary'))
    governor=next((row for row in result.get('checks',[]) if row.get('id')==summary.get('capacity_governing_id')),None)
    max_governor=next((row for row in result.get('checks',[]) if row.get('id')==summary.get('governing_id')),None)
    rows=[
        ('Verificações locais completas','sim' if summary.get('complete_checks') else 'não'),
        ('Capacidade equivalente total N em kN',_kn(summary.get('governing_capacity_N'))),
        ('Mecanismo da menor capacidade',_label(governor.get('label')) if governor else 'não disponível'),
        ('Maior utilização entre os casos',_value(summary.get('utilization'))),
        ('Verificação de maior utilização',_label(max_governor.get('label')) if max_governor else 'não disponível'),
        ('Quantidade de verificações primitivas',str(len(result.get('checks',[])))),
        ('Detalhamento atendido','sim' if summary.get('detailing_pass') else 'não'),
        ('Verificações resistentes não atendidas',str(len(summary.get('failed_check_ids') or []))),
    ]
    _tab(doc,['Resumo da avaliação local','Resultado'],rows,[3.4,3.67])
    _inputs(doc,c,result)
    _loads(doc,c,result)
    _section(doc,landscape=True)
    _heading(doc,'Desenho da entrada atual')
    p=doc.add_paragraph();p.paragraph_format.space_after=Pt(0)
    p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    p.add_run().add_picture(BytesIO(image_bytes(c,fmt='png',dpi=165)),width=Inches(12.7))
    doc.add_paragraph('Representação proporcional. Cotas e ações vêm da entrada atual; o resultado fornecido por um chamador não é usado como autorização ou geometria. O desenho de diagnóstico não cria uma configuração substituta.')
    _section(doc)
    _geometry(doc,result)
    _checks(doc,result)
    _heading(doc,'Conclusão e fronteira de responsabilidade')
    doc.add_paragraph(('Todas as verificações locais implementadas atendem dentro do domínio nominal declarado.' if approved(result)
                       else 'Esta entrada não tem aprovação global. As falhas, dados inválidos ou ações fora do domínio permanecem visíveis; verificações parciais favoráveis não removem esses bloqueios.')
                      +' A conclusão não abrange a raiz da chapa, soldas, apoio, estabilidade global, fadiga, compressão, reversão cíclica ou um nó completo.')
    doc.add_paragraph(BRAND)
    buffer=BytesIO();doc.save(buffer);return buffer.getvalue()
