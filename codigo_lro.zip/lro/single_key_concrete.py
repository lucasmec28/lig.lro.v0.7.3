"""Bounded conservative ACI318-19 single solid rectangular shear-key concrete.

Canonical N/mm/MPa. Native NBR bearing, force states and weld actions are never
modified. The three edge surfaces use real block clipping, not fictitious rods.
See docs/SINGLE_KEY_CONCRETE_COMPONENT.md for the reviewed finite contract.
"""
from dataclasses import dataclass, asdict, fields
import hashlib
import json
import math
from .models import Issue, finite_real

MODEL = 'aci318_19_conservative'
REF = ('ACI 318-19 §§17.11.1–17.11.3 e 17.7.2; AISC DG1 3ª ed., '
       '§§4.3.6/4.3.7, Ex.4.7-5, pp.78–87 · componente complementar conservador')
LIMITS = ('Componente conservador de contato e ruptura de borda da chave. Não aprova a chave, '
          'ancoragem ou base completa. Modos de tração dos chumbadores, cabeça/porca/rosca, '
          'transferência e flexão da placa receptora, armadura do bloco NBR 6118, juntas e '
          'transferência global à fundação/solo permanecem separados.')
POLICY = ('Concreto normal fissurado; λa=ψc,V=1, φ=0,65. Distâncias físicas, ψh usado=1 '
          'sem ganho de espessura ou ca1 efetivo de bloco estreito. Bordas paralelas: '
          'construção virtual tipo chumbador isolado desde o centro da chave, fator 2; ACI 17.11.3.2/17.7.2.1(c)/17.7.2.1.1. Não se afirma equivalência ou área inferior a toda projeção líquida de chave finita. '
          'Nenhum diâmetro/embutimento de barra, pryout ou distribuição V/4 no modelo da chave.')
INCH, LBF = 25.4, 4.4482216152605
PSI = LBF / INCH**2
PHI = .65


@dataclass(frozen=True)
class SingleKeyConcrete:
    model: str = 'off'
    rod_restraint: str = 'unknown'
    restraint_ref: str = ''
    filled_detail_ref: str = ''
    filled_detail_confirmed: bool = False
    vent_detail_ref: str = ''
    vents_confirmed: bool = False
    force_model_ref: str = ''
    force_model_confirmed: bool = False
    compression_policy: str = 'no_gain'
    qualification_signature: str = ''

    @classmethod
    def from_dict(cls, data):
        if not isinstance(data, dict):
            raise ValueError('Dados do concreto da chave devem ser um objeto.')
        extra = set(data) - {f.name for f in fields(cls)}
        if extra:
            raise ValueError('Campos não reconhecidos no concreto da chave: '+', '.join(sorted(extra)))
        return cls(**data)


def validate_single_key_concrete(c):
    u = getattr(c, 'single_key_concrete', None)
    if not isinstance(u, SingleKeyConcrete):
        return [Issue('error', 'Dados inválidos do concreto da chave.', REF, origin='single_key_concrete')]
    issues = []
    for f in fields(u):
        value = getattr(u, f.name)
        good = type(value) is bool if f.name.endswith('_confirmed') else isinstance(value, str)
        if not good:
            issues.append(Issue('error', 'Campo inválido do concreto da chave: '+f.name, REF, origin='single_key_concrete'))
    return issues


def _digest(data):
    # No rounding-based currency loophole: exact finite float representation.
    def stable(v):
        if isinstance(v, dict): return {k: stable(x) for k, x in v.items()}
        if isinstance(v, (list, tuple)): return [stable(x) for x in v]
        if type(v) in (float, int):
            if not finite_real(v): raise ValueError('Dados não finitos no vínculo.')
            return format(v, '.17g')
        return v
    return hashlib.sha256(json.dumps(stable(data), sort_keys=True, ensure_ascii=False, allow_nan=False).encode()).hexdigest()


def qualification_signature(c):
    """Bind active physical/model data, not dormant unrelated components."""
    u=asdict(c.single_key_concrete);u.pop('qualification_signature',None)
    if c.N<=0:u.pop('compression_policy',None)
    keys=('N','M','V','shear_path','plate_steel','tp','lug_steel','lug_t','lug_bh','lug_bv',
          'grout_t','grout_fck','fck','db','a1','a2','hef','block_xmin','block_xmax',
          'block_ymin','block_ymax','block_h','stiffener_detail')
    data={key:getattr(c,key) for key in keys}
    if data['stiffener_detail']=='web_pair_visual':data['stiffener_detail']='none'
    if c.stiffener_detail not in ('none','web_pair_visual'):
        data['stiffener']={key:getattr(c,key) for key in ('stiffener_length','stiffener_height','stiffener_t')}
    d=min(c.lug_bv-c.grout_t,2*c.lug_t)
    moments=(c.effective_moment,c.M+c.V*(c.tp+c.grout_t+d/2))
    pressures=(c.sigma_rd,PHI*.85*c.fck)
    tension=(c.N<0 or c.N==0 and any(m!=0 for m in moments) or c.N>0 and
             any(abs(m)/c.N>(c.L-c.N/(p*c.B))/2 for m,p in zip(moments,pressures)))
    if tension:
        anchor_keys=('anchor_type','anchor_head_width','anchor_head_length','anchor_head_t',
                     'anchor_bearing_t','anchor_nut_t','anchor_bottom_cover','anchor_head_hole',
                     'anchor_nut_bearing_area','anchor_detail_ref','anchor_detail_confirmed')
        data['anchor_detail']={key:getattr(c,key) for key in anchor_keys}
        cc=c.concrete_components
        data['nominal_tension']={key:getattr(cc,key) for key in ('area_tension','steel_area_ref')}
    data.update(component=u,column={key:getattr(c.column,key) for key in ('d','bf','tw','tf','clear','area')},model_type=c.model_type,L=c.L,B=c.B,a=c.a,
                pressure_aci=PHI*.85*c.fck,effective_depth=d,source_model=MODEL,policy=POLICY)
    return _digest(data)


def detail_is_current(c):
    u = c.single_key_concrete
    try:
        return (c.shear_path == 'plate' and u.model == MODEL and
                u.rod_restraint == 'unwelded' and bool(u.restraint_ref.strip()) and
                u.filled_detail_confirmed and bool(u.filled_detail_ref.strip()) and
                u.vents_confirmed and bool(u.vent_detail_ref.strip()) and
                u.force_model_confirmed and bool(u.force_model_ref.strip()) and
                bool(u.qualification_signature) and u.qualification_signature == qualification_signature(c))
    except (ValueError, TypeError, OverflowError):
        return False


def result_signature(c):
    # Results also depend on selected anchor checks and their documentation, while
    # those selection toggles do not change the physical key-detail qualification.
    return _digest(dict(qualification=qualification_signature(c),binding=c.single_key_concrete.qualification_signature,
                        component=asdict(c.single_key_concrete),concrete_components=asdict(c.concrete_components),
                        cone_model=c.cone_model,cone_subset_envelope=c.cone_subset_envelope))


def result_is_current(c, result):
    d = getattr(result, 'local_single_key_concrete', result)
    try:
        return bool(d) and c.shear_path == 'plate' and d.get('source_signature') == result_signature(c)
    except (ValueError, TypeError, OverflowError, AttributeError):
        return False


def single_key_concrete_assumptions(c):
    if c.shear_path != 'plate' or c.single_key_concrete.model == 'off': return []
    return [REF, POLICY,
            'h=H−g físico; d=min(h,2t) desde a superfície do concreto, Aef=b d. N original positivo comprime. '
            'Estado NBR e=tp+g+h/2 e estado complementar ACI e=tp+g+d/2 são simultaneamente conservados; Mbase=Mtop+Vreal e com sinais.',
            'Tipo 1: bloco retangular uniforme de largura B, linhas externas reais, sem prying. Tipo 2: apenas C1/C2/T1/T2 e linhas internas, sem fórmula C3/T3 do Tipo 1. '
            'Pressão complementar 0,65×0,85f′c, A2/A1=1; nunca presumir confinamento do exemplo.',
            'Quatro chumbadores; havendo Ti>0, hef≥2,5h físico e hef≥2,5csl. Restrição real da barra precisa de referência: solda no perímetro da arruela não é solda da barra. '
            'Graute fluido não retrátil, preenchimento/consolidação e ao menos um respiro de 25,4 mm junto a cada face longa são requisitos deste modelo opcional, sem proibição NBR universal.', LIMITS]


def _numbers(*values, positive=False):
    if not all(finite_real(v) and (not positive or v > 0) for v in values):
        raise ValueError('Valores devem ser reais finitos'+(' positivos.' if positive else '.'))


def _finite_values(*values):
    if not all(finite_real(v) for v in values):
        raise ValueError('Escala numérica excede o domínio finito do concreto da chave.')


def _rect(lo, hi, bottom):
    return [[lo, 0.], [hi, 0.], [hi, bottom], [lo, bottom]]


def key_geometry(*, b, H, g, t, bounds, ha):
    _numbers(b, H, t, ha, positive=True); _numbers(g)
    if not isinstance(bounds, (list, tuple)) or len(bounds) != 4:
        raise ValueError('Informe xmin,ymin,xmax,ymax reais do bloco.')
    _numbers(*bounds)
    xmin, ymin, xmax, ymax = bounds
    h = H-g; d = min(h, 2*t)
    if g < 0 or h <= 0 or ha <= h or not (xmin < -t/2 < t/2 < xmax and ymin < -b/2 < b/2 < ymax):
        raise ValueError('Chave física deve caber no concreto íntegro: h=H−g>0, ha>h e faces estritamente dentro do bloco.')
    Aef = b*d
    _finite_values(h, d, Aef, xmax-xmin, ymax-ymin, ha-h)
    return dict(b=b, H=H, g=g, h=h, d=d, t=t, Aef=Aef, bounds=list(bounds), ha=ha,
                physical_key_polygon=_rect(-b/2, b/2, h), effective_key_polygon=_rect(-b/2, b/2, d),
                physical_key_plan=[[-t/2,-b/2],[t/2,-b/2],[t/2,b/2],[-t/2,b/2]],
                deep_key=h>2*t, depth_origin='superfície do concreto, abaixo do graute')


def edge_surfaces(geometry, *, fc, V):
    """Three real/virtual failure surfaces, all demanded by the same actual |V|."""
    _numbers(fc, positive=True); _numbers(V)
    if fc > 10000*PSI: raise ValueError('f′c ultrapassa o limite ACI moldado no local de 10000 psi.')
    g = geometry; b,d,t,ha = (g[k] for k in ('b','d','t','ha'))
    xmin,ymin,xmax,ymax = g['bounds']
    c1 = xmax-t/2 if V >= 0 else -xmin-t/2
    r = 1.5*c1; lo=max(ymin,-b/2-r); hi=min(ymax,b/2+r); depth=min(ha,d+r)
    area=(hi-lo)*depth-b*d; a0=4.5*c1*c1
    ed=min(1., .7+.3*min(-b/2-ymin, ymax-b/2)/r)
    xface='x+' if V >= 0 else 'x-'
    specs=[dict(id=xface,face=xface,plane='yz',edge_coordinate=xmax if V>=0 else xmin,
                ca1=c1,AVc=area,AVco=a0,psi_ed=ed,parallel_factor=1.,
                gross_polygon=_rect(lo,hi,depth), removed_polygon=_rect(-b/2,b/2,d),
                clipped_bottom=ha<d+r,clipped_sides=[ymin>-b/2-r,ymax<b/2+r],
                projection_origin='face carregada real da chave',width=hi-lo,depth=depth)]
    for face,c1 in (('y+',ymax),('y-',-ymin)):
        r=1.5*c1; lo=max(xmin,-r); hi=min(xmax,r); depth=min(ha,r)
        specs.append(dict(id=face,face=face,plane='xz',edge_coordinate=ymax if face=='y+' else ymin,
                          ca1=c1,AVc=(hi-lo)*depth,AVco=4.5*c1*c1,psi_ed=1.,parallel_factor=2.,
                          gross_polygon=_rect(lo,hi,depth),removed_polygon=[],
                          clipped_bottom=ha<r,clipped_sides=[xmin>-r,xmax<r],width=hi-lo,depth=depth,
                          projection_origin='ponto virtual (x,z)=(0,0) no centro da chave; não é Vy físico'))
    for s in specs:
        vb=9*math.sqrt(fc/PSI)*(s['ca1']/INCH)**1.5*LBF
        nominal=s['parallel_factor']*(s['AVc']/s['AVco'])*s['psi_ed']*vb
        resistance=PHI*nominal
        _finite_values(s['AVc'],s['AVco'],vb,nominal,resistance)
        if min(s['AVc'],s['AVco'],resistance)<=0: raise ValueError('Área ou resistência não positiva da superfície.')
        ratio=abs(V)/resistance; _finite_values(ratio)
        s.update(Vb=vb,nominal=nominal,resistance=resistance,demand=abs(V),ratio=ratio,
                 passes=ratio<=1+1e-10,phi=PHI,psi_h_used=1.,psi_c=1.,lambda_a=1.,psi_ec=1.,
                 status='not_demanded' if V==0 else 'pass' if ratio<=1+1e-10 else 'fail')
    governing=min(specs,key=lambda s:s['resistance'])
    return dict(status='not_demanded' if V==0 else 'fail' if any(not s['passes'] for s in specs) else 'pass',
                surfaces=specs,governing=governing['id'],resistance=governing['resistance'],policy=POLICY,
                zero_V_face_convention='x+ somente para desenho, sem demanda' if V==0 else None)


def bearing_values(*, fc, Aef, N, V, n_tension=0, Nsa=None, contact_area=None,
                   contact_valid=True, compression_policy='no_gain'):
    _numbers(fc,Aef,positive=True); _numbers(N,V)
    if fc>10000*PSI:raise ValueError('f′c ultrapassa o limite ACI moldado no local de 10000 psi.')
    if type(n_tension) is not int or not 0<=n_tension<=4: raise ValueError('Contagem de barras tracionadas inválida.')
    out=dict(status='pending',demand=abs(V),N_original=N,n_tension=n_tension,Nsa=Nsa,
             reasons=[],Abp_used_upper_bound=None,compression_policy=compression_policy,
             phi=PHI,Aef=Aef,fc_adopted=fc)
    if compression_policy not in ('no_gain','contact_upper_bound'):
        out['reasons'].append('Política de compressão não suportada.'); return out
    if V==0 and N<0 and Nsa is None and n_tension>0:
        out.update(status='not_demanded',passes=True,reasons=['V=0: contato da chave não solicitado; Nsa ausente não cria demanda de corte. Modos de tração permanecem separados.'])
        return out
    psi=1.
    if N<0:
        if n_tension==0:
            out.update(status='invalid',reasons=['N<0 sem qualquer Ti>0: estado de equilíbrio inválido.']); return out
        if Nsa is None:
            out['reasons'].append('Ase,N nominal e sua fonte devem ser documentadas nos componentes ACI existentes.'); return out
        _numbers(Nsa,positive=True)
        denominator=n_tension*Nsa;_finite_values(denominator)
        psi=1+N/denominator
    elif N>0:
        if contact_valid is False or contact_area is not None and contact_area<=0:
            out.update(status='invalid',reasons=['N>0 sem contato comprimido admissível no mesmo estado.']); return out
        if compression_policy=='contact_upper_bound':
            if not contact_valid or contact_area is None:
                out['reasons'].append('Ganho por compressão aguarda área/estado de contato qualificado.'); return out
            _numbers(contact_area,positive=True)
            denominator=contact_area*fc;_finite_values(denominator)
            psi=min(2.,1+4*N/denominator)
            out['Abp_used_upper_bound']=contact_area
        else:
            out['compression_note']='compression enhancement not credited · ganho por compressão não creditado'
    nominal=1.7*fc*Aef*max(0.,psi);resistance=PHI*nominal
    _finite_values(psi,nominal,resistance)
    ratio=abs(V)/resistance if resistance>0 else None
    if ratio is not None:_finite_values(ratio)
    passed=V==0 or resistance>0 and ratio<=1+1e-10
    out.update(psi_brg=psi,nominal=nominal,resistance=resistance,ratio=ratio,passes=passed,
               status='not_demanded' if V==0 else 'pass' if passed else 'fail')
    if psi<=0:out['reasons'].append('ψbrg≤0: nenhuma resistência positiva de contato; fator nunca convertido em valor absoluto.')
    return out


def _state_regions(*,N,Mbase,L,B,a,row_y,pressure_limit,case,lc,C,Ft,Fmin,model):
    sign=1 if Mbase>=0 else -1
    xc=sign*(L/2-lc/2) if C else 0.
    interval=([L/2-lc,L/2] if sign>0 else [-L/2,-L/2+lc]) if C else []
    rods=[dict(id=f'A{i}',x=x,y=y,tension=Ft if x==-sign*a else Fmin)
          for i,(x,y) in enumerate(((x,y) for x in (-a,a) for y in (-row_y,row_y)),1)]
    rn=C-sum(r['tension'] for r in rods)-N
    rm=C*xc-sum(r['tension']*r['x'] for r in rods)-Mbase
    area=B*lc;sigma=C/area if C else 0.
    _finite_values(C,Ft,Fmin,lc,area,sigma,rn,rm)
    if min(C,Ft,Fmin,lc)<0 or lc>L or sigma>pressure_limit*(1+1e-10):
        raise ValueError('Regiões/forças/pressão inadmissíveis no estado de contato.')
    if abs(rn)>1e-8*max(1.,abs(N),C) or abs(rm)>1e-8*max(1.,abs(Mbase),C*L):
        raise ValueError('Resíduos de equilíbrio não admissíveis no estado de contato.')
    polygon=[[interval[0],-B/2],[interval[1],-B/2],[interval[1],B/2],[interval[0],B/2]] if C else []
    return dict(status='calculated',N=N,Mbase=Mbase,model=model,case=case,pressure_limit=pressure_limit,
                contact=dict(C=C,lc=lc,x=xc,area=area,interval=interval,polygon=polygon,pressure=sigma),
                rods=rods,residual_N=rn,residual_M=rm,n_tension=sum(r['tension']>0 for r in rods))


def type1_force_state(*,N,Mbase,L,B,a,pressure_limit,row_y=None):
    """Pure DG1 uniform-bearing region solver; no BasePlate mutation/evaluation."""
    _numbers(N,Mbase);_numbers(L,B,a,pressure_limit,positive=True)
    row_y=B/4 if row_y is None else row_y;_numbers(row_y,positive=True)
    if a>=L/2 or row_y>=B/2:raise ValueError('Linhas reais de chumbadores devem caber na placa.')
    q=pressure_limit*B;K=L/2+a;m=abs(Mbase)
    _finite_values(q,K,K*K,N*a,m+N*a,abs(N)*a,q*L)
    if N>q*L:raise ValueError('Compressão supera o contato pleno na pressão complementar sem confinamento.')
    if N==0 and m==0:case='ZERO';lc=C=Ft=Fmin=0.
    elif N>0 and m/N<=(L-N/q)/2:
        case='C1' if m==0 else 'C2';lc=L-2*m/N;C=N;Ft=Fmin=0.
    elif N<0 and m<=-N*a:
        case='T1' if m==0 else 'T2';lc=C=0.;Ft=(-N+m/a)/4;Fmin=(-N*a-m)/(4*a)
    else:
        D=K*K-2*(m+N*a)/q;_finite_values(D)
        if D<0:raise ValueError('Radicando negativo: equilíbrio uniforme misto não demonstrado.')
        denominator=K+math.sqrt(D);lc=(2*(m+N*a)/q)/denominator
        C=q*lc;Ft=(C-N)/2;Fmin=0.;case='C3' if N>0 else 'T3' if N<0 else 'M0'
    return _state_regions(N=N,Mbase=Mbase,L=L,B=B,a=a,row_y=row_y,pressure_limit=pressure_limit,
                          case=case,lc=lc,C=C,Ft=Ft,Fmin=Fmin,model='type1_uniform_full_width_DG1')


def type2_force_state(*,N,Mbase,L,B,a,pressure_limit,row_y):
    """Separate internal-row C1/C2/T1/T2 mechanics; no mixed-region fallback."""
    _numbers(N,Mbase);_numbers(L,B,a,pressure_limit,row_y,positive=True)
    if a>=L/2 or row_y>=B/2:raise ValueError('Linhas internas reais devem caber na placa.')
    q=pressure_limit*B;m=abs(Mbase);_finite_values(q,q*L,abs(N)*a)
    if N==0 and m==0:case='ZERO';lc=C=Ft=Fmin=0.
    elif N==0:raise ValueError('Tipo 2: momento puro complementar fora de C1/C2/T1/T2; não usar Tipo 1.')
    elif N>0:
        if N>q*L:raise ValueError('Tipo 2: compressão supera contato pleno na pressão complementar.')
        if m/N>(L-N/q)/2:raise ValueError('Tipo 2: estado complementar exige C3, fora da topologia C1/C2/T1/T2.')
        case='C1' if m==0 else 'C2';lc=L-2*m/N;C=N;Ft=Fmin=0.
    else:
        if m>-N*a:raise ValueError('Tipo 2: estado complementar exige T3, fora da topologia C1/C2/T1/T2.')
        case='T1' if m==0 else 'T2';lc=C=0.;Ft=(-N+m/a)/4;Fmin=(-N*a-m)/(4*a)
    return _state_regions(N=N,Mbase=Mbase,L=L,B=B,a=a,row_y=row_y,pressure_limit=pressure_limit,
                          case=case,lc=lc,C=C,Ft=Ft,Fmin=Fmin,model='type2_internal_C1_C2_T1_T2')


def _native_state(c,a,reason):
    meta=dict(id='native_nbr_full_depth',N=c.N,Mtop=c.M,Vtop=c.V,e=c.shear_eccentricity,
              Mbase=c.effective_moment,pressure_limit=c.sigma_rd,
              pressure_basis='NBR 0,85fck/1,40; A2/A1=1; estado nativo inalterado')
    if not a:return dict(meta,status='pending',reasons=[reason or 'Equilíbrio nativo indisponível.'],rods=[])
    state=_state_regions(N=c.N,Mbase=c.effective_moment,L=c.L,B=c.B,a=c.a,row_y=c.a2/2,
                         pressure_limit=c.sigma_rd,case=a['case'],lc=a['lc'],C=a['C'],
                         Ft=a['Ft_max'],Fmin=a['Ft_min'],model='native_NBR_type'+str(c.model_type))
    state.update(meta);state['reasons']=[]
    return state


def _nominal_steel(c):
    u=c.concrete_components;area=u.area_tension
    if not finite_real(area) or area<=0 or not u.steel_area_ref.strip():return None
    if area>math.pi*c.db*c.db/4:return None
    nominal=area*min(400.,1.9*250.,125000*PSI);_finite_values(nominal)
    return nominal


def _anchor_modes(c,state,Nsa):
    """Existing independently bounded anchor kernels, each with THIS state's Ti.

    No actual rod shear vector is invented. This function evaluates tension only.
    """
    from .concrete_anchorage import evaluate_cone,detail_blockers
    from .concrete_components import bearing_signature
    from .concrete_headed import evaluate_headed
    rods=state.get('rods',[]);active=[rod for rod in rods if rod['tension']>0]
    if state['status']!='calculated':return dict(status='pending',checks=[],modes={},reasons=['Estado de forças não disponível para modos de tração.'])
    if not active:return dict(status='not_demanded',checks=[],modes={},reasons=[])
    reasons=[];checks=[];modes={};u=c.concrete_components
    native_adapter=dict(Ft_max=max(r['tension'] for r in rods),Ft_min=min(r['tension'] for r in rods),
                        T_max_x=min(rods,key=lambda r:-r['tension'])['x'])
    cone=evaluate_cone(c,native_adapter)
    cone['combination']=dict(N=state['N'],M_top=state['Mtop'],M_foundation=state['Mbase'],V=state['Vtop'])
    conechecks=[dict(id='cone_'+g['id'],label='Cone de tração do estado '+state['id'],ids=g['ids'],
                    demand=g['demand'],resistance=g['resistance'],ratio=g['ratio'],method='ACI 17.6.2')
                for g in cone.get('primary_groups',[])]
    modes['cone']=dict(cone,checks=conechecks);checks+=conechecks
    if cone.get('status') not in ('calculated','not_demanded'):
        reasons+=cone.get('reasons',[]) or ['Cone de tração deste estado não selecionado/calculado.']
    problems=detail_blockers(c,rods)
    if u.model!='aci318_19':problems.append('Componentes ACI da ancoragem devem ser selecionados para pullout/ruptura lateral.')
    if u.bearing_area<=0:problems.append('Área efetiva de apoio enterrado ausente.')
    if not problems:
        hole=c.anchor_head_hole if c.anchor_type=='buried_plate_nut' else c.db
        area_limit=c.anchor_head_width*c.anchor_head_length-math.pi*hole**2/4
        if c.anchor_type=='buried_nut':area_limit=min(area_limit,c.anchor_nut_bearing_area)
        detail=dict(family=c.anchor_type,bearing_area_ref=u.bearing_area_ref,
                    effective_area_qualified=bool(u.bearing_confirmation) and u.bearing_confirmation==bearing_signature(c),
                    qualified_bearing_area=u.bearing_area,actual_available_bearing_area=area_limit,
                    detail_confirmed=c.anchor_detail_confirmed,detail_ref=c.anchor_detail_ref,
                    mechanical_resistance=u.mechanical_resistance if u.mechanical_resistance>0 else None,mechanical_ref=u.mechanical_ref)
        result=evaluate_headed(rods,(c.block_xmin,c.block_ymin,c.block_xmax,c.block_ymax),c.hef,c.fck,u.bearing_area,detail)
        for name in ('pullout','sideface'):
            mode=result[name];modes[name]=mode
            checks.extend(x for x in mode.get('checks',[]) if not x.get('diagnostic_only'))
            reasons.extend(mode.get('reasons',[]))
        mechanical=result.get('prerequisites',{}).get('mechanical',{})
        modes['head_mechanical']=mechanical;checks.extend(mechanical.get('checks',[]));reasons+=mechanical.get('reasons',[])
    else:
        for name in ('pullout','sideface','head_mechanical'):modes[name]=dict(status='pending',checks=[],reasons=list(problems))
        reasons+=problems
    if Nsa is not None:
        phi=.75 if u.ductile and u.ductility_ref.strip() else .65
        steelchecks=[dict(id='steel_'+rod['id'],label='Aço em tração ACI · '+rod['id']+' · '+state['id'],
                          ids=[rod['id']],demand=rod['tension'],resistance=phi*Nsa,ratio=rod['tension']/(phi*Nsa),
                          nominal=Nsa,phi=phi,method='ACI 17.6.1; aço A36 fy250/fu400; Ase,N documentada') for rod in active]
        modes['steel']=dict(status='calculated',checks=steelchecks,reasons=[]);checks+=steelchecks
    else:
        reason='Ase,N documentada ausente/incompatível para aço em tração ACI.'
        modes['steel']=dict(status='pending',checks=[],reasons=[reason]);reasons.append(reason)
    for ck in checks:
        _finite_values(ck['demand'],ck['resistance'],ck['ratio'])
    return dict(status='fail' if any(x['ratio']>1+1e-10 for x in checks) else 'pending' if reasons else 'pass',
                checks=checks,modes=modes,reasons=list(dict.fromkeys(reasons)),
                boundary='Somente tração de cada estado. Sem atribuir Vi=0 ou V/4; restrição soldada exige interação própria. Fendilhamento/armadura e conjunto completo separados.')


def evaluate_component(c,native_geometry=None,native_reason=None):
    u=c.single_key_concrete
    if c.shear_path!='plate' or u.model=='off':return {}
    out=dict(model=u.model,status='pending',complete=False,device_complete=False,attachment_complete=False,
             reasons=[],statuses={},states=[],top_actions=dict(N=c.N,Mtop=c.M,Vtop=c.V),
             source=REF,source_signature=result_signature(c),policy=POLICY,limits=LIMITS,
             native_actions=dict(N=c.N,Mtop=c.M,Vtop=c.V,e=c.shear_eccentricity,Mbase=c.effective_moment))
    if u.model!=MODEL:
        out['reasons'].append('Modelo complementar de concreto não suportado.');return out
    if u.rod_restraint not in ('unknown','unwelded','welded') or u.compression_policy not in ('no_gain','contact_upper_bound'):
        out['reasons'].append('Política de restrição/contato não suportada.');return out
    reasons=out['reasons'];status=out['statuses']
    try:
        geo=key_geometry(b=c.lug_bh,H=c.lug_bv,g=c.grout_t,t=c.lug_t,
                         bounds=(c.block_xmin,c.block_ymin,c.block_xmax,c.block_ymax),ha=c.block_h)
        out['geometry']=geo;out['edges']=edge_surfaces(geo,fc=c.fck,V=c.V);status['geometry']='pass'
    except (ValueError,OverflowError,ZeroDivisionError) as exc:
        out.update(status='invalid');status['geometry']='invalid';reasons.append(str(exc));return out
    current=detail_is_current(c)
    status['qualification']='pass' if current else 'pending'
    if not current:reasons.append('Registro opcional ACI ausente/desatualizado: vincular restrição real, preenchimento/respiros e regiões de força aos dados atuais.')
    if u.rod_restraint=='welded':reasons.append('Barras soldadas/rigidamente ligadas exigem interação concorrente ACI 17.11.1.1.3; solda perimetral da arruela não define esse estado.')
    elif u.rod_restraint!='unwelded' or not u.restraint_ref.strip():reasons.append('Restrição real das barras pendente; não deduzida da arruela soldada.')
    if not u.filled_detail_confirmed or not u.filled_detail_ref.strip():reasons.append('Detalhe íntegro preenchido, graute não retrátil e consolidação junto à chave pendentes.')
    if not u.vents_confirmed or not u.vent_detail_ref.strip():reasons.append('Ao menos um respiro/inspeção de 25,4 mm junto a cada face longa, e efeitos dos furos na placa/contato, pendentes.')
    if not u.force_model_confirmed or not u.force_model_ref.strip():reasons.append('Qualificação das regiões uniformes de contato/linhas reais e transferência pela placa pendente; equilíbrio isolado não demonstra compatibilidade.')
    if c.grout_fck<2*c.fck:
        reasons.append('Graute abaixo de 2fck: requisito NBR existente não atende; pressão complementar através do graute não qualificada.')
        status['grout']='pending'
    if c.stiffener_detail not in ('none','web_pair_visual'):reasons.append('Regiões uniformes sem redistribuição por enrijecedores não qualificadas para este detalhe.')
    if c.count<4:reasons.append('Modelo ACI exige ao menos quatro chumbadores reais; não é proibição NBR universal.')
    try:
        native=_native_state(c,native_geometry,native_reason)
        out['states'].append(native)
        e=c.tp+c.grout_t+geo['d']/2;Mbase=c.M+c.V*e;_finite_values(e,Mbase)
        supplemental=dict(id='aci_limited_bearing_centroid',N=c.N,Mtop=c.M,Vtop=c.V,e=e,Mbase=Mbase,
                          pressure_limit=PHI*.85*c.fck,pressure_basis='ACI/DG1 0,65×0,85f′c; A2/A1=1, sem confinamento',
                          reasons=[],status='pending',rods=[])
        try:
            solver=type1_force_state if c.model_type==1 else type2_force_state
            supplemental.update(solver(N=c.N,Mbase=Mbase,L=c.L,B=c.B,a=c.a,row_y=c.a2/2,pressure_limit=PHI*.85*c.fck))
        except (ValueError,OverflowError,ZeroDivisionError) as exc:
            supplemental['reasons'].append(str(exc));reasons.append('Estado ACI complementar: '+str(exc))
        supplemental['contact_qualification']='qualified' if current and c.grout_fck>=2*c.fck else 'pending'
        supplemental['plate_transfer_status']='pending'
        from .single_key_plate import eligible as receiving_section_eligible
        supplemental['plate_transfer_boundary']=(('Escoamento da seção bruta em componente separado; transferência completa da placa permanece pendente. '
              if receiving_section_eligible(c) else 'Sem verificação adicional automática da placa receptora. ')+
              ('Tipo 2 preserva l0=min[d,a2+1,75(a2−tw)] e regiões C1/C2/T1/T2; sem faixa externa Tipo 1.' if c.model_type==2 else
               'Tipo 1: bloco uniforme de largura B, sem prying ou redistribuição.'))
        out['states'].append(supplemental)
        Nsa=_nominal_steel(c)
        for state in out['states']:
            valid=state['status']=='calculated';rods=state.get('rods',[])
            area=state.get('contact',{}).get('area') if valid else None
            # Zero/positive axial no-gain checks remain useful even if equilibrium is pending.
            contact_valid=(area>0 if valid and c.N>0 else True)
            if c.N<0 and not valid:
                bearing=dict(status='pending',demand=abs(c.V),reasons=['ψbrg em tração aguarda Ti e contagem de barras do mesmo estado.'])
            else:
                policy=u.compression_policy
                qualified_gain=current and c.grout_fck>=2*c.fck
                if c.N>0 and policy=='contact_upper_bound' and not (qualified_gain and valid):
                    bearing=bearing_values(fc=c.fck,Aef=geo['Aef'],N=c.N,V=c.V,
                                           n_tension=sum(x['tension']>0 for x in rods),Nsa=Nsa,
                                           contact_area=area,contact_valid=contact_valid,compression_policy='no_gain')
                    bearing['requested_compression_policy']=policy
                    bearing['reasons'].append('Ganho solicitado não creditado enquanto o contato/registro estiver pendente; ψ=1 conservador calculado.')
                else:
                    bearing=bearing_values(fc=c.fck,Aef=geo['Aef'],N=c.N,V=c.V,
                                           n_tension=sum(x['tension']>0 for x in rods),Nsa=Nsa,
                                           contact_area=area,contact_valid=contact_valid,compression_policy=policy)
            state['bearing']=bearing
            active=[rod for rod in rods if rod['tension']>0]
            if active:
                csl=min(abs(rod['x']) for rod in active)
                state['anchorage_ratios']=dict(h_physical=geo['h'],csl=csl,hef=c.hef,
                                               required_hef_h=2.5*geo['h'],required_hef_csl=2.5*csl,
                                               passes=c.hef>=2.5*geo['h'] and c.hef>=2.5*csl)
                if not state['anchorage_ratios']['passes']:reasons.append(state['id']+': embutimento ACI insuficiente para 2,5h físico e/ou 2,5csl real.')
            state['anchor_modes']=_anchor_modes(c,state,Nsa)
            if not valid:reasons.extend(state.get('reasons',[]))
    except (ValueError,OverflowError,ZeroDivisionError) as exc:
        reasons.append(str(exc));status['arithmetic']='invalid'
    fail=(out['edges']['status']=='fail' or any(s.get('bearing',{}).get('status') in ('fail','invalid') or
          s.get('anchor_modes',{}).get('status')=='fail' or s.get('anchorage_ratios',{}).get('passes') is False for s in out['states']))
    pending=(bool(reasons) or len(out['states'])!=2 or any(s.get('bearing',{}).get('status')=='pending' or
             s.get('anchor_modes',{}).get('status')=='pending' or s.get('status')!='calculated' for s in out['states']))
    out['status']='fail' if fail else 'invalid' if status.get('arithmetic')=='invalid' else 'pending' if pending else 'pass'
    status['edges']=out['edges']['status'];status['force_states']='pass' if len(out['states'])==2 and all(s['status']=='calculated' for s in out['states']) else 'pending'
    out['local_concrete_status']='fail' if out['edges']['status']=='fail' or any(s.get('bearing',{}).get('status')=='fail' for s in out['states']) else 'pending' if reasons or any(s.get('bearing',{}).get('status')=='pending' for s in out['states']) else 'pass'
    out['reasons']=list(dict.fromkeys(reasons))
    return out


def add_single_key_concrete_checks(c,r,add,native_geometry=None,native_reason=None):
    d=evaluate_component(c,native_geometry,native_reason)
    if not d:return d
    for surface in d.get('edges',{}).get('surfaces',[]):
        if c.V==0:continue
        add('skc_edge_'+surface['id'],'Concreto da chave · borda '+surface['id'],surface['demand'],surface['resistance'],'N',REF,
            'φ×kpar×(AVc/AVco)×ψed×Vb; Vb=9√f′c ca1^1,5 em psi/in/lbf; ψh=1',
            f'ca1={surface["ca1"]:.8g}; AVc={surface["AVc"]:.8g}; AVco={surface["AVco"]:.8g}; φRn={surface["resistance"]:.8g}',POLICY)
    for index,state in enumerate(d.get('states',[])):
        bearing=state.get('bearing',{})
        if 'resistance' in bearing and c.V!=0:
            add(f'skc_bearing_{index}','Concreto da chave · contato · '+state['id'],abs(c.V),bearing['resistance'],'N',REF,
                'φVbrg=0,65×1,7f′c b min(h,2t) ψbrg; N original assinado',
                f'ψbrg={bearing["psi_brg"]:.8g}; φVbrg={bearing["resistance"]:.8g}; nTi>0={bearing["n_tension"]}',
                'Pressão axial e Ti são deste mesmo estado; sem γNBR adicional, sem área de graute.')
        ratios=state.get('anchorage_ratios',{})
        for suffix,field in (('h','required_hef_h'),('csl','required_hef_csl')):
            if field in ratios:
                add(f'skc_embedment_{index}_{suffix}','Prerequisito ACI opcional · '+state['id']+' · '+suffix,
                    ratios[field],ratios['hef'],'mm',REF,'hef ≥ 2,5h físico e hef ≥ 2,5csl real',
                    f'h={ratios["h_physical"]:.8g}; csl={ratios["csl"]:.8g}; hef={ratios["hef"]:.8g}',
                    'Aplica-se quando existe Ti>0; não restringe o modelo NBR independente.')
        for k,ck in enumerate(state.get('anchor_modes',{}).get('checks',[])):
            add(f'skc_anchor_{index}_{k}',ck['label']+' · '+state['id'],ck['demand'],ck['resistance'],'N',ck.get('method',REF),
                'Ti ou soma Ti do próprio estado ≤ resistência correspondente',
                f'Sd={ck["demand"]:.8g}; Rd={ck["resistance"]:.8g}; barras='+','.join(ck.get('ids',[])),
                'Modos de tração separados; não calcula nem presume cortante individual ou interação de barras soldadas.')
    for reason in d.get('reasons',[]):
        r.issues.append(Issue('noncompliance' if d['status']=='invalid' else 'pending',reason,REF,origin='single_key_concrete'))
    for state in d.get('states',[]):
        for reason in state.get('anchor_modes',{}).get('reasons',[]):
            r.issues.append(Issue('pending',state['id']+': '+reason,REF,origin='single_key_concrete_anchor'))
    r.issues.append(Issue('pending',LIMITS,REF,origin='single_key_concrete_scope'))
    return d
