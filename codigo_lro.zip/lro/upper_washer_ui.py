"""Arruela superior: entradas explícitas e resultados locais separados (0.8.5)."""
from dataclasses import asdict, fields
import math

import streamlit as st

from .models import KGF
from .report import number
from .upper_washer import UpperWasher

def _prefix(): return st.session_state.get('_baseplate_ui_prefix','bp')+'_uw_'
def _draft(name): return '_'+st.session_state.get('_baseplate_ui_prefix','bp')+'_'+name
MODELS = {
    'off': 'Não selecionado · verificações locais pendentes',
    'four_edge_elastic': '4 filetes contínuos · modelo elástico local',
}
LAYOUTS = {
    'unspecified': 'Arranjo não informado',
    'four_edges': '4 bordas externas contínuas · filetes iguais',
    'partial': 'Bordas parciais ou interrompidas · fora do modelo',
}
STEELS = {'unspecified': 'Aço da arruela não informado',
          'ASTM A572 Gr.50': 'ASTM A572 Gr.50 · fy=345 MPa, fu=450 MPa'}
PROCESSES = {'unspecified': 'Processo / execução não informados',
             'smaw_e7018_single_pass': 'SMAW · E7018 · passe único'}


def seed_upper_washer(washer):
    """Importação e exemplos substituem inclusive o detalhe hoje oculto."""
    data = asdict(washer)
    s = st.session_state
    for name, value in data.items():
        s[_prefix() + name] = float(value) if type(value) in (int, float) else value
    s[_draft('upper_washer_draft')] = data


def restore_upper_washer(connection):
    """A navegação não transforma detalhes ocultos em novos padrões."""
    s = st.session_state
    data = s.get(_draft('upper_washer_draft'), connection.get('upper_washer', {}))
    for name, default in asdict(UpperWasher()).items():
        value = data.get(name, default)
        s[_prefix() + name] = s.get(_prefix() + name, float(value) if type(value) in (int, float) else value)


def _selectbox(label, name, choices):
    options = list(choices)
    current = st.session_state.get(_prefix() + name)
    if current not in options:
        options.append(current)
    return st.selectbox(label, options, key=_prefix() + name,
                        format_func=lambda value: choices.get(value, str(value) + ' · fora do modelo'))


def upper_washer_widgets():
    with st.expander('Arruela superior · solda de contorno e furo', expanded=True):
        model = _selectbox('Verificações locais da arruela superior', 'model', MODELS)
        st.caption('Esta é a arruela horizontal sobre a face superior da placa de base. A cabeça, porca ou chapa enterrada da ancoragem é outra peça. Lado e espessura ta são os valores reais informados acima.')
        if model == 'off':
            st.caption('Sem resistência local adicional creditada. A exigência de dimensionar cada solda para Fv,Rd não reduzido permanece.')
            return
        _selectbox('Arranjo das soldas da arruela superior', 'layout', LAYOUTS)
        st.number_input('Perna w dos quatro filetes (mm)', key=_prefix() + 'leg', format='%.3f')
        st.caption('Quatro filetes de pernas iguais a 90°, externos, contínuos, no mesmo plano de raiz; garganta a=w/√2. Zero indica dimensão não informada. Bordas parciais não recebem crédito de contorno completo.')
        _selectbox('Aço da arruela superior', 'steel', STEELS)
        _selectbox('Processo e execução das soldas da arruela', 'process', PROCESSES)
        st.caption('Rota limitada a ASTM A572 Gr.50 e E7018/SMAW em passe único, fw=485 MPa. Informar fy=345 MPa isoladamente não define fu nem identifica o aço. A seleção não qualifica procedimento de soldagem.')
        st.number_input('Furo real df da placa de base (mm)', key=_prefix() + 'base_hole', format='%.3f')
        st.caption('Informe o furo circular efetivamente adotado na placa de base; zero = não informado. Não se preenche este campo com o valor de referência da Tabela 18. O furo da arruela permanece padrão db+1,5 mm.')
        st.checkbox('Confirmo arruela, barra e furo circular da placa concêntricos, sem afastamento ou calço.', key=_prefix() + 'centered')
        st.caption('O modelo requer arruela plana horizontal e quatro raízes/pés de solda apoiados em placa íntegra, com prateleira livre ≥w. Furos excêntricos, rasgos, filetes desiguais, ressaltos, torção e momentos locais adicionais exigem outro modelo. Encaixe numérico não comprova acesso de execução ou tolerâncias.')
        st.warning('Ação por arruela F=Fv,Rd sem redução, inclusive com V=0. Momento de apoio F·ta/2 e possível momento de extremidade da barra F·(tp+ta/2)/2 são considerados no envelope aditivo. Essa escolha conservadora do app deriva da hipótese de curvatura reversa do DG1; não é fórmula NBR nem prescrição DG1 de solda de arruela.')


def upper_washer_from_state():
    s = st.session_state
    previous = s.get(_draft('upper_washer_draft'), {})
    data = {field.name: s.get(_prefix() + field.name, previous.get(field.name, getattr(UpperWasher(), field.name)))
            for field in fields(UpperWasher())}
    washer = UpperWasher(**data)
    s[_draft('upper_washer_draft')] = asdict(washer)
    return washer


def _n(value, scale=1.):
    return number(value / scale, 3) if type(value) in (int, float) and math.isfinite(value) else '—'


def _status(label, status):
    if status == 'pass':
        st.success(label + ': ATENDE ao modelo local indicado.')
    elif status == 'fail':
        st.error(label + ': NÃO ATENDE ao modelo local indicado.')
    else:
        st.warning(label + ': PENDENTE, sem resistência local creditada.')


def upper_washer_results(c, result):
    if not c.native_anchor_shear or c.upper_washer.model == 'off':
        return
    local = result.local_upper_washer
    with st.expander('Arruela superior · resultados locais limitados', expanded=True):
        from .upper_washer_artifacts import image_bytes
        st.image(image_bytes(c,result),use_container_width=True)
        status = local.get('statuses', {})
        _status('Metal das soldas · envelope elástico', status.get('weld_metal'))
        _status('Dimensões dos filetes e implantação sobre a placa', status.get('weld_detail'))
        _status('Furo da arruela · pressão de contato e rasgamento de borda', status.get('hole'))
        for reason in local.get('reasons', []):
            st.warning(str(reason))
        force = local.get('F_N', result.geometry.get('anchor_shear', {}).get('weld_force_per_washer'))
        st.write(f'Ação por arruela: Fv,Rd não reduzido={_n(force, KGF)} kgf/barra. Cortante aplicado V={_n(c.V, KGF)} kgf; a ação local permanece mesmo com V=0.')
        st.caption('NBR 8800 §6.7.2.5 exige Fv,Rd para cada solda, sem reduzir por tração, V/4 ou capacidade do grupo. O uso desse mesmo F no furo é um envelope conservador de desenvolvimento da capacidade adotado pelo app, não uma exigência literal adicional dessa cláusula.')
        st.write(f'Momento de apoio: M_bearing=F·ta/2={_n(local.get("M_bearing_Nmm"), KGF*1000)} kgf·m.')
        st.write(f'Possível momento de extremidade da barra: |M_rod,DG1|=F·(tp+ta/2)/2={_n(local.get("M_rod_DG1_Nmm"), KGF*1000)} kgf·m.')
        st.write(f'Envelope conservador adotado: M_w=M_bearing+|M_rod,DG1|=F·(tp/2+3ta/4)={_n(local.get("M_envelope_Nmm"), KGF*1000)} kgf·m.')
        st.caption('O envelope cobre os dois sinais do possível binário de extremidade da hipótese DG1, além do apoio direto. É escolha de modelagem do app, não fórmula NBR ou prescrição DG1 da solda. Não cobre momentos adicionais arbitrários; não altera M nem o equilíbrio global da base. Furo centrado elimina torção no plano, mas não o momento fora do plano.')
        if local.get('q_resultant_Npmm') is not None:
            st.write(f'Quatro linhas de raiz: L={_n(local.get("L_mm"))} mm; garganta a={_n(local.get("throat_mm"))} mm; Iy,linha={_n(local.get("Iy_line_mm3"))} mm³. qmáx={_n(local.get("q_resultant_Npmm"))} N/mm; qRd={_n(local.get("q_weld_Rd_Npmm"))} N/mm; índice do metal de solda={_n(local.get("weld_utilization"))}.')
            st.caption('NBR Tabela 9 por unidade de comprimento: qRd=0,6fw·a/γw2, γw2=1,35. Comprimentos reais do contorno fechado, sem desconto artificial de 2w, sem aumento direcional de 1,5 e sem crédito resistente ao metal-base.')
        if local.get('weld_leg_min_mm') is not None:
            st.write(f'Perna informada w={_n(c.upper_washer.leg)} mm; mínima pela parte mais fina={_n(local.get("weld_leg_min_mm"))} mm; máxima na borda da arruela={_n(local.get("weld_leg_max_mm"))} mm. Furo real da placa df={_n(c.upper_washer.base_hole)} mm.')
        if local.get('hole_Rd_N') is not None:
            st.write(f'Furo da arruela: Rd={_n(local.get("hole_Rd_N"), KGF)} kgf; índice no envelope Fv,Rd={_n(local.get("hole_utilization"))}.')
            st.caption('NBR §6.3.3.3(a): mínimo entre pressão de contato e rasgamento da borda, com restrição à deformação de serviço. Falhar este envelope significa não desenvolver a capacidade integral adotada da barra; não demonstra falha para todo cortante aplicado menor. A expressão verifica o resultante horizontal direto, sem pressão local combinada do binário.')
        st.warning('Conjunto completo PENDENTE: flexão local da arruela e da placa, distribuição de contato e eventual binário da barra; seção líquida, bloco de cisalhamento e demais caminhos do metal-base (§6.5); transferência local da solda à placa; procedimento, execução e acesso; ancoragem completa no concreto, bloco/fundação e soldas pilar–placa. Passes locais não aprovam a base completa.')
