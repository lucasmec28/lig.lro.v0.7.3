"""Explicit catalog identities; legacy intent is never an implicit geometry conversion."""
FIXED='Placa de base · engastada'
PINNED='Placa de base · rotulada'
FAMILIES=(FIXED,PINNED)


def load_project(data,validate_values=True):
    kind=data.get('connection_type') if isinstance(data,dict) else None
    if kind=='base_plate_pinned':
        from .pinned_base_plate import PinnedBasePlate
        return PinnedBasePlate.from_dict(data,validate_values)
    if kind in ('base_plate','base_plate_fixed','base_plate_type1_legacy'):
        from .base_plate import FixedBasePlate
        return FixedBasePlate.from_dict(data,validate_values)
    raise ValueError('Arquivo não pertence a uma família de placas de base reconhecida.')


def catalog_family(project):
    return PINNED if project.model_type==2 else FIXED
