"""Original equations, AISC 360-16 LRFD / Manual 15 pp10-78–81.
Bounded lower-seat prototype; no proprietary table is embedded.
Audited Gerdau / AISC receivers, one-sided seat. Length mm, stress MPa, force N.
"""
from dataclasses import dataclass, asdict
import math
from .stiffened_console_catalog import COLUMNS,MATERIALS
FAMILY='Console enrijecido · AISC · escopo local'
IN=25.4; KSI=6.894757293168; KIP=4448.2216152605
@dataclass(frozen=True)
class Console:
    column_profile: str="Gerdau W360×122"
    column_material: str="ASTM A572 Gr.50"
    beam_d: float=21.1*IN
    beam_bf: float=8.27*IN
    beam_tw: float=.430*IN
    beam_tf: float=.685*IN
    beam_k1: float=.875*IN
    beam_k: float=1.19*IN
    beam_fy: float=50*KSI
    projection: float=7*IN
    reaction: float=125*KIP
    length: float=15*IN
    weld: float=5/16*IN
    rib_thickness: float=5/8*IN
    seat_thickness: float=3/8*IN
    seat_width: float=9*IN
    rib_seat_weld: float=5/16*IN
    rib_seat_length: float=6*IN


def elastic_weld_capacity(length,projection,weld,fexx=70*KSI,phi=.75):
    if any(not math.isfinite(x) or x<=0 for x in (length,projection,weld,fexx,phi)):
        raise ValueError('Geometria e resistências devem ser positivas e finitas.')
    # Elastic T weld: Lw=2.4l and tensile section modulus S=0.6l².
    demand_per_force=math.hypot(1/(2.4*length), .8*projection/(.6*length**2))
    return phi*.6*fexx*(math.sqrt(2)/2)*weld/demand_per_force


def evaluate(c):
    errors=[]
    if not isinstance(c.column_profile,str) or c.column_profile not in COLUMNS: errors.append("Pilar fora do catálogo auditado.")
    if not isinstance(c.column_material,str) or c.column_material not in MATERIALS: errors.append("Material do pilar não habilitado.")
    if errors:return {"status":"BLOQUEADO","errors":errors,"checks":[]}
    col=COLUMNS[c.column_profile]
    if col["manufacturer"]=="Gerdau" and c.column_material=="ASTM A992": errors.append("Para Gerdau, declarar A36 ou A572 Gr.50 conforme certificado; A992 não qualificado neste catálogo.")
    for k,v in asdict(c).items():
        if k in ("column_profile","column_material"):continue
        if isinstance(v,bool) or not isinstance(v,(int,float)) or v<=0 or v>1e8 or not math.isfinite(v):
            errors.append(k+': valor positivo e finito obrigatório.')
    if errors:return {'status':'BLOQUEADO','errors':errors,'checks':[]}
    W=c.projection; fyb=c.beam_fy; fyr=36*KSI; E=29000*KSI
    tw=c.beam_tw; tf=c.beam_tf; d=c.beam_d; k=c.beam_k; tc=col["tw"]; fuc=MATERIALS[c.column_material][1]*KSI
    if not (4*IN<=W<=7*IN and tf<=k<d/2 and tw<c.beam_bf and tw/2<=c.beam_k1<c.beam_bf/2 and 2*tf<d and 36*KSI<=fyb<=50*KSI):
        return {'status':'BLOQUEADO','errors':['Domínio: projeção de 4–7 in, viga I/W simétrica, 36–50ksi e geometria válida.'],'checks':[]}
    n=W-.75*IN
    ry=fyb*tw*(2.5*k+n)
    factor=3*n/d if n/d<=.2 else 4*n/d-.2
    rc=.75*.4*tw**2*(1+factor*(tw/tf)**1.5)*math.sqrt(E*fyb*tf/tw)
    rw=elastic_weld_capacity(c.length,W,c.weld)
    tmin=3.09*(c.weld/IN*16)/(fuc/KSI)*IN
    # Separate column base-metal shear development, no unjustified global stability check.
    rb=rw*min(1,tc/tmin)
    checks=[]
    def ck(name,demand,capacity,unit,ref):
        checks.append(dict(name=name,demand=demand,capacity=capacity,ratio=demand/capacity,unit=unit,ok=demand<=capacity*(1+1e-10),reference=ref))
    ck('Folga lateral nervura–parafusos',c.rib_thickness/2+c.weld+20.,2.75*IN,'mm','Raio livre de montagem de 20 mm: conferir ferramenta real')
    ck('Folga de concordância da viga',c.beam_k1+20.,2.75*IN,'mm','k1 declarado + raio livre de 20 mm; conferir ferramenta')
    ck('Viga · largura para dois parafusos prescritos',8*IN,c.beam_bf,'mm','Dois parafusos de 3/4 in, g = 5,5 in, bordas de 1,25 in')
    ck('Assento · largura para dois parafusos prescritos',8*IN,c.seat_width,'mm','Dois parafusos de 3/4 in, g = 5,5 in, bordas de 1,25 in')
    ck('Alma da viga · escoamento local',c.reaction,ry,'N','AISC 360-16 J10.2')
    ck('Alma da viga · crippling',c.reaction,rc,'N','AISC 360-16 J10.3; extremidade, ramo conforme N/d')
    ck('Grupo T · soldas ao pilar',c.reaction,rw,'N','Manual 15 10-80; método elástico, S=0.6l²')
    ck('Alma do pilar · desenvolvimento da solda',c.reaction,rb,'N','Manual 15 10-81 / Eq. 9-2; um lado')
    ck('Nervura · espessura mínima',max(fyb/fyr*tw,2*c.weld),c.rib_thickness,'mm','Manual 15 10-80; A36')
    ck('Assento · espessura mínima',3/8*IN,c.seat_thickness,'mm','Manual 15 10-80')
    ck('Recorte · patamar inferior de 20 mm',2*c.weld,20.,'mm','Manual 15 Fig. 10-10(b)')
    ck('Comprimento horizontal de solda disponível',.4*c.length+c.rib_thickness,c.seat_width,'mm','Manual 15 Fig. 10-10(b); 0,2l por lado')
    ck('Largura do assento entre concordâncias',c.seat_width,col['fit_clear'],'mm','Envelope conservador: AISC Manual 15 Tabela 1-1 e catálogo Gerdau p.3')
    ck('Ligação nervura–assento desenvolve solda horizontal',.4*c.length*c.weld,2*c.rib_seat_length*c.rib_seat_weld,'mm²','Manual 15 10-80; mesmo eletrodo E70')
    ck('Extensão da solda nervura–assento',c.rib_seat_length,W,'mm','Geometria do assento')
    def weld_limits(name,w,t1,t2):
        thick=max(t1,t2)/IN
        minimum=(1/8 if thick<=1/4 else 3/16 if thick<=1/2 else 1/4 if thick<=3/4 else 5/16)*IN
        ck(name+' · mínimo J2.4',minimum,w,'mm','AISC 360-16 Tabela J2.4')
        edge=min(t1,t2)
        maximum=edge if edge<1/4*IN else edge-1/16*IN
        ck(name+' · máximo na borda',w,maximum,'mm','AISC 360-16 J2.2b; sem solda de borda cheia')
    weld_limits('Solda horizontal assento–pilar',c.weld,c.seat_thickness,tc)
    weld_limits('Solda vertical nervura–pilar',c.weld,c.rib_thickness,tc)
    weld_limits('Solda nervura–assento',c.rib_seat_weld,c.rib_thickness,c.seat_thickness)
    if c.length>100*c.weld:errors.append('Domínio limitado a l/w≤100; solda longa exige avaliação específica.')
    if not 11*IN<=c.length<=32*IN: errors.append('Altura da nervura fora do domínio avaliado: 11–32 in.')
    if not math.isclose(c.rib_seat_weld,c.weld,rel_tol=0,abs_tol=1e-9):errors.append('Domínio limitado: solda nervura–assento deve ter a mesma perna da solda ao pilar.')
    if c.rib_seat_length<4*c.rib_seat_weld:errors.append('Solda nervura–assento deve ter comprimento mínimo 4w.')
    if .2*c.length<4*c.weld:errors.append('Solda horizontal ao pilar deve ter comprimento mínimo 4w.')
    # 20mm end shelves are fixed proposal; positive retained diagonal remains mandatory.
    if c.length<=20 or W<=20:errors.append('Recorte incompatível com a nervura.')
    return {'status':'BLOQUEADO' if errors else 'ATENDE AO ESCOPO LOCAL' if all(x['ok'] for x in checks) else 'NÃO ATENDE','errors':errors,'checks':checks,
      'input':asdict(c),'fixed':{'beam':'Perfil I/W simétrico com propriedades declaradas','column':c.column_profile+' / '+c.column_material,'column_catalogue':dict(col),'column_fy_mpa':MATERIALS[c.column_material][0]*KSI,'column_fu_mpa':fuc,'column_tmin_eq9_2_mm':tmin,'plates':'A36','electrode':'E70','projection_mm':W,'bearing_length_mm':n,'lower_shelf_mm':20,'outer_tip_mm':20,'bolt_axis_max_mm':max(W/2,2.625*IN),'bolt_axis_provided_mm':min(W/2,3*IN),'bolt_diameter_mm':.75*IN,'bolt_gauge_mm':5.5*IN,'bolt_min_edge_mm':1.25*IN,'top_angle_legs_mm':4*IN,'top_angle_thickness_mm':.25*IN,'top_angle_bolts_each_leg':2,'top_angle_length_mm':8*IN,'top_angle_bolt_axis_from_heel_mm':2*IN,'horizontal_weld_each_side_mm':.2*c.length},
      'warnings':['Patamar de 20 mm abaixo da recomendação de 25,4 mm; mínimo 2w verificado.',
      'Escopo: apoio inferior em um lado da alma do pilar selecionado. Material deve corresponder ao certificado do membro real. Não é aprovação de fabricação.',
      'Catálogo limitado a designações americanas explicitamente publicadas pela Gerdau e contidas na lista do Manual 15, p.10-79. O envelope de montagem adotado (228,6 ou 254 mm) é conservador; não se confunde d′ da Gerdau com T do Manual.',
      'Condição obrigatória: console centrado na alma de pilar contínuo, sem outra ligação interferente; nervura alinhada à alma da viga e ajustada para contato sob o assento; viga parafusada com parafusos de alta resistência; não soldar viga ao assento.',
      'Eixo dos parafusos do assento em min(W/2,76,2 mm) da face do pilar, evitando a exceção W14×43; folga da extremidade da viga 12,7 mm. Contenção superior com cantoneira ≥ 6,35 mm, perna vertical ≥ 101,6 mm; fixada por parafusos no detalhe adotado.',
      'Detalhe prescrito: dois parafusos ASTM F3125 Gr. A325 (Grupo A), diâmetro 19,05 mm, furos 20,6375 mm, g = 139,7 mm; cantoneira superior L 101,6 × 101,6 × 6,35 mm, comprimento 203,2 mm e dois parafusos por perna, eixos a 50,8 mm do talão. Cantoneira acima da mesa superior, perna vertical voltada para cima. Verificar acesso/fabricação. Sem ações horizontais, levantamento, momento imposto ou verificação global do pilar.']}


def project(c):
    return {'schema':'aisc_console_v2','units':{'length':'mm','force':'N','stress':'MPa'},'connection':asdict(c)}


def from_project(data):
    if not isinstance(data,dict) or set(data)!={'schema','units','connection'} or data['schema']!='aisc_console_v2' or data['units']!={'length':'mm','force':'N','stress':'MPa'}:
        raise ValueError('Projeto ou unidades incompatíveis.')
    if not isinstance(data['connection'],dict) or set(data['connection'])!=set(asdict(Console())):
        raise ValueError('Campos de projeto incompletos ou desconhecidos.')
    c=Console(**data['connection'])
    r=evaluate(c)
    if r['errors']:raise ValueError('; '.join(r['errors']))
    return c
