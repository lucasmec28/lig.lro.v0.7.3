"""Proportional, input-authentic views of a full-CJP aligned W splice.

Openings are the engine's actual rounded cuts, mirrored on both members.
Annotations occupy their own lanes. There are no cover plates, fictitious
continuous web welds across the holes, or fabrication-release claims.
"""
from dataclasses import asdict
from hashlib import sha256
from io import BytesIO
import json
from math import isfinite, cos, sin, pi

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon, Rectangle
from .drawing_annotations import dimension, rendered_wrap
from .welded_w_splice import COMPONENT_VERSION, DECLARATIONS, access_outline, all_cases, evaluate

INK = '#263746'
MEMBER = '#dce4e9'
WELD = '#ba432d'
MUTED = '#566979'
HOLE = '#ffffff'
STATUS = {
    'INVALID_INPUT': 'Entrada inválida', 'INVALID_GEOMETRY': 'Geometria inválida',
    'OUTSIDE_SUPPORTED_SCOPE': 'Fora do domínio implementado',
    'NOT_VERIFIED': 'Não verificado por pendências',
    'VERIFIED_SUBCHECK_FAIL': 'Verificação resistente não atendida',
    'FAIL': 'Verificação não atendida',
    'PASS': 'Verificações locais atendidas no domínio',
    'COMPLETE_CHECKS_PASS_WITHIN_SCOPE': 'Verificações locais atendidas no domínio',
    'DETAIL_FAIL': 'Detalhamento não atendido',
}


def input_fingerprint(c):
    return sha256(json.dumps(asdict(c), sort_keys=True, ensure_ascii=False,
                             allow_nan=False, separators=(',', ':')).encode('utf-8')).hexdigest()


def validated_result(c, result=None):
    """Caller-supplied results are never evidence for an exported artifact."""
    return evaluate(c)


def _num(v, signed=False):
    if isinstance(v, bool) or not isinstance(v, (int, float)) or not isfinite(v):
        return 'indisponível'
    return (format(v, '+.7g') if signed else format(v, '.7g')).replace('.', ',')


def _cases(c, r):
    cases = r.get('cases')
    return cases if isinstance(cases, list) else all_cases(c)


def _line(ax, xs, ys, gid, color=INK, lw=.9, **kwargs):
    obj = ax.plot(xs, ys, color=color, lw=lw, **kwargs)[0]
    obj.set_gid(gid)
    return obj


def _polygon(ax, vertices, gid, color=MEMBER, lw=.8, **kwargs):
    patch = Polygon(vertices, closed=True, facecolor=color, edgecolor=INK,
                    linewidth=lw, **kwargs)
    patch.set_gid(gid)
    ax.add_patch(patch)
    return patch


def _opening(ax, vertices, gid):
    patch = _polygon(ax, vertices, gid, HOLE, zorder=4)
    patch.set_edgecolor('none')
    # The opening mouth is empty space across the weld plane, not a boundary.
    outline = vertices[:-1] if vertices[0] == vertices[-1] else vertices
    _line(ax, [p[0] for p in outline], [p[1] for p in outline], gid + '_cut_edge',
          INK, .8, zorder=4.5)
    return patch


def _rect(ax, x, y, w, h, gid, color=MEMBER, **kwargs):
    patch = Rectangle((x, y), w, h, facecolor=color, edgecolor=INK,
                      linewidth=.8, **kwargs)
    patch.set_gid(gid)
    ax.add_patch(patch)
    return patch


def _safe_dimensions(c):
    keys = ('d', 'bf', 'tf', 'tw', 'access_h0', 'access_hmax_a', 'access_hmax_b',
            'access_length_a', 'access_length_b', 'access_radius_a', 'access_radius_b')
    return all(isinstance(getattr(c, key), (int, float))
               and not isinstance(getattr(c, key), bool)
               and isfinite(getattr(c, key)) and getattr(c, key) > 0 for key in keys)


def _section(ax, c):
    h = c.d / 2 - c.tf
    _rect(ax, -c.bf / 2, h, c.bf, c.tf, 'section_flange_top', MEMBER)
    _rect(ax, -c.bf / 2, -c.d / 2, c.bf, c.tf, 'section_flange_bottom', MEMBER)
    _rect(ax, -c.tw / 2, -h + c.access_h0, c.tw,
          2 * (h - c.access_h0), 'section_remaining_web', MEMBER)
    # Exact effective weld patches are visible without replacing their geometry
    # by thick line symbols that would cover physical access gaps.
    _rect(ax, -c.flange_weld_length / 2, c.d / 2 - c.flange_weld_throat,
          c.flange_weld_length, c.flange_weld_throat, 'cjp_patch_top', WELD, alpha=.6)
    _rect(ax, -c.flange_weld_length / 2, -c.d / 2,
          c.flange_weld_length, c.flange_weld_throat, 'cjp_patch_bottom', WELD, alpha=.6)
    _rect(ax, -c.web_weld_throat / 2, -c.web_weld_length / 2,
          c.web_weld_throat, c.web_weld_length, 'cjp_patch_web', WELD, alpha=.6)
    pad = max(c.d, c.bf) * .15
    dimension(ax, (-c.bf / 2, -c.d / 2 - pad * .65),
              (c.bf / 2, -c.d / 2 - pad * .65), 'bf = ' + _num(c.bf), fontsize=8)
    dimension(ax, (-c.bf / 2 - pad * .65, -c.d / 2),
              (-c.bf / 2 - pad * .65, c.d / 2), 'd = ' + _num(c.d),
              fontsize=8, rotation=90)
    ax.set_xlim(-c.bf / 2 - pad * 1.55, c.bf / 2 + pad * .5)
    ax.set_ylim(-c.d / 2 - pad * 1.5, c.d / 2 + pad * .5)
    ax.set_title('SEÇÃO NA JUNTA x = 0\nCJP nas áreas vermelhas; aberturas sem solda',
                 fontsize=9, loc='left', pad=12, color=INK)


def _longitudinal(ax, c):
    h = c.d / 2 - c.tf
    span = max(c.d * .64, 2.3 * max(c.access_length_a, c.access_length_b))
    column = c.orientation == 'column'
    transform = (lambda p: (-p[1], p[0])) if column else (lambda p: p)
    for side, sign in (('a', -1), ('b', 1)):
        x0, x1 = sorted((0, sign * span))
        for key, lo, hi in (('web', -h, h), ('flange_top', h, c.d / 2),
                            ('flange_bottom', -c.d / 2, -h)):
            points = [(x0, lo), (x1, lo), (x1, hi), (x0, hi)]
            _polygon(ax, [transform(p) for p in points], f'member_{side}_{key}')
        opening = access_outline(c, side)
        for end, sign_y in (('top', 1), ('bottom', -1)):
            vertices = [transform((sign * x, sign_y * (h - q))) for x, q in opening]
            _opening(ax, vertices, f'access_{side}_{end}')
        # Both members terminate at the same weld cut. A transverse dashed line
        # is not drawn through the holes, where neither web nor CJP exists.
    for sign_y in (1, -1):
        mouth = [transform((0, sign_y * h)), transform((0, sign_y * (h - c.access_h0)))]
        _line(ax, [p[0] for p in mouth], [p[1] for p in mouth],
              'empty_access_mouth_' + str(sign_y), HOLE, 1.5, zorder=4.6)
    for key, lo, hi in (('flange_top', c.d / 2 - c.flange_weld_throat, c.d / 2),
                        ('web', -c.web_weld_length / 2, c.web_weld_length / 2),
                        ('flange_bottom', -c.d / 2, -c.d / 2 + c.flange_weld_throat)):
        points = [transform((0, lo)), transform((0, hi))]
        _line(ax, [p[0] for p in points], [p[1] for p in points],
              'cjp_run_' + key, WELD, lw=3.0, zorder=5, solid_capstyle='butt')
    # Axis arrows are reference directions, not unlabelled per-case forces.
    xy0 = transform((span * .6, -c.d * .63))
    xy1 = transform((span * .86, -c.d * .63))
    arrow = ax.annotate('+x', xy=xy1, xytext=xy0, color=MUTED, fontsize=8,
                        arrowprops={'arrowstyle': '->', 'color': MUTED}, va='center')
    arrow.set_gid('local_axis_x_reference')
    y0 = transform((span * .9, c.d * .18)); y1 = transform((span * .9, -c.d * .08))
    yarrow = ax.annotate('+y', xy=y1, xytext=y0, color=MUTED, fontsize=8,
                         arrowprops={'arrowstyle': '->', 'color': MUTED}, ha='center')
    yarrow.set_gid('local_axis_y_reference')
    pad = c.d * .17
    if column:
        ax.set_xlim(-c.d / 2 - pad, c.d / 2 + pad)
        ax.set_ylim(-span - pad * .55, span + pad * .55)
    else:
        ax.set_xlim(-span - pad * .55, span + pad * .55)
        ax.set_ylim(-c.d / 2 - pad, c.d / 2 + pad)
    ax.set_title(('PILAR' if column else 'VIGA') + ' · VISTA LONGITUDINAL\n'
                 'Membro A: x < 0; membro B: x > 0', fontsize=9, loc='left', pad=12, color=INK)


def _access_detail(ax, c):
    max_length = max(c.access_length_a, c.access_length_b)
    hmax = max(c.access_hmax_a, c.access_hmax_b)
    for side, sign in (('a', -1), ('b', 1)):
        x0, x1 = sorted((0, sign * max_length * 1.13))
        _rect(ax, x0, -hmax * 1.3, x1 - x0, hmax * 1.3, 'detail_web_' + side)
        points = [(sign * x, -q) for x, q in access_outline(c, side)]
        _opening(ax, points, 'rounded_opening_detail_' + side)
    _line(ax, [0, 0], [0, -c.access_h0], 'detail_empty_mouth', HOLE, 1.5, zorder=4.6)
    _line(ax, [0, 0], [-hmax * 1.3, -c.access_h0], 'detail_cjp_remaining', WELD, 2.5,
          zorder=5, solid_capstyle='butt')
    _line(ax, [-max_length * 1.13, max_length * 1.13], [0, 0],
          'inner_flange_face_reference', MUTED, .75, linestyle='--', zorder=5)
    dimension(ax, (-c.access_length_a, -hmax * 1.66), (0, -hmax * 1.66),
              'LA=' + _num(c.access_length_a), fontsize=7.2)
    dimension(ax, (0, -hmax * 1.66), (c.access_length_b, -hmax * 1.66),
              'LB=' + _num(c.access_length_b), fontsize=7.2)
    dimension(ax, (max_length * 1.46, -c.access_h0), (max_length * 1.46, 0),
              'h0=' + _num(c.access_h0), fontsize=7.2, rotation=90)
    for side, sign in (('a', -1), ('b', 1)):
        L = getattr(c, 'access_length_' + side); R = getattr(c, 'access_radius_' + side)
        H = getattr(c, 'access_hmax_' + side)
        annotation = ax.annotate('R' + side.upper() + '=' + _num(R), xy=(sign * L, -H + R),
                                 xytext=(sign * max_length * 1.35, hmax * .22),
                                 fontsize=7.2, color=INK, ha='center',
                                 arrowprops={'arrowstyle': '->', 'lw': .7, 'color': INK})
        annotation.set_gid('radius_leader_' + side)
    ax.set_xlim(-max_length * 1.7, max_length * 1.75)
    ax.set_ylim(-hmax * 1.9, hmax * .42)
    ax.set_title('DETALHE AMPLIADO DAS ABERTURAS SUPERIORES\n'
                 'Mesma geometria espelhada nas aberturas inferiores',
                 loc='left', fontsize=8.5, color=INK, pad=10)


def _load_panel(ax, c):
    column = c.orientation == 'column'
    transform = (lambda x, y: (y, x)) if column else (lambda x, y: (x, -y))
    for name, value, direction in (('N', c.N, (1, 0)), ('V', c.V, (0, -1))):
        if value == 0:
            ax.text(-1.45, 1.05 if name == 'N' else .7, name + '=0 kN', fontsize=7.4, color=WELD)
            continue
        sign = 1 if value >= 0 else -1
        a = transform(0, 0); b = transform(sign * direction[0], sign * direction[1])
        arrow = ax.annotate('', xy=b, xytext=a,
                            arrowprops={'arrowstyle': '->', 'color': WELD, 'lw': 1.3})
        arrow.set_gid('actual_load_' + name + ('_positive' if sign > 0 else '_negative'))
        tx, ty = transform(sign * direction[0] * 1.1, sign * direction[1] * 1.1)
        horizontal = abs(tx) > abs(ty)
        ax.text(tx, ty + (.13 if horizontal else 0), name + '=' + _num(value / 1000, True) + ' kN',
                fontsize=7.4, ha=('right' if tx < 0 else 'left') if horizontal else 'center',
                va='bottom' if horizontal or ty > 0 else 'top', color=WELD)
    # Positive M bends toward tension at local +y; this is counterclockwise
    # in the beam's physical screen plane. Orientation rotates the same panel.
    if c.M != 0:
        theta0, theta1 = (pi * .12, pi * 1.55) if c.M >= 0 else (pi * 1.55, pi * .12)
        points = [transform(.43 * cos(theta0 + (theta1 - theta0) * i / 40),
                            -.43 * sin(theta0 + (theta1 - theta0) * i / 40)) for i in range(41)]
        _line(ax, [p[0] for p in points], [p[1] for p in points], 'actual_moment_arc', WELD, 1)
        arrow = ax.annotate('', xy=points[-1], xytext=points[-3],
                            arrowprops={'arrowstyle': '->', 'color': WELD, 'lw': 1.0})
        arrow.set_gid('actual_load_M_positive' if c.M >= 0 else 'actual_load_M_negative')
    ax.text(0, -1.64, 'M=' + _num(c.M / 1e6, True) + ' kN m', ha='center', fontsize=7.4, color=WELD)
    ax.text(0, 1.48, 'x=0', ha='center', fontsize=7, color=MUTED)
    ax.set_xlim(-1.8, 1.8); ax.set_ylim(-1.9, 1.8)
    ax.set_title('AÇÕES REAIS NO CORTE x = 0\nFace +x do membro A; V > 0: −y; M > 0: tração em +y',
                 loc='left', fontsize=8, color=INK, pad=8)


def figure(c, result=None):
    r = validated_result(c, result)
    cases = _cases(c, r)
    # All cases remain visible; output height expands rather than truncating.
    case_lines = []
    for case in cases:
        extra = '; '.join(key + '=' + _num(case.get(key), True)
                          for key in ('torsion', 'weak_M', 'transverse_V')
                          if case.get(key) not in (None, 0, 0.0))
        line = (str(case.get('id')) + ' | ' + str(case.get('label', '')) +
                ' | ' + str(case.get('kind', '')) + ': N=' + _num(case.get('N', 0) / 1000, True) +
                ' kN; M=' + _num(case.get('M', 0) / 1e6, True) +
                ' kN m; V=' + _num(case.get('V', 0) / 1000, True) + ' kN' +
                ('; ' + extra if extra else ''))
        case_lines.extend(rendered_wrap(line, 13 * 72, 8).splitlines())
    declaration_labels = {'material_certified': 'material', 'compatibility_declared': 'compatibilidade',
                          'procedure_qualified': 'procedimento', 'inspection_plan_declared': 'inspeção',
                          'actual_geometry_verified': 'geometria real', 'cut_quality_verified': 'corte',
                          'root_access_verified': 'acesso à raiz', 'alignment_verified': 'alinhamento',
                          'integrity_included': 'integridade'}
    pending = [declaration_labels.get(key, key) for key in DECLARATIONS if getattr(c, key) is not True]
    notes = [
        'CJP: mesas L=' + _num(c.flange_weld_length) + ' mm e garganta=' + _num(c.flange_weld_throat) +
        ' mm; alma L=' + _num(c.web_weld_length) + ' mm e garganta=' + _num(c.web_weld_throat) + ' mm.',
        'Aberturas: h0=' + _num(c.access_h0) + ' mm. A: L=' + _num(c.access_length_a) +
        ', hmax=' + _num(c.access_hmax_a) + ', R=' + _num(c.access_radius_a) +
        ' mm. B: L=' + _num(c.access_length_b) + ', hmax=' + _num(c.access_hmax_b) +
        ', R=' + _num(c.access_radius_b) + ' mm. tf=' + _num(c.tf) + '; tw=' + _num(c.tw) + ' mm.',
        'Materiais: A ' + c.steel_a + '; B ' + c.steel_b + '. Processo ' + c.process +
        '; consumível ' + c.consumable + '; WPS: ' + (c.procedure_id or 'PENDENTE') + '.',
        'Declarações pendentes: ' + (', '.join(pending) if pending else 'nenhuma; declarações informadas pelo responsável') + '.',
        'Fakury: tensões nominais de grupo elástico CJP. V integral na alma receptora; sem aprovação de picos físicos nas aberturas ou flambagem global.',
        'Desenho proporcional de cálculo, sem aprovação para fabricação. Preparação, raiz, tolerâncias, WPS e inspeção exigem detalhamento próprio.',
    ]
    note_lines = []
    for note in notes:
        note_lines.extend(rendered_wrap(note, 13 * 72, 8).splitlines())
    project_text = rendered_wrap(c.project, 13 * 72, 10)
    profile_text = rendered_wrap(c.profile_name + ' | ' + ('Pilar' if c.orientation == 'column' else 'Viga') + ' | ' + COMPONENT_VERSION, 13 * 72, 9)
    header_extra = .18 * max(0, len(project_text.splitlines()) - 1) + .16 * max(0, len(profile_text.splitlines()) - 1)
    height = 9.9 + header_extra + .18 * (len(case_lines) + len(note_lines))
    fig = plt.figure(figsize=(14, height), facecolor='white')
    def text_at(y, text, size=9, weight='normal', color=INK):
        artist = fig.text(.035, 1 - y / height, text, fontsize=size, fontweight=weight,
                          color=color, va='top', linespacing=1.25)
        return artist
    text_at(.25, 'EMENDA W SOLDADA CJP', 15, 'bold')
    text_at(.61, project_text, 10)
    text_at(1.03 + .18 * max(0, len(project_text.splitlines()) - 1), profile_text, 9)
    text_at(1.28 + header_extra, STATUS.get(r.get('status'), str(r.get('status'))) +
            ' · não é liberação de fabricação', 9.5, 'bold', WELD if not r.get('global_pass') else INK)
    section = fig.add_axes((.035, 1 - (6.1 + header_extra) / height, .32, 4.1 / height))
    side = fig.add_axes((.395, 1 - (6.1 + header_extra) / height, .565, 4.1 / height))
    detail = fig.add_axes((.395, 1 - (8.8 + header_extra) / height, .565, 2.0 / height))
    loads = fig.add_axes((.035, 1 - (8.8 + header_extra) / height, .32, 2.0 / height))
    for ax in (section, side, detail, loads):
        ax.set_aspect('equal'); ax.axis('off')
    if _safe_dimensions(c):
        try:
            _section(section, c); _longitudinal(side, c); _access_detail(detail, c); _load_panel(loads, c)
        except (ValueError, OverflowError, ZeroDivisionError):
            for ax in (section, side, detail, loads):
                ax.clear(); ax.axis('off')
            side.text(.5, .5, 'Geometria inválida para representar.\nNenhuma dimensão foi corrigida.',
                      transform=side.transAxes, ha='center', va='center', fontsize=11, color=WELD)
    else:
        side.text(.5, .5, 'Dimensões inválidas para desenho.\nNenhuma geometria foi normalizada.',
                  transform=side.transAxes, ha='center', va='center', fontsize=11, color=WELD)
    y = 9.15 + header_extra
    for line in note_lines:
        text_at(y, line, 8); y += .18
    y += .12
    text_at(y, 'TODOS OS CASOS ASSINADOS · ações reais e suplementares separadas', 9, 'bold'); y += .24
    for line in case_lines:
        text_at(y, line, 8); y += .18
    text_at(y + .13, 'Entradas SHA-256: ' + input_fingerprint(c), 6.5, color=MUTED)
    fig._welded_splice_drawing_height = 8.92 + header_extra
    fig._welded_splice_input_digest = input_fingerprint(c)
    fig._welded_splice_result = r
    return fig


def image_bytes(c, result=None, fmt='png'):
    # A positional format remains convenient without permitting forged results.
    if isinstance(result, str) and result in ('png', 'svg') and fmt == 'png':
        fmt, result = result, None
    if fmt not in ('png', 'svg'):
        raise ValueError('Formato disponível: png ou svg.')
    fig = figure(c, result)
    try:
        out = BytesIO()
        with matplotlib.rc_context({'svg.fonttype': 'none'}):
            fig.savefig(out, format=fmt, dpi=180, facecolor='white',
                        metadata={'Description': 'Entradas SHA-256: ' + input_fingerprint(c)}
                        if fmt == 'svg' else None)
        return out.getvalue()
    finally:
        plt.close(fig)


def drawing_svg(c, result=None):
    return image_bytes(c, result, fmt='svg').decode('utf-8')
