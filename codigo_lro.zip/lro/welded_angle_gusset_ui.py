from .display_precision import calculated_text
"""Native welded angle/gusset UI; isolated from the legacy M004 ``ws_`` state.

The accepted native payload is the source of truth. Unit controls retain the
exact imported scalar until the user edits that control. Rejected imports are
staged and never replace accepted widgets, drafts, results or report bytes.
"""
from .display_precision import display_format, display_frame, display_tree, display_value, number_input
from copy import deepcopy
import hashlib
import json
import math

import pandas as pd
import streamlit as st
from .load_conventions import render as render_load_convention

from .report import BRAND, LINK

PREFIX = 'wag_'
PROJECT = '_welded_angle_gusset_project'
DRAFT = '_welded_angle_gusset_ui_draft'
RESULT = '_welded_angle_gusset_result'
ACCEPTED = '_welded_angle_gusset_accepted_values'
TEMPLATE = '_welded_angle_gusset_native_template'
REPORT = 'wag_report'
# ws_ belongs to the existing bolted axial splice and must never be reused.


def _finite(value):
    try:
        return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)
    except (OverflowError, ValueError):
        return False


def _number(value, field):
    if not _finite(value) or float(value) != value:
        raise ValueError(f'{display_value(field)}: número finito, representável sem perda, obrigatório.')
    return float(value)


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f'Chave JSON duplicada: {display_value(key)}.')
        result[key] = value
    return result


def _json_load(payload):
    if len(payload) > 200000:
        raise ValueError('Arquivo maior que 200 kB.')
    def reject_constant(value):
        raise ValueError('Número JSON inválido: ' + value)
    return json.loads(payload, object_pairs_hook=_unique_object, parse_constant=reject_constant)


def _walk(value, path=()):
    if isinstance(value, dict):
        for key, item in value.items():
            yield from _walk(item, (*path, key))
    elif isinstance(value, (list, tuple)):
        for index, item in enumerate(value):
            yield from _walk(item, (*path, index))
    else:
        yield path, value


def _set_path(value, path, replacement):
    for part in path[:-1]:
        value = value[part]
    value[path[-1]] = replacement


def _factor(path):
    if path[-1] in ('N', 'V', 'V_out', 'out_of_plane_V', 'minor_V', 'weak_V', 'transverse_V'):
        return 1000.
    if path[-1] in ('M', 'M_applied', 'M_out', 'out_of_plane_M', 'torsion', 'T', 'minor_M', 'weak_M'):
        return 1000000.
    return 1.


def _key(path):
    suffix = '_kN' if _factor(path) == 1000. else '_kNm' if _factor(path) == 1000000. else ''
    return PREFIX + '_'.join(map(str, path)) + suffix


def import_ui_values(c):
    """Return all proposed widgets/accepted values before any state mutation."""
    native = c.to_dict()
    proposed, accepted = {}, {}
    for path, raw in _walk(native['connection']):
        display = raw
        if type(raw) in (int, float):
            display = _number(raw, '.'.join(map(str, path))) / _factor(path)
            if raw != 0 and display == 0:
                raise ValueError('.'.join(map(str, path)) + ': conversão de unidade não representável sem perda.')
        proposed[_key(path)] = display
        accepted[path] = {'raw': raw, 'display': display}
    proposed[ACCEPTED] = accepted
    proposed[TEMPLATE] = deepcopy(native)
    return proposed


def decode_project(payload):
    from .welded_angle_gusset import WeldedAngleGusset
    c = WeldedAngleGusset.from_dict(_json_load(payload))
    import_ui_values(c)
    return c


def seed(c):
    proposed = import_ui_values(c)
    st.session_state.update(proposed)
    st.session_state.pop(REPORT, None)
    st.session_state.pop(DRAFT, None)


def _current_native():
    """Rebuild every native field, keeping accepted force bits until edited."""
    s = st.session_state
    native = deepcopy(s[TEMPLATE])
    for path, original in _walk(native['connection']):
        shown = s[_key(path)]
        accepted = s[ACCEPTED][path]
        if shown == accepted['display'] and type(shown) is type(accepted['display']):
            raw = accepted['raw']
        elif type(original) in (int, float):
            _number(shown, '.'.join(map(str, path)))
            raw = shown * _factor(path)
            if not _finite(raw):
                raise ArithmeticError('.'.join(map(str, path)) + ': conversão excede a faixa numérica finita.')
            if type(original) is int and _factor(path) == 1:
                if int(raw) != raw:
                    raise ValueError('.'.join(map(str, path)) + ': inteiro obrigatório.')
                raw = int(raw)
        else:
            raw = shown
        _set_path(native['connection'], path, raw)
    return native


def _save_draft():
    s = st.session_state
    keys = [_key(path) for path, _ in _walk(s[TEMPLATE]['connection'])]
    keys += [ACCEPTED, TEMPLATE, 'wag_report_detailed', 'wag_include_small_angles']
    s[DRAFT] = {key: deepcopy(s[key]) for key in keys if key in s}


def use_example():
    from .welded_angle_gusset import presets
    seed(presets()[st.session_state.wag_example])


def load_project():
    try:
        upload = st.session_state.wag_upload
        if upload is None:
            raise ValueError('Selecione um arquivo JSON.')
        candidate = decode_project(upload.getvalue())
        seed(candidate)
        st.session_state.pop('wag_import_error', None)
    except (ValueError, TypeError, KeyError, OverflowError, UnicodeError) as exc:
        st.session_state.wag_import_error = 'Não foi possível abrir: ' + str(exc)


def _display(value):
    return f"{display_format(value, '.3f')}" if _finite(value) else '—'


def _select(label, options, path, labels=None):
    key = _key(path)
    options = list(options)
    current = st.session_state[key]
    if current not in options:
        options.append(current)
    return st.selectbox(label, options, key=key,
                        format_func=(lambda value: labels.get(value, str(value) + ' · importado')) if labels else str)


def _scalar(path, label=None, options=None, labels=None):
    key = _key(path)
    value = st.session_state[key]
    label = label or str(path[-1])
    if options is not None:
        return _select(label, options, path, labels)
    if type(value) is bool:
        return st.checkbox(label, key=key)
    if type(value) in (int, float):
        return number_input(label, key=key, format='%.2f')
    return st.text_input(label, key=key)


def _fail(exc):
    s = st.session_state
    s.pop(REPORT, None)
    s.pop(PROJECT, None)
    if TEMPLATE in s:
        _save_draft()
    status = 'NUMERICAL_FAILURE' if isinstance(exc, ArithmeticError) else 'INVALID_INPUT'
    s[RESULT] = {'status': status, 'global_pass': False, 'checks': [],
                 'geometry': {'valid': False}, 'summary': {'complete_checks': False},
                 'issues': [{'id': 'ui_input', 'severity': 'error', 'message': str(exc)}]}
    st.error('FALHA NUMÉRICA · CÁLCULO NÃO CONCLUÍDO' if status == 'NUMERICAL_FAILURE' else 'DADOS INVÁLIDOS')
    st.error(str(exc))
    st.caption('Nenhum resultado ou arquivo anterior é válido para a edição atual. Corrija os dados para recalcular.')
    st.button('Gerar memória 1L soldada', disabled=True)


def render():
    try:
        _render()
    except (ArithmeticError, ValueError, TypeError, KeyError) as exc:
        _fail(exc)

STATUS = {
    'INVALID_INPUT': 'DADOS INVÁLIDOS', 'INVALID_GEOMETRY': 'GEOMETRIA FISICAMENTE INVÁLIDA',
    'NUMERICAL_FAILURE': 'FALHA NUMÉRICA · CÁLCULO NÃO CONCLUÍDO',
    'OUTSIDE_SCOPE': 'FORA DO DOMÍNIO DA LIGAÇÃO 1L–CHAPA–MESA W',
    'NOT_VERIFIED': 'NÃO VERIFICADO · CONDIÇÕES PENDENTES',
    'DETAIL_FAIL': 'NÃO ATENDE AO DETALHAMENTO', 'DETAILING_FAIL': 'NÃO ATENDE AO DETALHAMENTO',
    'LOCAL_CHECKS_FAIL': 'NÃO ATENDE ÀS VERIFICAÇÕES LOCAIS',
    'LOCAL_CHECKS_PASS_WITHIN_SCOPE': 'ATENDE ÀS VERIFICAÇÕES LOCAIS NO DOMÍNIO',
    'COMPLETE_CHECKS_FAIL': 'NÃO ATENDE ÀS VERIFICAÇÕES LOCAIS',
    'VERIFIED_SUBCHECK_FAIL': 'NÃO ATENDE ÀS VERIFICAÇÕES LOCAIS',
    'COMPLETE_LOCAL_CHECKS_PASS_WITHIN_SCOPE': 'ATENDE ÀS VERIFICAÇÕES LOCAIS NO DOMÍNIO',
    'COMPLETE_CHECKS_PASS_WITHIN_SCOPE': 'ATENDE ÀS VERIFICAÇÕES LOCAIS NO DOMÍNIO',
    'INCOMPLETE_CHECKS': 'VERIFICAÇÕES INCOMPLETAS',
}
SCOPE_TEXT = ('Uma cantoneira de abas iguais do catálogo identificado, uma aba encostada em uma face da chapa de nó retangular, '
              'duas soldas longitudinais e raiz soldada à mesa exterior de W laminado do catálogo identificado, paralela ao eixo '
              'do W e centrada na alma. Tração estática no plano; transferência equilibrada calcanhar/ponta '
              'derivada de b e ec da seção selecionada, mantendo a excentricidade real e o momento da raiz. '
              'NBR 8800:2024 / Errata 1:2025, 6.1.8.2: idealização estática de ligação por uma aba, '
              'sem eliminar shear lag ou o momento da chapa.')

LABELS = {
    'project': 'Identificação do projeto', 'support_member': 'Membro de apoio',
    'support_face': 'Face receptora', 'angle_profile': 'Cantoneira de catálogo',
    'support_profile': 'Perfil W receptor', 'angle_steel': 'Aço da cantoneira',
    'gusset_steel': 'Aço da chapa de nó', 'support_steel': 'Aço do apoio W',
    'angle_electrode': 'Eletrodo cantoneira–chapa', 'root_electrode': 'Eletrodo chapa–mesa W',
    'plate_width': 'Largura da chapa / raiz B (mm)', 'plate_height': 'Projeção da chapa H (mm)',
    'plate_t': 'Espessura da chapa t (mm)', 'theta_deg': 'Ângulo da cantoneira com o eixo longitudinal do apoio W · θ (graus)',
    'center_s': 'Centro das soldas em s (mm)', 'center_n': 'Centro das soldas em n (mm)',
    'weld_length': 'Comprimento efetivo de cada solda 1L (mm)',
    'end_margin': 'Trecho sem solda na extremidade livre (mm)',
    'angle_weld_leg': 'Perna inscrita dos filetes cantoneira–chapa (mm)',
    'angle_weld_edge_detail': 'Detalhe da borda da cantoneira',
    'root_weld_leg': 'Perna dos dois filetes da raiz (mm)',
    'introduction_width': 'Largura da seção local de introdução (mm)',
    'support_end_left': 'Posição da extremidade W à esquerda · módulo (mm)',
    'support_end_right': 'Posição da extremidade W à direita (mm)',
    'N': 'Força axial na cantoneira N · tração positiva (kN)', 'V': 'Cortante adicional fora do modelo (kN)',
    'M': 'Momento adicional fora do modelo (kN·m)', 'torsion': 'Torção / ação espacial (kN·m)',
    'static': 'Carregamento estático', 'normal_combination': 'Combinação última normal',
    'fatigue': 'Fadiga exigida', 'seismic': 'Qualificação sísmica exigida',
    'minimum_force': 'Aplicar mínimo de força de 45 kN em caso separado',
    'recommend_half_capacity': 'Aplicar recomendação de meia capacidade em caso separado',
    'notes': 'Observações do responsável técnico',
}


def checks_complete(result):
    rows = result.get('checks') or []
    required = {'id', 'label', 'component', 'mechanism', 'case_id', 'demand', 'resistance', 'utilization', 'status'}
    return bool(rows) and result.get('summary', {}).get('complete_checks') is True and all(
        isinstance(row, dict) and required <= row.keys()
        and all(_finite(row[key]) for key in ('demand', 'resistance', 'utilization'))
        and row['status'] in ('PASS', 'FAIL') for row in rows)


def _checks_table(rows):
    return pd.DataFrame([{'Caso': x.get('case_id'), 'Verificação': x.get('label', x.get('name', x.get('id'))),
                          'ID': x.get('id'), 'Solicitação': x.get('demand'), 'Resistência': x.get('resistance'),
                          'Unidade': x.get('unit', 'N'), 'Índice': x.get('utilization'),
                          'Resultado': x.get('status', 'PASS' if x.get('utilization', 2) <= 1 else 'FAIL')}
                         for x in rows])


def _render():
    from .welded_angle_gusset import WeldedAngleGusset, FAMILY, COMPONENT_VERSION, MATERIALS, ELECTRODES, SUPPORT_CATALOG, evaluate, presets
    from .welded_angle_gusset_drawing import image_bytes
    from .welded_angle_gusset_report import create_report
    from .welded_angle_gusset_presentation import (physical_envelopes, selected_angle, angle_transfer,
                                                  angle_identity, angle_detail_disclosure)
    from .angle_catalog import catalog, label as angle_label

    s = st.session_state
    saved, draft = s.get(PROJECT), s.get(DRAFT)
    prior_report = s.pop(REPORT, None)
    s.pop(PROJECT, None); s.pop(RESULT, None)
    if 'wag_project' not in s:
        seed(WeldedAngleGusset.from_dict(saved) if saved else next(iter(presets().values())))
        if draft: s.update(draft)
    for path, _ in _walk(s[TEMPLATE]['connection']):
        key = _key(path)
        if key in s: s[key] = s[key]
    with st.sidebar:
        st.caption('Versão ' + COMPONENT_VERSION + ' · 1L soldada à chapa e mesa W')
        st.selectbox('Exemplo 1L soldada', list(presets()), key='wag_example')
        st.button('Usar exemplo 1L soldada', on_click=use_example)
        st.file_uploader('Abrir projeto 1L soldada', type=['json'], key='wag_upload')
        st.button('Carregar 1L soldada', on_click=load_project)
        if 'wag_import_error' in s: st.error(s.wag_import_error)
        st.caption(BRAND); st.link_button('LinkedIn · Lucas Oliveira', LINK)
    st.title(FAMILY)
    st.info(SCOPE_TEXT)
    st.caption('O domínio é verificado com as dimensões informadas: editar não ajusta outras medidas. '
               'Alma direta, compressão, ações espaciais e 2L exigem outro modelo. Não há aprovação global do apoio ou liberação de fabricação.')
    _scalar(('project',), LABELS['project'])
    left, right = st.columns([.95, 1.5], gap='large')
    rendered = {'project'}
    def scalar(name, options=None, labels=None):
        if (name,) in s[ACCEPTED]:
            _scalar((name,), LABELS.get(name, name), options, labels); rendered.add(name)
    with left:
        st.subheader('Membro, ações e materiais independentes')
        scalar('support_member', ('beam', 'column'), {'beam': 'Viga W', 'column': 'Pilar W'})
        scalar('support_face', ('flange', 'web'), {'flange': 'Mesa exterior · centrada na alma', 'web': 'Alma direta · fora deste domínio'})
        st.caption('Viga ou pilar conserva o cálculo local nos eixos s/n. Alma direta permanece identificada e não reaproveita a aprovação da mesa.')
        scalar('N')
        load_convention_slot = st.empty()
        with st.expander('Ações e condições fora do domínio'):
            for name in ('V', 'M', 'torsion', 'static', 'normal_combination', 'fatigue', 'seismic'): scalar(name)
            st.caption('O momento geométrico da raiz é calculado e preservado. Os campos acima são ações adicionais; valores não nulos nunca são descartados.')
        for name in ('angle_steel', 'gusset_steel', 'support_steel'): scalar(name, list(MATERIALS))
        for name in ('angle_electrode', 'root_electrode'): scalar(name, list(ELECTRODES))
        st.caption('Os três metais base e os dois consumíveis são registros independentes. Trocar a chapa não troca a cantoneira nem o apoio.')
        with st.expander('Cantoneira e soldas sobre a chapa', expanded=True):
            angles = catalog(include_legacy=True)
            include_small = st.checkbox('Incluir cantoneiras menores que 2½ pol.', key='wag_include_small_angles')
            visible_angles = [identity for identity, section in angles.items() if include_small or section['leg'] >= 63.5]
            scalar('angle_profile', visible_angles, {identity: angle_label(identity) for identity in angles})
            if s.get('wag_angle_profile') in angles and s['wag_angle_profile'] not in visible_angles:
                st.caption('Perfil atual menor que 2½ pol. preservado na seleção; nenhuma substituição automática.')
            selected = angles.get(s.get('wag_angle_profile'))
            if selected:
                st.caption(angle_identity(selected) + '; b=' + _display(selected['leg']) + ' mm; t=' + _display(selected['t'])
                           + ' mm; Ag=' + _display(selected['Ag']) + ' mm²; ec=' + _display(selected['centroid']) + ' mm.')
                st.caption('Fonte: ' + selected['source'])
                if not selected.get('section_properties_published'):
                    st.warning('Ag e ec não foram publicados nesta linha: cálculo resistente não disponível; nenhuma propriedade será estimada.')
                st.caption(angle_detail_disclosure(selected))
                st.caption('A escolha do perfil não altera o aço da cantoneira. Geometria e especificação do material são seleções independentes.')
            for name in ('theta_deg', 'center_s', 'center_n', 'weld_length', 'end_margin', 'angle_weld_leg'): scalar(name)
            scalar('angle_weld_edge_detail', ('ordinary', 'reinforced'),
                   {'ordinary': 'Borda comum · limite normativo sem reforço',
                    'reinforced': 'Borda reforçada · executar detalhe para garganta efetiva'})
            st.caption('Borda reforçada é uma escolha de detalhe de projeto. A execução deve garantir a garganta especificada conforme NBR 8800, 6.2.6.2.2(b).')
            st.caption('θ é medido de +s, paralelo ao eixo longitudinal da viga ou do pilar receptor, até o eixo da cantoneira. '
                       'A referência acompanha o apoio; não é a horizontal global. Ângulos agudos e obtusos mantêm os sinais das ações, dentro das condições geométricas do modelo.')
            transfer = angle_transfer(selected)
            if transfer:
                st.caption('Uma aba encostada; raízes reais a ' + _display(selected['leg']) + ' mm; centroide a '
                           + _display(selected['centroid']) + ' mm da face. Calcanhar=' + _display(100*transfer['heel'])
                           + '%; ponta=' + _display(100*transfer['toe']) + '%, uniformes ao longo de cada solda. '
                           'Centroide projetado v=' + _display(transfer['projected_centroid']) + ' mm.')
        with st.expander('Chapa, corte externo e raiz', expanded=True):
            for name in ('plate_width', 'plate_height', 'plate_t', 'root_weld_leg', 'introduction_width'): scalar(name)
            from .gusset_outer_end_ui import render as render_outer_end
            rendered.update(render_outer_end(st,'wag_','welded'))
            st.caption('A raiz usa dois filetes de comprimento B; a área da chapa na raiz é B·t, sem duplicação. '
                       'Seções horizontais e introdução local alimentam os mesmos envelopes físicos.')
        with st.expander('Apoio W e posição das extremidades'):
            scalar('support_profile', list(SUPPORT_CATALOG))
            scalar('support_end_left'); scalar('support_end_right')
            profile = SUPPORT_CATALOG.get(s.get('wag_support_profile'))
            if profile:
                st.caption('Perfil selecionado: ' + '; '.join(k + '=' + _display(profile[k]) + ' mm' for k in ('d', 'bf', 'tw', 'tf', 'r', 'k')))
                st.caption('Fonte: ' + profile['source'])
            st.caption('Raiz longitudinal e centrada sobre a alma. Exportar Nnormal, Vparalelo e M para a verificação do membro com suas ações concorrentes reais.')
        with st.expander('Política de ações'):
            scalar('minimum_force'); scalar('recommend_half_capacity')
            st.caption('Casos mínimos ou recomendados são alternativas separadas; não se misturam máximos de combinações diferentes.')
        # Future native fields cannot be silently hidden or discarded.
        other = [(path, value) for path, value in _walk(s[TEMPLATE]['connection']) if path[0] not in rendered and path[0] != 'notes']
        if other:
            with st.expander('Outras entradas nativas'):
                for path, _ in other: _scalar(path, '.'.join(map(str, path)))
        if ('notes',) in s[ACCEPTED]: st.text_area(LABELS['notes'], key='wag_notes')

    native = _current_native(); c = WeldedAngleGusset.from_dict(native)
    encoded = json.dumps(native, ensure_ascii=False, indent=2, allow_nan=False)
    with load_convention_slot.container():
        render_load_convention(st, 'welded_angle_gusset', c.N, theta_deg=c.theta_deg)
    _save_draft(); r = evaluate(c)
    digest = hashlib.sha256((encoded + json.dumps(r, ensure_ascii=False, sort_keys=True, allow_nan=False)).encode()).hexdigest()
    s[PROJECT], s[RESULT] = native, r
    complete = checks_complete(r); geometry_valid = r.get('geometry', {}).get('valid') is True
    status = r.get('status', 'INVALID_INPUT')
    ready = complete and geometry_valid and not status.startswith(('INVALID', 'NUMERICAL', 'OUTSIDE'))
    png = image_bytes(c, fmt='png') if geometry_valid else None
    with right:
        label = STATUS.get(status, status)
        if r.get('global_pass') is True and complete and geometry_valid: st.success(label + ' · LIGAÇÃO LOCAL')
        elif status == 'NOT_VERIFIED': st.warning(label)
        else: st.error(label)
        st.caption('Atendimento local não é aprovação da estrutura nem liberação de fabricação. '
                   'Um limite conservador excedido é uma falha de triagem do método, sem afirmar uma fissura física exata.')
        a, b = st.columns(2)
        a.metric('N real (kN)', _display(c.N / 1000.)); b.metric('Índice governante', _display(r.get('summary', {}).get('utilization')))
        for issue in r.get('issues') or []:
            message = issue.get('message', issue.get('text', str(issue)))
            if issue.get('severity') in ('info', 'note'): st.caption(message)
            elif issue.get('severity') in ('warning', 'pending', 'engineering_pending'): st.warning(message)
            else: st.error(message)
        for fabrication_note in (r.get('geometry') or {}).get('fabrication_notes', []):
            st.info(calculated_text(fabrication_note, assignments_only=True))
        if png: st.image(png, width='stretch')
        transfer = angle_transfer(selected_angle(c, r))
        centroid_text = ('v=' + _display(transfer['projected_centroid']) + ' mm' if transfer else 'não disponível')
        st.caption('N é a força axial na cantoneira. Momento local derivado da excentricidade da força axial; não é momento aplicado à cantoneira. '
                   'A referência de Mraiz é o centroide do grupo de soldas da raiz. O centro das soldas e o centroide real '
                   + centroid_text + ' definem a linha de força; não há afastamento arbitrário acrescentado.')
        with st.expander('Geometria, equilíbrio da raiz e ações para o membro'):
            for key in ('geometry', 'root', 'member_actions'):
                st.json(display_tree(r.get(key) or {}), expanded=False)
        if r.get('cases'):
            st.subheader('Casos independentes')
            st.dataframe(display_frame(pd.DataFrame([{'Caso': x.get('label', x.get('id')), 'ID': x.get('id'),
                                       'Natureza': x.get('kind', 'actual' if x.get('id') == 'actual' else 'supplementary'), 'N (kN)': x.get('N', 0) / 1000.}
                                      for x in r['cases']])), hide_index=True, width='stretch')
    if complete:
        st.subheader('Resultados por componente e mecanismo físico')
        envelopes = physical_envelopes(r)
        st.dataframe(display_frame(pd.DataFrame([{'Componente': e['component_label'], 'Mecanismo': e['mechanism_label'],
                                    'Índice real': e['actual_utilization'], 'Índice adotado': e['utilization'],
                                    'Resultado': e['status'], 'Governantes e empates': '; '.join(e['governing_ids'])}
                                   for e in envelopes])), hide_index=True, width='stretch')
        with st.expander('Governantes e ramos preservados'): st.json(display_tree(envelopes), expanded=False)
        with st.expander('Primitivas de ruptura por caso · áreas, estações e bordas reais'):
            for case in r.get('cases') or []:
                paths = case.get('paths') or []
                st.caption('Caso ' + str(case.get('id')) + ' · ' + str(len(paths)) + ' famílias de caminhos ativas')
                inactive = case.get('inactive_path_families') or []
                if inactive:
                    st.caption('Famílias geometricamente inativas: a borda livre não captura força positiva ou o bloco continua ligado à raiz apoiada; não são verificações esquecidas.')
                    st.dataframe(display_frame(pd.DataFrame([{'Família': x.get('id'), 'Motivo': x.get('reason')} for x in inactive])), hide_index=True, width='stretch')
                    st.json(display_tree(inactive), expanded=False)
                if paths: st.dataframe(display_frame(_checks_table(paths)), hide_index=True, width='stretch')
                st.json(display_tree(paths), expanded=False)
            st.caption('Inclui limites inferiores conservadores, identificados como tais; não são caminhos exatos de fissura inventados.')
        with st.expander('Seções, verificações completas e materiais'):
            st.dataframe(display_frame(_checks_table(r['checks'])), hide_index=True, width='stretch')
            for key in ('checks', 'cases', 'materials'): st.json(display_tree(r.get(key) or []), expanded=False)
    elif r.get('checks'):
        st.warning('Registros incompletos: conclusão resistente e emissão da memória bloqueadas.')
        st.json(display_tree(r['checks']), expanded=False)
    a, b, d = st.columns(3)
    a.download_button('Salvar projeto 1L soldada .json', encoded, 'ligacao_1L_soldada_gusset.json', 'application/json')
    if geometry_valid:
        b.download_button('Baixar desenho 1L soldada .png', png, 'ligacao_1L_soldada_gusset.png', 'image/png')
        b.download_button('Baixar desenho 1L soldada .svg', image_bytes(c, fmt='svg'), 'ligacao_1L_soldada_gusset.svg', 'image/svg+xml')
    detailed = d.checkbox('Memória detalhada · incluir primitivas e testemunhos', key='wag_report_detailed')
    report_digest = hashlib.sha256((digest + str(detailed)).encode()).hexdigest()
    if ready and prior_report and prior_report[0] == report_digest: s[REPORT] = prior_report
    if ready and not r.get('global_pass'): st.caption('A memória registra a falha atual; emiti-la não aprova a ligação.')
    if d.button('Gerar memória 1L soldada', disabled=not ready):
        name = 'memoria_1L_soldada_gusset' + ('_detalhada' if detailed else '') + '.docx'
        s[REPORT] = (report_digest, name, create_report(c, detailed=detailed))
    if REPORT in s:
        _, name, payload = s[REPORT]
        st.download_button('Baixar memória 1L soldada .docx', payload, name,
                           'application/vnd.openxmlformats-officedocument.wordprocessingml.document')
