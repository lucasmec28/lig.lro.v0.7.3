"""Separate experimental AISC seat UI. Does not borrow ASI factors."""
import json
from dataclasses import asdict
import streamlit as st
from .stiffened_console import Console,evaluate,KIP,FAMILY,project,from_project
from .stiffened_console_catalog import COLUMNS,MATERIALS
from .stiffened_console_report import csv_bytes,word_bytes
from pathlib import Path

def _import_project():
    try:
        upload=st.session_state.get("aisc_console_upload")
        if upload is None: raise ValueError("Selecione um projeto JSON.")
        if upload.size>100000: raise ValueError("Arquivo maior que100kB.")
        def pairs(items):
            out={}
            for k,v in items:
                if k in out: raise ValueError("Campo JSON duplicado.")
                out[k]=v
            return out
        c=from_project(json.loads(upload.getvalue(),object_pairs_hook=pairs))
        proposed={"aisc_console_"+k:(v/1000 if k=="reaction" else v) for k,v in asdict(c).items()}
        for key,value in proposed.items():
            if key not in ('aisc_console_column_profile','aisc_console_column_material') and not .001<=value<=100000.:
                raise ValueError('Valor fora da faixa da interface: '+key+'. Projeto atual preservado.')
        st.session_state.update(proposed)
        st.session_state.pop("aisc_console_import_error",None)
    except (ValueError,TypeError,KeyError,UnicodeError) as e:
        st.session_state["aisc_console_import_error"]=str(e)

def render():
    st.header('Console com nervura recortada')
    st.caption('Escopo local delimitado · AISC 360-16 LRFD / Manual 15 · unidades mm, kN')
    st.info('Domínio verificado: viga I/W simétrica com propriedades e Fy declarados; pilar do catálogo auditado Gerdau/AISC, material declarado, apoio em um lado da alma. Chapas A36 e soldas E70. Projeção entre101,6 e177,8mm; recortes com patamares de20mm. A correspondência americana é explicitamente publicada pela Gerdau; não é deduzida pelo peso.')
    st.write('O assento recebe a reação por contato. A nervura fica ajustada sob o assento. Há duas soldas verticais ao pilar e uma solda horizontal na face inferior do assento, estendida 0,2l para cada lado da nervura.')
    st.file_uploader('Importar projeto deste console',type=['json'],key='aisc_console_upload')
    st.button('Carregar projeto JSON',on_click=_import_project)
    if st.session_state.get('aisc_console_import_error'):st.error(st.session_state['aisc_console_import_error'])
    a,b=st.columns(2);vals={};c=Console()
    vals['column_profile']=st.selectbox('Pilar receptor auditado',list(COLUMNS),index=list(COLUMNS).index(c.column_profile),key='aisc_console_column_profile')
    vals['column_material']=st.selectbox('Material declarado do pilar: confirmar certificado',list(MATERIALS),index=list(MATERIALS).index(c.column_material),key='aisc_console_column_material')
    col=COLUMNS[vals['column_profile']]
    st.caption(f"Correspondência: {col['us_designation']}; tw={col['tw']:g} mm; envelope conservador de montagem={col['fit_clear']:g} mm.")
    labels={'beam_k1':'k1 da viga: meia largura da alma com concordância [mm]','beam_d':'Altura da viga [mm]','beam_bf':'Largura da mesa da viga [mm]','beam_tw':'Espessura da alma da viga [mm]','beam_tf':'Espessura da mesa da viga [mm]','beam_k':'k da viga: face externa até fim da concordância [mm]','beam_fy':'Fy declarado da viga [MPa]','projection':'Projeção do assento W [mm]','reaction':'Reação vertical de cálculo [kN]','length':'Altura da nervura l [mm]','weld':'Perna das soldas ao pilar [mm]','rib_thickness':'Espessura da nervura [mm]','seat_thickness':'Espessura do assento [mm]','seat_width':'Largura transversal do assento [mm]','rib_seat_weld':'Perna da solda nervura–assento [mm]','rib_seat_length':'Comprimento dessa solda, por lado [mm]'}
    for i,(key,val) in enumerate(asdict(c).items()):
        if key in ('rib_seat_weld','column_profile','column_material'): continue
        with (a if i%2==0 else b):
            shown=val/1000 if key=='reaction' else val
            vals[key]=st.number_input(labels[key],value=float(shown),min_value=0.001,max_value=100000.0,format='%.2f',key='aisc_console_'+key)*(1000 if key=='reaction' else 1)
    vals['rib_seat_weld']=vals['weld']
    r=evaluate(Console(**vals))
    st.subheader(r['status'])
    for e in r['errors']:st.error(e)
    rows=[]
    for row in r['checks']:
        scale=1000 if row['unit']=='N' else 1
        rows.append({'Verificação':row['name'],'Solicitação / mínimo':round(row['demand']/scale,2),'Resistência / disponível':round(row['capacity']/scale,2),'Unidade':'kN' if scale==1000 else row['unit'],'Utilização':round(row['ratio'],2),'Resultado':'OK' if row['ok'] else 'NÃO ATENDE','Referência':row['reference']})
    st.dataframe(rows,hide_index=True,use_container_width=True)
    st.caption('Solda nervura–assento com a mesma perna das soldas ao pilar, conforme domínio qualificado.')
    st.subheader('Condições do detalhe')
    for note in r.get('warnings',[]):st.write('• '+note)
    st.write('Parafusos e contenção superior seguem o detalhe prescritivo explicitado; forças horizontais, levantamento e momento imposto ficam fora deste domínio.')
    st.download_button('Baixar projeto JSON',json.dumps(project(Console(**vals)),ensure_ascii=False,indent=2),'console_aisc_projeto.json','application/json')
    st.download_button('Baixar resultados CSV',csv_bytes(Console(**vals)),'console_aisc_resultados.csv','text/csv')
    sketch=Path(__file__).parent.parent/'data'/'console_aisc_soldas_completadas.png'
    st.image(str(sketch),caption='Croqui original do caminho de carga; dimensões gerais esquemáticas.')
    st.download_button('Baixar memória Word',word_bytes(Console(**vals),sketch),'console_aisc_memoria.docx','application/vnd.openxmlformats-officedocument.wordprocessingml.document')
    st.download_button('Baixar memória numérica JSON',json.dumps(r,ensure_ascii=False,indent=2),'console_aisc_memoria.json','application/json')
    with st.expander('Equação original e referência do benchmark'):
        st.write('Grupo T: comprimento total 2,4l; módulo resistente à tração 0,6l²; excentricidade 0,8W. Capacidade LRFD=0,75×0,6FEXX×0,7071w / √[(1/(2,4l))²+(0,8W/(0,6l²))²].')
        st.write('Companion II.A-15: l = 381 mm, W = 177,8 mm, w = 7,9375 mm. Resultado 139,43 kip, frente ao valor publicado arredondado 139 kip. O pequeno desvio decorre de 0,7071 em vez de 0,707.')
