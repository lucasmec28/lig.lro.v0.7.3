"""Native CJP W-splice UI; isolated from the legacy M004 ``ws_`` state.

The accepted native payload is the source of truth. Unit controls retain the
exact imported scalar until the user edits that control. Rejected imports are
staged and never replace accepted widgets, drafts, results or report bytes.
"""
from .display_precision import display_format, display_frame, display_tree, display_value, number_input
from copy import deepcopy
import hashlib
import json
import math

import pandas as pd
import streamlit as st
from .load_conventions import render as render_load_convention, render_axial_state

from .models import STEELS
from .report import BRAND, LINK

PREFIX = 'wws_'
PROJECT = '_welded_w_splice_project'
DRAFT = '_welded_w_splice_ui_draft'
RESULT = '_welded_w_splice_result'
ACCEPTED = '_welded_w_splice_accepted_values'
TEMPLATE = '_welded_w_splice_native_template'
REPORT = 'wws_report'
# ws_ belongs to the existing bolted axial splice and must never be reused.


def _finite(value):
    try:
        return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)
    except (OverflowError, ValueError):
        return False


def _number(value, field):
    if not _finite(value) or float(value) != value:
        raise ValueError(f'{display_value(field)}: número finito, representável sem perda, obrigatório.')
    return float(value)


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f'Chave JSON duplicada: {display_value(key)}.')
        result[key] = value
    return result


def _json_load(payload):
    if len(payload) > 200000:
        raise ValueError('Arquivo maior que 200 kB.')
    def reject_constant(value):
        raise ValueError('Número JSON inválido: ' + value)
    return json.loads(payload, object_pairs_hook=_unique_object, parse_constant=reject_constant)


def _walk(value, path=()):
    if isinstance(value, dict):
        for key, item in value.items():
            yield from _walk(item, (*path, key))
    elif isinstance(value, (list, tuple)):
        for index, item in enumerate(value):
            yield from _walk(item, (*path, index))
    else:
        yield path, value


def _set_path(value, path, replacement):
    for part in path[:-1]:
        value = value[part]
    value[path[-1]] = replacement


def _factor(path):
    if path[-1] in ('N', 'V', 'minor_V', 'weak_V', 'transverse_V'):
        return 1000.
    if path[-1] in ('M', 'torsion', 'T', 'minor_M', 'weak_M'):
        return 1000000.
    return 1.


def _key(path):
    suffix = '_kN' if _factor(path) == 1000. else '_kNm' if _factor(path) == 1000000. else ''
    return PREFIX + '_'.join(map(str, path)) + suffix


def import_ui_values(c):
    """Return all proposed widgets/accepted values before any state mutation."""
    native = c.to_dict()
    proposed, accepted = {}, {}
    for path, raw in _walk(native['connection']):
        display = raw
        if type(raw) in (int, float):
            display = _number(raw, '.'.join(map(str, path))) / _factor(path)
            if raw != 0 and display == 0:
                raise ValueError('.'.join(map(str, path)) + ': conversão de unidade não representável sem perda.')
        proposed[_key(path)] = display
        accepted[path] = {'raw': raw, 'display': display}
    proposed[ACCEPTED] = accepted
    proposed[TEMPLATE] = deepcopy(native)
    return proposed


def decode_project(payload):
    from .welded_w_splice import WeldedWSplice
    c = WeldedWSplice.from_dict(_json_load(payload))
    import_ui_values(c)
    return c


def seed(c):
    proposed = import_ui_values(c)
    st.session_state.update(proposed)
    st.session_state.pop(REPORT, None)
    st.session_state.pop(DRAFT, None)


def _current_native():
    """Rebuild every native field, keeping accepted force bits until edited."""
    s = st.session_state
    native = deepcopy(s[TEMPLATE])
    for path, original in _walk(native['connection']):
        shown = s[_key(path)]
        accepted = s[ACCEPTED][path]
        if shown == accepted['display'] and type(shown) is type(accepted['display']):
            raw = accepted['raw']
        elif type(original) in (int, float):
            _number(shown, '.'.join(map(str, path)))
            raw = shown * _factor(path)
            if not _finite(raw):
                raise ArithmeticError('.'.join(map(str, path)) + ': conversão excede a faixa numérica finita.')
            if type(original) is int and _factor(path) == 1:
                if int(raw) != raw:
                    raise ValueError('.'.join(map(str, path)) + ': inteiro obrigatório.')
                raw = int(raw)
        else:
            raw = shown
        _set_path(native['connection'], path, raw)
    return native


def _save_draft():
    s = st.session_state
    keys = [_key(path) for path, _ in _walk(s[TEMPLATE]['connection'])]
    keys += [ACCEPTED, TEMPLATE, 'wws_report_detailed']
    s[DRAFT] = {key: deepcopy(s[key]) for key in keys if key in s}


def use_example():
    from .welded_w_splice import presets
    seed(presets()[st.session_state.wws_example])


def load_project():
    try:
        upload = st.session_state.wws_upload
        if upload is None:
            raise ValueError('Selecione um arquivo JSON.')
        candidate = decode_project(upload.getvalue())
        seed(candidate)
        st.session_state.pop('wws_import_error', None)
    except (ValueError, TypeError, KeyError, OverflowError, UnicodeError) as exc:
        st.session_state.wws_import_error = 'Não foi possível abrir: ' + str(exc)


def _display(value):
    return f"{display_format(value, '.3f')}" if _finite(value) else '—'


def _select(label, options, path, labels=None):
    key = _key(path)
    options = list(options)
    current = st.session_state[key]
    if current not in options:
        options.append(current)
    return st.selectbox(label, options, key=key,
                        format_func=(lambda value: labels.get(value, str(value) + ' · importado')) if labels else str)


def _scalar(path, label=None, options=None, labels=None):
    key = _key(path)
    value = st.session_state[key]
    label = label or str(path[-1])
    if options is not None:
        return _select(label, options, path, labels)
    if type(value) is bool:
        return st.checkbox(label, key=key)
    if type(value) in (int, float):
        return number_input(label, key=key, format='%.2f')
    return st.text_input(label, key=key)


def _fail(exc):
    s = st.session_state
    s.pop(REPORT, None)
    s.pop(PROJECT, None)
    if TEMPLATE in s:
        _save_draft()
    status = 'NUMERICAL_FAILURE' if isinstance(exc, ArithmeticError) else 'INVALID_INPUT'
    s[RESULT] = {'status': status, 'global_pass': False, 'checks': [],
                 'geometry': {'valid': False}, 'summary': {'complete_checks': False},
                 'issues': [{'id': 'ui_input', 'severity': 'error', 'message': str(exc)}]}
    st.error('FALHA NUMÉRICA · CÁLCULO NÃO CONCLUÍDO' if status == 'NUMERICAL_FAILURE' else 'DADOS INVÁLIDOS')
    st.error(str(exc))
    st.caption('Nenhum resultado ou arquivo anterior é válido para a edição atual. Corrija os dados para recalcular.')
    st.button('Gerar memória W soldada', disabled=True)


def render():
    try:
        _render()
    except (ArithmeticError, ValueError, TypeError, KeyError) as exc:
        _fail(exc)


STATUS = {
    'INVALID_INPUT': 'DADOS INVÁLIDOS',
    'INVALID_GEOMETRY': 'GEOMETRIA FISICAMENTE INVÁLIDA',
    'NUMERICAL_FAILURE': 'FALHA NUMÉRICA · CÁLCULO NÃO CONCLUÍDO',
    'OUTSIDE_SCOPE': 'FORA DO DOMÍNIO DA EMENDA W SOLDADA',
    'NOT_VERIFIED': 'NÃO VERIFICADO · DECLARAÇÕES PENDENTES',
    'DETAIL_FAIL': 'NÃO ATENDE AO DETALHAMENTO',
    'DETAILING_FAIL': 'NÃO ATENDE AO DETALHAMENTO',
    'LOCAL_CHECKS_FAIL': 'NÃO ATENDE ÀS VERIFICAÇÕES LOCAIS',
    'LOCAL_CHECKS_PASS_WITHIN_SCOPE': 'ATENDE ÀS VERIFICAÇÕES LOCAIS NO DOMÍNIO',
    'COMPLETE_CHECKS_FAIL': 'NÃO ATENDE ÀS VERIFICAÇÕES LOCAIS',
    'VERIFIED_SUBCHECK_FAIL': 'NÃO ATENDE ÀS VERIFICAÇÕES LOCAIS',
    'COMPLETE_LOCAL_CHECKS_PASS_WITHIN_SCOPE': 'ATENDE ÀS VERIFICAÇÕES LOCAIS NO DOMÍNIO',
    'COMPLETE_CHECKS_PASS_WITHIN_SCOPE': 'ATENDE ÀS VERIFICAÇÕES LOCAIS NO DOMÍNIO',
    'INCOMPLETE_CHECKS': 'VERIFICAÇÕES INCOMPLETAS',
}
DECLARATION_LABELS = {
    'material_certified': 'Certificados dos dois aços conferidos',
    'compatibility_declared': 'Processo e consumível compatíveis com os metais-base',
    'procedure_qualified': 'WPS qualificada e aplicável a esta junta e posição',
    'inspection_plan_declared': 'Plano de inspeção e aceitação definido',
    'actual_geometry_verified': 'Curvas, raízes e seções reais de ambos os membros conferidas',
    'cut_quality_verified': 'Cortes, transições suaves e acabamento verificados',
    'root_access_verified': 'Acesso real à raiz e execução CJP verificados',
    'alignment_verified': 'Alinhamento e tolerâncias reais conferidos',
    'integrity_included': 'Combinações reais e ações de integridade aplicáveis incluídas',
}


def checks_complete(result):
    rows = result.get('checks') or []
    required = {'id', 'label', 'component', 'mechanism', 'case_id', 'demand', 'resistance', 'utilization', 'status'}
    return bool(rows) and result.get('summary', {}).get('complete_checks') is True and all(
        isinstance(row, dict) and required <= row.keys()
        and all(_finite(row[key]) for key in ('demand', 'resistance', 'utilization'))
        and row['status'] in ('PASS', 'FAIL') for row in rows)


def _case_change(remove=False):
    from dataclasses import asdict
    from .welded_w_splice import LoadCase, WeldedWSplice
    try:
        native = _current_native()
        cases = native['connection']['load_cases']
        if remove:
            if cases:
                cases.pop()
        else:
            used = {case['id'] for case in cases}
            index = len(cases) + 2
            while f'real_{display_value(index)}' in used:
                index += 1
            cases.append(asdict(LoadCase(id=f'real_{display_value(index)}', label=f'Combinação adicional {display_value(index - 1)}')))
        seed(WeldedWSplice.from_dict(native))
        st.session_state.pop('wws_case_error', None)
    except (ValueError, TypeError, KeyError, ArithmeticError) as exc:
        st.session_state.wws_case_error = str(exc)


def _dimension_fields(items):
    for name, label in items:
        _scalar((name,), label + ' (mm)')


def _actions(path=(), additional=False):
    for name, label in (('N', 'Normal N · tração positiva (kN)'),
                        ('M', 'Momento M · eixo forte (kN·m)'),
                        ('V', 'Cortante V · plano da alma (kN)')):
        _scalar((*path, name), label)
        if additional and name == 'N':
            accepted = st.session_state[ACCEPTED][(*path, name)]
            shown = st.session_state[_key((*path, name))]
            axial = accepted['raw'] if shown == accepted['display'] else shown
            render_axial_state(st, 'welded_w_splice', axial)
    with st.expander('Ações fora do domínio' + (' · ' + str(path[1] + 1) if additional else '')):
        for name, label in (('torsion', 'Torção T (kN·m)'),
                            ('weak_M', 'Momento no eixo fraco (kN·m)'),
                            ('transverse_V', 'Cortante transversal (kN)')):
            _scalar((*path, name), label)
        st.caption('Valores não nulos são preservados e bloqueiam o domínio; não são descartados.')


def _checks_table(rows):
    return pd.DataFrame([{
        'ID': row['id'], 'Caso': row['case_id'], 'Componente': row['component'],
        'Mecanismo': row['mechanism'], 'Verificação': row['label'],
        'Solicitação': row['demand'], 'Resistência': row['resistance'],
        'Unidade': row.get('unit', ''), 'Índice': row['utilization'], 'Resultado': row['status'],
    } for row in rows])


def _render():
    from .welded_w_splice import WeldedWSplice, FAMILY, COMPONENT_VERSION, DECLARATIONS, SCOPE, evaluate, presets
    from .welded_w_splice_drawing import image_bytes
    from .welded_w_splice_report import create_report
    from .welded_w_splice_presentation import physical_envelopes

    s = st.session_state
    saved, draft = s.get(PROJECT), s.get(DRAFT)
    prior_report = s.pop(REPORT, None)
    s.pop(PROJECT, None)
    s.pop(RESULT, None)
    if 'wws_project' not in s:
        seed(WeldedWSplice.from_dict(saved) if saved else WeldedWSplice())
        if draft:
            s.update(draft)
    # Keep all native inputs even if an expander or another family hides them.
    for path, _ in _walk(s[TEMPLATE]['connection']):
        key = _key(path)
        if key in s:
            s[key] = s[key]
    with st.sidebar:
        st.caption('Versão ' + COMPONENT_VERSION + ' · emenda W soldada')
        st.selectbox('Exemplo W soldada', list(presets()), key='wws_example')
        st.button('Usar exemplo W soldada', on_click=use_example)
        st.file_uploader('Abrir projeto W soldada', type=['json'], key='wws_upload')
        st.button('Carregar W soldada', on_click=load_project)
        if 'wws_import_error' in s:
            st.error(s.wws_import_error)
        st.caption(BRAND)
        st.link_button('LinkedIn · Lucas Oliveira', LINK)
    st.title(FAMILY)
    st.caption('Vigas ou pilares · CJP integral · ações estáticas assinadas · unidades N/mm/MPa no arquivo nativo')
    st.info(SCOPE)
    st.caption('Fakury, equações 10.19–10.27; NBR 8800:2024 / Errata 1:2025. '
               'Grupo nominal elástico, sem pretensão de reproduzir picos de tensão no contorno das aberturas. '
               'As declarações começam pendentes: um exemplo numérico não aprova uma junta real.')
    _scalar(('project',), 'Identificação do projeto W soldada')
    left, right = st.columns([.95, 1.5], gap='large')
    with left:
        st.subheader('Perfil, material e ações')
        _select('Aplicação da emenda', ('beam', 'column'), ('orientation',),
                {'beam': 'Viga', 'column': 'Pilar'})
        st.caption('A escolha viga/pilar muda a apresentação; conserva N, M, V e as verificações locais.')
        _scalar(('profile_name',), 'Perfil W · membro A')
        _scalar(('profile_b_name',), 'Perfil W · membro B')
        _select('Aço do membro A', STEELS, ('steel_a',))
        _select('Aço do membro B', STEELS, ('steel_b',))
        st.caption('N e V em kN; M em kN·m. Ações já majoradas no plano da emenda. '
                   'Sinais conservados; N positivo em tração e M positivo traciona y positivo.')
        _actions()
        load_convention_slot = st.empty()
        with st.expander('Combinações adicionais · todas independentes'):
            st.caption('O caso real principal sempre permanece. Casos reais, mínimos e de integridade '
                       'são alternativas independentes; não há soma automática nem mínimo de momento inventado. '
                       'O mínimo de 45 kN usa a direção de (N,V) quando o resultante é não nulo; M permanece igual.')
            cases = s[TEMPLATE]['connection']['load_cases']
            for index, case in enumerate(cases):
                st.markdown('Combinação adicional ' + str(index + 1))
                _scalar(('load_cases', index, 'id'), 'ID da combinação ' + str(index + 1))
                _scalar(('load_cases', index, 'label'), 'Nome da combinação ' + str(index + 1))
                _actions(('load_cases', index), additional=True)
            a, b = st.columns(2)
            a.button('Adicionar combinação', key='wws_add_case', on_click=_case_change,
                     disabled=len(cases) >= 100)
            b.button('Remover última combinação', key='wws_remove_case', on_click=_case_change,
                     kwargs={'remove': True}, disabled=not cases)
            if 'wws_case_error' in s:
                st.error(s.wws_case_error)
        with st.expander('Perfil e alinhamento · dimensões reais'):
            _scalar(('profile_source',), 'Fonte das dimensões e propriedades')
            _select('Tipo de perfil', ('rolled_W',), ('profile_kind',), {'rolled_W': 'W laminado'})
            _dimension_fields((('d', 'Altura d'), ('bf', 'Largura bf'), ('tf', 'Espessura das mesas tf'),
                               ('tw', 'Espessura da alma tw'), ('root_radius', 'Raio real da raiz'),
                               ('clear_web_height', 'Altura livre de raízes')))
            st.caption('Geometria explícita, sem substituir por Ag de catálogo ou creditar filetes de raiz. '
                       'Editar uma dimensão não ajusta automaticamente garganta, comprimento ou abertura.')
            _dimension_fields((('offset_y', 'Deslocamento em y'), ('offset_z', 'Deslocamento em z'),
                               ('depth_mismatch', 'Desnível real de altura'),
                               ('flange_mismatch', 'Desalinhamento de mesas'), ('web_mismatch', 'Desalinhamento de almas')))
            _scalar(('rotation',), 'Rotação relativa declarada (graus)')
        with st.expander('Junta CJP · comprimentos e gargantas efetivos'):
            _select('Tipo de solda', ('CJP', 'PJP'), ('weld_type',))
            _dimension_fields((('flange_weld_length', 'Comprimento efetivo de cada mesa'),
                               ('flange_weld_throat', 'Garganta efetiva de cada mesa'),
                               ('web_weld_length', 'Comprimento efetivo da alma remanescente'),
                               ('web_weld_throat', 'Garganta efetiva da alma')))
            st.caption('Duas mesas e uma alma. Sem crédito resistente de contato de topo, backing, '
                       'chapas, abas de início/fim, cantoneiras ou parafusos temporários.')
        with st.expander('Aberturas reais · ambos os membros'):
            _select('Detalhe geométrico', ('NBR_Fig25_alt1_2_tangent_circle',), ('access_detail',),
                    {'NBR_Fig25_alt1_2_tangent_circle': 'NBR Fig. 25 · alternativas 1/2 · curva circular tangente'})
            _dimension_fields((('access_h0', 'Altura da abertura no plano da solda'),
                               ('root_clearance', 'Folga real além da raiz'),
                               ('access_hmax_a', 'Altura máxima da abertura · A'),
                               ('access_length_a', 'Comprimento da abertura · A'),
                               ('access_radius_a', 'Raio de transição · A'),
                               ('access_hmax_b', 'Altura máxima da abertura · B'),
                               ('access_length_b', 'Comprimento da abertura · B'),
                               ('access_radius_b', 'Raio de transição · B')))
            st.caption('A seção crítica receptora pode ficar além do plano da solda. '
                       'O transporte assinado de M inclui V e o afastamento do corte. '
                       'Comprimentos, alturas e raios devem corresponder às curvas reais verificadas.')
        with st.expander('WPS, fabricação e declarações · pendentes por padrão', expanded=True):
            _select('Processo de soldagem', ('SMAW', 'GMAW', 'FCAW', 'SAW'), ('process',))
            _scalar(('consumable',), 'Classificação exata do consumível')
            _scalar(('procedure_id',), 'Identificação e revisão da WPS aplicável')
            st.caption('Marque somente após conferir a evidência do projeto real. '
                       'Nenhuma declaração é inferida do nome do perfil, do eletrodo ou da baixa solicitação.')
            for name in DECLARATIONS:
                _scalar((name,), DECLARATION_LABELS[name])
        with st.expander('Políticas de ações e limites do domínio'):
            for name, label in (
                ('minimum_force', 'Aplicar mínimo de força de 45 kN · casos separados, NBR 6.1.5'),
                ('static', 'Ações estáticas'), ('normal_combination', 'Combinações últimas normais'),
                ('fatigue', 'Solicitação de fadiga presente · fora do domínio'),
                ('seismic', 'Qualificação sísmica necessária · fora do domínio'),
                ('impact', 'Impacto presente · fora do domínio'),
            ):
                _scalar((name,), label)
            st.caption('Ações de integridade devem constar como combinações adicionais quando aplicáveis. '
                       'A resistência dos membros, flambagem global, estabilidade lateral, rigidez do pórtico '
                       'e estabilidade de montagem permanecem com o projeto do sistema.')
        st.text_area('Observações do responsável técnico', key='wws_notes')

    native = _current_native()
    c = WeldedWSplice.from_dict(native)
    encoded = json.dumps(native, ensure_ascii=False, indent=2, allow_nan=False)
    _save_draft()
    with load_convention_slot.container():
        render_load_convention(st, 'welded_w_splice', c.N, orientation=c.orientation)
    r = evaluate(c)
    digest = hashlib.sha256((encoded + json.dumps(r, ensure_ascii=False, sort_keys=True, allow_nan=False)).encode()).hexdigest()
    s[PROJECT], s[RESULT] = native, r
    complete = checks_complete(r)
    geometry_valid = r.get('geometry', {}).get('valid') is True
    status = r.get('status', 'INVALID_INPUT')
    ready = complete and geometry_valid and not status.startswith(('INVALID', 'NUMERICAL', 'OUTSIDE'))
    png = image_bytes(c, fmt='png') if geometry_valid else None
    with right:
        label = STATUS.get(status, status)
        if r.get('global_pass') is True and complete and geometry_valid:
            st.success(label + ' · EMENDA LOCAL')
        elif status == 'NOT_VERIFIED':
            st.warning(label)
        else:
            st.error(label)
        st.caption('O resultado local não libera fabricação, montagem, rigidez de pórtico ou estabilidade global. '
                   'As duas extremidades são caminhos em série; resistências não são somadas.')
        a, b = st.columns(2)
        a.metric('N real principal (kN)', _display(c.N / 1000.))
        b.metric('Índice governante', _display(r.get('summary', {}).get('utilization')))
        for issue in r.get('issues') or []:
            message = issue.get('message', issue.get('text', str(issue)))
            severity = issue.get('severity', '')
            if severity in ('info', 'note'):
                st.caption(message)
            elif severity in ('warning', 'pending', 'engineering_pending', 'not_verified'):
                st.warning(message)
            else:
                st.error(message)
        if geometry_valid:
            st.image(png, width='stretch')
        with st.expander('Geometria calculada e equilíbrio assinado'):
            st.json(display_tree(r.get('geometry') or {}), expanded=False)
            if 'equilibrium' in r:
                st.json(display_tree(r['equilibrium']), expanded=False)
            if r.get('group_cases'):
                st.json(display_tree(r['group_cases']), expanded=False)
            if r.get('receiver_cases'):
                st.json(display_tree(r['receiver_cases']), expanded=False)
        cases = r.get('cases') or []
        if cases:
            st.subheader('Casos independentes · ações nativas')
            st.dataframe(display_frame(pd.DataFrame([{
                'Caso': case.get('label', case.get('id', '')), 'ID': case.get('id', ''),
                'Natureza': 'Real' if case.get('kind') == 'actual' else 'Mínimo separado',
                'N (kN)': case.get('N', 0) / 1000., 'M (kN·m)': case.get('M', 0) / 1e6,
                'V (kN)': case.get('V', 0) / 1000.,
            } for case in cases])), hide_index=True, width='stretch')
    rows = r.get('checks') or []
    if complete:
        st.subheader('Resultados locais por componente físico')
        envelopes = physical_envelopes(r)
        st.caption('Envelopes preservam combinações, ramos e empates. '
                   'A alma receptora recebe V integral, independentemente da parcela atribuída à sua solda pelo grupo elástico.')
        if envelopes:
            display_rows = []
            for envelope in envelopes:
                governing = envelope.get('governing', [])
                if isinstance(governing, dict):
                    governing = [governing]
                display_rows.append({
                    'Componente': envelope.get('component_label', envelope.get('component', '')),
                    'Mecanismo': envelope.get('mechanism_label', envelope.get('mechanism', '')),
                    'Índice real': envelope.get('actual_utilization'),
                    'Resultado real': envelope.get('actual_status'),
                    'Índice adotado': envelope.get('utilization'), 'Resultado adotado': envelope.get('status'),
                    'Governantes e empates': '; '.join(item.get('id', str(item)) for item in governing),
                })
            st.dataframe(display_frame(pd.DataFrame(display_rows)), hide_index=True, width='stretch')
        with st.expander('Governantes, empates e todos os ramos'):
            st.json(display_tree(envelopes), expanded=False)
        with st.expander('Todas as verificações primitivas · unidades e testemunhas'):
            st.dataframe(display_frame(_checks_table(rows)), hide_index=True, width='stretch')
            st.json(display_tree(rows), expanded=False)
    elif rows:
        st.warning('Registros incompletos: conclusão resistente e emissão da memória bloqueadas.')
        st.json(display_tree(rows), expanded=False)
    a, b, d = st.columns(3)
    a.download_button('Salvar projeto W soldada .json', encoded, 'emenda_W_soldada.json', 'application/json')
    if geometry_valid:
        b.download_button('Baixar desenho W soldada .png', png, 'emenda_W_soldada.png', 'image/png')
        b.download_button('Baixar desenho W soldada .svg', image_bytes(c, fmt='svg'), 'emenda_W_soldada.svg', 'image/svg+xml')
    detailed = d.checkbox('Memória detalhada · incluir verificações primitivas', key='wws_report_detailed')
    report_digest = hashlib.sha256((digest + str(detailed)).encode()).hexdigest()
    if ready and prior_report and prior_report[0] == report_digest:
        s[REPORT] = prior_report
    if ready and not r.get('global_pass'):
        st.caption('A memória registra as pendências ou falhas atuais; emiti-la não aprova a emenda.')
    if d.button('Gerar memória W soldada', disabled=not ready):
        filename = 'memoria_W_soldada_detalhada.docx' if detailed else 'memoria_W_soldada.docx'
        s[REPORT] = (report_digest, filename, create_report(c, detailed=detailed))
    if REPORT in s:
        _, filename, payload = s[REPORT]
        st.download_button('Baixar memória W soldada .docx', payload, filename,
                           'application/vnd.openxmlformats-officedocument.wordprocessingml.document')
