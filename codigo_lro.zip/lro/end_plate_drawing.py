"""Desenho vetorial proporcional, sem imagem gerada por IA."""
from .display_precision import display_format, display_value
from io import BytesIO
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Circle,Polygon,Arc
from math import cos,sin,radians,isfinite
from .drawing_annotations import dimension, rendered_wrap
from .end_plate_presentation import summary_lines,SCOPE_NOTICE
from .end_plate_detail import DETAIL_SCOPE,rib_ends,rib_polygon,detail_description

STIFFENER='#92bdac'
BLUE='#176b87';GRAY='#dce4e9';ORANGE='#b36b12';INK='#243844'

def stiffener_polygon(c,lower=False):
    """Real Fig.4-3 landings and diagonal corner clip in side-view mm.

    The landings trim the free slope only. Neither connected CJP run is
    shortened by a landing, and no weld crosses the corner clip.
    """
    h=c.ext_bottom if lower else c.ext_top
    points=[(0,c.stiffener_clip),(0,h),(c.stiffener_landing,h),
            (c.stiffener_length,c.stiffener_landing),(c.stiffener_length,0),
            (c.stiffener_clip,0)]
    return [(c.tp+x,c.beam.d+y if lower else -y) for x,y in points]

def figure(c):
    from .end_plate import evaluate,input_digest,method_revision
    r=evaluate(c)
    if any(i.severity=='error' and i.origin!='method' and i.text!='Informe pelo menos um esforço não nulo.' for i in r.issues):
        # Invalid geometry/data must never reach proportional drawing transforms.
        # This also covers the legacy 4E/4ES and pinned paths, not only 8ES.
        fig=plt.figure(figsize=(10,2.4))
        fig.text(.04,.85,r.status,fontsize=11,fontweight='bold',color='#a52b32')
        fig.text(.04,.58,'End plate · desenho proporcional indisponível: corrija os dados ou a geometria.',fontsize=10)
        fig.text(.04,.35,'Consulte os avisos da validação. Nenhuma geometria aproximada foi desenhada.',fontsize=9)
        try:
            fig.text(.04,.15,'Entradas SHA-256: '+input_digest(c)+' · revisão '+method_revision(c),fontsize=6)
        except (ValueError,TypeError,OverflowError):
            pass  # Non-finite inputs have no valid JSON identity.
        return fig
    stiffened=c.kind=='moment' and c.is_stiffened
    detail=c.has_detail_ribs
    eight=c.kind=='moment' and c.is_8es
    mre=c.is_mre12
    multi=eight or mre
    zero_actions=(multi and c.M==0 and c.N==0 and c.V==0) or (mre and c.M==0)
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'svg.fonttype':'none'})
    extents=[c.hp,c.bp,c.tp,c.ext_top,c.ext_bottom,*c.rows]+([c.stiffener_length] if stiffened else [])+([c.detail_rib_length,c.detail_rib_thickness] if detail else [])
    # A finite input can overflow a derived extent or collapse useful
    # features below floating-point/rendering resolution. This is only a
    # drawing guard, never an additional engineering acceptance limit.
    if (not all(isfinite(v) for v in extents) or
            max(abs(v) for v in extents)>max(1.,c.beam.d)*1e12):
        fig=plt.figure(figsize=(10,2.4))
        fig.text(.04,.88,r.status,fontsize=11,fontweight='bold',color='#a52b32')
        fig.text(.04,.63,'End plate · desenho proporcional indisponível para esta escala numérica.',fontsize=10)
        fig.text(.04,.43,'Revise as entradas e os avisos da validação. Não foi desenhada uma geometria aproximada.',fontsize=9)
        fig.text(.04,.15,'Entradas SHA-256: '+input_digest(c)+' · revisão '+method_revision(c),fontsize=6)
        return fig
    fig,(ax,side)=plt.subplots(1,2,figsize=((13.5,10.9) if multi else (11.2,9.5) if stiffened or detail else (10,8.0)),gridspec_kw={'width_ratios':[1,1.6 if multi else 1.1 if stiffened else 1.05]})
    color=INK if r.status=='ATENDE ÀS VERIFICAÇÕES REALIZADAS' else '#a52b32'
    # Header height is measured, including every wrapped governing/pending line.
    header_y=.975
    renderer=fig.canvas.get_renderer()
    def header(text,fontsize=8,weight='normal',color=color,width=.92):
        nonlocal header_y
        text=rendered_wrap(text,fig.get_figwidth()*72*width,fontsize,weight)
        t=fig.text(.04,header_y,text,fontsize=fontsize,fontweight=weight,color=color,va='top')
        header_y-=t.get_window_extent(renderer).height/fig.bbox.height+6/(fig.get_figheight()*72)
    header(r.status,10,'bold',width=.68)
    if stiffened:header(c.variant+' · duas nervuras externas · DG39 Tabela '+('5-16 / A-5(a)' if multi else '5-11')+' · coluna sem enrijecedores',8,'bold',color=BLUE)
    if stiffened:
        header(f'Aços independentes: viga {display_value(c.beam_steel)} · coluna {display_value(c.support_steel)}',7.8,color=BLUE)
        header(f'Chapa {display_value(c.plate_steel)} · duas nervuras {display_value(c.stiffener_steel)}',7.8,color=BLUE)
    if mre:
        header('MRE1/2 · 12 parafusos físicos'+(' · M nulo: sem extremidade tracionada definida' if zero_actions else ' · 6 ativos em tração · 6 recebem V/6 no lado comprimido'),8,'bold',color=BLUE)
        header(('Cálculo base sem nervuras' if detail else 'Sem nervuras')+' · DG39 Tabela 5-12 / A-4(a)'+(' · braços ativos indisponíveis' if zero_actions else ' · mesa tracionada '+('superior' if c.M>0 else 'inferior')+' · braços: '+', '.join('h'+str(i)+'='+display_format(h,'g') for i,h in enumerate(c.tension_arms,1))),7.8,color=BLUE)
        header('Aços: viga '+c.beam_steel+' · chapa '+c.plate_steel+' · coluna '+c.support_steel,7.4,color=BLUE)
        if r.checks:
            nom=r.geometry['actions']['nominal']
            header('Demanda espessa: '+('atende' if r.geometry['actions']['demand_no_prying'] else 'não atende')+' · nominal: chapa '+('atende' if nom['plate_no_prying'] else 'não atende')+' / coluna '+('atende' if nom['column_no_prying'] else 'não atende')+' (diagnóstico separado)',7.4,color=BLUE)
    if eight:
        if zero_actions:header('16 parafusos físicos · ações nulas: sem extremidade tracionada definida; braços ativos indisponíveis.',8,color=BLUE)
        else:header('16 parafusos físicos · 8 ativos em tração · mesa tracionada '+('superior' if c.M>0 else 'inferior')+' · braços em mm: '+', '.join(f"h{display_value(i)}={display_format(h, 'g')}" for i,h in enumerate(c.tension_arms,1)),8,color=BLUE)
    result_lines=summary_lines(r)
    # The resistant maximum excludes geometry/method conditions. Every value
    # is drawn from the same presentation contract as UI, native audit and Word.
    header(result_lines[0],9,'bold')
    for line in result_lines[1:]:header(line,7.4)
    header(SCOPE_NOTICE,6.8)
    if detail:header(DETAIL_SCOPE,6.8,color=INK)
    pending=any(i.severity=='pending' or (c.kind=='pinned' and i.origin=='local_scope') for i in r.issues)
    if pending:
        if c.kind=='pinned':
            header('ESCOPO LOCAL INCOMPLETO: hierarquia/momento das soldas da alma; tração dos parafusos por rotação;',7.5,color='#a52b32')
            header('transferência das soldas/mesas; mecanismo N/V, cortes da chapa, alavanca e contato ainda não qualificados.',7.5,color='#a52b32')
        else:header('VERIFICAÇÃO LOCAL INCOMPLETA: conferir pendências no projeto e na memória.',8,color='#a52b32')
    b=c.beam;s=c.support;top=-c.ext_top;bot=b.d+c.ext_bottom
    for a in (ax,side):a.set_aspect('equal');a.axis('off')
    def rect(a,x,y,w,h,fc,ec=INK,lw=1):a.add_patch(Rectangle((x,y),w,h,facecolor=fc,edgecolor=ec,linewidth=lw))
    def dim(a,x1,y1,x2,y2,text,vertical=False,below=False):
        return dimension(a,(x1,y1),(x2,y2),text,fontsize=7,rotation=90 if vertical else 0,
                         color=INK,offset=((5,0) if text.startswith('d = ') else (-5,0)) if vertical else (0,6 if below else -6),
                         ha=('left' if text.startswith('d = ') else 'right') if vertical else 'center',
                         pad=1,lw=.7,short_side=-1 if vertical or below else 1)
    rect(ax,-s.bf/2,top-40,s.bf,bot-top+80,'#f3f5f7','#c7cfd5',.6)
    rect(ax,-c.bp/2,top,c.bp,c.hp,'#d2eaf0',BLUE,1.5)
    rect(ax,-b.bf/2,0,b.bf,b.tf,GRAY)
    rect(ax,-b.tw/2,b.tf,b.tw,b.d-2*b.tf,GRAY)
    rect(ax,-b.bf/2,b.d-b.tf,b.bf,b.tf,GRAY)
    if stiffened:
        for y,h in [(top,c.ext_top),(b.d,c.ext_bottom)]:
            rect(ax,-c.stiffener_t/2,y,c.stiffener_t,h,STIFFENER,BLUE,1)
            ax.patches[-1].set_gid('stiffener_front_upper' if y==top else 'stiffener_front_lower')
    if detail:
        for lower in rib_ends(c):
            h=c.ext_bottom if lower else c.ext_top;y=b.d if lower else top
            rect(ax,-c.detail_rib_thickness/2,y,c.detail_rib_thickness,h,STIFFENER,BLUE,1)
            ax.patches[-1].set_gid('detail_rib_front_'+('lower' if lower else 'upper'))
    active_rows=(list(c.primary_rows[:4]) if c.M>0 else list(reversed(c.primary_rows[-4:]))) if eight and not zero_actions else []
    if mre and not zero_actions:active_rows=list(c.primary_rows[:3]) if c.M>0 else list(reversed(c.primary_rows[3:]))
    for row_index,y in enumerate(c.rows,1):
        for col_index,x in enumerate([-c.gauge/2,c.gauge/2],1):
            active=y in active_rows
            ax.add_patch(Circle((x,y),c.dh/2,facecolor='#fff1d6' if active or y in c.intermediate_rows else 'white',edgecolor=ORANGE if active or y in c.intermediate_rows else INK,lw=1))
            if multi:ax.patches[-1].set_gid(f'bolt_front_row_{display_value(row_index)}_col_{display_value(col_index)}'+('_inactive' if zero_actions else '_tension' if active else '_shear'))
            ax.plot([x-3,x+3],[y,y],color=INK,lw=.6);ax.plot([x,x],[y-3,y+3],color=INK,lw=.6)
    dim(ax,-c.bp/2,top-22,c.bp/2,top-22,f"bp = {display_format(c.bp, 'g')}")
    dim(ax,-c.bp/2-30,top,-c.bp/2-30,bot,f"hp = {display_format(c.hp, 'g')}",True)
    dim(ax,-c.gauge/2,bot+30,c.gauge/2,bot+30,f"g = {display_format(c.gauge, 'g')}",below=True)
    if c.kind=='pinned':
        dim(ax,c.bp/2+25,c.rows[0],c.bp/2+25,c.rows[1],f"p = {display_format(c.pitch, 'g')}",True)
    else:
        # Transverse annotation lanes retain a minimum display-space separation.
        lane=max(25.,(bot-top+143)/210*18)
        dim(ax,c.bp/2+lane,-c.pfo,c.bp/2+lane,0,f"pfo = {display_format(c.pfo, 'g')}",True)
        dim(ax,c.bp/2+2*lane,b.tf,c.bp/2+2*lane,b.tf+c.pfi,f"pfi = {display_format(c.pfi, 'g')}",True)
        if multi:
            for i,j in (((1,2),(3,4)) if mre else ((0,1),(2,3),(4,5),(6,7))):
                _,label=dim(ax,c.bp/2+3*lane,c.primary_rows[i],c.bp/2+3*lane,c.primary_rows[j],f"pb = {display_format(c.pb, 'g')}",True)
                label.set_gid(f'pb_dimension_rows_{display_value(i + 1)}_{display_value(j + 1)}')
        dim(ax,-c.bp/2-13,top,-c.bp/2-13,c.rows[0],f"e = {display_format(c.edge, 'g')}",True)
    fig.text(.23 if multi else .27,.145,f'{display_value(len(c.rows))} linhas × 2 parafusos'+(f' = {display_value(c.count)}' if multi else '')+f" · Ø {display_format(c.db, 'g')}"+(' · laranja: tração ativa' if multi and not zero_actions else ''),ha='center',fontsize=8)
    if c.intermediate_n:fig.text(.27,.115,f'{display_value(c.intermediate_n)} linha(s) central(is) sem crédito resistente',ha='center',fontsize=7,color=ORANGE)
    ax.set_xlim(-c.bp/2-60,c.bp/2+((3 if multi else 2)*lane+45 if c.kind=='moment' else 80));ax.set_ylim(bot+78,top-65)
    ax.set_title('VISTA FRONTAL\nChapa e seção da viga',loc='left',fontsize=10,fontweight='bold',pad=12)
    # Longitudinal slice of column; column depth is deliberately not dimensioned.
    stub=max(165.,c.stiffener_length+30.) if stiffened else max(165.,c.detail_rib_length+30.) if detail else 165.;colslice=65.
    rect(side,-s.tf,top-45,s.tf,bot-top+90,GRAY)
    rect(side,-s.tf-colslice,top-45,colslice,bot-top+90,'#f3f5f7','#c7cfd5',.6)
    rect(side,0,top,c.tp,c.hp,'#d2eaf0',BLUE,1.5)
    rect(side,c.tp,0,stub,b.tf,GRAY);rect(side,c.tp,b.d-b.tf,stub,b.tf,GRAY)
    rect(side,c.tp,b.tf,stub,b.d-2*b.tf,'#edf1f4','#bcc8d0',.7)
    for y in c.rows:
        rect(side,-s.tf-10,y-c.db/2,s.tf+c.tp+20,c.db,'#f1e1be',ORANGE,.8)
        rect(side,-s.tf-13,y-c.db*.7,7,c.db*1.4,ORANGE,ORANGE,.8)
        rect(side,c.tp+7,y-c.db*.7,7,c.db*1.4,ORANGE,ORANGE,.8)
    if c.kind=='pinned':
        for y,sign in [(0,-1),(b.d,1)]:side.add_patch(Polygon([(c.tp,y),(c.tp+c.weld,y),(c.tp,y+sign*c.weld)],facecolor=BLUE))
    else:
        for y in [b.tf/2,b.d-b.tf/2]:side.plot([c.tp,c.tp+6],[y-4,y+4],color=BLUE,lw=2)
    if stiffened:
        for lower in (False,True):
            suffix='lower' if lower else 'upper'
            patch=Polygon(stiffener_polygon(c,lower),facecolor=STIFFENER,edgecolor=BLUE,lw=1)
            patch.set_gid('stiffener_side_'+suffix);side.add_patch(patch)
            sign=1 if lower else -1;base=b.d if lower else 0.;height=c.ext_bottom if lower else c.ext_top
            side.plot([c.tp,c.tp],[base+sign*c.stiffener_clip,base+sign*height],color=BLUE,lw=2.6,gid='stiffener_cjp_plate_'+suffix)
            side.plot([c.tp+c.stiffener_clip,c.tp+c.stiffener_length],[base,base],color=BLUE,lw=2.6,gid='stiffener_cjp_flange_'+suffix)
        dim(side,c.tp,top-22,c.tp+c.stiffener_length,top-22,f"Lst = {display_format(c.stiffener_length, 'g')}")
        dim(side,c.tp+stub+23,top,c.tp+stub+23,0,f"hst = {display_format(c.ext_top, 'g')}",True)
        side.annotate('CJP à chapa',xy=(c.tp,-(c.ext_top+c.stiffener_clip)/2),
                      xytext=(c.tp+30,b.tf+60),fontsize=7,color=BLUE,
                      arrowprops={'arrowstyle':'-','color':BLUE,'lw':.8},ha='left')
        side.annotate('CJP à mesa',xy=(c.tp+(c.stiffener_length+c.stiffener_clip)/2,0),
                      xytext=(c.tp+75,b.tf+28),fontsize=7,color=BLUE,
                      arrowprops={'arrowstyle':'-','color':BLUE,'lw':.8},ha='left')
    if detail:
        for lower in rib_ends(c):
            patch=Polygon(rib_polygon(c,lower),facecolor=STIFFENER,edgecolor=BLUE,lw=1)
            patch.set_gid('detail_rib_side_'+('lower' if lower else 'upper'));side.add_patch(patch)
        dim(side,c.tp,top-22,c.tp+c.detail_rib_length,top-22,f"L = {display_format(c.detail_rib_length, 'g')}")
    dim(side,0,bot+30,c.tp,bot+30,f"tp = {display_format(c.tp, 'g')}",below=True)
    dim(side,c.tp+stub+23,0,c.tp+stub+23,b.d,f"d = {display_format(b.d, 'g')}",True)
    if multi and not zero_actions:
        pivot=b.d-b.tf/2 if c.M>0 else b.tf/2
        side.plot([c.tp+stub,c.tp+stub+200],[pivot,pivot],color=ORANGE,lw=.7,ls='--',gid='compression_pivot')
        for i,(row,h) in enumerate(zip(active_rows,c.tension_arms),1):
            lane_x=c.tp+stub+65+42*(i-1)
            _,label=dim(side,lane_x,row,lane_x,pivot,f"h{display_value(i)} = {display_format(h, 'g')}",True)
            label.set_gid(f'tension_arm_h{display_value(i)}')
    y=b.d/2
    if c.kind=='pinned' or c.N!=0:
        # Keep the positive-reference endpoints independent of the glyph box:
        # on the tall proportional view a combined Annotation clips the entire
        # short N arrow back into the N. A point-space label lane stays legible.
        n_tip=(c.tp+stub-45,y);n_tail=(c.tp+stub-90,y)
        n_arrow=side.annotate('',n_tip,n_tail,fontsize=9,
                              arrowprops={'arrowstyle':'->','color':INK,
                                          'shrinkA':0,'shrinkB':0})
        n_arrow._reference_label='N'
        side.annotate('N',xy=n_tip,xytext=(-6,-8),textcoords='offset points',
                      ha='center',va='top',fontsize=9,color=INK)
    if c.kind=='pinned' or c.V!=0:side.annotate('V',(c.tp+stub-25,y+70),(c.tp+stub-25,y+15),arrowprops={'arrowstyle':'->','color':INK},ha='center',fontsize=9)
    if c.kind=='moment':
        side.add_patch(Arc((c.tp+70,y),65,65,theta1=80,theta2=290,color=ORANGE,lw=1.3))
        # Positive moment opens the upper interface: clockwise on this screen.
        # Since y is downward/inverted, increasing DATA angle gives that sense.
        theta=radians(290)
        tip=(c.tp+70+32.5*cos(theta),y+32.5*sin(theta))
        side.annotate('',xy=tip,xytext=(-7*(-sin(theta)),7*cos(theta)),
                      textcoords='offset points',arrowprops={'arrowstyle':'-|>',
                      'color':ORANGE,'lw':1.3,'mutation_scale':10,'shrinkA':0,'shrinkB':0})
        side.annotate('M',xy=(c.tp+70,y),xytext=(4,16),textcoords='offset points',
                      ha='center',va='bottom',color=ORANGE,fontsize=10)
    side.set_xlim(-s.tf-colslice-20,c.tp+stub+(215 if multi else 60));side.set_ylim(bot+78,top-65)
    side.set_title('CORTE LONGITUDINAL\nChapa parafusada à coluna',loc='left',fontsize=9,fontweight='bold',pad=12)
    side.text(-s.tf/2,top-52,'Mesa da coluna',ha='center',fontsize=8)
    fig.text(.75,.145,'CJP nas mesas e alma' if c.kind=='moment' else f"Filetes contínuos w = {display_format(c.weld, 'g')}",ha='center',fontsize=8,color=BLUE)
    if stiffened:
        fig.text(.04,.113,f"2 nervuras: ts={display_format(c.stiffener_t, 'g')} mm · {display_value(c.stiffener_steel)} · Lst={display_format(c.stiffener_length, 'g')} mm · hst={display_format(c.ext_top, 'g')} mm",fontsize=8,color=BLUE)
        fig.text(.04,.091,f"Recorte: pernas de {display_format(c.stiffener_clip, 'g')} mm · patamares={display_format(c.stiffener_landing, 'g')} mm · CJP contínua nas duas interfaces; sem solda no recorte.",fontsize=7.8,color=BLUE)
        fig.text(.04,.073,'Soldar a viga à chapa antes das nervuras. Sem chapas de continuidade ou reforço da coluna.'+(' Estático no plano; sem qualificação sísmica/cíclica.' if multi else ''),fontsize=7.5,color=INK)
    if detail:fig.text(.04,.113,rendered_wrap(detail_description(c),fig.get_figwidth()*72*.9,7),fontsize=7,color=BLUE)
    if mre:fig.text(.04,.091,'Cortante: seis parafusos do lado comprimido; reações opostas na chapa e coluna. Nominal não é requisito adicional.',fontsize=7.5,color=INK)
    if c.kind=='pinned':fig.text(.04,.057,f"Setas: sentidos positivos de referência. Entradas: N={display_format(c.N, 'g')} N; V={display_format(c.V, 'g')} N. N negativo = compressão.",fontsize=7.5,color=INK)
    if c.kind=='moment':fig.text(.04,.057,f"Sentidos positivos de referência. Entradas: N={display_format(c.N, 'g')} N; V={display_format(c.V, 'g')} N; M={display_format(c.M, 'g')} N·mm. N<0: compressão; M<0: tração inferior.",fontsize=7.1,color=INK)
    fig.text(.04,.032,'Dimensões em mm · furos padrão · desenho ilustrativo proporcional · coluna mostrada parcialmente',fontsize=8,color=INK)
    fig.text(.04,.012,'Entradas SHA-256: '+input_digest(c)+(' · revisão '+method_revision(c)),fontsize=6,color=INK)
    fig.subplots_adjust(left=.07,right=.97,top=min(.84,header_y-30/(fig.get_figheight()*72)),bottom=.22,wspace=.35)
    return fig

def image_bytes(c,fmt='png'):
    fig=figure(c);out=BytesIO();fig.savefig(out,format=fmt,dpi=190,facecolor='white');plt.close(fig);return out.getvalue()
