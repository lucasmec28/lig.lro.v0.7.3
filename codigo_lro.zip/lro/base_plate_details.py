"""Explicit baseplate detailing; these choices do not certify strength/rigidity."""
import math
from .models import Issue, finite_real

ANCHOR_TYPES = {
    'unspecified':'Não especificado · projeto legado',
    'straight':'Reto sem cabeça · mecanismo de ancoragem a definir',
    'hook_j':'Gancho J · resistência não calculada',
    'headed':'Cabeça forjada · moldado no local',
    'buried_nut':'Porca de ancoragem enterrada · moldado no local',
    'buried_plate_nut':'Chapa de apoio enterrada e porca · moldado no local',
}
FIXITIES = {'unspecified':'Não especificado','pinned':'Rotulada · indicação legada Tipo 1','fixed':'Engastada · intenção do modelo'}
WELD_TYPES = {'unspecified':'A dimensionar','cjp':'Solda de chanfro com penetração total (CJP)','fillet':'Solda de filete'}
MEASURES = {'leg':'Perna z','throat':'Garganta efetiva a'}
DETAIL_DEFAULTS = {
    'base_fixity':'unspecified','anchor_type':'unspecified','cone_model':'off','cone_subset_envelope':False,
    'anchor_projection_above_plate':0.,'hef':250.,'block_xmin':-600.,'block_xmax':600.,'block_ymin':-500.,'block_ymax':500.,'block_h':700.,
    'anchor_head_width':65.,'anchor_head_length':65.,'anchor_head_t':30.,'anchor_bearing_t':10.,'anchor_nut_t':12.,'anchor_head_hole':22.,'anchor_bottom_cover':50.,
    'anchor_nut_bearing_area':300.,'anchor_detail_ref':'','anchor_detail_confirmed':False,
    'weld_web_type':'unspecified','weld_flange_type':'unspecified',
    'weld_web_measure':'leg','weld_flange_measure':'leg','weld_web_size':6.,'weld_flange_size':6.,
    'stiffener_detail':'none','stiffener_length':60.,'stiffener_height':120.,'stiffener_t':8.,
}


def fillet_dimensions(size,measure):
    """Equal-leg orthogonal fillet only; no penetration credit or weld capacity."""
    if not finite_real(size) or size<=0:
        raise ValueError('Tamanho do filete deve ser positivo e finito.')
    if measure not in MEASURES:raise ValueError('Informe perna ou garganta do filete.')
    return {'leg':size if measure=='leg' else size*math.sqrt(2),
            'throat':size/math.sqrt(2) if measure=='leg' else size}


def weld_description(c,part):
    kind=getattr(c,'weld_'+part+'_type')
    label=WELD_TYPES[kind]
    if kind=='fillet':
        dims=fillet_dimensions(getattr(c,'weld_'+part+'_size'),getattr(c,'weld_'+part+'_measure'))
        label+=f' · z={dims["leg"]:.3f} mm; a={dims["throat"]:.3f} mm'
    return label


def grout_geometry(c):
    """Actual 45° skirt; never use its footprint as the bearing calculation area."""
    return dict(top_L=c.L,top_B=c.B,bottom_L=c.L+2*c.grout_t,bottom_B=c.B+2*c.grout_t,
                footprint=(c.L+2*c.grout_t)*(c.B+2*c.grout_t),angle=45.,
                plate_area=c.L*c.B)


def fixed_base_washer_geometry(c):
    """One Type 1 drawing/clearance envelope, never a resistance credit.

    Native welded washers use their active dimensions. Other shear routes
    retain the Table 18 reference detail already drawn in the main view;
    dormant native-washer inputs must not change that physical depiction.
    """
    from .base_plate import ANCHORS, DETAIL
    if not finite_real(c.db):
        raise ValueError('Diâmetro inválido para o detalhe da arruela.')
    if getattr(c,'direct_anchor_shear',False):
        return dict(side=c.anchor_washer_side,thickness=c.anchor_washer_t,plate_hole=c.direct_shear.hole_diameter,native=False,direct=True)
    label=next((k for k,v in ANCHORS.items() if math.isclose(c.db,v,abs_tol=1e-8)),None)
    if label is None:
        raise ValueError('Diâmetro fora da série do detalhe da arruela.')
    ref=DETAIL[label]
    native=c.native_anchor_shear
    hole=ref['df']
    u=getattr(c,'upper_washer',None)
    if native and getattr(u,'model','off')!='off' and finite_real(u.base_hole) and u.base_hole>0:
        hole=u.base_hole
    return dict(side=c.anchor_washer_side if native else ref['washer_side'],
                thickness=c.anchor_washer_t if native else ref['washer_t'],
                plate_hole=hole,native=native)


def validate_rib_geometry(c):
    """Physical Type 1 solid-rib footprint only; no stiffness/strength model.

    Rod/hole circles and washer squares are checked in BOTH plan axes.
    Touching a hole/washer is rejected (1e-9 mm tolerance); a positive
    geometric gap does not establish weld/tool access or a resistant path.
    Call after basic input validation, or handle invalid input upstream.
    """
    if getattr(c,'model_type',None)!=1 or c.stiffener_detail not in ('web_pair','web_pair_visual'):
        return []
    values=(c.stiffener_length,c.stiffener_height,c.stiffener_t,c.a1,c.a2,c.db,c.B,c.column.bf)
    if any(not finite_real(v) or v<=0 for v in values):
        return [Issue('error','Geometria das nervuras inválida; corrija as dimensões antes de desenhar ou exportar.','Geometria de detalhamento',origin='rib_geometry')]
    issues=[]
    def invalid(text):issues.append(Issue('error',text,'Geometria de detalhamento',origin='rib_geometry'))
    length,t=c.stiffener_length,c.stiffener_t
    if length>2*c.a1+1e-9 or t>c.B+1e-9:
        invalid('Nervuras ultrapassam a placa: projeção deve caber em 2a1 e espessura em B. O detalhe informado é inválido; não há ajuste automático.')
    if t>c.column.bf+1e-9:
        invalid('Espessura da nervura ultrapassa a largura da mesa do pilar; a junta integral desenhada não cabe na mesa.')
    try:washer=fixed_base_washer_geometry(c)
    except ValueError as exc:
        invalid(str(exc));return issues
    # Positive x rib, positive y anchor: the other three pairs are symmetric.
    # Coordinates measured from the exterior face of the adjacent flange.
    dx=max(c.a1-length,0.)
    dy=max(c.a2/2-t/2,0.)
    distance=math.hypot(dx,dy)
    if distance<=c.db/2+1e-9:
        invalid('Nervura toca ou intercepta um chumbador em planta. Ajuste projeção, espessura ou espaçamento; o caminho de cortante não elimina a interferência.')
    elif distance<=washer['plate_hole']/2+1e-9:
        invalid('Pé da nervura toca ou cruza o furo da placa; falta apoio contínuo para o detalhe sólido desenhado.')
    side=washer['side']
    if finite_real(side) and side>0:
        overlap_x=min(length,c.a1+side/2)-max(0.,c.a1-side/2)
        overlap_y=min(t/2,c.a2/2+side/2)-max(-t/2,c.a2/2-side/2)
        if min(overlap_x,overlap_y)>=-1e-9:
            source='informada' if washer['native'] else 'de referência da Tabela 18'
            invalid('Nervura toca ou intercepta a arruela superior '+source+' em planta. Não há folga geométrica no detalhe; reveja dimensões e acesso das soldas.')
        u=getattr(c,'upper_washer',None)
        if washer['native'] and getattr(u,'model','off')!='off' and finite_real(u.leg) and u.leg>0:
            half=side/2+u.leg
            weld_x=min(length,c.a1+half)-max(0.,c.a1-half)
            weld_y=min(t/2,c.a2/2+half)-max(-t/2,c.a2/2-half)
            if min(weld_x,weld_y)>=-1e-9 and min(overlap_x,overlap_y)<-1e-9:
                invalid('Nervura toca ou intercepta o espaço físico do filete informado da arruela; reveja a implantação e o acesso.')
    return issues


def validate_details(c):
    issues=[]
    def invalid(text):issues.append(Issue('error',text,'Dados de detalhamento da base'))
    choices={'base_fixity':FIXITIES,'anchor_type':ANCHOR_TYPES,'cone_model':('off','aci318_19'),
             'weld_web_type':WELD_TYPES,'weld_flange_type':WELD_TYPES,
             'weld_web_measure':MEASURES,'weld_flange_measure':MEASURES,
             'stiffener_detail':('none','web_pair','web_pair_visual')}
    for key,opts in choices.items():
        if not isinstance(getattr(c,key),str) or getattr(c,key) not in opts:invalid(key+': opção não reconhecida.')
    if not isinstance(c.anchor_detail_ref,str):invalid('Referência da ancoragem: texto inválido.')
    if type(c.cone_subset_envelope) is not bool:invalid('Envelope suplementar deve ser booleano.')
    if type(c.anchor_detail_confirmed) is not bool:invalid('Confirmação da ancoragem deve ser booleana.')
    for key,default in DETAIL_DEFAULTS.items():
        if type(default) is float:
            val=getattr(c,key)
            if not finite_real(val):invalid(key+': informe número real finito.')
    if issues:return issues
    if c.anchor_projection_above_plate<0:
        invalid('Projeção acima da placa: use zero para proposta automática ou valor positivo.')
    if c.anchor_projection_above_plate>0:
        from .anchor_projection_detail import projection_geometry
        try:
            if projection_geometry(c)['free_tip']< -1e-9:
                invalid('Projeção informada menor que a pilha arruela + porca superior do detalhe.')
        except (ValueError,KeyError):
            invalid('Geometria da porca superior incompatível com o detalhe de projeção.')
    for part in ('web','flange'):
        if getattr(c,'weld_'+part+'_type')=='fillet' and getattr(c,'weld_'+part+'_size')<=0:invalid('Filete da '+('alma' if part=='web' else 'mesa')+': tamanho deve ser positivo.')
    if c.stiffener_detail in ('web_pair','web_pair_visual') and min(c.stiffener_length,c.stiffener_height,c.stiffener_t)<=0:
        invalid('Dimensões dos enrijecedores devem ser positivas.')
    if c.stiffener_detail=='web_pair_visual' and min(c.stiffener_length,c.stiffener_height)<=20:
        invalid('Projeção e altura das nervuras devem superar os patamares de 20 mm.')
    return issues


def detailing_issues(c):
    out=[]
    if c.model_type==2:
        out.append(Issue('warning','Base rotulada Tipo 2: quatro chumbadores internos, ações aplicadas N/V e momento local somente quando decorrente do caminho de V. A rigidez rotacional do detalhe não foi demonstrada.','Escopo do modelo'))
    elif c.migration_message:
        out.append(Issue('warning',c.migration_message,'Migração de projeto legado'))
    elif c.base_fixity!='unspecified':
        out.append(Issue('warning',FIXITIES[c.base_fixity]+': escolha do modelo estrutural global, sem verificação de rigidez rotacional. Família de quatro chumbadores externos com N/M/V. A seleção da família não certifica a rigidez do engaste.','Escopo do modelo'))
    if c.model_type==1 and c.base_fixity=='pinned' and c.M!=0:
        out.append(Issue('warning','Base declarada rotulada com M informado diferente de zero: o momento foi preservado integralmente. Confira a hipótese do modelo global; não se zera M automaticamente.','Ações na face superior'))
    if c.stiffener_detail=='web_pair':
        out.append(Issue('pending','Dois enrijecedores triangulares no plano da alma, um além de cada mesa: interpretação inicial do detalhe. Dimensões armazenadas/desenhadas, sem ganho de resistência. Os resultados NBR são referência da placa SEM enrijecedores; a distribuição real e a capacidade da base enrijecida exigem modelo específico.','Detalhamento sem verificação resistente'))
    if getattr(getattr(c,'column_weld',None),'model','off')=='two_flange_normal_web_shear':
        out.append(Issue('warning','Soldas de alma e mesas independentes: o componente duas mesas N/M e alma V explicita resistências locais, execução e qualificação documental. A seleção de juntas não aprova transferência integral, placa, ancoragem ou rigidez.','NBR 8800, 6.2 e 6.7.1.3'))
    elif c.weld_web_type!='unspecified' or c.weld_flange_type!='unspecified':
        out.append(Issue('pending','Soldas da alma e mesas especificadas separadamente; filetes com pernas iguais a 90° usam a=z/√2. A escolha CJP/filete e suas dimensões não demonstram resistência, metal-base, procedimento, inspeção ou transferência integral N/M/V.','NBR 8800, 6.2 e 6.7.1.3'))
    return out


VISUAL_RIB_NOTE = 'Nervuras de detalhamento: sem crédito de resistência ou rigidez; cálculo mantido sem nervuras. Nervuras e suas soldas não dimensionadas. A distribuição real de esforços e a rigidez do conjunto enrijecido não foram verificadas.'

def visual_rib_outline(length,height):
    if min(length,height)<=20:raise ValueError('Dimensões devem superar 20 mm.')
    return [(0.,0.),(length,0.),(length,20.),(20.,height),(0.,height)]

def proposed_rib_thickness(web):
    from .base_plate import STOCK
    return next((t for t in STOCK.values() if t>web),None)
