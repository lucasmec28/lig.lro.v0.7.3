"""Isolated UI, strict native schema and no stale export after invalid edits."""
from copy import deepcopy
from dataclasses import replace
import json
import math
from .welded_coverplate_splice import CoverplateSplice,Restraint,LoadCase,evaluate,detail_signature,restraint_signature,DECLARATIONS
PREFIX='wcp_'
PROJECT='_wcp_accepted_project'
TEMPLATE='_wcp_template'
ACCEPTED='_wcp_accepted_scalars'
RESULT='_wcp_result'
REPORT='_wcp_report'
ERROR='_wcp_error'
LABELS={
 'project':'Projeto','profile_name':'Designação do perfil','profile_kind':'Tipo de perfil admitido',
 'd':'Altura d (mm)','bf':'Largura da mesa bf (mm)','tf':'Espessura da mesa tf (mm)','tw':'Espessura da alma tw (mm)','root_radius':'Raio de raiz (mm)',
 'flange_width':'Largura das talas de mesa (mm)','flange_t':'Espessura das talas de mesa (mm)',
 'flange_overlap':'Sobreposição de cada lado nas mesas (mm)','flange_leg':'Perna das soldas de mesa (mm)','flange_setback':'Recuo da solda junto ao topo nas mesas (mm)',
 'web_height':'Altura das talas de alma (mm)','web_t':'Espessura de cada tala de alma (mm)',
 'web_overlap':'Sobreposição de cada lado na alma (mm)','web_leg':'Perna das soldas de alma (mm)','web_setback':'Recuo da solda junto ao topo na alma (mm)','gap':'Folga da emenda (mm)',
 'member_fy':'fy do receptor (MPa)','member_fu':'fu do receptor (MPa)','cover_fy':'fy das talas (MPa)','cover_fu':'fu das talas (MPa)','electrode_fw':'fw do eletrodo (MPa)','procedure_id':'Identificação do procedimento de soldagem',
 'N':'N (N; positivo em tração)','M':'M forte (N mm; positivo traciona mesa superior)','V':'V no plano da alma (N)',
 'torsion':'Torção aplicada (N mm; excluída)','weak_M':'M fraco (N mm; excluído)','transverse_V':'V transversal (N; excluído)',
 'geometry_verified':'Geometria real, igualdade e alinhamento verificados','materials_verified':'Materiais e compatibilidade certificados',
 'weld_access_verified':'Acesso às soldas reais, inclusive tala inferior, verificado','procedure_qualified':'Procedimento de soldagem qualificado','inspection_defined':'Plano de inspeção definido',
 'all_welds_complete':'Estado final com todas as soldas concluídas','global_member_design_verified':'Dimensionamento global dos membros verificado externamente',
 'integrity_actions_included':'Ações de integridade aplicáveis incluídas nas combinações',
 'static':'Ações estáticas','normal_combination':'Combinações normais','fatigue':'Fadiga (excluída)','seismic':'Qualificação sísmica (excluída)',
 'fire':'Incêndio (excluído)','erection':'Fase de montagem (excluída)','holes_or_notches':'Furos ou recortes (excluídos)',
 'fillers_or_offsets':'Calços ou desalinhamento (excluídos)','end_bearing':'Crédito de contato de topo (excluído)','minimum_force':'Mínimo de 45 kN quando aplicável',
 'id':'Identificador da combinação','reference':'Fonte ou método aceito para os Le','support_description':'Vínculos reais e flexibilidade do receptor considerados',
 'restraint_and_receiver_verified':'Rigidez e resistência dos travamentos e flexibilidade do receptor verificadas',
 'Le_normal_mm':'Le fora do plano da tala (mm; deslocamento y, flexão em z)',
 'Le_in_plane_mm':'Le no plano da tala (mm; deslocamento z, flexão em y)'}


def walk(value,path=()):
    if isinstance(value,dict):
        for k,v in value.items():yield from walk(v,(*path,k))
    elif isinstance(value,(list,tuple)):
        for i,v in enumerate(value):yield from walk(v,(*path,i))
    else:yield path,value


def key(path):return PREFIX+'_'.join(map(str,path))


def seed(state,c):
    native=c.to_dict();proposed={}
    for path,v in walk(native['connection']):
        display=float(v) if type(v) in (int,float) else v
        if type(v) in (int,float) and (not math.isfinite(display) or display!=v):
            raise ValueError('Entrada numérica não representável sem perda.')
        proposed[key(path)]=display
    proposed[TEMPLATE]=deepcopy(native)
    proposed[ACCEPTED]={path:dict(raw=v,display=proposed[key(path)]) for path,v in walk(native['connection'])}
    state.update(proposed);state[PROJECT]=deepcopy(native)
    state.pop(REPORT,None);state.pop(RESULT,None);state.pop(ERROR,None)
    state.pop('_wcp_import_error',None);state.pop('_wcp_bind_error',None)


def decode(payload):
    if len(payload)>400000:raise ValueError('Arquivo excede 400 kB.')
    def unique(pairs):
        d={}
        for k,v in pairs:
            if k in d:raise ValueError('Chave JSON duplicada: '+k)
            d[k]=v
        return d
    def reject(v):raise ValueError('Número JSON inválido: '+v)
    return CoverplateSplice.from_dict(json.loads(payload,object_pairs_hook=unique,parse_constant=reject))


def import_project(state,payload):
    c=decode(payload)
    staged={};seed(staged,c) # Complete validation before touching accepted state.
    state.update(staged);state.pop(REPORT,None);state.pop(RESULT,None);state.pop(ERROR,None)
    state.pop('_wcp_import_error',None);state.pop('_wcp_bind_error',None)
    return c


def current(state):
    raw=deepcopy(state[TEMPLATE])
    for path,old in walk(raw['connection']):
        v=state[key(path)];accepted=state[ACCEPTED][path]
        if type(v) is type(accepted['display']) and v==accepted['display']:v=accepted['raw']
        target=raw['connection']
        for part in path[:-1]:target=target[part]
        target[path[-1]]=v
    return CoverplateSplice.from_dict(raw)


def recalculate(state):
    state.pop(REPORT,None)
    try:
        c=current(state);r=evaluate(c)
        state[RESULT]=r
        if r['status'] in ('INVALID_INPUT','OUTSIDE_QUALIFIED_SCOPE','DETAIL_FAIL','INVALID_RESTRAINT_INPUT'):
            state[ERROR]='; '.join(r['issues']);return c,r
        state[PROJECT]=c.to_dict();state.pop(ERROR,None)
        return c,r
    except (ValueError,TypeError,ArithmeticError,OverflowError) as exc:
        r=dict(status='INVALID_INPUT',local_pass=False,checks=[],issues=[str(exc)])
        state[RESULT]=r;state[ERROR]=str(exc);return None,r


def render():
    import streamlit as st
    from .welded_coverplate_drawing import drawing_svg
    from .welded_coverplate_report import report_docx,result_json,MODE_LABELS,STATUS_LABELS,component_label,number_pt,project_label
    s=st.session_state
    from .package_identity import PACKAGE_ID
    st.title('Emenda com talas soldadas')
    st.caption('Aplicativo LRO Ligações '+PACKAGE_ID)
    st.info('Verificação local no domínio indicado. O projeto global dos membros e a análise dos travamentos são responsabilidades do projetista.')
    st.caption('NBR 8800:2024 + Errata1:2025; modelo FR AISC Manual15 Parte12. N/M nas mesas; V/2 por tala de alma, sem Lb de alma para Mweb=0.')
    if TEMPLATE not in s:seed(s,CoverplateSplice(project='Emenda com talas soldadas'))
    def load_upload():
        try:
            if s.get('wcp_upload') is not None:import_project(s,s['wcp_upload'].getvalue())
        except (ValueError,TypeError,ArithmeticError) as exc:s['_wcp_import_error']=str(exc)
    st.file_uploader('Importar projeto nativo completo',type=['json'],key='wcp_upload',on_change=load_upload)
    if s.get('_wcp_import_error'):st.error('Importação rejeitada; projeto atual preservado. '+s['_wcp_import_error'])
    def widget(path,v):
        if path[-1]=='detail_signature':return
        label=LABELS.get(path[-1],path[-1]);k=key(path)
        if type(v) is bool:st.checkbox(label,key=k)
        elif type(v) in (int,float):st.number_input(label,key=k,format='%.8g')
        else:st.text_input(label,key=k)
    connection=s[TEMPLATE]['connection']
    with st.expander('Geometria e materiais',expanded=True):
        cols=st.columns(2)
        scalar=[(p,v) for p,v in walk(connection) if p[0] not in ('cases','top_restraint','bottom_restraint') and type(v) is not bool]
        for i,(p,v) in enumerate(scalar):
            with cols[i%2]:widget(p,v)
    with st.expander('Combinações de cálculo',expanded=True):
        st.caption('Unidades nativas N e N mm. Todas as combinações são exibidas e verificadas.')
        def add_case():
            try:
                c=current(s)
                if len(c.cases)>=100:raise ValueError('Limite de 100 combinações.')
                used={x.id for x in c.cases};i=1
                while 'ULS'+str(i) in used:i+=1
                seed(s,replace(c,cases=(*c.cases,LoadCase(id='ULS'+str(i),N=0.,M=0.,V=0.))))
            except (ValueError,TypeError,ArithmeticError) as exc:s[ERROR]=str(exc)
        def remove_case():
            try:
                c=current(s)
                if len(c.cases)>1:seed(s,replace(c,cases=c.cases[:-1]))
            except (ValueError,TypeError,ArithmeticError) as exc:s[ERROR]=str(exc)
        st.button('Adicionar combinação',key='wcp_add_case',on_click=add_case)
        st.button('Remover última combinação',key='wcp_remove_case',on_click=remove_case,disabled=len(connection['cases'])<=1)
        for i,case in enumerate(connection['cases']):
            st.subheader(f'Combinação {i+1}')
            for p,v in walk(case,('cases',i)):widget(p,v)
    with st.expander('Travamentos locais das talas de mesa',expanded=True):
        st.info('Le efetivo fornecido pelo projetista: já contém K. Não é o vão da viga nem a folga. São duas direções para cada tala comprimida; nenhuma transferência automática do travamento global da viga.')
        for side,label in [('top','Tala superior'),('bottom','Tala inferior')]:
            st.subheader(label)
            for p,v in walk(connection[side+'_restraint'],(side+'_restraint',)):widget(p,v)
            def bind(which=side):
                try:
                    c=current(s);rec=getattr(c,which+'_restraint')
                    if not rec.restraint_and_receiver_verified or not rec.reference.strip() or not rec.support_description.strip() or min(rec.Le_normal_mm,rec.Le_in_plane_mm)<=0:
                        raise ValueError('Preencha os dois Le, a fonte, os vínculos e confirme sua verificação antes de vincular.')
                    s[key((which+'_restraint','detail_signature'))]=restraint_signature(c,rec,which)
                    s.pop('_wcp_bind_error',None)
                except (ValueError,TypeError,ArithmeticError) as exc:s['_wcp_bind_error']=str(exc)
            st.button('Confirmar estes vínculos para o detalhe atual: '+label,key='wcp_bind_'+side,on_click=bind)
        if s.get('_wcp_bind_error'):st.error(s['_wcp_bind_error'])
    with st.expander('Domínio e confirmações técnicas',expanded=False):
        for p,v in walk(connection):
            if len(p)==1 and type(v) is bool:widget(p,v)
    c,r=recalculate(s)
    st.subheader('Resultado atual')
    st.write(STATUS_LABELS.get(r['status'],r['status']))
    for issue in r['issues']:st.error(issue)
    st.caption('Dimensionamento global dos membros: pré-requisito externo, não calculado numericamente aqui.')
    if c is not None and r.get('geometry') and r['status'] not in ('INVALID_INPUT','OUTSIDE_QUALIFIED_SCOPE','DETAIL_FAIL','INVALID_RESTRAINT_INPUT'):
        st.image(drawing_svg(c))
    if r['checks']:
        rows=[dict(Combinação=x['case_id'],Componente=component_label(x['component']),Modo=MODE_LABELS.get(x['mode'],x['mode']),Solicitação=number_pt(x['demand']),Resistência=number_pt(x['capacity']),Índice=number_pt(x['utilization'],'.4f'),Unidade=x['unit'],Estado=STATUS_LABELS.get(x['status'],x['status'])) for x in r['checks']]
        st.dataframe(rows,use_container_width=True)
        st.download_button('Projeto JSON atual',json.dumps(c.to_dict(),ensure_ascii=False,indent=2,allow_nan=False),file_name='emenda_talas_projeto.json')
        st.download_button('Resultados rastreáveis JSON',result_json(c),file_name='emenda_talas_resultado.json')
        st.download_button('Desenho SVG',drawing_svg(c),file_name='emenda_talas.svg')
        if st.button('Gerar memorial Word atual',key='wcp_generate_report'):
            s[REPORT]=report_docx(c)
        if REPORT in s:st.download_button('Baixar memorial Word',s[REPORT],file_name='emenda_talas_memorial.docx')
