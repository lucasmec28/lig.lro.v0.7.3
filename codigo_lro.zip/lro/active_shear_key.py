"""Declared active-plate strip idealization; never whole-device approval.

N, mm, MPa.  NBR single-plate equations are reused as component analogies,
not presented as a normative cross/W geometry. Inactive steel has no credit.
"""
from dataclasses import dataclass, field, asdict, fields
import math
from .models import STEELS, Issue, finite_real as _finite

PATHS = ('cross_active_plate', 'w_flange_plates')
METHOD = 'active_plate_strips_v1'
SCOPE_LABEL = 'Verificação local por chapas ativas — idealização de componentes'
SOURCE = 'Idealização declarada de componentes; equações de chapa da NBR 8800:2024 corrigida 2025, 6.7.2.4, 6.6.5 e 6.5.5'
G1, G2, GC = 1.10, 1.35, 1.40
SHARING_LABELS = {
    'unknown_envelope': 'Envelope de repartição desconhecida · casos alternativos (V, 0) e (0, V)',
    'equal': 'Repartição igual V/2 · idealização explicitamente selecionada',
    'verified_range': 'Repartição por faixa documentada nas mesas físicas F+ / F−',
}
PENDING = [
    'Fixação das chapas ativas: resistência/detalhamento das soldas, metal-base e flexão local da placa de base a complementar; nenhuma continuidade de solda é presumida.',
    'Dispositivo completo: ruptura/arrancamento do concreto, bordas e interação de grupo a complementar. O cone dos chumbadores não verifica o concreto da chave nem sua interação.',
    'Transferência à fundação e bloco adequadamente armado a complementar.',
    'Ligações e estabilidade dos componentes inativos (chapa transversal ou alma) a complementar; sem crédito de resistência ou enrijecimento.',
]


@dataclass(frozen=True)
class ActiveShearKey:
    method: str = METHOD
    orientation: str = 'normal_x'
    continuous: bool = False
    concrete_filled: bool = False
    contact_full_depth: bool = True
    H: float = 100.
    b: float = 240.
    t: float = 25.
    secondary_length: float = 200.
    secondary_t: float = 10.
    cross_exclusion_positive: float = 20.
    cross_exclusion_negative: float = 20.
    d: float = 200.
    bf: float = 200.
    tw: float = 10.
    tf: float = 25.
    product: str = 'rolled'
    radius: float | None = None
    junction_exclusion: float = 30.
    geometry_ref: str = ''
    steel: str = 'ASTM A36'
    sharing: str = 'unknown_envelope'
    alpha_min: float = 0.
    alpha_max: float = 1.
    share_ref: str = ''
    share_signs: str = 'both'
    contact_intervals: dict = field(default_factory=dict)
    weld_geometry: dict = field(default_factory=dict)

    def to_dict(self, shape):
        data = asdict(self)
        if shape in PATHS:
            data['contact_intervals'] = contact_intervals(self, shape)
        return data

    @staticmethod
    def from_dict(data):
        if not isinstance(data, dict):
            raise ValueError('Dados da chave por chapas ativas devem ser um objeto JSON.')
        names = {f.name for f in fields(ActiveShearKey)}
        if set(data) - names:
            raise ValueError('Campos de chapas ativas não reconhecidos: ' + ', '.join(sorted(set(data)-names)))
        try:
            key=ActiveShearKey(**data)
            # Canonical centered intervals are reproducible from the unchanged physical
            # dimensions; JSON always writes them explicitly. Preserve custom strips.
            for shape in PATHS:
                if key.contact_intervals == canonical_contact_intervals(key,shape):
                    key=ActiveShearKey(**{**data,'contact_intervals':{}})
                    break
            return key
        except (TypeError, OverflowError) as exc:
            raise ValueError('Dados incompatíveis com a chave por chapas ativas.') from exc


def _strips(b, excluded):
    return [[-b/2, -excluded/2], [excluded/2, b/2]] if excluded else [[-b/2, b/2]]


def canonical_contact_intervals(k, shape):
    if shape == 'cross_active_plate':
        return {'P': {'positive': _strips(k.b, k.cross_exclusion_positive),
                      'negative': _strips(k.b, k.cross_exclusion_negative)}}
    return {'F+': {'positive': _strips(k.bf, 0.), 'negative': _strips(k.bf, k.junction_exclusion)},
            'F-': {'positive': _strips(k.bf, k.junction_exclusion), 'negative': _strips(k.bf, 0.)}}


def contact_intervals(k, shape):
    """Physical intervals, never replace physical steel width with exposed width."""
    return k.contact_intervals if k.contact_intervals else canonical_contact_intervals(k, shape)


def _interval_errors(intervals, width, symmetric=True, allow_empty=False):
    if not isinstance(intervals, (list, tuple)) or (not intervals and not allow_empty):
        return ['Informe intervalos de comprimento positivo.']
    previous = -math.inf
    normalized = []
    for pair in intervals:
        if not isinstance(pair, (list, tuple)) or len(pair) != 2 or not all(_finite(x) for x in pair):
            return ['Extremos dos intervalos devem ser números finitos.']
        lo, hi = pair
        if lo >= hi or lo < -width/2-1e-9 or hi > width/2+1e-9:
            return ['Intervalo negativo, nulo ou fora da largura física da chapa.']
        if lo < previous-1e-9:
            return ['Intervalos sobrepostos ou fora de ordem.']
        previous = hi
        normalized.append((lo, hi))
    if symmetric:
        mirrored = [(-hi, -lo) for lo, hi in reversed(normalized)]
        if any(not math.isclose(x, y, abs_tol=1e-8, rel_tol=0.)
               for p, q in zip(normalized, mirrored) for x, y in zip(p, q)):
            return ['Contato deve ser simétrico em y=0; torção fora do modelo.']
    return []


def validate_active_key(c):
    if c.shear_path not in PATHS:
        return []
    issues = []
    def issue(text, severity='error'):
        issues.append(Issue(severity, text, SOURCE))
    k = c.active_key
    if not isinstance(k, ActiveShearKey):
        issue('Informe uma chave por chapas ativas válida.'); return issues
    texts = ('method','orientation','product','geometry_ref','steel','sharing','share_ref','share_signs')
    for name in texts:
        if not isinstance(getattr(k,name),str):issue(name+': texto inválido.')
    for name in ('continuous','concrete_filled','contact_full_depth'):
        if type(getattr(k,name)) is not bool:issue(name+': confirmação deve ser booleana.')
    positive = ('H','b','t','secondary_length','secondary_t','cross_exclusion_positive',
                'cross_exclusion_negative','d','bf','tw','tf','junction_exclusion')
    for name in positive+('alpha_min','alpha_max'):
        v = getattr(k,name)
        if not _finite(v) or (name in positive and v <= 0):
            issue(name+': informe valor '+('positivo e ' if name in positive else '')+'finito.')
    if k.radius is not None and (not _finite(k.radius) or k.radius < 0):
        issue('Raio de concordância deve ser nulo ou positivo e finito, ou não informado.')
    if not isinstance(k.contact_intervals,dict) or not isinstance(k.weld_geometry,dict):
        issue('Geometria de contato e soldas deve ser registrada por chapa e face.')
    if issues:return issues
    if k.method != METHOD:issue('Identificador do método de chapas ativas não reconhecido.')
    if k.orientation != 'normal_x':
        issue('Orientação fora do modelo: V deve ser normal à chapa ativa/mesas (x). W girado 90° requer outro modelo; não se usa a alma ignorada como substituto.')
    if not k.continuous:
        issue('Confirme chapas ativas inteiras, maciças e contínuas até a raiz, sem furos, rasgos, recortes ou variação de espessura. Na cruz, a chapa perpendicular a V deve atravessar sem interrupção; meias chapas não equivalem à chapa contínua.')
    if not k.concrete_filled:
        issue('Confirme concreto efetivamente preenchendo todas as faixas creditadas, inclusive os vãos internos do W, sem vazio ou folga.')
    if not k.contact_full_depth:
        issue('Exclusões/contatos que variam com a profundidade exigem integração própria; este modelo usa faixas uniformes entre g e H.')
    if k.H <= c.grout_t:issue('H deve superar a espessura real g do graute.')
    if k.product not in ('rolled','fabricated'):issue('Produto da chave deve ser laminado ou fabricado.')
    if k.steel not in STEELS:
        issue('Aço das chapas ativas não reconhecido.')
    else:
        material = STEELS[k.steel]
        rolled = c.shear_path=='w_flange_plates' and k.product=='rolled'
        t = k.tf if c.shear_path=='w_flange_plates' else k.t
        if not (material.rolled_allowed if rolled else material.plate_allowed):
            issue('Aço não aplicável ao produto '+('laminado' if rolled else 'de chapa')+' informado.')
        lo, hi = (material.profile_min,material.profile_max) if rolled else (material.plate_min,material.plate_max)
        thicknesses = [k.tf,k.tw] if c.shear_path=='w_flange_plates' else [k.t]
        if any(not lo<=th<=hi for th in thicknesses):
            issue('Espessura das chapas ativas/perfil fora dos limites do produto selecionado.','noncompliance')
    if c.shear_path=='cross_active_plate':
        width, thickness = k.b,k.t
        if k.b>c.B or max(k.secondary_length,k.t)>c.L:
            issue('A cruz real deve caber sob a base: b≤B e comprimento secundário/espessura ativa≤L.')
        if k.secondary_length<=k.t:issue('Comprimento da chapa secundária deve superar a espessura da chapa ativa.')
        for name in ('cross_exclusion_positive','cross_exclusion_negative'):
            gap = getattr(k,name)
            if not k.secondary_t<=gap<k.b:
                issue('Exclusão real da junção deve incluir a espessura secundária e ser menor que b; inclua solda/folga na face correspondente.')
    else:
        width, thickness = k.bf,k.tf
        if k.d>c.L or k.bf>c.B:issue('O perfil W real deve caber sob a placa: d≤L e bf≤B.')
        if k.d<=2*k.tf or k.bf<=k.tw:issue('Dimensões d/bf/tw/tf do W são inconsistentes.')
        if k.radius is not None and 2*k.radius>k.d-2*k.tf:
            issue('Concordâncias de raio r não cabem na altura livre entre as mesas.')
        minimum = k.tw+2*(k.radius or 0.)
        if not minimum<=k.junction_exclusion<k.bf:
            issue('Exclusão interna deve ser ≥tw+2r (raio informado) e menor que bf; no fabricado inclua toda a solda/obstrução real.')
        if not k.geometry_ref.strip():
            issue('Informe procedência do perfil e fonte do raio ou da exclusão conservadora real da junção; nenhum raio é inventado.')
        if k.sharing not in SHARING_LABELS:issue('Selecione o modelo de repartição nas mesas.')
        if not 0<=k.alpha_min<=k.alpha_max<=1:issue('A faixa deve cumprir 0≤αmin≤αmax≤1.')
        if k.share_signs not in ('both','positive','negative'):issue('Abrangência de sinal da repartição não reconhecida.')
        if k.sharing=='verified_range':
            if not k.share_ref.strip():issue('Repartição documentada requer fonte/referência.')
            if (c.V>0 and k.share_signs=='negative') or (c.V<0 and k.share_signs=='positive'):
                issue('A referência de repartição não cobre o sinal atual de V; atualize a fonte ou use o envelope desconhecido.')
    if thickness>c.tp:issue('Espessura da chapa ativa/mesa não pode superar tp nesta idealização.')
    if any(x.severity=='error' for x in issues):return issues
    contacts = contact_intervals(k,c.shear_path)
    expected = canonical_contact_intervals(k,c.shear_path)
    if set(contacts)!=set(expected):
        issue('Contato deve identificar exatamente as chapas físicas do modelo.');return issues
    for plate, sides in contacts.items():
        if not isinstance(sides,dict) or set(sides)!={'positive','negative'}:
            issue(plate+': registre as duas faces, positiva e negativa.');continue
        for side, intervals in sides.items():
            errors = _interval_errors(intervals,width)
            for error in errors:issue(plate+' / '+side+': '+error)
            if not errors:
                for lo,hi in intervals:
                    if not any(lo>=a-1e-9 and hi<=b+1e-9 for a,b in expected[plate][side]):
                        issue(plate+' / '+side+': faixa de contato invade a junção/obstrução real não exposta.')
    for plate,sides in k.weld_geometry.items():
        if plate not in expected or not isinstance(sides,dict) or set(sides)-{'positive','negative'}:
            issue('Soldas: identifique chapa e face reais, sem comprimentos equivalentes.');continue
        for side,intervals in sides.items():
            for error in _interval_errors(intervals,width,symmetric=False,allow_empty=True):
                issue('Solda '+plate+' / '+side+': '+error)
    return issues


def active_key_assumptions(c):
    if c.shear_path not in PATHS:return []
    k=c.active_key
    return [
        SCOPE_LABEL+'. Equações da chapa única NBR reaplicadas como idealização explícita de componentes/faixas; a norma não prescreve este modelo de cruz/W.',
        'x paralelo a L/V; y paralelo à largura física da chapa; z desce da face inferior da placa. V perpendicular às chapas ativas. Contato uniforme entre g real e H; apenas faixas expostas simétricas e contínuas recebem crédito de aço. Sem redistribuição à banda central ocultada.',
        'Chapa transversal/alma visível, mas sem crédito de resistência ou enrijecimento. Sem soma de atrito, faces opostas, pontas ou capacidades de concreto do dispositivo.',
        ('Cruz: somente a chapa perpendicular a V, inteira e passante, recebe V total.' if c.shear_path=='cross_active_plate' else SHARING_LABELS.get(k.sharing,k.sharing)+'. Mesas físicas F+ em +x e F− em −x mantêm sua identidade na reversão. Repartição igual requer engajamento comum suficiente; dimensões iguais não provam reações iguais, especialmente nas faces internas interrompidas. O envelope cobre apenas parcelas não negativas de V; não cobre forças opostas autoequilibrantes.'),
        ('Ações Tipo 2 na face superior: somente N/V aplicados, M aplicado=0. eV=tp+(H+g)/2; Mlocal=V eV uma única vez, inclusive no envelope. Sem fator 2, sem braço d/2 e sem somar ações de dimensionamento das soldas ao equilíbrio.' if getattr(c,'model_type',1)==2 else 'Ações na face superior: M não inclui previamente esta excentricidade. eV=tp+(H+g)/2; Mef=M+V eV uma única vez, inclusive no envelope. Sem fator 2, sem braço d/2 e sem somar ações de dimensionamento das soldas ao equilíbrio.'),
        'Ações para as soldas por analogia à NBR: Vw=Rcontato e Mw=Rcontato(H+g)/2 por chapa/face, sem limitar pela solicitação ou pelo aço. Geometria desconhecida não impede os resultados locais, mas resistência das soldas permanece pendente.',
    ]+PENDING


def _face(c,k,intervals,t):
    b=sum(hi-lo for lo,hi in intervals)
    fy,fu=STEELS[k.steel].fy,STEELS[k.steel].fu
    area=b*(k.H-c.grout_t);sigma=1.7*c.fck/GC
    bearing=sigma*area;lever=(k.H+c.grout_t)/2
    return dict(b_contact=b,b_calc=b,contact_area=area,sigma_rd=sigma,
                bearing_rd=bearing,bending_rd=b*(fy/G1)*t*t/(2*(k.H+c.grout_t)),
                yield_rd=.60*fy*b*t/G1,rupture_rd=.60*fu*b*t/G2,
                weld_V=bearing,weld_M=bearing*lever)


def active_key_actions(c):
    """Valid inputs only. Per-plate envelope demands are alternative extrema."""
    k=c.active_key;contacts=contact_intervals(k,c.shear_path)
    if c.shear_path=='cross_active_plate':
        descriptors=[('P',0.,k.b,k.t)];shares=[1.];cases=[[c.V]]
        sharing_label='Chapa perpendicular contínua recebe V total'
    else:
        descriptors=[('F+',(k.d-k.tf)/2,k.bf,k.tf),('F-',-(k.d-k.tf)/2,k.bf,k.tf)]
        lo,hi=(0.,1.) if k.sharing=='unknown_envelope' else ((.5,.5) if k.sharing=='equal' else (k.alpha_min,k.alpha_max))
        shares=[hi,1-lo]
        cases=[[hi*c.V,(1-hi)*c.V]]
        if hi!=lo:cases.append([lo*c.V,(1-lo)*c.V])
        sharing_label=SHARING_LABELS[k.sharing]
    sign='negative' if c.V<0 else 'positive'
    lever=(k.H+c.grout_t)/2;plates=[]
    for (pid,x,b,t),share in zip(descriptors,shares):
        faces={side:_face(c,k,intervals,t) for side,intervals in contacts[pid].items()}
        loaded=faces[sign];force=share*c.V
        req=math.sqrt(2*abs(force)*(k.H+c.grout_t)/(loaded['b_calc']*(STEELS[k.steel].fy/G1)))
        local_pass=all(abs(force)<=loaded[key]*(1+1e-12) for key in ('bearing_rd','bending_rd','yield_rd','rupture_rd'))
        plates.append(dict(id=pid,x=x,b_steel=b,t=t,H=k.H,contact_by_sign=contacts[pid],faces=faces,
                           **loaded,force=force,M_root=force*lever,t_required=req,loaded_sign=sign,
                           strip_forces=[force*(hi-lo)/loaded['b_contact'] for lo,hi in contacts[pid][sign]],
                           local_pass=local_pass,weld_geometry=k.weld_geometry.get(pid,{})))
    result=dict(method=METHOD,scope_label=SCOPE_LABEL,sharing_label=sharing_label,plates=plates,
                allocation_cases=cases,z_R=lever,eV=c.tp+lever,delta_M=c.V*(c.tp+lever),
                M_effective=c.M+c.V*(c.tp+lever),local_pass=all(p['local_pass'] for p in plates),
                attachment='pending',device='pending')
    # Reject overflow before a check could be mislabeled as passing.
    def finite_tree(obj):
        if isinstance(obj,dict):return all(finite_tree(v) for v in obj.values())
        if isinstance(obj,(list,tuple)):return all(finite_tree(v) for v in obj)
        return math.isfinite(obj) if type(obj) in (int,float) else True
    if not finite_tree(result):raise OverflowError('Escala numérica das chapas ativas excede a precisão.')
    return result


def add_active_key_checks(c,r,add):
    a=active_key_actions(c);k=c.active_key
    for p in a['plates']:
        prefix='active_'+('P' if p['id']=='P' else ('plus' if p['id']=='F+' else 'minus'))
        description='Chapa ativa '+p['id']+' — '
        common=f'F={p["force"]:.6f}; b físico={p["b_steel"]:g}; bcontato=bcalc={p["b_calc"]:g}; H={k.H:g}; g={c.grout_t:g}; t={p["t"]:g}'
        for tag,title,rd,eq in [
            ('contact','contato local',p['bearing_rd'],'Rcontato = (1,7 fck/γc) bcontato (H−g)'),
            ('bending','flexão local',p['bending_rd'],'Rflexão = bcalc (fy/γa1) t² / [2(H+g)]'),
            ('yield','escoamento por cisalhamento',p['yield_rd'],'Rescoamento = 0,60 fy bcalc t / γa1'),
            ('rupture','ruptura por cisalhamento',p['rupture_rd'],'Rruptura = 0,60 fu bcalc t / γa2')]:
            add(prefix+'_'+tag,description+title,abs(p['force']),rd,'N',SOURCE,eq,
                common+f'; Rd={rd:.6f}; Mraiz={p["M_root"]:.6f}',
                'Somente faixas sólidas expostas; '+a['sharing_label']+'. Atendimento local não aprova o dispositivo completo.')
    for text in PENDING:r.issues.append(Issue('pending',text,SOURCE))
    r.issues.append(Issue('info',SCOPE_LABEL+'. '+a['sharing_label']+'. Sem soma de capacidades de concreto ou do dispositivo.',SOURCE))
    return a
