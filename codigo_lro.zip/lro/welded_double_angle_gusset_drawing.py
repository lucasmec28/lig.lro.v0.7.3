from .display_precision import calculated_text
"""Current-input proportional views of the welded symmetric 2L-T–gusset–W-flange route.

Public exports always evaluate the input again. A supplied result never grants
approval, supplies substitute geometry, or changes the actual force line.
"""
from .display_precision import display_format
from io import BytesIO
from dataclasses import asdict
import hashlib
import json
import math

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Arc, Polygon, Rectangle

from .drawing_annotations import dimension, rendered_wrap
from .welded_double_angle_gusset import COMPONENT_VERSION
from .welded_double_angle_gusset_presentation import (selected_angle, angle_transfer, angle_identity,
                                                angle_detail_disclosure)

INK = '#243749'
MUTED = '#667788'
PLATE = '#dce5ec'
ANGLE = '#80b4c0'
WELD = '#b13b39'
STATUS = {
    'INVALID_INPUT': 'Dados inválidos', 'INVALID_GEOMETRY': 'Geometria inválida',
    'NUMERICAL_FAILURE': 'Falha numérica', 'OUTSIDE_SCOPE': 'Fora do domínio qualificado',
    'DETAIL_FAIL': 'Não atende ao detalhamento', 'DETAILING_FAIL': 'Não atende ao detalhamento',
    'CHECKS_FAIL_AND_UNVERIFIED': 'Falha local e vínculos não verificados',
    'NOT_VERIFIED': 'Condições pendentes', 'INCOMPLETE_CHECKS': 'Verificações incompletas',
    'LOCAL_CHECKS_FAIL': 'Não atende às verificações locais',
    'COMPLETE_CHECKS_FAIL': 'Não atende às verificações locais',
    'VERIFIED_SUBCHECK_FAIL': 'Não atende às verificações locais',
    'LOCAL_CHECKS_PASS_WITHIN_SCOPE': 'Atende localmente no domínio',
    'COMPLETE_LOCAL_CHECKS_PASS_WITHIN_SCOPE': 'Atende localmente no domínio',
    'COMPLETE_CHECKS_PASS_WITHIN_SCOPE': 'Atende localmente no domínio',
}


def input_fingerprint(c):
    try: native = c.to_dict()
    except (TypeError, ValueError, ArithmeticError): native = asdict(c)
    return hashlib.sha256(json.dumps(native, ensure_ascii=False, sort_keys=True,
                                     separators=(',', ':'), default=str).encode()).hexdigest()


def validated_result(c, result=None):
    from .welded_double_angle_gusset import evaluate
    try: return evaluate(c)
    except (TypeError, ValueError, OverflowError, ArithmeticError) as exc:
        return {'status': 'NUMERICAL_FAILURE', 'global_pass': False,
                'geometry': {'valid': False}, 'summary': {'complete_checks': False},
                'checks': [], 'cases': [],
                'issues': [{'id': 'export_evaluation', 'severity': 'error', 'message': str(exc)}]}


def approved(r):
    return (r.get('global_pass') is True and r.get('geometry', {}).get('valid') is True
            and r.get('summary', {}).get('complete_checks') is True and bool(r.get('checks'))
            and all(x.get('status') == 'PASS' for x in r['checks']))


def _n(value, divisor=1):
    try: return f"{display_format(value / divisor, '.6g')}".replace('.', ',')
    except (TypeError, ValueError, OverflowError): return str(value)


def _line(ax, start, end, gid, **style):
    line, = ax.plot([start[0], end[0]], [start[1], end[1]], **style)
    line.set_gid(gid); return line


def _patch(ax, points, gid, **style):
    patch = Polygon(points, closed=True, **style); patch.set_gid(gid)
    ax.add_patch(patch); return patch


def angle_outline(section=None):
    """Rounded catalog outline only when both actual radii are available."""
    if section is None:
        from .angle_catalog import get_angle, LEGACY_ARCELOR_ID
        section = get_angle(LEGACY_ARCELOR_ID)
    if any(section.get(k) is None for k in ('leg', 't', 'root_radius', 'toe_radius')):
        return None
    b, t, root, toe = (section[k] for k in ('leg', 't', 'root_radius', 'toe_radius'))
    points = [(0., 0.), (b, 0.), (b, t-toe)]
    points += [(b-toe + toe*math.cos(a), t-toe + toe*math.sin(a))
               for a in [i*math.pi/2/16 for i in range(1, 17)]]
    points += [(t+root, t)]
    points += [(t+root + root*math.cos(a), t+root + root*math.sin(a))
               for a in [-math.pi/2-i*math.pi/2/24 for i in range(1, 25)]]
    points += [(t, b-toe)]
    points += [(t-toe + toe*math.cos(a), b-toe + toe*math.sin(a))
               for a in [i*math.pi/2/16 for i in range(1, 17)]]
    return points + [(0., b)]


def _nominal_section(ax, section):
    """Interrupted schematic: unknown corners are deliberately left open."""
    b, t = section['leg'], section['t']
    _line(ax, (b, 0.), (0., 0.), 'nominal_angle_outer_bottom', color=ANGLE, lw=2)
    _line(ax, (0., 0.), (0., b), 'nominal_angle_outer_side', color=ANGLE, lw=2)
    # These short dashed guides identify nominal thickness. Their ends are
    # drafting breaks, never asserted tangencies or calculated corner radii.
    low, high = t + .3*(b-t), b - .2*(b-t)
    _line(ax, (low, t), (high, t), 'nominal_angle_inner_bottom', color=ANGLE, lw=1.2, ls='--')
    _line(ax, (t, low), (t, high), 'nominal_angle_inner_side', color=ANGLE, lw=1.2, ls='--')
    ax.text(t, t, '?', fontsize=9, color=MUTED, ha='center', va='center', gid='unpublished_root_corner')
    ax.text(b, t/2, '?', fontsize=9, color=MUTED, ha='center', va='center', gid='unpublished_toe_corner')
    ax.text(t/2, b, '?', fontsize=9, color=MUTED, ha='center', va='center')


def figure(c, result=None):
    r = validated_result(c, result)
    angle = selected_angle(c, r)
    transfer = angle_transfer(angle)
    project = rendered_wrap('Projeto: ' + str(getattr(c, 'project', '')), 920, 9)
    extra = max(0, project.count('\n')) * .16
    fabrication_notes = '\n'.join((r.get('geometry') or {}).get('fabrication_notes', []))
    if fabrication_notes:
        both_faces = 'Executar e inspecionar nas duas cantoneiras, faces +z e −z.'
        if 'Executar e inspecionar nas duas cantoneiras e nas duas faces.' in fabrication_notes:
            fabrication_notes = fabrication_notes.replace('Executar e inspecionar nas duas cantoneiras e nas duas faces.', both_faces)
        else:
            fabrication_notes += ' ' + both_faces
    fabrication_text = rendered_wrap(calculated_text(fabrication_notes, assignments_only=True), 930, 8, fontweight='bold') if fabrication_notes else ''
    detail_height = (.2 + .14 * (fabrication_text.count('\n')+1)) if fabrication_text else 0.
    fig = plt.figure(figsize=(14, 11.5 + extra + detail_height), facecolor='white')
    fig._welded_double_angle_gusset_result = r
    fig._welded_double_angle_gusset_fingerprint = input_fingerprint(c)
    height = fig.get_figheight()
    def text(x, y, value, gid=None, **kwargs):
        obj = fig.text(x, y / height, value, color=kwargs.pop('color', INK), **kwargs)
        if gid: obj.set_gid(gid)
        return obj
    text(.035, height-.36, '2L EM T SOLDADAS À CHAPA DE NÓ E À MESA W', fontsize=16, fontweight='bold')
    member_labels={'beam':'VIGA W','column':'PILAR W'}
    text(.965, height-.35, member_labels.get(getattr(c,'support_member',''),'APOIO '+str(getattr(c,'support_member',''))), fontsize=11, ha='right')
    text(.035, height-.63, project, 'current_project', fontsize=9, va='top')
    if fabrication_text:
        text(.035, height-.94-extra, fabrication_text, 'angle_edge_fabrication_instruction', fontsize=8,
             va='top', fontweight='bold', linespacing=1.35)
    text(.035, 10.50, STATUS.get(r.get('status'), str(r.get('status'))), 'engine_status', fontsize=11,
         fontweight='bold', color=INK if approved(r) else WELD)
    text(.965, 10.50, 'Resultado local; não é liberação de fabricação', 'approval_scope', fontsize=8.5, ha='right')
    text(.035, 10.24, 'Ações atuais: N total do par=' + _n(getattr(c, 'N', None), 1000) + ' kN; N/2 por L=' + _n(getattr(c, 'N', None), 2000) + ' kN; V=' + _n(getattr(c, 'V', None), 1000)
         + ' kN; M adicional=' + _n(getattr(c, 'M', None), 1e6) + ' kN m; T=' + _n(getattr(c, 'torsion', None), 1e6) + ' kN m.',
         'actual_actions', fontsize=9)
    text(.035, 10.00, 'Duas cantoneiras idênticas: ' + angle_identity(angle, getattr(c, 'angle_profile', '')),
         'selected_angle_identity', fontsize=8.5)
    safe = (r.get('geometry', {}).get('valid') is True and getattr(c, 'support_face', None) == 'flange'
            and angle is not None and transfer is not None
            and getattr(c, 'topology', '') == 'symmetric_T' and getattr(c, 'interface', '') == 'welded'
            and getattr(c, 'symmetric_load', False) is True and getattr(c, 'accessible_both_faces', False) is True)
    if not safe:
        text(.05, 9.2, 'ENTRADA ATUAL SEM GEOMETRIA QUALIFICADA PARA ESTA VISTA', 'diagnostic_only', fontsize=14, fontweight='bold', color=WELD)
        lines = ['Face receptora informada: ' + str(getattr(c, 'support_face', '')),
                 'Cantoneira: ' + angle_identity(angle, getattr(c, 'angle_profile', '')),
                 'Fonte: ' + str((angle or {}).get('source', 'não disponível')),
                 angle_detail_disclosure(angle),
                 'Nenhuma geometria aprovada foi substituída pela entrada atual.']
        lines += [str(x.get('message', x)) for x in r.get('issues') or []]
        text(.05, 8.7, rendered_wrap('\n'.join(lines), 900, 11), fontsize=11, va='top', linespacing=1.45)
        text(.035, .4, COMPONENT_VERSION + ' · SHA-256: ' + input_fingerprint(c), 'input_fingerprint', fontsize=7)
        return fig

    theta = math.radians(c.theta_deg); co, si = math.cos(theta), math.sin(theta)
    point = lambda u, v: (c.center_s + u*co + v*si, c.center_n + u*si-v*co)
    u0, u1 = -c.weld_length/2, c.weld_length/2
    free_u = u0-c.end_margin; projected_v = transfer['projected_centroid']
    leg, angle_t, ec = (angle[k] for k in ('leg', 't', 'centroid'))
    half_leg = leg/2.
    split_text = _n(100*transfer['heel']) + '/' + _n(100*transfer['toe']) + '%'
    W = r['geometry']['support_catalog']
    B, H, t, weld = c.plate_width, c.plate_height, c.plate_t, c.angle_weld_leg
    elev = fig.add_axes((.035, 5.3/height, .59, 4.42/height))
    section = fig.add_axes((.685, 5.55/height, .28, 4.0/height))
    support = fig.add_axes((.705, 1.65/height, .25, 3.25/height))
    longitudinal = fig.add_axes((.035, 2.1/height, .59, 2.15/height))
    for ax in (elev, section, support, longitudinal): ax.set_aspect('equal'); ax.axis('off')
    elev.set_title('Plano da chapa · duas faces sobrepostas · dimensões em mm', loc='left', fontsize=10, pad=8)
    _patch(elev, r['geometry']['polygon'], 'gusset_polygon', facecolor=PLATE, edgecolor=INK)
    from .gusset_outer_end_drawing import draw as draw_outer_end
    draw_outer_end(elev,r['geometry'],_n)
    elev.add_patch(Rectangle((-B/2-40,-W['tf']),B+80,W['tf'],facecolor='#a9b6c2',edgecolor=INK))
    _patch(elev, [point(free_u,-half_leg), point(free_u,half_leg),point(u1+70,half_leg),point(u1+70,-half_leg)],
           'two_connected_angle_legs_projected', facecolor=ANGLE, edgecolor=INK, alpha=.62)
    _line(elev, point(free_u,-half_leg),point(free_u,half_leg), 'angle_free_end', color=INK, lw=2)
    for name, v, fraction in (('heel',-half_leg,transfer['heel']),('toe',half_leg,transfer['toe'])):
        for face, width, style in (('face_positive', 4, '-'), ('face_negative', 1.7, '--')):
            _line(elev, point(u0,v),point(u1,v), 'angle_weld_'+name+'_'+face, color=WELD if face == 'face_positive' else '#74262d', lw=width, ls=style)
        s,n = point(.2*c.weld_length,v)
        label = ('Calcanhar ' if name == 'heel' else 'Ponta ') + _n(100*fraction) + '% de N/2' + '\n' + _n(fraction*c.N,2000) + ' kN por face' + '\nΣ faces ' + _n(fraction*c.N,1000) + ' kN'
        elev.annotate(label,xy=(s,n),xytext=(-62 if name=='heel' else 42,4), textcoords='offset points',
                      fontsize=8, color=WELD, ha='right' if name=='heel' else 'left',
                      arrowprops={'arrowstyle':'-','color':WELD,'lw':.8}, bbox={'facecolor':'white','edgecolor':'none','alpha':.85,'pad':2})
    _line(elev, (-B/2,0),(B/2,0),'root_weld_line',color=WELD,lw=4)
    forcepoint = point(0,projected_v)
    force_root_s=forcepoint[0]-forcepoint[1]*co/si
    # Extend the same axial line to the root plane; no second force/couple.
    intersection=(force_root_s,0.)
    _line(elev,intersection,point(u1+90,projected_v),'physical_force_line',color=INK,lw=1.2,ls='--')
    _line(elev,(0.,0.),(0.,0.),'root_weld_centroid',color=INK,marker='o',ms=4)
    _line(elev,intersection,intersection,'force_root_intersection',color=INK,marker='o',ms=3)
    elev.annotate('G · (0; 0)',xy=(0.,0.),xytext=(8,10),textcoords='offset points',fontsize=7.5,zorder=8,
                  bbox={'facecolor':'white','edgecolor':'none','pad':1.5}).set_gid('root_centroid_label')
    if abs(force_root_s)>1e-9*max(1.,B):
        _line(elev,intersection,(force_root_s,-40.),'eccentricity_extension',color=MUTED,lw=.7)
        _line(elev,(0.,0.),(0.,-40.),'root_centroid_extension',color=MUTED,lw=.7)
        _,offset_label=dimension(elev,(force_root_s,-40.),(0.,-40.),'e_s='+_n(force_root_s)+' mm',fontsize=7.5,offset=(0,16))
        offset_label.set_gid('force_line_root_offset')
    else:
        elev.text(-B/2,-40.,'Linha axial por G · e_s=0',fontsize=7.5,
                  bbox={'facecolor':'white','edgecolor':'none','pad':1.5}).set_gid('force_line_root_offset')
    elev.plot(*forcepoint,'o',color=INK,ms=4)
    # The angle is local to the receiving member, never global horizontal.
    # The physical CG point is only the origin of this direction reference;
    # the unchanged dashed line continues to represent the actual N line.
    reference_end=(forcepoint[0]+110.,forcepoint[1])
    reference=elev.annotate('',xy=reference_end,xytext=forcepoint,
                           arrowprops={'arrowstyle':'->','color':MUTED,'lw':1.,'linestyle':'--'})
    reference.set_gid('angle_reference_positive_s')
    axis_label_above=point(.2*c.weld_length,half_leg)[1] < forcepoint[1]
    axis_label_offset=50 if c.N<0 and c.theta_deg<=60 else (14 if axis_label_above else -8)
    label=elev.text(reference_end[0]+4,reference_end[1]+axis_label_offset,'+s · eixo W',fontsize=8,color=MUTED,zorder=8,
                    va='bottom' if axis_label_above else 'top',bbox={'facecolor':'white','edgecolor':'none','pad':1.5})
    label.set_gid('angle_reference_axis_label')
    arc_radius=30.
    arc=Arc(forcepoint,2*arc_radius,2*arc_radius,angle=0,theta1=0,theta2=c.theta_deg,
            color=INK,lw=1.2)
    arc.set_gid('brace_angle_arc');elev.add_patch(arc)
    end=(forcepoint[0]+arc_radius*co,forcepoint[1]+arc_radius*si)
    before=math.radians(max(0.,c.theta_deg-7.))
    arrow=elev.annotate('',xy=end,
                       xytext=(forcepoint[0]+arc_radius*math.cos(before),forcepoint[1]+arc_radius*math.sin(before)),
                       arrowprops={'arrowstyle':'->','color':INK,'lw':1.2})
    arrow.set_gid('brace_angle_direction')
    half=theta/2
    label=elev.text(forcepoint[0]+53*math.cos(half),forcepoint[1]+53*math.sin(half),
                    'θ='+_n(c.theta_deg)+'°',fontsize=8,ha='center',va='center',
                    bbox={'facecolor':'white','edgecolor':'none','pad':1.5})
    label.set_gid('brace_angle_value')
    sign = 1 if c.N >= 0 else -1
    if c.N:
        tail, head = point(u1+15,projected_v),point(u1+70*sign,projected_v)
        annotation = elev.annotate('',xy=head,xytext=tail,arrowprops={'arrowstyle':'-|>','color':INK,'lw':2})
        annotation.set_gid('actual_force_arrow')
    p0,p1 = point(u0,-c.introduction_width/2),point(u0,c.introduction_width/2)
    _line(elev,p0,p1,'local_introduction_section',color='#286644',lw=1.4,ls='-.')
    elev.annotate('Seção local b='+_n(c.introduction_width),xy=p0,xytext=(-50,-16),textcoords='offset points',
                  fontsize=8,color='#286644',arrowprops={'arrowstyle':'-','color':'#286644'},
                  bbox={'facecolor':'white','edgecolor':'none','pad':1.5})
    dimension(elev,(-B/2,-68),(B/2,-68),'B = '+_n(B),fontsize=8)
    dimension(elev,(B/2+36,0),(B/2+36,H),('H_env = ' if r['geometry'].get('outer_end_cut',{}).get('trimmed') else 'H = ')+_n(H),fontsize=8,rotation=90)
    length_a,length_b=point(u0,-half_leg-27),point(u1,-half_leg-27)
    dimension(elev,length_a,length_b,'L = '+_n(c.weld_length),fontsize=8,rotation=c.theta_deg if c.theta_deg<=90 else c.theta_deg-180,offset=(-14,3))
    margin_mid=point((free_u+u0)/2,half_leg)
    elev.annotate('Margem livre = '+_n(c.end_margin)+' mm',xy=margin_mid,xytext=(40,-38),textcoords='offset points',
                  fontsize=8,arrowprops={'arrowstyle':'-','color':INK,'lw':.8},bbox={'facecolor':'white','edgecolor':'none','alpha':.9,'pad':2}).set_gid('free_end_margin_label')
    elev.text(-B/2,-95,'Dois filetes na raiz: perna '+_n(c.root_weld_leg)+'; L = B. Mesa exterior (vista parcial).',fontsize=8)
    elev.text(-B/2,H+38,'θ='+_n(c.theta_deg)+'°; centro das soldas ('+_n(c.center_s)+'; '+_n(c.center_n)+'); centroide v='+_n(projected_v)+'.',fontsize=8)
    elev.set_xlim(-B/2-90,B/2+110); elev.set_ylim(-112,max(H+65,point(u1+90,half_leg)[1]+20))

    outline = angle_outline(angle)
    scale = leg/100.
    section.set_title('Corte T normal à diagonal · '+('contorno publicado' if outline is not None else 'nominal'), fontsize=9, loc='left', pad=12)
    section.add_patch(Rectangle((-t/2,-leg-22*scale),t,leg+38*scale,facecolor=PLATE,edgecolor=INK,gid='single_central_gusset_T_section'))
    for sign, face, color in ((1, 'face_positive', ANGLE), (-1, 'face_negative', '#d9a568')):
        transform = lambda p: (sign*(t/2+p[1]), -p[0])
        if outline is not None:
            _patch(section, [transform(p) for p in outline], 'angle_section_'+face, facecolor=color, edgecolor=INK, lw=1.1)
        else:
            # Published b and t define nominal guides, not manufactured radii.
            low, high = angle_t+.3*(leg-angle_t), leg-.2*(leg-angle_t)
            for a, b, gid, style in (((leg,0),(0,0),'outer_connected','-'), ((0,0),(0,leg),'outer_free','-'),
                                     ((low,angle_t),(high,angle_t),'inner_connected','--'), ((angle_t,low),(angle_t,high),'inner_free','--')):
                _line(section, transform(a), transform(b), 'nominal_angle_'+gid+'_'+face, color=color, lw=2 if style == '-' else 1.2, ls=style)
            for point_id, p in (('root',(angle_t,angle_t)), ('toe',(leg,angle_t/2)), ('free_toe',(angle_t/2,leg))):
                z, w = transform(p)
                section.text(z,w,'?',fontsize=8,color=MUTED,ha='center',va='center',gid='unpublished_'+point_id+'_'+face)
        for name, points in (('heel',[(-weld,0),(0,0),(0,weld)]), ('toe',[(leg,0),(leg+weld,0),(leg,weld)])):
            _patch(section, [transform(p) for p in points], name+'_fillet_section_'+face, facecolor=WELD, edgecolor=WELD)
        cg=transform((ec,ec))
        _line(section,cg,cg,'angle_centroid_'+face,color=INK,marker='+',ms=8,mew=1.1)
        section.text(sign*(t/2+.62*leg), -38*scale, 'L '+('face +z' if sign>0 else 'face −z')+'\nN/2 = '+_n(c.N,2000)+' kN', fontsize=7.5,ha='center',va='top')
    _line(section,(-leg-t/2-12*scale, -leg*.66),(leg+t/2+12*scale,-leg*.66),'T_section_z_axis',color=MUTED,lw=.7,ls='--')
    section.text(leg+t/2+13*scale,-leg*.66,'+z',fontsize=8,va='center')
    section.annotate('Chapa única t='+_n(t),xy=(0,-leg*.81),xytext=(.34*leg,-.98*leg), fontsize=7.5,arrowprops={'arrowstyle':'-','lw':.7})
    section.text(0,23*scale,'Talões alinhados · abas livres para ±z',fontsize=7.8,ha='center')
    section.text(0,-leg-39*scale,'4 filetes longitudinais: talão + ponta em cada face',fontsize=7.5,ha='center')
    section.text(0,-leg-55*scale,'b='+_n(leg)+'; tL='+_n(angle_t)+'; Ag por L='+_n(angle['Ag'])+' mm²',fontsize=7.5,ha='center')
    section.text(0,-leg-71*scale,'ec por L='+_n(ec)+(' mm; compressão local, Ct inativo' if c.N<0 else ' mm; Ct por L preservado'),fontsize=7.5,ha='center')
    if outline is None:
        section.text(0,-leg-88*scale,'Raios não publicados · cantos não definidos',fontsize=7.1,ha='center',gid='unknown_angle_radii')
        section.text(0,-leg-103*scale,'Face plana não publicada · contorno nominal',fontsize=7.1,ha='center',gid='unknown_angle_toe_flat')
    else:
        section.text(0,-leg-88*scale,'Raio interno '+_n(angle['root_radius'])+'; ponta '+_n(angle['toe_radius'])+' mm',fontsize=7.5,ha='center')
        section.text(0,-leg-103*scale,'Face plana da ponta: '+_n(angle.get('toe_flat'))+' mm',fontsize=7.5,ha='center')
    section.set_xlim(-1.31*leg-t/2,1.31*leg+t/2); section.set_ylim(-leg-112*scale,36*scale)

    support.set_title('Corte no W · raiz centrada na alma',fontsize=10,loc='left',pad=8)
    d,bf,tw,tf=(W[k] for k in ('d','bf','tw','tf'))
    _patch(support,[(-bf/2,0),(bf/2,0),(bf/2,-tf),(tw/2,-tf),(tw/2,-d+tf),(bf/2,-d+tf),
                    (bf/2,-d),(-bf/2,-d),(-bf/2,-d+tf),(-tw/2,-d+tf),(-tw/2,-tf),(-bf/2,-tf)],
           'support_W_section',facecolor='#c1ccd6',edgecolor=INK)
    support.add_patch(Rectangle((-t/2,0),t,80,facecolor=PLATE,edgecolor=INK,gid='gusset_root_section'))
    rw=c.root_weld_leg
    _patch(support,[(-t/2-rw,0),(-t/2,0),(-t/2,rw)],'root_fillet_left',facecolor=WELD)
    _patch(support,[(t/2,0),(t/2+rw,0),(t/2,rw)],'root_fillet_right',facecolor=WELD)
    _line(support,(0,95),(0,-d-10),'W_web_centerline',color=MUTED,lw=.7,ls='--')
    support.annotate('t chapa='+_n(t)+'\n2 filetes de '+_n(rw),xy=(t/2+rw,2),xytext=(45,70),fontsize=8,arrowprops={'arrowstyle':'-','lw':.8})
    support.text(-bf/2-18,-d-41,str(W['name'])+' · d'+_n(d)+'; bf'+_n(bf)+'\ntw'+_n(tw)+'; tf'+_n(tf)+'; raio'+_n(W['r'])+' mm',fontsize=8,va='top')
    support.set_xlim(-bf/2-28,max(bf/2+40,145)); support.set_ylim(-d-84,105)

    longitudinal.set_title('Raiz longitudinal sobre a mesa W · extensão real do apoio',fontsize=10,loc='left',pad=10)
    lo,hi=-c.support_end_left,c.support_end_right
    longitudinal.add_patch(Rectangle((lo,-bf/2),hi-lo,bf,facecolor='#e7edf2',edgecolor=INK,gid='support_longitudinal_flange'))
    _line(longitudinal,(lo,0),(hi,0),'support_longitudinal_axis',color=MUTED,lw=.8,ls='--')
    for offset,gid in ((-t/2,'root_weld_left_face'),(t/2,'root_weld_right_face')):
        _line(longitudinal,(-B/2,offset),(B/2,offset),gid,color=WELD,lw=2)
    dimension(longitudinal,(lo,-125),(-B/2,-125),_n(c.support_end_left-B/2)+' livre',fontsize=8)
    dimension(longitudinal,(-B/2,-125),(B/2,-125),'Raiz '+_n(B),fontsize=8)
    dimension(longitudinal,(B/2,-125),(hi,-125),_n(c.support_end_right-B/2)+' livre',fontsize=8)
    longitudinal.set_xlim(lo-30,hi+30);longitudinal.set_ylim(-195,140)
    text(.035,4.80,'θ parte de +s, eixo longitudinal da viga ou do pilar W, até o eixo da cantoneira; não é a horizontal global.',
         'angle_member_reference',fontsize=8.3)
    text(.035,4.55,'Cada face: '+split_text+' de N/2 no talão/ponta. Chapa e raiz recebem N total; a simetria não apaga M da raiz.',fontsize=8.3)
    ns,vs=c.N*si,c.N*co
    moment=forcepoint[0]*ns-forcepoint[1]*vs
    root=r.get('root') or {}
    moment_display=('≈0' if abs(force_root_s)<=1e-9*max(1.,B) and abs(root.get('M',1.))<=1e-8*max(1.,abs(root.get('N',0.))) else _n(root.get('M'),1e6))
    root_text=('Raiz atual: Nnormal='+_n(root['N'],1000)+' kN; Vparalelo='+_n(root['V'],1000)+' kN; M='+moment_display+' kN m.'
               if all(k in root for k in ('N','V','M')) else 'Ações da raiz não avaliadas: entrada fora do domínio ou cálculo incompleto.')
    text(.035,1.94,'Momento local derivado da excentricidade da força axial; não é momento aplicado à cantoneira.',
         'axial_force_root_moment_explanation',fontsize=8.1)
    text(.035,1.70,root_text,'signed_root_actions',fontsize=9)
    text(.035,1.42,'Uma chapa A=B·t; dois filetes na raiz. Quatro soldas das L não duplicam a chapa nem a raiz.',fontsize=8.3)
    text(.035,1.14,'Apoio global requer ações concorrentes reais e verificação própria; esta figura documenta apenas o modelo local.',fontsize=8.3)
    text(.035,.82,'Aços: 2L idênticas '+str(c.angle_steel)+'; chapa '+str(c.gusset_steel)+'; apoio '+str(c.support_steel)+'.',fontsize=8)
    text(.035,.59,'Consumíveis independentes: 2L–chapa '+str(c.angle_electrode)+'; raiz '+str(c.root_electrode)+'. Dimensões em mm.',fontsize=8)
    text(.035,.08,'Fonte da cantoneira: '+str(angle.get('source','não disponível')),'selected_angle_source',fontsize=6.7)
    text(.035,.27,COMPONENT_VERSION+' · SHA-256: '+input_fingerprint(c),'input_fingerprint',fontsize=7)
    if c.N < 0:
        comp=r.get('compression') or {}; strip=comp.get('strip') or {}
        if strip.get('ends'):
            _line(elev,*strip['ends'],'compression_whitmore_retained',color='#75429c',lw=1.5,ls='--')
            for i,(p,x) in enumerate(zip(strip['ends'],strip['root_projections'])):
                _line(elev,p,(x,0),'compression_root_projection_'+str(i),color='#75429c',lw=.8,ls=':')
        # A dedicated footer keeps all legacy drawing views and annotations.
        old=fig.get_figheight();extra=1.15;new=old+extra
        for ax in fig.axes:
            box=ax.get_position();ax.set_position([box.x0,(box.y0*old+extra)/new,box.width,box.height*old/new])
        for obj in fig.texts:
            x,y=obj.get_position();obj.set_position((x,(y*old+extra)/new))
        fig.set_size_inches(fig.get_figwidth(),new)
        model_note='Compressão local: DG29 Ex5.4 K1,2. Faixa roxa reduzida na raiz real; N integral uma vez.' if strip else 'Compressão local: faixa não qualificada para a entrada atual; nenhum cálculo de instabilidade disponível.'
        strip_note=('bw='+_n(strip['width'])+' mm; Lmáx='+_n(strip['Lmax'])+' mm; Le/r='+_n(strip['Le_over_r'])+'; Nc,Rd='+_n(strip['resistance'],1000)+' kN (condicional).') if strip else 'Campo misto ou caminho geométrico não qualificado: consultar a ocorrência específica; não há resistência presumida.'
        lines=[(model_note, 'compression_model'),
               (strip_note,'compression_strip_values'),
               ('Raiz/W e continuação da diagonal: vínculos de rotação separados. W: contenção relativa ou ℓ e rotação reais.', 'compression_boundary_contract'),
               ('Vínculos pendentes: '+str(len(r.get('summary',{}).get('unverified_ids',[])))+'; falhas físicas: '+str(len(r.get('summary',{}).get('failed_check_ids',[])))+'. Não se presume travamento, vão lateral ou ações globais nulas.','compression_pending_status')]
        for i,(value,gid) in enumerate(lines):fig.text(.035,(.93-i*.23)/new,value,color=INK,fontsize=8,gid=gid)
    return fig


def image_bytes(c, result=None, fmt='png'):
    if fmt not in ('png','svg'): raise ValueError('Formato de desenho não suportado.')
    fig=figure(c,result)
    try:
        out=BytesIO()
        with matplotlib.rc_context({'svg.fonttype':'none'}):
            fig.savefig(out,format=fmt,dpi=150,facecolor='white',metadata={'Creator':'LRO Soluções de engenharia'})
        return out.getvalue()
    finally: plt.close(fig)


def drawing_svg(c, result=None):
    return image_bytes(c,result,'svg').decode('utf-8')
