"""Independent R017 UI, native persistence and conservative result presentation."""
from dataclasses import fields
import hashlib
import json
import math

import pandas as pd
import streamlit as st
from .load_conventions import render as render_load_convention

from .angle_catalog_ui import (render_selector as render_angle_catalog,
    draft_keys as angle_catalog_draft_keys, reset as reset_angle_catalog)
from .models import Profile, profiles, STEELS, BOLTS, KGF, VERSION
from .coped_double_angle import CopedDoubleAngle, FAMILY, SCOPE, HOLES, presets, evaluate
from .coped_double_angle_presentation import (physical_envelopes, governing_description,
    component_label, direction_label, state_label, check_label)
from .report import BRAND, LINK, number

P = {name: p for name, p in profiles().items() if p.family == 'W'}
PRESETS = presets()
CUSTOM = 'W personalizado'
PROFILE_VALUES = ('d', 'bf', 'tw', 'tf', 'clear', 'area', 'mass')
LOAD_UNITS = {'V': KGF, 'N': KGF, 'M': KGF * 1000, 'torsion': KGF * 1000}
LOAD_KEYS = {'V': 'V_kgf', 'N': 'N_kgf', 'M': 'M_kgfm', 'torsion': 'torsion_kgfm'}
STATUS = {
    'INVALID_INPUT': 'DADOS INVÁLIDOS',
    'NUMERICAL_FAILURE': 'FALHA NUMÉRICA · CÁLCULO NÃO CONCLUÍDO',
    'INVALID_GEOMETRY': 'GEOMETRIA FISICAMENTE INVÁLIDA',
    'OUTSIDE_R017_SCOPE': 'FORA DO DOMÍNIO R017 · CORTANTE',
    'DETAIL_FAIL': 'NÃO ATENDE AO DETALHAMENTO',
    'VERIFIED_SUBCHECK_FAIL': 'NÃO ATENDE ÀS VERIFICAÇÕES REALIZADAS',
    'ENGINEERING_MODEL_PENDING': 'VERIFICAÇÃO COMPLEMENTAR PENDENTE',
    'COMPLETE_LOCAL_CHECKS_PASS_WITHIN_SCOPE': 'ATENDE ÀS VERIFICAÇÕES NO DOMÍNIO R017',
    'COMPLETE_LOCAL_CHECKS_PASS_WITH_PRESET_DEVIATION': 'ATENDE NO DOMÍNIO · DETALHE DIFERE DO PRESET R017',
}


def _draft_keys():
    keys = ['ca_' + f.name for f in fields(CopedDoubleAngle) if f.name not in ('beam', 'support')]
    keys += ['ca_' + key for key in LOAD_KEYS.values()]
    for role in ('beam', 'support'):
        keys += ['ca_' + role + '_' + key for key in ('name', 'manual_name', 'family', 'source') + PROFILE_VALUES]
    return keys + angle_catalog_draft_keys('ca_')


def _widget_number(value, field):
    converted = float(value)
    if not math.isfinite(converted) or converted != value:
        raise ValueError(f'{field}: valor {value!r} não representável sem alteração '
                         'no controle numérico de precisão binária de 64 bits.')
    return converted


def seed(c):
    """Stage every conversion before changing the accepted project or report."""
    c.to_dict()
    proposed = {}
    for f in fields(c):
        if f.name not in ('beam', 'support'):
            value = getattr(c, f.name)
            if f.type in (float, 'float'):
                _widget_number(value, f.name)
            proposed['ca_' + f.name] = value
    for key, unit in LOAD_UNITS.items():
        proposed['ca_' + LOAD_KEYS[key]] = getattr(c, key) / unit
    for role in ('beam', 'support'):
        p = getattr(c, role)
        prefix = 'ca_' + role + '_'
        proposed[prefix + 'name'] = p.name if p.name in P and p == P[p.name] else CUSTOM
        proposed[prefix + 'manual_name'] = p.name
        proposed[prefix + 'family'] = p.family
        proposed[prefix + 'source'] = p.source
        for key in PROFILE_VALUES:
            proposed[prefix + key] = _widget_number(getattr(p, key), role + '.' + key)
    s = st.session_state
    for key, value in proposed.items():
        s[key] = value
    reset_angle_catalog('ca_')
    s.pop('ca_report', None)
    s.pop('_coped_double_angle_ui_draft', None)


def use_example():
    seed(PRESETS[st.session_state.ca_example])


def load_project():
    try:
        upload = st.session_state.ca_upload
        if upload is None:
            raise ValueError('Selecione um arquivo JSON.')
        if len(upload.getvalue()) > 200000:
            raise ValueError('Arquivo maior que 200 kB.')
        seed(CopedDoubleAngle.from_dict(json.loads(upload.getvalue())))
        st.session_state.pop('ca_import_error', None)
    except (ValueError, TypeError, KeyError, OverflowError) as exc:
        st.session_state.ca_import_error = 'Não foi possível abrir: ' + str(exc)


def bolt_changed():
    hole = HOLES.get(st.session_state.ca_db)
    if hole is not None:
        st.session_state.ca_hole_diameter = hole


def _select(label, options, key, labels=None, **kwargs):
    """Keep unsupported imported enum values visible, never silently normalize."""
    options = list(options)
    current = st.session_state.get(key)
    if current is not None and current not in options:
        options.append(current)
    if labels:
        kwargs['format_func'] = lambda value: labels.get(value, str(value) + ' · valor importado')
    return st.selectbox(label, options, key=key, **kwargs)


def _minimum(key, minimum):
    """Preserve legitimate imported dimensions below the normal display bound."""
    value = st.session_state.get(key)
    return min(minimum, float(value)) if _finite(value) else minimum


def _dimension(key, label, minimum=.01):
    return st.number_input(label + ' (mm)', min_value=_minimum('ca_' + key, minimum), key='ca_' + key)


def _profile(role, label):
    prefix = 'ca_' + role + '_'
    name = st.selectbox(label, [CUSTOM] + list(P), key=prefix + 'name')
    if name in P:
        p = P[name]
    else:
        with st.expander('Geometria personalizada · ' + label, expanded=True):
            designation = st.text_input('Designação · ' + label, key=prefix + 'manual_name')
            family = st.text_input('Família declarada · ' + label, key=prefix + 'family')
            values = {}
            for key, text in [('d', 'Altura d (mm)'), ('bf', 'Largura bf (mm)'),
                              ('tw', 'Alma tw (mm)'), ('tf', 'Mesa tf (mm)'),
                              ('clear', 'Altura livre das raízes (mm)'), ('area', 'Área A (mm²)'),
                              ('mass', 'Massa linear (kg/m)')]:
                values[key] = st.number_input(text + ' · ' + label, min_value=_minimum(prefix + key, .01), key=prefix + key)
            source = st.text_input('Fonte das dimensões/área · ' + label, key=prefix + 'source')
            p = Profile(designation, family, source=source, **values)
    st.caption(f'{label}: d={p.d:g}; bf={p.bf:g}; tw={p.tw:g}; tf={p.tf:g} mm; A={p.area:g} mm².')
    return p


def _force(key):
    """Preserve original JSON loads exactly until their display value is edited."""
    raw = st.session_state['ca_' + key]
    displayed = st.session_state['ca_' + LOAD_KEYS[key]]
    unit = LOAD_UNITS[key]
    if not _finite(raw) or not _finite(displayed):
        raise ValueError(f'{key}: número finito obrigatório.')
    if displayed == raw / unit:
        return raw
    converted = displayed * unit
    if not _finite(converted):
        raise ArithmeticError(f'{key}: a conversão da ação finita informada excedeu a faixa '
                              'numérica de cálculo em N ou N·mm.')
    return converted


def _finite(value):
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        return False
    try:
        return math.isfinite(value)
    except (OverflowError, ValueError):
        return False


def _kgf(value):
    return value / KGF if _finite(value) else None


def _display(value):
    return number(value, 3) if _finite(value) else '—'


def _checks_table(checks):
    rows = []
    for check in checks:
        rows.append({
            'ID': check.get('id', ''), 'Componente': component_label(check.get('component', '')),
            'Verificação': check_label(check),
            'Solicitação real (kgf)': _kgf(check.get('actual_demand_N')),
            'Solicitação adotada (kgf)': _kgf(check.get('demand_N')),
            'Resistência (kgf)': _kgf(check.get('design_capacity_N')),
            'Índice real': check.get('actual_utilization'), 'Índice adotado': check.get('utilization'),
            'Resultado real': state_label(check.get('actual_status')),
            'Resultado adotado': state_label(check.get('status')),
            'Sentido': direction_label(check.get('loaded_direction', 'direction_independent')),
            'Fórmula': check.get('formula', ''), 'Referência': check.get('reference', ''),
        })
    return pd.DataFrame(rows)


def _envelopes_table(envelopes):
    rows = []
    for envelope in envelopes:
        actual, adopted = envelope['actual_governing'], envelope['adopted_governing']
        rows.append({
            'Componente físico': envelope['component_label'], 'Mecanismo': envelope['mechanism_label'],
            'Solicitação real (kgf)': _kgf(actual['actual_demand_N']),
            'Resistência · ramo real (kgf)': _kgf(actual['design_capacity_N']),
            'Índice real': envelope['actual_utilization'],
            'Caso / sentido / ramo real': governing_description(actual),
            'Solicitação adotada (kgf)': _kgf(adopted['demand_N']),
            'Resistência · ramo adotado (kgf)': _kgf(adopted['design_capacity_N']),
            'Índice adotado': envelope['adopted_utilization'],
            'Caso / sentido / ramo adotado': governing_description(adopted),
            'Resultado real': state_label(envelope['actual_status']),
            'Resultado adotado': state_label(envelope['status']),
            'Falhas reais': envelope['actual_failure_count'],
            'Falhas adotadas': envelope['adopted_failure_count'],
            'Condição de contenção': envelope['restraint_condition'],
            'Ramos preservados': len(envelope['members']),
        })
    return pd.DataFrame(rows)


def _complete_checks(checks):
    required = {'id', 'component', 'actual_demand_N', 'demand_N', 'design_capacity_N',
                'actual_utilization', 'utilization', 'actual_status', 'status'}
    numeric = required - {'id', 'component', 'actual_status', 'status'}
    return bool(checks) and all(
        isinstance(row, dict) and required <= row.keys() and
        all(_finite(row[key]) for key in numeric) and
        row['actual_status'] in ('PASS', 'FAIL') and row['status'] in ('PASS', 'FAIL')
        for row in checks)


def _input_failure(s, status, exc):
    """Keep the failed current edit distinct from the preceding valid project."""
    s['_coped_double_angle_result'] = {
        'status': status, 'local_pass': False, 'global_pass': False, 'checks': [], 'summary': {},
        'geometry': {'valid': False},
        'issues': [{'severity': 'numerical_failure' if status == 'NUMERICAL_FAILURE' else 'invalid_input',
                    'text': str(exc)}],
    }
    st.error(STATUS[status])
    st.error(str(exc))
    st.caption('Nenhum resultado ou arquivo do cálculo anterior é válido para esta entrada. Corrija os dados para recalcular.')


def _approval_complete(result):
    """Require complete, input-bound local checks; this is no member approval."""
    blockers = {'invalid_input', 'numerical_failure', 'invalid_geometry', 'unsupported_scope', 'detail_fail',
                'engineering_pending', 'access_pending', 'error', 'pending', 'not_evaluated'}
    checks = result.get('checks') or []
    return (isinstance(result.get('inputs'), dict)
            and result.get('status') in ('COMPLETE_LOCAL_CHECKS_PASS_WITHIN_SCOPE', 'COMPLETE_LOCAL_CHECKS_PASS_WITH_PRESET_DEVIATION')
            and result.get('local_pass') is True
            and (result.get('geometry') or {}).get('valid') is True
            and (result.get('summary') or {}).get('complete_checks') is True
            and bool(checks) and all(isinstance(row, dict) and row.get('status') == 'PASS' for row in checks)
            and not any(isinstance(issue, dict) and issue.get('severity') in blockers for issue in (result.get('issues') or [])))


def render():
    # The boundary also covers profile construction and widget-derived values.
    # A failed current edit must never leave an older calculation eligible.
    try:
        _render()
    except (ArithmeticError, ValueError, TypeError, KeyError) as exc:
        s = st.session_state
        s.pop('ca_report', None)
        s.pop('_coped_double_angle_project', None)
        s['_coped_double_angle_ui_draft'] = {key: s[key] for key in _draft_keys() if key in s}
        failure = 'NUMERICAL_FAILURE' if isinstance(exc, ArithmeticError) else 'INVALID_INPUT'
        _input_failure(s, failure, exc)
        st.caption('Verificação global da viga de apoio e dos membros: EXTERNA.')
        st.button('Gerar memória R017', disabled=True, use_container_width=True)


def _render():
    from .coped_double_angle_drawing import image_bytes, drawing_svg
    from .coped_double_angle_report import create_report

    s = st.session_state
    saved = s.get('_coped_double_angle_project')
    draft = s.get('_coped_double_angle_ui_draft')
    # Retire old eligibility before conversion, construction or serialization.
    # Rejected imports and harmless reruns recover a report only after the
    # current inputs and canonical result reproduce its complete digest.
    prior_report = s.pop('ca_report', None)
    s.pop('_coped_double_angle_result', None)
    s.pop('_coped_double_angle_project', None)
    if 'ca_project' not in s:
        seed(CopedDoubleAngle.from_dict(saved) if saved else next(iter(PRESETS.values())))
        if draft:
            for key, value in draft.items():
                s[key] = value
    for key in _draft_keys():
        if key in s:
            s[key] = s[key]
    with st.sidebar:
        st.caption('Versão ' + VERSION + ' · cantoneiras duplas R017')
        st.selectbox('Exemplo de cantoneiras R017', list(PRESETS), key='ca_example')
        st.button('Usar exemplo R017', on_click=use_example, use_container_width=True)
        st.file_uploader('Abrir projeto R017', type=['json'], key='ca_upload')
        st.button('Carregar R017', on_click=load_project, use_container_width=True)
        if 'ca_import_error' in s:
            st.error(s.ca_import_error)
        st.divider()
        st.caption(BRAND)
        st.link_button('LinkedIn · Lucas Oliveira', LINK)
    st.title('Cantoneiras duplas · R017')
    st.caption('Viga com recortes superior e inferior → alma de viga de apoio perpendicular · duas cantoneiras · ambas as interfaces parafusadas')
    st.info('Domínio local: par simétrico convencional, V estático, recortes iguais e rasos. Componentes conforme NBR atual; estabilidade do recorte pelo modelo complementar Gerdau/AISC, com contenção externa documentada.')
    st.text_input('Identificação do projeto R017', key='ca_project')
    left, right = st.columns([.85, 1.5], gap='large')
    with left:
        beam = _profile('beam', 'Viga apoiada W')
        support = _profile('support', 'Viga de apoio W')
        st.number_input('Cortante Vsd já majorado, com sinal (kgf)', key='ca_V_kgf', format='%.2f')
        st.caption('V positivo para baixo. A inversão troca a borda livre carregada e a contenção necessária; V=0 exige ambas as contenções na conferência mínima.')
        load_convention_slot = st.empty()
        with st.expander('N, M e torção · ações fora do domínio R017'):
            st.number_input('Força axial N (kgf)', key='ca_N_kgf', format='%.2f')
            st.number_input('Momento M (kgf·m)', key='ca_M_kgfm', format='%.2f')
            st.number_input('Torção T (kgf·m)', key='ca_torsion_kgfm', format='%.2f')
        with st.expander('Recortes e interferência real', expanded=True):
            for key, label in [('c_top', 'Comprimento do recorte superior desde a ponta c sup'),
                               ('c_bottom', 'Comprimento do recorte inferior desde a ponta c inf'),
                               ('dc_top', 'Profundidade desde o topo da mesa superior dc sup'),
                               ('dc_bottom', 'Profundidade desde a base da mesa inferior dc inf'),
                               ('r_top', 'Raio do canto superior'), ('r_bottom', 'Raio do canto inferior')]:
                _dimension(key, label)
            _dimension('gap', 'Ponta da viga até a face da alma de apoio', 0.)
            st.number_input('Topo da viga abaixo do topo da viga de apoio (mm)', key='ca_beam_level')
            st.caption('R017 industrial: R15 nos dois cantos. Comprimentos e profundidades seguem a interferência real; raio mínimo Gerdau é uma recomendação distinta. Alterar qualquer recorte recalcula resistência e estabilidade.')
        with st.expander('Geometria das duas cantoneiras', expanded=True):
            render_angle_catalog('ca_')
            for key, label in [('beam_leg', 'Aba junto à alma da viga apoiada'),
                               ('support_leg', 'Aba junto à alma da viga de apoio'),
                               ('t', 'Espessura da cantoneira'), ('length', 'Comprimento vertical da cantoneira')]:
                _dimension(key, label)
            if not s.ca_angle_catalog_id:
                _dimension('root_radius', 'Raio interno da cantoneira', 0.)
            _dimension('angle_top', 'Topo da cantoneira abaixo do topo da viga apoiada', 0.)
        with st.expander('Interface 1 · parafusos comuns à alma e às duas cantoneiras', expanded=True):
            st.number_input('Parafusos verticais na alma', min_value=1, max_value=20, key='ca_web_rows')
            st.number_input('Colunas de parafusos na aba da viga', min_value=1, max_value=20, key='ca_web_columns')
            for key, label in [('beam_gauge', 'Face da alma de apoio até o eixo dos parafusos comuns'),
                               ('web_pitch', 'Passo vertical na alma'),
                               ('web_end_top', 'Topo da cantoneira até o primeiro parafuso da alma')]:
                _dimension(key, label)
            st.caption('n parafusos comuns atravessam cantoneira–alma–cantoneira: dois planos de corte. A única alma da viga não é duplicada.')
        with st.expander('Interface 2 · parafusos de cada cantoneira à alma de apoio', expanded=True):
            st.number_input('Parafusos verticais por cantoneira no apoio', min_value=1, max_value=20, key='ca_support_rows')
            st.number_input('Colunas de parafusos por aba de apoio', min_value=1, max_value=20, key='ca_support_columns')
            for key, label in [('support_gauge', 'Face da alma da viga apoiada até a linha de apoio'),
                               ('support_pitch', 'Passo vertical no apoio'),
                               ('support_end_top', 'Topo da cantoneira até o primeiro parafuso de apoio')]:
                _dimension(key, label)
            st.caption('2n furos físicos na única alma de apoio; corte simples em cada parafuso. O contato usa tw do apoio, nunca tf. As concordâncias com mesas contínuas não são bordas livres.')
            st.checkbox('Alma e mesas contínuas: sem abertura, entalhe ou ligação sobreposta no entorno', key='ca_support_intact')
            st.checkbox('Acesso ao verso da alma para porcas e ferramenta verificado', key='ca_support_back_access')
            st.number_input('Excentricidade normal à alma para exportação ao apoio (mm)', key='ca_support_eccentricity')
            st.caption('Excentricidade não nula exige fechar o caminho do momento. A partilha V/2 entre cantoneiras não define as cortantes nos vãos da viga de apoio.')
        with st.expander('Contenção externa na raiz dos recortes', expanded=True):
            st.warning('Informar sistema físico, posição e referência de verificação independente de resistência e rigidez. Preencher texto não dimensiona uma contenção; esta memória adota a condição de contorno externa declarada.')
            for side, label in [('top', 'Superior'), ('bottom', 'Inferior')]:
                st.text_input(label + ' · sistema e ligação física da contenção', key='ca_restraint_' + side + '_system')
                st.text_input(label + ' · documento da verificação independente de resistência e rigidez', key='ca_restraint_' + side + '_ref')
                _dimension('restraint_' + side + '_x', label + ' · posição desde a face do apoio', 0.)
            st.caption('A posição deve coincidir com folga + comprimento do recorte aplicável. Superior para V>0; inferior para V<0; ambas para V=0. Não se presume contenção por laje, mesa contínua ou simples presença das cantoneiras.')
        with st.expander('Furação, montagem e acesso'):
            _select('Diâmetro exato do parafuso (mm; métrico ou polegada)', list(HOLES), 'ca_db', on_change=bolt_changed)
            _select('Classe dos parafusos', list(BOLTS), 'ca_bolt')
            _dimension('hole_diameter', 'Diâmetro efetivo do furo')
            _select('Tipo de furo', ['standard_round', 'oversized_round', 'short_slot', 'long_slot'], 'ca_hole_type',
                    {'standard_round': 'Circular padrão', 'oversized_round': 'Circular alargado',
                     'short_slot': 'Alongado curto', 'long_slot': 'Alongado longo'})
            st.checkbox('Furo de broca documentado: sem acréscimo de 2 mm na dedução', key='ca_drilled')
            st.checkbox('Rosca excluída e documentada nos dois planos da alma', key='ca_web_threads_excluded')
            st.checkbox('Rosca excluída e documentada no plano do apoio', key='ca_support_threads_excluded')
            _dimension('fabrication_clearance', 'Folga adicional de fabricação', 0.)
            _dimension('tool_radius', 'Raio livre requerido para a ferramenta')
        with st.expander('Materiais, topologia e premissas'):
            for key, label in [('beam_steel', 'Aço da viga apoiada'), ('support_steel', 'Aço da viga de apoio'), ('angle_steel', 'Aço das cantoneiras')]:
                _select(label, [name for name, steel in STEELS.items() if steel.rolled_allowed], 'ca_' + key)
            _select('Exposição', ['painted', 'weathering'], 'ca_exposure', {'painted': 'Pintado / protegido', 'weathering': 'Aço patinável exposto'})
            _select('Interface física de apoio', ['beam_web', 'column_flange', 'column_web'], 'ca_kind',
                    {'beam_web': 'Alma de viga perpendicular · R017', 'column_flange': 'Mesa de pilar · fora deste domínio', 'column_web': 'Alma de pilar · fora deste domínio'})
            st.number_input('Quantidade real de cantoneiras', min_value=1, max_value=20, key='ca_angle_count')
            st.checkbox('Par de cantoneiras iguais, simétricas em relação à alma', key='ca_symmetric')
            _select('Recortes da viga', ['equal_double', 'top', 'bottom', 'none'], 'ca_cope',
                    {'equal_double': 'Superior e inferior iguais', 'top': 'Somente superior', 'bottom': 'Somente inferior', 'none': 'Sem recortes'})
            st.checkbox('Ações estáticas, sem impacto ou fadiga', key='ca_static')
            st.checkbox('Combinações últimas normais', key='ca_normal_combination')
            st.checkbox('Projeto exige resistência ao deslizamento', key='ca_no_slip_required')
        st.text_area('Observações e decisão do responsável técnico', key='ca_notes')

    values = {f.name: s['ca_' + f.name] for f in fields(CopedDoubleAngle)
              if f.name not in ('beam', 'support', *LOAD_UNITS)}
    c = CopedDoubleAngle(beam=beam, support=support, **{key: _force(key) for key in LOAD_UNITS}, **values)
    native = c.to_dict()
    encoded = json.dumps(native, ensure_ascii=False, indent=2, allow_nan=False)
    s['_coped_double_angle_ui_draft'] = {key: s[key] for key in _draft_keys() if key in s}
    with load_convention_slot.container():
        render_load_convention(st, 'coped_double_angle_r017', c.N)
    r = evaluate(c)
    digest = hashlib.sha256((encoded + json.dumps(r, ensure_ascii=False, sort_keys=True, allow_nan=False)).encode()).hexdigest()
    s['_coped_double_angle_project'] = native
    if prior_report and prior_report[0] == digest:
        s['ca_report'] = prior_report
    s['_coped_double_angle_result'] = r
    checks = r.get('checks') or []
    complete_checks = _complete_checks(checks)
    status = r.get('status', 'ENGINEERING_MODEL_PENDING')
    geometry_valid = ((r.get('geometry') or {}).get('valid') is True
                      and status not in ('INVALID_INPUT', 'NUMERICAL_FAILURE'))
    with right:
        text = STATUS.get(status, status)
        if status in ('INVALID_INPUT', 'NUMERICAL_FAILURE', 'INVALID_GEOMETRY', 'DETAIL_FAIL', 'VERIFIED_SUBCHECK_FAIL'):
            st.error(text)
        elif _approval_complete(r):
            st.success(text + ' · LIGAÇÃO LOCAL')
        else:
            if status in ('COMPLETE_LOCAL_CHECKS_PASS_WITHIN_SCOPE', 'COMPLETE_LOCAL_CHECKS_PASS_WITH_PRESET_DEVIATION'):
                text = STATUS['ENGINEERING_MODEL_PENDING'] + ' · completude local não confirmada'
            st.warning(text)
        st.caption('Verificação global da viga de apoio e dos membros: EXTERNA. O resultado local não aprova o membro completo.')
        summary = r.get('summary') or {}
        load = r.get('load_model') or {}
        if summary:
            a, b = st.columns(2)
            a.metric('Índice com V real', _display(summary.get('actual_governing_utilization')))
            b.metric('Índice com ação adotada', _display(summary.get('governing_utilization')))
            st.caption('Vsd=' + _display(_kgf(load.get('Vsd_N', c.V))) + ' kgf; Vd adotado=' +
                       _display(_kgf(load.get('Vd_N'))) + ' kgf. Governa: ' + next((check_label(row) for row in checks if row.get('id') == summary.get('governing_check_id')),
                            str(summary.get('governing_label', 'não determinado'))))
        if geometry_valid:
            st.image(image_bytes(c, r), width='stretch')
        for issue in r.get('issues') or []:
            text = issue.get('text', str(issue)) if isinstance(issue, dict) else str(issue)
            severity = issue.get('severity', '') if isinstance(issue, dict) else ''
            if severity in ('invalid_input', 'numerical_failure', 'invalid_geometry', 'detail_fail', 'error'):
                st.error(text)
            elif severity in ('unsupported_scope', 'engineering_pending', 'access_pending', 'preset_deviation', 'warning'):
                st.warning(text)
            else:
                st.caption(text)
            if isinstance(issue, dict) and issue.get('reference'):
                st.caption(str(issue['reference']))
        exceptions = (r.get('geometry') or {}).get('table16_exceptions') or {}
        if exceptions:
            with st.expander('Nota da Tabela 16 · qualificação pelas verificações existentes', expanded=True):
                for field, exception in exceptions.items():
                    edge = 'Ponta real da viga' if field == 'beam_end_min' else 'Borda real do componente'
                    st.write(edge + ': ' + _display(exception.get('actual_edge_mm')) +
                             ' mm; valor tabulado: ' + _display(exception.get('table16_minimum_mm')) + ' mm.')
                    qualification = ('EXCEÇÃO DA NOTA DA TABELA 16 VERIFICADA' if exception.get('qualified') is True
                                     else 'EXCEÇÃO DA NOTA DA TABELA 16 NÃO VERIFICADA')
                    st.write(qualification)
                    st.caption(str(exception.get('reason', '')))
                    for path in exception.get('paths') or []:
                        case = {'Vpos': 'V > 0', 'Vneg': 'V < 0'}.get(path.get('case'), 'Sentido avaliado')
                        for key, label in [('bearing_governing', 'Contato / rasgamento'), ('block_governing', 'Bloco L')]:
                            governor = path.get(key)
                            if governor:
                                st.write(case + ' · ' + label + ': Sd=' + _display(governor.get('demand_N')) +
                                         ' N; Rd=' + _display(governor.get('design_capacity_N')) + ' N; ' +
                                         state_label(governor.get('status')) + '.')
                    st.caption(str(exception.get('reference', '')))
                st.json(exceptions, expanded=False)
        for key, title in [('cope', 'Seção reduzida, flexão e estabilidade do recorte'),
                           ('restraints', 'Condições de contorno externas declaradas'),
                           ('support_web', 'Uma alma de apoio · introdução local e escopo'),
                           ('load_model', 'Partilha, excentricidades e reação física exportada')]:
            if r.get(key):
                with st.expander(title):
                    st.json(r[key], expanded=False)
        st.caption(SCOPE)
        for exclusion in r.get('exclusions') or []:
            st.caption(exclusion)
    if checks and complete_checks:
        envelopes = physical_envelopes(r)
        st.subheader('Envelopes por componente físico e mecanismo')
        st.caption(f'{len(envelopes)} envelopes conservam os {len(checks)} ramos originais, sem somar resistências em série. '
                   'Máximos real e adotado são selecionados separadamente; empates e todos os casos constam no detalhamento.')
        st.caption(f"Falhas resistentes: {sum(e['actual_failure_count'] for e in envelopes)} reais; "
                   f"{sum(e['adopted_failure_count'] for e in envelopes)} com a ação adotada. "
                   'Contenções e verificação global permanecem externas.')
        st.dataframe(_envelopes_table(envelopes), hide_index=True, width='stretch')
        with st.expander('Governantes completos · casos reais, adotados e empates'):
            st.caption('Cada envelope conserva as testemunhas integrais dos governantes, seus empates e todos os ramos membros.')
            st.json(envelopes, expanded=False)
        with st.expander('Todas as verificações primitivas · IDs, fórmulas e referências'):
            st.caption('Inclui cada furo, soma normativa, prefixo de bloco e sentido, sem redistribuição plástica implícita.')
            st.dataframe(_checks_table(checks), hide_index=True, width='stretch')
            for check in checks:
                st.write(str(check.get('id', '')) + ' · ' + check_label(check))
                formula = check.get('formula')
                if isinstance(formula, (dict, list)):
                    st.json(formula, expanded=False)
                elif formula is not None:
                    st.write(str(formula))
                st.caption(str(check.get('reference', '')))
            st.json(checks, expanded=False)
    elif checks:
        st.warning('Registros incompletos: não é possível formar envelopes ou emitir conclusão resistente.')
        with st.expander('Registros diagnósticos disponíveis'):
            st.json(checks, expanded=False)
    a, b, d = st.columns(3)
    a.download_button('Salvar projeto R017 .json', encoded, 'cantoneiras_duplas_R017.json', 'application/json')
    if geometry_valid:
        b.download_button('Baixar desenho R017 .svg', drawing_svg(c, r), 'cantoneiras_duplas_R017.svg', 'image/svg+xml')
    ready = complete_checks and geometry_valid and status not in ('INVALID_INPUT', 'NUMERICAL_FAILURE', 'INVALID_GEOMETRY', 'OUTSIDE_R017_SCOPE')
    if ready and not _approval_complete(r):
        st.caption('A memória registra resultados parciais, falhas e pendências. Sua emissão não representa aprovação da ligação.')
    if d.button('Gerar memória R017', disabled=not ready, use_container_width=True):
        s.ca_report = (digest, 'memoria_cantoneiras_duplas_R017.docx', create_report(c, r))
    if 'ca_report' in s:
        _, filename, payload = s.ca_report
        st.download_button('Baixar memória R017 .docx', payload, filename,
                           'application/vnd.openxmlformats-officedocument.wordprocessingml.document')
