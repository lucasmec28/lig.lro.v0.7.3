"""Proportional frozen-detail SVG; generated only from current valid geometry."""
from html import escape
from .welded_coverplate_splice import evaluate


def drawing_svg(c):
    r=evaluate(c)
    if r['status'] in ('INVALID_INPUT','OUTSIDE_QUALIFIED_SCOPE','DETAIL_FAIL','INVALID_RESTRAINT_INPUT') or not r['geometry']:
        raise ValueError('Desenho indisponível para geometria/domínio inválido.')
    g=r['geometry'];elements=[]
    def text(x,y,value,size=15):
        elements.append(f'<text x="{x}" y="{y}" font-size="{size}">{escape(str(value))}</text>')
    def line(x1,y1,x2,y2,color='#1f2937',width=2,dash=''):
        elements.append(f'<line x1="{x1:.3f}" y1="{y1:.3f}" x2="{x2:.3f}" y2="{y2:.3f}" stroke="{color}" stroke-width="{width}" stroke-dasharray="{dash}"/>')
    def rect(x,y,w,h,color):
        elements.append(f'<rect x="{x:.3f}" y="{y:.3f}" width="{w:.3f}" height="{h:.3f}" fill="{color}" stroke="#334155"/>')
    text(35,30,'Emenda com talas soldadas',23)
    text(35,55,'Detalhe local FR • x longitudinal • y vertical • z transversal às mesas')
    text(35,78,'Esquema da ligação; conferir com o projeto executivo. Cotas em mm.',13)
    length=max(g['flange_cover_length_mm'],g['web_cover_length_mm'])
    scale=min(650/(length+100),220/max(c.bf,c.d+2*c.flange_t))
    for kind,width,overlap,leg,basey,label in [('flange',c.flange_width,c.flange_overlap,c.flange_leg,260,'Planta da tala de mesa (x,z)'),('web',c.web_height,c.web_overlap,c.web_leg,585,'Vista lateral das talas de alma (x,y)')]:
        cx=390;cy=basey;plateL=c.gap+2*overlap
        text(35,basey-140,label,18)
        rect(cx-(length/2+45)*scale,cy-(c.bf if kind=='flange' else c.d)*scale/2,(length+90)*scale,(c.bf if kind=='flange' else c.d)*scale,'#edf1f5')
        rect(cx-c.gap*scale/2,cy-(c.bf if kind=='flange' else c.d)*scale/2,c.gap*scale,(c.bf if kind=='flange' else c.d)*scale,'white')
        rect(cx-plateL*scale/2,cy-width*scale/2,plateL*scale,width*scale,'#d7eaf5')
        for side in ('left','right'):
            for a,b in g['groups'][kind+'_'+side]:
                line(cx+a[0]*scale,cy-a[1]*scale,cx+b[0]*scale,cy-b[1]*scale,'#ad391d',4)
        line(cx,cy-125,cx,cy+125,'#64748b',1,'5,4')
        text(35,basey+140,f'L = {plateL:g}; largura/altura = {width:g}; sobreposição = {overlap:g}; filete s = {leg:g}',14)
        text(35,basey+162,f'Folga = {c.gap:g}; sem solda sobre a folga; grupos esquerdo e direito em série.',13)
        line(670,basey+115,730,basey+115);text(738,basey+120,'x')
        line(670,basey+115,670,basey+65);text(665,basey+57,'z' if kind=='flange' else 'y')
    text(790,120,'Seção transversal',18)
    sc=min(250/c.bf,260/(c.d+2*c.flange_t));cx=930;cy=310
    rect(cx-c.bf*sc/2,cy-c.d*sc/2,c.bf*sc,c.tf*sc,'#edf1f5')
    rect(cx-c.tw*sc/2,cy-(c.d/2-c.tf)*sc,c.tw*sc,(c.d-2*c.tf)*sc,'#edf1f5')
    rect(cx-c.bf*sc/2,cy+(c.d/2-c.tf)*sc,c.bf*sc,c.tf*sc,'#edf1f5')
    for sign in (-1,1):
        y=cy-c.d*sc/2-c.flange_t*sc if sign==1 else cy+c.d*sc/2
        rect(cx-c.flange_width*sc/2,y,c.flange_width*sc,c.flange_t*sc,'#d7eaf5')
        x=cx+c.tw*sc/2 if sign==1 else cx-c.tw*sc/2-c.web_t*sc
        rect(x,cy-c.web_height*sc/2,c.web_t*sc,c.web_height*sc,'#d7eaf5')
    line(1060,445,1110,445);text(1114,450,'z')
    line(1060,445,1060,390);text(1055,380,'y')
    text(790,490,f'dm = d + t = {g["dm_mm"]:g}',16)
    text(790,520,'N/2 + M/dm na tala superior',14)
    text(790,545,'N/2 − M/dm na tala inferior',14)
    text(790,570,'V/2 em cada tala de alma',14)
    text(790,595,'Alma: N = M = 0; sem Lb local',14)
    text(35,805,'Travamento das talas de mesa',19)
    y=836
    for side,label in [('top','Superior'),('bottom','Inferior')]:
        rec=getattr(c,side+'_restraint');state=r['restraints'].get(side,{})
        active=state.get('status')!='NOT_APPLICABLE_NO_COMPRESSION'
        text(35,y,f'{label}: Le normal = {rec.Le_normal_mm:g} mm (deslocamento y; flexão z); Le no plano = {rec.Le_in_plane_mm:g} mm (deslocamento z; flexão y).',14)
        text(35,y+22,'Le efetivo definido pelo projetista; não aplicar K novamente.' if active else 'Sem compressão nas combinações atuais: Le não aplicável.',13)
        y+=54
    text(35,965,'Soldas vermelhas são trechos reais. Verificar acesso da tala inferior e procedimento de soldagem.',13)
    text(35,988,'Estabilidade global da viga/pilar é pré-requisito externo, não resultado numérico deste módulo.',13)
    return '<svg xmlns="http://www.w3.org/2000/svg" width="1180" height="1020" viewBox="0 0 1180 1020"><rect width="1180" height="1020" fill="white"/><g font-family="DejaVu Sans,Arial" fill="#111827">'+''.join(elements)+'</g></svg>'
