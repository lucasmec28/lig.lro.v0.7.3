"""Nominal external-row plate components, not a constructed membrane field.

SCI P398 base Steps 3/4 and P207 6.8 establish the nominal component route.
The finite geometric contract is intentionally narrower than arbitrary plates.
L below is the physical length of a net-section cut, NEVER a P358 support hp.
"""
import math
from .models import finite_real
from .direct_plate_transfer import _check,three_state_contract

REF_NOMINAL='SCI P398 pp.64,70–72; SCI P207 6.8 for verified normal stiffener components'
REF_SHEAR='NBR8800:2024 corrigida2025 6.5.5; actual side-band gross/net cut'
REF_BLOCK='EN1993-1-8 3.10.2(3); gamma_M0=1.00, gamma_M2,plate=1.25; conservative c=0.5'


def thick_basal_plate_scope(*,B,t,fy,a,d,gauge,ex,flange_weld_leg,rod_fu,rod_As):
    """Optional application envelope, NOT a new V capacity or actual Ti.

    P398 Table5.3 all actual patterns, with the unreduced nominal EN bolt
    tension target. kthread is deliberately NOT used to enlarge this scope.
    Ribs retain their full separately calculated benefit for actual N/M.
    """
    out=dict(method='optional_basal_plate_rod_governed_scope_v1',qualifies=False,
             status='outside_optional_app_scope',normative_requirement=False,
             inference_T_capacity_implies_V_capacity=False,changes_actual_Ti=False,
             rib_normal_benefit_removed=False,reference='SCI P398 pp.70–71 Table5.3; conservative application envelope selected by this app')
    if (any(not finite_real(x) or x<=0 for x in (B,t,fy,a,d,gauge,ex,rod_fu,rod_As))
            or not finite_real(flange_weld_leg) or flange_weld_leg<0):
        out['reason']='Dados do envelope opcional indisponíveis.';return out
    mx=a-d/2-.8*flange_weld_leg;e=(B-gauge)/2
    if mx<=0 or e<=0:
        out['reason']='mx ou e reais não positivos no padrão P398.';return out
    nc=dict(single_curvature=B/2,individual_end=4*mx+1.25*ex,
            corner_outer=2*mx+.625*ex+e,group_end=2*mx+.625*ex+gauge/2)
    cp=dict(individual_circular=2*math.pi*mx,individual_end=math.pi*mx+2*e)
    leff=min(*nc.values(),*cp.values());rd=.5*leff*t*t*fy/mx
    target=2*.9*rod_fu*rod_As/1.25;ok=rd>=target-1e-8
    out.update(qualifies=ok,status='within_optional_app_scope' if ok else 'outside_optional_app_scope',
        mx_mm=mx,e_mm=e,ex_mm=ex,noncircular_leff_mm=nc,circular_leff_mm=cp,leff_mm=leff,
        gamma_M0=1.,gamma_M2_rod_reference=1.25,kthread_reference=1.,
        basal_plate_capacity_N=rd,reference_rod_pair_N=target,scope_ratio=target/rd,
        reason='Ramo nominal delimitado por placa basal isolada capaz da dupla nominal de hastes; não é ação real nem capacidade de V.' if ok else
               'Fora do ramo opcional de placa basal robusta. Não demonstra falha física e não invalida o benefício N/M das nervuras; outra qualificação de aplicabilidade é necessária.')
    return out


def external_plate_components(*,L,B,t,d,bf,tw,a,gauge,d0,fy,fu,V,states,source_half_width,
                              plate_monolithic=True,flange_weld_leg=None,rod_fu=None,rod_As=None,washer_width=None):
    out=dict(method='p398_external_nominal_v1',complete=False,passes=None,status='outside_nominal_domain',
             reasons=[],checks=[],states=[],reference=REF_NOMINAL,
             physical_inputs=dict(L=L,B=B,t=t,d=d,bf=bf,tw=tw,a=a,gauge=gauge,d0=d0,fy=fy,fu=fu,V=V,
                                  source_half_width=source_half_width,plate_monolithic=plate_monolithic,washer_width=washer_width),
             factors=dict(gamma_a1_shear=1.1,gamma_a2_shear=1.35,gamma_M0_block=1.,gamma_M2_block=1.25),
             assumptions=['V integral na fonte real da alma; nenhuma força horizontal atribuída às mesas/nervuras.',
                          'Composição nominal publicada, com verificações N/M e interações específicas preservadas.',
                          'Cortes líquidos e blocos reais complementares; L não é hp nem largura efetiva de apoio.'])
    vals=(L,B,t,d,bf,tw,a,gauge,d0,fy,fu)
    if (any(not finite_real(x) or not 0<x<=1e7 for x in vals) or not finite_real(V) or abs(V)>1e15
            or not finite_real(source_half_width) or source_half_width<tw/2 or fy>fu):
        out['reasons'].append('Dimensões, materiais, fonte ou ações inválidos.');return out
    b=gauge/2;ex=L/2-a;ey=B/2-b
    out['geometry']=dict(L_mm=L,B_mm=B,t_mm=t,a_mm=a,b_mm=b,gauge_mm=gauge,ex_mm=ex,ey_mm=ey,d0_mm=d0,
                         flange_tip_limit_mm=bf/2,source_half_width_mm=source_half_width)
    if plate_monolithic is not True:
        out['reasons'].append('Placa monolítica íntegra obrigatória no domínio nominal.');return out
    if (a<=d/2 or B<bf or gauge>bf+1e-9 or ex<1.2*d0-1e-9 or ey<1.2*d0-1e-9
            or 2*a<2.2*d0-1e-9 or gauge<2.4*d0-1e-9 or b-d0/2<=source_half_width):
        out['reasons'].append('Domínio nominal externo: uma linha por lado além das mesas, eixos dentro das pontas das mesas (P398p70), mínimos EN e bandas sem fonte horizontal. Fora do domínio não significa falha física.');return out
    # Physical contours, not just the hinge distance mx or bolt centre.
    if finite_real(flange_weld_leg) and flange_weld_leg>=0 and a-d/2-flange_weld_leg-d0/2<=0:
        out['reasons'].append('Contorno real do furo intercepta/toca a mesa ou seu filete físico. mx positivo não substitui esta verificação.');return out
    if washer_width is not None:
        if not finite_real(washer_width) or washer_width<=d0:
            out['reasons'].append('Largura física da arruela superior deve exceder o furo real da placa; cobertura axial não pode ser presumida.');return out
        if finite_real(flange_weld_leg) and (a-d/2-flange_weld_leg-washer_width/2<0 or min(ex,ey)<washer_width/2):
            out['reasons'].append('Arruela superior intercepta a mesa/filete físico ou ultrapassa a placa. Sua função somente axial não elimina a interferência geométrica.');return out
    expected={(x,y) for x in (-a,a) for y in (-b,b)}
    if not three_state_contract(states,V):
        out['reasons'].append('Exigem-se os três estados únicos e suas distribuições reais: uniforme, linha dianteira e envelope oposto.');return out
    for state in states:
        rods=state.get('rods',[])
        if len(rods)!=4 or {(r.get('x'),r.get('y')) for r in rods}!=expected or len({r.get('id') for r in rods})!=4:
            out['reasons'].append('Quatro furos reais devem corresponder à malha externa simétrica.');return out
        if any(not finite_real(r.get('shear')) or r['shear']<0 for r in rods):
            out['reasons'].append('Qi reais não negativos obrigatórios.');return out
        if not math.isclose(sum(r['shear'] for r in rods),abs(V),rel_tol=1e-9,abs_tol=1e-8):
            out['reasons'].append('V integral não equilibrado pelo estado.');return out
        if any(not math.isclose(sum(r['shear'] for r in rods if r['y']==y),abs(V)/2,rel_tol=1e-9,abs_tol=1e-8) for y in (-b,b)):
            out['reasons'].append('Estado sem simetria transversal de V/2 por banda.');return out
    s=1 if V>=0 else -1;Ant=t*(ey-d0/2)
    for state in states:
        checks=[];bands=[];prefixes=[]
        for y in (-b,b):
            rods=sorted((r for r in state['rods'] if r['y']==y),key=lambda r:s*r['x'])
            q=sum(r['shear'] for r in rods);Agv=L*t;dnet=d0+2.;Anv=(L-2*dnet)*t
            band=dict(side_y_mm=y,ids=[r['id'] for r in rods],Agv_mm2=Agv,Anv_mm2=Anv,demand_N=q,
                      horizontal_source_N=0.,cut_length_mm=L,inactive_holes_retained=True,
                      nbr_net_hole_deduction_mm=dnet,nbr_extra_hole_deduction_mm=2.,
                      net_hole_reference='NBR8800 5.2.4.1(a); +2mm conservatively, drilling not presumed')
            for mode,rd in [('gross',.6*fy*Agv/1.1),('net',.6*fu*Anv/1.35)]:
                checks.append(_check(state['id']+'_band_'+str(y)+'_'+mode,'Banda lateral real — cisalhamento '+mode,q,rd,REF_SHEAR,**band))
            bands.append(band)
            for n in (1,2):
                selected=rods[:n];lv=L/2+s*selected[-1]['x'];anv=t*(lv-(n-.5)*d0)
                qi=sum(r['shear'] for r in selected);rd=.5*fu*Ant/1.25+fy*anv/math.sqrt(3.)
                rec=dict(side_y_mm=y,ids=[r['id'] for r in selected],m=n,loaded_edge='x-' if s>0 else 'x+',
                         lv_mm=lv,Agv_mm2=t*lv,Anv_mm2=anv,Ant_mm2=Ant,tension_coefficient=.5,
                         inactive_holes_retained=True,forces_N={r['id']:r['shear'] for r in selected})
                ck=_check(state['id']+'_block_'+str(y)+'_'+str(n),'Bloco lateral real — '+','.join(rec['ids']),qi,rd,REF_BLOCK,sufficient=True,**rec)
                checks.append(ck);prefixes.append(ck)
        # Only the external row pulled AWAY from the central source produces
        # this whole-plate tension cut. The opposite row is not relabelled as
        # tension and does not acquire a fictitious compression-member model.
        pulled=[r for r in state['rods'] if s*r['x']<0]
        tension=sum(r['shear'] for r in pulled);Ag=B*t;An=(B-2*d0)*t
        normal=dict(ids=[r['id'] for r in pulled],loaded_edge='x-' if s>0 else 'x+',
                    demand_N=tension,Ag_mm2=Ag,An_mm2=An,horizontal_source_N=0.)
        normal_ref='EN1993-1-1 6.2.3; actual external tension cut; gamma_M0=1.00, gamma_M2=1.25'
        for mode,rd in [('gross',fy*Ag),('net',.9*fu*An/1.25)]:
            checks.append(_check(state['id']+'_normal_'+mode,'Seção normal externa tracionada — '+mode,tension,rd,normal_ref,**normal))
        double_anv=2*t*(ex-d0/2);double_ant=t*(gauge-d0)
        rd=.5*fu*double_ant/1.25+fy*double_anv/math.sqrt(3.)
        double=_check(state['id']+'_double_block','Bloco da dupla externa tracionada',tension,rd,REF_BLOCK,sufficient=True,
                      ids=normal['ids'],loaded_edge=normal['loaded_edge'],Anv_mm2=double_anv,Ant_mm2=double_ant,
                      tension_coefficient=.5,inactive_holes_retained=True)
        checks.append(double)
        out['states'].append(dict(id=state['id'],bands=bands,prefixes=prefixes,normal_cut=normal,double_block=double,
                                  checks=checks,passes=all(x['passes'] for x in checks)))
        out['checks'].extend(checks)
    envelope=thick_basal_plate_scope(B=B,t=t,fy=fy,a=a,d=d,gauge=gauge,ex=ex,
        flange_weld_leg=flange_weld_leg,rod_fu=rod_fu,rod_As=rod_As)
    out['application_envelope']=envelope
    out['complete']=envelope['qualifies'] and washer_width is not None
    if washer_width is None:out['reasons'].append('Contorno da arruela superior não informado para completar a aplicabilidade física.')
    if not envelope['qualifies']:out['reasons'].append(envelope['reason'])
    passed=all(x['passes'] for x in out['checks'])
    out['passes']=passed
    out['status']=('pass' if passed else 'fail' if any(not x['passes'] and not x.get('sufficient_bound') for x in out['checks'])
                   else 'sufficient_bound_exceeded') if out['complete'] else 'outside_optional_app_scope'
    return out
