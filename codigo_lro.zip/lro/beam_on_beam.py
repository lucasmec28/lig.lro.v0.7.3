"""Beam-on-beam bearing seat: independent, explicitly incomplete local family.

Canonical N/mm/MPa. No load amplification. Missing local equilibrium or prying
information is unknown, never zero. Global member stability is outside scope.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict, fields, replace
import math
from .models import Profile, profiles, STEELS, BOLTS, finite_real
from .double_angle import HOLES, EDGES, bolt_shear_resistance, bearing_resistance, GAMMA_A1, GAMMA_A2
from .local_checks import grip_factor
from .welded_support_single_angle import hardware_envelope

FAMILY = 'Viga sobre viga · chapa de apoio contínua'
CONNECTION_TYPE = 'beam_on_beam_bearing_plate'
COMPONENT_VERSION = '0.9.44-beam-on-beam-partial-dev'
NBR = 'ABNT NBR 8800:2024, Errata 1:2025'
SCOPE = ('Vigas W ortogonais: uma chapa contínua sob a mesa inferior da viga superior, '
         'soldada à viga superior e fixada por quatro parafusos à mesa superior da viga inferior. '
         'V descendente por contato; N no eixo da viga superior por corte simples nos parafusos. '
         'Verificações parciais locais, sem aprovação da ligação completa.')
EXCLUSIONS = [
    'Não aprova fabricação, montagem, estabilidade ou resistência global das vigas e do pórtico.',
    'Não atribui V ao corte dos parafusos nem usa atrito/protensão como resistência.',
    'Contato, tração dos parafusos, alavanca, chapa, soldas e regiões locais das vigas exigem fechamento conjunto explícito.',
    'Somente ELU estático normal, sem torção aplicada, grupo simétrico 2×2 e uma interface de corte.',
]

@dataclass(frozen=True)
class BeamOnBeam:
    beam: Profile
    support: Profile
    project: str = 'W360 sobre W410 · apoio com chapa contínua'
    plate_length: float = 140.
    plate_width: float = 260.
    tp: float = 10.
    bolt_pitch: float = 80.
    bolt_gauge: float = 200.
    db: float = 16.
    hole_diameter: float = 18.
    bolt: str = 'ASTM F3125 A325'
    threads_excluded: bool = False
    drilled: bool = False
    beam_steel: str = 'ASTM A572 Gr.50'
    support_steel: str = 'ASTM A572 Gr.50'
    plate_steel: str = 'ASTM A36'
    stiffener_steel: str = 'ASTM A36'
    weld_leg: float = 6.
    weld_length: float = 128.
    electrode_fuw: float = 485.
    stiffeners: bool = True
    stiffener_t: float = 6.
    stiffener_width: float = 60.
    stiffener_height: float = 381.4
    stiffener_clip: float = 20.
    stiffener_weld: float = 5.
    stiffener_y: float = 0.
    V: float = 25595.3565
    N: float = 9806.65
    applied_moment_y: float = 0.
    torsion: float = 0.
    reference_x: float | None = None
    contact_resultant: float | None = None
    contact_x: float | None = None
    contact_y: float | None = None
    support_root_radius: float | None = None
    support_end_negative: float | None = None
    support_end_positive: float | None = None
    bolt_tension_1: float | None = None
    bolt_tension_2: float | None = None
    bolt_tension_3: float | None = None
    bolt_tension_4: float | None = None
    tensions_include_prying: bool = False
    external_same_case: bool = False
    local_model_reference: str = ''
    tool_radius: float | None = None
    fabrication_clearance: float = 0.
    static: bool = True
    normal_combination: bool = True
    no_slip_required: bool = False
    notes: str = 'N=1000 kgf é hipótese artificial de reserva; esforço real próximo de zero.'

    @property
    def fixed_assumptions(self):
        return dict(physical_plates=1,physical_bolts=4,bolt_shear_planes=1,
                    bolts='symmetric_2_by_2_no_applied_torsion',vertical_load_path='bearing_not_bolt_shear',
                    load_reference='upper_beam_axis_at_declared_x',
                    coordinates='x_upper_axis_y_lower_axis_z_up_from_lower_top_flange',
                    transport='My=N*(beam.d/2+tp)+V*reference_x+applied_moment_y',
                    contact_equilibrium='C-sum(T)=V; C*xc-sum(T_i*x_i)=My; C*yc-sum(T_i*y_i)=0',
                    unknowns='None_is_unknown_never_zero',global_stability='outside_scope',
                    gamma_a1=GAMMA_A1,gamma_a2=GAMMA_A2)

    def to_dict(self):
        errors=input_errors(self)
        if errors: raise ValueError('; '.join(errors))
        return dict(schema_version=1,connection_type=CONNECTION_TYPE,component_version=COMPONENT_VERSION,
                    connection=asdict(self),units=dict(force='N',length='mm',stress='MPa',moment='N mm'),
                    fixed_assumptions=self.fixed_assumptions)

    @classmethod
    def from_dict(cls,data):
        keys={'schema_version','connection_type','component_version','connection','units','fixed_assumptions'}
        if not isinstance(data,dict) or set(data)!=keys: raise ValueError('Projeto: campos ausentes ou desconhecidos.')
        if type(data['schema_version']) is not int or data['schema_version']!=1 or data['connection_type']!=CONNECTION_TYPE or data['component_version']!=COMPONENT_VERSION:
            raise ValueError('Família ou versão de projeto incompatível.')
        raw=data['connection']
        if not isinstance(raw,dict) or set(raw)!={f.name for f in fields(cls)}: raise ValueError('Entrada incompleta ou desconhecida.')
        raw=dict(raw)
        for key in ('beam','support'):
            if not isinstance(raw[key],dict) or set(raw[key])!={f.name for f in fields(Profile)}: raise ValueError('Perfil incompleto.')
            raw[key]=Profile(**raw[key])
        c=cls(**raw); canonical=c.to_dict()
        if any(data[k]!=canonical[k] for k in ('units','fixed_assumptions')): raise ValueError('Unidades ou premissas incompatíveis.')
        return c

OPTIONAL={'reference_x','contact_resultant','contact_x','contact_y','support_root_radius','support_end_negative','support_end_positive','bolt_tension_1','bolt_tension_2','bolt_tension_3','bolt_tension_4','tool_radius'}
SIGNED={'V','N','applied_moment_y','torsion','reference_x','contact_x','contact_y','stiffener_y'}
BOOLS={'threads_excluded','drilled','stiffeners','tensions_include_prying','external_same_case','static','normal_combination','no_slip_required'}
STRINGS={'project','bolt','beam_steel','support_steel','plate_steel','stiffener_steel','local_model_reference','notes'}

def input_errors(c):
    if not isinstance(c,BeamOnBeam): return ['Entrada deve ser BeamOnBeam.']
    errors=[]
    for f in fields(c):
        k=f.name;v=getattr(c,k)
        if k in ('beam','support'):
            if not isinstance(v,Profile): errors.append(k+': perfil obrigatório.');continue
            for n in ('d','bf','tw','tf','clear','area','mass'):
                if not finite_real(getattr(v,n)) or getattr(v,n)<=0:errors.append(k+'.'+n+': positivo finito obrigatório.')
            for n in ('name','family','source'):
                if not isinstance(getattr(v,n),str):errors.append(k+'.'+n+': texto obrigatório.')
        elif k in STRINGS:
            if not isinstance(v,str):errors.append(k+': texto obrigatório.')
        elif k in BOOLS:
            if type(v) is not bool:errors.append(k+': booleano obrigatório.')
        elif k in OPTIONAL and v is None:pass
        elif not finite_real(v):errors.append(k+': número finito obrigatório.')
        elif k not in SIGNED and (v<0 if k in OPTIONAL|{'fabrication_clearance','stiffener_clip'} else v<=0): errors.append(k+': dimensão ou força inválida.')
    return errors


def presets():
    p=profiles();c=BeamOnBeam(p['W 360 x 39,0'],p['W 410 x 38,8'])
    return {'Caso informado · V=2610 kgf e N=1000 kgf · modelo local pendente':c,
            'Adverso · N elevado · sem aprovação completa':replace(c,N=300000.)}


def bolt_coordinates(c):
    return [(-c.bolt_pitch/2,-c.bolt_gauge/2),(c.bolt_pitch/2,-c.bolt_gauge/2),
            (-c.bolt_pitch/2,c.bolt_gauge/2),(c.bolt_pitch/2,c.bolt_gauge/2)]


def resolve_beam_seat_actions(c):
    """r × F transport from the upper centroid, in the explicitly declared axes."""
    h=c.beam.d/2+c.tp
    mn=c.N*h
    mv=None if c.reference_x is None else c.V*c.reference_x
    return dict(V_N=c.V,N_N=c.N,action_factor=1.,simultaneous=True,
                input_origin='Robot upper-axis end; N reserve identified separately in project notes',
                axes='x: eixo da superior; y: eixo da inferior; z: para cima',
                reference_x_mm=c.reference_x,upper_axis_height_mm=h,
                moment_from_N_Nmm=mn,moment_from_V_Nmm=mv,
                moment_at_contact_Nmm=None if mv is None else mn+mv+c.applied_moment_y,
                applied_moment_y_Nmm=c.applied_moment_y,torsion_Nmm=c.torsion,
                horizontal_bolt_shear_N=abs(c.N)/4 if c.torsion==0 else None,
                vertical_bolt_shear_N=0.,vertical_load_path='contato; V não é corte dos parafusos',
                inplane_group='quatro parafusos simétricos com mesma rigidez; um plano de corte',
                minimum_connection_strength='NBR 6.1.5.2: categoria/direção do mínimo ainda a definir; ações fornecidas não majoradas')


def _row(cid,name,demand=None,resistance=None,unit='N',reference='',equation='',notes='',category='RESISTANCE',status=None,**extras):
    eta=None
    if demand is not None and resistance is not None and resistance>0:
        eta=demand/resistance
    if status is None: status='PENDING' if eta is None else 'PASS' if eta<=1 else 'FAIL'
    return dict(id=cid,name=name,demand=demand,resistance=resistance,eta=eta,unit=unit,
                reference=reference,equation=equation,notes=notes,category=category,status=status,**extras)


def check_seat_fit(c):
    rows=[]; data=dict(bolt_coordinates_mm=bolt_coordinates(c),physical_plates=1,physical_bolts=4,
        plate_x_bounds_mm=[-c.plate_length/2,c.plate_length/2],plate_y_bounds_mm=[-c.plate_width/2,c.plate_width/2],
        grip_mm=c.tp+c.support.tf,tool_radius_mm=c.tool_radius,support_root_radius_mm=c.support_root_radius,
        physical_stiffeners=2 if c.stiffeners else 0)
    def bound(cid,name,value,limit,relation='>=',ref='',notes=''):
        ok=value>=limit if relation=='>=' else value<=limit if relation=='<=' else value>limit
        rows.append(_row(cid,name,value,limit,'mm',ref,relation,notes,'GEOMETRY','PASS' if ok else 'FAIL'))
    for role,p in [('upper',c.beam),('lower',c.support)]:
        bound(role+'_clear','Altura plana da alma · '+role,p.clear,p.d-2*p.tf,'<=')
        bound(role+'_flange','Largura da mesa · '+role,p.bf,p.tw,'>')
    bound('hole_diameter','Diâmetro físico do furo',c.hole_diameter,c.db,'>')
    if c.db in HOLES:
        bound('hole_standard','Máximo do furo-padrão',c.hole_diameter,HOLES[c.db],'<=',NBR+' tabela 14')
        emin=EDGES[c.db];tmin=min(c.tp,c.support.tf)
        for key,pitch in [('x',c.bolt_pitch),('y',c.bolt_gauge)]:
            bound('spacing_min_'+key,'Espaçamento mínimo '+key,pitch,max(2.7*c.db,c.hole_diameter+c.db),'>=',NBR+' 6.3.9')
            bound('spacing_max_'+key,'Espaçamento máximo '+key,pitch,min(24*tmin,300.),'<=',NBR+' 6.3.10','Contato contínuo e ambiente pintado; patinável exposto fora do domínio.')
        for key,edge,t in [('plate_x',(c.plate_length-c.bolt_pitch)/2,c.tp),('plate_y',(c.plate_width-c.bolt_gauge)/2,c.tp),('support_x',(c.support.bf-c.bolt_pitch)/2,c.support.tf)]:
            bound('edge_min_'+key,'Borda mínima · '+key,edge,emin,'>=',NBR+' tabela 16')
            bound('edge_max_'+key,'Borda máxima · '+key,edge,min(12*t,150.),'<=',NBR+' 6.3.12')
        hw=hardware_envelope(c.db);data['hardware_envelope']=hw;radius=hw['minimum_hardware_radius_mm']
        bound('hardware_upper_weld','Ferragem fora do pé da solda superior',c.bolt_gauge/2-c.beam.bf/2-c.weld_leg,radius+c.fabrication_clearance,ref=hw['source'])
        bound('hardware_lower_web','Ferragem fora da alma inferior',c.bolt_pitch/2-c.support.tw/2,radius+c.fabrication_clearance,ref=hw['source'])
        for key,dist in [('plate_x',(c.plate_length-c.bolt_pitch)/2),('plate_y',(c.plate_width-c.bolt_gauge)/2),('support_x',(c.support.bf-c.bolt_pitch)/2)]:
            bound('washer_edge_'+key,'Envelope da arruela na borda · '+key,dist,hw['washer_max_outside_mm']/2+c.fabrication_clearance,ref=hw['source'])
        if c.support_root_radius is None:
            rows.append(_row('root_clearance','Folga à concordância inferior',category='GEOMETRY',notes='Informar raio real e fonte; clear do catálogo não é tolerância fabril.'))
        else:
            bound('root_radius_positive','Raio real positivo da concordância W',c.support_root_radius,0.,'>')
            bound('hardware_lower_root','Ferragem fora da caixa de concordância inferior',c.bolt_pitch/2-c.support.tw/2-c.support_root_radius,radius+c.fabrication_clearance)
        if c.tool_radius is None:
            rows.append(_row('tool_access','Raio real da ferramenta de montagem',category='GEOMETRY',notes='Raio de ferramenta real não informado; envelope de ferragem não comprova montagem.'))
        else:
            bound('tool_hardware_floor','Ferramenta/envelope não inferior à ferragem',c.tool_radius,radius,ref=hw['source'])
            bound('tool_upper_weld','Ferramenta fora do pé da solda',c.bolt_gauge/2-c.beam.bf/2-c.weld_leg,c.tool_radius+c.fabrication_clearance)
            if c.support_root_radius is not None:
                bound('tool_lower_root','Ferramenta fora da concordância',c.bolt_pitch/2-c.support.tw/2-c.support_root_radius,c.tool_radius+c.fabrication_clearance)
    for key,distance in [('negative',c.support_end_negative),('positive',c.support_end_positive)]:
        if distance is None:
            rows.append(_row('support_end_'+key,'Extremidade física da viga inferior · '+key,category='GEOMETRY',notes='Distância ao cruzamento das almas não informada; verificar continuidade sob chapa e bordas reais.'))
        else:
            bound('support_plate_fit_'+key,'Mesa inferior contínua sob a chapa · '+key,distance,c.plate_width/2)
            if c.db in EDGES:bound('support_end_edge_'+key,'Borda física da mesa inferior · '+key,distance-c.bolt_gauge/2,EDGES[c.db],ref=NBR+' tabela 16')
    rows.append(_row('assembly_access','Comprimento de parafuso, engajamento, acesso axial e sequência de montagem',category='GEOMETRY',reference=NBR+' 6.3.1 e 6.8',notes='Raio de ferramenta/ferragem não comprova inserção axial, comprimento de porca/parafuso ou sequência real. Conferir detalhamento de montagem.'+(' A490 sob tração ou tração+corte exige protensão conforme 6.8; aperto simples não atende a essa condição.' if c.bolt=='ASTM F3125 A490' else '')))
    bound('plate_under_upper','Chapa cobre largura da mesa superior',c.plate_width,c.beam.bf+2*c.weld_leg)
    rows.append(_row('upper_end_weld_fit','Término físico da viga superior e posição dos filetes efetivos',category='GEOMETRY',notes='A referência das ações não é cota de término físico. Confirmar que ambas as linhas efetivas declaradas estão integralmente conectadas à mesa e à chapa.'))
    bound('weld_length_fit','Comprimento efetivo de solda cabe na chapa',c.weld_length,c.plate_length,'<=',notes='Término real da viga e comprimento efetivo permanecem declarados pelo responsável.')
    small=min(c.tp,c.beam.tf)
    wmin=3. if small<=6.3 else 5. if small<=12.5 else 6. if small<=19 else 8.
    bound('weld_min','Perna mínima do filete superior',c.weld_leg,wmin,ref=NBR+' tabela 11')
    bound('weld_max','Perna máxima na borda da mesa superior',c.weld_leg,c.beam.tf if c.beam.tf<6.3 else c.beam.tf-1.5,'<=',NBR+' 6.2.6.2.2','Sem exceção de borda reforçada.')
    bound('weld_longitudinal_end_length','Solda longitudinal de extremidade: comprimento ≥ espaçamento',c.weld_length,c.beam.bf,ref=NBR+' 6.2.6.2.3',notes='Filtro conservador para duas linhas longitudinais na transferência horizontal da mesa; sem qualificar shear lag integral.')
    bound('weld_length_min','Comprimento efetivo mínimo de cada linha',c.weld_length,max(4*c.weld_leg,40.),ref=NBR+' 6.2.6.2.3')
    bound('weld_length_domain','Limite de linha sem redução por comprimento',c.weld_length,100*c.weld_leg,'<=',NBR+' 6.2.2.2')
    data['valid']=not any(r['status']=='FAIL' for r in rows)
    return rows,data


def check_bolt_inplane_shear(c,valid_scope=True):
    fub=BOLTS[c.bolt];ab=math.pi*c.db**2/4;k=grip_factor(c.tp+c.support.tf,c.db)
    rv=bolt_shear_resistance(c.db,fub,c.threads_excluded,k)
    row=_row('bolt_horizontal_shear','Parafuso · corte horizontal por N',abs(c.N)/4 if valid_scope else None,rv,
        reference=NBR+' 6.3.3.2 e 6.3.7',equation='S=|N|/4; Rv=kpega·α·Ab·fub/γa2',
        notes='Uma interface; α=0,56 sem rosca ou 0,45 com rosca. V descendente transferido por contato. Não inclui tração/alavanca.',
        status=None if valid_scope else 'OUTSIDE_SCOPE',area_mm2=ab,grip_factor=k,alpha=.56 if c.threads_excluded else .45)
    return [row]


def check_hole_bearing_each_ply(c,valid_scope=True):
    rows=[];coords=bolt_coordinates(c);sign=1. if c.N>=0 else -1.
    for ply,t,fu,width,direction in [('plate',c.tp,STEELS[c.plate_steel].fu,c.plate_length,-sign),('lower_flange',c.support.tf,STEELS[c.support_steel].fu,c.support.bf,sign)]:
        for i,(x,y) in enumerate(coords,1):
            next_holes=[abs(x2-x)-c.hole_diameter for x2,y2 in coords if y2==y and direction*(x2-x)>0]
            edge=width/2-direction*x-c.hole_diameter/2
            lc=min([edge]+next_holes)
            rv=bearing_resistance(c.db,max(0.,lc),t,fu)
            rows.append(_row('hole_'+ply+'_'+str(i),'Contato no furo '+str(i)+' · '+ply,
                abs(c.N)/4 if valid_scope and lc>0 else None,rv,reference=NBR+' 6.3.3.3',
                equation='Fc,Rd=min(1,2·lf·t·fu;2,4·db·t·fu)/γa2',
                notes='Deformação em serviço limitada; sentido real desta peça, sem somar duas vezes ligamentos. Não é contato vertical.',
                status=('OUTSIDE_SCOPE' if not valid_scope else 'INVALID_GEOMETRY' if lc<=0 else None),
                clear_distance_mm=lc,load_direction_x=direction,thickness_mm=t,fu_MPa=fu))
    return rows


def check_weld_assigned_group(c,valid_scope=True):
    q=abs(c.N)/(2*c.weld_length);aw=c.weld_leg/math.sqrt(2)
    rows=[_row('weld_horizontal','Solda superior · somente parcela horizontal centrada',q if valid_scope else None,.6*c.electrode_fuw*aw/GAMMA_A2,'N/mm',
          NBR+' 6.2.5/tabela 9','q=|N|/(2Le); R=0,6·fuw·(w/√2)/γa2',
          'Duas linhas longitudinais simétricas. Sem crédito ao contato para N. Não aprova solda sob ação normal ou momento.',
          status=None if valid_scope else 'OUTSIDE_SCOPE',effective_total_length_mm=2*c.weld_length,throat_mm=aw)]
    for name,t,steel in [('upper_flange',c.beam.tf,STEELS[c.beam_steel]),('plate',c.tp,STEELS[c.plate_steel])]:
        for mode,cap in [('yield',.6*steel.fy*t/GAMMA_A1),('rupture',.6*steel.fu*t/GAMMA_A2)]:
            rows.append(_row('weld_base_'+name+'_'+mode,'Metal-base junto à solda · '+name+' · '+mode,q if valid_scope else None,cap,'N/mm',
                NBR+' tabela 9 e 6.5.5',('q=|N|/(2Le); R=0,6fy·t/γa1' if mode=='yield' else 'q=|N|/(2Le); R=0,6fu·t/γa2'),
                'Cada borda recebe N/2. Verificação local horizontal; não verifica seção integral, ruptura em bloco ou flexão.',
                status=None if valid_scope else 'OUTSIDE_SCOPE',thickness_mm=t))
    return rows


def check_stiffener_detail_only(c):
    rows=[]
    if not c.stiffeners:
        return [_row('stiffener_pair','Par inferior de enrijecedores obrigatório nesta família',0.,2.,'un',category='GEOMETRY',status='FAIL')]
    def check(cid,name,value,limit,relation='>=',ref=NBR+' 5.7.9.5'):
        ok=value>=limit if relation=='>=' else value>limit if relation=='>' else value<=limit if relation=='<=' else value<limit
        rows.append(_row(cid,name,value,limit,'mm',ref,relation,'Somente detalhamento; nenhuma resistência ou partilha V/2 creditada.','GEOMETRY','PASS' if ok else 'FAIL'))
    check('stiffener_width_min','Enrijecedor · largura mínima',c.stiffener_width+c.support.tw/2,c.support.bf/3)
    check('stiffener_t_min','Enrijecedor · espessura mínima',c.stiffener_t,max(c.support.tf/2,c.stiffener_width/16))
    check('stiffener_width_fit','Enrijecedor cabe sob a mesa inferior',c.stiffener_width,(c.support.bf-c.support.tw)/2,'<=','Geometria física')
    check('stiffener_height_fit','Enrijecedor cabe entre as mesas',c.stiffener_height,c.support.d-2*c.support.tf,'<=','Geometria física')
    check('stiffener_height_min','Extensão mínima do enrijecedor',c.stiffener_height,.75*(c.support.d-2*c.support.tf),ref=NBR+' 5.7.9.2')
    check('stiffener_station','Enrijecedores alinhados ao eixo da viga superior',abs(c.stiffener_y),0.,'<=','Domínio inicial simétrico; outro alinhamento precisa de modelo específico')
    check('stiffener_position','Par de enrijecedores sob a largura da mesa superior',abs(c.stiffener_y)+c.stiffener_t/2,c.beam.bf/2,'<=','Geometria física; não comprova alinhamento da resultante excêntrica')
    check('stiffener_clip_width','Recorte preserva largura positiva',c.stiffener_clip,c.stiffener_width,'<','Geometria física')
    check('stiffener_clip_height','Dois recortes cabem na altura',2*c.stiffener_clip,c.stiffener_height,'<','Geometria física')
    if c.support_root_radius is not None:check('stiffener_root_clip','Recorte afasta concordância inferior',c.stiffener_clip,c.support_root_radius,ref='Caixa conservadora de concordância')
    else:rows.append(_row('stiffener_root_clip','Recorte de concordância do enrijecedor',category='GEOMETRY',notes='Raio real não informado.'))
    minimum=min(c.stiffener_t,c.support.tw)
    wmin=3. if minimum<=6.3 else 5. if minimum<=12.5 else 6. if minimum<=19 else 8.
    check('stiffener_weld_min','Perna mínima dos filetes do enrijecedor',c.stiffener_weld,wmin,ref=NBR+' tabela 11')
    check('stiffener_weld_max','Filete na borda do enrijecedor',c.stiffener_weld,c.stiffener_t if c.stiffener_t<6.3 else c.stiffener_t-1.5,'<=',NBR+' 6.2.6.2.2')
    return rows


def check_bolt_tension_interaction_from_external(c,actions,valid_scope=True):
    """Check supplied same-case demands only after all three equilibrium equations.

    This does not derive prying, compatible contact or plate flexure. Even a
    perfectly equilibrated external set never closes the complete connection.
    """
    tensions=[getattr(c,'bolt_tension_'+str(i)) for i in range(1,5)]
    coords=bolt_coordinates(c);rows=[]
    state=dict(tensions_N=tensions,contact_resultant_N=c.contact_resultant,
               contact_centroid_mm=[c.contact_x,c.contact_y],equilibrium_checked=False,
               equilibrium_valid=False,prying_included=c.tensions_include_prying,
               same_case=c.external_same_case,reference=c.local_model_reference,
               compatibility_verified=False)
    required=[c.reference_x,c.contact_resultant,c.contact_x,c.contact_y]+tensions
    ready=all(x is not None for x in required) and c.tensions_include_prying and c.external_same_case and bool(c.local_model_reference.strip())
    if ready:
        C=c.contact_resultant;M=actions['moment_at_contact_Nmm']
        force=C-sum(tensions)-c.V
        moment_y=C*c.contact_x-sum(t*x for t,(x,y) in zip(tensions,coords))-M
        moment_x=C*c.contact_y-sum(t*y for t,(x,y) in zip(tensions,coords))
        force_tolerance=1e-8*max(1.,abs(C),abs(c.V),sum(tensions))
        moment_tolerance=1e-8*max(1.,abs(M),abs(C)*max(c.plate_length,c.plate_width),sum(tensions)*max(c.bolt_pitch,c.bolt_gauge))
        bounds=abs(c.contact_x)<=min(c.plate_length,c.support.bf)/2 and abs(c.contact_y)<=c.plate_width/2
        valid=C>0 and abs(force)<=force_tolerance and abs(moment_y)<=moment_tolerance and abs(moment_x)<=moment_tolerance and bounds
        state.update(equilibrium_checked=True,equilibrium_valid=valid,force_residual_N=force,
                     moment_y_residual_Nmm=moment_y,moment_x_residual_Nmm=moment_x,
                     force_tolerance_N=force_tolerance,moment_tolerance_Nmm=moment_tolerance,
                     centroid_inside_physical_contact=bounds)
        rows.append(_row('external_equilibrium','Equilíbrio das demandas externas C/T',category='MODEL',status='PASS' if valid else 'FAIL',
             reference='Equilíbrio estático; NBR 6.1.1.3 e 6.3.5.1',equation='C−ΣTi=V; Cxc−Σ(Tixi)=My; Cyc−Σ(Tiyi)=0',
             notes='Equilíbrio é necessário, mas não comprova compatibilidade, distribuição de pressão, flexão ou alavanca.',**{k:v for k,v in state.items() if 'residual' in k}))
    else:
        rows.append(_row('external_equilibrium','Equilíbrio das demandas externas C/T',category='MODEL',
             notes='Informar referencial x, C, xc, yc, Ti dos quatro parafusos, origem, mesmo caso simultâneo e inclusão explícita da alavanca.'))
    ab=math.pi*c.db**2/4;ft=.75*ab*BOLTS[c.bolt]/GAMMA_A2
    fv=bolt_shear_resistance(c.db,BOLTS[c.bolt],c.threads_excluded,grip_factor(c.tp+c.support.tf,c.db))
    usable=state['equilibrium_valid'] and valid_scope
    for i,t in enumerate(tensions,1):
        rows.append(_row('bolt_tension_'+str(i),'Parafuso '+str(i)+' · tração externa incluindo alavanca',t if usable else None,ft,
            reference=NBR+' 6.3.3.1',equation='Ft,Rd=0,75·Ab·fub/γa2',
            notes='Demanda fornecida pelo responsável, mesmo caso; não derivada automaticamente da geometria.',
            supplied_demand_N=t))
        eta=None if not usable else (t/ft)**2+(abs(c.N)/4/fv)**2
        rows.append(_row('bolt_interaction_'+str(i),'Parafuso '+str(i)+' · interação tração/corte',eta,1.,'—',
            NBR+' 6.3.3.4','η=(Ti/Ft,Rd)²+(Si/Fv,Rd)²≤1',
            'Somente verificável após equilíbrio dos dados externos; compatibilidade e flexão permanecem pendentes.'))
    return rows,state


def _safe(value):
    if isinstance(value,float) and not math.isfinite(value):return str(value)
    if isinstance(value,dict):return {str(k):_safe(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)):return [_safe(v) for v in value]
    return value if value is None or isinstance(value,(str,int,float,bool)) else repr(value)


def _evaluate(c):
    out=dict(status='INVALID_INPUT',global_pass=False,scope=SCOPE,exclusions=EXCLUSIONS.copy(),
        inputs=_safe(asdict(c)) if isinstance(c,BeamOnBeam) else repr(c),
        checks=[],issues=[],geometry={},load_model={},summary={},modules={})
    errors=input_errors(c)
    if errors:
        out['issues']=[dict(severity='invalid_input',text=e) for e in errors];return out
    out['load_model']=resolve_beam_seat_actions(c)
    geometry,g=check_seat_fit(c);geometry+=check_stiffener_detail_only(c)
    out['checks'].extend(geometry);out['geometry']=g
    unsupported=[]
    for bad,text in [(c.beam.family!='W' or c.support.family!='W','Somente perfis W laminados.'),
                     (c.V<=0,'Somente V descendente positivo no modelo de contato.'),
                     (c.torsion!=0,'Torção aplicada no plano exclui a distribuição N/4.'),
                     (c.db not in HOLES,'Diâmetro fora das tabelas de furo e ferragem qualificadas.'),
                     (c.bolt not in ('ASTM F3125 A325','ASTM F3125 A490'),'Classe de parafuso fora do domínio.'),
                     (c.electrode_fuw!=485.,'Primeira rota: eletrodo E7018 fuw=485 MPa.'),
                     (not c.static or not c.normal_combination,'Somente ações estáticas e combinação última normal.'),
                     (c.no_slip_required,'Resistência ao deslizamento de serviço não verificada.'),
                     (c.hole_diameter>HOLES.get(c.db,0),'Furo acima do padrão qualificado.')]:
        if bad:unsupported.append(text)
    materials_valid=True
    for name,steel,thicknesses,is_plate in [('viga superior',c.beam_steel,[c.beam.tf,c.beam.tw],False),('viga inferior',c.support_steel,[c.support.tf,c.support.tw],False),('chapa',c.plate_steel,[c.tp],True),('enrijecedor',c.stiffener_steel,[c.stiffener_t],True)]:
        if steel not in STEELS:
            unsupported.append(name+': aço não cadastrado.');materials_valid=False;continue
        s=STEELS[steel]
        allowed=s.plate_allowed if is_plate else s.rolled_allowed
        lo=s.plate_min if is_plate else s.profile_min;hi=s.plate_max if is_plate else s.profile_max
        if not allowed or any(not lo<=t<=hi for t in thicknesses):unsupported.append(name+': produto/espessura fora do aço cadastrado.');materials_valid=False
    out['issues'].extend(dict(severity='unsupported_scope',text=t) for t in unsupported)
    basic_valid=not unsupported and g['valid']
    if materials_valid and c.bolt in BOLTS and c.db in HOLES:
        for key,fn in [('bolt_inplane_shear',check_bolt_inplane_shear),('hole_bearing_each_ply',check_hole_bearing_each_ply),('weld_horizontal_component',check_weld_assigned_group)]:
            rows=fn(c,basic_valid);out['checks'].extend(rows)
            out['modules'][key]=dict(status='CALCULATED_PARTIAL' if basic_valid else 'OUTSIDE_SCOPE',check_ids=[r['id'] for r in rows])
        rows,external=check_bolt_tension_interaction_from_external(c,out['load_model'],basic_valid)
        out['checks'].extend(rows);out['load_model']['external_transfer']=external
        out['modules']['bolt_tension_interaction']=dict(status='EXTERNAL_DEMAND_CHECKED' if external['equilibrium_valid'] and basic_valid else 'PENDING',check_ids=[r['id'] for r in rows])
    out['modules']['seat_fit']=dict(status='CHECKED_WITH_PENDING_ACCESS',check_ids=[r['id'] for r in geometry])
    out['modules']['stiffener_detail']=dict(status='DETAIL_ONLY_NO_STRENGTH_CREDIT',physical_count=2 if c.stiffeners else 0)
    pending=[
        ('plate_inplane_paths','Seções e blocos reais da chapa entre soldas e furos',NBR+' 6.5.3–6.5.6','Não adota automaticamente área total da chapa nem duplica os dois lados; caminho local ainda não qualificado.'),
        ('contact_and_plate_flexure','Contato vertical e flexão da chapa contínua',NBR+' 6.1.1.3 e 6.3.5.1','C/centro/T equilibrados não validam pressões, flexão da chapa ou compatibilidade.'),
        ('upper_lower_local_regions','Mesas e almas locais de ambas as vigas',NBR+' 5.7.1–5.7.4','Não aplica fórmulas de carga centrada a contato excêntrico sem modelo; mantém a necessidade local.'),
        ('weld_normal_and_moment','Solda superior completa sob força normal e momento',NBR+' 6.2','A parcela horizontal calculada não elimina ações normais da transferência local.'),
        ('stiffener_strength_and_welds','Resistência dos enrijecedores e das soldas inferiores',NBR+' 5.7.9 e 6.2','Sem V/2 presumido, sem resistência creditada apenas pela presença no desenho.'),
        ('minimum_connection_strength','Resistência mínima normativa da ligação',NBR+' 6.1.5.2','A categoria do membro e aplicação direcional do mínimo precisam ser definidas; não altera ações fornecidas.'),
    ]
    for key,name,ref,note in pending:
        out['checks'].append(_row(key,name,reference=ref,notes=note,category='MODEL'))
        out['modules'][key]=dict(status='PENDING',reason=note)
    out['issues'].append(dict(severity='engineering_pending',code='local_transfer_grouped',
        text='Transferência local fora do plano pendente: contato, flexão, tração/alavanca e caminho até ambas as vigas/enrijecedores. Seções no plano e mínimo normativo ainda delimitados. Dados externos equilibrados não comprovam compatibilidade.',
        reference=NBR+' 6.1.1.3; 6.3.5; 5.7'))
    resistance=[r for r in out['checks'] if r['category']=='RESISTANCE']
    geom=[r for r in out['checks'] if r['category']=='GEOMETRY']
    models=[r for r in out['checks'] if r['category']=='MODEL']
    maxeta=max((r['eta'] for r in resistance if r['eta'] is not None),default=None)
    failures=[r for r in resistance if r['status']=='FAIL']
    gfails=[r for r in geom if r['status']=='FAIL']
    mfails=[r for r in models if r['status']=='FAIL']
    out['summary']=dict(resistance_max_utilization=maxeta,
        resistance_status='FAIL' if failures else 'PARTIAL_CHECKS_PASS' if any(r['status']=='PASS' for r in resistance) else 'NOT_CALCULATED',
        geometry_status='FAIL' if gfails else 'PENDING' if any(r['status']=='PENDING' for r in geom) else 'PASS',
        model_scope_status='OUTSIDE_SCOPE' if unsupported else 'EXTERNAL_EQUILIBRIUM_FAIL' if mfails else 'PENDING',
        verified_resistance_checks=sum(r['status']=='PASS' for r in resistance),failed_resistance_checks=len(failures),
        pending_resistance_checks=sum(r['status']=='PENDING' for r in resistance),complete_connection_verified=False,
        global_stability='outside_scope',action_basis='ações simultâneas fornecidas sem novos coeficientes de ações')
    out['status']='OUTSIDE_SUPPORTED_SCOPE' if unsupported else 'GEOMETRY_FAIL_MODEL_PENDING' if gfails else 'EXTERNAL_EQUILIBRIUM_FAIL' if mfails else 'LOCAL_RESISTANCE_FAIL_MODEL_PENDING' if failures else 'PARTIAL_CHECKS_PASS_MODEL_PENDING'
    return out


def evaluate(c):
    try:
        result=_evaluate(c)
        # A nonfinite result is never allowed to become an approval or JSON NaN.
        def finite_tree(value):
            if isinstance(value,float) and not math.isfinite(value):return False
            if isinstance(value,dict):return all(finite_tree(v) for v in value.values())
            if isinstance(value,(list,tuple)):return all(finite_tree(v) for v in value)
            return True
        if not finite_tree(result):raise ArithmeticError('Resultado não finito.')
        return result
    except (ArithmeticError,OverflowError,ValueError,TypeError,KeyError,ZeroDivisionError) as exc:
        return dict(status='NUMERICAL_FAILURE',global_pass=False,scope=SCOPE,exclusions=EXCLUSIONS.copy(),
            checks=[],issues=[dict(severity='numerical_failure',text=str(exc))],geometry={},load_model={},summary={},modules={},
            inputs=_safe(asdict(c)) if isinstance(c,BeamOnBeam) else repr(c))
