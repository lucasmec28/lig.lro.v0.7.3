"""Draw the evaluated bounded cap and its genuine physical axial gauge."""

def draw(ax,g,fmt,label_offset=(28,28)):
    cut=g.get('outer_end_cut')
    if not cut:return
    if not cut.get('trimmed'):
        if cut.get('state')=='no_trim':
            corner='beam_seam' in g
            ax.text(.98 if corner else .02,.92,'Corte externo\nsem remoção de material',transform=ax.transAxes,ha='right' if corner else 'left',va='top',fontsize=7.5,color='#34618a',bbox=dict(facecolor='white',edgecolor='none',pad=2)).set_gid('outer_end_no_trim')
        return
    a,b=cut['cut_segment'];line,=ax.plot([a[0],b[0]],[a[1],b[1]],color='#2757a5',lw=1.8,zorder=10);line.set_gid('outer_normal_cut_free')
    if not cut.get('dimension'):return
    p,q=cut['dimension'];mid=[(p[i]+q[i])/2 for i in (0,1)]
    arrow=ax.annotate('',xy=q,xytext=p,arrowprops=dict(arrowstyle='<->',color='#2757a5',lw=1.2),zorder=12);arrow.set_gid('outer_end_physical_dimension');arrow.arrow_patch.set_gid('outer_end_physical_dimension')
    label=ax.annotate('Corte externo\ne='+fmt(cut['distance_mm'])+' mm',xy=mid,xytext=label_offset,textcoords='offset points',fontsize=7.8,color='#2757a5',zorder=13,bbox=dict(facecolor='white',edgecolor='none',pad=2),arrowprops=dict(arrowstyle='-',color='#2757a5',lw=.7));label.set_gid('outer_end_dimension_label')
