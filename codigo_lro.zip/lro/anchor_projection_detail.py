"""Physical datum definitions for drawings, independent of strength calculations.

The automatic projection is a detailing proposal, never a thread-engagement
verification. Effective embedment is not the total manufactured rod length.
"""
import math


def projection_geometry(c):
    requested=getattr(c,'anchor_projection_above_plate',0.)
    if type(requested) not in (int,float) or not math.isfinite(requested) or requested<0:
        raise ValueError('Projeção acima da placa: informe zero (proposta automática) ou valor positivo.')
    washer=c.anchor_washer_t
    if getattr(c,'model_type',None)==1:
        from .base_plate_details import fixed_base_washer_geometry
        washer=fixed_base_washer_geometry(c)['thickness']
    nut=.75*c.db
    nut_width=1.5*c.db
    normalized=False
    if getattr(c,'washer_nut_type','')=='a563_a_heavy_hex_unc':
        from .channel_upper_washer import nut_geometry
        data=nut_geometry(c.db,c.anchor_washer_hole)
        nut=data['height'];nut_width=data['Fmax'];normalized=True
    proposal=washer+nut+6.
    above_plate=requested or proposal
    return dict(above_plate=above_plate,above_concrete=c.grout_t+c.tp+above_plate,
                washer_t=washer,nut_h=nut,nut_width=nut_width,
                free_tip=above_plate-washer-nut,automatic=requested==0,
                normalized_nut=normalized,
                rod_top=c.tp+above_plate,concrete_top=-c.grout_t,
                bearing_face=-c.grout_t-c.hef)


def projection_note(c):
    g=projection_geometry(c)
    if g['free_tip']< -1e-9:
        return 'ATENÇÃO: projeção insuficiente até para a pilha arruela + porca; corrigir o detalhe.'
    if abs(g['free_tip'])<=1e-9:
        return 'ATENÇÃO: ponta sem sobra acima da porca; confirmar engajamento da rosca e montagem.'
    return ('Projeção proposta: arruela + porca + 6 mm; confirmar montagem/rosca.' if g['automatic'] else
            'Projeção informada pelo usuário; confirmar montagem/rosca.')
