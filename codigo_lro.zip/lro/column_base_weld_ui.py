"""Column/base weld components with explicit, input-bound design records."""
from .display_precision import display_format, display_frame, display_value, number_input
from dataclasses import asdict, replace
from contextlib import nullcontext
import streamlit as st
from .column_base_weld import ColumnBaseWeld, MODEL, MODEL_QUALIFIED, SUPPORTED_STEELS, FW
from .base_weld_qualified import qualification_signature, qualification_binding_kind, CALCULATION_BASIS, DESIGN_SPECIFICATION
from .models import KGF
from .report import number
from .base_plate_details import WELD_TYPES, MEASURES, fillet_dimensions


METHODS = {
    'unspecified': 'Não especificado',
    'guide_example': 'Exemplo de guia aplicável ao detalhe e às ações',
    'one_way': 'Memória de transferência unidirecional',
    'plate_model': 'Modelo de placa verificado',
}
PROCESSES = {
    'unspecified': 'Não especificado',
    'smaw_e7018_single_pass': 'SMAW/E7018 · filete em passe único',
    'smaw_e7018': 'SMAW/E7018 · CJP qualificada',
    'smaw_e7018_mixed': 'SMAW/E7018 · filetes em passe único + CJP qualificada',
}
_FORCE_FIELDS = frozenset()


def _prefix(): return st.session_state.get('_baseplate_ui_prefix', 'bp')
def _key(name): return _prefix() + '_cw_' + name
def _draft(): return '_' + _prefix() + '_column_weld_draft'
def _canonical(value, previous, factor):
    return previous if previous is not None and value == previous / factor else value * factor


def _select(label, choices, name, labels):
    # Keep unsupported imported values visible rather than silently replacing them.
    options = list(choices)
    current = st.session_state.get(_key(name))
    if current is not None and current not in options:
        options.append(current)
    return st.selectbox(label, options, key=_key(name),
                        format_func=lambda value: labels.get(value, 'Dado importado fora do modelo: ' + str(value)))


def seed_column_weld(c):
    data = asdict(c.column_weld)
    for name, value in data.items():
        st.session_state[_key(name)] = (value / KGF if name in _FORCE_FIELDS else
                                       float(value) if type(value) in (float, int) else value)
    st.session_state[_draft()] = data


def restore_column_weld(connection):
    s = st.session_state
    data = s.get(_draft(), connection.get('column_weld', {}))
    for name, default in asdict(ColumnBaseWeld()).items():
        value = data.get(name, default)
        display = value / KGF if name in _FORCE_FIELDS else float(value) if type(value) in (float, int) else value
        s[_key(name)] = s.get(_key(name), display)


def _cjp_widgets():
    _select('Detalhe CJP de apoio/cobre-junta', ['unspecified', 'backing_removed', 'backing_retained'], 'cjp_detail',
            {'unspecified': 'Não especificado', 'backing_removed': 'Apoio/cobre-junta removido',
             'backing_retained': 'Apoio/cobre-junta mantido'})
    st.checkbox('Tenacidade Charpy do metal de solda CJP comprovada, inclusive seção espessa tracionada',
                key=_key('cjp_charpy_confirmed'))
    st.checkbox('Tenacidade do metal-base, quando aplicável, comprovada', key=_key('base_charpy_confirmed'))
    st.text_input('Registro de inspeção CJP · opcional nesta etapa de projeto', key=_key('inspection_ref'))


def _uplift_widgets():
    st.caption('Modelo local verificado para tração pura da base rotulada Tipo 2. Nas demais combinações, '
               'os dados ficam salvos e o cálculo permanece pendente. Usa o tipo de solda da alma e sua '
               'dimensão especificados acima; não credita as mesas.')
    number_input('Comprimento real reto contínuo centrado da solda da alma (mm)',
                    min_value=0., key=_key('web_length'), format='%.2f')
    st.caption('Exclua concordâncias, recortes e trechos sem solda. Cada faixa completa deve caber no '
               'comprimento real, sem cortar a força nem usar l₀ da placa como comprimento da solda.')
    _select('Processo e execução da solda pilar–placa',
            ['unspecified', 'smaw_e7018_single_pass', 'smaw_e7018'], 'process', PROCESSES)
    st.text_input('Procedimento e referência do detalhe da solda', key=_key('procedure_ref'))
    st.checkbox('Comprimento real contínuo e centrado, alma íntegra, sem interferência de furos, arruelas ou soldas.',
                key=_key('detail_confirmed'))
    if st.session_state.get(_prefix() + '_weld_web_type') == 'cjp':
        _cjp_widgets()
    st.warning('Calcula componentes locais da alma/solda e faixa suplementar da placa. Fusão local na placa, '
               'interação flexão–cisalhamento, furos/arruelas e caminho completo até a ancoragem continuam a verificar.')


def _qualified_widgets():
    st.caption('Componente condicionado à memória de transferência: todo N e M nas duas mesas; todo V na alma. '
               'Usa N/M/V de cálculo na face superior da placa, com N positivo em compressão. O momento adicional '
               'da chave abaixo da placa não entra nesta solda. Não presume rigidez da placa nem da base.')
    if _prefix() == 'pp':
        st.caption('Na família rotulada Tipo 2, o momento aplicado na face superior é M=0; o componente usa N e V informados.')
    st.caption('Tipos e dimensões são os especificados neste painel. '
               'Um filete exterior por mesa; dois filetes iguais nas faces da alma. CJP usa uma única seção '
               'fundida por mesa/alma. As duas mesas têm o mesmo detalhe e comprimento; alma e mesas podem ter tipos diferentes.')
    for name, label in (
        ('flange_length', 'Comprimento real reto contínuo de cada solda de mesa (mm)'),
        ('flange_effective_length', 'Comprimento efetivo qualificado de cada mesa (mm)'),
        ('web_length', 'Comprimento real reto contínuo da solda da alma por face (mm)'),
        ('web_effective_length', 'Comprimento efetivo qualificado da alma por face ou seção CJP (mm)'),
    ):
        number_input(label, min_value=0., key=_key(name), format='%.2f')
    st.caption(f'Filetes: fw={display_value(number(FW, 0))} MPa; resistência de linha 0,6·fw·a/1,35, sem aumento direcional AISC.')
    st.caption('Os trechos são centrados. Comprimento efetivo não pode superar o real; não se concede a largura '
               'inteira da mesa apenas porque os chumbadores ficam dentro dela. Em CJP, o comprimento pertence '
               'à seção fundida e não é multiplicado pelo número de faces.')
    _select('Transferência normal na interface pilar–placa', ['welded', 'fit_bearing'], 'normal_transfer',
            {'welded': 'Pelas soldas · tração e compressão, sem alívio por contato',
             'fit_bearing': 'Compressão pura por contato preparado · N>0 e M=0'})
    if st.session_state.get(_key('normal_transfer')) == 'fit_bearing':
        number_input('Área efetiva real de contato preparado (mm²)',
                        min_value=0., key=_key('bearing_area'), format='%.2f')
        st.text_input('Referência do preparo e da área efetiva de contato', key=_key('bearing_ref'))
        st.text_area('Comprovação do ajuste para contato, superfície e área de apoio', key=_key('bearing_basis'))
        st.caption('Somente N>0 e M=0: N passa ao contato, V continua na alma. Não elimina uma força de '
                   'compressão devida a M. A resistência local de contato é calculada pelo app com a área informada; '
                   'essa área não pode superar a seção real do pilar. Requisitos mínimos de solda e detalhe permanecem aplicáveis.')
    _select('Processo e execução da solda pilar–placa', PROCESSES, 'process', PROCESSES)
    if any(st.session_state.get(_prefix() + '_weld_' + part + '_type') == 'cjp' for part in ('web', 'flange')):
        _cjp_widgets()
    _select('Base da qualificação do caminho de forças', METHODS, 'qualification_method', METHODS)
    st.text_input('Referência da memória de transferência, revisão e combinação', key=_key('transfer_ref'))
    st.caption(CALCULATION_BASIS)
    st.caption(DESIGN_SPECIFICATION)
    st.caption('A referência acima deve identificar a análise específica que justifica Leff e a transferência da placa aos chumbadores/contato. Não se exige reescrever a estática calculada. O app registra o vínculo; não verifica o conteúdo da análise.')
    if st.checkbox('Mostrar registros complementares ou importados · opcionais',key=_key('_show_legacy_records')):
        st.text_area('Registro adicional da alocação · preservado do projeto',key=_key('allocation_basis'))
        st.text_area('Registro adicional dos comprimentos efetivos',key=_key('effective_length_basis'))
        st.text_area('Registro adicional de execução',key=_key('execution_ref'))
        st.text_input('Procedimento de soldagem · registro opcional',key=_key('procedure_ref'))


def column_weld_widgets(measure_changed=None):
    panel = st.expander('Soldas pilar–placa · detalhe, cálculo e qualificação')
    with panel:
        for part, label in (('web', 'Alma'), ('flange', 'Mesas')):
            key = _prefix() + '_weld_' + part + '_'
            st.selectbox(label + ' · tipo de solda', list(WELD_TYPES), key=key+'type', format_func=WELD_TYPES.get)
            if st.session_state[key+'type'] == 'fillet':
                st.selectbox(label + ' · dimensão informada', list(MEASURES), key=key+'measure',
                             format_func=MEASURES.get, on_change=measure_changed, args=(part,))
                number_input(label + ' · tamanho do filete (mm)', min_value=.1, key=key+'size', format='%.2f')
                dims = fillet_dimensions(st.session_state[key+'size'], st.session_state[key+'measure'])
                st.caption(f"Perna z={display_value(number(dims['leg'], 4))} mm; garganta a={display_value(number(dims['throat'], 4))} mm. A troca de unidade conserva o filete.")
        st.caption('Filetes de pernas iguais a 90°: a=z/√2, sem penetração adicional. Alma e mesas conservam suas especificações independentes.')
        options = ['off', MODEL_QUALIFIED]
        if _prefix() == 'pp':
            options.insert(1, MODEL)
        mode = _select('Submodelo resistente da solda pilar–placa', options, 'model',
                       {'off': 'Não selecionado', MODEL: 'Faixas de 45° até a alma · Tipo 2, N<0 e M=V=0',
                        MODEL_QUALIFIED: 'Duas mesas para N/M + alma para V · qualificação explícita'})
        if mode == 'off':
            st.caption('Detalhe salvo. Selecione o componente para calcular as resistências aplicáveis.')
            return panel
        _select('Aço do pilar para a solda e metal-base', ['unspecified'] + sorted(SUPPORTED_STEELS), 'column_steel',
                {'unspecified': 'Não especificado', **{name: name for name in SUPPORTED_STEELS}})
        if mode == MODEL:
            _uplift_widgets()
        elif mode == MODEL_QUALIFIED:
            _qualified_widgets()
        else:
            st.warning('Modelo importado não suportado. Os dados permanecem salvos, sem aprovação.')
    return panel


def column_weld_from_state():
    s = st.session_state
    prior = s.get(_draft(), {})
    data = {}
    for name, default in asdict(ColumnBaseWeld()).items():
        previous = prior.get(name, default)
        value = s.get(_key(name), previous / KGF if name in _FORCE_FIELDS else previous)
        data[name] = _canonical(value, prior.get(name), KGF) if name in _FORCE_FIELDS else value
    u = ColumnBaseWeld(**data)
    s[_draft()] = asdict(u)
    return u


def _qualification_records_present(u):
    if u.qualification_method not in ('guide_example', 'one_way', 'plate_model'):
        return False
    if not all(isinstance(getattr(u, name), str) and getattr(u, name).strip() for name in
               ('transfer_ref',)):
        return False
    if u.normal_transfer == 'fit_bearing':
        return (isinstance(u.bearing_area, (float, int)) and not isinstance(u.bearing_area, bool) and
                0 < u.bearing_area < float('inf') and bool(u.bearing_ref.strip()) and bool(u.bearing_basis.strip()))
    return u.normal_transfer == 'welded'


def column_weld_qualification(c, embedded=False):
    """Bind supplied records only by explicit action; edits irreversibly clear the old binding."""
    u = c.column_weld
    try:
        signature = qualification_signature(c)
        binding=qualification_binding_kind(c)
    except (ValueError, TypeError, OverflowError):
        signature = ''
        binding='stale'
    legacy_current=binding=='legacy_current' and u.model==MODEL_QUALIFIED
    stale = bool(u.qualification_signature) and (binding not in ('current','legacy_current') or u.model != MODEL_QUALIFIED)
    if legacy_current:
        u=replace(u,qualification_signature=signature)
    if stale:
        u = replace(u, qualification_signature='')
    if u.model == MODEL_QUALIFIED:
        with (nullcontext() if embedded else st.expander('Vínculo da qualificação à combinação e ao detalhe atuais', expanded=True)):
            if legacy_current:
                st.caption('Vínculo legado conferido e preservado para os mesmos dados físicos e memória. Registros opcionais deixam de alterar esse vínculo; resultados e arquivos continuam exigindo dados atuais.')
            ready = bool(signature) and _qualification_records_present(u)
            if not ready:
                st.caption('Para registrar o vínculo externo, informe método e a referência específica que cobre os comprimentos efetivos e a compatibilidade placa–chumbadores. O contato preparado também exige sua área e comprovação próprias.')
            st.caption('O vínculo registra que a memória citada cobre estes dados. Não substitui seu conteúdo, '
                       'a análise do responsável técnico ou a verificação completa da placa e da base.')
            bound_now = st.button('Vincular qualificação documental aos dados atuais',
                                  key=_key('bind_qualification'), disabled=not ready)
            if bound_now:
                u = replace(u, qualification_signature=signature)
            removed_now = st.button('Remover vínculo da qualificação', key=_key('clear_qualification'),
                                    disabled=not bool(u.qualification_signature))
            if removed_now:
                u = replace(u, qualification_signature='')
                st.caption('Vínculo removido; os registros foram preservados.')
            if u.qualification_signature and u.qualification_signature == signature:
                st.success('Qualificação documental vinculada aos dados atuais pelo responsável técnico.')
            elif stale and not bound_now:
                st.warning('Qualificação anterior invalidada por alteração de dados. Revise a memória e registre '
                           'um novo vínculo; voltar aos valores antigos não o restaura.')
            else:
                st.warning('Qualificação ainda não vinculada. Cálculos disponíveis são condicionais.')

    st.session_state[_draft()] = asdict(u)
    st.session_state[_key('qualification_signature')] = u.qualification_signature
    return replace(c, column_weld=u)


def _qualified_results(out, r):
    # The result's arithmetic and engineering qualification are deliberately separate.
    qualified = out.get('qualification_status') == 'qualified'
    status = out.get('status')
    if out.get('numerical_status')=='pass':
        st.success('Cálculo das soldas e seções locais: ATENDE para os comprimentos efetivos informados.')
    if status == 'fail':
        st.error('Há componente local calculado que não atende, mesmo sob as hipóteses informadas.')
    elif status == 'pass' and qualified:
        st.success('Os componentes locais calculados atendem no escopo da qualificação documental vinculada.')
    elif out.get('numerical_status') == 'pass':
        if qualified:
            st.warning('Componentes numéricos atendem condicionalmente. Há requisito de execução/detalhamento ou dado '
                       'pendente; consulte as condições abaixo.')
        else:
            st.warning('Componentes numéricos atendem condicionalmente; a qualificação documental de transferência '
                       'permanece pendente.')
    else:
        st.warning('Há dados, qualificações ou componentes pendentes. Consulte os resultados separados abaixo.')
    labels = {'missing': 'não vinculada', 'stale': 'desatualizada', 'qualified': 'documentalmente vinculada aos dados atuais'}
    st.write('Compatibilidade da transferência na placa: ' + labels.get(out.get('qualification_status'), 'pendente') + '.')
    st.caption('Execução e inspeção são requisitos de projeto; o app não verifica sua realização.')
    for reason in out.get('reasons', []):
        st.caption(str(reason))
    if 'F_left_N' in out:
        st.write(f"Ações na face superior: N={display_value(number(out['N_input_N'] / KGF, 3))} kgf; M={display_value(number(out['M_input_Nmm'] / (KGF * 1000), 3))} kgf·m; V={display_value(number(out['V_input_N'] / KGF, 3))} kgf.")
        st.write(f"Planos de transferência: xL={display_value(number(out['x_left_mm'], 3))} mm; xR={display_value(number(out['x_right_mm'], 3))} mm; h={display_value(number(out['h_mm'], 3))} mm.")
        st.write(f"Mesa −x: FL={display_value(number(out['F_left_N'] / KGF, 3))} kgf; mesa +x: FR={display_value(number(out['F_right_N'] / KGF, 3))} kgf; alma: V={display_value(number(out['web_shear_N'] / KGF, 3))} kgf.")
        st.caption('Forças das mesas conservam o sinal: positivo = tração no pilar; negativo = compressão. '
                   'O modo soldado verifica também as magnitudes comprimidas, sem alívio por contato. '
                   'Planos dos filetes exteriores: ±d/2; planos CJP: ±(d−tf)/2.')
        if out.get('normal_transfer_applied') == 'fit_bearing':
            st.write(f"Contato preparado: força={display_value(number(out['bearing_force_N'] / KGF, 3))} kgf; área={display_value(number(out['bearing_area_mm2'], 3))} mm²; Rd={display_value(number(out['bearing_resistance_N'] / KGF, 3))} kgf. Força normal nas soldas das mesas igual a zero para esta compressão pura.")
        elif out.get('normal_transfer_requested') == 'fit_bearing':
            st.caption('Contato preparado solicitado, mas sem crédito nesta combinação; as forças normais permanecem nas soldas.')
        st.write(f"Resultantes integradas: normal={display_value(number(out['normal_resultant_N'] / KGF, 3))} kgf (=−N); momento={display_value(number(out['moment_resultant_Nmm'] / (KGF * 1000), 3))} kgf·m (=M); cortante={display_value(number(out['shear_resultant_N'] / KGF, 3))} kgf (=V).")
        st.caption(f"Resíduos de equilíbrio: ΣFn+N={display_format(out['residual_N_N'], '.3g')} N; ΣxFn−M={display_format(out['residual_M_Nmm'], '.3g')} N·mm; ΣV−V={display_format(out['residual_V_N'], '.3g')} N. A força de um chumbador não é substituída pela força da mesa.")
    for part, label in (('flange', 'Cada mesa'), ('web', 'Alma')):
        row = out.get(part)
        if not row:
            continue
        st.write(f"{display_value(label)}: comprimento real={display_value(number(row['physical_length_mm'], 3))} mm; efetivo informado={display_value(number(row['effective_length_mm'], 3))} mm; adotado na resistência={display_value(number(row['design_length_mm'], 3))} mm; Rd={display_value(number(row['resistance_N'] / KGF, 3))} kgf; índice máximo={display_value(number(row['utilization'], 4))}.")
        if part == 'flange':
            st.caption(f"Trações lineares com sinal: qL={display_value(number(row['q_left_N_per_mm'], 3))} N/mm; qR={display_value(number(row['q_right_N_per_mm'], 3))} N/mm.")
        else:
            st.caption(f"Tração linear de corte qV={display_value(number(row['q_per_face_N_per_mm'], 3))} N/mm "
                       + ('por face de filete.' if row['kind'] == 'fillet' else 'na seção CJP única.'))
        if row['kind'] == 'fillet':
            st.caption(f"Filete: perna z={display_value(number(row['leg_mm'], 3))} mm; garganta a={display_value(number(row['throat_mm'], 3))} mm. "
                       + ('Um filete exterior por mesa.' if part == 'flange' else 'Duas faces iguais; cada uma transfere V/2.'))
            if part == 'web' and row['design_length_mm'] < row['effective_length_mm']:
                st.caption('Comprimento resistente da alma limitado pela redução longitudinal de filete longo; '
                           'não altera o comprimento físico nem o equilíbrio das forças informado.')
        else:
            st.caption('CJP: uma seção fundida, sem duplicação da resistência por faces.')
    checks = [x for x in r.checks if 'cwq_' in x.id]
    if checks:
        st.dataframe(display_frame([{'Verificação local': x.name, 'Sd': x.demand, 'Rd': x.resistance,
                       'Unidade': x.unit, 'Resultado': 'ATENDE' if x.passed else 'NÃO ATENDE'} for x in checks]),
                     hide_index=True, width='stretch')
    st.warning('Componente local condicionado: o equilíbrio N/M/V não prova a distribuição na placa. '
               'Transferência local na placa, ligação completa e rigidez rotacional continuam no escopo próprio.')


def column_weld_results(c, r):
    if c.column_weld.model == 'off':
        return
    out = r.local_column_weld
    title = ('Solda pilar–placa · duas mesas N/M + alma V' if c.column_weld.model == MODEL_QUALIFIED else
             'Solda pilar–placa · resultados locais Tipo 2')
    with st.expander(title, expanded=True):
        if c.column_weld.model == MODEL_QUALIFIED:
            _qualified_results(out, r)
            if out.get('current_signature') and 'F_left_N' in out:
                from .column_base_weld_drawing import image_bytes
                try:
                    png = image_bytes(c, r)
                    svg = image_bytes(c, r, fmt='svg')
                except ValueError as exc:
                    st.warning('Desenho local indisponível para estes dados: ' + str(exc))
                else:
                    st.image(png, width='stretch')
                    st.caption('Detalhe do componente e auditoria de forças na face superior; '
                               'cores distinguem trechos físicos e efetivos. Consulte a qualificação indicada na folha.')
                    st.download_button('Baixar detalhe da solda pilar–placa PNG', png, 'solda_pilar_placa.png',
                                       mime='image/png', key=_key('download_png'))
                    st.download_button('Baixar detalhe da solda pilar–placa SVG', svg, 'solda_pilar_placa.svg',
                                       mime='image/svg+xml', key=_key('download_svg'))
            return
        if out.get('status') == 'pass':
            st.success('Os componentes locais calculados atendem.')
        elif out.get('status') == 'fail':
            st.error('Há componente local que não atende.')
        else:
            st.warning('Modelo local pendente ou fora desta combinação.')
        for reason in out.get('reasons', []):
            st.caption(str(reason))
        for key, value in out.get('statuses', {}).items():
            st.write(str(key) + ': ' + str(value))
        if 'b_eff_mm' in out:
            st.write(f"Faixa efetiva b={display_value(number(out.get('b_eff_mm', 0), 3))} mm por barra; e={display_value(number(out.get('e_mm', 0), 3))} mm; força normal por face={display_value(number(out.get('q_normal_one_face_N_per_mm', 0), 3))} N/mm.")
            st.caption('CJP usa uma seção efetiva da alma: não duplica a capacidade por duas faces. '
                       'A placa mantém a verificação NBR Tipo 2 e recebe adicionalmente a verificação das faixas reais de 45°.')
        st.warning('Ligação completa ainda pendente: os resultados locais não demonstram transferência integral, '
                   'capacidade de rotação ou rigidez da base.')
