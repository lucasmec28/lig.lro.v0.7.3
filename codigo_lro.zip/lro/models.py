"""Valores canônicos: N, mm, MPa. Nenhum fator de carga neste módulo."""
from dataclasses import dataclass, asdict, field
from pathlib import Path
import json
import math

def finite_real(value):
    """Real scalar representable in the float range, including JSON integers."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return False
    try:
        return math.isfinite(value)
    except (OverflowError, ValueError):
        return False


KGF = 9.80665
VERSION = "0.9.44-beam-on-beam-partial-dev"
SUPPORT_WEB_EXCLUSION = "Não é verificada a interação fora do plano da alma da viga de apoio sob N+V ou N excêntrico."
COMPLEMENT_ASSUMPTION = "Entre mesas: as soldas à alma e às duas mesas usam grupo elástico sob hipótese de chapa e receptores rígidos no plano. Permanecem pendentes a resistência e a estabilidade do complemento, a transferência/redistribuição na chapa, a capacidade de rotação, o metal-base e a capacidade/rigidez dos receptores. As verificações da chapa retangular nominal são referências separadas, sem ganho de resistência pelo complemento; seus resultados não qualificam a chapa real de três bordas."
OPPOSITE_STIFFENER_ASSUMPTION = "Enrijecedor oposto coplanar à single plate, entre as faces internas das mesas da viga de apoio, representado apenas no detalhamento. Não são dimensionados o enrijecedor, suas soldas ou a redistribuição de esforços para as mesas. Não se atribui ganho de resistência ou estabilidade: a punção e as demais verificações mantêm a alma original, sem somar espessuras ou considerar outra viga no lado oposto."
INTERFERENCE_ASSUMPTION = "As interferências indicadas não impedem o cálculo das dimensões nominais informadas e devem ser resolvidas no detalhamento de fabricação. Alívios, recortes ou ajustes que alterem a seção resistente, os furos ou o comprimento útil de solda exigem atualizar os dados e recalcular."


@dataclass(frozen=True)
class Profile:
    name: str
    family: str
    mass: float
    d: float
    bf: float
    tw: float
    tf: float
    clear: float
    area: float
    source: str = "Seção informada pelo usuário"


def profiles():
    path = Path(__file__).resolve().parent.parent / "data" / "profiles.json"
    rows=json.loads(path.read_text(encoding="utf-8"))
    result={p["name"]: Profile(**p) for p in rows}
    if len(result)!=len(rows):raise ValueError("O catálogo contém designações ambíguas; identificar as variantes antes de utilizar.")
    return result


@dataclass(frozen=True)
class Steel:
    name: str
    fy: float
    fu: float
    plate_max: float = 200.0
    profile_max: float = 200.0
    plate_allowed: bool = True
    plate_min: float = 0.0
    profile_min: float = 0.0
    rolled_allowed: bool = True
    source: str = "ABNT NBR 8800:2024, tabela A.2"


# NBR 8800:2024, tabela A.2. Valores mínimos; limites de produto explícitos.
STEELS = {
    s.name: s for s in [
        Steel("ASTM A36",250,400),
        Steel("ASTM A572 Gr.42",290,415,150),
        Steel("ASTM A572 Gr.50",345,450,100),
        Steel("ASTM A572 Gr.55",380,485,50),
        Steel("ASTM A572 Gr.60",415,520,31.5,50),
        Steel("ASTM A572 Gr.65",450,550,31.5,50),
        Steel("ASTM A992",345,450,0,200,False),
        Steel("ASTM A913 Gr.50",345,450,0,50,False),
        Steel("ASTM A913 Gr.60",415,520,0,50,False),
        Steel("ASTM A913 Gr.65",450,550,0,50,False),
        Steel("USI-CIVIL 300",300,400,75,75,plate_min=6,profile_min=6,rolled_allowed=False,
              source="Usiminas, Catálogo de chapas grossas, jul. 2022, p.29; 6 ≤ t ≤ 75 mm"),
        Steel("USI-CIVIL 350",350,500,75,75,plate_min=6,profile_min=6,rolled_allowed=False,
              source="Usiminas, Catálogo de chapas grossas, jul. 2022, p.29; 6 ≤ t ≤ 75 mm"),
    ]
}

BOLTS = {"ASTM F3125 A325":830.0, "ASTM F3125 A490":1040.0, "ASTM A307":415.0}
DIAMETERS = {"1/2\"":12.7,"5/8\"":15.875,"3/4\"":19.05,"7/8\"":22.225,"1\"":25.4,"1 1/8\"":28.575,"1 1/4\"":31.75}
THICKNESSES = {"1/4\"":6.35,"5/16\"":7.9375,"3/8\"":9.525,"1/2\"":12.7,"5/8\"":15.875,"3/4\"":19.05}


@dataclass(frozen=True)
class Connection:
    beam: Profile
    support: Profile
    kind: str = "column_flange"
    beam_steel: str = "ASTM A572 Gr.50"
    support_steel: str = "ASTM A572 Gr.50"
    plate_steel: str = "ASTM A36"
    bolt: str = "ASTM F3125 A325"
    db: float = 19.05
    threads: bool = True
    n: int = 3
    pitch: float = 70.0
    edge_v: float = 40.0
    edge_h: float = 40.0
    a: float = 75.0
    gap: float = 10.0
    tp: float = 7.9375
    weld: float = 5.0
    fw: float = 485.0
    reinforced_weld: bool = False
    plate_top: float = 66.5
    beam_level: float = 0.0
    cope: str = "none"
    cope_top: float = 25.0
    cope_bottom: float = 25.0
    cope_length: float = 80.0
    clearance: float = 10.0
    tool_radius: float = 18.0
    drilled: bool = False
    V: float = 11000.0
    N: float = 2000.0
    restrained: bool = True
    norm_minimum: bool = True
    notes: str = ""
    project: str = "Ligação single plate"
    plate_shape: str = "rectangular"
    root_width: float = 60.0
    corner_clip: float = 20.0
    flange_weld: float = 5.0
    opposite_stiffener: bool = False
    stiffener_t: float = 7.9375
    stiffener_width: float = 60.0
    stiffener_clip: float = 20.0
    stiffener_weld: float = 5.0
    stiffener_steel: str = "ASTM A36"
    bolt_columns: int = 1
    gauge: float = 70.0
    support_joint_weld: float = 0.0
    support_edge_distance: float = 0.0
    def __post_init__(self):
        # Hipótese fixa solicitada em 09/10/2026. Booleanos inválidos são rejeitados.
        if self.restrained is False:object.__setattr__(self,'restrained',True)

    @property
    def fixed_assumptions(self):
        return {
            'contained_supported_beam': True,
            'supported_beam_weak_axis_moment_and_horizontal_shear': False,
            'welded_profile_internal_joint': 'complete_joint_penetration_matching_filler',
            'column_relative_flange_lateral_displacement': 'prevented_by_project_assumption',
            'between_flanges_complement': 'conditional_three_edge_weld_group_plate_and_receivers_pending' if self.full_depth else 'not_used',
            'opposite_stiffener': 'detailing_only_no_strength_credit' if self.opposite_stiffener else 'not_used',
            'supporting_girder_web_combined_out_of_plane_interaction': 'not_verified',
        }

    @property
    def hp(self): return 2*self.edge_v+(self.n-1)*self.pitch
    @property
    def width(self): return self.a+(self.bolt_columns-1)*self.gauge+self.edge_h
    @property
    def bolt_centroid_x(self):return self.a+(self.bolt_columns-1)*self.gauge/2
    @property
    def x_bolts(self):return [self.a+i*self.gauge for i in range(self.bolt_columns)]
    @property
    def full_depth(self):return self.plate_shape=='between_flanges'
    @property
    def root_height(self):return self.support.d-2*self.support.tf
    @property
    def beam_edge(self): return self.a-self.gap
    @property
    def dh(self): return self.db+(1.5875 if self.db < 25.4 else 3.175)
    @property
    def dh_net(self): return self.dh+(0 if self.drilled else 2.0)
    @property
    def y_bolts(self): return [self.plate_top+self.edge_v+i*self.pitch for i in range(self.n)]
    @property
    def yc(self): return self.plate_top+self.hp/2
    @property
    def eccentric_n(self): return self.beam.d/2-self.yc
    @property
    def support_web_combined_excluded(self):
        return not self.full_depth and self.kind=='beam_web' and self.N>0 and (self.V!=0 or abs(self.eccentric_n)>1e-8)
    @property
    def coped_top(self): return self.cope_top if self.cope in ("top","both") else 0.0
    @property
    def coped_bottom(self): return self.cope_bottom if self.cope=="both" else 0.0

    def to_dict(self): return {"schema_version":5,"app_version":VERSION,"connection":asdict(self),"fixed_assumptions":self.fixed_assumptions}

    @staticmethod
    def from_dict(data):
        if not isinstance(data,dict):raise ValueError("O projeto deve ser um objeto JSON.")
        if data.get("schema_version") not in (1,2,3,4,5): raise ValueError("Versão de arquivo de projeto não reconhecida.")
        if not isinstance(data.get("connection"),dict):raise ValueError("O arquivo não contém os dados da ligação.")
        d=dict(data["connection"])
        # Nos projetos antigos, o alívio do enrijecedor compartilhava a cota
        # do complemento. Preserva esse contorno ao migrar para o campo próprio.
        if 'stiffener_clip' not in d:d['stiffener_clip']=d.get('corner_clip',20.0)
        # A procedência, classificação e seção recebidas fazem parte do projeto.
        # Um nome igual ao catálogo não autoriza substituir os dados importados.
        if data.get('app_version')=='0.1.0' and d.get('project','').endswith('adaptado à V1'):
            d['project']='Exemplo de referência adaptado'
        d["beam"]=Profile(**d["beam"]);d["support"]=Profile(**d["support"])
        return Connection(**d)


@dataclass
class Check:
    id: str
    name: str
    demand: float
    resistance: float
    unit: str
    reference: str
    equation: str
    substitution: str
    variables: str
    case: str = "Entrada"

    @property
    def category(self):
        return "Condição do método" if self.id in ('support_punch','ductility','weld_development','full_compactness','opposite_compactness','ep_plate_rigidity','ep_column_rigidity','ep_plate_prying','ep_column_prying','ep_rotation','ep_ductility','ep_compact_flange','ep_compact_web') else "Resistência"

    @property
    def ratio(self):
        # Capacidades não finitas indicam falha numérica, nunca aprovação.
        # Não há resistência infinita como sentinela nos modelos implementados.
        if not math.isfinite(self.demand) or not math.isfinite(self.resistance) or self.resistance <= 0:
            return math.inf
        return abs(self.demand)/self.resistance

    @property
    def passed(self): return math.isfinite(self.ratio) and self.ratio <= 1+1e-10


@dataclass
class Issue:
    severity: str
    text: str
    reference: str = "Geometria e domínio do modelo"
    origin: str = "model"

    @property
    def origin_label(self):
        return {"data":"Dado do detalhamento", "model":"Limite do modelo", "configuration":"Configuração"}.get(self.origin,self.origin)


@dataclass
class Result:
    checks: list[Check] = field(default_factory=list)
    actual: list[Check] = field(default_factory=list)
    issues: list[Issue] = field(default_factory=list)
    geometry: dict = field(default_factory=dict)
    minimum_factor: float = 1.0

    @property
    def calculation_note(self):
        notes=[]
        if any(i.severity=='noncompliance' for i in self.issues):
            notes.append('Cálculo disponível com requisito de detalhamento não atendido; a continuidade do cálculo não aprova o detalhe.')
        if any(i.severity=='extrapolation' for i in self.issues):
            notes.append('Resultados calculados com extrapolação do modelo. Os índices não confirmam, por si, a resistência nem a classificação de rigidez da configuração fora do domínio validado; conferir as ressalvas nas premissas.')
        return ' '.join(notes)

    @property
    def status(self):
        if any(x.severity=="error" for x in self.issues):return "GEOMETRIA INVÁLIDA"
        if any(not c.passed for c in self.checks):return "NÃO ATENDE"
        if any(x.severity=="noncompliance" for x in self.issues):return "NÃO ATENDE AO DETALHAMENTO"
        if any(x.severity=="extrapolation" for x in self.issues):return "CÁLCULO COM RESSALVAS · EXTRAPOLAÇÃO DO MODELO"
        if any(x.severity=="pending" for x in self.issues):return "REVISAR CONDIÇÕES DE APLICAÇÃO"
        if not self.checks:return "SEM VERIFICAÇÕES DE RESISTÊNCIA"
        if any(x.severity=="interference" for x in self.issues):return "CÁLCULO ATENDE · CONFERIR INTERFERÊNCIAS"
        return "ATENDE ÀS VERIFICAÇÕES REALIZADAS"

    @property
    def governing(self):
        rows=[x for x in self.checks if x.category=='Resistência']
        return max(rows,key=lambda x:x.ratio) if rows else None


class SinglePlateCheck(Check):
    """Presentation policy scoped to Single plate; shared Check remains unchanged."""
    @property
    def numerically_valid(self):
        return (math.isfinite(self.demand) and math.isfinite(self.resistance)
                and self.resistance>0 and math.isfinite(self.ratio))

    @property
    def summary_visible(self):
        return self.id not in ('plate_vy','plate_vu','plate_ny','plate_nu','plate_mu','plate_ltb')

    @property
    def applicable(self):
        # These complete axial paths have no demand when N=0. Partial-column
        # paths can still be loaded by the bolt-group moment and remain active.
        return not (self.id in ('beam_n','block_plate_u','block_beam_u','plate_ny','plate_nu') and self.demand==0 and math.isfinite(self.resistance) and self.resistance>0)

    @property
    def outcome(self):
        if not self.numerically_valid:return 'Falha numérica · sem conclusão'
        if not self.applicable:return 'N/A · sem tração axial'
        if self.category=='Condição do método':
            return 'Condição satisfeita' if self.passed else 'Condição não satisfeita'
        return 'Atende' if self.passed else 'Não atende'


class SinglePlateFullDepthWeldCheck(SinglePlateCheck):
    """A rigid-part weld allocation does not prove the complete joint."""
    @property
    def outcome(self):
        if not self.numerically_valid:return 'Falha numérica · sem conclusão'
        return 'Atende à hipótese elástica' if self.passed else 'Não atende à hipótese elástica'


class SinglePlateNominalReferenceCheck(SinglePlateCheck):
    """Legacy rectangular-plate component envelope, not a three-edge failure."""
    @property
    def outcome(self):
        if not self.numerically_valid:return 'Falha numérica · sem conclusão'
        if not self.applicable:return 'N/A · sem tração axial'
        return 'Atende à referência retangular nominal' if self.passed else 'Não atende à referência retangular nominal'


@dataclass
class SinglePlateResult(Result):
    """Conclusion semantics for the existing Single plate family only."""
    full_depth_weld_group: dict | None = None
    actual_full_depth_weld_group: dict | None = None
    @property
    def method_provenance_note(self):
        if self.full_depth_weld_group is not None:
            return ('Rastreabilidade do grupo de três bordas: método elástico de linhas do AISC Manual 15ª edição, páginas 8-12/8-13; ponderação analítica declarada por áreas de gargantas distintas. A resistência local das soldas usa a NBR 8800:2024 corrigida 2025, 6.2.5 e Tabela 9. A hipótese de chapa e receptores rígidos não demonstra a transferência/redistribuição ou estabilidade da chapa, o metal-base, a capacidade dos receptores nem a capacidade de rotação. As referências retangulares nominais são verificações separadas e não qualificam o conjunto de três bordas.')
        return ('Rastreabilidade do método: os exemplos II.A-17B, II.A-19A e II.A-19B do P901-23W foram conferidos e sustentam N+V, duas colunas, detalhes estendidos, a hierarquia explícita e as hipóteses de contenção. Permanece a confirmar o domínio completo da dispensa automática de ductilidade: a Tabela 10-9 e sua discussão no Manual devem confirmar os intervalos de linhas, materiais e geometrias cobertos, inclusive a aplicação do atalho a detalhes estendidos ou de duas colunas. O procedimento existente é preservado sem inventar uma restrição; essa ressalva de aplicabilidade não é uma falha resistente demonstrada.')

    @property
    def summary_checks(self):
        return [x for x in self.checks if x.summary_visible]

    @property
    def actual_summary(self):
        return [x for x in self.actual if x.summary_visible]

    @property
    def resistance_failures(self):
        return [x for x in self.checks if x.numerically_valid and x.applicable and x.category=='Resistência' and not x.passed and not isinstance(x,(SinglePlateFullDepthWeldCheck,SinglePlateNominalReferenceCheck))]

    @property
    def conditional_model_failures(self):
        return [x for x in self.checks if x.numerically_valid and x.applicable and not x.passed and isinstance(x,(SinglePlateFullDepthWeldCheck,SinglePlateNominalReferenceCheck))]

    @property
    def method_failures(self):
        return [x for x in self.checks if x.numerically_valid and x.applicable and x.category=='Condição do método' and not x.passed and not isinstance(x,SinglePlateNominalReferenceCheck)]

    @property
    def numeric_failures(self):
        return [x for x in self.checks if not x.numerically_valid]

    @property
    def local_scope_issues(self):
        return [i for i in self.issues if i.origin=='local_scope']

    @property
    def coverage_note(self):
        parts=[]
        if self.numeric_failures:
            parts.append('Falha numérica: '+', '.join(x.name for x in self.numeric_failures)+'. Capacidade ou relação inválida; sem conclusão resistente para esses itens.')
        if self.resistance_failures:
            parts.append('Resistência local não atendida: '+', '.join(x.name for x in self.resistance_failures)+'.')
        if self.method_failures:
            parts.append('Condições do método não satisfeitas: '+', '.join(x.name for x in self.method_failures)+'. Esses limites de hierarquia não são capacidades sob a força aplicada.')
        if self.conditional_model_failures:
            parts.append('Modelo local condicionado não atendido: '+', '.join(x.name for x in self.conditional_model_failures)+'. O resultado depende da hipótese elástica ou da referência retangular nominal; não demonstra isoladamente falha física do conjunto de três bordas.')
        parts.extend(i.text for i in self.local_scope_issues)
        if any(i.severity=='noncompliance' for i in self.issues):parts.append('Há requisito de detalhamento não atendido.')
        if any(i.severity=='pending' and i.origin=='data' for i in self.issues):parts.append('Falta dado necessário para concluir o mecanismo local indicado.')
        parts.extend(i.text for i in self.issues if i.severity=='outside_method')
        return ' '.join(parts)

    @property
    def status(self):
        errors=[x for x in self.issues if x.severity=='error']
        if errors:
            if any(x.origin=='numeric' for x in errors):return 'FALHA NUMÉRICA · REVISAR ENTRADA'
            if any(x.origin=='material' for x in errors):return 'MATERIAL FORA DO DOMÍNIO'
            return 'GEOMETRIA INVÁLIDA'
        if self.numeric_failures:
            return 'FALHA NUMÉRICA · REVISAR ENTRADA'
        if self.resistance_failures:return 'NÃO ATENDE'
        if self.method_failures:return 'CONDIÇÕES DO MÉTODO NÃO SATISFEITAS'
        if self.conditional_model_failures:return 'MODELO LOCAL CONDICIONADO NÃO ATENDIDO · ESCOPO INCOMPLETO'
        if any(x.severity=='noncompliance' for x in self.issues):return 'NÃO ATENDE AO DETALHAMENTO'
        if any(x.severity=='outside_method' for x in self.issues):return 'FORA DO MÉTODO'
        if any(x.severity=='extrapolation' for x in self.issues):return 'CÁLCULO COM RESSALVAS · EXTRAPOLAÇÃO DO MODELO'
        if any(x.severity=='pending' and x.origin=='data' for x in self.issues):return 'DADOS NECESSÁRIOS AUSENTES'
        if any(x.severity=='pending' for x in self.issues):return 'REVISAR CONDIÇÕES DE APLICAÇÃO'
        if not self.checks:return 'SEM VERIFICAÇÕES DE RESISTÊNCIA'
        if self.local_scope_issues:return 'VERIFICAÇÕES LOCAIS ATENDEM · ESCOPO INCOMPLETO'
        if any(x.severity=='interference' for x in self.issues):return 'CÁLCULO ATENDE · CONFERIR INTERFERÊNCIAS'
        return 'ATENDE ÀS VERIFICAÇÕES REALIZADAS'

    @property
    def governing(self):
        rows=[x for x in self.summary_checks if x.numerically_valid and x.applicable and x.category=='Resistência']
        return max(rows,key=lambda x:x.ratio) if rows else None
