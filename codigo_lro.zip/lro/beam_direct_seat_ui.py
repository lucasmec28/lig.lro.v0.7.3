"""Separate direct-seat diagnostic route; native legacy projects stay untouched."""
from dataclasses import fields
import json
import math
from pathlib import Path

import pandas as pd
import streamlit as st

from . import beam_direct_seat as core
from .beam_direct_seat_presentation import HEADERS, checks_rows, STATUS, SCOPE_NAMES, fmt
from .beam_direct_seat_drawing import create_svg
from .display_precision import display_frame, display_format, display_tree, number_input
from .models import KGF, Profile, STEELS, profiles

PREFIX = 'bdsl_'
STATE = '_beam_direct_seat_local_'
CUSTOM = 'W personalizado'
P = {name: p for name, p in profiles().items() if p.family == 'W'}
PRESETS = core.presets()
PROFILE_VALUES = ('d', 'bf', 'tw', 'tf', 'clear', 'area', 'mass')
LOAD_UNITS = {'V': KGF, 'N': KGF, 'applied_moment_y': KGF * 1000, 'torsion': KGF * 1000}
LOAD_KEYS = {'V': 'V_kgf', 'N': 'N_kgf', 'applied_moment_y': 'My_kgfm', 'torsion': 'Tz_kgfm'}
EXTERNAL_METADATA = ('external_length_reported_mm', 'external_support_node', 'external_bracing_record')


def _draft_keys():
    keys = [PREFIX + f.name for f in fields(core.BeamDirectSeat) if f.name not in ('beam', 'support')]
    keys += [PREFIX + key for key in LOAD_KEYS.values()]
    for role in ('beam', 'support'):
        keys += [PREFIX + role + '_' + key for key in ('name', 'manual_name', 'family', 'source') + PROFILE_VALUES]
    return keys


def _finite(value):
    try:
        return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)
    except OverflowError:
        return False


def _widget_float(value, name):
    converted = float(value)
    if not math.isfinite(converted) or converted != value:
        raise ValueError(f'{name}: valor não representável sem alteração no controle.')
    return converted


def _proposed_ui_state(c):
    """Validate every imported field before any session mutation."""
    c.to_dict()
    proposed = {}
    for f in fields(c):
        if f.name in ('beam', 'support'):
            continue
        value = getattr(c, f.name)
        if isinstance(value, (int, float)) and not isinstance(value, bool) and f.name not in LOAD_UNITS:
            value = _widget_float(value, f.name)
        proposed[PREFIX + f.name] = value
    for key, unit in LOAD_UNITS.items():
        shown = getattr(c, key) / unit
        if not _finite(shown):
            raise ValueError(key + ': ação não representável no controle em kgf / kgf·m.')
        proposed[PREFIX + LOAD_KEYS[key]] = shown
    for role in ('beam', 'support'):
        p = getattr(c, role)
        prefix = PREFIX + role + '_'
        proposed[prefix + 'name'] = p.name if p.name in P and p == P[p.name] else CUSTOM
        for key, value in (('manual_name', p.name), ('family', p.family), ('source', p.source)):
            proposed[prefix + key] = value
        for key in PROFILE_VALUES:
            proposed[prefix + key] = _widget_float(getattr(p, key), role + '.' + key)
    return proposed


def seed(c):
    proposed = _proposed_ui_state(c)
    st.session_state.update(proposed)
    st.session_state[STATE + 'rotation_basis'] = _physical_signature(proposed)
    st.session_state.pop(STATE + 'rotation_reconfirm', None)
    st.session_state.pop(STATE + 'ui_draft', None)


def use_example():
    seed(PRESETS[st.session_state[PREFIX + 'example']])
    st.session_state.pop(PREFIX + 'import_error', None)


def _unique_object(pairs):
    data = {}
    for key, value in pairs:
        if key in data:
            raise ValueError('Campo JSON duplicado: ' + str(key))
        data[key] = value
    return data


def load_project():
    try:
        upload = st.session_state[PREFIX + 'upload']
        if upload is None:
            raise ValueError('Selecione um arquivo JSON desta família.')
        payload = upload.getvalue()
        if len(payload) > 200000:
            raise ValueError('Arquivo maior que 200 kB.')
        c = core.BeamDirectSeat.from_dict(json.loads(payload, object_pairs_hook=_unique_object))
        seed(c)
        st.session_state.pop(PREFIX + 'import_error', None)
    except (ValueError, TypeError, KeyError, OverflowError) as exc:
        st.session_state[PREFIX + 'import_error'] = 'Não foi possível abrir: ' + str(exc)


def _select(label, options, key):
    choices = list(options)
    current = st.session_state.get(key)
    if current is not None and current not in choices:
        choices.append(current)
    return st.selectbox(label, choices, key=key)


def _dimension(key, label, signed=False, optional=False):
    kwargs = {} if signed else {'min_value': 0.}
    if optional:
        kwargs['value'] = None
    return number_input(label + ' (mm)' + (' — em branco = desconhecido' if optional else ''),
                        key=PREFIX + key, **kwargs)


def _profile(role, title):
    prefix = PREFIX + role + '_'
    name = st.selectbox(title, [CUSTOM] + list(P), key=prefix + 'name')
    if name in P:
        p = P[name]
    else:
        with st.expander('Geometria personalizada — ' + title, expanded=True):
            designation = st.text_input('Designação — ' + title, key=prefix + 'manual_name')
            family = st.text_input('Família declarada — ' + title, key=prefix + 'family')
            values = {key: number_input(label + ' — ' + title, min_value=0., key=prefix + key)
                      for key, label in (('d', 'Altura d (mm)'), ('bf', 'Largura bf (mm)'),
                                         ('tw', 'Alma tw (mm)'), ('tf', 'Mesa tf (mm)'),
                                         ('clear', 'Altura livre das raízes (mm)'),
                                         ('area', 'Área A (mm²)'), ('mass', 'Massa linear (kg/m)'))}
            source = st.text_input('Fonte das dimensões/área — ' + title, key=prefix + 'source')
            p = Profile(designation, family, source=source, **values)
    st.caption(f'd={display_format(p.d)}; bf={display_format(p.bf)}; '
               f'tw={display_format(p.tw)}; tf={display_format(p.tf)} mm.')
    return p


def _force(key):
    raw, shown = st.session_state[PREFIX + key], st.session_state[PREFIX + LOAD_KEYS[key]]
    if not _finite(raw) or not _finite(shown):
        raise ValueError(key + ': ação finita obrigatória.')
    if shown == raw / LOAD_UNITS[key]:
        return raw
    converted = shown * LOAD_UNITS[key]
    if not _finite(converted):
        raise ArithmeticError(key + ': transbordamento na conversão para N / N mm.')
    return converted


def _physical_signature(state):
    excluded = {PREFIX + key for key in ('project', 'notes', 'rotational_detail_confirmed', *EXTERNAL_METADATA)}
    force_keys = {PREFIX + key for key in (*LOAD_UNITS, *LOAD_KEYS.values())}
    basis = {key: state.get(key) for key in sorted(set(_draft_keys()) - excluded - force_keys)}
    for key, unit in LOAD_UNITS.items():
        raw, shown = state.get(PREFIX + key), state.get(PREFIX + LOAD_KEYS[key])
        try:
            basis['canonical_' + key] = raw if shown == raw / unit else shown * unit
        except (TypeError, ValueError, ArithmeticError):
            basis['canonical_' + key] = {'raw': raw, 'shown': shown}
    return json.dumps(basis, sort_keys=True, ensure_ascii=False)


def _failure(exc):
    st.session_state.pop(STATE + 'project', None)
    st.session_state[STATE + 'result'] = {'status': 'INVALID_INPUT', 'global_pass': False,
                                         'checks': [], 'diagnosis': str(exc)}
    st.error('Entrada inválida: ' + str(exc))
    st.caption('Corrija a entrada para recalcular e exportar o projeto atual.')


def render():
    s = st.session_state
    if PREFIX + 'project' not in s:
        saved, draft = s.get(STATE + 'project'), s.get(STATE + 'ui_draft')
        seed(core.BeamDirectSeat.from_dict(saved) if saved else next(iter(PRESETS.values())))
        if draft:
            s.update(draft)
    current_basis = _physical_signature(s)
    if (s.get(STATE + 'rotation_basis') != current_basis
            and s.get(PREFIX + 'rotational_detail_confirmed')):
        s[PREFIX + 'rotational_detail_confirmed'] = False
        s[STATE + 'rotation_reconfirm'] = True
    s[STATE + 'rotation_basis'] = current_basis
    for key in _draft_keys():
        if key in s:
            s[key] = s[key]
    with st.sidebar:
        st.caption(core.COMPONENT_VERSION)
        st.selectbox('Exemplo de apoio direto', list(PRESETS), key=PREFIX + 'example')
        st.button('Usar exemplo de apoio direto', on_click=use_example, use_container_width=True)
        st.file_uploader('Abrir projeto de apoio direto', type=['json'], key=PREFIX + 'upload')
        st.button('Carregar apoio direto', on_click=load_project, use_container_width=True)
        if PREFIX + 'import_error' in s:
            st.error(s[PREFIX + 'import_error'])
    st.title(core.FAMILY)
    st.caption('Mesa inferior da W superior sobre a mesa superior da W de apoio, sem chapa intermediária. Diagnóstico local de gravidade '
               'centrada; os parafusos verticais não recebem V/4 como cortante.')
    st.info('Projeto local ASI DG6 A1(c)/A3. Estabilidade, vínculos e cortante global da viga de apoio pertencem ao projeto estrutural externo.')
    st.caption('As dimensões e condições iniciais descrevem uma proposta. Não atestam superfícies '
               'preparadas, contato ajustado, montagem ou comportamento executados.')
    st.text_input('Identificação do projeto de apoio direto', key=PREFIX + 'project')
    left, right = st.columns([.9, 1.5], gap='large')
    with left:
        beam = _profile('beam', 'Viga superior W')
        support = _profile('support', 'Viga de apoio W')
        st.subheader('Ações simultâneas na referência informada')
        number_input('V descendente já majorado (kgf)', key=PREFIX + 'V_kgf')
        st.caption('Premissa deste modelo: N = My = Tz = x = 0. Ações importadas fora do domínio são preservadas.')
        outside = any(s.get(PREFIX+k) is None or s.get(PREFIX+k) != 0 for k in ('N_kgf','My_kgfm','Tz_kgfm','reference_x'))
        with st.expander('Ações fora do modelo / dados importados', expanded=outside):
            number_input('N no eixo da viga superior, com sinal (kgf)', key=PREFIX + 'N_kgf')
            number_input('My aplicado na referência (kgf·m)', key=PREFIX + 'My_kgfm')
            number_input('Tz aplicado no plano dos parafusos (kgf·m)', key=PREFIX + 'Tz_kgfm')
            _dimension('reference_x', 'x da referência das ações ao eixo do apoio', signed=True, optional=True)
            st.caption('Os valores importados são preservados. N, My ou Tz não nulos permanecem '
                       'registrados e podem colocar o caso fora do domínio de gravidade centrada.')
        with st.expander('Contato direto e extremidade física', expanded=True):
            _dimension('end', 'Eixo da alma W inferior até o fim físico da W superior')
            _dimension('beam_radius', 'Raio de concordância nominal da W superior')
            _dimension('support_radius', 'Raio de concordância nominal da W inferior')
            st.text_input('Fonte dos raios e conferência dimensional', key=PREFIX + 'radius_source')
            st.checkbox('Especificar preparo das faces de contato direto', key=PREFIX + 'direct_bearing_faces_prepared')
            st.caption('A extremidade física e a referência das ações são cotas independentes. '
                       'A especificação de preparo precisa ser comprovada no detalhe e na execução.')
        with st.expander('Quatro parafusos, furos circulares e arruelas', expanded=True):
            _dimension('db', 'Diâmetro nominal dos parafusos')
            _dimension('bolt_pitch', 'Passo no eixo da W superior')
            _dimension('bolt_gauge', 'Gabarito no eixo da W inferior')
            _dimension('upper_hole', 'Diâmetro dos furos circulares na mesa inferior da W superior')
            _dimension('support_hole', 'Diâmetro dos furos circulares na mesa superior da W de apoio')
            for key, label in (('upper_washer_diameter', 'Arruela acima da mesa inferior da W superior — diâmetro externo'),
                               ('lower_washer_diameter', 'Arruela sob a mesa superior da W de apoio — diâmetro externo'),
                               ('tool_radius', 'Raio externo real do soquete/ferramenta'),
                               ('clearance', 'Folga adicional para montagem')):
                _dimension(key, label)
            st.caption('Furos circulares nas duas mesas e arruelas circulares. Conferir ferragem, '
                       'aperto e acesso reais. Este detalhe não demonstra liberação axial da viga; '
                       'se o projeto estrutural exigir essa liberação, a montagem precisa ser compatível.')
        with st.expander('Par inferior — detalhe construtivo sem crédito resistente', expanded=True):
            for key, label in (('stiff_thickness', 'Espessura de cada enrijecedor'),
                               ('stiff_width', 'Largura saliente de cada enrijecedor'),
                               ('stiff_height', 'Altura de cada enrijecedor'),
                               ('stiff_clip', 'Recorte de concordância'),
                               ('stiff_weld', 'Perna da solda do enrijecedor'),
                               ('stiff_weld_length', 'Comprimento útil declarado da solda')):
                _dimension(key, label)
            _dimension('stiff_y', 'Posição do par no eixo da W inferior', signed=True)
            for key, label in (('fitted_required', 'Exigir contato ajustado dos enrijecedores com a mesa superior da W de apoio'),
                               ('web_attached', 'Especificar ligação dos enrijecedores à alma da W de apoio'),
                               ('loaded_flange_attached', 'Especificar ligação à mesa superior carregada da W de apoio'),
                               ('full_height_attached_both', 'Especificar altura completa e ligação às duas mesas da W de apoio')):
                st.checkbox(label, key=PREFIX + key)
            st.caption('O par inferior informado é somente detalhe construtivo: '
                       'não está dimensionado e não recebe crédito resistente '
                       'neste diagnóstico. Os campos descrevem a proposta atual. O par não comprova '
                       'contenção longitudinal local da W superior, rotação ou estabilidade do sistema.')
        with st.expander('Materiais independentes'):
            for key, label in (('beam_steel', 'Aço da W superior'), ('support_steel', 'Aço da W de apoio'),
                               ('stiffener_steel', 'Aço dos enrijecedores')):
                _select(label, STEELS, PREFIX + key)
        with st.expander('Premissas externas informadas — somente registro', expanded=False):
            st.write('Comprimento externo informado (mm):', display_format(s[PREFIX + 'external_length_reported_mm']))
            st.write('Nó de apoio informado:', s[PREFIX + 'external_support_node'])
            st.write('Registro de contraventamentos:', s[PREFIX + 'external_bracing_record'])
            st.caption('Informações do caso externo: 4 m e nó interno central no exemplo. '
                       'Não definem vão, comprimento ℓ de cálculo, contenção longitudinal local '
                       'comprovada ou compatibilidade de rotação. O registro é preservado no JSON '
                       'sem produzir crédito resistente ou declaração de vínculo.')
        with st.expander('Rotação e montagem do detalhe real', expanded=False):
            if s.get(STATE + 'rotation_reconfirm') and not s[PREFIX + 'rotational_detail_confirmed']:
                st.info('Uma entrada do caso foi alterada. Confira novamente a compatibilidade '
                        'de rotação para o detalhe atual.')
            st.checkbox('Compatibilidade de rotação conferida para o detalhe atual',
                        key=PREFIX + 'rotational_detail_confirmed')
            st.caption('Esta declaração não impõe uma rótula ideal nem certifica aperto, retenção '
                       'ou liberação axial. A pendência de rotação não é uma falha resistente demonstrada.')
        st.text_area('Observações e proveniência do caso', key=PREFIX + 'notes')
    s[STATE + 'ui_draft'] = {key: s[key] for key in _draft_keys() if key in s}
    try:
        values = {f.name: s[PREFIX + f.name] for f in fields(core.BeamDirectSeat)
                  if f.name not in ('beam', 'support', *LOAD_UNITS)}
        c = core.BeamDirectSeat(beam=beam, support=support,
                                **{key: _force(key) for key in LOAD_UNITS}, **values)
        native = c.to_dict()
        encoded = json.dumps(native, ensure_ascii=False, indent=2, allow_nan=False)
        result = core.evaluate(c)
    except (ArithmeticError, ValueError, TypeError, KeyError) as exc:
        with right:
            _failure(exc)
        return
    s[STATE + 'project'] = native
    s[STATE + 'result'] = result
    with right:
        st.caption('Resistências locais pelo ASI DG6; verificações NBR suplementares exibidas separadamente.')
        specified = lambda flag: 'especificado' if flag else 'não especificado'
        st.caption('Especificação proposta a conferir na execução: contato ajustado dos enrijecedores — '
                   + specified(c.fitted_required) + '; preparo das faces de contato direto — '
                   + specified(c.direct_bearing_faces_prepared) + '; ligação à alma da W de apoio — '
                   + specified(c.web_attached) + '; ligação à mesa superior carregada da W de apoio — '
                   + specified(c.loaded_flange_attached) + '; altura completa e ligação às duas mesas da W de apoio — '
                   + specified(c.full_height_attached_both) + '. Aços propostos: W superior — '
                   + c.beam_steel + '; W de apoio — ' + c.support_steel + '; enrijecedores — '
                   + c.stiffener_steel + '.')
        with st.expander('Croqui atual — planta e vista lateral', expanded=True):
            st.image(create_svg(c), width='stretch')
            st.caption('Dimensões dos dados atuais; trechos das vigas interrompidos. Croqui de conferência, não desenho de fabricação.')
        st.caption('Par inferior: detalhe construtivo não dimensionado e sem crédito resistente. '
                   'Não é calculada capacidade de compressão da barra recortada, contato ajustado '
                   'ou resistência das suas soldas neste diagnóstico.')
        (st.success if result.get('local_connection_qualified') else st.error)(result.get('diagnosis', result.get('status', '')))
        st.metric('Verificações locais de gravidade',
                  'Atendidas no escopo local' if result.get('local_checks_satisfied') else 'Não atendidas / não concluídas')
        checks = result.get('checks') or []
        st.subheader('ASI DG6 A3 — resistências locais das almas')
        st.metric('Verificações resistentes implementadas',
                  'Atendidas no escopo local' if result.get('local_strength_checks_satisfied') else 'Não atendidas / não calculadas')
        resistance = [row for row in checks if row.get('category') == 'RESISTANCE']
        if resistance:
            st.dataframe(pd.DataFrame(checks_rows(resistance), columns=HEADERS), hide_index=True, width='stretch')
        st.subheader('Geometria do detalhe')
        st.metric('Condições geométricas implementadas',
                  'Atendidas' if result.get('local_geometry_checks_satisfied') else 'Não atendidas / não calculadas')
        geometry = [row for row in checks if row.get('category') == 'GEOMETRY']
        if geometry:
            with st.expander('Conferir furos, bordas, montagem e enrijecedores', expanded=False):
                st.dataframe(pd.DataFrame(checks_rows(geometry), columns=HEADERS), hide_index=True, width='stretch')
        with st.expander('Condições do método e ações atuais', expanded=True):
            st.write('Preparo das faces de contato: ' + specified(c.direct_bearing_faces_prepared))
            st.write('Reação ELU: ' + fmt(c.V / 1000) + ' kN; fator adicional: 1,00.')
            st.write('N, My, Tz e afastamento da referência iguais a zero; eixos das vigas ortogonais.')
            st.caption('A conferência de rotação e o projeto global permanecem externos ao resultado local.')
        with st.expander('Suplemento NBR — resultado independente', expanded=False):
            nbr = [row for row in checks if row.get('category') == 'NBR_SUPPLEMENT']
            st.dataframe(pd.DataFrame(checks_rows(nbr), columns=HEADERS), hide_index=True, width='stretch')
            st.caption('Limites inferiores conservadores de escoamento e enrugamento locais da alma, com demanda mínima de 45 kN. Não são somados às resistências DG6 nem substituem seu resultado. Sem crédito de enrijecedores.')
        with st.expander('Equações e referências', expanded=False):
            for row in checks:
                if row.get('category') in ('RESISTANCE', 'NBR_SUPPLEMENT'):
                    st.write(row['name'] + ': ' + row['equation'])
                    st.caption(row['reference'] + '. ' + row['notes'].replace('footprint', 'área de contato'))
        with st.expander('Condições externas — verificação independente', expanded=False):
            for scope in result.get('scopes', []):
                st.write(SCOPE_NAMES.get(scope['id'], 'Condição') + ': ' + STATUS.get(scope['status'], 'Pendente'))
                st.caption(scope['notes'])
            external = [row for row in checks if row.get('category') == 'EXTERNAL_CAPACITY']
            st.dataframe(pd.DataFrame(checks_rows(external), columns=HEADERS), hide_index=True, width='stretch')
            st.caption('Va e Vb inferiores são apenas capacidades de seção; a reação isolada não substitui o cortante total do painel. Estabilidade global fora deste módulo.')
        st.caption('Apoio direto e estados locais não certificam liberação axial, rotação, estabilidade global '
                   'ou fabricação. O resultado ATENDE refere-se ao escopo local calculado.')
    st.download_button('Salvar projeto de apoio direto .json', encoded,
                       'apoio_direto_furos_circulares.json', 'application/json')

    from .beam_direct_seat_report import create_report, create_mc_excerpt
    if result.get('checks'):
        st.download_button('Baixar memória de apoio direto .docx', create_report(c),
                           'memoria_apoio_direto_DG6.docx',
                           'application/vnd.openxmlformats-officedocument.wordprocessingml.document')

    if result.get('checks'):
        # Expensive drawing/Word generation only on request; never reuse stale inputs.
        saved_excerpt=st.session_state.get('direct_seat_mc_excerpt')
        if saved_excerpt and saved_excerpt[0]!=encoded:
            st.session_state.pop('direct_seat_mc_excerpt',None)
        if st.button('Gerar trecho para MC',key='direct_seat_generate_mc_excerpt'):
            st.session_state['direct_seat_mc_excerpt']=(encoded,create_mc_excerpt(c))
        saved_excerpt=st.session_state.get('direct_seat_mc_excerpt')
        if saved_excerpt and saved_excerpt[0]==encoded:
            st.download_button('Baixar trecho para MC .docx', saved_excerpt[1],
                               'Trecho_MC_apoio_direto_LRO.docx',
                               'application/vnd.openxmlformats-officedocument.wordprocessingml.document')
        st.caption('Trecho editável e compacto com croqui, dados e resultados atuais. A memória completa mantém as demonstrações complementares.')
        st.download_button('Baixar verificações de apoio direto CSV',
                           pd.DataFrame(checks_rows(result['checks']), columns=HEADERS).to_csv(index=False).encode('utf-8-sig'),
                           'Verificacoes_apoio_direto_LRO.csv', 'text/csv')
        st.download_button('Baixar croqui de apoio direto SVG', create_svg(c),
                           'Croqui_apoio_direto_LRO.svg', 'image/svg+xml')
