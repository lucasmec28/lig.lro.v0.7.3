"""Verified local column weld components; never an assembly approval.

The automatic pure-uplift Type 2 generator preserves DG1 Ex4.7-3 web strips.
A separate, explicitly qualified two-flange N/M + web-V component is available
for both families. NBR 8800:2024 corrected 2025 supplies resistance factors;
arbitrary flexible-plate effectiveness is never inferred from statics alone.
"""
from dataclasses import dataclass, fields
import math

from .models import Issue, STEELS, finite_real
from .base_plate_details import fillet_dimensions

REF = 'NBR 8800:2024 corrigida 2025, 6.2 e 6.5; AISC DG1 3ª ed., exemplo 4.7-3'
MODEL = 'type2_uplift_web_strips'
MODEL_QUALIFIED = 'two_flange_normal_web_shear'
G1, G2, FW = 1.10, 1.35, 485.0
SUPPORTED_STEELS = frozenset(('ASTM A36', 'ASTM A572 Gr.42', 'ASTM A572 Gr.50',
                              'ASTM A572 Gr.55', 'ASTM A992'))
WELDED_FAMILIES = frozenset(('CS', 'CVS', 'VS', 'Soldado'))
LIMITS = ('Verificações locais calculadas não aprovam a ligação pilar–placa: '
          'transferência e ruptura local do metal-base junto à fusão na placa, '
          'interação flexão–cisalhamento da placa, região dos furos/arruelas e '
          'caminho completo à ancoragem permanecem a verificar. Não se demonstra '
          'rigidez rotacional nem resistência geral N/M/V.')


@dataclass
class ColumnBaseWeld:
    model: str = 'off'
    column_steel: str = 'unspecified'
    process: str = 'unspecified'
    web_length: float = 0.0
    procedure_ref: str = ''
    detail_confirmed: bool = False
    cjp_detail: str = 'unspecified'
    cjp_charpy_confirmed: bool = False
    base_charpy_confirmed: bool = False
    inspection_ref: str = ''
    flange_length: float = 0.0
    flange_effective_length: float = 0.0
    web_effective_length: float = 0.0
    qualification_method: str = 'unspecified'
    transfer_ref: str = ''
    allocation_basis: str = ''
    effective_length_basis: str = ''
    execution_ref: str = ''
    qualification_signature: str = ''
    normal_transfer: str = 'welded'
    bearing_area: float = 0.0
    bearing_ref: str = ''
    bearing_basis: str = ''

    @classmethod
    def from_dict(cls, data):
        if not isinstance(data, dict):
            raise ValueError('Dados da solda pilar–placa devem ser um objeto.')
        unknown = set(data) - {f.name for f in fields(cls)}
        if unknown:
            raise ValueError('Campos não reconhecidos na solda pilar–placa: ' + ', '.join(sorted(unknown)))
        return cls(**data)


def _number(value, name, low=1e-6, high=1e6):
    if not finite_real(value) or not low <= value <= high:
        raise ValueError(name + ': valor fora do domínio numérico finito.')
    return float(value)


def fillet_line_resistance(leg, fw=FW):
    """NBR Table 9 default, N/mm. No directional or penetration credit."""
    leg = _number(leg, 'Perna do filete')
    fw = _number(fw, 'Resistência do eletrodo')
    return .6 * fw * (leg / math.sqrt(2)) / G2


def cjp_resistance(length, t_column, tp, fy_column, fy_plate):
    """One qualified CJP effective section, not two web-face welds."""
    vals = [_number(v, name) for v, name in zip(
        (length, t_column, tp, fy_column, fy_plate),
        ('Comprimento CJP', 'Espessura do pilar', 'Espessura da placa', 'fy pilar', 'fy placa'))]
    length, t_column, tp, fy_column, fy_plate = vals
    area = length * min(t_column, tp)
    normal = area * min(fy_column, fy_plate) / G1
    return {'A_MB_mm2': area, 'R_normal_N': normal, 'R_shear_N': .6 * normal}


def type2_uplift_values(N, a2, tw, web_length, tp, fy_column, fu_column, fy_plate, fu_plate):
    """Exact pure-uplift web-strip field and independent local resistances.

    Geometric containment in the real column, fabrication and material gates
    are the caller's responsibility. Invalid containment in web_length raises.
    """
    if not finite_real(N) or not -1e12 <= N < 0:
        raise ValueError('O campo de faixas exige N<0 finito, em N, e tração pura.')
    vals = [_number(v, name) for v, name in zip(
        (a2, tw, web_length, tp, fy_column, fu_column, fy_plate, fu_plate),
        ('a2', 'tw', 'Comprimento real de solda', 'tp', 'fy pilar', 'fu pilar', 'fy placa', 'fu placa'))]
    a2, tw, web_length, tp, fy_column, fu_column, fy_plate, fu_plate = vals
    if a2 <= tw:
        raise ValueError('Os chumbadores devem estar fora das faces da alma: a2>tw.')
    if fu_column < fy_column or fu_plate < fy_plate:
        raise ValueError('A resistência última não pode ser menor que fy.')
    e = (a2 - tw) / 2
    beff = 2 * e
    intervals = [[x - e, x + e] for x in (-a2 / 2, a2 / 2)]
    span = 2 * a2 - tw
    if span > web_length + 1e-8:
        raise ValueError('As faixas completas de 45° não cabem no comprimento real da solda da alma; não se recortam faixas.')
    rod = -N / 4
    qz = rod / beff
    m = rod * e / beff
    return {
        'e_mm': e, 'b_eff_mm': beff, 'intervals_mm': intervals, 'span_mm': span,
        'web_length_mm': web_length, 'T_per_rod_N': rod,
        'q_normal_one_face_N_per_mm': qz,
        'web_normal_line_N_per_mm': 2 * qz,
        'web_stress_MPa': 2 * qz / tw,
        'web_yield_Rd_MPa': fy_column / G1,
        'web_rupture_Rd_MPa': fu_column / G2,
        'web_yield_utilization': 2 * qz / (tw * fy_column / G1),
        'web_rupture_utilization': 2 * qz / (tw * fu_column / G2),
        'm_plate_Nmm_per_mm': m,
        'm_plate_Rd_Nmm_per_mm': fy_plate * tp ** 2 / (4 * G1),
        't_plate_plastic_req_mm': math.sqrt(4 * m * G1 / fy_plate),
        'plate_strip_shear_yield_Rd_N_per_mm': .6 * fy_plate * tp / G1,
        'plate_strip_shear_rupture_Rd_N_per_mm': .6 * fu_plate * tp / G2,
        'normal_resultant_N': 4 * qz * beff,
        'moment_resultant_Nmm': 0.0,
    }


def validate_column_weld(c):
    u = getattr(c, 'column_weld', None)
    if not isinstance(u, ColumnBaseWeld):
        return [Issue('error', 'Dados inválidos da solda pilar–placa.', REF, origin='column_weld')]
    issues = []
    for name in ('model', 'column_steel', 'process', 'procedure_ref', 'cjp_detail', 'inspection_ref',
                 'qualification_method','transfer_ref','allocation_basis','effective_length_basis',
                 'execution_ref','qualification_signature','normal_transfer','bearing_ref','bearing_basis'):
        if not isinstance(getattr(u, name), str):
            issues.append(Issue('error', 'Campo textual inválido da solda pilar–placa: ' + name, REF, origin='column_weld'))
    active=u.model!='off'
    if not finite_real(u.web_length) or (active and not 0 <= u.web_length <= 1e6):
        issues.append(Issue('error', 'Comprimento real da solda da alma deve ser finito e não negativo.', REF, origin='column_weld'))
    for name in ('flange_length','flange_effective_length','web_effective_length','bearing_area'):
        if not finite_real(getattr(u,name)) or (active and not 0 <= getattr(u,name) <= 1e9):
            issues.append(Issue('error', 'Dimensão da solda/contato deve ser real finita e não negativa: '+name, REF, origin='column_weld'))
    if isinstance(u.normal_transfer,str) and u.normal_transfer not in ('welded','fit_bearing'):
        issues.append(Issue('error','Modo de transferência normal não reconhecido.',REF,origin='column_weld'))
    for name in ('detail_confirmed', 'cjp_charpy_confirmed', 'base_charpy_confirmed'):
        if type(getattr(u, name)) is not bool:
            issues.append(Issue('error', 'Confirmação da solda pilar–placa deve ser booleana: ' + name, REF, origin='column_weld'))
    return issues


def column_weld_assumptions(c):
    u = getattr(c, 'column_weld', None)
    if not isinstance(u, ColumnBaseWeld) or u.model == 'off':
        return []
    if u.model == MODEL_QUALIFIED:
        from .base_weld_qualified import assumptions
        return assumptions(c)
    return [
        'Solda pilar–placa: submodelo local de tração pura da base Tipo 2. Quatro barras internas simétricas; '
        'toda a tração transmitida por faixas de 45° à alma, sem crédito às mesas. '
        'Ações na face superior; exige N<0 e M=V=0. Não usa l0 como comprimento de solda.',
        'Comprimento informado é real, reto, contínuo e centrado; confirmação de detalhe declara exclusão '
        'de concordâncias, recortes, furos e interferências. Aço do pilar é independente do aço da placa. '
        'Filetes E7018 sem ganho direcional; CJP é uma única seção fundida, com procedimento e inspeção especificados.',
        LIMITS,
    ]


def add_column_weld_checks(c, r, add):
    """Append local component checks via the app's nine-argument callback.

    `status` is only the computed-components status. `complete` is always false
    and the explicit scope issue remains even when every local check passes.
    """
    validation = validate_column_weld(c)
    if validation:
        r.issues.extend(validation)
        return {'status': 'pending', 'connection_status': 'pending', 'complete': False,
                'statuses': {}, 'reasons': [i.text for i in validation]}
    u = c.column_weld
    if u.model == 'off':
        return {}
    if u.model == MODEL_QUALIFIED:
        from .base_weld_qualified import add_qualified_checks
        return add_qualified_checks(c,r,add)
    out = {'status': 'pending', 'connection_status': 'pending', 'complete': False,
           'statuses': {}, 'reasons': [], 'scope': LIMITS}
    reasons = out['reasons']
    def pending(text):
        reasons.append(text)
        r.issues.append(Issue('pending', text, REF, origin='column_weld'))
    def fail(text):
        reasons.append(text)
        r.issues.append(Issue('noncompliance', text, REF, origin='column_weld'))
        out['status'] = 'fail'
    if u.model != MODEL:
        pending('Modelo de solda pilar–placa não suportado.'); return out
    if getattr(c, 'model_type', None) != 2:
        pending('O campo de faixas internas aplica-se somente à base Tipo 2; não verifica N/M/V da base engastada.'); return out
    if any(not finite_real(getattr(c, key, None)) for key in ('N', 'M', 'V')):
        pending('Ações inválidas na face superior da placa.'); return out
    if c.N >= 0 or c.M != 0 or c.V != 0:
        pending('O campo de faixas exige tração pura: N<0, M=0 e V=0 na face superior. Demanda geral N/M/V não estabelecida.'); return out
    if getattr(c, 'stiffener_detail', 'none') != 'none':
        pending('As faixas de tração foram definidas para placa sem enrijecedores.'); return out
    if u.column_steel not in SUPPORTED_STEELS or getattr(c, 'plate_steel', '') not in SUPPORTED_STEELS:
        pending('Identifique aços do pilar e da placa compatíveis com E7018 no grupo implementado da Tabela 8.'); return out
    cs, ps = STEELS[u.column_steel], STEELS[c.plate_steel]
    p = c.column
    if any(not finite_real(getattr(p, name, None)) or not 0 < getattr(p, name) <= 1e6
           for name in ('d', 'bf', 'tw', 'tf', 'clear')):
        pending('Geometria do pilar inválida para a solda.'); return out
    if p.d <= 2 * p.tf or p.bf <= p.tw or p.clear > p.d - 2 * p.tf + 1e-8:
        fail('Geometria da seção I/H incompatível com os trechos retos da alma.'); return out
    if not finite_real(c.tp) or not 0 < c.tp <= 1e6:
        pending('Espessura da placa inválida para a solda.'); return out
    if not ps.plate_allowed or not ps.plate_min <= c.tp <= ps.plate_max:
        fail('Placa fora do produto/espessura de aço permitido.'); return out
    if p.family in WELDED_FAMILIES:
        material_ok = cs.plate_allowed and all(cs.plate_min <= t <= cs.plate_max for t in (p.tw, p.tf))
    else:
        material_ok = cs.rolled_allowed and all(cs.profile_min <= t <= cs.profile_max for t in (p.tw, p.tf))
    if not material_ok:
        fail('Pilar fora do produto/espessura de aço permitido.'); return out
    if u.web_length <= 0:
        pending('Informe o comprimento real, reto e contínuo da solda da alma.'); return out
    if not u.detail_confirmed or not u.procedure_ref.strip():
        pending('Confirme os trechos retos centrados, material íntegro, acesso e ausência de interferências, e identifique o procedimento.'); return out
    if u.web_length > p.clear + 1e-8:
        fail('Comprimento real da solda supera o trecho livre da alma.'); return out
    kind = getattr(c, 'weld_web_type', 'unspecified')
    if kind not in ('fillet', 'cjp'):
        pending('Especifique filete ou CJP para a solda da alma.'); return out
    if kind == 'fillet' and u.process != 'smaw_e7018_single_pass':
        pending('O filete implementado exige SMAW/E7018 em passe único, conforme o detalhe e a Tabela 11.'); return out
    if kind == 'cjp':
        if u.process not in ('smaw_e7018', 'smaw_e7018_single_pass'):
            pending('A CJP implementada exige procedimento SMAW/E7018 compatível.'); return out
        if u.cjp_detail not in ('backing_removed', 'backing_retained') or not u.inspection_ref.strip():
            pending('CJP: especifique preparação com penetração total, condição da chapa de espera e inspeção.'); return out
        if u.cjp_detail == 'backing_retained' and not u.cjp_charpy_confirmed:
            pending('CJP em T com chapa de espera mantida exige metal de solda Charpy 27 J a temperatura máxima de 4 °C.'); return out
        if max(p.tw, p.tf) > 50 and not u.base_charpy_confirmed:
            pending('CJP em seção espessa tracionada: documente os requisitos de tenacidade do metal-base de 12.2.1.5.'); return out
        if max(p.tw,p.tf)>50 and not u.cjp_charpy_confirmed:
            pending('CJP em seção espessa tracionada: documente também a tenacidade Charpy do metal de solda conforme 6.2.4.2(b), inclusive com chapa de espera removida.'); return out
    try:
        values = type2_uplift_values(c.N, c.a2, p.tw, u.web_length, c.tp, cs.fy, cs.fu, ps.fy, ps.fu)
    except ValueError as exc:
        fail(str(exc)); return out
    out.update(values)
    out['statuses']['demand_field'] = 'established'
    passed = []
    def check(key, name, sd, rd, unit, equation, variables):
        add('cw_' + key, name, sd, rd, unit, REF, equation,
            f'Sd={sd:.10g}; Rd={rd:.10g}', variables)
        ok = finite_real(sd) and finite_real(rd) and rd > 0 and abs(sd) <= rd * (1 + 1e-10)
        out['statuses'][key] = 'pass' if ok else 'fail'
        passed.append(ok)
        return ok
    q = values['q_normal_one_face_N_per_mm']
    if kind == 'fillet':
        try:
            dims = fillet_dimensions(c.weld_web_size, c.weld_web_measure)
            qr = fillet_line_resistance(dims['leg'])
        except (ValueError, OverflowError) as exc:
            fail(str(exc)); return out
        out.update({'leg_mm': dims['leg'], 'throat_mm': dims['throat'],
                    'q_weld_Rd_N_per_mm': qr, 'weld_utilization': q / qr})
        check('web_weld', 'Pilar–placa — filete de cada face da alma', q, qr, 'N/mm',
              'qz=Ti/beff ≤ 0,6 fw a/γw2', 'Cada face; fw=485 MPa; a=z/√2; sem bônus direcional.')
        thin = min(p.tw, c.tp)
        minimum = 3 if thin <= 6.3 else 5 if thin <= 12.5 else 6 if thin <= 19 else 8
        check('leg_min', 'Pilar–placa — perna mínima da alma', minimum, dims['leg'], 'mm',
              'z ≥ zmin', 'Tabela 11; parte menos espessa; passe único.')
        check('length_min', 'Pilar–placa — comprimento contínuo mínimo', max(40, 4 * dims['leg']), u.web_length, 'mm',
              'Lw ≥ max(40;4z)', 'Comprimento físico contínuo; carregamento transversal de tração, sem redução longitudinal automática.')
        if not finite_real(getattr(c, 'B', None)) or c.B <= p.tw:
            fail('Largura da placa insuficiente para assentar os filetes.'); return out
        check('shelf', 'Pilar–placa — prateleira transversal do filete', dims['leg'], (c.B - p.tw) / 2, 'mm',
              'z ≤ (B−tw)/2', 'Não substitui a confirmação de acesso e ausência de interferência com furos/arruelas.')
    else:
        cj = cjp_resistance(1, p.tw, c.tp, cs.fy, ps.fy)
        out.update({'cjp_A_MB_per_length_mm': cj['A_MB_mm2'],
                    'cjp_q_normal_Rd_N_per_mm': cj['R_normal_N'],
                    'cjp_q_shear_Rd_N_per_mm': cj['R_shear_N'],
                    'weld_utilization': 2 * q / cj['R_normal_N']})
        check('web_cjp', 'Pilar–placa — seção CJP da alma sob tração', 2 * q, cj['R_normal_N'], 'N/mm',
              '2qz ≤ min(tw;tp) min(fy,pilar;fy,placa)/γa1',
              'Uma seção fundida; não somar duas faces. Compatibilidade, procedimento e inspeção explicitamente especificados.')
    sigma = values['web_stress_MPa']
    check('web_yield', 'Pilar–placa — escoamento local da alma tracionada', sigma, cs.fy / G1, 'MPa',
          'σalma=2qz/tw ≤ fy,pilar/γa1', 'Alma íntegra; sem furos/recortes nos trechos eficazes.')
    check('web_rupture', 'Pilar–placa — ruptura local da alma tracionada', sigma, cs.fu / G2, 'MPa',
          'σalma=2qz/tw ≤ fu,pilar/γa2', 'Área líquida igual à bruta somente no detalhe íntegro confirmado.')
    check('strip_bending', 'Pilar–placa — flexão suplementar da faixa da placa', values['m_plate_Nmm_per_mm'], values['m_plate_Rd_Nmm_per_mm'], 'N·mm/mm',
          'Ti e/beff ≤ fy,placa tp²/(4γa1)', 'Mecânica da faixa DG1 e fatores NBR; complementar à espessura nativa Tipo 2, sem usar l0 como comprimento de solda.')
    check('strip_shear', 'Pilar–placa — cisalhamento direto da faixa da placa', q,
          min(values['plate_strip_shear_yield_Rd_N_per_mm'], values['plate_strip_shear_rupture_Rd_N_per_mm']), 'N/mm',
          'Ti/beff ≤ min(0,6 fy,placa tp/γa1;0,6 fu,placa tp/γa2)',
          'Seção íntegra por face da alma; não inclui interação com flexão ou ruptura local junto à fusão.')
    out['status'] = 'pass' if all(passed) else 'fail'
    r.issues.append(Issue('pending', LIMITS, REF, origin='column_weld_scope'))
    return out
