"""Editable, input-bound Word record of the opposed two-row bolted route.

Compact reports retain physical envelopes and actual inputs. Detailed reports
also preserve each check and full canonical case evidence. Both reevaluate.
"""
from .display_precision import display_format
from dataclasses import asdict
from io import BytesIO
from math import isfinite
import json
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Inches, Pt, RGBColor
from docx.oxml.ns import qn
from .bolted_opposed_angle_gusset import COMPONENT_VERSION, FAMILY
from .bolted_opposed_angle_gusset_drawing import STATUS, image_bytes, input_fingerprint, validated_result
from .bolted_opposed_angle_gusset_presentation import physical_envelopes, selected_angle, angle_identity, angle_detail_disclosure
from .report import BRAND, _math, frac, group, power, radical, table


def _value(value):
    if value is None:return 'não informado'
    if isinstance(value,bool):return 'sim' if value else 'não'
    if isinstance(value,float):return display_format(value,'.15g').replace('.',',') if isfinite(value) else str(value)
    if isinstance(value,dict):return '; '.join(str(k)+'='+_value(v) for k,v in value.items())
    if isinstance(value,(list,tuple)):return '; '.join(_value(v) for v in value) or 'nenhum'
    return str(value) or 'não informado'


def _n(value,divisor=1):
    if isinstance(value,bool) or not isinstance(value,(int,float)) or not isfinite(value):return 'não disponível'
    return display_format(value/divisor,'.6g').replace('.',',')


def _flatten(value,prefix=''):
    if isinstance(value,dict):
        for key,item in value.items():yield from _flatten(item,prefix+'.'+str(key) if prefix else str(key))
    elif isinstance(value,(list,tuple)):
        if not value:yield prefix,'nenhum'
        for i,item in enumerate(value):yield from _flatten(item,prefix+'['+str(i)+']')
    else:yield prefix,_value(value)


def _tab(doc,headers,rows,widths=None,size=8):
    out=table(doc,headers,rows,widths or [6.97/len(headers)]*len(headers))
    for i,row in enumerate(out.rows):
        for j,cell in enumerate(row.cells):
            for p in cell.paragraphs:
                if j==0:p.alignment=WD_ALIGN_PARAGRAPH.LEFT
                if len(out.rows)<=6:p.paragraph_format.keep_with_next=i<len(out.rows)-1
                for run in p.runs:run.font.size=Pt(size)
    return out


def _head(doc,title,level=1):return doc.add_paragraph(title,style='Heading '+str(level))


def _inputs(doc,c,r):
    # Labels are presentation only; no UI widgets are invoked.
    from .bolted_angle_gusset_ui import LABELS
    _head(doc,'Entradas atuais e materiais independentes')
    doc.add_paragraph('Unidades nativas: N, mm e MPa; momentos em N mm. As forças da tabela abaixo estão em N, mesmo quando o controle da tela usa kN. Nenhum arredondamento da memória realimenta o cálculo.')
    labels=dict(LABELS)
    labels.update(n='Quantidade de parafusos por L e por linha',threads_excluded_1='Linha negativa com plano fora da rosca',threads_excluded_2='Linha positiva com plano fora da rosca',N='Força axial total N (N)',V='Cortante adicional V (N)',M='Momento adicional M (N mm)',torsion='Torção adicional (N mm)')
    _tab(doc,['Dado nativo','Valor'],[(labels.get(k,k),_value(v)) for k,v in asdict(c).items()],[3.65,3.32])
    angle=selected_angle(c,r)
    _head(doc,'Identidade da cantoneira selecionada',2)
    doc.add_paragraph(angle_identity(angle,c.angle_profile)+' · '+c.angle_profile)
    if angle:
        _tab(doc,['b (mm)','t (mm)','Ag por L (mm²)','ec por L (mm)'],[[_value(angle.get(k)) for k in ('leg','t','Ag','centroid')]])
        doc.add_paragraph('Fonte: '+str(angle.get('source','não disponível'))+'. '+angle_detail_disclosure(angle))
        if angle.get('source_sha256'):doc.add_paragraph('SHA-256 da fonte: '+str(angle['source_sha256']))
    doc.add_paragraph('A extensão interna do talão informada é uma geometria de detalhe da peça real. Não é raio fabricado a partir do catálogo, não usa raio de giração e não é uma declaração de conformidade. Sua ausência deixa a montagem pendente. Uma hipótese do exemplo não certifica a peça real.')
    _head(doc,'Propriedades dos materiais adotados pelo motor',2)
    if r.get('materials'):_tab(doc,['Material / propriedade','Valor'],list(_flatten(r['materials'])),[3.65,3.32])
    else:doc.add_paragraph('Sem propriedades resistentes concluídas para esta entrada.')
    doc.add_paragraph('Cinco registros independentes: aço da L, aço da chapa, aço do W, classe do parafuso e eletrodo da raiz. Compartilhar um valor de fy/fu não une os registros. Dimensão de catálogo não certifica aço, ferragem, procedimento de soldagem ou inspeção.')
    W=(r.get('geometry') or {}).get('support_catalog')
    if W:
        _head(doc,'W receptor selecionado',2)
        _tab(doc,['Perfil','d','bf','tw','tf','r','k'],[[str(W.get('name',c.support_profile))]+[_value(W.get(k)) for k in ('d','bf','tw','tf','r','k')]], [1.87,.85,.85,.85,.85,.85,.85],7.5)
        doc.add_paragraph('Dimensões em mm. Fonte: '+str(W.get('source','não informada')))


def _envelopes(doc,r):
    _head(doc,'Envelopes por componente e mecanismo físico')
    env=physical_envelopes(r)
    if not env:doc.add_paragraph('Nenhum envelope resistente concluído.');return
    doc.add_paragraph('η real corresponde a N real; η adotado conserva os casos mínimos e recomendados separados. Capacidades de partes em série ou caminhos alternativos não são somadas. Todos os empates governantes são preservados.')
    _tab(doc,['Componente / mecanismo','η real','η adotado','Estado'],
         [(e['component_label']+'\n'+e['mechanism_label']+'\n'+e['force_scope'],_n(e['actual_utilization']),_n(e['utilization']),e['status']) for e in env],[4.12,.85,.95,1.05])
    for e in env:
        p=doc.add_paragraph();p.add_run(e['component_label']+' / '+e['mechanism_label']+': ').bold=True
        p.add_run('; '.join(str(w.get('id'))+' ['+str(w.get('case_id'))+'] Sd='+_n(w.get('demand'))+', Rd='+_n(w.get('resistance'))+' '+str(w.get('unit','')) for w in e['governing']))
        for run in p.runs:run.font.size=Pt(7.5)


def _cases(doc,c,r):
    _head(doc,'Casos independentes, planos físicos e raiz comum')
    count=2
    doc.add_paragraph('N é a força total da ligação. 2L opostas ><: N/2 por L, N/(2n) em cada parafuso físico e em cada furo da chapa. São 2n parafusos distintos, cada um com um único plano de corte. Uma L está na face positiva e a outra na negativa, girada 180 graus; suas abas conectadas ocupam intervalos distintos no plano. A chapa única, os dois filetes da raiz e o W recebem N total uma vez.')
    doc.add_paragraph('O mínimo de 45 kN aplica-se uma vez à ligação, antes de repartir entre cantoneiras ou parafusos. A recomendação de 50% usa a resistência do par. São casos separados; N real zero permanece zero.')
    _tab(doc,['Parafusos físicos','Planos por parafuso','Linhas v (mm)','Pega sem ferragem (mm)'],[[str(2*c.n),'1','±'+_n(c.plate_t/2+c.gauge),_n(c.plate_t+(selected_angle(c,r) or {}).get('t',0))]],[1.45,1.5,2.,2.02])
    geometry=r.get('geometry') or {}
    centers=geometry.get('bolt_centers') or []
    if centers:
        _tab(doc,['Furo físico','Linha','s (mm)','n (mm)'],[(str(i+1),str(i//c.n),_n(p[0]),_n(p[1])) for i,p in enumerate(centers)],[1.6,1.2,2.08,2.09])
    cases=r.get('cases') or []
    if not cases:doc.add_paragraph('Nenhum caso resistente concluído.');return
    _tab(doc,['Caso','N total (kN)','N por L (kN)','N por plano (kN)'],
         [(str(x.get('id')),_n(x.get('N'),1000),_n(x.get('N',0)/count,1000),_n(x.get('N',0)/count/c.n,1000)) for x in cases],[2.2,1.4,1.4,1.97])
    for case in cases:
        _head(doc,'Raiz no caso '+str(case.get('id')),2)
        root=case.get('root') or (r.get('root') if case.get('id')=='actual' else {}) or {}
        _tab(doc,['Grandeza canônica','Valor'],list(_flatten(root)),[3.65,3.32])
    _head(doc,'Ações exportadas para o membro W',2)
    if r.get('member_actions'):_tab(doc,['Grandeza / referência','Valor'],list(_flatten(r['member_actions'])),[3.65,3.32])
    doc.add_paragraph('Nnormal é a variação de cortante transversal introduzida no membro; Vparalelo é o cisalhamento longitudinal da interface. No centroide do W, Mcentroide=Mraiz−dW Vparalelo/2. Combinar com as ações concorrentes reais do membro; nunca presumir apoio descarregado.')


def _method(doc,c):
    _head(doc,'Modelo e equações editáveis')
    doc.add_paragraph('Duas L idênticas opostas pelos vértices (><), uma por face, com h=tg e contato direto. Cada linha contém n parafusos nas mesmas estações u; a segunda L é girada 180 graus em torno de u. O graminho g parte do talão externo de cada L até sua linha, em sentidos opostos. O modelo não admite linhas assimétricas ou escalonadas.')
    _math(doc,group('v₋ = −(tg/2 + g);   v₊ = +(tg/2 + g);   Lc = (n − 1) p'))
    _math(doc,group('s = s0 + u cos θ + v sen θ;   n = n0 + u sen θ − v cos θ'))
    doc.add_paragraph('A NBR 8800, 6.1.8.2, é aplicada separadamente a cada extremidade de L sob tração estática normal. A força nominal de cada L atua na sua própria linha de parafusos. O centroide físico não muda: ec permanece no shear lag. A simetria do par não prova cancelamento pontual dos momentos de face nem resolve um campo tridimensional. Cortes parciais retêm o momento de cada linha realmente capturada.')
    _math(doc,group('An,L = Ag,L − dn tL;   Ae,L = Ct An,L;   Ct = max[1 − ',frac('ec','Lc'),'; 0,5]'))
    doc.add_paragraph('Ag e ec são os valores publicados para cada L do catálogo selecionado. Uma seção reta por L deduz um furo, enquanto a seção alinhada da chapa comum intercepta dois furos. As verificações bruta e efetiva do par equivalem a N/2 por L. Não se estima Ag por cantos vivos nem se anula ec pela posição do centroide do par.')
    _math(doc,group('Fparafuso = ',frac('N','2n'),';   Rplano = kpega α ',frac('π db² fub','4 γa2'),';   α = 0,45 ou 0,56'))
    doc.add_paragraph('Cada parafuso tem um único plano de corte, avaliado com sua condição real de rosca. A pega é tg+tL+ferragens aplicáveis. Não se utiliza tg+2tL ou resistência de corte duplo. Todos os contatos de furos resistem à parcela N/(2n), sem redistribuição de capacidade. Não se credita atrito por protensão.')
    _math(doc,group('Rcontato = ',frac('min(1,2 lc t fu; 2,4 db t fu)','γa2')))
    doc.add_paragraph('lc segue a força sobre cada peça: −u nas L e +u na chapa. Cada linha alcança sua própria saída livre, que pode diferir entre as linhas quando θ não é 90 graus. O diâmetro físico controla contato e montagem; dn segue a Tabela 14 acrescida de 2 mm, exceto furos por broca. Ferragem, talão, folga, passo, bordas mínimas e máximas, sobreposição das L e interferência com raiz ou outra L são verificações de geometria real.')
    _head(doc,'Introdução local na chapa comum',2)
    _math(doc,group('bWhitmore = (tg + 2g) + 2 Lc tan 30°'))
    doc.add_paragraph('O Whitmore agregado é recortado à chapa real e usa tg uma única vez. A triagem de ruptura líquida deduz dois furos. Cada faixa individual de largura 2Lc tan30° usa espessura alocada tg/2, sob N/2, e deduz seu próprio furo. Essa alocação conservadora evita contar material duas vezes; é um suplemento explícito, não uma fórmula prescrita pelo DG29 nem uma solução física tridimensional.')
    _math(doc,group('bn,zig = ℓesq + (v₊ − v₋) + ℓdir − 2dn + ',frac('(u₊ − u₋)²','4(v₊ − v₋)')))
    doc.add_paragraph('Enumeram-se todas as n² cadeias de dois furos em zigue-zague, mesmo com estações alinhadas: as saídas das bordas oblíquas variam com u. Cada caminho guarda suas saídas, deduções, crédito de escalonamento e força capturada. A capacidade líquida também é comparada conservadoramente com N total. Não se somam duas chapas independentes de espessura inteira.')
    _math(doc,group('Rbloco = min[',frac('0,60 fu Anv + Cts fu Ant','γa2'),'; ',frac('0,60 fy Agv + Cts fu Ant','γa2'),'];   Cts = 0,5'))
    doc.add_paragraph('Ambos os ramos usam γa2=1,35. Cada L tem caminhos até sua ponta conectada e até a ponta da aba livre através do talão; o talão não é borda livre. Na chapa, mantêm-se L externos, L internos que podem capturar ambas as linhas, e U entre as duas linhas, incluindo grupos parciais. Os dois comprimentos de saída do U são calculados. Caminhos alternativos não somam resistências; contato positivo com segmento da raiz apoiada torna o caminho inativo, com motivo registrado.')
    _math(doc,group('q = ',radical(group('r² − (u − uj)²')),';   r = dn/2'))
    doc.add_paragraph('A dedução transversal de capa circular é q no L externo, 3q no L interno e 2q no U central. O cisalhamento líquido subtrai os intervalos reais de furos ao longo de cada perna. Buscas em todos os intervalos de topologia retêm extremos interiores de ambos os ramos e limites de captura unilaterais. Amostrar apenas centros de furos não é suficiente, inclusive nos blocos das L.')
    _head(doc,'Envelope conservador dos caminhos parciais',2)
    _math(doc,group('Agv,min = tg (E − u);   Anv,min = tg [(E − u) − Σ ℓfuros restantes]'))
    _math(doc,group('Ant = 0;   Dcapturado = ',frac('k(u) N','2n')))
    doc.add_paragraph('Para cada linha ocupada, E é a primeira saída livre entre vlinha±dn/2. As deduções longitudinais usam a interseção de [u,E] com os diâmetros nominais dos furos; k(u) conta os furos realmente capturados no mesmo limite u. Avaliam-se as capas superiores uj+dn/2 e as mudanças de topologia. Não se combina a capa mais tardia com todos os furos passados e a força completa da linha. Descartar a resistência transversal constitui limite conservador para U com inícios desiguais e pernas ordinárias deslocadas dentro das faixas qualificadas. Falha deste envelope limita o método; não comprova colapso físico nem impõe análise universal por elementos finitos.')
    _head(doc,'Diagnóstico da introdução e ligamento não perfurado',2)
    _math(doc,group('σnominal = ',frac('N','A'),' + ',frac('M(x − x̄)','I'),';   τtriagem = ',frac('1,5 |V|','A')))
    doc.add_paragraph('Cortes horizontais e normais à diagonal subtraem a união de todas as cordas interceptadas, conservam A, centroide e I líquidos e somam forças e momentos das posições reais. As máscaras simultâneas e seus limites unilaterais são retidos. Esses campos são triagem nominal suplementar, NÃO solução exata de tensão de contato nem cisalhamento de uma seção repartida por furos. Os envelopes de resistência do material continuam obrigatórios.')
    doc.add_paragraph('O sinal negativo do campo hipotético na zona perfurada de introdução é somente diagnóstico informativo. Ele não constitui, sozinho, compressão física, reprovação NBR ou prova de instabilidade. A ligação B300 H300 t12,5 θ80 N100 conserva os testemunhos negativos qualificados, sem ser artificialmente ampliada para apagá-los. A introdução depende dos parafusos, contatos, seções líquidas e zigue-zague, blocos, envelopes parciais e Whitmore com alocação de material.')
    doc.add_paragraph('O ligamento íntegro entre a raiz e a menor borda física de furo conserva todas as cargas do lado carregado. O momento M(n)=Mraiz+nVraiz varia linearmente; os extremos da raiz e dessa borda delimitam as tensões. Compressão normal nesse ligamento ou na raiz permanece uma restrição real do domínio de tração e exige a rota correspondente de compressão e estabilidade. A borda usa o diâmetro físico, mesmo quando dn é maior.')
    _head(doc,'Raiz comum e membro W receptor',2)
    _math(doc,group('Nraiz = N sen θ;   Vraiz = N cos θ;   Mraiz = s0 Nraiz − n0 Vraiz'))
    doc.add_paragraph('θ é medido desde +s, paralelo ao eixo longitudinal do W, até o eixo médio do par. Os sinais são mantidos nos ângulos agudos e obtusos; 90 graus é regular. Mover P0 ao longo do mesmo eixo de força não altera Mraiz. Viga ou pilar é uma rotação rígida local; não há segundo apoio ou momento externo inventado.')
    _math(doc,group('qn = ',frac('Nraiz','B'),' ± ',frac('6 Mraiz','B²'),';   qs = ',frac('Vraiz','B')))
    _math(doc,group('qprojeto = max(qpico; 1,25 qmédio dos extremos);   τw = ',frac('qprojeto','√2 sraiz')))
    doc.add_paragraph('A raiz contém dois filetes iguais contínuos, de comprimento B, e uma única chapa A=B·tg. O envelope elástico conserva 6M/B²; 1,25 vezes a média dos módulos extremos é suplemento DG29 exclusivo da solda. Não se aplica aumento direcional. Mantêm-se mínimo do filete, borda, comprimento e compatibilidade.')
    _math(doc,group('δg = min(tg; 2 sraiz);   δW = 2 sraiz;   σeq = ',radical(group(power('σ'),' + 3 ',power('τ')))))
    doc.add_paragraph('Metais base da chapa e W usam componentes normal e tangencial separadas com seus próprios fy/fu. O puncionamento da mesa usa qpico/(2tf), sem o suplemento exclusivo da solda. Flexão ou sua isenção geométrica, alma, duas extremidades, cisalhamento longitudinal e interação local do W mantêm as condições qualificadas. No centroide do W, Mcentroide=Mraiz−dW Vparalelo/2. As ações globais concorrentes do W devem ser combinadas, nunca presumidas zero.')


def _diagnostics(doc,r):
    _head(doc,'Diagnósticos assinados e domínio do ligamento')
    for case in r.get('cases') or []:
        _head(doc,'Caso '+str(case.get('id')),2)
        for key,title in (('introduction_sign_diagnostic','Sinal nominal na zona perfurada'),('solid_root_ligament','Ligamento não perfurado')):
            value=case.get(key)
            if value is not None:
                doc.add_paragraph(title+': '+_value(value))
    doc.add_paragraph('Valores negativos apenas no diagnóstico da introdução não vetam o resultado. O domínio real da raiz e do ligamento íntegro é avaliado separadamente, juntamente com todos os estados-limite e envelopes materiais.')


def _details(doc,r):
    """Every accepted check, with nonduplicated critical witness tables.

    Exhaustive search intervals remain in the downloadable canonical result JSON;
    this readable appendix does not print the same path under check/case/alias.
    """
    _head(doc,'Detalhamento auditável de todas as verificações')
    references=[]
    for check in r.get('checks') or []:
        ref=check.get('reference','')
        if ref not in references:references.append(ref)
    _tab(doc,['Referência','Base normativa ou modelo'],[(str(i+1),ref or 'Identificada no mecanismo') for i,ref in enumerate(references)],[.7,6.27],7.5)
    for case in r.get('cases') or []:
        caseid=str(case.get('id'));_head(doc,'Verificações no caso '+caseid,2)
        rows=[x for x in r.get('checks') or [] if x.get('case_id')==case.get('id')]
        doc.add_paragraph('Todos os '+str(len(rows))+' registros resistentes deste caso. Sd e Rd usam a unidade indicada; η=Sd/Rd. Ref remete à tabela anterior. Identificadores mantidos exatamente para consulta no resultado JSON completo.')
        _tab(doc,['Identificador e Ref','Sd','Rd','η','Unid','Estado'],
            [(str(x['id'])+'\nRef '+str(references.index(x.get('reference',''))+1),_n(x['demand']),_n(x['resistance']),_n(x['utilization']),str(x.get('unit','N')),str(x['status'])) for x in rows],
            [3.35,.85,.85,.7,.55,.67],7)
    _head(doc,'Testemunhos integrais dos casos')
    doc.add_paragraph('As tabelas seguintes apresentam os governantes e empates de cada família de caminhos, todos os limites parciais e cadeias líquidas, e os extremos de seção. Cada valor vem do caso canônico atual. O arquivo de resultados completos JSON conserva todos os intervalos, máscaras, coordenadas e testemunhos de busca sem arredondamento; esta memória evita repeti-los sob os aliases do mesmo registro.')
    for case in r.get('cases') or []:
        _head(doc,'Testemunhos do caso '+str(case.get('id')),2)
        # Retain the complete native key inventory, while routing duplicate aliases
        # to the single physical evidence rather than duplicating pages of JSON.
        doc.add_paragraph('Registros nativos do caso: '+', '.join(case.keys())+'.')
        _tab(doc,['Propriedade da L','Valor'],[(k,_value(case.get(k))) for k in ('angle_Ct','angle_An','angle_Ae')],[3.65,3.32])
        doc.add_paragraph('Distribuição da força: '+_value(case.get('force_split')))
        _head(doc,'Blocos governantes por família física',2)
        families={}
        for witness in case.get('paths') or []:
            key=witness.get('family_id',witness.get('component','path'))
            families.setdefault(key,[]).append(witness)
        critical=[]
        for key,paths in families.items():
            active=[x for x in paths if x.get('active',True) and isinstance(x.get('utilization'),(int,float))]
            if active:
                largest=max(x['utilization'] for x in active)
                critical.extend(x for x in active if x['utilization']==largest)
        _tab(doc,['Caminho e capa u (mm)','Agv / Anv / Ant (mm²)','D / R (kN)','η'],
             [(str(x['id'])+'\nu='+_n(x.get('u')), ' / '.join(_n(x.get(k)) for k in ('Agv','Anv','Ant')),
               _n(x.get('demand'),1000)+' / '+_n(x.get('resistance'),1000),_n(x.get('utilization'))) for x in critical],
             [2.6,2.1,1.5,.77],7.5)
        for x in critical:
            doc.add_paragraph(str(x['id'])+': capturados='+_value(x.get('captured_ids',x.get('captured_bolts')))+
                '; saídas='+_value(x.get('free_exit_edges'))+'; coordenadas (s,n) mm='+_value(x.get('coordinates',x.get('path')))+
                '; contato na raiz='+_value(x.get('root_contact_length',0))+' mm.').paragraph_format.space_after=Pt(3)
        inactive=case.get('inactive_path_families') or []
        doc.add_paragraph('Famílias inativas e motivo: '+_value(inactive))
        doc.add_paragraph('Método de extremos: '+_value(case.get('block_path_envelope')))
        _head(doc,'Todos os limites correlacionados de perna ocupada',2)
        partial=case.get('unequal_partial_U_bounds') or []
        _tab(doc,['Linha e capa u','k / E (mm)','Agv / Anv (mm²)','D / R (kN)','η'],
            [(str(x.get('row'))+' / '+_n(x.get('u')),str(x.get('k'))+' / '+_n(x.get('end_min')),
              _n(x.get('Agv'))+' / '+_n(x.get('Anv')),_n(x.get('demand'),1000)+' / '+_n(x.get('resistance'),1000),_n(x.get('utilization'))) for x in partial],
            [1.2,1.25,1.9,1.8,.82],7.5)
        doc.add_paragraph('Ant=0 em todos os limites. Cada k, furo restante, capa u e resistência pertence ao mesmo corte; não se usa o antigo limite incompatível de todos os furos com capa tardia.')
        _head(doc,'Todas as cadeias líquidas em zigue-zague',2)
        _tab(doc,['Cadeia e uL / uR','An (mm²)','Crédito (mm)','Dcapt / R (kN)','η Ntotal'],
            [(str(x.get('id'))+'\n'+_n(x.get('u_left'))+' / '+_n(x.get('u_right')),_n(x.get('An')),_n(x.get('stagger_credit')),
              _n(x.get('D'),1000)+' / '+_n(x.get('R'),1000),_n(x.get('conservative_full_N_utilization'))) for x in case.get('zigzag_net_chains') or []],
            [2.,1.1,1.,1.9,.97],7.5)
        _head(doc,'Whitmore agregado e material alocado por linha',2)
        whits=[case.get('Whitmore') or {}]+list(case.get('Whitmore_rows') or [])
        _tab(doc,['Faixa','b / t (mm)','Ag / An (mm²)','D (kN)','η bruto / líquido'],
            [(str(x.get('id')),_n(x.get('width'))+' / '+_n(x.get('thickness')),_n(x.get('gross_area'))+' / '+_n(x.get('net_area')),
              _n(x.get('demand'),1000),_n(x.get('yield_utilization'))+' / '+_n(x.get('net_utilization'))) for x in whits],
            [1.25,1.2,1.8,1.,1.72],7.5)
        _head(doc,'Extremos das duas direções de corte',2)
        horizontal=case.get('horizontal_sections') or {}
        # These are complete critical records, including simultaneous masks;
        # interval collections and plate_sections aliases stay in the JSON.
        for key,value in horizontal.items():
            if key in ('intervals','bounds'):continue
            p=doc.add_paragraph('horizontal_sections.'+key+': '+_value(value))
            for run in p.runs:run.font.size=Pt(7.5)
        normal=case.get('force_normal_cuts') or []
        selected=[]
        for metric,mode in (('min_sigma',min),('yield_utilization',max),('rupture_utilization',max)):
            candidates=[x for x in normal if isinstance(x.get(metric),(int,float))]
            if candidates:
                extreme=mode(x[metric] for x in candidates)
                for x in candidates:
                    if x[metric]==extreme and x not in selected:selected.append(x)
        for x in selected:
            p=doc.add_paragraph('force_normal_cuts: '+_value(x))
            for run in p.runs:run.font.size=Pt(7.5)
        doc.add_paragraph('introduction_sign_diagnostic: '+_value(case.get('introduction_sign_diagnostic')))
        doc.add_paragraph('solid_root_ligament: '+_value(case.get('solid_root_ligament')))


def create_report(c,result=None,detailed=False):
    r=validated_result(c,result);doc=Document()
    sec=doc.sections[0];sec.page_width=Inches(8.27);sec.page_height=Inches(11.69)
    sec.top_margin=sec.bottom_margin=Inches(.65);sec.left_margin=sec.right_margin=Inches(.65)
    normal=doc.styles['Normal'];normal.font.name='Calibri';normal.font.size=Pt(9)
    normal.paragraph_format.space_after=Pt(5)
    for style in doc.styles:
        for border in list(style.element.iter(qn('w:pBdr'))):border.getparent().remove(border)
    for name in ('Heading 1','Heading 2'):
        style=doc.styles[name];style.font.name='Calibri';style.font.color.rgb=RGBColor.from_string('000000')
        style.paragraph_format.keep_with_next=True
    title=doc.styles['Title'];title.font.color.rgb=RGBColor.from_string('000000')
    doc.add_paragraph('Ligação parafusada de duas cantoneiras opostas',style='Title')
    doc.add_paragraph(str(c.project))
    doc.add_paragraph(COMPONENT_VERSION+' · '+('Memória detalhada' if detailed else 'Memória compacta'))
    p=doc.add_paragraph();p.add_run(STATUS.get(r.get('status'),str(r.get('status')))).bold=True
    p.add_run(' · estado canônico: '+str(r.get('status')))
    doc.add_paragraph('Cantoneira → parafusos e chapa perfurada → dois filetes da raiz → mesa exterior W. Família independente dos componentes axiais antigos; nenhum resultado deles aprova esta ligação completa.')
    doc.add_paragraph('SHA-256 das entradas atuais: '+input_fingerprint(c))
    for issue in r.get('issues') or []:
        doc.add_paragraph(str(issue.get('severity','Ocorrência'))+': '+str(issue.get('message',issue)))
    doc.add_picture(BytesIO(image_bytes(c,fmt='png')),width=Inches(6.97))
    doc.add_paragraph('Figura proporcional das entradas atuais: duas linhas e 2n furos físicos, seção oposta ><, um plano de corte por parafuso, chapa única e raiz dupla. Cantos da cantoneira sem raio publicado ficam interrompidos; a extensão real do talão é informação separada de montagem.')
    doc.add_page_break();_envelopes(doc,r);_inputs(doc,c,r);_cases(doc,c,r);_diagnostics(doc,r);_method(doc,c)
    if detailed:_details(doc,r)
    _head(doc,'Referências e limites')
    doc.add_paragraph('ABNT NBR 8800:2024 / Errata 1:2025: 5.2.2–5.2.5, tração, seção líquida e shear lag; 5.7, mesa e alma receptoras; 6.1.5 e 6.1.8.2, força mínima e idealização estática de extremidade de cantoneira; 6.2, filetes; 6.3 e Tabelas 14/16, parafusos, contato, furos, pega e distâncias; 6.5.3, 6.5.5 e 6.5.6, elementos conectados e blocos.')
    doc.add_paragraph('AISC Design Guide 29 (2014), Exemplo 5.4, Fig. 5-10, pp. 98–108 (PDF 106–116): precedente convencional de introdução, gusset, raiz e W. Seus parafusos compartilhados não definem a topologia oposta. As duas linhas, 2n parafusos de corte simples, geometria retangular, fatores NBR, demanda uniforme, caminhos refinados e envelope elástico são calculados separadamente. Não se transfere a redistribuição de resistência do exemplo AISC. Qualificação independente do método oposto de 11 outubro 2026, revisão refinada: B300/80 aprovado no domínio declarado, com sinal negativo de introdução preservado.')
    for item in r.get('exclusions') or []:doc.add_paragraph(str(item),style='List Bullet')
    doc.add_paragraph('Fora desta família: membros ou forças desiguais, linhas assimétricas ou escalonadas, enchimentos ou afastamentos, compressão, reversão ou fadiga, sismo, ações espaciais adicionais, alma W direta, raiz transversal ou deslocada, segundo apoio e chapa de canto. Esta rota usa duas linhas distintas em corte simples; não usa parafusos passantes compartilhados do arranjo T.')
    _head(doc,'Conclusão local')
    doc.add_paragraph('As verificações locais implementadas atendem no domínio declarado.' if r.get('global_pass') else 'A entrada atual permanece sem conclusão favorável completa. Resolver as falhas e pendências registradas antes de usar esta memória como verificação local.')
    doc.add_paragraph('Esta conclusão não aprova fabricação, montagem, estabilidade global da diagonal ou do sistema, travamentos do par, membro W carregado ou estrutura completa. '+BRAND)
    doc.core_properties.title=FAMILY;doc.core_properties.subject='Memória local '+COMPONENT_VERSION
    out=BytesIO();doc.save(out);return out.getvalue()

report_docx=create_report
