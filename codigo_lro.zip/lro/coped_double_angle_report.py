"""Editable R017 record: native equations, local scope and external restraints."""
from .display_precision import display_format, display_value
from collections import OrderedDict
from dataclasses import fields, is_dataclass
from io import BytesIO
from math import isfinite

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Inches, Pt, RGBColor

from .angle_catalog_selection import provenance_text, LABELS as CATALOG_LABELS
from .coped_double_angle import COMPONENT_VERSION, EXCLUSIONS, NBR, SCOPE
from .coped_double_angle_drawing import image_bytes, validated_result
from .models import KGF, STEELS, BOLTS
from .report import BRAND, LINK, _math, group, hyperlink
# Only neutral formatting helpers are shared. Check names and envelopes are R017-owned.
from .welded_double_angle_report import _mapping, _num as _common_num, _force as _common_force, _value as _common_value, _tab, _section, _flatten, SEVERITY as COMMON_SEVERITY
from .double_angle_report import LABELS as COMMON_LABELS
from .coped_double_angle_presentation import (physical_envelopes, component_label,
    governing_description, check_label, state_label)

SEVERITY = dict(COMMON_SEVERITY, numerical_failure="Falha numérica")

STATUS = {
    'INVALID_INPUT': 'Entrada inválida',
    'NUMERICAL_FAILURE': 'Falha numérica na avaliação',
    'INVALID_GEOMETRY': 'Geometria inválida',
    'OUTSIDE_R017_SCOPE': 'Fora do domínio R017',
    'ENGINEERING_MODEL_PENDING': 'Verificação local completa pendente',
    'VERIFIED_SUBCHECK_FAIL': 'Há verificação resistente não atendida',
    'DETAIL_FAIL': 'Há requisito de detalhamento não atendido',
    'COMPLETE_LOCAL_CHECKS_PASS_WITHIN_SCOPE': 'Verificações locais atendidas no domínio R017',
    'COMPLETE_LOCAL_CHECKS_PASS_WITH_PRESET_DEVIATION': 'Verificações locais atendidas com desvio do padrão de oficina',
}
LABELS = {key: value for key, value in COMMON_LABELS.items() if key not in ('support_edge_top', 'support_edge_bottom')}
LABELS.update({
    'gap': 'Folga da ponta da viga até a face da alma de apoio em mm',
    'c_top': 'Comprimento superior desde a ponta da viga em mm',
    'c_bottom': 'Comprimento inferior desde a ponta da viga em mm',
    'dc_top': 'Profundidade desde o topo da mesa superior em mm',
    'dc_bottom': 'Profundidade desde a base da mesa inferior em mm',
    'r_top': 'Raio do canto superior em mm', 'r_bottom': 'Raio do canto inferior em mm',
    'beam_level': 'Topo da viga apoiada abaixo do topo da viga de apoio em mm',
    'support_intact': 'Alma e mesas do apoio contínuas sem aberturas nem sobreposição',
    'support_back_access': 'Acesso verificado ao verso da alma de apoio',
    'support_eccentricity': 'Excentricidade normal à alma de apoio em mm',
    'restraint_top_system': 'Sistema físico da contenção superior',
    'restraint_top_ref': 'Referência externa de resistência e rigidez da contenção superior',
    'restraint_top_x': 'Posição da contenção superior desde a face do apoio em mm',
    'restraint_bottom_system': 'Sistema físico da contenção inferior',
    'restraint_bottom_ref': 'Referência externa de resistência e rigidez da contenção inferior',
    'restraint_bottom_x': 'Posição da contenção inferior desde a face do apoio em mm',
})


def _large_finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and isfinite(value) and abs(value) >= 1e12


def _num(value, places=6):
    # Keep finite overflow diagnostics readable; ordinary engineering values
    # retain the established formatting and all decisions remain canonical.
    return display_format(value, '.17g').replace('.', ',') if _large_finite(value) else _common_num(value, places)


def _force(value):
    return _num(value / KGF, 2) if _large_finite(value) else _common_force(value)


def _value(value):
    return _num(value) if _large_finite(value) else _common_value(value)


def _approved(r):
    blockers = {'invalid_input', 'invalid_geometry', 'unsupported_scope', 'engineering_pending',
                'access_pending', 'detail_fail', 'error', 'pending', 'not_evaluated', 'numerical_failure'}
    checks = r.get('checks') or []
    return (isinstance(r.get('inputs'), dict) and r.get('local_pass') is True
            and r.get('status') in ('COMPLETE_LOCAL_CHECKS_PASS_WITHIN_SCOPE', 'COMPLETE_LOCAL_CHECKS_PASS_WITH_PRESET_DEVIATION')
            and _mapping(r.get('geometry')).get('valid') is True
            and _mapping(r.get('summary')).get('complete_checks') is True
            and bool(checks) and all(isinstance(row, dict) and row.get('status') == 'PASS' for row in checks)
            and not any(isinstance(issue, dict) and issue.get('severity') in blockers for issue in (r.get('issues') or [])))


def _records(doc, title, value):
    doc.add_paragraph(title, style='Heading 2')
    if value:
        _tab(doc, ['Grandeza / caminho', 'Valor'], list(_flatten(value)), [3.75, 3.32], size=8)
    else:
        doc.add_paragraph('Resultado não fornecido nesta avaliação. Ausência de registro não significa atendimento.')


def _inputs(doc, c, r):
    if c.angle_catalog_id:
        doc.add_paragraph(provenance_text(c))
    doc.add_paragraph('Dados completos da entrada', style='Heading 1')
    doc.add_paragraph('Cada perfil é um componente físico independente. A ligação parafusada introduz a reação na alma da viga de apoio perpendicular. Seu contato e sua pega usam a espessura tw do apoio; a espessura tf da mesa não é substituta.')
    doc.add_paragraph('Perfis: d, bf, tw, tf e clear em mm; area em mm²; mass em kg/m. Ações internas em N e N mm, tensões em MPa. Todos os campos preservam o arquivo nativo.')
    for key, label in (('beam', 'Viga apoiada com dois recortes'), ('support', 'Viga de apoio perpendicular')):
        profile = getattr(c, key, None)
        doc.add_paragraph(label, style='Heading 2')
        if is_dataclass(profile):
            _tab(doc, ['Campo do perfil', 'Valor'], [(f.name, _value(getattr(profile, f.name))) for f in fields(profile)], [2.1, 4.97])
        else:
            doc.add_paragraph(str(profile))
    _tab(doc, ['Grandeza e campo de entrada', 'Valor informado'],
         [(CATALOG_LABELS.get(f.name, LABELS.get(f.name, f.name)) + '\n' + f.name, _value(getattr(c, f.name))) for f in fields(c)
          if f.name not in ('beam', 'support')], [4.3, 2.77])
    doc.add_paragraph('Materiais e coeficientes', style='Heading 2')
    for name in dict.fromkeys((c.beam_steel, c.support_steel, c.angle_steel)):
        steel = STEELS.get(name)
        doc.add_paragraph(str(name) + ': ' + (f'fy={display_value(_num(steel.fy, 3))} MPa; fu={display_value(_num(steel.fu, 3))} MPa.' if steel else 'Material não cadastrado; sem resistência presumida.'))
    bolt = BOLTS.get(c.bolt)
    if bolt is not None:
        doc.add_paragraph('Parafuso ' + str(c.bolt) + ': fub=' + _num(bolt if isinstance(bolt, (int, float)) else getattr(bolt, 'fu', getattr(bolt, 'fub', None)), 3) + ' MPa.')
    doc.add_paragraph('Componentes NBR: γa1=1,10 e γa2=1,35. O coeficiente de resistência da fórmula complementar de instabilidade já está incorporado nela; não há uma segunda divisão por γa1.')
    _records(doc, 'Premissas fixas do arquivo nativo', c.fixed_assumptions)
    g = _mapping(r.get('geometry'))
    _records(doc, 'Geometria derivada', {key: value for key, value in g.items() if key not in ('checks', 'detailing_checks', 'errors')})
    gchecks = [item for item in (g.get('checks') or []) if isinstance(item, dict)]
    if gchecks:
        _tab(doc, ['Critério geométrico', 'Valor / exigência em mm', 'Estado'],
             [(str(x.get('id', '')) + '\n' + str(x.get('reference', '')) + ('\n' + str(x['qualification_note']) if x.get('qualification_note') else ''),
               _num(x.get('actual'), 3) + ' / ' + str(x.get('relation', '')) + ' ' + _num(x.get('limit'), 3),
               ('Atende por exceção verificada da nota da Tabela 16' if x.get('qualification') == 'TABLE16_EXCEPTION_VERIFIED' else 'Atende' if x.get('passed') else 'Não atende')) for x in gchecks], [3.65, 2.35, 1.07], size=7.8)
    doc.add_paragraph('dh é o diâmetro físico usado no desenho e no contato. dn é a dedução líquida segundo a maior dimensão circular da Tabela 14, acrescida de 2 mm salvo furação por broca documentada. Os recortes são definidos desde a ponta e pelas faces externas das mesas; a posição do parafuso não é uma borda de cantoneira reutilizada como borda da alma.')


def _loads(doc, c, r):
    doc.add_paragraph('Ações e caminho das forças', style='Heading 1')
    lm = _mapping(r.get('load_model'))
    def moment(value):
        return _num(value / (KGF * 1000), 3) if isinstance(value, (int, float)) and not isinstance(value, bool) and isfinite(value) else 'não disponível'
    _tab(doc, ['Ação', 'Valor', 'Unidade'], [
        ('Vsd com sinal da entrada', _force(c.V), 'kgf'), ('Vd adotado na conferência', _force(lm.get('Vd_N')), 'kgf'),
        ('N informado', _force(c.N), 'kgf'), ('M informado', moment(c.M), 'kgf m'), ('T informado', moment(c.torsion), 'kgf m')], [4., 1.65, 1.42])
    doc.add_paragraph('V positivo atua para baixo na viga apoiada. Seus parafusos comuns empurram a alma para cima; as cantoneiras entregam a reação para baixo na alma de apoio. V negativo inverte os sentidos, as bordas carregadas e os trajetos aplicáveis. A ação mínima de 45 kN, quando aplicável, dimensiona a ligação; a carga física exportada à estrutura continua sendo a ação real.')
    for equation in [
        'Vângulo = Vd/2;  Vparafuso,alma = Vd/nalma;  Vplano,alma = Vd/(2nalma)',
        'Vparafuso,apoio = Vd/(2napoio);  nplanos,alma = 2;  nplanos,apoio = 1',
        'e = c + folga;  Mrecorte = |V| e',
        'Fapoio = (0, −Vsd, 0);  Mapoio = r × Fapoio;  Tx = Vsd ez',
    ]:
        _math(doc, group(equation))
    doc.add_paragraph('Total físico de parafusos: ' + str(c.web_rows * c.web_columns + c.angle_count * c.support_rows * c.support_columns) + '. São n parafusos comuns à alma apoiada e 2n parafusos de apoio no domínio de uma coluna por aba. Há 2n furos distintos em uma única alma de apoio; nenhuma espessura de alma é duplicada.')
    doc.add_paragraph('Caminho em série: alma recortada da viga → parafusos comuns → duas cantoneiras → parafusos de apoio → alma da viga de apoio. As resistências das interfaces não são somadas. Cada ângulo transmite V/2 no modelo convencional flexível, sem transformar essa partilha nas cortantes dos dois vãos do apoio.')
    _records(doc, 'Modelo de ações e exportação ao apoio', lm)
    _records(doc, 'Grupos físicos de parafusos', r.get('bolts'))
    doc.add_paragraph('No apoio, o eixo x segue o vão, y é vertical e z é normal à alma. A reação e seus pontos de aplicação devem ingressar no modelo global com seus sinais. A diferença entre cortantes de seções à esquerda e à direita deve equilibrar a reação; seus valores dependem da estrutura e das demais ações. Não se usa V vezes metade da altura do apoio como torque.')


def _cope(doc, c, r):
    doc.add_paragraph('Recorte duplo e condições de contorno', style='Heading 1')
    doc.add_paragraph('Modelo complementar, identificado separadamente das equações atuais de componentes NBR. A rota inicial cobre recortes superior e inferior iguais e rasos, c≤2d e dc≤0,2d, com contenção lateral independente na face recortada da mesa comprimida. Não é um limite universal de c=170 mm nem uma lista fechada de dimensões tabeladas.')
    for equation in [
        'h0 = d − 2dc;  W1 = tw h0²/6;  e = c + folga',
        'VRd,escoamento = fy W1/(1,10 e)',
        'φFbc = 350600 [tw²/(c h0)] [3,5 − 7,5(dc/d)]  [MPa]',
        'VRd,instabilidade = (φFbc) W1/e',
    ]:
        _math(doc, group(equation))
    doc.add_paragraph('Todas as dimensões dessas equações estão em mm; as resistências são N. O coeficiente 350600 MPa é a conversão coerente da forma kN/cm do Gerdau, p.25. W1 é elástico, sem ganho plástico; primeiro escoamento e instabilidade são limitantes distintos. O braço inclui a folga real, não somente o comprimento do corte nem a posição do centroide dos parafusos.')
    doc.add_paragraph('A contenção superior é requerida para V>0; a inferior para V<0; para V=0 são verificadas ambas sob a ação mínima de conferência. Sistema físico, posição e referência externa de resistência e rigidez são dados de projeto, registrados integralmente. O módulo não dimensiona essas contenções e não as deduz da laje, da continuidade da mesa ou da presença das cantoneiras.')
    _records(doc, 'Resultado do modelo de recorte', r.get('cope'))
    _records(doc, 'Evidência e posição das contenções externas', r.get('restraints'))
    doc.add_paragraph('Na seção reta recortada, Agv=h0 tw e Anv=(h0−n dn)tw. Contato e blocos da alma usam a borda livre real do recorte, com o canto arredondado quando aplicável, e a distância real à ponta. Prefixos de furos recebem a parcela de força que efetivamente carregam no modelo uniforme. A inversão deve refazer os trajetos carregados.')


def _support(doc, c, r):
    doc.add_paragraph('Alma de apoio e limite da verificação local', style='Heading 1')
    doc.add_paragraph('A introdução local convencional verifica cisalhamento dos parafusos, contato e rasgamento direcional nos furos da alma de apoio, detalhamento e acesso. Usa-se tw=' + _num(c.support.tw, 3) + ' mm e o material próprio do apoio. Em cada coluna, o furo intermediário encontra o ligamento p−dh no sentido carregado; o terminal em alma contínua usa o limite de contato sem fabricar uma borda livre na raiz da mesa.')
    _math(doc, group('Rb,i = min(1,2 lc,i; 2,4 db) tw,apoio fu,apoio/γa2'))
    doc.add_paragraph('A soma normativa das resistências dos furos e a compatibilidade da força uniforme por parafuso são verificações distintas. Não há duplicação da alma para somar os dois grupos. Não se transplanta um bloco de borda de mesa de pilar, nem um painel arbitrário carregado com V/2.')
    _records(doc, 'Resultado da introdução local no apoio', r.get('support_web'))
    doc.add_paragraph('A junção entre alma e mesa contínua não é uma borda cortada. Na geometria interior intacta não se inventa um bloco destacável a partir do fim da cantoneira. Aberturas, entalhes, outra ligação sobreposta, forças fora do plano ou caminhos locais adicionais exigem modelo próprio. NBR 5.7.1 trata forças normais aplicadas na face externa da mesa e não substitui este caminho de forças por furos da alma.')
    doc.add_paragraph('VERIFICAÇÃO GLOBAL DOS MEMBROS: EXTERNA, NÃO AVALIADA. Cortante em seções brutas e perfuradas, flexão, torção, estabilidade, apoios e demais ações da viga de apoio dependem de seu modelo estrutural. O atendimento local R017 não aprova o membro completo nem a estrutura. Estado declarado pelo motor: ' + str(r.get('member_global_status', 'EXTERNAL_NOT_EVALUATED')) + '.')


def _envelopes(doc, r):
    envelopes = physical_envelopes(r)
    doc.add_paragraph('Envelopes físicos da ligação R017', style='Heading 1')
    if not envelopes:
        doc.add_paragraph('Nenhum envelope resistente disponível. Verificações ausentes ou não calculadas não recebem aprovação presumida.')
        return
    doc.add_paragraph(f"{display_value(len(envelopes))} envelopes conservam todas as {display_value(len(r['checks']))} verificações individuais. São máximos de utilização, sem somar resistências de mecanismos ou interfaces diferentes. Cada solicitação e resistência pertence à linha governante correspondente. As verificações ausentes por limite de domínio permanecem pendentes.")
    rows = []
    for item in envelopes:
        actual = item['actual_governing']; adopted = item['adopted_governing']
        rows.append((item['component_label'] + '\n' + item['mechanism_label'],
            _force(actual['actual_demand_N']) + ' / ' + _force(actual['design_capacity_N']),
            _force(adopted['demand_N']) + ' / ' + _force(adopted['design_capacity_N']),
            _num(item['actual_utilization']) + '\n' + _num(item['adopted_utilization']),
            state_label(item['actual_status']) + '\n' + state_label(item['status'])))
    _tab(doc, ['Componente e mecanismo', 'Sd real / Rd\nkgf', 'Sd conf. / Rd\nkgf', 'ηreal\nηd', 'Real\nConf.'], rows,
         [2.52, 1.40, 1.40, .95, .80], size=8)
    doc.add_paragraph('Governantes sentidos empates e falhas', style='Heading 2')
    for item in envelopes:
        p = doc.add_paragraph(); p.add_run(item['component_label'] + ' · ' + item['mechanism_label'] + '. ').bold = True
        for key, label in (('actual', 'Real'), ('adopted', 'Conferência')):
            record = item[key + '_governing']; ties = item[key + '_governing_ties']
            p.add_run(label + ': ' + governing_description(record) + '. ID: ' + record['id'] + '. ')
            if len(ties) > 1:
                p.add_run('Empates: ' + ', '.join(row['id'] for row in ties) + '. ')
            failures = item[key + '_failure_ids']
            p.add_run('Falhas: ' + (', '.join(failures) if failures else 'nenhuma') + '. ')
        if item['conditional_on_external_restraints']:
            doc.add_paragraph(item['restraint_condition'])
    doc.add_paragraph('Cada furo, soma normativa, prefixo de bloco, sentido, ação, resistência, fórmula e referência permanece no desenvolvimento individual abaixo. Os IDs vinculam cada governante, empate e falha ao registro integral; a alma única de apoio reúne duas colunas físicas sem duplicar sua espessura.')


def _checks(doc,r):
    checks=[x for x in (r.get('checks') or []) if isinstance(x,dict)]
    doc.add_paragraph('Equações editáveis e referências',style='Heading 1')
    if not checks:
        doc.add_paragraph('Não há verificações resistentes calculadas. A ausência de linhas não significa atendimento. As pendências e o estado do motor impedem atribuir aprovação.')
        return
    formulas=OrderedDict()
    for row in checks:
        key=(str(row.get('formula','Fórmula não fornecida')),str(row.get('reference','Referência não fornecida')))
        formulas.setdefault(key,'E'+str(len(formulas)+1))
    for (formula,reference),code in formulas.items():
        doc.add_paragraph(code,style='Heading 2')
        _math(doc,group(formula))
        doc.paragraphs[-1].paragraph_format.keep_with_next=True
        doc.add_paragraph(reference)
    doc.add_paragraph('Ag e An: áreas bruta e líquida ao cisalhamento. Agv e Anv: áreas bruta e líquida ao corte no bloco; Ant: área líquida à tração; Cts: coeficiente de distribuição de tensão. fy, fu e fub: resistências características; db: diâmetro do parafuso; dh: furo físico; dn: dedução líquida; lc: ligamento livre; α: coeficiente por plano de corte; γa1 e γa2: coeficientes de resistência.')
    doc.add_paragraph('Blocos e contato usam os furos, bordas e a parcela de força da própria peça. Uma aba sem furo não recebe dedução da outra. A soma normativa das resistências de contato dos furos é distinta de multiplicar a capacidade do pior furo pelo número total de parafusos.')
    doc.add_paragraph('Todas as verificações calculadas',style='Heading 1')
    doc.add_paragraph(f'Total de {display_value(len(checks))} linhas. Sd e Rd correspondem à própria linha. ηreal usa a ação informada; ηd usa a ação adotada na conferência. A fórmula e a referência de cada linha são identificadas por E. Os estados são fornecidos pelo motor antes do arredondamento visual.')
    grouped=OrderedDict()
    for row in checks:grouped.setdefault(str(row.get('component','Sem componente')),[]).append(row)
    for component,items in grouped.items():
        doc.add_paragraph(component_label(component),style='Heading 2')
        rows=[]
        for row in items:
            fkey=(str(row.get('formula','Fórmula não fornecida')),str(row.get('reference','Referência não fornecida')))
            state=state_label(row.get('status', 'NOT_EVALUATED'))
            rows.append((check_label(row)+'\n'+str(row.get('id','')),
                         _force(row.get('actual_demand_N')),_force(row.get('demand_N')),
                         _force(row.get('design_capacity_N')),_num(row.get('actual_utilization'))+'\n'+_num(row.get('utilization')),
                         state,formulas[fkey]))
        _tab(doc,['Verificação e ID','Sd real\nkgf','Sd conf.\nkgf','Rd\nkgf','ηreal\nηd','Linha','Eq'],rows,[2.50,.84,.84,.84,.96,.62,.47],size=7.8)
    # Preserve every optional computed detail supplied by the engine. These
    # are supporting numbers, not a second independently rounded calculation.
    standard={'id','label','component','demand_N','actual_demand_N','design_capacity_N','utilization','actual_utilization','status','formula','reference'}
    details=[(str(row.get('id','')),[(str(k),v) for k,v in row.items() if k not in standard]) for row in checks]
    details=[(cid,items) for cid,items in details if items]
    if details:
        doc.add_paragraph('Áreas trajetos e valores auxiliares',style='Heading 1')
        for cid,items in details:
            p=doc.add_paragraph();p.add_run(cid+': ').bold=True
            p.add_run('; '.join(path+' = '+value for k,v in items for path,value in _flatten(v,k))+'.')

def create_report(c, r=None):
    """Return editable DOCX bytes without promoting partial local results."""
    r = validated_result(c, r)
    doc = Document(); section = doc.sections[0]
    section.page_width = Inches(8.27); section.page_height = Inches(11.69)
    section.top_margin = section.bottom_margin = Inches(.48)
    section.left_margin = section.right_margin = Inches(.60)
    for name in ('Normal', 'Title', 'Subtitle', 'Heading 1', 'Heading 2'):
        doc.styles[name].font.name = 'Arial'; doc.styles[name].font.color.rgb = RGBColor(0, 0, 0)
    for style in doc.styles:
        for border in style.element.xpath('.//w:pBdr'):
            border.getparent().remove(border)
    doc.styles['Normal'].font.size = Pt(9); doc.styles['Normal'].paragraph_format.space_after = Pt(5)
    doc.styles['Title'].font.size = Pt(21); doc.styles['Subtitle'].font.size = Pt(11)
    doc.styles['Heading 1'].font.size = Pt(12); doc.styles['Heading 2'].font.size = Pt(10)
    doc.core_properties.title = 'Memória de cálculo R017: cantoneiras e recorte duplo'
    doc.core_properties.author = 'LRO Soluções de engenharia LTDA.'
    doc.core_properties.subject = 'Ligação parafusada à alma de viga de apoio; verificação local e contenção externa'
    doc.add_paragraph('Memória de cálculo da ligação R017', style='Title')
    doc.add_paragraph('Duas cantoneiras parafusadas · recorte duplo · alma de viga de apoio', style='Subtitle')
    doc.add_paragraph(str(c.project)); doc.add_paragraph(c.beam.name + ' → ' + c.support.name + ' | Componente ' + COMPONENT_VERSION)
    status = str(r.get('status', 'RESULTADO INCOMPLETO'))
    unbound = not isinstance(r.get('inputs'), dict)
    approved = _approved(r)
    p = doc.add_paragraph(); p.add_run('Resultado sem vínculo de entrada: aprovação não disponível' if unbound else STATUS.get(status, status) if approved or status not in ('COMPLETE_LOCAL_CHECKS_PASS_WITHIN_SCOPE', 'COMPLETE_LOCAL_CHECKS_PASS_WITH_PRESET_DEVIATION') else 'Completude local não confirmada; sem aprovação').bold = True
    doc.add_paragraph('Estado do motor: ' + status + '.')
    if not approved:
        p = doc.add_paragraph('Não há aprovação local da ligação nesta avaliação. Linhas atendidas não eliminam falhas, verificações ausentes ou limites de escopo.'); p.runs[0].bold = True
    else:
        doc.add_paragraph('Atendimento local condicionado às premissas e contenções externas documentadas. A avaliação não abrange dimensionamento global dos membros nem verificação independente das contenções declaradas.')
    doc.add_paragraph('Verificação global dos membros: EXTERNA, NÃO AVALIADA em todos os casos. Não há aprovação global da estrutura nesta memória.')
    summary = _mapping(r.get('summary')); lm = _mapping(r.get('load_model'))
    governing = next((row for row in (r.get('checks') or []) if row['id'] == summary.get('governing_check_id')), None)
    governing_label = check_label(governing) if governing else str(summary.get('governing_label', 'não disponível'))
    _tab(doc, ['Síntese da avaliação', 'Resultado'], [
        ('Vsd da entrada em kgf', _force(c.V)), ('Vd da conferência em kgf', _force(lm.get('Vd_N'))),
        ('Verificação governante', governing_label),
        ('Índice governante real', _num(summary.get('actual_governing_utilization'))),
        ('Índice governante da conferência', _num(summary.get('governing_utilization'))),
        ('Número de verificações calculadas', len(r.get('checks') or [])),
        ('Atendimento local R017 no domínio', 'sim, no domínio' if approved else 'não'),
        ('Viga de apoio e membros completos', 'Verificação global externa')], [3.7, 3.37])
    doc.add_paragraph('Unidades internas: N, mm e MPa; momentos em N mm. Forças apresentadas em kgf, com 1 kgf = 9,80665 N. Os valores do motor são mantidos sem arredondamento intermediário; o arredondamento visual não altera a decisão.')
    doc.add_paragraph('Pendências e condições de uso', style='Heading 1')
    issues = [item for item in (r.get('issues') or []) if isinstance(item, dict)]
    for issue in issues:
        p = doc.add_paragraph(); p.add_run(SEVERITY.get(issue.get('severity'), str(issue.get('severity', 'Ocorrência'))) + ': ').bold = True
        p.add_run(str(issue.get('text', 'Sem descrição.')))
        if issue.get('reference'):
            p.add_run(' Referência: ' + str(issue['reference']) + '.')
    if not issues:
        doc.add_paragraph('Nenhuma ocorrência fornecida. A ausência de ocorrências não amplia o domínio nem substitui verificações ausentes.')
    try:
        png = image_bytes(c, r)
    except (ValueError, TypeError, AttributeError, OverflowError) as exc:
        doc.add_paragraph('Desenho não gerado por entrada sem representação segura: ' + str(exc))
    else:
        _section(doc, True)
        picture = doc.add_picture(BytesIO(png), width=Inches(9.15))
        doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
        picture._inline.docPr.set('descr', 'R017: elevação da viga com dois recortes arredondados, frente da única alma contínua de apoio e planta de duas cantoneiras L. n parafusos comuns em corte duplo e 2n parafusos no apoio em corte simples; dimensões reais e sentido de V.')
        _section(doc, False)
    _envelopes(doc, r)
    _inputs(doc, c, r); _loads(doc, c, r); _cope(doc, c, r); _support(doc, c, r); _checks(doc, r)
    for item in (r.get('not_applicable') or []):
        if isinstance(item, dict):
            doc.add_paragraph(str(item.get('mechanism', '')) + ': ' + str(item.get('reason', '')) + ' Referência: ' + str(item.get('reference', '')) + '.')
    doc.add_paragraph('Domínio, fontes e responsabilidade técnica', style='Heading 1').paragraph_format.page_break_before = True
    scope = r.get('scope', SCOPE)
    doc.add_paragraph(str(scope.get('statement', SCOPE)) if isinstance(scope, dict) else str(scope))
    for exclusion in (r.get('exclusions') or EXCLUSIONS):
        doc.add_paragraph(str(exclusion), style='List Bullet')
    doc.add_paragraph('Fonte geométrica: PADRÃO DE LIGAÇÕES 2Model, R017, página impressa 20. Os dois cantos são R15. A folha não fixa um comprimento ou profundidade universal de recorte e não contém tabela métrica de e/s. Os valores de bordas e passos do preset são gabarito adotado da tabela industrial R016; não são atribuídos à folha R017. A recomendação Gerdau de raio mínimo aproximadamente 12 mm é uma informação separada; não substitui o R15 industrial.')
    doc.add_paragraph('Componentes: ' + NBR + ', itens 6.1, 6.3, 6.5.5 e 6.5.6. Gerdau, Ligações para Estruturas de Aço, 7ª edição, 2018, páginas 19–26: mecanismo convencional e recorte. As tabelas históricas usam NBR 8800:2008 e excluem o apoio (p.9); não são reescaladas nesta avaliação.')
    doc.add_paragraph('Dowswell e Whyte, Local Stability of Double-Coped Beams, Engineering Journal 51(1), 2014, páginas 43–52, DOI 10.62913/engj.v51i1.1055: domínio e contenções dos recortes iguais. A fórmula complementar não é uma equação direta de instabilidade da NBR atual.')
    p = doc.add_paragraph(); hyperlink(p, 'Fonte primária do modelo de estabilidade', 'https://ej.aisc.org/index.php/engj/article/download/1055/1054/1054')
    doc.add_paragraph('AISC, Table Talk, Modern Steel Construction, fevereiro de 2024, e Simple Shear Connection Limit States, fevereiro de 2008: corroboração primária indexada do contato e rasgamento na alma de apoio, sem reprodução visual de exemplo completo ou validação global do apoio.')
    doc.add_paragraph('Rotação, estabilidade global, serviço, fadiga e montagem exigem compatibilização de projeto. As condições externas devem existir no detalhe executado. Ressalvas não substituem verificações aplicáveis.')
    p = doc.add_paragraph(); hyperlink(p, BRAND, LINK)
    out = BytesIO(); doc.save(out); return out.getvalue()
