"""Current-input, four-view drawing of the independent welded-support 2L route.

The column face is x=0; x follows the beam, y is vertical, and z crosses
the one beam web. Each physical angle is drawn separately. Supplied results
never supply geometry or approval: every entry point evaluates current input.
"""
from io import BytesIO

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.path import Path
from matplotlib.patches import Circle, PathPatch, Polygon, Rectangle

from .angle_catalog_selection import add_drawing_provenance
from .display_precision import display_format
from .drawing_annotations import dimension, rendered_wrap
from .models import finite_real

INK = '#263746'
MUTED = '#667785'
MEMBER = '#e2e8ee'
SHOP = '#88bcc7'
FIELD = '#b7c9ed'
WELD = '#b53231'
RETURN = '#a96712'
RED = '#a32835'

STATUS = {
    'INVALID_INPUT': 'DADOS INVÁLIDOS',
    'NUMERICAL_FAILURE': 'FALHA NUMÉRICA',
    'INVALID_GEOMETRY': 'GEOMETRIA INVÁLIDA',
    'OUTSIDE_SUPPORTED_SCOPE': 'FORA DO DOMÍNIO SUPORTADO',
    'DETAIL_FAIL': 'DETALHAMENTO NÃO ATENDIDO',
    'VERIFIED_SUBCHECK_FAIL': 'HÁ VERIFICAÇÃO NÃO ATENDIDA',
    'ENGINEERING_MODEL_PENDING': 'VERIFICAÇÃO COMPLEMENTAR PENDENTE',
    'COMPLETE_CHECKS_PASS_WITHIN_SCOPE': 'VERIFICAÇÕES LOCAIS ATENDIDAS NO DOMÍNIO',
}


def validated_result(c, result=None):
    """Ignore even a plausible or forged cached result; evaluate input now."""
    from .welded_support_double_angle import evaluate
    try:
        return evaluate(c)
    except (AttributeError, TypeError, ValueError, ArithmeticError) as exc:
        return dict(status='INVALID_INPUT', global_pass=False, checks=[],
                    geometry={}, summary={}, issues=[dict(
                        severity='invalid_input', text=str(exc))])


def _approved(result):
    """Local approval requires all gates, not just a truthy cached flag."""
    if not isinstance(result, dict):
        return False
    geometry = result.get('geometry')
    summary = result.get('summary')
    checks = result.get('checks')
    issues = result.get('issues')
    if not (isinstance(geometry, dict) and isinstance(summary, dict)
            and isinstance(checks, list) and isinstance(issues, list)):
        return False
    return (result.get('global_pass') is True
            and result.get('status') == 'COMPLETE_CHECKS_PASS_WITHIN_SCOPE'
            and geometry.get('valid') is True
            and geometry.get('physical_angle_count') == 2
            and geometry.get('physical_beam_webs') == 1
            and geometry.get('shear_planes') == 2
            and geometry.get('support_bolt_count') == 0
            and geometry.get('beam_weld_count') == 0
            and summary.get('complete_checks') is True
            and bool(checks)
            and all(isinstance(row, dict) and row.get('status') == 'PASS'
                    for row in checks)
            and all(isinstance(row, dict) and row.get('severity') not in {
                'invalid_input', 'invalid_geometry', 'unsupported_scope',
                'numerical_failure', 'detail_fail', 'access_pending',
                'engineering_pending', 'error', 'pending'} for row in issues))


def _num(value, signed=False):
    if finite_real(value):
        return display_format(value, '+.2f' if signed else '.2f')
    if isinstance(value, int) and not isinstance(value, bool):
        return 'inteiro fora da faixa numérica'
    return str(value)


def _label(value, limit=240):
    text = str(value)
    return text if len(text) <= limit else text[:limit] + ' […]'


def _drawable(c):
    """Reject unusable solids/scales without silently substituting a preset."""
    positive = ('beam_leg', 'support_leg', 't', 'length', 'beam_gauge',
                'web_pitch', 'web_end_top', 'db', 'hole_diameter', 'weld_leg')
    nonnegative = ('root_radius', 'angle_top', 'gap', 'top_return')
    values = []
    for key in positive + nonnegative:
        value = getattr(c, key, None)
        if not finite_real(value) or value < 0 or (key in positive and value == 0):
            return False
        values.append(value)
    for key in ('beam', 'support'):
        profile = getattr(c, key, None)
        for field in ('d', 'bf', 'tw', 'tf', 'clear'):
            value = getattr(profile, field, None)
            if not finite_real(value) or value <= 0:
                return False
            values.append(value)
        if profile.d <= 2*profile.tf or profile.bf <= profile.tw:
            return False
    if type(getattr(c, 'web_rows', None)) is not int or not 1 <= c.web_rows <= 20:
        return False
    if any(not finite_real(getattr(c, key, None)) for key in ('V', 'N', 'M', 'torsion')):
        return False
    solids = [value for value in values if value > 0]
    if max(solids) > 1e6 or min(solids) < 1e-5 or max(solids)/min(solids) > 1e6:
        return False
    if c.t + c.root_radius >= min(c.beam_leg, c.support_leg):
        return False
    if c.top_return > c.support_leg or c.gap >= c.beam_leg:
        return False
    return True


def _topology(c):
    return (getattr(c, 'kind', None) == 'column_flange'
            and getattr(c, 'angle_count', None) == 2
            and getattr(c, 'symmetric', None) is True
            and getattr(c, 'web_columns', None) == 1
            and getattr(c, 'assembly', None) == 'one_shop_angle_other_field_weld'
            and getattr(c, 'weld_layout', None) == 'toe_vertical_short_top'
            and getattr(c, 'cope', None) == 'none'
            and getattr(getattr(c, 'beam', None), 'family', None) == 'W'
            and getattr(getattr(c, 'support', None), 'family', None) == 'W')


def _provenance(fig, c):
    try:
        return add_drawing_provenance(fig, c, area_factor=2)
    except (AttributeError, TypeError, ValueError, ArithmeticError):
        fig.text(.035, .829, 'Identidade do catálogo inconsistente; proveniência não validada.',
                 fontsize=8, color=RED, parse_math=False).set_gid('invalid_catalog_provenance')
        return fig


def _figure(c, result=None):
    result = validated_result(c, result)
    fig = plt.figure(figsize=(17, 13), facecolor='white')

    def text(x, y, value, gid=None, **kwargs):
        artist = fig.text(x, y, value, color=kwargs.pop('color', INK),
                          parse_math=False, **kwargs)
        artist.set_gid(gid)
        return artist

    text(.035, .967, '2L  |  CANTONEIRAS SOLDADAS À MESA DO PILAR',
         'drawing_family_welded_support_double_angle', fontsize=17, fontweight='bold')
    text(.035, .941, 'Projeto: ' + _label(getattr(c, 'project', '')),
         'current_project', fontsize=9)
    beam, support = getattr(c, 'beam', None), getattr(c, 'support', None)
    text(.035, .920, 'Viga: ' + _label(getattr(beam, 'name', '?'), 80)
         + '  |  Pilar: ' + _label(getattr(support, 'name', '?'), 80),
         'current_profiles', fontsize=9)
    status = result.get('status', 'INVALID_INPUT')
    approved = _approved(result)
    text(.035, .895, STATUS.get(status, str(status)), 'engine_status_' + str(status),
         fontsize=10, fontweight='bold', color=INK if approved else RED)
    text(.965, .895, 'ATENDIMENTO LOCAL' if approved else 'SEM APROVAÇÃO GLOBAL',
         'approval_status', ha='right', fontsize=9, color=INK if approved else RED)
    actions = '; '.join(label + '=' + _num(getattr(c, key, None), True) + unit
                       for key, label, unit in [('V', 'V', ' N'), ('N', 'N', ' N'),
                                               ('M', 'M', ' N mm'), ('torsion', 'T', ' N mm')])
    text(.035, .873, 'Ações reais: ' + actions, 'actual_signed_actions', fontsize=9)
    text(.035, .851, 'ESTADO FINAL SOMENTE  |  Uma cantoneira de oficina + outra de campo; viga mantida içada durante a montagem.',
         'final_state_assembly_banner', fontsize=9, fontweight='bold')

    if not _drawable(c) or not _topology(c):
        text(.06, .760, 'ENTRADA SEM REPRESENTAÇÃO FÍSICA SEGURA', 'diagnostic_only',
             fontsize=17, fontweight='bold', color=RED)
        rows = [
            'As dimensões ou a topologia exigem um detalhe próprio; nenhum exemplo substituiu a entrada.',
            'Apoio: ' + _label(getattr(c, 'kind', None))
            + '; cantoneiras: ' + _label(getattr(c, 'angle_count', None))
            + '; simétricas: ' + _label(getattr(c, 'symmetric', None)) + '.',
            'Montagem: ' + _label(getattr(c, 'assembly', None))
            + '; recorte: ' + _label(getattr(c, 'cope', None)) + '.',
            'Solda: ' + _label(getattr(c, 'weld_layout', None))
            + '; colunas de parafusos: ' + _label(getattr(c, 'web_columns', None)) + '.',
            'Abas viga/apoio = ' + _num(getattr(c, 'beam_leg', None)) + ' / '
            + _num(getattr(c, 'support_leg', None)) + '; t = ' + _num(getattr(c, 't', None))
            + '; H = ' + _num(getattr(c, 'length', None)) + ' mm.',
        ]
        rows += [_label(row.get('text', row.get('message', '')), 400)
                 for row in result.get('issues', [])[:12]]
        if len(result.get('issues', [])) > 12:
            rows.append('Demais impedimentos constam da avaliação atual.')
        text(.06, .713, rendered_wrap('\n'.join(rows), 1010, 10), 'input_diagnostic',
             fontsize=10, va='top', linespacing=1.6)
        text(.035, .045, 'Esquema não emitido. Sem aprovação global ou liberação de fabricação.',
             fontsize=10, color=RED)
        return _provenance(fig, c)

    # Four independent equal-aspect views. Annotations have reserved lanes;
    # the enlarged grip is explicitly a separate scale.
    elev = fig.add_axes((.035, .491, .495, .306))
    front = fig.add_axes((.577, .491, .388, .306))
    plan = fig.add_axes((.035, .225, .495, .219))
    grip = fig.add_axes((.602, .238, .338, .206))
    for ax, name in ((elev, 'elevation_xy'), (front, 'support_face_zy'),
                     (plan, 'plan_xz'), (grip, 'grip_section_zy')):
        ax.set_aspect('equal')
        ax.axis('off')
        ax.set_gid('view_' + name)

    def title(ax, label):
        ax.set_title(label, loc='left', fontsize=10, fontweight='bold', color=INK, pad=13)

    def rect(ax, x, y, w, h, fill, gid, **kwargs):
        patch = Rectangle((x, y), w, h, facecolor=fill, edgecolor=INK, lw=.8, **kwargs)
        patch.set_gid(gid)
        ax.add_patch(patch)
        return patch

    def line(ax, xs, ys, gid=None, **kwargs):
        artist, = ax.plot(xs, ys, color=kwargs.pop('color', INK), lw=kwargs.pop('lw', .8), **kwargs)
        artist.set_gid(gid)
        return artist

    def dim(ax, p1, p2, label, gid, side=1, fontsize=7.5):
        pair = dimension(ax, p1, p2, label, fontsize=fontsize, color=INK,
                         rotation=90 if p1[0] == p2[0] else 0, short_side=side)
        pair[0].set_gid('dimension_' + gid)
        pair[1].set_gid('dimension_label_' + gid)
        return pair

    def leader(ax, label, xy, xytext, gid=None, **kwargs):
        artist = ax.annotate(label, xy=xy, xytext=xytext, ha=kwargs.pop('ha', 'left'),
                             va='center', fontsize=7.7, color=kwargs.pop('color', INK),
                             arrowprops={'arrowstyle': '-', 'lw': .6, 'color': MUTED},
                             bbox={'facecolor': 'white', 'edgecolor': 'none', 'pad': 1.4},
                             parse_math=False, **kwargs)
        artist.set_gid(gid)
        return artist

    def cut(ax, left, right, y, gid):
        span = right-left
        line(ax, [left, left+.4*span, left+.45*span, left+.5*span, right],
             [y, y, y+6, y, y], gid, lw=1)

    def flag(ax, x, y, gid):
        # Field-weld flag identifies the right-hand angle; no extra weld line.
        line(ax, [x, x], [y, y+20], gid + '_staff', color=MUTED)
        patch = Polygon([(x, y+20), (x+13, y+14), (x, y+8)],
                        facecolor=FIELD, edgecolor=INK, lw=.7)
        patch.set_gid(gid)
        ax.add_patch(patch)

    yt = c.beam.d/2-c.angle_top
    yb = yt-c.length
    ys = [yt-c.web_end_top-i*c.web_pitch for i in range(c.web_rows)]
    end = c.length-c.web_end_top-(c.web_rows-1)*c.web_pitch
    z0 = c.beam.tw/2
    toe = z0+c.support_leg
    b, s, t, rr = c.beam_leg, c.support_leg, c.t, c.root_radius
    stub = max(b+175, c.beam.d*.78, c.beam_gauge+100)
    top = max(c.beam.d/2, yt, max(ys))+30
    bottom = min(-c.beam.d/2, yb, min(ys))-30
    dl = max(top-bottom, c.beam.d)*.045

    title(elev, 'A  ELEVAÇÃO x–y  |  viga sem recorte')
    rect(elev, -c.support.d, bottom, c.support.d, top-bottom, MEMBER, 'column_elevation_crop', alpha=.48)
    rect(elev, -c.support.tf, bottom, c.support.tf, top-bottom, MEMBER, 'column_front_flange_elevation')
    rect(elev, -c.support.d, bottom, c.support.tf, top-bottom, MEMBER, 'column_rear_flange_elevation')
    cut(elev, -c.support.d, 0, top, 'column_top_crop_elevation')
    cut(elev, -c.support.d, 0, bottom, 'column_bottom_crop_elevation')
    rect(elev, c.gap, -c.beam.d/2, stub-c.gap, c.beam.d, '#f4f6f8', 'single_beam_web_elevation')
    rect(elev, c.gap, -c.beam.d/2, stub-c.gap, c.beam.tf, MEMBER, 'beam_bottom_flange_uncoped_elevation')
    rect(elev, c.gap, c.beam.d/2-c.beam.tf, stub-c.gap, c.beam.tf, MEMBER, 'beam_top_flange_uncoped_elevation')
    rect(elev, 0, yb, b, c.length, FIELD, 'two_angles_overlapped_beam_legs_elevation', alpha=.9)
    # The two toe welds project together at x=0, always on the column face.
    line(elev, [0, 0], [yb, yt], 'two_column_toe_welds_projection_elevation', color=WELD, lw=2.6)
    for index, y in enumerate(ys, 1):
        hole = Circle((c.beam_gauge, y), c.hole_diameter/2, facecolor='white', edgecolor=INK, lw=.9)
        hole.set_gid('common_web_hole_elevation_' + str(index))
        elev.add_patch(hole)
        q = c.hole_diameter*.23
        line(elev, [c.beam_gauge-q, c.beam_gauge+q], [y, y], 'hole_center_x_' + str(index), lw=.5)
        line(elev, [c.beam_gauge, c.beam_gauge], [y-q, y+q], 'hole_center_y_' + str(index), lw=.5)
    lane = b+dl
    dim(elev, (lane, yb), (lane, yt), 'H='+_num(c.length), 'angle_length')
    chain = lane+2.3*dl
    dim(elev, (chain, ys[0]), (chain, yt), 'e₁='+_num(c.web_end_top), 'web_end_top', -1)
    if len(ys) > 1:
        dim(elev, (chain, ys[-1]), (chain, ys[0]), str(c.web_rows-1)+' × p='+_num(c.web_pitch), 'web_pitch', -1)
    dim(elev, (chain, yb), (chain, ys[-1]), 'e₂='+_num(end), 'web_end_bottom', -1)
    dim(elev, (0, top+dl), (c.beam_gauge, top+dl), 'e='+_num(c.beam_gauge), 'beam_gauge')
    dim(elev, (0, bottom-dl), (b, bottom-dl), 'b viga='+_num(b), 'beam_leg', -1)
    leader(elev, 'folga='+_num(c.gap), (c.gap/2, -c.beam.d/2), (-c.support.d*.69, bottom-1.9*dl), 'beam_end_gap')
    leader(elev, '2L sobrepostas\nna projeção', (b*.25, (yt+yb)/2),
           (-c.support.d*.83, yt-c.length*.28), 'two_angles_elevation_projection')
    leader(elev, '2 filetes na mesa\n(ver B)', (0, yb+c.length*.14),
           (-c.support.d*.83, yb+c.length*.06), 'support_weld_projection_label', color=WELD)
    leader(elev, 'a₀='+_num(c.angle_top), (b, yt), (stub-5, top+dl), 'angle_top_offset', ha='right')
    load_x, load_y = stub-21, (yt+yb)/2
    if c.V:
        direction = -1 if c.V > 0 else 1
        artist = elev.annotate('', xy=(load_x, load_y+direction*48), xytext=(load_x, load_y-direction*33),
                               arrowprops={'arrowstyle': '-|>', 'color': RED, 'lw': 1.7, 'mutation_scale': 14})
        artist.set_gid('load_V_positive_down' if c.V > 0 else 'load_V_negative_up')
        artist.arrow_patch.set_gid(artist.get_gid())
    elev.text(load_x-10, load_y, 'V='+_num(c.V/1000)+'\nkN', fontsize=8.7,
              ha='right', va='center', color=RED).set_gid('actual_load_V')
    elev.text(-c.support.d, top+dl, 'Pilar contínuo\n(trecho interrompido)', fontsize=7.3,
              color=MUTED, va='center')
    elev.set_xlim(-c.support.d-12, stub+12)
    elev.set_ylim(bottom-3*dl, top+2.6*dl)

    title(front, 'B  FACE DO APOIO z–y  |  duas soldas independentes')
    rect(front, -c.support.bf/2, bottom, c.support.bf, top-bottom,
         MEMBER, 'column_flange_support_face', alpha=.65)
    for z in (-c.support.tw/2, c.support.tw/2):
        line(front, [z, z], [bottom, top], color=MUTED, ls='--', lw=.5)
    cut(front, -c.support.bf/2, c.support.bf/2, top, 'column_top_crop_front')
    cut(front, -c.support.bf/2, c.support.bf/2, bottom, 'column_bottom_crop_front')
    for sign, fill, role in ((-1, SHOP, 'shop'), (1, FIELD, 'field')):
        heel, outer = sign*z0, sign*toe
        rect(front, min(heel, outer), yb, s, c.length, fill, role+'_angle_support_leg_front')
        line(front, [outer, outer], [yb, yt], role+'_weld_vertical_toe_front',
             color=WELD, lw=3.1, solid_capstyle='butt')
        line(front, [outer, outer-sign*c.top_return], [yt, yt],
             role+'_weld_short_top_return_uncredited_front', color=RETURN, lw=3.1, solid_capstyle='butt')
        # Plain lower and heel borders are physical steel outlines, never welds.
        label_x = sign*(c.support.bf/2+24)
        leader(front, 'L1 OFICINA' if sign < 0 else 'L2 CAMPO',
               (sign*(z0+s*.54), yt-c.length*.20), (label_x, yt-c.length*.17),
               role+'_assembly_label', ha='right' if sign < 0 else 'left')
        leader(front, 'retorno '+_num(c.top_return)+'\nsem crédito',
               (outer-sign*c.top_return/2, yt), (label_x, yt+48),
               role+'_uncredited_return_label', ha='right' if sign < 0 else 'left', color=RETURN)
        leader(front, 'toe vertical\nw='+_num(c.weld_leg),
               (outer, yb+c.length*.30), (label_x, yb+c.length*.18),
               role+'_vertical_weld_label', ha='right' if sign < 0 else 'left', color=WELD)
    flag(front, c.support.bf/2+24, yt-c.length*.17+10, 'field_weld_flag')
    # Beam end projection preserves both continuous flanges and ONE web.
    rect(front, -z0, -c.beam.d/2+c.beam.tf, c.beam.tw, c.beam.d-2*c.beam.tf,
         'none', 'single_beam_web_front_projection', linestyle='--')
    for label, y in [('top', c.beam.d/2-c.beam.tf), ('bottom', -c.beam.d/2)]:
        rect(front, -c.beam.bf/2, y, c.beam.bf, c.beam.tf, 'none',
             'beam_'+label+'_flange_uncoped_front_projection', linestyle='--')
    for index, y in enumerate(ys, 1):
        line(front, [-z0-t-5, z0+t+5], [y, y], 'common_web_bolt_front_projection_'+str(index), lw=1.7)
    dim(front, (-c.support.bf/2, bottom-dl), (c.support.bf/2, bottom-dl),
        'bf pilar='+_num(c.support.bf), 'column_flange_width', -1)
    dim(front, (-toe, top+dl), (-z0, top+dl), 'b='+_num(s), 'shop_support_leg')
    dim(front, (z0, top+dl), (toe, top+dl), 'b='+_num(s), 'field_support_leg')
    front.text(0, yb-22, 'Bordas inferiores e talões SEM SOLDA', ha='center', va='top',
               fontsize=7.7, color=INK, bbox={'facecolor': 'white', 'edgecolor': 'none', 'pad': 1.3}
               ).set_gid('no_bottom_or_heel_welds_front')
    front.set_xlim(-c.support.bf/2-125, c.support.bf/2+125)
    front.set_ylim(bottom-2.8*dl, top+2.7*dl)

    title(plan, 'C  PLANTA x–z  |  duas peças L simétricas; uma alma')
    rect(plan, -c.support.d, -c.support.bf/2, c.support.tf, c.support.bf,
         MEMBER, 'column_rear_flange_plan')
    rect(plan, -c.support.tf, -c.support.bf/2, c.support.tf, c.support.bf,
         MEMBER, 'column_front_flange_plan')
    rect(plan, -c.support.d+c.support.tf, -c.support.tw/2,
         c.support.d-2*c.support.tf, c.support.tw, MEMBER, 'column_web_plan')
    rect(plan, c.gap, -z0, stub-c.gap, c.beam.tw, MEMBER, 'single_beam_web_plan')
    # The dashed rectangle is the uninterrupted flange envelope, not a cope.
    rect(plan, c.gap, -c.beam.bf/2, stub-c.gap, c.beam.bf, 'none',
         'continuous_beam_flange_envelope_plan', linestyle='--', alpha=.65)
    k = .5522847498307936
    for sign, fill, role in ((-1, SHOP, 'shop'), (1, FIELD, 'field')):
        vertices = [(0, z0), (b, z0), (b, z0+t), (t+rr, z0+t)]
        codes = [Path.MOVETO, Path.LINETO, Path.LINETO, Path.LINETO]
        if rr:
            vertices.extend([(t+rr-k*rr, z0+t), (t, z0+t+rr-k*rr), (t, z0+t+rr)])
            codes.extend([Path.CURVE4]*3)
        else:
            vertices.append((t, z0+t))
            codes.append(Path.LINETO)
        vertices.extend([(t, z0+s), (0, z0+s), (0, z0)])
        codes.extend([Path.LINETO, Path.LINETO, Path.CLOSEPOLY])
        patch = PathPatch(Path([(x, sign*z) for x, z in vertices], codes),
                          facecolor=fill, edgecolor=INK, lw=1)
        patch.set_gid(role+'_physical_angle_L_plan')
        plan.add_patch(patch)
        patch = Polygon([(0, sign*toe), (c.weld_leg, sign*toe), (0, sign*(toe+c.weld_leg))],
                        facecolor=WELD, edgecolor=WELD, lw=.6)
        patch.set_gid(role+'_column_toe_weld_section_plan')
        plan.add_patch(patch)
        leader(plan, 'L1 · OFICINA' if sign < 0 else 'L2 · CAMPO',
               (b*.77, sign*(z0+t/2)), (b+41, sign*(c.support.bf*.37)),
               role+'_angle_label_plan')
    low, high = -z0-t, z0+t
    rect(plan, c.beam_gauge-c.hole_diameter/2, low, c.hole_diameter, high-low,
         'white', 'common_three_plate_hole_plan')
    rect(plan, c.beam_gauge-c.db/2, low-7, c.db, high-low+14,
         '#718494', 'common_web_bolt_shank_plan')
    rect(plan, c.beam_gauge-c.db*.70, low-12, c.db*1.4, 5, INK, 'web_bolt_head_plan')
    rect(plan, c.beam_gauge-c.db*.65, high+7, c.db*1.3, 5, INK, 'web_bolt_nut_plan')
    for sign, role in ((-1, 'shop'), (1, 'field')):
        line(plan, [c.beam_gauge-c.db*.75, c.beam_gauge+c.db*.75], [sign*z0, sign*z0],
             role+'_shear_plane_plan', color=RED, lw=1.3, ls='--')
    dim(plan, (0, -c.support.bf/2-28), (b, -c.support.bf/2-28),
        'b viga='+_num(b), 'beam_leg_plan', -1)
    leader(plan, 'mesa tf='+_num(c.support.tf), (-c.support.tf/2, c.support.bf*.30),
           (-c.support.d*.75, c.support.bf/2+27), 'column_flange_thickness')
    leader(plan, '2 filetes verticais\nna mesa do pilar', (c.weld_leg/3, -toe-c.weld_leg/3),
           (-c.support.d*.82, -c.support.bf*.30), 'column_toe_welds_plan', color=WELD)
    leader(plan, 'mesas contínuas\nsem recorte', (stub-25, c.beam.bf/2),
           (stub-9, c.support.bf/2+27), 'uncoped_beam_plan', ha='right')
    plan.set_xlim(-c.support.d-15, stub+12)
    plan.set_ylim(-c.support.bf/2-59, c.support.bf/2+59)

    title(grip, 'D  CORTE NO PARAFUSO  |  pega real, ampliada')
    height = max(3*c.db, 2.5*(c.beam.tw+2*t))
    rect(grip, low, -height/2, t, height, SHOP, 'shop_angle_beam_leg_grip')
    rect(grip, -z0, -height/2, c.beam.tw, height, MEMBER, 'single_beam_web_grip')
    rect(grip, z0, -height/2, t, height, FIELD, 'field_angle_beam_leg_grip')
    rect(grip, low, -c.hole_diameter/2, high-low, c.hole_diameter, 'white', 'common_three_plate_hole_grip')
    extra = max(c.db*.4, 4)
    rect(grip, low-extra, -c.db/2, high-low+2*extra, c.db, '#718494', 'common_web_bolt_shank_grip')
    rect(grip, low-extra-4, -c.db*.70, 4, c.db*1.4, INK, 'web_bolt_head_grip')
    rect(grip, high+extra, -c.db*.65, 4, c.db*1.3, INK, 'web_bolt_nut_grip')
    for sign, role in ((-1, 'shop'), (1, 'field')):
        line(grip, [sign*z0, sign*z0], [-height*.58, height*.58],
             role+'_shear_plane_grip', color=RED, lw=1.4, ls='--')
    dim(grip, (low, -height*.82), (high, -height*.82),
        'pega = tw+2t = '+_num(c.beam.tw+2*t), 'double_shear_grip', -1, 7.8)
    leader(grip, 'L1 · t='+_num(t), (low+t/2, height*.35),
           (low-18, height*.37), 'shop_angle_thickness_grip', ha='right')
    leader(grip, 'L2 · t='+_num(t), (z0+t/2, height*.35),
           (high+18, height*.37), 'field_angle_thickness_grip')
    leader(grip, 'Alma única\ntw='+_num(c.beam.tw), (0, -height*.35),
           (high+18, -height*.28), 'single_web_thickness_grip')
    grip.text(0, height*.74, '2 PLANOS DE CORTE', ha='center', va='center',
              fontsize=8.5, color=RED, fontweight='bold').set_gid('two_shear_planes_grip_label')
    grip.text(0, -height*1.09, 'Um parafuso comum atravessa L1 + alma + L2.', ha='center',
              va='center', fontsize=7.7).set_gid('one_common_bolt_three_plies')
    grip.set_xlim(low-70, high+80)
    grip.set_ylim(-height*1.22, height*.92)

    summary = [
        '2 peças L iguais '+_num(b)+' × '+_num(s)+' × '+_num(t)+'; H='+_num(c.length)
        + '; raio interno r='+_num(rr)+' mm. Aço L: '+_label(c.angle_steel, 80)+'.',
        str(c.web_rows)+' parafusos comuns '+_label(c.bolt, 80)+' Ø'+_num(c.db)
        + '; furos físicos Ø'+_num(c.hole_diameter)+'; uma alma; corte duplo; pega tw+2t='+_num(c.beam.tw+2*t)+' mm.',
        'Por cantoneira: um filete vertical externo H='+_num(c.length)+'; w='+_num(c.weld_leg)
        + ' mm; retorno superior curto '+_num(c.top_return)+' mm, SEM crédito resistente.',
        'Vermelho: solda resistente na mesa. Ocre: retorno real sem crédito. SEM solda inferior, no talão ou na alma; SEM parafusos no apoio.',
        'Montagem: L1 pré-soldada em oficina; posicionar L2 com a viga içada, soldar L2 em campo e concluir todos os parafusos e o aperto final.',
        'Envelope declarado de soldagem em campo: raio='+_num(c.weld_tool_radius)
        + ' mm; folga de fabricação='+_num(c.fabrication_clearance)+' mm. Acesso real no local e procedimento não certificados.',
        'Somente o estado final é verificado. Fase provisória, estabilidade, içamento, escoramento e procedimento de soldagem não verificados.',
    ]
    if getattr(c, 'reinforced_weld_edge', False) is True:
        summary.append('Borda reforçada declarada: confirmar execução para w≤t (NBR 6.2.6.2.2(b)); nenhum ganho resistente extra creditado.')
    text(.035, .191, 'DETALHE FÍSICO E SEQUÊNCIA DE MONTAGEM', fontsize=10, fontweight='bold')
    text(.035, .169, '\n'.join(summary), 'physical_topology_notes', fontsize=8.5,
         va='top', linespacing=1.48)
    text(.035, .045, 'Cotas em mm. V descendente estático; N=M=T=0; pilar W contínuo; viga sem recorte. Escalas independentes entre vistas.',
         'scope_note', fontsize=8.4)
    text(.035, .025, 'Esquema dimensionado; não libera fabricação, estabilidade global ou retirada do içamento. Detalhe AISC P901 II.A-2A; verificações locais NBR 8800.',
         'fabrication_disclaimer', fontsize=8.2)
    return _provenance(fig, c)


def drawing(c, result=None):
    """Return a matplotlib Figure; the caller owns closing it."""
    with plt.rc_context({'font.family': 'DejaVu Sans', 'font.size': 10,
                         'svg.fonttype': 'none', 'text.parse_math': False}):
        return _figure(c, result)


def image_bytes(c, result=None, fmt='png'):
    """Raster/vector export from current input, never supplied results."""
    with plt.rc_context({'font.family': 'DejaVu Sans', 'font.size': 10,
                         'svg.fonttype': 'none', 'text.parse_math': False}):
        fig = _figure(c, result)
        try:
            output = BytesIO()
            fig.savefig(output, format=fmt, dpi=170, facecolor='white',
                        metadata={'Creator': 'LRO 2L welded to column flange'})
            return output.getvalue()
        finally:
            plt.close(fig)


def drawing_svg(c, result=None):
    return image_bytes(c, result, 'svg').decode('utf-8')
