"""Dimensioned native R016 drawings of two physical L angles.

x is the beam axis, y is vertical and z crosses the beam web. The column
flange face is x=0. Dimensions always come from the input, not a result.
"""
from io import BytesIO
from math import isfinite

from .angle_catalog_selection import add_drawing_provenance
from .double_angle import evaluate, input_errors
from .drawing_annotations import dimension, rendered_wrap

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.path import Path
from matplotlib.patches import Circle, PathPatch, Rectangle

INK='#263746'; MEMBER='#dce2e7'; ANGLE1='#76aeba'; ANGLE2='#e5b978'
MUTED='#677783'; RED='#a52b32'
ANGLES=(('A1','Cantoneira lado −z'),('A2','Cantoneira lado +z'))


def _dimensions(c):
    values=(c.beam.d,c.beam.bf,c.beam.tw,c.beam.tf,c.support.d,c.support.bf,
            c.support.tw,c.support.tf,c.beam_leg,c.support_leg,c.t,c.length,
            c.beam_gauge,c.support_gauge,c.web_pitch,c.support_pitch,
            c.web_end_top,c.support_end_top,c.support_edge_top,c.support_edge_bottom,
            c.hole_diameter,c.db)
    if any(isinstance(v,bool) or not isinstance(v,(int,float)) or not isfinite(v) or v<=0 for v in values):
        raise ValueError('O desenho R016 exige dimensões positivas e finitas.')
    for value in (c.gap,c.angle_top,c.root_radius):
        if isinstance(value,bool) or not isinstance(value,(int,float)) or not isfinite(value) or value<0:
            raise ValueError('Folga, posição e raio devem ser finitos e não negativos.')
    for count in (c.angle_count,c.web_rows,c.support_rows,c.web_columns,c.support_columns):
        if type(count) is not int or not 1<=count<=20:
            raise ValueError('O desenho R016 exige contagens inteiras entre 1 e 20.')
    if not isinstance(c.V,(int,float)) or not isfinite(c.V):
        raise ValueError('V deve ser finito para representar seu sentido.')


def _figure(c,r=None):
    # Caller-supplied results are compatibility-only, never approval evidence.
    errors=input_errors(c)
    if errors:raise ValueError('; '.join(errors))
    _dimensions(c)
    r=evaluate(c)
    fig=plt.figure(figsize=(14,10.1),facecolor='white')
    status=str(r.get('status','SEM AVALIAÇÃO'))
    fig.text(.035,.968,'LIGAÇÃO R016  |  CANTONEIRAS DE ALMA',fontsize=17,fontweight='bold',color=INK)
    # Rendered header rows keep complete free text away from status and views.
    header_y=.944
    header_width=.93*fig.get_figwidth()*72
    def header_row(value, size):
        nonlocal header_y
        item=fig.text(.035,header_y,rendered_wrap(value,header_width,size),
            fontsize=size,color=INK,va='top')
        fig.canvas.draw()
        header_y-=item.get_window_extent(fig.canvas.get_renderer()).height/fig.bbox.height+4/(fig.get_figheight()*72)
        return item
    header_row('Projeto: '+str(c.project),9.5)
    header_row(f'Viga {c.beam.name}  →  mesa do pilar {c.support.name}',9.5)
    header_row(f'Ações reais da entrada: V = {c.V:+} N; N = {c.N:+} N; M = {c.M:+} N mm; T = {c.torsion:+} N mm.',9)
    header_status=fig.text(.965,header_y,status,ha='right',va='top',fontsize=8,color=RED if not r.get('global_pass',False) else INK)
    if not r.get('global_pass',False):
        fig.text(.035,header_y,'SEM APROVAÇÃO GLOBAL',va='top',fontsize=8.8,color=RED)
    fig.canvas.draw()
    header_bottom=header_status.get_window_extent(fig.canvas.get_renderer()).y0
    topology=(c.angle_count==2 and c.symmetric is True and c.kind=='column_flange'
              and c.web_columns==1 and c.support_columns==1)
    if not topology:
        # There is no side definition for a one-angle branch. Do not invent a
        # side, a second angle, or an unspecified extra column of holes.
        fig.text(.06,.78,'TOPOLOGIA NÃO REPRESENTADA',fontsize=18,color=RED,fontweight='bold')
        fig.text(.06,.68,f'Entrada preservada: {c.angle_count} cantoneira(s); simetria={c.symmetric}; apoio={c.kind}.\n'
                 f'Colunas na alma={c.web_columns}; colunas por aba de apoio={c.support_columns}.\n'
                 'A representação R016 exige duas cantoneiras simétricas, uma coluna por interface\n'
                 'e ligação à mesa de pilar. Esta entrada exige detalhamento próprio.',fontsize=13,color=INK,linespacing=1.8)
        fig.text(.06,.45,f'Abas viga/apoio={c.beam_leg:g}/{c.support_leg:g}; t={c.t:g}; L={c.length:g} mm.\n'
                 f'Gabaritos viga/apoio={c.beam_gauge:g}/{c.support_gauge:g} mm; V={c.V/1000:g} kN.',fontsize=12,color=INK,linespacing=1.8)
        fig.text(.035,.04,'Sem aprovação global. Não foi desenhado um par para representar uma cantoneira única.',fontsize=11,color=RED)
        return add_drawing_provenance(fig, c)
    elev=fig.add_axes((.035,.465,.455,.35))
    front=fig.add_axes((.555,.44,.395,.375))
    plan=fig.add_axes((.035,.085,.54,.285))
    for ax in (elev,front,plan):
        ax.set_aspect('equal');ax.axis('off')

    def rect(ax,x,y,w,h,color,gid=None,**kw):
        p=Rectangle((x,y),w,h,facecolor=color,edgecolor=INK,lw=.8,**kw)
        p.set_gid(gid);ax.add_patch(p);return p
    def line(ax,x,y,gid=None,**kw):
        p,=ax.plot(x,y,color=kw.pop('color',INK),lw=kw.pop('lw',.8),**kw)
        p.set_gid(gid);return p
    def hole(ax,x,y,gid):
        p=Circle((x,y),c.hole_diameter/2,facecolor='white',edgecolor=INK,lw=.8)
        p.set_gid(gid);ax.add_patch(p)
        s=c.hole_diameter*.2;line(ax,[x-s,x+s],[y,y],lw=.45);line(ax,[x,x],[y-s,y+s],lw=.45)
    def dim(ax,x1,y1,x2,y2,label,short_side=1):
        return dimension(ax,(x1,y1),(x2,y2),label,fontsize=8.5,
            rotation=90 if x1==x2 else 0,color=INK,pad=1,lw=.65,short_side=short_side)
    def leader(ax,label,xy,text,ha='left',connectionstyle='arc3'):
        return ax.annotate(label,xy=xy,xytext=text,ha=ha,va='center',fontsize=8.6,color=INK,
                    arrowprops={'arrowstyle':'-','lw':.6,'color':INK,'connectionstyle':connectionstyle},
                    bbox={'facecolor':'white','edgecolor':'none','pad':1})
    def title(ax,label):ax.set_title(label,loc='left',fontsize=11,fontweight='bold',color=INK,pad=14)

    # Top and bottom are measured downward from the beam top. The support
    # input edges are measured from first/last support holes, independently.
    ytop=c.beam.d/2-c.angle_top;yb=ytop-c.length
    yw=[ytop-c.web_end_top-i*c.web_pitch for i in range(c.web_rows)]
    ys=[ytop-c.support_end_top-i*c.support_pitch for i in range(c.support_rows)]
    support_top=ys[0]+c.support_edge_top
    support_bottom=ys[-1]-c.support_edge_bottom
    z0=c.beam.tw/2;zs=z0+c.support_gauge
    stub=max(c.beam_leg+110,c.beam.d*.57)
    local_top=max(c.beam.d/2,ytop)+35;local_bottom=min(-c.beam.d/2,yb)-35

    title(elev,'A  ELEVAÇÃO NA ALMA DA VIGA')
    # Local column crop is visibly interrupted; these are not free edges.
    rect(elev,-c.support.d,local_bottom,c.support.d,local_top-local_bottom,MEMBER,'support_elevation_crop',alpha=.42)
    rect(elev,-c.support.tf,local_bottom,c.support.tf,local_top-local_bottom,MEMBER,'support_front_flange_elevation')
    rect(elev,-c.support.d,local_bottom,c.support.tf,local_top-local_bottom,MEMBER,'support_rear_flange_elevation')
    for y in (local_bottom,local_top):
        line(elev,[-c.support.d,-c.support.d*.68,-c.support.d*.62,-c.support.d*.55,0],[y,y,y+6,y,y],lw=1.2)
    rect(elev,c.gap,-c.beam.d/2,stub-c.gap,c.beam.d,'#eef1f4','beam_web_elevation')
    for suffix,y in (('bottom',-c.beam.d/2),('top',c.beam.d/2-c.beam.tf)):
        rect(elev,c.gap,y,stub-c.gap,c.beam.tf,MEMBER,'beam_'+suffix+'_flange_elevation')
    rect(elev,0,yb,c.beam_leg,c.length,ANGLE1,'angle_A1_elevation',alpha=.87)
    rect(elev,0,yb,c.beam_leg,c.length,'none','angle_A2_elevation',linestyle='--')
    for i,y in enumerate(yw):hole(elev,c.beam_gauge,y,f'web_hole_elevation_{i}')
    for i,y in enumerate(ys):
        line(elev,[-c.support.tf-7,c.t+7],[y,y],f'support_bolt_elevation_{i}',lw=2)
    dim(elev,0,local_bottom-28,c.beam_leg,local_bottom-28,f'b viga = {c.beam_leg:g}',short_side=-1)
    dim(elev,stub+23,yb,stub+23,ytop,f'L = {c.length:g}')
    dim(elev,0,local_top+24,c.beam_gauge,local_top+24,f'g viga = {c.beam_gauge:g}')
    leader(elev,f'Folga = {c.gap:g}',(c.gap/2,-c.beam.d/2),(c.beam_leg+22,local_bottom-27))
    leader(elev,'A1 visível; A2 atrás da alma',(c.beam_leg*.68,ytop-15),(c.beam_leg+35,ytop+22))
    elev.text(-c.support.d,local_top+24,'Fuste interrompido',fontsize=8.5,color=MUTED)
    # Positive V is drawn down; reversing V reverses the actual arrow.
    arrow_x=stub-28;ym=(ytop+yb)/2;direction=-1 if c.V>=0 else 1
    if c.V!=0:
        a=elev.annotate('',(arrow_x,ym+direction*48),(arrow_x,ym-direction*28),arrowprops={'arrowstyle':'-|>','lw':1.8,'color':RED,'mutation_scale':14})
        a.set_gid('load_V_positive_down' if c.V>0 else 'load_V_negative_up')
    elev.text(arrow_x-12,ym,f'V = {c.V/1000:g}\nkN',fontsize=9,color=RED,va='center',ha='right')
    elev.set_xlim(-c.support.d-10,stub+75);elev.set_ylim(local_bottom-60,local_top+45)

    title(front,'B  FRENTE DO APOIO E BORDAS LIVRES REAIS')
    # Unlike the local elevation, this view includes the true upper and
    # lower support edges, and uses the actual flange width, not the beam's.
    rect(front,-c.support.bf/2,support_bottom,c.support.bf,support_top-support_bottom,MEMBER,'support_front_real_edges',alpha=.7)
    for z in (-c.support.tw/2,c.support.tw/2):line(front,[z,z],[support_bottom,support_top],ls='--',color=MUTED,lw=.65)
    for sign,code,color in ((-1,'A1',ANGLE1),(1,'A2',ANGLE2)):
        z=-z0-c.support_leg if sign<0 else z0
        rect(front,z,yb,c.support_leg,c.length,color,f'angle_{code}_support_front')
        for i,y in enumerate(ys):hole(front,sign*zs,y,f'support_hole_{code}_{i}')
    # Beam section as an outline only, to leave the support bolt heads visible.
    rect(front,-c.beam.tw/2,-c.beam.d/2+c.beam.tf,c.beam.tw,c.beam.d-2*c.beam.tf,'none','beam_web_front')
    for suffix,y in (('top',c.beam.d/2-c.beam.tf),('bottom',-c.beam.d/2)):
        rect(front,-c.beam.bf/2,y,c.beam.bf,c.beam.tf,'none','beam_'+suffix+'_front')
    dim(front,-c.support.bf/2,support_bottom-40,c.support.bf/2,support_bottom-40,f'bf apoio = {c.support.bf:g}',short_side=-1)
    dim(front,c.support.bf/2+36,ys[0],c.support.bf/2+36,support_top,f'e apoio sup = {c.support_edge_top:g}',short_side=-1)
    dim(front,c.support.bf/2+36,support_bottom,c.support.bf/2+36,ys[-1],f'e apoio inf = {c.support_edge_bottom:g}',short_side=-1)
    dim(front,-zs,support_top+40,zs,support_top+40,f'linhas de apoio = {2*zs:g}')
    leader(front,'Borda lateral real',(-c.support.bf/2,ys[0]),(-c.support.bf/2-30,ys[0]+100),ha='right')
    front.set_xlim(-c.support.bf/2-220,c.support.bf/2+120)
    front.set_ylim(support_bottom-75,support_top+75)

    title(plan,'C  PLANTA NO NÍVEL DOS PARAFUSOS')
    rect(plan,-c.support.d,-c.support.bf/2,c.support.tf,c.support.bf,MEMBER,'support_rear_flange_plan')
    rect(plan,-c.support.tf,-c.support.bf/2,c.support.tf,c.support.bf,MEMBER,'support_front_flange_plan')
    rect(plan,-c.support.d+c.support.tf,-c.support.tw/2,c.support.d-2*c.support.tf,c.support.tw,MEMBER,'support_web_plan')
    rect(plan,c.gap,-z0,stub-c.gap,c.beam.tw,MEMBER,'beam_web_plan')
    for z in (-c.beam.bf/2,c.beam.bf/2):line(plan,[c.gap,stub],[z,z],ls='--',color=MUTED)
    # Each L is a single independent closed path; the root radius belongs
    # to its own angle, never an invented equivalent plate with thickness 2t.
    for sign,code,color in ((-1,'A1',ANGLE1),(1,'A2',ANGLE2)):
        b,s,t,rr=c.beam_leg,c.support_leg,c.t,c.root_radius;k=.5522847498307936
        verts=[(0,z0),(b,z0),(b,z0+t),(t+rr,z0+t)]
        codes=[Path.MOVETO,Path.LINETO,Path.LINETO,Path.LINETO]
        if rr>0:
            verts.extend([(t+rr-k*rr,z0+t),(t,z0+t+rr-k*rr),(t,z0+t+rr)])
            codes.extend([Path.CURVE4]*3)
        else:
            verts.append((t,z0+t));codes.append(Path.LINETO)
        verts.extend([(t,z0+s),(0,z0+s),(0,z0)])
        codes.extend([Path.LINETO,Path.LINETO,Path.CLOSEPOLY])
        patch=PathPatch(Path([(x,sign*z) for x,z in verts],codes),facecolor=color,edgecolor=INK,lw=.95)
        patch.set_gid(f'angle_{code}_L_plan');plan.add_patch(patch)
        line(plan,[-c.support.tf-8,c.t+8],[sign*zs,sign*zs],f'support_bolt_{code}_plan',lw=2)
        rect(plan,-c.support.tf-8,sign*zs-c.db*.35,5,c.db*.7,INK,f'support_head_{code}_plan')
        leader(plan,code,(c.beam_leg*.73,sign*(z0+c.t/2)),(c.beam_leg+42,sign*55))
    line(plan,[c.beam_gauge,c.beam_gauge],[-z0-c.t-8,z0+c.t+8],'shared_web_bolt_plan',lw=2)
    for sign in (-1,1):
        rect(plan,c.beam_gauge-c.db*.35,sign*(z0+c.t+5)-2,c.db*.7,4,INK,f'web_bolt_head_{sign}_plan')
        line(plan,[c.beam_gauge-9,c.beam_gauge+9],[sign*z0,sign*z0],f'web_shear_plane_{sign}',color=RED,lw=2)
    dim(plan,0,-c.support.bf/2-32,c.beam_leg,-c.support.bf/2-32,f'b viga = {c.beam_leg:g}',short_side=-1)
    dim(plan,stub+25,z0,stub+25,z0+c.support_leg,f'b apoio = {c.support_leg:g}',short_side=-1)
    leader(plan,f'g apoio = {c.support_gauge:g}',(c.t,zs),(35,c.support.bf/2+28))
    leader(plan,'Parafuso comum: 2 planos',(c.beam_gauge,0),(c.beam_leg+40,-c.support.bf/2+5),
        connectionstyle='angle,angleA=180,angleB=-90,rad=0')
    plan.set_xlim(-c.support.d-12,stub+105);plan.set_ylim(-c.support.bf/2-62,c.support.bf/2+60)

    web_bottom=c.length-c.web_end_top-(c.web_rows-1)*c.web_pitch
    support_end_bottom=c.length-c.support_end_top-(c.support_rows-1)*c.support_pitch
    notes=[
        f'2 peças L {c.beam_leg:g} × {c.support_leg:g} × {c.t:g}; raio interno {c.root_radius:g}',
        f'Comprimento {c.length:g}; topo a {c.angle_top:g} abaixo do topo da viga',
        f'Alma: {c.web_rows} parafusos comuns; passo {c.web_pitch:g}; bordas {c.web_end_top:g} / {web_bottom:g}',
        f'Apoio: 2 × {c.support_rows} parafusos; passo {c.support_pitch:g}; bordas {c.support_end_top:g} / {support_end_bottom:g}',
        f'Ø parafuso {c.db:g}; Ø furo físico {c.hole_diameter:g} mm',
        f'Alma da viga tw = {c.beam.tw:g}; mesa do apoio tf = {c.support.tf:g} mm',
        'Bordas verticais do apoio: medidas a partir do primeiro/último furo.',
        'Cada aba de apoio: 1 plano por parafuso; cada cantoneira recebe V/2.',
        'Cotas em mm. A1 azul; A2 ocre. Vermelho: V e planos de corte.',
    ]
    fig.text(.615,.372,'DIMENSÕES E INTERFACES FÍSICAS',fontsize=10.5,fontweight='bold',color=INK)
    fig.text(.615,.349,'\n'.join(notes),fontsize=8.9,linespacing=1.65,va='top',color=INK)
    fig.text(.035,.045,'Restrição do método: par simétrico usual R016, V estático; N = M = T = 0. Excentricidades geométricas permanecem no modelo.',fontsize=9.4,color=INK)
    fig.text(.035,.022,'Esquema dimensionado; não libera fabricação. Despachar as cantoneiras com a viga. Fonte geométrica: R016, p. 19.',fontsize=9.4,color=INK)
    # A measured title clearance also covers the two saved wrapped headers.
    fig.canvas.draw()
    renderer=fig.canvas.get_renderer()
    title_top=max(ax._left_title.get_window_extent(renderer).y1 for ax in (elev,front))
    shift=max(0.,(title_top+8*fig.dpi/72-header_bottom)/fig.bbox.height)
    for ax in (elev,front):
        pos=ax.get_position();ax.set_position((pos.x0,pos.y0-shift,pos.width,pos.height))
    return add_drawing_provenance(fig, c)


def image_bytes(c,r=None,fmt='png'):
    with plt.rc_context({'font.family':'DejaVu Sans','font.size':10,'svg.fonttype':'none'}):
        fig=_figure(c,r)
        try:
            out=BytesIO();fig.savefig(out,format=fmt,dpi=170,facecolor='white',metadata={'Creator':'LRO R016 double angle'})
            return out.getvalue()
        finally:plt.close(fig)


def drawing_svg(c,r=None):
    return image_bytes(c,r,'svg').decode('utf-8')
