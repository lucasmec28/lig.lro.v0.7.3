"""Fresh evaluated DOCX and machine-readable check export, candidate-only."""
import io
import json
from dataclasses import asdict
from .welded_coverplate_splice import evaluate,NBR,MODEL

MODE_LABELS={
 'gross_tension':'Tração e escoamento bruto','effective_tension':'Tração e ruptura efetiva',
 'compression':'Compressão e estabilidade local da tala','compression_local_yield':'Compressão local do receptor',
 'shear_yield':'Cisalhamento e escoamento','shear_rupture':'Cisalhamento e ruptura',
 'weld_metal':'Metal da solda','cover_weld_adjacent_rupture':'Tala junto à solda e ruptura',
 'cover_weld_adjacent_yield':'Tala junto à solda e escoamento','receiver_weld_adjacent_rupture':'Receptor junto à solda e ruptura',
 'receiver_weld_adjacent_yield':'Receptor junto à solda e escoamento',
 'receiver_axial_U':'Bloco U do receptor de mesa','receiver_half_flange_L':'Bloco L da meia mesa receptora',
 'receiver_vertical_L':'Caminho vertical do receptor de alma',
 'local_elastic_NMV_envelope':'Envelope elástico local N M V','whole_member_partial_axial_rupture':'Ruptura axial com ligação parcial do perfil'}


STATUS_LABELS={'LOCAL_CHECKS_PASS':'Verificações locais atendidas','LOCAL_CHECKS_FAIL':'Falha nas verificações locais',
 'NOT_VERIFIED':'Confirmações técnicas pendentes','INVALID_INPUT':'Entrada inválida','INVALID_RESTRAINT_INPUT':'Dados de travamento inválidos',
 'OUTSIDE_QUALIFIED_SCOPE':'Fora do domínio qualificado','DETAIL_FAIL':'Detalhamento não atendido',
 'PASS':'Atendido','FAIL':'Não atendido','NOT_APPLICABLE':'Não aplicável'}

def number_pt(value, spec='.3f'):
    """Display only; native JSON and numerical calculations remain unchanged."""
    return format(value, spec).replace('.', ',')


def case_kind_label(value):
    return {'actual':'atual','minimum_45kN':'mínima de 45 kN'}.get(value,value)


def project_label(value):
    return 'Emenda com talas soldadas' if value == 'Emenda com talas soldadas · candidato isolado' else value


def component_label(value):
    substitutions=[('top_flange_cover','Tala de mesa superior'),('bottom_flange_cover','Tala de mesa inferior'),
        ('front_web_cover','Tala de alma frontal'),('back_web_cover','Tala de alma posterior'),
        ('top_receiver','Mesa receptora superior'),('bottom_receiver','Mesa receptora inferior'),
        ('receiver_web','Alma receptora'),('receiver','Receptor'),('_left',' lado esquerdo'),('_right',' lado direito')]
    for a,b in substitutions:value=value.replace(a,b)
    return value.replace('_',' ')


def report_docx(c):
    from docx import Document
    from docx.shared import Inches,Pt,RGBColor
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    result=evaluate(c)
    if not result['checks']:
        raise ValueError('Memorial indisponível: entradas/domínio/travamentos inválidos.')
    doc=Document();sec=doc.sections[0]
    sec.page_width=Inches(8.5);sec.page_height=Inches(11)
    sec.top_margin=sec.bottom_margin=Inches(.7);sec.left_margin=sec.right_margin=Inches(.7)
    for name in ('Normal','Title','Heading 1','Heading 2'):
        st=doc.styles[name];st.font.name='Calibri';st.font.color.rgb=RGBColor(0,0,0)
    doc.styles['Normal'].font.size=Pt(10)
    for style in doc.styles:
        for border in list(style.element.iter(qn('w:pBdr'))):
            border.getparent().remove(border)
    doc.add_heading('Emenda com talas soldadas',0)
    from .package_identity import PACKAGE_ID
    doc.add_paragraph(project_label(c.project))
    doc.add_paragraph('Aplicativo LRO Ligações '+PACKAGE_ID+'.')
    doc.add_paragraph('Verificação local da ligação no domínio indicado. Não substitui o projeto global dos membros nem a aprovação do projeto para fabricação.')
    doc.add_paragraph('Resultado local: '+STATUS_LABELS.get(result['status'],result['status'])+'. Índice máximo: '+f'{number_pt(result["summary"]["max_utilization"], ".4f")}'+'.')
    doc.add_heading('Domínio e método',1)
    doc.add_paragraph('Dois perfis W/I laminados iguais, coaxiais e íntegros. Duas talas externas iguais nas mesas e duas talas iguais simétricas na alma. Soldas contínuas em U em cada sobreposição, sem solda na folga. Acesso e procedimento de execução devem corresponder ao detalhe real.')
    doc.add_paragraph('Forças conforme AISC Steel Construction Manual 15, Parte 12, páginas 12-11 e 12-12, Figura 12-7(b). N/M transmitidos pelas mesas nos centroides reais das talas externas. Cortante V/2 em cada tala de alma, com dispensa de excentricidade expressa para esta idealização FR. N e M das talas de alma são nulos; Lb de alma não é exigido.')
    doc.add_paragraph('Resistências: '+NBR+'. Combinações normais; γa1=1,10; γa2=γw2=1,35. Sem aumento direcional da resistência de solda. N positivo em tração; M positivo traciona a tala superior.')
    doc.add_paragraph('A estabilidade global, FLT e dimensionamento dos membros/sistema são pré-requisitos externos declarados, não verificações numéricas aprovadas pelo módulo. Excluídos fadiga, sismo, incêndio, montagem, torção aplicada, flexão fraca, contato de topo, furos, recortes, calços e desalinhamento.')
    doc.add_heading('Geometria e materiais',1)
    for line in [f'Perfil {c.profile_name}: d={number_pt(c.d, "g")}; bf={number_pt(c.bf, "g")}; tf={number_pt(c.tf, "g")}; tw={number_pt(c.tw, "g")}; raio={number_pt(c.root_radius, "g")} mm.',
                 f'Talas de mesa: b={number_pt(c.flange_width, "g")}; t={number_pt(c.flange_t, "g")}; sobreposição={number_pt(c.flange_overlap, "g")}; perna={number_pt(c.flange_leg, "g")}; recuo={number_pt(c.flange_setback, "g")} mm.',
                 f'Talas de alma: h={number_pt(c.web_height, "g")}; t={number_pt(c.web_t, "g")}; sobreposição={number_pt(c.web_overlap, "g")}; perna={number_pt(c.web_leg, "g")}; recuo={number_pt(c.web_setback, "g")} mm.',
                 f'Folga={number_pt(c.gap, "g")} mm. Braço entre centroides dm={number_pt(result["geometry"]["dm_mm"], "g")} mm.',
                 f'Receptor fy/fu={number_pt(c.member_fy, "g")}/{number_pt(c.member_fu, "g")}; talas fy/fu={number_pt(c.cover_fy, "g")}/{number_pt(c.cover_fu, "g")}; eletrodo fw={number_pt(c.electrode_fw, "g")} MPa. WPS: {c.procedure_id}.']:
        doc.add_paragraph(line)
    doc.add_heading('Comprimentos efetivos definidos pelo projetista',1)
    doc.add_paragraph('Eixos: x longitudinal da viga; y vertical; z transversal às mesas. Le já inclui o efeito dos vínculos: não multiplicar por K novamente nem substituir pelo vão da viga ou folga da emenda. São dados de engenharia fornecidos pelo projetista, não análise de travamento executada pelo aplicativo.')
    for side,label in [('top','Tala superior'),('bottom','Tala inferior')]:
        rec=getattr(c,side+'_restraint');data=result['restraints'][side]
        doc.add_heading(label,2)
        if data.get('status')=='NOT_APPLICABLE_NO_COMPRESSION':
            doc.add_paragraph('Sem compressão nas combinações atuais; comprimentos de compressão não aplicáveis.')
        else:
            doc.add_paragraph(f'Le normal à tala = {number_pt(rec.Le_normal_mm, "g")} mm: deslocamento y e flexão em torno de z. Le no plano = {number_pt(rec.Le_in_plane_mm, "g")} mm: deslocamento z e flexão em torno de y.')
            doc.add_paragraph('Fonte/método: '+rec.reference+'. Vínculos e flexibilidade do receptor: '+rec.support_description)
            cap=data['capacity'];doc.add_paragraph(f'Ne normal={number_pt(cap["Ne_normal_N"], ".3f")} N; Ne no plano={number_pt(cap["Ne_in_plane_N"], ".3f")} N; limite torsional={number_pt(cap["Ne_torsion_lower_N"], ".3f")} N. χ={number_pt(cap["chi"], ".6f")}; Aef={number_pt(cap["Aeff_mm2"], ".3f")} mm²; NRd={number_pt(cap["capacity_N"], ".3f")} N.')
            doc.add_paragraph('Torção de Saint-Venant do retângulo com termo de empenamento omitido conservadoramente. Elemento AA na sobreposição entre soldas reais; sem apoio central fictício. Revisão vinculada: '+rec.detail_signature)
    doc.add_heading('Combinações e caminhos de força',1)
    for case in result['cases']:
        doc.add_paragraph(f'{case["id"]} ({case_kind_label(case["kind"])}): N={number_pt(case["N"], ".8g")} N; M={number_pt(case["M"], ".8g")} N mm; V={number_pt(case["V"], ".8g")} N. Valores assinados da combinação atual.')
    for p in result['force_paths']:
        doc.add_paragraph(f'{p["case_id"]}: F superior={number_pt(p["top_N"], ".3f")} N; F inferior={number_pt(p["bottom_N"], ".3f")} N; cada tala de alma V={number_pt(p["each_web_V"], ".3f")} N. Resíduos N={number_pt(p["axial_residual_N"], ".3g")} N; M={number_pt(p["moment_residual_Nmm"], ".3g")} N mm.')
    doc.add_heading('Verificações locais',1)
    doc.add_paragraph('Solicitação e resistência usam a mesma unidade indicada. Grupos esquerdo e direito são caminhos em série. Os dois lados da alma compartilham uma única espessura receptora tw. O envelope N/M/V local é adicional e não cria nova distribuição de forças.')
    table=doc.add_table(rows=1,cols=5);table.autofit=False
    widths=[3.5,1.0,1.0,.8,.8]
    for column,w in zip(table.columns,widths):column.width=Inches(w)
    headers=['Componente e modo','Solicitação','Resistência','Índice','Unidade']
    for cell,w,label in zip(table.rows[0].cells,widths,headers):cell.width=Inches(w);cell.text=label
    repeat=OxmlElement('w:tblHeader');table.rows[0]._tr.get_or_add_trPr().append(repeat)
    for q in result['checks']:
        cells=table.add_row().cells
        values=[component_label(q['component'])+'\n'+MODE_LABELS.get(q['mode'],q['mode'])+'\n'+q['case_id'],f'{number_pt(q["demand"], ".3f")}',f'{number_pt(q["capacity"], ".3f")}',f'{number_pt(q["utilization"], ".4f")}',q['unit']]
        for cell,value,w in zip(cells,values,widths):cell.text=value;cell.width=Inches(w)
    for ri,row in enumerate(table.rows):
        no_split=OxmlElement('w:cantSplit');row._tr.get_or_add_trPr().append(no_split)
        for cell in row.cells:
            pr=cell._tc.get_or_add_tcPr();borders=OxmlElement('w:tcBorders')
            for side in ('top','left','bottom','right'):
                border=OxmlElement('w:'+side);border.set(qn('w:val'),'single');border.set(qn('w:sz'),'4');border.set(qn('w:color'),'D9D9D9');borders.append(border)
            pr.append(borders)
            shade=OxmlElement('w:shd');shade.set(qn('w:fill'),'E7EDF2' if ri==0 else 'FFFFFF' if ri%2 else 'F6F8FA');pr.append(shade)
            for p in cell.paragraphs:
                p.paragraph_format.space_after=Pt(3);p.paragraph_format.space_before=Pt(3)
                for run in p.runs:run.font.size=Pt(9)
    if result.get('applicability',{}).get('web_block'):
        doc.add_heading('Aplicabilidade de ruptura em bloco na alma',1)
        doc.add_paragraph(result['applicability']['web_block']['reason'])
        doc.add_paragraph('Verificações aplicadas em seu lugar: '+ '; '.join(result['applicability']['web_block']['checked_instead'])+'.')
    doc.add_heading('Rastreabilidade dos modos',1)
    doc.add_paragraph('Tração, ruptura efetiva, compressão, cisalhamento e bloco: NBR6.5.3 a 6.5.6, 5.2.5 e 5.3. Solda: NBR6.2.5/Tabela9 e limites de 6.2.6. Cortes físicos e parâmetros detalhados constam no JSON de resultados, com coordenadas e espessura alocada. Chapas sem furos soldadas nas bordas livres não reutilizam caminhos de bloco do receptor: são verificadas a seção transversal completa e cada linha de transferência adjacente à solda.')
    if result['issues']:
        doc.add_heading('Condições ainda não confirmadas',1)
        for issue in result['issues']:doc.add_paragraph(issue)
    data=io.BytesIO();doc.save(data);return data.getvalue()


def result_json(c):
    return json.dumps(dict(input=c.to_dict(),result=evaluate(c)),ensure_ascii=False,indent=2,allow_nan=False).encode()
