"""Lossless R017 presentation of existing checks, without new mechanics.

Each physical component/mechanism retains every primitive row, exact ties,
failures and its own demand/capacity. An envelope never adds resistances.
"""
from .display_precision import display_value
from collections import OrderedDict
from copy import deepcopy
import re

COMPONENT_LABELS = {
    'bolt_shared_web': 'Parafusos comuns da viga · corte duplo',
    'bolt_support_negative': 'Parafusos A1 no apoio · corte simples',
    'bolt_support_positive': 'Parafusos A2 no apoio · corte simples',
    'angle_negative_beam': 'A1 · aba parafusada junto à viga',
    'angle_positive_beam': 'A2 · aba parafusada junto à viga',
    'angle_negative_support': 'A1 · aba parafusada junto ao apoio',
    'angle_positive_support': 'A2 · aba parafusada junto ao apoio',
    'beam_web': 'Alma recortada única',
    'beam_cope': 'Recorte duplo',
    'beam_uncut': 'Viga íntegra após recorte',
    'support_web': 'Alma única de apoio · duas colunas físicas',
    'support_web_negative': 'Alma única de apoio · coluna A1',
    'support_web_positive': 'Alma única de apoio · coluna A2',
}
MECHANISM_LABELS = {
    'bolt_shear': 'Corte dos parafusos',
    'section_shear': 'Cisalhamento bruto e líquido',
    'uncut_shear': 'Cisalhamento da seção íntegra',
    'first_yield': 'Primeiro escoamento por flexão',
    'complementary_stability': 'Instabilidade complementar condicional',
    'bearing': 'Contato e rasgamento por furo e soma normativa',
    'block': 'Cisalhamento em blocos L',
}


def component_label(component):
    base = re.sub(r'_V(?:pos|neg)$', '', component)
    suffix = ' · V > 0' if component.endswith('_Vpos') else ' · V < 0' if component.endswith('_Vneg') else ''
    return COMPONENT_LABELS.get(base, base) + suffix


def direction_label(direction):
    return {'down': 'força para baixo', 'up': 'força para cima',
            'direction_independent': 'independente do sentido', None: 'independente do sentido'}.get(direction, str(direction))


def state_label(state):
    return {'PASS': 'Atende', 'FAIL': 'Falha', 'PENDING': 'Pendente',
            'NOT_EVALUATED': 'Não avaliado', 'NUMERICAL_FAILURE': 'Falha numérica'}.get(state, str(state))


def check_label(check):
    """Physical Portuguese label; the raw ID remains available separately."""
    if check['id'].startswith('bolt_'):
        return component_label(check['component'])
    return str(check.get('label', check['id']))


def _group(check):
    identifier = check['id']
    if identifier.startswith('bolt_'):
        return identifier, identifier, 'bolt_shear'
    if identifier == 'cope_first_yield':
        return identifier, 'beam_cope', 'first_yield'
    if identifier == 'cope_complementary_stability':
        return identifier, 'beam_cope', 'complementary_stability'
    if identifier == 'beam_uncut_web_shear':
        return identifier, 'beam_uncut', 'uncut_shear'
    if identifier.startswith('beam_web_shear_'):
        return 'beam_web_shear', 'beam_web', 'section_shear'
    if identifier.startswith('support_web_'):
        return 'support_web_bearing_all_physical_columns', 'support_web', 'bearing'
    core = re.sub(r'_V(?:pos|neg)', '', identifier)
    for suffix, mechanism in (('_bearing_', 'bearing'), ('_block_', 'block'), ('_shear_', 'section_shear')):
        if suffix in core:
            component = core.split(suffix)[0]
            return component + suffix[:-1], component, mechanism
    raise ValueError('Verificação R017 sem grupo de apresentação: ' + identifier)


def _witness(check, result, actual):
    record = deepcopy(check)
    load = result.get('load_model') or {}
    # The combined support-web sum carries its branch in the ID, not component.
    branch = re.search(r'_V(pos|neg)(?:_|$)', check['id'])
    sign = (1 if branch.group(1) == 'pos' else -1) if branch else None
    directions = [sign] if sign is not None else list(load.get('directions_evaluated') or [])
    total = load.get('Vsd_N' if actual else 'Vd_N')
    signed = ([total] if actual else [abs(total) * direction for direction in directions]) if total is not None else []
    record['case'] = {
        'kind': 'actual' if actual else 'adopted',
        'total_action_N': signed[0] if len(signed) == 1 else None,
        'stored_total_action_reference_N': total,
        'total_action_magnitude_N': abs(total) if total is not None else None,
        'signed_total_action_cases_N': signed,
        'directions_evaluated': directions,
        'branch_direction_sign': sign,
        'loaded_direction': check.get('loaded_direction', 'direction_independent'),
    }
    return record


def governing_description(record):
    case = record['case']
    if case['kind'] == 'actual' and case['total_action_N'] == 0:
        case_label = 'V real = 0; sem força real'
    else:
        case_label = ' / '.join('V > 0' if value > 0 else 'V < 0' for value in case['directions_evaluated'])
    branch = case['branch_direction_sign']
    if branch is not None and case['kind'] == 'actual' and case['total_action_N'] == 0:
        case_label += '; caminho para V > 0' if branch > 0 else '; caminho para V < 0'
    return f"{display_value(case_label)}; {display_value(direction_label(case['loaded_direction']))}; {display_value(component_label(record['component']))}; {display_value(check_label(record))}"


def _restraint_condition(result):
    restraints = result.get('restraints') or {}
    faces = restraints.get('required_compression_faces') or []
    names = [{'top': 'superior', 'bottom': 'inferior'}.get(face, face) for face in faces]
    where = ' e '.join(names) or 'requerida pelo sentido da ação'
    qualified = restraints.get('all_required_qualified') is True
    state = 'referência externa documentada' if qualified else 'comprovação externa pendente'
    return (f'Contenção lateral da mesa comprimida {display_value(where)} na face do recorte: {display_value(state)}. Resistência e rigidez do travamento não dimensionadas neste módulo.')


def physical_envelopes(result):
    """Return only present groups, with independent actual/adopted maxima.

    Normal inputs have 22 groups. Domain-excluded mechanisms remain absent;
    no placeholder group or missing row is promoted to an evaluated pass.
    """
    groups = OrderedDict()
    for row in result.get('checks') or []:
        groups.setdefault(_group(row), []).append(row)
    envelopes = []
    for (identifier, component, mechanism), members in groups.items():
        actual_max = max(row['actual_utilization'] for row in members)
        adopted_max = max(row['utilization'] for row in members)
        actual_ties = [_witness(row, result, True) for row in members if row['actual_utilization'] == actual_max]
        adopted_ties = [_witness(row, result, False) for row in members if row['utilization'] == adopted_max]
        actual_failures = [row['id'] for row in members if row['actual_status'] == 'FAIL']
        adopted_failures = [row['id'] for row in members if row['status'] == 'FAIL']
        conditional = identifier == 'cope_complementary_stability'
        envelopes.append({
            'id': identifier, 'component': component, 'component_label': component_label(component),
            'mechanism': mechanism, 'mechanism_label': MECHANISM_LABELS[mechanism], 'units': 'N',
            'actual_governing_id': actual_ties[0]['id'], 'adopted_governing_id': adopted_ties[0]['id'],
            'actual_utilization': actual_max, 'adopted_utilization': adopted_max,
            'actual_governing': actual_ties[0], 'adopted_governing': adopted_ties[0],
            'actual_governing_ties': actual_ties, 'adopted_governing_ties': adopted_ties,
            'actual_status': 'FAIL' if actual_failures else 'PASS',
            'status': 'FAIL' if adopted_failures else 'PASS',
            'actual_failure_ids': actual_failures, 'adopted_failure_ids': adopted_failures,
            'actual_failure_count': len(actual_failures), 'adopted_failure_count': len(adopted_failures),
            'member_ids': [row['id'] for row in members], 'members': deepcopy(members),
            'conditional_on_external_restraints': conditional,
            'external_restraints_qualified': (result.get('restraints') or {}).get('all_required_qualified') is True,
            'restraint_condition': _restraint_condition(result) if conditional else 'Condições externas da ligação registradas separadamente; atendimento da linha não aprova os membros.',
        })
    return envelopes
