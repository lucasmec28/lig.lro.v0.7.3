"""Symmetric welded 2L opostas–single rectangular gusset–exterior W flange.

Explicit physical assembly: N/2 on each identical angle and its two fillets;
full N on the single common gusset, root and W. Constructs four distinct projected source lines and clipped shared-plate paths.
Reuses scalar materials/root primitives and the arbitrary-line section solver;
never imports a prior connection result or approval. N, mm, MPa, N mm.
"""
from __future__ import annotations
from copy import deepcopy
from dataclasses import asdict, dataclass, fields, replace
import math
from . import welded_angle_gusset as shared
from .angle_catalog import get_angle, catalog, LEGACY_ARCELOR_ID
from .models import finite_real

MATERIALS, ELECTRODES, SUPPORT_CATALOG = shared.MATERIALS, shared.ELECTRODES, shared.SUPPORT_CATALOG
SUPPORT, ANGLE = shared.SUPPORT, shared.ANGLE
GAMMA_A1, GAMMA_A2, GAMMA_W2 = shared.GAMMA_A1, shared.GAMMA_A2, shared.GAMMA_W2
UNITS = dict(shared.UNITS)
FAMILY = 'Ligação 2L opostas–gusset–mesa W · soldada'
CONNECTION_TYPE = 'welded_opposed_angle_gusset'
COMPONENT_VERSION = '0.9.30-gusset-variants-dev'
SCOPE = ('Duas L idênticas opostas pelos vértices (><), uma por face da chapa central; h=tg. '
         'Quatro linhas projetadas distintas; N/2 por L, N integral na chapa única, raiz dupla e W. '
         'Método plano estático NBR6.1.8.2/6.5.2: binários locais superfície–plano médio idealizados, '
         'não cancelados nem verificados como campo tridimensional. Tração estática e seções inteiramente tracionadas.')
EXCLUSIONS = [
    ('Sem chapas poligonais, furos, enrijecedores, raiz descontínua/descentrada, retornos ou comprimentos de solda desiguais.'
     if entry.startswith('Sem contornos arbitrários,') else entry)
    for entry in shared.EXCLUSIONS
] + [
    'Somente L, materiais, ligações e carregamentos idênticos e compatíveis nas duas faces.',
    'Sem parafusos, interface mista, enchimentos, afastadores ou partilha desigual.',
    'Estabilidade global da diagonal composta e ações concorrentes reais do W fora do escopo.',
]
FACE_IDS = ('face_positive', 'face_negative')
FACE_LABELS = {'face_positive': 'L face +z', 'face_negative': 'L face −z'}
_safe, _issue, _finalize, _exact = shared._safe, shared._issue, shared._finalize, shared._exact
root_actions = shared.root_actions
minimum_fillet = shared.minimum_fillet
block_resistance = shared.block_resistance


@dataclass(frozen=True)
class WeldedOpposedAngleGusset(shared.WeldedAngleGusset):
    project: str = '2L opostas100×100×12 → gusset540×380×12 → mesa W · N total120kN'
    plate_width: float = 540.
    plate_height: float = 380.
    plate_t: float = 12.
    center_n: float = 195.
    weld_length: float = 240.
    root_weld_leg: float = 6.
    introduction_width: float = 260.
    support_end_left: float = 1200.
    support_end_right: float = 1200.
    N: float = 120000.
    topology: str = 'opposed_vertices'
    interface: str = 'welded'
    symmetric_load: bool = True
    accessible_both_faces: bool = True

    @property
    def fixed_assumptions(self):
        result = dict(super().fixed_assumptions)
        result.update(topology='opposed_vertices_two_identical_angles_one_per_face_four_distinct_projected_lines',
            heel_gap='derived_plate_t', load_transfer='N_total_half_each_angle_four_distinct_projected_sources',
            out_of_plane='per_angle_NBR6.1.8.2_static_end_exception_local_face_couples_idealized_not_canceled',
            equal_steel_and_geometry_both_faces=True, identical_far_end_loading=True,
            angle_count=2, angle_weld_count=4, gusset_count=1, root_weld_count=2,
            angle_section_area_basis='one_angle', force_input_basis='total_pair',
            minimum_45kN_basis='whole_connection_once', recommended_half_basis='half_pair_capacity',
            local_face_screen='each_N/2_allocated_t/2_with_actual_inplane_centroid_and_full_t_Ct')
        return result

    def to_dict(self):
        errors = input_errors(self)
        if errors: raise ValueError('; '.join(errors))
        return dict(schema_version=1, connection_type=CONNECTION_TYPE,
            component_version=COMPONENT_VERSION, connection={k:v for k,v in asdict(self).items() if k not in shared.outer.WELDED_FIELDS},
            units=dict(UNITS), fixed_assumptions=self.fixed_assumptions)

    @classmethod
    def from_dict(cls, data):
        keys = {'schema_version', 'connection_type', 'component_version', 'connection', 'units', 'fixed_assumptions'}
        if not isinstance(data, dict) or set(data) != keys:
            raise ValueError('Ligação soldada 2L opostas: campos nativos ausentes ou desconhecidos.')
        if (type(data['schema_version']) is not int or data['schema_version'] != 1
                or data['connection_type'] != CONNECTION_TYPE or data['component_version'] != COMPONENT_VERSION):
            raise ValueError('Família ou versão soldada 2L opostas incompatível; não se converte 1L silenciosamente.')
        raw = data['connection']
        if not isinstance(raw, dict) or set(raw) != {f.name for f in fields(cls)}-set(shared.outer.WELDED_FIELDS):
            raise ValueError('Campos da ligação 2L opostas incompletos ou desconhecidos.')
        candidate = cls(**raw)
        canonical = candidate.to_dict()
        if not _exact(data['units'], canonical['units']) or not _exact(data['fixed_assumptions'], canonical['fixed_assumptions']):
            raise ValueError('Unidades ou premissas 2L opostas incompatíveis; nenhuma conversão silenciosa.')
        return candidate


def input_errors(c):
    if not isinstance(c, WeldedOpposedAngleGusset): return ['Entrada deve ser WeldedOpposedAngleGusset.']
    return shared.input_errors(c)


def presets():
    c = WeldedOpposedAngleGusset()
    return {
        '2L opostas soldadas · N total120kN': c,
        '2L opostas soldadas · N total330kN · falha chapa comum': replace(c, N=330000., project='2L opostas · N330kN · falha chapa comum'),
        '2L opostas soldadas · θ105° espelho': replace(c, theta_deg=105., project='2L opostas · espelho θ105°'),
        '2L opostas soldadas · θ90°': replace(c, theta_deg=90.),
        '2L opostas soldadas · pilar W': replace(c, support_member='column'),
        '2L opostas soldadas · N real zero': replace(c, N=0.),
        '2L opostas Gerdau · L63,5×6,35 · borda reforçada': replace(c, angle_profile='GERDAU_EQUAL_ANGLE_P03_R25', angle_steel='ASTM A36', angle_weld_edge_detail='reinforced'),
    }

_forward_exit, _transverse_chord = shared._forward_exit, shared._transverse_chord
_path, _row, _envelope = shared._path, shared._row, shared._envelope

def _geometry(c, out):
    A = get_angle(c.angle_profile)
    if A is None:
        return None
    b, ta, ec = A['leg'], A['t'], A['centroid']
    if A['Ag'] is None or ec is None:
        _issue(out, 'angle_missing_section_properties', 'outside_scope',
               'Catálogo Gerdau não publica Ag/ec desta linha; propriedades não são inventadas nem herdadas de outra seção.')
        return None
    vh, vt, vc = -c.plate_t/2-b, c.plate_t/2+b, 0.
    fh, ft = 1-ec/b, ec/b
    A['resistance_model'] = ('catalog_radiused_legacy' if c.angle_profile == LEGACY_ARCELOR_ID
                             else 'nominal_equal_angle_NBR')
    A['projected_centroid_v'] = vc
    A['heel_force_fraction'], A['toe_force_fraction'] = fh, ft
    dimensions = ('plate_width', 'plate_height', 'plate_t', 'weld_length', 'angle_weld_leg',
                  'root_weld_leg', 'introduction_width', 'support_end_left', 'support_end_right')
    if any(getattr(c, key) <= 0 for key in dimensions) or c.end_margin < 0:
        _issue(out, 'positive_geometry', 'invalid_geometry', 'Dimensões positivas e margem de extremidade não negativa são obrigatórias.')
        return None
    if not 0 < c.theta_deg < 180:
        _issue(out, 'direction_topology', 'outside_scope', 'Topologia inicial exige 0 < θ < 180°; a direção de tração deve afastar-se da raiz.')
        return None
    B,H,L = c.plate_width,c.plate_height,c.weld_length
    W = SUPPORT_CATALOG.get(c.support_profile,SUPPORT)
    C,S = math.cos(math.radians(c.theta_deg)), math.sin(math.radians(c.theta_deg))
    def point(u,v): return [c.center_s+u*C+v*S,c.center_n+u*S-v*C]
    def inside(p, tol=1e-8): return -B/2-tol <= p[0] <= B/2+tol and -tol <= p[1] <= H+tol
    lines = []
    for sign, face in ((-1.,'face_negative'),(1.,'face_positive')):
        for name,v,f in [('heel',sign*c.plate_t/2,fh/2),('toe',sign*(c.plate_t/2+b),ft/2)]:
            outward=-sign if name=='heel' else sign
            vlo,vhi=sorted((v,v+outward*c.angle_weld_leg))
            lines.append(dict(id=name+'_'+face,location=name,face=face,z=sign*c.plate_t/2,
                v=v,force_fraction=f,force_fraction_of_angle=2*f,start=point(-L/2,v),
                end=point(L/2,v),centroid=point(0,v),length=L,footprint_v=[vlo,vhi],
                planar_projection_z=0.,load_basis='total_pair'))
    lines.sort(key=lambda p:p['v'])
    footprint_vs=sorted(set(v for line in lines for v in line['footprint_v']))
    corners=[point(u,v) for u in (-L/2,L/2) for v in footprint_vs]
    angle_end=[point(-L/2-c.end_margin,v) for v in (-c.plate_t/2-b,-c.plate_t/2,c.plate_t/2,c.plate_t/2+b)]
    top = {str(v): point((H-c.center_n+v*C)/S,v) for v in footprint_vs}
    exits = {str(v): _forward_exit(c,v) for v in footprint_vs}
    station_events = sorted(set([-L/2,L/2]+[
        (x-c.center_s)*C+(y-c.center_n)*S for x in (-B/2,B/2) for y in (0.,H)
        if -L/2 < (x-c.center_s)*C+(y-c.center_n)*S < L/2]))
    stations = [dict(u=u,chord=_transverse_chord(c,u)) for u in station_events]
    intro = [point(-L/2,v) for v in (-c.introduction_width/2,c.introduction_width/2)]
    left_corner_u = (-B/2-c.center_s)*C-c.center_n*S
    left_u = max(-L/2,left_corner_u)
    left_v = (-B/2-c.center_s-left_u*C)/S
    left_point = point(left_u,left_v)
    right_corner_u = (B/2-c.center_s)*C-c.center_n*S
    right_u = max(-L/2,right_corner_u)
    right_v = (B/2-c.center_s-right_u*C)/S
    right_point = point(right_u,right_v)
    fabrication_notes = []
    if c.angle_weld_edge_detail == 'reinforced':
        fabrication_notes.append('BORDA REFORÇADA DA CANTONEIRA: executar reforço na borda para obter garganta efetiva mínima a=s/√2='
            +format(c.angle_weld_leg/math.sqrt(2),'.6g')+' mm; filete inscrito s='+format(c.angle_weld_leg,'g')
            +' mm, conforme NBR 8800:2024, 6.2.6.2.2(b). Assegurar garganta por procedimento, execução e inspeção; não reduzir para a borda sem reforço.')
    g = dict(valid=False, polygon=[[-B/2,0],[B/2,0],[B/2,H],[-B/2,H]],
             direction=[C,S], weld_lines=lines, footprint_corners=corners,
             angle_free_end=angle_end, force_point=point(0,vc), root_centroid=[0.,0.],
             root_endpoints=[[-B/2,0],[B/2,0]], root_length=B,
             angle_section=dict(A), support_catalog=dict(W), fabrication_notes=fabrication_notes,
             introduction_endpoints=intro, footprint_vs=footprint_vs,
             top_intersections=top, forward_exits=exits, transverse_stations=stations,
             force_line_root_s=point(0,vc)[0]-point(0,vc)[1]*C/S,
             left_u=left_u,left_v=left_v, left_point=left_point,
             right_u=right_u,right_v=right_v,right_point=right_point,
             angle_free_end_u=-L/2-c.end_margin, weld_start_u=-L/2,weld_end_u=L/2,
             min_end_clearance=min(p[1] for p in angle_end)-c.root_weld_leg,
             support_end_clearances=[c.support_end_left-B/2,c.support_end_right-B/2],
             plate_width=B,plate_height=H,plate_t=c.plate_t,theta_deg=c.theta_deg,
             center=[c.center_s,c.center_n], angle_weld_leg=c.angle_weld_leg,root_weld_leg=c.root_weld_leg)
    if not all(inside(p) for p in corners+angle_end+intro):
        _issue(out, 'physical_containment', 'invalid_geometry', 'Solda, extremidade livre da cantoneira ou faixa local ultrapassa o contorno real da chapa.')
    if min(p[1] for p in corners+angle_end) <= c.root_weld_leg:
        _issue(out, 'root_interference', 'invalid_geometry', 'Cantoneira/filete longitudinal interfere no filete de raiz; exige afastamento físico positivo.')
    if any(e['u'] < L/2-1e-8 or not inside(e['point']) for e in exits.values()):
        _issue(out,'forward_path_exit','invalid_geometry','Caminho longitudinal alcança a borda antes do término físico da solda.')
    if min(g['support_end_clearances']) < 0:
        _issue(out, 'root_beyond_support', 'invalid_geometry', 'Raiz ultrapassa uma extremidade do membro W.')
    if c.introduction_width < c.plate_t+2*b+2*c.angle_weld_leg or c.introduction_width > c.plate_t+2*b+2*c.angle_weld_leg+2*L*math.tan(math.pi/6):
        _issue(out, 'spread_domain', 'outside_scope', 'Faixa local deve conter as quatro pegadas completas das soldas e espalhamento por lado entre0° e30° sobre o comprimento real.')
    if c.plate_t >= 2*L:
        _issue(out,'local_strip_Ct','outside_scope','Faixa local: a adaptação de Ct requer t<2L; Ct não positivo não é uma resistência qualificada.')
    # The exact legacy branch retains its published physical toe-flat gate.
    # Gerdau is a nominal NBR branch: s is an inscribed fillet leg, not a claim
    # that the full weld sits on an unpublished pre-weld flat toe face.
    for key,leg,thin in [('angle',c.angle_weld_leg,min(ta,c.plate_t)),('root',c.root_weld_leg,min(c.plate_t,W['tf']))]:
        if leg < minimum_fillet(thin):
            _issue(out, key+'_minimum_weld', 'detail_fail', f'Filete {key}: mínimo {minimum_fillet(thin):g}mm pela peça menos espessa ({thin:g}mm).')
        if key == 'angle' and A['toe_flat'] is not None and leg > A['toe_flat']:
            _issue(out, 'toe_flat_fit', 'invalid_geometry', f'Filete da ponta excede face plana declarada {A["toe_flat"]:g} mm de {A["name"]}.')
        edge_t = ta if key == 'angle' else c.plate_t
        maxleg = edge_t if edge_t < 6.3 else edge_t-1.5
        if key == 'angle' and c.angle_weld_edge_detail == 'reinforced' and A['manufacturer']=='Gerdau':
            maxleg = ta
        if leg > maxleg:
            _issue(out, key+'_maximum_weld', 'detail_fail', f'Filete ultrapassa máximo de {maxleg:g} mm no detalhe de borda selecionado.')
        length = L if key == 'angle' else B
        if length < max(4*leg,40.):
            _issue(out, key+'_effective_length', 'detail_fail', 'Comprimento efetivo deve alcançar4s e40mm neste detalhe.')
    if L > 100*c.angle_weld_leg or B > 100*c.root_weld_leg:
        _issue(out,'long_weld_reduction','outside_scope','L/s>100: a redução de comprimento de6.2.2.2(d) e sua distribuição não estão implementadas nesta rota; não há crédito de comprimento integral.')
    if c.plate_t+2*c.root_weld_leg > W['bf']:
        _issue(out,'flange_footprint_fit','invalid_geometry','Pegada da raiz tg+2s ultrapassa largura real da mesa W.')
    if L+c.end_margin < max(5*min(ta,c.plate_t),25.):
        _issue(out, 'lap_overlap', 'detail_fail', 'Sobreposição menor que max(5t da parte menos espessa,25mm).')
    if c.end_margin < c.angle_weld_leg:
        _issue(out, 'end_termination', 'detail_fail', 'Extremidade longitudinal deve conservar ao menos um lado do filete até a borda livre.')
    terminations=[]
    for v in footprint_vs:
        p=point(L/2,v)
        for edge in exits[str(v)]['edges']:
            gap={'top':H-p[1],'right':B/2-p[0],'left':p[0]+B/2}[edge]
            terminations.append(dict(v=v,point=p,edge=edge,normal_gap=gap,required=c.angle_weld_leg))
    g['forward_termination_clearances']=terminations
    for edge in ('top','left','right'):
        witnesses=[x for x in terminations if x['edge']==edge and x['normal_gap'] < c.angle_weld_leg]
        if witnesses:
            _issue(out, edge+'_termination', 'detail_fail',
                   'Extremidade física da solda requer afastamento normal de uma perna à borda livre real ('+edge+').',witnesses=witnesses)
    g.update(topology=c.topology,heel_gap=c.plate_t,angle_count=2,angle_weld_count=4,root_weld_count=2,gusset_count=1,pair_gross_area=2*A['Ag'],gusset_root_area=B*c.plate_t,projected_weld_lines=[dict(x) for x in lines],angles=[dict(face=face,load_fraction=.5,connected_surface_z=sign*c.plate_t/2,projected_centroid_v=sign*(c.plate_t/2+ec),toe_direction='opposite',section=dict(A)) for sign,face in ((-1.,'face_negative'),(1.,'face_positive'))])
    g['valid'] = not any(i['severity'] in ('invalid_geometry','outside_scope') for i in out['issues'])
    return g



def _clip(poly, fn):
    result=[]
    for a,b in zip(poly,poly[1:]+poly[:1]):
        fa,fb=fn(a),fn(b);ina,inb=fa>=-1e-9,fb>=-1e-9
        if ina:result.append(a)
        if ina!=inb:
            r=fa/(fa-fb);result.append([a[0]+r*(b[0]-a[0]),a[1]+r*(b[1]-a[1])])
    return result


def rupture_paths(c,g,N,angle,gusset):
    """Actual four-source detached rectangles clipped by the one physical plate.

    The selected footprints only propose a region; demand is recomputed from
    every actual source captured by it, including overlap/touch transitions.
    No resistance of alternative paths or repeated material is added.
    """
    C,S=g['direction'];L,t=c.weld_length,c.plate_t
    A=g['angle_section'];b,ta,ec=A['leg'],A['t'],A['centroid']
    def xy(u,v):return [c.center_s+u*C+v*S,c.center_n+u*S-v*C]
    def uv(p):return [(p[0]-c.center_s)*C+(p[1]-c.center_n)*S,(p[0]-c.center_s)*S-(p[1]-c.center_n)*C]
    def region(u,lo=None,hi=None):
        poly=_clip(g['polygon'],lambda p:uv(p)[0]-u)
        if lo is not None:poly=_clip(poly,lambda p:uv(p)[1]-lo)
        if hi is not None:poly=_clip(poly,lambda p:hi-uv(p)[1])
        return poly
    def root_contact(poly):
        xs=[p[0] for p in poly if abs(p[1])<1e-7]
        return max(xs)-min(xs) if xs else 0.
    paths=[];length=L+c.end_margin;fh,ft=1-ec/b,ec/b
    if A['resistance_model']=='catalog_radiused_legacy':
        r1,r2,flat=A['root_radius'],A['toe_radius'],A['toe_flat']
        ah=(ta+r1)*ta+(b-ta)*ta+(1-math.pi/4)*(r1*r1-r2*r2)
        at=r2*ta-(1-math.pi/4)*r2*r2
        bases=[('A-H','L talão',length*ta,ah,fh,False),('A-T','L ponta arredondada',length*ta,at,ft,False),
               ('A-B','L ambas',length*ta,ah,1.,False),('A-T-limit','Limite ponta publicada',length*flat,0.,ft,True),
               ('A-all','Envelope ordinário conservador',L*flat,0.,1.,True)]
    else:
        bases=[('A-nominal','Envelope nominal NBR de aba tL',ta*L,0.,1.,True)]
    for face in FACE_IDS:
        for id,label,av,at,f,conservative in bases:
            paths.append(_path(id+'_'+face,label+' · '+FACE_LABELS[face], 'angle',av,at,N*f/2,angle,
                conservative=conservative,face=face,load_basis='per_angle',
                note='Demanda desta L: N/2. Envelope conservador não é fissura exata.'))
    lines=g['weld_lines'];inactive=[];seen=set()
    def add(id,u,lo,hi,kind,coords,av,at,free_edges):
        signature=(u,lo,hi,kind)
        if signature in seen:return
        seen.add(signature)
        poly=region(u,lo,hi);contact=root_contact(poly)
        captured=[line for line in lines if (lo is None or line['v']>=lo-1e-8) and (hi is None or line['v']<=hi+1e-8)]
        fraction=max(0.,min(1.,(L/2-u)/L))
        if not captured or fraction<=0:return
        if contact>1e-10*max(1.,c.plate_width):
            inactive.append(dict(id=id,reason='Bloco retém contato positivo com a raiz apoiada.',supported_root_contact_length=contact,cut_u=u,block_polygon=poly));return
        if av<=0 or at<0:return
        demand=N*sum(line['force_fraction'] for line in captured)*fraction
        paths.append(_path(id,'Gusset: '+id,'gusset',av,at,demand,gusset,coords,
            kind=kind,cut_u=u,partial_fraction=fraction,captured_lines=[line['id'] for line in captured],
            supported_root_contact_length=contact,block_polygon=poly,free_edges=free_edges,load_basis='total_pair',
            note='Força capturada de todas as linhas reais; solda atravessada sem crédito resistente.'))
    for station in g['transverse_stations']:
        u=station['u']
        if u>=L/2:continue
        for i in range(len(lines)):
            for j in range(i,len(lines)):
                lo=min(p['footprint_v'][0] for p in lines[i:j+1]);hi=max(p['footprint_v'][1] for p in lines[i:j+1])
                left,right=_forward_exit(c,lo),_forward_exit(c,hi)
                add(f'G_U_{i+1}_{j+1}_u{u:.9f}',u,lo,hi,'U',
                    [left['point'],xy(u,lo),xy(u,hi),right['point']],
                    (left['u']+right['u']-2*u)*t,(hi-lo)*t,[left['edge'],right['edge']])
        chord=station['chord']
        # Footprint ends and all actual line coordinates are capture events.
        for cut in sorted(set(g['footprint_vs']+[line['v'] for line in lines])):
            if not chord['left']['v']-1e-8<=cut<=chord['right']['v']+1e-8:continue
            end=_forward_exit(c,cut)
            for side in ('left','right'):
                cap=chord[side]
                lo,hi=(None,cut) if side=='left' else (cut,None)
                add(f'G_L_{side}_v{cut:g}_u{u:.9f}',u,lo,hi,'L',
                    [end['point'],xy(u,cut),cap['point']],(end['u']-u)*t,abs(cap['v']-cut)*t,[end['edge'],cap['edge']])
    paths.append(_path('G-all','Chapa única: envelope conservador ordinário','gusset',t*L,0.,N,gusset,
        conservative=True,load_basis='total_pair',note='N integral em uma superfície tL; ligamentos transversais descartados. Não é fissura exata.'))
    g['inactive_path_families']=inactive
    return paths


def plate_sections(c,g,N):
    """Four-line piecewise resultants and exact interior normal extrema.

    The existing arbitrary-line polynomial utility supplies the sections only;
    opposed local strips are constructed here, with their own actual moments.
    """
    proxy=dict(g);proxy['angle_section']=dict(g['angle_section'],centroid=g['angle_section']['leg']/2)
    sections=shared.plate_sections(c,proxy,N)
    width,t=c.introduction_width,c.plate_t
    local=sections['local'];local['spread_angle_deg']=math.degrees(math.atan((width-(t+2*g['angle_section']['leg']+2*c.angle_weld_leg))/(2*c.weld_length)))
    e=t/2+g['angle_section']['centroid'];moment=N/2*e
    sigma=N/(width*t);bend=moment/((t/2)*width*width/6)
    face=dict(allocated_thickness_each=t/2,N_each=N/2,e_inplane_each=e,M_magnitude_each=moment,
        sigma_min=sigma-bend,sigma_max=sigma+bend,Ct_lower_full_thickness=local['Ct'],
        interpretation='Triagem suplementar no plano com t/2 por face. Binários físicos fora do plano idealizados por NBR6.1.8.2, não cancelados nem verificados.')
    local['face_screen']=face
    sections['min_normal']=min(sections['min_normal'],face['sigma_min'])
    sections['max_vm']=max(sections['max_vm'],abs(face['sigma_min']),abs(face['sigma_max']))
    for interval in sections['intervals']:
        mid=(interval['y_start']+interval['y_end'])/2;f0=f1=0.
        for line in g['weld_lines']:
            F=N*line['force_fraction'];start,end=line['start'][1],line['end'][1]
            a,b=(F,0.) if mid<=start else (0.,0.) if mid>=end else (F*end/(c.weld_length*g['direction'][1]),-F/(c.weld_length*g['direction'][1]))
            f0+=line['z']*a;f1+=line['z']*b
        interval['physical_surface_sum_zF_coeff']=[f0,f1]
        interval['surface_couple_status']='Diagnóstico físico idealizado fora pelo método estático; não é aprovação de tensões espaciais.'
    return sections



def _calculate_case(c,g,N,case,label,out,materials):
    angle,gusset,support=materials
    g=dict(g)  # Case-specific path applicability must not overwrite another case's witnesses.
    C,S=g['direction']; L=c.weld_length; B=c.plate_width;t=c.plate_t
    W=g['support_catalog']; A=g['angle_section']
    root=root_actions(N,c.theta_deg,g['force_point'])
    Nr,Vr,Mr=root['N'],root['V'],root['M']
    qends=[Nr/B-6*Mr/B**2,Nr/B+6*Mr/B**2]; qs=Vr/B
    qvec=[math.hypot(q,qs) for q in qends]
    qpeak=max(qvec);qavg=sum(qvec)/2;qd=max(qpeak,1.25*qavg)
    root.update(q_n_ends_N_per_mm=qends,q_s_N_per_mm=qs,q_peak=qpeak,q_average=qavg,q_design=qd,
                weld_stress=qd/(math.sqrt(2)*c.root_weld_leg),elastic_peak_equivalent_normal_N=B*max(abs(q) for q in qends))
    sections=plate_sections(c,g,N)
    tension_tol=1e-10*max(1.,abs(N)/(B*t))
    if sections['min_normal'] < -tension_tol:
        witness=min(sections['cuts'],key=lambda x:x['sigma_MPa'])
        if sections['local']['sigma_min'] < witness['sigma_MPa']:witness=sections['local']
        if sections['local']['face_screen']['sigma_min'] <= sections['min_normal']:witness=sections['local']['face_screen']
        _issue(out,case+'_compressed_section','outside_scope','Seção modelada contém compressão: estabilidade desta geometria ainda não qualificada.',
               minimum_normal_MPa=sections['min_normal'],witness=witness)
    paths=rupture_paths(c,g,N,angle,gusset)
    for p in paths:p['case_id']=case
    Ct=max(1-A['centroid']/L,.5)
    if not 0 < Ct <= 1:raise ArithmeticError('Ct da cantoneira inválido.')
    _envelope(out,'angle_tension','Cada L · tração bruta/efetiva · N/2','angle','tension',case,
        [dict(name='Escoamento bruto por L',demand=N/2,resistance=A['Ag']*angle.fy/GAMMA_A1,Ag=A['Ag']),
         dict(name='Ruptura efetiva por L',demand=N/2,resistance=Ct*A['Ag']*angle.fu/GAMMA_A2,Ct=Ct,Ae=Ct*A['Ag'])],
        'NBR5.2.2/5.2.5(c), An=Ag sem furos; piso Ac/Ag=0,5 por bissetriz de abas iguais')
    for component,name in [('angle','Cantoneira'),('gusset','Gusset')]:
        selected=[p for p in paths if p['component']==component]
        reference = ('NBR6.5.6; envelope nominal de aba tL, Ant=0; não reconstrói a ponta arredondada'
                     if component=='angle' and A['resistance_model']=='nominal_equal_angle_NBR'
                     else 'NBR6.5.6; caminhos físicos + envelope conservador')
        _envelope(out,component+'_block',name+' · bloco/rasgamento',component,'block_tearout',case,selected,reference)
    for line in g['weld_lines']:
        F=N*line['force_fraction'];name=line['id']; leg=c.angle_weld_leg
        _row(out,'angle_weld_'+name,'Solda longitudinal · '+name,'angle_weld','weld_'+name,case,F,
             L*leg/math.sqrt(2)*.6*ELECTRODES[c.angle_electrode]/GAMMA_W2,reference='NBR6.2.2.2/6.2.5: filete inscrito, garganta efetiva=s/√2, sem ganho direcional; assegurar execução e inspeção',length=L,leg=leg,force_fraction=line['force_fraction'])
    for component,material in [('angle',angle),('gusset',gusset)]:
        # One surface-adjacent contact footprint per line. Merge into single substrate mode.
        candidates=[]
        for line in g['weld_lines']:
            F=N*line['force_fraction']
            angle_depth=A['toe_flat'] if A['resistance_model']=='catalog_radiused_legacy' else A['t']
            depth=min(c.angle_weld_leg,angle_depth if component=='angle' else c.plate_t)
            Ac=L*depth
            for mech,R in [('Escoamento',.6*material.fy*Ac/GAMMA_A1),('Ruptura',.6*material.fu*Ac/GAMMA_A2)]:
                candidates.append(dict(name=line['id']+' '+mech,demand=F,resistance=R,area=Ac,effective_depth=depth))
        _envelope(out,component+'_substrate',component+' · metal-base da solda longitudinal',component,'longitudinal_substrate',case,candidates,'NBR6.5.5; área min(s,t)L no modelo nominal; face plana publicada somente no modelo legado')
    local=sections['local']; horizontal=sections['intervals']
    _envelope(out,'gusset_yield','Gusset · escoamento N/V/M','gusset','yielding',case,
        [dict(name='Seções horizontais: envelope elástico',demand=max(x['von_mises_envelope'] for x in horizontal),resistance=gusset.fy/GAMMA_A1,unit='MPa'),
         dict(name='Faixa física local N+M',demand=max(abs(local['sigma_min']),abs(local['sigma_max'])),resistance=gusset.fy/GAMMA_A1,unit='MPa')],
         'NBR6.5.3/6.5.5; VM elástico conservador; DG29 espalhamento0–30°')
    normal_max=max(abs(x['sigma_MPa']) for x in sections['cuts']);tau_max=max(x['tau_abs_max'] for x in horizontal)
    _envelope(out,'gusset_rupture','Gusset · ruptura por tração/cisalhamento','gusset','rupture',case,
        [dict(name='Seções horizontais Ct1',demand=normal_max,resistance=gusset.fu/GAMMA_A2,unit='MPa'),
         dict(name='Seções horizontais: cisalhamento',demand=tau_max,resistance=.6*gusset.fu/GAMMA_A2,unit='MPa'),
         dict(name='Faixa local Ct conservador adaptado',demand=max(abs(local['sigma_min']),abs(local['sigma_max'])),resistance=local['Ct']*gusset.fu/GAMMA_A2,unit='MPa',Ct=local['Ct'])],
         'NBR6.5.3/6.5.5; adaptação explícita de5.2.5(d) somente à faixa local')
    face=sections['local']['face_screen']
    _envelope(out,'gusset_face_screen','Chapa única · screen por face com meia espessura','gusset','allocated_face_screen',case,
        [dict(name='Escoamento N/2 em t/2',demand=face['sigma_max'],resistance=gusset.fy/GAMMA_A1,unit='MPa'),
         dict(name='Ruptura adaptada N/2 em t/2',demand=face['sigma_max'],resistance=local['Ct']*gusset.fu/GAMMA_A2,unit='MPa',Ct=local['Ct'])],
        'Triagem suplementar conservadora no plano; t/2 por face soma uma chapa; binário espacial não verificado')
    _row(out,'root_weld','Solda dupla da raiz · N/V/M','root_weld','weld',case,root['weld_stress'],
         .6*ELECTRODES[c.root_electrode]/GAMMA_W2,'MPa','NBR6.2.5 + DG29 max(qpico,1.25qmédio)',**root)
    # Substrate in the root: one actual plate section, not two thicknesses.
    qn=max(abs(q) for q in qends)
    for component,material,depth in [('gusset_root',gusset,min(t,2*c.root_weld_leg)),('support_contact',support,2*c.root_weld_leg)]:
        sn=qn/depth;ts=abs(qs)/depth
        _envelope(out,component+'_substrate',component+' · metal-base da raiz',component,'root_substrate',case,
            [dict(name='Escoamento combinado',demand=math.hypot(sn,math.sqrt(3)*ts),resistance=material.fy/GAMMA_A1,unit='MPa'),
             dict(name='Ruptura normal',demand=sn,resistance=material.fu/GAMMA_A2,unit='MPa'),
             dict(name='Ruptura por cisalhamento',demand=ts,resistance=.6*material.fu/GAMMA_A2,unit='MPa')],
             'NBR6.5.3/6.5.5; base recebendo tração normal + cisalhamento',)
    # Actual web end proximity acts on every loaded point, not root centroid alone.
    end_distance=min(g['support_end_clearances']);kfactor=2.5 if end_distance <= W['d'] else 5.
    Rnormal=1.10*support.fy*W['tw']*(kfactor*W['k']+B)/GAMMA_A1
    Neq=root['elastic_peak_equivalent_normal_N']
    _row(out,'W_web_normal','W · escoamento local da alma por força normal','support_web','local_normal_yield',case,Neq,Rnormal,
         reference='NBR5.7.3; envelope elástico |N|+6|M|/L derivado',end_factor=kfactor,end_distance=end_distance)
    As=W['tw']*B
    _envelope(out,'W_web_shear','W · cisalhamento longitudinal da alma','support_web','longitudinal_shear',case,
        [dict(name='Escoamento',demand=abs(Vr),resistance=.6*support.fy*As/GAMMA_A1),
         dict(name='Ruptura',demand=abs(Vr),resistance=.6*support.fu*As/GAMMA_A2)],'DG29 p204; NBR6.5.5; Agv=twL, Vparalelo')
    # Conservative simultaneous local normal/shear web screen used in qualified oracle.
    web_normal=Neq/(W['tw']*B)
    web_shear=1.5*abs(Vr)/As
    _row(out,'W_web_combined','W · combinação local da alma','support_web','combined_yield',case,
         math.hypot(web_normal,math.sqrt(3)*web_shear),support.fy/GAMMA_A1,'MPa','Triagem elástica local conservadora derivada')
    flange_tau=qpeak/(2*W['tf'])
    _envelope(out,'W_flange_punch','W · cisalhamento/punção da mesa','support_flange','punching',case,
        [dict(name='Escoamento nas duas faces longitudinais',demand=flange_tau,resistance=.6*support.fy/GAMMA_A1,unit='MPa'),
         dict(name='Ruptura nas duas faces longitudinais',demand=flange_tau,resistance=.6*support.fu/GAMMA_A2,unit='MPa')],
        'NBR6.5.5; duas superfícies2tfL, sem crédito das bordas curtas')
    footprint=t+2*c.root_weld_leg
    exempt=footprint < .15*W['bf']
    if not exempt:
        Rbend=6.25*support.fy*W['tf']**2/GAMMA_A1
        if end_distance < 10*W['tf']:Rbend/=2
        _row(out,'W_flange_bending','W · flexão local da mesa','support_flange','local_bending',case,Neq,Rbend,
             reference='NBR5.7.2; largura carregada tg+2s; metade junto à extremidade',footprint=footprint)
    root['flange_bending_exempt']=exempt;root['flange_footprint']=footprint
    member=dict(reference='Centroide da raiz na face exterior da mesa',point_local=[0.,0.],
                applied_to_support=dict(N_normal=Nr,V_parallel=Vr,M_root=Mr),
                equal_opposite_on_gusset=dict(N_normal=-Nr,V_parallel=-Vr,M_root=-Mr),
                introduced_member_shear_jump=Nr,introduced_member_axial_jump=Vr,
                root_to_member_centroid_normal_offset=W['d']/2,
                introduced_moment_about_member_centroid=Mr-W['d']/2*Vr,
                existing_member_actions=None,global_member_verified=False,
                note='Somar às ações concorrentes reais do membro; não se presume apoio descarregado.')
    record=dict(id=case,label=label,N=N,root=root,plate_sections=sections,paths=paths,
                inactive_path_families=g.get('inactive_path_families',[]),member_actions=member,
                angle_Ct=Ct,angle_Ae=Ct*A['Ag'],N_per_angle=N/2,angle_count=2,pair_gross_area=2*A['Ag'],pair_effective_area=2*Ct*A['Ag'],angle_forces=[dict(face=face,N=N/2,heel_N=N/2*A['heel_force_fraction'],toe_N=N/2*A['toe_force_fraction']) for face in FACE_IDS])
    out['cases'].append(record)
    if case=='actual':
        out.update(root=root,sections=sections,paths=paths,member_actions=member)
        out['geometry']['inactive_path_families']=g.get('inactive_path_families',[])


def evaluate(c):
    out=dict(status='INVALID_INPUT',global_pass=False,local_pass=False,issues=[],checks=[],cases=[],geometry={},
             root={},sections={},paths=[],materials={},member_actions={},summary={},inputs=_safe({k:v for k,v in asdict(c).items() if k not in shared.outer.WELDED_FIELDS}) if isinstance(c,WeldedOpposedAngleGusset) else _safe(c),
             family=FAMILY,connection_type=CONNECTION_TYPE,component_version=COMPONENT_VERSION,units=dict(UNITS),scope=SCOPE,exclusions=list(EXCLUSIONS))
    errors=input_errors(c)
    if errors:
        for n,e in enumerate(errors):_issue(out,'input_'+str(n),'invalid_input',e)
        return _finalize(out)
    out['fixed_assumptions']=c.fixed_assumptions
    conditions=[(c.topology!='opposed_vertices','opposed_topology','Somente duas L opostas pelos vértices (><), contato direto e h=tg.'),
      (c.interface!='welded','interface','Somente quatro filetes longitudinais; interface parafusada ou mista fora do ramo.'),
      (not c.symmetric_load,'symmetric_load','Partilha N/2 exige seções, aços, ligações e carregamento simétricos, inclusive na extremidade oposta.'),
      (not c.accessible_both_faces,'weld_access','As quatro soldas longitudinais exigem execução e inspeção acessíveis nas duas faces.'),
      (c.support_member not in ('beam','column'),'member','Membro de apoio deve ser viga ou pilar.'),
      (c.support_face!='flange','face','Ligação direta à alma W ainda não qualificada; esta rota usa mesa exterior centrada na alma.'),
      (get_angle(c.angle_profile) is None,'angle_catalog','Cantoneira não reconhecida; selecionar identidade exata de fabricante e linha do catálogo.'),
      (c.angle_weld_edge_detail not in ('ordinary','reinforced'),'angle_weld_edge_detail','Detalhe de borda deve ser ordinary ou reinforced.'),
      (c.angle_weld_edge_detail == 'reinforced' and c.angle_profile == LEGACY_ARCELOR_ID,'legacy_edge_detail','Seção ArcelorMittal legada conserva o detalhe original sem reforço de borda.'),
      (c.support_profile not in SUPPORT_CATALOG,'support_catalog','Perfil W laminado não reconhecido; selecionar identidade completa do catálogo.'),
      (c.N<0,'compression','N negativo é compressão; não é convertido em módulo nem aprovado pelo método de tração.'),
      (any(x!=0 for x in (c.V,c.M,c.torsion)),'external_actions','Ações V/M/T externas preservadas, mas fora desta rota axial; M geométrico da raiz é calculado normalmente.'),
      (not c.static or c.fatigue or c.seismic,'nonstatic','Exige solicitação estática sem fadiga/sismo para6.1.8.2.'),
      (not c.normal_combination,'combination','Fatores limitados a combinações últimas normais.'),
      (not c.minimum_force and 0<=c.N<45000,'minimum_force','Sem exceção declarada, desativar o candidato45kN impede aprovação para N<45kN.')]
    for test,id,msg in conditions:
        if test:_issue(out,id,'outside_scope',msg)
    A=get_angle(c.angle_profile)
    material_objs=[]
    for role,name,thickness in [('angle',c.angle_steel,A['t'] if A else 0.),('gusset',c.gusset_steel,c.plate_t),('support',c.support_steel,SUPPORT_CATALOG.get(c.support_profile,SUPPORT)['tf'])]:
        mat=MATERIALS.get(name)
        if not mat:
            _issue(out,role+'_material','outside_scope',role+': material fora do catálogo.');continue
        okay=(mat.plate_allowed and mat.plate_min<=thickness<=mat.plate_max if role=='gusset' else mat.rolled_allowed and mat.profile_min<=thickness<=mat.profile_max)
        if not okay:_issue(out,role+'_material_product','outside_scope',role+': produto/espessura fora do intervalo do aço selecionado.')
        material_objs.append(mat);out['materials'][role]=dict(name=name,fy=mat.fy,fu=mat.fu,thickness=thickness,source=mat.source)
    for interface,name in [('angle_weld',c.angle_electrode),('root_weld',c.root_electrode)]:
        if name not in ELECTRODES:_issue(out,interface+'_electrode','outside_scope','Consumível não reconhecido.')
        else:out['materials'][interface]=dict(name=name,fw=ELECTRODES[name])
    try:
        g=_geometry(c,out)
        if g is not None:out['geometry']=g
        # Never compute selected geometry using known fixture coefficients after a topology error.
        fatal=any(i['severity'] in ('outside_scope','invalid_geometry') for i in out['issues'])
        if g and not fatal and len(material_objs)==3:
            loads=[('actual','Tração real total do par',c.N)]
            if c.minimum_force and c.N<45000:loads.append(('minimum_45kN','Mínimo total45kN · NBR6.1.5.2',45000.))
            if c.recommend_half_capacity:
                a=material_objs[0];Ct=max(1-A['centroid']/c.weld_length,.5)
                half=.5*min(2*A['Ag']*a.fy/GAMMA_A1,2*Ct*A['Ag']*a.fu/GAMMA_A2)
                loads.append(('recommended_half','Recomendação50% da capacidade do par · opção do RT · NBR6.1.5.3',half))
            for id,label,N in loads:_calculate_case(c,g,N,id,label,out,material_objs)
        # Check all serialized arithmetic, including geometry intermediates.
        def check(v):
            if isinstance(v,dict):return all(check(x) for x in v.values())
            if isinstance(v,(tuple,list)):return all(check(x) for x in v)
            return finite_real(v) if isinstance(v,(int,float)) and not isinstance(v,bool) else True
        if not check(out):raise ArithmeticError('Resultado intermediário não finito.')
    except (ArithmeticError,ValueError,TypeError,ZeroDivisionError) as e:
        _issue(out,'numerical_failure','numerical_failure','Cálculo não concluído: '+str(e))
    return _finalize(out)
