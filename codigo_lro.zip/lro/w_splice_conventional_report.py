"""Traceable signed N/M/V report, with no inherited axial approval text."""
from collections import OrderedDict
from dataclasses import asdict
from io import BytesIO
import json
from math import isfinite
from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor
from .report import BRAND, LINK, _math as _legacy_math, group, hyperlink, number
from .w_splice_report import _tab as _base_tab, _section, _geometry, COMPONENTS
from .w_splice_conventional_drawing import image_bytes, SUPPORT_DETAIL
from .w_splice_conventional import COMPONENT_VERSION, evaluate
from .models import VERSION

STATUS = {
    'NOT_EVALUATED':'SEM AÇÕES NÃO NULAS AVALIÁVEIS',
    'INVALID_INPUT':'DADOS INVÁLIDOS',
    'NUMERICAL_FAILURE':'CÁLCULO NÃO CONCLUÍDO · FAIXA NUMÉRICA',
    'INVALID_GEOMETRY':'GEOMETRIA FISICAMENTE INVÁLIDA',
    'OUTSIDE_CONVENTIONAL_SCOPE':'FORA DO DOMÍNIO CONVENCIONAL',
    'VERIFIED_SUBCHECK_FAIL':'NÃO ATENDE ÀS VERIFICAÇÕES REALIZADAS',
    'DETAIL_FAIL':'NÃO ATENDE AO DETALHAMENTO',
    'LOCAL_CHECKS_PENDING':'VERIFICAÇÕES LOCAIS / PRÉ-REQUISITOS PENDENTES',
    'LOCAL_CHECKS_PASS_WITHIN_SCOPE':'ATENDE ÀS VERIFICAÇÕES LOCAIS NO DOMÍNIO',
}


def _math(doc,expr):
    """Keep italic first-glyph overhang clear of LibreOffice's OMML clip box."""
    pad=OxmlElement('m:r');text=OxmlElement('m:t')
    text.set(qn('xml:space'),'preserve');text.text='  ';pad.append(text)
    _legacy_math(doc,[pad,*expr])


def _tab(doc,headers,rows,widths,size=8.3):
    table=_base_tab(doc,headers,rows,widths,size)
    # Large diagnostic vectors may continue on the next page instead of clipping.
    for row in list(table.rows)[1:]:
        if sum(len(cell.text) for cell in row.cells)>900:
            for element in row._tr.xpath('./w:trPr/w:cantSplit'):
                element.getparent().remove(element)
    return table


def _num(value,places=6):
    if isinstance(value,bool) or not isinstance(value,(int,float)) or not isfinite(value):
        return str(value) if value is not None else 'não disponível'
    rendered=number(value,places)
    if value!=0 and (abs(value)<10**(-places) or len(rendered)>24):
        return f'{value:.12g}'.replace('.',',')
    return rendered


def _check_num(value):
    """Bound narrow resistance-table cells; exact values remain in result JSON."""
    rendered=_num(value)
    if isinstance(value,(int,float)) and not isinstance(value,bool) and isfinite(value) and len(rendered)>16:
        return f"{value:.6e}".replace(".",",")
    return rendered


def _json(value):
    return json.dumps(value,ensure_ascii=False,sort_keys=True,default=str,separators=(',',':'))


def _mapping(value):
    return value if isinstance(value,dict) else {}


def _table_value(value):
    if isinstance(value,(dict,list,tuple)):return _json(value)
    if isinstance(value,(int,bool)):return str(value)
    return _num(value)


def result_matches_input(c,r):
    """Input-copy comparison only; never evidence of calculation integrity.

    Public exports and local_pass_is_complete independently reevaluate c.
    """
    inp=r.get('inputs',r.get('input'))
    if not isinstance(inp,dict):
        return False
    current=asdict(c)
    if 'connection' in inp:
        inp=inp['connection']
    return inp==current


def local_pass_is_complete(c,r):
    if not isinstance(r,dict) or r!=evaluate(c):
        return False
    return _canonical_local_pass(r)


def _canonical_local_pass(r):
    summary=_mapping(r.get('summary'))
    checks=r.get('checks',[])
    blocked={'invalid_input','numerical_failure','invalid_geometry','unsupported_scope','engineering_pending','access_pending','detail_fail','service_pending','pending'}
    return (r.get('status')=='LOCAL_CHECKS_PASS_WITHIN_SCOPE'
            and summary.get('complete_local_checks') is True
            and _mapping(r.get('scope')).get('supported') is True
            and r.get('capacity_calculation_permitted') is True
            and summary.get('check_count')==len(checks)
            and bool(checks) and all(x.get('status') in ('PASS','NOT_APPLICABLE') for x in checks)
            and not any(x.get('severity') in blocked for x in r.get('issues',[]))
            )


def _loads(doc,c,r):
    doc.add_paragraph('Ações e modelo convencional',style='Heading 1')
    _tab(doc,['Ação de cálculo informada','Valor','Unidade'],[
        ('N, positivo em tração',_num(c.N),'N'),('M, eixo principal',_num(c.M),'N·mm'),
        ('V, cortante assinado',_num(c.V),'N'),('T, fora do domínio',_num(c.torsion),'N·mm')],[3.75,2.1,1.2])
    doc.add_paragraph('Ações últimas já majoradas; sem aplicação automática de fatores de carga. Os sinais são preservados. Compressão e reversão de M/V fazem parte deste modelo estático.')
    eccentricity=c.gap/2+c.web_member_end+(c.web_rows-1)*c.web_pitch/2
    jgroup=sum(((i-(c.web_rows-1)/2)*c.web_pitch)**2+((j-(c.web_levels-1)/2)*c.web_gauge)**2 for i in range(c.web_rows) for j in range(c.web_levels))
    for formula in ('h0 = d − tf; Ftop = N/2 − M/h0; Fbottom = N/2 + M/h0',
                    'Nw = 0; Mw(0) = 0; Vcover = V/2; M(x) = M(0) − V x',
                    f'Fouter = Fflange/2; Finner = Fflange/4; Fx = 0; Fy = ±V; Cg = −e V; e = {eccentricity:g} mm',
                    f'Jgroup = Σ(x² + y²) = {jgroup:g} mm²; qx = −Cg y/Jgroup; qy = Fy/6 + Cg x/Jgroup'):
        _math(doc,group(formula))
    doc.add_paragraph('Especialização atual de partilha igual: bo=2bi, mesma espessura e material; não é exigência universal da NBR. A externa recebe F/2 e cada interna F/4.')
    doc.add_paragraph('Fonte do modelo de forças e do apoio por filas: Fakury et al., §10.14.7, páginas impressas 311–320. Arranjo convencional com toda a normal e o momento nas mesas; a alma transfere V e seu momento de excentricidade Ve. As duas extremidades estão em série; suas capacidades não são somadas. Não há crédito de contato de topo.')
    lm=_mapping(r.get('load_model'))
    if not lm:
        doc.add_paragraph('Modelo de forças não calculado nesta avaliação; não se atribuem capacidades favoráveis.')
        return
    if r.get('load_cases'):
        doc.add_paragraph('Casos efetivamente calculados',style='Heading 2')
        _tab(doc,['Caso','N (N)','M (N·mm)','V (N)','Fsuperior (N)','Finferior (N)'],
             [(str(case.get('case_id','')), _num(case.get('N_N')), _num(case.get('M_Nmm')), _num(case.get('V_N')), _num(case.get('top_force_N')), _num(case.get('bottom_force_N'))) for case in r['load_cases']],
             [1.0,1.15,1.35,1.15,1.2,1.2],size=7.5)
    rows=[]
    for key,label,unit in (
        ('h0_mm','Braço h0','mm'),('top_force_N','Força assinada na mesa superior','N'),
        ('bottom_force_N','Força assinada na mesa inferior','N'),('Nw_N','Normal da alma','N'),
        ('Mw_splice_Nmm','Momento próprio da alma no centro','N·mm'),('V_N','Cortante total','N'),
        ('web_group_moment_per_cover_Nmm','Momento do grupo Ve por tala','N·mm'),
        ('web_design_moment_envelope_per_cover_Nmm','Envelope de projeto por tala: máximo entre Ve e cortes','N·mm'),
        ('web_max_cut_moment_per_cover_Nmm','Máximo momento real nos cortes por tala','N·mm'),
        ('member_moment_envelope_Nmm','Envelope M − Vx do membro no trecho de transferência','N·mm')):
        if key in lm:rows.append((label,_num(lm.get(key)),unit))
    _tab(doc,['Grandeza','Valor','Unidade'],rows,[4.0,1.85,1.2])
    doc.add_paragraph('O momento de grupo Ve não é o momento de todos os cortes. A resistência usa o maior entre o módulo de Ve e o máximo dos cortes reais. Os cortes antes e depois de cada estação são registrados abaixo. O envelope do membro alcança as filas extremas de mesa e retém o gradiente Vx.')
    groups=lm.get('web_groups',[])
    if groups:
        doc.add_paragraph('Grupos completos da alma e vetores',style='Heading 2')
        _tab(doc,['Lado','Centro x mm','Fx N','Fy N','Cg N·mm','J mm²'],[
            (x.get('side',''),_num(x.get('center_x_mm'),3),_num(x.get('Fx_N'),3),_num(x.get('Fy_N'),3),_num(x.get('C_Nmm'),3),_num(x.get('J_mm2'),3)) for x in groups],
            [.65,1.05,1.05,1.25,1.6,1.45],size=7.7)
        bolts=[]
        for item in groups:
            for i,bolt in enumerate(item.get('bolts',[]),1):
                bolts.append((str(item.get('side',''))+' '+str(i),_num(bolt.get('x_mm'),3),_num(bolt.get('y_mm'),3),
                              _num(bolt.get('qx_N'),3),_num(bolt.get('qy_N'),3),_num(bolt.get('resultant_N'),3),_num(bolt.get('each_plane_resultant_N'),3)))
        _tab(doc,['Parafuso','x mm','y mm','qx N','qy N','Resultante N','Por plano N'],bolts,[.8,.6,.6,1.15,1.15,1.4,1.35],size=7.7)
        doc.add_paragraph('Coordenadas x/y globais. Cada vetor do parafuso completo se divide igualmente entre as duas talas/planos físicos; não se duplica sua resistência. Os sinais variam com o lado e o cortante informado.')
    cuts=lm.get('web_cut_records',[])
    if cuts:
        doc.add_paragraph('Equilíbrio nos cortes antes/depois das filas, por tala',style='Heading 2')
        _tab(doc,['x mm','Corte','N N','V N','M N·mm'],[
            (_num(x.get('x_mm'),3),'depois' if x.get('inclusive') else 'antes',_num(x.get('N_N')),_num(x.get('V_N')),_num(x.get('M_Nmm'))) for x in cuts],
            [.8,.8,1.6,1.7,2.15],size=7.7)
    for key,label in [('residual_N_N','Resíduo de normal (N)'),('residual_M_Nmm','Resíduo de momento no centro (N·mm)'),('cover_residual_M_Nmm','Resíduo de equilíbrio global da tala (N·mm)')]:
        if key in lm:
            doc.add_paragraph(label+': '+_num(lm[key],9)+'.')



def _prerequisites(doc,c,r):
    doc.add_paragraph('Detalhe físico de apoio e pré-requisitos',style='Heading 1')
    doc.add_paragraph('Detalhe declarado: '+str(getattr(c,'assembly_detail','não informado'))+'.')
    for text in SUPPORT_DETAIL:
        doc.add_paragraph(text)
    doc.add_paragraph('São oito peças independentes: duas talas externas, quatro tiras internas e duas talas de alma. Nenhuma rigidez ou inércia composta pelo afastamento entre chapas é creditada. O comprimento sem apoio é o intervalo entre filas completas, inclusive a ponte central; nunca apenas a folga entre topos. O coeficiente K=1 é conservador em relação à premissa fonte. NBR 8800:2024, 6.5.4, com Er1:2025: o segundo ramo é Le/r > 25.')
    doc.add_paragraph('Política de ações mínimas / continuidade 6.1.5: '+str(getattr(c,'minimum_action_policy','pending'))+'.')
    _tab(doc,['Envelope mínimo informado','Valor','Unidade'],[
        ('N mínimo assinado',_num(getattr(c,'minimum_N',0.)),'N'),
        ('M mínimo assinado',_num(getattr(c,'minimum_M',0.)),'N·mm'),
        ('V mínimo assinado',_num(getattr(c,'minimum_V',0.)),'N')],[3.75,2.1,1.2])
    doc.add_paragraph('Referência do envelope ou decisão do responsável técnico: '+(str(getattr(c,'minimum_reference','')) or 'PENDENTE')+'. As ações reais não são substituídas por 45 kN nem convertidas de compressão em tração. O mínimo obrigatório de 6.1.5.2 é tratado em caso separado pelo motor. A recomendação de 50%/100% da resistência do membro em 6.1.5.3 tem decisão própria documentada; a escolha de não adotá-la não dispensa mínimos obrigatórios nem outros requisitos aplicáveis.')
    if getattr(c,'minimum_action_policy','pending')=='actual_actions_engineer_choice':
        doc.add_paragraph('DECISÃO DO RESPONSÁVEL TÉCNICO: usar as ações declaradas sem adotar a recomendação discricionária de 50%/100% da resistência do membro. A decisão e sua referência são fornecidas pelo responsável; não equivalem a capacidades globais verificadas pelo aplicativo.')
    doc.add_paragraph('Os valores minimum_N/M/V são utilizados apenas quando a política é provided_envelope. A tabela de casos efetivamente calculados identifica cada ação realmente conferida.')
    if r.get('minimum_action_basis'):
        _tab(doc,['Base dos mínimos / decisão','Registro exato'],[(k,_table_value(v)) for k,v in r['minimum_action_basis'].items()],[2.2,4.85],size=8)
    doc.add_paragraph('Capacidades externas do membro',style='Heading 2')
    _tab(doc,['Capacidade informada','Valor','Unidade'],[
        ('Nc,Rd',_num(getattr(c,'member_Nc_Rd',0.)),'N'),('Nt,Rd',_num(getattr(c,'member_Nt_Rd',0.)),'N'),
        ('M,Rd',_num(getattr(c,'member_M_Rd',0.)),'N·mm'),('V,Rd',_num(getattr(c,'member_V_Rd',0.)),'N')],[3.75,2.1,1.2])
    doc.add_paragraph('Fonte/referência externa: '+(str(getattr(c,'member_capacity_reference','')) or 'NÃO FORNECIDA')+'.')
    doc.add_paragraph('Vínculo de dados da verificação externa: '+(str(getattr(c,'member_capacity_binding','')) or 'NÃO FORNECIDO')+'. O vínculo de dados não certifica por si a análise externa. Resistências de compressão das talas jamais substituem Nc,Rd do membro.')
    for key in ('member_external','member_capacity_status','member_verification_status','prerequisites','external_member','service'):
        if key in r:
            doc.add_paragraph(key+': '+_json(r[key]))
    doc.add_paragraph('Se a verificação global do membro não estiver fornecida e validamente vinculada, ela permanece explicitamente excluída. Atendimento local não afirma estabilidade global, análise do sistema, rigidez de pórtico, deflexões, fadiga, sismo ou estabilidade de montagem.')
    doc.add_paragraph('Resistência ao deslizamento exigida pelo projeto: '+('SIM; é necessário cálculo específico de protensão, superfícies, furos e ações de serviço' if c.no_slip_required else 'NÃO declarada; este resultado é de ELU por contato')+'. O cálculo por contato não certifica ausência de deslizamento.')


def _checks(doc,r):
    rows=[x for x in r.get('checks',[]) if isinstance(x,dict)]
    doc.add_paragraph('Todas as verificações calculadas',style='Heading 1')
    doc.add_paragraph(f'Total de {len(rows)} linhas. Solicitação, resistência, unidade e estado são os devolvidos pelo motor, com decisões antes do arredondamento. Forças, momentos, tensões e índices adimensionais não recebem uma unidade universal de força. Células numéricas com mais de 16 caracteres usam notação científica com seis casas decimais; os valores completos permanecem no JSON de verificações.')
    if not rows:
        doc.add_paragraph('Não há verificações resistentes calculadas. As pendências e os limites de domínio não são convertidos em aprovação.')
        return
    equations=OrderedDict()
    for row in rows:
        equations.setdefault((str(row.get('formula','')),str(row.get('reference',''))),'E'+str(len(equations)+1))
    for (formula,ref),label in equations.items():
        doc.add_paragraph(label,style='Heading 2');_math(doc,group(formula));doc.add_paragraph(ref)
    grouped=OrderedDict()
    for row in rows:
        grouped.setdefault(str(row.get('component','não identificado')),[]).append(row)
    for component,checks in grouped.items():
        name=' '.join(COMPONENTS[component]) if component in COMPONENTS else component
        doc.add_paragraph(name,style='Heading 2')
        data=[]
        for row in checks:
            key=(str(row.get('formula','')),str(row.get('reference','')))
            data.append((str(row.get('id',''))+'\n'+str(row.get('label','')),
                         _check_num(row.get('demand')), _check_num(row.get('capacity')),
                         str(row.get('units','não declarada')), _check_num(row.get('utilization')),
                         'N/A' if row.get('status')=='NOT_APPLICABLE' else str(row.get('status','NÃO AVALIADO')),equations[key]))
        _tab(doc,['ID e verificação','Solicitação','Resistência','Unidade','η','Estado','Eq.'],data,[2.25,.95,.95,.65,.85,.88,.52],size=7.3)
    doc.add_paragraph('Notas de interpretação das resistências',style='Heading 2')
    doc.add_paragraph('Mesa do membro: NBR 5.1.2.2.4(a), b=bf/2 e Aef=2 beff tf; a faixa central já está incluída. χ=1 é uma tela local, não Nc,Rd global. Larguras AA/AL próprias das talas permanecem separadas.')
    doc.add_paragraph('Bloco de alma: caminhos físicos e prefixos de famílias L/U enumerados pelo motor, com ambas as bordas livres e espelhos; demanda integral |V|/2 por tala em cada caminho e Cts=0,5, condicionada ao domínio de equilíbrio declarado. Os caminhos retêm o momento residual como diagnóstico; a convenção escalar é a do procedimento fonte, sem lei inventada para Nw/Mw independentes. As interfaces da alma do membro com as mesas não são bordas livres.')
    doc.add_paragraph('Flexão líquida das talas de alma integra os três furos, inclusive o furo central: Znet=69.760 mm³ no exemplo de tala 200×10 mm, furos deduzidos de 24 mm e níveis ±60/0 mm; variantes usam sua geometria efetiva. O critério adicional |V|/VRd + |Menv|/MRd,net ≤ 1 é uma triagem conservadora de projeto; não é apresentado como uma equação normativa geral de fratura mista. Resistência à flexão, cisalhamento, combinação elástica e bloco são preservadas separadamente.')
    governing=_mapping(r.get('summary')).get('governing_check_id')
    row=next((x for x in rows if x.get('id')==governing),None)
    if row:
        doc.add_paragraph('Dados completos da linha governante',style='Heading 2')
        _tab(doc,['Campo','Valor'],[(k,_table_value(v)) for k,v in row.items()],[1.65,5.4],size=7.8)



def _envelopes(doc,r):
    doc.add_paragraph('Síntese por componente físico e mecanismo',style='Heading 1')
    envelopes=r.get('mechanism_envelopes',[])
    doc.add_paragraph(f'{len(envelopes)} envelopes de apresentação; {len(r.get("checks",[]))} verificações primitivas preservadas no desenvolvimento. Cada linha abaixo mantém a solicitação, a resistência, o índice e o caso da mesma verificação governante. Não há soma de capacidades nem redução dos 84 caminhos físicos por tala de alma. N/A (NOT_APPLICABLE) significa demanda nula em todos os ramos/casos do mecanismo.')
    data=[]
    for env in envelopes:
        row=env['governing_check']
        data.append((env['component_group']+'\n'+env['mechanism'],row['id'],
                     _check_num(row['demand']),_check_num(row['capacity']),row['units'],
                     _check_num(row['utilization']),'N/A' if env['status']=='NOT_APPLICABLE' else env['status']))
    if data:_tab(doc,['Componente / mecanismo','ID / caso governante','Solicitação','Resistência','Unid.','η','Estado'],data,[1.65,1.7,.9,.9,.5,.6,.8],size=7.4)


def _envelope_details(doc,r):
    envelopes=r.get('mechanism_envelopes',[])
    doc.add_paragraph('Apêndice de linhas governantes completas',style='Heading 1')
    # These compact records retain the exact chosen path, source and formula;
    # all member IDs and branch numeric rows remain in the detailed tables/JSON.
    for env in envelopes:
        row=env['governing_check']
        doc.add_paragraph(env['id']+' | '+env['governing_case_id']+' | '+str(env['primitive_count'])+' ramos',style='Heading 2')
        _tab(doc,['Campo governante','Valor'],[(k,_table_value(v)) for k,v in row.items()],[1.65,5.4],size=7.5)


def create_report(c,r=None):
    # Caller-controlled inputs, PASS flags and row counts are not provenance.
    # One accepted input creates the entire current artifact snapshot.
    supplied=r
    r=evaluate(c)
    refreshed=supplied is not None and supplied!=r
    doc=Document();section=doc.sections[0]
    section.page_width=Inches(8.27);section.page_height=Inches(11.69)
    section.top_margin=section.bottom_margin=Inches(.52)
    section.left_margin=section.right_margin=Inches(.6)
    for name in ('Normal','Title','Subtitle','Heading 1','Heading 2'):
        doc.styles[name].font.name='Arial';doc.styles[name].font.color.rgb=RGBColor(0,0,0)
    for style in doc.styles:
        for border in style.element.xpath('.//w:pBdr'):
            border.getparent().remove(border)
    doc.styles['Normal'].font.size=Pt(9)
    doc.styles['Normal'].paragraph_format.space_after=Pt(5)
    doc.styles['Title'].font.size=Pt(21)
    doc.core_properties.title='Memória da emenda W convencional N/M/V'
    doc.core_properties.author='LRO Soluções de engenharia LTDA.'
    doc.add_paragraph('Emenda W convencional N/M/V',style='Title')
    doc.add_paragraph('Oito talas independentes · ações assinadas · domínio local',style='Subtitle')
    doc.add_paragraph(str(c.project)+' | '+c.profile.name+' | Componente '+COMPONENT_VERSION)
    doc.add_paragraph('Aplicativo '+VERSION+' | Método convencional revisado 0.9.14')
    status=str(r.get('status','RESULTADO INCOMPLETO'))
    doc.add_paragraph(STATUS.get(status,status),style='Heading 1')
    doc.add_paragraph('Estado exato do motor: '+status+'.')
    if _canonical_local_pass(r):
        doc.add_paragraph('As verificações locais calculadas atendem dentro do domínio e das condições declaradas. Esse resultado não certifica a estabilidade global dos membros nem o comportamento de serviço.')
    else:
        doc.add_paragraph('Não há aprovação completa das verificações locais nesta avaliação. Linhas isoladas atendidas não eliminam falhas, pendências ou limites de domínio. Não há aprovação global da emenda.')
    if refreshed:
        doc.add_paragraph('AVISO DE RASTREABILIDADE: resultado fornecido incompleto, alterado ou desatualizado em relação ao projeto. Foi descartado; toda esta memória usa uma avaliação nova da entrada atual.')
    summary=_mapping(r.get('summary'))
    _tab(doc,['Síntese do motor','Valor'],[(k,_table_value(v)) for k,v in summary.items()] or [('Síntese','Não disponível')],[3.0,4.05])
    doc.add_paragraph('Unidades internas: N, mm, MPa e N·mm. Sem arredondamento intermediário. Esta família convencional é distinta do modelo axial M004 e do modelo geral com parcela de N/M na alma; projetos não são migrados silenciosamente.')
    doc.add_paragraph('Ocorrências, falhas e pendências',style='Heading 1')
    for issue in r.get('issues',[]):
        doc.add_paragraph(str(issue.get('severity',''))+' | '+str(issue.get('text',''))+' | '+str(issue.get('reference','')))
    if not r.get('issues'):
        doc.add_paragraph('Nenhuma ocorrência registrada; o domínio e as exclusões permanecem aplicáveis.')
    try:
        png=image_bytes(c,r)
    except (ValueError,TypeError,AttributeError,OverflowError,ZeroDivisionError) as exc:
        doc.add_paragraph('Desenho indisponível para esta entrada: '+str(exc))
    else:
        _section(doc,landscape=True)
        pic=doc.add_picture(BytesIO(png),width=Inches(10.45))
        pic._inline.docPr.set('descr','Emenda convencional N/M/V, oito talas W1 W2 F1 F2 F3 F4 F5 F6, apoios nas filas completas e sem contato de topo.')
        _section(doc,landscape=False)
    _envelopes(doc,r)
    _geometry(doc,c,r)
    for paragraph in doc.paragraphs:
        if paragraph.text.startswith('Área bruta de catálogo A='):
            paragraph.text=paragraph.text.replace('Área bruta de catálogo A=','Área bruta declarada A=',1)
    _loads(doc,c,r);_prerequisites(doc,c,r);_checks(doc,r)
    _envelope_details(doc,r)
    doc.add_paragraph('Entrada integral registrada',style='Heading 1')
    _tab(doc,['Campo','Valor exato'],[(k,_table_value(v)) for k,v in asdict(c).items()],[2.15,4.9],size=7.7)
    strips=_mapping(r.get('compression_strips'))
    if strips:
        doc.add_paragraph('Estabilidade independente das talas de mesa',style='Heading 1')
        outer=_mapping(strips.get('outer'));inner=_mapping(strips.get('inner'))
        keys=list(dict.fromkeys(list(outer)+list(inner)))
        _tab(doc,['Grandeza / estado','Externa','Cada tira interna'],
             [(key,_table_value(outer.get(key)),_table_value(inner.get(key))) for key in keys if key not in ('local_elements','local_basis')],
             [2.35,2.35,2.35],size=8)
        elements=[]
        for piece,data in strips.items():
            for elem in data.get('local_elements',[]):
                elements.append((piece,elem.get('kind',''),_num(elem.get('b_mm'),3),_num(elem.get('t_mm'),3),_num(elem.get('ratio'),6),_num(elem.get('limit'),6),_num(elem.get('beff_mm'),6)))
        _tab(doc,['Peça','Tipo','b mm','t mm','b/t','Limite','be mm'],elements,[1.,.6,.8,.8,1.15,1.3,1.4],size=7.8)
        doc.add_paragraph('Base local declarada: '+str(outer.get('local_basis',''))+'.')
    for key in ('scope','qualification_checks','web_ltb','net_web_section','member_hole_flexure','physical_covers','bolts'):
        if key in r:
            doc.add_paragraph(key,style='Heading 2')
            value=r[key]
            values=list(value.items()) if isinstance(value,dict) else [(key,value)]
            if key=='bolts' and isinstance(value,dict):
                values=[(k,v) for k,v in values if k!='physical_groups']
                values += [(f'grupo {index+1}',{k:v for k,v in item.items() if k!='bolts'}) for index,item in enumerate(value.get('physical_groups',[]))]
            _tab(doc,['Campo','Valor'],[(str(k),_table_value(v)) for k,v in values],[1.65,5.4],size=7.7)
    doc.add_paragraph('Referências: ABNT NBR 8800:2024, versão corrigida com Er1:2025; Fakury et al., §10.14.7, páginas 311–320; geometria base M004. Cada fórmula identifica sua referência específica. Esquema e memória não constituem liberação de fabricação.')
    p=doc.add_paragraph();hyperlink(p,BRAND,LINK)
    output=BytesIO();doc.save(output);return output.getvalue()
