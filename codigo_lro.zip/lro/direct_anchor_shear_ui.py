"""Explicit direct-bearing inputs and separate result scopes; no implicit migration."""
from dataclasses import asdict, replace
import streamlit as st
import pandas as pd
from .direct_anchor_shear import DirectAnchorShear, MODEL
from .display_precision import number_input, display_frame
from .models import KGF
from .report import number

METRIC_ANCHORS={f'M{d}':float(d) for d in (16,18,20,22,24,27,30,33,36)}
UNC_ANCHORS={'3/4 in · UNC 10':19.05,'7/8 in · UNC 9':22.225,'1 in · UNC 8':25.4,
             '1 1/8 in · UNC 7':28.575,'1 1/4 in · UNC 7':31.75}
MODEL_LABELS={'welded_washer':'Arruelas soldadas · NBR 6.7.2.5',
              'direct_plate_bearing':'Contato direto placa–chumbador · EN complementar',
              'external':'Resistência externa documentada do grupo'}
STATE_LABELS={'normal_hole_equal':'Distribuição uniforme em furos normais',
              'leading_row':'Linha dianteira no sentido de V',
              'opposite_row_envelope':'Linha oposta · envelope adicional'}
SCOPE_LABELS={'domain':'Domínio e documentação','steel_plate_uls':'ELU da haste e bearing da placa · EN',
              'plate_transfer_scope':'Transferência documental da placa','local_transfer_scope':'Integridade e transferência calculada da placa',
              'aci_components':'Ancoragem · ACI em paralelo','service_scope':'ELS e acomodação',
              'foundation_scope':'Fundação e interface civil'}


def _prefix(prefix=None):return prefix or st.session_state.get('_baseplate_ui_prefix','bp')
def _key(name,prefix=None):return _prefix(prefix)+'_ds_'+name

def direct_selected(prefix=None):
    p=_prefix(prefix);s=st.session_state
    return s.get(p+'_shear_path')=='anchors' and s.get(p+'_anchor_shear_model')=='direct_plate_bearing'


def anchor_choices(legacy, prefix=None, *, include_all=False):
    """Keep imported diameter exact, also when changing back to a legacy route."""
    options=dict(legacy)
    if include_all or direct_selected(prefix):options.update(METRIC_ANCHORS);options.update(UNC_ANCHORS)
    p=_prefix(prefix); label=st.session_state.get(p+'_db_label')
    combined={**legacy,**METRIC_ANCHORS,**UNC_ANCHORS}
    if label in combined:options.setdefault(label,combined[label])
    elif label is not None:
        actual=st.session_state.get(p+'_db')
        if type(actual) in (int,float):options[label]=actual
    return options


def anchor_label(db,legacy):
    options={**legacy,**METRIC_ANCHORS,**UNC_ANCHORS}
    return next((label for label,value in options.items() if abs(db-value)<1e-8),str(db)+' mm · importado')


def seed_direct_shear(config,prefix=None):
    p=_prefix(prefix);data=asdict(config)
    for name,value in data.items():
        st.session_state[_key(name,p)]=float(value) if type(value) in (float,int) else value
    st.session_state['_'+p+'_direct_shear_draft']=data


def restore_direct_shear(connection,prefix=None):
    p=_prefix(prefix);s=st.session_state
    data=s.get('_'+p+'_direct_shear_draft',connection.get('direct_shear',{}))
    for name,default in asdict(DirectAnchorShear()).items():
        value=data.get(name,default)
        s[_key(name,p)]=s.get(_key(name,p),float(value) if type(value) in (float,int) else value)


def direct_shear_from_state(active=None,prefix=None):
    p=_prefix(prefix);s=st.session_state
    defaults=asdict(DirectAnchorShear());old=s.get('_'+p+'_direct_shear_draft',{})
    values={name:s.get(_key(name,p),old.get(name,value)) for name,value in defaults.items()}
    enabled=direct_selected(p) if active is None else active
    if enabled:values['model']=MODEL
    u=DirectAnchorShear(**values)
    s['_'+p+'_direct_shear_draft']=asdict(u)
    return u


def _select(label,name,options,prefix):
    key=_key(name,prefix);options=dict(options)
    value=st.session_state[key]
    if value not in options:options[value]='Valor importado: '+str(value)
    return st.selectbox(label,list(options),key=key,format_func=options.get)


def _axial_washer_changed(prefix):
    st.session_state[prefix+'_anchor_washer_t_label']='Personalizada'


def direct_shear_widgets(prefix=None):
    p=_prefix(prefix);s=st.session_state
    st.markdown('**Contato direto da placa com a haste**')
    if p in ('bp','pp'):
        number_input('Lado da arruela superior axial (mm)',min_value=.1,key=p+'_anchor_washer_side')
        number_input('Espessura da arruela superior axial (mm)',min_value=.1,key=p+'_anchor_washer_t',on_change=_axial_washer_changed,args=(p,))
    st.caption('Método convencional sobre graute curado. Arruela superior somente axial: sem resistência lateral, atrito, chave ou engaste fictício. Diâmetro, material e furo são entradas independentes; selecionar esta rota não os converte.')
    _select('Base documental do material','material_basis',{
        'unspecified':'Não identificada · estudo sem aprovação',
        'EN_structural':'Aço estrutural de norma EN elegível',
        'EN_bolt':'Classe de parafuso de norma EN elegível',
        'EN_rebar':'Aço de armadura de norma EN elegível',
        'ASTM_supplementary':'ASTM A36/UNC · aplicação complementar documentada'},p)
    for name,label in [('material_name','Grau ou classe real da haste'),('material_specification','Norma de material e edição'),
                       ('material_reference','Referência das propriedades e rastreabilidade do produto'),
                       ('material_quality_reference','Fabricação final, qualidade e alongamento documentados')]:
        st.text_input(label,key=_key(name,p))
    for name,label in [('fy','fy real adotado (MPa)'),('fu','fu real adotado (MPa)')]:
        number_input(label,min_value=0.,key=_key(name,p))
    st.caption('Limites iniciais do programa: 235≤fy≤640 e 400≤fu≤800 MPa. Esses valores não certificam produto nem criam equivalência ASTM/EN. Classes EN usuais 4.6–8.8 exigem sua identificação e documentação reais.')
    if s[_key('material_basis',p)]=='ASTM_supplementary':
        _select('Protocolo complementar de material','material_protocol',{'':'Não selecionado','astm_a36_supplementary_v1':'ASTM A36/UNC · protocolo complementar v1'},p)
        st.text_input('Certificação do produto final e fabricação do chumbador',key=_key('certification_reference',p))
        st.text_input('Ductilidade e alongamento do produto final, requisito e base de medida',key=_key('ductility_reference',p))
        st.checkbox('Aceito esta aplicação complementar identificada a ASTM A36/UNC; não declaro equivalência ou conformidade material EN 3.3.',key=_key('supplementary_application_accepted',p))
        st.caption('Exige norma com edição, rastreabilidade, produto final e ductilidade documentados; fy/fu≤0,80. O aceite não preenche dados faltantes. A36 legado permanece estudo. A elegibilidade dúctil ACI é independente.')
    _select('Sistema real da rosca','thread_standard',{'metric':'Métrica','UNC_2A':'UNC ASME B1.1 · Class 2A'},p)
    if s[_key('thread_standard',p)]=='UNC_2A':
        number_input('Fios por polegada da rosca UNC (TPI)',min_value=0.,key=_key('thread_tpi',p))
        st.caption('Domínio: 3/4–10, 7/8–9, 1–8, 1 1/8–7 e 1 1/4–7. Não arredondar diâmetros UNC para métricos.')
    _select('Fabricação real da rosca','thread_manufacture',{'unspecified':'Não identificada','cut':'Cortada','rolled':'Laminada'},p)
    _select('Base da redução da rosca','thread_compliance',{'unspecified':'Não documentada','en1090_verified':'Conformidade EN1090 demonstrada','unverified_cut':'Rosca cortada documentada; redução kthread=0,85'},p)
    _select('Origem da área resistente As','thread_area_source',{'documented':'Área documentada do produto','calculated_asme':'Área calculada ASME para perfil UNC documentado'},p)
    number_input('Área resistente real As (mm²)',min_value=0.,key=_key('thread_area',p))
    st.text_input('Referência da rosca, perfil, dimensões, área e integridade',key=_key('thread_reference',p))
    st.caption('As calculada não é área certificada pelo fabricante. Nenhuma área, passo ou material é inferido apenas da bitola.')
    _select('Base dimensional do furo','hole_basis',{'en_normal_nominal':'Furo normal nominal · EN','supplementary_unc_bounded':'UNC · teto dimensional complementar'},p)
    _select('Tipo real do furo','hole_kind',{'unspecified':'Não definido','normal_round':'Circular normal / circular limitado complementar'},p)
    number_input('Diâmetro real do furo da placa d0 (mm)',min_value=0.,key=_key('hole_diameter',p))
    st.checkbox('Locação, furação, tolerâncias e inspeção preservam o furo efetivamente especificado.',key=_key('normal_hole_tolerance_verified',p))
    st.text_input('Referência da execução e tolerâncias de furação',key=_key('execution_reference',p))
    st.caption('Exige 0<d0−d≤2 mm para d≤24 mm e ≤3 mm acima. Furo alargado, rasgo, escareado, bucha/resina fora do ramo. Um furo existente não é reduzido para passar.')
    st.checkbox('Graute integral e íntegro na transferência',key=_key('grout_complete',p))
    st.checkbox('Graute curado na fase de cálculo',key=_key('grout_cured',p))
    st.checkbox('Sem stand-off, vazios, bolsões ou bainha livre',key=_key('no_free_standoff',p))
    st.text_input('Referência do graute e condições de assentamento',key=_key('grout_reference',p))
    st.caption('Domínio inicial: 0<tg≤40 mm e fck,graute≥max(fck,concreto;30 MPa). A fase antes da cura não é aprovada; F2 não significa momento da haste nulo.')
    st.checkbox('Carregamento estático, sem impacto, fadiga ou vibração significativa',key=_key('static_loading',p))
    number_input('Torção aplicada em torno de z (N·mm; fora do domínio se não nula)',key=_key('torsion_z',p))
    _select('Requisito de serviço','service_slip_requirement',{
        'ordinary_bearing':'Bearing ordinário · acomodação permitida',
        'no_slip':'Sem deslizamento · fora desta rota',
        'numeric_total_limit':'Limite numérico total · exige modelo de ELS próprio'},p)
    if s[_key('service_slip_requirement',p)]=='numeric_total_limit':
        number_input('Limite total de deslocamento exigido (mm)',min_value=0.,key=_key('service_total_limit',p))
    st.caption('d0−d é folga geométrica diametral, não deslocamento total nem limite superior. O app não calcula δtotal nem promete deslizamento zero. Integridade/transferência da placa e todos os modos ACI aplicáveis permanecem verificações separadas.')


def direct_shear_results(c,r):
    if not getattr(c,'direct_anchor_shear',False):return
    data=r.geometry.get('direct_anchor_shear',{})
    with st.expander('Contato direto · domínios, ELU, ACI e serviço',expanded=True):
        if not data:
            st.warning('Contato direto sem resultado: corrija os dados; nenhuma aprovação inferida.')
            return
        st.write('A rota resistente atende ao escopo calculado.' if data.get('direct_route_resistance_pass') else 'Rota direta não aprovada: conferir falhas, domínio e pendências abaixo.')
        st.caption('EN γM2=1,25; NBR γa2=1,35; ACI φ próprio. Não se somam capacidades nem se misturam fatores. Fundação e armaduras não são aprovadas por um resultado de componente.')
        for key,label in SCOPE_LABELS.items():
            item=data.get(key,{})
            st.write(label+': '+str(item.get('status','não calculado')))
            for reason in item.get('reasons',[]):st.caption(reason)
            if item.get('reason'):st.caption(item['reason'])
        material=data.get('material',{})
        local=data.get('local_transfer_scope',{})
        if local.get('panel'):
            if local['panel'].get('method')=='p398_external_nominal_v1':
                st.caption('P398 externo: composição nominal, cortes reais NBR/EN e envelope opcional de placa basal robusta. '
                           'Não é exigência normativa geral nem prova T⇒V; sem retirar benefício N/M das nervuras. Fora do envelope não significa falha física.')
            else:
                st.caption('Tipo2 P358: hp real da fonte da alma, bruto/líquido/bloco/flexão no plano e prefixos por estado. '
                       'γM0,placa=1,00; γM2,placa=1,25. Limites suficientes não são prova isolada de ruptura da placa real.')
            st.json(local['panel'])
        if data.get('normal_and_axial_scope',{}).get('axial_washer_complete') is False:
            st.warning('Arruela/porca superior: transferência axial local não calculada nesta composição simples. A arruela não recebe crédito lateral.')
        st.caption('Material: '+str(material.get('qualification_status','study_unqualified'))+' · '+str(material.get('name',c.direct_shear.material_name)))
        values=data.get('resistances',{})
        if values:
            st.write('Por haste: F1='+number(values.get('F1_N',0.)/KGF)+' kgf; F2='+number(values.get('F2_N',0.)/KGF)+' kgf; VRd=min(F1,F2)='+number(values.get('shear_Rd_N',0.)/KGF)+' kgf; TRd='+number(values.get('tension_Rd_N',0.)/KGF)+' kgf.')
            st.caption('kthread='+number(values.get('kthread',0.))+'; βLf='+number(values.get('beta_Lf',0.))+'. Efeito local/flexão do graute considerados implicitamente na resistência reduzida; momento individual não calculado.')
        for state in data.get('states',[]):
            st.markdown('**'+STATE_LABELS.get(state['id'],state['id'])+' · '+str(state.get('status','pendente'))+'**')
            if state.get('diagnostic_only'):st.warning('Estudo diagnóstico fora do domínio: um índice favorável não constitui aprovação.')
            st.caption(state.get('basis','')+' Cada estado recebe V integral e as mesmas trações concomitantes, inclusive prying aplicável. Estados alternativos: nunca simultâneos ou somados.')
            st.dataframe(display_frame(pd.DataFrame([{'Barra':rod['id'],'x mm':rod['x'],'y mm':rod['y'],
                'Ti kgf':rod['tension']/KGF,'Qi kgf':rod['shear']/KGF,'Ativa em corte':rod['credited_to_shear']} for rod in state.get('rods',[])])),hide_index=True,width='stretch')
            st.caption('ΣQi='+number(state.get('sum_shear_N',0.)/KGF)+' kgf; resíduo força='+number(state.get('residual_force_N',0.))+' N; resíduo torção='+number(state.get('residual_torsion_Nmm',0.))+' N·mm. Coleção convencional, não solver nem envoltória de todo contato possível.')
        for record in data.get('aci_components',{}).get('states',[]):
            sid=record.get('direct_state_id','Estado ACI')
            st.markdown('**ACI independente · '+STATE_LABELS.get(sid,sid)+'**')
            for mode,details in record.get('modes',{}).items():
                st.write(mode+': '+str(details.get('status','pendente')))
                for reason in details.get('reasons',[]):st.caption(str(reason))
            st.caption('Fatores ACI próprios; todas as Ti mantidas, inclusive nas hastes inativas ao corte. Pryout usa o conjunto ativo. Estes estados não se somam.')
        for reason in dict.fromkeys(data.get('reasons',[])+data.get('pending_reasons',[])):st.warning(reason)
