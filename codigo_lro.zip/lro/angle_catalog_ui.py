"""Shared Streamlit selection; updates only after an explicit catalog change."""
import streamlit as st

from .angle_catalog import catalog, get_angle, label

MANUAL = 'Manual / projeto importado'


def draft_keys(prefix):
    return [prefix + 'angle_catalog_previous', prefix + 'angle_manual_snapshot', prefix + 'angle_show_small']


def reset(prefix):
    """Call only after a complete import/example has been accepted."""
    s = st.session_state
    s[prefix + 'angle_catalog_previous'] = s.get(prefix + 'angle_catalog_id', '')
    s.pop(prefix + 'angle_manual_snapshot', None)
    s[prefix + 'angle_show_small'] = False


def _geometry_fields(axial):
    return (('leg', 't', 'Ag', 'ec', 'root_radius', 'profile_name', 'profile_source') if axial
            else ('beam_leg', 'support_leg', 't', 'root_radius'))


def changed(prefix, area_factor=1, axial=False):
    s = st.session_state
    identity = s[prefix + 'angle_catalog_id']
    previous = s.get(prefix + 'angle_catalog_previous', '')
    if identity and not previous:
        s[prefix + 'angle_manual_snapshot'] = {key: s[prefix + key] for key in _geometry_fields(axial)}
    if identity:
        record = get_angle(identity)
        if record is None:
            return
        dimensions = {'t': record['t'], 'root_radius': 0.}
        if axial:
            dimensions.update(leg=record['leg'],
                              Ag=area_factor * record['Ag'] if record['Ag'] is not None else 0.,
                              ec=record['centroid'] if record['centroid'] is not None else 0.,
                              profile_name=('2 × ' if area_factor == 2 else '') + record['name'],
                              profile_source=record['source'])
        else:
            dimensions.update(beam_leg=record['leg'], support_leg=record['leg'])
        for key, value in dimensions.items():
            s[prefix + key] = value
    else:
        snapshot = s.get(prefix + 'angle_manual_snapshot', {})
        for key, value in snapshot.items():
            s[prefix + key] = value
        if axial and not snapshot:
            # Imported catalog projects have no earlier manual draft. Keep the
            # actual numbers, but detach producer/source claims on manual edit.
            s[prefix + 'profile_name'] = 'Cantoneira manual personalizada'
            s[prefix + 'profile_source'] = 'Entrada manual; geometria e propriedades a documentar pelo responsável.'
    s[prefix + 'angle_root_source'] = ''
    s[prefix + 'angle_root_confirmed'] = False
    s[prefix + 'angle_catalog_previous'] = identity


def render_selector(prefix, area_factor=1, axial=False):
    s = st.session_state
    key = prefix + 'angle_catalog_id'
    s.setdefault(prefix + 'angle_catalog_previous', s.get(key, ''))
    s.setdefault(prefix + 'angle_show_small', False)
    include_small = st.checkbox('Incluir cantoneiras menores que 2½ pol.', key=prefix + 'angle_show_small')
    options = [''] + [identity for identity, record in catalog().items()
                       if include_small or record['leg'] >= 63.5 or identity == s.get(key)]
    if s.get(key, '') not in options:
        options.append(s[key])
    identity = st.selectbox('Perfil de cantoneira · catálogo Gerdau', options, key=key,
                            format_func=lambda value: label(value) if value else MANUAL,
                            on_change=changed, args=(prefix, area_factor, axial))
    if not identity:
        st.caption('Entrada manual: dimensões e propriedades do projeto são preservadas. '
                   'Selecionar Gerdau carrega os valores métricos da tabela e mantém o aço escolhido.')
        return
    record = get_angle(identity)
    if record is None:
        st.error('Perfil de catálogo não reconhecido. Nenhuma dimensão foi substituída.')
        return
    st.caption(record['source'] + '. Aço selecionado separadamente. '
               'Catálogo geométrico não amplia o domínio resistente da ligação.')
    for flag in record.get('review_flags', []):
        st.warning('Observação da tabela Gerdau: ' + str(flag))
    if (s[prefix + 'root_radius'] <= 0 or not s[prefix + 'angle_root_confirmed']
            or not s[prefix + 'angle_root_source'].strip()):
        st.warning('Raio interno não publicado pela Gerdau. O campo começa em 0 apenas como pendência, '
                   'sem aprovação: informe o raio real, uma fonte independente e confirme abaixo.')
    else:
        st.caption('Raio interno: declaração independente confirmada, sem atribuição ao catálogo Gerdau.')
    st.number_input('Raio interno real · declaração independente (mm)', min_value=0., key=prefix + 'root_radius', format='%.3f')
    st.text_input('Fonte independente do raio interno · documento/medição', key=prefix + 'angle_root_source')
    st.checkbox('Confirmo o raio interno manual para este perfil e sua fonte independente', key=prefix + 'angle_root_confirmed')
    if s.get(prefix + 'angle_manual_snapshot'):
        st.caption('Voltar a Manual restaura os últimos valores manuais, sem alterar o aço.')
