"""Editable Word sections for explicitly selected anchorage and column-weld components."""
from .models import KGF
from .report import table,number,_math,group
from .concrete_components import bearing_signature,distribution_signature

LABELS={'head_mechanical':'Apoio enterrado mecânico','pullout':'Pullout','sideface':'Ruptura lateral',
        'breakout':'Ruptura ao cortante','pryout':'Pryout','aci_steel':'Aço ACI','interaction':'Interação ACI dos estados enumerados'}


def append_component_report(doc,c,r,detailed=False):
    u=c.concrete_components
    if u.model!='off':
        doc.add_page_break();doc.add_paragraph('Ancoragem ACI por modos de ruptura',style='Heading 1')
        doc.add_paragraph('Verificações complementares ACI 318-19 e DG1, separadas dos coeficientes NBR. Concreto normal fissurado, ações já de cálculo. A triagem favorável dos modos disponíveis não aprova a ancoragem, as peças locais, o bloco armado ou a fundação.')
        demands=r.concrete_components.get('component_demands',{})
        va=demands.get('V_anchor',c.V)
        rows=[('Cortante na face superior',number(c.V/KGF,3)+' kgf'),
              ('Cortante nos chumbadores','Pendente de modelo físico' if va is None else number(va/KGF,3)+' kgf'),
              ('Caminho do cortante',c.shear_path)]
        modes=r.concrete_components.get('modes',{})
        if modes.get('pullout',{}).get('status')!='not_demanded':
            rows += [('Área efetiva de apoio Abrg',number(u.bearing_area,3)+' mm²'),
              ('Fonte da área',u.bearing_area_ref or 'Não informada'),
              ('Qualificação da área/detalhe','Vinculada ao detalhe atual' if u.bearing_confirmation==bearing_signature(c) else 'Pendente ou invalidada'),
              ('Resistência mecânica por barra',number(u.mechanical_resistance/KGF,3)+' kgf; '+(u.mechanical_ref or 'fonte pendente'))]
        if modes.get('aci_steel',{}).get('status')!='not_demanded':
            rows += [('Área efetiva de aço Ase,N',number(u.area_tension,3)+' mm²; '+(u.steel_area_ref or 'fonte pendente')),
              ('Ductilidade ACI','Com referência '+u.ductility_ref if u.ductile else 'Não comprovada: fatores conservadores do ramo não dúctil')]
        if va not in (None,0.):
            rows += [('Área efetiva de aço Ase,V',number(u.area_shear,3)+' mm²'),
              ('Distribuição do cortante',u.distribution_ref or 'Não qualificada'),
              ('Qualificação da distribuição','Vinculada à combinação/detalhe atual' if u.distribution_confirmation==distribution_signature(c) else 'Pendente ou invalidada'),
              ('Bordas paralelas','Construção perpendicular virtual ACI' if u.parallel_model=='virtual_perpendicular' else 'Pendentes'),
              ('Envelope suplementar de linhas','Selecionado' if u.optional_envelope else 'Não selecionado')]
        table(doc,['Entrada','Dado efetivamente usado'],rows,[2.35,4.6])
        shear=r.concrete_components.get('shear_details',{})
        if shear.get('rods'):
            table(doc,['Barra','x / y em mm','Tração em kgf','Cortante em kgf'],[
                (rod['id'],number(rod['x'],3)+' / '+number(rod['y'],3),number(rod['tension']/KGF,3),number(rod['shear']/KGF,3))
                for rod in shear['rods']],[.65,2.4,1.95,1.95])
            doc.add_paragraph(('Cortante nulo pelo caminho exclusivo selecionado. ' if va==0 else 'Forças simultâneas efetivas documentadas. ')+'Os casos de ruptura por borda são mecanismos alternativos; suas forças virtuais não são adicionadas ao vetor físico. Quando esta distribuição é válida, cada Vi também é comparado à capacidade NBR da mesma barra, além da soma do grupo.')
        doc.add_paragraph('Conversões usadas nas expressões ACI de unidades US: 1 pol.=25,4 mm; 1 psi=0,006894757293168361 MPa; 1 lbf=4,4482216152605 N. Os valores finais e intermediários são convertidos de forma consistente.')
        for name,mode in r.concrete_components.get('modes',{}).items():
            doc.add_paragraph(LABELS.get(name,name),style='Heading 2')
            equations={
                'pullout':['φNp = 0,70 × 8 Abrg fc'],
                'sideface':['Nsb,base = 160 c1 √Abrg √fc', 'φNsb = 0,70 α Nsb,base',
                            'αgrupo = 1+s/(6c1)', 'αcanto = min[1;(1+c2/c1)/4]'],
                'breakout':['φVcb = 0,70 (AVc/AVco) ψec,V ψed,V ψh,V kpar Vb',
                            'AVco = 4,5 c1,calc²', 'Vb = min(Vb1; Vb2)',
                            'Vb1 = 7 (ℓe/db)^0,2 √db √fc c1^1,5', 'Vb2 = 9 √fc c1^1,5'],
                'pryout':['φVcp = 0,70 kcp Ncp'],
                'aci_steel':['φNsa = φN Ase,N futa', 'φVsa = φV × 0,6 Ase,V futa × 0,8',
                             'futa = min[fu; 1,9fy; 125000 psi]'],
            }
            for equation in ([] if mode.get('status') in ('not_applicable','not_demanded') else equations.get(name,[])):
                if name=='aci_steel' and va==0 and 'φVsa' in equation:continue
                _math(doc,group(equation))
            if name=='pullout':doc.add_paragraph('Expressão em N, mm² e MPa.')
            elif name in ('sideface','breakout'):
                doc.add_paragraph('As expressões básicas Nsb,base e Vb usam dimensões em polegadas, fc em psi e resultado em lbf, antes da conversão para N. Os fatores geométricos permanecem adimensionais.')
            elif name=='pryout':doc.add_paragraph('kcp=1 para hef<2,5 pol.; caso contrário, 2. Ncp usa o cone do conjunto ativo de cisalhamento deste estado, com suas excentricidades e bordas.')
            elif name=='aci_steel':doc.add_paragraph('O fator 0,8 refere-se à base sobre graute. Áreas efetivas e ductilidade são dados documentados; não são presumidos pelo diâmetro nominal.')
            real=[ck for ck in mode.get('checks',[]) if not ck.get('diagnostic_only')]
            failed=any(ck.get('ratio',0)>1+1e-10 for ck in real) or mode.get('numerical_screen_passes') is False
            status='NÃO ATENDE aos resultados calculados' if failed else {'calculated':'Resultados calculados atendem','verified':'Comprovação documentada atende','not_demanded':'Sem solicitação','not_applicable':'Não aplicável no domínio verificado'}.get(mode.get('status'),'PENDENTE')
            doc.add_paragraph(status)
            if mode.get('applicability_note'):doc.add_paragraph(mode['applicability_note'])
            for reason in mode.get('reasons',[]):doc.add_paragraph(str(reason))
            if mode.get('checks'):
                table(doc,['Barras ou mecanismo','Sd kgf','Rd kgf','Índice','Base'],[
                    (','.join(ck.get('ids',[])),number(ck['demand']/KGF,3),number(ck['resistance']/KGF,3),number(ck['ratio'],3),
                     'Diagnóstico sem conclusão' if ck.get('diagnostic_only') else ck.get('method','ACI')) for ck in mode['checks']],
                    [1.6,1.,1.,.7,2.65])
            if name=='interaction' and 'beta_N' in mode:
                _math(doc,group('βN = ',number(mode['beta_N'],6),'; βV = ',number(mode['beta_V'],6),'; ηparcial = ',number(mode['ratio'],6)))
                for state in mode.get('states_summary',[]):
                    doc.add_paragraph(state['label']+': forças [N] '+str(state['forces'])+'; índice='+number(state['ratio'],6))
                doc.add_paragraph('βN e βV são os maiores índices dos modos aplicáveis, sempre com demanda e resistência do mesmo grupo ou barra. Quando ambos excedem 0,20, (βN+βV)/1,20 é comparado a 1, além dos limites individuais. Ausências mantêm a interação completa pendente; uma falha numérica conhecida é preservada.')
            if detailed:
                for ck in mode.get('checks',[]):
                    values=[]
                    for key,value in ck.items():
                        if key in ('demand','resistance','ratio','nominal','phi','ca1','ca2','ca1_physical','ca1_calc','spacing','area','area0','le','vb1','vb2','vb','psi_ec','psi_ed','psi_h','parallel_factor','kcp','hef_physical','hcalc','nb','ncp') and type(value) in (int,float):
                            values.append((key,number(value,6)))
                    for key,value in ck.get('factors',{}).items():
                        if type(value) in (int,float):values.append((key,number(value,6)))
                    if values:
                        doc.add_paragraph('Intermediários de '+ck.get('id',name)+': unidades canônicas N, mm e MPa, após conversões explícitas das expressões em pol/psi/lbf.')
                        table(doc,['Parâmetro','Valor'],values,[3.45,3.5])
        doc.add_paragraph('Diagnósticos sem conclusão não entram em verificações aprovadas ou reprovadas nem na interação conclusiva. Peças mecânicas documentadas são comparações próprias; não substituem as resistências ACI dos modos de concreto.')
    w=c.column_weld
    if w.model=='two_flange_normal_web_shear':
        from .column_base_weld_report import append_qualified_weld_report
        append_qualified_weld_report(doc,c,r,detailed)
    elif w.model!='off':
        doc.add_page_break();doc.add_paragraph('Solda pilar placa por faixas de tração pura',style='Heading 1')
        out=r.local_column_weld
        doc.add_paragraph('Submodelo DG1 de quatro faixas de 45° da base Tipo 2, N<0 e M=V=0 na face superior. Resistências locais de solda e metal-base conforme NBR. Não é campo geral de solicitações de uma placa flexível sob N/M/V.')
        table(doc,['Entrada','Especificação'],[
            ('Aço do pilar',w.column_steel),('Processo',w.process),('Comprimento real da alma',number(w.web_length,3)+' mm'),
            ('Detalhe íntegro confirmado','Sim' if w.detail_confirmed else 'Pendente'),('Procedimento',w.procedure_ref or 'Pendente'),
            ('CJP e inspeção',w.cjp_detail+'; '+(w.inspection_ref or 'não informada')),
            ('Tenacidade metal de solda / metal-base',('Confirmada' if w.cjp_charpy_confirmed else 'Não confirmada')+' / '+('Confirmada' if w.base_charpy_confirmed else 'Não confirmada')),
        ],[2.35,4.6])
        doc.add_paragraph({'pass':'Componentes locais calculados atendem','fail':'Há componente local que não atende'}.get(out.get('status'),'PENDENTE'))
        for reason in out.get('reasons',[]):doc.add_paragraph(str(reason))
        if out.get('b_eff_mm') is not None:
            _math(doc,group('Ti = −N/4; e = (a2 − tw)/2; beff = 2e; qz = Ti/beff; σalma = 2qz/tw'))
            table(doc,['Resultado local','Valor'],[(key,number(out[key],6)) for key in
                ('e_mm','b_eff_mm','span_mm','T_per_rod_N','q_normal_one_face_N_per_mm','web_normal_line_N_per_mm','web_stress_MPa','t_plate_plastic_req_mm')],[3.85,3.1])
            doc.add_paragraph('Valores em N, mm e MPa. Duas faces carregam uma alma: a tensão da alma é 2qz/tw; CJP usa uma única seção fundida, nunca duas capacidades. Faixas completas devem caber no comprimento real; não se recortam forças nem se substitui beff por l₀ da placa.')
        doc.add_paragraph(out.get('scope','Ligação completa a complementar; o modelo não é aplicável a todos os esforços.'))
