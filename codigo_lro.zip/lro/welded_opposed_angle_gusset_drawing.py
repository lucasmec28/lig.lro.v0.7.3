"""Current-input views of four distinct opposed weld lines and one central gusset."""
from io import BytesIO
from dataclasses import asdict
import hashlib,json,math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Arc
from .welded_double_angle_gusset_drawing import _line,_patch,_n,angle_outline,STATUS,INK,MUTED,PLATE,ANGLE,WELD
from .drawing_annotations import dimension,rendered_wrap
from .welded_opposed_angle_gusset import evaluate,COMPONENT_VERSION
from .welded_opposed_angle_gusset_presentation import selected_angle,angle_identity,angle_detail_disclosure


def input_fingerprint(c):
    try:native=c.to_dict()
    except (ValueError,TypeError,ArithmeticError):native=asdict(c)
    return hashlib.sha256(json.dumps(native,ensure_ascii=False,sort_keys=True,separators=(',',':'),default=str).encode()).hexdigest()


def validated_result(c,result=None):return evaluate(c)

def approved(r):return r.get('local_pass') is True and r.get('geometry',{}).get('valid') is True


def figure(c,result=None):
    r=validated_result(c,result);g=r.get('geometry') or {};a=selected_angle(c,r)
    fig=plt.figure(figsize=(14,12),facecolor='white')
    fig._welded_opposed_angle_gusset_result=r
    fig._welded_opposed_angle_gusset_fingerprint=input_fingerprint(c)
    def text(x,y,value,gid=None,**kw):
        obj=fig.text(x,y,value,color=kw.pop('color',INK),**kw)
        if gid:obj.set_gid(gid)
    text(.035,.965,'DUAS L OPOSTAS SOLDADAS À CHAPA E À MESA W',fontsize=16,fontweight='bold')
    text(.035,.935,rendered_wrap('Projeto: '+c.project,1200,9),'current_project',fontsize=9,va='top')
    text(.035,.895,STATUS.get(r['status'],r['status']),'engine_status',fontsize=11,fontweight='bold',color=INK if approved(r) else WELD)
    text(.035,.872,'N total='+_n(c.N,1000)+' kN; por L='+_n(c.N,2000)+' kN. '+angle_identity(a,c.angle_profile),'actual_actions',fontsize=9)
    text(.035,.851,'Apoio: '+('viga W' if c.support_member=='beam' else 'pilar W')+'; eixos locais s/n acompanham o membro. Resultado local, sem liberação de fabricação.',fontsize=8.5)
    if not g.get('valid') or c.topology!='opposed_vertices' or c.interface!='welded':
        text(.05,.76,'ENTRADA SEM GEOMETRIA QUALIFICADA','diagnostic_only',fontsize=14,fontweight='bold',color=WELD)
        text(.05,.70,rendered_wrap('\n'.join(x['message'] for x in r['issues']),1050,11),fontsize=11,va='top')
        text(.035,.03,COMPONENT_VERSION+' · SHA-256: '+input_fingerprint(c),'input_fingerprint',fontsize=7)
        return fig
    B,H,t,L=c.plate_width,c.plate_height,c.plate_t,c.weld_length
    b,ta,ec=a['leg'],a['t'],a['centroid'];sw=c.angle_weld_leg
    C,S=g['direction'];u0,u1=-L/2,L/2;free=u0-c.end_margin
    xy=lambda u,v:(c.center_s+u*C+v*S,c.center_n+u*S-v*C)
    elev=fig.add_axes((.035,.425,.57,.385));section=fig.add_axes((.655,.485,.31,.31))
    support=fig.add_axes((.705,.15,.235,.255));plan=fig.add_axes((.035,.245,.57,.12))
    for ax in (elev,section,support,plan):ax.axis('off');ax.set_aspect('equal')
    elev.set_title('Plano da chapa · quatro linhas distintas · dimensões em mm',loc='left',fontsize=10)
    _patch(elev,g['polygon'],'gusset_polygon',facecolor=PLATE,edgecolor=INK)
    W=g['support_catalog'];elev.add_patch(Rectangle((-B/2-25,-W['tf']),B+50,W['tf'],facecolor='#a9b6c2',edgecolor=INK))
    for sign,face,color in ((-1,'face_negative','#d9a568'),(1,'face_positive',ANGLE)):
        v0,v1=sorted([sign*t/2,sign*(t/2+b)])
        _patch(elev,[xy(free,v0),xy(free,v1),xy(u1+65,v1),xy(u1+65,v0)],'connected_leg_'+face,facecolor=color,alpha=.65,edgecolor=INK)
        _line(elev,xy(free,v0),xy(free,v1),'free_end_'+face,color=INK,lw=2)
    for line in g['weld_lines']:
        _line(elev,line['start'],line['end'],'angle_weld_'+line['id'],color=WELD,lw=3)
        # Stagger callouts by line to keep distinct narrow heel welds legible.
        idx=g['weld_lines'].index(line);p=xy((-.38 if idx%2 else .32)*L,line['v'])
        offset=[(-.4*B,.75*H),(-.4*B,.3*H),(.38*B,.82*H),(.4*B,.27*H)][idx]
        elev.annotate(('Talão' if line['location']=='heel' else 'Ponta')+' '+('−z' if line['z']<0 else '+z')+'\n'+_n(c.N*line['force_fraction'],1000)+' kN',xy=p,xytext=offset,textcoords='data',fontsize=7.8,ha='right' if idx<2 else 'left',color=WELD,arrowprops={'arrowstyle':'-','color':WELD},bbox={'facecolor':'white','edgecolor':'none','alpha':.85})
    _line(elev,(-B/2,0),(B/2,0),'root_weld_line',color=WELD,lw=4)
    root_s=g['force_line_root_s'];force=xy(0,0)
    _line(elev,(root_s,0),xy(u1+90,0),'physical_force_line',color=INK,ls='--',lw=1)
    if c.N:
        ar=elev.annotate('',xy=xy(u1+85,0),xytext=xy(u1+12,0),arrowprops={'arrowstyle':'-|>','color':INK,'lw':2});ar.set_gid('actual_force_arrow')
    elev.annotate('N total',xy=xy(u1+88,0),xytext=(8,0),textcoords='offset points',fontsize=9)
    for start,end,gid,label in [(force,(force[0]+110,force[1]),'reference_positive_s','+s · eixo W'),((0,0),(0,65),'reference_positive_n','+n')]:
        ar=elev.annotate('',xy=end,xytext=start,arrowprops={'arrowstyle':'->','color':MUTED,'linestyle':'--'});ar.set_gid(gid)
        elev.text(end[0]+3,end[1]+5,label,fontsize=8,color=MUTED)
    elev.add_patch(Arc(force,65,65,theta1=0,theta2=c.theta_deg,color=INK,gid='brace_angle_arc'))
    elev.text(force[0]+58*math.cos(math.radians(c.theta_deg/2)),force[1]+58*math.sin(math.radians(c.theta_deg/2)),'θ='+_n(c.theta_deg)+'°',fontsize=8,gid='brace_angle_value',bbox={'facecolor':'white','edgecolor':'none','alpha':.8})
    _line(elev,*g['introduction_endpoints'],'local_introduction_section',color='#286644',lw=1.5,ls='-.')
    dimension(elev,(-B/2,-55),(B/2,-55),'B='+_n(B),fontsize=8)
    dimension(elev,(B/2+25,0),(B/2+25,H),'H='+_n(H),fontsize=8,rotation=90)
    elev.text(-B/2,-95,'Quatro filetes L='+_n(L)+'; s='+_n(sw)+'; margem='+_n(c.end_margin)+'; faixa local='+_n(c.introduction_width),fontsize=8)
    elev.set_xlim(-B/2-65,B/2+85);elev.set_ylim(-115,max(H+20,xy(u1+100,0)[1]+25))
    # z horizontal and v vertical: rotating 180° makes the actual >< pair.
    section.set_title('Corte normal ao par · vértices opostos ><',loc='left',fontsize=10)
    section.add_patch(Rectangle((-t/2,-b-t/2-12),t,2*b+t+24,facecolor=PLATE,edgecolor=INK,gid='single_central_gusset_opposed_section'))
    outline=angle_outline(a)
    for sign,face,color in ((-1,'face_negative','#d9a568'),(1,'face_positive',ANGLE)):
        transform=lambda p:(sign*(t/2+p[1]),sign*(t/2+p[0]))
        if outline is not None:_patch(section,[transform(p) for p in outline],'angle_section_'+face,facecolor=color,edgecolor=INK)
        else:
            low,high=ta+.3*(b-ta),b-.2*(b-ta)
            for p,q,id,ls in [((0,0),(b,0),'connected','-'),((0,0),(0,b),'free','-'),((low,ta),(high,ta),'inner_connected','--'),((ta,low),(ta,high),'inner_free','--')]:_line(section,transform(p),transform(q),'nominal_'+id+'_'+face,color=color,lw=2,ls=ls)
            for p in ((ta,ta),(b,ta/2),(ta/2,b)):section.text(*transform(p),'?',color=MUTED,fontsize=8)
        for name,points in [('heel',[(-sw,0),(0,0),(0,sw)]),('toe',[(b,0),(b+sw,0),(b,sw)])]:_patch(section,[transform(p) for p in points],name+'_fillet_section_'+face,facecolor=WELD)
        cg=transform((ec,ec));_line(section,cg,cg,'angle_centroid_'+face,color=INK,marker='+',ms=8)
        section.text(sign*(t/2+.62*b),sign*(t/2+.58*b),'L '+('−z' if sign<0 else '+z')+'\nN/2',fontsize=8,ha='center')
    section.text(0,b+t/2+27,'h=tg='+_n(t)+' mm · derivado',fontsize=8,ha='center',gid='derived_heel_gap')
    section.text(0,-b-t/2-34,'4 filetes; centroides v=±'+_n(t/2+ec)+' mm',fontsize=8,ha='center')
    section.text(0,-b-t/2-49,'b='+_n(b)+'; tL='+_n(ta)+'; ec='+_n(ec),fontsize=8,ha='center')
    if outline is None:section.text(0,-b-t/2-65,'Raios não publicados; contorno nominal',fontsize=7.5,ha='center',gid='unknown_angle_radii')
    section.set_xlim(-b-t/2-20,b+t/2+20);section.set_ylim(-b-t/2-73,b+t/2+43)
    d,bf,tw,tf=(W[k] for k in ('d','bf','tw','tf'));rw=c.root_weld_leg
    support.set_title('Raiz dupla na mesa exterior W',fontsize=10,loc='left')
    _patch(support,[(-bf/2,0),(bf/2,0),(bf/2,-tf),(tw/2,-tf),(tw/2,-d+tf),(bf/2,-d+tf),(bf/2,-d),(-bf/2,-d),(-bf/2,-d+tf),(-tw/2,-d+tf),(-tw/2,-tf),(-bf/2,-tf)],'support_W_section',facecolor='#c1ccd6',edgecolor=INK)
    support.add_patch(Rectangle((-t/2,0),t,65,facecolor=PLATE,edgecolor=INK,gid='gusset_root_section'))
    for sign,name in [(-1,'left'),(1,'right')]:_patch(support,[(sign*t/2,0),(sign*(t/2+rw),0),(sign*t/2,rw)],'root_fillet_'+name,facecolor=WELD)
    _line(support,(0,80),(0,-d-15),'W_web_centerline',color=MUTED,ls='--',lw=.8)
    support.text(-bf/2,-d-40,W['name']+'\n2 filetes s='+_n(rw)+'; chapa t='+_n(t),fontsize=8)
    support.set_xlim(-bf/2-20,bf/2+50);support.set_ylim(-d-70,85)
    lo,hi=-c.support_end_left,c.support_end_right
    plan.set_title('Raiz longitudinal centrada sobre a alma · extremos reais W',fontsize=9,loc='left')
    plan.add_patch(Rectangle((lo,-bf/2),hi-lo,bf,facecolor=PLATE,edgecolor=INK,gid='support_longitudinal_flange'))
    for off,name in [(-t/2,'left'),(t/2,'right')]:_line(plan,(-B/2,off),(B/2,off),'root_weld_'+name+'_face',color=WELD,lw=2)
    dimension(plan,(lo,-135),(-B/2,-135),_n(c.support_end_left-B/2)+' livre',fontsize=8)
    dimension(plan,(-B/2,-135),(B/2,-135),'raiz '+_n(B),fontsize=8)
    dimension(plan,(B/2,-135),(hi,-135),_n(c.support_end_right-B/2)+' livre',fontsize=8)
    plan.set_xlim(lo-40,hi+40);plan.set_ylim(-185,110)
    root=r.get('root') or {}
    text(.035,.207,'Raiz atual: Nnormal='+_n(root.get('N'),1000)+' kN; Vparalelo='+_n(root.get('V'),1000)+' kN; M='+_n(root.get('M'),1e6)+' kN m.','signed_root_actions',fontsize=9)
    text(.035,.183,'M é derivado da linha axial real. Uma chapa B·t; dois filetes na raiz; N integral no apoio.',fontsize=8.5)
    text(.035,.145,'NBR6.1.8.2 / 6.5.2: idealização estática aplicada por L. Binários locais entre face e plano médio',fontsize=8.5)
    text(.035,.124,'são idealizados fora do modelo; não são declarados cancelados ou aprovados como tensões 3D.','planar_idealization',fontsize=8.5)
    text(.035,.097,'Aços: L '+c.angle_steel+'; chapa '+c.gusset_steel+'; W '+c.support_steel+'.',fontsize=8)
    text(.035,.077,'Consumíveis: L–chapa '+c.angle_electrode+'; raiz '+c.root_electrode+'. '+angle_detail_disclosure(a),fontsize=7.1)
    text(.035,.044,rendered_wrap('Fonte L: '+a['source'],1250,6.8),'selected_angle_source',fontsize=6.8)
    text(.035,.025,COMPONENT_VERSION+' · SHA-256: '+input_fingerprint(c),'input_fingerprint',fontsize=7)
    return fig


def image_bytes(c,result=None,fmt='png'):
    if fmt not in ('png','svg'):raise ValueError('Formato não suportado.')
    fig=figure(c,result)
    try:
        out=BytesIO()
        with matplotlib.rc_context({'svg.fonttype':'none'}):fig.savefig(out,format=fmt,dpi=150,metadata={'Creator':'LRO Soluções de engenharia'})
        return out.getvalue()
    finally:plt.close(fig)

def drawing_svg(c,result=None):return image_bytes(c,result,'svg').decode('utf-8')
