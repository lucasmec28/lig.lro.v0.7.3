"""Lossless physical envelopes for two opposed L on one bolted gusset.

No capacities are recalculated here. Force bases distinguish whole-pair checks,
per-L checks, individual single-shear bolts and captured partial row groups.
"""
from collections import OrderedDict
from copy import deepcopy
from .bolted_angle_gusset_presentation import (
    selected_angle, angle_identity, angle_detail_disclosure, angle_transfer,
    _finite, _governors, _status, COMPONENT_LABELS, MECHANISM_LABELS,
    governing_description,
)

MECHANISMS = dict(MECHANISM_LABELS, **{
    'unequal_partial_U_bound':'Caminho parcial ocupado · envelope conservador correlacionado',
    'supplemental_partial_block_bound':'Caminho parcial ocupado · envelope conservador correlacionado',
    'partial_U_bound':'Caminho parcial ocupado · envelope conservador correlacionado',
    'zigzag_net':'Seção líquida em zigue-zague · chapa comum',
    'zigzag_net_rupture':'Seção líquida em zigue-zague · chapa comum',
    'Whitmore_row_yield':'Whitmore por linha · suplemento com t/2',
    'Whitmore_row_net':'Whitmore líquido por linha · suplemento com t/2',
})


def physical_envelopes(result):
    groups=OrderedDict()
    for item in result.get('checks') or []:
        if not isinstance(item,dict):continue
        component=str(item.get('component','unidentified'))
        mechanism=str(item.get('mechanism','unidentified'))
        detail=item.get('details') or {}
        witness=detail.get('witness') or {}
        row=item.get('row',detail.get('row',witness.get('row')))
        row_whitmore='whitmore' in mechanism.lower() and witness.get('load_fraction') == .5
        if row_whitmore and row is None:
            identity=str(witness.get('id',''))
            row=int(identity.split('_')[1]) if identity.startswith('row_') and identity.split('_')[1].isdigit() else identity
        plane=item.get('plane',detail.get('plane')) if component=='bolt' else None
        if component in ('bolt','angle_bearing','gusset_bearing') or mechanism == 'bearing':
            basis='per_physical_bolt';scope='N/(2n) por parafuso e furo; um plano'
        elif component=='angle' and mechanism not in ('tension_yield','tension_rupture'):
            basis='per_angle';scope='Força capturada por L, até N/2'
        elif 'partial' in mechanism.lower() or 'partial' in str(item.get('id','')).lower():
            basis='captured_row';scope='kN/(2n) do grupo realmente capturado'
        elif component=='gusset' and mechanism in ('block','block_shear','block_tearout'):
            basis='captured_group';scope='Força capturada em cada caminho da chapa comum'
        elif component=='gusset' and mechanism in ('normal_net_yield','normal_net_rupture','nominal_perforated_yield','nominal_perforated_rupture'):
            basis='captured_section';scope='Resultantes dos furos capturados em cada seção'
        elif row_whitmore:
            basis='per_row_half_thickness';scope='N/2 por linha; espessura alocada tg/2'
        else:
            basis='total';scope='N total da ligação; chapa e raiz comuns'
        if component=='angle' and basis=='total':scope='N total contra resistência do par; N/2 por L'
        groups.setdefault((component,mechanism,row,plane,basis,scope),[]).append(item)
    out=[]
    for (component,mechanism,row,plane,basis,scope),items in groups.items():
        actual=[r for r in items if r.get('case_id')=='actual' or r.get('case_kind')=='actual']
        maximum,governing=_governors(items);actual_max,actual_governing=_governors(actual)
        label=COMPONENT_LABELS.get(component,component.replace('_',' '))
        if component=='angle':label='Par de cantoneiras · total' if basis=='total' else 'Cantoneira · contato por furo' if basis=='per_physical_bolt' else 'Cantoneira · por L'
        if component=='gusset' and mechanism=='bearing':label='Chapa · contato por furo'
        if component=='angle_pair':label='Par 2L opostas ><'
        if row is not None:label+=' · linha '+str(row)
        if plane is not None:label+=' · plano único'
        identity=component+'__'+mechanism+('__row_'+str(row) if row is not None else '')
        out.append(dict(id=identity,component=component,component_label=label,
            mechanism=mechanism,mechanism_label=(MECHANISMS.get(mechanism,mechanism.replace('_',' '))+(' · suplemento com tg/2' if basis=='per_row_half_thickness' else '')),
            row=row,plane=plane,face=None,load_basis=basis,force_scope=scope,
            units=items[0].get('unit',''),utilization=maximum,adopted_utilization=maximum,
            actual_utilization=actual_max,status=_status(items),actual_status=_status(actual),
            governing=governing,governing_ties=deepcopy(governing),adopted_governing_ties=deepcopy(governing),
            actual_governing=actual_governing,actual_governing_ties=deepcopy(actual_governing),
            governing_ids=[x.get('id') for x in governing],member_ids=[x.get('id') for x in items],members=deepcopy(items)))
    return out


def concise_memory(c,result=None):
    """Plain-text MC, always tied to a fresh current-input evaluation."""
    from .bolted_opposed_angle_gusset_drawing import validated_result, input_fingerprint, STATUS, _n
    r=validated_result(c,result)
    root=r.get('root') or {};g=r.get('geometry') or {};section=selected_angle(c,r) or {}
    lines=[str(c.project), '2L opostas >< parafusadas em chapa única com raiz dupla na mesa W',
        'Estado: '+STATUS.get(r.get('status'),str(r.get('status')))+'; índice governante='+_n(r.get('summary',{}).get('utilization')),
        'Cantoneira: '+angle_identity(section,c.angle_profile)+'; Ag='+_n(section.get('Ag'))+' mm² e ec='+_n(section.get('centroid'))+' mm por L.',
        'N total='+_n(c.N,1000)+' kN; N/2='+_n(c.N/2,1000)+' kN por L; '+str(2*c.n)+' parafusos físicos, um plano por parafuso; N/(2n)='+_n(c.N/(2*c.n),1000)+' kN por parafuso e furo.',
        'Chapa B×H×tg='+_n(c.plate_width)+'×'+_n(c.plate_height)+'×'+_n(c.plate_t)+' mm; θ='+_n(c.theta_deg)+'°; g='+_n(c.gauge)+' mm; h=tg; linhas v=±'+_n(c.plate_t/2+c.gauge)+' mm.',
        'Parafusos '+str(c.bolt)+' d='+_n(c.db)+' mm; passo='+_n(c.pitch)+' mm; furo físico='+_n(c.hole_diameter)+' mm; dedução líquida='+_n(g.get('net_hole_diameter'))+' mm; pega=tg+tL+arruelas.',
        'Materiais independentes: L '+str(c.angle_steel)+'; chapa '+str(c.gusset_steel)+'; W '+str(c.support_steel)+'; raiz '+str(c.root_electrode)+'.',
        'Raiz: dois filetes de '+_n(c.root_weld_leg)+' mm por B; Nn='+_n(root.get('N'),1000)+' kN; Vs='+_n(root.get('V'),1000)+' kN; M='+_n(root.get('M'),1e6)+' kN m.',
        'Mínimo de 45 kN e recomendação de 50% são casos separados, aplicados ao conjunto antes de dividir. N real zero permanece zero.',
        'NBR 8800:2024/Errata 1:2025 e rota convencional DG29 adaptada. Idealização estática 6.1.8.2 por L mantém ec e momentos das linhas; não prova cancelamento físico local fora do plano.',
        'Sinal nominal negativo na introdução perfurada é diagnóstico informativo. Resistências e envelopes materiais continuam obrigatórios. Compressão na raiz ou no ligamento íntegro fica fora deste domínio de tração.',
        'Envelopes locais:']
    for e in physical_envelopes(r):
        lines.append('- '+e['component_label']+' / '+e['mechanism_label']+': η='+_n(e['utilization'])+'; '+e['status']+'; '+e['force_scope']+'.')
    for issue in r.get('issues') or []:lines.append(str(issue.get('severity','Ocorrência'))+': '+str(issue.get('message',issue)))
    lines.extend(['Resultado local não libera fabricação, montagem ou estabilidade global da diagonal, W e estrutura.', 'SHA-256 das entradas: '+input_fingerprint(c)])
    return '\n'.join(lines)
