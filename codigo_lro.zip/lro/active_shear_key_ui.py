"""Interface e estado isolado da idealização por chapas ativas (0.8.4)."""
from .display_precision import display_frame, display_value, number_input
from dataclasses import asdict, fields
import json
import math

import pandas as pd
import streamlit as st

from .active_shear_key import ActiveShearKey
from .models import KGF, STEELS
from .report import number

ACTIVE_PATHS = ('cross_active_plate', 'w_flange_plates')
DEVICE_MODELS = {
    'plate': 'Chapa retangular · verificações locais',
    'cross_active_plate': 'Cruciforme · chapa ativa contínua',
    'w_flange_plates': 'Perfil W/I · duas mesas ativas',
    'external': 'Cruciforme, perfil W ou outro · memória externa',
}
SCOPE_LABEL = 'Verificação local por chapas ativas — idealização de componentes'
SHARING = {
    'unknown_envelope': 'Repartição desconhecida · envelope conservador (padrão)',
    'equal': 'Repartição igual α=0,5 · hipótese explícita',
    'verified_range': 'Repartição ou intervalo verificado · com referência',
}
# Só estes campos alteram a forma das faixas de contato ao longo de y.
_CONTACT_FIELDS = ('b', 'bf', 'secondary_t', 'cross_exclusion_positive',
                   'cross_exclusion_negative', 'tw', 'radius', 'junction_exclusion')
def _prefix(): return st.session_state.get('_baseplate_ui_prefix','bp')+'_ak_'
def _draft(name): return '_'+st.session_state.get('_baseplate_ui_prefix','bp')+'_'+name


def _shape_from_contacts(data):
    contacts = data.get('contact_intervals', {})
    return 'cross_active_plate' if 'P' in contacts else 'w_flange_plates' if 'F+' in contacts else None


def seed_active_key(key, shape=None):
    """Importação/exemplo substitui o rascunho, inclusive campos hoje ocultos."""
    data = asdict(key)
    s = st.session_state
    for field in fields(key):
        value = data[field.name]
        if field.name not in ('radius', 'weld_geometry', 'contact_intervals'):
            s[_prefix() + field.name] = float(value) if type(value) in (int, float) else value
    s[_prefix() + 'has_radius'] = key.radius is not None
    s[_prefix() + 'radius'] = float(key.radius) if key.radius is not None else 0.
    s[_prefix() + 'weld_json'] = json.dumps(key.weld_geometry, ensure_ascii=False, indent=2)
    s[_draft('active_weld_json')] = s[_prefix() + 'weld_json']
    s[_draft('active_key_draft')] = data
    s[_draft('active_key_shape')] = shape if shape in ACTIVE_PATHS else _shape_from_contacts(data)
    if shape == 'w_flange_plates':
        s[_draft('active_w_product')] = key.product


def restore_active_key(connection):
    """Recria widgets ocultos sem apagar a geometria independente da chave."""
    s = st.session_state
    if _draft('active_key_draft') not in s:
        seed_active_key(ActiveShearKey.from_dict(connection.get('active_key', {})), connection.get('shear_path'))
    data = s[_draft('active_key_draft')]
    defaults = asdict(ActiveShearKey())
    for name, default in defaults.items():
        if name in ('radius', 'weld_geometry', 'contact_intervals'):
            continue
        value = data.get(name, default)
        s[_prefix() + name] = s.get(_prefix() + name, float(value) if type(value) in (int, float) else value)
    s[_prefix() + 'has_radius'] = s.get(_prefix() + 'has_radius', data.get('radius') is not None)
    s[_prefix() + 'radius'] = s.get(_prefix() + 'radius', float(data.get('radius') or 0.))
    s[_prefix() + 'weld_json'] = s.get(_prefix() + 'weld_json', s.get(_draft('active_weld_json'), json.dumps(data.get('weld_geometry', {}), ensure_ascii=False, indent=2)))


def _selectbox(label, choices, name, labels=None):
    """Conserva uma seleção importada incompatível para o motor a rejeitar."""
    current = st.session_state.get(_prefix() + name)
    options = list(choices)
    if current not in options:
        options.append(current)
    return st.selectbox(label, options, key=_prefix() + name,
                        format_func=lambda value: (labels or {}).get(value, value) if value in choices else str(value) + ' · fora do escopo')


def _number(label, name):
    # Sem clamps: uma entrada fora do domínio precisa ficar visível e ser rejeitada.
    return number_input(label + ' (mm)', key=_prefix() + name, format='%.2f')


def active_key_widgets(shape, grout):
    if shape == 'cross_active_plate':
        st.session_state[_prefix() + 'product'] = 'fabricated'
    elif st.session_state.get(_draft('active_key_shape')) != shape:
        st.session_state[_prefix() + 'product'] = st.session_state.get(_draft('active_w_product'), 'rolled')
    st.caption(SCOPE_LABEL)
    st.caption('Equações da chapa da NBR 8800 §§6.7.2.4, 6.6.5 e 6.5.5 reutilizadas por analogia. Cruciforme/W não são geometrias expressamente cobertas pela cláusula de chapa única. Pressão uniforme nas faixas expostas; sem redistribuição para a faixa central oculta.')
    _selectbox('Orientação da chave em relação ao V global', ['normal_x', 'rotated_90'], 'orientation',
               {'normal_x': 'V normal à chapa/mesas ativas · direção x', 'rotated_90': 'Chave girada 90° com V global mantido · fora do modelo'})
    _number('Projeção H abaixo da face inferior da placa', 'H')
    st.caption(f'Graute real g={display_value(number(grout, 3))} mm, informado em Concreto e assentamento. Penetração H−g; pressão somente abaixo do graute. A Tabela 18 não substitui esse g nesta rota.')
    if shape == 'cross_active_plate':
        _number('Largura física b da chapa ativa P', 'b')
        _number('Espessura t da chapa ativa P', 't')
        _number('Comprimento total da chapa transversal inativa', 'secondary_length')
        _number('Espessura da chapa transversal inativa', 'secondary_t')
        _number('Obstrução central real c+ na face carregada por V positivo', 'cross_exclusion_positive')
        _number('Obstrução central real c− na face carregada por V negativo', 'cross_exclusion_negative')
        st.caption('P recebe V integral. A chapa transversal permanece no desenho, sem resistência nem enrijecimento creditados. c+/c− incluem espessura transversal, soldas e folgas reais em toda a profundidade; as duas faixas são simétricas em y.')
        product = 'fabricated'
    else:
        product = _selectbox('Produto da chave W/I', ['rolled', 'fabricated'], 'product',
                             {'rolled': 'Perfil laminado', 'fabricated': 'Perfil fabricado com chapas soldadas'})
        st.session_state[_draft('active_w_product')] = product
        for label, name in [('Altura d do perfil na direção x', 'd'), ('Largura física bf das mesas', 'bf'),
                            ('Espessura tw da alma inativa', 'tw'), ('Espessura tf das mesas ativas', 'tf')]:
            _number(label, name)
        if product == 'rolled':
            st.checkbox('Raio real de concordância conhecido e documentado', key=_prefix() + 'has_radius')
            if st.session_state[_prefix() + 'has_radius']:
                _number('Raio real r do perfil laminado', 'radius')
            else:
                st.caption('Sem raio presumido: informe uma exclusão central conservadora e sua fonte. O catálogo do pilar não fornece o raio desta chave.')
        _number('Exclusão central real c_inner nas faces internas', 'junction_exclusion')
        st.caption('c_inner cobre a alma e toda concordância/solda/folga: ≥tw+2r quando r é conhecido. F+ permanece em x positivo e F− em x negativo. V>0: F+ externa e F− interna; V<0: as faces se invertem. A alma tem crédito resistente zero.')
    steel_choices = [name for name, steel in STEELS.items() if (steel.rolled_allowed if product == 'rolled' else steel.plate_allowed)]
    steel = _selectbox('Aço das chapas ativas / perfil da chave', steel_choices, 'steel')
    if steel in STEELS:
        material = STEELS[steel]
        lo, hi = (material.profile_min, material.profile_max) if product == 'rolled' else (material.plate_min, material.plate_max)
        st.caption(f'fy={display_value(number(material.fy))} MPa; fu={display_value(number(material.fu))} MPa. Limites do produto: {display_value(number(lo))} a {display_value(number(hi))} mm; aplicação e espessuras verificadas pelo motor. {display_value(material.source)}')
    st.text_input('Referência da geometria, produto e exclusões de contato', key=_prefix() + 'geometry_ref')
    st.checkbox('Confirmo chapa ativa passante sem corte/rasgo, ou ambas as mesas contínuas até a placa de base.', key=_prefix() + 'continuous')
    st.checkbox('Confirmo concreto preenchendo fisicamente todas as faixas creditadas, inclusive os espaços internos do W.', key=_prefix() + 'concrete_filled')
    st.checkbox('Contato e exclusões uniformes em toda a profundidade g…H.', key=_prefix() + 'contact_full_depth')
    st.caption('Sem furos, recortes, mudanças de espessura ou interrupções nas faixas ativas. Não se credita concreto oculto pela junção. Exclusões variáveis com a profundidade e faixas assimétricas exigem outro modelo.')
    if shape == 'w_flange_plates':
        sharing = _selectbox('Repartição entre as mesas físicas F+ e F−', list(SHARING), 'sharing', SHARING)
        if sharing == 'unknown_envelope':
            st.warning('Envelope padrão: casos alternativos (V,0) e (0,V). Cada mesa é verificada para |V| separadamente; não são duas forças V simultâneas e não há ganho de capacidade por duas mesas.')
        elif sharing == 'equal':
            st.warning('α=0,5 é uma hipótese de engenharia selecionada: supõe restrição comum e engajamento suficiente. Dimensões metálicas iguais não demonstram reações iguais no concreto; as capacidades das faces interna e externa continuam distintas. Não é prescrição da NBR.')
        elif sharing == 'verified_range':
            a, b = st.columns(2)
            with a:
                number_input('α mínimo atribuído à mesa física F+', key=_prefix() + 'alpha_min', format='%.2f')
            with b:
                number_input('α máximo atribuído à mesa física F+', key=_prefix() + 'alpha_max', format='%.2f')
            st.caption('F+=αV; F−=(1−α)V; 0≤αmín≤αmáx≤1. Para repartição exata, use extremos iguais. A repartição permanece nas mesmas mesas quando V muda de sinal.')
            st.text_input('Referência que fundamenta a repartição', key=_prefix() + 'share_ref')
            _selectbox('Sinais de V cobertos pela referência da repartição', ['both', 'positive', 'negative'], 'share_signs',
                       {'both': 'Ambos os sinais', 'positive': 'Somente V positivo', 'negative': 'Somente V negativo'})
        st.caption('O envelope vale apenas para parcelas não negativas entre 0 e V. Forças opostas autoequilibradas, pré-carga, torção e transferência resistente pela alma não são cobertas. Nenhuma capacidade total é obtida somando resistências das mesas.')
    with st.expander('Segmentos reais das soldas de raiz · registro opcional'):
        st.text_area('Geometria de soldas por chapa e face (JSON)', key=_prefix() + 'weld_json', height=170)
        st.caption('Use {} se desconhecida. Formato: {"P":{"positive":[[-120,-10],[10,120]],"negative":[[-120,-10],[10,120]]}}; para W, use F+ e F−. Intervalos em y, em mm. Registre somente trechos reais. Nenhuma resistência de solda é aprovada nesta versão, mesmo com geometria conhecida.')
    st.warning('M e V são ações na face superior da placa, sem incluir previamente V·eV. Mef=M+V·[tp+(H+g)/2] é aplicado uma única vez em qualquer repartição. Sem parcela d/2, sem duplicar V e sem somar ações prescritas de solda ao equilíbrio global.')


def active_key_from_state(shape):
    s = st.session_state
    previous = s[_draft('active_key_draft')]
    data = {field.name: s.get(_prefix() + field.name, previous.get(field.name, getattr(ActiveShearKey(), field.name)))
            for field in fields(ActiveShearKey())}
    data['radius'] = s[_prefix() + 'radius'] if s[_prefix() + 'has_radius'] else None
    data['method'] = 'active_plate_strips_v1'
    data['contact_intervals'] = previous.get('contact_intervals', {})
    if shape in ACTIVE_PATHS and (shape != s.get(_draft('active_key_shape')) or any(data[name] != previous.get(name) for name in _CONTACT_FIELDS)):
        data['contact_intervals'] = {}
    errors = []
    raw = s[_prefix() + 'weld_json']
    s[_draft('active_weld_json')] = raw
    try:
        weld = json.loads(raw, parse_constant=lambda value: (_ for _ in ()).throw(ValueError('Valor não finito: ' + value)))
        if not isinstance(weld, dict):
            raise ValueError('O nível principal precisa ser um objeto JSON.')
        data['weld_geometry'] = weld
    except (ValueError, TypeError) as exc:
        data['weld_geometry'] = previous.get('weld_geometry', {})
        if shape in ACTIVE_PATHS:
            errors.append('Geometria de solda não salva: corrija o JSON antes de exportar. ' + str(exc))
    key = ActiveShearKey(**data)
    # to_dict produz os intervalos canônicos sem confundir largura física e contato.
    if shape in ACTIVE_PATHS:
        try:
            data = key.to_dict(shape)
        except (ValueError, TypeError, KeyError, OverflowError):
            data = asdict(key)
        s[_draft('active_key_shape')] = shape
    else:
        data = asdict(key)
    s[_draft('active_key_draft')] = data
    return key, errors


def _n(value, scale=1.):
    return number(value / scale, 3) if isinstance(value, (int, float)) and math.isfinite(value) else '—'


def active_key_results(c, result):
    """Demandas locais e ações de ligação separadas das verificações pendentes."""
    key = result.geometry.get('active_key')
    if not key:
        return
    st.subheader(key.get('scope_label', SCOPE_LABEL))
    local = key.get('local_pass')
    if local is True:
        st.success('Chapas ativas: ATENDE localmente sob a idealização declarada.')
    elif local is False:
        st.error('Chapas ativas: NÃO ATENDE às verificações locais da idealização.')
    st.write(key.get('sharing_label', 'Chapa ativa P: F=V.'))
    st.warning('Ligação e dispositivo completo PENDENTES: soldas/metal-base/flexão local da base; ruptura do concreto, bordas e grupo; armadura e transferência à fundação; ligação/estabilidade dos componentes inativos. Chumbadores e soldas do pilar mantêm suas verificações e exclusões próprias. O cone de chumbadores não verifica a chave nem sua interação.')
    st.caption('b_steel é largura física; b_contact é contato exposto; b_calc=b_contact são as faixas de aço creditadas. A faixa central permanece desenhada, sem ganho por redistribuição lateral. Não há soma de capacidade de dispositivo ou de concreto.')
    a = result.geometry
    st.write(f"M na face superior={display_value(_n(c.M, KGF * 1000))} kgf·m; zR={display_value(_n(key.get('z_R', a.get('z_R'))))} mm; eV={display_value(_n(key.get('eV', a.get('eV'))))} mm; ΔM={display_value(_n(key.get('delta_M', a.get('delta_M')), KGF * 1000))} kgf·m; Mef={display_value(_n(key.get('M_effective', a.get('M_effective')), KGF * 1000))} kgf·m.")
    plates = key.get('plates', [])
    cases = key.get('allocation_cases', [])
    if cases:
        with st.expander('Casos de repartição das forças reais', expanded=True):
            for index, case in enumerate(cases, 1):
                st.write('Caso ' + str(index) + ': ' + '; '.join(f"{display_value(plate['id'])}={display_value(_n(force, KGF))} kgf" for plate, force in zip(plates, case)) + f'; ΣF={display_value(_n(sum(case), KGF))} kgf.')
            st.caption('Casos alternativos do envelope/intervalo são verificados separadamente. As maiores demandas por mesa na tabela abaixo não constituem necessariamente um mesmo caso simultâneo.')
    rows = []
    for plate in plates:
        rows.append({'Chapa': plate['id'], 'Face carregada / sinal': plate.get('loaded_sign', '—'),
                     'b_steel (mm)': _n(plate.get('b_steel')), 'b_contact (mm)': _n(plate.get('b_contact')),
                     'b_calc (mm)': _n(plate.get('b_calc')), 'F (kgf)': _n(plate.get('force'), KGF),
                     'M raiz (kgf·m)': _n(plate.get('M_root'), KGF*1000),
                     'Contato Rd (kgf)': _n(plate.get('bearing_rd'), KGF), 'Flexão Rd (kgf)': _n(plate.get('bending_rd'), KGF),
                     'Escoamento Rd (kgf)': _n(plate.get('yield_rd'), KGF), 'Ruptura Rd (kgf)': _n(plate.get('rupture_rd'), KGF),
                     't requerido (mm)': _n(plate.get('t_required')), 'Local': 'Atende' if plate.get('local_pass') else 'Não atende'})
    if rows:
        st.dataframe(display_frame(pd.DataFrame(rows)), hide_index=True, width='stretch')
    with st.expander('Contato por sinal e ações prescritas das soldas', expanded=True):
        face_rows = []
        for plate in plates:
            for sign, face in plate.get('faces', {}).items():
                contacts = plate.get('contact_by_sign', {}).get(sign, [])
                face_rows.append({'Chapa': plate['id'], 'Sinal de V': '+' if sign == 'positive' else '−',
                                  'Faixas expostas y (mm)': str(contacts), 'b_contact (mm)': _n(face.get('b_contact')),
                                  'Área de contato (mm²)': _n(face.get('contact_area')),
                                  'Contato Rd / Vw (kgf)': _n(face.get('weld_V', face.get('bearing_rd')), KGF),
                                  'Mw prescrito (kgf·m)': _n(face.get('weld_M'), KGF*1000)})
        if face_rows:
            st.dataframe(display_frame(pd.DataFrame(face_rows)), hide_index=True, width='stretch')
        st.caption('Vw=Rcontato e Mw=Rcontato·zR por chapa e face, mesmo quando superiores à demanda ou à resistência do aço. Ações prescritas por analogia à NBR; não são aplicadas novamente à base. Raiz externa contínua com raiz interna interrompida não é um par de filetes coextensivos de largura integral. Resistência da ligação permanece pendente.')
    st.caption('Método active_plate_strips_v1. Fij=Fi·bj/b_contact; pressão uniforme de g a H; zR=(H+g)/2. Repartição/contacto/continuidade são hipóteses explícitas deste modelo de componentes, não disposições normativas para cruciformes ou perfis W.')
