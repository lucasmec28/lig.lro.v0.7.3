"""Nominal Gerdau U catalog, with explicit missing local geometry.

The manufacturer's PDF table governs 10/12-inch grouping. The nominal
clear envelope below is NOT a published straight-web dimension.
"""
import json
from pathlib import Path
from .models import Profile

CATALOG_PATH=Path(__file__).resolve().parent.parent/'data'/'gerdau_u.json'

def catalog_data():
    return json.loads(CATALOG_PATH.read_text(encoding='utf-8'))

def _name(row):
    # Established local designation uses rounded nominal depth in millimetres.
    return 'U '+str(round(row['d_mm']))+' × '+format(row['mass_kg_per_m'],'g').replace('.',',')

def channel_profiles():
    data=catalog_data()
    source=('Gerdau, Catálogo Perfil I e U, p.2. Dimensões nominais; tf não é mínimo local. '
            'clear=d−2tf é apenas envelope provisório, NÃO T reto publicado. '+data['official_pdf_url'])
    return {_name(r):Profile(_name(r),'U laminado Gerdau',r['mass_kg_per_m'],r['d_mm'],r['bf_mm'],
        r['tw_mm'],r['tf_nominal_mm'],r['d_mm']-2*r['tf_nominal_mm'],r['area_mm2'],source)
        for r in data['rows']}

def catalog_properties(profile):
    """Identify exact catalog geometry/source, not a user-supplied name alone."""
    profiles=channel_profiles()
    if profiles.get(profile.name)!=profile:return None
    row=next(r for r in catalog_data()['rows'] if _name(r)==profile.name)
    return dict(row,ec_mm=row['centroid_x_mm'])


FLANGE_TAPER_SLOPE = 0.1614
FLANGE_TAPER_ASSUMPTION = (
    'Hipótese geométrica autorizada: inclinação linear 16,14% (0,1614 mm/mm); '
    'tf do catálogo assumido como espessura média no balanço livre L=bf−tw. '
    'tmin,nom=tf−0,1614·(bf−tw)/2, em mm, sem arredondamento interno. '
    'É a espessura nominal na ponta idealizada sem arredondamento geométrico, '
    'não mínimo real medido nem garantia de fabricação/tolerâncias do fabricante. '
    'Área e centroide permanecem os publicados no catálogo; não são integrados desta geometria. '
    'T reto entre raízes permanece independente e exige verificação do detalhe real. '
    'O valor nominal alimenta o envelope local do metal-base. Na mesa, o mínimo de filete usa o envelope suficiente conservador Tabela 11(tp); não a ponta. Junta T reta não recebe o teto de borda t ou t−1,5. '
    'A aplicabilidade à peça real deve ser confirmada pelo responsável técnico.'
)

def nominal_flange_tip(profile):
    """Engineering idealization only; retain original published section properties."""
    if catalog_properties(profile) is None:
        raise ValueError('Espessura nominal automática exige perfil exato do catálogo Gerdau.')
    return profile.tf - FLANGE_TAPER_SLOPE * (profile.bf-profile.tw)/2
