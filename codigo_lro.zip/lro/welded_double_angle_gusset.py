"""Symmetric welded 2L-T–single rectangular gusset–exterior W flange.

Explicit physical assembly: N/2 on each identical angle and its two fillets;
full N on the single common gusset, root and W. Reuses the frozen 1L primitive
geometry/section solver without importing its result or approval. No capacity
of a coincident gusset path or root is duplicated. N, mm, MPa, N mm.
"""
from __future__ import annotations
from copy import deepcopy
from dataclasses import asdict, dataclass, fields, replace
import math
from . import welded_angle_gusset as shared
from .angle_catalog import get_angle, catalog, LEGACY_ARCELOR_ID
from .models import finite_real
from . import one_root_compression as compression

MATERIALS, ELECTRODES, SUPPORT_CATALOG = shared.MATERIALS, shared.ELECTRODES, shared.SUPPORT_CATALOG
SUPPORT, ANGLE = shared.SUPPORT, shared.ANGLE
GAMMA_A1, GAMMA_A2, GAMMA_W2 = shared.GAMMA_A1, shared.GAMMA_A2, shared.GAMMA_W2
UNITS = dict(shared.UNITS)
FAMILY = 'Ligação 2L-T–gusset–mesa W · soldada'
CONNECTION_TYPE = 'welded_double_angle_gusset'
LEGACY_COMPONENT_VERSION = '0.9.28-welded-double-angle-gusset-dev'
PRE_CAP_COMPONENT_VERSION = '0.9.37-one-root-compression-dev'
COMPONENT_VERSION = '0.9.39-welded-double-outer-end-dev'
SCOPE = ('Duas cantoneiras laminadas iguais em T simétrico, uma por face da mesma chapa, '
         'talões alinhados e pontas no mesmo sentido no plano. Quatro filetes longitudinais acessíveis, '
         'N total repartido igualmente entre as L. Chapa única de envelope retangular e corte externo perpendicular opcional, raiz dupla na mesa exterior '
         'de W laminado, longitudinal e centrada na alma. Tração ou compressão local condicionada em combinação normal, '
         'sem fadiga, NBR8800:2024/Errata1:2025. Excentricidade e momento reais no plano preservados. '
         'Seções elásticas e faixa local conservadora; compressão exige campo inteiro não positivo e vínculos físicos DG29 Ex5.4 K1,2.')
EXCLUSIONS = [x for x in shared.EXCLUSIONS if not x.startswith('Compressão,')] + ['Fadiga, sismo, ação espacial e ligação direta à alma W exigem outra qualificação.'] + [
    'Somente T simétrico: cantoneiras, aços, soldas e carregamento idênticos nas duas faces.',
    'Cantoneiras opostas pelo vértice (><), parafusos, interface mista e partilha desigual não implementados.',
    'Estabilidade global da diagonal composta, ligações/travamentos intermediários e ações existentes do W fora do escopo.',
]
FACE_IDS = ('face_positive', 'face_negative')
FACE_LABELS = {'face_positive': 'L face +z', 'face_negative': 'L face −z'}
_safe, _issue, _finalize, _exact = shared._safe, shared._issue, compression.finalize, shared._exact
root_actions = shared.root_actions
minimum_fillet = shared.minimum_fillet
block_resistance = shared.block_resistance


@dataclass(frozen=True)
class WeldedDoubleAngleGusset(shared.WeldedAngleGusset):
    project: str = '2L-T100×100×12 → gusset400×300×10 → mesa W · N total100kN'
    topology: str = 'symmetric_T'
    interface: str = 'welded'
    symmetric_load: bool = True
    accessible_both_faces: bool = True
    compression_root_rotation: str = 'unknown'
    compression_root_source: str = ''
    compression_root_stamp: str = ''
    compression_brace_rotation: str = 'unknown'
    compression_brace_source: str = ''
    compression_brace_stamp: str = ''
    compression_receiver_relative: str = 'unknown'
    compression_receiver_source: str = ''
    compression_receiver_stamp: str = ''
    compression_unbraced_length: float = 0.
    compression_flange_rotation: str = 'unknown'
    compression_receiver_interaction: str = 'unknown'
    compression_interaction_source: str = '' 

    @property
    def fixed_assumptions(self):
        result = dict(super().fixed_assumptions)
        result.update(topology='two_identical_angles_opposite_faces_aligned_heels_T_four_fillets_one_gusset_double_root',
            load_transfer='N_total_half_each_angle_aggregate_projected_lines_for_common_gusset',
            out_of_plane='mirrored_external_resultant_and_NBR6.1.8.2_static_double_angle_exception',
            equal_steel_and_geometry_both_faces=True, identical_far_end_loading=True,
            accessible_four_angle_fillets=True, angle_count=2, angle_weld_count=4,
            gusset_count=1, root_weld_count=2, angle_section_area_basis='one_angle',
            force_input_basis='total_pair', minimum_45kN_basis='whole_connection_once',
            recommended_half_basis='half_pair_capacity', root_gusset_depth='min(t,2sroot)',
            root_contact_model='normal_shear_yield_normal_rupture_shear_rupture_envelope',
            W_flange_punch_demand='q_peak/(2tf)')
        if self.N < 0:
            result.update(rupture_envelope='compression_uniform_run_shear_only_Ant0_no_tensile_Ct',
                root_contact_model='compression_shear_yield_and_shear_rupture_no_normal_tensile_rupture',
                recommended_half_basis='requires_real_global_compression_capacity_not_inferred',
                compression_model=compression.MODEL,
                compression_boundary='separate_documented_root_brace_rotation_and_receiver_conditions_no_defaults')
        return result

    def to_dict(self):
        errors = input_errors(self)
        if errors: raise ValueError('; '.join(errors))
        return dict(schema_version=1, connection_type=CONNECTION_TYPE,
            component_version=COMPONENT_VERSION, connection=asdict(self),
            units=dict(UNITS), fixed_assumptions=self.fixed_assumptions)

    @classmethod
    def from_dict(cls, data):
        keys = {'schema_version', 'connection_type', 'component_version', 'connection', 'units', 'fixed_assumptions'}
        if not isinstance(data, dict) or set(data) != keys:
            raise ValueError('Ligação soldada 2L-T: campos nativos ausentes ou desconhecidos.')
        if (type(data['schema_version']) is not int or data['schema_version'] != 1
                or data['connection_type'] != CONNECTION_TYPE or data['component_version'] not in (COMPONENT_VERSION, PRE_CAP_COMPONENT_VERSION, LEGACY_COMPONENT_VERSION)):
            raise ValueError('Família ou versão soldada 2L-T incompatível; não se converte 1L silenciosamente.')
        raw = data['connection']
        field_names = {f.name for f in fields(cls)}
        if data['component_version'] != COMPONENT_VERSION:
            legacy_names=field_names-set(shared.outer.WELDED_FIELDS)
            if data['component_version']==LEGACY_COMPONENT_VERSION:legacy_names-=set(compression.FIELDS)
            if not isinstance(raw,dict) or set(raw)!=legacy_names:raise ValueError('Campos legados incompletos ou híbridos; corte externo não é presumido.')
            raw=dict(raw,gusset_end_shape='original',gusset_weld_end_distance=0.)
        if data['component_version'] == LEGACY_COMPONENT_VERSION:
            if not isinstance(raw, dict) or set(raw) != field_names - set(compression.FIELDS):
                raise ValueError('Campos legados 0.9.28 incompletos ou híbridos; nenhum vínculo de compressão presumido.')
            defaults = cls()
            raw = dict(raw, **{k:getattr(defaults,k) for k in compression.FIELDS})
        if not isinstance(raw, dict) or set(raw) != field_names:
            raise ValueError('Campos da ligação 2L-T incompletos ou desconhecidos.')
        candidate = cls(**raw)
        canonical = candidate.to_dict()
        expected_assumptions = replace(candidate,N=0.).fixed_assumptions if data['component_version']==LEGACY_COMPONENT_VERSION else canonical['fixed_assumptions']
        if not _exact(data['units'], canonical['units']) or not _exact(data['fixed_assumptions'], expected_assumptions):
            raise ValueError('Unidades ou premissas 2L-T incompatíveis; nenhuma conversão silenciosa.')
        return candidate


def input_errors(c):
    if not isinstance(c, WeldedDoubleAngleGusset): return ['Entrada deve ser WeldedDoubleAngleGusset.']
    errors = shared.input_errors(c)
    for key in ('compression_root_rotation','compression_brace_rotation','compression_receiver_relative'):
        if getattr(c,key) not in compression.STATUSES: errors.append(key+': estado deve ser unknown, confirmed ou absent.')
    if c.compression_flange_rotation not in ('unknown','restrained','free'): errors.append('compression_flange_rotation: estado inválido.')
    if c.compression_receiver_interaction not in ('unknown','isolated','interactive'): errors.append('compression_receiver_interaction: estado inválido.')
    if finite_real(c.compression_unbraced_length) and c.compression_unbraced_length<0:errors.append('compression_unbraced_length: use zero para não informado ou comprimento positivo real.')
    return errors


def presets():
    c = WeldedDoubleAngleGusset()
    return {
        '2L-T soldada · N total100kN': c,
        '2L-T compressão · SRC1 −200kN · falha e vínculos pendentes': replace(c, N=-200000., project='SRC1 · compressão −200kN · mesma geometria, vínculos desconhecidos'),
        '2L-T soldada · N total200kN · falha da chapa comum': replace(c, project='2L-T · N total200kN · falha da chapa comum', N=200000.),
        '2L-T Gerdau · L63,5×6,35 · borda reforçada': replace(c, project='2L-T Gerdau63,5×6,35 · N total100kN · borda reforçada',
            angle_profile='GERDAU_EQUAL_ANGLE_P03_R25', angle_steel='ASTM A36', angle_weld_edge_detail='reinforced'),
        '2L-T soldada · pilar W · N total100kN': replace(c, project='2L-T → pilar W · N total100kN', support_member='column'),
        '2L-T soldada · N real zero / candidato total45kN': replace(c, project='2L-T · N real zero · mínimo total45kN', N=0.),
        '2L-T soldada · θ90° · N total100kN': replace(c, project='2L-T · θ90° · N total100kN', theta_deg=90.),
        '2L-T soldada · θ135° alinhado · N total45kN': replace(c, project='2L-T · θ135° · N total45kN', N=45000.,
            theta_deg=135.,plate_width=600.,plate_height=200.,center_s=-50.801515190165006,
            center_n=80.5,weld_length=65.,end_margin=20.,root_weld_leg=6.),
    }


def _physical_geometry(c, g):
    """Expose four physical fillets but retain the two aggregated projections."""
    g['projected_weld_lines'] = deepcopy(g['weld_lines'])
    g['weld_lines'] = []
    g['angles'] = []
    for face, sign in zip(FACE_IDS, (1., -1.)):
        g['angles'].append(dict(id=face, face=face, label=FACE_LABELS[face],
            z_sign=sign, connected_surface_z=sign*c.plate_t/2,
            section=deepcopy(g['angle_section']), load_fraction=.5,
            heel_aligned=True, toe_direction='same_positive_v',
            contour_model=g['angle_section']['resistance_model']))
        for line in g['projected_weld_lines']:
            item=deepcopy(line)
            item.update(id=line['id']+'_'+face, location=line['id'], face=face,
                z=sign*c.plate_t/2, force_fraction=line['force_fraction']/2,
                force_fraction_of_angle=line['force_fraction'], load_basis='total_pair')
            g['weld_lines'].append(item)
    g.update(topology=c.topology, angle_count=2, angle_weld_count=4, root_weld_count=2,
             gusset_count=1, gusset_root_area=c.plate_width*c.plate_t,
             pair_gross_area=2*g['angle_section']['Ag'], out_of_plane_resultant_moment=0.)
    if g['fabrication_notes']:
        g['fabrication_notes']=[n+' Executar e inspecionar nas duas cantoneiras e nas duas faces.' for n in g['fabrication_notes']]
    return g


def _face_path(path, face):
    p=deepcopy(path)
    p.update(id=p['id']+'_'+face, name=p['name']+' · '+FACE_LABELS[face],
             face=face,load_basis='per_angle')
    if 'note' in p:
        if 'demanda N integral' in p['note']:
            p['note'] = p['note'].replace('demanda N integral', 'demanda integral da cantoneira desta face (N/2 do par)')
        else:
            p['note'] += ' Demanda N/2 da cantoneira desta face.'
    return p


def _calculate_case(c,g,N,case,label,out,materials):
    """Assemble physical face checks and a single full-force shared load path.

    Two independent calls to pure primitive calculation routines, not evaluate:
    no prior global_pass, cached result, or doubled shared resistance is reused.
    Common sections/paths/root/W are solved with total N. Face contacts consume
    N/2, including each surface-adjacent gusset longitudinal-weld contact.
    """
    common=dict(checks=[],cases=[],issues=[],geometry=deepcopy(g))
    face_result=dict(checks=[],cases=[],issues=[],geometry=deepcopy(g))
    shared._calculate_case(c,g,N,case,label,common,materials)
    shared._calculate_case(c,g,N/2,case,label,face_result,materials)
    # Common geometry/sign issues are authoritative; N/2 adds no new topology.
    out['issues'].extend(common['issues'])
    def face_check(row):
        return row['component'] in ('angle','angle_weld') or (row['component']=='gusset' and row['mechanism']=='longitudinal_substrate')
    for row in common['checks']:
        if not face_check(row):
            row=deepcopy(row);row['load_basis']='total_pair'
            row['label'] += ' · N total do par'
            out['checks'].append(row)
    # Each member is an actual distinct angle or face contact, not capacity sum.
    for face in FACE_IDS:
        for source in face_result['checks']:
            if face_check(source):
                row=deepcopy(source)
                row.update(id=row['id']+'_'+face,face=face,load_basis='per_angle')
                row['label'] += ' · '+FACE_LABELS[face]+' · N/2'
                row['details'].update(face=face,N_per_angle=N/2,N_total=N)
                if row['mechanism']=='block_tearout':
                    row['details']['candidates']=[_face_path(p,face) for p in row['details']['candidates']]
                    row['details']['governing']=_face_path(row['details']['governing'],face)
                out['checks'].append(row)
    record=deepcopy(common['cases'][0])
    paths=[dict(deepcopy(p),load_basis='total_pair') for p in record['paths'] if p['component']=='gusset']
    for face in FACE_IDS:
        paths += [_face_path(p,face) for p in face_result['cases'][0]['paths'] if p['component']=='angle']
    record['paths']=paths
    A=g['angle_section']; angle=materials[0]
    Ct=record['angle_Ct']; Ag=A['Ag']; Ae=Ct*Ag
    capacities=dict(gross_yield=2*Ag*angle.fy/GAMMA_A1,effective_rupture=2*Ae*angle.fu/GAMMA_A2)
    shared._envelope(out,'pair_tension','Par 2L-T · tração total, Ct de cada L preservado','angle_pair','tension',case,
        [dict(name='Escoamento bruto do par',demand=N,resistance=capacities['gross_yield'],Ag_each=Ag,Ag_pair=2*Ag),
         dict(name='Ruptura efetiva do par',demand=N,resistance=capacities['effective_rupture'],Ct_each=Ct,Ae_each=Ae,Ae_pair=2*Ae)],
        'NBR5.2.2/5.2.5(c); duas áreas físicas idênticas; Ct de cada face, não Ct1 do par')
    out['checks'][-1]['load_basis']='total_pair'
    record.update(N_per_angle=N/2,angle_area_basis='one_angle',angle_count=2,
        angle_gross_area=Ag,pair_gross_area=2*Ag,pair_effective_area=2*Ae,pair_tension_capacities=capacities,
        angle_forces=[dict(face=face,N=N/2,heel_N=N/2*A['heel_force_fraction'],toe_N=N/2*A['toe_force_fraction']) for face in FACE_IDS])
    out['cases'].append(record)
    if case=='actual':
        out.update(root=record['root'],sections=record['plate_sections'],paths=paths,member_actions=record['member_actions'])
        out['geometry']['inactive_path_families']=record['inactive_path_families']


def evaluate(c):
    out=dict(status='INVALID_INPUT',global_pass=False,local_pass=False,issues=[],checks=[],cases=[],geometry={},
             root={},sections={},paths=[],materials={},member_actions={},summary={},inputs=_safe(asdict(c)) if isinstance(c,WeldedDoubleAngleGusset) else _safe(c),
             family=FAMILY,connection_type=CONNECTION_TYPE,component_version=COMPONENT_VERSION,units=dict(UNITS),scope=SCOPE,exclusions=list(EXCLUSIONS))
    errors=input_errors(c)
    if errors:
        for n,e in enumerate(errors):_issue(out,'input_'+str(n),'invalid_input',e)
        return _finalize(out)
    out['fixed_assumptions']=c.fixed_assumptions
    conditions=[(c.topology!='symmetric_T','T_topology','Somente T simétrico com talões alinhados; vértices opostos >< fora do ramo.'),
      (c.interface!='welded','interface','Somente quatro filetes longitudinais; interface parafusada ou mista fora do ramo.'),
      (not c.symmetric_load,'symmetric_load','Partilha N/2 exige seções, aços, ligações e carregamento simétricos, inclusive na extremidade oposta.'),
      (not c.accessible_both_faces,'weld_access','As quatro soldas longitudinais exigem execução e inspeção acessíveis nas duas faces.'),
      (c.support_member not in ('beam','column'),'member','Membro de apoio deve ser viga ou pilar.'),
      (c.support_face!='flange','face','Ligação direta à alma W ainda não qualificada; esta rota usa mesa exterior centrada na alma.'),
      (get_angle(c.angle_profile) is None,'angle_catalog','Cantoneira não reconhecida; selecionar identidade exata de fabricante e linha do catálogo.'),
      (c.angle_weld_edge_detail not in ('ordinary','reinforced'),'angle_weld_edge_detail','Detalhe de borda deve ser ordinary ou reinforced.'),
      (c.angle_weld_edge_detail == 'reinforced' and c.angle_profile == LEGACY_ARCELOR_ID,'legacy_edge_detail','Seção ArcelorMittal legada conserva o detalhe original sem reforço de borda.'),
      (c.support_profile not in SUPPORT_CATALOG,'support_catalog','Perfil W laminado não reconhecido; selecionar identidade completa do catálogo.'),
      (any(x!=0 for x in (c.V,c.M,c.torsion)),'external_actions','Ações V/M/T externas preservadas, mas fora desta rota axial; M geométrico da raiz é calculado normalmente.'),
      (not c.static or c.fatigue or c.seismic,'nonstatic','Exige solicitação estática sem fadiga/sismo para6.1.8.2.'),
      (not c.normal_combination,'combination','Fatores limitados a combinações últimas normais.'),
      (not c.minimum_force and abs(c.N)<45000,'minimum_force','Sem exceção declarada, desativar o candidato45kN impede aprovação para N<45kN.')]
    for test,id,msg in conditions:
        if test:_issue(out,id,'outside_scope',msg)
    A=get_angle(c.angle_profile)
    material_objs=[]
    for role,name,thickness in [('angle',c.angle_steel,A['t'] if A else 0.),('gusset',c.gusset_steel,c.plate_t),('support',c.support_steel,SUPPORT_CATALOG.get(c.support_profile,SUPPORT)['tf'])]:
        mat=MATERIALS.get(name)
        if not mat:
            _issue(out,role+'_material','outside_scope',role+': material fora do catálogo.');continue
        okay=(mat.plate_allowed and mat.plate_min<=thickness<=mat.plate_max if role=='gusset' else mat.rolled_allowed and mat.profile_min<=thickness<=mat.profile_max)
        if not okay:_issue(out,role+'_material_product','outside_scope',role+': produto/espessura fora do intervalo do aço selecionado.')
        material_objs.append(mat);out['materials'][role]=dict(name=name,fy=mat.fy,fu=mat.fu,thickness=thickness,source=mat.source)
    for interface,name in [('angle_weld',c.angle_electrode),('root_weld',c.root_electrode)]:
        if name not in ELECTRODES:_issue(out,interface+'_electrode','outside_scope','Consumível não reconhecido.')
        else:out['materials'][interface]=dict(name=name,fw=ELECTRODES[name])
    try:
        g=shared._geometry(c,out)
        if g is not None:out['geometry']=g
        # Never compute selected geometry using known fixture coefficients after a topology error.
        fatal=any(i['severity'] in ('outside_scope','invalid_geometry') for i in out['issues'])
        if g and not fatal and len(material_objs)==3:
            is_compression=c.N<0
            if is_compression:compression.boundaries(c,out)
            loads=[('actual','Compressão real total do par' if is_compression else 'Tração real total do par',c.N)]
            if c.minimum_force and abs(c.N)<45000:loads.append(('minimum_45kN','Mínimo total45kN com sinal preservado · NBR6.1.5.2' if is_compression else 'Mínimo total45kN · NBR6.1.5.2',-45000. if is_compression else 45000.))
            if c.recommend_half_capacity and is_compression:
                _issue(out,'compression_recommended_half','unverified','A recomendação50% em compressão depende da resistência global real da diagonal; não se usa Ct de tração nem capacidade global inventada. Política adicional pendente do responsável.')
            if c.recommend_half_capacity and not is_compression:
                a=material_objs[0];Ct=max(1-A['centroid']/c.weld_length,.5)
                half=.5*min(2*A['Ag']*a.fy/GAMMA_A1,2*Ct*A['Ag']*a.fu/GAMMA_A2)
                loads.append(('recommended_half','Recomendação50% da capacidade do par · opção do RT · NBR6.1.5.3',half))
            for id,label,N in loads:
                (compression.calculate_case if N<0 else _calculate_case)(c,g,N,id,label,out,material_objs)
        if g is not None:_physical_geometry(c,out['geometry'])
        # Check all serialized arithmetic, including geometry intermediates.
        def check(v):
            if isinstance(v,dict):return all(check(x) for x in v.values())
            if isinstance(v,(tuple,list)):return all(check(x) for x in v)
            return finite_real(v) if isinstance(v,(int,float)) and not isinstance(v,bool) else True
        if not check(out):raise ArithmeticError('Resultado intermediário não finito.')
    except (ArithmeticError,ValueError,TypeError,ZeroDivisionError) as e:
        _issue(out,'numerical_failure','numerical_failure','Cálculo não concluído: '+str(e))
    return _finalize(out)
