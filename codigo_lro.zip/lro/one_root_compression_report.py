"""Concise grouped local compression memory, canonical input-bound evaluation."""
from io import BytesIO
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.oxml.ns import qn
from .welded_double_angle_gusset import COMPONENT_VERSION
from .welded_double_angle_gusset_drawing import image_bytes, input_fingerprint, validated_result, STATUS
from .welded_double_angle_gusset_report import _tab, _heading, _n, _value, _envelopes, _details
from .report import _math, frac, group, power, radical, sub, BRAND


def create_report(c,detailed=False):
    r=validated_result(c);comp=r.get('compression') or {};strip=comp.get('strip') or {};g=r.get('geometry') or {}
    doc=Document();sec=doc.sections[0]
    sec.page_width=Inches(8.27);sec.page_height=Inches(11.69)
    sec.top_margin=sec.bottom_margin=Inches(.55);sec.left_margin=sec.right_margin=Inches(.65)
    normal=doc.styles['Normal'];normal.font.name='Calibri';normal.font.size=Pt(9)
    normal.paragraph_format.space_after=Pt(5)
    for name,size in (('Title',20),('Subtitle',11),('Heading 1',12),('Heading 2',10)):
        style=doc.styles[name];style.font.name='Calibri';style.font.size=Pt(size);style.font.color.rgb=RGBColor(0,0,0)
        style.font.underline=False;style.paragraph_format.keep_with_next=True
        for b in list(style.element.iter(qn('w:pBdr'))):b.getparent().remove(b)
    doc.add_paragraph('Compressão local de duas cantoneiras em T na mesa W',style='Title')
    doc.add_paragraph('Memória de cálculo '+('detalhada' if detailed else 'resumida'),style='Subtitle')
    doc.add_paragraph('Projeto: '+c.project)
    doc.add_paragraph(STATUS.get(r['status'],r['status'])).runs[0].bold=True
    summary=r['summary']
    doc.add_paragraph('Estado: '+r['status']+'. Maior índice numérico η='+_n(summary.get('utilization'),7)+
        '. Falhas físicas: '+str(len(summary.get('failed_check_ids',[])))+'. Condições não verificadas: '+str(len(summary.get('unverified_ids',[])))+'.')
    doc.add_paragraph('Uma chapa retangular e uma raiz contínua dupla, centrada na alma de W laminado. N negativo comprime o par; cada L recebe N/2, enquanto a chapa, a raiz e o W recebem N uma vez. O modelo DG29 Exemplo5.4 admite deslocamento lateral com K1,2 e exige os vínculos reais de rotação identificados abaixo. Resultados condicionais não aprovam o detalhe real, a estrutura global ou a fabricação.')
    _heading(doc,'Condições físicas e informações faltantes')
    bounds=comp.get('boundaries') or {}
    for role,label in [('root','Raiz e W receptor'),('brace','Continuação da diagonal'),('receiver','Condições locais do W')]:
        b=bounds.get(role,{})
        status=('vinculado ao detalhe atual' if b.get('qualified',b.get('evidence_current',False)) else 'NÃO VERIFICADO')
        doc.add_paragraph(label+': '+status+'. Fonte: '+str(b.get('source') or 'não informada')+'.')
    for issue in r.get('issues',[]):doc.add_paragraph(str(issue.get('message')),style='List Bullet')
    _envelopes(doc,r)
    doc.add_page_break();_heading(doc,'Detalhe proporcional da entrada atual')
    doc.add_picture(BytesIO(image_bytes(c,fmt='png')),width=Inches(6.9))
    doc.add_paragraph('Faixa roxa: Whitmore retida e projeções na raiz real. A faixa reduzida recebe a compressão integral; material omitido não ganha resistência. Os apoios necessários são condições documentadas, sem símbolos que inventem travamentos.')
    doc.add_page_break();_heading(doc,'Geometria e materiais usados')
    A=g.get('angle_section') or {};W=g.get('support_catalog') or {}
    _tab(doc,['Elemento','Dados'],[
        ('Chapa única',f"B={c.plate_width:g}; H={c.plate_height:g}; t={c.plate_t:g} mm; {c.gusset_steel}"),
        ('Cada cantoneira',f"{A.get('manufacturer','')} {A.get('name',c.angle_profile)}; Ag={A.get('Ag')}; b={A.get('leg')}; t={A.get('t')}; ec={A.get('centroid')} mm; {c.angle_steel}"),
        ('W receptor',c.support_profile+f"; d={W.get('d')}; bf={W.get('bf')}; tw={W.get('tw')}; tf={W.get('tf')}; k={W.get('k')} mm; {c.support_steel}"),
        ('Implantação',f"θ={c.theta_deg:g}°; centro ({c.center_s:g}; {c.center_n:g}) mm; seção local={c.introduction_width:g} mm"),
        ('Soldas',f"Quatro filetes L={c.weld_length:g} mm / perna={c.angle_weld_leg:g} mm ({c.angle_electrode}); raiz dupla B={c.plate_width:g} / perna={c.root_weld_leg:g} mm ({c.root_electrode})"),
        ('Extremidades W',f"Esquerda={c.support_end_left:g}; direita={c.support_end_right:g} mm desde o centro da raiz; não são vãos laterais"),
        ('Ações adicionais',f"V={c.V:g} N; M={c.M:g} N mm; T={c.torsion:g} N mm"),
    ],[1.35,5.62])
    if r.get('materials'):
        _tab(doc,['Material','fy ou fw (MPa)','fu (MPa)'],[(v.get('name',k),_n(v.get('fy',v.get('fw'))),_n(v.get('fu'))) for k,v in r['materials'].items()],[3.17,1.9,1.9])
    _heading(doc,'Casos separados e ações reais na raiz')
    doc.add_paragraph('O mínimo de módulo45kN mantém o sinal antes da divisão entre as duas L. Nunca é somado ao caso real. O caso zero conserva a convenção nominal positiva em sua rota própria. A recomendação adicional de50% em compressão exige a resistência global real da diagonal, não deduzida de Ct de tração.')
    _tab(doc,['Caso','N total kN','N por L kN','N raiz kN','V raiz kN','M raiz kNm'],[
        (x['id'],_n(x['N'],5,1000),_n(x.get('N_per_angle'),5,1000),_n(x['root']['N'],5,1000),_n(x['root']['V'],5,1000),_n(x['root']['M'],5,1e6)) for x in r.get('cases',[])],[1.47,1.1,1.1,1.1,1.1,1.1],7.5)
    root=r.get('root') or {}
    if root:
        doc.add_paragraph('Trações normais de linha na raiz real: '+_value(root.get('q_n_ends_N_per_mm'))+' N/mm. Neq de pressão='+_n(root.get('compression_peak_equivalent_N'),6,1000)+' kN é um envelope resistente conservador; não entra novamente no equilíbrio.')
    member=r.get('member_actions') or {}
    doc.add_paragraph('Momento introduzido no centroide do W='+_n(member.get('introduced_moment_about_member_centroid'),6,1e6)+' kNm. Exportar também Nnormal e Vparalelo assinados e combiná-los com as ações globais reais. O aplicativo não presume membro descarregado.')
    if strip:
        _heading(doc,'Instabilidade condicional da chapa')
        _tab(doc,['Faixa e comprimentos','Valor'],[
            ('Intervalo Whitmore bruto v (mm)',_value(strip['raw_v'])),('Intervalo retido centrado em v0 (mm)',_value(strip['retained_v'])),
            ('v0 e largura bw (mm)',_n(strip['v0'],6)+'; '+_n(strip['width'],6)),('Projeções na raiz (mm)',_value(strip['root_projections'])),
            ('Comprimentos nas duas bordas e centro (mm)',_value(strip['three_lengths'])),
            ('Lmáx / Le / Le por r',_n(strip['Lmax'],6)+' / '+_n(strip['Le'],6)+' / '+_n(strip['Le_over_r'],6)),
            ('λ0 / χ / Nc Rd (kN)',_n(strip['lambda0'],8)+' / '+_n(strip['chi'],8)+' / '+_n(strip['resistance'],6,1000)),
        ],[3.45,3.52])
    _heading(doc,'Modelo e equações')
    _math(doc,group('Ftalão por face = (1 − ',frac('ec','b'),') ',frac('N','2'),'; Fponta por face = ',frac('ec','b'),' ',frac('N','2')))
    _math(doc,group('Nraiz = N sen θ; Vraiz = N cos θ; Mraiz = xs Nraiz − yn Vraiz'))
    _math(doc,group('σ = ',frac('N','A'),' ± ',frac('M','S'),'; σeq = ',radical(group(power('σ'),' + 3 ',power('τ'))),' ≤ ',frac('fy','γa1')))
    doc.add_paragraph('As seções horizontais mantêm os extremos exatos dos polinômios de força remanescente e o envelope N/V/M; a faixa local mantém a excentricidade ec−b/2. O primeiro domínio automático exige normais não positivas em todas essas seções e nos dois extremos da raiz. Campo misto exige outro modelo, sem substituição por módulo de N.')
    _math(doc,group('A = ',sub('b','w'),' t; I = ',frac(group(sub('b','w'),power('t','3')),'12'),'; r = ',frac('t',radical('12'))))
    _math(doc,group(sub('L','e'),' = 1,2 ',sub('L','máx'),'; ',sub('N','e'),' = ',frac(group(power('π'),' E I'),power(sub('L','e')))))
    _math(doc,group(sub('λ','0'),' = ',radical(frac(group('A ',sub('f','y')),sub('N','e')))))
    _math(doc,group('χ = ',power('0,658',power(sub('λ','0'))),' para ',sub('λ','0'),' ≤ 1,5'))
    _math(doc,group('χ = ',frac('0,877',power(sub('λ','0'))),' para ',sub('λ','0'),' > 1,5'))
    _math(doc,group(sub('N','c,Rd'),' = ',frac(group('χ A ',sub('f','y')),sub('γ','a1')),'; E = 200000 MPa'))
    _math(doc,group(sub('γ','a1'),' = 1,10; ',sub('γ','a2'),' = ',sub('γ','w2'),' = 1,35'))
    doc.add_paragraph('K1,2 provém do modelo convencional do DG29 Ex5.4. Não fixa deslocamento lateral da ponta, mas não representa rotação livre nas duas extremidades. A faixa é cortada à chapa e às projeções que atingem a raiz real e depois centrada na linha física de força. Le usa o máximo em toda essa faixa, sem atalho de canto ou raiz adicional. O limite automático Le/r = 200 é conservador de comportamento em serviço, não proibição absoluta da NBR.')
    doc.add_paragraph('NBR8800:2024/Er1:2025, Errata1 PDF1, corrige6.5.4(b) para Le/r>25. O corpo PDF117 conserva o texto superado. Aplica-se aqui a curva integral mesmo abaixo de25, uma escolha conservadora. Não há ambiguidade normativa pendente sobre a desigualdade.')
    doc.add_paragraph('Cada L recebe compressão bruta e triagem AL3 conservadora com b integral. O limite de transferência uniforme usa uma superfície L vezes espessura, Ant=0 e γa2; conserva a espessura plana publicada no catálogo legado. Metal de filete e substrato local usam cada força física por face. Ruptura normal tracionada, Ct de tração e blocos de saída tracionada não são resistências de compressão.')
    _heading(doc,'Mecanismos do W receptor')
    doc.add_paragraph('NBR5.7.3 usa o comprimento real B e a menor distância do ponto carregado à extremidade; NBR5.7.4 usa os ramos d/2 e B/d. Cisalhamento longitudinal, combinação normal/cisalhamento e as duas superfícies de cisalhamento da mesa permanecem. NBR5.7.2 por tração na mesa está inativa neste campo comprimido.')
    sw=comp.get('receiver_sidesway') or {}
    doc.add_paragraph('NBR5.7.5: '+str(sw.get('status','UNVERIFIED'))+'. Fonte: '+(c.compression_receiver_source or 'não informada')+'. ℓ informado='+_n(c.compression_unbraced_length)+' mm (zero significa ausente); rotação='+c.compression_flange_rotation+'.')
    doc.add_paragraph('Sem contenção relativa real entre mesas, h=d−2k e ρ=(h/tw)/(ℓ/bf). Cr=16E é conservador sem inventar o estado de momento global. Rotação impedida: Rd=Cr tw³ tf/(γa1 h²) [0,94+0,37ρ³] para ρ≤2,3; rotação livre: mesmo fator vezes0,37ρ³ para ρ≤1,7. Somente razão estritamente maior dispensa o modo. Esse cálculo não comprova a rotação da raiz do gusset. Par de forças opostas5.7.6 ou painel interagente requer identificação e outro modelo físico.')
    _heading(doc,'Fontes e conclusão')
    doc.add_paragraph('ABNT NBR8800:2024/Errata1:2025: 5.3, 5.7.3–5.7.6, 6.1.5, 6.2, 6.5.3–6.5.5. AISC DG29(2014), Exemplo5.4, pp98,103–104,108–109; ApêndiceC. Dowswell(2006), Effective Length Factors for Gusset Plate Buckling, Engineering Journal43(2), pp91–102, ressalvas de vínculos rotacionais.')
    doc.add_paragraph('Fonte geométrica das L: '+str(A.get('source','não disponível'))+'. Fonte do W: '+str(W.get('source','não disponível'))+'.')
    doc.add_paragraph('Verificações locais atendem apenas às condições explicitamente declaradas.' if r.get('local_pass') else 'Sem atendimento local completo. Resolver as falhas e os vínculos pendentes registrados; resultado numérico favorável isolado não elimina uma falha física.')
    doc.add_paragraph('Fora desta memória: estabilidade global da diagonal/W/pórtico, fadiga, sismo, ações espaciais adicionais, uma L, cantoneiras opostas, parafusos, alma direta, chapa arbitrária ou raiz interrompida. Um detalhe ordinário documentado pode estabelecer os vínculos; não se exige genericamente análise por elementos finitos.')
    if c.notes:doc.add_paragraph('Observações: '+c.notes)
    if detailed:_details(doc,r)
    doc.add_paragraph(COMPONENT_VERSION+' · SHA-256 das entradas: '+input_fingerprint(c))
    doc.add_paragraph(BRAND)
    doc.core_properties.title='Compressão local de duas cantoneiras em T na mesa W'
    doc.core_properties.subject='Memória local '+COMPONENT_VERSION
    output=BytesIO();doc.save(output);return output.getvalue()
