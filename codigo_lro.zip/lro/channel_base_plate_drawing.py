"""Physical channel-base drawing in the same x/y frame as the kernel.

Plan coordinates are displayed as (y, x). No symmetric I/H replacement is used.
"""
from io import BytesIO
import math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Polygon, Rectangle, FancyArrowPatch
from .drawing_annotations import dimension
from .display_precision import display_format
from .models import KGF
from .anchor_projection_detail import projection_geometry, projection_note
from .concrete_anchorage import SUPPORTED

INK = '#243749'
PLATE = '#dce6ec'
COLUMN = '#728a9c'
ACCENT = '#b75024'


def _f(value):
    return display_format(value, '.2f')


def require_current_result(c, r):
    """Prevent a drawing/report combining current inputs with old reactions."""
    from .channel_base_plate import evaluate
    current = evaluate(c)
    if r is not None and r != current:
        raise ValueError('Resultado desatualizado: recalcule a base U para os dados atuais.')
    return current


def _drawable(c):
    p = c.column
    values = (c.L, c.B, c.tp, c.db, c.anchor_y, p.d, p.bf, p.tw, p.tf,
              c.centroid_back, c.anchor_washer_side, c.grout_t)
    if any(type(v) not in (int, float) or not math.isfinite(v) or not 0 < v <= 1e6 for v in values):
        raise ValueError('Dimensões fora do domínio do desenho da base U.')
    if c.anchor_layout=='four' and (not math.isfinite(c.anchor_x) or c.anchor_x<=0):
        raise ValueError('Semiespaçamento ax inválido para quatro barras.')
    if not math.isfinite(c.offset_y) or p.d <= 2*p.tf or p.bf <= p.tw:
        raise ValueError('Seção U inválida para o desenho.')


def drawing(c, r=None):
    _drawable(c)
    if r is not None:
        require_current_result(c, r)
    p, L, B = c.column, c.L, c.B
    ag=projection_geometry(c)
    if not math.isfinite(c.hef) or c.hef<=0:
        raise ValueError("Embutimento hef inválido para o desenho.")
    back = c.offset_y-c.centroid_back
    fig, (plan, side) = plt.subplots(1, 2, figsize=(13.4, 7.8), gridspec_kw={'width_ratios': [1, 1.12]})
    fig.patch.set_facecolor('white')
    for ax in (plan, side):
        ax.set_aspect('equal')
        ax.axis('off')
    def rect(ax, x, y, w, h, color, gid, **kw):
        item = Rectangle((x,y),w,h,facecolor=color,edgecolor=INK,lw=.8,**kw)
        item.set_gid(gid);ax.add_patch(item)
        return item
    def text(ax,x,y,label,**kw):
        return ax.text(x,y,label,color=INK,**{'fontsize':8,**kw})
    def arrow(ax,start,end,gid,color=ACCENT):
        item=FancyArrowPatch(start,end,arrowstyle='-|>',mutation_scale=12,color=color,lw=1.2)
        item.set_gid(gid);ax.add_patch(item)
    m=max(L,B)*.13
    plan.set_title('PLANTA y–x · U ASSIMÉTRICO',loc='left',fontsize=10,fontweight='bold',color=INK,pad=16)
    rect(plan,-B/2,-L/2,B,L,PLATE,'u_plate_plan')
    verts=[(back,-p.d/2),(back+p.bf,-p.d/2),(back+p.bf,-p.d/2+p.tf),
           (back+p.tw,-p.d/2+p.tf),(back+p.tw,p.d/2-p.tf),(back+p.bf,p.d/2-p.tf),
           (back+p.bf,p.d/2),(back,p.d/2)]
    section=Polygon(verts,closed=True,facecolor=COLUMN,edgecolor=INK,lw=.9)
    section.set_gid('u_column_section');plan.add_patch(section)
    plan.plot([0,0],[-L/2,L/2],ls='-.',lw=.55,color=INK,gid='u_plate_x_axis')
    plan.plot([-B/2,B/2],[0,0],ls='-.',lw=.55,color=INK,gid='u_plate_y_axis')
    for i,(x,y) in enumerate(c.anchor_coordinates,1):
        s=c.anchor_washer_side
        rect(plan,y-s/2,x-s/2,s,s,'none',f'u_washer_A{i}',linestyle='--')
        if c.direct_anchor_shear and c.direct_shear.hole_diameter>0:
            hole=Circle((y,x),c.direct_shear.hole_diameter/2,fill=False,edgecolor=INK,lw=.7,ls=':')
            hole.set_gid(f'direct_plate_hole_A{i}');plan.add_patch(hole)
        circle=Circle((y,x),c.db/2,facecolor='white',edgecolor=INK,lw=1)
        circle.set_gid(f'u_anchor_A{i}');plan.add_patch(circle)
        plan.annotate(f'A{i}',(y,x),xytext=(0,7 if x>0 else -8),textcoords='offset points',
                      ha='center',va='bottom' if x>0 else 'top',fontsize=8,color=INK)
    plan.plot([c.offset_y],[0],marker='o',markersize=4,color=ACCENT,gid='u_column_centroid')
    plan.annotate('CG do U',(c.offset_y,0),xytext=(-16,50),textcoords='offset points',ha='right',
                  fontsize=8,color=ACCENT,arrowprops={'arrowstyle':'-','color':ACCENT,'lw':.7})
    dimension(plan,(-B/2,-L/2-m*.65),(B/2,-L/2-m*.65),'B='+_f(B)+' mm',fontsize=8)
    dimension(plan,(-B/2-m*.65,-L/2),(-B/2-m*.65,L/2),'L='+_f(L)+' mm',rotation=90,fontsize=8)
    dimension(plan,(-c.anchor_y,L/2+m*.55),(c.anchor_y,L/2+m*.55),'2ay='+_f(2*c.anchor_y),fontsize=8)
    if c.anchor_layout=='four':
        dimension(plan,(B/2+m*.6,-c.anchor_x),(B/2+m*.6,c.anchor_x),'2ax='+_f(2*c.anchor_x),rotation=90,fontsize=8)
    else:
        text(plan,0,L/2+m*.93,'Duas barras no eixo x=0 · atrás da alma / frente da abertura',ha='center',fontsize=7)
    text(plan,0,-L/2-m*1.55,'Dorso: y=ey−ec='+_f(back)+' mm',ha='center')
    text(plan,0,-L/2-m*1.95,'ec='+_f(c.centroid_back)+' mm · ey='+_f(c.offset_y)+' mm',ha='center')
    origin=(-B/2+m*.1,-L/2+m*.15)
    arrow(plan,origin,(origin[0]+m*.7,origin[1]),'u_plan_y_direction',INK)
    arrow(plan,origin,(origin[0],origin[1]+m*.7),'u_plan_x_direction',INK)
    text(plan,origin[0]+m*.8,origin[1],'+y',va='center')
    text(plan,origin[0],origin[1]+m*.8,'+x',ha='center')
    plan.set_xlim(-B/2-m*1.35,B/2+m*1.25)
    plan.set_ylim(-L/2-m*2.2,L/2+m*1.05)

    side.set_title('ELEVAÇÃO x–z · AÇÕES APLICADAS',loc='left',fontsize=10,fontweight='bold',color=INK,pad=16)
    hc=max(L*.6,p.d*.9)
    embed=c.hef+c.anchor_head_t+max(c.anchor_bottom_cover,30.)
    has_head=c.anchor_type in SUPPORTED
    rect(side,-L/2-m,-c.grout_t-embed,L+2*m,embed,'#ece9e2','u_concrete_section',hatch='..')
    grout=Polygon([(-L/2,0),(L/2,0),(L/2+c.grout_t,-c.grout_t),(-L/2-c.grout_t,-c.grout_t)],
                  facecolor='#e4e5db',edgecolor=INK,lw=.8)
    grout.set_gid('u_grout_section');side.add_patch(grout)
    rect(side,-L/2,0,L,c.tp,PLATE,'u_plate_elevation')
    rect(side,-p.d/2,c.tp,p.d,hc,'#ebf0f3','u_column_elevation')
    for tag,x in [('left',-p.d/2),('right',p.d/2-p.tf)]:
        rect(side,x,c.tp,p.tf,hc,COLUMN,'u_'+tag+'_flange_elevation')
    for i,x in enumerate(sorted({x for x,y in c.anchor_coordinates}),1):
        nut_h=ag['nut_h'];nut_width=ag['nut_width']
        zface=ag['bearing_face']
        # The rod below the bearing face is an assembly envelope, not a cut length.
        rod_end=zface-c.anchor_head_t if has_head else zface
        rect(side,x-c.db/2,rod_end,c.db,ag['rod_top']-rod_end,'#f8fafb',f'u_anchor_projection_{i}')
        if has_head:
            rect(side,x-c.anchor_head_length/2,zface-c.anchor_bearing_t,c.anchor_head_length,c.anchor_bearing_t,
                 '#b2cbb6',f'u_buried_bearing_{i}')
            side.plot([x-c.anchor_head_length/2,x+c.anchor_head_length/2],[zface,zface],
                      color='#447c58',lw=1.4,gid=f'u_bearing_face_{i}')
            if c.anchor_type=='buried_plate_nut':
                rect(side,x-c.db*.75,zface-c.anchor_bearing_t-c.anchor_nut_t,c.db*1.5,c.anchor_nut_t,
                     '#637b8d',f'u_buried_nut_{i}')
        rect(side,x-c.anchor_washer_side/2,c.tp,c.anchor_washer_side,c.anchor_washer_t,COLUMN,'u_upper_washer_projection')
        nw=nut_width; z=c.tp+c.anchor_washer_t; bevel=nw*.12
        nut=Polygon([(x-nw/2+bevel,z),(x+nw/2-bevel,z),(x+nw/2,z+nut_h*.2),
                     (x+nw/2,z+nut_h*.8),(x+nw/2-bevel,z+nut_h),(x-nw/2+bevel,z+nut_h),
                     (x-nw/2,z+nut_h*.8),(x-nw/2,z+nut_h*.2)],closed=True,
                    facecolor='#c5d1da',edgecolor=INK,lw=.8)
        nut.set_gid('u_upper_nut_schematic');side.add_patch(nut)
        if i==1:
            side.annotate('Arruela axial + porca; sem crédito lateral' if c.direct_anchor_shear else 'Arruela + porca superior',(x-c.anchor_washer_side/2,c.tp+c.anchor_washer_t/2),
                xytext=(-L/2,c.tp+hc*.24),fontsize=7,color=INK,ha='center',
                arrowprops={'arrowstyle':'-','lw':.7,'color':INK})
    dimension(side,(-L/2-m*1.35,ag['bearing_face']),(-L/2-m*1.35,-c.grout_t),
              'hef='+_f(c.hef)+' mm',rotation=90,fontsize=8)
    if not has_head:
        text(side,0,ag['bearing_face']-m*.65,'hef informado; mecanismo enterrado a definir',ha='center',fontsize=7,
             bbox={'facecolor':'white','edgecolor':'none','pad':2})
    text(side,0,-c.grout_t-embed+m*.5,
         '2 barras coincidentes em x=0' if c.anchor_count==2 else '2 barras por posição projetada',
         ha='center',fontsize=7,bbox={'facecolor':'white','edgecolor':'none','pad':2})
    # Leaders rather than short stacked dimensions keep the two datums readable.
    side.annotate('Topo do concreto',xy=(L/2,-c.grout_t),xytext=(L/2+m*.8,-c.grout_t-embed*.25),
                  fontsize=7,color=INK,arrowprops={'arrowstyle':'-','lw':.7,'color':INK})
    dimension(side,(L/2+m*1.65,-c.grout_t),(L/2+m*1.65,ag['rod_top']),
              'P concreto='+_f(ag['above_concrete'])+' mm',rotation=90,fontsize=7)
    side.annotate('P placa='+_f(ag['above_plate'])+' mm',xy=(max(x for x,y in c.anchor_coordinates),ag['rod_top']),
                  xytext=(L/2+m*.3,c.tp+hc*.85),fontsize=7,color=INK,
                  arrowprops={'arrowstyle':'-','lw':.7,'color':INK})
    head=c.tp+hc
    if c.N:
        ends=((0,head+m*1.7),(0,head-m*.25))
        if c.N<0:ends=ends[::-1]
        arrow(side,*ends,'u_applied_N')
    text(side,m*.25,head+m*1.1,'N='+_f(c.N/KGF)+' kgf',ha='left')
    if c.V:
        start=(p.d/2+m*.15,c.tp+hc*.53)
        end=(p.d/2+m*1.25,c.tp+hc*.53)
        arrow(side,*( (start,end) if c.V>0 else (end,start) ),'u_applied_V')
    text(side,p.d/2+m*.35,c.tp+hc*.7,'V='+_f(c.V/KGF)+' kgf',ha='left')
    side.annotate('tp='+_f(c.tp)+' mm',xy=(-L/2,c.tp/2),xytext=(-L/2-m*.9,c.tp+hc*.5),
                  fontsize=7,color=INK,arrowprops={'arrowstyle':'-','lw':.7,'color':INK})
    text(side,0,-c.grout_t-embed-m*.55,'M aplicado = 0 · V paralelo à alma (+x)',ha='center')
    text(side,0,-c.grout_t-embed-m*.95,'hef: topo do concreto → face de apoio; não é o comprimento total.',ha='center',fontsize=7)
    fig.text(.50,.035,projection_note(c),ha='center',fontsize=8,color=INK)
    fig.text(.50,.012,('CONTATO DIRETO · d0='+_f(c.direct_shear.hole_diameter)+' mm. Estados alternativos, não somados; arruela sem crédito lateral.' if c.direct_anchor_shear else 'Trecho de concreto ilustrativo. Porca genérica se não catalogada. Comprimento total da barra não definido.'),ha='center',fontsize=7,color=INK)
    side.set_xlim(-L/2-m*1.8,L/2+m*3.4)
    side.set_ylim(-c.grout_t-embed-m*1.35,head+m*2.15)
    fig.subplots_adjust(left=.055,right=.97,bottom=.11,top=.89,wspace=.22)
    fig.suptitle('BASE U ROTULADA · '+('DOIS' if c.anchor_count==2 else 'QUATRO')+' CHUMBADORES',fontsize=12,fontweight='bold',color=INK,y=.98)
    return fig


draw = drawing


def image_bytes(c, r=None, fmt='png'):
    if fmt not in ('png','svg'):
        raise ValueError('Formato de desenho deve ser png ou svg.')
    fig=drawing(c,r)
    try:
        out=BytesIO();fig.savefig(out,format=fmt,dpi=160,facecolor='white',bbox_inches='tight')
        return out.getvalue()
    finally:
        plt.close(fig)
