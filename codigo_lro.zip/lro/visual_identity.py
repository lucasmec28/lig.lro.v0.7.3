"""Reusable LRO browser-shell identity, independent of engines and project state.

Only presentation tokens live here. Technical renderer palettes, semantic status
colors, dimensions, formulas and exported artifacts are deliberately untouched.
"""
from html import escape
from types import MappingProxyType

TOKENS = MappingProxyType({
    'navy': '#0a2342', 'navy_accent': '#12365b', 'background': '#f3f6fa',
    'surface': '#ffffff', 'text': '#172b43', 'muted': '#50637b',
    'border': '#d7e1ec', 'focus': '#2a70aa', 'radius': '12px',
    'font': '"Segoe UI", Roboto, Arial, sans-serif',
})


def shell_css():
    """No JavaScript, remote font, image filters or engineering-status overrides."""
    t = TOKENS
    return f'''<style>
:root {{ --lro-navy: {t['navy']}; --lro-accent: {t['navy_accent']};
 --lro-background: {t['background']}; --lro-surface: {t['surface']};
 --lro-text: {t['text']}; --lro-muted: {t['muted']}; --lro-border: {t['border']}; }}
[data-testid="stAppViewContainer"] {{ background: var(--lro-background); }}
[data-testid="stSidebar"] {{ background: #eaf0f7; }}
.stApp {{ font-family: {t['font']}; }}
.lro-shell-header {{ padding: 1.35rem 1.65rem; margin: 0 0 1.1rem;
 background: var(--lro-navy); color: white; border-radius: {t['radius']}; }}
.lro-shell-header h1 {{ color: white; font-size: 1.65rem; margin: 0; padding: 0; }}
.lro-shell-header p {{ color: #dce8f6; margin: .4rem 0 0; font-size: .95rem; }}
.lro-shell-eyebrow {{ color: #dce8f6; font-size: .72rem; letter-spacing: .14em;
 text-transform: uppercase; margin-bottom: .35rem; }}
.lro-shell-project {{ border-left: 4px solid var(--lro-navy); padding: .65rem 1rem;
 background: var(--lro-surface); color: var(--lro-text); margin: .8rem 0 1rem; }}
[data-testid="stBaseButton-primary"] {{ background: var(--lro-navy); border-color: var(--lro-navy); color: white; }}
[data-testid="stBaseButton-primary"]:hover {{ background: var(--lro-accent); border-color: var(--lro-accent); color: white; }}
[class*="st-key-nav_guide_card_"] button {{ border-color: var(--lro-border); color: var(--lro-navy); }}
[class*="st-key-nav_guide_card_"] button:focus-visible {{ outline: 3px solid {t['focus']}; outline-offset: 2px; }}
</style>'''


def render_header(st, app_name='Ligações metálicas'):
    """Inject branded shell only; callers own their optional theme switch."""
    st.markdown(shell_css(), unsafe_allow_html=True)
    st.markdown('<div class="lro-shell-header"><div class="lro-shell-eyebrow">LRO · Engenharia estrutural</div>'
                '<h1>' + escape(app_name) + '</h1><p>Catálogo de ligações · entradas, vistas e verificações do projeto</p></div>',
                unsafe_allow_html=True)


def render_project_heading(st, family_label):
    st.markdown('<div class="lro-shell-project"><strong>Projeto atual</strong> · '
                + escape(family_label) + '<br>As entradas, vistas e verificações abaixo pertencem ao formulário aberto.</div>',
                unsafe_allow_html=True)
