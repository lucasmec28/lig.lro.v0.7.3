"""Catalogue-only navigation for the nineteen implemented connection families.

This module never inspects a project, draft, physical widget or result. Search
labels describe the nominal catalogue domain, not compatibility or approval.
Only the explicit open callback can write the existing dispatcher selector.
Streamlit is imported solely by the rendering function.
"""
from dataclasses import dataclass
from typing import MutableMapping


@dataclass(frozen=True)
class Family:
    id: str
    route_select_value: str
    interface_tags: tuple[str, ...]
    model_tag: str
    scope_caption: str


INTERFACES = (('base_plate', 'Placa de base'), ('column_flange', 'Viga–mesa de coluna'), ('column_web', 'Viga–alma de coluna'), ('beam_web', 'Viga–viga · alma da viga de apoio'), ('w_splice', 'Emenda entre perfis W coaxiais'), ('axial_double_angle_gusset', 'Barra 2L–chapa de nó'), ('axial_single_angle_plate', 'Barra 1L–chapa retangular'), ('welded_angle_gusset_flange', 'Barra 1L–chapa de nó–mesa W'), ('welded_double_angle_gusset_flange', 'Barra 2L-T–chapa de nó–mesa W'), ('welded_opposed_angle_gusset_flange', 'Barra 2L opostas–chapa de nó–mesa W'), ('bolted_angle_gusset_flange', 'Barra 1L / 2L-T / 2L opostas parafusada–chapa de nó–mesa W'), ('corner_gusset_strong_axis', 'Canto viga–pilar · gusset em duas mesas'))

MODELS = (('nominal_no_external_moment', 'Rotulada / flexível · sem momento externo'), ('moment_intent', 'Engastada · intenção do modelo'), ('axial_tension', 'Tração axial'), ('conventional_nmv', 'N/M/V · modelo convencional'), ('welded_nmv', 'N/M/V · CJP soldada'), ('corner_complete_cuts', 'Diagonal + cortes concorrentes completos'))

FAMILIES = (
    Family('single_plate', 'Single plate', ('column_flange', 'beam_web'), 'nominal_no_external_moment', 'Chapa simples: viga na mesa de coluna ou na alma de viga perpendicular. Sem M externo. N de compressão e interação fora do plano do apoio conservam as exclusões atuais. Complemento e enrijecedor oposto só em alma de viga, sem ganho de resistência.'),
    Family('column_web_double_cover', 'Alma de coluna · duas talas', ('column_web',), 'nominal_no_external_moment', 'Viga na alma de coluna: nervura, duas talas e quatro enrijecedores horizontais; N/V, rótula nominal no meio da folga. Qualificação da rotação/flexibilidade e estabilidade do conjunto permanece pendente.'),
    Family('end_plate_pinned', 'End plate · rotulada', ('column_flange',), 'nominal_no_external_moment', 'End plate de altura total na mesa de coluna, N/V sem M externo; rótula nominal e qualificação local incompleta continuam explícitas.'),
    Family('end_plate_moment', 'End plate · engastada', ('column_flange',), 'moment_intent', 'End plate de momento na mesa de coluna: variantes internas 4E, 4ES CJP e 8ES CJP com 16 parafusos. 4E mantém extensões e linhas intermediárias próprias; 4ES/8ES exigem simetria e nervuras. Não certifica rigidez fora do domínio DG39.'),
    Family('base_plate_fixed', 'Placa de base · engastada', ('base_plate',), 'moment_intent', 'Base Tipo 1, quatro chumbadores externos, N/M/V. Intenção de engaste não verifica rigidez. Arquivo Tipo 1 legado com indicação rotulada mantém geometria, momento, aviso e rota externa; nunca vira Tipo 2.'),
    Family('base_plate_pinned', 'Placa de base · rotulada', ('base_plate',), 'nominal_no_external_moment', 'Base Tipo 2, quatro chumbadores internos, N/V sem M aplicado. Momento local de chave é conservado; intenção rotulada não certifica rotação.'),
    Family('w_splice_m004', 'Emenda W · M004 · tração axial', ('w_splice',), 'axial_tension', 'Dois W idênticos e coaxiais, oito talas balanceadas, tração axial estática. M=V=T=0; não qualifica continuidade rígida.'),
    Family('w_splice_conventional', 'Emenda W · convencional · N/M/V', ('w_splice',), 'conventional_nmv', 'Dois W idênticos e coaxiais, oito talas. N/M integralmente nas mesas; V/Ve na alma. Não certifica rigidez ou continuidade de pórtico; não converter para M004.'),
    Family('double_angle_r016', 'Cantoneiras duplas · R016 · cortante', ('column_flange',), 'nominal_no_external_moment', 'Duas cantoneiras parafusadas à alma de viga W sem recortes e à mesa de pilar W; V estático, N=M=T=0. Interfaces alternativas presentes no formulário são fora do domínio.'),
    Family('welded_double_angle_r015', 'Cantoneiras duplas · R015 · soldadas/parafusadas', ('column_flange',), 'nominal_no_external_moment', 'Duas cantoneiras soldadas em U à alma de viga W sem recortes e parafusadas à mesa de pilar W; V estático, N=M=T=0. Apoio na alma exige outro modelo.'),
    Family('coped_double_angle_r017', 'Cantoneiras duplas · R017 · viga recortada', ('beam_web',), 'nominal_no_external_moment', 'Duas cantoneiras parafusadas, viga W com recortes superior/inferior iguais, apoio na alma íntegra interior de viga W perpendicular; V estático, N=M=T=0. Não suporta alma de coluna.'),
    Family('axial_double_angle_bolted', 'Ligação axial 2L–chapa de nó · parafusada', ('axial_double_angle_gusset',), 'axial_tension', 'Duas cantoneiras iguais em faces opostas de chapa retangular real, uma linha de parafusos passantes e dois planos de corte. Tração estática no eixo nominal dos parafusos, NBR 6.1.8.2; corte terminal centrado com N e M=V=0. Não verifica raiz da chapa, soldas ou apoio a jusante.'),
    Family('axial_single_angle_bolted', 'Ligação axial 1L–chapa retangular · parafusada', ('axial_single_angle_plate',), 'axial_tension', 'Uma cantoneira de abas iguais em uma face de chapa retangular real, uma linha de parafusos e um plano de corte. Tração estática no eixo nominal comum, NBR 6.1.8.2 e 6.5.2; excentricidades físicas em y e z omitidas, não canceladas. Corte terminal nominal N e M=V=0; não verifica raiz, apoio nem modelo de carga no CG físico.'),
    Family('welded_w_splice', 'Emenda W · soldada · N/M/V', ('w_splice',), 'welded_nmv', 'Dois W laminados idênticos e coaxiais, para vigas ou pilares, CJP nas duas mesas e na alma remanescente. N/M/V assinados no grupo elástico publicado, aberturas e seções receptoras reais. Exige dados, detalhe e WPS declarados; não certifica rigidez, estabilidade global ou montagem.'),
    Family('welded_angle_gusset', 'Ligação 1L–gusset–mesa W · soldada', ('welded_angle_gusset_flange',), 'axial_tension', 'Uma L100×100×12 em uma face da chapa retangular, duas soldas longitudinais e raiz dupla na mesa exterior de W laminado, longitudinal e centrada na alma. Tração estática com excentricidade e momento real da raiz; verifica cantoneira, chapa, soldas e região local receptora. Viga e pilar conservam o mesmo cálculo local. Geometria deve atender às condições do modelo; alma direta, compressão, ações espaciais e 2L fora desta rota. Não aprova o apoio global nem libera fabricação.'),
    Family('welded_double_angle_gusset', 'Ligação 2L-T–gusset–mesa W · soldada', ('welded_double_angle_gusset_flange',), 'axial_tension', 'Duas L idênticas em T simétrico, uma em cada face da chapa única, talões alinhados e abas livres para lados opostos. Quatro filetes longitudinais, N total do par e N/2 por L; chapa, raiz dupla e mesa exterior W recebem N integral. Tração estática com shear lag individual, excentricidade e momento real da raiz preservados. Raiz longitudinal centrada na alma; viga e pilar usam o mesmo cálculo local. Sem parafusos, assimetria, compressão ou arranjo pelos vértices (><) dentro desta rota T; usar sua família separada. Não verifica estabilidade global nem libera fabricação.'),
    Family('welded_opposed_angle_gusset', 'Ligação 2L opostas–gusset–mesa W · soldada', ('welded_opposed_angle_gusset_flange',), 'axial_tension', 'Duas L idênticas opostas pelos vértices (><), h=tg, quatro filetes projetados distintos. N/2 por L; chapa única, raiz dupla e W recebem N integral. Método plano estático NBR6.1.8.2/6.5.2, com binários locais idealizados fora, nunca declarados cancelados. Sem compressão, fadiga, ações espaciais, enchimentos ou apoio direto na alma. Não aprova estabilidade global ou fabricação.'),
    Family('bolted_angle_gusset', 'Ligação 1L / 2L-T–gusset–mesa W · parafusada completa', ('bolted_angle_gusset_flange',), 'axial_tension', 'Uma L, par simétrico2L-T ou par de L opostas(><), com gusset retangular perfurado e raiz dupla na mesa exteriorW. 1L usa uma linha em corte simples; T usa uma linha de parafusos passantes compartilhados em corte duplo; opostas usam duas linhas distintas e 2n parafusos em corte simples. Contato, líquido efetivo, blocos, Whitmore, raiz e W locais; triagens nominais perfuradas complementares. Exige envelope real de talão e ferramenta. Tração estática e raiz única; sem aprovação global.'),
    Family('corner_gusset', 'Ligação de canto 2L-T–gusset–viga/pilar · soldada', ('corner_gusset_strong_axis',), 'corner_complete_cuts', 'Uma L ou par simétrico 2L-T, soldado ou com uma linha de parafusos, na chapa de canto com duas raízes: mesas da viga e do pilar no eixo forte. Viga com mesas CJP e alma em filetes; continuidade horizontal em cada mesa. Caso completo com cortes assinados da viga e do pilar superior; corte inferior derivado. Tração estática da diagonal, compressão local real verificada nos receptores e continuidade. Gusset comprimido ou distribuição excêntrica ainda não qualificados; não libera fabricação ou estabilidade global.'),
)

def route_label(value):
    """Presentation label only; preserve the existing native route selector key."""
    if value == 'Ligação 1L / 2L-T–gusset–mesa W · parafusada completa':
        return 'Ligação 1L / 2L-T / 2L opostas–gusset–mesa W · parafusada completa'
    if value == 'Ligação de canto 2L-T–gusset–viga/pilar · soldada':
        return 'Canto 1L / 2L-T–gusset–viga/pilar · soldada ou parafusada'
    return value


PERMANENT_NOTE = (
    'Os filtros ajudam a encontrar uma família. Não configuram o projeto aberto '
    'nem comprovam rigidez ou capacidade de rotação. Confirme o apoio real e o '
    'modelo no formulário da família e confira seu escopo e suas verificações.'
)
OUTSIDE_NOTE = (
    'A família aberta está fora destes filtros. '
    'O projeto continua aberto sem alterações.'
)
EMPTY_NOTE = 'Nenhuma família implementada para estes filtros'
STATIC_NOTES = {
    'single_plate': (
        'Esta família atende mesa de coluna e alma de viga. O filtro não escolhe '
        'nem altera o apoio do projeto. Confirme ‘Tipo de apoio’ no formulário.'
    ),
    'base_plate_fixed': (
        'Projetos legados com indicação rotulada permanecem no modelo Tipo 1 '
        'de chumbadores externos. Escolher um filtro não os converte em base '
        'rotulada Tipo 2.'
    ),
    'column_web_double_cover': (
        'N/V, rótula nominal; qualificação da rotação/flexibilidade e '
        'estabilidade do conjunto pendente.'
    ),
}


def search_families(interface='all', model='all'):
    """Pure AND search, unique families in the unchanged direct-selector order."""
    return tuple(family for family in FAMILIES
                 if (interface == 'all' or interface in family.interface_tags)
                 and (model == 'all' or model == family.model_tag))


def available_models(interface='all'):
    """Category IDs present in the static interface catalogue, excluding all."""
    present = {family.model_tag for family in search_families(interface)}
    return tuple(model_id for model_id, _ in MODELS if model_id in present)


def interface_changed(state: MutableMapping):
    """Only search state changes; an unavailable model resets to the wildcard."""
    model = state.get('nav_guide_model', 'all')
    cleared = model != 'all' and model not in available_models(
        state.get('nav_guide_interface', 'all'))
    if cleared:
        state['nav_guide_model'] = 'all'
    state['nav_guide_model_cleared'] = cleared
    state['nav_guide_candidate'] = 'none'


def model_changed(state: MutableMapping):
    state['nav_guide_candidate'] = 'none'
    state['nav_guide_model_cleared'] = False


def clear_filters(state: MutableMapping):
    state['nav_guide_interface'] = 'all'
    state['nav_guide_model'] = 'all'
    state['nav_guide_candidate'] = 'none'
    state['nav_guide_model_cleared'] = False


def open_family(state: MutableMapping):
    """Validate at click time; run before widgets on the normal Streamlit rerun."""
    candidate = state.get('nav_guide_candidate', 'none')
    for family in search_families(state.get('nav_guide_interface', 'all'),
                                  state.get('nav_guide_model', 'all')):
        if family.id == candidate:
            if state.get('connection_family') != family.route_select_value:
                state['connection_family'] = family.route_select_value
                return True
            return False
    return False


def render():
    import streamlit as st

    state = st.session_state
    for key, value in (('nav_guide_interface', 'all'), ('nav_guide_model', 'all'),
                       ('nav_guide_candidate', 'none'),
                       ('nav_guide_model_cleared', False)):
        state.setdefault(key, value)

    with st.sidebar.expander('Encontrar uma família · seleção guiada', expanded=False):
        st.caption(PERMANENT_NOTE)
        interface_labels = dict(INTERFACES)
        model_labels = dict(MODELS)
        interface = state['nav_guide_interface']
        model = state['nav_guide_model']
        # Inconsistent/stale search state has no routing fallback. Recovery
        # changes only the guide via its explicit clear action.
        valid_interface = interface in ('all', *interface_labels)
        valid_model = model in ('all', *available_models(interface))
        if valid_interface:
            st.selectbox('1 · Onde é a ligação?', ['all', *interface_labels],
                         format_func=lambda value: 'Todos' if value == 'all' else interface_labels[value],
                         key='nav_guide_interface', on_change=interface_changed, args=(state,))
        if valid_interface and valid_model:
            st.selectbox('2 · Modelo de ligação', ['all', *available_models(interface)],
                         format_func=lambda value: 'Todos os modelos' if value == 'all' else model_labels[value],
                         key='nav_guide_model', on_change=model_changed, args=(state,))
        if state.get('nav_guide_model_cleared', False):
            st.caption('O filtro de modelo foi limpo para “Todos os modelos”, '
                       'pois a nova interface não contém a categoria anterior.')

        results = search_families(interface, model)
        if state.get('connection_family') not in {family.route_select_value for family in results}:
            st.info(OUTSIDE_NOTE)
        result_by_id = {family.id: family for family in results}
        if results and valid_interface and valid_model:
            if state['nav_guide_candidate'] not in ('none', *result_by_id):
                state['nav_guide_candidate'] = 'none'
            st.selectbox('3 · Família disponível', ['none', *result_by_id],
                         format_func=lambda value: 'Selecione uma família' if value == 'none'
                         else route_label(result_by_id[value].route_select_value),
                         key='nav_guide_candidate')
            selected = result_by_id.get(state['nav_guide_candidate'])
            if selected is not None:
                st.caption(selected.scope_caption)
                if selected.id in STATIC_NOTES:
                    st.caption(STATIC_NOTES[selected.id])
        else:
            st.warning(EMPTY_NOTE)
            selected = None

        already_open = selected is not None and selected.route_select_value == state.get('connection_family')
        st.button('Família já aberta' if already_open else 'Abrir família',
                  key='nav_guide_open', disabled=selected is None or already_open,
                  on_click=open_family, args=(state,))
        st.button('Limpar filtros', key='nav_guide_clear', on_click=clear_filters, args=(state,))
