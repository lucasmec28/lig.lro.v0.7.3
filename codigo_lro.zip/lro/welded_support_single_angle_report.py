"""Editable, independently scoped calculation record for welded-support 1L.

The public exporter always evaluates the current input. ``result`` is accepted
only for API compatibility, is never read, and is never serialized or embedded.
Presentation formatting must not feed back into the input or the calculation.
"""
from dataclasses import fields, is_dataclass
from io import BytesIO
from math import pi, sqrt

from docx import Document
from docx.enum.section import WD_ORIENT, WD_SECTION_START
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor

from .angle_catalog import get_angle
from .display_precision import calculated_text
from .models import BOLTS, STEELS, finite_real
from .report import BRAND, _math, frac, group, hyperlink, number, power, radical, sub, table
from .welded_support_single_angle import (
    COMPONENT_VERSION, CONNECTION_TYPE, EXCLUSIONS, NBR, SCOPE,
    WeldedSupportSingleAngle, evaluate, input_errors,
)


STATUS = {
    'INVALID_INPUT': 'Entrada inválida',
    'INVALID_GEOMETRY': 'Geometria inválida',
    'NUMERICAL_FAILURE': 'Falha numérica',
    'OUTSIDE_SUPPORTED_SCOPE': 'Fora do domínio implementado',
    'VERIFIED_SUBCHECK_FAIL': 'Verificação resistente não atendida',
    'DETAIL_FAIL': 'Requisito de detalhamento não atendido',
    'ENGINEERING_MODEL_PENDING': 'Verificação completa pendente',
    'COMPLETE_CHECKS_PASS_WITHIN_SCOPE': 'Verificações locais atendidas no domínio declarado',
}
LABELS = {
    'project': 'Projeto', 'kind': 'Interface receptora', 'side': 'Lado da cantoneira',
    'beam_leg': 'Aba junto à alma b_viga em mm', 'support_leg': 'Aba na mesa b em mm',
    't': 'Espessura real da cantoneira t em mm', 'root_radius': 'Raio interno real em mm',
    'length': 'Altura da cantoneira H em mm', 'angle_top': 'Topo L abaixo do topo da viga em mm',
    'beam_gauge': 'Face do apoio até eixo dos parafusos e em mm',
    'web_rows': 'Número de parafusos na coluna', 'web_columns': 'Colunas de parafusos na alma',
    'web_pitch': 'Passo vertical p em mm', 'web_end_top': 'Borda superior L em mm',
    'gap': 'Folga ponta da viga até face do pilar em mm',
    'weld_leg': 'Perna do filete w em mm', 'top_return': 'Retorno superior físico em mm',
    'weld_layout': 'Arranjo de soldas', 'weld_process': 'Processo e eletrodo',
    'reinforced_weld_edge': 'Exceção de borda reforçada documentada pelo responsável',
    'electrode_fuw': 'Resistência fuw em MPa', 'beam_steel': 'Aço da viga',
    'support_steel': 'Aço do pilar', 'angle_steel': 'Aço da cantoneira única',
    'bolt': 'Classe dos parafusos', 'db': 'Diâmetro do parafuso db em mm',
    'hole_diameter': 'Diâmetro físico do furo dh em mm', 'hole_type': 'Tipo de furo',
    'drilled': 'Furação por broca documentada',
    'web_threads_excluded': 'Rosca excluída do único plano de corte',
    'V': 'V real com sinal em N', 'N': 'N externo real em N',
    'M': 'M externo real em N mm', 'torsion': 'T externo real em N mm',
    'cope': 'Recorte da viga', 'static': 'Ações estáticas',
    'normal_combination': 'Combinação última normal',
    'no_slip_required': 'Ausência de deslizamento exigida',
    'support_continuous': 'Mesa do pilar contínua na região',
    'tool_radius': 'Raio do envelope de cabeça, porca, arruela e ferramenta em mm',
    'fabrication_clearance': 'Folga adicional de fabricação em mm',
    'exposure': 'Exposição', 'notes': 'Observações',
    'angle_catalog_id': 'Identificador de catálogo da cantoneira',
    'angle_root_source': 'Fonte do raio de concordância',
    'angle_root_confirmed': 'Raio de concordância confirmado',
}
SEVERITY = {
    'invalid_input': 'Entrada inválida', 'invalid_geometry': 'Geometria inválida',
    'numerical_failure': 'Falha numérica', 'unsupported_scope': 'Fora do domínio',
    'detail_fail': 'Detalhamento não atendido', 'access_pending': 'Acesso pendente',
    'engineering_pending': 'Pendência técnica', 'info': 'Informação',
}


def _mapping(value):
    return value if isinstance(value, dict) else {}


def _value(value):
    if isinstance(value, bool):
        return 'sim' if value else 'não'
    if value is None:
        return 'não disponível'
    if isinstance(value, (int, float)):
        return number(value, 2) if finite_real(value) else str(value) + ' (inválido)'
    if isinstance(value, (tuple, list)):
        return '(' + '; '.join(_value(item) for item in value) + ')'
    if isinstance(value, dict):
        return '; '.join(str(key) + '=' + _value(item) for key, item in value.items())
    return str(value)


def _kn(value):
    return _value(value / 1000.) if finite_real(value) else 'não disponível'


def _flatten(value, path=''):
    if isinstance(value, dict):
        for key, child in value.items():
            yield from _flatten(child, path + '.' + str(key) if path else str(key))
    elif isinstance(value, (tuple, list)) and any(isinstance(x, (dict, tuple, list)) for x in value):
        for index, child in enumerate(value):
            yield from _flatten(child, path + '[' + str(index) + ']')
    else:
        yield path, _value(value)


def _approved(result):
    blockers = {'invalid_input', 'invalid_geometry', 'numerical_failure', 'unsupported_scope',
                'detail_fail', 'access_pending', 'engineering_pending', 'error', 'pending'}
    checks = result.get('checks') or []
    return (result.get('status') == 'COMPLETE_CHECKS_PASS_WITHIN_SCOPE'
            and result.get('global_pass') is True
            and _mapping(result.get('geometry')).get('valid') is True
            and _mapping(result.get('summary')).get('complete_checks') is True
            and bool(checks) and all(row.get('status') == 'PASS' for row in checks)
            and not any(row.get('severity') in blockers for row in result.get('issues', [])))


def _heading(doc, text, level=1):
    return doc.add_paragraph(text, style='Heading ' + str(level))


def _tab(doc, headers, rows, widths, size=8.2):
    result = table(doc, headers, rows, widths)
    for row in result.rows:
        for cell in row.cells:
            for margin in cell._tc.xpath('./w:tcPr/w:tcMar/w:top | ./w:tcPr/w:tcMar/w:bottom'):
                margin.set(qn('w:w'), '40')
            for paragraph in cell.paragraphs:
                paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT
                for run in paragraph.runs:
                    run.font.size = Pt(size)
    gap = doc.paragraphs[-1]
    gap.paragraph_format.space_before = gap.paragraph_format.space_after = Pt(0)
    gap.paragraph_format.line_spacing = Pt(2)
    return result


def _section(doc, landscape=False):
    section = doc.add_section(WD_SECTION_START.NEW_PAGE)
    section.orientation = WD_ORIENT.LANDSCAPE if landscape else WD_ORIENT.PORTRAIT
    section.page_width = Inches(11.69 if landscape else 8.27)
    section.page_height = Inches(8.27 if landscape else 11.69)
    section.top_margin = section.bottom_margin = Inches(.55)
    section.left_margin = section.right_margin = Inches(.60)
    return section


def _equations(doc, *expressions):
    for expression in expressions:
        _math(doc, group(expression))


def _inputs(doc, c):
    _heading(doc, 'Dados de entrada completos')
    doc.add_paragraph('Unidades nativas: N, mm, MPa e N mm. As apresentações numéricas têm no máximo duas casas decimais; '
                      'valores muito pequenos usam notação científica. A entrada e os resultados permanecem sem arredondamento. '
                      'Designações, fontes e observações são conservadas como texto.')
    if not isinstance(c, WeldedSupportSingleAngle):
        doc.add_paragraph('Objeto de entrada recebido: ' + repr(c))
        return
    _heading(doc, 'Perfis da viga e do pilar', 2)
    doc.add_paragraph('d, bf, tw, tf e clear em mm; area em mm²; mass em kg/m. A mesa receptora usa tf do pilar, '
                      'uma única espessura física; tw da viga pertence apenas à alma apoiada.')
    for key, label in (('beam', 'Viga apoiada'), ('support', 'Pilar receptor')):
        profile = getattr(c, key)
        rows = [(label + ' · ' + f.name, _value(getattr(profile, f.name))) for f in fields(profile)] if is_dataclass(profile) else [(label, _value(profile))]
        _tab(doc, ['Campo do perfil', 'Valor declarado'], rows, [3.15, 3.92])
    _heading(doc, 'Geometria ações fabricação e montagem', 2)
    rows = [(LABELS.get(f.name, f.name) + '\n' + f.name, _value(getattr(c, f.name)))
            for f in fields(c) if f.name not in ('beam', 'support')]
    _tab(doc, ['Grandeza e identificador de entrada', 'Valor declarado'], rows, [4.25, 2.82])
    if c.angle_catalog_id and not input_errors(c):
        record = get_angle(c.angle_catalog_id)
        if record:
            doc.add_paragraph('Fonte do catálogo: ' + record['source'] + '. Raio interno manual declarado: ' +
                              _value(c.root_radius) + ' mm. Fonte independente: ' + (c.angle_root_source or 'pendente') +
                              '. A seleção não certifica o aço ou a fabricação e não amplia o domínio do modelo.')
    _heading(doc, 'Materiais e coeficientes', 2)
    rows = []
    for role, key in (('Cantoneira única', 'angle_steel'), ('Alma da viga', 'beam_steel'), ('Mesa do pilar', 'support_steel')):
        name = getattr(c, key)
        steel = STEELS.get(name) if isinstance(name, str) else None
        rows.append((role, _value(name), _value(getattr(steel, 'fy', None)), _value(getattr(steel, 'fu', None))))
    _tab(doc, ['Componente', 'Aço', 'fy MPa', 'fu MPa'], rows, [1.65, 3.02, 1.2, 1.2])
    fub = BOLTS.get(c.bolt) if isinstance(c.bolt, str) else None
    doc.add_paragraph('Parafusos: fub=' + _value(fub) + ' MPa. Metal de solda: fuw=' + _value(c.electrode_fuw) +
                      ' MPa. Coeficientes para combinações normais: γa1=1,10 e γa2=1,35. E=200.000 MPa na seleção geométrica e no cortante da alma.')
    doc.add_paragraph('A fonte de propriedades e o raio real devem corresponder ao produto adquirido. Um nome de perfil '
                      'não substitui a conferência das dimensões, do raio, do aço, da faixa de espessura e das ferragens.')
    _heading(doc, 'Premissas fixas', 2)
    _tab(doc, ['Premissa do modelo', 'Valor'], list(_flatten(c.fixed_assumptions)), [3.2, 3.87])


def _loads_and_scope(doc, c, result):
    _heading(doc, 'Caminho das forças e domínio convencional')
    doc.add_paragraph('Há uma cantoneira laminada em uma face da alma da viga. Os parafusos atravessam a aba e uma única '
                      'alma, em um único plano de corte. A aba perpendicular está soldada à MESA DO PILAR. A montagem '
                      'considera soldagem da cantoneira em oficina e parafusamento da viga em campo, contato firme sem calços '
                      'e folga positiva na ponta da viga. Não existem parafusos no apoio, solda na alma da viga ou solda no talão.')
    doc.add_paragraph('O detalhe convencional publicado em AISC P901 v16, exemplo II.A-29, fornece a hipótese de flexibilidade '
                      'e a distribuição direta dos parafusos no domínio restrito. As resistências dos componentes são calculadas '
                      'pela NBR 8800:2024 com Errata 1:2025. Essa combinação não transforma uma tabela ICR AISC em resistência NBR '
                      'nem atribui à NBR uma dispensa geral da excentricidade de cantoneiras simples.')
    doc.add_paragraph('V positivo significa descendente. V nulo ou ascendente, qualquer N, M ou T externo diferente de zero, '
                      'reversão, fadiga ou impacto estão fora desta rota e permanecem como informados. O valor absoluto de V '
                      'não é empregado para fazer uma ação excluída parecer admissível. As ações já são de cálculo, sem majoração adicional.')
    lm = _mapping(result.get('load_model'))
    _tab(doc, ['Ação preservada ou demanda de projeto', 'Valor', 'Unidade'], [
        ('V real com sinal', _value(getattr(c, 'V', None)), 'N'),
        ('N externo real', _value(getattr(c, 'N', None)), 'N'),
        ('M externo real', _value(getattr(c, 'M', None)), 'N mm'),
        ('T externo real', _value(getattr(c, 'torsion', None)), 'N mm'),
        ('V real', _kn(getattr(c, 'V', None)), 'kN'),
        ('V adotado nas verificações locais', _kn(lm.get('Vd_N')), 'kN'),
    ], [4.07, 1.5, 1.5])
    _math(doc, group(sub('V', 'd'), ' = max(', sub('V', 'real'), '; 45 kN), somente no domínio Vreal > 0'))
    _math(doc, group(sub('F', 'L'), ' = ', sub('V', 'd'), ';  ', sub('F', 'parafuso'), ' = ', frac(sub('V', 'd'), 'n'), ';  nplanos = 1'))
    doc.add_paragraph('A força mínima de 45 kN da ligação é aplicada uma única vez ao conjunto, conforme NBR 6.1.5.2. '
                      'A cantoneira única e o grupo L recebem Vd inteiro. Não se duplica o mínimo, não se divide V por dois '
                      'e não se substitui a reação real do modelo global pelo mínimo local. Os índices real e adotado são separados.')
    if lm:
        _tab(doc, ['Modelo de ações e referência', 'Valor'], list(_flatten(lm)), [3.5, 3.57])
    else:
        doc.add_paragraph('Não há demanda resistente adotada para esta entrada: o motor interrompeu a avaliação antes do modelo resistente. '
                          'As fórmulas deste memorial documentam a rota, mas não aprovam uma configuração bloqueada.')
    doc.add_paragraph('Eixos do transporte ao modelo global: X normal à face do pilar, positivo da linha central do pilar para '
                      'a face carregada; Y vertical para cima; Z completa o sistema destro. Na face, F=(0; −Vreal; 0). '
                      'Do centro do pilar até a face, r=(d_pilar/2; 0; 0), logo r×F=(0; 0; −Vreal d_pilar/2). '
                      'Esse transporte só deve ser incluído se ainda não existir no modelo global. Não é um momento de engaste '
                      'adicionado à ligação convencional. Os eixos locais do grupo de solda são definidos separadamente.')
    _heading(doc, 'Limites da qualificação desta implementação', 2)
    doc.add_paragraph('O domínio inicial exige uma linha de 2 a 4 parafusos, e≤76,20 mm medido da face do apoio ao eixo dos '
                      'parafusos, meia alma≤6,35 mm, abas de pelo menos 63,50 mm, espessura de 6,35 mm até o valor exato de '
                      '3/8 in, b_apoio/t≥8 e abas geometricamente robustas. Os limites adicionais são escolhas restritivas '
                      'de qualificação da implementação, e não critérios normativos de ductilidade rotacional.')
    _equations(doc, 'b/t ≤ 0,45 √(E/fy)  [triagem geométrica desta implementação]')
    doc.add_paragraph('A expressão 0,45√(E/fy) vem da Tabela 4, grupo AL3, da NBR, relativa à compressão longitudinal de '
                      'cantoneiras. Seu uso aqui é apenas triagem conservadora de perfis usuais. Não demonstra, por si, '
                      'rotação, ductilidade ou estabilidade da placa sob o campo local da ligação. O limite de borda '
                      'w≤t−1,50 mm também não é prova de ductilidade. A exceção explícita de borda reforçada da NBR '
                      '6.2.6.2.2(b) permite até w≤t apenas quando declarada e documentada pelo responsável. Essa declaração '
                      'não cria reforço automaticamente e não aumenta a resistência calculada. Abas iguais são admissíveis '
                      'se todas as condições forem atendidas.')
    doc.add_paragraph('O retorno superior é físico, curto, pelo menos 2w, no máximo 4w e no máximo metade da aba, mantendo '
                      'aberta a região junto ao talão. Ele não participa do comprimento, centroide, inércia ou capacidade da '
                      'solda resistente. O detalhe não admite solda de topo completa nem solda no talão.')


def _geometry(doc, result):
    _heading(doc, 'Geometria derivada e verificações de detalhe')
    g = _mapping(result.get('geometry'))
    if not g:
        doc.add_paragraph('Geometria derivada não produzida para esta entrada. Nenhum detalhe é considerado atendido por omissão.')
        return
    doc.add_paragraph('Os segmentos de solda usam coordenadas (z global; y para cima desde a borda inferior da cantoneira), '
                      'com o plano médio da alma da viga em z=0. O retorno superior aparece '
                      'apenas nos segmentos físicos. Os y dos furos são medidos para baixo a partir do topo da viga. '
                      'As dimensões derivadas em mm, contagens e indicadores constam a seguir.')
    _tab(doc, ['Grandeza derivada', 'Valor'], list(_flatten({k: v for k, v in g.items() if k != 'checks'})), [3.65, 3.42])
    doc.add_paragraph('Cada condição abaixo é examinada separadamente. Condições de acesso, de fabricação, de domínio '
                      'e de resistência não se substituem. Critérios adimensionais incluem contagens e relações de esbeltez; '
                      'os demais comprimentos estão em mm. Os testes usam os valores completos, antes da formatação.')
    _tab(doc, ['Critério e referência', 'Medido', 'Exigência', 'Estado'], [
        (row['id'] + '\n' + row.get('reference', ''), _value(row.get('actual')),
         row.get('relation', '') + ' ' + _value(row.get('limit')),
         'Atende' if row.get('passed') else 'Não atende')
        for row in g.get('checks', [])
    ], [3.6, .88, 1.15, 1.44], size=7.8)
    doc.add_paragraph('dh é o furo físico empregado no contato e no desenho. dn é a dedução líquida baseada na Tabela 14 '
                      'e no acréscimo de 2 mm quando a furação por broca não está documentada. A ponta inferior da cantoneira '
                      'é a borda carregada para V descendente. Na alma, a reação da interface tem sentido oposto, para cima; '
                      'a alma continua acima do primeiro furo e não recebe uma borda livre vertical fictícia. '
                      'A folga da ponta da viga é distinta de e.')


def _weld(doc, result):
    _heading(doc, 'Grupo L da solda na mesa do pilar')
    doc.add_paragraph('Para a derivação, u vai do toe externo ao talão e y sobe da borda inferior. '
                      'A solda vertical liga (0;0) a (0;H), e a inferior liga (0;0) a (b;0). A força vertical '
                      'F=−V atua em uL=b+tw_viga/2. Este u local é distinto do eixo global Z. O retorno superior '
                      'não integra estas duas linhas. No lado espelhado, a formulação em u e a capacidade são invariantes.')
    _math(doc, group('L = H + b;  ', sub('u', 'c'), ' = ', frac(power('b'), '2L'), ';  ', sub('y', 'c'), ' = ', frac(power('H'), '2L')))
    _math(doc, group('J = ', frac(group(power('H', '3'), ' + ', power('b', '3')), '3'), ' − L(', power(sub('u', 'c')), ' + ', power(sub('y', 'c')), ')'))
    _equations(doc, 'uL = b + tw,viga/2;  eu = uL − uc;  mu = F eu',
               'qu(u,y) = −mu(y − yc)/J;  qy(u,y) = F/L + mu(u − uc)/J')
    _math(doc, group(sub('q', 'max'), ' = max extremos ', radical(group(power(sub('q', 'u')), ' + ', power(sub('q', 'y'))))))
    doc.add_paragraph('Os números do motor e as tabelas abaixo usam (z global; y local). Para s=+1 em positive_z '
                      'e s=−1 em negative_z: ztoe=s(tw/2+b), u=s(ztoe−z), zc=s(tw/2+b−uc) e zL=0. '
                      'As trações se relacionam por qz=−s qu. O momento escalar do kernel é mzy=(zL−zc)F=−Mx global, '
                      'e não um Mz global. A seguir, os campos nativos x_mm e qx significam, respectivamente, z e qz.')
    doc.add_paragraph('O campo é afim em cada segmento reto; a norma máxima ocorre em uma extremidade. O motor verifica '
                      'as extremidades exatas, sem discretização e sem coeficiente de centro instantâneo de rotação. '
                      'A excentricidade no plano da solda permanece. Não se acrescenta um momento fora do plano de outro modelo '
                      'à hipótese convencional flexível adotada.')
    _math(doc, group('a = ', frac('w', radical('2')), ';  ', sub('q', 'Rd'), ' = ', frac(group('0,60 ', sub('f', 'uw'), ' a'), sub('γ', 'a2'))))
    _math(doc, group(sub('V', 'Rd,solda'), ' = ', frac(sub('q', 'Rd'), group(sub('q', 'max'), '(F=−1 N)'))))
    doc.add_paragraph('A garganta uniforme usa w/√2. Não há aumento direcional de resistência. A referência resistente é '
                      'NBR Tabela 9; o método elástico convencional é documentado em P901 II.A-27. O exemplo II.A-29 '
                      'com coeficiente ICR corrigido não é alvo de ajuste desta capacidade elástica conservadora.')
    weld = _mapping(result.get('welds'))
    if not weld:
        doc.add_paragraph('Grupo resistente não calculado para a entrada atual.')
        return
    unit = _mapping(weld.get('per_unit_force'))
    actual = _mapping(weld.get('actual'))
    _tab(doc, ['Grandeza da solda', 'Valor'], [
        ('Perna w em mm', _value(weld.get('leg_mm'))),
        ('Garganta a em mm', _value(weld.get('throat_mm'))),
        ('Resistência linear qRd em N/mm', _value(weld.get('line_resistance_N_per_mm'))),
        ('Comprimento efetivo L em mm', _value(unit.get('total_length_mm'))),
        ('Centroide zc global em mm', _value(unit.get('centroid_x_mm'))),
        ('Centroide yc em mm', _value(unit.get('centroid_y_mm'))),
        ('Inércia de linha J em mm³', _value(unit.get('J_line_mm3'))),
        ('Ponto de carga (z; y) em mm', _value(unit.get('load_point_mm'))),
        ('Excentricidade zL−zc em mm', _value(unit.get('eccentricity_x_mm'))),
        ('Momento escalar mzy unitário em N mm', _value(unit.get('moment_about_centroid_Nmm'))),
        ('Mx global no centroide para V real em N mm', _value(weld.get('actual_centroid_Mx_Nmm'))),
        ('Mx global na origem para V real em N mm', _value(weld.get('actual_origin_Mx_Nmm'))),
        ('qmax para F=−1 N em N/mm', _value(unit.get('max_resultant_N_per_mm'))),
        ('qmax para V real em N/mm', _value(actual.get('max_resultant_N_per_mm'))),
        ('Retorno superior creditado', _value(weld.get('top_return_credited'))),
    ], [4.1, 2.97])
    _heading(doc, 'Trações nas extremidades e equilíbrio', 2)
    rows = []
    for segment in unit.get('segments', []):
        for endpoint in segment.get('endpoint_forces', []):
            rows.append((segment['id'] + ' ' + endpoint['endpoint'],
                         _value(endpoint['x_mm']) + '; ' + _value(endpoint['y_mm']),
                         _value(endpoint['qx_N_per_mm']), _value(endpoint['qy_N_per_mm']),
                         _value(endpoint['resultant_N_per_mm'])))
    _tab(doc, ['Extremidade', 'z e y em mm', 'qz N/mm', 'qy N/mm', 'q N/mm'], rows, [2., 1.47, 1.2, 1.2, 1.2])
    doc.add_paragraph('As trações da tabela são para F=−1 N. A extremidade inferior do toe pertence às duas linhas e aparece duas '
                      'vezes como testemunho geométrico; isso não duplica sua força integrada.')
    _equations(doc, '∫qz dl = 0;  ∫qy dl = F',
               '∫[(z−zc)qy − (y−yc)qz] dl = mzy',
               '∫(z qy − y qz) dl = F zL = 0;  Mx global = −mzy')
    _tab(doc, ['Equilíbrio integrado do grupo', 'F unitário', 'V real'], [
        (key, _value(value), _value(_mapping(actual.get('equilibrium')).get(key)))
        for key, value in _mapping(unit.get('equilibrium')).items()
    ], [3.65, 1.71, 1.71])
    critical = _mapping(unit.get('critical_point'))
    doc.add_paragraph('Extremidade crítica: ' + _value(critical.get('segment')) + ' / ' + _value(critical.get('endpoint')) +
                      ', coordenadas (' + _value(critical.get('x_mm')) + '; ' + _value(critical.get('y_mm')) + ') mm.')


def _section_envelope(doc, result):
    _heading(doc, 'Aba soldada e envelope de tensões de seção')
    doc.add_paragraph('A verificação suplementar integra as trações prescritas da solda na aba única. Uma seção vertical '
                      'a u do toe possui A=tH e W=tH²/6. Integram-se a solda vertical inteira e a solda inferior de 0 até u, '
                      'com momentos em (u;H/2). Usa-se o campo unitário F=−1 N nos eixos locais positivos.')
    _equations(doc, 'K = mu/J;  A0 = F/L − Kuc;  0 ≤ u ≤ b',
               'N(u) = −KH(H/2−yc) + Kyc u',
               'V(u) = A0(H+u) + Ku²/2',
               'B(u) = KH³/12 − uHA0 − A0u²/2 − Ku³/6 + KHyc u/2',
               'N(b) = 0;  V(b) = F;  B(b) = F tw,viga/2')
    doc.add_paragraph('Os máximos de |N| são procurados nos extremos. Para |V|, acrescenta-se a raiz interior u=−A0/K '
                      'quando existente. Para |B|, acrescentam-se as raízes interiores de −HA0−A0u−Ku²/2+KHyc/2=0. '
                      'A força e o momento no talão verificam o transporte da linha do centro da alma.')
    _math(doc, group(sub('σ', 'bound'), ' = ', frac(sub('N', 'max'), 'tH'), ' + ', frac(group('6', sub('B', 'max')), group('t', power('H')))))
    _math(doc, group(sub('τ', 'bound'), ' = ', frac(group('1,50', sub('V', 'max')), 'tH'), ';  ',
                     sub('σ', 'VM,bound'), ' = ', radical(group(power(sub('σ', 'bound')), ' + 3', power(sub('τ', 'bound'))))))
    _math(doc, group(sub('V', 'Rd,aba'), ' = ', frac(group(sub('f', 'y'), '/', sub('γ', 'a1')), group(sub('σ', 'VM,bound'), '(F=−1 N)'))))
    doc.add_paragraph('Combinar os máximos separados produz um envelope conservador dentro da idealização elástica '
                      'de seção retangular. É uma solução exata das resultantes integradas, não uma solução pontual exata '
                      'de elasticidade bidimensional de placa. A comparação com fy/γa1 não substitui a qualificação do detalhe '
                      'convencional nem a triagem geométrica de domínio.')
    section = _mapping(_mapping(result.get('welds')).get('support_leg_section'))
    if section:
        _tab(doc, ['Resultante unitária máxima em módulo', 'u em mm', 'Valor com sinal'], [
            (key + (' em N mm' if key == 'B' else ' em N'), _value(row.get('u_mm')), _value(row.get('resultant')))
            for key, row in _mapping(section.get('maxima')).items()
        ], [3.35, 1.4, 2.32])
        _tab(doc, ['Testemunho de seção unitária', 'Valor'], list(_flatten({
            k: value for k, value in section.items() if k not in ('maxima', 'equation', 'stress_model')
        })), [4.1, 2.97])
    else:
        doc.add_paragraph('Envelope de seção não calculado para a entrada atual.')


def _component_derivations(doc, c, result):
    _heading(doc, 'Demais componentes e derivação das capacidades')
    _heading(doc, 'Metal base junto à solda', 2)
    _equations(doc, 'qRd,y = fy tbase/(√3 γa1);  qRd,u = 0,60 fu tbase/γa2',
               'VRd,base = qRd,base / qmax(F=−1 N)')
    doc.add_paragraph('Verificam-se separadamente escoamento e ruptura da cantoneira com tbase=t e da mesa do pilar '
                      'com tbase=tf_pilar, pelas espessuras físicas integrais. São limites locais conservadores de tração '
                      'linear, confrontados com |q|max. Não se somam duas mesas, não se usa tw_pilar em lugar de tf_pilar '
                      'e não se toma esse teste como verificação global ou flexão completa do pilar.')
    _heading(doc, 'Cisalhamento das abas e dos parafusos', 2)
    _equations(doc, 'Ag = Ht;  An,viga = (H − n dn)t;  An,apoio = Ht',
               'VRd,y = 0,60 fy Ag/γa1;  VRd,u = 0,60 fu An/γa2',
               'Ab = πdb²/4;  αv = 0,45 com rosca ou 0,56 com rosca excluída',
               'gpega = tw,viga + t;  kpega = max[0; 1 − 0,01 max(0; gpega−5db)/1,50]',
               'Rv,parafuso = αv Ab fub kpega/γa2;  VRd,grupo = n Rv,parafuso')
    doc.add_paragraph('Cada parafuso possui exatamente um plano de corte. A demanda individual é Vd/n. '
                      'O fator de pega do motor é apresentado com dimensões em mm. As duas abas de uma mesma cantoneira '
                      'são verificações de componentes em série; suas capacidades não são somadas.')
    bolts = _mapping(result.get('bolts'))
    if bolts:
        _tab(doc, ['Parafusos e plano de corte', 'Valor'], list(_flatten(bolts)), [4.1, 2.97])
    _heading(doc, 'Contato por furo e transferência em série', 2)
    _equations(doc, 'Rb = min(1,20 lc; 2,40 db) tbase fu/γa2',
               'lc,L = p−dh nos furos interiores;  lc,L,inferior = eb−dh/2',
               'lc,alma = p−dh abaixo do primeiro;  primeiro: Rb = 2,40 db tw,viga fu/γa2',
               'Rb,L,grupo = Σi Rb,L,i;  Rb,alma,grupo = Σi Rb,alma,i',
               'Rtransferência = Σi min(Rv,i; Rb,L,i; Rb,alma,i)')
    doc.add_paragraph('A distribuição convencional direta exige também o atendimento individual de cada furo. '
                      'A soma de transferência limita as peças em série por furo e não substitui esse exame individual. '
                      'O primeiro parafuso da alma contínua recebe a reação para cima e não possui borda livre superior '
                      'de rasgamento. Os demais usam o ligamento até o furo acima. '
                      'O bordo da ponta da viga, perpendicular à direção desta força, continua verificado geometricamente.')
    _heading(doc, 'Blocos pela borda inferior da cantoneira', 2)
    _equations(doc, 'eb = H−et−(n−1)p;  lkv = eb+(k−1)p;  k=1,…,n',
               'Agv = lkv t;  Anv = [lkv−(k−0,50)dn]t;  Ant = (b_viga−e−dn/2)t',
               'Rbloco = [min(0,60fu Anv; 0,60fy Agv)+fu Ant]/γa2',
               'Sd,bloco = (k/n)Vd;  VRd,equivalente = (n/k)Rbloco')
    doc.add_paragraph('Cada caminho fecha k furos a partir da borda inferior carregada até a ponta livre da aba. '
                      'Cts=1. As áreas e demandas são próprias de cada caminho; resistências de blocos alternativos '
                      'não se somam. Sem recorte e com mesas contínuas, o bloco específico de alma recortada não é aplicado, '
                      'conforme o domínio de P901 II.A-29.')
    _heading(doc, 'Cortante da alma da viga', 2)
    _equations(doc, 'λ = h_livre/tw;  λp = 1,10√(5,34 E/fy);  λr = 1,37√(5,34 E/fy)',
               'Cv = 1 se λ≤λp;  Cv = λp/λ se λp<λ≤λr',
               'Cv = 1,24(λp/λ)² se λ>λr;  VRd = 0,60fy d tw Cv/γa1')
    doc.add_paragraph('A verificação de cortante utiliza kv=5,34 e a área d×tw do perfil da viga. Ela não certifica '
                      'a flexão, interação global, estabilidade lateral ou o dimensionamento de toda a viga.')
    if _mapping(result.get('load_model')) and isinstance(c, WeldedSupportSingleAngle):
        g = result['geometry']
        steel = STEELS[c.beam_steel]
        rows = [
            ('Ag de cada aba em mm²', c.length*c.t),
            ('An da aba parafusada em mm²', (c.length-c.web_rows*g['dn'])*c.t),
            ('An da aba soldada em mm²', c.length*c.t),
            ('Área de um parafuso Ab em mm²', pi*c.db*c.db/4),
            ('αv adotado', .56 if c.web_threads_excluded else .45),
            ('λ da alma', c.beam.clear/c.beam.tw),
            ('λp da alma', 1.1*sqrt(5.34*200000./steel.fy)),
            ('λr da alma', 1.37*sqrt(5.34*200000./steel.fy)),
            ('Área d tw da alma em mm²', c.beam.d*c.beam.tw),
        ]
        _tab(doc, ['Substituição geométrica sem arredondamento de cálculo', 'Valor exibido'], [(a, _value(b)) for a, b in rows], [4.55, 2.52])


def _checks(doc, result):
    checks = result.get('checks') or []
    if not checks:
        _heading(doc, 'Capacidades não avaliadas')
        doc.add_paragraph('Sem verificações resistentes para esta entrada. Capacidades de resultados anteriores não são reutilizadas.')
        return
    _section(doc, landscape=True)
    _heading(doc, 'Todas as capacidades e demandas locais')
    doc.add_paragraph('Todas as forças desta tabela estão em kN. Sd real conserva a reação real; Sd projeto usa Vd uma '
                      'vez. Rd é a resistência do mecanismo ou subconjunto identificado. VRd eq é a capacidade equivalente '
                      'para o V total da ligação, sem somar componentes em série. η usa valores não arredondados; o estado '
                      'do motor prevalece se a apresentação arredondar um índice próximo de 1.')
    _tab(doc, ['Verificação e identificador', 'Sd real', 'Sd projeto', 'Rd', 'VRd eq', 'η real', 'η projeto', 'Estado'], [
        (row['label'] + '\n' + row['id'], _kn(row.get('actual_demand_N')), _kn(row.get('demand_N')),
         _kn(row.get('design_capacity_N')), _kn(row.get('equivalent_total_V_capacity_N')),
         _value(row.get('actual_utilization')), _value(row.get('utilization')), row.get('status', ''))
        for row in checks
    ], [3.3, .97, 1.02, 1., 1., 1., 1.1, 1.1], size=8.1)
    _heading(doc, 'Fórmulas referências e testemunhos de cada verificação')
    doc.add_paragraph('As equações editáveis definem os termos. Áreas dos blocos em mm²; clear_distance_mm e '
                      'thickness_mm em mm; Cv adimensional. Ausência de clear_distance_mm no primeiro furo da alma '
                      'significa que não há borda livre vertical acima. per_hole_capacities_N está em N.')
    main = {'id', 'label', 'component', 'demand_N', 'actual_demand_N', 'design_capacity_N', 'utilization',
            'actual_utilization', 'status', 'equivalent_total_V_capacity_N', 'formula', 'reference'}
    formula_table = _tab(doc, ['Verificação e componente', 'Fórmula implementada e referência', 'Testemunhos adicionais'], [
        (row['id'] + '\n' + row.get('component', ''), '',
         '\n'.join(key + ' = ' + value for key, value in _flatten({k: v for k, v in row.items() if k not in main})) or 'Sem campo adicional')
        for row in checks
    ], [2.4, 5.35, 2.74], size=7.8)
    for table_row, check in zip(formula_table.rows[1:], checks):
        cell = table_row.cells[1]
        _math(cell, group(check.get('formula', '')))
        # Keep every primitive's exact expression editable, including repeated
        # mechanisms. The checked expression stays tied to its own ID/source.
        for math_run in cell._tc.xpath('.//m:r'):
            properties = OxmlElement('w:rPr')
            size = OxmlElement('w:sz')
            size.set(qn('w:val'), '16')
            properties.append(size)
            math_run.insert(0, properties)
        reference = cell.add_paragraph(check.get('reference', ''))
        reference.paragraph_format.space_after = Pt(0)
        for run in reference.runs:
            run.font.size = Pt(7.8)
        # The initially empty cell paragraph would otherwise inflate every row.
        empty = cell.paragraphs[0]
        empty._p.getparent().remove(empty._p)


def _closing(doc, result):
    _section(doc)
    _heading(doc, 'Conclusão rastreabilidade e limites')
    status = result.get('status', 'NOT_EVALUATED')
    doc.add_paragraph(STATUS.get(status, status) + ' · ' + status)
    if _approved(result):
        doc.add_paragraph('A configuração atende às verificações locais implementadas e às condições de domínio e '
                          'detalhamento examinadas. Este atendimento é condicionado às premissas, dimensões e ações '
                          'registradas; não constitui aprovação global da estrutura nem liberação de fabricação.')
    else:
        doc.add_paragraph('SEM APROVAÇÃO LOCAL. Falhas, pendências, entrada inválida ou domínio não coberto impedem '
                          'interpretar este memorial como aprovação, mesmo quando existam componentes individuais com resultado PASS.')
    summary = _mapping(result.get('summary'))
    if summary:
        keys = ('complete_checks', 'governing_check_id', 'governing_utilization',
                'actual_governing_utilization', 'equivalent_total_V_capacity_N', 'failed_check_ids', 'check_count')
        _tab(doc, ['Resumo recalculado', 'Valor'], list(_flatten({key: summary[key] for key in keys if key in summary})), [3.55, 3.52])
    _heading(doc, 'Avisos e bloqueios', 2)
    issues = result.get('issues') or []
    if issues:
        _tab(doc, ['Classificação', 'Ocorrência e referência'], [
            (SEVERITY.get(row.get('severity'), str(row.get('severity'))), calculated_text(row.get('text', ''), assignments_only=True) +
             ('\n' + row['reference'] if row.get('reference') else '')) for row in issues
        ], [1.45, 5.62])
    else:
        doc.add_paragraph('Nenhuma ocorrência adicional retornada pelo motor.')
    for row in result.get('not_applicable', []):
        doc.add_paragraph(row.get('mechanism', '') + ': ' + row.get('reason', ''))
    _heading(doc, 'Escopo local e verificações externas', 2)
    for exclusion in result.get('exclusions', EXCLUSIONS):
        doc.add_paragraph(exclusion, style='List Bullet')
    doc.add_paragraph('Continuam a cargo do projeto estrutural: ações e combinações globais; resistência, estabilidade '
                      'e interação global da viga, pilar e pórtico; condições reais de continuidade do receptor; '
                      'compatibilidade de rotação e montagem; soldabilidade, procedimento de execução, inspeção, '
                      'proteção contra corrosão e acesso real no edifício. Não há certificação de ductilidade por uma razão geométrica isolada.')
    _heading(doc, 'Referências e natureza da verificação', 2)
    doc.add_paragraph(NBR + ': 6.1.5.2 para força mínima; Tabelas 9 e 11 e seção 6.2 para soldas; '
                      '6.3.3, 6.3.7, 6.3.9 a 6.3.12, Tabelas 14 e 16 para parafusos e detalhe; '
                      '6.5.5 e 6.5.6 para cisalhamento e bloco; 5.4.3.1 para cortante da alma; '
                      'Tabela 4 grupo AL3 somente como fonte da expressão usada na triagem geométrica declarada.')
    doc.add_paragraph('AISC Manual Companion v16, P901: exemplo II.A-29, páginas IIA-284 a IIA-292, '
                      'detalhe convencional; II.A-27, método elástico de solda. A errata corrige kl para 3 in '
                      'no benchmark ICR de II.A-29. Os resultados ICR e os elásticos são modelos diferentes; '
                      'não se calibra o campo elástico para obter a resistência tabelada.')
    for label, url in (
        ('Errata oficial AISC do Manual Companion v16 de 02/06/2025', 'https://www.aisc.org/media/12lltkmv/manual-companion-v160_vol-1-errata.pdf'),
        ('AISC Steel Interchange de fevereiro de 2005 sobre o detalhe flexível', 'https://www.aisc.org/globalassets/modern-steel/steel-interchange/2005/2005v02_si_web.pdf'),
        ('Errata AISC de Detailing for Steel Construction segunda edição', 'https://www.aisc.org/media/a3mjwxyh/errata-to-detailing-for-steel-construction-2nd-ed.pdf'),
    ):
        hyperlink(doc.add_paragraph(), label, url)
    doc.add_paragraph('Modelo analítico suplementar: integração das trações do grupo L e envelope conservador de seção '
                      'da aba soldada. Trata-se de formulação de equilíbrio documentada nas equações deste memorial, '
                      'não de um coeficiente normativo de ductilidade nem de uma verificação experimental.')


def create_report(c, result=None):
    """Return DOCX bytes for *c*, ignoring all supplied evaluation objects."""
    # This call must stay unconditional: an optional/stale result cannot bypass
    # current geometry, signed actions, scope gates, or resistant checks.
    current = evaluate(c)
    doc = Document()
    section = doc.sections[0]
    section.page_width = Inches(8.27)
    section.page_height = Inches(11.69)
    section.top_margin = section.bottom_margin = Inches(.55)
    section.left_margin = section.right_margin = Inches(.60)
    for style_name in ('Normal', 'Title', 'Heading 1', 'Heading 2', 'List Bullet'):
        style = doc.styles[style_name]
        style.font.name = 'Arial'
        style.font.color.rgb = RGBColor(0, 0, 0)
    for style in doc.styles:
        for border in style.element.xpath('.//w:pBdr'):
            border.getparent().remove(border)
    doc.styles['Normal'].font.size = Pt(9)
    doc.styles['Normal'].paragraph_format.space_after = Pt(5)
    doc.styles['Title'].font.size = Pt(20)
    doc.styles['Heading 1'].font.size = Pt(12)
    doc.styles['Heading 2'].font.size = Pt(10)
    for name in ('Heading 1', 'Heading 2'):
        doc.styles[name].paragraph_format.keep_with_next = True
    doc.core_properties.title = 'Memória de cálculo de cantoneira única soldada à mesa do pilar'
    doc.core_properties.subject = 'Ligação 1L com parafusos em uma alma e solda L no pilar'
    doc.core_properties.author = 'LRO Soluções de engenharia LTDA.'
    doc.add_paragraph('Cantoneira única soldada à mesa do pilar', style='Title')
    doc.add_paragraph('Memória de cálculo da ligação para cortante descendente')
    doc.add_paragraph(_value(getattr(c, 'project', 'Entrada sem projeto')))
    status = current.get('status', 'NOT_EVALUATED')
    paragraph = doc.add_paragraph()
    paragraph.add_run(STATUS.get(status, status)).bold = True
    doc.add_paragraph(status)
    if _approved(current):
        summary = current['summary']
        doc.add_paragraph('Atendimento local dentro do domínio declarado. Governa ' + summary['governing_label'] +
                          ', com η adotado=' + _value(summary['governing_utilization']) +
                          ', η real=' + _value(summary['actual_governing_utilization']) +
                          ' e capacidade equivalente de V=' + _kn(summary['equivalent_total_V_capacity_N']) + ' kN.')
    else:
        doc.add_paragraph('SEM APROVAÇÃO LOCAL. Consulte os bloqueios e os resultados da entrada atual antes de qualquer uso de projeto.')
    doc.add_paragraph(SCOPE)
    doc.add_paragraph('A cantoneira única recebe toda a força. Há um plano de corte por parafuso, nenhuma solda na alma '
                      'da viga e nenhum parafuso no apoio. A solda resistente é L na mesa do pilar; o retorno superior '
                      'curto é físico e não recebe crédito resistente. A conclusão é estritamente local.')
    doc.add_paragraph('Tipo de conexão: ' + CONNECTION_TYPE + '. Versão do componente: ' + COMPONENT_VERSION +
                      '. Este arquivo reavalia a entrada atual. Resultados fornecidos externamente não são aceitos '
                      'como fonte de aprovação nem incorporados como dados serializados ao documento.')
    drawable = isinstance(c, WeldedSupportSingleAngle) and not input_errors(c)
    if not drawable:
        doc.add_paragraph('Entrada inválida sem esquema dimensionado. Os dados informados e seus erros são preservados abaixo.')
    _inputs(doc, c)
    _loads_and_scope(doc, c, current)
    _geometry(doc, current)
    _weld(doc, current)
    _section_envelope(doc, current)
    _component_derivations(doc, c, current)
    _checks(doc, current)
    _closing(doc, current)
    if drawable:
        from .welded_support_single_angle_drawing import image_bytes
        sheet = _section(doc, landscape=True)
        sheet.page_width = Inches(16.54)
        sheet.page_height = Inches(11.69)
        _heading(doc, 'Desenho da ligação em folha A3')
        paragraph = doc.add_paragraph()
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        paragraph.add_run().add_picture(BytesIO(image_bytes(c, current)), width=Inches(13.0))
        doc.add_paragraph('Esquema da entrada atual. O desenho não substitui detalhamento executivo nem altera o estado de avaliação.')
    footer = doc.sections[0].footer.paragraphs[0]
    footer.add_run(BRAND + '  |  Página ')
    field = OxmlElement('w:fldSimple')
    field.set(qn('w:instr'), 'PAGE')
    footer._p.append(field)
    for run in footer.runs:
        run.font.size = Pt(7)
    stream = BytesIO()
    doc.save(stream)
    return stream.getvalue()
