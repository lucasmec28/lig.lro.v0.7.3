"""Reusable, editable portrait excerpts. Presentation only; no design arithmetic."""
from io import BytesIO
from docx import Document
from docx.shared import Cm, Pt, RGBColor
from .report import table, number, display

HEADERS = ('Verificação', 'Sd / valor', 'Rd / limite', 'Unid.', 'Índice', 'Atende')

def document(title, project, status, image, caption):
    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Cm(21), Cm(29.7)
    sec.left_margin = sec.right_margin = Cm(1.6)
    sec.top_margin = sec.bottom_margin = Cm(1.6)
    for name in ('Normal', 'Title', 'Heading 1', 'Heading 2'):
        style = doc.styles[name]
        style.font.name = 'Arial'
        style.font.color.rgb = RGBColor(0, 0, 0)
        style.paragraph_format.space_after = Pt(4)
    for style in doc.styles:
        for border in style.element.xpath('.//w:pBdr'):
            border.getparent().remove(border)
    doc.styles['Normal'].font.size = Pt(9)
    doc.styles['Title'].font.size = Pt(16)
    doc.styles['Heading 1'].font.size = Pt(11)
    doc.styles['Heading 2'].font.size = Pt(10)
    doc.core_properties.title = title
    doc.core_properties.author = 'LRO Soluções de engenharia LTDA.'
    doc.add_heading(title, 0)
    doc.add_paragraph(project)
    doc.add_paragraph(status).runs[0].bold = True
    doc.add_picture(BytesIO(image), width=Cm(17.7))
    doc.add_paragraph(caption)
    return doc

def data_table(doc, rows):
    doc.add_heading('Dados adotados e caso de cálculo', 1)
    table(doc, ('Parâmetro', 'Valor', 'Unid.'), rows, (3.2, 3.0, .75))

def result_table(doc, title, rows):
    if not rows:
        return
    doc.add_heading(title, 1)
    table(doc, HEADERS, rows, (3.1, .85, .85, .5, .65, 1.0))

def object_checks(doc, checks):
    """Use existing engine categories, never infer geometry from a numerical unit."""
    groups = {}
    for check in checks:
        category = getattr(check, 'category', 'Verificações calculadas')
        if check.id in {'u_weld_length_web','u_weld_length_flange','u_weld_min_alma','u_weld_min_mesa'}:
            category = 'Requisitos geométricos das soldas'
        elif check.id in {'bp_width','bp_anchor_washer_thickness','bp_anchor_washer_side','bp_anchor_washer_fit'}:
            category = 'Requisitos geométricos do detalhe'
        sd, unit = display(check.demand, check.unit)
        rd, _ = display(check.resistance, check.unit)
        case = getattr(check, 'case', 'Entrada')
        label = check.name + (' · caso: ' + case if case != 'Entrada' else '')
        groups.setdefault(category, []).append((label, sd, rd, unit, number(check.ratio), 'Sim' if check.passed else 'Não'))
    for category, rows in groups.items():
        result_table(doc, category, rows)
    doc.add_paragraph('Valores apresentados com duas casas decimais; decisões e índices calculados com precisão interna. Para espessuras e condições geométricas, valor e limite seguem a relação indicada na memória completa. “Sim” vale para a linha apresentada e não substitui o alcance do resultado.')

def close(doc, notes, references):
    doc.add_heading('Condições e alcance', 1)
    for text in dict.fromkeys(n for n in notes if n):
        doc.add_paragraph(text)
    doc.add_paragraph('Trecho resumido para inserção na MC. Consultar a memória completa para equações, hipóteses detalhadas e verificações dos componentes complementares. O resumo não amplia o escopo verificado.')
    doc.add_heading('Referências', 1)
    doc.add_paragraph('; '.join(dict.fromkeys(r for r in references if r)))
    output = BytesIO()
    doc.save(output)
    return output.getvalue()
