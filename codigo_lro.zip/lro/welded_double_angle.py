"""R015: paired U-welded beam-web angles, bolted to column flange.

Units N, mm, MPa. The line group is integrated analytically, per physical
angle. Historical LCSP capacities are not the current-NBR oracle.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict, fields, replace
import math
from .angle_catalog_selection import (native_connection, valid_native_fields, identity_errors,
    missing_data_errors, STRING_FIELDS as CATALOG_STRINGS, BOOL_FIELDS as CATALOG_BOOLS)
from .models import Profile, profiles, STEELS, BOLTS, finite_real
from .double_angle import (GAMMA_A1, GAMMA_A2, NBR, HOLES, EDGES, INDUSTRIAL,
    TOL, _safe, _issue, _check, bolt_shear_resistance, bearing_rows, l_blocks)

FAMILY = 'Cantoneiras duplas · R015 · soldadas/parafusadas'
CONNECTION_TYPE = 'double_angle_r015_welded_bolted_shear'
COMPONENT_VERSION = '0.9.2-angle-dev'
SCOPE = ('R015/LCSP: duas cantoneiras iguais, soldadas em U à alma de viga W sem recortes '
         'e parafusadas à mesa de pilar W. V estático, N=M=T=0. Soldas com excentricidade explícita.')
EXCLUSIONS = ['Cantoneira única, assimetria, abas estendidas e apoio na alma exigem modelos próprios.',
    'Não verifica fadiga, impacto, atrito, recortes ou dimensionamento global dos membros.',
    'Atendimento local depende da cobertura do modelo, montagem, rotação e de todas as verificações aplicáveis.']

@dataclass(frozen=True)
class WeldedDoubleAngle:
    beam: Profile
    support: Profile
    project: str = 'R015 · duas cantoneiras soldadas/parafusadas'
    kind: str = 'column_flange'
    angle_count: int = 2
    symmetric: bool = True
    beam_leg: float = 76.0
    support_leg: float = 76.0
    t: float = 6.4
    root_radius: float = 8.0
    length: float = 260.0
    angle_top: float = 44.5
    support_gauge: float = 45.0
    support_rows: int = 4
    support_columns: int = 1
    support_pitch: float = 60.0
    support_end_top: float = 40.0
    gap: float = 10.0
    weld_layout: str = 'U_three_edges'
    reinforced_weld_edge: bool = False
    weld_leg: float = 4.0
    weld_start: float = 20.0
    weld_process: str = 'SMAW_E7018'
    electrode_fuw: float = 485.0
    support_edge_top: float = 500.0
    support_edge_bottom: float = 500.0
    beam_steel: str = 'ASTM A572 Gr.50'
    support_steel: str = 'ASTM A572 Gr.50'
    angle_steel: str = 'ASTM A36'
    bolt: str = 'ASTM F3125 A325'
    db: float = 20.0
    hole_diameter: float = 22.0
    hole_type: str = 'standard_round'
    drilled: bool = False
    support_threads_excluded: bool = False
    exposure: str = 'painted'
    V: float = 100000.0
    N: float = 0.0
    M: float = 0.0
    torsion: float = 0.0
    cope: str = 'none'
    static: bool = True
    normal_combination: bool = True
    no_slip_required: bool = False
    tool_radius: float = 22.0
    fabrication_clearance: float = 3.0
    notes: str = ''
    angle_catalog_id: str = ''
    angle_root_source: str = ''
    angle_root_confirmed: bool = False


    @property
    def fixed_assumptions(self):
        return {'topology':'R015_two_equal_angles_U_welded_to_beam_web_bolted_to_column_flange',
            'web_bolts':0,'support_shear_planes':1,
            'weld_group':'three_connected_effective_line_segments_per_angle_open_at_support',
            'weld_throat':'leg/sqrt(2), no penetration or directional enhancement',
            'weld_passes':'single_pass_fillets_in_Table11_route; qualified_execution_procedure_required',
            'weld_force_model':'elastic_line_group; Fy=V/2 at support_face_x=0; Mz=-xbar*Fy',
            'shared_web':'single physical web, both angle weld fields superposed',
            'contact':'firm_direct_contact_at_support_no_shims',
            'continuity':'rolled_W_beam_and_column_no_copes_extra_openings_or_local_discontinuities',
            'normal_ultimate_combinations_only':True,
            'net_hole_policy':'Table14_maximum_plus_2mm_unless_documented_drilled',
            'gamma_a1':GAMMA_A1,'gamma_a2':GAMMA_A2}

    def to_dict(self):
        errors=input_errors(self)
        if errors:raise ValueError('; '.join(errors))
        return {'schema_version':1,'connection_type':CONNECTION_TYPE,'component_version':COMPONENT_VERSION,
            'connection':native_connection(self),'units':{'force':'N','length':'mm','stress':'MPa','moment':'N mm'},
            'fixed_assumptions':self.fixed_assumptions}

    @classmethod
    def from_dict(cls,data):
        allowed={'schema_version','connection_type','component_version','connection','units','fixed_assumptions'}
        if not isinstance(data,dict) or set(data)!=allowed:raise ValueError('Projeto R015: campos ausentes ou desconhecidos.')
        if type(data['schema_version']) is not int or data['schema_version']!=1 or data['connection_type']!=CONNECTION_TYPE or data['component_version']!=COMPONENT_VERSION:
            raise ValueError('Família ou versão R015 incompatível.')
        raw=data['connection']
        if not valid_native_fields(raw, cls):raise ValueError('Dados R015 incompletos ou desconhecidos.')
        raw=dict(raw)
        for key in ('beam','support'):
            p=raw[key]
            if not isinstance(p,dict) or set(p)!={f.name for f in fields(Profile)}:raise ValueError(key+': perfil inválido ou incompleto.')
            raw[key]=Profile(**p)
        c=cls(**raw);canonical=c.to_dict()
        for key in ('units','fixed_assumptions'):
            if data[key]!=canonical[key]:raise ValueError(key+': premissas/unidades incompatíveis.')
        return c


def presets():
    p=profiles();base=WeldedDoubleAngle(p['W 360 x 32,9'],p['W 310 x 97,0 (H)'])
    return {'R015 · W360/W310 · M20 · V=100 kN':base,
        'R015 · cortante invertido':replace(base,project='R015 · V invertido',V=-100000.),
        'R015 · solicitação elevada':replace(base,project='R015 · solicitação elevada',V=500000.)}


def input_errors(c):
    if not isinstance(c,WeldedDoubleAngle):return ['A entrada deve ser WeldedDoubleAngle.']
    errors=[]
    strings={'project','kind','beam_steel','support_steel','angle_steel','bolt','hole_type','exposure','cope','notes','weld_layout','weld_process'}
    bools={'symmetric','reinforced_weld_edge','drilled','support_threads_excluded','static','normal_combination','no_slip_required'}
    ints={'angle_count','support_rows','support_columns'}
    nonnegative={'root_radius','angle_top','gap','fabrication_clearance','weld_start'}
    for f in fields(c):
        name=f.name;v=getattr(c,name)
        if name in ('beam','support'):
            if not isinstance(v,Profile):errors.append(name+': perfil obrigatório.');continue
            for key in ('d','bf','tw','tf','clear','area','mass'):
                if not finite_real(getattr(v,key)) or getattr(v,key)<=0:errors.append(f'{name}.{key}: positivo finito obrigatório.')
            for key in ('name','family','source'):
                if not isinstance(getattr(v,key),str):errors.append(f'{name}.{key}: texto obrigatório.')
        elif name in strings | CATALOG_STRINGS:
            if not isinstance(v,str):errors.append(name+': texto obrigatório.')
        elif name in bools | CATALOG_BOOLS:
            if type(v) is not bool:errors.append(name+': booleano obrigatório.')
        elif name in ints:
            if type(v) is not int or not 1<=v<=20:errors.append(name+': inteiro entre 1 e 20 obrigatório.')
        elif not finite_real(v):errors.append(name+': número finito obrigatório.')
        elif name in nonnegative:
            if v<0:errors.append(name+': não negativo obrigatório.')
        elif name not in ('V','N','M','torsion') and v<=0:errors.append(name+': valor positivo obrigatório.')
    return errors + (identity_errors(c, 1) if not errors else [])


def elastic_line_group(segments, Fx, Fy, load_x, load_y):
    """Exact elastic uniform-throat line-group integrals (N/mm).

    Each segment is ((x1,y1),(x2,y2)). Uniform load along a straight line
    plus rotation about the line centroid is affine; its norm reaches its
    maximum at an endpoint. No mesh or ICR coefficient is used.
    """
    if any(not finite_real(v) for v in (Fx,Fy,load_x,load_y)):
        raise ValueError('Ações/coordenadas finitas obrigatórias para o grupo de solda.')
    lines=[]
    for i,seg in enumerate(segments):
        (x1,y1),(x2,y2)=seg
        if any(not finite_real(v) for v in (x1,y1,x2,y2)):raise ValueError('Segmento não finito.')
        L=math.hypot(x2-x1,y2-y1)
        if L<=0:raise ValueError('Segmento de solda deve ter comprimento positivo.')
        lines.append(dict(id=f'segment_{i+1}',start_mm=[x1,y1],end_mm=[x2,y2],length_mm=L,
            midpoint_mm=[(x1+x2)/2,(y1+y2)/2]))
    if not lines:raise ValueError('Grupo de solda vazio.')
    total=sum(s['length_mm'] for s in lines)
    xc=sum(s['length_mm']*s['midpoint_mm'][0] for s in lines)/total
    yc=sum(s['length_mm']*s['midpoint_mm'][1] for s in lines)/total
    J=0.
    for s in lines:
        L=s['length_mm'];xm,ym=s['midpoint_mm']
        J+=L*((xm-xc)**2+(ym-yc)**2)+L**3/12
    if not math.isfinite(J) or J<=0:raise ArithmeticError('Inércia polar não positiva/finita.')
    M=(load_x-xc)*Fy-(load_y-yc)*Fx
    points=[];sum_fx=sum_fy=sum_m=0.
    for s in lines:
        endpoints=[]
        for label,(x,y) in zip(('start','end'),(s['start_mm'],s['end_mm'])):
            qx=Fx/total-M*(y-yc)/J;qy=Fy/total+M*(x-xc)/J
            p=dict(segment=s['id'],endpoint=label,x_mm=x,y_mm=y,qx_N_per_mm=qx,qy_N_per_mm=qy,
                resultant_N_per_mm=math.hypot(qx,qy))
            endpoints.append(p);points.append(p)
        s['endpoint_forces']=endpoints
        L=s['length_mm'];xm,ym=s['midpoint_mm']
        sum_fx+=L*(Fx/total-M*(ym-yc)/J)
        sum_fy+=L*(Fy/total+M*(xm-xc)/J)
        sum_m+=L*((xm-xc)*Fy/total-(ym-yc)*Fx/total)+M/J*(L*((xm-xc)**2+(ym-yc)**2)+L**3/12)
    critical=max(points,key=lambda p:p['resultant_N_per_mm'])
    return dict(total_length_mm=total,centroid_x_mm=xc,centroid_y_mm=yc,J_line_mm3=J,
        force_x_N=Fx,force_y_N=Fy,load_point_mm=[load_x,load_y],moment_about_centroid_Nmm=M,
        eccentricity_x_mm=load_x-xc,eccentricity_y_mm=load_y-yc,
        segments=lines,critical_point=critical,max_resultant_N_per_mm=critical['resultant_N_per_mm'],
        equilibrium=dict(integrated_Fx_N=sum_fx,integrated_Fy_N=sum_fy,
            integrated_M_about_centroid_Nmm=sum_m,
            integrated_M_about_origin_Nmm=sum_m+xc*sum_fy-yc*sum_fx,
            Fx_residual_N=sum_fx-Fx,Fy_residual_N=sum_fy-Fy,M_residual_Nmm=sum_m-M))


def weld_segments(c):
    return [((c.weld_start,0.),(c.beam_leg,0.)),
            ((c.beam_leg,0.),(c.beam_leg,c.length)),
            ((c.beam_leg,c.length),(c.weld_start,c.length))]


def geometry(c,out):
    dh=c.hole_diameter;dn=HOLES.get(c.db,dh)+(0. if c.drilled else 2.)
    bottom=c.length-c.support_end_top-(c.support_rows-1)*c.support_pitch
    z=c.beam.tw/2+c.support_gauge;beamroot=(c.beam.d-c.beam.clear)/2
    supportroot=max(0.,(c.support.d-2*c.support.tf-c.support.clear)/2)
    thin=min(c.t,c.beam.tw);minimum=3. if thin<=6.3 else 5. if thin<=12.5 else 6. if thin<=19. else 8.
    maximum=c.t if c.t<6.3 else c.t-1.5
    g=dict(valid=False,dh=dh,dn=dn,physical_hole_diameter_mm=dh,net_deduction_diameter_mm=dn,
        table14_max_hole_mm=HOLES.get(c.db),support_end_bottom_mm=bottom,
        support_hole_y_mm=[c.angle_top+c.support_end_top+i*c.support_pitch for i in range(c.support_rows)],
        support_hole_z_mm=[-z,z],support_free_toe_edge_mm=c.support_leg-c.support_gauge,
        column_flange_edge_mm=c.support.bf/2-z,angle_beam_clear_top_mm=c.angle_top-beamroot,
        angle_beam_clear_bottom_mm=c.beam.d-beamroot-c.angle_top-c.length,
        column_top_y_mm=c.angle_top+c.support_end_top-c.support_edge_top,
        column_bottom_y_mm=c.angle_top+c.support_end_top+(c.support_rows-1)*c.support_pitch+c.support_edge_bottom,
        support_grip_mm=c.support.tf+c.t,physical_angle_count=c.angle_count,web_bolt_count=0,
        each_support_leg_bolt_count=c.support_rows*c.support_columns,
        total_bolt_count=c.angle_count*c.support_rows*c.support_columns,
        weld_horizontal_length_mm=c.beam_leg-c.weld_start,weld_vertical_length_mm=c.length,
        weld_start_x_mm=c.weld_start,weld_toe_x_mm=c.beam_leg,
        weld_throat_mm=c.weld_leg/math.sqrt(2),weld_minimum_leg_mm=minimum,
        weld_unreinforced_maximum_leg_mm=maximum,weld_edge_reinforced=c.reinforced_weld_edge,
        weld_segments_per_angle_mm=weld_segments(c),industrial_N_intervals=c.support_rows-1,
        industrial_Z_mm=c.beam.d-2*c.beam.tf,checks=[],detailing_checks=[],errors=[])
    out['geometry']=g
    def scalar(key,value,limit,relation,category,text,reference='Geometria física R015'):
        passed=(value>limit if relation=='>' else value>=limit*(1-TOL) if relation=='>=' else value<=limit*(1+TOL))
        row=dict(id=key,actual=value,limit=limit,relation=relation,category=category,passed=passed,units='mm',reference=reference)
        g['checks'].append(row)
        if category=='detail':g['detailing_checks'].append(row)
        if not passed:
            if category=='geometry':g['errors'].append(key)
            severity={'geometry':'invalid_geometry','detail':'detail_fail','preset':'preset_deviation','access':'access_pending','model':'engineering_pending'}[category]
            _issue(out,severity,f'{text}: {value:g} mm; requerido {relation} {limit:g} mm.',reference,field=key)
    for name,p in [('beam',c.beam),('support',c.support)]:
        scalar(name+'_web_height',p.d-2*p.tf,0.,'>','geometry',name+': alma entre mesas')
        scalar(name+'_root_clear',p.clear,p.d-2*p.tf,'<=','geometry',name+': trecho livre das raízes')
        scalar(name+'_flange_width',p.bf,p.tw,'>','geometry',name+': mesa além da alma')
    for name,b in [('beam',c.beam_leg),('support',c.support_leg)]:
        scalar(name+'_straight_leg',b-c.t-c.root_radius,0.,'>','geometry',name+': aba reta')
    scalar('angle_clear_top',g['angle_beam_clear_top_mm'],c.weld_leg,'>=','geometry','Filete superior integralmente fora da raiz da viga')
    scalar('angle_clear_bottom',g['angle_beam_clear_bottom_mm'],c.weld_leg,'>=','geometry','Filete inferior integralmente fora da raiz da viga')
    scalar('angle_support_fit',c.beam.tw+2*c.support_leg,c.support.bf,'<=','geometry','Abas dentro da mesa do pilar')
    scalar('weld_horizontal_length',g['weld_horizontal_length_mm'],0.,'>','geometry','Trechos horizontais reais do U')
    scalar('weld_start_beam_end',c.weld_start,c.gap,'>=','geometry','Início efetivo dos filetes apoiado na alma existente')
    scalar('beam_angle_overlap',c.beam_leg-c.gap,max(5*min(c.t,c.beam.tw),25.),'>=','detail','Sobreposição mínima entre a aba e a alma',NBR+', 6.2.6.2.5')
    scalar('weld_start_angle_root',c.weld_start,c.t+c.root_radius,'>=','model','Início dos filetes fora da concordância nesta idealização plana; sem fechar o talão')
    scalar('weld_leg_min',c.weld_leg,minimum,'>=','detail','Perna mínima pela peça mais fina',NBR+', tabela11')
    if not c.reinforced_weld_edge:
        scalar('weld_leg_max',c.weld_leg,maximum,'<=','detail','Máximo na borda sem reforço explicitamente detalhado',NBR+', 6.2.6.2.2')
    else:
        _issue(out,'warning','Borda explicitamente especificada como reforçada durante a execução para garantir a garganta requerida; não é simples arredondamento do filete máximo. Registrar esse detalhe no desenho e procedimento.',NBR+', 6.2.6.2.2')
        scalar('weld_leg_reinforced_physical',c.weld_leg,c.t,'<=','geometry','Filete reforçado limitado pela geometria adotada nesta rota')
    for name,L in [('horizontal',g['weld_horizontal_length_mm']),('vertical',c.length)]:
        scalar('weld_'+name+'_min_length',L,max(4*c.weld_leg,40.),'>=','model',
            'Comprimento do segmento '+name+' fora da rota de perna integral adotada; a alternativa normativa de perna efetiva limitada a 25% do comprimento não está implementada, sem redução silenciosa da perna',
            NBR+', 6.2.6.2.3; limite do método adotado, não proibição normativa universal')
        scalar('weld_'+name+'_long_joint',L,100*c.weld_leg,'<=','model','Trecho dentro da rota sem redução por comprimento longo',NBR+', 6.2.2.2(d); 100w é domínio limitado desta implementação, não proibição universal de comprimentos maiores')
    for name,value in [('top',g['angle_beam_clear_top_mm']-c.weld_leg),('bottom',g['angle_beam_clear_bottom_mm']-c.weld_leg)]:
        scalar('weld_'+name+'_fabrication_clear',value,c.fabrication_clearance,'>=','access','Acesso/folga de fabricação do filete '+name)
    scalar('conventional_restraint_depth',c.length,c.beam.d/2,'>=','model','Comprimento da ligação usual para impedimento de giro longitudinal','Gerdau2018 p.20; NBR6.1.7')
    scalar('conventional_upper_location',g['support_hole_y_mm'][0],c.beam.d-g['support_hole_y_mm'][-1],'<=','model','Grupo centralizado ou próximo ao topo','Gerdau2018 p.20')
    scalar('support_toe_hole',g['support_free_toe_edge_mm']-dh/2,0.,'>','geometry','Furo integral na aba de apoio')
    scalar('column_toe_hole',g['column_flange_edge_mm']-dh/2,0.,'>','geometry','Furo integral na mesa do pilar')
    scalar('support_hole_root',c.support_gauge-c.t-c.root_radius-dh/2,0.,'>=','geometry','Furo fora da concordância da cantoneira')
    scalar('support_tool_root',c.support_gauge-c.t-c.root_radius,c.tool_radius+c.fabrication_clearance,'>=','access','Ferramenta junto à concordância')
    scalar('column_back_tool_root',z-c.support.tw/2-supportroot,c.tool_radius+c.fabrication_clearance,'>=','access','Ferramenta atrás da mesa fora da raiz do pilar')
    emin=EDGES.get(c.db,0.);pmin=max(2.7*c.db,dh+c.db);tmin=min(c.t,c.support.tf)
    if c.support_rows>1:
        scalar('support_pitch_physical',c.support_pitch-dh,0.,'>','geometry','Furos separados')
        scalar('support_pitch_min',c.support_pitch,pmin,'>=','detail','Passo mínimo',NBR+', 6.3.9')
        scalar('support_pitch_max',c.support_pitch,min(14*tmin,180.) if c.exposure=='weathering' else min(24*tmin,300.),'<=','detail','Passo máximo',NBR+', 6.3.10')
    for pos,e in [('top',c.support_end_top),('bottom',bottom)]:
        scalar('support_end_'+pos,e-dn/2,0.,'>','geometry','Ligamento líquido de extremidade '+pos)
        scalar('support_edge_'+pos+'_min',e,emin,'>=','detail','Borda mínima '+pos,NBR+', tabela16')
        scalar('support_edge_'+pos+'_max',e,min(12*c.t,150.),'<=','detail','Borda máxima '+pos,NBR+', 6.3.12')
    scalar('support_net_shear_length',c.length-c.support_rows*dn,0.,'>','geometry','Comprimento líquido da aba perfurada')
    for k in range(1,c.support_rows+1):
        scalar(f'support_net_prefix{k}',min(c.support_end_top,bottom)+(k-1)*c.support_pitch-(k-.5)*dn,0.,'>','geometry',f'Área líquida de bloco {k}')
    for name,e,t in [('angle_support_toe',g['support_free_toe_edge_mm'],c.t),('column_toe',g['column_flange_edge_mm'],c.support.tf)]:
        scalar(name+'_net',e-dn/2,0.,'>','geometry',name+': ligamento líquido')
        scalar(name+'_min',e,emin,'>=','detail',name+': borda mínima',NBR+', tabela16')
        scalar(name+'_max',e,min(12*t,150.),'<=','detail',name+': borda máxima',NBR+', 6.3.12')
    for name,e in [('top',c.support_edge_top),('bottom',c.support_edge_bottom)]:
        scalar('column_end_'+name,e-dn/2,0.,'>','geometry','Furo dentro da borda real do pilar '+name)
        scalar('column_end_'+name+'_min',e,emin,'>=','detail','Borda mínima real do pilar '+name,NBR+', tabela16')
    scalar('support_columns_min',2*z,pmin,'>=','detail','Distância entre duas linhas na mesa',NBR+', 6.3.9')
    if c.tool_radius<c.db/2:_issue(out,'access_pending','Raio de ferramenta menor que o raio do parafuso.','Montagem')
    if c.db in INDUSTRIAL:
        e,p=INDUSTRIAL[c.db];N=c.support_rows-1;zmin=40+2*e+N*p;zmax=zmin+p
        g.update(industrial_end_mm=e,industrial_pitch_mm=p,industrial_Z_min_mm=zmin,industrial_Z_max_mm=zmax)
        if not (math.isclose(c.support_pitch,p) and math.isclose(c.support_end_top,e) and math.isclose(bottom,e)):
            _issue(out,'preset_deviation','Passos/bordas reais diferem da tabela R015; a variação não é falha física automática.','R015 p.18')
        if not zmin<=g['industrial_Z_mm']<zmax:
            _issue(out,'preset_deviation',f'Z fora da faixa R015 para N={N} intervalos ({c.support_rows} parafusos por aba).','R015 p.18')
    else:_issue(out,'preset_deviation','Diâmetro fora da tabela métrica R015. Medidas imperiais e métricas permanecem distintas.','R015 p.18')
    g['valid']=not g['errors'];return g


def angle_elastic_section_envelope(c,group):
    """Exact U-line equilibrium; conservative combination of section extrema.

    The top/bottom branch tractions are affine in x. The support resultant
    acts at x=0. Cut V is quadratic and cut M cubic; all derivative roots
    inside each interval are evaluated, without a sampling-grid assumption.
    """
    F=group['force_y_N'];M=group['moment_about_centroid_Nmm'];J=group['J_line_mm3']
    xc=group['centroid_x_mm'];Lw=group['total_length_mm'];s=c.weld_start;b=c.beam_leg;H=c.length
    a=F/Lw+M*(s-xc)/J;k=M/J;end=b-s
    vpoints=[0.,end];mpoints=[0.,end]
    if k!=0:
        vroot=-a/k
        if 0<vroot<end:vpoints.append(vroot)
    # M'(u)=F+M H²/(2J)−2a u−k u².
    A=-k;B=-2*a;C=F+M*H*H/(2*J)
    if abs(A)<1e-30:
        if B!=0 and 0<-C/B<end:mpoints.append(-C/B)
    else:
        disc=B*B-4*A*C
        if disc>=0:
            for root in ((-B+math.sqrt(disc))/(2*A),(-B-math.sqrt(disc))/(2*A)):
                if 0<root<end:mpoints.append(root)
    def Vcut(u):return F-2*a*u-k*u*u
    def Mcut(u):return F*(s+u)-a*u*u-k*u**3/3+M*H*H*u/(2*J)
    vcandidates=[(0.,F),(s,F)]+[(s+u,Vcut(u)) for u in vpoints]
    mcandidates=[(0.,0.),(s,F*s)]+[(s+u,Mcut(u)) for u in mpoints]
    xv,vmax=max(vcandidates,key=lambda v:abs(v[1]));xm,mmax=max(mcandidates,key=lambda v:abs(v[1]))
    sigma=6*abs(mmax)/(c.t*H*H);tau=1.5*abs(vmax)/(c.t*H)
    return dict(max_abs_V_N=abs(vmax),V_critical_x_mm=xv,max_abs_M_Nmm=abs(mmax),M_critical_x_mm=xm,
        elastic_sigma_bound_MPa=sigma,elastic_tau_bound_MPa=tau,
        elastic_equivalent_stress_bound_MPa=math.sqrt(sigma*sigma+3*tau*tau),
        V_candidates=[dict(x_mm=x,V_N=v) for x,v in vcandidates],
        M_candidates=[dict(x_mm=x,M_Nmm=m) for x,m in mcandidates],
        equation='V=F−2au−ku²; M=F(s+u)−au²−ku³/3+Mwg H²u/(2J); u=x−s',
        bound='Extremos separados de sigma e tau combinados conservadoramente; não se acredita plastificação.')


def _evaluate(c):
    out=dict(status='INVALID_INPUT',global_pass=False,issues=[],checks=[],geometry={},load_model={},summary={},components={},
        physical_angles=[],welds={},scope=SCOPE,exclusions=EXCLUSIONS.copy(),not_applicable=[],
        inputs=_safe(asdict(c)) if isinstance(c,WeldedDoubleAngle) else _safe(c),
        units={'force':'N','length':'mm','area':'mm²','stress':'MPa','moment':'N mm','line_force':'N/mm'})
    errors=input_errors(c)
    if not errors:
        errors = missing_data_errors(c)
    if errors:
        for text in errors:_issue(out,'invalid_input',text)
        return out
    for bad,text in [
        (c.beam.family!='W' or c.support.family!='W','Viga e pilar W laminados exigidos.'),
        (c.kind!='column_flange','Somente mesa de pilar; apoio na alma exige outro modelo.'),
        (c.angle_count!=2 or not c.symmetric,'Somente par de cantoneiras idênticas e simétricas.'),
        (c.support_columns!=1,'Múltiplas colunas de parafusos alteram a flexão da aba de apoio.'),
        (any(x!=0 for x in (c.N,c.M,c.torsion)),'N, M ou torção não nulos: ações preservadas, modelo V-only não executado.'),
        (c.cope!='none','Viga recortada exige modelo de trecho recortado próprio.'),
        (not c.static,'Impacto, fadiga e carregamento cíclico fora do domínio estático.'),
        (not c.normal_combination,'Somente combinações últimas normais.'),
        (c.no_slip_required,'Resistência ao deslizamento requer verificação de serviço própria.'),
        (c.hole_type!='standard_round','Somente furo circular padrão.'),
        (c.db not in HOLES,'Diâmetro sem tabela de furação implementada.'),
        (c.bolt not in ('ASTM F3125 A325','ASTM F3125 A490'),'Classe de parafuso não implementada.'),
        (c.exposure not in ('painted','weathering'),'Exposição sem critério implementado.'),
        (c.support_rows<2,'Ao menos dois parafusos em cada aba de apoio.'),
        (c.weld_layout!='U_three_edges','Somente U de três bordas na aba da viga, sem solda no talão ou na aba saliente de apoio.'),
        (c.weld_process!='SMAW_E7018','Rota de filete exige processo/eletrodo SMAW E7018 compatível.'),
        (c.electrode_fuw<485.,'Grupo não uniforme exige classe E70 ou superior compatível; entrada inferior ao E7018 cadastrado.')]:
        if bad:_issue(out,'unsupported_scope',text,'Domínio R015/LCSP')
    if c.db in HOLES and not c.db<c.hole_diameter<=HOLES[c.db]:
        _issue(out,'unsupported_scope','Furo físico deve satisfazer db<dh≤máximo circular da Tabela14.',NBR+', tabela14')
    allowed_weld_steels={'ASTM A36','ASTM A572 Gr.42','ASTM A572 Gr.50','ASTM A572 Gr.55','ASTM A992'}
    for name,steel_name,ts in [('beam',c.beam_steel,[c.beam.tw,c.beam.tf]),('support',c.support_steel,[c.support.tw,c.support.tf]),('angle',c.angle_steel,[c.t])]:
        steel=STEELS.get(steel_name)
        if steel is None or not steel.rolled_allowed or any(not steel.profile_min<=t<=steel.profile_max for t in ts):
            _issue(out,'unsupported_scope',name+': produto/material/espessura fora do cadastro.',NBR+', tabelaA.2')
        if name!='support' and steel_name not in allowed_weld_steels:
            _issue(out,'unsupported_scope',name+': compatibilidade do metal-base com E7018 não cadastrada nesta rota.',NBR+', tabela8 e tabela9 nota(d)')
    if c.electrode_fuw>485.:
        _issue(out,'engineering_pending','Resistência informada acima dos 485 MPa cadastrados para E7018 requer classe/procedimento e compatibilidade documentados; o número é preservado, sem liberação automática.',NBR+', tabela8 e tabela9')
    standard=any(all(math.isclose(a,b,rel_tol=0,abs_tol=1e-8) for a,b in zip(
        (c.beam_leg,c.support_leg,c.t,c.support_gauge),case)) for case in ((76.,76.,6.4,45.),(102.,102.,8.,65.)))
    if not standard:
        _issue(out,'engineering_pending','Geometria alternativa válida pode ser calculada localmente, mas a classificação/flexão da aba de apoio não está validada por esta rota. As referências L76×76×6,4 g45 e L102×102×8 g65 são casos documentados, não limites universais de gabarito.','Gerdau2018 p.14,p.19–26; NBR6.1.1.3')
    if c.gap==0.:
        _issue(out,'engineering_pending','Folga zero pode criar contato da ponta da viga com o pilar e alterar a rotação e as forças; contato não verificado.',NBR+', 6.1.1.3 e6.1.3')
    g=geometry(c,out)
    if not g['valid']:out['status']='INVALID_GEOMETRY';return out
    if any(i['severity']=='unsupported_scope' for i in out['issues']):out['status']='OUTSIDE_R015_SCOPE';return out
    Vabs=max(abs(c.V),45000.);sgn=1 if c.V>=0 else -1
    out['load_model']=dict(Vsd_N=c.V,Vd_N=sgn*Vabs,assembly_minimum_N=45000.,each_angle_force_N=Vabs/2,
        each_support_group_force_N=Vabs/2,web_bolt_force_N=0.,directions_evaluated=[1,-1] if c.V==0 else [sgn],
        column_delivered_vertical_force_N=c.V,column_delivered_transport_moment_about_centroid_Nmm=c.V*c.support.d/2,
        beam_connection_end_moment_at_weld_toe_Nmm=c.V*c.beam_leg,
        column_transport_note='Somar ao modelo global apenas se ele ainda não inclui o transporte da face ao centro do pilar.',
        external_actions={'V':c.V,'N':c.N,'M':c.M,'torsion':c.torsion},
        serial_interfaces='Alma contínua → dois grupos de solda excêntricos → duas cantoneiras → parafusos → mesa do pilar; resistências em série não se somam.',
        eccentricity_model='Por cantoneira: Fy=Vd/2 em x=0; Mz=−xbar Fy; qx=−Mz(y−ybar)/J; qy=Fy/Lw+Mz(x−xbar)/J.',
        minimum_note='Piso de45kN aplicado uma única vez ao conjunto antes da divisão entre cantoneiras.')
    if abs(c.V)<45000.:
        _issue(out,'info','Piso de 45 kN aplicado ao conjunto; V real preservado. Para V=0 avaliam-se os dois sentidos estáticos.',NBR+', 6.1.5.2')
    sa,sb,ss=STEELS[c.angle_steel],STEELS[c.beam_steel],STEELS[c.support_steel]
    unit=elastic_line_group(weld_segments(c),0.,1.,0.,c.length/2)
    actual=elastic_line_group(weld_segments(c),0.,sgn*Vabs/2,0.,c.length/2)
    qfactor=unit['max_resultant_N_per_mm'];qw=.6*c.electrode_fuw*g['weld_throat_mm']/GAMMA_A2
    section=angle_elastic_section_envelope(c,unit)
    out['welds']=dict(layout=c.weld_layout,per_angle=actual,per_unit_angle_force=unit,
        leg_mm=c.weld_leg,throat_mm=g['weld_throat_mm'],electrode_fuw_MPa=c.electrode_fuw,
        weld_line_resistance_N_per_mm=qw,angle_section_per_unit_force=section,
        physical_group_count=2,actual_Vsd_scale=abs(c.V)/Vabs,
        base_metal_method='Tração/corte local em linha: limite conservador de von Mises e ruptura por corte por unidade de comprimento; alma única com tw/2 alocada a cada grupo simétrico.')
    out['load_model']['each_weld_group_moment_Nmm']=actual['moment_about_centroid_Nmm']
    out['load_model']['weld_centroid_x_mm']=actual['centroid_x_mm']
    for side in ('negative','positive'):
        ident='angle_'+side
        out['physical_angles'].append(dict(id=ident,side=side,beam_leg_mm=c.beam_leg,support_leg_mm=c.support_leg,
            thickness_mm=c.t,length_mm=c.length,force_N=Vabs/2,weld_group=ident+'_weld'))
        _check(out,ident+'_weld_rupture','Ruptura do grupo U excêntrico',ident+'_weld',qw/qfactor,.5,
            'VRd,ângulo=[0,60 fuw (w/√2)/γa2]/qmax(F=1)',NBR+', 6.2.5 tabela9; distribuição elástica em equilíbrio',
            peak_line_force_N_per_mm=actual['max_resultant_N_per_mm'],line_resistance_N_per_mm=qw,
            line_force_per_unit_angle_force_per_mm=qfactor,throat_mm=g['weld_throat_mm'],
            weld_total_length_mm=actual['total_length_mm'],centroid_x_mm=actual['centroid_x_mm'],J_line_mm3=actual['J_line_mm3'],
            moment_Nmm=actual['moment_about_centroid_Nmm'],no_directional_strength_gain=True)
        for mode,capacity,formula in [
            ('yield',sa.fy*c.t/(math.sqrt(3)*GAMMA_A1),'fy t/(√3 γa1) ≥ |q|; limite conservador de von Mises'),
            ('rupture',.6*sa.fu*c.t/GAMMA_A2,'0,60 fu t/γa2 ≥ |q|; comparação local conservadora por unidade de comprimento')]:
            _check(out,ident+'_weld_base_'+mode,'Metal-base da cantoneira junto ao U · '+{'yield':'escoamento','rupture':'ruptura'}[mode],ident+'_beam',capacity/qfactor,.5,
                formula,NBR+', tabela9 remete a6.5; AISC MSC jul.2016 Keeping Fillet, fig.3; suplemento racional conservador',
                local_line_capacity_N_per_mm=capacity,thickness_mm=c.t,base_metal_only=True)
        eq=section['elastic_equivalent_stress_bound_MPa']
        _check(out,ident+'_beam_elastic_interaction','Aba soldada · interação elástica de flexão e corte no plano',ident+'_beam',sa.fy/GAMMA_A1/eq,.5,
            '√[(6Mmax/tL²)²+3(1,5Vmax/tL)²] ≤ fy/γa1; envelope exato de equilíbrio do U',
            NBR+', 6.1.1.3 e6.5; suplemento elástico sem crédito plástico',
            per_unit_angle_force=section,no_yielding_credit=True)
        for leg,n in [('beam',0),('support',c.support_rows)]:
            Ag=c.length*c.t;An=(c.length-n*g['dn'])*c.t;component=ident+'_'+leg
            out['components'][component]=dict(material=asdict(sa),physical_angle=ident,leg=leg,Ag_mm2=Ag,An_mm2=An,
                thickness_mm=c.t,force_fraction=.5,deducted_holes=n)
            _check(out,component+'_shear_gross','Cisalhamento · escoamento bruto',component,.6*sa.fy*Ag/GAMMA_A1,.5,
                '0,60 fy Ag/γa1',NBR+', 6.5.5(a)',Ag_mm2=Ag)
            _check(out,component+'_shear_net','Cisalhamento · ruptura líquida',component,.6*sa.fu*An/GAMMA_A2,.5,
                '0,60 fu An/γa2',NBR+', 6.5.5(b)',An_mm2=An,deducted_holes=n,
                net_hole_deduction_mm=g['dn'] if n else 0.)
    # A single web receives both aligned weld fields. Check 2q against full tw.
    for mode,capacity,formula in [('yield',sb.fy*c.beam.tw/(math.sqrt(3)*GAMMA_A1),'fy tw/(√3 γa1) ≥ 2|qângulo|'),
        ('rupture',.6*sb.fu*c.beam.tw/GAMMA_A2,'0,60 fu tw/γa2 ≥ 2|qângulo|')]:
        _check(out,'beam_weld_base_'+mode,'Alma única junto às duas soldas · '+{'yield':'escoamento','rupture':'ruptura'}[mode],'beam_web',capacity/qfactor,1.,
            formula,NBR+', tabela9 remete a6.5; AISC MSC jul.2016 Keeping Fillet, fig.3; envelope conservador',
            thickness_mm=c.beam.tw,combined_peak_line_force_N_per_mm=2*actual['max_resultant_N_per_mm'],
            full_web_line_capacity_N_per_mm=capacity,web_thickness_count=1)
    h=c.beam.clear;Ag=h*c.beam.tw
    out['components']['beam_web']=dict(material=asdict(sb),Ag_mm2=Ag,An_mm2=Ag,thickness_mm=c.beam.tw,force_fraction=1.,deducted_holes=0)
    _check(out,'beam_web_shear_gross','Alma da viga · cisalhamento bruto local','beam_web',.6*sb.fy*Ag/GAMMA_A1,1.,'0,60 fy h_livre tw/γa1',NBR+', 6.5.5(a)',Ag_mm2=Ag)
    _check(out,'beam_web_shear_net','Alma sem furos · ruptura local','beam_web',.6*sb.fu*Ag/GAMMA_A2,1.,'0,60 fu h_livre tw/γa2; An=Ag',NBR+', 6.5.5(b)',An_mm2=Ag,deducted_holes=0)
    lam=h/c.beam.tw;lp=1.1*math.sqrt(5.34*200000./sb.fy);lr=1.37*math.sqrt(5.34*200000./sb.fy)
    Cv=1. if lam<=lp else lp/lam if lam<=lr else 1.24*(lp/lam)**2
    _check(out,'beam_web_shear_buckling','Alma da viga · cisalhamento com instabilidade','beam_web',.6*sb.fy*c.beam.d*c.beam.tw*Cv/GAMMA_A1,1.,
        '0,60 fy (d tw) Cv/γa1; kv=5,34',NBR+', 5.4.3.1',lambda_web=lam,lambda_p=lp,lambda_r=lr,Cv=Cv)
    ab=math.pi*c.db*c.db/4;grip=g['support_grip_mm'];grip_factor=max(0.,1-.01*max(0.,grip-5*c.db)/1.5)
    rdplane=bolt_shear_resistance(c.db,BOLTS[c.bolt],c.support_threads_excluded,grip_factor)
    out['bolts']=dict(Ab_mm2=ab,fub_MPa=BOLTS[c.bolt],groups=[])
    for side in ('negative','positive'):
        out['bolts']['groups'].append(dict(id='support_'+side,bolt_count=c.support_rows,shear_planes=1,
            coefficient=.56 if c.support_threads_excluded else .45,grip_mm=grip,grip_factor=grip_factor,
            resistance_per_plane_N=rdplane,each_bolt_force_N=Vabs/(2*c.support_rows),each_plane_force_N=Vabs/(2*c.support_rows)))
        _check(out,'bolt_support_'+side,'Parafusos da aba de apoio · corte simples','bolt_support_'+side,c.support_rows*rdplane,.5,
            'n α Ab fub/γa2 × fator de pega',NBR+', 6.3.3.2 e6.3.7',bolt_count=c.support_rows,shear_planes=1,grip_factor=grip_factor)
        out['components']['column_flange_'+side]=dict(material=asdict(ss),thickness_mm=c.support.tf,force_fraction=.5,free_toe_distance_mm=g['column_flange_edge_mm'])
    for sign in out['load_model']['directions_evaluated']:
        suffix='_Vpos' if sign>0 else '_Vneg';beam_dir='down' if sign>0 else 'up';support_dir='up' if sign>0 else 'down'
        for side in ('negative','positive'):
            ident='angle_'+side+'_support'+suffix;end=c.support_end_top if sign>0 else g['support_end_bottom_mm']
            bearing_rows(out,c,ident,c.support_rows,c.support_pitch,c.t,sa.fu,.5,end,support_dir)
            l_blocks(out,ident,c.support_rows,c.support_pitch,end,g['support_free_toe_edge_mm'],c.t,g['dn'],sa.fy,sa.fu,.5,1.,support_dir,NBR+', 6.5.6; Gerdau2018 p.25')
            ident='column_flange_'+side+suffix;end=c.support_edge_bottom if sign>0 else c.support_edge_top
            bearing_rows(out,c,ident,c.support_rows,c.support_pitch,c.support.tf,ss.fu,.5,end,beam_dir)
            l_blocks(out,ident,c.support_rows,c.support_pitch,end,g['column_flange_edge_mm'],c.support.tf,g['dn'],ss.fy,ss.fu,.5,.5,beam_dir,
                NBR+', 6.5.6; borda lateral e extremidade reais do pilar, Cts=0,5 conservador')
    out['not_applicable']=[
        dict(mechanism='Parafusos/furos na alma da viga ou aba soldada',reason='Interface inteiramente soldada; nenhuma dedução de furos fictícios.',reference='R015 p.18; Gerdau2018 p.19'),
        dict(mechanism='Bloco L de viga recortada',reason='Sem recorte, furos ou borda horizontal livre na alma. Mesas contínuas impedem transplantar o bloco da viga recortada.',reference='Gerdau2018 p.25'),
        dict(mechanism='Retorno soldado na aba saliente de apoio',reason='Não existe solda no apoio nem fechamento do talão. Os três trechos do U ficam na aba junto à viga.',reference=NBR+', 6.2.6.2.6(c); Gerdau2018 p.19/p.50'),
        dict(mechanism='Flexão transversal/punção por ação normal à mesa do apoio',reason='V age no plano da mesa no modelo usual simétrico; N=M=T externos nulos.',reference='Domínio convencional LCSP; NBR6.1.1.3')]
    _issue(out,'info','O U é integrado por cantoneira e recebe V/2 com momento geométrico. Nenhuma capacidade de solda é somada à dos parafusos em série. Os dois campos atuam na mesma alma física.','Gerdau2018 p.26; equilíbrio elástico')
    _issue(out,'info','Classificação flexível restrita ao detalhe usual documentado, sem solda na aba saliente do apoio, sem talão fechado e com folgas. Não calcula curva momento–rotação, resistência/estabilidade global ou fadiga.',NBR+', 6.1.2.3,6.1.3,6.1.7')
    _issue(out,'info','Capacidades históricas LCSP do Gerdau usam ICR e NBR2008; não são convertidas globalmente nem usadas como resultado-alvo do modelo elástico atual.','Gerdau2018 p.26 e50')
    if c.beam.source.startswith('material didático') or c.support.source.startswith('material didático'):
        _issue(out,'warning','Dimensões/raios de catálogo didático: conferir fornecimento antes da fabricação.','Cadastro dos perfis')
    failures=[r['id'] for r in out['checks'] if r['status']=='FAIL'];governing=max(out['checks'],key=lambda r:r['utilization'])
    severities={i['severity'] for i in out['issues']};pending=bool(severities&{'engineering_pending','access_pending'})
    out['summary']=dict(governing_check_id=governing['id'],governing_label=governing['label'],governing_component=governing['component'],
        governing_utilization=governing['utilization'],actual_governing_utilization=governing['actual_utilization'],
        equivalent_total_V_capacity_N=governing['equivalent_total_V_capacity_N'],failed_check_ids=failures,check_count=len(out['checks']),
        strength_status='FAIL' if failures else 'PASS',complete_checks=not pending,physical_angle_count=2)
    out['status']=('VERIFIED_SUBCHECK_FAIL' if failures else 'DETAIL_FAIL' if 'detail_fail' in severities else 'ENGINEERING_MODEL_PENDING' if pending else
        'COMPLETE_CHECKS_PASS_WITH_PRESET_DEVIATION' if 'preset_deviation' in severities else 'COMPLETE_CHECKS_PASS_WITHIN_SCOPE')
    out['global_pass']=out['status'] in ('COMPLETE_CHECKS_PASS_WITH_PRESET_DEVIATION','COMPLETE_CHECKS_PASS_WITHIN_SCOPE')
    return out


def evaluate(c):
    try:
        out=_evaluate(c)
        def finite(value):
            if isinstance(value,float):return math.isfinite(value)
            if isinstance(value,dict):return all(finite(v) for v in value.values())
            if isinstance(value,(tuple,list)):return all(finite(v) for v in value)
            return True
        if not finite(out):raise ArithmeticError('Faixa numérica finita excedida.')
        return out
    except (ArithmeticError,OverflowError,ValueError) as exc:
        return dict(status='NUMERICAL_FAILURE',global_pass=False,issues=[dict(severity='numerical_failure',text=str(exc),reference='Faixa numérica do cálculo; entrada finita não garante resultados derivados representáveis')],
            checks=[],geometry={},load_model={},summary={},components={},physical_angles=[],welds={},scope=SCOPE,
            exclusions=EXCLUSIONS.copy(),inputs=_safe(asdict(c)) if isinstance(c,WeldedDoubleAngle) else _safe(c))
