"""Complete opposed 2L ><, two distinct single-shear rows, one gusset and W root.

N, mm, MPa. NBR 8800:2024/Errata 1:2025 normal static tension; method-qualified
conventional limit states plus separately identified supplemental nominal screens.
The actual angle end eccentricity is idealized under 6.1.8.2, not erased physically.
One central gusset and one double root receive TOTAL N in this opposed arrangement.
No old axial or welded connection result is used as a complete-route shortcut.
"""
from __future__ import annotations
from dataclasses import asdict, dataclass, fields, replace
import math
from .models import BOLTS, finite_real
from .angle_catalog import get_angle, catalog
from .welded_angle_gusset import MATERIALS, ELECTRODES, SUPPORT_CATALOG, minimum_fillet
from .bolted_gusset_geometry import point, ray_exit, transverse_chord
from .bolted_opposed_gusset_geometry import (rupture_paths, partial_bounds, zigzag_chains,
    horizontal_sections, force_normal_sections, solid_ligament)
from .bolted_angle_gusset import root_checks as _shared_root_checks

FAMILY = 'Ligação 2L opostas ><–gusset–mesa W · parafusada completa'
CONNECTION_TYPE = 'bolted_opposed_angle_gusset'
COMPONENT_VERSION = '0.9.31-opposed-bolted-gusset-dev'
UNITS = {'force': 'N', 'length': 'mm', 'stress': 'MPa', 'moment': 'N mm'}
GAMMA_A1, GAMMA_A2, GAMMA_W2 = 1.10, 1.35, 1.35
ARRANGEMENTS = ('2L-opposed',)
HOLES = {12.7: 14.2875, 15.875: 17.4625, 19.05: 20.6375, 22.225: 23.8125,
         25.4: 28.575, 28.575: 31.75, 31.75: 34.925, 36.: 39.,
         16.: 18., 20.: 22., 22.: 24., 24.: 27., 27.: 30., 30.: 33.}
EDGES = {12.7: 19., 15.875: 22., 19.05: 25., 22.225: 28., 25.4: 32.,
         28.575: 38., 31.75: 41., 36.: 45., 16.: 22., 20.: 26.,
         22.: 28., 24.: 30., 27.: 34., 30.: 38.}
SCOPE = ('Duas L idênticas opostas ><, contato direto, h=tg, duas linhas distintas alinhadas, '
    '2n parafusos físicos de corte simples. Cada L recebe N/2; uma chapa perfurada, dois filetes de raiz e um W recebem N integral. '
    'Tração estática normal; NBR8800:2024/Errata1:2025 6.1.8.2 aplicada individualmente a cada L. '
    'Idealização de extremidade não comprova cancelamento físico dos binários locais de face. '
    'Sinal nominal no trecho perfurado é diagnóstico; compressão da raiz/ligamento íntegro continua fora do domínio.')
EXCLUSIONS = [
    'Compressão, fadiga, sismo, reversão e V/M/T externos; enchimentos, afastamentos e prying espacial.',
    'L desiguais, partilha desigual, linhas escalonadas/assimétricas, furos alongados e crédito por atrito.',
    'Raiz transversal/descontínua, alma W direta, I soldado, segundo apoio ou ligação de canto.',
    'Triagens de seção perfurada e espessura alocada são suplementos nominais; não representam campo exato de contato/contínuo.',
    'Envelope conservador parcial cobre pernas retas na pegada nominal dos furos, não fissuras curvas arbitrárias.',
    'Resultado local não aprova fabricação, montagem sem detalhe real, WPS/inspeção ou estabilidade global.',
    'Ações concorrentes reais do W devem ser combinadas às ações exportadas; apoio descarregado não presumido.',
]
SOURCES = {'NBR': 'ABNT NBR8800:2024/Errata1:2025 §§5.2,5.7,6.1.8.2,6.2,6.3,6.5; Tabelas14/16',
    'DG29': 'AISC DG29(2014), Ex5.4: rota convencional adaptada; topologia/fatores AISC não transplantados',
    'qualification': 'Opposed bolted qualification revision2, 2026-10-11; 736 independent reference comparisons'}



@dataclass(frozen=True)
class BoltedOpposedAngleGusset:
    project: str = '2L opostas >< Gerdau L76,2×6,35 → gusset300×300×12,5 → mesa W · 80° · N100kN'
    arrangement: str = '2L-opposed'
    support_member: str = 'beam'
    support_face: str = 'flange'
    angle_profile: str = 'GERDAU_EQUAL_ANGLE_P03_R29'
    support_profile: str = 'W310x165x52'
    angle_steel: str = 'ASTM A36'
    gusset_steel: str = 'ASTM A36'
    support_steel: str = 'ASTM A572 Gr.50'
    plate_width: float = 300.
    plate_height: float = 300.
    plate_t: float = 12.5
    theta_deg: float = 80.
    center_s: float = 0.
    center_n: float = 150.
    row_offset: float = 0.
    bolt: str = 'ASTM F3125 A325'
    db: float = 16.
    n: int = 3
    pitch: float = 50.
    gauge: float = 40.
    angle_end: float = 35.
    drilled: bool = True
    threads_excluded_1: bool = False
    threads_excluded_2: bool = False
    pretensioned: bool = False
    exposure: str = 'painted'
    tool_radius: float = 18.
    fabrication_clearance: float = 2.
    heel_extent: float | None = None
    heel_extent_source: str = ''
    washer_stack: float = 0.
    root_weld_leg: float = 5.
    root_electrode: str = 'E60'
    support_end_left: float = 1000.
    support_end_right: float = 1000.
    N: float = 100000.
    V: float = 0.
    M: float = 0.
    torsion: float = 0.
    static: bool = True
    normal_combination: bool = True
    fatigue: bool = False
    seismic: bool = False
    minimum_force: bool = True
    recommend_half_capacity: bool = False
    notes: str = ''

    @property
    def angle_count(self):
        return 2

    @property
    def hole_diameter(self):
        return HOLES.get(self.db) if finite_real(self.db) else None

    @property
    def fixed_assumptions(self):
        return dict(topology='opposed_identical_angles_two_distinct_single_shear_rows',
            arrangement=self.arrangement, angle_count=2, physical_bolt_rows=2,
            physical_bolts='2*n', shear_planes_per_bolt=1, common_gusset_count=1, double_root_count=1,
            contact='firm_direct_no_fillers', heel_gap='h=plate_t', row_v='plus_minus(plate_t/2+gauge)',
            load_model='NBR6.1.8.2_static_nominal_model_separately_each_angle',
            out_of_plane='local_face_couples_idealized_not_proved_cancelled',
            angle_shear_lag='actual_catalog_ec_Lc_first_to_last_Ct_floor0.5',
            total_N='each_angle_N/2_each_physical_bolt_N/(2*n)_one_plate_root_W_full_N',
            bearing='each_distinct_hole_N/(2*n)_opposite_part_directions',
            net_hole_policy='Table14_plus2mm_unless_drilled', slip_resistance_credit=False,
            block='outer_L_inward_L_both_U_actual_caps_Cts0.5_root_attached_inactive',
            partial_bound='correlated_cap_remaining_holes_and_captured_load_zero_transverse_credit',
            net_chains='all_n_squared_two_row_chains_actual_side_exits_NBR_stagger_credit',
            sections='all_crossing_masks_both_cut_directions_union_chords_supplemental_material_screen',
            sign_diagnostic='introduction_sign_informative_only_unperforated_ligament_root_tension_gated',
            Whitmore='aggregate_plus_per_row_half_plate_thickness_no_double_material',
            root='one_double_equal_longitudinal_root_centered_on_exterior_rolled_W_flange',
            gamma_a1=GAMMA_A1, gamma_a2=GAMMA_A2, gamma_w2=GAMMA_W2,
            support_member_global_pass=False)

    def to_dict(self):
        errors = input_errors(self)
        if errors:
            raise ValueError('; '.join(errors))
        if self.arrangement not in ARRANGEMENTS:
            raise ValueError('Arranjo nativo deve ser 2L-opposed; T/1L não são este modelo.')
        return dict(schema_version=1, connection_type=CONNECTION_TYPE, component_version=COMPONENT_VERSION,
            connection=asdict(self), units=dict(UNITS), fixed_assumptions=self.fixed_assumptions)

    @classmethod
    def from_dict(cls, data):
        required = {'schema_version', 'connection_type', 'component_version', 'connection', 'units', 'fixed_assumptions'}
        if not isinstance(data, dict) or set(data) != required:
            raise ValueError('Ligação parafusada completa: campos nativos ausentes ou desconhecidos.')
        if type(data['schema_version']) is not int or data['schema_version'] != 1 or data['connection_type'] != CONNECTION_TYPE or data['component_version'] != COMPONENT_VERSION:
            raise ValueError('Família/versão incompatível; componentes axiais ou soldados não são migrados silenciosamente.')
        raw = data['connection']
        if not isinstance(raw, dict) or set(raw) != {f.name for f in fields(cls)}:
            raise ValueError('Campos da ligação parafusada incompletos ou desconhecidos.')
        candidate = cls(**raw)
        canonical = candidate.to_dict()
        if not _exact(data['units'], canonical['units']) or not _exact(data['fixed_assumptions'], canonical['fixed_assumptions']):
            raise ValueError('Unidades ou premissas incompatíveis; nenhuma conversão silenciosa.')
        return candidate


def _exact(a, b):
    if type(a) is not type(b):
        return False
    if isinstance(b, dict):
        return set(a) == set(b) and all(_exact(a[k], b[k]) for k in b)
    if isinstance(b, list):
        return len(a) == len(b) and all(_exact(x, y) for x, y in zip(a, b))
    return a == b


def input_errors(c):
    if not isinstance(c, BoltedOpposedAngleGusset):
        return ['Entrada deve ser BoltedOpposedAngleGusset.']
    errors = []
    for f in fields(c):
        value = getattr(c, f.name)
        if f.type in ('str', str):
            if not isinstance(value, str):
                errors.append(f.name+': texto obrigatório.')
        elif f.type in ('bool', bool):
            if type(value) is not bool:
                errors.append(f.name+': booleano explícito obrigatório.')
        elif f.name == 'n':
            if type(value) is not int or value < 2:
                errors.append('n: inteiro >=2 obrigatório por linha; Lc deve ser positivo.')
        elif f.name == 'heel_extent' and value is None:
            pass
        elif not finite_real(value):
            errors.append(f.name+': número real finito obrigatório.')
    return errors


def presets():
    base = replace(BoltedOpposedAngleGusset(), heel_extent=12.35,
        heel_extent_source='Hipótese dimensional explícita: talão12,35mm (t+6); NÃO é dado Gerdau; verificar peça real.')
    return {'2L opostas >< · B300 · 80° · N100kN · detalhe assumido': base,
        '2L opostas >< · B340 · 80°': replace(base, plate_width=340., project='2L opostas >< · B340/80°'),
        '2L opostas >< · 90°': replace(base, theta_deg=90., project='2L opostas >< · 90°'),
        '2L opostas >< · 100° · espelho': replace(base, theta_deg=100., project='2L opostas >< · 100°'),
        '2L opostas >< · N300kN · falha': replace(base, N=300000., project='2L opostas >< · N300kN · falha'),
        '2L opostas >< · N real zero': replace(base, N=0., project='2L opostas >< · N real zero'),
        '2L opostas >< · 70° · raiz comprimida': replace(base, theta_deg=70., project='2L opostas >< · 70° · fora do domínio'),
        '2L opostas >< · talão real pendente': BoltedOpposedAngleGusset()}


def _safe(value):
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return value if finite_real(value) else None
    if isinstance(value, dict):
        return {str(k): _safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_safe(v) for v in value]
    return value if value is None or isinstance(value, (str, bool)) else repr(value)


def _issue(out, id, severity, message, **detail):
    out['issues'].append(dict(id=id, severity=severity, message=message, **detail))


def _row(out, id, label, component, mechanism, case, demand, resistance, unit='N', reference='', **details):
    if not all(finite_real(v) for v in (demand, resistance)) or demand < 0 or resistance <= 0:
        raise ArithmeticError('Nonpositive/nonfinite demand or capacity: '+id)
    utilization = demand/resistance
    out['checks'].append(dict(id=case+'__'+id, label=label, component=component,
        mechanism=mechanism, case_id=case, demand=demand, resistance=resistance, unit=unit,
        utilization=utilization, status='PASS' if utilization <= 1. else 'FAIL',
        reference=reference, details=details))


def _geometry(c, out):
    A, W = get_angle(c.angle_profile), SUPPORT_CATALOG.get(c.support_profile)
    if A is None or W is None:
        return None
    if A['Ag'] is None or A['centroid'] is None:
        _issue(out, 'missing_catalog_properties', 'outside_scope', 'Ag/ec não publicados; não são inferidos.')
        return None
    positive = ('plate_width', 'plate_height', 'plate_t', 'pitch', 'gauge', 'angle_end', 'db',
        'tool_radius', 'root_weld_leg', 'support_end_left', 'support_end_right')
    if any(getattr(c, key) <= 0 for key in positive) or c.fabrication_clearance < 0 or c.washer_stack < 0:
        _issue(out, 'positive_geometry', 'invalid_geometry', 'Dimensões positivas e folgas/arruelas não negativas obrigatórias.')
        return None
    if c.heel_extent is not None and c.heel_extent < A['t']:
        _issue(out, 'heel_extent_geometry', 'invalid_geometry', 'Envelope interno do talão deve alcançar ao menos a espessura da aba.')
    if not 0 < c.theta_deg < 180:
        _issue(out, 'theta_domain', 'outside_scope', 'Exige 0<theta<180 graus, direção de tração afastando da raiz.')
        return None
    if c.hole_diameter is None:
        _issue(out, 'diameter_system', 'outside_scope', 'Diâmetro/sistema sem furo padrão identificado nas Tabelas14/16.')
        return None
    B, H, dh = c.plate_width, c.plate_height, c.hole_diameter
    dn = dh if c.drilled else dh+2.
    C, S = math.cos(math.radians(c.theta_deg)), math.sin(math.radians(c.theta_deg))
    stations = [c.row_offset+(j-(c.n-1)/2)*c.pitch for j in range(c.n)]
    row_v = [-c.plate_t/2-c.gauge, c.plate_t/2+c.gauge]
    holes = [point(c, u, v) for v in row_v for u in stations]
    tool = c.tool_radius+c.fabrication_clearance
    end_u = stations[0]-c.angle_end
    leg_intervals = [[-c.plate_t/2-A['leg'], -c.plate_t/2], [c.plate_t/2, c.plate_t/2+A['leg']]]
    rows = []
    for ri, (v, vs) in enumerate(zip(row_v, leg_intervals)):
        footprint = [point(c, end_u, vs[0]), point(c, stations[-1]+tool, vs[0]),
            point(c, stations[-1]+tool, vs[1]), point(c, end_u, vs[1])]
        rows.append(dict(row=ri, face=-1 if ri == 0 else 1, v=v,
            bolt_centers=holes[ri*c.n:(ri+1)*c.n], connected_leg_v=vs,
            footprint_corners=footprint, angle_free_end=[point(c, end_u, z) for z in vs]))
    footprint = [p for row in rows for p in row['footprint_corners']]
    ends = [p for row in rows for p in row['angle_free_end']]
    grip = A['t']+c.plate_t+c.washer_stack
    exempt = c.pretensioned and c.bolt in ('ASTM F3125 A325', 'ASTM F3125 A490')
    grip_raw = 1.-.01*max(0., grip-5*c.db)/1.5
    factor = 1. if exempt else max(0., grip_raw)
    g = dict(valid=False, polygon=[[-B/2, 0.], [B/2, 0.], [B/2, H], [-B/2, H]],
        direction=[C, S], center=[c.center_s, c.center_n], force_point=point(c, c.row_offset),
        bolt_stations=stations, bolt_centers=holes, hole_diameter=dh, net_hole_diameter=dn,
        angle_section=dict(A), support_catalog=dict(W), angle_count=c.angle_count,
        shear_planes=1, shear_planes_per_bolt=1, physical_bolt_count=2*c.n, physical_gusset_count=1,
        bolt_rows=rows, row_v=row_v, row_spacing=row_v[1]-row_v[0], h=c.plate_t,
        angle_footprints=[row["footprint_corners"] for row in rows],
        root_endpoints=[[-B/2, 0.], [B/2, 0.]], root_centroid=[0., 0.], root_length=B,
        plate_width=B, plate_height=H, plate_t=c.plate_t, theta_deg=c.theta_deg,
        root_weld_leg=c.root_weld_leg, footprint_corners=footprint, angle_free_end=ends,
        angle_free_end_u=end_u, connected_leg_v=leg_intervals, grip=grip, grip_factor=factor,
        grip_factor_raw=grip_raw, grip_pretension_exemption=exempt, washer_stack=c.washer_stack,
        support_end_clearances=[c.support_end_left-B/2, c.support_end_right-B/2],
        tool_required=tool, Lc=(c.n-1)*c.pitch,
        heel_extent=c.heel_extent, heel_extent_source=c.heel_extent_source,
        heel_extent_catalog_verified=False, fabrication_notes=[], inactive_path_families=[])
    def limit(id, actual, bound, operator='>=', severity='detail_fail', message=None, reference='NBR6.3/Tabelas14/16'):
        ok = (actual >= bound-1e-9 if operator == '>=' else actual <= bound+1e-9 if operator == '<=' else actual > bound)
        g.setdefault('detail_checks', []).append(dict(id=id, actual=actual, bound=bound, operator=operator,
            status='PASS' if ok else 'FAIL', reference=reference))
        if not ok:
            _issue(out, id, severity, message or id+': limite dimensional não atendido.', actual=actual, bound=bound)
    for j, (x, y) in enumerate(holes):
        clearances = dict(left=x+B/2, right=B/2-x, root=y, top=H-y)
        for edge, gap in clearances.items():
            limit(f'hole{j+1}_{edge}_net_ligament', gap, dn/2+1e-8, severity='invalid_geometry')
            limit(f'hole{j+1}_{edge}_tool', gap, tool+(c.root_weld_leg if edge == 'root' else 0.),
                severity='invalid_geometry', reference='Envelope real informado de ferramenta/hardware e raiz')
            if edge != 'root':
                limit(f'hole{j+1}_{edge}_minimum', gap, EDGES[c.db])
    def inside(p):
        return -B/2-1e-9 <= p[0] <= B/2+1e-9 and c.root_weld_leg+1e-9 <= p[1] <= H+1e-9
    if not all(inside(p) for p in footprint):
        _issue(out, 'angle_footprint_containment', 'invalid_geometry', 'Sobreposição física da aba/endereço livre ou envelope da última fixação cruza borda/raiz.')
    if min(g['support_end_clearances']) < 0:
        _issue(out, 'root_beyond_support', 'invalid_geometry', 'Raiz ultrapassa extremidade real do W.')
    for edge, distance in [('left', min(x+B/2 for x, _ in holes)), ('right', min(B/2-x for x, _ in holes)), ('top', min(H-y for _, y in holes))]:
        limit('gusset_'+edge+'_maximum_edge', distance, min(12*c.plate_t, 150.), '<=',
            reference='NBR6.3.12: distância ao parafuso mais próximo de CADA borda livre; raiz não é borda livre')
    limit('cross_row_pitch_min', row_v[1]-row_v[0], max(2.7*c.db, dh+c.db))
    limit('cross_row_net_ligament', row_v[1]-row_v[0]-dn, 1e-8, severity='invalid_geometry')
    limit('cross_row_tool_clearance', row_v[1]-row_v[0], 2*c.tool_radius+c.fabrication_clearance)
    limit('opposite_face_tool_to_other_L', c.plate_t+c.gauge, tool, severity='invalid_geometry')
    limit('pitch_min', c.pitch, max(2.7*c.db, dh+c.db))
    limit('pitch_net_ligament', c.pitch-dn, 1e-8, severity='invalid_geometry')
    thin = min(A['t'], c.plate_t)
    limit('pitch_max', c.pitch, min(14*thin, 180.) if c.exposure == 'weathering' else min(24*thin, 300.), '<=')
    limit('tool_covers_hole', c.tool_radius, dh/2, severity='invalid_geometry')
    limit('adjacent_tool_clearance', c.pitch, 2*c.tool_radius+c.fabrication_clearance)
    for key, distance in [('angle_end', c.angle_end), ('angle_toe', A['leg']-c.gauge)]:
        limit(key+'_net_ligament', distance, dn/2+1e-8, severity='invalid_geometry')
        limit(key+'_minimum', distance, EDGES[c.db])
        limit(key+'_maximum', distance, min(12*A['t'], 150.), '<=')
        limit(key+'_tool', distance, tool, severity='invalid_geometry')
    limit('known_heel_thickness_hole_clearance', c.gauge-A['t'], dh/2, severity='invalid_geometry')
    limit('known_heel_thickness_tool_clearance', c.gauge-A['t'], tool, severity='invalid_geometry')
    if c.heel_extent is None:
        _issue(out, 'heel_extent_missing', 'detail_pending', 'Informar envelope interno real do talão e sua origem; catálogo Gerdau não publica raio. Mecânica não certifica montagem.')
    else:
        limit('heel_hole_clearance', c.gauge-c.heel_extent, dh/2, severity='invalid_geometry')
        limit('heel_tool_clearance', c.gauge-c.heel_extent, tool, severity='invalid_geometry')
        if not c.heel_extent_source.strip():
            _issue(out, 'heel_extent_source_missing', 'detail_pending', 'Identificar origem do envelope real/hipótese dimensional do talão.')
        g['fabrication_notes'].append('Envelope de talão informado: '+str(c.heel_extent)+' mm; '+c.heel_extent_source)
    if c.pitch < 3*c.db:
        _issue(out, 'pitch_preferred', 'warning', 'Passo atende mínimo se verificado; preferência3d não alcançada.')
    limit('grip_factor_positive', factor, 0., '>', severity='invalid_geometry', reference='NBR6.3.7: redução por pega, arruelas incluídas conservadoramente')
    limit('lap_overlap', g['Lc']+c.angle_end, max(5*thin, 25.))
    limit('root_fillet_min', c.root_weld_leg, minimum_fillet(min(c.plate_t, W['tf'])), reference='NBR6.2.6.2: peça menos espessa')
    limit('root_fillet_max', c.root_weld_leg, c.plate_t if c.plate_t < 6.3 else c.plate_t-1.5, '<=', reference='NBR6.2.6.2: borda ordinária do gusset')
    limit('root_effective_length', B, max(4*c.root_weld_leg, 40.), reference='NBR6.2.2.2')
    limit('root_weld_long_limit', B/c.root_weld_leg, 100., '<=', severity='outside_scope', reference='L/s>100: redução de comprimento não coberta')
    limit('flange_footprint', c.plate_t+2*c.root_weld_leg, W['bf'], '<=', severity='invalid_geometry')
    if any(i['severity'] in ('invalid_geometry', 'outside_scope') for i in out['issues']):
        return g
    for row in rows:
        forward = ray_exit(c, row['bolt_centers'][0], [C, S])
        row['forward_exit'] = dict(forward, u=stations[0]+forward['distance'])
        if forward['edge'] == 'root':
            _issue(out, 'forward_root', 'invalid_geometry', 'Saída carregada não pode ser raiz apoiada.')
    g['forward_exits'] = [row['forward_exit'] for row in rows]
    g['forward_exit'] = g['forward_exits'][0]  # presentation convenience, never used for the other row.
    g['force_line_root_s'] = c.center_s-c.center_n*C/S
    g['transverse_stations'] = [dict(u=u, chord=transverse_chord(c, u)) for u in stations]
    chord = transverse_chord(c, stations[0])
    left, right = -chord['left']['distance'], chord['right']['distance']
    spread = 2*g['Lc']*math.tan(math.pi/6)
    whitmores = []
    for id, vc, width, thickness, hole_vs in [('aggregate', 0., row_v[1]-row_v[0]+spread, c.plate_t, row_v),
        ('row_0_half_depth', row_v[0], spread, c.plate_t/2, [row_v[0]]),
        ('row_1_half_depth', row_v[1], spread, c.plate_t/2, [row_v[1]])]:
        vlo, vhi = max(vc-width/2, left), min(vc+width/2, right)
        if (vlo > vc-width/2+1e-9 and chord['left']['edge'] == 'root') or (vhi < vc+width/2-1e-9 and chord['right']['edge'] == 'root'):
            _issue(out, id+'_root_contact', 'outside_scope', 'Whitmore cruza raiz apoiada; sem continuação além da interface.')
        deduction = sum(max(0., min(vhi, v+dn/2)-max(vlo, v-dn/2)) for v in hole_vs)
        if vhi-vlo-deduction <= 0:
            _issue(out, id+'_nonpositive_net', 'invalid_geometry', 'Whitmore sem ligamento líquido positivo.')
        whitmores.append(dict(id=id, nominal_width=width, width=vhi-vlo, thickness=thickness,
            clipped=vhi-vlo < width-1e-9, v_limits=[vlo, vhi], actual_deduction=deduction,
            endpoints=[point(c, stations[0], vlo), point(c, stations[0], vhi)],
            load_fraction=1. if id == 'aggregate' else .5,
            classification='conventional_aggregate' if id == 'aggregate' else 'supplemental_allocated_half_thickness'))
    g['Whitmore'], g['Whitmore_rows'] = whitmores[0], whitmores[1:]
    g['valid'] = not any(i['severity'] in ('invalid_geometry', 'outside_scope') for i in out['issues'])
    return g


def root_checks(c, g, N, case, out, gusset, support):
    """Reuse only the one-root/W primitive with its physical force-count contract.

    That primitive assigns N/c.n to each supplied point. Opposed geometry has 2n
    points, so pass exactly 2n. It never evaluates any T bolt or plate result.
    """
    return _shared_root_checks(replace(c, n=2*c.n), g, N, case, out, gusset, support)


def _calculate_case(c, g, N, case, label, out, materials):
    angle, gusset, support = materials
    A = g['angle_section']; dn, dh = g['net_hole_diameter'], g['hole_diameter']
    Ct = max(1.-A['centroid']/g['Lc'], .5); An = A['Ag']-dn*A['t']
    if An <= 0:
        raise ValueError('Seção líquida da L não positiva.')
    F = N/(2*c.n)
    _row(out, 'angle_yield', '2L · escoamento bruto do par', 'angle', 'tension_yield', case,
        N, 2*A['Ag']*angle.fy/GAMMA_A1, reference='NBR5.2.2(a); Ag real por L, cada L N/2',
        count=2, Ag_one=A['Ag'], each_angle_demand=N/2, load_basis='total_N_against_pair_resistance')
    _row(out, 'angle_net', '2L · ruptura líquida efetiva do par', 'angle', 'tension_rupture', case,
        N, 2*Ct*An*angle.fu/GAMMA_A2, reference='NBR5.2.2/5.2.4/5.2.5; ec real de cada L, uma dedução por L',
        count=2, An_one=An, Ct=Ct, ec=A['centroid'], Lc=g['Lc'], net_hole_diameter=dn,
        each_angle_demand=N/2, load_basis='total_N_against_pair_resistance')
    planes, bearing = [], dict(angle=[], gusset=[])
    for ri, row in enumerate(g['bolt_rows']):
        excluded = getattr(c, 'threads_excluded_'+str(ri+1))
        coefficient = .56 if excluded and c.bolt != 'ASTM A307' else .45
        resistance = coefficient*math.pi*c.db**2/4*BOLTS[c.bolt]/GAMMA_A2*g['grip_factor']
        for j, (u, position) in enumerate(zip(g['bolt_stations'], row['bolt_centers'])):
            physical = ri*c.n+j+1
            record = dict(bolt=physical, row=ri, face=row['face'], local_bolt=j+1, plane=1,
                demand=F, resistance=resistance, utilization=F/resistance, coefficient=coefficient,
                threads_excluded=excluded, fub=BOLTS[c.bolt], grip=g['grip'],
                grip_factor=g['grip_factor'], position=position, load_basis='each_physical_bolt_N_over_2n')
            planes.append(record)
            _row(out, f'bolt_{physical}_plane_1', f'Parafuso{physical} · linha{ri+1} · corte simples',
                'bolt', 'bolt_shear', case, F, resistance,
                reference='NBR6.3.3.2/6.3.7; 2n parafusos distintos, um plano por parafuso; sem atrito',
                bolt_record=record, row=ri, face=row['face'], plane=1, load_basis=record['load_basis'])
            angle_lc = c.angle_end-dh/2 if j == 0 else c.pitch-dh
            plate_lc = c.pitch-dh if j < c.n-1 else row['forward_exit']['u']-u-dh/2
            for component, lc, thickness, material in [('angle', angle_lc, A['t'], angle),
                ('gusset', plate_lc, c.plate_t, gusset)]:
                if lc <= 0:
                    raise ValueError('Ligamento de contato não positivo em '+component)
                R = min(1.2*lc*thickness*material.fu, 2.4*c.db*thickness*material.fu)/GAMMA_A2
                detail = dict(hole=physical, row=ri, face=row['face'], local_hole=j+1, lc=lc,
                    tearout_R=1.2*lc*thickness*material.fu/GAMMA_A2,
                    bearing_cap_R=2.4*c.db*thickness*material.fu/GAMMA_A2, R=R,
                    demand=F, utilization=F/R, force_direction='-u' if component == 'angle' else '+u',
                    physical_hole_diameter=dh, copies=1, position=position,
                    load_basis='each_distinct_hole_N_over_2n')
                bearing[component].append(detail)
                _row(out, f'{component}_bearing_{physical}', f'{component} · linha{ri+1} · contato{j+1}',
                    component, 'bearing', case, F, R,
                    reference='NBR6.3.3.3(a); min(1.2lc t fu,2.4db t fu)/gamma_a2, saída real por linha',
                    row=ri, face=row['face'], bearing=detail, load_basis=detail['load_basis'])
    paths, inactive = rupture_paths(c, g, N, angle, gusset)
    for p in paths:
        p['case_id'] = case
        _row(out, p['id'], p['name'], p['component'], 'block_tearout', case,
            p['demand'], p['resistance'], reference=p['reference'], path=p,
            load_basis=p['load_basis'])
    partial = partial_bounds(c, g, N, gusset)
    for p in partial:
        p['case_id'] = case
        _row(out, p['id'], 'Envelope parcial correlacionado · linha'+str(p['row']+1),
            'gusset', 'supplemental_partial_block_bound', case, p['demand'], p['resistance'],
            reference='Suplemento conservador: cap/força/furos correlacionados, Ant=0; não regra NBR autônoma',
            witness=p, classification=p['classification'])
    chains = zigzag_chains(c, g, N, gusset.fu)
    for p in chains:
        _row(out, p['id'], 'Gusset · cadeia líquida de duas linhas', 'gusset', 'zigzag_net', case,
            N, p['R'], reference='NBR5.2.4.1(b-c), s²/(4g); força capturada e triagem conservadora Ntotal',
            chain=p, load_basis='conservative_full_N_with_actual_captured_demand_retained')
    whitmores = []
    for source in [g['Whitmore']]+g['Whitmore_rows']:
        whit = dict(source); D = N*whit['load_fraction']
        whit.update(gross_area=whit['width']*whit['thickness'],
            net_area=(whit['width']-whit['actual_deduction'])*whit['thickness'], demand=D)
        whit['R_yield'] = whit['gross_area']*gusset.fy/GAMMA_A1
        whit['R_net'] = whit['net_area']*gusset.fu/GAMMA_A2
        whit['yield_utilization'], whit['net_utilization'] = D/whit['R_yield'], D/whit['R_net']
        aggregate = whit['id'] == 'aggregate'
        prefix = 'Whitmore' if aggregate else 'Whitmore_'+whit['id']
        for mode, suffix in [('yield', 'bruto'), ('net', 'líquido suplementar')]:
            _row(out, prefix+'_'+mode, ('Gusset · Whitmore total · ' if aggregate else 'Gusset · meia espessura por linha · ')+suffix,
                'gusset', 'Whitmore_'+mode, case, D, whit['R_'+mode],
                reference=('DG29 espalhamento30°/NBR fatores; largura real recortada' if aggregate else
                    'Suplemento explícito de material alocado: cada linha tg/2 e N/2, sem duplicação de chapa'),
                witness=whit, classification=whit['classification'])
        whitmores.append(whit)
    whit, whit_rows = whitmores[0], whitmores[1:]
    normal = force_normal_sections(c, g, N, gusset.fy, gusset.fu)
    for key, strength in [('yield', gusset.fy/GAMMA_A1), ('rupture', gusset.fu/GAMMA_A2)]:
        witness = max(normal, key=lambda z:z[key+'_utilization'])
        _row(out, 'normal_net_'+key, 'Gusset · triagem líquida normal de duas linhas · '+key,
            'gusset', 'normal_net_'+key, case, max(map(abs, witness['sigma_edges'])), strength, 'MPa',
            'Suplemento nominal N/M: união de cordas, centroide líquido e todas as máscaras de força', witness=witness)
    horizontal = horizontal_sections(c, g, N, gusset.fy, gusset.fu)
    _row(out, 'nominal_perforated_yield', 'Gusset · triagem material perfurada N/V/M', 'gusset',
        'nominal_perforated_yield', case, horizontal['max_VM'], gusset.fy/GAMMA_A1, 'MPa',
        'Suplemento nominal: sigma=N/A+M(s-sbar)/I; tau1.5V/A; não solução exata de contato',
        extrema_method=horizontal['extrema_method'])
    _row(out, 'nominal_perforated_rupture', 'Gusset · envelope material nominal tração/cisalhamento',
        'gusset', 'nominal_perforated_rupture', case, horizontal['utilization_rupture'], 1., 'ratio',
        'Suplemento NBR6.5.3/6.5.5: valores absolutos normal/cisalhamento separados')
    minimum = min(horizontal['min_sigma'], min(z['min_sigma'] for z in normal))
    diagnostic = dict(min_sigma=minimum, horizontal_min_sigma=horizontal['min_sigma'],
        force_normal_min_sigma=min(z['min_sigma'] for z in normal),
        nonnegative=minimum >= -1e-8, affects_acceptance=False,
        classification='informative_introduction_zone_sign',
        note='Sinal negativo da hipótese nominal perfurada não demonstra compressão física/flambagem; envelope material permanece obrigatório.')
    solid = solid_ligament(c, g, N)
    if not solid['tensile']:
        _issue(out, case+'_compressed_solid_ligament', 'outside_scope',
            'Raiz/ligamento íntegro comprimido: fora do modelo de tração; não se confunde com diagnóstico perfurado.',
            minimum_normal_MPa=solid['min_sigma'], witness=min(solid['cuts'], key=lambda z:z['min_sigma']))
    root, member = root_checks(c, g, N, case, out, gusset, support)
    utilization = dict(angle_yield=N/(2*A['Ag']*angle.fy/GAMMA_A1), angle_net=N/(2*Ct*An*angle.fu/GAMMA_A2),
        bolt_shear=max(p['utilization'] for p in planes), angle_bearing=max(p['utilization'] for p in bearing['angle']),
        plate_bearing=max(p['utilization'] for p in bearing['gusset']),
        angle_block=max(p['utilization'] for p in paths if p['component'] == 'angle'),
        plate_block=max([p['utilization'] for p in paths if p['component'] == 'gusset']+[0.]),
        gusset_unequal_partial_bound=max(p['utilization'] for p in partial),
        gusset_zigzag_net=max(p['conservative_full_N_utilization'] for p in chains))
    for key in ('normal_net_yield', 'normal_net_rupture', 'nominal_perforated_yield',
        'nominal_perforated_rupture', 'root_weld', 'root_gusset_contact', 'root_W_contact',
        'W_flange_shear', 'W_web_normal', 'W_longitudinal_shear', 'W_web_VM', 'W_flange_bending'):
        selected = [r for r in out['checks'] if r['id'] == case+'__'+key]
        if selected:
            utilization[key] = selected[0]['utilization']
    utilization['Whitmore_yield'] = max(w['yield_utilization'] for w in whitmores)
    utilization['Whitmore_net'] = max(w['net_utilization'] for w in whitmores)
    # Explicit source-reference aliases; they do not create additional capacities/checks.
    aliases = dict(angle_gross='angle_yield', angle_contact='angle_bearing', gusset_contact='plate_bearing',
        gusset_block='plate_block', nominal_horizontal_yield='nominal_perforated_yield',
        nominal_horizontal_rupture='nominal_perforated_rupture', root_weld_u='root_weld',
        root_gusset_contact_u='root_gusset_contact', root_W_contact_u='root_W_contact',
        root_flange_punch_u='W_flange_shear', root_web_normal_u='W_web_normal',
        root_web_longitudinal_u='W_longitudinal_shear', root_web_VM_u='W_web_VM')
    for alias, key in aliases.items():
        utilization[alias] = utilization[key]
    utilization['force_normal_net'] = max(utilization['normal_net_yield'], utilization['normal_net_rupture'])
    centered = dict(plate_block=max([p['utilization'] for p in paths if p['component'] == 'gusset' and p['event'] == 'bolt_center']+[0.]))
    block_envelope = dict(method='Two distinct shear rows: outer L, inward L captures both, common U, each angle toe/far toe',
        extrema='Hole/corner intervals, both analytic branch stationary points and all one-sided force captures',
        partial='Correlated occupied-row cap/holes/force bound; Ant0; separate supplemental acceptance',
        reference_center_path_utilizations=centered, alternatives_never_summed=True)
    record = dict(id=case, label=label, N=N, root=root, member_actions=member, paths=paths,
        block_path_envelope=block_envelope, reference_center_path_utilizations=centered,
        inactive_path_families=inactive, angle_Ct=Ct, angle_Ae=Ct*An, angle_An=An,
        bolt_planes=planes, bearing=bearing, Whitmore=whit, Whitmore_rows=whit_rows,
        force_normal_cuts=normal, horizontal_sections=horizontal, plate_sections=horizontal,
        unequal_partial_U_bounds=partial, zigzag_net_chains=chains, solid_root_ligament=solid,
        introduction_sign_diagnostic=diagnostic, nominal_min_sigma=minimum,
        normal_tension_domain=solid['tensile'], load_introduction_sign_diagnostic_nonnegative=diagnostic['nonnegative'],
        utilizations=utilization,
        force_split=dict(total=N, each_angle=N/2, each_bolt=F, each_plane=F, each_gusset_hole=F,
            physical_bolt_count=2*c.n, shear_planes_per_bolt=1, common_gusset=N, root=N, W=N),
        angle=dict(Ct=Ct, An_one=An, yield_R_total=2*A['Ag']*angle.fy/GAMMA_A1,
            net_R_total=2*Ct*An*angle.fu/GAMMA_A2))
    out['cases'].append(record)
    if case == 'actual':
        for key in ('root', 'paths', 'member_actions', 'bearing', 'Whitmore', 'Whitmore_rows',
            'force_normal_cuts', 'utilizations', 'block_path_envelope', 'reference_center_path_utilizations',
            'unequal_partial_U_bounds', 'zigzag_net_chains', 'solid_root_ligament', 'introduction_sign_diagnostic'):
            out[key] = record[key]
        out['sections'] = horizontal
        out['geometry']['inactive_path_families'] = inactive


def _finalize(out):
    severities = {x['severity'] for x in out['issues']}
    complete = bool(out['checks']) and not severities.intersection({'invalid_input', 'numerical_failure', 'invalid_geometry', 'outside_scope'})
    failures = [x['id'] for x in out['checks'] if x['status'] == 'FAIL']
    detail_ok = not severities.intersection({'detail_fail', 'detail_pending'})
    passed = complete and not failures and detail_ok
    status = next((name for severity, name in [('invalid_input', 'INVALID_INPUT'), ('numerical_failure', 'NUMERICAL_FAILURE'),
        ('invalid_geometry', 'INVALID_GEOMETRY'), ('outside_scope', 'OUTSIDE_SCOPE'),
        ('detail_fail', 'DETAILING_FAIL'), ('detail_pending', 'DETAILING_PENDING')] if severity in severities),
        'COMPLETE_CHECKS_FAIL' if failures else 'COMPLETE_LOCAL_CHECKS_PASS_WITHIN_SCOPE' if complete else 'INCOMPLETE_CHECKS')
    governing = max(out['checks'], key=lambda r: r['utilization']) if out['checks'] else None
    out.update(status=status, global_pass=passed, local_pass=passed, global_member_verified=False,
        summary=dict(complete_checks=complete, utilization=governing['utilization'] if governing else None,
            governing_id=governing['id'] if governing else None, failed_check_ids=failures,
            check_count=len(out['checks']), case_count=len(out['cases']), detailing_pass=detail_ok,
            mechanics_pass=complete and not failures, global_member_verified=False))
    return _safe(out)


def evaluate(c):
    out = dict(status='INVALID_INPUT', global_pass=False, local_pass=False, issues=[], checks=[], cases=[], geometry={},
        root={}, sections={}, paths=[], materials={}, member_actions={}, summary={},
        inputs=_safe(asdict(c)) if isinstance(c, BoltedOpposedAngleGusset) else _safe(c), family=FAMILY,
        connection_type=CONNECTION_TYPE, component_version=COMPONENT_VERSION, units=dict(UNITS),
        scope=SCOPE, exclusions=list(EXCLUSIONS), sources=dict(SOURCES))
    errors = input_errors(c)
    if errors:
        for j, error in enumerate(errors):
            _issue(out, 'input_'+str(j), 'invalid_input', error)
        return _finalize(out)
    out['fixed_assumptions'] = c.fixed_assumptions
    conditions = [
        (c.arrangement not in ARRANGEMENTS, 'arrangement', 'Somente 2L-opposed: duas linhas próprias, corte simples, uma chapa comum.'),
        (c.support_member not in ('beam', 'column'), 'support_member', 'Apoio deve ser viga ou pilar W.'),
        (c.support_face != 'flange', 'support_face', 'Somente mesa exterior W, raiz longitudinal centrada na alma.'),
        (get_angle(c.angle_profile) is None, 'angle_catalog', 'Identidade exata de catálogo não reconhecida.'),
        (c.support_profile not in SUPPORT_CATALOG, 'support_catalog', 'W laminado com identidade exata não reconhecido.'),
        (c.bolt not in BOLTS, 'bolt_class', 'Classe de parafuso não reconhecida.'),
        (c.root_electrode not in ELECTRODES, 'root_electrode', 'Eletrodo de raiz não reconhecido.'),
        (c.exposure not in ('painted', 'weathering'), 'exposure', 'Exposição deve ser painted ou weathering.'),
        (c.bolt == 'ASTM A307' and c.pretensioned, 'pretension_grade', 'A307 não recebe dispensa de pega por protensão.'),
        (c.N < 0, 'compression', 'N negativo é compressão, não convertido em módulo.'),
        (any(x != 0 for x in (c.V, c.M, c.torsion)), 'external_actions', 'V/M/T externos preservados, fora desta rota axial; momento geométrico calculado.'),
        (not c.static or c.fatigue or c.seismic, 'nonstatic', 'Somente tração estática sem fadiga/sismo, NBR6.1.8.2.'),
        (not c.normal_combination, 'combination', 'Fatores limitados a combinações normais.'),
        (not c.minimum_force and 0 <= c.N < 45000., 'minimum_force', 'Mínimo45kN desativado sem exceção qualificada para N<45kN.')]
    for test, id, message in conditions:
        if test:
            _issue(out, id, 'outside_scope', message)
    A = get_angle(c.angle_profile); W = SUPPORT_CATALOG.get(c.support_profile)
    materials = []
    for role, name, thicknesses in [('angle', c.angle_steel, [A['t']] if A else []),
        ('gusset', c.gusset_steel, [c.plate_t]), ('support', c.support_steel, [W['tf'], W['tw']] if W else [])]:
        material = MATERIALS.get(name)
        if material is None:
            _issue(out, role+'_material', 'outside_scope', role+': aço fora do catálogo.'); continue
        allowed = all(material.plate_allowed and material.plate_min <= t <= material.plate_max if role == 'gusset'
            else material.rolled_allowed and material.profile_min <= t <= material.profile_max for t in thicknesses)
        if not allowed:
            _issue(out, role+'_material_product', 'outside_scope', role+': produto/espessura fora do aço selecionado.')
        materials.append(material)
        out['materials'][role] = dict(name=name, fy=material.fy, fu=material.fu, thicknesses=thicknesses, source=material.source)
    if c.bolt in BOLTS:
        out['materials']['bolt'] = dict(name=c.bolt, fub=BOLTS[c.bolt])
    if c.root_electrode in ELECTRODES:
        out['materials']['root_weld'] = dict(name=c.root_electrode, fw=ELECTRODES[c.root_electrode])
    try:
        # Invalid topology must not reach arithmetic that presumes the arrangement.
        if any(i['severity'] == 'outside_scope' for i in out['issues']):
            return _finalize(out)
        g = _geometry(c, out)
        if g is not None:
            out['geometry'] = g
        # End-loaded uniform distribution is qualified only through 950 mm.
        # NBR6.3.8 states the long-group boundary for bearing-type tension
        # splices; conservatively adopt it for this end lap. Keep every local
        # diagnostic calculation, but do not approve an unqualified long group.
        if g and g['Lc'] > 950.:
            _issue(out, 'long_bolt_group', 'outside_scope',
                'Lc>950 mm: distribuição uniforme do grupo longo não qualificada nesta rota. '
                'Limite de NBR6.3.8 para emendas tracionadas adotado conservadoramente na sobreposição de extremidade; '
                'resultados locais mantidos como diagnóstico, sem correção automática1,20 ou aprovação do modelo longo.',
                actual=g['Lc'], qualified_limit=950., reference='NBR8800:2024/Errata1:2025 §6.3.8')
        if g and g['valid'] and len(materials) == 3:
            loads = [('actual', 'Tração total real informada', c.N)]
            if c.minimum_force and c.N < 45000.:
                loads.append(('minimum_45kN', 'Mínimo45kN da ligação inteira, repartido depois', 45000.))
            if c.recommend_half_capacity:
                angle = materials[0]; Ct = max(1.-A['centroid']/g['Lc'], .5)
                half = .5*c.angle_count*min(A['Ag']*angle.fy/GAMMA_A1, Ct*(A['Ag']-g['net_hole_diameter']*A['t'])*angle.fu/GAMMA_A2)
                loads.append(('recommended_half', 'Recomendação50% da resistência do conjunto de L', half))
            for id, label, force in loads:
                _calculate_case(c, g, force, id, label, out, materials)
        def finite(value):
            if isinstance(value, dict):
                return all(finite(x) for x in value.values())
            if isinstance(value, (list, tuple)):
                return all(finite(x) for x in value)
            return finite_real(value) if isinstance(value, (int, float)) and not isinstance(value, bool) else True
        if not finite(out):
            raise ArithmeticError('Resultado intermediário não finito.')
    except (ArithmeticError, ValueError, TypeError, OverflowError) as error:
        _issue(out, 'numerical_failure', 'numerical_failure', 'Cálculo não concluído: '+str(error))
    return _finalize(out)
