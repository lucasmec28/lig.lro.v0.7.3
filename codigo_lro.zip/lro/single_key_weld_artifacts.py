"""Physical two-fillet drawing and editable Word record, from the same result."""
from io import BytesIO
import math

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Polygon
from docx.shared import Inches

from .single_key_weld import LIMITS, REF, result_is_current

LABELS = {'pass': 'ATENDE no escopo local', 'fail': 'NÃO ATENDE no escopo local', 'pending': 'PENDENTE'}
STATUS_LABELS = {'weld_metal': 'Metal dos dois filetes', 'weld_detail': 'Detalhamento numérico',
                 'geometry': 'Geometria e implantação', 'domain': 'Domínio geométrico', 'materials': 'Materiais e processo',
                 'execution': 'Execução e vínculo documental', 'qualification': 'Vínculo documental'}


def _n(value, scale=1.):
    return f'{value / scale:.6f}' if type(value) in (int, float) and math.isfinite(value) else '—'


def _data(c, result):
    d = getattr(result, 'local_single_key_weld', {}) or {}
    if d:
        try:
            current = result_is_current(c, d)
        except (ValueError, TypeError, OverflowError):
            current = False
        if not current:
            return {'status': 'pending', 'weld_component_status': 'pending',
                    'reasons': ['Resultado desatualizado: recalcular para as entradas atuais.'], 'physical_segments': []}
    return d


def _positive(value, fallback=1.):
    return value if type(value) in (int, float) and math.isfinite(value) and value > 0 else fallback


def image_bytes(c, result, fmt='png'):
    d = _data(c, result)
    u = c.single_key_weld
    eligible = c.shear_path == 'plate' and u.model == 'two_opposed_fillets' and u.weld_type == 'fillet' and u.layout == 'two_equal_continuous'
    with plt.rc_context({'font.family': 'DejaVu Sans', 'font.size': 9, 'svg.fonttype': 'none'}):
        fig = plt.figure(figsize=(11.8, 7.0), layout='constrained')
        grid = fig.add_gridspec(2, 2, height_ratios=[1.1, 1.])
        plan, section, notes = fig.add_subplot(grid[0, 0]), fig.add_subplot(grid[0, 1]), fig.add_subplot(grid[1, :])
        for ax in (plan, section):
            ax.set_aspect('equal')
            ax.axis('off')
        notes.axis('off')
        fig.suptitle('CHAVE DE CHAPA ÚNICA · DOIS FILETES OPOSTOS', fontsize=13, fontweight='bold')
        if not eligible or not d.get('physical_segments'):
            plan.text(.5, .5, 'Geometria resistente não disponível\npara o modelo ou resultado atual.', ha='center', va='center', transform=plan.transAxes)
            section.text(.5, .5, 'Sem crédito de contorno ou resistência\npara cruz, W ou outra topologia.', ha='center', va='center', transform=section.transAxes)
        else:
            b, t, H, tp = (_positive(c.lug_bh), _positive(c.lug_t), _positive(c.lug_bv), _positive(c.tp))
            z = _positive(d.get('leg_mm'))
            span = max(b, t + 2*z)
            # The gray rectangle is the solid key section, never a weld outline.
            key = Rectangle((-t/2, -b/2), t, b, fc='#d8e2eb', ec='#425a6c', lw=1)
            key.set_gid('single_key_solid_section')
            plan.add_patch(key)
            for i, segment in enumerate(d['physical_segments']):
                root, toe, center = segment['root_x_mm'], segment['toe_x_mm'], segment['centroid_x_mm']
                y0, y1 = segment['y_start_mm'], segment['y_end_mm']
                # Filled footprint only; no return/end-edge line is credited.
                plan.add_patch(Rectangle((min(root, toe), y0), abs(toe-root), y1-y0, fc='#f6d9bf', ec='none'))
                line, = plan.plot([root, root], [y0, y1], color='#c46126', lw=3,
                                  label='2 raízes físicas: x=±t/2' if i == 0 else None)
                line.set_gid('single_key_weld_root_' + str(segment['id']))
                line, = plan.plot([center, center], [y0, y1], color='#2265a1', lw=1.6, ls='--',
                                  label='Linhas analíticas: x=±ac/2' if i == 0 else None)
                line.set_gid('single_key_weld_centroid_' + str(segment['id']))
            plan.annotate('', xy=(span*.7, 0), xytext=(span*.45, 0), arrowprops={'arrowstyle': '->', 'color': '#364c60'})
            plan.text(span*.71, 0, '+x', va='center')
            plan.annotate('', xy=(0, b*.67), xytext=(0, b*.54), arrowprops={'arrowstyle': '->', 'color': '#364c60'})
            plan.text(0, b*.69, '+y', ha='center')
            plan.set_xlim(-span*.85, span*.85)
            plan.set_ylim(-b*.64, b*.79)
            plan.set_title(f'VISTA INFERIOR · b={b:g} mm; t={t:g} mm', fontsize=10)
            plan.legend(loc='lower center', bbox_to_anchor=(.5, -.15), frameon=False, fontsize=8)
            # Local x-z section. The orange triangles are the actual two fillets.
            extent = max(t/2+z, .26*H, tp)
            section.add_patch(Rectangle((-extent*1.7, -tp), extent*3.4, tp, fc='#c2d2df', ec='#425a6c'))
            section.add_patch(Rectangle((-t/2, 0), t, H, fc='#d8e2eb', ec='#425a6c'))
            for sign in (-1, 1):
                triangle = Polygon([(sign*t/2, 0), (sign*(t/2+z), 0), (sign*t/2, z)],
                                   fc='#f6d9bf', ec='#c46126', lw=1.1)
                triangle.set_gid('single_key_weld_section_' + ('plus' if sign > 0 else 'minus'))
                section.add_patch(triangle)
            if 0 <= c.grout_t < H:
                section.axhline(c.grout_t, color='#898989', lw=.8, ls=':')
                section.text(extent*1.75, c.grout_t, f'g={c.grout_t:g} mm', va='center', fontsize=8)
            # Arrows show tractions exerted by the key on the receiving plate.
            arrow_length = max(tp*.45, H*.12)
            for segment in d['physical_segments']:
                center = segment['centroid_x_mm']
                sign = 1 if segment['qz_Npmm'] >= 0 else -1
                ybase = -tp-arrow_length*1.3
                section.annotate('', xy=(center, ybase+sign*arrow_length/2),
                                 xytext=(center, ybase-sign*arrow_length/2),
                                 arrowprops={'arrowstyle': '->', 'color': '#2265a1', 'lw': 1.4})
                section.text(center, ybase-arrow_length*.8, 'qz+' if center > 0 else 'qz−', ha='center', fontsize=8)
            sign = 1 if d.get('Vw_N', 0) >= 0 else -1
            section.annotate('', xy=(sign*extent*.55, -tp*.45), xytext=(-sign*extent*.55, -tp*.45),
                             arrowprops={'arrowstyle': '->', 'color': '#233544', 'lw': 1.5})
            section.text(0, -tp*.55, 'Vw', ha='center', va='bottom', fontsize=8)
            section.annotate('', xy=(-extent*1.35, H*.7), xytext=(-extent*1.35, H*.4), arrowprops={'arrowstyle': '->'})
            section.text(-extent*1.42, H*.6, '+z', ha='right')
            drawn_depth = max(H, z)  # Invalid oversized legs still need uncluttered diagnostics.
            section.text(0, drawn_depth*1.10, f'H={H:g} mm; tp={tp:g} mm; z={z:g} mm', ha='center', fontsize=8)
            section.set_xlim(-extent*2.2, extent*2.9)
            section.set_ylim(drawn_depth*1.2, -tp-arrow_length*2.5)
            section.set_title('CORTE x–z · AÇÕES DA CHAVE SOBRE A PLACA', fontsize=10)
        values = [
            'Componente: ' + LABELS.get(d.get('weld_component_status', d.get('status')), 'PENDENTE') + '; ligação e base completas pendentes.',
            'Metal de solda: ' + LABELS.get(d.get('statuses', {}).get('weld_metal'), 'PENDENTE') + '; execução: ' + ('registro vinculado aos dados atuais.' if d.get('statuses', {}).get('execution') == 'pass' else 'registro pendente ou desatualizado.'),
            f'V aplicado={_n(d.get("Vactual_N", c.V), 1000)} kN; Vw prescrito={_n(d.get("Vw_N"), 1000)} kN; Mw prescrito={_n(d.get("Mw_Nmm"), 1e6)} kN·m.',
            f'Lreal={_n(d.get("Lreal_mm"))} mm; Leff={_n(d.get("Leff_mm"))} mm por filete; garganta a={_n(d.get("throat_mm"))} mm; ac={_n(d.get("arm_mm"))} mm.',
            f'qx={_n(d.get("qx_Npmm"))} N/mm; qz,+={_n(d.get("qz_plus_Npmm"))} N/mm; qz,−={_n(d.get("qz_minus_Npmm"))} N/mm.',
            f'q={_n(d.get("q_resultant_Npmm"))} N/mm; qRd={_n(d.get("q_Rd_Npmm"))} N/mm; índice={_n(d.get("utilization"))}; fw=485 MPa; γw2=1,35.',
            'Binário local: ac=t+2z/3; qz,±=±Mw/(ac Leff). Raízes físicas em ±t/2, sem soldas de retorno.',
            'Sinais nas ações da chave sobre a placa; reação na chave oposta. Mw usa a convenção escalar do app.',
            'Em V=0 conserva-se o envelope positivo. Vw/Mw não substituem V aplicado no equilíbrio global.',
            'Metal-base/transferência local à placa, flexão da placa e concreto da chave permanecem separados.',
        ]
        if d.get('resistance_basis_valid') is False:
            values[-1] = 'qRd e índice nominais, sem crédito resistente: material ou domínio pendente. Transferência local pendente.'
        if d.get('leg_mm', 0) > c.lug_bv:
            values.append('NÃO ATENDE: perna vertical z>H, sem apoio integral na face física da chave.')
        if any('abaixo do graute' in reason for reason in d.get('reasons', [])):
            values.append('Domínio pendente: z>g ocupa a face de contato com concreto; exige outro detalhe. Não é máximo universal NBR.')
        if not d.get('physical_segments'):
            values.append(' · '.join(d.get('reasons', []))[:175])
        step = min(.095, .98 / (len(values) + .3))
        for i, line in enumerate(values):
            notes.text(.01, .98-i*step, line, va='top', fontsize=9, transform=notes.transAxes)
        out = BytesIO()
        fig.savefig(out, format=fmt, dpi=150)
        plt.close(fig)
        return out.getvalue()


def append_report(doc, c, result):
    if c.shear_path != 'plate' or c.single_key_weld.model == 'off':
        return
    from .report import table, _math, group, sub, frac, radical, power
    d, u = _data(c, result), c.single_key_weld
    title = doc.add_paragraph('Solda da chave de chapa única · dois filetes opostos', style='Heading 1')
    title.paragraph_format.page_break_before = True
    doc.add_picture(BytesIO(image_bytes(c, result)), width=Inches(6.95))
    doc.add_paragraph('Componente de metal de solda e detalhamento: ' + LABELS.get(d.get('weld_component_status', d.get('status')), 'PENDENTE') + '. Ligação completa e dispositivo completo: PENDENTES.')
    if d.get('resistance_basis_valid') is False:
        doc.add_paragraph('qRd e índice abaixo são valores nominais condicionais, sem crédito resistente: material ou domínio fora da base qualificada. Falhas numéricas identificadas permanecem visíveis.')
    for name, status in d.get('statuses', {}).items():
        doc.add_paragraph(STATUS_LABELS.get(name, name.replace('_', ' ')) + ': ' + LABELS.get(status, 'PENDENTE') + '.')
    for reason in d.get('reasons', []):
        doc.add_paragraph(str(reason))
    doc.add_paragraph(f'Aço real da chave: {c.lug_steel}; aço real da placa: {c.plate_steel}. Processo: {u.process}; passe único: ' +
                      ('confirmado' if u.single_pass_confirmed else 'não confirmado') + '. Registro de execução: ' + (u.execution_ref or 'NÃO INFORMADO') + '.')
    doc.add_paragraph('Geometria física: chave maciça centrada; largura b=bh em y, espessura t=tpv em x e projeção H=bv em z, para baixo. Exatamente duas raízes x=±t/2, sem retornos nas extremidades. Linhas analíticas do binário x=±ac/2 não mudam a espessura real nem a excentricidade global. Domínio atual: Lreal=Leff=b, a tamanho pleno até as extremidades.')
    rows = [
        ('Perna física z / garganta a', _n(d.get('leg_mm'))+' / '+_n(d.get('throat_mm')), 'mm'),
        ('Comprimento real / efetivo por filete', _n(d.get('Lreal_mm'))+' / '+_n(d.get('Leff_mm')), 'mm'),
        ('Braço analítico ac=t+2z/3', _n(d.get('arm_mm')), 'mm'),
        ('Cortante real aplicado V', _n(d.get('Vactual_N', c.V), 1000), 'kN'),
        ('Cortante prescrito Vw com sinal', _n(d.get('Vw_N'), 1000), 'kN'),
        ('Momento prescrito Mw com sinal', _n(d.get('Mw_Nmm'), 1e6), 'kN·m'),
        ('qx em cada filete', _n(d.get('qx_Npmm')), 'N/mm'),
        ('qz,+ / qz,−', _n(d.get('qz_plus_Npmm'))+' / '+_n(d.get('qz_minus_Npmm')), 'N/mm'),
        ('Resultante q / resistência qRd', _n(d.get('q_resultant_Npmm'))+' / '+_n(d.get('q_Rd_Npmm')), 'N/mm'),
        ('Índice q/qRd', _n(d.get('utilization')), '—'),
    ]
    table(doc, ['Grandeza', 'Valor', 'Unidade'], rows, [3.8, 2.35, .8])
    doc.add_paragraph('Ações prescritas e campo vetorial', style='Heading 2')
    doc.add_paragraph('s=−1 para V<0 e s=+1 para V≥0. Com V=0 conserva-se o envelope positivo. Ações de referência da chave sobre a placa; na chave isolada a reação inverte. Mw adota a convenção escalar do app, positiva para V positivo.')
    _math(doc, group('σ = 1,7 ', sub('f','ck'), ' / 1,40;   ', sub('V','w'), ' = s σ b(H − g);   ', sub('M','w'), ' = ', sub('V','w'), '(H + g)/2'))
    _math(doc, group(sub('a','c'), ' = t + 2z/3;   a = z/√2;   ', sub('q','x'), ' = ', frac(sub('V','w'), group('2',sub('L','eff')))))
    _math(doc, group(sub('q','z,+'), ' = ', frac(sub('M','w'), group(sub('a','c'),sub('L','eff'))), ';   ', sub('q','z,−'), ' = −', sub('q','z,+')))
    _math(doc, group('q = ', radical(group(power(sub('q','x')), ' + ', power(sub('q','z')))), ';   ', sub('q','Rd'), ' = 0,6 × 485 × a / 1,35'))
    doc.add_paragraph('fw=485 MPa, γw2=1,35. O vetor inclui a componente normal comprimida; o resultante tem mesma magnitude em ambos os filetes. Sem aumento direcional AISC de 1,5 e sem somar duas capacidades de momento. Ações integrais de contato NBR, sem reduzir por V aplicado, aço da chave, atrito ou chumbadores.')
    _math(doc, group('Σ', sub('q','x'), sub('L','eff'), ' = ', sub('V','w'), ';   Σ', sub('q','z'), sub('L','eff'), ' = 0;   Σx', sub('q','z'), sub('L','eff'), ' = ', sub('M','w')))
    if 'residual_V_N' in d:
        doc.add_paragraph(f'Resíduos numéricos: ΣqxLeff−Vw={d["residual_V_N"]:.3e} N; ΣqzLeff={d["residual_normal_N"]:.3e} N; ΣxqzLeff−Mw={d["residual_M_Nmm"]:.3e} N·mm.')
    doc.add_paragraph('Vw e Mw são ações locais de dimensionamento; não são realimentados no equilíbrio global. Permanece Mlocal=Mtopo+Vaplicado[tp+(H+g)/2], uma única vez. A solda superior pilar–placa conserva suas próprias ações da face superior.')
    doc.add_paragraph('Detalhamento: mínimo de perna pela menor espessura real da chave/placa (Tabela 11) e execução em passe único explicitamente registrada; Leff≥máx(40 mm;4z) por filete. Lreal≤100z é limite finito desta implementação, não proibição universal NBR de solda transversal longa. Não aplicar automaticamente t−1,5 à raiz de junta T; verificar apoio dos pés, prateleira, bordas e acesso reais.')
    doc.add_paragraph(LIMITS)
    doc.add_paragraph('Referências e combinação de métodos: ' + REF + '. O DG1 fornece a idealização do binário nos centroides; ações prescritas e resistência escalar são da NBR. AISC e NBR podem produzir vereditos diferentes para a mesma geometria. As exigências da NBR 6118 para o bloco armado e a transferência à fundação permanecem separadas.')
