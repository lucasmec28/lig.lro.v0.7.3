"""Proportional Type 2 drawing: four interior anchors, applied N/V only."""
from .display_precision import display_format
from io import BytesIO
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Circle, Polygon, FancyArrowPatch
from .models import KGF
from .base_plate_drawing import INK, PLATE, COLUMN, CONTACT, TENSION


def image_bytes(c, r=None, fmt='png'):
    from .pinned_base_plate import evaluate
    from .base_plate import detail_reference
    r=evaluate(c)  # Current inputs always own the published drawing.
    if c.model_type!=2:raise ValueError('Desenho reservado à base rotulada Tipo 2.')
    p=c.column;L=c.L;B=c.B;a=r.geometry;ref=detail_reference(c)
    side=c.anchor_washer_side if c.native_anchor_shear else ref['washer_side']
    ta=c.anchor_washer_t if c.native_anchor_shear else ref['washer_t']
    m=max(40.,.11*L,.13*B);h=max(110.,.38*L);ground=-c.grout_t
    with plt.rc_context({'font.family':'DejaVu Sans','font.size':9,'svg.fonttype':'none'}):
        fig=plt.figure(figsize=(12.8,8.8),layout='constrained')
        grid=fig.add_gridspec(2,2,height_ratios=[4.0,1.3])
        plan=fig.add_subplot(grid[0,0]);sec=fig.add_subplot(grid[0,1]);note=fig.add_subplot(grid[1,:])
        for ax in (plan,sec):ax.set_aspect('equal');ax.axis('off')
        note.axis('off')
        def rect(ax,x,y,w,h,color,gid,**kwargs):
            obj=Rectangle((x,y),w,h,facecolor=color,edgecolor=INK,lw=.8,**kwargs)
            obj.set_gid(gid);ax.add_patch(obj);return obj
        def dim(ax,x0,y0,x1,y1,label):
            ax.annotate('',(x1,y1),(x0,y0),arrowprops={'arrowstyle':'<->','lw':.7,'color':INK})
            ax.text((x0+x1)/2,(y0+y1)/2,label,ha='center',va='center',rotation=90 if x0==x1 else 0,
                    fontsize=8,color=INK,bbox={'facecolor':'white','edgecolor':'none','pad':1.3})
        def arrow(ax,start,end,gid,color=INK):
            obj=FancyArrowPatch(start,end,arrowstyle='-|>',mutation_scale=11,lw=1.3,color=color)
            obj.set_gid(gid);ax.add_patch(obj)
        plan.set_title('ROTULADA · TIPO 2 · PLANTA / ALMA VERTICAL',loc='left',fontsize=10.5,fontweight='bold',color=INK)
        rect(plan,-B/2-c.grout_t,-L/2-c.grout_t,B+2*c.grout_t,L+2*c.grout_t,'#f3e7d3','pinned_grout_footprint',alpha=.55,ls='--')
        rect(plan,-B/2,-L/2,B,L,PLATE,'pinned_plate',alpha=.55)
        rect(plan,-p.bf/2,-p.d/2,p.bf,p.tf,COLUMN,'pinned_lower_flange')
        rect(plan,-p.bf/2,p.d/2-p.tf,p.bf,p.tf,COLUMN,'pinned_upper_flange')
        rect(plan,-p.tw/2,-p.d/2+p.tf,p.tw,p.d-2*p.tf,COLUMN,'pinned_column_web')
        for i,(x,y) in enumerate(((x,y) for x in (-c.a,c.a) for y in (-c.a2/2,c.a2/2)),1):
            rect(plan,y-side/2,x-side/2,side,side,'#f1d6a9','pinned_washer_A'+str(i),alpha=.9)
            if c.direct_anchor_shear and c.direct_shear.hole_diameter>0:
                hole=Circle((y,x),c.direct_shear.hole_diameter/2,fill=False,edgecolor=INK,lw=.7,ls=':')
                hole.set_gid('direct_plate_hole_A'+str(i));plan.add_patch(hole)
            circle=Circle((y,x),c.db/2,facecolor='white',edgecolor=INK,lw=.9)
            circle.set_gid('pinned_anchor_A'+str(i));plan.add_patch(circle)
            # Keep ID glyphs clear of the actual washer, plate and grout edges.
            sign=1 if y>0 else -1
            outer=max(B/2+c.grout_t,abs(y)+side/2)
            plan.annotate('A'+str(i),xy=(sign*outer,x),xytext=(sign*5,0),
                          textcoords='offset points',ha='left' if y>0 else 'right',
                          va='center',fontsize=8,color=INK)
        plan.plot([0,0],[-L/2-m*.2,L/2+m*.2],color=INK,lw=.5,ls='-.')
        dim(plan,-B/2,-L/2-m*.85,B/2,-L/2-m*.85,f"B={display_format(B, 'g')}")
        dim(plan,-B/2-m*.8,-L/2,-B/2-m*.8,L/2,f"L={display_format(L, 'g')}")
        dim(plan,B/2+m*.6,-c.a,B/2+m*.6,c.a,f"a₂={display_format(c.a2, 'g')}")
        dim(plan,-c.a2/2,L/2+m*.65,c.a2/2,L/2+m*.65,f"a₂={display_format(c.a2, 'g')}")
        plan.set_xlim(-B/2-m*1.5,B/2+m*1.55);plan.set_ylim(-L/2-m*1.4,L/2+m*1.25)
        sec.set_title('CORTE x · AÇÕES NO TOPO / REAÇÕES',loc='left',fontsize=10.5,fontweight='bold',color=INK)
        concrete=max(90.,L*.24)
        rect(sec,-L/2-m,ground-concrete,L+2*m,concrete,'#e7e5e0','pinned_concrete',hatch='..')
        grout=Polygon([(-L/2,0),(L/2,0),(L/2+c.grout_t,ground),(-L/2-c.grout_t,ground)],facecolor='#f3e7d3',edgecolor=INK,lw=.8)
        grout.set_gid('pinned_grout_section');sec.add_patch(grout)
        rect(sec,-L/2,0,L,c.tp,PLATE,'pinned_plate_section')
        rect(sec,-p.d/2,c.tp,p.d,h,'#edf0f3','pinned_column_section')
        for sign in (-1,1):
            x=sign*(p.d/2-p.tf/2);rect(sec,x-p.tf/2,c.tp,p.tf,h,COLUMN,'pinned_flange_'+str(sign))
        for x in (-c.a,c.a):
            sec.plot([x,x],[ground-concrete*.8,c.tp+ta+c.db],color=INK,lw=2)
            rect(sec,x-side/2,c.tp,side,ta,'#f1d6a9','pinned_washer_section_'+str(x))
            rect(sec,x-c.db*.65,c.tp+ta,c.db*1.3,c.db*.7,COLUMN,'pinned_nut_'+str(x))
        if c.shear_path=='plate':
            rect(sec,-c.lug_t/2,-c.lug_bv,c.lug_t,c.lug_bv,PLATE,'pinned_lug')
            y=-(c.lug_bv+c.grout_t)/2
            if c.V:
                sign=1 if c.V>0 else -1
                arrow(sec,(sign*m*.8,y),(0,y),'pinned_lug_reaction')
            dim(sec,L/2+m*.5,-c.lug_bv,L/2+m*.5,0,f"bv={display_format(c.lug_bv, 'g')}")
        yload=c.tp+h+m*.35
        if c.N:
            start,end=((0,yload+m),(0,yload)) if c.N>0 else ((0,yload),(0,yload+m))
            arrow(sec,start,end,'pinned_applied_N');sec.text(8,yload+m*.45,'N',color=INK)
        if c.V:
            sign=1 if c.V>0 else -1
            arrow(sec,(-sign*p.d*.3,c.tp+h*.72),(sign*p.d*.3,c.tp+h*.72),'pinned_applied_V')
            sec.text(0,c.tp+h*.72+10,'V',ha='center',color=INK)
        sec.text(-L/2-m,ground-concrete-12,'Ancoragem esquemática; duas barras projetadas em cada linha.',fontsize=7.7,color=INK,va='top')
        y0=ground-concrete-m*1.9;qh=m*.55
        sec.plot([-L/2,L/2],[y0,y0],color=INK,lw=.8)
        if a:
            sign=a['moment_sign']
            if a['C']:
                x0=L/2-a['lc'] if sign>0 else -L/2
                rect(sec,x0,y0-qh,a['lc'],qh,CONTACT,'pinned_contact')
                sec.text(a['C_x'],y0-qh-10,f"C={display_format(a['C'] / KGF, '.1f')} kgf",ha='center',va='top',fontsize=8,color=INK)
            for x,F in ((-sign*c.a,a['Ft_max']),(sign*c.a,a['Ft_min'])):
                if F>0:
                    arrow(sec,(x,y0+qh),(x,y0-qh),'pinned_tension_'+str(x),TENSION)
                    sec.text(x,y0+qh+8,f"2×{display_format(F / KGF, '.1f')} kgf",ha='center',fontsize=8,color=TENSION)
        sec.set_xlim(-L/2-m*1.25,L/2+m*1.2);sec.set_ylim(y0-qh-m,c.tp+h+m*1.6)
        values=[
            'Geometria própria: quatro chumbadores internos em (±a₂/2; ±a₂/2). Não é o arranjo externo Tipo 1.',
            f"L=d+4a₁={display_format(L, 'g')} mm; B=a₂+2a₁={display_format(B, 'g')} mm; a=a₂/2={display_format(c.a, 'g')} mm. Aplicados: N={display_format(c.N / KGF, '.2f')} kgf; V={display_format(c.V / KGF, '.2f')} kgf; M=0.",
            ('Caso '+a['case']+f"; Mlocal={display_format(a['M_effective'] / (KGF * 1000), '.3f')} kgf·m; t requerido={display_format(a['t_required'], '.3f')} mm." if a else 'Sem solução admissível: consultar os bloqueios do modelo.'),
            'Tração da placa Tipo 2: l₀=min[d; a₂+1,75(a₂−tw)]. C3/T3 e momento puro não são admitidos.',
            'Cotas em mm; desenho proporcional. Acesso, fabricação, ancoragem completa, soldas e rigidez exigem verificações próprias.',
        ]
        if c.direct_anchor_shear:
            values.append('CONTATO DIRETO · d0='+display_format(c.direct_shear.hole_diameter,'g')+' mm; arruela axial sem crédito lateral. Estados alternativos, nunca somados.')
        for i,line in enumerate(values):note.text(0,.98-i*(.15 if c.direct_anchor_shear else .185),line,transform=note.transAxes,fontsize=8.5 if c.direct_anchor_shear else 9,color=INK,va='top')
        out=BytesIO();fig.savefig(out,format=fmt,dpi=155,facecolor='white');plt.close(fig);return out.getvalue()
