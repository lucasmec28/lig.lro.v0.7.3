"""End plates na mesa de coluna. N, mm, MPa; ações já de cálculo.

Resistências NBR 8800:2024/2025. Linhas de plastificação e critério
construtivo FR complementares do DG39 (2023), caso 4E não enrijecido.
Extrapolações são sinalizadas sem aprovação do domínio ou da rigidez.
"""
from dataclasses import dataclass, asdict, fields, replace, field
from decimal import Decimal
import math
import hashlib
import json
from .models import Profile, Check, Issue, Result, STEELS, BOLTS, DIAMETERS, VERSION, profiles, INTERFERENCE_ASSUMPTION
from .end_plate_detail import DETAIL_FIELDS, DETAIL_SCOPE, next_stock_thickness
from .engine import bolt_shear
from .local_checks import grip_factor, web_shear
from .column_checks import crippling_point

G1=1.10;G2=1.35;E=200000.
NBR='ABNT NBR 8800:2024, versão corrigida 2025'
DG='AISC Design Guide 39 (2023)'
SCI='SCI P358 (2014), 4.7, Check 1'
PINNED_REVISION='endplate-pinned-nbr-scoped-0911-v1'
MOMENT_REVISION='endplate-4e-column-flange-demand-20261012-v1'
FOURES_REVISION='endplate-4es-independent-steels-0925-v1'
MRE12_REVISION='endplate-mre12-nbr-demand-thick-0941-v1'
EIGHTES_REVISION='endplate-8es-independent-steels-0925-v1'
CJP_STEELS=('ASTM A36','ASTM A572 Gr.42','ASTM A572 Gr.50')
STIFFENER_FIELDS={'stiffener_steel','stiffener_t','stiffener_length','stiffener_clip','stiffener_landing','stiffener_weld','stiffener_electrode','stiffener_compatible','stiffener_clearance'}
PINNED_GAPS=(
    'Qualificação local não demonstrada: hierarquia das soldas alma–chapa ou dimensionamento com momento coexistente de rotação, nos materiais efetivos.',
    'Qualificação local não demonstrada: tração dos parafusos induzida pela rotação, ou reserva justificada, combinada com N/V. Não se aplica automaticamente o fator SCI 0,8 às resistências NBR.',
    'Qualificação local não demonstrada: transferência pelas soldas das mesas e efeitos locais das mesas, com distribuição compatível entre alma e mesas.',
    'Qualificação local não demonstrada: extensão simultânea N/V de tração e compressão para a topologia de altura total, incluindo distribuição, cortes físicos e interações da chapa, alavanca nula e contato.',
)

def method_revision(c):
    return PINNED_REVISION if c.kind=='pinned' else MRE12_REVISION if c.is_mre12 else EIGHTES_REVISION if c.variant=='8ES' else FOURES_REVISION if c.variant=='4ES' else MOMENT_REVISION


def minimum_bolt_spacing(db):
    """Catalog dimensions and 2.7 are exact engineering decimals; no geometric tolerance."""
    return float(Decimal(str(db))*Decimal('2.7'))


def fillet_minimum(thinner):
    """NBR 6.2.6.2.1/Table 11: actual smaller thickness of each joint."""
    return 3. if thinner<=6.3 else 5. if thinner<=12.5 else 6. if thinner<=19. else 8.


def fillet_edge_maximum(edge,reinforced):
    """NBR 6.2.6.2.2: exact 6.3 mm edge boundary, not stock rounding."""
    return edge if reinforced or edge<6.3 else edge-1.5


class PinnedEndPlateCheck(Check):
    """Scoped presentation; the shared/moment Check is unchanged."""
    @property
    def numerically_valid(self):
        return (math.isfinite(self.demand) and math.isfinite(self.resistance)
                and self.resistance>0 and math.isfinite(self.ratio))
    @property
    def applicable(self):
        return not (self.numerically_valid and self.demand==0 and self.id not in ('ep_rotation','ep_ductility'))
    @property
    def outcome(self):
        if not self.numerically_valid:return 'Falha numérica · sem conclusão'
        if not self.applicable:return 'N/A · sem solicitação deste mecanismo'
        if self.category=='Condição do método':return 'Condição satisfeita' if self.passed else 'Condição não satisfeita'
        return 'Atende' if self.passed else 'Não atende'



class PinnedNoPryingUnqualifiedCheck(PinnedEndPlateCheck):
    @property
    def outcome(self):
        if not self.numerically_valid or not self.passed:return super().outcome
        return 'Não qualificado · condição de alavanca não satisfeita'


def pinned_summary(rows):
    """Only proved duplicates are consolidated; every numeric branch remains."""
    out=[]
    for row in rows:
        if row.id in ('ep_bolt_shear','ep_bolt_tension','ep_beam_web'):continue
        if row.id=='ep_beam_nv':
            branches=[x for x in rows if x.id in ('ep_beam_nv','ep_beam_web')]
            winner=max(branches,key=lambda x:x.ratio)
            row=replace(row,name='Alma da viga — envoltória N/V e cisalhamento',demand=winner.ratio,resistance=1.,unit='—',
                equation='η=max(σeq/(fy/γa1); |V|/VRd); VRd=0,6 fy h tw Cv/γa1',
                substitution='; '.join(x.id+': Sd='+format(x.demand,'.9g')+'; Rd='+format(x.resistance,'.9g')+'; η='+format(x.ratio,'.9g') for x in branches),
                variables='Governante: '+winner.name+'. Ambos os ramos permanecem calculados: interação elástica N/V e cisalhamento com Cv, inclusive alma esbelta. Viga sem furos locais; sem dedução fictícia de furos.')
        if row.id=='ep_bolt_interaction':
            branches=[x for x in rows if x.id in ('ep_bolt_tension','ep_bolt_shear')]
            row=replace(row,variables=row.variables+' Os escalares não negativos são limitados pela elipse; sem aprovações duplicadas. '+
                ' '.join(x.name+': '+x.substitution+'. '+x.equation+'.' for x in branches))
        out.append(row)
    return out


class PinnedEndPlateResult(Result):
    @property
    def summary_checks(self):return pinned_summary(self.checks)
    @property
    def actual_summary(self):return pinned_summary(self.actual)
    @property
    def resistance_failures(self):return [x for x in self.checks if x.numerically_valid and x.applicable and x.category=='Resistência' and not x.passed]
    @property
    def method_failures(self):return [x for x in self.checks if x.numerically_valid and x.applicable and x.category=='Condição do método' and (not x.passed or not getattr(x,'source_qualified',True))]
    @property
    def numeric_failures(self):return [x for x in self.checks if not x.numerically_valid]
    @property
    def local_scope_issues(self):return [x for x in self.issues if x.origin=='local_scope']
    @property
    def coverage_note(self):
        notes=[]
        if self.resistance_failures:notes.append('Resistência local não atendida: '+', '.join(x.name for x in self.resistance_failures)+'.')
        if self.numeric_failures:notes.append('Falha numérica em '+', '.join(x.name for x in self.numeric_failures)+': sem conclusão para esses mecanismos; falhas resistentes finitas permanecem válidas.')
        if self.method_failures:notes.append('Condições do método não satisfeitas: '+', '.join(x.name for x in self.method_failures)+'. Não são sobrecargas resistentes demonstradas.')
        if any(x.severity=='noncompliance' for x in self.issues):notes.append('Há requisito de detalhamento não atendido; as dimensões informadas foram preservadas.')
        notes.extend(x.text for x in self.issues if x.origin in ('numeric','local_scope'))
        return ' '.join(notes)
    @property
    def status(self):
        if self.resistance_failures:return 'NÃO ATENDE'
        if self.numeric_failures or any(x.origin=='numeric' for x in self.issues):return 'FALHA NUMÉRICA · REVISAR ENTRADA'
        if any(x.severity=='error' and x.origin=='data' for x in self.issues):return 'DADOS NECESSÁRIOS AUSENTES'
        if any(x.severity=='error' for x in self.issues):return 'GEOMETRIA INVÁLIDA'
        if any(x.severity=='noncompliance' for x in self.issues):return 'NÃO ATENDE AO DETALHAMENTO'
        if self.method_failures:return 'CONDIÇÕES DO MÉTODO NÃO SATISFEITAS'
        if any(x.severity=='extrapolation' for x in self.issues):return 'CÁLCULO COM RESSALVAS · EXTRAPOLAÇÃO DO MODELO'
        if any(x.severity=='pending' for x in self.issues):return 'REVISAR CONDIÇÕES DE APLICAÇÃO'
        if not self.checks:return 'SEM VERIFICAÇÕES DE RESISTÊNCIA'
        if self.local_scope_issues:return 'VERIFICAÇÕES LOCAIS ATENDEM · ESCOPO INCOMPLETO'
        if any(x.severity=='interference' for x in self.issues):return 'CÁLCULO ATENDE · CONFERIR INTERFERÊNCIAS'
        return 'ATENDE ÀS VERIFICAÇÕES REALIZADAS'
    @property
    def governing(self):
        rows=[x for x in self.summary_checks if x.numerically_valid and x.applicable and x.category=='Resistência']
        return max(rows,key=lambda x:x.ratio) if rows else None

@dataclass
class MomentEndPlateCheck(Check):
    """Moment-specific outcome; numeric rows retain their case and source intact."""
    no_prying_qualified: bool = True

    @property
    def numerically_valid(self):
        return math.isfinite(self.demand) and math.isfinite(self.resistance) and self.resistance>0 and math.isfinite(self.ratio)
    @property
    def applicable(self):
        # The minimum DG39 weld-development demand is already present in demand.
        return not (self.numerically_valid and self.demand==0)
    @property
    def outcome(self):
        if not self.numerically_valid:return 'Falha numérica · sem conclusão'
        if not self.applicable:return 'N/A · sem solicitação deste mecanismo'
        if self.category=='Condição do método':return 'Condição satisfeita' if self.passed else 'Condição não satisfeita'
        if not self.passed:return 'Não atende'
        if not self.no_prying_qualified:return 'Não qualificado · condições de chapa e coluna espessas não satisfeitas'
        return 'Atende'


@dataclass
class FourESEndPlateCheck(MomentEndPlateCheck):
    """Source qualification is separate from the finite numeric comparison."""
    source_qualified: bool = True

    @property
    def category(self):
        if self.id.startswith('ep_stiffener_'):return 'Condição do método'
        return super().category
    @property
    def outcome(self):
        if self.numerically_valid and self.applicable and self.passed and not self.source_qualified:
            return 'Não qualificado · domínio ou caminho dos enrijecedores 4ES não satisfeito'
        return super().outcome


class EightESEndPlateCheck(FourESEndPlateCheck):
    @property
    def passed(self):
        if self.id in ('ep_plate_rigidity','ep_column_rigidity'):
            return self.numerically_valid and self.demand<=self.resistance
        return super().passed
    @property
    def outcome(self):return super().outcome.replace('enrijecedores 4ES','enrijecedores 8ES')


def moment_envelope(*cases):
    """Select a COMPLETE row per mechanism; never mix case demands/capacities."""
    out={}
    for rows in cases:
        for row in rows:
            current=out.get(row.id)
            if current is None or (row.numerically_valid and (not current.numerically_valid or row.ratio>current.ratio)):
                out[row.id]=row
    return list(out.values())


MOMENT_GROUPS={
    'ep_bolt_interaction':('ep_bolt_interaction','ep_bolt_tension','ep_bolt_shear'),
    'ep_plate_rigidity':('ep_plate_rigidity','ep_plate_yield'),
    'ep_weld_cjp_web_local':('ep_weld_cjp_web_local','ep_beam_web_local_tension'),
}


def moment_summary(rows):
    """Only three proved display redundancies; all branches stay in checks."""
    hidden={'ep_bolt_tension','ep_bolt_shear','ep_plate_yield','ep_beam_web_local_tension'}
    names={'ep_plate_rigidity':'Chapa — espessura do método e plastificação',
           'ep_weld_cjp_web_local':'Alma e junta CJP — transferência local à tração'}
    out=[]
    for row in rows:
        if row.id in hidden:continue
        if row.id in MOMENT_GROUPS:
            branches=[x for x in rows if x.id in MOMENT_GROUPS[row.id]]
            # Keep the complete selected row. Companion branches carry their own
            # case, unit, demand, capacity and outcome, including actual yielding.
            if row.id=='ep_plate_rigidity':row=replace(max(branches,key=lambda x:x.ratio),name=names['ep_plate_rigidity'])
            branch_text=' '.join(x.name+' ['+x.case+']: Sd='+format(x.demand,'.12g')+' '+x.unit+'; Rd='+format(x.resistance,'.12g')+' '+x.unit+'; η='+format(x.ratio,'.12g')+'; '+x.outcome+'. '+x.equation+'. '+x.substitution+'. Fonte: '+x.reference+'.' for x in branches)
            row=replace(row,name=names.get(row.id,row.name),variables=row.variables+' Ramos numéricos conservados: '+branch_text)
        out.append(row)
    return out


@dataclass
class MomentEndPlateResult(Result):
    minimum: list[Check] = field(default_factory=list)
    case_records: list[dict] = field(default_factory=list)

    @property
    def summary_checks(self):return moment_summary(self.checks)
    @property
    def actual_summary(self):return moment_summary(self.actual)
    @property
    def minimum_summary(self):return moment_summary(self.minimum)
    @property
    def all_case_checks(self):return self.actual+self.minimum
    @property
    def resistance_failures(self):return [x for x in self.checks if x.numerically_valid and x.applicable and x.category=='Resistência' and not x.passed]
    @property
    def method_failures(self):return [x for x in self.checks if x.numerically_valid and x.applicable and x.category=='Condição do método' and (not x.passed or not getattr(x,'source_qualified',True))]
    @property
    def numeric_failures(self):return [x for x in self.all_case_checks if not x.numerically_valid]
    @property
    def coverage_note(self):
        notes=[]
        if self.resistance_failures:notes.append('Resistência local não atendida: '+', '.join(x.name+' ['+x.case+']' for x in self.resistance_failures)+'.')
        if self.numeric_failures:notes.append('Falha numérica: mecanismos com valores não finitos ou resistência não positiva não têm conclusão; resultados finitos disponíveis são preservados.')
        if self.method_failures:notes.append('Condições do método não satisfeitas: '+', '.join(x.name+' ['+x.case+']' for x in self.method_failures)+'. Não são, isoladamente, sobrecargas resistentes demonstradas. Tração/interação dos parafusos sem alavanca dependem das duas espessuras requeridas.')
        if any(x.severity=='noncompliance' for x in self.issues):notes.append('Há requisito de detalhamento não atendido; as dimensões informadas foram preservadas.')
        notes.extend(x.text for x in self.issues if x.origin in ('numeric','method','local_scope') or x.severity=='pending')
        return ' '.join(dict.fromkeys(notes))
    @property
    def status(self):
        if self.resistance_failures:return 'NÃO ATENDE'
        if self.numeric_failures or any(x.origin=='numeric' for x in self.issues):return 'FALHA NUMÉRICA · REVISAR ENTRADA'
        if any(x.severity=='error' and x.origin=='data' for x in self.issues):return 'DADOS NECESSÁRIOS AUSENTES OU INVÁLIDOS'
        if any(x.severity=='error' and x.origin not in ('method','numeric') for x in self.issues):return 'GEOMETRIA INVÁLIDA'
        if any(x.severity=='noncompliance' for x in self.issues):return 'NÃO ATENDE AO DETALHAMENTO'
        if self.method_failures or any(x.origin=='method' for x in self.issues):return 'CONDIÇÕES DO MÉTODO NÃO SATISFEITAS'
        if any(x.severity=='extrapolation' for x in self.issues):return 'CÁLCULO COM RESSALVAS · EXTRAPOLAÇÃO DO MODELO'
        if any(x.severity=='pending' for x in self.issues):return 'VERIFICAÇÕES LOCAIS ATENDEM · ESCOPO INCOMPLETO'
        if not self.checks:return 'SEM VERIFICAÇÕES DE RESISTÊNCIA'
        if any(x.severity=='interference' for x in self.issues):return 'CÁLCULO ATENDE · CONFERIR INTERFERÊNCIAS'
        return 'ATENDE ÀS VERIFICAÇÕES REALIZADAS'
    @property
    def governing(self):
        rows=[x for x in self.checks if x.numerically_valid and x.applicable and x.category=='Resistência']
        return max(rows,key=lambda x:x.ratio) if rows else None


def moment_decimal_spacings(c):
    """Derived engineering dimensions, evaluated before binary row subtraction."""
    d=lambda x:Decimal(str(x))
    inner=d(c.beam.d)-2*d(c.beam.tf)-2*d(c.pfi)
    outer=d(c.pfo)+d(c.beam.tf)+d(c.pfi)
    if c.is_mre12:return [outer,d(c.pb),inner-2*d(c.pb),d(c.pb),outer]
    if c.is_8es:return [d(c.pb),outer,d(c.pb),inner-2*d(c.pb),d(c.pb),outer,d(c.pb)]
    return [outer]+[inner/Decimal(c.intermediate_n+1)]*(c.intermediate_n+1)+([outer] if c.layout=='both' else [])


STOCK={'1/4"':6.35,'5/16"':7.9375,'3/8"':9.525,'1/2"':12.7,'5/8"':15.875,'3/4"':19.05,'7/8"':22.225,'1"':25.4,'1 1/4"':31.75,'1 1/2"':38.1}

@dataclass(frozen=True)
class EndPlate:
    beam: Profile
    support: Profile
    kind: str='pinned'
    layout: str='both'
    project: str='End plate na mesa de coluna'
    beam_steel: str='ASTM A572 Gr.50'
    support_steel: str='ASTM A36'
    plate_steel: str='ASTM A36'
    bolt: str='ASTM F3125 A325'
    db: float=19.05
    tp: float=9.525
    bp: float=180.
    gauge: float=100.
    n: int=4
    pitch: float=70.
    overhang: float=5.
    pfi: float=45.
    pfo: float=40.
    edge: float=35.
    intermediate_n: int=0
    weld: float=5.
    fw: float=485.
    reinforced_edge: bool=True
    threads: bool=True
    drilled: bool=False
    norm_minimum: bool=True
    tool_radius: float=18.
    V: float=11000.
    N: float=2000.
    M: float=0.
    notes: str=''
    variant: str='4E'
    pb: float=70.
    stiffener_steel: str='ASTM A572 Gr.50'
    stiffener_t: float=9.525
    stiffener_length: float=150.
    stiffener_clip: float=25.4
    stiffener_landing: float=25.4
    stiffener_weld: str='CJP'
    stiffener_electrode: str='E7018'
    stiffener_compatible: bool=True
    stiffener_clearance: bool=True
    detail_ribs: bool=False
    detail_rib_auto_t: bool=True
    detail_rib_t: float=9.525
    detail_rib_length: float=150.
    cjp_electrode: str='E7018'
    cjp_compatible: bool=False
    @property
    def has_detail_ribs(self):return self.kind=='moment' and self.variant in ('4E','MRE12_U') and self.detail_ribs
    @property
    def detail_rib_thickness(self):
        return next_stock_thickness(self.beam.tw) if self.detail_rib_auto_t else self.detail_rib_t
    @property
    def is_mre12(self):return self.kind=='moment' and self.variant=='MRE12_U'
    @property
    def is_4es(self):return self.kind=='moment' and self.variant=='4ES'
    @property
    def is_8es(self):return self.kind=='moment' and self.variant=='8ES'
    @property
    def is_stiffened(self):return self.is_4es or self.is_8es
    @property
    def tension_arms(self):
        h1=self.beam.d-self.beam.tf/2+self.pfo
        h2=self.beam.d-1.5*self.beam.tf-self.pfi
        return [h1,h2,h2-self.pb] if self.is_mre12 else [h1+self.pb,h1,h2,h2-self.pb] if self.is_8es else [h1,h2]
    @property
    def web_tension_length(self):return self.pfi+(self.pb if self.is_8es or self.is_mre12 else 0.)+152.4
    @property
    def dh(self):return self.db+(1.5875 if self.db<25.4 else 3.175)
    @property
    def dn(self):return self.dh+(0 if self.drilled else 2.)
    @property
    def ext_top(self):return self.overhang if self.kind=='pinned' else self.pfo+self.edge+(self.pb if self.is_8es else 0.)
    @property
    def ext_bottom(self):return self.overhang if self.kind=='pinned' or self.layout=='top' else self.pfo+self.edge+(self.pb if self.is_8es else 0.)
    @property
    def hp(self):return self.beam.d+self.ext_top+self.ext_bottom
    @property
    def primary_rows(self):
        # y é positivo para baixo a partir da face superior da viga.
        if self.kind=='pinned':return [(self.beam.d-(self.n-1)*self.pitch)/2+i*self.pitch for i in range(self.n)]
        if self.is_mre12:
            return [-self.pfo,self.beam.tf+self.pfi,self.beam.tf+self.pfi+self.pb,
                    self.beam.d-self.beam.tf-self.pfi-self.pb,self.beam.d-self.beam.tf-self.pfi,self.beam.d+self.pfo]
        if self.is_8es:
            return [-self.pfo-self.pb,-self.pfo,self.beam.tf+self.pfi,self.beam.tf+self.pfi+self.pb,
                    self.beam.d-self.beam.tf-self.pfi-self.pb,self.beam.d-self.beam.tf-self.pfi,
                    self.beam.d+self.pfo,self.beam.d+self.pfo+self.pb]
        return [-self.pfo,self.beam.tf+self.pfi,self.beam.d-self.beam.tf-self.pfi]+([self.beam.d+self.pfo] if self.layout=='both' else [])
    @property
    def intermediate_rows(self):
        if self.kind!='moment' or self.is_8es or self.is_mre12:return []
        lo=self.beam.tf+self.pfi;hi=self.beam.d-self.beam.tf-self.pfi
        return [lo+(hi-lo)*i/(self.intermediate_n+1) for i in range(1,self.intermediate_n+1)]
    @property
    def rows(self):return self.primary_rows if self.is_8es or self.is_mre12 else sorted(self.primary_rows+self.intermediate_rows)
    @property
    def calculation_count(self):return 2*len(self.primary_rows)
    @property
    def effective_bp(self):return min(self.bp,self.beam.bf+max(25.4,self.tp)) if self.kind=='moment' else self.bp
    @property
    def effective_bfc(self):return min(self.support.bf,self.beam.bf+max(25.4,self.tp)) if self.kind=='moment' else self.support.bf
    @property
    def count(self):return 2*len(self.rows)
    @property
    def assumptions(self):
        common=[
            'Análise local em duas dimensões. Esforços de cálculo no nó, no plano da alma da viga; N positivo é tração. V é vertical. Não há momento no eixo de menor inércia nem cortante horizontal.',
            'Uma viga ortogonal e centrada na alma da coluna; coluna contínua, sem extremidade, emenda ou abertura próxima ao grupo. Não há viga oposta ou outras cargas locais concorrentes no nó.',
            'Viga com contenção eficaz; impedido o deslocamento lateral relativo das mesas da coluna. Juntas internas mesa–alma dos perfis soldados com penetração total e metal de adição compatível.',
            'Chapa e coluna pintadas ou protegidas contra corrosão. Espaçamentos máximos avaliados na região em contato; os prolongamentos da coluna contínua além do contorno da chapa não são bordas de uma emenda sobreposta.',
            'Furos padrão, ligação por contato, parafusos de alta resistência com protensão inicial conforme NBR 6.8, sem crédito ao atrito. Chapa e mesa da coluna em contato, sem calços. Soldagem em oficina.',
            'Análise global da coluna, interação com seu esforço axial, efeitos de segunda ordem e compatibilidade com a estrutura são externos ao modelo local. Não se avaliam fadiga, vibração, ações cíclicas, sismo ou incêndio.',
            'Dimensões de ferramenta são envelopes de montagem informados; comprimentos de parafusos, arruelas, preparação das juntas e tolerâncias devem constar do detalhamento de fabricação.',
        ]
        if self.kind=='pinned':common += [
            'Rotulada nominal de altura total: SCI P358 é referência complementar de detalhamento; resistências calculadas conforme NBR. Gabarito de 90 a 140 mm e chapa com fy ≤ 275 MPa são condições da referência. Sobra até 10 mm e grupo abrangendo metade da altura são limites adotados pela aplicação, sem atribuí-los ao Check 1. A qualificação local completa permanece explicitamente pendente, mesmo quando os componentes calculados atendem.',
            'Na parcela calculada, N é atribuído à alma, com tração igual por parafuso e compressão por contato. As soldas das mesas existem e sua transferência permanece não qualificada; ausência de crédito resistente não elimina a restrição física. O modelo não recebe momento externo; |M| ≤ 1e-9 N·mm é tolerância numérica de zero.',
            'Para não desprezar alavanca indevidamente, exige-se chapa e mesa da coluna rígidas sob a tração calculada, pela NBR 6.3.5.3. Essa condição local de alavanca nula não é classificação de rigidez rotacional do nó.',
            'Filetes contínuos na alma e nas mesas da viga; borda reforçada admitida onde explicitamente indicada.' if self.reinforced_edge else 'Filetes contínuos na alma e nas mesas da viga, sem reforço de borda.',
        ]
        else:common += [
            'End plate estendida sem nervuras, configuração base 4E do DG39: duas linhas tracionadas, dois parafusos por linha. O critério construtivo FR do guia só sustenta a hipótese de rigidez dentro de seu domínio de aplicação, a critério do responsável técnico conforme NBR 6.1.2.3. Com avisos de extrapolação, essa classificação não está confirmada. Não é calculada uma curva momento–rotação nem se verifica Si ≥ 25EI/L ou Kv/Kp da análise global.',
            'Método de chapa espessa: chapa e mesa da coluna devem resistir a 1,10 Meq antes da plastificação; γr=1,0. Resistências nominais do mecanismo são divididas por γa1. A versão também exige espessura não menor que a obtida com φb=0,90 do guia.',
            'N é distribuído igualmente entre as mesas. Para tração, Meq=|M|+N(d−tf)/2. Não se usa o alívio de tração causado por compressão. Domínio limitado a |N|(d−tf)/2 ≤ |M|/2.',
            'As soldas das duas mesas e da alma da viga à chapa de topo são de penetração total, com metal de adição compatível. Esta especificação é própria da end plate engastada; não cria solda entre viga e coluna. A tensão equivalente da seção inteira não substitui as verificações locais de transferência na região tracionada.',
            'Sem contribuição resistente de laje mista. Não há furos de acesso às soldas alterando a seção ou o caminho de forças. Preparação, sequência, qualificação e inspeção das juntas CJP devem garantir a penetração e a compatibilidade especificadas, inclusive nas interseções mesa–alma.',
            'A força da mesa tracionada para transferência local é Ff=|M|/(d−tf)+max(N;0)/2. No grupo base 4E, metade de Ff solicita a alma junto à linha interna e metade solicita o prolongamento não enrijecido da chapa. A força cortante V da ligação não substitui essas demandas. A região de tração da alma tem lwt=pfi+152,4 mm a partir da face interna da mesa tracionada; não se atribui resistência a comprimento inexistente de alma.',
            'A verificação do painel da coluna usa somente a contribuição da alma, sem ganho das mesas. Adota-se Ncol,Sd ≤ 0,4 Ag,col fy,col e despreza-se o cortante favorável da coluna. Outros esforços de nó exigem compatibilização externa.',
        ]
        if self.kind=='moment' and not self.is_stiffened:
            common.append('Coluna 4E sem reforço: Ff=|M|/(d−tf)+max(N;0)/2 e Fc=|M|/(d−tf)+max(−N;0)/2. Escoamento local da alma usa max(Ff;Fc); enrugamento usa Fc, conforme DG39 3.5/3.7.6. T=4Tb e C=max(T−N;0) permanecem exclusivos dos caminhos de parafusos e contato. As resistências NBR conservam k=tf, ln=0 e a condição de extremidade, sem crédito ao raio, espalhamento ou reforço.')
        if self.is_4es:
            common=[note for note in common if not note.startswith('End plate estendida sem nervuras') and not note.startswith('A força da mesa tracionada')]
            common += [
                'Variante 4ES, DG39 tabela 5-11: duas nervuras físicas centradas, uma acima e uma abaixo da viga; oito parafusos, quatro ativos à tração por caso. Extensões simétricas e os dois extremos preparados para tração permitem casos estáticos separados de ±M. Não é qualificação sísmica/cíclica. Sem enrijecedores, chapas de continuidade ou doubler na coluna.',
                'O mecanismo 4ES exige de<s=√(bp,ef g)/2, ambas as espessuras de chapa/coluna e o caminho qualificado das nervuras. pfo/pfi são limitados a s somente em Yp; coordenadas e braços físicos permanecem informados. Critério FR complementar somente no domínio fonte, sujeito à análise global do responsável técnico; não se calcula curva momento–rotação.',
                'A força de mesa é Ff=|M|/(d−tf)+max(N;0)/2; Fc=|M|/(d−tf)+max(−N;0)/2. A alma da coluna recebe max(Ff;Fc) no escoamento e Fc no enrugamento. O resultante dos parafusos T=4Tb e o contato C=max(T−N;0) são grandezas distintas. A transferência local da alma da viga permanece Ff/2; não se inventa cisalhamento do prolongamento enrijecido.',
                'Rota 4ES: aços da viga, chapa de topo e nervuras selecionados independentemente entre A36/A572 Gr.42/Gr.50; ts≥tw fyb/fys. Sem furos nas nervuras/regiões conectadas. CJP contínua nas duas interfaces. Cada junta usa área da menor espessura conectada e menor fy, conforme NBR 6.2.5.1; desenvolvimento integral verificado separadamente. A coluna conserva seu próprio aço.',
                'Detalhe adotado DG39 figura 4-3: hst=pfo+de; Lst≥hst/tan30°; patamares cerca de 25,4 mm recomendados. Recorte de canto real; solda-se primeiro a mesa da viga e depois as nervuras, com preparação, acesso e inspeção que garantam a CJP. Comprimentos conectados reais hst−recorte e Lst−recorte; não existe solda fictícia através do recorte.',
                'Desenvolvimento CJP das nervuras no mesmo nível de resistência de cálculo NBR: tração fys ts/γa1 na chapa e cisalhamento 0,60 fys ts/γa1 na mesa, por unidade de comprimento conectado. As capacidades usam min(fys;fyp) min(ts;tp)/γa1 e 0,60 min(fys;fyb) min(ts;tf)/γa1; uma nervura mais resistente pode falhar mesmo com receptor mais espesso. ts≤espessura receptora é necessário, mas não suficiente. Não se aplica a regra de esbeltez sísmica da eq.3-37.',
                'Rota de consumível adotada: eletrodo E7018 classe 70 (fw=485 MPa), processo/preparação compatíveis conforme NBR tabela 8, para A36/A572 Gr.42/Gr.50. A relação sem furos fu/γa2≥fy/γa1 é verificada separadamente nos aços da viga, chapa e nervuras. Para grupos diferentes, baixo hidrogênio e preaquecimento do grupo de maior resistência conforme tabela 8, nota a; a declaração inclui qualificação do procedimento.',
                'Fontes verificadas: edição DG39 2023 fornecida. A errata oficial de novembro de 2024 não estava acessível na qualificação; não foi declarada revisada.',
            ]
        if self.is_8es:
            common=[note for note in common if not note.startswith('End plate estendida sem nervuras') and not note.startswith('A força da mesa tracionada')]
            common += [
                'Variante 8ES, DG39 tabela 5-16 e tabela A-5(a): oito linhas físicas com dois parafusos por linha, 16 parafusos totais e oito ativos à tração em quatro linhas por caso estático. Duas nervuras externas idênticas centradas na alma; extensões simétricas. Sem linhas intermediárias, enrijecedores, continuidade ou doubler na coluna.',
                'Método 8ES ordinário estático: de<sP estritamente; pfo/pfi limitados a sP somente no Yp. Braços, coordenadas, pb e c físicos não são limitados. Yc usa a tabela A-5(a) de coluna contínua não enrijecida, com sC próprio e coeficientes literais h2 c/4 e h3 c/2. Ambas as espessuras e o caminho CJP qualificado são necessários; sem solução de chapa fina, alavanca ou sismo.',
                'Tb=Meq/[2(h1+h2+h3+h4)], T=8Tb e C=max(T−N;0). V/16 atua em todos os parafusos físicos, com interação NBR nos oito tracionados. Ff=|M|/(d−tf)+max(N;0)/2; Fc=|M|/(d−tf)+max(−N;0)/2. Escoamento local da alma da coluna usa max(Ff;Fc); enrugamento usa Fc. T não substitui Ff.',
                'Transferência local da alma: (4/8)Ff=Ff/2, lwt=pfi+pb+152,4 mm; lws=min(d−2tf−lwt;(d−2tf)/2). Regiões CJP de tração e cisalhamento disjuntas em cada caso, refletidas com M. Não se descontam ambas as regiões alternativas. Não se verificam escoamento/ruptura por cisalhamento da extensão enrijecida, conforme exemplo 5.3-7 p.184.',
                'Viga, chapa e nervuras com aços independentes A36/A572 Gr.42/Gr.50; ts≥tw fyb/fys. CJP usa o menor fy e a menor espessura de cada interface; desenvolvimento integral da nervura obrigatório. Sem furos nas regiões soldadas; fu/γa2≥fy/γa1 verificado em cada um dos três materiais. E7018 fw=485 MPa, baixo hidrogênio e preaquecimento pelo grupo de maior resistência, com procedimento/preparação compatíveis declarados conforme NBR tabela 8, nota a. A coluna conserva seu próprio aço.',
                'Detalhe fonte adotado: hst=pfo+pb+de; Lst≥hst/tan30°. Recorte diagonal real; comprimentos conectados hst−recorte e Lst−recorte, sem solda através do recorte. Patamares aproximadamente 25,4 mm recomendados, sem dedução adicional das juntas. Primeiro soldar alma–chapa, depois mesa–chapa, depois instalar nervuras; acesso e inspeção CJP obrigatórios.',
                'CJP nervura–chapa desenvolve fys ts/γa1 em tração; nervura–mesa desenvolve 0,60 fys ts/γa1 em cisalhamento. Hierarquia no mesmo nível de cálculo NBR. A eq.3-37 de esbeltez sísmica não é imposta ao serviço ordinário. Não há regra fictícia de filete, compressão integral ou punção da nervura.',
                'Domínio de equações testadas: DG39 tabela 5-9 com ±10%; sem intervalo próprio inventado para pb. Espaçamentos, ligamentos e bordas usam as oito linhas físicas. Desvios de domínio são extrapolação, separados de sobrecarga resistente. Critério FR complementar sujeito à análise global; nenhuma curva momento–rotação é calculada.',
                'Fontes: DG39 2023 fornecido, tabelas 5-16/A-5(a), exemplo 5.3-7 e NBR 8800:2024 corrigida 2025. Errata de novembro de 2024 indisponível, não declarada revisada. O exemplo com bp=12 pol. excede a faixa da tabela 5-9 e é apenas oráculo de componentes; a substituição inconsistente de braços da p.257 não altera os coeficientes da tabela A-5.',
            ]
        if self.is_mre12:
            from .end_plate_mre12 import assumptions
            return common[:7]+[('Modelo base de cálculo: '+note if self.has_detail_ribs and note.startswith('MRE1/2 sem nervuras') else note) for note in assumptions(self)]+([DETAIL_SCOPE] if self.has_detail_ribs else [])
        if self.kind=='moment' and self.intermediate_n:
            common.append('Linhas intermediárias são parafusos de detalhamento, sem crédito de resistência ou redistribuição de N, V e M: as forças continuam atribuídas ao grupo base 4E. Todos os furos são considerados nos ligamentos e blocos da chapa e no espaçamento. O efeito dos parafusos adicionais sobre contato, tração, alavanca e linhas de plastificação exige avaliação específica; este arranjo é sinalizado como extrapolação, sem aprovação automática de resistência ou rigidez.')
        if self.has_detail_ribs:
            common=[('Modelo base de cálculo: '+note if note.startswith('End plate estendida sem nervuras') else note) for note in common]
            common.append(DETAIL_SCOPE)
        return common
    def to_dict(self):
        # A saved outcome is an audit snapshot, never authority on reimport.
        # from_dict loads the unchanged inputs and the engine recalculates them.
        return {'schema_version':1,'app_version':VERSION,'connection_type':'end_plate','connection':connection_inputs(self),'fixed_assumptions':self.assumptions,'verification':verification_snapshot(self)}
    @staticmethod
    def from_dict(data):
        if not isinstance(data,dict) or data.get('connection_type')!='end_plate' or data.get('schema_version')!=1:raise ValueError('Selecione um projeto de end plate desta versão.')
        d=dict(data['connection'])
        if {'cjp_electrode','cjp_compatible'}&set(d) and d.get('variant')!='MRE12_U':
            raise ValueError('Campos CJP MRE1/2 exigem identidade variant=MRE12_U; não se converte para outra topologia.')
        if 'pb' in d and 'variant' not in d:raise ValueError('Projeto com pb exige identidade variant explícita; não se converte 8ES para 4E.')
        if d.get('variant')=='MRE12_U':
            from .end_plate_mre12 import required_inputs
            missing=required_inputs()-set(d)
            if missing:raise ValueError('Projeto MRE1/2 sem dados/declarações obrigatórios: '+', '.join(sorted(missing)))
            if d['kind']!='moment':raise ValueError('Identidade MRE1/2 exige kind=moment.')
        if d.get('variant')=='8ES':
            required=STIFFENER_FIELDS|{'kind','beam','support','variant','layout','pb','pfi','pfo','edge','gauge','tp','bp','db','bolt','beam_steel','support_steel','plate_steel','threads','drilled','norm_minimum','tool_radius','fw','V','N','M','intermediate_n'}
            missing=required-set(d)
            if missing:raise ValueError('Projeto 8ES sem dados/declarações obrigatórios: '+', '.join(sorted(missing))+'. Não se presume geometria ou qualificação CJP.')
            if d['kind']!='moment':raise ValueError('Identidade 8ES exige kind=moment; não se converte para rotulada.')
        if d.get('kind')=='moment' and d.get('variant')=='4ES':
            missing=STIFFENER_FIELDS-set(d)
            if missing:raise ValueError('Projeto 4ES sem dados/declarações obrigatórios: '+', '.join(sorted(missing))+'. Não se presume compatibilidade CJP ou geometria não informada.')
        if d.get('variant')=='8ES':
            unknown=set(d)-{f.name for f in fields(EndPlate)}
            if unknown:raise ValueError('Campos 8ES desconhecidos: '+', '.join(sorted(unknown)))
        d['beam']=Profile(**d['beam']);d['support']=Profile(**d['support']);result=EndPlate(**d)
        if result.is_8es or result.is_mre12:
            invalid=[i.text for i in validate(result) if i.severity=='error' and i.origin in ('data','numeric')]
            if invalid:raise ValueError('Entradas '+('MRE1/2' if result.is_mre12 else '8ES')+' inválidas: '+' '.join(invalid))
        from .end_plate_detail import validate_detail_inputs
        validate_detail_inputs(result)
        return result


def yield_4e(bp,g,h1,h2,pfo,pfi):
    """DG39 Tabela 5-10. Todas as medidas na mesma unidade; Y tem dimensão L."""
    s=math.sqrt(bp*g)/2;pi=min(pfi,s)
    return bp/2*(h1/pfo+h2*(1/pi+1/s)-.5)+2/g*h2*(s+pi)


def yield_4es(bp,g,h1,h2,pfo,pfi,de):
    """DG39 Table 5-11, strict de<s. Cap pitches only inside Yp."""
    s=math.sqrt(bp*g)/2
    if not 0<de<s:raise ValueError('4ES Table 5-11 requires 0 < de < s.')
    po=min(pfo,s);pi=min(pfi,s)
    return bp/2*(h1*(1/po+1/(2*de))+h2*(1/pi+1/s))+2/g*(h1*(po+de)+h2*(pi+s))


def yield_8es(bp,g,h1,h2,h3,h4,pfo,pfi,pb,de):
    """DG39 Table 5-16. Literal row coefficients; caps only in Yp."""
    s=math.sqrt(bp*g)/2
    if not 0<de<s:raise ValueError('8ES Table 5-16 requires 0 < de < s.')
    po=min(pfo,s);pi=min(pfi,s)
    return (bp/2*(h1/(2*de)+h2/po+h3/pi+h4/s)
        +2/g*(h1*(de+3*pb/4)+h2*(po+pb/4)+h3*(pi+3*pb/4)+h4*(s+pb/4))+g)


def yield_column_8es(bfc,g,h1,h2,h3,h4,c,pb):
    """DG39 Table A-5(a), continuous unstiffened column; h2 c/4 is literal."""
    s=math.sqrt(bfc*g)/2
    return bfc/2*(h1/s+h4/s)+2/g*(h1*(pb+c/2+s)+h2*(pb/2+c/4)+h3*(pb/2+c/2)+h4*s)+g/2


def source_domain_8es(c):
    """DG39 Table5-9 exact engineering-decimal ±10% boundaries; no pb range."""
    limits={'pfi':(c.pfi,'22.86','69.85'),'pfo':(c.pfo,'22.86','69.85'),
        'extension':(c.ext_top,'57.15','209.55'),'g':(c.gauge,'62.865','195.58'),
        'd':(c.beam.d,'360.045','2011.68'),'bp':(c.bp,'114.3','286.385'),
        'tf':(c.beam.tf,'8.5725','27.94')}
    return {key:dict(value=value,low=float(lo),high=float(hi),within=Decimal(lo)<=Decimal(str(value))<=Decimal(hi))
        for key,(value,lo,hi) in limits.items()}


def stiffener_state(c):
    """Independent finite steels; each CJP develops its actual connected base metal.

    NBR 6.2.5.1/Table 9: use the lower fy and the thinner connected metal
    separately, not min(fy*t). DG39 3.7.5 requires full stiffener development.
    """
    ss=STEELS[c.stiffener_steel];sb=STEELS[c.beam_steel];sp=STEELS[c.plate_steel]
    h=c.ext_top;L=c.stiffener_length;ts=c.stiffener_t
    required=c.beam.tw*sb.fy/ss.fy
    length_required=h/math.tan(math.radians(30))
    runs=(h-c.stiffener_clip,L-c.stiffener_clip)
    same=c.stiffener_steel==c.beam_steel==c.plate_steel
    hierarchy=ts<=min(c.tp,c.beam.tf)
    materials=all(name in CJP_STEELS for name in (c.beam_steel,c.plate_steel,c.stiffener_steel))
    electrode=c.stiffener_electrode=='E7018' and c.fw==485.
    compatible=c.stiffener_compatible and c.stiffener_weld=='CJP' and electrode and materials
    nohole_ratios={name:(steel.fu/G2)/(steel.fy/G1) for name,steel in
                   (('beam',sb),('plate',sp),('stiffener',ss))}
    nohole=all(steel.fu/G2>=steel.fy/G1 for steel in (sb,sp,ss))
    qt=ss.fy*ts/G1;qv=.6*ss.fy*ts/G1
    plate_qrd=min(ss.fy,sp.fy)*min(ts,c.tp)/G1
    flange_qrd=.6*min(ss.fy,sb.fy)*min(ts,c.beam.tf)/G1
    # The thickness consequence is also compared before multiplication: one
    # ULP of insufficient receiver thickness can round away in fy*t/gamma.
    development=hierarchy and qt<=plate_qrd and qv<=flange_qrd
    qualified=(development and compatible and nohole and c.stiffener_clearance and
        ts>=required and L>=length_required and min(runs)>0 and
        0<c.stiffener_landing<min(h,L))
    return dict(stiffener_height=h,stiffener_t_required=required,stiffener_length_required=length_required,
        stiffener_plate_run=runs[0],stiffener_flange_run=runs[1],stiffener_same_steel=same,
        stiffener_receiver_hierarchy=hierarchy,stiffener_cjp_compatible=compatible,
        stiffener_materials_qualified=materials,stiffener_cjp_development_qualified=development,
        stiffener_nohole_rupture_qualified=nohole,stiffener_nohole_rupture_yield_ratio=(ss.fu/G2)/(ss.fy/G1),
        stiffener_nohole_material_ratios=nohole_ratios,
        stiffener_electrode=c.stiffener_electrode,stiffener_receiver_plate_qrd=sp.fy*c.tp/G1,
        stiffener_receiver_flange_qrd=.6*sb.fy*c.beam.tf/G1,
        stiffener_qualified=qualified,
        stiffener_qt=qt,stiffener_qv=qv,
        stiffener_plate_qrd=plate_qrd,stiffener_flange_qrd=flange_qrd)


def yield_column_4e(bfc,g,h1,h2,c):
    """DG39 eq. 3-44, coluna contínua não enrijecida."""
    s=math.sqrt(bfc*g)/2
    return bfc/2*(h1+h2)/s+2/g*(h2*(3*c/4+s)+h1*(c/4+s)+c*c/2)+g/2


def thick_required(M,fy,Y,gamma=G1):return math.sqrt(1.10*M*max(gamma,1/.90)/(fy*Y))


def rigid_strip(T,b,p,fu,db):
    """NBR 6.3.5.3. b é distância do eixo do furo à face do elemento tracionado."""
    return math.sqrt(4*max(b-db/2,0)*T*G1/(p*fu))


def tributaries(rows,lo,hi,b):
    # NBR 6.3.5.2, faixas externas/internas; espaçamentos não uniformes
    # recebem metade do intervalo em cada lado, limitada a 1,75b.
    return [min(y-lo if i==0 else (y-rows[i-1])/2,1.75*b)+min(hi-y if i==len(rows)-1 else (rows[i+1]-y)/2,1.75*b) for i,y in enumerate(rows)]


def validate(c):
    if c.variant=='MRE12_U' and c.kind!='moment':return [Issue('error','Identidade MRE1/2 exige kind=moment.','Identidade do método','data')]
    if c.is_mre12:
        from .end_plate_mre12 import validate_mre12
        return validate_mre12(c)
    out=[]
    def err(t,ref='Geometria e domínio do modelo',origin='model'):out.append(Issue('error',t,ref,origin))
    def domain(t,ref='Domínio do modelo'):out.append(Issue('extrapolation',t,ref))
    def detail(t,ref):out.append(Issue('noncompliance',t+' Cálculo liberado; requisito de detalhamento não atendido.',ref,'data'))
    def interference(t):out.append(Issue('interference',t))
    if c.is_8es:
        required_numbers=tuple(f.name for f in fields(c) if f.type in (float,int) and f.name not in DETAIL_FIELDS)
        if any(type(getattr(c,k)) not in (int,float) or not math.isfinite(getattr(c,k)) for k in required_numbers):
            err('Entradas numéricas 8ES devem ser números reais finitos, não textos ou booleanos.',origin='data');return out
        if c.pb<=0:err('Passo pb 8ES deve ser positivo.',origin='data');return out
        if c.db not in DIAMETERS.values():
            err('Diâmetro 8ES deve coincidir exatamente com o catálogo; não se arredonda a entrada.',origin='data');return out
        if any(type(getattr(c,k)) is not str for k in ('beam_steel','support_steel','plate_steel','bolt','layout','stiffener_weld','stiffener_electrode')):
            err('Seleções nativas 8ES devem ser identificadores de texto válidos.',origin='data');return out
        if c.layout!='both' or c.intermediate_n!=0:
            err('8ES exige extensões simétricas, oito linhas primárias e 16 parafusos; sem linhas intermediárias.',DG+', tabela 5-16',origin='method');return out
        for profile in (c.beam,c.support):
            if not isinstance(profile,Profile) or any(type(getattr(profile,k)) not in (int,float) for k in ('d','bf','tw','tf','clear','area')):
                err('Seções nativas 8ES inválidas.',origin='data');return out
    nums=[f.name for f in fields(c) if f.name not in DETAIL_FIELDS and (c.is_stiffened or f.name not in STIFFENER_FIELDS) and (c.is_8es or f.name!='pb') and isinstance(getattr(c,f.name),(int,float)) and not isinstance(getattr(c,f.name),bool)]
    if any(not math.isfinite(getattr(c,k)) for k in nums):err('Todos os números devem ser finitos.',origin='numeric');return out
    positive_dimensions=('db','tp','bp','gauge','pfi','pfo','edge','fw','tool_radius') if c.is_8es else ('db','tp','bp','gauge','pitch','overhang','pfi','pfo','edge','weld','fw','tool_radius')
    if any(getattr(c,k)<=0 for k in positive_dimensions):err('Dimensões e resistências devem ser positivas.');return out
    if c.kind=='moment' and c.variant not in ('4E','4ES','8ES'):err('Variante de end plate inválida.',origin='data');return out
    if c.kind not in ('pinned','moment') or c.layout not in ('top','both'):err('Tipo ou extensão de chapa inválido.');return out
    if isinstance(c.n,bool) or not isinstance(c.n,int) or (not c.is_8es and not 2<=c.n<=10):err('Usar de 2 a 10 linhas inteiras.' if not c.is_8es else 'Campo legado n deve ser inteiro; as oito linhas 8ES são fixas.');return out
    if type(c.intermediate_n) is not int or not 0<=c.intermediate_n<=10:err('Usar de 0 a 10 linhas intermediárias inteiras.');return out
    if c.kind=='pinned' and c.intermediate_n:err('Na rotulada, use o campo de linhas do grupo, sem linhas intermediárias extras.');return out
    if c.bolt not in BOLTS or c.bolt=='ASTM A307' or not any(abs(c.db-v)<1e-6 for v in DIAMETERS.values()):err('Usar parafuso A325/A490 e diâmetro imperial disponível.');return out
    if any(not isinstance(getattr(c,k),bool) for k in ('threads','drilled','norm_minimum','reinforced_edge')):err('Opção booleana inválida.');return out
    for p,name,steel in [(c.beam,'viga',c.beam_steel),(c.support,'coluna',c.support_steel)]:
        if steel not in STEELS:err('Aço da '+name+' não reconhecido.');continue
        if any(not math.isfinite(getattr(p,k)) or getattr(p,k)<=0 for k in ('d','bf','tw','tf','clear','area')) or p.d<=2*p.tf or p.bf<=p.tw or p.clear>p.d-2*p.tf+1:err('Seção da '+name+' inválida.');continue
        st=STEELS[steel];welded=p.family in ('CS','CVS','VS','Soldado')
        if (welded and not st.plate_allowed) or (not welded and not st.rolled_allowed) or min(p.tf,p.tw)<st.profile_min or max(p.tf,p.tw)>st.profile_max:err('Material incompatível com produto/espessura da '+name+'.')
    if c.plate_steel not in STEELS:err('Aço da chapa não reconhecido.');return out
    sp=STEELS[c.plate_steel]
    if not sp.plate_allowed or not sp.plate_min<=c.tp<=sp.plate_max:err('Aço da chapa incompatível com a espessura/produto.');return out
    if c.is_stiffened:
        for key in ('stiffener_t','stiffener_length','stiffener_clip','stiffener_landing'):
            value=getattr(c,key)
            if type(value) not in (int,float) or not math.isfinite(value) or value<=0:
                err('Dimensões dos enrijecedores devem ser números positivos finitos.',origin='data');return out
        if type(c.stiffener_compatible) is not bool or type(c.stiffener_clearance) is not bool:
            err('Declarações de compatibilidade/acesso CJP devem ser booleanas.',origin='data');return out
        if type(c.stiffener_steel) is not str or c.stiffener_steel not in STEELS:err('Aço do enrijecedor não reconhecido.',origin='data');return out
        ss=STEELS[c.stiffener_steel]
        if not ss.plate_allowed or not ss.plate_min<=c.stiffener_t<=ss.plate_max:
            err('Aço do enrijecedor incompatível com produto/espessura.',origin='data');return out
    if out:return out
    b,s=c.beam,c.support;rows=c.rows
    edge_min={12.7:19,15.875:22,19.05:25,22.225:28,25.4:32,28.575:38,31.75:41}[c.db]
    if c.effective_bp<c.bp:out.append(Issue('info',f'Largura física bp={c.bp:g} mm; largura efetiva no mecanismo limitada a {c.effective_bp:g} mm.',DG+', 3.7.2'))
    if c.effective_bfc<s.bf:out.append(Issue('info',f'Mesa da coluna: largura física bfc={s.bf:g} mm; largura efetiva no mecanismo limitada a {c.effective_bfc:g} mm.',DG+', 4.2.2, eq.4-3'))
    if c.bp>s.bf:err('A chapa ultrapassa a largura da mesa da coluna.')
    if c.bp<b.bf+2*c.weld and c.kind=='pinned':err('A largura da chapa não deixa espaço lateral para os filetes das mesas.')
    lateral_edge=(min(c.bp,s.bf)-c.gauge)/2
    if lateral_edge<=c.dh/2:err('Furo lateral fora do material ou sem ligamento livre positivo.')
    elif lateral_edge<edge_min:
        if c.kind=='pinned':detail(f'Borda lateral {lateral_edge:g} mm inferior ao mínimo adotado {edge_min:g} mm; limite do detalhe suportado, sem qualificar a exceção normativa por contato.',NBR+', 6.3.11')
        else:detail(f'Borda lateral {lateral_edge:g} mm inferior ao mínimo adotado {edge_min:g} mm; furo com ligamento físico positivo.',NBR+', 6.3.11')
    elif lateral_edge<c.tool_radius:interference('Envelope de montagem ultrapassa a borda lateral da chapa ou da mesa da coluna.')
    root_b=(b.d-b.clear)/2;root_c=(s.d-s.clear)/2-s.tf
    clearance_weld=c.weld if c.kind=='pinned' else 0. # CJP has no hidden fillet-leg envelope.
    if c.gauge/2<=max(b.tw/2+clearance_weld,s.tw/2+max(root_c,0))+c.tool_radius:interference('O gabarito dos parafusos interfere com a alma, concordância ou solda.')
    if c.kind=='pinned':
        for label,value in [('Passo entre linhas',c.pitch),('Gabarito horizontal',c.gauge)]:
            if value<=c.dh:err(label+' produz furos sobrepostos ou ligamento livre não positivo.')
            elif value<minimum_bolt_spacing(c.db):detail(f'{label} {value:.12g} mm inferior a 2,7db={minimum_bolt_spacing(c.db):.12g} mm.',NBR+', 6.3.9')
    else:
        spacing_limit=Decimal(str(minimum_bolt_spacing(c.db)))
        hole=Decimal(str(c.db))+Decimal('1.5875' if c.db<25.4 else '3.175')
        for label,value in [('Gabarito horizontal',Decimal(str(c.gauge)))]+[(f'Passo entre linhas {i+1}–{i+2}',v) for i,v in enumerate(moment_decimal_spacings(c))]:
            if value<=hole:err(label+' produz furos sobrepostos ou ligamento livre não positivo.')
            elif value<spacing_limit or value-hole<Decimal(str(c.db)):
                detail(f'{label} {value} mm; mínimo 2,7db={minimum_bolt_spacing(c.db):.12g} mm e ligamento livre ≥ db.',NBR+', 6.3.9')
    pmax=min(24*min(c.tp,s.tf),300.)
    if max([c.gauge]+[y2-y1 for y1,y2 in zip(rows,rows[1:])])>pmax:
        maximum=max([c.gauge]+[y2-y1 for y1,y2 in zip(rows,rows[1:])])
        detail(f'Espaçamento máximo adotado {maximum:g} mm; limite na região em contato {pmax:g} mm. Rever passo, espessura ou arranjo de parafusos.',NBR+', 6.3.10(a)')
    if max((c.bp-c.gauge)/2,rows[0]+c.ext_top,b.d+c.ext_bottom-rows[-1])>min(12*c.tp,150.):
        detail('Distância máxima à borda da chapa excede min(12tp;150 mm).',NBR+', 6.3.12')
    # Parafusos externos não podem interceptar a mesa; internos precisam deixar ferramenta.
    for y in rows:
        if 0<=y<=b.d and not root_b+clearance_weld+c.tool_radius<=y<=b.d-root_b-clearance_weld-c.tool_radius:interference('Linha interna interfere com mesa, concordância, solda ou ferramenta.');break
        if y<0 and -y<c.tool_radius+clearance_weld:interference('Linha superior externa muito próxima da mesa.');break
        if y>b.d and y-b.d<c.tool_radius+clearance_weld:interference('Linha inferior externa muito próxima da mesa.');break
    vertical_edge=min(rows[0]+c.ext_top,b.d+c.ext_bottom-rows[-1])
    if vertical_edge<=c.dh/2:err('Furo superior/inferior fora do material ou sem ligamento livre positivo.')
    elif vertical_edge<edge_min:
        if c.kind=='pinned':detail(f'Borda superior/inferior {vertical_edge:g} mm inferior ao mínimo adotado {edge_min:g} mm; limite do detalhe suportado, sem qualificar a exceção normativa por contato.',NBR+', 6.3.11')
        else:detail(f'Borda superior/inferior {vertical_edge:g} mm inferior ao mínimo adotado {edge_min:g} mm; furo com ligamento físico positivo.',NBR+', 6.3.11')
    elif vertical_edge<c.tool_radius:interference('Envelope de montagem ultrapassa a borda superior/inferior da chapa.')
    if c.kind=='pinned':
        if min(rows)<=b.tf or max(rows)>=b.d-b.tf:err('Na rotulada, as linhas de parafusos devem ficar entre as mesas da viga.')
        if abs(c.M)>1e-9:err('Ligação rotulada recebe somente V e N; remova o momento externo.')
        if c.gauge<=max(b.tw,s.tw):err('Gabarito deve superar a espessura das almas para haver braço e faixa tributária positivos.')
        if not 90<=c.gauge<=140:domain('Gabarito fora de 90 a 140 mm: a classificação rotulada exige avaliação específica.',SCI)
        if sp.fy>275:domain('Chapa com fy > 275 MPa: fora do detalhamento usado para a classificação rotulada.',SCI)
        if c.overhang<c.weld:interference('A sobra superior/inferior deve acomodar o filete.')
        if c.overhang>10:domain('Sobra da rotulada acima de 10 mm: fora do detalhamento adotado; valor usual 5 mm.')
        if (c.n-1)*c.pitch<b.d/2:domain('Grupo da rotulada abrange menos da metade da altura da viga: avaliar a classificação rotulada.')
        for label,t in [('alma–chapa',b.tw),('mesa–chapa',b.tf)]:
            smaller=min(t,c.tp);wmin=fillet_minimum(smaller)
            # The beam end is an exposed edge; the end plate receives this weld on its face.
            wmax=fillet_edge_maximum(t,c.reinforced_edge)
            if c.weld<wmin:detail(f'Filete {label}: w={c.weld:g} mm; mínimo {wmin:g} mm para menor espessura {smaller:g} mm.',NBR+', 6.2.6.2.1/tabela 11')
            if c.weld>wmax+1e-9:detail(f'Filete {label}: w={c.weld:g} mm; máximo {wmax:g} mm na borda efetiva da viga t={t:g} mm (chapa receptora pela face); reforço '+('declarado.' if c.reinforced_edge else 'não declarado.'),NBR+', 6.2.6.2.2')
        if b.clear-2*c.weld<=0:err('Comprimento resistente da solda da alma não positivo após descontar as extremidades.')
    else:
        if sp.fy>345:domain('Chapa com fy > 345 MPa, fora do domínio adotado do DG39.',DG+', 3.7.2')
        for steel,label in ((STEELS[c.beam_steel],'Viga'),(STEELS[c.support_steel],'Coluna')):
            if steel.fy>380:domain(label+' com fy > 380 MPa (limite arredondado de 55 ksi): material fora da faixa avaliada; resistência e rigidez exigem avaliação específica.',DG+', 4.1.3')
        if c.bp<b.bf:
            out.append(Issue('pending',f'VERIFICAÇÃO LOCAL INCOMPLETA: bp={c.bp:g} mm é menor que bf={b.bf:g} mm. A junta CJP das mesas foi calculada apenas na largura fisicamente conectada min(bp;bf); a transferência da mesa mais larga para essa junta parcial exige detalhamento e modelo específicos.',DG+', 3.7.5 e caminho físico da junta mesa–chapa','configuration'))
        if c.fw<max(STEELS[c.beam_steel].fu,sp.fu):err('A solda de penetração total exige metal de adição compatível com os metais-base.')
        if c.gauge>b.bf:domain('Gabarito excede bf da viga: fora do arranjo adotado do modelo '+c.variant+'.',DG+', 3.7.2')
        limits=[('pfi',c.pfi,25.4,63.5),('pfo',c.pfo,25.4,63.5),('extensão',c.ext_top,63.5,190.5),('gabarito',c.gauge,69.85,177.8),('altura da viga',b.d,400.05,1828.8),('largura da chapa',c.bp,127,260.35),('mesa da viga',b.tf,9.525,25.4)]
        for name,val,lo,hi in limits:
            within=(Decimal(str(lo))*Decimal('.9')<=Decimal(str(val))<=Decimal(str(hi))*Decimal('1.1')) if c.is_8es else .9*lo<=val<=1.1*hi
            if not within:domain(f'{name}: {val:g} mm fora do intervalo {lo*.9:g}–{hi*1.1:g} mm, já considerada a tolerância de 10%. Cálculo por extrapolação; resistência e rigidez do arranjo exigem avaliação específica.',DG+', 4.1.2 e 5.3.1/tabela 5-9')
        if c.is_8es:
            if b.tf+c.pfi+c.pb>=b.d-b.tf-c.pfi-c.pb:
                err('As linhas internas 8ES se cruzam ou coincidem; a ordem física não pode ser corrigida por ordenação.')
            if min(c.tension_arms)<=0:err('Todos os quatro braços 8ES devem ser positivos.')
            elif not c.edge<math.sqrt(c.effective_bp*c.gauge)/2:
                err('8ES: de deve ser estritamente menor que s=√(bp,ef g)/2. Não se extrapola a tabela 5-16 em de≥s.',DG+', tabela 5-16',origin='method')
            else:
                yp=yield_8es(c.effective_bp,c.gauge,*c.tension_arms,c.pfo,c.pfi,c.pb,c.edge)
                yc=yield_column_8es(c.effective_bfc,c.gauge,*c.tension_arms,c.pfo+b.tf+c.pfi,c.pb)
                if not all(math.isfinite(v) and v>0 for v in (yp,yc)):err('Parâmetro Yp/Yc 8ES deve ser positivo finito.')
        else:
            if b.tf+c.pfi>=b.d-b.tf-c.pfi:err('As duas linhas internas do grupo base se cruzam ou coincidem; reduza pfi ou reveja a seção.')
            h1=b.d-b.tf/2+c.pfo;h2=b.d-1.5*b.tf-c.pfi
            if min(h1,h2)<=0:err('Braços do mecanismo '+c.variant+' devem ser positivos.')
            elif c.is_4es and not c.edge<math.sqrt(c.effective_bp*c.gauge)/2:
                err('4ES: de deve ser estritamente menor que s=√(bp,ef g)/2. Não se extrapola a tabela 5-11 em de≥s.',DG+', tabela 5-11',origin='method')
            elif min(yield_4es(c.effective_bp,c.gauge,h1,h2,c.pfo,c.pfi,c.edge) if c.is_4es else yield_4e(c.effective_bp,c.gauge,h1,h2,c.pfo,c.pfi),yield_column_4e(c.effective_bfc,c.gauge,h1,h2,c.pfo+b.tf+c.pfi))<=0:err('Parâmetro de plastificação não positivo; equação '+c.variant+' inaplicável.')
        if c.is_stiffened:
            if c.layout!='both' or c.intermediate_n:
                err('4ES inicial exige extensões simétricas, exatamente oito parafusos e duas nervuras centradas; sem linhas intermediárias.',DG+', tabela 5-11',origin='method')
            if c.stiffener_clip>=min(c.ext_top,c.stiffener_length):
                err('Recorte do enrijecedor elimina um comprimento conectado CJP; informar recorte menor que hst e Lst.')
            if not 0<c.stiffener_landing<min(c.ext_top,c.stiffener_length):
                err('Patamares do enrijecedor devem ser positivos e menores que hst e Lst.')
            state=stiffener_state(c)
            if not state['stiffener_materials_qualified']:
                out.append(Issue('pending','4ES CJP admite seleção independente dos aços da viga, chapa e nervuras entre A36/A572 Gr.42/Gr.50. Material fora desta rota finita requer qualificação específica.',NBR+', tabelas 8 e 9; '+DG+', 4.1.3 p.50','method'))
            if not state['stiffener_cjp_compatible']:
                out.append(Issue('pending','4ES requer ambas as juntas de nervura CJP contínuas e compatíveis. Rota E7018 classe 70, fw=485 MPa, para cada aço A36/A572 Gr.42/Gr.50 selecionado independentemente. Procedimento/preparação, baixo hidrogênio e preaquecimento pelo grupo de maior resistência devem atender à tabela 8, nota a. fw isolado não comprova compatibilidade. Filetes não qualificados.',DG+', p.45; '+NBR+', tabelas 8 e 9','method'))
            if not state['stiffener_nohole_rupture_qualified']:
                out.append(Issue('pending','Ruptura sem furos deve satisfazer fu/γa2≥fy/γa1 em cada aço da viga, chapa e nervuras para a hipótese de desenvolvimento CJP; invariante não satisfeita.',NBR+', 6.5 e tabela 9','method'))
            if not c.stiffener_clearance:
                out.append(Issue('pending','Acesso/preparação CJP no recorte não confirmados. Soldar a mesa primeiro e a nervura depois; sem solda através do recorte.',DG+', figura 4-3, pp.52–53','method'))
            if c.gauge/2<=c.stiffener_t/2+c.tool_radius:
                interference('Envelope de ferramenta dos parafusos externos intercepta a nervura centrada.')
            if c.stiffener_landing!=25.4:
                out.append(Issue('info','Patamares informados preservados; cerca de 25,4 mm é recomendação de fabricação do detalhe adotado, não limite NBR obrigatório.',DG+', figura 4-3'))
        if c.intermediate_n:domain('Linhas intermediárias adicionadas apenas para detalhamento, sem crédito resistente. O cálculo utiliza o grupo base 4E e desconta os furos adicionais; o arranjo ampliado exige avaliação específica de contato, tração e alavanca.',DG+', modelo 4E e premissa de implementação')
        if c.layout=='top' and c.M<=0:err('Extensão só acima: este modelo 4E exige M > 0 (tração na mesa superior). Para inversão, escolha extensão acima e abaixo.',origin='method')
        if c.M==0 or abs(c.N)*(b.d-b.tf)>abs(c.M):err('O modelo de engaste '+c.variant+' exige momento dominante: |N|(d−tf) ≤ |M|. Para axial dominante, é necessário outro modelo de distribuição.',DG+', 3.5',origin='method')
        if c.web_tension_length>b.d-2*b.tf+(0. if c.is_8es else 1e-9):
            out.append(Issue('pending',f'VERIFICAÇÃO LOCAL INCOMPLETA: a região de tração da alma lwt={'pfi+pb+152,4' if c.is_8es else 'pfi+152,4'}={c.web_tension_length:g} mm excede a altura física entre mesas {b.d-2*b.tf:g} mm. A resistência local da alma e a distribuição das juntas CJP nessa região exigem modelo específico; as demais contas permanecem disponíveis sem aprovar essa transferência.',DG+', 3.7.5, eq.3-40 e figura 3-17','configuration'))
    if max(abs(c.V),abs(c.N),abs(c.M))==0 or (c.kind=='pinned' and c.V==0 and c.N==0):
        if c.kind=='pinned':err('Informe pelo menos um esforço não nulo; falta direção para a conferência mínima.',origin='data')
        else:err('Informe pelo menos um esforço não nulo.',origin='data')
    if any(i.severity=='interference' for i in out):out.append(Issue('excluded',INTERFERENCE_ASSUMPTION))
    if not c.norm_minimum:out.append(Issue('pending','Conferência normativa mínima desativada: modo de comparação.',NBR+', 6.1.5'))
    if c.is_8es:out=[replace(i,text=i.text.replace('4ES','8ES').replace('exatamente oito parafusos','exatamente 16 parafusos'),reference=i.reference.replace('tabela 5-11','tabela 5-16')) for i in out]
    return out


def _calculate(c,V,N,M,case):
    if c.is_mre12:
        from .end_plate_mre12 import calculate_mre12
        return calculate_mre12(c,V,N,M,case)
    b,s=c.beam,c.support;sp=STEELS[c.plate_steel];sb=STEELS[c.beam_steel];sc=STEELS[c.support_steel]
    rows=[];a={};nb=c.calculation_count;fub=BOLTS[c.bolt];Ab=math.pi*c.db**2/4
    def add(i,name,sd,rd,unit,ref,eq,sub,var):rows.append((PinnedEndPlateCheck if c.kind=='pinned' else EightESEndPlateCheck if c.is_8es else FourESEndPlateCheck if c.is_4es else MomentEndPlateCheck)('ep_'+i,name,sd,rd,unit,ref,eq,sub,var,case))
    nbolts=len(c.rows);shear=abs(V)/nb
    Ft=.75*fub*Ab/G2;Fv=bolt_shear(c.db,fub,c.threads)*grip_factor(c.tp+s.tf,c.db)
    if c.kind=='moment':
        z=b.d-b.tf;Meq=abs(M)+max(N,0)*z/2;h1=b.d-b.tf/2+c.pfo;h2=b.d-1.5*b.tf-c.pfi
        # Equal tension in the active rows, never an elastic h/sum(h²) split.
        if c.is_8es:
            h1,h2,h3,h4=c.tension_arms
            Tb=Meq/(2*sum(c.tension_arms));T=8*Tb;C=T-N
            Yp=yield_8es(c.effective_bp,c.gauge,h1,h2,h3,h4,c.pfo,c.pfi,c.pb,c.edge)
            Yc=yield_column_8es(c.effective_bfc,c.gauge,h1,h2,h3,h4,c.pfo+b.tf+c.pfi,c.pb)
            table='5-16'
        else:
            Tb=Meq/(2*(h1+h2));T=4*Tb;C=T-N
            Yp=yield_4es(c.effective_bp,c.gauge,h1,h2,c.pfo,c.pfi,c.edge) if c.is_4es else yield_4e(c.effective_bp,c.gauge,h1,h2,c.pfo,c.pfi)
            table='5-11' if c.is_4es else '5-10'
            Yc=yield_column_4e(c.effective_bfc,c.gauge,h1,h2,c.pfo+b.tf+c.pfi)
        tp_req=thick_required(Meq,sp.fy,Yp);tc_req=thick_required(Meq,sc.fy,Yc)
        add('plate_rigidity','Chapa — espessura para chapa espessa e critério FR',tp_req,c.tp,'mm',DG+', 3.2, 5.1.1 eq.5-4 e tabela '+table,'tp,req = √[1,10 Meq max(γa1;1/0,90)/(fy Yp)]',f'Meq={Meq:.3f}; Yp={Yp:.6f}; fy={sp.fy:g}; tp,req={tp_req:.4f}', 'Meq: momento equivalente; Yp: parâmetro de linhas de plastificação; γr=1. Chapa espessa evita alavanca no domínio do guia.')
        add('column_rigidity','Coluna — espessura da mesa sem alavanca',tc_req,s.tf,'mm',DG+', 3.7.6 eq.3-44, 4.2.2 eq.4-3 e 5.1.1','tf,req = √[1,10 Meq max(γa1;1/0,90)/(fyc Yc)]',f'bfc={s.bf:g}; bfc,ef={c.effective_bfc:g}; Yc={Yc:.6f}; fyc={sc.fy:g}; tf,req={tc_req:.4f}', 'Coluna contínua sem enrijecedores; parâmetro Yc com o mesmo grupo '+c.variant+' e bfc,ef=min(bfc;bf+max(tp;25,4)). Não se ignora a deformação da mesa da coluna.')
        add('plate_yield','Chapa — linhas de plastificação',Meq,sp.fy*c.tp**2*Yp/G1,'Nmm',DG+', tabela '+table+'; '+NBR+', γa1','MRd=fy tp² Yp/γa1',f'Yp={Yp:.6f}; tp={c.tp:g}; MRd={sp.fy*c.tp**2*Yp/G1:.3f}','Resistência nominal do mecanismo '+c.variant+'; mínimo de chapa espessa verificado separadamente.')
        # Local force transfer is based on the beam flange force (DG39 3-39),
        # NOT on V or on the separately calculated bolt resultant T=4*Tb.
        Ff=abs(M)/z+max(N,0)/2
        Flocal=Ff/2; lwt=c.web_tension_length; hw=b.d-2*b.tf
        Agv=c.bp*c.tp;Anv=max(0.,c.bp-2*c.dn)*c.tp
        local_vars='Ff: força da mesa tracionada, sem alívio por compressão axial; dois dos quatro parafusos tracionados do grupo base 4E. V atua em outro caminho. Extensão ativa '+('superior' if M>0 else 'inferior')+'.'
        if not c.is_stiffened:
            add('extension_shear_yield','Extensão da chapa — escoamento por cisalhamento de Ff/2',Flocal,.6*sp.fy*Agv/G1,'N',DG+', exemplo 5.3-1, pp.125–126; '+NBR+', 6.5.5(a)','VSd=Ff/2; Ff=|M|/(d−tf)+max(N;0)/2; VRd=0,6 fy bp tp/γa1',f'Ff={Ff:.6f}; VSd={Flocal:.6f}; Agv=bp tp={Agv:.6f}; VRd={.6*sp.fy*Agv/G1:.6f}',local_vars+' Largura física da chapa; sem nervuras.')
        if not c.is_stiffened:
            add('extension_shear_rupture','Extensão da chapa — ruptura por cisalhamento de Ff/2',Flocal,.6*sp.fu*Anv/G2,'N',DG+', exemplo 5.3-1, pp.125–126; '+NBR+', 6.5.5(b)','VSd=Ff/2; Anv=(bp−2dn)tp; VRd=0,6 fu Anv/γa2',f'Ff={Ff:.6f}; VSd={Flocal:.6f}; dn={c.dn:.6f}; Anv={Anv:.6f}; VRd={.6*sp.fu*Anv/G2:.6f}',local_vars+' Dois furos na seção líquida transversal; dn segue a dedução NBR do projeto. Não se importa a dedução AISC de 1/16 pol.')
        if lwt<=hw+(0. if c.is_8es else 1e-9):
            Rwt=sb.fy*b.tw*lwt/G1
            add('beam_web_local_tension','Alma da viga — escoamento local à tração de Ff/2',Flocal,Rwt,'N',DG+', 3.7.5 eq.3-39/3-40 e exemplo p.129; '+NBR+', 6.5.1 e 6.5.3(a)','Tw,Sd=(2/4)Ff; lwt=pfi+152,4; Tw,Rd=fyb tw lwt/γa1',f'Ff={Ff:.6f}; Tw,Sd={Flocal:.6f}; lwt={lwt:.6f}; tw={b.tw:g}; Ag={b.tw*lwt:.6f}; Tw,Rd={Rwt:.6f}','Faixa de alma sem furos, desde a face interna da mesa tracionada até 152,4 mm além da linha interna. Sem crédito às mesas ou a enrijecedores. Verificação adicional à tensão elástica global e ao cisalhamento vertical.')
        # The compatible CJP welds develop the weaker connected material over
        # real, disjoint DG39 local tension/shear zones (NBR Table 9).
        fy_joint=min(sb.fy,sp.fy);te=min(b.tf,c.tp);we=min(b.tw,c.tp)
        Fc=abs(M)/z+max(-N,0)/2
        Fflange=max(Ff,Fc,.60*sb.fy*b.bf*b.tf)
        flange_width=min(b.bf,c.bp)
        Rflange=fy_joint*flange_width*te/G1
        add('weld_cjp_flange_local','Junta CJP das mesas — transferência local e mínimo de desenvolvimento',Fflange,Rflange,'N',DG+', 3.7.5 eq.3-38/3-39; '+NBR+', 6.2.5.1/tabela 9','Ff=|M|/(d−tf)+max(N;0)/2; Fc=|M|/(d−tf)+max(−N;0)/2; FSd=max(Ff;Fc;0,60 fyb bf tf); FRd=min(fyb;fyp) min(bf;bp) min(tf;tp)/γa1',f'Ff={Ff:.6f}; Fc={Fc:.6f}; mínimo={.60*sb.fy*b.bf*b.tf:.6f}; FSd={Fflange:.6f}; largura ligada={flange_width:g}; te={te:g}; FRd={Rflange:.6f}','Mínimo de 60% é critério complementar DG39 para desenvolvimento da junta, sem importar fatores LRFD para a resistência NBR. Envelope das duas mesas, incluindo compressão axial sem redução da tração. Compatibilidade total do metal de adição; produto dos menores fy e espessura é conservador.')
        lws=max(0.,min(hw-lwt,hw/2))
        if lwt<=hw+(0. if c.is_8es else 1e-9):
            Fweb=max(Flocal,.60*sb.fy*b.tw*lwt);Rweb=fy_joint*we*lwt/G1
            add('weld_cjp_web_local','Junta CJP da alma — tração local junto aos parafusos',Fweb,Rweb,'N',DG+', 3.7.5 eq.3-40/3-41, p.129; '+NBR+', 6.2.5.1/tabela 9','FSd=max(Ff/2;0,60 fyb tw lwt); FRd=min(fyb;fyp) min(tw;tp) lwt/γa1',f'Ff/2={Flocal:.6f}; mínimo={.60*sb.fy*b.tw*lwt:.6f}; FSd={Fweb:.6f}; lwt={lwt:.6f}; we={we:g}; FRd={Rweb:.6f}','Região junto à mesa tracionada, invertida com o sinal de M; não se distribui essa força por toda a altura da alma. Resistência do metal-base mais fraco da junta CJP compatível; distinta do escoamento da alma da viga isolada.')
            if lws>0 or abs(V)>0:
                Rwsv=.6*fy_joint*we*lws/G1
                add('weld_cjp_web_shear','Junta CJP da alma — cisalhamento na região disponível',abs(V),Rwsv,'N',DG+', 3.7.5 p.45, figura 3-17; '+NBR+', 6.2.5.1/tabela 9','lws=min(d−2tf−lwt;(d−2tf)/2); VRd=0,6 min(fyb;fyp) min(tw;tp) lws/γa1',f'lwt={lwt:.6f}; hw={hw:.6f}; lws={lws:.6f}; VSd={abs(V):.6f}; VRd={Rwsv:.6f}','Todo o cortante V é atribuído ao trecho da junta fora da região ativa de tração, no lado comprimido e limitado à metade da altura livre. Sem sobreposição de áreas resistentes ou crédito aos filetes/mesas.')
        a.update(web_shear_weld_length=lws,flange_cjp_width=flange_width,flange_compression_force=Fc,effective_bfc=c.effective_bfc)
        a.update(flange_transfer_force=Ff,local_transfer_force=Flocal,web_tension_length=lwt,web_physical_height=hw,web_tension_region_fits=lwt<=hw+(0. if c.is_8es else 1e-9),extension_gross_shear_area=Agv,extension_net_shear_area=Anv,tension_side='top' if M>0 else 'bottom')
        # Elastic end section for weld/base. No local beam holes in this connection.
        te=min(b.tf,c.tp);we=min(b.tw,c.tp);hw=b.d-2*b.tf
        A=2*b.bf*te+hw*we;I=2*(b.bf*te**3/12+b.bf*te*(b.d/2-b.tf/2)**2)+we*hw**3/12;W=I/(b.d/2)
        sigma=abs(N)/A+abs(M)/W;tau=abs(V)/(we*hw);equiv=math.hypot(sigma,math.sqrt(3)*tau)
        add('weld_cjp','Viga e juntas de penetração total — tensão equivalente',equiv,min(sb.fy,sp.fy)/G1,'MPa',NBR+', 6.2.5/tabela 9 e 6.5','σeq=√[(|N|/A+|M|/W)²+3(V/Aw)²]',f'A={A:.3f}; W={W:.3f}; Aw={we*hw:.3f}; σeq={equiv:.4f}', 'Critério elástico conservador, combinando máximos de tensões. Gargantas limitadas a min(tp;tf) nas mesas e min(tp;tw) na alma. Juntas CJP em ambas as mesas e alma, metal de adição compatível.')
        flange_lambda=(b.bf-b.tw)/(2*b.tf);web_lambda=b.clear/b.tw
        add('compact_flange','Viga — mesa compacta no nó',flange_lambda,.38*math.sqrt(E/sb.fy),'—',NBR+', 5.4 e anexo D','(bf−tw)/(2tf) ≤ 0,38√(E/fy)',f'λ={flange_lambda:.4f}; fy={sb.fy:g}', 'Restrição conservadora do modelo à seção compacta; não substitui o dimensionamento global da viga.')
        add('compact_web','Viga — alma compacta no nó',web_lambda,3.76*math.sqrt(E/sb.fy),'—',NBR+', 5.4 e anexo D','h/tw ≤ 3,76√(E/fy)',f'λ={web_lambda:.4f}; fy={sb.fy:g}', 'Limite conservador para a flexão; esforço axial dominante é excluído pelo domínio do DG39.')
        a.update(Meq=Meq,Yp=Yp,Yc=Yc,tp_required=tp_req,column_tf_required=tc_req,h1=h1,h2=h2,z=z)
        if c.is_stiffened:
            state=stiffener_state(c);a.update(state)
            a.pop('extension_gross_shear_area',None);a.pop('extension_net_shear_area',None)
            a.update(variant=c.variant,plate_table=table,column_table='A-5(a)' if c.is_8es else 'A-2',plate_s=math.sqrt(c.effective_bp*c.gauge)/2)
            ss=STEELS[c.stiffener_steel]
            ref=DG+', eq.3-36, pp.43,45,50 e figura 4-3; '+NBR+', 6.2.5.1, tabelas 8 e 9'
            add('stiffener_thickness','Nervuras — espessura para o caminho '+c.variant,state['stiffener_t_required'],c.stiffener_t,'mm',ref,'ts,req=tw fyb/fys',f'tw={b.tw:g}; fyb={sb.fy:g}; fys={ss.fy:g}; ts,req={state["stiffener_t_required"]:.9f}; ts={c.stiffener_t:g}','Duas nervuras físicas iguais. Condição do caminho de forças DG39; não é a esbeltez sísmica da eq.3-37.')
            add('stiffener_length','Nervuras — comprimento do detalhe adotado',state['stiffener_length_required'],c.stiffener_length,'mm',ref,'Lst,req=hst/tan30°; hst='+('pfo+pb+de' if c.is_8es else 'pfo+de'),f'hst={c.ext_top:g}; Lst,req={state["stiffener_length_required"]:.9f}; Lst={c.stiffener_length:g}','Detalhe fonte adotado de 30 graus, distinto de limite obrigatório NBR. Patamares e recorte preservados no desenho.')
            add('stiffener_receiver','Nervuras CJP — hierarquia das espessuras receptoras',c.stiffener_t,min(c.tp,b.tf),'mm',ref,'ts≤min(tp;tf)',f'ts={c.stiffener_t:g}; tp={c.tp:g}; tf={b.tf:g}; fys={ss.fy:g}; fyp={sp.fy:g}; fyb={sb.fy:g}','Condição necessária já implicada pelo desenvolvimento CJP integral nas duas interfaces. Não basta com aços diferentes: cada junta usa separadamente o menor fy e a menor espessura, nas verificações seguintes. Não representa continuidade na coluna.')
            for interface,label,run,target,capacity,equation in [
                ('plate','chapa',state['stiffener_plate_run'],state['stiffener_qt'],state['stiffener_plate_qrd'],'qdev=fys ts/γa1; qRd=min(fys;fyp) min(ts;tp)/γa1'),
                ('flange','mesa',state['stiffener_flange_run'],state['stiffener_qv'],state['stiffener_flange_qrd'],'qdev=0,60 fys ts/γa1; qRd=0,60 min(fys;fyb) min(ts;tf)/γa1')]:
                add('stiffener_cjp_'+interface,'CJP nervura–'+label+' — desenvolvimento por comprimento real',target,capacity,'N/mm',ref,equation,f'fys={ss.fy:g}; fy receptor={sp.fy if interface=="plate" else sb.fy:g}; ts={c.stiffener_t:g}; t receptor={c.tp if interface=="plate" else b.tf:g}; Lconectado={run:.9f}; qdev={target:.9f}; qRd={capacity:.9f}; desenvolvimento total={target*run:.9f} N; capacidade total={capacity*run:.9f} N','Condição de desenvolvimento no mesmo nível NBR de resistência de cálculo, sem comparar força nominal à própria resistência reduzida. Junta CJP contínua compatível e sem furos; comprimento termina no recorte real. Não se aplica regra de comprimento de filetes ou fator direcional AISC.')
            # Every entered 4ES prerequisite conditions the plate mechanism and
            # no-prying assertion, even if both numerical thicknesses pass.
            source_ok=state['stiffener_qualified'] and not any(i.severity in ('error','pending','extrapolation','noncompliance') for i in validate(c))
            rows=[replace(x,source_qualified=source_ok) if x.id in ('ep_plate_rigidity','ep_plate_yield','ep_stiffener_thickness','ep_stiffener_length','ep_stiffener_receiver','ep_stiffener_cjp_plate','ep_stiffener_cjp_flange') else x for x in rows]
            rows=[replace(x,reference=x.reference+'; tabela A-2 (4E/4ES)') if x.id=='ep_column_rigidity' else x for x in rows]
            rows=[replace(x,reference=x.reference.replace('exemplo p.129','exemplo 5.3-2, pp.144–145').replace('p.129','pp.144–145')) if x.id in ('ep_beam_web_local_tension','ep_weld_cjp_web_local') else x for x in rows]
            if c.is_8es:
                active=c.primary_rows[:4] if M>0 else list(reversed(c.primary_rows[4:]))
                pivot=b.d-b.tf/2 if M>0 else b.tf/2
                a.update(h3=h3,h4=h4,arms=c.tension_arms,active_rows=active,active_bolt_count=8,
                    compression_pivot=pivot,active_arms=[abs(pivot-y) for y in active],pb=c.pb,
                    column_s=math.sqrt(c.effective_bfc*c.gauge)/2,column_c=c.pfo+b.tf+c.pfi,
                    plate_pfi_effective=min(c.pfi,a['plate_s']),plate_pfo_effective=min(c.pfo,a['plate_s']),source_ranges=source_domain_8es(c))
                a['bolts']=[dict(x=x,y=y,tension=Tb if y in active else 0.,shear=shear,active_tension=y in active) for y in c.rows for x in (-c.gauge/2,c.gauge/2)]
                a['plate_kernel']='Yp=bp,ef/2[h1/(2de)+h2/po+h3/pi+h4/sP]+2/g[h1(de+3pb/4)+h2(po+pb/4)+h3(pi+3pb/4)+h4(sP+pb/4)]+g'
                a['column_kernel']='Yc=bcf,ef/2(h1/sC+h4/sC)+2/g[h1(pb+c/2+sC)+h2(pb/2+c/4)+h3(pb/2+c/2)+h4 sC]+g/2'
                source_sub=f'h1={h1:.12g}; h2={h2:.12g}; h3={h3:.12g}; h4={h4:.12g}; pb={c.pb:.12g}; de={c.edge:.12g}; po={a["plate_pfo_effective"]:.12g}; pi={a["plate_pfi_effective"]:.12g}; sP={a["plate_s"]:.12g}; sC={a["column_s"]:.12g}; c={a["column_c"]:.12g}; bp,ef={c.effective_bp:.12g}; bcf,ef={c.effective_bfc:.12g}'
                rows=[replace(x,substitution=x.substitution+'; '+source_sub,variables=x.variables+' '+a['plate_kernel' if x.id!='ep_column_rigidity' else 'column_kernel']) if x.id in ('ep_plate_rigidity','ep_plate_yield','ep_column_rigidity') else x for x in rows]
                rows=[replace(x,reference=DG+', tabela A-5(a), pp.269–270; eq.4-3; condição de chapa espessa p.49') if x.id=='ep_column_rigidity' else x for x in rows]
                rows=[replace(x,reference=x.reference.replace('exemplo 5.3-2, pp.144–145','exemplo 5.3-7, pp.186–187').replace('pp.144–145','exemplo 5.3-7, pp.186–187'),
                    equation=x.equation.replace('(2/4)Ff','(4/8)Ff').replace('lwt=pfi+152,4','lwt=pfi+pb+152,4'),
                    variables=x.variables.replace('linha interna','segunda linha interna')) if x.id in ('ep_beam_web_local_tension','ep_weld_cjp_web_local') else x for x in rows]
                rows=[replace(x,reference=x.reference+'; '+DG+', exemplo 5.3-7, p.185') if x.id.startswith('ep_stiffener_') else x for x in rows]


    else:
        Tb=max(N,0)/nb;T=max(N,0);C=max(-N,0);z=b.d-b.tf
        # Uniform pure axial load, no external moment in a nominally pinned joint.
        for key,t,fu,tw,lo,hi,label in [('plate',c.tp,sp.fu,b.tw,-c.ext_top,b.d+c.ext_bottom,'Chapa'),('column',s.tf,sc.fu,s.tw,-c.ext_top,b.d+c.ext_bottom,'Mesa da coluna')]:
            arm=(c.gauge-tw)/2;ps=tributaries(c.rows,lo,hi,arm);pmin=min(ps)
            tr=rigid_strip(Tb,arm,pmin,fu,c.db)
            add(key+'_prying',label+' — espessura para alavanca nula',tr,t,'mm',NBR+', 6.3.5.2 e 6.3.5.3','tmin=√[4(b−db/2) Ft,0,Sd γa1/(p fu)]',f'b={arm:.4f}; p={pmin:.4f}; Ft,0,Sd={Tb:.3f}; fu={fu:g}; tmin={tr:.4f}', 'b: eixo do parafuso à face da alma; p: menor largura tributária limitada pela NBR. Usa-se o menor p para todas as linhas, sem alavanca omitida se o requisito falhar.')
            if key=='plate':a['tp_required']=tr
            else:a['column_tf_required']=tr
        limit=10. if b.d<=457 else 12.
        add('rotation','Rótula — limite construtivo de espessura',c.tp,limit,'mm',SCI,'tp ≤ 10 mm (d ≤ 457 mm); tp ≤ 12 mm (d > 457 mm)',f'tp={c.tp:g}; d={b.d:g}; limite={limit:g}', 'Limite conservador de detalhamento para chapa com fy ≤ 275 MPa. Não é resistência sob a carga nem mola rotacional calculada.')
        add('ductility','Rótula — critério complementar de ductilidade em amarração',c.tp,c.db/1.9*math.sqrt(fub/sp.fy),'mm',SCI+', nota 4','tp ≤ (db/1,9)√(fub/fy)',f'db={c.db:g}; fub={fub:g}; fy={sp.fy:g}', 'Critério de ductilidade da distribuição plástica em amarração na fonte SCI, conservado como condição complementar do detalhe. Não qualifica por si a capacidade de rotação nem o mecanismo ordinário N/V.')
        L=max(b.clear-2*c.weld,0);a_w=2*c.weld/math.sqrt(2)*L;load=math.hypot(V,N)
        add('weld_fillet','Soldas alma–chapa — resultante V e N',load,.6*c.fw*a_w/G2,'N',NBR+', 6.2.5','FRd=0,6 fw · 2(w/√2)L/γw2',f'L={L:.3f}; w={c.weld:g}; Aw={a_w:.3f}; R={load:.3f}', 'Dois filetes na alma, descontadas extremidades. Filetes nas mesas são exigidos no detalhe mas não recebem crédito na resistência à resultante.')
        Rbase=L*min(b.tw*sb.fy,c.tp*sp.fy)*.6/G1
        add('base_weld','Metal-base junto à solda da alma',load,Rbase,'N',NBR+', 6.5.5','FRd=0,6 L min(tw fyb;tp fyp)/γa1',f'L={L:.3f}; tw={b.tw:g}; tp={c.tp:g}; FRd={Rbase:.3f}', 'Verificação conservadora da resultante por resistência ao cisalhamento; uma faixa conectada da alma e uma da chapa.')
    a.update(V=V,N=N,M=M,bolt_tension=Tb,bolt_shear=shear,T=T,C=max(C,0),calculation_nb=nb,detail_nb=c.count,effective_bp=c.effective_bp)
    add('bolt_shear','Parafusos — cisalhamento',shear,Fv,'N',NBR+', 6.3.3.2','Fv,Rd=kpega α Ab fub/γa2',f'Ab={Ab:.4f}; α={.45 if c.threads else .56}; Fv,Sd={shear:.3f}; Fv,Rd={Fv:.3f}','Um plano de corte. α=0,45 com rosca; 0,56 sem rosca. V distribuído aos parafusos do grupo base, inclusive aos tracionados; linhas intermediárias sem crédito resistente.')
    add('bolt_tension','Parafusos — tração',Tb,Ft,'N',NBR+', 6.3.3.1','Ft,Rd=0,75 Ab fub/γa2',f'Ft,Sd={Tb:.3f}; Ft,Rd={Ft:.3f}','Força por parafuso sem alavanca; válida quando chapa e mesa da coluna atendem às espessuras requeridas.')
    if c.kind=='pinned':
        xt=Tb/Ft if Ft>0 else math.inf; xv=shear/Fv if Fv>0 else math.inf
        eta=xt*xt+xv*xv
    else:eta=(Tb/Ft)**2+(shear/Fv)**2
    add('bolt_interaction','Parafusos — interação tração e cisalhamento',eta,1.,'—',NBR+', 6.3.3.4','η=(Ft,Sd/Ft,Rd)²+(Fv,Sd/Fv,Rd)² ≤ 1',f'η=({Tb:.3f}/{Ft:.3f})²+({shear:.3f}/{Fv:.3f})²={eta:.6f}','Combinação elíptica da NBR vigente. Não se soma N diretamente ao cisalhamento do parafuso.')
    ys=c.rows
    for key,t,fu,fy,width,edge_y,label in [('plate',c.tp,sp.fu,sp.fy,c.bp,min(ys[0]+c.ext_top,b.d+c.ext_bottom-ys[-1]),'Chapa'),('column',s.tf,sc.fu,sc.fy,s.bf,None,'Mesa da coluna')]:
        distances=[y2-y1-c.dh for y1,y2 in zip(ys,ys[1:])]
        if edge_y is not None:distances.append(edge_y-c.dh/2)
        lc=min(distances);Rb=min(1.2*lc*t*fu,2.4*c.db*t*fu)/G2
        add('bearing_'+key,label+' — contato nos furos',shear,Rb,'N',NBR+', 6.3.3.3','Fc,Rd=min(1,2 lc t fu;2,4 db t fu)/γa2',f'lc={lc:.4f}; t={t:g}; Fc,Rd={Rb:.3f}', 'Menor ligamento livre aplicado conservadoramente a todos os furos. Coluna contínua sem borda longitudinal próxima.')
        if key=='plate':
            # Both side strips, all subsets ending at the free upper/lower edge.
            capacities=[];block_records=[]
            for ordered,primary,start in [(ys,c.primary_rows,-c.ext_top),([-y for y in reversed(ys)],[-y for y in reversed(c.primary_rows)],-(b.d+c.ext_bottom))]:
                for j,y in enumerate(ordered,1):
                    lv=y-start;Agv=lv*t;Anv=max(0,lv-(j-.5)*c.dn)*t;Ant=max(0,(width-c.gauge-c.dn)/2)*t
                    rr=2*min(.6*fu*Anv+.5*fu*Ant,.6*fy*Agv+.5*fu*Ant)/G2
                    loaded=sum(p<=y+1e-8 for p in primary)
                    if loaded:
                        capacities.append((rr*nb/(2*loaded),lv,j,rr,loaded))
                        if c.is_8es:block_records.append(dict(edge='top' if start==-c.ext_top else 'bottom',hole_rows=j,loaded_rows=loaded,lv=lv,Agv=Agv,Anv=Anv,Ant=Ant,resistance=rr,demand=2*loaded*shear,equivalent_V_resistance=rr*nb/(2*loaded)))
            if c.is_8es:a['plate_blocks']=block_records
            Rc,lv,j,rr,loaded=min(capacities)
            add('block_plate','Chapa — rasgamento de blocos parciais e completos',abs(V),Rc,'N',NBR+', 6.5.6','Rbloco=2 min(0,6 fu Anv+0,5 fu Ant;0,6 fy Agv+0,5 fu Ant)/γa2',f'Bloco com {j} linhas de furos e {loaded} linhas do grupo base por lado; lv={lv:.3f}; Rbloco={rr:.3f}; resistência equivalente ao V total={Rc:.3f}', 'São percorridos os blocos que terminam nas bordas superior e inferior. Demanda proporcional aos parafusos do grupo base contidos no bloco; todos os furos são deduzidos, inclusive os intermediários sem crédito resistente. Ct=0,5 conservador.')
    Rv,cv=web_shear(b.clear,b.tw,sb.fy)
    add('beam_web','Viga — cisalhamento da alma',abs(V),Rv,'N',NBR+', 5.4.3','VRd=0,6 fy h tw Cv/γa1',f'h={b.clear:g}; tw={b.tw:g}; Cv={cv:.5f}; VRd={Rv:.3f}', 'Alma sem furos na ligação de topo; sem ganho por enrijecedores.')
    if c.kind=='pinned':
        # Axial is deliberately assigned to the connected web strip.
        sigma=abs(N)/(b.clear*b.tw);tau=1.5*abs(V)/(b.clear*b.tw)
        add('beam_nv','Alma da viga — interação local N e V',math.hypot(sigma,math.sqrt(3)*tau),sb.fy/G1,'MPa',NBR+', 6.5; modelo elástico','σeq=√[(N/Aw)²+3(1,5V/Aw)²]',f'Aw={b.clear*b.tw:.3f}; σ={sigma:.4f}; τ={tau:.4f}', 'Conservador: sem crédito às mesas para o esforço axial. Compressão global da viga é externa ao modelo local.')
    # MOMENT column-web demands follow the beam flange forces (DG39 3.5/3.7.6),
    # including legacy 4E. Bolt/contact resultants T/C remain separate below.
    fc=max(Ff,Fc) if c.kind=='moment' else max(max(C,0),max(N,0))
    crippling_force=Fc if c.kind=='moment' else max(C,0)
    ln=0. if c.kind=='moment' else b.clear
    Ry=1.10*(2.5*s.tf+ln)*sc.fy*s.tw/G1
    add('column_web_yield','Coluna — escoamento local da alma',fc,Ry,'N',NBR+', 5.7.3.2(b)','FRd=1,10(2,5k+ln) fyc twc/γa1',f'k=tf={s.tf:g}; ln={ln:g}; FRd={Ry:.3f}; F={fc:.3f}', 'Sem crédito ao raio e ao espalhamento da força nas ligações com momento; caso de extremidade conservador.')
    add('column_crippling','Coluna — enrugamento da alma sob compressão',crippling_force,crippling_point(s.tw,s.tf,sc.fy),'N',NBR+', 5.7.4.2(b)','FRd=0,33 twc² √(E fyc tfc/twc)/γa1',f'twc={s.tw:g}; tfc={s.tf:g}; '+(f'Fc={Fc:.3f}' if c.kind=='moment' else f'C={max(C,0):.3f}'), 'Resistência mínima, sem crédito ao comprimento carregado ou à posição interna da carga.')
    Rc=min(sp.fy,sc.fy)/G1*b.bf*b.tf
    contact_sub=f'Acontato=bf tf={b.bf*b.tf:.3f}; CRd={Rc:.3f}'
    if c.kind=='moment':contact_sub=f'T={8 if c.is_8es else 4}Tb={T:.9f}; N={N:.9f}; C=max(T−N;0)={max(C,0):.9f}; '+contact_sub
    add('contact','Chapa e coluna — compressão local de contato',max(C,0),Rc,'N',NBR+', 6.5; equilíbrio local','CRd=min(fyp;fyc) bf tf/γa1',contact_sub, 'Contato considerado somente sobre a área de uma mesa da viga, conservador para a rotulada em compressão; placa em contato com a coluna.')
    if c.kind=='moment':
        # Pure panel shear is a lower-bound contribution; its boundary conditions
        # and absence of significant column axial compression remain explicit.
        Rp,cp=web_shear(s.clear,s.tw,sc.fy)
        demand=abs(M)/(b.d-b.tf)+abs(N)/2
        add('panel','Coluna — cisalhamento do painel da alma',demand,Rp,'N',NBR+', 5.4.3 e 5.7.7; parcela conservadora da alma','Vp=|M|/(d−tf)+|N|/2; VRd=0,6 fyc hc twc Cv/γa1',f'Vp={demand:.3f}; hc={s.clear:g}; Cv={cp:.5f}; VRd={Rp:.3f}', 'Sem ganho das mesas da coluna nem dedução do cortante favorável da coluna; hipótese de Ncol,Sd ≤ 0,4 Ag,col fy,col declarada nas premissas.')
    if c.kind=='pinned' and any(x.id in ('ep_plate_prying','ep_column_prying') and not x.passed for x in rows):
        rows=[PinnedNoPryingUnqualifiedCheck(**asdict(x)) if x.id in ('ep_bolt_tension','ep_bolt_interaction') else x for x in rows]
    if c.kind=='moment':
        qualified=all(x.numerically_valid and (x.demand<=x.resistance if c.is_8es else x.passed) for x in rows if x.id in ('ep_plate_rigidity','ep_column_rigidity'))
        if c.is_stiffened:
            qualified=qualified and source_ok
            rows=[replace(x,source_qualified=source_ok) if x.id in ('ep_bolt_tension','ep_bolt_interaction') else x for x in rows]
            rows=[replace(x,reference=x.reference+'; '+DG+', eq.3-39/3-48',variables=x.variables+' Demanda de mesa Ff/Fc, distinta de T dos parafusos e C do contato; sem crédito a reforço da coluna.') if x.id in ('ep_column_web_yield','ep_column_crippling') else x for x in rows]
            a.update(column_web_yield_force=fc,column_crippling_force=crippling_force)
        else:
            column_ref=DG+', 3.5 p.37; 3.7.6 eq.3-48; exemplo 5.3-1 p.132'
            column_vars=' Demanda de mesa Ff/Fc, distinta de T dos parafusos e C do contato; sem crédito a reforço da coluna.'
            force_sub=f'Ff={Ff:.9f}; Fc={Fc:.9f}; '
            rows=[replace(x,reference=x.reference+'; '+column_ref,
                          equation=('FSd=max(Ff;Fc); ' if x.id=='ep_column_web_yield' else 'FSd=Fc; ')+x.equation,
                          substitution=force_sub+x.substitution,variables=x.variables+column_vars)
                  if x.id in ('ep_column_web_yield','ep_column_crippling') else x for x in rows]
            a.update(column_web_yield_force=fc,column_crippling_force=crippling_force)
        rows=[replace(x,no_prying_qualified=qualified) if x.id in ('ep_bolt_tension','ep_bolt_interaction') else x for x in rows]
    if c.is_8es:
        rows=[replace(x,variables=x.variables.replace('grupo base','grupo físico 8ES').replace('linhas intermediárias sem crédito resistente','oito linhas primárias, sem linhas intermediárias').replace('inclusive os intermediários sem crédito resistente','oito linhas primárias, sem linhas intermediárias')) if x.id in ('ep_bolt_shear','ep_block_plate') else x for x in rows]
    return rows,a


def connection_inputs(c):
    data=asdict(c)
    if not c.detail_ribs and c.detail_rib_auto_t and c.detail_rib_t==9.525 and c.detail_rib_length==150.:
        for key in DETAIL_FIELDS:data.pop(key,None)
    if not c.is_8es and not c.is_mre12:data.pop('pb',None) # Preserve every delivered legacy input identity.
    if not c.is_mre12:
        data.pop('cjp_electrode',None);data.pop('cjp_compatible',None)
    return data


def input_digest(c):
    return hashlib.sha256(json.dumps(connection_inputs(c),ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def moment_snapshot(c,r):
    from .end_plate_presentation import result_indices
    def safe(v):
        if isinstance(v,float) and not math.isfinite(v):return None
        if isinstance(v,dict):return {k:safe(x) for k,x in v.items()}
        if isinstance(v,(tuple,list)):return [safe(x) for x in v]
        return v
    def row(x):
        return dict(asdict(x),ratio=x.ratio,passed=x.passed,category=x.category,outcome=x.outcome,applicable=x.applicable,numerically_valid=x.numerically_valid)
    cases=[dict(v,checks=[row(x) for x in v['checks']]) for v in r.case_records]
    return safe({'method_revision':method_revision(c),'input_sha256':input_digest(c),
        'status':r.status,'approved':r.status=='ATENDE ÀS VERIFICAÇÕES REALIZADAS',
        'complete_within_declared_scope':bool(r.checks) and not r.numeric_failures and (not c.is_stiffened or all(getattr(x,'source_qualified',True) for x in r.checks)) and not any(i.severity in ('error','pending','extrapolation') for i in r.issues),
        'max_ratio':max((x.ratio for x in r.checks),default=0.),'minimum_factor':r.minimum_factor,
        'result_indices':result_indices(r),
        'actual_checks':[row(x) for x in r.actual],'minimum_checks':[row(x) for x in r.minimum],
        'cases':cases,'checks':[row(x) for x in r.checks],'governing_envelope':[row(x) for x in r.checks],
        'summary_checks':[row(x) for x in r.summary_checks],'coverage_note':r.coverage_note,
        'issues':[asdict(i) for i in r.issues],'geometry':r.geometry,
        'notice':'Retrato auditável recalculado das entradas: casos completos e envoltória por mecanismo, com fonte e substituição do caso governante. Resultados importados não concedem aprovação.'})


def verification_snapshot(c):
    from .end_plate_presentation import result_indices
    r=evaluate(c)
    if c.kind=='moment':return moment_snapshot(c,r)
    def finite(v):return v if math.isfinite(v) else None
    snapshot={'method_revision':method_revision(c),'input_sha256':input_digest(c),
        'status':r.status,'complete_within_declared_scope':bool(r.checks) and not any(i.severity in ('error','pending','extrapolation') or (c.kind=='pinned' and i.origin=='local_scope') for i in r.issues),
        'approved':r.status=='ATENDE ÀS VERIFICAÇÕES REALIZADAS','max_ratio':finite(max((x.ratio for x in r.checks),default=0.)),
        'result_indices':result_indices(r),
        'checks':[dict(asdict(x),ratio=finite(x.ratio),passed=x.passed) for x in r.checks],
        'issues':[asdict(i) for i in r.issues],'geometry':r.geometry,
        'notice':'Retrato auditável vinculado às entradas. Ao abrir o projeto, todas as verificações são recalculadas; resultados importados não concedem aprovação.'}
    if c.kind=='pinned':
        snapshot.update(coverage_note=r.coverage_note,summary_checks=[dict(asdict(x),ratio=finite(x.ratio),passed=x.passed,category=x.category,outcome=x.outcome,applicable=x.applicable) for x in r.summary_checks])
        for row,x in zip(snapshot['checks'],r.checks):row.update(category=x.category,outcome=x.outcome,applicable=x.applicable)
    if c.kind=='pinned':
        def safe(value):
            if isinstance(value,float) and not math.isfinite(value):return None
            if isinstance(value,dict):return {k:safe(v) for k,v in value.items()}
            if isinstance(value,list):return [safe(v) for v in value]
            return value
        snapshot=safe(snapshot)
    return snapshot


def evaluate(c):
    if c.kind=='moment':return evaluate_moment(c)
    issues=validate(c);r=(PinnedEndPlateResult if c.kind=='pinned' else Result)(issues=issues)
    if c.kind=='pinned':r.issues.extend(Issue('scope',note,NBR+', 6.1.1.3 e 6.1.3; '+SCI,'local_scope') for note in PINNED_GAPS)
    if any(i.severity=='error' for i in issues):return r
    try:actual,aa=_calculate(c,c.V,c.N,c.M,'Entrada')
    except (ArithmeticError,ValueError) as exc:
        if c.kind!='pinned':raise
        r.issues.append(Issue('error','Falha numérica na avaliação das ações de entrada: '+type(exc).__name__+'.','Avaliação numérica','numeric'));return r
    result=math.hypot(c.N,c.V)
    # Minimum-force check keeps the complete proportional load path when nonzero.
    f=max(1,45000/result) if c.norm_minimum and result>0 else 1.
    r.actual=actual;r.minimum_factor=f
    try:r.checks,a=_calculate(c,c.V*f,c.N*f,c.M,'Mínimo de força' if f>1 else 'Entrada')
    except (ArithmeticError,ValueError) as exc:
        if c.kind!='pinned':raise
        r.checks=actual
        r.geometry={'actions':aa,'actual_actions':aa,'rows':c.rows,'primary_rows':c.primary_rows,'intermediate_rows':c.intermediate_rows,'hp':c.hp,'nb':c.count,'calculation_nb':c.calculation_count}
        r.issues.append(Issue('error','Falha numérica na conferência mínima: '+type(exc).__name__+'.','Avaliação numérica','numeric'));return r
    if c.kind=='moment' and abs(c.N*f)*(c.beam.d-c.beam.tf)>abs(c.M):
        r.issues.append(Issue('error','A conferência mínima de força ultrapassa o domínio de axial do DG39; revisar o modelo da ligação.',DG+', 3.5'))
        r.checks=[];r.actual=[];return r
    r.geometry={'actions':a,'actual_actions':aa,'rows':c.rows,'primary_rows':c.primary_rows,'intermediate_rows':c.intermediate_rows,'hp':c.hp,'nb':c.count,'calculation_nb':c.calculation_count}
    return r


def evaluate_moment(c):
    r=MomentEndPlateResult()
    try:r.issues=validate(c)
    except (ArithmeticError,ValueError) as exc:
        r.issues.append(Issue('error','Falha numérica na validação: '+type(exc).__name__+'.','Avaliação numérica','numeric'));return r
    if any(i.severity=='error' for i in r.issues):return r
    result=math.hypot(c.N,c.V)
    f=max(1.,45000/result) if c.norm_minimum and result>0 else 1.
    r.minimum_factor=f
    cases=[('Entrada',c.V,c.N,c.M)]
    if f>1:cases.append(('Mínimo de força',c.V*f,c.N*f,c.M))
    actions={}
    for label,V,N,M in cases:
        record={'label':label,'required':True,'actions':{'V':V,'N':N,'M':M},'status':'calculated','checks':[]}
        r.case_records.append(record)
        if label!='Entrada' and abs(N)*(c.beam.d-c.beam.tf)>abs(M):
            text='Caso requerido Mínimo de força não resolvido: a conferência de 45 kN ultrapassa |N|(d−tf) ≤ |M| do DG39. Resultados válidos da Entrada foram preservados; este caso requer outro modelo de distribuição.'
            record.update(status='unresolved_method_scope',reason=text)
            r.issues.append(Issue('pending',text,DG+', 3.5','method'));continue
        try:rows,a=_calculate(c,V,N,M,label)
        except (ArithmeticError,ValueError) as exc:
            text='Falha numérica no caso '+label+': '+type(exc).__name__+'. Sem conclusão para este caso.'
            record.update(status='numerical_failure',reason=text)
            r.issues.append(Issue('error',text,'Avaliação numérica','numeric'));continue
        record['checks']=rows;actions[label]=a
        if label=='Entrada':r.actual=rows
        else:r.minimum=rows
        if any(not x.numerically_valid for x in rows):
            record['status']='numerical_failure'
            r.issues.append(Issue('error','Caso '+label+': há resultado não finito ou resistência não positiva; não implica aprovação nem sobrecarga finita.','Avaliação numérica','numeric'))
    r.checks=moment_envelope(r.actual,r.minimum)
    aa=actions.get('Entrada',{'V':c.V,'N':c.N,'M':c.M})
    a=actions.get('Mínimo de força',aa)
    r.geometry={'actions':a,'actual_actions':aa,'minimum_actions':actions.get('Mínimo de força'),
        'rows':c.rows,'primary_rows':c.primary_rows,'intermediate_rows':c.intermediate_rows,
        'hp':c.hp,'nb':c.count,'calculation_nb':c.calculation_count,
        'envelope_note':'Cada mecanismo conserva a linha completa do seu caso governante; não há um único caso governante de todas as verificações.'}
    return r


def presets():
    p=profiles();b=p['W 410 x 38,8'];s=p['CS 600 x 281']
    return {
        'Rotulada · V e tração':EndPlate(b,s),
        'Rotulada · V e compressão':EndPlate(b,s,N=-2000.),
        'Engastada · extensão acima e abaixo':EndPlate(b,s,kind='moment',tp=19.05,bp=160.,M=40000000.,V=40000.,project='End plate engastada estendida nos dois lados'),
        'Engastada · extensão somente acima':EndPlate(b,s,kind='moment',layout='top',tp=19.05,bp=160.,M=40000000.,V=40000.,project='End plate engastada estendida acima'),
        'Engastada · 12 parafusos sem nervuras (MRE1/2)':EndPlate(p['W 610 x 125,0'],p['CS 600 x 377'],kind='moment',variant='MRE12_U',beam_steel='ASTM A572 Gr.50',support_steel='ASTM A572 Gr.50',plate_steel='ASTM A572 Gr.50',tp=25.4,bp=250.,gauge=150.,pfo=50.,pfi=50.,pb=90.,edge=40.,M=180e6,N=20000.,V=60000.,cjp_compatible=True,project='MRE1/2 · testemunho numérico local, condições físicas a confirmar'),
        'Engastada · 8ES com 16 parafusos CJP':EndPlate(p['W 460 x 74,0'],p['W 360 x 122,0 (H)*'],kind='moment',variant='8ES',beam_steel='ASTM A572 Gr.50',support_steel='ASTM A572 Gr.50',plate_steel='ASTM A572 Gr.50',tp=12.7,bp=210.,gauge=140.,pb=70.,M=100000000.,V=40000.,stiffener_length=275.,project='End plate 8ES com 16 parafusos e duas nervuras CJP'),
        'Engastada · 4ES com enrijecedores CJP':EndPlate(p['W 410 x 46,1'],p['W 310 x 97,0 (H)'],kind='moment',variant='4ES',beam_steel='ASTM A572 Gr.50',support_steel='ASTM A572 Gr.50',plate_steel='ASTM A572 Gr.50',tp=19.05,bp=160.,M=40000000.,V=40000.,project='End plate 4ES com duas nervuras CJP'),
    }
