"""Current-input plan and x–z detail of the restricted direct-flange seat.

Both SVG and PNG are rendered from the same figure. Member continuation lengths
are schematic; connection coordinates and cross-sections use equal data scales.
The lower stiffener root relief is the declared square c×c envelope, not a
bevel silently substituted for it. This module does not calculate resistance.
"""
from io import BytesIO
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Polygon, Rectangle

from .beam_direct_seat import input_errors
from .drawing_annotations import dimension, rendered_wrap

INK = "#263c4c"
MUTED = "#5f7382"
UPPER = "#82b9c1"
LOWER = "#cedbe4"
STIFF = "#edc17d"
ACCENT = "#985031"


def _n(value):
    return (f"{value:.2f}".rstrip("0").rstrip(".") or "0").replace(".", ",")


def _drawable(c):
    try:
        errors = input_errors(c)
        if errors:
            return errors
        dims = [getattr(p, k) for p in (c.beam, c.support) for k in ("d", "bf", "tw", "tf")]
        dims += [c.end, c.db, c.upper_hole, c.support_hole, c.bolt_pitch,
                 c.bolt_gauge, c.stiff_thickness, c.stiff_width, c.stiff_height]
        if max(dims) > 1e6 or min(dims) < 1e-5 or max(dims) / min(dims) > 1e6:
            return ["Dimensões fora do intervalo de representação segura."]
        if abs(c.stiff_y) > 1e6 or abs(c.reference_x) > 1e6:
            return ["Coordenadas fora do intervalo de representação segura."]
        if c.stiff_clip > c.stiff_width or 2 * c.stiff_clip > c.stiff_height:
            return ["Recortes declarados excedem o corpo do enrijecedor; corrija a geometria."]
        return []
    except (AttributeError, TypeError, ValueError, ArithmeticError):
        return ["Entradas sem representação física segura."]


def _figure(c):
    fig = plt.figure(figsize=(11.2, 10.0), facecolor="white")

    def ft(x, y, value, gid, size=10, **kw):
        item = fig.text(x, y, str(value), fontsize=size, color=kw.pop("color", INK),
                        parse_math=False, **kw)
        item.set_gid(gid)
        return item

    ft(.04, .965, "APOIO DIRETO ENTRE MESAS", "drawing_title", 17, weight="bold")
    ft(.04, .937, "Planta da interface e vista lateral · dimensões em mm", "drawing_subtitle", 11, color=MUTED)
    ft(.04, .908, "CROQUI DAS ENTRADAS · NÃO É LIBERAÇÃO PARA FABRICAÇÃO", "drawing_scope", 10,
       color=ACCENT, weight="bold")
    errors = _drawable(c)
    if errors:
        ft(.06, .78, "Geometria não representada", "diagnostic_title", 16, weight="bold", color=ACCENT)
        ft(.06, .72, rendered_wrap("\n".join(errors[:8]), 680, 11), "diagnostic_issues", 11, va="top")
        ft(.06, .25, "Nenhuma geometria de exemplo substitui a entrada atual.", "diagnostic_scope", 11)
        return fig

    u, p = c.beam, c.support
    left = max(u.d * .64, p.bf * 1.45, c.bolt_pitch, abs(min(c.reference_x, 0)) * 1.1)
    span_y = max(u.bf * 1.10, c.bolt_gauge * 1.1, abs(c.stiff_y) + c.stiff_thickness)
    right = max(c.end, p.bf / 2, c.bolt_pitch / 2, c.reference_x)
    pitch, gauge = c.bolt_pitch / 2, c.bolt_gauge / 2

    ft(.045, .867, "1 · PLANTA x–y", "plan_title", 12, weight="bold")
    ft(.045, .844, "Mesa superior omitida para mostrar a interface", "plan_scope", 9, color=MUTED)
    ft(.535, .867, "2 · VISTA LATERAL x–z", "lateral_title", 12, weight="bold")
    ft(.535, .844, "Seção I da viga inferior; superior em vista longitudinal", "lateral_scope", 9, color=MUTED)

    def axes(bounds, gid):
        ax = fig.add_axes(bounds)
        ax.set_gid(gid); ax.set_aspect("equal"); ax.axis("off")
        return ax

    def rect(ax, x, y, w, h, color, gid, **kw):
        item = Rectangle((x, y), w, h, facecolor=color, edgecolor=INK,
                         linewidth=.85, **kw)
        item.set_gid(gid); ax.add_patch(item)
        return item

    def line(ax, xs, ys, gid, **kw):
        item, = ax.plot(xs, ys, color=kw.pop("color", INK), linewidth=kw.pop("lw", .9), **kw)
        item.set_gid(gid)
        return item

    def text(ax, x, y, value, gid, **kw):
        item = ax.text(x, y, str(value), fontsize=kw.pop("size", 9), color=kw.pop("color", INK),
                       parse_math=False, **kw)
        item.set_gid(gid)
        return item

    def dim(ax, p1, p2, value, gid, **kw):
        arrow, label = dimension(ax, p1, p2, value, fontsize=9, **kw)
        arrow.set_gid(gid + "_span"); label.set_gid(gid)

    def break_vertical(ax, x, bottom, top, gid):
        line(ax, [x, x], [bottom, top], gid + "_mask", color="white", lw=4)
        mid = (bottom + top) / 2
        line(ax, [x, x, x-5, x+5, x, x],
             [bottom, mid-12, mid-5, mid+5, mid+12, top], gid)

    # Plan: the lower top flange and upper bottom flange meet directly.
    plan = axes([.035, .365, .455, .445], "plan_xy")
    rect(plan, -p.bf/2, -span_y, p.bf, 2*span_y, LOWER, "plan_support_top_flange")
    line(plan, [0, 0], [-span_y-8, span_y+8], "plan_support_web_axis", color=MUTED, linestyle="--")
    rect(plan, -left, -u.bf/2, left+c.end, u.bf, UPPER, "plan_upper_bottom_flange", alpha=.75)
    for sign in (-1, 1):
        x = p.tw/2 if sign > 0 else -p.tw/2-c.stiff_width
        rect(plan, x, c.stiff_y-c.stiff_thickness/2, c.stiff_width, c.stiff_thickness,
             STIFF, "plan_stiffener_" + ("right" if sign > 0 else "left"),
             linestyle="--", alpha=.95)
    # The upper web is shown as its true thickness, not a second flange.
    for sign in (-1, 1):
        line(plan, [-left, c.end], [sign*u.tw/2]*2, "plan_upper_web_" + str(sign), color=MUTED, linestyle="--")
    for index, (x, y) in enumerate([(-pitch, -gauge), (pitch, -gauge), (-pitch, gauge), (pitch, gauge)], 1):
        outer = Circle((x, y), c.upper_washer_diameter/2, fill=False, edgecolor=MUTED, linewidth=.7)
        outer.set_gid("plan_upper_washer_" + str(index)); plan.add_patch(outer)
        lower = Circle((x, y), c.support_hole/2, fill=False, edgecolor=ACCENT, linestyle="--", linewidth=1.1)
        lower.set_gid("plan_lower_hole_" + str(index)); plan.add_patch(lower)
        hole = Circle((x, y), c.upper_hole/2, facecolor="white", edgecolor=INK, linewidth=1)
        hole.set_gid("plan_upper_hole_" + str(index)); plan.add_patch(hole)
        line(plan, [x-3, x+3], [y, y], "plan_bolt_center_x_" + str(index), lw=.7)
        line(plan, [x, x], [y-3, y+3], "plan_bolt_center_y_" + str(index), lw=.7)
        text(plan, x+c.upper_washer_diameter/2+3, y, str(index), "plan_bolt_number_"+str(index), size=8, va="center")
    break_vertical(plan, -left, -u.bf/2, u.bf/2, "plan_upper_continuation")
    for sign in (-1, 1):
        y = sign*span_y
        line(plan, [-p.bf/2, p.bf/2], [y, y], "plan_lower_continuation_mask_"+str(sign), color="white", lw=4)
        line(plan, [-p.bf/2, -12, -5, 5, 12, p.bf/2],
             [y, y, y-5, y+5, y, y], "plan_lower_continuation_"+str(sign))
    end_lane = max(span_y+30, u.bf/2+40)
    dim(plan, (0, end_lane), (c.end, end_lane), "fim x = +"+_n(c.end), "dimension_upper_end")
    for x in (0, c.end):
        line(plan, [x, x], [u.bf/2+6, end_lane+4], "plan_end_extension_"+str(x), color=MUTED, lw=.5)
    dim(plan, (-pitch, -u.bf/2-30), (pitch, -u.bf/2-30), "pₓ = "+_n(c.bolt_pitch), "dimension_bolt_pitch")
    dim(plan, (-left-30, -gauge), (-left-30, gauge), "gᵧ = "+_n(c.bolt_gauge), "dimension_bolt_gauge", rotation=90)
    dim(plan, (-p.bf/2, -span_y-32), (p.bf/2, -span_y-32), "b inf. = "+_n(p.bf), "dimension_support_width")
    dim(plan, (right+32, -u.bf/2), (right+32, u.bf/2), "b sup. = "+_n(u.bf), "dimension_upper_width", rotation=90)
    text(plan, -left+7, 18, "x →", "plan_axis_x", size=11)
    text(plan, 10, span_y-18, "y ↑", "plan_axis_y", size=11)
    plan.set_xlim(-left-65, right+65); plan.set_ylim(-span_y-64, end_lane+35)

    # Lateral: support I section and the two separate root-notched stiffeners.
    lat = axes([.525, .305, .44, .51], "lateral_xz")
    rect(lat, -p.bf/2, -p.tf, p.bf, p.tf, LOWER, "lateral_support_top_flange")
    rect(lat, -p.bf/2, -p.d, p.bf, p.tf, LOWER, "lateral_support_bottom_flange")
    rect(lat, -p.tw/2, -p.d+p.tf, p.tw, p.d-2*p.tf, LOWER, "lateral_support_web")
    for sign in (-1, 1):
        inner, outer = sign*p.tw/2, sign*(p.tw/2+c.stiff_width)
        cut = inner + sign*c.stiff_clip
        top, bottom = -p.tf, -p.tf-c.stiff_height
        points = [(cut, top), (outer, top), (outer, bottom), (cut, bottom),
                  (cut, bottom+c.stiff_clip), (inner, bottom+c.stiff_clip),
                  (inner, top-c.stiff_clip), (cut, top-c.stiff_clip)]
        item = Polygon(points, closed=True, facecolor=STIFF, edgecolor=INK, linewidth=.9)
        item.set_gid("lateral_stiffener_" + ("right" if sign > 0 else "left")); lat.add_patch(item)
        middle = (top+bottom)/2
        line(lat, [inner]*2, [middle-c.stiff_weld_length/2, middle+c.stiff_weld_length/2],
             "lateral_declared_web_weld_"+str(sign), color=ACCENT, lw=2.1)
    rect(lat, -left, u.tf, left+c.end, u.d-2*u.tf, UPPER, "lateral_upper_web", alpha=.4)
    rect(lat, -left, 0, left+c.end, u.tf, UPPER, "lateral_upper_bottom_flange")
    rect(lat, -left, u.d-u.tf, left+c.end, u.tf, UPPER, "lateral_upper_top_flange")
    break_vertical(lat, -left, 0, u.d, "lateral_upper_continuation")
    # Hardware length is illustrative; actual flange/bolt/washer widths track inputs.
    extra = max(c.db*.6, 8)
    for index, x in enumerate((-pitch, pitch), 1):
        rect(lat, x-c.db/2, -p.tf-extra, c.db, p.tf+u.tf+2*extra, INK, "lateral_bolt_pair_"+str(index), zorder=6)
        rect(lat, x-c.upper_washer_diameter/2, u.tf, c.upper_washer_diameter, max(c.db*.12, 1),
             LOWER, "lateral_upper_washer_"+str(index), zorder=7)
        rect(lat, x-c.lower_washer_diameter/2, -p.tf-max(c.db*.12, 1), c.lower_washer_diameter,
             max(c.db*.12, 1), LOWER, "lateral_lower_washer_"+str(index), zorder=7)
    contact_left = max(-left, -p.bf/2)
    contact_right = min(c.end, p.bf/2)
    line(lat, [contact_left, contact_right], [0, 0], "direct_flange_contact", color=ACCENT, lw=1.6, zorder=8)
    contact = lat.annotate("Contato direto\nz = 0", xy=(contact_left+8, 0), xytext=(-left-25, -p.d*.24),
                           fontsize=9, color=ACCENT, parse_math=False,
                           arrowprops={"arrowstyle":"-", "color":ACCENT, "lw":.8})
    contact.set_gid("direct_contact_label")
    dim(lat, (-left-27, 0), (-left-27, u.d), "d sup. = "+_n(u.d), "dimension_upper_depth", rotation=90)
    dim(lat, (right+42, -p.d), (right+42, 0), "d inf. = "+_n(p.d), "dimension_support_depth", rotation=90)
    dim(lat, (0, u.d+35), (c.end, u.d+35), "fim x = +"+_n(c.end), "lateral_upper_end")
    line(lat, [0, 0], [-p.d-12, u.d+55], "lateral_origin", color=MUTED, linestyle=":", lw=.65)
    text(lat, -left, -p.d-42, "2 parafusos sobrepostos em cada posição x", "projected_bolt_count", size=8.5)
    text(lat, -left, -p.d-70, "x →     z ↑", "lateral_axes", size=10)
    lat.set_xlim(-left-60, right+85); lat.set_ylim(-p.d-95, u.d+85)

    # A full-width key keeps text away from the small section details.
    ft(.045, .322, "4 PARAFUSOS · MALHA 2 × 2", "bolt_key_title", 10, weight="bold")
    ft(.045, .300, "Haste Ø"+_n(c.db)+" · furos sup./inf. Ø"+_n(c.upper_hole)+" / Ø"+_n(c.support_hole), "bolt_holes", 9)
    ft(.045, .278, "Arruelas sup./inf. Ø"+_n(c.upper_washer_diameter)+" / Ø"+_n(c.lower_washer_diameter), "washer_key", 9)
    ft(.045, .256, "x = ±"+_n(pitch)+"; y = ±"+_n(gauge), "bolt_coordinates", 9)
    fig.add_artist(plt.Line2D([.04, .96], [.229, .229], transform=fig.transFigure, color="#d3dce2", linewidth=1))
    upper_name = rendered_wrap("Superior: "+u.name+" · eixo x · mesa t = "+_n(u.tf)+" · alma t = "+_n(u.tw), 730, 10)
    lower_name = rendered_wrap("Inferior: "+p.name+" · eixo y · mesa t = "+_n(p.tf)+" · alma t = "+_n(p.tw), 730, 10)
    ft(.045, .212, upper_name, "current_upper_profile", 10, va="top")
    ft(.045, .187, lower_name, "current_lower_profile", 10, va="top")
    ft(.045, .153, "Par de enrijecedores: 2 × "+_n(c.stiff_thickness)+" × "+_n(c.stiff_width)+" × "+_n(c.stiff_height)+
       " (esp. × largura × altura); plano y = "+_n(c.stiff_y), "stiffener_geometry", 10)
    ft(.045, .128, "Alívios quadrados na raiz: "+_n(c.stiff_clip)+" × "+_n(c.stiff_clip)+
       "; filete declarado a = "+_n(c.stiff_weld)+"; comprimento efetivo = "+_n(c.stiff_weld_length), "stiffener_relief_weld", 10)
    ft(.045, .103, "Par construtivo sem resistência creditada. Ajuste e ligações às mesas/alma devem ser conferidos.", "stiffener_no_credit", 9, color=ACCENT)
    ft(.045, .078, "V = "+_n(c.V/1000)+" kN · N = "+_n(c.N/1000)+" kN · My = "+_n(c.applied_moment_y/1e6)+
       " kN·m · Tz = "+_n(c.torsion/1e6)+" kN·m · referência x = "+_n(c.reference_x), "current_actions", 9)
    ft(.045, .053, "Geometria proporcional em cada vista; escalas entre vistas distintas. Continuidade dos membros esquemática.", "scale_scope", 8.5, color=MUTED)
    ft(.045, .032, "Ferragens em vista lateral são indicativas. Furos circulares; sem chapa intermediária e sem solda superior.", "hardware_scope", 8.5, color=MUTED)
    return fig


def create_svg(c):
    """Return a standalone, XML-escaped SVG of the current connection inputs."""
    with matplotlib.rc_context({"svg.fonttype": "none", "font.family": "DejaVu Sans", "text.usetex": False}):
        fig = _figure(c)
        try:
            out = BytesIO()
            fig.savefig(out, format="svg", facecolor="white", metadata={"Date": None})
            return out.getvalue().decode("utf-8")
        finally:
            plt.close(fig)


def png_bytes(c):
    """Return report-ready PNG bytes using the existing Matplotlib dependency."""
    with matplotlib.rc_context({"font.family": "DejaVu Sans", "text.usetex": False}):
        fig = _figure(c)
        try:
            out = BytesIO()
            fig.savefig(out, format="png", dpi=180, facecolor="white")
            return out.getvalue()
        finally:
            plt.close(fig)
