"""Native catalog identity and missing-data checks shared by angle families.

Catalog availability is not engineering qualification. No material or source
radius is inferred, and exact legacy input shapes remain valid.
"""
from dataclasses import asdict, fields

from .angle_catalog import catalog, get_angle, label

COMMON_FIELDS = frozenset(('angle_catalog_id', 'angle_root_source', 'angle_root_confirmed'))
METADATA_FIELDS = COMMON_FIELDS
STRING_FIELDS = frozenset(('angle_catalog_id', 'angle_root_source'))
BOOL_FIELDS = frozenset(('angle_root_confirmed',))
LABELS = {
    'angle_catalog_id': 'Identidade permanente no catálogo Gerdau',
    'angle_root_source': 'Fonte independente do raio interno',
    'angle_root_confirmed': 'Raio interno manual confirmado pelo responsável',
}


def native_connection(c):
    """Export complete inputs; legacy fields keep their exact values and units."""
    return asdict(c)


def valid_native_fields(raw, cls):
    complete = {field.name for field in fields(cls)}
    return isinstance(raw, dict) and set(raw) in (complete, complete - METADATA_FIELDS)


def identity_errors(c, area_factor=1):
    """Reject false identity claims without rewriting any imported geometry."""
    identity = c.angle_catalog_id
    if not isinstance(identity, str) or not identity:
        return []
    record = catalog().get(identity)
    if record is None:
        return ['angle_catalog_id: perfil Gerdau não reconhecido; use a entrada manual para outro perfil.']
    expected = {'t': record['t']}
    if hasattr(c, 'Ag'):
        expected['leg'] = record['leg']
        if record['Ag'] is not None:
            expected['Ag'] = area_factor * record['Ag']
        if record['centroid'] is not None:
            expected['ec'] = record['centroid']
    else:
        expected.update(beam_leg=record['leg'], support_leg=record['leg'])
    return [f'{key}: valor difere do catálogo Gerdau selecionado; selecione Manual para geometria/propriedades personalizadas.'
            for key, value in expected.items() if getattr(c, key) != value]


def missing_data_errors(c):
    """Block calculations, while allowing native save of pending declarations."""
    if not c.angle_catalog_id:
        return []
    record = get_angle(c.angle_catalog_id)
    if record is None:
        return []  # Identity validation supplies the diagnostic.
    errors = []
    if record['root_radius'] is None and (c.root_radius <= 0 or not c.angle_root_confirmed or not c.angle_root_source.strip()):
        errors.append('Gerdau não publica o raio interno: informe o raio real, sua fonte independente e confirme a declaração antes de calcular.')
    return errors


def provenance_text(c):
    identity = getattr(c, 'angle_catalog_id', '')
    if not identity:
        return ''
    record = get_angle(identity)
    if record is None:
        return 'Identidade de catálogo não reconhecida: ' + str(identity)
    text = label(identity) + '. ' + record['source'] + '. Dimensões métricas publicadas preservadas. '
    text += ('Raio interno não publicado pela Gerdau; valor manual declarado: '
             + str(c.root_radius) + ' mm. Fonte independente: ' + (c.angle_root_source or 'pendente') + '. ')
    if hasattr(c, 'Ag'):
        if record['Ag'] is None or record['centroid'] is None:
            text += 'Ag/ec não publicados: perfil excluído do catálogo operacional. '
        else:
            text += 'Ag e centroide provêm da tabela Gerdau; em 2L, Ag é a soma de duas cantoneiras iguais. '
    if record.get('property_selection_criterion'):
        text += record['property_selection_criterion'] + ' '
    return text + 'A seleção não certifica aço, fabricação nem amplia o domínio do modelo de ligação.'


def add_drawing_provenance(fig, c, area_factor=1):
    """Append a measured band without shrinking or overlaying physical views."""
    if not getattr(c, 'angle_catalog_id', ''):
        return fig
    errors = identity_errors(c, area_factor)
    if errors:
        raise ValueError('; '.join(errors))
    from .drawing_annotations import rendered_wrap
    record = get_angle(c.angle_catalog_id)
    declared = ('confirmado' if c.angle_root_confirmed and c.angle_root_source.strip()
                and c.root_radius > 0 else 'PENDENTE')
    rows = [
        label(c.angle_catalog_id) + ' | ID: ' + c.angle_catalog_id,
        ('Fonte da geometria e Ag/ec: ' if hasattr(c, 'Ag') else 'Fonte das abas/espessura: ') + record['source'] + '.',
        f'Raio interno r={c.root_radius:g} mm: manual, {declared}; não publicado pela Gerdau. '
        + 'Fonte independente: ' + (c.angle_root_source or 'pendente') + '.',
        'Aço selecionado separadamente: ' + c.angle_steel + '. O catálogo não amplia o domínio resistente da ligação.',
    ]
    width, height = fig.get_size_inches()
    fontsize = 8.2
    text = rendered_wrap('\n'.join(rows), .93 * width * 72, fontsize)
    extra = (text.count('\n') + 1) * fontsize * 1.4 / 72 + .22
    positions = [(ax, ax.get_position(original=True).frozen()) for ax in fig.axes]
    texts = [(artist, artist.get_position()) for artist in fig.texts]
    fig.set_size_inches(width, height + extra, forward=True)
    for ax, pos in positions:
        ax.set_position((pos.x0, (pos.y0 * height + extra) / (height + extra),
                         pos.width, pos.height * height / (height + extra)))
    for artist, (x, y) in texts:
        artist.set_position((x, (y * height + extra) / (height + extra)))
    artist = fig.text(.035, (extra - .09) / (height + extra), text, va='top',
                      fontsize=fontsize, linespacing=1.4, color='#263746')
    artist.set_gid('angle_catalog_provenance')
    return fig
