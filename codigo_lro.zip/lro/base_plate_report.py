"""Memória editável PT-BR da base Tipo 1; mesma geometria e motor da tela."""
from io import BytesIO
from docx import Document
from docx.oxml import OxmlElement
from docx.shared import Inches,Pt,RGBColor
from .models import KGF,STEELS,VERSION
from .base_plate import NBR,G1,G2,GC,MU,EXTERNAL_SHAPES,detail_reference
from .base_plate_drawing import image_bytes
from .base_plate_detail_drawing import detail_image_bytes
from .base_plate_details import ANCHOR_TYPES,FIXITIES,weld_description,grout_geometry
from .concrete_anchorage import SOURCE as CONE_SOURCE
from .report import BRAND,LINK,number,display,decimal_text,table,hyperlink,_math,group,sub,frac,power,radical


def _text_sub(base,index):
    """Índice descritivo, sem converter a palavra 'int' em operador integral."""
    element=sub(base,index)
    for run in element.xpath('.//m:sub//m:r',namespaces={'m':'http://schemas.openxmlformats.org/officeDocument/2006/math'}):
        properties=OxmlElement('m:rPr');properties.append(OxmlElement('m:nor'))
        run.insert(0,properties)
    return element


def _text_power_sub(base,index,exponent):
    """Explicit combined script avoids LibreOffice parsing a nested 'in' token."""
    element=OxmlElement('m:sSubSup')
    for tag,value in [('e',base),('sub',index),('sup',exponent)]:
        slot=OxmlElement('m:'+tag)
        for run in group(value):
            props=OxmlElement('m:rPr');props.append(OxmlElement('m:nor'));run.insert(0,props);slot.append(run)
        element.append(slot)
    return element


def _equilibrium_equations(doc,c,a):
    case=a['case']
    if c.shear_path=='plate':
        _math(doc,group(sub('e','V'),' = ',sub('t','p'),' + ',frac(group(sub('b','v'),' + ',sub('e','n')),'2')))
        _math(doc,group('ΔM = V ',sub('e','V'),';   ',sub('M','ef'),' = ',sub('M','informado'),' + ΔM'))
        doc.add_paragraph('Transporte estático das ações da face superior da placa até a reação da chave. '
                          'Somam-se M informado e ΔM com seus sinais, uma única vez; somente depois se toma o módulo. '
                          'Nas equações de equilíbrio a seguir, M designa Mef. O sinal de Mef define os lados comprimido e tracionado.')
    _math(doc,group('L = d + 4',sub('a','1'),';   B = ',sub('a','2'),' + 2',sub('a','1'),';   a = L/2 − ',sub('a','1')))
    _math(doc,group(sub('σ','Rd'),' = ',frac(group('0,85',sub('f','ck')),sub('γ','c')),';   ',sub('A','2'),'/',sub('A','1'),' = 1'))
    if case.startswith('C'):
        _math(doc,group('e = |M|/N;   ',sub('e','crit'),' = ',frac(group('L − N/(',sub('σ','Rd'),' B)'),'2')))
        _math(doc,group('X = ',frac('4 d bf',power('(d + bf)')),' ',frac('N',group('L B ',sub('σ','Rd'))),' ≤ 1'))
        _math(doc,group('λ = min(1; ',frac(group('2',radical('X')),group('1 + ',radical('1 − X'))),')'))
    if case=='C1': _math(doc,group(sub('l','c'),' = L;   C = N;   ',sub('F','t,Sd'),' = 0'))
    elif case=='C2': _math(doc,group(sub('l','c'),' = L − 2e;   C = N;   ',sub('F','t,Sd'),' = 0'))
    elif case in ('C3','T3','M0'):
        term='|M| + N a' if case=='C3' else ('|M| − U a' if case=='T3' else '|M|')
        _math(doc,group('H = L/2 + a;   D = ',power('H'),' − ',frac(group('2(',term,')'),group(sub('σ','Rd'),' B')),' ≥ 0'))
        _math(doc,group(sub('l','c'),' = H − ',radical('D'),';   C = ',sub('σ','Rd'),' B ',sub('l','c')))
        _math(doc,group(sub('F','t,Sd'),' = ',frac(group('2(C ', '− N)' if case=='C3' else ('+ U)' if case=='T3' else ')')),sub('n','b'))))
        doc.add_paragraph('A implementação usa a raiz equivalente racionalizada lc = [2(|M| + N a)/(σRd B)]/[H + √D], com N algébrico, para evitar perda de precisão. A solução exige 0 < lc ≤ L, tração não negativa e compressão total N ≤ σRd L B.')
    elif case in ('T1','T2'):
        _math(doc,group('U = −N;   ',sub('F','t,máx'),' = ',frac('U',sub('n','b')),' + ',frac('|M|',group('a ',sub('n','b')))))
        _math(doc,group(sub('F','t,mín'),' = ',frac('U',sub('n','b')),' − ',frac('|M|',group('a ',sub('n','b'))),';   C = 0'))
    _math(doc,group('C − 2',sub('F','t,máx'),' − 2',sub('F','t,mín'),' = N'))
    _math(doc,group('C ',sub('x','C'),' − 2',sub('F','t,máx'),' ',sub('x','T,máx'),' − 2',sub('F','t,mín'),' ',sub('x','T,mín'),' = M'))
    doc.add_paragraph('N positivo comprime. U é a magnitude da tração axial. Ft,máx e Ft,mín são forças individuais nas duas linhas, com dois chumbadores em cada linha; x indica a posição algébrica em relação ao centro da placa. O sinal de M troca as linhas. lc é o comprimento do bloco equivalente uniforme de compressão; não é uma previsão elástica de abertura ou deslocamento.')


def _check_equation(doc,row):
    key=row.id
    if key=='bp_anchor_shear_native':
        expr=group('|',sub('V','Sd'),'| ≤ ',sub('V','Rd,grupo'),' = Σ ',sub('V','Rd,i'))
    elif key=='bp_anchor_shear_special':
        expr=group('|',sub('V','Sd'),'| ≤ Σ min(',sub('V','aço,Rd,i'),'; 5',power(sub('d','b')),sub('σ','c,Rd'),')')
    elif key=='bp_anchor_shear_interaction':
        expr=group('|',sub('V','Sd'),'| ≤ Σ ',_text_sub('V','int,Rd,i'))
    elif key.startswith('bp_cone_'):
        expr=group('φ',sub('N','cb'),' = 0,70 ',frac(sub('A','Nc'),sub('A','Nco')),' ',sub('ψ','ec,N'),' ',sub('ψ','ed,N'),' ',sub('N','b'))
    elif key.startswith('bp_anchor_washer_'):
        expr=group(row.equation)
    elif key.startswith('bp_lug_'):
        # Mantém toda equação do motor em OMML editável, inclusive novos
        # controles de geometria, sem cair na fórmula do dispositivo externo.
        expr=group(row.equation)
    elif key=='bp_shear_anchors_external':expr=group(row.equation)
    elif key=='bp_plate_contact':
        expr=group(sub('t','min,c'),' = ',sub('l','max'),radical(frac(group('2',sub('σ','Sd')),frac(sub('f','y'),sub('γ','a1')))))
    elif key=='bp_plate_tension':
        expr=group(sub('t','min,t'),' = ',radical(frac(group('2',sub('n','b'),sub('F','t,Sd'),'(m − ',sub('a','1'),')'),group('B ',frac(sub('f','y'),sub('γ','a1'))))))
    elif key=='bp_anchor_steel':
        expr=group(sub('F','t,Rd'),' = ',frac(group('0,75 π',power(sub('d','b')),sub('f','u')),group('4',sub('γ','a2'))))
    elif key=='bp_contact':
        expr=group(sub('σ','Sd'),' = ',frac('C',group('B ',sub('l','c'))),' ≤ ',frac(group('0,85',sub('f','ck')),sub('γ','c')))
    elif key=='bp_shear':
        expr=group(sub('V','Rd'),' = min(',frac(group('0,45 C'),sub('γ','a2')),'; ',sub('τ','Rd'),' L B)')
    elif key=='bp_grout':expr=group(sub('f','ck,graute'),' ≥ 2',sub('f','ck'))
    elif key=='bp_width':expr=group('B ≥ bf + 25 mm')
    else:expr=group('|',sub('V','Sd'),'| ≤ ',sub('V','Rd,dispositivo'))
    _math(doc,expr)


def _anchor_shear_equations(doc):
    """Equações da NBR 6.7.2.5 em OMML, sem rateio fictício do esforço."""
    _math(doc,group(sub('A','b'),' = ',frac(group('π',power(sub('d','b'))),'4'),';   ',
                    sub('F','v,Rd'),' = ',frac(group('0,45',sub('A','b'),sub('f','ub')),sub('γ','a2'))))
    _math(doc,group('α = 1,45',frac(group(sub('t','p'),' + ',frac(sub('t','a'),'2')),sub('d','b')),
                    frac(sub('f','ub'),sub('f','y,b')),frac(sub('γ','a1'),sub('γ','a2'))))
    _math(doc,group(sub('V','aço,Rd,i'),' = max[0; ',frac(
        group(radical(group('(1 + ',power('α'),')',power(sub('F','v,Rd')),' − ',
                            power(group('(0,533',sub('F','t,Sd,i'),')')))),
              ' − α(0,533',sub('F','t,máx'),')'),group('1 + ',power('α'))),']'))
    _math(doc,group(_text_sub('V','int,Rd,i'),' = ',sub('F','v,Rd'),radical(group('1 − ',
                    power(group('(',frac(sub('F','t,Sd,i'),sub('F','t,Rd')),')')))),
                    ';   0 ≤ ',sub('F','t,Sd,i'),' ≤ ',sub('F','t,Rd')))
    _math(doc,group(sub('σ','c,Rd'),' = ',frac(group('0,85',sub('f','ck')),sub('γ','c')),';   ',
                    sub('V','Rd,i'),' = min(',sub('V','aço,Rd,i'),'; ',_text_sub('V','int,Rd,i'),'; 5',power(sub('d','b')),sub('σ','c,Rd'),')'))
    _math(doc,group(sub('V','Rd,grupo'),' = ',sub('V','Rd,1'),' + ',sub('V','Rd,2'),' + ',sub('V','Rd,3'),' + ',sub('V','Rd,4'),
                    ';   |',sub('V','Sd'),'| ≤ ',sub('V','Rd,grupo')))


def _anchor_shear_actions(doc,c,a):
    """Capacidades condicionais das quatro barras e ação integral de solda."""
    shear=a['anchor_shear']
    doc.add_paragraph('Cortante nativo com arruelas soldadas',style='Heading 1')
    doc.add_paragraph('Quatro barras ASTM A36 e quatro arruelas especiais quadradas idênticas, soldadas à face superior da placa. '
                      'As quatro barras devem estar efetivamente mobilizadas, com furos-padrão nas arruelas. '
                      'O modelo usa a tração individual da mesma combinação N–M e soma as quatro capacidades condicionais '
                      'conforme NBR 6.7.2.5. O cortante total é resistido por esse caminho, sem soma de atrito ou chave.')
    doc.add_paragraph('Arruelas adotadas: '+number(c.anchor_washer_side)+' × '+number(c.anchor_washer_side)+' × '+
                      number(c.anchor_washer_t,3)+' mm; furo Ø'+number(c.anchor_washer_hole,3)+' mm; aço fy=345 MPa. '
                      'Essas são as dimensões reais usadas no cálculo e no desenho; a Tabela 18 aparece separadamente como referência.')
    table(doc,['Barra','x e y (mm)','Ft,Sd,i (kN)','Vaço,Rd,i (kN)','Vint,Rd,i (kN)','VRd,i (kN)','Domínio'],[
        (rod['id'],number(rod['x'],3)+'; '+number(rod['y'],3),number(rod['tension']/1000,4),
         number(rod['steel_rd']/1000,4) if rod['domain_ok'] else 'Inválido',
         number(rod['combined_rd']/1000,4) if rod['domain_ok'] else 'Inválido',
         number(rod['rd']/1000,4) if rod['domain_ok'] else 'Sem crédito',
         'Válido' if rod['domain_ok'] else 'Não atende') for rod in shear['rods']
    ],[.45,1.35,1.,1.05,1.05,1.05,1.])
    doc.add_paragraph('Origem no centro da placa; x paralelo a L e y paralelo a B. A1 e A2 estão em x=−a; '
                      'A3 e A4, em x=+a. M positivo comprime +x e traciona −x; M negativo troca as linhas. '
                      'V positivo atua em +x. A tabela apresenta capacidades condicionais, sem impor uma distribuição '
                      'do cortante aplicado entre as barras.')
    table(doc,['Grandeza do modelo','Valor','Unidade'],[
        ('α com fy,b=250 MPa e fub=400 MPa',number(shear['alpha'],6),'—'),
        ('Fv,Rd sem redução por tração e flexão local',number(shear['shear_unreduced_rd']/1000,6),'kN/barra'),
        ('Ft,Rd para o limite adicional de interação',number(shear['tension_rd']/1000,6),'kN/barra'),
        ('Ft,máx no termo subtrativo conservador',number(shear['subtractive_tension']/1000,6),'kN'),
        ('Limite local 5db²σc,Rd',number(shear['concrete_cap']/1000,6),'kN/barra'),
        ('Soma das quatro capacidades VRd,grupo',number(shear['group_rd']/1000,6),'kN'),
        ('Cortante aplicado com sinal',number(c.V/1000,6),'kN'),
    ],[4.15,1.9,.9])
    doc.add_paragraph('Fv,Rd usa roscas no plano de corte, conforme NBR 6.3.3.2. '
                      'O fy,b de α é a resistência ao escoamento da barra ASTM A36, e não a da placa ou da arruela. '
                      'Vaço,Rd,i é o limite conservador de 6.7.2.5, preservando o coeficiente 0,533. '
                      'Vint,Rd,i é o limite adicional da interação geral de 6.3.3.4, expresso como capacidade para a tração individual atual. '
                      'O limite local de concreto usa σc,Rd=0,85fck/γc, com A2/A1=1; '
                      'não comprova a ancoragem ou a resistência do grupo no concreto. '
                      'Se o domínio de uma barra não for atendido, a memória sinaliza a falha e não lhe atribui crédito resistente.')
    doc.add_paragraph('Índices da expressão impressa: o radical usa Ft,Sd,i e o termo subtrativo apresenta Ft,Sd,1. '
                      'O cálculo mantém a tração individual no radical e usa a maior tração simultânea Ft,máx no termo subtrativo '
                      'de todas as barras, adotando um limite conservador para ambas as leituras. '
                      'Valores resultantes negativos recebem capacidade nula. '
                      'Essa escolha não é apresentada como transcrição literal nem como correção da norma.')
    doc.add_paragraph('M informado é preservado na face superior da placa. Não se acrescenta automaticamente V·tp ou V·graute. '
                      'O termo tp+ta/2 integra o parâmetro local α da NBR 6.7.2.5; não é um transporte global das ações. '
                      'Outra referência de carregamento ou excentricidade global exige avaliação específica.')
    doc.add_paragraph('Ação obrigatória para a solda de cada arruela',style='Heading 2')
    _math(doc,group(sub('F','w,Sd,arruela'),' = ',sub('F','v,Rd')))
    doc.add_paragraph('Cada solda de arruela deve resistir a Fv,Rd sem redução = '+
                      number(shear['weld_force_per_washer']/1000,6)+' kN. '
                      'A ação não é limitada pela capacidade reduzida VRd,i nem pelo cortante aplicado. '
                      'Não se calcula resistência ou utilização da solda nesta etapa.')
    doc.add_paragraph('Permanecem a complementar o dimensionamento e o detalhamento das soldas das arruelas, '
                      'o metal-base e a transferência local entre arruela e placa, incluindo flexão, pressão de contato e '
                      'rasgamento em furos conforme 6.3.3.3; '
                      'a ancoragem completa, arrancamento, pryout, interação e demais modos no concreto; '
                      'o bloco armado e sua ligação à fundação. Também permanecem pendentes as soldas do pilar. '
                      'O cone de tração aparece em seção própria quando selecionado. O atendimento do aço e do limite local não aprova a base completa.')


def _lug_actions(doc,c,a):
    """Ações normativas de solda, sem inventar uma resistência da ligação."""
    lug=a['lug']
    doc.add_paragraph('Chapa única para o cortante',style='Heading 2')
    doc.add_paragraph('Uma chapa retangular vertical centrada na base, com bh na direção y, espessura tpv na direção x '
                      'e cortante perpendicular à face. A projeção bv é medida abaixo da face inferior da placa. '
                      'A espessura real do graute é en='+number(c.grout_t)+' mm; a altura efetiva de contato é bv−en. '
                      'A chave recebe o cortante total, sem soma de atrito.')
    _math(doc,group(sub('σ','chave,Rd'),' = ',frac(group('1,7',sub('f','ck')),sub('γ','c')),
                    ';   ',sub('A','2'),'/',sub('A','1'),' = 4'))
    _math(doc,group(sub('A','contato'),' = ',sub('b','h'),'(',sub('b','v'),' − ',sub('e','n'),');   ',
                    sub('V','contato,Rd'),' = ',sub('σ','chave,Rd'),' ',sub('A','contato')))
    doc.add_paragraph('O aumento de contato A2/A1=4 é prescrito para a chave pela NBR 6.7.2.4. '
                      'O contato da própria placa de base permanece com A2/A1=1. '
                      'Contato, flexão e cisalhamento da chapa são verificações locais independentes; '
                      'seu mínimo não constitui resistência certificada do dispositivo completo.')
    doc.add_paragraph('Ações obrigatórias para dimensionar as soldas',style='Heading 2')
    _math(doc,group(sub('V','w'),' = ',sub('V','contato,Rd')))
    _math(doc,group(sub('M','w'),' = ',frac(group(sub('σ','chave,Rd'),' ',sub('b','h'),
                    '(',power(sub('b','v')),' − ',power(sub('e','n')),')'),'2'),
                    ' = ',sub('V','w'),frac(group(sub('b','v'),' + ',sub('e','n')),'2')))
    table(doc,['Ação para a solda','Valor','Unidade'],[
        ('Vw igual à resistência de contato',number(lug['weld_V']/1000,6),'kN'),
        ('Mw na face inferior da placa',number(lug['weld_M']/1e6,6),'kN·m'),
    ],[4.15,1.9,.9])
    doc.add_paragraph('A NBR 6.7.2.4 exige essas ações a partir da resistência de contato, mesmo que superem o cortante '
                      'aplicado ou as resistências locais do aço da chave. Não se limita Vw pela menor resistência da chapa. '
                      'Mw é a ação local para a solda na face inferior; ΔM é o transporte da ação aplicada para o equilíbrio global. '
                      'Não são somados entre si.')
    doc.add_paragraph('Permanecem pendentes o dimensionamento e o detalhamento das soldas da chave, inclusive metal de solda '
                      'e metal-base, a flexão local da placa na fixação da chave, a ruptura e os efeitos de borda do concreto, '
                      'o bloco armado e sua transferência à fundação. Também permanecem pendentes a ancoragem no concreto '
                      'e as soldas do pilar. Um resultado local que atende não aprova o dispositivo completo.')


def _detail_and_cone_report(doc,c,r):
    a=r.geometry;cone=a.get('concrete_cone',{});grout=grout_geometry(c)
    doc.add_page_break()
    doc.add_paragraph('Detalhe da ancoragem, vínculo e soldas',style='Heading 1')
    doc.add_picture(BytesIO(detail_image_bytes(c,r)),width=Inches(6.95))
    doc.add_paragraph('Geometria de detalhe com alma vertical em planta. Peça de apoio enterrada e arruela superior da placa são componentes distintos. O desenho não confirma resistência ou rigidez; somente o cone de tração tem cálculo complementar quando selecionado e dentro do domínio.')
    table(doc,['Item','Especificação'],[
        ('Vínculo pretendido',FIXITIES[c.base_fixity]+'; M informado preservado'),
        ('Ancoragem enterrada',ANCHOR_TYPES[c.anchor_type]),
        ('Solda da alma',weld_description(c,'web')),
        ('Soldas das mesas',weld_description(c,'flange')),
        ('Enrijecedores','Sem enrijecedores' if c.stiffener_detail=='none' else f'2 triângulos no plano da alma; um além de cada mesa. Projeção {number(c.stiffener_length)}; altura {number(c.stiffener_height)}; t={number(c.stiffener_t)} mm'),
        ('Graute a 45°',f'Face inferior {number(grout["bottom_L"])} × {number(grout["bottom_B"])} mm; área geométrica {number(grout["footprint"])} mm²'),
    ],[1.65,5.3])
    doc.add_paragraph('Filete de pernas iguais a 90°: a=z/√2. Perna/garganta são medidas do mesmo filete; a troca de modo conserva seu tamanho. CJP exige preparação, execução e inspeção. Não há cálculo geral da resistência das soldas ou do metal-base sob N/M/V. M no topo da placa não se confunde com Mef de equilíbrio do lado da fundação.')
    if c.stiffener_detail!='none':
        doc.add_paragraph('Interpretação inicial reversível do pedido de dois enrijecedores: chapas triangulares verticais além das mesas, alinhadas com a alma e soldadas às mesas e à placa. Os resultados de chapa e distribuição N–M continuam como referência SEM enrijecedores, sem comprovar a capacidade ou a distribuição real da base enrijecida.')
    doc.add_paragraph('A projeção física do graute a 45° não aumenta a área resistente adotada: contato B×lc; limite de atrito L×B. Não se confunde com a projeção de ruptura do cone de tração.')
    if c.anchor_type!='unspecified' or c.cone_model!='off':
        table(doc,['Dado físico','Valor'],[
            ('Limites reais do bloco',f'x=[{number(c.block_xmin)}; {number(c.block_xmax)}]; y=[{number(c.block_ymin)}; {number(c.block_ymax)}] mm'),
            ('Altura h / hef físico / cobrimento inferior adotado',f'{number(c.block_h)} / {number(c.hef)} / {number(c.anchor_bottom_cover)} mm'),
            ('Peça enterrada x×y×t / extensão inferior completa',f'{number(c.anchor_head_length)}×{number(c.anchor_head_width)}×{number(c.anchor_bearing_t)} / {number(c.anchor_head_t)} mm'),
            ('Porca inferior / furo da chapa / cobertura disponível',f'{number(c.anchor_nut_t)} / {number(c.anchor_head_hole)} / {number(c.block_h-c.hef-c.anchor_head_t)} mm' if c.anchor_type=='buried_plate_nut' else 'Cobrimento disponível '+number(c.block_h-c.hef-c.anchor_head_t)+' mm; '+('área líquida da porca '+number(c.anchor_nut_bearing_area)+' mm²' if c.anchor_type=='buried_nut' else 'cabeça forjada')),
            ('Referência do detalhe',c.anchor_detail_ref or 'Não informada'),
            ('Moldado no local e concreto íntegro','Declarado pelo usuário' if c.anchor_detail_confirmed else 'Pendente'),
        ],[3.3,3.65])
        # The generic table helper adds a trailing empty paragraph; remove it
        # before the next page-start heading so it cannot create a blank page.
        trailing=doc.paragraphs[-1]
        if not trailing.text:trailing._element.getparent().remove(trailing._element)
    if c.cone_model=='off':
        doc.add_paragraph('Cone de concreto por tração não selecionado: não foi atribuída resistência nativa à ancoragem.')
        return
    doc.add_paragraph('Cone de concreto à tração · ACI complementar',style='Heading 1').paragraph_format.page_break_before=True
    doc.add_paragraph(CONE_SOURCE+'. Concreto normal fissurado; sem crédito de armadura suplementar. O valor numérico de fck é usado como resistência especificada cilíndrica f′c. As trações já majoradas do equilíbrio NBR são usadas sem refatoração; φ ACI não recebe γc adicional. Essa base complementar requer aceitação do responsável técnico, não é uma calibração normativa integral NBR/ACI.')
    if cone.get('status')=='pending':
        doc.add_paragraph('DADOS PENDENTES: nenhuma resistência do cone calculada.')
        for reason in cone['reasons']:doc.add_paragraph(reason)
        return
    if cone.get('status')=='not_demanded':
        doc.add_paragraph('NÃO SOLICITADO NESTA COMBINAÇÃO: nenhuma barra está tracionada. Isso não é aprovação da ancoragem ao cortante.')
        return
    doc.add_paragraph('Padrão: grupos efetivamente tracionados e conectados; barras sem tração não ampliam a área. Cones desconectados são verificados separadamente, sem comparação com resistências somadas. '+('Foi ativado o envelope suplementar conservador de subconjuntos; não é uma exigência literal da ACI.' if c.cone_subset_envelope else 'Envelope suplementar conservador de subconjuntos desligado.'))
    table(doc,['Barra','x / y (mm)','Tração simultânea (kN)'],[
        (rod['id'],number(rod['x'])+' / '+number(rod['y']),number(rod['tension']/1000,5)) for rod in cone['rods']
    ],[.6,3.2,3.15])
    _math(doc,group('φ',sub('N','cb'),' = 0,70 ',frac(sub('A','Nc'),sub('A','Nco')),' ',sub('ψ','ec,N'),' ',sub('ψ','ed,N'),' ',sub('N','b')))
    _math(doc,group(sub('N','b'),' = 24 ',radical(sub('f','c,psi')),' ',_text_power_sub('h','calc,pol','1,5'),' [lbf];   ',sub('A','Nco'),' = 9 ',_text_power_sub('h','calc','2')))
    _math(doc,group(sub('ψ','ec,N'),' = ',frac('1',group('1 + ',frac(sub('e','x'),group('1,5 ',sub('h','calc'))))),' × ',frac('1',group('1 + ',frac(sub('e','y'),group('1,5 ',sub('h','calc')))))))
    _math(doc,group(sub('ψ','ed,N'),' = min(1; 0,7 + 0,3 ',frac(sub('c','min'),group('1,5 ',sub('h','calc'))),')'))
    doc.add_paragraph('Unidades da expressão básica: polegadas, psi e lbf; 1 in=25,4 mm, 1 psi=0,006894757293168 MPa e 1 lbf=4,4482216152605 N. Não se aplica o coeficiente 24 diretamente em mm/MPa. ψc,N=ψcp,N=1. Não se usa o aumento opcional de grande embutimento.')
    doc.add_paragraph('ANc é a união das projeções quadradas de lado 3hcalc, recortada nos limites reais do bloco; não se usa simplesmente a caixa envolvente de um conjunto em L. Para três ou mais bordas do envelope do grupo a menos de 1,5hef físico, hcalc=min[hef físico; max(cmax/1,5; smax/3)]. cmax considera somente essas bordas influentes; smax é o maior passo adjacente da malha Tipo 1. O ajuste não altera a posição física da cabeça. Excentricidade usa resultante de tração em relação ao centro das barras tracionadas, não ao centro da placa ou da área recortada.')
    table(doc,['Barras / base','hef / hcalc (mm)','ANc (mm²)','ψec / ψed','Tração / φNcb (kN)','η'],[
        (', '.join(g['ids'])+(' · extra' if g['basis']=='supplemental' else ' · ACI'),number(g['hef'],2)+' / '+number(g['hcalc'],2),number(g['area'],1),number(g['psi_ec'],4)+' / '+number(g['psi_ed'],4),number(g['demand']/1000,3)+' / '+number(g['resistance']/1000,3),number(g['ratio'],3)) for g in cone['groups']
    ],[1.1,1.1,1.15,1.15,1.6,.85])
    g=cone['governing']
    doc.add_paragraph('Resultado governante do cone: '+', '.join(g['ids'])+'; η='+number(g['ratio'],3)+'; '+('ATENDE' if g['ratio']<=1 else 'NÃO ATENDE')+' A ESTA VERIFICAÇÃO. '+('Resultado suplementar conservador da aplicação.' if g['basis']=='supplemental' else 'Grupo tracionado conectado do método ACI.'))
    doc.add_paragraph('ANCORAGEM COMPLETA A COMPLEMENTAR: pullout, ruptura lateral (side-face blowout), fendilhamento/cobrimentos/detalhamento, cortante/pryout/interação no concreto, rigidez/apoio local da cabeça/porca/chapa e bloco armado. O limite local 5db²σc,Rd da rota NBR de cortante não substitui nenhuma dessas verificações.')


def create_report(c,r,detailed=False):
    if not r.geometry or any(i.severity=='error' for i in r.issues):
        raise ValueError('Corrija os dados e obtenha uma solução de equilíbrio antes de gerar a memória.')
    a=r.geometry;ref=detail_reference(c);doc=Document();sec=doc.sections[0]
    native=c.shear_path=='anchors' and getattr(c,'anchor_shear_model','external')=='welded_washer'
    # Mantém a página A4 e a identidade das memórias técnicas existentes.
    sec.page_width=Inches(8.27);sec.page_height=Inches(11.69)
    sec.top_margin=sec.bottom_margin=Inches(.6);sec.left_margin=sec.right_margin=Inches(.65)
    for name in ('Normal','Title','Subtitle','Heading 1','Heading 2'):
        sty=doc.styles[name];sty.font.name='Arial';sty.font.color.rgb=RGBColor(0,0,0)
    for sty in doc.styles:
        for border in sty.element.xpath('.//w:pBdr'):border.getparent().remove(border)
    doc.styles['Normal'].font.size=Pt(9.5);doc.styles['Normal'].paragraph_format.space_after=Pt(5)
    doc.styles['Title'].font.size=Pt(20);doc.styles['Heading 1'].font.size=Pt(12);doc.styles['Heading 2'].font.size=Pt(10)
    if c.shear_path=='plate' or native:
        doc.styles['Normal'].paragraph_format.space_after=Pt(4)
        doc.styles['Heading 1'].paragraph_format.space_before=Pt(8)
        doc.styles['Heading 2'].paragraph_format.space_before=Pt(6)
    doc.core_properties.title='Placa de base Tipo 1 com quatro chumbadores externos'
    doc.core_properties.author='LRO Soluções de engenharia LTDA.'
    doc.add_paragraph('Placa de base Tipo 1',style='Title')
    doc.add_paragraph('Quatro chumbadores externos e perfil I ou H',style='Subtitle')
    doc.add_paragraph(c.project)
    p=doc.add_paragraph();p.add_run(r.component_status).bold=True
    doc.add_paragraph(r.calculation_note)
    intro='Esta memória verifica a chapa sem enrijecedores, a pressão de contato no concreto e a ruptura à tração do aço dos chumbadores sob N, M e V de cálculo. A resistência ao deslizamento segue o caminho selecionado. '
    if c.shear_path=='plate':intro+='Inclui o contato, a flexão e o cisalhamento locais da chave de chapa única, suas ações obrigatórias para solda e o momento adicional V·eV no equilíbrio global. '
    if native:intro+='Inclui o cortante pelos quatro chumbadores com arruelas soldadas, condicionado às trações individuais, o limite local de concreto e a ação obrigatória de cada solda. '
    if c.cone_model!='off':intro+='Cone de tração ACI complementar em seção própria, quando os dados e o domínio permitem. '
    doc.add_paragraph(intro+'Os resultados não aprovam a base completa nem determinam sua rigidez rotacional.')
    doc.add_picture(BytesIO(image_bytes(c,r)),width=Inches(6.95))
    doc.add_paragraph('O perfil e a placa estão em proporção. O trecho de ancoragem é esquemático. A geometria Tipo 1 escolhida mantém a mesma distância a1 da mesa à linha dos chumbadores e da linha à borda; placas com outro arranjo exigem outro modelo de cálculo, não sendo fisicamente proibidas.')
    doc.add_page_break()
    doc.add_paragraph('Dados e materiais',style='Heading 1')
    rows=[('Pilar',c.column.name,decimal_text(f'd={c.column.d:g}; bf={c.column.bf:g}; tw={c.column.tw:g}; tf={c.column.tf:g} mm')),
          ('Placa',c.plate_steel,f'{number(c.L)} × {number(c.B)} × {number(c.tp,4)} mm'),
          ('Chumbadores','4 barras ASTM A36',ref['label']+' = '+number(c.db,3)+' mm; fu=400 MPa'),
          ('Arranjo Tipo 1','Simétrico',f'a1={number(c.a1)}; a2={number(c.a2)}; a={number(c.a)} mm'),
          ('Concreto e graute','Argamassa expansiva',f'fck={number(c.fck)} MPa; graute={number(c.grout_fck)} MPa; e={number(c.grout_t)} mm'),
          ('Aço da placa','Resistência característica',f'fy={number(c.fy)} MPa; fu={number(STEELS[c.plate_steel].fu)} MPa')]
    if c.shear_path=='plate':
        rows.extend([
            ('Chave de chapa única',c.lug_steel,f'bh={number(c.lug_bh)}; bv={number(c.lug_bv)}; tpv={number(c.lug_t)} mm'),
            ('Aço da chave','Resistência característica',f'fy={number(c.lug_fy)} MPa; fu={number(c.lug_fu)} MPa'),
        ])
    if native:
        rows.append(('Arruelas adotadas','4 quadradas soldadas; fy=345 MPa',
                     f'{number(c.anchor_washer_side)} × {number(c.anchor_washer_side)} × {number(c.anchor_washer_t,3)} mm; furo Ø{number(c.anchor_washer_hole,3)} mm'))
    table(doc,['Componente','Especificação','Dimensões e resistências'],rows,[1.25,2.15,3.55])
    doc.add_paragraph('Combinações usuais: γa1=1,10; γa2=1,35; γc=1,40. Nenhuma nova majoração das ações. Pressão resistente da placa de base sem aumento por confinamento: A2/A1=1.' if c.shear_path=='plate' else 'Combinações usuais: γa1=1,10; γa2=1,35; γc=1,40. Nenhuma nova majoração das ações. Pressão resistente sem aumento por confinamento: A2/A1=1.')
    doc.add_paragraph('Ações e equilíbrio',style='Heading 1')
    table(doc,['N em kgf','M em kgf·m','V em kgf','Caso'],[(number(c.N/KGF),number(c.M/(KGF*1000)),number(c.V/KGF),a['case'])],[1.75,1.75,1.75,1.7])
    doc.add_paragraph('Ações referidas à face superior da placa. N positivo: compressão; negativo: tração. Momento no eixo de maior inércia. O cortante tem caminho resistente próprio.')
    if native:
        doc.add_paragraph('V positivo atua em +x; M positivo é horário no corte, comprimindo o lado +x. '
                          'Nesta rota, M informado é preservado, sem transporte automático do cortante; '
                          'a flexão local da barra está incluída no parâmetro α de 6.7.2.5.')
    if c.shear_path=='plate':
        doc.add_paragraph('A tabela anterior preserva as ações informadas. V positivo atua em +x; M positivo é horário no corte '
                          'e comprime o lado +x. A reação da chave acrescenta ΔM com o sinal de V. '
                          'O equilíbrio e o dimensionamento da placa e dos chumbadores usam Mef=M+ΔM.')
        table(doc,['Transporte das ações','Valor','Unidade'],[
            ('M informado com sinal',number(a['M_input']/1e6,6),'kN·m'),
            ('eV = tp + (bv + en)/2',number(a['eV'],3),'mm'),
            ('ΔM = V · eV com sinal',number(a['delta_M']/1e6,6),'kN·m'),
            ('Mef = M informado + ΔM',number(a['M_effective']/1e6,6),'kN·m'),
        ],[4.15,1.9,.9])
        doc.add_page_break()
        doc.add_paragraph('Resultados do equilíbrio e ações da chave',style='Heading 1')
    rows=[('Comprimento do bloco equivalente lc',number(a['lc'],3),'mm'),
          ('Pressão uniforme σSd / σRd',number(a['sigma'],4)+' / '+number(c.sigma_rd,4),'MPa'),
          ('Resultante comprimida C',number(a['C']/KGF),'kgf'),
          ('Tração total nos quatro chumbadores',number(a['T_total']/KGF),'kgf'),
          ('Tração por chumbador na linha mais solicitada',number(a['Ft_max']/KGF),'kgf'),
          ('Tração por chumbador na outra linha',number(a['Ft_min']/KGF),'kgf'),
          ('Espessura requerida / adotada',number(a['t_required'],3)+' / '+number(c.tp,3),'mm'),
          ('Diâmetro requerido pelo aço / adotado',number(a['db_required'],3)+' / '+number(c.db,3),'mm')]
    table(doc,['Grandeza','Valor','Unidade'],rows,[4.15,1.9,.9])
    doc.add_paragraph('Resíduo numérico de equilíbrio: '+f'N={a["residual_N"]:.3e} N; M={a["residual_M"]:.3e} N·mm. Esses resíduos verificam o cálculo estático e não constituem resistência adicional.')
    if c.shear_path=='plate':_lug_actions(doc,c,a)
    if native:
        doc.add_page_break()
        _anchor_shear_actions(doc,c,a)
    if any((c.anchor_type!='unspecified',c.cone_model!='off',c.base_fixity!='unspecified',c.stiffener_detail!='none',c.weld_web_type!='unspecified',c.weld_flange_type!='unspecified')):
        _detail_and_cone_report(doc,c,r)
    doc.add_page_break()
    doc.add_paragraph('Verificações dos componentes',style='Heading 1')
    doc.add_paragraph('Índice η = solicitação/resistência ou espessura requerida/adotada, limitado a 1,000. “Atende” vale exclusivamente para cada verificação indicada.')
    rows=[]
    for row in r.checks:
        sd,unit=display(row.demand,row.unit);rd,_=display(row.resistance,row.unit)
        rows.append((row.name,sd,rd,unit,number(row.ratio,3),'Sim' if row.passed else 'Não'))
    table(doc,['Verificação','Solicitação','Resistência ou limite','Unid.','η','Atende'],rows,[3.05,.9,.95,.55,.65,.85])
    doc.add_paragraph('Caminho do cortante',style='Heading 2')
    if c.shear_path=='friction':
        doc.add_paragraph('Atrito entre placa e graute expansivo, μ=0,45 conforme NBR 6.7.2.2. VRd='+number(a['friction_rd']/KGF)+' kgf. Não há contribuição dos chumbadores. Sem contato comprimido, a resistência por atrito é nula.')
    elif native:
        doc.add_paragraph('Cortante pelos próprios chumbadores com arruelas soldadas, calculado pela NBR 6.7.2.5. '
                          'VRd,grupo='+number(a['anchor_shear']['group_rd']/KGF)+' kgf, resultante da soma das capacidades '
                          'individuais já limitadas pela tração simultânea e pelo limite local de concreto. '
                          'Não se soma atrito ou chave. Soldas, transferência local, ancoragem e bloco permanecem a complementar.')
    elif c.shear_path=='anchors':
        doc.add_paragraph('Cortante pelos próprios chumbadores. VRd externo do grupo instalado para a combinação atual: '+number(c.anchor_shear_rd/KGF)+' kgf. Referência: '+(c.anchor_shear_ref or 'NÃO INFORMADA')+'. O app faz somente uma comparação documental, sem somar atrito ou chave. Resistência ao corte, interação tração–cisalhamento, efeitos locais e transferência ao concreto não são calculados neste módulo; a memória externa deve cobrir os esforços combinados e a excentricidade da reação. Esta rota preserva M informado, sem transporte automático V·e; a memória externa deve fornecer as ações resultantes adequadas para a base.')
        doc.add_paragraph('Aplicabilidade documentada para estes dados: '+('confirmada pelo usuário' if c.anchor_capacity_confirmed else 'PENDENTE')+'. A confirmação é invalidada por alterações nas ações, geometria, materiais, resistência ou referência. Não é certificação da base ou validação da memória externa pelo app.')
    elif c.shear_path=='plate':
        doc.add_paragraph('Chave de chapa única para o cortante total. As verificações locais de contato, flexão e cisalhamento '
                          'constam acima; não há soma de atrito. As ações Vw e Mw para as soldas são apresentadas separadamente. '
                          'A ligação da chave, o concreto e o bloco continuam com verificações complementares pendentes.')
    else:
        doc.add_paragraph('Dispositivo externo para o cortante total. Resistência de cálculo informada: '+number(c.external_shear_rd/KGF)+' kgf. Referência: '+(c.external_shear_ref or 'NÃO INFORMADA')+'. O app compara V com a resistência informada, sem calcular o dispositivo ou somar atrito.')
        if getattr(c,'external_shape',''):doc.add_paragraph('Configuração informada do dispositivo externo: '+EXTERNAL_SHAPES.get(c.external_shape,c.external_shape)+'. O formato é descritivo e não altera a resistência documentada.')
    for i in r.issues:
        if i.severity!='excluded':
            p=doc.add_paragraph(i.text);p.add_run(' ['+i.reference+']')
    heading=doc.add_paragraph('Referência de detalhamento da Tabela 18 corrigida',style='Heading 1')
    if c.shear_path=='plate' or native:heading.paragraph_format.page_break_before=True
    doc.add_paragraph('Valores de referência para a bitola selecionada. A tabela foi substituída na versão corrigida de 2025. Estes valores orientam o próximo detalhamento; não demonstram que o bloco ou a ancoragem do projeto foram executados ou dimensionados.')
    if native:doc.add_paragraph('A arruela desta tabela é uma referência de mínimo. O cálculo nativo e o desenho usam o lado e a espessura efetivamente informados, apresentados em Dados e materiais; o furo adotado é db+1,5 mm.')
    rows=[('Furo da placa df',number(ref['df'])+' mm'),
          ('Arruela especial em aço fy=345 MPa',f'{number(ref["washer_side"])} × {number(ref["washer_side"])} × {number(ref["washer_t"])} mm; furo '+number(ref['washer_hole'],3)+' mm'),
          ('Chumbador e porcas pesadas',f'h1={ref["h1"]}; h2={ref["h2"]}; r1={ref["r1"]}; r2={ref["r2"]} mm'),
          ('Bloco de referência Nb × Bb × Ab',f'{number(ref["Nb"])} × {number(ref["Bb"])} × {number(ref["Ab"])} mm'),
          ('Armadura mínima tabulada',f'Ø{number(ref["rebar_diameter"])} a cada {number(ref["S"])} mm; da≤{number(ref["da_max"])} mm'),
          ('Materiais e afastamento tabulados',f'fck,min={ref["fck_min"]} MPa; en={ref["en"]} mm; a3={ref["a3"]} mm')]
    table(doc,['Item de referência','Valor da tabela e dimensões derivadas'],rows,[2.35,4.6])
    doc.add_paragraph('Nb=max[Nb,min; L+2en; L+2(a3−a1)]; Bb=max[B+2en; B+2(a3−a1)]; Ab=max[h1+100; Nb]. A armadura do bloco deve ser dimensionada conforme NBR 6118; se da exceder metade de h1−0,5(r2+db), a armadura mínima deve ser recalculada. Se a1/a2 diferirem dos tabulados, a ancoragem e o detalhamento precisam de verificação específica.')
    doc.add_page_break()
    doc.add_paragraph('Equações e substituições',style='Heading 1')
    doc.add_paragraph('Cálculo em N, mm e MPa; resultados de forças convertidos para kgf com 1 kgf=9,80665 N. Bloco uniforme de compressão da NBR 6.7; não se aplica a distribuição triangular/trapezoidal elástica nem o limite e=L/6.')
    _equilibrium_equations(doc,c,a)
    if native:
        doc.add_paragraph('Equações do cortante com arruelas soldadas',style='Heading 2')
        _anchor_shear_equations(doc)
        doc.add_paragraph('Vaço,Rd,i é o limite conservador de 6.7.2.5, com Ft,máx no termo subtrativo; '
                          'Vint,Rd,i é o limite adicional de 6.3.3.4. '
                          'Usam-se fy,b=250 MPa, fub=400 MPa, γa1=1,10 e γa2=1,35. '
                          'A interação é aplicada à tração individual obtida do equilíbrio; nenhuma parcela do cortante aplicado é presumida por barra.')
    if a['C']:
        _math(doc,group('m = (L − 0,95d)/2;   n = (B − 0,80bf)/2;   ',sub('n','0'),' = ',frac(radical('d bf'),'4')))
        doc.add_paragraph('Em C1/C2/C3, com lc≥m, lmax=max(m;n;λn0); com lc<m, lmax=max[√(lc(2m−lc));n]. Em T3 e no limite de momento puro, o termo λn0 não é utilizado. A espessura final é a maior entre as parcelas de contato e tração.')
    if c.shear_path=='plate' or native:
        doc.add_page_break()
        doc.add_paragraph('Equações das verificações dos componentes',style='Heading 1')
    chosen=r.checks if detailed else [x for x in r.checks if x.id not in ('bp_grout','bp_width')]
    for row in chosen:
        start=len(doc.paragraphs)
        doc.add_paragraph(row.name,style='Heading 2');_check_equation(doc,row)
        doc.add_paragraph(decimal_text(row.substitution))
        doc.add_paragraph(row.variables+' Referência: '+row.reference+'.')
        for para in doc.paragraphs[start:-1]:para.paragraph_format.keep_with_next=True
    if c.shear_path!='anchors' or native:doc.add_page_break()
    final_section_start=len(doc.paragraphs)
    doc.add_paragraph('Premissas e verificações complementares',style='Heading 1')
    for text in c.assumptions:doc.add_paragraph(text)
    if c.notes:doc.add_paragraph('Observações do projeto: '+c.notes)
    doc.add_paragraph('Referências',style='Heading 1')
    doc.add_paragraph(NBR+', 6.6.5 e 6.7.1–6.7.2.3; tabela 18 e expressão de X conforme a versão corrigida 2025. Resistências de cálculo das combinações usuais, tabela 3.')
    if native:
        doc.add_paragraph(NBR+', 6.7.2.5: cortante pelos chumbadores com arruelas soldadas, capacidades condicionadas à tração, '
                          'soma das barras e ação das soldas sem redução. '
                          '6.3.3.1–6.3.3.2: resistências básicas da barra; 6.3.3.4: limite adicional de interação; '
                          '6.6.5: pressão resistente de concreto com A2/A1=1. '
                          'As verificações locais de contato e rasgamento da arruela conforme 6.3.3.3, '
                          'o dimensionamento das soldas e a transferência local à placa permanecem pendentes.')
    if c.shear_path=='plate':
        doc.add_paragraph(NBR+', 6.7.2.4 e Figura 24: geometria da chave, contato, espessura e ações obrigatórias para as soldas; '
                          '6.5.5(a) e (b): escoamento e ruptura por cisalhamento da chapa. '
                          'O dimensionamento da solda e do metal-base, incluindo as condições de 6.2 e da Tabela 9, permanece pendente.')
        doc.add_paragraph('AISC Design Guide 1, Base Connection Design for Steel Structures, 3ª edição, 2024, pp. 79–82 e 89–90: '
                          'efeito do cortante excêntrico no equilíbrio global e flexão local da placa. '
                          'eV=tp+(bv+en)/2 e ΔM=V·eV são obtidos por estática para a referência adotada; '
                          'não são apresentados como equação numerada da NBR. Não se calcula resistência de solda por este guia neste módulo.')
    doc.add_paragraph('ABNT NBR 6118, para o dimensionamento complementar do bloco e suas armaduras. Esta memória não completa as verificações da ancoragem no concreto. O cone de tração, quando selecionado, aparece separadamente como base ACI complementar.')
    if c.cone_model!='off':doc.add_paragraph(CONE_SOURCE+'; DG1 4.3.2.2, pp. 29–33; exemplos 4.7-3, 4.7-5 e 4.7-15. Método básico em unidades US; sem ganho opcional para grande embutimento.')
    doc.add_paragraph(BRAND)
    p=doc.add_paragraph('LRO Ligações '+VERSION+' · ');hyperlink(p,'LinkedIn — Lucas Oliveira',LINK)
    if native:
        # Reserva espaço para a identificação ao final sem uma página órfã.
        for para in doc.paragraphs[final_section_start:]:
            para.paragraph_format.space_after=Pt(3)
        doc.paragraphs[-2].paragraph_format.keep_with_next=True
    out=BytesIO();doc.save(out);return out.getvalue()
