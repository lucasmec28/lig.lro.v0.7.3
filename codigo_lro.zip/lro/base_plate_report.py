"""Memória editável PT-BR da base Tipo 1; mesma geometria e motor da tela."""
from io import BytesIO
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from .models import KGF,STEELS,VERSION
from .base_plate import NBR,G1,G2,GC,MU,detail_reference
from .base_plate_drawing import image_bytes
from .report import BRAND,LINK,number,display,decimal_text,table,hyperlink,_math,group,sub,frac,power,radical


def _equilibrium_equations(doc,c,a):
    case=a['case']
    _math(doc,group('L = d + 4',sub('a','1'),';   B = ',sub('a','2'),' + 2',sub('a','1'),';   a = L/2 − ',sub('a','1')))
    _math(doc,group(sub('σ','Rd'),' = ',frac(group('0,85',sub('f','ck')),sub('γ','c')),';   ',sub('A','2'),'/',sub('A','1'),' = 1'))
    if case.startswith('C'):
        _math(doc,group('e = |M|/N;   ',sub('e','crit'),' = ',frac(group('L − N/(',sub('σ','Rd'),' B)'),'2')))
        _math(doc,group('X = ',frac('4 d bf',power('(d + bf)')),' ',frac('N',group('L B ',sub('σ','Rd'))),' ≤ 1'))
        _math(doc,group('λ = min(1; ',frac(group('2',radical('X')),group('1 + ',radical('1 − X'))),')'))
    if case=='C1': _math(doc,group(sub('l','c'),' = L;   C = N;   ',sub('F','t,Sd'),' = 0'))
    elif case=='C2': _math(doc,group(sub('l','c'),' = L − 2e;   C = N;   ',sub('F','t,Sd'),' = 0'))
    elif case in ('C3','T3','M0'):
        term='|M| + N a' if case=='C3' else ('|M| − U a' if case=='T3' else '|M|')
        _math(doc,group('H = L/2 + a;   D = ',power('H'),' − ',frac(group('2(',term,')'),group(sub('σ','Rd'),' B')),' ≥ 0'))
        _math(doc,group(sub('l','c'),' = H − ',radical('D'),';   C = ',sub('σ','Rd'),' B ',sub('l','c')))
        _math(doc,group(sub('F','t,Sd'),' = ',frac(group('2(C ', '− N)' if case=='C3' else ('+ U)' if case=='T3' else ')')),sub('n','b'))))
        doc.add_paragraph('A implementação usa a raiz equivalente racionalizada lc = [2(|M| + N a)/(σRd B)]/[H + √D], com N algébrico, para evitar perda de precisão. A solução exige 0 < lc ≤ L, tração não negativa e compressão total N ≤ σRd L B.')
    elif case in ('T1','T2'):
        _math(doc,group('U = −N;   ',sub('F','t,máx'),' = ',frac('U',sub('n','b')),' + ',frac('|M|',group('a ',sub('n','b')))))
        _math(doc,group(sub('F','t,mín'),' = ',frac('U',sub('n','b')),' − ',frac('|M|',group('a ',sub('n','b'))),';   C = 0'))
    _math(doc,group('C − 2',sub('F','t,máx'),' − 2',sub('F','t,mín'),' = N'))
    _math(doc,group('C ',sub('x','C'),' − 2',sub('F','t,máx'),' ',sub('x','T,máx'),' − 2',sub('F','t,mín'),' ',sub('x','T,mín'),' = M'))
    doc.add_paragraph('N positivo comprime. U é a magnitude da tração axial. Ft,máx e Ft,mín são forças individuais nas duas linhas, com dois chumbadores em cada linha; x indica a posição algébrica em relação ao centro da placa. O sinal de M troca as linhas. lc é o comprimento do bloco equivalente uniforme de compressão; não é uma previsão elástica de abertura ou deslocamento.')


def _check_equation(doc,row):
    key=row.id
    if key=='bp_plate_contact':
        expr=group(sub('t','min,c'),' = ',sub('l','max'),radical(frac(group('2',sub('σ','Sd')),frac(sub('f','y'),sub('γ','a1')))))
    elif key=='bp_plate_tension':
        expr=group(sub('t','min,t'),' = ',radical(frac(group('2',sub('n','b'),sub('F','t,Sd'),'(m − ',sub('a','1'),')'),group('B ',frac(sub('f','y'),sub('γ','a1'))))))
    elif key=='bp_anchor_steel':
        expr=group(sub('F','t,Rd'),' = ',frac(group('0,75 π',power(sub('d','b')),sub('f','u')),group('4',sub('γ','a2'))))
    elif key=='bp_contact':
        expr=group(sub('σ','Sd'),' = ',frac('C',group('B ',sub('l','c'))),' ≤ ',frac(group('0,85',sub('f','ck')),sub('γ','c')))
    elif key=='bp_shear':
        expr=group(sub('V','Rd'),' = min(',frac(group('0,45 C'),sub('γ','a2')),'; ',sub('τ','Rd'),' L B)')
    elif key=='bp_grout':expr=group(sub('f','ck,graute'),' ≥ 2',sub('f','ck'))
    elif key=='bp_width':expr=group('B ≥ bf + 25 mm')
    else:expr=group('|',sub('V','Sd'),'| ≤ ',sub('V','Rd,dispositivo'))
    _math(doc,expr)


def create_report(c,r,detailed=False):
    if not r.geometry or any(i.severity=='error' for i in r.issues):
        raise ValueError('Corrija os dados e obtenha uma solução de equilíbrio antes de gerar a memória.')
    a=r.geometry;ref=detail_reference(c);doc=Document();sec=doc.sections[0]
    # Mantém a página A4 e a identidade das memórias técnicas existentes.
    sec.page_width=Inches(8.27);sec.page_height=Inches(11.69)
    sec.top_margin=sec.bottom_margin=Inches(.6);sec.left_margin=sec.right_margin=Inches(.65)
    for name in ('Normal','Title','Subtitle','Heading 1','Heading 2'):
        sty=doc.styles[name];sty.font.name='Arial';sty.font.color.rgb=RGBColor(0,0,0)
    for sty in doc.styles:
        for border in sty.element.xpath('.//w:pBdr'):border.getparent().remove(border)
    doc.styles['Normal'].font.size=Pt(9.5);doc.styles['Normal'].paragraph_format.space_after=Pt(5)
    doc.styles['Title'].font.size=Pt(20);doc.styles['Heading 1'].font.size=Pt(12);doc.styles['Heading 2'].font.size=Pt(10)
    doc.core_properties.title='Placa de base Tipo 1 com quatro chumbadores externos'
    doc.core_properties.author='LRO Soluções de engenharia LTDA.'
    doc.add_paragraph('Placa de base Tipo 1',style='Title')
    doc.add_paragraph('Quatro chumbadores externos e perfil I ou H',style='Subtitle')
    doc.add_paragraph(c.project)
    p=doc.add_paragraph();p.add_run(r.component_status).bold=True
    doc.add_paragraph(r.calculation_note)
    doc.add_paragraph('Esta memória verifica a chapa sem enrijecedores, a pressão de contato no concreto e a ruptura à tração do aço dos chumbadores sob N, M e V de cálculo. A resistência ao deslizamento segue o caminho selecionado. Os resultados não aprovam a base completa nem determinam sua rigidez rotacional.')
    doc.add_picture(BytesIO(image_bytes(c,r)),width=Inches(6.95))
    doc.add_paragraph('O perfil e a placa estão em proporção. O trecho de ancoragem é esquemático. A geometria Tipo 1 escolhida mantém a mesma distância a1 da mesa à linha dos chumbadores e da linha à borda; placas com outro arranjo exigem outro modelo de cálculo, não sendo fisicamente proibidas.')
    doc.add_page_break()
    doc.add_paragraph('Dados e materiais',style='Heading 1')
    rows=[('Pilar',c.column.name,decimal_text(f'd={c.column.d:g}; bf={c.column.bf:g}; tw={c.column.tw:g}; tf={c.column.tf:g} mm')),
          ('Placa',c.plate_steel,f'{number(c.L)} × {number(c.B)} × {number(c.tp,4)} mm'),
          ('Chumbadores','4 barras ASTM A36',ref['label']+' = '+number(c.db,3)+' mm; fu=400 MPa'),
          ('Arranjo Tipo 1','Simétrico',f'a1={number(c.a1)}; a2={number(c.a2)}; a={number(c.a)} mm'),
          ('Concreto e graute','Argamassa expansiva',f'fck={number(c.fck)} MPa; graute={number(c.grout_fck)} MPa; e={number(c.grout_t)} mm'),
          ('Aço da placa','Resistência característica',f'fy={number(c.fy)} MPa; fu={number(STEELS[c.plate_steel].fu)} MPa')]
    table(doc,['Componente','Especificação','Dimensões e resistências'],rows,[1.25,2.15,3.55])
    doc.add_paragraph('Combinações usuais: γa1=1,10; γa2=1,35; γc=1,40. Nenhuma nova majoração das ações. Pressão resistente sem aumento por confinamento: A2/A1=1.')
    doc.add_paragraph('Ações e equilíbrio',style='Heading 1')
    table(doc,['N em kgf','M em kgf·m','V em kgf','Caso'],[(number(c.N/KGF),number(c.M/(KGF*1000)),number(c.V/KGF),a['case'])],[1.75,1.75,1.75,1.7])
    doc.add_paragraph('Ações referidas à face superior da placa. N positivo: compressão; negativo: tração. Momento no eixo de maior inércia. O cortante tem caminho resistente próprio.')
    rows=[('Comprimento do bloco equivalente lc',number(a['lc'],3),'mm'),
          ('Pressão uniforme σSd / σRd',number(a['sigma'],4)+' / '+number(c.sigma_rd,4),'MPa'),
          ('Resultante comprimida C',number(a['C']/KGF),'kgf'),
          ('Tração total nos quatro chumbadores',number(a['T_total']/KGF),'kgf'),
          ('Tração por chumbador na linha mais solicitada',number(a['Ft_max']/KGF),'kgf'),
          ('Tração por chumbador na outra linha',number(a['Ft_min']/KGF),'kgf'),
          ('Espessura requerida / adotada',number(a['t_required'],3)+' / '+number(c.tp,3),'mm'),
          ('Diâmetro requerido pelo aço / adotado',number(a['db_required'],3)+' / '+number(c.db,3),'mm')]
    table(doc,['Grandeza','Valor','Unidade'],rows,[4.15,1.9,.9])
    doc.add_paragraph('Resíduo numérico de equilíbrio: '+f'N={a["residual_N"]:.3e} N; M={a["residual_M"]:.3e} N·mm. Esses resíduos verificam o cálculo estático e não constituem resistência adicional.')
    doc.add_page_break()
    doc.add_paragraph('Verificações dos componentes',style='Heading 1')
    doc.add_paragraph('Índice η = solicitação/resistência ou espessura requerida/adotada, limitado a 1,000. “Atende” vale exclusivamente para cada verificação indicada.')
    rows=[]
    for row in r.checks:
        sd,unit=display(row.demand,row.unit);rd,_=display(row.resistance,row.unit)
        rows.append((row.name,sd,rd,unit,number(row.ratio,3),'Sim' if row.passed else 'Não'))
    table(doc,['Verificação','Solicitação','Resistência ou limite','Unid.','η','Atende'],rows,[3.05,.9,.95,.55,.65,.85])
    doc.add_paragraph('Caminho do cortante',style='Heading 2')
    if c.shear_path=='friction':
        doc.add_paragraph('Atrito entre placa e graute expansivo, μ=0,45 conforme NBR 6.7.2.2. VRd='+number(a['friction_rd']/KGF)+' kgf. Não há contribuição dos chumbadores. Sem contato comprimido, a resistência por atrito é nula.')
    else:
        doc.add_paragraph('Dispositivo externo para o cortante total. Resistência de cálculo informada: '+number(c.external_shear_rd/KGF)+' kgf. Referência: '+(c.external_shear_ref or 'NÃO INFORMADA')+'. O app compara V com a resistência informada, sem calcular o dispositivo ou somar atrito.')
    for i in r.issues:
        if i.severity!='excluded':
            p=doc.add_paragraph(i.text);p.add_run(' ['+i.reference+']')
    doc.add_paragraph('Referência de detalhamento da Tabela 18 corrigida',style='Heading 1')
    doc.add_paragraph('Valores de referência para a bitola selecionada. A tabela foi substituída na versão corrigida de 2025. Estes valores orientam o próximo detalhamento; não demonstram que o bloco ou a ancoragem do projeto foram executados ou dimensionados.')
    rows=[('Furo da placa df',number(ref['df'])+' mm'),
          ('Arruela especial em aço fy=345 MPa',f'{number(ref["washer_side"])} × {number(ref["washer_side"])} × {number(ref["washer_t"])} mm; furo '+number(ref['washer_hole'],3)+' mm'),
          ('Chumbador e porcas pesadas',f'h1={ref["h1"]}; h2={ref["h2"]}; r1={ref["r1"]}; r2={ref["r2"]} mm'),
          ('Bloco de referência Nb × Bb × Ab',f'{number(ref["Nb"])} × {number(ref["Bb"])} × {number(ref["Ab"])} mm'),
          ('Armadura mínima tabulada',f'Ø{number(ref["rebar_diameter"])} a cada {number(ref["S"])} mm; da≤{number(ref["da_max"])} mm'),
          ('Materiais e afastamento tabulados',f'fck,min={ref["fck_min"]} MPa; en={ref["en"]} mm; a3={ref["a3"]} mm')]
    table(doc,['Item de referência','Valor da tabela e dimensões derivadas'],rows,[2.35,4.6])
    doc.add_paragraph('Nb=max[Nb,min; L+2en; L+2(a3−a1)]; Bb=max[B+2en; B+2(a3−a1)]; Ab=max[h1+100; Nb]. A armadura do bloco deve ser dimensionada conforme NBR 6118; se da exceder metade de h1−0,5(r2+db), a armadura mínima deve ser recalculada. Se a1/a2 diferirem dos tabulados, a ancoragem e o detalhamento precisam de verificação específica.')
    doc.add_page_break()
    doc.add_paragraph('Equações e substituições',style='Heading 1')
    doc.add_paragraph('Cálculo em N, mm e MPa; resultados de forças convertidos para kgf com 1 kgf=9,80665 N. Bloco uniforme de compressão da NBR 6.7; não se aplica a distribuição triangular/trapezoidal elástica nem o limite e=L/6.')
    _equilibrium_equations(doc,c,a)
    if a['C']:
        _math(doc,group('m = (L − 0,95d)/2;   n = (B − 0,80bf)/2;   ',sub('n','0'),' = ',frac(radical('d bf'),'4')))
        doc.add_paragraph('Em C1/C2/C3, com lc≥m, lmax=max(m;n;λn0); com lc<m, lmax=max[√(lc(2m−lc));n]. Em T3 e no limite de momento puro, o termo λn0 não é utilizado. A espessura final é a maior entre as parcelas de contato e tração.')
    chosen=r.checks if detailed else [x for x in r.checks if x.id not in ('bp_grout','bp_width')]
    for row in chosen:
        start=len(doc.paragraphs)
        doc.add_paragraph(row.name,style='Heading 2');_check_equation(doc,row)
        doc.add_paragraph(decimal_text(row.substitution))
        doc.add_paragraph(row.variables+' Referência: '+row.reference+'.')
        for para in doc.paragraphs[start:-1]:para.paragraph_format.keep_with_next=True
    doc.add_page_break()
    doc.add_paragraph('Premissas e verificações complementares',style='Heading 1')
    for text in c.assumptions:doc.add_paragraph(text)
    if c.notes:doc.add_paragraph('Observações do projeto: '+c.notes)
    doc.add_paragraph('Referências',style='Heading 1')
    doc.add_paragraph(NBR+', 6.6.5 e 6.7.1–6.7.2.3; tabela 18 e expressão de X conforme a versão corrigida 2025. Resistências de cálculo das combinações usuais, tabela 3.')
    doc.add_paragraph('ABNT NBR 6118, para o dimensionamento complementar do bloco e suas armaduras. Esta memória não executa as verificações da ancoragem no concreto.')
    doc.add_paragraph(BRAND)
    p=doc.add_paragraph('LRO Ligações '+VERSION+' · ');hyperlink(p,'LinkedIn — Lucas Oliveira',LINK)
    out=BytesIO();doc.save(out);return out.getvalue()
