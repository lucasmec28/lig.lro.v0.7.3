"""Memória editável PT-BR da base Tipo 1; mesma geometria e motor da tela."""
from io import BytesIO
from docx import Document
from docx.oxml import OxmlElement
from docx.shared import Inches,Pt,RGBColor
from .models import KGF,STEELS,VERSION
from .base_plate import NBR,G1,G2,GC,MU,EXTERNAL_SHAPES,detail_reference
from .base_plate_drawing import image_bytes
from .base_plate_detail_drawing import detail_image_bytes
from .base_plate_details import ANCHOR_TYPES,FIXITIES,weld_description,grout_geometry
from .concrete_anchorage import SOURCE as CONE_SOURCE
from .report import BRAND,LINK,number,display,decimal_text,table,hyperlink,_math,group,sub,frac,power,radical

ACTIVE_KEY_PATHS=('cross_active_plate','w_flange_plates')


def _text_sub(base,index):
    """Índice descritivo, sem converter a palavra 'int' em operador integral."""
    element=sub(base,index)
    for run in element.xpath('.//m:sub//m:r',namespaces={'m':'http://schemas.openxmlformats.org/officeDocument/2006/math'}):
        properties=OxmlElement('m:rPr');properties.append(OxmlElement('m:nor'))
        run.insert(0,properties)
    return element


def _text_power_sub(base,index,exponent):
    """Explicit combined script avoids LibreOffice parsing a nested 'in' token."""
    element=OxmlElement('m:sSubSup')
    for tag,value in [('e',base),('sub',index),('sup',exponent)]:
        slot=OxmlElement('m:'+tag)
        for run in group(value):
            props=OxmlElement('m:rPr');props.append(OxmlElement('m:nor'));run.insert(0,props);slot.append(run)
        element.append(slot)
    return element


def _equilibrium_equations(doc,c,a):
    case=a['case']
    active=c.shear_path in ACTIVE_KEY_PATHS
    arm=lambda: sub('H','eq') if active else 'H'
    if c.shear_path=='plate' or c.shear_path in ACTIVE_KEY_PATHS:
        if c.shear_path in ACTIVE_KEY_PATHS:
            _math(doc,group(sub('e','V'),' = ',sub('t','p'),' + ',frac('H + g','2')))
        else:
            _math(doc,group(sub('e','V'),' = ',sub('t','p'),' + ',frac(group(sub('b','v'),' + ',sub('e','n')),'2')))
        _math(doc,group('ΔM = V ',sub('e','V'),';   ',sub('M','ef'),' = ',sub('M','informado'),' + ΔM'))
        doc.add_paragraph('Transporte estático das ações da face superior da placa até a reação da chave. '
                          'Somam-se M informado e ΔM com seus sinais, uma única vez; somente depois se toma o módulo. '
                          'Nas equações de equilíbrio a seguir, M designa Mef. O sinal de Mef define os lados comprimido e tracionado.')
    _math(doc,group('L = d + 4',sub('a','1'),';   B = ',sub('a','2'),' + 2',sub('a','1'),';   a = ',group(sub('a','2'),'/2') if c.model_type==2 else group('L/2 − ',sub('a','1'))))
    if c.model_type==2:
        doc.add_paragraph('Tipo 2: quatro chumbadores em (±a₂/2; ±a₂/2), internos às mesas e ao lado da alma. Somente N e V aplicados; M aplicado=0. O M usado no equilíbrio é exclusivamente o momento local da reação de V, quando houver. Domínio restrito a C1/C2/T1/T2.')
    _math(doc,group(sub('σ','Rd'),' = ',frac(group('0,85',sub('f','ck')),sub('γ','c')),';   ',sub('A','2'),'/',sub('A','1'),' = 1'))
    if case.startswith('C'):
        _math(doc,group('e = |M|/N;   ',sub('e','crit'),' = ',frac(group('L − N/(',sub('σ','Rd'),' B)'),'2')))
        _math(doc,group('X = ',frac('4 d bf',power('(d + bf)')),' ',frac('N',group('L B ',sub('σ','Rd'))),' ≤ 1'))
        _math(doc,group('λ = min(1; ',frac(group('2',radical('X')),group('1 + ',radical('1 − X'))),')'))
    if case=='C1': _math(doc,group(sub('l','c'),' = L;   C = N;   ',sub('F','t,Sd'),' = 0'))
    elif case=='C2': _math(doc,group(sub('l','c'),' = L − 2e;   C = N;   ',sub('F','t,Sd'),' = 0'))
    elif case in ('C3','T3','M0'):
        term='|M| + N a' if case=='C3' else ('|M| − U a' if case=='T3' else '|M|')
        _math(doc,group(arm(),' = L/2 + a;   D = ',power(arm()),' − ',frac(group('2(',term,')'),group(sub('σ','Rd'),' B')),' ≥ 0'))
        _math(doc,group(sub('l','c'),' = ',arm(),' − ',radical('D'),';   C = ',sub('σ','Rd'),' B ',sub('l','c')))
        _math(doc,group(sub('F','t,Sd'),' = ',frac(group('2(C ', '− N)' if case=='C3' else ('+ U)' if case=='T3' else ')')),sub('n','b'))))
        doc.add_paragraph('A implementação usa a raiz equivalente racionalizada lc = [2(|M| + N a)/(σRd B)]/['+
                          ('Heq' if active else 'H')+' + √D], com N algébrico, para evitar perda de precisão. A solução exige 0 < lc ≤ L, tração não negativa e compressão total N ≤ σRd L B.'+
                          (' Heq é o braço auxiliar do equilíbrio da base; H continua sendo a projeção física da chave.' if active else ''))
    elif case in ('T1','T2'):
        _math(doc,group('U = −N;   ',sub('F','t,máx'),' = ',frac('U',sub('n','b')),' + ',frac('|M|',group('a ',sub('n','b')))))
        _math(doc,group(sub('F','t,mín'),' = ',frac('U',sub('n','b')),' − ',frac('|M|',group('a ',sub('n','b'))),';   C = 0'))
    _math(doc,group('C − 2',sub('F','t,máx'),' − 2',sub('F','t,mín'),' = N'))
    _math(doc,group('C ',sub('x','C'),' − 2',sub('F','t,máx'),' ',sub('x','T,máx'),' − 2',sub('F','t,mín'),' ',sub('x','T,mín'),' = M'))
    doc.add_paragraph('N positivo comprime. U é a magnitude da tração axial. Ft,máx e Ft,mín são forças individuais nas duas linhas, com dois chumbadores em cada linha; x indica a posição algébrica em relação ao centro da placa. O sinal de M troca as linhas. lc é o comprimento do bloco equivalente uniforme de compressão; não é uma previsão elástica de abertura ou deslocamento.')


def _check_equation(doc,row):
    key=row.id
    if key=='bp_anchor_shear_native':
        expr=group('|',sub('V','Sd'),'| ≤ ',sub('V','Rd,grupo'),' = Σ ',sub('V','Rd,i'))
    elif key=='bp_anchor_shear_special':
        expr=group('|',sub('V','Sd'),'| ≤ Σ min(',sub('V','aço,Rd,i'),'; 5',power(sub('d','b')),sub('σ','c,Rd'),')')
    elif key=='bp_anchor_shear_interaction':
        expr=group('|',sub('V','Sd'),'| ≤ Σ ',_text_sub('V','int,Rd,i'))
    elif key.startswith('bp_cone_'):
        expr=group('φ',sub('N','cb'),' = 0,70 ',frac(sub('A','Nc'),sub('A','Nco')),' ',sub('ψ','ec,N'),' ',sub('ψ','ed,N'),' ',sub('N','b'))
    elif key.startswith('bp_skw_'):
        equations = {
            'bp_skw_leg_min': group('z ≥ ', sub('z','min'), '(', sub('t','menor'), ')'),
            'bp_skw_length_min': group(sub('L','eff'), ' ≥ max(40 mm; 4z)'),
            'bp_skw_shelf': group('z ≤ ', frac(group('L − ', sub('t','chave')), '2')),
            'bp_skw_key_face': group('z ≤ H'),
            'bp_skw_metal': group('q = ', radical(group(power(sub('q','x')), ' + ', power(sub('q','z')))),
                                  ' ≤ ', sub('q','Rd'), ' = ', frac(group('0,6 ', sub('f','w'), ' a'), sub('γ','w2'))),
        }
        expr=equations.get(key,group(row.equation))
    elif key.startswith('bp_skc_edge_'):
        expr=group('φ',sub('V','cb'),' = 0,65 ',sub('k','par'),' ',frac(sub('A','Vc'),sub('A','Vco')),' ',sub('ψ','ed'),' ',sub('V','b'),';   ',sub('ψ','h'),' = 1')
    elif key.startswith('bp_skc_bearing_'):
        expr=group('φ',sub('V','brg'),' = 0,65 × 1,7 ',sub('f′','c'),' b min(h; 2t) ',sub('ψ','brg'))
    elif key.startswith('bp_skc_embedment_'):
        expr=group(sub('h','ef'),' ≥ 2,5h;   ',sub('h','ef'),' ≥ 2,5',sub('c','sl'))
    elif key.startswith('bp_anchor_washer_'):
        expr=group(row.equation)
    elif key.startswith(('bp_lug_','bp_active_','bp_uw_','bp_cc_','bp_skc_','bp_cw_','bp_cwq_')):
        # Mantém toda equação do motor em OMML editável, inclusive novos
        # controles de geometria, sem cair na fórmula do dispositivo externo.
        expr=group(row.equation)
    elif key=='bp_shear_anchors_external':expr=group(row.equation)
    elif key=='bp_plate_contact':
        expr=group(sub('t','min,c'),' = ',sub('l','max'),radical(frac(group('2',sub('σ','Sd')),frac(sub('f','y'),sub('γ','a1')))))
    elif key=='bp_plate_tension' and 'l0' in row.equation:
        expr=group(sub('t','min,t'),' = ',radical(frac(group(sub('n','b'),sub('F','t,Sd'),'(',sub('a','2'),' − ',sub('t','w'),')'),group(sub('l','0'),' ',frac(sub('f','y'),sub('γ','a1'))))),';   ',sub('l','0'),' = min[d; ',sub('a','2'),' + 1,75(',sub('a','2'),' − ',sub('t','w'),')]')
    elif key=='bp_plate_tension':
        expr=group(sub('t','min,t'),' = ',radical(frac(group('2',sub('n','b'),sub('F','t,Sd'),'(m − ',sub('a','1'),')'),group('B ',frac(sub('f','y'),sub('γ','a1'))))))
    elif key=='bp_anchor_steel':
        expr=group(sub('F','t,Rd'),' = ',frac(group('0,75 π',power(sub('d','b')),sub('f','u')),group('4',sub('γ','a2'))))
    elif key=='bp_contact':
        expr=group(sub('σ','Sd'),' = ',frac('C',group('B ',sub('l','c'))),' ≤ ',frac(group('0,85',sub('f','ck')),sub('γ','c')))
    elif key=='bp_shear':
        expr=group(sub('V','Rd'),' = min(',frac(group('0,45 C'),sub('γ','a2')),'; ',sub('τ','Rd'),' L B)')
    elif key=='bp_grout':expr=group(sub('f','ck,graute'),' ≥ 2',sub('f','ck'))
    elif key=='bp_width':expr=group('B ≥ bf + 25 mm')
    else:expr=group('|',sub('V','Sd'),'| ≤ ',sub('V','Rd,dispositivo'))
    _math(doc,expr)


def _anchor_shear_equations(doc):
    """Equações da NBR 6.7.2.5 em OMML, sem rateio fictício do esforço."""
    _math(doc,group(sub('A','b'),' = ',frac(group('π',power(sub('d','b'))),'4'),';   ',
                    sub('F','v,Rd'),' = ',frac(group('0,45',sub('A','b'),sub('f','ub')),sub('γ','a2'))))
    _math(doc,group('α = 1,45',frac(group(sub('t','p'),' + ',frac(sub('t','a'),'2')),sub('d','b')),
                    frac(sub('f','ub'),sub('f','y,b')),frac(sub('γ','a1'),sub('γ','a2'))))
    _math(doc,group(sub('V','aço,Rd,i'),' = max[0; ',frac(
        group(radical(group('(1 + ',power('α'),')',power(sub('F','v,Rd')),' − ',
                            power(group('(0,533',sub('F','t,Sd,i'),')')))),
              ' − α(0,533',sub('F','t,máx'),')'),group('1 + ',power('α'))),']'))
    _math(doc,group(_text_sub('V','int,Rd,i'),' = ',sub('F','v,Rd'),radical(group('1 − ',
                    power(group('(',frac(sub('F','t,Sd,i'),sub('F','t,Rd')),')')))),
                    ';   0 ≤ ',sub('F','t,Sd,i'),' ≤ ',sub('F','t,Rd')))
    _math(doc,group(sub('σ','c,Rd'),' = ',frac(group('0,85',sub('f','ck')),sub('γ','c')),';   ',
                    sub('V','Rd,i'),' = min(',sub('V','aço,Rd,i'),'; ',_text_sub('V','int,Rd,i'),'; 5',power(sub('d','b')),sub('σ','c,Rd'),')'))
    _math(doc,group(sub('V','Rd,grupo'),' = ',sub('V','Rd,1'),' + ',sub('V','Rd,2'),' + ',sub('V','Rd,3'),' + ',sub('V','Rd,4'),
                    ';   |',sub('V','Sd'),'| ≤ ',sub('V','Rd,grupo')))


def _anchor_shear_actions(doc,c,a):
    """Capacidades condicionais das quatro barras e ação integral de solda."""
    shear=a['anchor_shear']
    doc.add_paragraph('Cortante nativo com arruelas soldadas',style='Heading 1')
    doc.add_paragraph('Quatro barras ASTM A36 e quatro arruelas especiais quadradas idênticas, soldadas à face superior da placa. '
                      'As quatro barras devem estar efetivamente mobilizadas, com furos-padrão nas arruelas. '
                      'O modelo usa a tração individual da mesma combinação N–M e soma as quatro capacidades condicionais '
                      'conforme NBR 6.7.2.5. O cortante total é resistido por esse caminho, sem soma de atrito ou chave.')
    doc.add_paragraph('Arruelas adotadas: '+number(c.anchor_washer_side)+' × '+number(c.anchor_washer_side)+' × '+
                      number(c.anchor_washer_t,3)+' mm; furo Ø'+number(c.anchor_washer_hole,3)+' mm; aço fy=345 MPa. '
                      'Essas são as dimensões reais usadas no cálculo e no desenho; a Tabela 18 aparece separadamente como referência.')
    table(doc,['Barra','x e y (mm)','Ft,Sd,i (kN)','Vaço,Rd,i (kN)','Vint,Rd,i (kN)','VRd,i (kN)','Domínio'],[
        (rod['id'],number(rod['x'],3)+'; '+number(rod['y'],3),number(rod['tension']/1000,4),
         number(rod['steel_rd']/1000,4) if rod['domain_ok'] else 'Inválido',
         number(rod['combined_rd']/1000,4) if rod['domain_ok'] else 'Inválido',
         number(rod['rd']/1000,4) if rod['domain_ok'] else 'Sem crédito',
         'Válido' if rod['domain_ok'] else 'Não atende') for rod in shear['rods']
    ],[.45,1.35,1.,1.05,1.05,1.05,1.])
    doc.add_paragraph('Origem no centro da placa; x paralelo a L e y paralelo a B. A1 e A2 estão em x=−a; '
                      'A3 e A4, em x=+a. M positivo comprime +x e traciona −x; M negativo troca as linhas. '
                      'V positivo atua em +x. A tabela apresenta capacidades condicionais, sem impor uma distribuição '
                      'do cortante aplicado entre as barras.')
    table(doc,['Grandeza do modelo','Valor','Unidade'],[
        ('α com fy,b=250 MPa e fub=400 MPa',number(shear['alpha'],6),'—'),
        ('Fv,Rd sem redução por tração e flexão local',number(shear['shear_unreduced_rd']/1000,6),'kN/barra'),
        ('Ft,Rd para o limite adicional de interação',number(shear['tension_rd']/1000,6),'kN/barra'),
        ('Ft,máx no termo subtrativo conservador',number(shear['subtractive_tension']/1000,6),'kN'),
        ('Limite local 5db²σc,Rd',number(shear['concrete_cap']/1000,6),'kN/barra'),
        ('Soma das quatro capacidades VRd,grupo',number(shear['group_rd']/1000,6),'kN'),
        ('Cortante aplicado com sinal',number(c.V/1000,6),'kN'),
    ],[4.15,1.9,.9])
    doc.add_paragraph('Fv,Rd usa roscas no plano de corte, conforme NBR 6.3.3.2. '
                      'O fy,b de α é a resistência ao escoamento da barra ASTM A36, e não a da placa ou da arruela. '
                      'Vaço,Rd,i é o limite conservador de 6.7.2.5, preservando o coeficiente 0,533. '
                      'Vint,Rd,i é o limite adicional da interação geral de 6.3.3.4, expresso como capacidade para a tração individual atual. '
                      'O limite local de concreto usa σc,Rd=0,85fck/γc, com A2/A1=1; '
                      'não comprova a ancoragem ou a resistência do grupo no concreto. '
                      'Se o domínio de uma barra não for atendido, a memória sinaliza a falha e não lhe atribui crédito resistente.')
    doc.add_paragraph('Índices da expressão impressa: o radical usa Ft,Sd,i e o termo subtrativo apresenta Ft,Sd,1. '
                      'O cálculo mantém a tração individual no radical e usa a maior tração simultânea Ft,máx no termo subtrativo '
                      'de todas as barras, adotando um limite conservador para ambas as leituras. '
                      'Valores resultantes negativos recebem capacidade nula. '
                      'Essa escolha não é apresentada como transcrição literal nem como correção da norma.')
    doc.add_paragraph(('M aplicado é zero no Tipo 2. Não se acrescenta V·tp ou V·graute à rota de arruelas soldadas. ' if c.model_type==2 else 'M informado é preservado na face superior da placa. Não se acrescenta automaticamente V·tp ou V·graute. ')+
                      'O termo tp+ta/2 integra o parâmetro local α da NBR 6.7.2.5; não é um transporte global das ações. '
                      'Outra referência de carregamento ou excentricidade global exige avaliação específica.')
    doc.add_paragraph('Ação obrigatória para a solda de cada arruela',style='Heading 2')
    _math(doc,group(sub('F','w,Sd,arruela'),' = ',sub('F','v,Rd')))
    doc.add_paragraph('Cada solda de arruela deve resistir a Fv,Rd sem redução = '+
                      number(shear['weld_force_per_washer']/1000,6)+' kN. '
                      'A ação não é limitada pela capacidade reduzida VRd,i nem pelo cortante aplicado. '
                       + ('O submodelo local selecionado é apresentado em seção própria.' if c.upper_washer.model!='off' else 'Não se calcula resistência ou utilização da solda nesta etapa.'))
    doc.add_paragraph('As verificações locais selecionadas aparecem em seção própria; permanecem a complementar os modos não cobertos, '
                      'o metal-base e a transferência local entre arruela e placa, incluindo flexão, pressão de contato e '
                      'rasgamento em furos conforme 6.3.3.3; '
                      'a ancoragem completa e os modos de concreto não cobertos pelos cálculos complementares selecionados; '
                      'o bloco armado e sua ligação à fundação. Também permanecem pendentes as soldas do pilar. '
                      'O cone de tração e os demais componentes de ancoragem aparecem em seções próprias quando selecionados. O atendimento do aço e do limite local não aprova a base completa.')


def _lug_actions(doc,c,a):
    """Ações normativas de solda, sem inventar uma resistência da ligação."""
    lug=a['lug']
    doc.add_paragraph('Chapa única para o cortante',style='Heading 2')
    doc.add_paragraph('Uma chapa retangular vertical centrada na base, com bh na direção y, espessura tpv na direção x '
                      'e cortante perpendicular à face. A projeção bv é medida abaixo da face inferior da placa. '
                      'A espessura real do graute é en='+number(c.grout_t)+' mm; a altura efetiva de contato é bv−en. '
                      'A chave recebe o cortante total, sem soma de atrito.')
    _math(doc,group(sub('σ','chave,Rd'),' = ',frac(group('1,7',sub('f','ck')),sub('γ','c')),
                    ';   ',sub('A','2'),'/',sub('A','1'),' = 4'))
    _math(doc,group(sub('A','contato'),' = ',sub('b','h'),'(',sub('b','v'),' − ',sub('e','n'),');   ',
                    sub('V','contato,Rd'),' = ',sub('σ','chave,Rd'),' ',sub('A','contato')))
    doc.add_paragraph('O aumento de contato A2/A1=4 é prescrito para a chave pela NBR 6.7.2.4. '
                      'O contato da própria placa de base permanece com A2/A1=1. '
                      'Contato, flexão e cisalhamento da chapa são verificações locais independentes; '
                      'seu mínimo não constitui resistência certificada do dispositivo completo.')
    doc.add_paragraph('Ações obrigatórias para dimensionar as soldas',style='Heading 2')
    if c.single_key_weld.model!='off':
        doc.add_paragraph('Vw e Mw nesta seção são magnitudes de capacidade prescritas. Os sinais do caso, inclusive o envelope positivo em V=0, constam da seção do componente dos dois filetes.')
    _math(doc,group(sub('V','w'),' = ',sub('V','contato,Rd')))
    _math(doc,group(sub('M','w'),' = ',frac(group(sub('σ','chave,Rd'),' ',sub('b','h'),
                    '(',power(sub('b','v')),' − ',power(sub('e','n')),')'),'2'),
                    ' = ',sub('V','w'),frac(group(sub('b','v'),' + ',sub('e','n')),'2')))
    table(doc,['Ação para a solda','Valor','Unidade'],[
        ('Vw igual à resistência de contato',number(lug['weld_V']/1000,6),'kN'),
        ('Mw na face inferior da placa',number(lug['weld_M']/1e6,6),'kN·m'),
    ],[4.15,1.9,.9])
    doc.add_paragraph('A NBR 6.7.2.4 exige essas ações a partir da resistência de contato, mesmo que superem o cortante '
                      'aplicado ou as resistências locais do aço da chave. Não se limita Vw pela menor resistência da chapa. '
                      'Mw é a ação local para a solda na face inferior; ΔM é o transporte da ação aplicada para o equilíbrio global. '
                      'Não são somados entre si.')
    doc.add_paragraph(('Componente dos dois filetes selecionado: metal de solda, detalhamento numérico e vínculo de execução apresentados em seção própria. Permanecem pendentes o metal-base, ' if c.single_key_weld.model!='off' else 'Permanecem pendentes o dimensionamento e o detalhamento das soldas da chave, inclusive metal de solda e metal-base, ') +
                      'a flexão local da placa na fixação da chave, ' +
                      ('os modos de concreto não cobertos pelo componente ACI conservador da seção própria, ' if c.single_key_concrete.model!='off' else 'a ruptura e os efeitos de borda do concreto, ') +
                      'o bloco armado e sua transferência à fundação. Também permanecem pendentes a ancoragem no concreto '
                      'e as soldas do pilar. Um resultado local que atende não aprova o dispositivo completo.')


def _active_key_equations(doc):
    """NBR plate expressions with explicit strip substitutions, native OMML."""
    _math(doc,group(sub('b','contato,i'),' = Σ ',sub('b','ij'),';   ',sub('b','cálculo,i'),' = ',sub('b','contato,i')))
    _math(doc,group(sub('F','ij'),' = ',sub('F','i'),frac(sub('b','ij'),sub('b','contato,i')),
                    ';   ',sub('σ','Rd'),' = ',frac(group('1,7 ',sub('f','ck')),sub('γ','c'))))
    _math(doc,group(sub('A','i'),' = ',sub('b','contato,i'),'(H − g);   ',sub('R','contato,i'),' = ',sub('σ','Rd'),' ',sub('A','i')))
    _math(doc,group(sub('z','R'),' = ',frac('H + g','2'),';   ',sub('M','raiz,i'),' = ',sub('F','i'),' ',sub('z','R')))
    _math(doc,group(sub('t','req,i'),' = ',radical(frac(group('2 |',sub('F','i'),'| (H + g)'),
                    group(sub('b','cálculo,i'),' (',frac(sub('f','y'),sub('γ','a1')),')')))))
    _math(doc,group(sub('R','flexão,i'),' = ',frac(group(sub('b','cálculo,i'),' (',frac(sub('f','y'),sub('γ','a1')),') ',power('t')),group('2 (H + g)'))))
    _math(doc,group(sub('R','escoamento,i'),' = ',frac(group('0,60 ',sub('f','y'),' ',sub('b','cálculo,i'),' t'),sub('γ','a1')),
                    ';   ',sub('R','ruptura,i'),' = ',frac(group('0,60 ',sub('f','u'),' ',sub('b','cálculo,i'),' t'),sub('γ','a2'))))
    _math(doc,group(sub('F','+'),' = αV;   ',sub('F','−'),' = (1 − α)V;   Σ ',sub('F','i'),' = V'))
    _math(doc,group('Σ ',sub('M','raiz,i'),' = V ',sub('z','R'),';   ',sub('e','V'),' = ',sub('t','p'),' + ',sub('z','R'),
                    ';   ',sub('M','ef'),' = M + V ',sub('e','V')))
    _math(doc,group(sub('V','w,i'),' = ',sub('R','contato,i'),';   ',sub('M','w,i'),' = ',sub('R','contato,i'),' ',sub('z','R')))


def _interval_text(intervals):
    return '; '.join('['+number(lo,3)+'; '+number(hi,3)+']' for lo,hi in intervals)


def _active_key_actions(doc,c,a):
    """Full component evidence; demands and prescribed weld actions stay apart."""
    key=c.active_key;data=a['active_key'];plates=data['plates']
    is_w=c.shear_path=='w_flange_plates'
    doc.add_paragraph(data['scope_label'],style='Heading 1')
    doc.add_paragraph('Método: '+data['method']+'. '+
                      ('Duas mesas contínuas perpendiculares a V. A alma permanece física, sem crédito de resistência ou enrijecimento.' if is_w else
                       'Chapa primária passante e contínua perpendicular a V. A chapa secundária permanece física, sem crédito de resistência ou enrijecimento.'))
    doc.add_paragraph('As expressões de chapa única da NBR são reutilizadas com substituições declaradas por componentes e faixas. '
                      'Não são equações normativas específicas de cruciformes ou perfis W. Somente faixas verticais contínuas atrás do contato '
                      'plano exposto recebem crédito; o aço central permanece desenhado, sem redistribuição lateral presumida. '
                      'Pressão uniforme nos intervalos ao longo de y e de z=g até H. Não se soma atrito, alma ou chapa secundária.')
    steel=STEELS[key.steel]
    geometry=[('Projeção H / graute real g / penetração H−g',f'{number(key.H)} / {number(c.grout_t)} / {number(key.H-c.grout_t)} mm'),
              ('Aço e produto',key.steel+'; '+('laminado' if key.product=='rolled' else 'fabricado')+
               f'; fy={number(steel.fy)} MPa; fu={number(steel.fu)} MPa'),
              ('Orientação local',('Chapas normais a x' if key.orientation=='normal_x' else str(key.orientation))+'; V ao longo de x; larguras ao longo de y'),
              ('Continuidade das chapas ativas / concreto nos contatos',
               ('Confirmada' if key.continuous else 'Pendente')+' / '+('Confirmado' if key.concrete_filled else 'Pendente')),
              ('Referência da geometria',key.geometry_ref or 'Não informada')]
    if is_w:
        geometry.extend([
            ('Geometria própria do W',f'd={number(key.d)}; bf={number(key.bf)}; tw={number(key.tw)}; tf={number(key.tf)} mm'),
            ('Raio real / exclusão central interna',('Não informado' if key.radius is None else number(key.radius)+' mm')+
             ' / '+('Derivada dos intervalos de contato' if key.junction_exclusion is None else number(key.junction_exclusion)+' mm')),
        ])
    else:
        geometry.extend([
            ('Chapa primária física',f'b aço={number(key.b)}; t={number(key.t)} mm'),
            ('Chapa secundária física',f'comprimento={number(key.secondary_length)}; t={number(key.secondary_t)} mm'),
            ('Exclusões por face +x / −x',f'{number(key.cross_exclusion_positive)} / {number(key.cross_exclusion_negative)} mm'),
        ])
    table(doc,['Dado do componente','Valor adotado'],geometry,[2.95,4.])
    table(doc,['Chapa física','x (mm)','b aço (mm)','t (mm)','Face +x: contato y (mm)','Face −x: contato y (mm)'],[
        (p['id'],number(p['x']),number(p['b_steel']),number(p['t']),
         _interval_text(p['contact_by_sign']['positive']),_interval_text(p['contact_by_sign']['negative'])) for p in plates
    ],[.60,.70,.85,.60,2.1,2.1])
    doc.add_paragraph('Os intervalos são a geometria efetivamente usada, inclusive após recarregar o JSON. b aço é a largura física '
                      'completa; b contato e b cálculo são a soma das faixas expostas na face carregada. '
                      'V=0 não solicita cortante, mas ambas as faces continuam registradas.')
    doc.add_paragraph('Partilha das forças e casos simultâneos',style='Heading 2')
    doc.add_paragraph(data['sharing_label'])
    if is_w:
        if key.sharing=='unknown_envelope':
            doc.add_paragraph('Envelope de partilha desconhecida: α∈[0;1]. Cada mesa é verificada separadamente para |V|. '
                              'Os extremos (V;0) e (0;V) são casos alternativos; nunca duas forças V simultâneas ou soma 2V. '
                              'Não há ganho de capacidade por duas mesas. O envelope abrange somente partilhas não negativas deste modelo.')
        elif key.sharing=='equal':
            doc.add_paragraph('Partilha igual escolhida explicitamente: α=0,5. Pressupõe chapas iguais, restrição comum e engajamento suficiente. '
                              'Dimensões metálicas iguais não demonstram reações iguais no concreto, sobretudo com uma face interrompida. '
                              'Trata-se de idealização de engenharia, não de prescrição da NBR.')
        else:
            doc.add_paragraph('Intervalo verificado de α: ['+number(key.alpha_min,5)+'; '+number(key.alpha_max,5)+']. '
                              'Referência: '+key.share_ref+'. Sinais cobertos pela referência: '+
                              {'both':'positivo e negativo','positive':'positivo','negative':'negativo'}.get(key.share_signs,key.share_signs)+'.')
        doc.add_paragraph('F+ é sempre a mesa em x positivo e F− em x negativo. A fração α permanece atribuída à mesma mesa física na reversão. '
                          'Com V>0, F+ carrega a face externa e F− a interna; com V<0, F+ carrega a interna e F− a externa. '
                          'O modelo não abrange forças opostas autoequilibradas, torção, pré-carga ou transferência resistente pela alma.')
    else:
        doc.add_paragraph('A chapa primária P recebe F=V. A secundária não divide a força nem acrescenta resistência local.')
    case_rows=[]
    for i,forces in enumerate(data['allocation_cases'],1):
        for p,force in zip(plates,forces):
            case_rows.append((str(i),p['id'],number(force/1000,6),number(force*data['z_R']/1e6,6),number(sum(forces)/1000,6)))
    table(doc,['Caso','Chapa','Fi com sinal (kN)','mi com sinal (kN·m)','ΣFi do caso (kN)'],case_rows,[.5,.65,1.8,2.,2.])
    doc.add_paragraph('Demanda local por chapa',style='Heading 2')
    doc.add_paragraph(('No envelope, a demanda de cada linha é seu extremo independente. Não se interpreta a tabela como uma alocação simultânea. '
                      if len(data['allocation_cases'])>1 else 'As forças são as da alocação simultânea declarada. ')+
                      'Não se somam resistências de contato. A fixação e o dispositivo completo não são aprovados por esses resultados.')
    table(doc,['Chapa / face','|Fi| (kN)','b contato / cálculo (mm)','t req / real (mm)','mi (kN·m)','Local'],[
        (p['id']+' / '+{'positive':'+x','negative':'−x'}.get(p['loaded_sign'],str(p['loaded_sign'])),
         number(abs(p['force'])/1000,4),number(p['b_contact'])+' / '+number(p['b_calc']),
         number(p['t_required'],4)+' / '+number(p['t']),number(p['M_root']/1e6,6),
         'Atende' if p['local_pass'] else 'Não atende') for p in plates
    ],[.8,.85,1.55,1.4,1.45,.7])
    capacity_rows=[]
    for p in plates:
        for label,name in [('Contato','bearing_rd'),('Flexão','bending_rd'),('Escoamento','yield_rd'),('Ruptura','rupture_rd')]:
            capacity=p[name]
            capacity_rows.append((p['id'],label,number(abs(p['force'])/1000,4),number(capacity/1000,6),number(abs(p['force'])/capacity,4)))
    table(doc,['Chapa','Verificação local','Demanda (kN)','Resistência (kN)','η'],capacity_rows,[.65,1.6,1.5,1.9,1.3])
    doc.add_paragraph('Ações obrigatórias para dimensionar as soldas',style='Heading 2')
    doc.add_paragraph('Por analogia de componentes à NBR 6.7.2.4, Vw,i é a resistência de contato de cada face e Mw,i=Vw,i zR. '
                      'Não se limita Vw pela força aplicada ou pela menor resistência do aço. As magnitudes de ambas as faces são mostradas '
                      'abaixo; na combinação, o sinal acompanha o cortante da chapa. Não são cargas adicionais globais e não se somam a V·eV.')
    weld_rows=[]
    for p in plates:
        for sign in ('positive','negative'):
            face=p['faces'][sign]
            weld_rows.append((p['id'],'+x / V>0' if sign=='positive' else '−x / V<0',number(face['b_contact']),
                              number(face['weld_V']/1000,6),number(face['weld_M']/1e6,6)))
    table(doc,['Chapa','Face / sinal','b contato (mm)','Vw (kN)','Mw (kN·m)'],weld_rows,[.65,1.35,1.4,1.7,1.85])
    if key.weld_geometry:
        import json
        doc.add_paragraph('Geometria de solda de raiz declarada (intervalos y em mm, por chapa e face): '+
                          json.dumps(key.weld_geometry,ensure_ascii=False,sort_keys=True)+'.')
    else:
        doc.add_paragraph('Soldas de raiz: geometria não informada. Não se presume solda contínua nem dois filetes coextensivos em toda a largura.')
    doc.add_paragraph('Resistência de solda PENDENTE. Uma face exterior contínua e uma face interior interrompida não constituem um par de filetes '
                      'de largura total. São necessários segmentos reais, transferência estabelecida, metal de solda, metal-base e flexão local da placa.')
    doc.add_paragraph('Estado separado das verificações',style='Heading 2')
    table(doc,['Escopo','Estado'],[
        ('Verificações locais de chapas ativas','ATENDEM AO MODELO' if data['local_pass'] else 'NÃO ATENDEM AO MODELO'),
        ('Fixação local: soldas, metal-base e flexão da placa','PENDENTE'),
        ('Dispositivo completo e ruptura do concreto da chave','PENDENTE'),
        ('Bordas, interação de grupo e com os chumbadores','PENDENTE'),
        ('Armadura, bloco e transferência à fundação','PENDENTE'),
        ('Ligações e estabilidade da alma / chapa secundária inativa','PENDENTE'),
        ('Soldas do pilar e demais exclusões da ancoragem','A COMPLEMENTAR conforme as seções específicas'),
    ],[5.1,1.85])
    # The generic table helper adds a blank paragraph. Here it can push the
    # short scope qualification onto an otherwise empty continuation page.
    trailing=doc.paragraphs[-1]
    if not trailing.text:trailing._element.getparent().remove(trailing._element)
    doc.add_paragraph('O cone de tração dos chumbadores não verifica automaticamente a ruptura da chave ou sua interação. '
                      'Atendimento local não aprova o dispositivo completo.')


def _detail_and_cone_report(doc,c,r):
    a=r.geometry;cone=a.get('concrete_cone',{});grout=grout_geometry(c)
    doc.add_page_break()
    doc.add_paragraph('Detalhe da ancoragem, vínculo e soldas',style='Heading 1')
    doc.add_picture(BytesIO(detail_image_bytes(c,r)),width=Inches(6.95))
    doc.add_paragraph('Geometria de detalhe com alma vertical em planta. Peça de apoio enterrada e arruela superior da placa são componentes distintos. O desenho não confirma resistência ou rigidez; o cone de tração e os demais modos de ancoragem têm verificações complementares independentes quando selecionados e dentro de seus domínios.')
    table(doc,['Item','Especificação'],[
        ('Família e vínculo',c.catalog_label+('; N/V aplicados, M aplicado=0' if c.model_type==2 else '; M informado preservado')),
        ('Ancoragem enterrada',ANCHOR_TYPES[c.anchor_type]),
        ('Solda da alma',weld_description(c,'web')),
        ('Soldas das mesas',weld_description(c,'flange')),
        ('Enrijecedores','Sem enrijecedores' if c.stiffener_detail=='none' else f'2 triângulos no plano da alma; um além de cada mesa. Projeção {number(c.stiffener_length)}; altura {number(c.stiffener_height)}; t={number(c.stiffener_t)} mm'),
        ('Graute a 45°',f'Face inferior {number(grout["bottom_L"])} × {number(grout["bottom_B"])} mm; área geométrica {number(grout["footprint"])} mm²'),
    ],[1.65,5.3])
    weld_scope=('O componente condicional duas mesas N/M e alma V, sua qualificação e os resultados locais são discriminados em seção própria. Base completa e metal-base local da placa continuam a complementar. ' if c.column_weld.model=='two_flange_normal_web_shear' else 'Não há cálculo geral da resistência das soldas ou do metal-base sob N/M/V. ')
    doc.add_paragraph('Filete de pernas iguais a 90°: a=z/√2. Perna/garganta são medidas do mesmo filete; a troca de modo conserva seu tamanho. CJP exige preparação, execução e inspeção. '+weld_scope+'M no topo da placa não se confunde com Mef de equilíbrio do lado da fundação.')
    if c.stiffener_detail!='none':
        doc.add_paragraph('Interpretação inicial reversível do pedido de dois enrijecedores: chapas triangulares verticais além das mesas, alinhadas com a alma e soldadas às mesas e à placa. Os resultados de chapa e distribuição N–M continuam como referência SEM enrijecedores, sem comprovar a capacidade ou a distribuição real da base enrijecida.')
    doc.add_paragraph('A projeção física do graute a 45° não aumenta a área resistente adotada: contato B×lc; limite de atrito L×B. Não se confunde com a projeção de ruptura do cone de tração.')
    if c.anchor_type!='unspecified' or c.cone_model!='off':
        table(doc,['Dado físico','Valor'],[
            ('Limites reais do bloco',f'x=[{number(c.block_xmin)}; {number(c.block_xmax)}]; y=[{number(c.block_ymin)}; {number(c.block_ymax)}] mm'),
            ('Altura h / hef físico / cobrimento inferior adotado',f'{number(c.block_h)} / {number(c.hef)} / {number(c.anchor_bottom_cover)} mm'),
            ('Peça enterrada x×y×t / extensão inferior completa',f'{number(c.anchor_head_length)}×{number(c.anchor_head_width)}×{number(c.anchor_bearing_t)} / {number(c.anchor_head_t)} mm'),
            ('Porca inferior / furo da chapa / cobertura disponível',f'{number(c.anchor_nut_t)} / {number(c.anchor_head_hole)} / {number(c.block_h-c.hef-c.anchor_head_t)} mm' if c.anchor_type=='buried_plate_nut' else 'Cobrimento disponível '+number(c.block_h-c.hef-c.anchor_head_t)+' mm; '+('área líquida da porca '+number(c.anchor_nut_bearing_area)+' mm²' if c.anchor_type=='buried_nut' else 'cabeça forjada')),
            ('Referência do detalhe',c.anchor_detail_ref or 'Não informada'),
            ('Moldado no local e concreto íntegro','Declarado pelo usuário' if c.anchor_detail_confirmed else 'Pendente'),
        ],[3.3,3.65])
        # The generic table helper adds a trailing empty paragraph; remove it
        # before the next page-start heading so it cannot create a blank page.
        trailing=doc.paragraphs[-1]
        if not trailing.text:trailing._element.getparent().remove(trailing._element)
    if c.cone_model=='off':
        doc.add_paragraph('Cone de concreto por tração não selecionado: não foi atribuída resistência nativa à ancoragem.')
        return
    doc.add_paragraph('Cone de concreto à tração · ACI complementar',style='Heading 1').paragraph_format.page_break_before=True
    doc.add_paragraph(CONE_SOURCE+'. Concreto normal fissurado; sem crédito de armadura suplementar. O valor numérico de fck é usado como resistência especificada cilíndrica f′c. As trações já majoradas do equilíbrio NBR são usadas sem refatoração; φ ACI não recebe γc adicional. Essa base complementar requer aceitação do responsável técnico, não é uma calibração normativa integral NBR/ACI.')
    if cone.get('status')=='pending':
        doc.add_paragraph('DADOS PENDENTES: nenhuma resistência do cone calculada.')
        for reason in cone['reasons']:doc.add_paragraph(reason)
        return
    if cone.get('status')=='not_demanded':
        doc.add_paragraph('NÃO SOLICITADO NESTA COMBINAÇÃO: nenhuma barra está tracionada. Isso não é aprovação da ancoragem ao cortante.')
        return
    doc.add_paragraph('Padrão: grupos efetivamente tracionados e conectados; barras sem tração não ampliam a área. Cones desconectados são verificados separadamente, sem comparação com resistências somadas. '+('Foi ativado o envelope suplementar conservador de subconjuntos; não é uma exigência literal da ACI.' if c.cone_subset_envelope else 'Envelope suplementar conservador de subconjuntos desligado.'))
    table(doc,['Barra','x / y (mm)','Tração simultânea (kN)'],[
        (rod['id'],number(rod['x'])+' / '+number(rod['y']),number(rod['tension']/1000,5)) for rod in cone['rods']
    ],[.6,3.2,3.15])
    _math(doc,group('φ',sub('N','cb'),' = 0,70 ',frac(sub('A','Nc'),sub('A','Nco')),' ',sub('ψ','ec,N'),' ',sub('ψ','ed,N'),' ',sub('N','b')))
    _math(doc,group(sub('N','b'),' = 24 ',radical(sub('f','c,psi')),' ',_text_power_sub('h','calc,pol','1,5'),' [lbf];   ',sub('A','Nco'),' = 9 ',_text_power_sub('h','calc','2')))
    _math(doc,group(sub('ψ','ec,N'),' = ',frac('1',group('1 + ',frac(sub('e','x'),group('1,5 ',sub('h','calc'))))),' × ',frac('1',group('1 + ',frac(sub('e','y'),group('1,5 ',sub('h','calc')))))))
    _math(doc,group(sub('ψ','ed,N'),' = min(1; 0,7 + 0,3 ',frac(sub('c','min'),group('1,5 ',sub('h','calc'))),')'))
    doc.add_paragraph('Unidades da expressão básica: polegadas, psi e lbf; 1 in=25,4 mm, 1 psi=0,006894757293168 MPa e 1 lbf=4,4482216152605 N. Não se aplica o coeficiente 24 diretamente em mm/MPa. ψc,N=ψcp,N=1. Não se usa o aumento opcional de grande embutimento.')
    doc.add_paragraph('ANc é a união das projeções quadradas de lado 3hcalc, recortada nos limites reais do bloco; não se usa simplesmente a caixa envolvente de um conjunto em L. Para três ou mais bordas do envelope do grupo a menos de 1,5hef físico, hcalc=min[hef físico; max(cmax/1,5; smax/3)]. cmax considera somente essas bordas influentes; smax é o maior passo adjacente da malha real da família selecionada. O ajuste não altera a posição física da cabeça. Excentricidade usa resultante de tração em relação ao centro das barras tracionadas, não ao centro da placa ou da área recortada.')
    table(doc,['Barras / base','hef / hcalc (mm)','ANc (mm²)','ψec / ψed','Tração / φNcb (kN)','η'],[
        (', '.join(g['ids'])+(' · extra' if g['basis']=='supplemental' else ' · ACI'),number(g['hef'],2)+' / '+number(g['hcalc'],2),number(g['area'],1),number(g['psi_ec'],4)+' / '+number(g['psi_ed'],4),number(g['demand']/1000,3)+' / '+number(g['resistance']/1000,3),number(g['ratio'],3)) for g in cone['groups']
    ],[1.1,1.1,1.15,1.15,1.6,.85])
    g=cone['governing']
    doc.add_paragraph('Resultado governante do cone: '+', '.join(g['ids'])+'; η='+number(g['ratio'],3)+'; '+('ATENDE' if g['ratio']<=1 else 'NÃO ATENDE')+' A ESTA VERIFICAÇÃO. '+('Resultado suplementar conservador da aplicação.' if g['basis']=='supplemental' else 'Grupo tracionado conectado do método ACI.'))
    doc.add_paragraph('ANCORAGEM COMPLETA A COMPLEMENTAR: pullout, ruptura lateral (side-face blowout), fendilhamento/cobrimentos/detalhamento, cortante/pryout/interação no concreto, rigidez/apoio local da cabeça/porca/chapa e bloco armado. O limite local 5db²σc,Rd da rota NBR de cortante não substitui nenhuma dessas verificações.')


def create_report(c,r,detailed=False):
    if c.shear_path=='plate' and c.single_key_concrete.model!='off':
        from .single_key_concrete_artifacts import require_current_result
        require_current_result(c,r)
    if c.shear_path=='plate' and c.single_key_weld.model!='off':
        from .single_key_weld import result_is_current
        if not result_is_current(c,r):
            raise ValueError('Resultado da solda da chave desatualizado: recalcule para as entradas atuais.')
    if c.column_weld.model=='two_flange_normal_web_shear':
        from .column_base_weld_drawing import require_current_result
        require_current_result(c,r)
    if not r.geometry or any(i.severity=='error' for i in r.issues):
        raise ValueError('Corrija os dados e obtenha uma solução de equilíbrio antes de gerar a memória.')
    a=r.geometry;ref=detail_reference(c);doc=Document();sec=doc.sections[0]
    native=c.shear_path=='anchors' and getattr(c,'anchor_shear_model','external')=='welded_washer'
    active=c.shear_path in ACTIVE_KEY_PATHS
    # Mantém a página A4 e a identidade das memórias técnicas existentes.
    sec.page_width=Inches(8.27);sec.page_height=Inches(11.69)
    sec.top_margin=sec.bottom_margin=Inches(.6);sec.left_margin=sec.right_margin=Inches(.65)
    for name in ('Normal','Title','Subtitle','Heading 1','Heading 2'):
        sty=doc.styles[name];sty.font.name='Arial';sty.font.color.rgb=RGBColor(0,0,0)
    for sty in doc.styles:
        for border in sty.element.xpath('.//w:pBdr'):border.getparent().remove(border)
    doc.styles['Normal'].font.size=Pt(9.5);doc.styles['Normal'].paragraph_format.space_after=Pt(5)
    doc.styles['Title'].font.size=Pt(20);doc.styles['Heading 1'].font.size=Pt(12);doc.styles['Heading 2'].font.size=Pt(10)
    if c.shear_path=='plate' or native or active:
        doc.styles['Normal'].paragraph_format.space_after=Pt(4)
        doc.styles['Heading 1'].paragraph_format.space_before=Pt(8)
        doc.styles['Heading 2'].paragraph_format.space_before=Pt(6)
    doc.core_properties.title=c.catalog_label.replace(' · ',' ')
    doc.core_properties.author='LRO Soluções de engenharia LTDA.'
    doc.add_paragraph(c.catalog_label.replace(' · ',' '),style='Title')
    doc.add_paragraph(('Quatro chumbadores internos · Tipo 2' if c.model_type==2 else 'Quatro chumbadores externos · Tipo 1')+' e perfil I ou H',style='Subtitle')
    if c.migration_message:doc.add_paragraph(c.migration_message)
    doc.add_paragraph(c.project)
    p=doc.add_paragraph();p.add_run(r.component_status).bold=True
    doc.add_paragraph(r.calculation_note)
    intro='Esta memória verifica a chapa sem enrijecedores, a pressão de contato no concreto e a ruptura à tração do aço dos chumbadores sob '+('N e V de cálculo, sem momento aplicado. ' if c.model_type==2 else 'N, M e V de cálculo. ')+'A resistência ao deslizamento segue o caminho selecionado. '
    if c.shear_path=='plate':
        intro+='Inclui o contato, a flexão e o cisalhamento locais da chave de chapa única, suas ações obrigatórias para solda e o momento adicional V·eV no equilíbrio global. '
        if c.single_key_weld.model!='off':intro+='O componente local dos dois filetes é discriminado em seção própria, sem completar a fixação da chave. '
        if c.single_key_concrete.model!='off':intro+='O concreto ACI conservador da chave e os estados nativo/complementar são discriminados em seção própria, sem aprovação da chave ou base completas. '
    if active:intro+='Inclui a verificação local por chapas ativas, com idealização explícita de componentes/faixas, partilha declarada, ações para as soldas e transporte estático V·eV uma única vez. '
    if native:intro+='Inclui o cortante pelos quatro chumbadores com arruelas soldadas, condicionado às trações individuais, o limite local de concreto e a ação obrigatória de cada solda. '
    if c.cone_model!='off':intro+='Cone de tração ACI complementar em seção própria, quando os dados e o domínio permitem. '
    doc.add_paragraph(intro+'Os resultados não aprovam a base completa nem determinam sua rigidez rotacional.')
    doc.add_picture(BytesIO(image_bytes(c,r)),width=Inches(6.95))
    doc.add_paragraph(('A chave e a placa estão em proporção; as bandas coloridas têm espessura gráfica simbólica e comprimentos reais. As forças de casos alternativos não são simultâneas. ' if active else 'O perfil e a placa estão em proporção. O trecho de ancoragem é esquemático. ')+
                      ('A geometria Tipo 2 usa malha quadrada de chumbadores internos, com a=a2/2. L=d+4a1 e B=a2+2a1. A flexão da placa em tração usa o comprimento efetivo l0 limitado por d.' if c.model_type==2 else 'A geometria Tipo 1 escolhida mantém a mesma distância a1 da mesa à linha dos chumbadores e da linha à borda; placas com outro arranjo exigem outro modelo de cálculo, não sendo fisicamente proibidas.'))
    doc.add_page_break()
    doc.add_paragraph('Dados e materiais',style='Heading 1')
    rows=[('Pilar',c.column.name,decimal_text(f'd={c.column.d:g}; bf={c.column.bf:g}; tw={c.column.tw:g}; tf={c.column.tf:g} mm')),
          ('Placa',c.plate_steel,f'{number(c.L)} × {number(c.B)} × {number(c.tp,4)} mm'),
          ('Chumbadores','4 barras ASTM A36',ref['label']+' = '+number(c.db,3)+' mm; fu=400 MPa'),
          (f'Arranjo Tipo {c.model_type}','Simétrico',f'a1={number(c.a1)}; a2={number(c.a2)}; a={number(c.a)} mm'),
          ('Concreto e graute','Argamassa expansiva',f'fck={number(c.fck)} MPa; graute={number(c.grout_fck)} MPa; e={number(c.grout_t)} mm'),
          ('Aço da placa','Resistência característica',f'fy={number(c.fy)} MPa; fu={number(STEELS[c.plate_steel].fu)} MPa')]
    if c.shear_path=='plate':
        rows.extend([
            ('Chave de chapa única',c.lug_steel,f'bh={number(c.lug_bh)}; bv={number(c.lug_bv)}; tpv={number(c.lug_t)} mm'),
            ('Aço da chave','Resistência característica',f'fy={number(c.lug_fy)} MPa; fu={number(c.lug_fu)} MPa'),
        ])
    if native:
        rows.append(('Arruelas adotadas','4 quadradas soldadas; fy=345 MPa',
                     f'{number(c.anchor_washer_side)} × {number(c.anchor_washer_side)} × {number(c.anchor_washer_t,3)} mm; furo Ø{number(c.anchor_washer_hole,3)} mm'))
    if active:
        rows.append(('Chave por chapas ativas',c.active_key.steel,
                     ('Cruciforme: primária passante' if c.shear_path=='cross_active_plate' else 'W: duas mesas contínuas')+
                     '; H='+number(c.active_key.H)+' mm; geometria própria e partilha em seção específica'))
    table(doc,['Componente','Especificação','Dimensões e resistências'],rows,[1.25,2.15,3.55])
    doc.add_paragraph('Combinações usuais: γa1=1,10; γa2=1,35; γc=1,40. Nenhuma nova majoração das ações. Pressão resistente da placa de base sem aumento por confinamento: A2/A1=1.' if c.shear_path=='plate' or active else 'Combinações usuais: γa1=1,10; γa2=1,35; γc=1,40. Nenhuma nova majoração das ações. Pressão resistente sem aumento por confinamento: A2/A1=1.')
    doc.add_paragraph('Ações e equilíbrio',style='Heading 1')
    if c.model_type==2:
        table(doc,['N em kgf','V em kgf','Caso'],[(number(c.N/KGF),number(c.V/KGF),a['case'])],[2.3,2.3,2.35])
        doc.add_paragraph('Momento aplicado: zero, fixo no modelo rotulado. Eventual Mlocal vem somente da excentricidade física da reação de cortante, abaixo discriminada.')
    else:
        table(doc,['N em kgf','M em kgf·m','V em kgf','Caso'],[(number(c.N/KGF),number(c.M/(KGF*1000)),number(c.V/KGF),a['case'])],[1.75,1.75,1.75,1.7])
    doc.add_paragraph('Ações referidas à face superior da placa. N positivo: compressão; negativo: tração. '+('Não há momento aplicado. ' if c.model_type==2 else 'Momento no eixo de maior inércia. ')+'O cortante tem caminho resistente próprio.')
    if native:
        doc.add_paragraph(('V positivo atua em +x. M aplicado é zero e a rota nativa não acrescenta momento global; ' if c.model_type==2 else 'V positivo atua em +x; M positivo é horário no corte, comprimindo o lado +x. Nesta rota, M informado é preservado, sem transporte automático do cortante; ')+
                          'a flexão local da barra está incluída no parâmetro α de 6.7.2.5.')
    if c.shear_path=='plate' or active:
        doc.add_paragraph('A tabela anterior preserva as ações informadas. V positivo atua em +x; M positivo é horário no corte '
                          'e comprime o lado +x. A reação da chave acrescenta ΔM com o sinal de V. '
                          'O equilíbrio e o dimensionamento da placa e dos chumbadores usam Mef=M+ΔM.')
        table(doc,['Transporte das ações','Valor','Unidade'],[
            ('M informado com sinal',number(a['M_input']/1e6,6),'kN·m'),
            ('eV = tp + (H + g)/2' if active else 'eV = tp + (bv + en)/2',number(a['eV'],3),'mm'),
            ('ΔM = V · eV com sinal',number(a['delta_M']/1e6,6),'kN·m'),
            ('Mef = M informado + ΔM',number(a['M_effective']/1e6,6),'kN·m'),
        ],[4.15,1.9,.9])
        if active:doc.add_paragraph('M informado não inclui previamente esta excentricidade. O transporte usa ΣFi=V uma única vez em todos os modos de partilha, inclusive no envelope; sem fator 2, sem braço d/2 e sem cargas de capacidade das soldas.')
        doc.add_page_break()
        doc.add_paragraph('Resultados do equilíbrio e ações da chave',style='Heading 1')
    rows=[('Comprimento do bloco equivalente lc',number(a['lc'],3),'mm'),
          ('Pressão uniforme σSd / σRd',number(a['sigma'],4)+' / '+number(c.sigma_rd,4),'MPa'),
          ('Resultante comprimida C',number(a['C']/KGF),'kgf'),
          ('Tração total nos quatro chumbadores',number(a['T_total']/KGF),'kgf'),
          ('Tração por chumbador na linha mais solicitada',number(a['Ft_max']/KGF),'kgf'),
          ('Tração por chumbador na outra linha',number(a['Ft_min']/KGF),'kgf'),
          ('Espessura requerida / adotada',number(a['t_required'],3)+' / '+number(c.tp,3),'mm'),
          ('Diâmetro requerido pelo aço / adotado',number(a['db_required'],3)+' / '+number(c.db,3),'mm')]
    table(doc,['Grandeza','Valor','Unidade'],rows,[4.15,1.9,.9])
    doc.add_paragraph('Resíduo numérico de equilíbrio: '+f'N={a["residual_N"]:.3e} N; M={a["residual_M"]:.3e} N·mm. Esses resíduos verificam o cálculo estático e não constituem resistência adicional.')
    if c.shear_path=='plate':_lug_actions(doc,c,a)
    if active:
        doc.add_page_break()
        _active_key_actions(doc,c,a)
    if native:
        doc.add_page_break()
        _anchor_shear_actions(doc,c,a)
    if any((c.anchor_type!='unspecified',c.cone_model!='off',c.base_fixity!='unspecified',c.stiffener_detail!='none',c.weld_web_type!='unspecified',c.weld_flange_type!='unspecified')):
        _detail_and_cone_report(doc,c,r)
    from .base_component_report import append_component_report
    append_component_report(doc,c,r,detailed)
    extra_components=c.concrete_components.model!='off' or c.column_weld.model!='off'
    if not active and not extra_components:doc.add_page_break()
    checks_heading=doc.add_paragraph('Verificações dos componentes',style='Heading 1')
    if active or extra_components:checks_heading.paragraph_format.page_break_before=True
    doc.add_paragraph('Índice η = solicitação/resistência ou espessura requerida/adotada, limitado a 1,000. “Atende” vale exclusivamente para cada verificação indicada.')
    rows=[]
    for row in r.checks:
        sd,unit=display(row.demand,row.unit);rd,_=display(row.resistance,row.unit)
        rows.append((row.name,sd,rd,unit,number(row.ratio,3),'Sim' if row.passed else 'Não'))
    table(doc,['Verificação','Solicitação','Resistência ou limite','Unid.','η','Atende'],rows,[3.05,.9,.95,.55,.65,.85])
    doc.add_paragraph('Caminho do cortante',style='Heading 2')
    if c.shear_path=='friction':
        doc.add_paragraph('Atrito entre placa e graute expansivo, μ=0,45 conforme NBR 6.7.2.2. VRd='+number(a['friction_rd']/KGF)+' kgf. Não há contribuição dos chumbadores. Sem contato comprimido, a resistência por atrito é nula.')
    elif native:
        doc.add_paragraph('Cortante pelos próprios chumbadores com arruelas soldadas, calculado pela NBR 6.7.2.5. '
                          'VRd,grupo='+number(a['anchor_shear']['group_rd']/KGF)+' kgf, resultante da soma das capacidades '
                          'individuais já limitadas pela tração simultânea e pelo limite local de concreto. '
                          'Não se soma atrito ou chave. Soldas, transferência local, ancoragem e bloco permanecem a complementar.')
    elif c.shear_path=='anchors':
        doc.add_paragraph('Cortante pelos próprios chumbadores. VRd externo do grupo instalado para a combinação atual: '+number(c.anchor_shear_rd/KGF)+' kgf. Referência: '+(c.anchor_shear_ref or 'NÃO INFORMADA')+'. O app faz somente uma comparação documental, sem somar atrito ou chave. Resistência ao corte, interação tração–cisalhamento, efeitos locais e transferência ao concreto não são calculados neste módulo; a memória externa deve cobrir os esforços combinados e a excentricidade da reação. Esta rota preserva M informado, sem transporte automático V·e; a memória externa deve fornecer as ações resultantes adequadas para a base.')
        doc.add_paragraph('Aplicabilidade documentada para estes dados: '+('confirmada pelo usuário' if c.anchor_capacity_confirmed else 'PENDENTE')+'. A confirmação é invalidada por alterações nas ações, geometria, materiais, resistência ou referência. Não é certificação da base ou validação da memória externa pelo app.')
    elif c.shear_path=='plate':
        doc.add_paragraph('Chave de chapa única para o cortante total. As verificações locais de contato, flexão e cisalhamento '
                          'constam acima; não há soma de atrito. As ações Vw e Mw para as soldas são apresentadas separadamente. '
                          'A ligação da chave, o concreto e o bloco continuam com verificações complementares pendentes.')
    elif active:
        doc.add_paragraph(a['active_key']['scope_label']+'. '+a['active_key']['sharing_label']+'. '
                          'Contato e aço verificados somente nas faixas expostas das chapas perpendiculares a V. '
                          'Não se somam capacidades das mesas, alma, chapa secundária ou atrito. Fixação local, concreto e dispositivo completo permanecem pendentes.')
    else:
        doc.add_paragraph('Dispositivo externo para o cortante total. Resistência de cálculo informada: '+number(c.external_shear_rd/KGF)+' kgf. Referência: '+(c.external_shear_ref or 'NÃO INFORMADA')+'. O app compara V com a resistência informada, sem calcular o dispositivo ou somar atrito.')
        if getattr(c,'external_shape',''):doc.add_paragraph('Configuração informada do dispositivo externo: '+EXTERNAL_SHAPES.get(c.external_shape,c.external_shape)+'. O formato é descritivo e não altera a resistência documentada.')
    for i in r.issues:
        if c.column_weld.model=='two_flange_normal_web_shear' and (i.origin=='column_weld_scope' or i.text==r.calculation_note):
            continue  # Escopo integral já apresentado na seção própria e nas premissas.
        if i.severity!='excluded':
            p=doc.add_paragraph(i.text);p.add_run(' ['+i.reference+']')
    from .upper_washer_artifacts import append_report
    append_report(doc,c,r)
    from .single_key_weld_artifacts import append_report as append_single_key_weld_report
    append_single_key_weld_report(doc,c,r)
    from .single_key_concrete_artifacts import append_report as append_single_key_concrete_report
    append_single_key_concrete_report(doc,c,r)
    heading=doc.add_paragraph('Referência de detalhamento da Tabela 18 corrigida',style='Heading 1')
    if c.shear_path=='plate' or native or active:heading.paragraph_format.page_break_before=True
    doc.add_paragraph('Valores de referência para a bitola selecionada. A tabela foi substituída na versão corrigida de 2025. Estes valores orientam o próximo detalhamento; não demonstram que o bloco ou a ancoragem do projeto foram executados ou dimensionados.')
    if native:doc.add_paragraph('A arruela desta tabela é uma referência de mínimo. O cálculo nativo e o desenho usam o lado e a espessura efetivamente informados, apresentados em Dados e materiais; o furo adotado é db+1,5 mm.')
    rows=[('Furo da placa df',number(ref['df'])+' mm'),
          ('Arruela especial em aço fy=345 MPa',f'{number(ref["washer_side"])} × {number(ref["washer_side"])} × {number(ref["washer_t"])} mm; furo '+number(ref['washer_hole'],3)+' mm'),
          ('Chumbador e porcas pesadas',f'h1={ref["h1"]}; h2={ref["h2"]}; r1={ref["r1"]}; r2={ref["r2"]} mm'),
          ('Bloco de referência Nb × Bb × Ab',f'{number(ref["Nb"])} × {number(ref["Bb"])} × {number(ref["Ab"])} mm'),
          ('Armadura mínima tabulada',f'Ø{number(ref["rebar_diameter"])} a cada {number(ref["S"])} mm; da≤{number(ref["da_max"])} mm'),
          ('Materiais e afastamento tabulados',f'fck,min={ref["fck_min"]} MPa; en={ref["en"]} mm; a3={ref["a3"]} mm')]
    table(doc,['Item de referência','Valor da tabela e dimensões derivadas'],rows,[2.35,4.6])
    doc.add_paragraph(('Tipo 2: margem a3,tab−a1,tab; Nb=max[Nb,min; L+2en; L+2margem]; Bb=max[B+2en; B+2margem]; Ab=max[h1+100; Nb]. ' if c.model_type==2 else 'Nb=max[Nb,min; L+2en; L+2(a3−a1)]; Bb=max[B+2en; B+2(a3−a1)]; Ab=max[h1+100; Nb]. ')+'A armadura do bloco deve ser dimensionada conforme NBR 6118; se da exceder metade de h1−0,5(r2+db), a armadura mínima deve ser recalculada. Se a1/a2 diferirem dos tabulados, a ancoragem e o detalhamento precisam de verificação específica.')
    doc.add_page_break()
    doc.add_paragraph('Equações e substituições',style='Heading 1')
    doc.add_paragraph('Cálculo em N, mm e MPa; resultados de forças convertidos para kgf com 1 kgf=9,80665 N. Bloco uniforme de compressão da NBR 6.7; não se aplica a distribuição triangular/trapezoidal elástica nem o limite e=L/6.')
    _equilibrium_equations(doc,c,a)
    if active:
        doc.add_paragraph('Equações das chapas ativas: substituições por componentes/faixas',style='Heading 2').paragraph_format.page_break_before=True
        _active_key_equations(doc)
        doc.add_paragraph('b cálculo=b contato, sem crédito da banda central. Para a cruz, F=V na chapa primária; α e as identidades F+/F− aplicam-se somente às duas mesas W. '
                          'São magnitudes de resistência por chapa e face, não uma resistência global somada. O momento de raiz preserva o sinal de Fi.')
    if native:
        doc.add_paragraph('Equações do cortante com arruelas soldadas',style='Heading 2')
        _anchor_shear_equations(doc)
        doc.add_paragraph('Vaço,Rd,i é o limite conservador de 6.7.2.5, com Ft,máx no termo subtrativo; '
                          'Vint,Rd,i é o limite adicional de 6.3.3.4. '
                          'Usam-se fy,b=250 MPa, fub=400 MPa, γa1=1,10 e γa2=1,35. '
                          'A interação é aplicada à tração individual obtida do equilíbrio; nenhuma parcela do cortante aplicado é presumida por barra.')
    if a['C']:
        _math(doc,group('m = (L − 0,95d)/2;   n = (B − 0,80bf)/2;   ',sub('n','0'),' = ',frac(radical('d bf'),'4')))
        doc.add_paragraph('Em C1/C2/C3, com lc≥m, lmax=max(m;n;λn0); com lc<m, lmax=max[√(lc(2m−lc));n]. Em T3 e no limite de momento puro, o termo λn0 não é utilizado. A espessura final é a maior entre as parcelas de contato e tração.')
    if c.shear_path=='plate' or native or active:
        doc.add_page_break()
        doc.add_paragraph('Equações das verificações dos componentes',style='Heading 1')
    chosen=r.checks if detailed else [x for x in r.checks if x.id not in ('bp_grout','bp_width')]
    for row in chosen:
        start=len(doc.paragraphs)
        doc.add_paragraph(row.name,style='Heading 2');_check_equation(doc,row)
        doc.add_paragraph(decimal_text(row.substitution))
        doc.add_paragraph(row.variables+' Referência: '+row.reference+'.')
        for para in doc.paragraphs[start:-1]:para.paragraph_format.keep_with_next=True
    if not active and (c.shear_path!='anchors' or native):doc.add_page_break()
    final_section_start=len(doc.paragraphs)
    final_heading=doc.add_paragraph('Premissas e verificações complementares',style='Heading 1')
    if active:final_heading.paragraph_format.page_break_before=True
    for text in c.assumptions:doc.add_paragraph(text)
    if c.notes:doc.add_paragraph('Observações do projeto: '+c.notes)
    doc.add_paragraph('Referências',style='Heading 1')
    doc.add_paragraph(NBR+', 6.6.5 e 6.7.1–6.7.2.3; tabela 18 e expressão de X conforme a versão corrigida 2025. Resistências de cálculo das combinações usuais, tabela 3.')
    if native:
        doc.add_paragraph(NBR+', 6.7.2.5: cortante pelos chumbadores com arruelas soldadas, capacidades condicionadas à tração, '
                          'soma das barras e ação das soldas sem redução. '
                          '6.3.3.1–6.3.3.2: resistências básicas da barra; 6.3.3.4: limite adicional de interação; '
                          '6.6.5: pressão resistente de concreto com A2/A1=1. '
                          'Contato/rasgamento direto e metal das soldas são verificados somente quando selecionado o submodelo local explícito. '
                          'Flexão acoplada e transferência local à placa permanecem pendentes.')
    if c.shear_path=='plate':
        doc.add_paragraph(NBR+', 6.7.2.4 e Figura 24: geometria da chave, contato, espessura e ações obrigatórias para as soldas; '
                          '6.5.5(a) e (b): escoamento e ruptura por cisalhamento da chapa. '
                          + ('Metal dos dois filetes e detalhamento numérico, quando selecionados, estão discriminados em seção própria; metal-base/transferência à placa permanecem pendentes.' if c.single_key_weld.model!='off' else 'O dimensionamento da solda e do metal-base, incluindo as condições de 6.2 e da Tabela 9, permanece pendente.'))
        doc.add_paragraph('AISC Design Guide 1, Base Connection Design for Steel Structures, 3ª edição, 2024, pp. 79–82 e 89–90: '
                          'efeito do cortante excêntrico no equilíbrio global e flexão local da placa. '
                          'eV=tp+(bv+en)/2 e ΔM=V·eV são obtidos por estática para a referência adotada; '
                          'não são apresentados como equação numerada da NBR. ' + ('O componente dos dois filetes combina a idealização de binário local do Ex. 4.7-5, pp. 88–89, com ações e resistência NBR, sem aumento direcional AISC.' if c.single_key_weld.model!='off' else 'Não se calcula resistência de solda por este guia nesta rota.'))
    if active:
        doc.add_paragraph(NBR+', 6.7.2.4, 6.6.5 e 6.5.5: expressões da chapa única reaplicadas com substituições declaradas por componentes/faixas. '
                          'A distribuição uniforme nas faixas, as exclusões de contato e a partilha entre mesas W são idealizações explícitas de engenharia; '
                          'não se atribui à norma uma prescrição de resistência para cruciformes ou perfis W. Método '+a['active_key']['method']+'.')
        doc.add_paragraph('AISC Design Guide 1, Base Connection Design for Steel Structures, 3ª edição, 2024: referência de equilíbrio de soldas e cortante excêntrico. '
                          'No submodelo da chave não se calcula resistência de solda ou metal-base. eV=tp+(H+g)/2 e Mef=M+V eV decorrem da estática da referência declarada, '
                          'sem soma das ações de capacidade de contato ao equilíbrio global.')
    doc.add_paragraph('ABNT NBR 6118, para o dimensionamento complementar do bloco e suas armaduras. Esta memória não completa as verificações da ancoragem no concreto. O cone de tração, quando selecionado, aparece separadamente como base ACI complementar.')
    if c.cone_model!='off':doc.add_paragraph(CONE_SOURCE+'; DG1 4.3.2.2, pp. 29–33; exemplos 4.7-3, 4.7-5 e 4.7-15. Método básico em unidades US; sem ganho opcional para grande embutimento.')
    if c.concrete_components.model!='off':
        doc.add_paragraph('ACI 318-19, 17.6.1, 17.6.3 e 17.6.4: aço em tração, pullout e ruptura lateral; 17.7.1–17.7.3: aço em corte, ruptura por borda e pryout; 17.8: interação. AISC DG1, 3ª edição, 4.3.2 e exemplo 4.7-7: modos individuais/grupais e interação por índices compatíveis. Os estados alternativos e requisitos de aplicação estão identificados na seção de ancoragem.')
    if c.column_weld.model=='two_flange_normal_web_shear':
        doc.add_paragraph('AISC Design Guide 1, Base Connection Design for Steel Structures, 3ª edição: 4.3.2 (transferência e comprimentos efetivos), 4.3.5 (contato preparado), 4.3.6 e 4.3.9–4.3.10 (momento e combinações); exemplos 4.7-5, pp. 90–91 (alma em cortante), e 4.7-9, pp. 109–115 (par nas mesas exteriores); p. 161 (chave inferior e referência das ações). O exemplo de momento puro não aprova automaticamente a extensão estática N/M/V ou outra geometria. '+NBR+', 6.2 e 6.5, Tabelas 9 e 11: resistências e requisitos locais; sem aumento direcional AISC. O registro de engenharia qualifica a alocação e os comprimentos para os dados atuais.')
    elif c.column_weld.model!='off':
        doc.add_paragraph('AISC DG1, 3ª edição, exemplo 4.7-3, pp. 71–73: faixas locais de tração da base Tipo 2. '+NBR+', 6.2 e 6.5, Tabelas 9 e 11: solda, metal-base, dimensões e qualificações aplicáveis. Esta combinação de referências verifica somente os componentes expressamente indicados.')
    doc.add_paragraph(BRAND)
    p=doc.add_paragraph('LRO Ligações '+VERSION+' · ');hyperlink(p,'LinkedIn — Lucas Oliveira',LINK)
    if native:
        # Reserva espaço para a identificação ao final sem uma página órfã.
        for para in doc.paragraphs[final_section_start:]:
            para.paragraph_format.space_after=Pt(3)
        doc.paragraphs[-2].paragraph_format.keep_with_next=True
    out=BytesIO();doc.save(out);return out.getvalue()
