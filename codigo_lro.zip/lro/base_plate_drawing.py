"""Desenho proporcional da base Tipo 1 e das reações, com geometria real."""
from io import BytesIO
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Circle,FancyArrowPatch
from .models import KGF

INK='#20354a';PLATE='#8faec1';COLUMN='#cbd3da';CONTACT='#e5b574';TENSION='#af4545'

def image_bytes(c,r=None,fmt='png'):
    from .base_plate import evaluate,detail_reference
    if r is None:r=evaluate(c)
    a=r.geometry;ref=detail_reference(c);L,B=c.L,c.B;d,bf,tf,tw=c.column.d,c.column.bf,c.column.tf,c.column.tw
    with plt.rc_context({'font.family':'DejaVu Sans','font.size':9,'svg.fonttype':'none'}):
        fig,(plan,sec)=plt.subplots(1,2,figsize=(12,6.3),layout='constrained')
        for ax in (plan,sec):ax.axis('off');ax.set_aspect('equal')
        def rect(ax,x,y,w,h,color,**kw):ax.add_patch(Rectangle((x,y),w,h,facecolor=color,edgecolor=INK,lw=.8,**kw))
        def dim(ax,x1,y1,x2,y2,label,offset=0):
            ax.annotate('',(x2,y2),(x1,y1),arrowprops={'arrowstyle':'<->','lw':.65,'color':INK,'shrinkA':0,'shrinkB':0})
            ax.text((x1+x2)/2,(y1+y2)/2,label,rotation=90 if x1==x2 else 0,ha='center',va='center',fontsize=8,
                    bbox={'facecolor':'white','edgecolor':'none','pad':1.1},color=INK)
        def leader(ax,text,xy,at):
            ax.annotate(text,xy=xy,xytext=at,fontsize=8,color=INK,ha='left',va='center',
                        arrowprops={'arrowstyle':'-','lw':.6,'color':INK},bbox={'facecolor':'white','edgecolor':'none','pad':1.2})
        margin=max(38,L*.085,B*.1)
        plan.set_title('PLANTA DA PLACA',loc='left',fontsize=11,fontweight='bold',color=INK,pad=14)
        rect(plan,-L/2,-B/2,L,B,PLATE,alpha=.48)
        rect(plan,-d/2,-bf/2,tf,bf,COLUMN);rect(plan,d/2-tf,-bf/2,tf,bf,COLUMN)
        rect(plan,-d/2+tf,-tw/2,d-2*tf,tw,COLUMN)
        for x in (-c.a,c.a):
            for y in (-c.a2/2,c.a2/2):
                side=ref['washer_side']
                rect(plan,x-side/2,y-side/2,side,side,'none',linestyle='--')
                plan.add_patch(Circle((x,y),ref['df']/2,fill=False,ec=INK,lw=.65,ls=':'))
                plan.add_patch(Circle((x,y),c.db/2,facecolor='white',ec=INK,lw=1))
        plan.plot([-L/2-margin*.2,L/2+margin*.2],[0,0],lw=.6,ls='-.',color=INK)
        plan.plot([0,0],[-B/2-margin*.2,B/2+margin*.2],lw=.6,ls='-.',color=INK)
        dim(plan,-L/2,-B/2-margin,L/2,-B/2-margin,f'L = {L:g}')
        dim(plan,-L/2-margin,-B/2,-L/2-margin,B/2,f'B = {B:g}')
        yy=B/2+margin*.75
        for x in (d/2,c.a,L/2):plan.plot([x,x],[B/2,yy+margin*.15],color=INK,lw=.5)
        dim(plan,d/2,yy,c.a,yy,f'a₁={c.a1:g}')
        dim(plan,c.a,yy,L/2,yy,f'a₁={c.a1:g}')
        dim(plan,L/2+margin*.75,-c.a2/2,L/2+margin*.75,c.a2/2,f'a₂ = {c.a2:g}')
        dim(plan,L/2+margin*.75,c.a2/2,L/2+margin*.75,B/2,'a₁')
        leader(plan,'Arruela especial',(c.a,c.a2/2),(0,B/2+margin*1.55))
        plan.text(-L/2,-B/2-margin*1.8,'L = d + 4a₁   |   B = a₂ + 2a₁',fontsize=9,color=INK)
        plan.text(-L/2,-B/2-margin*2.35,'Eixo de maior inércia: paralelo a B',fontsize=8,color=INK)
        plan.set_xlim(-L/2-margin*1.55,L/2+margin*1.45)
        plan.set_ylim(-B/2-margin*2.8,B/2+margin*2.1)
        sec.set_title('CORTE NO PLANO DA ALMA E REAÇÕES',loc='left',fontsize=11,fontweight='bold',color=INK,pad=14)
        height=max(100.,L*.45);ground=-c.grout_t;concrete=max(90.,L*.28)
        rect(sec,-L/2-margin,ground-concrete,L+2*margin,concrete,'#e6e4df',hatch='..')
        rect(sec,-L/2,ground,L,c.grout_t,'#f3e7d3')
        rect(sec,-L/2,0,L,c.tp,PLATE)
        rect(sec,-d/2,c.tp,d,height,'#edf0f3')
        rect(sec,-d/2,c.tp,tf,height,COLUMN);rect(sec,d/2-tf,c.tp,tf,height,COLUMN)
        for x in (-c.a,c.a):
            sec.plot([x,x],[ground-concrete*.75,c.tp+ref['washer_t']+c.db],color=INK,lw=2.4)
            rect(sec,x-ref['washer_side']/2,c.tp,ref['washer_side'],ref['washer_t'],COLUMN)
            rect(sec,x-c.db*.65,c.tp+ref['washer_t'],c.db*1.3,c.db*.7,'#637b8d')
            rect(sec,x-c.db*.7,ground-concrete*.75,c.db*1.4,c.db*.7,'#637b8d')
        sec.text(-L/2-margin,ground-concrete-8,'Ancoragem esquemática; comprimento e bloco\nrequerem dimensionamento e detalhamento próprios.',fontsize=8,color=INK,va='top')
        dim(sec,L/2+margin*.65,0,L/2+margin*.65,c.tp,f'tₚ = {c.tp:g}')
        leader(sec,f'Graute {c.grout_t:g} mm',(-L*.25,-c.grout_t*.5),(-L/2-margin,ground-concrete*.3))
        # Diagrama separado: faixa comprimida uniforme, sem sugerir contato linear.
        ydiagram=ground-concrete-90;qh=max(23,L*.07)
        sec.plot([-L/2,L/2],[ydiagram,ydiagram],color=INK,lw=1)
        if a:
            lc=a['lc'];sgn=a['moment_sign']
            if a['C']>0:
                x0=L/2-lc if sgn>0 else -L/2
                rect(sec,x0,ydiagram-qh,lc,qh,CONTACT)
                # A seta representa a resultante; altura do diagrama é simbólica.
                xc=a['C_x']
                sec.annotate('',(xc,ydiagram),(xc,ydiagram-qh*1.5),arrowprops={'arrowstyle':'->','lw':1.3,'color':INK})
                sec.text(xc,ydiagram-qh*1.9,f'C = {a["C"]/KGF:,.0f} kgf'.replace(',','.'),ha='center',fontsize=8,color=INK)
                dim(sec,x0,ydiagram+18,x0+lc,ydiagram+18,f'lc = {lc:.1f}')
            for xx,F in ((-sgn*c.a,a['Ft_max']),(sgn*c.a,a['Ft_min'])):
                if F>0:
                    sec.annotate('',(xx,ydiagram-qh),(xx,ydiagram+qh*.5),arrowprops={'arrowstyle':'->','lw':1.3,'color':TENSION})
                    sec.text(xx,ydiagram+qh*.8,f'2 × {F/KGF:,.0f} kgf'.replace(',','.'),ha='center',fontsize=8,color=TENSION)
            sec.text(-L/2-margin,ydiagram-qh*3,'Caso '+a['case']+' | Faixa de contato uniforme; alturas das setas simbólicas.',fontsize=8,color=INK)
        if c.N:
            top=c.tp+height+margin*.5;tail=top+margin;head=top
            if c.N<0:tail,head=head,tail
            sec.annotate('',(0,head),(0,tail),arrowprops={'arrowstyle':'->','lw':1.3,'color':INK})
            sec.text(8,(tail+head)/2,'N',fontsize=9,color=INK)
        if c.M:
            sec.text(d/2+8,c.tp+height*.82,'M '+('↻' if c.M>0 else '↺'),fontsize=12,color=INK)
        sec.set_xlim(-L/2-margin*1.3,L/2+margin*1.5)
        sec.set_ylim(ydiagram-qh*3.6,c.tp+height+margin*1.9)
        fig.supxlabel('Cotas em mm. Perfil e placa proporcionais. Quatro barras ASTM A36, sem enrijecedores.\n'
                      'O desenho não substitui o detalhamento de fabricação, das soldas ou do bloco.',fontsize=9,color=INK)
        out=BytesIO();fig.savefig(out,format=fmt,dpi=160,facecolor='white');plt.close(fig);return out.getvalue()
