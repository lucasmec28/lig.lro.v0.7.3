"""Desenho proporcional da base Tipo 1 e das reações, com geometria real."""
from io import BytesIO
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Circle,FancyArrowPatch,Polygon
from .models import KGF
from .drawing_annotations import dimension

INK='#20354a';PLATE='#8faec1';COLUMN='#cbd3da';CONTACT='#e5b574';TENSION='#af4545'

def _grout_section(ax,c,gid='actual_grout'):
    en=c.grout_t;L=c.L
    patch=Polygon([(-L/2,0),(L/2,0),(L/2+en,-en),(-L/2-en,-en)],
                  closed=True,facecolor='#f3e7d3',edgecolor=INK,lw=.8)
    patch.set_gid(gid);ax.add_patch(patch)
    return patch


def _grout_plan(ax,c):
    patch=Rectangle((-c.L/2-c.grout_t,-c.B/2-c.grout_t),c.L+2*c.grout_t,c.B+2*c.grout_t,
                    facecolor='none',edgecolor='#a98450',lw=.8,ls='--')
    patch.set_gid('grout_45_footprint');ax.add_patch(patch)


def image_bytes(c,r=None,fmt='png'):
    if c.model_type==2:
        from .pinned_base_plate_drawing import image_bytes as pinned_image_bytes
        return pinned_image_bytes(c,r,fmt)
    from .base_plate import evaluate,detail_reference
    if r is None:r=evaluate(c)
    if c.shear_path in ('cross_active_plate','w_flange_plates'):
        from .active_shear_key_drawing import image_bytes as active_image_bytes
        return active_image_bytes(c,r,fmt)
    if c.shear_path=='plate':return _shear_plate_image_bytes(c,r,fmt)
    if c.shear_path=='anchors' and getattr(c,'anchor_shear_model','external')=='welded_washer':
        return _anchor_washer_image_bytes(c,r,fmt)
    a=r.geometry;ref=detail_reference(c);L,B=c.L,c.B;d,bf,tf,tw=c.column.d,c.column.bf,c.column.tf,c.column.tw
    with plt.rc_context({'font.family':'DejaVu Sans','font.size':9,'svg.fonttype':'none'}):
        fig,(plan,sec)=plt.subplots(1,2,figsize=(12,6.3),layout='constrained')
        for ax in (plan,sec):ax.axis('off');ax.set_aspect('equal')
        def rect(ax,x,y,w,h,color,**kw):ax.add_patch(Rectangle((x,y),w,h,facecolor=color,edgecolor=INK,lw=.8,**kw))
        def dim(ax,x1,y1,x2,y2,label,offset=0,short_side=None):
            side=short_side if short_side is not None else (-1 if x1>0 else 1) if x1==x2 else (1 if y1>0 else -1)
            return dimension(ax,(x1,y1),(x2,y2),label,fontsize=8,
                             rotation=90 if x1==x2 else 0,color=INK,pad=1.1,lw=.65,short_side=side)
        def leader(ax,text,xy,at):
            ax.annotate(text,xy=xy,xytext=at,fontsize=8,color=INK,ha='left',va='center',
                        arrowprops={'arrowstyle':'-','lw':.6,'color':INK},bbox={'facecolor':'white','edgecolor':'none','pad':1.2})
        margin=max(38,L*.085,B*.1,c.grout_t*1.15)
        plan.set_title('PLANTA DA PLACA',loc='left',fontsize=11,fontweight='bold',color=INK,pad=14)
        _grout_plan(plan,c)
        rect(plan,-L/2,-B/2,L,B,PLATE,alpha=.48)
        rect(plan,-d/2,-bf/2,tf,bf,COLUMN);rect(plan,d/2-tf,-bf/2,tf,bf,COLUMN)
        rect(plan,-d/2+tf,-tw/2,d-2*tf,tw,COLUMN)
        for x in (-c.a,c.a):
            for y in (-c.a2/2,c.a2/2):
                side=ref['washer_side']
                rect(plan,x-side/2,y-side/2,side,side,'none',linestyle='--')
                plan.add_patch(Circle((x,y),ref['df']/2,fill=False,ec=INK,lw=.65,ls=':'))
                plan.add_patch(Circle((x,y),c.db/2,facecolor='white',ec=INK,lw=1))
        plan.plot([-L/2-margin*.2,L/2+margin*.2],[0,0],lw=.6,ls='-.',color=INK)
        plan.plot([0,0],[-B/2-margin*.2,B/2+margin*.2],lw=.6,ls='-.',color=INK)
        dim(plan,-L/2,-B/2-margin,L/2,-B/2-margin,f'L = {L:g}')
        dim(plan,-L/2-margin,-B/2,-L/2-margin,B/2,f'B = {B:g}')
        yy=B/2+margin*.75
        for x in (d/2,c.a,L/2):plan.plot([x,x],[B/2,yy+margin*.15],color=INK,lw=.5)
        dim(plan,d/2,yy,c.a,yy,f'a₁={c.a1:g}')
        dim(plan,c.a,yy,L/2,yy,f'a₁={c.a1:g}')
        dim(plan,L/2+margin*.75,-c.a2/2,L/2+margin*.75,c.a2/2,f'a₂ = {c.a2:g}')
        dim(plan,L/2+margin*.75,c.a2/2,L/2+margin*.75,B/2,'a₁')
        leader(plan,'Arruela especial',(c.a,c.a2/2),(0,B/2+margin*1.55))
        plan.text(-L/2,-B/2-margin*1.8,'L = d + 4a₁   |   B = a₂ + 2a₁',fontsize=9,color=INK)
        plan.text(-L/2,-B/2-margin*2.35,'Eixo de maior inércia: paralelo a B',fontsize=8,color=INK)
        plan.set_xlim(-L/2-margin*1.55,L/2+margin*1.45)
        plan.set_ylim(-B/2-margin*2.8,B/2+margin*2.1)
        sec.set_title('CORTE NO PLANO DA ALMA E REAÇÕES',loc='left',fontsize=11,fontweight='bold',color=INK,pad=14)
        height=max(100.,L*.45);ground=-c.grout_t;concrete=max(90.,L*.28)
        rect(sec,-L/2-margin,ground-concrete,L+2*margin,concrete,'#e6e4df',hatch='..')
        _grout_section(sec,c)
        rect(sec,-L/2,0,L,c.tp,PLATE)
        rect(sec,-d/2,c.tp,d,height,'#edf0f3')
        rect(sec,-d/2,c.tp,tf,height,COLUMN);rect(sec,d/2-tf,c.tp,tf,height,COLUMN)
        for x in (-c.a,c.a):
            sec.plot([x,x],[ground-concrete*.75,c.tp+ref['washer_t']+c.db],color=INK,lw=2.4)
            rect(sec,x-ref['washer_side']/2,c.tp,ref['washer_side'],ref['washer_t'],COLUMN)
            rect(sec,x-c.db*.65,c.tp+ref['washer_t'],c.db*1.3,c.db*.7,'#637b8d')
            # Trecho interrompido: a peça enterrada aparece no detalhe específico.
        sec.text(-L/2-margin,ground-concrete-8,'Ancoragem esquemática; comprimento e bloco\nrequerem dimensionamento e detalhamento próprios.',fontsize=8,color=INK,va='top')
        dim(sec,L/2+margin*.65,0,L/2+margin*.65,c.tp,f'tₚ = {c.tp:g}')
        leader(sec,f'Graute {c.grout_t:g} mm; saia 45°',(-L*.25,-c.grout_t*.5),(-L/2-margin,ground-concrete*.3))
        # Diagrama separado: faixa comprimida uniforme, sem sugerir contato linear.
        ydiagram=ground-concrete-90;qh=max(23,L*.07)
        sec.plot([-L/2,L/2],[ydiagram,ydiagram],color=INK,lw=1)
        if a:
            lc=a['lc'];sgn=a['moment_sign']
            if a['C']>0:
                x0=L/2-lc if sgn>0 else -L/2
                rect(sec,x0,ydiagram-qh,lc,qh,CONTACT)
                # A seta representa a resultante; altura do diagrama é simbólica.
                xc=a['C_x']
                sec.annotate('',(xc,ydiagram),(xc,ydiagram-qh*1.5),arrowprops={'arrowstyle':'->','lw':1.3,'color':INK})
                sec.text(xc,ydiagram-qh*1.9,f'C = {a["C"]/KGF:,.0f} kgf'.replace(',','.'),ha='center',fontsize=8,color=INK)
                dim(sec,x0,ydiagram+18,x0+lc,ydiagram+18,f'lc = {lc:.1f}',short_side=1)
            for xx,F in ((-sgn*c.a,a['Ft_max']),(sgn*c.a,a['Ft_min'])):
                if F>0:
                    sec.annotate('',(xx,ydiagram-qh),(xx,ydiagram+qh*.5),arrowprops={'arrowstyle':'->','lw':1.3,'color':TENSION})
                    sec.text(xx,ydiagram+qh*.8,f'2 × {F/KGF:,.0f} kgf'.replace(',','.'),ha='center',fontsize=8,color=TENSION)
            sec.text(-L/2-margin,ydiagram-qh*3,'Caso '+a['case']+' | Faixa de contato uniforme; alturas das setas simbólicas.',fontsize=8,color=INK)
        if c.N:
            top=c.tp+height+margin*.5;tail=top+margin;head=top
            if c.N<0:tail,head=head,tail
            sec.annotate('',(0,head),(0,tail),arrowprops={'arrowstyle':'->','lw':1.3,'color':INK})
            sec.text(8,(tail+head)/2,'N',fontsize=9,color=INK)
        if c.M:
            sec.text(d/2+8,c.tp+height*.82,'M '+('↻' if c.M>0 else '↺'),fontsize=12,color=INK)
        sec.set_xlim(-L/2-margin*1.3,L/2+margin*1.5)
        sec.set_ylim(ydiagram-qh*3.6,c.tp+height+margin*1.9)
        fig.supxlabel('Cotas em mm. Perfil e placa proporcionais. Modelo sem ganho de enrijecedores; graute a 45° (tracejado em planta).\n'
                      'O desenho não substitui o detalhamento de fabricação, das soldas ou do bloco.',fontsize=9,color=INK)
        out=BytesIO();fig.savefig(out,format=fmt,dpi=160,facecolor='white');plt.close(fig);return out.getvalue()


def _anchor_washer_image_bytes(c,r,fmt='png'):
    """Arruelas efetivamente informadas e quatro capacidades condicionais.

    A seta V identifica somente o cortante total do grupo. Não representa
    uma distribuição imposta entre as barras. O momento informado é mantido.
    """
    from .base_plate import detail_reference
    a=r.geometry;ref=detail_reference(c);L,B=c.L,c.B;p=c.column
    side,ta,hole=c.anchor_washer_side,c.anchor_washer_t,c.anchor_washer_hole
    shear=a.get('anchor_shear',{}) if a else {};rods=shear.get('rods',[])
    margin=max(42.,L*.09,B*.12);sgn=1 if c.V>=0 else -1
    with plt.rc_context({'font.family':'DejaVu Sans','font.size':9,'svg.fonttype':'none'}):
        fig=plt.figure(figsize=(12.8,8.8),layout='constrained')
        grid=fig.add_gridspec(2,2,height_ratios=(3.1,1.65))
        plan=fig.add_subplot(grid[0,0]);sec=fig.add_subplot(grid[0,1])
        notes=fig.add_subplot(grid[1,0]);eq=fig.add_subplot(grid[1,1])
        for ax in (plan,sec,eq):ax.axis('off');ax.set_aspect('equal')
        notes.axis('off')
        def rect(ax,x,y,w,h,color,gid=None,**kw):
            patch=Rectangle((x,y),w,h,facecolor=color,edgecolor=INK,lw=.85,**kw)
            if gid:patch.set_gid(gid)
            ax.add_patch(patch);return patch
        def text(ax,x,y,label,**kw):
            return ax.text(x,y,label,color=INK,fontsize=8,**kw)
        def dim(ax,x1,y1,x2,y2,label,short_side=None):
            side=short_side if short_side is not None else (-1 if x1>0 else 1) if x1==x2 else (1 if y1>0 else -1)
            return dimension(ax,(x1,y1),(x2,y2),label,fontsize=8,
                             rotation=90 if x1==x2 else 0,color=INK,pad=1.1,lw=.65,short_side=side)
        def arrow(ax,tail,head,gid,color=INK):
            patch=FancyArrowPatch(tail,head,arrowstyle='-|>',mutation_scale=12,lw=1.4,color=color)
            patch.set_gid(gid);ax.add_patch(patch)
        def leader(ax,label,xy,at):
            ax.annotate(label,xy=xy,xytext=at,fontsize=8,color=INK,ha='left',va='center',
                        arrowprops={'arrowstyle':'-','lw':.6,'color':INK},
                        bbox={'facecolor':'white','edgecolor':'none','pad':1.2})
        plan.set_title('PLANTA DAS QUATRO ARRUELAS SOLDADAS',loc='left',fontsize=11,fontweight='bold',color=INK)
        _grout_plan(plan,c)
        rect(plan,-L/2,-B/2,L,B,PLATE,alpha=.48)
        rect(plan,-p.d/2,-p.bf/2,p.tf,p.bf,COLUMN)
        rect(plan,p.d/2-p.tf,-p.bf/2,p.tf,p.bf,COLUMN)
        rect(plan,-p.d/2+p.tf,-p.tw/2,p.d-2*p.tf,p.tw,COLUMN)
        for i,(x,y) in enumerate(((x,y) for x in (-c.a,c.a) for y in (-c.a2/2,c.a2/2)),1):
            rid='A'+str(i)
            rect(plan,x-side/2,y-side/2,side,side,'#f1d6a9',gid='washer_plan_'+rid,alpha=.9)
            # O furo alargado da placa fica encoberto pela arruela.
            plan.add_patch(Circle((x,y),ref['df']/2,fill=False,ec=INK,lw=.65,ls=':'))
            aperture=Circle((x,y),hole/2,facecolor='white',ec=INK,lw=.8)
            aperture.set_gid('washer_hole_'+rid);plan.add_patch(aperture)
            rod=Circle((x,y),c.db/2,facecolor=COLUMN,ec=INK,lw=.8)
            rod.set_gid('anchor_'+rid);plan.add_patch(rod)
            # Align the near edge of the rendered ID outside all actual outlines;
            # point offsets remain legible at either native export resolution.
            label_sign=1 if y>0 else -1
            outer=max(B/2+c.grout_t,abs(y)+side/2)
            plan.annotate(rid,xy=(x,label_sign*outer),xytext=(0,label_sign*4),
                          textcoords='offset points',fontsize=8,color=INK,
                          ha='center',va='bottom' if y>0 else 'top')
        plan.plot([-L/2-margin*.1,L/2+margin*.1],[0,0],lw=.6,ls='-.',color=INK)
        plan.plot([0,0],[-B/2-margin*.1,B/2+margin*.1],lw=.6,ls='-.',color=INK)
        dim(plan,-L/2,-B/2-margin*.95,L/2,-B/2-margin*.95,f'L = {L:g}')
        dim(plan,-L/2-margin*.8,-B/2,-L/2-margin*.8,B/2,f'B = {B:g}')
        dim(plan,L/2+margin*.8,-c.a2/2,L/2+margin*.8,c.a2/2,f'a₂ = {c.a2:g}')
        dim(plan,p.d/2,B/2+margin*.7,c.a,B/2+margin*.7,f'a₁={c.a1:g}')
        dim(plan,c.a,B/2+margin*.7,L/2,B/2+margin*.7,f'a₁={c.a1:g}')
        arrow(plan,(-sgn*L*.15,B/2+margin*1.6),(sgn*L*.15,B/2+margin*1.6),'anchor_plan_shear')
        text(plan,0,B/2+margin*1.9,f'V = {c.V/1000:+.2f} kN (grupo)',ha='center')
        arrow(plan,(L/2+margin*.1,-B/2-margin*.15),(L/2+margin*.8,-B/2-margin*.15),'anchor_axis_x')
        text(plan,L/2+margin*.5,-B/2-margin*.48,'+x',ha='center')
        text(plan,-L/2,-B/2-margin*1.55,'x = ±a; y = ±a₂/2. Origem no centro; +y para cima.')
        text(plan,-L/2,-B/2-margin*1.98,f'Arruelas reais: {side:g} × {side:g} × {ta:g} mm; furo Ø{hole:g} mm.')
        plan.set_xlim(-L/2-margin*1.15,L/2+margin*1.25)
        plan.set_ylim(-B/2-margin*2.35,B/2+margin*2.25)

        sec.set_title('CORTE x z E DIMENSÕES REAIS',loc='left',fontsize=11,fontweight='bold',color=INK)
        height=max(95.,L*.32);bottom=-c.grout_t-max(85.,L*.21)
        rect(sec,-L/2-max(c.grout_t,margin*.4),bottom,L+2*max(c.grout_t,margin*.4),-c.grout_t-bottom,'#e6e4df',hatch='..')
        _grout_section(sec,c,'anchor_actual_grout')
        rect(sec,-L/2,0,L,c.tp,PLATE)
        rect(sec,-p.d/2,c.tp,p.d,height,'#edf0f3')
        rect(sec,-p.d/2,c.tp,p.tf,height,COLUMN);rect(sec,p.d/2-p.tf,c.tp,p.tf,height,COLUMN)
        for j,x in enumerate((-c.a,c.a),1):
            sec.plot([x,x],[bottom+margin*.2,c.tp+ta+c.db],color=INK,lw=2.4)
            rect(sec,x-side/2,c.tp,side,ta,'#f1d6a9',gid='washer_section_'+str(j))
            rect(sec,x-c.db*.65,c.tp+ta,c.db*1.3,c.db*.7,'#637b8d')
        dim(sec,L/2+margin*.4,0,L/2+margin*.4,c.tp,f'tp = {c.tp:g}')
        dim(sec,-L/2-margin*.8,-c.grout_t,-L/2-margin*.8,0,f'en = {c.grout_t:g}')
        leader(sec,f'ta = {ta:g} mm; lado = {side:g} mm',(c.a+side/2,c.tp+ta/2),(L*.1,c.tp+height*.6))
        arrow(sec,(-sgn*L*.17,c.tp),(sgn*L*.17,c.tp),'anchor_applied_shear')
        text(sec,0,c.tp+margin*.25,'V na face superior',ha='center')
        if c.N:
            z=c.tp+height+margin*.22
            arrow(sec,(0,z+margin*.7 if c.N>0 else z),(0,z if c.N>0 else z+margin*.7),'anchor_axial_force')
            text(sec,margin*.22,z+margin*.3,'N')
        text(sec,-p.d/2,c.tp+height*.72,'M informado '+('↻' if c.M>=0 else '↺'))
        text(sec,-p.d/2,c.tp+height*.48,f'{c.M/1e6:+.3f} kN·m')
        text(sec,-L/2-margin*.4,bottom-margin*.4,'Ancoragem e bloco esquemáticos; embutimento não verificado.')
        text(sec,-L/2-margin*.4,bottom-margin*.84,'Arruelas soldadas à placa; filetes dependem de dimensionamento.')
        text(sec,-L/2-margin*.4,bottom-margin*1.28,'M mantido na face superior; sem transporte automático de V.')
        sec.set_xlim(-L/2-margin*1.1,L/2+margin*1.25)
        sec.set_ylim(bottom-margin*1.7,c.tp+height+margin*1.2)

        notes.set_title('TRAÇÃO E CAPACIDADE CONDICIONAL POR BARRA',loc='left',fontsize=10,fontweight='bold',color=INK)
        lines=[]
        for rod in rods:
            value=f'{rod["rd"]/1000:.2f} kN' if rod['domain_ok'] else 'fora do domínio'
            lines.append(f'{rod["id"]}: (x,y)=({rod["x"]:+g}; {rod["y"]:+g}) mm | Ft={rod["tension"]/1000:.2f} kN | VRd={value}')
        if shear:
            lines.extend([
                f'Σ VRd,i = {shear["group_rd"]/1000:.2f} kN; |V| = {abs(c.V)/1000:.2f} kN; α = {shear["alpha"]:.3f}.',
                f'Solda de cada arruela: ação Fv,Rd = {shear["weld_force_per_washer"]/1000:.2f} kN, sem redução.',
            ])
        lines.extend(['Limite conservador 6.7.2.5; sem soma de atrito ou chave.',
                      'Soldas, transferência local, ancoragem, grupo e bordas do concreto',
                      'e bloco armado permanecem a complementar.'])
        for i,line in enumerate(lines):notes.text(0,.98-i*.105,line,fontsize=8,color=INK,va='top',transform=notes.transAxes)
        eq.set_title('REAÇÕES E CONVENÇÃO DE SINAIS',loc='left',fontsize=10,fontweight='bold',color=INK)
        qh=max(22.,L*.055);eq.plot([-L/2,L/2],[0,0],color=INK,lw=1)
        if a:
            ms=a['moment_sign'];lc=a['lc']
            if a['C']>0:
                x0=L/2-lc if ms>0 else -L/2
                rect(eq,x0,-qh,lc,qh,CONTACT,gid='anchor_base_compression_block')
                arrow(eq,(a['C_x'],-qh*2),(a['C_x'],0),'anchor_base_compression_reaction')
                text(eq,a['C_x'],-qh*2.7,f'C = {a["C"]/1000:.2f} kN',ha='center')
                dim(eq,x0,qh*.7,x0+lc,qh*.7,f'lc = {lc:.1f}',short_side=1)
            for name,xx,F in (('max',-ms*c.a,a['Ft_max']),('min',ms*c.a,a['Ft_min'])):
                if F>0:
                    arrow(eq,(xx,qh*.4),(xx,-qh),'anchor_native_tension_'+name,TENSION)
                    text(eq,xx,qh*1.4,f'2 × {F/1000:.2f} kN',ha='center')
            text(eq,-L/2-margin*.4,-qh*3.55,'Caso '+a['case']+'; faixa uniforme e alturas simbólicas.')
        text(eq,-L/2-margin*.4,-qh*4.25,'N positivo comprime; V positivo em +x; M positivo horário.')
        text(eq,-L/2-margin*.4,-qh*4.95,'M positivo comprime +x e traciona −x; M negativo troca os lados.')
        eq.set_xlim(-L/2-margin*.7,L/2+margin*.7);eq.set_ylim(-qh*5.5,qh*2.2)
        fig.supxlabel('Cotas em mm. Modelo local NBR 6.7.2.5 com quatro barras ASTM A36 e arruelas soldadas. '
                      'O resultado não aprova a base completa.',fontsize=8,color=INK)
        out=BytesIO();fig.savefig(out,format=fmt,dpi=160,facecolor='white');plt.close(fig);return out.getvalue()


def _shear_plate_image_bytes(c,r,fmt='png'):
    """Chapa única: planta x/y, corte x/z e equilíbrio com o momento transportado.

    A face superior da placa está em z=tp e sua face inferior em z=0.
    A reação de contato da chave atua em z=−(bv+en)/2. Nenhuma dimensão
    do graute ou da chave é tomada da tabela de detalhamento dos chumbadores.
    """
    from .base_plate import detail_reference
    a=r.geometry;ref=detail_reference(c);L,B=c.L,c.B;p=c.column
    bh,bv,t,en=c.lug_bh,c.lug_bv,c.lug_t,c.grout_t
    key_color='#a5601a';margin=max(40,L*.09,B*.12,c.grout_t*1.15)
    zc=-(bv+en)/2;sgn=1 if c.V>=0 else -1
    with plt.rc_context({'font.family':'DejaVu Sans','font.size':9,'svg.fonttype':'none'}):
        fig=plt.figure(figsize=(12.8,8.1),layout='constrained')
        grid=fig.add_gridspec(2,2,height_ratios=(3.3,1.25))
        plan=fig.add_subplot(grid[0,0]);sec=fig.add_subplot(grid[0,1])
        notes=fig.add_subplot(grid[1,0]);eq=fig.add_subplot(grid[1,1])
        for ax in (plan,sec,eq):ax.axis('off');ax.set_aspect('equal')
        notes.axis('off')
        def rect(ax,x,y,w,h,color,gid=None,**kw):
            patch=Rectangle((x,y),w,h,facecolor=color,edgecolor=INK,lw=.85,**kw)
            if gid:patch.set_gid(gid)
            ax.add_patch(patch);return patch
        def text(ax,x,y,label,**kw):
            return ax.text(x,y,label,color=INK,fontsize=8,**kw)
        def dim(ax,x1,y1,x2,y2,label,short_side=None):
            side=short_side if short_side is not None else (-1 if x1>0 else 1) if x1==x2 else (1 if y1>0 else -1)
            return dimension(ax,(x1,y1),(x2,y2),label,fontsize=8,
                             rotation=90 if x1==x2 else 0,color=INK,pad=1.1,lw=.65,short_side=side)
        def arrow(ax,tail,head,label,gid,color=INK,at=None):
            patch=FancyArrowPatch(tail,head,arrowstyle='-|>',mutation_scale=12,lw=1.4,color=color)
            patch.set_gid(gid);ax.add_patch(patch)
            if label:
                at=at or ((tail[0]+head[0])/2,(tail[1]+head[1])/2+10)
                text(ax,*at,label,ha='center',bbox={'facecolor':'white','edgecolor':'none','pad':1})
        def leader(ax,label,xy,at):
            ax.annotate(label,xy=xy,xytext=at,fontsize=8,color=INK,ha='left',va='center',
                        arrowprops={'arrowstyle':'-','lw':.6,'color':INK},
                        bbox={'facecolor':'white','edgecolor':'none','pad':1.2})
        plan.set_title('PLANTA DA PLACA E DA CHAVE',loc='left',fontsize=11,fontweight='bold',color=INK)
        _grout_plan(plan,c)
        rect(plan,-L/2,-B/2,L,B,PLATE,alpha=.48)
        rect(plan,-p.d/2,-p.bf/2,p.tf,p.bf,COLUMN)
        rect(plan,p.d/2-p.tf,-p.bf/2,p.tf,p.bf,COLUMN)
        rect(plan,-p.d/2+p.tf,-p.tw/2,p.d-2*p.tf,p.tw,COLUMN)
        for x in (-c.a,c.a):
            for y in (-c.a2/2,c.a2/2):
                w=ref['washer_side'];rect(plan,x-w/2,y-w/2,w,w,'none',linestyle='--')
                plan.add_patch(Circle((x,y),ref['df']/2,fill=False,ec=INK,lw=.65,ls=':'))
                plan.add_patch(Circle((x,y),c.db/2,facecolor='white',ec=INK,lw=1))
        rect(plan,-t/2,-bh/2,t,bh,'#f7d9a7',gid='lug_plan',linestyle='--',alpha=.92)
        plan.plot([-L/2-margin*.2,L/2+margin*.2],[0,0],lw=.6,ls='-.',color=INK)
        plan.plot([0,0],[-B/2-margin*.2,B/2+margin*.2],lw=.6,ls='-.',color=INK)
        dim(plan,-L/2,-B/2-margin*.65,L/2,-B/2-margin*.65,f'L = {L:g}')
        dim(plan,-L/2-margin*.65,-B/2,-L/2-margin*.65,B/2,f'B = {B:g}')
        dim(plan,t/2+margin*.65,-bh/2,t/2+margin*.65,bh/2,f'bh = {bh:g}')
        for x in (-t/2,t/2):plan.plot([x,x],[-bh/2,-B/2-margin*1.65],lw=.5,color=INK)
        dim(plan,-t/2,-B/2-margin*1.5,t/2,-B/2-margin*1.5,f'tpv = {t:g}')
        leader(plan,'Chapa vertical sob a base',(-t/2,bh/2),(-L*.42,B/2+margin*.72))
        arrow(plan,(-sgn*L*.13,B/2+margin*1.38),(sgn*L*.13,B/2+margin*1.38),
              'V perpendicular à face da chave','lug_plan_shear',key_color,at=(0,B/2+margin*1.65))
        arrow(plan,(L/2+margin*.15,-B/2),(L/2+margin*.95,-B/2),'+x','axis_x',at=(L/2+margin*.6,-B/2-margin*.25))
        arrow(plan,(L/2+margin*.15,-B/2),(L/2+margin*.15,-B/2+margin*.8),'+y','axis_y',at=(L/2+margin*.52,-B/2+margin*.7))
        text(plan,-L/2,-B/2-margin*2.15,'bh paralelo a y; tpv paralelo a x. Chave centrada na base.')
        plan.set_xlim(-L/2-margin*1.2,L/2+margin*1.2)
        plan.set_ylim(-B/2-margin*2.6,B/2+margin*2.05)

        sec.set_title('CORTE x z E BRAÇO DO CORTANTE',loc='left',fontsize=11,fontweight='bold',color=INK)
        height=max(95,L*.32);bottom=-max(bv+margin*.55,en+90)
        rect(sec,-L/2-max(en,margin*.4),bottom,L+2*max(en,margin*.4),-en-bottom,'#e6e4df',hatch='..')
        _grout_section(sec,c,'actual_grout')
        rect(sec,-L/2,0,L,c.tp,PLATE)
        rect(sec,-p.d/2,c.tp,p.d,height,'#edf0f3')
        rect(sec,-p.d/2,c.tp,p.tf,height,COLUMN);rect(sec,p.d/2-p.tf,c.tp,p.tf,height,COLUMN)
        for x in (-c.a,c.a):
            sec.plot([x,x],[bottom+margin*.2,c.tp+ref['washer_t']+c.db],color=INK,lw=2.4)
            rect(sec,x-ref['washer_side']/2,c.tp,ref['washer_side'],ref['washer_t'],COLUMN)
            rect(sec,x-c.db*.65,c.tp+ref['washer_t'],c.db*1.3,c.db*.7,'#637b8d')
        rect(sec,-t/2,-bv,t,bv,'#f7d9a7',gid='lug_section')
        face=sgn*t/2
        contact_line,=sec.plot([face,face],[-bv,-en],color=key_color,lw=3)
        contact_line.set_gid('lug_bearing_face')
        arrow(sec,(-sgn*L*.19,c.tp),(sgn*L*.19,c.tp),'V na face superior','lug_applied_shear',key_color,
              at=(0,c.tp+margin*.3))
        arrow(sec,(face+sgn*L*.21,zc),(face,zc),'Reação −V','lug_bearing_reaction',key_color,
              at=(face+sgn*L*.13,zc-margin*.35))
        sec.plot([-t/2,L/2+margin*1.15],[zc,zc],ls=':',color=INK,lw=.6)
        sec.plot([0,L/2+margin*1.15],[c.tp,c.tp],ls=':',color=INK,lw=.6)
        dim(sec,L/2+margin*.95,zc,L/2+margin*.95,c.tp,f'eV = {c.shear_eccentricity:g}')
        dim(sec,-L/2-margin*.8,-bv,-L/2-margin*.8,0,f'bv = {bv:g}')
        dim(sec,-L/2-margin*.2,-en,-L/2-margin*.2,0,f'en = {en:g}')
        dim(sec,L/2+margin*.3,0,L/2+margin*.3,c.tp,f'tp = {c.tp:g}')
        leader(sec,f'Contato efetivo: bv − en = {bv-en:g} mm',(face,-bv+(.15*(bv-en))),
               (-L*.42,bottom-margin*.4))
        text(sec,-L/2-margin*.4,bottom-margin*.95,'Projeção bv a partir da face inferior; en é o graute informado.')
        text(sec,-L/2-margin*.4,bottom-margin*1.4,'Ancoragem e bloco esquemáticos; sem dimensão de embutimento verificada.')
        if c.N:
            z=c.tp+height+margin*.3
            arrow(sec,(0,z+margin*.75 if c.N>0 else z),(0,z if c.N>0 else z+margin*.75),
                  'N','axial_force',at=(margin*.3,z+margin*.4))
        # A convenção é explícita mesmo quando o momento informado é zero.
        text(sec,-p.d/2,c.tp+height*.65,'M informado '+('↻' if c.M>=0 else '↺'))
        text(sec,-p.d/2,c.tp+height*.43,f'{c.M/1e6:+.3f} kN·m')
        sec.set_xlim(-L/2-margin*1.2,L/2+margin*1.4)
        sec.set_ylim(bottom-margin*1.8,c.tp+height+margin*1.35)

        notes.set_title('SINAIS E EQUILÍBRIO GLOBAL',loc='left',fontsize=10,fontweight='bold',color=INK)
        mi=a.get('M_input',c.M);dm=a.get('delta_M',c.V*c.shear_eccentricity)
        me=a.get('M_effective',c.effective_moment)
        lines=[
            'N positivo comprime; V positivo em +x; M positivo horário (↻).',
            'Momento positivo comprime o lado +x e traciona o lado −x.',
            f'eV = tp + (bv + en)/2 = {c.shear_eccentricity:g} mm',
            f'ΔM = V · eV = {dm/1e6:+.3f} kN·m',
            f'Mef = M + ΔM = {mi/1e6:+.3f} + ({dm/1e6:+.3f}) = {me/1e6:+.3f} kN·m',
            'Somar os momentos com sinal antes de tomar o módulo.',
            'Verificações locais; dispositivo completo pendente.',
        ]
        for i,line in enumerate(lines):notes.text(0,.95-i*.14,line,fontsize=8,color=INK,va='top',transform=notes.transAxes)
        eq.set_title('REAÇÕES COM Mef',loc='left',fontsize=10,fontweight='bold',color=INK)
        qh=max(22,L*.055);eq.plot([-L/2,L/2],[0,0],color=INK,lw=1)
        if a:
            ms=a['moment_sign'];lc=a['lc']
            if a['C']>0:
                x0=L/2-lc if ms>0 else -L/2
                rect(eq,x0,-qh,lc,qh,CONTACT,gid='base_compression_block')
                arrow(eq,(a['C_x'],-qh*2),(a['C_x'],0),'','base_compression_reaction')
                text(eq,a['C_x'],-qh*2.7,f'C = {a["C"]/1000:.2f} kN',ha='center')
                dim(eq,x0,qh*.7,x0+lc,qh*.7,f'lc = {lc:.1f}',short_side=1)
            for name,xx,F in (('max',-ms*c.a,a['Ft_max']),('min',ms*c.a,a['Ft_min'])):
                if F>0:
                    arrow(eq,(xx,qh*.4),(xx,-qh),'','anchor_tension_'+name,TENSION)
                    text(eq,xx,qh*1.4,f'2 × {F/1000:.2f} kN',ha='center')
            text(eq,-L/2-margin*.4,-qh*3.6,'Caso '+a['case']+'; faixa uniforme e setas de altura simbólica.')
        eq.set_xlim(-L/2-margin*.7,L/2+margin*.7);eq.set_ylim(-qh*4.1,qh*2.4)
        fig.supxlabel('Cotas em mm. Chapa única retangular, sem furos e sem enrijecedores. '
                      'O desenho não substitui o detalhamento de fabricação, soldas e bloco.',fontsize=8,color=INK)
        out=BytesIO();fig.savefig(out,format=fmt,dpi=160,facecolor='white');plt.close(fig);return out.getvalue()
