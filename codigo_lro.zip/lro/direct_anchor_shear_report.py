"""Editable Word section for direct-bearing results, including unresolved scopes."""
from dataclasses import asdict
from .models import KGF
from .report import table, number, _math, group

STATE_LABELS={'normal_hole_equal':'Distribuição uniforme em furos normais',
              'leading_row':'Linha dianteira no sentido de V',
              'opposite_row_envelope':'Linha oposta · envelope adicional'}
SCOPE_LABELS={'domain':'Domínio e documentação', 'steel_plate_uls':'ELU da haste e bearing da placa · EN',
              'plate_transfer_scope':'Transferência documental da placa','local_transfer_scope':'Transferência local calculada da placa',
              'aci_components':'Ancoragem · ACI em paralelo','service_scope':'ELS e acomodação',
              'foundation_scope':'Fundação e interface civil'}


def _val(value):
    if isinstance(value,bool):return 'Sim' if value else 'Não'
    if isinstance(value,(int,float)):return number(value,6)
    return str(value) if value not in ('',None) else 'Não informado'


def append_direct_report(doc,c,r,detailed=False):
    if not getattr(c,'direct_anchor_shear',False):return
    out=r.geometry.get('direct_anchor_shear',{})
    doc.add_paragraph('Contato direto placa–chumbador',style='Heading 1').paragraph_format.page_break_before=True
    doc.add_paragraph('Método convencional sobre graute curado. Base complementar EN 1993-1-8:2005 corrigida, '
                      'com ancoragem ACI independente. Sem crédito de atrito, chave, resistência lateral da arruela, '
                      'engaste fictício ou momento individual calculado. A arruela superior mantém somente função axial.')
    doc.add_paragraph('EN: γM2=1,25. NBR: γa2=1,35 nos modos NBR próprios. ACI: fatores φ próprios; '
                      'não se multiplicam, dividem ou combinam fatores dos sistemas e não se somam suas capacidades. '
                      'No aço ACI, sem ductilidade especificamente comprovada, φN=0,65 e φV=0,60; com comprovação '
                      'aplicável, φN=0,75 e φV=0,65. Mantém-se a redução 0,80 no cortante ACI sobre graute.')
    doc.add_paragraph('ATENDE ao escopo resistente da rota direta.' if out.get('direct_route_resistance_pass') else
                      'ROTA DIRETA NÃO APROVADA: resultados numéricos, falhas e pendências são apresentados sem convertê-los em aprovação.')
    rows=[]
    for key,label in SCOPE_LABELS.items():
        item=out.get(key,{})
        reasons=list(item.get('reasons',[]))
        if item.get('reason'):reasons.append(item['reason'])
        rows.append((label,str(item.get('status','não calculado')),'; '.join(reasons) or 'Consultar resultados e alcance próprios.'))
    table(doc,['Escopo independente','Estado','Motivos / limite'],rows,[2.1,1.15,3.7])
    u=c.direct_shear
    material=out.get('material',{})
    doc.add_paragraph('Material real: '+(u.material_name or 'NÃO IDENTIFICADO')+'; base '+u.material_basis+'. '
                      'Estado: '+str(material.get('qualification_status','study_unqualified'))+'.')
    if u.material_basis=='ASTM_supplementary':
        doc.add_paragraph('ASTM A36/UNC: aplicação complementar explícita, não equivalência ASTM/EN e não declaração de '
                          'conformidade material EN 3.3. Exige protocolo, norma com edição, certificado/rastreabilidade, '
                          'fabricação final, ductilidade/alongamento e rosca documentados, além do aceite. Defaults legados não constituem prova.')
    # Exact project data stay auditable even for a blocked numerical study.
    input_labels={'model':'Método','material_name':'Material real','material_basis':'Base do material',
        'material_specification':'Especificação e edição','material_reference':'Propriedades e rastreabilidade',
        'material_quality_reference':'Fabricação final e qualidade','material_protocol':'Protocolo complementar',
        'certification_reference':'Certificação do produto final','ductility_reference':'Ductilidade e base de alongamento',
        'supplementary_application_accepted':'Aplicação complementar aceita explicitamente',
        'fy':'fy (MPa)','fu':'fu (MPa)','thread_area':'As (mm²)','thread_tpi':'Rosca UNC (fios/pol.)',
        'thread_standard':'Sistema/perfil de rosca','thread_area_source':'Origem de As','thread_manufacture':'Fabricação da rosca',
        'thread_compliance':'Base de kthread','thread_reference':'Referência da rosca/área',
        'hole_diameter':'Furo efetivo d0 (mm)','hole_basis':'Base dimensional do furo','hole_kind':'Tipo do furo',
        'normal_hole_tolerance_verified':'Tolerâncias especificadas','execution_reference':'Referência de execução',
        'grout_complete':'Graute integral','grout_cured':'Graute curado','no_free_standoff':'Sem afastamento/vazios',
        'grout_reference':'Referência de graute','service_slip_requirement':'Requisito de ELS',
        'service_total_limit':'Limite total exigido (mm)','plate_transfer_complete':'Registro documental de transferência',
        'plate_transfer_reference':'Referência documental de transferência','static_loading':'Carregamento estático',
        'torsion_z':'Torção externa z (N·mm)'}
    doc.add_paragraph('Dados efetivamente informados',style='Heading 2')
    table(doc,['Entrada','Valor / referência'],[(input_labels.get(k,k),_val(v)) for k,v in asdict(u).items()], [2.75,4.2])
    doc.add_paragraph('Diâmetro real d='+number(c.db,6)+' mm; furo d0='+number(u.hole_diameter,6)+
                      ' mm. Dimensões próprias, não valores tabulados da Tabela 18. Nenhuma bitola, propriedade ou abertura foi convertida para fazê-la atender.')
    res=out.get('resistances',{})
    if res:
        doc.add_paragraph('Resistências independentes da haste · EN',style='Heading 2')
        for eq in ['F1 = βLf kthread αv fu As / γM2', 'F2 = (0,44 − 0,0003 fy) fu As / γM2',
                   'VRd = min(F1; F2)', 'TRd = kthread 0,9 fu As / γM2',
                   'Qi/VRd + Ti/(1,4 TRd) ≤ 1; Qi ≤ VRd; Ti ≤ TRd',
                   'Fb,Rd = k1 αb fu,placa d tp / γM2',
                   'Rlinha = n × menor limite individual; sem redistribuição implícita']:
            _math(doc,group(eq))
        table(doc,['Parâmetro','Valor'],[(k,_val(v)) for k,v in res.items() if isinstance(v,(int,float,bool))],[3.7,3.25])
        doc.add_paragraph('F1 é corte da haste, não bearing da placa. F2 inclui implicitamente efeito local/flexão do graute na resistência reduzida; '
                          'não demonstra Mhaste=0 nem fornece rigidez ou deslocamento. βLf reduz somente F1 quando aplicável; '
                          'a redução adicional de rosca não é aplicada automaticamente a F2.')
    local=out.get('local_transfer_scope',{})
    if local.get('checks'):
        doc.add_paragraph('Transferência da placa · componentes publicados',style='Heading 2')
        panel=local.get('panel',{})
        if panel.get('method')=='p398_external_nominal_v1':
            append_external_plate_report(doc,panel)
        elif panel:
            doc.add_paragraph('Tipo2 interno: SCI P358 Check9 aplicado à subplaca correspondente à fonte contínua REAL da alma. '
                'γM0,placa=1,00 e γM2,placa=1,25 recomendados EN; não é o γM2=1,10 britânico do P358. '
                'Não usa L como hp nem soma os comprimentos dos dois filetes. Prefixos de bloco com fator0,5 são limites suficientes conservadores, '
                'não prova isolada de ruptura quando excedidos. N/M e interações específicas permanecem independentes.')
            table(doc,['Geometria física / fator','Valor'],[(k,_val(v)) for k,v in panel.get('geometry',{}).items()],[3.7,3.25])
            for state in panel.get('states',[]):
                doc.add_paragraph('Blocos reais · '+STATE_LABELS.get(state['id'],state['id']),style='Heading 3')
                table(doc,['Barras / borda','lv / Anv / Ant','Qi / Rd (N)','Estado'],[
                    (','.join(x['ids'])+' / '+x['loaded_edge'],_val(x['lv_mm'])+' / '+_val(x['Anv_mm2'])+' / '+_val(x['Ant_mm2']),
                     _val(x['demand'])+' / '+_val(x['resistance']),x['status']) for x in state.get('prefixes',[])],[1.5,2.1,2.0,1.35])
        table(doc,['Componente','Sd / Rd','Unidade','Índice / estado'],[
            (x['label'],_val(x['demand'])+' / '+_val(x['resistance']),x.get('unit','N'),_val(x['ratio'])+' / '+x['status'])
            for x in local['checks']],[2.7,1.9,.6,1.75])
    normal=out.get('normal_and_axial_scope',{})
    if normal:
        doc.add_paragraph('Transferência normal/axial: '+str(normal.get('status'))+'. '+normal.get('reason',''))
        if normal.get('axial_washer_complete') is False:doc.add_paragraph('PENDÊNCIA: transferência axial local da arruela/porca superior não calculada nesta composição simples.')
    service=out.get('service_scope',{})
    doc.add_paragraph('ELS sem deslocamento inventado',style='Heading 2')
    doc.add_paragraph('Folga geométrica diametral d0−d='+number(service.get('diametral_clearance_mm',u.hole_diameter-c.db),6)+
                      ' mm. Não é previsão ou limite superior de deslocamento total. Bearing ordinário admite acomodação; '
                      'sem deslizamento fica fora desta rota. Limite numérico total exige modelo de ELS próprio e permanece pendente, '
                      'mesmo com ELU favorável. O programa não calcula δtotal.')
    for state in out.get('states',[]):
        doc.add_paragraph(STATE_LABELS.get(state['id'],state['id']),style='Heading 2')
        doc.add_paragraph(state.get('basis','')+'. Estado '+str(state.get('status','pendente'))+'. '
                          'Cada estado recebe V integral; as trações concomitantes, inclusive prying aplicável, não mudam ao inverter V. '
                          'Estados alternativos, nunca simultâneos ou somados. A coleção não é solver de contato nem prova de envoltória de todos os contatos possíveis.')
        table(doc,['Barra','x / y mm','Ti kgf','Qi kgf','Ativa em corte'],[
            (rod['id'],number(rod['x'])+' / '+number(rod['y']),number(rod['tension']/KGF),number(rod['shear']/KGF),
             'Sim' if rod['credited_to_shear'] else 'Não; Ti conservado') for rod in state.get('rods',[])],[.55,1.5,1.1,1.1,2.7])
        doc.add_paragraph('ΣQi='+number(state.get('sum_shear_N',0.),6)+' N; resíduo de força='+number(state.get('residual_force_N',0.),6)+
                          ' N; resíduo de torção='+number(state.get('residual_torsion_Nmm',0.),6)+' N·mm. '
                          'V>0 carrega haste/concreto em +x; a reação da haste na placa e a borda de rasgamento ficam em −x; V<0 inverte essas faces.')
        if detailed and state.get('checks'):
            table(doc,['Verificação','Sd','Rd','Unid.','Índice','Estado'],[
                (ck.get('label',ck['id']),_val(ck.get('demand')),_val(ck.get('resistance')),ck.get('unit','N'),
                 _val(ck.get('ratio')),ck.get('status','pendente')) for ck in state['checks']],[2.35,.9,.9,.7,.7,1.4])
    for record in out.get('aci_components',{}).get('states',[]):
        sid=record.get('direct_state_id','Estado ACI')
        doc.add_paragraph('ACI paralelo · '+STATE_LABELS.get(sid,sid),style='Heading 2')
        mat=record.get('material',{})
        doc.add_paragraph('Material efetivo ACI: '+str(mat.get('name',u.material_name))+'; fy='+_val(mat.get('fy',u.fy))+
                          '; fu='+_val(mat.get('fu',u.fu))+' MPa. Todas as trações permanecem, inclusive em hastes inativas ao corte; pryout usa o conjunto ativo.')
        for name,mode in record.get('modes',{}).items():
            doc.add_paragraph(name+': '+str(mode.get('status','pendente'))+'. '+'; '.join(str(v) for v in mode.get('reasons',[])))
            if detailed and mode.get('checks'):
                table(doc,['Mecanismo / barras','Sd N','Rd N','Índice'],[
                    (ck.get('id',','.join(ck.get('ids',[]))),_val(ck.get('demand')),_val(ck.get('resistance')),_val(ck.get('ratio')))
                    for ck in mode['checks']],[3.1,1.3,1.3,1.25])
    for reason in dict.fromkeys(out.get('reasons',[])+out.get('pending_reasons',[])):doc.add_paragraph('PENDÊNCIA / DOMÍNIO: '+str(reason))
    doc.add_paragraph('Fontes: EN 1993-1-8:2005 corrigida, §§3.3, 3.6.1/Table 3.4, 3.7, 3.8, 3.11, 3.12 e 6.2.2; '
                      'SCI P398; HERON 53(2008), pp.87–108; AISC DG1 3ª edição; ACI 318-19. '
                      'Para ASTM/UNC, protocolo complementar identificado, AISC 360 §A3.4 e ASME B1.1. '
                      'Não se declara conformidade integral EN ou aprovação da fundação.')


def compact_direct_layout(doc):
    """Flow supplementary sections; retain only the first cover-page break.

    Legacy independent component sheets force page breaks even when their
    current content is one paragraph. A composed direct report uses normal
    heading keep-with-next and table pagination instead, with no text removed.
    """
    from docx.oxml.ns import qn
    first=True
    for paragraph in doc.paragraphs:
        if paragraph.paragraph_format.page_break_before:
            paragraph.paragraph_format.page_break_before=False
        for br in list(paragraph._p.xpath('.//w:br')):
            if br.get(qn('w:type'))=='page':
                if first:first=False
                else:br.getparent().remove(br)


def append_external_plate_report(doc,panel):
    doc.add_paragraph('Placa externa por composição nominal publicada',style='Heading 2')
    doc.add_paragraph('SCI P398 base pp.64 e70–72; extensão nominal às nervuras por P2076.8, com consumidores N/M próprios. '
        'V integral na alma, sem crédito horizontal das mesas/nervuras. Cortes reais NBR/EN complementares; não usa hp=L nem campo próprio. '
        'NBR6.5.5: γa1=1,10, γa2=1,35; furos líquidos deduzidos com d0+2 mm conservador, sem presumir broca. '
        'Blocos EN3.10.2 e seção tracionada EN1-1 6.2.3: γM0=1,00 e γM2=1,25, com d0 real. Fatores separados.')
    table(doc,['Geometria física','Valor'],[(k,_val(v)) for k,v in panel.get('geometry',{}).items()],[3.7,3.25])
    env=panel.get('application_envelope',{})
    doc.add_paragraph('Envelope OPCIONAL de aplicabilidade do aplicativo: placa basal isolada no ramo de haste governante, '
        'P398 Tabela5.3. Não é exigência normativa geral da base nervurada, ação Ti real nem prova de capacidade V por capacidade T. '
        'O benefício das nervuras no N/M real é preservado. Fora do envelope significa outra qualificação necessária, não falha física.')
    table(doc,['Envelope opcional','Valor'],[(k,_val(v)) for k,v in env.items() if not isinstance(v,(dict,list))],[3.7,3.25])
    table(doc,['Padrão real P398','leff mm'],[(k,_val(v)) for group_ in ('noncircular_leff_mm','circular_leff_mm') for k,v in env.get(group_,{}).items()],[4.8,2.15])
    for state in panel.get('states',[]):
        doc.add_paragraph('Cortes reais · '+STATE_LABELS.get(state['id'],state['id']),style='Heading 3')
        table(doc,['Banda / hastes','Agv / Anv mm²','dnet mm / Q N'],[
            (_val(x['side_y_mm'])+' / '+','.join(x['ids']),_val(x['Agv_mm2'])+' / '+_val(x['Anv_mm2']),
             _val(x['nbr_net_hole_deduction_mm'])+' / '+_val(x['demand_N'])) for x in state.get('bands',[])],[2.1,2.8,2.05])
        table(doc,['Bloco / borda','lv / Anv / Ant','Q / Rd N'],[
            (','.join(x['ids'])+' / '+x['loaded_edge'],_val(x['lv_mm'])+' / '+_val(x['Anv_mm2'])+' / '+_val(x['Ant_mm2']),
             _val(x['demand'])+' / '+_val(x['resistance'])) for x in state.get('prefixes',[])],[1.6,3.1,2.25])
        normal=state.get('normal_cut',{});double=state.get('double_block',{})
        table(doc,['Seção externa tracionada','Valor'],[
            ('Hastes / borda',','.join(normal.get('ids',[]))+' / '+normal.get('loaded_edge','')),
            ('T real / Ag / An',_val(normal.get('demand_N'))+' / '+_val(normal.get('Ag_mm2'))+' / '+_val(normal.get('An_mm2'))),
            ('Bloco duplo Anv / Ant',_val(double.get('Anv_mm2'))+' / '+_val(double.get('Ant_mm2'))),
            ('Bloco duplo T / Rd',_val(double.get('demand'))+' / '+_val(double.get('resistance')))],[3.7,3.25])
    doc.add_paragraph('Prefixos retêm furos inativos. Blocos com c=0,5 são limites suficientes conservadores. '
        'A linha externa comprimida não é renomeada como tracionada. Os componentes não calculam rigidez ou deslocamento de ELS.')
