"""Portuguese presentation only; engine IDs, numbers and schemas stay intact."""
from .display_precision import display_format
from .models import KGF

HEADERS = ('Verificação', 'Sd ou valor', 'Rd ou limite', 'Unid.', 'Índice', 'Atende')
STATUS = {'PASS':'Sim', 'FAIL':'Não', 'PENDING':'Pendente',
          'EXTERNAL_REQUIRED':'Verificação externa', 'EXTERNAL_RESPONSIBILITY':'Responsabilidade externa',
          'CONSTRUCTION_REQUIREMENT':'Exigência de execução', 'NO_STRENGTH_CREDIT':'Sem crédito resistente',
          'NOT_SATISFIED':'Não atendido'}
SCOPE_NAMES = {'dg6_local':'Verificação local ASI DG6', 'nbr_supplement':'Suplemento NBR',
               'lower_panel_shear':'Cortante total da viga inferior', 'external_stability':'Estabilidade do sistema',
               'fabrication':'Execução', 'constructive_pair':'Par de enrijecedores construtivos'}

def fmt(value):
    return '—' if value is None else display_format(value, '.2f').replace('.', ',')

def check_name(row):
    symbol = row['id'].rsplit('_', 1)[-1] if '_dg6_' in row['id'] else ''
    name = row['name'] + (' (' + symbol + ')' if symbol else '')
    return name

def checks_rows(rows):
    output = []
    for row in rows:
        geometric = row.get('category') == 'GEOMETRY'
        sd = row.get('value') if geometric else row.get('demand')
        rd = row.get('limit') if geometric else row.get('resistance')
        unit = row.get('unit', '')
        if not geometric and unit == 'N':
            sd = sd / KGF if sd is not None else None
            rd = rd / KGF if rd is not None else None
            unit = 'kgf'
        relation = row.get('equation', '') if geometric else ''
        name = check_name(row) + (' [' + relation + ']' if relation else '')
        output.append(dict(zip(HEADERS, (name, fmt(sd), fmt(rd), unit, fmt(row.get('eta')),
                                        STATUS.get(row.get('status'), 'Pendente')))))
    return output
