"""Calculated-domain conclusion, independent of deployment/approval flags."""
import math
from stiffened_base_kernels_candidate_20261017.report_adapter import collect_check_states
REQUIRED=('sides','central_plate','central_supports','receiver','internal_transfer','anchorage','upper_washers','concrete_contact','grout','equilibrium','contact_support_geometry','reaction_actions','actual_rods','physical_inputs')
def selected_domain_conclusion(result):
    states=collect_check_states(result)
    failed=[s for s in states if s['state']=='component_bound_not_satisfied']
    outside=[s for s in states if s['state'] not in ('component_bound_satisfied','component_bound_not_satisfied','not_demanded')]
    missing=[k for k in REQUIRED if k not in result]
    def require(condition, message):
        if not condition:missing.append(message)
    for name in REQUIRED:
        require(bool(result.get(name)),name+' vazio')
    sides=result.get('sides',[])
    require(isinstance(sides,list) and len(sides)==2,'dois lados obrigatórios')
    if isinstance(sides,list):
        require({s.get('side') for s in sides if isinstance(s,dict)}=={-1,1},'identidade dos lados')
        for side in sides:
            if not isinstance(side,dict):missing.append('lado inválido');continue
            for name in ('load_path','elastic','selected_resistance','adjacent_base_metal'):
                value=side.get(name)
                require(isinstance(value,dict) and bool(value),'lado sem '+name)
                if isinstance(value,dict):
                    if name=='load_path':require(value.get('domain') is True,'caminho de forças não qualificado')
                    elif name=='selected_resistance':
                        require(value.get('component_domain') is True,'resistência fora do domínio')
                        require(bool(collect_check_states(value)),'resistência sem verificação')
                    else:require(bool(collect_check_states(value)),'lado sem verificações de '+name)
    for name in ('central_plate','central_supports','receiver','internal_transfer','anchorage'):
        component=result.get(name,{})
        require(isinstance(component,dict) and component.get('domain') is True,name+' não qualificado')
        require(bool(collect_check_states(component)),name+' sem verificações')
    for name in ('upper_washers','actual_rods'):
        value=result.get(name,[])
        require(isinstance(value,list) and len(value)==4,name+' deve ter quatro elementos')
        if isinstance(value,list):require(len({v.get('id') for v in value if isinstance(v,dict)})==4,name+' identificadores')
    for washer in result.get('upper_washers',[]):
        wr=washer.get('result',{}) if isinstance(washer,dict) else {}
        require(wr.get('component_domain') is True and bool(wr.get('prescription_checks')),'arruela sem prescrição qualificada')
    for name in ('concrete_contact','grout'):
        require(isinstance(result.get(name,{}).get('capacity_bound_satisfied'),bool),name+' sem verificação')
    require(result.get('contact_support_geometry',{}).get('domain') is True,'contato físico não qualificado')
    eq=result.get('equilibrium',{});loads=result.get('physical_inputs',{}).get('loads',{})
    for residual,action in (('residual_N','N_N'),('residual_M_Nmm','M_Nmm')):
        value=eq.get(residual);scale=max(1.,abs(loads.get(action,0.)))
        # Numerical bookkeeping tolerance, not a resistance or normative allowance.
        require(isinstance(value,(int,float)) and math.isfinite(value) and abs(value)<=1e-8*scale,'equilíbrio '+residual)
    qualified=result.get('calculation_coverage_complete') is True and not result.get('missing') and not outside and not missing and bool(states)
    state='outside_or_incomplete_domain' if not qualified else 'criteria_not_satisfied' if failed else 'criteria_satisfied_in_selected_domain'
    labels={'outside_or_incomplete_domain':'Fora do domínio ou cálculo incompleto',
      'criteria_not_satisfied':'Não atende a um ou mais critérios calculados',
      'criteria_satisfied_in_selected_domain':'Atende aos critérios calculados no domínio selecionado'}
    return dict(state=state,label=labels[state],coverage_qualified=qualified,failed_checks=failed,
                outside_checks=outside,missing_components=missing,
                scope='N + M uniaxial estático, V = 0; somente hipóteses e componentes explicitamente calculados',
                universal_compliance_claim=False)
