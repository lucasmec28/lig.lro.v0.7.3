"""Actual input geometry, no geometry corrections."""
from html import escape
import math

def geometry_svg(inputs,result=None):
    g=inputs['geometry'];co=inputs['connections'];w=inputs['washer'];a=inputs['anchorage']
    L=g['plate_length_mm'];B=g['plate_width_mm'];d=g['column_depth_mm'];bf=g['column_flange_width_mm'];tf=g['column_flange_thickness_mm'];tw=g['column_web_thickness_mm']
    h=g['rib_height_mm'];lr=g['rib_length_mm'];tr=g['rib_thickness_mm']
    if not all(math.isfinite(v) and v>0 for v in (L,B,d,bf,tf,tw,h,lr,tr)):raise ValueError('Dimensões positivas necessárias para desenhar')
    scale=min(650/L,230/B);ox=390;oy=200
    parts=['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 700" role="img" aria-label="Geometria real da base nervurada"><rect width="800" height="700" fill="white"/><g font-family="Arial" font-size="14" fill="#162b42">']
    def text(x,y,s):parts.append(f'<text x="{x}" y="{y}">{escape(str(s))}</text>')
    def rect(x,y,width,height,fill,stroke='#27485f'):
        parts.append(f'<rect x="{ox+x*scale}" y="{oy-y*scale-height*scale}" width="{width*scale}" height="{height*scale}" fill="{fill}" stroke="{stroke}"/>')
    text(25,28,'PLANTA · x horizontal / y vertical · dimensões em mm')
    rect(-L/2,-B/2,L,B,'#edf2f6')
    if result and result.get('contact_support_geometry'):
        x0,y0,x1,y1=result['contact_support_geometry']['actual_contact_rectangle_mm'];rect(x0,y0,x1-x0,y1-y0,'#cdebd0')
    rect(-d/2,-bf/2,tf,bf,'#9aaebc');rect(d/2-tf,-bf/2,tf,bf,'#9aaebc');rect(-d/2+tf,-tw/2,d-2*tf,tw,'#9aaebc')
    for sign in (-1,1):rect(-d/2-lr if sign<0 else d/2,-tr/2,lr,tr,'#d7a461')
    for rod in a['rods']:
        x=rod['x'];y=rod['y'];width=w['washer_width_mm']
        if w['washer_shape']=='circular':
            parts.append(f'<circle cx="{ox+x*scale}" cy="{oy-y*scale}" r="{width*scale/2}" fill="none" stroke="#8960a3"/>')
        else:rect(x-width/2,y-width/2,width,width,'none','#8960a3')
        for cx,cy,diam,col in ((x-w['center_offset_x_mm'],y-w['center_offset_y_mm'],w['base_hole_mm'],'#c53c39'),(x,y,a['rod_diameter_mm'],'#172e45')):
            parts.append(f'<circle cx="{ox+cx*scale}" cy="{oy-cy*scale}" r="{diam*scale/2}" fill="none" stroke="{col}"/>')
        text(ox+x*scale+(-width*scale/2-28 if x<0 else width*scale/2+8),oy-y*scale+5,rod['id'])
    text(25,330,f'L = {L:g} · B = {B:g} · d = {d:g} · bf = {bf:g} · g = {g["gauge_mm"]:g}')
    text(25,355,'Verde: contato comprimido · roxo: arruela · vermelho: furo da base · círculo escuro: haste')
    text(25,390,'ELEVAÇÃO DA NERVURA · geometria dos vértices informados')
    scale=min(400/lr,200/h);ox=180;oy=620
    pts=' '.join(f'{ox+x*scale},{oy-z*scale}' for x,z in [(0,0),*g['rib_top_profile_mm'],(lr,0)])
    parts.append(f'<polygon points="{pts}" fill="#f0dfc6" stroke="#95642f"/>')
    parts.append(f'<line x1="{ox}" y1="{oy}" x2="{ox+lr*scale}" y2="{oy}" stroke="#125e9c" stroke-width="4"/>')
    parts.append(f'<line x1="{ox}" y1="{oy}" x2="{ox}" y2="{oy-h*scale}" stroke="#a33636" stroke-width="4"/>')
    text(25,435,f'h = {h:g}')
    text(25,460,f'tr = {tr:g}')
    text(25,485,f'tp = {g["plate_thickness_mm"]:g}')
    text(25,650,f'lr = {lr:g} · a1 = {g["bolt_s_mm"]:g} · altura / projeção = {h/lr:.3f}')
    text(25,675,f'Pé (azul): garganta {co["rib_foot_throat_mm"]:g} · raiz (vermelho): garganta {co["rib_root_throat_mm"]:g} · pilar–base: perna {co["column_base_leg_mm"]:g}')
    parts.append('</g></svg>');return ''.join(parts)


def geometry_png(inputs,result=None):
    """Rasterize the exact passive SVG primitives for portable Word figures.

    No browser, process, geometry substitution or external file is involved.
    """
    import io
    from xml.etree import ElementTree as ET
    from PIL import Image,ImageDraw,ImageFont
    root=ET.fromstring(geometry_svg(inputs,result));scale=2
    canvas=Image.new('RGB',(1600,1400),'white');draw=ImageDraw.Draw(canvas)
    for family in ('DejaVuSans.ttf','Arial.ttf','arial.ttf'):
        try:
            font=ImageFont.truetype(family,14*scale);break
        except OSError:continue
    else:
        try:font=ImageFont.load_default(size=14*scale)
        except TypeError:font=ImageFont.load_default()
    def color(value,default=None):return default if value in (None,'none') else value
    def num(el,key,default=0):return float(el.get(key,default))*scale
    for el in root.iter():
        tag=el.tag.split('}')[-1];stroke=color(el.get('stroke'));fill=color(el.get('fill'));width=max(1,round(num(el,'stroke-width',1)))
        if tag=='rect':
            x=num(el,'x');y=num(el,'y');draw.rectangle((x,y,x+num(el,'width'),y+num(el,'height')),fill=fill,outline=stroke,width=width)
        elif tag=='circle':
            x=num(el,'cx');y=num(el,'cy');r=num(el,'r');draw.ellipse((x-r,y-r,x+r,y+r),fill=fill,outline=stroke,width=width)
        elif tag=='line':draw.line((num(el,'x1'),num(el,'y1'),num(el,'x2'),num(el,'y2')),fill=stroke,width=width)
        elif tag=='polygon':
            points=[tuple(float(c)*scale for c in pair.split(',')) for pair in el.get('points','').split()]
            draw.polygon(points,fill=fill,outline=stroke,width=width)
        elif tag=='text':draw.text((num(el,'x'),num(el,'y')),''.join(el.itertext()),fill=fill or '#162b42',font=font,anchor='ls')
    out=io.BytesIO();canvas.save(out,format='PNG');return out.getvalue()
