"""Word export of the same user-facing report, without recalculating engineering."""
from html.parser import HTMLParser
from io import BytesIO
from datetime import datetime, timezone
import re
from docx import Document
from docx.shared import Mm, Pt, RGBColor
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.image.image import Image
from stiffened_base_kernels_candidate_20261017.user_report import export_user_mc


class _ReportParser(HTMLParser):
    """Read only the report's visible paragraphs and table cells, in order."""
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.blocks=[]; self.table=None; self.row=None; self.cell=None
        self.block=None; self.buffer=[]; self.in_body=False

    def handle_starttag(self, tag, attrs):
        if tag=='body': self.in_body=True
        if not self.in_body: return
        if tag=='table': self.table=[]
        elif tag=='tr': self.row=[]
        elif tag in ('td','th'): self.cell=[]
        elif tag=='br':
            if self.cell is not None: self.cell.append('\n')
            elif self.block: self.buffer.append('\n')
        elif tag in ('h1','h2','h3','p','figcaption','footer') and self.table is None:
            self.block=tag; self.buffer=[]

    def handle_data(self, data):
        if not self.in_body: return
        if self.cell is not None: self.cell.append(data)
        elif self.block: self.buffer.append(data)

    def handle_endtag(self, tag):
        if tag in ('td','th') and self.cell is not None:
            self.row.append(''.join(self.cell).strip()); self.cell=None
        elif tag=='tr' and self.row is not None:
            self.table.append(self.row); self.row=None
        elif tag=='table' and self.table is not None:
            self.blocks.append(('table',self.table)); self.table=None
        elif tag==self.block:
            self.blocks.append((tag,''.join(self.buffer).strip()));self.block=None;self.buffer=[]
        elif tag=='body': self.in_body=False


def _xml(tag, **attrs):
    node=OxmlElement(tag)
    for key,value in attrs.items(): node.set(qn('w:'+key),str(value))
    return node


def _format_document(doc):
    section=doc.sections[0]
    section.page_width=Mm(210);section.page_height=Mm(297)
    section.left_margin=section.right_margin=Mm(16)
    section.top_margin=section.bottom_margin=Mm(16)
    for name in ('Normal','Title','Heading 1','Heading 2','Heading 3','Caption'):
        style=doc.styles[name];style.font.name='Arial';style.font.color.rgb=RGBColor(0,0,0)
        for border in list(style.element.iter(qn('w:pBdr'))):border.getparent().remove(border)
        style.font.size=Pt({'Title':22,'Heading 1':14,'Heading 2':11,'Heading 3':10,'Caption':9}.get(name,10))
        fmt=style.paragraph_format;fmt.space_after=Pt(5);fmt.line_spacing=1.05
        if name.startswith('Heading'):
            fmt.space_before=Pt(10);fmt.keep_with_next=True
    doc.styles['Title'].paragraph_format.space_after=Pt(8)
    doc.core_properties.title='Memória de cálculo da base de pilar com nervuras'
    doc.core_properties.subject='Ações, geometria, verificações e referências do domínio selecionado'
    doc.core_properties.author='';doc.core_properties.last_modified_by=''
    doc.core_properties.comments='';doc.core_properties.keywords=''
    doc.core_properties.created=doc.core_properties.modified=datetime.now(timezone.utc)
    normal=doc.styles['Normal']._element.get_or_add_rPr()
    normal.append(_xml('w:lang',val='pt-BR'))
    footer=section.footer.paragraphs[0];footer.alignment=WD_ALIGN_PARAGRAPH.RIGHT
    footer.add_run('Página ')
    for number,field in enumerate(('PAGE','NUMPAGES')):
        if number:footer.add_run(' de ')
        simple=_xml('w:fldSimple',instr=field)
        run=OxmlElement('w:r');text=OxmlElement('w:t');text.text='1';run.append(text);simple.append(run)
        footer._p.append(simple)
    for run in footer.runs:run.font.size=Pt(8)



def _add_table(doc, rows):
    if not rows: return
    n=max(len(row) for row in rows)
    headers=rows[0]
    if n==4:
        ratios=(.28,.15,.45,.12) if headers[-1] in ('Fonte','Referência') else (.32,.18,.32,.18)
    elif n==3: ratios=(.25,.63,.12)
    elif n==2: ratios=(.09,.91) if headers[0]=='Fonte' else (.37,.63)
    else: ratios=tuple(1/n for _ in range(n))
    table=doc.add_table(rows=0,cols=n);table.alignment=WD_TABLE_ALIGNMENT.CENTER;table.autofit=False
    for col,ratio in zip(table.columns,ratios): col.width=Mm(178*ratio)
    pr=table._tbl.tblPr
    borders=_xml('w:tblBorders')
    for edge in ('top','left','bottom','right','insideH','insideV'):
        borders.append(_xml('w:'+edge,val='single',sz=4,color='D9D9D9'))
    pr.append(borders)
    margins=_xml('w:tblCellMar')
    for edge in ('top','bottom'): margins.append(_xml('w:'+edge,w=55,type='dxa'))
    for edge in ('left','right'): margins.append(_xml('w:'+edge,w=75,type='dxa'))
    pr.append(margins)
    for index,values in enumerate(rows):
        row=table.add_row()
        # Allow row continuation instead of the LibreOffice cantSplit pagination
        # edge case that can omit body rows when only the header fits.
        row._tr.get_or_add_trPr().append(_xml('w:cantSplit',val='0'))
        if index==0:row._tr.get_or_add_trPr().append(_xml('w:tblHeader'))
        for i,cell in enumerate(row.cells):
            cell.width=Mm(178*ratios[i]);cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            cell.text=values[i] if i<len(values) else ''
            if index==0:cell._tc.get_or_add_tcPr().append(_xml('w:shd',fill='DCE6F1'))
            for paragraph in cell.paragraphs:
                pf=paragraph.paragraph_format;pf.space_after=Pt(1);pf.space_before=Pt(1);pf.line_spacing=1.0
                pf.keep_together=True
                pf.keep_with_next=(index==0 or (len(rows)<=5 and index<len(rows)-1))
                if i==n-1 and headers[-1]=='Fonte':paragraph.alignment=WD_ALIGN_PARAGRAPH.CENTER
                for run in paragraph.runs:
                    run.font.name='Arial';run.font.size=Pt(9);run.font.color.rgb=RGBColor(0,0,0);run.bold=index==0
    doc.add_paragraph().paragraph_format.space_after=Pt(1)


def _add_drawing(doc, png_bytes):
    if not isinstance(png_bytes,bytes) or not png_bytes.startswith(b'\x89PNG\r\n\x1a\n'):
        raise ValueError('O desenho deve ser fornecido como bytes PNG válidos.')
    image=Image.from_file(BytesIO(png_bytes))
    width=min(178,210*image.px_width/image.px_height)
    doc.add_heading('Desenhos essenciais do detalhe',level=2)
    para=doc.add_paragraph();para.alignment=WD_ALIGN_PARAGRAPH.CENTER
    shape=para.add_run().add_picture(BytesIO(png_bytes),width=Mm(width))
    shape._inline.docPr.set('descr','Planta e cortes da geometria da base com nervuras fornecida para cálculo')
    para.paragraph_format.keep_with_next=True
    doc.add_paragraph('Geometria e cortes do detalhe informado. Conferir cotas, materiais e condições de apoio com as entradas desta memória.',style='Caption')


def export_user_docx(inputs, result, png_bytes=None):
    """Return a DOCX byte stream using the HTML report as the sole content source.

    The optional PNG is supplied by the caller from the same physical drawing.
    No rendering process, filesystem write, network call or calculation is started.
    """
    parser=_ReportParser();parser.feed(export_user_mc(inputs,result));parser.close()
    doc=Document();_format_document(doc)
    drawing_added=False
    for kind,content in parser.blocks:
        if kind=='h2' and content.startswith('3.') and png_bytes is not None and not drawing_added:
            _add_drawing(doc,png_bytes);drawing_added=True
        if kind=='table':_add_table(doc,content)
        elif kind=='h1':doc.add_paragraph(content,style='Title')
        elif kind in ('h2','h3'):
            # Headings keep their numbers while avoiding decorative punctuation.
            content=re.sub(r'^(\d+)\.\s*',r'\1 ',content)
            doc.add_heading(content,level=1 if kind=='h2' else 2)
        elif content:doc.add_paragraph(content,style='Caption' if kind=='figcaption' else None)
    if png_bytes is not None and not drawing_added:_add_drawing(doc,png_bytes)
    stream=BytesIO();doc.save(stream);return stream.getvalue()
