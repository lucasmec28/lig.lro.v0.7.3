"""Transactional input boundary. No changes to entered geometry or method."""
import hashlib,json,math
from stiffened_base_kernels_candidate_20261017.complete_fixture import fixture
SCHEMA='lro.stiffened-base.nm.v1'
TEMPLATE=fixture()
ENUMS={'column_fabrication':['welded','rolled'],'left':['P207_long_tension_rib','triangular_inscribed_strips'],
'right':['P207_long_tension_rib','triangular_inscribed_strips'],
'short_edge_support_condition':['both_short_edges_rigidly_supported','not_confirmed'],
'washer_shape':['square','circular'],'family':['headed'],'thread_class':['UNC 2A']}

def leaves(value,path=()):
    if isinstance(value,dict):
        for k,v in value.items():yield from leaves(v,path+(k,))
    else:yield path,value

def parse_fields(fields):
    out={};errors=[]
    for path,template in leaves(TEMPLATE):
        key='.'.join(path);raw=fields.get(key,'')
        try:
            if raw is None or raw=='':raise ValueError('campo obrigatório')
            if isinstance(template,bool):
                if not isinstance(raw,(str,bool)) or raw not in ('Sim','Não',True,False):raise ValueError('confirme Sim ou Não')
                value=raw in ('Sim',True)
            elif isinstance(template,(int,float)):
                if isinstance(raw,bool):raise ValueError('valor numérico, não booleano')
                value=float(raw)
                if not math.isfinite(value):raise ValueError('valor não finito')
            elif isinstance(template,(list,tuple)):
                value=json.loads(raw) if isinstance(raw,str) else raw
                if not isinstance(value,(list,tuple)):raise ValueError('use uma lista JSON')
                if path[-1]=='rods':
                    if len(value)!=4 or any(not isinstance(r,dict) or set(r)!={'id','x','y'} for r in value):raise ValueError('informe exatamente quatro hastes com id, x e y')
                    if len({r['id'] for r in value})!=4:raise ValueError('identificadores de hastes devem ser únicos')
                    numbers=[r[k] for r in value for k in ('x','y')]
                elif path[-1]=='block_bounds_mm':
                    if len(value)!=4:raise ValueError('informe quatro limites')
                    numbers=value
                else:
                    if len(value)<(2 if path[-1]=='rib_top_profile_mm' else 1) or any(not isinstance(row,(list,tuple)) or len(row)!=2 for row in value):raise ValueError('informe pares de valores')
                    numbers=[n for row in value for n in row]
                if any(isinstance(n,bool) or not isinstance(n,(int,float)) or not math.isfinite(n) for n in numbers):raise ValueError('a lista deve conter números finitos')
            else:
                if not isinstance(raw,str):raise ValueError('texto obrigatório')
                value=raw.strip()
                if not value:raise ValueError('texto obrigatório')
                if path[-1] in ENUMS and value not in ENUMS[path[-1]]:raise ValueError('opção de método/detalhe não reconhecida')
            node=out
            for part in path[:-1]:node=node.setdefault(part,{})
            node[path[-1]]=value
        except (ValueError,TypeError) as exc:errors.append(f'{key}: {exc}')
    return out,errors

def validate_document(doc):
    if not isinstance(doc,dict) or doc.get('schema')!=SCHEMA:raise ValueError('Formato de projeto não reconhecido')
    inputs=doc.get('inputs')
    if not isinstance(inputs,dict):raise ValueError('Entradas ausentes')
    expected={'.'.join(p) for p,_ in leaves(TEMPLATE)}
    actual={'.'.join(p):v for p,v in leaves(inputs)}
    if set(actual)!=expected:raise ValueError('Campos ausentes ou desconhecidos: '+', '.join(sorted(set(actual)^expected)))
    parsed,errors=parse_fields(actual)
    if errors:raise ValueError('; '.join(errors))
    return parsed

def _canonical(value):
    if isinstance(value,dict):return {k:_canonical(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)):return [_canonical(v) for v in value]
    if isinstance(value,(int,float)) and not isinstance(value,bool):return float(value)
    return value

def fingerprint(inputs):return hashlib.sha256(json.dumps(_canonical(inputs),sort_keys=True,allow_nan=False).encode()).hexdigest()
def document(inputs):return json.dumps(dict(schema=SCHEMA,inputs=inputs),ensure_ascii=False,indent=2,allow_nan=False)

def calculate(inputs):
    from stiffened_base_kernels_candidate_20261017.full_composer import compose_complete_selected_domain
    try:result=compose_complete_selected_domain(**inputs)
    except (ValueError,TypeError,KeyError,IndexError,ZeroDivisionError,OverflowError) as exc:
        result=dict(calculation_coverage_complete=False,assembly_approval=False,physical_inputs=inputs,
                    missing=[str(exc)],check_states=[],input_domain_error=str(exc))

    from .conclusion import selected_domain_conclusion
    conclusion=selected_domain_conclusion(result)
    result['selected_domain_conclusion']={k:conclusion[k] for k in ('state','label','coverage_qualified','scope','universal_compliance_claim')}
    return result
