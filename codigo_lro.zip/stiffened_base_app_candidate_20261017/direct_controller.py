"""Transactional input boundary. No changes to entered geometry or method."""
import hashlib,json,math
from stiffened_base_kernels_candidate_20261017.complete_fixture import fixture
from dataclasses import asdict
from lro.direct_anchor_shear import DirectAnchorShear
SCHEMA='lro.stiffened-base.nmv.direct.v1'
TEMPLATE=fixture()
TEMPLATE['washer']['A36_equivalence_selected']=False
TEMPLATE['direct_shear']=asdict(DirectAnchorShear())
TEMPLATE['direct_detail']=dict(grout_t_mm=0.,block_height_mm=0.,actions_reference_plate_top_confirmed=False,actions_reference_ref='')
ENUMS={'column_fabrication':['welded','rolled'],'left':['P207_long_tension_rib','triangular_inscribed_strips'],
'right':['P207_long_tension_rib','triangular_inscribed_strips'],
'short_edge_support_condition':['both_short_edges_rigidly_supported','not_confirmed'],
'washer_shape':['square','circular'],'family':['headed'],'thread_class':['UNC 2A']}

def leaves(value,path=()):
    if isinstance(value,dict):
        for k,v in value.items():yield from leaves(v,path+(k,))
    else:yield path,value

def parse_fields(fields):
    out={};errors=[]
    for path,template in leaves(TEMPLATE):
        key='.'.join(path);raw=fields.get(key,'')
        try:
            if raw is None or (raw=='' and not (path[0]=='direct_shear' and isinstance(template,str))):raise ValueError('campo obrigatório')
            if isinstance(template,bool):
                if not isinstance(raw,(str,bool)) or raw not in ('Sim','Não',True,False):raise ValueError('confirme Sim ou Não')
                value=raw in ('Sim',True)
            elif isinstance(template,(int,float)):
                if isinstance(raw,bool):raise ValueError('valor numérico, não booleano')
                value=float(raw)
                if not math.isfinite(value):raise ValueError('valor não finito')
            elif isinstance(template,(list,tuple)):
                value=json.loads(raw) if isinstance(raw,str) else raw
                if not isinstance(value,(list,tuple)):raise ValueError('use uma lista JSON')
                if path[-1]=='rods':
                    if len(value)!=4 or any(not isinstance(r,dict) or set(r)!={'id','x','y'} for r in value):raise ValueError('informe exatamente quatro hastes com id, x e y')
                    if len({r['id'] for r in value})!=4:raise ValueError('identificadores de hastes devem ser únicos')
                    numbers=[r[k] for r in value for k in ('x','y')]
                elif path[-1]=='block_bounds_mm':
                    if len(value)!=4:raise ValueError('informe quatro limites')
                    numbers=value
                else:
                    if len(value)<(2 if path[-1]=='rib_top_profile_mm' else 1) or any(not isinstance(row,(list,tuple)) or len(row)!=2 for row in value):raise ValueError('informe pares de valores')
                    numbers=[n for row in value for n in row]
                if any(isinstance(n,bool) or not isinstance(n,(int,float)) or not math.isfinite(n) for n in numbers):raise ValueError('a lista deve conter números finitos')
            else:
                if not isinstance(raw,str):raise ValueError('texto obrigatório')
                value=raw.strip()
                if not value and path[0]!='direct_shear':raise ValueError('texto obrigatório')
                if path[-1] in ENUMS and value not in ENUMS[path[-1]]:raise ValueError('opção de método/detalhe não reconhecida')
            node=out
            for part in path[:-1]:node=node.setdefault(part,{})
            node[path[-1]]=value
        except (ValueError,TypeError) as exc:errors.append(f'{key}: {exc}')
    return out,errors

def validate_document(doc):
    if not isinstance(doc,dict) or doc.get('schema')!=SCHEMA:raise ValueError('Formato de projeto não reconhecido')
    inputs=doc.get('inputs')
    if not isinstance(inputs,dict):raise ValueError('Entradas ausentes')
    expected={'.'.join(p) for p,_ in leaves(TEMPLATE)}
    actual={'.'.join(p):v for p,v in leaves(inputs)}
    if set(actual)!=expected:raise ValueError('Campos ausentes ou desconhecidos: '+', '.join(sorted(set(actual)^expected)))
    parsed,errors=parse_fields(actual)
    if errors:raise ValueError('; '.join(errors))
    return parsed

def _canonical(value):
    if isinstance(value,dict):return {k:_canonical(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)):return [_canonical(v) for v in value]
    if isinstance(value,(int,float)) and not isinstance(value,bool):return float(value)
    return value

def fingerprint(inputs):return hashlib.sha256(json.dumps(_canonical(inputs),sort_keys=True,allow_nan=False).encode()).hexdigest()
def document(inputs):return json.dumps(dict(schema=SCHEMA,inputs=inputs),ensure_ascii=False,indent=2,allow_nan=False)

def calculate(inputs):
    from stiffened_base_kernels_candidate_20261017.direct_composer import compose_stiffened_direct
    try: return compose_stiffened_direct(**inputs)
    except (ValueError,TypeError,KeyError,IndexError,ZeroDivisionError,OverflowError,AttributeError) as exc:
        return dict(coverage_qualified=False,calculation_coverage_complete=False,assembly_approval=False,
            physical_inputs=inputs,missing=[str(exc)],checks_flat=[],input_domain_error=str(exc),
            conclusion_label='Fora do domínio ou composição incompleta',nm_components={},direct_anchor_shear={},aci_components={},web_transfer={})


def direct_example(sign=1):
    """Deliberately loaded synthetic example; certificates are NOT real products."""
    from .positive_fixture import positive_fixture
    from lro.direct_anchor_shear import MODEL,unc_thread_area
    p=positive_fixture(sign)
    p['loads']['V_N']=40000.
    p['anchorage']['rod_material']='ASTM A36'
    p['washer'].update(base_hole_mm=28.4,center_offset_x_mm=0.,center_offset_y_mm=0.,A36_equivalence_selected=True)
    u=DirectAnchorShear(model=MODEL,material_name='ASTM A36',material_basis='ASTM_supplementary',
        material_specification='ASTM A36/A36M-19',material_reference='EXEMPLO SINTÉTICO: certificado não real',
        material_quality_reference='EXEMPLO SINTÉTICO: qualidade e alongamento documentados para teste',
        material_protocol='astm_a36_supplementary_v1',certification_reference='EXEMPLO SINTÉTICO: fabricação final',
        ductility_reference='EXEMPLO SINTÉTICO: alongamento do produto final',supplementary_application_accepted=True,
        fy=250.,fu=400.,thread_area=unc_thread_area(25.4,8.),thread_standard='UNC_2A',thread_tpi=8.,
        thread_area_source='calculated_asme',thread_manufacture='cut',thread_compliance='unverified_cut',
        thread_reference='EXEMPLO SINTÉTICO: UNC1-8 Class2A, área calculada ASME',hole_diameter=28.4,
        hole_kind='normal_round',hole_basis='supplementary_unc_bounded',normal_hole_tolerance_verified=True,
        execution_reference='EXEMPLO SINTÉTICO: furação e inspeção',grout_complete=True,grout_cured=True,
        no_free_standoff=True,grout_reference='EXEMPLO SINTÉTICO: graute integral curado',static_loading=True)
    p['direct_shear']=asdict(u)
    p['direct_detail']=dict(grout_t_mm=25.,block_height_mm=700.,actions_reference_plate_top_confirmed=True,
        actions_reference_ref='EXEMPLO SINTÉTICO: ações na face superior da placa')
    return p
