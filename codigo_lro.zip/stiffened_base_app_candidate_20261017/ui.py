"""Explicit-entry review route; does not modify the existing base routes."""
import json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import streamlit as st
from stiffened_base_app_candidate_20261017.controller import TEMPLATE,leaves,parse_fields,validate_document,document,fingerprint,calculate
from stiffened_base_kernels_candidate_20261017.complete_fixture import fixture

GROUPS={'geometry':'1 · Geometria real (mm)','materials':'2 · Aços (MPa)','loads':'3 · Ações de cálculo (N e N·mm)',
'connections':'4 · Soldas, contato e condições físicas','anchorage':'5 · Ancoragem e bloco de concreto',
'washer':'6 · Arruela e porca','models':'7 · Método resistente por lado'}
LABELS={
'plate_length_mm':'Comprimento L da placa','plate_width_mm':'Largura B da placa','plate_thickness_mm':'Espessura da placa',
'column_depth_mm':'Altura d do pilar','column_flange_width_mm':'Largura bf das mesas','column_flange_thickness_mm':'Espessura tf da mesa',
'column_web_thickness_mm':'Espessura tw da alma','rib_length_mm':'Projeção lr da nervura','rib_height_mm':'Altura h na raiz',
'rib_thickness_mm':'Espessura da nervura','rib_top_profile_mm':'Vértices do topo da nervura [[s,h], …]',
'gauge_mm':'Distância transversal entre eixos das hastes','bolt_s_mm':'Distância a1 da face do pilar ao eixo da haste',
'N_N':'Força normal N (compressão positiva)','M_Nmm':'Momento M (sinal define o lado tracionado)','V_N':'Cortante externo V (domínio: zero)',
'rods':'Hastes reais [{"id":"A1","x":…,"y":…}, …]','free_rod_segments':'Trechos livres da haste [[comprimento mm, área mm²], …]',
'block_bounds_mm':'Limites do bloco [xmin, ymin, xmax, ymax] (mm)',
'column_direct_bearing':'Contato direto garantido entre pilar e placa','rib_compression_bearing':'Contato compressivo garantido nervura–placa',
'plate_monolithic':'Placa monolítica contínua sobre a nervura','equivalent_two_rib_fillets':'Dois filetes equivalentes na nervura',
'whole_rib_connected':'Toda a seção da nervura conectada','intact_rib':'Nervura sem furos ou recortes',
'short_edge_support_condition':'Condição de apoio dos dois catetos','column_fabrication':'Fabricação do perfil',
'column_root_radius_mm':'Raio real da raiz do perfil laminado (mm)','internal_throat_mm':'Garganta da solda mesa–alma (mm)',
'rib_foot_throat_mm':'Garganta dos filetes nervura–placa (mm)','rib_root_throat_mm':'Garganta dos filetes nervura–mesa (mm)',
'column_base_leg_mm':'Perna dos filetes pilar–placa (mm)','mechanical_resistance':'Resistência de cálculo documentada da cabeça (N)',
'mechanical_ref':'Referência que comprova a resistência da cabeça','bearing_area_ref':'Referência da área líquida da cabeça',
'left':'Nervura esquerda (x negativo)','right':'Nervura direita (x positivo)',
'washer_centered_on_rod':'Arruela centrada na haste real','center_offset_x_mm':'Centro da arruela menos centro do furo da base: dx (mm)',
'center_offset_y_mm':'Centro da arruela menos centro do furo da base: dy (mm)'}
from stiffened_base_app_candidate_20261017.controller import ENUMS

def display_label(key):
    if key in LABELS:return LABELS[key]
    from stiffened_base_kernels_candidate_20261017.user_report import _LABELS
    if key in _LABELS:return _LABELS[key]
    return key.replace('_mm2',' (mm²)').replace('_mm',' (mm)').replace('_MPa',' (MPa)').replace('_',' ')

def load_inputs(data=None):
    for path,template in leaves(TEMPLATE):
        key='sb.'+'.'.join(path)
        if data is None:st.session_state[key]=''
        else:
            v=data
            for part in path:v=v[part]
            st.session_state[key]=('Sim' if v else 'Não') if isinstance(v,bool) else json.dumps(v,ensure_ascii=False) if isinstance(v,(list,tuple)) else str(v)
    st.session_state.pop('sb.result',None);st.session_state.pop('sb.signature',None)

def render():
    st.header('Base nervurada · N + M')
    st.caption('Ambiente de revisão isolado. Cálculo estático com V = 0, quatro hastes simétricas e condições físicas explicitamente confirmadas. Não substitui a revisão do projeto.')
    st.info('Tração: SCI P207, h ≥ 1,8 lr. Compressão: núcleo triangular inscrito, Shakya–Vinnakota com errata. A escolha é feita por lado, sem alterar sua geometria. Fora desse domínio, o resultado parcial e a memória permanecem disponíveis.')
    c1,c2=st.columns(2)
    c1.button('Novo projeto · limpar todos os campos',on_click=load_inputs,key='sb.reset')
    c2.button('Carregar exemplo ilustrativo N + M',on_click=lambda:load_inputs(fixture()),key='sb.example',help='Preenche explicitamente um exemplo com falhas de resistência; não é uma solução aprovada.')
    with st.expander('Importar / reimportar projeto JSON'):
        upload=st.file_uploader('Arquivo de projeto',type=['json'],key='sb.upload')
        text=st.text_area('Ou cole o JSON do projeto',key='sb.import_text')
        if st.button('Aplicar importação',key='sb.import'):
            try:
                raw=upload.getvalue().decode('utf-8') if upload else text
                data=validate_document(json.loads(raw))
                load_inputs(data);st.success('Projeto importado. O resultado anterior foi invalidado.');st.rerun()
            except (ValueError,TypeError,KeyError) as exc:st.error(f'Importação recusada sem alterar o projeto: {exc}')
    fields={}
    for group,title in GROUPS.items():
        with st.expander(title,expanded=group in ('geometry','loads')):
            st.caption('Preencha todos os campos. Unidades indicadas no nome; nenhuma dimensão é escolhida automaticamente.')
            for path,template in leaves({group:TEMPLATE[group]}):
                leaf=path[-1];key='sb.'+'.'.join(path);label=display_label(leaf)
                if len(path)>2:label=' / '.join(path[1:-1])+' · '+label
                if isinstance(template,bool):value=st.selectbox(label,['','Sim','Não'],key=key)
                elif leaf in ENUMS:value=st.selectbox(label,['']+ENUMS[leaf],key=key,format_func=lambda x:{'welded':'Soldado','rolled':'Laminado','P207_long_tension_rib':'Tração · nervura longa SCI P207','triangular_inscribed_strips':'Compressão · faixas triangulares inscritas','both_short_edges_rigidly_supported':'Dois catetos rigidamente apoiados','not_confirmed':'Apoio não confirmado','square':'Quadrada','circular':'Circular','headed':'Cabeça mecânica'}.get(x,x))
                elif isinstance(template,(list,tuple)):value=st.text_area(label,key=key,height=90,help='Lista JSON com coordenadas e dimensões reais. Não é ajustada pelo programa.')
                else:value=st.text_input(label,key=key)
                fields['.'.join(path)]=value
    inputs,errors=parse_fields(fields)
    if not errors:
        from stiffened_base_app_candidate_20261017.drawing import geometry_svg
        svg=None
        try:
            current=st.session_state.get('sb.result') if st.session_state.get('sb.signature')==fingerprint(inputs) else None
            svg=geometry_svg(inputs,current)
            st.image(svg,width="stretch")
            st.download_button('Salvar desenho SVG',svg,'geometria_base.svg','image/svg+xml',key='sb.svg')
        except (ValueError,KeyError,TypeError,IndexError):st.warning('Geometria incompleta ou incompatível para desenhar; confira os valores.')
        st.download_button('Salvar entradas JSON',document(inputs),'base_nervurada.json','application/json',key='sb.save')
    if st.button('Calcular base nervurada',type='primary',key='sb.calculate'):
        if errors:
            st.error('Complete os campos antes de calcular. Nenhum valor foi substituído.')
            st.write(errors)
        else:
            st.session_state['sb.result']=calculate(inputs);st.session_state['sb.signature']=fingerprint(inputs)
            st.rerun()
    result=st.session_state.get('sb.result')
    if result is None:return
    stale=bool(errors) or st.session_state.get('sb.signature')!=fingerprint(inputs)
    if stale:
        st.warning('As entradas foram alteradas. Recalcule para visualizar ou exportar o resultado correspondente.');return
    from stiffened_base_app_candidate_20261017.conclusion import selected_domain_conclusion
    st.subheader(selected_domain_conclusion(result)['label'])
    if result.get('calculation_coverage_complete'):st.success('Verificações do domínio selecionado calculadas. Isto não significa resistência atendida.')
    else:st.warning('Cobertura parcial / fora do domínio selecionado. Consulte as pendências abaixo.')
    for note in result.get('missing',[]):st.warning(note)
    if result.get('reaction_actions'):
        st.subheader('Equilíbrio e ações')
        st.json(result['reaction_actions']);st.json(result.get('equilibrium',{}))
    st.subheader('Verificações e estados')
    from stiffened_base_kernels_candidate_20261017.user_report import _path, _label
    from stiffened_base_kernels_candidate_20261017.report_adapter import collect_check_states
    states=collect_check_states(result)
    failed=sum(s.get('state')=='component_bound_not_satisfied' for s in states)
    if failed:st.error(f'{failed} verificações não atendem ao limite adotado. A memória permanece disponível.')
    rows=[{'Componente / critério':_path(s['component']),'Estado':_label(s['state'])} for s in states]
    if rows:st.dataframe(rows,hide_index=True,width='stretch')
    with st.expander('Resultados completos, inclusive falhas'):
        st.json(result)
    st.download_button('Salvar resultados JSON',json.dumps(result,ensure_ascii=False,indent=2),'resultados_base.json','application/json',key='sb.result_json')
    from stiffened_base_kernels_candidate_20261017.user_report import export_user_mc
    from stiffened_base_app_candidate_20261017.docx_report import export_user_docx
    from stiffened_base_app_candidate_20261017.drawing import geometry_png
    png=geometry_png(inputs,result) if svg is not None else None
    st.download_button('Exportar memória de cálculo Word',export_user_docx(inputs,result,png_bytes=png),'memoria_base_nervurada.docx','application/vnd.openxmlformats-officedocument.wordprocessingml.document',key='sb.mc_word')
    st.download_button('Salvar prévia HTML da memória',export_user_mc(inputs,result,drawing_svg=svg),'memoria_base_nervurada.html','text/html',key='sb.mc')
