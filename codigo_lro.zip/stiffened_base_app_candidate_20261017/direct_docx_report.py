"""Client-facing editorial export of stored N/M/V results; never recalculates."""
from io import BytesIO
import hashlib
import json
from docx import Document
from docx.shared import Mm,Pt,RGBColor
from docx.oxml.ns import qn
from .docx_report import _format_document,_add_table as _legacy_table,_add_drawing
from .direct_report_view import GROUPS,STATE_LABELS,label,text,leaves,display_checks,governing_groups,reference_pt


def _add_table(doc,rows,ratios=None):
    _legacy_table(doc,rows)
    if not rows:return
    table=doc.tables[-1]
    if ratios is None:ratios=(.52,.48) if len(rows[0])==2 else tuple(1/len(rows[0]) for _ in rows[0])
    for col,r in zip(table.columns,ratios):col.width=Mm(178*r)
    for row in table.rows:
        # Compact client rows fit a page; avoid separating a criterion from its ID.
        for flag in row._tr.xpath('./w:trPr/w:cantSplit'):flag.set(qn('w:val'),'1')
        for cell,r in zip(row.cells,ratios):
            cell.width=Mm(178*r)
            for paragraph in cell.paragraphs:
                paragraph.paragraph_format.keep_with_next=False
                paragraph.paragraph_format.keep_together=True
    return table


def _v(x):return '—' if x is None else text(x)


def _status(passed,complete=True):return 'Pendente' if not complete else 'Atende' if passed else 'Não atende'


def _illustrative(inputs):
    raw=json.dumps(inputs,ensure_ascii=False).lower()
    return any(s in raw for s in ('exemplo sintético','illustrative','exemplo ilustrativo','certificado não real'))


def _summary_status(result,prefix,complete):
    rows=[x for x in result.get('checks_flat',[]) if x.get('component','').startswith(prefix)]
    return _status(bool(rows) and all(x.get('state')=='atende' for x in rows),complete and bool(rows))


def export_user_docx(inputs,result,png_bytes=None):
    if result.get('physical_inputs') is not None and result['physical_inputs']!=inputs:
        raise ValueError('Resultado desatualizado: as entradas N/M/V não correspondem à memória.')
    doc=Document();_format_document(doc)
    doc.styles['Subtitle'].font.color.rgb=RGBColor(0,0,0)
    doc.core_properties.title='Memória de cálculo da base nervurada com cisalhamento direto'
    doc.add_paragraph('Memória de cálculo da base nervurada',style='Title')
    doc.add_paragraph('Força normal momento e cisalhamento direto aos chumbadores',style='Subtitle')
    if _illustrative(inputs):doc.add_paragraph('EXEMPLO ILUSTRATIVO DE TESTE. As dimensões, ações e referências documentais deste exemplo não são dados de uma obra do usuário nem certificados reais. Não utilizar como projeto executivo.')
    passed=result.get('selected_route_resistance_pass') is True
    complete=result.get('calculation_coverage_complete') is True
    doc.add_paragraph('ESCOPO NOMINAL DELIMITADO N + M + V ATENDE.' if passed else 'ESCOPO NOMINAL N + M + V NÃO APROVADO. '+('Há critérios não atendidos.' if complete else 'Há pendências de cobertura ou de dados.'))
    doc.add_paragraph('Esta memória apresenta a ligação no domínio selecionado, seus critérios governantes e todas as falhas ou pendências identificadas. Não aprova fundação, solo, estabilidade global, rigidez rotacional ou execução. O relatório usa os resultados armazenados, sem recalcular ou substituir entradas.')
    direct=result.get('direct_anchor_shear',{});aci=result.get('aci_components',{});web=result.get('web_transfer',{});plate=result.get('plate_transfer_scope',{});nm=result.get('nm_components',{})
    nm_missing=[x for x in nm.get('missing',[]) if x!='Ancoragem transferida ao consumidor direto de estados N/M/V.']
    doc.add_heading('Conclusão por componente',level=1)
    _add_table(doc,[['Componente','Conclusão e abrangência'],
      ['Componentes normais N e M',_summary_status(result,'nm_components',not nm_missing)+'. Placa, nervuras, soldas e arruelas axiais nos domínios selecionados.'],
      ['Hastes e pressão nos furos EN',_status(direct.get('steel_plate_uls',{}).get('passes'),direct.get('domain',{}).get('eligible',False))+'. Tração, cortante reduzido, pressão no furo e interação.'],
      ['Transferência pela placa',_status(plate.get('passes'),plate.get('complete',False))+'. Bandas, cortes e blocos reais, além do envelope opcional.'],
      ['Introdução de V pela alma e receptor',_summary_status(result,'web_transfer',web.get('web_transfer_calculated',False))+'. Solda alma à placa, metal base, receptor e ligação interna mesa à alma.'],
      ['Ancoragem no concreto ACI',_status(aci.get('passes'),aci.get('complete',False))+'. Modos selecionados e estados alternativos, separados dos fatores EN e NBR.'],
      ['Condição de serviço',_status(direct.get('service_scope',{}).get('passes'),direct.get('service_scope',{}).get('eligible',False))+'. Acomodação por contato; deslocamento total não calculado.'],
      ['Fundação e comprovação de execução','Externas ao cálculo da ligação. Exigem dimensionamento e documentação próprios.']])
    missing=list(dict.fromkeys(str(x) for x in result.get('missing',[])))
    doc.add_heading('Falhas e pendências',level=1)
    for note in missing:doc.add_paragraph('Pendência: '+note.replace('in-plane','no plano da placa'))
    failures=[x for x in display_checks(result) if x.get('state')!='atende']
    if not missing and not failures:doc.add_paragraph('Nenhuma falha resistente ou pendência de cobertura no escopo nominal delimitado. As condições de execução e os escopos externos abaixo continuam obrigatórios.')
    if failures:
        _add_table(doc,[['ID e componente','Estado','Solicitação / limite','Índice']]+[[c['id']+' '+c['family']+'\n'+c['criterion'],c['state'],_v(c.get('demand'))+' / '+_v(c.get('resistance'))+' '+c.get('unit',''),_v(c.get('display_ratio'))] for c in failures],(.43,.15,.28,.14))
    doc.add_heading('Ações e equilíbrio',level=1)
    loads=inputs.get('loads',{})
    _add_table(doc,[['Ação de cálculo','Combinação informada','Projeção normal N/M'],['N (N)',_v(loads.get('N_N')),_v(loads.get('N_N'))],['M (N·mm)',_v(loads.get('M_Nmm')),_v(loads.get('M_Nmm'))],['V (N)',_v(loads.get('V_N')),'0 somente nos componentes normais']],(.28,.30,.42))
    doc.add_paragraph('A projeção normal preserva o benefício das nervuras em N/M. O cortante informado é mantido integralmente nos consumidores da alma, placa, hastes e concreto; não é redistribuído às nervuras. As trações concomitantes, incluindo efeito alavanca quando aplicável no modelo N/M, são preservadas.')
    if nm.get('reaction_actions'):_add_table(doc,[['Reação ou resíduo','Valor']]+[[label(k),text(v)] for k,v in {**nm.get('reaction_actions',{}),**nm.get('equilibrium',{})}.items() if not isinstance(v,(dict,list))])
    if png_bytes is not None:_add_drawing(doc,png_bytes)
    doc.add_heading('Geometria materiais e condições informadas',level=1)
    doc.add_paragraph('Unidades N, mm e MPa. Entradas conservadas sem substituição silenciosa. Nos campos documentais, a identificação do exemplo ou do documento fornecido é mantida.')
    for group,values in inputs.items():
        if group=='loads':continue
        doc.add_heading(GROUPS.get(group,label(group)),level=2)
        rows=[['Parâmetro','Valor informado']]
        for path,value in leaves(values):
            if path[-1] in ('plate_transfer_complete','plate_transfer_reference'):continue
            name=' / '.join(label(x) for x in path)
            shown=text(value)
            if path[-1]=='service_total_limit' and values.get('service_slip_requirement')!='numeric_total_limit':shown='Não utilizado neste modo; valor armazenado '+shown
            rows.append([name,shown])
        _add_table(doc,rows)
    doc.add_heading('Condições comuns e limites de aplicação',level=1)
    for paragraph in [
      'O domínio exige carregamento estático, sem torção externa, ações na face superior da placa, graute integral e curado, furos circulares normais controlados e ausência de afastamento livre, vazios ou bainhas. Furos alargados e fase anterior à cura não são liberados.',
      'A placa deve ser monolítica; os furos, filetes e arruelas devem caber no contorno físico. As nervuras precisam conservar o contorno conectado e as condições de apoio exigidas pelo modelo normal selecionado. A geometria informada não é substituída por um exemplo padrão.',
      'A solda da alma à placa exige dois filetes contínuos equivalentes no comprimento físico considerado. Soldas internas, eletrodos, procedimento, união integral e inspeção precisam corresponder ao detalhe. Não podem existir recortes, furos, folgas ou interrupções não informados nas regiões de transferência.',
      'O cálculo local do receptor não comprova a estabilidade ou as tensões globais do pilar. O comprimento destravado da mesa e as ações concomitantes devem ser comprovados no projeto global. A ligação interna mesa à alma é calculada; fabricação e inspeção não são certificadas por esta memória.',
      'Arruela superior não soldada somente axial. Não há crédito resistente de atrito, chave de cisalhamento, engaste fictício, arruela lateral ou nervura em V.',
      'ASTM A36 e rosca UNC são aplicação complementar documentada, sem equivalência automática às classes EN. Área resistente As e propriedades finais devem corresponder ao produto. A aceitação do procedimento não substitui certificados, geometria de rosca, ductilidade ou rastreabilidade.',
      'EN γM2=1,25 na haste e pressão no furo. NBR γa1=1,10 e γa2=1,35 nos respectivos modos. ACI utiliza fatores φ próprios e redução 0,80 no cortante sobre graute. Não combinar fatores nem somar capacidades de normas diferentes.',
      'A folga diametral d0−d é informação geométrica, não previsão nem limite superior do movimento. O programa não calcula δtotal. Exigência antideslizante ou limite total numérico precisa de modelo próprio de ELS; não há promessa de deslocamento nulo.',
      'Fundação armada, solo, fendilhamento global, execução, fadiga, sismo, flexão biaxial e geometrias fora dos padrões implementados não são aprovados por esta composição.'
    ]:doc.add_paragraph(paragraph)
    doc.add_heading('Hastes e estados alternativos de contato',level=1)
    mat=direct.get('material',{});res=direct.get('resistances',{})
    _add_table(doc,[['Parâmetro ou resistência','Valor']]+[[name,_v(value)] for name,value in [('fy da haste (MPa)',mat.get('fy_MPa')),('fu da haste (MPa)',mat.get('fu_MPa')),('As real (mm²)',mat.get('As_mm2')),('Coeficiente αv complementar',res.get('alpha_v')),('Fator da rosca',res.get('kthread')),('Fator de junta longa',res.get('beta_Lf')),('F1 (N)',res.get('F1_N')),('F2 (N)',res.get('F2_N')),('Cortante resistente mínimo (N)',res.get('shear_Rd_N')),('Tração resistente EN (N)',res.get('tension_Rd_N'))]])
    doc.add_paragraph('EN 1993-1-8 §6.2.2: F1 = βLf kthread αv fu As / γM2; F2 = (0,44−0,0003fy)fuAs/γM2; VRd=min(F1,F2). TRd=kthread·0,9fuAs/γM2. Interação: Qi/VRd+Ti/(1,4TRd)≤1, além dos limites individuais. A pressão nos furos é verificada separadamente. O efeito local do graute está implícito na resistência reduzida, sem afirmar momento individual nulo na haste.')
    states=direct.get('states',[])
    rows=[['Estado e haste','Ti (N)','Qi (N)','Corte ativo']]
    for state in states:
        for rod in state.get('rods',[]):rows.append([STATE_LABELS.get(state.get('id'),state.get('id',''))+' / '+str(rod['id']),text(rod['tension']),text(rod['shear']),text(rod['credited_to_shear'])])
    _add_table(doc,rows,(.48,.18,.18,.16))
    doc.add_paragraph('Os três estados são alternativas com V integral, nunca simultâneas ou somadas. Hastes inativas ao corte mantêm sua tração. O concreto ACI é verificado em cada estado, incluindo as alternativas de borda; essas alternativas não criam novas ações físicas.')
    _add_table(doc,[['Fator ACI','Valor']]+[[name,_v(aci.get(key))] for key,name in [('phi_N','φ para tração'),('phi_V','φ para cortante'),('concrete_phi','φ do concreto'),('grout_factor','Redução sobre graute')]])
    doc.add_heading('Placa externa e envelope opcional',level=1)
    doc.add_paragraph('A composição usa SCI P398, p. 64 e 70–72, e P207 §6.8 para os componentes normais das nervuras. V é introduzido pela alma e verificado em bandas reais, cortes brutos e líquidos, blocos laterais, prefixos e bloco da dupla. Não há campo de transferência próprio no plano da placa nem largura efetiva arbitrária.')
    doc.add_paragraph('Envelope OPCIONAL de aplicação: a placa basal isolada precisa atender ao limite selecionado da Tabela 5.3 do P398. Não é exigência normativa geral da base nervurada, não altera Ti e não demonstra capacidade V a partir de capacidade T. Fora desse envelope significa cobertura não qualificada neste ramo, não ruptura física automática.')
    env=plate.get('application_envelope',{})
    _add_table(doc,[['Envelope opcional P398','Valor']]+[[name,_v(value)] for name,value in [('Estado',_status(env.get('qualifies'),bool(env))),('mx (mm)',env.get('mx_mm')),('e (mm)',env.get('e_mm')),('ex (mm)',env.get('ex_mm')),('Comprimento efetivo governante (mm)',env.get('leff_mm')),('Capacidade basal de referência (N)',env.get('basal_plate_capacity_N')),('Referência resistente da dupla (N)',env.get('reference_rod_pair_N')),('Relação do envelope',env.get('scope_ratio'))]])
    doc.add_paragraph('NBR 8800 §6.5.5: bandas bruta e líquida, com dedução conservadora d0+2 mm sem presumir fabricação por broca. EN §3.10.2: blocos com coeficiente transversal conservador 0,5. EN 1993-1-1 §6.2.3: seção externa tracionada. Os furos inativos são retidos nos cortes; os fatores EN e NBR permanecem separados.')
    doc.add_heading('Critérios governantes por família',level=1)
    doc.add_paragraph('Cada linha reúne somente a mesma família, critério, fonte e unidade. Apresenta o maior índice desse grupo; uma falha ou pendência tem prioridade e também consta integralmente na seção inicial. Critérios prescritivos conservam seu estado mesmo sem índice. Não se excluem contato ou graute quando o registro original não traz índice. A relação escalar exibida, quando necessária, usa apenas Sd/Rd já armazenados; não recalcula resistência.')
    groups=governing_groups(result);refs={}
    for g in groups:
        if g['reference'] and g['reference'] not in refs:refs[g['reference']]='R'+str(len(refs)+1)
    rows=[['ID e família','Critério e estado','Sd / Rd ou exigido / disponível','Índice e fonte']]
    for g in groups:
        c=g['selected'];rows.append([c['id']+' '+g['family'],g['criterion']+'\n'+c.get('state','pendente'),_v(c.get('demand'))+' / '+_v(c.get('resistance'))+' '+c.get('unit',''),_v(c.get('display_ratio'))+'\n'+refs.get(g['reference'],'Prescrição')])
    _add_table(doc,rows,(.32,.27,.28,.13))
    doc.add_paragraph('Sd e Rd pertencem ao mesmo critério. N/1 mm identifica força no trecho unitário da junta; N/mm identifica grandeza linear. Traço significa verificação prescritiva ou dado não escalar, não aprovação automática. Arredondamento é apenas de apresentação; os estados usam os resultados integrais armazenados.')
    doc.add_heading('Referências dos critérios',level=1)
    _add_table(doc,[['Fonte','Referência']]+[[code,reference_pt(ref)] for ref,code in refs.items()],(.10,.90))
    doc.add_heading('Rastreabilidade e arquivo completo',level=1)
    digest=hashlib.sha256(json.dumps(result,sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(',',':')).encode()).hexdigest()
    doc.add_paragraph(f"O resultado completo conserva {len(result.get('checks_flat',[]))} registros, inclusive repetições de consumidores; esse número não representa modos físicos independentes. O identificador C0001 corresponde ao item de índice zero da lista checks_flat do JSON de resultados, C0002 ao índice um, e assim sucessivamente. Os valores adicionais apresentados são lidos do mesmo componente original.")
    doc.add_paragraph('O anexo eletrônico opcional é obtido em Salvar resultados N/M/V JSON. Ele preserva todas as entradas, estados, verificações, fontes e limitações técnicas. O quadro resumido não altera esse arquivo. SHA-256 do conteúdo canônico dos resultados: '+digest+'.')
    doc.add_paragraph('Conclusão: '+('o escopo nominal delimitado atende aos critérios calculados.' if passed else 'o escopo nominal não está aprovado; conservar as falhas e pendências indicadas.')+' A comprovação documental de materiais, fabricação e execução e os projetos externos permanecem necessários.')
    stream=BytesIO();doc.save(stream);return stream.getvalue()
