"""Explicit synthetic regression specimen, not a change to any user's design.

Same topological model, practical fck20, plate45, rib20 and actual11mm throats.
A wider gauge140/bf190 maintains P398 flange restraint and washer toe clearance.
Compression is NOT relieved from rib foot welds: direct rib bearing stays False.
"""
from stiffened_base_kernels_candidate_20261017.complete_fixture import fixture

def positive_fixture(sign=1):
    p=fixture(sign*14e6)
    p['loads'].update(N_N=40000,M_Nmm=sign*14e6)
    p['geometry'].update(rib_thickness_mm=20,plate_thickness_mm=45,
        rib_top_profile_mm=[[0,400],[20,400],[186.4,100]],gauge_mm=140,column_flange_width_mm=190)
    p['connections'].update(rib_foot_throat_mm=11,rib_root_throat_mm=11,grout_fck_MPa=40)
    p['anchorage']['concrete_fck_MPa']=20
    for rod in p['anchorage']['rods']:rod['y']=70 if rod['y']>0 else -70
    return p
