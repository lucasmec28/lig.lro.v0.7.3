"""Read-only editorial views of stored results. No resistance calculation."""
from copy import deepcopy
import math
import re
from stiffened_base_kernels_candidate_20261017.user_report import _label
from .direct_labels import LABELS

STATE_LABELS={'normal_hole_equal':'Distribuição uniforme','leading_row':'Linha dianteira','opposite_row_envelope':'Envelope da linha oposta'}
VALUES={'conventional_grouted_ec3':'Contato direto convencional sobre graute', 'ASTM_supplementary':'Aplicação complementar ASTM',
 'astm_a36_supplementary_v1':'Protocolo complementar ASTM A36 e UNC', 'calculated_asme':'Área calculada pelo perfil ASME documentado',
 'UNC_2A':'UNC ASME B1.1 classe 2A','cut':'Cortada','rolled':'Laminada','unverified_cut':'Rosca cortada sem conformidade EN comprovada; redução 0,85',
 'normal_round':'Circular normal','supplementary_unc_bounded':'Limites dimensionais complementares UNC',
 'ordinary_bearing':'Contato com acomodação admitida','no_slip':'Sem deslizamento exigido','numeric_total_limit':'Limite total numérico exigido',
 'en_normal_nominal':'Furo normal nominal EN','en1090_verified':'Conformidade EN 1090 demonstrada','documented':'Área documentada',
 'unspecified':'Não informado','off':'Não selecionado','within_optional_app_scope':'Dentro do envelope opcional',
 'outside_optional_app_scope':'Fora do envelope opcional','pass':'Atende','fail':'Não atende','pending':'Pendente',
 'supplemental_qualified':'Aplicação complementar qualificada','astm_a36_supplemental':'ASTM A36 em aplicação complementar',
 'EN_structural':'Aço estrutural EN','EN_bolt':'Classe de parafuso EN','EN_rebar':'Armadura EN','metric':'Rosca métrica',
 'headed':'Com cabeça','cast_in':'Concretada no local','not_demanded':'Não solicitado','not_applicable':'Não aplicável'}
EXTRA_LABELS={'qualified_bearing_area':'Área de apoio qualificada (mm²)','actual_available_bearing_area':'Área física disponível de apoio (mm²)',
 'plate_fy_MPa':'fy da chapa (MPa)','plate_fu_MPa':'fu da chapa (MPa)','rib_fy_MPa':'fy da nervura (MPa)','rib_fu_MPa':'fu da nervura (MPa)',
 'column_fy_MPa':'fy do pilar (MPa)','column_fu_MPa':'fu do pilar (MPa)','rod_fy_MPa':'fy do chumbador (MPa)','rod_fu_MPa':'fu do chumbador (MPa)',
 'threads_per_inch':'Fios por polegada','no_free_standoff':'Sem afastamento livre vazios ou bainhas','plate_transfer_complete':'Registro documental da placa','plate_transfer_reference':'Referência documental da placa',
 'grout_fck_MPa':'Resistência do graute fck (MPa)','column_fabrication':'Fabricação do pilar','column_root_radius_mm':'Raio de concordância do pilar (mm)',
 'rib_foot_throat_mm':'Garganta da solda nervura à placa (mm)','rib_root_throat_mm':'Garganta da solda nervura ao pilar (mm)',
 'rib_fuw_MPa':'Resistência do metal de solda das nervuras (MPa)','column_base_fuw_MPa':'Resistência do metal de solda pilar à placa (MPa)',
 'column_direct_bearing':'Apoio direto do pilar','plate_monolithic':'Chapa monolítica','equivalent_two_rib_fillets':'Dois filetes equivalentes por nervura',
 'rib_compression_bearing':'Apoio direto da nervura comprimida','whole_rib_connected':'Contorno da nervura integralmente conectado',
 'intact_rib':'Nervura íntegra','short_edge_support_condition':'Condição das duas bordas curtas',
 'column_flange_lateral_length_mm':'Comprimento lateral da mesa do pilar (mm)','internal_throat_mm':'Garganta da ligação interna mesa à alma (mm)',
 'internal_fuw_MPa':'Resistência do metal da solda interna (MPa)','internal_continuous_two_faces':'Solda interna contínua nas duas faces',
 'internal_connected_height_mm':'Altura conectada internamente (mm)','bearing_area_mm2':'Área líquida de apoio da cabeça (mm²)',
 'bearing_area_ref':'Documento da área de apoio','qualified_bearing_area_mm2':'Área de apoio qualificada (mm²)',
 'actual_available_bearing_area_mm2':'Área física disponível de apoio (mm²)','effective_area_qualified':'Área efetiva qualificada',
 'detail_confirmed':'Detalhe confirmado','cast_in':'Concretada no local','normalweight':'Concreto de peso normal',
 'cracked':'Concreto fissurado','static':'Carregamento estático','intact_prism':'Prisma íntegro',
 'no_sleeves_or_voids':'Ausência de bainhas e vazios','splitting_detail_satisfied':'Detalhe contra fendilhamento atendido',
 'washer_width_mm':'Largura da arruela (mm)','washer_thickness_mm':'Espessura da arruela (mm)','washer_hole_mm':'Furo da arruela (mm)',
 'base_hole_mm':'Furo da placa (mm)','center_offset_x_mm':'Excentricidade da arruela em x (mm)','center_offset_y_mm':'Excentricidade da arruela em y (mm)',
 'washer_centered_on_rod':'Arruela centrada na haste','thread_class':'Classe de rosca','A36_equivalence_selected':'Aceite da prescrição axial DG1 para A36 sem equivalência EN'}
GROUPS={'geometry':'Geometria','materials':'Materiais','loads':'Ações','connections':'Ligações e apoios','anchorage':'Ancoragem',
 'washer':'Arruela e porca','models':'Modelos normais selecionados','direct_shear':'Contato direto e rastreabilidade','direct_detail':'Interface do cortante'}


def label(key):return EXTRA_LABELS.get(key,LABELS.get(key,_label(key)))

def text(value):
    if value is None:return 'Não informado'
    if isinstance(value,bool):return 'Sim' if value else 'Não'
    if isinstance(value,float):return f'{value:.8g}'
    if isinstance(value,(list,tuple)):return '['+'; '.join(text(x) for x in value)+']'
    if isinstance(value,dict):return '; '.join(label(k)+': '+text(v) for k,v in value.items())
    return VALUES.get(str(value),_label(str(value)))


def leaves(obj,path=()):
    if isinstance(obj,dict):
        for key,value in obj.items():yield from leaves(value,path+(str(key),))
    else:yield path,obj


def resolve(obj,path):
    for name,index in re.findall(r'([^.[\]]+)|\[(\d+)\]',path):obj=obj[int(index)] if index else obj[name]
    return obj


def family(ck):
    p=ck.get('component','');s=ck.get('label','')
    if p.startswith(('nm_components','NM')):
        if 'concrete_contact' in p:return 'Contato com o concreto'
        if '.grout' in p:return 'Resistência do graute'
        if '.sides[' in p:
            side='Nervura esquerda' if '.sides[0]' in p else 'Nervura direita'
            if 'adjacent_base_metal' in p:return side+' e metal base junto às soldas'
            if 'weld' in p:return side+' e soldas'
            if '.elastic.plate_flexure' in p:return side+' e flexão local da placa'
            if '.elastic.rib_local_normal' in p:return side+' e efeito local'
            if '.elastic.' in p:return side+' e tensões nas seções'
            return side+' e resistência selecionada'
        if 'central_plate' in p:return 'Faixas centrais da placa'
        if 'central_supports' in p:return 'Apoios das faixas centrais'
        if 'upper_washers' in p:return 'Arruelas e porcas em tração'
        return 'Componentes normais'
    if p.startswith('direct_anchor_shear'):
        if ck.get('unit')=='mm':return 'Prescrições geométricas dos furos EN'
        if 'Bearing' in s:return 'Pressão de contato nos furos da placa'
        if 'Interação' in s:return 'Interação tração e cortante EN'
        if 'Tração' in s:return 'Tração das hastes EN'
        if 'linha' in s:return 'Resistência da linha de hastes EN'
        return 'Cisalhamento reduzido das hastes EN'
    if p.startswith('aci_components'):
        ref=ck.get('reference','')
        if '.cone.' in p:return 'Cone de ruptura do concreto ACI'
        if '.headed.pullout' in p:return 'Arrancamento local da cabeça ACI'
        if '17.6.1' in ref:return 'Aço das hastes em tração ACI'
        if '17.7.1' in ref:return 'Aço das hastes em cortante ACI'
        if '17.7.2' in ref:return 'Ruptura do concreto por cortante ACI'
        if '17.7.3' in ref:return 'Arrancamento por alavanca ACI'
        if '17.6.2' in ref:return 'Cone de ruptura do concreto ACI'
        if '17.6.3' in ref:return 'Arrancamento local da cabeça ACI'
        if 'Interação' in ref:return 'Interação tração e cortante ACI'
        return 'Resistência documentada da cabeça'
    if p.startswith('web_transfer'):
        if '.receiver.' in p:return 'Pilar receptor e painel de alma'
        if '.internal_transfer.' in p:return 'Ligação interna mesa à alma'
        if 'elastic' in s:return 'Introdução local e tensões combinadas'
        if any(x in s for x in ('minimum','available','material_matching')):return 'Prescrições da solda da alma à placa'
        return 'Ligação da alma à placa'
    if p.startswith('nbr_rod_tension'):return 'Tração das hastes NBR'
    if p.startswith('plate_transfer_scope'):
        if 'Banda' in s:return 'Bandas laterais da placa'
        if 'Bloco lateral' in s:return 'Blocos laterais e prefixos da placa'
        if 'dupla' in s:return 'Bloco da dupla externa'
        return 'Seção externa tracionada da placa'
    return 'Demais critérios calculados'


def criterion(ck):
    p=ck.get('component','');s=ck.get('label','')
    combined=p+' '+s
    if p.startswith('direct_anchor_shear') and ck.get('unit')=='mm':return s
    for token,name in [('minimum_leg','Perna mínima'),('minimum_length','Comprimento mínimo'),('available_shelf','Espaço físico disponível'),('material_matching','Compatibilidade do metal de solda'),('prescription_satisfied','Prescrição axial da arruela'),('rod_check','Tração axial'),('gross_yield','Escoamento bruto'),('net_rupture','Ruptura líquida'),('local_DG1','Escoamento local'),('shear_yield','Escoamento por cortante'),('shear_rupture','Ruptura por cortante'),('normal_pass','Tensão normal'),('shear_pass','Tensão de cisalhamento'),('web_local_yield','Escoamento local da alma'),('flange_local_flexure','Flexão local da mesa'),('web_crippling','Enrugamento da alma'),('opposed_compression','Compressões opostas'),('.panel','Painel de alma'),('full_strength_weld','Solda para resistência integral')]:
        if token in combined:return name
    if 'gross' in s:return 'Seção bruta'
    if 'net' in s:return 'Seção líquida'
    if 'Bloco lateral' in s:return 'Bloco e prefixos'
    if 'Bloco da dupla' in s:return 'Bloco da dupla'
    if 'minimum_effective_length' in s:return 'Comprimento efetivo mínimo'
    if 'plate_flexure' in p:return 'Flexão da placa'
    if 'weld' in combined:return 'Metal de solda'
    if '.selected_resistance' in p:return 'Resistência e estabilidade selecionada'
    if '.elastic.' in p:return 'Tensão normal'
    if 'elastic' in s:return 'Tensão combinada'
    if 'weld' in combined:return 'Metal de solda'
    if 'central_plate' in p:return 'Flexão da faixa'
    if 'central_supports' in p:return 'Apoio físico da faixa'
    return ck['family']


def reference_pt(ref):
    replacements={'no confinement credit':'sem crédito de confinamento','normal combinations':'combinações normais',
     'Table 9 and notes d/i':'Tabela 9 e notas d/i','source PDF':'PDF da fonte','direct compression bearing; physical support section stress':'apoio direto em compressão na seção física',
     'Explicit illustrative supplied design capacity, not derived by this fixture':'Resistência ilustrativa fornecida, não calculada neste exemplo',
     'physical two-sided web-foot joint':'ligação física da alma à placa em duas faces','physical two-sided web-foot T joint':'ligação física em T em duas faces','Table9/Table11':'Tabelas 9 e 11',
     'supplementary elastic screen':'verificação elástica complementar','explicitly selected':'adotado explicitamente',
     'zero loaded length/end':'comprimento carregado nulo e posição de extremidade','end reduction':'redução de extremidade',
     'point/end bound':'limite pontual na extremidade','algebraic field and concurrent axial envelope':'campo algébrico e envelope axial concomitante',
     'same-elevation opposing compression':'compressões opostas na mesma cota',
     'actual side-band gross/net cut':'cortes bruto e líquido das bandas reais', 'conservative c=0.5':'coeficiente conservador c=0,5',
     'actual external tension cut':'corte real da seção externa tracionada','gamma_M0':'γM0','gamma_M2,plate':'γM2 da placa','gamma_M2':'γM2',
     'gammaM0':'γM0','3rd':'3ª edição','Table4-3':'Tabela 4-3','Table2-2':'Tabela 2-2','Eq4-21 to4-23':'Equações 4-21 a 4-23',
     'one-way transverse strips':'faixas transversais unidirecionais','matching chi curve':'curva χ correspondente','gamma_a1':'γa1','Table 3.4':'Tabela 3.4','Step6C':'Etapa 6C','Eqs2.17/2.18':'Equações 2.17 e 2.18','long-rib shortcut':'simplificação para nervura longa','Eq1.23':'Equação 1.23','Errata 1:2025':'Errata 1:2025','Table9':'Tabela 9','pp.':'p.','pp55-56':'p. 55–56','pp36–37':'p. 36–37'}
    for a,b in replacements.items():ref=ref.replace(a,b)
    return ref


def display_checks(result):
    rows=[]
    for i,original in enumerate(result.get('checks_flat',[])):
        ck=deepcopy(original);ck['id']=f'C{i+1:04d}';ck['index']=i;ck['family']=family(ck)
        try:
            node=resolve(result,ck['component'])
            if not isinstance(node,dict):node=resolve(result,ck['component'].rsplit('.',1)[0])
        except (KeyError,IndexError,TypeError):node={}
        if 'utilization_M' in node:
            ck['ratio']=node['utilization_M'];ck['resistance']=node.get('capacity',{}).get('M_design_Nmm');ck['unit']='N·mm'
        if '.central_supports.' in ck['component']:
            ck['demand']=node.get('bearing_stress_MPa');ck['resistance']=node.get('bearing_resistance_MPa');ck['unit']='MPa'
        if ck['component'].endswith('.shear_pass') and '.central_plate.' in ck['component']:
            ck['demand']=node.get('shear_stress_MPa');ck['resistance']=node.get('shear_resistance_MPa');ck['unit']='MPa'
        for target,candidates in [('demand',('demand_N_mm','plate_yield_N_mm','M_about_O_Nmm','demand_N','T_N')),
                                  ('resistance',('resistance_N_mm','two_face_resistance_N_mm','M_design_Nmm','resistance_N'))]:
            if ck.get(target) is None:
                for key in candidates:
                    if isinstance(node.get(key),(float,int)) and not isinstance(node[key],bool):ck[target]=node[key];break
        if not ck.get('unit'):
            if any(k in node for k in ('demand_N_mm','two_face_resistance_N_mm')):ck['unit']='N/mm'
            elif 'M_design_Nmm' in node:ck['unit']='N·mm'
            elif ck['family']=='Resistência do graute':ck['unit']='MPa'
            elif ck.get('demand') is not None and ck.get('resistance') is not None:ck['unit']='N'
        if not ck.get('reference'):
            ck['reference']=node.get('resistance_source',node.get('source_resistance',node.get('source_model',node.get('source',node.get('reference','')))))
        if not ck.get('reference'):
            path=ck['component']
            while '.' in path:
                path=path.rsplit('.',1)[0]
                try:ancestor=resolve(result,path)
                except (KeyError,IndexError,TypeError):continue
                if isinstance(ancestor,dict):
                    for key in ('source_resistance','resistance_source','source','source_model','reference'):
                        if isinstance(ancestor.get(key),str) and ancestor[key]:ck['reference']=ancestor[key];break
                if ck.get('reference'):break
        # Index is only a display aid for stored scalar Sd/Rd, never a new check.
        if ck.get('ratio') is None and type(ck.get('demand')) in (int,float) and type(ck.get('resistance')) in (int,float) and ck['resistance']>0:
            ck['display_ratio']=ck['demand']/ck['resistance']
        else:ck['display_ratio']=ck.get('ratio')
        ck['criterion']=criterion(ck)
        rows.append(ck)
    return rows


def governing_groups(result):
    groups={}
    for ck in display_checks(result):groups.setdefault((ck['family'],ck['criterion'],ck.get('reference',''),ck.get('unit','')),[]).append(ck)
    out=[]
    for (name,mode,ref,unit),rows in groups.items():
        # Pending/failing states cannot be hidden by a favourable higher scalar.
        rank=lambda x:(x.get('state')!='atende',float(x['display_ratio']) if type(x.get('display_ratio')) in (int,float) and math.isfinite(x['display_ratio']) else -1.)
        selected=max(rows,key=rank)
        out.append({'family':name,'criterion':mode,'reference':ref,'unit':unit,'count':len(rows),'selected':selected,
                    'members':[x['id'] for x in rows],'nonpassing':[x for x in rows if x.get('state')!='atende']})
    return out
