"""Separate N/M/V direct-bearing review screen; the earlier N/M route is unchanged."""
import json
from copy import deepcopy
import streamlit as st
from .direct_controller import TEMPLATE,leaves,parse_fields,validate_document,document,fingerprint,calculate,direct_example
from .controller import ENUMS as NM_ENUMS
from .ui import GROUPS as NM_GROUPS,display_label as normal_label

PREFIX='sbv.'
GROUPS={**NM_GROUPS,'direct_shear':'8 · Contato direto, material e ELS',
        'direct_detail':'9 · Interface do cortante e dados reais'}
from .direct_labels import LABELS
DIRECT_ENUMS={
    'model':['off','conventional_grouted_ec3'],
    'material_basis':['unspecified','EN_structural','EN_bolt','EN_rebar','ASTM_supplementary'],
    'material_protocol':['','astm_a36_supplementary_v1'],
    'thread_standard':['metric','UNC_2A'],'thread_area_source':['documented','calculated_asme'],
    'thread_manufacture':['unspecified','cut','rolled'],'thread_compliance':['unspecified','en1090_verified','unverified_cut'],
    'hole_kind':['unspecified','normal_round'],'hole_basis':['en_normal_nominal','supplementary_unc_bounded'],
    'service_slip_requirement':['ordinary_bearing','no_slip','numeric_total_limit']}
ENUM_LABELS={'off':'Não selecionado','conventional_grouted_ec3':'Convencional sobre graute · EN complementar',
    'unspecified':'Não identificado','ASTM_supplementary':'ASTM A36/UNC · aplicação complementar',
    'EN_structural':'Aço estrutural de norma EN elegível','EN_bolt':'Classe de parafuso de norma EN elegível','EN_rebar':'Armadura de norma EN elegível',
    'metric':'Métrica','UNC_2A':'UNC ASME B1.1 · Class 2A','cut':'Cortada','rolled':'Laminada',
    'documented':'Área documentada','calculated_asme':'Área de projeto ASME para perfil documentado',
    'en1090_verified':'Conformidade EN1090 demonstrada','unverified_cut':'Rosca cortada documentada · kthread=0,85',
    'normal_round':'Circular normal / limitada complementar','en_normal_nominal':'Furo normal nominal EN',
    'supplementary_unc_bounded':'UNC · limites dimensionais complementares','ordinary_bearing':'Bearing ordinário, acomodação permitida',
    'no_slip':'Sem deslizamento · fora do ramo','numeric_total_limit':'Limite total numérico · ELS próprio necessário',
    'astm_a36_supplementary_v1':'Protocolo complementar ASTM A36/UNC v1'}


def load_inputs(data=None):
    for path,template in leaves(TEMPLATE):
        key=PREFIX+'.'.join(path)
        if data is None:st.session_state[key]=''
        else:
            value=data
            for part in path:value=value[part]
            st.session_state[key]=('Sim' if value else 'Não') if isinstance(value,bool) else json.dumps(value,ensure_ascii=False) if isinstance(value,(list,tuple)) else str(value)
    for key in ('result','signature'):st.session_state.pop(PREFIX+key,None)


def render():
    st.header('Base nervurada · N + M + V · contato direto')
    st.caption('Rota de revisão separada. Mantém todas as entradas originais; não modifica a rota N/M anterior.')
    st.caption('Composição nominal P398/P207 delimitada: N/M mantém os componentes reais das nervuras; V integral na alma. '
               'O ramo opcional exige placa basal robusta pelos padrões reais P398, além dos consumidores de V próprios. '
               'Não é exigência normativa geral nem prova T⇒V; fundação e rigidez global permanecem externas.')
    st.info('Sem atrito, chave ou resistência lateral da arruela. EN γM2=1,25, NBR γa2=1,35 e ACI φ são bases independentes. '
            'Estados de contato são alternativas com V integral, nunca somados. d0−d não é deslocamento total calculado.')
    a,b=st.columns(2)
    a.button('Novo projeto N/M/V · limpar campos',on_click=load_inputs,key=PREFIX+'reset')
    b.button('Carregar exemplo de estudo N/M/V',on_click=lambda:load_inputs(direct_example()),key=PREFIX+'example',
             help='Preenchimento explícito de exemplo ilustrativo. Não representa obra, certificado real ou solução aprovada.')
    with st.expander('Importar / reimportar projeto N/M/V JSON'):
        upload=st.file_uploader('Arquivo N/M/V',type=['json'],key=PREFIX+'upload')
        text=st.text_area('Ou cole o JSON N/M/V',key=PREFIX+'import_text')
        if st.button('Aplicar importação N/M/V',key=PREFIX+'import'):
            try:
                raw=upload.getvalue().decode('utf-8') if upload else text
                data=validate_document(json.loads(raw))
                load_inputs(data);st.success('Projeto importado. Resultado anterior invalidado.');st.rerun()
            except (ValueError,TypeError,KeyError,UnicodeError) as exc:st.error('Importação recusada sem alterar o projeto: '+str(exc))
    fields={}
    for group,title in GROUPS.items():
        if group not in TEMPLATE:continue
        with st.expander(title,expanded=group in ('loads','direct_shear')):
            if group=='direct_shear':
                st.caption('Material, diâmetro, rosca e furo não são convertidos. A36 legado sem documentação e aceite permanece estudo. '
                           'Para UNC: 3/4–10, 7/8–9, 1–8, 1 1/8–7 e 1 1/4–7; não arredondar para métricos. '
                           'Furo exige 0<d0−d≤2 mm para d≤24 mm e ≤3 mm acima. O aceite não substitui os documentos.')
            for path,template in leaves({group:TEMPLATE[group]}):
                leaf=path[-1];key=PREFIX+'.'.join(path);label=LABELS.get(leaf,normal_label(leaf))
                if len(path)>2:label=' / '.join(path[1:-1])+' · '+label
                if group=='direct_shear' and leaf in ('plate_transfer_complete','plate_transfer_reference'):
                    value=st.session_state.get(key,'Não' if isinstance(template,bool) else '')
                    st.session_state[key]=value
                elif isinstance(template,bool):value=st.selectbox(label,['','Sim','Não'],key=key)
                elif leaf in (DIRECT_ENUMS if group=='direct_shear' else NM_ENUMS):
                    options=list(dict.fromkeys(['']+(DIRECT_ENUMS if group=='direct_shear' else NM_ENUMS)[leaf]))
                    old=st.session_state.get(key)
                    if old is not None and old not in options:options.append(old)
                    value=st.selectbox(label,options,key=key,format_func=lambda x:ENUM_LABELS.get(x,x))
                elif isinstance(template,(list,tuple)):
                    value=st.text_area(label,key=key,height=90,help='Lista JSON real. O programa não altera as coordenadas ou dimensões.')
                else:value=st.text_input(label,key=key)
                fields['.'.join(path)]=value
            if group=='washer':st.caption('Arruela superior apenas axial. Seu modelo e geometria não concedem capacidade lateral ao contato direto.')
            if group=='direct_detail':st.caption('A referência de aplicação deve confirmar N/M/V no topo da placa. Não se soma V·e novamente ou zera V físico para aprovar o conjunto.')
    inputs,errors=parse_fields(fields)
    svg=None
    if not errors:
        from .drawing import geometry_svg
        try:
            cached=st.session_state.get(PREFIX+'result') if st.session_state.get(PREFIX+'signature')==fingerprint(inputs) else None
            svg=geometry_svg(inputs,(cached or {}).get('nm_components'))
            st.image(svg,width='stretch')
            st.caption('Geometria original da placa, hastes, nervuras e detalhe axial. O furo do detalhe axial e d0 direto são conservados separadamente; divergências não são ajustadas pelo desenho.')
            st.download_button('Salvar geometria N/M/V SVG',svg,'geometria_base_nmv_direta.svg','image/svg+xml',key=PREFIX+'svg')
        except (ValueError,KeyError,TypeError,IndexError):st.warning('Geometria ainda não desenhável; entradas e resultados parciais continuam disponíveis.')
        st.download_button('Salvar entradas N/M/V JSON',document(inputs),'base_nervurada_nmv_direta.json','application/json',key=PREFIX+'save')
    if st.button('Calcular componentes N/M/V',type='primary',key=PREFIX+'calculate'):
        if errors:st.error('Corrija os campos indicados; nenhum valor será substituído.');st.write(errors)
        else:
            st.session_state[PREFIX+'result']=calculate(inputs)
            st.session_state[PREFIX+'signature']=fingerprint(inputs)
            st.rerun()
    result=st.session_state.get(PREFIX+'result')
    if result is None:return
    if errors or st.session_state.get(PREFIX+'signature')!=fingerprint(inputs):
        st.warning('Entradas alteradas. Recalcule antes de visualizar ou exportar resultados N/M/V.');return
    st.subheader(result.get('conclusion_label','Resultado parcial, conjunto N/M/V não aprovado'))
    if result.get('selected_route_resistance_pass'):
        st.success('Escopo nominal delimitado N/M/V atende aos componentes calculados. Não aprova fundação, solo ou estabilidade global.')
    elif result.get('calculation_coverage_complete'):
        st.error('Cobertura nominal completa neste domínio, com critério resistente não atendido; consulte as falhas.')
    else:st.warning('Cobertura incompleta: consulte as pendências reais. Não é aprovação do conjunto.')
    for note in result.get('missing',[]):st.warning(str(note))
    for key,title in [('direct_anchor_shear','Haste e bearing da placa'),('aci_components','Ancoragem ACI'),('web_transfer','Transferência real de V à alma'),('plate_transfer_scope','Placa externa e envelope nominal')]:
        with st.expander(title):
            obj=result.get(key,{})
            domain=obj.get('domain',{})
            default=domain.get('status','consultar escopos') if isinstance(domain,dict) else 'domínio elegível' if domain else 'domínio pendente'
            st.write('Estado: '+str(obj.get('status',default)))
            if key=='direct_anchor_shear':
                for scope in ('domain','steel_plate_uls','service_scope','plate_transfer_scope','local_transfer_scope','foundation_scope'):
                    if scope in obj:st.write(scope+': '+str(obj[scope].get('status','pendente')))
                st.caption('δtotal não calculado. Folga diametral não limita deslocamento total. Estados alternativos, sem soma de forças ou capacidades.')
            st.json(obj)
    rows=[{'Componente':ck.get('component',''),'Estado':ck.get('state',''),'Índice':ck.get('ratio'),
           'Sd':ck.get('demand'),'Rd':ck.get('resistance'),'Referência':ck.get('reference','')} for ck in result.get('checks_flat',[])]
    st.subheader('Verificações calculadas, inclusive falhas')
    if rows:st.dataframe(rows,hide_index=True,width='stretch')
    with st.expander('Componentes normais N/M · projeção V=0 somente neste pacote'):
        st.caption('Os resultados desta subseção não validam V ou a composição N/M/V. Ações físicas originais permanecem preservadas.')
        st.json(result.get('nm_components',{}))
    st.download_button('Salvar resultados N/M/V JSON',json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False),
        'resultados_base_nmv_direta.json','application/json',key=PREFIX+'result_json')
    from .direct_docx_report import export_user_docx
    from .drawing import geometry_png
    png=None
    if svg is not None:
        try:png=geometry_png(inputs,result.get('nm_components'))
        except (ValueError,KeyError,TypeError,IndexError):pass
    try:
        raw=export_user_docx(inputs,result,png_bytes=png)
        st.download_button('Exportar memória N/M/V Word',raw,'memoria_base_nmv_direta.docx',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',key=PREFIX+'mc_word')
    except (ValueError,TypeError,KeyError) as exc:st.warning('Memória Word indisponível: '+str(exc))
