"""Independent acceptance checks, with no pytest dependency.

Run: python independent_regressions.py --source /path/to/extracted/source
The fixtures intentionally originate in v0.7.3. Passing software checks does not
constitute an independent structural validation or authorize excluded methods.
"""
import argparse
from copy import deepcopy
from dataclasses import asdict, fields, replace
from io import BytesIO
import json
import math
from pathlib import Path
import sys
import unittest
from zipfile import ZipFile
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent.parent
parser = argparse.ArgumentParser()
parser.add_argument('--source', type=Path, required=True)
args, remaining = parser.parse_known_args()
sys.path.insert(0, str(args.source.resolve()))
from lro import engine, end_plate, double_cover
from lro.models import Connection, Check, VERSION
from lro.examples import presets as single_presets
from lro.end_plate import EndPlate
from lro.double_cover import DoubleCoverConnection
from lro.report import create_report as single_report
from lro.end_plate_report import create_report as ep_report
from lro.double_cover_report import create_report as double_report

EP = list(end_plate.presets().values())
PIN = next(c for c in EP if c.kind == 'pinned')
MOM = next(c for c in EP if c.kind == 'moment' and c.layout == 'both')
SINGLES = list(single_presets().values())
WEB = next(c for c in SINGLES if c.kind == 'beam_web' and c.cope == 'none')
COLUMN = next(c for c in SINGLES if c.kind == 'column_flange' and c.support.family == 'CS')
DOUBLE = next(iter(double_cover.presets().values()))
FAMILIES = [('single_web', WEB, engine.evaluate, single_report),
            ('single_column', COLUMN, engine.evaluate, single_report),
            ('double_cover', DOUBLE, double_cover.evaluate, double_report),
            ('end_plate_pinned', PIN, end_plate.evaluate, ep_report),
            ('end_plate_moment', MOM, end_plate.evaluate, ep_report)]


def exact_approval(result):
    return result.status == 'ATENDE ÀS VERIFICAÇÕES REALIZADAS'


def report_text(raw):
    with ZipFile(BytesIO(raw)) as z:
        root = ET.fromstring(z.read('word/document.xml'))
    return ' '.join(node.text or '' for node in root.iter() if node.tag.endswith('}t'))


def real_project():
    return EndPlate.from_dict(json.loads((HERE/'fixtures/W200_original_v073.json').read_text()))


class IndependentAcceptance(unittest.TestCase):
    def test_old_w200_roundtrip_preserves_every_entered_value(self):
        original = json.loads((HERE/'fixtures/W200_original_v073.json').read_text())['connection']
        c = real_project()
        reopened = EndPlate.from_dict(json.loads(json.dumps(c.to_dict(), allow_nan=False)))
        for key, value in original.items():
            with self.subTest(key=key):
                self.assertEqual(asdict(reopened)[key], value)
        self.assertEqual(reopened, c)

    def test_w200_computes_with_traceable_nonapproving_range_warning(self):
        r = end_plate.evaluate(real_project())
        self.assertTrue(r.checks, 'W200 must expose numerical checks, not be blocked by test-range limits')
        self.assertFalse(exact_approval(r), 'Out-of-tested-range must not silently become unconditional approval')
        self.assertTrue(any('207' in i.text and ('DG39' in i.reference or 'Design Guide 39' in i.reference) for i in r.issues))
        self.assertTrue(any('8.4' in i.text or '8,4' in i.text for i in r.issues))
        self.assertFalse(any(i.severity == 'error' for i in r.issues), 'Range deviation is not physically invalid geometry')
        for x in r.checks:
            with self.subTest(check=x.id):
                self.assertTrue(math.isfinite(x.demand))
                self.assertTrue(math.isfinite(x.resistance))
                self.assertGreater(x.resistance, 0)

    def test_w200_warning_survives_recalculation_json_and_word(self):
        c = replace(real_project(), notes='AUDIT: observação com acentuação, 10 mm e N positivo.')
        for c in [c, EndPlate.from_dict(json.loads(json.dumps(c.to_dict()))), replace(c, V=c.V*1.05)]:
            with self.subTest(V=c.V):
                r = end_plate.evaluate(c)
                self.assertTrue(r.checks)
                text = report_text(ep_report(c, r, False))
                self.assertIn(c.notes, text)
                self.assertIn(r.status, text)
                for issue in r.issues:
                    if '207' in issue.text or '8.4' in issue.text or '8,4' in issue.text:
                        self.assertIn(issue.text, text)

    def test_five_families_calculate_and_roundtrip(self):
        for label, c, evaluate, report in FAMILIES:
            with self.subTest(family=label):
                reopened = type(c).from_dict(json.loads(json.dumps(c.to_dict(), allow_nan=False)))
                self.assertEqual(c, reopened)
                r = evaluate(reopened)
                self.assertTrue(r.checks)
                self.assertFalse(any(i.severity == 'error' for i in r.issues))
                self.assertTrue(all(math.isfinite(x.demand) and math.isfinite(x.resistance) for x in r.checks))
                self.assertEqual([x.id for x in r.checks], [x.id for x in evaluate(c).checks])

    def test_noncompliant_maximum_spacing_is_calculable_but_not_approved(self):
        variants = [('single_web', replace(WEB,n=2,pitch=160.,plate_top=60.), engine.evaluate, single_report),
                    ('single_column', replace(COLUMN,n=2,pitch=170.,plate_top=70.), engine.evaluate, single_report),
                    ('double_cover', replace(DOUBLE,n=2,pitch=160.), double_cover.evaluate, double_report),
                    ('moment', replace(MOM,pfi=30.), end_plate.evaluate, ep_report)]
        for label, c, evaluate, report in variants:
            with self.subTest(family=label):
                r=evaluate(c)
                self.assertTrue(r.checks, 'A spacing noncompliance should not hide all numerical checks')
                self.assertFalse(exact_approval(r))
                self.assertTrue(any('6.3.10' in i.reference for i in r.issues))
                text=report_text(report(c,r))
                self.assertIn(r.status,text)
                for i in r.issues:
                    if '6.3.10' in i.reference:self.assertIn(i.text,text)

    def test_physically_overlapping_holes_never_approve(self):
        for label,c,evaluate,_ in FAMILIES:
            changes={'gauge':1.} if isinstance(c,EndPlate) else {'pitch':1.}
            with self.subTest(family=label):
                r=evaluate(replace(c,**changes))
                self.assertFalse(exact_approval(r))
                self.assertTrue(any(i.severity=='error' for i in r.issues))

    def test_invalid_dimensions_nan_and_zero_rows_do_not_approve(self):
        for label,c,evaluate,_ in FAMILIES:
            for key,value in [('db',0),('n',0),('V',float('nan')),('V',float('inf'))]:
                with self.subTest(family=label,key=key,value=value):
                    r=evaluate(replace(c,**{key:value}))
                    self.assertFalse(exact_approval(r))
                    self.assertFalse(r.checks)

    def test_malformed_json_dimensions_are_rejected_not_coerced(self):
        for label,c,evaluate,_ in FAMILIES:
            for key,value in [('db','19.05'),('n',False),('V',None),('threads','true')]:
                with self.subTest(family=label,key=key):
                    data=deepcopy(c.to_dict());data['connection'][key]=value
                    try:
                        candidate=type(c).from_dict(data)
                        result=evaluate(candidate)
                    except (TypeError,ValueError,KeyError,AttributeError):
                        continue # UI import handlers already catch these rejection classes.
                    self.assertFalse(exact_approval(result))
                    self.assertFalse(result.checks)

    def test_both_extensions_preserve_moment_sign_symmetry(self):
        a=end_plate.evaluate(MOM);b=end_plate.evaluate(replace(MOM,M=-MOM.M))
        self.assertEqual([x.id for x in a.checks],[x.id for x in b.checks])
        for x,y in zip(a.checks,b.checks):self.assertAlmostEqual(x.ratio,y.ratio,places=10)

    def test_above_only_reverse_moment_does_not_approve(self):
        r=end_plate.evaluate(replace(MOM,layout='top',M=-abs(MOM.M)))
        self.assertFalse(exact_approval(r))
        self.assertFalse(r.checks, 'Top-only reversed tension has no implemented 4E arrangement')

    def test_pinned_external_moment_does_not_disappear(self):
        c=replace(PIN,M=10000)
        reopened=EndPlate.from_dict(json.loads(json.dumps(c.to_dict())))
        self.assertEqual(reopened.M,10000)
        r=end_plate.evaluate(reopened)
        self.assertFalse(exact_approval(r));self.assertFalse(r.checks)

    def test_axial_dominance_and_minimum_force_never_approve(self):
        for c in [replace(MOM,N=300000),replace(MOM,N=1000,V=0,M=1000000)]:
            with self.subTest(N=c.N,M=c.M):
                r=end_plate.evaluate(c)
                self.assertFalse(exact_approval(r))
                self.assertTrue(any('axial' in i.text.lower() or 'momento dominante' in i.text.lower() for i in r.issues))

    def test_single_plate_unsupported_compression_is_not_recast_as_tension(self):
        for c in [WEB,COLUMN]:
            r=engine.evaluate(replace(c,N=-1000))
            self.assertFalse(exact_approval(r));self.assertFalse(r.checks)

    def test_disabled_minimum_force_never_has_unconditional_approval(self):
        for label,c,evaluate,_ in FAMILIES:
            with self.subTest(family=label):
                r=evaluate(replace(c,norm_minimum=False))
                self.assertTrue(r.checks)
                self.assertFalse(exact_approval(r))
                self.assertTrue(any('45 kN' in i.text or 'mínima' in i.text for i in r.issues))

    def test_declared_exclusions_are_not_fabricated_as_passed_checks(self):
        web=engine.evaluate(WEB)
        self.assertTrue(any('fora do plano' in i.text for i in web.issues))
        self.assertFalse(any('interação fora do plano' in x.name.lower() for x in web.checks))
        dc=double_cover.evaluate(DOUBLE)
        self.assertTrue(any('rotação' in i.text and 'não' in i.text for i in dc.issues))
        self.assertFalse(any(x.id=='dc_brace' for x in dc.checks))

    def test_detailing_only_stiffener_and_complement_add_no_strength(self):
        a=engine.evaluate(WEB)
        for c in [replace(WEB,opposite_stiffener=True),replace(WEB,plate_shape='between_flanges')]:
            r=engine.evaluate(c)
            self.assertTrue(r.checks)
            self.assertEqual([(x.id,x.demand,x.resistance) for x in a.checks],[(x.id,x.demand,x.resistance) for x in r.checks])

    def test_nonfinite_check_resistance_is_never_a_pass(self):
        # An infinite calculated capacity is invalid, not infinite real resistance.
        for value in [float('inf'),float('nan')]:
            c=Check('audit','Audit',1.,value,'N','','','','')
            self.assertFalse(c.passed)

    def test_observations_and_input_actions_survive_all_word_reports(self):
        for label,c,evaluate,report in FAMILIES:
            with self.subTest(family=label):
                c=replace(c,notes='AUDIT: esforço já majorado; fabricação deve conferir as cotas.')
                r=evaluate(c)
                text=report_text(report(c,r,False))
                self.assertIn(c.notes,text)
                self.assertIn(r.status,text)
                self.assertIn('Premissas adotadas',text)
                heading = 'Memória de cálculo' if 'Memória de cálculo' in text else 'Equações e substituições'
                self.assertIn(heading,text)
                self.assertGreater(text.index('Premissas adotadas'),text.index(heading))

if __name__=='__main__':
    print('Independent acceptance checks for LRO',VERSION, 'source:',args.source.resolve(),flush=True)
    unittest.main(argv=[sys.argv[0],*remaining],verbosity=2)
