# LRO Ligações 0.9.73

Mantenha app.py, codigo_lro.zip, requirements.txt e README.md juntos. Instale as dependências de requirements.txt e execute `streamlit run app.py`.

Inclui a nova família completa de emenda de perfis W/I iguais por talas soldadas, no domínio estático explicitamente indicado: N/M nas mesas e V/2 em cada tala de alma. Para cada tala de mesa comprimida, informe o comprimento efetivo Le normal ao plano da tala (deslocamento y, flexão em torno de z) e no plano da tala (deslocamento z, flexão em torno de y), com fonte e condições de apoio. Le já inclui os efeitos dos vínculos. Não há entrada de Lb da alma para esta rota sem flexão nas talas de alma.

O dimensionamento e a estabilidade global dos membros continuam como pré-requisitos externos. As confirmações do projetista e todos os limites de aplicação devem corresponder ao projeto real.

Inclui proteções de geometria e exportação: resultados, desenhos e memoriais devem corresponder às entradas atuais. Esta candidata acrescenta componentes resistentes de base nervurada e contato direto placa–chumbador em domínios delimitados. Não inclui base tubular. Consulte docs/DIRECT_ANCHOR_CANDIDATE.md para seleção, conclusão por família, envelope opcional, pendências e limites; não é aprovação integral da fundação.

A identidade do aplicativo é 0.9.73. Identificadores internos antigos de esquema/componente são preservados para compatibilidade, não representam a versão do pacote.
