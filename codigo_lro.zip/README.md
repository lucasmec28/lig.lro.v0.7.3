# LRO Ligações 0.8.0

Cálculo local e detalhamento de ligações de aço com Streamlit, projetos JSON, desenhos proporcionais e memória Word com equações editáveis.

Desenvolvido por LRO Soluções de engenharia LTDA.

## Publicação

A distribuição pronta para GitHub contém quatro arquivos na raiz: `app.py`, `codigo_lro.zip`, `requirements.txt` e `README.md`. Envie os quatro juntos e mantenha `codigo_lro.zip` compactado. No Streamlit, use `app.py` e Python 3.12. Ao atualizar, substitua os quatro arquivos e reinicie o app.

Este README interno acompanha o código-fonte contido em `codigo_lro.zip`. Para desenvolvimento, extraia uma cópia separada e execute:

```bash
python -m pip install -r requirements-dev.txt
python -m pytest -q tests
python -m streamlit run app.py
```

## Ligações

- Single plate na alma da viga de apoio ou na mesa da coluna, com V e N de tração.
- Duas talas na alma da coluna, com V e N com sinal.
- End plate rotulada na mesa da coluna, com V e N com sinal.
- End plate engastada na mesa da coluna, com M, V e N, extensão acima e abaixo ou somente acima.

Esforços já de cálculo. Entradas em kgf e kgf·m na tela; dimensões em mm. Modelo plano, sem carregamento no eixo de menor inércia. Premissas e exclusões acompanham a tela e o final do Word.

## Melhorias incluídas desde a 0.7.4

Limites empíricos do método passam a avisos quando é possível executar as equações. A W200 pode seguir no modelo 4E com ressalva explícita de extrapolação. Espaçamento máximo e bordas máximas não atendidos deixam o resultado como **NÃO ATENDE AO DETALHAMENTO**, mas permitem calcular e exportar.

Novo campo **Linhas intermediárias entre as mesas** na end plate engastada: adiciona pares de parafusos no detalhe, considera todos os furos nos ligamentos e blocos, sem crédito resistente nem redistribuição das forças do grupo base 4E. O arranjo ampliado permanece com ressalva e exige avaliação específica para confirmar resistência e rigidez.

As cinco ligações foram auditadas; os critérios de resistência permanecem visíveis e as entradas não são corrigidas automaticamente. Veja `docs/AJUSTES_V074.md` para alcance, exemplos e bloqueios mantidos. Documentos de versões anteriores são históricos e devem ser lidos junto desta revisão.

Os exemplos W200 e W410 com linha intermediária são estudos com ressalvas; não são detalhes aprovados para execução. O exemplo W410 é uma reconstrução a partir do print, mantendo as demais entradas do JSON W200.

O pacote inclui o catálogo de perfis, módulos, exemplos, testes e documentos necessários, sem depender de instalações anteriores. `python verificar_pacote.py` verifica a integridade dos arquivos da distribuição original.


## Correções da 0.7.5

A navegação entre famílias mantém o projeto em edição; rotulada e engastada conservam rascunhos independentes. Valores numéricos não finitos nunca produzem uma verificação favorável. Os modelos estruturais da 0.7.4 foram preservados, inclusive as ressalvas da W200 e as linhas intermediárias sem crédito resistente. Veja `docs/AJUSTES_V075.md` dentro de `codigo_lro.zip`. Salve o JSON para preservar o projeto além da sessão.


## Placas de base na 0.8.0

Nova família **Placa de base · Tipo 1** para pilar I/H, quatro chumbadores externos ASTM A36 e chapa sem enrijecedores. Entradas N/M/V já majoradas; N positivo comprime a base. Seleção dos regimes C1/C2/C3 e T1/T2/T3, chapa por contato/tração, contato no concreto normal de 20–50 MPa, ruptura do aço dos chumbadores e cortante por atrito ou resistência externa documentada.

Ancoragem no concreto, bloco armado, soldas e classificação de rigidez permanecem a complementar. O dispositivo de cisalhamento não é dimensionado; sua resistência externa não soma atrito. A Tabela 18 usa a versão corrigida em 2025. Consulte docs/PLACAS_DE_BASE_V080.md.

As cinco configurações de ligações anteriores e a preservação dos projetos da 0.7.5 foram mantidas.
