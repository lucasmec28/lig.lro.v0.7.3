# LRO Ligações 0.8.3

Cálculo local e detalhamento de ligações de aço com Streamlit, projetos JSON, desenhos proporcionais e memória Word com equações editáveis.

Desenvolvido por LRO Soluções de engenharia LTDA.

## Publicação

A distribuição pronta para GitHub contém quatro arquivos na raiz: `app.py`, `codigo_lro.zip`, `requirements.txt` e `README.md`. Envie os quatro juntos e mantenha `codigo_lro.zip` compactado. No Streamlit, use `app.py` e Python 3.12. Ao atualizar, substitua os quatro arquivos e reinicie o app.

Este README interno acompanha o código-fonte contido em `codigo_lro.zip`. Para desenvolvimento, extraia uma cópia separada e execute:

```bash
python -m pip install -r requirements-dev.txt
python -m pytest -q tests
python -m streamlit run app.py
```

## Ligações

- Single plate na alma da viga de apoio ou na mesa da coluna, com V e N de tração.
- Duas talas na alma da coluna, com V e N com sinal.
- End plate rotulada na mesa da coluna, com V e N com sinal.
- End plate engastada na mesa da coluna, com M, V e N, extensão acima e abaixo ou somente acima.

Esforços já de cálculo. Entradas em kgf e kgf·m na tela; dimensões em mm. Modelo plano, sem carregamento no eixo de menor inércia. Premissas e exclusões acompanham a tela e o final do Word.

## Melhorias incluídas desde a 0.7.4

Limites empíricos do método passam a avisos quando é possível executar as equações. A W200 pode seguir no modelo 4E com ressalva explícita de extrapolação. Espaçamento máximo e bordas máximas não atendidos deixam o resultado como **NÃO ATENDE AO DETALHAMENTO**, mas permitem calcular e exportar.

Novo campo **Linhas intermediárias entre as mesas** na end plate engastada: adiciona pares de parafusos no detalhe, considera todos os furos nos ligamentos e blocos, sem crédito resistente nem redistribuição das forças do grupo base 4E. O arranjo ampliado permanece com ressalva e exige avaliação específica para confirmar resistência e rigidez.

As cinco ligações foram auditadas; os critérios de resistência permanecem visíveis e as entradas não são corrigidas automaticamente. Veja `docs/AJUSTES_V074.md` para alcance, exemplos e bloqueios mantidos. Documentos de versões anteriores são históricos e devem ser lidos junto desta revisão.

Os exemplos W200 e W410 com linha intermediária são estudos com ressalvas; não são detalhes aprovados para execução. O exemplo W410 é uma reconstrução a partir do print, mantendo as demais entradas do JSON W200.

O pacote inclui o catálogo de perfis, módulos, exemplos, testes e documentos necessários, sem depender de instalações anteriores. `python verificar_pacote.py` verifica a integridade dos arquivos da distribuição original.


## Correções da 0.7.5

A navegação entre famílias mantém o projeto em edição; rotulada e engastada conservam rascunhos independentes. Valores numéricos não finitos nunca produzem uma verificação favorável. Os modelos estruturais da 0.7.4 foram preservados, inclusive as ressalvas da W200 e as linhas intermediárias sem crédito resistente. Veja `docs/AJUSTES_V075.md` dentro de `codigo_lro.zip`. Salve o JSON para preservar o projeto além da sessão.


## Placas de base na 0.8.0

Nova família **Placa de base · Tipo 1** para pilar I/H, quatro chumbadores externos ASTM A36 e chapa sem enrijecedores. Entradas N/M/V já majoradas; N positivo comprime a base. Seleção dos regimes C1/C2/C3 e T1/T2/T3, chapa por contato/tração, contato no concreto normal de 20–50 MPa, ruptura do aço dos chumbadores e cortante por atrito ou resistência externa documentada.

Ancoragem no concreto, bloco armado, soldas e classificação de rigidez permanecem a complementar. O dispositivo de cisalhamento não é dimensionado; sua resistência externa não soma atrito. A Tabela 18 usa a versão corrigida em 2025. Consulte docs/PLACAS_DE_BASE_V080.md.

As cinco configurações de ligações anteriores e a preservação dos projetos da 0.7.5 foram mantidas.


## Chave de chapa retangular na 0.8.1

Em Placa de base → Caminho resistente do cortante, selecione **Chave de chapa retangular · verificações locais**. Informe bh, bv, espessura e aço. O graute usa a dimensão real informada. São calculados contato local, flexão e cisalhamento da chapa, relação tpv≤tp e os efeitos globais do cortante excêntrico, com sinais: Mef=M+V[tp+(bv+en)/2]. M/V são informados na face superior, sem incluir essa parcela antecipadamente. O JSON guarda os valores de entrada.

O app apresenta as ações normativas para dimensionar as soldas na resistência de contato do concreto. **Resistência das soldas, metal-base/fixação local, ruptura do concreto e bloco armado permanecem a complementar.** Os resultados locais não aprovam o dispositivo completo. Cruciformes e trechos W continuam na rota de resistência externa documentada, com descritor claro, sem seção equivalente fictícia. Não se soma atrito.

Há exemplo didático de cortante puro, desenho de sinais/geometria, memória Word e testes de cinco casos de aceitação, inversão/cancelamento de sinais e preservação dos projetos. Veja `docs/CHAVE_RETANGULAR_V081.md` e `docs/VALIDACAO_V081.md`. As descrições da 0.8.0 acima registram o alcance daquela versão.


## Três opções de transferência do cortante

O seletor principal distingue **chumbadores**, **barra/chave de cisalhamento** e **atrito**, sem soma automática de resistências. Uma nova base abre em chumbadores com **quatro arruelas soldadas**, no domínio descrito abaixo. Atrito e resistência externa documentada continuam disponíveis. Projetos antigos conservam seu caminho e não são convertidos em aprovação nativa. Na rota externa, capacidade e referência são independentes das da chave; a confirmação de aplicabilidade é vinculada aos dados atuais e invalidada quando esses dados mudam.

A revisão geral do posicionamento de textos/cotas/chamadas nos desenhos ficou registrada como melhoria de baixa prioridade para etapa futura, conforme solicitado.


## Novo na 0.8.2: cortante nos chumbadores

O modelo nativo usa quatro barras ASTM A36 com arruelas especiais quadradas soldadas à placa, furo-padrão db+1,5 mm e dimensões reais de lado/espessura. Calcula as trações simultâneas por barra, a expressão especial da NBR 6.7.2.5, o limite adicional da interação geral de 6.3.3.4 e o limite local de concreto. Aplica o mínimo por barra antes da soma; no limite de tração, a reserva de cortante é zero. Não presume V/4 nem soma atrito ou chave.

A expressão publicada tem índice i na raiz e 1 no termo subtrativo. O app adota explicitamente a maior tração simultânea neste último termo como limite conservador e avisa quando as trações diferem. Isso não é apresentado como correção oficial da norma.

Cada solda recebe como ação de dimensionamento Fv,Rd sem redução. **Soldas, arruelas/transferência local, ancoragem no concreto, bloco e demais verificações da base continuam a complementar.** O limite local de concreto não substitui cone, arrancamento, pryout, bordas ou grupo. O resultado favorável dos componentes não aprova a base completa.

Há desenho das quatro arruelas reais, tabela de trações e resistências individuais, memória Word com equações editáveis e exemplos JSON. Método, domínio e ressalvas: `docs/CHUMBADORES_CORTANTE_V082.md`. Registro de software: `docs/VALIDACAO_V082.md`. A 0.8.1 permanece como distribuição independente.


## Cone de tração e detalhamento na 0.8.3

Verificação complementar do cone de concreto por tração conforme ACI 318-19, apoiada no AISC Design Guide 1, 3ª edição, para quatro chumbadores externos moldados no local com cabeça/porca/chapa enterrada e concreto íntegro. Considera as trações simultâneas efetivas, bordas reais do bloco, sobreposição das projeções, excentricidade do grupo e correção de embutimento por múltiplas bordas. A ancoragem completa continua a complementar: os modos não calculados são discriminados na tela e na memória. Não aplica resistência de cone a barra reta sem mecanismo definido, chumbador J ou ancoragem química.

Alma e mesas têm escolhas independentes de solda CJP ou filete; neste último, perna ou garganta, com conversão explícita para filete de pernas iguais a 90°. São especificações de detalhamento, sem resistência geral das soldas certificada. Vínculo rotulado/engastado representa a intenção do modelo, preservando N/M/V e quatro chumbadores. O par de enrijecedores no plano da alma é detalhamento sem crédito resistente. O graute desce da face inferior da placa a 45°, sem ampliar a área de contato usada no cálculo.

Veja `docs/PLACAS_DE_BASE_V083.md` para o alcance, limites e exemplos. Projetos anteriores continuam importáveis e não recebem automaticamente crédito de ancoragem no concreto.
