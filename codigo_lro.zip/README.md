# LRO Ligações 0.7.3

Esta é a cópia completa do código-fonte da versão 0.7.3. A distribuição para GitHub usa um inicializador externo e este conteúdo em `codigo_lro.zip`. Os métodos e limites técnicos permanecem os da versão 0.7.2.

Desenvolvido por LRO Soluções de engenharia LTDA.

[LinkedIn de Lucas Oliveira](https://www.linkedin.com/in/lucas-oliveira-722723149/?isSelfProfile=true)

Aplicativo Streamlit para ligações de perfis I, com desenho proporcional, verificação geométrica, memória Word editável e projetos JSON. Forças em **kgf**, momentos em **kgf·m**, dimensões em **mm**. Diâmetros e espessuras têm opções em polegadas. As ações inseridas já são de cálculo.

## Atualizar e abrir

1. Pare o app no terminal com **Ctrl+C**.
2. Extraia este pacote em uma **pasta nova**, preservando seus projetos JSON e a versão anterior.
3. Abra o terminal na pasta que contém `app.py`, ative seu ambiente Python 3.12 e execute:

```bash
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

Para uma instalação nova no Windows:

```powershell
py -3.12 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe -m streamlit run app.py
```

Para reabrir depois, basta o último comando. Não precisa reinstalar as bibliotecas em cada uso. Fechar apenas a aba do navegador não encerra o processo do aplicativo.

O pacote não altera automaticamente o app hospedado. Para Streamlit Cloud, atualize também as pastas `lro/` e `data/`, mantendo a estrutura; não envie `.venv`.

### Atualizar o GitHub / Streamlit Cloud

1. Extraia **este ZIP completo** em uma pasta nova. `app.py` está na raiz do ZIP.
2. No repositório do app, envie o conteúdo extraído, preservando a pasta `lro/` e suas subpastas. `app.py`, `requirements.txt`, `lro/` e `data/` devem ficar no mesmo nível. Não envie somente o ZIP ou somente `app.py`.
3. Confira no GitHub os caminhos `lro/double_cover_ui.py`, `lro/end_plate_ui.py` e `lro/models.py`.
4. Confira se o Streamlit aponta para esse repositório, a branch atualizada e `app.py`. Reinicie o app após terminar o envio de todos os arquivos.
5. Confira a versão **0.7.2** e teste as quatro opções do seletor **Tipo de ligação**.

Incluído `verificar_pacote.py`: execute `python verificar_pacote.py` na pasta extraída para conferir arquivos ausentes ou diferentes da distribuição. A conversão de quebra de linha entre Windows e Linux é aceita. Após uma alteração intencional de código, o verificador indicará a diferença em relação ao pacote original.

**Diagnóstico dos logs de 09/10/2026:** os dois módulos de interface e a propriedade `Issue.origin_label` existem nos ZIPs 0.7.1 e 0.7.2 conferidos. Os logs mostram que o processo publicado executou arquivos diferentes ou incompletos. Não foi possível determinar apenas pelos logs se a divergência ocorreu no envio, no caminho/branch de publicação ou em módulos antigos carregados. Esta revisão inclui mensagens de recuperação para arquivos ausentes e incompatibilidade do módulo de modelos; não altera equações ou resultados resistentes por causa desses erros de publicação.

## Famílias disponíveis

| Seleção | Ações de entrada | Arranjo |
|---|---|---|
| Single plate | V e N de tração | Chapa soldada à mesa da coluna ou alma da viga de apoio; viga apoiada parafusada |
| Alma de coluna com duas talas | V e N com sinal | Talas independentes, nervura e quatro horizontais soldados à coluna |
| End plate rotulada | V e N com sinal | Chapa de altura total, sobra inicial de 5 mm, parafusos entre mesas |
| End plate engastada | M, V e N com sinal | Modelo 4E sem nervuras, extensão acima e abaixo ou somente acima |

N positivo é tração; N negativo é compressão. Na end plate engastada, M positivo traciona a mesa superior. A ligação com extensão somente acima aceita esse sentido de momento; para o sentido inverso, use extensão também abaixo.

## Ajustes da versão 0.7.2

- **Enrijecedor oposto** na single plate viga–viga, independente do complemento entre mesas. Espessura, largura, alívio, filete e aço ajustáveis; desenho proporcional, Word e JSON acompanham os dados.
- A opção é de detalhamento: não dimensiona o reforço, suas soldas ou a redistribuição para as mesas. A punção e as demais resistências não recebem aumento por ativar o enrijecedor. A premissa aparece no final da página e do Word.
- Corrigida a transcrição da alternativa rigorosa do SCI P358 para **cortante puro**: usa `ts·tp`, não `ts²`. A equação Word e os testes foram atualizados. Casos com N > 0 continuam com o requisito conservador, sem alteração numérica.
- Mantidos os ajustes 0.7.1: interferências de montagem permitem cálculo e exportação quando as equações são válidas; complemento até as mesas disponível apenas em viga–viga, sem verificações extras nem crédito resistente.
- `examples/Teste_usuario_enrijecedor_oposto.docx` mostra o novo detalhe no caso W150×13,0 → W250×22,3, com complemento e enrijecedor de largura ilustrativa de 45 mm. As falhas do caso recebido continuam indicadas. Os esforços e os componentes originais não foram redimensionados.

Consulte `docs/AJUSTES_V072.md` para hipóteses, correção da punção e fontes. Recalcule projetos com cortante puro e gere novamente suas memórias.

## Recursos da versão 0.7

- O resultado de atendimento passou a ser **ATENDE ÀS VERIFICAÇÕES REALIZADAS**. As premissas e exclusões ficam no final da tela e no final do Word. Falhas resistentes, geometrias inválidas e condições reais fora do domínio continuam sendo indicadas.
- As end plates verificam parafusos sob tração, cisalhamento e interação elíptica; contato nos furos; blocos da chapa; soldas e metal-base; alma da viga; mesa e alma da coluna. A engastada inclui o painel da coluna sob as premissas declaradas.
- A rotulada compara a espessura com os limites de flexibilidade do detalhamento e com a espessura necessária para não omitir efeito alavanca sob N.
- A engastada calcula a espessura mínima da chapa e da mesa da coluna pelo procedimento de chapa espessa do DG39. Adota-se o comportamento usual pela NBR 6.1.2.3, dentro do domínio do modelo. Não se calcula uma curva momento–rotação ou uma mola Si para a análise global.
- Os projetos antigos de single plate e duas talas continuam aceitos. As end plates usam um tipo JSON próprio. Ao carregar um exemplo ou projeto de end plate, o tipo exibido acompanha o arquivo.

## Domínio das end plates

A end plate engastada usa a geometria **4E** do Design Guide 39, com dois parafusos por linha e sem enrijecedores. Os intervalos ensaiados do guia, incluindo a margem de 10%, são conferidos. Exige-se momento dominante: `|N|(d−tf) ≤ |M|`. Aço da chapa com fy até 345 MPa. Não se extrapola o procedimento para axial dominante, chapa enrijecida, múltiplas colunas de parafusos ou outros padrões de furação.

A rotulada usa gabarito de 90–140 mm e chapa com fy até 275 MPa, inicialmente A36. O limite adotado é 10 mm para vigas até 457 mm de altura e 12 mm para vigas maiores. Os demais aços continuam no catálogo; escolher material fora desse domínio produz indicação para revisar a escolha.

A conferência normativa mínima de 45 kN atua sobre a resultante N/V, com direção e sentido preservados. **O momento externo não é multiplicado por esse fator.** Não se aplica automaticamente um suposto mínimo de momento de 50% da resistência da viga.

Nas end plates engastadas, as juntas **viga–chapa** são CJP nas duas mesas e na alma, com metal de adição compatível. Na rotulada são filetes contínuos. Em ambas, **chapa–coluna é parafusada**.

A coluna é contínua, sem extremidade ou emenda próxima; não há outra viga ou cargas locais concorrentes no nó. O painel usa a hipótese `Ncol,Sd ≤ 0,4 Ag,col fy,col` e não desconta cortante favorável da coluna. As verificações globais dos membros e a compatibilização com o modelo estrutural permanecem no projeto.

## Exemplos e documentação

`examples/` conserva os projetos JSON anteriores e inclui o novo Word e SVG da versão 0.7.2. Os relatórios e desenhos estáticos antigos foram retirados deste pacote; use os JSON para gerar resultados atualizados. Os três exemplos de end plate usam W410×38,8 chegando à mesa de CS600×281. Os esforços são exemplos de uso, não um dimensionamento aprovado para uma obra.

- `docs/END_PLATES_METODOLOGIA.md`: equações, hipóteses, limites e fontes das novas famílias.
- `docs/registro_end_plates.json`: resultados numéricos reproduzíveis dos exemplos.
- `docs/DUAS_TALAS_METODOLOGIA.md`: modelo local da nervura e talas.
- `docs/REVISAO_TECNICA.md` e `docs/METODOLOGIA.md`: histórico técnico das single plates.

Nas duas talas, estabilidade acoplada e capacidade de rotação do conjunto continuam fora das verificações de componentes; a nota está nas premissas. Nas single plates, a interação fora do plano da alma da viga de apoio sob N+V ou N excêntrico continua excluída. A alteração de apresentação não atribui resistência a esses mecanismos.

## Testes

```bash
python -m pip install -r requirements-dev.txt
python -m pytest -q tests
```

Incluem regressão das famílias anteriores, comparação numérica com o exemplo 5.3-1 do DG39, substituição independente das equações da NBR, conversão de unidades, sinais, domínio, interação nos parafusos, importação e exportação. São testes de software e conferências analíticas identificadas, não validação experimental do conjunto.
