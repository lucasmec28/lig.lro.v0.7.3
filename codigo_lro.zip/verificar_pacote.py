"""Confere a distribuição local com o manifesto; não requer bibliotecas extras."""
import hashlib
import json
from pathlib import Path


def verify(root):
    root = Path(root)
    try:
        manifest = json.loads((root / 'docs/release_manifest.json').read_text(encoding='utf-8'))
        entries = manifest['files']
        if not entries:
            raise ValueError('manifesto vazio')
    except (OSError, ValueError, KeyError) as exc:
        return [f'Manifesto indisponível ou inválido: {exc}']
    problems = []
    for entry in entries:
        relative = Path(entry['path'])
        if relative.is_absolute() or '..' in relative.parts:
            problems.append(f'Caminho inválido no manifesto: {relative}')
            continue
        path = root / relative
        if not path.is_file():
            problems.append(f'Ausente: {relative.as_posix()}')
            continue
        data = path.read_bytes()
        if hashlib.sha256(data).hexdigest() == entry['sha256']:
            continue
        # Git/Windows podem converter LF para CRLF sem mudar o conteúdo.
        normalized = hashlib.sha256(data.replace(b'\r\n', b'\n')).hexdigest()
        if normalized != entry.get('sha256_lf'):
            problems.append(f'Diferente do pacote: {relative.as_posix()}')
    return problems


if __name__ == '__main__':
    problems = verify(Path(__file__).resolve().parent)
    for problem in problems:
        print(problem)
    print('PACOTE ÍNTEGRO' if not problems else 'REVISAR ARQUIVOS DO PACOTE')
    raise SystemExit(bool(problems))
