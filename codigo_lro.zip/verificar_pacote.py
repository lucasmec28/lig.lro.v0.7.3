"""Confere a distribuição local com o manifesto; não requer bibliotecas extras."""
import hashlib
import json
from pathlib import Path


def verify(root):
    root = Path(root)
    try:
        current_path=root / 'docs/CATALOG_SCOPE0965_MANIFEST.json'
        manifest = json.loads((current_path if current_path.is_file() else root / 'docs/release_manifest.json').read_text(encoding='utf-8'))
        if current_path.is_file() and manifest.get('kind')!='catalog_scope0965':raise ValueError('identidade do manifesto atual inválida')
        entries = manifest['files']
        if not entries:
            raise ValueError('manifesto vazio')
        # A revisão restrita preserva o manifesto histórico da base 0.9.44.
        # Sobrepor somente os arquivos declarados no patch desta cópia.
        patch_path = root / 'docs/DIRECT_SEAT_PATCH_MANIFEST.json'
        if not current_path.is_file() and patch_path.is_file():
            patch = json.loads(patch_path.read_text(encoding='utf-8'))
            baseline_bytes = (root / 'docs/release_manifest.json').read_bytes()
            if (patch.get('kind') != 'restricted_direct_seat_patch'
                    or hashlib.sha256(baseline_bytes.replace(b'\r\n', b'\n')).hexdigest()
                    != patch.get('base_release_manifest_sha256_lf')):
                raise ValueError('patch não corresponde ao manifesto da base')
            merged = {entry['path']: entry for entry in entries}
            for entry in patch['files']:
                merged[entry['path']] = entry
            entries = list(merged.values())
    except (OSError, ValueError, KeyError) as exc:
        return [f'Manifesto indisponível ou inválido: {exc}']
    problems = []
    for entry in entries:
        relative = Path(entry['path'])
        if relative.is_absolute() or '..' in relative.parts:
            problems.append(f'Caminho inválido no manifesto: {relative}')
            continue
        path = root / relative
        if not path.is_file():
            problems.append(f'Ausente: {relative.as_posix()}')
            continue
        data = path.read_bytes()
        if hashlib.sha256(data).hexdigest() == entry['sha256']:
            continue
        # Git/Windows podem converter LF para CRLF sem mudar o conteúdo.
        normalized = hashlib.sha256(data.replace(b'\r\n', b'\n')).hexdigest()
        if normalized != entry.get('sha256_lf'):
            problems.append(f'Diferente do pacote: {relative.as_posix()}')
    return problems


if __name__ == '__main__':
    problems = verify(Path(__file__).resolve().parent)
    for problem in problems:
        print(problem)
    print('PACOTE ÍNTEGRO' if not problems else 'REVISAR ARQUIVOS DO PACOTE')
    raise SystemExit(bool(problems))
