"""Confere a distribuição compacta atual; não requer bibliotecas extras.

Manifestos históricos são mantidos como evidência, nunca como validadores da
revisão atual. O manifesto 0973 é criado somente na cópia de distribuição.
"""
import hashlib
import json
from pathlib import Path, PurePosixPath

MANIFEST = 'docs/WELDED_COVERPLATE0973_MANIFEST.json'
PACKAGE_ID = '0.9.73'


def _relative(value):
    if not isinstance(value, str) or not value or '\\' in value or ':' in value:
        raise ValueError('caminho inválido no manifesto')
    path = PurePosixPath(value)
    if path.is_absolute() or '..' in path.parts or str(path) != value:
        raise ValueError('caminho inválido no manifesto: ' + value)
    return path


def verify(root):
    root = Path(root)
    try:
        manifest = json.loads((root / MANIFEST).read_text(encoding='utf-8'))
        if (manifest.get('kind') != 'welded_coverplate0973'
                or manifest.get('package') != PACKAGE_ID):
            raise ValueError('identidade do manifesto atual inválida')
        entries = manifest['files']
        if not isinstance(entries, list) or not entries:
            raise ValueError('manifesto vazio ou inválido')
        seen = set()
        for entry in entries:
            name = str(_relative(entry['path']))
            if name in seen or name == MANIFEST:
                raise ValueError('entrada repetida ou autorreferente: ' + name)
            seen.add(name)
            for key in ('sha256', 'sha256_lf'):
                digest = entry[key]
                if (not isinstance(digest, str) or len(digest) != 64
                        or any(c not in '0123456789abcdef' for c in digest)):
                    raise ValueError('SHA-256 inválido: ' + name)
    except (OSError, ValueError, KeyError, TypeError, AttributeError) as exc:
        return [f'Manifesto atual indisponível ou inválido: {exc}']
    problems = []
    for entry in entries:
        relative = entry['path']
        path = root / relative
        if path.is_symlink() or not path.resolve().is_relative_to(root.resolve()):
            problems.append(f'Caminho inválido no pacote: {relative}')
            continue
        if not path.is_file():
            problems.append(f'Ausente: {relative}')
            continue
        data = path.read_bytes()
        if hashlib.sha256(data).hexdigest() == entry['sha256']:
            continue
        normalized = hashlib.sha256(data.replace(b'\r\n', b'\n')).hexdigest()
        if normalized != entry['sha256_lf']:
            problems.append(f'Diferente do pacote: {relative}')
    for path in sorted(root.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts or path.suffix == '.pyc':
            continue
        relative = path.relative_to(root).as_posix()
        if relative not in seen and relative != MANIFEST:
            problems.append(f'Não declarado no pacote: {relative}')
    return problems


if __name__ == '__main__':
    problems = verify(Path(__file__).resolve().parent)
    for problem in problems:
        print(problem)
    print('PACOTE ÍNTEGRO' if not problems else 'REVISAR ARQUIVOS DO PACOTE')
    raise SystemExit(bool(problems))
